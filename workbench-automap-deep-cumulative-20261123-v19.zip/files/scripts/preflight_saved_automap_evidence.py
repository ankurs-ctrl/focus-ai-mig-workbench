"""Measure real admitted evidence and exact continuations; never call models or write mappings."""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/sttm-builder"))
sys.path.insert(0, str(ROOT / "scripts"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request-file")
    parser.add_argument("--env-file")
    parser.add_argument("--summary-only", action="store_true", help="Summarize cached diagnostics without connecting or exposing packet bodies")
    parser.add_argument("--batch-index", type=int, choices=range(4))
    parser.add_argument("--prepare-current", action="store_true", help="Read current project, Values, links and corrections instead of archived learning")
    parser.add_argument("--live", action="store_true", help="Run one bounded isolated batch; never apply its results")
    args = parser.parse_args()
    private = ROOT / ".dev-cache" / "automap-real-evidence-preflight"
    if args.summary_only:
        if args.request_file:
            from app.core.sttm_builder import STTMBuilderService
            from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
            request = STTMBuilderEnvelopeRequest.model_validate(json.loads(Path(args.request_file).read_text(encoding="utf-8")))
            columns, profiles, _, _ = STTMBuilderService._learning_retrieval_inputs(request, request.context.target_table.qualified_name)
            print(json.dumps({"retrieval_input_columns": len(columns), "typed_profiles": sum(bool(item.get("type")) for item in profiles),
                              "grained_profiles": sum(bool(item.get("grain")) for item in profiles),
                              "source_tables": [table.qualified_name for table in request.context.source_tables],
                              "semantic_shapes": sorted({tuple(sorted(item.semantic_model))
                                                  for item in request.context.semantic_context if isinstance(item.semantic_model, dict)})}, indent=2))
        for path in sorted(private.glob("batch-[0-9][0-9].json")):
            summary = json.loads(path.read_text(encoding="utf-8"))["summary"]
            exclusions = {json.dumps(item, sort_keys=True): item for diagnostic in summary["diagnostics"].values()
                          for item in diagnostic.get("recipe_admission", {}).get("exclusions", [])}
            print(json.dumps({"batch": summary["batch"], "sizes": summary["sizes"],
                              "admitted_recipes": sum(summary["recipe_counts"].values()),
                              "target_counts": {target: diagnostic.get("inapplicable_pattern_count")
                                                for target, diagnostic in summary["diagnostics"].items()},
                              "exclusions": list(exclusions.values())}, indent=2))
        return
    if not args.request_file or not args.env_file:
        parser.error("--request-file and --env-file are required unless --summary-only is used")
    if args.live and args.batch_index is None:
        parser.error("The live probe requires exactly one --batch-index")
    from app.core.config import Settings
    from app.core.snowflake import SnowflakeClient
    from app.core.sttm_builder import STTMBuilderService
    from app.core.automap_batching import dependency_batches
    from app.core.automap_policy import focused_learning
    from app.core.automap_retrieval import AutoMapContext, batch_messages, batch_packet, encoded
    from app.core.assistant_retrieval import budget_messages
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMAgentRequestEnvelope
    from automap_message_sizes import expand_packet

    settings = Settings(_env_file=args.env_file)
    request = STTMBuilderEnvelopeRequest.model_validate(json.loads(Path(args.request_file).read_text(encoding="utf-8")))
    client = SnowflakeClient(settings)
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._settings, service._session = settings, client.session
    private.mkdir(parents=True, exist_ok=True)
    try:
        if args.prepare_current:
            from app.core.learning_retrieval import LearningRetrievalService
            service._settings = settings.model_copy(update={"automap_context_retrieval_v1": True})
            service._learning_service = LearningRetrievalService(client.session, service._settings)
            request = request.model_copy(update={"context": request.context.model_copy(update={
                "learning_context": None, "prepared_context_hash": None,
            })})
            request = service._with_learning_context(request)
        for index, attributes in enumerate(dependency_batches(request, 4)):
            if args.batch_index is not None and index != args.batch_index:
                continue
            batch = request.model_copy(update={"data": request.data.model_copy(update={"attributes": attributes})})
            raw = STTMAgentRequestEnvelope.from_builder_request(batch).model_dump(mode="json", exclude_none=True)
            raw["context"]["learning_context"] = focused_learning(raw["context"].get("learning_context") or {})
            store = AutoMapContext(raw)
            store.manifest()
            discovery = service._discover_auto_map_batch_evidence(batch, list(store.targets))
            store.discover_batch(lambda targets: {target: discovery[target] for target in targets})
            results = []

            def complete_reads(operations):
                pending = list({encoded(item): item for item in operations}.values())
                count = 0
                while pending:
                    pending = [operation for operation in pending if not any(item["request"] ==
                        {key: value for key, value in operation.items() if key != "cursor"} for item in results)]
                    if not pending:
                        break
                    chunk, pending = pending[:24], pending[24:]
                    count += len(chunk)
                    if count > settings.automap_context_max_operations:
                        raise ValueError("Preflight exact-read operation allowance exceeded")
                    response = store.read_many({"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash,
                        "operation": "multi_read", "reads": chunk}, max_bytes=32768,
                        max_total_bytes=settings.agent_outbound_message_max_bytes)
                    for item in response["results"]:
                        operation, result = item["request"], item["result"]
                        if result.get("error"):
                            raise ValueError(result["detail"])
                        if result.get("next_cursor"):
                            pending.append({**operation, "cursor": result["next_cursor"]})
                        else:
                            exact = {key: value for key, value in operation.items() if key != "cursor"}
                            if not any(item["request"] == exact for item in results):
                                results.append({"request": exact, "result": store.exact_completed_result(exact)})

            complete_reads([operation for target in store.targets
                            for operation in store.required_operations(target, {"source_attributes": []})])
            positive_chars = store.check_positive_budget(settings.automap_learning_max_chars)
            initial = batch_packet(store, results)
            operations = []
            for target in store.targets:
                # This is serialization pressure from admitted primary evidence,
                # not a claim that a model selected a correct mapping.
                operations.extend(store.required_operations(target, {
                    "source_attributes": [], "used_learning_ids": sorted(store.recipe_ids(target)),
                }))
                candidates = discovery[target].get("source_candidates", {}).get(target, [])
                if candidates:
                    operations.extend(store.required_operations(target, {"source_attributes": [candidates[0]]}))
            complete_reads(operations)
            continuation = batch_packet(store, results)
            expected = store.manifest()
            expected["retrieved_auto_map_context"] = [{key: value for key, value in item.items() if key != "read_key"}
                                                       for item in results]
            assert expand_packet(continuation) == expected
            sizes = {}
            for name, packet in (("initial", initial), ("continuation", continuation)):
                messages = batch_messages(packet)
                sizes[name] = {"chars": len(encoded(messages)), "bytes": len(encoded(messages).encode())}
                try:
                    budget_messages(messages, max_chars=settings.agent_outbound_message_max_chars,
                                    max_bytes=settings.agent_outbound_message_max_bytes)
                    sizes[name]["status"] = "fits"
                except ValueError as exc:
                    sizes[name].update(status="blocked", error=str(exc))
            summary = {"batch": index, "targets": len(store.targets), "positive_chars": positive_chars,
                       "sizes": sizes, "recipe_counts": {target: len(store.recipe_ids(target)) for target in store.targets},
                       "diagnostics": {target: discovery[target].get("diagnostics") for target in store.targets},
                       "exact_expansion": True,
                       "limitation": "Real discovery/admission plus dependency pressure; no model selection, accuracy or acceptance claim."}
            (private / f"batch-{index:02d}.json").write_text(encoded({"summary": summary,
                "discovery": discovery, "initial": initial, "continuation": continuation}), encoding="utf-8")
            admission_exclusions = {encoded(item): item for diagnostic in summary["diagnostics"].values()
                                    for item in diagnostic.get("recipe_admission", {}).get("exclusions", [])}
            print(json.dumps({**summary, "diagnostics": {**next(iter(summary["diagnostics"].values()), {}),
                "inapplicable_pattern_count": sum(item["stage"] == "applicability" for item in admission_exclusions.values()),
                "recipe_admission": {"exclusions": list(admission_exclusions.values())}},
                "target_status": {target: discovery[target].get("diagnostics", {}).get("status") for target in store.targets}}), flush=True)
            if args.live:
                if any(value["status"] != "fits" for value in sizes.values()):
                    raise ValueError("Exact preflight budget failed; model was not called")
                if any(discovery[target].get("diagnostics", {}).get("status") in
                       {"unavailable", "degraded", "error"} for target in store.targets):
                    raise ValueError("Evidence retrieval failed; model was not called")
                from app.core.snowflake_agent import SnowflakeAgentClient
                from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
                from app.guardrails.config.loader import load_config
                from app.guardrails.contracts.decisions import GovernanceDecision
                rest = client.get_rest_session_context()
                service._settings = settings.model_copy(update={"automap_context_retrieval_v1": True,
                    "automap_context_max_rounds": 2, "automap_context_target_seconds": 150})
                service._agent = SnowflakeAgentClient(token=rest.token, host=rest.host,
                    auth_mode="snowflake_token", request_timeout=60)
                service._source_mapping_agent_name = settings.resolved_source_mapping_agent
                service._model_guard = ModelBoundaryGuard(load_config(settings=settings))
                # Freeze the already admitted evidence for this isolated probe.
                # Further Search is not replaced with fixture or archived rules.
                service._discover_auto_map_batch_evidence = lambda req, targets, **options: (
                    STTMBuilderService._discover_auto_map_batch_evidence(service, req, targets, **options)
                    if options else {target: deepcopy(discovery[target]) for target in targets})
                decision = GovernanceDecision(trace_id="bounded-saved-batch-probe",
                    request_id=batch.request_id, operation=batch.operation.value)
                text, thread, metadata = service._invoke_retrieval_auto_map(batch, decision)
                response = json.loads(text)
                audit = metadata["auto_map_retrieval"]
                mappings = response["data"]["result"]["mappings"]
                (private / f"batch-{index:02d}-live.json").write_text(encoded({"response": response,
                    "thread": thread, "metadata": metadata}), encoding="utf-8")
                print(json.dumps({"batch": index, "model_calls": audit["model_call_count"],
                    "elapsed_seconds": audit["elapsed_seconds"], "peak_bytes": audit["peak_message_bytes"],
                    "grounded": sum(value.get("transformation_classification") != "unresolved" for value in mappings.values()),
                    "results": {target: {"classification": value.get("transformation_classification"),
                        "reason": value.get("unmatched_reason")} for target, value in mappings.items()},
                    "limitation": "Bounded isolated existing-agent probe; no application acceptance, save, publication or load."}), flush=True)
    finally:
        client.close()


if __name__ == "__main__":
    main()