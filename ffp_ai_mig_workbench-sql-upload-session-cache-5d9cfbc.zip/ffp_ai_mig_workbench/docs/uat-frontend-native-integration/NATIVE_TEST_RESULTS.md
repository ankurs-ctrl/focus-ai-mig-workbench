# Native Auto-map verification — 2 November 2026

Release state: client-test package requested by the user before live acceptance is complete. Do not broadly enable UAT until the remaining live matrix passes.

## Completed

- Full STTM Builder backend suite: 4,092 passed, 31 skipped in 213.41 seconds. Four skips require the external authoritative client.env; 27 were already skipped. No replacement env was fabricated. This final local run includes the latest guidance and tool-contract changes. Two additional coverage/invalid-contract tests subsequently passed in a 36-test focused run.
- 21 frontend harnesses passed; TypeScript noEmit passed before the latest backend-only corrections.
- Deployment wrapper: 147 passed after correcting PowerShell 7.5 process environment removal and blank required export handling.
- DEV protocol checks: nine caller-rights procedures, dedicated investigator and transformation agents, Search service and separate admission/Analyst resources verified. Existing shared agents and UAT were not modified.
- Real registered evidence read returned the requested source card and its owner capsule. Its isolated probe snapshot was separate from the model test and did not establish model read coverage.
- Live technical positive control `native-dev-aff048061b5c41b3a4a7a52390c9b60d`: completed, BILLINGCOUNTRY selected cc."COUNTRY_CODE", one agent run, four tool calls, exact evidence and server compilation, durable target checkpoint. 166.34 seconds including preparation/archiving. This is a synthetic target contract over a real DEV source, not certification of household joins or client migration accuracy. Search and Analyst were not invoked in this control.

## Live failures corrected during testing

1. SQL literal escaping altered embedded JSON in CREATE AGENT. Renderer now escapes backslashes as well as quotes.
2. Snowflake UPDATE returns both affected rows and a multi-joined diagnostic counter. Exactly one updated row with zero multi-joined rows is required.
3. Float timestamp binding failed in TO_TIMESTAMP_LTZ. Registry deadlines now bind integer microseconds with explicit numeric type/scale.
4. Local Snowpark 1.18 lacked the archive AST-control API. Local tests use temporary Snowpark 1.56; application dependency minimum is 1.40.
5. Quoted lowercase procedure parameter was incompatible with agent named-argument invocation. Procedures now declare unquoted REQUEST_JSON; probes use named arguments.
6. Agent flattened operation fields outside params. Per-tool specifications now include complete request examples, mandatory target scope, and actionable error feedback. Validation was not weakened.
7. Current mapping intent/project context existed in the immutable archive but was not mandatory evidence in the native path. An exact required guidance node now carries it. This latest change is locally tested but not yet reinstalled/live replayed.
8. Learning coverage formerly followed semantic support rather than historical retrieval. It now records completed target-scoped SearchPrecedents operations.
9. Parent recovery could wait on SQL connection setup before yielding ready HTTP responses. It now uses one bounded independent reader and retains deadline/failed-response recovery tests.

## Remaining acceptance

- Re-render and reinstall the latest guidance/coverage runtime changes in DEV; pin the verified agent definitions.
- Actual scoped Search -> read -> checkpoint, real prepared Analyst observation, and actual independent transformation specialist with compiled/executed rule.
- Actual webapp -> proxy -> worker -> durable job -> response/UI delivery (local services were started on 8017/8018; frontend startup on 3017 was blocked by approval-review usage availability).
- Physical manual mapping and uploaded narrow CTE, larger parallel batch case, checked/no-checkbox reevaluation, saved edit fencing, partial failures and unresolved policy/contradictions.
- Confirm mapping/rule semantics against expected results, SQL execution, coverage and latency, not only terminal status.
- Final backend/frontend regression and diff/package checks.
- Client AVD authoritative profile gates and client UAT accuracy acceptance remain separate.

V11 is packaged at the user’s request as a client-test delta; it has not been committed or pushed. Do not treat DEV installation or the technical positive control as full release acceptance.
