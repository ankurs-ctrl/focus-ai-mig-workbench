'use client';

import {
    createContext,
    useCallback,
    useContext,
    useEffect,
    useMemo,
    useRef,
    useState,
    type ReactNode,
} from 'react';
import {
    AI_CHAT_DEFAULT_SIDEBAR_WIDTH,
    AI_CHAT_MAX_SIDEBAR_WIDTH,
    AI_CHAT_MIN_SIDEBAR_WIDTH,
    AI_CHAT_MOBILE_BREAKPOINT,
    AI_CHAT_RAIL_TOP_STORAGE_KEY,
    AI_CHAT_SIDEBAR_WIDTH_STORAGE_KEY,
    AI_CHAT_TABLET_BREAKPOINT,
    clampRailTop,
    getDefaultRailTop,
    loadRailTop,
    loadSidebarWidth,
} from '@/features/ai-agent/ai-chat-layout-constants';
import {
    createChatSessionId,
    deriveSessionTitle,
    loadAllStoredChatSessions,
    loadStoredChatSessions,
    persistChatSessions,
    type StoredChatSession,
} from '@/features/ai-agent/ai-chat-session-utils';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { deleteAssistantConversation, fetchAssistantConversation, fetchAssistantConversationHistory, importLegacyQuickHistory, updateAssistantConversation } from '@/services/migrationAgentService';

type PanelView = 'chat' | 'history' | 'notifications';

type AiChatLayoutContextValue = {
    isOpen: boolean;
    isFullscreen: boolean;
    panelView: PanelView;
    historySearch: string;
    sessions: StoredChatSession[];
    activeSessionId: string | null;
    selectedRecommendationId: string | null;
    resolvedRecommendationIds: ReadonlySet<string>;
    recentSessions: StoredChatSession[];
    railTop: number;
    effectiveSidebarWidth: number;
    isResizing: boolean;
    isMobile: boolean;
    isTablet: boolean;
    layoutHeight: number;
    newChatVersion: number;
    agentPageProjectId: string | null;
    setLayoutMetrics: (width: number, height: number) => void;
    setHistorySearch: (value: string) => void;
    setPanelView: (view: PanelView) => void;
    setAgentPageProjectId: (projectId: string | null) => void;
    openChat: () => void;
    closeChat: () => void;
    toggleFullscreen: () => void;
    exitFullscreen: () => void;
    handleNewChat: () => void;
    handleShowHistory: () => void;
    handleShowNotifications: () => void;
    handleSelectRecommendation: (recommendationId: string) => void;
    markRecommendationResolved: (recommendationId: string) => void;
    handleSelectSession: (session: StoredChatSession) => void;
    handleDeleteSession: (session: StoredChatSession) => Promise<void>;
    handleUpdateSession: (session: StoredChatSession, changes: { title?: string; projectId?: string | null; pinned?: boolean }) => Promise<void>;
    beginRailDrag: (event: React.MouseEvent<HTMLDivElement>) => void;
    beginRailTouchDrag: (event: React.TouchEvent<HTMLDivElement>) => void;
    beginSidebarResize: (event: React.MouseEvent<HTMLDivElement>) => void;
};

const AiChatLayoutContext = createContext<AiChatLayoutContextValue | null>(null);

function hasUserMessages(messages: { role: string }[]) {
    return messages.some((message) => message.role === 'user');
}

export function AiChatLayoutProvider({ children }: { children: ReactNode }) {
    const [isOpen, setIsOpen] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [panelView, setPanelView] = useState<PanelView>('chat');
    const [sidebarWidth, setSidebarWidth] = useState(AI_CHAT_DEFAULT_SIDEBAR_WIDTH);
    const [isResizing, setIsResizing] = useState(false);
    const [historySearch, setHistorySearch] = useState('');
    const [sessions, setSessions] = useState<StoredChatSession[]>([]);
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
    const [selectedRecommendationId, setSelectedRecommendationId] = useState<string | null>(null);
    const [resolvedRecommendationIds, setResolvedRecommendationIds] = useState<Set<string>>(
        () => new Set(),
    );
    const [railTop, setRailTop] = useState(0);
    const [layoutWidth, setLayoutWidth] = useState(1200);
    const [layoutHeight, setLayoutHeight] = useState(600);
    const [hydrated, setHydrated] = useState(false);
    const [newChatVersion, setNewChatVersion] = useState(0);
    const [agentPageProjectId, setAgentPageProjectIdState] = useState<string | null>(null);
    const isDraggingRailRef = useRef(false);

    const {
        chatMessages,
        resetChatSession,
        restoreChatSession,
        session,
        activeProjectId,
        activeSttmId,
    } = useSttmBuilderContext();
    const chatScope = agentPageProjectId != null
        ? `${session?.user_id ?? 'anonymous'}::${agentPageProjectId || 'general'}::agent`
        : `${session?.user_id ?? 'anonymous'}::${activeProjectId ?? 'new'}::${activeSttmId ?? 'new'}`;

    const setAgentPageProjectId = useCallback((projectId: string | null) => {
        setAgentPageProjectIdState(projectId);
        setPanelView('chat');
        setHistorySearch('');
        setSelectedRecommendationId(null);
        setResolvedRecommendationIds(new Set());
    }, []);

    const isMobile = layoutWidth < AI_CHAT_MOBILE_BREAKPOINT;
    const isTablet =
        layoutWidth >= AI_CHAT_MOBILE_BREAKPOINT && layoutWidth < AI_CHAT_TABLET_BREAKPOINT;

    const effectiveSidebarWidth = useMemo(() => {
        if (isFullscreen) {
            return Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, layoutWidth);
        }
        if (isMobile) {
            return Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, layoutWidth);
        }
        if (isTablet) {
            return Math.min(380, Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, layoutWidth - 16));
        }
        return Math.min(
            AI_CHAT_MAX_SIDEBAR_WIDTH,
            Math.max(
                AI_CHAT_MIN_SIDEBAR_WIDTH,
                Math.min(sidebarWidth, layoutWidth - 16),
            ),
        );
    }, [isFullscreen, isMobile, isTablet, layoutWidth, sidebarWidth]);

    const setLayoutMetrics = useCallback((width: number, height: number) => {
        setLayoutWidth(width);
        setLayoutHeight(height);
        setRailTop((current) => clampRailTop(current || getDefaultRailTop(height), height));
    }, []);

    useEffect(() => {
        const stored = agentPageProjectId != null
            ? loadAllStoredChatSessions(String(session?.user_id ?? 'anonymous'))
            : loadStoredChatSessions(chatScope);
        // Session history is hydrated from browser storage when the scope changes.
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setSessions(stored);
        setActiveSessionId(null);
        setSelectedRecommendationId(null);
        setResolvedRecommendationIds(new Set());
        setSidebarWidth(loadSidebarWidth());
        setHydrated(true);
        const migrationMarker = `aia:server-history-migrated::${chatScope}`;
        if (stored.length && !window.localStorage.getItem(migrationMarker)) {
            const browserMigrationId = `browser:${chatScope}`;
            void importLegacyQuickHistory(browserMigrationId, stored)
                .then((confirmed) => {
                    if (confirmed) window.localStorage.setItem(migrationMarker, new Date().toISOString());
                })
                .catch(() => {
                    // Retain local history and retry on a later authenticated visit.
                });
        }
        void fetchAssistantConversationHistory()
            .then((serverSessions) => {
                setSessions((current) => {
                    const localByBackendId = new Map(current.filter((item) => item.backendConversationId).map((item) => [item.backendConversationId, item]));
                    const serverRows: StoredChatSession[] = serverSessions
                        .map((item) => {
                            const local = localByBackendId.get(item.conversation_id);
                            return ({
                            id: local?.id ?? item.conversation_id,
                            title: item.title,
                            messages: local?.messages ?? [],
                            updatedAt: new Date(item.updated_at).getTime(),
                            mode: item.mode,
                            backendConversationId: item.conversation_id,
                            projectId: item.project_id ?? null,
                            sttmId: item.sttm_id ?? null,
                            storageScope: local?.storageScope,
                            pinned: item.pinned ?? local?.pinned ?? false,
                        });
                        });
                    const serverIds = new Set(serverSessions.map((item) => item.conversation_id));
                    return [...current.filter((item) => !item.backendConversationId || !serverIds.has(item.backendConversationId)), ...serverRows].sort((a, b) => b.updatedAt - a.updatedAt);
                });
            })
            .catch(() => {
                // Local history remains available while server history is unavailable.
            });
    }, [agentPageProjectId, chatScope, session?.user_id]);

    useEffect(() => {
        if (!hydrated || layoutHeight <= 0) return;
        // Restore the persisted position after the container has a measured height.
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setRailTop((current) => {
            if (current > 0) return clampRailTop(current, layoutHeight);
            return loadRailTop(layoutHeight);
        });
    }, [hydrated, layoutHeight]);

    useEffect(() => {
        const refresh = () => {
            void fetchAssistantConversationHistory().then((serverSessions) => {
                setSessions((current) => {
                    const byBackendId = new Map(current.filter((item) => item.backendConversationId)
                        .map((item) => [item.backendConversationId as string, item]));
                    for (const item of serverSessions) {
                        const existing = byBackendId.get(item.conversation_id);
                        byBackendId.set(item.conversation_id, {
                            id: existing?.id ?? item.conversation_id,
                            title: item.title,
                            messages: existing?.messages ?? [],
                            updatedAt: new Date(item.updated_at).getTime(),
                            mode: item.mode,
                            backendConversationId: item.conversation_id,
                            projectId: item.project_id ?? null,
                            sttmId: item.sttm_id ?? null,
                            storageScope: existing?.storageScope,
                            pinned: item.pinned ?? false,
                        });
                    }
                    return [...current.filter((item) => !item.backendConversationId), ...byBackendId.values()]
                        .sort((left, right) => right.updatedAt - left.updatedAt);
                });
            }).catch(() => undefined);
        };
        window.addEventListener('aia:refresh-assistant-history', refresh);
        return () => window.removeEventListener('aia:refresh-assistant-history', refresh);
    }, []);

    useEffect(() => {
        if (!hydrated) return;
        try {
            window.localStorage.setItem(AI_CHAT_RAIL_TOP_STORAGE_KEY, String(railTop));
        } catch {
            // Ignore storage errors.
        }
    }, [railTop, hydrated]);

    useEffect(() => {
        if (!hydrated || isMobile || isTablet) return;
        try {
            window.localStorage.setItem(AI_CHAT_SIDEBAR_WIDTH_STORAGE_KEY, String(sidebarWidth));
        } catch {
            // Ignore storage errors.
        }
    }, [sidebarWidth, hydrated, isMobile, isTablet]);

    const upsertCurrentSession = useCallback(() => {
        if (!hasUserMessages(chatMessages)) return;

        const sessionId = activeSessionId ?? createChatSessionId();
        const nextSession: StoredChatSession = {
            id: sessionId,
            title: deriveSessionTitle(chatMessages),
            messages: chatMessages.map((message) => ({ ...message })),
            updatedAt: Date.now(),
            mode: 'quick',
            backendConversationId: [...chatMessages].reverse().find((message) => message.conversationId)?.conversationId ?? null,
            projectId: agentPageProjectId != null ? (agentPageProjectId === 'general' ? null : agentPageProjectId) : activeProjectId,
            sttmId: agentPageProjectId != null ? null : activeSttmId,
            storageScope: chatScope,
        };

        setSessions((previous) => {
            const existing = previous.find((item) => item.id === sessionId);
            if (existing) {
                nextSession.title = existing.title === 'New chat' ? nextSession.title : existing.title;
                nextSession.pinned = existing.pinned;
            }
            const filtered = previous.filter((session) => session.id !== sessionId);
            const next = [nextSession, ...filtered];
            const local = loadStoredChatSessions(chatScope).filter((session) => session.id !== sessionId);
            persistChatSessions(chatScope, [nextSession, ...local]);
            return next;
        });
        setActiveSessionId(sessionId);
    }, [activeSessionId, agentPageProjectId, activeProjectId, activeSttmId, chatMessages, chatScope]);

    useEffect(() => {
        if (!hasUserMessages(chatMessages)) return;
        const timeout = window.setTimeout(() => {
            upsertCurrentSession();
        }, 400);
        return () => window.clearTimeout(timeout);
    }, [chatMessages, upsertCurrentSession]);

    const openChat = useCallback(() => {
        setIsOpen(true);
    }, []);

    const closeChat = useCallback(() => {
        setIsOpen(false);
        setIsFullscreen(false);
        setPanelView('chat');
        setHistorySearch('');
    }, []);

    const toggleFullscreen = useCallback(() => {
        setIsFullscreen((current) => !current);
    }, []);

    const exitFullscreen = useCallback(() => {
        setIsFullscreen(false);
    }, []);

    const handleNewChat = useCallback(() => {
        upsertCurrentSession();
        setActiveSessionId(null);
        resetChatSession();
        setNewChatVersion((current) => current + 1);
        setPanelView('chat');
        setHistorySearch('');
    }, [resetChatSession, upsertCurrentSession]);

    const handleShowHistory = useCallback(() => {
        upsertCurrentSession();
        setPanelView('history');
        // A Deep turn is persisted outside the legacy Quick message store, so
        // refresh on every visit instead of waiting for a workspace remount.
        void fetchAssistantConversationHistory()
            .then((serverSessions) => {
                setSessions((current) => {
                    const byBackendId = new Map(
                        current
                            .filter((item) => item.backendConversationId)
                            .map((item) => [item.backendConversationId as string, item]),
                    );
                    for (const item of serverSessions) {
                        const existing = byBackendId.get(item.conversation_id);
                        byBackendId.set(item.conversation_id, {
                            id: existing?.id ?? item.conversation_id,
                            title: item.title,
                            messages: existing?.messages ?? [],
                            updatedAt: new Date(item.updated_at).getTime(),
                            mode: item.mode,
                            backendConversationId: item.conversation_id,
                            projectId: item.project_id ?? existing?.projectId ?? null,
                            sttmId: item.sttm_id ?? existing?.sttmId ?? null,
                            pinned: item.pinned ?? existing?.pinned ?? false,
                        });
                    }
                    const localOnly = current.filter((item) => !item.backendConversationId);
                    return [...localOnly, ...byBackendId.values()]
                        .sort((left, right) => right.updatedAt - left.updatedAt);
                });
            })
            .catch(() => {
                // Keep the last durable/local snapshot if history is offline.
            });
    }, [upsertCurrentSession]);

    const handleShowNotifications = useCallback(() => {
        setPanelView('notifications');
    }, []);

    const handleSelectRecommendation = useCallback((recommendationId: string) => {
        setSelectedRecommendationId(recommendationId);
        setPanelView('chat');
        setIsOpen(true);
    }, []);

    const markRecommendationResolved = useCallback((recommendationId: string) => {
        setResolvedRecommendationIds((current) => {
            const next = new Set(current);
            next.add(recommendationId);
            return next;
        });
        setSelectedRecommendationId((current) =>
            current === recommendationId ? null : current,
        );
    }, []);

    const handleSelectSession = useCallback(
        (session: StoredChatSession) => {
            setActiveSessionId(session.id);
            if (session.mode === 'deep' && session.backendConversationId) {
                setPanelView('chat');
                window.dispatchEvent(new CustomEvent('aia:restore-assistant-conversation', {
                    detail: { conversationId: session.backendConversationId, mode: session.mode },
                }));
                return;
            }
            window.dispatchEvent(new CustomEvent('aia:select-assistant-mode', {
                detail: { mode: 'quick' },
            }));
            if (session.mode === 'quick' && session.backendConversationId && session.messages.length === 0) {
                void fetchAssistantConversation(session.backendConversationId).then((detail) => {
                    restoreChatSession({
                        messages: detail.turns
                            .filter((turn) => turn.role === 'user' || turn.role === 'assistant')
                            .map((turn) => ({
                                id: turn.turn_id,
                                role: turn.role as 'user' | 'assistant',
                                content: turn.message,
                                conversationId: session.backendConversationId,
                            })),
                        conversationId: session.backendConversationId,
                    });
                });
                setPanelView('chat');
                return;
            }
            restoreChatSession({
                messages: session.messages,
                conversationId: session.backendConversationId ?? null,
            });
            setPanelView('chat');
        },
        [restoreChatSession],
    );

    const handleDeleteSession = useCallback(async (session: StoredChatSession) => {
        if (session.backendConversationId) {
            await deleteAssistantConversation(session.backendConversationId);
        }
        setSessions((previous) => {
            const next = previous.filter((item) => item.id !== session.id);
            if (session.storageScope) {
                persistChatSessions(session.storageScope, loadStoredChatSessions(session.storageScope).filter((item) => item.id !== session.id));
            }
            return next;
        });
        if (activeSessionId === session.id) {
            resetChatSession();
            setActiveSessionId(null);
            setNewChatVersion((value) => value + 1);
        }
    }, [activeSessionId, resetChatSession]);

    const handleUpdateSession = useCallback(async (session: StoredChatSession, changes: { title?: string; projectId?: string | null; pinned?: boolean }) => {
        const updated = session.backendConversationId
            ? await updateAssistantConversation(session.backendConversationId, {
                ...(changes.title !== undefined ? { title: changes.title } : {}),
                ...(changes.projectId !== undefined ? { project_id: changes.projectId } : {}),
                ...(changes.pinned !== undefined ? { pinned: changes.pinned } : {}),
            })
            : null;
        const patch = {
            title: updated?.title ?? changes.title ?? session.title,
            projectId: updated ? updated.project_id ?? null : changes.projectId !== undefined ? changes.projectId : session.projectId,
            sttmId: updated ? updated.sttm_id ?? null : changes.projectId !== undefined ? null : session.sttmId,
            pinned: updated?.pinned ?? changes.pinned ?? session.pinned ?? false,
        };
        setSessions((current) => current.map((item) => item.id === session.id ? { ...item, ...patch } : item));
        if (session.storageScope) {
            persistChatSessions(session.storageScope, loadStoredChatSessions(session.storageScope).map((item) => item.id === session.id ? { ...item, ...patch } : item));
        }
    }, []);

    const beginRailDrag = useCallback(
        (event: React.MouseEvent<HTMLDivElement>) => {
            event.preventDefault();
            event.stopPropagation();
            isDraggingRailRef.current = false;

            const startY = event.clientY;
            const startTop = railTop;

            const onMove = (moveEvent: MouseEvent) => {
                const deltaY = moveEvent.clientY - startY;
                if (Math.abs(deltaY) > 4) {
                    isDraggingRailRef.current = true;
                }
                setRailTop(clampRailTop(startTop + deltaY, layoutHeight));
            };

            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                window.setTimeout(() => {
                    isDraggingRailRef.current = false;
                }, 0);
            };

            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        },
        [layoutHeight, railTop],
    );

    const beginRailTouchDrag = useCallback(
        (event: React.TouchEvent<HTMLDivElement>) => {
            event.stopPropagation();
            isDraggingRailRef.current = false;

            const startY = event.touches[0]?.clientY ?? 0;
            const startTop = railTop;

            const onMove = (moveEvent: TouchEvent) => {
                const clientY = moveEvent.touches[0]?.clientY;
                if (clientY == null) return;
                const deltaY = clientY - startY;
                if (Math.abs(deltaY) > 4) {
                    isDraggingRailRef.current = true;
                }
                setRailTop(clampRailTop(startTop + deltaY, layoutHeight));
            };

            const onEnd = () => {
                document.removeEventListener('touchmove', onMove);
                document.removeEventListener('touchend', onEnd);
                window.setTimeout(() => {
                    isDraggingRailRef.current = false;
                }, 0);
            };

            document.addEventListener('touchmove', onMove, { passive: false });
            document.addEventListener('touchend', onEnd);
        },
        [layoutHeight, railTop],
    );

    const beginSidebarResize = useCallback(
        (event: React.MouseEvent<HTMLDivElement>) => {
            if (isMobile || isTablet) return;
            event.preventDefault();
            setIsResizing(true);
            const startX = event.clientX;
            const startWidth = sidebarWidth;

            const onMove = (moveEvent: MouseEvent) => {
                const nextWidth = Math.min(
                    Math.min(AI_CHAT_MAX_SIDEBAR_WIDTH, layoutWidth - 16),
                    Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, startWidth + (startX - moveEvent.clientX)),
                );
                setSidebarWidth(nextWidth);
            };

            const onUp = () => {
                setIsResizing(false);
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            };

            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        },
        [isMobile, isTablet, layoutWidth, sidebarWidth],
    );

    const value = useMemo(
        () => ({
            isOpen,
            isFullscreen,
            panelView,
            historySearch,
            sessions,
            activeSessionId,
            selectedRecommendationId,
            resolvedRecommendationIds,
            recentSessions: sessions.slice(0, 3),
            railTop,
            effectiveSidebarWidth,
            isResizing,
            isMobile,
            isTablet,
            layoutHeight,
            newChatVersion,
            agentPageProjectId,
            setLayoutMetrics,
            setHistorySearch,
            setPanelView,
            setAgentPageProjectId,
            openChat,
            closeChat,
            toggleFullscreen,
            exitFullscreen,
            handleNewChat,
            handleShowHistory,
            handleShowNotifications,
            handleSelectRecommendation,
            markRecommendationResolved,
            handleSelectSession,
            handleDeleteSession,
            handleUpdateSession,
            beginRailDrag,
            beginRailTouchDrag,
            beginSidebarResize,
        }),
        [
            isOpen,
            isFullscreen,
            panelView,
            historySearch,
            sessions,
            activeSessionId,
            selectedRecommendationId,
            resolvedRecommendationIds,
            railTop,
            effectiveSidebarWidth,
            isResizing,
            isMobile,
            isTablet,
            layoutHeight,
            newChatVersion,
            agentPageProjectId,
            setLayoutMetrics,
            setAgentPageProjectId,
            openChat,
            closeChat,
            toggleFullscreen,
            exitFullscreen,
            handleNewChat,
            handleShowHistory,
            handleShowNotifications,
            handleSelectRecommendation,
            markRecommendationResolved,
            handleSelectSession,
            handleDeleteSession,
            handleUpdateSession,
            beginRailDrag,
            beginRailTouchDrag,
            beginSidebarResize,
        ],
    );

    return <AiChatLayoutContext.Provider value={value}>{children}</AiChatLayoutContext.Provider>;
}

export function useAiChatLayout() {
    const context = useContext(AiChatLayoutContext);
    if (!context) {
        throw new Error('useAiChatLayout must be used within AiChatLayoutProvider');
    }
    return context;
}
