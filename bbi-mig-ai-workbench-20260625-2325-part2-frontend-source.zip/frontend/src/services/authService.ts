import { getApiData } from '@/api/axiosInstance';
import { API_ROUTES } from '@/api/routes';
import type { PermissionSet, UserSession } from '@/types/user';
import {
  mockPermissions,
  mockSnowflakeContext,
  mockUserRoles,
  mockUserSession,
} from './mock/authMockData';
import { mockDelay, throwMockError, useMockDb } from './mock/mockConfig';
import { AppError } from '@/api/errors/app-error';

export type SnowflakeContext = {
  current_user: string;
  current_role?: string | null;
  current_warehouse?: string | null;
  current_database?: string | null;
  current_schema?: string | null;
};

export type UserRolesResponse = {
  app_roles: string[];
  active_app_role?: string | null;
  data_roles: string[];
};

function isExpiredSessionError(error: unknown): boolean {
  if (error instanceof AppError) {
    const status = error.payload.statusCode;
    return status === 401 || status === 403;
  }
  return false;
}

function shouldRedirectToLogin(): boolean {
  if (typeof window === 'undefined') {
    return false;
  }
  const path = window.location.pathname;
  return path !== '/home' && path !== '/landing';
}

export const authService = {
  startLogin: (nextPath: string = '/home'): void => {
    const encodedNext = encodeURIComponent(nextPath);
    window.location.assign(`/api${API_ROUTES.auth.login}?next=${encodedNext}`);
  },

  logout: (): void => {
    window.location.assign(`/api${API_ROUTES.auth.logout}`);
  },

  getSession: async (): Promise<UserSession> => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(mockUserSession);
    }
    try {
      return await getApiData<UserSession>(API_ROUTES.auth.session, { skipGlobalError: true });
    } catch (error) {
      if (isExpiredSessionError(error) && shouldRedirectToLogin()) {
        const nextPath = `${window.location.pathname}${window.location.search}${window.location.hash}`;
        authService.startLogin(nextPath || '/dashboard');
      }
      throw error;
    }
  },

  getPermissions: async (): Promise<PermissionSet> => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(mockPermissions);
    }
    return getApiData<PermissionSet>(API_ROUTES.auth.permissions);
  },

  getSnowflakeContext: async (): Promise<SnowflakeContext> => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(mockSnowflakeContext);
    }
    return getApiData<SnowflakeContext>(API_ROUTES.auth.snowflakeContext);
  },

  getUserRoles: async (): Promise<UserRolesResponse> => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(mockUserRoles);
    }
    return getApiData<UserRolesResponse>(API_ROUTES.user.roles);
  },
};
