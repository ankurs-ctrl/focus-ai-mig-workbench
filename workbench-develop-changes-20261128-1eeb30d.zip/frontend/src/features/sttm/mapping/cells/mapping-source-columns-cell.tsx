'use client';

import { businessReviewText } from '../mapping-review-model';
import { useState } from 'react';
import type { SxProps, Theme } from '@mui/material/styles';

import {
  AiaBox,
  AiaButton,
  AiaIconButton,
  AiaSelect,
  AiaTableCellPrimitive,
  AiaTooltip,
} from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import type { AiaAutocompleteOption } from '@/components/ui/aia-auto-complete';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { AutoFixHighRoundedIcon, ViewColumnOutlinedIcon } from '@/utils/icons';
import {
  MAPPING_PREPROCESS_RULE_ICON_BUTTON_SX,
  MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
  MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT,
  MAPPING_TABLE_BODY_TEXT_SX,
  MAPPING_TABLE_SECONDARY_INPUT_SX,
  MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
} from '../mapping-table-styles';

export type SourceMappingType =
  | 'direct'
  | 'attribute'
  | 'custom'
  | 'upper'
  | 'lower'
  | 'trim';

export const CREATE_FIRM_VALUE_OPTION_VALUE = '+create-attribute';

const DIRECT_LIKE_FUNCTION_LABELS: Partial<Record<SourceMappingType, string>> = {
  upper: 'UPPER',
  lower: 'LOWER',
  trim: 'TRIM',
};

function formatDirectLikeSourceDisplay(
  mappingType: SourceMappingType,
  columnName: string,
): string {
  if (!columnName) {
    return '';
  }
  const fn = DIRECT_LIKE_FUNCTION_LABELS[mappingType];
  return fn ? `${fn}(${columnName})` : columnName;
}

type MappingSourceColumnsCellProps = {
  children?: React.ReactNode;
  displayText?: (text: string) => string;
  mappingType: SourceMappingType;
  value: string | null;
  sourceColumns?: string[] | null;
  /**
   * SQL from a saved library rule. Shown on this Custom row only.
   * Typed custom SQL and other transform rules keep their current source-column text.
   */
  librarySql?: string | null;
  /** Firm values used in the custom rule; counted after the source columns. */
  firmValueNames?: string[];
  options: AiaAutocompleteOption[];
  onChange: (value: string) => void;
  attributeName?: string | null;
  attributeOptions?: Array<{ label: string; value: string; hint?: string }>;
  onAttributeChange?: (value: string) => void;
  onCreateAttribute?: () => void;
  onEditAttribute?: (attributeName: string) => void;
  onAttributeMenuOpen?: () => void;
  isLoadingAttributeOptions?: boolean;
  onPreProcess?: () => void;
  onDirectSourcePick?: () => void;
  scopeWarning?: string | null;
  disabled?: boolean;
  width?: number | string;
  minWidth?: number | string;
  confidenceReason?: string | null;
  businessMeaning?: string | null;
  candidateSourceColumns?: string[];
  firCandidates?: FIRMappingCandidate[];
  onApplyFirCandidate?: (candidate: FIRMappingCandidate) => void;
  onPrepareSource?: (candidate: FIRMappingCandidate) => void;
  onKeepUnresolved?: () => void;
  onUndoRecommendation?: () => void;
  recommendationUndoAvailable?: boolean;
  recommendationActionError?: string | null;
  sx?: SxProps<Theme>;
};

export type FIRMappingCandidate = {
  recommendationId: string;
  sourceColumn?: string | null;
  title: string;
  businessRationale?: string | null;
  evidenceSummary?: string | null;
  confidence?: number | null;
  compatibilityTier?: number | null;
  missingDependencies: string[];
  canApply: boolean;
  blockedReasons: string[];
  actionKind?: string | null;
  expectedWorkspaceHash?: string | null;
};

const DISABLED_SOURCE_FIELD_BG = '#f8fafc';

const SOURCE_FIELD_ROOT_SX = {
  ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
  height: MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT,
  minHeight: MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT,
  borderRadius: '6px',
};

function compactCandidateLabels(candidates: string[]): Map<string, string> {
  const leafCounts = new Map<string, number>();
  candidates.forEach((candidate) => {
    const leaf = candidate.split('.').filter(Boolean).at(-1) ?? candidate;
    leafCounts.set(leaf.toUpperCase(), (leafCounts.get(leaf.toUpperCase()) ?? 0) + 1);
  });
  return new Map(candidates.map((candidate) => {
    const parts = candidate.split('.').filter(Boolean);
    const column = parts.at(-1) ?? candidate;
    const table = parts.at(-2);
    const label = (leafCounts.get(column.toUpperCase()) ?? 0) > 1 && table
      ? `${table}.${column}`
      : column;
    return [candidate, label];
  }));
}

function columnLeafName(ref: string): string {
  return ref.split('.').filter(Boolean).at(-1) ?? ref;
}

function resolveCustomSourceColumns(
  value: string | null | undefined,
  sourceColumns?: string[] | null,
): string[] {
  if (sourceColumns?.length) {
    return sourceColumns.map((column) => column.trim()).filter(Boolean);
  }
  if (!value?.trim()) return [];
  return value
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

/** Source / CTE column leaf names, then firm value names. */
function customSourceNames(
  value: string | null | undefined,
  sourceColumns?: string[] | null,
  firmValueNames: string[] = [],
): string[] {
  return [...resolveCustomSourceColumns(value, sourceColumns).map(columnLeafName), ...firmValueNames];
}

/** One item → its name; multiple → first name + others count (columns and firm values). */
export function formatCustomSourceColumnsParts(
  value: string | null | undefined,
  sourceColumns?: string[] | null,
  firmValueNames: string[] = [],
): { firstName: string; othersCount: number } | null {
  const names = customSourceNames(value, sourceColumns, firmValueNames);
  if (!names.length) return null;
  return {
    firstName: names[0],
    othersCount: Math.max(0, names.length - 1),
  };
}

/** One item → its name; multiple → "First +n others". */
export function formatCustomSourceColumnsLabel(
  value: string | null | undefined,
  sourceColumns?: string[] | null,
  firmValueNames: string[] = [],
): string {
  const parts = formatCustomSourceColumnsParts(value, sourceColumns, firmValueNames);
  if (!parts) return '';
  if (parts.othersCount === 0) return parts.firstName;
  return `${parts.firstName} +${parts.othersCount} others`;
}

export const MappingSourceColumnsCell = ({
  mappingType,
  children,
  displayText,
  value,
  sourceColumns,
  librarySql,
  firmValueNames = [],
  options,
  onChange,
  attributeName,
  attributeOptions = [],
  onAttributeChange,
  onCreateAttribute,
  onEditAttribute,
  onAttributeMenuOpen,
  isLoadingAttributeOptions = false,
  onPreProcess,
  onDirectSourcePick,
  scopeWarning,
  disabled = false,
  width,
  minWidth,
  confidenceReason,
  businessMeaning,
  candidateSourceColumns = [],
  firCandidates = [],
  onApplyFirCandidate,
  onPrepareSource,
  onKeepUnresolved,
  onUndoRecommendation,
  recommendationUndoAvailable = false,
  recommendationActionError,
  sx,
}: MappingSourceColumnsCellProps) => {
  const [candidatesExpanded, setCandidatesExpanded] = useState(false);
  const visibleCandidates = Array.from(new Set(candidateSourceColumns))
    .filter((candidate) => candidate && candidate !== value)
    .slice(0, 3);
  const candidateLabels = compactCandidateLabels(visibleCandidates);
  const visibleFirCandidates = firCandidates.slice(0, 3);
  const friendlySources = displayText ? [...resolveCustomSourceColumns(value, sourceColumns).map(displayText), ...firmValueNames] : [];
  const customSourceParts = friendlySources.length ? {firstName:friendlySources[0],othersCount:friendlySources.length-1} : formatCustomSourceColumnsParts(value, sourceColumns, firmValueNames);
  const plainTextValue = formatCustomSourceColumnsLabel(value, sourceColumns, firmValueNames);
  const customSourceTooltip = (friendlySources.length ? friendlySources : customSourceNames(value, sourceColumns, firmValueNames)).join(', ');
  const librarySqlText = librarySql?.trim() ?? '';
  const showLibrarySql = Boolean(librarySqlText);
  const showCustomPlaceholder = !customSourceParts && !showLibrarySql;
  const directColumnName = value?.trim() ? columnLeafName(value.trim()) : '';
  const directDisplayValue = displayText && value ? displayText(value) : formatDirectLikeSourceDisplay(mappingType, directColumnName);
  const showDirectPlaceholder = !directColumnName;

  if (mappingType === 'custom') {
    return (
      <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx }, { overflow: 'visible' })}>
        <AiaBox
          sx={{
            display: 'flex',
            alignItems: showCustomPlaceholder ? 'flex-start' : 'center',
            gap: 0.75,
            height: showCustomPlaceholder ? 'auto' : MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
            minHeight: MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
            width: '100%',
            minWidth: 0,
          }}
        >
          <AiaTooltip
            title={showLibrarySql ? librarySqlText : customSourceTooltip || 'Use Pre-process to add source columns...'}
            arrow
            placement="top"
            disableHoverListener={!showLibrarySql && !plainTextValue}
          >
            <AiaText
              component="div"
              sx={{
                flex: 1,
                minWidth: 0,
                ...MAPPING_TABLE_BODY_TEXT_SX,
                ...(showLibrarySql || (displayText && value) ? {fontFamily:'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'} : {}),
                color: showLibrarySql || plainTextValue ? undefined : '#94a3b8',
                lineHeight: 1.45,
                textAlign: 'left',
                ...(showCustomPlaceholder
                  ? {
                      whiteSpace: 'normal',
                      overflowWrap: 'anywhere',
                      wordBreak: 'break-word',
                    }
                  : {
                      maxHeight: '100%',
                      overflow: 'hidden',
                      whiteSpace: 'nowrap',
                      textOverflow: 'ellipsis',
                    }),
              }}
            >
              {showLibrarySql ? (
                librarySqlText
              ) : customSourceParts ? (
                <>
                  {customSourceParts.firstName}
                  {customSourceParts.othersCount > 0 ? (
                    <AiaText
                      component="span"
                      sx={{
                        ml: 0.5,
                        color: '#94a3b8',
                        fontStyle: 'italic',
                        fontSize: 'inherit',
                        fontWeight: 400,
                      }}
                    >
                      {`+${customSourceParts.othersCount} others`}
                    </AiaText>
                  ) : null}
                </>
              ) : (
                'Use Pre-process to add source columns...'
              )}
            </AiaText>
          </AiaTooltip>
          <AiaTooltip title="Pre-process" arrow placement="top">
            <span>
              <AiaIconButton
                data-tour={TOUR_TARGETS.sttmPreprocessButton}
                size="small"
                aria-label="Pre-process"
                onClick={onPreProcess}
                sx={{
                  ...MAPPING_PREPROCESS_RULE_ICON_BUTTON_SX,
                  ...(showCustomPlaceholder ? { mt: '1px' } : null),
                }}
              >
                <AutoFixHighRoundedIcon sx={{ fontSize: 18 }} />
              </AiaIconButton>
            </span>
          </AiaTooltip>
        </AiaBox>
        {children}
      </AiaTableCellPrimitive>
    );
  }

  if (mappingType === 'attribute') {
    return (
      <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx }, { overflow: 'hidden' })}>
        <AiaBox
          sx={{
            display: 'flex',
            alignItems: 'center',
            height: MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
            minHeight: MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
            width: '100%',
          }}
        >
          <AiaSelect
            label=""
            fullWidth
            size="small"
            searchable
            searchPlaceholder="Search firm values"
            noResultsMessage="No matching firm values"
            emptyMessage={
              isLoadingAttributeOptions ? 'Loading firm values...' : 'No firm values found'
            }
            pinnedOptionValue={onCreateAttribute ? CREATE_FIRM_VALUE_OPTION_VALUE : undefined}
            onEditOption={onEditAttribute}
            value={attributeName ?? ''}
            options={
              onCreateAttribute
                ? [
                    ...attributeOptions,
                    { label: 'Create Attribute', value: CREATE_FIRM_VALUE_OPTION_VALUE },
                  ]
                : attributeOptions
            }
            placeholder={
              isLoadingAttributeOptions
                ? 'Loading firm values...'
                : attributeOptions.length === 0
                  ? 'No firm values found'
                  : 'Select firm value...'
            }
            onOpen={onAttributeMenuOpen}
            onChange={(next) => {
              const value = Array.isArray(next) ? next[0] ?? '' : next;
              if (value === CREATE_FIRM_VALUE_OPTION_VALUE) {
                onCreateAttribute?.();
                return;
              }
              onAttributeChange?.(value);
            }}
            sx={{
              ...MAPPING_TABLE_SECONDARY_INPUT_SX,
              '& .MuiOutlinedInput-root': {
                ...SOURCE_FIELD_ROOT_SX,
                bgcolor: attributeOptions.length === 0 ? DISABLED_SOURCE_FIELD_BG : '#fff',
              },
            }}
          />
        </AiaBox>
        {children}
      </AiaTableCellPrimitive>
    );
  }

  return (
    <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx }, { overflow: 'visible' })}>
      <AiaBox sx={{ display: 'grid', gap: 0.5 }}>
        <AiaBox
          sx={{
            display: 'flex',
            alignItems: showDirectPlaceholder ? 'flex-start' : 'center',
            gap: 0.75,
            height: showDirectPlaceholder ? 'auto' : MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
            minHeight: MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
            width: '100%',
            minWidth: 0,
          }}
        >
          <AiaText
            component="div"
            sx={{
              flex: 1,
              minWidth: 0,
              ...MAPPING_TABLE_BODY_TEXT_SX,
              ...(displayText && value ? {fontFamily:'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'} : {}),
              color: directDisplayValue ? undefined : '#94a3b8',
              lineHeight: 1.45,
              textAlign: 'left',
              ...(showDirectPlaceholder
                ? {
                    whiteSpace: 'normal',
                    overflowWrap: 'anywhere',
                    wordBreak: 'break-word',
                  }
                : {
                    maxHeight: '100%',
                    overflow: 'hidden',
                    whiteSpace: 'normal',
                    overflowWrap: 'anywhere',
                    textOverflow: 'ellipsis',
                  }),
            }}
          >
            {directDisplayValue || 'Use Direct pick to add source column...'}
          </AiaText>
          <AiaTooltip title="Direct source pick" arrow placement="top">
            <span>
              <AiaIconButton
                size="small"
                aria-label="Direct source pick"
                disabled={disabled}
                onClick={onDirectSourcePick}
                sx={{
                  ...MAPPING_PREPROCESS_RULE_ICON_BUTTON_SX,
                  ...(showDirectPlaceholder ? { mt: '1px' } : null),
                }}
              >
                <ViewColumnOutlinedIcon sx={{ fontSize: 18 }} />
              </AiaIconButton>
            </span>
          </AiaTooltip>
        </AiaBox>
        {scopeWarning ? <AiaTooltip title={scopeWarning} arrow>
          <AiaText role="status" sx={{fontSize:'0.72rem', overflowWrap:'anywhere'}}>Outside selected sources</AiaText>
        </AiaTooltip> : null}
        {(visibleFirCandidates.length || visibleCandidates.length) ? (
          <AiaBox sx={{ display: 'grid', gap: 0.5 }}>
            <AiaButton
              size="small"
              variant="text"
              aria-expanded={candidatesExpanded}
              onClick={() => setCandidatesExpanded((expanded) => !expanded)}
              sx={{
                justifySelf: 'start',
                minHeight: 24,
                p: 0,
                textTransform: 'none',
                fontSize: '0.7rem',
                fontWeight: 700,
              }}
            >
              {candidatesExpanded
                ? 'Hide candidates'
                : `View candidates (${visibleFirCandidates.length || visibleCandidates.length})`}
            </AiaButton>
            {candidatesExpanded ? (
              <AiaBox
                role="list"
                aria-label="Recommended source columns"
                sx={{ display: 'grid', gap: 0.55 }}
              >
                {visibleFirCandidates.length ? visibleFirCandidates.map((candidate) => (
                  <AiaBox
                    key={candidate.recommendationId}
                    role="listitem"
                    sx={{
                      display: 'grid',
                      gap: 0.65,
                      p: 0.75,
                      border: '1px solid #e2e8f0',
                      borderRadius: '6px',
                      bgcolor: '#f8fafc',
                    }}
                  >
                    <AiaBox sx={{ minWidth: 0 }}>
                      <AiaTooltip title={candidate.sourceColumn || candidate.title} placement="top" arrow>
                        <AiaText sx={{ fontSize: '0.72rem', fontWeight: 800, overflowWrap: 'anywhere' }}>
                          {candidate.sourceColumn
                            ? compactCandidateLabels([candidate.sourceColumn]).get(candidate.sourceColumn)
                            : candidate.title}
                        </AiaText>
                      </AiaTooltip>
                      <AiaText sx={{ mt: 0.2, fontSize: '0.66rem', color: '#475569', lineHeight: 1.4 }}>
                        {businessReviewText(candidate.businessRationale) || businessReviewText(candidate.evidenceSummary) || businessReviewText(candidate.title)}
                      </AiaText>
                    </AiaBox>
                    <AiaBox sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                      {candidate.sourceColumn && candidate.canApply ? (
                        <AiaButton
                          size="small"
                          variant="outlined"
                          disabled={disabled}
                          onClick={() => onApplyFirCandidate?.(candidate)}
                          sx={{ minHeight: 26, px: 0.9, textTransform: 'none', fontSize: '0.68rem' }}
                        >
                          Apply
                        </AiaButton>
                      ) : (
                        <AiaButton
                          size="small"
                          variant="outlined"
                          onClick={() => onPrepareSource?.(candidate)}
                          sx={{ minHeight: 26, px: 0.9, textTransform: 'none', fontSize: '0.68rem' }}
                        >
                          Prepare Source
                        </AiaButton>
                      )}
                      <AiaButton
                        size="small"
                        variant="text"
                        onClick={() => {
                          onKeepUnresolved?.();
                          setCandidatesExpanded(false);
                        }}
                        sx={{ minHeight: 26, px: 0.9, textTransform: 'none', fontSize: '0.68rem' }}
                      >
                        Keep current mapping
                      </AiaButton>
                    </AiaBox>
                  </AiaBox>
                )) : visibleCandidates.map((candidate, index) => (
                  <AiaBox
                    key={candidate}
                    role="listitem"
                    sx={{
                      display: 'grid',
                      gridTemplateColumns: 'minmax(0, 1fr) auto',
                      gap: 0.75,
                      alignItems: 'center',
                      p: 0.75,
                      border: '1px solid #e2e8f0',
                      borderRadius: '6px',
                      bgcolor: '#f8fafc',
                    }}
                  >
                    <AiaTooltip title={candidate} placement="top" arrow>
                      <AiaBox sx={{ minWidth: 0 }}>
                        <AiaText sx={{ fontSize: '0.72rem', fontWeight: 800, overflowWrap: 'anywhere' }}>
                          {candidateLabels.get(candidate)}
                        </AiaText>
                        <AiaText sx={{ mt: 0.15, fontSize: '0.66rem', color: '#64748b', lineHeight: 1.35 }}>
                          {index === 0
                            ? businessReviewText(confidenceReason) || businessReviewText(businessMeaning) || 'Source candidate.'
                            : 'Alternative compatible source candidate.'}
                        </AiaText>
                      </AiaBox>
                    </AiaTooltip>
                    <AiaButton
                      size="small"
                      variant="outlined"
                      disabled={disabled}
                      onClick={() => onChange(candidate)}
                      sx={{ minHeight: 26, px: 0.9, textTransform: 'none', fontSize: '0.68rem' }}
                    >
                      Apply
                    </AiaButton>
                  </AiaBox>
                ))}
                {recommendationUndoAvailable ? (
                  <AiaButton
                    size="small"
                    variant="text"
                    onClick={onUndoRecommendation}
                    sx={{ justifySelf: 'start', minHeight: 26, px: 0, textTransform: 'none', fontSize: '0.68rem' }}
                  >
                    Undo recommendation
                  </AiaButton>
                ) : null}
                {recommendationActionError ? (
                  <AiaText role="alert" sx={{ fontSize: '0.66rem', color: '#b91c1c', lineHeight: 1.4 }}>
                    {recommendationActionError}
                  </AiaText>
                ) : null}
              </AiaBox>
            ) : null}
          </AiaBox>
        ) : null}
      </AiaBox>
      {children}
    </AiaTableCellPrimitive>
  );
};
