import type { ColumnGroup, DerivedSource, MappingMode, MappingState } from '@/features/sttm/types/sttm.types';
import type { RelationGraphContext, RelationshipContextItem, SemanticContextItem, TableRef } from '@/types/api-contract';
import type { JoinConfig } from '@/features/sttm/types/sttm.types';
import { relationAliasFor } from '@/features/sttm/mapping/relation-alias';
import { isValuePlaceholder, resolveProjectValuePlaceholders } from '@/features/sttm/mapping/project-attribute-utils';
import { sqlIdentifierParts, sqlIdentifierKey } from '@/features/sttm/shared/sql-identifiers';
import type { ProjectAttributeRecord } from '@/services/projectService';

export type SourceColumnOption = {
  label: string;
  value: string;
  dataType: string;
  group: string;
};

export function derivedOutputSqlName(source: DerivedSource, name: string): string {
  const outputs = (source.queryScope?.outputs ?? []) as Array<Record<string, unknown>>;
  const matches = outputs.filter(output => output.name === name);
  const output = matches.length === 1 ? matches[0] : undefined;
  const alias = String(output?.sql ?? '').match(/\bAS\s+("(?:""|[^"])*"|[A-Za-z_][A-Za-z0-9_$]*)\s*$/i)?.[1];
  const direct = output?.direct_column as Record<string, unknown> | undefined;
  return alias ?? (direct?.name === name ? String(direct.name_sql || name) : name);
}

export function derivedColumnReference(source: DerivedSource, name: string): string {
  return `${relationAliasFor(source.id, source.sourceName)}.${derivedOutputSqlName(source, name)}`;
}

/** Resolve only a unique owned CTE identity; never modify literals or nested queries. */
export function canonicalizeCteReferences(raw: string, graph: RelationGraphContext): string {
  const tokenPattern = /'(?:''|[^'])*'|--[^\r\n]*|\/\*[\s\S]*?\*\/|\$\$[\s\S]*?\$\$|(?:"(?:""|[^"])*"|[A-Za-z_][A-Za-z0-9_$]*)(?:\s*\.\s*(?:"(?:""|[^"])*"|[A-Za-z_][A-Za-z0-9_$]*))*/g;
  const tokens = [...raw.matchAll(tokenPattern)];
  if (tokens.some(match => /^(SELECT|WITH)$/i.test(match[0]))) return raw;
  return raw.replace(tokenPattern, token => {
    if (/^(?:'|--|\/\*|\$\$)/.test(token)) return token;
    const parts = sqlIdentifierParts(token);
    if (parts.length !== 2) return token;
    const qualifier = JSON.stringify(parts.slice(0, -1));
    const matches = graph.nodes.filter(node => [node.alias, node.original_cte_name ?? '',
      node.table ? qualifiedTableName(node.table) : ''].some(name => sqlIdentifierKey(name) === qualifier));
    if (matches.length !== 1 || matches[0].kind !== 'DERIVED_SOURCE') return token;
    const node = matches[0];
    const output = parts[1];
    const columns = (node.output_columns ?? []).filter(column => column.sql_name
      ? sqlIdentifierKey(String(column.sql_name)) === JSON.stringify([output])
      : String(column.name ?? column.column_name ?? '') === output);
    if (columns.length !== 1) return token;
    return `${node.alias}.${columns[0].sql_name || (/^[A-Z_][A-Z0-9_$]*$/.test(output) ? output : `"${output.replaceAll('"', '""')}"`)}`;
  });
}

export function canonicalizeMappingBindings(mapping: MappingState, graph: RelationGraphContext): MappingState {
  const bind = (value: string) => canonicalizeCteReferences(value, graph);
  if (mapping.mappingMode === 'constant' || mapping.mappingMode === 'attribute') return mapping;
  return {...mapping, sourceColumn: mapping.sourceColumn ? bind(mapping.sourceColumn) : mapping.sourceColumn,
    sourceColumns: mapping.sourceColumns?.map(bind), sourceDependencies: mapping.sourceDependencies?.map(bind),
    expression: mapping.expression ? bind(mapping.expression) : mapping.expression};
}

export function manualSourceScopeWarning(reference: string, drivingId: string | null,
  derivedSources: DerivedSource[], relationships: JoinConfig[]): string | null {
  if (!derivedSources.some(source => source.id === drivingId)) return null;
  const connected = new Set([drivingId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const join of relationships) {
      if (!join.leftTableId || !join.rightTableId) continue;
      if (connected.has(join.leftTableId) && !connected.has(join.rightTableId)) { connected.add(join.rightTableId); changed = true; }
      if (connected.has(join.rightTableId) && !connected.has(join.leftTableId)) { connected.add(join.leftTableId); changed = true; }
    }
  }
  const parts = sqlIdentifierParts(reference);
  const qualifier = JSON.stringify(parts.slice(0, -1));
  const candidates = derivedSources.filter(source => [relationAliasFor(source.id, source.sourceName),
    String(source.queryScope?.name_sql ?? source.queryScope?.name ?? source.sourceName)]
    .some(alias => sqlIdentifierKey(alias) === qualifier));
  if (candidates.length === 1 && connected.has(candidates[0].id)) return null;
  if (candidates.length > 1) return 'Ambiguous CTE name. Select a uniquely identified CTE output.';
  if ([...connected].some(id => id && sqlIdentifierKey(id) === qualifier)) return null;
  return 'Outside the driving CTE scope: expose this column in the CTE or prepare an explicit connected relation. This row will be omitted from the draft, not from compilation.';
}

export function tableAlias(tableName: string) {
  return tableName.toLowerCase();
}

export function buildCompilerRelationGraph(params: {
  semanticContext?: SemanticContextItem[] | null;
  sourceTables: TableRef[];
  sourceColumnsByTable?: Record<string, Array<{ name?: string | null; type?: string | null }>>;
  derivedSources: DerivedSource[];
  relationships: JoinConfig[];
  mappings: MappingState[];
  queryModifiers?: Record<string, string>;
}): RelationGraphContext {
  const { sourceTables, sourceColumnsByTable = {}, derivedSources, relationships, mappings } = params;
  const selectedDerived = derivedSources.filter((source) => source.isSelected);
  const nodes: RelationGraphContext['nodes'] = [
    ...sourceTables.map((table) => {
      const relationId = table.relation_id ?? qualifiedTableName(table);
      return {
        relation_id: relationId,
        kind: 'PHYSICAL_TABLE' as const,
        alias: relationAliasFor(relationId),
        table,
        grain: semanticGrainForTable(params.semanticContext, table),
        output_columns: (sourceColumnsByTable[qualifiedTableName(table)] ?? []).map((column) => ({
          name: column.name,
          data_type: column.type,
        })),
      };
    }),
    ...selectedDerived.map((source) => ({
      relation_id: source.id,
      kind: 'DERIVED_SOURCE' as const,
      alias: relationAliasFor(source.id, source.sourceName),
      derived_source_id: source.id,
      physical_view_name: source.physicalViewName ?? null,
      sql_text: source.sqlText ?? null,
      original_cte_name: source.id.startsWith('sql-cte:') ? String(source.queryScope?.name_sql ?? source.queryScope?.name ?? source.sourceName) : null,
      output_columns: (source.outputColumns ?? source.previewColumns?.map((column) => ({
        name: column.name,
        data_type: column.dataType,
        is_primary_key: column.isPrimaryKey,
      })) ?? []).map((column: Record<string, unknown>) => {
        const name = String(column.name ?? column.column_name ?? '');
        const ownedOutputs = (source.queryScope?.outputs ?? []) as Array<Record<string, unknown>>;
        const sqlName = ownedOutputs.filter(output => output.name === name).length === 1
          ? derivedOutputSqlName(source, name) : '';
        return {...column, ...(sqlName ? {sql_name: sqlName} : {})};
      }),
      column_semantics: source.columnSemantics ?? [],
      grain: source.grain ?? null,
      keys: source.keys ?? [],
      dependency_hash: source.sourceDependencyHash ?? source.upstreamHash ?? null,
      parent_relation_ids: source.parentDerivedSourceIds ?? source.derivedSourceIds ?? [],
      base_relation_ids: (source.baseSourceTables ?? []).map(qualifiedTableName),
    })),
  ];
  const nodeIds = new Set(nodes.map((node) => node.relation_id));
  const edges = relationships
    .filter((join) => join.leftTableId && join.rightTableId && nodeIds.has(join.leftTableId) && nodeIds.has(join.rightTableId))
    .map((join, index) => ({
      edge_id: join.id ?? `relation-edge-${index + 1}`,
      left_relation_id: String(join.leftTableId),
      right_relation_id: String(join.rightTableId),
      join_type: join.joinType ?? 'INNER',
      provenance: join.source ?? 'USER_DEFINED',
      validation_status: join.locked ? 'validated' : 'selected',
      additional_predicate: join.sqlPredicate ?? null,
      conditions: (join.sqlPredicate ? [] : join.conditions ?? [])
        .filter((condition) => condition.leftColumn && condition.rightColumn)
        .map((condition) => ({
          left_column: String(condition.leftColumn),
          right_column: String(condition.rightColumn),
          operator: condition.operator ?? '=',
        })),
    }))
    .filter((edge) => edge.conditions.length > 0 || edge.additional_predicate);
  const value_bindings = mappings
    .filter(
      (mapping) =>
        (mapping.mappingMode === 'constant' || mapping.mappingMode === 'attribute')
        && mapping.constantValue != null,
    )
    .map((mapping) => {
      const placeholder = String(mapping.constantValue).trim().startsWith('$');
      return {
        binding_id: `value:${mapping.id}`,
        value: String(mapping.constantValue),
        data_type: mapping.targetType || null,
        is_placeholder: placeholder,
        allow_project_specific_value: false,
        resolution_status: placeholder ? 'placeholder_contract' : 'resolved',
      };
    });
  return { nodes, edges, value_bindings, query_modifiers: params.queryModifiers ?? {} };
}

export function semanticGrainForTable(items: SemanticContextItem[] | null | undefined, table: TableRef | null | undefined): string | null {
  if (!table) return null;
  const name = qualifiedTableName(table).toUpperCase();
  const item = items?.find((entry) => qualifiedTableName(entry.table).toUpperCase() === name);
  const model = item?.semantic_model;
  if (!model || typeof model !== 'object' || Array.isArray(model)) return null;
  const grain = (model as Record<string, unknown>).grain;
  return typeof grain === 'string' && grain.trim() ? grain.trim() : null;
}

function qualifiedTableName(table: TableRef) {
  return `${table.database}.${table.schema}.${table.table}`.replace(/\.+/g, '.');
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function formatSqlType(type?: string) {
  if (!type) return 'VARCHAR';
  const upper = type.toUpperCase();
  if (upper.includes('NUMBER') || upper === 'INT') return 'BIGINT';
  if (upper.includes('VARCHAR') || upper.includes('TEXT')) return 'VARCHAR';
  if (upper.includes('DATE') && !upper.includes('TIME')) return 'DATE';
  if (upper.includes('TIMESTAMP')) return 'TIMESTAMP';
  if (upper.includes('DECIMAL') || upper.includes('FLOAT')) return 'DECIMAL';
  return upper;
}

const COLUMN_SAMPLE_VALUES: Record<string, string> = {
  CUSTOMER_ID: '2047',
  CUSTOMER_KEY: '2047',
  CUSTOMER_NAME: 'Acme Corp',
  EMAIL: 'acme@corp.com',
  COUNTRY_CODE: 'US',
  ORDER_ID: '10001',
  ORDER_DATE: '20230115',
  ORDER_DATE_KEY: '20230115',
  ORDER_AMOUNT: '1240.50',
  NET_AMOUNT: '1240.50',
  QUANTITY: '3',
  COMMISSION_RATE: '0.10',
  STATUS: 'shipped',
  REGION_NAME: 'Northeast',
  CREATED_DATE: '20230115',
  ORDER_ITEM_ID: '90001',
  PRODUCT_ID: '301',
  LINE_AMOUNT: '49.98',
  SALES_KEY: '88001',
  PRODUCT_KEY: '401',
  SALE_DATE: '2024-02-01',
  SEGMENT: 'enterprise',
  COUNTRY: 'United States',
};

export function getColumnSampleDisplayValue(columnName?: string, dataType?: string): string {
  const name = String(columnName || '').trim().toUpperCase();
  if (name && COLUMN_SAMPLE_VALUES[name]) {
    return COLUMN_SAMPLE_VALUES[name];
  }

  const formatted = formatSqlType(dataType).toLowerCase();
  if (formatted.includes('date') || formatted.includes('timestamp')) {
    return '2024-01-01';
  }
  if (
    formatted.includes('int') ||
    formatted.includes('number') ||
    formatted.includes('decimal') ||
    formatted.includes('float')
  ) {
    return '0';
  }
  if (name.endsWith('_ID')) {
    return '1001';
  }
  if (name.includes('EMAIL')) {
    return 'user@example.com';
  }
  if (name.includes('NAME')) {
    return 'Sample';
  }
  if (name.includes('STATUS')) {
    return 'active';
  }
  return '—';
}

export type MappingDataPreviewResult = {
  sourceValue: string | null;
  transformedValue: string | null;
  displayValue: string | null;
  ruleLabel: string | null;
  hasTransform: boolean;
};

function applyPreviewTransform(
  value: string,
  rule: string,
  expression?: string | null,
): string {
  const normalizedRule = rule.trim().toUpperCase();

  switch (normalizedRule) {
    case 'UPPER':
      return value.toUpperCase();
    case 'LOWER':
      return value.toLowerCase();
    case 'TRIM':
      return value.trim();
    case 'DATE_FORMAT': {
      const digits = value.replace(/\D/g, '');
      if (digits.length === 8) {
        return `${digits.slice(0, 4)}-${digits.slice(4, 6)}-${digits.slice(6, 8)}`;
      }
      return value;
    }
    case 'CAST':
      return value;
    case 'COALESCE':
      return value || '—';
    case 'SUBSTRING':
      return value.slice(0, Math.min(4, value.length));
    case 'REPLACE':
      return value;
    case 'NULLIF':
      return value === '' ? 'NULL' : value;
    case 'CONCATENATE':
      return value;
    case 'CUSTOM':
      return expression?.trim() ? value : value;
    default:
      return value;
  }
}

export function parseMappingMode(value: unknown): MappingMode {
  const mode = String(value ?? "source").toLowerCase();
  if (mode === "constant") return "constant";
  if (mode === "attribute") return "attribute";
  return "source";
}

export function getMappingSourceColumnLabel(mapping: MappingState): string | null {
  if (mapping.mappingMode === "constant") {
    return mapping.constantValue?.trim() || null;
  }
  if (mapping.mappingMode === "attribute") {
    return mapping.attributeName?.trim() || null;
  }
  const sourceColumns =
    mapping.sourceColumns && mapping.sourceColumns.length
      ? mapping.sourceColumns
      : parseSourceColumns(mapping.sourceColumn);
  return sourceColumns[0] ?? null;
}

function toSafePreviewText(value: unknown, maxLength = 160): string | null {
  if (value == null) {
    return null;
  }

  let text: string | null = null;
  if (typeof value === 'string') {
    text = value;
  } else if (typeof value === 'number' || typeof value === 'boolean' || typeof value === 'bigint') {
    text = String(value);
  }

  if (!text) {
    return null;
  }

  const trimmed = text.trim();
  if (!trimmed) {
    return null;
  }

  return trimmed.length > maxLength ? `${trimmed.slice(0, maxLength)}…` : trimmed;
}

export function buildMappingDataPreview(mapping: MappingState): MappingDataPreviewResult {
  if (mapping.mappingMode === "constant" || mapping.mappingMode === "attribute") {
    const constantValue = toSafePreviewText(mapping.constantValue);
    return {
      sourceValue: constantValue,
      transformedValue: constantValue,
      displayValue: constantValue,
      ruleLabel: mapping.mappingMode === "attribute" ? "ATTRIBUTE" : "VALUE",
      hasTransform: true,
    };
  }
  const sourceColumn = getMappingSourceColumnLabel(mapping);
  if (!sourceColumn) {
    return {
      sourceValue: null,
      transformedValue: null,
      displayValue: null,
      ruleLabel: null,
      hasTransform: false,
    };
  }

  const columnName = sourceColumn.split('.').pop() ?? sourceColumn;
  const sourceValue = toSafePreviewText(
    getColumnSampleDisplayValue(
      columnName,
      mapping.sourceType ?? mapping.targetType ?? undefined,
    ),
  );

  const rule = toSafePreviewText(mapping.rule, 64) ?? 'Direct';
  const isDirect = rule === 'Direct' || rule === 'Select...';

  if (isDirect) {
    return {
      sourceValue,
      transformedValue: null,
      displayValue: sourceValue,
      ruleLabel: null,
      hasTransform: false,
    };
  }

  const transformedValue = toSafePreviewText(
    applyPreviewTransform(sourceValue ?? '', rule, mapping.expression),
  );

  return {
    sourceValue,
    transformedValue,
    displayValue: transformedValue,
    ruleLabel: rule.toUpperCase(),
    hasTransform: true,
  };
}

export function typeChipColor(dataType?: string): 'default' | 'primary' | 'secondary' | 'info' {
  const formatted = formatSqlType(dataType);
  const isNumeric =
    formatted === 'BIGINT' ||
    formatted === 'INT' ||
    formatted === 'DECIMAL' ||
    formatted === 'NUMBER';
  const isDate = formatted === 'DATE' || formatted === 'TIMESTAMP';

  if (isNumeric) return 'secondary';
  if (isDate) return 'info';
  return 'default';
}

export function getDerivedDisplayColumns(source: DerivedSource): Array<{ name: string; type: string }> {
  if (source.previewColumns?.length) {
    return source.previewColumns.map((column) => ({
      name: column.name,
      type: column.dataType || '—',
    }));
  }
  if (source.outputColumns?.length) {
    return source.outputColumns
      .map((column) => ({
        name: String(column.name ?? column.column_name ?? '').trim(),
        type: String(column.data_type ?? column.dataType ?? column.type ?? '—'),
      }))
      .filter((column) => Boolean(column.name));
  }
  return (source.columns ?? [])
    .filter((column) => column.name)
    .map((column) => ({
      name: String(column.name),
      type: column.type ?? '—',
    }));
}

export function buildSourceColumnOptions(
  sourceAttributeGroups: ColumnGroup[],
  derivedSources: DerivedSource[],
  sourceRelations: Array<{tableId: string; qualifiedName: string; isSelected: boolean}> = [],
): SourceColumnOption[] {
  const options: SourceColumnOption[] = [];

  for (const group of sourceAttributeGroups) {
    const instances = sourceRelations.filter(table => table.isSelected && table.tableId.startsWith('sql-instance:')
      && table.qualifiedName === group.qualifiedName);
    const owners = instances.length ? instances.map(table => relationAliasFor(table.tableId)) : [group.qualifiedName];
    for (const owner of owners) for (const column of group.columns) {
      if (!column.name) continue;
      options.push({
        label: `${instances.length ? owner : group.table}.${column.name}`,
        value: `${owner}.${column.name}`,
        dataType: column.type || 'VARCHAR',
        group: instances.length ? owner : group.table,
      });
    }
  }

  for (const source of derivedSources.filter((item) => item.isSelected)) {
    const alias = relationAliasFor(source.id, source.sourceName);
    for (const column of getDerivedDisplayColumns(source)) {
      options.push({
        label: `${alias}.${column.name}`,
        value: derivedColumnReference(source, column.name),
        dataType: column.type,
        group: source.sourceName,
      });
    }
  }

  return options;
}

export function findSourceColumnOption(
  options: SourceColumnOption[],
  value: string | null | undefined,
) {
  if (!value) return null;
  const normalized = value.trim().toLowerCase();
  return (
    options.find((option) => option.value.toLowerCase() === normalized) ??
    options.find((option) => option.label.toLowerCase() === normalized) ??
    null
  );
}

export function generateMappingDescription(params: {
  rule: string;
  sourceColumns: string[];
  targetColumn: string;
  expression?: string | null;
}): string {
  const { rule, sourceColumns, targetColumn, expression } = params;
  const joinedSources = sourceColumns.join(', ');
  const normalizedRule = (rule || '').trim();

  if (!normalizedRule || normalizedRule === 'Select...') {
    return '';
  }

  if (normalizedRule === 'Custom' && expression?.trim()) {
    return sourceColumns.length
      ? `Custom expression maps ${targetColumn} using ${joinedSources}.`
      : `Custom expression mapping for ${targetColumn}.`;
  }

  if (sourceColumns.length === 0) {
    return '';
  }

  if (normalizedRule === 'Direct') {
    return sourceColumns.length === 1
      ? `Direct mapping from ${sourceColumns[0]} to ${targetColumn}.`
      : `Maps ${targetColumn} from ${joinedSources}.`;
  }

  return `Applies ${normalizedRule} on ${joinedSources} for ${targetColumn}.`;
}

export function parseSourceColumns(value: string | null | undefined): string[] {
  if (!value) return [];
  return value
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

function findTopLevelKeyword(sql: string, keyword: string, startIndex = 0): number {
  const upper = sql.toUpperCase();
  const target = keyword.toUpperCase();
  let depth = 0;
  let index = startIndex;
  while (index < sql.length) {
    const character = sql[index];
    if (character === "'" || character === '"') {
      const quote = character;
      index += 1;
      while (index < sql.length) {
        if (sql[index] === quote) {
          if (sql[index + 1] === quote) {
            index += 2;
            continue;
          }
          index += 1;
          break;
        }
        index += 1;
      }
      continue;
    }
    if (character === '-' && sql[index + 1] === '-') {
      const newline = sql.indexOf('\n', index);
      index = newline === -1 ? sql.length : newline + 1;
      continue;
    }
    if (character === '/' && sql[index + 1] === '*') {
      const end = sql.indexOf('*/', index + 2);
      index = end === -1 ? sql.length : end + 2;
      continue;
    }
    if (character === '(') {
      depth += 1;
      index += 1;
      continue;
    }
    if (character === ')') {
      depth -= 1;
      index += 1;
      continue;
    }
    if (depth === 0 && upper.startsWith(target, index)) {
      const before = index === 0 ? '' : sql[index - 1];
      const after = sql[index + target.length] ?? '';
      if (!/[A-Za-z0-9_$]/.test(before) && !/[A-Za-z0-9_$]/.test(after)) {
        return index;
      }
    }
    index += 1;
  }
  return -1;
}

function splitBaseQuerySql(baseSql: string): { withBlock: string; fromTail: string } {
  const trimmed = String(baseSql ?? '').trim().replace(/;+\s*$/, '');
  if (!trimmed) return { withBlock: '', fromTail: '' };

  let withBlock = '';
  let remainder = trimmed;
  if (/^WITH\b/i.test(trimmed)) {
    const selectIndex = findTopLevelKeyword(trimmed, 'SELECT');
    if (selectIndex > 0) {
      withBlock = trimmed.slice(0, selectIndex).trimEnd();
      remainder = trimmed.slice(selectIndex);
    }
  }
  if (!/^SELECT\b/i.test(remainder)) {
    return { withBlock, fromTail: remainder };
  }
  const fromIndex = findTopLevelKeyword(remainder, 'FROM');
  return { withBlock, fromTail: fromIndex === -1 ? '' : remainder.slice(fromIndex) };
}

function resolveLegacyDerivedReferences(sql: string, derivedSources: DerivedSource[]): string {
  let resolved = sql;
  for (const source of derivedSources.filter((item) => item.isSelected !== false)) {
    const sourceSql = source.sqlText?.trim().replace(/;+\s*$/, '');
    const relation = sourceSql
      ? `(\n${sourceSql}\n)`
      : source.physicalViewName?.trim();
    if (!relation) continue;
    const name = source.sourceName.replace(/\s+/g, '_');
    for (const prefix of ['DERIVED.DERIVED', 'CTE.CTE']) {
      const placeholder = new RegExp(`${prefix.replaceAll('.', '\\.')}\\.${escapeRegExp(name)}\\b`, 'gi');
      resolved = resolved.replace(placeholder, () => relation);
    }
  }
  return resolved;
}

function buildSourceAliasLookup(params: {
  sourceTables: TableRef[];
  derivedSources?: DerivedSource[];
}) {
  const { sourceTables, derivedSources = [] } = params;
  const lookup = new Map<string, string>();

  for (const table of sourceTables) {
    const qualified = qualifiedTableName(table);
    const alias = relationAliasFor(table.relation_id ?? qualified);
    if (sourceTables.filter(other => qualifiedTableName(other) === qualified).length === 1) {
      lookup.set(qualified, alias);
      lookup.set(tableAlias(table.table), alias);
    }
  }

  for (const source of derivedSources.filter((item) => item.isSelected !== false)) {
    const alias = relationAliasFor(source.id, source.sourceName);
    const syntheticName = source.sourceName.replace(/\s+/g, '_');
    for (const seed of [
      source.alias,
      source.sourceName,
      source.id,
      source.physicalViewName,
      `DERIVED.DERIVED.${syntheticName}`,
      `CTE.CTE.${syntheticName}`,
    ]) {
      if (!seed) continue;
      lookup.set(tableAlias(String(seed).replace(/\s+/g, '_')), alias);
    }
  }

  return lookup;
}

function normalizeSourceExpression(
  expression: string,
  params: {
    sourceTables: TableRef[];
    derivedSources?: DerivedSource[];
  },
) {
  let normalized = expression;
  const aliasLookup = buildSourceAliasLookup(params);

  const entries = [...aliasLookup.entries()].sort(
    ([left], [right]) => right.length - left.length,
  );
  for (const [alias, resolved] of entries) {
    if (!resolved || resolved === alias) {
      continue;
    }
    const pattern = new RegExp(
      `(^|[^A-Za-z0-9_\\.])(${escapeRegExp(alias)})\\.([A-Za-z_][A-Za-z0-9_$]*)`,
      'gi',
    );
    normalized = normalized.replace(pattern, (_, prefix: string, _alias: string, column: string) =>
      `${prefix}${resolved}.${column}`,
    );
  }

  return normalized;
}

function qualifyBareSourceIdentifiers(expression: string, sourceColumns: string[]) {
  const candidates = new Map<string, Set<string>>();
  for (const sourceColumn of sourceColumns) {
    const normalized = String(sourceColumn || '').trim();
    if (!normalized) continue;
    const columnName = normalized.split('.').pop()?.trim();
    if (!columnName) continue;
    const key = columnName.toUpperCase();
    const values = candidates.get(key) ?? new Set<string>();
    values.add(normalized);
    candidates.set(key, values);
  }

  let output = '';
  let index = 0;
  let quote: "'" | '"' | '`' | null = null;
  while (index < expression.length) {
    const character = expression[index];
    if (quote) {
      output += character;
      if (character === quote) {
        if (quote === "'" && expression[index + 1] === "'") {
          output += expression[index + 1];
          index += 2;
          continue;
        }
        quote = null;
      }
      index += 1;
      continue;
    }
    if (character === "'" || character === '"' || character === '`') {
      quote = character;
      output += character;
      index += 1;
      continue;
    }
    if (/[A-Za-z_]/.test(character)) {
      let end = index + 1;
      while (end < expression.length && /[A-Za-z0-9_$]/.test(expression[end])) {
        end += 1;
      }
      const token = expression.slice(index, end);
      const prior = index > 0 ? expression[index - 1] : '';
      const next = end < expression.length ? expression[end] : '';
      const matches = candidates.get(token.toUpperCase());
      output += prior !== '.' && next !== '.' && matches?.size === 1
        ? [...matches][0]
        : token;
      index = end;
      continue;
    }
    output += character;
    index += 1;
  }
  return output;
}

export function buildFallbackSourceQuerySql(params: {
  sourceQuerySql?: string | null;
  sourceTables: TableRef[];
  derivedSources?: DerivedSource[];
  relationships?: RelationshipContextItem[];
  drivingTable?: TableRef | null;
}) {
  const {
    sourceQuerySql,
    sourceTables,
    derivedSources = [],
    relationships = [],
    drivingTable,
  } = params;

  if (sourceQuerySql?.trim()) {
    return resolveLegacyDerivedReferences(sourceQuerySql, derivedSources);
  }

  const selectedDerivedSources = derivedSources.filter((source) => source.isSelected !== false);
  if (!sourceTables.length && selectedDerivedSources.length === 1) {
    const derivedSql = selectedDerivedSources[0].sqlText?.trim().replace(/;+\s*$/, '');
    if (derivedSql) {
      const alias = relationAliasFor(
        selectedDerivedSources[0].id,
        selectedDerivedSources[0].sourceName,
      );
      return `FROM (\n${derivedSql}\n) AS ${alias}`;
    }
  }

  if (!sourceTables.length) {
    return '';
  }

  const tableByQualifiedName = new Map(
    sourceTables.map((table) => [qualifiedTableName(table).toUpperCase(), table] as const),
  );
  const seedTable =
    (drivingTable ? tableByQualifiedName.get(qualifiedTableName(drivingTable).toUpperCase()) : null) ??
    sourceTables[0];
  if (!seedTable) {
    return '';
  }

  const sourceAlias = (table: TableRef) => relationAliasFor(qualifiedTableName(table));
  const lines = [
    `FROM ${qualifiedTableName(seedTable)} AS ${sourceAlias(seedTable)}`,
  ];
  const visited = new Set<string>([qualifiedTableName(seedTable).toUpperCase()]);
  const pending = relationships.filter(
    (relationship) =>
      relationship.left_table &&
      relationship.right_table &&
      (relationship.sql_predicate || relationship.conditions?.some((condition) => condition.left_column && condition.right_column)),
  );

  let progressed = true;
  while (progressed) {
    progressed = false;
    for (const relationship of pending) {
      const leftName = qualifiedTableName(relationship.left_table).toUpperCase();
      const rightName = qualifiedTableName(relationship.right_table).toUpperCase();
      const leftVisited = visited.has(leftName);
      const rightVisited = visited.has(rightName);

      if (leftVisited === rightVisited) {
        continue;
      }

      const attachingTable = leftVisited ? relationship.right_table : relationship.left_table;
      const attachingName = qualifiedTableName(attachingTable).toUpperCase();
      const selectedJoinType = relationship.join_type?.trim() || 'INNER';
      const joinType = leftVisited ? selectedJoinType
        : selectedJoinType === 'LEFT' ? 'RIGHT' : selectedJoinType === 'RIGHT' ? 'LEFT' : selectedJoinType;
      const validConditions = (relationship.conditions ?? []).filter(
        (condition) => condition.left_column && condition.right_column,
      );
      if (!validConditions.length && !relationship.sql_predicate) {
        continue;
      }

      lines.push(
        `${joinType} JOIN ${qualifiedTableName(attachingTable)} AS ${sourceAlias(attachingTable)}`,
      );
      lines.push(
        `  ON ${relationship.sql_predicate || validConditions
          .map(
            (condition) =>
              `${sourceAlias(relationship.left_table)}.${condition.left_column} ${condition.operator ?? '='} ${sourceAlias(relationship.right_table)}.${condition.right_column}`,
          )
          .join('\n  AND ')}`,
      );
      visited.add(attachingName);
      progressed = true;
    }
  }

  const unjoinedTables = sourceTables.filter(
    (table) => !visited.has(qualifiedTableName(table).toUpperCase()),
  );
  if (unjoinedTables.length) {
    lines.push('-- Additional selected tables are waiting for join conditions:');
    lines.push(
      ...unjoinedTables.map((table) => `-- ${qualifiedTableName(table)}`),
    );
  }

  return lines.join('\n');
}

export function buildSourceQueryPreviewSql(params: {
  sourceQuerySql: string;
  sourceFilterSql?: string;
  sourceGroupBySql?: string;
  sourceOrderBySql?: string;
}) {
  const { sourceQuerySql, sourceFilterSql, sourceGroupBySql, sourceOrderBySql } = params;
  const { withBlock, fromTail } = splitBaseQuerySql(sourceQuerySql);
  if (!fromTail) {
    return '-- Select source tables and relationships in Step 1 to generate SQL.';
  }

  const lines = withBlock
    ? [withBlock, 'SELECT', '  *', fromTail]
    : ['SELECT', '  *', fromTail];

  if (sourceFilterSql?.trim()) {
    lines.push(`WHERE\n${sourceFilterSql.trim()}`);
  }
  if (sourceGroupBySql?.trim()) {
    lines.push(`GROUP BY\n  ${sourceGroupBySql.trim()}`);
  }
  if (sourceOrderBySql?.trim()) {
    lines.push(`ORDER BY\n  ${sourceOrderBySql.trim()}`);
  }

  return lines.join('\n');
}

export function buildMappingExpression(mapping: MappingState) {
  return buildResolvedMappingExpression(mapping, { sourceTables: [], derivedSources: [] });
}

export function buildResolvedMappingExpression(
  mapping: MappingState,
  params: {
    sourceTables: TableRef[];
    derivedSources?: DerivedSource[];
  },
) {
  if (mapping.mappingMode === "constant" || mapping.mappingMode === "attribute") {
    return buildSnowflakeConstantExpression(mapping.constantValue, mapping.targetType);
  }
  const sourceColumns =
    mapping.sourceColumns && mapping.sourceColumns.length
      ? mapping.sourceColumns
      : parseSourceColumns(mapping.sourceColumn);

  if (mapping.expression?.trim()) {
    const normalizedHints = sourceColumns.map((item) =>
      normalizeSourceExpression(item, params),
    );
    return qualifyBareSourceIdentifiers(
      normalizeSourceExpression(mapping.expression.trim(), params),
      normalizedHints,
    );
  }
  if (!sourceColumns.length) {
    return 'NULL';
  }

  const normalizedSourceColumns = sourceColumns.map((item) =>
    normalizeSourceExpression(item, params),
  );

  const rule = (mapping.rule || 'Direct').trim().toUpperCase();
  if (rule === 'DIRECT' || rule === 'SELECT...') {
    return normalizedSourceColumns[0];
  }
  if (rule === 'CONCATENATE') {
    return `CONCAT(${normalizedSourceColumns.join(', ')})`;
  }
  if (sourceColumns.length === 1 && ['UPPER', 'LOWER', 'TRIM'].includes(rule)) {
    return `${rule}(${normalizedSourceColumns[0]})`;
  }
  if (sourceColumns.length === 1 && rule === 'NULLIF') {
    return `NULLIF(${normalizedSourceColumns[0]}, '')`;
  }
  return normalizedSourceColumns[0];
}

function buildSnowflakeConstantExpression(
  value: string | null | undefined,
  targetType: string | null | undefined,
) {
  const raw = String(value ?? "");
  const trimmed = raw.trim();
  const blankTypedValue = !trimmed && /^(NUMBER|DECIMAL|NUMERIC|INT|INTEGER|BIGINT|FLOAT|DOUBLE|BOOLEAN|BOOL|DATE|TIME)/i.test(String(targetType ?? ''));
  if (value == null || blankTypedValue || trimmed.toUpperCase() === "NULL") {
    return "NULL";
  }
  // A firm-value placeholder stays SQL code so it resolves to the project's
  // value; quoting it would load the literal text "$Name".
  if (isValuePlaceholder(trimmed)) {
    return trimmed;
  }

  const normalizedType = String(targetType ?? "").trim().toUpperCase();
  if (
    /^(NUMBER|DECIMAL|NUMERIC|INT|INTEGER|BIGINT|SMALLINT|FLOAT|DOUBLE|REAL)/.test(
      normalizedType,
    )
    && /^[-+]?(?:\d+\.?\d*|\.\d+)$/.test(trimmed)
  ) {
    return trimmed;
  }
  if (
    /^(BOOLEAN|BOOL)/.test(normalizedType)
    && /^(TRUE|FALSE)$/i.test(trimmed)
  ) {
    return trimmed.toUpperCase();
  }

  const quoted = `'${raw.replaceAll('\\', '\\\\').replaceAll("'", "''")}'`;
  if (/^(DATE|TIME|TIMESTAMP)/.test(normalizedType)) {
    return `CAST(${quoted} AS ${normalizedType})`;
  }
  if (/^(VARIANT|OBJECT|ARRAY)/.test(normalizedType)) {
    return `PARSE_JSON(${quoted})`;
  }
  return quoted;
}

export type CteDraftResult = {
  sql: string;
  status: 'complete' | 'partial' | 'blocked';
  shownCount: number;
  mappedCount: number;
  diagnostics: Array<{targetColumn: string; reference: string; reason: string}>;
  blockers: string[];
};

type CteDraftParams = {
  graph: RelationGraphContext; drivingId: string | null; mappings: MappingState[];
  filterSql?: string; groupBySql?: string; orderBySql?: string;
};

export function buildCteDraftSql(params: CteDraftParams): string | null {
  return buildCteDraft(params)?.sql ?? null;
}

export function buildCteDraft(params: CteDraftParams): CteDraftResult | null {
  const {graph, drivingId, mappings} = params;
  const driver = graph.nodes.find(node => node.relation_id === drivingId);
  if (!driver || driver.kind !== 'DERIVED_SOURCE') return null;
  const connected = new Set([driver.relation_id]);
  const mappedCount = mappings.filter(row => row.status === 'MAPPED').length;
  const diagnostics: CteDraftResult['diagnostics'] = [];
  const comment = (text: string) => `-- ${text.replace(/[\r\n]/g, ' ')}`;
  const blocked = (blockers: string[]): CteDraftResult => ({status:'blocked', shownCount:0, mappedCount,
    diagnostics, blockers, sql: ['-- Draft unavailable; no mapping rows were discarded.',
      ...blockers.map(comment), ...diagnostics.map(item => comment(`${item.targetColumn}: review ${item.reference}. ${item.reason}`))].join('\n')});
  if (Object.keys(graph.query_modifiers ?? {}).some(key => !['distinct','having','qualify','limit','offset'].includes(key))) {
    return blocked(['This CTE uses query modifiers that require scope-aware compilation. Select Compile & Validate.']);
  }
  const pending = [...graph.edges];
  const joins: string[] = [];
  const issues: string[] = [];
  const render = (node: typeof driver) => node.sql_text?.trim()
    ? `${node.alias} AS ${node.alias}`
    : node.table ? `${qualifiedTableName(node.table)} AS ${node.alias}` : null;
  while (pending.length) {
    const index = pending.findIndex(edge => connected.has(edge.left_relation_id) !== connected.has(edge.right_relation_id));
    if (index < 0) { issues.push('The prepared joins need graph review.'); break; }
    const [edge] = pending.splice(index, 1);
    const reverse = connected.has(edge.right_relation_id);
    const nextId = reverse ? edge.left_relation_id : edge.right_relation_id;
    const next = graph.nodes.find(node => node.relation_id === nextId);
    const left = graph.nodes.find(node => node.relation_id === edge.left_relation_id);
    const right = graph.nodes.find(node => node.relation_id === edge.right_relation_id);
    if (!next || !left || !right || !render(next)) { issues.push('A joined source needs its SQL definition.'); break; }
    const joinType = String(edge.join_type || 'INNER').toUpperCase().replace(/\s+OUTER$/, '');
    if (!['INNER','LEFT','RIGHT','FULL'].includes(joinType)) { issues.push('This join type needs compiler review.'); break; }
    const type = reverse ? ({LEFT:'RIGHT',RIGHT:'LEFT'}[joinType as 'LEFT' | 'RIGHT'] ?? joinType) : joinType;
    const predicate = edge.additional_predicate || (edge.conditions ?? []).map(condition =>
      `${left.alias}.${condition.left_column} ${condition.operator || '='} ${right.alias}.${condition.right_column}`).join(' AND ');
    if (!predicate) { issues.push('A prepared join has no complete predicate.'); break; }
    joins.push(`${type} JOIN ${render(next)} ON ${predicate}`);
    connected.add(nextId);
  }
  const bindDraftExpression = (raw: string): string | null => {
    if (!raw.trim()) return null;
    // A conservative lexical subset, not a replacement for compiler validation.
    // Never rewrite literals/comments or accept query scopes in a row expression.
    const tokens = /'(?:''|[^'])*'|--[^\r\n]*|\/\*[\s\S]*?\*\/|(?:"(?:""|[^"])*"|[A-Za-z_][A-Za-z0-9_$]*)(?:\s*\.\s*(?:"(?:""|[^"])*"|[A-Za-z_][A-Za-z0-9_$]*))*|\$[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|\s+|\|\||<>|!=|<=|>=|[()+*/,=<>%-]/gy;
    const keywords = new Set(['CASE','WHEN','THEN','ELSE','END','NULL','TRUE','FALSE','AND','OR','NOT','IS','IN','LIKE','ILIKE','BETWEEN']);
    const functions = new Set(['TRIM','LTRIM','RTRIM','UPPER','LOWER','COALESCE','NULLIF','IFF','CONCAT','CONCAT_WS','REPLACE','SUBSTR','SUBSTRING','LENGTH','ROUND','ABS']);
    let rendered = '', offset = 0, depth = 0;
    while (offset < raw.length) {
      tokens.lastIndex = offset;
      const match = tokens.exec(raw);
      if (!match) return null;
      const token = match[0];
      offset = tokens.lastIndex;
      if (token === '(') depth++;
      if (token === ')' && --depth < 0) return null;
      if (/^["A-Za-z_]/.test(token)) {
        const parts = sqlIdentifierParts(token);
        if (parts.length >= 2) {
          const qualifier = JSON.stringify(parts.slice(0,-1));
          const matches = graph.nodes.filter(node => connected.has(node.relation_id) && [node.alias,
            node.table ? qualifiedTableName(node.table) : ''].some(value => sqlIdentifierKey(value) === qualifier));
          if (matches.length !== 1) return null;
          const output = parts[parts.length-1];
          const matchingOutputs = (matches[0].output_columns ?? []).filter(column => {
            if (column.sql_name) return sqlIdentifierKey(column.sql_name) === JSON.stringify([output]);
            return String(column.name ?? column.column_name ?? '') === output;
          });
          if (matchingOutputs.length !== 1) return null;
          rendered += `${matches[0].alias}."${output.replaceAll('"','""')}"`;
          continue;
        }
        const upper = token.toUpperCase();
        if (!keywords.has(upper) && !(functions.has(upper) && /^\s*\(/.test(raw.slice(offset)))) return null;
      }
      rendered += token;
    }
    return depth === 0 ? rendered : null;
  };
  const selections: string[] = [];
  for (const mapping of mappings.filter(row => row.status === 'MAPPED')) {
    let expression: string | null = null;
    if (mapping.mappingMode === 'constant' || mapping.mappingMode === 'attribute') {
      expression = mapping.constantValue == null ? null : buildSnowflakeConstantExpression(mapping.constantValue, mapping.targetType);
    } else {
      const sources = mapping.sourceColumns?.length ? mapping.sourceColumns : parseSourceColumns(mapping.sourceColumn);
      // Only expressions whose complete lexical binding can be checked are shown.
      const raw = mapping.expression?.trim() || (sources.length === 1 && ['DIRECT','IDENTITY',''].includes((mapping.rule || '').toUpperCase()) ? sources[0] : '');
      expression = bindDraftExpression(canonicalizeCteReferences(raw, graph));
    }
    if (expression) selections.push(`  ${expression}\n    AS ${mapping.targetColumn}`);
    else diagnostics.push({targetColumn: mapping.targetColumn,
      reference: mapping.expression || (mapping.sourceColumns?.length ? mapping.sourceColumns.join(', ') : mapping.sourceColumn) || mapping.attributeName || '(no value)',
      reason: mapping.mappingMode === 'constant' || mapping.mappingMode === 'attribute'
        ? 'Value is unavailable; configure the constant or Firm Value.'
        : 'Binding is not uniquely available in the outer source scope, or the expression needs compiler review. Expose the column in the CTE or prepare an explicit connected relation.'});
  }
  if (issues.length) return blocked(issues);
  if (!selections.length) return blocked([mappedCount ? 'No mapped projections can be shown safely.' : 'Map a target column to see SQL here.']);
  const definitions = graph.nodes.filter(node => connected.has(node.relation_id) && node.sql_text?.trim())
    .map(node => `${node.alias} AS (\n${node.sql_text!.trim().replace(/;\s*$/, '')}\n)`);
  if (graph.nodes.some(node => connected.has(node.relation_id) && (node.parent_relation_ids ?? []).length)) {
    return blocked(['This CTE has external derived dependencies. Compile to resolve their scoped definitions.']);
  }
  if (!definitions.length || !render(driver)) return blocked(['The CTE driver needs its SQL definition.']);
  const modifiers = graph.query_modifiers ?? {};
  const header = diagnostics.length ? [
    `-- Partial draft - not compiled or validated. ${selections.length} of ${mappedCount} mapped targets shown.`,
    '-- Omitted projections remain in the mapping and full compiler request. This incomplete projection may change DISTINCT/grouped results.',
    ...diagnostics.map(item => comment(`${item.targetColumn}: review ${item.reference}. ${item.reason}`)),
  ] : ['-- Draft SQL - not compiled or validated.'];
  const sql = [...header, `WITH ${definitions.join(',\n')}`,
    `SELECT${modifiers.distinct ? ' DISTINCT' : ''}\n${selections.join(',\n')}`, `FROM ${render(driver)}`,
    ...joins, params.filterSql ? `WHERE ${params.filterSql}` : '', params.groupBySql ? `GROUP BY ${params.groupBySql}` : '',
    modifiers.having ? (/^HAVING\b/i.test(modifiers.having) ? modifiers.having : `HAVING ${modifiers.having}`) : '',
    modifiers.qualify ? (/^QUALIFY\b/i.test(modifiers.qualify) ? modifiers.qualify : `QUALIFY ${modifiers.qualify}`) : '',
    params.orderBySql ? `ORDER BY ${params.orderBySql}` : '', modifiers.limit ? (/^LIMIT\b/i.test(modifiers.limit) ? modifiers.limit : `LIMIT ${modifiers.limit}`) : '',
    modifiers.offset ? (/^OFFSET\b/i.test(modifiers.offset) ? modifiers.offset : `OFFSET ${modifiers.offset}`) : ''].filter(Boolean).join('\n');
  return {sql, status: diagnostics.length ? 'partial' : 'complete', shownCount: selections.length,
    mappedCount, diagnostics, blockers: []};
}

export function buildMappingSelectSql(params: {
  mappings: MappingState[];
  sourceQuerySql: string;
  sourceTables?: TableRef[];
  derivedSources?: DerivedSource[];
  sourceFilterSql?: string;
  sourceGroupBySql?: string;
  sourceOrderBySql?: string;
  projectAttributes?: ProjectAttributeRecord[];
}) {
  return resolveProjectValuePlaceholders(buildUnresolvedMappingSelectSql(params), params.projectAttributes ?? []);
}

function buildUnresolvedMappingSelectSql(params: {
  mappings: MappingState[];
  sourceQuerySql: string;
  sourceTables?: TableRef[];
  derivedSources?: DerivedSource[];
  sourceFilterSql?: string;
  sourceGroupBySql?: string;
  sourceOrderBySql?: string;
}) {
  const {
    mappings,
    sourceQuerySql,
    sourceTables = [],
    derivedSources = [],
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
  } = params;
  const activeMappings = mappings.filter((mapping) => mapping.status === 'MAPPED');
  const { withBlock, fromTail } = splitBaseQuerySql(
    resolveLegacyDerivedReferences(sourceQuerySql, derivedSources),
  );
  if (!fromTail) {
    return '-- Select source tables and relationships in Step 1 to generate SQL.';
  }

  if (!activeMappings.length) {
    const lines = withBlock
      ? [withBlock, 'SELECT', '  *', fromTail]
      : ['SELECT', '  *', fromTail];
    if (sourceFilterSql?.trim()) lines.push(`WHERE\n${sourceFilterSql.trim()}`);
    if (sourceGroupBySql?.trim()) lines.push(`GROUP BY\n  ${sourceGroupBySql.trim()}`);
    if (sourceOrderBySql?.trim()) lines.push(`ORDER BY\n  ${sourceOrderBySql.trim()}`);
    return lines.join('\n');
  }

  const lines = [
    ...(withBlock ? [withBlock] : []),
    'SELECT',
    activeMappings
      .map(
        (mapping) =>
          `  ${buildResolvedMappingExpression(mapping, { sourceTables, derivedSources })} AS ${mapping.targetColumn}`,
      )
      .join(',\n'),
    fromTail,
  ];

  if (sourceFilterSql?.trim()) {
    lines.push(`WHERE\n${sourceFilterSql.trim()}`);
  }
  if (sourceGroupBySql?.trim()) {
    lines.push(`GROUP BY\n  ${sourceGroupBySql.trim()}`);
  }
  if (sourceOrderBySql?.trim()) {
    lines.push(`ORDER BY\n  ${sourceOrderBySql.trim()}`);
  }

  return lines.join('\n');
}

export function buildMappingInsertSql(params: {
  mappings: MappingState[];
  targetQualifiedName: string | null;
  sourceQuerySql: string;
  sourceTables?: TableRef[];
  derivedSources?: DerivedSource[];
  sourceFilterSql?: string;
  sourceGroupBySql?: string;
  sourceOrderBySql?: string;
  projectAttributes?: ProjectAttributeRecord[];
}) {
  const {
    mappings,
    targetQualifiedName,
    sourceQuerySql,
    sourceTables = [],
    derivedSources = [],
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    projectAttributes,
  } = params;
  const selectSql = buildMappingSelectSql({
    mappings,
    sourceQuerySql,
    sourceTables,
    derivedSources,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    projectAttributes,
  });
  if (selectSql.startsWith('--')) {
    return selectSql;
  }

  const activeMappings = mappings.filter((mapping) => mapping.status === 'MAPPED');
  const insertColumns = activeMappings.map((mapping) => `  ${mapping.targetColumn}`).join(',\n');
  const today = new Date().toISOString().slice(0, 10);

  return [
    '-- STTM Builder - Auto-generated SQL',
    `-- Target: ${targetQualifiedName ?? 'TARGET_TABLE'}`,
    `-- Date: ${today}`,
    '',
    `INSERT INTO ${targetQualifiedName ?? 'TARGET_TABLE'} (`,
    insertColumns,
    ')',
    selectSql,
    ';',
  ].join('\n');
}
