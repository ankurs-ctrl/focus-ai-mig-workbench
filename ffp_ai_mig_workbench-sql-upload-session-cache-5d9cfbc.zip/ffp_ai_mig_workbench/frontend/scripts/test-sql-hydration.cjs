const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
function load(relative) {
  const filename = path.resolve(__dirname, relative);
  const loaded = new Module(filename, module);
  loaded.require = (name) => name.startsWith('@/')
    ? load(`../src/${name.slice(2)}.ts`) : require(name);
  loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
  }).outputText, filename);
  return loaded.exports;
}
const { hydrateBuilderFromSql } = load('../src/features/sttm/source-target/sql-hydration.ts');
const tables = ['A', 'B'].map(name => ({id: `D.S.${name}`, database: 'D', schema: 'S', name,
  columns: [{name:'ID'}, {name:'TS'}, {name:'ACTIVE'}, {name:'NAME'}]}));
const hydrated = hydrateBuilderFromSql("SELECT a.ID, UPPER(a.NAME) AS CLEAN FROM D.S.A a LEFT JOIN D.S.B b ON a.ID=b.ID WHERE a.ACTIVE=TRUE QUALIFY ROW_NUMBER() OVER(PARTITION BY a.ID ORDER BY a.TS)=1 ORDER BY a.ID DESC NULLS FIRST LIMIT 5", tables);
assert.equal(hydrated.joins.length, 1);
assert.equal(hydrated.filterGroups[0].children[0].field, 'S.A.ACTIVE');
assert.match(hydrated.clauses.qualify, /ROW_NUMBER/);
assert.equal(hydrated.clauses.orderBy[0], 'a.ID DESC NULLS FIRST');
assert.equal(hydrated.clauses.limit, '5');
assert.match(hydrated.projectionSql, /UPPER\(a.NAME\) AS CLEAN/);
assert.equal(hydrated.relationAliases['D.S.A'], 'a');
const partial = hydrateBuilderFromSql('SELECT a.ID FROM D.S.A a LEFT JOIN D.S.B b ON a.ID=b.ID AND b.ACTIVE=TRUE', tables);
assert.equal(partial.diagnostics.unparsedJoinConditions.length, 1);
const ambiguous = hydrateBuilderFromSql('SELECT ID FROM A', [...tables, {...tables[0], id:'OTHER.S.A', database:'OTHER'}]);
assert.equal(ambiguous.diagnostics.unresolvedTables.length, 1);
const literal = hydrateBuilderFromSql("SELECT '-- not a comment /* */' AS TXT FROM D.S.A a", tables);
assert.match(literal.projectionSql, /-- not a comment/);
const { selectedDerivedClosure } = load('../src/features/sttm/shared/derived-source-closure.ts');
const sources = [{id:'base', isSelected:false}, {id:'final', isSelected:true, parentDerivedSourceIds:['base']}];
assert.deepEqual(selectedDerivedClosure(sources).map(s=>s.id), ['base','final']);
assert.equal(sources[0].isSelected, false);
assert.throws(()=>selectedDerivedClosure([{id:'f',isSelected:true,parentDerivedSourceIds:['missing']}]), /Missing/);
assert.throws(()=>selectedDerivedClosure([{id:'f',isSelected:true,parentDerivedSourceIds:['f']}]), /Cyclic/);
console.log('SQL hydration and dependency closure regressions passed.');

const {bindScopeRelations, localScopeSourceTables, scopeProjection, scopeSelectedColumns} = load('../src/features/sttm/source-target/scoped-sql-editor.ts');
const ref = (qualifier, name) => ({qualifier, name, name_sql:name, quoted:false, qualifier_quoted:false});
const direct = ref('a', 'ID');
const scope = {
  scope_id:'statement:0/scope:0', query_kind:'select', parent_scope_id:null, kind:'query', name:null,
  definition_sql:'', definition_hash:'hash', projection_sql:"a.ID AS KEY, UPPER(a.NAME) AS CLEAN, 'literal' AS LABEL",
  clauses:{distinct:'DISTINCT',having:'HAVING COUNT(*) > 1',qualify:'QUALIFY ROW_NUMBER() OVER(ORDER BY a.ID)=1',limit:'LIMIT 5',offset:'OFFSET 2'},
  relations: tables.map((table,index)=>({relation_instance_id:`r${index}`, relation_name:table.id, alias:['a','b'][index],
    alias_sql:['a','b'][index], sql:`${table.id} AS ${['a','b'][index]}`, source_scope_id:null,
    identifier_parts:['D','S',table.name].map(name=>({name,quoted:false}))})),
  joins:[{join_id:'j',right_relation_id:'r1',referenced_relation_ids:['r0','r1'],join_type:'LEFT OUTER',using:[],
    predicate:'a.ID = b.ID OR (a.TS > b.TS AND b.ACTIVE = TRUE)'}],
  outputs:[
    {name:'KEY',sql:'a.ID AS KEY',ordinal:0,direct_column:direct,star:false,source_columns:[direct]},
    {name:'CLEAN',sql:'UPPER(a.NAME) AS CLEAN',ordinal:1,direct_column:null,star:false,source_columns:[ref('a','NAME')]},
    {name:'LABEL',sql:"'literal' AS LABEL",ordinal:2,direct_column:null,star:false,source_columns:[]},
  ],
};
const localDependency = {...scope, scope_id:'cte-addresses', parent_scope_id:'root', kind:'cte', name:'__addresses', joins:[], relations:[scope.relations[0]]};
const localRoot = {...scope, scope_id:'root', joins:[], relations:[{...scope.relations[0], relation_name:'__addresses', source_scope_id:'cte-addresses', identifier_parts:[{name:'__addresses',quoted:false}]}]};
const beforeLocal = JSON.stringify([localRoot, localDependency]);
assert.deepEqual(localScopeSourceTables(localRoot,[localRoot,localDependency],tables), ['D.S.A']);
assert.equal(JSON.stringify([localRoot,localDependency]),beforeLocal);
assert.throws(()=>localScopeSourceTables(localRoot,[localRoot],tables),/Missing local SQL scope/);
assert.throws(()=>localScopeSourceTables(localRoot,[localRoot,{...localDependency,relations:localRoot.relations}],tables),/Recursive CTE/);
assert.throws(()=>localScopeSourceTables({...localRoot,relations:[{...localRoot.relations[0],source_scope_id:null}]},[localRoot],tables),/Unavailable source identity/);
const binding = bindScopeRelations(scope, tables);
const pairScope = {...scope, joins:[{...scope.joins[0], predicate:'a.ID = b.ID', structured:{
  left_relation_id:'r0', right_relation_id:'r1', conditions:[{left_column:'ID',operator:'=',right_column:'ID'}],
}}]};
const pairBinding = bindScopeRelations(pairScope,tables);
assert.equal(pairBinding.joins[0].sqlPredicate, undefined);
assert.deepEqual(pairBinding.joins[0].conditions,[{id:'condition-0',leftColumn:'ID',operator:'=',rightColumn:'ID'}]);
assert.equal(binding.joins[0].sqlPredicate, scope.joins[0].predicate);
assert.deepEqual(binding.joins[0].conditions, []);
assert.equal(binding.joins[0].joinType, 'LEFT');
const selected = scopeSelectedColumns(scope, binding, tables);
assert.deepEqual(selected, {'D.S.A':['ID','NAME']});
const edited = scopeProjection(scope, binding, tables, {'D.S.A':['NAME','TS']}, selected);
assert.equal(edited, 'UPPER(a.NAME) AS CLEAN, \'literal\' AS LABEL, a."TS"');
assert.equal(scopeProjection(scope,binding,tables,selected,selected),scope.projection_sql);
const extra = scopeProjection(scope,binding,tables,{'D.S.A':['ID','NAME','TS']},selected);
assert.match(extra,/a.ID AS KEY/);
assert.match(extra,/UPPER\(a.NAME\) AS CLEAN/);
const starScope={...scope, projection_sql:'a.*', outputs:[{name:'*',sql:'a.*',ordinal:0,star:true,plain_star:true,
  star_qualifier:'a',direct_column:null,source_columns:[]}]};
const allColumns=scopeSelectedColumns(starScope,binding,tables);
assert.equal(scopeProjection(starScope,binding,tables,{'D.S.A':['ID']},allColumns),'a."ID"');
assert.throws(()=>scopeProjection(starScope,binding,tables.map(table=>({...table,columns:[]})),
  {'D.S.A':['ID']},{}),/complete source-column catalog/);
const selfJoin={...scope,relations:[scope.relations[0],{...scope.relations[0],relation_instance_id:'r1',alias:'b'}]};
assert.throws(()=>bindScopeRelations(selfJoin,tables),/same table more than once/);
const ambiguousScope={...scope,relations:[{...scope.relations[0],relation_name:'A',identifier_parts:[{name:'A',quoted:false}]}]};
assert.throws(()=>bindScopeRelations(ambiguousScope,[...tables,{...tables[0],id:'D.OTHER.A',schema:'OTHER'}]),/Ambiguous/);
console.log('Canonical full-join predicates, output aliases, computed outputs and wildcard edits passed.');

const {buildSqlUploadWorkspace} = load('../src/features/sttm/mapping/sql-upload-workspace.ts');
const uploaded = {asset_id:'fixture',parsed_summary:{
  source_tables:['D.S.A','D.S.B'], target_table:'D.T.RESULT', driving_relation:'D.S.A',
  outer_relation_aliases:{A:'D.S.A',B:'D.S.B'}, outer_where_sql:'a.ACTIVE = TRUE',
  query_scopes:[scope], ctes:[], variables:{VALUE:'replacement'},
  variable_bindings:[{name:'VALUE',resolved_value:'replacement',inferred_type:'VARCHAR'}],
  column_mappings:[{target_alias:'KEY',source_columns:['a.ID'],mapping_mode:'source',
    transformation:"CONCAT(a.ID, '$VALUE') /* a.ID stays comment */"}],
}};
const workspace = buildSqlUploadWorkspace(uploaded);
const pairWorkspace = buildSqlUploadWorkspace({...uploaded,parsed_summary:{...uploaded.parsed_summary,query_scopes:[pairScope]}});
assert.equal(pairWorkspace.relationships[0].sqlPredicate,undefined);
assert.equal(pairWorkspace.relationships[0].conditions[0].leftColumn,'ID');
assert.equal(workspace.relationships.length,1);
assert.match(workspace.relationships[0].sqlPredicate,/ OR /);
assert.deepEqual(workspace.relationships[0].conditions,[]);
assert.equal(workspace.queryModifiers.distinct,'DISTINCT');
assert.equal(workspace.queryModifiers.limit,'LIMIT 5');
assert.match(workspace.queryModifiers.qualify,/QUALIFY/);
assert.match(workspace.mappings[0].expression,/'\$VALUE'/);
assert.match(workspace.mappings[0].expression,/\/\* a.ID stays comment \*\//);
console.log('Shared upload/Mapping/source adapter preserves complete predicates and SQL literals.');
const {appendPreviewClauses}=load('../src/features/sttm/source-target/query-preview-clauses.ts');
const preview=appendPreviewClauses('SELECT DISTINCT a.ID FROM D.S.A a', {
  whereSql:'a.ID > 1', groupBySql:'a.ID', orderBySql:'a.ID DESC NULLS FIRST', modifiers:workspace.queryModifiers,
});
assert.ok(preview.indexOf('WHERE') < preview.indexOf('GROUP BY'));
assert.ok(preview.indexOf('GROUP BY') < preview.indexOf('HAVING'));
assert.ok(preview.indexOf('HAVING') < preview.indexOf('QUALIFY'));
assert.ok(preview.indexOf('QUALIFY') < preview.indexOf('\nORDER BY'));
assert.ok(preview.indexOf('\nORDER BY') < preview.indexOf('LIMIT'));
assert.ok(preview.endsWith('OFFSET 2'));
console.log('Source preview retains scope clauses in Snowflake query order.');
const {sqlIdentifierParts,sqlIdentifierKey,sqlIdentifierSuffixMatches}=load('../src/features/sttm/shared/sql-identifiers.ts');
assert.deepEqual(sqlIdentifierParts('"Db.X"."Sch"."a.b"'),['Db.X','Sch','a.b']);
assert.deepEqual(sqlIdentifierParts(' db . s . t '),['DB','S','T']);
assert.notEqual(sqlIdentifierKey('D.S."case"'),sqlIdentifierKey('D.S.CASE'));
assert.equal(sqlIdentifierSuffixMatches('"Db.X"."Sch"."a.b"','"Sch"."a.b"'),true);
assert.equal(sqlIdentifierSuffixMatches('D.S."case"','CASE'),false);
assert.deepEqual(sqlIdentifierParts('D.S.T;DROP'),[]);
console.log('Quoted dots and case-sensitive identities remain distinct in upload resolution.');

// A bare (non-parenthesized) CASE...END predicate must not have its internal
// WHEN-branch ANDs/ORs mistaken for top-level delimiters, and the whole CASE
// expression must survive as one editable leaf instead of degrading to an
// unrepresented (empty-field) fallback that forces raw SQL mode.
const caseTables = [{id:'D.S.C', database:'D', schema:'S', name:'C',
  columns:[{name:'ID'},{name:'STATUS'},{name:'FLAG'}]}];
const caseWhereSql = "SELECT c.ID FROM D.S.C c WHERE (c.STATUS = 'A' OR c.ID IN (1,2)) AND CASE WHEN c.ID = 1 AND c.FLAG = 1 THEN 'Yes' WHEN c.FLAG = 0 THEN 'No' ELSE 'No' END = 'Yes' AND c.ID > 0";
const hydratedCase = hydrateBuilderFromSql(caseWhereSql, caseTables);
const topLevelParts = hydratedCase.filterGroups[0].children;
assert.equal(topLevelParts.length, 3, 'CASE WHEN...AND...END must not fragment the top-level AND split');
assert.equal(topLevelParts[0].type, 'group');
assert.equal(topLevelParts[0].logic, 'OR');
assert.equal(topLevelParts[1].type, 'condition');
assert.match(topLevelParts[1].field, /^CASE WHEN/);
assert.match(topLevelParts[1].field, /END$/);
assert.equal(topLevelParts[1].operator, '=');
assert.equal(topLevelParts[1].value, 'Yes');
assert.equal(topLevelParts[2].field, 'S.C.ID');
assert.equal(topLevelParts[2].operator, '>');
assert.equal(topLevelParts[2].value, '0');

// The uploaded EverNest-style outer WHERE: an OR group, a CASE...END compared
// to a literal, and a plain condition, all at the top level.
const everNestWhereSql = "SELECT c.ID FROM D.S.C c WHERE (c.STATUS IN ('Client') OR c.ID IN (1193, 1441)) AND CASE WHEN c.ID IN (444,619) THEN 'Yes' WHEN c.FLAG = 1 THEN 'Yes' ELSE 'No' END = 'Yes' AND c.FLAG = 0";
const hydratedEverNest = hydrateBuilderFromSql(everNestWhereSql, caseTables);
const everNestParts = hydratedEverNest.filterGroups[0].children;
assert.equal(everNestParts.length, 3);
assert.match(everNestParts[1].field, /^CASE WHEN c\.ID IN \(444,619\) THEN 'Yes' WHEN c\.FLAG = 1 THEN 'Yes' ELSE 'No' END$/);
assert.equal(everNestParts[1].value, 'Yes');

// A plain string literal / BETWEEN / NOT(...) must now be fully representable
// (no empty-field leaf), confirming add-derived-modal.tsx no longer needs its
// removed blanket raw-mode regex for these shapes.
const hasUnrepresentedFilter = (groups) => groups.some((group) => group.children.some((child) =>
  child.type === 'group' ? hasUnrepresentedFilter([child]) : !child.field));
const literalWhereSql = "SELECT c.ID FROM D.S.C c WHERE c.STATUS = 'Active' AND c.ID BETWEEN 1 AND 10 AND NOT (c.FLAG = 1)";
const hydratedLiteral = hydrateBuilderFromSql(literalWhereSql, caseTables);
assert.equal(hasUnrepresentedFilter(hydratedLiteral.filterGroups), false,
  'literal/BETWEEN/NOT(...) predicates must be fully representable without raw-mode fallback');
console.log('CASE...END depth-aware parsing and literal/BETWEEN representability passed.');
