#!/usr/bin/env python3
"""Render the SPCS service spec template using environment variables."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from string import Template
from urllib.parse import urlparse


def _validate_spcs_oauth_config(template_path: Path) -> None:
    if template_path.name not in {"webapp.yaml.tmpl", "sttm-builder.yaml.tmpl"}:
        return
    if os.environ.get("AUTH_MODE", "").strip().lower() != "custom_oauth":
        return

    redirect_uri = os.environ.get("SNOWFLAKE_OAUTH_REDIRECT_URI", "").strip()
    parsed = urlparse(redirect_uri)
    if parsed.scheme != "https" or parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
        raise SystemExit(
            "SNOWFLAKE_OAUTH_REDIRECT_URI for the SPCS webapp must be an HTTPS "
            "public callback URL; localhost and loopback redirects are rejected"
        )
    if os.environ.get("AUTH_SESSION_COOKIE_SECURE", "").strip().lower() != "true":
        raise SystemExit(
            "AUTH_SESSION_COOKIE_SECURE must be true for custom OAuth in SPCS"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    template_path = Path(args.template)
    _validate_spcs_oauth_config(template_path)
    template = Template(template_path.read_text(encoding="utf-8"))
    rendered = template.safe_substitute(os.environ)
    Path(args.output).write_text(rendered, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
