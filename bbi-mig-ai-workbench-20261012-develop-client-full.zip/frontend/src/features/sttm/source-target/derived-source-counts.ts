import type { DerivedSource } from "@/features/sttm/types/sttm.types";

export function getDerivedSourceCounts(source: DerivedSource) {
  const sourceTableCount = source.tableIds?.length ?? source.baseSourceTables?.length ?? 0;
  const outputColumnCount =
    source.outputColumns?.length
    || source.previewColumns?.length
    || source.columns?.length
    || 0;
  const selectedColumnCount = source.selectedColumnsByTable
    ? Object.values(source.selectedColumnsByTable).reduce(
        (total, columns) => total + columns.length,
        0,
      )
    : (source.columns?.length ?? 0);

  return { sourceTableCount, selectedColumnCount, outputColumnCount };
}

/** e.g. "1 source table · 2 output columns" */
export function formatDerivedSourceSummary(source: DerivedSource): string {
  const { sourceTableCount, selectedColumnCount, outputColumnCount } =
    getDerivedSourceCounts(source);
  const tables = `${sourceTableCount} source table${sourceTableCount === 1 ? "" : "s"}`;
  const columns =
    outputColumnCount > 0
      ? `${outputColumnCount} output column${outputColumnCount === 1 ? "" : "s"}`
      : `${selectedColumnCount} selected columns`;
  return `${tables} · ${columns}`;
}
