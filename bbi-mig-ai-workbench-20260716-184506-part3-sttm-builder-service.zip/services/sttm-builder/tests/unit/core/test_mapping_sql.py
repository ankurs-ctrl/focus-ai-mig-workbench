from app.core.mapping_sql import MappingSqlService
from app.core.snowflake_analyst import SnowflakeAnalystResponse
from app.schema.mapping_sql import MappingSqlReviewRequest


class _Query:
    def collect(self):
        return []


class _Session:
    def sql(self, _query):
        return _Query()


class _Analyst:
    def __init__(self):
        self.calls = []

    def ask(self, **kwargs):
        self.calls.append(kwargs)
        return SnowflakeAnalystResponse(
            request_id="analyst-request",
            text="The SQL is valid.",
            sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC",
        )


def test_review_uses_inline_semantic_yaml_when_view_is_not_promoted() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC",
        generated_sql="INSERT INTO DB.SCHEMA.TGT (ID) SELECT SRC.ID FROM DB.SCHEMA.SRC",
        semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
    )

    response = service.review(request)

    assert response.review_agent == "CORTEX_ANALYST"
    assert analyst.calls[0]["semantic_view"] is None
    assert analyst.calls[0]["semantic_model_yaml"] == request.semantic_model_yaml
