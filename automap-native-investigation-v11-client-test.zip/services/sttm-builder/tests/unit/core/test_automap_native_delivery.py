"""Parent response/checkpoint delivery independent of slow connection setup."""

from concurrent.futures import Future, TimeoutError
from threading import Event
from types import SimpleNamespace
import time
import pytest
from app.core import automap_native_delivery as delivery
from tests.unit.core.test_automap_fast_batch import prepared_request
from tests.unit.core.test_automap_fast_context import fast_payload


def test_ready_worker_is_not_blocked_by_slow_checkpoint_connection(monkeypatch):
    release = Event()
    entered = Event()
    calls = []

    def slow(*args):
        calls.append(1)
        entered.set()
        assert release.wait(3)
        return []

    monkeypatch.setattr(delivery, "_read_checkpoints", slow)
    req = prepared_request(fast_payload())
    future = Future()
    future.set_result("ready")
    start = time.monotonic()
    try:
        results = list(
            delivery.completed_with_checkpoints(
                None,
                {future: 0},
                req,
                [req.data.attributes],
                {},
                poll_seconds=0.01,
                deadline=time.time() + 1,
            )
        )
        assert results == [future] and future.result() == "ready"
        assert time.monotonic() - start < 0.5 and entered.wait(0.5) and calls == [1]
    finally:
        release.set()


def test_parent_deadline_survives_stalled_connection_without_spawning_extra_readers(
    monkeypatch,
):
    release = Event()
    calls = []

    def slow(*args):
        calls.append(1)
        assert release.wait(3)
        return []

    monkeypatch.setattr(delivery, "_read_checkpoints", slow)
    req = prepared_request(fast_payload())
    future = Future()
    start = time.monotonic()
    try:
        with pytest.raises(TimeoutError, match="deadline"):
            list(
                delivery.completed_with_checkpoints(
                    None,
                    {future: 0},
                    req,
                    [req.data.attributes],
                    {},
                    poll_seconds=0.01,
                    deadline=time.time() + 0.08,
                )
            )
        assert time.monotonic() - start < 0.5 and calls == [1]
    finally:
        release.set()


def test_checkpoint_is_returned_even_when_worker_response_failed(monkeypatch):
    req = prepared_request(fast_payload())
    future = Future()
    future.set_exception(RuntimeError("lost response"))
    result = SimpleNamespace(
        meta={
            "auto_map_native_checkpoint_token": "verified",
            "auto_map_native_checkpoint_targets": ["NAME0"],
        }
    )
    import copy

    result.model_copy = lambda **kw: copy.copy(result)

    def read(*args):
        time.sleep(0.02)
        return [(0, req, result)]

    monkeypatch.setattr(delivery, "_read_checkpoints", read)
    proxy = SimpleNamespace(_batch_identity=lambda *a: "batch")
    events = list(
        delivery.completed_with_checkpoints(
            proxy,
            {future: 0},
            req,
            [req.data.attributes],
            {},
            poll_seconds=0.01,
            progress_callback=lambda *a: None,
            deadline=time.time() + 1,
        )
    )
    assert events[0] == ("checkpoint", 0, result)
    assert events[1].result().meta["auto_map_native_provisional"] is False
