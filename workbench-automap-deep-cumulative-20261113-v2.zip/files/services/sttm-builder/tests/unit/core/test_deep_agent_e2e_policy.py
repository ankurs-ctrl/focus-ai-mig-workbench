import importlib.util
import json
from pathlib import Path

import pytest

_SCRIPTS = Path(__file__).resolve().parents[5] / "scripts"


def _harness():
    spec = importlib.util.spec_from_file_location("deep_agent_e2e", _SCRIPTS / "deep_agent_e2e.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _join_item(question: str) -> dict:
    return {"category": "source_join_path", "question": question, "choices": [
        {"choice_id": "c1", "label": "Review candidate path: CONTACTS.ID = CONTACT_UDFS.CONTACT_ID"},
        {"choice_id": "c2", "label": "Use candidate path: CONTACT_UDFS.ID = CONTACTS.ID", "recommended": True},
    ]}


def test_answer_policy_prefers_the_first_matching_rule() -> None:
    policy = _harness().AnswerPolicy({"default": "stop", "rules": [
        {"category": "mapping_candidate_review", "answer": "wrong category"},
        {"question": "CONTACT_UDFS connect to", "choice": r"CONTACTS\.ID = CONTACT_UDFS"},
    ]})
    reply, why = policy.decide(_join_item("Join path 6 of 7: How should DB.SRC.CONTACT_UDFS connect to DB.SRC.CONTACTS?"))
    assert reply == {"choice_id": "c1"}
    assert why.startswith("rule 1")


def test_answer_policy_falls_back_to_recommended_or_stops() -> None:
    harness = _harness()
    item = _join_item("How should DB.SRC.OTHER connect to DB.SRC.CONTACTS?")
    assert harness.AnswerPolicy({"default": "recommended"}).decide(item)[0] == {"choice_id": "c2"}
    assert harness.AnswerPolicy({"default": "stop"}).decide(item)[0] is None
    with pytest.raises(ValueError):
        harness.AnswerPolicy({"default": "guess"})


def test_shipped_tmd_answers_file_is_a_valid_policy() -> None:
    spec = json.loads((_SCRIPTS / "e2e" / "tmd_ten_targets.answers.json").read_text(encoding="utf-8"))
    policy = _harness().AnswerPolicy(spec)
    reply, _ = policy.decide({"category": "source_join_path", "choices": [],
                              "question": "Join path 1 of 7: How should X.Y.CONTACT_FAMILIES connect to X.Y.CONTACTS?"})
    assert reply and "CONTACT_FAMILY_MEMBERS.FAMILY_ID" in reply["answer"]
    notes, _ = policy.decide({"category": "source_join_path", "choices": [],
                              "question": "How should X.Y.NOTES connect to X.Y.CONTACTS?"})
    assert notes and notes["answer"].startswith("NOTES.ID = NOTE_ASSOCIATIONS.NOTE_ID")
