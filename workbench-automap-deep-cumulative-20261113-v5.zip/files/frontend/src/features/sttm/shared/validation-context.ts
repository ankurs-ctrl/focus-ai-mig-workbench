import { sha256 } from '@noble/hashes/sha256';
import type { SttmBuilderState } from '../store/sttm-builder-slice';
import { resolveSelectedSourceTables, resolveSelectedTargetTable } from './sttm-selection-utils';

export function validationDigest(value: unknown): string {
  const stable = (item: unknown): unknown => Array.isArray(item) ? item.map(stable)
    : item && typeof item === 'object' ? Object.fromEntries(Object.entries(item).sort(([a],[b])=>a.localeCompare(b)).map(([key,value])=>[key,stable(value)])) : item;
  return Array.from(sha256(new TextEncoder().encode(JSON.stringify(stable(value)))),byte=>byte.toString(16).padStart(2,'0')).join('');
}
export type SourceValidation = {contextSignature:string; previewKey:string; valid:boolean; synced:boolean};
/** Executable dependencies only: navigation, review flags and model prose are irrelevant. */
export function selectionValidationSignature(state: SttmBuilderState): string {
  const tables=resolveSelectedSourceTables({...state,sources:state.sources??[],sourceDatabases:state.sourceDatabases??[]});
  const identity=(id:string|null|undefined)=>{
    const source=tables.find(table=>table.tableId===id);
    return source&&!source.tableId.startsWith('sql-instance:')?source.qualifiedName:id??null;
  };
  const table=(item:typeof tables[number])=>({id:identity(item.tableId),name:item.qualifiedName});
  return validationDigest({version:1,project:state.activeProjectId,target:resolveSelectedTargetTable({...state,targets:state.targets??[],targetDatabases:state.targetDatabases??[]})?.qualifiedName,
    sources:tables.map(table).sort((a,b)=>String(a.id).localeCompare(String(b.id))),driver:identity(state.drivingTableId),
    derived:(state.derivedSources??[]).filter(item=>item.isSelected).map(item=>({id:item.id,sql:item.sqlText??'',definition:item.definitionSql??'',scope:item.queryScope??{},view:item.physicalViewName??null})).sort((a,b)=>String(a.id).localeCompare(String(b.id))),
    joins:(state.relationships??[]).map(item=>({left:identity(item.leftTableId),right:identity(item.rightTableId),type:item.joinType??'INNER',conditions:(item.conditions??[]).map((condition,index)=>({left:condition.leftColumn??'',right:condition.rightColumn??'',operator:condition.operator??'=',connector:index?condition.connector??'AND':null})),predicate:item.sqlPredicate??null})).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))),
    sql:state.sourceQuerySql??'',filters:state.sourceFilterSql??'',groupBy:state.sourceGroupBySql??'',orderBy:state.sourceOrderBySql??'',modifiers:state.sourceQueryModifiers??{},
    values:state.validationValuesSignature??firmValuesSignature([]),
  });
}
export function readSourceValidation(history: unknown): SourceValidation|null {
  if(!Array.isArray(history))return null;
  const record=[...history].reverse().find(item=>item?.kind==='source_selection_validation');
  return record&&typeof record.contextSignature==='string'&&typeof record.previewKey==='string'&&typeof record.valid==='boolean'&&typeof record.synced==='boolean'
    ? {contextSignature:record.contextSignature,previewKey:record.previewKey,valid:record.valid,synced:record.synced}:null;
}

/** Ignore timestamps and display-only metadata when checking executable Values. */
export function firmValuesSignature(values: Array<Record<string, unknown>>): string {
  return validationDigest(values.map(item=>({id:item.attribute_id??null,name:item.attribute_name??item.name??null,
    type:item.attribute_type??null,value:item.attribute_value??item.value??null,status:item.status??null,
    placeholder:item.placeholder??null,resolution:item.resolution_state??item.resolved??null}))
    .sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))));
}
