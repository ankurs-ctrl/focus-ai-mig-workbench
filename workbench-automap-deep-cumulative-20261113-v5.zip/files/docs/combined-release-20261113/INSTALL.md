# Cumulative Auto-map and Deep Agent overlay

## v4 publication and Deep Agent authentication follow-up

Read `PUBLICATION-DEEP-AUTH.md` first for the latest changes and deployment steps. Publication validates SELECT only and writes definitions to metadata; target INSERT grants are not required. Deep housekeeping uses explicit SPCS service identity while user work reuses the app OAuth session. Existing Deep flags now reach the backend through all supported deployment scripts. Apply the existing Deep migrations if not installed, retain shared OAuth secret mappings and rebuild matching images. No new OAuth credential or production schema migration is introduced by v4. `PUBLICATION-OAUTH-RESULTS.json` records the accepted isolated native checks and their limits.


This package combines the Auto-map remediation with the supplied `deep-agent-develop-20261112-4ea56d6.zip`. Apply the contents of `files/` to the repository root, preserving paths. It is cumulative relative to the supplied client UAT ZIP; previous remediation files are included. Preserve local environment files, credentials, account configuration and deployment secrets. The manifest records every included file.

## v3 preparation follow-up

Read `CACHED-PREPARATION.md` for this release’s cached-handoff, authored-revision, published-semantics and authentication changes. If the previous cumulative release is already installed, deploy matching rebuilt frontend, API and Auto-map workers together on all replicas. This follow-up adds no new environment variable, table, grant, agent instruction, capacity, timeout or context ceiling. Keep the existing client configuration. Previous failed client jobs are not replayed automatically. The steps below still apply to cumulative features not yet installed.

## Deploy in this order

1. Install the included merged backend dependency lock through the existing image build. Apply the additive Deep Agent migrations listed in `docs/deep-agent-integration/DEPLOYMENT.md`, in that order, against the existing metadata namespace. Do not replace the metadata schema or reset existing operational tables.
2. Run the existing metadata bootstrap with the client's current database, schema, warehouse and authentication settings. `scripts/bootstrap_sttm_metadata_infra.py` now includes both `project-bootstrap-lock.sql` and `automap-evidence-tool.sql`. The latter creates `TBL_AUTOMAP_TOOL_CONTEXT` and `SP_AUTOMAP_READ_EVIDENCE(VARCHAR, VARCHAR) EXECUTE AS CALLER`. No admission-table migration is needed. If applying just this additive DDL, substitute `__STTM_METADATA_NAMESPACE__` with the configured metadata namespace before execution.
3. Ensure the existing application role has USAGE on the metadata database/schema and evidence procedure, and SELECT/INSERT/UPDATE on the tool-context table. These are operational evidence records and counters; the procedure does not execute arbitrary model SQL. Use the existing role/grant deployment mechanism; do not grant a new broad role to users.
4. Run `python scripts/verify_mapping_agent_specs.py`. Update the three mapping agents' instructions using `scripts/sync_workbench_agent_specs.py`, preserving client models, budgets, permissions and other tools. Include `--include-evidence-tool --warehouse <existing-warehouse>` for source mapping and transformation rule agents. First prepare/export the diff; then apply the reviewed specifications through the existing agent deployment mechanism. Do not use `--allow-runtime-changes` for this release.
5. Rebuild and deploy matching backend, Auto-map worker and frontend versions to every replica. Keep the existing execution slots, context ceiling, deadlines and warehouse limits. Batches remain independently scheduled under shared admission; a blocked sibling does not create a barrier.

The agent sync command also requires the existing `--cli`, `--connection` and `--namespace` arguments. Its `--output-dir` must be a new absolute directory. `--apply` requires an explicit `--agents` list; publishing a saved specification is a separate verified step. Use the script's help and existing deployment CLI rather than substituting test-account agents.

## Configuration

Auto-map requires no new capacity or timeout setting. Its default source batch size is now eight targets. To activate optional native evidence registration, set the existing `AGENT_SPEC_SOURCE_MAPPING_SHA256` and `AGENT_SPEC_TRANSFORMATION_RULE_SHA256` deployment settings to the respective template hashes in `infra/snowflake/agents/agent_spec_manifest.json`, after installing the corresponding instructions and tool. These settings describe installed capabilities; do not set them before deploying the procedure/tool. Complete initial packets work without optional retrieval.

Deep Agent enablement is separate: retain or configure `MIGRATION_AGENT_ENABLED`, `MIGRATION_AGENT_TRUE_RESUME_V1`, `MIGRATION_AGENT_TOOL_GOVERNANCE_V1`, `ASSISTANT_UNIFIED_HISTORY_V1` and `ASSISTANT_INTENT_ROUTING_V1` as described in the Deep Agent deployment notes. Configure its LIGHT/MEDIUM/HIGH models to ones available to the deployment role. No environment file is supplied or overwritten.

The included container entry point is `python -m app.service_main`, which supervises the API and enabled durable Deep Agent worker. If your deployment already runs a separate supervised worker, choose one arrangement to avoid duplicate workers. The notes in the original Deep Agent delivery describing a develop-only package document that earlier delivery; this cumulative ZIP includes the feature but does not itself deploy or push any branch.

## Release checks and limits

Read `VALIDATION.md` for measured results and remaining deployment checks. Auto-map drafts retain backend-estimated confidence, model confidence when supplied, exact target identities, transformation status and explicit missing dependencies. SQL-upload preview/publication, semantic-gap behavior, admin recovery and internal-alias display fixes are retained.

The 120–140 second performance goal is not claimed as passed. The user accepted the approximately 179-second native correctness result for this release. Current code has not been verified in a newly deployed SPCS image in this session; client OAuth, role grants and multi-replica deployment remain environment-specific checks. No client mappings were modified by isolated acceptance.

## Loan workbook / assistant follow-up

Read `LOAN-ASSISTANT.md` and `LOAN-NATIVE-RESULTS.json` for the real-table test and remaining business inputs. This follow-up changes backend routing/parsing, frontend rendering and AGT_STTM_BUILDER instructions. Deploy those together; it adds no new table or environment variable. The successful real Auto-map acceptance uses the configured fast path. Verify the existing `AUTOMAP_FAST_PATH_V1`, `AUTOMAP_PARALLEL_CONTEXT_V1` and `AUTOMAP_DURABLE_RUNS_V2` installation switches and their already-provisioned shared pool configuration are active for the intended service; do not copy the isolated test pool, reset slots, or raise capacity. The default local standard path timed out and is not claimed as a passing acceptance.
