import time
from unittest.mock import Mock
import pytest
from app.core.snowflake import _acquire_lease_capacity, SnowflakeLeaseDeadlineExpired


def test_capacity_poll_does_not_discard_remaining_batch_deadline():
    semaphore=Mock()
    semaphore.acquire.side_effect=[False,False,True]
    deadline=time.monotonic()+30
    assert _acquire_lease_capacity(semaphore,deadline)
    assert semaphore.acquire.call_count==3
    assert all(0<call.kwargs['timeout']<=5 for call in semaphore.acquire.call_args_list)


def test_unbounded_call_keeps_original_one_wait_behavior():
    semaphore=Mock()
    semaphore.acquire.return_value=False
    assert not _acquire_lease_capacity(semaphore,None)
    assert semaphore.acquire.call_count==1


def test_expired_deadline_does_not_acquire_or_reset_budget():
    semaphore=Mock()
    with pytest.raises(SnowflakeLeaseDeadlineExpired):
        _acquire_lease_capacity(semaphore,time.monotonic()-1)
    semaphore.acquire.assert_not_called()


def test_pool_retirement_preserves_reserved_active_and_queued_callers():
    from app.core.snowflake import SnowflakeSessionLeasePool
    pool=SnowflakeSessionLeasePool(settings=Mock(),user_token='',role='R',workload='control',maximum=2)
    pool.reserve();pool.reserve()
    assert not pool.is_idle
    pool.close()
    assert not pool._closed
    pool.release_reservation()
    assert not pool._closed
    pool.release_reservation()
    assert pool._closed and pool.is_idle


def test_control_retry_window_starts_after_initial_queue_and_is_shared(monkeypatch):
    from contextlib import contextmanager
    from types import SimpleNamespace
    from app.core import automap_admission as admission
    from tests.unit.core.test_automap_admission import Database, ACCOUNT, EPOCH, TABLE
    clock=[100.0]
    monkeypatch.setattr(admission,'time',SimpleNamespace(monotonic=lambda:clock[0],sleep=lambda seconds:clock.__setitem__(0,clock[0]+seconds)))
    database=Database();acquire_deadlines=[];sql_deadlines=[]
    @contextmanager
    def bounded(deadline):
        acquire_deadlines.append(deadline)
        clock[0]+=15 if len(acquire_deadlines)==1 else 1
        with database.factory() as session:yield session
    def provider():return bounded(None)
    provider.with_deadline=bounded
    store=admission.SnowflakeCallAdmission(session_factory=provider,table=TABLE,account_namespace=ACCOUNT,pool_epoch=EPOCH,capacity=2)
    request=SimpleNamespace(effective_deadline=200.0,runtime_trace=None,check_active=lambda:None)
    def operation():
        with store._transaction():
            sql_deadlines.append(admission._CONTROL_DEADLINE.get())
            if len(sql_deadlines)==1:raise admission.AdmissionContended('acknowledged rollback')
    admission.retry_control_operation(request,'dispatch_preparation',operation)
    assert acquire_deadlines==[200.0,125.0]
    assert sql_deadlines==[125.0,125.0]
    assert admission._CONTROL_QUEUE_WINDOW.get() is None
    assert admission._CONTROL_DEADLINE.get() is None


def test_run_acknowledgement_contention_does_not_repost_model(monkeypatch):
    from app.core.automap_durable_admission import DurableRunAdmission
    from app.core.automap_admission import AdmissionContended
    from tests.unit.core.test_automap_durable_runs_v2 import test_real_background_transport_reaches_model_and_confirms_terminal_before_release
    original=DurableRunAdmission.record_run;seen=[]
    def record(self,permit,run_id):
        seen.append((permit,run_id))
        if len(seen)==1:raise AdmissionContended('acknowledged rollback')
        return original(self,permit,run_id)
    monkeypatch.setattr(DurableRunAdmission,'record_run',record)
    test_real_background_transport_reaches_model_and_confirms_terminal_before_release('success')
    assert len(seen)==2 and seen[0]==seen[1]


def test_reusable_capacity_preserves_fifo_and_expired_waiters_do_not_leak():
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event
    from app.core.snowflake import _FairLeaseCapacity
    capacity=_FairLeaseCapacity(1)
    assert _acquire_lease_capacity(capacity,time.monotonic()+5)
    order=[];first_acquired=Event();release_first=Event()
    def wait(index):
        assert _acquire_lease_capacity(capacity,time.monotonic()+5)
        try:
            order.append(index)
            if index==1:
                first_acquired.set();assert release_first.wait(5)
        finally:capacity.release()
    with ThreadPoolExecutor(max_workers=2) as executor:
        first=executor.submit(wait,1)
        # Observe actual queue membership, not thread start order.
        deadline=time.monotonic()+2
        while not capacity._waiters and time.monotonic()<deadline:Event().wait(.001)
        assert capacity._waiters
        second=executor.submit(wait,2)
        capacity.release();assert first_acquired.wait(5)
        assert order==[1]
        release_first.set();first.result();second.result()
    assert order==[1,2]
    assert _acquire_lease_capacity(capacity,time.monotonic()+5)
    with pytest.raises(SnowflakeLeaseDeadlineExpired):_acquire_lease_capacity(capacity,time.monotonic()+.01)
    capacity.release()
    assert _acquire_lease_capacity(capacity,time.monotonic()+5)
    capacity.release()
    with pytest.raises(ValueError):capacity.release()
