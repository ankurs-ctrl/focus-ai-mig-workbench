import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

/** Must match backend Settings.auth_session_cookie_name (AUTH_SESSION_COOKIE_NAME). */
const AUTH_SESSION_COOKIE_NAME = "sttm_session";

const PUBLIC_PATHS = ["/home", "/landing"];

function isPublicPath(pathname: string): boolean {
  return PUBLIC_PATHS.some(
    (path) => pathname === path || pathname.startsWith(`${path}/`),
  );
}

function isAssetOrApiPath(pathname: string): boolean {
  if (pathname.startsWith("/api")) return true;
  if (pathname.startsWith("/_next")) return true;
  // Static files (favicon, images, etc.)
  if (pathname.includes(".") && !pathname.endsWith(".html")) return true;
  return false;
}

function hasAuthSession(request: NextRequest): boolean {
  const value = request.cookies.get(AUTH_SESSION_COOKIE_NAME)?.value?.trim();
  return Boolean(value);
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (isAssetOrApiPath(pathname)) {
    return NextResponse.next();
  }

  const localDevSession = process.env.NODE_ENV === "development"
    && process.env.LOCAL_DEV_AUTH_ENABLED === "true"
    && ["localhost", "127.0.0.1", "[::1]"].includes(request.nextUrl.hostname);
  // Local API sessions use trusted dev identity rather than OAuth cookies.
  // The backend remains responsible for authorizing every data request.
  if (localDevSession) return NextResponse.next();

  const authenticated = hasAuthSession(request);

  if (pathname === "/") {
    const url = request.nextUrl.clone();
    url.pathname = authenticated ? "/dashboard" : "/home";
    return NextResponse.redirect(url);
  }

  if (!authenticated && !isPublicPath(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = "/home";
    url.search = "";
    return NextResponse.redirect(url);
  }

  if (authenticated && isPublicPath(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
