from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any
from unittest.mock import Mock

import pytest

from app.core.project_service import ProjectService
from app.schema.project import STTMAutosaveRequest


def _snapshot(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "page": "summary",
        "surface": "SUMMARY",
        "action": "workspace.autosaved",
        "captured_at": "2026-10-07T10:00:00Z",
        "session_id": "session-1",
        "thread_id": "thread-1",
        "mapping_lifecycle": "new",
        "sttm_description": "Imported from upload.sql",
        "business_goal": "Load accounts",
        "conversation_history": [{"role": "assistant", "content": "Welcome"}],
        "source_tables": [{"database": "DB", "schema": "RAW", "table": "ACCOUNTS"}],
        "target_table": {"database": "DB", "schema": "CUR", "table": "ACCOUNT_DIM"},
        "driving_table": None,
        "driving_relation_id": "sql-cte:abc:final",
        "derived_sources": [{"id": "sql-cte:abc:final", "name": "final", "sql_text": "SELECT 1"}],
        "relation_graph": {
            "nodes": [
                {
                    "relation_id": "sql-cte:abc:final",
                    "kind": "DERIVED_SOURCE",
                    "sql_text": "SELECT  1",
                },
            ],
            "edges": [
                {
                    "left_relation_id": "sql-cte:abc:final",
                    "right_relation_id": "DB.RAW.ACCOUNTS",
                    "join_type": "LEFT",
                    "conditions": [{"left_column": "id", "operator": "=", "right_column": "ID"}],
                }
            ],
        },
        "mapping_rows": [
            {
                "id": "upload:ID:0",
                "target_column": "ID",
                "source_columns": ["cte_final.id"],
                "mapping_mode": "source",
                "expression": None,
                "rule": "Direct",
                "status": "MAPPED",
            }
        ],
        "filters": {"filter_sql": "cte_final.id > 1", "base_query_sql": "WITH x AS (...) SELECT *"},
        "raw_mapping_sql": "WITH final AS (SELECT 1) SELECT id FROM final",
        "compiled_mapping_sql": "",
        "checked_mapping_row_ids": ["upload:ID:0"],
    }
    base.update(overrides)
    return base


def test_autosave_updates_dashboard_target_from_selected_workspace(monkeypatch):
    captured: dict[str, Any] = {}
    service = ProjectService.__new__(ProjectService)
    monkeypatch.setattr(ProjectService, "_sttm_table", property(lambda self: "DB.META.STTM"))
    service._has_column = lambda table, column: True
    service._actor_column_values = lambda table, user: {}
    service._session = SimpleNamespace(sql=lambda statement, params=None: (
        captured.update(statement=statement, params=params)
        or SimpleNamespace(collect=lambda: [])))
    service._update_sttm_draft_payload(
        sttm_id="42", snapshot=_snapshot(), snapshot_id="snap", semantic_bundle_id=None,
        semantic_bundle_hash=None, user_id="user",
    )
    assert "TARGET_TABLE = ?" in captured["statement"]
    assert "DB.CUR.ACCOUNT_DIM" in captured["params"]


def test_existing_dashboard_row_uses_saved_target_when_header_is_empty():
    service = ProjectService.__new__(ProjectService)
    record = service._sttm_from_row({
        "STTM_ID": 42, "PROJECT_ID": 7, "TARGET_TABLE": "",
        "DRAFT_PAYLOAD": {"target_table": {"database": "DB", "schema": "CUR", "table": "ACCOUNT_DIM"}},
        "STTM_METADATA": {},
    }, mapping_counts={})
    assert record.target_table == "DB.CUR.ACCOUNT_DIM"


def test_dashboard_prefers_current_draft_target_over_stale_header():
    service = ProjectService.__new__(ProjectService)
    record = service._sttm_from_row({
        "STTM_ID": 42, "PROJECT_ID": 7, "TARGET_TABLE": "DB.CUR.OLD_TABLE",
        "DRAFT_PAYLOAD": {"target_table": {"database": "DB", "schema": "CUR", "table": "ACCOUNT_DIM"}},
        "STTM_METADATA": {},
    }, mapping_counts={})
    assert record.target_table == "DB.CUR.ACCOUNT_DIM"


def test_semantic_hash_ignores_viewing_and_derived_artifacts() -> None:
    reopened = _snapshot(
        page="mapping",
        surface="MAPPING",
        captured_at="2026-10-08T09:00:00Z",
        session_id="session-2",
        thread_id=None,
        mapping_lifecycle="update",
        sttm_description="",
        business_goal=None,
        conversation_history=[],
        filters={"filter_sql": "cte_final.id  >  1", "base_query_sql": "regenerated preview"},
        compiled_mapping_sql="INSERT INTO ...",
        checked_mapping_row_ids=[],
        authored_sql_semantic_key="ask1:deadbeef:1",
    )

    assert ProjectService._semantic_workspace_hash(reopened) == ProjectService._semantic_workspace_hash(
        _snapshot()
    )


@pytest.mark.parametrize(
    "change",
    [
        {"mapping_rows": [{"target_column": "ID", "source_columns": ["cte_final.id"], "expression": "UPPER(cte_final.id)", "status": "MAPPED"}]},
        {"relation_graph": {"nodes": [{"relation_id": "sql-cte:abc:final", "kind": "DERIVED_SOURCE", "sql_text": "SELECT 2"}], "edges": []}},
        {"source_tables": []},
        {"filters": {"filter_sql": "cte_final.id > 2"}},
        {"driving_relation_id": "DB.RAW.ACCOUNTS"},
        {"raw_mapping_sql": "SELECT 2"},
    ],
)
def test_semantic_hash_detects_mapping_edits(change: dict[str, Any]) -> None:
    assert ProjectService._semantic_workspace_hash(_snapshot(**change)) != ProjectService._semantic_workspace_hash(
        _snapshot()
    )


def test_hash_retains_sql_literal_whitespace_and_predicate_only_edits():
    first = _snapshot(raw_mapping_sql="SELECT 'a  b' FROM t")
    second = _snapshot(raw_mapping_sql="SELECT 'a b' FROM t")
    assert ProjectService._semantic_workspace_hash(first) != ProjectService._semantic_workspace_hash(second)
    original = _snapshot()
    edited = _snapshot()
    edited["relation_graph"]["edges"][0]["additional_predicate"] = "a.ID = b.ID OR b.ID IS NULL"
    assert ProjectService._semantic_workspace_hash(original) != ProjectService._semantic_workspace_hash(edited)
    edited = _snapshot()
    edited["filters"]["query_modifiers"] = {"qualify": "ROW_NUMBER() OVER(ORDER BY ID)=1"}
    assert ProjectService._semantic_workspace_hash(original) != ProjectService._semantic_workspace_hash(edited)


def test_legacy_snapshot_matches_current_snapshot_of_same_mapping() -> None:
    current = _snapshot(
        driving_relation_id="DB.RAW.ACCOUNTS",
        relation_graph={"nodes": [], "edges": []},
    )
    legacy = {
        key: value
        for key, value in current.items()
        if key not in {"driving_relation_id", "unresolved_source_tables"}
    }
    legacy["driving_table"] = {"database": "db", "schema": "raw", "table": "accounts"}
    legacy["derived_sources"] = [{"id": "sql-cte:abc:final", "name": "final"}]

    assert ProjectService._semantic_workspace_hash(legacy) == ProjectService._semantic_workspace_hash(current)


def _autosave_service(previous: dict[str, Any], *, has_unpublished_draft: bool = False):
    service = ProjectService.__new__(ProjectService)
    calls: dict[str, list[Any]] = {"draft": [], "sources": [], "rows": []}
    service._settings = SimpleNamespace(
        autosave_postsave_async_v1=True,
        autosave_singleflight_v1=False,
        snowflake_sttm_table="STTMS", snowflake_sttm_sources_table="SOURCES",
        snowflake_sttm_attributes_table="ATTRIBUTES",
        qualify_metadata_object_name=lambda name: f"DB.S.{name}",
    )
    service._table_columns = Mock(return_value=set())
    service._session = Mock()
    service._session.sql.return_value.collect.return_value = [{"number_of_rows_updated": 1}]
    service._async_jobs = Mock()
    service._async_jobs.enqueue.return_value = ("job", "queued")
    service.ensure_storage_exists = lambda: None
    service.get_sttm_record = lambda _sttm_id, *, include_counts=True: SimpleNamespace(
        project_id="p1",
        metadata={},
        has_unpublished_draft=has_unpublished_draft,
    )
    service._validate_project_value_bindings = lambda _project_id, _snapshot: None
    service._latest_snapshot = lambda _sttm_id: {**previous, "snapshot_id": "snap-1", "context_hash": "old"}
    service._memory = SimpleNamespace(
        ensure_storage_exists=lambda: None,
        save_workspace_snapshot=lambda **_kwargs: "snap-2",
    )
    service._update_sttm_draft_payload = lambda **kwargs: calls["draft"].append(kwargs)
    service._replace_sources = lambda *args, **kwargs: calls["sources"].append(args) or 1
    service._replace_mapping_rows = lambda **kwargs: calls["rows"].append(kwargs) or 1
    service._run_postsave_projections = lambda **_kwargs: (0, 0)
    return service, calls


def test_reopening_a_completed_mapping_keeps_its_status() -> None:
    service, calls = _autosave_service(_snapshot())

    response = service.autosave_sttm(
        "42",
        STTMAutosaveRequest(
            workspace_snapshot=_snapshot(page="mapping", conversation_history=[], mapping_lifecycle="update"),
        ),
        user_id="u1",
    )

    assert response.snapshot_id == "snap-2"
    assert response.has_unpublished_draft is False
    assert calls["draft"] and calls["draft"][0]["preserve_status"] is True
    assert calls["sources"] == []
    assert calls["rows"] == []


def test_real_edit_still_marks_the_mapping_in_progress() -> None:
    service, calls = _autosave_service(_snapshot())
    edited = _snapshot()
    edited["mapping_rows"] = [{**edited["mapping_rows"][0], "expression": "UPPER(cte_final.id)"}]

    response = service.autosave_sttm(
        "42",
        STTMAutosaveRequest(workspace_snapshot=edited),
        user_id="u1",
    )

    assert response.has_unpublished_draft is True
    assert calls["draft"] and not calls["draft"][0].get("preserve_status", False)
    assert len(calls["sources"]) == 1


@pytest.mark.parametrize("mode, expression", [("attribute", None), ("source", "cte_final.id || $MISSING")])
def test_actual_autosave_missing_value_is_a_durable_manual_draft_not_learning(mode, expression):
    service, calls = _autosave_service(_snapshot(), has_unpublished_draft=True)
    service.list_project_attributes = Mock(return_value=[])
    service.create_project_attribute = Mock(side_effect=AssertionError("no implicit Values"))
    saved = {}
    service._memory.save_workspace_snapshot = lambda **kwargs: saved.update(kwargs["snapshot_payload"]) or "snap-2"
    edited = _snapshot()
    edited["mapping_rows"][0].update(mapping_mode=mode, attribute_name="MISSING", expression=expression,
        manually_saved=True, manually_edited_after_auto_map=True, accepted=True,
        confidence_reason="Original model explanation", confidence=.49,
        validation={"result": "valid"}, ai_candidates=[{"candidate_id": "c", "original_confidence_score": .95,
        "adjusted_confidence_score": .49, "scoring_issues": [{"code": "value", "message": "Missing Value"}]}])
    result = service.autosave_sttm("42", STTMAutosaveRequest(workspace_snapshot=edited), user_id="u")
    row = saved["mapping_rows"][0]
    assert row["status"] == "MAPPED" and row["validation"] is None and row["accepted"] is False
    assert row["manually_saved"] and row["manually_edited_after_auto_map"]
    assert row["confidence_reason"] == "Original model explanation" and row["confidence"] == .49
    assert row["expression"] == expression and row["ai_candidates"] == edited["mapping_rows"][0]["ai_candidates"]
    assert row["draft_issues"][0]["code"] == "missing_project_value"
    assert calls["rows"][0]["snapshot"]["mapping_rows"] == saved["mapping_rows"]
    assert result.post_save_job_id is None and result.recorded_fir_event_count == 0
    service._async_jobs.enqueue.assert_not_called()
    service.create_project_attribute.assert_not_called()
    assert service._session.sql.call_args_list[-1].args[0] == "COMMIT"
    service._latest_snapshot = lambda _: {**saved, "snapshot_id": "snap-2"}
    service._async_jobs.for_snapshot.return_value = None
    retry = service.autosave_sttm("42", STTMAutosaveRequest(workspace_snapshot=saved), user_id="u")
    assert retry.snapshot_id == "snap-2" and len(calls["rows"]) == 1
    assert len(saved["mapping_rows"][0]["draft_issues"]) == 1
    from app.core.exceptions import AppValidationError
    with pytest.raises(AppValidationError):
        ProjectService._validate_project_value_bindings(service, "p1", saved)


def test_value_lookup_failure_rolls_back_autosave_instead_of_claiming_an_empty_roster():
    service, calls = _autosave_service(_snapshot())
    service.list_project_attributes = Mock(side_effect=RuntimeError("roster unavailable"))
    edited = _snapshot()
    edited["mapping_rows"][0].update(mapping_mode="attribute", attribute_name="FIRM")
    with pytest.raises(RuntimeError, match="roster unavailable"):
        service.autosave_sttm("42", STTMAutosaveRequest(workspace_snapshot=edited), user_id="u")
    assert calls["rows"] == [] and service._session.sql.call_args_list[-1].args[0] == "ROLLBACK"


@pytest.mark.parametrize("value", [False, 0, ""])
def test_value_issue_reconciliation_does_not_promote_or_erase_original_evidence(value):
    service = ProjectService.__new__(ProjectService)
    service.list_project_attributes = Mock(return_value=[SimpleNamespace(attribute_name="FIRM", attribute_value=value)])
    snapshot = {"mapping_rows": [{"mapping_mode": "attribute", "attribute_name": "FIRM", "status": "NEEDS_VALIDATION",
        "confidence": .49, "confidence_reason": "Original", "validation": None,
        "draft_issues": [{"source": "draft_value_check", "code": "missing_project_value"},
                         {"source": "manual", "code": "review"}]}]}
    service._annotate_draft_value_issues("p1", snapshot)
    service._validate_project_value_bindings("p1", snapshot)
    row = snapshot["mapping_rows"][0]
    assert row["draft_issues"] == [{"source": "manual", "code": "review"}]
    assert row["status"] == "MAPPED" and row["validation"] is None
    assert row["confidence"] == .49 and row["confidence_reason"] == "Original"


def test_missing_value_annotation_preserves_failed_validation_and_exact_reason():
    service = ProjectService.__new__(ProjectService)
    service.list_project_attributes = lambda _: []
    failed = {"result": "failed", "definitionSignature": "row", "contextSignature": "context", "error": "SQL incomplete"}
    snapshot = {"mapping_rows": [{"mapping_mode": "source", "expression": "$MISSING +",
        "validation": failed.copy(), "status": "VALIDATION_FAILED", "confidence_reason": "Original"}]}
    service._annotate_draft_value_issues("p1", snapshot)
    row = snapshot["mapping_rows"][0]
    assert row["validation"] == failed and row["status"] == "MAPPED"
    assert row["confidence_reason"] == "Original" and row["expression"] == "$MISSING +"


def test_candidate_only_draft_change_refreshes_normalized_recovery_without_learning():
    previous = _snapshot()
    previous["mapping_rows"][0]["status"] = "NEEDS_VALIDATION"
    service, calls = _autosave_service(previous, has_unpublished_draft=True)
    edited = _snapshot()
    edited["mapping_rows"][0].update(status="NEEDS_VALIDATION", ai_candidates=[{"candidate_id": "new", "original_confidence_score": None}])
    result = service.autosave_sttm("42", STTMAutosaveRequest(workspace_snapshot=edited), user_id="u")
    assert len(calls["rows"]) == 1 and calls["draft"][0]["preserve_status"] is True
    assert result.post_save_job_id is None
    service._async_jobs.enqueue.assert_not_called()


@pytest.mark.parametrize('definition, mapped', [
    ({'source_columns': ['missing.COLUMN']}, True), ({'expression': 'BROKEN('}, True),
    ({'natural_language_rule': 'Use the household business name'}, True),
    ({'mapping_mode': 'attribute', 'attribute_name': 'MissingFirm'}, True),
    *[({'mapping_mode': 'constant', 'constant_value': value}, True) for value in [False, 0, '']],
    ({'mapping_mode': 'constant', 'constant_value': None}, False), ({'mapping_mode': 'attribute'}, False),
    ({'rule': 'Direct'}, False), ({'rule': 'Custom'}, False), ({'source_columns': [' ']}, False),
    ({'candidate_source_attributes': ['src.NAME']}, False),
])
def test_backend_completeness_does_not_create_validation_or_acceptance(definition, mapped):
    service = ProjectService.__new__(ProjectService)
    service.list_project_attributes = lambda _: []
    snapshot = {'mapping_rows': [{**definition, 'status': 'VALIDATION_FAILED'}]}
    for _ in range(3):
        service._annotate_draft_value_issues('p1', snapshot)
        row = snapshot['mapping_rows'][0]
        assert row['status'] == ('MAPPED' if mapped else 'UNMAPPED')
        assert row.get('validation') is None and not row.get('accepted')


def test_actual_autosave_preserves_66_mapped_definitions_without_validation_receipts():
    rows = [{'id': f'upload:{index}', 'target_column': f'FIELD_{index}', 'source_columns': [f'cte_final.FIELD_{index}'],
             'rule': 'Direct', 'status': 'NEEDS_VALIDATION', 'validation': None} for index in range(66)]
    original = _snapshot(mapping_rows=rows)
    service, calls = _autosave_service(_snapshot(), has_unpublished_draft=True)
    saved = {}
    service._memory.save_workspace_snapshot = lambda **kwargs: saved.update(kwargs['snapshot_payload']) or 'saved-66'
    result = service.autosave_sttm('42', STTMAutosaveRequest(workspace_snapshot=original), user_id='u')
    assert len(saved['mapping_rows']) == 66
    assert all(row['status'] == 'MAPPED' and row.get('validation') is None and not row.get('accepted') for row in saved['mapping_rows'])
    assert saved['raw_mapping_sql'] == original['raw_mapping_sql']
    assert calls['rows'][0]['snapshot']['mapping_rows'] == saved['mapping_rows']
    assert result.recorded_fir_event_count == 0 and result.post_save_job_id is None


def _accepted_snapshot():
    snapshot = _snapshot(raw_mapping_sql="SELECT 2")
    snapshot["mapping_rows"][0].update(manually_saved=True, expression="TRIM(cte_final.id)")
    return snapshot


def test_draft_only_edit_persists_without_feedback_or_learning_job():
    service, calls = _autosave_service(_snapshot())
    result = service.autosave_sttm("42", STTMAutosaveRequest(
        workspace_snapshot=_snapshot(raw_mapping_sql="SELECT 2")), user_id="u")
    assert result.snapshot_id == "snap-2"
    assert calls["rows"]
    assert result.post_save_job_id is None
    service._async_jobs.enqueue.assert_not_called()


def test_autosave_snapshot_rows_and_learning_capture_commit_together():
    service, _ = _autosave_service(_snapshot())
    sequence = []
    service._session.sql.side_effect = lambda sql, **kwargs: (
        sequence.append(sql) or SimpleNamespace(collect=lambda: [{"number_of_rows_updated": 1}])
    )
    service._memory.save_workspace_snapshot = lambda **kwargs: sequence.append("SNAPSHOT") or "snap-2"
    service._replace_sources = lambda *args, **kwargs: sequence.append("SOURCES") or 1
    service._replace_mapping_rows = lambda **kwargs: sequence.append("ROWS") or 1
    service._update_sttm_draft_payload = lambda **kwargs: sequence.append("HEADER")
    service._async_jobs.enqueue.side_effect = lambda **kwargs: sequence.append("OUTBOX") or ("job", "queued")
    result = service.autosave_sttm("42", STTMAutosaveRequest(
        workspace_snapshot=_accepted_snapshot()), user_id="u")
    assert sequence[0] == "BEGIN TRANSACTION"
    assert sequence[-1] == "COMMIT"
    assert sequence[2:-1] == ["SNAPSHOT", "SOURCES", "ROWS", "HEADER", "OUTBOX"]
    assert result.post_save_job_id == "job"


def test_autosave_outbox_failure_rolls_back_instead_of_leaving_saved_draft():
    service, _ = _autosave_service(_snapshot())
    service._async_jobs.enqueue.side_effect = RuntimeError("outbox unavailable")
    with pytest.raises(RuntimeError, match="outbox unavailable"):
        service.autosave_sttm("42", STTMAutosaveRequest(
            workspace_snapshot=_accepted_snapshot()), user_id="u")
    statements = [call.args[0] for call in service._session.sql.call_args_list]
    assert statements[-1] == "ROLLBACK"
    assert "COMMIT" not in statements


def test_deferred_autosave_acknowledges_commit_without_running_projections():
    service, _ = _autosave_service(_snapshot())
    service._settings.autosave_postsave_async_v1 = False
    service.process_postsave_jobs = Mock(side_effect=AssertionError("must run after response"))
    result = service.autosave_sttm(
        "42", STTMAutosaveRequest(workspace_snapshot=_accepted_snapshot()),
        user_id="u", defer_postsave=True,
    )
    assert result.post_save_job_id == "job"
    assert result.post_save_job_status == "queued"
    assert service._session.sql.call_args_list[-1].args[0] == "COMMIT"
    service._async_jobs.enqueue.assert_called_once()
    service.process_postsave_jobs.assert_not_called()


def test_non_http_autosave_preserves_synchronous_projection_behavior():
    service, _ = _autosave_service(_snapshot())
    service._settings.autosave_postsave_async_v1 = False
    service.process_postsave_jobs = Mock()
    service._async_jobs.for_snapshot.return_value = {"STATUS": "completed"}
    result = service.autosave_sttm(
        "42", STTMAutosaveRequest(workspace_snapshot=_accepted_snapshot()),
        user_id="u",
    )
    service.process_postsave_jobs.assert_called_once_with(
        worker_id="autosave:42", sttm_id="42", snapshot_id="snap-2", max_jobs=1,
    )
    assert result.post_save_job_status == "completed"


def test_unchanged_retry_returns_existing_projection_job_for_recovery():
    service, calls = _autosave_service(_snapshot())
    edited = _snapshot(raw_mapping_sql="SELECT 2")
    request = STTMAutosaveRequest(workspace_snapshot=edited)
    saved = {}
    service._memory.save_workspace_snapshot = lambda **kwargs: saved.update(kwargs["snapshot_payload"]) or "snap-2"
    service.autosave_sttm("42", request, user_id="u")
    service._latest_snapshot = lambda _: {**saved, "snapshot_id": "snap-2"}
    service._async_jobs.for_snapshot.return_value = {"JOB_ID": "job", "STATUS": "queued"}
    retry = service.autosave_sttm("42", request, user_id="u")
    assert retry.post_save_job_id == "job"
    assert retry.post_save_job_status == "queued"
    assert len(calls["rows"]) == 1


def test_publish_autosave_is_never_treated_as_unchanged() -> None:
    service, calls = _autosave_service(_snapshot())

    service.autosave_sttm(
        "42",
        STTMAutosaveRequest(workspace_snapshot=_snapshot(), action="sttm.publish_autosave"),
        user_id="u1",
    )

    assert not calls["draft"][0].get("preserve_status", False)
    assert len(calls["sources"]) == 1


class _Query:
    def collect(self):
        return []


class _Session:
    def __init__(self) -> None:
        self.calls: list[tuple[str, Any]] = []

    def sql(self, query: str, params: Any = None) -> _Query:
        self.calls.append((query, params))
        return _Query()


def _source_service() -> tuple[ProjectService, _Session]:
    session = _Session()
    service = ProjectService.__new__(ProjectService)
    service._session = session
    service._settings = SimpleNamespace(
        sttm_source_bulk_write_v1=True,
        snowflake_sttm_sources_table="DB.META.TBL_STTM_SOURCES",
        qualify_metadata_object_name=lambda value: value,
    )
    service._table_columns = lambda _table: {
        "STTM_ID", "SOURCE_NAME", "DATABASE_NAME", "SCHEMA_NAME", "TABLE_NAME",
        "DESCRIPTION", "IS_DRAFT", "LAST_MODIFIED_BY",
    }
    service._column_type = lambda _table, _column: "VARCHAR"
    return service, session


def test_sources_fall_back_to_derived_inputs_instead_of_being_erased() -> None:
    service, session = _source_service()

    service._replace_sources(
        "42",
        {
            "source_tables": [],
            "derived_sources": [
                {
                    "id": "sql-cte:abc:final",
                    "name": "final",
                    "base_source_tables": [{"database": "DB", "schema": "RAW", "table": "ACCOUNTS"}],
                    "table_ids": ["DB.RAW.OWNERS", "accounts"],
                }
            ],
        },
        user_id="u1",
    )

    persisted = json.loads(session.calls[-1][1][0])
    physical = [row for row in persisted if not row["description"].startswith("DERIVED_SOURCE:")]
    assert [row["description"] for row in physical] == ["DB.RAW.ACCOUNTS", "DB.RAW.OWNERS"]


def test_incomplete_source_refs_are_never_written_as_blank_rows() -> None:
    service, session = _source_service()

    service._replace_sources(
        "42",
        {
            "source_tables": [
                {"database": "DB", "schema": "RAW", "table": "ACCOUNTS"},
                {"database": "", "schema": "", "table": "OWNERS"},
            ],
            "derived_sources": [],
        },
        user_id="u1",
    )

    persisted = json.loads(session.calls[-1][1][0])
    assert [row["table_name"] for row in persisted] == ["ACCOUNTS"]


def test_deep_draft_artifacts_enqueue_without_becoming_learning():
    service, _ = _autosave_service(_snapshot())
    result = service.autosave_sttm('42', STTMAutosaveRequest(
        workspace_snapshot=_snapshot(raw_mapping_sql='SELECT 2'), action='migration_agent.draft_saved',
        agent_artifacts=[{'type': 'specialist_decision', 'source_decisions': [{'target_column': 'ID'}]}]), user_id='u')
    assert result.post_save_job_id == 'job'
    service._async_jobs.enqueue.assert_called_once()
    service._record_agent_artifacts = Mock(return_value=1)
    service._record_autosave_fir_events = Mock(side_effect=AssertionError('Generated drafts must not become feedback'))
    payload = service._async_jobs.enqueue.call_args.kwargs['payload']
    assert ProjectService._run_postsave_projections(service, project_id='9', sttm_id='42', projection_payload=payload) == (1, 0)
    service._record_agent_artifacts.assert_called_once()
    service._record_autosave_fir_events.assert_not_called()
