-- ============================================================
-- One-time deprecation of unused metadata objects (2.9.6)
--
-- Every object below is empty or unread: no reads or writes in the 90 days of
-- ACCOUNT_USAGE.ACCESS_HISTORY checked on 2026-10-13, and no reference in the
-- application, procedures, tasks, views or agent specs. The bootstrap no longer
-- creates them (create-table-ddl.sql, fir_v2_linking_schema.sql,
-- fir_search_services.sql). Run once per existing environment, after approval.
--
-- Kept on purpose: SV_PIPELINE_LOG and SEM_DATABASE_REGISTRY (read by the
-- semantic v2 pipeline), SEM_SCHEMA_VIEWS (semantic v2 pipeline owned),
-- TBL_FIR_INFERENCE_EVIDENCE (written by SP_FIR_STORE_INFERENCE).
--
-- Tables keep Time Travel, so a drop can be reverted with UNDROP TABLE.
-- ============================================================

DROP VIEW IF EXISTS __STTM_METADATA_NAMESPACE__.VW_FIR_ACTIVE_PROJECT_LINKS;
DROP VIEW IF EXISTS __STTM_METADATA_NAMESPACE__.VW_FIR_ACTIVE_MAPPING_LINKS;
DROP VIEW IF EXISTS __STTM_METADATA_NAMESPACE__.VW_FIR_INFERENCES_SEARCH;
DROP VIEW IF EXISTS __STTM_METADATA_NAMESPACE__.VW_FIR_RECOMMENDATIONS_SEARCH;
DROP VIEW IF EXISTS __STTM_METADATA_NAMESPACE__.VW_FIR_SEMANTIC_VERSIONS_SEARCH;

-- Children before parents (TBL_DBT_VERSIONS/FILES reference TBL_DBT_CONVERSION).
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_DBT_FILES;
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_DBT_VERSIONS;
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_DBT_CONVERSION;
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_CONVERSATIONS;
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_TABLE_STATS;
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_ATTRIBUTE_STATS;
DROP TABLE IF EXISTS __STTM_METADATA_NAMESPACE__.TBL_SEMANTIC_OVERRIDES;
