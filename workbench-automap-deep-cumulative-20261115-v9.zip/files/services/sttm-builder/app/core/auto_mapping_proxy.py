import json
import hashlib
import logging
import math
import re
import threading
import time
import uuid
from collections.abc import Callable, Iterator
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError, as_completed
from datetime import UTC, datetime
from typing import Any

import httpx
from fastapi import HTTPException, Request

from app.auth.models import AppPersona
from app.core.agent_payload_budget import AgentPayloadBudgetError, budget_agent_payload
from app.core.automap_batch import FAST_INTEGRATION_VERSION, fast_project_enabled
from app.core.automap_row_candidates import SCORING_POLICY_VERSION, SCORING_META_KEY
from app.core.automap_stored_json import store_json
from app.core.config import Settings
from app.core.exceptions import ContextPrecedentUnavailableError, SnowflakeAgentError
from app.core.snowflake import SnowflakeClient, get_local_transaction_pool
from app.core.warehouse_routing import WarehouseWorkload
from app.schema.contracts import ApiWarning
from app.schema.common import AttributeRef, TableRef
from app.schema.sttm_builder import (
    AttributeMapping,
    Interface,
    SourceMappingResult,
    STTMBuilderEnvelopeRequest,
    STTMBuilderResponse,
    STTMStatus,
    STTMOperation,
    SubAgent,
    TransformationResult,
)

logger = logging.getLogger(__name__)

_AUTO_MAP_JOBS: dict[str, dict[str, Any]] = {}
_AUTO_MAP_JOBS_LOCK = threading.Lock()
_AUTO_MAP_ACTIVE_RUNNERS: set[str] = set()
_AUTO_MAP_ACCEPT_LOCKS: dict[str, Any] = {}
_AUTO_MAP_TENANT_SEMAPHORES_LOCK = threading.Lock()
_AUTO_MAP_TENANT_SEMAPHORES: dict[str, threading.BoundedSemaphore] = {}
_AUTO_MAP_JOB_TTL_SECONDS = 60 * 60
_AUTO_MAP_LEASE_SECONDS = 210
_MIN_CONTEXT_PRESERVING_BATCH = 4
_RESOLUTION_PLAN_KEY = "_automap_resolution_plan"
_RESOLUTION_VERSION = FAST_INTEGRATION_VERSION
_RESOLUTION_DEADLINE_SECONDS = 180.0
_PREFLIGHT_VERSION = "fast-target-preflight-v7-frozen-packets"
_PREFLIGHT_BUDGET_CODE = "AUTO_MAP_PREFLIGHT_BUDGET_EXCEEDED"
_PREFLIGHT_DEADLINE_CODE = "AUTO_MAP_PREFLIGHT_DEADLINE_EXCEEDED"


class _BackendResolutionPlan(dict):
    """In-process trust marker; JSON from a caller never acquires this type."""


class _BackendAcceptance(dict):
    """Server-stamped acceptance clock retained across preparation and storage."""


class _AutoMapPersistenceError(SnowflakeAgentError):
    pass

_FORWARDED_HEADER_NAMES = (
    "Sf-Context-Current-User",
    "Sf-Context-Current-User-Email",
    "Sf-Context-Current-User-Token",
    "X-Request-Id",
    "X-Trace-Id",
)
_OAUTH_FORWARDED_HEADER_NAMES = (
    "X-Workbench-OAuth-Access-Token",
    "X-Workbench-OAuth-User",
    "X-Workbench-OAuth-Email",
    "X-Workbench-OAuth-Role",
)


class _DelegatedHeaders(dict[str, str]):
    """Keep the verified browser session reference on the host, never on the wire."""

    def __init__(self, *args, session_id: str | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.session_id = session_id
        self.refresh_lock = threading.Lock()


class AutoMappingTransportTooLargeError(AgentPayloadBudgetError):
    """The shared worker envelope, not the target-specific model prompt, is too large."""


class AutoMappingProxyClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._base_url = settings.resolved_auto_mapping_service_url.rstrip("/")
        self._timeout = settings.auto_mapping_service_timeout_seconds
        self._retry_attempts = max(1, settings.auto_mapping_service_retry_attempts)
        self._batch_size = max(1, settings.auto_mapping_proxy_batch_size)
        self._max_in_flight = max(1, settings.auto_mapping_proxy_max_in_flight)
        if settings.automap_fast_path_v1:
            self._max_in_flight = settings.automap_fast_max_in_flight

    def _batch_identity(self, req, attributes):
        from app.core.automap_retrieval import digest, STRATEGY_VERSION
        from app.core.automap_policy import POLICY_VERSION
        identity = {
            "scoring_policy_version": req.meta.get(SCORING_META_KEY),
            "strategy_version": STRATEGY_VERSION,
            "policy_version": POLICY_VERSION,
            "batch_count": self._settings.automap_context_batch_count,
            "context_hash": digest(req.context.model_dump(mode="json", exclude_none=True)),
            "decision_hash": digest({"data": req.data.model_dump(mode="json", exclude_none=True),
                                     "actor": req.actor.model_dump(mode="json") if req.actor else None}),
            "target_attributes": [item.target_attribute for item in attributes],
        }
        plan = self._trusted_resolution_plan(req)
        if plan:
            identity.update(resolution_version=plan["version"], baseline_hash=plan["baseline_hash"],
                            partition_hash=plan["partition_hash"], decision_hash=plan["input_hash"],
                            acceptance_deadline=plan["deadline_at"], handoff_hash=plan.get("handoff_hash"),
                            worker_variant=req.meta.get("auto_map_fast_path"),
                            batch_partition_hash=self._resolution_digest([
                                item.model_dump(mode="json") for item in attributes]))
        return identity

    @staticmethod
    def _resolution_digest(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                         ensure_ascii=False).encode("utf-8")).hexdigest()

    @staticmethod
    def _without_resolution_meta(meta):
        return {key: value for key, value in meta.items() if key not in {
            _RESOLUTION_PLAN_KEY, "_automap_frozen_packet", "_automap_packet_ref", "_automap_deadline", "auto_map_deadline_at", "automap_preserved_targets",
            "auto_mapping_review", "automap_baseline_preservation", "automap_resolution",
            "auto_map_parent_resolution_version", "auto_map_fast_path", "_automap_acceptance",
            "_automap_call_tracking", "_automap_fast_handoff", "auto_map_prepared_readonly", "automap_generation_policy", "automap_rules_policy",
        }}

    def _accept_resolution(self, req):
        if req.meta.get("auto_map_resolution_mode") is None and any(
                req.meta.get(key) is not None for key in ("auto_map_target_scope", "auto_map_reevaluate_targets")):
            raise HTTPException(status_code=422, detail="Explicit target scope requires an Auto-map resolution mode")
        acceptance = req.meta.get("_automap_acceptance")
        meta = self._without_resolution_meta(req.meta)
        if getattr(self._settings,'automap_durable_runs_v2',False):
            meta['_automap_execution_protocol']='background_v2'
            meta['_automap_call_tracking']='pooled_v2' if getattr(self._settings,'automap_shared_capacity_limit',True) else 'operation_v3'
        meta[SCORING_META_KEY] = SCORING_POLICY_VERSION
        meta.pop("automap_draft_validation", None)
        if not fast_project_enabled(self._settings, req.context.project_id):
            if meta.get("auto_map_target_scope") is not None or meta.get("auto_map_resolution_mode") in {"reeval_selected", "reeval_all"}:
                raise HTTPException(status_code=422, detail="Selected-target completion and reevaluation are not enabled for this project")
            meta.pop("auto_map_resolution_mode", None)
            meta.pop("auto_map_reevaluate_targets", None)
        elif meta.get("auto_map_resolution_mode") is not None:
            self._resolution_mode(req)
            if not isinstance(acceptance, _BackendAcceptance):
                accepted_at = time.time()
                acceptance = _BackendAcceptance(version=_RESOLUTION_VERSION, scoring_policy_version=SCORING_POLICY_VERSION, accepted_at=accepted_at,
                    budget_seconds=self._settings.automap_fast_job_seconds,
                    deadline_at=accepted_at + self._settings.automap_fast_job_seconds)
            meta.update(auto_map_fast_path="v1", _automap_acceptance=acceptance)
            # New fast runs use the draft policy; legacy/frozen protocols stay intact.
            meta['automap_generation_policy'] = 'draft-v3'
            meta['automap_rules_policy'] = 'rules-v2'
        # A new fast request need not carry a UI-specific resolution mode to
        # receive the current draft protocol. Frozen jobs are never reaccepted.
        if fast_project_enabled(self._settings, req.context.project_id):
            meta['automap_generation_policy'] = 'draft-v3'
            meta['automap_rules_policy'] = 'rules-v2'
            if not isinstance(req.meta.get('_automap_acceptance'), _BackendAcceptance):
                meta['automap_packet_policy'] = 'frozen-packets-v1'
        return req.model_copy(update={"meta": meta})

    @staticmethod
    def _resolution_mode(req):
        mode = req.meta.get("auto_map_resolution_mode")
        if mode is None:
            return None
        if not isinstance(mode, str) or mode not in {"preserve_and_complete", "reeval_selected", "reeval_all"}:
            raise HTTPException(status_code=422, detail="Invalid auto_map_resolution_mode")
        attributes = list(req.data.attributes or [])
        names = [item.target_attribute for item in attributes]
        tables = {item.target_table.qualified_name for item in attributes}
        from app.core.automap_batch import fast_target_identity
        # SourceMappingResult has one flat target namespace. Never collapse tables.
        if not names or len({fast_target_identity(name) for name in names}) != len(names) or len(tables) != 1:
            raise HTTPException(status_code=422, detail="Auto-map resolution requires unique targets in one target table")
        scope = req.meta.get("auto_map_target_scope")
        if scope is not None and (not isinstance(scope, list) or not scope
                or any(not isinstance(name, str) or name not in names for name in scope)
                or len(set(scope)) != len(scope)):
            raise HTTPException(status_code=422, detail="auto_map_target_scope requires unique exact targets from the request")
        choices = req.meta.get("auto_map_reevaluate_targets")
        if mode == "reeval_selected":
            if (not isinstance(choices, list) or not choices
                    or any(not isinstance(choice, str) or choice not in names for choice in choices)
                    or len(set(choices)) != len(choices)):
                raise HTTPException(status_code=422, detail="reeval_selected requires exact auto_map_reevaluate_targets from the request")
        elif choices is not None:
            raise HTTPException(status_code=422, detail="auto_map_reevaluate_targets is only valid with reeval_selected")
        if choices and scope is not None and not set(choices) <= set(scope):
            raise HTTPException(status_code=422, detail="Reevaluation authority must be inside the requested target scope")
        return mode

    def _resolution_inputs(self, req):
        workspace = req.context.workspace_context
        baseline = {
            "mapping_rows": [row.model_dump(mode="json") for row in workspace.mapping_rows] if workspace else [],
            "mapping_sql": workspace.mapping_sql if workspace else None,
            "raw_mapping_sql": workspace.raw_mapping_sql if workspace else None,
            "target_table": workspace.target_table.model_dump(mode="json") if workspace and workspace.target_table else None,
        }
        graph = req.context.relation_graph.model_dump(mode="json") if req.context.relation_graph else None
        return baseline, {"scoring_policy_version": req.meta.get(SCORING_META_KEY), "baseline": baseline, "graph": graph,
            "driving_relation_id": workspace.driving_relation_id if workspace else None,
            "source_tables": [table.model_dump(mode="json") for table in req.context.source_tables or []],
            "target_table": req.context.target_table.model_dump(mode="json") if req.context.target_table else None,
            "driving_table": req.context.driving_table.model_dump(mode="json") if req.context.driving_table else None,
            "project_id": req.context.project_id, "sttm_id": req.context.sttm_id,
            "actor": req.actor.model_dump(mode="json") if req.actor else None,
            "data": req.data.model_dump(mode="json"),
            "worker_variant": req.meta.get("auto_map_fast_path"),
            "mode": self._resolution_mode(req), "selected": req.meta.get("auto_map_reevaluate_targets"),
            "target_scope": req.meta.get("auto_map_target_scope"), "shared_input_revision": req.meta.get("auto_map_shared_input_revision"),
            "workspace_filters": workspace.filters.model_dump(mode="json") if workspace else None}

    def _trusted_resolution_plan(self, req):
        plan = req.meta.get(_RESOLUTION_PLAN_KEY)
        if not isinstance(plan, _BackendResolutionPlan):
            return None
        if not fast_project_enabled(self._settings, req.context.project_id):
            raise SnowflakeAgentError("Frozen fast Auto-map is no longer enabled; start a new job")
        baseline, inputs = self._resolution_inputs(req)
        if (plan.get("version") != _RESOLUTION_VERSION
                or plan.get("scoring_policy_version") != SCORING_POLICY_VERSION
                or req.meta.get(SCORING_META_KEY) != SCORING_POLICY_VERSION
                or plan.get("baseline_hash") != self._resolution_digest(baseline)
                or plan.get("input_hash") != self._resolution_digest(inputs)
                or plan.get("partition_hash") != self._resolution_digest(plan.get("targets"))):
            raise SnowflakeAgentError("Frozen Auto-map resolution does not match this workspace revision; start a new job")
        if (type(plan.get("deadline_at")) not in (int, float) or not math.isfinite(plan["deadline_at"])
                or plan.get("deadline_at") != (req.meta.get("_automap_acceptance") or {}).get("deadline_at")):
            raise SnowflakeAgentError("Frozen Auto-map resolution has no valid deadline")
        if plan.get("handoff") is not None and plan.get("handoff_hash") != self._resolution_digest(plan["handoff"]):
            raise SnowflakeAgentError("Frozen Auto-map prepared handoff changed")
        if "preflight" in plan or "preflight_hash" in plan:
            if (not isinstance(plan.get("preflight"), dict)
                    or plan["preflight"].get("version") not in {_PREFLIGHT_VERSION, "fast-target-preflight-v6-evidence-review-budget"}
                    or plan.get("preflight_hash") != self._resolution_digest(plan["preflight"])):
                raise SnowflakeAgentError("Frozen Auto-map preflight changed; start a new job")
        return plan

    def _freeze_resolution(self, req, *, project_attributes=None):
        if self._trusted_resolution_plan(req):
            return req
        if req.meta.get("auto_map_resolution_mode") is not None:
            from app.core.automap_fast_context import hydrate_authored_cte_graph
            req = hydrate_authored_cte_graph(req)
        req = self._accept_resolution(req)
        meta = req.meta
        mode = self._resolution_mode(req)
        if mode is None:
            return req
        deadline_at = meta["_automap_acceptance"]["deadline_at"]
        from app.core.automap_deterministic import resolve_authored_targets, regeneration_targets
        if req.meta.get('automap_packet_policy') == 'frozen-packets-v1' and mode in {'reeval_all', 'reeval_selected'}:
            resolution = regeneration_targets(req)
            if mode == 'reeval_selected':
                # Compatibility callers may send all rows with a checked subset.
                # Only untouched rows need the historical preservation proof.
                selected = set(req.meta.get('auto_map_reevaluate_targets') or [])
                untouched = [item for item in req.data.attributes if item.target_attribute not in selected]
                if untouched:
                    from dataclasses import replace
                    previous = resolve_authored_targets(req.model_copy(update={'data':req.data.model_copy(update={'attributes':untouched})}),
                        project_attributes=project_attributes if project_attributes is not None else [])
                    by_name = {item.attribute.target_attribute:item for item in previous.targets}
                    resolution = replace(resolution, targets=tuple(by_name.get(item.attribute.target_attribute,item) for item in resolution.targets))
        else:
            resolution = resolve_authored_targets(req, project_attributes=project_attributes if project_attributes is not None else [])
        selected = set(req.meta.get("auto_map_reevaluate_targets") or [])
        scope = set(req.meta.get("auto_map_target_scope") or [item.target_attribute for item in req.data.attributes])
        entries = []
        for target in resolution.targets:
            name = target.attribute.target_attribute
            reevaluate = name in scope and (mode == "reeval_all" or (mode == "reeval_selected" and name in selected))
            # Presence is not validity: unfinished authored text still needs review.
            # Exclude empty UI/legacy labels, not explicit values (including "").
            has_baseline = bool(any(
                any(column.strip() for column in row.source_columns) or (row.expression or "").strip()
                or row.constant_value is not None or (row.attribute_name or "").strip()
                or (row.natural_language_rule or "").strip()
                or (row.rule or "").strip().upper() not in {"", "SELECT...", "DIRECT", "IDENTITY", "VALUE"}
                for row in target.baseline_rows))
            entries.append({
                "target_attribute": name, "target_table": target.attribute.target_table.qualified_name,
                "status": "not_selected" if name not in scope else "pending" if reevaluate else
                    "not_selected" if mode == "reeval_selected" and req.meta.get("auto_map_target_scope") is None and target.status == "pending" else target.status,
                "preserve_baseline": not reevaluate and (has_baseline or target.status == "definition_preserved"),
                "had_baseline": has_baseline, "reevaluate": reevaluate,
                "mapping": target.mapping.model_dump(mode="json") if target.mapping else None,
                "origin": target.origin, "requires_authored_query": target.requires_authored_query,
                "unresolved_values": list(target.unresolved_values),
                "execution_status": target.execution_status,
                "diagnostics": [{"code": note.code, "message": note.message} for note in target.diagnostics],
            })
        baseline, inputs = self._resolution_inputs(req)
        plan = _BackendResolutionPlan(version=_RESOLUTION_VERSION, scoring_policy_version=SCORING_POLICY_VERSION, mode=mode, targets=entries,
            baseline_hash=self._resolution_digest(baseline), input_hash=self._resolution_digest(inputs),
            partition_hash=self._resolution_digest(entries), deadline_at=deadline_at)
        from app.core.automap_prepared_evidence import trusted
        artifact = trusted(req)
        if artifact is not None:
            from app.core.automap_stored_json import store_json
            plan["prepared_automap"] = store_json(artifact)
        return req.model_copy(update={"meta": {**meta, _RESOLUTION_PLAN_KEY: plan}})

    def _restore_resolution(self, req):
        """Only called for the envelope loaded from owner-scoped durable storage."""
        req = self._restore_acceptance(req)
        if req.meta.get("auto_map_resolution_mode") is None:
            return req if _RESOLUTION_PLAN_KEY not in req.meta else req.model_copy(update={"meta": self._without_resolution_meta(req.meta)})
        raw = req.meta.get(_RESOLUTION_PLAN_KEY)
        if raw is None:
            if req.meta.get("auto_map_resolution_mode") is not None:
                raise SnowflakeAgentError("Durable Auto-map resolution is missing; start a new job")
            return req
        if not isinstance(raw, dict):
            raise SnowflakeAgentError("Invalid durable Auto-map resolution")
        req = req.model_copy(update={"meta": {**req.meta, _RESOLUTION_PLAN_KEY: _BackendResolutionPlan(deepcopy(raw))}})
        self._trusted_resolution_plan(req)
        return req

    @staticmethod
    def _restore_acceptance(req):
        if req.meta.get(SCORING_META_KEY) != SCORING_POLICY_VERSION:
            raise SnowflakeAgentError("Historical Auto-map policy cannot be resumed; start a new job")
        if req.meta.get("auto_map_resolution_mode") is None:
            return req
        acceptance = req.meta.get("_automap_acceptance")
        if (not isinstance(acceptance, dict) or acceptance.get("version") != _RESOLUTION_VERSION
                or acceptance.get("scoring_policy_version") != SCORING_POLICY_VERSION
                or type(acceptance.get("accepted_at")) not in (int, float)
                or type(acceptance.get("deadline_at")) not in (int, float)
                or not math.isfinite(acceptance["accepted_at"])
                or type(acceptance.get("budget_seconds", _RESOLUTION_DEADLINE_SECONDS)) not in (int, float)
                or not 60 <= acceptance.get("budget_seconds", _RESOLUTION_DEADLINE_SECONDS) <= 600
                or acceptance["deadline_at"] != acceptance["accepted_at"] + acceptance.get("budget_seconds", _RESOLUTION_DEADLINE_SECONDS)):
            raise SnowflakeAgentError("Durable Auto-map acceptance clock is invalid; start a new job")
        return req.model_copy(update={"meta": {**req.meta, "_automap_acceptance": _BackendAcceptance(acceptance)}})

    def _pending_resolution_request(self, req):
        plan = self._trusted_resolution_plan(req)
        if not plan:
            return req
        pending = {entry["target_attribute"] for entry in plan["targets"] if entry["status"] == "pending"}
        if plan.get("prepared_automap"):
            from app.core.automap_prepared_evidence import TrustedPreparedAutoMap
            req.context._prepared_automap = TrustedPreparedAutoMap(plan["prepared_automap"])
        meta = self._without_resolution_meta(req.meta)
        meta.pop("auto_map_resolution_mode", None)
        meta.pop("auto_map_reevaluate_targets", None)
        pending_req = req.model_copy(update={
            "data": req.data.model_copy(update={"attributes": [item for item in req.data.attributes or [] if item.target_attribute in pending]}),
            "context": req.context.model_copy(update={"replay_exact_precedent": False}),
            "meta": {**meta, **{key: req.meta[key] for key in ("automap_generation_policy", "automap_rules_policy", "_automap_call_tracking") if key in req.meta}, "_automap_deadline": plan["deadline_at"],
                     "auto_map_deadline_at": datetime.fromtimestamp(plan["deadline_at"], UTC).isoformat(),
                     "auto_map_parent_resolution_version": plan["version"], "auto_map_fast_path": "v1",
                     "auto_map_prepared_readonly": True, "_automap_fast_handoff": deepcopy(plan.get("handoff"))},
        })
        if not pending_req.data.attributes:
            return pending_req
        from app.core.automap_batch import canonical_model_wire_request, validate_fast_request
        from app.core.sttm_builder import STTMBuilderService
        pending_req = canonical_model_wire_request(STTMBuilderService._with_intent_route(pending_req))
        if plan.get("handoff"):
            pending_req.context.prepared_context_hash = plan["handoff"]["prepared_context_hash"]
            validate_fast_request(pending_req, self._settings)
        return pending_req

    def _complete_resolution_response(self, req, response=None):
        plan = self._trusted_resolution_plan(req)
        assert plan is not None
        result = response.result if response else None
        worker_mappings = result.mappings if isinstance(result, SourceMappingResult) else {}
        mappings = {}
        preserved = []
        resolved = []
        blocked = []
        proposed = {}
        diagnostics = []
        for entry in plan["targets"]:
            target = entry["target_attribute"]
            if entry["preserve_baseline"]:
                preserved.append(target)
            if entry["status"] == "definition_preserved":
                resolved.append(target)
                if entry["unresolved_values"]:
                    blocked.append(target)
                # Reference-only: the scalar cannot represent full-query population,
                # CTEs, or exact frontend rows. The baseline remains the definition.
                mappings[target] = AttributeMapping(source_attributes=[], confidence_score=0.0,
                    transformation_classification="unresolved" if target in blocked else "reused",
                    confidence_reason="Current definition retained, not a new mapping or execution approval.",
                    unmatched_reason="Bind required project Values before execution." if target in blocked else None,
                    description="See context.workspace_context and meta.automap_baseline_preservation.")
            else:
                mapping = worker_mappings.get(target) or worker_mappings.get(f"{entry['target_table']}.{target}")
                mapping = mapping or AttributeMapping(source_attributes=[], confidence_score=0.0,
                    transformation_classification="unresolved", unmatched_reason="No validated worker mapping was returned for this target.")
                mappings[target] = mapping
                proposed[target] = mapping
            diagnostics.append({key: entry[key] for key in (
                "target_attribute", "origin", "status", "reevaluate", "had_baseline", "unresolved_values", "execution_status", "requires_authored_query", "diagnostics")})
        _, review = self._build_mapping_review(proposed)
        review_only=set(response.meta.get("automap_evidence_review_only_targets",[])) & set(proposed) if response else set()
        for target in sorted(review_only):
            if proposed[target].transformation_classification=="unresolved":continue
            review["unresolved_count"]+=1;review["action_required_count"]+=1
            review["recommendations"].append({"target_attribute":target,"category":"semantic_support_review",
                "severity":"action_required","title":"Review uncertain semantic support before applying",
                "detail":proposed[target].confidence_reason or "The bindings compile but require business review.",
                "recommended_action":"Compare verified alternatives and explicitly accept the proposal.",
                "candidate_sources":proposed[target].candidate_source_attributes,"evidence_ids":[]})
        new_count = sum(1 for entry in plan["targets"] if entry["target_attribute"] in proposed
                        and not entry["had_baseline"] and entry["target_attribute"] not in review_only and self._build_mapping_review({entry["target_attribute"]: proposed[entry["target_attribute"]]})[1]["mapped_count"])
        proposed_count = review["mapped_count"]
        review.update(total_count=len(mappings), preserved_count=len(resolved), newly_mapped_count=new_count,
                      mapped_count=new_count, proposed_count=proposed_count, execution_blocked_count=len(blocked),
                      unresolved_count=review["unresolved_count"] + len(blocked),
                      action_required_count=review["action_required_count"] + len(blocked))
        review["baseline_retained_count"] = len(preserved)
        new_targets = {entry["target_attribute"] for entry in plan["targets"] if not entry["had_baseline"]}
        reviewed_new = {item["target_attribute"] for item in review["recommendations"]
                        if item["severity"] == "review" and item["target_attribute"] in new_targets}
        review["mapped_with_review_count"] = len(reviewed_new)
        review["completed_without_review_count"] = max(0, new_count - len(reviewed_new))
        retained_proposals = [entry["target_attribute"] for entry in plan["targets"]
            if entry["status"] == "pending" and entry["preserve_baseline"]
            and entry["target_attribute"] in proposed
            and self._build_mapping_review({entry["target_attribute"]: proposed[entry["target_attribute"]]})[1]["mapped_count"]]
        review["unresolved_count"] += len(retained_proposals)
        review["action_required_count"] += len(retained_proposals)
        for target in retained_proposals:
            review["recommendations"].append({"target_attribute": target, "category": "baseline_proposal",
                "severity": "action_required", "title": "Review the proposal without replacing the current definition",
                "detail": "The current definition could not be proven. A worker proposal is available, but has not been applied.",
                "recommended_action": "Review the retained definition and explicitly accept or reject the proposed change.",
                "candidate_sources": proposed[target].source_attributes, "evidence_ids": []})
        for target in blocked:
            review["recommendations"].append({"target_attribute": target, "category": "unbound_values",
                "severity": "action_required", "title": "Bind project Values before execution",
                "detail": "The authored definition is retained unchanged; no Value was invented.",
                "recommended_action": "Supply the project's required Values and validate the mapping before execution.",
                "candidate_sources": [], "evidence_ids": []})
        review["headline"] = (f"Auto-map: {len(resolved)} definition(s) preserved; {new_count} newly mapped; "
                              f"{proposed_count - new_count} replacement proposal(s); {review['unresolved_count']} target(s) need input. "
                              "Preservation is not execution approval.")
        dispatch = dict(response.meta.get("auto_mapping_dispatch") or {}) if response else {
            "attribute_count": len(mappings), "batch_count": 0, "batch_sizes": [], "failed_batches": [],
            "resumed_batch_indices": [], "batching_mode": "deterministic_preservation", "max_in_flight": 0}
        dispatch.update(attribute_count=len(mappings),
                        pending_attribute_count=sum(entry["status"] == "pending" for entry in plan["targets"]),
                        preserved_attribute_count=len(resolved))
        coverage = dict(response.meta.get("auto_mapping_coverage") or {}) if response else {}
        if coverage:
            coverage.update(requested=len(mappings), returned=len(mappings))
        meta = {**self._without_resolution_meta(response.meta if response else req.meta),
            **({"auto_mapping_coverage": coverage} if coverage else {}),
            "auto_mapping_dispatch": dispatch, "auto_mapping_review": review, "automap_preserved_targets": preserved,
            "automap_baseline_preservation": {"version": plan["version"], "baseline_hash": plan["baseline_hash"],
                "partition_hash": plan["partition_hash"], "instruction": "preserve_frontend_rows",
                "definition_source": "context.workspace_context", "apply_preserved_mappings": False,
                "preserve_mapping_sql": True, "preserve_raw_mapping_sql": True},
            "automap_resolution": {"version": plan["version"], "mode": plan["mode"], "targets": diagnostics,
                "execution_status": "blocked" if review["unresolved_count"] else "not_validated"}}
        from app.core.automap_batch import canonical_model_wire_request
        response_req = canonical_model_wire_request(req, wire=False)
        merged = STTMBuilderResponse.from_invocation(response_req, thread_id=response.thread_id if response else None,
            parent_message_id=response.parent_message_id if response else None, agent=response.agent if response else None,
            result=SourceMappingResult(mappings=mappings), message=review["headline"],
            status=STTMStatus.NEEDS_INPUT if review["action_required_count"] or dispatch.get("failed_batches") else STTMStatus.COMPLETED,
            warnings=response.warnings if response else [], meta=meta)
        merged.meta = meta
        return merged

    def _resolution_partial_metadata(self, root, response, attributes):
        """Partials must carry the same non-overwrite instruction as the final."""
        complete = self._complete_resolution_response(root, response)
        plan = self._trusted_resolution_plan(root)
        targets = {item.target_attribute for item in attributes}
        proposed = response.result.mappings
        _, review = self._build_mapping_review(proposed)
        new_mappings = {entry["target_attribute"]: proposed[entry["target_attribute"]]
                        for entry in plan["targets"] if entry["target_attribute"] in proposed and not entry["had_baseline"]}
        review_only=set(response.meta.get("automap_evidence_review_only_targets",[]))
        _, new_review = self._build_mapping_review({key:value for key,value in new_mappings.items()if key not in review_only})
        uncertain=[target for target in review_only & proposed.keys() if proposed[target].transformation_classification!="unresolved"]
        review["unresolved_count"]+=len(uncertain);review["action_required_count"]+=len(uncertain)
        review.update(preserved_count=0, newly_mapped_count=new_review["mapped_count"],
                      proposed_count=review["mapped_count"], mapped_count=new_review["mapped_count"],
                      completed_without_review_count=new_review["completed_without_review_count"],
                      mapped_with_review_count=new_review["mapped_with_review_count"])
        retained = [item for item in complete.meta["auto_mapping_review"]["recommendations"]
                    if item["category"] == "baseline_proposal" and item["target_attribute"] in targets]
        review["recommendations"].extend(retained)
        review["unresolved_count"] += len(retained)
        review["action_required_count"] += len(retained)
        if retained:
            response.data.status = STTMStatus.NEEDS_INPUT
        review["headline"] = (f"Auto-map batch: {review['newly_mapped_count']} newly mapped; "
                              f"{review['proposed_count'] - review['newly_mapped_count']} replacement proposal(s); "
                              f"{review['unresolved_count']} target(s) need input. Existing definitions remain unchanged.")
        response.meta = {**self._without_resolution_meta(response.meta),
            "auto_mapping_review": review,
            "automap_preserved_targets": [name for name in complete.meta["automap_preserved_targets"] if name in targets],
            "automap_baseline_preservation": complete.meta["automap_baseline_preservation"],
            "automap_resolution": {**complete.meta["automap_resolution"],
                "targets": [item for item in complete.meta["automap_resolution"]["targets"]
                            if item["target_attribute"] in targets],
                "execution_status": "blocked" if review["unresolved_count"] else "not_validated"}}
        response.message = response.data.message = review["headline"]
        return response

    def _resolution_batch_response(self, req, response, batch_index):
        if response.request_id != req.request_id or response.operation != req.operation:
            raise SnowflakeAgentError("Worker response does not match the Auto-map request")
        self._validate_worker_response(response, req=req, batch_index=batch_index)
        result = response.data.result if response.data else response.result
        retrieval = response.meta.get("auto_map_retrieval") or {}
        no_worker_result = (retrieval.get("parallel_preparation") or retrieval.get("auto_map_fast_path")) and retrieval.get("model_call_count") == 0
        provenance = response.meta.get("durable_model_provenance") or {}
        proven_results = provenance.get("validated_results") or {}
        mappings = {}
        warnings = list(response.warnings)
        for attribute in req.data.attributes or []:
            target = attribute.target_attribute
            mapping = result.mappings.get(target) or result.mappings.get(f"{attribute.target_table.qualified_name}.{target}")
            proven = (no_worker_result and mapping is not None and self._validated_retry_candidate(mapping)
                and proven_results.get(target) == self._resolution_digest(mapping.model_dump(mode="json"))
                and any(type(count) is int and count > 0
                        for count in provenance.get("attempt_model_call_counts", [])))
            if no_worker_result and not proven:
                mapping = AttributeMapping(source_attributes=[], confidence_score=0.0,
                    transformation_classification="unresolved", unmatched_reason="Preparation did not reach source mapping; no mapping was accepted.")
            if mapping is None:
                mapping = AttributeMapping(source_attributes=[], confidence_score=0.0,
                    transformation_classification="unresolved", unmatched_reason="Worker omitted this exact target; no mapping was fabricated.")
                warnings.append(ApiWarning(code="AUTO_MAPPING_TARGET_OMITTED", message=mapping.unmatched_reason, field=target))
            mappings[target] = mapping
        selected = SourceMappingResult(mappings=mappings)
        _, review = self._build_mapping_review(mappings)
        return response.model_copy(update={"result": selected, "warnings": warnings,
            "data": response.data.model_copy(update={"result": selected,
                "status": STTMStatus.NEEDS_INPUT if review["unresolved_count"] else response.data.status})})

    @property
    def enabled(self) -> bool:
        return bool(self._base_url)

    @staticmethod
    def _build_mapping_review(
        mappings: dict[str, AttributeMapping],
    ) -> tuple[str, dict[str, Any]]:
        """Build a deterministic, actionable review of the validated agent output."""
        recommendations: list[dict[str, Any]] = []
        mapped_count = 0
        unresolved_count = 0
        low_confidence_count = 0
        override_count = 0
        missing_derived_count = 0

        for target, mapping in mappings.items():
            is_unresolved = (
                mapping.transformation_classification == "unresolved"
                or (
                    mapping.mapping_mode not in {"constant", "attribute"}
                    and not mapping.source_attributes
                    and not mapping.source_dependencies
                )
                or (mapping.mapping_mode == "constant" and mapping.constant_value is None)
                or (
                    mapping.mapping_mode == "attribute"
                    and (
                        not mapping.attribute_name
                        or mapping.constant_value is None
                        or not mapping.value_binding_ids
                    )
                )
            )
            if is_unresolved:
                unresolved_count += 1
            else:
                mapped_count += 1

            reason = str(mapping.unmatched_reason or "").strip()
            evidence_ids = list(
                dict.fromkeys(
                    [
                        *mapping.used_inference_ids,
                        *mapping.used_recommendation_ids,
                        *mapping.used_learning_ids,
                    ]
                )
            )
            candidate_sources = list(
                dict.fromkeys(
                    [
                        *mapping.candidate_source_attributes,
                        *mapping.source_attributes,
                        *mapping.source_dependencies,
                    ]
                )
            )[:6]

            if reason.startswith(_PREFLIGHT_BUDGET_CODE + ":"):
                recommendations.append({"target_attribute": target, "category": "preflight_budget_exceeded",
                    "severity": "action_required", "title": "Resolve the mandatory evidence budget before retrying",
                    "detail": reason, "recommended_action": (
                        "Review the retained definition and mandatory context with the workspace owner. "
                        "Use an explicitly reviewed source scope or mapping; no evidence was clipped and no model no-match was inferred."),
                    "candidate_sources": [], "evidence_ids": []})
                continue

            if reason.startswith(_PREFLIGHT_DEADLINE_CODE + ":"):
                recommendations.append({"target_attribute": target, "category": "preflight_deadline_exceeded",
                    "severity": "action_required", "title": "Review incomplete preparation before retrying",
                    "detail": reason, "recommended_action": "The shared request deadline expired. Review the retained definition; no model no-match or size overflow was inferred.",
                    "candidate_sources": [], "evidence_ids": []})
                continue

            if "derived source output contract" in reason.lower():
                missing_derived_count += 1
                recommendations.append(
                    {
                        "target_attribute": target,
                        "category": "missing_derived_output",
                        "severity": "action_required",
                        "title": "Update the selected derived source or choose an available output",
                        "detail": reason,
                        "recommended_action": (
                            "Open Source Selection, edit the relevant derived source, add the "
                            "business-approved output with lineage and semantics, validate/save it, "
                            "then rerun Auto-map. If the historical field is not valid for this "
                            "source, choose one of the available candidates instead."
                        ),
                        "candidate_sources": candidate_sources,
                        "evidence_ids": evidence_ids,
                    }
                )
                continue

            if is_unresolved:
                recommendations.append(
                    {
                        "target_attribute": target,
                        "category": "unresolved_mapping",
                        "severity": "action_required",
                        "title": "Resolve the source or Value binding",
                        "detail": reason or mapping.confidence_reason or (
                            "The current source graph does not contain enough validated evidence."
                        ),
                        "recommended_action": (
                            "Review the suggested candidates and linked evidence. Select or prepare "
                            "the required source, then rerun Auto-map for this target."
                        ),
                        "candidate_sources": candidate_sources,
                        "evidence_ids": evidence_ids,
                    }
                )
                continue

            if mapping.candidate_source_attributes and mapping.confidence_score >= 0.8:
                recommendations.append({
                    "target_attribute": target,
                    "category": "alternative_candidates",
                    "severity": "review",
                    "title": "Compare alternative source candidates",
                    "detail": mapping.confidence_reason or (
                        "The selected mapping has alternative candidates that warrant semantic review."
                    ),
                    "recommended_action": (
                        "Compare the alternatives with the selected source. Suggestions are not validated "
                        "replacements; check graph connectivity and business meaning before applying one."
                    ),
                    "candidate_sources": candidate_sources,
                    "evidence_ids": evidence_ids,
                })

            if mapping.confidence_score < 0.8:
                low_confidence_count += 1
                recommendations.append(
                    {
                        "target_attribute": target,
                        "category": "low_confidence",
                        "severity": "review",
                        "title": f"Review low-confidence mapping ({mapping.confidence_score:.0%})",
                        "detail": mapping.confidence_reason or (
                            "The mapping passed structural validation but has weak semantic evidence."
                        ),
                        "recommended_action": (
                            "Compare the proposed source and preprocessing rule with the target's "
                            "business meaning and sample data before accepting it."
                        ),
                        "candidate_sources": candidate_sources,
                        "evidence_ids": evidence_ids,
                    }
                )

            if mapping.precedent_decision == "unresolved":
                recommendations.append(
                    {
                        "target_attribute": target,
                        "category": "precedent_unverified",
                        "severity": "review",
                        "title": "Review mapping without a verified precedent",
                        "detail": mapping.confidence_reason or (
                            "The current source binding is structurally valid, but its "
                            "historical precedent claim could not be verified."
                        ),
                        "recommended_action": (
                            "Review the current source binding and evidence before publishing."
                        ),
                        "candidate_sources": candidate_sources,
                        "evidence_ids": evidence_ids,
                    }
                )

            if mapping.precedent_decision == "override_precedent":
                override_count += 1
                recommendations.append(
                    {
                        "target_attribute": target,
                        "category": "precedent_override",
                        "severity": "review",
                        "title": "Review the change from linked precedent",
                        "detail": mapping.confidence_reason or (
                            "The agent selected a current-source mapping that differs from history."
                        ),
                        "recommended_action": (
                            "Confirm that the cited evidence and current source structure justify "
                            "the override before publishing."
                        ),
                        "candidate_sources": candidate_sources,
                        "evidence_ids": list(
                            dict.fromkeys([*mapping.override_evidence, *evidence_ids])
                        ),
                    }
                )

        total_count = len(mappings)
        action_required_targets = {
            item["target_attribute"]
            for item in recommendations
            if item["severity"] == "action_required"
        }
        mapped_review_targets = {
            item["target_attribute"]
            for item in recommendations
            if item["severity"] == "review"
        } - action_required_targets
        review_count = len(action_required_targets | mapped_review_targets)
        completed_without_review_count = max(0, mapped_count - len(mapped_review_targets))
        headline = f"Auto-map completed: {mapped_count}/{total_count} targets mapped."
        if review_count:
            headline += (
                f" {completed_without_review_count} mapped target(s) need no further action; "
                f"{len(mapped_review_targets)} mapped target(s) need review; "
                f"{len(action_required_targets)} target(s) still require input."
            )
        else:
            headline += " No mapping issues were detected."
        if missing_derived_count:
            headline += (
                f" {missing_derived_count} learned mapping(s) require outputs that the current "
                "derived source does not expose."
            )

        return headline, {
            "headline": headline,
            "total_count": total_count,
            "mapped_count": mapped_count,
            "unresolved_count": unresolved_count,
            "low_confidence_count": low_confidence_count,
            "precedent_override_count": override_count,
            "missing_derived_output_count": missing_derived_count,
            "completed_without_review_count": completed_without_review_count,
            "mapped_with_review_count": len(mapped_review_targets),
            "action_required_count": len(action_required_targets),
            "recommendations": recommendations,
        }

    def should_delegate(self, req: STTMBuilderEnvelopeRequest) -> bool:
        return self.enabled and req.data.intent == Interface.AUTO_MAP

    def start_job(self, request, req, *, session=None, prepare=False):
        req = req.model_copy(update={"meta": self._without_resolution_meta(req.meta)})
        req = self._accept_resolution(req)
        if not prepare:
            return self._start_job(request, req, session=session)
        principal = request.state.current_principal
        owner = str(principal.snowflake_user or principal.user_id)
        identity = str(uuid.uuid5(uuid.NAMESPACE_URL, f"automap:{owner}:{req.request_id}"))
        with _AUTO_MAP_JOBS_LOCK:
            lock = _AUTO_MAP_ACCEPT_LOCKS.setdefault(identity, threading.Lock())
        if not lock.acquire(timeout=20):
            raise HTTPException(status_code=503, detail="Auto-map acceptance is in progress; recover by request ID")
        try:
            fingerprint = hashlib.sha256(json.dumps(
                {"scoring_policy_version": SCORING_POLICY_VERSION,
                 "context": req.context.model_dump(mode="json"), "data": req.data.model_dump(mode="json"),
                 **({"resolution_mode": req.meta["auto_map_resolution_mode"],
                     "worker_variant": req.meta.get("auto_map_fast_path"),
                     "reevaluate_targets": req.meta.get("auto_map_reevaluate_targets")}
                    if req.meta.get("auto_map_resolution_mode") is not None else {})},
                sort_keys=True, separators=(",", ":"), default=str,
            ).encode()).hexdigest()
            headers = self._forward_headers(request)
            existing = self._load_persisted_job(identity, owner=owner, headers=headers, session=session)
            if existing:
                if existing.get("acceptance_hash") != fingerprint:
                    raise HTTPException(status_code=409, detail="Auto-map request ID already belongs to a different workspace revision")
                return self.get_job(request, identity, session=session)
            return self._start_job(request, req, session=session, prepare=True,
                                   accepted_id=identity, acceptance_hash=fingerprint)
        finally:
            lock.release()

    def _start_job(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
        *,
        session: Any | None = None,
        prepare: bool = False,
        accepted_id: str | None = None,
        acceptance_hash: str | None = None,
    ) -> dict[str, Any]:
        """Run long Cortex mapping work outside the public ingress request."""
        principal = getattr(request.state, "current_principal", None)
        owner = str(
            getattr(principal, "snowflake_user", None)
            or getattr(principal, "user_id", None)
            or ""
        )
        if prepare and not self._settings.auto_map_pipeline_v2:
            raise HTTPException(status_code=503, detail="Durable Auto-map acceptance requires pipeline v2")
        req = self._accept_resolution(req) if not self._trusted_resolution_plan(req) else req
        if not prepare:
            req = self._freeze_resolution(req)
        headers = self._forward_headers(request)
        job_id = accepted_id or str(uuid.uuid4())
        created_at = datetime.now(UTC)
        record: dict[str, Any] = {
            "job_id": job_id,
            "request_id": req.request_id,
            "owner": owner,
            "recovery_session_hash": hashlib.sha256(headers.session_id.encode()).hexdigest()
                if getattr(headers,'session_id',None) else None,
            "recovery_role": headers.get('X-Workbench-OAuth-Role'),
            "scoring_policy_version": SCORING_POLICY_VERSION,
            "generation_policy": req.meta.get("automap_generation_policy"),
            "rules_policy": req.meta.get("automap_rules_policy"),
            "execution_protocol": 'background_v2' if getattr(self._settings,'automap_durable_runs_v2',False) else 'legacy_sync_v1',
            "call_tracking": req.meta.get("_automap_call_tracking","pooled_v2"),
            "acceptance_hash": acceptance_hash,
            "status": "queued",
            "created_at": created_at.isoformat(),
            "updated_at": created_at.isoformat(),
            "attribute_count": len(req.data.attributes or []),
            "batch_count": 0 if prepare else len(self._build_batches(req)),
            "preparation_pending": prepare,
            "completed_batch_count": 0,
            "completed_attribute_count": 0,
            "partial_responses": [],
            "response": None,
            "error": None,
            "stage": "queued",
            "prepared_context_hash": req.context.prepared_context_hash,
            "context_hash": req.context.prepared_context_hash,
            "semantic_bundle_id": req.context.semantic_bundle_id,
            "semantic_bundle_label": req.context.semantic_bundle_label,
            "agent_spec_hashes": dict(req.meta.get("agent_spec_hashes") or {}),
            "retrieved_evidence_ids": list(
                req.context.execution_context.evidence_ids
                if req.context.execution_context
                else []
            ),
            "retrieved_precedent_ids": list(
                req.context.learning_context.linked_mapping_ids
                if req.context.learning_context
                else []
            ),
            "pipeline_version": "v2" if self._settings.auto_map_pipeline_v2 else "legacy_adapter",
            "batch_strategy": self._batch_identity(req, list(req.data.attributes or []))
                if (self._settings.automap_context_retrieval_v1 or self._trusted_resolution_plan(req)) and not prepare else None,
            "prepared_automap": store_json(getattr(req.context._prepared_automap, 'body', None)),
            "request_envelope": (
                req.model_dump(mode="json")
                if self._settings.auto_map_pipeline_v2
                else None
            ),
            "state_version": 0,
            "timings_ms": {},
        }
        self._prune_jobs()
        with _AUTO_MAP_JOBS_LOCK:
            _AUTO_MAP_JOBS[job_id] = record
        if self._settings.auto_map_pipeline_v2:
            self._persist_job(record, headers=headers, session=session, required=True)

        self._launch_job_runner(
            job_id,
            req=req,
            headers=headers,
            owner=owner,
            record=record,
        )
        return self._public_job(record)

    def _launch_job_runner(
        self,
        job_id: str,
        *,
        req: STTMBuilderEnvelopeRequest,
        headers: dict[str, str],
        owner: str,
        record: dict[str, Any],
    ) -> bool:
        """Start or resume one durable job once per local replica and lease."""
        if (record.get("scoring_policy_version") != SCORING_POLICY_VERSION
                or req.meta.get(SCORING_META_KEY) != SCORING_POLICY_VERSION):
            return False  # Historical jobs remain readable, never reinterpreted by a new worker.
        expected_protocol='background_v2' if getattr(self._settings,'automap_durable_runs_v2',False) else 'legacy_sync_v1'
        if record.get('execution_protocol','legacy_sync_v1')!=expected_protocol:
            return False  # cutover/rollback cannot reinterpret an old dispatch attempt
        if isinstance(record.get("prepared_automap"), dict):
            from app.core.automap_prepared_evidence import TrustedPreparedAutoMap
            req.context._prepared_automap = TrustedPreparedAutoMap(record["prepared_automap"])
        with _AUTO_MAP_JOBS_LOCK:
            if job_id in _AUTO_MAP_ACTIVE_RUNNERS:
                return False
            _AUTO_MAP_ACTIVE_RUNNERS.add(job_id)

        def run() -> None:
            nonlocal req
            started = time.perf_counter()
            durable_client: SnowflakeClient | None = None
            durable_session: Any | None = None
            heartbeat_stop = threading.Event()
            lease_lost = threading.Event()
            heartbeat = None
            try:
                if self._settings.auto_map_pipeline_v2:
                    durable_client = self._open_job_client(headers)
                    durable_session = durable_client.session
                    if not self._claim_job_lease(
                        job_id,
                        owner=owner,
                        headers=headers,
                        session=durable_session,
                    ):
                        logger.info(
                            "Auto-map job %s is already leased by another replica",
                            job_id,
                        )
                        return
                    if record.get("acceptance_hash"):
                        accepted = self._load_persisted_job(job_id, owner=owner, headers=headers, session=durable_session)
                        if not accepted or accepted.get("acceptance_hash") != record["acceptance_hash"]:
                            raise SnowflakeAgentError("Auto-map acceptance revision does not match durable storage")
                    if self._settings.automap_context_retrieval_v1 or self._resolution_job(record):
                        def renew():
                            while not heartbeat_stop.wait(_AUTO_MAP_LEASE_SECONDS / 3):
                                try:
                                    if not self._renew_job_lease(job_id, headers=headers):
                                        lease_lost.set()
                                        return
                                except Exception:
                                    lease_lost.set()
                                    logger.exception("Auto-map dispatcher lost lease job_id=%s", job_id)
                                    return
                        heartbeat = threading.Thread(target=renew, daemon=True, name=f"auto-map-lease-{job_id[:8]}")
                        heartbeat.start()
                if record.get("preparation_pending"):
                    req = self._restore_acceptance(req)
                if not record.get("preparation_pending") and not isinstance(req.meta.get(_RESOLUTION_PLAN_KEY), _BackendResolutionPlan):
                    req = self._restore_resolution(req)
                if record.get("preparation_pending"):
                    self._update_job(job_id, headers=headers, session=durable_session,
                                     status="running", stage="preparing")
                    preparation_started = time.perf_counter()
                    req = self._prepare_job_request(req, session=durable_session, owner=owner, headers=headers)
                    req = self._freeze_resolution(req)
                    # Persist the enriched envelope before preflight can raise, so
                    # a failed job remains reproducible without logging its evidence.
                    self._update_job(
                        job_id, headers=headers, session=durable_session, require_persistence=True,
                        preparation_pending=False, request_envelope=req.model_dump(mode="json"),
                        prepared_context_hash=req.context.prepared_context_hash,
                        context_hash=req.context.prepared_context_hash,
                        semantic_bundle_id=req.context.semantic_bundle_id,
                        agent_spec_hashes=dict(req.meta.get("agent_spec_hashes") or {}),
                        preparation_diagnostics={"stage": "target_batch_preflight",
                                                 "target_count": len(req.data.attributes or [])},
                    )
                    preflight = []
                    batches = self._build_batches(req, diagnostics=preflight)
                    self._quarantine_resolution_receipts(job_id, req, headers=headers, session=durable_session)
                    self._update_job(
                        job_id, headers=headers, session=durable_session, require_persistence=True,
                        batch_count=len(batches),
                        request_envelope=req.model_dump(mode="json"),
                        batch_strategy=self._batch_identity(req, list(req.data.attributes or []))
                            if self._settings.automap_context_retrieval_v1 or self._trusted_resolution_plan(req) else None,
                        preparation_diagnostics={"stage": "ready", "batches": preflight},
                        preparation_ms=round((time.perf_counter() - preparation_started) * 1000, 2),
                    )
                    if lease_lost.is_set():
                        return
                elif self._trusted_resolution_plan(req):
                    # Old durable envelopes may predate the cached preflight. Freeze
                    # and acknowledge it before any fitting batch can be dispatched.
                    preflight = []
                    batches = self._build_batches(req, diagnostics=preflight)
                    self._quarantine_resolution_receipts(job_id, req, headers=headers, session=durable_session)
                    self._update_job(job_id, headers=headers, session=durable_session, require_persistence=True,
                        request_envelope=req.model_dump(mode="json"), batch_count=len(batches),
                        preparation_diagnostics={"stage": "ready", "batches": preflight})
                self._update_job(
                    job_id,
                    headers=headers,
                    session=durable_session,
                    status="running",
                    stage="finalizing" if self._trusted_resolution_plan(req) and not any(
                        entry["status"] == "pending" for entry in self._trusted_resolution_plan(req)["targets"]) else "source_mapping",
                )
                try:
                    def progress(batch_index, batch_attributes, batch_response):
                        if lease_lost.is_set():
                            raise SnowflakeAgentError("Auto-map dispatcher lease was lost; results were not persisted")
                        self._record_partial_response(job_id, batch_index=batch_index, batch_attributes=batch_attributes,
                                                      response=batch_response, headers=headers, session=durable_session)
                    invoke_kwargs: dict[str, Any] = {
                        "progress_callback": progress
                    }
                    persisted_partials = list(record.get("partial_responses") or [])
                    if persisted_partials:
                        invoke_kwargs["resume_partials"] = persisted_partials
                    req._automap_durable_receipt = True  # Enriched request and preflight receipts ACKed above.
                    response = self._invoke_with_headers(
                        req,
                        headers=headers,
                        **invoke_kwargs,
                    )
                except TypeError as exc:
                    if self._resolution_job(record):
                        raise
                    # Some unit tests and legacy integrations monkeypatch this
                    # internal method without the progress_callback kwarg. Keep
                    # that compatibility while production calls still receive
                    # partial batch updates.
                    if not any(
                        keyword in str(exc)
                        for keyword in ("progress_callback", "resume_partials")
                    ):
                        raise
                    response = self._invoke_with_headers(req, headers=headers)
            except Exception as exc:
                if lease_lost.is_set():
                    return
                if isinstance(exc, _AutoMapPersistenceError):
                    logger.exception("Auto-map durable acknowledgement failed job_id=%s", job_id)
                    return
                logger.exception(
                    "Async Auto-map job failed: job_id=%s request_id=%s error_type=%s",
                    job_id,
                    req.request_id,
                    type(exc).__name__,
                )
                error = {"code": "AUTO_MAPPING_JOB_FAILED",
                         "message": "The Auto-map Agent job could not be completed."}
                if isinstance(exc, HTTPException) and exc.status_code == 401:
                    error = {"code": "AUTO_MAP_AUTHENTICATION_REQUIRED",
                        "message": "Your session expired. Sign in again to recover retained Auto-map results.",
                        "stage": "authentication", "trace_id": str(req.request_id)}
                from app.core.automap_batch import _FastInvariantError
                if isinstance(exc, _FastInvariantError):
                    error = {"code": "AUTO_MAP_PREPARATION_INVALID",
                        "message": "Auto-map execution context could not be prepared. Existing mappings were retained.",
                        "stage": "preparation", "invariant": exc.code,
                        "trace_id": str(req.request_id)}
                if isinstance(exc, AgentPayloadBudgetError):
                    from app.core.automap_shards import MessageBudgetError
                    cause = exc
                    while cause is not None and not isinstance(cause, MessageBudgetError):
                        cause = cause.__cause__
                    error = {"code": "AUTO_MAP_PREPARATION_BUDGET_EXCEEDED",
                             "message": "Mandatory Auto-map evidence does not fit the configured message budget.",
                             "stage": "target_batch_preflight",
                             "requested_targets": [item.target_attribute for item in req.data.attributes or []]}
                    if cause is not None:
                        error.update(measured_chars=cause.char_count, measured_bytes=cause.byte_count,
                                     limit_chars=cause.budget.max_chars, limit_bytes=cause.budget.max_bytes)
                        if getattr(cause, "components", None):
                            error["largest_components"] = list(cause.components)
                self._update_job(
                    job_id,
                    headers=headers,
                    session=durable_session,
                    status="failed",
                    error=error,
                    stage="failed",
                    timings_ms={"total": round((time.perf_counter() - started) * 1000, 2)},
                )
                return
            else:
                if lease_lost.is_set():
                    return
                failed_batches = set((response.meta.get("auto_mapping_dispatch") or {}).get("failed_batches") or [])
                plan = self._trusted_resolution_plan(req)
                if plan:
                    dispatch = response.meta["auto_mapping_dispatch"]
                    try:
                        self._update_job(job_id, headers=headers, session=durable_session, require_persistence=True,
                            status="partial_failure" if failed_batches else "completed",
                            response=response.model_dump(mode="json"),
                            completed_batch_count=dispatch["batch_count"] - len(failed_batches),
                            completed_attribute_count=len(plan["targets"]) - response.meta["auto_mapping_review"]["unresolved_count"],
                            stage="partial_failure" if failed_batches else "completed",
                            timings_ms={"total": round((time.perf_counter() - started) * 1000, 2)})
                    except _AutoMapPersistenceError:
                        logger.exception("Auto-map terminal result was not durably acknowledged job_id=%s", job_id)
                    return
                batches = self._build_batches(req)
                if not failed_batches:
                    self._ensure_missing_partial_responses(
                        job_id, req=req, response=response, headers=headers, session=durable_session,
                    )
                self._update_job(
                    job_id,
                    headers=headers,
                    session=durable_session,
                    status="partial_failure" if failed_batches else "completed",
                    response=response.model_dump(mode="json"),
                    completed_batch_count=len(batches) - len(failed_batches),
                    completed_attribute_count=sum(len(batch) for index, batch in enumerate(batches)
                                                  if index not in failed_batches),
                    stage="partial_failure" if failed_batches else "completed",
                    timings_ms={"total": round((time.perf_counter() - started) * 1000, 2)},
                )
            finally:
                heartbeat_stop.set()
                if heartbeat is not None:
                    heartbeat.join(timeout=5)
                if durable_client is not None:
                    durable_client.close()
                with _AUTO_MAP_JOBS_LOCK:
                    _AUTO_MAP_ACTIVE_RUNNERS.discard(job_id)

        threading.Thread(
            target=run,
            name=f"auto-map-job-{job_id[:8]}",
            daemon=True,
        ).start()
        return True

    def _prepare_job_request(self, req, *, session, owner, headers):
        preparation_started = time.perf_counter()
        from app.core.sttm_builder import STTMBuilderService
        from app.core.mapping_sql import MappingSqlService
        req = self._accept_resolution(req) if not self._trusted_resolution_plan(req) else req
        project_attributes = []
        if req.meta.get("auto_map_resolution_mode") is not None:
            if time.time() >= req.meta["_automap_acceptance"]["deadline_at"] - 20:
                return self._freeze_resolution(req, project_attributes=[])
            loader = STTMBuilderService.__new__(STTMBuilderService)
            loader._settings, loader._session = self._settings, session
            try:
                project_attributes = loader._load_project_firm_values(str(req.context.project_id))
            except Exception as exc:
                if req.meta.get('automap_generation_policy') != 'draft-v3':
                    raise ContextPrecedentUnavailableError("Authoritative project Values could not be loaded") from exc
                logger.warning('Auto-map project Values unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)
                req = req.model_copy(update={'meta': {**req.meta, 'automap_values_unavailable': True}})
        req = self._freeze_resolution(req, project_attributes=project_attributes)
        plan = self._trusted_resolution_plan(req)
        if plan and plan.get("prepared_automap"):
            from app.core.automap_prepared_evidence import TrustedPreparedAutoMap
            req.context._prepared_automap = TrustedPreparedAutoMap(plan["prepared_automap"])
        if plan and not any(entry["status"] == "pending" for entry in plan["targets"]):
            return req
        if plan and time.time() >= plan["deadline_at"] - 20:
            return req
        from app.core.datahub import DataHubAdapter
        from app.core.derived_source import DerivedSourceService
        from app.core.semantic_context import SemanticContextService
        from app.core.semantic_model import SemanticModelService
        from app.core.table_selection import TableSelectionService
        from app.core.sttm_builder import STTMBuilderService
        from types import SimpleNamespace
        role = headers.get("X-Workbench-OAuth-Role") or headers.get("X-Workbench-Caller-Role") or self._settings.snowflake_role
        scope = f"{owner}|automap-preparation|{role}"
        model = SemanticModelService(self._settings)
        # Preparation has no model calls. Keep its session runner-owned and its
        # cache access-scoped; model authentication belongs to the worker.
        semantic = SemanticContextService(
            session=session, settings=self._settings, semantic_model_service=model,
            table_selection_service=TableSelectionService(SimpleNamespace(session=session), self._settings, scope),
            derived_source_service=DerivedSourceService(session, self._settings),
            datahub_adapter=DataHubAdapter(self._settings), access_scope=scope,
        )
        service = STTMBuilderService(None, analyst_client=None, settings=self._settings,
            session=session, semantic_model_service=model, semantic_context_service=semantic,
            access_scope=scope)
        if plan:
            service._with_project_firm_values = lambda graph, project_id: MappingSqlService.with_project_values(graph, project_attributes)
        # Install authoritative Values before execution context is constructed.
        req = req.model_copy(update={"context": req.context.model_copy(update={
            "relation_graph": MappingSqlService.with_project_values(req.context.relation_graph, project_attributes)})}) if plan else req
        prepared = service.prepare_auto_map_request(req.model_copy(deep=True) if plan else req)
        if plan:
            prepared = prepared.model_copy(update={"data": req.data, "context": prepared.context.model_copy(update={
                "workspace_context": req.context.workspace_context,
                "relation_graph": MappingSqlService.with_project_values(prepared.context.relation_graph, project_attributes)})})
            prepared = service._finalize_auto_map_preparation(prepared)
            frozen = _BackendResolutionPlan(deepcopy(plan))
            frozen["input_hash"] = self._resolution_digest(self._resolution_inputs(prepared)[1])
            prepared.meta = {**prepared.meta, _RESOLUTION_PLAN_KEY: frozen}
            pending = self._pending_resolution_request(prepared)
            decision = service._build_governance_decision(pending)
            service._model_guard.assert_model_target_allowed(operation=pending.operation.value, target="agent", decision=decision)
            pending = service._govern_request_for_model(pending, decision)
            discovery = None
            if time.time() < plan["deadline_at"] - 20:
                from app.core.automap_retrieval import target_name
                discovery = service._discover_auto_map_batch_evidence(pending,
                    [target_name(item.target_attribute) for item in pending.data.attributes])
            prepared = self._bind_fast_handoff(prepared, discovery=discovery)
            trusted = self._trusted_resolution_plan(prepared)
            trusted['preparation_ms'] = round((time.perf_counter() - preparation_started) * 1000, 2)
        return prepared

    def _bind_fast_handoff(self, req, *, discovery=None):
        from app.core.automap_batch import freeze_fast_handoff
        plan = self._trusted_resolution_plan(req)
        if not plan:
            return req
        pending = self._pending_resolution_request(req)
        handoff = freeze_fast_handoff(pending, discovery=discovery)
        frozen = _BackendResolutionPlan(deepcopy(plan))
        frozen.update(handoff=handoff, handoff_hash=self._resolution_digest(handoff))
        return req.model_copy(update={"meta": {**req.meta, _RESOLUTION_PLAN_KEY: frozen}})

    def find_job(self, request, request_id, *, session):
        principal = request.state.current_principal
        owner = str(principal.snowflake_user or principal.user_id)
        table = self._settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
        rows = session.sql(
            f"SELECT JOB_ID FROM {table} WHERE REQUEST_ID = ? AND OWNER_ID = ? "
            "AND EXPIRES_AT > CURRENT_TIMESTAMP() ORDER BY CREATED_AT DESC LIMIT 1",
            params=[request_id, owner],
        ).collect()
        if not rows:
            raise HTTPException(status_code=404, detail="Auto-map request has not been accepted yet")
        row = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
        return self.get_job(request, str(row["JOB_ID"]), session=session)

    def _ensure_missing_partial_responses(
        self,
        job_id: str,
        *,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
        headers: dict[str, str],
        session: Any | None,
    ) -> None:
        """Guarantee a terminal job exposes one idempotent partial per batch."""
        batches = self._build_batches(req)
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS.get(job_id) or {}
            present = {
                int(item.get("batch_index", -1))
                for item in record.get("partial_responses") or []
            }
        for batch_index, batch in enumerate(batches):
            if batch_index in present:
                continue
            batch_targets = {
                str(getattr(attribute, "target_attribute", "") or "")
                for attribute in batch
            }
            batch_response = self._response_for_targets(response, batch_targets)
            if req.meta.get(SCORING_META_KEY) is not None:
                batch_response.meta = {**batch_response.meta, "batch_identity": self._batch_identity(req, batch)}
            self._record_partial_response(
                job_id,
                batch_index=batch_index,
                batch_attributes=batch,
                response=batch_response,
                headers=headers,
                session=session,
            )

    @staticmethod
    def _response_for_targets(
        response: STTMBuilderResponse,
        target_attributes: set[str],
    ) -> STTMBuilderResponse:
        """Return a compact response containing only one batch's mappings."""
        result = response.data.result if response.data else None
        if not isinstance(result, SourceMappingResult):
            result = response.result
        if not isinstance(result, SourceMappingResult):
            return response
        normalized_targets = {
            str(target).rsplit(".", 1)[-1].upper()
            for target in target_attributes
            if target
        }
        selected = SourceMappingResult(
            mappings={
                target: mapping
                for target, mapping in result.mappings.items()
                if str(target).rsplit(".", 1)[-1].upper() in normalized_targets
            }
        )
        data = (
            response.data.model_copy(update={"result": selected})
            if response.data is not None
            else None
        )
        return response.model_copy(update={"data": data, "result": selected})

    def get_job(
        self,
        request: Request,
        job_id: str,
        *,
        session: Any | None = None,
    ) -> dict[str, Any]:
        principal = getattr(request.state, "current_principal", None)
        owner = str(
            getattr(principal, "snowflake_user", None)
            or getattr(principal, "user_id", None)
            or ""
        )
        headers = self._forward_headers(request)
        record = None
        if self._settings.auto_map_pipeline_v2:
            try:
                record = self._load_persisted_job(
                    job_id,
                    owner=owner,
                    headers=headers,
                    session=session,
                )
            except HTTPException:
                # A transient Snowflake response truncation must not make an
                # active job disappear on the replica that owns its runner.
                # Durable state remains authoritative whenever it is readable.
                with _AUTO_MAP_JOBS_LOCK:
                    record = _AUTO_MAP_JOBS.get(job_id)
                if record is None:
                    raise
                logger.warning(
                    "Serving Auto-map job %s from replica memory after a transient "
                    "durable-state read failure",
                    job_id,
                )
            if record is not None:
                with _AUTO_MAP_JOBS_LOCK:
                    # A poll can finish with an older database snapshot while
                    # the dispatcher is committing preparation/progress. Never
                    # replace its live revision or lease fence with that read.
                    if job_id not in _AUTO_MAP_ACTIVE_RUNNERS:
                        _AUTO_MAP_JOBS[job_id] = record
                if record.get("status") in {"queued", "running"}:
                    raw_envelope = record.get("request_envelope")
                    if isinstance(raw_envelope, dict):
                        try:
                            resumable_req = STTMBuilderEnvelopeRequest.model_validate(
                                raw_envelope
                            )
                        except Exception:
                            logger.exception(
                                "Durable Auto-map job %s contains an invalid request envelope",
                                job_id,
                            )
                        else:
                            self._launch_job_runner(
                                job_id,
                                req=resumable_req,
                                headers=headers,
                                owner=owner,
                                record=record,
                            )
        with _AUTO_MAP_JOBS_LOCK:
            record = record or _AUTO_MAP_JOBS.get(job_id)
            if record is None:
                raise HTTPException(status_code=404, detail="Auto-map job was not found")
            if record.get("owner") != owner:
                raise HTTPException(status_code=403, detail="Auto-map job belongs to another user")
            public = self._public_job(record)
        return self._with_runtime_progress(public, record, session)

    def _with_runtime_progress(self, public, record, session):
        """Best-effort read-only telemetry after normal job-owner authorization.

        No job GET acquires/reclaims capacity or authorizes model submission.
        """
        if session is None or public.get('status') != 'running' or not getattr(self._settings, 'automap_durable_runs_v2', False):
            return public
        table = getattr(self._settings, 'automap_parallel_permit_table_fqn', '')
        if record.get('call_tracking') == 'operation_v3':
            table = self._settings.qualify_metadata_object_name('TBL_AUTOMAP_CALL_OPERATIONS')
        archive = getattr(self._settings, 'automap_parallel_archive_table_fqn', '')
        import re
        if not all(type(name) is str and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_$]*(\.[A-Za-z_][A-Za-z0-9_$]*){2}', name) for name in (table,archive)):
            return public
        try:
            from app.core.automap_runtime import _session_identity
            caller = _session_identity(session, deadline=time.monotonic()+2)
            if caller.native_user != record.get('owner') or caller.role != record.get('recovery_role'):
                return public
            rows = session.sql(f"""SELECT CASE
                WHEN P.STATE = 'QUARANTINED' THEN 'recovering'
                WHEN P.STATE = 'FREE' THEN 'finalizing'
                WHEN P.MODEL_RUN_ID IS NOT NULL THEN 'model_run'
                WHEN P.SLOT_ID IS NOT NULL THEN 'thread_persist'
                ELSE '{'operation_claim' if record.get('call_tracking') == 'operation_v3' else 'admission_wait'}' END AS PHASE, COUNT(DISTINCT A.CONTENT_HASH) AS N
                FROM {archive} A LEFT JOIN {table} P
                ON P.CALLER_ID = A.OWNER_ID AND P.GENERATION = A.SNAPSHOT_ID
                AND P.JOB_ID = TRY_PARSE_JSON(A.BODY):value:job_id::VARCHAR
                AND P.SHARD_ID = TRY_PARSE_JSON(A.BODY):value:request:shard_id::VARCHAR
                WHERE A.OWNER_ID = ? AND A.ACCESS_SCOPE = ? AND A.CREATED_AT >= TO_TIMESTAMP_TZ(?)
                AND TRY_PARSE_JSON(A.BODY):value:protocol::VARCHAR = 'automap_fast_model_request_v1'
                AND TRY_PARSE_JSON(A.BODY):value:parent_request_id::VARCHAR = ?
                AND NOT EXISTS (SELECT 1 FROM {archive} R WHERE R.OWNER_ID = A.OWNER_ID
                    AND R.ACCESS_SCOPE = A.ACCESS_SCOPE AND R.SNAPSHOT_ID = A.SNAPSHOT_ID
                    AND TRY_PARSE_JSON(R.BODY):value:protocol::VARCHAR IN ('automap_fast_model_response_v1','automap_fast_model_failure_v1')
                    AND TRY_PARSE_JSON(R.BODY):value:request_archive_ref::VARCHAR = A.CONTENT_HASH)
                GROUP BY PHASE""",params=[caller.native_user,caller.access_scope,record['created_at'],record['request_id']]).collect(
                    statement_params={'STATEMENT_TIMEOUT_IN_SECONDS':'2','LOCK_TIMEOUT':'1'})
            phases = {}
            for row in rows:
                data=row.as_dict() if hasattr(row,'as_dict') else dict(row)
                if data.get('PHASE') in {'recovering','finalizing','model_run','thread_persist','admission_wait','operation_claim'} and type(data.get('N')) is int and 0 < data['N'] <= 64:
                    phases[data['PHASE']]=data['N']
            if phases:
                public={**public,'phase_counts':phases,'stage':next(phase for phase in ('model_run','thread_persist','operation_claim','admission_wait','recovering','finalizing') if phase in phases)}
        except Exception:
            logger.debug('Auto-map runtime progress unavailable; retaining durable job stage')
        return public

    def _public_job(self, record: dict[str, Any]) -> dict[str, Any]:
        private_fields = {"owner", "request_envelope", "acceptance_hash", "rejected_partial_receipts",
                          "recovery_session_id", "recovery_session_hash", "recovery_role"}
        public = {key: value for key, value in record.items() if key not in private_fields}
        expected_protocol='background_v2' if getattr(self._settings,'automap_durable_runs_v2',False) else 'legacy_sync_v1'
        if record.get('execution_protocol','legacy_sync_v1')!=expected_protocol and record.get('status') in {'queued','running'}:
            public.update(status='failed',stage='historical_execution_protocol',error={
                'code':'AUTO_MAP_EXECUTION_PROTOCOL_CHANGED',
                'message':'This job belongs to the previous execution protocol. Retained results remain available; start a new Auto-map for unfinished targets.'})
        if record.get("scoring_policy_version") != SCORING_POLICY_VERSION:
            # Preserve old evidence for inspection, never as applicable receipts.
            public.update(historical_result={"response": public.get("response"),
                "partial_responses": public.get("partial_responses", [])},
                response=None, partial_responses=[], results_applicable=False,
                completed_batch_count=0, completed_attribute_count=0)
            if public.get("status") in {"queued", "running"}:
                public.update(status="failed", error="Historical scoring policy; start a compatible new job.")
            return public
        if self._resolution_job(record) and record.get("partial_responses"):
            # A poll may hold the old durable revision, including when the
            # quarantine ACK fails. Never expose its rejected raw receipts.
            try:
                req = self._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(record["request_envelope"]))
                retained, rejected = self._resolution_receipts(req, record["partial_responses"])
                if rejected:
                    public.update(partial_responses=retained, **self._receipt_counts(req, retained))
            except Exception:
                public.update(partial_responses=[], completed_batch_count=0, completed_attribute_count=0)
        return public

    def _resolution_receipts(self, root, partials):
        plan = self._trusted_resolution_plan(root)
        pending = self._pending_resolution_request(root)
        preflight = plan.get("preflight") or {}
        entries = preflight.get("batches") or []
        attributes = {item.target_attribute: item for item in pending.data.attributes}
        retained, rejected, seen = [], [], set()
        for partial in partials:
            try:
                index = partial.get("batch_index")
                if type(index) is not int or not 0 <= index < len(entries) or index in seen:
                    raise ValueError("Invalid or duplicate batch index")
                entry = entries[index]
                batch = [attributes[name] for name in entry["target_attributes"]]
                if entry.get("rejection") or partial.get("batch_identity") != self._batch_identity(root, batch):
                    raise ValueError("Receipt does not match the admitted partition")
                names = [item.target_attribute for item in batch]
                if partial.get("target_attributes", names) != names or partial.get("attribute_count", len(names)) != len(names):
                    raise ValueError("Receipt target metadata does not match the batch")
                response = STTMBuilderResponse.model_validate(partial.get("response"))
                if (response.request_id != pending.request_id or response.operation != pending.operation
                        or response.error is not None or not response.data or response.data.status == STTMStatus.FAILED
                        or not isinstance(response.data.result, SourceMappingResult)
                        or set(response.data.result.mappings) != set(names)
                        or response.result != response.data.result):
                    raise ValueError("Receipt response does not match the request")
                if (any(warning.code in {"AUTO_MAPPING_TARGET_OMITTED", "parallel_stage_failed",
                        "parallel_read_budget_exceeded", "parallel_message_budget_exceeded"}
                        for warning in self._response_warnings(response))
                        or ((response.meta.get("auto_map_retrieval") or {}).get("parallel_preparation")
                            and (response.meta.get("auto_map_retrieval") or {}).get("model_call_count") == 0)):
                    raise ValueError("Receipt has no accepted worker result")
                batch_req = pending.model_copy(update={"data": pending.data.model_copy(update={"attributes": batch})})
                validated = self._resolution_batch_response(batch_req, response, index)
                if validated.result != response.result:
                    raise ValueError("Receipt contains an unaccepted mapping")
                seen.add(index)
                retained.append(partial)
            except Exception:
                rejected.append({"receipt_hash": self._resolution_digest(partial),
                    "reason": "invalid_frozen_partition_receipt"})
        return retained, rejected

    def _receipt_counts(self, root, partials):
        completed = sum(entry["status"] == "definition_preserved" and not entry["unresolved_values"]
                        for entry in self._trusted_resolution_plan(root)["targets"])
        for partial in partials:
            response = STTMBuilderResponse.model_validate(partial["response"])
            names = set(response.result.mappings)
            attributes = [item for item in root.data.attributes if item.target_attribute in names]
            response = self._resolution_partial_metadata(root, response, attributes)
            completed += len(names) - response.meta["auto_mapping_review"]["unresolved_count"]
        return {"completed_batch_count": len(partials), "completed_attribute_count": completed}

    def _quarantine_resolution_receipts(self, job_id, req, *, headers, session):
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS[job_id]
            partials = list(record.get("partial_responses") or [])
            audit = list(record.get("rejected_partial_receipts") or [])
        if not partials:
            return
        retained, rejected = self._resolution_receipts(req, partials)
        if rejected:
            self._update_job(job_id, headers=headers, session=session, require_persistence=True,
                partial_responses=retained, rejected_partial_receipts=audit + rejected,
                **self._receipt_counts(req, retained))

    @staticmethod
    def _resolution_job(record):
        return bool(((record.get("request_envelope") or {}).get("meta") or {}).get("auto_map_resolution_mode"))

    def _claim_job_lease(
        self,
        job_id: str,
        *,
        owner: str,
        headers: dict[str, str],
        session: Any | None = None,
    ) -> bool:
        """Atomically claim an expired/available durable job lease."""
        own_client: SnowflakeClient | None = None
        try:
            active_session = session
            if active_session is None:
                own_client = self._open_job_client(headers)
                active_session = own_client.session
            table = self._settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
            lease_owner = f"{self._settings.app_name}:{uuid.uuid4()}"
            active_session.sql(
                f"""
                UPDATE {table}
                SET LEASE_OWNER = ?,
                    LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP()),
                    ATTEMPT_COUNT = COALESCE(ATTEMPT_COUNT, 0) + 1,
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHERE JOB_ID = ?
                  AND OWNER_ID = ?
                  AND STATUS IN ('queued', 'running')
                  AND (LEASE_EXPIRES_AT IS NULL OR LEASE_EXPIRES_AT < CURRENT_TIMESTAMP())
                """,
                params=[lease_owner, _AUTO_MAP_LEASE_SECONDS, job_id, owner],
            ).collect()
            rows = active_session.sql(
                f"""
                SELECT LEASE_OWNER
                FROM {table}
                WHERE JOB_ID = ? AND OWNER_ID = ?
                LIMIT 1
                """,
                params=[job_id, owner],
            ).collect()
            if not rows:
                return False
            row = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
            claimed = str(row.get("LEASE_OWNER") or "") == lease_owner
            if claimed and (self._settings.automap_context_retrieval_v1 or self._resolution_job(_AUTO_MAP_JOBS.get(job_id) or {})):
                with _AUTO_MAP_JOBS_LOCK:
                    record = _AUTO_MAP_JOBS.get(job_id)
                    if record is not None:
                        record["dispatcher_lease_owner"] = lease_owner
            return claimed
        finally:
            if own_client is not None:
                own_client.close()

    def _renew_job_lease(self, job_id: str, *, headers: dict[str, str]) -> bool:
        with _AUTO_MAP_JOBS_LOCK:
            lease_owner = (_AUTO_MAP_JOBS.get(job_id) or {}).get("dispatcher_lease_owner")
        if not lease_owner:
            return False
        client = self._open_job_client(headers)
        try:
            table = self._settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
            rows = client.session.sql(
                f"UPDATE {table} SET LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP()) "
                "WHERE JOB_ID = ? AND LEASE_OWNER = ? AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP() "
                "AND STATUS IN ('queued', 'running')",
                params=[_AUTO_MAP_LEASE_SECONDS, job_id, lease_owner],
            ).collect()
            return bool(rows and int(rows[0][0]) == 1)
        finally:
            client.close()

    def _update_job(
        self,
        job_id: str,
        *,
        headers: dict[str, str] | None = None,
        session: Any | None = None,
        require_persistence: bool = False,
        **updates: Any,
    ) -> None:
        snapshot: dict[str, Any] | None = None
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS.get(job_id)
            if record is None:
                return
            original = record
            strict = self._resolution_job(record) and self._settings.auto_map_pipeline_v2
            if strict:
                record = deepcopy(record)
            record.update(updates)
            record["updated_at"] = datetime.now(UTC).isoformat()
            record["state_version"] = int(record.get("state_version") or 0) + 1
            snapshot = dict(record)
        if self._settings.auto_map_pipeline_v2 and snapshot is not None:
            self._persist_job(
                snapshot,
                headers=headers or {},
                session=session,
                required=require_persistence or strict,
            )
        if strict:
            with _AUTO_MAP_JOBS_LOCK:
                original.update(record)

    def _record_partial_response(
        self,
        job_id: str,
        *,
        batch_index: int,
        batch_attributes: list[Any],
        response: STTMBuilderResponse,
        headers: dict[str, str] | None = None,
        session: Any | None = None,
    ) -> None:
        snapshot: dict[str, Any] | None = None
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS.get(job_id)
            if record is None:
                return
            original = record
            strict = self._resolution_job(record) and self._settings.auto_map_pipeline_v2
            if strict:
                record = deepcopy(record)
            if record.get("scoring_policy_version") == SCORING_POLICY_VERSION and self._settings.auto_map_pipeline_v2:
                frozen = STTMBuilderEnvelopeRequest.model_validate(record["request_envelope"])
                self._check_draft_response(frozen, response)
                if response.meta.get("batch_identity") != self._batch_identity(
                        self._restore_resolution(frozen), batch_attributes):
                    raise SnowflakeAgentError("Partial receipt does not match the frozen scoring policy and batch")
            partials = list(record.get("partial_responses") or [])
            partials = [
                item
                for item in partials
                if int(item.get("batch_index", -1)) != batch_index
            ]
            durable_response = self._compact_partial_response(response)
            partials.append(
                {
                    "batch_index": batch_index,
                    "attribute_count": len(batch_attributes),
                    "target_attributes": [
                        getattr(attribute, "target_attribute", None)
                        for attribute in batch_attributes
                    ],
                    "response": durable_response.model_dump(mode="json"),
                    "batch_identity": response.meta.get("batch_identity"),
                    "completed_at": datetime.now(UTC).isoformat(),
                }
            )
            partials.sort(key=lambda item: int(item.get("batch_index", 0)))
            record["partial_responses"] = partials
            record["completed_batch_count"] = len(partials)
            record["completed_attribute_count"] = sum(
                int(item.get("attribute_count") or 0) for item in partials
            )
            if self._resolution_job(record):
                plan = (record["request_envelope"].get("meta") or {}).get(_RESOLUTION_PLAN_KEY) or {}
                record["completed_attribute_count"] = sum(
                    entry["status"] == "definition_preserved" and not entry["unresolved_values"]
                    for entry in plan.get("targets", [])) + sum(
                        max(0, int(item.get("attribute_count") or 0) - int(
                            ((item.get("response") or {}).get("meta", {}).get("auto_mapping_review") or {}).get("unresolved_count", 0)))
                        for item in partials)
            record["updated_at"] = datetime.now(UTC).isoformat()
            record["state_version"] = int(record.get("state_version") or 0) + 1
            record["stage"] = "transformation" if any(
                str(value.transformation_classification or "") == "complex"
                for value in (
                    response.data.result.mappings.values()
                    if response.data and isinstance(response.data.result, SourceMappingResult)
                    else []
                )
            ) else "source_mapping"
            expected_attributes = int(record.get("attribute_count") or 0)
            if (
                expected_attributes
                and int(record.get("completed_attribute_count") or 0)
                >= expected_attributes
            ):
                record["stage"] = "finalizing"
            snapshot = dict(record)
        if self._settings.auto_map_pipeline_v2 and snapshot is not None:
            self._persist_job(
                snapshot,
                headers=headers or {},
                session=session,
                required=strict,
            )
        if strict:
            with _AUTO_MAP_JOBS_LOCK:
                original.update(record)

    @staticmethod
    def _compact_partial_response(
        response: STTMBuilderResponse,
    ) -> STTMBuilderResponse:
        """Strip immutable prepared context from one durable batch result.

        The full request envelope already lives once on the job row. Persisting
        semantic YAML, FIR context, the workspace snapshot, and relation graph
        again for every partial caused cumulative Snowflake payload growth.
        """
        compact_context = response.context.model_copy(
            update={
                "semantic_context": None,
                "learning_context": None,
                "workspace_context": None,
                "execution_context": None,
                "relation_graph": None,
                "datahub_context": None,
                "derived_source_lineage": None,
                "artifact_refs": [],
            }
        )
        return response.model_copy(update={"context": compact_context})

    def _open_job_client(self, headers: dict[str, str]) -> SnowflakeClient:
        headers = self._fresh_worker_headers(headers)
        token = (
            headers.get("X-Workbench-OAuth-Access-Token")
            or headers.get("Sf-Context-Current-User-Token")
            or ""
        )
        role = headers.get("X-Workbench-OAuth-Role") or headers.get("X-Workbench-Caller-Role") or None
        if self._settings.local_dev_auth_enabled and not token:
            # Independent exclusive sessions for dispatcher and heartbeat; reuse
            # only after release, avoiding interactive SSO on every heartbeat.
            lease = get_local_transaction_pool(self._settings, role, WarehouseWorkload.AUTOMAP).lease()
            client = lease.__enter__()
            class LeasedClient:
                session = client.session
                def close(self):
                    lease.__exit__(None, None, None)
            return LeasedClient()
        return SnowflakeClient(self._settings, user_token=token, role=role)

    @staticmethod
    def _sql_literal(value: Any) -> str:
        return "'" + str(value if value is not None else "").replace("'", "''") + "'"

    def _persist_job(
        self,
        record: dict[str, Any],
        *,
        headers: dict[str, str],
        session: Any | None = None,
        required: bool,
    ) -> None:
        own_client: SnowflakeClient | None = None
        try:
            active_session = session
            if active_session is None:
                own_client = self._open_job_client(headers)
                active_session = own_client.session
            table = self._settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
            # Keep SQL-visible projections, but protect hash-bearing sections from
            # VARIANT numeric normalization (12.0 -> 12). Rebuild on every write;
            # never shadow mutable status, ownership, recovery or lease metadata.
            exact = {key: record[key] for key in
                     ("request_envelope", "partial_responses", "response") if key in record}
            modern = ((record.get('request_envelope') or {}).get('meta') or {}).get('automap_packet_policy') == 'frozen-packets-v1'
            if modern:
                from app.core.automap_stored_json import store_json, job_section_storage
                stored = {**record, **job_section_storage(exact), '_automap_exact_json': {
                    'encoding':'automap-exact-json-v2', 'payload':store_json(exact, force=True, preserve_order=True)}}
            else:
                stored = {**record, "_automap_exact_json": {
                    "encoding": "automap-exact-json-v1",
                    "json": json.dumps(exact, separators=(",", ":"), default=str, allow_nan=False),
                }}
            payload = json.dumps(stored, separators=(",", ":"), default=str)
            sql = f"""
                MERGE INTO {table} target
                USING (
                    SELECT ? AS JOB_ID,
                           ? AS REQUEST_ID,
                           ? AS OWNER_ID,
                           ? AS STATUS,
                           ? AS STAGE,
                           ? AS CONTEXT_HASH,
                           ? AS SEMANTIC_BUNDLE_ID,
                           PARSE_JSON(?) AS AGENT_SPEC_HASHES,
                           PARSE_JSON(?) AS JOB_STATE
                ) source
                ON target.JOB_ID = source.JOB_ID
                WHEN MATCHED
                  AND NOT (source.JOB_STATE:acceptance_hash IS NOT NULL
                           AND source.JOB_STATE:state_version::NUMBER = 0)
                  AND COALESCE(target.JOB_STATE:state_version::NUMBER, 0)
                      <= COALESCE(source.JOB_STATE:state_version::NUMBER, 0)
                  AND (source.JOB_STATE:dispatcher_lease_owner IS NULL OR (
                      target.LEASE_OWNER = source.JOB_STATE:dispatcher_lease_owner::STRING
                      AND target.LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()))
                THEN UPDATE SET
                    REQUEST_ID = source.REQUEST_ID,
                    OWNER_ID = source.OWNER_ID,
                    STATUS = source.STATUS,
                    STAGE = source.STAGE,
                    CONTEXT_HASH = source.CONTEXT_HASH,
                    SEMANTIC_BUNDLE_ID = source.SEMANTIC_BUNDLE_ID,
                    AGENT_SPEC_HASHES = source.AGENT_SPEC_HASHES,
                    JOB_STATE = source.JOB_STATE,
                    UPDATED_AT = CURRENT_TIMESTAMP(),
                    EXPIRES_AT = DATEADD('day', 7, CURRENT_TIMESTAMP())
                WHEN NOT MATCHED THEN INSERT (
                    JOB_ID, REQUEST_ID, OWNER_ID, STATUS, STAGE, CONTEXT_HASH,
                    SEMANTIC_BUNDLE_ID, AGENT_SPEC_HASHES, JOB_STATE
                ) VALUES (
                    source.JOB_ID, source.REQUEST_ID, source.OWNER_ID, source.STATUS,
                    source.STAGE, source.CONTEXT_HASH, source.SEMANTIC_BUNDLE_ID,
                    source.AGENT_SPEC_HASHES, source.JOB_STATE
                )
            """
            from app.core.automap_storage_sql import collect_storage_sql
            affected = collect_storage_sql(active_session,
                sql,
                params=[
                    str(record.get("job_id") or ""),
                    str(record.get("request_id") or ""),
                    str(record.get("owner") or ""),
                    str(record.get("status") or ""),
                    str(record.get("stage") or ""),
                    str(record.get("context_hash") or ""),
                    str(record.get("semantic_bundle_id") or ""),
                    json.dumps(record.get("agent_spec_hashes") or {}, separators=(",", ":")),
                    payload,
                ],
            )
            if required and self._resolution_job(record):
                values = []
                for row in affected:
                    if hasattr(row, "as_dict"):
                        values.extend(row.as_dict().values())
                    elif isinstance(row, dict):
                        values.extend(row.values())
                    else:
                        values.extend(row)
                if not values or sum(int(value) for value in values) != 1:
                    raise _AutoMapPersistenceError("Auto-map durable write was not acknowledged by exactly one affected row")
        except Exception as exc:
            logger.exception("Could not persist Auto-map job %s", record.get("job_id"))
            if required:
                if int(record.get("state_version") or 0) == 0:
                    with _AUTO_MAP_JOBS_LOCK:
                        _AUTO_MAP_JOBS.pop(str(record.get("job_id")), None)
                if self._resolution_job(record):
                    raise _AutoMapPersistenceError("Auto-map state was not durably acknowledged; no completion was published") from exc
                raise HTTPException(
                    status_code=503,
                    detail="Durable Auto-map job storage is unavailable; the job was not started.",
                ) from exc
        finally:
            if own_client is not None:
                own_client.close()

    @staticmethod
    def _load_job_state(state: Any) -> dict[str, Any] | None:
        """Decode durable sections before model validation or public/cache access."""
        if isinstance(state, str):
            state = json.loads(state)
        if not isinstance(state, dict):
            return None
        state = dict(state)
        if "_automap_exact_json" not in state:
            return state  # Legacy records retain all existing hash checks.
        wrapper = state.pop("_automap_exact_json")
        modern = isinstance(wrapper, dict) and wrapper.get('encoding') == 'automap-exact-json-v2'
        if modern:
            if set(wrapper) != {'encoding','payload'}:
                raise ValueError('Invalid Auto-map exact JSON encoding')
            from app.core.automap_stored_json import load_stored, job_section_storage
            exact_v2 = load_stored(wrapper['payload'])
            state.update(job_section_storage({key:state[key] for key in ('request_envelope','partial_responses','response') if key in state}, restore=True))
        elif (not isinstance(wrapper, dict) or set(wrapper) != {"encoding", "json"}
                or wrapper["encoding"] != "automap-exact-json-v1"
                or not isinstance(wrapper["json"], str)):
            raise ValueError("Invalid Auto-map exact JSON encoding")

        def unique_object(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError("Duplicate Auto-map exact JSON key")
                result[key] = value
            return result

        def invalid_constant(value):
            raise ValueError("Non-finite Auto-map exact JSON value")

        def finite_float(value):
            number = float(value)
            if not math.isfinite(number):
                raise ValueError("Non-finite Auto-map exact JSON number")
            return number

        def same_projection(projected, exact):
            if isinstance(exact, dict):
                return (isinstance(projected, dict) and set(projected) == set(exact)
                        and all(same_projection(projected[key], value) for key, value in exact.items()))
            if isinstance(exact, list):
                return (isinstance(projected, list) and len(projected) == len(exact)
                        and all(same_projection(left, right) for left, right in zip(projected, exact)))
            if type(exact) in (int, float):
                return type(projected) in (int, float) and projected == exact
            return type(projected) is type(exact) and projected == exact

        exact = exact_v2 if modern else json.loads(wrapper["json"], object_pairs_hook=unique_object,
                           parse_constant=invalid_constant, parse_float=finite_float)
        sections = {"request_envelope": dict, "partial_responses": list, "response": dict}
        if not isinstance(exact, dict) or set(exact) != set(state).intersection(sections):
            raise ValueError("Invalid Auto-map exact JSON sections")
        for key, value in exact.items():
            if value is not None and not isinstance(value, sections[key]):
                raise ValueError("Invalid Auto-map exact JSON section")
            # Numeric equality allows VARIANT's integral-float coercion; this is
            # only a stale-projection guard, not a replacement for hash proofs.
            if not same_projection(state[key], value):
                raise ValueError("Auto-map exact JSON projection changed")
        state.update(exact)
        return state

    def _load_persisted_job(
        self,
        job_id: str,
        *,
        owner: str,
        headers: dict[str, str],
        session: Any | None = None,
    ) -> dict[str, Any] | None:
        own_client: SnowflakeClient | None = None
        try:
            active_session = session
            if active_session is None:
                own_client = self._open_job_client(headers)
                active_session = own_client.session
            table = self._settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
            from app.core.automap_storage_sql import collect_storage_sql
            rows = collect_storage_sql(active_session,
                f"""
                SELECT JOB_STATE
                FROM {table}
                WHERE JOB_ID = ?
                  AND OWNER_ID = ?
                  AND EXPIRES_AT > CURRENT_TIMESTAMP()
                LIMIT 1
                """,
                params=[job_id, owner],
            )
            if not rows:
                return None
            row = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
            return self._load_job_state(row.get("JOB_STATE"))
        except Exception as exc:
            logger.exception("Could not load durable Auto-map job %s", job_id)
            raise HTTPException(
                status_code=503,
                detail="Durable Auto-map job storage is temporarily unavailable.",
            ) from exc
        finally:
            if own_client is not None:
                own_client.close()

    @staticmethod
    def _prune_jobs() -> None:
        cutoff = time.time() - _AUTO_MAP_JOB_TTL_SECONDS
        with _AUTO_MAP_JOBS_LOCK:
            expired = []
            for job_id, record in _AUTO_MAP_JOBS.items():
                created_at = str(record.get("created_at") or "")
                try:
                    timestamp = datetime.fromisoformat(created_at).timestamp()
                except ValueError:
                    timestamp = 0
                if timestamp < cutoff:
                    expired.append(job_id)
            for job_id in expired:
                _AUTO_MAP_JOBS.pop(job_id, None)

    def invoke(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderResponse:
        if not self.should_delegate(req):
            raise SnowflakeAgentError("Auto-mapping worker service is not configured.")

        headers = self._forward_headers(request)
        req = req.model_copy(update={"meta": self._without_resolution_meta(req.meta)})
        return self._invoke_with_headers(req, headers=headers)

    def _invoke_with_headers(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        headers: dict[str, str],
        progress_callback: Callable[[int, list[Any], STTMBuilderResponse], None] | None = None,
        resume_partials: list[dict[str, Any]] | None = None,
    ) -> STTMBuilderResponse:
        req = self._freeze_resolution(req)
        plan = self._trusted_resolution_plan(req)
        if plan:
            pending = self._pending_resolution_request(req)
            if not pending.data.attributes:
                return self._complete_resolution_response(req)
            response = self._invoke_worker_batches(pending, headers=headers, progress_callback=progress_callback,
                resume_partials=resume_partials, resolution_root=req)
            return self._complete_resolution_response(req, response)
        return self._invoke_worker_batches(req, headers=headers, progress_callback=progress_callback,
                                          resume_partials=resume_partials)

    def _invoke_worker_batches(self, req, *, headers, progress_callback=None, resume_partials=None,
                              resolution_root=None):
        attributes = list(req.data.attributes or [])
        batches = self._build_batches(resolution_root or req)
        plan = self._trusted_resolution_plan(resolution_root) if resolution_root is not None else None
        preflight = plan.get("preflight") if plan else None
        rejected = {index: entry["rejection"] for index, entry in enumerate(preflight["batches"])
                    if entry.get("rejection")} if preflight else {}
        strict_identity = self._settings.automap_context_retrieval_v1 or resolution_root is not None or req.meta.get(SCORING_META_KEY) is not None
        resumed_responses: dict[int, STTMBuilderResponse] = {}
        if resolution_root is not None:
            resume_partials, _ = self._resolution_receipts(resolution_root, resume_partials or [])
        for partial in resume_partials or []:
            try:
                batch_index = int(partial.get("batch_index", -1))
                if batch_index in rejected:
                    continue  # A local budget rejection can never be a worker receipt.
                if partial.get("batch_identity") and not strict_identity:
                    raise SnowflakeAgentError("Retrieval job resume is disabled; start a new job after its strategy is accepted")
                if strict_identity and (
                    not 0 <= batch_index < len(batches)
                    or partial.get("batch_identity") != self._batch_identity(resolution_root or req, batches[batch_index])
                ):
                    continue
                partial_response = STTMBuilderResponse.model_validate(
                    partial.get("response")
                )
                if req.meta.get(SCORING_META_KEY):
                    self._check_draft_response(req, partial_response)
                if resolution_root is not None and (partial_response.request_id != req.request_id
                        or partial_response.operation != req.operation or partial_response.error is not None
                        or not partial_response.data or partial_response.data.status == STTMStatus.FAILED):
                    continue
                if resolution_root is not None and (
                    any(warning.code in {"AUTO_MAPPING_TARGET_OMITTED", "parallel_stage_failed",
                        "parallel_read_budget_exceeded", "parallel_message_budget_exceeded"}
                        for warning in self._response_warnings(partial_response))
                    or ((partial_response.meta.get("auto_map_retrieval") or {}).get("parallel_preparation")
                        and (partial_response.meta.get("auto_map_retrieval") or {}).get("model_call_count") == 0)):
                    continue
                if strict_identity:
                    result = partial_response.data.result if partial_response.data else partial_response.result
                    if not isinstance(result, SourceMappingResult) or set(result.mappings) != {
                        item.target_attribute for item in batches[batch_index]
                    }:
                        continue
                    if resolution_root is not None:
                        batch_request = req.model_copy(update={"data": req.data.model_copy(update={"attributes": batches[batch_index]})})
                        partial_response = self._resolution_batch_response(batch_request, partial_response, batch_index)
                        partial_response = self._resolution_partial_metadata(resolution_root, partial_response, batches[batch_index])
            except SnowflakeAgentError:
                if resolution_root is not None:
                    continue
                raise
            except Exception:
                logger.warning(
                    "Ignoring invalid persisted Auto-map partial for request_id=%s",
                    req.request_id,
                )
                continue
            if batch_index >= 0:
                resumed_responses[batch_index] = partial_response
        # Sheet review requires individually validated complete options from the
        # worker; a historical scalar shortcut is not that response contract.
        precedent_response = None if (self._settings.automap_context_retrieval_v1
            or req.meta.get("auto_map_sheet_review_v1")) else self._exact_precedent_response(req)
        if precedent_response is not None:
            self._demote_undefined_firm_values(precedent_response, req=req)
            if 0 in resumed_responses:
                return resumed_responses[0]
            if progress_callback is not None:
                progress_callback(0, attributes, precedent_response)
            return precedent_response

        logger.info(
            "Dispatching auto-map request_id=%s attributes=%s batches=%s max_in_flight=%s",
            req.request_id,
            len(attributes),
            len(batches),
            self._max_in_flight,
        )
        responses: dict[int, STTMBuilderResponse] = {
            index: response
            for index, response in resumed_responses.items()
            if 0 <= index < len(batches)
        }
        for index, rejection in rejected.items():
            responses[index] = self._preflight_rejection_response(req, batches[index], rejection)
        failures: dict[int, Exception] = {}
        pending_indices = [
            index for index in range(len(batches)) if index not in responses
        ]
        deadline = req.meta.get("_automap_deadline") if resolution_root is not None else None
        if deadline and getattr(self._settings,'automap_durable_runs_v2',False):
            deadline += self._settings.automap_queue_seconds
        if deadline and time.time() >= deadline:
            failures.update({index: SnowflakeAgentError("Auto-map request deadline exceeded") for index in pending_indices})
            pending_indices = []
        logger.info("Auto-map batches queued request_id=%s batches=%s at=%.6f", req.request_id, pending_indices, time.time())
        executor = ThreadPoolExecutor(
            max_workers=min(self._max_in_flight, max(1, len(pending_indices)))
        )
        futures = {}
        try:
            futures = {
                executor.submit(
                    self._invoke_complete_batch,
                    req.model_copy(
                        update={
                            "data": req.data.model_copy(update={"attributes": batch}),
                            "meta": {
                                **req.meta,
                                "auto_mapping_batch_index": index,
                                **({"_automap_frozen_packet": preflight["batches"][index]["frozen_packet"],
                                    "_automap_fast_handoff": {**req.meta["_automap_fast_handoff"],
                                        "packet_digest": preflight["batches"][index]["frozen_packet"]["receipt_digest"]}}
                                   if preflight and preflight["batches"][index].get("frozen_packet") and isinstance(req.meta.get("_automap_fast_handoff"), dict) else {}),
                                # Each batch runs its own complex-transformation
                                # stage; nothing resumes a deferred one, so a
                                # deferral left CAST/CONCAT/lookup rows as Direct.
                            },
                        }
                    ),
                    headers=headers,
                    batch_index=index,
                    **({"planned_model_payload": preflight["batches"][index]["diagnostics"]} if preflight else {}),
                ): index
                for index, batch in enumerate(batches)
                if index in pending_indices
            }
            completions = as_completed(futures, timeout=max(0.0, deadline - time.time()) if deadline else None)
            for future in completions:
                index = futures[future]
                try:
                    if deadline and time.time() >= deadline:
                        raise SnowflakeAgentError("Auto-map request deadline exceeded; late result was not accepted")
                    responses[index] = future.result()
                    if req.meta.get(SCORING_META_KEY) is not None:
                        self._check_draft_response(req, responses[index])
                        responses[index].meta["batch_identity"] = self._batch_identity(resolution_root or req, batches[index])
                    if resolution_root is not None:
                        batch_request = req.model_copy(update={"data": req.data.model_copy(update={"attributes": batches[index]})})
                        responses[index] = self._resolution_batch_response(batch_request, responses[index], index)
                        responses[index] = self._resolution_partial_metadata(resolution_root, responses[index], batches[index])
                        responses[index].meta = {**responses[index].meta,
                            "batch_identity": self._batch_identity(resolution_root, batches[index])}
                    incomplete = resolution_root is not None and (
                        any(warning.code == "AUTO_MAPPING_TARGET_OMITTED" for warning in self._response_warnings(responses[index]))
                        or ((responses[index].meta.get("auto_map_retrieval") or {}).get("parallel_preparation")
                            and (responses[index].meta.get("auto_map_retrieval") or {}).get("model_call_count") == 0))
                    if progress_callback is not None and not incomplete:
                        progress_callback(index, batches[index], responses[index])
                except _AutoMapPersistenceError:
                    raise
                except Exception as exc:
                    responses.pop(index, None)
                    failures[index] = exc
        except FutureTimeoutError:
            for future, index in futures.items():
                if index not in responses and index not in failures:
                    failures[index] = SnowflakeAgentError("Auto-map request deadline exceeded; no result was accepted")
                    future.cancel()
        finally:
            # A running in-process call retains its permit until it exits. It
            # cannot publish a late partial after the parent stops waiting.
            executor.shutdown(wait=resolution_root is None, cancel_futures=True)

        if not responses and resolution_root is None:
            first_failure = failures[min(failures)]
            raise SnowflakeAgentError(
                f"All Auto-map worker batches failed: {first_failure}"
            ) from first_failure

        incomplete_batches = {
            index for index, response in responses.items()
            if (response.meta.get("auto_map_retrieval") or {}).get("parallel_preparation")
            and ((response.meta.get("auto_map_retrieval") or {}).get("model_call_count") == 0
                 or any(warning.code in {"parallel_stage_failed", "parallel_read_budget_exceeded",
                                         "parallel_message_budget_exceeded"}
                        for warning in self._response_warnings(response)))
        }
        # Persist failed fast receipts so resume cannot replay uncertain calls.
        incomplete_batches.update(index for index, response in responses.items()
            if (response.meta.get("auto_map_retrieval") or {}).get("auto_map_fast_path")
            and any(warning.code in {"auto_map_fast_stage_failed", "auto_map_fast_read_budget_exceeded",
                                     "auto_map_fast_message_budget_exceeded"}
                    for warning in self._response_warnings(response)))
        if resolution_root is not None:
            incomplete_batches.update(index for index, response in responses.items()
                if any(warning.code == "AUTO_MAPPING_TARGET_OMITTED" for warning in self._response_warnings(response)))
        failed_or_incomplete = set(failures) | incomplete_batches | set(rejected)
        worker_responses = {index: response for index, response in responses.items() if index not in rejected}
        first_responses = worker_responses or responses
        first = first_responses[min(first_responses)] if first_responses else STTMBuilderResponse.from_invocation(
            req, thread_id=None, parent_message_id=None, agent=None, result=SourceMappingResult(mappings={}),
            message="No worker mappings completed.", status=STTMStatus.NEEDS_INPUT)
        merged_mappings: dict[str, AttributeMapping] = {}
        merged_warnings = []
        for index, batch in enumerate(batches):
            response = responses.get(index)
            if response is not None:
                merged_warnings.extend(self._response_warnings(response))
            response_result = response.data.result if response and response.data else None
            if not isinstance(response_result, SourceMappingResult):
                response_result = response.result if response else None
            if isinstance(response_result, SourceMappingResult):
                merged_mappings.update(response_result.mappings)
                continue
            failure = failures.get(index)
            for attribute in batch:
                key = attribute.target_attribute
                merged_mappings[key] = AttributeMapping(
                    source_attributes=[],
                    confidence_score=0.0,
                    transformation_classification="unresolved",
                    unmatched_reason=(
                        "The dedicated Auto-map worker could not process this target attribute."
                    ),
                )
                merged_warnings.append(
                    ApiWarning(
                        code="AUTO_MAPPING_BATCH_FAILED",
                        message=f"Auto-map batch {index + 1} failed: {failure}",
                        field=key,
                    )
                )

        ordered_mappings: dict[str, AttributeMapping] = {}
        for attribute in attributes:
            target = str(attribute.target_attribute)
            if target in merged_mappings:
                ordered_mappings[target] = merged_mappings[target]
        for target, mapping in merged_mappings.items():
            ordered_mappings.setdefault(target, mapping)
        merged_result = SourceMappingResult(mappings=ordered_mappings)
        review_message, mapping_review = self._build_mapping_review(ordered_mappings)
        failed_target_count = sum(len(batches[index]) for index in failures)
        if failed_or_incomplete:
            review_message = (
                f"Auto-map has incomplete coverage in {len(failed_or_incomplete)}/{len(batches)} batches. "
                "Grounded mappings were preserved; unresolved targets need review. "
                + review_message
            )
            mapping_review = {**mapping_review, "headline": review_message,
                              "failed_batch_count": len(failed_or_incomplete),
                              "infrastructure_failed_count": failed_target_count}
        merged_data = first.data.model_copy(
            update={
                "result": merged_result,
                "message": review_message,
                "status": STTMStatus.NEEDS_INPUT if failed_or_incomplete or mapping_review["action_required_count"] else STTMStatus.COMPLETED,
            }
        ) if first.data else None
        from app.core.sttm_builder import STTMBuilderService
        merged_warnings = STTMBuilderService._auto_map_response_warnings(merged_warnings)
        parallel = any((response.meta.get("auto_map_retrieval") or {}).get("parallel_preparation")
                       for response in responses.values())
        from app.core.automap_batch import canonical_model_wire_request
        merged_response = first.model_copy(
            update={
                # Resumable partials intentionally omit the large immutable
                # prepared context. Reattach only its governed response view.
                "context": canonical_model_wire_request(req, wire=False).context,
                "data": merged_data,
                "result": merged_result,
                "message": review_message,
                "warnings": merged_warnings,
                "meta": {
                    **first.meta,
                    "auto_map_target_bindings": {name:binding for response in responses.values()
                        for name,binding in (response.meta.get("auto_map_target_bindings") or {}).items()},
                    "automap_evidence_review_only_targets": sorted({target for response in responses.values()
                        for target in response.meta.get("automap_evidence_review_only_targets", [])
                        if isinstance(target, str) and target in {item.target_attribute for item in req.data.attributes or []}}),
                    **({"assistant_context": STTMBuilderService._auto_map_assistant_context(merged_warnings)}
                       if parallel else {}),
                    "auto_map_retrieval_batches": [
                        {"batch_index": index, **response.meta["auto_map_retrieval"]}
                        for index, response in sorted(responses.items())
                        if isinstance(response.meta.get("auto_map_retrieval"), dict)
                    ],
                    "transformation_stage_batches": [
                        {"batch_index": index, **response.meta["transformation_stage"]}
                        for index, response in sorted(responses.items())
                        if isinstance(response.meta.get("transformation_stage"), dict)
                    ],
                    "auto_map_preparation_ms": plan.get("preparation_ms") if plan else None,
                    "auto_map_batch_metrics": [
                        {"batch_index": index, "target_count": len(batches[index]),
                         "source_model_call_count": (response.meta.get("auto_map_retrieval") or {}).get("source_model_call_count",
                             (response.meta.get("auto_map_retrieval") or {}).get("model_call_count")),
                         "total_model_call_count": (response.meta.get("auto_map_retrieval") or {}).get("model_call_count"),
                         "transformation_ms": (response.meta.get("auto_mapping_worker") or {}).get("selective_transformation_stage_ms"),
                         "timings_ms": (response.meta.get("auto_map_retrieval") or {}).get("timings_ms"),
                         "elapsed_seconds": (response.meta.get("auto_map_retrieval") or {}).get("elapsed_seconds")}
                        for index, response in sorted(responses.items())],
                    "auto_mapping_dispatch": {
                        "attribute_count": len(attributes),
                        "batch_count": len(batches),
                        "batch_size": self._batch_size,
                        "batch_sizes": [len(batch) for batch in batches],
                        "batching_mode": "fast_pending_targets_v2" if req.meta.get("auto_map_fast_path") == "v1" else "balanced_exact_batch_v2" if self._settings.automap_context_retrieval_v1 else "adaptive_complexity_token_budget",
                        "max_in_flight": self._max_in_flight,
                        "resumed_batch_indices": sorted(responses.keys() & resumed_responses.keys()),
                        "failed_batches": sorted(failed_or_incomplete),
                        **({"preflight_hash": plan["preflight_hash"],
                            "preflight_rejected_batches": sorted(rejected),
                            "preflight_rejections": [dict(rejection, batch_index=index,
                                preflight_hash=plan["preflight_hash"],
                                batch_identity=self._batch_identity(resolution_root, batches[index]))
                                for index, rejection in rejected.items()]} if rejected else {}),
                        **({"incomplete_worker_batches": sorted(incomplete_batches)} if incomplete_batches else {}),
                    },
                    **({"auto_mapping_coverage": {"complete_coverage": False,
                        "requested": len(attributes), "returned": len(ordered_mappings),
                        "preflight_rejected_targets": [item.target_attribute for index in rejected for item in batches[index]],
                        "preflight_hash": plan["preflight_hash"]}} if rejected else {}),
                    "auto_mapping_review": mapping_review,
                },
            }
        )
        return merged_response

    def _apply_global_complex_transform(
        self,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
        *,
        headers: dict[str, str],
    ) -> STTMBuilderResponse:
        """Invoke AGT_TRANSFORMATION_RULE once after all source batches merge."""
        result = response.data.result if response.data else response.result
        if not isinstance(result, SourceMappingResult):
            return response
        attributes_by_target = {
            self._normalized_target(item.target_attribute): item
            for item in (req.data.attributes or [])
        }
        complex_targets = [
            target
            for target, mapping in result.mappings.items()
            if mapping.precedent_decision in {"override_precedent", "unresolved", None}
            and (
                mapping.transformation_classification == "complex"
                or str(mapping.preprocessing_rule_type or "").upper() == "CUSTOM"
            )
        ]
        transform_attributes = []
        for target in complex_targets:
            original = attributes_by_target.get(self._normalized_target(target))
            if original is None:
                continue
            refs: list[AttributeRef] = []
            for source in result.mappings[target].source_attributes:
                parts = source.split(".")
                if len(parts) == 4:
                    refs.append(
                        AttributeRef(
                            table=TableRef(database=parts[0], schema=parts[1], table=parts[2]),
                            attribute=parts[3],
                        )
                    )
            transform_attributes.append(
                original.model_copy(update={"source_mappings": refs or None})
            )
        if not transform_attributes:
            return response
        transform_req = req.model_copy(
            update={
                "operation": STTMOperation.TRANSFORM,
                "data": req.data.model_copy(
                    update={
                        "intent": Interface.TRANSFORM,
                        "intent_route": "transformation_rule",
                        "attributes": transform_attributes,
                        "message": (
                            "Generate only attribute-level expressions for the merged complex "
                            "mappings. Preserve compiler-owned joins."
                        ),
                    }
                ),
                "context": req.context.model_copy(
                    update={"routing_hint": "transformation_rule"}
                ),
                "meta": {
                    **req.meta,
                    "auto_map_stage": "global_complex_transformation",
                },
            }
        )
        started = time.perf_counter()
        transformed = self._invoke_batch(
            transform_req,
            headers=headers,
            batch_index=len(self._build_batches(req)),
        )
        transform_result = transformed.data.result if transformed.data else transformed.result
        if not isinstance(transform_result, TransformationResult):
            return response.model_copy(
                update={
                    "warnings": [
                        *response.warnings,
                        ApiWarning(
                            code="AUTO_MAP_TRANSFORMATION_STAGE_SKIPPED",
                            message="The global complex transformation stage returned no validated rules.",
                        ),
                    ]
                }
            )
        rules = {
            self._normalized_target(rule.target_attribute): rule
            for rule in transform_result.rules
        }
        mappings = dict(result.mappings)
        for target in complex_targets:
            rule = rules.get(self._normalized_target(target))
            if rule is None:
                continue
            current = mappings[target]
            mappings[target] = current.model_copy(
                update={
                    "preprocessing_rule": rule.rule,
                    "preprocessing_rule_type": "Custom",
                    "preprocessing_nl_rule": rule.description,
                    "transformation_classification": "complex",
                    "used_inference_ids": sorted({*current.used_inference_ids, *rule.used_inference_ids}),
                    "used_recommendation_ids": sorted({*current.used_recommendation_ids, *rule.used_recommendation_ids}),
                }
            )
        merged_result = SourceMappingResult(mappings=mappings)
        merged_data = response.data.model_copy(update={"result": merged_result}) if response.data else None
        return response.model_copy(
            update={
                "data": merged_data,
                "result": merged_result,
                "warnings": [*response.warnings, *transformed.warnings],
                "meta": {
                    **response.meta,
                    "transformation_stage": {
                        "agent": "AGT_TRANSFORMATION_RULE",
                        "invocation_count": 1,
                        "target_count": len(transform_attributes),
                        "duration_ms": round((time.perf_counter() - started) * 1000, 1),
                    },
                },
            }
        )

    @staticmethod
    def _normalized_target(value: Any) -> str:
        return str(value or "").rsplit(".", 1)[-1].strip().upper()

    @classmethod
    def _missing_batch_attributes(
        cls,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
    ) -> list[Any]:
        result = response.data.result if response.data else None
        if not isinstance(result, SourceMappingResult):
            result = response.result
        returned = {
            cls._normalized_target(target)
            for target in (result.mappings if isinstance(result, SourceMappingResult) else {})
        }
        return [
            attribute
            for attribute in (req.data.attributes or [])
            if cls._normalized_target(attribute.target_attribute) not in returned
        ]

    @staticmethod
    def _response_warnings(response: STTMBuilderResponse) -> list[ApiWarning]:
        from app.core.sttm_builder import STTMBuilderService
        retrieval = response.meta.get("auto_map_retrieval") or {}
        parallel = retrieval.get("parallel_preparation") or {}
        return STTMBuilderService._auto_map_response_warnings(
            response.warnings, retrieval.get("warnings", []), parallel.get("warnings", []))

    @staticmethod
    def _merge_batch_responses(
        base: STTMBuilderResponse,
        addition: STTMBuilderResponse,
    ) -> STTMBuilderResponse:
        base_result = base.data.result if base.data else base.result
        addition_result = addition.data.result if addition.data else addition.result
        if not isinstance(base_result, SourceMappingResult):
            return addition
        if not isinstance(addition_result, SourceMappingResult):
            return base
        merged_result = SourceMappingResult(
            mappings={**base_result.mappings, **addition_result.mappings}
        )
        merged_data = (
            base.data.model_copy(update={"result": merged_result})
            if base.data is not None
            else None
        )
        attempts = []
        for response in (base, addition):
            recorded = response.meta.get("agent_payload_attempts")
            if isinstance(recorded, list):
                attempts.extend(recorded)
            elif response.meta.get("agent_payload"):
                attempts.append(response.meta["agent_payload"])
        from app.core.sttm_builder import STTMBuilderService
        warnings = STTMBuilderService._auto_map_response_warnings(
            AutoMappingProxyClient._response_warnings(base), AutoMappingProxyClient._response_warnings(addition))
        parallel = any((response.meta.get("auto_map_retrieval") or {}).get("parallel_preparation")
                       for response in (base, addition))
        return base.model_copy(
            update={
                "data": merged_data,
                "result": merged_result,
                "warnings": warnings,
                "meta": {**base.meta, "agent_payload_attempts": attempts,
                         **({"assistant_context": STTMBuilderService._auto_map_assistant_context(warnings)}
                            if parallel else {})},
            }
        )

    @staticmethod
    def _fast_response_diagnostics(response: STTMBuilderResponse) -> dict[str, Any]:
        """Read worker diagnostics, not the echoed root fast-path selector.

        Missing/null optional objects mean no diagnostics. Malformed objects or
        retry controls are contract failures, never evidence of a successful run.
        """
        diagnostics = response.meta
        path = "meta"
        for key in ("auto_map_retrieval", "auto_map_fast_path", "fast_diagnostics"):
            path += "." + key
            diagnostics = diagnostics.get(key)
            if diagnostics is None:
                return {}
            if not isinstance(diagnostics, dict):
                raise SnowflakeAgentError(
                    f"AUTO_MAPPING_INVALID_FAST_DIAGNOSTICS: {path} must be an object or null."
                )
        for key in ("failure_kind", "stop_reason"):
            value = diagnostics.get(key)
            if value is not None and not isinstance(value, str):
                raise SnowflakeAgentError(
                    f"AUTO_MAPPING_INVALID_FAST_DIAGNOSTICS: {path}.{key} must be a string or null."
                )
        return diagnostics

    @staticmethod
    def _validated_retry_candidate(mapping: AttributeMapping) -> bool:
        chosen = mapping.selected_candidate_id or mapping.draft_candidate_id
        return any(candidate.candidate_id == chosen and candidate.validation_status == 'valid'
                   for candidate in mapping.candidates)

    def _invoke_complete_batch(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        headers: dict[str, str],
        batch_index: int,
        planned_model_payload: dict[str, Any] | None = None,
    ) -> STTMBuilderResponse:
        """Repair a successful-but-truncated agent batch before returning it."""
        logger.info("Auto-map batch started request_id=%s batch=%s at=%.6f", req.request_id, batch_index, time.time())
        self._remaining_worker_timeout(req)
        from app.core.sttm_builder import STTMBuilderService
        if self._settings.automap_context_retrieval_v1 or req.meta.get("auto_map_parent_resolution_version"):
            if planned_model_payload is None:
                planned_model_payload = STTMBuilderService.project_agent_payload(req, self._settings).diagnostics
            response = self._invoke_batch(req, headers=headers, batch_index=batch_index)
            if getattr(self._settings,'automap_durable_runs_v2',False):
                retained = response
                diag = self._fast_response_diagnostics(response)
                # Worker call counts are evidence, not the number of proxy POSTs.
                # Never trust echoed/request-provided aggregate provenance.
                retained.meta.pop('durable_model_provenance', None)
                counts = []

                def record_attempt(worker):
                    count = (worker.meta.get('auto_map_retrieval') or {}).get('model_call_count')
                    count = count if type(count) is int and count >= 0 else None
                    counts.append(count)
                    result = worker.data.result if worker.data else worker.result
                    return {target: self._resolution_digest(mapping.model_dump(mode='json'))
                            for target, mapping in result.mappings.items()
                            if count and self._validated_retry_candidate(mapping)} if isinstance(result, SourceMappingResult) else {}

                proven_results = record_attempt(response)
                for attempt in range(self._settings.automap_run_retry_attempts):
                    if diag.get('stop_reason')=='canceled' or diag.get('pre_submission_failure') is True:break
                    if diag.get('failure_kind') not in {'transport','stopped','admission_unavailable','admission_claim_uncertain','admission_contended'}:
                        break
                    self._remaining_worker_timeout(req)
                    time.sleep(min(4,2**attempt))
                    response=self._invoke_batch(req,headers=headers,batch_index=batch_index)
                    latest = self._fast_response_diagnostics(response)
                    latest_proven_results = record_attempt(response)
                    merged=self._merge_batch_responses(retained,response)
                    previous=retained.data.result if retained.data else retained.result
                    current=merged.data.result if merged.data else merged.result
                    retained_targets = []
                    if isinstance(previous,SourceMappingResult) and isinstance(current,SourceMappingResult):
                        for target,mapping in previous.mappings.items():
                            if (self._validated_retry_candidate(mapping)
                                    and proven_results.get(target) == self._resolution_digest(mapping.model_dump(mode='json'))):
                                current.mappings[target]=mapping
                                retained_targets.append(target)
                    latest_proven_results.update({target: proven_results[target]
                        for target in retained_targets if target in proven_results})
                    proven_results = latest_proven_results
                    # Use the established one-level dictionary merge for bindings,
                    # but preserve the latest diagnostic object verbatim for control.
                    payload_attempts = merged.meta.get('agent_payload_attempts', [])
                    merged.meta = STTMBuilderService._merge_agent_meta(merged.meta, response.meta)
                    merged.meta.update(agent_payload_attempts=payload_attempts,
                        auto_map_retrieval=response.meta.get('auto_map_retrieval'),
                        durable_transport_retries=attempt+1,
                        durable_model_provenance={'attempt_model_call_counts': list(counts),
                            'model_call_count': sum(counts) if all(count is not None for count in counts) else None,
                            'validated_results': dict(proven_results)})
                    bindings = dict(merged.meta.get('auto_map_target_bindings') or {})
                    prior_bindings = retained.meta.get('auto_map_target_bindings') or {}
                    for target in retained_targets:
                        if target in prior_bindings:
                            bindings[target] = prior_bindings[target]
                    if bindings:
                        merged.meta['auto_map_target_bindings'] = bindings
                    history=list(retained.meta.get('durable_transport_history') or [])
                    history.append({'attempt':attempt,'failure_kind':diag.get('failure_kind')})
                    merged.meta['durable_transport_history']=history
                    complete=isinstance(current,SourceMappingResult) and all(
                        name in current.mappings and any(
                            candidate.candidate_id==(current.mappings[name].selected_candidate_id or current.mappings[name].draft_candidate_id)
                            and candidate.validation_status=='valid' for candidate in current.mappings[name].candidates)
                        for name in (a.target_attribute for a in req.data.attributes or []))
                    if complete and not latest.get('failure_kind') and response.error is None:
                        # Earlier transient attempt failures are technical history,
                        # not a failure of the now-complete, validated batch. Keep
                        # every current warning and every business/validation issue.
                        fresh={(w.code,w.field) for w in self._response_warnings(response)}
                        merged.warnings=[w for w in self._response_warnings(merged)
                            if w.code not in {'auto_map_fast_stage_failed','admission_wait'} or (w.code,w.field) in fresh]
                        merged.error=response.error
                        merged.message=response.message
                        if merged.data is not None and response.data is not None:
                            merged.data=merged.data.model_copy(update={'status':response.data.status,'message':response.data.message})
                    retained=merged
                    diag = latest
                response=retained
            response = response.model_copy(update={"warnings": self._response_warnings(response)})
            response.meta = {**response.meta, "batch_identity": self._batch_identity(req, list(req.data.attributes or [])),
                             "planned_model_payload": planned_model_payload}
            # The batch engine supplies explicit unresolved rows for omissions;
            # never create hidden child worker calls or per-target retries.
            return response
        projection_error = None
        try:
            projection = STTMBuilderService.project_agent_payload(req, self._settings)
        except AgentPayloadBudgetError as exc:
            # Resumed jobs can have been planned with a different worker budget.
            projection = None
            projection_error = exc
        planned_projection = {
            **(projection.diagnostics if projection is not None else {"split_reason": "local_context_budget"}),
            "sha256": hashlib.sha256(projection.text.encode("utf-8")).hexdigest() if projection is not None else None,
            "target_count": len(req.data.attributes or []),
            "effective_max_in_flight": self._max_in_flight,
        }
        pending_req = req
        merged: STTMBuilderResponse | None = None
        for _attempt in range(max(1, self._retry_attempts)):
            try:
                if projection_error is not None:
                    error, projection_error = projection_error, None
                    raise error
                response = self._invoke_batch(pending_req, headers=headers, batch_index=batch_index)
            except AutoMappingTransportTooLargeError:
                # Target subdivision does not shrink the shared prepared context.
                raise
            except (AgentPayloadBudgetError, HTTPException, SnowflakeAgentError) as exc:
                detail = str(getattr(exc, "detail", exc)).lower()
                oversized = isinstance(exc, AgentPayloadBudgetError) or getattr(exc, "status_code", None) == 413 or any(
                    token in detail for token in ("payload_required_context_too_large", "context window", "too many tokens", "payload too large", "http 413")
                )
                pending = list(pending_req.data.attributes or [])
                if not oversized or len(pending) < 2:
                    raise
                midpoint = len(pending) // 2
                children = []
                # Reuse the bounded host executor, without nested concurrency.
                for group in (pending[:midpoint], pending[midpoint:]):
                    child = pending_req.model_copy(update={
                        "data": pending_req.data.model_copy(update={"attributes": group}),
                    })
                    children.append(self._invoke_complete_batch(child, headers=headers, batch_index=batch_index))
                response = self._merge_batch_responses(children[0], children[1])
                response.meta = {**response.meta, "automatic_context_split": True,
                                 "recovered_target_count": len(pending)}
            merged = response if merged is None else self._merge_batch_responses(merged, response)
            missing = self._missing_batch_attributes(req, merged)
            if not missing:
                merged.meta = {**merged.meta, "planned_model_payload": planned_projection}
                return merged
            pending_req = req.model_copy(
                update={
                    "data": req.data.model_copy(update={"attributes": missing}),
                    "meta": {
                        **req.meta,
                        "auto_mapping_repair": True,
                        "auto_mapping_repair_target_count": len(missing),
                    },
                }
            )

        assert merged is not None
        missing = self._missing_batch_attributes(req, merged)
        result = merged.data.result if merged.data else merged.result
        if isinstance(result, SourceMappingResult) and missing:
            repaired_mappings = dict(result.mappings)
            warnings = list(merged.warnings)
            for attribute in missing:
                target = str(attribute.target_attribute)
                repaired_mappings[target] = AttributeMapping(
                    source_attributes=[],
                    confidence_score=0.0,
                    transformation_classification="unresolved",
                    unmatched_reason=(
                        "AGT_SOURCE_MAPPING omitted this target after a bounded repair retry."
                    ),
                )
                warnings.append(
                    ApiWarning(
                        code="AUTO_MAPPING_TARGET_OMITTED",
                        message=(
                            "The mapping agent omitted this target after retry; it remains "
                            "unmapped for review instead of being silently dropped."
                        ),
                        field=target,
                    )
                )
            repaired_result = SourceMappingResult(mappings=repaired_mappings)
            repaired_data = (
                merged.data.model_copy(
                    update={"result": repaired_result, "status": STTMStatus.NEEDS_INPUT}
                )
                if merged.data is not None
                else None
            )
            merged = merged.model_copy(
                update={
                    "data": repaired_data,
                    "result": repaired_result,
                    "warnings": warnings,
                    "meta": {
                        **merged.meta,
                        "auto_mapping_coverage": {
                            "requested": len(req.data.attributes or []),
                            "returned": len(req.data.attributes or []) - len(missing),
                            "omitted_targets": [
                                str(attribute.target_attribute) for attribute in missing
                            ],
                        },
                    },
                }
            )
        return merged

    def _build_batches(self, req: STTMBuilderEnvelopeRequest, *, diagnostics=None) -> list[list[Any]]:
        if req.meta.get("auto_map_resolution_mode") is not None or _RESOLUTION_PLAN_KEY in req.meta:
            req = self._freeze_resolution(req)
            if self._trusted_resolution_plan(req):
                pending_req = self._pending_resolution_request(req)
                if not pending_req.data.attributes:
                    return []
                return self._fast_preflight_batches(req, pending_req, diagnostics=diagnostics)
        attributes = list(req.data.attributes or [])
        if not attributes:
            return [[]]
        if getattr(self._settings, "automap_context_retrieval_v1", False) or req.meta.get("auto_map_fast_path") == "v1":
            from app.core.sttm_builder import STTMBuilderService
            pending = list(reversed(self._balanced_retrieval_batches(req)))
            planned = []
            while pending:
                batch = pending.pop()
                batch_req = req.model_copy(update={"data": req.data.model_copy(update={"attributes": batch})})
                try:
                    projected = STTMBuilderService.project_agent_payload(batch_req, self._settings)
                except AgentPayloadBudgetError as exc:
                    if len(batch) == 1:
                        raise AgentPayloadBudgetError(
                            f"Target {batch[0].target_attribute} cannot fit mandatory exact evidence: {exc}"
                        ) from exc
                    midpoint = len(batch) // 2
                    pending.extend((batch[midpoint:], batch[:midpoint]))
                else:
                    baseline = projected.diagnostics.get("fast_preflight", projected.diagnostics.get("parallel_preflight", {}))
                    planned.append((batch, baseline))

            # An excluded whole-table group is often too large regardless of
            # target count. Splitting every batch down to two targets repeats
            # that same failed scan many times. Allow one extra batch only
            # when both child preflights prove a net coverage improvement.
            if len(planned) < 5:
                best = None
                for index, (batch, baseline) in enumerate(planned):
                    if not baseline.get("excluded_group_count") or len(batch) < 3:
                        continue
                    midpoint = len(batch) // 2
                    halves = (batch[:midpoint], batch[midpoint:])
                    children = []
                    try:
                        for half in halves:
                            child_req = req.model_copy(update={"data": req.data.model_copy(update={"attributes": half})})
                            child = STTMBuilderService.project_agent_payload(child_req, self._settings)
                            children.append((half, child.diagnostics.get("parallel_preflight", {})))
                    except AgentPayloadBudgetError:
                        continue  # Parent already fits; a failed probe cannot improve coverage.
                    def excluded_weight(item):
                        targets, sizing = item
                        return len(targets) * max(int(sizing.get("excluded_record_count") or 0),
                                                  int(sizing.get("excluded_group_count") or 0))
                    gain = excluded_weight((batch, baseline)) - sum(map(excluded_weight, children))
                    if gain > 0 and (best is None or gain > best[0]):
                        best = (gain, index, children)
                if best is not None:
                    _, index, children = best
                    planned[index:index + 1] = children
            if diagnostics is not None:
                diagnostics.extend({"target_count": len(batch), **baseline} for batch, baseline in planned)
            return [batch for batch, _ in planned]
        if self._exact_precedent(req) is not None:
            return [attributes]
        return self._build_legacy_batches(req)

    def _fast_preflight_batches(self, root, req, *, diagnostics=None):
        """Freeze local outcomes separately from the authored-target partition."""
        plan = self._trusted_resolution_plan(root)
        binding = self._resolution_digest({
            "request": req.model_dump(mode="json"),
            "identity": self._batch_identity(root, list(req.data.attributes)),
            "limits": {"chars": self._settings.agent_outbound_message_max_chars,
                "bytes": self._settings.agent_outbound_message_max_bytes,
                "batch_count": self._settings.automap_context_batch_count,
                "preflight_version": (plan.get("preflight") or {}).get("version", _PREFLIGHT_VERSION),
                "revision": self._settings.automap_fast_canary_revision},
        })
        cached = plan.get("preflight")
        if cached is None:
            from app.core.sttm_builder import STTMBuilderService
            from app.core.automap_fast_context import FastContextDeadlineError, fast_projection_deadline, request_deadline
            monotonic_deadline = request_deadline(req.meta)
            pending = list(reversed(self._balanced_retrieval_batches(req)))
            entries = []
            def check_deadline():
                if time.time() >= plan["deadline_at"] or time.monotonic() >= monotonic_deadline:
                    raise FastContextDeadlineError("Auto-map request deadline exceeded during local preflight")
            while pending:
                batch = pending.pop()
                batch_req = req.model_copy(update={"data": req.data.model_copy(update={"attributes": batch})})
                entry = {"target_attributes": [item.target_attribute for item in batch]}
                packet_started = time.perf_counter()
                try:
                    check_deadline()
                    try:
                        with fast_projection_deadline(monotonic_deadline):
                            projected = STTMBuilderService.project_agent_payload(batch_req, self._settings)
                    except AgentPayloadBudgetError:
                        check_deadline()  # Expired work must not start child projections.
                        raise
                    check_deadline()
                except FastContextDeadlineError:
                    entry.update(status="deadline_exceeded", rejection={"code": _PREFLIGHT_DEADLINE_CODE,
                        "stage": "target_batch_preflight", "reason": "shared_request_deadline_exceeded",
                        "model_call_count": 0, "complete_coverage": False}, diagnostics={})
                    entries.append(entry)
                    entries.extend({"target_attributes": [item.target_attribute for item in remaining],
                        "status": entry["status"], "rejection": dict(entry["rejection"]), "diagnostics": {}}
                        for remaining in reversed(pending))
                    break
                except AgentPayloadBudgetError as exc:
                    if len(batch) > 1:
                        midpoint = len(batch) // 2
                        pending.extend((batch[midpoint:], batch[:midpoint]))
                        continue
                    entry.update(status="locally_blocked", rejection=self._preflight_budget_diagnostic(exc), diagnostics={})
                else:
                    sizing = projected.diagnostics.get("fast_preflight") or {}
                    if sizing.get("requires_target_subdivision") or sizing.get("essential_contract_overflow") or sizing.get("input_sizing_ready") is False:
                        if len(batch) > 1:
                            midpoint = len(batch) // 2
                            pending.extend((batch[midpoint:], batch[:midpoint]))
                            continue
                        entry.update(status="locally_blocked", rejection={
                            "code": _PREFLIGHT_BUDGET_CODE, "stage": "target_batch_preflight",
                            "reason": "essential_contract_overflow", "model_call_count":0,
                            "complete_coverage":False}, diagnostics=deepcopy(projected.diagnostics))
                    else:
                        entry.update(status="ready", rejection=None, diagnostics=deepcopy(projected.diagnostics))
                        if isinstance(getattr(projected, 'frozen_packet', None), dict):
                            from app.core.automap_stored_json import store_json
                            entry['frozen_packet'] = store_json(projected.frozen_packet, public_keys=(
                                'version','receipt_digest','message_digest','input_digest','final_chars','final_bytes','limits'))
                entry['phase_timings_ms'] = {'projection_sizing_and_receipt': round((time.perf_counter() - packet_started) * 1000, 2)}
                entries.append(entry)
            cached = {"version": _PREFLIGHT_VERSION, "binding_hash": binding, "batches": entries}
            # Only the server-owned marker is mutated. Caller envelopes never
            # acquire it; the runner persists this extension before dispatch.
            plan.update(preflight=cached, preflight_hash=self._resolution_digest(cached))
        if cached.get("binding_hash") != binding:
            raise SnowflakeAgentError("Frozen Auto-map preflight does not match this request or budget; start a new job")
        attributes = {item.target_attribute: item for item in req.data.attributes}
        names = [name for entry in cached["batches"] for name in entry["target_attributes"]]
        if len(names) != len(attributes) or set(names) != set(attributes):
            raise SnowflakeAgentError("Frozen Auto-map preflight has invalid target coverage")
        batches = [[attributes[name] for name in entry["target_attributes"]] for entry in cached["batches"]]
        if diagnostics is not None:
            diagnostics.extend({"batch_index": index, "target_count": len(batch),
                "target_attributes": cached["batches"][index]["target_attributes"],
                "status": cached["batches"][index]["status"], "preflight_hash": plan["preflight_hash"],
                **(cached["batches"][index]["diagnostics"].get("fast_preflight") or {}),
                **({"rejection": cached["batches"][index]["rejection"]} if cached["batches"][index]["rejection"] else {})}
                for index, batch in enumerate(batches))
        return batches

    def _preflight_budget_diagnostic(self, exc):
        from app.core.automap_shards import MessageBudgetError
        diagnostic = {"code": _PREFLIGHT_BUDGET_CODE, "stage": "target_batch_preflight",
            "reason": "mandatory_exact_evidence_oversized", "model_call_count": 0,
            "complete_coverage": False, "measured_chars": None, "measured_bytes": None,
            "limit_chars": min(180_000, self._settings.agent_outbound_message_max_chars),
            "limit_bytes": min(180_000, self._settings.agent_outbound_message_max_bytes)}
        from app.core.automap_evidence_blocks import EvidenceReviewBudgetError
        if isinstance(exc, EvidenceReviewBudgetError):
            return {**diagnostic, **exc.diagnostics}
        from app.core.automap_fast_context import FastIdentityBudgetError
        if isinstance(exc, FastIdentityBudgetError):
            return {**diagnostic, **exc.diagnostics, "reason": "indivisible_identity_oversized"}
        cause = exc
        while cause is not None:
            if isinstance(cause, MessageBudgetError):
                diagnostic.update(measured_chars=cause.char_count, measured_bytes=cause.byte_count,
                    limit_chars=cause.budget.max_chars, limit_bytes=cause.budget.max_bytes)
                break
            cause = cause.__cause__
        # Exception text can contain original evidence. Persist safe typed sizes
        # only; the full evidence already lives in the durable request envelope.
        return diagnostic

    @staticmethod
    def _preflight_rejection_response(req, attributes, rejection):
        detail = ("The shared request deadline expired during local preparation."
                  if rejection["code"] == _PREFLIGHT_DEADLINE_CODE else
                  "A required atomic identifier or datatype exceeds the message allowance; correct that input."
                  if rejection.get("reason") == "indivisible_identity_oversized" else
                  "Mandatory exact evidence needs more review calls than this batch allows; replan the evidence scope."
                  if rejection.get("reason") == "evidence_review_call_budget_exceeded" else
                  "Mandatory exact evidence exceeds the message budget.")
        reason = (f"{rejection['code']}: {detail} "
            "No worker or model was called; this is not a model no-match. "
            "The original evidence and existing definition remain unchanged.")
        mappings = {item.target_attribute: AttributeMapping(source_attributes=[], confidence_score=0.0,
            transformation_classification="unresolved", unmatched_reason=reason) for item in attributes}
        return STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None, agent=None,
            result=SourceMappingResult(mappings=mappings), message=reason, status=STTMStatus.NEEDS_INPUT,
            warnings=[ApiWarning(code=rejection["code"], message=reason, field=item.target_attribute) for item in attributes],
            meta={})

    def _balanced_retrieval_batches(self, req):
        from app.core.automap_batching import dependency_batches
        count = self._settings.automap_context_batch_count
        if req.meta.get("auto_map_fast_path") == "v1":
            count = max(1, math.ceil(len(req.data.attributes or []) / self._settings.automap_fast_batch_targets))
        return dependency_batches(req, count)

    def _build_legacy_batches(self, req):
        attributes = list(req.data.attributes or [])
        if self._exact_precedent(req) is not None:
            return [attributes]
        precedent_by_target: dict[str, dict[str, Any]] = {}
        learning = req.context.learning_context
        if learning is not None:
            for precedent in learning.mapping_precedents:
                for mapping in precedent.mappings:
                    target = str(mapping.get("target_column") or "").upper()
                    if target and target not in precedent_by_target:
                        precedent_by_target[target] = mapping

        complex_tokens = (
            "CASE ", "COALESCE(", "CONCAT", "CAST(", "TO_CHAR(",
            "DATE", "SUBSTRING", "REPLACE(", "NULLIF(",
        )

        def rank(attribute: Any) -> tuple[int, int, str]:
            target = str(getattr(attribute, "target_attribute", "") or "")
            precedent = precedent_by_target.get(target.upper())
            if precedent:
                if str(precedent.get("mapping_mode") or "source") == "constant":
                    complexity = 0
                else:
                    rule = str(precedent.get("preprocessing_rule") or "").upper()
                    rule_type = str(precedent.get("preprocessing_rule_type") or "DIRECT").upper()
                    complexity = 3 if rule_type == "CUSTOM" or any(token in rule for token in complex_tokens) else 1
            else:
                description = str(getattr(attribute, "target_description", "") or "").upper()
                complexity = 3 if any(token in description for token in complex_tokens) else 2
            payload_size = len(json.dumps(attribute.model_dump(mode="json"), default=str))
            return (complexity, payload_size, target)

        ordered = sorted(attributes, key=rank)
        batches: list[list[Any]] = []
        current: list[Any] = []
        current_complexity = 0
        for attribute in ordered:
            complexity, _payload_chars, _target = rank(attribute)
            max_items = min(self._batch_size, 6 if complexity >= 3 else 16)
            candidate = [*current, attribute]
            candidate_req = req.model_copy(
                update={"data": req.data.model_copy(update={"attributes": candidate})}
            )
            candidate_fits = True
            try:
                # Plan batches against the target-specific Cortex prompt that
                # the worker will build, not against the larger internal
                # host-to-worker transport envelope.
                from app.core.sttm_builder import STTMBuilderService
                model_projection = STTMBuilderService.project_agent_payload(candidate_req, self._settings)
                candidate_fits = (
                    model_projection.diagnostics["final_chars"]
                    <= self._settings.agent_outbound_message_max_chars
                    and model_projection.diagnostics["final_bytes"]
                    <= self._settings.agent_outbound_message_max_bytes
                    # Emergency compaction strips this batch's precedent. Prefer a
                    # smaller parallel batch with full context, down to a floor that
                    # keeps the number of agent calls bounded.
                    and not (
                        model_projection.diagnostics["emergency_compaction"]
                        and len(candidate) > _MIN_CONTEXT_PRESERVING_BATCH
                    )
                )
            except AgentPayloadBudgetError:
                candidate_fits = False
            must_flush = bool(current) and (
                len(current) >= max_items
                or not candidate_fits
                or (current_complexity < 3 <= complexity)
            )
            if must_flush:
                batches.append(current)
                current = []
            current.append(attribute)
            current_complexity = complexity
            if len(current) == 1:
                single_req = req.model_copy(
                    update={"data": req.data.model_copy(update={"attributes": current})}
                )
                from app.core.sttm_builder import STTMBuilderService
                STTMBuilderService.project_agent_payload(single_req, self._settings)
        if current:
            batches.append(current)
        return batches

    def _budget_batch_request(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> tuple[STTMBuilderEnvelopeRequest, dict[str, Any]]:
        # This payload travels only between the public host and the private
        # Auto-map worker. It is not the Cortex model prompt. Preserve the
        # prepared semantic/FIR context across that hop; the worker applies the
        # smaller, target-specific model budget in _build_agent_payload().
        transport_limit = max(
            self._settings.agent_caller_inline_fallback_limit_bytes,
            self._settings.agent_outbound_message_max_bytes,
        )
        from app.core.automap_batch import canonical_model_wire_request, validate_fast_request
        req = canonical_model_wire_request(req)
        if req.meta.get("_automap_fast_handoff") is not None:
            validate_fast_request(req, self._settings)
        raw = req.to_worker_payload()
        try:
            result = budget_agent_payload(
                raw,
                max_chars=transport_limit,
                max_bytes=transport_limit,
                enabled=False,
            )
        except AgentPayloadBudgetError as exc:
            wire_text = json.dumps(raw, separators=(",", ":"), ensure_ascii=False)
            raise AutoMappingTransportTooLargeError(
                "Host-to-worker transport exceeds its shared-context limit "
                f"({len(wire_text.encode('utf-8'))} bytes before artifact sanitization; "
                f"limit {transport_limit} bytes). This is not the Cortex prompt limit; "
                "splitting target columns does not reduce the shared context."
            ) from exc
        budgeted = STTMBuilderEnvelopeRequest.model_validate(result.payload)
        if req.meta.get("_automap_fast_handoff") is not None:
            validate_fast_request(budgeted, self._settings)
        result.diagnostics["budget_scope"] = "host_to_worker_transport"
        result.diagnostics["model_prompt_budget_applied_by_worker"] = True
        return budgeted, result.diagnostics

    @staticmethod
    def _exact_precedent(req: STTMBuilderEnvelopeRequest) -> Any | None:
        """Return a precedent only for an explicit diagnostic replay request.

        Exact target coverage does not establish that the current source graph is
        identical to the historical graph. Production Auto-map therefore sends the
        precedent to AGT_SOURCE_MAPPING as evidence. Deterministic replay remains
        available for controlled cache/compiler diagnostics only.
        """
        if (
            not req.context.replay_exact_precedent
            or req.context.omit_linked_precedent
            or str(req.data.message or "").strip()
        ):
            return None
        learning = req.context.learning_context
        if learning is None:
            return None
        requested = {
            str(attribute.target_attribute).upper()
            for attribute in (req.data.attributes or [])
        }
        corrected_targets = {
            str(item.target_column).upper() for item in learning.correction_history
        }
        if requested & corrected_targets:
            return None
        for recommendation in learning.fir_recommendations:
            payload = recommendation.get("payload") if isinstance(recommendation, dict) else None
            if isinstance(payload, dict) and (
                payload.get("override_precedent") is True
                or str(payload.get("precedent_decision") or "").lower() == "override_precedent"
            ):
                return None
        for precedent in learning.mapping_precedents:
            if str(precedent.compatibility or "").strip().lower() != "exact":
                continue
            if precedent.confidence < 0.95:
                continue
            by_target = {
                str(item.get("target_column") or "").upper(): item
                for item in precedent.mappings
                if item.get("target_column")
            }
            if requested and requested.issubset(by_target):
                return precedent
        return None

    @classmethod
    def _exact_precedent_response(
        cls,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderResponse | None:
        precedent = cls._exact_precedent(req)
        if precedent is None:
            return None
        by_target = {
            str(item.get("target_column") or "").upper(): item
            for item in precedent.mappings
            if item.get("target_column")
        }
        mappings: dict[str, AttributeMapping] = {}
        for index, attribute in enumerate(req.data.attributes or [], start=1):
            source = by_target[attribute.target_attribute.upper()]
            mode = str(source.get("mapping_mode") or "source").lower()
            constant_value = source.get("constant_value")
            source_columns = [str(value) for value in source.get("source_columns") or [] if value]
            rule_type = str(
                source.get("preprocessing_rule_type")
                or ("Value" if mode == "constant" else "Direct")
            )
            rule = source.get("preprocessing_rule")
            mappings[attribute.target_attribute] = AttributeMapping(
                source_attributes=source_columns,
                mapping_mode=(
                    "attribute"
                    if mode in {"attribute", "project_attribute", "project_value"}
                    else "constant"
                    if mode in {"constant", "value"}
                    else "source"
                ),
                constant_value=str(constant_value) if constant_value is not None else None,
                attribute_name=(
                    str(source.get("attribute_name"))
                    if source.get("attribute_name") is not None
                    else None
                ),
                source_dependencies=source_columns,
                value_binding_ids=[
                    binding.binding_id
                    for binding in (
                        req.context.relation_graph.value_bindings
                        if req.context.relation_graph is not None
                        else []
                    )
                    if mode in {"attribute", "project_attribute", "project_value"}
                    and str(binding.attribute_name or "").upper()
                    == str(source.get("attribute_name") or "").upper()
                ],
                transformation_classification=(
                    "value"
                    if mode in {"constant", "value", "attribute", "project_attribute", "project_value"}
                    else "reused"
                    if rule_type.upper() == "CUSTOM"
                    else "direct"
                ),
                precedent_decision="accept_precedent",
                precedent_mapping_id=precedent.precedent_sttm_id,
                override_evidence=[],
                confidence_score=min(1.0, max(0.0, float(precedent.confidence))),
                confidence_reason=(
                    f"Accepted exact compatible completed mapping {precedent.precedent_sttm_id}; "
                    "no user correction or explicit FIR override evidence was present."
                ),
                preprocessing_rule=str(rule) if rule is not None else None,
                preprocessing_rule_type=rule_type,
                preprocessing_nl_rule=(
                    f"Reuse the validated {rule_type} rule from completed mapping "
                    f"{precedent.precedent_sttm_id}."
                ),
                processing_order=index,
                description=source.get("description"),
                used_learning_ids=[
                    value for value in [str(source.get("mapping_id") or "")] if value
                ],
            )
        response = STTMBuilderResponse.from_invocation(
            req,
            thread_id=f"precedent-cache:{precedent.precedent_sttm_id}",
            parent_message_id=None,
            agent=SubAgent.SOURCE_MAPPING_AGENT,
            result=SourceMappingResult(mappings=mappings),
            message=(
                f"Accepted {len(mappings)} mappings from exact completed precedent "
                f"{precedent.precedent_sttm_id}."
            ),
            status=STTMStatus.COMPLETED,
        )
        return response.model_copy(
            update={
                "warnings": list(req.warnings),
                "meta": {
                    **response.meta,
                    "auto_mapping_dispatch": {
                        "attribute_count": len(mappings),
                        "batch_count": 1,
                        "batch_sizes": [len(mappings)],
                        "batching_mode": "exact_precedent_cache",
                        "max_in_flight": 0,
                        "failed_batches": [],
                    },
                    "accepted_precedent": {
                        "sttm_id": precedent.precedent_sttm_id,
                        "project_id": precedent.precedent_project_id,
                        "raw_sql_hash": precedent.raw_sql_hash,
                        "mapping_count": len(precedent.mappings),
                        "cte_count": len(precedent.ctes),
                        "business_rule_count": len(precedent.business_rules),
                    },
                },
            }
        )

    def _invoke_batch(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        headers: dict[str, str],
        batch_index: int,
    ) -> STTMBuilderResponse:
        tenant_key = "|".join(
            (
                str(headers.get("X-Workbench-OAuth-Role") or "default-role").upper(),
                str(
                    headers.get("X-Workbench-OAuth-User")
                    or headers.get("Sf-Context-Current-User")
                    or "default-user"
                ).upper(),
            )
        )
        with _AUTO_MAP_TENANT_SEMAPHORES_LOCK:
            semaphore = _AUTO_MAP_TENANT_SEMAPHORES.get(tenant_key)
            if semaphore is None:
                semaphore = threading.BoundedSemaphore(
                    max(1, self._settings.auto_mapping_worker_max_concurrency)
                )
                _AUTO_MAP_TENANT_SEMAPHORES[tenant_key] = semaphore
        acquired = semaphore.acquire(timeout=self._remaining_worker_timeout(req))
        if not acquired:
            raise SnowflakeAgentError(
                "Auto-mapping concurrency is busy for this delegated user and role."
            )
        try:
            return self._invoke_batch_unlimited(
                req,
                headers=headers,
                batch_index=batch_index,
            )
        finally:
            semaphore.release()

    def _invoke_batch_unlimited(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        headers: dict[str, str],
        batch_index: int,
    ) -> STTMBuilderResponse:
        if (req._automap_durable_receipt and self._settings.automap_durable_runs_v2
                and isinstance(req.meta.get('_automap_frozen_packet'), dict)):
            from app.core.automap_frozen_packet import worker_reference
            req = worker_reference(req)
        req, budget_diagnostics = self._budget_batch_request(req)
        payload = req.to_worker_payload()
        payload.get("meta", {}).pop(_RESOLUTION_PLAN_KEY, None)
        logger.info(
            "Auto-map batch payload request_id=%s batch=%s original_chars=%s "
            "final_chars=%s final_bytes=%s compacted=%s",
            req.request_id,
            batch_index + 1,
            budget_diagnostics["original_chars"],
            budget_diagnostics["final_chars"],
            budget_diagnostics["final_bytes"],
            budget_diagnostics["compacted"],
        )
        last_error: Exception | None = None
        attempts = 1 if (req.meta.get("auto_map_fast_path") == "v1"
            or req.meta.get('_automap_packet_ref') is not None) else self._retry_attempts
        if self._base_url == "inprocess":
            # Local/integration compatibility adapter: exercise the private worker
            # ASGI application without opening a second listening socket. SPCS keeps
            # using its internal service URL and therefore never enters this branch.
            from fastapi.testclient import TestClient

            from app.auto_mapping_worker.main import app as worker_app

            logger.info(
                "Dispatching auto-map request_id=%s batch=%s to in-process worker",
                req.request_id,
                batch_index + 1,
            )
            for attempt in range(1, attempts + 1):
                self._remaining_worker_timeout(req)
                from contextlib import nullcontext
                managed_client = getattr(self, '_local_worker_client', None)
                # Acceptance/local hosts can own one worker application lifespan
                # for all concurrent batches, like a continuously running SPCS
                # worker. This handle is never accepted from request metadata.
                with (nullcontext(managed_client) if managed_client is not None else TestClient(worker_app)) as client:
                    response = client.post(
                        "/api/v1/auto-mapping/invoke",
                        headers=self._fresh_worker_headers(headers),
                        json=payload,
                    )
                if response.status_code == 200:
                    try:
                        parsed = STTMBuilderResponse.model_validate(response.json())
                    except Exception as exc:
                        raise SnowflakeAgentError(
                            "In-process Auto-mapping worker returned an invalid "
                            f"response payload: {exc}"
                        ) from exc
                    self._validate_worker_response(parsed, req=req, batch_index=batch_index)
                    return parsed

                error_detail = self._worker_error_detail(response)
                message = (
                    f"In-process Auto-mapping worker returned HTTP {response.status_code}"
                    + (f": {error_detail}" if error_detail else "")
                )
                if response.status_code < 500 and response.status_code != 429:
                    raise SnowflakeAgentError(message)
                last_error = SnowflakeAgentError(message)
                if attempt >= attempts:
                    break
                logger.warning(
                    "In-process Auto-mapping worker returned a transient error "
                    "(attempt %s/%s). Retrying: %s",
                    attempt,
                    self._retry_attempts,
                    response.status_code,
                )
                time.sleep(1.0)

            raise SnowflakeAgentError(
                f"In-process Auto-mapping worker request failed: {last_error}"
            ) from last_error

        endpoint = f"{self._base_url}/api/v1/auto-mapping/invoke"
        logger.info(
            "Dispatching auto-map request_id=%s batch=%s to worker endpoint=%s",
            req.request_id,
            batch_index + 1,
            endpoint,
        )

        for attempt in range(1, attempts + 1):
            try:
                with httpx.Client(timeout=self._remaining_worker_timeout(req)) as client:
                    response = client.post(
                        endpoint,
                        headers=self._fresh_worker_headers(headers),
                        json=payload,
                    )
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt >= attempts:
                    break
                logger.warning(
                    "Auto-mapping worker call failed (attempt %s/%s). Retrying: %s",
                    attempt,
                    self._retry_attempts,
                    exc,
                )
                time.sleep(1.0)
                continue

            if response.status_code == 200:
                logger.info(
                    "Auto-mapping worker request_id=%s completed with HTTP 200",
                    req.request_id,
                )
                try:
                    parsed = STTMBuilderResponse.model_validate(response.json())
                except Exception as exc:
                    raise SnowflakeAgentError(
                        f"Auto-mapping worker returned an invalid response payload: {exc}"
                    ) from exc
                self._validate_worker_response(parsed, req=req, batch_index=batch_index)
                return parsed

            if response.status_code < 500 and response.status_code != 429:
                logger.warning(
                    "Auto-mapping worker request_id=%s failed with HTTP %s",
                    req.request_id,
                    response.status_code,
                )
                raise SnowflakeAgentError(
                    f"Auto-mapping worker returned HTTP {response.status_code}"
                    + (f": {self._worker_error_detail(response)}" if self._worker_error_detail(response) else "")
                )

            error_detail = self._worker_error_detail(response)
            last_error = SnowflakeAgentError(
                f"Auto-mapping worker returned HTTP {response.status_code}"
                + (f": {error_detail}" if error_detail else "")
            )
            if attempt >= attempts:
                break
            logger.warning(
                "Auto-mapping worker returned a transient error (attempt %s/%s). Retrying: %s",
                attempt,
                self._retry_attempts,
                response.status_code,
            )
            time.sleep(1.0)

        raise SnowflakeAgentError(
            f"Auto-mapping worker request failed: {last_error}"
        ) from last_error

    def _remaining_worker_timeout(self, req):
        deadline = req.meta.get("_automap_deadline")
        if deadline is None:
            return self._timeout
        if getattr(self._settings,'automap_durable_runs_v2',False):
            deadline += self._settings.automap_queue_seconds
        remaining = float(deadline) - time.time()
        if remaining <= 0:
            raise SnowflakeAgentError("Auto-map request deadline exceeded before worker dispatch")
        timeout = max(self._timeout,self._settings.automap_fast_batch_seconds) + self._settings.automap_queue_seconds if getattr(self._settings,'automap_durable_runs_v2',False) else self._timeout
        return min(timeout, remaining)

    @staticmethod
    def _worker_error_detail(response: Any) -> str | None:
        try:
            payload = response.json()
        except Exception:
            return None
        if not isinstance(payload, dict):
            return None
        error = payload.get("error")
        if isinstance(error, dict):
            code = str(error.get("code") or "").strip()
            detail = str(error.get("detail") or error.get("title") or "").strip()
            combined = " - ".join(value for value in (code, detail) if value)
            return combined[:500] or None
        detail = payload.get("detail")
        return str(detail)[:500] if detail else None

    @staticmethod
    def _check_draft_response(req, response):
        expected = req.meta.get(SCORING_META_KEY)
        if expected is None:
            return
        result = response.data.result if response.data else response.result
        if (expected != SCORING_POLICY_VERSION
                or response.meta.get("automap_draft_validation") != expected
                or response.meta.get(SCORING_META_KEY) != expected
                or not isinstance(result, SourceMappingResult)
                or any(candidate.scoring_policy_version != expected
                       for mapping in result.mappings.values() for candidate in mapping.candidates)):
            raise SnowflakeAgentError("Worker draft/scoring policy mismatch; start a compatible new job")

    @staticmethod
    def _validate_worker_response(
        response: STTMBuilderResponse,
        *,
        req: STTMBuilderEnvelopeRequest,
        batch_index: int,
    ) -> None:
        """Reject HTTP-200 envelopes that contain an Agent or contract failure."""
        if response.error is not None:
            code = response.error.code or "AUTO_MAPPING_AGENT_ERROR"
            raise SnowflakeAgentError(
                f"Auto-map batch {batch_index + 1} failed with {code}: "
                f"{response.error.title}"
            )
        response_data = response.data
        if response_data is None or response_data.status.value == "failed":
            raise SnowflakeAgentError(
                f"Auto-map batch {batch_index + 1} returned a failed response envelope."
            )
        result = response_data.result
        if req.data.intent == Interface.TRANSFORM:
            if not isinstance(result, TransformationResult):
                result = response.result
            if not isinstance(result, TransformationResult) or not result.rules:
                raise SnowflakeAgentError(
                    "The global Auto-map transformation stage returned no rules."
                )
            return
        if not isinstance(result, SourceMappingResult):
            result = response.result
        if not isinstance(result, SourceMappingResult) or not result.mappings:
            raise SnowflakeAgentError(
                f"Auto-map batch {batch_index + 1} returned no source-mapping result."
            )

        AutoMappingProxyClient._check_draft_response(req, response)
        if response.meta.get("automap_draft_validation") == SCORING_POLICY_VERSION:
            # The worker validated each exact definition. Legacy normalization
            # below can erase SQL, synthesize Direct, or rebind a Firm Value.
            if response.data is not None:
                response.result = response.data.result
            return

        learning = req.context.learning_context
        precedents_by_id = {
            str(precedent.precedent_sttm_id): precedent
            for precedent in (learning.mapping_precedents if learning else [])
            if precedent.precedent_sttm_id
        }
        allowed_precedent_ids = {
            precedent_id for precedent_id in precedents_by_id
        }
        if req.context.omit_linked_precedent:
            allowed_precedent_ids.clear()

        normalized_targets: list[str] = []

        def normalized_mode(value: Any) -> str:
            return "constant" if str(value or "source").lower() in {
                "constant", "value", "literal", "placeholder"
            } else "source"

        def normalized_rule(value: Any) -> str:
            return " ".join(str(value or "").strip().upper().split())

        def accepted_contract_matches(
            target: str,
            mapping: AttributeMapping,
            precedent_id: str,
        ) -> bool:
            precedent = precedents_by_id.get(precedent_id)
            if precedent is None or not precedent.mappings:
                return True
            target_leaf = str(target).rsplit(".", 1)[-1].upper()
            historical = next(
                (
                    item
                    for item in precedent.mappings
                    if str(item.get("target_column") or "").rsplit(".", 1)[-1].upper()
                    == target_leaf
                ),
                None,
            )
            if historical is None:
                return False
            if normalized_mode(historical.get("mapping_mode")) != normalized_mode(
                mapping.mapping_mode
            ):
                return False
            if normalized_mode(mapping.mapping_mode) == "constant":
                if str(historical.get("constant_value") or "").strip() != str(
                    mapping.constant_value or ""
                ).strip():
                    return False
            historical_type = normalized_rule(
                historical.get("preprocessing_rule_type")
            )
            current_type = normalized_rule(mapping.preprocessing_rule_type)
            if historical_type and current_type and historical_type != current_type:
                return False
            historical_rule = normalized_rule(historical.get("preprocessing_rule"))
            current_rule = normalized_rule(mapping.preprocessing_rule)
            if historical_rule and current_rule and historical_rule != current_rule:
                return False
            return True

        for target, mapping in result.mappings.items():
            decision = mapping.precedent_decision
            precedent_id = str(mapping.precedent_mapping_id or "")
            valid_link = bool(precedent_id and precedent_id in allowed_precedent_ids)
            invalid_accept = decision == "accept_precedent" and (
                not valid_link
                or not accepted_contract_matches(target, mapping, precedent_id)
            )
            invalid_override = decision == "override_precedent" and (
                not valid_link or not mapping.override_evidence
            )
            # Precedent metadata is optional. A verified source binding must not
            # become unresolved merely because the specialist made a fresh
            # decision and therefore did not cite/override historical work.
            if not (invalid_accept or invalid_override):
                continue
            mapping.precedent_decision = "unresolved"
            mapping.precedent_mapping_id = None
            mapping.confidence_reason = " ".join(
                value
                for value in (
                    mapping.confidence_reason,
                    "The linked precedent does not support this exact accepted contract; "
                    "the inferred mapping is retained for review.",
                )
                if value
            )
            normalized_targets.append(target)

        if normalized_targets:
            response.warnings.append(
                ApiWarning(
                    code="AUTO_MAPPING_PRECEDENT_DECISION_NORMALIZED",
                    message=(
                        "Unsupported precedent decisions were changed to unresolved for: "
                        + ", ".join(normalized_targets)
                    ),
                    field="precedent_decision",
                )
            )

        graph = req.context.relation_graph
        invalid_graph_targets: list[str] = []
        if graph is not None:
            relation_contracts: list[tuple[str, set[str], bool]] = []
            for node in graph.nodes:
                columns = {
                    str(item.get("name") or item.get("column_name") or "").strip().upper()
                    for item in node.output_columns
                    if isinstance(item, dict)
                    and str(item.get("name") or item.get("column_name") or "").strip()
                }
                identifiers = {
                    str(node.relation_id or "").strip(),
                    str(node.alias or "").strip(),
                    str(node.physical_view_name or "").strip(),
                }
                if node.table is not None:
                    identifiers.add(node.table.qualified_name)
                for identifier in identifiers:
                    if identifier:
                        relation_contracts.append(
                            (
                                identifier.upper(),
                                columns,
                                node.kind.value in {"DERIVED_SOURCE", "CTE"},
                            )
                        )
            relation_contracts.sort(key=lambda item: len(item[0]), reverse=True)

            def invalid_derived_reference(value: str) -> str | None:
                upper = str(value or "").upper()
                for identifier, columns, is_derived in relation_contracts:
                    for match in re.finditer(
                        rf"(?<![A-Z0-9_$]){re.escape(identifier)}\.([A-Z_][A-Z0-9_$]*)",
                        upper,
                    ):
                        column = match.group(1)
                        if is_derived and (not columns or column not in columns):
                            return f"{identifier}.{column}"
                return None

            for target, mapping in result.mappings.items():
                if mapping.mapping_mode == "constant":
                    continue
                original_source_attributes = list(mapping.source_attributes)
                original_source_dependencies = list(mapping.source_dependencies)
                valid_source_attributes = [
                    value
                    for value in original_source_attributes
                    if invalid_derived_reference(str(value)) is None
                ]
                valid_source_dependencies = [
                    value
                    for value in original_source_dependencies
                    if invalid_derived_reference(str(value)) is None
                ]
                invalid_values = [
                    value
                    for value in [
                        *original_source_attributes,
                        *original_source_dependencies,
                        str(mapping.preprocessing_rule or ""),
                    ]
                    if invalid_derived_reference(str(value)) is not None
                ]
                invalid_reference = next(
                    (
                        invalid_derived_reference(str(value))
                        for value in invalid_values
                        if invalid_derived_reference(str(value)) is not None
                    ),
                    None,
                )
                if invalid_reference is None:
                    continue
                original_sources = [
                    *original_source_attributes,
                    *original_source_dependencies,
                ]
                mapping.candidate_source_attributes = list(
                    dict.fromkeys([*mapping.candidate_source_attributes, *original_sources])
                )[:6]
                # Agents sometimes return both a verified physical column and a
                # stale/imagined derived alias for the same target.  Do not throw
                # away the verified binding merely because the optional alias is
                # absent from the selected derived-source contract.
                if valid_source_attributes or valid_source_dependencies:
                    mapping.source_attributes = valid_source_attributes
                    mapping.source_dependencies = valid_source_dependencies
                    if invalid_derived_reference(str(mapping.preprocessing_rule or "")):
                        mapping.preprocessing_rule = (
                            "Direct" if len(valid_source_attributes) == 1 else None
                        )
                        mapping.preprocessing_rule_type = (
                            "Direct" if len(valid_source_attributes) == 1 else None
                        )
                    if mapping.precedent_decision == "unresolved":
                        mapping.precedent_decision = None
                    if (
                        mapping.transformation_classification == "unresolved"
                        and len(valid_source_attributes) == 1
                    ):
                        mapping.transformation_classification = "direct"
                    mapping.unmatched_reason = None
                    continue
                mapping.source_attributes = []
                mapping.source_dependencies = []
                mapping.preprocessing_rule = None
                mapping.preprocessing_rule_type = None
                mapping.precedent_decision = "unresolved"
                mapping.precedent_mapping_id = None
                mapping.confidence_score = 0.0
                mapping.unmatched_reason = (
                    f"The proposed source {invalid_reference} is not present in the selected "
                    "derived source output contract. Update and revalidate the derived source "
                    "through the derived-source workflow, or select an existing output column."
                )
                invalid_graph_targets.append(target)

        if invalid_graph_targets:
            response.warnings.append(
                ApiWarning(
                    code="AUTO_MAPPING_DERIVED_OUTPUT_NOT_FOUND",
                    message=(
                        "Mappings that referenced absent derived outputs were left unresolved: "
                        + ", ".join(invalid_graph_targets)
                    ),
                    field="source_attributes",
                )
            )
        AutoMappingProxyClient._demote_undefined_firm_values(response, req=req)
        # Deserialization creates distinct legacy and envelope result objects.
        # All consumers must see the same validated result, not stale UUIDs or
        # mappings from the unvalidated top-level compatibility field.
        if response.data is not None:
            response.result = response.data.result

    @staticmethod
    def _demote_undefined_firm_values(
        response: STTMBuilderResponse,
        *,
        req: STTMBuilderEnvelopeRequest,
    ) -> None:
        """Leave targets unresolved when they use a firm value this project lacks.

        Linked precedents from other projects carry their own ``$Name`` values.
        Only the current project's firm values (resolved graph bindings) can be
        compiled, so any other name would reach Snowflake as an undefined
        session variable.
        """
        if response.meta.get("automap_draft_validation") == SCORING_POLICY_VERSION:
            return
        from app.core.mapping_sql import MappingSqlService

        graph = req.context.relation_graph
        result = response.data.result if response.data is not None else None
        if not isinstance(result, SourceMappingResult):
            result = response.result
        if graph is None or not isinstance(result, SourceMappingResult):
            return
        defined = set(MappingSqlService._resolved_placeholder_sql(graph))
        undefined_targets: list[str] = []
        for target, mapping in result.mappings.items():
            texts = [str(mapping.preprocessing_rule or "")]
            if mapping.mapping_mode in {"constant", "attribute"}:
                texts.append(str(mapping.constant_value or ""))
                if mapping.mapping_mode == "attribute" and mapping.attribute_name:
                    texts.append(f"${str(mapping.attribute_name).strip().lstrip('$')}")
            undefined = sorted(
                {
                    placeholder
                    for text in texts
                    for placeholder in MappingSqlService._placeholders_in_sql(text)
                    if placeholder.upper() not in defined
                },
                key=str.upper,
            )
            if not undefined:
                # Model-generated UUIDs are not authoritative value identities.
                # Persist the named placeholders actually used by the expression;
                # they survive graph rebuilds and resolve against this project.
                mapping.value_binding_ids = sorted({
                    placeholder for text in texts
                    for placeholder in MappingSqlService._placeholders_in_sql(text)
                }, key=str.upper)
                continue
            mapping.candidate_source_attributes = list(
                dict.fromkeys([*mapping.candidate_source_attributes, *mapping.source_attributes])
            )[:6]
            mapping.source_attributes = []
            mapping.source_dependencies = []
            mapping.value_binding_ids = []
            mapping.mapping_mode = "source"
            mapping.constant_value = None
            mapping.attribute_name = None
            mapping.preprocessing_rule = None
            mapping.preprocessing_rule_type = None
            mapping.transformation_classification = "unresolved"
            mapping.precedent_decision = "unresolved"
            mapping.precedent_mapping_id = None
            mapping.confidence_score = 0.0
            mapping.unmatched_reason = (
                f"Firm value {', '.join(undefined)} is not defined for this project "
                "(it comes from another project's mapping). Add it under the project's "
                "firm values, or map this target to a source column."
            )
            undefined_targets.append(target)
        if undefined_targets:
            response.warnings.append(
                ApiWarning(
                    code="AUTO_MAPPING_FIRM_VALUE_NOT_DEFINED",
                    message=(
                        "Mappings that used firm values not defined for this project were "
                        "left unresolved: " + ", ".join(undefined_targets)
                    ),
                    field="constant_value",
                )
            )

    def invoke_stream(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
        *,
        prepare_request: Callable[[STTMBuilderEnvelopeRequest], STTMBuilderEnvelopeRequest] | None = None,
    ) -> Iterator[str]:
        def emit(event: str, data: dict[str, object]) -> str:
            return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"

        try:
            if prepare_request is not None:
                yield emit(
                    "status",
                    {
                        "phase": "automap_bundle_resolution",
                        "message": "Resolving the saved source and target semantic assets.",
                    },
                )
                req = prepare_request(req)
                semantic = req.context.workspace_context.semantic if req.context.workspace_context else None
                yield emit(
                    "status",
                    {
                        "phase": "automap_bundle_validated",
                        "message": "The composed semantic bundle is valid and ready for worker dispatch.",
                        "bundle_id": req.context.semantic_bundle_id,
                        "bundle_hash": semantic.bundle_hash if semantic else None,
                        "context_hash": (
                            req.context.workspace_context.context_hash
                            if req.context.workspace_context
                            else None
                        ),
                    },
                )
            yield emit(
                "status",
                {
                    "phase": "automap_batch_assignment",
                    "message": (
                        "Assigning ordered target-attribute batches across up to two "
                        "Auto-map service instances."
                    ),
                    "attribute_count": len(req.data.attributes or []),
                    "batch_size": self._batch_size,
                    "max_in_flight": self._max_in_flight,
                },
            )
            # Keep the browser-facing SSE connection active while the two private
            # service instances wait for their Cortex Agent responses.
            started_at = time.monotonic()
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(self.invoke, request, req)
                while True:
                    try:
                        response = future.result(timeout=10.0)
                        break
                    except FutureTimeoutError:
                        yield emit(
                            "status",
                            {
                                "phase": "automap_workers_running",
                                "message": (
                                    "AGT_SOURCE_MAPPING is processing semantic mapping batches "
                                    "across the Auto-map service instances."
                                ),
                                "elapsed_seconds": int(time.monotonic() - started_at),
                                "max_in_flight": self._max_in_flight,
                            },
                        )
            yield emit(
                "status",
                {
                    "phase": "automap_worker_completed",
                    "message": "All completed worker batches were merged in target order.",
                },
            )
            yield emit("final", response.model_dump(mode="json"))
        except Exception as exc:
            logger.exception(
                "Auto-map stream failed: request_id=%s error_type=%s",
                req.request_id,
                type(exc).__name__,
            )
            yield emit(
                "error",
                {
                    "contract_version": "1.0",
                    "request_id": req.request_id,
                    "operation": req.operation.value,
                    "data": None,
                    "warnings": [],
                    "error": {
                        "type": "about:blank",
                        "title": "Auto-map worker request failed",
                        "status": 502,
                        "detail": "The Auto-map worker could not complete the request.",
                        "code": "AUTO_MAPPING_WORKER_ERROR",
                    },
                    "message": "The Auto-map worker could not complete the request.",
                },
            )

    def _fresh_worker_headers(self, headers: dict[str, str]) -> dict[str, str]:
        session_id = getattr(headers, "session_id", None)
        if not session_id or not self._settings.uses_custom_oauth:
            return dict(headers)
        from app.auth.custom_oauth import (
            _session_select_row, _refresh_session_if_needed, decrypt_access_token,
        )
        with headers.refresh_lock:
            record = _session_select_row(session_id, self._settings)
            expected_user = str(headers.get("X-Workbench-OAuth-User") or "").upper()
            expected_role = str(headers.get("X-Workbench-OAuth-Role") or "").upper()
            if (record is None or str(record.snowflake_user).upper() != expected_user
                    or str(record.snowflake_role or "").upper() != expected_role):
                raise HTTPException(status_code=401, detail="Auto-map session changed or expired; sign in again.")
            record = _refresh_session_if_needed(record, self._settings)
            if (str(record.snowflake_user).upper() != expected_user
                    or str(record.snowflake_role or "").upper() != expected_role):
                raise HTTPException(status_code=401, detail="Auto-map session changed or expired; sign in again.")
            refreshed = dict(headers)
            refreshed["X-Workbench-OAuth-Access-Token"] = decrypt_access_token(record, self._settings)
            return refreshed

    def _forward_headers(self, request: Request) -> dict[str, str]:
        headers: dict[str, str] = _DelegatedHeaders({"Content-Type": "application/json"})
        forwarded_header_names = (
            _OAUTH_FORWARDED_HEADER_NAMES if self._settings.uses_custom_oauth else _FORWARDED_HEADER_NAMES
        )
        for header_name in forwarded_header_names:
            value = request.headers.get(header_name)
            if value:
                headers[header_name] = value
        principal = getattr(request.state, "current_principal", None)
        if principal is not None:
            if self._settings.uses_custom_oauth and principal.snowflake_user_token:
                headers.session_id = getattr(principal, "oauth_session_id", None)
                headers["X-Workbench-OAuth-Access-Token"] = principal.snowflake_user_token
                headers["X-Workbench-OAuth-User"] = principal.snowflake_user
                headers["X-Workbench-OAuth-Email"] = principal.email
                if principal.snowflake_role:
                    headers["X-Workbench-OAuth-Role"] = principal.snowflake_role
            caller_role = None
            if principal.app_persona is AppPersona.ADMIN:
                caller_role = self._settings.app_role_admin
            elif principal.app_persona is AppPersona.PUBLISHER:
                caller_role = self._settings.app_role_publisher
            elif principal.app_persona is AppPersona.VIEWER:
                caller_role = self._settings.app_role_viewer
            if self._settings.local_dev_auth_enabled and not principal.snowflake_user_token:
                caller_role = self._settings.snowflake_role
            elif not self._settings.spcs_execute_as_caller_enabled and not self._settings.uses_custom_oauth:
                caller_role = self._settings.snowflake_role
            if caller_role:
                headers["X-Workbench-Caller-Role"] = caller_role
        return headers
