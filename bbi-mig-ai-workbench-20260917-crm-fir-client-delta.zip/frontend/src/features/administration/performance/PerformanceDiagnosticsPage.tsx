'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AiaAlert,
  AiaBox,
  AiaButton,
  AiaCircularProgress,
  AiaPaper,
} from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { AutorenewRoundedIcon } from '@/utils/icons';
import {
  getRuntimeDiagnostics,
  type RuntimeDiagnostics,
} from '@/services/diagnosticsService';
import AdminPageHeader from '../shared/admin-page-header';
import { adminContentScrollSx, adminPageShellSx } from '../shared/administration-ui-styles';

const formatMs = (value: number | undefined) => `${Math.round(value ?? 0).toLocaleString()} ms`;
const formatRate = (value: number | undefined) => `${Math.round((value ?? 0) * 100)}%`;

function StatusCard({ label, value }: { label: string; value: string }) {
  return (
    <AiaPaper elevation={0} sx={{ border: '1px solid #E8ECF4', borderRadius: 2, p: 2 }}>
      <AiaText sx={{ color: '#64748B', fontSize: 12 }}>{label}</AiaText>
      <AiaText sx={{ color: '#0F172A', fontSize: 20, fontWeight: 700, mt: 0.5 }}>
        {value}
      </AiaText>
    </AiaPaper>
  );
}

export default function PerformanceDiagnosticsPage() {
  const [data, setData] = useState<RuntimeDiagnostics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await getRuntimeDiagnostics());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Unable to load runtime diagnostics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const durations = useMemo(
    () =>
      Object.entries(data?.performance?.durations ?? {})
        .sort((left, right) => right[1].p95_ms - left[1].p95_ms)
        .slice(0, 30),
    [data],
  );
  const optimization = data?.runtime_optimization;
  const readCache = data?.backend_read_cache;
  const rates = data?.performance?.rates;

  return (
    <AiaBox sx={adminPageShellSx}>
      <AiaBox sx={adminContentScrollSx}>
        <AiaBox className="px-5 py-4">
          <AdminPageHeader
            title="Performance Diagnostics"
            subtitle="Live process-local latency, cache, warehouse routing, and concurrency telemetry"
            actions={
              <AiaButton
                variant="outlined"
                startIcon={<AutorenewRoundedIcon sx={{ fontSize: 18 }} />}
                onClick={() => void refresh()}
                disabled={loading}
              >
                Refresh
              </AiaButton>
            }
          />

          {error ? <AiaAlert severity="error" sx={{ mt: 3 }}>{error}</AiaAlert> : null}
          {loading && !data ? (
            <AiaBox className="flex min-h-80 items-center justify-center">
              <AiaCircularProgress />
            </AiaBox>
          ) : (
            <>
              <AiaBox sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 2, mt: 3 }}>
                <StatusCard label="Read-cache entries" value={String(readCache?.entries ?? 0)} />
                <StatusCard label="Requests coalescing" value={String(readCache?.inflight ?? 0)} />
                <StatusCard label="Prepared-context hit rate" value={formatRate(rates?.prepared_context_hit_rate)} />
                <StatusCard label="Learning-context hit rate" value={formatRate(rates?.learning_context_hit_rate)} />
                <StatusCard label="Auto Map in-flight limit" value={String(optimization?.automap_max_in_flight ?? 0)} />
                <StatusCard label="Auto Map worker concurrency" value={String(optimization?.automap_worker_concurrency ?? 0)} />
              </AiaBox>

              <AiaPaper elevation={0} sx={{ border: '1px solid #E8ECF4', borderRadius: 2, p: 2.5, mt: 3 }}>
                <AiaText sx={{ fontSize: 16, fontWeight: 700 }}>Runtime configuration</AiaText>
                <AiaBox sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 1.5, mt: 2 }}>
                  {Object.entries(optimization?.warehouse_routing ?? {}).map(([workload, warehouse]) => (
                    <AiaBox key={workload}>
                      <AiaText sx={{ color: '#64748B', fontSize: 12 }}>{workload} warehouse</AiaText>
                      <AiaText sx={{ fontWeight: 600 }}>{warehouse || 'Default session warehouse'}</AiaText>
                    </AiaBox>
                  ))}
                  {[
                    ['Session lease pool', optimization?.session_lease_pool],
                    ['Parallel context preparation', optimization?.prepare_parallel],
                    ['Parallel learning retrieval', optimization?.learning_parallel],
                    ['Async detail persistence', optimization?.async_postsave],
                  ].map(([label, enabled]) => (
                    <AiaBox key={String(label)}>
                      <AiaText sx={{ color: '#64748B', fontSize: 12 }}>{String(label)}</AiaText>
                      <AiaText sx={{ fontWeight: 600 }}>{enabled ? 'Enabled' : 'Disabled'}</AiaText>
                    </AiaBox>
                  ))}
                </AiaBox>
              </AiaPaper>

              <AiaPaper elevation={0} sx={{ border: '1px solid #E8ECF4', borderRadius: 2, mt: 3, overflow: 'hidden' }}>
                <AiaBox sx={{ p: 2.5, borderBottom: '1px solid #E8ECF4' }}>
                  <AiaText sx={{ fontSize: 16, fontWeight: 700 }}>Slowest measured operations</AiaText>
                  <AiaText sx={{ color: '#64748B', fontSize: 12, mt: 0.5 }}>
                    Rolling service-instance sample, ordered by p95. Snowflake query history remains the source of truth for credits.
                  </AiaText>
                </AiaBox>
                <div className="overflow-x-auto">
                  <table className="min-w-[720px] w-full border-collapse text-left text-[13px]">
                    <thead className="bg-slate-50 text-xs text-slate-500">
                      <tr>{['Operation', 'Samples', 'Average', 'p50', 'p95', 'p99', 'Maximum'].map((heading) => <th className="p-3" key={heading}>{heading}</th>)}</tr>
                    </thead>
                    <tbody>
                      {durations.length ? durations.map(([name, metric]) => (
                        <tr key={name} className="border-t border-slate-100">
                          <td className="p-3 font-semibold">{name}</td>
                          <td className="p-3">{metric.sample_count}</td>
                          <td className="p-3">{formatMs(metric.avg_ms)}</td>
                          <td className="p-3">{formatMs(metric.p50_ms)}</td>
                          <td className="p-3">{formatMs(metric.p95_ms)}</td>
                          <td className="p-3">{formatMs(metric.p99_ms)}</td>
                          <td className="p-3">{formatMs(metric.max_ms)}</td>
                        </tr>
                      )) : (
                        <tr><td colSpan={7} className="p-6 text-center text-slate-500">No timed operations have been recorded in this service instance yet.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </AiaPaper>
            </>
          )}
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
