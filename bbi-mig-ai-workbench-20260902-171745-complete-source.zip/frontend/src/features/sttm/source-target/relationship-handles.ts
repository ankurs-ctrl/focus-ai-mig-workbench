type TableHandleRef = {
  database?: string;
  schema?: string;
  name?: string;
  label?: string;
};

export type TableHandleSide = "left" | "right";

/** Historic sides: joins left the source on the right and entered on the left. */
function defaultSide(kind: "source" | "target"): TableHandleSide {
  return kind === "source" ? "right" : "left";
}

export function buildTableHeaderHandleKey(
  table: TableHandleRef,
  kind: "source" | "target",
  side: TableHandleSide = defaultSide(kind),
) {
  const tableName = table.name ?? table.label ?? "table";
  return `${table.database ?? "—"}.${table.schema ?? "—"}.${tableName}-header-${kind}-${side}`;
}

export function resolveTableHeaderHandleId(
  table: TableHandleRef | undefined,
  kind: "source" | "target",
  side: TableHandleSide = defaultSide(kind),
) {
  if (!table) return undefined;
  return buildTableHeaderHandleKey(table, kind, side);
}

export function isTableHeaderHandle(handleId: string | null | undefined) {
  if (!handleId) return false;
  return handleId.includes("-header-source-") || handleId.includes("-header-target-");
}
