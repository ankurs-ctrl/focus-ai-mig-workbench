"""Conservative exact-name/type prefill. Ambiguity always remains model work."""
from __future__ import annotations
from app.agent_tools.specialists import SpecialistDecision


def prefill_exact_contracts(targets, sources, requested):
    by_name={}
    for table, contract in sources.items():
        for column in contract['column_contracts']:
            by_name.setdefault(str(column['name']).upper(),[]).append((table,column))
    decisions=[]
    for target in targets:
        name=str(target['name'])
        candidates=by_name.get(name.upper(),[])
        if name not in requested or len(candidates)!=1:continue
        table,source=candidates[0]
        if str(source['type']).upper()!=str(target['type']).upper():continue
        decisions.append(SpecialistDecision(target_column=name,decision='mapped',
            source_columns=[f'{table}.{source["name"]}'],confidence=1,
            decision_reason='Exact unique column name and type in verified current contracts.',
            evidence_ids_used=[f'table_contract:{table.upper()}'],mapping_classification='direct'))
    return decisions
