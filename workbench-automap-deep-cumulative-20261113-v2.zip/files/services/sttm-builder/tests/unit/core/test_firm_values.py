from __future__ import annotations

import threading
from types import SimpleNamespace

from app.agent_tools.firm_values import (
    apply, binding, choose, hints, known_values, names_in, usable_value, usages_from_rows,
)


def _usage(sttm, column, *, mode="source", attr=None, expression=None, constant=None, project="4", name="EverNest"):
    return {"PROJECT_ID": project, "PROJECT_NAME": name, "STTM_ID": sttm, "STATUS": "DRAFT",
            "TARGET_COLUMN": column, "MAPPING_MODE": mode, "ATTRIBUTE_NAME": attr,
            "EXPRESSION": expression, "CONSTANT_VALUE": constant}


ROWS = [
    _usage("201", "Transaction_Firm__c", expression="$TransactionFirmID"),
    _usage("2105", "Transaction_Firm__c", mode="attribute", attr="TransactionFirmID"),
    _usage("2901", "Transaction_Firm__c", mode="attribute", attr="TransactionFirmID", project="101", name="TMD"),
    _usage("201", "Legacy_ID__c", expression="$LegacyHHcPrefix || SOURCE.LegacyHHID"),
    _usage("201", "OwnerId", expression="COALESCE(mu.TARGETCRMID, $BackupOwnerID)"),
    _usage("201", "Master_Payout_Date__c", expression="TO_CHAR(TRY_TO_DATE($Master_Payout_Date), 'yyyy-mm-DD')"),
    _usage("2901", "RecordTypeId", mode="attribute", attr="LegacyHHcPrefix", project="101", name="TMD"),
    _usage("2105", "RecordTypeId", mode="attribute", attr="HHRecordType"),
    _usage("2001", "RecordTypeId", mode="attribute", attr="HHRecordType"),
]


def test_usages_are_classified_by_shape() -> None:
    shapes = {(item.target_column, item.shape, item.name) for item in usages_from_rows(ROWS)}
    assert ("Transaction_Firm__c", "value", "TransactionFirmID") in shapes
    assert ("Legacy_ID__c", "prefix", "LegacyHHcPrefix") in shapes
    assert ("OwnerId", "fallback", "BackupOwnerID") in shapes
    assert ("Master_Payout_Date__c", "rule", "Master_Payout_Date") in shapes


def test_choice_matches_columns_by_name_and_prefers_held_then_support() -> None:
    usages = usages_from_rows(ROWS)
    columns = ["TRANSACTION_FIRM__C", "RECORDTYPEID", "LEGACY_ID__C", "NAME"]
    choices = choose(columns, usages, current_names=[])
    assert choices["TRANSACTION_FIRM__C"].name == "TransactionFirmID"
    assert choices["TRANSACTION_FIRM__C"].support == 3
    assert choices["RECORDTYPEID"].name == "HHRecordType"      # 2 mappings beat 1
    assert "NAME" not in choices
    # A firm value the current project already holds ranks first.
    held_first = choose(columns, usages, current_names=["LegacyHHcPrefix"])
    assert held_first["RECORDTYPEID"].name == "LegacyHHcPrefix"
    assert choose(columns, usages, current_names=[], min_support=3).keys() == {"TRANSACTION_FIRM__C"}


def test_apply_value_prefix_and_fallback_shapes() -> None:
    choices = choose(["TRANSACTION_FIRM__C", "LEGACY_ID__C", "OWNERID"], usages_from_rows(ROWS), current_names=[])
    firm = {"name": "TransactionFirmID", "type": "VARCHAR", "value": "001Qi00001Rb8gCIAR", "attribute_id": "a1"}
    row = {"target_column": "TRANSACTION_FIRM__C", "status": "draft",
           "source_columns": ["DB.S.CONTACTS.BUSINESS_ID"], "confidence": 0.4}
    replaced = apply(row, choices["TRANSACTION_FIRM__C"], firm, confidence=0.9, override_source=True)
    assert replaced["source_columns"] == ["DB.S.CONTACTS.BUSINESS_ID"]
    assert row["mapping_mode"] == "attribute" and row["attribute_name"] == "TransactionFirmID"
    assert row["constant_value"] == "001Qi00001Rb8gCIAR" and row["source_columns"] == []
    assert row["confidence"] == 0.9 and row["evidence_ids"]

    kept = {"target_column": "TRANSACTION_FIRM__C", "status": "draft", "source_columns": ["X.Y"]}
    assert apply(kept, choices["TRANSACTION_FIRM__C"], firm, confidence=0.9, override_source=False) is None
    assert kept.get("mapping_mode") is None

    prefix = {"target_column": "LEGACY_ID__C", "status": "draft", "source_columns": ["C.ID"],
              "expression": "CAST(C.ID AS VARCHAR(50))"}
    apply(prefix, choices["LEGACY_ID__C"], {"name": "LegacyHHcPrefix", "value": "TMD_RT_"},
          confidence=0.9, override_source=True)
    assert prefix["expression"] == "$LegacyHHcPrefix || CAST(C.ID AS VARCHAR(50))"

    existing_prefix = {"target_column": "LEGACY_ID__C", "status": "draft", "source_columns": ["C.ID"],
                       "expression": "'TMD_RT_' || CAST(C.ID AS VARCHAR(50))"}
    apply(existing_prefix, choices["LEGACY_ID__C"], {"name": "LegacyHHcPrefix", "value": "TMD_RT_"},
          confidence=0.9, override_source=True)
    assert existing_prefix["expression"] == "$LegacyHHcPrefix || CAST(C.ID AS VARCHAR(50))"

    flattened_prefix = {"target_column": "LEGACY_ID__C", "status": "draft", "source_columns": ["C.ID"],
                        "expression": "'TMD_RT_BAID_' || CAST(C.ID AS VARCHAR(50))"}
    apply(flattened_prefix, choices["LEGACY_ID__C"], {"name": "LegacyHHcPrefix", "value": "TMD_RT_"},
          confidence=0.9, override_source=True)
    assert flattened_prefix["expression"] == "$LegacyHHcPrefix || 'BAID_' || CAST(C.ID AS VARCHAR(50))"

    fallback = {"target_column": "OWNERID", "status": "draft", "source_columns": ["MU.TARGET_CRM_ID"]}
    apply(fallback, choices["OWNERID"], {"name": "BackupOwnerID", "value": "005Qi"}, confidence=0.9,
          override_source=True)
    assert fallback["expression"] == "COALESCE(MU.TARGET_CRM_ID, $BackupOwnerID)"

    existing_fallback = {"target_column": "OWNERID", "status": "draft", "source_columns": [],
                         "expression": "'005Qi'"}
    apply(existing_fallback, choices["OWNERID"], {"name": "BackupOwnerID", "value": "005Qi"},
          confidence=0.9, override_source=True)
    assert existing_fallback["mapping_mode"] == "attribute"
    assert existing_fallback["attribute_name"] == "BackupOwnerID"
    assert existing_fallback["expression"] is None

    # A row the user's own notes decided is never changed.
    noted = {"target_column": "OWNERID", "status": "draft", "source_columns": ["A.B"], "attachment_evidence": [{}]}
    assert apply(noted, choices["OWNERID"], {"name": "BackupOwnerID", "value": "x"}, confidence=0.9,
                 override_source=True) is None and "expression" not in noted


def test_known_values_skip_scripts_and_the_current_project() -> None:
    values = [
        {"PROJECT_ID": "4", "PROJECT_NAME": "EverNest", "ATTRIBUTE_NAME": "BackupOwnerID", "ATTRIBUTE_TYPE": "VARCHAR",
         "ATTRIBUTE_VALUE": "005Qi00000ZBGiAIAX", "ATTRIBUTE_ID": "1"},
        {"PROJECT_ID": "401", "PROJECT_NAME": "Test", "ATTRIBUTE_NAME": "BackupOwnerID", "ATTRIBUTE_TYPE": "VARCHAR",
         "ATTRIBUTE_VALUE": "005Qi';  -- default SET TransactionFirmID = '001'", "ATTRIBUTE_ID": "2"},
        {"PROJECT_ID": "9", "PROJECT_NAME": "Mine", "ATTRIBUTE_NAME": "BackupOwnerID", "ATTRIBUTE_TYPE": "VARCHAR",
         "ATTRIBUTE_VALUE": "mine", "ATTRIBUTE_ID": "3"},
    ]
    found = known_values(values, "backup_owner_id", exclude_project="9")
    assert [item["value"] for item in found] == ["005Qi00000ZBGiAIAX"]
    assert not usable_value("2026-13-01", "DATE") and usable_value("2026-01-01", "DATE")


def test_binding_and_hints_describe_the_firm_value() -> None:
    firm = {"name": "ClientStartDate", "type": "DATE", "value": "2026-01-01", "attribute_id": "a9"}
    assert binding(firm) == {
        "binding_id": "project-attribute:a9", "value": "$ClientStartDate", "resolved_value": "2026-01-01",
        "data_type": "DATE", "attribute_name": "ClientStartDate", "is_placeholder": True,
        "allow_project_specific_value": True, "resolution_status": "project_attribute",
        "provenance": "current_project_attribute",
    }
    choices = choose(["BFFS_CLIENTSTARTDATE__C"], usages_from_rows(
        [_usage("2901", "bffs_clientstartdate__c", mode="attribute", attr="ClientStartDate")]), ["ClientStartDate"])
    listed = hints(choices, {"CLIENTSTARTDATE": firm})
    assert listed[0]["placeholder"] == "$ClientStartDate"
    assert listed[0]["used_for"] == ["BFFS_CLIENTSTARTDATE__C (value)"]
    assert names_in("$A || $B || $A") == ["A", "B"]


class _Projects:
    def __init__(self, attributes):
        self.attributes = attributes
        self.created = []

    def list_project_attributes(self, _project_id):
        return self.attributes

    def firm_value_usages(self, _columns):
        return {"usages": ROWS, "values": [
            {"PROJECT_ID": "101", "PROJECT_NAME": "TMD", "ATTRIBUTE_NAME": "TransactionFirmID",
             "ATTRIBUTE_TYPE": "VARCHAR", "ATTRIBUTE_VALUE": "001Qi00001Rb8gCIAR", "ATTRIBUTE_ID": "t1"}]}

    def create_project_attribute(self, project_id, payload, *, user_id, **_):
        record = SimpleNamespace(attribute_id="new", attribute_name=payload.attribute_name,
                                 attribute_type=payload.attribute_type, attribute_value=payload.attribute_value)
        self.created.append((project_id, record))
        self.attributes = [*self.attributes, record]
        return record


def _handler(projects):
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.Lock()
    handler._projects = projects
    handler._settings = None
    handler._budget = None
    handler._trace = lambda *args, **kwargs: None
    handler._emit = lambda *args, **kwargs: None
    handler._actor = lambda state: SimpleNamespace(user_id="1")
    return handler


def test_workbench_binds_held_values_and_asks_for_missing_ones() -> None:
    held = SimpleNamespace(attribute_id="h1", attribute_name="LegacyHHcPrefix", attribute_type="VARCHAR",
                           attribute_value="TMD_RT_")
    projects = _Projects([held])
    handler = _handler(projects)
    state = {"project_id": "1601", "prompt": "Migrate households"}
    context = handler._firm_value_context(state, ["TRANSACTION_FIRM__C", "LEGACY_ID__C"])
    rows = [
        {"target_column": "TRANSACTION_FIRM__C", "status": "unresolved", "source_columns": []},
        {"target_column": "LEGACY_ID__C", "status": "draft", "source_columns": ["C.ID"]},
    ]
    reviews = handler._apply_firm_values(state, rows, context, target_table="DB.T.HOUSEHOLD",
                                         target_column_contracts=[{"name": "TRANSACTION_FIRM__C", "type": "TEXT"}])
    assert rows[1]["expression"] == "$LegacyHHcPrefix || C.ID"
    assert rows[0]["status"] == "unresolved"
    assert len(reviews) == 1 and reviews[0]["blocking"] is True
    details = reviews[0]["details"]
    assert details["firm_value_name"] == "TransactionFirmID"
    assert details["candidates"][0]["constant_value"] == "001Qi00001Rb8gCIAR"
    assert projects.created == []   # another firm's value is never copied without review
    bindings = handler._precedent_value_bindings(state, [])
    assert [item.value for item in bindings] == ["$LegacyHHcPrefix"]


def test_workbench_creates_a_firm_value_the_user_stated() -> None:
    projects = _Projects([])
    handler = _handler(projects)
    state = {"project_id": "1601", "prompt": "TransactionFirmID = 001Qi00001Rb8gCIAR"}
    context = handler._firm_value_context(state, ["TRANSACTION_FIRM__C"])
    rows = [{"target_column": "TRANSACTION_FIRM__C", "status": "unresolved", "source_columns": []}]
    reviews = handler._apply_firm_values(state, rows, context, target_table="DB.T.HOUSEHOLD",
                                         target_column_contracts=[{"name": "TRANSACTION_FIRM__C", "type": "TEXT"}])
    assert reviews == []
    assert projects.created[0][1].attribute_value == "001Qi00001Rb8gCIAR"
    assert projects.created[0][1].attribute_type == "VARCHAR"
    assert rows[0]["mapping_mode"] == "attribute" and rows[0]["status"] == "draft"


def test_review_choice_creates_the_missing_firm_value_and_binds_the_row() -> None:
    from app.agent_runs.review_apply import ensure_firm_value
    from app.core.workspace_snapshot import apply_review_choice

    projects = _Projects([])
    candidate = {"attribute_name": "TransactionFirmID", "constant_value": "001Qi",
                 "firm_value": {"name": "TransactionFirmID", "type": "VARCHAR", "value": "001Qi",
                                "source_project_id": "101"}}
    chosen = ensure_firm_value(projects, "1601", candidate, user_id="1")
    assert projects.created and chosen["constant_value"] == "001Qi"
    snapshot = apply_review_choice({"mapping_rows": [{"id": "r1", "target_column": "TRANSACTION_FIRM__C",
                                                      "status": "UNMAPPED", "source_columns": []}]},
                                   "TRANSACTION_FIRM__C", chosen, answered_by="1")
    row = snapshot["mapping_rows"][0]
    assert (row["mapping_mode"], row["attribute_name"], row["constant_value"], row["status"]) == (
        "attribute", "TransactionFirmID", "001Qi", "MAPPED")
    # Applying again binds to the value the project now holds.
    again = ensure_firm_value(projects, "1601", {**candidate, "constant_value": "other"}, user_id="1")
    assert again["constant_value"] == "001Qi" and len(projects.created) == 1


def test_review_choices_label_firm_values_and_accept_a_typed_value() -> None:
    from app.agent_runs.service import AgentRunService
    choices = AgentRunService._mapping_review_choices(
        [{"attribute_name": "TransactionFirmID", "constant_value": "001Qi",
          "firm_value": {"projects": ["TMD"]}, "confidence": 0.45, "reason": "TMD uses it"}],
        {"firm_value_name": "TransactionFirmID", "firm_value_type": "TEXT"},
    )
    assert choices[0].label == "Firm value TransactionFirmID = 001Qi (used in TMD)"
    assert choices[-1].selection_payload["firm_value"] == {"name": "TransactionFirmID", "type": "TEXT"}
