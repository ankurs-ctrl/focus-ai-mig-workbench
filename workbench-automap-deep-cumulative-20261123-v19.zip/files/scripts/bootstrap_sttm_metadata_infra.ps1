param(
    [string]$EnvFile = "",
    [switch]$LinkingMigrationOnly,
    [switch]$PerformanceR13Only
)

$ErrorActionPreference = "Stop"

$RootDir = Split-Path -Parent $PSScriptRoot
if (-not $EnvFile) {
    $EnvFile = Join-Path $RootDir "infra/snowflake/env/client.env"
}

$ToolsVenv = Join-Path $RootDir ".client-tools-venv"
$PythonExe = if ($IsWindows) {
    Join-Path $ToolsVenv "Scripts/python.exe"
} else {
    Join-Path $ToolsVenv "bin/python"
}
$ScriptPath = Join-Path $PSScriptRoot "bootstrap_sttm_metadata_infra.py"

function Import-EnvFile {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "Env file not found: $Path"
    }

    $values = @{}
    foreach ($line in Get-Content $Path) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("#")) {
            continue
        }

        $parts = $trimmed -split "=", 2
        if ($parts.Count -ne 2) {
            continue
        }

        $key = $parts[0].Trim()
        $value = $parts[1].Trim()
        if (($value.StartsWith('"') -and $value.EndsWith('"')) -or
            ($value.StartsWith("'") -and $value.EndsWith("'"))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        $values[$key] = $value
    }
    return $values
}

if (-not (Test-Path $PythonExe)) {
    Write-Host "Client tools virtualenv is not bootstrapped yet. Running bootstrap script first."
    & (Join-Path $PSScriptRoot "bootstrap_client_spcs_tools.ps1")
}

if (-not (Test-Path $PythonExe)) {
    throw "Client tools Python executable not found: $PythonExe"
}

$cfg = Import-EnvFile -Path $EnvFile

& $PythonExe -c "import snowflake.connector"
if ($LASTEXITCODE -ne 0) {
    & $PythonExe -m pip install --upgrade snowflake-connector-python
    if ($LASTEXITCODE -ne 0) {
        throw "Could not install snowflake-connector-python."
    }
}

Write-Host "Bootstrapping STTM metadata infra into $($cfg['SNOWFLAKE_DATABASE']).$($cfg['SNOWFLAKE_SCHEMA'])"

$pyArgs = @(
    $ScriptPath,
    "--account", $cfg["SNOWFLAKE_ACCOUNT"],
    "--user", $cfg["SNOWFLAKE_USER"],
    "--database", $cfg["SNOWFLAKE_DATABASE"],
    "--schema", $cfg["SNOWFLAKE_SCHEMA"]
)

if ($LinkingMigrationOnly) {
    $pyArgs += "--linking-migration-only"
}
if ($PerformanceR13Only) {
    $pyArgs += "--performance-r13-only"
}

if ($cfg["FIR_TASK_POLICY"]) {
    $pyArgs += @("--fir-task-policy", $cfg["FIR_TASK_POLICY"])
}
if ($cfg["FIR_QUEUE_INTERVAL_MINUTES"]) {
    $pyArgs += @("--fir-queue-interval-minutes", $cfg["FIR_QUEUE_INTERVAL_MINUTES"])
}

if ($cfg["PRESERVE_SEMANTIC_REGISTRY"] -eq "true") {
    $pyArgs += "--preserve-semantic-registry"
}

$semanticDatabase = if ($cfg.ContainsKey("SNOWFLAKE_SEMANTIC_VIEWS_DATABASE") -and
    $cfg["SNOWFLAKE_SEMANTIC_VIEWS_DATABASE"]) {
    $cfg["SNOWFLAKE_SEMANTIC_VIEWS_DATABASE"]
} else {
    $cfg["SNOWFLAKE_DATABASE"]
}

$semanticSchema = if ($cfg.ContainsKey("SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA") -and
    $cfg["SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA"]) {
    $cfg["SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA"]
} else {
    $cfg["SNOWFLAKE_SCHEMA"]
}

$semanticTableObject = if ($cfg.ContainsKey("SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE") -and
    $cfg["SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE"]) {
    $cfg["SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE"]
} else {
    "LATEST_TABLE_VIEWS"
}

$semanticColumnObject = if ($cfg.ContainsKey("SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE") -and
    $cfg["SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE"]) {
    $cfg["SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE"]
} else {
    "LATEST_COLUMN_VIEWS"
}

$semanticNativeObject = if ($cfg.ContainsKey("SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE") -and
    $cfg["SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE"]) {
    $cfg["SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE"]
} else {
    "LATEST_NATIVE_VIEWS"
}

$pyArgs += @(
    "--semantic-database", $semanticDatabase,
    "--semantic-schema", $semanticSchema,
    "--semantic-table-object", $semanticTableObject,
    "--semantic-column-object", $semanticColumnObject,
    "--semantic-native-object", $semanticNativeObject
)

if ($cfg.ContainsKey("SNOWFLAKE_PASSWORD") -and $cfg["SNOWFLAKE_PASSWORD"]) {
    $pyArgs += @("--password", $cfg["SNOWFLAKE_PASSWORD"])
}
if ($cfg.ContainsKey("SNOWFLAKE_AUTHENTICATOR") -and $cfg["SNOWFLAKE_AUTHENTICATOR"]) {
    $pyArgs += @("--authenticator", $cfg["SNOWFLAKE_AUTHENTICATOR"])
}
if ($cfg.ContainsKey("SNOWFLAKE_HOST") -and $cfg["SNOWFLAKE_HOST"]) {
    $pyArgs += @("--host", $cfg["SNOWFLAKE_HOST"])
}
if ($cfg.ContainsKey("SNOWFLAKE_ROLE") -and $cfg["SNOWFLAKE_ROLE"]) {
    $pyArgs += @("--role", $cfg["SNOWFLAKE_ROLE"])
}
if ($cfg.ContainsKey("SNOWFLAKE_WAREHOUSE") -and $cfg["SNOWFLAKE_WAREHOUSE"]) {
    $pyArgs += @("--warehouse", $cfg["SNOWFLAKE_WAREHOUSE"])
}

$authenticator = if ($cfg.ContainsKey("SNOWFLAKE_AUTHENTICATOR")) {
    [string]$cfg["SNOWFLAKE_AUTHENTICATOR"]
} else {
    ""
}

$privateKeyFile = $null
$previousPassphrase = $env:PRIVATE_KEY_PASSPHRASE

try {
    if ($authenticator.Trim().ToLowerInvariant() -eq "snowflake_jwt") {
        $keyContent = $env:PKCS8_KEY_CONTENT
        $passphrase = if ($env:KEY_PASSPHRASE) {
            $env:KEY_PASSPHRASE
        } else {
            $env:PRIVATE_KEY_PASSPHRASE
        }

        if ([string]::IsNullOrWhiteSpace($keyContent)) {
            throw "PKCS8_KEY_CONTENT is required for SNOWFLAKE_JWT authentication."
        }
        if ([string]::IsNullOrWhiteSpace($passphrase)) {
            throw "KEY_PASSPHRASE or PRIVATE_KEY_PASSPHRASE is required for the encrypted private key."
        }

        $keyDirectory = Join-Path $RootDir ".secrets"
        New-Item -ItemType Directory -Force -Path $keyDirectory | Out-Null
        $privateKeyFile = Join-Path $keyDirectory "sttm_bootstrap_rsa_pkcs8.p8"

        # Accept either a complete encrypted PEM or its base64 body.
        $body = $keyContent `
            -replace '-----BEGIN ENCRYPTED PRIVATE KEY-----', '' `
            -replace '-----END ENCRYPTED PRIVATE KEY-----', '' `
            -replace '\s+', ''
        $wrappedBody = ($body -replace '.{64}', "`$0`n").TrimEnd()
        $pem = "-----BEGIN ENCRYPTED PRIVATE KEY-----`n$wrappedBody`n-----END ENCRYPTED PRIVATE KEY-----`n"

        [System.IO.File]::WriteAllText(
            $privateKeyFile,
            $pem,
            [System.Text.UTF8Encoding]::new($false)
        )
        if (-not $IsWindows) {
            & chmod 600 $privateKeyFile
            if ($LASTEXITCODE -ne 0) {
                throw "Could not restrict permissions on the private-key file."
            }
        }

        $env:PRIVATE_KEY_PASSPHRASE = $passphrase
        $pyArgs += @("--private-key-file", $privateKeyFile)
    }

    $env:PYTHONUTF8 = "1"
    $env:PYTHONIOENCODING = "utf-8"

    & $PythonExe @pyArgs
    if ($LASTEXITCODE -ne 0) {
        throw "STTM metadata bootstrap failed with exit code $LASTEXITCODE"
    }
} finally {
    $env:PRIVATE_KEY_PASSPHRASE = $previousPassphrase
    if ($privateKeyFile -and (Test-Path $privateKeyFile)) {
        Remove-Item $privateKeyFile -Force
    }
}
