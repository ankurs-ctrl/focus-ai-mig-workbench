import type {
  DerivedSource,
  JoinConfig,
  MappingState,
  TableNode,
} from "@/features/sttm/types/sttm.types";

/**
 * Semantic key of the workspace an authored (uploaded or edited) SQL artifact
 * was written against.
 *
 * Authored SQL stays authoritative only while the durable relation graph and
 * mappings still match it. The key deliberately excludes metadata that loads
 * after hydration (column catalogs, semantic bundles, catalog descriptions) so
 * that opening a mapping never makes its authored SQL look stale, while any
 * user edit to sources, joins, derived SQL, mappings, or filters does.
 */
export type AuthoredSqlKeyInput = {
  sources: TableNode[];
  /** Selected target identity, excluding its reloadable column catalog. */
  targets?: TableNode[];
  derivedSources: DerivedSource[];
  relationships: JoinConfig[];
  mappings: MappingState[];
  drivingTableId?: string | null;
  sourceFilterSql?: string | null;
  sourceGroupBySql?: string | null;
  sourceOrderBySql?: string | null;
  sourceQueryModifiers?: Record<string, string>;
};

const text = (value: unknown) => String(value ?? "").trim();
// Normalize only unquoted identifiers; quoted case and spaces are significant.
const upper = (value: unknown) => text(value).replace(/"(?:""|[^"])*"|[^\"]+/g,
  part => part.startsWith('"') ? part : part.toUpperCase());
const sqlText = (value: unknown) => String(value ?? "");

function digest(value: string, version = "ask3"): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return `${version}:${hash.toString(16).padStart(8, "0")}:${value.length.toString(36)}`;
}

/** Only the empty shape emitted by target-catalog hydration has no SQL intent. */
export function isEmptyTargetPlaceholder(mapping: MappingState): boolean {
  if (mapping.status !== "UNMAPPED" || mapping.rule !== "Select...") return false;
  // Do not discard false/zero/empty-string constants or unrecognized future intent.
  const catalogFields = new Set(["id", "targetColumn", "targetType", "targetOrdinal", "status", "rule"]);
  return Object.entries(mapping).every(([key, value]) => {
    if (catalogFields.has(key)) return true;
    if (key === "mappingMode") return value == null || value === "source";
    if (key === "manuallySaved" || key === "manuallyEditedAfterAutoMap" || key === "descriptionEdited") return !value;
    return value == null || (Array.isArray(value) && value.length === 0);
  });
}

export function computeAuthoredSqlSemanticKey(input: AuthoredSqlKeyInput): string {
  return authoredSqlKey(input);
}

function authoredSqlKey(input: AuthoredSqlKeyInput): string {
  const sources = input.sources
    .filter((table) => table.isSelected)
    .map((table) => upper(table.qualifiedName))
    .sort();
  const derived = input.derivedSources
    .filter((source) => source.isSelected)
    .map((source) => [text(source.id), sqlText(source.sqlText)])
    .sort(([left], [right]) => left.localeCompare(right));
  const relationships = input.relationships
    .filter((join) => !join.reviewRequired)
    .map((join) => [
      text(join.leftTableId),
      text(join.rightTableId),
      upper(join.joinType || "INNER"),
      (() => {
        const rendered = (join.conditions ?? []).map((condition, index) => {
          const textValue = [
            upper(condition.leftColumn),
            text(condition.operator || "="),
            upper(condition.rightColumn),
          ].join(" ");
          return index > 0 && String(condition.connector ?? "").toUpperCase() === "OR" ? `${textValue}|OR` : textValue;
        });
        return rendered.some((item) => item.endsWith("|OR")) ? rendered : [...rendered].sort();
      })(),
      ...(join.sqlPredicate ? [join.sqlPredicate] : []),
    ])
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
  const mappings = input.mappings
    .filter((mapping) => !isEmptyTargetPlaceholder(mapping))
    .map((mapping) => [
      upper(mapping.targetColumn),
      text(mapping.status),
      text(mapping.mappingMode || "source"),
      (mapping.sourceColumns ?? (mapping.sourceColumn ? [mapping.sourceColumn] : [])).map(text),
      sqlText(mapping.expression),
      mapping.constantValue ?? null,
      text(mapping.targetType), sqlText(mapping.rule), text(mapping.attributeName),
      sqlText(mapping.nlRule), text(mapping.targetSqlName),
    ])
    .sort((left, right) => String(left[0]).localeCompare(String(right[0])));
  return digest(JSON.stringify({
    sources,
    targets: (input.targets ?? []).filter(table => table.isSelected).map(table => upper(table.qualifiedName)).sort(),
    derived,
    relationships,
    mappings,
    driving: text(input.drivingTableId),
    filter: sqlText(input.sourceFilterSql),
    groupBy: sqlText(input.sourceGroupBySql),
    orderBy: sqlText(input.sourceOrderBySql),
    ...(Object.keys(input.sourceQueryModifiers ?? {}).length ? { queryModifiers: input.sourceQueryModifiers } : {}),
  }));
}

/**
 * True when authored SQL exists and the workspace still matches the key it was
 * written against. Legacy keys collapsed SQL literals and cannot prove currency.
 * Keep their SQL for recovery, but require explicit Sync before rebinding it.
 */
export function authoredSqlIsCurrent(
  authoredSql: string | null | undefined,
  storedKey: string | null | undefined,
  input: AuthoredSqlKeyInput,
): boolean {
  if (!text(authoredSql)) return false;
  if (!storedKey?.startsWith("ask3:")) return false;
  return storedKey === computeAuthoredSqlSemanticKey(input);
}
