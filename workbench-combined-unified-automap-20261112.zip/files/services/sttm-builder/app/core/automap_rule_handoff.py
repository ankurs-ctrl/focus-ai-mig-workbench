"""Checked routing of existing Auto-map definitions to the scalar-rule specialist."""
import hashlib
import json
import re
from sqlglot import exp, parse_one
from app.core.mapping_contracts import valid_attribute_expression


def definition_hash(mapping, context=None):
    body = {key: getattr(mapping, key) for key in ('source_attributes', 'source_dependencies',
        'mapping_mode', 'constant_value', 'attribute_name', 'preprocessing_rule', 'value_binding_ids',
        'preprocessing_nl_rule', 'rule_intent')}
    if context is not None:
        graph = context.relation_graph
        if graph:
            lookup = {identifier: binding.value for binding in graph.value_bindings
                      for identifier in (binding.binding_id, binding.value)}
            body['value_binding_ids'] = sorted({lookup.get(identifier, identifier) for identifier in body['value_binding_ids']})
        body['workspace'] = context.model_dump(mode='json', include={'relation_graph', 'mapping_intent', 'semantic_bundle_hash', 'target_table'})
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def custom_rule(mapping):
    expression = (mapping.preprocessing_rule or '').strip()
    nl = (mapping.preprocessing_nl_rule or '').strip()
    descriptive_direct = bool(re.match(r'^(?:direct (?:mapping|copy|assignment)|copy (?:the )?source|use (?:the )?(?:approved )?firm value)\b', nl, re.I))
    operation_intent = bool(re.search(r'\b(case|when|if|concat(?:enate)?|trim|upper|lower|convert|cast|format|combine|prefix|suffix|coalesce|replace|calculate|derive)\b', nl, re.I))
    direct_value = mapping.mapping_mode in {'constant', 'attribute'} and (
        not expression or expression == mapping.constant_value or expression.upper() in {'NULL', 'TRUE', 'FALSE'})
    intent = bool(mapping.rule_intent or (nl and not descriptive_direct and (not direct_value or operation_intent)))
    if intent:
        return True
    if mapping.mapping_mode in {'constant', 'attribute'} and (not expression or expression == mapping.constant_value):
        return False
    if valid_attribute_expression(expression):
        tree = parse_one(expression, read='snowflake')
        if mapping.mapping_mode == 'source' and isinstance(tree, exp.Column):
            return False
        if mapping.mapping_mode in {'constant', 'attribute'} and expression.upper() in {'NULL', 'TRUE', 'FALSE'}:
            return False
        return True
    return (len(mapping.source_attributes) > 1
            or mapping.transformation_classification in {'complex', 'simple_multi_source'}
            or str(mapping.preprocessing_rule_type or '').upper() not in {'', 'DIRECT', 'IDENTITY', 'VALUE', 'SELECT...'})


def rule_route(mapping, context=None):
    if custom_rule(mapping):
        if mapping.rule_stage == 'rule_complete' and mapping.rule_definition_hash == definition_hash(mapping, context):
            return 'rule_complete', 'The unchanged rule was already completed by the specialist.'
        return 'rule_pending', 'Custom SQL or transformation intent requires the transformation specialist.'
    if mapping.mapping_mode in {'constant', 'attribute'}:
        return 'value', 'Direct constant or Firm Value assignment; no custom rule is required.'
    if len(mapping.source_attributes) == 1:
        return 'direct', 'One source column with no custom-rule intent.'
    return 'missing_dependency', 'No supported binding or executable Value definition is available.'


class RuleStageBudgetExhausted(TimeoutError):
    """No rule dispatch occurred: the existing shared allowance is exhausted."""


def review_optional_history_claims(mapping, *, recipe_ids, precedent_ids):
    """Unsubstantiated positive history claims are review notes, not SQL errors.

    Citations remain untouched for authorization checks. Overrides/corrections,
    current bindings, required reads and executable SQL are never waived here.
    """
    notes = list((mapping.decision_basis or {}).get('history_review_required') or [])
    if mapping.pattern_decision in {'accept_exact_precedent', 'adapt_pattern'} and not set(mapping.used_learning_ids) & set(recipe_ids):
        mapping.pattern_decision = 'unresolved'
        notes.append('Historical recipe reuse was not cited; review this draft against the supplied evidence.')
    if mapping.precedent_decision == 'accept_precedent' and mapping.precedent_mapping_id not in set(precedent_ids):
        mapping.precedent_decision = 'unresolved'
        mapping.precedent_mapping_id = None
        notes.append('Linked mapping reuse was not established; no linked precedent is credited.')
    if notes:
        if 'Historical attribution requires review.' not in (mapping.confidence_reason or ''):
            mapping.confidence_reason = ((mapping.confidence_reason or '') + ' Historical attribution requires review.').strip()
        mapping.decision_basis = {**(mapping.decision_basis or {}), 'history_review_required': list(dict.fromkeys(notes))}
    return mapping


def match_retrieved_recipe(mapping, store, target, context):
    """Attribute exact expression matches to already-read trusted FIR, not guesses.

    This does not choose a mapping or establish population compatibility. Only
    exact current SQL and unambiguous named CTE alias adaptation are matched.
    """
    if not mapping.preprocessing_rule or context.relation_graph is None:
        return mapping
    aliases = {}
    for node in context.relation_graph.nodes:
        if node.original_cte_name:
            aliases.setdefault(node.original_cte_name.upper(), set()).add(node.alias)
    def canonical(text):
        tree = parse_one(text, read='snowflake')
        for column in tree.find_all(exp.Column):
            replacements = aliases.get(column.table.upper(), set())
            qualifier = column.args.get('table')
            case_sensitive = qualifier is not None and qualifier.args.get('quoted') and qualifier.name != qualifier.name.upper()
            if len(replacements) == 1 and not case_sensitive:
                column.set('table', exp.to_identifier(next(iter(replacements))))
        for identifier in tree.find_all(exp.Identifier):
            if not identifier.args.get('quoted') or identifier.name == identifier.name.upper():
                identifier.set('this', identifier.name.upper());identifier.set('quoted', False)
        return tree.sql(dialect='snowflake')
    try: current = canonical(mapping.preprocessing_rule)
    except Exception:return mapping
    allowed = store.recipe_ids(target) & store.evidence_ids(target)
    matched = []
    for category, records in store.evidence.get(target, {}).items():
        if 'target_mapping_patterns' not in category:continue
        for record in records:
            pattern = record.get('pattern') or record
            identity = pattern.get('pattern_id')
            if identity not in allowed or pattern.get('validation_status') not in {'validated','accepted','published'}:
                continue
            if record.get('applicable') is not True or record.get('guidance_only'):continue
            expression = (pattern.get('mapping_recipe') or {}).get('expression')
            try:
                if expression and canonical(expression) == current:matched.append(identity)
            except Exception:continue
    if matched:
        inferred = set(matched) - set(mapping.used_learning_ids)
        if inferred:
            mapping.decision_basis = {**mapping.decision_basis, 'backend_inferred_recipe_ids': sorted(inferred)}
        mapping.used_learning_ids = sorted(set(mapping.used_learning_ids) | set(matched))
        mapping.decision_basis = {**mapping.decision_basis, 'backend_matched_recipe_ids': sorted(set(matched))}
    return mapping
