from types import SimpleNamespace

from app.core.project_service import ProjectService
from app.schema.project import (
    ProjectCreateFromTemplateRequest,
    ProjectRecord,
    ProjectTemplateRecord,
    ProjectTemplateTarget,
    STTMRecord,
)


class _TransactionQuery:
    def collect(self):
        return []


class _TransactionSession:
    def __init__(self) -> None:
        self.statements: list[str] = []

    def sql(self, statement: str, params=None):
        self.statements.append(statement)
        if statement.startswith('UPDATE') and 'BOOTSTRAP_LOCK' in statement:
            return SimpleNamespace(collect=lambda:[{'number of rows updated':1}])
        return _TransactionQuery()


def _service() -> ProjectService:
    service = ProjectService.__new__(ProjectService)
    service._settings = SimpleNamespace(snowflake_projects_table='PROJECTS', snowflake_workspace_snapshots_table='SNAPSHOTS')
    service._session = _TransactionSession()
    service.ensure_storage_exists = lambda: None
    service._table_columns = lambda table:{'SNAPSHOT_ID','SNAPSHOT_PAYLOAD','STTM_ID'}
    service._qualified_name = lambda name: 'DB.S.' + name
    service._initialize_blank_mappings = lambda project, payloads, **kwargs: [service.create_sttm(project.project_id, payload,
        user_id=kwargs['user_id'], display_name=kwargs['display_name'], session_id=None, thread_id=None, emit_fir=False) for payload in payloads]
    return service


def _template() -> ProjectTemplateRecord:
    return ProjectTemplateRecord(
        template_id="CRM_MIGRATION",
        template_version="1.0",
        label="CRM Migration",
        source_systems=["REDTAIL", "OTHER"],
        target_contract_id="CRM_COMMON_TARGET",
        target_contract_version="1.0",
        target_database="CLIENT_DB",
        target_schema="SALESFORCE",
        available_targets=[
            ProjectTemplateTarget(
                logical_target_key="CRM.HOUSEHOLD",
                table_name="HOUSEHOLD",
                physical_fqn="CLIENT_DB.SALESFORCE.HOUSEHOLD",
                columns=[{"name": "HOUSEHOLD_ID", "type": "NUMBER", "primary_key": True}],
                column_count=1,
            ),
            ProjectTemplateTarget(
                logical_target_key="CRM.CALLS",
                table_name="CALLS",
                physical_fqn="CLIENT_DB.SALESFORCE.CALLS",
                columns=[{"name": "CALL_ID", "type": "NUMBER", "primary_key": True}],
                column_count=1,
            ),
        ],
        missing_targets=[],
    )


def test_template_bootstrap_creates_target_locked_shells_without_fir() -> None:
    service = _service()
    service.get_project_templates = lambda **_kwargs: [_template()]
    service.list_projects = lambda: []
    created_payloads = []
    project = ProjectRecord(project_id="project-1", project_name="Migration")

    def create_project(payload, **kwargs):
        assert kwargs["emit_fir"] is False
        assert payload.metadata["source_system_key"] == "REDTAIL"
        return project.model_copy(update={"metadata": payload.metadata})

    def create_sttm(project_id, payload, **kwargs):
        assert project_id == "project-1"
        assert kwargs["emit_fir"] is False
        created_payloads.append(payload)
        return STTMRecord(
            sttm_id=f"sttm-{len(created_payloads)}",
            project_id=project_id,
            sttm_name=payload.sttm_name,
            target_table=payload.target_table.qualified_name,
            metadata=payload.metadata,
        )

    service.create_project = create_project
    service.create_sttm = create_sttm

    result = service.create_project_from_template(
        ProjectCreateFromTemplateRequest(
            project_name="Migration",
            source_system_key="REDTAIL",
            idempotency_key="bootstrap-123",
        ),
        user_id="user-1",
    )

    assert [item.target_table for item in result.mappings] == [
        "CLIENT_DB.SALESFORCE.HOUSEHOLD",
        "CLIENT_DB.SALESFORCE.CALLS",
    ]
    assert created_payloads[0].metadata["logical_target_table_key"] == "CRM.HOUSEHOLD"
    snapshot = created_payloads[0].workspace_snapshot.model_dump(mode="json")
    assert snapshot["mapping_rows"][0]["target_column"] == "HOUSEHOLD_ID"
    assert service._session.statements[0] == 'BEGIN'
    assert service._session.statements[-1] == 'COMMIT'
    assert service._session.statements.count('BEGIN') == 1


def test_empty_project_is_allowed_when_target_schema_has_no_tables() -> None:
    service = _service()
    empty_template = _template().model_copy(update={"available_targets": []})
    service.get_project_templates = lambda **_kwargs: [empty_template]
    service.list_projects = lambda: []
    service.create_project = lambda payload, **_kwargs: ProjectRecord(
        project_id="project-1",
        project_name=payload.project_name,
        metadata=payload.metadata,
    )

    result = service.create_project_from_template(
        ProjectCreateFromTemplateRequest(
            project_name="Exception",
            source_system_key="OTHER",
            bootstrap_mode="EMPTY",
            idempotency_key="bootstrap-empty",
        ),
        user_id="user-1",
    )

    assert result.mappings == []
    assert result.bootstrap_status == "COMPLETE"


def test_selected_target_subset_creates_only_chosen_mapping():
    service = _service()
    service.get_project_templates = lambda **kwargs: [_template()]
    service.list_projects = lambda: []
    service.create_project = lambda payload, **kwargs: ProjectRecord(project_id='subset',project_name=payload.project_name,metadata=payload.metadata)
    created = []
    def create(project_id,payload,**kwargs):
        created.append(payload.target_table.table)
        return STTMRecord(sttm_id='one',project_id=project_id,sttm_name=payload.sttm_name,metadata=payload.metadata)
    service.create_sttm = create
    result = service.create_project_from_template(ProjectCreateFromTemplateRequest(project_name='Subset',
        source_system_key='REDTAIL',idempotency_key='subset-key',selected_target_tables=['calls']),user_id='fixture')
    assert created == ['CALLS']
    assert result.project.metadata['selected_target_tables'] == ['CALLS']


def test_unknown_target_selection_is_rejected_before_project_creation():
    import pytest
    from app.core.exceptions import AppValidationError
    service = _service()
    service.get_project_templates = lambda **kwargs: [_template()]
    for selected in [[], ['SECRET_TABLE']]:
        with pytest.raises(AppValidationError,match='approved target'):
            service.create_project_from_template(ProjectCreateFromTemplateRequest(project_name='Bad',
                source_system_key='REDTAIL',idempotency_key='invalid-key',selected_target_tables=selected),user_id='fixture')


def test_target_columns_survive_unavailable_optional_key_metadata():
    service = _service()
    class Session:
        def sql(self, statement):
            assert 'KEY_COLUMN_USAGE' not in statement
            if statement.startswith('SHOW PRIMARY KEYS'):
                raise RuntimeError('Optional key metadata unavailable')
            row = SimpleNamespace(as_dict=lambda: {'TABLE_NAME':'HOUSEHOLD','COLUMN_NAME':'ID',
                'DATA_TYPE':'TEXT','IS_NULLABLE':'YES','ORDINAL_POSITION':1})
            return SimpleNamespace(collect=lambda: [row])
    service._session = Session()
    result = service._discover_target_contract_columns(database='CLIENT_DB',schema='TARGET_TABLES',table_names=['HOUSEHOLD'])
    assert result['HOUSEHOLD'][0]['name'] == 'ID'
    assert result['HOUSEHOLD'][0]['primary_key'] is False


def test_json_contract_restricts_approved_tables_and_columns() -> None:
    service = ProjectService.__new__(ProjectService)
    service._settings = SimpleNamespace(
        crm_target_tables="IGNORED_TABLE",
        crm_target_contract_json=(
            '{"tables":{"HOUSEHOLD":{"columns":['
            '{"name":"HOUSEHOLD_ID","semantic_role":"primary_key"},'
            '"NAME"]}}}'
        ),
    )

    tables, columns = service._crm_target_contract()

    assert tables == ["HOUSEHOLD"]
    assert [item["name"] for item in columns["HOUSEHOLD"]] == [
        "HOUSEHOLD_ID",
        "NAME",
    ]
    assert columns["HOUSEHOLD"][0]["semantic_role"] == "primary_key"


def test_all_ten_template_mappings_receive_the_authenticated_creator_display_name():
    service = _service()
    targets = [ProjectTemplateTarget(logical_target_key=f"CRM.TARGET_{index}", table_name=f"TARGET_{index}",
        physical_fqn=f"CLIENT_DB.TARGETS.TARGET_{index}", columns=[{"name": "ID", "type": "NUMBER"}], column_count=1)
        for index in range(10)]
    template = _template().model_copy(update={"target_schema": "TARGETS", "available_targets": targets})
    service.get_project_templates = lambda **kwargs: [template]
    service.list_projects = lambda: []
    service.create_project = lambda payload, **kwargs: ProjectRecord(project_id="project", project_name=payload.project_name, metadata=payload.metadata)
    creators = []
    def create(project_id, payload, **kwargs):
        creators.append((kwargs["user_id"], kwargs["display_name"]))
        return STTMRecord(sttm_id=str(len(creators)), project_id=project_id, sttm_name=payload.sttm_name, metadata=payload.metadata)
    service.create_sttm = create
    result = service.create_project_from_template(ProjectCreateFromTemplateRequest(project_name="All targets",
        source_system_key="REDTAIL", target_database="CLIENT_DB", target_schema="TARGETS", idempotency_key="all-ten-targets"),
        user_id="42", display_name="Ankur Sharma")
    assert len(result.mappings) == 10
    assert creators == [("42", "Ankur Sharma")] * 10


def test_template_mapping_persists_display_name_without_replacing_numeric_actor_identity():
    import json
    from app.schema.project import STTMCreateRequest
    service = _service()
    service._settings = SimpleNamespace(snowflake_sttm_table="DB.META.STTMS")
    service._qualified_name = lambda name: name
    service._validate_project_value_bindings = lambda *args: None
    service._actor_column_values = lambda table, actor: {"ACTOR_USER_ID": service._quote_literal(actor)}
    service._order_by_expr = lambda *args: "STTM_ID"
    written = {}
    service._insert_existing_columns_bound = lambda table, values: written.update(values)
    def sql(statement):
        metadata = json.loads(written["STTM_METADATA"][1][0])
        row = {"STTM_ID": "7", "PROJECT_ID": "project", "STTM_NAME": "Redtail → Household", "STTM_METADATA": metadata}
        return SimpleNamespace(collect=lambda: [SimpleNamespace(as_dict=lambda: row)])
    service._session = SimpleNamespace(sql=sql)
    result = service.create_sttm("project", STTMCreateRequest(sttm_name="Redtail → Household", metadata={"bootstrap_origin": "project_template"}),
        user_id="42", display_name="Ankur Sharma", session_id=None, thread_id=None, emit_fir=False)
    assert written["ACTOR_USER_ID"] == "'42'"
    assert result.metadata["actor_user_id"] == "42"
    assert result.metadata["created_by_name"] == "Ankur Sharma"
    assert result.sttm_name == "Redtail → Household"


def test_legacy_template_creator_lookup_is_batched_and_does_not_relabel_manual_mappings():
    service = _service()
    service._settings = SimpleNamespace(qualified_users_table="DB.META.USERS")
    service._table_columns = lambda table: {"USER_ID", "DISPLAY_NAME", "SNOWFLAKE_USER"}
    calls = []
    def sql(statement, params=None):
        calls.append((statement, params))
        return SimpleNamespace(collect=lambda: [SimpleNamespace(as_dict=lambda: {"CREATOR_ID": "42", "CREATOR_NAME": "Ankur Sharma"}),
            SimpleNamespace(as_dict=lambda: {"CREATOR_ID": "84", "CREATOR_NAME": "Another Creator"})])
    service._session = SimpleNamespace(sql=sql)
    mappings = [STTMRecord(sttm_id=str(index), project_id="project", metadata={"bootstrap_origin": "project_template", "actor_user_id": "42"}) for index in range(10)]
    manual = STTMRecord(sttm_id="manual", project_id="project", metadata={"actor_user_id": "42"})
    known = STTMRecord(sttm_id="known", project_id="project", metadata={"bootstrap_origin": "project_template", "actor_user_id": "42", "created_by_name": "Original name"})
    another = STTMRecord(sttm_id="another", project_id="project", metadata={"bootstrap_origin": "project_template", "actor_user_id": "84"})
    before = [item.model_dump() for item in mappings]
    result = service._with_template_creator_names([*mappings, manual, known, another])
    assert len(calls) == 1
    assert calls[0][1] == ["42", "84"]
    assert "42" not in calls[0][0]
    assert [item.metadata["created_by_name"] for item in result[:10]] == ["Ankur Sharma"] * 10
    assert result[-3] is manual and "created_by_name" not in manual.metadata
    assert result[-2].metadata["created_by_name"] == "Original name"
    assert result[-1].metadata["created_by_name"] == "Another Creator"
    assert [item.model_dump() for item in mappings] == before


def test_unavailable_optional_creator_profile_does_not_break_mapping_loading():
    service = _service()
    service._settings = SimpleNamespace(qualified_users_table="DB.META.USERS")
    service._table_columns = lambda table: {"USER_ID", "DISPLAY_NAME"}
    def unavailable(*args, **kwargs):
        raise RuntimeError("Profile table unavailable")
    service._session = SimpleNamespace(sql=unavailable)
    mappings = [STTMRecord(sttm_id="template", project_id="project", metadata={"bootstrap_origin": "project_template", "actor_user_id": "42"})]
    assert service._with_template_creator_names(mappings) is mappings


def test_manual_mapping_creator_is_not_looked_up_or_relabelled():
    service = _service()
    def unexpected(*args, **kwargs):
        raise AssertionError("Manual mappings must not enter the template creator lookup")
    service._table_columns = unexpected
    service._session = SimpleNamespace(sql=unexpected)
    mappings = [STTMRecord(sttm_id="manual", project_id="project", metadata={"actor_user_id": "42"})]
    assert service._with_template_creator_names(mappings) is mappings
    assert mappings[0].metadata == {"actor_user_id": "42"}
