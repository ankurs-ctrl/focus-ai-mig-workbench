"use client";
import { sqlTableReference } from '@/features/sttm/shared/sql-identifiers';
import { resolveReviewSemanticContext } from '@/features/sttm/mapping/review-semantic-context';
import { APP_FONT_FAMILY } from '@/theme/fonts';
import { AiaAlert, AiaBox, AiaButton, AiaCircularProgress, AiaDialog, AiaDialogActions, AiaDialogContent, AiaDialogTitle, AiaIconButton, AiaCheckbox, AiaPaper, AiaStack, AiaTableBody, AiaTableCellPrimitive, AiaTableHead, AiaTablePrimitive, AiaTableRowPrimitive, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import {
  AccountTreeOutlinedIcon,
  ChecklistRtlRoundedIcon,
  CloseRoundedIcon,
  InfoOutlinedIcon,
  TableRowsRoundedIcon,
  TerminalRoundedIcon,
} from '@/utils/icons';

import { AiaResizeHandle } from '@/components/ui/aia-resize-handle';
import { useSidebarSlot } from '@/features/sttm/layout/sidebar-slot-context';
import { SttmSidebarCollapseFooter } from '@/features/sttm/layout/sttm-sidebar-collapse-footer';
import SourceTargetAttributeList from '@/features/sttm/mapping/source-target-attribute-list';
import SourceTargetAttributeMapping from '@/features/sttm/mapping/source-target-attribute-mapping';
import PreProcessModal from '@/features/sttm/mapping/pre-process-modal';
import { SttmLineageWorkspacePanel } from '@/features/sttm/lineage/sttm-lineage-workspace-panel';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { joinConnectorPayload } from '@/features/sttm/source-target/join-predicate';
import { useProjectAttributes } from '@/features/sttm/mapping/use-project-attributes';
import { buildRelationDisplayAliases, formatRelationDisplayText, splitSourceDisplayLabel } from '@/features/sttm/mapping/relation-alias';
import { useAppDispatch } from '@/store/hooks';
import { fetchAttributes, setSqlValidatedSignature } from '@/features/sttm/store/sttm-builder-slice';
import { OPEN_MAPPING_TAB_STORAGE_KEY } from '@/features/sttm/shared/mapping-validation';
import { useMappingValidationStatus } from '@/features/sttm/shared/use-mapping-validation-status';
import { SttmNoticeDialog } from '@/features/sttm/shared/sttm-notice-dialog';
import { collectSelectedSourceQualifiedNames } from '@/features/sttm/shared/sttm-selection-utils';
import {
  buildFallbackSourceQuerySql,
  buildCompilerRelationGraph,
  buildMappingInsertSql,
  buildMappingSelectSql,
  buildCteDraft,
  canonicalizeMappingBindings,
  buildSourceQueryPreviewSql,
  generateMappingDescription,
  parseSourceColumns,
  semanticGrainForTable,
} from '@/features/sttm/mapping/mapping-utils';
import { dbService } from '@/services/dbService';
import { MappingSqlPreview } from '@/components/sql';
import { formatSqlForDisplay } from '@/components/sql/format-sql';
import { MappingProgressIndicator } from '@/features/sttm/shared/mapping-progress-indicator';
import { BuilderWorkspaceTabBar } from '@/features/sttm/shared/builder-workspace-tab-bar';
import { CARD_TITLE_SX, BODY_SX } from '@/config/typography-tokens';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { useTour } from '@/features/tour/engine/tour-context';
import type {
  MappingSqlPreviewResponse,
  MappingSqlCompileResponse,
  MappingSqlParseResponse,
  MappingSqlReviewRequest,
  MappingSqlReviewResponse,
  TableRef,
} from '@/types/api-contract';
import type { JoinConfig, MappingState } from '@/features/sttm/types/sttm.types';
import type { SqlUploadResult } from '@/features/sttm/mapping/sql-bundle-review-panel';
import { buildSqlUploadWorkspace } from '@/features/sttm/mapping/sql-upload-workspace';
import { workspaceDerivedSources } from '@/features/sttm/shared/derived-source-closure';
import {
  buildMappingCompilerContextHash,
  selectMappingSqlArtifact,
} from '@/features/sttm/mapping/mapping-sql-artifact';

type MappingTab = 'mapping' | 'sql-preview' | 'data-preview' | 'data-lineage';

const MIN_SIDEBAR_WIDTH = 248;
// Dragging can widen the sidebar up to half of the window.
const MAX_SIDEBAR_VIEWPORT_RATIO = 0.5;
const COLLAPSED_SIDEBAR_WIDTH = 70;

type PreviewDisplayRow = {
  mappingId: string;
  targetColumn: string;
  targetType: string;
  sourceColumn: string;
  sourceColumnDisplay: string;
  sourceRelationDisplay: string;
  sourceValue: string;
  transformedValue: string;
  description: string;
  expressionLabel: string | null;
  confidenceScore: number | null;
  confidenceReason: string | null;
  candidateSourceColumns: string[];
  rowCount: number;
  rowIndex: number;
  displayIndex: number;
};

type SqlUnifiedDiffLine = {
  text: string;
  kind: 'context' | 'removed' | 'added' | 'separator';
};

function countFilterConditions(
  groups: Array<{ type?: string; children?: unknown[] }>,
): number {
  return groups.reduce((count, group) => {
    if (group.type === 'condition') {
      return count + 1;
    }
    const children = Array.isArray(group.children)
      ? (group.children as Array<{ type?: string; children?: unknown[] }>)
      : [];
    return count + countFilterConditions(children);
  }, 0);
}

function qualifiedNameToTableRef(qualifiedName: string): TableRef | null {
  return sqlTableReference(qualifiedName);
}

function buildEditedInsertSql(
  previewSql: string,
  targetQualifiedName: string | null,
  mappings: MappingState[],
): string {
  const targetColumns = mappings
    .filter((mapping) => mapping.status === 'MAPPED')
    .map((mapping) => `  ${mapping.targetColumn}`);
  if (!targetQualifiedName || !targetColumns.length) return previewSql;
  return [
    `INSERT INTO ${targetQualifiedName} (`,
    targetColumns.join(',\n'),
    ')',
    previewSql.trim().replace(/;\s*$/, ''),
    ';',
  ].join('\n');
}

function stringifyPreviewValue(value: unknown): string {
  if (value === null) return 'NULL';
  if (value === undefined) return 'Not sampled';
  if (value === '') return '(empty)';
  if (typeof value === 'object') {
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }
  return String(value);
}

function confidenceTone(confidenceScore: number | null | undefined) {
  if (confidenceScore === null || confidenceScore === undefined) {
    return { color: '#64748b', backgroundColor: '#f8fafc', borderColor: '#e2e8f0' };
  }
  if (confidenceScore >= 0.8) {
    return { color: '#166534', backgroundColor: '#dcfce7', borderColor: '#86efac' };
  }
  if (confidenceScore >= 0.55) {
    return { color: '#92400e', backgroundColor: '#fef3c7', borderColor: '#fcd34d' };
  }
  return { color: '#b91c1c', backgroundColor: '#fee2e2', borderColor: '#fca5a5' };
}

function buildUnifiedSqlDiffLines(originalSql: string, optimizedSql: string): SqlUnifiedDiffLine[] {
  const originalLines = formatSqlForDisplay(originalSql).split('\n');
  const optimizedLines = formatSqlForDisplay(optimizedSql).split('\n');
  const dp: number[][] = Array.from({ length: originalLines.length + 1 }, () =>
    Array.from({ length: optimizedLines.length + 1 }, () => 0),
  );

  for (let i = originalLines.length - 1; i >= 0; i -= 1) {
    for (let j = optimizedLines.length - 1; j >= 0; j -= 1) {
      dp[i][j] =
        originalLines[i] === optimizedLines[j]
          ? dp[i + 1][j + 1] + 1
          : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }

  const rows: SqlUnifiedDiffLine[] = [];
  let i = 0;
  let j = 0;

  while (i < originalLines.length && j < optimizedLines.length) {
    if (originalLines[i] === optimizedLines[j]) {
      rows.push({ text: originalLines[i], kind: 'context' });
      i += 1;
      j += 1;
      continue;
    }

    if (dp[i + 1][j] >= dp[i][j + 1]) {
      rows.push({ text: originalLines[i], kind: 'removed' });
      i += 1;
      continue;
    }

    rows.push({ text: optimizedLines[j], kind: 'added' });
    j += 1;
  }

  while (i < originalLines.length) {
    rows.push({ text: originalLines[i], kind: 'removed' });
    i += 1;
  }

  while (j < optimizedLines.length) {
    rows.push({ text: optimizedLines[j], kind: 'added' });
    j += 1;
  }

  const contextRadius = 3;
  const visibleContextIndexes = new Set<number>();

  rows.forEach((row, index) => {
    if (row.kind === 'context') {
      return;
    }
    for (
      let visibleIndex = Math.max(0, index - contextRadius);
      visibleIndex <= Math.min(rows.length - 1, index + contextRadius);
      visibleIndex += 1
    ) {
      visibleContextIndexes.add(visibleIndex);
    }
  });

  const compacted: SqlUnifiedDiffLine[] = [];
  let hiddenContextRun = false;

  rows.forEach((row, index) => {
    if (row.kind === 'context' && !visibleContextIndexes.has(index)) {
      if (!hiddenContextRun) {
        compacted.push({ text: '...', kind: 'separator' });
        hiddenContextRun = true;
      }
      return;
    }
    hiddenContextRun = false;
    compacted.push(row);
  });

  const changedLineCount = compacted.filter(
    (row) => row.kind === 'added' || row.kind === 'removed',
  ).length;
  if (changedLineCount === 0) {
    return rows.slice(0, 120);
  }

  return compacted;
}

function getReviewAgentLabel(reviewAgent: string | null | undefined): string {
  return reviewAgent === 'CORTEX_ANALYST' ? 'Cortex Analyst' : 'Snowflake validation repair';
}

export default function MappingPage() {
  return <MappingPageContent />;
}

function MappingPageContent() {
  const router = useRouter();
  const { setContent, collapsed, setCollapsed, width, setWidth } = useSidebarSlot();
  const resizeStateRef = useRef<{ startX: number; startWidth: number } | null>(null);
  const dispatch = useAppDispatch();
  const lastValidatedReviewContextRef = useRef<string | null>(null);
  const [activeTab, setActiveTab] = useState<MappingTab>('mapping');
  const { notifyTourContextChanged } = useTour();

  useEffect(() => {
    notifyTourContextChanged();
  }, [activeTab, notifyTourContextChanged]);

  // "Go to SQL tab" from the publish guard on the summary step.
  useEffect(() => {
    try {
      const requestedTab = window.sessionStorage.getItem(OPEN_MAPPING_TAB_STORAGE_KEY);
      if (requestedTab) {
        window.sessionStorage.removeItem(OPEN_MAPPING_TAB_STORAGE_KEY);
        if (requestedTab === 'sql-preview') setActiveTab('sql-preview');
      }
    } catch {
      // Storage unavailable: stay on the default tab.
    }
  }, []);

  const {
    signature: mappingValidationSignature,
    isValidated: isMappingSqlValidated,
  } = useMappingValidationStatus();
  // Set after a successful Compile & Validate; the effect below records the workspace
  // signature once the resulting state (e.g. synced SQL edits) has rendered.
  const [validationSucceeded, setValidationSucceeded] = useState(false);
  // Latest compile/validation error messages, readable right after an awaited call
  // (the matching state values only update on the next render).
  const compilerErrorRef = useRef<string | null>(null);
  const reviewErrorRef = useRef<string | null>(null);
  const [sqlFailureNotice, setSqlFailureNotice] = useState<{ title: string; message: string } | null>(null);

  useEffect(() => {
    if (!validationSucceeded) return;
    setValidationSucceeded(false);
    dispatch(setSqlValidatedSignature(mappingValidationSignature));
  }, [dispatch, mappingValidationSignature, validationSucceeded]);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewStage, setReviewStage] = useState<string | null>(null);
  const [reviewResult, setReviewResult] = useState<MappingSqlReviewResponse | null>(null);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [reviewBannerDismissed, setReviewBannerDismissed] = useState(false);
  const [approvedVariant, setApprovedVariant] = useState<'original' | 'optimized'>('original');
  const [reviewSelectionVariant, setReviewSelectionVariant] = useState<'original' | 'optimized' | null>(null);
  const [approvedPreviewSql, setApprovedPreviewSql] = useState<string | null>(null);
  const [validatedPreviewData, setValidatedPreviewData] = useState<MappingSqlPreviewResponse | null>(null);
  const [editableSql, setEditableSql] = useState('');
  const [sqlParseLoading, setSqlParseLoading] = useState(false);
  // Compile settled mapping changes from both Auto-map and saved manual edits.
  const [isCompilingSql, setIsCompilingSql] = useState(false);
  const [autoCompile, setAutoCompile] = useState(false);
  const autoCompileEpoch = useRef(0);
  const [authoredSqlContextHash, setAuthoredSqlContextHash] = useState<string | null>(null);
  const previousMappingSqlRef = useRef('');
  const [sqlParseResult, setSqlParseResult] = useState<MappingSqlParseResponse | null>(null);
  const [sqlParseDialogOpen, setSqlParseDialogOpen] = useState(false);
  const [selectedPreviewRowIndex, setSelectedPreviewRowIndex] = useState(0);
  const {
    mappings,
    pendingManualEditSnapshots,
    mappingLoading,
    targetAttributeGroup,
    ensureTargetMappings,
    fullData,
    sources,
    targets,
    loadState,
    errorState,
    relationships,
    derivedSources,
    drivingTableId,
    sourceAttributeGroups,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    sourceQueryModifiers,
    semanticBundleId,
    semanticBundleLabel,
    semanticViewName,
    semanticContextItems,
    mappingSql,
    authoredSqlIsCurrent,
    mappingPreviewSql,
    compiledMappingSql,
    compiledMappingScriptSql,
    compiledMappingReady,
    compiledMappingPreviewSql,
    compiledMappingContextHash,
    openSttmStatus,
    sessionHydrated,
    session,
    activeProjectId,
    activeSttmId,
    workspacePersistenceStatus,
    workspacePersistenceError,
    pendingSourceReconciliation,
    acknowledgeSourceReconciliation,
    refreshAssistantSignals,
    setMappingPreviewSql,
    setMappingSql,
    setMappingSqlVariant,
    setCompiledMappingResult,
    applyParsedSqlWorkspace,
  } = useSttmBuilderContext();
  const { projectAttributes, isLoadingProjectAttributes, projectAttributesError, reloadProjectAttributes } = useProjectAttributes(activeProjectId);
  const uploadHydratedRef = useRef(false);

  useEffect(() => {
    if (uploadHydratedRef.current || loadState.initial !== 'success') return;
    const raw = sessionStorage.getItem('upload_parsed_data');
    if (!raw) return;
    let uploaded: SqlUploadResult;
    try {
      uploaded = JSON.parse(raw) as SqlUploadResult;
    } catch {
      sessionStorage.removeItem('upload_parsed_data');
      return;
    }
    applyParsedSqlWorkspace(buildSqlUploadWorkspace(uploaded));
    uploadHydratedRef.current = true;
    sessionStorage.removeItem('upload_parsed_data');
    refreshAssistantSignals('sql.upload.applied');
  }, [applyParsedSqlWorkspace, loadState.initial, refreshAssistantSignals]);

  const hasSelectedSources = useMemo(
    () => sources.some((table) => table.isSelected),
    [sources],
  );
  const hasSelectedDerivedSources = useMemo(
    () => derivedSources.some((source) => source.isSelected),
    [derivedSources],
  );
  const hasSelectedInputs = hasSelectedSources || hasSelectedDerivedSources;

  const hasSelectedTarget = useMemo(
    () => targets.some((table) => table.isSelected),
    [targets],
  );

  const hasTargetColumns = useMemo(
    () => (targetAttributeGroup?.columns?.filter((col) => col.name).length ?? 0) > 0,
    [targetAttributeGroup],
  );
  const selectedTargetQualifiedNameForHydration =
    targets.find((table) => table.isSelected)?.qualifiedName ?? null;
  const selectedTargetMetadataLoaded = Boolean(
    selectedTargetQualifiedNameForHydration
    && targetAttributeGroup?.qualifiedName === selectedTargetQualifiedNameForHydration
    && hasTargetColumns,
  );
  const isSavedWorkspace = Boolean(activeProjectId && activeSttmId);

  const savedWorkspaceHydrating =
    !sessionHydrated ||
    openSttmStatus === 'loading' ||
    (isSavedWorkspace &&
      openSttmStatus === 'success' &&
      !selectedTargetMetadataLoaded &&
      loadState.attributes !== 'error' &&
      !errorState.attributes);

  const totalCount = mappings.length;
  const mappedCount = mappings.filter((m) => m.status === 'MAPPED').length;
  const selectedInputCount = useMemo(
    () =>
      sources.filter((table) => table.isSelected).length +
      derivedSources.filter((source) => source.isSelected).length,
    [derivedSources, sources],
  );
  const filterCount = useMemo(
    () => countFilterConditions(sourceFilterGroups as Array<{ type?: string; children?: unknown[] }>),
    [sourceFilterGroups],
  );

  useEffect(() => {
    setContent(null);
    return () => setContent(null);
  }, [setContent]);

  useEffect(() => {
    const handlePointerMove = (event: MouseEvent) => {
      const state = resizeStateRef.current;
      if (!state) {
        return;
      }
      const maxWidth = Math.max(MIN_SIDEBAR_WIDTH, Math.floor(window.innerWidth * MAX_SIDEBAR_VIEWPORT_RATIO));
      const nextWidth = Math.min(
        maxWidth,
        Math.max(MIN_SIDEBAR_WIDTH, state.startWidth + event.clientX - state.startX),
      );
      setWidth(nextWidth);
    };

    const handlePointerUp = () => {
      resizeStateRef.current = null;
    };

    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
    };
  }, [setWidth]);

  const beginResize = (event: React.MouseEvent<HTMLDivElement>) => {
    resizeStateRef.current = {
      startX: event.clientX,
      startWidth: width,
    };
  };

  useEffect(() => {
    if (savedWorkspaceHydrating) {
      return;
    }
    if (!hasSelectedInputs || !hasSelectedTarget) {
      router.replace('/sttm/builder/new');
      return;
    }

    if (loadState.attributes === 'loading' || loadState.attributes === 'idle') {
      return;
    }

    // A saved mapping already has durable mapping rows. Do not send it back to
    // Selection simply because source metadata completed before target metadata.
    // The selected-target hydration effect will populate the target group.
    if (!hasTargetColumns && !isSavedWorkspace) {
      router.replace('/sttm/builder/new');
    }
  }, [
    hasSelectedInputs,
    hasSelectedTarget,
    hasTargetColumns,
    isSavedWorkspace,
    loadState.attributes,
    router,
    savedWorkspaceHydrating,
  ]);

  const targetTableKey = targetAttributeGroup?.qualifiedName ?? '';
  const targetColumnsSignature = useMemo(
    () =>
      (targetAttributeGroup?.columns ?? [])
        .filter((col) => col.name)
        .map((col) => `${col.name}:${col.type ?? ''}`)
        .join('|'),
    [targetAttributeGroup],
  );

  useEffect(() => {
    if (
      savedWorkspaceHydrating ||
      !targetAttributeGroup ||
      !targetColumnsSignature
    ) {
      return;
    }

    const initialMappings = targetAttributeGroup.columns
      .filter((col) => col.name)
      .map((col, idx) => {
        const targetColumn = col.name as string;
        return {
          id: `${targetTableKey}-${idx}`,
          targetColumn,
          targetType: col.type || 'VARCHAR',
          sourceColumn: null,
          sourceType: null,
          expression: null,
          rule: 'Select...' as const,
          status: 'UNMAPPED' as const,
          nlRule: null,
          loadOrder: null,
          description: null,
          confidenceScore: null,
          confidenceReason: null,
          candidateSourceColumns: [],
          unmatchedReason: null,
          aiSuggestedRule: null,
          aiSuggestedRuleType: null,
        };
      });
    ensureTargetMappings(initialMappings);
  }, [
    targetAttributeGroup,
    targetTableKey,
    targetColumnsSignature,
    ensureTargetMappings,
    savedWorkspaceHydrating,
  ]);

  const selectedSourceKey = useMemo(
    () =>
      Array.from(new Set([
        ...collectSelectedSourceQualifiedNames(fullData?.sources ?? []),
        ...sources.filter((table) => table.isSelected).map((table) => table.qualifiedName),
      ]))
        .sort()
        .join('|'),
    [fullData?.sources, sources],
  );

  const selectedTargetKey =
    targets.find((table) => table.isSelected)?.qualifiedName ?? '';

  useEffect(() => {
    if (openSttmStatus === 'loading') return;
    if (selectedSourceKey) {
      dispatch(
        fetchAttributes({
          qualifiedNames: selectedSourceKey.split('|'),
          side: 'source',
        }),
      );
    }
    if (selectedTargetKey) {
      dispatch(
        fetchAttributes({
          qualifiedNames: [selectedTargetKey],
          side: 'target',
        }),
      );
    }
  }, [dispatch, openSttmStatus, selectedSourceKey, selectedTargetKey]);

  const selectedTargetQualifiedName =
    targets.find((table) => table.isSelected)?.qualifiedName ??
    targetAttributeGroup?.qualifiedName ??
    null;

  const selectedSourceTables = useMemo(
    () =>
      sources
        .filter((table) => table.isSelected)
        .map((table) => {
          const ref = qualifiedNameToTableRef(table.qualifiedName);
          return ref && table.tableId.startsWith('sql-instance:') ? {...ref, relation_id: table.tableId} : ref;
        })
        .filter((table): table is TableRef => Boolean(table)),
    [sources],
  );
  const selectedDerivedSourceRecords = useMemo(
    () => derivedSources.filter((source) => source.isSelected),
    [derivedSources],
  );

  const selectedTargetTableRef = useMemo(
    () =>
      selectedTargetQualifiedName
        ? qualifiedNameToTableRef(selectedTargetQualifiedName)
        : null,
    [selectedTargetQualifiedName],
  );

  const drivingTableRef = useMemo(
    () => (drivingTableId ? qualifiedNameToTableRef(drivingTableId) : null),
    [drivingTableId],
  );

  const selectedColumnsByTable = useMemo(
    () =>
      Object.fromEntries(
        sourceAttributeGroups
          .map((group) => [
            group.qualifiedName,
            group.columns.map((column) => String(column.name)).filter(Boolean),
          ])
          .filter(([, columns]) => columns.length > 0),
      ),
    [sourceAttributeGroups],
  );

  const sqlCompletionCandidates = useMemo(
    () => [...new Set([
      ...sourceAttributeGroups.flatMap((group) =>
        group.columns.flatMap((column) => {
          const name = String(column.name ?? '').trim();
          if (!name) return [];
          const tableName = group.qualifiedName.split('.').pop();
          return tableName ? [name, `${tableName}.${name}`] : [name];
        })),
      ...(targetAttributeGroup?.columns ?? []).map((column) => String(column.name ?? '').trim()),
    ].filter(Boolean))],
    [sourceAttributeGroups, targetAttributeGroup],
  );

  const relationshipPayload = useMemo(
    () =>
      relationships
        .filter((join) => join.leftTableId && join.rightTableId && (join.conditions?.length || join.sqlPredicate))
        .map((join) => {
          const leftTable = qualifiedNameToTableRef(String(join.leftTableId));
          const rightTable = qualifiedNameToTableRef(String(join.rightTableId));
          return leftTable && rightTable
            ? {
                left_table: leftTable,
                right_table: rightTable,
                join_type: join.joinType ?? 'INNER',
                constraint_name: join.constraintName ?? null,
                source: join.source ?? 'USER_DEFINED',
                locked: join.locked ?? false,
                sql_predicate: join.sqlPredicate || null,
                conditions: join.sqlPredicate ? [] : (join.conditions ?? [])
                  .filter((condition) => condition.leftColumn && condition.rightColumn)
                  .map((condition) => ({
                    left_column: String(condition.leftColumn),
                    right_column: String(condition.rightColumn),
                    operator: condition.operator ?? '=',
                    ...joinConnectorPayload(condition.connector),
                  })),
              }
            : null;
        })
        .filter((join): join is NonNullable<typeof join> => Boolean(join)),
    [relationships],
  );

  const resolvedSourceQuerySql = useMemo(
    () =>
      buildFallbackSourceQuerySql({
        sourceQuerySql,
        sourceTables: selectedSourceTables,
        derivedSources: selectedDerivedSourceRecords,
        relationships: relationshipPayload,
        drivingTable: drivingTableRef,
      }),
    [
      drivingTableRef,
      relationshipPayload,
      selectedDerivedSourceRecords,
      selectedSourceTables,
      sourceQuerySql,
    ],
  );

  const generatedInsertSql = useMemo(
    () =>
      buildMappingInsertSql({
        mappings,
        targetQualifiedName: selectedTargetQualifiedName,
        sourceQuerySql: resolvedSourceQuerySql,
        sourceTables: selectedSourceTables,
        derivedSources: selectedDerivedSourceRecords,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
        projectAttributes,
      }),
    [
      projectAttributes,
      selectedDerivedSourceRecords,
      selectedSourceTables,
      mappings,
      resolvedSourceQuerySql,
      selectedTargetQualifiedName,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
    ],
  );

  const previewSql = useMemo(
    () =>
      buildMappingSelectSql({
        mappings,
        sourceQuerySql: resolvedSourceQuerySql,
        sourceTables: selectedSourceTables,
        derivedSources: selectedDerivedSourceRecords,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
        projectAttributes,
      }),
    [
      projectAttributes,
      selectedDerivedSourceRecords,
      selectedSourceTables,
      mappings,
      resolvedSourceQuerySql,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
    ],
  );

  const compilerRelationGraph = useMemo(
    () => buildCompilerRelationGraph({
      semanticContext: semanticContextItems,
      sourceTables: selectedSourceTables,
      sourceColumnsByTable: Object.fromEntries(
        sourceAttributeGroups.map((group) => [group.qualifiedName, group.columns]),
      ),
      derivedSources: selectedDerivedSourceRecords,
      relationships,
      mappings,
      queryModifiers: sourceQueryModifiers,
    }),
    [semanticContextItems, mappings, relationships, selectedDerivedSourceRecords, selectedSourceTables, sourceAttributeGroups, sourceQueryModifiers],
  );
  const [compilerError, setCompilerError] = useState<string | null>(null);
  const [compilerBindingNotes, setCompilerBindingNotes] = useState<string[]>([]);
  const compilerContextHash = useMemo(
    () => buildMappingCompilerContextHash({
      projectId: activeProjectId,
      firmValues: projectAttributes,
      semanticContext: semanticContextItems,
      relationGraph: compilerRelationGraph,
      mappings,
      targetTable: selectedTargetTableRef,
      drivingTableId,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
    }),
    [
      compilerRelationGraph,
      activeProjectId,
      projectAttributes,
      drivingTableId,
      semanticContextItems,
      mappings,
      selectedTargetTableRef,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
    ],
  );

  useEffect(() => {
    if (mappingSql !== previousMappingSqlRef.current) {
      previousMappingSqlRef.current = mappingSql;
      setAuthoredSqlContextHash(mappingSql.trim() ? compilerContextHash : null);
    }
  }, [compilerContextHash, mappingSql]);

  const latestCompileContext = useRef(compilerContextHash);
  useLayoutEffect(() => { latestCompileContext.current = compilerContextHash; }, [compilerContextHash]);
  const compileSequence = useRef(0);
  const compileCurrentMappingSql = useCallback(async (automatic = false): Promise<MappingSqlCompileResponse | null> => {
    const epoch = autoCompileEpoch.current;
    const sequence = ++compileSequence.current;
    const activeMappings = mappings.filter((mapping) => mapping.status === 'MAPPED');
    if (!activeMappings.length || !compilerRelationGraph.nodes.length) {
      compilerErrorRef.current = 'Map at least one target attribute before compiling SQL.';
      setCompilerError(compilerErrorRef.current);
      return null;
    }
    setIsCompilingSql(true);
    compilerErrorRef.current = null;
    setCompilerError(null);
    try {
      const response = await dbService.compileMappingSql({
        relation_graph: compilerRelationGraph,
        target_grain: semanticGrainForTable(semanticContextItems, selectedTargetTableRef),
        mappings: activeMappings.map(mapping => canonicalizeMappingBindings(mapping, compilerRelationGraph)).map((mapping) => ({
          target_column: mapping.targetColumn,
          target_sql_name: mapping.targetSqlName,
          target_type: mapping.targetType,
          source_column: mapping.sourceColumn,
          source_columns: mapping.sourceColumns ?? parseSourceColumns(mapping.sourceColumn),
          mapping_mode: mapping.mappingMode ?? 'source',
          constant_value: mapping.constantValue ?? null,
          attribute_name: mapping.attributeName ?? null,
          expression: mapping.expression,
          rule: mapping.rule,
          status: mapping.status,
          nl_rule: mapping.nlRule,
          description: mapping.description,
          source_dependencies: mapping.sourceDependencies ?? mapping.sourceColumns ?? parseSourceColumns(mapping.sourceColumn),
          // Match the row-owned binding created by buildCompilerRelationGraph,
          // including reopened rows with legacy/model-generated binding IDs.
          value_binding_ids: mapping.mappingMode === 'constant' || mapping.mappingMode === 'attribute'
            ? [`value:${mapping.id}`]
            : [],
          precedent_decision: mapping.precedentDecision,
          precedent_mapping_id: mapping.precedentMappingId,
        })),
        target_table: selectedTargetTableRef,
        // The SQL's outer FROM relation drives the compiled query. It may be
        // an imported CTE whose physical inputs stay selected for lineage.
        driving_relation_id: compilerRelationGraph.nodes.some((node) =>
          node.relation_id === drivingTableId) ? drivingTableId : null,
        where_predicates: sourceFilterSql?.trim() ? [sourceFilterSql.trim()] : [],
        group_by_expressions: sourceGroupBySql?.trim() ? [sourceGroupBySql.trim()] : [],
        order_by_expressions: sourceOrderBySql?.trim() ? [sourceOrderBySql.trim()] : [],
        self_contained_derived: true,
        validate_with_explain: false,
        allow_unresolved_placeholders: true,
        accepted_precedent_sttm_id: null,
        input_hash: compilerContextHash,
        // The backend resolves this project's firm values into $placeholders.
        project_id: activeProjectId ?? null,
      });
      if (latestCompileContext.current !== compilerContextHash || sequence !== compileSequence.current
          || (automatic && epoch !== autoCompileEpoch.current)) return null;
      setCompilerBindingNotes(response.warnings.filter(note => note.includes('authored rule unchanged')));
      setCompiledMappingResult({
        generatedSql: response.generated_sql,
        previewSql: response.preview_sql,
        scriptSql: response.script_sql,
        ready: response.ready,
        contextHash: response.input_hash ?? compilerContextHash,
      });
      if (!response.ready) {
        compilerErrorRef.current = response.warnings.join(' ') || 'Resolve the remaining mapping values before previewing.';
        setCompilerError(compilerErrorRef.current);
      }
      return response;
    } catch (error) {
      if (latestCompileContext.current !== compilerContextHash || sequence !== compileSequence.current
          || (automatic && epoch !== autoCompileEpoch.current)) return null;
      compilerErrorRef.current = error instanceof Error ? error.message : 'The relation graph could not be compiled.';
      setCompilerError(compilerErrorRef.current);
      return null;
    } finally {
      if (sequence === compileSequence.current) setIsCompilingSql(false);
    }
  }, [
    activeProjectId,
    compilerRelationGraph,
    compilerContextHash,
    semanticContextItems,
    drivingTableId,
    mappings,
    selectedTargetTableRef,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    setCompiledMappingResult,
  ]);

  useEffect(() => {
    // Editing the graph invalidates compiler errors from the previous graph,
    // but does not launch another compile or block the mapping UI.
    setCompilerError(null);
    setCompilerBindingNotes([]);
  }, [compilerContextHash]);

  const sourceQueryPreviewSql = useMemo(
    () =>
      buildSourceQueryPreviewSql({
        sourceQuerySql: resolvedSourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [resolvedSourceQuerySql, sourceFilterSql, sourceGroupBySql, sourceOrderBySql],
  );

  // Keep imported/edited SQL until the mapping graph changes. Once rows,
  // relationships, filters, or the target change, the compiler result becomes
  // canonical so the mapping and SQL tabs stay synchronized.
  const currentSqlArtifact = useMemo(
    () => selectMappingSqlArtifact({
      authoredSql: mappingSql,
      authoredPreviewSql: mappingPreviewSql,
      authoredContextHash: authoredSqlContextHash,
      authoredIsCurrent: authoredSqlIsCurrent,
      compiledSql: compiledMappingSql,
      compiledScriptSql: compiledMappingScriptSql,
      compiledReady: compiledMappingReady,
      compiledPreviewSql: compiledMappingPreviewSql,
      compiledContextHash: compiledMappingContextHash,
      currentContextHash: compilerContextHash,
      fallbackSql: generatedInsertSql,
      fallbackPreviewSql: previewSql,
      allowFallback: false,
    }),
    [authoredSqlContextHash, authoredSqlIsCurrent, compiledMappingContextHash, compiledMappingPreviewSql, compiledMappingSql, compiledMappingScriptSql, compiledMappingReady, compilerContextHash, generatedInsertSql, mappingPreviewSql, mappingSql, previewSql],
  );
  const canonicalOrGeneratedPreviewSql = currentSqlArtifact.previewSql;
  const canonicalOrGeneratedExecutionSql = currentSqlArtifact.generatedSql;
  // Display only: never pass this draft into artifacts, persistence or execution.
  // Complex graphs require the backend's scope-aware compiler.
  const provisionalSupported = compilerRelationGraph.nodes.length === 1
    && Boolean(compilerRelationGraph.nodes[0].table)
    && !selectedDerivedSourceRecords.length && !sourceQuerySql?.trim()
    && !compilerRelationGraph.edges.length && !Object.keys(compilerRelationGraph.query_modifiers ?? {}).length;
  const cteDraft = useMemo(() => buildCteDraft({graph: compilerRelationGraph,
    drivingId: drivingTableId, mappings, filterSql: sourceFilterSql,
    groupBySql: sourceGroupBySql, orderBySql: sourceOrderBySql}),
    [compilerRelationGraph, drivingTableId, mappings, sourceFilterSql, sourceGroupBySql, sourceOrderBySql]);
  const provisionalSql = !mappedCount ? '-- Map a target column to see SQL here.'
    : isLoadingProjectAttributes || savedWorkspaceHydrating ? '-- Loading source context and project values...'
    : provisionalSupported ? `-- Draft SQL - not compiled or validated.\n${previewSql}`
    : cteDraft?.sql ?? '-- This source graph requires compilation. Select Compile & Validate to prepare its SQL.';

  // Preference is not mapping content and never dirties autosave or learning.
  const autoCompilePreferenceKey = session?.user_id ? `sttm:auto-compile:${session.user_id}` : null;
  useEffect(() => {
    try { setAutoCompile(Boolean(autoCompilePreferenceKey && localStorage.getItem(autoCompilePreferenceKey) === 'true')); }
    catch { setAutoCompile(false); }
  }, [autoCompilePreferenceKey]);
  const changeAutoCompile = (enabled: boolean) => {
    autoCompileEpoch.current += 1;
    lastAutomaticCompileHash.current = null;
    setAutoCompile(enabled);
    try { if (autoCompilePreferenceKey) localStorage.setItem(autoCompilePreferenceKey, String(enabled)); } catch { /* Storage may be unavailable. */ }
  };

  const lastAutomaticCompileHash = useRef<string | null>(null);
  useEffect(() => {
    if (!autoCompile || mappingLoading || savedWorkspaceHydrating || isLoadingProjectAttributes
        || Object.keys(pendingManualEditSnapshots).length || currentSqlArtifact.source !== 'generated'
        || isCompilingSql || reviewLoading
        || !mappedCount || lastAutomaticCompileHash.current === compilerContextHash) return;
    // Final batch updates and project-value refreshes can supersede a compile.
    // Retry the settled input, not just the first loading -> idle transition.
    const timer = window.setTimeout(() => {
      lastAutomaticCompileHash.current = compilerContextHash;
      void compileCurrentMappingSql(true);
    }, 650);
    return () => window.clearTimeout(timer);
  }, [autoCompile, compileCurrentMappingSql, compilerContextHash, currentSqlArtifact.source,
    isCompilingSql, isLoadingProjectAttributes, mappedCount, mappingLoading,
    pendingManualEditSnapshots, reviewLoading, savedWorkspaceHydrating]);

  useEffect(() => {
    if (!sqlParseDialogOpen) {
      setEditableSql(currentSqlArtifact.scriptSql);
    }
  }, [currentSqlArtifact.scriptSql, sqlParseDialogOpen]);

  const knownSqlTables = useMemo(() => {
    const refs = new Map<string, TableRef>();
    const collect = (
      databases: NonNullable<typeof fullData>['sources'],
    ) => {
      for (const database of databases ?? []) {
        for (const schema of database.schemas ?? []) {
          for (const table of schema.tables ?? []) {
            const ref = qualifiedNameToTableRef(table.qualifiedName);
            if (ref) refs.set(table.qualifiedName.toUpperCase(), ref);
          }
        }
      }
    };
    collect(fullData?.sources ?? []);
    collect(fullData?.targets ?? []);
    return Array.from(refs.values());
  }, [fullData]);

  const applyParsedSqlResult = useCallback((
    parseResult: MappingSqlParseResponse,
    commit = true,
    preserveReview = false,
  ) => {
    if (!parseResult.valid) return null;
    const workspace = parseResult.parsed_workspace;
    if (!workspace.parsed_document) throw new Error('The SQL parser did not return its scoped document. No workspace changes were applied.');
    const parsedWorkspace = buildSqlUploadWorkspace({
      asset_id: `mapping-${activeSttmId ?? 'new'}`,
      parsed_summary: { ...workspace.parsed_document, target_table: workspace.target_table },
      import_preview: {
        sql: String(workspace.sql ?? editableSql),
        table_references: (workspace.source_tables ?? []).map((fqn, index) => ({
          raw_identifier: workspace.parsed_document?.source_tables?.[index] ?? fqn,
          resolved_fqn: fqn, resolution_status: 'resolved', reference_role: 'source',
        })),
      },
    });
    const parsedMappings = parsedWorkspace.mappings.map((mapping, index) => {
      const serverRow = workspace.mapping_rows?.[index];
      const attribute = serverRow?.mapping_mode === 'attribute';
      return {
        ...mapping,
        targetType: targetAttributeGroup?.columns.find((column) => column.name === mapping.targetColumn)?.type ?? 'TEXT',
        ...(attribute ? { mappingMode: 'attribute' as const, attributeName: String(serverRow.attribute_name ?? ''),
          constantValue: String(serverRow.constant_value ?? ''), sourceColumn: null, sourceColumns: [],
          sourceDependencies: [], expression: null, nlRule: null, rule: 'Value' } : {}),
      };
    });
    parsedWorkspace.mappings = parsedMappings;
    const parsedRelationships = parsedWorkspace.relationships;
    if (commit) {
      applyParsedSqlWorkspace(parsedWorkspace);
      setSqlParseDialogOpen(false);
      setActiveTab('mapping');
      if (!preserveReview) {
        setReviewResult(null);
        setValidatedPreviewData(null);
      }
      refreshAssistantSignals('sql.applied');
    }
    return { parsedMappings, parsedRelationships };
  }, [
    applyParsedSqlWorkspace,
    activeSttmId,
    editableSql,
    refreshAssistantSignals,
    targetAttributeGroup,
  ]);

  const handleApplyParsedSql = useCallback(() => {
    if (sqlParseResult) applyParsedSqlResult(sqlParseResult);
  }, [applyParsedSqlResult, sqlParseResult]);

  const mappedMappings = useMemo(
    () =>
      mappings
        .filter((mapping) => mapping.status === 'MAPPED')
        .map((mapping) => ({
          target_column: mapping.targetColumn,
          target_sql_name: mapping.targetSqlName,
          target_type: mapping.targetType,
          source_column: mapping.sourceColumn,
          source_columns:
            mapping.sourceColumns && mapping.sourceColumns.length
              ? mapping.sourceColumns
              : parseSourceColumns(mapping.sourceColumn),
          mapping_mode: mapping.mappingMode ?? "source",
          constant_value: mapping.constantValue ?? null,
          attribute_name: mapping.attributeName ?? null,
          expression: mapping.expression,
          rule: mapping.rule,
          status: mapping.status,
          nl_rule: mapping.nlRule,
          description: mapping.description,
        })),
    [mappings],
  );

  const mappingSqlRequestPayload = useMemo(
    () => ({
      source_tables: selectedSourceTables,
      target_table: selectedTargetTableRef,
      driving_table: drivingTableRef,
      selected_derived_sources: derivedSources
        .filter((source) => source.isSelected)
        .map((source) => source.id),
      relationships: relationshipPayload,
      selected_columns_by_table: selectedColumnsByTable,
      semantic_bundle_id: semanticBundleId,
      semantic_bundle_label: semanticBundleLabel,
      semantic_view_name: semanticViewName,
      relation_graph: compilerRelationGraph,
      source_query_sql: sourceQueryPreviewSql,
      preview_sql: canonicalOrGeneratedPreviewSql,
      generated_sql: canonicalOrGeneratedExecutionSql,
      mappings: mappedMappings,
      preview_limit: 5,
      project_id: activeProjectId ?? null,
    }),
    [
      activeProjectId,
      derivedSources,
      drivingTableRef,
      canonicalOrGeneratedExecutionSql,
      canonicalOrGeneratedPreviewSql,
      compilerRelationGraph,
      mappedMappings,
      relationshipPayload,
      selectedColumnsByTable,
      selectedSourceTables,
      selectedTargetTableRef,
      semanticBundleId,
      semanticBundleLabel,
      semanticViewName,
      sourceQueryPreviewSql,
    ],
  );

  const reviewContextSignature = useMemo(
    () =>
      JSON.stringify({
        target: selectedTargetQualifiedName,
        drivingTableId,
        selectedSourceTables: selectedSourceTables
          .map((table) => `${table.database}.${table.schema}.${table.table}`)
          .sort(),
        selectedDerivedSources: selectedDerivedSourceRecords.map((source) => source.id).sort(),
        relationshipSignature: relationshipPayload.map((join) => ({
          left: `${join.left_table.database}.${join.left_table.schema}.${join.left_table.table}`,
          right: `${join.right_table.database}.${join.right_table.schema}.${join.right_table.table}`,
          joinType: join.join_type,
          conditions: join.conditions,
        })),
        mappingSql: canonicalOrGeneratedPreviewSql,
      }),
    [
      drivingTableId,
      canonicalOrGeneratedPreviewSql,
      relationshipPayload,
      selectedDerivedSourceRecords,
      selectedSourceTables,
      selectedTargetQualifiedName,
    ],
  );
  const currentSqlHasValidationReceipt = Boolean(
    reviewResult?.execution_ready
    && (validationSucceeded || isMappingSqlValidated)
    && [reviewResult.original_preview_sql, reviewResult.optimized_preview_sql]
      .some((sql) => sql?.trim().replace(/;\s*$/, '')
        === canonicalOrGeneratedPreviewSql.trim().replace(/;\s*$/, '')),
  );

  useEffect(() => {
    if (reviewResult || validatedPreviewData || mappingPreviewSql.trim()) {
      return;
    }
    setApprovedVariant('original');
    setReviewSelectionVariant(null);
    setApprovedPreviewSql(null);
    setSelectedPreviewRowIndex(0);
        setPreviewError(null);
    setReviewBannerDismissed(false);
    setMappingPreviewSql(previewSql);
    setMappingSqlVariant('original');
  }, [
    generatedInsertSql,
    mappingPreviewSql,
    previewSql,
    reviewResult,
    setMappingPreviewSql,
    setMappingSqlVariant,
    validatedPreviewData,
  ]);

  useEffect(() => {
    if ((!reviewResult && !validatedPreviewData) || !lastValidatedReviewContextRef.current) {
      return;
    }
    if (currentSqlHasValidationReceipt) {
      lastValidatedReviewContextRef.current = reviewContextSignature;
      return;
    }
    if (reviewContextSignature === lastValidatedReviewContextRef.current) {
      return;
    }
    if (reviewDialogOpen || reviewLoading || previewLoading) {
      return;
    }
    lastValidatedReviewContextRef.current = reviewContextSignature;
    setApprovedVariant('original');
    setReviewSelectionVariant(null);
    setApprovedPreviewSql(null);
    setValidatedPreviewData(null);
    setSelectedPreviewRowIndex(0);
    setPreviewError(null);
    setReviewResult(null);
    setReviewStage(null);
    setReviewBannerDismissed(false);
    setMappingPreviewSql(previewSql);
    setMappingSqlVariant('original');
  }, [
    generatedInsertSql,
    currentSqlHasValidationReceipt,
    previewLoading,
    previewSql,
    reviewContextSignature,
    reviewDialogOpen,
    reviewLoading,
    reviewResult,
    setMappingPreviewSql,
    setMappingSqlVariant,
    validatedPreviewData,
  ]);

  useEffect(() => {
    const handleRunValidation = () => setActiveTab('sql-preview');
    window.addEventListener('sttm:run-validation', handleRunValidation);
    return () => window.removeEventListener('sttm:run-validation', handleRunValidation);
  }, []);

  const runValidatedPreview = async (
    variant: 'original' | 'optimized',
    review: MappingSqlReviewResponse,
  ) => {
    const requestContext = compilerContextHash;
    setPreviewLoading(true);
    setPreviewError(null);
    setReviewStage(
      variant === 'optimized'
        ? 'Running the Cortex Analyst-approved SQL preview in Snowflake...'
        : 'Running the approved SQL preview in Snowflake...'
    );
    const approvedPreview = variant === 'optimized'
      ? review.optimized_preview_sql ?? review.original_preview_sql
      : review.original_preview_sql;
    const approvedGenerated = variant === 'optimized'
      ? review.optimized_generated_sql ?? review.original_generated_sql
      : review.original_generated_sql;

    try {
      const result = await dbService.previewMappingSql({
        ...mappingSqlRequestPayload,
        chosen_variant: variant,
        approved_preview_sql: approvedPreview,
        approved_generated_sql: approvedGenerated,
      });
      if (latestCompileContext.current !== requestContext) return;
      setApprovedVariant(variant);
      setApprovedPreviewSql(approvedPreview);
      setMappingPreviewSql(result.executed_preview_sql || approvedPreview);
      setMappingSqlVariant(result.variant_used ?? variant);
      setValidatedPreviewData(result);
      setActiveTab('data-preview');
      setReviewStage(
        `${result.variant_used === 'optimized' ? 'Optimized' : 'Original'} SQL preview finished. ${result.preview_rows.length} sample row(s) were returned.`
      );
    } catch (error) {
      if (latestCompileContext.current !== requestContext) return;
      setPreviewError(
        error instanceof Error ? error.message : 'Unable to run validated SQL preview.',
      );
      setValidatedPreviewData(null);
      setActiveTab('data-preview');
      setReviewStage('Preview execution failed. Review the error details below.');
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleRunPreview = async () => {
    if (currentSqlArtifact.source === 'compiled' && !currentSqlArtifact.ready) {
      setPreviewError('Resolve the compiler checks before running a preview.');
      return;
    }
    if ((!reviewResult || !currentSqlHasValidationReceipt) && isMappingSqlValidated) {
      // Validated earlier (e.g. before a reload) but this session has no validation
      // result to run against, and Compile & Validate is disabled while unchanged.
      // Re-validate the same SQL, then run the preview in one step.
      const review = await handleCompileAndValidate();
      if (!review?.execution_ready) return;
      if (review.requires_approval) return; // the review dialog asks which SQL to run
      await runValidatedPreview('original', review);
      return;
    }
    if (!reviewResult || !currentSqlHasValidationReceipt) {
      setPreviewError('Validate the current SQL before running a preview.');
      setActiveTab('sql-preview');
      return;
    }
    const variant = reviewResult.requires_approval
      ? reviewSelectionVariant
      : (reviewSelectionVariant ?? 'original');
    if (!variant) {
      setReviewDialogOpen(true);
      return;
    }
    await runValidatedPreview(variant, reviewResult);
  };

  const handleValidateSql = async (
    requestOptimization = false,
    payloadOverride?: MappingSqlReviewRequest,
    validationSignature = reviewContextSignature,
  ): Promise<MappingSqlReviewResponse | null> => {
    const baseReviewPayload = payloadOverride ?? mappingSqlRequestPayload;
    const requestContext = compilerContextHash;
    if (!baseReviewPayload.mappings.length) {
      reviewErrorRef.current = 'Map at least one target attribute before validating SQL.';
      setReviewError(reviewErrorRef.current);
      setActiveTab('sql-preview');
      return null;
    }
    setReviewLoading(true);
    reviewErrorRef.current = null;
    setReviewError(null);
        setPreviewError(null);
    setValidatedPreviewData(null);
    setReviewResult(null);
    setReviewBannerDismissed(false);
    setApprovedVariant('original');
    setReviewStage(
      requestOptimization
        ? 'Preparing the semantic model for Cortex Analyst optimization...'
        : 'Checking the generated SQL with Snowflake validation...',
    );
    refreshAssistantSignals("before_validation");
    try {
      const semanticReview = await resolveReviewSemanticContext(baseReviewPayload, requestOptimization, async () => {
        const semanticRefresh = await dbService.refreshSemanticContext({
          project_id: activeProjectId,
          workspace_derived_sources: workspaceDerivedSources(derivedSources),
          selected_source_tables: baseReviewPayload.source_tables,
          selected_derived_sources: baseReviewPayload.selected_derived_sources ?? [],
          target_table: baseReviewPayload.target_table ?? null,
          relationships: (baseReviewPayload.relationships ?? []) as Array<Record<string, unknown>>,
          requested_level: 'FULL_REGISTRY',
          force: false,
        });
        return {
          ...baseReviewPayload,
          semantic_bundle_id: semanticRefresh.bundle_id ?? baseReviewPayload.semantic_bundle_id,
          semantic_bundle_label: semanticRefresh.bundle_label ?? baseReviewPayload.semantic_bundle_label,
          semantic_view_name: semanticRefresh.semantic_view_name ?? null,
          semantic_model_yaml: semanticRefresh.semantic_model_yaml ?? null,
        };
      });
      if (latestCompileContext.current !== requestContext) return null;
      if (semanticReview.warning) setReviewStage(semanticReview.warning);
      const result = await dbService.reviewMappingSql({
        ...semanticReview.payload,
        request_optimization: requestOptimization,
      });
      if (semanticReview.warning) result.warnings = [...(result.warnings ?? []), semanticReview.warning];
      if (latestCompileContext.current !== requestContext) return null;
      // Review-only semantic discovery must not replace the prepared mapping
      // context after compilation: that invalidates the script we just built.
      // Source preparation owns persisted semantic refreshes; this model is
      // supplied to the review request above without mutating the workspace.
      lastValidatedReviewContextRef.current = validationSignature;
      setReviewResult(result);
      setReviewSelectionVariant(result.requires_approval ? 'original' : null);
      const defaultPreviewSql =
        result.optimized_preview_sql ?? result.original_preview_sql;
      setApprovedPreviewSql(result.requires_approval ? result.original_preview_sql : defaultPreviewSql);
      if (result.requires_approval) {
        setMappingPreviewSql(result.original_preview_sql);
        setMappingSqlVariant('original');
      } else {
        setMappingPreviewSql(defaultPreviewSql);
        setMappingSqlVariant('original');
      }
      setActiveTab('sql-preview');
      if (!result.execution_ready) {
        setReviewStage(result.review_summary || 'SQL review found issues that still need attention before preview can run.');
      } else if (result.review_agent === 'CORTEX_ANALYST') {
        setReviewStage(
          result.requires_approval
            ? 'Cortex Analyst found an optimization suggestion. Review the proposed SQL before running the preview.'
            : 'Cortex Analyst reviewed the SQL and found no required optimization changes. You can run the preview now.'
        );
      } else {
        setReviewStage(
          result.requires_approval
            ? 'Snowflake validation found an optimized SQL option. Review it before running the preview.'
            : 'Snowflake validation completed successfully. No SQL optimization changes were required.'
        );
      }
      if (result.requires_approval && result.optimized_preview_sql) {
        setReviewDialogOpen(true);
      }
      refreshAssistantSignals("after_validation");
      return result;
    } catch (error) {
      if (latestCompileContext.current !== requestContext) return null;
      refreshAssistantSignals("after_validation");
      reviewErrorRef.current =
        error instanceof Error ? error.message : 'Unable to validate the generated SQL.';
      setReviewError(reviewErrorRef.current);
      setReviewStage('SQL review failed. Fix the issue and try validation again.');
      return null;
    } finally {
      setReviewLoading(false);
    }
  };

  const handleCompileAndValidate = async (
    requestOptimization = false,
  ): Promise<MappingSqlReviewResponse | null> => {
    const compiled = await compileCurrentMappingSql();
    if (!compiled || !compiled.ready) {
      setSqlFailureNotice({
        title: 'SQL compilation failed',
        message: compilerErrorRef.current
          ?? 'The mapping could not be compiled into SQL. Review the mapping and try Compile & Validate again.',
      });
      return null;
    }
    const review = await handleValidateSql(requestOptimization, {
      ...mappingSqlRequestPayload,
      preview_sql: compiled.preview_sql,
      canonical_preview_sql: compiled.canonical_preview_sql,
      generated_sql: compiled.generated_sql,
    });
    if (review?.execution_ready) {
      setValidationSucceeded(true);
    } else {
      setSqlFailureNotice({
        title: 'SQL validation failed',
        message: review
          ? review.review_summary || 'Snowflake validation found issues that must be fixed before this mapping can be published.'
          : reviewErrorRef.current ?? 'Unable to validate the generated SQL. Try Compile & Validate again.',
      });
    }
    return review;
  };

  const handleReviewSqlChanges = async () => {
    if (!editableSql.trim()) return false;
    setSqlParseLoading(true);
    setPreviewError(null);
    try {
      const result = await dbService.parseMappingSql({
        sql: editableSql,
        project_id: activeProjectId,
        known_tables: knownSqlTables,
        current_workspace: {
          source_tables: selectedSourceTables.map(
            (table) => `${table.database}.${table.schema}.${table.table}`,
          ),
          target_table: selectedTargetQualifiedName,
          mapping_rows: mappedMappings,
          relationships: relationshipPayload,
          filters: sourceFilterSql ? [{ sql_fragment: sourceFilterSql }] : [],
        },
      });
      setSqlParseResult(result);
      if (!result.valid) {
        setSqlParseDialogOpen(true);
        return false;
      }

      const parsed = applyParsedSqlResult(result, false);
      if (!parsed) return false;
      const parsedTargetName = result.parsed_workspace.target_table ?? selectedTargetQualifiedName;
      const parsedTarget = parsedTargetName ? qualifiedNameToTableRef(parsedTargetName) : null;
      const parsedSources = (result.parsed_workspace.source_tables ?? [])
        .map(qualifiedNameToTableRef)
        .filter((table): table is TableRef => Boolean(table));
      const parsedReviewMappings = parsed.parsedMappings.map((mapping) => ({
        target_column: mapping.targetColumn,
          target_sql_name: mapping.targetSqlName,
        target_type: mapping.targetType,
        source_column: mapping.sourceColumn,
        source_columns: mapping.sourceColumns ?? parseSourceColumns(mapping.sourceColumn),
        mapping_mode: mapping.mappingMode ?? 'source',
        constant_value: mapping.constantValue ?? null,
        attribute_name: mapping.attributeName ?? null,
        expression: mapping.expression,
        rule: mapping.rule,
        status: mapping.status,
        nl_rule: mapping.nlRule,
        description: mapping.description,
      }));
      const review = await handleValidateSql(false, {
        ...mappingSqlRequestPayload,
        source_tables: parsedSources.length ? parsedSources : mappingSqlRequestPayload.source_tables,
        target_table: parsedTarget ?? mappingSqlRequestPayload.target_table,
        preview_sql: result.preview_sql ?? editableSql,
        generated_sql: buildEditedInsertSql(result.preview_sql ?? editableSql, parsedTargetName, parsed.parsedMappings),
        mappings: parsedReviewMappings,
      });
      if (!review?.execution_ready) {
        setSqlFailureNotice({
          title: 'SQL validation failed',
          message: review
            ? review.review_summary || 'Snowflake validation found issues in the edited SQL.'
            : reviewErrorRef.current ?? 'Unable to validate the edited SQL.',
        });
        return false;
      }
      applyParsedSqlResult(result, true, true);
      // Recorded after the synced mappings render, so it matches the new workspace.
      setValidationSucceeded(true);
      setReviewStage('Edited SQL compiled, validated, and synchronized with the mapping workspace.');
      setActiveTab('mapping');
      return true;
    } catch (error) {
      setPreviewError(error instanceof Error ? error.message : 'SQL parsing failed.');
      setSqlFailureNotice({
        title: 'SQL validation failed',
        message: error instanceof Error ? error.message : 'SQL parsing failed.',
      });
      return false;
    } finally {
      setSqlParseLoading(false);
    }
  };

  const handleAiSqlRepair = useCallback(async () => {
    const requestContext = compilerContextHash;
    setReviewLoading(true);
    setReviewError(null);
    setReviewStage('AI is repairing the syntax and Snowflake will validate the candidate...');
    try {
      const result = await dbService.reviewMappingSql({
        ...mappingSqlRequestPayload,
        attempt_ai_repair: true,
      });
      if (latestCompileContext.current !== requestContext) return;
      setReviewResult(result);
      setReviewSelectionVariant(result.requires_approval ? 'original' : null);
      if (result.optimized_preview_sql) {
        setApprovedPreviewSql(result.original_preview_sql);
        setMappingPreviewSql(result.original_preview_sql);
        setMappingSqlVariant('original');
        setReviewDialogOpen(true);
        setReviewStage('AI prepared a repair that passed Snowflake validation. Compare and approve it.');
      } else {
        setReviewStage(result.review_summary || 'AI could not produce a safe validated repair.');
      }
    } catch (error) {
      if (latestCompileContext.current !== requestContext) return;
      setReviewError(error instanceof Error ? error.message : 'Unable to generate an AI SQL repair.');
      setReviewStage('AI SQL repair failed. The current SQL was not changed.');
    } finally {
      setReviewLoading(false);
    }
  }, [compilerContextHash, mappingSqlRequestPayload, setMappingPreviewSql, setMappingSqlVariant]);

  const handleApproveReviewedSql = useCallback(async (variant: 'original' | 'optimized') => {
    if (!reviewResult) {
      setReviewDialogOpen(false);
      return;
    }
    setReviewDialogOpen(false);
    setApprovedVariant(variant);
    setReviewSelectionVariant(variant);
    if (variant === 'optimized') {
      const optimizedPreviewSql =
        reviewResult.optimized_preview_sql ?? reviewResult.original_preview_sql;
      setApprovedPreviewSql(optimizedPreviewSql);
      setMappingSql(reviewResult.optimized_generated_sql ?? reviewResult.original_generated_sql);
      setMappingPreviewSql(optimizedPreviewSql);
      setMappingSqlVariant('optimized');
      setCompiledMappingResult({
        generatedSql: reviewResult.optimized_generated_sql ?? reviewResult.original_generated_sql,
        previewSql: optimizedPreviewSql,
        scriptSql: reviewResult.optimized_script_sql,
        ready: reviewResult.execution_ready,
        contextHash: compilerContextHash,
      });
      setReviewStage(
        reviewResult.review_kind === 'repair'
          ? 'Suggested SQL repair applied. Run the preview when you are ready.'
          : 'Optimized SQL applied. Run the preview when you are ready.',
      );
    } else {
      setApprovedPreviewSql(reviewResult.original_preview_sql);
      setMappingSql(reviewResult.original_generated_sql);
      setMappingPreviewSql(reviewResult.original_preview_sql);
      setMappingSqlVariant('original');
      setCompiledMappingResult({
        generatedSql: reviewResult.original_generated_sql,
        previewSql: reviewResult.original_preview_sql,
        scriptSql: reviewResult.original_script_sql,
        ready: !reviewResult.validation_error && reviewResult.execution_ready,
        contextHash: compilerContextHash,
      });
      setReviewStage('Original SQL selected. Run the preview when you are ready.');
    }
  }, [compilerContextHash, reviewResult, setCompiledMappingResult, setMappingPreviewSql, setMappingSql, setMappingSqlVariant]);

  const previewRelationLabels = useMemo(() => buildRelationDisplayAliases(
    compilerRelationGraph.nodes.map((node) => ({
      identity: node.relation_id,
      alias: node.alias,
      displaySeed: selectedDerivedSourceRecords.find((source) => source.id === node.relation_id)?.sourceName,
    })),
  ), [compilerRelationGraph.nodes, selectedDerivedSourceRecords]);

  const previewDisplayRows = useMemo<PreviewDisplayRow[]>(() => {
    if (!validatedPreviewData || !validatedPreviewData.preview_rows?.length) {
      return [];
    }
    const selectedRow =
      validatedPreviewData.preview_rows[selectedPreviewRowIndex] ??
      validatedPreviewData.preview_rows[0];
    const selectedSourceRow =
      validatedPreviewData.source_sample_rows?.[selectedPreviewRowIndex] ??
      validatedPreviewData.source_sample_rows?.[0];
    const sourceRow = selectedSourceRow?.values ?? {};
    const transformedRow = selectedRow?.values ?? {};
    let displayIndex = 1;

    return mappings.flatMap((mapping) => {
      if (mapping.status !== 'MAPPED') {
        return [];
      }
      const sourceColumns =
        mapping.sourceColumns && mapping.sourceColumns.length
          ? mapping.sourceColumns
          : parseSourceColumns(mapping.sourceColumn);
      const effectiveSources = sourceColumns.length ? sourceColumns : ['—'];
      const description =
        mapping.description?.trim() ||
        generateMappingDescription({
          rule: mapping.rule,
          sourceColumns: sourceColumns.filter(Boolean),
          targetColumn: mapping.targetColumn,
          expression: mapping.expression,
        }) ||
        '—';
      const transformedValue = stringifyPreviewValue(transformedRow[mapping.targetColumn]);
      const expressionLabel =
        mapping.expression?.trim() ||
        (mapping.rule && mapping.rule !== 'Direct' && mapping.rule !== 'Select...' ? mapping.rule : null);

      return effectiveSources.map((sourceColumn, index) => {
        const alias = validatedPreviewData.source_sample_aliases?.[sourceColumn];
        const sourceLabel = splitSourceDisplayLabel(formatRelationDisplayText(sourceColumn, previewRelationLabels));
        const sourceValue =
          sourceColumn === '—'
            ? '—'
            : stringifyPreviewValue(alias ? sourceRow[alias] : undefined);
        const row: PreviewDisplayRow = {
          mappingId: mapping.id,
          targetColumn: mapping.targetColumn,
          targetType: mapping.targetType,
          sourceColumn,
          sourceColumnDisplay: sourceLabel.column,
          sourceRelationDisplay: sourceLabel.relation,
          sourceValue,
          transformedValue,
          description: formatRelationDisplayText(description, previewRelationLabels),
          expressionLabel: expressionLabel ? formatRelationDisplayText(expressionLabel, previewRelationLabels) : null,
          confidenceScore: mapping.confidenceScore ?? null,
          confidenceReason: mapping.confidenceReason ? formatRelationDisplayText(mapping.confidenceReason, previewRelationLabels) : null,
          candidateSourceColumns: (mapping.candidateSourceColumns ?? []).map((source) => formatRelationDisplayText(source, previewRelationLabels)),
          rowCount: effectiveSources.length,
          rowIndex: index,
          displayIndex,
        };
        if (index === effectiveSources.length - 1) {
          displayIndex += 1;
        }
        return row;
      });
    });
  }, [mappings, previewRelationLabels, selectedPreviewRowIndex, validatedPreviewData]);

  const previewResultRows = useMemo<Array<Record<string, unknown> & { index: number }>>(
    () =>
      (validatedPreviewData?.preview_rows ?? []).map((row, index) => ({
        index: index + 1,
        ...row.values,
      })),
    [validatedPreviewData],
  );

  useEffect(() => {
    if (!previewResultRows.length) {
      setSelectedPreviewRowIndex(0);
      return;
    }
    if (selectedPreviewRowIndex > previewResultRows.length - 1) {
      setSelectedPreviewRowIndex(0);
    }
  }, [previewResultRows.length, selectedPreviewRowIndex]);

  const tabs: Array<{ key: MappingTab; label: string; icon: ReactNode; badge?: number; tourTarget?: string }> = [
    { key: 'mapping', label: 'Mapping', icon: <ChecklistRtlRoundedIcon sx={{ fontSize: 17 }} /> },
    {
      key: 'sql-preview',
      label: 'SQL',
      icon: <TerminalRoundedIcon sx={{ fontSize: 17 }} />,
      badge: mappedCount > 0 ? mappedCount : undefined,
      tourTarget: TOUR_TARGETS.sttmSqlPreviewTab,
    },
    {
      key: 'data-preview',
      label: 'Data Preview',
      icon: <TableRowsRoundedIcon sx={{ fontSize: 17 }} />,
      tourTarget: TOUR_TARGETS.sttmDataPreviewTab,
    },
    {
      key: 'data-lineage',
      label: 'Data Lineage',
      icon: <AccountTreeOutlinedIcon sx={{ fontSize: 17 }} />,
      tourTarget: TOUR_TARGETS.sttmDataLineageTab,
    },
  ];

  const progressTrailing = (
    <MappingProgressIndicator mappedCount={mappedCount} totalCount={totalCount} />
  );

  const compactReviewSummary = useMemo(() => {
    if (!reviewResult?.review_summary) return null;
    const firstSentence = reviewResult.review_summary.split(/(?<=[.!?])\s+/)[0]?.trim();
    return firstSentence || reviewResult.review_summary;
  }, [reviewResult]);

  const reviewDiffDocument = useMemo(
    () => {
      if (!reviewResult?.optimized_preview_sql) {
        return null;
      }
      const hasGeneratedDelta =
        Boolean(reviewResult.optimized_generated_sql) &&
        reviewResult.optimized_generated_sql !== reviewResult.original_generated_sql;
      const originalSql = hasGeneratedDelta
        ? reviewResult.original_generated_sql
        : reviewResult.original_preview_sql;
      const optimizedSql = hasGeneratedDelta
        ? (reviewResult.optimized_generated_sql ?? reviewResult.original_generated_sql)
        : (reviewResult.optimized_preview_sql ?? reviewResult.original_preview_sql);

      return {
        title: hasGeneratedDelta ? 'Final generated SQL changes' : 'Preview SQL changes',
        originalSql,
        optimizedSql,
        lines: buildUnifiedSqlDiffLines(originalSql, optimizedSql),
      };
    },
    [reviewResult],
  );

  const reviewDiffSummary = useMemo(() => {
    const removals = reviewDiffDocument?.lines.filter((row) => row.kind === 'removed').length ?? 0;
    const additions = reviewDiffDocument?.lines.filter((row) => row.kind === 'added').length ?? 0;
    return { removals, additions };
  }, [reviewDiffDocument]);

  const sqlReviewStatusPanel = useMemo(() => {
    if ((!reviewError && !reviewStage && !reviewResult && !previewError) || reviewBannerDismissed) {
      return null;
    }

    const tone = reviewError
      ? 'error'
      : previewError
        ? 'warning'
        : reviewResult && !reviewResult.execution_ready
          ? 'error'
        : reviewResult?.requires_approval
          ? 'warning'
          : reviewLoading || previewLoading
            ? 'info'
            : 'success';

    const primaryMessage = reviewError
      ? reviewError
      : previewError
        ? previewError
        : reviewResult
          ? compactReviewSummary || reviewResult.review_summary
          : reviewStage;

    const secondaryMessage =
      !reviewError && !previewError && reviewResult?.warnings?.length
        ? reviewResult.warnings.join(' ')
        : null;

    return (
      <AiaStack spacing={1.25}>
        {primaryMessage ? (
          <AiaAlert
            severity={tone}
            sx={{ borderRadius: 2, py: 0.25 }}
            action={
              reviewLoading || previewLoading ? (
                <AiaCircularProgress size={18} color="inherit" />
              ) : reviewResult?.requires_approval ? (
                <AiaBox sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                  <AiaButton
                    color="inherit"
                    size="small"
                    sx={{ textTransform: 'none', fontWeight: 700 }}
                    onClick={() => setReviewDialogOpen(true)}
                  >
                    View diff
                  </AiaButton>
                  <AiaButton
                    color="inherit"
                    size="small"
                    disabled={reviewSelectionVariant === 'optimized'}
                    sx={{ textTransform: 'none', fontWeight: 700 }}
                    onClick={() => {
                      void handleApproveReviewedSql('optimized');
                    }}
                  >
                    {reviewSelectionVariant === 'optimized' ? 'Applied' : 'Apply'}
                  </AiaButton>
                  <AiaIconButton size="small" color="inherit" onClick={() => setReviewBannerDismissed(true)}>
                    <CloseRoundedIcon fontSize="small" />
                  </AiaIconButton>
                </AiaBox>
              ) : (
                <AiaBox sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  {reviewResult && !reviewError && !previewError && !reviewLoading && !previewLoading ? (
                    <AiaText sx={{ fontSize: '0.76rem', fontWeight: 700, opacity: 0.9 }}>
                      {!reviewResult.execution_ready
                        ? 'Fix required'
                        : reviewResult.requires_approval
                          ? 'Review required'
                          : 'No changes required'}
                    </AiaText>
                  ) : null}
                  <AiaIconButton size="small" color="inherit" onClick={() => setReviewBannerDismissed(true)}>
                    <CloseRoundedIcon fontSize="small" />
                  </AiaIconButton>
                </AiaBox>
              )
            }
          >
            {reviewResult && !reviewError && !previewError ? (
              <AiaText sx={{ fontSize: '0.82rem', fontWeight: 700, mb: 0.4 }}>
                Reviewed by {getReviewAgentLabel(reviewResult.review_agent)}
              </AiaText>
            ) : null}
            <AiaText sx={{ fontSize: '0.8rem', lineHeight: 1.5 }}>
              {primaryMessage}
            </AiaText>
            {secondaryMessage ? (
              <AiaText sx={{ fontSize: '0.76rem', lineHeight: 1.45, mt: 0.5 }}>
                {secondaryMessage}
              </AiaText>
            ) : null}
            {reviewResult && !reviewResult.execution_ready && reviewResult.repair_options?.length ? (
              <AiaBox sx={{ mt: 1.25, display: 'grid', gap: 0.75 }}>
                <AiaText sx={{ fontSize: '0.78rem', fontWeight: 800 }}>
                  Ways to fix this
                </AiaText>
                {reviewResult.repair_options.map((option) => (
                  <AiaBox
                    key={`${option.code}-${option.identifier ?? ''}`}
                    sx={{
                      minWidth: 0,
                      p: 1,
                      border: '1px solid currentColor',
                      borderRadius: 1.5,
                      opacity: 0.95,
                    }}
                  >
                    <AiaBox sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 1, flexWrap: 'wrap' }}>
                      <AiaBox sx={{ minWidth: 0, flex: '1 1 280px' }}>
                        <AiaText sx={{ fontSize: '0.76rem', fontWeight: 800, overflowWrap: 'anywhere' }}>
                          {option.title}
                        </AiaText>
                        <AiaText sx={{ mt: 0.25, fontSize: '0.73rem', lineHeight: 1.45, overflowWrap: 'anywhere', wordBreak: 'break-word' }}>
                          {option.description}
                        </AiaText>
                      </AiaBox>
                      {option.action === 'review_suggested_sql' ? (
                        <AiaButton color="inherit" size="small" sx={{ textTransform: 'none', fontWeight: 700 }} onClick={() => setReviewDialogOpen(true)}>
                          Compare repair
                        </AiaButton>
                      ) : option.action === 'request_ai_repair' ? (
                        <AiaButton
                          color="inherit"
                          size="small"
                          disabled={reviewLoading}
                          sx={{ textTransform: 'none', fontWeight: 700 }}
                          onClick={() => { void handleAiSqlRepair(); }}
                        >
                          {reviewLoading ? 'Repairing…' : 'Fix with AI'}
                        </AiaButton>
                      ) : option.action === 'open_mapping' ? (
                        <AiaButton color="inherit" size="small" sx={{ textTransform: 'none', fontWeight: 700 }} onClick={() => setActiveTab('mapping')}>
                          Open mapping
                        </AiaButton>
                      ) : (
                        <AiaText sx={{ fontSize: '0.7rem', fontWeight: 800, opacity: 0.85 }}>
                          Use Edit SQL above
                        </AiaText>
                      )}
                    </AiaBox>
                  </AiaBox>
                ))}
              </AiaBox>
            ) : null}
          </AiaAlert>
        ) : null}
      </AiaStack>
    );
  }, [
    compactReviewSummary,
    previewError,
    previewLoading,
    reviewBannerDismissed,
    reviewError,
    reviewLoading,
    reviewResult,
    reviewSelectionVariant,
    reviewStage,
    handleApproveReviewedSql,
    handleAiSqlRepair,
  ]);

  return (
    <div className="flex h-full min-h-0 w-full min-w-0 flex-1 flex-col overflow-hidden bg-white">
      <BuilderWorkspaceTabBar
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        trailing={progressTrailing}
      />

      {workspacePersistenceStatus === 'saving' || workspacePersistenceStatus === 'saving_details'
        || workspacePersistenceStatus === 'details_pending' ? (
        <AiaBox sx={{ px: 2, py: 0.5, bgcolor: '#eff6ff', borderBottom: '1px solid #bfdbfe' }}>
          <AiaText sx={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 700 }}>
            {workspacePersistenceStatus === 'saving' ? 'Saving draft…'
              : workspacePersistenceStatus === 'details_pending' ? 'Draft saved · Background details still pending'
                : 'Draft saved · Updating background details…'}
          </AiaText>
        </AiaBox>
      ) : workspacePersistenceStatus === 'error' ? (
        <AiaBox sx={{ px: 2, py: 0.5, bgcolor: '#fff7ed', borderBottom: '1px solid #fed7aa' }}>
          <AiaText sx={{ fontSize: '0.75rem', color: '#9a3412', fontWeight: 700 }}>
            {workspacePersistenceError || 'The latest draft save needs attention.'}
          </AiaText>
        </AiaBox>
      ) : null}

      {projectAttributesError ? (
        <AiaAlert severity="warning" sx={{ borderRadius: 0 }} action={(
          <AiaButton size="small" variant="outlined" disabled={isLoadingProjectAttributes}
            onClick={() => { void reloadProjectAttributes(); }}>Retry values</AiaButton>
        )}>
          {projectAttributesError}
        </AiaAlert>
      ) : null}

      {pendingSourceReconciliation.length > 0 ? (
        <AiaAlert
          severity="warning"
          sx={{ borderRadius: 0 }}
          action={(
            <AiaButton size="small" variant="outlined" onClick={acknowledgeSourceReconciliation}>
              Acknowledge
            </AiaButton>
          )}
        >
          <AiaText sx={{ fontSize: '0.8rem', fontWeight: 800 }}>
            {pendingSourceReconciliation.length} mapped{' '}
            {pendingSourceReconciliation.length === 1 ? 'row references' : 'rows reference'} an unresolved source
          </AiaText>
          <AiaText sx={{ mt: 0.35, fontSize: '0.76rem', lineHeight: 1.5, overflowWrap: 'anywhere' }}>
            These targets point at source relations that are not resolvable in the current workspace:{' '}
            {pendingSourceReconciliation.slice(0, 8).join(', ')}
            {pendingSourceReconciliation.length > 8
              ? ` and ${pendingSourceReconciliation.length - 8} more`
              : ''}
            . They remain mapped and your saved work is unchanged, but SQL compilation may fail until the missing source is re-added.
          </AiaText>
        </AiaAlert>
      ) : null}

      <AiaBox
        sx={{
          display: 'flex',
          flex: 1,
          minHeight: 0,
          minWidth: 0,
          overflow: 'hidden',
        }}
      >
        {activeTab === 'mapping' ? (
        <AiaBox
              sx={{
            display: 'flex',
            width: collapsed ? COLLAPSED_SIDEBAR_WIDTH : width,
            minWidth: collapsed ? COLLAPSED_SIDEBAR_WIDTH : MIN_SIDEBAR_WIDTH,
            maxWidth: collapsed ? COLLAPSED_SIDEBAR_WIDTH : '50vw',
            flexShrink: 0,
            borderRight: '1px solid #e5e7eb',
            overflow: 'hidden',
            bgcolor: 'var(--color-surface)',
            minHeight: 0,
            height: '100%',
          }}
        >
          {collapsed ? (
            <AiaBox
            sx={{
                width: '100%',
                height: '100%',
                minHeight: 0,
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <AiaBox sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
                <SourceTargetAttributeList embedded />
              </AiaBox>
              <SttmSidebarCollapseFooter
                collapsed
                centered
                expandLabel="Expand source sidebar"
                onToggle={() => setCollapsed(false)}
              />
            </AiaBox>
          ) : (
            <AiaBox sx={{ display: 'flex', width: '100%', minWidth: 0, minHeight: 0, flex: 1 }}>
              <AiaBox
                sx={{
                  minWidth: 0,
                  flex: 1,
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  overflow: 'hidden',
                }}
              >
                <SourceTargetAttributeList embedded />
              </AiaBox>
              <AiaResizeHandle
                direction="horizontal"
                onMouseDown={beginResize}
                sx={{ alignSelf: 'stretch', height: '100%' }}
              />
            </AiaBox>
          )}
        </AiaBox>
        ) : null}

        <AiaBox
            sx={{
              flex: 1,
              minWidth: 0,
              minHeight: 0,
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
        {activeTab === 'mapping' ? (
          <AiaBox
              sx={{
              minWidth: 0,
              flex: 1,
              minHeight: 0,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
            <SourceTargetAttributeMapping />
          </AiaBox>
        ) : null}

        {activeTab === 'sql-preview' ? (
          <AiaBox
            data-tour={TOUR_TARGETS.sttmSqlPreviewPanel}
            sx={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}
          >
            <MappingSqlPreview
              displayRelations={compilerRelationGraph.nodes.map((node) => ({
                identity: node.relation_id,
                alias: node.alias,
                displaySeed: selectedDerivedSourceRecords.find((source) => source.id === node.relation_id)?.sourceName,
              }))}
              autoCompile={autoCompile}
              onAutoCompileChange={changeAutoCompile}
              provisional={currentSqlArtifact.source === 'generated'}
              sqlTitle={
                currentSqlArtifact.source === 'generated'
                  ? isCompilingSql ? 'Draft SQL · Compiling' : cteDraft?.status === 'partial' ? 'Partial draft · Not validated'
                    : cteDraft?.status === 'blocked' ? 'Draft unavailable · Not validated' : 'Draft SQL · Not validated'
                  : currentSqlArtifact.source === 'authored' ? 'Imported SQL' : 'Compiled SQL'
              }
              targetLabel={selectedTargetQualifiedName?.split('.').pop() ?? null}
              mappedCount={mappedCount}
              tableCount={selectedInputCount}
              filterCount={filterCount}
              joinCount={relationships.length}
              generatedSql={
                approvedVariant === 'optimized' && approvedPreviewSql && currentSqlHasValidationReceipt
                  ? reviewResult?.optimized_script_sql || approvedPreviewSql
                  : currentSqlArtifact.source === 'generated' ? provisionalSql : currentSqlArtifact.scriptSql
              }
              suggestions={sqlCompletionCandidates}
              onCompile={() => {
                void handleCompileAndValidate();
              }}
              compileDisabled={
                reviewLoading
                || mappedCount === 0
                || !compilerRelationGraph.nodes.length
                // Nothing changed in Select Tables or the mapping since the last
                // successful validation, so there is nothing new to validate.
                || (isMappingSqlValidated && currentSqlArtifact.source !== 'generated')
              }
              compileLoading={isCompilingSql || reviewLoading}
              onOptimize={() => {
                void handleCompileAndValidate(true);
              }}
              optimizeDisabled={reviewLoading || mappedCount === 0 || Boolean(compilerError)}
              optimizeLoading={reviewLoading}
              onRunPreview={() => {
                void handleRunPreview();
              }}
              runDisabled={
                previewLoading
                || currentSqlArtifact.source === 'generated'
                || (currentSqlArtifact.source === 'compiled' && !currentSqlArtifact.ready)
                || reviewLoading
                || Boolean(compilerError)
                || (!currentSqlHasValidationReceipt && !isMappingSqlValidated)
                || (Boolean(reviewResult?.requires_approval) && !reviewSelectionVariant)
              }
              runLoading={previewLoading}
              runLabel={previewLoading ? 'Running...' : 'Run Preview'}
              statusPanel={
                <>
                  {currentSqlArtifact.source === 'generated' && cteDraft && !savedWorkspaceHydrating ? (
                    <AiaAlert severity={cteDraft.status === 'complete' ? 'info' : 'warning'} sx={{ mb: 1 }}>
                      <AiaText sx={{ fontSize: '0.8rem', fontWeight: 700 }}>
                        {cteDraft.shownCount} of {cteDraft.mappedCount} mapped targets shown. Draft not validated.
                      </AiaText>
                      {cteDraft.diagnostics.length > 0 || cteDraft.blockers.length > 0 ? (
                        <AiaBox component="details" sx={{ mt: 0.35, fontSize: '0.76rem', lineHeight: 1.5, overflowWrap: 'anywhere' }}>
                          <summary>Review draft issues ({cteDraft.diagnostics.length + cteDraft.blockers.length})</summary>
                          <AiaBox sx={{ maxHeight: 180, overflow: 'auto' }}>
                            <AiaText sx={{ fontSize: 'inherit', mt: 0.5 }}>All mapped rows remain included in compilation.</AiaText>
                            {cteDraft.diagnostics.map(item => <AiaText key={item.targetColumn} sx={{ fontSize: 'inherit', mt: 0.5 }}>
                              {item.targetColumn}: {item.reference} — {item.reason}
                            </AiaText>)}
                            {cteDraft.blockers.map(reason => <AiaText key={reason} sx={{ fontSize: 'inherit', mt: 0.5 }}>{reason}</AiaText>)}
                          </AiaBox>
                        </AiaBox>
                      ) : null}
                    </AiaAlert>
                  ) : null}
                  {isMappingSqlValidated && currentSqlArtifact.source !== 'generated' && !compilerError && !reviewLoading ? (
                    <AiaAlert severity="success" sx={{ mb: 1 }}>
                      <AiaText sx={{ fontSize: '0.8rem', fontWeight: 700 }}>
                        SQL validated for the mapped columns. Unmapped targets and business rules still require review before publishing.
                      </AiaText>
                    </AiaAlert>
                  ) : null}
                  {compilerBindingNotes.length > 0 && !compilerError ? (
                    <details className="rounded-lg border border-slate-200 p-3 text-sm text-slate-600">
                      <summary>CTE executable binding adaptations ({compilerBindingNotes.length})</summary>
                      {compilerBindingNotes.map(note => <p key={note} className="mt-2 break-words">{note}</p>)}
                    </details>
                  ) : null}
                  {compilerError ? (
                    <AiaAlert severity="warning" sx={{ mb: 1 }}>
                      <AiaText sx={{ fontSize: '0.8rem', fontWeight: 800 }}>
                        SQL graph needs attention
                      </AiaText>
                      <AiaText sx={{ mt: 0.35, fontSize: '0.76rem', lineHeight: 1.5, overflowWrap: 'anywhere' }}>
                        {compilerError}
                      </AiaText>
                      <AiaText sx={{ mt: 0.35, fontSize: '0.73rem', lineHeight: 1.45 }}>
                        Resolve the compiler error and compile again. Any draft shown is not validated.
                      </AiaText>
                    </AiaAlert>
                  ) : null}
                  {sqlReviewStatusPanel}
                </>
              }
              editableSql={editableSql}
              onEditableSqlChange={setEditableSql}
              onReviewSqlChanges={handleReviewSqlChanges}
              reviewSqlChangesLoading={sqlParseLoading || reviewLoading}
            />
          </AiaBox>
                  ) : null}

        {activeTab === 'data-preview' ? (
          <AiaBox
            data-tour={TOUR_TARGETS.sttmDataPreviewPanel}
            sx={{ flex: 1, width: '100%', minWidth: 0, minHeight: 0, overflow: 'auto', p: 2, backgroundColor: '#fff' }}
          >
            <AiaPaper
              elevation={0}
              sx={{ border: '1px solid #e5e7eb', borderRadius: 3, overflow: 'hidden', width: '100%' }}
            >
              <AiaBox sx={{ px: 2, py: 1.5, borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <AiaText sx={CARD_TITLE_SX}>
                  Result preview
                </AiaText>
                <AiaText sx={{ fontSize: '0.76rem', color: '#64748b' }}>
                  {validatedPreviewData?.preview_rows?.length ?? 0} sample rows
                </AiaText>
              </AiaBox>
              {validatedPreviewData ? (
                <AiaBox sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                  <AiaText sx={{ fontSize: '0.76rem', color: '#475569', lineHeight: 1.5 }}>
                    Sample values below come from executing the approved SQL in Snowflake. They are not AI-generated values.
                    {reviewResult
                      ? ` The approved SQL variant came from ${getReviewAgentLabel(reviewResult.review_agent)}.`
                      : ''}
                  </AiaText>
                </AiaBox>
              ) : null}
              {previewLoading ? (
                <AiaBox sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', py: 8, gap: 1.5 }}>
                  <AiaCircularProgress size={32} />
                  <AiaText sx={{ fontSize: '0.88rem', color: '#475569', fontWeight: 500 }}>
                    Running preview in Snowflake…
                  </AiaText>
                </AiaBox>
              ) : previewError ? (
                <AiaBox sx={{ p: 2.5 }}>
                  <AiaText sx={{ fontSize: '0.82rem', color: '#b91c1c' }}>
                    {previewError}
                  </AiaText>
                </AiaBox>
              ) : !validatedPreviewData ? (
                <AiaBox sx={{ p: 2.5 }}>
                  <AiaText sx={BODY_SX}>
                    Validate the generated SQL first to preview actual sample output values.
                  </AiaText>
                  <AiaButton
                    variant="outlined"
                    size="medium"
                    customColor="var(--color-primary)"
                    customBorderColor="var(--color-primary)"
                    sx={{ mt: 1.5 }}
                    onClick={() => {
                      setActiveTab('sql-preview');
                    }}
                  >
                    Go to SQL preview
                  </AiaButton>
                </AiaBox>
              ) : previewResultRows.length === 0 ? (
                <AiaBox sx={{ p: 2.5 }}>
                  <AiaText sx={{ fontSize: '0.82rem', color: '#64748b' }}>
                    The approved SQL executed successfully, but it returned 0 preview rows for this sample run.
                  </AiaText>
                  <AiaText sx={{ fontSize: '0.76rem', color: '#94a3b8', mt: 0.75, lineHeight: 1.5 }}>
                    This usually means the current joins, filters, or transformed expressions did not produce matching sample output rows yet.
                  </AiaText>
                </AiaBox>
              ) : (
                <AiaStack spacing={2} sx={{ p: 2 }}>
                  {validatedPreviewData.warnings?.length ? (
                    <AiaAlert severity="warning" sx={{ borderRadius: 2 }}>
                      {validatedPreviewData.warnings.join(' ')}
                    </AiaAlert>
                  ) : null}
                  <AiaPaper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                    <AiaBox sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                      <AiaText sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Sample output rows</AiaText>
                      <AiaText sx={{ mt: 0.4, fontSize: '0.72rem', color: '#64748b' }}>
                        Select an output row to inspect its transformed values below.
                      </AiaText>
                    </AiaBox>
                    <AiaBox sx={{ overflow: 'auto' }}>
                      <AiaTablePrimitive size="small" stickyHeader>
                        <AiaTableHead>
                          <AiaTableRowPrimitive>
                            <AiaTableCellPrimitive sx={{ width: 56, fontWeight: 800 }}>Use</AiaTableCellPrimitive>
                            <AiaTableCellPrimitive sx={{ width: 52, fontWeight: 800 }}>#</AiaTableCellPrimitive>
                            {validatedPreviewData.preview_columns.map((column) => (
                              <AiaTableCellPrimitive key={column.name} sx={{ minWidth: 180, fontWeight: 800 }}>
                                {column.name}
                              </AiaTableCellPrimitive>
                            ))}
                          </AiaTableRowPrimitive>
                        </AiaTableHead>
                        <AiaTableBody>
                          {previewResultRows.map((row) => (
                            <AiaTableRowPrimitive
                              key={`result-${row.index}`}
                              hover
                              selected={selectedPreviewRowIndex === row.index - 1}
                  sx={{
                                cursor: 'pointer',
                                '&.Mui-selected': { backgroundColor: '#eff6ff' },
                                '&.Mui-selected:hover': { backgroundColor: '#dbeafe' },
                              }}
                              onClick={() => setSelectedPreviewRowIndex(row.index - 1)}
                            >
                              <AiaTableCellPrimitive padding="checkbox">
                                <AiaCheckbox
                                  checked={selectedPreviewRowIndex === row.index - 1}
                                  checkHandler={() => setSelectedPreviewRowIndex(row.index - 1)}
                                  size="small"
                                />
                              </AiaTableCellPrimitive>
                              <AiaTableCellPrimitive sx={{ fontSize: '0.8rem', color: '#64748b' }}>{row.index}</AiaTableCellPrimitive>
                              {validatedPreviewData.preview_columns.map((column) => (
                                <AiaTableCellPrimitive key={`${row.index}-${column.name}`} sx={{ fontSize: '0.82rem', color: "var(--aia-text-color)", whiteSpace: 'nowrap' }}>
                                  {stringifyPreviewValue(row[column.name])}
                                </AiaTableCellPrimitive>
                              ))}
                            </AiaTableRowPrimitive>
                          ))}
                        </AiaTableBody>
                      </AiaTablePrimitive>
                    </AiaBox>
                  </AiaPaper>
                  <AiaPaper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                    <AiaBox sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                      <AiaText sx={{ fontSize: '0.82rem', fontWeight: 800 }}>
                        Column trace for sample row {selectedPreviewRowIndex + 1}
                      </AiaText>
                      <AiaText sx={{ mt: 0.4, fontSize: '0.72rem', color: '#64748b' }}>
                        AI confidence estimates mapping fit, not value completeness. NULL means no returned value;
                        Not sampled means no source sample was available. Source samples are queried separately and may not match this output row.
                      </AiaText>
                    </AiaBox>
                    <AiaBox sx={{ overflow: 'auto' }}>
                      <AiaTablePrimitive size="small" stickyHeader>
                        <AiaTableHead>
                          <AiaTableRowPrimitive>
                            <AiaTableCellPrimitive sx={{ width: 52, fontWeight: 800 }}>#</AiaTableCellPrimitive>
                            <AiaTableCellPrimitive sx={{ minWidth: 240, fontWeight: 800 }}>Target Attr</AiaTableCellPrimitive>
                            <AiaTableCellPrimitive sx={{ minWidth: 210, fontWeight: 800 }}>Source Column</AiaTableCellPrimitive>
                            <AiaTableCellPrimitive sx={{ minWidth: 170, fontWeight: 800 }}>Source Value</AiaTableCellPrimitive>
                            <AiaTableCellPrimitive sx={{ minWidth: 200, fontWeight: 800 }}>Transformed Value</AiaTableCellPrimitive>
                            <AiaTableCellPrimitive sx={{ minWidth: 280, fontWeight: 800 }}>Description</AiaTableCellPrimitive>
                          </AiaTableRowPrimitive>
                        </AiaTableHead>
                        <AiaTableBody>
                          {previewDisplayRows.map((row) => (
                            <AiaTableRowPrimitive key={`${row.mappingId}-${row.rowIndex}`} hover>
                              {row.rowIndex === 0 ? (
                                <AiaTableCellPrimitive rowSpan={row.rowCount} sx={{ fontSize: '0.82rem', color: '#64748b', verticalAlign: 'top' }}>
                                  {row.displayIndex}
                                </AiaTableCellPrimitive>
                              ) : null}
                              {row.rowIndex === 0 ? (
                                <AiaTableCellPrimitive rowSpan={row.rowCount} sx={{ verticalAlign: 'top' }}>
                                  <AiaBox sx={{ minWidth: 0 }}>
                                    <AiaText sx={{ fontSize: '0.92rem', fontWeight: 800, color: "var(--aia-text-color)" }}>
                                      {row.targetColumn}
                                    </AiaText>
                                    <AiaText sx={{ fontSize: '0.72rem', color: '#94a3b8', mt: 0.25 }}>
                                      {row.targetType || '—'}
                                    </AiaText>
                                  </AiaBox>
                                </AiaTableCellPrimitive>
                              ) : null}
                              <AiaTableCellPrimitive sx={{ verticalAlign: 'top' }}>
                                <AiaBox sx={{ display: 'grid', gap: 0.45 }}>
                                  <AiaBox sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.55 }}>
                                    <AiaText sx={{ fontSize: '0.84rem', fontWeight: 700, color: "var(--aia-text-color)", lineHeight: 1.4, overflowWrap: 'anywhere' }}>
                                      {row.sourceColumnDisplay}
                                    </AiaText>
                                    {row.confidenceScore !== null ? (
                                      <AiaBox
                    sx={{
                                          display: 'inline-flex',
                      alignItems: 'center',
                                          gap: 0.35,
                                          px: 0.65,
                                          py: 0.15,
                                          borderRadius: 999,
                                          border: '1px solid',
                                          ...confidenceTone(row.confidenceScore),
                                        }}
                                        >
                                          <AiaText sx={{ fontSize: '0.68rem', fontWeight: 800, color: 'inherit' }}>
                                            {Math.round(row.confidenceScore * 100)}%
                                          </AiaText>
                                          {row.confidenceReason || row.candidateSourceColumns.length ? (
                                            <AiaTooltip
                                              title={
                                                [
                                                  row.description && row.description !== '—'
                                                    ? `Business fit: ${row.description}`
                                                    : null,
                                                  row.confidenceReason
                                                    ? `Evidence: ${row.confidenceReason}`
                                                    : null,
                                                  row.candidateSourceColumns.length
                                                    ? `Best alternatives: ${row.candidateSourceColumns.join(', ')}`
                                                    : null,
                                                ].filter(Boolean).join('\n')
                                              }
                                              placement="top"
                                              arrow
                                            >
                                              <InfoOutlinedIcon sx={{ fontSize: 13, color: 'inherit', cursor: 'help' }} />
                                            </AiaTooltip>
                                          ) : null}
                                        </AiaBox>
                                    ) : null}
                                  </AiaBox>
                                  {row.sourceRelationDisplay ? (
                                    <AiaText sx={{ fontSize: '0.7rem', color: '#94a3b8', lineHeight: 1.35, overflowWrap: 'anywhere' }}>
                                      {row.sourceRelationDisplay}
                                    </AiaText>
                                  ) : null}
                                </AiaBox>
                              </AiaTableCellPrimitive>
                              <AiaTableCellPrimitive sx={{ verticalAlign: 'top' }}>
                                <AiaBox
                    sx={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    px: 1.25,
                                    py: 0.5,
                                    borderRadius: 1.5,
                                    bgcolor: '#111827',
                                    color: '#f8fafc',
                                    fontSize: '0.78rem',
                                    fontWeight: 700,
                                  }}
                                >
                                  {row.sourceValue}
                                </AiaBox>
                              </AiaTableCellPrimitive>
                              {row.rowIndex === 0 ? (
                                <AiaTableCellPrimitive rowSpan={row.rowCount} sx={{ verticalAlign: 'top' }}>
                                  <AiaBox sx={{ display: 'grid', gap: 0.7, minWidth: 180 }}>
                                    <AiaBox
                  sx={{
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        px: 1.25,
                                        py: 0.6,
                                        borderRadius: 1.5,
                                        bgcolor: '#ecfdf5',
                                        color: '#166534',
                                        fontSize: '0.84rem',
                                        fontWeight: 800,
                                      }}
                                    >
                                      {row.transformedValue}
                                    </AiaBox>
                                    {row.expressionLabel ? (
                                      <AiaBox
                  sx={{
                                          display: 'inline-flex',
                                          px: 1.1,
                                          py: 0.55,
                                          borderRadius: 1.5,
                                          bgcolor: '#f5f3ff',
                                          color: '#6d28d9',
                                        }}
                                      >
                                        <AiaText sx={{ fontSize: '0.7rem', fontWeight: 700, lineHeight: 1.45 }}>
                                          {row.expressionLabel}
                                        </AiaText>
                                      </AiaBox>
                                    ) : null}
                                  </AiaBox>
                                </AiaTableCellPrimitive>
                              ) : null}
                              {row.rowIndex === 0 ? (
                                <AiaTableCellPrimitive rowSpan={row.rowCount} sx={{ verticalAlign: 'top' }}>
                                  <AiaText sx={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.5 }}>
                                    {row.description}
                                  </AiaText>
                                </AiaTableCellPrimitive>
                              ) : null}
                            </AiaTableRowPrimitive>
                          ))}
                        </AiaTableBody>
                      </AiaTablePrimitive>
                    </AiaBox>
                  </AiaPaper>
                </AiaStack>
              )}
            </AiaPaper>
          </AiaBox>
        ) : null}
        {activeTab === 'data-lineage' ? (
          <AiaBox data-tour={TOUR_TARGETS.sttmDataLineagePanel} sx={{ flex: 1, minHeight: 0, minWidth: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <SttmLineageWorkspacePanel />
          </AiaBox>
        ) : null}
        </AiaBox>
      </AiaBox>
      <AiaDialog
        open={sqlParseDialogOpen}
        onClose={() => setSqlParseDialogOpen(false)}
        fullWidth
        maxWidth="md"
      >
        <AiaDialogTitle sx={{ fontWeight: 800 }}>
          Review SQL workspace changes
        </AiaDialogTitle>
        <AiaDialogContent dividers>
          {!sqlParseResult ? (
            <AiaAlert severity="warning">No parsed SQL result is available.</AiaAlert>
          ) : (
            <AiaStack spacing={2}>
              <AiaAlert severity={sqlParseResult.valid ? 'info' : 'error'}>
                {sqlParseResult.valid
                  ? 'The SQL resolved successfully. Applying it will update the complete mapping workspace in one operation.'
                  : 'The SQL cannot be applied until every ambiguous or unresolved reference is corrected.'}
              </AiaAlert>
              {sqlParseResult.unresolved_references.length ? (
                <AiaBox>
                  <AiaText sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Unresolved references</AiaText>
                  {sqlParseResult.unresolved_references.map((reference) => (
                    <AiaText key={reference} sx={{ mt: 0.5, fontSize: '0.78rem', color: '#b91c1c', overflowWrap: 'anywhere' }}>
                      {reference}
                    </AiaText>
                  ))}
                </AiaBox>
              ) : null}
              {Object.keys(sqlParseResult.ambiguous_references).length ? (
                <AiaBox>
                  <AiaText sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Ambiguous references</AiaText>
                  {Object.entries(sqlParseResult.ambiguous_references).map(([reference, candidates]) => (
                    <AiaText key={reference} sx={{ mt: 0.5, fontSize: '0.78rem', color: '#b91c1c', overflowWrap: 'anywhere' }}>
                      {reference}: {candidates.join(', ')}
                    </AiaText>
                  ))}
                </AiaBox>
              ) : null}
              {sqlParseResult.warnings.length ? (
                <AiaBox>
                  <AiaText sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Warnings</AiaText>
                  {sqlParseResult.warnings.map((warning) => (
                    <AiaText key={warning} sx={{ mt: 0.5, fontSize: '0.78rem', color: '#92400e' }}>
                      {warning}
                    </AiaText>
                  ))}
                </AiaBox>
              ) : null}
              <AiaBox
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))' },
                  gap: 1.25,
                }}
              >
                {Object.entries(sqlParseResult.diff).map(([category, changes]) => (
                  <AiaPaper key={category} variant="outlined" sx={{ p: 1.5, borderRadius: 2, minWidth: 0 }}>
                    <AiaText sx={{ fontSize: '0.76rem', fontWeight: 800, textTransform: 'capitalize' }}>
                      {category.replaceAll('_', ' ')}
                    </AiaText>
                    <AiaText sx={{ mt: 0.35, fontSize: '0.74rem', color: '#64748b' }}>
                      {changes.length} change{changes.length === 1 ? '' : 's'}
                    </AiaText>
                    {changes.slice(0, 4).map((change, index) => (
                      <AiaText key={`${category}-${index}`} sx={{ mt: 0.5, fontSize: '0.72rem', overflowWrap: 'anywhere' }}>
                        {typeof change === 'string' ? change : JSON.stringify(change)}
                      </AiaText>
                    ))}
                  </AiaPaper>
                ))}
              </AiaBox>
            </AiaStack>
          )}
        </AiaDialogContent>
        <AiaDialogActions sx={{ px: 3, py: 2 }}>
          <AiaButton onClick={() => setSqlParseDialogOpen(false)}>Cancel</AiaButton>
          <AiaButton
            variant="contained"
            disabled={!sqlParseResult?.valid}
            onClick={handleApplyParsedSql}
          >
            Apply workspace changes
          </AiaButton>
        </AiaDialogActions>
      </AiaDialog>
      <AiaDialog
        open={reviewDialogOpen}
        onClose={() => setReviewDialogOpen(false)}
        fullWidth
        maxWidth="lg"
        slotProps={{
          paper: {
            sx: {
              borderRadius: 3,
              maxHeight: '90vh',
            },
          },
        }}
      >
        <AiaDialogTitle sx={{ fontWeight: 800 }}>
          {reviewResult?.review_kind === 'repair' ? 'Review suggested SQL repair' : 'Review optimized SQL'}
        </AiaDialogTitle>
        <AiaDialogContent dividers sx={{ overflowY: 'auto', minHeight: 240, p: 0 }}>
          {reviewResult ? (
            <AiaBox sx={{ display: 'grid', gap: 2, p: 3 }}>
              <AiaAlert severity="info" sx={{ borderRadius: 2 }}>
                <AiaText sx={{ fontSize: '0.82rem', whiteSpace: 'pre-line' }}>
                  {reviewResult.review_summary}
                </AiaText>
              </AiaAlert>
              {reviewResult.warnings?.length ? (
                <AiaAlert severity="warning" sx={{ borderRadius: 2 }}>
                  <AiaText sx={{ fontSize: '0.8rem', whiteSpace: 'pre-line' }}>
                    {reviewResult.warnings.join(' ')}
                  </AiaText>
                </AiaAlert>
              ) : null}
              {reviewDiffDocument?.lines.length ? (
                <AiaPaper
                  variant="outlined"
                sx={{
                    borderRadius: 2,
                    overflow: 'hidden',
                  display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  <AiaBox sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                    <AiaBox sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap' }}>
                      <AiaText sx={{ fontSize: '0.82rem', fontWeight: 800 }}>{reviewDiffDocument.title}</AiaText>
                      <AiaBox sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
                        <AiaText sx={{ fontSize: '0.74rem', fontWeight: 700, color: '#b91c1c' }}>
                          - {reviewDiffSummary.removals} removal{reviewDiffSummary.removals === 1 ? '' : 's'}
                        </AiaText>
                        <AiaText sx={{ fontSize: '0.74rem', fontWeight: 700, color: '#15803d' }}>
                          + {reviewDiffSummary.additions} addition{reviewDiffSummary.additions === 1 ? '' : 's'}
                        </AiaText>
                      </AiaBox>
                    </AiaBox>
                    <AiaText sx={{ mt: 0.75, fontSize: '0.74rem', color: '#64748b' }}>
                      Green lines are from the suggested {reviewResult.review_kind === 'repair' ? 'repaired' : 'optimized'} version. Red lines are from the current version that would be replaced.
                    </AiaText>
                  </AiaBox>
                  <AiaBox
                  sx={{
                      fontFamily: APP_FONT_FAMILY,
                      fontSize: '0.74rem',
                      overflowY: 'auto',
                      overflowX: 'auto',
                      bgcolor: '#ffffff',
                      maxHeight: '52vh',
                    }}
                  >
                    {reviewDiffDocument.lines.map((row, index) => (
                      <AiaBox
                        key={`diff-${index}`}
                        sx={{
                          display: 'grid',
                          gridTemplateColumns: '32px 1fr',
                          gap: 1,
                          px: 1.5,
                          py: 0.45,
                          bgcolor:
                            row.kind === 'added'
                              ? '#dcfce7'
                              : row.kind === 'removed'
                                ? '#fee2e2'
                                : row.kind === 'separator'
                                  ? '#f8fafc'
                                  : '#ffffff',
                          color:
                            row.kind === 'added'
                              ? '#166534'
                              : row.kind === 'removed'
                                ? '#991b1b'
                                : row.kind === 'separator'
                                  ? '#64748b'
                                  : 'var(--aia-text-color)',
                          borderBottom:
                            row.kind === 'added'
                              ? '1px solid #86efac'
                              : row.kind === 'removed'
                                ? '1px solid #fca5a5'
                                : '1px solid #f3f4f6',
                          whiteSpace: 'pre',
                        }}
                      >
                        <AiaText component="span" sx={{ fontFamily: 'inherit', fontSize: 'inherit', fontWeight: 800, color: 'inherit', textAlign: 'center' }}>
                          {row.kind === 'added'
                            ? '+'
                            : row.kind === 'removed'
                              ? '-'
                              : row.kind === 'separator'
                                ? '⋯'
                                : ' '}
                        </AiaText>
                        <AiaText component="span" sx={{ fontFamily: 'inherit', fontSize: 'inherit', color: 'inherit', fontStyle: row.kind === 'separator' ? 'italic' : 'normal' }}>
                          {row.text || ' '}
                        </AiaText>
                      </AiaBox>
                    ))}
                  </AiaBox>
                </AiaPaper>
              ) : null}
              <AiaBox sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
                <AiaPaper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                  <AiaBox sx={{ px: 2, py: 1.1, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                    <AiaText sx={{ fontSize: '0.8rem', fontWeight: 800 }}>
                      Original SQL
                    </AiaText>
                  </AiaBox>
                  <AiaBox sx={{ fontFamily: APP_FONT_FAMILY, fontSize: '0.72rem', maxHeight: '32vh', overflow: 'auto', bgcolor: '#fff' }}>
                    {formatSqlForDisplay(reviewResult.original_preview_sql || '').split('\n').map((line, index) => (
                      <AiaBox key={`original-sql-${index}`} sx={{ px: 1.5, py: 0.42, borderBottom: '1px solid #f3f4f6', whiteSpace: 'pre', color: "var(--aia-text-color)" }}>
                        {line || ' '}
                      </AiaBox>
                    ))}
                  </AiaBox>
                </AiaPaper>
                <AiaPaper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                  <AiaBox sx={{ px: 2, py: 1.1, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                    <AiaText sx={{ fontSize: '0.8rem', fontWeight: 800 }}>
                      {reviewResult.review_kind === 'repair' ? 'Suggested repaired SQL' : 'Optimized SQL'}
                    </AiaText>
                  </AiaBox>
                  <AiaBox sx={{ fontFamily: APP_FONT_FAMILY, fontSize: '0.72rem', maxHeight: '32vh', overflow: 'auto', bgcolor: '#fff' }}>
                    {formatSqlForDisplay(reviewResult.optimized_preview_sql || '').split('\n').map((line, index) => (
                      <AiaBox key={`optimized-sql-${index}`} sx={{ px: 1.5, py: 0.42, borderBottom: '1px solid #f3f4f6', whiteSpace: 'pre', color: "var(--aia-text-color)" }}>
                        {line || ' '}
                      </AiaBox>
                    ))}
                  </AiaBox>
                </AiaPaper>
              </AiaBox>
            </AiaBox>
        ) : null}
          {!reviewResult ? (
            <AiaBox sx={{ p: 3 }}>
              <AiaAlert severity="warning" sx={{ borderRadius: 2 }}>
                <AiaText sx={{ fontSize: '0.8rem', lineHeight: 1.5 }}>
                  The SQL review changed before the dialog finished rendering. Please validate SQL again to review the latest version.
                </AiaText>
              </AiaAlert>
            </AiaBox>
        ) : null}
        </AiaDialogContent>
        <AiaDialogActions sx={{ px: 3, py: 2 }}>
          <AiaButton onClick={() => setReviewDialogOpen(false)} sx={{ textTransform: 'none', fontWeight: 700 }}>
            Cancel
          </AiaButton>
          <AiaButton
            variant="outlined"
            onClick={() => {
              void handleApproveReviewedSql('original');
            }}
            disabled={reviewSelectionVariant === 'original'}
            sx={{ textTransform: 'none', fontWeight: 700 }}
          >
            {reviewSelectionVariant === 'original' ? 'Original selected' : 'Keep original and run preview'}
          </AiaButton>
          <AiaButton
            variant="contained"
            onClick={() => {
              void handleApproveReviewedSql('optimized');
            }}
            disabled={reviewSelectionVariant === 'optimized'}
            sx={{ textTransform: 'none', fontWeight: 700 }}
          >
            {reviewSelectionVariant === 'optimized'
              ? reviewResult?.review_kind === 'repair' ? 'Suggested repair applied' : 'Optimized SQL applied'
              : reviewResult?.review_kind === 'repair' ? 'Use suggested repair' : 'Use optimized and run preview'}
          </AiaButton>
        </AiaDialogActions>
      </AiaDialog>
      <PreProcessModal />
      <SttmNoticeDialog
        open={sqlFailureNotice !== null}
        tone="error"
        title={sqlFailureNotice?.title ?? ''}
        message={
          sqlFailureNotice
            ? `${sqlFailureNotice.message}\n\nThis mapping can't be published until Compile & Validate succeeds.`
            : ''
        }
        onClose={() => setSqlFailureNotice(null)}
      />
    </div>
  );
}
