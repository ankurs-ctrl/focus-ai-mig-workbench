"""Dependency proposals copied from retrieved, trusted FIR; never model-authored joins."""
from copy import deepcopy
import hashlib
import json

from app.schema.sttm_builder import MappingDependencyProposal, MappingSuggestion
from app.core.mapping_contracts import column_identity


def dependency_suggestions(target, store):
    if store is None:
        return []
    from app.core.automap_retrieval import target_name
    target = target_name(target)
    categories = store.evidence.get(target, {})
    available = getattr(store, 'available_evidence', {}).get(target, {})
    records = [record for group in (categories, available) for key, values in group.items()
               if 'target_mapping_patterns' in key for record in values]

    def expand(value):
        if isinstance(value, dict):
            handle = value.get('exact_dependency_id')
            if handle:
                return deepcopy(store.historical_dependencies.get(handle))
            return {key: expand(item) for key, item in value.items()}
        return [expand(item) for item in value] if isinstance(value, list) else deepcopy(value)

    results, seen = [], set()
    for raw in records:
        record = expand(raw)
        if not isinstance(record, dict):
            continue
        pattern = record.get('pattern') or record
        if not isinstance(pattern, dict):
            continue
        identifier = pattern.get('pattern_id')
        if (not identifier or identifier in seen or pattern.get('superseded_by')
                or pattern.get('validation_status') not in {'published', 'validated', 'accepted'}):
            continue
        contract = pattern.get('target_contract') or {}
        if column_identity(contract.get('target_column')) != column_identity(target):
            continue
        missing = record.get('missing_dependencies') or []
        ctes = pattern.get('derived_dependencies') or []
        joins = pattern.get('relationship_dependencies') or []
        if not (record.get('decision') == 'unresolved' and (ctes or joins)
                and any(str(item).startswith(('derived_output:', 'relationship:')) for item in missing)):
            continue
        # Use complete retrieved records. Missing SQL stays missing, not an invented recipe.
        ctes = [item for item in ctes if isinstance(item, dict)] if isinstance(ctes, list) else []
        joins = [item for item in joins if isinstance(item, dict)] if isinstance(joins, list) else []
        recipe = pattern.get('mapping_recipe') or {}
        provenance = pattern.get('provenance') or {}
        proposal = MappingDependencyProposal(target_columns=[target], evidence_ids=[str(identifier)],
            publication_version_id=provenance.get('publication_version_id'), ctes=ctes, joins=joins,
            transformation=recipe.get('expression'), population=pattern.get('query_shaping_dependencies'))
        identity = hashlib.sha256(json.dumps(proposal.model_dump(mode='json'), sort_keys=True).encode()).hexdigest()[:24]
        names = ', '.join(str(item.get('name') or item.get('alias') or 'CTE') for item in ctes)
        message = (f'A previous mapping for {target} requires ' + (names or 'an additional relationship')
                   + '. Review the published dependency and its filters before adding it, then rerun this target.')
        results.append(MappingSuggestion(suggestion_id=identity, kind='cte' if ctes else 'relationship',
            message=message, source_references=recipe.get('logical_source_dependencies') or recipe.get('source_dependencies') or [],
            dependency_proposal=proposal))
        seen.add(identifier)
    return results
