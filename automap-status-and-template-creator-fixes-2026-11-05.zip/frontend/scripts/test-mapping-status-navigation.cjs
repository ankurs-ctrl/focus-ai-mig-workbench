const assert=require('node:assert/strict');
const test=require('node:test');
const fs=require('node:fs');const path=require('node:path');const ts=require('typescript');const Module=require('node:module');
const root=path.resolve(__dirname,'../src');const cache=new Map();
const mocks={};
let compileResult=async()=>({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});
function load(file){
 if(cache.has(file))return cache.get(file).exports;
 const loaded=new Module(file,module);cache.set(file,loaded);
 loaded.require=request=>{
  if(request==='@/api/axiosInstance')return {getApiErrorMessage:(error,fallback)=>error.message||fallback};
  if(request==='@/services/dbService')return {dbService:{compileMappingSql:payload=>compileResult(payload)}};
  if(request==='@/services/projectService')return {listProjectAttributes:async()=>[]};
  if(request.startsWith('@/services/')){
   if(!mocks[request])mocks[request]=new Proxy({},{get:(_target,key)=> key==='then'?undefined:(...args)=>{const fn=mocks[`${request}:${String(key)}`];return fn?fn(...args):{};}});
   return mocks[request];
  }
  if(request.startsWith('@/')||request.startsWith('.')){
   let target=request.startsWith('@/')?path.join(root,request.slice(2)):path.resolve(path.dirname(file),request);
   if(!path.extname(target))target+='.ts';return load(target);
  }
  return require(request);
 };
 loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);
 return loaded.exports;
}
const slice=load(path.join(root,'features/sttm/store/sttm-builder-slice.ts'));
const validation=load(path.join(root,'features/sttm/shared/row-validation-state.ts'));
const context=load(path.join(root,'features/sttm/shared/validation-context.ts'));
const review=load(path.join(root,'features/sttm/mapping/mapping-review-model.ts'));
const {configureStore}=require('@reduxjs/toolkit');
const table=(id,name=id)=>({tableId:id,tableName:name,qualifiedName:`D.S.${name}`,isSelected:true,tag:'Source',rows:'1',columns:1,columnItems:[{name:'NAME',type:'VARCHAR'}]});
const row=()=>({id:'name',targetColumn:'NAME',targetType:'VARCHAR',sourceColumn:'src.NAME',sourceColumns:['src.NAME'],mappingMode:'source',rule:'Direct',expression:null,status:'MAPPED'});
const option=(id='selected',ref='src.NAME')=>({candidate_id:id,source_attributes:[ref],source_dependencies:[],mapping_mode:'source',preprocessing_rule_type:'Direct',confidence_score:.8,confidence_reason:'Corresponding name',validation_status:'valid',validation_errors:[],warnings:[],value_binding_ids:[]});
function state(rows=[row()]){
 const state=structuredClone(slice.default(undefined,{type:'@@init'}));
 Object.assign(state,{activeProjectId:'project',activeSttmId:'mapping',sources:[table('source')],targets:[table('target','TARGET')],drivingTableId:'source',mappings:rows});
 for(const row of rows)if(row.status==='MAPPED')row.validation=validation.validatedRow(row,context.selectionValidationSignature(state));
 return state;
}
function store(initial=state()) {return configureStore({reducer:{sttmBuilder:slice.default},preloadedState:{sttmBuilder:initial},middleware:get=>get({serializableCheck:false,immutableCheck:false})});}
function normalize(initial){return slice.default(initial,slice.setValidationValuesSignature({projectId:'other',signature:'ignored'}));}

test('the actual slice keeps validated applied rows mapped despite AI review flags, confidence and guidance',()=>{
 const initial=state();const current=initial.mappings[0];Object.assign(current,{selectedAiCandidateId:'selected',aiReviewStatus:'unreviewed',confidenceScore:.1,aiCandidates:[option()],aiSuggestions:[{suggestion_id:'coverage',kind:'source_data',message:'Check coverage',source_references:[]}]});
 const result=normalize(initial);assert.equal(result.mappings[0].status,'MAPPED');
 assert.equal(result.mappings[0].aiReviewStatus,'unreviewed');
 const sum=load(path.join(root,'features/sttm/mapping/mapping-review-summary.ts')).mappingReviewSummary(result.mappings,{},result.sources,[],result.activeSttmId);
 assert.match(sum,/Currently validated mappings:\*\* 1/);assert.match(sum,/Rows still unresolved:\*\* 0/);
});
test('source visibility, a saved manual flag, and stale MAPPED labels cannot certify incomplete or unvalidated definitions',()=>{
 const initial=state([{...row(),status:'UNMAPPED',manuallySaved:true},{...row(),id:'custom',rule:'Custom',expression:null,status:'UNMAPPED'},{...row(),id:'value',sourceColumn:null,sourceColumns:[],mappingMode:'attribute',attributeName:'FIRM',status:'UNMAPPED'},{...row(),id:'blank',sourceColumn:null,sourceColumns:[],rule:'Direct',status:'UNMAPPED'}]);
 assert.deepEqual(normalize(initial).mappings.map(row=>row.status),['NEEDS_VALIDATION','NEEDS_VALIDATION','NEEDS_VALIDATION','UNMAPPED']);
});
test('a failed alternative never invalidates the currently validated definition or destroys its undo',()=>{
 const initial=state();const current=initial.mappings[0];Object.assign(current,{selectedAiCandidateId:'selected',aiReviewStatus:'unreviewed',aiCandidates:[option(),option('alternative','src.OTHER')],aiUndoSnapshot:{...row(),sourceColumn:'src.OLD',sourceColumns:['src.OLD']}});
 const expected=structuredClone(current.validation);const history=structuredClone(current.aiUndoSnapshot);
 const result=slice.default(initial,slice.sheetCandidateInvalidated({mappingId:'name',candidateId:'alternative',signature:slice.autoMapInputSignature? slice.autoMapInputSignature(current):JSON.stringify([current.id,current.targetColumn,current.targetType,current.targetOrdinal,current.sourceColumn,current.sourceType,current.sourceColumns,current.mappingMode,current.constantValue,current.attributeName,current.expression,current.rule,current.nlRule,current.loadOrder,current.description,current.descriptionEdited,current.sourceDependencies,current.valueBindingIds]),shared:slice.autoMapSharedInputs(initial),reason:'Missing join'}));
 assert.equal(result.mappings[0].status,'MAPPED');assert.deepEqual(result.mappings[0].validation,expected);assert.deepEqual(result.mappings[0].aiUndoSnapshot,history);
 assert.equal(result.mappings[0].aiCandidates[1].validation_status,'invalid');
});
test('confirmed current blocking errors have their own status; editing makes that failed proof stale',()=>{
 const initial=state();initial.mappings[0].validation=validation.validatedRow(initial.mappings[0],context.selectionValidationSignature(initial),'failed','Column not found');
 assert.equal(normalize(initial).mappings[0].status,'VALIDATION_FAILED');
 const changed=slice.default(initial,slice.updateMapping({id:'name',updates:{sourceColumn:'src.FIXED',sourceColumns:['src.FIXED']}}));
 assert.equal(changed.mappings[0].status,'NEEDS_VALIDATION');
});
test('validation is unaffected by viewing recommendations and survives browser draft hydration',()=>{
 const initial=state();const signature=context.selectionValidationSignature(initial);
 initial.sourceValidation={contextSignature:signature,previewKey:'preview',valid:true,synced:true};
 initial.mappings[0].aiUndoSnapshot={...row(),sourceColumn:'src.OLD',sourceColumns:['src.OLD']};
 const hydrated=slice.default(undefined,slice.hydrateBuilderSession(initial));
 assert.deepEqual(hydrated.sourceValidation,initial.sourceValidation);assert.equal(context.selectionValidationSignature(hydrated),signature);
 assert.equal(hydrated.mappings[0].status,'MAPPED');assert.deepEqual(hydrated.mappings[0].aiUndoSnapshot,initial.mappings[0].aiUndoSnapshot);
});
test('every executable selection dependency changes the signature, while cancellation restores eligibility',()=>{
 const initial=state();const before=context.selectionValidationSignature(initial);const changes=[
 s=>s.sourceQuerySql='SELECT changed',s=>s.sources.push(table('other')),s=>s.targets[0].qualifiedName='D.S.OTHER',s=>s.drivingTableId='other',
 s=>s.relationships.push({id:'join',leftTableId:'source',rightTableId:'other',joinType:'LEFT',conditions:[{leftColumn:'ID',operator:'=',rightColumn:'ID'}]}),
 s=>s.sourceFilterSql='ID > 1',s=>s.sourceGroupBySql='ID',s=>s.sourceOrderBySql='ID',s=>s.sourceQueryModifiers={distinct:'DISTINCT'},
 s=>s.derivedSources.push({id:'cte',sourceName:'cte',isSelected:true,sqlText:'SELECT 1',joins:[],filters:[],columns:[]}),s=>s.validationValuesSignature='new-values',
 ];
 for(const change of changes){const changed=structuredClone(initial);change(changed);assert.notEqual(context.selectionValidationSignature(changed),before);assert.equal(normalize(changed).mappings[0].status,'NEEDS_VALIDATION');assert.equal(context.selectionValidationSignature(initial),before);}
 const viewed=structuredClone(initial);viewed.mappings[0].aiReviewStatus='confirmed';viewed.selectedMappingIds=['name'];viewed.sources[0].rows='99';assert.equal(context.selectionValidationSignature(viewed),before);
 const edited=slice.default(initial,slice.updateMapping({id:'name',updates:{sourceColumns:['src.EDIT'],sourceColumn:'src.EDIT'}}));
 const canceled=slice.default(edited,slice.cancelPendingManualMappingEdits());assert.equal(canceled.mappings[0].status,'MAPPED');
});
test('selection validation responses for an old revision cannot enable Next',()=>{
 const initial=state();const old=context.selectionValidationSignature(initial);initial.sourceFilterSql='ID > 1';
 const result=slice.default(initial,slice.setSourceValidation({contextSignature:old,previewKey:'old',valid:true,synced:true}));assert.equal(result.sourceValidation,null);
 const current=context.selectionValidationSignature(initial);const valid=slice.default(result,slice.setSourceValidation({contextSignature:current,previewKey:'new',valid:true,synced:true}));assert.equal(valid.sourceValidation.contextSignature,current);
 const failed=slice.default(valid,slice.setSourceValidation({contextSignature:current,previewKey:'new',valid:false,synced:false}));assert.equal(failed.sourceValidation.valid,false);
});
test('saving the reviewed join is the first source mutation and updates one shared recommendation status',()=>{
 const initial=state();const lookup={...table('lookup'),isSelected:false};initial.sources.push(lookup);
 initial.sourceQuerySql='SELECT authored';initial.sourceFilterSql='ID > 0';initial.pendingManualEditSnapshots={name:{...initial.mappings[0]}};
 initial.mappings[0].aiSuggestions=[{suggestion_id:'join-1',kind:'relationship',message:'Requires lookup',source_references:[]}];
 const before=structuredClone(initial);const result=slice.default(initial,slice.saveReviewedJoin({id:'reviewed',leftTableId:'source',rightTableId:'lookup',joinType:'LEFT',conditions:[{leftColumn:'ID',operator:'=',rightColumn:'ID'}],recommendationId:'join-1'}));
 assert.equal(before.sources[1].isSelected,false);assert.equal(before.relationships.length,0);
 assert.equal(result.sources[1].isSelected,true);assert.equal(result.relationships.length,1);assert.equal(result.mappings[0].aiSuggestions[0].recommendation_status,'saved');
 assert.equal(result.mappings[0].status,'NEEDS_VALIDATION');assert.equal(result.drivingTableId,before.drivingTableId);assert.equal(result.sourceQuerySql,before.sourceQuerySql);assert.equal(result.sourceFilterSql,before.sourceFilterSql);assert.deepEqual(result.pendingManualEditSnapshots,before.pendingManualEditSnapshots);
});
test('undo is offered only for a distinct recoverable previous definition',()=>{
 const current=row();assert.equal(validation.recoverableAiUndo({...current,aiUndoSnapshot:{sourceColumns:[],sourceColumn:null}}),false);
 assert.equal(validation.recoverableAiUndo({...current,aiUndoSnapshot:{...current,confidenceScore:.99}}),false);
 assert.equal(validation.recoverableAiUndo({...current,aiUndoSnapshot:{...current,sourceColumns:['src.OLD']}}),true);
});
module.exports={load,slice,state,store,validation,context};

test('a retained AI definition keeps current validation when a new sheet run has only invalid alternatives',()=>{
 const initial=state();initial.targetAttributeGroup={qualifiedName:'D.S.TARGET',columns:[{name:'NAME'}]};
 Object.assign(initial.mappings[0],{selectedAiCandidateId:'selected',aiReviewStatus:'unreviewed',aiCandidates:[option()]});
 const proof=structuredClone(initial.mappings[0].validation);
 let next=slice.default(initial,slice.runAutoMap.pending('run',undefined));
 next=slice.default(next,({type:'sttmBuilder/autoMapBatchApplied',payload:{requestId:'run',completedMappingIds:['name'],processedCount:1,totalCount:1,response:{operation:'sttm.auto_map',meta:{automap_sheet_candidates_v1:true},result:{mappings:{NAME:{candidates:[{...option('bad','src.MISSING'),validation_status:'invalid',validation_errors:['Column unavailable']}],suggestions:[{suggestion_id:'business',kind:'business_rule',message:'Review policy',source_references:[]}]}}}}}}));
 assert.equal(next.mappings[0].status,'MAPPED');assert.equal(next.mappings[0].sourceColumn,initial.mappings[0].sourceColumn);assert.deepEqual(next.mappings[0].validation,proof);
});
test('the real row validation thunk validates a manual current definition without creating an AI candidate or changing its provenance',async()=>{
 const currentStore=store();const history={...row(),sourceColumn:'src.OLD',sourceColumns:['src.OLD']};
 currentStore.dispatch(slice.updateMapping({id:'name',updates:{sourceColumn:'src.EDIT',sourceColumns:['src.EDIT'],aiUndoSnapshot:history}}));
 const before=currentStore.getState().sttmBuilder.mappings[0];assert.equal(before.status,'NEEDS_VALIDATION');
 compileResult=async payload=>{assert.equal(payload.validate_with_explain,true);assert.deepEqual(payload.mappings[0].source_columns,['src.EDIT']);return {valid:true,ready:true,unresolved_placeholders:[],warnings:[]};};
 await currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true})).unwrap();
 const after=currentStore.getState().sttmBuilder.mappings[0];assert.equal(after.status,'MAPPED');assert.equal(after.selectedAiCandidateId,undefined);assert.equal(after.aiCandidates,undefined);assert.deepEqual(after.aiUndoSnapshot,history);
});
test('a late row validation response cannot certify the newer edited definition',async()=>{
 const currentStore=store();currentStore.dispatch(slice.updateMapping({id:'name',updates:{sourceColumn:'src.ONE',sourceColumns:['src.ONE']}}));
 let finish;compileResult=()=>new Promise(resolve=>{finish=resolve;});
 const request=currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true}));
 await new Promise(resolve=>setImmediate(resolve));
 currentStore.dispatch(slice.updateMapping({id:'name',updates:{sourceColumn:'src.TWO',sourceColumns:['src.TWO']}}));
 finish({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});await assert.rejects(request.unwrap(),error=>/inputs changed/.test(error.message));
 const after=currentStore.getState().sttmBuilder.mappings[0];assert.equal(after.sourceColumn,'src.TWO');assert.equal(after.status,'NEEDS_VALIDATION');
});
test('source validation and row proofs survive canonical backend snapshot serialization',()=>{
 const initial=state();initial.validationValuesSignature='authoritative-values';
 const signature=context.selectionValidationSignature(initial);initial.sourceValidation={contextSignature:signature,previewKey:'preview',valid:true,synced:true};
 initial.mappings[0].validation=validation.validatedRow(initial.mappings[0],signature);
 const snapshot=slice.snapshotFromState(initial,'manual.save');
 assert.equal(snapshot.validation_values_signature,'authoritative-values');assert.deepEqual(context.readSourceValidation(snapshot.validation_history),initial.sourceValidation);assert.deepEqual(snapshot.mapping_rows[0].validation,initial.mappings[0].validation);
});

function expression(source,name){let found;function visit(node){if(ts.isVariableDeclaration(node)&&node.name.getText(source)===name)found=node.initializer;ts.forEachChild(node,visit);}visit(source);assert.ok(found,name);return found.getText(source);}
function evaluate(source,bindings){const module={exports:{}};const js=ts.transpileModule('module.exports = '+source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;new Function('module',...Object.keys(bindings),js)(module,...Object.values(bindings));return module.exports;}
const flowFile=path.join(root,'features/sttm/source-target/table-relationship-flow.tsx');
const flow=ts.createSourceFile(flowFile,fs.readFileSync(flowFile,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const navigation=load(path.join(root,'features/sttm/mapping/review-navigation.ts'));
function joinCallbacks(initial){
 let modal;function visit(node){if((ts.isJsxSelfClosingElement(node)||ts.isJsxOpeningElement(node))&&node.tagName.getText(flow)==='JoinModal')modal=node;ts.forEachChild(node,visit);}visit(flow);assert.ok(modal);
 const calls=[];const saved={current:null};const session=new Map();const intent={id:'intent',suggestionId:'join-1',mappingId:'name',base:'/sttm/builder/mapping'};
 const bindings={rowJoinIntent:intent,savedRowJoinIntent:saved,setIsJoinModalOpen:()=>{},setEditingJoin:()=>{},setJoinState:()=>{throw new Error('Legacy SQL-mutating save must not run');},saveReviewedJoin:join=>calls.push(['save',join]),refreshAssistantSignals:()=>{},reviewRouter:{push:url=>calls.push(['navigate',url])},rowReviewUrl:navigation.rowReviewUrl,JOIN_REVIEW_KEY:navigation.JOIN_REVIEW_KEY,window:{setTimeout:()=>{},sessionStorage:{setItem:(key,value)=>session.set(key,value),removeItem:key=>session.delete(key)}}};
 const callback=name=>evaluate(modal.attributes.properties.find(item=>item.name?.text===name).initializer.expression.getText(flow),bindings);
 return{close:callback('onClose'),confirm:callback('onConfirm'),calls,session,saved};
}
test('canceling the actual join editor writes no sources, relationships or mapping and returns to the row',()=>{
 const callbacks=joinCallbacks(state());callbacks.close();assert.deepEqual(callbacks.calls,[['navigate','/sttm/builder/mapping/mapping?reviewRow=name&reviewSection=suggestions']]);assert.equal(callbacks.saved.current,null);
});
test('the join editor Save followed by its normal Close retains saved navigation and offers reevaluation',()=>{
 const callbacks=joinCallbacks(state());const join={id:'j',leftTableId:'source',rightTableId:'lookup',joinType:'LEFT',conditions:[{leftColumn:'ID',operator:'=',rightColumn:'ID'}]};
 callbacks.confirm(join);callbacks.close();assert.equal(callbacks.calls.filter(item=>item[0]==='save').length,1);assert.equal(callbacks.calls.filter(item=>item[0]==='navigate').length,1);
 assert.match(callbacks.calls.at(-1)[1],/joinReviewed=1$/);assert.equal(JSON.parse(callbacks.session.get(navigation.JOIN_REVIEW_KEY)).status,'saved');
});
test('opening the real recommendation hook only stores a scoped navigation intent, without dispatching source selection',()=>{
 const initial=state();initial.sources.push({...table('lookup'),isSelected:false});const before=JSON.stringify(initial);const writes=[];
 const file=path.join(root,'features/sttm/mapping/use-row-join-review.ts');const loaded=new Module(file,module);
 loaded.require=name=>name==='next/navigation'?{useRouter:()=>({push:url=>writes.push(url)})}:name.endsWith('sttm-builder-context')?{useSttmBuilderContext:()=>({...initial,fullData:{sources:[]},selectJoinReviewSources:()=>{throw new Error('Provisional selection was persisted');}})}:navigation;
 loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);
 const previous=global.window;global.window={location:{pathname:'/sttm/builder/mapping/mapping'},sessionStorage:{setItem:(key,value)=>writes.push(JSON.parse(value))}};
 try{loaded.exports.useRowJoinReview()(initial.mappings[0],{suggestion_id:'join-1',kind:'relationship',message:'Use known lookup',join_recommendation:{left_relation_id:'source',right_relation_id:'lookup'}});}finally{global.window=previous;}
 assert.equal(JSON.stringify(initial),before);assert.equal(writes[0].recommendation.right_relation_id,'lookup');assert.equal(writes[1],'/sttm/builder/mapping?joinReview=1');
});
const filterFile=path.join(root,'features/sttm/source-target/filter-conditions.tsx');
const filters=ts.createSourceFile(filterFile,fs.readFileSync(filterFile,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
function selectionValidator(){
 let resolve;const gates=[];const latest={current:'revision'};
 const bindings={validationRevision:'revision',validationSequence:{current:0},latestValidationRevision:latest,setValidatedGateKey:()=>{},requireSyncForNext:true,setSourcePreviewGate:gate=>gates.push(gate),isLoadingProjectAttributes:false,projectAttributesError:null,editablePreviewSql:'SELECT 1',setPreviewValidation:()=>{},setValidatedPreview:()=>{},effectiveSqlCatalog:[],drivingTableId:null,relationships:[],rootGroups:[],setIsValidatingPreview:()=>{},dbService:{validateDerivedSource:()=>new Promise(done=>{resolve=done;})},sourceValidationSignature:'context',previewGateKey:'preview',hasPreviewChanges:false,getApiErrorMessage:error=>error.message};
 const validate=evaluate(expression(filters,'handleValidatePreviewSql'),bindings);return{validate,gates,latest,complete:result=>resolve(result)};
}
test('the real selection validator ignores a late successful response from an older SQL/dependency revision',async()=>{
 const validator=selectionValidator();const request=validator.validate();validator.latest.current='newer-revision';validator.complete({valid:true,preview_rows:[]});assert.equal(await request,false);assert.equal(validator.gates.some(gate=>gate.persist&&gate.validated),false);
});
test('selection validation persists its exact successful revision and stores failures as disabled gates',async()=>{
 for(const valid of [true,false]){const validator=selectionValidator();const request=validator.validate();validator.complete({valid,preview_rows:[]});assert.equal(await request,valid);const receipt=validator.gates.findLast(gate=>gate.persist);assert.deepEqual(receipt,{validated:valid,synced:valid,contextSignature:'context',previewKey:'preview',persist:true});}
});

function effectContaining(source,text){let result;function visit(node){if(ts.isCallExpression(node)&&/^(React\.)?useEffect$/.test(node.expression.getText(source))&&node.arguments[0]?.getText(source).includes(text))result=node.arguments[0].getText(source);ts.forEachChild(node,visit);}visit(source);assert.ok(result,text);return result;}
test('the selection gate restores a saved valid context on navigation and cancel, and rejects changed dependencies or failures',()=>{
 const effect=effectContaining(filters,'const restored');
 const run=changes=>{const gates=[];const keys=[];evaluate(effect,{requireSyncForNext:true,syncApplied:false,sourceValidationSignature:'current',previewGateKey:'preview',isSyncingPreview:false,hasPreviewChanges:false,isLoadingProjectAttributes:false,projectAttributesError:null,sourceValidation:{contextSignature:'current',valid:true,synced:true},validatedGateKey:null,setValidatedGateKey:key=>keys.push(key),setSourcePreviewGate:gate=>gates.push(gate),setSyncApplied:()=>{},...changes})();return{gates,keys};};
 assert.equal(run({}).gates.at(-1).validated,true);
 assert.equal(run({hasPreviewChanges:true}).gates.at(-1).validated,false);
 assert.equal(run({sourceValidationSignature:'edited'}).gates.at(-1).validated,false);
 assert.equal(run({sourceValidation:{contextSignature:'current',valid:false,synced:false}}).gates.at(-1).validated,false);
 assert.equal(run({sourceValidation:null}).gates.at(-1).validated,false);
 assert.equal(run({isLoadingProjectAttributes:true}).gates.at(-1).validated,false);
 assert.equal(run({previewGateKey:'reopened-preview'}).gates.at(-1).validated,true);
 assert.equal(run({}).gates.at(-1).validated,true,'cancel to the original context restores eligibility');
});
test('filter/query hydration effects do not emit persisted edits on mount; user revisions still emit once',()=>{
 const filterEffect=effectContaining(filters,'onChangeRef.current?.');const queryEffect=effectContaining(filters,'onQueryChangeRef.current?.');
 const emittedFilterRevision={current:0},filterEditRevision={current:0},emittedQueryRevision={current:0},queryEditRevision={current:0};const writes=[];
 const bindings={emittedFilterRevision,filterEditRevision,emittedQueryRevision,queryEditRevision,rootGroups:[],generateSQL:()=>'',onChangeRef:{current:()=>writes.push('filters')},onQueryChangeRef:{current:()=>writes.push('query')},groupByItems:[],orderByItems:[],groupBySql:'',orderBySql:''};
 const filter=evaluate(filterEffect,bindings),query=evaluate(queryEffect,bindings);filter();query();assert.deepEqual(writes,[]);
 filterEditRevision.current=1;queryEditRevision.current=1;filter();query();filter();query();assert.deepEqual(writes,['filters','query']);
});

test('backend reopen preserves the exact selection receipt and row status for physical joins and CTE contexts',()=>{
 for(const derived of [false,true,'cte-only']){
  const initial=state();initial.sources=[table('D.S.ACCOUNTS','ACCOUNTS'),table('D.S.LOOKUP','LOOKUP')];initial.targets=[table('D.S.TARGET','TARGET')];initial.drivingTableId='D.S.ACCOUNTS';
  initial.relationships=[{id:'existing',leftTableId:'D.S.ACCOUNTS',rightTableId:'D.S.LOOKUP',joinType:'LEFT',conditions:[{leftColumn:'ID',rightColumn:'ID',operator:'='}]}];
  initial.sourceQuerySql='SELECT * FROM D.S.ACCOUNTS LEFT JOIN D.S.LOOKUP ON ACCOUNTS.ID = LOOKUP.ID';
  if(derived){initial.derivedSources=[{id:'sql-cte:cte',sourceName:'authored_cte',isSelected:true,sqlText:'SELECT NAME FROM D.S.ACCOUNTS',joins:[],filters:[],columns:[{name:'NAME',type:'VARCHAR'}]}];initial.drivingTableId='sql-cte:cte';}
  if(derived==='cte-only'){initial.sources=[];initial.relationships=[];initial.derivedSources[0].sqlText="SELECT 'Name' AS NAME";initial.sourceQuerySql="WITH authored_cte AS (SELECT 'Name' AS NAME) SELECT * FROM authored_cte";}
  const signature=context.selectionValidationSignature(initial);initial.sourceValidation={contextSignature:signature,previewKey:'validated',valid:true,synced:true};initial.mappings[0].validation=validation.validatedRow(initial.mappings[0],signature);
  const snapshot=slice.snapshotFromState(initial,'manual.save');const args={projectId:'project',sttmId:'mapping'};
  let reopened=slice.default(undefined,slice.openSttmFromBackend.pending('open',args));
  reopened=slice.default(reopened,slice.openSttmFromBackend.fulfilled({projectId:'project',sttmId:'mapping',detail:{latest_snapshot:snapshot,sources:[],mapping_rows:snapshot.mapping_rows,sttm:{sttm_name:'Saved mapping',project_id:'project'},project:{project_name:'Project'}}},'open',args));
  assert.equal(context.selectionValidationSignature(reopened),signature,derived?'CTE dependencies':'physical dependencies');assert.deepEqual(reopened.sourceValidation,initial.sourceValidation);assert.equal(reopened.mappings[0].status,'MAPPED');
 }
});

test('a stale selected candidate ID cannot invalidate a different current definition',async()=>{
 const initial=state();Object.assign(initial.mappings[0],{selectedAiCandidateId:'stale',aiCandidates:[option('stale','src.OLD')]});
 const currentStore=store(initial);compileResult=async()=>({valid:false,ready:false,unresolved_placeholders:[],warnings:['Invalid old option']});
 await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'stale'})).unwrap(),error=>/Invalid old option/.test(error.message));
 const result=currentStore.getState().sttmBuilder.mappings[0];assert.equal(result.status,'MAPPED');assert.deepEqual(result.validation,initial.mappings[0].validation);assert.equal(result.aiCandidates[0].validation_status,'invalid');
});

test('validation checks the exact legacy rule definition without silently rewriting executable fields',async()=>{
 const initial=state([{...row(),status:'UNMAPPED',sourceColumn:null,sourceColumns:[],rule:'CURRENT_TIMESTAMP()',expression:null}]);const currentStore=store(initial);
 compileResult=async payload=>{assert.equal(payload.mappings[0].expression,null);assert.equal(payload.mappings[0].rule,'CURRENT_TIMESTAMP()');return {valid:false,ready:false,unresolved_placeholders:[],warnings:['Rule requires an expression']};};
 await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true})).unwrap(),error=>/requires an expression/.test(error.message));
 assert.equal(currentStore.getState().sttmBuilder.mappings[0].status,'VALIDATION_FAILED');assert.equal(currentStore.getState().sttmBuilder.mappings[0].rule,'CURRENT_TIMESTAMP()');
});
