param(
    [string]$EnvFile = "",
    [string]$ImageTag = "",
    [string]$PythonExe = "",
    [string]$SnowflakeCliVersion = "",
    [switch]$ForceRecreateConnection,
    [switch]$SkipConnectionSetup,
    [switch]$SkipPrereqs,
    [switch]$SkipLogin
)

$ErrorActionPreference = "Stop"

# Purpose:
# - convenience wrapper for the entire Windows deployment sequence
# - good for rehearsals or when you want to prove there is a one-command path
# - for live demos, you can still run each individual script one by one

if (-not $EnvFile) {
    $EnvFile = Join-Path $PSScriptRoot "client.streamlit-demo.env"
}

$bootstrapArgs = @{}
if ($PythonExe) {
    $bootstrapArgs["PythonExe"] = $PythonExe
}
if ($SnowflakeCliVersion) {
    $bootstrapArgs["SnowflakeCliVersion"] = $SnowflakeCliVersion
}

& (Join-Path $PSScriptRoot "bootstrap_client_spcs_tools.ps1") @bootstrapArgs

if (-not $SkipConnectionSetup) {
    $connectionArgs = @{
        EnvFile = $EnvFile
    }
    if ($ForceRecreateConnection) {
        $connectionArgs["ForceRecreate"] = $true
    }
    & (Join-Path $PSScriptRoot "configure_client_snow_connection.ps1") @connectionArgs
}

if (-not $SkipPrereqs) {
    & (Join-Path $PSScriptRoot "prepare_spcs_prereqs.ps1") -EnvFile $EnvFile
}

$buildArgs = @{
    EnvFile = $EnvFile
}
if ($ImageTag) {
    $buildArgs["ImageTag"] = $ImageTag
}
if ($SkipLogin) {
    $buildArgs["SkipLogin"] = $true
}
& (Join-Path $PSScriptRoot "build_and_push_demo_image.ps1") @buildArgs

$deployArgs = @{
    EnvFile = $EnvFile
}
if ($ImageTag) {
    $deployArgs["ImageTag"] = $ImageTag
}
& (Join-Path $PSScriptRoot "deploy_streamlit_demo_service.ps1") @deployArgs
