'use client';
import {useEffect,useState} from 'react';
import {IconButton,Tooltip,Dialog,DialogTitle,DialogContent,DialogActions,Button,Alert} from '@mui/material';
import ArchiveOutlined from '@mui/icons-material/ArchiveOutlined';
import DeleteOutline from '@mui/icons-material/DeleteOutlined';
import {authService} from '@/services/authService';
import {postEnvelopeData,buildApiEnvelope} from '@/api/axiosInstance';
import {invalidateProjectMetadataCache} from '@/services/projectService';

export default function AdminResourceActions({kind,id,name,onRemoved}:{kind:'project'|'mapping';id:string;name:string;onRemoved?:()=>void}) {
 const [admin,setAdmin]=useState(false),[action,setAction]=useState<'archive'|'delete'|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{let live=true;void authService.getSession().then(session=>{if(live)setAdmin(session.app_persona==='ADMIN');}).catch(()=>{});return()=>{live=false;};},[]);
 if(!admin)return null;
 const run=async()=>{setBusy(true);setError('');try{
  await postEnvelopeData(`/v1/admin/resources/${kind}/${encodeURIComponent(id)}/${action}`,buildApiEnvelope('admin.resource.'+action,{}));
  invalidateProjectMetadataCache();setAction(null);if(onRemoved)onRemoved();else window.location.reload();
 }catch(cause){setError(cause instanceof Error?cause.message:'The action failed. Nothing has been removed from this view.');}finally{setBusy(false);}};
 return <span onClick={event=>event.stopPropagation()}>
  <Tooltip title="Archive"><IconButton size="small" aria-label={`Archive ${name}`} onClick={()=>setAction('archive')}><ArchiveOutlined fontSize="small"/></IconButton></Tooltip>
  <Tooltip title="Delete from lists"><IconButton size="small" aria-label={`Delete ${name}`} onClick={()=>setAction('delete')} sx={{color:'#b91c1c'}}><DeleteOutline fontSize="small"/></IconButton></Tooltip>
  <Dialog open={Boolean(action)} onClose={()=>{if(!busy)setAction(null);}} maxWidth="xs" fullWidth>
   <DialogTitle>{action==='delete'?'Delete from lists':'Archive'} {kind}?</DialogTitle>
   <DialogContent><p><strong>{name}</strong> will disappear from project and mapping listings.{kind==='project'?' Its mappings will also be hidden.':''}</p><p>Published history and saved work are retained for administrative recovery. This does not delete Snowflake source or target tables.</p>{error?<Alert severity="error">{error}</Alert>:null}</DialogContent>
   <DialogActions><Button disabled={busy} onClick={()=>setAction(null)}>Cancel</Button><Button color={action==='delete'?'error':'primary'} variant="contained" disabled={busy} onClick={()=>void run()}>{busy?'Saving…':action==='delete'?'Delete from lists':'Archive'}</Button></DialogActions>
  </Dialog>
 </span>;
}
