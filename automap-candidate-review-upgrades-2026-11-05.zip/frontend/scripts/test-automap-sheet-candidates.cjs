const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const h = require('./test-automap-preservation.cjs');
const sheetFile = path.resolve(__dirname, '../src/features/sttm/mapping/sheet-candidates.ts');
const sheet = new Module(sheetFile, module);
sheet._compile(ts.transpileModule(fs.readFileSync(sheetFile, 'utf8'), {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,sheetFile);
const candidate = (id='one', changes={}) => ({candidate_id:id,source_attributes:['src.Name'],source_dependencies:['src.Name'],
  confidence_score:.3,confidence_reason:'Business evidence for '+id,preprocessing_rule_type:'Direct',mapping_mode:'source',
  transformation_classification:'direct',validation_status:'valid',validation_errors:[],warnings:[],value_binding_ids:[],...changes});
function begin(state) { h.reducer(h.pendingReducer)(state,{meta:{requestId:'sheet-run'}}); }
function deliver(state, options, changes={}) {
 h.helpers.applyAutoMapResponseToState(state,h.response({...options[0],candidates:options,...changes}));
}
function findInitializer(ast,name) {
 let result;
 function visit(node) { if(node.initializer && node.name?.getText(ast)===name) result=node.initializer;ts.forEachChild(node,visit); }
 visit(ast);assert.ok(result,name);return result;
}
const dependencies={...h.helpers,...sheet.exports};
const capture=h.compile(h.functions(h.slice,['captureManualEditSnapshot'])+';return captureManualEditSnapshot;',dependencies);
function reducer(name) {return h.compile(`return (${findInitializer(h.slice,name).getText(h.slice)});`,{...dependencies,captureManualEditSnapshot:capture});}
function stateFor(...rows) {return {...h.stateFor(...rows),mappingLoading:false,derivedSources:[],relationships:[],sources:[],sourceQueryModifiers:{}};}
function selectionHarness(state, compile) {
 const writes=[];const sent=[];let values=[{attribute_id:'firm',attribute_name:'FIRM',attribute_value:'approved'}];
 const callback=findInitializer(h.slice,'selectSheetCandidate').arguments[1].getText(h.slice);
 const select=h.compile(`return (${callback});`,{...dependencies,
  listProjectAttributes:async()=>values,
  resolveSelectedSourceTables:()=>[],
  buildRelationGraph:(_s,_d,_j,_m,currentValues)=>({nodes:[],edges:[],value_bindings:currentValues}),
  dbService:{compileMappingSql:async payload=>{sent.push(payload);return compile ? compile(payload) : {valid:true,ready:true,unresolved_placeholders:[],warnings:[]};}},
  sheetCandidateValidated:payload=>({type:'valid',payload}),
  sheetCandidateInvalidated:payload=>({type:'invalid',payload}),
  sheetCandidateRevalidated:payload=>({type:'revalidated',payload}),
 });
 return {sent,writes,setValues:next=>{values=next;},select:options=>select(options,{getState:()=>({sttmBuilder:state}),dispatch:action=>{writes.push(action);reducer(action.type==='invalid'?'sheetCandidateInvalidated':action.type==='revalidated'?'sheetCandidateRevalidated':'sheetCandidateValidated')(state,action);}})};
}

test('Auto-map fills a blank draft with a low-confidence valid choice and no chat queue',()=>{
 const state=stateFor(h.blank());begin(state);
 deliver(state,[candidate('bad',{confidence_score:.99,validation_status:'invalid',validation_errors:['Missing column']}),candidate()]);
 assert.equal(state.mappings[0].sourceColumn,'src.Name');
 assert.equal(state.mappings[0].confidenceScore,.3);
 assert.equal(state.mappings[0].aiReviewStatus,'unreviewed');
 assert.equal(state.mappings[0].selectedAiCandidateId,'one');
 assert.equal(state.mappings[0].status,'MAPPED');
 assert.equal(state.pendingAiMappingReviews.length,0);
 assert.equal(state.mappings[0].aiCandidates[0].validation_status,'invalid');
});

test('complete alternatives preserve every field and do not manufacture missing alternatives',()=>{
 const result=sheet.exports.rankedRowCandidates([candidate('rule',{preprocessing_rule:'TRIM(src.Name)',preprocessing_rule_type:'Custom'}),candidate('value',{source_attributes:[],mapping_mode:'attribute',attribute_name:'FIRM',constant_value:'$FIRM',value_binding_ids:['firm']})]);
 assert.equal(result.length,2);assert.equal(result[0].preprocessing_rule,'TRIM(src.Name)');
 assert.deepEqual(result[1].value_binding_ids,['firm']);assert.equal(result[1].confidence_reason,'Business evidence for value');
 assert.equal(sheet.exports.rankedRowCandidates([candidate()]).length,1);
});

test('human-authored and confirmed definitions remain unchanged while alternatives appear in the row',()=>{
 for(const row of [h.imported(),{...h.imported(),aiReviewStatus:'confirmed'},{...h.imported(),manuallySaved:true}]) {
  const state=stateFor(structuredClone(row));begin(state);deliver(state,[candidate()]);
  for(const field of ['expression','sourceColumn','sourceColumns','rule','mappingMode']) assert.deepEqual(state.mappings[0][field],row[field]);
  assert.equal(state.mappings[0].aiCandidates.length,1);assert.equal(state.pendingAiMappingReviews.length,0);
 }
});

test('unavailable Values and invalid SQL cannot become executable draft mappings',()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate('bad',{validation_status:'invalid',validation_errors:['Missing Value']})]);
 assert.equal(state.mappings[0].status,'UNMAPPED');assert.equal(state.mappings[0].selectedAiCandidateId,null);
 assert.equal(state.mappings[0].sourceColumn,null);
});

test('only checked target rows receive draft suggestions',()=>{
 const state=stateFor(h.blank(),h.blank('OTHER'));state.selectedMappingIds=['NAME'];begin(state);
 deliver(state,[candidate()]);assert.equal(state.mappings[1].aiCandidates,undefined);assert.equal(state.mappings[1].sourceColumn,null);
});

test('switching validates first then atomically changes source, mode, rule and dependencies',async()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate(),candidate('rule',{source_attributes:['src.Other'],source_dependencies:['src.Other'],preprocessing_rule:'TRIM(src.Other)',preprocessing_rule_type:'Custom',transformation_classification:'complex'})]);
 state.mappingLoading=false;state.autoMapRun=null;
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'rule'});
 const row=state.mappings[0];assert.equal(row.sourceColumn,'src.Other');assert.equal(row.rule,'Custom');assert.equal(row.expression,'TRIM(src.Other)');
 assert.deepEqual(row.sourceDependencies,['src.Other']);assert.equal(row.aiReviewStatus,'unreviewed');
 assert.equal(harness.sent[0].validate_with_explain,true);assert.equal(harness.sent[0].allow_unresolved_placeholders,false);
 assert.equal(harness.sent[0].project_id,'project');assert.equal(harness.sent[0].relation_graph.value_bindings[0].attribute_value,'approved');
});

test('validation failure or changed input never applies the candidate',async()=>{
 for(const mode of ['invalid','race']) {
  const state=stateFor({...h.blank(),aiCandidates:[candidate()],aiReviewStatus:null});
  const harness=selectionHarness(state,async()=>{
   if(mode==='race')state.mappings[0].expression='user changed';
   return {valid:mode!=='invalid',ready:true,unresolved_placeholders:[],warnings:['Invalid rule']};
  });
  await assert.rejects(harness.select({mappingId:'NAME',candidateId:'one'}),mode==='invalid'?/Invalid rule/:/changed/);
  assert.equal(harness.writes.length,mode==='invalid'?1:0);assert.equal(state.mappings[0].sourceColumn,null);
  if(mode==='invalid')assert.equal(state.mappings[0].aiCandidates[0].validation_status,'invalid');
 }
});

test('confirmation is validated and undo restores the complete earlier definition',async()=>{
 const row={...h.blank(),aiCandidates:[candidate()]};const state=stateFor(row);
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'one',confirm:true});
 assert.equal(row.aiReviewStatus,'confirmed');assert.equal(row.confidenceScore,.3);assert.equal(row.selectedAiCandidateId,'one');
 reducer('undoSheetSuggestion')(state,{payload:'NAME'});
 assert.equal(row.sourceColumn,null);assert.equal(row.expression,null);assert.equal(row.status,'UNMAPPED');assert.equal(row.aiReviewStatus,null);
 assert.equal(row.aiCandidates.length,1);assert.equal(row.aiUndoSnapshot,null);assert.deepEqual(row.sourceColumns,[]);assert.deepEqual(row.sourceDependencies,[]);assert.equal(row.confidenceScore,null);
});

test('manual edits clear candidate selection and protect the edited definition on another Auto-map',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};const state=stateFor(row);
 reducer('updateMapping')(state,{payload:{id:'NAME',updates:{expression:'UPPER(src.Name)',rule:'Custom'}}});
 assert.equal(row.aiReviewStatus,'edited');assert.equal(row.selectedAiCandidateId,null);
 assert.equal(row.expression,'UPPER(src.Name)');
});

test('candidate details, selection, review and undo survive workspace JSON and reopen recovery',()=>{
 const file=path.resolve(__dirname,'../src/features/sttm/context/workbench-context.ts');
 const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true);
 const mappingRows=findInitializer(ast,'mapping_rows').getText(ast);
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()],aiReviewStatus:'confirmed',aiUndoSnapshot:{sourceColumn:null,status:'UNMAPPED'}};
 const rows=h.compile(`return (${mappingRows});`,{input:{mappings:[row]}});
 const recoveryFile=path.resolve(__dirname,'../src/features/sttm/shared/mapping-row-recovery.ts');
 const recovery=ts.createSourceFile(recoveryFile,fs.readFileSync(recoveryFile,'utf8'),ts.ScriptTarget.Latest,true);
 const recover=h.compile(h.functions(recovery,['savedMappingEvidence'])+';return savedMappingEvidence;');
 const restored=recover(JSON.parse(JSON.stringify(rows[0])));
 assert.deepEqual(restored.aiCandidates,row.aiCandidates);assert.equal(restored.selectedAiCandidateId,'one');
 assert.equal(restored.aiReviewStatus,'confirmed');assert.deepEqual(restored.aiUndoSnapshot,row.aiUndoSnapshot);
});

test('candidate confirmation saves a draft choice without committing another row’s pending manual edits',async()=>{
 const row={...h.blank(),aiCandidates:[candidate()]};const other={...h.blank('OTHER'),expression:'manual draft'};
 const state=stateFor(row,other);state.pendingManualEditSnapshots.OTHER={...other,expression:null};
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'one',confirm:true});
 assert.equal(row.aiReviewStatus,'confirmed');assert.equal(state.pendingManualEditSnapshots.NAME,undefined);
 assert.equal(state.pendingManualEditSnapshots.OTHER.expression,null);assert.equal(other.expression,'manual draft');
 assert.equal(state.autoMapBlockedByManualEdits,true);
});

test('an already selected AI option becomes unresolved if its current Value or SQL validation fails',async()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};
 const state=stateFor(row);
 const harness=selectionHarness(state,async()=>({valid:false,ready:false,unresolved_placeholders:['$FIRM'],warnings:['Value unavailable']}));
 await assert.rejects(harness.select({mappingId:'NAME',candidateId:'one',confirm:true}),/Value unavailable/);
 assert.equal(row.status,'UNMAPPED');assert.equal(row.selectedAiCandidateId,null);assert.equal(row.aiReviewStatus,null);
 assert.equal(row.aiCandidates[0].validation_status,'invalid');assert.equal(row.unmatchedReason,'Value unavailable');
});

test('an invalid replacement does not demote a different valid current choice',async()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate(),candidate('other',{source_attributes:['src.Other']})]};
 const state=stateFor(row);
 const harness=selectionHarness(state,async()=>({valid:false,ready:false,unresolved_placeholders:[],warnings:['Column unavailable']}));
 await assert.rejects(harness.select({mappingId:'NAME',candidateId:'other'}),/Column unavailable/);
 assert.equal(row.status,'MAPPED');assert.equal(row.selectedAiCandidateId,'one');assert.equal(row.sourceColumn,'src.Name');
 assert.equal(row.aiCandidates[1].validation_status,'invalid');
});

test('chat receives only draft suggestion, low-confidence and unresolved counts',()=>{
 const state=stateFor(h.blank(),h.blank('OTHER'));begin(state);deliver(state,[candidate()]);
 h.reducer(h.fulfilledReducer)(state,{meta:{requestId:'sheet-run'},payload:{sheetReviewV1:true,totalCount:2,failedTargets:[],autoMapOutcome:null}});
 assert.equal(state.chatMessages.length,1);
 assert.match(state.chatMessages[0].content,/New draft mappings applied:\*\* 1/);
 assert.match(state.chatMessages[0].content,/Low-confidence draft suggestions:\*\* 1/);
 assert.match(state.chatMessages[0].content,/Rows still unresolved:\*\* 1/);
 assert.equal(state.pendingAiMappingReviews.length,0);
 assert.doesNotMatch(state.chatMessages[0].content,/Apply Changes|accept.*queue/i);
});

const review=h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/mapping-review-model.ts'));
const navigation=h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/review-navigation.ts'));
const physical=(id='D.S.ACCOUNTS',qualified='D.S.ACCOUNTS')=>({tableId:id,qualifiedName:qualified,tableName:'ACCOUNTS',isSelected:true,columnItems:[]});
const aliases=h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/relation-alias.ts'));

test('the current mapping and explanation-only variants are excluded from alternatives',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate(),candidate('duplicate',{confidence_score:.99,confidence_reason:'Another explanation'})]};
 assert.equal(review.alternativeCandidates(row).length,0);
 row.aiCandidates.push(candidate('trim',{preprocessing_rule_type:'Custom',preprocessing_rule:'TRIM(src.Name)'}));
 assert.equal(review.alternativeCandidates(row).length,1);
 assert.equal(review.alternativeCandidates(row)[0].candidate_id,'trim');
});

test('identity comparison resolves exact aliases/FQNs and equivalent built-in expressions, retaining real dependency differences',()=>{
 const source=physical();const catalog=review.reviewCatalog([source],[]);const alias=aliases.relationAliasFor(source.qualifiedName);
 const row={...h.blank(),sourceColumns:[`${alias}.NAME`],sourceColumn:`${alias}.NAME`,rule:'Trim',sourceDependencies:[]};
 const same=candidate('same',{source_attributes:['D.S.ACCOUNTS.NAME'],source_dependencies:['D.S.ACCOUNTS.NAME'],preprocessing_rule_type:'Custom',preprocessing_rule:' TRIM( D.S.ACCOUNTS.NAME ) '});
 assert.equal(review.definitionKey(row,catalog),review.definitionKey(same,catalog));
 const extra={...same,source_dependencies:['D.S.ACCOUNTS.NAME','D.S.ACCOUNTS.PARENT_ID']};
 assert.notEqual(review.definitionKey(row,catalog),review.definitionKey(extra,catalog));
 const upper={...same,preprocessing_rule:'UPPER(TRIM(D.S.ACCOUNTS.NAME))'};
 assert.notEqual(review.definitionKey(row,catalog),review.definitionKey(upper,catalog));
});

test('generated display aliases are metadata-bound and preserve quoted identifiers, authored roles and real hash-like table names',()=>{
 const source=physical();const alias=aliases.relationAliasFor(source.qualifiedName);const catalog=review.reviewCatalog([source],[]);
 assert.equal(catalog.display(`${alias}.NAME`),'ACCOUNTS.NAME');
 assert.equal(catalog.display(`${alias}."Mixed.Name"`),'ACCOUNTS."Mixed.Name"');
 assert.equal(catalog.display(`'${alias}.NAME'`),`'${alias}.NAME'`,'SQL literals remain literal data');
 assert.equal(catalog.display('accounts_NOT_A_REAL_ALIAS.NAME'),'accounts_NOT_A_REAL_ALIAS.NAME');
 const legitimate=physical('D.S.ACCOUNTS_ENUEH8','D.S.ACCOUNTS_ENUEH8');
 assert.equal(review.reviewCatalog([legitimate],[]).display(`${aliases.relationAliasFor(legitimate.qualifiedName)}.NAME`),'ACCOUNTS_ENUEH8.NAME');
 const roles=review.reviewCatalog([physical('sql-instance:upload:Household'),physical('sql-instance:upload:Parent')],[]);
 assert.equal(roles.display('Household.NAME'),'ACCOUNTS (Household).NAME');
 assert.equal(roles.display('Parent.NAME'),'ACCOUNTS (Parent).NAME');
 assert.notEqual(roles.identity('Household.NAME'),roles.identity('Parent.NAME'));
 const cte={id:'sql-cte:upload:Families',sourceName:'Families',isSelected:true};
 assert.equal(review.reviewCatalog([], [cte]).display(`${aliases.relationAliasFor(cte.id,cte.sourceName)}.ID`),'Families.ID');
});

test('same-named tables across databases remain unambiguous and unknown bindings never collapse together',()=>{
 const catalog=review.reviewCatalog([physical('D1.S.ACCOUNTS','D1.S.ACCOUNTS'),physical('D2.S.ACCOUNTS','D2.S.ACCOUNTS')],[]);
 assert.notEqual(catalog.nodes[0].label,catalog.nodes[1].label);
 assert.notEqual(catalog.identity('unknown:one'),catalog.identity('unknown:two'));
});

test('Value comparison uses the approved named placeholder rather than ephemeral row binding IDs',()=>{
 const row={...h.blank(),mappingMode:'attribute',constantValue:'$FIRM',attributeName:'FIRM',rule:'Value',valueBindingIds:['value:old-row']};
 const option=candidate('value',{source_attributes:[],source_dependencies:[],mapping_mode:'attribute',constant_value:'$FIRM',attribute_name:'FIRM',value_binding_ids:['$FIRM'],preprocessing_rule_type:'Value'});
 assert.equal(review.definitionKey(row),review.definitionKey(option));
});

test('empty/prose-only responses become guidance, never invented confidence candidates',()=>{
 const empty=candidate('empty',{source_attributes:[],source_dependencies:[],confidence_score:0,transformation_classification:'unresolved',unmatched_reason:'SI_FIRM is entirely null; consider a lookup.'});
 const row={...h.blank(),aiCandidates:[empty]};
 assert.equal(review.alternativeCandidates(row).length,0);assert.equal(review.guidanceForRow(row).length,1);
 assert.match(review.guidanceForRow(row)[0].message,/entirely null/);
});

test('switching keeps the previous full mapping and confirmation preserves its independent undo point',async()=>{
 const original=candidate('original',{confidence_score:.85,confidence_reason:'Original reason'});
 const next=candidate('next',{source_attributes:['src.Other'],source_dependencies:['src.Other'],confidence_score:.72,confidence_reason:'New reason'});
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(original),aiCandidates:[original,next]};const state=stateFor(row);const harness=selectionHarness(state);
 await harness.select({mappingId:row.id,candidateId:'next'});
 let alternatives=review.alternativeCandidates(row);assert.equal(alternatives.length,1);
 assert.equal(alternatives[0].confidence_score,.85);assert.equal(alternatives[0].confidence_reason,'Original reason');
 assert.equal(alternatives[0].previously_applied,true);assert.deepEqual(alternatives[0].source_dependencies,['src.Name']);
 const undo=structuredClone(row.aiUndoSnapshot);
 await harness.select({mappingId:row.id,candidateId:'next',confirm:true});
 assert.deepEqual(row.aiUndoSnapshot,undo);assert.equal(row.aiReviewStatus,'confirmed');
});

test('a manual previous mapping keeps its expression and has no manufactured score or explanation',async()=>{
 const row={...h.imported(),confidenceScore:null,confidenceReason:null,manuallySaved:true,aiCandidates:[candidate()]};
 const state=stateFor(row);const harness=selectionHarness(state);
 await harness.select({mappingId:row.id,candidateId:'one'});
 const previous=review.alternativeCandidates(row)[0];assert.equal(previous.origin,'manual');
 assert.equal(previous.confidence_score,null);assert.equal(previous.confidence_reason,null);
 assert.equal(previous.preprocessing_rule,h.imported().expression);assert.equal(previous.previously_applied,true);
});

test('revalidation updates option readiness without applying a different definition',async()=>{
 const row={...h.blank(),aiCandidates:[candidate('pending',{validation_status:'unvalidated'})]};const state=stateFor(row);const harness=selectionHarness(state);
 await harness.select({mappingId:row.id,candidateId:'pending',validateOnly:true});
 assert.equal(row.aiCandidates[0].validation_status,'valid');assert.equal(row.sourceColumn,null);assert.equal(row.status,'UNMAPPED');
});

test('row-specific warnings are deduplicated and another target’s warning is excluded',()=>{
 const row={...h.blank(),targetColumn:'ADDRESS'};
 assert.deepEqual(review.relevantWarnings(row,['ADDRESS needs review','ADDRESS needs review','REFERRAL_ID has poor coverage'],['ADDRESS','REFERRAL_ID']),['ADDRESS needs review']);
});

test('review navigation scopes requests and prefills only supplied relationship evidence',()=>{
 const storage={getItem:()=>JSON.stringify({id:'intent',projectId:'p',sttmId:'s',mappingId:'row',targetColumn:'FIRM',purpose:'Known purpose',base:'/sttm/builder/s',status:'pending',recommendation:{left_relation_id:'a',right_relation_id:'b'}})};
 const intent=navigation.readJoinReview(storage,'p','s');assert.ok(intent);assert.equal(navigation.readJoinReview(storage,'other','s'),null);
 const unknown=navigation.joinReviewDraft(intent,['a','b'],[]);assert.equal(unknown.joinType,undefined);assert.deepEqual(unknown.conditions,[]);
 const explicit={...intent,recommendation:{...intent.recommendation,join_type:'LEFT',conditions:[{left_column:'FIRM_ID',right_column:'ID',operator:'='}]}};
 const known=navigation.joinReviewDraft(explicit,['a','b'],[]);assert.equal(known.joinType,'LEFT');assert.equal(known.conditions[0].leftColumn,'FIRM_ID');
 const original={id:'existing',leftTableId:'a',rightTableId:'b',joinType:'INNER',sqlPredicate:'a.ID = b.ID AND b.ACTIVE = 1',conditions:[]};
 assert.deepEqual(navigation.joinReviewDraft(explicit,['a','b'],[original]),original);
 assert.match(navigation.rowReviewUrl('/sttm/builder/s','row / &'),/row%20%2F%20%26/);
});

test('join review source selection and explicit save preserve authored SQL, CTEs, aliases, filters and pending edits',()=>{
 const source=physical();const lookup=physical('D.S.FIRMS','D.S.FIRMS');source.isSelected=true;lookup.isSelected=false;
 const state=stateFor({...h.imported()});state.sourceDatabases=[{schemas:[{tables:[source,lookup]}]}];state.sources=[source];
 Object.assign(state,{drivingTableId:'original-driver',sourceQuerySql:'WITH untouched AS (SELECT 1) SELECT * FROM untouched',mappingSql:'uploaded SQL',rawMappingSql:'raw SQL',derivedSources:[{id:'cte',sqlText:'SELECT 1',isSelected:true}],sourceFilterGroups:[{id:'filter'}],sourceQueryModifiers:{where:'keep'},relationships:[{id:'authored',sqlPredicate:'a.ID=b.ID OR b.ID IS NULL'}],pendingManualEditSnapshots:{NAME:{...state.mappings[0]}},autoMapBlockedByManualEdits:true});
 const protectedKeys=['drivingTableId','sourceQuerySql','mappingSql','rawMappingSql','derivedSources','sourceFilterGroups','sourceQueryModifiers','pendingManualEditSnapshots','mappings'];
 const before=Object.fromEntries(protectedKeys.map(key=>[key,structuredClone(state[key])]));
 reducer('selectJoinReviewSources')(state,{payload:['D.S.FIRMS','invented']});
 assert.equal(state.sources.length,2);assert.equal(state.relationships.length,1);
 reducer('saveReviewedJoin')(state,{payload:{id:'reviewed',leftTableId:'D.S.ACCOUNTS',rightTableId:'D.S.FIRMS',joinType:'LEFT',conditions:[{leftColumn:'FIRM_ID',rightColumn:'ID',operator:'='}]}});
 for(const key of protectedKeys)assert.deepEqual(state[key],before[key],key);
 assert.equal(state.relationships[0].sqlPredicate,'a.ID=b.ID OR b.ID IS NULL');assert.equal(state.relationships.length,2);
});

test('single-row reevaluation preserves the existing checkbox selection',()=>{
 const state=stateFor(h.blank('NAME'),h.blank('OTHER'));state.selectedMappingIds=['OTHER'];
 assert.deepEqual(h.helpers.autoMapScope(state,{action:'complete',mappingIds:['NAME']}).names,['NAME']);
 assert.deepEqual(state.selectedMappingIds,['OTHER']);
});

function renderReviewRow(row,{sourceCell=false,open=null}={}) {
 const React=require('react');const {renderToStaticMarkup}=require('react-dom/server');
 const context={mappings:[row],sources:[],derivedSources:[],mappingLoading:false,activeProjectId:'p',activeSttmId:'s',fullData:{sources:[]},selectSheetCandidate:async()=>{},undoSheetSuggestion:()=>{},updateMapping:()=>{},selectJoinReviewSources:()=>{},runAutoMap:()=>{}};
 let opened=false;
 const reactForTest=open?{...React,useState:initial=>{if(initial===null&&!opened){opened=true;return React.useState(open);}return React.useState(initial);}}:React;
 const dom=(tag)=>({children,component,sx,...props})=>React.createElement(component||tag,Object.fromEntries(Object.entries(props).filter(([key])=>!['onChange','checkHandler','inputSx','enterDelay','arrow','fullWidth','size','variant','placement','options','slotProps','color'].includes(key))),children);
 const Box=dom('div');const Text=dom('span');const Button=dom('button');
 const ui={AiaBox:Box,AiaText:Text,AiaButton:Button,AiaTableCellPrimitive:dom('td'),AiaIconButton:Button,AiaTooltip:({children})=>children,AiaCollapse:({in:shown,children})=>shown?React.createElement('div',{},children):null,AiaSelect:()=>null};
 const styles={MAPPING_TABLE_BODY_TEXT_SX:{fontFamily:'inherit'},MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX:38,MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT:38};
 const load=(file)=>{
  const loaded=new Module(file,module);loaded.require=request=>{
   if(request==='react')return reactForTest;
   if(request==='next/navigation')return {useRouter:()=>({push:()=>{}}),useSearchParams:()=>new URLSearchParams()};
   if(request.endsWith('sttm-builder-context'))return {useSttmBuilderContext:()=>context};
   if(request==='@/components/ui')return ui;
   if(request==='@/components/ui/aia-text')return {AiaText:Text};
   if(request==='@/components/ui/aia-table')return {aiaTableCellSx:()=>({})};
   if(request.endsWith('mapping-table-styles'))return styles;
   if(request==='@/utils/icons')return new Proxy({},{get:()=>()=>null});
   if(request.includes('tour-targets'))return {TOUR_TARGETS:{}};
   if(request.endsWith('sheet-candidates'))return sheet.exports;
   if(request.endsWith('mapping-review-model'))return review;
   if(request.endsWith('review-navigation'))return navigation;
   return require(request);
  };
  loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText,file);return loaded.exports;
 };
 const Component=load(path.resolve(__dirname,'../src/features/sttm/mapping/mapping-row-candidates.tsx')).MappingRowCandidates;
 const content=React.createElement(Component,{row});
 if(!sourceCell)return renderToStaticMarkup(content);
 const Source=load(path.resolve(__dirname,'../src/features/sttm/mapping/cells/mapping-source-columns-cell.tsx')).MappingSourceColumnsCell;
 return renderToStaticMarkup(React.createElement('table',{},React.createElement('tbody',{},React.createElement('tr',{},React.createElement(Source,{mappingType:'direct',value:row.sourceColumn,sourceColumns:row.sourceColumns,options:[],onChange:()=>{}},content)))));
}

test('row controls render beneath the source and current-only candidates have no alternatives button',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};
 const html=renderReviewRow(row,{sourceCell:true});
 assert.match(html,/<td[ >]/);assert.match(html,/AI suggested/);assert.match(html,/Confirm mapping/);
 assert.doesNotMatch(html,/View candidates|Use candidate/);
 assert.ok(html.indexOf('Direct source pick')<html.indexOf('AI suggested'),'selected-source controls precede review controls');
 const invalid={...row,aiCandidates:[candidate('one',{validation_status:'invalid',validation_errors:['Needs validation']})]};
 const pending=renderReviewRow(invalid);assert.match(pending,/Current mapping requires revalidation/);assert.match(pending,/Revalidate current mapping/);assert.doesNotMatch(pending,/View candidates|Use candidate/);
});

test('guidance-only results render Suggestions, collapsed by default, without a fake 0%-Direct option',()=>{
 const row={...h.blank(),aiCandidates:[candidate('empty',{source_attributes:[],source_dependencies:[],confidence_score:0,unmatched_reason:'No suitable source <script>alert(1)</script>'})]};
 const html=renderReviewRow(row);assert.match(html,/Suggestions \(1\)/);assert.doesNotMatch(html,/0%|View candidates|No source columns|<script/);
 const expanded=renderReviewRow(row,{open:'suggestions'});assert.match(expanded,/No suitable source/);assert.doesNotMatch(expanded,/<script>/);
});

test('the actual mapping component nests review content only in the Source Column cell',()=>{
 const file=path.resolve(__dirname,'../src/features/sttm/mapping/source-target-attribute-mapping.tsx');
 const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 let source=false,target=false;
 function visit(node){if(ts.isJsxElement(node)) {
  const name=node.openingElement.tagName.getText(ast);
  if(node.children.some(child=>child.getText(ast).includes('MappingRowCandidates'))){if(name==='MappingSourceColumnsCell')source=true;if(name==='MappingTargetColumnCell')target=true;}
 }ts.forEachChild(node,visit);}visit(ast);
 assert.equal(source,true);assert.equal(target,false);
});
