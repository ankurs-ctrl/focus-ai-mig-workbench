import type { MappingState, MappingStatus } from '../types/sttm.types';
import { validationDigest } from './validation-context';
const NAMED_RULES = new Set(['DIRECT','IDENTITY','VALUE','SELECT...','CUSTOM','UPPER','LOWER','TRIM','CAST','COALESCE','DATE_FORMAT','SUBSTRING','REPLACE','NULLIF','CONCATENATE']);
/** Older drafts may store authored SQL directly in the rule field. The compiler still decides validity. */
export function storedRuleExpression(row:Partial<MappingState>):string|null {
  const rule=row.rule?.trim();return rule&&!NAMED_RULES.has(rule.toUpperCase())?rule:null;
}
export type RowValidation = {definitionSignature:string;contextSignature:string;result:'valid'|'failed';error?:string};
export function hasMappingDefinition(row: Partial<MappingState>): boolean {
  return Boolean(row.sourceColumn?.trim() || row.sourceColumns?.length || row.expression?.trim() || row.attributeName?.trim() || row.constantValue!=null || row.nlRule?.trim() || (row.rule?.trim()&&!['DIRECT','IDENTITY','SELECT...','VALUE'].includes(row.rule.trim().toUpperCase())));
}
export function completeMappingDefinition(row: Partial<MappingState>): boolean {
  if(row.mappingMode==='constant')return row.constantValue!=null;
  if(row.mappingMode==='attribute')return Boolean(row.attributeName?.trim());
  if(row.expression?.trim())return true;
  const sourceCount=row.sourceColumns?.length??(row.sourceColumn?.trim()?1:0);
  const rule=(row.rule??'Direct').trim().toUpperCase();
  if(['DIRECT','IDENTITY',''].includes(rule))return sourceCount===1;
  // SQL in an old rule field is reviewable, but it still needs compilation.
  return Boolean(storedRuleExpression(row));
}
export function rowDefinitionSignature(row: Partial<MappingState>): string {
  return validationDigest({target:row.targetColumn,targetType:row.targetType,source:row.sourceColumns?.length?row.sourceColumns:row.sourceColumn,
    mode:row.mappingMode??'source',constant:row.constantValue??null,attribute:row.attributeName??null,rule:row.rule??'Direct',expression:row.expression??null,
    dependencies:row.sourceDependencies??[],values:row.valueBindingIds??[]});
}
export function validatedRow(row: MappingState, contextSignature:string, result:'valid'|'failed'='valid', error?:string):RowValidation {
  return {definitionSignature:rowDefinitionSignature(row),contextSignature,result,...(error?{error}:{})};
}
export function rowMappingStatus(row: MappingState,contextSignature:string): MappingStatus {
  if(row.status==='PROCESSING')return 'PROCESSING';
  if(!hasMappingDefinition(row))return 'UNMAPPED';
  const proof=row.validation;
  if(proof&&proof.contextSignature===contextSignature&&proof.definitionSignature===rowDefinitionSignature(row)&&proof.result==='failed')return 'VALIDATION_FAILED';
  if(!completeMappingDefinition(row))return 'NEEDS_VALIDATION';
  return proof?.result==='valid'&&proof.contextSignature===contextSignature&&proof.definitionSignature===rowDefinitionSignature(row)?'MAPPED':'NEEDS_VALIDATION';
}
export function recoverableAiUndo(row:MappingState):boolean {
  return Boolean(row.aiUndoSnapshot&&hasMappingDefinition(row.aiUndoSnapshot)&&rowDefinitionSignature(row)!==rowDefinitionSignature(row.aiUndoSnapshot));
}
