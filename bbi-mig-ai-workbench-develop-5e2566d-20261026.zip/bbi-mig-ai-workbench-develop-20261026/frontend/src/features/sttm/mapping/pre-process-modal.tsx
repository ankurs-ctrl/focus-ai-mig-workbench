'use client';
import { AiaAccordion, AiaAccordionDetails, AiaAccordionSummary, AiaBox, AiaButton, AiaCheckbox, AiaChip, AiaDialog } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ExpandMoreIcon, KeyIcon, LinkIcon, StorageRoundedIcon } from '@/utils/icons';

import {
  SqlEditor,
  SQL_COMPLETION_KEYWORDS,
  SQL_EDITOR_PANEL_MIN_HEIGHT,
  SQL_FUNCTION_COMPLETIONS,
  mergeSqlCompletionCandidates,
} from '@/components/sql';
import { AiaSearchbox } from '@/components/ui/aia-searchbox';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { useAiChatLayout } from '@/features/ai-agent/ai-chat-layout-context';
import { useTour } from '@/features/tour/engine/tour-context';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import type { ColumnGroup, DerivedSource } from '@/features/sttm/types/sttm.types';
import { withPreservedAutoMapConfidence } from './mapping-confidence-groups';
import { useProjectAttributes } from './use-project-attributes';
import { firmValueLiteral, firmValueLiteralPattern } from './firm-value-literal';
import type { ProjectAttributeRecord } from '@/services/projectService';
import { AiaResizeHandle } from '@/components/ui/aia-resize-handle';
import { SttmSidebarCollapseFooter } from '@/features/sttm/layout/sttm-sidebar-collapse-footer';
import { SttmSidebarCollapsedRail } from '@/features/sttm/layout/sttm-sidebar-collapsed-rail';
import { ResizableSidebarSections } from '@/features/sttm/layout/resizable-sidebar-sections';
import { SttmSidebarSectionIcon } from '@/features/sttm/layout/sttm-sidebar-icons';
import {
  formatSqlType,
  generateMappingDescription,
  getDerivedDisplayColumns,
  parseSourceColumns,
} from './mapping-utils';
import { relationAliasFor } from './relation-alias';
import {
  sttmSidebarBodyTextSx,
  sttmSidebarColumnTypeSx,
  sttmSidebarSearchboxSx,
  sttmSidebarSearchInputSx,
  sttmSidebarSecondaryTextSx,
} from '@/features/sttm/layout/sttm-sidebar-text-styles';
import { textStyleCssVars } from '@/config/typography-tokens';

const modalCloseButtonSx = {
  minWidth: 28,
  width: 28,
  height: 28,
  p: 0,
  fontSize: 14,
  lineHeight: 1,
  boxShadow: 'none',
  color: 'var(--aia-button-color)',
  '&:hover': {
    bgcolor: 'transparent',
    color: 'var(--aia-button-hover-color)',
  },
} as const;

const modalPrimaryButtonColors = {
  customBackgroundColor: 'var(--aia-primary-bg-color)',
  customColor: 'var(--aia-primary-bg-text-color)',
  customBorderColor: 'var(--aia-primary-bg-color)',
  customHoverBackgroundColor: 'var(--aia-primary-bg-hover-color)',
} as const;

const singleLineNameSx = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
} as const;

function tableAlias(tableName: string) {
  return tableName.toLowerCase();
}

function schemaCategory(qualifiedName: string) {
  const schema = qualifiedName.split('.')[1] ?? qualifiedName;
  return schema.split('_')[0] || schema;
}

type PreProcessColumnGroup = ColumnGroup & {
  matchNames?: string[];
};

const CTE_SECTION_LABEL = 'CTE Sources';

// Each sidebar section's search bar stays pinned at the top while its list scrolls.
const STICKY_SEARCH_SX = {
  position: 'sticky',
  top: 0,
  zIndex: 1,
  flexShrink: 0,
  backgroundColor: 'var(--color-surface)',
} as const;

const sectionCategorySx = {
  px: 1,
  py: 0.5,
  ...sttmSidebarSecondaryTextSx,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
} as const;

function filterColumnGroups<T extends ColumnGroup>(groups: T[], search: string): T[] {
  const query = search.trim().toLowerCase();
  if (!query) return groups;
  return groups
    .map((group) => ({
      ...group,
      columns: group.columns.filter(
        (col) =>
          col.name?.toLowerCase().includes(query) ||
          group.table.toLowerCase().includes(query),
      ),
    }))
    .filter((group) => group.columns.length > 0);
}

function derivedColumnsForPicker(source: DerivedSource) {
  const displayColumns = getDerivedDisplayColumns(source);
  if (displayColumns.length) return displayColumns;
  // Fall back to the CTE's selected columns so a CTE is never listed without columns
  // just because its output/preview columns were not loaded.
  const seen = new Set<string>();
  return Object.values(source.selectedColumnsByTable ?? {})
    .flat()
    .map((name) => String(name ?? '').trim())
    .filter((name) => {
      const key = name.toUpperCase();
      if (!name || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .map((name) => ({ name, type: '—' }));
}

// Every CTE selected in Select Tables (CTE Sources) is listed, even when its columns are
// unavailable, so it is never silently missing from the picker.
function buildDerivedColumnGroups(derivedSources: DerivedSource[]): PreProcessColumnGroup[] {
  return derivedSources
    .filter((source) => source.isSelected)
    .map((source) => {
      const normalize = (value: string | null | undefined) =>
        String(value ?? '').trim().replace(/\s+/g, '_');
      const alias = normalize(source.alias || source.sourceName || source.id);
      return {
        table: alias,
        qualifiedName: `CTE.CTE.${alias}`,
        columns: derivedColumnsForPicker(source),
        matchNames: [
          normalize(source.sourceName),
          normalize(source.id),
          normalize(source.physicalViewName?.split('.').pop()),
          relationAliasFor(source.id, source.sourceName),
        ].filter(Boolean),
      };
    });
}

function sourceColumnMatches(item: string, group: PreProcessColumnGroup, columnName: string) {
  const parts = item.trim().toLowerCase().split('.');
  if (parts.length < 2 || parts[parts.length - 1] !== columnName.toLowerCase()) return false;
  const relation = parts[parts.length - 2];
  return [group.table, ...(group.matchNames ?? [])].some(
    (name) => name.toLowerCase() === relation,
  );
}

const DEFAULT_SOURCE_SIDEBAR_WIDTH = 340;
const MIN_SOURCE_SIDEBAR_WIDTH = 248;
const COLLAPSED_SOURCE_SIDEBAR_WIDTH = 70;
const FOOTER_ROW_HEIGHT = 76;
// Dragging can widen the source sidebar up to half of the window.
const MAX_SOURCE_SIDEBAR_VIEWPORT_RATIO = 0.5;

function groupBySchema<T extends ColumnGroup>(groups: T[]) {
  const map = new Map<string, T[]>();
  for (const group of groups) {
    const key = schemaCategory(group.qualifiedName);
    const bucket = map.get(key) ?? [];
    bucket.push(group);
    map.set(key, bucket);
  }
  return Array.from(map.entries());
}

function looksLikeSqlExpression(value?: string | null) {
  const trimmed = value?.trim();
  if (!trimmed) return false;

  const upper = trimmed.toUpperCase();
  if (
    [
      'DIRECT',
      'UPPER',
      'LOWER',
      'TRIM',
      'CAST',
      'COALESCE',
      'DATE_FORMAT',
      'SUBSTRING',
      'REPLACE',
      'NULLIF',
      'CONCATENATE',
    ].includes(upper)
  ) {
    return false;
  }

  return /[().\s,]/.test(trimmed);
}

export default function PreProcessModal() {
  const {
    isPreProcessModalOpen,
    setPreProcessModalOpen,
    activeMappingId,
    mappings,
    updateMapping,
    sourceAttributeGroups: physicalSourceGroups,
    derivedSources,
    relationships,
    refreshAssistantSignals,
    activeProjectId,
  } = useSttmBuilderContext();
  // Firm values (project attributes) of the mapping's project; loaded only while open.
  const { projectAttributes: firmValues } = useProjectAttributes(
    isPreProcessModalOpen ? activeProjectId : null,
  );
  const {
    isOpen: isAssistantOpen,
    effectiveSidebarWidth,
    isMobile,
    isTablet,
  } = useAiChatLayout();
  const { registerModalTour, startTour } = useTour();

  const [expression, setExpression] = useState('');
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [sourceSearch, setSourceSearch] = useState('');
  const [cteSearch, setCteSearch] = useState('');
  const [firmSearch, setFirmSearch] = useState('');
  const [expandedTables, setExpandedTables] = useState<Record<string, boolean>>({});
  // Collapsing keeps the dragged width, so expanding reopens the sidebar at the same size.
  const [sourceSidebarCollapsed, setSourceSidebarCollapsed] = useState(false);
  const [sourceSidebarWidth, setSourceSidebarWidth] = useState(DEFAULT_SOURCE_SIDEBAR_WIDTH);
  const sourceSidebarResizeRef = useRef<{ startX: number; startWidth: number } | null>(null);

  useEffect(() => {
    const handlePointerMove = (event: MouseEvent) => {
      const state = sourceSidebarResizeRef.current;
      if (!state) {
        return;
      }
      const maxWidth = Math.max(
        MIN_SOURCE_SIDEBAR_WIDTH,
        Math.floor(window.innerWidth * MAX_SOURCE_SIDEBAR_VIEWPORT_RATIO),
      );
      setSourceSidebarWidth(
        Math.min(maxWidth, Math.max(MIN_SOURCE_SIDEBAR_WIDTH, state.startWidth + event.clientX - state.startX)),
      );
    };
    const handlePointerUp = () => {
      sourceSidebarResizeRef.current = null;
    };
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
    };
  }, []);

  const activeMapping = mappings.find((m) => m.id === activeMappingId);
  const joinCount = relationships.length;

  const physicalColumnGroups = useMemo<PreProcessColumnGroup[]>(
    () =>
      // Saved mappings (auto-map, relation graph, compiler) qualify columns with the
      // identity alias, e.g. `customer_20231101_ab12cd.ID`; accept it so they pre-tick.
      physicalSourceGroups.map((group) => ({
        ...group,
        matchNames: [relationAliasFor(group.qualifiedName)],
      })),
    [physicalSourceGroups],
  );

  const derivedColumnGroups = useMemo(
    () => buildDerivedColumnGroups(derivedSources),
    [derivedSources],
  );

  const sourceAttributeGroups = useMemo<PreProcessColumnGroup[]>(
    () => [...physicalColumnGroups, ...derivedColumnGroups],
    [physicalColumnGroups, derivedColumnGroups],
  );

  // Prefill from the saved mapping once per open (or when switching rows). Keying on the
  // mapping object instead would re-run on every `mappings` update and overwrite edits.
  const prefillKey = isPreProcessModalOpen ? activeMappingId : null;
  const [prefilledKey, setPrefilledKey] = useState<string | null>(null);
  if (prefillKey !== prefilledKey) {
    setPrefilledKey(prefillKey);
    if (prefillKey && activeMapping) {
      const initialColumns =
        activeMapping.sourceColumns && activeMapping.sourceColumns.length
          ? activeMapping.sourceColumns
          : parseSourceColumns(activeMapping.sourceColumn);
      const suggestedExpression =
        !activeMapping.expression && looksLikeSqlExpression(activeMapping.aiSuggestedRule)
          ? activeMapping.aiSuggestedRule?.trim() ?? ''
          : '';
      setExpression(activeMapping.expression || suggestedExpression || initialColumns.join(', '));
      setSelectedColumns(initialColumns);
    } else {
      setExpression('');
      setSelectedColumns([]);
    }
    setSourceSearch('');
    setCteSearch('');
    setFirmSearch('');
  }

  useEffect(() => {
    if (!isPreProcessModalOpen) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setExpandedTables(
      Object.fromEntries(
        sourceAttributeGroups.map((group) => [group.qualifiedName, true]),
      ),
    );
  }, [isPreProcessModalOpen, sourceAttributeGroups]);

  useEffect(() => {
    if (!isPreProcessModalOpen) {
      registerModalTour(null);
      return;
    }
    registerModalTour('sttm-preprocess');
    return () => registerModalTour(null);
  }, [isPreProcessModalOpen, registerModalTour]);

  const handleClose = () => {
    setPreProcessModalOpen(false);
  };

  const handleApply = () => {
    if (!activeMappingId) return;
    const trimmedExpression = expression.trim();
    const targetColumn = activeMapping?.targetColumn ?? '';
    const nextRule = trimmedExpression ? 'Custom' : (activeMapping?.rule || 'Direct');
    const description = generateMappingDescription({
      rule: nextRule,
      sourceColumns: selectedColumns,
      targetColumn,
      expression: trimmedExpression,
    });

    const hasContent = trimmedExpression || selectedColumns.length > 0;

    const updates = {
      expression: trimmedExpression || null,
      // The NL Rule column mirrors the SQL Preview at the time the rule is applied.
      nlRule: trimmedExpression || null,
      sourceColumns: selectedColumns,
      sourceColumn: selectedColumns.join(', ') || null,
      mappingMode: 'source' as const,
      constantValue: null,
      attributeName: null,
      rule: nextRule,
      status: (hasContent ? 'MAPPED' : 'UNMAPPED') as 'MAPPED' | 'UNMAPPED',
      ...(activeMapping?.descriptionEdited ? {} : { description }),
    };

    updateMapping(
      activeMappingId,
      activeMapping
        ? withPreservedAutoMapConfidence(activeMapping, updates)
        : updates,
    );
    window.setTimeout(() => refreshAssistantSignals('on_transformation_review'), 0);
    handleClose();
  };

  const insertText = (text: string, wrapExisting = false) => {
    if (wrapExisting && text.includes('()')) {
      setExpression((prev) => (prev ? text.replace('()', `(${prev})`) : text));
    } else {
      setExpression((prev) => prev + (prev && !prev.endsWith(' ') ? ' ' : '') + text);
    }
  };

  const toggleColumnSelection = (
    group: PreProcessColumnGroup,
    columnName: string,
    checked?: boolean,
  ) => {
    const fullValue = `${tableAlias(group.table)}.${columnName}`;
    const isCurrentlySelected = selectedColumns.some((item) =>
      sourceColumnMatches(item, group, columnName),
    );
    const shouldSelect = checked !== undefined ? checked : !isCurrentlySelected;

    if (shouldSelect) {
      setSelectedColumns((prev) => {
        if (prev.some((item) => sourceColumnMatches(item, group, columnName))) return prev;
        return [...prev, fullValue];
      });
      insertText(fullValue);
      return;
    }

    setSelectedColumns((prev) =>
      prev.filter((item) => !sourceColumnMatches(item, group, columnName)),
    );
    setExpression((prev) =>
      prev
        .split(/(\s+)/)
        .filter((part) => !part.trim() || !sourceColumnMatches(part, group, columnName))
        .join('')
        .replace(/\s{2,}/g, ' ')
        .trim(),
    );
  };

  const selectedCteCount = selectedColumns.filter((item) =>
    derivedColumnGroups.some((group) =>
      group.columns.some((col) => sourceColumnMatches(item, group, col.name ?? '')),
    ),
  ).length;
  const selectedSourceCount = selectedColumns.length - selectedCteCount;
  const selectionSummary = `${selectedSourceCount} ${selectedSourceCount === 1 ? 'column' : 'columns'}, ${selectedCteCount} CTE selected`;

  const isColumnSelected = (group: PreProcessColumnGroup, columnName: string) =>
    selectedColumns.some((item) => sourceColumnMatches(item, group, columnName));

  // Clicking a firm value inserts its value (as a SQL literal) into the expression; the
  // checkbox reflects whether that literal is present.
  const isFirmValueSelected = (literal: string) =>
    firmValueLiteralPattern(literal).test(expression);

  const toggleFirmValue = (literal: string, checked?: boolean) => {
    const shouldSelect = checked !== undefined ? checked : !isFirmValueSelected(literal);
    if (shouldSelect) {
      if (!isFirmValueSelected(literal)) insertText(literal);
      return;
    }
    setExpression((prev) =>
      prev
        .replace(firmValueLiteralPattern(literal, 'g'), '$1')
        .replace(/\s{2,}/g, ' ')
        .trim(),
    );
  };

  const filteredFirmValues = useMemo(() => {
    const query = firmSearch.trim().toLowerCase();
    if (!query) return firmValues;
    return firmValues.filter(
      (attribute) =>
        attribute.attribute_name.toLowerCase().includes(query)
        || String(attribute.attribute_value ?? '').toLowerCase().includes(query),
    );
  }, [firmSearch, firmValues]);

  const filteredSourceSchemas = useMemo(
    () => groupBySchema(filterColumnGroups(physicalColumnGroups, sourceSearch)),
    [physicalColumnGroups, sourceSearch],
  );

  const filteredCteGroups = useMemo(
    () => filterColumnGroups(derivedColumnGroups, cteSearch),
    [derivedColumnGroups, cteSearch],
  );

  const renderSectionSearch = (
    value: string,
    onChange: (value: string) => void,
    placeholder: string,
  ) => (
    <AiaBox sx={{ ...STICKY_SEARCH_SX, px: 1, pb: 1 }}>
      <AiaSearchbox
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        sx={sttmSidebarSearchboxSx}
        inputSx={sttmSidebarSearchInputSx}
      />
    </AiaBox>
  );

  const renderSectionEmpty = (message: string) => (
    <AiaText sx={{ px: 1, py: 0.5, ...sttmSidebarSecondaryTextSx, fontStyle: 'italic' }}>
      {message}
    </AiaText>
  );

  const renderColumnGroup = (group: PreProcessColumnGroup, isCte: boolean) => {
    const isExpanded = expandedTables[group.qualifiedName] ?? true;
    return (
      <AiaAccordion
        key={group.qualifiedName}
        expanded={isExpanded}
        onChange={(_, expanded) =>
          setExpandedTables((prev) => ({
            ...prev,
            [group.qualifiedName]: expanded,
          }))
        }
        disableGutters
        elevation={0}
        sx={{
          bgcolor: 'transparent',
          '&:before': { display: 'none' },
          boxShadow: 'none',
        }}
      >
        <AiaAccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ fontSize: 18, color: '#6b7280' }} />}
          sx={{
            minHeight: 34,
            px: 0.5,
            '& .MuiAccordionSummary-content': {
              my: 0.5,
              display: 'flex',
              alignItems: 'center',
              gap: 0.75,
              minWidth: 0,
            },
          }}
        >
          <StorageRoundedIcon sx={{ fontSize: 14, color: '#6b7280', flexShrink: 0 }} />
          <AiaText
            title={group.table}
            sx={{ ...sttmSidebarBodyTextSx, ...singleLineNameSx, fontWeight: 400 }}
          >
            {group.table}
          </AiaText>
        </AiaAccordionSummary>
        <AiaAccordionDetails sx={{ p: 0, pb: 0.5 }}>
          {group.columns.length === 0 && isCte ? (
            <AiaText sx={{ px: 1.25, py: 0.45, ...sttmSidebarSecondaryTextSx, fontStyle: 'italic' }}>
              No output columns available for this CTE.
            </AiaText>
          ) : null}
          {group.columns.map((col) => {
            const colName = col.name ?? '';
            const isSelected = isColumnSelected(group, colName);
            const typeLabel = (col.type ? formatSqlType(col.type) : '—').toLowerCase();

            return (
              <AiaBox
                key={`${group.qualifiedName}-${colName}`}
                onClick={() => toggleColumnSelection(group, colName)}
                sx={{
                  px: 1.25,
                  py: 0.45,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 1,
                  cursor: 'pointer',
                  borderRadius: '6px',
                  '&:hover': { bgcolor: '#f3f4f6' },
                }}
              >
                <AiaBox
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 0.75,
                    minWidth: 0,
                    flex: 1,
                  }}
                >
                  <AiaCheckbox
                    checked={isSelected}
                    checkHandler={(checked) =>
                      toggleColumnSelection(group, colName, checked)
                    }
                    uncheckedColor="var(--aia-primary-bg-color)"
                    checkedColor="var(--aia-primary-bg-color)"
                  />
                  <AiaBox
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 0.5,
                      flex: 1,
                      minWidth: 0,
                    }}
                  >
                    <AiaText
                      title={colName}
                      sx={{
                        ...sttmSidebarSecondaryTextSx,
                        ...singleLineNameSx,
                        color: 'var(--color-text)',
                      }}
                    >
                      {colName}
                    </AiaText>
                    {col.isPrimaryKey ? (
                      <KeyIcon sx={{ fontSize: 16, color: '#ca8a04', flexShrink: 0 }} />
                    ) : null}
                    {col.isForeignKey ? (
                      <LinkIcon sx={{ fontSize: 16, color: '#9ca3af', flexShrink: 0 }} />
                    ) : null}
                  </AiaBox>
                </AiaBox>
                <AiaText
                  sx={{
                    ...sttmSidebarColumnTypeSx,
                    display: 'block',
                    mt: 0,
                    flexShrink: 0,
                    textAlign: 'right',
                  }}
                >
                  {typeLabel}
                </AiaText>
              </AiaBox>
            );
          })}
        </AiaAccordionDetails>
      </AiaAccordion>
    );
  };

  const renderFirmValue = (attribute: ProjectAttributeRecord) => {
    const name = attribute.attribute_name;
    const value = String(attribute.attribute_value ?? '');
    const literal = firmValueLiteral(attribute.attribute_value, attribute.attribute_type);
    const isSelected = isFirmValueSelected(literal);
    return (
      <AiaBox
        key={attribute.attribute_id}
        onClick={() => toggleFirmValue(literal)}
        sx={{
          px: 1.25,
          py: 0.6,
          display: 'flex',
          alignItems: 'flex-start',
          gap: 0.75,
          cursor: 'pointer',
          borderRadius: '6px',
          '&:hover': { bgcolor: '#f3f4f6' },
        }}
      >
        <AiaCheckbox
          checked={isSelected}
          checkHandler={(checked) => toggleFirmValue(literal, checked)}
          uncheckedColor="var(--aia-primary-bg-color)"
          checkedColor="var(--aia-primary-bg-color)"
        />
        {/* Name on one line; the value wraps on the line below it. */}
        <AiaBox sx={{ minWidth: 0, flex: 1 }}>
          <AiaText
            title={name}
            sx={{
              ...sttmSidebarSecondaryTextSx,
              ...singleLineNameSx,
              color: 'var(--color-text)',
            }}
          >
            {name}
          </AiaText>
          <AiaText
            sx={{
              ...sttmSidebarColumnTypeSx,
              display: 'block',
              mt: 0.25,
              textTransform: 'none',
              whiteSpace: 'normal',
              overflowWrap: 'anywhere',
            }}
          >
            {value || '—'}
          </AiaText>
        </AiaBox>
      </AiaBox>
    );
  };

  const sqlCompletionCandidates = useMemo(() => {
    const identifiers = sourceAttributeGroups.flatMap((group) => {
      const alias = tableAlias(group.table);
      const columns = group.columns.flatMap((column) => {
        const name = String(column.name ?? '').trim();
        if (!name) return [];
        return alias ? [name, `${alias}.${name}`] : [name];
      });
      return [alias, group.table, group.qualifiedName, ...columns].filter(Boolean);
    });

    return mergeSqlCompletionCandidates(
      identifiers,
      SQL_FUNCTION_COMPLETIONS,
      SQL_COMPLETION_KEYWORDS,
    );
  }, [sourceAttributeGroups]);

  const joinSubtitle =
    joinCount > 0 ? `${joinCount} join${joinCount === 1 ? '' : 's'} from Step 1` : undefined;
  const assistantDockWidth =
    isAssistantOpen && !isMobile && !isTablet ? effectiveSidebarWidth : 0;

  return (
    <AiaDialog
      open={isPreProcessModalOpen}
      onClose={handleClose}
      maxWidth="xl"
      fullWidth
      sx={{
        right: `${assistantDockWidth}px`,
        transition: 'right 220ms ease',
        '& .MuiDialog-paper': {
          height: '90vh',
          maxWidth: assistantDockWidth
            ? `min(1536px, calc(100vw - ${assistantDockWidth + 48}px))`
            : undefined,
          borderRadius: '16px',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        },
      }}
    >
      <AiaBox sx={{ p: 3, borderBottom: '1px solid #f1f5f9' }}>
        <AiaBox sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
          <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1.5, minWidth: 0, flex: 1 }}>
            <AiaBox
              sx={{
                width: 36,
                height: 36,
                borderRadius: '50%',
                bgcolor: 'var(--color-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <StorageRoundedIcon sx={{ fontSize: 18, color: '#fff' }} />
            </AiaBox>
            <AiaBox sx={{ minWidth: 0 }}>
              <AiaText
                sx={{
                  ...textStyleCssVars('cardTitle'),
                  textTransform: 'capitalize',
                  letterSpacing: '-0.01em',
                }}
              >
                Pre-Processing Rule
              </AiaText>
              {activeMapping ? (
                <AiaBox sx={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 1.25, mt: 0.25 }}>
                  <AiaText sx={{ ...textStyleCssVars('secondaryText') }}>
                    Target:{' '}
                    <AiaBox component="span" sx={{ fontWeight: 700, color: "var(--aia-text-color)" }}>
                      {activeMapping.targetColumn}
                    </AiaBox>
                  </AiaText>
                  <AiaText sx={{ ...textStyleCssVars('secondaryText') }}>
                    Type:{' '}
                    <AiaBox component="span" sx={{ fontWeight: 600, color: '#374151' }}>
                      {formatSqlType(activeMapping.targetType)}
                    </AiaBox>
                  </AiaText>
                  {joinCount > 0 ? (
                    <AiaChip
                      size="small"
                      color="success"
                      label={`++ ${joinCount} join${joinCount === 1 ? '' : 's'} in FROM`}
                    />
                  ) : null}
                </AiaBox>
              ) : null}
            </AiaBox>
          </AiaBox>
          <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0 }}>
            <AiaButton
              variant="contained"
              size="small"
              onClick={() => startTour('sttm-preprocess')}
              aria-label="Start Pre-Processing Rule tour guide"
              sx={{
                textTransform: 'none',
                fontWeight: 700,
                fontSize: 13,
                borderRadius: '10px',
                px: 1.5,
                py: 0.6,
                minHeight: 34,
                backgroundColor: 'var(--aia-primary-bg-color)',
                color: 'var(--aia-primary-bg-text-color)',
                boxShadow: 'none',
                '&:hover': {
                  backgroundColor: 'var(--aia-primary-bg-hover-color)',
                },
              }}
            >
              Tour Guide
            </AiaButton>
            <AiaButton
              variant="text"
              size="small"
              onClick={handleClose}
              sx={modalCloseButtonSx}
              aria-label="Close"
            >
              ✕
            </AiaButton>
          </AiaBox>
        </AiaBox>
      </AiaBox>

      <AiaBox sx={{ display: 'flex', flex: 1, minHeight: 0 }}>
        <AiaBox
          data-tour={TOUR_TARGETS.preprocessSourceTables}
          sx={{
            width: sourceSidebarCollapsed ? COLLAPSED_SOURCE_SIDEBAR_WIDTH : sourceSidebarWidth,
            minWidth: sourceSidebarCollapsed ? COLLAPSED_SOURCE_SIDEBAR_WIDTH : MIN_SOURCE_SIDEBAR_WIDTH,
            maxWidth: sourceSidebarCollapsed ? COLLAPSED_SOURCE_SIDEBAR_WIDTH : '50vw',
            flexShrink: 0,
            borderRight: '1px solid #e5e7eb',
            display: 'flex',
            minHeight: 0,
            overflow: 'hidden',
            bgcolor: '#fff',
          }}
        >
          {sourceSidebarCollapsed ? (
            <AiaBox sx={{ width: '100%', minHeight: 0, display: 'flex', flexDirection: 'column' }}>
              <AiaBox sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
                <SttmSidebarCollapsedRail
                  items={[
                    { kind: 'source', label: 'Source Tables' },
                    { kind: 'derived', label: CTE_SECTION_LABEL },
                    ...(activeProjectId ? [{ kind: 'firm' as const, label: 'Firm Values' }] : []),
                  ]}
                />
              </AiaBox>
              <SttmSidebarCollapseFooter
                collapsed
                centered
                height={FOOTER_ROW_HEIGHT}
                expandLabel="Expand source sidebar"
                onToggle={() => setSourceSidebarCollapsed(false)}
              />
            </AiaBox>
          ) : null}
          {/* Hidden rather than unmounted while collapsed, so search and expanded tables are kept. */}
          <AiaBox
            sx={{
              display: sourceSidebarCollapsed ? 'none' : 'flex',
              flexDirection: 'column',
              flex: 1,
              minWidth: 0,
              minHeight: 0,
            }}
          >
          <AiaBox sx={{ flex: 1, minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <ResizableSidebarSections
              // Only Source Tables starts open in this popup.
              defaultExpanded={{ source: true, cte: false, firm: false }}
              sections={[
                {
                  id: 'source',
                  title: 'Source Tables',
                  icon: <SttmSidebarSectionIcon kind="source" />,
                  content: (
                    <>
                      {renderSectionSearch(sourceSearch, setSourceSearch, 'Search tables, columns...')}
                      <AiaBox sx={{ px: 0.5 }}>
                        {filteredSourceSchemas.map(([schema, groups]) => (
                          <AiaBox key={schema} sx={{ mb: 1 }}>
                            <AiaText sx={sectionCategorySx}>{schema}</AiaText>
                            {groups.map((group) => renderColumnGroup(group, false))}
                          </AiaBox>
                        ))}
                        {filteredSourceSchemas.length === 0
                          ? renderSectionEmpty(
                              physicalColumnGroups.length === 0
                                ? 'No source tables available. Select tables first.'
                                : 'No columns match your search.',
                            )
                          : null}
                      </AiaBox>
                    </>
                  ),
                },
                {
                  id: 'cte',
                  title: CTE_SECTION_LABEL,
                  icon: <SttmSidebarSectionIcon kind="derived" />,
                  content: (
                    <>
                      {renderSectionSearch(cteSearch, setCteSearch, 'Search CTEs, columns...')}
                      <AiaBox sx={{ px: 0.5 }}>
                        {filteredCteGroups.map((group) => renderColumnGroup(group, true))}
                        {filteredCteGroups.length === 0
                          ? renderSectionEmpty(
                              derivedColumnGroups.length === 0
                                ? 'No CTE sources selected in Select Tables.'
                                : 'No CTEs or columns match your search.',
                            )
                          : null}
                      </AiaBox>
                    </>
                  ),
                },
                ...(activeProjectId
                  ? [
                      {
                        id: 'firm',
                        title: 'Firm Values',
                        icon: <SttmSidebarSectionIcon kind="firm" />,
                        content: (
                          <>
                            {renderSectionSearch(firmSearch, setFirmSearch, 'Search firm values...')}
                            <AiaBox sx={{ px: 0.5 }}>
                              {filteredFirmValues.map((attribute) => renderFirmValue(attribute))}
                              {filteredFirmValues.length === 0
                                ? renderSectionEmpty(
                                    firmValues.length === 0
                                      ? 'No firm values in this project.'
                                      : 'No firm values match your search.',
                                  )
                                : null}
                            </AiaBox>
                          </>
                        ),
                      },
                    ]
                  : []),
              ]}
            />
          </AiaBox>
          <SttmSidebarCollapseFooter
            collapsed={false}
            height={FOOTER_ROW_HEIGHT}
            collapseLabel="Collapse source sidebar"
            onToggle={() => setSourceSidebarCollapsed(true)}
          />
          </AiaBox>
          {sourceSidebarCollapsed ? null : (
            <AiaResizeHandle
              direction="horizontal"
              onMouseDown={(event) => {
                event.preventDefault();
                sourceSidebarResizeRef.current = { startX: event.clientX, startWidth: sourceSidebarWidth };
              }}
            />
          )}
        </AiaBox>

        <AiaBox sx={{ flex: 1, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
        <AiaBox
          data-tour={TOUR_TARGETS.preprocessSqlEditor}
          sx={{
            flex: 1,
            minWidth: 0,
            minHeight: 0,
            display: 'flex',
            p: 3,
            bgcolor: '#f8fafc',
            overflow: 'hidden',
          }}
        >
          <SqlEditor
            value={expression}
            onChange={setExpression}
            completionCandidates={sqlCompletionCandidates}
            title="SQL Preview"
            subtitle={joinSubtitle}
            placeholder={`-- Type or click a column from the left panel\n-- e.g. UPPER(a.NAME)   or   ROW_NUMBER() OVER(ORDER BY a.DATE_KEY)`}
            showFunctionLibrary
            showCopy
            functionLibraryTourTargets={{
              root: TOUR_TARGETS.preprocessFunctionLibraryRoot,
              library: TOUR_TARGETS.preprocessFunctionLibrary,
              tabs: TOUR_TARGETS.preprocessFunctionTabs,
              panel: TOUR_TARGETS.preprocessFunctionLibrary,
            }}
            fillHeight
            minHeight={SQL_EDITOR_PANEL_MIN_HEIGHT}
            maxHeight="100%"
            sx={{ width: '100%', flex: 1, minHeight: 0 }}
          />
        </AiaBox>

      <AiaBox
        sx={{
          px: 3,
          height: FOOTER_ROW_HEIGHT,
          flexShrink: 0,
          borderTop: '1px solid #f1f5f9',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 2,
        }}
      >
        <AiaText title={selectionSummary} sx={{ fontSize: 12, color: '#64748b', ...singleLineNameSx }}>
          {selectionSummary}
        </AiaText>
        <AiaBox sx={{ display: 'flex', gap: 1.5, flexShrink: 0 }}>
          <AiaButton
            variant="outlined"
            size="large"
            onClick={handleClose}
            data-tour={TOUR_TARGETS.preprocessCancel}
            customBorderColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-color)"
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            size="large"
            color="primary"
            onClick={handleApply}
            data-tour={TOUR_TARGETS.preprocessApplyRule}
            disabled={!expression.trim() && selectedColumns.length === 0}
            {...modalPrimaryButtonColors}
          >
            Apply Rule
          </AiaButton>
        </AiaBox>
      </AiaBox>
        </AiaBox>
      </AiaBox>
    </AiaDialog>
  );
}
