const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
function sessionUtils(storage = new Map()) {
  const context = { exports: {}, window: { localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
    get length() { return storage.size; },
    key: index => [...storage.keys()][index] ?? null,
  } } };
  const source = fs.readFileSync(path.join(root, 'src/features/ai-agent/ai-chat-session-utils.ts'), 'utf8');
  vm.runInNewContext(ts.transpileModule(source, {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022}}).outputText, context);
  return context.exports;
}
test('merged history retains logical identity, renamed titles and project scope', () => {
  const utils = sessionUtils();
  utils.persistChatSessions('alice::project-a::agent', [{id:'chat', title:'My renamed chat', updatedAt:2, messages:[], logicalConversationId:'logical-a', backendConversationId:'server-a', mode:'deep', pinned:true}]);
  utils.persistChatSessions('bob::project-b::agent', [{id:'foreign', title:'Other user', updatedAt:3, messages:[]}]);
  const chats = utils.loadAllStoredChatSessions('alice');
  assert.equal(chats.length, 1);
  assert.equal(chats[0].projectId, 'project-a');
  assert.equal(chats[0].storageScope, 'alice::project-a::agent');
  assert.equal(chats[0].logicalConversationId, 'logical-a');
  assert.equal(chats[0].backendConversationId, 'server-a');
  assert.equal(chats[0].title, 'My renamed chat');
  assert.equal(chats[0].pinned, true);
});
test('merged history groups Today, Yesterday and Older without losing chats', () => {
  const utils = sessionUtils(); const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today); yesterday.setDate(today.getDate()-1);
  const older = new Date(today); older.setDate(today.getDate()-4);
  const grouped = utils.groupSessionsByRecency([{id:'old',updatedAt:+older}, {id:'today',updatedAt:Date.now()}, {id:'yesterday',updatedAt:+yesterday}]);
  assert.deepEqual(Array.from(grouped, item => item.label), ['TODAY','YESTERDAY','OLDER']);
  assert.deepEqual(Array.from(grouped, item => item.sessions[0].id), ['today','yesterday','old']);
});
test('actual chat restore reducer resumes logical conversation without reusing physical thread', () => {
  const source = fs.readFileSync(path.join(root, 'src/features/sttm/store/sttm-builder-slice.ts'), 'utf8');
  const tree = ts.createSourceFile('slice.ts', source, ts.ScriptTarget.Latest, true); let reducer;
  function visit(node) {
    if (ts.isPropertyAssignment(node) && node.name.getText(tree) === 'restoreChatSession') reducer = node.initializer.getText(tree);
    ts.forEachChild(node, visit);
  }
  visit(tree); assert.ok(reducer);
  const context = { exports:{}, upgradeAssistantWelcome: messages => messages };
  vm.runInNewContext(ts.transpileModule('exports.restore = ('+reducer+');', {compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText, context);
  const state = { agentThreadId:'old-thread', agentLogicalConversationId:'old-logical', agentPhysicalThreadSegment:3, agentParentMessageId:'old-parent' };
  context.exports.restore(state, {payload:{messages:[],logicalConversationId:'saved-logical'}});
  assert.equal(state.agentLogicalConversationId, 'saved-logical');
  assert.equal(state.agentThreadId, null);
  assert.equal(state.agentPhysicalThreadSegment, null);
  assert.equal(state.agentParentMessageId, null);
});
test('side-panel rename and delete route through the saved scoped conversation', async () => {
  const source = fs.readFileSync(path.join(root, 'src/features/ai-agent/ai-chat-layout-context.tsx'), 'utf8');
  const tree = ts.createSourceFile('context.tsx', source, ts.ScriptTarget.Latest, true);
  const callbacks = {};
  function visit(node) {
    if (ts.isVariableDeclaration(node) && ['renameSession','deleteSession'].includes(node.name.getText(tree))) callbacks[node.name.getText(tree)] = node.initializer.arguments[0].getText(tree);
    ts.forEachChild(node, visit);
  }
  visit(tree);
  const saved = {id:'saved', storageScope:'alice::other-project::agent'}; const calls = [];
  const context = {exports:{}, sessions:[saved], console, handleUpdateSession:async (...args) => calls.push(['rename',...args]), handleDeleteSession:async (...args) => calls.push(['delete',...args])};
  for (const [name,callback] of Object.entries(callbacks)) vm.runInNewContext(ts.transpileModule(`exports.${name} = (${callback});`, {compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText, context);
  context.exports.renameSession('saved','  Renamed  '); context.exports.deleteSession('saved');
  await Promise.resolve();
  assert.equal(calls[0][0], 'rename'); assert.equal(calls[0][1],saved); assert.equal(calls[0][2].title,'Renamed');
  assert.equal(calls[1][0], 'delete'); assert.equal(calls[1][1],saved);
});
