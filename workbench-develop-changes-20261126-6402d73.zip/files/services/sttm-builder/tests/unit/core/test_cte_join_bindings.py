from app.agent_tools.cte_join_bindings import resolve_passthrough_joins
import pytest


def source(sql='SELECT ID, ADMIN_ID, TRY_CAST(CENTS AS NUMBER) AS AMOUNT FROM DB.RAW.LOAN'):
 return {'driving_source':'DB.RAW.LOAN','supporting_sources':['DB.DW.USER'],
  'derived_sources':[{'name':'parsed','sql':sql}]}


def join():
 return {'left_table':'parsed','right_table':'DB.DW.USER','join_type':'LEFT',
  'conditions':[{'left_column':'ADMIN_ID','right_column':'ID','operator':'='}]}


def test_projection_preserves_unchanged_join_key_and_input():
 original=join();result=resolve_passthrough_joins(source(),[original])[0]
 assert result['left_table']=='DB.RAW.LOAN'
 assert original['left_table']=='parsed'
 assert result['cte_passthrough_sources'][0]['cte']=='parsed'
 assert result['conditions']==original['conditions']


@pytest.mark.parametrize('sql',[
 'SELECT ID, ADMIN_ID FROM DB.RAW.LOAN WHERE ACTIVE',
 'SELECT DISTINCT ID, ADMIN_ID FROM DB.RAW.LOAN',
 'SELECT ADMIN_ID, MAX(ID) ID FROM DB.RAW.LOAN GROUP BY ADMIN_ID',
 'SELECT ID, ADMIN_ID FROM DB.RAW.LOAN LIMIT 5',
 'SELECT l.ID, l.ADMIN_ID FROM DB.RAW.LOAN l JOIN DB.DW.USER u ON l.ADMIN_ID=u.ID',
 'SELECT ID, OTHER_ID AS ADMIN_ID FROM DB.RAW.LOAN',
 'SELECT ID, UPPER(ADMIN_ID) AS ADMIN_ID FROM DB.RAW.LOAN',
 'SELECT ID, ADMIN_ID FROM OTHER.RAW.LOAN',
 'SELECT ID, ADMIN_ID FROM DB.RAW.LOAN QUALIFY ROW_NUMBER() OVER (ORDER BY ID)=1',
 'SELECT ADMIN_ID, (SELECT COUNT(*) FROM DB.DW.USER) N FROM DB.RAW.LOAN',
 'SELECT * FROM DB.RAW.LOAN TABLESAMPLE (10)',
 'SELECT * EXCLUDE ADMIN_ID FROM DB.RAW.LOAN',
 'SELECT *, ADMIN_ID FROM DB.RAW.LOAN',
 'SELECT broken (((',
])
def test_population_or_key_changes_do_not_authorize_physical_rewrite(sql):
 assert resolve_passthrough_joins(source(sql),[join()])==[join()]


def test_duplicate_cte_names_and_renamed_output_are_unresolved():
 value=source();value['derived_sources']*=2
 assert resolve_passthrough_joins(value,[join()])==[join()]
 assert resolve_passthrough_joins(source('SELECT ADMIN_ID AS JOIN_ID FROM DB.RAW.LOAN'),[
  {**join(),'conditions':[{'left_column':'JOIN_ID','right_column':'ID'}]}])[0]['left_table']=='parsed'


def test_current_qualified_physical_reference_is_not_mistaken_for_same_named_cte():
 value={**join(),'left_table':'OTHER.RAW.PARSED'}
 assert resolve_passthrough_joins(source(),[value])==[value]


def test_star_and_exact_alias_remain_row_preserving():
 for sql in ['SELECT * FROM DB.RAW.LOAN','SELECT l.ADMIN_ID AS ADMIN_ID FROM DB.RAW.LOAN l']:
  assert resolve_passthrough_joins(source(sql),[join()])[0]['left_table']=='DB.RAW.LOAN'
