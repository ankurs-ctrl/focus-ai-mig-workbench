import pytest

from app.agent_tools.source_readiness import assess_source_readiness
from app.agent_runs.models import AgentCommand, AgentActor


def test_historical_sql_script_is_evidence_not_a_planned_read_query():
    from app.core.sql_execution_guard import is_single_read_only_query
    assert is_single_read_only_query('WITH c AS (SELECT 1 AS ID) SELECT ID FROM c')
    assert not is_single_read_only_query('SET migration_id = 1; SELECT 1')
    assert not is_single_read_only_query('INSERT INTO DB.SCH.TARGET SELECT 1')
    assert not is_single_read_only_query('WITH c AS (SELECT 1) DELETE FROM DB.SCH.TARGET')


def test_unresolved_mapping_review_candidates_require_current_source_columns():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    candidates = WorkbenchWorkflowHandlers._mapping_review_candidates(
        "REGION", {"target_column": "REGION", "status": "unresolved", "source_columns": [],
                   "confidence": 0, "confidence_reason": "No verified mapping"},
        [
            {"target_column": "REGION", "source_columns": ["DB.SRC.CONTACTS.REGION_CODE"],
             "transformation": "UPPER(REGION_CODE)", "evidence_source": "historical_precedent",
             "evidence_id": "prior:1"},
            {"target_column": "REGION", "source_columns": ["DB.SRC.CONTACTS.MISSING"],
             "transformation": "MISSING", "evidence_source": "historical_precedent"},
        ],
        {"DB.SRC.CONTACTS": {"columns": ["ID", "REGION_CODE"]}},
    )
    assert len(candidates) == 1
    assert candidates[0]["source_columns"] == ["DB.SRC.CONTACTS.REGION_CODE"]
    assert candidates[0]["confidence"] < 0.8
    assert "business applicability" in candidates[0]["reason"]


def test_historical_source_cte_overrides_stale_snapshot_driving_table():
    from app.agent_tools.workbench import _historical_sql_driving_source
    sql=('WITH SOURCE AS (SELECT c.ID FROM DB.SRC.CONTACTS c '
         'JOIN DB.SRC.ADDRESSES a ON c.ID=a.CONTACT_ID) SELECT ID FROM SOURCE')
    assert _historical_sql_driving_source(sql,['DB.SRC.ADDRESSES','DB.SRC.CONTACTS'])=='DB.SRC.CONTACTS'
    assert _historical_sql_driving_source(sql,['DB.SRC.ADDRESSES']) is None


def test_unused_historical_ctes_do_not_expand_active_source_graph():
    from app.agent_tools.workbench import _active_sql_lineage
    from app.core.sql_parser import parse_sql_document
    sql=(
        'WITH UnusedMaster AS (SELECT ID FROM DB.SRC.UNUSED), '
        'Billing AS (SELECT CONTACT_ID FROM DB.SRC.ADDRESSES), '
        'SOURCE AS (SELECT c.ID FROM DB.SRC.CONTACTS c '
        'LEFT JOIN Billing b ON b.CONTACT_ID=c.ID) '
        'SELECT s.ID FROM SOURCE s LEFT JOIN DB.SRC.COUNTRY_CODES cc ON cc.ID=s.ID'
    )
    references, active_ctes = _active_sql_lineage(sql,parse_sql_document(sql))
    assert set(references)=={
        'DB.SRC.CONTACTS','DB.SRC.ADDRESSES','DB.SRC.COUNTRY_CODES',
    }
    assert 'DB.SRC.UNUSED' not in references
    assert active_ctes == {'BILLING', 'SOURCE'}


def test_historical_join_evidence_preserves_scoped_column_pairs():
    from app.core.sql_parser import parse_sql_document
    sql = (
        'SELECT c.ID FROM DB.SRC.CONTACTS c '
        'LEFT JOIN DB.SRC.CONTACT_FAMILY_MEMBERS m '
        'ON m.CONTACT_ID = c.ID AND m.DELETED = FALSE'
    )
    joins = parse_sql_document(sql).join_patterns
    assert len(joins) == 1
    assert joins[0].column_pairs == [
        {'left_column': 'ID', 'right_column': 'CONTACT_ID'},
    ]
    ambiguous = parse_sql_document(
        'SELECT c.ID FROM DB.SRC.CONTACTS c JOIN DB.SRC.MEMBERS m '
        'ON m.CONTACT_ID = c.ID OR m.LEGACY_ID = c.ID'
    ).join_patterns
    assert ambiguous[0].column_pairs == []


def test_historical_join_aliases_are_local_to_each_cte_select():
    from app.core.sql_parser import parse_sql_document

    sql = (
        'WITH first AS (SELECT a.ID FROM DB.ONE.EVENTS a '
        'JOIN DB.ONE.CATEGORIES x ON x.ID = a.CATEGORY_ID), '
        'second AS (SELECT b.ID FROM DB.TWO.EVENTS b '
        'JOIN DB.TWO.REGION_LOOKUP x ON '
        'TRIM(UPPER(x.ALIAS)) = TRIM(UPPER(b.REGION)) OR '
        'TRIM(UPPER(x.CODE)) = TRIM(UPPER(b.REGION))) '
        'SELECT ID FROM second'
    )
    joins = parse_sql_document(sql).join_patterns
    lookup = next(item for item in joins if item.right_table == 'DB.TWO.REGION_LOOKUP')
    assert lookup.scope_aliases['X'] == 'DB.TWO.REGION_LOOKUP'
    assert lookup.scope_aliases['B'] == 'DB.TWO.EVENTS'
    assert lookup.column_pairs == []


def test_published_join_reuse_requires_current_contract_and_accepted_status():
    from unittest.mock import Mock
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._describe_table = Mock(side_effect=lambda name: {
        'columns': ['ID'] if name.endswith('CONTACTS') else ['CONTACT_ID'],
    })
    selected = ['DB.SRC.CONTACTS', 'DB.SRC.MEMBERS']
    join = {
        'left_table': 'DB.SRC.CONTACTS', 'right_table': 'DB.SRC.MEMBERS',
        'join_type': 'LEFT',
        'conditions': [{'left_column': 'ID', 'right_column': 'CONTACT_ID'}],
    }
    precedents = [
        {'sttm_id': 'draft', 'sttm_status': 'IN_PROGRESS', 'relationships': [join]},
        {'sttm_id': 'published', 'sttm_status': 'COMPLETE', 'relationships': [join]},
        {'sttm_id': 'stale', 'sttm_status': 'PUBLISHED', 'relationships': [
            {**join, 'conditions': [{'left_column': 'OLD_ID', 'right_column': 'CONTACT_ID'}]},
        ]},
    ]
    accepted = handler._published_relationship_evidence(precedents, selected)
    assert len(accepted) == 1
    assert accepted[0]['evidence_ref'] == 'sttm_precedent:published'
    assert accepted[0]['trust_state'] == 'published_current_columns_verified_cardinality_pending'


def test_published_sql_join_is_reusable_without_snapshot_join_when_current():
    from unittest.mock import Mock
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._describe_table = Mock(side_effect=lambda name: {
        'columns': ['ID'] if name.endswith('CONTACTS') else ['CONTACT_ID'],
    })
    accepted = handler._published_relationship_evidence([{
        'sttm_id': 'published', 'sttm_status': 'COMPLETE', 'relationships': [],
        'mapping_sql': 'SELECT c.ID FROM DB.SRC.CONTACTS c LEFT JOIN DB.SRC.MEMBERS m ON c.ID = m.CONTACT_ID',
    }], ['DB.SRC.CONTACTS', 'DB.SRC.MEMBERS'])
    assert len(accepted) == 1
    assert accepted[0]['conditions'] == [{
        'left_column': 'ID', 'right_column': 'CONTACT_ID', 'operator': '=',
    }]
    filtered = handler._published_relationship_evidence([{
        'sttm_id': 'published', 'sttm_status': 'COMPLETE', 'relationships': [],
        'mapping_sql': ('SELECT c.ID FROM DB.SRC.CONTACTS c LEFT JOIN DB.SRC.MEMBERS m '
                        'ON c.ID = m.CONTACT_ID AND m.DELETED = FALSE'),
    }], ['DB.SRC.CONTACTS', 'DB.SRC.MEMBERS'])
    assert filtered == []


def test_completed_precedent_scopes_joins_to_reachable_ctes_and_current_contract():
    from app.agent_tools.workbench import _scoped_precedent_query
    sql = (
        'WITH UNUSED AS (SELECT ID FROM DB.SRC.EXTRA), '
        'DEDUP AS (SELECT a.ID, b.LABEL FROM DB.SRC.ADDRESSES a '
        'LEFT JOIN DB.SRC.CODES b ON b.ID=a.CODE_ID '
        'QUALIFY ROW_NUMBER() OVER (PARTITION BY a.ID ORDER BY b.LABEL)=1) '
        'SELECT c.ID AS HOUSEHOLD_ID, d.LABEL AS COUNTRY '
        'FROM DB.SRC.CONTACTS c LEFT JOIN DEDUP d ON d.ID=c.ID'
    )
    scoped = _scoped_precedent_query(
        sql,
        allowed_sources=['DB.SRC.CONTACTS', 'DB.SRC.ADDRESSES', 'DB.SRC.CODES'],
        target_columns=['HOUSEHOLD_ID', 'COUNTRY'],
    )
    assert set(scoped['physical_sources']) == {
        'DB.SRC.CONTACTS', 'DB.SRC.ADDRESSES', 'DB.SRC.CODES',
    }
    assert scoped['active_ctes'] == ['DEDUP']


def test_small_identifier_source_does_not_establish_full_target_coverage():
    columns = ['KEY', *[f'ATTRIBUTE_{i}' for i in range(25)]]
    result = assess_source_readiness(columns, ['DB.SRC.KEY_MAP'],
        [{'target_column':'KEY','source_columns':['DB.SRC.KEY_MAP.KEY']}], [])
    assert not result['ready_for_analyst']
    assert len(result['unresolved_columns']) == 25


def test_historical_reference_prefers_a_verified_precedent_source():
    from app.agent_tools.source_readiness import resolve_visible_references
    visible = ['DB.CURRENT.CONTACTS', 'DB.ARCHIVE.CONTACTS']
    resolved, unresolved = resolve_visible_references(
        ['CONTACTS'], visible, ['DB.CURRENT.CONTACTS'],
    )
    assert resolved == ['DB.CURRENT.CONTACTS']
    assert unresolved == []
    assert resolve_visible_references(['CONTACTS'], visible) == ([], ['CONTACTS'])


def test_disconnected_sources_are_not_approvable_from_unrelated_joins():
    from app.agent_tools.source_readiness import disconnected_plan_sources
    relationships = [{
        'left_table': {'database': 'DB', 'schema': 'SRC', 'table': 'CONTACTS'},
        'right_table': {'database': 'DB', 'schema': 'SRC', 'table': 'STATUS'},
        'conditions': [{'left_column': 'STATUS_ID', 'right_column': 'ID'}],
    }, {
        'left_table': 'DB.SRC.ADDRESSES',
        'right_table': 'DB.SRC.COUNTRY_CODES',
        'conditions': [{'left_column': 'COUNTRY', 'right_column': 'CODE'}],
    }]
    assert disconnected_plan_sources('DB.SRC.CONTACTS', [
        'DB.SRC.STATUS', 'DB.SRC.ADDRESSES', 'DB.SRC.COUNTRY_CODES',
    ], relationships) == ['DB.SRC.ADDRESSES', 'DB.SRC.COUNTRY_CODES']


def test_multisource_lineage_must_be_visible_even_if_one_candidate_covers_target():
    rows = [{'target_column':'NAME','source_columns':['DB.SRC.PARTY.NAME']},
            {'target_column':'NAME','source_columns':['DB.SRC.HISTORY.NAME']}]
    result = assess_source_readiness(['NAME'], ['DB.SRC.PARTY'], rows, [])
    assert result['missing_source_tables'] == ['DB.SRC.HISTORY']
    assert not result['ready_for_analyst']


def test_constants_allow_different_column_counts_without_claiming_business_approval():
    rows = [{'target_column':'KEY','source_columns':['DB.SRC.KEY_MAP.KEY']},
            {'target_column':'FLAG','mapping_mode':'constant','constant_value':False}]
    result = assess_source_readiness(['KEY','FLAG'], ['DB.SRC.KEY_MAP'], rows, [])
    assert result['ready_for_analyst']
    assert not result['business_correctness_verified']


def test_command_ids_fit_existing_schema_and_preserve_legacy_idempotency():
    run_id = 'run_' + 'a'*32
    values = dict(command_id=f'{run_id}:project.create_draft:migration_run:{run_id}',
                  run_id=run_id, step_id='project.create_draft', operation='project.create_draft',
                  subject_key='migration_run:'+run_id, actor=AgentActor(app_user_id='user',effective_role='EDITOR'),
                  payload={'name':'generic project'})
    first = AgentCommand(**values)
    assert len(first.command_id) == 64
    assert AgentCommand(**values).command_id == first.command_id
    assert AgentCommand(**{**values,'command_id':'short-existing-id'}).command_id == 'short-existing-id'
    assert AgentCommand(**{**values,'command_id':'short-existing-id'}).idempotency_key == first.idempotency_key
    assert AgentCommand.model_validate(first.model_dump()).command_id == first.command_id


def test_historical_sql_recovers_missing_picker_sources_without_guessing_schema():
    from app.agent_tools.source_readiness import resolve_visible_references
    resolved, unresolved = resolve_visible_references(['SRC.PARTY','COUNTRY_CODES','MISSING'],
        ['DB.SRC.PARTY','DB.LOOKUP.COUNTRY_CODES','OTHER.LOOKUP.COUNTRY_CODES'])
    assert resolved == ['DB.SRC.PARTY']
    assert unresolved == ['COUNTRY_CODES','MISSING']


def test_legacy_graph_learning_is_structured_without_promoting_trust():
    from app.core.learning_normalization import normalize_legacy_learning
    record={'LEARNING_ID':'legacy-cte','LEARNING_TYPE':'cte_lineage','TRUST_STAGE':'evidence',
            'ATTRIBUTES':{'target_table':'DB.TGT.PARTY','source_tables':['DB.SRC.PARTY'],
                          'cte_sql':'SELECT KEY FROM DB.SRC.PARTY'},'CONFIDENCE':0.99}
    normalized=normalize_legacy_learning(record)
    assert normalized['subject_key'].startswith('cte_lineage:DB.TGT.PARTY:')
    assert normalized['trust_stage']=='evidence'
    assert normalized['structured_rule']['cte_sql']=='SELECT KEY FROM DB.SRC.PARTY'
    assert normalize_legacy_learning(record)==normalized
    assert 'SUBJECT_KEY' not in record


def test_evidence_preparation_discovers_precedents_and_sql_sources_without_model_project_ids():
    from types import SimpleNamespace
    from unittest.mock import Mock
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_runs.models import ToolResult
    handler=WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock=threading.RLock()
    handler._learning=None
    handler._tool=Mock()
    handler._describe_table=Mock(return_value={'columns':['KEY','NAME'],'column_contracts':[]})
    handler._describe_tables=Mock(return_value={})
    snapshot={'source_tables':['DB.SRC.KEY_MAP'],
              'mapping_sql':('WITH BillingAddress AS (SELECT KEY FROM DB.SRC.PARTY), '
                             'FamilyHOH AS (SELECT p.KEY, p.NAME FROM DB.SRC.PARTY p '
                             'JOIN BillingAddress b ON p.KEY=b.KEY) '
                             'SELECT f.KEY, f.NAME FROM FamilyHOH f JOIN DB.SRC.KEY_MAP m ON f.KEY=m.KEY'),
              'derived_sources':[{'id':'sql-cte:BillingAddress','name':'BillingAddress'},
                                 {'id':'sql-cte:FamilyHOH','name':'FamilyHOH'}],
              'mapping_rows':[{'target_column':'KEY','source_columns':['DB.SRC.KEY_MAP.KEY']},
                              {'target_column':'NAME','source_columns':['DB.SRC.PARTY.NAME']}]}
    detail=SimpleNamespace(latest_snapshot=snapshot,sources=[],mapping_rows=[],
        sttm=SimpleNamespace(sttm_name='prior',target_table='DB.TGT.PARTY',coverage_percent=100))
    weak_detail=SimpleNamespace(latest_snapshot={
        'source_tables':['DB.SRC.SMALL_MAP'],
        'mapping_rows':[{'target_column':'KEY','source_columns':['DB.SRC.SMALL_MAP.KEY']}],
    },sources=[],mapping_rows=[],
        sttm=SimpleNamespace(sttm_name='incomplete mapper',target_table='DB.TGT.PARTY',coverage_percent=100))
    handler._projects=SimpleNamespace(find_target_precedent_projects=Mock(return_value=['project']),
                                     get_sttm_detail=Mock(side_effect=lambda sttm_id: (
                                         weak_detail if sttm_id == 'weak-sttm' else detail)))
    handler.get_project_context=Mock(return_value=ToolResult(status='succeeded',summary='Prior',data={
        'project':{'project_name':'Prior'},'mappings':[
            {'sttm_id':'weak-sttm','target_table':'DB.TGT.PARTY','coverage_percent':100},
            {'sttm_id':'prior-sttm','target_table':'DB.TGT.PARTY','coverage_percent':100},
        ]}))
    handler._session=Mock()
    handler._session.sql.return_value.collect.return_value=[
        {'database_name':'DB','schema_name':'SRC','name':'KEY_MAP'},
        {'database_name':'DB','schema_name':'SRC','name':'SMALL_MAP'},
        {'database_name':'DB','schema_name':'SRC','name':'PARTY'}]
    handler.retrieve_fir_evidence=Mock(return_value=ToolResult(status='succeeded',summary='FIR',data={'cards':[]}))
    handler.read_stored_semantic_context=Mock(return_value=ToolResult(status='succeeded',summary='No registry',data={'status':'unavailable'}))
    handler.search_workbench_rag=Mock(return_value=ToolResult(status='succeeded',summary='No documents',data={'hits':[]}))
    handler.ask_sql_analyst=Mock()
    result=handler.prepare_migration_evidence({'run_id':'run','prompt':'Map party','authorized_schemas':['DB.SRC']},
        source_tables=['DB.SRC.KEY_MAP'],target_table='DB.TGT.PARTY')
    assert result.data['source_tables']==['DB.SRC.KEY_MAP']
    assert 'DB.SRC.PARTY' in result.data['historical_source_candidates']
    assert any(item['table'] == 'DB.SRC.PARTY' and item['target_column_lineage_count'] >= 1
               for item in result.data['source_candidate_evidence'])
    assert not result.data['source_readiness']['ready_for_analyst']
    assert result.data['exact_target_precedents'][0]['mapping_row_count']==2
    assert result.data['exact_target_precedents'][0]['sttm_id']=='prior-sttm'
    assert any(item['evidence_id'] == 'sttm_precedent:weak-sttm'
               and item['target_column'] == 'KEY'
               for item in result.data['plan_candidate']['auto_map']['mapping_evidence'])
    preparation=result.data['plan_candidate']['source_preparation']
    assert not any('derived source requires SQL recovery' in value.lower()
                   for value in preparation['unresolved_items'])
    assert preparation['derived_sources']==[]
    assert preparation['relationships']==[]
    assert not preparation['precedent_reference']
    assert result.data['historical_derived_candidates']
    handler._projects.find_target_precedent_projects.assert_called_once()
    handler.ask_sql_analyst.assert_not_called()  # Incomplete semantics cannot be bypassed by source coverage.

    unselected=handler.prepare_migration_evidence({'run_id':'run2','prompt':'Map party','authorized_schemas':['DB.SRC']},
        source_tables=[],target_table='DB.TGT.PARTY')
    assert unselected.data['source_tables']==[]
    assert unselected.data['historical_source_candidates']
    assert unselected.data['source_readiness']['missing_source_tables'] == []
    assert not unselected.data['source_readiness']['ready_for_analyst']
    assert unselected.data['plan_candidate']['source_preparation']['driving_source'] is None
    assert unselected.data['plan_candidate']['execution_steps'][0]['sql'] is None
    assert any('current driving source' in item.lower() for item in unselected.data['plan_candidate']['source_preparation']['unresolved_items'])


def test_named_driver_expands_exact_target_precedent_and_keeps_firm_value_unresolved():
    from types import SimpleNamespace
    from unittest.mock import Mock
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_runs.models import ToolResult

    sql = ("SET FirmId = 1101;\nWITH Billing AS (SELECT CONTACT_ID, CITY FROM DB.SRC.ADDRESSES), "
           "SOURCE AS (SELECT c.ID, b.CITY FROM DB.SRC.CONTACTS c "
           "LEFT JOIN Billing b ON c.ID=b.CONTACT_ID) "
           "SELECT s.ID AS HOUSEHOLD_ID, s.CITY AS BILLINGCITY, $FirmId AS FIRM_ID, "
           "'legacy' AS SOURCE_FLAG, '001-legacy-firm' AS TRANSACTION_FIRM__C FROM SOURCE s")
    snapshot = {
        'source_tables': ['DB.SRC.CONTACTS', 'DB.SRC.ADDRESSES'],
        'mapping_sql': sql,
        'mapping_rows': [
            {'target_column': 'HOUSEHOLD_ID', 'source_columns': ['DB.SRC.CONTACTS.ID']},
            {'target_column': 'BILLINGCITY', 'source_columns': ['DB.SRC.ADDRESSES.CITY']},
            {'target_column': 'FIRM_ID', 'mapping_mode': 'constant', 'constant_value': '$FirmId'},
            {'target_column': 'SOURCE_FLAG', 'mapping_mode': 'constant', 'constant_value': 'legacy'},
            {'target_column': 'TRANSACTION_FIRM__C', 'mapping_mode': 'constant',
             'constant_value': '001-legacy-firm'},
        ],
    }
    detail = SimpleNamespace(latest_snapshot=snapshot, sources=[], mapping_rows=[],
        sttm=SimpleNamespace(sttm_name='prior', target_table='DB.TGT.HOUSEHOLD',
                             coverage_percent=100, status='COMPLETE', project_id='old-project'))
    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.RLock()
    handler._learning = None
    handler._tool = Mock()
    handler._describe_tables = Mock(return_value={})
    handler._describe_table = Mock(side_effect=lambda table: {
        'columns': ['HOUSEHOLD_ID', 'BILLINGCITY', 'FIRM_ID', 'SOURCE_FLAG', 'TRANSACTION_FIRM__C']
                   if table == 'DB.TGT.HOUSEHOLD'
                   else ['ID', 'CONTACT_ID', 'CITY'],
        'column_contracts': [],
    })
    handler._projects = SimpleNamespace(
        find_target_precedent_projects=Mock(return_value=['old-project']),
        get_sttm_detail=Mock(return_value=detail),
    )
    handler.get_project_context = Mock(return_value=ToolResult(status='succeeded', summary='Prior', data={
        'project': {'project_name': 'Prior'},
        'mappings': [{'sttm_id': 'prior-sttm', 'target_table': 'DB.TGT.HOUSEHOLD',
                      'status': 'COMPLETE', 'coverage_percent': 100}],
    }))
    handler._session = Mock()
    handler._session.sql.return_value.collect.return_value = [
        {'database_name': 'DB', 'schema_name': 'SRC', 'name': name}
        for name in ('CONTACTS', 'ADDRESSES')
    ]
    join = {'left_table': 'DB.SRC.CONTACTS', 'right_table': 'DB.SRC.ADDRESSES',
            'join_type': 'LEFT', 'conditions': [{'left_column': 'ID', 'right_column': 'CONTACT_ID'}],
            'source': 'SEMANTIC_REGISTRY'}
    handler.retrieve_fir_evidence = Mock(return_value=ToolResult(status='succeeded', summary='FIR', data={'cards': []}))
    handler.discover_current_relationships = Mock(return_value=ToolResult(status='succeeded', summary='Joins',
        data={'active': [join], 'recommendations': []}))
    handler.read_stored_semantic_context = Mock(return_value=ToolResult(status='succeeded', summary='Semantic',
        data={'status': 'available', 'analyst_ready': True, 'verified_relationships': [join]}))
    handler.search_workbench_rag = Mock(return_value=ToolResult(status='succeeded', summary='RAG', data={'hits': []}))
    handler.ask_sql_analyst = Mock(return_value=ToolResult(status='failed', summary='No SQL'))

    result = handler.prepare_migration_evidence(
        {'run_id': 'run', 'prompt': 'Map household using CONTACTS', 'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.CONTACTS'], target_table='DB.TGT.HOUSEHOLD',
    )
    source = result.data['plan_candidate']['source_preparation']
    assert source['driving_source'] == 'DB.SRC.CONTACTS'
    assert source['supporting_sources'] == ['DB.SRC.ADDRESSES']
    assert source['relationships']
    assert any(item['source'] == 'HISTORICAL_CTE_KEY_CANDIDATE'
               and item['left_table']['table'] == 'CONTACTS'
               and item['right_table']['table'] == 'ADDRESSES'
               for item in result.data['historical_relationship_candidates'])
    assert {item['name'] for item in source['derived_sources']} >= {'Billing', 'SOURCE'}
    assert source['source_rationale']['DB.SRC.ADDRESSES']
    binding = next(item for item in source['value_bindings'] if item['name'] == 'FirmId')
    assert binding['candidate_value'] == '1101'

    assert binding['resolved_value'] is None
    assert binding['target_columns'] == ['FIRM_ID']
    assert all(item['name'] != 'constant_SOURCE_FLAG' for item in source['value_bindings'])
    transaction_firm = next(item for item in source['value_bindings']
                            if item['name'] == 'TransactionFirmID')
    assert transaction_firm['target_columns'] == ['TRANSACTION_FIRM__C']
    assert all(item['name'] != 'constant_TRANSACTION_FIRM__C' for item in source['value_bindings'])
    assert any(item['subject'] == 'value_binding' for item in result.data['plan_candidate']['decisions'])
    handler._projects.list_project_attributes = Mock(return_value=[
        SimpleNamespace(attribute_name='FirmId', attribute_value='2202', attribute_type='INT'),
        SimpleNamespace(attribute_name='constant_SOURCE_FLAG', attribute_value='current', attribute_type='VARCHAR'),
        SimpleNamespace(attribute_name='TransactionFirmID', attribute_value='001-current-firm',
                        attribute_type='VARCHAR'),
    ])
    applicable = handler.prepare_migration_evidence(
        {'run_id': 'run-current', 'project_id': 'current-project',
         'prompt': 'Map household using CONTACTS', 'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.CONTACTS'], target_table='DB.TGT.HOUSEHOLD',
    )
    current_source = applicable.data['plan_candidate']['source_preparation']
    assert {item['resolved_value'] for item in current_source['value_bindings']} == {
        '2202', 'current', '001-current-firm'}
    assert all(item['subject'] != 'value_binding' for item in applicable.data['plan_candidate']['decisions'])
    different_grain = handler.prepare_migration_evidence(
        {'run_id': 'run-addresses', 'prompt': 'Map household using ADDRESSES',
         'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.ADDRESSES'], target_table='DB.TGT.HOUSEHOLD',
    )
    different_source = different_grain.data['plan_candidate']['source_preparation']
    assert different_source['driving_source'] == 'DB.SRC.ADDRESSES'
    assert different_source['precedent_reference'] == {}
    assert 'DB.SRC.CONTACTS' not in different_source['supporting_sources']
    handler.retrieve_fir_evidence = Mock(return_value=ToolResult(status='succeeded', summary='FIR', data={
        'cards': [{'learning_id': 'accepted-lineage', 'target_column': 'SOURCE_FLAG',
                   'approval_state': 'approved',
                   'source_columns': ['DB.SRC.CONTACTS.ID']}],
    }))
    fir_expanded = handler.prepare_migration_evidence(
        {'run_id': 'run-fir', 'prompt': 'Map household using ADDRESSES',
         'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.ADDRESSES'], target_table='DB.TGT.HOUSEHOLD',
    ).data['plan_candidate']['source_preparation']
    assert fir_expanded['driving_source'] == 'DB.SRC.ADDRESSES'
    assert fir_expanded['supporting_sources'] == ['DB.SRC.CONTACTS']
    assert 'accepted-lineage' in fir_expanded['source_rationale']['DB.SRC.CONTACTS']
    handler.retrieve_fir_evidence = Mock(return_value=ToolResult(status='succeeded', summary='FIR', data={
        'cards': [
            {'learning_id': 'accepted-lineage', 'target_column': 'SOURCE_FLAG',
             'approval_state': 'approved', 'source_columns': ['DB.SRC.CONTACTS.ID']},
            {'learning_id': 'competing-lineage', 'target_column': 'SOURCE_FLAG',
             'approval_state': 'approved', 'source_columns': ['DB.SRC.ADDRESSES.ID']},
        ],
    }))
    ambiguous_fir = handler.prepare_migration_evidence(
        {'run_id': 'run-fir-conflict', 'prompt': 'Map household using ADDRESSES',
         'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.ADDRESSES'], target_table='DB.TGT.HOUSEHOLD',
    ).data['plan_candidate']['source_preparation']
    assert 'DB.SRC.CONTACTS' not in ambiguous_fir['supporting_sources']
    handler.retrieve_fir_evidence = Mock(return_value=ToolResult(status='succeeded', summary='FIR', data={'cards': []}))
    alternate_join = {**join, 'conditions': [{'left_column': 'ID', 'right_column': 'CITY'}],
                      'source': 'PUBLISHED_PRECEDENT'}
    handler.read_stored_semantic_context = Mock(return_value=ToolResult(status='succeeded', summary='Semantic',
        data={'status': 'available', 'analyst_ready': True, 'verified_relationships': [alternate_join]}))
    conflicted = handler.prepare_migration_evidence(
        {'run_id': 'run-conflict', 'project_id': 'current-project',
         'prompt': 'Map household using CONTACTS', 'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.CONTACTS'], target_table='DB.TGT.HOUSEHOLD',
    )
    join_decision = next(item for item in conflicted.data['plan_candidate']['decisions']
                         if item['subject'] == 'join')
    assert len(join_decision['alternatives']) == 1
    assert join_decision['alternatives'][0]['relationship']['conditions'][0]['right_column'] == 'CONTACT_ID'
    assert not any('disagree on join keys' in item
                   for item in conflicted.data['plan_candidate']['source_preparation']['unresolved_items'])
    handler._describe_table = Mock(side_effect=lambda table: {
        'columns': ['HOUSEHOLD_ID', 'BILLINGCITY', 'FIRM_ID', 'SOURCE_FLAG', 'TRANSACTION_FIRM__C']
                   if table == 'DB.TGT.HOUSEHOLD'
                   else ['ID', 'CONTACT_ID'] if table == 'DB.SRC.ADDRESSES'
                   else ['ID', 'CONTACT_ID', 'CITY'],
        'column_contracts': [],
    })
    stale = handler.prepare_migration_evidence(
        {'run_id': 'run-stale', 'prompt': 'Map household using CONTACTS', 'authorized_schemas': ['DB.SRC']},
        source_tables=['DB.SRC.CONTACTS'], target_table='DB.TGT.HOUSEHOLD',
    )
    assert any('DB.SRC.ADDRESSES.CITY' in item
               for item in stale.data['plan_candidate']['source_preparation']['unresolved_items'])


def test_precedent_lookup_join_candidates_follow_cte_lineage_without_named_tables():
    from types import SimpleNamespace
    from unittest.mock import Mock
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_runs.models import ToolResult
    from app.agent_tools.join_research import research_questions

    event, location, lookup, user_map = ('DB.SRC.EVENTS', 'DB.SRC.LOCATIONS',
                                         'DB.SRC.REGION_LOOKUP', 'DB.SRC.USER_MAP')
    sql = (
        'WITH users AS (SELECT * FROM DB.SRC.USER_MAP), '
        "prepared AS (SELECT e.ID, l.REGION, 'No' AS STATUS_FLAG FROM DB.SRC.EVENTS e "
        'LEFT JOIN DB.SRC.LOCATIONS l ON e.LOCATION_ID = l.ID '
        'LEFT JOIN users u ON u.ID = e.OWNER_ID) '
        'SELECT p.ID AS EVENT_ID, r.LABEL AS REGION_LABEL, p.STATUS_FLAG AS EVENT_FLAG FROM prepared p '
        'LEFT JOIN DB.SRC.REGION_LOOKUP r ON '
        'TRIM(UPPER(p.REGION)) = TRIM(UPPER(r.ALIAS)) OR '
        'TRIM(UPPER(p.REGION)) = TRIM(UPPER(r.CODE))'
    )
    snapshot = {'source_tables': [event, location, lookup, user_map], 'mapping_sql': sql,
                'mapping_rows': [{'target_column': 'EVENT_ID', 'source_columns': [f'{event}.ID']},
                                 {'target_column': 'REGION_LABEL', 'source_columns': [f'{lookup}.LABEL']},
                                 {'target_column': 'EVENT_FLAG', 'source_columns': ['prepared.STATUS_FLAG']}]}
    detail = SimpleNamespace(latest_snapshot=snapshot, sources=[], mapping_rows=[],
        sttm=SimpleNamespace(sttm_name='prior', target_table='DB.TGT.EVENT_RESULT',
                             coverage_percent=100, status='COMPLETE', project_id='old-project'))
    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.RLock()
    handler._learning = None
    handler._tool = Mock()
    handler._describe_tables = Mock(return_value={})
    handler._describe_table = Mock(side_effect=lambda table: {
        'columns': ['EVENT_ID', 'REGION_LABEL', 'EVENT_FLAG'] if table == 'DB.TGT.EVENT_RESULT'
                   else ['ID', 'LOCATION_ID', 'OWNER_ID'] if table == event
                   else ['ID', 'REGION'] if table == location
                   else ['ID'] if table == user_map
                   else ['CODE', 'ALIAS', 'LABEL'],
        'column_contracts': [],
    })
    handler._projects = SimpleNamespace(
        find_target_precedent_projects=Mock(return_value=['old-project']),
        get_sttm_detail=Mock(return_value=detail),
    )
    handler.get_project_context = Mock(return_value=ToolResult(status='succeeded', summary='Prior', data={
        'project': {'project_name': 'Prior'},
        'mappings': [{'sttm_id': 'prior-sttm', 'target_table': 'DB.TGT.EVENT_RESULT',
                      'status': 'COMPLETE', 'coverage_percent': 100}],
    }))
    handler._session = Mock()
    handler._session.sql.return_value.collect.return_value = [
        {'database_name': 'DB', 'schema_name': 'SRC', 'name': name}
        for name in ('EVENTS', 'LOCATIONS', 'REGION_LOOKUP', 'USER_MAP')
    ]
    handler.retrieve_fir_evidence = Mock(return_value=ToolResult(status='succeeded', summary='FIR', data={'cards': []}))
    handler.discover_current_relationships = Mock(return_value=ToolResult(status='succeeded', summary='Joins',
        data={'active': [], 'recommendations': []}))
    handler.read_stored_semantic_context = Mock(return_value=ToolResult(status='succeeded', summary='Semantic',
        data={'status': 'unavailable', 'analyst_ready': False, 'verified_relationships': []}))
    handler.search_workbench_rag = Mock(return_value=ToolResult(status='succeeded', summary='RAG', data={'hits': []}))
    handler.ask_sql_analyst = Mock(return_value=ToolResult(status='failed', summary='No SQL'))

    result = handler.prepare_migration_evidence(
        {'run_id': 'run', 'prompt': 'Map events using EVENTS', 'authorized_schemas': ['DB.SRC']},
        source_tables=[event], target_table='DB.TGT.EVENT_RESULT',
    )
    candidates = result.data['historical_relationship_candidates']
    flag = next(item for item in result.data['plan_candidate']['auto_map']['mapping_evidence']
                if item['target_column'] == 'EVENT_FLAG')
    assert flag['source_columns'] == []
    assert flag['mapping_mode'] == 'constant'
    assert flag['constant_value'] == 'No'
    assert all(binding['name'] != 'constant_EVENT_FLAG'
               for binding in result.data['plan_candidate']['source_preparation']['value_bindings'])
    lookup_join = next((item for item in candidates if item.get('normalized_lookup_alternative') == 'CODE'), None)
    assert lookup_join is not None, (candidates, result.data['plan_candidate']['source_preparation']['supporting_sources'],
                                     result.data['plan_candidate']['source_preparation']['precedent_reference'])
    assert lookup_join['left_table']['table'] == 'LOCATIONS'
    assert lookup_join['right_table']['table'] == 'REGION_LOOKUP'
    assert lookup_join['conditions'][0]['left_column'] == 'REGION'
    assert any(item['left_table']['table'] == 'EVENTS' and item['right_table']['table'] == 'LOCATIONS'
               for item in candidates)
    assert any(item['left_table']['table'] == 'EVENTS' and item['right_table']['table'] == 'USER_MAP'
               for item in candidates)
    questions = research_questions(result.model_dump(mode='json'))
    assert any(question['target'] == lookup and question['options'] for question in questions)


def test_verified_semantic_graph_reaches_plan_and_analyst_before_column_mapping():
    from types import SimpleNamespace
    from unittest.mock import Mock
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_runs.models import ToolResult

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.RLock()
    handler._learning = None
    handler._tool = Mock()
    handler._settings = SimpleNamespace(migration_agent_precedent_project_limit=5)
    handler._describe_table = Mock(return_value={'columns':['ID','NAME'], 'column_contracts':[]})
    handler._describe_tables = Mock(return_value={})
    handler._projects = SimpleNamespace(find_target_precedent_projects=Mock(return_value=[]))
    handler._session = Mock()
    handler._session.sql.return_value.collect.return_value = [
        {'database_name':'DB','schema_name':'SRC','name':'FAMILIES'},
        {'database_name':'DB','schema_name':'SRC','name':'CONTACTS'},
    ]
    join = {
        'left_table': {'database':'DB','schema':'SRC','table':'FAMILIES'},
        'right_table': {'database':'DB','schema':'SRC','table':'CONTACTS'},
        'conditions': [{'left_column':'ID','right_column':'FAMILY_ID','operator':'='}],
        'source': 'SEMANTIC_REGISTRY',
    }
    handler.retrieve_fir_evidence = Mock(return_value=ToolResult(status='succeeded', summary='FIR', data={'cards':[]}))
    handler.read_stored_semantic_context = Mock(return_value=ToolResult(status='succeeded', summary='Stored', data={
        'status':'available', 'analyst_ready':True, 'verified_relationships':[join],
    }))
    handler.discover_current_relationships = Mock(return_value=ToolResult(status='succeeded', summary='Current joins',
        data={'active':[join], 'recommendations':[]}))
    handler.search_workbench_rag = Mock(return_value=ToolResult(status='succeeded', summary='RAG', data={'hits':[]}))
    handler.ask_sql_analyst = Mock(return_value=ToolResult(status='succeeded', summary='Draft SQL', data={
        'sql':'SELECT f.ID, c.NAME FROM DB.SRC.FAMILIES f JOIN DB.SRC.CONTACTS c ON f.ID = c.FAMILY_ID',
    }))

    result = handler.prepare_migration_evidence({'run_id':'run', 'prompt':'Map household'},
        source_tables=['DB.SRC.FAMILIES','DB.SRC.CONTACTS'], target_table='DB.TGT.HOUSEHOLD')
    source = result.data['plan_candidate']['source_preparation']
    assert source['relationships'] == [join]
    assert source['unresolved_items'] == []
    assert result.data['source_readiness']['unresolved_columns'] == ['ID','NAME']
    assert result.data['analyst_eligibility']['eligible'] is True
    handler.ask_sql_analyst.assert_called_once()


def test_semantic_reader_excludes_unsafe_registry_join_from_verified_plan_evidence():
    from types import SimpleNamespace
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.semantic_context import SemanticBundleStatus

    safe = {
        'left_table': {'database':'DB','schema':'SRC','table':'FAMILIES'},
        'right_table': {'database':'DB','schema':'SRC','table':'CONTACTS'},
        'conditions':[{'left_column':'ID','right_column':'FAMILY_ID'}],
        'source':'SEMANTIC_REGISTRY',
    }
    unsafe = {
        'left_table': {'database':'DB','schema':'SRC','table':'CONTACTS'},
        'right_table': {'database':'DB','schema':'SRC','table':'ADDRESSES'},
        'conditions':[{'left_column':'ID','right_column':'CONTACT_ID'}],
        'source':'SEMANTIC_REGISTRY',
    }
    class Semantic:
        def refresh_bundle(self, _request, **_kwargs):
            return SimpleNamespace(bundle_id='bundle',bundle_hash='hash', semantic_view_name=None,
                status=SemanticBundleStatus.READY,
                summary=SimpleNamespace(source_table_count=3, relationship_count=2,
                    composed_model_hash='model', tables=[]),
                semantic_context=[], reading_instructions=None, warnings=[], analyst_ready=False,
                excluded_relationships=[{'relationship':unsafe,'reason':'uniqueness unproven'}])
        def get_projection(self, _request):
            return SimpleNamespace(payload={'relationships':[safe,unsafe]},projection_id='projection',projection_hash='hash')
    handler = WorkbenchWorkflowHandlers(repository=object(),project_service=object(),session=object(),
        semantic_context=Semantic())
    result = handler.read_stored_semantic_context({'run_id':'run','app_user_id':'user','effective_role':'EDITOR'},
        source_tables=['DB.SRC.FAMILIES','DB.SRC.CONTACTS','DB.SRC.ADDRESSES'], target_table='DB.TGT.HOUSEHOLD')
    assert result.data['verified_relationships'] == [safe]
    assert result.data['excluded_relationship_count'] == 1


def test_current_relationship_discovery_reuses_active_service_and_checks_columns(monkeypatch):
    from types import SimpleNamespace
    from unittest.mock import Mock
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.common import TableRef
    from app.schema.table_selection import RelationshipItem, RelationshipColumnMapping
    import app.core.table_selection as table_selection

    left = TableRef(database='DB', schema='SRC', table='FAMILIES')
    right = TableRef(database='DB', schema='SRC', table='CONTACTS')
    active = RelationshipItem(id='active', left_table=left, right_table=right,
        conditions=[RelationshipColumnMapping(left_column='ID', right_column='FAMILY_ID')],
        source='SEMANTIC_VIEW', review_required=False)
    reviewed = RelationshipItem(id='review', left_table=left, right_table=right,
        conditions=[RelationshipColumnMapping(left_column='ALT_ID', right_column='FAMILY_ID')],
        source='SEMANTIC_VIEW', review_required=True, review_reason='ambiguous key')
    service = Mock()
    service.list_relationship_discovery_for_tables.return_value = ([active], [active, reviewed])
    monkeypatch.setattr(table_selection, 'TableSelectionService', lambda *_args, **_kwargs: service)
    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._settings = SimpleNamespace(migration_agent_contract_batch_limit=8)
    handler._session = object()
    handler._domain_lock = threading.RLock()
    handler._tool = Mock()
    handler._describe_table = Mock(side_effect=lambda table: {
        'columns':['ID'] if table.endswith('FAMILIES') else ['FAMILY_ID'],
    })
    result = handler.discover_current_relationships({'run_id':'run', 'app_user_id':'user'},
        ['DB.SRC.FAMILIES','DB.SRC.CONTACTS'])
    assert result.status == 'succeeded'
    assert [item['id'] for item in result.data['active']] == ['active']
    assert result.data['active'][0]['trust_state'] == 'current_columns_verified_cardinality_pending'
    assert [item['id'] for item in result.data['recommendations']] == ['review']
    assert result.data['still_disconnected'] == []


def test_disconnected_sources_surface_scoped_semantic_bridge_candidates(monkeypatch):
    from types import SimpleNamespace
    from unittest.mock import Mock
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.core.semantic_knowledge_resolver import SemanticKnowledgeResolver
    import app.core.table_selection as table_selection

    service = Mock()
    service.list_relationship_discovery_for_tables.return_value = ([], [])
    monkeypatch.setattr(table_selection, 'TableSelectionService', lambda *_args, **_kwargs: service)
    monkeypatch.setattr(SemanticKnowledgeResolver, '__init__', lambda *_args: None)
    monkeypatch.setattr(SemanticKnowledgeResolver, 'resolve', lambda *_args: [{
        'fqn': 'DB.SRC.CONTACTS',
        'curated_version': None,
        'relationships': [
            {'related_table': 'DB.SRC.CONTACT_FAMILY_MEMBERS',
             'column_mappings': [{'fk_column': 'CONTACT_ID', 'pk_column': 'ID'}],
             'confidence': 'MEDIUM'},
            {'related_table': 'DB.PRIVATE.SECRET',
             'column_mappings': [{'fk_column': 'ID', 'pk_column': 'CONTACT_ID'}],
             'confidence': 'HIGH'},
        ],
    }])
    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._settings = SimpleNamespace(migration_agent_contract_batch_limit=8)
    handler._session = object()
    handler._domain_lock = threading.RLock()
    handler._tool = Mock()
    handler._describe_table = Mock(side_effect=lambda table: {
        'columns': ['ID'] if table == 'DB.SRC.CONTACTS'
        else ['CONTACT_ID', 'FAMILY_ID'] if table.endswith('CONTACT_FAMILY_MEMBERS')
        else [],
    })
    result = handler.discover_current_relationships(
        {'app_user_id': 'user', 'authorized_schemas': ['DB.SRC']},
        ['DB.SRC.CONTACTS', 'DB.SRC.CONTACT_FAMILIES'],
        visible_tables=['DB.SRC.CONTACTS', 'DB.SRC.CONTACT_FAMILIES',
                        'DB.SRC.CONTACT_FAMILY_MEMBERS', 'DB.PRIVATE.SECRET'],
    )
    assert result.status == 'succeeded'
    assert result.data['active'] == []
    assert result.data['still_disconnected']
    assert [item['related_table'] for item in result.data['expansion_candidates']] == [
        'DB.SRC.CONTACT_FAMILY_MEMBERS',
    ]
    assert result.data['expansion_candidates'][0]['active'] is False
    assert result.data['expansion_candidates'][0]['column_contract_status'] == 'reversed_candidate'
    assert result.data['expansion_candidates'][0]['candidate_conditions'] == [
        {'from_column': 'ID', 'related_column': 'CONTACT_ID'},
    ]


def test_schema_overflow_does_not_offer_an_unchanged_resume():
    from types import SimpleNamespace
    from app.agent_runs.recovery import failure_code,can_resume
    from app.agent_runs.models import RunStatus
    error=RuntimeError("String value is too long and would be truncated")
    assert failure_code(error)=='schema_contract_error'
    legacy=SimpleNamespace(error_code='1304',safe_error=str(error),status=RunStatus.FAILED,
                           resume_attempt=0,cancel_requested_at=None)
    assert not can_resume(legacy)
    legacy.error_code='budget_exhausted'
    legacy.safe_error='Budget exhausted'
    assert can_resume(legacy)
def test_join_research_offers_indirect_candidate_path_and_checks_explicit_rules() -> None:
    from app.agent_tools.join_research import parse_join_rules, research_questions

    driver = "DB.SRC.CONTACTS"
    bridge = "DB.SRC.FAMILIES"
    target = "DB.SRC.ADDRESSES"
    candidate = {
        "data": {
            "plan_candidate": {"source_preparation": {
                "driving_source": driver, "supporting_sources": [bridge, target], "relationships": [],
                "derived_sources": [{"name": "BillingAddress", "base_source_tables": [target]}],
            }},
            "historical_relationship_candidates": [
                {"left_table": driver, "right_table": bridge,
                 "conditions": [{"left_column": "FAMILY_ID", "right_column": "ID"}]},
                {"left_table": bridge, "right_table": target,
                 "conditions": [{"left_column": "ID", "right_column": "FAMILY_ID"}]},
            ],
        },
    }
    questions = research_questions(candidate)
    address = next(item for item in questions if item["target"] == target)
    assert len(address["options"][0]["joins"]) == 2
    assert address["cte_leads"] == ["BillingAddress"]
    parsed = parse_join_rules("CONTACTS.FAMILY_ID = FAMILIES.ID; FAMILIES.ID = ADDRESSES.FAMILY_ID",
                              [driver, bridge, target])
    assert len(parsed) == 2
    assert parsed[1]["right_table"] == target


def test_join_rules_tolerate_the_same_table_listed_more_than_once() -> None:
    from app.agent_tools.join_research import parse_join_rules

    # The clarify step merges driver, target, authorized scope and catalog
    # candidates; the same FQN routinely appears in several of those lists and
    # must not look like two different tables sharing a leaf name.
    selected = ["DB.SRC.CONTACTS", "db.src.contacts", "DB.SRC.CONTACT_FAMILIES",
                "DB.SRC.CONTACT_FAMILY_MEMBERS", "DB.SRC.CONTACTS"]
    parsed = parse_join_rules(
        "CONTACT_FAMILIES.ID = CONTACT_FAMILY_MEMBERS.FAMILY_ID; "
        "CONTACT_FAMILY_MEMBERS.CONTACT_ID = CONTACTS.ID",
        selected,
    )
    assert [(item["left_table"], item["right_table"]) for item in parsed] == [
        ("DB.SRC.CONTACT_FAMILIES", "DB.SRC.CONTACT_FAMILY_MEMBERS"),
        ("DB.SRC.CONTACT_FAMILY_MEMBERS", "DB.SRC.CONTACTS"),
    ]


def test_join_rules_still_reject_a_leaf_name_shared_by_two_schemas() -> None:
    from app.agent_tools.join_research import parse_join_rules

    with pytest.raises(ValueError, match="unambiguous"):
        parse_join_rules("CONTACTS.ID = NOTES.CONTACT_ID",
                         ["DB.SRC_A.CONTACTS", "DB.SRC_B.CONTACTS", "DB.SRC_A.NOTES"])
    qualified = parse_join_rules("DB.SRC_B.CONTACTS.ID = NOTES.CONTACT_ID",
                                 ["DB.SRC_A.CONTACTS", "DB.SRC_B.CONTACTS", "DB.SRC_A.NOTES"])
    assert qualified[0]["left_table"] == "DB.SRC_B.CONTACTS"


def test_join_research_can_offer_catalog_bridge_outside_initial_selection() -> None:
    from app.agent_tools.join_research import research_questions

    driver, bridge, target = "DB.SRC.CONTACTS", "DB.SRC.FAMILIES", "DB.SRC.ADDRESSES"
    prepared = {"data": {
        "plan_candidate": {"source_preparation": {"driving_source": driver,
                                                  "supporting_sources": [target], "relationships": []}},
        "catalog_candidates": [driver, bridge, target],
        "historical_relationship_candidates": [{"left_table": bridge, "right_table": target,
            "conditions": [{"left_column": "ID", "right_column": "FAMILY_ID"}]}],
        "current_relationships": {"expansion_candidates": [{
            "from_table": driver, "related_table": bridge, "column_contract_status": "verified",
            "candidate_conditions": [{"from_column": "FAMILY_ID", "related_column": "ID"}],
        }]},
    }}
    questions = research_questions(prepared)
    assert [item["target"] for item in questions] == [target]
    assert len(questions[0]["options"][0]["joins"]) == 2


def test_join_research_offers_unverified_current_column_candidates_when_catalog_has_no_path() -> None:
    from app.agent_tools.join_research import research_questions

    driver, target = "DB.SRC.CONTACTS", "DB.SRC.FAMILIES"
    prepared = {"data": {"plan_candidate": {"source_preparation": {
        "driving_source": driver, "supporting_sources": [target], "relationships": [],
    }}, "catalog_candidates": [driver, target]}}
    contracts = {driver: {"columns": ["ID", "FAMILY_ID"]}, target: {"columns": ["ID", "NAME"]}}
    question = research_questions(prepared, contracts)[0]
    assert question["options"]
    assert "Low confidence" in question["options"][0]["description"]
    assert question["options"][0]["joins"][0]["source"] == "CURRENT_COLUMN_NAME_PROPOSAL"


def test_join_research_excludes_stale_historical_columns_and_keeps_current_alternatives() -> None:
    from app.agent_tools.join_research import research_questions

    driver, target = "DB.SRC.CONTACTS", "DB.SRC.MEMBERS"
    prepared = {"data": {"plan_candidate": {"source_preparation": {
        "driving_source": driver, "supporting_sources": [target], "relationships": [],
    }}, "catalog_candidates": [driver, target], "historical_relationship_candidates": [
        {"left_table": driver, "right_table": target,
         "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}]},
        {"left_table": driver, "right_table": target,
         "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]},
    ]}}
    contracts = {driver: {"columns": ["ID"]}, target: {"columns": ["ID", "CONTACT_ID"]}}
    options = research_questions(prepared, contracts)[0]["options"]
    assert options
    assert all(join["conditions"][0]["left_column"] != "CONTACT_ID"
               for option in options for join in option["joins"])
    assert any(join["conditions"][0] == {"left_column": "ID", "right_column": "CONTACT_ID", "operator": "="}
               for option in options for join in option["joins"])


def test_join_research_excludes_incompatible_current_key_types() -> None:
    from app.agent_tools.join_research import research_questions

    driver, target = "DB.SRC.CONTACTS", "DB.SRC.FAMILIES"
    prepared = {"data": {"plan_candidate": {"source_preparation": {
        "driving_source": driver, "supporting_sources": [target], "relationships": [],
    }}, "catalog_candidates": [driver, target], "historical_relationship_candidates": [
        {"left_table": driver, "right_table": target,
         "conditions": [{"left_column": "ID", "right_column": "TEXT_ID"}]},
        {"left_table": driver, "right_table": target,
         "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]},
    ]}}
    contracts = {
        driver: {"columns": ["ID"], "column_contracts": [{"name": "ID", "type": "NUMBER"}]},
        target: {"columns": ["TEXT_ID", "CONTACT_ID"], "column_contracts": [
            {"name": "TEXT_ID", "type": "VARCHAR"}, {"name": "CONTACT_ID", "type": "NUMBER"},
        ]},
    }
    options = research_questions(prepared, contracts)[0]["options"]
    assert options
    assert all(join["conditions"][0]["right_column"] != "TEXT_ID"
               for option in options for join in option["joins"])
    assert any(join["conditions"][0]["right_column"] == "CONTACT_ID"
               for option in options for join in option["joins"])


def test_join_research_offers_normalized_code_or_alias_and_parses_reviewed_rule() -> None:
    from app.agent_tools.join_research import parse_join_rules, research_questions

    driver, target = "DB.SRC.EVENTS", "DB.SRC.REGION_LOOKUP"
    prepared = {"data": {"plan_candidate": {"source_preparation": {
        "driving_source": driver, "supporting_sources": [target], "relationships": [],
    }}, "catalog_candidates": [driver, target], "historical_relationship_candidates": [{
        "left_table": driver, "right_table": target,
        "conditions": [{"left_column": "REGION_VALUE", "right_column": "REGION_CODE"}],
        "normalized_lookup_alternative": "REGION_ALIAS", "source": "HISTORICAL_NORMALIZED_LOOKUP_CANDIDATE",
    }]}}
    question = research_questions(prepared)[0]
    option = next(value for value in question["options"] if "code or alias" in value["label"])
    join = option["joins"][0]
    assert join["normalized_lookup_alternative"] == "REGION_ALIAS"
    parsed = parse_join_rules(
        "NORMALIZED_OR(EVENTS.REGION_VALUE, REGION_LOOKUP.REGION_CODE, REGION_LOOKUP.REGION_ALIAS)",
        [driver, target],
    )
    assert parsed[0]["normalized_lookup_alternative"] == "REGION_ALIAS"


def test_selected_fqn_join_candidates_validate_against_current_table_contracts() -> None:
    from unittest.mock import Mock
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.common import TableRef

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._describe_table = Mock(side_effect=lambda _name: {
        'column_contracts': [{'name': 'ID', 'type': 'NUMBER'},
                             {'name': 'PARENT_ID', 'type': 'NUMBER'}],
    })
    parent = TableRef(database='DB', schema='SRC', table='PARENTS')
    child = TableRef(database='DB', schema='SRC', table='CHILDREN')
    relationships, findings, _metrics = handler._validate_source_relationships(
        state={}, source_tables=[parent, child], reconcile=False,
        raw_relationships=[{
            'left_table': parent.qualified_name,
            'right_table': child.qualified_name,
            'join_type': 'LEFT',
            'conditions': [{'left_column': 'ID', 'right_column': 'PARENT_ID', 'operator': '='}],
            'source': 'HISTORICAL_CTE_KEY_CANDIDATE',
        }],
    )
    assert len(relationships) == 1
    assert findings == []


def test_transient_failures_stay_resumable_and_permanent_ones_do_not() -> None:
    from types import SimpleNamespace

    from app.agent_runs.models import RunStatus
    from app.agent_runs.recovery import can_resume, failure_code

    class _SqlError(Exception):
        def __init__(self, code):
            super().__init__("lock wait")
            self.sql_error_code = code

    assert failure_code(TimeoutError("Timed out while flushing durable trace events")) == "transient_failure"
    assert failure_code(ConnectionResetError("reset")) == "transient_failure"
    assert failure_code(_SqlError(625)) == "transient_failure"
    assert failure_code(PermissionError("no")) == "authorization_denied"
    assert failure_code(RuntimeError("unknown")) == "permanent_tool_failure"
    run = SimpleNamespace(status=RunStatus.FAILED, resume_attempt=0, policy=SimpleNamespace(max_resume_attempts=2),
                          cancel_requested_at=None, error_code="transient_failure", safe_error="")
    assert can_resume(run)


def test_precedent_join_columns_take_the_contract_spelling() -> None:
    """TMD scripts write `c.family_id`; quoted as "family_id" the join check and the draft fail to compile."""
    from unittest.mock import Mock
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.common import TableRef

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._describe_table = Mock(side_effect=lambda _name: {
        'column_contracts': [{'name': 'ID', 'type': 'NUMBER'}, {'name': 'FAMILY_ID', 'type': 'NUMBER'},
                             {'name': 'ADDRESSABLE_TYPE', 'type': 'VARCHAR'}],
    })
    parent = TableRef(database='DB', schema='SRC', table='CONTACT_FAMILIES')
    child = TableRef(database='DB', schema='SRC', table='CONTACT_FAMILY_MEMBERS')
    relationships, findings, _metrics = handler._validate_source_relationships(
        state={}, source_tables=[parent, child], reconcile=False,
        raw_relationships=[{
            'left_table': child.qualified_name, 'right_table': parent.qualified_name, 'join_type': 'LEFT',
            'conditions': [{'left_column': 'family_id', 'right_column': 'id', 'operator': '='}],
            'literal_filters': [{'side': 'left', 'column': 'addressable_type', 'operator': '=', 'value': 'Crm::Contact'}],
            'source': 'HISTORICAL_CTE_KEY_CANDIDATE',
        }],
    )
    assert findings == []
    condition = relationships[0].conditions[0]
    assert (condition.left_column, condition.right_column) == ('FAMILY_ID', 'ID')
    assert relationships[0].literal_filters[0].column == 'ADDRESSABLE_TYPE'


def _fanout_handler(right_unique: int):
    from unittest.mock import Mock
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._describe_table = Mock(side_effect=lambda _name: {
        'column_contracts': [{'name': 'ID', 'type': 'NUMBER'}, {'name': 'ACTIVITY_ID', 'type': 'NUMBER'},
                             {'name': 'CONTACT_ID', 'type': 'NUMBER'}]})
    handler._setting = lambda _name, default=None: default
    handler._tool = lambda _name: None
    import threading
    handler._domain_lock = threading.RLock()
    stats = {"LEFT_ROW_COUNT": 100, "LEFT_UNIQUE_KEY_COUNT": 100, "LEFT_NULL_KEY_COUNT": 0,
             "RIGHT_ROW_COUNT": 210, "RIGHT_UNIQUE_KEY_COUNT": right_unique, "RIGHT_NULL_KEY_COUNT": 0,
             "JOINED_ROW_COUNT": 210, "MATCHED_ROW_COUNT": 210, "ORPHAN_ROW_COUNT": 0, "MATCHED_LEFT_KEY_COUNT": 100}
    lookup = {**stats, "LEFT_ROW_COUNT": 210, "LEFT_UNIQUE_KEY_COUNT": 210, "RIGHT_ROW_COUNT": 100,
              "RIGHT_UNIQUE_KEY_COUNT": 100, "JOINED_ROW_COUNT": 210, "MATCHED_LEFT_KEY_COUNT": 210}

    def sql(query, *_args):
        # The link -> parent join is many-to-one; only the first join fans out.
        row = lookup if '"ACTIVITIES_CONTACTS" AS L' in query else stats
        return Mock(collect=lambda: [Mock(as_dict=lambda: row)])

    handler._session = Mock(sql=sql)
    return handler


def test_a_link_table_fanout_is_a_grain_question_not_a_blocker() -> None:
    from app.schema.common import TableRef

    activities, link, contacts = (TableRef(database='DB', schema='SRC', table=name)
                                  for name in ('ACTIVITIES', 'ACTIVITIES_CONTACTS', 'CONTACTS'))
    relationships = [
        {'left_table': activities.qualified_name, 'right_table': link.qualified_name, 'join_type': 'INNER',
         'conditions': [{'left_column': 'ID', 'right_column': 'ACTIVITY_ID', 'operator': '='}]},
        {'left_table': link.qualified_name, 'right_table': contacts.qualified_name, 'join_type': 'INNER',
         'conditions': [{'left_column': 'CONTACT_ID', 'right_column': 'ID', 'operator': '='}]},
    ]
    _models, findings, _metrics = _fanout_handler(right_unique=100)._validate_source_relationships(
        state={}, source_tables=[activities, link, contacts], reconcile=True, raw_relationships=relationships)
    grain = [item for item in findings if item['category'] == 'join_grain']
    assert grain and not grain[0]['blocking'] and 'ACTIVITIES_CONTACTS' in grain[0]['safe_summary']
    assert not [item for item in findings if item['category'] == 'join_fanout']


def test_a_fanout_from_a_duplicated_lookup_still_blocks() -> None:
    from app.schema.common import TableRef

    activities, codes = (TableRef(database='DB', schema='SRC', table=name) for name in ('ACTIVITIES', 'CODES'))
    _models, findings, _metrics = _fanout_handler(right_unique=100)._validate_source_relationships(
        state={}, source_tables=[activities, codes], reconcile=True, raw_relationships=[
            {'left_table': activities.qualified_name, 'right_table': codes.qualified_name, 'join_type': 'LEFT',
             'conditions': [{'left_column': 'ID', 'right_column': 'ACTIVITY_ID', 'operator': '='}]}])
    assert any(item['category'] == 'join_fanout' and item['blocking'] for item in findings)
