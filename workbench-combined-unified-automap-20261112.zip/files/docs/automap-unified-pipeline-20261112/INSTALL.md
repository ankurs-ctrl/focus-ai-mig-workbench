# Unified Auto-map and admission recovery

This is a cumulative source overlay relative to the originally supplied client ZIP. Apply files/ over the repository root. All previous Auto-map, confidence/rule, SQL-upload, bootstrap and administration fixes remain included. No environment files, credentials, dependencies or built images are included.

## Deploy

1. Build and deploy the same code version to the web backend and every Auto-map worker replica. Rebuild/deploy the frontend for the phase labels. Use the existing bootstrap/CI process, which now includes and validates the project-bootstrap lock as documented in the previous release.
2. Deploy the updated AGT_STTM_BUILDER, AGT_SOURCE_MAPPING and AGT_TRANSFORMATION_RULE instructions and matching manifest. All three are required for this release. Run `python scripts/verify_mapping_agent_specs.py` before deployment. The transformation guidance distinguishes linked-mapping claims from reusable-pattern citations. Merge instructions into the existing client agents while preserving their tools, tool resources, caller permissions, configured models and budgets. `scripts/sync_workbench_agent_specs.py` supports instruction-only preparation/application for these three agents and AGT_FIR_SYSTEM; use the existing client CLI/connection and configured namespace.
3. Apply the semantic-gap instructions to the other installed agents using their included templates: AGT_FIR_SYSTEM, AGT_WORKBENCH_CONVERSATION, AGT_SEMANTIC_MODEL_V2, AGT_DBT_CONVERSION and AGT_DBT_TEST_GENERATION. Legacy semantic and scan templates are also updated: apply them only if those agents are deployed. The scan agent can have the configured AUTOMAP_PARALLEL_TEST_AGENT name rather than a standard name. Preserve live tools/resources/runtime settings; do not create unused agents just for this change. Existing bootstrap/deployment scripts cover the installed-agent inventory.
4. No new admission columns, migrations, grants, environment variables, capacity increases or context-limit increases are required. Existing runtime tables/configuration must already support background_v2. Do not reset or reseed slots/quarantines.
5. Start a new Auto-map job. Newly accepted fast requests use draft-v3 and rules-v2 with or without a UI resolution mode. The pending-worker handoff preserves those markers. New job status and runtime diagnostics expose the policies for verification. Frozen older jobs retain their existing evidence and recovery identities.

The former AUTOMAP_FAST_PROJECT_IDS rollout setting is retained for compatibility but no longer selects different algorithms between projects. The installation's existing AUTOMAP_FAST_PATH_V1 switch remains; project/role authorization is unchanged. SQL upload, fresh workspaces, partial workspaces and CTE driving sources normalize into the same draft engine. Complete existing definitions remain protected by preserve-and-complete behavior.

## Behavior

- The background call creates one provider thread and atomically saves the thread reference, request reference and current lease in one fenced transaction before the model POST. This replaces separate saves and the redundant standalone pre-dispatch renewal.
- Recognized SQL contention is retried only after an acknowledged rollback, using the same thread/request/permit: at most three attempts in a ten-second retry window, further bounded by the existing request deadline. SQL/network finalization still needs bounded cleanup; this is not a promise to interrupt every warehouse operation at exactly ten seconds.
- Heartbeat renewal uses bounded database-only retries. Its control budget protects an already-running or uncertain remote call and never extends inference or authorizes a second model POST.
- Lost commit acknowledgements, failed rollbacks and stale ownership are not blindly retried. Failed preparation is explicitly not dispatched; the proxy does not restart an exhausted preparation as another full batch attempt. Existing terminal reconciliation handles uncertain outcomes.
- SQL code/state/query ID, transaction outcome and failed operation survive safe diagnostic wrappers. SQL text, binds and credentials are excluded. Planned calls, actual POST attempts and completed responses are distinct counters.
- Verified archive writes and exact readbacks share one exclusive lease and transaction; handles become durable only after acknowledged COMMIT. Existing content-addressed recovery remains.
- Intentional SQL NULL has a canonical constant definition (mapping_mode constant, constant_value the JSON string "NULL"). A missing field or JSON null is not treated as a SQL keyword. The source agent and packet explicitly distinguish these cases without inventing missing business values.
- Unsupported positive history claims become review notes with a confidence cap rather than blocking otherwise valid SQL. Backend-matched recipe IDs are credited only for exact authorized/trusted expression matches and are marked separately from model citations. Mandatory corrections, citation authorization and current bindings remain checked.
- Admission queue time already covered by the durable wait budget is not charged a second time against the source scheduling window. Transformation and finalization reserves remain.
- New draft requests send bounded complete context directly for mapping decisions. They do not run the old preliminary quote-review workflow. Oversized context is handled by existing deterministic packing/batch splitting, not by increasing context or truncating authored expressions.
- Existing job polling can show Preparing evidence, Waiting for execution capacity, Saving execution state and Model running, plus aggregate phase counts. Progress enrichment is read-only, caller/role/request scoped and bounded to two-second SQL operations. It is best-effort telemetry; unavailable/older receipts fall back to durable job stage. It never acquires, releases or reconciles a permit.

## Verification

Read VALIDATION.md and the native acceptance reports in this directory. The scenario runner is scripts/validate_automap_durable_live.py with --mixed-rules --concurrent-batches --scenario new|partial|sql-upload|cte. It restricts itself to our separate test account and uses scratch schemas. Supply credentials locally through the existing --credential-env option; never package that file. Use an existing approved warehouse with --warehouse.

The client incident's original blocking query remains unidentified: its native SQL diagnostics were discarded by the deployed version. This release fixes the confirmed control-state and policy-handoff gaps; it does not establish which historical transaction blocked the client or guarantee every business target is resolvable.

## Missing semantic YAML: shared behavior

Missing or unusable source/target YAML no longer rejects the whole selection. Available native semantics remain available; each unavailable asset gets an explicit gap record. All-missing selections still carry current workspace/catalog bindings and authorized FIR/history. No semantic generation, broad registry scan, extra model review or per-table COUNT/column query is added just to continue.

The builder, source mapper and transformation specialist may use older or similar semantic evidence already available through authorized context/retrieval as guidance about business meaning or expression shape. That evidence cannot add selectable current columns or prove current joins, population, types or firm literals. There is no new cross-role history access or unrestricted search. Missing current dependencies still produce specific suggestions; supported siblings remain usable drafts.

The AI Assistant returns the agent's answer followed by a concise semantic-gap notice; the full missing-asset list is retained in response metadata. Cached/reopened bundles preserve coverage. For incomplete selections, the builder retains Search/other authorized tools while removing Analyst tools from this request only. It never binds a historical/default Analyst view to the incomplete selection. Real SQL execution, Value/source validation and caller authorization remain checked.

Refresh/generate the missing assets when available, then use the existing refresh action to invalidate the prepared context. Missing YAML reduces evidence quality; it does not promise that every requested business rule is inferable without additional input. Agent instructions retain the required JSON response schemas and the mapping/rule agents' mandatory numeric model confidence; calculated backend confidence remains the fallback.
