# Auto-map remediation — overlay for supplied UAT ZIP

Apply the files from `files/` at the application repository root, preserving paths. `MANIFEST.json` lists every included file, its checksum, and the supplied-ZIP checksum where it existed. This package contains source files only: no environment files, credentials, node_modules, Git metadata, or built images. No files require deletion.

The four client durable-JSON/retry fixes are retained. Files identical to the supplied ZIP are omitted. The newer CodeCommit session/navigation fixes are included where the ZIP differs, so this overlay preserves the tested UAT baseline.

## Deployment

1. Back up the current source and record existing web/worker image tags. Drain or reconcile in-flight Auto-map work before switching versions.
2. Apply the overlay. Rebuild the frontend and backend images using the existing locked dependencies and deployment process. Deploy the same backend revision to both web backend and Auto-map worker; deploy the frontend with it.
3. Update the existing source-mapping and transformation agents from `infra/snowflake/agents/agent_spec_source_mapping.yaml` and `agent_spec_transformation_rule.yaml` in the intended account/namespace. Verify `python scripts/verify_mapping_agent_specs.py`. Keep the manifest and deployed specs together. Use your existing authenticated agent deployment procedure; do not copy development credentials.
4. Run a new Auto-map job after deployment. Existing frozen jobs retain their prior protocol. Draft-v3 is assigned by the backend to newly accepted explicit fast-resolution jobs; it is not an environment variable.

No dependency lockfiles, existing environment files, warehouse settings, resource monitors, account permissions, or production database schemas were changed. No required new environment variables or admission-pool migration are introduced. Existing fast-path/project enablement, durable-v2, worker routing and input/call/deadline limits still apply. The draft behavior requires the existing fast Auto-map flow enabled for the project; the frontend already submits its explicit resolution mode. Do not raise the input ceiling.

## Optional historical FIR reprojection

Existing older publications may lack full contracts. `scripts/reproject_published_automap_learning.py` rebuilds target-pattern projections from immutable current published snapshots, in pages of at most 100. It does not alter the published versions. First run without `--execute` and inspect the report:

```
python scripts/reproject_published_automap_learning.py --credential-env /path/to/existing/backend.env --namespace DATABASE.SCHEMA --expected-account ORGANIZATION.ACCOUNT --limit 50 --output /path/to/reprojection-dry-run.json
```

Only after reviewing that report, repeat with `--execute`. Continue with `--after-version` from `next_after_version`. The script reads the existing credential file; it does not edit it. This optional write has not been run against client data.

## Behavior and limits

Linked/current history ranks first; compatible accessible cross-project history remains usable. Unknown historical metadata stays a review warning. Missing CTEs/joins are cited suggestions copied from retrieved trusted history. They are displayed for manual review/addition in Source Selection; they are not automatically inserted. Exact oversized transformation groups split; a single oversized target is deferred. Failures preserve completed drafts and report unfinished targets; provider outages cannot guarantee a mapping for every target.

SQL preview uses exact output keys, including quoted/dotted names. Optional source-comparison failure does not hide output values. Publication preserves parser-captured CTE definitions and still checks SQL/Values/source dependencies and optimistic concurrency. The exact client screenshot exception cannot be proven without its server trace.

See `VALIDATION.md` for tests and live-test limitations before promoting this overlay.
