"""The agent writes its own CTEs when the data needs them, in the shape the UI builds."""
from __future__ import annotations

from types import SimpleNamespace

from app.agent_runs.contracts import MappingContextPackageV1
from app.agent_tools.cte_designer import aggregate_per_key, dedup_lookup, dedup_lookup_sql, dedup_order_columns
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.core.workspace_snapshot import relation_alias_for, relation_graph
from app.schema.common import TableRef
from app.schema.mapping_sql import MappingSqlCompileResponse, MappingSqlPreviewResponse, MappingSqlReviewResponse
from app.schema.sttm_builder import RelationshipContextItem
from app.schema.workspace_context import WorkbenchContextSnapshotV1

CONTACTS = "DB.S.CONTACTS"
EMAILS = "DB.S.EMAILS"
ACTIVITIES = "DB.S.ACTIVITIES"
LINKS = "DB.S.ACTIVITIES_CONTACTS"
ADDRESSES = "DB.S.ADDRESSES"
COUNTRIES = "DB.S.COUNTRY_CODES"


def _ref(fqn: str) -> dict[str, str]:
    database, schema, table = fqn.split(".")
    return {"database": database, "schema": schema, "table": table}


def test_dedup_lookup_keeps_one_row_per_key_in_the_builder_shape() -> None:
    assert dedup_lookup_sql(COUNTRIES, ["COUNTRY_CODE"], ["ID"]) == (
        f"SELECT *\nFROM {COUNTRIES}\nQUALIFY ROW_NUMBER() OVER (PARTITION BY COUNTRY_CODE ORDER BY ID) = 1"
    )
    cte = dedup_lookup(table=_ref(COUNTRIES), key_columns=["COUNTRY_CODE"], order_columns=["ID"],
                       columns=[{"name": "ID", "type": "NUMBER"}, {"name": "COUNTRY_CODE", "type": "TEXT"}],
                       duplicate_keys=18, total_rows=266)
    assert cte["id"].startswith("agent_cte_") and cte["origin"] == "agent"
    assert cte["grain"] == "One row per COUNTRY_CODE" and "18 keys repeated across 266 rows" in cte["purpose"]
    assert [column["name"] for column in cte["output_columns"]] == ["ID", "COUNTRY_CODE"]
    assert cte["alias"] == relation_alias_for(cte["id"], cte["name"])
    contract = {"key_columns": [], "column_contracts": [{"name": "COUNTRY_CODE"}, {"name": "NAME"}, {"name": "ID"}]}
    assert dedup_order_columns(contract, ["COUNTRY_CODE"]) == ["NAME", "ID"]
    assert dedup_order_columns({**contract, "key_columns": ["ID"]}, ["COUNTRY_CODE"]) == ["ID"]


def _graph(tables: list[str], relationships: list[dict]) -> dict:
    return relation_graph(
        source_tables=tables,
        source_columns_by_table={table: [{"name": "ID", "data_type": "NUMBER"}, {"name": "CONTACT_ID", "data_type": "NUMBER"},
                                         {"name": "ACTIVITY_ID", "data_type": "NUMBER"}] for table in tables},
        relationships=relationships,
    )


def test_aggregate_rule_moves_into_a_per_key_cte() -> None:
    graph = _graph([CONTACTS, EMAILS], [{
        "left_table": _ref(EMAILS), "right_table": _ref(CONTACTS), "join_type": "LEFT",
        "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}],
    }])
    plan = aggregate_per_key(target_column="EMAIL", target_type="VARCHAR(500)",
                             expression=f"LISTAGG(DISTINCT {EMAILS}.ADDRESS, ';')", graph=graph, driving_id=CONTACTS)
    assert plan is not None
    cte = plan.derived_source
    assert cte["sql_text"] == (
        "SELECT t1.CONTACT_ID AS CONTACT_ID,\n  LISTAGG(DISTINCT t1.ADDRESS, ';') AS EMAIL\n"
        f"FROM {EMAILS} AS t1\nGROUP BY t1.CONTACT_ID"
    )
    assert plan.edge["left_relation_id"] == CONTACTS and plan.edge["right_relation_id"] == cte["id"]
    assert plan.edge["conditions"] == [{"left_column": "ID", "operator": "=", "right_column": "CONTACT_ID"}]
    assert plan.expression == "email_per_contacts.EMAIL"
    assert cte["keys"] == ["CONTACT_ID"] and [c["name"] for c in cte["output_columns"]] == ["CONTACT_ID", "EMAIL"]


def test_aggregate_through_a_link_table_joins_inside_the_cte() -> None:
    graph = _graph([ACTIVITIES, LINKS, CONTACTS], [
        {"left_table": _ref(LINKS), "right_table": _ref(ACTIVITIES), "join_type": "LEFT",
         "conditions": [{"left_column": "ACTIVITY_ID", "right_column": "ID"}]},
        {"left_table": _ref(LINKS), "right_table": _ref(CONTACTS), "join_type": "LEFT",
         "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}]},
    ])
    plan = aggregate_per_key(target_column="WHO", target_type=None, expression="LISTAGG(CONTACTS.NAME, ', ')",
                             graph=graph, driving_id=ACTIVITIES)
    assert plan is not None
    assert plan.derived_source["sql_text"] == (
        "SELECT t1.ACTIVITY_ID AS ACTIVITY_ID,\n  LISTAGG(t2.NAME, ', ') AS WHO\n"
        f"FROM {LINKS} AS t1\nJOIN {CONTACTS} AS t2\n  ON t1.CONTACT_ID = t2.ID\nGROUP BY t1.ACTIVITY_ID"
    )


def test_aggregate_designer_refuses_what_it_cannot_do_safely() -> None:
    graph = _graph([CONTACTS, EMAILS], [{
        "left_table": _ref(EMAILS), "right_table": _ref(CONTACTS),
        "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}],
    }])
    # Mixes driver columns into the aggregate, uses a window, or reads nothing joinable.
    assert aggregate_per_key(target_column="X", target_type=None, graph=graph, driving_id=CONTACTS,
                             expression=f"MAX({CONTACTS}.ID) + MAX({EMAILS}.ID)") is None
    assert aggregate_per_key(target_column="X", target_type=None, graph=graph, driving_id=CONTACTS,
                             expression=f"MAX({EMAILS}.ID) OVER (PARTITION BY {EMAILS}.CONTACT_ID)") is None
    assert aggregate_per_key(target_column="X", target_type=None, graph=graph, driving_id=CONTACTS,
                             expression="COUNT(*)") is None


class _MappingSql:
    def __init__(self) -> None:
        self.requests = []

    def compile(self, request):
        self.requests.append(request)
        select = ", ".join(f"{item.expression or item.source_dependencies[0]} AS {item.target_column}"
                           for item in request.mappings)
        return MappingSqlCompileResponse(valid=True, ready=True, preview_sql=f"SELECT {select}",
                                         generated_sql=f"INSERT INTO T SELECT {select};")

    def review(self, request):
        return MappingSqlReviewResponse(valid=True, review_agent="SNOWFLAKE", syntax_valid=True, execution_ready=True,
                                        review_summary="ok", original_preview_sql=request.preview_sql,
                                        original_generated_sql=request.generated_sql)

    def preview(self, request):
        return MappingSqlPreviewResponse(valid=True, variant_used="original",
                                         executed_preview_sql=request.preview_sql,
                                         executed_generated_sql=request.generated_sql)


def test_agent_validation_builds_the_aggregate_cte_instead_of_holding_the_column_back() -> None:
    contacts, emails = TableRef(**_ref(CONTACTS)), TableRef(**_ref(EMAILS))
    context = MappingContextPackageV1(
        run_id="run", thread_id="run", app_user_id="1", effective_role="R",
        workspace=WorkbenchContextSnapshotV1(
            source_tables=[contacts, emails], driving_table=contacts,
            relationships=[{"left_table": _ref(EMAILS), "right_table": _ref(CONTACTS), "join_type": "LEFT",
                            "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}]}],
        ),
    )
    mapping_sql = _MappingSql()
    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object(),  # type: ignore[arg-type]
                                         mapping_sql=mapping_sql)  # type: ignore[arg-type]
    rows = [
        {"id": "a", "target_column": "ID", "status": "draft", "source_columns": [f"{CONTACTS}.ID"]},
        {"id": "b", "target_column": "EMAIL", "status": "draft", "source_columns": [f"{EMAILS}.ADDRESS"],
         "expression": f"LISTAGG(DISTINCT {EMAILS}.ADDRESS, ';')", "mapping_classification": "derived"},
    ]
    result = handlers._validate_generated_sql(
        state={"run_id": "run", "mapping_context_package": context.model_dump(mode="json")},
        target_table="DB.T.CONTACT", source_tables=[CONTACTS, EMAILS],
        source_columns={CONTACTS: ["ID"], EMAILS: ["CONTACT_ID", "ADDRESS"]},
        rows=rows, policy=SimpleNamespace(validation_depth="preview", preview_row_limit=20),
    )
    assert result["compile_valid"] and not result["columns_held_for_review"]
    request = mapping_sql.requests[0]
    cte_nodes = [node for node in request.relation_graph.nodes if node.kind.value == "DERIVED_SOURCE"]
    assert len(cte_nodes) == 1 and cte_nodes[0].sql_text.startswith("SELECT t1.CONTACT_ID")
    assert {item.target_column: item.source_dependencies for item in request.mappings}["EMAIL"] == ["email_per_contacts.EMAIL"]
    assert rows[1]["repairs"][0]["root_cause"] == "aggregate_grain"
    design = result["workspace_design"]
    assert any(item["id"] == cte_nodes[0].relation_id for item in design["derived_sources"])


def test_fanout_lookup_is_replaced_by_a_one_row_per_key_cte() -> None:
    class _Session:
        def sql(self, _text):
            return SimpleNamespace(collect=lambda: [{"LEFT_ROW_COUNT": 100, "JOINED_ROW_COUNT": 100}])

    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=_Session())  # type: ignore[arg-type]
    handlers._describe_table = lambda fqn: {  # type: ignore[method-assign]
        "key_columns": [], "columns": ["ID", "COUNTRY_CODE", "NAME"],
        "column_contracts": [{"name": "ID", "type": "NUMBER"}, {"name": "COUNTRY_CODE", "type": "TEXT"},
                             {"name": "NAME", "type": "TEXT"}],
    }
    addresses, countries = TableRef(**_ref(ADDRESSES)), TableRef(**_ref(COUNTRIES))
    relationship = RelationshipContextItem(left_table=addresses, right_table=countries, join_type="LEFT",
                                           conditions=[{"left_column": "COUNTRY", "right_column": "COUNTRY_CODE"}])
    workspace = WorkbenchContextSnapshotV1(source_tables=[addresses, countries], driving_table=addresses,
                                           relationships=[relationship.model_dump(mode="json")])
    findings = [{"category": "join_fanout", "blocking": True, "details": {"edge_id": "join_1", "fanout_ratio": 10.99}}]
    metrics = {"join_1": {"relationship_index": 0, "right_row_count": 266, "right_unique_key_count": 248,
                          "right_null_key_count": 0, "fanout_ratio": 10.99}}
    handlers._design_lookup_ctes(workspace=workspace, relationship_models=[relationship], findings=findings, metrics=metrics)
    assert [finding["category"] for finding in findings] == ["join_dedup_applied"]
    assert not findings[0]["blocking"] and "18 of its keys" in findings[0]["safe_summary"]
    derived = workspace.derived_sources[0]
    assert workspace.relationships[0]["dedup_relation_id"] == derived.id
    assert "PARTITION BY COUNTRY_CODE ORDER BY ID, NAME" in derived.lineage[0]["sql"]

    context = MappingContextPackageV1(run_id="run", thread_id="run", app_user_id="1", effective_role="R",
                                      workspace=workspace)
    design = handlers._canonical_design(
        state={"mapping_context_package": context.model_dump(mode="json")},
        source_tables=[ADDRESSES, COUNTRIES], source_columns={ADDRESSES: ["COUNTRY"], COUNTRIES: ["COUNTRY_CODE", "NAME"]},
    )
    edge = design["graph"].edges[0]
    assert (edge.left_relation_id, edge.right_relation_id) == (ADDRESSES, derived.id)
    row = handlers._canonical_row({"id": "r", "target_column": "COUNTRY_NAME", "status": "draft",
                                   "source_columns": [f"{COUNTRIES}.NAME"]}, {**design, "source_columns": {}})
    assert row["source_columns"] == [f"{derived.name}.NAME"]


def test_a_child_with_many_rows_per_parent_is_reduced_with_its_filter_inside_the_cte() -> None:
    from app.agent_tools.cte_designer import reduce_child

    cte = reduce_child(table=_ref(EMAILS), key_columns=["EMAILABLE_ID"], order_columns=["ID"],
                       filters=[{"column": "EMAILABLE_TYPE", "value": "Crm::Contact"}],
                       columns=[{"name": "ID", "type": "NUMBER"}, {"name": "ADDRESS", "type": "TEXT"}],
                       parent_name="CONTACTS", rows=9800, keys=7000)
    assert cte["sql_text"] == (
        f"SELECT *\nFROM {EMAILS}\nWHERE EMAILABLE_TYPE = 'Crm::Contact'\n"
        "QUALIFY ROW_NUMBER() OVER (PARTITION BY EMAILABLE_ID ORDER BY ID) = 1"
    )
    assert cte["name"] == "emails_one_per_contacts" and "1.4 per key" in cte["purpose"]
    assert cte["lineage"][0]["reduced_from"] == {"table": EMAILS, "filters": [{"column": "EMAILABLE_TYPE", "value": "Crm::Contact"}]}


def test_an_aggregate_over_a_reduced_child_reads_every_child_row() -> None:
    from app.agent_tools.cte_designer import reduce_child

    reduced = reduce_child(table=_ref(EMAILS), key_columns=["CONTACT_ID"], order_columns=["ID"],
                           filters=[{"column": "KIND", "value": "work"}], columns=[{"name": "CONTACT_ID"}, {"name": "ADDRESS"}],
                           parent_name="CONTACTS", rows=10, keys=5)
    graph = relation_graph(
        source_tables=[CONTACTS], source_columns_by_table={CONTACTS: [{"name": "ID"}]}, derived_sources=[reduced],
        derived_edges=[{"left_relation_id": reduced["id"], "right_relation_id": CONTACTS, "join_type": "LEFT",
                        "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}]}],
    )
    plan = aggregate_per_key(target_column="EMAILS", target_type=None, graph=graph, driving_id=CONTACTS,
                             expression="LISTAGG(emails_one_per_contacts.ADDRESS, ';')",
                             derived_names={reduced["id"]: reduced["name"]},
                             reductions={reduced["id"]: reduced["lineage"][0]["reduced_from"]})
    assert plan is not None
    assert plan.derived_source["sql_text"] == (
        "SELECT t1.CONTACT_ID AS CONTACT_ID,\n  LISTAGG(t1.ADDRESS, ';') AS EMAILS\n"
        f"FROM {EMAILS} AS t1\nWHERE t1.KIND = 'work'\nGROUP BY t1.CONTACT_ID"
    )


def test_source_preparation_reduces_a_fanning_child_and_routes_every_join_through_it() -> None:
    queries = []

    class _Session:
        def sql(self, text):
            queries.append(text)
            if "NEAR_ROWS" in text:
                return SimpleNamespace(collect=lambda: [{"NEAR_ROWS": 100, "JOINED_ROWS": 250, "CHILD_ROWS": 240, "CHILD_KEYS": 90}])
            return SimpleNamespace(collect=lambda: [{"JOINED_ROWS": 100}])

    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=_Session())  # type: ignore[arg-type]
    handlers._describe_table = lambda fqn: {"key_columns": ["ID"], "columns": ["ID", "CONTACT_ID"],  # type: ignore[method-assign]
                                            "column_contracts": [{"name": "ID", "type": "NUMBER"}, {"name": "CONTACT_ID", "type": "NUMBER"}]}
    contacts, emails = TableRef(**_ref(CONTACTS)), TableRef(**_ref(EMAILS))
    relationship = RelationshipContextItem(left_table=emails, right_table=contacts, join_type="LEFT",
                                           conditions=[{"left_column": "CONTACT_ID", "right_column": "ID"}])
    workspace = WorkbenchContextSnapshotV1(source_tables=[contacts, emails], driving_table=contacts,
                                           relationships=[relationship.model_dump(mode="json")])
    findings: list = []
    handlers._reduce_fanout_children(workspace=workspace, relationship_models=[relationship], findings=findings)
    assert findings[0]["category"] == "join_child_reduced" and not findings[0]["blocking"]
    derived = workspace.derived_sources[0]
    assert workspace.relationships[0]["left_relation_override"] == derived.id
    context = MappingContextPackageV1(run_id="run", thread_id="run", app_user_id="1", effective_role="R", workspace=workspace)
    design = handlers._canonical_design(state={"mapping_context_package": context.model_dump(mode="json")},
                                        source_tables=[CONTACTS, EMAILS], source_columns={CONTACTS: ["ID"], EMAILS: ["CONTACT_ID"]})
    edge = design["graph"].edges[0]
    assert {edge.left_relation_id, edge.right_relation_id} == {CONTACTS, derived.id}
    assert design["rewrites"][EMAILS] == derived.name
