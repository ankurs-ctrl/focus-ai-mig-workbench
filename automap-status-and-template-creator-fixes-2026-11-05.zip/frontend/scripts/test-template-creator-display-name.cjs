const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const ts=require('typescript');
for(const name of ['features/mappings/AllMappingsPage.tsx','features/projects/ProjectDetailPage.tsx']){
 const file=path.resolve(__dirname,'../src',name);const source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 const helpers=new Set(['initialsFor','formatCreatedAt','relativeTime','statusForSttm','mappingItemFromSttm']);
 const text=source.statements.filter(node=>ts.isFunctionDeclaration(node)&&helpers.has(node.name?.text)).map(node=>node.getText(source)).join('\n');
 const js=ts.transpileModule(text+'\nmodule.exports=mappingItemFromSttm;',{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
 const module={exports:{}};new Function('module',js)(module);const map=module.exports;
 const project={project_id:'project',project_name:'Migration'};
 for(let index=0;index<10;index++){
  const record={sttm_id:String(index),sttm_name:`Target ${index}`,status:'DRAFT',metadata:{bootstrap_origin:'project_template',actor_user_id:'42',created_by_name:'Ankur Sharma'}};
  const result=map(record,project,index);assert.equal(result.createdBy.name,'Ankur Sharma');assert.equal(result.createdBy.initials,'AS');assert.equal(record.metadata.actor_user_id,'42');assert.equal(result.name,`Target ${index}`);
 }
 const manual=map({sttm_id:'manual',status:'DRAFT',metadata:{actor_user_id:'manual_creator',created_by_name:'Different metadata name'}},project,0);
 assert.equal(manual.createdBy.name,'manual_creator','manual creation keeps its existing behavior');
 const legacy=map({sttm_id:'legacy',status:'DRAFT',metadata:{bootstrap_origin:'project_template',actor_user_id:'42'}},project,0);assert.equal(legacy.createdBy.name,'42','missing profile data never substitutes the current viewer');
 console.log(name+': all ten template mappings display the creator name; actor identity and manual creation are unchanged.');
}
