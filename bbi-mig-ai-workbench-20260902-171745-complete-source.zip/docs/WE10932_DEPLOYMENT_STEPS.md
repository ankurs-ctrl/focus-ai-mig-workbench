# BBI AI Migration Workbench — New Account Deployment Log
**Account:** FVEVNBL-WE10932  
**Date:** 2026-08-24  
**Performed by:** Claude Code (automated) + Ankur Sinha (ACCOUNTADMIN)

---

## Account Details

| Field | Value |
|---|---|
| Account identifier | `fvevnbl-we10932` |
| Account hostname | `fvevnbl-we10932.snowflakecomputing.com` |
| Region endpoint | `is41904.us-east-2.aws.snowflakecomputing.com` |
| Username | `ANKUR_SINHA` |
| Login name | `ankurs` |
| Role used | `ACCOUNTADMIN` |

---

## What Was Done (Automated)

### Step 1 — Core namespace

```sql
CREATE DATABASE IF NOT EXISTS BBI_WORKBENCH_DB;
CREATE SCHEMA  IF NOT EXISTS BBI_WORKBENCH_DB.SCH_WORKBENCH;
CREATE WAREHOUSE IF NOT EXISTS COMPUTE_WH
  WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;
```

### Step 2 — Compute pools

```sql
CREATE COMPUTE POOL IF NOT EXISTS AI_WORKBENCH_POOL
  MIN_NODES = 1 MAX_NODES = 1
  INSTANCE_FAMILY = CPU_X64_S AUTO_RESUME = TRUE AUTO_SUSPEND_SECS = 3600;

CREATE COMPUTE POOL IF NOT EXISTS AI_WORKBENCH_AUTOMAP_POOL
  MIN_NODES = 1 MAX_NODES = 2
  INSTANCE_FAMILY = CPU_X64_S AUTO_RESUME = TRUE AUTO_SUSPEND_SECS = 3600;

GRANT BIND SERVICE ENDPOINT ON ACCOUNT TO ROLE ACCOUNTADMIN;
```

### Step 3 — Image repository and deploy stage

```sql
CREATE IMAGE REPOSITORY IF NOT EXISTS
  BBI_WORKBENCH_DB.SCH_WORKBENCH.AI_WORKBENCH_IMAGES;

CREATE STAGE IF NOT EXISTS
  BBI_WORKBENCH_DB.SCH_WORKBENCH.AI_WORKBENCH_DEPLOY_STAGE;
```

### Step 4 — Egress network rule  ⚠️ BLOCKED (trial account)

```sql
CREATE OR REPLACE NETWORK RULE
  BBI_WORKBENCH_DB.SCH_WORKBENCH.AI_WORKBENCH_SNOWFLAKE_EGRESS_RULE
  TYPE = HOST_PORT MODE = EGRESS
  VALUE_LIST = ('fvevnbl-we10932.snowflakecomputing.com:443');
```

The network rule **was created successfully**.  
The External Access Integration (`AI_WORKBENCH_EGRESS_INTEGRATION`) **could not be created** because this is a trial account:

> `509009 (0A000): External access is not supported for trial accounts.`

**Action required:** Upgrade to a paid Snowflake account, then run:
```sql
USE ROLE ACCOUNTADMIN;
CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION AI_WORKBENCH_EGRESS_INTEGRATION
  ALLOWED_NETWORK_RULES = (
    BBI_WORKBENCH_DB.SCH_WORKBENCH.AI_WORKBENCH_SNOWFLAKE_EGRESS_RULE
  )
  ENABLED = TRUE;
GRANT USAGE ON INTEGRATION AI_WORKBENCH_EGRESS_INTEGRATION TO ROLE ACCOUNTADMIN;
```

### Step 5 — Custom OAuth Security Integration

```sql
CREATE OR REPLACE SECURITY INTEGRATION WORKBENCH_OAUTH_INTEGRATION
  TYPE                         = OAUTH
  ENABLED                      = TRUE
  OAUTH_CLIENT                 = CUSTOM
  OAUTH_CLIENT_TYPE            = 'CONFIDENTIAL'
  OAUTH_REDIRECT_URI           = 'https://placeholder.snowflakecomputing.app/api/v1/auth/callback'
  OAUTH_ISSUE_REFRESH_TOKENS   = TRUE
  OAUTH_REFRESH_TOKEN_VALIDITY = 7776000;
```

Generated credentials (also stored in Snowflake secrets — see Step 6):

| Field | Value |
|---|---|
| `OAUTH_CLIENT_ID` | `Af192PxN/NbepHmm8bg4dBuvndM=` |
| `OAUTH_CLIENT_SECRET` | `fKiyU5j+2h2VMJ/rN5203SlvaJ9ejCe4SS6bB7kBd9I=` |
| Authorize URL | `https://is41904.us-east-2.aws.snowflakecomputing.com/oauth/authorize` |
| Token URL | `https://is41904.us-east-2.aws.snowflakecomputing.com/oauth/token-request` |

**ACCOUNTADMIN unblocked for OAuth:**
```sql
-- The account default blocks privileged roles from OAuth. Disabled it:
ALTER ACCOUNT SET OAUTH_ADD_PRIVILEGED_ROLES_TO_BLOCKED_LIST = FALSE;

ALTER SECURITY INTEGRATION WORKBENCH_OAUTH_INTEGRATION
  SET BLOCKED_ROLES_LIST = ('ORGADMIN', 'SECURITYADMIN');
-- ACCOUNTADMIN is now allowed to authenticate via OAuth
```

### Step 6 — Password secrets

```sql
-- OAuth client credentials (client_id as USERNAME, client_secret as PASSWORD)
CREATE OR REPLACE SECRET BBI_WORKBENCH_DB.SCH_WORKBENCH.STTM_BUILDER_OAUTH_CLIENT_CREDENTIALS
  TYPE = PASSWORD
  USERNAME = 'Af192PxN/NbepHmm8bg4dBuvndM='
  PASSWORD = 'fKiyU5j+2h2VMJ/rN5203SlvaJ9ejCe4SS6bB7kBd9I=';

-- Session keys (session secret as USERNAME, encryption key as PASSWORD)
CREATE OR REPLACE SECRET BBI_WORKBENCH_DB.SCH_WORKBENCH.STTM_BUILDER_OAUTH_SESSION_KEYS
  TYPE = PASSWORD
  USERNAME = 'UFBoseLmu2ZbClNRFsJtsThX2hv02J1sQKJqRazb9eJhx0o9HDI8KHFIwD69Z1Mh'
  PASSWORD = 'ZPkAnpIQSJv6JtDyijH99VxjF8SZQF5o3ReQvL1pk2I=';

GRANT READ ON SECRET BBI_WORKBENCH_DB.SCH_WORKBENCH.STTM_BUILDER_OAUTH_CLIENT_CREDENTIALS TO ROLE ACCOUNTADMIN;
GRANT READ ON SECRET BBI_WORKBENCH_DB.SCH_WORKBENCH.STTM_BUILDER_OAUTH_SESSION_KEYS TO ROLE ACCOUNTADMIN;
```

### Step 7 — Artifact stage

```sql
CREATE STAGE IF NOT EXISTS BBI_WORKBENCH_DB.SCH_WORKBENCH.AI_WORKBENCH_ARTIFACTS
  DIRECTORY = (ENABLE = FALSE)
  COMMENT = 'Content-addressed workbench artifacts.';
```

---

## Configuration File

`infra/snowflake/env/client.env` was written and is ready for the next deployment steps. Key values:

| Variable | Value |
|---|---|
| `SNOWFLAKE_ACCOUNT` | `fvevnbl-we10932` |
| `SNOWFLAKE_USER` | `ANKUR_SINHA` |
| `SNOWFLAKE_DATABASE` | `BBI_WORKBENCH_DB` |
| `SNOWFLAKE_SCHEMA` | `SCH_WORKBENCH` |
| `SNOWFLAKE_COMPUTE_POOL` | `AI_WORKBENCH_POOL` |
| `WEBAPP_SERVICE_NAME` | `WORKBENCH_WEBAPP` |
| `SNOWFLAKE_EGRESS_INTEGRATION` | `AI_WORKBENCH_EGRESS_INTEGRATION` *(pending paid account upgrade)* |
| `SNOWFLAKE_OAUTH_AUTHORIZE_URL` | `https://is41904.us-east-2.aws.snowflakecomputing.com/oauth/authorize` |
| `SNOWFLAKE_OAUTH_TOKEN_URL` | `https://is41904.us-east-2.aws.snowflakecomputing.com/oauth/token-request` |
| `SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT` | `BBI_WORKBENCH_DB.SCH_WORKBENCH.STTM_BUILDER_OAUTH_CLIENT_CREDENTIALS` |
| `SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT` | `BBI_WORKBENCH_DB.SCH_WORKBENCH.STTM_BUILDER_OAUTH_SESSION_KEYS` |

---

## What Remains (Manual / Post-Upgrade)

### A. External Access Integration (requires paid account)

After upgrading from trial:
```sql
USE ROLE ACCOUNTADMIN;
CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION AI_WORKBENCH_EGRESS_INTEGRATION
  ALLOWED_NETWORK_RULES = (
    BBI_WORKBENCH_DB.SCH_WORKBENCH.AI_WORKBENCH_SNOWFLAKE_EGRESS_RULE
  )
  ENABLED = TRUE;
GRANT USAGE ON INTEGRATION AI_WORKBENCH_EGRESS_INTEGRATION TO ROLE ACCOUNTADMIN;
```

### B. Bootstrap metadata (tables, procs, agents)

```bash
cd /path/to/bbi-mig-ai-workbench
./scripts/bootstrap_client_spcs_tools.sh
./scripts/configure_client_snow_connection.sh --env-file infra/snowflake/env/client.env
./scripts/bootstrap_sttm_metadata_infra.sh   --env-file infra/snowflake/env/client.env
```

### C. Build, push, and deploy the SPCS service

```bash
./scripts/deploy_spcs_client_snow.sh --env-file infra/snowflake/env/client.env \
  --image-tag workbench-20260824
```

### D. Update the OAuth redirect URI

After `deploy_spcs_client_snow.sh` finishes, retrieve the real public endpoint:
```bash
.client-tools-venv/bin/snow spcs service list-endpoints WORKBENCH_WEBAPP \
  -c workbench-spcs-we10932 \
  --database BBI_WORKBENCH_DB --schema SCH_WORKBENCH
```

Then update `client.env`:
```
SNOWFLAKE_OAUTH_REDIRECT_URI=https://<real-host>/api/v1/auth/callback
```

And update the Snowflake integration:
```sql
ALTER SECURITY INTEGRATION WORKBENCH_OAUTH_INTEGRATION
  SET OAUTH_REDIRECT_URI = 'https://<real-host>/api/v1/auth/callback';
```

Then redeploy (Step C) so the backend picks up the new redirect URI.

### E. Grant service role access (after first deploy)

```sql
-- Run after CREATE SERVICE succeeds:
GRANT SERVICE ROLE BBI_WORKBENCH_DB.SCH_WORKBENCH.WORKBENCH_WEBAPP!backend_access
  TO ROLE ACCOUNTADMIN;
```

### F. Verify

```bash
.client-tools-venv/bin/snow spcs service status WORKBENCH_WEBAPP \
  -c workbench-spcs-we10932 --database BBI_WORKBENCH_DB --schema SCH_WORKBENCH

.client-tools-venv/bin/snow spcs service list-containers WORKBENCH_WEBAPP \
  -c workbench-spcs-we10932 --database BBI_WORKBENCH_DB --schema SCH_WORKBENCH
```

Open the public endpoint in a browser and confirm login, source/target selection, and Auto-map work.

---

## Known Blocker

| Blocker | Description | Fix |
|---|---|---|
| Trial account | `EXTERNAL ACCESS INTEGRATION` cannot be created | Upgrade to paid Snowflake account, then run the SQL in §A above |

The application **cannot run** until the External Access Integration exists — the backend needs it to reach the Snowflake Cortex Agent REST API and execute caller-rights SQL from within the SPCS container.
