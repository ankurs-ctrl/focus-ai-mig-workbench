"""Offline canonical-snapshot reuse contracts for semantic bundle preparation."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import yaml

from app.core.config import Settings
from app.core.semantic_context import SemanticContextService, invalidate_semantic_bundle_cache
from app.schema.common import TableRef
from app.schema.semantic_context import SemanticContextRefreshRequest, SemanticLevel


def canonical_record(table, version):
    document = {
        "name": f"SV_{table.table}",
        "tables": [{
            "name": table.table,
            "description": version,
            "base_table": {"database": table.database, "schema": table.schema, "table": table.table},
            "dimensions": [{"name": "ID", "expr": "ID", "data_type": "NUMBER"}],
        }],
    }
    return {
        "database": table.database, "schema_name": table.schema, "table_name": table.table,
        "scope": "TABLE", "updated_at": "2026-10-29",
        "semantic_model": {
            "description": version,
            "attributes": [{"name": "ID", "data_type": "NUMBER", "synonyms": [version]}],
            "semantic_view": {"yaml": yaml.safe_dump(document), "yaml_hash": version, "source": "SEM_NATIVE_VIEWS"},
        },
    }


@pytest.fixture
def service():
    invalidate_semantic_bundle_cache()
    instance = SemanticContextService.__new__(SemanticContextService)
    instance._session = SimpleNamespace(sql=Mock(side_effect=AssertionError("No database calls allowed")))
    instance._settings = Settings(_env_file=None)
    instance._access_fingerprint = "offline-canonical-snapshot"
    instance._semantic_model_service = SimpleNamespace(get_table_records=Mock())
    instance._table_selection_service = SimpleNamespace(
        list_attributes_for_tables=Mock(side_effect=AssertionError("Unexpected column fallback")))
    instance._derived_source_service = SimpleNamespace(get_sources_by_ids=Mock(return_value=[]))
    instance.get_bundle = Mock(return_value=None)
    instance.ensure_storage_exists = Mock()
    instance._upsert_bundle = Mock()
    instance._persist_bundle_artifact = Mock()
    instance._active_curation_overlay = Mock(return_value={})
    yield instance
    instance._session.sql.assert_not_called()
    invalidate_semantic_bundle_cache()


def bundle_inputs(service):
    source = TableRef(database="DB", schema="SRC", table="SOURCE")
    target = TableRef(database="DB", schema="TGT", table="TARGET")
    records = [canonical_record(source, "source-v1"), canonical_record(target, "target-v1")]
    service._semantic_model_service.get_table_records.return_value = records
    request = SemanticContextRefreshRequest(selected_source_tables=[source, source], target_table=target)
    return request, records


def test_cold_bundle_fetches_one_canonical_snapshot_without_mutating_inputs(service):
    request, records = bundle_inputs(service)
    before = deepcopy(records)
    request_before = request.model_dump(mode="json")

    response = service.refresh_bundle(request)

    service._semantic_model_service.get_table_records.assert_called_once_with(
        service._session, [request.selected_source_tables[0], request.target_table])
    assert not response.cache_hit and response.cache_source == "fresh"
    assert len(response.semantic_context) == len(response.raw_assets) == 2
    assert response.summary.asset_versions == {"DB.SRC.SOURCE": "source-v1", "DB.TGT.TARGET": "target-v1"}
    assert response.analyst_ready and response.missing_assets == []
    assert records == before
    assert request.model_dump(mode="json") == request_before
    service._table_selection_service.list_attributes_for_tables.assert_not_called()


def test_versions_composition_and_context_use_same_snapshot_if_registry_changes(service):
    request, records = bundle_inputs(service)
    changed = deepcopy(records)
    for record in changed:
        record["semantic_model"]["semantic_view"]["yaml_hash"] = "later-version"
        record["semantic_model"]["description"] = "later-version"
    service._semantic_model_service.get_table_records.side_effect = [records, changed]

    response = service.refresh_bundle(request)

    assert [item["semantic_model"]["semantic_view"]["yaml_hash"] for item in response.semantic_context] == [
        "source-v1", "target-v1"]
    assert [item["semantic_model"]["description"] for item in response.semantic_context] == [
        "source-v1", "target-v1"]
    assert [item["yaml_hash"] for item in response.raw_assets] == ["source-v1", "target-v1"]
    assert [table["description"] for table in yaml.safe_load(response.semantic_model_yaml)["tables"]] == [
        "source-v1", "target-v1"]
    versions = [{"fqn": name, "version": version} for name, version in response.summary.asset_versions.items()]
    assert response.registry_version == hashlib.sha256(json.dumps(versions, sort_keys=True).encode()).hexdigest()
    assert response.summary.composed_model_hash == hashlib.sha256(response.semantic_model_yaml.encode()).hexdigest()
    service._semantic_model_service.get_table_records.assert_called_once()


def test_memory_cache_reuses_bundle_without_fetch_and_returns_independent_copies(service):
    request, records = bundle_inputs(service)
    first = service.refresh_bundle(request)
    expected = deepcopy(first.semantic_context)
    service._semantic_model_service.get_table_records.reset_mock()
    service._semantic_model_service.get_table_records.side_effect = AssertionError("Cached path refetched registry")
    first.semantic_context[0]["semantic_model"]["semantic_view"]["yaml_hash"] = "caller-edit"

    second = service.refresh_bundle(request)
    assert second.cache_hit and second.cache_status == "l1" and second.cache_source == "memory"
    assert second.bundle_hash == first.bundle_hash and second.registry_version == first.registry_version
    assert second.semantic_context == expected
    second.semantic_context[0]["semantic_model"]["attributes"][0]["synonyms"].append("caller-edit")
    assert service.refresh_bundle(request).semantic_context == expected
    assert records[0]["semantic_model"]["semantic_view"]["yaml_hash"] == "source-v1"
    service._semantic_model_service.get_table_records.assert_not_called()


def test_durable_cache_does_not_fetch_registry(service):
    request, _ = bundle_inputs(service)
    first = service.refresh_bundle(request)
    artifact = first.model_dump(mode="json")
    invalidate_semantic_bundle_cache()
    service.get_bundle.return_value = {"bundle_artifact": artifact, "updated_at": datetime.now(timezone.utc)}
    service._semantic_model_service.get_table_records.reset_mock()
    service._semantic_model_service.get_table_records.side_effect = AssertionError("Durable hit refetched registry")

    hit = service.refresh_bundle(request)

    assert hit.cache_hit and hit.cache_status == "l2" and hit.cache_source == "durable"
    assert hit.bundle_hash == first.bundle_hash and hit.summary.asset_versions == first.summary.asset_versions
    assert hit.semantic_context == first.semantic_context
    service._semantic_model_service.get_table_records.assert_not_called()


def test_force_refresh_fetches_exactly_one_new_snapshot_and_changes_versions(service):
    request, _ = bundle_inputs(service)
    first = service.refresh_bundle(request)
    service._semantic_model_service.get_table_records.reset_mock()
    service._semantic_model_service.get_table_records.return_value = [
        canonical_record(request.selected_source_tables[0], "source-v2"),
        canonical_record(request.target_table, "target-v2"),
    ]

    refreshed = service.refresh_bundle(request.model_copy(update={"force": True}))

    service._semantic_model_service.get_table_records.assert_called_once()
    assert refreshed.bundle_id == first.bundle_id
    assert refreshed.bundle_hash != first.bundle_hash and refreshed.registry_version != first.registry_version
    assert refreshed.summary.asset_versions == {"DB.SRC.SOURCE": "source-v2", "DB.TGT.TARGET": "target-v2"}


@pytest.mark.parametrize("explicit_none", [False, True])
def test_context_items_legacy_callers_still_fetch_records(service, explicit_none):
    table = TableRef(database="DB", schema="SRC", table="SOURCE")
    records = [canonical_record(table, "source-v1")]
    service._semantic_model_service.get_table_records.return_value = records
    kwargs = {"canonical_records": None} if explicit_none else {}

    result = service._build_semantic_context_items(
        selected_source_tables=[table], derived_records=[], relationships=[],
        requested_level=SemanticLevel.FULL_REGISTRY, **kwargs)

    service._semantic_model_service.get_table_records.assert_called_once_with(service._session, [table])
    assert result[0].semantic_model["semantic_view"]["yaml_hash"] == "source-v1"


def test_context_items_reuses_readonly_records_and_preserves_selection_order(service):
    request, records = bundle_inputs(service)
    before = deepcopy(records)
    service._semantic_model_service.get_table_records.side_effect = AssertionError("Snapshot refetched")

    result = service._build_semantic_context_items(
        selected_source_tables=[request.target_table, request.selected_source_tables[0]],
        derived_records=[], relationships=[], requested_level=SemanticLevel.FULL_REGISTRY,
        canonical_records=records)

    assert [item.table for item in result] == [request.target_table, request.selected_source_tables[0]]
    assert [item.semantic_model["description"] for item in result] == ["target-v1", "source-v1"]
    assert records == before
    service._semantic_model_service.get_table_records.assert_not_called()


def test_explicit_empty_snapshot_uses_existing_column_fallback_without_registry_fetch(service):
    table = TableRef(database="DB", schema="SRC", table="SOURCE")
    service._semantic_model_service.get_table_records.side_effect = AssertionError("Empty snapshot refetched")
    service._table_selection_service.list_attributes_for_tables = Mock(return_value=[SimpleNamespace(columns=[
        SimpleNamespace(column_name="ID", data_type="NUMBER", is_primary_key=True, is_foreign_key=False)])])

    result = service._build_semantic_context_items(
        selected_source_tables=[table], derived_records=[], relationships=[],
        requested_level=SemanticLevel.L1_CONTEXT, canonical_records=[])

    service._semantic_model_service.get_table_records.assert_not_called()
    service._table_selection_service.list_attributes_for_tables.assert_called_once_with([table.qualified_name])
    assert result[0].scope == "TABLE"
    assert result[0].semantic_model["attributes"] == [{
        "name": "ID", "data_type": "NUMBER", "is_primary_key": True, "is_foreign_key": False}]

@pytest.mark.parametrize("keep", ["source", "target", "none"])
def test_missing_yaml_returns_available_evidence_and_explicit_gaps_without_catalog_queries(service, keep):
    request, records = bundle_inputs(service)
    kept = [records[0]] if keep == "source" else [records[1]] if keep == "target" else []
    service._semantic_model_service.get_table_records.return_value = kept
    response = service.refresh_bundle(request)
    missing = sorted(table.qualified_name for table in [request.selected_source_tables[0], request.target_table]
                     if not any(record["table_name"] == table.table for record in kept))
    assert response.missing_assets == missing
    assert response.status.value == "partial" and not response.analyst_ready
    assert response.semantic_model_yaml is None and response.semantic_view_name is None
    assert len(response.semantic_context) == 2 and len(response.raw_assets) == len(kept)
    gaps = [item for item in response.semantic_context if item["semantic_model"].get("semantic_status")]
    assert len(gaps) == len(missing)
    assert all(item["semantic_model"]["attributes"] == [] for item in gaps)
    assert "evidence gap" in response.reading_instructions.interpretation_notes[-1]
    assert service.refresh_bundle(request).missing_assets == missing
    artifact = response.model_dump(mode="json")
    invalidate_semantic_bundle_cache()
    service.get_bundle.return_value = {"bundle_artifact": artifact, "updated_at": datetime.now(timezone.utc)}
    reopened = service.refresh_bundle(request)
    assert reopened.cache_source == "durable" and reopened.missing_assets == missing
    assert reopened.semantic_context == response.semantic_context and not reopened.analyst_ready
    service._table_selection_service.list_attributes_for_tables.assert_not_called()


@pytest.mark.parametrize("yaml_value", [None, "[bad: yaml", "tables: []", "[]"])
def test_prior_or_unusable_semantics_remain_guidance_not_current_bindings(service, yaml_value):
    request, records = bundle_inputs(service)
    records[0]["semantic_model"]["semantic_view"]["yaml"] = yaml_value
    records[0]["semantic_model"]["attributes"].append({"name": "OBSOLETE_COLUMN", "data_type": "VARCHAR"})
    response = service.refresh_bundle(request)
    assert response.missing_assets == ["DB.SRC.SOURCE"]
    gap = next(item["semantic_model"] for item in response.semantic_context if item["table"]["table"] == "SOURCE")
    assert gap["attributes"] == [] and gap["historical_semantics_authority"].startswith("guidance_only")
    assert gap["historical_semantics"]["attributes"][-1]["name"] == "OBSOLETE_COLUMN"
    from app.core.automap_retrieval import AutoMapContext
    payload = {"context": {"source_tables": [request.selected_source_tables[0].model_dump(mode="json")],
        "target_table": request.target_table.model_dump(mode="json"), "semantic_context": response.semantic_context},
        "data": {"attributes": [{"target_attribute": "ID"}]}}
    store = AutoMapContext(payload)
    assert "OBSOLETE_COLUMN" not in store.inventory.get("DB.SRC.SOURCE", {})
    assert "OBSOLETE_COLUMN" in json.dumps(store.tables["DB.SRC.SOURCE"])
    from app.core.automap_context_packer import shared_capsule
    assert shared_capsule(payload["context"])["semantic_evidence_coverage"]["missing_assets"] == ["DB.SRC.SOURCE"]


def test_chat_projection_preserves_gap_and_historical_guidance_without_binding_old_columns(service):
    request, records = bundle_inputs(service)
    records[0]["semantic_model"].pop("semantic_view")
    response = service.refresh_bundle(request)
    from app.schema.semantic_context import SemanticProjectionProfile
    projected = service._build_projection_payload(profile=SemanticProjectionProfile.CHAT_SUMMARY,
        bundle={"bundle_artifact": response.model_dump(mode="json")},
        source_tables=[request.selected_source_tables[0]], target_table=request.target_table,
        derived_records=[], table_records_by_fqn={"DB.SRC.SOURCE": records[0], "DB.TGT.TARGET": records[1]},
        relationships=[], target_columns=[], source_columns_by_table={}, mapping_row={}, include_full_semantics=False)
    assert projected["semantic_evidence_coverage"] == {"status": "partial", "missing_assets": ["DB.SRC.SOURCE"]}
    assert projected["tables"][0]["notable_columns"] == []
    assert projected["tables"][0]["historical_semantics"]["description"] == "source-v1"
    assert projected["tables"][0]["semantic_status"] == "native_yaml_missing"
