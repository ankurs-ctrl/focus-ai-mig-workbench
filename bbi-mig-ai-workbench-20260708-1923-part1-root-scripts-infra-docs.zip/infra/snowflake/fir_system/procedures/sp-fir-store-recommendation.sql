-- ============================================================
-- SP_FIR_STORE_RECOMMENDATION
-- Thin CRUD tool for AGT_FIR_SYSTEM: stores the agent's recommendation.
-- The agent provides ALL content (target, trigger, type, payload, display).
-- This procedure just writes to the database.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_STORE_RECOMMENDATION(
    "FIR_RECORD_ID" VARCHAR,
    "TARGET_AGENT" VARCHAR,
    "TRIGGER_TYPE" VARCHAR,
    "RECOMMENDATION_TYPE" VARCHAR,
    "PRIORITY" INTEGER,
    "AGENT_PAYLOAD" VARCHAR,
    "CONFIDENCE" FLOAT,
    "AGENT_NOTES" VARCHAR,
    "DISPLAY_MESSAGE" VARCHAR DEFAULT NULL,
    "DISPLAY_OPTIONS" VARCHAR DEFAULT NULL,
    "NOTIFICATION_LAYER" VARCHAR DEFAULT NULL,
    "APPLICABLE_PROJECTS" VARCHAR DEFAULT NULL,
    "APPLICABLE_TABLES" VARCHAR DEFAULT NULL,
    "APPLICABLE_COLUMNS" VARCHAR DEFAULT NULL
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'store_recommendation'
EXECUTE AS OWNER
AS
$$
import json
import uuid
from datetime import datetime


def store_recommendation(
    session,
    fir_record_id: str,
    target_agent: str,
    trigger_type: str,
    recommendation_type: str,
    priority: int,
    agent_payload: str,
    confidence: float,
    agent_notes: str,
    display_message: str = None,
    display_options: str = None,
    notification_layer: str = None,
    applicable_projects: str = None,
    applicable_tables: str = None,
    applicable_columns: str = None
) -> dict:
    """Store the agent's crafted recommendation."""

    recommendation_id = str(uuid.uuid4())

    # Parse JSON string parameters
    def _parse_json_safe(val):
        if not val:
            return None
        try:
            return json.loads(val)
        except (json.JSONDecodeError, TypeError):
            return None

    payload_parsed = _parse_json_safe(agent_payload) or {}
    options_parsed = _parse_json_safe(display_options)
    projects_parsed = _parse_json_safe(applicable_projects)
    tables_parsed = _parse_json_safe(applicable_tables)
    columns_parsed = _parse_json_safe(applicable_columns)

    # INSERT into TBL_FIR_AGENT_RECOMMENDATIONS (explicit column list to match table order)
    options_json = json.dumps(options_parsed) if options_parsed else ''
    projects_json = json.dumps(projects_parsed) if projects_parsed else ''
    tables_json = json.dumps(tables_parsed) if tables_parsed else ''
    columns_json = json.dumps(columns_parsed) if columns_parsed else ''

    session.sql("""
        INSERT INTO __STTM_METADATA_NAMESPACE__.TBL_FIR_AGENT_RECOMMENDATIONS (
            AGENT_RECOMMENDATION_ID, FIR_RECORD_ID, TARGET_AGENT, TRIGGER_TYPE,
            TRIGGER_CONDITION, RECOMMENDATION_TYPE, RECOMMENDATION_PRIORITY,
            AGENT_PAYLOAD, APPLICABLE_PROJECTS, APPLICABLE_TABLES, APPLICABLE_COLUMNS,
            CONFIDENCE, USAGE_COUNT, SUCCESS_COUNT, LAST_USED_AT,
            CREATED_AT, UPDATED_AT, STATUS,
            AGENT_NOTES, DISPLAY_MESSAGE, DISPLAY_OPTIONS, NOTIFICATION_LAYER
        )
        SELECT
            ?, ?, ?, ?,
            NULL, ?, ?,
            PARSE_JSON(?), TRY_PARSE_JSON(?), TRY_PARSE_JSON(?), TRY_PARSE_JSON(?),
            ?, 0, 0, NULL,
            CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 'active',
            ?, ?, TRY_PARSE_JSON(?), ?
    """, [
        recommendation_id, fir_record_id, target_agent, trigger_type,
        recommendation_type, priority,
        json.dumps(payload_parsed), projects_json, tables_json, columns_json,
        confidence,
        agent_notes, display_message, options_json, notification_layer
    ]).collect()

    # Update FIR_360 processing stage
    session.sql("""
        UPDATE __STTM_METADATA_NAMESPACE__.TBL_AGENT_FIR_360
        SET RECOMMENDATION_ID = ?,
            PROCESSING_STAGE = 'completed',
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE FIR_RECORD_ID = ?
          AND PROCESSING_STAGE = 'inference_generated'
    """, [recommendation_id, fir_record_id]).collect()

    return {
        'status': 'success',
        'recommendation_id': recommendation_id,
        'fir_record_id': fir_record_id,
        'target_agent': target_agent,
        'trigger_type': trigger_type,
        'recommendation_type': recommendation_type,
        'priority': priority,
        'confidence': confidence,
        'is_user_notification': target_agent == 'APP_USER_NOTIFICATION'
    }
$$;
