"use client";

import { useMemo, useState } from "react";

import { AiaSearchbox } from "@/components/ui/aia-searchbox";
import type { Column } from "@/features/sttm/types/sttm.types";

export type AccordionJoinChip = {
  id: string;
  label: string;
  /** How many joins this chip stands for; counts above 1 are shown inline. */
  count?: number;
};

export type TableColumnsAccordionProps = {
  columns: Column[];
  /** Joins this table takes part in, rendered as `INNER → Orders` chips. */
  joinChips?: AccordionJoinChip[];
  /** Column names of this table referenced by a join condition. */
  joinConditionColumns?: string[];
  /** Card accent, so the accordion reads as part of the card it opens inside. */
  accentColor?: string;
};

type TabKey = "joinKeys" | "allColumns";

function columnBadge(col: Column) {
  if (col.isPrimaryKey) {
    return { label: "PK", className: "tcol-acc__badge--pk" };
  }
  if (col.isForeignKey) {
    return { label: "FK", className: "tcol-acc__badge--fk" };
  }
  return { label: "—", className: "tcol-acc__badge--none" };
}

/**
 * Column browser that lives inside the table card itself. Search filters both
 * tabs at once, and the list scrolls in place so a table with hundreds of
 * columns never stretches the card past the canvas.
 */
export function TableColumnsAccordion({
  columns,
  joinChips = [],
  joinConditionColumns = [],
  accentColor = "#2563eb",
}: TableColumnsAccordionProps) {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<TabKey>("joinKeys");

  const joinKeyColumns = useMemo(() => {
    const conditionColumns = new Set(
      joinConditionColumns.map((name) => name.toLowerCase()),
    );
    return columns.filter(
      (col) =>
        col.isPrimaryKey ||
        col.isForeignKey ||
        conditionColumns.has(String(col.name ?? "").toLowerCase()),
    );
  }, [columns, joinConditionColumns]);

  const tabs = useMemo(() => {
    const query = search.trim().toLowerCase();
    const applySearch = (source: Column[]) =>
      query
        ? source.filter((col) =>
            `${col.name ?? ""} ${col.type ?? ""}`.toLowerCase().includes(query),
          )
        : source;

    return [
      {
        key: "joinKeys" as TabKey,
        label: "Join Keys",
        columns: applySearch(joinKeyColumns),
        empty: query
          ? "No join keys match your search."
          : "No join keys on this table yet.",
      },
      {
        key: "allColumns" as TabKey,
        label: "All Columns",
        columns: applySearch(columns),
        empty: query ? "No columns match your search." : "No columns on this table.",
      },
    ];
  }, [columns, joinKeyColumns, search]);

  const activePanel = tabs.find((tab) => tab.key === activeTab) ?? tabs[0];

  return (
    <div
      className="tcol-acc nodrag nowheel"
      onClick={(event) => event.stopPropagation()}
    >
      {joinChips.length > 0 ? (
        <div className="tcol-acc__joins sttm-scroll-pane">
          {joinChips.map((chip) => (
            <span
              key={chip.id}
              className="tcol-acc__join-chip"
              title={
                chip.count && chip.count > 1
                  ? `${chip.label} · ${chip.count} joins`
                  : chip.label
              }
            >
              {chip.label}
              {chip.count && chip.count > 1 ? (
                <span className="tcol-acc__join-chip-count">{chip.count}</span>
              ) : null}
            </span>
          ))}
        </div>
      ) : null}

      <div className="tcol-acc__search">
        <AiaSearchbox
          value={search}
          onChange={setSearch}
          placeholder="Search columns..."
          showSearchIcon
          sx={{
            minHeight: 0,
            py: 0.5,
            px: 1,
            backgroundColor: "#f9fafb",
            border: "1px solid #e5e7eb",
            "&:focus-within": {
              backgroundColor: "#ffffff",
              borderColor: "#cbd5e1",
              boxShadow: "none",
            },
          }}
          inputSx={{
            "& .MuiInputBase-input": {
              fontSize: 12,
            },
          }}
        />
      </div>

      <div className="tcol-acc__tabs" role="tablist">
        {tabs.map((tab) => {
          const isActive = tab.key === activePanel.key;
          return (
            <button
              key={tab.key}
              type="button"
              role="tab"
              id={`tcol-acc-tab-${tab.key}`}
              aria-selected={isActive}
              aria-controls={`tcol-acc-panel-${tab.key}`}
              className={`tcol-acc__tab ${isActive ? "tcol-acc__tab--active" : ""}`}
              style={isActive ? { color: accentColor } : undefined}
              onClick={(event) => {
                event.stopPropagation();
                setActiveTab(tab.key);
              }}
            >
              {tab.label}
              <span
                className="tcol-acc__tab-count"
                style={
                  isActive
                    ? { color: accentColor, backgroundColor: `${accentColor}14` }
                    : undefined
                }
              >
                {tab.columns.length}
              </span>
            </button>
          );
        })}
      </div>

      <div
        className="tcol-acc__list sttm-scroll-pane"
        role="tabpanel"
        id={`tcol-acc-panel-${activePanel.key}`}
        aria-labelledby={`tcol-acc-tab-${activePanel.key}`}
      >
        {activePanel.columns.length === 0 ? (
          <div className="tcol-acc__empty">{activePanel.empty}</div>
        ) : (
          activePanel.columns.map((col, index) => {
            const badge = columnBadge(col);
            return (
              <div className="tcol-acc__row" key={`${col.name ?? "column"}-${index}`}>
                <span className={`tcol-acc__badge ${badge.className}`}>
                  {badge.label}
                </span>
                <span className="tcol-acc__col-name">{col.name}</span>
                <span className="tcol-acc__col-type">
                  {(col.type ?? "").toUpperCase()}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
