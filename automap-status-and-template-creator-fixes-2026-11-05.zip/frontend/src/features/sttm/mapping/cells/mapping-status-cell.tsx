import { plainValidationMessage } from '../mapping-review-model';
import { AiaTooltip, AiaTableCellPrimitive, AiaChip, AiaBox } from '@/components/ui';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import type { SxProps, Theme } from '@mui/material/styles';
import type { MappingStatus } from '@/features/sttm/types/sttm.types';
import type { AiaChipColor } from '@/components/ui/aia-chip';

type MappingStatusCellProps = {
  status: MappingStatus;
  details?: string;
  align?: 'left' | 'center' | 'right';
  width?: number | string;
  minWidth?: number | string;
  sx?: SxProps<Theme>;
};

const STATUS_LABELS: Record<MappingStatus, string> = {
  MAPPED: 'Mapped',
  PROCESSING: 'Processing',
  UNMAPPED: 'Unmapped',
  NEEDS_VALIDATION: 'Needs validation',
  VALIDATION_FAILED: 'Validation failed',
};

const STATUS_COLORS: Record<MappingStatus, AiaChipColor> = {
  MAPPED: 'success',
  PROCESSING: 'primary',
  UNMAPPED: 'warning',
  NEEDS_VALIDATION: 'warning',
  VALIDATION_FAILED: 'error',
};

export const MappingStatusCell = ({
  status,
  details,
  align = 'left',
  width = 110,
  minWidth,
  sx,
}: MappingStatusCellProps) => (
  <AiaTableCellPrimitive align={align} sx={aiaTableCellSx({width,minWidth,sx})}>
    <AiaTooltip title={status==='VALIDATION_FAILED'&&details?plainValidationMessage(details):details || STATUS_LABELS[status]} arrow><span>
      <AiaChip label={STATUS_LABELS[status]} color={STATUS_COLORS[status]} size="small" rounded />
    </span></AiaTooltip>
    {status==='VALIDATION_FAILED'&&details?<AiaBox component="details" sx={{fontFamily:'inherit',fontSize:'0.75rem',mt:.5,overflowWrap:'anywhere'}}>
      <summary>Details</summary>
      <AiaBox>{plainValidationMessage(details)}</AiaBox>
      <AiaBox component="code" sx={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{details}</AiaBox>
    </AiaBox>:null}
  </AiaTableCellPrimitive>
);
