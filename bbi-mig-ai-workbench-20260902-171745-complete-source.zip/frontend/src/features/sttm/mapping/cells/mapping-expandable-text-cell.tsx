'use client';

import { useCallback, useLayoutEffect, useRef, useState } from 'react';
import type { SxProps, Theme } from '@mui/material/styles';

import { AiaBox, AiaIconButton, AiaTableCellPrimitive } from '@/components/ui';
import { AiaInput } from '@/components/ui/aia-input';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import { TYPOGRAPHY_TOKENS, tokenLineHeight } from '@/config/typography-tokens';
import {
  KeyboardArrowDownRoundedIcon,
  KeyboardArrowRightRoundedIcon,
} from '@/utils/icons';
import {
  MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX,
  MAPPING_TABLE_SECONDARY_INPUT_SX,
  MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
} from '../mapping-table-styles';

const EXPAND_TOGGLE_WIDTH = 28;
const INPUT_PADDING_Y_PX = 8;
const FONT_SIZE_PX = TYPOGRAPHY_TOKENS.secondaryText.fontSize;
const LINE_HEIGHT = tokenLineHeight(TYPOGRAPHY_TOKENS.secondaryText);
const LINE_HEIGHT_PX = Math.round(FONT_SIZE_PX * LINE_HEIGHT);
/** Collapsed control matches source-column / single-line expand height. */
const COLLAPSED_CONTROL_HEIGHT_PX = MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX;

type MappingExpandableTextCellProps = {
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  width?: number | string;
  minWidth?: number | string;
  inputSx?: SxProps<Theme>;
  sx?: SxProps<Theme>;
};

function measureFullContentHeight(textarea: HTMLTextAreaElement): number {
  const previousHeight = textarea.style.height;
  const previousMaxHeight = textarea.style.maxHeight;
  textarea.style.maxHeight = 'none';
  textarea.style.height = '0px';
  const fullHeight = textarea.scrollHeight;
  textarea.style.height = previousHeight;
  textarea.style.maxHeight = previousMaxHeight;
  return fullHeight;
}

function syncTextareaHeight(textarea: HTMLTextAreaElement, expanded: boolean) {
  const fullHeight = measureFullContentHeight(textarea);
  if (expanded) {
    const nextHeight = Math.max(fullHeight, COLLAPSED_CONTROL_HEIGHT_PX);
    textarea.style.maxHeight = 'none';
    textarea.style.overflowY = nextHeight > COLLAPSED_CONTROL_HEIGHT_PX ? 'auto' : 'hidden';
    textarea.style.height = `${nextHeight}px`;
    return fullHeight;
  }

  // Empty / short collapsed rows keep the same height as single-line expand mode.
  textarea.style.maxHeight = `${COLLAPSED_CONTROL_HEIGHT_PX}px`;
  textarea.style.overflowY = 'hidden';
  textarea.style.height = `${COLLAPSED_CONTROL_HEIGHT_PX}px`;
  return fullHeight;
}

export const MappingExpandableTextCell = ({
  placeholder,
  value,
  onChange,
  width,
  minWidth,
  inputSx,
  sx,
}: MappingExpandableTextCellProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [expanded, setExpanded] = useState(false);
  const [canExpand, setCanExpand] = useState(false);

  const syncHeight = useCallback(() => {
    const textarea = containerRef.current?.querySelector('textarea');
    if (!textarea) {
      return;
    }

    const fullHeight = syncTextareaHeight(textarea, expanded);
    const needsExpansion = fullHeight > COLLAPSED_CONTROL_HEIGHT_PX + 1;
    setCanExpand(needsExpansion);
    if (!needsExpansion && expanded) {
      setExpanded(false);
    }
  }, [expanded]);

  useLayoutEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      syncHeight();
    });
    return () => window.cancelAnimationFrame(frame);
  }, [value, expanded, width, syncHeight]);

  const toggleEnabled = canExpand || expanded;
  const ChevronIcon = expanded ? KeyboardArrowDownRoundedIcon : KeyboardArrowRightRoundedIcon;

  return (
    <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx }, { overflow: 'visible' })}>
      <AiaBox
        ref={containerRef}
        sx={{
          display: 'flex',
          alignItems: 'stretch',
          width: '100%',
          minWidth: 0,
          height: expanded ? 'auto' : COLLAPSED_CONTROL_HEIGHT_PX,
          minHeight: COLLAPSED_CONTROL_HEIGHT_PX,
          border: '1px solid #e5e7eb',
          borderRadius: '6px',
          bgcolor: '#fff',
          overflow: 'hidden',
        }}
      >
        <AiaIconButton
          type="button"
          size="small"
          disabled={!toggleEnabled}
          aria-expanded={expanded}
          aria-label={expanded ? 'Collapse text' : 'Expand text'}
          onClick={() => setExpanded((prev) => !prev)}
          sx={{
            flexShrink: 0,
            width: EXPAND_TOGGLE_WIDTH,
            minWidth: EXPAND_TOGGLE_WIDTH,
            alignSelf: 'stretch',
            borderRadius: 0,
            borderRight: '1px solid #e5e7eb',
            color: toggleEnabled ? 'var(--aia-primary-bg-color)' : '#cbd5e1',
            bgcolor: '#fafafa',
            '&:hover': {
              bgcolor: toggleEnabled
                ? 'color-mix(in srgb, var(--aia-primary-bg-color) 8%, #fafafa)'
                : '#fafafa',
            },
          }}
        >
          <ChevronIcon sx={{ fontSize: 18 }} />
        </AiaIconButton>
        <AiaBox sx={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'flex-start' }}>
          <AiaInput
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            size="small"
            fullWidth
            multiline
            minRows={1}
            sx={[
              MAPPING_TABLE_SECONDARY_INPUT_SX,
              ...(inputSx ? (Array.isArray(inputSx) ? inputSx : [inputSx]) : []),
              {
                width: '100%',
                '& .MuiOutlinedInput-root': {
                  ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
                  alignItems: 'flex-start',
                  minHeight: COLLAPSED_CONTROL_HEIGHT_PX,
                  height: 'auto',
                  borderRadius: 0,
                  bgcolor: '#fff',
                  py: '0 !important',
                },
                '& .MuiOutlinedInput-notchedOutline': {
                  border: 'none',
                },
                '& .MuiInputBase-input, & .MuiInputBase-inputMultiline': {
                  ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
                  fontSize: `${FONT_SIZE_PX}px !important`,
                  lineHeight: `${LINE_HEIGHT_PX}px !important`,
                  paddingTop: `${INPUT_PADDING_Y_PX}px !important`,
                  paddingBottom: `${INPUT_PADDING_Y_PX}px !important`,
                  whiteSpace: 'pre-wrap',
                  overflowWrap: 'anywhere',
                  overflowX: 'hidden',
                  boxSizing: 'border-box',
                  resize: 'none',
                },
              },
            ]}
          />
        </AiaBox>
      </AiaBox>
    </AiaTableCellPrimitive>
  );
};
