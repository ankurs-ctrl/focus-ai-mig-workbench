# Mapping, Summary and published SQL parity — V17

Cumulative over V16 and both client baseline ZIPs. All previous Auto-map, Deep Agent, PR #63, SQL-upload, publication and administration files remain included. Earlier release limitations still apply outside these SQL fixes.

## Corrected causes

The Mapping SQL viewer renamed aliases for display while Copy retained the original string. It now displays the exact artifact passed to Copy/Edit. The backend compiler already produces readable relation aliases consistently across its SQL forms; no second textual SQL rewrite is applied by the viewer. Quoted identifiers and literal contents remain untouched.

Final Summary previously omitted sourceQueryModifiers when constructing its compiler graph. Mapping included them. Both pages now use those modifiers, preserving artifact currency and avoiding a different fallback query on Summary.

An optimized preview could override the Mapping SQL view before synchronization. Previewing an alternative no longer changes the canonical SQL display. Optimization still requires synchronization and validation before it becomes the current saved definition.

The publication snapshot explicitly identifies the current compiled artifact versus authored SQL. Server validation still reconstructs the graph, rows, population and current Values and compares the SQL; client flags/hashes never authorize an incompatible query. Original uploaded raw SQL is retained as provenance rather than overriding a valid current compiled mapping.

The server captures published_mapping_sql as the exact displayed extraction script, including SET Firm Value declarations when used. Every statement is checked against the server-compiled current script. The published SQL header stores that captured script. The optional generated INSERT remains separately retained as compiled_mapping_sql for execution-related consumers. Published definitions are metadata; no source/target data DML is performed.

## Requested inspection: draft behavior already exists

No new auto-compile behavior was added. Mapping already builds a provisional SQL display while compilation is pending and when auto-compile is off. The existing CTE-aware builder includes available source preparation, joins, row definitions and filters. Incomplete dependencies may yield a labeled partial draft or explanatory comments, not a claim of executable readiness. The live browser check verified nonempty SQL with auto-compile off and on. Copy/execute/publication still require the current appropriate artifact and validation; provisional UI SQL is not silently persisted as compiled SQL.

## Verification

194 backend publication/compiler tests pass, including exact displayed-script capture, rejection of altered displayed SQL, current compiled mapping superseding an old uploaded query, quoted apostrophes and Firm Value SET declarations. 19 snapshot/autosave tests and 562 frontend tests pass. Current TypeScript and reconstructed baseline-(3) TypeScript pass.

The actual local browser opened isolated mapping 7601, toggled auto-compile and compared Mapping and Summary rendered SQL: identical 3592 characters, no page errors. Publication capture tests use the real server validator/capture logic with a test SQL session. No native publication was performed and no client mapping was touched. Cold local navigation took longer than the initial test's selectors allowed; failed harness attempts were not counted as passed. The successful run uses the actual Final SQL tab's accessible name, including its count badge.

## Deployment

Apply files/ over the repository root and rebuild matching frontend/API images; deploy the cumulative matching workers as usual. Preserve client.env, environment files and credentials. No new environment variable, table, grant, bootstrap step or Snowflake agent-spec deployment is required for V17. Added fields are additive JSON snapshot fields and validation output. Existing published versions remain immutable; this change applies to new captures. No CodeCommit synchronization or SPCS deployment is claimed.
