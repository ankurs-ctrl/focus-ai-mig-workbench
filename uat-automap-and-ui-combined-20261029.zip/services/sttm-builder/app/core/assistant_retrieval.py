"""Request-local exact context retrieval; no cross-user or mutable shared handles."""
from copy import deepcopy
import hashlib
import json
from typing import Any

from app.core.agent_payload_budget import AgentPayloadBudgetError


def _text(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def scoped_context(payload: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    result = deepcopy(payload)
    dictionary = result.pop('context_value_dictionary', [])
    def expand(value):
        if isinstance(value, dict):
            if set(value) == {'$ctx'}:
                index = value['$ctx']
                if isinstance(index, int) and 0 <= index < len(dictionary):
                    return deepcopy(dictionary[index])
                raise ValueError('Unresolved context value reference')
            return {key: expand(item) for key, item in value.items()}
        return [expand(item) for item in value] if isinstance(value, list) else value
    result = expand(result)
    reference_root = deepcopy(result)
    def resolve_same_as(value, seen=()):
        if isinstance(value, dict):
            if set(value) == {'same_as'}:
                path = value['same_as']
                if not isinstance(path, str) or path in seen:
                    raise ValueError('Invalid or cyclic context reference')
                target = reference_root
                for part in path.split('.'):
                    if not isinstance(target, dict) or part not in target:
                        raise ValueError('Unavailable context reference')
                    target = target[part]
                return resolve_same_as(target, (*seen, path))
            return {key: resolve_same_as(item, seen) for key, item in value.items()}
        return [resolve_same_as(item, seen) for item in value] if isinstance(value, list) else value
    result = resolve_same_as(result)
    context = result.get('context') or {}
    workspace = context.get('workspace_context') or {}
    # Request hash binds every section to the already-authorized current snapshot.
    snapshot_hash = hashlib.sha256(_text(payload).encode()).hexdigest()
    sections = {}
    if context.get('relation_graph') is not None and workspace.get('relation_graph') == context.get('relation_graph'):
        workspace['relation_graph'] = {'same_as': 'context.relation_graph'}
    elif workspace.get('relation_graph'):
        # The saved graph can differ from the live graph; retain both exactly
        # without sending a second executable namespace in the initial packet.
        sections['workspace.relation_graph'] = workspace.pop('relation_graph')
    fingerprint = workspace.get('compiled_mapping_context_hash')
    if isinstance(fingerprint, str) and len(fingerprint) > 256:
        # Legacy clients put serialized compiler inputs here, not a digest.
        sections['workspace.compiled_mapping_context_hash'] = workspace.pop('compiled_mapping_context_hash')
    for container, prefix, keys in (
        (context, 'context', ('semantic_context', 'learning_context', 'execution_context', 'datahub_context', 'derived_source_lineage', 'context_selection', 'key_contracts')),
        (workspace, 'workspace', ('derived_sources', 'raw_mapping_sql', 'parsed_mapping_model', 'mapping_sql', 'mapping_preview_sql', 'compiled_mapping_sql', 'compiled_mapping_script_sql', 'compiled_mapping_preview_sql', 'compiled_mapping_semantic_context', 'pending_mapping_proposals', 'conversation_history', 'auto_map_outcome', 'validation_history')),
    ):
        for key in keys:
            if container.get(key):
                section = f'{prefix}.{key}'
                sections[section] = container.pop(key)
    # Search is optional evidence discovery, not a substitute for project policy
    # or known corrections. Keep these authoritative constraints in every turn.
    learning = sections.get('context.learning_context') or {}
    required_learning = {key: deepcopy(learning[key]) for key in (
        'project_context', 'mapping_intent', 'context_key', 'linked_project_ids',
        'linked_mapping_ids', 'correction_history', 'mandatory_negative_evidence',
        'retrieval_diagnostics',
    ) if learning.get(key)}
    if required_learning:
        context['learning_context'] = required_learning
    derived = sections.get('workspace.derived_sources') or []
    if isinstance(derived, list):
        context['workspace_derived_source_index'] = [
            {**{key: deepcopy(item[key]) for key in (
                'id', 'name', 'is_selected', 'sql_hash', 'row_grain', 'purpose',
            ) if key in item}, 'section': 'workspace.derived_sources', 'path': [index]}
            for index, item in enumerate(derived) if isinstance(item, dict)
        ]
    # Keep graph identity/columns/edges inline, retrieve the exact SQL on demand.
    graph = context.get('relation_graph') or {}
    if isinstance(graph, dict):
        for node in graph.get('nodes') or []:
            if node.get('sql_text'):
                sections[f"relation_sql:{node['relation_id']}"] = node.pop('sql_text')
    # Wide physical schemas must be pageable too, not only derived SQL. Keep
    # executable graph topology and population constraints inline and exact.
    if isinstance(graph, dict):
        for node in graph.get('nodes') or []:
            columns = node.get('output_columns')
            if columns and len(_text(columns).encode()) > 4096:
                key = f"relation_columns:{node['relation_id']}"
                sections[key] = node.pop('output_columns')
                node['output_columns_reference'] = {'section': key, 'count': len(columns), 'complete_inline': False}
    for container, prefix in ((context, 'context'), (workspace, 'workspace')):
        selected = container.get('selected_columns_by_table')
        if selected and len(_text(selected).encode()) > 4096:
            key = f'{prefix}.selected_columns_by_table'
            sections[key] = container.pop('selected_columns_by_table')
            container['selected_columns_reference'] = {'section': key, 'complete_inline': False}
    rows = workspace.get('mapping_rows')
    if isinstance(rows, list) and len(_text(rows).encode()) > 8192:
        key = 'workspace.mapping_rows'
        sections[key] = rows
        checked = set(workspace.get('checked_mapping_row_ids') or [])
        if workspace.get('active_mapping_row_id'):
            checked.add(workspace['active_mapping_row_id'])
        workspace['mapping_rows'] = [row for row in rows if row.get('id') in checked]
        workspace['mapping_rows_reference'] = {
            'section': key, 'count': len(rows), 'complete_inline': False,
            'index': [{'id': row.get('id'), 'target_column': row.get('target_column'), 'path': [index]}
                      for index, row in enumerate(rows)],
        }
    history = sections.get('workspace.conversation_history') or []
    for index in range(len(history) - 1, -1, -1):
        turn = history[index]
        if isinstance(turn, dict) and turn.get('role') == 'assistant' and turn.get('content'):
            reference = {'section': 'workspace.conversation_history', 'path': [index],
                         'policy': 'Historical visible answer, not current workspace evidence. Reformat without changing facts or applying mappings.'}
            if len(_text(turn).encode()) <= 8192:
                reference['content'] = turn['content']
            context['recent_visible_answer'] = reference
            break
    context['exact_detail_policy'] = (
        'A reference or index is not complete evidence. Retrieve exact required column metadata, '
        'mapping rows or selected-column lists before reasoning about omitted entries. '
        'Inline mapping_rows may contain only checked rows, not all mapped columns.'
    )
    manifest = {key: {'sha256': hashlib.sha256(_text(value).encode()).hexdigest(), 'bytes': len(_text(value).encode()),
                      'items': len(value) if isinstance(value, (list, dict, str)) else None,
                      'json_characters': len(_text(value))}
                for key, value in sections.items()}
    context['exact_context_retrieval'] = {
        'snapshot_hash': snapshot_hash, 'sections': manifest,
        'protocol': 'WORKSPACE_CONTEXT is an application-handled response delegation, NOT a registered Snowflake tool. Do NOT look for a callable tool or tell the user to supply omitted content. The application inspects your final JSON response, executes a validated bounded read, and invokes you again with the exact result. If omitted context is required, your entire response MUST be a JSON object (no Markdown fence or prose) with top-level meta.delegation containing ALL required fields: tool:"WORKSPACE_CONTEXT", snapshot_hash:<this exact hash>, section:<exact listed key>, section_hash:<that section sha256>, path:[], start:<integer>, end:<integer>. This response is a retrieval request, not a completed user answer. Optional path selects nested object keys or list indexes. Without encoding, string offsets use items; encoding:"json_text" uses json_characters. Request only the needed range (at most 8 reads per turn). After the backend supplies retrieved_workspace_context, answer the original request in the normal final-response contract, or emit another top-level meta.delegation. Missing required content must be reported, never guessed. Search is historical evidence, not current SQL.',
        'response_template': {
            'meta': {'delegation': {
                'tool': 'WORKSPACE_CONTEXT', 'snapshot_hash': snapshot_hash,
                'section': '<exact manifest key>', 'section_hash': '<listed sha256>',
                'path': [], 'start': 0, 'end': '<bounded integer>',
            }},
        },
    }
    context['assistant_evidence_policy'] = {
        'current_state': 'Current selection, live relation graph, mapping rows, filters, project Values and required learning constraints are authoritative. Never replace them with Search results or prior conversation.',
        'historical_evidence': 'Use registered SearchWorkbenchRag and SearchFIRKnowledge when historical knowledge is needed. Match project and source/target scope; a search hit is not approval or proof of current-source compatibility.',
        'workspace_details': 'Search cannot recover unsaved CTE SQL, local edits or private request artifacts. Retrieve exact needed paths from the manifest before interpreting omitted definitions. Index entries identify assets; they do not establish semantic suitability.',
        'delegation': 'Choose registered specialists when needed. Resolve required workspace details first and pass task-relevant exact context and constraints, not manifest handles that a subagent cannot dereference. Analyst is a backend delegation, not a registered tool. For SQL generation return the normal response JSON with top-level meta.delegation={"tool":"CORTEX_ANALYST","purpose":"sql_generation","requires_actual_rows":false,"question":"<self-contained SQL request with exact required fields, evidence and constraints>"}. The backend will generate without preview execution. Do not call a transformation specialist instead when Analyst is explicitly requested. For data questions use the existing requires_actual_rows:true contract.',
    }
    return result, {'snapshot_hash': snapshot_hash, 'sections': sections, 'manifest': manifest}


def retrieve_context(store: dict[str, Any], delegation: dict[str, Any], max_bytes: int) -> dict[str, Any]:
    key = delegation.get('section')
    if delegation.get('snapshot_hash') != store['snapshot_hash'] or key not in store['sections']:
        raise ValueError('Unavailable or stale workspace context reference')
    if delegation.get('section_hash') != store['manifest'][key]['sha256']:
        raise ValueError('Workspace context section hash mismatch')
    value = store['sections'][key]
    path = delegation.get('path', [])
    if not isinstance(path, list) or len(path) > 12:
        raise ValueError('Invalid workspace section path')
    for part in path:
        if isinstance(value, dict) and isinstance(part, str) and part in value:
            value = value[part]
        elif isinstance(value, list) and type(part) is int and 0 <= part < len(value):
            value = value[part]
        else:
            raise ValueError('Unavailable workspace section path')
    encoding = delegation.get('encoding')
    if encoding is not None and encoding != 'json_text':
        raise ValueError('Unsupported context range encoding')
    if encoding == 'json_text':
        value = _text(value)
    start, end = delegation.get('start', 0), delegation.get('end')
    if isinstance(start, bool) or not isinstance(start, int) or start < 0 or isinstance(end, bool) or not isinstance(end, int) or end <= start:
        raise ValueError('An explicit bounded context range is required')
    if isinstance(value, dict):
        entries = list(value.items())
        selected, total = dict(entries[start:end]), len(entries)
    elif isinstance(value, (list, str)):
        selected, total = value[start:end], len(value)
    else:
        raise ValueError('Workspace context section does not support ranged retrieval')
    if start >= total or end > total:
        raise ValueError('Workspace context range is outside the exact section')
    result = {'section': key, 'snapshot_hash': store['snapshot_hash'], 'section_hash': store['manifest'][key]['sha256'],
              'path': path, 'encoding': encoding, 'start': start, 'end': end, 'total': total, 'complete': start == 0 and end == total, 'data': selected}
    if len(_text(result).encode()) > max_bytes:
        raise AgentPayloadBudgetError('Requested context range exceeds the bounded retrieval budget; request a smaller range')
    return result


def budget_messages(messages: list[dict[str, Any]], *, max_chars: int, max_bytes: int) -> list[dict[str, Any]]:
    def fits(value):
        text = _text(value)
        return len(text) <= max_chars and len(text.encode()) <= max_bytes
    result = deepcopy(messages)
    # Only historical turns can be omitted; current request/tool data stays exact.
    removed = 0
    while len(result) > 1 and not fits(result):
        result.pop(0)
        removed += 1
    if removed:
        notice = {'role': 'user', 'content': [{'type': 'text', 'text': 'Older history omitted; do not infer it.'}]}
        while len(result) > 1 and not fits([notice, *result]):
            result.pop(0)
        if fits([notice, *result]):
            result.insert(0, notice)
    if not fits(result):
        raise AgentPayloadBudgetError('Required current message and retrieved context exceed the complete-message budget')
    return result