from __future__ import annotations

import re
from collections import deque
from typing import Any


def _key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def build_manifest(
    prompt: str,
    requested_mappings: list[str] | None = None,
    target_scope: list[str] | None = None,
) -> list[dict[str, Any]]:
    names = [value.strip() for value in requested_mappings or [] if value.strip()]
    if not names:
        names = [str(target).split('.')[-1].strip('"') for target in target_scope or []]
    if not names:
        names = ["Mapping"]
    targets = target_scope or []
    selected_keys = {_key(name) for name in names}
    manifest: list[dict[str, Any]] = []
    for index, name in enumerate(names):
        mapping_key = _key(name) or f"mapping_{index + 1}"
        dependencies: list[str] = []
        manifest.append(
            {
                "mapping_key": mapping_key,
                "mapping_name": name,
                "target_table": targets[index] if index < len(targets) else None,
                "dependencies": dependencies,
                "status": "PENDING",
            }
        )
    if len({item["mapping_key"] for item in manifest}) != len(manifest):
        raise ValueError("Duplicate mapping names require distinct mapping keys")
    _assert_acyclic(manifest)
    return manifest


def build_manifest_from_specs(
    mapping_specs: list[dict[str, Any]],
    dependencies: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """One manifest item per validated mapping spec, in plan order.

    The validated plan is the source of truth for multi-target work; deriving
    the manifest from free-text requested names instead produced a single
    placeholder mapping that no target could be matched to.
    """
    manifest: list[dict[str, Any]] = []
    for index, spec in enumerate(mapping_specs):
        target = str(spec.get("target_table") or "").strip()
        if not target:
            raise ValueError("mapping_target_contract_missing")
        key = str(spec.get("mapping_key") or "") or _key(target.split(".")[-1]) or f"mapping_{index + 1}"
        manifest.append({
            "mapping_key": key,
            "mapping_name": str(spec.get("mapping_name") or target.split(".")[-1].strip('"')),
            "target_table": target,
            "dependencies": [],
            "status": "PENDING",
        })
    keys = {item["mapping_key"] for item in manifest}
    if len(keys) != len(manifest):
        raise ValueError("Duplicate mapping names require distinct mapping keys")
    producers: dict[str, set[str]] = {key: set() for key in keys}
    for edge in [*(dependencies or []), *(d for spec in mapping_specs for d in spec.get("dependencies") or [])]:
        consumer, producer = str(edge.get("consumer_mapping") or ""), str(edge.get("producer_mapping") or "")
        if consumer in producers and producer in keys and producer != consumer:
            producers[consumer].add(producer)
    for item in manifest:
        item["dependencies"] = sorted(producers[item["mapping_key"]])
    _assert_acyclic(manifest)
    return manifest


def _assert_acyclic(manifest: list[dict[str, Any]]) -> None:
    indegree = {str(item["mapping_key"]): 0 for item in manifest}
    dependents: dict[str, list[str]] = {key: [] for key in indegree}
    for item in manifest:
        key = str(item["mapping_key"])
        for dependency in item.get("dependencies") or []:
            if dependency not in indegree:
                raise ValueError(f"Unknown mapping dependency {dependency}")
            indegree[key] += 1
            dependents[dependency].append(key)
    ready = deque(key for key, count in indegree.items() if count == 0)
    visited = 0
    while ready:
        key = ready.popleft()
        visited += 1
        for dependent in dependents[key]:
            indegree[dependent] -= 1
            if indegree[dependent] == 0:
                ready.append(dependent)
    if visited != len(manifest):
        raise ValueError("Mapping dependency graph contains a cycle")


def topological_order(manifest: list[dict[str, Any]]) -> list[str]:
    _assert_acyclic(manifest)
    by_key = {str(item["mapping_key"]): item for item in manifest}
    result: list[str] = []
    remaining = set(by_key)
    while remaining:
        ready = sorted(
            key for key in remaining
            if set(by_key[key].get("dependencies") or []).issubset(result)
        )
        if not ready:
            raise ValueError("Mapping dependency graph cannot be scheduled")
        result.extend(ready)
        remaining.difference_update(ready)
    return result


def invalidate_downstream(
    manifest: list[dict[str, Any]], changed_mapping_key: str
) -> list[str]:
    stale: list[str] = []
    queue = deque([changed_mapping_key])
    while queue:
        current = queue.popleft()
        for item in manifest:
            key = str(item["mapping_key"])
            if current in (item.get("dependencies") or []) and key not in stale:
                item["status"] = "STALE"
                item["stale_reason"] = f"Upstream contract {changed_mapping_key} changed"
                stale.append(key)
                queue.append(key)
    return stale
