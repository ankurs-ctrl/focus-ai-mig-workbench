"""Synthetic Household regression: original reference is never modified/executed."""
from pathlib import Path
from app.core.sql_parser import parse_sql_document
from app.schema.sttm_builder import RelationGraphContext
from app.schema.mapping_sql import MappingSqlCompileRequest,MappingSqlMappingItem
from app.core.mapping_sql import MappingSqlService
from sqlglot import parse_one,exp

FIXTURE=Path(__file__).resolve().parents[2]/'fixtures/sql_upload/evernest_household_relation_instances.sql'


def test_synthetic_household_has_eleven_physical_tables_and_distinct_lookup_instances():
    parsed=parse_sql_document(FIXTURE.read_text()).to_dict()
    assert len(parsed['source_tables'])==11
    outer=next(scope for scope in parsed['query_scopes']if not scope['parent_scope_id'])
    relations=outer['relations']
    country=[r for r in relations if r['relation_name'].endswith('COUNTRY_CODES')]
    state=[r for r in relations if r['relation_name'].endswith('STATE_CODES')]
    assert len(country)==len(state)==2
    assert len({r['relation_instance_id']for r in country+state})==4
    assert {r['alias']for r in country}=={'ccMail','ccOther'}
    assert next(r for r in country if r['alias']=='ccOther')['alias_quoted']is True
    assert len(outer['joins'])==4 and all(j['join_type']=='LEFT'for j in outer['joins'])
    assert 'other_country' in outer['joins'][1]['predicate']
    assert 'billing_country' not in outer['joins'][1]['predicate']


def test_backend_compiler_and_json_reopen_preserve_repeated_physical_bindings():
    # A small executable projection isolates the relation-instance contract
    # independently of the fixture's external tables and household policy.
    table={'database':'REGRESSION_DB','schema':'EVERNEST','table':'COUNTRY_CODES'}
    graph=RelationGraphContext.model_validate({'nodes':[
        {'relation_id':'mail','kind':'PHYSICAL_TABLE','alias':'ccMail','table':table,
         'output_columns':[{'name':'COUNTRY_CODE','data_type':'VARCHAR'}]},
        {'relation_id':'other','kind':'PHYSICAL_TABLE','alias':'ccOther','table':table,
         'output_columns':[{'name':'COUNTRY_CODE','data_type':'VARCHAR'}]}],
        'edges':[{'edge_id':'country','left_relation_id':'mail','right_relation_id':'other','join_type':'LEFT',
          'additional_predicate':'ccMail.COUNTRY_CODE = ccOther.COUNTRY_CODE'}]})
    reopened=RelationGraphContext.model_validate_json(graph.model_dump_json())
    request=MappingSqlCompileRequest(relation_graph=reopened,driving_relation_id='mail',mappings=[
        MappingSqlMappingItem(target_column='BillingCountry',source_columns=['ccMail.COUNTRY_CODE'],rule='Direct'),
        MappingSqlMappingItem(target_column='OtherCountry',source_columns=['ccOther.COUNTRY_CODE'],rule='Direct')],
        validate_with_explain=False,allow_unresolved_placeholders=False)
    result=MappingSqlService(session=None,analyst_client=None).compile(request)
    assert result.ready and result.valid
    tree=parse_one(result.preview_sql,read='snowflake')
    assert len(list(tree.find_all(exp.Table)))==2
    assert len(tree.args['joins'])==1
    assert {c.table.upper()for c in tree.find_all(exp.Column)}=={'CCMAIL','CCOTHER'}


def test_household_upload_apply_save_reopen_compile_preserves_lookup_occurrences():
    # Production parser, frontend builder/Apply reducer, JSON graph and compiler.
    from test_sql_upload_real_fixture import run_frontend
    import json
    text=FIXTURE.read_text()
    parsed=parse_sql_document(text).to_dict()
    uploaded={'asset_id':'evernest-synthetic','parsed_summary':parsed,'import_preview':{'sql':text,
      'table_references':[{'raw_identifier':name,'resolved_fqn':name,'reference_role':'source',
        'resolution_status':'resolved','catalog_status':'available','semantic_status':'active'}
        for name in parsed['source_tables']]}}
    result=run_frontend(uploaded)
    workspace=result['workspace']
    assert len(workspace['sourceInstances'])==4
    assert len(workspace['relationships'])==4
    graph=RelationGraphContext.model_validate_json(json.dumps(result['snapshot']['relation_graph']))
    instances={item['relationId'] for item in workspace['sourceInstances']}
    assert {item['tableId'] for item in result['reopenedSources'] if item['tableId'].startswith('sql-instance:')} == instances
    aliases={node.alias for node in graph.nodes if node.kind=='PHYSICAL_TABLE'}
    assert {'ccMail','"ccOther"','scMail','scOther'} <= aliases
    assert len({edge.right_relation_id for edge in graph.edges})==4
    request=MappingSqlCompileRequest(relation_graph=graph,driving_relation_id=workspace['drivingTableId'],
      where_predicates=[workspace['filterSql']],order_by_expressions=[workspace['orderBySql']],
      mappings=[MappingSqlMappingItem(target_column=row['targetColumn'], source_columns=row.get('sourceColumns',[]),
        expression=row.get('expression'),rule=row.get('rule'), target_type=row.get('targetType'), mapping_mode=row.get('mappingMode','source'),
        constant_value=row.get('constantValue')) for row in workspace['mappings']],
      validate_with_explain=False,allow_unresolved_placeholders=False)
    compiled=MappingSqlService(session=None,analyst_client=None).compile(request)
    assert compiled.valid and compiled.ready, compiled.model_dump()
    query=parse_one(compiled.preview_sql,read='snowflake')
    assert len(query.args['joins'])==4
    assert all(join.side=='LEFT' for join in query.args['joins'])
    assert 'other_country' in query.args['joins'][1].sql().lower()
    assert 'billing_country' not in query.args['joins'][1].sql().lower()
    assert '"ccOther"' in compiled.preview_sql
    assert len(list(query.find_all(exp.CTE))) >= 3
    constant=next(item.this for item in query.expressions if item.alias=='EmptyConstant')
    assert isinstance(constant,exp.Literal) and constant.is_string and constant.this==''
    assert result['expressions']['EmptyConstant']=="''"
    assert_synthetic_rows(compiled.preview_sql)
    assert_synthetic_rows(parsed['preview_sql'])
    assert workspace['sql']==text


def test_native_inventory_keeps_repeated_lookup_bindings_distinct():
    from tests.unit.core.test_automap_fast_context import fast_payload
    from tests.unit.core.test_automap_fast_batch import prepared_request
    from app.core.automap_native_contract import build_snapshot
    value=fast_payload()
    table={'database':'REGRESSION_DB','schema':'EVERNEST','table':'COUNTRY_CODES'}
    columns=[{'name':'COUNTRY_CODE','data_type':'VARCHAR'},{'name':'COUNTRY_ALIAS','data_type':'VARCHAR'}]
    value['context']['source_tables']=[table]
    value['context']['semantic_context']=[{'table':table,'semantic_model':{'attributes':columns}}]
    value['context']['relation_graph']={'nodes':[
      {'relation_id':'mail','kind':'PHYSICAL_TABLE','alias':'ccMail','table':table,'output_columns':columns},
      {'relation_id':'other','kind':'PHYSICAL_TABLE','alias':'"ccOther"','table':table,'output_columns':columns}],
      'edges':[{'edge_id':'same-country','left_relation_id':'mail','right_relation_id':'other','join_type':'LEFT',
        'additional_predicate':'ccMail.COUNTRY_CODE="ccOther".COUNTRY_CODE'}]}
    value['context']['workspace_context']={'driving_relation_id':'mail'}
    snapshot=build_snapshot(prepared_request(value),validated_derived=[])
    refs={item['source_ref'] for item in snapshot['sources'].values()}
    assert 'ccMail."COUNTRY_CODE"' in refs
    assert '"ccOther"."COUNTRY_CODE"' in refs
    assert len(snapshot['sources'])==4


def test_ambiguous_physical_name_does_not_choose_a_self_join_binding():
    import pytest
    table={'database':'D','schema':'S','table':'COUNTRY_CODES'}
    graph=RelationGraphContext.model_validate({'nodes':[
        {'relation_id':'mail','kind':'PHYSICAL_TABLE','alias':'ccMail','table':table},
        {'relation_id':'other','kind':'PHYSICAL_TABLE','alias':'"ccOther"','table':table}],
        'edges':[{'edge_id':'pair','left_relation_id':'mail','right_relation_id':'other','join_type':'LEFT',
          'additional_predicate':'ccMail.COUNTRY_CODE="ccOther".COUNTRY_CODE'}]})
    request=MappingSqlCompileRequest(relation_graph=graph,driving_relation_id='mail',
      mappings=[MappingSqlMappingItem(target_column='COUNTRY',source_columns=['D.S.COUNTRY_CODES.COUNTRY_CODE'],rule='Direct')],
      validate_with_explain=False)
    with pytest.raises(ValueError): MappingSqlService(session=None,analyst_client=None).compile(request)


def test_quoted_and_unquoted_alias_case_remain_distinct():
    import pytest
    table={'database':'D','schema':'S','table':'COUNTRY_CODES'}
    nodes={name:__import__('app.schema.sttm_builder',fromlist=['RelationNode']).RelationNode.model_validate(
        {'relation_id':name,'kind':'PHYSICAL_TABLE','alias':alias,'table':table})
        for name,alias in [('mail','ccMail'),('other','"ccOther"')]}
    aliases={'CCMAIL':'mail','ccOther':'other'}
    MappingSqlService._validate_expression_aliases('"ccOther".COUNTRY_CODE',aliases,nodes)
    for sql in ['ccOther.COUNTRY_CODE','"CCOTHER".COUNTRY_CODE','"ccMail".COUNTRY_CODE']:
        with pytest.raises(ValueError,match='Undefined SQL alias'):
            MappingSqlService._validate_expression_aliases(sql,aliases,nodes)


def assert_synthetic_rows(sql):
    # Execute a dialect-translated copy only against temporary in-memory SQLite
    # data. This checks row/population preservation, not Snowflake availability.
    import sqlite3
    from sqlglot import parse
    db=sqlite3.connect(':memory:')
    try:
        seed=FIXTURE.with_name('evernest_household_relation_instances_seed.sql').read_text()
        for statement in parse(seed,read='snowflake'):
            if statement is not None and not isinstance(statement,exp.Use):
                db.execute(statement.sql(dialect='sqlite'))
        tree=parse_one(sql,read='snowflake')
        for table in tree.find_all(exp.Table):
            if table.catalog=='REGRESSION_DB':
                table.set('catalog',None); table.set('db',None)
        rows=db.execute(tree.sql(dialect='sqlite')).fetchall()
        assert rows==[(1,'Pittsburgh','US','CA','PA','ON','Jane Stone','')]
    finally:
        db.close()
