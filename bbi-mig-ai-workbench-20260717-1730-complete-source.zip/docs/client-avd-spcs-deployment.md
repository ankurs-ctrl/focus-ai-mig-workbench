# Client AVD / SPCS deployment runbook

This runbook is for moving the current Workbench build to a client Snowflake
environment where the client IT/admin team controls account-level objects.

The current architecture is:

- one product-facing assistant orchestrator: `AGT_STTM_BUILDER`;
- one separate Auto-map worker service backed by `AGT_SOURCE_MAPPING`;
- one optional admin-only CoCo deep-agent service inside the webapp service;
- custom OAuth inside SPCS, with Snowflake secrets supplying OAuth credentials;
- semantic assets read from the workbench registry, not generated during chat.

`AGT_SEMANTIC_MODEL_V2` is intentionally not part of the web request path. The
client semantic pipeline should publish/refresh registry assets separately.

## 1. What changed since the older client deployment

The old client deployment was a single service and normally used ingress caller
auth. The current deployment needs:

1. Custom OAuth security integration and redirect registration.
2. `securityContext.enableCustomCredentials: true` for the webapp service.
3. OAuth client credentials and session keys stored as Snowflake password
   secrets, not embedded in rendered YAML.
4. Separate private Auto-map SPCS service, usually with two instances.
5. CoCo runtime included in the webapp service and exposed through the app
   same-origin websocket proxy.
6. `AGT_STTM_BUILDER` as the normal assistant orchestrator. The
   `SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT` env var is compatibility-only and
   should be blank or set to `AGT_STTM_BUILDER`.

## 2. Client IT/admin prerequisites

Ask the client IT/admin team to create or approve these account-level objects.
Names below are examples; use the client naming standard.

### Roles and warehouses

- Deployment/admin role with permission to create/update SPCS objects.
- Runtime role for the app service.
- User roles that will sign in through OAuth, for example `FOCUS_ADMIN`.
- Warehouse for agent/procedure/query work.

Minimum role capabilities typically needed by the deployment/admin role:

- `CREATE DATABASE` or ownership on the target database.
- `CREATE SCHEMA` or ownership on the target schema.
- `CREATE SERVICE`, `CREATE COMPUTE POOL`, and `CREATE IMAGE REPOSITORY`.
- `BIND SERVICE ENDPOINT` on the account.
- `CREATE SECRET` in the deployment schema.
- `CREATE NETWORK RULE` and `CREATE EXTERNAL ACCESS INTEGRATION`.
- `CREATE SECURITY INTEGRATION` for the OAuth integration.
- ability to create/replace Cortex Agents and procedures used by the workbench.

Minimum runtime/user capabilities:

- `USAGE` on database, schema, warehouse, compute pools, and integrations.
- `SELECT` on source/target data allowed for STTM work.
- `USAGE`/read access to the workbench semantic registry.
- `EXECUTE`/`USAGE` on the required procedures and Cortex Agents.
- service role grants for the service endpoints.
- `CALLER MODIFY` on metadata tables written through restricted caller-rights
  code paths, especially `TBL_DERIVED_SOURCES`.

### Compute pools

Create or approve two compute pools:

- webapp pool: runs frontend, nginx, STTM backend, and CoCo container;
- automap pool: runs the dedicated Auto-map worker service.

Start with existing pool sizes if the client already has one. If catalog and
agent endpoints still show 14-15 second startup on warmed requests, increase the
webapp pool first; if Auto-map batches are slow after first-token time is fixed,
increase the Auto-map pool or agent-side model/tool performance.

### Image repository

Create a Snowpark Container Services image repository in the workbench schema.
The deploy script pushes versioned images there.

### External access integration

The webapp and worker must reach Snowflake OAuth/token/Cortex endpoints. The
existing external access integration is sufficient if it already allows the
account Snowflake host and OAuth token host. If the account region/host changes,
update the network rule.

### OAuth security integration

Create a custom OAuth security integration for the app.

Required behavior:

- Authorization Code flow.
- Confidential client with client id/secret.
- Redirect URL must include the SPCS ingress callback:
  `https://<webapp-ingress-host>/api/v1/auth/callback`
- Keep the local callback only for local dev if the client allows it:
  `http://localhost:3000/api/v1/auth/callback`
- Scope should include the user role used by the workbench, for example
  `session:role:FOCUS_ADMIN`, or the client-approved equivalent.

Important: if Snowflake gives a new endpoint host, the redirect URL must be
registered again on the OAuth integration. If the service name/account endpoint
stays the same, it does not need to change on every redeploy.

### Secrets

Create password-type secrets in the workbench schema:

1. OAuth client credential secret
   - username = OAuth client id
   - password = OAuth client secret
2. Session key secret
   - username = `AUTH_SESSION_SECRET`
   - password = `AUTH_SESSION_ENCRYPTION_KEY`

The service spec maps these into environment variables. Do not paste client id,
client secret, session secret, or encryption key into rendered YAML artifacts.

## 3. Workbench database/schema objects

Run the schema/object bootstrap used by the repo before service deployment. The
core registry tables are:

- `SEM_TABLE_VIEWS`
- `SEM_COLUMN_VIEWS`
- `TBL_SEMANTIC_MODELS`
- `TBL_SEMANTIC_BUNDLES`
- `TBL_SEMANTIC_OVERRIDES`

Other required metadata tables include:

- `TBL_DERIVED_SOURCES`
- `TBL_WORKBENCH_OAUTH_SESSIONS`
- `TBL_WORKBENCH_CONVERSATION_TURNS`
- `TBL_WORKBENCH_FEEDBACK`
- `TBL_WORKBENCH_RECOMMENDATIONS`
- `TBL_WORKBENCH_RELATIONSHIP_FACTS`
- `TBL_WORKBENCH_RAG_DOCUMENTS`
- Auto-map job/result tables created by the current DDL/bootstrap scripts.

Core procedures include:

- semantic read/compose/publish procedures;
- `SP_GET_TABLE_RELATIONSHIPS`;
- derived-source save/read procedures;
- source mapping and transformation helper procedures;
- DBT/test-case helper procedures if the summary workflow is enabled.

Core agents include:

- `AGT_STTM_BUILDER`
- `AGT_SOURCE_MAPPING`
- `AGT_TRANSFORMATION_RULE`
- `AGT_DBT_CONVERSION`
- `AGT_DBT_TEST_GENERATION`

`AGT_WORKBENCH_CONVERSATION` may remain temporarily for rollback, but the web
assistant should not use it for normal answers.

## 4. Configure the client env file

Start from:

`infra/snowflake/env/client.env.example`

Key settings:

```text
AUTH_MODE=custom_oauth
SPCS_EXECUTE_AS_CALLER_ENABLED=true
SPCS_ENABLE_CUSTOM_CREDENTIALS=true

SNOWFLAKE_STTM_BUILDER_AGENT=<DB>.<SCHEMA>.AGT_STTM_BUILDER
SNOWFLAKE_SOURCE_MAPPING_AGENT=<DB>.<SCHEMA>.AGT_SOURCE_MAPPING
SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT=

WEBAPP_SERVICE_NAME=<client_webapp_service>
AUTO_MAPPING_SERVICE_NAME=<client_automap_service>
AUTO_MAPPING_SERVICE_INSTANCES=2

SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT=<DB>.<SCHEMA>.<oauth_secret>
SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT=<DB>.<SCHEMA>.<session_secret>
SNOWFLAKE_OAUTH_REDIRECT_URI=https://<webapp-ingress-host>/api/v1/auth/callback
```

Leave `SNOWFLAKE_ACCOUNT` and `SNOWFLAKE_HOST` platform-managed inside SPCS
unless the env file explicitly needs them for local tooling. The service should
use Snowflake-provided runtime host/account values for connector traffic.

## 5. Deploy

From the repo root on the client AVD:

```powershell
.\scripts\deploy_spcs_client_snow.ps1 -EnvFile .\infra\snowflake\env\client.env -ImageTag <tag>
```

For Linux/macOS shells:

```bash
./scripts/deploy_spcs_client_snow.sh infra/snowflake/env/client.env <tag>
```

After the first deploy, get the endpoint:

```sql
SHOW ENDPOINTS IN SERVICE <DB>.<SCHEMA>.<WEBAPP_SERVICE_NAME>;
```

If the endpoint host differs from the OAuth redirect URL, ask IT/admin to add
the new callback URL to the OAuth security integration, then redeploy or restart
the service.

## 6. Post-deploy smoke tests

Run these in order:

1. `SYSTEM$GET_SERVICE_STATUS` for the webapp and Auto-map services.
2. Open the webapp endpoint and complete OAuth login.
3. `/api/v1/auth/session` returns envelope `1.0` and the signed-in user/role.
4. Source-selection page loads databases/schemas/tables with cache hits after
   warm-up.
5. Select two sources and one target; semantic context badge becomes ready.
6. Ask normal assistant: `hello` and `what can you do?`
7. Ask derived-source generation with the selected sources.
8. Go to mapping page and run Auto-map; both worker instances should process
   batches and UI rows should update as results arrive.
9. Check a mapped row and ask why confidence is low; the assistant should see
   checked row context and Auto-map reasoning.
10. Validate SQL; Run Preview remains available even if Analyst validation
    cannot repair a query.
11. Open CoCo as admin and send a read-only message; permission prompts should
    appear for mutating actions.

## 7. Expected troubleshooting signals

- `SEMANTIC_BUNDLE_NOT_READY`: selection changed but bundle resolve did not
  complete. Rebuild context; do not let chat generate semantic assets.
- Cortex Agent `399504` missing skill: deployed agent spec references a
  Snowflake skill not present in client. Current `AGT_STTM_BUILDER` spec avoids
  external skill references.
- OAuth `invalid_client` in SPCS: check `enableCustomCredentials`, OAuth secret
  mapping, Basic-only token exchange, and redirect URL.
- Derived-source save `CALLER MODIFY`: grant `CALLER MODIFY` on
  `TBL_DERIVED_SOURCES` to the procedure owner role / required runtime role.
- CoCo websocket connects but session fails: use `/api/v1/coco/diagnostics`,
  then inspect the `coco-agent` container logs. Do not disable permission checks
  to make it work.

## 8. What IT/admin should not grant

- Do not grant the app direct write access to semantic registry tables for
  normal application traffic.
- Do not expose OAuth secrets in env files or rendered YAML.
- Do not grant production DDL/mutation privileges to CoCo without explicit
  client-approved allowlists and permission cards.
- Do not make `AGT_SEMANTIC_MODEL_V2` run inside chat, Auto-map, or validation
  request paths.
