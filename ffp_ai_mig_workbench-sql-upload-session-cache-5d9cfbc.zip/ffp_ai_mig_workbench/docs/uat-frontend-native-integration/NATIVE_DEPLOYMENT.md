# V11 client test package

This cumulative delta is supplied at the user's request for client-side completion of acceptance. It is not a fully live-accepted release. Apply to the existing full application checkout, preserving client.env and .env.local. It includes prior V6–V10 application corrections plus native investigation, deployment definitions and tests. The user confirmed client baseline 49c6a576 corresponds to V5.1; that remote commit was not fetched independently. Local delta baseline is recorded in MANIFEST.json. Do not apply blindly over divergent client changes: compare the manifest and review conflicts first. No code was pushed to UAT by this work.

## What changed

Native Cortex orchestration chooses exact evidence reads, scoped Search, precedent retrieval, optional prepared Analyst, validation and checkpoint submission. It uses dedicated pinned agents and caller-rights procedures; existing shared source/transformation agents are untouched. Exact evidence stays archived, active candidate dependencies persist, hidden CTE parent columns stay nonselectable, and current business guidance is mandatory. Direct proposals retain alternatives/confidence; uncertain outcomes require review. Complex selected bindings start an independent specialist with frozen source/Value identities. Existing definitions and run-start revisions remain protected until explicit acceptance.

Independent checkpoints let the parent recover valid results after worker delivery failures. Parent SQL recovery no longer blocks ready HTTP responses. Runtime failures report a stage instead of pretending the source evidence is absent. Strict final-answer and tool-scope validation remains enabled.

## AVD deployment sequence

1. Extract these relative paths over the reviewed full checkout. Do not delete client env files, install the Mac temporary environment, upload this ZIP into Git, or copy any local DEV pins/account settings. Install the application's Python dependencies using its normal build process. Snowpark minimum is now 1.40 and SQLGlot remains 30.x.
2. Render the account-specific resources from the applied checkout. The following PowerShell command only renders files; replace every bracketed value with the existing approved client setting:

```powershell
python scripts/render_automap_native.py --metadata "<DATABASE>.<METADATA_SCHEMA>" --warehouse "<AUTOMAP_WAREHOUSE>" --role "<CALLER_ROLE>" --stage "<DATABASE>.<SCHEMA>.<EXISTING_INTERNAL_STAGE>" --account-namespace "<ORGANIZATION>.<ACCOUNT_NAME>" --pool-capacity 8 --output "artifacts/automap-native-v11"
```

Use the canonical organization/account name, not the locator. Keep this output directory between renders: its manifest retains the pool epoch. Rendered runtime ZIP/import paths are content addressed. The renderer reads no env files and does not connect, deploy or enable features.

3. Review `install.sql`, `configuration.json`, `agent-source.json`, `agent-rule.json`, `upload.txt`, and `runtime-manifest.json`. Upload the generated runtime ZIP to its exact staged hash path before installing the procedures. Follow the account's existing stage upload workflow; verify the local SHA256 printed by the renderer, and disable overwrite. `install.sql` is FIRST INSTALL ONLY: it creates new versioned tables, row policies, Search service, nine procedures, two dedicated agents and grants. It does not use OR REPLACE. Do not run a global metadata bootstrap merely to install this feature.
4. If these exact native objects already exist, stop and compare their definitions. Do not rerun CREATE/INSERT, reset slot inventories/epochs, or overwrite agents while calls are active. Quarantined or held calls require existing same-caller reconciliation; never free them based on elapsed time. Upgrade only the reviewed native procedures/agents through the existing release process after active work is drained, preserving all state tables and content-addressed imports. Existing shared agents are outside this change.
5. Verify the installed definitions and named-argument protocol on the AVD using the application's Python environment and an existing Snowflake connection:

```powershell
python scripts/verify_automap_native_install.py --connection "<EXISTING_CONNECTION>" --metadata "<DATABASE>.<METADATA_SCHEMA>" --rendered "artifacts/automap-native-v11"
```

This checks definitions and tools; it does not enable the feature or prove live mapping accuracy. Pin the VERIFIED GET hashes from this command, not hashes copied from DEV.

6. Configure both webapp and worker through the existing deployment configuration. Transfer native permit/archive FQNs, canonical account namespace, epoch and capacity from the reviewed generated configuration. Set the verified source/rule spec hashes. Enable `AUTOMAP_FAST_PATH_V1=true`, explicit `AUTOMAP_FAST_PROJECT_IDS=501`, `AUTOMAP_NATIVE_TOOLS_V1=true`, `AUTOMAP_NATIVE_PROJECT_IDS=501`, and a release-specific `AUTOMAP_FAST_CANARY_REVISION`. Initial native batch count is 4; pool capacity 8 permits concurrent roots and specialists. Retain the existing authenticated worker URL and caller session configuration. Input character and UTF-8 byte caps are independently configured up to 180000; output remains 120000. Flagged configuration failures are explicit; no fallback into the old investigation loop.
7. Render/review both service specs using the existing scripts, then deploy through the client's normal pipeline. Do not change shared agents. Run the acceptance matrix in TEST_RESULTS.md, compare actual mappings, transformations, existing rows, scope, coverage and latency. Enable other projects only after their evaluation.

## Required live tests still outstanding

The direct country technical positive control passed in DEV. Search, Analyst, transformation specialist, uploaded CTE and full proxy/UI end-to-end acceptance were not completed. The latest mandatory guidance and historical-coverage correction were offline-tested after the positive control and must be included in the client render/install and replay. Existing client-auth profile checks require the client's authoritative env. Preserve unsupported targets as explicit unresolved/review items; never relax evidence or compilation gates just to produce a count.

## Rollback and retention

Disable `AUTOMAP_NATIVE_TOOLS_V1` on both services and deploy the previous application release if needed. Keep native job/archive tables, admission inventories and agent definitions available until all in-flight/uncertain work is reconciled. Do not reset epochs or delete active snapshots. Do not point the old pipeline at native permit tables. Retain staging ZIPs referenced by installed procedures.

Source Search documents and native snapshots contain project evidence; apply the client's approved retention/access controls. Analyst can create caller-owned content-addressed `AUTOMAP_POP_*` metadata views; these do not change source/target rows. Successful observations return the view name and snapshot hash. Before cleanup, inspect completed/expired job state including RPC results and ensure no active/uncertain operation references a view. Failed Analyst attempts can leave an unreferenced view; identify those through the caller's query history and reviewed native object inventory. Cleanup is an operator action; never automatically drop views while a job may still use them.
