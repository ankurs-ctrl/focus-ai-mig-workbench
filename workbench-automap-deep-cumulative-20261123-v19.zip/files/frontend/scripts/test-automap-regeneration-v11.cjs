const assert=require('node:assert/strict'),test=require('node:test'),path=require('node:path');
const h=require('./test-automap-preservation.cjs');
const recovery=h.loadPure(path.resolve(__dirname,'../src/features/sttm/shared/mapping-row-recovery.ts'));
const option=id=>({candidate_id:id,source_attributes:['src.NewName'],source_dependencies:['src.NewName'],confidence_score:.72,original_confidence_score:.72,confidence_reason:'Current target meaning and binding',preprocessing_rule_type:'Direct',mapping_mode:'source',transformation_classification:'direct',scoring_policy_version:'draft-caps-v1',validation_status:'valid',validation_errors:[],warnings:[],value_binding_ids:[]});
function start(rows,checked=[]) {const state={...h.stateFor(...rows),sources:[],derivedSources:[],selectedMappingIds:checked};h.reducer(h.pendingReducer)(state,{meta:{requestId:'generation-11'}});return state;}
function deliver(state,mappings) {h.helpers.applyAutoMapResponseToState(state,{operation:'sttm.auto_map',request_id:'generation-11',result:{mappings},meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'}});}
const receipt=option=>({...option,candidates:[option],draft_candidate_id:option.candidate_id});
const counts=state=>h.helpers.autoMapCompletionCounts(state,state.autoMapRun.targetNames,'generation-11',0);
test('37 saved rows regenerate, duplicate checkpoints count once, pre-run Undo survives',()=>{
 const original=Array.from({length:37},(_,i)=>({...h.imported(),id:'FIELD'+i,targetColumn:'FIELD'+i,manuallySaved:true,aiReviewStatus:'confirmed'}));
 const state=start(structuredClone(original)),mappings=Object.fromEntries(original.map(row=>[row.targetColumn,receipt(option(row.id))]));
 deliver(state,mappings);deliver(state,mappings);const c=counts(state);
 assert.equal(c.requested,37);assert.equal(c.processed,37);assert.equal(c.supportedProposals,37);assert.equal(c.replaced,37);assert.equal(c.newMappings,0);assert.equal(c.unresolved,0);
 for(let i=0;i<37;i++){assert.equal(state.mappings[i].sourceColumn,'src.NewName');assert.equal(state.mappings[i].aiReviewStatus,'unreviewed');assert.equal(state.mappings[i].aiUndoSnapshot.expression,original[i].expression);assert.equal(state.mappings[i].aiUndoSnapshot.manuallySaved,true);}
 assert.match(h.helpers.autoMapCompletionMessage(37,c),/37 definitions replaced/);
});
test('blank uploaded-query rows receive drafts without changing population',()=>{
 const state=start(Array.from({length:37},(_,i)=>h.blank('FIELD'+i)));
 state.rawMappingSql=state.mappingSql='WITH src AS (SELECT Name FROM D.S.T WHERE active = 1) SELECT Name FROM src';state.autoMapRun.sharedInputs=h.helpers.autoMapSharedInputs(state);
 deliver(state,Object.fromEntries(state.mappings.map(row=>[row.targetColumn,receipt(option(row.id))])));
 assert.equal(counts(state).newMappings,37);assert.equal(counts(state).replaced,0);assert.match(state.rawMappingSql,/WHERE active = 1/);
});
test('checked regeneration holds only in-flight edited rows and retains their proposals',()=>{
 const original=[{...h.imported(),manuallySaved:true},h.blank('OTHER'),h.blank('UNCHECKED')],state=start(structuredClone(original),['NAME','OTHER']);
 state.mappings[0].expression="'MY NEW EDIT'";state.autoMapRun.manualEditsDuringRun=['NAME'];
 deliver(state,{NAME:receipt(option('name')),OTHER:receipt(option('other')),UNCHECKED:receipt(option('ignored'))});
 assert.equal(state.mappings[0].expression,"'MY NEW EDIT'");assert.equal(state.mappings[0].aiCandidates.length,1);assert.equal(state.mappings[1].sourceColumn,'src.NewName');assert.deepEqual(state.mappings[2],original[2]);assert.equal(counts(state).heldForEdits,1);assert.equal(counts(state).newMappings,1);
});
test('identical definitions count unchanged; unsupported targets retain inputs; provenance reopens',()=>{
 const state=start([{...h.blank(),sourceColumn:'src.NewName',sourceColumns:['src.NewName'],rule:'Direct',manuallySaved:true,status:'MAPPED'},h.blank('OTHER')]);
 deliver(state,{NAME:receipt(option('same')),OTHER:{candidates:[],source_attributes:[],transformation_classification:'unresolved'}});
 assert.equal(counts(state).unchanged,1);assert.equal(counts(state).withoutSupportedProposal,1);assert.equal(counts(state).processed,2);
 const row=state.mappings[0],saved=recovery.savedMappingEvidence({ai_generation:row.aiGeneration,ai_candidates:row.aiCandidates,ai_undo_snapshot:row.aiUndoSnapshot});
 assert.deepEqual(saved.aiGeneration,row.aiGeneration);assert.deepEqual(saved.aiUndoSnapshot,row.aiUndoSnapshot);
});
test('a late empty checkpoint retains supported current-generation candidates and counts',()=>{
 const state=start([h.blank()]);deliver(state,{NAME:receipt(option('supported'))});
 deliver(state,{NAME:{candidates:[],source_attributes:[],transformation_classification:'unresolved'}});
 assert.equal(state.mappings[0].sourceColumn,'src.NewName');assert.equal(state.mappings[0].aiCandidates[0].candidate_id,'supported');
 assert.equal(counts(state).supportedProposals,1);assert.equal(counts(state).newMappings,1);assert.equal(counts(state).withoutSupportedProposal,0);
});
test('failed target outcomes count as processed without erasing a successful sibling',()=>{
 const state=start([h.blank(),h.blank('OTHER')]);deliver(state,{NAME:receipt(option('supported'))});
 h.helpers.applyAutoMapResponseToState(state,{operation:'sttm.auto_map',request_id:'generation-11',result:{mappings:{}},warnings:[{code:'AUTO_MAPPING_BATCH_FAILED',field:'OTHER',message:'Provider unavailable'}],meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'}});
 assert.equal(state.mappings[0].sourceColumn,'src.NewName');assert.equal(counts(state).processed,2);
 assert.equal(counts(state).supportedProposals,1);assert.equal(counts(state).withoutSupportedProposal,1);
});
