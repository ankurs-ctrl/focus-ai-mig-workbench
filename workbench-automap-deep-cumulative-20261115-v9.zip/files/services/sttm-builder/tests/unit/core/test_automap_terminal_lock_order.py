from contextlib import contextmanager
from types import SimpleNamespace

import pytest

from app.core.automap_admission import ScanCallLifecycle,Completion
from app.core.automap_durable_admission import DurableRunAdmission


def test_terminal_row_locks_precede_archive_and_ack_only_after_commit():
    calls=[]
    state=SimpleNamespace(active=True,invoked=True,completion=None,reference=object(),
        request=SimpleNamespace(scope='scope'),permit=SimpleNamespace(identity=SimpleNamespace(caller_id='user')),
        terminal_commit_acknowledged=False)
    def release(session,permit,completion):
        assert completion is Completion.SUCCEEDED
        calls.append('operation_row')
    gate=SimpleNamespace(_current=SimpleNamespace(get=lambda:state),store=SimpleNamespace(complete_on_session=release))
    @contextmanager
    def checkpoint():
        calls.append('begin')
        yield SimpleNamespace(session=object(),put=lambda *a:calls.append('archive'),get=lambda *a:'body')
        assert state.terminal_commit_acknowledged is False
        calls.append('commit')
    archive=SimpleNamespace(_scope='scope',_caller=SimpleNamespace(native_user='user'),checkpoint=checkpoint)
    ScanCallLifecycle(gate,state).commit_terminal_result(archive,'ref','body')
    assert calls==['begin','operation_row','archive','commit']
    assert state.terminal_commit_acknowledged


def test_failed_archive_does_not_acknowledge_terminal_commit():
    state=SimpleNamespace(active=True,invoked=True,completion=None,reference=object(),
        request=SimpleNamespace(scope='scope'),permit=SimpleNamespace(identity=SimpleNamespace(caller_id='user')),
        terminal_commit_acknowledged=False)
    effects=[]
    @contextmanager
    def checkpoint():
        try:
            yield SimpleNamespace(session=None,put=lambda *a:(_ for _ in ()).throw(TimeoutError()),get=lambda *a:None)
        except Exception:
            effects.clear()  # Transaction rollback restores the provisional row.
            raise
    gate=SimpleNamespace(_current=SimpleNamespace(get=lambda:state),store=SimpleNamespace(complete_on_session=lambda *a:effects.append('provisional')))
    archive=SimpleNamespace(_scope='scope',_caller=SimpleNamespace(native_user='user'),checkpoint=checkpoint)
    with pytest.raises(TimeoutError):ScanCallLifecycle(gate,state).commit_terminal_result(archive,'ref','body')
    assert not effects and state.terminal_commit_acknowledged is False


def test_fenced_release_updates_row_before_standard_audit():
    calls=[]
    store=SimpleNamespace(_table='DB.META.OPERATIONS',_permit_params=lambda permit:[],
        _sql=lambda session,query,params:calls.append('row') or [{'number of rows updated':1}],
        _event=lambda *args:calls.append('audit'))
    DurableRunAdmission.complete_on_session(store,None,object(),Completion.SUCCEEDED)
    assert calls==['row','audit']
