const fs=require('fs'),path=require('path'),ts=require('typescript'),Module=require('module'),assert=require('node:assert/strict');
const file=path.resolve(__dirname,'../src/features/dashboard/NewMappingDialog.tsx'),ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true);
let source;function scan(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='recoverSqlUpload')source=n.initializer.getText(ast);ts.forEachChild(n,scan);}scan(ast);assert.ok(source);
const moduleFile=path.resolve(__dirname,'../src/features/sttm/mapping/sql-upload-recovery.ts');const helpers=new Module(moduleFile,module);helpers._compile(ts.transpileModule(fs.readFileSync(moduleFile,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,moduleFile);
const {uploadRecoveryKey,readSqlUploadHandle}=helpers.exports;
async function probe(status,result,identity){const values=new Map(),project='501',key=uploadRecoveryKey(project,'',identity);values.set(key,JSON.stringify({requestId:'saved',fingerprint:'hash'}));let recovered=null;
const context={activeSqlRequest:{current:null},observeSqlUpload:async()=>({request_id:'saved',status,result}),resolveApiBaseUrl:()=>'',uploadRecoveryKey,readSqlUploadHandle,recoveryIdentity:identity,existingSttmId:null,
localStorage:{getItem:k=>values.get(k)??null,removeItem:k=>values.delete(k)},setUploadRecoveryPending:()=>{},setUploadRetryAllowed:()=>{},setUploadingOperation:()=>{},setUploadResult:value=>recovered=typeof value==='function'?value(recovered):value,selectUploadValues:()=>{},setUploadRecoveryNotice:()=>{}};
const compiled=new Module(file,module);compiled._compile(ts.transpileModule(`module.exports = c => {const {${Object.keys(context).join(',')}}=c;return (${source});};`,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);
await compiled.exports(context)('saved',project,identity,new AbortController().signal);
assert.ok(values.has(key),'A saved preview or unauthorized lookup must retain the original recovery handle');if(result)assert.equal(recovered,result);return values;}
(async()=>{await probe('completed',{asset_id:'saved'},'alice-role1');await probe('failed',{asset_id:'saved'},'alice-role1');await probe('not_visible',null,'bob-role1');const original=await probe('completed',{asset_id:'saved'},'alice-role1');assert.ok(original.has(uploadRecoveryKey('501','','alice-role1')));assert.ok(!original.has(uploadRecoveryKey('501','','bob-role1')));console.log('Completed/failed previews survive reload; caller-specific recovery handles are retained.');})().catch(e=>{console.error(e);process.exitCode=1});

const test = require('node:test');
test('a changed file can replace the recovered preview while caller identity is loading', async () => {
  let source;
  function findHandler(node) {
    if (ts.isVariableDeclaration(node) && node.name.getText(ast) === 'handleFileUpload') {
      source = node.initializer.getText(ast);
    }
    ts.forEachChild(node, findHandler);
  }
  findHandler(ast);
  assert.ok(source);
  const { File } = require('node:buffer');
  global.crypto ||= require('node:crypto').webcrypto;
  const fingerprint = helpers.exports.sqlUploadFingerprint;
  const scope = 'alice-role1';
  const key = uploadRecoveryKey('501', '', scope);
  const options = [['project_id','501'], ['mode','auto_populate'], ['source_table_hints',''],
    ['target_table_hint',''], ['filename','mapping.sql']];
  const savedHash = await fingerprint(new Blob(['SELECT 1']), options);
  const values = new Map([[key, JSON.stringify({requestId:'old-upload', fingerprint:savedHash})]]);
  const prior = new AbortController();
  const posted = [], recovered = [], previewActions = [];
  let resolveIdentity;
  let previewReady = true;
  const context = {
    abortControllerRef: {current: prior},
    activeSqlRequest: {current: null}, setFilePickerOpen() {},
    recoveryIdentity: null,
    recoveryIdentityRequest: {current: new Promise(resolve => { resolveIdentity = resolve; })},
    selectedProjectId: '501', projectId: '501', existingSttmId: null, fixedTargetTable: null,
    sourceTableHints: '', targetTableHint: '', logicalTargetKey: null, sourceSystemKey: null,
    store: {getState: () => ({sttmBuilder:{}})},
    uploadRetryAllowed: false,
    localStorage: {getItem: k => values.get(k) ?? null, setItem: (k, value) => values.set(k, value)},
    uploadRecoveryKey, readSqlUploadHandle, sqlUploadFingerprint: fingerprint,
    loadRecoveryIdentity: () => { throw new Error('An existing request should be reused'); },
    resolveApiBaseUrl: () => '', API_ROUTES: {upload: {sql:'/upload/sql'}},
    fetch: async (_url, request) => { posted.push(request); return {ok:true}; },
    recoverSqlUpload: async requestId => { recovered.push(requestId); return previewReady; },
    setSqlEditText: text => previewActions.push(["editor", text]),
    setUploadResult: result => previewActions.push(["preview", result]), setUploadRecoveryPending() {}, setUploadRecoveryNotice() {},
    setSelectedProjectValueNames() {}, setValueConflicts() {}, setUploadingOperation() {},
    setUploading() {}, setUploadRetryAllowed() {},
  };
  const transport = new Module(file,module);
  transport._compile(ts.transpileModule(
    `module.exports = c => { const {${Object.keys(context).join(',')}}=c; return (${source}); };`,
    {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}},
  ).outputText,file);
  const handler = transport.exports(context);
  const upload = handler({target: {value:'mapping.sql', files:[new File(['SELECT 2'], 'mapping.sql')]}}, 'sql');
  assert.equal(prior.signal.aborted, true);
  assert.equal(posted.length, 0);
  resolveIdentity(scope);
  await upload;
  assert.equal(posted.length, 1);
  assert.equal(await posted[0].body.get('file').text(), 'SELECT 2');
  const saved = readSqlUploadHandle(values.get(key));
  assert.notEqual(saved.requestId, 'old-upload');
  assert.deepEqual(recovered, [saved.requestId]);

  await handler({target: {files:[new File(['SELECT 2'], 'mapping.sql')]}}, 'sql');
  assert.equal(posted.length, 2);
  const repeat = readSqlUploadHandle(values.get(key));
  assert.notEqual(repeat.requestId, saved.requestId);
  assert.deepEqual(recovered, [saved.requestId, repeat.requestId]);

  const previousActions = previewActions.length;
  const editedSql = "SELECT 'edited' AS OUTPUT_COLUMN";
  await handler(null, 'sql', new File([editedSql], 'mapping.sql'), true);
  assert.equal(posted.length, 3);
  assert.equal(await posted[2].body.get('file').text(), editedSql);
  assert.deepEqual(previewActions.slice(previousActions), [["editor", null]],
    'The edited text uses the same parser and leaves the preview intact until a new result is returned.');
  previewReady = false;
  const afterSuccessfulParse = previewActions.length;
  await handler(null, 'sql', new File(['incomplete SQL'], 'mapping.sql'), true);
  assert.equal(previewActions.length, afterSuccessfulParse,
    'Without a new preview, the editor and its text remain available.');
});
