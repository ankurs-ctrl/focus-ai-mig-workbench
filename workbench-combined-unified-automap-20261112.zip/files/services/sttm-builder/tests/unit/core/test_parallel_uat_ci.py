"""Offline UAT workflow contracts; never invoke Snow CLI or a real deployment."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from uuid import UUID

import pytest
import yaml
from dotenv import dotenv_values

from scripts import prepare_parallel_automap_infra as infra
from scripts.render_spcs_spec import PARALLEL_FIELDS, load_parallel_profile, render_template

ROOT = Path(__file__).resolve().parents[5]
WORKFLOW = ROOT / '.github/workflows/pipeline-ai-migration-uat.yml'
PROFILE = ROOT / 'infra/snowflake/env/parallel.uat.json'
VALIDATE = 'Validate parallel UAT profile and render before provisioning'
GENERATE = 'Prepare parallel UAT infrastructure SQL offline'
PROVISION = 'Provision and validate parallel UAT infrastructure in order'
BOOTSTRAP = 'Bootstrap Metadata Infrastructure'
DEPLOY = 'Deploy Single-Service SPCS Webapp'
WORKFLOW_STAGES = {
    'true': ('create', 'validate-agent', 'initialize-pool', 'validate-pool'),
    'false': ('validate-agent', 'validate-pool'),
}


def workflow():
    return yaml.load(WORKFLOW.read_text(encoding='utf-8'), Loader=yaml.BaseLoader)


def step(name):
    return next(item for item in workflow()['jobs']['deploy-workbench']['steps'] if item['name'] == name)


def context(host_style='hyphen'):
    scope = json.loads(PROFILE.read_text())['scope']
    host = scope['account_namespace'].lower().replace('.', '-')
    if host_style == 'hyphen':
        host = host.replace('_', '-')
    host += '.snowflakecomputing.com'
    return {
        **{'SNOWFLAKE_' + key.upper(): scope[key] for key in ('database', 'schema', 'role', 'connection')},
        'SNOWFLAKE_ACCOUNT': scope['account_namespace'].replace('.', '-'),
        'SNOWFLAKE_REST_HOST': host,
        'SNOWFLAKE_REGISTRY_HOST': host.replace('.snowflakecomputing.com', '.registry.snowflakecomputing.com'),
        'AUTH_MODE': 'custom_oauth',
        'SNOWFLAKE_OAUTH_AUTHORIZE_URL': f'https://{host}/oauth/authorize',
        'SNOWFLAKE_OAUTH_TOKEN_URL': f'https://{host}/oauth/token-request',
    }


def test_one_time_provisioning_opt_in_is_event_scoped_and_defaults_off():
    document = workflow()
    assert document['on']['push']['branches'] == ['UAT']
    assert document['on']['workflow_dispatch']['inputs']['parallel_rollout'] == {
        'description': 'One-time additive parallel infrastructure creation and empty-pool initialization (exclusive approval required)',
        'type': 'boolean', 'required': 'false', 'default': 'false',
    }
    job = document['jobs']['deploy-workbench']
    assert job['if'] == "github.ref == 'refs/heads/UAT'"
    assert job['environment'] == 'prod-snowflake-workbench'
    assert job['env']['AUTOMAP_PARALLEL_ROLLOUT'] == (
        "${{ (github.event_name == 'workflow_dispatch' && inputs.parallel_rollout == true || "
        "github.event_name == 'push' && contains(github.event.head_commit.message, '[parallel-automap]')) "
        "&& 'true' || 'false' }}"
    )
    assert document['concurrency'] == {'group': 'uat-parallel-automap-provision', 'cancel-in-progress': 'false'}
    assert 'concurrency' not in job  # one gate for normal and parallel runs, no branch/run-id split


def test_validation_always_precedes_bootstrap_and_deploy():
    steps = workflow()['jobs']['deploy-workbench']['steps']
    names = [item['name'] for item in steps]
    order = ['Guardrail: Require UAT deployment destinations', 'Configure Snow CLI Connection',
             'Install reviewed recovery runtime', VALIDATE, GENERATE, PROVISION, BOOTSTRAP, DEPLOY]
    assert [names.index(name) for name in order] == sorted(names.index(name) for name in order)
    for name in (VALIDATE, GENERATE, PROVISION, BOOTSTRAP):
        assert 'if' not in step(name)
        assert step(name)['shell'] == 'pwsh'
        assert 'continue-on-error' not in step(name)
    assert names.count(BOOTSTRAP) == 1
    assert 'if' not in step(DEPLOY)
    provisioning = step(PROVISION)['run']
    assert 'Initial pool provisioning ONLY' in provisioning
    assert 'stopped dispatchers' in provisioning
    assert 'for security DDL' in provisioning
    assert 'First release push needs [parallel-automap]' in provisioning


def test_bootstrap_step_updates_repo_agents_with_jwt_secrets_only():
    bootstrap = step(BOOTSTRAP)
    assert bootstrap['run'] == './scripts/bootstrap_sttm_metadata_infra.ps1'
    assert bootstrap['env'] == {
        'PKCS8_KEY_CONTENT': '${{ secrets.FFP_HDP_AI_ML_PROD_01_PKCS8 }}',
        'KEY_PASSPHRASE': '${{ secrets.FFP_HDP_AI_ML_PROD_01_PP }}',
        'PRIVATE_KEY_PASSPHRASE': '${{ secrets.FFP_HDP_AI_ML_PROD_01_PP }}',
    }
    assert 'FIR_RECOVER_REVIEWED_UAT' not in WORKFLOW.read_text()
    env_file = ROOT / 'infra/snowflake/env/client.env'
    if not env_file.is_file():
        return  # Environment files are branch-specific; develop has none.
    values = dotenv_values(env_file, interpolate=False)
    # Bootstrap must preserve the external semantic registry and keep every FIR task running.
    assert values['PRESERVE_SEMANTIC_REGISTRY'] == 'true'
    assert values['FIR_TASK_POLICY'] == 'enable-all'


def test_keep_private_env_and_jwt_path_and_publication_recovery():
    document = workflow()
    assert document['env']['ENV_FILE'] == 'infra/snowflake/env/client.env'
    assert document['env']['PUBLICATION_RECOVERY_ENABLED'] == 'true'
    assert 'AUTOMAP_DEPLOY_PROFILE_FILE' not in document['env']
    assert 'AUTOMAP_DEPLOY_PROFILE_FILE' not in document['jobs']['deploy-workbench']['env']
    deploy = step(DEPLOY)['run']
    assert 'AUTOMAP_PARALLEL_ROLLOUT' not in deploy
    assert "$env:AUTOMAP_DEPLOY_ENVIRONMENT = 'UAT'" in deploy
    assert "$env:AUTOMAP_DEPLOY_PROFILE_FILE = (Resolve-Path 'infra/snowflake/env/parallel.uat.json').Path" in deploy
    assert './scripts/deploy_spcs_client_snow_single_service.ps1' in deploy
    assert './scripts/deploy_parallel_automap.ps1' not in deploy
    assert not re.search(r'\$env:PUBLICATION_RECOVERY_\w+\s*=', deploy)
    assert '-ValidateOnly' in step(VALIDATE)['run']
    assert 'PathSeparator' in step(VALIDATE)['run']
    assert 'PathSeparator' in deploy  # step-local PATH does not survive preflight
    assert step('Configure Snow CLI Connection')['run'] == './scripts/configure_client_snow_connection.ps1'
    assert step(PROVISION)['env']['PRIVATE_KEY_PASSPHRASE'] == '${{ secrets.FFP_HDP_AI_ML_PROD_01_PP }}'
    assert 'snow sql -c client-spcs' in step(PROVISION)['run']
    assert '--database FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT --schema SCH_STTM_METADATA' in step(PROVISION)['run']
    assert '--role FFP_HDP_DLAB_MIG_WORKBENCH_DB_DEPLOY_ROLE_UAT -f $sqlFile' in step(PROVISION)['run']
    assert 'Copy-Item' not in WORKFLOW.read_text()
    assert 'FFP_HDP_DLAB_DB_DEV' not in WORKFLOW.read_text()
    assert 'MHSUEJT.GD01711' not in WORKFLOW.read_text()


@pytest.mark.parametrize('host_style', ['hyphen', 'underscore'])
def test_checked_in_profile_matches_real_validator_and_four_slot_contract(host_style):
    document = json.loads(PROFILE.read_text())
    scope, values = infra.load_profile(PROFILE, 'UAT')
    validated = load_parallel_profile(PROFILE, 'UAT', context(host_style))
    assert scope['connection'] == 'client-spcs'
    assert scope['account_namespace'] == 'MHSUEJT.FFP_HDP_SNOW_ACCOUNT_PROD'
    assert values['AUTOMAP_PARALLEL_POOL_CAPACITY'] == values['AUTOMAP_PARALLEL_MAX_WORKERS'] == '4'
    assert values['AUTOMAP_CONTEXT_BATCH_COUNT'] == '4'
    assert values['AUTOMAP_FAST_PATH_V1'] == validated['AUTOMAP_FAST_PATH_V1'] == 'true'
    assert values['AUTOMAP_FAST_PROJECT_IDS'] == validated['AUTOMAP_FAST_PROJECT_IDS'] == '*'
    assert values['AUTOMAP_FAST_CANARY_REVISION'] == 'uat-source-mapping-v3'
    assert validated['AUTOMAP_PARALLEL_CONTEXT_V1'] == 'true'
    assert values['AUTO_MAPPING_PROXY_MAX_IN_FLIGHT'] == values['AUTO_MAPPING_WORKER_MAX_CONCURRENCY'] == '12'
    assert values['AUTOMAP_FAST_MAX_IN_FLIGHT'] == '12'  # the fast path ignores the proxy cap
    assert values['AUTOMAP_PARALLEL_MAX_CALLS'] == '32'
    assert values['AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS'] == '16'
    assert validated['SNOWFLAKE_WRITE_LEASE_POOL_V1'] == 'true'
    assert set(document['settings']) <= PARALLEL_FIELDS
    epoch = values['AUTOMAP_PARALLEL_POOL_EPOCH']
    assert epoch == '9078a6fb-0c1e-45b3-9b34-ab0c8a97bf0a'  # stable across reruns
    assert str(UUID(epoch)) == epoch and UUID(epoch).version == 4
    assert epoch != 'b84e9707-12a3-4aa6-b841-5a1da77e85c8'
    prefix = 'FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT.SCH_STTM_METADATA.'
    assert values['AUTOMAP_PARALLEL_TEST_AGENT'] == prefix + 'AGT_AUTOMAP_SCAN_DEV_TEST'
    assert values['AUTOMAP_PARALLEL_PERMIT_TABLE_FQN'] == prefix + 'TBL_AUTOMAP_CALL_ADMISSION_UAT'
    assert values['AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN'] == prefix + 'TBL_AUTOMAP_CONTEXT_ARCHIVE_UAT'
    assert not any('INSTANCES' in key or 'NODES' in key for key in document['settings'])


@pytest.mark.parametrize('field', ['SNOWFLAKE_ACCOUNT', 'SNOWFLAKE_CONNECTION', 'SNOWFLAKE_DATABASE',
                                  'SNOWFLAKE_ROLE', 'SNOWFLAKE_SCHEMA', 'SNOWFLAKE_REST_HOST'])
def test_checked_in_profile_rejects_wrong_runtime_scope(field):
    values = context()
    values[field] = 'wrong-scope'
    with pytest.raises(ValueError):
        load_parallel_profile(PROFILE, 'UAT', values)


@pytest.mark.parametrize('name', ['webapp', 'automap-worker'])
def test_checked_in_profile_renders_both_services_without_losing_recovery(name):
    raw = (ROOT / f'infra/snowflake/service-specs/{name}.yaml.tmpl').read_text()
    values = {key: 'synthetic' for key in re.findall(r'\$\{([A-Z][A-Z0-9_]*)\}', raw)}
    values.update(context(), AUTOMAP_DEPLOY_PROFILE_FILE=str(PROFILE), AUTOMAP_DEPLOY_ENVIRONMENT='UAT',
                  COCO_SIDECAR_ENABLED='false', SNOWFLAKE_OAUTH_SECRET_MAPPINGS='',
                  AUTO_MAP_PIPELINE_V2='false', AUTO_MAPPING_PROXY_BATCH_SIZE='6',
                  PUBLICATION_RECOVERY_ENABLED='true', PUBLICATION_RECOVERY_ROLE=context()['SNOWFLAKE_ROLE'])
    rendered = render_template(raw, values)
    containers = yaml.safe_load(rendered)['spec']['containers']
    actual = containers[0]['env']
    assert actual['AUTOMAP_PARALLEL_POOL_CAPACITY'] == actual['AUTOMAP_PARALLEL_MAX_WORKERS'] == '4'
    assert actual['AUTO_MAPPING_PROXY_MAX_IN_FLIGHT'] == actual['AUTOMAP_FAST_MAX_IN_FLIGHT'] == '12'
    assert actual['AUTOMAP_PARALLEL_CONTEXT_V1'] == 'true'
    assert 'SNOWFLAKE_ACCOUNT' not in actual
    assert '${' not in rendered
    if name == 'webapp':
        assert any(container['name'] == 'publication-recovery' for container in containers)


@pytest.mark.parametrize('stage', infra.STAGES)
def test_real_generator_cli_for_uat_is_guarded_additive_and_never_resets(stage):
    arguments = [sys.executable, str(ROOT / 'scripts/prepare_parallel_automap_infra.py'),
                 '--profile', str(PROFILE), '--environment', 'UAT', '--stage', stage]
    if stage in ('create', 'initialize-pool', 'expand-pool'):
        arguments.append('--exclusive-deployment')
    if stage == 'initialize-pool':
        arguments.append('--initialize-empty-pool')
    if stage == 'expand-pool':
        arguments.extend(['--previous-capacity', '2'])
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stderr
    sql = result.stdout
    assert 'CURRENT_ACCOUNT_NAME()' in sql and 'CURRENT_SCHEMA()' in sql
    assert 'FFP_HDP_SNOW_ACCOUNT_PROD' in sql and 'RAISE scope_mismatch;' in sql
    assert 'FFP_HDP_DLAB_DB_DEV' not in sql and 'MHSUEJT.GD01711' not in sql
    assert not re.search(r'\b(?:OR REPLACE|TRUNCATE|DELETE FROM|UPDATE|ALTER AGENT|GRANT)\b', sql)
    if stage == 'initialize-pool':
        assert 'GENERATOR(ROWCOUNT => 4)' in sql
        assert 'IF (row_count = 0) THEN' in sql
        assert 'row_count <> 4 OR distinct_slots <> 4' in sql
        assert 'POOL_EPOCH <>' in sql and '9078a6fb-0c1e-45b3-9b34-ab0c8a97bf0a' in sql
        assert 'ROLLBACK;' in sql and 'RAISE inventory_mismatch;' in sql
        assert 'UUID_STRING' not in sql
    if stage == 'expand-pool':
        assert 'GENERATOR(ROWCOUNT => 2)' in sql
        assert "STATE IS NULL OR STATE <> 'FREE'" in sql.replace("''", "'")


@pytest.mark.parametrize('stage', ['validate-agent', 'validate-pool'])
def test_routine_validation_sql_is_nonmutating_and_accepts_occupied_inventory(stage):
    sql = infra.prepare_sql(PROFILE, 'UAT', stage)
    body = '\n'.join(line for line in sql.splitlines() if not line.startswith('--'))
    assert not re.search(r'\b(?:CREATE|ALTER|DROP|INSERT|UPDATE|DELETE|MERGE|TRUNCATE|GRANT|REVOKE)\b', body)
    if stage == 'validate-pool':
        body = body.replace("''", "'")
        assert "STATE NOT IN ('FREE', 'HELD', 'QUARANTINED')" in body
        assert "STATE IN ('HELD', 'QUARANTINED') AND OWNER_TOKEN IS NULL" in body
        assert 'row_count <> 4 OR distinct_slots <> 4 OR invalid_rows <> 0' in body
        assert 'RAISE inventory_mismatch;' in body


@pytest.mark.parametrize('previous_capacity', [None, 0, 4, 5, True, 2.0])
def test_optional_expansion_requires_explicit_valid_previous_capacity(previous_capacity):
    with pytest.raises(ValueError, match='expand-pool requires --previous-capacity'):
        infra.prepare_sql(PROFILE, 'UAT', 'expand-pool', exclusive_deployment=True,
                          previous_capacity=previous_capacity)


def test_optional_expansion_requires_exclusive_approval_and_never_seeds():
    with pytest.raises(ValueError, match='--exclusive-deployment'):
        infra.prepare_sql(PROFILE, 'UAT', 'expand-pool', previous_capacity=2)
    with pytest.raises(ValueError, match='--initialize-empty-pool'):
        infra.prepare_sql(PROFILE, 'UAT', 'expand-pool', previous_capacity=2,
                          exclusive_deployment=True, initialize_empty_pool=True)
    for stage in WORKFLOW_STAGES['false']:
        with pytest.raises(ValueError, match='only valid for expand-pool'):
            infra.prepare_sql(PROFILE, 'UAT', stage, previous_capacity=2)


def test_initialization_preserves_existing_occupied_uat_pool_contract():
    sql = infra.prepare_sql(PROFILE, 'UAT', 'initialize-pool',
                            initialize_empty_pool=True, exclusive_deployment=True)
    body = '\n'.join(line for line in sql.splitlines() if not line.startswith('--')).replace("''", "'")
    assert body.count('INSERT INTO') == 1
    assert re.search(r'IF \(row_count = 0\) THEN\s+INSERT INTO.*?WHERE NOT EXISTS.*?END IF;', body, re.S)
    assert not re.search(r'\b(?:UPDATE|DELETE|MERGE|TRUNCATE|ALTER|DROP)\b', body)
    assert "STATE NOT IN ('FREE', 'HELD', 'QUARANTINED')" in body
    assert "STATE IN ('HELD', 'QUARANTINED') AND OWNER_TOKEN IS NULL" in body
    assert 'FENCE < 0 OR FENCE <> TRUNC(FENCE)' in body
    assert 'POOL_EPOCH <>' in body and '9078a6fb-0c1e-45b3-9b34-ab0c8a97bf0a' in body


DEPLOY_CONTEXT = ('SNOWFLAKE_ROLE', 'SNOWFLAKE_CONNECTION', 'SNOWFLAKE_REGISTRY_HOST')


def run_actual_deploy_render(tmp_path, *, enabled='false', settings=None, omit_exports=(), ambient=None,
                            extra_lines='', fast_settings=None):
    """Run the YAML deploy body with only the protected deployment boundary mocked.

    Import its real env reader and allowlisted preparation AST, not the wrapper's
    context seeding. Real renderer subprocesses inherit this fresh step's exports.
    Docker, bootstrap, Snow CLI and deployment statements are never executed.
    """
    source = step(DEPLOY)['run'].replace('${{ github.run_id }}', 'offline-test')
    assert source.count('./scripts/deploy_spcs_client_snow_single_service.ps1') == 1
    source = source.replace('./scripts/deploy_spcs_client_snow_single_service.ps1', 'Invoke-OfflineDeployer')
    for key in omit_exports:
        source, count = re.subn(rf'(?m)^\s*\$env:{key}\s*=.*$', '', source)
        assert count == 1, f'missing explicit workflow export: {key}'
    (tmp_path / '.client-tools-venv/bin').mkdir(parents=True)
    profile_path = tmp_path / 'infra/snowflake/env/parallel.uat.json'
    profile_path.parent.mkdir(parents=True)
    if fast_settings is None:
        profile_path.write_bytes(PROFILE.read_bytes())
    else:
        document = json.loads(PROFILE.read_text())
        toggles = {'AUTOMAP_FAST_PATH_V1', 'AUTOMAP_FAST_PROJECT_IDS', 'AUTOMAP_FAST_CANARY_REVISION'}
        document['settings'] = {key: value for key, value in document['settings'].items()
                                if key not in toggles}
        document['settings'].update(fast_settings)
        profile_path.write_text(json.dumps(document), encoding='utf-8')
    values = dict(dotenv_values(ROOT / 'infra/snowflake/env/client.env.example', interpolate=False))
    values.update(context(), SNOWFLAKE_OAUTH_REDIRECT_URI='https://app.example.test/api/v1/auth/callback',
                  AUTO_MAPPING_SERVICE_NAME='AUTOMAP_WORKER', SNOWFLAKE_PASSWORD='never-log-this',
                  AUTH_SESSION_SECRET='never-log-this', PRIVATE_KEY_PASSPHRASE='env-file-not-step-secret',
                  AUTO_MAPPING_SERVICE_MIN_INSTANCES='5', AUTO_MAPPING_SERVICE_MAX_INSTANCES='5',
                  AUTO_MAPPING_COMPUTE_POOL_MIN_NODES='5', AUTO_MAPPING_COMPUTE_POOL_MAX_NODES='5')
    values.update(settings or {})
    env_file = tmp_path / 'synthetic.env'
    env_file.write_text('\n'.join(f'{key}="{value}"' for key, value in values.items() if value is not None)
                        + '\n' + extra_lines, encoding='utf-8')
    before = env_file.read_bytes()
    fake = r"""
function Get-ParsedStatements([string]$Path) {
    $tokens = $null
    $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$errors)
    if ($errors.Count) { throw 'Invalid preparation AST' }
    return @($ast.EndBlock.Statements)
}
$wrapperStatements = Get-ParsedStatements (Join-Path $env:TEST_ROOT 'scripts/deploy_parallel_automap.ps1')
$sliceHelper = @($wrapperStatements | Where-Object { $_ -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $_.Name -eq 'Get-ConfigurationSlice' })
if ($sliceHelper.Count -ne 1) { throw 'Missing pure preparation helper' }
. ([scriptblock]::Create($sliceHelper[0].Extent.Text))
function Invoke-OfflineDeployer {
    param([string]$EnvFile, [string]$ImageTag)
    Write-Output DEPLOY_MOCK_ONLY
    if ($EnvFile -cne $env:ENV_FILE -or $ImageTag -cne 'offline-test') { throw 'Deployment arguments changed' }
    if ($env:PUBLICATION_RECOVERY_ENABLED -cne 'true') { throw 'Recovery lost' }
    if ($env:PRIVATE_KEY_PASSPHRASE -cne 'step-scoped-jwt-sentinel') { throw 'JWT step secret overwritten' }
    if ($env:SNOWFLAKE_PASSWORD -or $env:AUTH_SESSION_SECRET) { throw 'Unrelated secrets exported' }
    $entryKeys = @([Environment]::GetEnvironmentVariables('Process').Keys | Where-Object { $_ -match '^(SNOWFLAKE_|AUTH_|AUTO_MAP_)' } | Sort-Object)
    $RootDir = $env:TEST_ROOT
    $statements = Get-ParsedStatements (Join-Path $RootDir 'scripts/deploy_spcs_client_snow_single_service.ps1')
    foreach ($name in @('Import-ClientEnv', 'Convert-ToDnsLabel')) {
        $helper = @($statements | Where-Object { $_ -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $_.Name -eq $name })
        if ($helper.Count -ne 1) { throw 'Missing protected helper' }
        . ([scriptblock]::Create($helper[0].Extent.Text))
    }
    $cfg = Import-ClientEnv -Path $EnvFile
    $deployAutomap = $cfg.ContainsKey('AUTO_MAPPING_SERVICE_NAME') -and -not [string]::IsNullOrWhiteSpace($cfg['AUTO_MAPPING_SERVICE_NAME'])
    . (Get-ConfigurationSlice $statements '$appName =' 'if (-not (Get-Command docker')
    . (Get-ConfigurationSlice $statements '$env:SNOWFLAKE_DATABASE_LOWER =' 'function Build-AndPushImage')
    $receipt = @{ entryKeys = $entryKeys; minimum = $automapServiceMinInstances; maximum = $automapServiceMaxInstances }
    foreach ($key in @('SNOWFLAKE_ACCOUNT', 'SNOWFLAKE_DATABASE', 'SNOWFLAKE_SCHEMA', 'SNOWFLAKE_ROLE', 'SNOWFLAKE_CONNECTION', 'SNOWFLAKE_REGISTRY_HOST', 'SNOWFLAKE_REST_HOST', 'AUTH_MODE', 'SNOWFLAKE_OAUTH_AUTHORIZE_URL', 'SNOWFLAKE_OAUTH_TOKEN_URL')) {
        $receipt[$key] = [Environment]::GetEnvironmentVariable($key, 'Process')
    }
    $receipt | ConvertTo-Json | Set-Content -LiteralPath 'preparation.json' -Encoding UTF8
    foreach ($name in @('webapp', 'automap-worker')) {
        & $env:TEST_PYTHON -P (Join-Path $RootDir 'scripts/render_spcs_spec.py') --template (Join-Path $RootDir "infra/snowflake/service-specs/$name.yaml.tmpl") --output "$name.yaml"
        if ($LASTEXITCODE -ne 0) { throw "Offline render failed: $name (exit $LASTEXITCODE)" }
        Write-Output "RENDERED:$name"
    }
}
"""
    result = run_powershell(tmp_path, fake + source, AUTOMAP_PARALLEL_ROLLOUT=enabled,
                            PUBLICATION_RECOVERY_ENABLED='true', PRIVATE_KEY_PASSPHRASE='step-scoped-jwt-sentinel',
                            ENV_FILE=str(env_file), TEST_ROOT=str(ROOT), TEST_PYTHON=sys.executable, **(ambient or {}))
    assert env_file.read_bytes() == before
    assert 'never-log-this' not in result.stdout + result.stderr
    assert 'env-file-not-step-secret' not in result.stdout + result.stderr
    return result


@pytest.mark.parametrize('enabled', ['true', 'false'], ids=['rollout-marked', 'ordinary-unmarked'])
def test_actual_deploy_step_always_applies_profile_and_preserves_recovery(tmp_path, enabled):
    result = run_actual_deploy_render(tmp_path, enabled=enabled)
    assert result.returncode == 0, result.stdout + result.stderr
    assert re.findall(r'RENDERED:([a-z-]+)', result.stdout) == ['webapp', 'automap-worker']
    receipt = json.loads((tmp_path / 'preparation.json').read_text(encoding='utf-8-sig'))
    assert receipt['entryKeys'] == sorted(DEPLOY_CONTEXT)  # no blanket env-file import
    assert receipt['minimum'] == receipt['maximum'] == '5'
    for key, value in context().items():
        assert receipt[key] == value  # every profile input, not just the first failing field
    profile_settings = json.loads(PROFILE.read_text())['settings']
    for name in ('webapp', 'automap-worker'):
        rendered = (tmp_path / f'{name}.yaml').read_text()
        assert '${' not in rendered and 'never-log-this' not in rendered
        containers = yaml.safe_load(rendered)['spec']['containers']
        backend = next(item for item in containers if item['name'] == ('sttm-builder' if name == 'webapp' else 'automap-worker'))
        for key, value in profile_settings.items():
            assert backend['env'][key] == (str(value).lower() if isinstance(value, bool) else str(value))
        assert rendered_canary_receipt(backend['env']) == {
            'revision': 'uat-source-mapping-v3', 'image_version': 'offline-test',
            'enabled': True, 'project_ids': '*', 'eligible_301': True, 'eligible_501': True, 'eligible_502': True,
        }
        assert backend['env']['AUTO_MAP_PIPELINE_V2'] == 'false'
        assert 'SNOWFLAKE_ACCOUNT' not in backend['env']
        assert not set(DEPLOY_CONTEXT) & backend['env'].keys()
        if name == 'webapp':
            recovery = next(item for item in containers if item['name'] == 'publication-recovery')
            assert context()['SNOWFLAKE_ROLE'] in recovery['args']
            assert 'PRIVATE_KEY_PASSPHRASE' not in recovery['env']
        else:
            assert not any(item['name'] == 'publication-recovery' for item in containers)


def rendered_canary_receipt(environment):
    """Load the complete rendered container environment, not a mocked Settings object."""
    from app.core.automap_batch import fast_project_enabled
    from app.core.config import Settings
    actual = Settings(_env_file=None, **environment)
    return {
        'revision': actual.automap_fast_canary_revision,
        'image_version': actual.app_version,
        'enabled': actual.automap_fast_path_v1,
        'project_ids': actual.automap_fast_project_ids,
        'eligible_301': fast_project_enabled(actual, '301'),
        'eligible_501': fast_project_enabled(actual, '501'),
        'eligible_502': fast_project_enabled(actual, '502'),
    }


def test_actual_deploy_fast_canary_and_rollback_change_only_three_env_fields(tmp_path):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    from tests.unit.core.test_auto_mapping_proxy import _request
    baseline = {}
    fast_fields = {'AUTOMAP_FAST_PATH_V1', 'AUTOMAP_FAST_PROJECT_IDS', 'AUTOMAP_FAST_CANARY_REVISION'}
    for variant, overrides, expected in [
        ('on', None, (True, '*', 'uat-source-mapping-v3')),
        ('restricted', {'AUTOMAP_FAST_PATH_V1': True, 'AUTOMAP_FAST_PROJECT_IDS': '501',
                        'AUTOMAP_FAST_CANARY_REVISION': 'restricted-501'}, (True, '501', 'restricted-501')),
        ('off', {'AUTOMAP_FAST_PATH_V1': False, 'AUTOMAP_FAST_PROJECT_IDS': '*',
                 'AUTOMAP_FAST_CANARY_REVISION': 'rollback-all'}, (False, '*', 'rollback-all')),
        ('defaults', {}, (False, '', '')),
    ]:
        result = run_actual_deploy_render(tmp_path / variant, fast_settings=overrides, ambient={
            'AUTOMAP_FAST_PATH_V1': 'true', 'AUTOMAP_FAST_PROJECT_IDS': '501,502',
            'AUTOMAP_FAST_CANARY_REVISION': 'stale-ambient',
        })
        assert result.returncode == 0, result.stdout + result.stderr
        for name in ('webapp', 'automap-worker'):
            spec = yaml.safe_load((tmp_path / variant / f'{name}.yaml').read_text())
            containers = spec['spec']['containers']
            backend = containers[0]
            receipt = rendered_canary_receipt(backend['env'])
            assert (receipt['enabled'], receipt['project_ids'], receipt['revision']) == expected
            assert receipt['eligible_501'] is expected[0]
            assert receipt['eligible_301'] is expected[0]
            assert receipt['eligible_502'] is expected[0]
            config = Settings(_env_file=None, **backend['env'])
            for project in ('301', '501', '502', '1501', '5010', '0501'):
                for opt_in in (True, False):
                    request = _request(1)
                    request.context.project_id = project
                    request.meta = {'auto_map_fast_path': 'v1'}
                    if opt_in:
                        request.meta['auto_map_resolution_mode'] = 'preserve_and_complete'
                    accepted = AutoMappingProxyClient(config)._accept_resolution(request)
                    eligible = expected[0] and project != '0501'
                    assert ('auto_map_fast_path' in accepted.meta) == (eligible and opt_in)
            for container in containers[1:]:
                assert not fast_fields & container.get('env', {}).keys()
            for key in fast_fields:
                del backend['env'][key]
            if variant == 'on':
                baseline[name] = spec
            else:
                assert spec == baseline[name]  # Includes resources, recovery, image and all other settings.


def test_checked_in_dev_profile_does_not_inherit_uat_canary():
    path = ROOT / 'infra/snowflake/env/parallel.dev.json'
    _, settings = infra.load_profile(path, 'DEV')
    assert settings['AUTOMAP_FAST_PATH_V1'] == 'false'
    assert settings['AUTOMAP_FAST_PROJECT_IDS'] == settings['AUTOMAP_FAST_CANARY_REVISION'] == ''
    assert settings['AUTOMAP_PARALLEL_POOL_CAPACITY'] == '2'


@pytest.mark.parametrize('key', DEPLOY_CONTEXT)
def test_actual_deploy_render_requires_each_new_export(tmp_path, key):
    result = run_actual_deploy_render(tmp_path, omit_exports=(key,))
    assert result.returncode != 0
    assert f'ValueError: {key}' in result.stderr
    assert 'DEPLOY_MOCK_ONLY' in result.stdout and 'RENDERED:' not in result.stdout


@pytest.mark.parametrize('key', DEPLOY_CONTEXT)
@pytest.mark.parametrize('bad', [None, '', 'wrong-scope', '$(throw "must-not-execute")', '"', "'"])
def test_actual_deploy_step_rejects_invalid_file_context_before_delegation(tmp_path, key, bad):
    # Correct ambient values must never rescue missing/invalid env-file context.
    result = run_actual_deploy_render(tmp_path, settings={key: bad},
                                     ambient={field: context()[field] for field in DEPLOY_CONTEXT})
    assert result.returncode != 0
    assert f'UAT deployment refused: {key}' in result.stderr
    assert 'DEPLOY_MOCK_ONLY' not in result.stdout
    assert not (tmp_path / 'preparation.json').exists()


@pytest.mark.parametrize('key', DEPLOY_CONTEXT)
def test_actual_deploy_step_rejects_duplicate_context(tmp_path, key):
    result = run_actual_deploy_render(tmp_path, extra_lines=f'{key}={context()[key]}\n')
    assert result.returncode != 0
    assert f'UAT deployment refused: {key} is duplicated' in result.stderr
    assert 'DEPLOY_MOCK_ONLY' not in result.stdout


def test_actual_deploy_step_accepts_protected_parser_quoting_and_comments(tmp_path):
    lines = [f'  {key} = \'{context()[key]}\'  ' for key in DEPLOY_CONTEXT]
    result = run_actual_deploy_render(tmp_path, settings=dict.fromkeys(DEPLOY_CONTEXT),
                                     extra_lines='# SNOWFLAKE_ROLE=wrong-scope\n\n' + '\n'.join(lines))
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'RENDERED:automap-worker' in result.stdout


@pytest.mark.parametrize('host_style', ['hyphen', 'underscore'])
def test_actual_deploy_step_uses_file_context_not_stale_ambient(tmp_path, host_style):
    result = run_actual_deploy_render(tmp_path, settings=context(host_style),
                                     ambient={key: 'stale-ambient' for key in DEPLOY_CONTEXT})
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'RENDERED:automap-worker' in result.stdout


@pytest.mark.parametrize('key', ['SNOWFLAKE_ACCOUNT', 'SNOWFLAKE_DATABASE', 'SNOWFLAKE_SCHEMA',
                                 'SNOWFLAKE_REST_HOST', 'SNOWFLAKE_OAUTH_AUTHORIZE_URL', 'SNOWFLAKE_OAUTH_TOKEN_URL'])
def test_actual_deployer_other_profile_inputs_still_fail_closed(tmp_path, key):
    result = run_actual_deploy_render(tmp_path, settings={key: 'wrong-scope'})
    assert result.returncode != 0
    assert f'ValueError: {key}' in result.stderr
    assert 'RENDERED:' not in result.stdout


def test_all_workflow_powershell_steps_parse_without_execution(tmp_path):
    for index, item in enumerate(workflow()['jobs']['deploy-workbench']['steps']):
        if item.get('shell') != 'pwsh':
            continue
        source = re.sub(r'\$\{\{.*?\}\}', 'offline-test', item['run'])
        (tmp_path / f'step-{index}.ps1').write_text(source, encoding='utf-8')
    result = run_powershell(tmp_path, """
foreach ($file in Get-ChildItem -Filter 'step-*.ps1') {
    $tokens = $null
    $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors) | Out-Null
    if ($errors.Count) { throw ($errors | Out-String) }
}
Write-Output ALL_PARSED
""")
    assert result.returncode == 0, result.stderr
    assert 'ALL_PARSED' in result.stdout


def run_powershell(tmp_path, source, **variables):
    executable = shutil.which('pwsh') or shutil.which('powershell')
    assert executable, 'PowerShell is required for offline workflow execution tests'
    harness = tmp_path / 'workflow-test.ps1'
    harness.write_text("$ErrorActionPreference = 'Stop'\n" + source, encoding='utf-8')
    environment = {key: value for key, value in os.environ.items()
                   if key.upper() in {'SYSTEMROOT', 'WINDIR', 'PATH', 'PATHEXT', 'COMSPEC', 'TEMP', 'TMP'}}
    environment.update(variables)
    return subprocess.run([executable, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(harness)],
                          cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=30)


@pytest.mark.parametrize('enabled,failed_stage', [
    (enabled, stage) for enabled, stages in WORKFLOW_STAGES.items() for stage in (None, *stages)
])
def test_actual_provision_loop_stops_on_first_failed_stage(tmp_path, enabled, failed_stage):
    source = step(PROVISION)['run']
    assert source.count('& ./.client-tools-venv/bin/snow') == 1
    source = source.replace('& ./.client-tools-venv/bin/snow', 'Invoke-OfflineSnow')
    fake = """
function Invoke-OfflineSnow {
    $position = [array]::IndexOf($args, '-f')
    $stage = [IO.Path]::GetFileNameWithoutExtension($args[$position + 1])
    if ($stage -eq 'expand-pool') { throw 'automatic expansion forbidden' }
    Write-Output "EXECUTED:$stage"
    $global:LASTEXITCODE = if ($stage -eq $env:FAILED_STAGE) { 7 } else { 0 }
}
"""
    result = run_powershell(tmp_path, fake + source + '\nWrite-Output DEPLOY_REACHABLE',
                            RUNNER_TEMP=str(tmp_path), FAILED_STAGE=failed_stage or '',
                            AUTOMAP_PARALLEL_ROLLOUT=enabled)
    expected = list(WORKFLOW_STAGES[enabled])
    if failed_stage:
        expected = expected[:expected.index(failed_stage) + 1]
        assert result.returncode != 0
        assert 'DEPLOY_REACHABLE' not in result.stdout
    else:
        assert result.returncode == 0, result.stderr
        assert 'DEPLOY_REACHABLE' in result.stdout
    assert re.findall(r'EXECUTED:([a-z-]+)', result.stdout) == expected


@pytest.mark.parametrize('enabled,failed_stage', [
    (enabled, stage) for enabled, stages in WORKFLOW_STAGES.items() for stage in (None, *stages)
])
def test_actual_generation_loop_requires_exclusive_seed_and_stops_on_failure(tmp_path, enabled, failed_stage):
    source = step(GENERATE)['run']
    assert source.count('& ./.client-tools-venv/bin/python ./scripts/prepare_parallel_automap_infra.py') == 1
    source = source.replace('& ./.client-tools-venv/bin/python ./scripts/prepare_parallel_automap_infra.py',
                            'Invoke-OfflineGenerator')
    fake = """
function Invoke-OfflineGenerator {
    $position = [array]::IndexOf($args, '--stage')
    $stage = $args[$position + 1]
    if ($stage -eq 'expand-pool' -or $args -contains '--previous-capacity') { throw 'automatic expansion forbidden' }
    if (($stage -in @('create', 'initialize-pool')) -ne ($args -contains '--exclusive-deployment')) { throw 'exclusive gate missing' }
    if (($stage -eq 'initialize-pool') -ne ($args -contains '--initialize-empty-pool')) { throw 'wrong seed flag' }
    Write-Output "GENERATED:$stage"
    $global:LASTEXITCODE = if ($stage -eq $env:FAILED_STAGE) { 7 } else { 0 }
}
"""
    result = run_powershell(tmp_path, fake + source + '\nWrite-Output PROVISION_REACHABLE',
                            RUNNER_TEMP=str(tmp_path), FAILED_STAGE=failed_stage or '',
                            AUTOMAP_PARALLEL_ROLLOUT=enabled)
    expected = list(WORKFLOW_STAGES[enabled])
    if failed_stage:
        expected = expected[:expected.index(failed_stage) + 1]
        assert result.returncode != 0
        assert 'PROVISION_REACHABLE' not in result.stdout
    else:
        assert result.returncode == 0, result.stderr
        assert 'PROVISION_REACHABLE' in result.stdout
    assert sorted(path.stem for path in (tmp_path / 'parallel-automap-uat').glob('*.sql')) == sorted(expected)
    for stage in expected:
        assert (tmp_path / 'parallel-automap-uat' / f'{stage}.sql').read_text(encoding='utf-8-sig').strip() == f'GENERATED:{stage}'


@pytest.mark.parametrize('minimum,maximum,pool_min,pool_max,accepted', [
    ('5', '5', '5', '5', True),
    (None, None, None, None, False),
    ('2', '2', '5', '5', False),
    ('5', '5', '2', '5', False),
    ('5', '5', '5', '2', False),
    ('2', '5', '5', '5', False),
    ('', '5', '5', '5', False),
])
@pytest.mark.parametrize('enabled', ['true', 'false'])
def test_preflight_requires_five_workers_and_pool_nodes(tmp_path, minimum, maximum, pool_min, pool_max, accepted, enabled):
    source = step(VALIDATE)['run'].replace('${{ github.run_id }}', 'offline-test')
    assert source.count('./scripts/deploy_parallel_automap.ps1') == 1
    source = source.replace('./scripts/deploy_parallel_automap.ps1', 'Invoke-OfflineWrapper')
    (tmp_path / '.client-tools-venv/bin').mkdir(parents=True)
    env_file = tmp_path / 'synthetic.env'
    settings = {key: value for key, value in [
        ('AUTO_MAPPING_SERVICE_MIN_INSTANCES', minimum),
        ('AUTO_MAPPING_SERVICE_MAX_INSTANCES', maximum),
        ('AUTO_MAPPING_COMPUTE_POOL_MIN_NODES', pool_min),
        ('AUTO_MAPPING_COMPUTE_POOL_MAX_NODES', pool_max),
    ] if value is not None}
    env_file.write_text('\n'.join(f'{key}={value}' for key, value in settings.items()))
    fake = """
function Invoke-OfflineWrapper {
    if ($args -notcontains '-ValidateOnly') { throw 'deployment forbidden' }
    Write-Output VALIDATE_ONLY
}
"""
    result = run_powershell(tmp_path, fake + source, ENV_FILE=str(env_file), AUTOMAP_PARALLEL_ROLLOUT=enabled)
    assert (result.returncode == 0) == accepted, result.stdout + result.stderr
    assert ('VALIDATE_ONLY' in result.stdout) == accepted
