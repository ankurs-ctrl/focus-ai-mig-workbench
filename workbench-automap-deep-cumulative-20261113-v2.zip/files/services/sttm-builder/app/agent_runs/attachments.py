from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import zipfile
from pathlib import PurePath
from typing import Any
from uuid import uuid4
from xml.etree import ElementTree

import openpyxl
from pypdf import PdfReader

from app.agent_runs.models import AgentAttachment
from app.core.sql_parser import parse_sql_document


MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024
SUPPORTED_EXTENSIONS = {
    ".sql",
    ".xlsx",
    ".csv",
    ".txt",
    ".md",
    ".json",
    ".yaml",
    ".yml",
    ".docx",
    ".pdf",
    ".srt",
    ".vtt",
}
MIME_BY_EXTENSION = {
    ".sql": "application/sql",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".csv": "text/csv",
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".json": "application/json",
    ".yaml": "application/yaml",
    ".yml": "application/yaml",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".pdf": "application/pdf",
    ".srt": "application/x-subrip",
    ".vtt": "text/vtt",
}
PROMPT_INJECTION_PATTERNS = (
    re.compile(r"ignore\s+(all\s+)?(previous|prior|system)\s+instructions", re.I),
    re.compile(r"(system|developer)\s*prompt", re.I),
    re.compile(r"you\s+are\s+(now|an?)", re.I),
    re.compile(r"execute\s+(this|the)\s+(script|command|sql)", re.I),
)


class AttachmentValidationError(ValueError):
    pass


def detect_mime(filename: str, content: bytes) -> tuple[str, str]:
    extension = PurePath(filename).suffix.lower()
    if extension == ".xls":
        raise AttachmentValidationError(
            "Legacy .xls files are not supported; convert the workbook to .xlsx."
        )
    if extension not in SUPPORTED_EXTENSIONS:
        raise AttachmentValidationError(
            f"Unsupported attachment type {extension or '<none>'}. "
            f"Supported types: {', '.join(sorted(SUPPORTED_EXTENSIONS))}."
        )
    if extension in {".xlsx", ".docx"}:
        if not content.startswith(b"PK"):
            raise AttachmentValidationError("The file extension does not match an OOXML document")
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                names = set(archive.namelist())
            required = "xl/workbook.xml" if extension == ".xlsx" else "word/document.xml"
            if required not in names:
                raise AttachmentValidationError("The file contents do not match the declared OOXML type")
        except zipfile.BadZipFile as exc:
            raise AttachmentValidationError("The OOXML attachment is not a valid ZIP container") from exc
    elif extension == ".pdf" and not content.startswith(b"%PDF-"):
        raise AttachmentValidationError("The file contents do not match a PDF document")
    elif extension != ".pdf" and b"\x00" in content[:4096]:
        raise AttachmentValidationError("Binary content is not allowed for this attachment type")
    return extension, MIME_BY_EXTENSION[extension]


def prompt_injection_indicators(text: str) -> list[str]:
    return [pattern.pattern for pattern in PROMPT_INJECTION_PATTERNS if pattern.search(text)]


def _parse_docx(content: bytes) -> dict[str, Any]:
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        root = ElementTree.fromstring(archive.read("word/document.xml"))
    namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paragraphs = [
        "".join(node.text or "" for node in paragraph.findall(".//w:t", namespace)).strip()
        for paragraph in root.findall(".//w:p", namespace)
    ]
    return {"document_text": "\n".join(value for value in paragraphs if value)[:500_000]}


def _parse_pdf(content: bytes) -> dict[str, Any]:
    try:
        reader = PdfReader(io.BytesIO(content), strict=False)
        if reader.is_encrypted:
            raise AttachmentValidationError("Encrypted PDFs must be decrypted before upload")
        if len(reader.pages) > 250:
            raise AttachmentValidationError("PDF exceeds the 250-page parsing limit")
        pages = []
        for number, page in enumerate(reader.pages, start=1):
            pages.append(f"[page {number}]\n{page.extract_text() or ''}")
            if sum(map(len, pages)) >= 500_000:
                break
        if not any(page.partition("\n")[2].strip() for page in pages):
            raise AttachmentValidationError("This PDF has no extractable text; upload a text transcript or OCR version")
        return {"document_text": "\n".join(pages)[:500_000]}
    except AttachmentValidationError:
        raise
    except Exception as exc:
        raise AttachmentValidationError("The PDF could not be parsed as text") from exc


def _parse_xlsx(content: bytes) -> dict[str, Any]:
    workbook = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=False)
    sheets: list[dict[str, Any]] = []
    for sheet in workbook.worksheets[:20]:
        rows: list[list[str]] = []
        for row in sheet.iter_rows(values_only=True):
            rows.append([str(value) if value is not None else "" for value in row[:100]])
            if len(rows) >= 10_000:
                break
        sheets.append({"name": sheet.title, "rows": rows})
    return {"sheets": sheets}


def _parse_csv(content: bytes) -> dict[str, Any]:
    text = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    rows = [dict(row) for _, row in zip(range(10_000), reader, strict=False)]
    return {"columns": reader.fieldnames or [], "mapping_rows": rows}


def parse_attachment(filename: str, content: bytes) -> tuple[str, str, dict[str, Any], list[str]]:
    extension, mime = detect_mime(filename, content)
    text_for_scan = ""
    if extension == ".sql":
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        # The raw text is kept with its lineage so the agent can quote and
        # reuse the statements, not just the parsed structure.
        parsed = {"sql_text": text_for_scan[:500_000], **parse_sql_document(text_for_scan).to_dict()}
    elif extension == ".xlsx":
        parsed = _parse_xlsx(content)
        text_for_scan = json.dumps(parsed, default=str)
    elif extension == ".csv":
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        parsed = _parse_csv(content)
    elif extension == ".json":
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        parsed = {"json": json.loads(text_for_scan)}
    elif extension in {".yaml", ".yml", ".txt", ".md", ".srt", ".vtt"}:
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        parsed = {"document_text": text_for_scan[:500_000]}
    elif extension == ".docx":
        parsed = _parse_docx(content)
        text_for_scan = str(parsed.get("document_text") or "")
    elif extension == ".pdf":
        parsed = _parse_pdf(content)
        text_for_scan = str(parsed.get("document_text") or "")
    else:  # pragma: no cover - guarded by detect_mime
        raise AttachmentValidationError("Unsupported attachment type")
    indicators = prompt_injection_indicators(text_for_scan)
    manifest = {
        "parser_version": "2.0",
        "content_is_untrusted_evidence": True,
        "atomized": parsed,
        "prompt_injection_detected": bool(indicators),
    }
    return extension, mime, manifest, indicators


class AttachmentService:
    """Validate, parse without execution, and persist immutable attachment metadata."""

    def __init__(self, session: Any, *, stage_prefix: str = "@WORKBENCH_AGENT_ATTACHMENTS") -> None:
        self._session = session
        self._stage_prefix = stage_prefix.rstrip("/")

    def ingest(
        self,
        *,
        filename: str,
        content: bytes,
        owner_user_id: str,
        tenant_id: str = "default",
    ) -> AgentAttachment:
        if not filename or PurePath(filename).name != filename:
            raise AttachmentValidationError("Attachment filename must not contain a path")
        if not content:
            raise AttachmentValidationError("Attachment is empty")
        if len(content) > MAX_ATTACHMENT_BYTES:
            raise AttachmentValidationError(
                f"Attachment exceeds the {MAX_ATTACHMENT_BYTES // (1024 * 1024)} MB limit"
            )
        extension, mime, manifest, indicators = parse_attachment(filename, content)
        digest = hashlib.sha256(content).hexdigest()
        existing_rows = self._session.sql(
            """SELECT ATTACHMENT_PAYLOAD FROM TBL_AGENT_ATTACHMENTS
            WHERE TENANT_ID = ? AND OWNER_USER_ID = ? AND CONTENT_HASH = ? LIMIT 1""",
            [tenant_id, owner_user_id, digest],
        ).collect()
        if existing_rows:
            row = existing_rows[0].as_dict() if hasattr(existing_rows[0], "as_dict") else dict(existing_rows[0])
            payload = row.get("ATTACHMENT_PAYLOAD") or {}
            if isinstance(payload, str):
                payload = json.loads(payload)
            return AgentAttachment.model_validate(payload)
        attachment_id = f"att_{uuid4().hex}"
        safe_tenant = re.sub(r"[^A-Za-z0-9_-]", "_", tenant_id)[:128] or "default"
        immutable_uri = f"{self._stage_prefix}/{safe_tenant}/{digest}/{digest}{extension}"
        # Snowpark file.put_stream performs an immutable content-addressed write;
        # overwrite is disabled so a replay cannot replace original evidence.
        file_api = getattr(self._session, "file", None)
        if file_api is not None and hasattr(file_api, "put_stream"):
            file_api.put_stream(io.BytesIO(content), immutable_uri, overwrite=False, auto_compress=False)
        attachment = AgentAttachment(
            attachment_id=attachment_id,
            owner_user_id=owner_user_id,
            tenant_id=tenant_id,
            filename=filename,
            extension=extension,
            detected_mime=mime,
            size_bytes=len(content),
            content_hash=digest,
            immutable_uri=immutable_uri,
            scan_status="clean",
            parser_status="parsed",
            prompt_injection_indicators=indicators,
            parsed_manifest=manifest,
        )
        self._session.sql(
            """
            INSERT INTO TBL_AGENT_ATTACHMENTS
                (ATTACHMENT_ID, OWNER_USER_ID, TENANT_ID, CONTENT_HASH, IMMUTABLE_URI,
                 FILENAME, DETECTED_MIME, SIZE_BYTES, SCAN_STATUS, PARSER_STATUS,
                 ATTACHMENT_PAYLOAD, CREATED_AT, UPDATED_AT)
            SELECT ?,?,?,?,?,?,?,?,?,?,PARSE_JSON(?),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP()
            """,
            [
                attachment.attachment_id, attachment.owner_user_id, attachment.tenant_id,
                attachment.content_hash, attachment.immutable_uri, attachment.filename,
                attachment.detected_mime, attachment.size_bytes, attachment.scan_status,
                attachment.parser_status, json.dumps(attachment.model_dump(mode="json"), default=str),
            ],
        ).collect()
        return attachment
