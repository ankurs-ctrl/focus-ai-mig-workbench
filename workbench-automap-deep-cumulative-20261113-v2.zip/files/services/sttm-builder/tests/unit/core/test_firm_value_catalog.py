from app.agent_tools.firm_value_catalog import build_catalog, catalog_choices, inventory, required_values
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.core.sql_parser import parse_sql_document

HH = """WITH SOURCE AS (SELECT c.id AS LegacyCRMID, c.name, mu.TARGET_CRM_ID FROM DB.S.CONTACTS c
  LEFT JOIN DB.S.MAPPER_USER mu ON mu.WRITING_ADVISOR_ID = c.writing_advisor_id)
SELECT $HHRecordType AS "RecordTypeId",
       $LegacyHHcPrefix || 'HH_' || SOURCE.LegacyCRMID AS "Legacy_ID__c",
       COALESCE(SOURCE.TARGET_CRM_ID, $BackupOwnerID) AS "OwnerId",
       $TransactionFirmID AS "Transaction_Firm__c",
       SOURCE.name AS "Name"
FROM SOURCE"""


def _catalog():
    return build_catalog(
        [("01-HHs.sql", "DB.AIA_WB_TARGET.HOUSEHOLD", parse_sql_document(HH))],
        ["HHRecordType", "LegacyHHcPrefix", "BackupOwnerID", "TransactionFirmID", "MigrationMasterSchema", "Referral"],
        source="test",
    )


def test_catalog_records_names_kinds_and_column_usage_but_no_values():
    catalog = _catalog()
    by_name = {item["name"]: item for item in catalog["values"]}
    assert "MigrationMasterSchema" not in by_name  # names a schema, not a firm value
    assert by_name["HHRecordType"]["kind"] == "core"
    assert by_name["BackupOwnerID"]["kind"] == "firm"
    assert [(u["column"], u["shape"]) for u in by_name["HHRecordType"]["used_for"]] == [("RecordTypeId", "value")]
    assert by_name["LegacyHHcPrefix"]["used_for"][0]["shape"] == "prefix"
    assert by_name["BackupOwnerID"]["used_for"][0]["shape"] == "fallback"
    assert all("value" not in item for item in catalog["values"])


def test_catalog_choices_for_fixed_target_columns():
    choices = catalog_choices(_catalog(), "FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD",
                              ["RECORDTYPEID", "TRANSACTION_FIRM__C", "OWNERID", "NAME"])
    assert {column: (c.name, c.shape) for column, c in choices.items()} == {
        "RECORDTYPEID": ("HHRecordType", "value"),
        "TRANSACTION_FIRM__C": ("TransactionFirmID", "value"),
        "OWNERID": ("BackupOwnerID", "fallback"),
    }
    assert choices["RECORDTYPEID"].reason.startswith("The firm-value catalogue sets RECORDTYPEID")
    assert catalog_choices(_catalog(), "X.Y.BIZ_ACCOUNTS", ["RECORDTYPEID"]) == {}


def test_inventory_lists_missing_values_and_who_holds_them():
    catalog = _catalog()
    held = {"BACKUPOWNERID": {"name": "BackupOwnerID", "value": "005"}}
    holders = [
        {"PROJECT_ID": "101", "PROJECT_NAME": "Redtale TMD", "ATTRIBUTE_NAME": "HHRecordType"},
        {"PROJECT_ID": "101", "PROJECT_NAME": "Redtale TMD", "ATTRIBUTE_NAME": "TransactionFirmID"},
        {"PROJECT_ID": "7", "PROJECT_NAME": "Other", "ATTRIBUTE_NAME": "HHRecordType"},
        {"PROJECT_ID": "9", "PROJECT_NAME": "This", "ATTRIBUTE_NAME": "HHRecordType"},
    ]
    result = inventory(catalog, ["DB.AIA_WB_TARGET.HOUSEHOLD"], held, holders, project_id="9")
    assert result["held"] == ["BackupOwnerID"]
    assert sorted(item["name"] for item in result["missing"]) == ["HHRecordType", "LegacyHHcPrefix", "TransactionFirmID"]
    assert result["import_sources"][0] == {"project_id": "101", "project_name": "Redtale TMD",
                                           "names": ["HHRecordType", "TransactionFirmID"]}
    assert "1 of 4 firm values" in result["summary"]
    assert set(required_values(catalog, ["X.Y.CALLS"])) == set()


def test_inventory_can_plan_an_import_before_the_new_project_exists(monkeypatch):
    monkeypatch.setattr("app.agent_tools.firm_value_catalog.load_catalog", lambda _settings: _catalog())

    class Projects:
        @staticmethod
        def firm_value_holders(names):
            assert sorted(names) == ["BackupOwnerID", "HHRecordType", "LegacyHHcPrefix", "TransactionFirmID"]
            return [{
                "PROJECT_ID": "101",
                "PROJECT_NAME": "Redtale TMD",
                "ATTRIBUTE_NAME": name,
            } for name in names]

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._settings = None
    handler._projects = Projects()
    handler._budget = None
    import threading
    handler._domain_lock = threading.RLock()

    result = handler.firm_values_inventory({}, ["DB.AIA_WB_TARGET.HOUSEHOLD"])

    assert result.status == "succeeded"
    assert result.data["held"] == []
    assert result.data["import_sources"][0]["project_id"] == "101"
    assert len(result.data["import_sources"][0]["names"]) == 4
