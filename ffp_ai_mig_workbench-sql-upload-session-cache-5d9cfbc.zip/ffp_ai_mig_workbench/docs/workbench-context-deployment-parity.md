# Workbench context and deployment parity

## Authorized release (2026-10-16)

The owner authorized committing the local FEATURE work, pushing a release branch
and uppercase `UAT`, and deploying DEV. Earlier no-deployment statements below
record historical gates, not the current authorization. Business acceptance gaps
remain separate from release authorization.

- `scripts/bootstrap_sttm_metadata_infra.py --check-release-parity` validates all
  tracked bootstrap dependencies and eight agent tool/resource inventories offline.
- New installs include canonical FIR history and recipe Search definitions. Do not
  run full bootstrap against existing DEV merely to deploy application images:
  it replaces agents and applies tasks/streams. Existing agent changes require
  complete before-spec snapshots and a reviewed, selective update.
- `CurrentBundleAnalyst` is runtime-only. Renderer defaults keep
  `AGENT_REQUEST_SCOPED_ANALYST_V1=false` and `AGENT_BUNDLE_VIEW_SCHEMA` empty.
  Cyclic bundle relationships still block its live acceptance.
- Preserve the protected deployer's bytes. Build FEATURE images, push matching
  backend/worker tags, then use its FEATURE copy with `-SkipBuild -ImageTag ...`
  and the reviewed private DEV profile. Set `STTM_MAPPING_BULK_WRITE_V1=true`
  in the invoking process; retain explicit batch size 16 in the profile.
- Live preflight found DEV web min/max 1/1 and worker min/max 2/2. Preserve both
  services' counts, endpoint identities, integrations and existing compute pool.
- Uppercase `UAT` is distinct from lowercase `uat`. Its push workflow deploys to
  the UAT database/service. Merge non-destructively and preserve its deployment
  and authentication changes; never copy the DEV env into UAT.
- Release checks: backend suite 1,059 passed with three known failures (protected
  deployer bulk-write export, protected batch fallback, Windows POSIX file mode);
  all 13 frontend harnesses passed; backend, frontend production and nginx images
  built successfully. These checks do not prove mapping business correctness.

## Implementation baseline (2026-10-15)

- Application code: `ffp_ai_mig_workbench_zip_review`.
- Branch: `feature/automap-context-firm-values-2.9.6`.
- Starting HEAD: `dad856fd31339dd00024c989340815e3dbc50d2c`.
- Starting tree: 45 tracked modified files, plus existing assistant-context tests,
  fonts, session gate, tour additions and deployment logs. These changes are
  inherited; they must not be discarded or attributed to this implementation.
- Local runtime baseline: MAIN `.env.local` and its trusted CA bundle, with
  backend port 8000 and frontend port 3000. Do not use the stale feature env.
- Verified local transport allowance: 4194304 bytes. Model message allowance:
  120000 characters / 131072 bytes. Submitted SPCS values: 1048576 transport
  bytes and 200000 characters / 262144 model bytes.
- Local registry objects: `LATEST_TABLE_REGISTRY_V`,
  `LATEST_COLUMN_REGISTRY_V`, `LATEST_NATIVE_VIEWS` in
  `FFP_HDP_DLAB_DB_DEV.SCH_STTM_MCP`.
- Audited backend/worker image digest:
  `sha256:3d5466b73b84d8b70fb0b31426187b968d3a27781f4607755a617a19367016ef`.
- Audited frontend digest:
  `sha256:e15e91eeff99bf1117da9f4d74f2ee95866f178da4190b9ef49be5941b5814ca`.

## Guardrails

Do not modify `scripts/deploy_spcs_client_snow_safe.ps1`. Do not publish agents,
grant privileges, deploy services, load targets, commit or push as part of local
implementation. Service monitoring is denied by this chat's restricted session
scope; do not bypass that denial through another connection.

The exact ACCOUNT semantic ambiguity remains unverified. Tests for validation
must reproduce a semantic-resolution failure without asserting its production
cause. Existing scope, SQL fidelity, legacy bindings, SET values and compiler
hash safeguards remain authoritative.

## Acceptance record

Implementation and verification results are appended as each step completes.
Local unit fixtures are not a substitute for live 37-column Auto-map or agent
acceptance. Release remains gated on explicit approval and permitted monitoring.

## Selective October 14 zip merge

Archive: `bbi-mig-ai-workbench-develop-8300e985-20261014.zip`, root
`bbi-mig-ai-workbench-develop-20261014`.

Included: pinned source/target/CTE library searches, shared Select Tables title
and icon styling, main-panel/relationship title reuse, AI Agent dashboard step,
mapping source/rule header targets, confidence groups, Query Preview and SQL
edit/validate/optimize/run tour steps. Updated CTE/preprocess/new-mapping guidance
to match current controls. Tour copy does not claim every target is auto-mapped
or that suggested optimizations are applied without approval.

Already present: font assets and family adopters, typography tokens, sign-in
session handling, tour engine, new-project and join-definition tours. Remaining
wording-only differences are intentional when the existing guidance is more
accurate (CTE drag/edit, publish validation gates and source/target requirements).

Excluded: zip changes removing scoped AST SQL application, WHERE/QUALIFY/ORDER
fidelity, driving-table controls, join operator reversal, conflict detection or
full-predicate handling. These are not cosmetic omissions.

## Implemented behavior and verification

- Complete AST-supported ON predicates become ordinary column conditions;
  complex predicates remain intact with an explicit replacement action.
- Uploaded CTE original identifiers travel separately from durable aliases.
  Compiler output removes exact standalone self-wrappers and preserves original
  quoted names when safe. Scope-bound renames update dependent references;
  name capture, collisions and unsupported shapes retain stable aliases.
- Plain SQL review has no semantic-refresh prerequisite. Optional optimization
  reuses YAML and reports a warning instead of aborting validation on a refresh
  error. Review does not mutate compiler semantic inputs.
- Semantic preparation reuses unchanged access-scoped inputs, with fixed-age
  validity, revision-sensitive keys, bounded cache/locks and invalidation
  generation checks. Persisted derived IDs still resolve current revisions.
- Oversized chat uses a request-local exact-section manifest. Backend executes
  only typed orchestrator delegations with snapshot/section hash checks, nested
  paths, bounded ranges, explicit budget failures and continuation. Graph
  bindings and UI state remain inline. No shared-agent tool mutation is used.
- Full message budgeting includes checkpoint/history and JSON envelope overhead.
  Required current content is not truncated; omitted history is distinguished.
- Eight frontend Node regression harnesses passed; TypeScript and focused ESLint
  passed. The final Next.js build compiled in 15.8 seconds, completed TypeScript
  in 67 seconds, and generated all 23 static pages successfully.
- Full backend unit suite: **780 passed, 3 baseline failures, 3 warnings**.
  Remaining failures are the protected renderer's missing bulk-write export,
  its batch-size fallback, and POSIX mode-0600 expectation on Windows. The
  reviewed explicit profile remains batch size 16. The trackable example now
  preserves the reviewed non-secret registry, transport and packet settings.
  New paired-spec/unchanged-script tests passed.
- Latest registry views exist, column contracts were inspected, and bounded
  read-access probes succeeded through the active Snowflake connection.
- Independent static SQL and retrieval reviews found edge cases; fixes and
  regression tests cover physical-table name capture, dependent aliases,
  factored context closure, nested range paging and invalidation races.

## Release preparation (no deployment performed)

Both host and worker must use the reviewed feature `infra/snowflake/env/client.env`:
transport 4194304 bytes, model packet 120000 characters / 131072 bytes, and the
three `LATEST_*` registry views. Paired template tests check those exact values
and preserve custom OAuth. Batching remains 16 with two in-flight batches.

Run `scripts/workbench_release_manifest.py` before building. It prints the
feature root, branch, full revision, dirty status, non-secret runtime settings,
per-source hashes and a unique suggested image tag. Capture its output with the
release evidence; do not reuse bare `dad856f` for a dirty-source build.

Invoke the unchanged protected deployer **from the feature checkout**, with its
explicit reviewed env path, only after release approval. The deployer's root is
its own script directory, not the shell's current directory. Set the existing
renderer plumbing gap `STTM_MAPPING_BULK_WRITE_V1=true` in the parent process;
do not edit the protected script to export it. Deploy matching host/worker
images together and verify digests/specs after rollout through permitted access.

Protected deployer SHA256:
`486DDC012EFFA2EF7B19C6A1FD40CB7622F8929A15A0C3DA9D2E856B9837BAC6`.

Open acceptance gates: current RSS still blocks service monitoring. Exact ACCOUNT
ambiguity, the original HOUSEHOLD 35/37-column worker workload, live Analyst
delegation and complete saved-mapping browser acceptance remain unverified.
Local production UI acceptance encountered a cookie/middleware redirect loop:
local backend session returns 200 without the cookie required by frontend
production middleware. Local development routing now requires all three guards:
Next development mode, explicit server-side `LOCAL_DEV_AUTH_ENABLED=true`, and
loopback hostname. The launcher derives the flag from the chosen backend env.
Production/remote requests retain the cookie guard; backend data authorization
is unchanged. Middleware regression, launcher tests and TypeScript passed.
Browser Dashboard now renders 25 projects and 193 mappings on ports 8000/3000.
No fake cookie was used. This is a local UI smoke check, not live agent acceptance.

## Final local/API and live chat checks (2026-10-15)

- The latest feature backend is loaded on 8000; the development frontend is on
  3000. Dashboard, mapping list and new unsaved builder rendered. DOM checks
  confirmed all three source/target/CTE searches have sticky ancestors. The CTE
  dialog opened and was canceled without saving. This does not prove every tour
  step or imported join edit/save/reopen workflow in the browser.
- Nine API parse/compile cycles passed: three each for `accounts`, `cte_accounts`
  and legitimate `cte_cte_accounts`. Output did not retain the generated internal
  alias. Final cycle request: `db331b52-9ebd-47a8-a21d-477a05406cc7`. These were
  synthetic compiler fixtures, not live physical-table compilation checks.
- SQL review without any semantic model passed for `SELECT 1` and a read-only
  ACCOUNT query with `WHERE 1 = 0`. ACCOUNT request:
  `df3f549b-0ec1-42dc-bf73-7d09c2b64e52`; executor reported syntax valid and
  execution ready. This does not establish the original ambiguity's cause.
- Full unchanged workspace snapshots now reuse prepared semantics by normalized
  input equality, rather than explicit field presence. Source changes, clears,
  driving-relation changes and filter changes invalidate provenance.
- Live chat exposed invalid optional agent semantic-refresh metadata with a null
  bundle ID. It is now rejected with an explicit warning without inventing a
  bundle or discarding the answer; regression tests cover canonical and legacy
  responses. Out-of-range retrieval requests return a bounded error for correction
  rather than HTTP 500. Hash/range validation remains strict and returns no data
  for invalid requests.
- An oversized 200K-character SQL fixture reached the normal orchestrator through
  a bounded manifest. Initial attempts showed that the live agent needed clearer
  application-delegation instructions and could choose invalid offsets; neither
  attempt was counted as a pass. The corrected protocol explicitly distinguishes
  response delegation from registered Snowflake tools.
- Final isolated request `parity-live-retrieval-bounded` retrieved an unseen tail
  marker exactly; thread `903e35fc-6aa3-4c32-b7c3-5457718dca80`. Follow-up
  `parity-live-retrieval-bounded-followup` repeated it exactly; thread
  `789be764-ba95-4a00-91ea-0d71518c1945`. No Search, Analyst, SQL execution or
  mapping tool was requested. This proves the live request-local continuation
  path on the explicit fixture, not arbitrary task accuracy or live Analyst use.
- An isolated 37-target ACCOUNT identity-mapping request failed before model
  dispatch with `AGENT_PAYLOAD_REQUIRED_CONTEXT_TOO_LARGE`. Direct request
  `parity-isolated-37-account-valid` and batched job request
  `parity-isolated-37-worker` both failed; the job path reduced to one target
  without fitting the required semantic context. This is an observed model-packet
  blocker, not a successful 37-column test and not proof of the HOUSEHOLD cause.
  Logs measured about 493K characters of semantic context in the direct request.
  Read-only registry inspection found a 441540-character raw ACCOUNT semantic
  record, including 61619 characters of PK-detection evidence. No required rules
  were truncated and the model limit was not increased to hide the failure.
- The restarted MAIN-env local runtime has hybrid projection and compact encoding
  disabled, and batch size 5. The explicit release profile has the same disabled
  projection flags but batch size 16. Prior successful local process overrides
  therefore remain to be established before asserting full runtime parity.
  Existing dependency-aware projection is a separate mode; it was not blindly
  enabled or treated as a proven replacement. Resolving this model-packet gate
  and rerunning the worker fixture is required before release readiness.
- Final tested source fingerprint:
  `2154350ff8066958caf38444ebd3d5fbafe012386cad17c4e434aa41db269eb0`.
  Suggested unreleased tag: `dad856f-20261015T132704Z-2154350f`.
  Re-run the manifest before an approved build if any included source changes.

The real client env remains ignored because it contains secrets. This document
is explicitly allowed by `.gitignore`; non-secret defaults are in the example
profile. No deployment, agent publication, grants, commit or push was performed.
Task 8 remains open for the listed acceptance/release gates.