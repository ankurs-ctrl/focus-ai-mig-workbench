"""Execute exact operational SQL without a duplicate Snowpark AST payload.

Select the supported API before executing; never catch/replay a SQL operation.
Small injected adapters can retain their existing sql/collect signatures.
"""
from inspect import signature


def collect_storage_sql(session, sql, params=None):
    options = {'_emit_ast': False} if '_emit_ast' in signature(session.sql).parameters else {}
    frame = session.sql(sql, params=params, **options)
    collect_options = {'_emit_ast':False} if '_emit_ast' in signature(frame.collect).parameters else {}
    return frame.collect(**collect_options)
