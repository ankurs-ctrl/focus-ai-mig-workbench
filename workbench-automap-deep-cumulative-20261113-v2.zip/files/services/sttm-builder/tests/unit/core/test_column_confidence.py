from __future__ import annotations

from app.agent_tools.column_confidence import (
    DEFAULT_WEIGHTS,
    candidate_confidence,
    score_column,
    type_family,
    weights_from_settings,
)

ROW = {"target_column": "NAME", "source_columns": ["DB.NEW.CONTACT_FAMILIES.NAME"], "confidence": 0.8}
PRECEDENT = {"target_column": "NAME", "source_columns": ["DB.OLD.CONTACT_FAMILIES.NAME"],
             "evidence_source": "historical_precedent", "approval_state": "candidate", "evidence_id": "sttm_precedent:1"}


def test_specialist_alone_is_capped() -> None:
    scored = score_column(ROW, [])
    assert scored["confidence"] == round(0.8 * DEFAULT_WEIGHTS["specialist"], 4)


def test_precedent_on_another_clients_copy_corroborates_by_table_and_column_name() -> None:
    alone = score_column(ROW, [])["confidence"]
    scored = score_column(ROW, [PRECEDENT])
    assert scored["confidence"] > alone
    assert scored["agreeing_evidence_ids"] == ["sttm_precedent:1"]
    approved = score_column(ROW, [{**PRECEDENT, "approval_state": "published"}])["confidence"]
    assert approved > scored["confidence"]


def test_one_kind_counts_once() -> None:
    twice = score_column(ROW, [PRECEDENT, {**PRECEDENT, "evidence_id": "sttm_precedent:2"}])["confidence"]
    assert twice == score_column(ROW, [PRECEDENT])["confidence"]


def test_conflicting_approved_precedent_lowers_confidence_more_than_an_unverified_lead() -> None:
    other = {**PRECEDENT, "source_columns": ["DB.OLD.CONTACTS.FIRST_NAME"], "approval_state": "published"}
    lead = {**other, "evidence_source": "fir_learning", "approval_state": "unverified"}
    base = score_column(ROW, [])["confidence"]
    against_precedent = score_column(ROW, [other])
    against_lead = score_column(ROW, [lead])["confidence"]
    assert against_precedent["confidence"] < against_lead < base
    assert "CONTACTS.FIRST_NAME" in against_precedent["reasons"][-1]


def test_direct_type_mismatch_is_penalised_but_casts_are_not() -> None:
    types = {"DB.NEW.CONTACT_FAMILIES.NAME": "VARCHAR(100)"}
    mismatch = score_column(ROW, [], target_type="DATE", source_types=types)
    assert mismatch["confidence"] < score_column(ROW, [])["confidence"]
    cast = score_column({**ROW, "expression": "TRY_TO_DATE(NAME)"}, [], target_type="DATE", source_types=types)
    assert cast["confidence"] == score_column(ROW, [])["confidence"]
    # Anything can be written into a text column.
    assert score_column(ROW, [], target_type="VARCHAR(10)", source_types={"DB.NEW.CONTACT_FAMILIES.NAME": "NUMBER(38,0)"}) \
        == score_column(ROW, [])


def test_candidate_confidence_combines_every_source_for_the_same_lineage() -> None:
    fir = {"target_column": "NAME", "source_columns": ["CONTACT_FAMILIES.NAME"], "evidence_source": "fir_learning",
           "approval_state": "approved", "evidence_id": "learning:9"}
    one = candidate_confidence("NAME", ["DB.NEW.CONTACT_FAMILIES.NAME"], PRECEDENT, [PRECEDENT])
    both = candidate_confidence("NAME", ["DB.NEW.CONTACT_FAMILIES.NAME"], PRECEDENT, [PRECEDENT, fir])
    assert both > one > 0
    # An explicit score on the evidence item is kept.
    assert candidate_confidence("NAME", [], {**PRECEDENT, "confidence": 0.33}, []) == 0.33


def test_type_families_and_settings_override() -> None:
    assert type_family("NUMBER(38,0)") == "number" and type_family("TIMESTAMP_NTZ(9)") == "datetime"
    assert type_family("VARCHAR(18)") == "text" and type_family("BOOLEAN") == "boolean"

    class _Settings:
        migration_agent_column_evidence_weights_json = '{"specialist": 0.5, "unknown": 1}'

    weights = weights_from_settings(_Settings())
    assert weights["specialist"] == 0.5 and "unknown" not in weights


def test_output_equivalent_precedent_sql_becomes_column_evidence_that_corroborates() -> None:
    from types import SimpleNamespace

    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    sql = (
        'WITH SOURCE AS (SELECT c.ID, c.NAME, f.NAME AS FAMILY_NAME FROM DB.OLD.CONTACTS c '
        'JOIN DB.OLD.CONTACT_FAMILIES f ON f.ID = c.FAMILY_ID) '
        'SELECT s.FAMILY_NAME AS "NAME", \'Household\' AS "TYPE__C", s.ID AS "LEGACY_ID__C" FROM SOURCE s'
    )
    detail = SimpleNamespace(latest_snapshot={"mapping_sql": sql}, sttm=SimpleNamespace(status="DRAFT"))
    handlers = WorkbenchWorkflowHandlers(repository=object(), session=object(),
                                         project_service=SimpleNamespace(get_sttm_detail=lambda _id: detail))
    evidence = handlers._output_equivalent_column_evidence(
        [{"sttm_id": "2101"}], ["NAME", "TYPE__C", "LEGACY_ID__C", "NOT_IN_SQL"])
    by_target = {item["target_column"]: item for item in evidence}
    assert set(by_target) == {"NAME", "TYPE__C", "LEGACY_ID__C"}
    assert by_target["NAME"]["evidence_id"] == "sttm_precedent:2101"
    assert by_target["NAME"]["approval_state"] == "candidate"
    assert any(value.upper().endswith("CONTACT_FAMILIES.NAME") for value in by_target["NAME"]["source_columns"])
    assert by_target["TYPE__C"]["source_columns"] == [] and by_target["TYPE__C"]["constant_value"] == "Household"
    # The same lineage on the current client's copy is corroborated.
    row = {"target_column": "NAME", "source_columns": ["DB.NEW.CONTACT_FAMILIES.NAME"], "confidence": 0.9}
    assert score_column(row, evidence)["agreeing_evidence_ids"] == ["sttm_precedent:2101"]


def test_identifiers_match_across_naming_styles_of_client_copies() -> None:
    row = {"target_column": "OWNERID", "source_columns": ["DB.NEW.MAPPER_USER.TARGET_CRM_ID"], "confidence": 0.9}
    old = {**PRECEDENT, "target_column": "OWNERID", "source_columns": ["DB.OLD.MAPPER_USER.TARGETCRMID"]}
    scored = score_column(row, [old])
    assert scored["agreeing_evidence_ids"] == ["sttm_precedent:1"] and not scored["conflicting_evidence_ids"]
    # A genuinely different column still conflicts, reported with its real name.
    other = {**old, "source_columns": ["DB.OLD.CONTACTS.OWNER_NAME"]}
    assert "CONTACTS.OWNER_NAME" in score_column(row, [other])["reasons"][-1]


def test_uncorroborated_drafts_are_confirmed_together_but_disagreements_stay_separate() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    rows = [
        {"target_column": "A", "status": "draft", "confidence": 0.6, "source_columns": ["DB.S.T.A"],
         "confidence_evidence": {"reasons": ["specialist 85%"], "conflicting_evidence_ids": []}},
        {"target_column": "B", "status": "draft", "confidence": 0.5, "source_columns": ["DB.S.T.B"],
         "confidence_evidence": {"reasons": ["specialist 70%"], "conflicting_evidence_ids": []}},
        {"target_column": "C", "status": "draft", "confidence": 0.4, "source_columns": ["DB.S.T.C"],
         "confidence_evidence": {"reasons": ["earlier evidence maps it from T.X instead"],
                                 "conflicting_evidence_ids": ["sttm_precedent:1"]}},
        {"target_column": "D", "status": "unresolved", "confidence": 0.0, "source_columns": []},
    ]
    reviews = [{"category": "mapping_candidate_review", "blocking": row["status"] == "unresolved",
                "safe_summary": row["target_column"], "details": {"target_column": row["target_column"]}} for row in rows]
    result = WorkbenchWorkflowHandlers._batch_uncorroborated_reviews(reviews, rows, "DB.T.HOUSEHOLD")
    singles = [item["details"].get("target_column") for item in result if item["details"].get("target_column")]
    assert singles == ["C", "D"]
    batch = next(item for item in result if item["details"].get("target_columns"))
    assert batch["details"]["target_columns"] == ["B", "A"] and batch["blocking"] is False
    assert "T.B" in batch["safe_summary"] and "HOUSEHOLD" in batch["safe_summary"]
