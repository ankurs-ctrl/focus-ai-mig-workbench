'use client';

import { useEffect, useId, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { AiaBox, AiaButton, AiaCollapse, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useSttmBuilderContext } from '../context/sttm-builder-context';
import type { MappingState } from '../types/sttm.types';
import type { AutoMapCandidate, AutoMapSuggestion } from '@/types/api-contract';
import { MAPPING_TABLE_BODY_TEXT_SX } from './mapping-table-styles';
import { aiUndoSnapshot } from './sheet-candidates';
import { alternativeCandidates, currentCandidate, previousMappingCandidate, relevantWarnings, guidanceForRow, plainValidationMessage, reviewCatalog, type ReviewCatalog } from './mapping-review-model';
import { JOIN_REVIEW_KEY, knownReviewSources, mappingBase, type JoinReviewIntent } from './review-navigation';

const MONO = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';
const textSx = {...MAPPING_TABLE_BODY_TEXT_SX, overflowWrap: 'anywhere' as const};
function Exact({text, catalog}: {text: string; catalog: ReviewCatalog}) {
  return <AiaTooltip title={catalog.reference(text)?.title || text} arrow><AiaBox component="code" sx={{fontFamily: MONO, overflowWrap:'anywhere', whiteSpace:'pre-wrap'}}>{catalog.display(text)}</AiaBox></AiaTooltip>;
}
function ReviewText({text,catalog}:{text:string;catalog:ReviewCatalog}) {
  const friendly=catalog.display(text);
  return <>{friendly.split(/(`[^`]+`|\$[A-Za-z_][\w$]*|\b\d+(?:\.\d+)?%|(?:"[^"]+"|[A-Z_][A-Z0-9_$]*)(?:\s+\([^)]*\))?(?:\.(?:"[^"]+"|[A-Z_][A-Z0-9_$]*))+)/g).map((part,index)=> /^\d+(?:\.\d+)?%$/.test(part)
    ? <strong key={index}>{part}</strong> : /^`[^`]+`$|^\$[A-Za-z_][\w$]*$|^(?:"[^"]+"|[A-Z_][A-Z0-9_$]*)(?:\s+\([^)]*\))?(?:\.(?:"[^"]+"|[A-Z_][A-Z0-9_$]*))+$/.test(part)
      ? <AiaBox key={index} component="code" sx={{fontFamily:MONO}}>{part.replace(/^`|`$/g,'')}</AiaBox> : part)}</>;
}
function Bullets({items,catalog}:{items:string[];catalog:ReviewCatalog}) {
  const unique=Array.from(new Set(items.map(item=>item.trim()).filter(Boolean)));
  if(!unique.length)return null;
  return <AiaBox component="ul" sx={{m:0,pl:2}}>{unique.map((text,index)=><AiaBox component="li" key={index} sx={textSx}><ReviewText text={text} catalog={catalog}/></AiaBox>)}</AiaBox>;
}
function Details({option,catalog}:{option:AutoMapCandidate;catalog:ReviewCatalog}) {
  const reasons=(option.confidence_reason||option.preprocessing_nl_rule||'').split(/\r?\n|(?<=[.!?])\s+(?=[A-Z])/).filter(Boolean);
  const limitations=Array.from(new Set([...(option.warnings??[]),...(option.validation_errors??[]).map(plainValidationMessage)]));
  return <AiaBox sx={{display:'grid',gap:.5,minWidth:0}}>
    <AiaText sx={textSx}><strong>{option.mapping_mode==='attribute'||option.mapping_mode==='constant'?'Value:':'Source:'}</strong>{' '}
      {option.mapping_mode==='attribute'?<Exact text={`$${option.attribute_name||''}`} catalog={catalog}/>:option.mapping_mode==='constant'?<AiaBox component="code" sx={{fontFamily:MONO}}>{option.constant_value??'Unavailable'}</AiaBox>
        :option.source_attributes.map((ref,index)=><span key={index}>{index?', ':''}<Exact text={ref} catalog={catalog}/></span>)}</AiaText>
    <AiaText sx={textSx}><strong>Mapping:</strong> {option.origin==='manual'?'Manual mapping · ':''}{option.mapping_mode==='attribute'?'Firm Value':option.mapping_mode==='constant'?'Constant':option.preprocessing_rule_type||'Direct'}</AiaText>
    <AiaText sx={textSx}><strong>Confidence: {option.confidence_score==null?'not available':`${Math.round(option.confidence_score*100)}%`}</strong></AiaText>
    {option.preprocessing_rule?<AiaText sx={textSx}><strong>Transformation:</strong>{' '}<Exact text={option.preprocessing_rule} catalog={catalog}/></AiaText>:null}
    <AiaText sx={textSx}><strong>Why suggested</strong></AiaText>
    {reasons.length?<Bullets items={reasons.slice(0,3)} catalog={catalog}/>:<AiaText sx={textSx}>{option.origin==='manual'?'Original manually authored definition; no AI explanation was recorded.':'No explanation was supplied.'}</AiaText>}
    {limitations.length?<><AiaText sx={textSx}><strong>Considerations</strong></AiaText><Bullets items={limitations} catalog={catalog}/></>:null}
    {option.source_dependencies?.length?<AiaText sx={textSx}><strong>Dependencies:</strong>{' '}{option.source_dependencies.map((ref,index)=><span key={index}>{index?', ':''}<Exact text={ref} catalog={catalog}/></span>)}</AiaText>:null}
    {(option.validation_errors?.length||reasons.length>3)?<AiaBox component="details" sx={textSx}><summary>Technical details</summary><Bullets items={[...(option.validation_errors??[]),...reasons.slice(3)]} catalog={catalog}/></AiaBox>:null}
  </AiaBox>;
}

/** All review controls belong beneath the selected source, within that cell. */
export function MappingRowCandidates({row}:{row:MappingState}) {
  const context=useSttmBuilderContext();
  const {selectSheetCandidate,undoSheetSuggestion,updateMapping,mappingLoading,sources,derivedSources,activeProjectId,activeSttmId,fullData,selectJoinReviewSources,runAutoMap}=context;
  const router=useRouter();const search=useSearchParams();const id=useId();
  const [section,setSection]=useState<'candidates'|'suggestions'|null>(null);
  const [currentOpen,setCurrentOpen]=useState(false);const [busy,setBusy]=useState(false);const [error,setError]=useState<string|null>(null);
  const catalog=useMemo(()=>reviewCatalog(sources,derivedSources),[sources,derivedSources]);
  const alternatives=alternativeCandidates(row,catalog);const current=currentCandidate(row,catalog);const manualCurrent=!current&&row.status==='MAPPED'?previousMappingCandidate(row):null;const suggestions=guidanceForRow(row);
  useEffect(()=>{
    const focus=(event?:Event)=>{const detail=(event as CustomEvent)?.detail;const mappingId=detail?.mappingId??search.get('reviewRow');
      if(mappingId===row.id)setSection((detail?.section??search.get('reviewSection'))==='suggestions'?'suggestions':'candidates');};
    focus();window.addEventListener('sttm:review-row',focus);return()=>window.removeEventListener('sttm:review-row',focus);
  },[row.id,search]);
  if(!row.aiCandidates?.length&&!suggestions.length&&!row.aiReviewStatus)return null;
  const disabled=busy||mappingLoading;
  const clean=(option:AutoMapCandidate)=>({...option,warnings:relevantWarnings(row,option.warnings??[],context.mappings.map(item=>item.targetColumn))});
  const act=async(candidateId:string,confirm=false,validateOnly=false)=>{setBusy(true);setError(null);
    try{await selectSheetCandidate(row.id,candidateId,confirm,validateOnly);}catch(cause){setError(cause&&typeof cause==='object'&&'message'in cause?String(cause.message):'Unable to validate this mapping.');}finally{setBusy(false);}};
  const joinReview=(suggestion:AutoMapSuggestion)=>{
    const base=mappingBase(activeSttmId,window.location.pathname);
    const intent:JoinReviewIntent={id:`${row.id}:${suggestion.suggestion_id}`,projectId:activeProjectId,sttmId:activeSttmId,
      mappingId:row.id,targetColumn:row.targetColumn,purpose:suggestion.message,base,recommendation:suggestion.join_recommendation??{},status:'pending'};
    try{
      const known=[...sources,...(fullData?.sources??[]).flatMap(db=>db.schemas.flatMap(schema=>schema.tables))];
      const selected=knownReviewSources(intent,known);
      const resolve=(id?:string|null)=>selected.find(source=>source.tableId===id)?.tableId
        ?? (selected.filter(source=>source.qualifiedName===id).length===1?selected.find(source=>source.qualifiedName===id)?.tableId:undefined)
        ?? derivedSources.find(source=>source.id===id&&source.isSelected)?.id;
      intent.recommendation={...intent.recommendation,left_relation_id:resolve(intent.recommendation.left_relation_id),right_relation_id:resolve(intent.recommendation.right_relation_id)};
      window.sessionStorage.setItem(JOIN_REVIEW_KEY,JSON.stringify(intent));
      selectJoinReviewSources(selected.map(source=>source.tableId));
      router.push(`${base}?joinReview=1`);
    }catch{setError('Unable to open the join review. Your current mapping has been preserved.');}
  };
  const currentNeedsValidation=current&&current.validation_status!=='valid';
  return <AiaBox id={`review-${row.id}`} sx={{...textSx,width:'100%',minWidth:0,mt:.5,display:'grid',gap:.5}}>
    <AiaText sx={textSx}><strong>{currentNeedsValidation?'Current mapping requires revalidation':row.aiReviewStatus==='unreviewed'?'AI suggested — not reviewed':row.aiReviewStatus==='confirmed'?'User confirmed':row.aiReviewStatus==='edited'?'Manually edited — draft':row.status==='MAPPED'?'Existing mapping preserved':'Unresolved — review suggestions'}</strong></AiaText>
    {(current||manualCurrent||(row.status==='MAPPED'&&row.confidenceReason))?<AiaBox>
      <AiaButton size="small" variant="text" onClick={()=>setCurrentOpen(!currentOpen)} aria-expanded={currentOpen} sx={{fontFamily:'inherit',textTransform:'none',p:.25}}>Confidence and reasoning{row.confidenceScore==null?'':` · ${Math.round(row.confidenceScore*100)}%`}</AiaButton>
      <AiaCollapse in={currentOpen}>{current?<Details option={clean(current)} catalog={catalog}/>:manualCurrent?<Details option={clean(manualCurrent)} catalog={catalog}/>:<Bullets items={[row.confidenceReason||'Confidence not available']} catalog={catalog}/>}</AiaCollapse>
    </AiaBox>:null}
    <AiaBox sx={{display:'flex',gap:.5,flexWrap:'wrap'}}>
      {alternatives.length?<AiaButton size="small" variant="text" aria-expanded={section==='candidates'} aria-controls={`${id}-candidates`} onClick={()=>setSection(section==='candidates'?null:'candidates')} sx={{fontFamily:'inherit',textTransform:'none',p:.25}}>View candidates ({alternatives.length})</AiaButton>:null}
      {suggestions.length?<AiaButton size="small" variant="text" aria-expanded={section==='suggestions'} aria-controls={`${id}-suggestions`} onClick={()=>setSection(section==='suggestions'?null:'suggestions')} sx={{fontFamily:'inherit',textTransform:'none',p:.25}}>Suggestions ({suggestions.length})</AiaButton>:null}
      {currentNeedsValidation?<AiaButton size="small" disabled={disabled} onClick={()=>void act(current.candidate_id,false,true)} sx={{fontFamily:'inherit',textTransform:'none'}}>Revalidate current mapping</AiaButton>:current&&row.aiReviewStatus==='unreviewed'?<AiaButton size="small" disabled={disabled} onClick={()=>void act(current.candidate_id,true)} sx={{fontFamily:'inherit',textTransform:'none'}}>Confirm mapping</AiaButton>:null}
      {row.aiUndoSnapshot?<AiaButton size="small" disabled={disabled} onClick={()=>undoSheetSuggestion(row.id)} sx={{fontFamily:'inherit',textTransform:'none'}}>Undo AI change</AiaButton>:null}
      {row.selectedAiCandidateId?<AiaButton size="small" disabled={disabled} onClick={()=>updateMapping(row.id,{aiUndoSnapshot:aiUndoSnapshot(row),sourceColumn:null,sourceColumns:[],mappingMode:'source',constantValue:null,attributeName:null,expression:null,rule:'Direct',sourceDependencies:[],valueBindingIds:[],status:'UNMAPPED',selectedAiCandidateId:null,transformationClassification:'unresolved'})} sx={{fontFamily:'inherit',textTransform:'none'}}>Clear suggestion</AiaButton>:null}
      {search.get('joinReviewed')==='1'&&search.get('reviewRow')===row.id?<AiaButton size="small" disabled={disabled||context.autoMapBlockedByManualEdits} onClick={()=>runAutoMap({action:'complete',mappingIds:[row.id]})} sx={{fontFamily:'inherit',textTransform:'none'}}>Reevaluate this mapping</AiaButton>:null}
    </AiaBox>
    {context.autoMapBlockedByManualEdits&&search.get('joinReviewed')==='1'&&search.get('reviewRow')===row.id?<AiaText sx={textSx}>Save or discard pending manual edits before reevaluating this mapping.</AiaText>:null}
    {error?<AiaText role="alert" sx={{...textSx,color:'#b91c1c'}}>{error}</AiaText>:null}
    <AiaCollapse in={section==='candidates'}><AiaBox id={`${id}-candidates`} sx={{display:'grid',gap:1,minWidth:0}}>
      {alternatives.map(option=><AiaBox key={option.candidate_id} sx={{p:1,border:'1px solid #e2e8f0',borderRadius:'6px',minWidth:0,maxWidth:'100%',overflowWrap:'anywhere'}}>
        {option.previously_applied?<AiaText sx={textSx}><strong>Previously applied</strong></AiaText>:null}
        <Details option={clean(option)} catalog={catalog}/>
        {option.validation_status!=='valid'?<AiaButton size="small" disabled={disabled} onClick={()=>void act(option.candidate_id,false,true)} sx={{fontFamily:'inherit',textTransform:'none'}}>Revalidate option</AiaButton>:null}
        <AiaButton size="small" variant="outlined" disabled={disabled||option.validation_status!=='valid'} onClick={()=>void act(option.candidate_id)} sx={{fontFamily:'inherit',textTransform:'none',mt:.5}}>Use candidate</AiaButton>
      </AiaBox>)}
    </AiaBox></AiaCollapse>
    <AiaCollapse in={section==='suggestions'}><AiaBox id={`${id}-suggestions`} sx={{display:'grid',gap:1,minWidth:0}}>
      {suggestions.map(item=><AiaBox key={item.suggestion_id} sx={{p:1,border:'1px solid #e2e8f0',borderRadius:'6px'}}>
        <AiaText sx={textSx}><strong>{item.kind==='relationship'?'Suggested relationship':'Suggested next action'}</strong></AiaText>
        <Bullets items={item.message.split(/\r?\n|(?<=[.!?])\s+(?=[A-Z])/).filter(Boolean).slice(0,3)} catalog={catalog}/>
        {item.message.length>400?<AiaBox component="details" sx={textSx}><summary>More context</summary><ReviewText text={item.message} catalog={catalog}/></AiaBox>:null}
        {item.source_references?.length?<AiaText sx={textSx}>Relevant sources:{' '}{item.source_references.map((ref,index)=><span key={index}>{index?', ':''}<Exact text={ref} catalog={catalog}/></span>)}</AiaText>:null}
        {item.kind==='relationship'?<AiaButton size="small" variant="outlined" disabled={disabled} onClick={()=>joinReview(item)} sx={{fontFamily:'inherit',textTransform:'none',mt:.5}}>Review suggested join</AiaButton>:null}
      </AiaBox>)}
    </AiaBox></AiaCollapse>
  </AiaBox>;
}
