import json
from pathlib import Path
import pytest
from app.core.automap_evidence_tool import final_content, tool_hint, context_handle
from app.core.automap_scan_transport import ScanTransportError
from types import SimpleNamespace

SQL=Path(__file__).resolve().parents[5]/'infra/snowflake/automap-evidence-tool.sql'
# Execute the actual procedure implementation offline; no copied test algorithm.
namespace={}
exec(SQL.read_text().split('AS $$',1)[1].rsplit('$$',1)[0],namespace)
select=namespace['select_records']


def record(identity='fir:1',body=None):
    return {'record_id':identity,'kind':'fir','targets':['NAME'],'body':body or {'sql':"COALESCE(a.NAME, 'Unknown')"}}


def test_tool_returns_complete_atomic_records_and_defers_oversize_multibyte():
    body={'targets':['NAME'],'records':[record(),record('fir:2',{'sql':"CASE WHEN a.NAME IS NULL THEN '"+'中'*12000+"' END"})]}
    result=select(body,{'targets':['NAME']},32000,32000)
    assert result['records']==[body['records'][0]]
    assert result['status']=='deferred' and result['deferred_ids']==['fir:2']
    assert body['records'][1]['body']['sql'].endswith("' END")
    assert len(json.dumps(result,ensure_ascii=False).encode())<32000


@pytest.mark.parametrize('query',[
    {'targets':['FOREIGN']},{'targets':['NAME'],'record_ids':['foreign']},
    {'targets':['NAME'],'sql':'SELECT * FROM OTHER'}, {'targets':['NAME'],'cursor':True},
    {'targets':['NAME'],'kind':'execute_sql'}])
def test_tool_rejects_scope_or_query_forgery(query):
    with pytest.raises(ValueError):select({'targets':['NAME'],'records':[record()]},query,32000,32000)


def tool_blocks(handle='a'*32):
    return [{'type':'tool_use','tool_use':{'type':'generic','name':'ReadAutoMapEvidence','tool_use_id':'one',
        'input':{'CONTEXT_HANDLE':handle,'REQUEST_JSON':'{"targets":["NAME"]}'}}},
        {'type':'tool_result','tool_result':{'type':'generic','name':'ReadAutoMapEvidence','tool_use_id':'one',
            'status':'success','content':[{'type':'text','text':'{"mappings":"THIS IS NOT FINAL OUTPUT"}'}]}}]


def test_only_final_assistant_output_is_extracted_and_tool_json_is_not_a_mapping():
    payload={'role':'assistant','status':'completed','content':tool_blocks()+[{'type':'text','text':'{"data":{"result":{"mappings":{}}}}'}]}
    filtered=final_content(payload,'a'*32)
    assert filtered['content']==payload['content'][-1:]
    assert len(payload['content'])==3
    req=SimpleNamespace(message=json.dumps([{'role':'user','content':[tool_hint('a'*32)]}]))
    assert context_handle(req)=='a'*32


@pytest.mark.parametrize('change',['foreign_tool','foreign_context','unpaired','extra_calls'])
def test_tool_terminal_proof_rejects_foreign_or_unpaired_blocks(change):
    blocks=tool_blocks()
    if change=='foreign_tool':blocks[0]['tool_use']['name']='ExecuteSQL'
    if change=='foreign_context':blocks[0]['tool_use']['input']['CONTEXT_HANDLE']='b'*32
    if change=='unpaired':blocks=blocks[:1]
    if change=='extra_calls':blocks=blocks+blocks
    with pytest.raises(ScanTransportError):final_content({'content':blocks},'a'*32)


def test_bootstrap_and_procedure_keep_native_identity_expiry_and_call_limits():
    sql=SQL.read_text()
    for text in ['EXECUTE AS CALLER','OWNER_USER=CURRENT_USER()','OWNER_ROLE=CURRENT_ROLE()',
                 'EXPIRES_AT>CURRENT_TIMESTAMP()','CALL_COUNT<2','BEGIN TRANSACTION',"session.sql('COMMIT')"]:
        assert text in sql
    assert 'automap-evidence-tool.sql' in (SQL.parents[2]/'scripts/bootstrap_sttm_metadata_infra.py').read_text()


def test_requested_rule_scope_excludes_direct_siblings():
    from app.core.automap_evidence_tool import requested_targets
    messages=[{'role':'user','content':[{'type':'text','text':json.dumps({'data':{'attributes':[
        {'target_attribute':'DISPLAY_NAME'}]}})}]}]
    assert requested_targets(messages,('ID','DISPLAY_NAME'))==('DISPLAY_NAME',)
    messages[0]['content'][0]['text']=json.dumps({'data':{'attributes':[{'target_attribute':'FOREIGN'}]}})
    assert requested_targets(messages,('ID','DISPLAY_NAME'))==('ID','DISPLAY_NAME')


def test_installer_adds_only_named_tool_and_preserves_client_runtime():
    import yaml
    from scripts.sync_workbench_agent_specs import include_evidence_tool
    template=yaml.safe_load((SQL.parents[2]/'infra/snowflake/agents/agent_spec_source_mapping.yaml').read_text())
    original={'models':{'orchestration':'client-model'},'orchestration':{'budget':{'seconds':75}},
              'tools':[{'tool_spec':{'name':'ClientSearch','type':'cortex_search'}}],
              'tool_resources':{'ClientSearch':{'search_service':'CLIENT.DB.SEARCH'}}}
    merged=include_evidence_tool(original,template,namespace='CLIENT.META',warehouse='APP_WH')
    assert merged['models']==original['models'] and merged['orchestration']==original['orchestration']
    assert len(original['tools'])==1 and len(merged['tools'])==2
    assert merged['tool_resources']['ClientSearch']==original['tool_resources']['ClientSearch']
    assert merged['tool_resources']['ReadAutoMapEvidence']['identifier']=='CLIENT.META.SP_AUTOMAP_READ_EVIDENCE'
    assert include_evidence_tool(merged,template,namespace='CLIENT.META',warehouse='APP_WH')==merged
