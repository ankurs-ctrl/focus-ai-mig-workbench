# Auto-map confidence and custom-rule overlay

Apply `files/` to the root of the repository extracted from the original client ZIP, preserving paths. This overlay includes the prior SQL-upload, FIR and durable recovery fixes; it can also be applied over the previous remediation overlay. No deletion is required. MANIFEST.json records before/after hashes against the original supplied ZIP.

## Required deployment

1. Record existing image/config tags and drain/reconcile active Auto-map work before a version switch.
2. Rebuild and deploy the backend to both the public web backend and private Auto-map worker. Rebuild/deploy the frontend from the same source overlay. Keep the existing dependency locks.
3. Update the existing `AGT_SOURCE_MAPPING` and `AGT_TRANSFORMATION_RULE` objects from their supplied YAML specs in the correct metadata namespace. Use the existing authenticated agent deployment procedure. Run `python scripts/verify_mapping_agent_specs.py`; both specs and the manifest must match.
4. Start a NEW Auto-map job. New explicitly accepted fast-resolution jobs receive backend metadata `automap_rules_policy=rules-v2` and the existing `automap_generation_policy=draft-v3`. These are server-owned protocol markers, NOT environment variables. Stored jobs without rules-v2 retain the earlier routing/scoring protocol; do not edit persisted job JSON to add the marker.

No new environment variables, dependency upgrades, database migrations, warehouse/resource-monitor changes, or capacity increases are required. No environment/credential files are included or modified. Existing project fast-path enablement, caller permissions, worker routing, byte/character limits and durable-v2 admission must remain configured through your normal deployment process.

The agent specs now require finite numeric confidence and an evidence-based confidence reason for each output. Valid positive model confidence remains attributable and is subject to backend caps. Missing/malformed confidence, or zero inconsistent with verified support, uses a deterministic evidence estimate. Zero remains appropriate when no supported proposal exists. Confidence is an estimate, not execution approval.

Direct source mappings, constants and direct approved Firm Value assignments skip the specialist. Custom CASE, concatenation, conversions and Firm Value expressions go through it, including rules without source columns. New jobs reserve source scheduling/call capacity for rule generation within existing limits. The backend carries exact candidate identity and records per-target routes/outcomes. An unchanged completed rule can be reused; changed definitions require regeneration.

Client environment files, existing mappings, in-flight operations and business data were not deployed or repaired by preparing this package. Historical FIR reprojection remains optional: see the earlier remediation installation notes. SQL upload validation, preview and publication fixes are retained.

See VALIDATION.md and the included native test report for the actual acceptance scope and remaining limitations.
