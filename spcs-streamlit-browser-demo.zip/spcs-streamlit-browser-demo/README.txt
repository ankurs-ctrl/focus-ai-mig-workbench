SPCS Streamlit Browser Demo Bundle
==================================

This folder is self-contained. You can copy or unzip just this bundle into a client deployment machine without bringing the whole `bbi-mig-ai-workbench` repo.

Contents
--------

- `app.py`: Streamlit app
- `Dockerfile`: image build for SPCS
- `requirements.txt`: local and container Python dependencies
- `.env.example`: local rehearsal environment example
- `deploy/client.streamlit-demo.env.example`: Snow CLI deployment env example
- `deploy/import_env_file.ps1`: PowerShell helper that imports a `.env` file into the current session
- `deploy/run_local_streamlit_demo.ps1`: PowerShell helper for local rehearsal on Windows
- `deploy/bootstrap_client_spcs_tools.ps1`: installs Snow CLI into a local tools venv
- `deploy/configure_client_snow_connection.ps1`: creates or reuses the Snow CLI connection
- `deploy/prepare_spcs_prereqs.ps1`: creates schema, image repo, stage, and optional compute pool and egress integration
- `deploy/build_and_push_demo_image.ps1`: builds the Docker image and pushes it to the Snowflake registry
- `deploy/deploy_streamlit_demo_service.ps1`: renders the service spec, stages it, and creates the service
- `deploy/grant_demo_endpoint_access.ps1`: grants `browser_access` to the target role
- `deploy/run_full_streamlit_demo_deploy.ps1`: one-command Windows deploy wrapper
- `deploy/render_spcs_spec.py`: service spec renderer
- `deploy/service-specs/spcs-streamlit-browser.yaml.tmpl`: SPCS service spec template
- `deploy/local_smoke_test.py`: Snowflake connectivity check without needing Streamlit
- `deploy/spcs-streamlit-browser-demo.txt`: step-by-step deployment walkthrough

Local rehearsal
---------------

1. Copy `.env.example` to `.env`.
2. Fill in your local Snowflake credentials.
3. On macOS/Linux, run:

   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   set -a
   source .env
   set +a
   python deploy/local_smoke_test.py
   streamlit run app.py

4. On Windows PowerShell, do not use `source`. Use:

   Copy-Item .env.example .env
   .\deploy\run_local_streamlit_demo.ps1

Notes
-----

- If `SNOWFLAKE_AUTHENTICATOR=externalbrowser`, the app uses browser auth.
- If `SNOWFLAKE_AUTHENTICATOR` is blank and `SNOWFLAKE_PASSWORD` is set, the app uses password auth. This matches your existing local `.env.local` pattern.
- In deployed SPCS mode, the app ignores local user credentials and uses Snowflake ingress caller-rights auth.

Docker image
------------

Build the image you will push to the Snowflake image repository:

  docker build --platform linux/amd64 -t spcs-streamlit-browser:local .

Deployment walkthrough
----------------------

Use:

  deploy/spcs-streamlit-browser-demo.txt

That file explains the step-by-step SPCS flow: registry, compute pool, stage, spec upload, service create, endpoint grant, and endpoint lookup.

Windows PowerShell flow
-----------------------

For a client AVD or any Windows machine, the bundle now includes `.ps1` scripts for the full flow:

  copy deploy\client.streamlit-demo.env.example deploy\client.streamlit-demo.env
  .\deploy\bootstrap_client_spcs_tools.ps1
  .\deploy\configure_client_snow_connection.ps1
  .\deploy\prepare_spcs_prereqs.ps1
  .\deploy\build_and_push_demo_image.ps1
  .\deploy\deploy_streamlit_demo_service.ps1

Or run the all-in-one wrapper:

  .\deploy\run_full_streamlit_demo_deploy.ps1

What Each PowerShell Script Does
--------------------------------

- `bootstrap_client_spcs_tools.ps1`: creates a tools-only virtualenv and installs Snow CLI.
- `configure_client_snow_connection.ps1`: creates or reuses the named Snow CLI connection. In client AVD this is the `externalbrowser` login step.
- `prepare_spcs_prereqs.ps1`: creates the schema objects you want to show in the demo: schema, image repository, stage, and optionally compute pool and egress integration.
- `build_and_push_demo_image.ps1`: builds the Docker image from this bundle, logs Docker into Snowflake registry, and pushes the tagged image.
- `deploy_streamlit_demo_service.ps1`: renders the service spec, uploads it to the stage root, creates the service, and refreshes it with `ALTER SERVICE`.
- `grant_demo_endpoint_access.ps1`: grants the `browser_access` service role to an end-user role so users can open the public endpoint.
- `run_full_streamlit_demo_deploy.ps1`: runs the full sequence in one go.

What the Spec Needs and Why
---------------------------

- `image`: points Snowflake to the exact pushed image tag in the image repository.
- `env`: passes Snowflake account, host, warehouse, database, and schema so the app can connect back to Snowflake from inside SPCS.
- `resources`: gives Snowflake enough CPU and memory information to place the container in the compute pool.
- `readinessProbe`: tells Snowflake how to know the Streamlit app is healthy and ready.
- `endpoints.public: true`: creates a public Snowflake ingress endpoint, which is what you show to the client.
- `capabilities.securityContext.executeAsCaller: true`: enables caller-rights behavior so the app sees the signed-in user’s object visibility.
- `serviceRoles.browser_access`: gives you an explicit endpoint access role to grant to client-facing users.
