import sys

import pytest

from app.core.config import Settings
from app.service_main import service_commands


def test_disabled_deep_agent_keeps_api_only(monkeypatch):
    monkeypatch.setenv("APP_MODULE", "app.main:app")
    monkeypatch.setenv("PORT", "8000")
    commands = service_commands(Settings(_env_file=None, MIGRATION_AGENT_ENABLED=False))
    assert len(commands) == 1
    assert commands[0][:4] == [sys.executable, "-m", "uvicorn", "app.main:app"]


def test_enabled_deep_agent_starts_worker_and_api():
    settings = Settings(_env_file=None, APP_ENV="local", MIGRATION_AGENT_ENABLED=True,
                        MIGRATION_AGENT_TRUE_RESUME_V1=True, MIGRATION_AGENT_TOOL_GOVERNANCE_V1=True,
                        MIGRATION_AGENT_MODEL_LIGHT="test", MIGRATION_AGENT_MODEL_MEDIUM="test",
                        MIGRATION_AGENT_MODEL_HIGH="test")
    assert service_commands(settings)[1] == [sys.executable, "-m", "app.agent_worker_main"]


def test_incomplete_enabled_configuration_fails_before_accepting_jobs():
    with pytest.raises(ValueError, match="configuration is incomplete"):
        service_commands(Settings(_env_file=None, MIGRATION_AGENT_ENABLED=True))
