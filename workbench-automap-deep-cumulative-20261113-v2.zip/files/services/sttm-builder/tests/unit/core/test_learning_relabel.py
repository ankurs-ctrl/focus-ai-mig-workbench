import json

from app.core.learning_relabel import (
    plan_pattern_relabels,
    relabeled_pattern,
    relabeled_subject_key,
    summarize_plans,
)
from app.schema.fir_patterns import TargetMappingPatternV2

CONTRACTS = {
    "HOUSEHOLD": ["LEGACY_ID__C", "HOUSEHOLD_TYPE__C", "OGSTATECODE", "BILLINGCITY", "NAME", "RECORDTYPEID"],
    "BIZ_ACCOUNTS": ["LEGACY_ID__C", "TYPE", "PHONE", "BILLINGCITY", "NAME", "OGCOMPANYSTATE", "RECORDTYPEID"],
}


def _row(pattern_id, target, column, *, asset="a1", scope="client", recipe=None, sources=None):
    payload = {
        "pattern_id": pattern_id, "scope": scope, "project_id": "4",
        "target_contract": {"target_fqn": target, "target_column": column},
        "source_system_profile": {"vendor_family": None, "source_tables": sources or []},
        "source_compatibility_signature": "s",
        "mapping_recipe": recipe or {"mode": "direct", "source_dependencies": ["DB.S.CONTACTS.ID"]},
        "provenance": {"asset_id": asset, "evidence_class": "unvalidated_authored_sql"},
        "content_hash": pattern_id,
    }
    return {"PATTERN_ID": pattern_id, "TARGET_TABLE": target, "TARGET_COLUMN": column, "SCOPE": scope,
            "PATTERN_PAYLOAD": json.dumps(payload)}


def test_alias_target_and_script_column_names_move_to_fixed_target():
    plans = plan_pattern_relabels(
        [_row("p1", "FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_TARGET.EVERNEST_HH_SF_IMPORT", "xxOGStateCode")], CONTRACTS)
    plan = plans[0]
    assert plan.action == "relabel"
    assert plan.new_target == "FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD"
    assert plan.new_column == "OGSTATECODE"
    assert plan.new_scope == "source_system"


def test_blank_target_uploads_are_inferred_from_their_columns():
    rows = [_row(f"b{i}", "", column, asset="upload") for i, column in
            enumerate(["Legacy_ID__c", "Phone", "Type", "XXogCOMPANYState"])]
    plans = plan_pattern_relabels(rows, CONTRACTS)
    assert {plan.new_target for plan in plans} == {"FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.BIZ_ACCOUNTS"}
    assert "inferred" in plans[0].reason


def test_firm_value_placeholders_become_target_standard_and_projects_stay_project():
    plans = plan_pattern_relabels([
        _row("f1", "X.Y.BIZ_ACCOUNTS", "RecordTypeId", recipe={"mode": "value", "placeholder": "$BizAcctRecordType"}),
        _row("f2", "X.Y.BIZ_ACCOUNTS", "Name", scope="project"),
    ], CONTRACTS)
    assert plans[0].new_scope == "target_standard"
    assert plans[1].new_scope == "project"


def test_unmappable_learnings_are_skipped_with_a_reason():
    plans = plan_pattern_relabels([
        _row("s1", "OTHER.DB.CTL_ABL_ACTIVITY", "SUBJECT"),
        _row("s2", "X.Y.HOUSEHOLD", "NOT_A_COLUMN"),
    ], CONTRACTS)
    assert [plan.action for plan in plans] == ["skip", "skip"]
    summary = summarize_plans(plans)
    assert summary["skip_reasons"] == {"no fixed target for this learning": 1, "column not in the fixed target": 1}


def test_relabeled_pattern_is_a_valid_new_pattern():
    row = _row("p1", "DB.SCH_EVERNEST_HH_TARGET.EVERNEST_HH_SF_IMPORT", "xxOGStateCode")
    plan = plan_pattern_relabels([row], CONTRACTS)[0]
    payload = relabeled_pattern(json.loads(row["PATTERN_PAYLOAD"]), plan)
    pattern = TargetMappingPatternV2.model_validate(payload)
    assert pattern.subject_key == "target_column:FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD.OGSTATECODE"
    assert pattern.target_contract["original_target_column"] == "xxOGStateCode"
    assert pattern.target_contract["target_role"] == "household_account"
    assert pattern.provenance["relabeled_from"] == "p1"
    assert pattern.pattern_id != "p1"


def test_subject_keys_move_to_fixed_target():
    key = "target_column:FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_TARGET.EVERNEST_HH_SF_IMPORT.RecordTypeId"
    assert relabeled_subject_key(key, CONTRACTS) == "target_column:FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD.RECORDTYPEID"
    assert relabeled_subject_key("target_column:FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD.NAME", CONTRACTS) is None
    assert relabeled_subject_key("relationship:A->B:abc", CONTRACTS) is None
