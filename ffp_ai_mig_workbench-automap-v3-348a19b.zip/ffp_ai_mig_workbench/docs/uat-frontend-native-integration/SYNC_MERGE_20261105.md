# Combined sync branch — 5 November 2026

Branch: `sync/uat-frontend-native-integration`.

This merge combines local `5d9cfbc` (including Contacts fix `31b2546`) with CodeCommit `0fe00a2` (including join connectors `3701da8`). Their common ancestor is `719fd41`. Both histories are retained in a merge commit.

| Area | Combined behavior |
| --- | --- |
| Dashboard | Team statistics, quick stats, recent mappings and status-filter links, plus local immediate cache display and background summary refresh |
| Join editor | Team AND/OR connectors and grouped predicates, retained through request construction, snapshots, SQL previews, compilation and relationship learning |
| SQL uploads | Local scoped lineage, quoted identifiers, safe recovery/retry, publication fencing, feature readiness and bootstrap integration |
| Mapping compilation | Team join connectors alongside local quoted target SQL names and existing validation |
| Session and caching | Local cookie redirect correction, role-scoped cache lifecycle and targeted autosave updates |
| Auto-map | Existing native investigation, preservation and delivery code retained |

Retention verification compared Git object bytes: all 50 files changed only locally and all 27 files changed only remotely were retained exactly from their respective parent. Eleven overlapping application files merged automatically and were reviewed for the combined behavior. No application conflict resolution or replacement with one parent's entire frontend was required.

Verification: **4,171 backend tests passed, 31 skipped** in 231.04 seconds; **28 frontend harnesses passed**; TypeScript passed with `tsc --noEmit --incremental false`. The additional frontend integration harness exercises grouped predicates, OR serialization, distinct quoted sources, quoted targets, empty-string constants and dashboard lifecycle counts together. Existing Contacts, upload recovery, cache/session, Auto-map and compiler tests remain part of verification.

The existing temporary test dependencies were incomplete. Swagger UI bundle 1.1.0 and the repository-locked SQLGlot 30.12.0 were restored in `/tmp/sync-merge-test-deps`; an official PowerShell 7.5.0 distribution was extracted to `/tmp/sync-merge-pwsh`. Earlier runs were affected by missing module files and system SQLGlot 27.7.0. The complete rerun passed with the restored dependencies. No application dependencies, lockfiles, environment files or authentication settings were changed.

No live Snowflake execution or deployment was performed. Existing deployment prerequisites remain in `SQL_UPLOAD_SESSION_CACHE_CORRECTIONS.md`, including the upload-recovery migration. The CodeCommit `UAT` branch is not part of this update.
