-- ============================================================
-- SP_FIR_READ_PENDING_RECORDS
-- Thin CRUD tool for AGT_FIR_SYSTEM: reads raw pending records.
-- The agent does ALL reasoning; this procedure just fetches data.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_READ_PENDING_RECORDS(
    "BATCH_SIZE" INTEGER DEFAULT 50,
    "PROCESSING_STAGE" VARCHAR DEFAULT 'pending'
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'read_pending_records'
EXECUTE AS OWNER
AS
$$
import json

def read_pending_records(session, batch_size: int = 50, processing_stage: str = 'pending') -> dict:
    """Read raw pending records from TBL_AGENT_FIR_360 for agent processing."""
    results = session.sql("""
        SELECT
            FIR_RECORD_ID,
            FIR_RECORD_KEY,
            FEEDBACK_ID,
            SOURCE_TYPE,
            SOURCE_EVENT_TYPE,
            USER_ID,
            SESSION_ID,
            PROJECT_ID,
            STTM_ID,
            SEMANTIC_BUNDLE_ID,
            ENTITY_TYPE,
            ENTITY_IDS,
            FEEDBACK_PAYLOAD,
            INITIAL_CONFIDENCE,
            CURRENT_CONFIDENCE,
            TARGET_AGENTS,
            CREATED_AT
        FROM __STTM_METADATA_NAMESPACE__.TBL_AGENT_FIR_360
        WHERE PROCESSING_STAGE = ?
        ORDER BY CREATED_AT ASC
        LIMIT ?
    """, [processing_stage, batch_size]).collect()

    records = []
    for row in results:
        record = {
            'fir_record_id': row['FIR_RECORD_ID'],
            'fir_record_key': row['FIR_RECORD_KEY'],
            'feedback_id': row['FEEDBACK_ID'],
            'source_type': row['SOURCE_TYPE'],
            'source_event_type': row['SOURCE_EVENT_TYPE'],
            'user_id': row['USER_ID'],
            'session_id': row['SESSION_ID'],
            'project_id': row['PROJECT_ID'],
            'sttm_id': row['STTM_ID'],
            'semantic_bundle_id': row['SEMANTIC_BUNDLE_ID'],
            'entity_type': row['ENTITY_TYPE'],
            'entity_ids': row['ENTITY_IDS'],
            'feedback_payload': json.loads(row['FEEDBACK_PAYLOAD']) if isinstance(row['FEEDBACK_PAYLOAD'], str) else row['FEEDBACK_PAYLOAD'],
            'initial_confidence': row['INITIAL_CONFIDENCE'],
            'current_confidence': row['CURRENT_CONFIDENCE'],
            'target_agents': row['TARGET_AGENTS'],
            'created_at': str(row['CREATED_AT']) if row['CREATED_AT'] else None
        }
        records.append(record)

    return {
        'status': 'success',
        'record_count': len(records),
        'processing_stage': processing_stage,
        'records': records
    }
$$;
