-- ============================================================
-- SP_FIR_GET_AGENT_RECOMMENDATIONS
-- Retrieves formatted recommendations for a specific agent and trigger.
-- Called by other agents to get FIR recommendations for learning_context.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_GET_AGENT_RECOMMENDATIONS(
    "AGENT_NAME" VARCHAR,
    "TRIGGER_TYPE" VARCHAR,
    "CONTEXT" VARIANT
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'get_recommendations'
EXECUTE AS CALLER
AS
$$
import json
from datetime import datetime
from typing import Any, List, Dict, Optional


def _extract_context_filters(context: dict) -> dict:
    """Extract filtering criteria from the provided context."""
    return {
        'project_id': context.get('project_id'),
        'table_names': context.get('table_names', []),
        'column_names': context.get('column_names', []),
        'sttm_id': context.get('sttm_id'),
        'semantic_bundle_id': context.get('semantic_bundle_id'),
        'max_results': context.get('max_results', 10),
        'min_confidence': context.get('min_confidence', 0.3),
        'include_archived': context.get('include_archived', False)
    }


def _build_query(agent_name: str, trigger_type: str, filters: dict) -> str:
    """Build the SQL query with live scoring: confidence * usage_factor * recency * ML boost."""
    base_query = """
        SELECT
            r.AGENT_RECOMMENDATION_ID,
            r.FIR_RECORD_ID,
            r.TARGET_AGENT,
            r.TRIGGER_TYPE,
            r.RECOMMENDATION_TYPE,
            r.RECOMMENDATION_PRIORITY,
            r.AGENT_PAYLOAD,
            r.APPLICABLE_PROJECTS,
            r.APPLICABLE_TABLES,
            r.APPLICABLE_COLUMNS,
            r.CONFIDENCE,
            r.USAGE_COUNT,
            r.SUCCESS_COUNT,
            r.CREATED_AT,
            LEAST(100, GREATEST(1, ROUND(
                (COALESCE(r.CONFIDENCE, 0.5) * 100)
                * (1.0 + LN(1 + COALESCE(r.SUCCESS_COUNT, 0)) / LN(1 + GREATEST(COALESCE(r.USAGE_COUNT, 0), 1)))
                * POWER(0.95, DATEDIFF('day', r.CREATED_AT, CURRENT_TIMESTAMP()) / 30.0)
                * (0.5 + 0.5 * COALESCE(m.RECOMMENDATION_HELPFULNESS_PROBABILITY, 0.5))
            ))) AS COMPUTED_SCORE
        FROM __STTM_METADATA_NAMESPACE__.TBL_FIR_AGENT_RECOMMENDATIONS r
        LEFT JOIN __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_FIR_MODEL_SCORES m
            ON r.AGENT_RECOMMENDATION_ID = m.ENTITY_ID
            AND m.ENTITY_TYPE = 'recommendation'
            AND m.SCORED_AT > DATEADD('day', -7, CURRENT_TIMESTAMP())
        WHERE r.TARGET_AGENT = '{agent_name}'
          AND r.TRIGGER_TYPE = '{trigger_type}'
          AND r.CONFIDENCE >= {min_confidence}
    """.format(
        agent_name=agent_name,
        trigger_type=trigger_type,
        min_confidence=filters['min_confidence']
    )

    if not filters['include_archived']:
        base_query += " AND r.STATUS = 'active'"

    if filters.get('table_names'):
        tables_array = "ARRAY_CONSTRUCT(" + ",".join(
            f"'{t}'" for t in filters['table_names']
        ) + ")"
        base_query += f" AND ARRAYS_OVERLAP(r.APPLICABLE_TABLES, {tables_array})"

    base_query += """
        ORDER BY COMPUTED_SCORE DESC, r.RECOMMENDATION_PRIORITY DESC, r.CREATED_AT DESC
        LIMIT {max_results}
    """.format(max_results=filters['max_results'])

    return base_query


def _filter_by_applicability(recommendations: list, filters: dict) -> list:
    """Filter recommendations based on project, table, and column applicability."""
    filtered = []

    for rec in recommendations:
        applicable_projects = rec.get('applicable_projects')
        applicable_tables = rec.get('applicable_tables')
        applicable_columns = rec.get('applicable_columns')

        project_match = True
        if applicable_projects and filters['project_id']:
            project_match = filters['project_id'] in applicable_projects

        table_match = True
        if applicable_tables and filters['table_names']:
            table_match = any(t in applicable_tables for t in filters['table_names'])

        column_match = True
        if applicable_columns and filters['column_names']:
            column_match = any(c in applicable_columns for c in filters['column_names'])

        if project_match and table_match and column_match:
            filtered.append(rec)

    return filtered


def _format_for_learning_context(recommendations: list) -> list:
    """Format recommendations for injection into agent learning_context."""
    formatted = []

    for rec in recommendations:
        payload = rec.get('agent_payload', {})
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except:
                payload = {}

        formatted.append({
            'source': 'fir_system',
            'recommendation_id': rec.get('agent_recommendation_id'),
            'type': rec.get('recommendation_type'),
            'priority': rec.get('recommendation_priority'),
            'score': rec.get('computed_score', rec.get('recommendation_priority')),
            'confidence': rec.get('confidence'),
            'payload': payload,
            'usage_stats': {
                'used': rec.get('usage_count', 0),
                'successful': rec.get('success_count', 0)
            }
        })

    return formatted


def _record_usage(session, recommendation_ids: list) -> None:
    """Record that recommendations were retrieved (for usage tracking)."""
    if not recommendation_ids:
        return

    ids_str = ','.join([f"'{rid}'" for rid in recommendation_ids])
    session.sql(f"""
        UPDATE __STTM_METADATA_NAMESPACE__.TBL_FIR_AGENT_RECOMMENDATIONS
        SET USAGE_COUNT = USAGE_COUNT + 1,
            LAST_USED_AT = CURRENT_TIMESTAMP(),
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE AGENT_RECOMMENDATION_ID IN ({ids_str})
    """).collect()


def get_recommendations(session, agent_name: str, trigger_type: str, context: Any) -> dict:
    """Main handler to get recommendations for an agent."""
    results = {
        'status': 'success',
        'agent': agent_name,
        'trigger': trigger_type,
        'recommendations': [],
        'total_found': 0,
        'total_returned': 0,
        'errors': [],
        'retrieved_at': datetime.utcnow().isoformat()
    }

    try:
        if isinstance(context, str):
            context = json.loads(context)
        elif context is None:
            context = {}

        filters = _extract_context_filters(context)

        query = _build_query(agent_name, trigger_type, filters)
        raw_results = session.sql(query).collect()

        recommendations = []
        for row in raw_results:
            rec = {
                'agent_recommendation_id': row['AGENT_RECOMMENDATION_ID'],
                'fir_record_id': row['FIR_RECORD_ID'],
                'target_agent': row['TARGET_AGENT'],
                'trigger_type': row['TRIGGER_TYPE'],
                'recommendation_type': row['RECOMMENDATION_TYPE'],
                'recommendation_priority': row['RECOMMENDATION_PRIORITY'],
                'computed_score': row['COMPUTED_SCORE'],
                'agent_payload': json.loads(row['AGENT_PAYLOAD']) if isinstance(row['AGENT_PAYLOAD'], str) else (row['AGENT_PAYLOAD'] or {}),
                'applicable_projects': json.loads(row['APPLICABLE_PROJECTS']) if isinstance(row['APPLICABLE_PROJECTS'], str) else (row['APPLICABLE_PROJECTS'] or []),
                'applicable_tables': json.loads(row['APPLICABLE_TABLES']) if isinstance(row['APPLICABLE_TABLES'], str) else (row['APPLICABLE_TABLES'] or []),
                'applicable_columns': json.loads(row['APPLICABLE_COLUMNS']) if isinstance(row['APPLICABLE_COLUMNS'], str) else (row['APPLICABLE_COLUMNS'] or []),
                'confidence': row['CONFIDENCE'],
                'usage_count': row['USAGE_COUNT'],
                'success_count': row['SUCCESS_COUNT'],
                'created_at': str(row['CREATED_AT']) if row['CREATED_AT'] else None
            }
            recommendations.append(rec)

        results['total_found'] = len(recommendations)

        filtered = _filter_by_applicability(recommendations, filters)

        formatted = _format_for_learning_context(filtered)

        _record_usage(session, [r['agent_recommendation_id'] for r in filtered])

        results['recommendations'] = formatted
        results['total_returned'] = len(formatted)

    except Exception as e:
        results['status'] = 'failed'
        results['errors'].append(str(e))

    return results
$$;


-- ============================================================
-- SP_FIR_RECORD_RECOMMENDATION_SUCCESS
-- Records that a recommendation was successfully used.
-- Called after an agent uses a recommendation and user accepts.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_RECORD_RECOMMENDATION_SUCCESS(
    "RECOMMENDATION_ID" VARCHAR
)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
BEGIN
    UPDATE __STTM_METADATA_NAMESPACE__.TBL_FIR_AGENT_RECOMMENDATIONS
    SET SUCCESS_COUNT = SUCCESS_COUNT + 1,
        UPDATED_AT = CURRENT_TIMESTAMP()
    WHERE AGENT_RECOMMENDATION_ID = :RECOMMENDATION_ID;

    RETURN OBJECT_CONSTRUCT(
        'status', 'success',
        'recommendation_id', :RECOMMENDATION_ID,
        'updated_at', CURRENT_TIMESTAMP()::STRING
    );
END;
$$;
