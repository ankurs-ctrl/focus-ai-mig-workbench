#/usr/bin/env python3
"""Render the SPCS service spec template using environment variables."""

from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path
from string import Template
from urllib.parse import urlparse
from uuid import UUID


# Non-secret runtime overrides only. Deployment destinations and credentials must
# continue to come from the operator's existing EnvFile, never this overlay.
PARALLEL_DEFAULTS = {
    "AUTOMAP_PARALLEL_CONTEXT_V1": "false",
    "AUTOMAP_PARALLEL_TEST_AGENT": "",
    "AUTOMAP_PARALLEL_PERMIT_TABLE_FQN": "",
    "AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN": "",
    "AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE": "",
    "AUTOMAP_PARALLEL_POOL_EPOCH": "",
    "AUTOMAP_PARALLEL_POOL_CAPACITY": "0",
    "AUTOMAP_PARALLEL_MAX_WORKERS": "2",
    "AUTOMAP_PARALLEL_MAX_CALLS": "32",
    "AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS": "16",
    "SNOWFLAKE_WRITE_LEASE_POOL_V1": "false",
}
PARALLEL_BOOLEAN_FIELDS = {
    "AUTOMAP_PARALLEL_CONTEXT_V1", "SNOWFLAKE_WRITE_LEASE_POOL_V1",
    "AUTOMAP_CONTEXT_RETRIEVAL_V1", "AUTO_MAP_PIPELINE_V2",
}
PARALLEL_INTEGER_BOUNDS = {
    "AUTOMAP_PARALLEL_POOL_CAPACITY": (0, 32),
    "AUTOMAP_PARALLEL_MAX_WORKERS": (1, 32),
    "AUTOMAP_PARALLEL_MAX_CALLS": (1, 64),
    "AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS": (0, 32),
    "AUTOMAP_CONTEXT_BATCH_COUNT": (3, 4),
    "AUTO_MAPPING_WORKER_MAX_CONCURRENCY": (1, 8),
    "AUTO_MAPPING_PROXY_MAX_IN_FLIGHT": (1, 8),
    "AUTO_MAPPING_PROXY_BATCH_SIZE": (1, 16),
}
PARALLEL_FIELDS = set(PARALLEL_DEFAULTS) | PARALLEL_BOOLEAN_FIELDS | set(PARALLEL_INTEGER_BOUNDS)
DEPLOYMENT_SCOPES = {
    "DEV": {
        "account_namespace": "MHSUEJT.GD01711",
        "database": "FFP_HDP_DLAB_DB_DEV",
        "schema": "SCH_STTM_METADATA",
        "role": "FFP_HDP_DLAB_DB_DEPLOY_ROLE_DEV",
    },
    "UAT": {
        "account_namespace": "MHSUEJT.FFP_HDP_SNOW_ACCOUNT_PROD",
        "database": "FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT",
        "schema": "SCH_STTM_METADATA",
        "role": "FFP_HDP_DLAB_MIG_WORKBENCH_DB_DEPLOY_ROLE_UAT",
    },
}


_OPTIONAL_TEMPLATE_DEFAULTS = {
    **PARALLEL_DEFAULTS,
    "AUTO_MAPPING_WORKER_MAX_CONCURRENCY": "5",
    "AUTO_MAPPING_PROXY_MAX_IN_FLIGHT": "5",
    "AUTO_MAPPING_PROXY_BATCH_SIZE": "16",
    "AUTO_MAP_PIPELINE_V2": "false",
    # PowerShell removes process environment variables when they are assigned an
    # empty string. Same-origin SPCS deployments intentionally leave this blank,
    # so preserve the empty value during template substitution.
    "CRM_TARGET_DATABASE": "",
    "CRM_TARGET_SCHEMA": "",
    "CRM_TARGET_TABLES": "HOUSEHOLD,BUSINESS,ALERTS,CALLS",
    "CORS_ALLOWED_ORIGINS": "",
    "SNOWFLAKE_PREPARATION_WAREHOUSE": "",
    "SNOWFLAKE_PREPARATION_STATEMENT_TIMEOUT_SECONDS": "300",
    "PERF_DIAGNOSTICS_V1": "true",
    "PREPARED_CONTEXT_CACHE_V2": "true",
    "CONTEXT_SINGLEFLIGHT_V1": "true",
    "FIR_QUERY_PRUNING_V1": "true",
    "TARGET_SCOPED_CACHE_INVALIDATION_V1": "true",
    "RELATIONSHIP_CAPABILITY_CACHE_V1": "true",
    "RELATIONSHIP_PROC_FAST_GUARDS_V1": "true",
    "LOW_CONFIDENCE_JOIN_REVIEW_V1": "true",
    "CONVERSATION_MEMORY_V2": "true",
    "SNOWFLAKE_SESSION_LEASE_POOL_V1": "false",
    "LEARNING_PARALLEL_V1": "false",
    "PREPARE_PARALLEL_V1": "false",
    "AUTOSAVE_SINGLEFLIGHT_V1": "true",
    "STTM_MAPPING_BULK_WRITE_V1": "false",
    "AUTOSAVE_POSTSAVE_ASYNC_V1": "false",
    "PREPARATION_WAREHOUSE_ROUTING_V1": "false",
    "DURABLE_STTM_ROUTE_V1": "true",
    "AGENT_STREAM_BATCHING_V1": "true",
    "AUTOMAP_CONTEXT_RETRIEVAL_V1": "true",
    "AUTOMAP_CONTEXT_BATCH_COUNT": "4",
    "AGENT_REQUEST_SCOPED_ANALYST_V1": "false",
    "AGENT_BUNDLE_VIEW_SCHEMA": "",
}


def _canonical_hosts(namespace: str) -> set[str]:
    account = namespace.lower().replace(".", "-")
    return {account + ".snowflakecomputing.com",
            account.replace("_", "-") + ".snowflakecomputing.com"}


def validate_parallel_settings(values: dict[str, str]) -> None:
    """Fail closed without including configuration values in errors."""
    for name in PARALLEL_BOOLEAN_FIELDS:
        if name in values and values[name] not in {"true", "false"}:
            raise ValueError(f"{name} must be true or false")
    for name, (minimum, maximum) in PARALLEL_INTEGER_BOUNDS.items():
        if name not in values:
            continue
        value = values[name]
        if (not isinstance(value, str) or not re.fullmatch(r"0|[1-9][0-9]*", value)
                or not minimum <= int(value) <= maximum):
            raise ValueError(f"{name} must be an integer in {minimum}..{maximum}")
    enabled = values.get("AUTOMAP_PARALLEL_CONTEXT_V1", "false") == "true"
    resource_fields = ("AUTOMAP_PARALLEL_TEST_AGENT", "AUTOMAP_PARALLEL_PERMIT_TABLE_FQN",
                       "AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN")
    identifier = r"[A-Z_][A-Z0-9_$]*"
    resources = []
    for name in resource_fields:
        value = values.get(name, "")
        if enabled or value:
            if not re.fullmatch(rf"{identifier}\.{identifier}\.{identifier}", value):
                raise ValueError(f"{name} requires an exact uppercase three-part FQN")
            expected_prefix = f"{values.get('SNOWFLAKE_DATABASE', '')}.{values.get('SNOWFLAKE_SCHEMA', '')}."
            if not value.startswith(expected_prefix):
                raise ValueError(f"{name} must match the deployment database and schema")
            resources.append(value)
    if len(resources) != len(set(resources)):
        raise ValueError("Parallel agent and tables must be distinct objects")
    namespace = values.get("AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE", "")
    if namespace or enabled:
        if not re.fullmatch(r"[A-Z0-9_]+\.[A-Z0-9_]+", namespace):
            raise ValueError("AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE requires canonical uppercase ORG.ACCOUNT")
        if values.get("SNOWFLAKE_REST_HOST") not in _canonical_hosts(namespace):
            raise ValueError("SNOWFLAKE_REST_HOST must match the canonical parallel account")
        if values.get("SNOWFLAKE_ACCOUNT") not in {namespace, namespace.replace(".", "-")}:
            raise ValueError("SNOWFLAKE_ACCOUNT must match the canonical parallel account")
    epoch = values.get("AUTOMAP_PARALLEL_POOL_EPOCH", "")
    if epoch or enabled:
        try:
            if str(UUID(epoch)) != epoch or UUID(epoch).int == 0:
                raise ValueError
        except (ValueError, AttributeError):
            raise ValueError("AUTOMAP_PARALLEL_POOL_EPOCH requires a nonzero canonical UUID") from None
    if enabled:
        if values.get("AUTOMAP_CONTEXT_RETRIEVAL_V1") != "true":
            raise ValueError("Parallel Auto-map requires AUTOMAP_CONTEXT_RETRIEVAL_V1=true")
        capacity = int(values.get("AUTOMAP_PARALLEL_POOL_CAPACITY", "0"))
        if capacity < 1 or int(values.get("AUTOMAP_PARALLEL_MAX_WORKERS", "2")) > capacity:
            raise ValueError("Parallel workers require explicit provisioned capacity, with workers <= capacity")
        if (values.get("AUTH_MODE", "custom_oauth").strip().lower() == "custom_oauth"
                and values.get("SNOWFLAKE_WRITE_LEASE_POOL_V1") != "true"):
            raise ValueError("Consumer OAuth parallel calls require explicit SNOWFLAKE_WRITE_LEASE_POOL_V1=true")


def _unique_json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON configuration key")
        result[key] = value
    return result


def load_parallel_profile(path: Path, deployment_environment: str,
                          environment: dict[str, str]) -> dict[str, str]:
    """Validate the non-secret overlay against the existing deployment profile."""
    try:
        profile = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_unique_json_object)
    except (OSError, ValueError):
        raise ValueError("Parallel profile must be readable, duplicate-free JSON") from None
    if not isinstance(profile, dict) or set(profile) != {"environment", "scope", "settings"}:
        raise ValueError("Parallel profile requires only environment, scope, and settings")
    if deployment_environment not in DEPLOYMENT_SCOPES or profile["environment"] != deployment_environment:
        raise ValueError("Parallel profile environment mismatch")
    expected = DEPLOYMENT_SCOPES[deployment_environment]
    scope = profile["scope"]
    if not isinstance(scope, dict) or set(scope) != set(expected) | {"connection"}:
        raise ValueError("Parallel profile scope requires account_namespace, database, schema, role, connection")
    for name, value in expected.items():
        if scope[name] != value:
            raise ValueError(f"Parallel profile {name} does not match the approved environment")
    if not isinstance(scope["connection"], str) or not re.fullmatch(r"[A-Za-z0-9_-]+", scope["connection"]):
        raise ValueError("Parallel profile connection must name an existing Snow CLI profile")
    for name, env_name in {"database": "SNOWFLAKE_DATABASE", "schema": "SNOWFLAKE_SCHEMA",
                           "role": "SNOWFLAKE_ROLE", "connection": "SNOWFLAKE_CONNECTION"}.items():
        if environment.get(env_name) != scope[name]:
            raise ValueError(f"{env_name} does not match the approved parallel profile")
    namespace = scope["account_namespace"]
    if environment.get("SNOWFLAKE_ACCOUNT") not in {namespace, namespace.replace(".", "-")}:
        raise ValueError("SNOWFLAKE_ACCOUNT does not match the approved environment")
    host = environment.get("SNOWFLAKE_REST_HOST") or namespace.lower().replace(".", "-").replace("_", "-") + ".snowflakecomputing.com"
    if host not in _canonical_hosts(namespace):
        raise ValueError("SNOWFLAKE_REST_HOST must match the canonical account")
    if environment.get("SNOWFLAKE_REGISTRY_HOST", "").lower().replace("_", "-") != host.replace("_", "-").replace(".snowflakecomputing.com", ".registry.snowflakecomputing.com"):
        raise ValueError("SNOWFLAKE_REGISTRY_HOST must match the canonical account")
    if environment.get("AUTH_MODE", "custom_oauth").strip().lower() == "custom_oauth":
        for name in ("SNOWFLAKE_OAUTH_AUTHORIZE_URL", "SNOWFLAKE_OAUTH_TOKEN_URL"):
            parsed = urlparse(environment.get(name, ""))
            try:
                valid_port = parsed.port in {None, 443}
            except ValueError:
                valid_port = False
            if (parsed.scheme != "https" or parsed.hostname not in _canonical_hosts(namespace)
                    or parsed.username is not None or parsed.password is not None or not valid_port):
                raise ValueError(f"{name} must use the canonical deployment account")
    settings = profile["settings"]
    if not isinstance(settings, dict) or set(settings) - PARALLEL_FIELDS:
        raise ValueError("Parallel settings contain unsupported fields")
    overrides = dict(PARALLEL_DEFAULTS)
    for name, value in settings.items():
        if name in PARALLEL_BOOLEAN_FIELDS:
            if type(value) is not bool:
                raise ValueError(f"{name} must be a JSON boolean")
            overrides[name] = str(value).lower()
        elif name in PARALLEL_INTEGER_BOUNDS:
            if type(value) is not int:
                raise ValueError(f"{name} must be a JSON integer")
            overrides[name] = str(value)
        elif isinstance(value, str):
            overrides[name] = value
        else:
            raise ValueError(f"{name} must be a JSON string")
    if overrides["AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE"] not in {"", namespace}:
        raise ValueError("Parallel account namespace differs from the deployment profile")
    overrides["SNOWFLAKE_REST_HOST"] = host
    effective = {**_OPTIONAL_TEMPLATE_DEFAULTS, **environment, **overrides}
    validate_parallel_settings(effective)
    return overrides


def _validate_spcs_oauth_config(template_path: Path) -> None:
    if template_path.name not in {"webapp.yaml.tmpl", "sttm-builder.yaml.tmpl"}:
        return
    if os.environ.get("AUTH_MODE", "").strip().lower() != "custom_oauth":
        return

    redirect_uri = os.environ.get("SNOWFLAKE_OAUTH_REDIRECT_URI", "").strip()
    parsed = urlparse(redirect_uri)
    if parsed.scheme != "https" or parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
        raise SystemExit(
            "SNOWFLAKE_OAUTH_REDIRECT_URI for the SPCS webapp must be an HTTPS "
            "public callback URL; localhost and loopback redirects are rejected"
        )
    if os.environ.get("AUTH_SESSION_COOKIE_SECURE", "").strip().lower() != "true":
        raise SystemExit(
            "AUTH_SESSION_COOKIE_SECURE must be true for custom OAuth in SPCS"
        )


def render_template(raw_template: str, environment: dict[str, str]) -> str:
    if environment.get("COCO_SIDECAR_ENABLED", "false").strip().lower() not in {
        "1",
        "true",
        "yes",
    }:
        raw_template = re.sub(
            r"(?ms)^\s*# BEGIN COCO_SIDECAR\n.*?^\s*# END COCO_SIDECAR\n?",
            "",
            raw_template,
        )
    else:
        raw_template = raw_template.replace(
            "    # BEGIN COCO_SIDECAR\n", ""
        ).replace("    # END COCO_SIDECAR\n", "")
    template_values = dict(_OPTIONAL_TEMPLATE_DEFAULTS)
    template_values.update(environment)
    profile_path = environment.get("AUTOMAP_DEPLOY_PROFILE_FILE")
    if profile_path:
        template_values.update(load_parallel_profile(
            Path(profile_path), environment.get("AUTOMAP_DEPLOY_ENVIRONMENT", ""), environment))
    if "${AUTOMAP_PARALLEL_CONTEXT_V1}" in raw_template:
        validate_parallel_settings(template_values)
    rendered = Template(raw_template).safe_substitute(template_values)
    unresolved = sorted(
        set(re.findall(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", rendered))
    )
    if unresolved:
        raise SystemExit(
            "SPCS template contains unresolved environment variables: "
            + ", ".join(unresolved)
        )
    if environment.get("PUBLICATION_RECOVERY_ENABLED", "false").lower() == "true":
        import yaml
        role = environment.get("PUBLICATION_RECOVERY_ROLE", "")
        if not re.fullmatch(r"[A-Z_][A-Z0-9_$]*", role):
            raise ValueError("Publication recovery requires an explicit owner role")
        spec = yaml.safe_load(rendered)
        containers = spec["spec"]["containers"]
        backend = next((item for item in containers if item["name"] == "sttm-builder"), None)
        if backend is None:
            return rendered
        # Only non-secret metadata settings are shared. No caller OAuth credentials.
        allowed = {"APP_ENV", "APP_VERSION", "SNOWFLAKE_WAREHOUSE", "SNOWFLAKE_DATABASE",
                   "SNOWFLAKE_SCHEMA", "SNOWFLAKE_SEMANTIC_VIEWS_DATABASE",
                   "SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA", "SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE",
                   "SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE", "SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE",
                   "FIR_TARGET_MAPPING_PATTERNS_V2", "FIR_DURABLE_JOBS_V2"}
        containers.append({"name": "publication-recovery", "image": backend["image"],
            "command": ["/app/.venv/bin/python"],
            "args": ["-m", "app.core.publication_recovery", "--enable-owner-recovery", "--expected-role", role, "--all-projects",
                     "--interval-seconds", "30", "--max-jobs", "4"],
            "env": {key: value for key, value in backend.get("env", {}).items() if key in allowed},
            "resources": {"requests": {"cpu": "0.1", "memory": "256Mi"},
                          "limits": {"cpu": "0.5", "memory": "1Gi"}}})
        rendered = yaml.safe_dump(spec, sort_keys=False)
    return rendered


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template")
    parser.add_argument("--output")
    parser.add_argument("--validate-parallel-profile", action="store_true")
    args = parser.parse_args()

    if args.validate_parallel_profile:
        try:
            load_parallel_profile(Path(os.environ["AUTOMAP_DEPLOY_PROFILE_FILE"]),
                                  os.environ["AUTOMAP_DEPLOY_ENVIRONMENT"], dict(os.environ))
        except (KeyError, ValueError):
            raise SystemExit("Parallel profile validation failed; check scope, allowlisted settings, and explicit prerequisites") from None
        return 0
    if not args.template or not args.output:
        parser.error("--template and --output are required for rendering")
    template_path = Path(args.template)
    _validate_spcs_oauth_config(template_path)
    raw_template = template_path.read_text(encoding="utf-8")
    rendered = render_template(raw_template, dict(os.environ))
    Path(args.output).write_text(rendered, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
