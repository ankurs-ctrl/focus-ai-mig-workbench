"""Table contract reads and cheap change detection for stored contracts.

Contracts are read with ``DESC TABLE`` (the exact semantics every downstream
gate was built on). A stored contract is later confirmed without re-reading it:
``catalog_signatures`` renders each column server-side exactly as ``DESC
TABLE`` reports it and hashes the ordered list, so one
``INFORMATION_SCHEMA.COLUMNS`` query per database tells which stored contracts
are unchanged, changed or no longer visible.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any, Callable, Iterable

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
_NOT_FOUND = re.compile(r"does not exist or not authorized", re.I)


class TableContractUnavailable(LookupError):
    """The table does not exist or is not visible to the caller's role."""

    error_code = "table_not_found"


def normalize_fqn(value: Any) -> str:
    return ".".join(part.strip().strip('"').upper() for part in str(value or "").split("."))


def split_fqn(value: Any) -> tuple[str, str, str]:
    parts = [part.strip().strip('"') for part in str(value or "").split(".")]
    if len(parts) != 3 or not all(_IDENTIFIER.fullmatch(part) for part in parts):
        raise ValueError(f"Unsafe table identifier: {value}")
    return parts[0], parts[1], parts[2]


def _identifier(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def _row(row: Any) -> dict[str, Any]:
    return row.as_dict() if hasattr(row, "as_dict") else dict(row)


def describe_type(data_type: Any, length: Any = None, precision: Any = None,
                  scale: Any = None, datetime_precision: Any = None) -> str:
    """Render an INFORMATION_SCHEMA type exactly as ``DESC TABLE`` reports it.

    Mirrors ``_SIGNATURE_TYPE_SQL``; both must change together.
    """
    base = str(data_type or "").upper()
    if base == "TEXT":
        return f"VARCHAR({int(length)})" if length is not None else "VARCHAR"
    if base == "BINARY" and length is not None:
        return f"BINARY({int(length)})"
    if base == "NUMBER" and precision is not None:
        return f"NUMBER({int(precision)},{int(scale or 0)})"
    if base in {"TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "TIME"} and datetime_precision is not None:
        return f"{base}({int(datetime_precision)})"
    return base


_SIGNATURE_TYPE_SQL = """CASE DATA_TYPE
    WHEN 'TEXT' THEN COALESCE('VARCHAR(' || CHARACTER_MAXIMUM_LENGTH || ')', 'VARCHAR')
    WHEN 'BINARY' THEN COALESCE('BINARY(' || CHARACTER_MAXIMUM_LENGTH || ')', 'BINARY')
    WHEN 'NUMBER' THEN COALESCE('NUMBER(' || NUMERIC_PRECISION || ',' || COALESCE(NUMERIC_SCALE, 0) || ')', 'NUMBER')
    WHEN 'TIMESTAMP_NTZ' THEN COALESCE('TIMESTAMP_NTZ(' || DATETIME_PRECISION || ')', 'TIMESTAMP_NTZ')
    WHEN 'TIMESTAMP_LTZ' THEN COALESCE('TIMESTAMP_LTZ(' || DATETIME_PRECISION || ')', 'TIMESTAMP_LTZ')
    WHEN 'TIMESTAMP_TZ' THEN COALESCE('TIMESTAMP_TZ(' || DATETIME_PRECISION || ')', 'TIMESTAMP_TZ')
    WHEN 'TIME' THEN COALESCE('TIME(' || DATETIME_PRECISION || ')', 'TIME')
    ELSE DATA_TYPE END"""


def column_signature_text(column_contracts: Iterable[dict[str, Any]]) -> str:
    return "|".join(
        f"{item.get('name')}:{str(item.get('type') or '').upper()}:{'Y' if item.get('nullable', True) else 'N'}"
        for item in column_contracts
    )


def contract_fingerprint(contract: dict[str, Any]) -> str:
    """MD5 of the ordered column contract; equals the server-side signature."""
    text = column_signature_text(item for item in contract.get("column_contracts") or [] if isinstance(item, dict))
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def describe_table(sql: Callable[..., Any], fqn: str) -> dict[str, Any] | None:
    """``DESC TABLE`` one table; ``None`` when it does not exist or is not visible."""
    quoted = ".".join(_identifier(part) for part in split_fqn(fqn))
    try:
        rows = [_row(row) for row in sql(f"DESC TABLE {quoted}").collect()]
    except Exception as exc:
        if _NOT_FOUND.search(str(exc)):
            return None
        raise
    column_contracts = [
        {
            "name": str(row.get("name") or row.get("NAME") or ""),
            "type": str(row.get("type") or row.get("TYPE") or ""),
            "nullable": str(row.get("null?") or row.get("NULL?") or "").upper() not in {"N", "NO", "FALSE"},
            "primary_key": str(row.get("primary key") or row.get("PRIMARY KEY") or "").upper() in {"Y", "TRUE", "1"},
        }
        for row in rows
        if str(row.get("name") or row.get("NAME") or "")
    ]
    return {
        "columns": [item["name"] for item in column_contracts],
        "key_columns": [item["name"] for item in column_contracts if item["primary_key"]],
        "column_contracts": column_contracts,
    }


def read_contracts(sql: Callable[..., Any], table_fqns: Iterable[str]) -> dict[str, dict[str, Any]]:
    """Read contracts keyed by normalized FQN; invisible tables are absent."""
    contracts: dict[str, dict[str, Any]] = {}
    for fqn in dict.fromkeys(table_fqns):
        contract = describe_table(sql, fqn)
        if contract is not None:
            contracts[normalize_fqn(fqn)] = contract
    return contracts


def catalog_signatures(sql: Callable[..., Any], table_fqns: Iterable[str]) -> dict[str, str]:
    """Current column signatures for tables, one query per database.

    Tables that no longer exist or are no longer visible are absent. A name
    resolves like an unquoted identifier (upper case) or exactly as given.
    """
    by_database: dict[str, set[tuple[str, str]]] = {}
    wanted: dict[tuple[str, str, str], str] = {}
    for value in table_fqns:
        database, schema, table = split_fqn(value)
        pairs = by_database.setdefault(database.upper(), set())
        for candidate in {(schema, table), (schema.upper(), table.upper())}:
            pairs.add(candidate)
            wanted[(database.upper(), *candidate)] = normalize_fqn(value)
    signatures: dict[str, str] = {}
    for database, pairs in sorted(by_database.items()):
        ordered = sorted(pairs)
        predicate = " OR ".join("(TABLE_SCHEMA = ? AND TABLE_NAME = ?)" for _ in ordered)
        rows = sql(
            "SELECT TABLE_SCHEMA, TABLE_NAME, MD5(LISTAGG(COLUMN_NAME || ':' || "
            f"{_SIGNATURE_TYPE_SQL} || ':' || IFF(IS_NULLABLE = 'YES', 'Y', 'N'), '|') "
            "WITHIN GROUP (ORDER BY ORDINAL_POSITION)) AS SIGNATURE "
            f"FROM {_identifier(database)}.INFORMATION_SCHEMA.COLUMNS WHERE {predicate} "
            "GROUP BY TABLE_SCHEMA, TABLE_NAME",
            params=[value for pair in ordered for value in pair],
        ).collect()
        for row in rows:
            data = _row(row)
            key = wanted.get((database, str(data.get("TABLE_SCHEMA") or ""), str(data.get("TABLE_NAME") or "")))
            if key is not None:
                signatures[key] = str(data.get("SIGNATURE") or "")
    return signatures


def same_named_signatures(sql: Callable[..., Any], table_fqns: Iterable[str]) -> dict[str, dict[str, str]]:
    """Every caller-visible table sharing a name with one of ``table_fqns``, with its signature.

    Returns ``{input fqn: {visible fqn: signature}}`` (the input table itself
    included when visible), one ``INFORMATION_SCHEMA.COLUMNS`` query per
    database. Used to find another schema's copy of the same source system
    without knowing the schema names in advance.
    """
    by_database: dict[str, dict[str, list[str]]] = {}
    for value in table_fqns:
        database, _, table = split_fqn(value)
        by_database.setdefault(database.upper(), {}).setdefault(table.upper(), []).append(normalize_fqn(value))
    found: dict[str, dict[str, str]] = {}
    for database, names in sorted(by_database.items()):
        ordered = sorted(names)
        rows = sql(
            "SELECT TABLE_SCHEMA, TABLE_NAME, MD5(LISTAGG(COLUMN_NAME || ':' || "
            f"{_SIGNATURE_TYPE_SQL} || ':' || IFF(IS_NULLABLE = 'YES', 'Y', 'N'), '|') "
            "WITHIN GROUP (ORDER BY ORDINAL_POSITION)) AS SIGNATURE "
            f"FROM {_identifier(database)}.INFORMATION_SCHEMA.COLUMNS "
            f"WHERE TABLE_SCHEMA <> 'INFORMATION_SCHEMA' AND TABLE_NAME IN ({', '.join('?' for _ in ordered)}) "
            "GROUP BY TABLE_SCHEMA, TABLE_NAME",
            params=ordered,
        ).collect()
        for row in rows:
            data = _row(row)
            name = str(data.get("TABLE_NAME") or "").upper()
            visible = normalize_fqn(f"{database}.{data.get('TABLE_SCHEMA')}.{data.get('TABLE_NAME')}")
            for source in names.get(name, []):
                found.setdefault(source, {})[visible] = str(data.get("SIGNATURE") or "")
    return found
