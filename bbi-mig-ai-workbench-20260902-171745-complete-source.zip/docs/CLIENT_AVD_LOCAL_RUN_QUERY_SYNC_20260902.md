# Client AVD local run guide — SQL Query Preview sync

This release adds SQL Query Preview synchronization to the source-selection
workspace. Edited SQL can now be validated and applied back to source table
selection, CTE-derived sources, Join Definitions, filter/group/sort controls,
and the table relationship canvas. The SQL editor also offers inline catalog
completion; press `Tab` to accept the light-colour suggestion.

## Package choice

Use one of these approaches, not both:

1. Extract the single `*-complete-source.zip`; or
2. Extract all three `part1`, `part2`, and `part3` ZIP files into the same target
   directory.

The archives intentionally exclude secrets, `client.env`, `.env.local`,
`node_modules`, Python virtual environments, `.next`, and Git metadata. Existing
environment files in an AVD checkout are therefore not overwritten.

## Prerequisites on the Windows AVD

- PowerShell 5.1 or newer
- Node.js 20 or newer with `npm`
- Python 3.11 or newer
- Network access to the configured npm/Python package repositories for the
  initial dependency install
- Snowflake connectivity and the existing client-specific credentials/config

## Extract and install

Copy the release directory to the AVD, open PowerShell in that release
directory, and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\extract-and-setup.ps1 `
  -TargetDir "C:\workbench\bbi-mig-ai-workbench"
```

For an existing source tree, use that existing path as `TargetDir`. The source
files are overlaid, while the excluded environment files remain in place.

If dependencies are already installed and only source is being refreshed:

```powershell
powershell -ExecutionPolicy Bypass -File .\extract-and-setup.ps1 `
  -TargetDir "C:\workbench\bbi-mig-ai-workbench" `
  -SkipNpmInstall
```

## Preserve and verify the existing environment

Confirm these files still exist after extraction:

```text
C:\workbench\bbi-mig-ai-workbench\infra\snowflake\env\client.env
C:\workbench\bbi-mig-ai-workbench\services\sttm-builder\.env.local
```

No new environment variable is required specifically for SQL-to-UI sync.

For localhost use, `.env.local` must contain the client Snowflake settings and
one supported local authentication configuration. For the established direct
local mode, verify at least:

```dotenv
LOCAL_DEV_AUTH_ENABLED=true
SNOWFLAKE_ACCOUNT=<existing client value>
SNOWFLAKE_USER=<existing client value>
SNOWFLAKE_WAREHOUSE=<existing client value>
```

Use the existing `SNOWFLAKE_AUTHENTICATOR=externalbrowser` configuration or the
existing password/OAuth settings. Do not copy values from an example file over
working client credentials. `client.env` remains the authoritative file for
Snowflake infrastructure/SPCS deployment; `.env.local` is used by the local
backend.

## Start locally

From the extracted repository root:

```powershell
Set-Location "C:\workbench\bbi-mig-ai-workbench"
powershell -ExecutionPolicy Bypass -File .\start-ai-workbench-dev.ps1
```

The launcher reuses the existing environments, adds only missing example keys,
installs missing dependencies, and starts:

- Frontend: `http://127.0.0.1:3000`
- Backend health: `http://127.0.0.1:8000/health`
- Backend API docs: `http://127.0.0.1:8000/docs`

Press `Ctrl+C` in the launcher window to stop both processes. If a previous run
was interrupted, run `.\stop-ai-workbench-dev.ps1` before starting again.

## Manual start fallback

If the combined launcher cannot be used, open two PowerShell windows.

Backend:

```powershell
Set-Location "C:\workbench\bbi-mig-ai-workbench"
powershell -ExecutionPolicy Bypass -File .\scripts\start_sttm_backend_local.ps1
```

Frontend:

```powershell
Set-Location "C:\workbench\bbi-mig-ai-workbench\frontend"
$env:BACKEND_DEV_ORIGIN = "http://127.0.0.1:8000"
$env:NEXT_PUBLIC_APP_ENV = "local"
$env:NODE_OPTIONS = "--max-old-space-size=4096"
npm run dev
```

## Verify the new behavior

1. Open an STTM builder and select at least one source table.
2. In Query Preview, edit the SQL. Add a loaded catalog table, a CTE, a
   column-to-column join, and a `WHERE` filter.
3. Confirm inline table/schema/database completion appears in a lighter colour;
   press `Tab` to accept it.
4. Click **Sync to UI**.
5. A valid query first runs through Snowflake validation and then updates:
   source selection, CTE-derived cards, Join Definitions, filters/grouping/
   sorting, and the relationship canvas.
6. Open Join Definitions and inspect the canvas. CTE SQL remains stored on its
   derived-source record and is inlined into executable preview SQL.
7. Enter malformed SQL and click **Sync to UI**. A syntax error should be shown.
8. Enter an unknown/ambiguous table or column and sync again. A catalog or
   Snowflake semantic validation error should be shown without changing the UI.

Only SQL that passes validation is applied. If a join predicate cannot be
represented by the visual builder, the UI reports the unsupported condition
instead of silently dropping it.

## Optional verification after extraction

```powershell
Set-Location "C:\workbench\bbi-mig-ai-workbench\frontend"
npm ci
npx tsc --noEmit
npm run build

Set-Location "C:\workbench\bbi-mig-ai-workbench"
.\services\sttm-builder\.venv\Scripts\python.exe -m pytest `
  .\services\sttm-builder\tests\unit\core\test_derived_source.py -q
```

Use `MANIFEST.txt` or `MANIFEST.json` in the release directory to verify ZIP
sizes and SHA-256 checksums before and after transfer.
