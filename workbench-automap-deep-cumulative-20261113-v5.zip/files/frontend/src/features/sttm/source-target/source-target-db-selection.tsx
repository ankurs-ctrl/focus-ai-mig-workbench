"use client";
import { AiaBox, AiaButton, AiaCircularProgress, AiaCollapse, AiaIconButton, AiaSelect, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useEffect, useState } from "react";
import { listProjects, type ProjectRecord } from "@/services/projectService";
import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";
import {
  EditOutlinedIcon,
  KeyboardArrowDownRoundedIcon,
  KeyboardArrowRightRoundedIcon,
  TableChartOutlinedIcon,
} from '@/utils/icons';
import { BODY_SX, SECONDARY_TEXT_SX, TYPOGRAPHY_TOKENS } from "@/config/typography-tokens";
import { HierarchyIcon } from '@/features/sttm/shared/hierarchy-icons';

import { AiaCheckbox } from "@/components/ui/aia-checkbox";
import { getDerivedSourceCounts } from "./derived-source-counts";
import { AiaSearchbox } from "@/components/ui/aia-searchbox";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import { ResizableSidebarSections } from "@/features/sttm/layout/resizable-sidebar-sections";
import { useSidebarSlot } from "@/features/sttm/layout/sidebar-slot-context";
import { SttmSidebarCollapseFooter } from "@/features/sttm/layout/sttm-sidebar-collapse-footer";
import { SttmSidebarCollapsedRail } from "@/features/sttm/layout/sttm-sidebar-collapsed-rail";
import { SttmSidebarSectionIcon } from "@/features/sttm/layout/sttm-sidebar-icons";
import {
  sttmSidebarBodyTextMutedSx,
  sttmSidebarBodyTextSx,
  sttmSidebarChevronSx,
  sttmSidebarHierarchyIconSx,
  sttmSidebarSearchboxSx,
  sttmSidebarSearchInputSx,
  sttmSelectTablesTitleIconSx,
  sttmSelectTablesTitleSx,
} from "@/features/sttm/layout/sttm-sidebar-text-styles";
import type {
  DatabaseNode,
  DerivedSource,
  SchemaNode,
  SelectionSide,
} from "@/features/sttm/types/sttm.types";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import { AddDerivedModal } from "@/features/sttm/source-target/add-derived-modal";
import {
  writeDerivedWorkspaceDragPayload,
  writeWorkspaceDragPayload,
} from "@/features/sttm/source-target/source-workspace-dnd";
import { useDirectTableSelection } from "@/features/sttm/source-target/use-direct-table-selection";

/**
 * Full database / schema / table name on hover (Source and Target Selection). Names stay
 * on one line with an ellipsis in the sidebar; only the tooltip wraps long names.
 */
function SidebarNameTooltip({
  title,
  children,
}: {
  title: string;
  children: React.ReactElement;
}) {
  return (
    <AiaTooltip
      title={title}
      placement="right"
      arrow
      enterDelay={300}
      slotProps={{
        tooltip: {
          sx: {
            maxWidth: 360,
            fontSize: 13,
            lineHeight: 1.45,
            whiteSpace: "normal",
            overflowWrap: "anywhere",
          },
        },
      }}
    >
      {children}
    </AiaTooltip>
  );
}

// Keeps a section's search box pinned to the top of its scroll area while the list
// below it scrolls. The background hides list rows scrolling underneath.
const STICKY_SEARCH_SX = {
  position: "sticky",
  top: 0,
  zIndex: 1,
  flexShrink: 0,
  backgroundColor: "var(--color-surface)",
} as const;

function SidebarStateShell({ children }: { children: React.ReactNode }) {
  return (
    <AiaBox
      sx={{
        width: "100%",
        minWidth: 0,
        height: "100%",
        backgroundColor: "var(--color-surface)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        px: 2,
      }}
    >
      {children}
    </AiaBox>
  );
}

export default function DataSelectionPanel() {
  const {
    fullData,
    derivedSources,
    activeProjectId,
    toggleDerivedSource,
    updateDerivedSource,
    loadState,
    errorState,
    reloadInitialData,
    loadSchemas,
    selectSchema,
    addDerivedSource,
  } = useSttmBuilderContext();

  const { setCollapsed, collapsed } = useSidebarSlot();
  const [sourceSearchText, setSourceSearchText] = useState("");
  const [targetSearchText, setTargetSearchText] = useState("");
  const [derivedSearchText, setDerivedSearchText] = useState("");
  const [cteProject, setCteProject] = useState("all");
  const [cteProjects, setCteProjects] = useState<ProjectRecord[]>([]);
  useEffect(() => {
    let current = true;
    void listProjects().then((projects) => {
      if (current) setCteProjects(projects);
    }).catch(() => { /* CTEs remain browsable by project ID if names are unavailable. */ });
    return () => { current = false; };
  }, [activeProjectId]);
  const [expandedDbs, setExpandedDbs] = useState<Record<string, boolean>>({});
  const [expandedSchemas, setExpandedSchemas] = useState<Record<string, boolean>>({});
  const [editingDerivedSource, setEditingDerivedSource] = useState<DerivedSource | null>(null);
  const [duplicatingDerivedSource, setDuplicatingDerivedSource] = useState<DerivedSource | null>(null);
  const directSelection = useDirectTableSelection();
  const [addingSchemaKey, setAddingSchemaKey] = useState<string | null>(null);

  if (loadState.initial === "loading") {
    return (
      <SidebarStateShell>
        <AiaBox sx={{ textAlign: "center" }}>
          <AiaCircularProgress size={22} />
          <AiaText sx={{ ...sttmSidebarBodyTextMutedSx, mt: 1.5 }}>
            Loading databases...
          </AiaText>
        </AiaBox>
      </SidebarStateShell>
    );
  }

  if (loadState.initial === "error") {
    return (
      <SidebarStateShell>
        <AiaBox sx={{ textAlign: "center" }}>
          <AiaText sx={sttmSidebarBodyTextSx}>
            Unable to load databases
          </AiaText>

          <AiaText sx={{ ...sttmSidebarBodyTextMutedSx, mt: 0.75 }}>
            {errorState.initial || "Please try again."}
          </AiaText>

          <AiaButton
            variant="contained"
            onClick={() => {
              void reloadInitialData();
            }}
            sx={{
              mt: 2,
              height: 30,
              borderRadius: "4px",
              backgroundColor: "var(--color-primary-save)",
              border: "1px solid var(--color-primary-save)",
              color: "#ffffff",
              fontSize: "12px",
              fontWeight: 600,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "var(--color-primary-hover)",
                borderColor: "var(--color-primary-hover)",
                boxShadow: "none",
              },
            }}
          >
            Retry
          </AiaButton>
        </AiaBox>
      </SidebarStateShell>
    );
  }

  const hasDatabases =
    (fullData?.sources?.length ?? 0) > 0 || (fullData?.targets?.length ?? 0) > 0;

  if (!hasDatabases) {
    return (
      <SidebarStateShell>
        <AiaBox sx={{ textAlign: "center" }}>
          <AiaText sx={sttmSidebarBodyTextSx}>
            No databases found
          </AiaText>

          <AiaText sx={{ ...sttmSidebarBodyTextMutedSx, mt: 0.75 }}>
            There are no source or target databases available.
          </AiaText>
        </AiaBox>
      </SidebarStateShell>
    );
  }

  if (collapsed) {
    return (
      <AiaBox
        sx={{
          width: "100%",
          minWidth: 0,
          height: "100%",
          backgroundColor: "var(--color-surface)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <SttmSidebarCollapsedRail
          items={[
            { kind: "source", label: "Source Selection" },
            { kind: "target", label: "Target Selection" },
            { kind: "derived", label: "CTE Library" },
          ]}
        />
      </AiaBox>
    );
  }

  const toggleDb = async (type: SelectionSide, dbId: string) => {
    const key = `${type}:${dbId}`;
    const willExpand = !expandedDbs[key];

    setExpandedDbs((prev) => ({
      ...prev,
      [key]: willExpand,
    }));

    if (willExpand) {
      await loadSchemas(type, dbId);
    }
  };

  const matchesSearch = (value: string, searchText: string) =>
    value.toLowerCase().includes(searchText.toLowerCase());

  const schemaHasMatch = (schema: SchemaNode, query: string) =>
    matchesSearch(schema.schemaName, query) ||
    schema.tables.some((table) => matchesSearch(table.tableName, query));

  const dbHasMatch = (db: DatabaseNode, query: string) =>
    matchesSearch(db.dbName, query) ||
    db.schemas.some((schema) => schemaHasMatch(schema, query));

  const renderSchema = (
    schema: SchemaNode,
    dbId: string,
    type: SelectionSide,
    searchText: string,
    showAllTables: boolean,
  ) => {
    const tablesLoadKey = `${type}:${schema.schemaId}`;
    const isTablesLoading = loadState.tablesBySchema[tablesLoadKey] === "loading";
    const tablesError = errorState.tablesBySchema[tablesLoadKey];
    const query = searchText.trim();
    const filterTables = Boolean(query) && !showAllTables;

    const visibleTables = filterTables
      ? schema.tables.filter((table) => matchesSearch(table.tableName, query))
      : schema.tables;

    // Auto-reveal tables that matched the search, without changing the manual expand state.
    const isSchemaExpanded =
      Boolean(expandedSchemas[tablesLoadKey]) || (filterTables && visibleTables.length > 0);
    // The target holds a single table, so only source schemas offer "add all tables".
    const schemaCheck = type === "source" ? directSelection.schemaCheckState(type, schema) : "none";
    const isAddingSchema = addingSchemaKey === tablesLoadKey;

    return (
      <AiaBox key={schema.schemaId}>
        <AiaBox
          draggable={!isTablesLoading}
          onDragStart={(event) => {
            writeWorkspaceDragPayload(event.dataTransfer, {
              side: type,
              items: [{ kind: "schema", dbId, schemaId: schema.schemaId }],
            });
          }}
          onClick={() => {
            if (!isTablesLoading) {
              setExpandedSchemas((prev) => ({
                ...prev,
                [tablesLoadKey]: !prev[tablesLoadKey],
              }));

              // Always call selectSchema so the source/target panels get populated.
              // fetchTables handles caching internally — won't re-fetch if already loaded.
              void selectSchema(type, dbId, schema.schemaId);
            }
          }}
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            pl: 3,
            pr: 1,
            py: 0.5,
            borderRadius: "6px",
            cursor: isTablesLoading ? "default" : "pointer",
            backgroundColor: schema.isSelected
              ? "var(--color-surface-muted)"
              : "transparent",
            borderLeft: schema.isSelected
              ? "3px solid var(--color-primary-save)"
              : "3px solid transparent",
            "&:hover": {
              backgroundColor: isTablesLoading
                ? undefined
                : "var(--color-surface-muted)",
            },
          }}
        >
          {type === "source" ? (
            <AiaTooltip
              title={schemaCheck === "all"
                ? `Remove all ${schema.schemaName} tables from Source Tables`
                : `Add all ${schema.schemaName} tables to Source Tables`}
              placement="top"
              enterDelay={400}
            >
              <span>
                <AiaCheckbox
                  checked={schemaCheck === "all"}
                  indeterminate={schemaCheck === "some"}
                  disabled={isTablesLoading || isAddingSchema}
                  ariaLabel={schemaCheck === "all"
                    ? `Remove all tables in ${schema.schemaName} from source tables`
                    : `Add all tables in ${schema.schemaName} to source tables`}
                  checkHandler={() => {
                    setAddingSchemaKey(tablesLoadKey);
                    void directSelection.toggleSchema(dbId, schema)
                      .then(() => setExpandedSchemas((prev) => ({ ...prev, [tablesLoadKey]: true })))
                      .finally(() => setAddingSchemaKey(null));
                  }}
                  uncheckedColor="var(--color-muted)"
                  checkedColor="var(--color-primary-save)"
                  sx={{ p: 0.25, "& .MuiSvgIcon-root": { fontSize: 18 } }}
                />
              </span>
            </AiaTooltip>
          ) : null}
          <HierarchyIcon
            level="schema"
            sx={{
              ...sttmSidebarHierarchyIconSx,
              color: schema.isSelected
                ? "var(--color-primary-save)"
                : "var(--color-muted)",
            }}
          />

          <SidebarNameTooltip title={schema.schemaName}>
          <AiaText
            sx={{
              ...sttmSidebarBodyTextSx,
              flex: 1,
              fontWeight: 400,
              color: schema.isSelected
                ? "var(--color-primary-save)"
                : "var(--color-text)",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {schema.schemaName}
          </AiaText>
          </SidebarNameTooltip>

          {isTablesLoading || isAddingSchema ? (
            <AiaCircularProgress size={18} />
          ) : isSchemaExpanded ? (
            <KeyboardArrowDownRoundedIcon sx={sttmSidebarChevronSx} />
          ) : (
            <KeyboardArrowRightRoundedIcon sx={sttmSidebarChevronSx} />
          )}
        </AiaBox>

        {tablesError ? (
          <AiaText
            sx={{
              ...sttmSidebarBodyTextSx,
              pl: 5,
              pr: 1,
              pb: 0.5,
              color: "var(--color-danger, #d32f2f)",
            }}
          >
            {tablesError}
          </AiaText>
        ) : null}

        <AiaCollapse in={isSchemaExpanded} timeout="auto" unmountOnExit>
          <AiaBox sx={{ mt: 0.2 }}>
            {isTablesLoading ? (
              <AiaBox
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  pl: 5,
                  py: 0.6,
                }}
              >
                <AiaCircularProgress size={18} />
                <AiaText sx={sttmSidebarBodyTextMutedSx}>
                  Loading tables...
                </AiaText>
              </AiaBox>
            ) : visibleTables.length ? (
              visibleTables.map((table) => {
                const inWorkspace = directSelection.isSelected(type, table);
                const actionLabel = type === "source"
                  ? inWorkspace ? `Remove ${table.tableName} from source tables` : `Add ${table.tableName} to source tables`
                  : inWorkspace ? `Clear ${table.tableName} as the target table` : `Set ${table.tableName} as the target table`;
                return (
                <AiaBox
                  key={table.tableId}
                  draggable
                  onDragStart={(event) => {
                    writeWorkspaceDragPayload(event.dataTransfer, {
                      side: type,
                      items: [{ kind: "table", tableId: table.tableId }],
                    });
                  }}
                  // Clicking the row is the same as ticking its checkbox; dragging still works.
                  onClick={() => directSelection.toggleTable(type, table)}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 0.75,
                    pl: 4,
                    pr: 1,
                    py: 0.2,
                    borderRadius: "6px",
                    color: "var(--color-text)",
                    cursor: "pointer",
                    backgroundColor: inWorkspace ? "var(--color-surface-muted)" : "transparent",
                    "&:hover": { backgroundColor: "var(--color-surface-muted)" },
                    "&:active": { cursor: "grabbing" },
                  }}
                >
                  <AiaCheckbox
                    checked={inWorkspace}
                    ariaLabel={actionLabel}
                    checkHandler={() => directSelection.toggleTable(type, table)}
                    uncheckedColor="var(--color-muted)"
                    checkedColor="var(--color-primary-save)"
                    sx={{ p: 0.25, "& .MuiSvgIcon-root": { fontSize: 18 } }}
                  />
                  <HierarchyIcon level="table" sx={sttmSidebarHierarchyIconSx} />
                  <SidebarNameTooltip title={table.tableName}>
                  <AiaText
                    sx={{
                      ...sttmSidebarBodyTextSx,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {table.tableName}
                  </AiaText>
                  </SidebarNameTooltip>
                </AiaBox>
                );
              })
            ) : (
              <AiaText
                sx={{
                  ...sttmSidebarBodyTextMutedSx,
                  pl: 5,
                  pr: 1,
                  py: 0.5,
                }}
              >
                No tables found
              </AiaText>
            )}
          </AiaBox>
        </AiaCollapse>
      </AiaBox>
    );
  };

  const renderDatabaseSectionContent = (
    items: DatabaseNode[],
    type: SelectionSide,
    searchText: string,
  ) => {
    const query = searchText.trim();

    return (
    <AiaBox sx={{ py: 0.5 }}>
      {items.filter((db) => !query || dbHasMatch(db, query)).map((db) => {
        const expandKey = `${type}:${db.dbId}`;
        const dbNameHit = Boolean(query) && matchesSearch(db.dbName, query);
        const filterSchemas = Boolean(query) && !dbNameHit;
        const visibleSchemas = filterSchemas
          ? db.schemas.filter((schema) => schemaHasMatch(schema, query))
          : db.schemas;
        // Auto-reveal schemas that matched the search, without changing the manual expand state.
        const isDbExpanded =
          Boolean(expandedDbs[expandKey]) || (filterSchemas && visibleSchemas.length > 0);
        const isSchemasLoading = loadState.schemasByDb[expandKey] === "loading";
        const schemasError = errorState.schemasByDb[expandKey];

        return (
          <AiaBox key={db.dbId} sx={{ mb: 0.4 }}>
            <AiaBox
              draggable={!isSchemasLoading}
              onDragStart={(event) => {
                writeWorkspaceDragPayload(event.dataTransfer, {
                  side: type,
                  items: [{ kind: "database", dbId: db.dbId }],
                });
              }}
              onClick={() => {
                if (!isSchemasLoading) {
                  void toggleDb(type, db.dbId);
                }
              }}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                px: 1,
                py: 0.6,
                borderRadius: "6px",
                cursor: isSchemasLoading ? "default" : "grab",
                backgroundColor: db.isSelected
                  ? "var(--color-surface-muted)"
                  : "transparent",
                "&:hover": {
                  backgroundColor: isSchemasLoading
                    ? undefined
                    : "var(--color-surface-muted)",
                },
              }}
            >
              {isDbExpanded ? (
                <KeyboardArrowDownRoundedIcon sx={sttmSidebarChevronSx} />
              ) : (
                <KeyboardArrowRightRoundedIcon sx={sttmSidebarChevronSx} />
              )}

              <HierarchyIcon
                level="database"
                sx={{
                  ...sttmSidebarHierarchyIconSx,
                  color: db.isSelected
                    ? "var(--color-primary-save)"
                    : "var(--color-text)",
                }}
              />

              <SidebarNameTooltip title={db.dbName}>
              <AiaText
                sx={{
                  ...sttmSidebarBodyTextSx,
                  flex: 1,
                  fontWeight: 400,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                {db.dbName}
              </AiaText>
              </SidebarNameTooltip>

              {isSchemasLoading ? <AiaCircularProgress size={18} /> : null}
            </AiaBox>

            <AiaCollapse in={isDbExpanded} timeout="auto" unmountOnExit>
              <AiaBox sx={{ mt: 0.2 }}>
                {isSchemasLoading ? (
                  <AiaBox
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                      pl: 3,
                      py: 0.75,
                    }}
                  >
                    <AiaCircularProgress size={18} />
                    <AiaText sx={sttmSidebarBodyTextMutedSx}>
                      Loading schemas...
                    </AiaText>
                  </AiaBox>
                ) : schemasError ? (
                  <AiaBox sx={{ pl: 3, pr: 1, py: 0.5 }}>
                    <AiaText
                      sx={{
                        ...sttmSidebarBodyTextSx,
                        color: "var(--color-danger, #d32f2f)",
                      }}
                    >
                      {schemasError}
                    </AiaText>

                    <AiaButton
                      variant="text"
                      onClick={() => {
                        void loadSchemas(type, db.dbId);
                      }}
                      sx={{
                        mt: 0.25,
                        px: 0,
                        minWidth: "auto",
                        ...sttmSidebarBodyTextSx,
                        textTransform: "none",
                        color: "var(--color-primary-save)",
                      }}
                    >
                      Retry
                    </AiaButton>
                  </AiaBox>
                ) : (
                  visibleSchemas.map((schema) =>
                    renderSchema(
                      schema,
                      db.dbId,
                      type,
                      searchText,
                      !query || dbNameHit || matchesSearch(schema.schemaName, query),
                    ),
                  )
                )}
              </AiaBox>
            </AiaCollapse>
          </AiaBox>
        );
      })}
    </AiaBox>
    );
  };

  const visibleDerivedSources = derivedSources.filter((source) => {
    if (cteProject !== "all" && (source.projectId || "shared") !== cteProject) return false;
    if (!derivedSearchText.trim()) {
      return true;
    }
    return (
      matchesSearch(source.sourceName, derivedSearchText) ||
      matchesSearch(source.purpose ?? "", derivedSearchText)
    );
  });

  const renderDerivedSourcesContent = () => (
    <AiaBox sx={{ py: 0.5, px: 0.5, width: "100%", minWidth: 0, boxSizing: "border-box" }}>
      <AiaBox sx={{ ...STICKY_SEARCH_SX, px: 1, pb: 1 }}>
        <AiaSelect
          label="Project"
          value={cteProject}
          onChange={(value) => setCteProject(String(value))}
          fullWidth
          size="small"
          options={[
            { value: "all", label: "All projects" },
            { value: "shared", label: "Shared CTEs" },
            ...Array.from(new Set([
              ...cteProjects.map((project) => project.project_id),
              ...derivedSources.flatMap((source) => source.projectId ? [source.projectId] : []),
            ])).map((id) => ({
              value: id,
              label: cteProjects.find((project) => project.project_id === id)?.project_name
                ?? (id === activeProjectId ? "Current project" : id),
            })).sort((a, b) => a.label.localeCompare(b.label)),
          ]}
        />
        <AiaSearchbox
          value={derivedSearchText}
          onChange={setDerivedSearchText}
          placeholder="Search CTEs..."
          sx={{ ...sttmSidebarSearchboxSx, mt: 1 }}
          inputSx={sttmSidebarSearchInputSx}
        />
      </AiaBox>
      {derivedSources.length ? (
        <>
          <AiaText
            sx={{
              ...sttmSidebarBodyTextMutedSx,
              px: 1,
              pb: 0.75,
            }}
          >
            Drag a CTE into CTE Sources to use it.
          </AiaText>
          {visibleDerivedSources.length === 0 ? (
            <AiaText
              sx={{
                ...sttmSidebarBodyTextMutedSx,
                px: 1,
                py: 0.5,
              }}
            >
              No CTEs match this project and search.
            </AiaText>
          ) : null}
          {visibleDerivedSources.map((source) => {
            const inWorkspace = !!source.isSelected;
            const { sourceTableCount, outputColumnCount, selectedColumnCount } = getDerivedSourceCounts(source);

            return (
              <AiaBox
                key={source.id}
                draggable
                onDragStart={(event) => {
                  writeDerivedWorkspaceDragPayload(event.dataTransfer, {
                    derivedSourceIds: [source.id],
                  });
                }}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  width: "100%",
                  minWidth: 0,
                  boxSizing: "border-box",
                  px: 1,
                  py: 0.6,
                  mb: 0.5,
                  gap: 0.75,
                  borderRadius: "6px",
                  border: "1px solid",
                  borderColor: inWorkspace ? "#bbf7d0" : "#e5e7eb",
                  backgroundColor: inWorkspace ? "#f0fdf4" : "transparent",
                  cursor: "grab",
                  "&:hover": {
                    borderColor: inWorkspace ? "#86efac" : "#d1d5db",
                    backgroundColor: inWorkspace ? "#ecfdf5" : "#f8fafc",
                  },
                  "&:active": { cursor: "grabbing" },
                }}
              >
                <AiaCheckbox
                  checked={inWorkspace}
                  checkHandler={() => toggleDerivedSource(source.id)}
                  uncheckedColor="var(--aia-primary-bg-color)"
                  checkedColor="var(--aia-primary-bg-color)"
                />
                <TableChartOutlinedIcon
                  sx={{
                    ...sttmSidebarHierarchyIconSx,
                    color: "#9ca3af",
                  }}
                />

                <AiaBox sx={{ flexGrow: 1, minWidth: 0 }}>
                  <AiaText
                    sx={{
                      ...BODY_SX,
                      color: TYPOGRAPHY_TOKENS.body.color,
                      whiteSpace: "normal",
                      overflowWrap: "anywhere",
                      wordBreak: "break-word",
                    }}
                  >
                    {source.sourceName}
                  </AiaText>
                  <AiaText sx={{ ...SECONDARY_TEXT_SX, display: "block" }}>
                    {cteProjects.find((project) => project.project_id === source.projectId)?.project_name
                      ?? (source.projectId === activeProjectId ? "Current project" : source.projectId || "Shared CTE")}
                  </AiaText>
                  <AiaText sx={{ ...SECONDARY_TEXT_SX, display: "block", mt: 0 }}>
                    {sourceTableCount} source tables · {outputColumnCount || selectedColumnCount} columns
                  </AiaText>
                  {inWorkspace ? (
                    <AiaText sx={{ ...SECONDARY_TEXT_SX, display: "block", mt: 0 }}>
                      In CTE Sources
                    </AiaText>
                  ) : null}
                </AiaBox>

                <AiaIconButton
                  size="small"
                  aria-label={`Duplicate ${source.sourceName}`}
                  title="Duplicate CTE"
                  draggable={false}
                  onMouseDown={(event) => { event.stopPropagation(); event.preventDefault(); }}
                  onClick={(event) => {
                    event.stopPropagation();
                    event.preventDefault();
                    setDuplicatingDerivedSource(source);
                  }}
                  onDragStart={(event) => { event.stopPropagation(); event.preventDefault(); }}
                  sx={{ flexShrink: 0, width: 28, height: 28, color: "#64748b" }}
                >
                  <ContentCopyOutlinedIcon sx={{ fontSize: 16 }} />
                </AiaIconButton>
                <AiaIconButton
                  size="small"
                  aria-label={`Edit ${source.sourceName}`}
                  title="Edit CTE"
                  draggable={false}
                  onMouseDown={(event) => {
                    event.stopPropagation();
                    event.preventDefault();
                  }}
                  onClick={(event) => {
                    event.stopPropagation();
                    event.preventDefault();
                    if (source.projectId && source.projectId !== activeProjectId) {
                      setDuplicatingDerivedSource(source);
                    } else {
                      setEditingDerivedSource(source);
                    }
                  }}
                  onDragStart={(event) => {
                    event.stopPropagation();
                    event.preventDefault();
                  }}
                  sx={{
                    flexShrink: 0,
                    width: 28,
                    height: 28,
                    color: "#64748b",
                    "&:hover": {
                      color: "var(--color-primary-save)",
                      backgroundColor: "rgba(15, 23, 42, 0.04)",
                    },
                  }}
                >
                  <EditOutlinedIcon sx={{ fontSize: 16 }} />
                </AiaIconButton>
              </AiaBox>
            );
          })}
        </>
      ) : (
        <AiaText
          sx={{
            ...sttmSidebarBodyTextMutedSx,
            px: 1,
            py: 0.5,
          }}
        >
          No CTEs in the library yet. Create one from CTE Sources.
        </AiaText>
      )}
    </AiaBox>
  );

  const renderDatabaseSection = (
    items: DatabaseNode[],
    type: SelectionSide,
    searchText: string,
    onSearchChange: (value: string) => void,
  ) => (
    <>
      <AiaBox sx={{ ...STICKY_SEARCH_SX, px: 1.5, pb: 1 }}>
        <AiaSearchbox
          value={searchText}
          onChange={onSearchChange}
          placeholder="Search databases, schemas, tables..."
          sx={sttmSidebarSearchboxSx}
          inputSx={sttmSidebarSearchInputSx}
        />
      </AiaBox>
      {renderDatabaseSectionContent(items, type, searchText)}
    </>
  );

  return (
    <AiaBox
      sx={{
        width: "100%",
        minWidth: 0,
        height: "100%",
        backgroundColor: "var(--color-surface)",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <AiaBox sx={{ flex: 1, minHeight: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <ResizableSidebarSections
          sections={[
            {
              id: "source",
              title: "Source Selection",
              icon: <SttmSidebarSectionIcon kind="source" />,
              tourTarget: TOUR_TARGETS.sttmSourceSelection,
              content: renderDatabaseSection(
                fullData?.sources || [],
                "source",
                sourceSearchText,
                setSourceSearchText,
              ),
            },
            {
              id: "target",
              title: "Target Selection",
              icon: <SttmSidebarSectionIcon kind="target" />,
              tourTarget: TOUR_TARGETS.sttmTargetSelection,
              content: renderDatabaseSection(
                fullData?.targets || [],
                "target",
                targetSearchText,
                setTargetSearchText,
              ),
            },
            {
              id: "derived",
              title: "CTE Library",
              icon: <SttmSidebarSectionIcon kind="derived" />,
              tourTarget: TOUR_TARGETS.sttmDerivedSources,
              content: renderDerivedSourcesContent(),
            },
          ]}
          defaultExpanded={{ source: true, target: true, derived: true }}
          titleSx={sttmSelectTablesTitleSx}
          iconSx={sttmSelectTablesTitleIconSx}
        />
      </AiaBox>

      <SttmSidebarCollapseFooter
        collapsed={false}
        collapseLabel="Collapse source sidebar"
        onToggle={() => setCollapsed(true)}
      />

      <AddDerivedModal
        isOpen={editingDerivedSource !== null || duplicatingDerivedSource !== null}
        editingSource={editingDerivedSource ?? duplicatingDerivedSource}
        duplicateMode={duplicatingDerivedSource !== null}
        onClose={() => { setEditingDerivedSource(null); setDuplicatingDerivedSource(null); }}
        onConfirm={(source) => {
          if (source.id === editingDerivedSource?.id && !duplicatingDerivedSource) updateDerivedSource(source);
          else addDerivedSource(source);
          setEditingDerivedSource(null);
          setDuplicatingDerivedSource(null);
        }}
      />
    </AiaBox>
  );
}
