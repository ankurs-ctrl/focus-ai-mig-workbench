# Assistant UX, scoped discovery and draft completion — v10

V10 preserves the earlier cumulative Auto-map, Deep Agent, SQL-upload, publication, administration and PR #63 work. It is an overlay for either supplied `ffp_ai_mig_workbench (2).zip` or `(3).zip`, not a replacement environment configuration.

## Behavior

- Quick and Deep use the same scroll-intent logic. Scrolling up pauses following, keeps the beginning reachable and shows Jump to latest. Deep now wraps message content separately from its scroll viewport. The sidebar can shrink correctly.
- A closed Deep transport reconnects even if React still holds a connected flag. The project pencil opens the normal welcome/composer/Quick–Deep interface with project-scoped storage. Project history remains separate. The prior chat is saved under its original project before switching.
- Discovery tools accept optional `database` and `schema`, resolve qualified names before execution, and use parameterized bounded INFORMATION_SCHEMA queries rather than `SHOW TERSE TABLES IN ACCOUNT`. Scope is caller-visible and restricted by declared run schemas. Shared read results and failures prevent reworded searches from repeating the same timed-out scope scan. Exact lookup remains available after broad discovery fails.
- Native SQL code, SQL state, query ID and operation survive generic tool wrappers without SQL text, bindings or credentials. Progress narration receives verified succeeded/failed tool outcomes; failed discovery is not completed discovery.
- Normal rotation of an active same-user/same-role OAuth token queues the same durable checkpoint for rebuilt caller SQL/REST clients. Budgets, owner and completed receipts remain. Revocation, expiry and owner/role changes still require authentication; no service/user fallback is introduced.
- Source and transformation instructions request the strongest supported draft for every target without business questions or approval pauses. Low confidence or missing YAML alone does not suppress drafts. Missing real Values/CTEs/joins remain explicit dependencies; literals and bindings are never fabricated.
- Model-authored join recommendations prefill current table instances, columns, operators and composite AND/OR conditions for review. Current output bindings are checked; unknown columns stay incomplete. Same-table joins are reused only if the full definition matches, including custom predicates. Save applies the join; Cancel changes nothing.
- Unchanged Selection validation survives background Values loading. Actual authored dependency changes still invalidate it. Business suggestions retain model provenance; backend diagnostic fallbacks are not reintroduced as business advice.
- Auto-map status uses the requested generation target count, deduplicated target outcomes and separate source/specialist stages. Old job events cannot replace the count. The top-right block is the only Auto-map completion surface; its counts remain until dismissal or the next run. The duplicate bottom colored toast is no longer mounted.

## Deployment

1. Copy the ZIP's `files/` contents over the repository root, preserving paths. Preserve all environment files and credentials. The manifest verifies both supplied baselines and retains previous cumulative files and all 206 supplied Deep Agent files. Extra client-only files are not deleted.
2. Run the existing bootstrap only for cumulative prerequisites not already installed. **V10 adds no table, migration, environment variable, capacity increase or timeout increase.** Existing operational tables, evidence tool and Deep additive migrations remain prerequisites.
3. Run `python scripts/verify_mapping_agent_specs.py`. Deploy the updated source-mapping and transformation instructions through `scripts/sync_workbench_agent_specs.py` using your existing CLI, connection and metadata namespace. Preserve client models, budgets, authorization and tools; do not use `--allow-runtime-changes`. Use the existing documented evidence-tool deployment options if that tool is not already installed.
4. After deploying the matching instructions/tool, update the existing deployed specification-hash settings (not new variables):

```text
AGENT_SPEC_SOURCE_MAPPING_SHA256=f3266022a5153b48e6aa6f3e04712194c2f7aab94a26abb862a44879eb96a729
AGENT_SPEC_TRANSFORMATION_RULE_SHA256=7adfa5e0bb221571b9f390d3e9ac393a46808e34ba37905ac41a41b158e7294c
```

If the current deployment already injects these settings from the manifest, regenerate the service specifications rather than editing client secrets. Do not advertise the new hashes before installing the matching agent instructions.
5. Rebuild and deploy matching frontend, API, Auto-map workers and Deep Agent worker on all replicas. Preserve active-job recovery and v9 encoded artifact compatibility. No client mapping changes or failed-client-job replay are part of this release.
6. Verify project pencil → standard chat, Quick/Deep scrolling, bell → prefilled join → Save/Cancel, unchanged Selection return, and one isolated Auto-map generation. Publishing remains separate.

## Evidence and limits

Read `ASSISTANT-DRAFTS-V10-RESULTS.json`. Full backend suite: 5,828 passed, 32 skipped; subsequent focused diagnostics checks: 108 passed. Frontend: 555 passed, TypeScript passed. Baseline-(3) reconstruction also passes TypeScript with retained legacy files.

Three real prepare → durable job → private worker → native agent → frontend reducer runs returned 37 supported proposals each, positive estimated confidence, FIR citation, actual specialist submissions and correct expected SQL values. Their measured times were **222.01s, 215.01s and 207.45s**. A separate empty-YAML-registry run returned all 37 supported proposals in **201.63s**. These results do **not** pass the 200-second gate. The earlier cold-fixture execution-state failure is also retained in the report; uncertain calls were not replayed.

Read-only native scoped discovery measured **0.871s** for exact lookup, **1.541s** for schema name search and zero scans for its repeated cached query. The browser tests use synthetic long summaries only in a temporary local test server. None of their numbered sections, fixtures, debug logging or fake API responses belong to the release.

No five-replica SPCS benchmark or live client OAuth-rotation acceptance was performed. The final Quick jump click was not executed because browser approval review hit its usage limit; Deep's jump action, Quick scroll retention during growth and the project-chat presentation were observed. The full sidebar/fullscreen browser matrix remains a deployment acceptance item.
