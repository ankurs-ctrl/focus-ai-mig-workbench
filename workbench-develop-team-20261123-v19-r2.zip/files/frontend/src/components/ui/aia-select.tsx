'use client';

import React, { useEffect, useState } from 'react';
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  ListItemText,
  Checkbox,
  ListSubheader,
} from '@mui/material';
import type { SelectChangeEvent } from '@mui/material/Select';
import type { SxProps, Theme } from '@mui/material/styles';

import { AiaButton } from './aia-button';
import { AiaInput } from './aia-input';
import { AiaTooltip } from './aia-tooltip';
import { AddRoundedIcon } from '@/utils/icons';

export interface AiaSelectOption {
  label: string;
  value: string;
  /** Shown beside the option while the pointer is on it. */
  hint?: string;
}

export interface AiaSelectProps {
  label?: string;
  value?: string | string[];
  options?: AiaSelectOption[];
  onChange?: (value: string | string[]) => void;
  onOpen?: () => void;
  placeholder?: string;
  multiple?: boolean;
  disabled?: boolean;
  size?: 'small' | 'medium';
  fullWidth?: boolean;
  iconComponent?: React.ElementType;
  sx?: SxProps<Theme>;
  menuItemSx?: SxProps<Theme>;
  menuPlacement?: 'default' | 'above';
  /** Show a search field at the top of the menu. Other selects stay unchanged. */
  searchable?: boolean;
  searchPlaceholder?: string;
  noResultsMessage?: string;
  emptyMessage?: string;
  /** Keep this option visible as the primary action, outside the search results. */
  pinnedOptionValue?: string;
  /**
   * Keep the open menu the same width as the control. Long labels stay inside
   * that width, and hovering a label shows the full text.
   */
  menuMatchAnchor?: boolean;
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const HINT_PREVIEW_LENGTH = 800;

function optionHintTitle(hint: string): string {
  const text = hint.trim();
  if (!text) return 'No value';
  return text.length > HINT_PREVIEW_LENGTH ? `${text.slice(0, HINT_PREVIEW_LENGTH)}…` : text;
}

const MenuProps = {
  sx: {
    // AiaSelect is used inside custom dialogs whose overlay sits above MUI's
    // default menu z-index. Keep the portal menu above those dialogs.
    zIndex: 1600,
  },
  slotProps: {
    paper: {
      sx: {
        maxHeight: ITEM_HEIGHT * 4 + ITEM_PADDING_TOP,
      },
    },
  },
};

const AiaSelect = ({
  label = '',
  value,
  options = [],
  onChange,
  onOpen,
  placeholder = 'Select…',
  multiple = false,
  disabled = false,
  size = 'small',
  fullWidth = true,
  iconComponent,
  sx,
  menuItemSx,
  menuPlacement = 'default',
  searchable = false,
  searchPlaceholder = 'Search',
  noResultsMessage = 'No matches found',
  emptyMessage = 'No options found',
  pinnedOptionValue,
  menuMatchAnchor = false,
}: AiaSelectProps) => {
  const [search, setSearch] = useState('');
  const [anchorNode, setAnchorNode] = useState<HTMLDivElement | null>(null);
  const [anchorMenuWidth, setAnchorMenuWidth] = useState<number | null>(null);
  const enhanced = searchable || Boolean(pinnedOptionValue);
  const pinnedOption = pinnedOptionValue
    ? options.find((option) => option.value === pinnedOptionValue)
    : undefined;
  const query = search.trim().toLowerCase();
  const selectableOptions = pinnedOption
    ? options.filter((option) => option.value !== pinnedOption.value)
    : options;
  const visibleOptions = searchable && query
    ? selectableOptions.filter((option) => option.label.toLowerCase().includes(query))
    : selectableOptions;

  useEffect(() => {
    if (!menuMatchAnchor || !anchorNode) return;
    const update = () => setAnchorMenuWidth(anchorNode.offsetWidth);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(anchorNode);
    return () => observer.disconnect();
  }, [anchorNode, menuMatchAnchor]);

  const handleChange = (event: SelectChangeEvent<string | string[]>) => {
    const rawValue = event.target.value;
    onChange?.(
      multiple
        ? typeof rawValue === 'string'
          ? rawValue.split(',')
          : (rawValue as string[])
        : (rawValue as string),
    );
    if (searchable) setSearch('');
  };

  const abovePlacement = menuPlacement === 'above'
    ? {
        anchorOrigin: { vertical: 'top' as const, horizontal: 'left' as const },
        transformOrigin: { vertical: 'bottom' as const, horizontal: 'left' as const },
      }
    : {};
  const anchorMenuSx = menuMatchAnchor && anchorMenuWidth
    ? {
        width: `${anchorMenuWidth}px !important`,
        minWidth: `${anchorMenuWidth}px !important`,
        maxWidth: `${anchorMenuWidth}px !important`,
        boxSizing: 'border-box' as const,
        overflowX: 'hidden' as const,
      }
    : {};
  const menuProps = enhanced
    ? {
        ...MenuProps,
        ...abovePlacement,
        autoFocus: false,
        disableAutoFocusItem: true,
        ...(menuMatchAnchor ? { marginThreshold: 0 } : {}),
        slotProps: {
          paper: {
            sx: {
              maxHeight: 360,
              minWidth: menuMatchAnchor ? undefined : 240,
              ...anchorMenuSx,
            },
          },
        },
      }
    : {
        ...MenuProps,
        ...abovePlacement,
        ...(menuMatchAnchor ? { marginThreshold: 0 } : {}),
        slotProps: {
          paper: {
            sx: {
              maxHeight: ITEM_HEIGHT * 4 + ITEM_PADDING_TOP,
              ...anchorMenuSx,
            },
          },
        },
      };

  const renderSelectedLabel = (label: string) =>
    menuMatchAnchor ? (
      <span
        title={label}
        style={{
          display: 'block',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}
      >
        {label}
      </span>
    ) : (
      label
    );

  const select = (
    <Select
      ref={menuMatchAnchor ? setAnchorNode : undefined}
      multiple={multiple}
      value={value}
      label={label || undefined}
      onChange={handleChange}
      onOpen={() => {
        if (searchable) setSearch('');
        onOpen?.();
      }}
      onClose={() => {
        if (searchable) setSearch('');
      }}
      disabled={disabled}
      IconComponent={iconComponent}
      input={label ? <OutlinedInput label={label} size={size} /> : <OutlinedInput size={size} />}
      MenuProps={menuProps}
      displayEmpty
      sx={[
        fullWidth ? { width: '100%' } : {},
        {
          '& .MuiSelect-select': {
            paddingTop: size === 'small' ? 1 : 1.5,
            paddingBottom: size === 'small' ? 1 : 1.5,
          },
        },
        ...(sx ? (Array.isArray(sx) ? sx : [sx]) : []),
      ]}
      renderValue={(selected) =>
        multiple
          ? (selected as string[])
              .map((v) => options.find((o) => o.value === v)?.label)
              .join(', ')
          : (() => {
              const s = selected as string;
              if (!s) {
                return <span style={{ color: '#9ca3af' }}>{placeholder}</span>;
              }
              const label = options.find((o) => o.value === s)?.label;
              return label ? (
                renderSelectedLabel(label)
              ) : (
                <span style={{ color: '#9ca3af' }}>{placeholder}</span>
              );
            })()
      }
    >
      {searchable ? (
        <ListSubheader
          sx={{
            position: 'sticky',
            top: 0,
            zIndex: 2,
            bgcolor: '#fff',
            px: 1,
            py: 1,
            lineHeight: 'normal',
          }}
          onMouseDown={(event) => event.stopPropagation()}
          onKeyDown={(event) => {
            if (event.key !== 'Escape') event.stopPropagation();
          }}
        >
          <AiaInput
            value={search}
            onChange={setSearch}
            placeholder={searchPlaceholder}
            size="small"
            inputProps={{ autoFocus: true, 'aria-label': searchPlaceholder }}
          />
        </ListSubheader>
      ) : null}
      {selectableOptions.map((opt) => {
        const isSelected = multiple
          ? (value as string[] | undefined)?.includes(opt.value)
          : value === opt.value;
        const hidden = Boolean(
          searchable && query && !opt.label.toLowerCase().includes(query),
        );

        const row = (
          <>
            {multiple && <Checkbox checked={!!isSelected} size="medium" />}
            <ListItemText
              primary={menuMatchAnchor ? (
                <span
                  title={opt.label}
                  style={{
                    display: 'block',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {opt.label}
                </span>
              ) : opt.label}
              sx={menuMatchAnchor ? { minWidth: 0 } : undefined}
            />
          </>
        );

        return (
          <MenuItem
            key={opt.value}
            value={opt.value}
            sx={[
              ...(Array.isArray(menuItemSx) ? menuItemSx : menuItemSx ? [menuItemSx] : []),
              hidden ? { display: 'none' } : null,
              opt.hint !== undefined ? { px: 0, py: 0 } : null,
              menuMatchAnchor ? { minWidth: 0, overflow: 'hidden' } : null,
            ]}
          >
            {opt.hint === undefined ? row : (
              <AiaTooltip
                title={optionHintTitle(opt.hint)}
                placement="right"
                enterDelay={0}
                enterNextDelay={0}
                leaveDelay={0}
                disableInteractive
                slotProps={{
                  transition: { timeout: 0 },
                  popper: { sx: { zIndex: 1800 } },
                  tooltip: {
                    sx: {
                      maxWidth: 360,
                      whiteSpace: 'pre-wrap',
                      overflowWrap: 'anywhere',
                      fontSize: 12,
                      lineHeight: 1.45,
                    },
                  },
                }}
              >
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    width: '100%',
                    minWidth: 0,
                    padding: '6px 16px',
                  }}
                >
                  {row}
                </span>
              </AiaTooltip>
            )}
          </MenuItem>
        );
      })}
      {searchable && visibleOptions.length === 0 ? (
        <ListSubheader
          disableSticky
          sx={{
            color: '#6B7280',
            fontSize: 13,
            fontWeight: 400,
            lineHeight: '40px',
            bgcolor: 'transparent',
          }}
        >
          {query ? noResultsMessage : emptyMessage}
        </ListSubheader>
      ) : null}
      {pinnedOption ? (
        <MenuItem
          value={pinnedOption.value}
          sx={{
            position: 'sticky',
            bottom: 0,
            zIndex: 2,
            bgcolor: '#fff',
            px: 1,
            py: 1,
            borderTop: '1px solid #E5E7EB',
            '&.Mui-selected, &.Mui-selected:hover, &:hover, &.Mui-focusVisible': {
              bgcolor: '#fff',
            },
            '&:hover .MuiButton-root': {
              backgroundColor: 'var(--aia-button-hover-color)',
            },
          }}
        >
          <AiaButton
            variant="contained"
            color="primary"
            size="medium"
            fullWidth
            tabIndex={-1}
            startIcon={<AddRoundedIcon sx={{ fontSize: 18 }} />}
            sx={{ pointerEvents: 'none' }}
          >
            {pinnedOption.label}
          </AiaButton>
        </MenuItem>
      ) : null}
    </Select>
  );

  if (!label) {
    return select;
  }

  return (
    <FormControl
      sx={[{ minWidth: fullWidth ? 0 : 120 }]}
      size={size}
      fullWidth={fullWidth}
      disabled={disabled}
    >
      <InputLabel size={size}>{label}</InputLabel>
      {select}
    </FormControl>
  );
};

export { AiaSelect };
