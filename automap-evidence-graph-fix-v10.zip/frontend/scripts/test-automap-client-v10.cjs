// Real default thunk, wire request, progress/terminal reducers and acceptance.
const assert=require('node:assert/strict');
const test=require('node:test').test;
const ts=require('typescript');
const h=require('./test-automap-preservation.cjs');
const {helpers,reducer,stateFor,blank,imported,direct}=h;
const values=[{name:'FirmID',value:'current'}];
const functions={},reducers={};let acceptSource,semanticReducer;
function visit(node){
  if(ts.isFunctionDeclaration(node)&&node.name)functions[node.name.text]=node.getText(h.slice).replace(/^export\s+/,'');
  if(ts.isPropertyAssignment(node))reducers[node.name.getText(h.slice)]=node.initializer.getText(h.slice);
  if(ts.isVariableDeclaration(node)&&node.name.getText(h.slice)==='acceptPendingAiMappingReviews')acceptSource=node.initializer.arguments[1].getText(h.slice);
  ts.forEachChild(node,visit);
}visit(h.slice);semanticReducer=reducers.autoMapSemanticPrepared;
const originals=()=>[imported(),{...blank('CONST'),status:'MAPPED',mappingMode:'constant',constantValue:'',rule:'Value'},
  {...blank('ATTRIBUTE'),status:'MAPPED',mappingMode:'attribute',attributeName:'FirmID',constantValue:'$FirmID',valueBindingIds:['firm'],rule:'Value'}];
function harness({checked=[],options,advanced=true,unresolved=false,partial=true,edit,originalStatus='MAPPED'}={}){
  const authored=originals().map(row=>({...row,status:originalStatus}));
  const state={...stateFor(...authored.map(row=>structuredClone(row)),...Array.from({length:34},(_,i)=>blank('COL_'+i))),
    sources:[{qualifiedName:'D.S.SOURCE',isSelected:true}],targets:[{qualifiedName:'D.T.TARGET',isSelected:true}],
    derivedSources:[],sourceAttributeGroups:[{columns:[{name:'NewName'}]}],relationships:[],
    semanticBundleId:'bundle',semanticContextItems:[{}]};
  state.targetAttributeGroup.qualifiedName='D.T.TARGET';state.selectedMappingIds=checked;
  state.semanticDependencySignature=helpers.autoMapSourceInputs(state);
  reducer(h.pendingReducer)(state,{meta:{requestId:'run-one',arg:options}});
  const capturedRun=structuredClone(state.autoMapRun);const requests=[];let lastResponse;
  const creator=type=>payload=>({type,payload});
  const thunk=h.compile(`return (${h.thunkSource});`,{
    ...helpers,resolveSelectedSourceTables:s=>s.sources,resolveSelectedTargetTable:s=>s.targets[0],
    makeTableRef:q=>{const[database,schema,table]=q.split('.');return{database,schema,table};},
    estimateAutoMapComplexity:()=>0,autoMapBatchesInitialized:creator('initialized'),autoMapStreamStatus:creator('status'),
    autoMapSemanticPrepared:creator('semantic'),autoMapBatchStarted:creator('started'),autoMapBatchApplied:creator('applied'),
    getSelectedDerivedSourceIds:()=>[],listProjectAttributes:async()=>values,
    snapshotFromState:s=>({mapping_rows:s.mappings.map(row=>({id:row.id,target_column:row.targetColumn,
      source_columns:row.sourceColumns??(row.sourceColumn?[row.sourceColumn]:[]),expression:row.expression,
      mapping_mode:row.mappingMode,constant_value:row.constantValue,attribute_name:row.attributeName,rule:row.rule,status:row.status}))}),
    findTargetDescription:()=>null,qualifiedTableRefOrNull:()=>null,buildRelationshipPayload:()=>[],
    buildRelationGraph:()=>({}),buildSelectedColumnsByTable:()=>({}),getErrorMessage:e=>e.message,
    workbenchService:{getAutoMapCapabilities:async()=>({selected_scope:advanced,reevaluation:advanced}),
      startAutoMapJob:async req=>{
        requests.push(req);if(edit)edit(state);
        const names=req.attributes.map(a=>a.target_attribute);
        const originalNames=authored.map(row=>row.targetColumn);
        lastResponse={operation:'sttm.auto_map',warnings:[],result:{mappings:Object.fromEntries(names.map(name=>[name,
          unresolved&&originalNames.includes(name)?{source_attributes:[],confidence_score:0,transformation_classification:'unresolved',
          unmatched_reason:'Need a business decision',candidate_source_attributes:['src.Alternative'],confidence_reason:'Supported alternative needs review'}:direct]))},
          meta:{automap_preserved_targets:[],automap_baseline_preservation:{instruction:'preserve_frontend_rows',apply_preserved_mappings:false},
            automap_resolution:{mode:req.meta.auto_map_resolution_mode,targets:names.map(name=>({target_attribute:name,status:'pending',
              reevaluate:req.meta.auto_map_resolution_mode==='reeval_all'||(req.meta.auto_map_reevaluate_targets??[]).includes(name),
              had_baseline:originalNames.includes(name),execution_status:'not_validated',unresolved_values:[]}))}}};
        return{status:'completed',completed_attribute_count:names.length,
          partial_responses:partial?[{batch_index:0,target_attributes:names,response:structuredClone(lastResponse)}]:[],response:lastResponse};
      },invokeStream:()=>{throw new Error('Unexpected compatibility fallback');}},
  });
  return{state,authored,requests,capturedRun,get response(){return lastResponse;},run:async()=>{
    const result=await thunk(options,{requestId:'run-one',getState:()=>({sttmBuilder:state}),dispatch:action=>{
      if(action.type==='semantic')reducer(semanticReducer)(state,action);
      if(action.type==='started')reducer(h.startReducer)(state,action);
      if(action.type==='applied')reducer(h.appliedReducer)(state,action);
    },rejectWithValue:error=>({error})});
    if(!result.error)reducer(h.fulfilledReducer)(state,{meta:{requestId:'run-one'},payload:result});
    else reducer(h.rejectedReducer)(state,{meta:{requestId:'run-one'},payload:result.error});
    return result;
  }};
}
async function accept(state,all){
  const fn=h.compile(`return (${acceptSource});`,{...helpers,listProjectAttributes:async()=>values,getErrorMessage:e=>e.message,
    applyPendingAiMappingReview:payload=>({type:'one',payload}),applyAllPendingAiMappingReviews:payload=>({type:'all',payload})});
  return fn({all},{getState:()=>({sttmBuilder:state}),dispatch:action=>reducer(reducers[action.type==='all'?'applyAllPendingAiMappingReviews':'applyPendingAiMappingReview'])(state,action),rejectWithValue:error=>({error})});
}
for(const partial of[false,true])test(`no-checkbox default sends explicit all-target reevaluation and yields 34 new + 3 replacements (partial=${partial})`,async()=>{
  const t=harness({partial});const result=await t.run();assert.equal(result.error,undefined);
  const req=t.requests[0];assert.equal(req.attributes.length,37);assert.equal(req.meta.auto_map_resolution_mode,'reeval_all');
  assert.deepEqual(req.meta.auto_map_target_scope,t.state.targetAttributeGroup.columns.map(c=>c.name));
  assert.equal(req.meta.auto_map_reevaluate_targets,undefined);
  assert.deepEqual(t.capturedRun.reevaluateTargets,['NAME','CONST','ATTRIBUTE']);
  for(let i=0;i<3;i++)assert.deepEqual(t.state.mappings[i],t.authored[i]);
  assert.equal(t.state.mappings.filter(row=>row.status==='MAPPED').length,37);
  assert.equal(t.state.pendingAiMappingReviews.length,3);
  assert.deepEqual(result.completion,{newMappings:34,newProposals:0,replacementProposals:3,preservedDefinitions:3,unresolved:0});
});
for(const all of[false,true])test(`existing default-run replacements apply only after explicit acceptance (all=${all})`,async()=>{
  const t=harness();await t.run();for(let i=0;i<3;i++)assert.deepEqual(t.state.mappings[i],t.authored[i]);
  await accept(t.state,all);
  assert.equal(t.state.pendingAiMappingReviews.length,all?0:2);
  assert.equal(t.state.mappings[0].sourceColumn,'src.NewName');
  if(!all)assert.deepEqual(t.state.mappings[1],t.authored[1]);
});
test('default unresolved reevaluation preserves source/empty-constant/project-attribute definitions and their mapped status',async()=>{
  const t=harness({unresolved:true});const result=await t.run();assert.equal(result.error,undefined);
  for(let i=0;i<3;i++)assert.deepEqual(t.state.mappings[i],t.authored[i]);
  await accept(t.state,true);assert.equal(t.state.pendingAiMappingReviews.length,0);
  assert.equal(result.completion.unresolved,3);
  for(const original of t.authored)assert.deepEqual(t.state.mappingSuggestions.find(row=>row.targetAttribute===original.targetColumn).candidateSourceAttributes,['src.Alternative']);
});
test('default reevaluation does not certify originally unproven definitions',async()=>{
  const t=harness({originalStatus:'UNMAPPED'});await t.run();
  for(let i=0;i<3;i++)assert.deepEqual(t.state.mappings[i],t.authored[i]);
  assert.equal(t.state.pendingAiMappingReviews.length,3);
});
test('pending diagnostics without a reevaluate marker cannot downgrade a default-run baseline',()=>{
  const state=stateFor(imported());reducer(h.pendingReducer)(state,{meta:{requestId:'run-one'}});
  helpers.applyAutoMapResponseToState(state,{operation:'sttm.auto_map',result:{mappings:{NAME:direct}},meta:{
    automap_preserved_targets:['NAME'],automap_baseline_preservation:{instruction:'preserve_frontend_rows',apply_preserved_mappings:false},
    automap_resolution:{targets:[{target_attribute:'NAME',status:'pending'}]}}});
  assert.deepEqual(state.mappings[0],imported());assert.equal(state.pendingAiMappingReviews.length,1);
});
test('edits saved during default all-target reevaluation remain protected from late proposals',async()=>{
  const t=harness({edit:state=>{
    const update=h.compile(`${functions.captureManualEditSnapshot};return (${reducers.updateMapping});`,helpers);
    update(state,{payload:{id:'NAME',updates:{expression:'src.UserSaved',status:'MAPPED'}}});
    reducer(reducers.commitPendingManualMappingEdits)(state,{});
  }});const result=await t.run();assert.equal(result.error,undefined);
  assert.equal(t.state.mappings[0].expression,'src.UserSaved');assert.equal(t.state.mappings[0].status,'MAPPED');
  assert.equal(t.state.pendingAiMappingReviews.length,2);await accept(t.state,true);
  assert.equal(t.state.mappings[0].expression,'src.UserSaved');
});
test('unsupported default all-target reevaluation fails before POST without preserving silently',async()=>{
  const t=harness({advanced:false});const result=await t.run();
  assert.match(result.error,/not enabled/);assert.equal(t.requests.length,0);
  for(let i=0;i<3;i++)assert.deepEqual(t.state.mappings[i],t.authored[i]);
});
test('checked existing and empty rows retain exactly checked scope',async()=>{
  const t=harness({checked:['NAME','COL_0']});const result=await t.run();assert.equal(result.error,undefined);
  const req=t.requests[0];assert.deepEqual(req.attributes.map(a=>a.target_attribute),['NAME','COL_0']);
  assert.equal(req.meta.auto_map_resolution_mode,'reeval_selected');assert.deepEqual(req.meta.auto_map_reevaluate_targets,['NAME']);
  assert.equal(t.state.pendingAiMappingReviews.length,1);assert.equal(t.state.mappings.find(row=>row.id==='COL_0').status,'MAPPED');
  assert.deepEqual(t.state.mappings[1],t.authored[1]);assert.equal(t.state.mappings.find(row=>row.id==='COL_1').status,'UNMAPPED');
});
test('explicit preserve-only compatibility operation remains separate from default reevaluation',()=>{
  const state=stateFor(imported(),blank('NEW'));
  assert.equal(helpers.autoMapScope(state).mode,'reeval_all');
  assert.equal(helpers.autoMapScope(state,{}).mode,'reeval_all');
  assert.equal(helpers.autoMapScope(state,{action:'complete'}).mode,'preserve_and_complete');
  state.selectedMappingIds=['NEW'];assert.equal(helpers.autoMapScope(state).mode,'preserve_and_complete');
  assert.deepEqual(helpers.autoMapScope(state,{action:'reeval_all'}).names,['NAME','NEW']);
});
