import logging
import re
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlglot.errors import ParseError, TokenError

from app.api.deps import (
    get_mapping_sql_execution_service,
    get_mapping_sql_service,
    get_project_service,
)
from app.core.exceptions import AppValidationError, SnowflakeQueryError
from app.core.mapping_sql import MappingSqlService
from app.core.project_service import ProjectService
from app.schema.contracts import ApiRequestEnvelope, ApiResponseEnvelope, ApiWarning, build_response_envelope
from app.schema.mapping_sql import (
    MappingSqlCompileRequest,
    MappingSqlCompileResponse,
    MappingSqlGraphRepairRequest,
    MappingSqlGraphRepairResponse,
    MappingSqlParseRequest,
    MappingSqlParseResponse,
    MappingSqlPreviewRequest,
    MappingSqlPreviewResponse,
    MappingSqlReviewRequest,
    MappingSqlReviewResponse,
)

router = APIRouter(prefix="/workbench/mapping-sql", tags=["Mapping SQL"])
logger = logging.getLogger(__name__)


def _project_id(payload: Any, context: dict[str, Any]) -> str | None:
    value = getattr(payload, "project_id", None) or (context or {}).get("project_id")
    text = str(value or "").strip()
    return text or None


def _resolve_project_values(
    payload: Any,
    context: dict[str, Any],
    project_service: ProjectService,
) -> list[str]:
    """Attach the project's firm values to the payload's relation graph.

    The stored project attributes are authoritative, so compiled and previewed SQL
    carries the values the project actually uses rather than ``$Name`` text.
    """
    project_id = _project_id(payload, context)
    if not project_id:
        return []
    try:
        attributes = project_service.list_project_attributes(project_id)
    except Exception as exc:  # Firm values are additive; compile still reports leftovers.
        logger.warning("Project firm values unavailable project_id=%s: %s", project_id, exc)
        payload.relation_graph = MappingSqlService.with_project_values(payload.relation_graph, [])
        return ["Project firm values could not be loaded; placeholders may remain unresolved."]
    payload.relation_graph = MappingSqlService.with_project_values(payload.relation_graph, attributes)
    MappingSqlService.resolve_payload_sql(payload)
    suspicious = MappingSqlService.suspicious_project_values(attributes)
    if suspicious:
        return [
            "Project firm values look like captured SQL script text, not a value: "
            + ", ".join(suspicious)
            + ". Correct them in Project Settings before publishing."
        ]
    return []


@router.post("/repair-graph", response_model=ApiResponseEnvelope[MappingSqlGraphRepairResponse])
def repair_mapping_graph(
    body: ApiRequestEnvelope[MappingSqlGraphRepairRequest] | MappingSqlGraphRepairRequest,
    request: Request,
    service: Annotated[MappingSqlService, Depends(get_mapping_sql_execution_service)],
) -> ApiResponseEnvelope[MappingSqlGraphRepairResponse]:
    if isinstance(body, MappingSqlGraphRepairRequest):
        payload, request_id, actor, context = body, None, None, {}
    else:
        payload, request_id, actor, context = body.data, body.request_id, body.actor, body.context
    result = service.repair_graph(payload)
    return build_response_envelope(
        operation="mapping_sql.repair_graph",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=[],
        data=result,
    )


@router.post("/compile", response_model=ApiResponseEnvelope[MappingSqlCompileResponse])
def compile_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlCompileRequest] | MappingSqlCompileRequest,
    request: Request,
    service: Annotated[
        MappingSqlService,
        Depends(get_mapping_sql_execution_service),
    ],
    project_service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[MappingSqlCompileResponse]:
    if isinstance(body, MappingSqlCompileRequest):
        payload, request_id, actor, context = body, None, None, {}
    else:
        payload, request_id, actor, context = body.data, body.request_id, body.actor, body.context
    try:
        value_warnings = _resolve_project_values(payload, context, project_service)
        result = service.compile(payload)
    except (ParseError, TokenError) as exc:
        raise AppValidationError(
            "SQL input could not be parsed. Check literal quoting and expression syntax.",
            details=[{"field": "relation_graph", "error_type": "invalid_sql_syntax",
                      "message": "Check mapping expressions, filters, and derived-source SQL."}],
        ) from exc
    except ValueError as exc:
        message = str(exc)
        field = "relation_graph"
        error_type = "invalid_relation_graph"
        if "dependency" in message.lower() or "mapping expression" in message.lower():
            field = "mappings.source_dependencies"
            error_type = "missing_mapping_dependency"
        elif "placeholder" in message.lower() or "value binding" in message.lower():
            field = "relation_graph.value_bindings"
            error_type = "unresolved_value_binding"
        elif "join" in message.lower() or "disconnected" in message.lower():
            field = "relation_graph.edges"
            error_type = "missing_or_disconnected_join"
        target_match = re.search(r"\(target:\s*([^\)]+)\)", message, flags=re.IGNORECASE)
        detail = {
            "field": field,
            "message": message,
            "error_type": error_type,
            "recommended_action": (
                "Reconcile the affected mapping against the current selected relation graph."
                if error_type == "missing_mapping_dependency"
                else "Add or approve a verified relationship connecting the required relations."
                if error_type == "missing_or_disconnected_join"
                else "Resolve the reported compiler input before validating SQL."
            ),
        }
        if target_match:
            detail["affected_target_column"] = target_match.group(1).strip()
        raise AppValidationError(
            message,
            details=[detail],
        ) from exc
    return build_response_envelope(
        operation="mapping_sql.compile",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=[
            ApiWarning(code="MAPPING_SQL_WARNING", message=warning)
            for warning in [*value_warnings, *result.warnings]
        ],
        data=result,
    )


@router.post("/parse", response_model=ApiResponseEnvelope[MappingSqlParseResponse])
def parse_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlParseRequest] | MappingSqlParseRequest,
    request: Request,
    service: Annotated[MappingSqlService, Depends(get_mapping_sql_service)],
    project_service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[MappingSqlParseResponse]:
    if isinstance(body, MappingSqlParseRequest):
        payload, request_id, actor, context = body, None, None, {}
    else:
        payload, request_id, actor, context = body.data, body.request_id, body.actor, body.context
    project_values = None
    if payload.project_id:
        attributes = project_service.list_project_attributes(payload.project_id)
        project_values = MappingSqlService._resolved_placeholder_sql(MappingSqlService.with_project_values(None, attributes))
    try:
        result = service.parse(payload, project_values=project_values)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return build_response_envelope(
        operation="mapping_sql.parse",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=result.warnings,
        data=result,
    )


@router.post("/review", response_model=ApiResponseEnvelope[MappingSqlReviewResponse])
def review_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlReviewRequest] | MappingSqlReviewRequest,
    request: Request,
    service: Annotated[
        MappingSqlService,
        Depends(get_mapping_sql_execution_service),
    ],
    project_service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[MappingSqlReviewResponse]:
    if isinstance(body, MappingSqlReviewRequest):
        payload = body
        request_id = None
        actor = None
        context: dict[str, object] = {}
        warnings = []
        meta: dict[str, object] = {}
    else:
        payload = body.data
        request_id = body.request_id
        actor = body.actor
        context = body.context
        warnings = body.warnings
        meta = body.meta
    warnings = [
        *warnings,
        *(
            ApiWarning(code="MAPPING_SQL_WARNING", message=message)
            for message in _resolve_project_values(payload, context, project_service)
        ),
    ]

    try:
        result = service.review(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return build_response_envelope(
        operation="mapping_sql.review",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=warnings,
        meta=meta,
        data=result,
    )


@router.post("/preview", response_model=ApiResponseEnvelope[MappingSqlPreviewResponse])
def preview_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlPreviewRequest] | MappingSqlPreviewRequest,
    request: Request,
    service: Annotated[
        MappingSqlService,
        Depends(get_mapping_sql_execution_service),
    ],
    project_service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[MappingSqlPreviewResponse]:
    if isinstance(body, MappingSqlPreviewRequest):
        payload = body
        request_id = None
        actor = None
        context: dict[str, object] = {}
        warnings = []
        meta: dict[str, object] = {}
    else:
        payload = body.data
        request_id = body.request_id
        actor = body.actor
        context = body.context
        warnings = body.warnings
        meta = body.meta
    warnings = [
        *warnings,
        *(
            ApiWarning(code="MAPPING_SQL_WARNING", message=message)
            for message in _resolve_project_values(payload, context, project_service)
        ),
    ]

    try:
        result = service.preview(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise SnowflakeQueryError(
            "Snowflake could not run the mapping preview SQL: "
            f"{MappingSqlService._summarize_sql_error(exc)}"
        ) from exc

    return build_response_envelope(
        operation="mapping_sql.preview",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=warnings,
        meta=meta,
        data=result,
    )
