# Reuse the app session without repeated OAuth — 10 November 2026

A valid app session should take the user to `/dashboard`. The root URL already routes a session-bearing browser to that page, where the shared session gate verifies the identity. A missing or expired session goes to sign-in. Permission denial and service unavailability stay distinct.

The home page uses the shared verified in-memory session instead of forcing another network check. Cached identity stays available for the session; five minutes schedules non-blocking background revalidation rather than expiring it. The gate, header and page consumers share the same pending request on a cold load. No authentication state is newly persisted in browser storage.

The backend login endpoint now checks an existing app session before creating an OAuth state or redirecting to the provider. It refreshes an expiring token through the existing flow when needed, verifies that the stored access token can be decrypted, then redirects directly to the sanitized local destination. Missing, revoked or expired sessions still use the existing PKCE login. Database, permission and provider failures are not silently treated as an expired login. Redirect responses are not cacheable.

Each authenticated request still reads the session's active/revoked state from Snowflake. Only the non-security last-access timestamp is throttled to approximately once per minute. Recent sessions avoid an UPDATE and COMMIT during their check. Timestamp comparisons and updates use UTC to match the existing UTC token/session records and work consistently across account timezones. Authentication and authorization decisions are not cached by this new timestamp logic.

The initial shared identity gate remains in place, with the same UI. The first required OAuth authorization is unchanged; this fix reuses an established app session rather than replacing the custom OAuth architecture. Snowflake ingress identity and caller credential mechanisms are documented in [Snowflake's SPCS SQL execution documentation](https://docs.snowflake.com/en/developer-guide/snowpark-container-services/spcs-execute-sql).

Verification:

- Complete backend suite: 4,783 passed, 31 environment-dependent tests skipped.
- Final focused auth/routes/restart checks after the UTC adjustment: 39 passed.
- All 32 frontend regression scripts passed; added checks cover valid-session dashboard routing, cold-request deduplication and warm cache reuse. TypeScript passed.
- A temporary table in this system's separate Snowflake test account verified real SQL session reuse, UTC activity touches and immediate revocation. It used a fake OAuth grant, performed no real OAuth exchange and changed no real user session. The temporary table was removed by closing its connection.

The saved work is committed to CodeCommit with the earlier 12-slot Auto-map implementation. No `.env` file, credential, OAuth client configuration or UI styling is changed. Client SPCS/IdP latency and the complete interactive SSO round-trip require confirmation in the client environment.

Session-wide navigation and data-cache retention are described in `session-cache-navigation.md`. That follow-up retains cached data through normal navigation, narrows invalidation after saves, and handles confirmed expiry and cross-tab identity changes.
