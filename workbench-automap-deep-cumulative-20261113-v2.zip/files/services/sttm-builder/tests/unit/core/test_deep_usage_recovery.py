import pytest

from app.agent_runs.models import AgentActor, RunCreateRequest
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.agent_runs.trace_writer import DurableTraceWriter
from app.agent_runs.usage import restore_usage
from app.agent_runtime.execution import BudgetExceededError, ExecutionBudget


def test_model_attempt_is_committed_before_dispatch_and_survives_restart():
    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    actor = AgentActor(user_id="user", effective_role="EDITOR")
    run = service.create_run(RunCreateRequest(prompt="Plan a mapping"), actor)
    budget = ExecutionBudget(model_limit=4, tool_limit=8, model_used=3)
    writer = DurableTraceWriter(service, run)
    writer.set_usage_provider(budget.structured_snapshot)
    try:
        budget.consume_model("supervisor.model")
        writer("model.started", "running", "Analyze evidence", {})
        # No explicit flush: a provider attempt must already be durable here.
        usage = repository.latest_budget_usage(run.run_id)
        assert usage["model_calls"] == 4
        restored = repository.get_run(run.run_id)
        assert restored.model_calls_used == 0
        restore_usage(restored, usage)
        restarted = ExecutionBudget(model_limit=4, tool_limit=8, model_used=restored.model_calls_used)
        with pytest.raises(BudgetExceededError):
            restarted.consume_model("supervisor.model")
        assert service.get_state(run.run_id, actor).run.model_calls_used == 4
    finally:
        writer.close()


def test_restored_counts_never_decrease_and_keep_token_categories():
    repository = InMemoryAgentRunRepository()
    run = AgentRunService(repository).create_run(
        RunCreateRequest(prompt="Inspect evidence"), AgentActor(user_id="user", effective_role="EDITOR"))
    run.model_calls_used = 9
    run.category_usage = {"input_tokens": 100}
    restore_usage(run, {"model_calls": 3, "domain_operations": 7, "category_input_tokens": 90,
                        "category_output_tokens": 25, "elapsed_seconds": 30})
    assert run.model_calls_used == 9
    assert run.tool_calls_used == 7
    assert run.category_usage == {"input_tokens": 100, "output_tokens": 25}
    assert run.elapsed_seconds_used == 30
