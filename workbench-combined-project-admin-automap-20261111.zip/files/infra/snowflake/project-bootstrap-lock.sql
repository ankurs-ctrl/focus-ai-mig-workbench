-- Run once before deploying, in the application's metadata database/schema.
-- Atomic CREATE initializes one mutex row; request transactions UPDATE it to
-- serialize idempotency checks across replicas. No application data is deleted.
CREATE TABLE IF NOT EXISTS TBL_PROJECT_BOOTSTRAP_LOCK AS
SELECT 'project-bootstrap'::VARCHAR AS LOCK_KEY, 0::NUMBER AS FENCE;
-- Grant SELECT and UPDATE on this table to the same caller role(s) allowed to
-- create projects, using your existing deployment role/grant process.
