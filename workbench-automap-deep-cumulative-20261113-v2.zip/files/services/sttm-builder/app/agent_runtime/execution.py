from __future__ import annotations

import json
import threading
import time
from collections.abc import Callable
from typing import Any
from uuid import uuid4

from langchain.agents.middleware.types import AgentMiddleware


class ModelOutputTruncatedError(RuntimeError):
    """Provider output ended before a complete decision; never replay it as success."""


class BudgetExceededError(RuntimeError):
    """Raised before an operation that would exceed a hard run budget."""

    error_code = "budget_exhausted"

    def __init__(self, message: str, *, kind: str = "other") -> None:
        super().__init__(message)
        self.kind = kind


class EffortPromotionRequested(RuntimeError):
    """Restart at the durable boundary with a complete, deployment-resolved policy."""
    def __init__(self, policy: dict[str, Any]):
        super().__init__('Actionable work requires the next configured effort tier')
        self.policy = policy


class UnfinishedPlanError(RuntimeError):
    error_code = "unfinished_plan"


class MissingFinalSynthesisError(RuntimeError):
    error_code = "missing_final_synthesis"


class ExecutionCancelledError(RuntimeError):
    """Raised at a model/tool boundary after durable cancellation is observed."""

    error_code = "execution_cancelled"


class ExecutionLeaseLostError(RuntimeError):
    """Raised when this worker no longer owns the durable run lease."""

    error_code = "worker_lease_lost"


class ExecutionBudget:
    """Thread-safe, shared budget for supervisor, specialists, and domain tools."""

    def __init__(
        self,
        *,
        model_limit: int,
        tool_limit: int,
        model_used: int = 0,
        tool_used: int = 0,
        finalization_model_reserve: int = 0,
        finalization_tool_reserve: int = 0,
        adaptive_limits: list[dict[str, Any]] | None = None,
        cancellation_check: Callable[[], bool | str | None] | None = None,
        category_limits: dict[str, int] | None = None,
        category_usage: dict[str, int] | None = None,
        elapsed_seconds: int | None = None,
        elapsed_used: float = 0,
        finalization_seconds: int = 60,
        token_limit: int = 0,
    ) -> None:
        self._category_limits = dict(category_limits or {})
        self._category_usage = dict(category_usage or {})
        # Supervisor model tokens; 0 means no token cap (call budgets still apply).
        # Counts live in category usage so they survive a resumed run.
        self._token_limit = max(0, int(token_limit or 0))
        self._started = time.monotonic()
        self._elapsed_used = elapsed_used
        self._elapsed_limit = elapsed_seconds
        self._finalization_seconds = finalization_seconds
        self.model_limit = model_limit
        self.tool_limit = tool_limit
        self._model_used = model_used
        self._tool_used = tool_used
        self._finalization_model_reserve = max(0, min(finalization_model_reserve, model_limit))
        self._finalization_tool_reserve = max(0, min(finalization_tool_reserve, tool_limit))
        self._finalization_active = False
        self._adaptive_limits = list(adaptive_limits or [])
        self._supervisor_tool_requests = 0
        self._specialist_calls = 0
        self._cache_hits = 0
        self._lock = threading.Lock()
        self._cancellation_check = cancellation_check or (lambda: False)

    def set_cancellation_check(self, check: Callable[[], bool | str | None]) -> None:
        self._cancellation_check = check

    def ensure_active(self, operation: str) -> None:
        if self._elapsed_limit is not None:
            available = self._elapsed_limit - (0 if self._finalization_active else self._finalization_seconds)
            if self._elapsed_used + time.monotonic() - self._started >= available:
                raise BudgetExceededError("Elapsed-time budget exhausted; resume the durable run", kind="elapsed")
        state = self._cancellation_check()
        if state == "lease_lost":
            raise ExecutionLeaseLostError(f"Worker lease was lost before {operation}")
        if state:
            raise ExecutionCancelledError(f"Run cancellation observed before {operation}")

    def record_transaction_cleanup(self) -> None:
        # Rollback must remain possible after cancellation, lease loss or budget
        # exhaustion. Count it, but never prevent releasing a transaction.
        with self._lock:
            self._category_usage['persistence_cleanup_queries'] = self._category_usage.get('persistence_cleanup_queries', 0) + 1

    def consume_category(self, category: str, operation: str) -> None:
        self.ensure_active(operation)
        with self._lock:
            used = self._category_usage.get(category, 0)
            limit = self._category_limits.get(category)
            if limit is not None and used >= limit:
                raise BudgetExceededError(f"{category} budget exhausted before {operation}", kind="category")
            self._category_usage[category] = used + 1

    def consume_model(self, operation: str) -> None:
        self.ensure_active(operation)
        with self._lock:
            used_tokens = self._category_usage.get("input_tokens", 0) + self._category_usage.get("output_tokens", 0)
            if self._token_limit and not self._finalization_active and used_tokens >= self._token_limit:
                raise BudgetExceededError(
                    f"Token budget exhausted before {operation} ({used_tokens}/{self._token_limit})",
                    kind="tokens",
                )
            active_limit = self.model_limit if self._finalization_active else self.model_limit - self._finalization_model_reserve
            if self._model_used + 1 > active_limit:
                raise BudgetExceededError(
                    f"Model-call budget exhausted before {operation} "
                    f"({self._model_used}/{active_limit}; {'finalization' if self._finalization_active else 'working'} phase)",
                    kind="model",
                )
            self._model_used += 1

    def consume_tool(self, operation: str) -> None:
        self.consume_category("domain_operations", operation)
        with self._lock:
            active_limit = self.tool_limit if self._finalization_active else self.tool_limit - self._finalization_tool_reserve
            if self._tool_used + 1 > active_limit:
                raise BudgetExceededError(
                    f"Tool-call budget exhausted before {operation} "
                    f"({self._tool_used}/{active_limit}; {'finalization' if self._finalization_active else 'working'} phase)",
                    kind="tool",
                )
            self._tool_used += 1

    def begin_finalization(self) -> None:
        """Unlock the protected reserve for the host-requested synthesis turn."""
        with self._lock:
            self._finalization_active = True

    def try_auto_scale(self) -> dict[str, int] | None:
        """Promote an Auto run to its next bounded tier at a safe boundary."""
        with self._lock:
            if self._finalization_active or not self._adaptive_limits:
                return None
            previous_model_limit = self.model_limit
            previous_tool_limit = self.tool_limit
            next_limits = self._adaptive_limits.pop(0)
            if next_limits.get('policy'):
                raise EffortPromotionRequested(next_limits['policy'])
            self.model_limit = max(self.model_limit, int(next_limits["model_limit"]))
            self.tool_limit = max(self.tool_limit, int(next_limits["tool_limit"]))
            self._finalization_model_reserve = max(
                self._finalization_model_reserve,
                int(next_limits["finalization_model_reserve"]),
            )
            self._finalization_tool_reserve = max(
                self._finalization_tool_reserve,
                int(next_limits["finalization_tool_reserve"]),
            )
            return {
                "previous_model_limit": previous_model_limit,
                "model_limit": self.model_limit,
                "previous_tool_limit": previous_tool_limit,
                "tool_limit": self.tool_limit,
                "finalization_model_reserve": self._finalization_model_reserve,
                "finalization_tool_reserve": self._finalization_tool_reserve,
            }

    def record_supervisor_tool_request(self) -> None:
        with self._lock:
            self._supervisor_tool_requests += 1

    def record_specialist_call(self) -> None:
        with self._lock:
            self._specialist_calls += 1

    def record_cache_hit(self) -> None:
        with self._lock:
            self._cache_hits += 1

    def record_tokens(self, *, input_tokens: int, output_tokens: int, cached_tokens: int = 0) -> None:
        with self._lock:
            for key, value in (("input_tokens", input_tokens), ("output_tokens", output_tokens),
                               ("cached_tokens", cached_tokens)):
                self._category_usage[key] = self._category_usage.get(key, 0) + max(0, int(value or 0))

    def structured_snapshot(self) -> dict[str, int]:
        with self._lock:
            active_model_limit = self.model_limit if self._finalization_active else self.model_limit - self._finalization_model_reserve
            active_tool_limit = self.tool_limit if self._finalization_active else self.tool_limit - self._finalization_tool_reserve
            return {
                **{f"category_{key}": value for key, value in self._category_usage.items()},
                "elapsed_seconds": int(self._elapsed_used + time.monotonic() - self._started),
                "model_calls": self._model_used,
                "supervisor_tool_requests": self._supervisor_tool_requests,
                "domain_operations": self._tool_used,
                "specialist_calls": self._specialist_calls,
                "cache_hits": self._cache_hits,
                "token_limit": self._token_limit,
                "finalization_active": int(self._finalization_active),
                "finalization_model_reserve": self._finalization_model_reserve,
                "finalization_tool_reserve": self._finalization_tool_reserve,
                "model_limit": self.model_limit,
                "tool_limit": self.tool_limit,
                "active_model_remaining": max(0, active_model_limit - self._model_used),
                "active_tool_remaining": max(0, active_tool_limit - self._tool_used),
                "total_model_remaining": max(0, self.model_limit - self._model_used),
                "total_tool_remaining": max(0, self.tool_limit - self._tool_used),
            }

    def snapshot(self) -> tuple[int, int]:
        with self._lock:
            return self._model_used, self._tool_used


class SharedBudgetMiddleware(AgentMiddleware):
    """Counts Deep Agents supervisor calls against the shared hard budget.

    It runs inside Deep Agents' summarization middleware, so each request it
    sees is the effective (possibly compacted) context. After every call it
    records the provider's token usage and emits ``context.usage`` for the chat
    context meter, plus ``context.compacted`` when the summary boundary moves.
    """

    def __init__(self, budget: ExecutionBudget, trace: "TraceEmitter | None" = None,
                 *, context_window: int = 0) -> None:
        super().__init__()
        self._budget = budget
        self._trace = trace or null_trace
        self._context_window = max(0, int(context_window or 0))
        self._tool_tokens: dict[str, int] = {}
        self._summary_cutoff: int | None = None

    def _usage(self, request: Any, response: Any, trace_id: str) -> dict[str, Any]:
        """Record provider usage; emit the context meter and any compaction."""
        try:
            from langchain_core.messages import ToolMessage
            from langchain_core.messages.utils import count_tokens_approximately
        except ImportError:  # pragma: no cover - langchain is a runtime dependency
            return {}
        messages = list(getattr(response, "result", None) or [])
        usage = next((getattr(m, "usage_metadata", None) for m in reversed(messages)
                      if getattr(m, "usage_metadata", None)), None) or {}
        input_tokens = int(usage.get("input_tokens") or 0)
        output_tokens = int(usage.get("output_tokens") or 0)
        cached = int(dict(usage.get("input_token_details") or {}).get("cache_read") or 0)
        self._budget.record_tokens(input_tokens=input_tokens, output_tokens=output_tokens, cached_tokens=cached)
        request_messages = list(getattr(request, "messages", None) or [])
        system = getattr(request, "system_message", None)
        estimate = {
            "system": count_tokens_approximately([system]) if system is not None else 0,
            "tools": sum(self._tool_size(tool) for tool in getattr(request, "tools", None) or []),
            "tool_results": count_tokens_approximately(
                [m for m in request_messages if isinstance(m, ToolMessage)]),
            "messages": count_tokens_approximately(
                [m for m in request_messages if not isinstance(m, ToolMessage)]),
        }
        estimated_total = sum(estimate.values())
        used = input_tokens or estimated_total
        # The provider reports only a total; split it in the estimated proportions.
        scale = (used / estimated_total) if estimated_total else 0
        categories = {key: int(round(value * scale)) for key, value in estimate.items()}
        window = self._context_window
        event = dict(getattr(request, "state", None) or {}).get("_summarization_event") or {}
        cutoff = event.get("cutoff_index") if isinstance(event, dict) else None
        compacted = cutoff is not None and cutoff != self._summary_cutoff
        if compacted:
            self._summary_cutoff = cutoff
            summary = getattr(event.get("summary_message"), "content", "") if isinstance(event, dict) else ""
            if not isinstance(summary, str):
                summary = json.dumps(summary, default=str)
            self._trace(
                "context.compacted", "succeeded",
                "Earlier conversation was summarized to keep the working context within the model window.",
                {"trace_id": f"context:compaction:{cutoff}", "kind": "context", "label": "Context summarized",
                 "cutoff_index": cutoff, "history_path": event.get("file_path"),
                 # A later run in this conversation starts from this summary.
                 "summary": summary[:20_000] or None},
            )
        snapshot = self._budget.structured_snapshot()
        self._trace(
            "context.usage", "succeeded", f"Context {used:,}/{window:,} tokens" if window else f"Context {used:,} tokens",
            {"trace_id": "context:usage", "kind": "context", "label": "Context window",
             "used_tokens": used, "window_tokens": window, "output_tokens": output_tokens, "cached_tokens": cached,
             "categories": categories, "free_tokens": max(0, window - used) if window else None,
             "compaction_at_tokens": int(window * 0.85) if window else None,
             "summarized": self._summary_cutoff is not None, "estimated": not input_tokens,
             "run_input_tokens": snapshot.get("category_input_tokens", 0),
             "run_output_tokens": snapshot.get("category_output_tokens", 0),
             "model_call_trace_id": trace_id},
        )
        return {"input_tokens": input_tokens, "output_tokens": output_tokens, "cached_tokens": cached}

    def _check_complete_output(self, response: Any, trace_id: str) -> None:
        messages = list(getattr(response, "result", None) or [])
        for message in messages:
            reason = str(dict(getattr(message, "response_metadata", None) or {}).get("finish_reason") or "")
            if reason in {"length", "max_tokens", "max_completion_tokens"}:
                self._trace("model.truncated", "failed",
                            "The model output limit ended before a complete decision; incomplete actions were not executed.",
                            {"trace_id": trace_id, "kind": "model", "label": "Incomplete model output", "finish_reason": reason})
                raise ModelOutputTruncatedError("Model output was truncated; adjust the output limit or reduce plan scope before resuming.")

    def _tool_size(self, tool: Any) -> int:
        name = str(getattr(tool, "name", None) or (tool.get("name") if isinstance(tool, dict) else "") or id(tool))
        if name not in self._tool_tokens:
            try:
                from langchain_core.utils.function_calling import convert_to_openai_tool
                self._tool_tokens[name] = len(json.dumps(convert_to_openai_tool(tool), default=str)) // 4
            except Exception:
                self._tool_tokens[name] = 0
        return self._tool_tokens[name]

    def before_model(self, state: Any, runtime: Any) -> None:
        self._budget.consume_model("supervisor.model")

    async def abefore_model(self, state: Any, runtime: Any) -> None:
        self._budget.consume_model("supervisor.model")

    def wrap_tool_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        self._budget.ensure_active(f"supervisor.tool.{request.tool_call.get('name', 'unknown')}")
        self._budget.record_supervisor_tool_request()
        return handler(request)

    async def awrap_tool_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        self._budget.ensure_active(f"supervisor.tool.{request.tool_call.get('name', 'unknown')}")
        self._budget.record_supervisor_tool_request()
        return await handler(request)

    def wrap_model_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        trace_id = f"model:supervisor:{uuid4().hex}"
        started_at = time.perf_counter()
        self._trace(
            "model.started",
            "running",
            "The supervisor is analyzing verified evidence and deciding the next action.",
            {"trace_id": trace_id, "kind": "model", "label": "Analyze evidence"},
        )
        try:
            response = handler(request)
        except Exception:
            self._trace(
                "model.failed",
                "failed",
                "The supervisor model call failed before returning a decision.",
                {
                    "trace_id": trace_id,
                    "kind": "model",
                    "label": "Analyze evidence",
                    "metrics": {"duration_ms": round((time.perf_counter() - started_at) * 1000)},
                },
            )
            raise
        try:
            tokens = self._usage(request, response, trace_id)
        except Exception:  # accounting never fails a model call
            tokens = {}
        self._trace(
            "model.completed",
            "succeeded",
            "The supervisor selected the next action from the available evidence.",
            {
                "trace_id": trace_id,
                "kind": "model",
                "label": "Analyze evidence",
                "metrics": {"duration_ms": round((time.perf_counter() - started_at) * 1000), **tokens},
            },
        )
        self._check_complete_output(response, trace_id)
        return response

    async def awrap_model_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        trace_id = f"model:supervisor:{uuid4().hex}"
        started_at = time.perf_counter()
        self._trace(
            "model.started",
            "running",
            "The supervisor is analyzing verified evidence and deciding the next action.",
            {"trace_id": trace_id, "kind": "model", "label": "Analyze evidence"},
        )
        try:
            response = await handler(request)
        except Exception:
            self._trace(
                "model.failed",
                "failed",
                "The supervisor model call failed before returning a decision.",
                {
                    "trace_id": trace_id,
                    "kind": "model",
                    "label": "Analyze evidence",
                    "metrics": {"duration_ms": round((time.perf_counter() - started_at) * 1000)},
                },
            )
            raise
        try:
            tokens = self._usage(request, response, trace_id)
        except Exception:  # accounting never fails a model call
            tokens = {}
        self._trace(
            "model.completed",
            "succeeded",
            "The supervisor selected the next action from the available evidence.",
            {
                "trace_id": trace_id,
                "kind": "model",
                "label": "Analyze evidence",
                "metrics": {"duration_ms": round((time.perf_counter() - started_at) * 1000), **tokens},
            },
        )
        self._check_complete_output(response, trace_id)
        return response


TraceEmitter = Callable[[str, str, str, dict[str, Any]], None]


def null_trace(event_type: str, status: str, summary: str, data: dict[str, Any]) -> None:
    del event_type, status, summary, data


class BudgetedSession:
    """Count issued Snowpark queries at the shared session boundary."""
    def __init__(self, session: Any, budget: ExecutionBudget):
        self._session, self._budget = session, budget

    def sql(self, query, *args, **kwargs):
        if str(query).strip().rstrip(';').upper() in {'COMMIT','ROLLBACK'}:
            self._budget.record_transaction_cleanup()
        else:
            self._budget.consume_category('snowflake_queries', 'snowflake.query')
        return self._session.sql(query, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._session, name)
