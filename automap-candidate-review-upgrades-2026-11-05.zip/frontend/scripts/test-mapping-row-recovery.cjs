const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
function compile(filename, source) {
  const loaded = new Module(filename, module);
  loaded.require = name => name.startsWith('@/')
    ? load(path.resolve(__dirname, `../src/${name.slice(2)}.ts`)) : require(name);
  loaded._compile(ts.transpileModule(source, {compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020,
  }}).outputText, filename);
  return loaded.exports;
}
function load(filename) { return compile(filename, fs.readFileSync(filename, 'utf8')); }
const {missingTargetMappings, savedMappingEvidence, savedRunBlockers} = load(path.resolve(__dirname, '../src/features/sttm/shared/mapping-row-recovery.ts'));
const blank = (targetColumn, id = targetColumn) => ({id, targetColumn, status: 'UNMAPPED', sourceColumn: null});
const saved = {...blank('NAME', 'saved'), status:'UNMAPPED', sourceColumn:'cte."Name"',
  unmatchedReason:'Required relations are disconnected', transformationClassification:'unresolved'};
const targets = [blank('NAME'), blank('VALUE'), blank('OTHER')];
const existing = [saved];
const missing = missingTargetMappings(existing, targets);
assert.deepEqual(missing.map(row => row.targetColumn), ['VALUE', 'OTHER']);
assert.equal(existing[0], saved);
assert.equal(missingTargetMappings([...existing, ...missing], targets).length, 0);
assert.equal(missingTargetMappings([blank('D.S.T.NAME')], [blank('NAME')]).length, 0);
assert.equal(missingTargetMappings([blank('"name"')], [blank('NAME')]).length, 1);
assert.equal(missingTargetMappings([blank('NAME', 'VALUE')], [blank('VALUE')])[0].id, 'VALUE:missing:1');
assert.deepEqual(savedMappingEvidence({unmatched_reason:'exact reason', used_learning_ids:['learn'],
  candidate_source_attributes:['cte."Name"']}), {
  aiCandidates:[], aiSuggestions:[], selectedAiCandidateId:null, aiReviewStatus:null, aiUndoSnapshot:null,
  unmatchedReason:'exact reason', usedLearningIds:['learn'], candidateSourceColumns:['cte."Name"'],
  usedInferenceIds:[], usedRecommendationIds:[],
});
const savedOutcome = {mappings:{'D.S.T.NAME':{unmatched_reason:'legacy graph rejection'}}};
assert.deepEqual(savedRunBlockers([saved], savedOutcome), ['legacy graph rejection']);
assert.deepEqual(savedRunBlockers([{...saved,status:'MAPPED'}], savedOutcome), []);
assert.deepEqual(savedRunBlockers([{...saved,targetColumn:'OTHER'}], savedOutcome), []);
assert.equal(saved.unmatchedReason, 'Required relations are disconnected');

const slicePath = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
const slice = ts.createSourceFile(slicePath, fs.readFileSync(slicePath, 'utf8'), ts.ScriptTarget.Latest, true);
let recoveryReducer, restoreRow;
function visit(node) {
  if (ts.isPropertyAssignment(node) && node.name.getText(slice) === 'ensureTargetMappings') recoveryReducer = node.initializer.getText(slice);
  if (ts.isBinaryExpression(node) && node.left.getText(slice) === 'state.mappings'
    && ts.isCallExpression(node.right) && node.right.expression.getText(slice) === 'rawMappingRows.map') restoreRow = node.right.arguments[0].getText(slice);
  ts.forEachChild(node, visit);
}
visit(slice);
assert.ok(recoveryReducer);
assert.ok(restoreRow);
const ensure = compile(slicePath, `module.exports = missingTargetMappings => (${recoveryReducer});`)(missingTargetMappings);
const state = {mappings:existing, selectedMappingIds:['saved'], pendingManualEditSnapshots:{saved:{...saved}}, pendingAiMappingReviews:[{mappingId:'saved'}]};
ensure(state, {payload:targets});
assert.equal(state.mappings.length, 3);
assert.equal(state.mappings[0], saved);
assert.deepEqual(state.selectedMappingIds, ['saved']);
assert.ok(state.pendingManualEditSnapshots.saved);
assert.equal(state.pendingAiMappingReviews.length, 1);
ensure(state, {payload:targets});
assert.equal(state.mappings.length, 3);
const restore = compile(slicePath, `module.exports = (savedMappingEvidence) => {
  const rewriteLegacyAliasReference = value => value;
  const legacyAliasRewrites = new Map();
  const dependencyIsAvailable = () => true;
  const downgradedTargetColumns = [];
  return (${restoreRow});
};`)(savedMappingEvidence);
const restored = restore({id:'saved', target_column:'NAME', status:'UNMAPPED',
  source_columns:['cte."Name"'], unmatched_reason:'exact graph rejection',
  confidence:0.97, transformation_classification:'unresolved', used_learning_ids:['learn']}, 0);
assert.equal(restored.unmatchedReason, 'exact graph rejection');
assert.equal(restored.status, 'UNMAPPED');
assert.equal(restored.confidenceScore, 0.97);
assert.equal(restored.transformationClassification, 'unresolved');
assert.deepEqual(restored.usedLearningIds, ['learn']);
console.log('Target coverage appends idempotently, preserves edits and quoted identities, and actual reopen hydration retains validation evidence.');

const graphReducers = {};
function visitGraph(node) {
  if (ts.isPropertyAssignment(node) && ['removeDerivedSource', 'toggleDerivedSource', 'clearDerivedSources'].includes(node.name.getText(slice))) {
    graphReducers[node.name.getText(slice)] = compile(slicePath, `module.exports = (${node.initializer.getText(slice)});`);
  }
  ts.forEachChild(node, visitGraph);
}
visitGraph(slice);
for (const name of Object.keys(graphReducers)) {
  const state = {derivedSources:[{id:'derived',isSelected:true}], drivingTableId:'derived',
    compiledMappingReady:true, compiledMappingContextHash:'old', mappings:[saved]};
  graphReducers[name](state, {payload:{id:'derived'}});
  assert.equal(state.drivingTableId, null);
  assert.equal(state.compiledMappingReady, false);
  assert.equal(state.compiledMappingContextHash, null);
  assert.equal(state.mappings[0], saved);
}
const unrelated = {derivedSources:[{id:'driver',isSelected:true},{id:'other',isSelected:false}], drivingTableId:'driver'};
graphReducers.toggleDerivedSource(unrelated, {payload:{id:'other'}});
assert.equal(unrelated.drivingTableId, 'driver');
console.log('Removing a derived driver invalidates compilation without choosing another population or changing mappings.');

const reducerNames = ['autoMapReviewIsApplicable', 'autoMapReviewFromRun', 'autoMapRevisionHash', 'autoMapSourceInputs', 'autoMapSharedInputs', 'autoMapInputsMatch', 'stablePreparedContextValue', 'applyAutoMapResponseToState', 'normalizeTargetKey', 'targetKeyVariants',
  'autoMapRecord', 'autoMapCount', 'extractAutoMapPreservation', 'autoMapInputSignature',
  'autoMapRowIsEdited', 'restoreAutoMapStatus', 'extractAutoMappingReview'];
const reducerSource = slice.statements.filter(node => ts.isFunctionDeclaration(node)
  && reducerNames.includes(node.name?.text)).map(node => node.getText(slice)).join('\n');
const applyAutoMap = compile(slicePath, `
  const {sha256} = require('@noble/hashes/sha256');
  const extractSemanticViewNameFromStatus = (_, fallback) => fallback;
  const normalizeSemanticContextItems = value => value;
  const buildPendingAiMappingReviews = () => [];
  const applyMappingSuggestion = row => { row.status = 'MAPPED'; row.sourceColumn = 'new.ID'; };
  ${reducerSource}
  module.exports = applyAutoMapResponseToState;
`);
const preserved = {...blank('NAME'), status:'MAPPED', sourceColumn:'old.NAME', preprocessingRule:'TRIM(old.NAME)'};
const failedState = {mappings:[preserved, {...blank('VALUE'), status:'PROCESSING'}, blank('OTHER')],
  mappingSuggestions:[], pendingManualEditSnapshots:{}, pendingAiMappingReviews:[]};
const failedResponse = {warnings:[{code:'AUTO_MAPPING_BATCH_FAILED',field:'DB.S.T.NAME'},
  {code:'AUTO_MAPPING_BATCH_FAILED',field:'VALUE'}], result:{mappings:{
    NAME:{source_attributes:[],confidence_score:0}, VALUE:{source_attributes:[],confidence_score:0},
    OTHER:{source_attributes:['new.ID'],confidence_score:0.99}}}};
applyAutoMap(failedState, failedResponse);
assert.equal(preserved.status, 'MAPPED');
assert.equal(preserved.sourceColumn, 'old.NAME');
assert.equal(preserved.preprocessingRule, 'TRIM(old.NAME)');
assert.equal(failedState.mappings[1].status, 'UNMAPPED');
assert.equal(failedState.mappings[2].status, 'MAPPED');
applyAutoMap(failedState, failedResponse);
assert.equal(preserved.sourceColumn, 'old.NAME');
console.log('Mixed Auto-map failure preserves mapped expressions, clears processing, and applies successful targets idempotently.');

const pagePath = path.resolve(__dirname, '../src/app/sttm/builder/new/mapping/page.tsx');
const page = ts.createSourceFile(pagePath, fs.readFileSync(pagePath, 'utf8'), ts.ScriptTarget.Latest, true);
let autoCompileEffect;
function visitPage(node) {
  if (ts.isCallExpression(node) && node.expression.getText(page) === 'useEffect'
    && node.arguments[0]?.getText(page).includes('lastAutomaticCompileHash.current === compilerContextHash')) autoCompileEffect = node.arguments[0].getText(page);
  ts.forEachChild(node, visitPage);
}
visitPage(page);
assert.ok(autoCompileEffect);
const runEffect = compile(pagePath, `module.exports = context => { const {
  autoCompile, mappingLoading, currentSqlArtifact, isCompilingSql, reviewLoading,
  savedWorkspaceHydrating, isLoadingProjectAttributes, pendingManualEditSnapshots,
  mappedCount, lastAutomaticCompileHash, compilerContextHash, window, compileCurrentMappingSql
} = context; return (${autoCompileEffect})(); };`);
const timers = [];
let compiles = 0;
const input = {autoCompile:false, mappingLoading:false, currentSqlArtifact:{source:'generated'}, savedWorkspaceHydrating:false,
  isLoadingProjectAttributes:false, pendingManualEditSnapshots:{},
  activeTab:'mapping', isCompilingSql:false, reviewLoading:false, mappedCount:1,
  lastAutomaticCompileHash:{current:null}, compilerContextHash:'current',
  window:{setTimeout:callback=>{timers.push(callback);return 1;},clearTimeout:()=>{}},
  compileCurrentMappingSql:()=>{compiles++;}};
runEffect(input);
assert.equal(timers.length, 0);
input.autoCompile = true;
runEffect(input);
assert.equal(timers.length, 1);
timers.shift()();
assert.equal(compiles, 1);
assert.equal(input.lastAutomaticCompileHash.current, 'current');
input.compilerContextHash = 'blocked';
input.mappedCount = 0;
runEffect(input);
assert.equal(timers.length, 0);
console.log('Settled valid Auto-map rows compile independently of save state; unresolved rows do not trigger compilation.');

const reducers = {};
let captureSource, cloneSource;
function visitManual(node) {
  if (ts.isFunctionDeclaration(node)) {
    if (node.name?.text === 'captureManualEditSnapshot') captureSource = node.getText(slice);
    if (node.name?.text === 'cloneMappingSnapshot') cloneSource = node.getText(slice);
  }
  if (ts.isPropertyAssignment(node) && ['commitPendingManualMappingEdits', 'cancelPendingManualMappingEdits'].includes(node.name.getText(slice))) {
    reducers[node.name.getText(slice)] = node.initializer.getText(slice);
  }
  ts.forEachChild(node, visitManual);
}
visitManual(slice);
const manual = compile(slicePath, `${cloneSource}\n${captureSource}\nmodule.exports = {
  capture: captureManualEditSnapshot, save: ${reducers.commitPendingManualMappingEdits}, cancel: ${reducers.cancelPendingManualMappingEdits}
};`);
const approved = {id:'manual', targetColumn:'NAME', sourceColumns:['a.NAME'], expression:'a.NAME', status:'MAPPED', manuallySaved:true};
const manualState = {mappings:[{...approved}], pendingManualEditSnapshots:{}, selectedMappingIds:[], autoMapBlockedByManualEdits:false};
manual.capture(manualState, manualState.mappings[0]);
manualState.mappings[0].expression = 'TRIM(a.NAME)';
assert.equal(manualState.mappings[0].manuallySaved, false);
assert.equal(manualState.pendingManualEditSnapshots.manual.manuallySaved, true);
assert.equal(manualState.pendingManualEditSnapshots.manual.expression, 'a.NAME');
manual.cancel(manualState);
assert.equal(manualState.mappings[0].manuallySaved, true);
assert.equal(manualState.mappings[0].expression, 'a.NAME');
manual.capture(manualState, manualState.mappings[0]);
manualState.mappings[0].expression = 'TRIM(a.NAME)';
manual.save(manualState);
assert.equal(manualState.mappings[0].manuallySaved, true);
assert.equal(manualState.mappings[0].expression, 'TRIM(a.NAME)');
assert.deepEqual(manualState.pendingManualEditSnapshots, {});
console.log('Manual edit clears acceptance until Save; Cancel restores the prior accepted decision.');