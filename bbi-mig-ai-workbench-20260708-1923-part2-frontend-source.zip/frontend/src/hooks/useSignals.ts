/**
 * React hook for subscribing to real-time FIR signals.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { signalService, Signal, SignalPriority, SignalLayer } from '@/services/signalService';
import { API_ROUTES } from '@/api/routes';
import { resolveApiBaseUrl } from '@/api/axiosInstance';

const MAX_SIGNAL_AGE_MS = 60 * 1000; // 1 minute - signals older than this are considered stale

export interface UseSignalsOptions {
  autoConnect?: boolean;
  filterPriority?: SignalPriority[];
  filterLayer?: SignalLayer[];
  filterType?: string[];
  maxSignals?: number;
}

export interface UseSignalsResult {
  signals: Signal[];
  isConnected: boolean;
  sessionId: string | null;
  error: Error | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  dismissSignal: (signalId: string) => void;
  clearSignals: () => void;
}

export function useSignals(options: UseSignalsOptions = {}): UseSignalsResult {
  const {
    autoConnect = true,
    filterPriority,
    filterLayer,
    filterType,
    maxSignals = 10,
  } = options;

  const [signals, setSignals] = useState<Signal[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [error, setError] = useState<Error | null>(null);

  const shouldIncludeSignal = useCallback(
    (signal: Signal): boolean => {
      if (filterPriority && !filterPriority.includes(signal.priority)) {
        return false;
      }
      if (filterLayer && !filterLayer.includes(signal.layer)) {
        return false;
      }
      if (filterType && !filterType.includes(signal.signal_type)) {
        return false;
      }
      return true;
    },
    [filterPriority, filterLayer, filterType]
  );

  // Use refs for callbacks to avoid recreating the effect on every render
  const shouldIncludeSignalRef = useRef(shouldIncludeSignal);
  shouldIncludeSignalRef.current = shouldIncludeSignal;

  const maxSignalsRef = useRef(maxSignals);
  maxSignalsRef.current = maxSignals;

  // Track if we've already initiated a connection
  const hasInitiatedConnection = useRef(false);

  const handleSignal = useCallback((signal: Signal) => {
    // Filter out stale signals
    const signalAge = Date.now() - signal.created_at;
    if (signalAge > MAX_SIGNAL_AGE_MS) {
      console.debug('Ignoring stale signal:', signal.signal_id, 'age:', signalAge);
      return;
    }

    if (!shouldIncludeSignalRef.current(signal)) {
      return;
    }

    setSignals((prev) => {
      const existing = prev.find((s) => s.signal_id === signal.signal_id);
      if (existing) {
        return prev;
      }

      const updated = [signal, ...prev];
      return updated.slice(0, maxSignalsRef.current);
    });
  }, []);

  const handleConnection = useCallback((connected: boolean, sid?: string) => {
    setIsConnected(connected);
    setSessionId(sid || null);
    if (!connected) {
      setError(null);
    }
  }, []);

  const handleError = useCallback((err: Error) => {
    setError(err);
  }, []);

  const connect = useCallback(async () => {
    try {
      setError(null);
      await signalService.connect();
    } catch (err) {
      setError(err instanceof Error ? err : new Error(String(err)));
    }
  }, []);

  const disconnect = useCallback(() => {
    signalService.disconnect();
  }, []);

  const dismissSignal = useCallback((signalId: string) => {
    setSignals((prev) => prev.filter((s) => s.signal_id !== signalId));
  }, []);

  const clearSignals = useCallback(() => {
    setSignals([]);
  }, []);

  // Fetch pre-existing FIR notifications on initial connection
  const hasFetchedInitial = useRef(false);
  useEffect(() => {
    if (!isConnected || hasFetchedInitial.current) return;
    hasFetchedInitial.current = true;

    const fetchPending = async () => {
      try {
        const baseUrl = resolveApiBaseUrl();
        const res = await fetch(`${baseUrl}${API_ROUTES.notifications.pending}?limit=5`);
        if (!res.ok) return;
        const data = await res.json();
        const notifications = data?.notifications ?? [];
        for (const n of notifications) {
          const signal: Signal = {
            signal_id: n.id || `fir_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            signal_type: `fir.${n.type || 'recommendation'}`,
            title: n.type === 'feedback_question' ? 'Question' : 'FIR Insight',
            message: n.message || '',
            priority: n.priority >= 80 ? 'high' : n.priority >= 50 ? 'medium' : 'low',
            layer: (n.layer as SignalLayer) || 'notification',
            options: n.options?.map((opt: { id?: string; label?: string } | string) =>
              typeof opt === 'string'
                ? { id: opt, label: opt }
                : { id: opt.id || opt.label || '', label: opt.label || opt.id || '' }
            ),
            metadata: {
              recommendation_id: n.id,
              recommendation_type: n.type,
              confidence: n.confidence,
              score: n.score,
            },
            created_at: n.created_at ? n.created_at * 1000 : Date.now(),
          };
          handleSignal(signal);
        }
      } catch {
        // Non-fatal: notifications endpoint may not be available yet
      }
    };
    fetchPending();
  }, [isConnected, handleSignal]);

  // Connection effect - runs only once when autoConnect is true
  useEffect(() => {
    const unsubSignal = signalService.onSignal(handleSignal);
    const unsubConnection = signalService.onConnection(handleConnection);
    const unsubError = signalService.onError(handleError);

    // Only connect once per hook instance
    if (autoConnect && !hasInitiatedConnection.current) {
      hasInitiatedConnection.current = true;
      connect();
    }

    return () => {
      unsubSignal();
      unsubConnection();
      unsubError();
    };
  }, [autoConnect, connect, handleSignal, handleConnection, handleError]);

  return {
    signals,
    isConnected,
    sessionId,
    error,
    connect,
    disconnect,
    dismissSignal,
    clearSignals,
  };
}

export type { Signal, SignalPriority, SignalLayer };
