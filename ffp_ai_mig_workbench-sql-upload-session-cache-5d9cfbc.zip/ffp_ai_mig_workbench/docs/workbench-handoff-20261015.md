# Workbench continuation prompt and complete next-release inventory

Checkpoint: 2026-10-15. The user requested this handoff and paused implementation
to continue in another chat. Their latest requirement is that the next deployment
include all intended fixes, not just the latest Auto-map change. This is not
authorization to deploy, scale services, commit, push, grant, or load target data.

Copy the prompt below into the next chat, or ask it to read this entire file.

## Continuation prompt

Continue the already approved work on the migration workbench. Read this complete
handoff, the two detailed plans below, and the relevant code/diffs before editing.
Do not restart the singleton experiment or ask me to approve the existing plan
again. Execute the batched-retrieval plan, validate actual accuracy and latency,
and prepare one complete release inventory covering ALL intended work described
below. Keep release/deployment authorization separate from implementation.

### 1. Authoritative folders and saved plans

- MAIN, providing environment, Python virtualenv, trusted CA, and plans:
  `C:/Users/ankur.sinha/Desktop/bbi-workbench-dev/ffp_ai_mig_workbench`
- FEATURE, the implementation/application checkout to inspect, edit, test, and
  eventually build from:
  `C:/Users/ankur.sinha/Desktop/bbi-workbench-dev/ffp_ai_mig_workbench_zip_review`
- FEATURE branch: `feature/automap-context-firm-values-2.9.6`.
- FEATURE HEAD: `dad856fd31339dd00024c989340815e3dbc50d2c`.
- MAIN branch/HEAD inherited from earlier work: `import/develop-6fa37ce` / `6cf8f93`.
- Current approved replacement plan:
  `<MAIN>/.snowflake/cortex/plans/automap-batched-retrieval-performance.plan.md`.
- Original parity plan:
  `<MAIN>/.snowflake/cortex/plans/workbench-context-deployment-parity.plan.md`.
- Supporting FEATURE documents:
  `docs/automap-scoped-retrieval.md`,
  `docs/workbench-context-deployment-parity.md`,
  `docs/assistant-context-continuity.md`,
  `docs/automap-context-rollout.md`.

Both plans were verified to exist. The parity plan's steps 1-7 were implemented
locally; step 8 remains acceptance/release-gated. The NEW batching redesign is
approved but NOT implemented. Older documents and memory entries contain
superseded progress; this checkpoint takes precedence for current status.

### 2. Non-negotiable restrictions

- NEVER edit `scripts/deploy_spcs_client_snow_safe.ps1`.
- Preserve all inherited dirty/untracked work. No reset, checkout-overwrite,
  wholesale zip copy, unrelated redesign, or assumption that HEAD is the build.
- Backend 8000; frontend 3000. Use FEATURE code with the verified MAIN environment
  and trusted CA. FEATURE's own local env was stale; do not substitute it blindly.
- Do not expose `.env.local`, client env secrets, auth URLs/tokens, or customer
  payload dumps. Do not disable TLS verification.
- Do not bypass restricted-session-scope denials using another connection.
- Do not reduce accuracy by truncating mandatory evidence, silently dropping
  corrections/population rules, guessing bindings, or blindly increasing budgets.
- No mapping publication, target-data loading, grants, commit, push, or SPCS
  deployment without appropriate explicit authorization.
- The user explicitly permits modifying/testing an EXISTING DEVELOPMENT mapping.
  Use project 2301/mapping 9601; do not impose the superseded isolated-new-mapping
  restriction. Protect its captured baseline and distinguish tests from publish.
- SPCS Auto-map currently has two instances. Increasing to three/four is only a
  possible LATER option, NOT authorized in this change.

Protected deployer SHA256 last verified:
`486DDC012EFFA2EF7B19C6A1FD40CB7622F8929A15A0C3DA9D2E856B9837BAC6`.

### 3. Earlier work that must be retained in the next release

Some work below was previously deployed at historical tag `dad856f`; subsequent
parity/retrieval changes remain local. Recheck the actual diff/image manifests
instead of assuming all current files were deployed.

- Transformation-rule Apply parity with CTE/derived-source Apply. Actions are
  artifact/intent-based, not brittle keyword triggers. Preserve multi-column
  transformation proposals, accepted Apply behavior, and artifact ownership.
- Assistant markdown/SQL/table rendering and wrap-toggle behavior.
- Assistant continuity: current workspace explanations, mapping reopen memory,
  checkpoint/history handling, typed delegation, and visible execution evidence.
- Earlier FIR/Auto-map learning, transport restoration/deduplication, mapping
  binding/compiler safeguards, approved project Value/SET bindings, and scoped
  upload/edit fidelity. Do not regress WHERE/QUALIFY/ORDER, CTE driving tables,
  dependency closure, join operators, compiler receipts/hashes, or Apply cards.
- Selective October 14 teammate zip merge from
  `C:/Users/ankur.sinha/Downloads/bbi-mig-ai-workbench-develop-8300e985-20261014.zip`:
  fonts/typography, safe sign-in/session UI, tour engine/content/targets, pinned
  searches, titles/icons, and current control guidance. Older zip logic that
  removed newer SQL/CTE safeguards was intentionally excluded.
- Auto-map recipe Cortex Search bootstrap inclusion. Do not omit this from
  deployment/bootstrap preparation.

Do not attribute every dirty file to this session. The parity baseline already
contained 45 modified tracked files plus untracked work; current tree is larger.

### 4. Original parity fixes now implemented locally

1. Provenance/config baseline: correct FEATURE source root, dirty-source hashes,
   host/worker transport versus model-message limits, registry checks and release
   fingerprint helper. The prior image DID contain the transport fix; the claim
   that dirty source was absent was corrected with hashes.
2. Imported joins: whole-expression SQLGlot representability converts ordinary
   equality/AND/comparison joins to normal controls. Reversed operands retain
   operator meaning. Complex OR/function/multi-relation predicates remain intact
   in explicit SQL fallback; no partial extraction that drops terms.
3. Original CTE names: retain original spelling/quoting separately from durable
   IDs/aliases. Compiler removes safe exact self-wrappers and performs lexical,
   bound renaming. Preserve legitimate `cte_` prefixes; avoid accumulating
   `cte_cte_...`. Collisions/name capture/unsafe shapes keep stable aliases.
4. Compile & Validate is independent of optional semantic refresh. Prepared YAML
   is reused; optional optimization failure warns instead of hiding valid SQL.
5. Access-, selection-, revision-, and invalidation-scoped semantic reuse:
   fixed-age validity, bounded cache/locks, coalescing, stale in-flight refresh
   protection, current derived revisions, full-snapshot equality handling.
6. Oversized CHAT: request-local exact-section store and bounded typed backend
   retrieval with snapshot/section hashes, nested paths, ranges and continuation.
   Full serialized-message budget includes history/checkpoints/envelope. Required
   rules are not truncated; omitted older history is disclosed. Bad ranges return
   bounded corrective errors, not HTTP 500. Invalid optional null bundle metadata
   is warned/rejected without inventing a bundle or discarding the answer.
7. Remaining safe zip changes: pinned source/target/CTE library searches, shared
   title/icon styling, dashboard Agent tour, mapping source/rule/confidence tour
   targets, Query Preview/SQL edit/validate/optimize/run guidance.
8. Release settings/docs are prepared, but actual release acceptance is OPEN.

Important files (relative to FEATURE):

- `services/sttm-builder/app/core/query_scope_contract.py`
- `services/sttm-builder/app/core/mapping_sql.py`
- `services/sttm-builder/app/core/prepared_context.py`
- `services/sttm-builder/app/core/semantic_context.py`
- `services/sttm-builder/app/core/assistant_context.py`
- `services/sttm-builder/app/core/assistant_retrieval.py`
- `services/sttm-builder/app/core/conversation_continuity.py`
- `services/sttm-builder/app/routers/sttm_builder.py`
- `services/sttm-builder/app/schema/sttm_builder.py`
- `frontend/src/features/sttm/shared/scoped-join.ts`
- `frontend/src/features/sttm/source-target/scoped-sql-editor.ts`
- `frontend/src/features/sttm/source-target/join-modal.tsx`
- `frontend/src/features/sttm/mapping/sql-upload-workspace.ts`
- `frontend/src/features/sttm/mapping/review-semantic-context.ts`
- `frontend/src/features/sttm/mapping/mapping-utils.ts`
- `frontend/src/features/sttm/context/workbench-context.ts`
- `frontend/src/features/sttm/store/sttm-builder-slice.ts`
- `frontend/src/app/sttm/builder/new/mapping/page.tsx`
- `frontend/middleware.ts`, `start-ai-workbench-dev.ps1`
- `scripts/workbench_release_manifest.py`

Local browser auth loop was fixed ONLY for development + explicit
`LOCAL_DEV_AUTH_ENABLED=true` + loopback. Remote/production cookie guards and
backend authorization remain. No fake auth cookie was used.

### 5. Exact Auto-map retrieval implemented, but singleton architecture REJECTED

Architecture goal: small current-workspace authority -> historical Search
discovery -> canonical evidence hydration/applicability -> exact semantic/CTE
reads -> mapping decisions -> backend evidence/binding/compiler validation.
Missing evidence means explicit unresolved targets, never guessed successes.

Current implementation is behind `AUTOMAP_CONTEXT_RETRIEVAL_V1=false` by default:

- `app/core/automap_retrieval.py`: immutable request-local exact store, hashes,
  legal namespace, domain identities, backend cursors, lossless path/value pages,
  mandatory corrections/negative/linked evidence, semantic/dependency validation.
- Nested real `attribute_semantic_model` indexing; original YAML retained.
- Large table contracts deferred to exact reads instead of duplicated inline.
- Target-filtered learning/execution duplicate evidence fixed.
- Exact repeated-record AND repeated-string dictionaries, collision protection,
  round-trip tests; no summarization or authority rewrite.
- Workspace population dependency includes exact query-shaping fields, not
  unrelated chat/other-target outcomes; original full workspace remains stored.
- Missing private CTE parents recovered ONLY from exact top-level WITH AST bodies
  already embedded in selected SQL. Dependency evidence only, NOT new selectable
  sources. Genuinely absent parents remain errors.
- Builder invokes application-handled `meta.delegation.tool=AUTO_MAP_CONTEXT`,
  not a registered Snowflake native retrieval tool. Fresh physical threads use
  exact reconstructed evidence and complete-message budgeting.
- Validation includes read completion, target/source/structural semantics,
  mandatory negative evidence, citations/precedent support and compiler binding.
- Optional Analyst is prepared-only, backend-mediated, selected-scope/read-only
  SQL checked; generated SQL and executed factual rows are distinct.

Critical CURRENT defects to replace, not preserve:

- `auto_mapping_proxy.py:_build_batches` near 1414 returns singleton batches
  when the retrieval flag is enabled.
- `sttm_builder.py:_invoke_retrieval_auto_map` near 1028 loops over each target
  sequentially and runs separate per-target model/read loops.
- `invoke_auto_map_parallel` is not a fix: it calls one invoke and then repair /
  complex-transformation stages. Larger envelopes alone would retain hidden
  per-target serialization.
- `AutoMapContext.read` accepts one operation; manifest template covers first
  target; protocol says independent targets.
- `evidence_ids()` currently unions ALL read targets. Before shared batch use,
  make citation authorization target-aware.
- Exact case handling needs careful quoted/unquoted regression tests.
- Planner/invoker lossless projection needs consistency.
- Timeout checks between calls and network timeouts do NOT prove hard whole-job
  cancellation across client retries/Search/SQL work.

### 6. Approved NEW batching plan (implement next)

The user requires **3-4 TOTAL batches per mapping job, concurrently**, not per
instance, not singleton targets, and not hidden target model loops. Small mappings
can use fewer. Preserve current two SPCS instances. Aim to recover the previous
roughly two-minute behavior, but claim only measured results.

Tasks:

1. Capture failed acceptance and disable singleton rollout.
2. Implement three/four balanced concurrent worker batches.
3. Vectorize exact retrieval across each target batch.
4. Validate target evidence without redundant round trips.
5. Align specs, bootstrap, runtime settings and supported live development sync.
6. Verify full application accuracy and latency.

Requirements:

- One batch-level model loop; a turn returns multi-read delegation OR multi-target
  decisions. NO outer sequential target model loop.
- One governed exact store per batch; shared current graph/contracts/population /
  dependencies reused once, historical evidence still target-scoped.
- Bounded exact multi-read list, per-operation scope/hash validation, exact pages
  and opaque cursors, explicit errors, no unbounded session parallelism.
- Batch discovery/canonical hydration using caller session/bound parameters;
  prepare current profile/applicability once per batch, not per column.
- Prepare deterministic mandatory reads together; aggregate deficits for all
  targets into one continuation; do not ask one model turn per known identity.
- Validate each target separately, including structural semantics, citations,
  negative evidence, Value approvals and exact CTE closure. No accuracy shortcut.
- Plan on same lossless bounded manifest used at invocation. If a group exceeds
  required-message budget, expose the exact blocker; do not silently split to
  dozens of worker calls or truncate it.
- Keep durable single-dispatcher lease across replicas. Persist/check resume
  identity using target set + context hash + NEW strategy version, so old
  singleton partials cannot merge into a new batch layout.
- Enforce per-JOB in-flight cap three/four. Do not claim an unimplemented
  account-wide cap across unrelated jobs.
- Bound model rounds, retrieval work, full messages and wall time honestly.
- Preserve optional prepared-only backend Analyst; no native shared rebinding.
- Offline actual-request replay FIRST, bounded real batch probe SECOND, full
  frontend app acceptance ONLY once the probe is viable.

Outdated tests MUST change: `len(batches)==37`, singleton sizes, and scripted
37-target private-worker `len(agent.calls)==148` describe the rejected design.
Replace with <=4 batches, concurrent dispatch, vectorized rounds, ordering,
resume validation, foreign scope rejection, target citation isolation, lossless
pages/dictionaries, negative corrections and CTE/case tests.

### 7. Live agents, bootstrap and Analyst decisions

User specifically required local specs + bootstrap + Snowflake to agree.
SUPPORTED development save/readback/publish completed for:

- `FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA.AGT_SOURCE_MAPPING`
- `FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA.AGT_STTM_BUILDER`

Preserved actual tools/resources/model/budgets. Source mapping:
`claude-haiku-4-5`, 200 seconds / 16000 tokens, no native tools/resources;
published VERSION$2/default LAST at that checkpoint. Builder preserved four tools:
`SearchWorkbenchRag`, `SearchFIRKnowledge`, `AGT_SOURCE_MAPPING`,
`AGT_TRANSFORMATION_RULE`. Search resources remain CSS_WORKBENCH_RAG (5),
CSS_FIR_KNOWLEDGE (8); subagent procedures remain existing bindings.

Native Analyst was NOT restored. Analyst is an optional actual-data specialist
for factual uniqueness/join multiplication/value equivalence/count questions,
not a general recipe/history/registry JSON reader. Do not query every target or
rebind one shared native Analyst tool to whichever mapping last ran.

Files:

- `infra/snowflake/agents/agent_spec_source_mapping.yaml`
- `infra/snowflake/agents/agent_spec_sttm_builder.yaml`
- `scripts/bootstrap_sttm_metadata_infra.py`
- `scripts/sync_workbench_agent_specs.py`
- `infra/snowflake/env/client.env.example`

Bootstrap legacy all-bundle Analyst restoration is now explicit opt-in
`--restore-bundle-analyst-tools`, not default. Recipe Search bootstrap retained.
The CURRENT instructions still describe old per-target reads. Update to batched
multi-read contract, then supported read/write/save/readback/publish in development
while preserving non-instruction fields/comments. Do not run broad bootstrap or
handwrite mutation SQL as a shortcut.

Backups: `.dev-cache/agent-spec-sync/*.before.yaml`.
Windows helper registers workspace with short instruction-free content, writes
complete structured YAML, verifies round-trip, then saves/readbacks COMPLETE
spec. Necessary because full builder YAML exceeds command-line length; no
instruction truncation. agent-write output filename must be relative.

Temporary official checksum-verified CLI, no PATH/permanent install:
`C:/Users/ankur.sinha/AppData/Local/Temp/workbench-cortex-cli-20261015/coco-1.2.14+213013.25aeae2a44ca-windows-amd64/cortex.exe`.

Live routing test proved builder EXPLAINS backend Analyst delegation; it did NOT
prove actual factual Analyst execution or new batching accuracy.

### 8. Actual acceptance results: do not confuse completion with correctness

- Strict ACCOUNT identity probe: ID, ISDELETED, MASTERRECORDID correctly bound,
  exact semantic reads + real Search, four calls EACH, approximately 43-46s each.
  This did not establish full HOUSEHOLD accuracy/performance.
- Earlier actual app failure job `727aeec8-f48f-423b-8764-924142b75139`:
  37 targets, 14 batches, zero completed, 88.6s, generic AUTO_MAPPING_JOB_FAILED.
  Ran before new flag enablement. Root cause not conclusively obtained; zero
  completed batches does not mean no dispatch.
- Initial new path rejected before job creation: LEGACY_ID__C manifest 134492
  chars exceeded model budget. Exact deferred table-contract fix reduced real
  one-target manifest to 77587 chars; lossless factoring later about 65974.
- FULL APPLICATION singleton experiment:
  job `e2e6c20a-17b5-47d9-b661-04cbbda7b271`, 37 targets, 37 singleton batches,
  completed after **1557 seconds, ALL 37 unresolved**. Browser 20-minute safety
  timeout did not cancel durable backend job. Explicit accuracy/latency FAILURE.
- Saved real LEGACY replays remained unresolved: bounded time, missing embedded
  CTE parents (fixed), then full-message overflow. Latest thread
  `f20b6d97-8130-47e7-9930-18bf9f31c50b`, four reads, still overflow. Do not call
  the CTE repair successful mapping acceptance.
- No more full singleton runs. Flag is disabled again in local backend process.

Tests:

- Latest retrieval focused suite: **30 passed** before new redesign.
- Last proper full backend run: **826 passed, 3 inherited failures, 3 warnings**,
  28.12s; BEFORE all latest follow-up retrieval edits. Rerun after implementation.
- Inherited failures: protected deployer missing STTM_MAPPING_BULK_WRITE_V1 export;
  protected deployer batch fallback !=16; Windows POSIX 0600 assertion.
  Do not edit protected script to make these green.
- Prior parity: eight frontend Node harnesses, TypeScript, focused lint and
  production Next build passed; 23 static pages. Not a fresh new-engine result.
- Nine API compile roundtrips for accounts/cte_accounts/cte_cte_accounts passed.
- Plain ACCOUNT WHERE 1=0 validation passed, but original semantic ambiguity
  cause remains unreproduced.
- Live oversized CHAT tail retrieval and follow-up passed on explicit 200K
  fixture; not arbitrary mapping/Analyst accuracy.

### 9. Current application and protected baseline

Browser: `http://127.0.0.1:3000/sttm/builder/9601/mapping`.
Project 2301, mapping 9601, Deep Agent Test TMD Baseline / 01-EverNest-HHs.
Target `FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD`, 37 target columns.
Initial browser snapshot: 32 mapping rows, 13 derived-source records, five
relationships, 415764 characters. Persisted localStorage backup:
`automap-acceptance-backup-9601-20261015` -> {key, raw, capturedAt}.
Original key:
`sttm-builder-session-v7::439278407::2301::9601::snapshot_305ecd2ba0934dfabc37`.

Sources/derived definitions and relationships checked unchanged during test.
Some unresolved partials changed browser mapping statuses; do NOT assume initial
rows are still current or final job results all applied after browser timeout.
Inspect before next test; do not overwrite backup or click duplicate jobs.

Last verified listeners: backend PID11928:8000, frontend PID14888:3000.
Backend terminal `c0d91c9c-d6c8-49b5-90c1-b32848c068ef`; frontend terminal
`91a2a7f0-4063-4b93-b28c-d6904e2ae68a`. Recheck processes in next chat.
Backend FEATURE, no reload, MAIN .env.local unchanged, process overrides:
APP_ENV=local; DEV_SNAPSHOT_CACHE_MODE=off;
AUTOMAP_CONTEXT_RETRIEVAL_V1=false; AUTO_MAPPING_SERVICE_URL=inprocess;
CORS loopback3000; REQUESTS_CA_BUNDLE points to MAIN virtualenv certifi/cacert.pem.
Use MAIN `services/sttm-builder/.venv/Scripts/python.exe` and absolute FEATURE
app-dir. Local inprocess worker route is `/api/v1/auto-mapping/invoke`.
SPCS uses explicit internal URL, not inprocess.

Main frontend durable route: `/api/v1/workbench/auto-map-jobs`; GET by job ID.
Private worker: `app/auto_mapping_worker/router.py` -> invoke_auto_map_parallel.
Frontend polls durable state/partials; timeout extension is NOT performance fix.

### 10. Snowflake specifics and actual request shape

Account MHSUEJT-GD01711, user ANKURSINHA, connection client-spcsv1;
role FFP_HDP_DLAB_DB_DEPLOY_ROLE_DEV;
database FFP_HDP_DLAB_DB_DEV;
warehouse FFP_HDP_DLAB_DB_ADHOC_XS_WH_DEV.

Recipe Search:
`FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA.CSS_AUTOMAP_RECIPES_V1`, last verified
ACTIVE indexing/serving, 91 rows, PATTERN_ID key, five-minute lag,
snowflake-arctic-embed-m-v1.5; source TBL_FIR_TARGET_MAPPING_PATTERNS.
Attributes TARGET_TABLE/TARGET_COLUMN/SCOPE/PROJECT_ID/STTM_ID.
Search owner-rights/filtering is NOT sufficient authorization; hydrate canonical
evidence and enforce scope/lifecycle/trust/applicability server-side.

Jobs table: `FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA.TBL_AUTO_MAP_JOBS`.
Metadata is in JOB_STATE JSON: request_envelope/context/project_id, sttm_id,
attribute_count, batch_count, completed counts, partial_responses, response,
error, stage, timings_ms. Inspect real schema/JSON before writing queries.

Registry namespace SCH_STTM_MCP: LATEST_TABLE_REGISTRY_V,
LATEST_COLUMN_REGISTRY_V, LATEST_NATIVE_VIEWS. Actual registry field SEMANTIC_VIEW,
not guessed SEMANTIC_MODEL. ACCOUNT raw semantic record 441540 chars, 475 rich
attributes, 61619 chars PK evidence; source SCH_TRANSFORM_SOURCE.ACCOUNT.

Actual HOUSEHOLD request: execution_context ~1949303 chars;
learning_context ~1948778; semantic_context ~452499; workspace_context ~350591;
relation_graph ~58574. 93 target recipes ~1938277 chars. Execution/learning
recipes were identical before target filtering; large historical SQL/dependencies
explain size, not merely final expressions.

Selected CTEs UserMaster/HHMaster/ReferralMaster/SOURCE; aliases cte_usermaster /
cte_hhmaster / cte_referralmaster / cte_source.
SOURCE identity `sql-cte:bd6e58f163c8:statement:0/scope:12:SOURCE`, exact SQL 9939
chars, nine private embedded parents: BillingAddress, FamilyHOH,
PrefContactMethod, Drinks, PetName, ContactMadeAwareofFocus,
AllTaxIDsHaveClientContactRecord, SIGNEDAdvisoryAgreement,
FocusLanguageInvestmentAgreement. Preserve exact identities/SQL.

Read-only helpers:
`scripts/inspect_automap_manifest.py` (--env-file, --job-id, --live-target);
`scripts/test_automap_scoped_live.py` (--env-file, --targets, --live, --live-search).
The existing inspect helper selects ONE target and bypasses frontend job save;
adapt/add batched offline replay deliberately, don't present it as app acceptance.

### 11. Complete next-deployment scope and release gates

Next authorized release must include intended inherited work + parity fixes +
accepted new batching code, frontend and backend together, AND corresponding
bootstrap/agent instructions/config/tests/docs. Do not deploy only a backend
patch from MAIN or rebuild bare HEAD and omit dirty/untracked intended files.

- Inventory all relevant diffs/untracked files, including fonts/tours/assistant
  modules/tests/scripts. Exclude secrets, caches, logs, backup YAML and generated
  artifacts deliberately; don't blindly git add everything.
- Generate fresh `scripts/workbench_release_manifest.py` evidence after final
  edits. Old fingerprint2154350f/tag suggestions are STALE. Use unique dirty-source
  build tag and per-file hashes, not reused bare dad856f.
- Align both host and worker: transport4MiB; reviewed registry views; bounded
  model packet/full-message budgets; accepted new three/four-batch strategy and
  cap; retrieval flag only enabled after acceptance. Do not carry old singleton
  instructions or old batch-size config as final batching acceptance.
- Preserve SPCS authentication/custom OAuth, roles, warehouse, registry/internal
  worker URL and compute pool. Do not transplant local credentials/TLS settings.
- Historical deployment mismatch was transport1MiB vs local4MiB. Transport and
  model limits are DIFFERENT; model120000chars/131072bytes local vs submitted
  200000/262144 does not justify raising model context blindly.
- Preserve unchanged safe deployer. Existing external process export workaround
  for STTM_MAPPING_BULK_WRITE_V1=true is documented; don't edit renderer.
- Build/test paired host+worker backend and frontend from FEATURE and verify
  exact hashes/digests/config through permitted access after authorized rollout.
- Worker service WORKBENCH_AUTOMAP_DEV; webapp AI_WORKBENCH_OKTA_WEBAPP_DEV_v4;
  namespace FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA;
  compute pool WORKBENCH_COMPUTE_POOL_DEV. Current two worker instances stay.
- Historical images are NOT this release: backend/worker
  sha256:3d5466b73b84d8b70fb0b31426187b968d3a27781f4607755a617a19367016ef;
  frontend sha256:e15e91eeff99bf1117da9f4d74f2ee95866f178da4190b9ef49be5941b5814ca.
- Monitoring currently denied by RSS USER SPECIFIED lacking MONITOR. Do not
  bypass; separately authorized/available monitoring is a release gate.

Still OPEN: new batched engine; target-aware shared evidence; real-request packet
fit; full HOUSEHOLD business accuracy/latency; factual Analyst acceptance; exact
ACCOUNT ambiguity reproduction; imported join edit/save/reopen browser workflow;
complete tour/browser acceptance; fresh full test/build/manifest; actual permitted
SPCS deployment verification. Job completed/HTTP200/mock tests are not substitutes.

### 12. Exactly where work stopped

After the latest Execute approval, the assistant read plans/code, verified dirty
tree and 8000/3000 listeners, registered six authoritative batching tasks in the
todo tool (task1 in_progress, rest pending), and changed ONLY the failed-acceptance
paragraph in `docs/automap-scoped-retrieval.md` to record1557s/37unresolved and
disabled singleton rollout. Then the user requested this handoff and paused.
This handoff and its `.gitignore` allowlist are the only additional file changes.

NO new batching implementation edits occurred. Task1 was NOT marked complete;
don't invent progress. No server restart, full rerun, new live spec sync, commit,
push, SPCS deployment, mapping publish or scaling in this last execution segment.
The attached older five-item checklist is superseded by the approved six-task
batching plan; track authoritative tasks and update completion immediately.

Resume: inspect current diffs/runtime/baseline, finish task1 verification, then
implement the balanced scheduler AND actual vectorized model/multi-read engine,
not just displayed batch counts. Test offline, review, sync intended development
instructions through supported lifecycle, bounded real batch, then full mapping
9601 in app. Record preparation/Search/model/transformation/finalization time,
model-call count, exact packet size, grounded/unresolved rate, bindings/rules/null
handling/population/Value approvals and comparison evidence. Report failures
honestly and keep the next release gated until viable.

## Memory references for Cortex Code

Project memory directory:
`/memories/projects/Users-ankur.sinha-Desktop-bbi-workbench-dev-ffp-ai-mig-workbench/`.
Read MEMORY.md, batching-handoff.md, automap-retrieval-implementation.md and
parity-implementation.md as needed. Older chronological entries are superseded
where they conflict with this checkpoint. Use required skills for agent, SQL,
Snowpark or frontend tasks before the corresponding operations.