"""Catch worker-only import failures before a queued run waits indefinitely."""


def test_durable_worker_entrypoint_imports() -> None:
    from app import agent_worker_main

    assert callable(agent_worker_main.main)


def test_worker_restarts_expired_sessions_without_a_tight_crash_loop() -> None:
    from app.agent_worker_main import _expired_worker_session, _worker_restart_delay

    assert _expired_worker_session(RuntimeError("390114: Authentication token has expired"))
    assert not _expired_worker_session(RuntimeError("Temporary query timeout"))
    assert [_worker_restart_delay(attempt) for attempt in (1, 2, 3, 6, 20)] == [1, 2, 4, 30, 30]
