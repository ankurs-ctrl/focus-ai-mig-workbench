import socket
import time
from types import SimpleNamespace

from app.agent_runs.wake import WorkerWakeListener, notify_workers


def _free_udp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]


def test_queued_run_wakes_an_idle_worker_before_its_poll_timeout() -> None:
    settings = SimpleNamespace(migration_agent_wake_port=_free_udp_port(), migration_agent_max_concurrency=1)
    listener = WorkerWakeListener(settings, 0)
    try:
        notify_workers(settings)
        started = time.monotonic()
        assert listener.wait(5.0) is True
        assert time.monotonic() - started < 1.0
        # A burst is coalesced; the next wait is a plain timeout.
        assert listener.wait(0.05) is False
    finally:
        listener.close()


def test_disabled_wake_port_keeps_plain_polling() -> None:
    settings = SimpleNamespace(migration_agent_wake_port=0, migration_agent_max_concurrency=2)
    listener = WorkerWakeListener(settings, 0)
    notify_workers(settings)  # no-op, never raises
    started = time.monotonic()
    assert listener.wait(0.05) is False
    assert time.monotonic() - started >= 0.04
    listener.close()


def test_unavailable_wake_port_falls_back_to_polling() -> None:
    port = _free_udp_port()
    settings = SimpleNamespace(migration_agent_wake_port=port, migration_agent_max_concurrency=1)
    owner = WorkerWakeListener(settings, 0)
    try:
        second = WorkerWakeListener(settings, 0)
        assert second.wait(0.02) is False
        second.close()
    finally:
        owner.close()
