"""Bounded, cited retrieval over run-owned parsed attachments."""
from __future__ import annotations

import json
import re
from typing import Any


def load_scoped_attachments(session: Any, attachment_ids: list[str], owner_user_id: str, tenant_id: str) -> list[dict[str, Any]]:
    """Load parsed manifests in one scoped metadata read; never read the stage path."""
    ids = list(dict.fromkeys(str(value) for value in attachment_ids if str(value)))[:20]
    if not ids:
        return []
    placeholders = ", ".join("?" for _ in ids)
    rows = session.sql(
        f"""SELECT ATTACHMENT_ID, ATTACHMENT_PAYLOAD FROM TBL_AGENT_ATTACHMENTS
        WHERE ATTACHMENT_ID IN ({placeholders}) AND OWNER_USER_ID = ? AND TENANT_ID = ?
        AND SCAN_STATUS = 'clean' AND PARSER_STATUS = 'parsed'""",
        [*ids, owner_user_id, tenant_id],
    ).collect()
    found: dict[str, dict[str, Any]] = {}
    for raw_row in rows:
        row = raw_row.as_dict() if hasattr(raw_row, "as_dict") else dict(raw_row)
        payload = row.get("ATTACHMENT_PAYLOAD") or row.get("attachment_payload") or {}
        found[str(row.get("ATTACHMENT_ID") or row.get("attachment_id"))] = (
            json.loads(payload) if isinstance(payload, str) else payload
        )
    if any(attachment_id not in found for attachment_id in ids):
        raise PermissionError("An attachment is unavailable or outside the initiating user's scope")
    return [found[attachment_id] for attachment_id in ids]


def retrieve_attachment_evidence(attachments: list[dict[str, Any]], query: str, *, limit: int = 8) -> list[dict[str, Any]]:
    """Record-sized pieces (transcript turns, sheet rows, SQL statements, paragraph groups) ranked by the query.

    A piece that shares no term with the query is not returned; with no usable
    terms, the first pieces of each file are.
    """
    from app.agent_runs.attachment_facts import records

    terms = {term for term in re.findall(r"[A-Za-z_][A-Za-z_0-9]{2,}", query.upper())
             if term not in {"THE", "AND", "FOR", "WITH", "FROM", "USE", "THIS", "THAT"}}
    chunks: list[dict[str, Any]] = []
    for attachment in attachments:
        filename = str(attachment.get("filename") or attachment.get("FILENAME") or "attachment")
        attachment_id = str(attachment.get("attachment_id") or attachment.get("ATTACHMENT_ID") or "")
        pieces = records(attachment)
        if not pieces:
            manifest = attachment.get("parsed_manifest") or {}
            if isinstance(manifest, str):
                manifest = json.loads(manifest)
            source = json.dumps(manifest.get("atomized") or {}, default=str, ensure_ascii=False)
            pieces = [{"section": f"characters {start + 1}-{min(start + 4000, len(source))}", "text": source[start:start + 4000]}
                      for start in range(0, len(source), 4000)]
        for piece in pieces:
            text = str(piece.get("text") or "")
            if piece.get("speaker") or piece.get("timestamp"):
                # A transcript turn is read with who said it and when.
                prefix = " ".join(filter(None, [f"[{piece['timestamp']}]" if piece.get("timestamp") else "",
                                                f"{piece['speaker']}:" if piece.get("speaker") else ""]))
                text = f"{prefix} {text}"
            chunk = {
                "section": piece["section"], "text": text[:4000],
                "attachment_id": attachment_id, "filename": filename,
                "evidence_id": f"attachment:{attachment_id}#{piece['section']}",
                "content_hash": attachment.get("content_hash") or attachment.get("CONTENT_HASH"),
            }
            for key in ("speaker", "timestamp"):
                if piece.get(key):
                    chunk[key] = piece[key]
            chunks.append(chunk)
    if not terms:
        return chunks[:max(0, limit)]
    ranked = []
    for index, chunk in enumerate(chunks):
        haystack = (chunk["text"] + " " + chunk["filename"]).upper()
        score = sum(1 for term in terms if term in haystack)
        if score:
            ranked.append((score, index, chunk))
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return [chunk for _, _, chunk in ranked[:max(0, limit)]]
