"""Shared integrations must survive combining the Deep Agent release."""
from app.core.config import Settings
from app.core.datahub import DataHubAdapter


def test_deep_configuration_keeps_existing_datahub_disabled_path():
    settings = Settings(_env_file=None, DATAHUB_ENABLED=False)
    assert DataHubAdapter(settings).build_context(source_tables=[], derived_source_ids=[]) is None


def test_existing_datahub_overrides_survive_deep_settings():
    settings = Settings(_env_file=None, DATAHUB_ENABLED=True,
        DATAHUB_GRAPHQL_URL='https://metadata.example/graphql', DATAHUB_UI_URL='https://metadata.example',
        DATAHUB_TOKEN='fixture-only', DATAHUB_DATASET_ENV='UAT', DATAHUB_TIMEOUT_SECONDS=7)
    assert settings.datahub_enabled and settings.datahub_dataset_env == 'UAT'
    assert settings.datahub_graphql_url.endswith('/graphql')
    assert settings.datahub_ui_url == 'https://metadata.example'
    assert settings.datahub_token == 'fixture-only' and settings.datahub_timeout_seconds == 7
    assert DataHubAdapter(settings).build_context(source_tables=[], derived_source_ids=[]) is None
