"""Bounded local OCR for attachment pages and images."""
from __future__ import annotations

import io
import subprocess
import time

from PIL import Image, ImageOps

MAX_OCR_PAGES = 8
MAX_IMAGE_PIXELS = 24_000_000


def _recognize(image: Image.Image, timeout: float) -> str:
    if image.width * image.height > MAX_IMAGE_PIXELS:
        raise ValueError("Image dimensions exceed the OCR limit")
    image = ImageOps.exif_transpose(image)
    image.thumbnail((2400, 2400))
    encoded = io.BytesIO()
    image.convert("RGB").save(encoded, format="PNG")
    result = subprocess.run(
        ["tesseract", "stdin", "stdout", "--psm", "3"],
        input=encoded.getvalue(), capture_output=True, check=True, timeout=timeout,
    )
    return result.stdout.decode("utf-8", errors="replace").strip()


def recognize_pdf_page(content: bytes, page: int, timeout: float) -> str:
    deadline = time.monotonic() + timeout
    raster = subprocess.run(
        ["pdftoppm", "-f", str(page), "-l", str(page),
         "-scale-to", "1800", "-singlefile", "-png", "-"],
        input=content, capture_output=True, check=True, timeout=min(timeout, 4),
    )
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return ""
    with Image.open(io.BytesIO(raster.stdout)) as image:
        return _recognize(image, min(remaining, 6))


def recognize_image(content: bytes, extension: str) -> tuple[str, list[int]]:
    formats = {".png": ["PNG"], ".jpg": ["JPEG"], ".jpeg": ["JPEG"], ".tif": ["TIFF"], ".tiff": ["TIFF"]}
    deadline = time.monotonic() + 25
    with Image.open(io.BytesIO(content), formats=formats[extension]) as image:
        pages = []
        omitted = []
        frame_count = getattr(image, "n_frames", 1)
        for index in range(min(frame_count, MAX_OCR_PAGES)):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                omitted.extend(range(index + 1, min(frame_count, MAX_OCR_PAGES) + 1))
                break
            image.seek(index)
            try:
                text = _recognize(image, min(remaining, 5))
            except subprocess.TimeoutExpired:
                text = ""
            if text:
                pages.append(f"[page {index + 1}]\n{text}")
            else:
                omitted.append(index + 1)
        if frame_count > MAX_OCR_PAGES:
            omitted.extend(range(MAX_OCR_PAGES + 1, min(frame_count, MAX_OCR_PAGES + 250) + 1))
        return "\n".join(pages), omitted
