from __future__ import annotations

import asyncio
from typing import Any

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from app.agent_runtime import model_adapter


def _capture_model(
    monkeypatch: pytest.MonkeyPatch,
    *,
    model: str = "claude-sonnet-4-5",
    **overrides: Any,
) -> dict[str, Any]:
    captured: dict[str, Any] = {}

    def fake_chat_open_ai(**kwargs: Any) -> dict[str, Any]:
        captured.update(kwargs)
        return captured

    monkeypatch.setattr(model_adapter, "SnowflakeCortexChatOpenAI", fake_chat_open_ai)
    model_adapter.build_snowflake_cortex_model(
        host="acme.snowflakecomputing.com",
        oauth_token="test-token",
        model=model,
        **overrides,
    )
    captured["http_client"].close()
    asyncio.run(captured["http_async_client"].aclose())
    return captured


def test_local_session_token_uses_snowflake_authorization_header(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured = _capture_model(monkeypatch, auth_mode="snowflake_token")

    assert captured["default_headers"] == {
        "Authorization": 'Snowflake Token="test-token"',
    }


def test_delegated_oauth_uses_oauth_token_type_header(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured = _capture_model(monkeypatch, auth_mode="oauth_bearer")

    assert captured["default_headers"] == {
        "X-Snowflake-Authorization-Token-Type": "OAUTH",
    }
    assert "model_kwargs" not in captured
    assert "disable_streaming" not in captured


def test_unknown_auth_mode_is_rejected() -> None:
    with pytest.raises(ValueError, match="Unsupported Snowflake Cortex auth mode"):
        model_adapter.build_snowflake_cortex_model(
            host="acme.snowflakecomputing.com",
            oauth_token="test-token",
            model="claude-sonnet-4-5",
            auth_mode="unexpected",
        )


def test_reasoning_effort_is_only_sent_to_openai_models(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    anthropic = _capture_model(monkeypatch, reasoning_effort="low")
    assert "reasoning_effort" not in anthropic

    openai = _capture_model(
        monkeypatch,
        model="openai-gpt-5.2",
        reasoning_effort="high",
    )
    assert openai["reasoning_effort"] == "high"


def test_completed_tool_history_is_normalized_without_losing_results() -> None:
    messages = [
        SystemMessage(content="Use governed tools."),
        HumanMessage(content="Find the best loan source."),
        AIMessage(
            content="I will inspect the catalog.",
            tool_calls=[
                {
                    "id": "call-1",
                    "name": "search_catalog",
                    "args": {"query": "loan income"},
                    "type": "tool_call",
                }
            ],
        ),
        ToolMessage(
            content='{"matches":["DB.SCHEMA.LOAN"]}',
            tool_call_id="call-1",
        ),
    ]

    normalized = model_adapter.normalize_cortex_tool_history(messages)

    assert not any(isinstance(message, ToolMessage) for message in normalized)
    assert not any(
        isinstance(message, AIMessage) and message.tool_calls for message in normalized
    )
    assert any(
        isinstance(message, HumanMessage)
        and "Verified result from search_catalog" in str(message.content)
        and "DB.SCHEMA.LOAN" in str(message.content)
        for message in normalized
    )


def test_full_plan_output_limit_is_explicit_and_configurable(monkeypatch):
    assert _capture_model(monkeypatch)["max_completion_tokens"] == 16_384
    assert _capture_model(monkeypatch, max_completion_tokens=8192)["max_completion_tokens"] == 8192


@pytest.mark.parametrize("reason", ["length", "max_tokens", "max_completion_tokens"])
def test_truncated_decision_is_not_executed_or_silently_retried(reason):
    from types import SimpleNamespace
    from app.agent_runtime.execution import ExecutionBudget, SharedBudgetMiddleware, ModelOutputTruncatedError
    events = []
    middleware = SharedBudgetMiddleware(ExecutionBudget(model_limit=5, tool_limit=10),
                                       trace=lambda event, *_: events.append(event))
    response = SimpleNamespace(result=[AIMessage(content="incomplete", response_metadata={"finish_reason": reason})])
    with pytest.raises(ModelOutputTruncatedError):
        middleware.wrap_model_call(SimpleNamespace(messages=[], tools=[]), lambda _: response)
    assert "model.truncated" in events


def test_complete_decision_is_preserved():
    from types import SimpleNamespace
    from app.agent_runtime.execution import ExecutionBudget, SharedBudgetMiddleware
    middleware = SharedBudgetMiddleware(ExecutionBudget(model_limit=5, tool_limit=10))
    response = SimpleNamespace(result=[AIMessage(content="complete", response_metadata={"finish_reason": "stop"})])
    assert middleware.wrap_model_call(SimpleNamespace(messages=[], tools=[]), lambda _: response) is response
