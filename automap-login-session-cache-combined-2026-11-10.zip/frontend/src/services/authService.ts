import { onCacheIdentityChange, cacheScope, setCacheIdentity, reportSessionFailure } from '@/services/session-cache-scope';
import { AppError } from '@/api/errors/app-error';
import { getApiData } from '@/api/axiosInstance';
import { API_ROUTES } from '@/api/routes';
import type { PermissionSet, UserSession } from '@/types/user';

// v3 was sessionStorage (cleared on tab close); v4 is localStorage (persists across sessions).
const STTM_BUILDER_SESSION_STORAGE_KEY_LEGACY = "sttm-builder-session-v3";
const STTM_BUILDER_SESSION_STORAGE_KEY = "sttm-builder-session-v4";
/** Persists session display_name across reloads until logout. */
const AUTH_DISPLAY_NAME_STORAGE_KEY = "sttm-auth-display-name";
/** Persists the session role label (e.g. "Admin") across reloads until logout. */
const AUTH_ROLE_STORAGE_KEY = "sttm-auth-role";
// Refresh verified identity in the background; this does not expire cached data
// or sign the user out. Backend authorization remains authoritative on every API.
const AUTH_SESSION_REFRESH_INTERVAL_MS = 5 * 60 * 1000;

let cachedUserSession: { value: UserSession; refreshAt: number } | null = null;
let pendingUserSession: Promise<UserSession> | null = null;
let sessionGeneration = 0;

/** Non-secret scope for in-flight reads; never share across logout or identity changes. */
export function getAuthenticatedReadScope(): string | null {
  const session = cachedUserSession?.value;
  return session ? JSON.stringify([sessionGeneration,session.user_id,session.app_persona,session.snowflake_role ?? null]) : null;
}

function resolveDisplayName(session: UserSession): string {
  const fromProfile = (session.display_name || "").trim();
  if (fromProfile) return fromProfile;
  return (session.email || "").trim();
}

export function getStoredDisplayName(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.localStorage.getItem(AUTH_DISPLAY_NAME_STORAGE_KEY);
    const trimmed = value?.trim() || "";
    return trimmed || null;
  } catch {
    return null;
  }
}

export function persistDisplayName(session: UserSession): string | null {
  const displayName = resolveDisplayName(session);
  if (!displayName || typeof window === "undefined") {
    return displayName || null;
  }
  try {
    window.localStorage.setItem(AUTH_DISPLAY_NAME_STORAGE_KEY, displayName);
  } catch {
    // Ignore storage write failures (private mode / quota).
  }
  return displayName;
}

export function clearStoredDisplayName() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(AUTH_DISPLAY_NAME_STORAGE_KEY);
  } catch {
    // Ignore storage cleanup failures.
  }
}

/** Header label for a session persona, e.g. "ADMIN" -> "Admin". */
export function formatPersonaLabel(persona: string | null | undefined): string | null {
  const value = (persona || "").trim();
  if (!value) return null;
  return `${value.charAt(0).toUpperCase()}${value.slice(1).toLowerCase()}`;
}

/** Last known role label (e.g. "Admin"), kept like the display name until logout. */
export function getStoredRole(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(AUTH_ROLE_STORAGE_KEY)?.trim() || null;
  } catch {
    return null;
  }
}

function persistRole(session: UserSession) {
  const role = formatPersonaLabel(session.app_persona);
  if (!role || typeof window === "undefined") return;
  try {
    window.localStorage.setItem(AUTH_ROLE_STORAGE_KEY, role);
  } catch {
    // Ignore storage write failures (private mode / quota).
  }
}

function clearStoredRole() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(AUTH_ROLE_STORAGE_KEY);
  } catch {
    // Ignore storage cleanup failures.
  }
}

export function clearBrowserWorkbenchSession() {
  sessionGeneration += 1;
  setCacheIdentity(null);
  cachedUserSession = null;
  pendingUserSession = null;
  clearStoredDisplayName();
  clearStoredRole();
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.localStorage.removeItem(STTM_BUILDER_SESSION_STORAGE_KEY);
    window.localStorage.removeItem("sttm-cache-identity");
    // Also clear the legacy sessionStorage key if it still exists.
    window.sessionStorage.removeItem(STTM_BUILDER_SESSION_STORAGE_KEY_LEGACY);
    window.sessionStorage.removeItem("sttm.activeSemanticContext");
  } catch {
    // Ignore browser storage cleanup failures.
  }
}

export type SnowflakeContext = {
  current_user: string;
  current_role?: string | null;
  current_warehouse?: string | null;
  current_database?: string | null;
  current_schema?: string | null;
};

export type UserRolesResponse = {
  app_roles: string[];
  active_app_role?: string | null;
  data_roles: string[];
};

export const authService = {
  getSession: async (forceRefresh = false): Promise<UserSession> => {
    if (!forceRefresh && cachedUserSession && cacheScope()) {
      const cached = cachedUserSession;
      if (cached.refreshAt <= Date.now() && !pendingUserSession) {
        void authService.getSession(true).catch((error: unknown) => {
          if (cachedUserSession !== cached) return; // A prior login must not evict a newer one.
          if (error instanceof AppError && [401,403].includes(error.payload.statusCode ?? 0)) {
            setCacheIdentity(null);
            reportSessionFailure(error);
          } else if (cachedUserSession === cached) {
            cached.refreshAt = Date.now()+30_000; // Bounded retry after a transient outage.
          }
        });
      }
      return cached.value;
    }
    if (pendingUserSession) return pendingUserSession;
    const generation = sessionGeneration;
    const pending = getApiData<UserSession>(API_ROUTES.auth.session, {
      skipGlobalError: true,
    })
      .then((value) => {
        if (generation !== sessionGeneration) throw new Error('Authenticated session changed.');
        const nextIdentity = JSON.stringify([value.user_id, value.app_persona, value.snowflake_role ?? null]);
        const priorIdentity = cacheScope();
        let persistedIdentity: string | null = null;
        try { persistedIdentity = window.localStorage.getItem('sttm-cache-identity'); } catch { /* Browser storage is optional. */ }
        if ((priorIdentity && priorIdentity !== nextIdentity) || (persistedIdentity && persistedIdentity !== nextIdentity))
          clearBrowserWorkbenchSession();
        setCacheIdentity(nextIdentity);
        try { window.localStorage.setItem('sttm-cache-identity', nextIdentity); } catch { /* Browser storage is optional. */ }
        if (priorIdentity && priorIdentity !== nextIdentity && typeof window !== 'undefined')
          window.location.reload(); // Redux/page state must also leave the previous identity.
        persistDisplayName(value);
        persistRole(value);
        cachedUserSession = {
          value,
          refreshAt: Date.now() + AUTH_SESSION_REFRESH_INTERVAL_MS,
        };
        return value;
      })
      .finally(() => {
        if (pendingUserSession === pending) pendingUserSession = null;
      });
    pendingUserSession = pending;
    return pending;
  },

  getPermissions: async (): Promise<PermissionSet> => {
    return getApiData<PermissionSet>(API_ROUTES.auth.permissions);
  },

  getSnowflakeContext: async (): Promise<SnowflakeContext> => {
    return getApiData<SnowflakeContext>(API_ROUTES.auth.snowflakeContext);
  },

  getUserRoles: async (): Promise<UserRolesResponse> => {
    return getApiData<UserRolesResponse>(API_ROUTES.user.roles);
  },

  getLoginUrl: (next = "/dashboard"): string => {
    const encodedNext = encodeURIComponent(next);
    return `/api${API_ROUTES.auth.login}?next=${encodedNext}`;
  },

  getStoredDisplayName,

  getStoredRole,

  logout: (): void => {
    clearBrowserWorkbenchSession();
    // Backend clears the session cookie and redirects to AUTH_POST_LOGOUT_REDIRECT_PATH (/home).
    window.location.assign(`/api${API_ROUTES.auth.logout}`);
  },
};

onCacheIdentityChange(() => {
  if (cacheScope() !== null) return;
  sessionGeneration++;
  cachedUserSession = null;
  pendingUserSession = null;
});

// Another tab can log out or select a different user/role. Drop this tab's
// verified reads and Redux state without rewriting the other tab's new identity.
if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
  window.addEventListener('storage', (event) => {
    if (event.key !== 'sttm-cache-identity' || (event.storageArea && event.storageArea !== window.localStorage)) return;
    if ((cacheScope() !== null && event.newValue === cacheScope()) || (!cacheScope() && !pendingUserSession)) return;
    setCacheIdentity(null);
    window.location.reload();
  });
}
