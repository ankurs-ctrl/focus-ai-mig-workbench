import type { DatabaseNode, DerivedSource, TableNode } from '@/features/sttm/types/sttm.types';

function flattenSelectedSourceTables(branch: DatabaseNode[]): TableNode[] {
  const selected: TableNode[] = [];
  for (const db of branch) {
    for (const schema of db.schemas) {
      for (const table of schema.tables) {
        if (table.isSelected) {
          selected.push({ ...table });
        }
      }
    }
  }
  return selected;
}

export function collectSelectedSourceQualifiedNames(branch: DatabaseNode[]): string[] {
  return flattenSelectedSourceTables(branch).map((table) => table.qualifiedName);
}

export function getSelectedSourceTables(branch: DatabaseNode[]): TableNode[] {
  return flattenSelectedSourceTables(branch);
}

export function getSelectedTargetTable(branch: DatabaseNode[]): TableNode | undefined {
  for (const db of branch) {
    for (const schema of db.schemas) {
      for (const table of schema.tables) {
        if (table.isSelected) {
          return table;
        }
      }
    }
  }
  return undefined;
}

export function resolveBuilderSelectionState(state: {
  sourceDatabases: DatabaseNode[];
  targetDatabases: DatabaseNode[];
  sources: TableNode[];
  targets: TableNode[];
  derivedSources: DerivedSource[];
}) {
  const selectedSourceTables = getSelectedSourceTables(state.sourceDatabases);
  const resolvedSourceTables =
    selectedSourceTables.length > 0
      ? selectedSourceTables
      : state.sources.filter((table) => table.isSelected);

  const selectedTargetTable =
    getSelectedTargetTable(state.targetDatabases) ??
    state.targets.find((table) => table.isSelected);

  const canProceedToMapping =
    (resolvedSourceTables.length > 0 ||
      state.derivedSources.some((source) => source.isSelected)) &&
    Boolean(selectedTargetTable);

  return {
    resolvedSourceTables,
    selectedTargetTable,
    canProceedToMapping,
  };
}
