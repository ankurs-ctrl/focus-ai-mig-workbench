# Latest develop integration — V18

Cumulative over V17. Built from latest fetched CodeCommit develop 9568db8 plus our source commit 308047d. The merge had zero textual conflicts, including the shared project_service.py file.

Preserved team changes: Kalyani (kbmore1, ffdaf2d) project-wise sequential mapping display numbers, stable no-op-save ordering and local read-cache invalidation; Abhishek (ece4392) searchable Firm Value selection, create/reuse from Mapping, and duplicate stored-value validation; Ajith (b533939, 4ea4e6e, merged at 9568db8) saved manual 100% display, retained grouping while edits save, and a separate Unmapped confidence group.

Integration corrections preserve their behavior. Fixed optional sx array typing in the shared select component. Updated regression harnesses for the team's new timestamp helper, confidence rank state and summary-cache mutation fencing. Added an assertion that explicit Auto-map regeneration clears the manual display flag. Fixed an intent guard that assumed every test run object had error/status fields; explicit completed-run diagnosis protection remains.

Final merged verification: 4851 backend core tests passed, 31 skipped; 562 frontend tests passed; current and reconstructed baseline-(3) TypeScript passed. This does not claim new SPCS or business-data acceptance. All prior release limitations remain explicit in their notes.

The integration uses a normal merge and non-forced develop push, preserving the team commit ancestry. UAT is not changed by this integration. The verified remote commit is recorded in the delivery chat/ZIP manifest. No environment files, credentials or client Snowflake objects are synchronized. Local dependencies and worker lock files are excluded.

Use this cumulative overlay rather than V17 when deploying with the latest team changes. Build matching frontend/API/workers. V18 adds no environment variable, metadata table, grant or bootstrap requirement. Keep previous deployment prerequisites. Older release statements about working-tree/unpushed status describe those historical releases; consult this integration's verified commit for current status.
