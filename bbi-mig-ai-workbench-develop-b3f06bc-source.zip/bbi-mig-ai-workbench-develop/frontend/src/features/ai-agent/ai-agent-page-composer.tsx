"use client";

import { useRef, useState } from "react";
import { InputBase, ListItemIcon, ListItemText, MenuList } from "@mui/material";
import {
  AiaBox,
  AiaDivider,
  AiaIconButton,
  AiaMenu,
  AiaMenuItem,
  AiaStack,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import { AI_AGENT_PAGE_CONTENT_MAX_WIDTH } from "@/features/ai-agent/ai-chat-layout-constants";
import {
  AddRoundedIcon,
  CheckRoundedIcon,
  ChecklistRtlRoundedIcon,
  FileUploadOutlinedIcon,
  KeyboardArrowDownRoundedIcon,
  NorthIcon,
  SmartToyIcon,
} from "@/utils/icons";

type ChatMode = "plan" | "agent";

type EffortOption = {
  id: string;
  label: string;
  description: string;
};

type ModelOption = {
  id: string;
  label: string;
};

const EFFORT_OPTIONS: EffortOption[] = [
  {
    id: "auto",
    label: "Auto",
    description: "Balances quality and cost. Recommended for most work.",
  },
  {
    id: "high",
    label: "High effort",
    description: "Deeper reasoning for hard tasks. Highest quality, highest cost.",
  },
  {
    id: "medium",
    label: "Medium effort",
    description: "Solid quality for everyday work. Good balance of speed and depth.",
  },
  {
    id: "low",
    label: "Low effort",
    description: "Faster responses at lower cost. Best for simple questions.",
  },
];

const MODEL_OPTIONS: ModelOption[] = [
  { id: "cortex", label: "Cortex" },
];

type AiAgentPageComposerProps = {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  disabled?: boolean;
  loading?: boolean;
  /** Centered under empty-state greeting vs docked at bottom of chat. */
  placement?: "docked" | "centered";
  placeholder?: string;
  /** Outer content width. Use full container width in project browse. */
  contentMaxWidth?: number | string;
};

export function AiAgentPageComposer({
  value,
  onChange,
  onSend,
  disabled = false,
  loading = false,
  placement = "docked",
  placeholder = "Ask or build anything...",
  contentMaxWidth = AI_AGENT_PAGE_CONTENT_MAX_WIDTH,
}: AiAgentPageComposerProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [plusAnchor, setPlusAnchor] = useState<null | HTMLElement>(null);
  const [modelAnchor, setModelAnchor] = useState<null | HTMLElement>(null);
  const [chatMode, setChatMode] = useState<ChatMode>("agent");
  const [effortId, setEffortId] = useState(EFFORT_OPTIONS[0].id);
  const [modelId, setModelId] = useState<string | null>(null);

  const canSend = !loading && !disabled && value.trim().length > 0;
  const selectedEffort = EFFORT_OPTIONS.find((option) => option.id === effortId);
  const selectedModel = MODEL_OPTIONS.find((option) => option.id === modelId);
  const selectionLabel = selectedModel?.label ?? selectedEffort?.label ?? "Auto";

  const closePlusMenu = () => setPlusAnchor(null);
  const closeModelMenu = () => setModelAnchor(null);

  return (
    <AiaBox
      sx={{
        flexShrink: 0,
        px: placement === "centered" ? 0 : { xs: 2, md: 3 },
        pb: placement === "centered" ? 0 : 2.5,
        pt: placement === "centered" ? 0 : 1,
        width: "100%",
      }}
    >
      <AiaBox sx={{ width: "100%", maxWidth: contentMaxWidth, mx: "auto" }}>
        <AiaBox
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 1,
            px: 1.75,
            pt: 1.5,
            pb: 1.25,
            borderRadius: "24px",
            border: "1px solid #E2E8F0",
            backgroundColor: "#FFFFFF",
            boxShadow: "0 1px 2px rgba(15, 23, 42, 0.04)",
          }}
        >
          <InputBase
            multiline
            minRows={2}
            maxRows={6}
            value={value}
            onChange={(event) => onChange(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                if (canSend) onSend();
              }
            }}
            placeholder={placeholder}
            disabled={disabled || loading}
            fullWidth
            sx={{
              ...textStyleCssVars("body"),
              alignItems: "flex-start",
              "& .MuiInputBase-input": {
                padding: "2px 4px",
                fontSize: 15,
                lineHeight: 1.5,
                color: "#0F172A",
              },
              "& .MuiInputBase-input::placeholder": {
                color: "#94A3B8",
                opacity: 1,
              },
            }}
          />

          <AiaStack
            direction="row"
            spacing={1}
            sx={{ alignItems: "center", justifyContent: "space-between" }}
          >
            <AiaIconButton
              size="small"
              aria-label="Add options"
              title="Add options"
              disabled={disabled || loading}
              onClick={(event) => setPlusAnchor(event.currentTarget)}
              sx={{
                width: 34,
                height: 34,
                border: "1px solid #E2E8F0",
                borderRadius: "50%",
                color: "#334155",
                backgroundColor: "#FFFFFF",
                "&:hover": { backgroundColor: "#F8FAFC" },
              }}
            >
              <AddRoundedIcon sx={{ fontSize: 20 }} />
            </AiaIconButton>

            <AiaStack direction="row" spacing={0.75} sx={{ alignItems: "center" }}>
              <AiaBox
                component="button"
                type="button"
                disabled={disabled || loading}
                onClick={(event) => setModelAnchor(event.currentTarget)}
                sx={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 0.35,
                  border: "none",
                  background: "transparent",
                  cursor: disabled || loading ? "default" : "pointer",
                  color: "#64748B",
                  px: 0.75,
                  py: 0.5,
                  borderRadius: "999px",
                  "&:hover": {
                    backgroundColor: disabled || loading ? "transparent" : "#F8FAFC",
                  },
                }}
              >
                <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#64748B" }}>
                  {selectionLabel}
                </AiaText>
                <KeyboardArrowDownRoundedIcon sx={{ fontSize: 18, color: "#94A3B8" }} />
              </AiaBox>

              <AiaIconButton
                aria-label="Send message"
                onClick={onSend}
                disabled={!canSend}
                sx={{
                  width: 36,
                  height: 36,
                  flexShrink: 0,
                  backgroundColor: canSend ? "#BFDBFE" : "#E2E8F0",
                  color: canSend ? "#1D4ED8" : "#94A3B8",
                  "&:hover": {
                    backgroundColor: canSend ? "#93C5FD" : "#E2E8F0",
                  },
                  "&.Mui-disabled": {
                    backgroundColor: "#E2E8F0",
                    color: "#94A3B8",
                  },
                }}
              >
                <NorthIcon sx={{ fontSize: 20 }} />
              </AiaIconButton>
            </AiaStack>
          </AiaStack>
        </AiaBox>

        <input
          ref={fileInputRef}
          type="file"
          hidden
          multiple
          onChange={() => {
            if (fileInputRef.current) fileInputRef.current.value = "";
          }}
        />

        <AiaMenu
          anchorEl={plusAnchor}
          open={Boolean(plusAnchor)}
          onClose={closePlusMenu}
          anchorOrigin={{ vertical: "top", horizontal: "left" }}
          transformOrigin={{ vertical: "bottom", horizontal: "left" }}
          slotProps={{
            paper: {
              sx: {
                mt: -0.5,
                minWidth: 280,
                width: 300,
                borderRadius: "12px",
                border: "1px solid #E2E8F0",
                backgroundColor: "#FFFFFF",
                boxShadow: "0 8px 24px rgba(15, 23, 42, 0.12)",
              },
            },
          }}
        >
          <MenuList dense sx={{ py: 0.5 }}>
            <AiaMenuItem
              selected={chatMode === "plan"}
              onClick={() => {
                setChatMode("plan");
                closePlusMenu();
              }}
              sx={{ py: 1.1, px: 1.5 }}
            >
              <ListItemIcon sx={{ minWidth: 34 }}>
                <ChecklistRtlRoundedIcon sx={{ fontSize: 18, color: "#475569" }} />
              </ListItemIcon>
              <ListItemText
                primary="Plan mode"
                slotProps={{
                  primary: { sx: { fontSize: 13, fontWeight: 600, color: "#0F172A" } },
                }}
              />
              {chatMode === "plan" ? (
                <CheckRoundedIcon sx={{ fontSize: 16, color: "#2563EB" }} />
              ) : null}
            </AiaMenuItem>
            <AiaMenuItem
              selected={chatMode === "agent"}
              onClick={() => {
                setChatMode("agent");
                closePlusMenu();
              }}
              sx={{ py: 1.1, px: 1.5 }}
            >
              <ListItemIcon sx={{ minWidth: 34 }}>
                <SmartToyIcon sx={{ fontSize: 18, color: "#475569" }} />
              </ListItemIcon>
              <ListItemText
                primary="Agent mode"
                slotProps={{
                  primary: { sx: { fontSize: 13, fontWeight: 600, color: "#0F172A" } },
                }}
              />
              {chatMode === "agent" ? (
                <CheckRoundedIcon sx={{ fontSize: 16, color: "#2563EB" }} />
              ) : null}
            </AiaMenuItem>
            <AiaDivider sx={{ my: 0.5 }} />
            <AiaMenuItem
              onClick={() => {
                closePlusMenu();
                fileInputRef.current?.click();
              }}
              sx={{ py: 1.1, px: 1.5 }}
            >
              <ListItemIcon sx={{ minWidth: 34 }}>
                <FileUploadOutlinedIcon sx={{ fontSize: 18, color: "#475569" }} />
              </ListItemIcon>
              <ListItemText
                primary="Upload"
                slotProps={{
                  primary: { sx: { fontSize: 13, fontWeight: 600, color: "#0F172A" } },
                }}
              />
            </AiaMenuItem>
          </MenuList>
        </AiaMenu>

        <AiaMenu
          anchorEl={modelAnchor}
          open={Boolean(modelAnchor)}
          onClose={closeModelMenu}
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
          transformOrigin={{ vertical: "bottom", horizontal: "right" }}
          slotProps={{
            paper: {
              sx: {
                mt: -0.5,
                minWidth: 320,
                maxWidth: 360,
                maxHeight: 420,
                borderRadius: "12px",
                border: "1px solid #E2E8F0",
                backgroundColor: "#FFFFFF",
                boxShadow: "0 8px 24px rgba(15, 23, 42, 0.12)",
              },
            },
          }}
        >
          <MenuList dense sx={{ py: 0.75 }}>
            <AiaText
              sx={{
                px: 2,
                pb: 0.75,
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: 0.5,
                color: "#94A3B8",
              }}
            >
              EFFORT
            </AiaText>
            {EFFORT_OPTIONS.map((option) => {
              const selected = modelId == null && effortId === option.id;
              return (
                <AiaMenuItem
                  key={option.id}
                  selected={selected}
                  onClick={() => {
                    setEffortId(option.id);
                    setModelId(null);
                    closeModelMenu();
                  }}
                  sx={{ alignItems: "flex-start", py: 1.1 }}
                >
                  <ListItemText
                    primary={option.label}
                    secondary={option.description}
                    slotProps={{
                      primary: {
                        sx: { fontSize: 13, fontWeight: 650, color: "#0F172A" },
                      },
                      secondary: {
                        sx: {
                          fontSize: 11.5,
                          color: "#94A3B8",
                          lineHeight: 1.4,
                          whiteSpace: "normal",
                        },
                      },
                    }}
                  />
                  {selected ? (
                    <CheckRoundedIcon sx={{ fontSize: 16, color: "#2563EB", mt: 0.35 }} />
                  ) : null}
                </AiaMenuItem>
              );
            })}
            <AiaBox sx={{ height: 8 }} />
            <AiaText
              sx={{
                px: 2,
                pb: 0.75,
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: 0.5,
                color: "#94A3B8",
              }}
            >
              MODELS
            </AiaText>
            {MODEL_OPTIONS.map((option) => {
              const selected = modelId === option.id;
              return (
                <AiaMenuItem
                  key={option.id}
                  selected={selected}
                  onClick={() => {
                    setModelId(option.id);
                    closeModelMenu();
                  }}
                  sx={{ py: 1.1 }}
                >
                  <ListItemText
                    primary={option.label}
                    slotProps={{
                      primary: {
                        sx: { fontSize: 13, fontWeight: 650, color: "#0F172A" },
                      },
                    }}
                  />
                  {selected ? (
                    <CheckRoundedIcon sx={{ fontSize: 16, color: "#2563EB" }} />
                  ) : null}
                </AiaMenuItem>
              );
            })}
          </MenuList>
        </AiaMenu>
      </AiaBox>
    </AiaBox>
  );
}
