from app.agent_runs.reference_compare import (
    OutputColumn,
    bind_variables,
    column_key,
    comparison_sql,
    key_column,
    output_columns,
    pair_columns,
    prepare_for_learning,
    reference_query,
    select_of,
    split_statements,
    summarize,
)

SCRIPT = """---- TMD Buisness Accounts
Set MigrationMasterSchema = 'SCH_REDTAIL_TMD_MASTER';
SET LegacyHHcPrefix = 'TMD_RT_'; -- keep this under 14!
SET BackupOwnerID = '005Qi00000bvarUIAQ';  // TMD default
SET CoreMigrationDatabase = 'FFP_HDP_CRM_MIG_DB_DEV';
USE DATABASE IDENTIFIER($CoreMigrationDatabase);
SET UserMasterTable = CONCAT($MigrationMasterSchema , '.MAPPER_USER');
WITH USER_MASTER AS (SELECT * FROM IDENTIFIER($UserMasterTable))
, SOURCE AS (
  select 'BAID_'||C.id as LegacyCRMID, c.writing_advisor_id as Owner  // Added by John G.
  from CONTACTS c
  LEFT JOIN EMAILS e ON e.emailable_id = c.id AND e.address <> 'email$email.com'
  where c.deleted = 0
)
SELECT DISTINCT
    $LegacyHHcPrefix || SOURCE.LegacyCRMID AS "Legacy_ID__c"
  , IFNULL(mu.TARGET_CRM_ID, $BackupOwnerID) AS "OwnerId"
  , SOURCE.Owner AS Owner
FROM SOURCE LEFT JOIN USER_MASTER mu ON SOURCE.Owner = mu.WRITING_ADVISOR_ID
-- )
"""


def test_split_statements_ignores_semicolons_in_strings_and_comments():
    parts = split_statements("SET a = 'x;y'; -- c;\nSELECT 1 // z;\n; SELECT ';'")
    assert parts == ["SET a = 'x;y'", "SELECT 1", "SELECT ';'"]


def test_reference_query_binds_variables_but_not_dollars_in_strings():
    ref = reference_query(SCRIPT)
    assert ref.variables["USERMASTERTABLE"] == "SCH_REDTAIL_TMD_MASTER.MAPPER_USER"
    assert "FROM SCH_REDTAIL_TMD_MASTER.MAPPER_USER" in ref.query
    assert "'TMD_RT_' || SOURCE.LegacyCRMID" in ref.query
    assert "IFNULL(mu.TARGET_CRM_ID, '005Qi00000bvarUIAQ')" in ref.query
    assert "'email$email.com'" in ref.query
    assert ref.use_statements == ["USE DATABASE FFP_HDP_CRM_MIG_DB_DEV"]
    assert ref.unresolved == []


def test_overrides_flow_into_derived_variables():
    ref = reference_query(SCRIPT, overrides={"MigrationMasterSchema": "DB.SCH_TMD_SOURCE"})
    assert "FROM DB.SCH_TMD_SOURCE.MAPPER_USER" in ref.query


def test_unknown_variables_are_reported_and_left_alone():
    sql, missing = bind_variables("SELECT $Known, $Missing", {"KNOWN": "v"})
    assert sql == "SELECT 'v', $Missing"
    assert missing == ["Missing"]


def test_output_columns_keep_case_sensitivity():
    columns = output_columns(reference_query(SCRIPT).query)
    assert columns == [OutputColumn("Legacy_ID__c", True), OutputColumn("OwnerId", True), OutputColumn("Owner", False)]
    assert columns[0].reference == '"Legacy_ID__c"'
    assert columns[2].reference == "OWNER"


def test_select_of_drops_insert_column_list():
    sql = "INSERT INTO DB.S.T (A, B) WITH x AS (SELECT 1) SELECT 1 AS A, 2 AS B FROM x;"
    assert select_of(sql) == "WITH x AS (SELECT 1) SELECT 1 AS A, 2 AS B FROM x"


def test_column_key_pairs_xx_original_value_columns():
    assert column_key("XXogCOMPANYState") == column_key("OGCOMPANYSTATE")
    assert column_key("Legacy_ID__c") == column_key("LEGACY_ID__C")
    assert column_key("xxxOwnerName") == "OWNERNAME"


def test_pair_columns_reports_unpaired_sides():
    ref = [OutputColumn("Legacy_ID__c", True), OutputColumn("Phone", True), OutputColumn("XXogCOMPANYState", True)]
    agent = [OutputColumn("LEGACY_ID__C", False), OutputColumn("OGCOMPANYSTATE", False), OutputColumn("EXTRA", False)]
    pairs, ref_only, agent_only = pair_columns(ref, agent)
    assert [(r.name, a.name) for r, a in pairs] == [("Legacy_ID__c", "LEGACY_ID__C"), ("XXogCOMPANYState", "OGCOMPANYSTATE")]
    assert [c.name for c in ref_only] == ["Phone"]
    assert [c.name for c in agent_only] == ["EXTRA"]
    assert key_column(ref).name == "Legacy_ID__c"


def test_comparison_sql_is_one_select_over_both_queries():
    ref = [OutputColumn("Legacy_ID__c", True)]
    agent = [OutputColumn("LEGACY_ID__C", False)]
    pairs, _, _ = pair_columns(ref, agent)
    sql = comparison_sql("SELECT 'a' AS \"Legacy_ID__c\"", "SELECT 'a' AS LEGACY_ID__C", pairs,
                         reference_key=ref[0], agent_key=agent[0])
    assert sql.startswith("WITH ref AS (")
    assert 'NULLIF(TRIM(TO_VARCHAR("Legacy_ID__c")), \'\') AS K' in sql
    assert "'matched_keys'" in sql and "'value_match'" in sql


def test_prepare_for_learning_resolves_tables_but_keeps_firm_values():
    script = prepare_for_learning(SCRIPT, source_schema="DB.SRC", overrides={"MigrationMasterSchema": "DB.SRC"})
    assert "DB.SRC.MAPPER_USER" in script.sql
    assert "DB.SRC.CONTACTS" in script.sql and "DB.SRC.EMAILS" in script.sql
    assert "$LegacyHHcPrefix" in script.sql and "$BackupOwnerID" in script.sql
    assert "'email$email.com'" in script.sql
    assert script.firm_values == {"LegacyHHcPrefix": "TMD_RT_", "BackupOwnerID": "005Qi00000bvarUIAQ"}
    assert script.source_tables == ["DB.SRC.CONTACTS", "DB.SRC.EMAILS", "DB.SRC.MAPPER_USER"]


def test_prepare_for_learning_points_shared_lookups_at_project_copies():
    script = prepare_for_learning(
        "SELECT s.State_Code AS \"BillingState\" FROM CONTACTS c "
        "LEFT JOIN FFP_HDP_CRM_MIG_DB_DEV.SCH_OPS.STATE_CODES s ON s.STATE = c.STATE",
        source_schema="DB.SRC",
        table_overrides={"FFP_HDP_CRM_MIG_DB_DEV.SCH_OPS.STATE_CODES": "DB.SRC.STATE_CODES"},
    )
    assert "SCH_OPS" not in script.sql
    assert script.source_tables == ["DB.SRC.CONTACTS", "DB.SRC.STATE_CODES"]


def test_prepare_for_learning_expands_final_star_and_moves_schemas():
    script = prepare_for_learning(
        "WITH SOURCE AS (SELECT m.ID AS \"Household__c\", $LegacyHHcPrefix || m.ID AS \"Legacy_Id__c\", "
        "'Active' AS Status FROM OLD_DB.MASTER.MAPPER_HH_MASTER m) SELECT * FROM SOURCE",
        source_schema="DB.SRC", table_overrides={"OLD_DB.MASTER": "DB.SRC"},
    )
    assert [c.name for c in output_columns(script.sql)] == ["Household__c", "Legacy_Id__c", "Status"]
    assert script.source_tables == ["DB.SRC.MAPPER_HH_MASTER"]


def test_summarize_reports_overlap_and_agreement():
    result = {"reference_rows": 10, "agent_rows": 12, "reference_keys": 10, "matched_keys": 5,
              "columns": [{"value_match": 1.0, "distinct_overlap": 0.5}, {"value_match": 0.5, "distinct_overlap": 0.1}]}
    row = summarize("T", result, ["Phone"], [])
    assert row["key_overlap"] == 0.5
    assert row["columns_agreeing"] == 1
    assert row["mean_value_match"] == 0.75
    assert row["reference_only_columns"] == ["Phone"]
