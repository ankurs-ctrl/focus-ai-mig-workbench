"""Host-owned test coverage and read-only assertions; specialist output is a proposal."""
from collections import Counter
from pathlib import PurePosixPath
from typing import Any

from app.core.sql_execution_guard import sql_hash


def audit_test_artifacts(data: dict[str, Any], target_columns: list[str]) -> dict[str, Any]:
    expected = set(target_columns)
    cases = data.get('test_case_document') or []
    ids = Counter(str(case.get('test_case_id') or '') for case in cases)
    covered = {str(case.get('target_attribute') or '') for case in cases}
    issues = []
    if data.get('status') != 'completed':
        issues.append('specialist_generation_incomplete')
    if not cases:
        issues.append('no_test_cases')
    if '' in ids or any(count > 1 for count in ids.values()):
        issues.append('missing_or_duplicate_test_identity')
    if expected - covered:
        issues.append('target_coverage_incomplete')
    if covered - expected:
        issues.append('unassigned_target_attribute')
    paths = []
    for artifact in data.get('seed_files') or []:
        path = str(artifact.get('file_path') or '')
        parts = PurePosixPath(path).parts
        if not path or path.startswith('/') or '\\' in path or ':' in path or '..' in parts:
            issues.append('unsafe_artifact_path')
        paths.append(path)
    if len(paths) != len(set(paths)):
        issues.append('duplicate_artifact_path')
    return {'passed': not issues, 'issues': sorted(set(issues)),
            'uncovered_targets': sorted(expected - covered), 'execution_status': 'not_run',
            'business_correctness_verified': False}


def contract_test_queries(sql: str, columns: list[dict], key_columns: list[str]) -> list[dict]:
    """Only existing contract nullability/keys become assertions; no inferred rules."""
    source = sql.strip().rstrip(';')
    names = {str(column['name']) for column in columns}
    if set(key_columns) - names:
        raise ValueError('Test keys are outside the target contract')
    def quoted(name):
        return '"' + name.replace('"', '""') + '"'
    tests = []
    for column in columns:
        name = str(column['name'])
        if column.get('nullable') is False or name in key_columns:
            tests.append({'test_id': 'not_null:' + name, 'kind': 'not_null', 'columns': [name],
                'sql': f'SELECT COUNT(*) AS CHECKED_ROWS, COALESCE(COUNT_IF({quoted(name)} IS NULL),0) AS VIOLATIONS FROM (\n{source}\n) AS MAPPING_TEST'})
    if key_columns:
        group = ','.join(quoted(name) for name in key_columns)
        tests.append({'test_id': 'unique:target_key', 'kind': 'unique', 'columns': key_columns,
            'sql': f'SELECT COALESCE(SUM(N),0) AS CHECKED_ROWS, COALESCE(SUM(GREATEST(N-1,0)),0) AS VIOLATIONS FROM (SELECT COUNT(*) AS N FROM (\n{source}\n) AS MAPPING_TEST GROUP BY {group}) AS KEY_GROUPS'})
    for test in tests:
        test['mapping_sql_hash'] = sql_hash(source)
        test['test_sql_hash'] = sql_hash(test['sql'])
    return tests


def evaluate_test_rows(rows: list[dict]) -> dict:
    if len(rows) != 1:
        raise ValueError('A contract assertion must return exactly one aggregate row')
    value = {str(key).upper(): item for key, item in rows[0].items()}
    checked, violations = value.get('CHECKED_ROWS'), value.get('VIOLATIONS')
    if checked is None or violations is None or int(checked) < 0 or int(violations) < 0:
        raise ValueError('Invalid assertion result')
    return {'status': 'failed' if int(violations) else 'passed' if int(checked) else 'inconclusive',
            'checked_rows': int(checked), 'violations': int(violations)}
