import re
from types import SimpleNamespace

import pytest

from app.core.mapping_sql import MappingSqlService
from app.core.snowflake_analyst import SnowflakeAnalystResponse
from app.schema.common import TableRef
from app.schema.mapping_sql import (
    MappingSqlCompileRequest,
    MappingSqlMappingItem,
    MappingSqlParseRequest,
    MappingSqlPreviewRequest,
    MappingSqlReviewRequest,
)
from app.schema.sttm_builder import (
    RelationEdge,
    RelationGraphContext,
    RelationNode,
    RelationNodeKind,
    RelationshipConditionItem,
    ValueBinding,
)


@pytest.mark.parametrize("value", ["O'Brien", "C:\\new\\folder", "\\'Example\\'", "ends\\"])
def test_constant_literal_round_trips_without_interpreting_escapes(value):
    from sqlglot import parse_one

    rendered = MappingSqlService._compile_constant(value, "VARCHAR")
    assert parse_one(rendered, read="snowflake").this == value


def test_invalid_mapping_expression_reports_target_without_literal():
    node = RelationNode(relation_id="DB.SRC.T", alias="src", kind="PHYSICAL_TABLE",
                        table=TableRef(database="DB", schema="SRC", table="T"))
    request = MappingSqlCompileRequest(
        relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column="RESULT", expression="'private_unterminated")],
    )
    with pytest.raises(ValueError, match="RESULT") as error:
        MappingSqlService(session=None, analyst_client=None).compile(request)
    assert "private_unterminated" not in str(error.value)


@pytest.mark.parametrize("value, expected", [(None, "NULL"), ("", "NULL"), ("$Firm", "$Firm"), ("42", "42")])
def test_constant_escaping_preserves_existing_null_placeholder_numeric_contract(value, expected):
    assert MappingSqlService._compile_constant(value, "NUMBER") == expected


def test_compile_route_sanitizes_token_errors():
    import app.api  # noqa: F401
    from app.routers.mapping_sql import compile_mapping_sql
    from app.core.exceptions import AppValidationError
    from sqlglot.errors import TokenError

    class BrokenCompiler:
        def compile(self, payload):
            raise TokenError("private literal must not escape")

    with pytest.raises(AppValidationError) as error:
        compile_mapping_sql(MappingSqlCompileRequest(relation_graph=RelationGraphContext(),
                            mappings=[MappingSqlMappingItem(target_column="RESULT", expression="1")]),
                            None, BrokenCompiler(), None)
    assert "could not be parsed" in str(error.value)
    assert "private literal" not in str(error.value)


def test_embedded_parent_dependency_retains_enclosing_population_sql():
    parent = 'sql-cte:upload/scope:1:Filtered'
    sql = 'WITH outer_source AS (WITH Filtered AS (SELECT ID FROM DB.SRC.T WHERE ID > 0) SELECT ID FROM Filtered) SELECT ID FROM outer_source'
    node = RelationNode(relation_id='sql-cte:upload/scope:2:outer_source', alias='src', kind='CTE',
                        sql_text=sql, parent_relation_ids=[parent], output_columns=[{'name':'ID'}])
    result = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column='RESULT', source_columns=['src.ID'], source_dependencies=[parent])]))
    assert result.ready
    assert 'ID > 0' in result.preview_sql
    assert result.required_relation_ids == [node.relation_id]


@pytest.mark.parametrize('case', ['unknown', 'unused', 'ambiguous', 'quoted-mismatch'])
def test_embedded_parent_dependency_fails_closed(case):
    parent = 'sql-cte:upload/scope:1:Filtered'
    sql = 'WITH Filtered AS (SELECT ID FROM DB.SRC.T) SELECT ID FROM Filtered'
    if case == 'unused': sql = 'WITH Filtered AS (SELECT ID FROM DB.SRC.T) SELECT 1 AS ID'
    if case == 'quoted-mismatch': sql = 'WITH "filtered" AS (SELECT ID FROM DB.SRC.T) SELECT ID FROM "filtered"'
    node = RelationNode(relation_id='owner', alias='src', kind='CTE', sql_text=sql,
                        parent_relation_ids=[] if case == 'unknown' else [parent])
    nodes = {'owner':node}
    if case == 'ambiguous': nodes['other'] = node.model_copy(update={'relation_id':'other','alias':'other'})
    assert MappingSqlService._resolve_dependency_relation(parent, nodes, {'SRC':'owner'}) is None


def test_exact_relation_dependency_is_not_misread_as_column():
    node = RelationNode(relation_id='DB.SRC.T', alias='src', kind='PHYSICAL_TABLE',
                        table=TableRef(database='DB', schema='SRC', table='T'))
    assert MappingSqlService._resolve_dependency_relation('DB.SRC.T', {node.relation_id:node}, {'SRC':node.relation_id}) == node.relation_id


class _Query:
    def collect(self):
        return []


class _Session:
    def sql(self, _query):
        return _Query()


@pytest.mark.parametrize('name', ['accounts', 'cte_accounts', 'cte_cte_accounts', '"Case.Name"'])
def test_uploaded_cte_output_preserves_original_name_without_self_wrapper(name):
    from app.core.sql_parser import parse_sql_document
    source = f'WITH {name} AS (SELECT ID FROM DB.SRC.CONTACTS WHERE ID > 0) SELECT * FROM {name}'
    cte = parse_sql_document(source).ctes[0]
    node = RelationNode(relation_id='sql-cte:upload:scope:original', alias='cte_internal',
        kind=RelationNodeKind.CTE, sql_text=cte.sql_text, original_cte_name=name, output_columns=[{'name': 'ID'}])
    for _ in range(3):
        response = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column='ID', expression='cte_internal.ID')]))
        parsed = parse_sql_document(response.preview_sql)
        assert len(parsed.ctes) == 1
        assert parsed.ctes[0].name == cte.name
        assert 'cte_internal' not in response.preview_sql
        assert 'SELECT * FROM' not in response.preview_sql
        assert 'ID > 0' in response.preview_sql
        node.sql_text = parsed.ctes[0].sql_text


def test_uploaded_cte_output_keeps_dependency_local_to_definition():
    node = RelationNode(relation_id='sql-cte:upload:scope:final', alias='cte_final', original_cte_name='final',
        kind=RelationNodeKind.CTE, output_columns=[{'name': 'ID'}], sql_text='WITH base AS (SELECT ID FROM DB.SRC.CONTACTS), final AS (SELECT ID FROM base WHERE ID > 0) SELECT * FROM final')
    response = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column='ID', expression='cte_final.ID')]))
    assert response.preview_sql.count('final AS') == 1
    assert 'base AS' in response.preview_sql
    assert 'ID > 0' in response.preview_sql


def test_quoted_join_columns_are_valid_identifiers_not_sql_fragments():
    assert MappingSqlService._safe_sql_identifier('"Id"', label='column') == '"Id"'
    with pytest.raises(ValueError):
        MappingSqlService._safe_sql_identifier('"Id"; DROP TABLE A', label='column')


@pytest.mark.parametrize("expression", [None, "COALESCE(master.billfrequency, 'master.BillFrequency')"])
def test_physical_source_columns_bind_exact_case_from_saved_contract(expression):
    node = RelationNode(relation_id="DB.SRC.MASTER", alias="master", kind="PHYSICAL_TABLE",
                        table=TableRef(database="DB", schema="SRC", table="MASTER"),
                        output_columns=[{"name": "BillFrequency"}])
    result = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column="BILL_FREQUENCY", source_columns=["master.BillFrequency"],
                                       expression=expression, rule="Direct")]))
    assert 'master."BillFrequency"' in result.preview_sql
    if expression:
        assert "'master.BillFrequency'" in result.preview_sql


def test_physical_case_binding_never_repairs_wrong_explicit_quote():
    node = RelationNode(relation_id="DB.SRC.MASTER", alias="master", kind="PHYSICAL_TABLE",
                        table=TableRef(database="DB", schema="SRC", table="MASTER"),
                        output_columns=[{"name": "BillFrequency"}])
    with pytest.raises(ValueError, match="not produced"):
        MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="FREQUENCY", source_columns=['master."billfrequency"'])]))


def test_physical_case_binding_rejects_ambiguous_casefolded_contract():
    node = RelationNode(relation_id="DB.SRC.MASTER", alias="master", kind="PHYSICAL_TABLE",
                        table=TableRef(database="DB", schema="SRC", table="MASTER"),
                        output_columns=[{"name": "BillFrequency"}, {"name": "billfrequency"}])
    with pytest.raises(ValueError, match="Ambiguous"):
        MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="FREQUENCY", source_columns=['master.BILLFREQUENCY'])]))


def test_uppercase_physical_contract_keeps_unquoted_identifier():
    node = RelationNode(relation_id="DB.SRC.MASTER", alias="master", kind="PHYSICAL_TABLE",
                        table=TableRef(database="DB", schema="SRC", table="MASTER"),
                        output_columns=[{"name": "ID"}, {"name": "Id"}])
    result = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column="ID", source_columns=['master.id'])]))
    assert 'master.id AS ID' in result.preview_sql


def test_outer_physical_case_binding_preserves_nested_cte_namespace():
    nodes = {"DB.SRC.MASTER": RelationNode(relation_id="DB.SRC.MASTER", alias="master", kind="PHYSICAL_TABLE",
        table=TableRef(database="DB", schema="SRC", table="MASTER"), output_columns=[{"name": "BillFrequency"}])}
    sql = "WITH inner_cte AS (SELECT master.billfrequency FROM OTHER.TABLE AS master) SELECT master.billfrequency FROM DB.SRC.MASTER AS master"
    result = MappingSqlService._bind_physical_column_case(sql, nodes, {"MASTER": "DB.SRC.MASTER"}, outer_query=True)
    assert 'SELECT master.billfrequency FROM OTHER.TABLE AS master' in " ".join(result.split())
    assert 'master."BillFrequency"' in result


def test_outer_physical_case_binding_includes_population_predicates():
    node = RelationNode(relation_id="DB.SRC.MASTER", alias="master", kind="PHYSICAL_TABLE",
        table=TableRef(database="DB", schema="SRC", table="MASTER"), output_columns=[{"name": "BillFrequency"}])
    result = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=RelationGraphContext(nodes=[node]), validate_with_explain=False,
        where_predicates=["master.billfrequency IS NOT NULL"],
        mappings=[MappingSqlMappingItem(target_column="FREQUENCY", source_columns=['master.billfrequency'])]))
    assert result.preview_sql.count('master."BillFrequency"') == 2


def test_imported_name_collision_keeps_stable_alias_and_filters():
    node = RelationNode(relation_id='sql-cte:upload:scope:accounts', alias='cte_accounts', original_cte_name='accounts',
        kind=RelationNodeKind.CTE, sql_text='WITH accounts AS (SELECT ID FROM DB.SRC.CONTACTS WHERE ID > 0) SELECT * FROM accounts')
    sql = 'WITH accounts AS (SELECT 1 AS ID), cte_accounts AS (WITH accounts AS (SELECT ID FROM DB.SRC.CONTACTS WHERE ID > 0) SELECT * FROM accounts) SELECT cte_accounts.ID FROM cte_accounts'
    result = MappingSqlService._render_imported_ctes(sql, [node], {node.relation_id: node.alias})
    assert 'cte_accounts AS' in result
    assert result.count('accounts AS') == 2  # existing CTE plus stable cte_accounts
    assert 'ID > 0' in result


def test_imported_cte_name_does_not_capture_sibling_physical_table():
    node = RelationNode(relation_id='sql-cte:upload:accounts', alias='cte_accounts', original_cte_name='accounts', kind=RelationNodeKind.CTE)
    sql = 'WITH cte_accounts AS (WITH accounts AS (SELECT 1 ID) SELECT * FROM accounts), child AS (SELECT ID FROM accounts) SELECT cte_accounts.ID FROM cte_accounts'
    result = MappingSqlService._render_imported_ctes(sql, [node], {node.relation_id:node.alias})
    assert 'cte_accounts AS' in result
    assert 'FROM accounts' in result


def test_qualified_physical_table_is_not_a_cte_envelope():
    node = RelationNode(relation_id='sql-cte:upload:accounts', alias='cte_accounts', original_cte_name='accounts', kind=RelationNodeKind.CTE)
    sql = 'WITH cte_accounts AS (WITH accounts AS (SELECT 1 ID) SELECT * FROM DB.S.accounts) SELECT * FROM cte_accounts'
    result = MappingSqlService._render_imported_ctes(sql, [node], {node.relation_id:node.alias})
    assert 'DB.S.accounts' in result
    assert re.search(r'SELECT\s+\*', result)


def test_imported_cte_renames_bound_child_references_and_preserves_explicit_alias():
    node = RelationNode(relation_id='sql-cte:upload:parent', alias='cte_parent', original_cte_name='parent', kind=RelationNodeKind.CTE)
    sql = 'WITH cte_parent AS (WITH parent AS (SELECT 1 ID) SELECT * FROM parent), child AS (SELECT cte_parent.ID FROM cte_parent) SELECT cte_parent.ID FROM cte_parent AS cte_parent'
    result = MappingSqlService._render_imported_ctes(sql, [node], {node.relation_id:node.alias})
    assert 'parent AS' in result
    assert re.search(r'SELECT\s+parent.ID', result)
    assert 'FROM parent AS cte_parent' in result
    assert 'SELECT\n  cte_parent.ID' in result


def test_quoted_relation_alias_has_case_preserving_binding_contract():
    assert MappingSqlService._safe_sql_identifier('"Mixed"', label='relation alias') == '"Mixed"'
    assert MappingSqlService._sql_alias_key('"Mixed"') == 'Mixed'
    assert MappingSqlService._sql_alias_key('mixed') == 'MIXED'
    with pytest.raises(ValueError, match='relation alias'):
        MappingSqlService._safe_sql_identifier('"A"; SELECT 1', label='relation alias')


def test_missing_current_project_value_cannot_reuse_snapshot_resolution():
    graph = RelationGraphContext(value_bindings=[ValueBinding(
        binding_id="firm", value="$FirmID", resolved_value="another-firm",
        is_placeholder=True, resolution_status="project_attribute", allow_project_specific_value=True,
    )])
    resolved = MappingSqlService.with_project_values(graph, [])
    assert resolved.value_bindings[0].resolved_value is None
    assert MappingSqlService._resolved_placeholder_sql(resolved) == {}


def test_bare_function_label_is_not_an_executable_column():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id="source", alias="source",
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table="CONTACTS"),
        output_columns=[{"name": "NEXT_REVIEW_AT", "data_type": "DATE"}])])
    with pytest.raises(ValueError, match="Undefined column.*TO_DATE"):
        MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=graph, validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="NEXT_REVIEW", expression="TO_DATE")]))


def test_identical_placeholder_bindings_can_share_named_reference():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id="src", alias="src",
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table="CONTACTS"))],
        value_bindings=[ValueBinding(binding_id=identifier, value="$FirmID", resolved_value="current",
            data_type="VARCHAR", is_placeholder=True, resolution_status="project_attribute") for identifier in ("row1", "row2")])
    response = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=graph, validate_with_explain=False, mappings=[MappingSqlMappingItem(
            target_column="FIRM", mapping_mode="attribute", constant_value="$FirmID", value_binding_ids=["$FirmID"])]))
    assert "SET FirmID" in response.script_sql


def test_source_comparison_preserves_cte_scope_and_resolves_qualified_columns():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id="DB.SRC.CONTACTS", alias="contacts",
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table="CONTACTS"))])
    query = MappingSqlService._source_value_preview_query(
        "WITH addresses AS (SELECT ID, CITY FROM DB.SRC.ADDRESSES) "
        "SELECT * FROM DB.SRC.CONTACTS AS contacts LEFT JOIN addresses ON contacts.ID = addresses.ID "
        "WHERE contacts.ACTIVE = TRUE",
        {"DB.SRC.CONTACTS.CLIENT_SINCE": "SRC_1", "addresses.CITY": "SRC_2"}, limit=5, graph=graph)
    assert "contacts.CLIENT_SINCE AS SRC_1" in query
    assert "addresses.CITY AS SRC_2" in query
    assert "WITH addresses AS" in query
    assert "LEFT JOIN addresses ON contacts.ID = addresses.ID" in query
    assert "WHERE contacts.ACTIVE = TRUE" in query
    assert "SOURCE_FOUNDATION" not in query
    assert query.endswith("LIMIT 5")


def test_ambiguous_unqualified_expression_is_rejected():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id=name, alias=name,
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table=name),
        output_columns=[{"name": "NAME"}]) for name in ("CONTACTS", "FAMILIES")])
    with pytest.raises(ValueError, match="Ambiguous column.*NAME"):
        MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=graph, validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="NAME", expression="TRIM(NAME)")]))


def test_compiler_keeps_prepared_joins_even_for_value_only_projection():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id=name, alias=name,
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table=name.upper()))
        for name in ("contacts", "members", "families")], edges=[
            RelationEdge(edge_id="member", left_relation_id="contacts", right_relation_id="members", join_type="LEFT",
                conditions=[RelationshipConditionItem(left_column="ID", right_column="CONTACT_ID")]),
            RelationEdge(edge_id="family", left_relation_id="members", right_relation_id="families", join_type="LEFT",
                conditions=[RelationshipConditionItem(left_column="FAMILY_ID", right_column="ID")]),
        ])
    response = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=graph, driving_relation_id="contacts", validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column="FLAG", mapping_mode="constant", constant_value="Yes")]))
    assert "LEFT JOIN DB.SRC.MEMBERS" in response.preview_sql
    assert "LEFT JOIN DB.SRC.FAMILIES" in response.preview_sql


def test_compiler_preserves_complete_or_join_predicate_without_equality_pairs():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id=name, alias=name,
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table=name.upper()))
        for name in ("contacts", "members")], edges=[RelationEdge(
            edge_id="full_predicate", left_relation_id="contacts", right_relation_id="members", join_type="LEFT",
            additional_predicate="contacts.ID = members.CONTACT_ID OR (contacts.TS > members.TS AND members.ACTIVE = TRUE)",
        )])
    response = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=graph, driving_relation_id="contacts", validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column="FLAG", mapping_mode="constant", constant_value="Yes")]))
    assert "LEFT JOIN DB.SRC.MEMBERS" in response.preview_sql
    assert "contacts.ID = members.CONTACT_ID OR" in response.preview_sql
    assert "contacts.TS > members.TS AND members.ACTIVE = TRUE" in response.preview_sql
    graph.edges[0].additional_predicate = "contacts.ID = missing.ID"
    with pytest.raises(ValueError, match="Undefined SQL alias"):
        MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=graph, driving_relation_id="contacts", validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="FLAG", mapping_mode="constant", constant_value="Yes")]))


def test_compiler_preserves_imported_outer_query_modifiers():
    graph = RelationGraphContext(nodes=[RelationNode(relation_id="contacts", alias="contacts",
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table="CONTACTS"))],
        query_modifiers={"distinct": "DISTINCT", "having": "HAVING COUNT(*) > 1",
            "qualify": "QUALIFY ROW_NUMBER() OVER (ORDER BY contacts.ID) = 1", "limit": "LIMIT 5", "offset": "OFFSET 2"})
    response = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=graph, driving_relation_id="contacts", validate_with_explain=False,
        group_by_expressions=["contacts.ID"], order_by_expressions=["contacts.ID DESC NULLS FIRST"],
        mappings=[MappingSqlMappingItem(target_column="ID", source_column="contacts.ID")]))
    from sqlglot import parse_one
    sql = parse_one(response.preview_sql, read="snowflake")
    assert sql.args["distinct"] is not None
    assert sql.args["having"].sql() == "HAVING COUNT(*) > 1"
    assert sql.args["qualify"] is not None
    assert sql.args["limit"].expression.this == "5"
    assert sql.args["offset"].expression.this == "2"
    graph.query_modifiers = {"limit": "LIMIT 5; DELETE FROM DB.SRC.CONTACTS"}
    with pytest.raises(ValueError, match="Invalid limit"):
        MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=graph, validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="ID", source_column="contacts.ID")]))


def test_script_edits_validate_set_values_without_promoting_literals():
    service = MappingSqlService(session=_Session(), analyst_client=None)
    body = MappingSqlParseRequest(sql="SET FirmID = 'A'; SELECT $FirmID AS F FROM DB.SRC.CONTACTS", project_id="firm-a")
    response = service.parse(body, project_values={"$FIRMID": "'A'"})
    assert response.valid
    assert "SET" not in response.preview_sql
    assert "'A' AS F" in response.preview_sql
    assert "$FirmID" in response.canonical_sql or "$FIRMID" in response.canonical_sql
    mapping = response.parsed_workspace["mapping_rows"][0]
    assert mapping["mapping_mode"] == "attribute"
    assert mapping["attribute_name"].upper() == "FIRMID"
    assert mapping["constant_value"].upper() == "$FIRMID"
    with pytest.raises(ValueError, match="must match"):
        service.parse(body, project_values={"$FIRMID": "'B'"})


def test_optimized_query_preserves_project_placeholders_in_export_script():
    class Analyst:
        def ask(self, **kwargs):
            assert "$FirmID" in kwargs["question"]
            return SimpleNamespace(sql="SELECT $FirmID AS F FROM DB.SRC.CONTACTS WHERE ID > 0",
                                   text="Keep the required population filter.", response_metadata={})
    graph = RelationGraphContext(value_bindings=[ValueBinding(binding_id="firm", value="$FirmID",
        resolved_value="A", data_type="VARCHAR", attribute_name="FirmID", is_placeholder=True,
        allow_project_specific_value=True, resolution_status="project_attribute")])
    service = MappingSqlService(session=_Session(), analyst_client=Analyst())
    response = service.review(MappingSqlReviewRequest(source_query_sql="SELECT * FROM DB.SRC.CONTACTS",
        preview_sql="SELECT 'A' AS F FROM DB.SRC.CONTACTS", generated_sql="SELECT 'A' AS F FROM DB.SRC.CONTACTS",
        canonical_preview_sql="SELECT $FirmID AS F FROM DB.SRC.CONTACTS", relation_graph=graph,
        semantic_model_yaml="name: test", request_optimization=True))
    assert response.execution_ready
    assert "SET FirmID = 'A';" in response.optimized_script_sql
    assert "$FirmID" in response.optimized_script_sql
    assert "$FirmID" not in response.optimized_preview_sql


def test_direct_projection_uses_selected_column_not_first_dependency():
    service = MappingSqlService(session=_Session(), analyst_client=None)
    graph = RelationGraphContext(nodes=[RelationNode(relation_id="mapper", alias="mapper",
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table="MAPPER"), grain="contact")])
    body = MappingSqlCompileRequest(relation_graph=graph, validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column="REFERRAL", rule="Direct", source_column="mapper.SALESFORCE_ID",
            source_dependencies=["mapper.SOURCE_ID", "mapper.SALESFORCE_ID"])])
    response = service.compile(body)
    assert "mapper.SALESFORCE_ID AS REFERRAL" in response.preview_sql
    assert "mapper.SOURCE_ID AS REFERRAL" not in response.preview_sql
    body.target_grain = "household"
    response = service.compile(body)
    assert response.valid and not response.ready
    assert response.grain_validation == "requires_review"


@pytest.mark.parametrize("repair_kind", ["deterministic", "cortex"])
def test_repair_keeps_canonical_set_script_and_resolves_only_validation(monkeypatch, repair_kind):
    service = MappingSqlService(session=_Session(), analyst_client=None)
    graph = RelationGraphContext(value_bindings=[ValueBinding(binding_id="firm", value="$FirmID",
        resolved_value="A", data_type="VARCHAR", is_placeholder=True,
        resolution_status="project_attribute", allow_project_specific_value=True)])

    def invalid(_sql):
        raise ValueError("syntax error")

    def repaired(sql, **kwargs):
        assert "$FirmID" in sql
        return "SELECT $FirmID AS F FROM DB.SRC.CONTACTS WHERE ID > 0", "Syntax repaired"

    def validate(sql):
        assert "$FirmID" not in sql
        return True

    monkeypatch.setattr(service, "_validate_preview_sql", invalid)
    monkeypatch.setattr(service, "_candidate_sql_is_valid", validate)
    if repair_kind == "deterministic":
        monkeypatch.setattr(service, "_attempt_sql_repair", repaired)
    else:
        monkeypatch.setattr(service, "_attempt_sql_repair", lambda *args, **kwargs: (None, ""))
        monkeypatch.setattr(service, "_attempt_cortex_sql_repair", lambda body, sql, **kwargs: repaired(sql))
    response = service.review(MappingSqlReviewRequest(source_query_sql="SELECT * FROM DB.SRC.CONTACTS",
        preview_sql="SELECT 'A' AS F FROM DB.SRC.CONTACTS", generated_sql="SELECT 'A' AS F FROM DB.SRC.CONTACTS",
        canonical_preview_sql="SELECT $FirmID AS F FROM DB.SRC.CONTACTS", relation_graph=graph, attempt_ai_repair=True))
    assert response.execution_ready
    assert "SET FirmID = 'A';" in response.optimized_script_sql
    assert "$FirmID" in response.optimized_script_sql
    assert "$FirmID" not in response.optimized_preview_sql


@pytest.mark.parametrize("rule", ["Cast", "Concatenate", "Custom"])
def test_missing_transformation_never_falls_back_to_raw_source(rule):
    service = MappingSqlService(session=_Session(), analyst_client=None)
    graph = RelationGraphContext(nodes=[RelationNode(relation_id="source", alias="source",
        kind=RelationNodeKind.PHYSICAL_TABLE, table=TableRef(database="DB", schema="SRC", table="CONTACTS"))])
    with pytest.raises(ValueError, match="requires a SQL expression"):
        service.compile(MappingSqlCompileRequest(relation_graph=graph, validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="NAME", rule=rule, source_columns=["source.NAME"])]))


class _PreviewQuery:
    schema = SimpleNamespace(fields=[])

    def collect(self):
        return []


class _PreviewSession:
    def sql(self, _query, params=None):
        return _PreviewQuery()


def test_preview_without_source_alias_comparison_returns_rows_contract() -> None:
    service = MappingSqlService(session=_PreviewSession(), analyst_client=_Analyst())

    response = service.preview(
        MappingSqlPreviewRequest(
            source_query_sql="SELECT 1",
            preview_sql="SELECT 1 AS VALUE",
            generated_sql="SELECT 1 AS VALUE",
        )
    )

    assert response.valid is True
    assert response.preview_rows == []
    assert response.source_sample_rows == []


@pytest.mark.parametrize(
    "sql_text",
    [
        "SELECT 1; SELECT 2",
        "DELETE FROM DB.SCHEMA.TARGET",
        "CALL DB.SCHEMA.DO_WORK()",
    ],
)
def test_preview_rejects_multiple_statements_and_non_query_sql(sql_text: str) -> None:
    service = MappingSqlService(session=_PreviewSession(), analyst_client=_Analyst())

    with pytest.raises(ValueError, match="SELECT|WITH|DDL|DML|CALL|command"):
        service.preview(
            MappingSqlPreviewRequest(
                source_query_sql="SELECT 1",
                preview_sql=sql_text,
                generated_sql=sql_text,
            )
        )


class _FailingQuery:
    def collect(self):
        raise RuntimeError(
            "SQL compilation error: Session variable '$TransactionFirmID' does not exist"
        )


class _FailingSession:
    def sql(self, _query):
        return _FailingQuery()


class _AiRepairSession:
    def sql(self, query, params=None):
        if "AI_COMPLETE" in query or "CORTEX.COMPLETE" in query:
            class Completion:
                def collect(self):
                    return [{"RESPONSE": '{"sql":"SELECT SRC.AMOUNT / 100 AS AMOUNT FROM DB.SCHEMA.SRC AS SRC","summary":"Replaced the invalid operator phrase."}'}]
            return Completion()
        if "AMOUNT / 100" in query:
            return _Query()
        return _FailingQuery()


class _Analyst:
    def __init__(self):
        self.calls = []

    def ask(self, **kwargs):
        self.calls.append(kwargs)
        return SnowflakeAnalystResponse(
            request_id="analyst-request",
            text="The SQL is valid.",
            sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC",
        )


def test_compile_uses_current_graph_even_when_all_rows_accept_precedent() -> None:
    class Session:
        def sql(self, *_args, **_kwargs):
            raise AssertionError("Compilation must not retrieve prior RAW_MAPPING_SQL")

    service = MappingSqlService(
        session=Session(),
        analyst_client=_Analyst(),
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(
                nodes=[
                    RelationNode(
                        relation_id="DB.CRM.CONTACTS",
                        kind=RelationNodeKind.PHYSICAL_TABLE,
                        alias="contacts_1",
                        table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
                    )
                ],
            ),
            mappings=[
                MappingSqlMappingItem(
                    target_column="LEGACY_ID__C",
                    source_column="contacts_1.ID",
                    source_columns=["contacts_1.ID"],
                    source_dependencies=["contacts_1.ID"],
                    expression="'HH-' || CAST(contacts_1.ID AS TEXT)",
                    status="MAPPED",
                    precedent_decision="accept_precedent",
                    precedent_mapping_id="1101",
                )
            ],
            target_table=TableRef(database="DB", schema="TGT", table="EVERNEST_HH"),
            accepted_precedent_sttm_id="1101",
            input_hash="workspace-structure-v2",
            validate_with_explain=False,
        )
    )

    assert response.valid is True
    assert response.ready is True
    assert response.input_hash == "workspace-structure-v2"
    assert "'HH-' || CAST(contacts_1.ID AS TEXT) AS LEGACY_ID__C" in response.preview_sql
    assert "FROM DB.CRM.CONTACTS AS contacts_1" in response.preview_sql
    assert "UserMaster" not in response.preview_sql


def test_compile_resolves_a_dependency_saved_under_the_positional_alias_scheme() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.SERVICING_ADVISORS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="servicing_advisors_kc2ar1",
                table=TableRef(
                    database="DB", schema="CRM", table="SERVICING_ADVISORS"
                ),
            )
        ]
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="ADVISOR_ID",
                    source_dependencies=["servicing_advisors_15.ID"],
                    expression="TRIM(servicing_advisors_15.ID)",
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "TRIM(servicing_advisors_kc2ar1.ID) AS ADVISOR_ID" in response.preview_sql


def test_compile_rejects_a_legacy_alias_that_matches_more_than_one_relation() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.SERVICING_ADVISORS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="servicing_advisors_kc2ar1",
                table=TableRef(database="DB", schema="CRM", table="SERVICING_ADVISORS"),
            ),
            RelationNode(
                relation_id="DB.ARCHIVE.SERVICING_ADVISORS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="servicing_advisors_x8z991",
                table=TableRef(database="DB", schema="ARCHIVE", table="SERVICING_ADVISORS"),
            ),
        ]
    )

    with pytest.raises(ValueError, match="Undefined relation or alias"):
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="ADVISOR_ID",
                        source_dependencies=["servicing_advisors_15.ID"],
                        status="MAPPED",
                    )
                ],
            )
        )


def test_legacy_alias_resolution_prefers_an_exact_suffix_shaped_table_name() -> None:
    relation_id = "DB.CRM.CONTACT_UDF_FIELDS"
    nodes = {
        relation_id: RelationNode(
            relation_id=relation_id,
            kind=RelationNodeKind.PHYSICAL_TABLE,
            alias="contact_udf_fields_a1b2c3",
            table=TableRef(database="DB", schema="CRM", table="CONTACT_UDF_FIELDS"),
        )
    }

    resolved = MappingSqlService._resolve_legacy_alias_relation(
        "CONTACT_UDF_FIELDS",
        nodes,
        {"CONTACT_UDF_FIELDS_A1B2C3": relation_id},
    )

    assert resolved == relation_id


def test_compile_resolves_project_value_binding_without_exposing_placeholder() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(
                nodes=[
                    RelationNode(
                        relation_id="DB.CRM.CONTACTS",
                        kind=RelationNodeKind.PHYSICAL_TABLE,
                        alias="contacts_1",
                        table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
                    )
                ],
                value_bindings=[
                    ValueBinding(
                        binding_id="project-attribute:firm",
                        value="$TransactionFirmID",
                        resolved_value="42",
                        data_type="NUMBER",
                        attribute_name="TransactionFirmID",
                        is_placeholder=True,
                        allow_project_specific_value=True,
                        resolution_status="project_attribute",
                    )
                ],
            ),
            mappings=[
                MappingSqlMappingItem(
                    target_column="TRANSACTION_FIRM_ID",
                    target_type="NUMBER",
                    mapping_mode="attribute",
                    constant_value="$TransactionFirmID",
                    attribute_name="TransactionFirmID",
                    value_binding_ids=["project-attribute:firm"],
                    status="MAPPED",
                )
            ],
            target_table=TableRef(database="DB", schema="TGT", table="EVERNEST_HH"),
            validate_with_explain=False,
        )
    )

    assert response.ready is True
    assert "42 AS TRANSACTION_FIRM_ID" in response.preview_sql
    assert "$TransactionFirmID" not in response.preview_sql


def test_review_uses_inline_semantic_yaml_when_view_is_not_promoted() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC",
        generated_sql="INSERT INTO DB.SCHEMA.TGT (ID) SELECT SRC.ID FROM DB.SCHEMA.SRC",
        semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
        request_optimization=True,
    )

    response = service.review(request)

    assert response.review_agent == "CORTEX_ANALYST"
    assert analyst.calls[0]["semantic_view"] is None
    assert analyst.calls[0]["semantic_model_yaml"] == request.semantic_model_yaml


def test_review_skips_analyst_for_valid_sql_without_optimization_request() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)

    response = service.review(
        MappingSqlReviewRequest(
            source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
            preview_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC AS SRC",
            generated_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC AS SRC",
            semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
        )
    )

    assert response.execution_ready is True
    assert response.review_agent == "SNOWFLAKE_EXECUTOR"
    assert analyst.calls == []


def test_review_prompt_includes_derived_output_contract_and_saved_sql() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT household_1.HOUSEHOLD_ID AS ID FROM household_1",
        generated_sql="SELECT household_1.HOUSEHOLD_ID AS ID FROM household_1",
        semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
        request_optimization=True,
        relation_graph=RelationGraphContext(
            nodes=[
                RelationNode(
                    relation_id="household",
                    kind=RelationNodeKind.DERIVED_SOURCE,
                    alias="household_1",
                    sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES",
                    output_columns=[
                        {"name": "CONTACT_ID", "data_type": "NUMBER"},
                        {"name": "HOUSEHOLD_ID", "data_type": "NUMBER"},
                    ],
                )
            ]
        ),
    )

    service.review(request)

    question = analyst.calls[0]["question"]
    assert "outputs=['CONTACT_ID', 'HOUSEHOLD_ID']" in question
    assert "Saved SQL for derived relation household" in question
    assert "Never reference a derived column" in question


def test_review_returns_actionable_value_binding_fix_when_validation_fails() -> None:
    service = MappingSqlService(session=_FailingSession(), analyst_client=_Analyst())
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT '$TransactionFirmID' AS TRANSACTION_FIRM__C FROM DB.SCHEMA.SRC",
        generated_sql=(
            "INSERT INTO DB.SCHEMA.TGT (TRANSACTION_FIRM__C) "
            "SELECT '$TransactionFirmID' FROM DB.SCHEMA.SRC"
        ),
    )

    response = service.review(request)

    assert response.execution_ready is False
    assert response.requires_approval is False
    assert [item.code for item in response.repair_options] == [
        "resolve_value_binding",
        "edit_sql",
    ]
    assert response.repair_options[0].identifier == "$TransactionFirmID"
    assert response.repair_options[0].action == "open_mapping"


def test_review_ai_repair_is_snowflake_validated_before_approval() -> None:
    service = MappingSqlService(session=_AiRepairSession(), analyst_client=_Analyst())
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT CAST / DIVIDE AS AMOUNT FROM DB.SCHEMA.SRC AS SRC",
        generated_sql="SELECT CAST / DIVIDE AS AMOUNT FROM DB.SCHEMA.SRC AS SRC",
        mappings=[MappingSqlMappingItem(target_column="AMOUNT", status="MAPPED")],
        attempt_ai_repair=True,
    )

    response = service.review(request)

    assert response.execution_ready is True
    assert response.requires_approval is True
    assert response.review_kind == "repair"
    assert response.optimized_preview_sql == "SELECT SRC.AMOUNT / 100 AS AMOUNT FROM DB.SCHEMA.SRC AS SRC"


def test_parse_blocks_ambiguous_unqualified_table_references() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.parse(
        MappingSqlParseRequest(
            sql="INSERT INTO TARGET_TABLE (ID) SELECT ID FROM CONTACT",
            known_tables=[
                TableRef(database="DB_A", schema="CRM", table="CONTACT"),
                TableRef(database="DB_B", schema="CRM", table="CONTACT"),
                TableRef(database="DB_A", schema="CRM", table="TARGET_TABLE"),
            ],
        )
    )

    assert response.valid is False
    assert response.ambiguous_references["CONTACT"] == [
        "DB_A.CRM.CONTACT",
        "DB_B.CRM.CONTACT",
    ]


def test_parse_select_preview_preserves_current_target() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.parse(
        MappingSqlParseRequest(
            sql="SELECT SRC.ID AS ID FROM DB_A.CRM.CONTACT AS SRC",
            known_tables=[
                TableRef(database="DB_A", schema="CRM", table="CONTACT"),
                TableRef(database="DB_A", schema="CRM", table="TARGET_TABLE"),
            ],
            current_workspace={"target_table": "DB_A.CRM.TARGET_TABLE"},
        )
    )

    assert response.valid is True
    assert response.parsed_workspace["target_table"] == "DB_A.CRM.TARGET_TABLE"
    assert "target_table_changed" not in response.diff


def test_parse_resolves_static_set_variable_as_project_attribute() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.parse(
        MappingSqlParseRequest(
            sql=(
                "SET ParentOfficeID = '001-office';\n"
                "SELECT $ParentOfficeID AS PARENT_ID FROM DB_A.CRM.CONTACT"
            ),
            known_tables=[
                TableRef(database="DB_A", schema="CRM", table="CONTACT"),
            ],
        )
    )

    row = response.parsed_workspace["mapping_rows"][0]
    assert row["mapping_mode"] == "attribute"
    assert row["attribute_name"] == "ParentOfficeID"
    assert row["constant_value"] == "001-office"


def test_compile_unifies_physical_and_derived_relations() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="household_rollup",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="household_rollup_2",
                sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES",
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-household",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="household_rollup",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID", right_column="CONTACT_ID", operator="="
                    )
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            target_table=TableRef(database="DB", schema="CRM", table="TARGET"),
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="LEGACY_ID",
                    source_columns=["DB.CRM.CONTACTS.ID", "household_rollup_2.HOUSEHOLD_ID"],
                    source_dependencies=["DB.CRM.CONTACTS.ID", "household_rollup_2.HOUSEHOLD_ID"],
                    expression="COALESCE(household_rollup_2.HOUSEHOLD_ID, DB.CRM.CONTACTS.ID)",
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "WITH\nhousehold_rollup_2 AS (" in response.preview_sql
    assert "FROM DB.CRM.CONTACTS AS contacts_1" in response.preview_sql
    assert "LEFT JOIN household_rollup_2" in response.preview_sql
    assert "COALESCE(household_rollup_2.HOUSEHOLD_ID, contacts_1.ID)" in response.preview_sql
    assert response.preview_sql.count("FROM DB.CRM.CONTACTS") == 1


def test_self_contained_compile_joins_the_saved_view_when_a_derived_node_has_no_sql() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="state_codes_one_per_state_code",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="state_codes_2",
                physical_view_name="DB.META.DSV_STATE_CODES",
                output_columns=[
                    {"name": "STATE_CODE", "data_type": "VARCHAR"},
                    {"name": "STATE_NAME", "data_type": "VARCHAR"},
                ],
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-state",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="state_codes_one_per_state_code",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(left_column="STATE", right_column="STATE_CODE", operator="=")
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            self_contained_derived=True,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="STATE_NAME",
                    source_dependencies=["state_codes_2.STATE_NAME"],
                    status="MAPPED",
                )
            ],
        )
    )

    # No CTE body is available, so the join must reference the saved view
    # rather than an alias that no WITH clause defines.
    assert "WITH" not in response.preview_sql
    assert "LEFT JOIN DB.META.DSV_STATE_CODES AS state_codes_2" in response.preview_sql


def test_compile_defines_a_cte_for_every_joined_derived_relation() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="addresses_one",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="addresses_2",
                sql_text="SELECT ADDRESSABLE_ID, STATE, CITY FROM DB.CRM.ADDRESSES",
                output_columns=[
                    {"name": "ADDRESSABLE_ID", "data_type": "NUMBER"},
                    {"name": "STATE", "data_type": "VARCHAR"},
                    {"name": "CITY", "data_type": "VARCHAR"},
                ],
            ),
            RelationNode(
                relation_id="state_codes_one",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="state_codes_3",
                sql_text="SELECT STATE_CODE, STATE_NAME FROM DB.CRM.STATE_CODES",
                output_columns=[
                    {"name": "STATE_CODE", "data_type": "VARCHAR"},
                    {"name": "STATE_NAME", "data_type": "VARCHAR"},
                ],
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="addresses_one",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(left_column="ID", right_column="ADDRESSABLE_ID", operator="=")
                ],
            ),
            RelationEdge(
                edge_id="addresses-state",
                left_relation_id="addresses_one",
                right_relation_id="state_codes_one",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(left_column="STATE", right_column="STATE_CODE", operator="=")
                ],
            ),
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            self_contained_derived=True,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="CITY",
                    source_dependencies=["addresses_2.CITY"],
                    status="MAPPED",
                )
            ],
        )
    )

    sql = response.preview_sql
    # No column reads state_codes_3, but the plan joins it, so it must be defined.
    if "JOIN state_codes_3" in sql:
        assert "state_codes_3 AS (" in sql
    assert "addresses_2 AS (" in sql


def test_compile_binds_a_bare_source_token_to_the_single_mapped_column() -> None:
    bind = MappingSqlService._bind_source_placeholder

    assert bind("CAST(source AS VARCHAR)", ["contact_families.TEMP_ID"]) == (
        "CAST(contact_families.TEMP_ID AS VARCHAR)"
    )
    # Literals, qualifiers, longer identifiers and multi-column rules stay as-is.
    assert bind("COALESCE(source, 'source')", ["c.X"]) == "COALESCE(c.X, 'source')"
    assert bind("source.ID || source_id", ["c.X"]) == "source.ID || source_id"
    assert bind("CONCAT(source, ' ')", ["c.A", "c.B"]) == "CONCAT(source, ' ')"


def test_compile_rejects_query_level_mapping_expression() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ]
    )

    try:
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="ID",
                        source_dependencies=["contacts_1.ID"],
                        expression="contacts_1.ID FROM DB.CRM.CONTACTS",
                        status="MAPPED",
                    )
                ],
            )
        )
    except ValueError as exc:
        assert "Query-level SQL" in str(exc)
    else:
        raise AssertionError("Expected query-level SQL to be rejected")


def test_compile_preserves_but_blocks_unresolved_value_placeholder() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="parent-office",
                value="$ParentOfficeID",
                is_placeholder=True,
                resolution_status="placeholder_contract",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    mapping_mode="constant",
                    constant_value="$ParentOfficeID",
                    value_binding_ids=["parent-office"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is False
    assert response.unresolved_placeholders == ["$ParentOfficeID"]
    assert "$ParentOfficeID AS PARENT_ID" in response.preview_sql


def test_compile_substitutes_only_explicitly_resolved_value_placeholder() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="parent-office",
                value="$ParentOfficeID",
                resolved_value="001-office",
                data_type="VARCHAR",
                is_placeholder=True,
                resolution_status="resolved",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    mapping_mode="constant",
                    constant_value="$ParentOfficeID",
                    value_binding_ids=["parent-office"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert response.unresolved_placeholders == []
    assert "'001-office' AS PARENT_ID" in response.preview_sql


def test_compile_uses_named_project_attribute_as_governed_value_binding() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="project-parent-office",
                attribute_name="PARENT_OFFICE_ID",
                value="001-office",
                resolved_value="001-office",
                data_type="VARCHAR",
                allow_project_specific_value=True,
                resolution_status="resolved",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    mapping_mode="attribute",
                    attribute_name="PARENT_OFFICE_ID",
                    constant_value="001-office",
                    value_binding_ids=["project-parent-office"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert response.unresolved_placeholders == []
    assert "'001-office' AS PARENT_ID" in response.preview_sql


def test_compile_accepts_unique_placeholder_value_as_binding_reference() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="canonical-TransactionFirmID",
                value="$TransactionFirmID",
                is_placeholder=True,
                resolution_status="placeholder_contract",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="TRANSACTION_FIRM__C",
                    mapping_mode="constant",
                    constant_value="$TransactionFirmID",
                    value_binding_ids=["$TransactionFirmID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is False
    assert response.unresolved_placeholders == ["$TransactionFirmID"]


def test_compile_rejects_circular_derived_dependencies() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="derived_a",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="derived_a",
                sql_text="SELECT ID FROM derived_b",
                parent_relation_ids=["derived_b"],
            ),
            RelationNode(
                relation_id="derived_b",
                kind=RelationNodeKind.CTE,
                alias="derived_b",
                sql_text="SELECT ID FROM derived_a",
                parent_relation_ids=["derived_a"],
            ),
        ]
    )

    try:
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                driving_relation_id="derived_a",
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="ID",
                        source_dependencies=["derived_a.ID"],
                        status="MAPPED",
                    )
                ],
            )
        )
    except ValueError as exc:
        assert "Circular derived-source dependency" in str(exc)
    else:
        raise AssertionError("Expected circular derived dependencies to be rejected")


def test_compile_rejects_column_missing_from_derived_output_contract() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="household_rollup",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="household_rollup_1",
                sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES",
                output_columns=[
                    {"name": "CONTACT_ID", "data_type": "NUMBER"},
                    {"name": "HOUSEHOLD_ID", "data_type": "NUMBER"},
                ],
            )
        ]
    )

    try:
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="LEGACY_FIRM_INFO__C",
                        source_columns=["household_rollup.MISSING_LEGACY_INFO"],
                        source_dependencies=["household_rollup.MISSING_LEGACY_INFO"],
                        status="MAPPED",
                    )
                ],
            )
        )
    except ValueError as exc:
        assert "is not produced by relation household_rollup" in str(exc)
    else:
        raise AssertionError("Expected missing derived output to be rejected")


def test_compile_resolves_a_project_attribute_placeholder_inside_an_expression() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_9",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="backup-owner",
                value="$BackupOwnerID",
                is_placeholder=True,
                resolution_status="project_attribute",
                resolved_value="005Qi00000ZBGiAIAX",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            target_table=TableRef(database="DB", schema="CRM", table="TARGET"),
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="OWNERID",
                    source_columns=["DB.CRM.CONTACTS.ID"],
                    source_dependencies=["DB.CRM.CONTACTS.ID"],
                    expression="COALESCE(contacts_9.ID, $BackupOwnerID)",
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert response.unresolved_placeholders == []
    assert "$BackupOwnerID" not in response.preview_sql
    assert "COALESCE(contacts_9.ID, '005Qi00000ZBGiAIAX')" in response.preview_sql


def _bare_qualifier_graph(second_schema: str = "CRM") -> RelationGraphContext:
    return RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_9",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id=f"DB.{second_schema}.ADDRESSES",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="addresses_18",
                table=TableRef(database="DB", schema=second_schema, table="ADDRESSES"),
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id=f"DB.{second_schema}.ADDRESSES",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID", right_column="ADDRESSABLE_ID", operator="="
                    )
                ],
            )
        ],
    )


def _bare_qualifier_request(
    graph: RelationGraphContext, expression: str
) -> MappingSqlCompileRequest:
    return MappingSqlCompileRequest(
        relation_graph=graph,
        target_table=TableRef(database="DB", schema="CRM", table="TARGET"),
        driving_relation_id="DB.CRM.CONTACTS",
        validate_with_explain=False,
        mappings=[
            MappingSqlMappingItem(
                target_column="BILLINGCOUNTRY",
                source_columns=["DB.CRM.CONTACTS.ID"],
                source_dependencies=["DB.CRM.CONTACTS.ID"],
                expression=expression,
                status="MAPPED",
            )
        ],
    )


def test_compile_resolves_a_bare_table_name_qualifier_to_its_alias() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.compile(
        _bare_qualifier_request(
            _bare_qualifier_graph(),
            "NULLIF(UPPER(TRIM(ADDRESSES.COUNTRY)), '')",
        )
    )

    assert response.ready is True
    assert "addresses_18.COUNTRY" in response.preview_sql
    assert "ADDRESSES.COUNTRY" not in response.preview_sql
    assert "LEFT JOIN DB.CRM.ADDRESSES AS addresses_18" in response.preview_sql


def test_compile_resolves_a_schema_qualified_table_name_to_its_alias() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.compile(
        _bare_qualifier_request(
            _bare_qualifier_graph(),
            "TRIM(CRM.ADDRESSES.COUNTRY)",
        )
    )

    assert response.ready is True
    assert "addresses_18.COUNTRY" in response.preview_sql


def test_compile_still_rejects_an_unknown_bare_table_name() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    with pytest.raises(ValueError, match="Undefined SQL alias in mapping expression: PHONES"):
        service.compile(
            _bare_qualifier_request(_bare_qualifier_graph(), "TRIM(PHONES.NUMBER)")
        )


def test_compile_refuses_an_ambiguous_bare_table_name() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = _bare_qualifier_graph(second_schema="BILLING")
    graph.nodes.append(
        RelationNode(
            relation_id="DB.SHIPPING.ADDRESSES",
            kind=RelationNodeKind.PHYSICAL_TABLE,
            alias="addresses_21",
            table=TableRef(database="DB", schema="SHIPPING", table="ADDRESSES"),
        )
    )

    with pytest.raises(ValueError, match="Undefined SQL alias in mapping expression: ADDRESSES"):
        service.compile(_bare_qualifier_request(graph, "TRIM(ADDRESSES.COUNTRY)"))

    response = service.compile(
        _bare_qualifier_request(graph, "TRIM(BILLING.ADDRESSES.COUNTRY)")
    )
    assert response.ready is True
    assert "addresses_18.COUNTRY" in response.preview_sql


def test_compile_inherits_parent_join_for_a_disconnected_derived_source() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="DB.CRM.ADDRESSES",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="addresses_2",
                table=TableRef(database="DB", schema="CRM", table="ADDRESSES"),
            ),
            RelationNode(
                relation_id="billing_address",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="billing_address_3",
                sql_text=(
                    "SELECT a.ADDRESSABLE_ID AS CONTACT_ID, a.COUNTRY "
                    "FROM DB.CRM.ADDRESSES AS a WHERE a.IS_PRIMARY = 1"
                ),
                output_columns=[{"name": "CONTACT_ID"}, {"name": "COUNTRY"}],
                column_semantics=[
                    {
                        "name": "CONTACT_ID",
                        "source_columns": ["a.ADDRESSABLE_ID"],
                    },
                    {"name": "COUNTRY", "source_columns": ["a.COUNTRY"]},
                ],
                base_relation_ids=["DB.CRM.ADDRESSES"],
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="DB.CRM.ADDRESSES",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID",
                        right_column="ADDRESSABLE_ID",
                        operator="=",
                    )
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="BILLINGCOUNTRY",
                    source_dependencies=["billing_address.COUNTRY"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "LEFT JOIN billing_address_3" in response.preview_sql
    assert "contacts_1.ID = billing_address_3.CONTACT_ID" in response.preview_sql


def test_compile_does_not_inherit_a_join_when_the_parent_key_was_dropped() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="DB.CRM.ADDRESSES",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="addresses_2",
                table=TableRef(database="DB", schema="CRM", table="ADDRESSES"),
            ),
            RelationNode(
                relation_id="billing_address",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="billing_address_3",
                sql_text="SELECT a.COUNTRY FROM DB.CRM.ADDRESSES AS a",
                output_columns=[{"name": "COUNTRY"}],
                column_semantics=[
                    {"name": "COUNTRY", "source_columns": ["a.COUNTRY"]}
                ],
                base_relation_ids=["DB.CRM.ADDRESSES"],
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="DB.CRM.ADDRESSES",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID",
                        right_column="ADDRESSABLE_ID",
                        operator="=",
                    )
                ],
            )
        ],
    )

    with pytest.raises(ValueError, match="Required relations are disconnected"):
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                driving_relation_id="DB.CRM.CONTACTS",
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="BILLINGCOUNTRY",
                        source_dependencies=["billing_address.COUNTRY"],
                        status="MAPPED",
                    )
                ],
            )
        )


def test_derived_lineage_does_not_invent_join_or_change_driver():
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(nodes=[
        RelationNode(relation_id="DB.CRM.ACCOUNTS", kind=RelationNodeKind.PHYSICAL_TABLE,
                     alias="accounts", table=TableRef(database="DB", schema="CRM", table="ACCOUNTS")),
        RelationNode(relation_id="filtered_accounts", kind=RelationNodeKind.DERIVED_SOURCE,
                     alias="filtered_accounts", sql_text="SELECT ID FROM DB.CRM.ACCOUNTS WHERE ACTIVE = TRUE",
                     output_columns=[{"name": "ID"}], base_relation_ids=["DB.CRM.ACCOUNTS"]),
    ])
    request = MappingSqlCompileRequest(relation_graph=graph, driving_relation_id="DB.CRM.ACCOUNTS",
        validate_with_explain=False, mappings=[MappingSqlMappingItem(target_column="ID",
            source_dependencies=["filtered_accounts.ID"], status="MAPPED")])
    with pytest.raises(ValueError, match="lineage is not an outer join"):
        service.compile(request)
    assert request.driving_relation_id == "DB.CRM.ACCOUNTS"
    assert request.relation_graph.edges == []
    request.driving_relation_id = "filtered_accounts"
    response = service.compile(request)
    assert "ACTIVE = TRUE" in response.preview_sql
    assert "FROM filtered_accounts" in response.preview_sql


def test_compile_resolves_dependency_relation_id_case_insensitively() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ]
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="OWNER_ID",
                    source_dependencies=["db.crm.contacts.ID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "contacts_1.ID AS OWNER_ID" in response.preview_sql


def test_compile_reverses_left_join_when_driving_from_right_endpoint() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.PARENT",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="parent_1",
                table=TableRef(database="DB", schema="CRM", table="PARENT"),
            ),
            RelationNode(
                relation_id="DB.CRM.CHILD",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="child_2",
                table=TableRef(database="DB", schema="CRM", table="CHILD"),
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="parent-child",
                left_relation_id="DB.CRM.PARENT",
                right_relation_id="DB.CRM.CHILD",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID",
                        right_column="PARENT_ID",
                        operator="=",
                    )
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CHILD",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    source_dependencies=["DB.CRM.PARENT.ID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert "FROM DB.CRM.CHILD AS child_2" in response.preview_sql
    assert "RIGHT JOIN DB.CRM.PARENT AS parent_1" in response.preview_sql


def test_compile_normalizes_driving_and_edge_relation_ids_case_insensitively() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.PARENT",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="parent_1",
                table=TableRef(database="DB", schema="CRM", table="PARENT"),
            ),
            RelationNode(
                relation_id="DB.CRM.CHILD",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="child_2",
                table=TableRef(database="DB", schema="CRM", table="CHILD"),
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="parent-child",
                left_relation_id="db.crm.parent",
                right_relation_id="db.crm.child",
                join_type="INNER",
                conditions=[
                    RelationshipConditionItem(left_column="ID", right_column="PARENT_ID")
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="db.crm.child",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    source_dependencies=["db.crm.parent.ID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "JOIN DB.CRM.PARENT AS parent_1" in response.preview_sql


def _firm_values() -> list[SimpleNamespace]:
    """Project attributes as stored (TBL_PROJECT_ATTRIBUTES), mixed types."""
    return [
        SimpleNamespace(attribute_name="TransactionFirmID", attribute_type="VARCHAR", attribute_value="001Qi00001RTLXGIA5"),
        SimpleNamespace(attribute_name="LegacyHHcPrefix", attribute_type="VARCHAR", attribute_value="EVR_RT_"),
        SimpleNamespace(attribute_name="BackupOwnerID", attribute_type="VARCHAR", attribute_value="005Qi00000ZBGiAIAX"),
        SimpleNamespace(attribute_name="ID", attribute_type="INT", attribute_value="11"),
        SimpleNamespace(attribute_name="ClientStartDate", attribute_type="DATE", attribute_value="2026-01-01"),
    ]


def _contacts_graph(**kwargs) -> RelationGraphContext:
    return RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            *kwargs.pop("extra_nodes", []),
        ],
        **kwargs,
    )


def test_firm_values_resolve_in_every_shape_the_ui_and_agents_save() -> None:
    """Saved rows: source-mode whole placeholder, placeholder inside custom SQL,
    agent casing, quoted placeholder, and placeholder in WHERE/QUALIFY."""
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    # The compile graph the mapping page builds: a placeholder contract, no value.
    graph = _contacts_graph(
        value_bindings=[
            ValueBinding(binding_id="firm", value="$TransactionFirmID", is_placeholder=True,
                         resolution_status="placeholder_contract"),
        ]
    )
    graph = MappingSqlService.with_project_values(graph, _firm_values())

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            where_predicates=["contacts_1.FIRM_ID = $TRANSACTIONFIRMID"],
            qualify_predicates=["contacts_1.START_DATE >= $ClientStartDate"],
            mappings=[
                MappingSqlMappingItem(target_column="TRANSACTION_FIRM__C", source_dependencies=["DB.CRM.CONTACTS.ID"],
                                      expression="$TransactionFirmID", value_binding_ids=["firm"], status="MAPPED"),
                MappingSqlMappingItem(target_column="LEGACY_ID__C", source_dependencies=["DB.CRM.CONTACTS.ID"],
                                      expression="$LegacyHHcPrefix || contacts_1.ID", status="MAPPED"),
                MappingSqlMappingItem(target_column="OWNERID", source_dependencies=["DB.CRM.CONTACTS.OWNER_ID"],
                                      expression="COALESCE(NULLIF(TRIM(contacts_1.OWNER_ID), ''), '$backupownerid')",
                                      status="MAPPED"),
                MappingSqlMappingItem(target_column="EXTERNAL_ID", mapping_mode="attribute", constant_value="$id",
                                      status="MAPPED"),
                MappingSqlMappingItem(target_column="NOTE", source_dependencies=["DB.CRM.CONTACTS.ID"],
                                      expression="'Cost $5 per $TransactionFirmID row'", status="MAPPED"),
            ],
        )
    )

    sql = response.preview_sql
    assert response.ready is True and response.unresolved_placeholders == []
    assert "'001Qi00001RTLXGIA5' AS TRANSACTION_FIRM__C" in sql
    assert "'EVR_RT_' || contacts_1.ID AS LEGACY_ID__C" in sql
    assert "COALESCE(NULLIF(TRIM(contacts_1.OWNER_ID), ''), '005Qi00000ZBGiAIAX') AS OWNERID" in sql
    assert "11 AS EXTERNAL_ID" in sql  # INT firm value stays numeric
    assert "contacts_1.FIRM_ID = '001Qi00001RTLXGIA5'" in sql
    assert "contacts_1.START_DATE >= '2026-01-01'" in sql
    assert "'Cost $5 per $TransactionFirmID row'" in sql  # text inside a literal is never rewritten


def test_firm_values_resolve_inside_cte_sql_and_join_predicates() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = _contacts_graph(
        extra_nodes=[
            RelationNode(
                relation_id="firm_households",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="firm_households_2",
                sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES WHERE FIRM = $TransactionFirmID",
            )
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-households",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="firm_households",
                join_type="LEFT",
                conditions=[RelationshipConditionItem(left_column="ID", right_column="CONTACT_ID", operator="=")],
                additional_predicate="contacts_1.OWNER_ID <> $BackupOwnerID",
            )
        ],
    )
    graph = MappingSqlService.with_project_values(graph, _firm_values())

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(target_column="HOUSEHOLD_ID", source_dependencies=["firm_households_2.HOUSEHOLD_ID"],
                                      status="MAPPED"),
            ],
        )
    )

    assert "WHERE FIRM = '001Qi00001RTLXGIA5'" in response.preview_sql
    assert "(contacts_1.OWNER_ID <> '005Qi00000ZBGiAIAX')" in response.preview_sql
    assert "$" not in response.preview_sql


def test_placeholder_left_in_a_custom_transformation_blocks_execution() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = MappingSqlService.with_project_values(_contacts_graph(), _firm_values())

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            allow_unresolved_placeholders=True,
            mappings=[
                MappingSqlMappingItem(target_column="PARENTID", source_dependencies=["DB.CRM.CONTACTS.ID"],
                                      expression="COALESCE(contacts_1.PARENT_ID, $ParentOfficeID)", status="MAPPED"),
                MappingSqlMappingItem(target_column="RECORDTYPEID", source_dependencies=["DB.CRM.CONTACTS.ID"],
                                      expression="'$HHRecordType'", status="MAPPED"),
            ],
        )
    )

    # Not project firm values: reported by name instead of silently loading "$Name".
    assert response.ready is False
    assert response.unresolved_placeholders == ["$HHRecordType", "$ParentOfficeID"]
    assert any("$ParentOfficeID" in warning for warning in response.warnings)


def test_project_values_take_stored_value_and_type_over_frontend_binding() -> None:
    graph = _contacts_graph(
        value_bindings=[
            ValueBinding(binding_id="ui-firm", value="$TRANSACTIONFIRMID", resolved_value="stale",
                         data_type="NUMBER", is_placeholder=True, resolution_status="resolved"),
        ]
    )
    bindings = {b.binding_id: b for b in MappingSqlService.with_project_values(graph, _firm_values()).value_bindings}

    assert bindings["ui-firm"].resolved_value == "001Qi00001RTLXGIA5"
    assert bindings["ui-firm"].data_type == "VARCHAR"
    assert bindings["ui-firm"].resolution_status == "project_attribute"
    assert "project-TransactionFirmID" not in bindings  # matched in place, not duplicated
    assert bindings["project-LegacyHHcPrefix"].value == "$LegacyHHcPrefix"


def test_preview_sql_is_resolved_with_project_values_before_execution() -> None:
    payload = MappingSqlPreviewRequest(
        source_query_sql="SELECT 1",
        preview_sql="SELECT $LegacyHHcPrefix || c.ID AS LEGACY_ID FROM DB.CRM.CONTACTS c",
        generated_sql="INSERT INTO T (LEGACY_ID) SELECT $LegacyHHcPrefix || c.ID FROM DB.CRM.CONTACTS c",
        project_id="1701",
    )
    payload.relation_graph = MappingSqlService.with_project_values(payload.relation_graph, _firm_values())
    MappingSqlService.resolve_payload_sql(payload)

    assert payload.preview_sql == "SELECT 'EVR_RT_' || c.ID AS LEGACY_ID FROM DB.CRM.CONTACTS c"
    assert "$" not in payload.generated_sql


def test_mapping_sql_routes_load_firm_values_for_the_request_project() -> None:
    import app.api  # noqa: F401  (router package import order)
    from app.routers.mapping_sql import _resolve_project_values

    class _Projects:
        def __init__(self):
            self.calls = []

        def list_project_attributes(self, project_id):
            self.calls.append(project_id)
            return _firm_values()

    projects = _Projects()
    payload = MappingSqlPreviewRequest(source_query_sql="SELECT 1", preview_sql="SELECT $ID AS X",
                                       generated_sql="SELECT $ID AS X")
    assert _resolve_project_values(payload, {"project_id": "1701"}, projects) == []
    assert projects.calls == ["1701"]
    assert payload.preview_sql == "SELECT 11 AS X"

    class _Broken:
        def list_project_attributes(self, project_id):
            raise RuntimeError("warehouse suspended")

    untouched = MappingSqlPreviewRequest(source_query_sql="SELECT 1", preview_sql="SELECT $ID AS X",
                                         generated_sql="SELECT $ID AS X", project_id="1701")
    assert _resolve_project_values(untouched, {}, _Broken())  # warns, never fails the request
    assert untouched.preview_sql == "SELECT $ID AS X"


def test_firm_values_saved_with_quotes_or_script_text_are_handled() -> None:
    """Live project data: SQL-imported values keep quotes ('Active'); one import
    captured script text into the value."""
    attributes = [
        SimpleNamespace(attribute_name="IAA_STATUS", attribute_type="VARCHAR", attribute_value="'Active'"),
        SimpleNamespace(attribute_name="LEGACY_HHC_PREFIX", attribute_type="VARCHAR", attribute_value="'EVR_RT_'"),
        SimpleNamespace(attribute_name="BackupOwnerID", attribute_type="VARCHAR",
                        attribute_value="005Qi00000bvarUIAQ';  -- TMD default SET TransactionFirmID = '001'"),
        SimpleNamespace(attribute_name="ENTITY_AGREEMENT", attribute_type="BOOLEAN", attribute_value="FALSE"),
    ]
    graph = MappingSqlService.with_project_values(RelationGraphContext(), attributes)

    sql = MappingSqlService.resolve_sql_placeholders(
        "SELECT $IAA_STATUS, $LEGACY_HHC_PREFIX || x.ID, $ENTITY_AGREEMENT, $BackupOwnerID", graph
    )
    assert sql.startswith("SELECT 'Active', 'EVR_RT_' || x.ID, FALSE, '005Qi00000bvarUIAQ'';")
    # Script text stays inside one escaped literal (never executable) and is flagged.
    assert MappingSqlService.suspicious_project_values(attributes) == ["BackupOwnerID"]


def test_identity_digest_matches_the_aliases_the_mapping_page_generates() -> None:
    from app.core.mapping_sql import _identity_digest

    # Aliases taken from live generated SQL (relation-alias.ts relationAliasFor).
    assert _identity_digest("FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS") == "9g51lg"
    assert _identity_digest("FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACT_FAMILIES") == "6kv7o4"
    assert _identity_digest("FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACT_STATUSES") == "m8x0he"


def _digest_alias_graph(**kwargs) -> RelationGraphContext:
    from app.core.mapping_sql import _identity_digest

    contacts_id = "FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS"
    derived_id = "derived-source-addresses"
    return RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id=contacts_id,
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias=f"contacts_{_identity_digest(contacts_id)}",
                table=TableRef(database="FFP_HDP_DLAB_DB_DEV", schema="SCH_TMD_SOURCE", table="CONTACTS"),
            ),
            RelationNode(
                relation_id=derived_id,
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias=f"addresses_one_per_contacts_{_identity_digest(derived_id)}",
                sql_text=(
                    "SELECT CONTACT_ID, ZIP FROM FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.ADDRESSES "
                    "QUALIFY ROW_NUMBER() OVER (PARTITION BY CONTACT_ID ORDER BY ID) = 1"
                ),
                output_columns=[{"name": "CONTACT_ID"}, {"name": "ZIP"}],
            ),
            *kwargs.pop("extra_nodes", []),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id=contacts_id,
                right_relation_id=derived_id,
                join_type="LEFT",
                conditions=[RelationshipConditionItem(left_column="ID", right_column="CONTACT_ID", operator="=")],
            )
        ],
        **kwargs,
    )


def _digest_alias_request(graph: RelationGraphContext, **kwargs) -> MappingSqlCompileRequest:
    from app.core.mapping_sql import _identity_digest

    derived_alias = f"addresses_one_per_contacts_{_identity_digest('derived-source-addresses')}"
    contacts_alias = f"contacts_{_identity_digest('FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS')}"
    return MappingSqlCompileRequest(
        relation_graph=graph,
        driving_relation_id="FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS",
        validate_with_explain=False,
        mappings=[
            MappingSqlMappingItem(target_column="BILLINGPOSTALCODE", source_dependencies=[f"{derived_alias}.ZIP"],
                                  status="MAPPED"),
            MappingSqlMappingItem(target_column="LEGACY_ID__C", source_dependencies=[f"{contacts_alias}.ID"],
                                  expression=f"$LegacyHHcPrefix || {contacts_alias}.ID", status="MAPPED"),
            MappingSqlMappingItem(target_column="TRANSACTION_FIRM__C", mapping_mode="attribute",
                                  constant_value="$TRANSACTIONFIRMID", status="MAPPED"),
        ],
        **kwargs,
    )


def test_compiled_sql_names_relations_by_their_table_or_cte_name() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = MappingSqlService.with_project_values(_digest_alias_graph(), _firm_values())

    response = service.compile(_digest_alias_request(graph))

    sql = response.preview_sql
    assert "addresses_one_per_contacts AS (" in sql
    assert "addresses_one_per_contacts.ZIP AS BILLINGPOSTALCODE" in sql
    assert "FROM FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS AS contacts" in sql
    assert "ON contacts.ID = addresses_one_per_contacts.CONTACT_ID" in sql
    assert not re.search(r"_[0-9a-z]{6}\b", sql.replace("SCH_TMD_SOURCE", ""))
    # The workspace keeps its stable digest aliases.
    assert response.relation_aliases["derived-source-addresses"].startswith("addresses_one_per_contacts_")


def test_duplicate_table_names_use_stable_schema_labels():
    from app.core.mapping_sql import _identity_digest
    nodes = [RelationNode(relation_id=f'DB.{schema}.ACCOUNTS', kind=RelationNodeKind.PHYSICAL_TABLE,
                          alias=f'accounts_{_identity_digest(f"DB.{schema}.ACCOUNTS")}',
                          table=TableRef(database='DB', schema=schema, table='ACCOUNTS'))
             for schema in ['CRM', 'BILLING']]
    before = MappingSqlService._display_aliases(nodes)
    assert set(before.values()) == {'accounts_crm', 'accounts_billing'}
    assert MappingSqlService._display_aliases(list(reversed(nodes))) == before


def test_learned_expression_must_use_current_alias_not_historical_alias():
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = _digest_alias_graph()
    current = graph.nodes[0].alias
    graph = graph.model_copy(update={'nodes': [graph.nodes[0]], 'edges': []})
    request = MappingSqlCompileRequest(
        relation_graph=graph, driving_relation_id=graph.nodes[0].relation_id,
        validate_with_explain=False,
        mappings=[MappingSqlMappingItem(target_column='ID', status='MAPPED',
            source_dependencies=[f'{current}.ID'], expression='TRIM(old_mapping_alias.ID)')],
    )
    with pytest.raises(ValueError, match='Undefined SQL alias'):
        service.compile(request)
    request.mappings[0].expression = f'TRIM({current}.ID)'
    response = service.compile(request)
    assert 'TRIM(contacts.ID)' in response.preview_sql
    assert graph.nodes[0].alias == current


def test_readable_alias_changes_only_bound_identifiers():
    sql = "SELECT src_ab1234.ID, 'src_ab1234.ID', $$src_ab1234.ID$$ FROM DB.S.T AS src_ab1234 -- src_ab1234.ID\nWHERE EXISTS (SELECT 1 FROM DB.S.U AS src_ab1234 WHERE src_ab1234.ID = 1)"
    result = MappingSqlService._with_display_aliases(sql, {'src_ab1234': 'src'})
    assert result.startswith("SELECT src.ID, 'src_ab1234.ID', $$src_ab1234.ID$$ FROM DB.S.T AS src -- src_ab1234.ID")
    assert "FROM DB.S.U AS src_ab1234 WHERE src_ab1234.ID = 1" in result


def test_readable_alias_preserves_correlated_binding_and_avoids_capture():
    sql = 'SELECT src_ab1234.ID FROM DB.S.T AS src_ab1234 WHERE EXISTS (SELECT 1 FROM DB.S.U AS other WHERE other.ID = src_ab1234.ID)'
    result = MappingSqlService._with_display_aliases(sql, {'src_ab1234': 'src'})
    assert 'other.ID = src.ID' in result
    occupied = sql.replace('AS other', 'AS src').replace('other.ID', 'src.ID')
    assert MappingSqlService._with_display_aliases(occupied, {'src_ab1234': 'src'}) == occupied


def test_readable_name_is_skipped_when_it_would_collide_or_shadow() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    shadowing = RelationNode(
        relation_id="derived-uses-bare-contacts",
        kind=RelationNodeKind.DERIVED_SOURCE,
        alias="contacts_x",  # not a digest alias; stays as is
        sql_text="SELECT ID FROM addresses_one_per_contacts",
        output_columns=[{"name": "ID"}],
    )
    graph = MappingSqlService.with_project_values(
        _digest_alias_graph(extra_nodes=[shadowing]), _firm_values()
    )

    sql = service.compile(_digest_alias_request(graph)).preview_sql

    # A CTE named addresses_one_per_contacts would shadow the bare table reference.
    assert "addresses_one_per_contacts_" in sql
    assert "AS contacts\n" in sql or "AS contacts" in sql


def test_compile_returns_a_set_script_with_the_projects_firm_value_names() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = MappingSqlService.with_project_values(_digest_alias_graph(), _firm_values())

    response = service.compile(_digest_alias_request(graph))

    assert response.ready is True
    # Execution form: one statement with the values inlined.
    assert "'001Qi00001RTLXGIA5' AS TRANSACTION_FIRM__C" in response.preview_sql
    assert "$" not in response.preview_sql
    script = response.script_sql or ""
    assert script.startswith("-- Firm values\n")
    assert "SET LegacyHHcPrefix = 'EVR_RT_';" in script
    assert "SET TransactionFirmID = '001Qi00001RTLXGIA5';" in script
    assert "SET BackupOwnerID" not in script  # only values the query uses
    assert "$TransactionFirmID AS TRANSACTION_FIRM__C" in script
    assert "$LegacyHHcPrefix || contacts.ID AS LEGACY_ID__C" in script
    assert "INSERT" not in script.upper()
    assert script.rstrip().endswith(";")


def test_compile_has_no_script_when_no_firm_value_is_used() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = MappingSqlService.with_project_values(_contacts_graph(), _firm_values())

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[MappingSqlMappingItem(target_column="ID", source_dependencies=["contacts_1.ID"],
                                            status="MAPPED")],
        )
    )

    assert response.script_sql is None


class _MustNotRunSession:
    def sql(self, *_args, **_kwargs):
        raise AssertionError("Snowflake must not be called for undefined firm values")


def test_review_stops_before_snowflake_when_a_firm_value_is_not_defined() -> None:
    service = MappingSqlService(session=_MustNotRunSession(), analyst_client=_Analyst())
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT $ClientStartDate AS LEGACY_FIRM_INFO__C FROM DB.SCHEMA.SRC",
        generated_sql="SELECT $ClientStartDate AS LEGACY_FIRM_INFO__C FROM DB.SCHEMA.SRC",
        semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
    )

    response = service.review(request)

    assert response.execution_ready is False and response.valid is False
    assert "Firm value $ClientStartDate is not defined for this project" in response.review_summary
    assert "session variable" not in response.review_summary.lower()
    assert [item.code for item in response.repair_options] == ["resolve_value_binding", "edit_sql"]
    assert response.repair_options[0].identifier == "$ClientStartDate"
@pytest.mark.parametrize('value',['',' ',' leading and trailing '],ids=['empty','space','padded'])
def test_text_constants_preserve_authored_empty_and_whitespace(value):
    from sqlglot import parse_one,exp
    expression=parse_one(MappingSqlService._compile_constant(value,'VARCHAR'),read='snowflake')
    assert isinstance(expression,exp.Literal) and expression.is_string and expression.this==value
