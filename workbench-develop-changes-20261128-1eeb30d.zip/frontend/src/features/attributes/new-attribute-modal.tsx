"use client";
/* eslint-disable react-hooks/set-state-in-effect -- Form state must hydrate when edit-modal inputs change. */

import { useEffect, useMemo, useState } from "react";
import {
  AiaBox,
  AiaButton,
  AiaIconButton,
  AiaInput,
  AiaSelect,
  AiaStack,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { AddRoundedIcon, CloseOutlinedIcon, LockOutlinedIcon } from "@/utils/icons";

import {
  ATTRIBUTE_TYPE_OPTIONS,
  firmValueConflictMessage,
  firmValueSharedValueWarning,
  getAttributeNameValidationError,
  isValidAttributeName,
  type AttributeType,
  type FirmValueIdentity,
  type HardcodedAttribute,
  type NewAttributeFormValues,
} from "./attributes-data";

const CREATE_ROW_COUNT = 5;

type DraftRow = {
  id: string;
  attributeName: string;
  attributeType: AttributeType | "";
  attributeValue: string;
  nameTouched: boolean;
};

type NewAttributeModalProps = {
  open: boolean;
  projectName: string;
  mode?: "create" | "edit";
  initialValues?: HardcodedAttribute | null;
  existingFirmValues?: FirmValueIdentity[];
  ignoreFirmValueId?: string;
  onClose: () => void;
  onSubmit: (values: NewAttributeFormValues[]) => void | Promise<void>;
};

const fieldLabelSx = {
  fontSize: 10,
  fontWeight: 700,
  letterSpacing: "0.08em",
  color: "#94A3B8",
  mb: 0.75,
} as const;

const inputSx = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "10px",
    fontSize: 14,
    color: "var(--aia-text-color)",
    backgroundColor: "#FFFFFF",
    "& fieldset": {
      borderColor: "#E5E7EB",
    },
    "&:hover fieldset": {
      borderColor: "#C7D2FE",
    },
    "&.Mui-focused fieldset": {
      borderColor: "#818CF8",
      borderWidth: "1px",
    },
    "&.Mui-disabled": {
      backgroundColor: "#F8FAFC",
    },
  },
  "& .MuiInputBase-input::placeholder": {
    color: "#94A3B8",
    opacity: 1,
  },
} as const;

const compactInputSx = {
  ...inputSx,
  "& .MuiOutlinedInput-root": {
    ...inputSx["& .MuiOutlinedInput-root"],
    borderRadius: "8px",
    fontSize: 13,
    minHeight: 38,
  },
} as const;

const inputErrorSx = {
  ...inputSx,
  "& .MuiOutlinedInput-root": {
    ...inputSx["& .MuiOutlinedInput-root"],
    "& fieldset": {
      borderColor: "#FCA5A5",
    },
    "&:hover fieldset": {
      borderColor: "#F87171",
    },
    "&.Mui-focused fieldset": {
      borderColor: "#EF4444",
      borderWidth: "1px",
    },
  },
} as const;

const compactErrorSx = {
  ...compactInputSx,
  "& .MuiOutlinedInput-root": {
    ...compactInputSx["& .MuiOutlinedInput-root"],
    "& fieldset": {
      borderColor: "#FCA5A5",
    },
  },
} as const;

const fieldHintSx = {
  fontSize: 11,
  color: "#94A3B8",
  mt: 0.75,
  lineHeight: 1.4,
} as const;

const fieldErrorSx = {
  fontSize: 14,
  fontWeight: 400,
  color: "#DC2626",
  mt: 0.75,
  lineHeight: 1.5,
} as const;

const cellHintSx = {
  fontSize: 11,
  fontWeight: 400,
  color: "#DC2626",
  mt: 0.5,
  lineHeight: 1.35,
} as const;

const headerCellSx = {
  fontSize: 10,
  fontWeight: 700,
  letterSpacing: "0.06em",
  color: "#64748B",
  pb: 1,
} as const;

function emptyDraftRow(): DraftRow {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    attributeName: "",
    attributeType: "",
    attributeValue: "",
    nameTouched: false,
  };
}

function isRowStarted(row: DraftRow) {
  return Boolean(row.attributeName.trim() || row.attributeType || row.attributeValue.trim());
}

function isRowComplete(row: DraftRow) {
  return Boolean(
    isValidAttributeName(row.attributeName) && row.attributeType && row.attributeValue.trim(),
  );
}

export default function NewAttributeModal({
  open,
  projectName,
  mode = "create",
  initialValues = null,
  existingFirmValues = [],
  ignoreFirmValueId,
  onClose,
  onSubmit,
}: NewAttributeModalProps) {
  const isEdit = mode === "edit";
  const [attributeName, setAttributeName] = useState("");
  const [attributeType, setAttributeType] = useState<AttributeType | "">("");
  const [attributeValue, setAttributeValue] = useState("");
  const [attributeNameTouched, setAttributeNameTouched] = useState(false);
  const [rows, setRows] = useState<DraftRow[]>(() =>
    Array.from({ length: CREATE_ROW_COUNT }, emptyDraftRow),
  );
  const [submitAttempted, setSubmitAttempted] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      return;
    }
    setSubmitError(null);
    setIsSubmitting(false);
    setSubmitAttempted(false);
    if (isEdit && initialValues) {
      setAttributeName(initialValues.attributeName);
      setAttributeType(initialValues.attributeType);
      setAttributeValue(initialValues.attributeValue);
      setAttributeNameTouched(false);
      return;
    }
    setAttributeName("");
    setAttributeType("");
    setAttributeValue("");
    setAttributeNameTouched(false);
    setRows(Array.from({ length: CREATE_ROW_COUNT }, emptyDraftRow));
  }, [open, isEdit, initialValues]);

  const attributeNameError = useMemo(
    () => (attributeNameTouched ? getAttributeNameValidationError(attributeName) : null),
    [attributeName, attributeNameTouched],
  );

  const nameConflictError = useMemo(
    () =>
      firmValueConflictMessage(existingFirmValues, {
        attributeName,
        ignoreId: ignoreFirmValueId,
      }),
    [attributeName, existingFirmValues, ignoreFirmValueId],
  );

  const nameFieldError = attributeNameError || nameConflictError;

  const sharedValueWarning = useMemo(
    () =>
      firmValueSharedValueWarning(existingFirmValues, {
        attributeName,
        attributeValue,
        ignoreId: ignoreFirmValueId,
      }),
    [attributeName, attributeValue, existingFirmValues, ignoreFirmValueId],
  );

  const createRowIssues = useMemo(() => {
    if (isSubmitting) {
      return new Map<string, { name?: string; warning?: string }>();
    }
    const issues = new Map<string, { name?: string; warning?: string }>();
    const seen = new Map<string, string>();
    for (const row of rows) {
      if (!isRowStarted(row) && !submitAttempted) {
        continue;
      }
      if (!isRowStarted(row)) {
        continue;
      }
      const nameIssue =
        getAttributeNameValidationError(row.attributeName)
        || firmValueConflictMessage(existingFirmValues, { attributeName: row.attributeName });
      const key = row.attributeName.trim().toUpperCase();
      const duplicateInBatch = key && seen.has(key)
        ? `Project value ${row.attributeName.trim()} already exists.`
        : null;
      if (key) {
        seen.set(key, row.id);
      }
      const warning = firmValueSharedValueWarning(
        [
          ...existingFirmValues,
          ...rows
            .filter((item) => item.id !== row.id && isRowStarted(item))
            .map((item) => ({
              id: item.id,
              attributeName: item.attributeName,
              attributeValue: item.attributeValue,
            })),
        ],
        { attributeName: row.attributeName, attributeValue: row.attributeValue },
      );
      const name = nameIssue || duplicateInBatch || undefined;
      if (name || warning) {
        issues.set(row.id, { name, warning: warning ?? undefined });
      }
    }
    return issues;
  }, [existingFirmValues, isSubmitting, rows, submitAttempted]);

  const completeCreateRows = useMemo(
    () => rows.filter((row) => isRowComplete(row) && !createRowIssues.get(row.id)?.name),
    [createRowIssues, rows],
  );

  const createCanSubmit = completeCreateRows.length > 0
    && rows.filter(isRowStarted).every((row) => isRowComplete(row) && !createRowIssues.get(row.id)?.name)
    && Boolean(projectName.trim());

  const editCanSubmit = Boolean(
    isValidAttributeName(attributeName)
      && !nameConflictError
      && attributeType
      && projectName.trim()
      && attributeValue.trim(),
  );

  const canSubmit = isEdit ? editCanSubmit : createCanSubmit;

  const updateRow = (id: string, patch: Partial<DraftRow>) => {
    setSubmitError(null);
    setRows((current) => current.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  };

  const handleClose = () => {
    onClose();
  };

  const handleSubmit = async () => {
    if (isSubmitting) {
      return;
    }
    if (isEdit) {
      setAttributeNameTouched(true);
      if (!editCanSubmit || !attributeType) {
        return;
      }
      setSubmitError(null);
      setIsSubmitting(true);
      try {
        await onSubmit([
          {
            attributeName: attributeName.trim(),
            attributeType,
            projectName: projectName.trim(),
            attributeValue: attributeValue.trim(),
          },
        ]);
        onClose();
      } catch (error) {
        setIsSubmitting(false);
        setSubmitError(
          error instanceof Error && error.message
            ? error.message
            : "Unable to save the firm value.",
        );
      }
      return;
    }

    setSubmitAttempted(true);
    const started = rows.filter(isRowStarted);
    if (!started.length || !createCanSubmit) {
      setSubmitError(started.length ? null : "Enter at least one firm value.");
      return;
    }
    setSubmitError(null);
    setIsSubmitting(true);
    try {
      await onSubmit(
        completeCreateRows.map((row) => ({
          attributeName: row.attributeName.trim(),
          attributeType: row.attributeType as AttributeType,
          projectName: projectName.trim(),
          attributeValue: row.attributeValue.trim(),
        })),
      );
      onClose();
    } catch (error) {
      setIsSubmitting(false);
      setSubmitError(
        error instanceof Error && error.message
          ? error.message
          : "Unable to save the firm values.",
      );
    }
  };

  if (!open) {
    return null;
  }

  const title = isEdit ? "Edit Attribute" : "New Attribute";
  const submitLabel = isEdit ? "Save" : "Add";

  return (
    <AiaBox
      role="dialog"
      aria-modal="true"
      aria-label={title}
      sx={{
        position: "fixed",
        inset: 0,
        zIndex: 1400,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        p: 2,
      }}
    >
      <AiaBox
        onClick={handleClose}
        sx={{
          position: "absolute",
          inset: 0,
          bgcolor: "rgba(15, 23, 42, 0.45)",
        }}
      />

      <AiaBox
        sx={{
          position: "relative",
          width: "100%",
          maxWidth: isEdit ? 480 : 960,
          maxHeight: "calc(100vh - 48px)",
          display: "flex",
          flexDirection: "column",
          borderRadius: "16px",
          bgcolor: "#FFFFFF",
          border: "1px solid #E5E7EB",
          boxShadow: "0 24px 60px rgba(15, 23, 42, 0.18)",
          overflow: "hidden",
        }}
      >
        <AiaBox
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 1.5,
            px: 2.5,
            py: 2,
            borderBottom: "1px solid #F1F5F9",
            flexShrink: 0,
          }}
        >
          <AiaStack direction="row" spacing={1.25} sx={{ alignItems: "center", minWidth: 0 }}>
            <AiaBox
              sx={{
                width: 36,
                height: 36,
                borderRadius: "10px",
                bgcolor: "#F1F5F9",
                color: "#475569",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <LockOutlinedIcon sx={{ fontSize: 18 }} />
            </AiaBox>
            <AiaText sx={{ fontSize: 16, fontWeight: 600, color: "var(--aia-text-color)" }}>
              {title}
            </AiaText>
          </AiaStack>
          <AiaIconButton
            aria-label={`Close ${title.toLowerCase()} dialog`}
            onClick={handleClose}
            sx={{
              width: 32,
              height: 32,
              color: "#64748B",
              border: "1px solid #E5E7EB",
              borderRadius: "8px",
            }}
          >
            <CloseOutlinedIcon sx={{ fontSize: 18 }} />
          </AiaIconButton>
        </AiaBox>

        {isEdit ? (
          <AiaBox sx={{ px: 2.5, py: 2.25, overflow: "auto" }}>
            <AiaBox sx={{ mb: 2 }}>
              <AiaText sx={fieldLabelSx}>ATTRIBUTE NAME *</AiaText>
              <AiaInput
                fullWidth
                value={attributeName}
                onChange={(value) => {
                  setSubmitError(null);
                  setAttributeName(value.replace(/[^A-Za-z0-9_]/g, ""));
                }}
                onKeyDown={(event) => {
                  if (event.key === " ") {
                    event.preventDefault();
                  }
                }}
                inputProps={{
                  onBlur: () => setAttributeNameTouched(true),
                }}
                placeholder="e.g. CUSTOMER_ID"
                sx={nameFieldError ? inputErrorSx : inputSx}
              />
              {nameFieldError ? (
                <AiaText sx={fieldErrorSx}>{nameFieldError}</AiaText>
              ) : (
                <AiaText sx={fieldHintSx}>
                  Use letters, numbers, and underscores. Must start with a letter or underscore.
                </AiaText>
              )}
            </AiaBox>

            <AiaBox sx={{ mb: 2 }}>
              <AiaText sx={fieldLabelSx}>ATTRIBUTE TYPE *</AiaText>
              <AiaSelect
                fullWidth
                value={attributeType}
                options={[...ATTRIBUTE_TYPE_OPTIONS]}
                placeholder="Select attribute type"
                onChange={(value) => {
                  setSubmitError(null);
                  setAttributeType(value as AttributeType);
                }}
              />
            </AiaBox>

            <AiaBox sx={{ mb: 2 }}>
              <AiaText sx={fieldLabelSx}>PROJECT NAME *</AiaText>
              <AiaInput fullWidth value={projectName} disabled sx={inputSx} />
            </AiaBox>

            <AiaBox>
              <AiaText sx={fieldLabelSx}>ATTRIBUTE VALUE *</AiaText>
              <AiaInput
                fullWidth
                multiline
                minRows={3}
                value={attributeValue}
                onChange={(value) => {
                  setSubmitError(null);
                  setAttributeValue(value);
                }}
                placeholder="Enter attribute value"
                sx={inputSx}
              />
              {sharedValueWarning ? (
                <AiaText sx={{ ...fieldErrorSx, color: "#B45309" }}>{sharedValueWarning}</AiaText>
              ) : null}
            </AiaBox>
          </AiaBox>
        ) : (
          <AiaBox sx={{ px: 2.5, py: 2.25, overflow: "auto", minHeight: 0, flex: 1 }}>
            <AiaText sx={{ ...fieldHintSx, mt: 0, mb: 1.5 }}>
              Fill one or more rows. Empty rows are ignored. Use letters, numbers, and underscores for names.
            </AiaText>
            <AiaBox
              sx={{
                display: "grid",
                gridTemplateColumns: "minmax(140px, 1.1fr) 150px minmax(160px, 1.2fr) minmax(140px, 1fr)",
                columnGap: 1,
                mb: 0.75,
              }}
            >
              <AiaText sx={headerCellSx}>ATTRIBUTE NAME *</AiaText>
              <AiaText sx={headerCellSx}>ATTRIBUTE TYPE *</AiaText>
              <AiaText sx={headerCellSx}>ATTRIBUTE VALUE *</AiaText>
              <AiaText sx={headerCellSx}>PROJECT NAME *</AiaText>
            </AiaBox>
            <AiaBox sx={{ display: "flex", flexDirection: "column", gap: 1.25 }}>
              {rows.map((row) => {
                const issue = createRowIssues.get(row.id);
                const showNameError = Boolean(issue?.name && (row.nameTouched || submitAttempted));
                return (
                  <AiaBox
                    key={row.id}
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "minmax(140px, 1.1fr) 150px minmax(160px, 1.2fr) minmax(140px, 1fr)",
                      columnGap: 1,
                      alignItems: "flex-start",
                    }}
                  >
                    <AiaBox>
                      <AiaInput
                        fullWidth
                        value={row.attributeName}
                        onChange={(value) =>
                          updateRow(row.id, {
                            attributeName: value.replace(/[^A-Za-z0-9_]/g, ""),
                          })
                        }
                        onKeyDown={(event) => {
                          if (event.key === " ") {
                            event.preventDefault();
                          }
                        }}
                        inputProps={{
                          onBlur: () => updateRow(row.id, { nameTouched: true }),
                        }}
                        placeholder="e.g. CUSTOMER_ID"
                        sx={showNameError ? compactErrorSx : compactInputSx}
                      />
                      {showNameError ? <AiaText sx={cellHintSx}>{issue?.name}</AiaText> : null}
                    </AiaBox>
                    <AiaSelect
                      fullWidth
                      size="small"
                      value={row.attributeType}
                      options={[...ATTRIBUTE_TYPE_OPTIONS]}
                      placeholder="Type"
                      onChange={(value) =>
                        updateRow(row.id, { attributeType: value as AttributeType })
                      }
                    />
                    <AiaBox>
                      <AiaInput
                        fullWidth
                        value={row.attributeValue}
                        onChange={(value) => updateRow(row.id, { attributeValue: value })}
                        placeholder="Value"
                        sx={compactInputSx}
                      />
                      {issue?.warning ? (
                        <AiaText sx={{ ...cellHintSx, color: "#B45309" }}>{issue.warning}</AiaText>
                      ) : null}
                    </AiaBox>
                    <AiaInput fullWidth value={projectName} disabled sx={compactInputSx} />
                  </AiaBox>
                );
              })}
            </AiaBox>
            {rows.some((row) => isRowStarted(row) && !isRowComplete(row)) ? (
              <AiaText sx={{ ...fieldHintSx, mt: 1.25 }}>
                Complete or clear every started row before adding.
              </AiaText>
            ) : null}
            <AiaButton
              variant="text"
              startIcon={<AddRoundedIcon sx={{ fontSize: 18 }} />}
              onClick={() => {
                setRows((current) => [...current, emptyDraftRow()]);
              }}
              sx={{
                mt: 1.5,
                px: 0.5,
                minWidth: 0,
                textTransform: "none",
                fontSize: 13,
                fontWeight: 600,
                color: "#374151",
              }}
            >
              Add row
            </AiaButton>
          </AiaBox>
        )}

        {submitError ? (
          <AiaText sx={{ ...fieldErrorSx, px: 2.5, pt: 0.5 }}>{submitError}</AiaText>
        ) : null}
        <AiaBox
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 1.25,
            px: 2.5,
            py: 2,
            borderTop: "1px solid #F1F5F9",
            bgcolor: "#FAFBFC",
            flexShrink: 0,
          }}
        >
          <AiaButton
            variant="outlined"
            onClick={handleClose}
            sx={{
              minWidth: 96,
              height: 38,
              borderRadius: "10px",
              borderColor: "#E5E7EB",
              color: "#374151",
              fontSize: 13,
              fontWeight: 600,
              textTransform: "none",
              "&:hover": {
                borderColor: "#D1D5DB",
                bgcolor: "#F9FAFB",
              },
            }}
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            disabled={!canSubmit || isSubmitting}
            onClick={() => {
              void handleSubmit();
            }}
            sx={{
              minWidth: 96,
              height: 38,
              borderRadius: "10px",
              textTransform: "none",
              fontSize: 13,
              fontWeight: 600,
              boxShadow: "none",
              bgcolor: canSubmit && !isSubmitting ? "#111827" : "#E5E7EB",
              color: canSubmit && !isSubmitting ? "#FFFFFF" : "#94A3B8",
              border: canSubmit && !isSubmitting ? "1px solid #111827" : "1px solid #E5E7EB",
              "&:hover": {
                bgcolor: canSubmit && !isSubmitting ? "#1F2937" : "#E5E7EB",
                boxShadow: "none",
              },
            }}
          >
            {submitLabel}
          </AiaButton>
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
