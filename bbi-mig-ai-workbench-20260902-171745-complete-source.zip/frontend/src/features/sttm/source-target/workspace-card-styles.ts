/** Background of a selected workspace card; text flips to white on top of it. */
export const WORKSPACE_CARD_SELECTED_BG = "#2d2d2d";
export const WORKSPACE_CARD_SELECTED_TEXT = "#ffffff";

/** Shared by source, target, and CTE cards so all three read as one control. */
export function workspaceCardSx(isSelected: boolean) {
  return {
    display: "flex",
    alignItems: "center",
    width: "100%",
    minWidth: 0,
    maxWidth: "100%",
    boxSizing: "border-box",
    px: 1.25,
    py: 0.6,
    mb: 0.5,
    gap: 1,
    cursor: "pointer",
    borderRadius: "10px",
    borderColor: isSelected ? WORKSPACE_CARD_SELECTED_BG : "#e5e7eb",
    backgroundColor: isSelected
      ? WORKSPACE_CARD_SELECTED_BG
      : "var(--color-surface, #ffffff)",
    color: isSelected ? WORKSPACE_CARD_SELECTED_TEXT : "#111827",
    transition: "120ms ease",
    boxShadow: "none",
    "&:last-child": {
      mb: 0,
    },
    "&:hover": {
      borderColor: isSelected ? WORKSPACE_CARD_SELECTED_BG : "#d1d5db",
      backgroundColor: isSelected ? WORKSPACE_CARD_SELECTED_BG : "#f1f5f9",
      boxShadow: "none",
    },
  } as const;
}
