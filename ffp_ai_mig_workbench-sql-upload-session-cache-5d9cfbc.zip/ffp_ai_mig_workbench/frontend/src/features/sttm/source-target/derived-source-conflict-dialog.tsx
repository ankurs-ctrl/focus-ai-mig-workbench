'use client';

import { AiaBox, AiaButton, AiaIconButton } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { CloseOutlinedIcon } from '@/utils/icons';
import { textStyleCssVars } from '@/config/typography-tokens';

export type DerivedSourceNameConflict = {
  existingId: string;
  existingName: string;
  existingVersion: number;
  suggestedName: string;
};

type DerivedSourceConflictDialogProps = {
  conflict: DerivedSourceNameConflict | null;
  busy?: boolean;
  onClose: () => void;
  onSaveAsNewVersion: () => void;
  onOverwrite: () => void;
};

/** Asked when a derived source with the same name already exists in the project. */
export function DerivedSourceConflictDialog({
  conflict,
  busy = false,
  onClose,
  onSaveAsNewVersion,
  onOverwrite,
}: DerivedSourceConflictDialogProps) {
  if (!conflict) {
    return null;
  }
  const title = 'Derived source already exists';

  return (
    <AiaBox
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={busy ? undefined : onClose}
      sx={{
        position: 'fixed',
        inset: 0,
        zIndex: 1400,
        px: 2,
        py: 4,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(15, 23, 42, 0.42)',
        backdropFilter: 'blur(4px)',
      }}
    >
      <AiaBox
        onClick={(event) => event.stopPropagation()}
        sx={{
          width: '100%',
          maxWidth: 500,
          borderRadius: '16px',
          border: '1px solid rgba(15, 23, 42, 0.08)',
          boxShadow: '0 30px 60px rgba(15, 23, 42, 0.18)',
          overflow: 'hidden',
          backgroundColor: '#FFFFFF',
        }}
      >
        <AiaBox
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: 1.5,
            px: 2.5,
            py: 2,
            borderBottom: '1px solid #EEF2F7',
          }}
        >
          <AiaText sx={{ ...textStyleCssVars('cardTitle'), letterSpacing: '-0.01em' }}>{title}</AiaText>
          <AiaIconButton
            onClick={onClose}
            disabled={busy}
            aria-label="Close"
            sx={{
              width: 32,
              height: 32,
              border: '1px solid #E2E8F0',
              color: '#64748B',
              bgcolor: '#FFFFFF',
              '&:hover': { bgcolor: '#F8FAFC' },
            }}
          >
            <CloseOutlinedIcon sx={{ fontSize: 18 }} />
          </AiaIconButton>
        </AiaBox>

        <AiaBox sx={{ px: 2.5, py: 2.25 }}>
          <AiaText sx={{ fontSize: 14, color: '#334155', lineHeight: 1.6 }}>
            <AiaText component="span" sx={{ fontWeight: 700, color: '#0f172a' }}>
              {conflict.existingName}
            </AiaText>{' '}
            (version {conflict.existingVersion}) already exists in this project with different SQL.
          </AiaText>
          <AiaText sx={{ mt: 1, fontSize: 13, color: '#64748B', lineHeight: 1.55 }}>
            Save as <b>{conflict.suggestedName}</b> to keep both, or overwrite the existing derived
            source. Mappings that use it will pick up the new SQL.
          </AiaText>
        </AiaBox>

        <AiaBox
          sx={{
            px: 2.5,
            py: 2,
            borderTop: '1px solid #EEF2F7',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            gap: 1.25,
          }}
        >
          <AiaButton
            variant="outlined"
            onClick={onClose}
            disabled={busy}
            sx={{ minWidth: 88, height: 38, borderRadius: '10px', borderColor: '#dbe2ea', color: '#334155', fontSize: 14, fontWeight: 600, textTransform: 'none' }}
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="outlined"
            onClick={onOverwrite}
            disabled={busy}
            sx={{ minWidth: 110, height: 38, borderRadius: '10px', fontSize: 14, fontWeight: 600, textTransform: 'none' }}
          >
            Overwrite
          </AiaButton>
          <AiaButton
            variant="contained"
            color="primary"
            onClick={onSaveAsNewVersion}
            disabled={busy}
            autoFocus
            sx={{ minWidth: 150, height: 38, borderRadius: '10px', fontSize: 14, fontWeight: 700, textTransform: 'none' }}
          >
            Save as new version
          </AiaButton>
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
