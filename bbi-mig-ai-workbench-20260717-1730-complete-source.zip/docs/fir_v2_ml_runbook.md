# FIR V2 ML Runbook

This project now includes a real Snowflake-native FIR training and scoring path.

## What It Does

The training stack:

- backfills FIR feature snapshots from existing signal / feedback history when needed
- registers a Snowflake Feature Store entity and feature view
- trains logistic-regression baseline models for:
  - feedback-needed prediction
  - recommendation-helpfulness prediction
  - recommendation-type prediction
- logs those models into Snowflake Model Registry
- scores live FIR contexts and writes the latest predictions into:
  - `TBL_WORKBENCH_FIR_MODEL_SCORES`

The application reads those scores during FIR feature snapshot construction and uses them to steer live recommendation / feedback selection.

## Script

The main script is:

`scripts/train_and_score_fir_v2.py`

It reads Snowflake credentials from:

`services/sttm-builder/.env.local`

## Local Run

From the repo root:

```bash
./venv/bin/python scripts/train_and_score_fir_v2.py --env-file services/sttm-builder/.env.local
```

## Windows PowerShell Run

From the repo root:

```powershell
.\venv\Scripts\python.exe .\scripts\train_and_score_fir_v2.py --env-file .\services\sttm-builder\.env.local
```

## Suggested Cadence

For now, run the training/scoring script:

- after new client feedback is imported
- after major mapping sessions
- nightly as a scheduled job for active client environments

## Current Baseline Scope

This is a structured-feature baseline, not the final model stack.

Current model outputs:

- `feedback_needed_probability`
- `recommendation_helpfulness_probability`
- `recommendation_type`
- `recommendation_priority`

## Expected Next Evolution

- increase the volume of FIR events and feature snapshots
- replace or augment logistic regression with gradient-boosted models
- promote more mapping-intent and semantic-learning features into the feature view
- run the training script on a schedule in the client environment
