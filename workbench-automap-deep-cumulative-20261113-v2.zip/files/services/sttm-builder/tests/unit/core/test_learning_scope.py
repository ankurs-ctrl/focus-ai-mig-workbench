import json

from app.core.config import Settings
from app.core.learning_scope import (
    canonical_column,
    canonical_target,
    derive_scope,
    infer_target_from_columns,
    scope_rank,
    target_role,
    vendor_family,
)
from app.core.target_mapping_patterns import TargetMappingPatternService
from app.schema.fir_patterns import TargetMappingPatternV2

TMD_SOURCES = [
    "FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS",
    "FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACT_STATUSES",
    "FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACT_FAMILIES",
    "FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.ACTIVITY_CODES",
]


def test_old_and_fixed_target_names_resolve_to_one_canonical_target():
    assert canonical_target("FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_TARGET.EVERNEST_HH_SF_IMPORT") == (
        "FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD")
    assert canonical_target("OTHER_DB.X.BIZ_ACCOUNTS") == "FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.BIZ_ACCOUNTS"
    # A client's own target table is not claimed for the fixed schema.
    assert canonical_target("CLIENT.CRM.CUSTOMER") is None


def test_target_roles():
    assert target_role("EVERNEST_HH_SF_IMPORT") == "household_account"
    assert target_role("BIZ_CONTACTS") == "business_contact"
    assert target_role("BIZ_ACCOUNTS") == "business_account"
    assert target_role("PERSONACCOUNT") == "person_account"
    assert target_role("CALLS") == "call_activity"


def test_columns_map_to_fixed_target_columns_and_tables():
    assert canonical_column("xxOGStateCode", ["OGSTATECODE", "NAME"]) == "OGSTATECODE"
    contracts = {
        "HOUSEHOLD": ["LEGACY_ID__C", "HOUSEHOLD_TYPE__C", "FINSERV__STATUS__C", "BILLINGCITY", "NAME"],
        "BIZ_ACCOUNTS": ["LEGACY_ID__C", "TYPE", "PHONE", "BILLINGCITY", "NAME", "OGCOMPANYSTATE"],
    }
    table, share = infer_target_from_columns(["Legacy_ID__c", "Phone", "Type", "XXogCOMPANYState"], contracts)
    assert table == "BIZ_ACCOUNTS" and share == 1.0
    # Too close to call -> no guess.
    assert infer_target_from_columns(["Legacy_ID__c", "Name"], contracts)[0] is None


def test_vendor_from_table_fingerprint_and_firm_aliases():
    assert vendor_family(TMD_SOURCES) == "REDTAIL"
    assert vendor_family([], declared="EVERNEST") == "REDTAIL"
    assert vendor_family(["RAW.HUBSPOT.CONTACT"]) is None


def test_scope_from_recipe_and_precedence():
    assert derive_scope({"source_dependencies": ["A.B.C"]}) == "source_system"
    assert derive_scope({"placeholder": "$HHRecordType"}) == "target_standard"
    assert derive_scope({}, has_project_literal=True) == "project"
    ranks = [scope_rank("project", same_project=True, same_vendor=False),
             scope_rank("source_system", same_project=False, same_vendor=True),
             scope_rank("target_standard", same_project=False, same_vendor=False),
             scope_rank("source_system", same_project=False, same_vendor=False)]
    assert ranks == sorted(ranks)


class _Session:
    def __init__(self, patterns):
        self.patterns = patterns
        self.statements = []

    def sql(self, statement):
        self.statements.append(statement)
        rows = []
        if "SELECT PATTERN_PAYLOAD" in statement:
            rows = [type("R", (), {"as_dict": lambda self, p=p: {
                "PATTERN_PAYLOAD": json.dumps(p.model_dump(mode="json"), default=str),
                "SUPPORT_COUNT": 1, "CONTRADICTION_COUNT": 0,
                "VALIDATION_STATUS": p.validation_status, "CONFIDENCE": p.confidence}})() for p in self.patterns]
        return type("Q", (), {"collect": lambda self, rows=rows: rows})()


def _pattern(pattern_id, *, scope, column, project_id="4", sources=None):
    return TargetMappingPatternV2(
        pattern_id=pattern_id, scope=scope, project_id=project_id,
        target_contract={"target_fqn": "FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD", "target_column": column,
                         "target_role": "household_account"},
        source_system_profile={"vendor_family": "REDTAIL", "source_tables": sources or []},
        source_compatibility_signature="s", mapping_recipe={"mode": "direct"},
        validation_status="published", confidence=0.9, content_hash=pattern_id,
    )


def test_retrieval_matches_role_and_normalized_columns_and_ranks_by_scope():
    session = _Session([
        _pattern("std", scope="target_standard", column="xxOGStateCode"),
        _pattern("own", scope="project", column="OGSTATECODE", project_id="1902"),
    ])
    service = TargetMappingPatternService(session, Settings())
    candidates = service.retrieve_candidates(
        target_table="FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET.HOUSEHOLD", target_columns=["OGSTATECODE"],
        source_tables=TMD_SOURCES, project_id="1902", canonical_target_scope=True,
    )
    statement = next(s for s in session.statements if "SELECT PATTERN_PAYLOAD" in s)
    assert "target_role::STRING = 'household_account'" in statement
    assert "SPLIT_PART(TARGET_TABLE" not in statement
    assert "SCOPE <> 'project' OR PROJECT_ID = '1902'" in statement
    assert "'OGSTATECODE'" in statement
    assert [c.pattern.pattern_id for c in candidates] == ["own", "std"]
    assert candidates[1].pattern.target_contract["target_column"] == "OGSTATECODE"
    assert candidates[1].pattern.target_contract["learned_target_column"] == "xxOGStateCode"
