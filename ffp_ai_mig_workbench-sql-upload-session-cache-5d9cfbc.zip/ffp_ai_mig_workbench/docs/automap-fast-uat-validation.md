# Deterministic-first Auto-map UAT canary

## Scope

The direct-mapping fast path requires `AUTOMAP_FAST_PATH_V1=true`, exact membership
in `AUTOMAP_FAST_PROJECT_IDS`, and an explicit resolution mode. The UAT profile
enables only project `501`, revision `uat-fast-501-v1`. Other projects retain the
legacy route. Shared archive batching and frontend correctness fixes also apply
outside the canary.

Preserve-and-complete keeps authored SQL and row definitions separate from new
mapping proposals. Definitions are not business approval or execution readiness.
Unbound project Values remain blocked. Whole-table admission is non-exhaustive;
omitted tables are not evidence of no match. All new fast-path model calls use the
existing four-slot durable pool and existing `AGT_SOURCE_MAPPING` without changing
its specification. Unknown remote outcomes are not automatically retried or freed.

## Verification before publication, 2026-10-29

- Integrated backend: 3,409 passed, one Windows-only POSIX-mode skip, three existing
  Pydantic field-shadowing warnings. Includes native-probe offline tests.
- Both platform-sensitive suites: six passed in an isolated Linux container with
  networking disabled and source mounted read-only. The POSIX security assertion
  is unchanged on Linux; the SQL fixture is unchanged on disk.
- All frontend `scripts/test-*.cjs` harnesses passed, including 29 preservation and
  13 scroll tests. TypeScript and the Next.js production build passed.
- Independent review reproduced two model-wire hash issues and two preservation
  issues. Regression tests now cover the real HTTP serialization boundary,
  governed samples, prior artifacts, unfinished rules, and partial/terminal replay.
- Reconstructed Ft. Pitt fixture: 35 authored definitions preserved, zero model
  calls; unresolved Values still block execution. This is not a real saved-request
  or deployed browser acceptance result.
- Offline archive comparison: 5,657 to 20 SQL calls and 512 to one transaction,
  with identical 223 blobs and reducer output. This is not measured live latency.
- Live UAT SQL compatibility: bulk insert/read returned two inserted and two
  validated diagnostic records; rollback left zero records. No business data was
  written. This does not verify the Snowpark client binding or commit path.
- The local named-connection archive probe could not finish interactive SSO and
  issued no SQL. Do not treat it as a successful native Python integration test.

## Deployment and acceptance gates

Use the existing GitHub `UAT` workflow and protected deployment scripts. Do not
include the initial-infrastructure rollout marker. Recheck current jobs and all
four permits before restarting services; an expired lease alone does not prove
remote work completed. Verify every web container and all five worker replicas
against the new image, not merely the CI conclusion.

In project 501, test a fresh upload, reopened/compiled draft, and a separate
blank mapping requiring genuine inference. Do not publish mappings or load target
data. Measure click-to-committed-result wall time; record preserved/new/proposed/
unresolved counts separately. Test upward assistant scrolling and late user edits.
Keep prior mappings unchanged. Provider latency, live transport compatibility,
and the 120-180-second goal remain acceptance gates, not claims made by this file.

The optional `scripts/validate_automap_uat_native.py` defaults to dry run. Its
`--execute` modes intentionally persist isolated diagnostic archive records;
fast-one-call also creates one thread and uses the existing admission inventory.
It performs no business writes, resets, grants, or agent changes. Review safe
failure output and pool state before any retry.

## Live acceptance follow-up, 2026-10-30

Initial deployed canary `8f67a69` did not pass functional acceptance:

- New upload mapping `2702`, job `4f5906bb-dc85-5bde-8031-6727d3ba8c36`:
  66.712 seconds click-to-return, 27 requested definitions preserved internally,
  10 unbound catalog targets, zero agent calls. A singleton packet overflow
  incorrectly failed the whole job. The actual catalog has 600 ACCOUNTS columns;
  the earlier offline fixture had only 24. The 35 uploaded projections are not
  the same set as the 37 catalog targets. Original visible row inputs survived.
- Manual country-code mapping `2803`, job `d2e181ad-eff8-5968-8b44-9ec1d877b7df`:
  108.244 seconds click-to-return, 37 unresolved, zero agent calls. Parent Search
  counters (74 queries across 37 targets) were replayed against child-batch limits
  (30 or 27). Read-only source validation was used; no target writes or publication.

Follow-up changes preserve valid definitions through per-target preflight rejection,
retain blocked targets as explicitly unresolved without worker receipts, enforce
deadline checks between projections, select encodings satisfying both size limits,
and replay parent Search accounting at its original scope. Large diagnostic-only
ID lists remain in the immutable handoff rather than each model-facing receipt.
Required evidence, whole tables, hashes, and admission safeguards remain intact.

Final follow-up offline backend suite: 3,656 passed, one platform skip. Independent
reviews passed the new preflight and shared-discovery regressions. The full
600-column packet fit and post-fix live inference remain unverified until rerun.

### Results on `cc41995` and response-diagnostics follow-up

- Uploaded mapping `2702`, job `a840f858-56d7-562d-a19a-e86b24df20c9`:
  118.166 seconds click-to-return. Exact browser comparison found the full SQL
  and all 45 row objects unchanged. Backend reported 27 definitions preserved,
  zero newly mapped, and ten pending targets blocked by mandatory context size.
  All 37 requested targets need input, including preserved definitions with
  unresolved Values. This verifies preservation, not completion of missing mappings.
- Country mapping `2803`, job `b3c464c6-f8c5-5487-bae6-af08149bcb33`:
  124.823 seconds click-to-return; four model attempts. Two returned structured
  unresolved results but plain-string warnings caused batch validation failure.
  Two raised strict terminal-response errors whose precise causes were not logged.
  All four permits returned to FREE; no accepted mappings. Four requests and two
  model responses were durably archived. Failed runtime is not successful SLO evidence.
- The follow-up normalizes ancillary warnings without relaxing candidate validation,
  records typed, privacy-safe response-shape diagnostics, and archives failures after
  admission completion. Unknown calls remain quarantined and cannot be blindly retried.
  Failed-call model timing and trusted diagnostics reach the job response metadata.
- Follow-up regression selection: 3,621 passed, one platform skip. Independent
  review passed 49 focused tests. This selection differs from the earlier 3,656-test
  run; counts are not a before/after quality comparison.
- Live assistant summary scrolling stayed at the top for 12.45 seconds; Jump to
  latest returned to the bottom. Streaming-specific behavior remains harness-tested.

## Rollback and limits

Disable the fast flag through the UAT profile and redeploy only after checking
in-flight work. Frozen fast jobs reject disabled configuration rather than
silently switching protocols. Do not reset occupied permits or delete recovery
records. Preserve original requests and validated committed results.

Deferred: fair scheduling across all callers, automatic recovery of ambiguous
dispatch crash gaps, hard cancellation of blocking I/O, internal-table picker
classification, retention policy, and a representative 20-run median/p95 study.
No new stored procedure, external orchestration framework, broad grant, compute
pool resize, or recovery-table deletion is part of this release.