"""Where a learning applies: canonical target, target role, source system, scope.

The target schema is fixed and shared (one set of CRM import tables) while
every client brings a different source schema. Learnings therefore key on
the canonical target column and carry one of three scopes:

* ``project``          - firm values, firm-specific overrides, user choices
                         for one project; only that project sees them.
* ``source_system``    - how a source system (e.g. Redtail) feeds the target:
                         segmentation, code values, joins; any project whose
                         source matches the same system sees them.
* ``target_standard``  - how the target is always filled regardless of source:
                         record types, owner fallback, legacy-id and phone
                         formats; every project sees them.

``client`` is the pre-scope value and is treated like ``source_system``.
"""
from __future__ import annotations

import json
import re
from typing import Any, Iterable

SCOPE_PROJECT = "project"
SCOPE_SOURCE_SYSTEM = "source_system"
SCOPE_TARGET_STANDARD = "target_standard"
SCOPE_LEGACY = "client"
SHARED_SCOPES = (SCOPE_SOURCE_SYSTEM, SCOPE_TARGET_STANDARD, SCOPE_LEGACY)

DEFAULT_CANONICAL_SCHEMA = "FFP_HDP_DLAB_DB_DEV.AIA_WB_TARGET"
DEFAULT_CANONICAL_TABLES = (
    "AGREEMENTS", "ALERTS", "BIZ_ACCOUNTS", "BIZ_CONTACTS", "CALLS",
    "HOUSEHOLD", "MEETINGS", "NOTES", "PERSONACCOUNT", "TASKS",
)
DEFAULT_TARGET_ALIASES = {
    "EVERNEST_HH_SF_IMPORT": "HOUSEHOLD",
    "EVERNEST_AGREEMENTS_TARGET": "AGREEMENTS",
}
DEFAULT_SOURCE_FINGERPRINTS = {
    "REDTAIL": [
        "CONTACTS", "CONTACT_FAMILIES", "CONTACT_FAMILY_MEMBERS", "CONTACT_STATUSES",
        "ACTIVITY_CODES", "ACTIVITIES_CONTACTS", "NOTE_ASSOCIATIONS", "WRITING_ADVISORS",
        "SERVICING_ADVISORS", "CONTACT_UDFS",
    ],
}
# Name markers for systems that are recognised by schema or table naming.
_VENDOR_MARKERS = {
    "REDTAIL": ("REDTAIL",),
    "SALESFORCE": ("SALESFORCE", "SFDC"),
    "WEALTHBOX": ("WEALTHBOX",),
    "ADDEPAR": ("ADDEPAR",),
    "ORION": ("ORION",),
    "TAMARAC": ("TAMARAC",),
}
# Firm names that earlier imports recorded as the vendor; they ran on Redtail.
_FIRM_VENDOR_ALIASES = {"EVERNEST": "REDTAIL", "TMD": "REDTAIL"}

_ROLE_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("business_contact", ("BIZ_CONTACT", "BUSINESS_CONTACT")),
    ("business_account", ("BIZ_ACCOUNT", "BUSINESS_ACCOUNT", "BUSINESS")),
    ("person_account", ("PERSONACCOUNT", "PERSON_ACCOUNT", "PERSON")),
    ("household_account", ("HOUSEHOLD", "_HH_", "HH_")),
    ("call_activity", ("CALL",)),
    ("task_activity", ("TASK",)),
    ("meeting_activity", ("MEETING", "EVENT")),
    ("note", ("NOTE",)),
    ("agreement", ("AGREEMENT",)),
    ("alert", ("ALERT",)),
)


def _json_setting(settings: Any, name: str, default: Any) -> Any:
    raw = getattr(settings, name, None) if settings is not None else None
    if raw in (None, ""):
        return default
    if isinstance(raw, (dict, list)):
        return raw
    try:
        return json.loads(str(raw))
    except (TypeError, ValueError):
        return default


def canonical_schema(settings: Any = None) -> str:
    value = str(getattr(settings, "migration_canonical_target_schema", "") or "").strip() if settings else ""
    return (value or DEFAULT_CANONICAL_SCHEMA).upper()


def canonical_tables(settings: Any = None) -> set[str]:
    raw = str(getattr(settings, "migration_canonical_target_tables", "") or "").strip() if settings else ""
    names = [item for item in re.split(r"[\s,]+", raw) if item] or list(DEFAULT_CANONICAL_TABLES)
    return {item.upper() for item in names}


def target_aliases(settings: Any = None) -> dict[str, str]:
    aliases = _json_setting(settings, "migration_target_aliases_json", DEFAULT_TARGET_ALIASES)
    return {str(k).upper(): str(v).upper() for k, v in (aliases or {}).items()}


def source_fingerprints(settings: Any = None) -> dict[str, list[str]]:
    value = _json_setting(settings, "migration_source_system_fingerprints_json", DEFAULT_SOURCE_FINGERPRINTS)
    return {str(k).upper(): [str(t).upper() for t in v or []] for k, v in (value or {}).items()}


def _leaf(name: str) -> str:
    return str(name or "").strip().strip('"').split(".")[-1].strip('"').upper()


def canonical_target(table: str | None, settings: Any = None, *, known_tables: Iterable[str] | None = None) -> str | None:
    """The fixed-schema FQN for ``table`` (itself, an alias, or a same-named fixed table), else None."""
    if not table:
        return None
    schema = canonical_schema(settings)
    text = str(table).strip().upper().replace('"', "")
    if text.startswith(schema + "."):
        return text
    leaf = _leaf(text)
    leaf = target_aliases(settings).get(leaf, leaf)
    known = {_leaf(item) for item in known_tables} if known_tables is not None else canonical_tables(settings)
    if not leaf or leaf not in known:
        return None
    return f"{schema}.{leaf}"


def target_role(table: str | None) -> str | None:
    """Business role of a target table from its (canonical or alias) name."""
    leaf = _leaf(table or "")
    if not leaf:
        return None
    padded = f"_{leaf}_"
    for role, markers in _ROLE_RULES:
        if any(marker in padded or marker in leaf for marker in markers):
            return role
    return None


def _column_key(name: str) -> str:
    key = re.sub(r"[^A-Z0-9]", "", str(name or "").upper())
    stripped = key.lstrip("X")
    return stripped if len(key) - len(stripped) >= 2 and len(stripped) >= 3 else key


def canonical_column(column: str, target_columns: Iterable[str]) -> str | None:
    """The target column ``column`` names, ignoring case, separators and ``XX`` prefixes."""
    wanted = _column_key(column)
    for candidate in target_columns:
        if _column_key(candidate) == wanted:
            return str(candidate).upper()
    return None


def infer_target_from_columns(
    columns: Iterable[str], contracts: dict[str, Iterable[str]], *, min_share: float = 0.6,
) -> tuple[str | None, float]:
    """The target whose columns best cover ``columns`` (share of columns that exist in it)."""
    keys = {_column_key(item) for item in columns if item}
    if not keys:
        return None, 0.0
    best, best_share, runner_up = None, 0.0, 0.0
    for table, table_columns in contracts.items():
        table_keys = {_column_key(item) for item in table_columns}
        share = len(keys & table_keys) / len(keys)
        if share > best_share:
            best, runner_up, best_share = table, best_share, share
        elif share > runner_up:
            runner_up = share
    if best is None or best_share < min_share or best_share - runner_up < 0.1:
        return None, best_share
    return best, round(best_share, 4)


def vendor_family(source_tables: Iterable[str], settings: Any = None, *, declared: str | None = None) -> str | None:
    """Source system of a source table set: declared, then table fingerprint, then name markers."""
    tables = [str(item).upper() for item in source_tables or [] if item]
    if declared:
        value = str(declared).strip().upper()
        value = _FIRM_VENDOR_ALIASES.get(value, value)
        if value:
            return value
    leaves = {_leaf(item) for item in tables}
    best, best_hits = None, 0
    for family, fingerprint in source_fingerprints(settings).items():
        hits = len(leaves & set(fingerprint))
        if hits >= min(3, len(fingerprint)) and hits > best_hits:
            best, best_hits = family, hits
    if best:
        return best
    joined = " ".join(tables)
    for family, markers in _VENDOR_MARKERS.items():
        if any(marker in joined for marker in markers):
            return family
    for firm, family in _FIRM_VENDOR_ALIASES.items():
        if firm in joined:
            return family
    return None


def source_schemas(source_tables: Iterable[str]) -> list[str]:
    """``DATABASE.SCHEMA`` of each fully qualified source table."""
    schemas = set()
    for item in source_tables or []:
        parts = str(item).upper().replace('"', "").split(".")
        if len(parts) >= 3:
            schemas.add(".".join(parts[-3:-1]))
    return sorted(schemas)


def derive_scope(recipe: dict[str, Any], *, evidence_class: str | None = None, has_project_literal: bool = False) -> str:
    """Scope a column recipe earns from what it depends on."""
    if has_project_literal or evidence_class == "explicit_user_correction":
        return SCOPE_PROJECT
    if recipe.get("source_dependencies") or recipe.get("logical_source_dependencies"):
        return SCOPE_SOURCE_SYSTEM
    return SCOPE_TARGET_STANDARD


def scope_rank(scope: str | None, *, same_project: bool, same_vendor: bool) -> int:
    """Lower is preferred: this project's choices, then this source system, then target standards."""
    value = str(scope or SCOPE_LEGACY)
    if value == SCOPE_PROJECT:
        return 0 if same_project else 9
    if value in (SCOPE_SOURCE_SYSTEM, SCOPE_LEGACY):
        return 1 if same_vendor else 3
    if value == SCOPE_TARGET_STANDARD:
        return 2
    return 4
