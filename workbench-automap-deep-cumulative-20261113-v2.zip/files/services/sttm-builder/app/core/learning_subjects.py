from __future__ import annotations

import re
from enum import Enum


class LearningSubjectType(str, Enum):
    PROJECT = "project"
    MAPPING = "mapping"
    TARGET_TABLE = "target_table"
    TARGET_COLUMN = "target_column"
    MAPPING_ROW = "mapping_row"
    SOURCE_TABLE = "source_table"
    SOURCE_COLUMN = "source_column"
    RELATIONSHIP = "relationship"
    DERIVED_SOURCE = "derived_source"
    TRANSFORMATION = "transformation"
    QUERY_RULE = "query_rule"
    VALIDATION_ARTIFACT = "validation_artifact"


def normalize_identifier(value: str) -> str:
    return ".".join(part.strip().strip('"').upper() for part in value.split(".") if part.strip())


def target_column_subject(target_table: str, target_column: str) -> str:
    table = normalize_identifier(target_table)
    column = normalize_identifier(target_column)
    if not table or "." not in table:
        raise ValueError("A schema-qualified target table is required for target-column learning")
    if not column or "." in column:
        raise ValueError("A terminal target column name is required")
    return f"target_column:{table}.{column}"


def mapping_row_subject(sttm_id: str, target_table: str, target_column: str) -> str:
    return f"mapping_row:{sttm_id}:{target_column_subject(target_table, target_column).removeprefix('target_column:')}"


def relationship_subject(left_fqn: str, right_fqn: str, condition_hash: str) -> str:
    return f"relationship:{normalize_identifier(left_fqn)}->{normalize_identifier(right_fqn)}:{condition_hash.lower()}"


def normalized_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
