-- EverNest Households reference migration
-- Reconstructed from the supplied Snowflake screenshots for Workbench testing.
-- Update the client-specific variables in the first section before running.

/* ============================================================================
   Variables to update for each new firm
   ============================================================================ */
SET MigrationDataSchema   = 'SCH_REDTAIL_EVERNEST_06_23_2026';
SET MigrationMasterSchema = 'SCH_REDTAIL_EVERNEST_MASTER';

SET ClientStartDate   = '2026-01-01';
SET LegacyHHcPrefix   = 'EVR_RT_';
SET LegacyContactPrefix = 'EVR_RT_';
SET Referral           = '';
SET BackupOwnerID      = '005G000000ZBGIIAX';
SET TransactionFirmID  = '001G000001PL0000cYyVIYAU';
SET ParentOfficeID     = '001G000001K9yCDTAZ';

/* Core variables generally remain unchanged. */
SET CoreMigrationDatabase = 'FFP_HDP_CRM_MIG_DB_DEV';
SET OrionHHIDPrefix       = 'Household-1525-';
SET OrionIndividualIDPrefix = 'Person-1525-';
SET HHRecordType           = '01241000001IBjjAAO';
SET BizAcctRecordType      = '01241000001IBjjAAG';
SET IndvAcctRecordType     = '01241000001IBjjAAG';
SET IndvContactRecordType  = '01241000001IBj0AAG';
SET BizContactRecordType   = '01241000001IBj1AAG';
SET HHBaseClientCategory   = 'Wealth Management Client';
SET TaskRecordTypeID       = '01241000001IBk4AAG';
SET NoteTaskRecordTypeID   = '01241000001IBk4AAG';
SET EventTaskRecordTypeID  = '01241000001IBk4AAG';

USE DATABASE IDENTIFIER($CoreMigrationDatabase);
USE SCHEMA IDENTIFIER($MigrationDataSchema);

/* Resolve master tables through Snowflake session variables. */
SET UserMasterTable      = CONCAT($MigrationMasterSchema, '.MAPPER_USER');
SET ContactMasterTable   = CONCAT($MigrationMasterSchema, '.MAPPER_CONTACT_MASTER');
SET HHMasterTable        = CONCAT($MigrationMasterSchema, '.MAPPER_HH_MASTER');
SET OppMasterTable       = CONCAT($MigrationMasterSchema, '.MAPPER_OPPORTUNITY_MASTER');
SET ACRMasterTable       = CONCAT($MigrationMasterSchema, '.MAPPER_ACR_MASTER');
SET BizAcctMasterTable   = CONCAT($MigrationMasterSchema, '.MAPPER_BIZ_ACCOUNT');
SET LeadMasterTable      = CONCAT($MigrationMasterSchema, '.MAPPER_LEAD_MASTER');
SET ReferralMasterTable  = CONCAT($MigrationMasterSchema, '.MAPPER_REFERRAL_MASTER');

/* ============================================================================
   Source CTEs
   ============================================================================ */
WITH UserMaster AS (
    SELECT * FROM IDENTIFIER($UserMasterTable)
),
ContactMaster AS (
    SELECT * FROM IDENTIFIER($ContactMasterTable)
),
HHMaster AS (
    SELECT * FROM IDENTIFIER($HHMasterTable)
),
OppMaster AS (
    SELECT * FROM IDENTIFIER($OppMasterTable)
),
ACRMaster AS (
    SELECT * FROM IDENTIFIER($ACRMasterTable)
),
BizAcctMaster AS (
    SELECT * FROM IDENTIFIER($BizAcctMasterTable)
),
LeadMaster AS (
    SELECT * FROM IDENTIFIER($LeadMasterTable)
),
ReferralMaster AS (
    SELECT * FROM IDENTIFIER($ReferralMasterTable)
),

/* Primary billing address. */
BillingAddress AS (
    SELECT
        ad.addressable_id AS contact_id,
        COALESCE(ad.street_address, '') || COALESCE(CHR(10) || ad.secondary_address, '') AS billing_street,
        COALESCE(ad.city, '') AS billing_city,
        COALESCE(ad.state, '') AS billing_state,
        COALESCE(ad.zip, '') AS billing_postal_code,
        COALESCE(ad.country, '') AS billing_country
    FROM ADDRESSES ad
    WHERE ad.deleted = 0
      AND ad.is_primary = 1
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY ad.addressable_id ORDER BY ad.street_address
    ) = 1
),

FamilyHOH AS (
    SELECT
        cfm2.family_id,
        cfm2.contact_id AS hoh_contact_id,
        cs.name AS hoh_status
    FROM CONTACTS cfam
    JOIN CONTACT_FAMILY_MEMBERS cfm2
      ON cfm2.contact_id = cfam.id
    JOIN CONTACT_STATUSES cs
      ON cs.id = cfam.status_id
     AND COALESCE(cfm2.hoh, 0) = 1
     AND cfm2.deleted = 0
     AND cfam.deleted = 0
     AND cfm2.family_id NOT IN (2176, 2431)
),

PrefContactMethod AS (
    SELECT a.contact_id, a.field_value AS pref_contact_method
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 12
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),
Drinks AS (
    SELECT a.contact_id, a.field_value AS drinks
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 8
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),
PetName AS (
    SELECT a.contact_id, a.field_value AS pet_name
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 10
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),
ContactMadeAwareOfFocus AS (
    SELECT a.contact_id, a.field_value AS contact_made_aware_of_focus
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 13
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),
AllTaxIDsHaveClientContactRecord AS (
    SELECT a.contact_id, a.field_value AS all_tax_ids_have_client_contact_record
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 14
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),
SIGNEDAdvisoryAgreement AS (
    SELECT a.contact_id, a.field_value AS signed_advisory_agreement
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 15
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),
FocusLanguageInvestmentAgreement AS (
    SELECT a.contact_id, a.field_value AS focus_language_investment_agreement
    FROM CONTACT_UDFS a
    LEFT JOIN CONTACT_UDF_FIELDS b
      ON a.contact_udf_field_id = b.id
    WHERE b.id = 16
      AND a.deleted = 0
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY a.contact_id ORDER BY a.created_at
    ) = 1
),

SOURCE AS (
    SELECT DISTINCT
        'HH-' || TO_CHAR(c.id) AS legacy_hh_id,
        c.type,
        cfm.family_id,
        COALESCE(cfm.hoh, 0) AS hoh,
        COALESCE(mu.first_name || ' ' || mu.last_name, 'Niki Woodworth') AS owner_name,
        cs.id AS status_id,
        cs.name AS status,
        c.servicing_advisor_id AS ama,
        sa.name AS ama_name,
        COALESCE(c.writing_advisor_id, 2) AS pma,
        COALESCE(wa.name, 'Frank Esposito') AS pma_name,
        c.company_name,
        c.first_name,
        c.last_name,
        c.id AS contact_id,
        c.next_review_at,
        cc.name AS review_schedule,
        CASE
            WHEN cc.name = 'Client - 1 Meetings' THEN 'Annually'
            WHEN cc.name = 'Client - 3 Meetings' THEN 'Triannually'
            WHEN cc.name = 'Client - 2 Meetings' THEN 'Semiannually'
            WHEN cc.name = 'Client - 4 Meetings' THEN 'Quarterly'
            ELSE 'Only as Needed'
        END AS review_frequency,
        NULL AS legacy_portfolio_system_hhid,
        COALESCE(pcm.pref_contact_method, '') || CHR(10) ||
            COALESCE(dr.drinks, '') || CHR(10) ||
            COALESCE(pn.pet_name, '') || CHR(10) ||
            COALESCE(cmaf.contact_made_aware_of_focus, '') || CHR(10) ||
            COALESCE(saa.signed_advisory_agreement, '') || CHR(10) ||
            COALESCE(flia.focus_language_investment_agreement, '') AS legacy_firm_info,
        ba.billing_street,
        ba.billing_city,
        ba.billing_state,
        ba.billing_postal_code,
        ba.billing_country,
        c.salesforce_id AS referral_id,
        c.source_of_business AS source_of_business,
        c.legacy_hh_id AS legacy_crm_id,
        CASE
            WHEN cs.name = 'Client' AND c.type = 'Crm::Contact::Individual'
                THEN 'Client Relationship'
            WHEN cs.name = 'Client' AND c.type = 'Crm::Contact::Business'
                THEN 'Institutional Client'
            WHEN cs.name = 'Client' AND c.type = 'Crm::Contact::Trust'
                THEN 'Institutional Client'
            WHEN cs.name = 'Client' AND c.type = 'Crm::Contact::ContactAssociation'
                THEN 'Institutional Client'
            ELSE NULL
        END AS household_type,
        ba.billing_street AS billing_street_source,
        ba.billing_city AS billing_city_source,
        ba.billing_state AS billing_state_source,
        ba.billing_postal_code AS billing_postal_code_source,
        ba.billing_country AS billing_country_source,
        'No' AS is_rpc_client,
        CASE
            WHEN c.source_of_business = 'Client Referral' THEN 'Client Sourced'
            WHEN c.source_of_business = 'Networking' THEN 'Advisor Sourced'
            WHEN c.source_of_business = 'COI Referral' THEN 'COI - Firm Sourced'
            ELSE 'Advisor Sourced'
        END AS source_of_business_label,
        c.referred_by,
        c.first_name || ' ' || COALESCE(c.last_name, c.company_name, '') AS mail_merge_first_last,
        IFF(c.last_name IS NULL OR c.last_name = '', c.company_name, c.last_name) AS mail_merge_last_only,
        c.client_since,
        c.writing_advisor_id AS owner_id,
        wa.name AS owner_name_from_master,
        CASE
            WHEN c.id IN (444,619,702,1288,1290,1291,168,326,658,659,55,195,1636,2060,1639,1640,1844,2535,1853,1854)
                THEN 'Yes'
            WHEN c.id IN (679,1695,1247,1201,2018,1419,1331,2635,1554,2061,2037,2036,13,2853,2730,1657,2749,2854,1302,2728,1435,1668)
                THEN 'No'
            WHEN cfm.hoh = 1 THEN 'Yes'
            WHEN cfm.id IS NULL THEN 'Yes'
            WHEN cfm.hoh = 0 AND cfm.relationship = 1 AND hoh.hoh_status <> 'Deceased' THEN 'No'
            WHEN cfm.hoh = 0 AND cfm.relationship = 1 AND hoh.hoh_status = 'Deceased' THEN 'Yes'
            WHEN cfm.hoh = 0 AND cfm.relationship <> 1 AND DATEDIFF(year, c.dob, CURRENT_DATE()) >= 21 THEN 'Yes'
            ELSE 'No'
        END AS included_in_household
    FROM CONTACTS c
    LEFT JOIN CONTACT_STATUSES cs ON cs.id = c.status_id
    LEFT JOIN CONTACT_FAMILY_MEMBERS cfm ON cfm.contact_id = c.id AND cfm.deleted = 0
    LEFT JOIN CONTACT_FAMILIES cf ON cf.id = cfm.family_id AND cf.deleted = 0
    LEFT JOIN SERVICING_ADVISORS sa ON sa.id = c.servicing_advisor_id
    LEFT JOIN WRITING_ADVISORS wa ON wa.id = c.writing_advisor_id
    LEFT JOIN BillingAddress ba ON ba.contact_id = c.id
    LEFT JOIN FamilyHOH hoh ON hoh.family_id = cfm.family_id
    LEFT JOIN UserMaster mu ON mu.id = c.writing_advisor_id
    LEFT JOIN CONTACT_CATEGORIES cc ON cc.id = c.category_id
    LEFT JOIN PrefContactMethod pcm ON pcm.contact_id = c.id
    LEFT JOIN Drinks dr ON dr.contact_id = c.id
    LEFT JOIN PetName pn ON pn.contact_id = c.id
    LEFT JOIN ContactMadeAwareOfFocus cmaf ON cmaf.contact_id = c.id
    LEFT JOIN AllTaxIDsHaveClientContactRecord atc ON atc.contact_id = c.id
    LEFT JOIN SIGNEDAdvisoryAgreement saa ON saa.contact_id = c.id
    LEFT JOIN FocusLanguageInvestmentAgreement flia ON flia.contact_id = c.id
    WHERE (cs.name IN ('Client') OR c.id IN (1193, 1441))
      AND c.deleted = 0
)

/* Final household migration projection. */
SELECT DISTINCT
    $TransactionFirmID AS Transaction_Firm__c,
    $ParentOfficeID AS ParentID,
    $LegacyHHcPrefix || SOURCE.legacy_hh_id AS Legacy_ID__c,
    $ClientStartDate AS bffs_ClientStartDate__c,
    COALESCE(SOURCE.owner_id, $BackupOwnerID) AS OwnerId,
    SOURCE.owner_name_from_master AS xxxOwnerName,
    $HHRecordType AS RecordTypeId,
    SOURCE.household_type AS Household_Type__c,
    SOURCE.status AS FInServ_Status__c,
    TO_CHAR(CURRENT_DATE(), 'YYYY-MM-DD') AS Master_Payout_Date__c,
    SOURCE.source_of_business_label AS SourceOfBusiness__c,
    SOURCE.billing_street AS BillingStreet,
    SOURCE.billing_city AS BillingCity,
    SOURCE.billing_state AS BillingState,
    SOURCE.billing_postal_code AS BillingPostalCode,
    SOURCE.billing_country AS BillingCountry,
    SOURCE.referral_id AS Referral__c,
    SOURCE.legacy_crm_id AS Legacy_Firm_Info__c,
    SOURCE.mail_merge_first_last AS Mail_Merge_First_and_Last__c,
    SOURCE.mail_merge_last_only AS Mail_Merge_Last_Only__c,
    SOURCE.is_rpc_client AS Is_RPC_Client__c,
    SOURCE.review_frequency AS FInServ_Review_Frequency__c,
    SOURCE.client_since AS bffs_LegacyStartDate__c,
    SOURCE.legacy_portfolio_system_hhid AS LegacyPortfolioSystemHHID__c,
    SOURCE.legacy_hh_id AS source_household_id,
    SOURCE.included_in_household
FROM SOURCE
LEFT JOIN UserMaster u
  ON SOURCE.owner_id = u.writing_advisor_id
LEFT JOIN COUNTRY_CODES cc
  ON TRIM(UPPER(cc.country_alias)) = TRIM(UPPER(SOURCE.billing_country))
  OR TRIM(UPPER(cc.country_code)) = TRIM(UPPER(SOURCE.billing_country))
LEFT JOIN STATE_CODES sc
  ON TRIM(UPPER(SOURCE.billing_state)) = TRIM(UPPER(sc.state_alias))
  OR TRIM(UPPER(SOURCE.billing_state)) = TRIM(UPPER(sc.state_code))
LEFT JOIN HHMaster mh
  ON $LegacyHHcPrefix || SOURCE.legacy_hh_id = mh.TargetCRMId
LEFT JOIN ReferralMaster rm
  ON SOURCE.source_of_business = rm.REFERRAL_SOURCE__c
 AND rm.legacy_id__c NOT LIKE '%CustomJenReferralNetwork%'
WHERE SOURCE.included_in_household = 'Yes'
  AND (
        SOURCE.legacy_crm_id IS NOT NULL
        OR SOURCE.legacy_hh_id IN ('EVR_RT_HH_1441', 'EVR_RT_HH_1193')
      )
ORDER BY SOURCE.legacy_hh_id;
