'use client';

import { memo, useMemo } from 'react';
import { SQL_TOKEN_COLORS, tokenizeSql, type SqlToken } from './sql-tokenizer';

type SqlHighlightProps = {
  text: string;
  tokens?: SqlToken[];
  /**
   * Render every token at normal weight. Required when the highlight sits under an
   * editable textarea: bold glyphs are wider in a proportional font, which would
   * push the visible text out of line with the caret.
   */
  uniformWeight?: boolean;
};

function SqlHighlightComponent({
  text,
  tokens: providedTokens,
  uniformWeight = false,
}: SqlHighlightProps) {
  const tokens = useMemo(
    () => providedTokens ?? tokenizeSql(text),
    [providedTokens, text],
  );

  if (!text || tokens.length === 0) return null;

  return (
    <>
      {tokens.map((token, idx) => (
        <span
          key={`${idx}-${token.type}`}
          style={{
            color: SQL_TOKEN_COLORS[token.type],
            fontWeight:
              !uniformWeight && (token.type === 'keyword' || token.type === 'function')
                ? 600
                : 400,
          }}
        >
          {token.value}
        </span>
      ))}
    </>
  );
}

export const SqlHighlight = memo(SqlHighlightComponent);
