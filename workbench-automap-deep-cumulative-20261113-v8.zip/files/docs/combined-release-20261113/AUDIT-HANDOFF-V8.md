# V8 release audit: preserve execution tracking through the parent/worker handoff

V8 supersedes v7. Do not treat the v7 native model acceptance as proof of ownership-only dispatch.

The audit found that `_pending_resolution_request` removed the server-selected `_automap_call_tracking` marker while projecting child batches. Children then selected the legacy pooled store. V7 standalone ownership concurrency/duplicate tests were valid, but its full model acceptance did not assert which tracking implementation was actually used. The added pooled-path run exposed a 349.04s partial failure and the saved phase trace confirmed legacy admission_wait.

The corrected child projection preserves the server-owned marker, alongside existing generation/rule policies. Public acceptance still discards browser-supplied tracking metadata and selects policy on the server. Legacy frozen jobs without the marker keep their original recovery store; configuration changes do not retarget an already frozen generation.

New regressions cover server policy selection, child projection, durable restore and configuration changes. Native acceptance now asserts operation_v3 at the actual worker endpoint and operation_claim in the trace immediately before every model POST; a silently pooled test run cannot pass. The acceptance worker uses the same reusable caller control-session pool as production rather than a fresh connection for every control operation.

The service renderer default is also corrected from four targets to eight, matching the backend. Explicit client/profile overrides are preserved. If an existing environment or deployment profile explicitly selects AUTOMAP_FAST_BATCH_TARGETS=4, change that client setting to 8 if the desired deployment uses normal eight-target batches; no client environment files are bundled or changed by this release.

All v7 bootstrap, hybrid ownership table, narrow administrator grants, matching service images and agent deployment requirements still apply. AUTOMAP_SHARED_CAPACITY_LIMIT=false remains the default. SPCS replicas do not remove Snowflake/provider latency or ensure a universal 200-second bound. A local test uses native Snowflake sessions/models and concurrent batches, but is not a five-replica SPCS benchmark. See the new native report for measured outcomes rather than assuming deployment will make every run faster.


## Tests and release integrity

The v7 ZIP was audited before this correction: all 417 files matched their manifest, all 398 v6 files were retained, and the new bootstrap, service templates, metadata grant templates and matching agent manifest were present. That audit does not replace behavior testing.

After the correction, 209 parent/job/ownership tests passed, 166 actual fast-batch regressions passed, and 179 deployment/render/ownership/bootstrap checks passed. The new handoff tests deliberately fail on the v7 child projection. These are focused follow-up checks; the preceding full v7 suite was 5772 passed and 32 skipped. Frontend source is unchanged from v7, which passed 490 checks and TypeScript.


The checked-in UAT durable deployment profile specifies six caller control sessions; the default local acceptance used two. This is a metadata connection-pool setting, not a model-slot count. V8 adds an explicit acceptance-only CLI override so the native report records the tested value without modifying any client environment file. Existing UAT profile overrides remain authoritative.


## Corrected native acceptance

The corrected 40-target/12-source mixed fixture passed in **156.64 seconds** with six control sessions: 40 supported proposals, no failed batches, FIR recipe reuse and expected Snowflake output values verified. Five eight-target source submissions were sent between 15:50:06.114 and 15:50:07.256 UTC on November 13, 2026; two transformation submissions followed. Every actual POST trace contains operation_claim, and the returned runtime metadata identifies durable_operation_tracking with global_admission=false. Per-call initial source preparation was 16.90–17.63 seconds; control-session acquisition was 1.12–1.44 seconds. No operations remained occupied afterward.

The corrected actual prepare/job/private-worker Loan Income flow completed twice with two control sessions: 325.99s and 276.30s. Both returned 33 outcomes, 32 positive-confidence proposals and one missing-dependency outcome, without failed batches. The first completed three custom rules and the warm run five; ten actual worker calls preserved operation_v3, and all nineteen actual model POSTs passed the operation_claim assertion. These slower measurements remain part of the release evidence and do not support a universal under-200-second promise.

The failed 349.04s pre-fix pooling reproduction is retained as AUTOMAP-POOLED-LOAN-V8.json. It diagnoses the v7 marker-loss defect; it is not a failed corrected acceptance. V7 full-model results are retained for historical evidence but do not establish ownership-only dispatch.

No new bootstrap or grant change is added beyond v7; v8 preserves those installation files. Run the updated bootstrap and apply the narrow metadata grants before deploying matching images and agents. Ensure the rendered shared-capacity flag is false and the target batch size is eight unless an explicit reviewed override is intended. The six-session native test changes only its isolated test settings; it does not edit client.env or the UAT profile.
