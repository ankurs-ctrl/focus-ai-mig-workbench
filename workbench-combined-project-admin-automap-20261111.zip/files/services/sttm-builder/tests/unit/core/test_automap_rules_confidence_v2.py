import asyncio
import json
from types import SimpleNamespace
import pytest
from tests.test_automap_fast_transport import harness as transport_harness
from tests.unit.core.test_automap_guarded_specialist import setup, rules
from app.core.automap_rule_handoff import rule_route, definition_hash
from app.core.automap_row_candidates import score_candidate
from app.schema.sttm_builder import AttributeMapping, STTMBuilderEnvelopeRequest, MappingCandidate
from tests.unit.core.test_automap_fast_context import fast_payload, unpack


def draft_request(req):
    from app.core.automap_batch import freeze_fast_handoff
    req.meta['automap_generation_policy'] = 'draft-v3'
    req.meta['automap_rules_policy'] = 'rules-v2'
    req.meta['_automap_fast_handoff'] = freeze_fast_handoff(req)
    return req


@pytest.mark.parametrize('label', ['direct', 'unresolved', 'complex'])
def test_nl_rule_mislabeled_still_runs_specialist_with_identity(transport_harness, label):
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    req = draft_request(req)
    source = json.loads(source)
    item = source['data']['result']['mappings']['NAME0']
    item.update(transformation_classification=label, preprocessing_nl_rule='Trim surrounding whitespace',
                rule_intent={'description': 'Trim whitespace', 'required_columns': ['a.X47']})
    def hook(outgoing):
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:
            h.state.answer = json.dumps(source)
        else:
            packet = unpack(json.loads(outgoing.content)['messages'])
            selected = packet['data']['attributes'][0]['selected_mapping']
            answer = json.loads(rules('NAME0'))
            answer['data']['result']['rules'][0]['rule_candidate_id'] = selected['rule_candidate_id']
            h.state.answer = json.dumps(answer)
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    mapping = final.result.mappings['NAME0']
    assert mapping.preprocessing_rule == 'TRIM(a.X47)'
    assert mapping.rule_stage == 'rule_complete'
    assert mapping.confidence_score > 0
    assert mapping.confidence_policy_version == 'evidence-v1'
    assert models[0]._stage_calls['transformation_rule'] == 1, final.meta.get('transformation_stage')
    assert all(slot['STATE'] == 'FREE' for slot in h.database.slots)


@pytest.mark.parametrize('expression', ["CASE WHEN $FirmFlag = 'Y' THEN $FirmName ELSE 'Other' END", "CASE WHEN a.X47 IS NULL THEN $FirmName ELSE a.X47 END", "UPPER(a.X47)"])
def test_custom_expression_routes_even_when_labeled_direct(expression):
    mapping = AttributeMapping(source_attributes=[] if 'a.X47' not in expression else ['a.X47'], confidence_score=.5,
        preprocessing_rule=expression, transformation_classification='direct', preprocessing_rule_type='Direct')
    assert rule_route(mapping)[0] == 'rule_pending'


def test_unchanged_completed_rule_skips_but_edit_invalidates_receipt():
    mapping = AttributeMapping(source_attributes=['a.X47'], confidence_score=.5, preprocessing_rule='TRIM(a.X47)', rule_stage='rule_complete')
    mapping.rule_definition_hash = definition_hash(mapping)
    assert rule_route(mapping)[0] == 'rule_complete'
    mapping.preprocessing_rule = 'UPPER(a.X47)'
    assert rule_route(mapping)[0] == 'rule_pending'


@pytest.mark.parametrize('model_score', [None, 0, .98])
def test_calculated_score_positive_and_idempotent_even_without_model_score(model_score):
    payload = fast_payload(1)
    payload['meta']['automap_generation_policy'] = 'draft-v3'
    payload['meta']['automap_rules_policy'] = 'rules-v2'
    req = STTMBuilderEnvelopeRequest.model_validate(payload)
    candidate = MappingCandidate(source_attributes=['a.X47'], source_dependencies=['a.X47'], confidence_score=model_score or 0,
        original_confidence_score=model_score, preprocessing_rule_type='Direct', validation_status='valid',
        decision_basis={'citations': ['src:a.X47']})
    first = score_candidate(candidate, [], req=req, target='NAME0')
    second = score_candidate(first, [], req=req, target='NAME0')
    assert first.confidence_score == second.confidence_score > 0
    assert first.original_confidence_score == model_score
    assert first.confidence_provenance == second.confidence_provenance
    assert first.confidence_policy_version == 'evidence-v1'


def test_no_supported_proposal_has_zero_score():
    payload = fast_payload(1); payload['meta']['automap_generation_policy'] = 'draft-v3'
    payload['meta']['automap_rules_policy'] = 'rules-v2'
    req = STTMBuilderEnvelopeRequest.model_validate(payload)
    candidate = MappingCandidate(source_attributes=[], confidence_score=.99, original_confidence_score=.99)
    assert score_candidate(candidate, [], req=req, target='NAME0').confidence_score == 0


@pytest.mark.parametrize('score', [None, 'missing', 0.87])
def test_real_source_response_missing_or_malformed_confidence_keeps_direct_definition(transport_harness, score):
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    req = draft_request(req)
    source = json.loads(source)
    item = source['data']['result']['mappings']['NAME0']
    item.update(preprocessing_rule_type='Direct', transformation_classification='direct')
    if score is None:
        item.pop('confidence_score')
    else:
        item['confidence_score'] = score
    h.state.answer = json.dumps(source)
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    candidate = final.result.mappings['NAME0'].candidates[0]
    assert candidate.source_attributes == ['a.X47']
    assert candidate.confidence_score > 0
    assert candidate.confidence_provenance['score_source'] == ('model_with_backend_caps' if isinstance(score, float) else 'backend_evidence_fallback')
    assert models[0]._stage_calls['transformation_rule'] == 0


def test_wrong_candidate_rule_never_receives_completed_receipt(transport_harness):
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    req = draft_request(req)
    def hook(outgoing):
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:
            h.state.answer = source
        else:
            answer = json.loads(rules('NAME0'))
            answer['data']['result']['rules'][0]['rule_candidate_id'] = 'wrong-candidate'
            h.state.answer = json.dumps(answer)
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings['NAME0'].rule_stage != 'rule_complete'
    assert not final.result.mappings['NAME0'].rule_definition_hash


def test_source_scheduling_reserves_calls_without_stopping_rule_runtime(transport_harness):
    import time
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    req = draft_request(req)
    h.state.answer = source
    # Create the runtime through the actual public worker flow.
    asyncio.run(builder.invoke_auto_map_parallel(req))
    runtime = models[0]
    runtime._source_schedule_deadline = time.monotonic() - 1
    with pytest.raises(TimeoutError, match='reserved'):
        runtime.run([], runtime.next_call_index, stage='source_mapping')
    assert not runtime._stop.is_set()
    runtime.check_active()


def test_value_only_case_runs_specialist_without_fake_source_column(transport_harness):
    from app.schema.sttm_builder import ValueBinding
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    req.context.relation_graph.value_bindings = [ValueBinding(binding_id='prefix', value='$FirmPrefix',
        resolved_value='TEST-', data_type='VARCHAR', allow_project_specific_value=True, is_placeholder=True)]
    from app.core.automap_policy import preparation_hash
    req.context.prepared_context_hash = preparation_hash(req.context)
    req = draft_request(req)
    source = json.loads(source)
    source['data']['result']['mappings']['NAME0'] = {'source_attributes': [], 'source_dependencies': [],
        'value_binding_ids': ['prefix'], 'confidence_score': .8, 'preprocessing_rule_type': 'Custom',
        'transformation_classification': 'complex', 'mapping_mode': 'source',
        'rule_intent': {'description': "CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other' END"},
        'decision_basis': {'citations': ['val:$FirmPrefix']}}
    def hook(outgoing):
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:
            h.state.answer = json.dumps(source)
        else:
            packet = unpack(json.loads(outgoing.content)['messages'])
            selected = packet['data']['attributes'][0]['selected_mapping']
            h.state.answer = json.dumps({'agent': 'AGT_TRANSFORMATION_RULE', 'data': {'result': {'rules': [{
                'target_attribute': 'NAME0', 'rule_candidate_id': selected['rule_candidate_id'],
                'rule': "CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other' END",
                'source_dependencies': [], 'value_binding_ids': ['prefix'], 'confidence_score': .9}]}}})
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    mapping = final.result.mappings['NAME0']
    assert mapping.rule_stage == 'rule_complete', final.meta.get('transformation_stage')
    assert mapping.source_attributes == []
    assert mapping.value_binding_ids == ['$FirmPrefix']
    assert mapping.preprocessing_rule.startswith('CASE ')
    assert mapping.confidence_score > 0
    assert models[0]._stage_calls['transformation_rule'] == 1


@pytest.mark.parametrize('description,expected', [('Intentionally SQL NULL; no owner lookup', 'NULL'), ('Owner name from available evidence', None)])
def test_json_null_constant_only_becomes_sql_null_with_explicit_support(transport_harness, description, expected):
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    req.data.attributes[0].target_description = description
    req = draft_request(req)
    source = json.loads(source)
    source['data']['result']['mappings']['NAME0'] = {'source_attributes': [], 'source_dependencies': [],
        'mapping_mode': 'constant', 'constant_value': None, 'confidence_score': .9, 'transformation_classification': 'value'}
    h.state.answer = json.dumps(source)
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    mapping = final.result.mappings['NAME0']
    assert mapping.constant_value == expected
    if expected:
        assert mapping.candidates[0].validation_status == 'valid'
        assert mapping.confidence_score > 0
        assert mapping.rule_stage == 'value'
    else:
        assert mapping.confidence_score == 0
    assert models[0]._stage_calls['transformation_rule'] == 0


def test_rule_receipt_changes_with_current_firm_values():
    from app.schema.sttm_builder import ValueBinding
    req = STTMBuilderEnvelopeRequest.model_validate(fast_payload())
    req.context.relation_graph.value_bindings = [ValueBinding(binding_id='prefix', value='$FirmPrefix', resolved_value='A')]
    mapping = AttributeMapping(source_attributes=[], confidence_score=.8, preprocessing_rule="UPPER($FirmPrefix)", rule_stage='rule_complete')
    mapping.rule_definition_hash = definition_hash(mapping, req.context)
    assert rule_route(mapping, req.context)[0] == 'rule_complete'
    req.context.relation_graph.value_bindings[0].resolved_value = 'B'
    assert rule_route(mapping, req.context)[0] == 'rule_pending'


def test_partial_specialist_response_keeps_valid_sibling_through_failed_repair(transport_harness):
    h = transport_harness
    builder, models, req, source = setup(h, 2)
    req = draft_request(req)
    posts = []
    def hook(outgoing):
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:
            h.state.answer = source
        else:
            packet = unpack(json.loads(outgoing.content)['messages'])
            posts.append(packet)
            if len(posts) == 1:
                answer = json.loads(rules('NAME0', 'NAME1'))
                answer['data']['status'] = 'needs_input'
                for rule in answer['data']['result']['rules']:
                    rule['rule_candidate_id'] = next(item['selected_mapping']['rule_candidate_id'] for item in packet['data']['attributes'] if item['target_attribute'] == rule['target_attribute'])
                answer['data']['result']['rules'][1]['rule'] = None
                h.state.answer = json.dumps(answer)
            else:
                h.state.mode = 'timeout'
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings['NAME0'].rule_stage == 'rule_complete'
    assert final.result.mappings['NAME0'].preprocessing_rule == 'TRIM(a.X47)'
    assert final.result.mappings['NAME1'].rule_stage != 'rule_complete'
    assert len(posts) == 2
    assert len(posts[1]['data']['attributes']) == 1


def test_rules_protocol_is_assigned_only_to_new_backend_accepted_resolution():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    req = STTMBuilderEnvelopeRequest.model_validate(fast_payload())
    req.context.project_id = '1'
    settings = Settings(_env_file=None, AUTOMAP_FAST_PATH_V1=True, AUTOMAP_FAST_PROJECT_IDS='*')
    proxy = AutoMappingProxyClient(settings)
    req.meta['auto_map_resolution_mode'] = 'preserve_and_complete'
    accepted = proxy._accept_resolution(req)
    assert accepted.meta['automap_rules_policy'] == 'rules-v2'
    req.meta.pop('auto_map_resolution_mode')
    req.meta['automap_rules_policy'] = 'rules-v2'
    legacy = proxy._accept_resolution(req)
    assert 'automap_rules_policy' not in legacy.meta
