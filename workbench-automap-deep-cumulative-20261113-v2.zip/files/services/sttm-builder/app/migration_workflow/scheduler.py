"""Deterministic, completion-driven scheduling; no entity names or model decisions."""
from __future__ import annotations
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from enum import Enum
from typing import Any, Callable, Literal
from pydantic import BaseModel, Field, model_validator


class PartitionState(str, Enum):
    READY = 'READY'
    RUNNING = 'RUNNING'
    COMPLETED = 'COMPLETED'
    WAITING = 'WAITING_FOR_DEPENDENCY'
    AMBIGUOUS = 'AMBIGUOUS'
    INVALID = 'INVALID'
    NEEDS_REVIEW = 'NEEDS_REVIEW'


class Dependency(BaseModel):
    consumer_mapping: str
    producer_mapping: str
    producer_output: str
    producer_columns: list[str] = Field(default_factory=list)
    consumer_project: str = ''
    producer_project: str = ''
    consumer_columns: list[str] = Field(default_factory=list)
    consumer_artifact: str | None = None
    dependency_type: str = 'ARTIFACT_CONTRACT'
    required_producer_stage: str = 'mapped'
    blocking_scope: Literal['column', 'artifact', 'mapping', 'compile', 'validation', 'reconciliation'] = 'compile'
    required: bool = True
    evidence_id: str = Field(min_length=1)
    confidence: float = Field(ge=0, le=1)
    revision: int = Field(default=1, ge=1)
    producer_revision: int = Field(default=1, ge=1)
    availability: Literal['draft', 'load_time'] = 'draft'
    state: str = 'WAITING_FOR_DEPENDENCY'


class ArtifactContract(BaseModel):
    artifact_id: str
    producer_mapping: str
    producer_project: str = ''
    revision: int = Field(ge=1)
    stage: str
    evidence_ids: list[str] = Field(min_length=1)
    availability: Literal['draft', 'load_time'] = 'draft'
    verified: bool = False
    payload: dict[str, Any] = Field(default_factory=dict)


class Partition(BaseModel):
    partition_id: str
    mapping_key: str
    project_id: str = ''
    stage: Literal['map', 'compile', 'validate', 'reconcile'] = 'map'
    columns: list[str] = Field(default_factory=list)
    waits_for: list[str] = Field(default_factory=list)
    dependencies: list[Dependency] = Field(default_factory=list)
    revision: int = Field(default=1, ge=1)
    state: PartitionState = PartitionState.READY
    result: dict[str, Any] = Field(default_factory=dict)
    dependency_contracts: list[ArtifactContract] = Field(default_factory=list)


def validate_graph(partitions: list[Partition]) -> None:
    by_id = {p.partition_id: p for p in partitions}
    if len(by_id) != len(partitions):
        raise ValueError('Duplicate partition identity')
    edges = {p.partition_id: set(p.waits_for) for p in partitions}
    # Cross-mapping contracts also participate in cycle detection.
    for p in partitions:
        for d in p.dependencies:
            if d.consumer_mapping != p.mapping_key:
                raise ValueError('Dependency consumer does not match its partition')
            if d.availability == 'draft' and d.required:
                producers = {v.partition_id for v in partitions if v.mapping_key == d.producer_mapping and v.partition_id != p.partition_id}
                if not producers:
                    raise ValueError(f'Unknown producer mapping: {d.producer_mapping}')
                # A mapped artifact can be produced before compilation.
                if d.required_producer_stage == 'mapped':
                    mapped = [by_id[v] for v in producers if by_id[v].stage == 'map']
                    available = {column for producer in mapped for column in producer.columns}
                    if set(d.producer_columns) - available:
                        raise ValueError('Dependency references unknown producer columns')
                    edges[p.partition_id].update(producer.partition_id for producer in mapped
                        if not d.producer_columns or set(d.producer_columns).intersection(producer.columns))
                else:
                    edges[p.partition_id].update(v for v in producers if by_id[v].stage == 'compile')
    for key, parents in edges.items():
        if parents - by_id.keys():
            raise ValueError(f'Unknown dependency for {key}')
    remaining = dict(edges)
    while remaining:
        ready = {key for key, parents in remaining.items() if not parents.intersection(remaining)}
        if not ready:
            raise ValueError('Dependency graph contains a cycle: ' + ', '.join(sorted(remaining)))
        remaining = {key: parents for key, parents in remaining.items() if key not in ready}


def dependency_ready(edge: Dependency, contracts: dict[str, ArtifactContract]) -> bool:
    contract = contracts.get(edge.producer_output)
    return bool(contract and edge.availability == contract.availability == 'draft' and contract.verified
                and contract.producer_mapping == edge.producer_mapping
                and (not edge.producer_project or contract.producer_project == edge.producer_project)
                and contract.revision == edge.producer_revision
                and contract.stage == edge.required_producer_stage)


class PartitionScheduler:
    def __init__(self, *, max_workers: int, persist: Callable[[Partition], None], check_active: Callable[[], None]):
        if max_workers < 1:
            raise ValueError('Worker capacity must be positive')
        self.max_workers = max_workers
        self.persist = persist
        self.check_active = check_active

    def run(self, partitions: list[Partition], execute: Callable[[Partition], dict[str, Any]], *, contracts: list[ArtifactContract] = ()) -> list[Partition]:
        validate_graph(partitions)
        by_id = {p.partition_id: p for p in partitions}
        outputs = {c.artifact_id: c for c in contracts}
        for p in partitions:
            for value in p.result.get('artifact_contracts', []) if p.state == PartitionState.COMPLETED else []:
                c = ArtifactContract.model_validate(value)
                if c.producer_mapping != p.mapping_key or c.revision != p.revision:
                    raise ValueError('Stale persisted artifact contract')
                if c.artifact_id in outputs and outputs[c.artifact_id] != c:
                    raise ValueError('Conflicting persisted artifact contract')
                outputs[c.artifact_id] = c
            if p.state == PartitionState.RUNNING:
                p.state = PartitionState.READY  # reclaimed owner must use idempotent domain commands
        with ThreadPoolExecutor(max_workers=self.max_workers, thread_name_prefix='migration-partition') as pool:
            running = {}
            while True:
                self.check_active()
                pending = [p for p in partitions if p.state in {PartitionState.READY, PartitionState.WAITING}]
                for p in pending:
                    parents_ready = all(by_id[key].state == PartitionState.COMPLETED for key in p.waits_for)
                    evidence_ready = all(not d.required or dependency_ready(d, outputs) for d in p.dependencies)
                    if not parents_ready or not evidence_ready:
                        if p.state != PartitionState.WAITING:
                            p.state = PartitionState.WAITING; self.persist(p)
                        continue
                    if len(running) >= self.max_workers:
                        continue
                    p.dependency_contracts = [outputs[d.producer_output].model_copy(deep=True)
                        for d in p.dependencies if dependency_ready(d, outputs)]
                    p.state = PartitionState.RUNNING
                    self.persist(p)
                    running[pool.submit(execute, p.model_copy(deep=True))] = p
                if not running:
                    break
                finished, _ = wait(running, return_when=FIRST_COMPLETED, timeout=0.25)
                for future in finished:
                    p = running.pop(future)
                    try:
                        result = future.result()
                        if result.get('revision', p.revision) != p.revision:
                            raise ValueError('Stale partition result')
                        next_state = PartitionState(result.get('partition_state', 'COMPLETED'))
                        new_outputs = {}
                        for value in result.get('artifact_contracts', []):
                            c = ArtifactContract.model_validate(value)
                            if c.producer_mapping != p.mapping_key or c.revision != p.revision:
                                raise ValueError('Artifact producer/revision mismatch')
                            existing = new_outputs.get(c.artifact_id) or outputs.get(c.artifact_id)
                            if existing and existing != c:
                                raise ValueError('Conflicting artifact contract')
                            new_outputs[c.artifact_id] = c
                        p.result = result
                        p.state = next_state
                        if next_state == PartitionState.COMPLETED:
                            # Contracts may need columns from several independent producer
                            # partitions. Assemble from durable completed rows, never running
                            # siblings, and persist the contract on the completing partition.
                            if p.stage == 'map':
                                from app.migration_workflow.artifacts import emit_artifact_contracts
                                siblings = [s for s in partitions if s.mapping_key == p.mapping_key
                                    and s.project_id == p.project_id and s.revision == p.revision]
                                combined = {'mapping_rows': merge_column_partitions(siblings)}
                                declared = [d for consumer in partitions for d in consumer.dependencies
                                    if d.producer_output not in outputs and d.producer_output not in new_outputs]
                                for value in emit_artifact_contracts(mapping_key=p.mapping_key,
                                        project_id=p.project_id, revision=p.revision, stage='mapped',
                                        result=combined, dependencies=declared):
                                    c = ArtifactContract.model_validate(value)
                                    new_outputs[c.artifact_id] = c
                                    p.result.setdefault('artifact_contracts', []).append(value)
                            outputs.update(new_outputs)
                    except (PermissionError, KeyboardInterrupt):
                        raise
                    except Exception as exc:
                        # Budget/cancellation must propagate to the resumable run boundary.
                        if getattr(exc, 'error_code', '') in {'budget_exhausted','execution_cancelled','worker_lease_lost'}:
                            raise
                        p.state = PartitionState.NEEDS_REVIEW
                        partial = getattr(exc, 'partial_result', None)
                        p.result = dict(partial) if isinstance(partial, dict) else {
                            'error_type': type(exc).__name__, 'safe_summary': str(exc)
                        }
                        p.result.setdefault('error_type', type(exc).__name__)
                    self.persist(p)
        return partitions


def merge_column_partitions(partitions: list[Partition]) -> list[dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for p in sorted(partitions, key=lambda item: item.partition_id):
        if p.state != PartitionState.COMPLETED or p.stage != 'map':
            continue
        allowed = {c.upper() for c in p.columns}
        for row in p.result.get('mapping_rows', []):
            key = str(row['target_column']).upper()
            if allowed and key not in allowed:
                raise ValueError('Partition returned an unassigned target column')
            if key in rows and rows[key] != row:
                raise ValueError('Conflicting target-column assignments')
            rows[key] = row
    return [rows[key] for key in sorted(rows)]
