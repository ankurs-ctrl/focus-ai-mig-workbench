"""Transformation calls on the owning Auto-map runtime, without legacy replay."""
import json

from app.core.automap_fast_transport import FastModelRuntime
from app.schema.sttm_builder import STTMBuilderResponse, STTMStatus, SubAgent, TransformationResult


def invoke_specialist(service, req, runtime):
    if not isinstance(runtime, FastModelRuntime) and getattr(runtime, "is_test_runtime", False) is not True:
        raise ValueError("Transformation requires the owning guarded Auto-map runtime")
    runtime.check_active()
    projected = service.project_agent_payload(req, service._settings)
    messages = [{"role": "user", "content": [{"type": "text", "text": projected.text}]}]
    raw, _thread, diagnostics = runtime.run(messages, runtime.next_call_index, stage="transformation_rule")
    runtime.check_active()
    # Completion is enforced by the transport. Delegation is not a completed
    # rule and cannot be smuggled through the legacy envelope normalizer.
    from app.core.sttm_builder import _extract_json_object
    envelope = json.loads(_extract_json_object(raw))
    if not isinstance(envelope, dict) or (envelope.get("meta") or {}).get("delegation"):
        raise ValueError("Specialist returned delegation instead of completed rules")
    parsed = service._parse_envelope(raw)
    if parsed[4] is not None or parsed[6] != STTMStatus.COMPLETED or not isinstance(parsed[1], TransformationResult):
        raise ValueError("Specialist did not return completed structured rules")
    runtime.check_active()
    answer = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.TRANSFORMATION_AGENT, result=parsed[1], message=parsed[2],
        warnings=service._auto_map_response_warnings(parsed[3]), status=STTMStatus.COMPLETED,
        meta={"fast_diagnostics": diagnostics.get("fast_diagnostics", {})})
    answer = service._postflight_guard.finalize_sttm_response(answer, runtime._decision)
    runtime.check_active()
    if answer.error is not None or answer.data.status != STTMStatus.COMPLETED:
        raise ValueError("Specialist rule did not pass response governance")
    return answer
