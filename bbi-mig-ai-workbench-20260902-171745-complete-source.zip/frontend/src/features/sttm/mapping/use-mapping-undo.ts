'use client';

import { useCallback, useState } from 'react';

import type { MappingState } from '@/features/sttm/types/sttm.types';

export const MAX_MAPPING_UNDO_STACK = 5;

type MappingUndoEntry = {
  id: string;
  snapshot: MappingState;
};

function cloneMappingState(row: MappingState): MappingState {
  return {
    ...row,
    sourceColumns: row.sourceColumns ? [...row.sourceColumns] : undefined,
    candidateSourceColumns: row.candidateSourceColumns
      ? [...row.candidateSourceColumns]
      : undefined,
    usedInferenceIds: row.usedInferenceIds ? [...row.usedInferenceIds] : undefined,
    usedRecommendationIds: row.usedRecommendationIds
      ? [...row.usedRecommendationIds]
      : undefined,
    usedLearningIds: row.usedLearningIds ? [...row.usedLearningIds] : undefined,
    sourceDependencies: row.sourceDependencies ? [...row.sourceDependencies] : undefined,
    valueBindingIds: row.valueBindingIds ? [...row.valueBindingIds] : undefined,
    overrideEvidence: row.overrideEvidence ? [...row.overrideEvidence] : undefined,
  };
}

export function useMappingUndo(
  mappings: MappingState[],
  updateMapping: (id: string, updates: Partial<MappingState>) => void,
) {
  const [undoStack, setUndoStack] = useState<MappingUndoEntry[]>([]);

  const pushUndoSnapshot = useCallback((row: MappingState) => {
    setUndoStack((current) => {
      const next = [...current, { id: row.id, snapshot: cloneMappingState(row) }];
      return next.slice(-MAX_MAPPING_UNDO_STACK);
    });
  }, []);

  const updateMappingWithUndo = useCallback((
    id: string,
    updates: Partial<MappingState>,
    options?: { skipUndo?: boolean },
  ) => {
    const row = mappings.find((mapping) => mapping.id === id);
    if (!row) {
      return;
    }

    if (!options?.skipUndo) {
      pushUndoSnapshot(row);
    }

    updateMapping(id, updates);
  }, [mappings, pushUndoSnapshot, updateMapping]);

  const undoLastChange = useCallback(() => {
    setUndoStack((current) => {
      const entry = current[current.length - 1];
      if (!entry) {
        return current;
      }

      updateMapping(entry.id, cloneMappingState(entry.snapshot));
      return current.slice(0, -1);
    });
  }, [updateMapping]);

  const clearUndoStack = useCallback(() => {
    setUndoStack([]);
  }, []);

  return {
    undoCount: undoStack.length,
    canUndo: undoStack.length > 0,
    updateMappingWithUndo,
    undoLastChange,
    clearUndoStack,
  };
}
