"use client";
import { AiaBox, AiaButton, AiaIconButton, AiaStack } from '@/components/ui';
import { AiaInput } from '@/components/ui/aia-input';
import { AiaText } from '@/components/ui/aia-text';
import { useEffect, useMemo, useRef, useState } from "react";
import {
  AddRoundedIcon,
  ArrowForwardRoundedIcon,
  CloseRoundedIcon,
  GridOnRoundedIcon,
  TerminalRoundedIcon,
  ViewKanbanRoundedIcon,
} from "@/utils/icons";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import { useTour } from "@/features/tour/engine/tour-context";
import { API_ROUTES } from "@/api/routes";
import { useRouter } from "next/navigation";

type UploadResult = {
  asset_id: string;
  filename?: string;
  parsed_summary?: {
    sources?: string[];
    targets?: string[];
    mappings_count?: number;
    columns_count?: number;
  };
};

type MappingCreationMode = "sql" | "excel" | "manual" | null;

type NewMappingDialogProps = {
  open: boolean;
  onClose: () => void;
  onBuildManually: (details?: { name: string; description: string }) => void;
  projectId?: string;
};

type MappingOption = {
  id: Exclude<MappingCreationMode, null>;
  label: string;
  badge?: string;
  badgeBg: string;
  badgeFg: string;
  description: string;
  icon: React.ReactNode;
};

const OPTIONS: MappingOption[] = [
  {
    id: "sql",
    label: "SQL Upload",
    badge: "AUTO-GENERATE",
    badgeBg: "#ede9fe",
    badgeFg: "#7c3aed",
    description: "Upload a SQL file and auto-generate the source-to-target mapping from your query.",
    icon: <TerminalRoundedIcon sx={{ fontSize: 24, color: "#64748b" }} />,
  },
  {
    id: "excel",
    label: "Upload Excel File",
    badge: "IMPORT",
    badgeBg: "#dcfce7",
    badgeFg: "#059669",
    description: "Import an existing mapping spreadsheet to populate the STTM grid automatically.",
    icon: <GridOnRoundedIcon sx={{ fontSize: 24, color: "#64748b" }} />,
  },
  {
    id: "manual",
    label: "Build Mapping Manually",
    badgeBg: "transparent",
    badgeFg: "#0f172a",
    description: "Select source tables, define joins, and map columns step by step through the guided workflow.",
    icon: <ViewKanbanRoundedIcon sx={{ fontSize: 24, color: "#64748b" }} />,
  },
];

export default function NewMappingDialog({
  open,
  onClose,
  onBuildManually,
  projectId,
}: NewMappingDialogProps) {
  const { registerModalTour, startTour } = useTour();
  const [selectedMode, setSelectedMode] = useState<MappingCreationMode>(null);
  const [mappingName, setMappingName] = useState("");
  const [mappingDescription, setMappingDescription] = useState("");
  const sqlInputRef = useRef<HTMLInputElement | null>(null);
  const excelInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!open) {
      registerModalTour(null);
      return;
    }
    registerModalTour("new-mapping");
    return () => registerModalTour(null);
  }, [open, registerModalTour]);

  const selectedOption = useMemo(
    () => OPTIONS.find((option) => option.id === selectedMode) ?? null,
    [selectedMode],
  );

  const handleClose = () => {
    setSelectedMode(null);
    setMappingName("");
    setMappingDescription("");
    setUploadResult(null);
    setLearningComplete(false);
    onClose();
  };

  const handleUploadSelection = (input: HTMLInputElement | null) => {
    if (!input) {
      return;
    }
    input.value = "";
    input.click();
  };

  const handleProceed = () => {
    if (!selectedMode) {
      return;
    }

    if (selectedMode === "manual") {
      setSelectedMode(null);
      setMappingName("");
      setMappingDescription("");
      if (projectId) {
        onBuildManually({ name: mappingName.trim(), description: mappingDescription.trim() });
      } else {
        onBuildManually();
      }
      return;
    }

    handleUploadSelection(selectedMode === "sql" ? sqlInputRef.current : excelInputRef.current);
  };

  const router = useRouter();
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<UploadResult | null>(null);
  const [learningInProgress, setLearningInProgress] = useState(false);
  const [learningComplete, setLearningComplete] = useState(false);

  const handleFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "sql" | "excel"
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("File exceeds 5MB limit");
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("project_id", projectId || "default");
      formData.append("mode", "auto_populate");

      const endpoint = type === "sql" ? API_ROUTES.upload.sql : API_ROUTES.upload.excel;
      const response = await fetch(`/api${endpoint}`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const err = await response.json().catch(() => ({ detail: "Upload failed" }));
        alert(err.detail || "Upload failed");
        return;
      }

      const result = await response.json();
      setUploadResult({ ...result, filename: file.name });
    } catch {
      alert("Upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleContinueEditing = () => {
    if (!uploadResult) return;
    sessionStorage.setItem("upload_parsed_data", JSON.stringify(uploadResult));
    setUploadResult(null);
    setSelectedMode(null);
    onClose();
    router.push("/sttm/builder/new/mapping?source=upload");
  };

  const handleUseAsLearning = async () => {
    if (!uploadResult?.asset_id) return;
    setLearningInProgress(true);
    try {
      const response = await fetch(`/api${API_ROUTES.upload.triggerLearning}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          asset_id: uploadResult.asset_id,
          project_id: projectId || "default",
        }),
      });
      if (!response.ok) {
        const err = await response.json().catch(() => ({ detail: "Learning failed" }));
        alert(err.detail || "Failed to create learnings.");
        return;
      }
      setLearningComplete(true);
    } catch {
      alert("Failed to create learnings. Please try again.");
    } finally {
      setLearningInProgress(false);
    }
  };

  const handleLearningDone = () => {
    setUploadResult(null);
    setLearningComplete(false);
    setSelectedMode(null);
    onClose();
  };

  if (!open) {
    return (
      <>
        <input
          ref={sqlInputRef}
          type="file"
          accept=".sql,text/sql,application/sql"
          hidden
          onChange={(e) => handleFileUpload(e, "sql")}
        />
        <input
          ref={excelInputRef}
          type="file"
          accept=".xlsx,.xls,.csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
          hidden
          onChange={(e) => handleFileUpload(e, "excel")}
        />
      </>
    );
  }

  return (
    <>
      <AiaBox
        role="dialog"
        aria-modal="true"
        aria-label="New Mapping"
        onClick={handleClose}
        sx={{
          position: "fixed",
          inset: 0,
          zIndex: 1400,
          px: 2,
          py: 4,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(15, 23, 42, 0.42)",
          backdropFilter: "blur(4px)",
        }}
      >
        <AiaBox
          data-tour={TOUR_TARGETS.newMappingModal}
          onClick={(event) => event.stopPropagation()}
          sx={{
            width: "100%",
            maxWidth: 728,
            borderRadius: "24px",
            border: "1px solid rgba(15, 23, 42, 0.08)",
            boxShadow: "0 30px 60px rgba(15, 23, 42, 0.18)",
            overflow: "hidden",
            backgroundColor: "#fff",
          }}
        >
          <AiaBox
            sx={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: 2,
              px: 4,
              py: 3.25,
              borderBottom: "1px solid #edf2f7",
            }}
          >
            <AiaStack direction="row" spacing={2} sx={{ alignItems: "center" }}>
              <AiaBox
                sx={{
                  width: 48,
                  height: 48,
                  borderRadius: "14px",
                  bgcolor: "var(--aia-button-color)",
                  color: "var(--aia-button-text-color)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <AddRoundedIcon sx={{ fontSize: 28 }} />
              </AiaBox>
              <AiaBox>
                <AiaText sx={{ fontSize: 18, fontWeight: 800, color: "#0f172a" }}>
                  New Mapping
                </AiaText>
                <AiaText sx={{ fontSize: 14, color: "#64748b", mt: 0.5 }}>
                  Choose how you&apos;d like to create this mapping
                </AiaText>
              </AiaBox>
            </AiaStack>

            <AiaStack direction="row" spacing={1} sx={{ alignItems: "center", flexShrink: 0 }}>
              <AiaButton
                variant="contained"
                size="small"
                onClick={() => startTour("new-mapping")}
                aria-label="Start New Mapping tour guide"
                sx={{
                  textTransform: "none",
                  fontWeight: 700,
                  fontSize: 13,
                  borderRadius: "10px",
                  px: 1.5,
                  py: 0.6,
                  minHeight: 34,
                  backgroundColor: "var(--aia-primary-bg-color)",
                  color: "var(--aia-primary-bg-text-color)",
                  boxShadow: "none",
                  "&:hover": {
                    backgroundColor: "var(--aia-primary-bg-hover-color)",
                  },
                }}
              >
                Tour Guide
              </AiaButton>
              <AiaIconButton
                onClick={handleClose}
              sx={{
                border: "1px solid #e2e8f0",
                color: "#64748b",
                bgcolor: "#fff",
                "&:hover": {
                  bgcolor: "#f8fafc",
                },
              }}
            >
              <CloseRoundedIcon sx={{ fontSize: 18 }} />
            </AiaIconButton>
            </AiaStack>
          </AiaBox>

          {uploadResult ? (
            <AiaBox sx={{ px: 4, py: 3.5 }}>
              {learningComplete ? (
                <AiaStack spacing={2} sx={{ alignItems: "center", py: 2 }}>
                  <AiaBox sx={{ width: 56, height: 56, borderRadius: "50%", bgcolor: "#dcfce7", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <AiaText sx={{ fontSize: 28 }}>&#10003;</AiaText>
                  </AiaBox>
                  <AiaText sx={{ fontSize: 16, fontWeight: 700, color: "#0f172a", textAlign: "center" }}>
                    Learnings Created Successfully
                  </AiaText>
                  <AiaText sx={{ fontSize: 13.5, color: "#64748b", textAlign: "center" }}>
                    All AI agents have been updated with patterns from your uploaded document. Future recommendations will prioritize these learnings.
                  </AiaText>
                  <AiaButton variant="contained" color="primary" rounded="lg" size="medium" onClick={handleLearningDone} sx={{ mt: 1, borderRadius: "14px", fontWeight: 700 }}>
                    Done
                  </AiaButton>
                </AiaStack>
              ) : learningInProgress ? (
                <AiaStack spacing={2} sx={{ alignItems: "center", py: 3 }}>
                  <AiaBox sx={{ width: 48, height: 48, borderRadius: "50%", border: "3px solid #e2e8f0", borderTopColor: "var(--aia-button-color)", animation: "spin 1s linear infinite", "@keyframes spin": { from: { transform: "rotate(0deg)" }, to: { transform: "rotate(360deg)" } } }} />
                  <AiaText sx={{ fontSize: 15, fontWeight: 700, color: "#0f172a" }}>
                    Creating Learnings...
                  </AiaText>
                  <AiaText sx={{ fontSize: 13, color: "#64748b", textAlign: "center" }}>
                    FIR agents are analyzing your document and generating recommendations. This may take a moment.
                  </AiaText>
                </AiaStack>
              ) : (
                <AiaStack spacing={2.5}>
                  <AiaBox sx={{ p: 2, borderRadius: "12px", bgcolor: "#f8fafc", border: "1px solid #e2e8f0" }}>
                    <AiaText sx={{ fontSize: 13, fontWeight: 700, color: "#334155", mb: 0.5 }}>
                      File uploaded: {uploadResult.filename || "document"}
                    </AiaText>
                    {uploadResult.parsed_summary && (
                      <AiaText sx={{ fontSize: 12.5, color: "#64748b" }}>
                        {uploadResult.parsed_summary.sources?.length ?? 0} source table(s)
                        {uploadResult.parsed_summary.targets?.length ? ` • ${uploadResult.parsed_summary.targets.length} target(s)` : ""}
                        {uploadResult.parsed_summary.columns_count ? ` • ${uploadResult.parsed_summary.columns_count} columns` : ""}
                      </AiaText>
                    )}
                  </AiaBox>
                  <AiaText sx={{ fontSize: 14, fontWeight: 600, color: "#0f172a" }}>
                    What would you like to do with this file?
                  </AiaText>
                  <AiaButton
                    variant="text"
                    onClick={handleContinueEditing}
                    sx={{ width: "100%", textTransform: "none", display: "block", px: 2.25, py: 2, borderRadius: "14px", border: "1px solid #dbe2ea", textAlign: "left", "&:hover": { borderColor: "var(--aia-button-color)", bgcolor: "#fafbff" } }}
                  >
                    <AiaText sx={{ fontSize: 14, fontWeight: 700, color: "#0f172a" }}>Continue Editing</AiaText>
                    <AiaText sx={{ fontSize: 12.5, color: "#64748b", mt: 0.5 }}>Auto-populate the mapping builder with parsed tables and columns from this file.</AiaText>
                  </AiaButton>
                  <AiaButton
                    variant="text"
                    onClick={handleUseAsLearning}
                    sx={{ width: "100%", textTransform: "none", display: "block", px: 2.25, py: 2, borderRadius: "14px", border: "1px solid #dbe2ea", textAlign: "left", "&:hover": { borderColor: "var(--aia-button-color)", bgcolor: "#fafbff" } }}
                  >
                    <AiaText sx={{ fontSize: 14, fontWeight: 700, color: "#0f172a" }}>Use as Highest-Priority Learning</AiaText>
                    <AiaText sx={{ fontSize: 12.5, color: "#64748b", mt: 0.5 }}>AI agents will use 80-90% of patterns from this document for all future recommendations and answers.</AiaText>
                  </AiaButton>
                </AiaStack>
              )}
            </AiaBox>
          ) : (
          <AiaBox sx={{ px: 4, py: 3.5 }}>
            <AiaStack spacing={2}>
              {OPTIONS.map((option) => {
                const selected = selectedMode === option.id;

                return (
                  <AiaButton
                    key={option.id}
                    variant="text"
                    onClick={() => setSelectedMode(option.id)}
                    data-tour={
                      option.id === "sql"
                        ? TOUR_TARGETS.newMappingSqlUpload
                        : option.id === "excel"
                          ? TOUR_TARGETS.newMappingExcelUpload
                          : TOUR_TARGETS.newMappingManual
                    }
                    sx={{
                      width: "100%",
                      textTransform: "none",
                      display: "block",
                      px: 0,
                      py: 0,
                      borderRadius: "18px",
                      border: selected
                        ? "1px solid var(--aia-button-color)"
                        : "1px solid #dbe2ea",
                      boxShadow: selected ? "none" : "0 2px 8px rgba(15, 23, 42, 0.06)",
                      backgroundColor: "#fff",
                      "&:hover": {
                        backgroundColor: "#fff",
                        borderColor: selected ? "var(--aia-button-color)" : "#cbd5e1",
                      },
                    }}
                  >
                    <AiaBox
                      sx={{
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 2,
                        px: 2.25,
                        py: 2.1,
                        textAlign: "left",
                        width: "100%",
                      }}
                    >
                      <AiaBox
                        sx={{
                          width: 54,
                          height: 54,
                          borderRadius: "16px",
                          border: "1px solid #e5e7eb",
                          backgroundColor: "#f8fafc",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        {option.icon}
                      </AiaBox>

                      <AiaBox sx={{ minWidth: 0, flex: 1, overflow: "hidden" }}>
                        <AiaStack
                          direction="row"
                          spacing={1}
                          useFlexGap
                          sx={{ alignItems: "center", flexWrap: "wrap" }}
                        >
                          <AiaText sx={{ fontSize: 15, fontWeight: 800, color: "#0f172a" }}>
                            {option.label}
                          </AiaText>
                          {option.badge ? (
                            <AiaBox
                              component="span"
                              sx={{
                                px: 1,
                                py: 0.35,
                                borderRadius: "999px",
                                backgroundColor: option.badgeBg,
                                color: option.badgeFg,
                                fontSize: 11,
                                fontWeight: 800,
                                letterSpacing: "0.02em",
                              }}
                            >
                              {option.badge}
                            </AiaBox>
                          ) : null}
                        </AiaStack>
                        <AiaText
                          sx={{
                            mt: 0.85,
                            fontSize: 13.5,
                            lineHeight: 1.55,
                            color: "#64748b",
                            display: "block",
                            overflowWrap: "anywhere",
                            wordBreak: "break-word",
                          }}
                        >
                          {option.description}
                        </AiaText>
                      </AiaBox>

                      <AiaBox
                        aria-hidden
                        sx={{
                          width: 26,
                          height: 26,
                          borderRadius: "50%",
                          border: selected
                            ? "7px solid var(--aia-button-color)"
                            : "2px solid #cbd5e1",
                          backgroundColor: selected ? "#fff" : "transparent",
                          boxShadow: selected ? "0 0 0 4px var(--aia-button-color)" : "none",
                          flexShrink: 0,
                          alignSelf: "center",
                          ml: 0.5,
                        }}
                      />
                    </AiaBox>
                  </AiaButton>
                );
              })}
            </AiaStack>
          </AiaBox>
          )}

          {selectedMode === "manual" && projectId && !uploadResult && (
            <AiaBox
              sx={{
                px: 4,
                pb: 3,
                display: "flex",
                flexDirection: "column",
                gap: 2,
              }}
            >
              <AiaInput
                label="Mapping Name"
                value={mappingName}
                onChange={setMappingName}
                placeholder="e.g. Customer Orders → DW_ORDERS"
                fullWidth
              />
              <AiaInput
                label="Description (optional)"
                value={mappingDescription}
                onChange={setMappingDescription}
                placeholder="Briefly describe the purpose of this mapping"
                multiline
                minRows={2}
                maxRows={4}
                fullWidth
              />
            </AiaBox>
          )}

          {!uploadResult && (
          <AiaBox
            sx={{
              px: 4,
              py: 2.25,
              borderTop: "1px solid #edf2f7",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 2,
              backgroundColor: "#fff",
            }}
          >
            <AiaText
              sx={{
                fontSize: 13.5,
                color: "#94a3b8",
                fontWeight: 500,
                flex: 1,
                minWidth: 0,
                pr: 2,
                overflowWrap: "anywhere",
                wordBreak: "break-word",
              }}
            >
              {selectedOption
                ? selectedOption.description
                : "Select an option above to continue"}
            </AiaText>

            <AiaStack direction="row" spacing={1.25} sx={{ flexShrink: 0 }}>
              <AiaButton
                variant="outlined"
                rounded="lg"
                size="medium"
                onClick={handleClose}
                data-tour={TOUR_TARGETS.newMappingCancel}
                sx={{
                  minWidth: 108,
                  height: 44,
                  borderRadius: "14px",
                  color: "#334155",
                  borderColor: "#dbe2ea",
                  fontSize: 14,
                  fontWeight: 700,
                }}
              >
                Cancel
              </AiaButton>
              <AiaButton
                variant="contained"
                color="primary"
                rounded="lg"
                size="medium"
                endIcon={<ArrowForwardRoundedIcon sx={{ fontSize: 16 }} />}
                disabled={
                  !selectedMode ||
                  (selectedMode === "manual" && !!projectId && !mappingName.trim())
                }
                onClick={handleProceed}
                sx={{
                  minWidth: 156,
                  height: 44,
                  borderRadius: "14px",
                  fontSize: 14,
                  fontWeight: 800,
                }}
              >
                {selectedMode === "manual" ? "Build Mapping" : "Choose File"}
              </AiaButton>
            </AiaStack>
          </AiaBox>
          )}
        </AiaBox>
      </AiaBox>

      <input
        ref={sqlInputRef}
        type="file"
        accept=".sql,text/sql,application/sql"
        hidden
        onChange={(e) => handleFileUpload(e, "sql")}
      />
      <input
        ref={excelInputRef}
        type="file"
        accept=".xlsx,.xls,.csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
        hidden
        onChange={(e) => handleFileUpload(e, "excel")}
      />
    </>
  );
}
