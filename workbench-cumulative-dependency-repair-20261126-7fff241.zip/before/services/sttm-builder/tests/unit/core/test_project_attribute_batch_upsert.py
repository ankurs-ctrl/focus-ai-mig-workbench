from types import SimpleNamespace
import json

import pytest

from app.core.exceptions import AppValidationError
from app.core.project_service import ProjectService
from app.schema.project import (
    ProjectAttributeBatchUpsertRequest,
    ProjectAttributeCreateRequest,
    ProjectAttributeRecord,
)


class _Row:
    def __init__(self, values):
        self._values = values

    def as_dict(self):
        return self._values


class _Query:
    def __init__(self, rows):
        self._rows = rows

    def collect(self):
        return self._rows


class _Session:
    def __init__(self, rows):
        self.rows = rows
        self.calls = []

    def sql(self, query, params=None):
        self.calls.append((query, params))
        if "SELECT ATTRIBUTE_NAME, ATTRIBUTE_TYPE, ATTRIBUTE_VALUE" in query:
            return _Query([_Row(row) for row in self.rows])
        return _Query([])


def _service(rows):
    service = ProjectService.__new__(ProjectService)
    service._session = _Session(rows)
    service._settings = SimpleNamespace(
        snowflake_project_attributes_table="DB.META.TBL_PROJECT_ATTRIBUTES",
        qualify_metadata_object_name=lambda value: value,
    )
    service.ensure_storage_exists = lambda: None
    service.get_project = lambda _project_id: SimpleNamespace(project_id="project-1")
    service.list_project_attributes = lambda project_id: [
        ProjectAttributeRecord(
            attribute_id="attribute-1",
            project_id=project_id,
            attribute_name="FirmId",
            attribute_type="VARCHAR",
            attribute_value="001",
        )
    ]
    return service


def _payload(value="001"):
    return ProjectAttributeBatchUpsertRequest(
        attributes=[
            ProjectAttributeCreateRequest(
                attribute_name="FirmId",
                attribute_type="varchar",
                attribute_value=value,
            )
        ]
    )


def test_batch_upsert_accepts_existing_identical_value_without_merge() -> None:
    service = _service([{"ATTRIBUTE_NAME": "FirmId", "ATTRIBUTE_TYPE": "VARCHAR", "ATTRIBUTE_VALUE": "001"}])

    result = service.upsert_project_attributes("project-1", _payload(), user_id="USER")

    assert result.created_count == 0
    assert result.unchanged_count == 1
    assert not any("MERGE INTO" in query for query, _params in service._session.calls)


def test_batch_upsert_rejects_existing_conflicting_value() -> None:
    service = _service([{"ATTRIBUTE_NAME": "FirmId", "ATTRIBUTE_TYPE": "VARCHAR", "ATTRIBUTE_VALUE": "999"}])

    with pytest.raises(AppValidationError, match="different value"):
        service.upsert_project_attributes("project-1", _payload(), user_id="USER")


def test_batch_upsert_rejects_existing_conflicting_type() -> None:
    service = _service([
        {"ATTRIBUTE_NAME": "FirmId", "ATTRIBUTE_TYPE": "NUMBER", "ATTRIBUTE_VALUE": "001"}
    ])

    with pytest.raises(AppValidationError, match="different value"):
        service.upsert_project_attributes("project-1", _payload(), user_id="USER")


def test_batch_upsert_rejects_duplicate_active_records() -> None:
    service = _service([
        {
            "ATTRIBUTE_NAME": "FirmId",
            "ATTRIBUTE_TYPE": "VARCHAR",
            "ATTRIBUTE_VALUE": "001",
            "NAME_COUNT": 2,
        }
    ])

    with pytest.raises(AppValidationError, match="duplicate active records"):
        service.upsert_project_attributes("project-1", _payload(), user_id="USER")


def test_batch_upsert_inserts_all_missing_values_with_one_merge() -> None:
    service = _service([])

    result = service.upsert_project_attributes("project-1", _payload(), user_id="USER")

    merge_calls = [call for call in service._session.calls if "MERGE INTO" in call[0]]
    assert result.created_count == 1
    assert result.unchanged_count == 0
    assert len(merge_calls) == 1
    assert "FLATTEN(INPUT => PARSE_JSON(?))" in merge_calls[0][0]


def test_create_project_attribute_rejects_an_existing_value() -> None:
    service = _service([])

    def sql(query, params=None):
        service._session.calls.append((query, params))
        if "TRIM(ATTRIBUTE_VALUE)" in query:
            return _Query([_Row({"ATTRIBUTE_NAME": "TransactionFirmID"})])
        return _Query([])

    service._session.sql = sql

    with pytest.raises(AppValidationError, match="already stored as TransactionFirmID"):
        service.create_project_attribute(
            "project-1",
            ProjectAttributeCreateRequest(
                attribute_name="BackupOwnerID",
                attribute_type="VARCHAR",
                attribute_value=" 001G00000 ",
            ),
            user_id="USER",
        )

    assert not any("INSERT INTO" in query for query, _params in service._session.calls)


def test_batch_upsert_rejects_a_new_name_with_an_existing_value() -> None:
    service = _service([])

    def sql(query, params=None):
        service._session.calls.append((query, params))
        if "TRIM(ATTRIBUTE_VALUE) AS ATTRIBUTE_VALUE" in query:
            return _Query([_Row({"ATTRIBUTE_NAME": "TransactionFirmID", "ATTRIBUTE_VALUE": "001"})])
        return _Query([])

    service._session.sql = sql

    with pytest.raises(AppValidationError, match="already stored as TransactionFirmID"):
        service.upsert_project_attributes(
            "project-1",
            ProjectAttributeBatchUpsertRequest(
                attributes=[
                    ProjectAttributeCreateRequest(
                        attribute_name="BackupOwnerID",
                        attribute_type="VARCHAR",
                        attribute_value="001",
                    )
                ]
            ),
            user_id="USER",
        )

    assert not any("MERGE INTO" in query for query, _params in service._session.calls)


def test_batch_upsert_rejects_two_new_names_with_the_same_value() -> None:
    service = _service([])

    with pytest.raises(AppValidationError, match="already stored as BackupOwnerID, TransactionFirmID"):
        service.upsert_project_attributes(
            "project-1",
            ProjectAttributeBatchUpsertRequest(
                attributes=[
                    ProjectAttributeCreateRequest(
                        attribute_name="TransactionFirmID",
                        attribute_type="VARCHAR",
                        attribute_value="001",
                    ),
                    ProjectAttributeCreateRequest(
                        attribute_name="BackupOwnerID",
                        attribute_type="VARCHAR",
                        attribute_value="001",
                    ),
                ]
            ),
            user_id="USER",
        )


def test_batch_upsert_existing_lookup_binds_normalized_name_list() -> None:
    service = _service([])

    service.upsert_project_attributes("project-1", _payload(), user_id="USER")

    lookup = next(
        call
        for call in service._session.calls
        if "SELECT ATTRIBUTE_NAME, ATTRIBUTE_TYPE, ATTRIBUTE_VALUE" in call[0]
    )
    assert json.loads(lookup[1][0]) == ["FIRMID"]
    assert "SELECT UPPER(value::STRING)" in lookup[0]