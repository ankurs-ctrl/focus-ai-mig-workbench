"""Verified relationship graph over current table contracts.

Join candidates are generated from the contracts themselves (no table names
are known in advance), verified against the data, and scored so that the
agent can apply an unambiguous join on its own and ask only when the evidence
genuinely does not single one out.

Generators
    * foreign-key name rule: ``<STEM>_ID`` refers to a table whose singular
      name is STEM, or ends with ``_STEM`` (a qualified lookup such as
      ``CONTACT_CATEGORIES`` for ``CATEGORY_ID``), on that table's key;
    * polymorphic association: a ``<X>_ID`` + ``<X>_TYPE`` column pair; each
      stored type value names its parent table and becomes a literal filter;
    * external evidence (registry, precedent SQL, learnings, user answers) is
      merged in as additional evidence on the same edge.

Verification measures, per candidate, how many distinct child key values
exist in the parent (``coverage``) and whether the parent key is unique.

Scoring treats one child column as having exactly one true parent. Each
candidate's likelihood is ``name_prior * coverage ** orphan_sensitivity``; the
likelihoods of the competing parents of the same child column are normalized
into a probability, which is the confidence shown to the user and used for
auto-resolution together with the margin to the runner-up.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")

DEFAULT_NAME_PRIORS: dict[str, float] = {
    # <STEM>_ID where the parent's singular name is exactly STEM.
    "exact_stem": 0.9,
    # Parent is STEM qualified by a prefix the child table shares
    # (CONTACTS.CATEGORY_ID -> CONTACT_CATEGORIES).
    "qualified_shared": 0.9,
    # Parent is STEM qualified by a prefix the child table does not share
    # (ACTIVITIES.CATEGORY_ID -> CONTACT_CATEGORIES).
    "qualified_foreign": 0.35,
    # A polymorphic <X>_ID whose <X>_TYPE value names the parent.
    "polymorphic": 0.9,
    # Identically named key columns that are each table's own key (ID = ID).
    "shared_primary_key": 0.05,
    # Candidates only asserted by an external source, with no name structure;
    # the external evidence itself carries the weight.
    "external_only": 0.05,
}
# Prior contributed by external evidence, combined with the name prior by noisy-OR.
DEFAULT_EVIDENCE_WEIGHTS: dict[str, float] = {
    "declared_fk": 0.99,
    "user_confirmed": 0.98,
    "learning": 0.9,
    "published_precedent": 0.9,
    "structural_precedent": 0.8,
    "sql_parsed": 0.75,
    "registry_inferred": 0.4,
}


@dataclass(frozen=True)
class LiteralFilter:
    """``<side table>.<column> = '<value>'`` applied inside the join."""

    side: str  # "left" or "right"
    column: str
    value: str
    operator: str = "="

    def to_dict(self) -> dict[str, str]:
        return {"side": self.side, "column": self.column, "operator": self.operator, "value": self.value}


@dataclass
class Evidence:
    kind: str
    confidence: float
    detail: dict[str, Any] = field(default_factory=dict)
    evidence_ids: list[str] = field(default_factory=list)


@dataclass
class RelationshipEdge:
    child_table: str
    child_column: str
    parent_table: str
    parent_column: str
    literal_filters: tuple[LiteralFilter, ...] = ()
    name_rule: str = "external_only"
    evidence: list[Evidence] = field(default_factory=list)
    verification: dict[str, Any] | None = None
    likelihood: float = 0.0
    confidence: float = 0.0
    margin: float = 0.0
    competitors: int = 0

    @property
    def slot(self) -> tuple[str, str, tuple[tuple[str, str, str], ...]]:
        """The child column (and filter) whose true parent is being decided."""
        return (self.child_table, self.child_column,
                tuple(sorted((item.side, item.column, item.value) for item in self.literal_filters)))

    @property
    def key(self) -> str:
        payload = json.dumps([self.child_table, self.child_column, self.parent_table, self.parent_column,
                              [item.to_dict() for item in self.literal_filters]], sort_keys=True)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20]

    @property
    def verified(self) -> bool:
        return bool(self.verification and self.verification.get("status") == "verified")

    def to_relationship(self) -> dict[str, Any]:
        """The plan/join-research relationship shape (child is the left side)."""
        relationship: dict[str, Any] = {
            "left_table": self.child_table,
            "right_table": self.parent_table,
            "join_type": "LEFT",
            "conditions": [{"left_column": self.child_column, "right_column": self.parent_column, "operator": "="}],
            "source": "RELATIONSHIP_GRAPH",
            "confidence": round(self.confidence, 4),
            "confidence_margin": round(self.margin, 4),
            "evidence": [
                {"kind": item.kind, "confidence": round(item.confidence, 4), **item.detail,
                 **({"evidence_ids": item.evidence_ids} if item.evidence_ids else {})}
                for item in self.evidence
            ],
        }
        if self.literal_filters:
            relationship["literal_filters"] = [item.to_dict() for item in self.literal_filters]
        if self.verification:
            relationship["verification"] = dict(self.verification)
        return relationship


def singular(name: str) -> str:
    """Singular form of an upper-case identifier's last word."""
    if name.endswith("IES") and len(name) > 3:
        return name[:-3] + "Y"
    if re.search(r"(SS|SH|CH|X|Z)ES$", name) or re.search(r"USES$", name):
        return name[:-2]
    if name.endswith("S") and not name.endswith("SS") and not name.endswith("US") and len(name) > 1:
        return name[:-1]
    return name


def _leaf(fqn: str) -> str:
    return fqn.rsplit(".", 1)[-1].upper()


def _tokens(name: str) -> set[str]:
    return {singular(part) for part in name.upper().split("_") if part}


def _key_column(contract: dict[str, Any]) -> str | None:
    keys = [str(value) for value in contract.get("key_columns") or []]
    if len(keys) == 1:
        return keys[0]
    columns = {str(value).upper(): str(value) for value in contract.get("columns") or []}
    return columns.get("ID") if not keys else None


def _type_families(contract: dict[str, Any], family: Callable[[str], str]) -> dict[str, str]:
    return {str(item.get("name") or "").upper(): family(str(item.get("type") or ""))
            for item in contract.get("column_contracts") or [] if isinstance(item, dict)}


def _name_rule(child_table: str, stem: str, parent_table: str) -> str | None:
    parent = singular(_leaf(parent_table))
    if parent == stem:
        return "exact_stem"
    if parent.endswith(f"_{stem}"):
        qualifier = _tokens(parent[: -len(stem) - 1])
        return "qualified_shared" if qualifier <= _tokens(_leaf(child_table)) else "qualified_foreign"
    return None


def fk_name_candidates(
    contracts: dict[str, dict[str, Any]],
    type_family: Callable[[str], str],
) -> list[RelationshipEdge]:
    """``<STEM>_ID`` columns pointing at the key of a table named STEM.

    A junction table (one that itself references two or more tables) is an
    association, not an entity: it is never a *qualified-name* parent, so
    ``ACTIVITIES_CONTACTS`` does not compete with ``CONTACTS`` for every
    ``CONTACT_ID``.
    """
    families = {table: _type_families(contract, type_family) for table, contract in contracts.items()}
    keys = {table: _key_column(contract) for table, contract in contracts.items()}
    edges: list[RelationshipEdge] = []
    for child, contract in contracts.items():
        for column in contract.get("columns") or []:
            name = str(column).upper()
            if not name.endswith("_ID") or name == str(keys.get(child) or "").upper():
                continue
            stem = name[:-3]
            for parent in contracts:
                parent_key = keys.get(parent)
                if parent == child or not parent_key:
                    continue
                rule = _name_rule(child, stem, parent)
                if rule is None:
                    continue
                if families[child].get(name) != families[parent].get(parent_key.upper()):
                    continue
                edges.append(RelationshipEdge(child_table=child, child_column=str(column), parent_table=parent,
                                              parent_column=parent_key, name_rule=rule))
    junctions = set(junction_tables(edge for edge in edges if edge.name_rule == "exact_stem"))
    return [edge for edge in edges
            if not (edge.name_rule.startswith("qualified") and edge.parent_table in junctions)]


def polymorphic_slots(contracts: dict[str, dict[str, Any]]) -> list[tuple[str, str, str]]:
    """``(table, id_column, type_column)`` for every ``<X>_ID`` + ``<X>_TYPE`` pair."""
    slots = []
    for table, contract in contracts.items():
        columns = {str(value).upper(): str(value) for value in contract.get("columns") or []}
        for name, original in columns.items():
            if name.endswith("_ID") and f"{name[:-3]}_TYPE" in columns:
                slots.append((table, original, columns[f"{name[:-3]}_TYPE"]))
    return slots


def polymorphic_candidates(
    slots: Iterable[tuple[str, str, str]],
    type_values: dict[tuple[str, str], list[str]],
    contracts: dict[str, dict[str, Any]],
) -> list[RelationshipEdge]:
    """Map each stored type value (``Crm::Contact``) to the table it names."""
    edges: list[RelationshipEdge] = []
    for table, id_column, type_column in slots:
        for value in type_values.get((table, type_column), []):
            words = [singular(part) for part in re.split(r"[^A-Za-z0-9]+", str(value).upper()) if part]
            if not words:
                continue
            for parent, contract in contracts.items():
                parent_key = _key_column(contract)
                if parent == table or not parent_key:
                    continue
                leaf = singular(_leaf(parent))
                if leaf == words[-1] or leaf == "_".join(words[-2:]):
                    edges.append(RelationshipEdge(
                        child_table=table, child_column=id_column, parent_table=parent, parent_column=parent_key,
                        literal_filters=(LiteralFilter("left", type_column, str(value)),), name_rule="polymorphic",
                    ))
    return edges


def junction_tables(edges: Iterable[RelationshipEdge]) -> dict[str, list[str]]:
    """Tables holding name-rule references to two or more different tables."""
    parents: dict[str, set[str]] = {}
    for edge in edges:
        if edge.name_rule != "external_only":
            parents.setdefault(edge.child_table, set()).add(edge.parent_table)
    return {table: sorted(targets) for table, targets in parents.items() if len(targets) >= 2}


def _fqn(value: Any) -> str:
    if isinstance(value, dict):
        value = value.get("qualified_name") or ".".join(
            str(value.get(key) or "") for key in ("database", "schema", "table"))
    return ".".join(part.strip().strip('"').upper() for part in str(value or "").split("."))


def _condition_columns(condition: dict[str, Any]) -> tuple[str, str]:
    left = condition.get("left_column") or condition.get("fk_column") or condition.get("source_column") \
        or condition.get("from_column")
    right = condition.get("right_column") or condition.get("pk_column") or condition.get("target_column") \
        or condition.get("related_column")
    return str(left or ""), str(right or "")


def merge_external(
    edges: list[RelationshipEdge],
    external: Iterable[tuple[str, dict[str, Any]]],
    contracts: dict[str, dict[str, Any]],
) -> list[RelationshipEdge]:
    """Attach external evidence to matching edges; add edges only external sources assert.

    ``external`` items are ``(kind, relationship)`` in any of the relationship
    shapes used by the Workbench (plan relationships, registry items with
    ``TableRef`` tables, ``fk_column``/``pk_column`` mappings). Orientation is
    normalized so that the side whose column is its own table key is the parent.
    """
    by_key = {(edge.child_table, edge.child_column.upper(), edge.parent_table, edge.parent_column.upper(),
               tuple(sorted((f.side, f.column.upper(), f.value) for f in edge.literal_filters))): edge
              for edge in edges}
    keys = {table: str(_key_column(contract) or "").upper() for table, contract in contracts.items()}
    # Precedent SQL spells columns as written (`n.noteable_id`); the verification
    # SQL quotes them, so every external column takes its contract spelling.
    names = {table: {str(value).upper(): str(value) for value in contract.get("columns") or []}
             for table, contract in contracts.items()}
    for kind, relationship in external:
        conditions = [item for item in relationship.get("conditions") or relationship.get("column_mappings") or []
                      if isinstance(item, dict)]
        if len(conditions) != 1:
            continue
        left = _fqn(relationship.get("left_table") or relationship.get("source_table") or relationship.get("from_table"))
        right = _fqn(relationship.get("right_table") or relationship.get("target_table")
                     or relationship.get("referenced_table") or relationship.get("related_table"))
        left_column, right_column = _condition_columns(conditions[0])
        if left not in contracts or right not in contracts or not left_column or not right_column:
            continue
        if names[left] and names[right]:
            left_column = names[left].get(left_column.upper())
            right_column = names[right].get(right_column.upper())
            if not left_column or not right_column:
                continue  # the column is not in the current table
        filters = []
        for item in relationship.get("literal_filters") or []:
            if isinstance(item, dict) and item.get("column") and item.get("value") is not None:
                side = str(item.get("side") or "left")
                column = names[left if side == "left" else right].get(str(item["column"]).upper(), str(item["column"]))
                filters.append(LiteralFilter(side, column, str(item["value"])))
        if right_column.upper() == keys.get(right) or left_column.upper() != keys.get(left):
            child, child_column, parent, parent_column = left, left_column, right, right_column
        else:
            child, child_column, parent, parent_column = right, right_column, left, left_column
            filters = [LiteralFilter("right" if item.side == "left" else "left", item.column, item.value)
                       for item in filters]
        filter_key = tuple(sorted((f.side, f.column.upper(), f.value) for f in filters))
        key = (child, child_column.upper(), parent, parent_column.upper(), filter_key)
        edge = by_key.get(key)
        if edge is None:
            shared_key = child_column.upper() == keys.get(child) and parent_column.upper() == keys.get(parent)
            edge = RelationshipEdge(child_table=child, child_column=child_column, parent_table=parent,
                                    parent_column=parent_column, literal_filters=tuple(filters),
                                    name_rule="shared_primary_key" if shared_key else "external_only")
            by_key[key] = edge
            edges.append(edge)
        raw_confidence = relationship.get("confidence")
        if isinstance(raw_confidence, (int, float)):
            confidence = float(raw_confidence)
        else:
            confidence = {"HIGH": 0.9, "MEDIUM": 0.6, "LOW": 0.3}.get(str(raw_confidence or "").upper(), 1.0)
        edge.evidence.append(Evidence(
            kind=kind, confidence=confidence,
            detail={"source": str(relationship.get("source") or kind)},
            evidence_ids=[str(value) for value in relationship.get("evidence_ids") or []],
        ))
    return edges


def score_edges(
    edges: list[RelationshipEdge],
    *,
    name_priors: dict[str, float] | None = None,
    evidence_weights: dict[str, float] | None = None,
    orphan_sensitivity: float = 20.0,
    duplicate_parent_penalty: float = 0.5,
    chance_floor: float = 0.05,
) -> list[RelationshipEdge]:
    """Posterior probability that each candidate is the true parent of its child column.

    Hypotheses for one child column (slot): each candidate parent H_i, or
    H_0 "none of them". ``P(H_i)`` is the name prior combined with external
    evidence by noisy-OR; ``P(H_0) = prod(1 - P(H_i))``.

    * Under H_i nearly every child value exists in parent i; orphans are
      evidence against it: ``L_i = coverage_i ** orphan_sensitivity``. Competing
      parents often share key values, so their overlaps are not independent
      and are not used against H_i.
    * Under H_0 every observed overlap is coincidence. The chance of an
      overlap is estimated from the parent key's density over its numeric
      range: ``L_0 = prod(min(1, chance_i / coverage_i) ** orphan_sensitivity)``.
      Dense sequential surrogate keys overlap by chance, so their coverage
      barely moves H_0; overlap with a sparse key is hard to explain away.

    Weights are normalized in log space. Unverified candidates keep their prior.
    """
    priors = {**DEFAULT_NAME_PRIORS, **(name_priors or {})}
    weights = {**DEFAULT_EVIDENCE_WEIGHTS, **(evidence_weights or {})}
    prior_of: dict[int, float] = {}
    for edge in edges:
        prior = priors.get(edge.name_rule, priors["external_only"])
        remaining = 1.0 - prior
        # Several sources of the same kind (one registry claim reached through
        # two lookups) are one piece of evidence, not independent ones.
        strongest: dict[str, float] = {}
        for item in edge.evidence:
            if item.kind == "registry_inferred" and edge.name_rule == "shared_primary_key":
                # The registry infers from name equality plus value overlap;
                # for two tables' own surrogate keys both are coincidental.
                continue
            strongest[item.kind] = max(strongest.get(item.kind, 0.0), max(0.0, min(1.0, item.confidence)))
        for kind, confidence in strongest.items():
            remaining *= 1.0 - min(1.0, weights.get(kind, 0.3) * confidence)
        prior_of[id(edge)] = min(0.999, 1.0 - remaining)
    groups: dict[Any, list[RelationshipEdge]] = {}
    for edge in edges:
        groups.setdefault(edge.slot, []).append(edge)
    for group in groups.values():
        none_log = sum(math.log(max(1.0 - prior_of[id(edge)], 1e-12)) for edge in group)
        logs: dict[int, float | None] = {}
        for edge in group:
            log_weight: float | None = math.log(prior_of[id(edge)])
            if edge.verified:
                coverage = max(float(edge.verification.get("coverage") or 0.0), 1e-9)
                chance = max(float(chance_floor), float(edge.verification.get("chance_coverage") or 0.0))
                log_weight += orphan_sensitivity * math.log(coverage)
                if not edge.verification.get("parent_key_unique", True):
                    log_weight += math.log(max(duplicate_parent_penalty, 1e-9))
                none_log += orphan_sensitivity * min(0.0, math.log(chance) - math.log(coverage))
            elif edge.verification is not None:
                log_weight = None  # verification ran and found no overlap or the parent was unusable
            logs[id(edge)] = log_weight
        top = max([none_log, *(value for value in logs.values() if value is not None)])
        weights_of = {key: (math.exp(value - top) if value is not None else 0.0) for key, value in logs.items()}
        none = math.exp(none_log - top)
        total = sum(weights_of.values()) + none
        for edge in group:
            edge.likelihood = weights_of[id(edge)]
            edge.confidence = edge.likelihood / total
        for edge in group:
            rivals = [other.confidence for other in group if other is not edge]
            edge.margin = edge.confidence - max([*rivals, none / total])
            edge.competitors = len(group) - 1
    return edges


def auto_resolvable(edge: RelationshipEdge, *, confidence: float, margin: float, min_coverage: float = 0.9) -> bool:
    """An edge may be applied without asking only when the data verified it.

    Beyond confidence and margin, the join must not orphan many child rows
    (``min_coverage``) and the parent key must be unique: a non-unique parent
    multiplies the child's rows, a design decision for the user.
    """
    return (edge.verified and edge.name_rule != "shared_primary_key"
            and bool(edge.verification.get("parent_key_unique"))
            and float(edge.verification.get("coverage") or 0.0) >= min_coverage
            and edge.confidence >= confidence and edge.margin >= margin)


def verification_sql(edge: RelationshipEdge, sample_limit: int) -> tuple[str, list[Any]]:
    """One row of coverage and uniqueness metrics for a candidate edge.

    Child key values are a deterministic sample (``ORDER BY HASH``) of the
    distinct non-null values; parent uniqueness is measured on the full key.
    """
    def quoted(fqn: str) -> str:
        parts = fqn.split(".")
        if len(parts) != 3 or not all(_IDENTIFIER.fullmatch(part) for part in parts):
            raise ValueError(f"Unsafe table identifier: {fqn}")
        return ".".join(f'"{part}"' for part in parts)

    for column in (edge.child_column, edge.parent_column, *(item.column for item in edge.literal_filters)):
        if not _IDENTIFIER.fullmatch(column):
            raise ValueError(f"Unsafe column identifier: {column}")
    child_filters = [item for item in edge.literal_filters if item.side == "left"]
    where = " AND ".join([f'"{edge.child_column}" IS NOT NULL', *(f'"{item.column}" = ?' for item in child_filters)])
    params: list[Any] = [item.value for item in child_filters]
    sql = (
        f"WITH child AS (SELECT K FROM (SELECT DISTINCT \"{edge.child_column}\" AS K FROM {quoted(edge.child_table)} "
        f"WHERE {where}) ORDER BY HASH(K) LIMIT {int(sample_limit)}), "
        f"parent AS (SELECT \"{edge.parent_column}\" AS K, COUNT(*) AS N FROM {quoted(edge.parent_table)} "
        f"WHERE \"{edge.parent_column}\" IS NOT NULL GROUP BY 1), "
        "span AS (SELECT MIN(TRY_TO_DOUBLE(TO_VARCHAR(K))) AS LO, MAX(TRY_TO_DOUBLE(TO_VARCHAR(K))) AS HI FROM child), "
        "stats AS (SELECT COUNT(*) AS PV, COALESCE(MAX(N), 0) AS MAXN FROM parent) "
        "SELECT ? AS EDGE_KEY, (SELECT COUNT(*) FROM child) AS CHILD_VALUES, "
        "(SELECT COUNT(*) FROM child JOIN parent ON parent.K = child.K) AS MATCHED_VALUES, "
        "stats.PV AS PARENT_VALUES, stats.MAXN AS MAX_PARENT_ROWS, span.LO AS CHILD_MIN, span.HI AS CHILD_MAX, "
        "(SELECT COUNT(*) FROM parent WHERE TRY_TO_DOUBLE(TO_VARCHAR(parent.K)) BETWEEN span.LO AND span.HI) "
        "AS PARENT_IN_CHILD_SPAN FROM stats CROSS JOIN span"
    )
    return sql, [*params, edge.key]


def apply_verification(edge: RelationshipEdge, row: dict[str, Any], *, min_child_values: int) -> None:
    child_values = int(row.get("CHILD_VALUES") or 0)
    matched = int(row.get("MATCHED_VALUES") or 0)
    parent_values = int(row.get("PARENT_VALUES") or 0)
    max_parent_rows = int(row.get("MAX_PARENT_ROWS") or 0)
    low, high = row.get("CHILD_MIN"), row.get("CHILD_MAX")
    # Coverage expected if the column did NOT reference this parent: the
    # chance that a value in the child's own numeric span is a parent key,
    # i.e. how densely parent keys fill that span. Surrogate keys cluster at
    # low values, so a dense span makes any overlap uninformative.
    chance = 0.0
    if low is not None and high is not None and float(high) >= float(low):
        chance = min(1.0, int(row.get("PARENT_IN_CHILD_SPAN") or 0) / (float(high) - float(low) + 1.0))
    status = "verified" if child_values >= min_child_values and parent_values > 0 and matched > 0 else "no_evidence"
    edge.verification = {
        "status": status,
        "coverage": round(matched / child_values, 6) if child_values else 0.0,
        "chance_coverage": round(chance, 6),
        "child_values_sampled": child_values,
        "matched_values": matched,
        "parent_values": parent_values,
        "parent_key_unique": max_parent_rows <= 1,
        "sample_method": "distinct child keys ORDER BY HASH",
    }


def verify_edges(
    sql: Callable[..., Any],
    edges: list[RelationshipEdge],
    *,
    sample_limit: int,
    min_child_values: int,
    batch_size: int,
) -> int:
    """Verify edges against the data in ``UNION ALL`` batches; returns queries issued."""
    queries = 0
    pending = [edge for edge in edges if edge.verification is None]
    for start in range(0, len(pending), max(1, batch_size)):
        batch = pending[start:start + max(1, batch_size)]
        statements, params = [], []
        for edge in batch:
            statement, values = verification_sql(edge, sample_limit)
            statements.append(f"SELECT * FROM ({statement})")
            params.extend(values)
        rows = sql("\nUNION ALL\n".join(statements), params=params).collect()
        queries += 1
        by_key = {}
        for row in rows:
            data = row.as_dict() if hasattr(row, "as_dict") else dict(row)
            by_key[str(data.get("EDGE_KEY"))] = data
        for edge in batch:
            apply_verification(edge, by_key.get(edge.key) or {}, min_child_values=min_child_values)
    return queries


def polymorphic_type_values(
    sql: Callable[..., Any],
    slots: Iterable[tuple[str, str, str]],
    *,
    limit: int,
) -> dict[tuple[str, str], list[str]]:
    """Stored type values of each polymorphic slot, most frequent first (bounded)."""
    values: dict[tuple[str, str], list[str]] = {}
    for table, _id_column, type_column in slots:
        parts = table.split(".")
        if len(parts) != 3 or not all(_IDENTIFIER.fullmatch(part) for part in [*parts, type_column]):
            raise ValueError(f"Unsafe identifier: {table}.{type_column}")
        quoted = ".".join(f'"{part}"' for part in parts)
        rows = sql(
            f'SELECT "{type_column}" AS V, COUNT(*) AS N FROM {quoted} WHERE "{type_column}" IS NOT NULL '
            f"GROUP BY 1 ORDER BY N DESC, V LIMIT {int(limit)}"
        ).collect()
        values[(table, type_column)] = [
            str((row.as_dict() if hasattr(row, "as_dict") else dict(row)).get("V")) for row in rows
        ]
    return values


PEAK_FACTOR = 0.2


def without_subsumed_unfiltered(edges: Iterable[RelationshipEdge]) -> list[RelationshipEdge]:
    """Drop an unfiltered join when a verified type-filtered version of it exists.

    A polymorphic ``<X>_ID`` holds keys of several parent types; without its
    ``<X>_TYPE`` discriminator the join also matches other types' rows whose
    ids happen to exist in the parent. The filtered edge is the relationship.
    """
    edges = list(edges)
    filtered = {(edge.child_table, edge.child_column.upper(), edge.parent_table, edge.parent_column.upper())
                for edge in edges if edge.literal_filters and edge.verified}
    return [edge for edge in edges if edge.literal_filters or
            (edge.child_table, edge.child_column.upper(), edge.parent_table, edge.parent_column.upper()) not in filtered]


def path_shape(driver: str, hops: Iterable[tuple[str, str, str]]) -> tuple[bool, int]:
    """``(coherent, peaks)`` for a path of ``(child_table, child_column, parent_table)`` hops.

    Walking from ``driver``, a table the path passes through is entered and
    left by one hop each:

    * child side of both hops through the *same* column: incoherent, one value
      cannot reference two parents (a polymorphic ``<X>_ID`` read as both
      ``Contact`` and ``Activity``);
    * child side of both hops through different columns: an association
      (junction) table, the intended many-to-many route;
    * parent side of both hops: a "peak", the two neighbours only share a
      parent row (activities and notes with the same category). The driver and
      target are then related incidentally, so such paths rank below direct or
      junction routes and are never recommended automatically.
    """
    node = driver
    previous: tuple[str, str] | None = None  # (role of ``node`` in the entering hop, its column)
    peaks = 0
    for child_table, child_column, parent_table in hops:
        if node == child_table:
            role, column, node_next = "child", child_column, parent_table
        elif node == parent_table:
            role, column, node_next = "parent", "", child_table
        else:
            return False, peaks
        if previous is not None:
            if previous[0] == role == "child" and previous[1] == column:
                return False, peaks
            if previous[0] == role == "parent":
                peaks += 1
        previous = ("parent" if role == "child" else "child", child_column if role == "parent" else "")
        node = node_next
    return True, peaks


def path_confidence(confidences: Iterable[float], peaks: int) -> float:
    product = 1.0
    for value in confidences:
        product *= float(value)
    return product * (PEAK_FACTOR ** peaks)


def best_paths(
    edges: Iterable[RelationshipEdge],
    driver: str,
    target: str,
    *,
    max_depth: int = 4,
    limit: int = 3,
) -> list[tuple[float, list[RelationshipEdge]]]:
    """Most probable coherent join paths from ``driver`` to ``target`` (edges are undirected).

    Path confidence is the product of edge confidences, discounted per
    shared-parent peak (see ``path_shape``); a path never revisits a table.
    """
    adjacency: dict[str, list[RelationshipEdge]] = {}
    for edge in edges:
        if edge.confidence <= 0:
            continue
        adjacency.setdefault(edge.child_table, []).append(edge)
        adjacency.setdefault(edge.parent_table, []).append(edge)
    results: list[tuple[float, list[RelationshipEdge]]] = []

    def walk(node: str, visited: set[str], path: list[RelationshipEdge]) -> None:
        if node == target and path:
            coherent, peaks = path_shape(driver, [(e.child_table, e.child_column, e.parent_table) for e in path])
            if coherent:
                results.append((path_confidence([e.confidence for e in path], peaks), list(path)))
            return
        if len(path) >= max_depth:
            return
        for edge in adjacency.get(node, []):
            other = edge.parent_table if edge.child_table == node else edge.child_table
            if other in visited:
                continue
            path.append(edge)
            visited.add(other)
            walk(other, visited, path)
            visited.discard(other)
            path.pop()

    walk(driver, {driver}, [])
    results.sort(key=lambda item: (-item[0], len(item[1])))
    return results[:limit]
