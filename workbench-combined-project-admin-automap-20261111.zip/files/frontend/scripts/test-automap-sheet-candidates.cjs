const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const h = require('./test-automap-preservation.cjs');
const sheetFile = path.resolve(__dirname, '../src/features/sttm/mapping/sheet-candidates.ts');
const sheet = {exports: h.loadPure(sheetFile)};
const candidate = (id='one', changes={}) => ({candidate_id:id,source_attributes:['src.Name'],source_dependencies:['src.Name'],
  confidence_score:.3,original_confidence_score:changes.confidence_score ?? .3,confidence_reason:'Business evidence for '+id,preprocessing_rule_type:'Direct',mapping_mode:'source',
  transformation_classification:'direct',scoring_policy_version:'draft-caps-v1',validation_status:'valid',validation_errors:[],warnings:[],value_binding_ids:[],...changes});
function begin(state) { h.reducer(h.pendingReducer)(state,{meta:{requestId:'sheet-run'}}); }
function deliver(state, options, changes={}) {
 h.helpers.applyAutoMapResponseToState(state,h.response({...options[0],candidates:options,...changes},
  {meta:{automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'}}));
}
function findInitializer(ast,name) {
 let result;
 function visit(node) { if(node.initializer && node.name?.getText(ast)===name) result=node.initializer;ts.forEachChild(node,visit); }
 visit(ast);assert.ok(result,name);return result;
}
const dependencies={...h.helpers,...sheet.exports};
const capture=h.compile(h.functions(h.slice,['captureManualEditSnapshot'])+';return captureManualEditSnapshot;',dependencies);
function reducer(name) {return h.compile(`return (${findInitializer(h.slice,name).getText(h.slice)});`,{...dependencies,captureManualEditSnapshot:capture});}
function stateFor(...rows) {return {...h.stateFor(...rows),mappingLoading:false,derivedSources:[],relationships:[],sources:[],sourceQueryModifiers:{}};}
function selectionHarness(state, compile) {
 const writes=[];const sent=[];let values=[{attribute_id:'firm',attribute_name:'FIRM',attribute_value:'approved'}];
 const callback=findInitializer(h.slice,'selectSheetCandidate').arguments[1].getText(h.slice);
 const select=h.compile(`return (${callback});`,{...dependencies,
  listProjectAttributes:async()=>values,
  resolveSelectedSourceTables:()=>[],
  buildRelationGraph:(_s,_d,_j,_m,currentValues)=>({nodes:[],edges:[],value_bindings:currentValues}),
  dbService:{compileMappingSql:async payload=>{sent.push(payload);return compile ? compile(payload) : {valid:true,ready:true,unresolved_placeholders:[],warnings:[]};}},
  sheetCandidateValidated:payload=>({type:'valid',payload}),
  sheetCandidateInvalidated:payload=>({type:'invalid',payload}),
  sheetCandidateRevalidated:payload=>({type:'revalidated',payload}),
 });
 return {sent,writes,setValues:next=>{values=next;},select:options=>select(options,{getState:()=>({sttmBuilder:state}),dispatch:action=>{writes.push(action);reducer(action.type==='invalid'?'sheetCandidateInvalidated':action.type==='revalidated'?'sheetCandidateRevalidated':'sheetCandidateValidated')(state,action);}})};
}

test('draft contract inherits original confidence and applies independently of valid-only selection',()=>{
 const filename=path.resolve(__dirname,'../src/types/api-contract.ts');
 const ast=ts.createSourceFile(filename,fs.readFileSync(filename,'utf8'),ts.ScriptTarget.Latest,true);
 const aliases=new Map(ast.statements.filter(ts.isTypeAliasDeclaration).map(node=>[node.name.text,node]));
 function fields(name) {
  const result=new Map();
  function visit(node) {if(ts.isPropertySignature(node)) result.set(node.name.getText(ast),node);ts.forEachChild(node,visit);}
  visit(aliases.get(name));return result;
 }
 const candidateFields=fields('AutoMapCandidate');
 for(const name of ['original_confidence_score','adjusted_confidence_score']) {
  const field = name === 'original_confidence_score' ? fields('MappingOption').get(name) : candidateFields.get(name);
  assert.equal(field.type.getText(ast),'number | null');
  assert.ok(field.questionToken);
 }
 assert.equal(candidateFields.get('scoring_policy_version').type.getText(ast),'string | null');
 assert.equal(candidateFields.get('scoring_issues').type.getText(ast),'CandidateScoringIssue[]');
 const issues=fields('CandidateScoringIssue');
 assert.equal(issues.get('category').type.getText(ast),'"source" | "sql" | "value" | "validation" | "evidence"');
 assert.equal(issues.get('severity').type.getText(ast),'"error" | "warning"');
 assert.equal(issues.get('code').type.getText(ast),'string');
 assert.equal(issues.get('message').type.getText(ast),'string');
 const mapping=fields('AttributeMapping');
 for(const name of ['selected_candidate_id','draft_candidate_id']) assert.equal(mapping.get(name).type.getText(ast),'string | null');
 const state=stateFor(h.blank());begin(state);
 deliver(state,[candidate('bad',{validation_status:'invalid',validation_errors:['Missing Value']})],
  {draft_candidate_id:'bad',selected_candidate_id:null});
 assert.equal(state.mappings[0].selectedAiCandidateId,'bad');
 assert.equal(state.mappings[0].sourceColumn,'src.Name');
 assert.equal(state.mappings[0].validation.result,'failed');
});

test('historical and mixed-policy candidate receipts cannot change definitions or scores',()=>{
 for(const kind of ['missing','old','mixed']) {
  const state=stateFor(h.blank());begin(state);const before=structuredClone(state.mappings);
  const draft=candidate('old',{confidence_score:.99,validation_status:'invalid',scoring_policy_version:kind==='mixed'?'old':'draft-caps-v1'});
  const meta=kind==='missing'?{}:{automap_scoring_policy_version:kind==='old'?'old':'draft-caps-v1',automap_draft_validation:'draft-caps-v1'};
  h.helpers.applyAutoMapResponseToState(state,h.response({...draft,candidates:[draft]},{meta}));
  assert.deepEqual(state.mappings,before);assert.match(state.errorState.autoMap,/incompatible/);
 }
});

test('explicit current validation refreshes confidence without erasing evidence or unknown scores',async()=>{
 for(const original of [.99,null]) for(const evidence of [false,true]) {
  const issue={code:'candidate_value',category:'value',severity:'error',message:'Required Firm Value is unresolved: $FIRM'};
  const remaining={code:'missing_reason',category:'evidence',severity:'warning',message:'No candidate-specific reasoning was supplied.'};
  const draft=candidate('value',{preprocessing_rule:'COALESCE(src.Name, $FIRM)',preprocessing_rule_type:'Custom',
   original_confidence_score:original,adjusted_confidence_score:original===null?null:.49,confidence_score:original===null?0:.49,
   validation_status:'invalid',validation_errors:[issue.message],warnings:[issue.message,...(evidence?[remaining.message]:[])],scoring_issues:[issue,...(evidence?[remaining]:[])]});
  const state=stateFor({...h.blank(),...sheet.exports.candidateRowUpdates(draft),aiCandidates:[draft]});
  const harness=selectionHarness(state);await harness.select({mappingId:'NAME',candidateId:'value',validateOnly:true});
  const row=state.mappings[0],current=row.aiCandidates[0],expected=original===null?null:evidence?.79:.99;
  assert.equal(row.status,'MAPPED');assert.equal(row.confidenceScore,expected);assert.equal(current.adjusted_confidence_score,expected);
  assert.equal(current.original_confidence_score,original);assert.deepEqual(current.validation_errors,[]);
  assert.deepEqual(current.scoring_issues,evidence?[remaining]:[]);assert.deepEqual(current.warnings,evidence?[remaining.message]:[]);
 }
});

test('confirmation refreshes the selected score and retains evidence caps',async()=>{
 const issue={code:'candidate_sql',category:'sql',severity:'error',message:'Previous SQL validation failed'};
 const evidence={code:'missing_reason',category:'evidence',severity:'warning',message:'No candidate-specific reasoning was supplied.'};
 const draft=candidate('fixed',{original_confidence_score:.99,adjusted_confidence_score:.49,confidence_score:.49,validation_status:'invalid',
  validation_errors:[issue.message],scoring_issues:[issue,evidence]});
 const state=stateFor({...h.blank(),aiCandidates:[draft]});
 await selectionHarness(state).select({mappingId:'NAME',candidateId:'fixed',confirm:true});
 assert.equal(state.mappings[0].status,'MAPPED');assert.equal(state.mappings[0].confidenceScore,.79);
 assert.deepEqual(state.mappings[0].aiCandidates[0].scoring_issues,[evidence]);
 assert.equal(state.mappings[0].aiCandidates[0].original_confidence_score,.99);
});

test('successful SQL compilation cannot erase malformed capture or admission blockers',async()=>{
 for(const issue of [{code:'malformed_field',category:'source',severity:'error',message:'Malformed proposal field source_attributes: "[{"'},
  {code:'capture_validation',category:'validation',severity:'error',message:'Admission still required'}]) {
  const draft=candidate('blocked',{original_confidence_score:.99,adjusted_confidence_score:.49,validation_status:'invalid',validation_errors:[issue.message],scoring_issues:[issue]});
  const state=stateFor({...h.blank(),...sheet.exports.candidateRowUpdates(draft),aiCandidates:[draft]});
  await selectionHarness(state).select({mappingId:'NAME',candidateId:'blocked',validateOnly:true});
  assert.equal(state.mappings[0].status,'MAPPED');assert.notEqual(state.mappings[0].validation?.result,'valid');assert.deepEqual(state.mappings[0].aiCandidates[0].scoring_issues,[issue]);
 }
});

test('frontend relation graph includes every provided Value, including false zero and empty',()=>{
 const build=h.compile(h.functions(h.slice,['buildRelationGraph'])+';return buildRelationGraph;',dependencies);
 const values=Array.from({length:48},(_,index)=>({attribute_id:'id'+index,attribute_name:'Value'+index,
  attribute_type:'VARCHAR',attribute_value:index===0?false:index===1?0:index===2?'':'private-'+index}));
 const graph=build([],[],[],[],values);
 assert.equal(graph.value_bindings.length,48);
 assert.deepEqual(graph.value_bindings.map(binding=>binding.value),values.map(value=>'$'+value.attribute_name));
 assert.deepEqual(graph.value_bindings.slice(0,3).map(binding=>binding.resolved_value),[false,0,'']);
});

test('Auto-map fills the highest-ranked concrete draft even before a lower valid choice',()=>{
 const state=stateFor(h.blank());begin(state);
 deliver(state,[candidate('bad',{confidence_score:.99,validation_status:'invalid',validation_errors:['Missing column']}),candidate()]);
 assert.equal(state.mappings[0].sourceColumn,'src.Name');
 assert.equal(state.mappings[0].confidenceScore,.99);
 assert.equal(state.mappings[0].aiReviewStatus,'unreviewed');
 assert.equal(state.mappings[0].selectedAiCandidateId,'bad');
 assert.equal(state.mappings[0].status,'MAPPED');
 assert.equal(state.pendingAiMappingReviews.length,0);
 assert.equal(state.mappings[0].aiCandidates[0].validation_status,'invalid');
});

test('complete alternatives preserve every field and do not manufacture missing alternatives',()=>{
 const result=sheet.exports.rankedRowCandidates([candidate('rule',{preprocessing_rule:'TRIM(src.Name)',preprocessing_rule_type:'Custom'}),candidate('value',{source_attributes:[],mapping_mode:'attribute',attribute_name:'FIRM',constant_value:'$FIRM',value_binding_ids:['firm']})]);
 assert.equal(result.length,2);assert.equal(result[0].preprocessing_rule,'TRIM(src.Name)');
 assert.deepEqual(result[1].value_binding_ids,['firm']);assert.equal(result[1].confidence_reason,'Business evidence for value');
 assert.equal(sheet.exports.rankedRowCandidates([candidate()]).length,1);
});

test('human-authored and confirmed definitions remain unchanged while alternatives appear in the row',()=>{
 for(const row of [h.imported(),{...h.imported(),aiReviewStatus:'confirmed'},{...h.imported(),manuallySaved:true}]) {
  const state=stateFor(structuredClone(row));begin(state);deliver(state,[candidate()]);
  for(const field of ['expression','sourceColumn','sourceColumns','rule','mappingMode']) assert.deepEqual(state.mappings[0][field],row[field]);
  assert.equal(state.mappings[0].aiCandidates.length,1);assert.equal(state.pendingAiMappingReviews.length,0);
 }
});

test('unavailable Values and invalid SQL populate drafts without executable approval',()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate('bad',{validation_status:'invalid',validation_errors:['Missing Value']})]);
 assert.equal(state.mappings[0].status,'MAPPED');assert.equal(state.mappings[0].selectedAiCandidateId,'bad');
 assert.equal(state.mappings[0].sourceColumn,'src.Name');assert.equal(state.mappings[0].validation.result,'failed');
 assert.equal(state.compiledMappingReady,false);assert.equal(state.mappings[0].aiReviewStatus,'unreviewed');
});

test('only checked target rows receive draft suggestions',()=>{
 const state=stateFor(h.blank(),h.blank('OTHER'));state.selectedMappingIds=['NAME'];begin(state);
 deliver(state,[candidate()]);assert.equal(state.mappings[1].aiCandidates,undefined);assert.equal(state.mappings[1].sourceColumn,null);
});

test('switching atomically chooses a draft without invoking compilation or certifying it',async()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate(),candidate('rule',{source_attributes:['src.Other'],source_dependencies:['src.Other'],preprocessing_rule:'TRIM(src.Other)',preprocessing_rule_type:'Custom',transformation_classification:'complex'})]);
 state.mappingLoading=false;state.autoMapRun=null;
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'rule'});
 const row=state.mappings[0];assert.equal(row.sourceColumn,'src.Other');assert.equal(row.rule,'Custom');assert.equal(row.expression,'TRIM(src.Other)');
 assert.deepEqual(row.sourceDependencies,['src.Other']);assert.equal(row.aiReviewStatus,'unreviewed');
 assert.equal(harness.sent.length,0);assert.equal(row.status,'MAPPED');assert.equal(row.validation,null);
});

test('validation failure or changed input never applies the candidate',async()=>{
 for(const mode of ['invalid','race']) {
  const state=stateFor({...h.blank(),aiCandidates:[candidate()],aiReviewStatus:null});
  const harness=selectionHarness(state,async()=>{
   if(mode==='race')state.mappings[0].expression='user changed';
   return {valid:mode!=='invalid',ready:true,unresolved_placeholders:[],warnings:['Invalid rule']};
  });
  await assert.rejects(harness.select({mappingId:'NAME',candidateId:'one',confirm:true}),mode==='invalid'?/Invalid rule/:/changed/);
  assert.equal(harness.writes.length,mode==='invalid'?1:0);assert.equal(state.mappings[0].sourceColumn,null);
  if(mode==='invalid')assert.equal(state.mappings[0].aiCandidates[0].validation_status,'invalid');
 }
});

test('confirmation is validated and undo restores the complete earlier definition',async()=>{
 const row={...h.blank(),aiCandidates:[candidate()]};const state=stateFor(row);
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'one',confirm:true});
 assert.equal(row.aiReviewStatus,'confirmed');assert.equal(row.confidenceScore,.3);assert.equal(row.selectedAiCandidateId,'one');
 reducer('undoSheetSuggestion')(state,{payload:'NAME'});
 assert.equal(row.sourceColumn,null);assert.equal(row.expression,null);assert.equal(row.status,'UNMAPPED');assert.equal(row.aiReviewStatus,null);
 assert.equal(row.aiCandidates.length,1);assert.equal(row.aiUndoSnapshot,null);assert.deepEqual(row.sourceColumns,[]);assert.deepEqual(row.sourceDependencies,[]);assert.equal(row.confidenceScore,null);
});

test('manual edits clear candidate selection and protect the edited definition on another Auto-map',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};const state=stateFor(row);
 reducer('updateMapping')(state,{payload:{id:'NAME',updates:{expression:'UPPER(src.Name)',rule:'Custom'}}});
 assert.equal(row.aiReviewStatus,'edited');assert.equal(row.selectedAiCandidateId,null);
 assert.equal(row.expression,'UPPER(src.Name)');
});

test('candidate details, selection, review and undo survive workspace JSON and reopen recovery',()=>{
 const file=path.resolve(__dirname,'../src/features/sttm/context/workbench-context.ts');
 const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true);
 const mappingRows=findInitializer(ast,'mapping_rows').getText(ast);
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()],aiReviewStatus:'confirmed',aiUndoSnapshot:{sourceColumn:null,status:'UNMAPPED'}};
 const rows=h.compile(`return (${mappingRows});`,{input:{mappings:[row]},...h.helpers});
 const recoveryFile=path.resolve(__dirname,'../src/features/sttm/shared/mapping-row-recovery.ts');
 const recovery=ts.createSourceFile(recoveryFile,fs.readFileSync(recoveryFile,'utf8'),ts.ScriptTarget.Latest,true);
 const recover=h.compile(h.functions(recovery,['savedMappingEvidence'])+';return savedMappingEvidence;');
 const restored=recover(JSON.parse(JSON.stringify(rows[0])));
 assert.deepEqual(restored.aiCandidates,row.aiCandidates);assert.equal(restored.selectedAiCandidateId,'one');
 assert.equal(restored.aiReviewStatus,'confirmed');assert.deepEqual(restored.aiUndoSnapshot,row.aiUndoSnapshot);
});

test('candidate confirmation saves a draft choice without committing another row’s pending manual edits',async()=>{
 const row={...h.blank(),aiCandidates:[candidate()]};const other={...h.blank('OTHER'),expression:'manual draft'};
 const state=stateFor(row,other);state.pendingManualEditSnapshots.OTHER={...other,expression:null};
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'one',confirm:true});
 assert.equal(row.aiReviewStatus,'confirmed');assert.equal(state.pendingManualEditSnapshots.NAME,undefined);
 assert.equal(state.pendingManualEditSnapshots.OTHER.expression,null);assert.equal(other.expression,'manual draft');
 assert.equal(state.autoMapBlockedByManualEdits,true);
});

test('an already selected definition has validation-failed status when its Value or SQL validation fails',async()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};
 const state=stateFor(row);
 const harness=selectionHarness(state,async()=>({valid:false,ready:false,unresolved_placeholders:['$FIRM'],warnings:['Value unavailable']}));
 await assert.rejects(harness.select({mappingId:'NAME',candidateId:'one',confirm:true}),/Value unavailable/);
 assert.equal(row.status,'MAPPED');assert.equal(row.selectedAiCandidateId,'one');assert.equal(row.aiReviewStatus,'unreviewed');
 assert.equal(row.aiCandidates[0].validation_status,'invalid');assert.equal(row.unmatchedReason,'Value unavailable');
});

test('explicitly choosing an invalid replacement applies only a draft and retains undo',async()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate(),candidate('other',{source_attributes:['src.Other'],validation_status:'invalid',validation_errors:['Column unavailable']})]};
 const state=stateFor(row);
 const harness=selectionHarness(state,async()=>({valid:false,ready:false,unresolved_placeholders:[],warnings:['Column unavailable']}));
 await harness.select({mappingId:'NAME',candidateId:'other'});
 assert.equal(row.status,'MAPPED');assert.equal(row.selectedAiCandidateId,'other');assert.equal(row.sourceColumn,'src.Other');
 assert.equal(row.aiCandidates[0].validation_status,'invalid');assert.equal(harness.sent.length,0);
 reducer('undoSheetSuggestion')(state,{payload:'NAME'});assert.equal(row.sourceColumn,'src.Name');assert.equal(row.selectedAiCandidateId,'one');
});

test('chat receives only draft suggestion, low-confidence and unresolved counts',()=>{
 const state=stateFor(h.blank(),h.blank('OTHER'));begin(state);deliver(state,[candidate()]);
 h.reducer(h.fulfilledReducer)(state,{meta:{requestId:'sheet-run'},payload:{sheetReviewV1:true,totalCount:2,failedTargets:[],autoMapOutcome:null}});
 assert.equal(state.chatMessages.length,1);
 assert.match(state.chatMessages[0].content,/New draft mappings applied:\*\* 1/);
 assert.match(state.chatMessages[0].content,/Low-confidence draft suggestions:\*\* 1/);
 assert.match(state.chatMessages[0].content,/Unmapped:\*\* 1/);
 assert.equal(state.pendingAiMappingReviews.length,0);
 assert.doesNotMatch(state.chatMessages[0].content,/Apply Changes|accept.*queue/i);
});

test('adjusted confidence ranks concrete drafts and unknown provenance never becomes zero',()=>{
 const unknown=candidate('unknown',{confidence_score:0,original_confidence_score:null,adjusted_confidence_score:null});
 const scored=candidate('scored',{confidence_score:.49,original_confidence_score:.95,adjusted_confidence_score:.49,
  scoring_policy_version:'draft-caps-v1',validation_status:'invalid',scoring_issues:[{code:'missing_value',category:'value',severity:'error',message:'Required Firm Value is unresolved: $FIRM'}]});
 assert.deepEqual(sheet.exports.rankedRowCandidates([unknown,scored,candidate('zero',{confidence_score:0})]).map(item=>item.candidate_id),['scored','zero','unknown']);
 const state=stateFor(h.blank());begin(state);deliver(state,[unknown,scored],{selected_candidate_id:null,draft_candidate_id:'scored'});
 const first=structuredClone(state.mappings[0]);deliver(state,[unknown,scored]);
 assert.equal(state.mappings[0].confidenceScore,.49);assert.deepEqual(state.mappings[0].aiCandidates,first.aiCandidates);
 assert.equal(state.mappings[0].aiCandidates[0].original_confidence_score,.95);
 assert.equal(h.helpers.guidanceForRow(state.mappings[0]).filter(item=>item.message.includes('$FIRM')).length,1);
 const unknownState=stateFor(h.blank());begin(unknownState);deliver(unknownState,[unknown]);
 assert.equal(unknownState.mappings[0].confidenceScore,null);assert.equal(unknownState.mappings[0].validation,null);
 assert.equal(unknownState.mappings[0].status,'MAPPED');
});

test('Direct labels cannot erase exact invalid SQL, quoted identifiers, CTEs or Value expressions',()=>{
 for(const expression of ['  TRIM(src."Mixed.Name")  ',"WITH names AS (SELECT 'MiXeD' AS NAME) SELECT NAME FROM names",'src.Name || $MISSING']) {
  const draft=candidate('sql',{preprocessing_rule_type:'Direct',preprocessing_rule:expression,validation_status:'invalid',validation_errors:['Expression requires a validated transformation rule']});
  const state=stateFor(h.blank());begin(state);deliver(state,[draft]);
  assert.equal(state.mappings[0].expression,expression);assert.equal(state.mappings[0].aiSuggestedRule,expression);
  assert.equal(state.mappings[0].rule,'Direct');assert.equal(state.mappings[0].validation.result,'failed');
  assert.equal(h.helpers.definitionKey(state.mappings[0]),h.helpers.definitionKey(draft));
 }
 for(const value of ['', '0', 'false']) {
  const state=stateFor(h.blank());begin(state);deliver(state,[candidate('value',{source_attributes:[],mapping_mode:'constant',constant_value:value,validation_status:'unvalidated'})]);
  assert.equal(state.mappings[0].constantValue,value);assert.equal(state.mappings[0].status,'MAPPED');
 }
});

test('empty and names-only guidance or malformed candidates never create a mapping',()=>{
 for(const fields of [
  {candidates:[]}, {candidates:undefined,source_attributes:['src.Name']},
  {candidates:[candidate('names',{source_attributes:[],source_dependencies:[],candidate_source_attributes:['src.Name'],preprocessing_rule:'Consider matching customer names'})]},
  {candidates:[candidate('blank',{source_attributes:['  '],source_dependencies:[]})]},
  {candidates:[candidate('malformed',{source_attributes:[{name:'src.Name'}]})]},
 ]) {
  const state=stateFor(h.blank());begin(state);
  h.helpers.applyAutoMapResponseToState(state,h.response(fields,{meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'}}));
  assert.equal(state.mappings[0].sourceColumn,null);assert.equal(state.mappings[0].status,'UNMAPPED');
  assert.equal(state.mappings[0].selectedAiCandidateId,null);assert.notEqual(state.mappings[0].validation?.result,'valid');
 }
});

test('a later empty or failed receipt preserves an already populated draft and its first undo',()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate('draft',{validation_status:'invalid',validation_errors:['Missing column']})]);
 const original=structuredClone(state.mappings[0]);
 deliver(state,[],{source_attributes:[],unmatched_reason:'No newer proposal'});
 assert.equal(state.mappings[0].sourceColumn,original.sourceColumn);assert.equal(state.mappings[0].selectedAiCandidateId,'draft');
 assert.deepEqual(state.mappings[0].validation,original.validation);assert.deepEqual(state.mappings[0].aiUndoSnapshot,original.aiUndoSnapshot);
 h.helpers.applyAutoMapResponseToState(state,h.response({candidates:[candidate('failed',{source_attributes:['src.Failed']})]}, {warnings:[{code:'AUTO_MAPPING_BATCH_FAILED',field:'NAME'}]}));
 assert.equal(state.mappings[0].sourceColumn,original.sourceColumn);assert.deepEqual(state.mappings[0].aiUndoSnapshot,original.aiUndoSnapshot);
});

const review=h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/mapping-review-model.ts'));
const navigation=h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/review-navigation.ts'));
const physical=(id='D.S.ACCOUNTS',qualified='D.S.ACCOUNTS')=>({tableId:id,qualifiedName:qualified,tableName:'ACCOUNTS',isSelected:true,columnItems:[]});
const aliases=h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/relation-alias.ts'));

test('the current mapping and explanation-only variants are excluded from alternatives',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate(),candidate('duplicate',{confidence_score:.99,confidence_reason:'Another explanation'})]};
 assert.equal(review.alternativeCandidates(row).length,0);
 row.aiCandidates.push(candidate('trim',{preprocessing_rule_type:'Custom',preprocessing_rule:'TRIM(src.Name)'}));
 assert.equal(review.alternativeCandidates(row).length,1);
 assert.equal(review.alternativeCandidates(row)[0].candidate_id,'trim');
});

test('identity comparison resolves exact aliases/FQNs and equivalent built-in expressions, retaining real dependency differences',()=>{
 const source=physical();const catalog=review.reviewCatalog([source],[]);const alias=aliases.relationAliasFor(source.qualifiedName);
 const row={...h.blank(),sourceColumns:[`${alias}.NAME`],sourceColumn:`${alias}.NAME`,rule:'Trim',sourceDependencies:[]};
 const same=candidate('same',{source_attributes:['D.S.ACCOUNTS.NAME'],source_dependencies:['D.S.ACCOUNTS.NAME'],preprocessing_rule_type:'Custom',preprocessing_rule:' TRIM( D.S.ACCOUNTS.NAME ) '});
 assert.equal(review.definitionKey(row,catalog),review.definitionKey(same,catalog));
 const extra={...same,source_dependencies:['D.S.ACCOUNTS.NAME','D.S.ACCOUNTS.PARENT_ID']};
 assert.notEqual(review.definitionKey(row,catalog),review.definitionKey(extra,catalog));
 const upper={...same,preprocessing_rule:'UPPER(TRIM(D.S.ACCOUNTS.NAME))'};
 assert.notEqual(review.definitionKey(row,catalog),review.definitionKey(upper,catalog));
});

test('generated display aliases are metadata-bound and preserve quoted identifiers, authored roles and real hash-like table names',()=>{
 const source=physical();const alias=aliases.relationAliasFor(source.qualifiedName);const catalog=review.reviewCatalog([source],[]);
 assert.equal(catalog.display(`${alias}.NAME`),'ACCOUNTS.NAME');
 assert.equal(catalog.display(`${alias}."Mixed.Name"`),'ACCOUNTS."Mixed.Name"');
 assert.equal(catalog.display(`'${alias}.NAME'`),`'${alias}.NAME'`,'SQL literals remain literal data');
 assert.equal(catalog.display('accounts_NOT_A_REAL_ALIAS.NAME'),'accounts_NOT_A_REAL_ALIAS.NAME');
 const legitimate=physical('D.S.ACCOUNTS_ENUEH8','D.S.ACCOUNTS_ENUEH8');
 assert.equal(review.reviewCatalog([legitimate],[]).display(`${aliases.relationAliasFor(legitimate.qualifiedName)}.NAME`),'ACCOUNTS_ENUEH8.NAME');
 const roles=review.reviewCatalog([physical('sql-instance:upload:Household'),physical('sql-instance:upload:Parent')],[]);
 assert.equal(roles.display('Household.NAME'),'ACCOUNTS (Household).NAME');
 assert.equal(roles.display('Parent.NAME'),'ACCOUNTS (Parent).NAME');
 assert.notEqual(roles.identity('Household.NAME'),roles.identity('Parent.NAME'));
 const cte={id:'sql-cte:upload:Families',sourceName:'Families',isSelected:true};
 assert.equal(review.reviewCatalog([], [cte]).display(`${aliases.relationAliasFor(cte.id,cte.sourceName)}.ID`),'Families.ID');
});

test('same-named tables across databases remain unambiguous and unknown bindings never collapse together',()=>{
 const catalog=review.reviewCatalog([physical('D1.S.ACCOUNTS','D1.S.ACCOUNTS'),physical('D2.S.ACCOUNTS','D2.S.ACCOUNTS')],[]);
 assert.notEqual(catalog.nodes[0].label,catalog.nodes[1].label);
 assert.notEqual(catalog.identity('unknown:one'),catalog.identity('unknown:two'));
});

test('Value comparison uses the approved named placeholder rather than ephemeral row binding IDs',()=>{
 const row={...h.blank(),mappingMode:'attribute',constantValue:'$FIRM',attributeName:'FIRM',rule:'Value',valueBindingIds:['value:old-row']};
 const option=candidate('value',{source_attributes:[],source_dependencies:[],mapping_mode:'attribute',constant_value:'$FIRM',attribute_name:'FIRM',value_binding_ids:['$FIRM'],preprocessing_rule_type:'Value'});
 assert.equal(review.definitionKey(row),review.definitionKey(option));
});

test('empty/prose-only responses become guidance, never invented confidence candidates',()=>{
 const empty=candidate('empty',{source_attributes:[],source_dependencies:[],confidence_score:0,transformation_classification:'unresolved',unmatched_reason:'SI_FIRM is entirely null; consider a lookup.'});
 const row={...h.blank(),aiCandidates:[empty]};
 assert.equal(review.alternativeCandidates(row).length,0);assert.equal(review.guidanceForRow(row).length,1);
 assert.match(review.guidanceForRow(row)[0].message,/entirely null/);
});

test('switching keeps the previous full mapping and confirmation preserves its independent undo point',async()=>{
 const original=candidate('original',{confidence_score:.85,confidence_reason:'Original reason'});
 const next=candidate('next',{source_attributes:['src.Other'],source_dependencies:['src.Other'],confidence_score:.72,confidence_reason:'New reason'});
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(original),aiCandidates:[original,next]};const state=stateFor(row);const harness=selectionHarness(state);
 await harness.select({mappingId:row.id,candidateId:'next'});
 let alternatives=review.alternativeCandidates(row);assert.equal(alternatives.length,1);
 assert.equal(alternatives[0].confidence_score,.85);assert.equal(alternatives[0].confidence_reason,'Original reason');
 assert.equal(alternatives[0].previously_applied,true);assert.deepEqual(alternatives[0].source_dependencies,['src.Name']);
 const undo=structuredClone(row.aiUndoSnapshot);
 await harness.select({mappingId:row.id,candidateId:'next',confirm:true});
 assert.deepEqual(row.aiUndoSnapshot,undo);assert.equal(row.aiReviewStatus,'confirmed');
});

test('a manual previous mapping keeps its expression and has no manufactured score or explanation',async()=>{
 const row={...h.imported(),confidenceScore:null,confidenceReason:null,manuallySaved:true,aiCandidates:[candidate()]};
 const state=stateFor(row);const harness=selectionHarness(state);
 await harness.select({mappingId:row.id,candidateId:'one'});
 const previous=review.alternativeCandidates(row)[0];assert.equal(previous.origin,'manual');
 assert.equal(previous.confidence_score,null);assert.equal(previous.confidence_reason,null);
 assert.equal(previous.preprocessing_rule,h.imported().expression);assert.equal(previous.previously_applied,true);
});

test('revalidation updates option readiness without applying a different definition',async()=>{
 const row={...h.blank(),aiCandidates:[candidate('pending',{validation_status:'unvalidated'})]};const state=stateFor(row);const harness=selectionHarness(state);
 await harness.select({mappingId:row.id,candidateId:'pending',validateOnly:true});
 assert.equal(row.aiCandidates[0].validation_status,'valid');assert.equal(row.sourceColumn,null);assert.equal(row.status,'UNMAPPED');
});

test('row-specific warnings are deduplicated and another target’s warning is excluded',()=>{
 const row={...h.blank(),targetColumn:'ADDRESS'};
 assert.deepEqual(review.relevantWarnings(row,['ADDRESS needs review','ADDRESS needs review','REFERRAL_ID has poor coverage'],['ADDRESS','REFERRAL_ID']),['ADDRESS needs review']);
});

test('review navigation scopes requests and prefills only supplied relationship evidence',()=>{
 const storage={getItem:()=>JSON.stringify({id:'intent',projectId:'p',sttmId:'s',mappingId:'row',targetColumn:'FIRM',purpose:'Known purpose',base:'/sttm/builder/s',status:'pending',recommendation:{left_relation_id:'a',right_relation_id:'b'}})};
 const intent=navigation.readJoinReview(storage,'p','s');assert.ok(intent);assert.equal(navigation.readJoinReview(storage,'other','s'),null);
 const unknown=navigation.joinReviewDraft(intent,['a','b'],[]);assert.equal(unknown.joinType,undefined);assert.deepEqual(unknown.conditions,[]);
 const explicit={...intent,recommendation:{...intent.recommendation,join_type:'LEFT',conditions:[{left_column:'FIRM_ID',right_column:'ID',operator:'='}]}};
 const known=navigation.joinReviewDraft(explicit,['a','b'],[]);assert.equal(known.joinType,'LEFT');assert.equal(known.conditions[0].leftColumn,'FIRM_ID');
 const original={id:'existing',leftTableId:'a',rightTableId:'b',joinType:'INNER',sqlPredicate:'a.ID = b.ID AND b.ACTIVE = 1',conditions:[]};
 assert.deepEqual(navigation.joinReviewDraft(explicit,['a','b'],[original]),original);
 assert.match(navigation.rowReviewUrl('/sttm/builder/s','row / &'),/row%20%2F%20%26/);
});

test('join review source selection and explicit save preserve authored SQL, CTEs, aliases, filters and pending edits',()=>{
 const source=physical();const lookup=physical('D.S.FIRMS','D.S.FIRMS');source.isSelected=true;lookup.isSelected=false;
 const state=stateFor({...h.imported()});state.sourceDatabases=[{schemas:[{tables:[source,lookup]}]}];state.sources=[source];
 Object.assign(state,{drivingTableId:'original-driver',sourceQuerySql:'WITH untouched AS (SELECT 1) SELECT * FROM untouched',mappingSql:'uploaded SQL',rawMappingSql:'raw SQL',derivedSources:[{id:'cte',sqlText:'SELECT 1',isSelected:true}],sourceFilterGroups:[{id:'filter'}],sourceQueryModifiers:{where:'keep'},relationships:[{id:'authored',sqlPredicate:'a.ID=b.ID OR b.ID IS NULL'}],pendingManualEditSnapshots:{NAME:{...state.mappings[0]}},autoMapBlockedByManualEdits:true});
 const protectedKeys=['drivingTableId','sourceQuerySql','mappingSql','rawMappingSql','derivedSources','sourceFilterGroups','sourceQueryModifiers','pendingManualEditSnapshots','mappings'];
 const before=Object.fromEntries(protectedKeys.map(key=>[key,structuredClone(state[key])]));
 reducer('selectJoinReviewSources')(state,{payload:['D.S.FIRMS','invented']});
 assert.equal(state.sources.length,2);assert.equal(state.relationships.length,1);
 reducer('saveReviewedJoin')(state,{payload:{id:'reviewed',leftTableId:'D.S.ACCOUNTS',rightTableId:'D.S.FIRMS',joinType:'LEFT',conditions:[{leftColumn:'FIRM_ID',rightColumn:'ID',operator:'='}]}});
 for(const key of protectedKeys)assert.deepEqual(state[key],before[key],key);
 assert.equal(state.relationships[0].sqlPredicate,'a.ID=b.ID OR b.ID IS NULL');assert.equal(state.relationships.length,2);
});

test('single-row reevaluation preserves the existing checkbox selection',()=>{
 const state=stateFor(h.blank('NAME'),h.blank('OTHER'));state.selectedMappingIds=['OTHER'];
 assert.deepEqual(h.helpers.autoMapScope(state,{action:'complete',mappingIds:['NAME']}).names,['NAME']);
 assert.deepEqual(state.selectedMappingIds,['OTHER']);
});

function renderReviewRow(row,{sourceCell=false,open=null,fullRow=false}={}) {
 const React=require('react');const {renderToStaticMarkup}=require('react-dom/server');
 const context={mappings:[row],sources:[],derivedSources:[],mappingLoading:false,activeProjectId:'p',activeSttmId:'s',fullData:{sources:[]},selectSheetCandidate:async()=>{},undoSheetSuggestion:()=>{},updateMapping:()=>{},selectJoinReviewSources:()=>{},runAutoMap:()=>{}};
 let opened=false;
 const reactForTest=open?{...React,useState:initial=>{if(open==='reasoning'&&initial===false&&!opened){opened=true;return React.useState(true);}if(!['reasoning','actions'].includes(open)&&initial===null&&!opened){opened=true;return React.useState(open);}return React.useState(initial);}}:React;
 const dom=(tag)=>({children,component,sx,...props})=>React.createElement(component||tag,Object.fromEntries(Object.entries(props).filter(([key])=>!['onChange','checkHandler','inputSx','enterDelay','arrow','fullWidth','size','variant','placement','options','slotProps','color'].includes(key))),children);
 const Box=dom('div');const Text=dom('span');const Button=dom('button');
 const ui={AiaChip:({label})=>React.createElement('span',{},label),AiaMenu:({open,children})=>open?React.createElement('div',{},children):null,AiaMenuItem:Button,AiaBox:Box,AiaText:Text,AiaButton:Button,AiaTableCellPrimitive:dom('td'),AiaIconButton:Button,AiaTooltip:({children,title})=>React.createElement('span',{},children,title),AiaCollapse:({in:shown,children})=>shown?React.createElement('div',{},children):null,AiaSelect:()=>null};
 const styles={MAPPING_TABLE_BODY_TEXT_SX:{fontFamily:'inherit'},MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX:38,MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT:38};
 const load=(file)=>{
  const loaded=new Module(file,module);loaded.require=request=>{
   if(request==='react')return reactForTest;
   if(request==='next/navigation')return {useRouter:()=>({push:()=>{}}),useSearchParams:()=>new URLSearchParams()};
   if(request.endsWith('sttm-builder-context'))return {useSttmBuilderContext:()=>context};
   if(request==='@/components/ui')return ui;
   if(request==='@/components/ui/aia-text')return {AiaText:Text};
   if(request==='@/components/ui/aia-table')return {aiaTableCellSx:()=>({})};
   if(request.endsWith('mapping-table-styles'))return styles;
   if(request==='@/utils/icons')return new Proxy({},{get:()=>()=>null});
   if(request.includes('tour-targets'))return {TOUR_TARGETS:{}};
   if(request.endsWith('mapping-confidence-groups'))return h.loadPure(path.resolve(__dirname,'../src/features/sttm/mapping/mapping-confidence-groups.ts'));
   if(request.endsWith('join-predicate'))return h.loadPure(path.resolve(__dirname,'../src/features/sttm/source-target/join-predicate.ts'));
   if(request.endsWith('sheet-candidates'))return sheet.exports;
   if(request.endsWith('mapping-review-model'))return review;
   if(request.endsWith('review-navigation'))return navigation;
   if(request.endsWith('row-validation-state'))return h.helpers;
   if(request.endsWith('use-row-join-review'))return {useRowJoinReview:()=>()=>{}};
   return require(request);
  };
  loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText,file);return loaded.exports;
 };
 const Component=load(path.resolve(__dirname,'../src/features/sttm/mapping/mapping-row-candidates.tsx')).MappingRowCandidates;
 const content=React.createElement(Component,{row});
 if(!sourceCell&&!fullRow)return renderToStaticMarkup(content);
 const Source=load(path.resolve(__dirname,'../src/features/sttm/mapping/cells/mapping-source-columns-cell.tsx')).MappingSourceColumnsCell;
 const Status=load(path.resolve(__dirname,'../src/features/sttm/mapping/cells/mapping-status-cell.tsx')).MappingStatusCell;
 const Confidence=load(path.resolve(__dirname,'../src/features/sttm/mapping/cells/mapping-confidence-cell.tsx')).MappingConfidenceCell;
 return renderToStaticMarkup(React.createElement('table',{},React.createElement('tbody',{},React.createElement('tr',{},
  React.createElement(Source,{mappingType:row.rule==='Custom'?'custom':'direct',value:row.sourceColumn,sourceColumns:row.sourceColumns,options:[],onChange:()=>{}},content),
  fullRow?React.createElement(Confidence,{status:row.status,confidenceScore:row.confidenceScore,reason:row.confidenceReason}):null,
  fullRow?React.createElement(Status,{status:row.status,displayStatus:review.mappingDisplayStatus(row),details:row.validation?.error}):null))));
}

test('historical candidates retain evidence and render disabled without diagnostic panels',()=>{
 const old=candidate('historical',{scoring_policy_version:undefined,confidence_score:.99,validation_status:'invalid',confidence_reason:'Historical business reason'});
 const row={...h.blank(),aiCandidates:[old]};
 const html=renderReviewRow(row,{open:'candidates'});
 assert.match(html,/Historical business reason/);assert.match(html,/Estimated mapping confidence: 99%/);
 assert.match(html,/disabled=""[^>]*>Use candidate/);assert.match(html,/Generate a fresh candidate/);
 assert.doesNotMatch(html,/Technical diagnostics|Review needed/);
 const state=stateFor(row);begin(state);deliver(state,[candidate('fresh')]);
 assert.equal(row.selectedAiCandidateId,'fresh');assert.deepEqual(row.aiCandidates.find(item=>item.candidate_id==='historical'),old);
});

test('score provenance survives explicit switching and invalid alternatives keep the existing Use candidate enabled',async()=>{
 const original=candidate('original',{original_confidence_score:.95,adjusted_confidence_score:.49,confidence_score:.49,scoring_policy_version:'draft-caps-v1',
  validation_status:'invalid',validation_errors:['Missing source'],scoring_issues:[{code:'source',category:'source',severity:'error',message:'Source requires review'}]});
 const next=candidate('next',{source_attributes:['src.Next'],original_confidence_score:null,adjusted_confidence_score:null,confidence_score:0,validation_status:'invalid'});
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(original),aiCandidates:[original,next]};const state=stateFor(row);
 const html=renderReviewRow(row,{open:'candidates'});
 assert.match(html,/Use candidate/);assert.doesNotMatch(html,/disabled=""[^>]*>Use candidate/);assert.match(html,/Estimated mapping confidence: not available/);assert.doesNotMatch(html,/Confidence: 0%/);
 await selectionHarness(state).select({mappingId:'NAME',candidateId:'next'});
 const previous=review.alternativeCandidates(row)[0];
 assert.equal(previous.original_confidence_score,.95);assert.equal(previous.adjusted_confidence_score,.49);assert.equal(previous.scoring_policy_version,'draft-caps-v1');assert.deepEqual(previous.scoring_issues,original.scoring_issues);
 reducer('undoSheetSuggestion')(state,{payload:'NAME'});assert.equal(row.confidenceScore,.49);
});

test('expression-only drafts are not described as unresolved and initial undo clears failed validation',()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate('sql',{source_attributes:[],source_dependencies:[],preprocessing_rule:'CURRENT_TIMESTAMP()',preprocessing_rule_type:'Custom',validation_status:'invalid',validation_errors:['Validation unavailable']})]);
 const summary=h.helpers.mappingReviewSummary(state.mappings,state.autoMapRun.baseline,[],[],'one');
 assert.match(summary,/CURRENT_TIMESTAMP\(\)/);assert.doesNotMatch(summary,/\*\*Unresolved\*\*/);
 state.mappingLoading=false;reducer('undoSheetSuggestion')(state,{payload:'NAME'});
 assert.equal(state.mappings[0].status,'UNMAPPED');assert.equal(state.mappings[0].validation,null);
});

test('row controls render beneath the source and current-only candidates have no alternatives button',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};
 const html=renderReviewRow(row,{sourceCell:true});
 assert.match(html,/<td[ >]/);assert.match(html,/Reasoning/);assert.doesNotMatch(html,/AI suggested|Confirm mapping|Confidence and reasoning/);
 assert.doesNotMatch(html,/View candidates|Use candidate/);
 assert.ok(html.indexOf('Direct source pick')<html.indexOf('Reasoning'),'selected-source controls precede review controls');
 const invalid={...row,status:'NEEDS_VALIDATION',aiCandidates:[candidate('one',{validation_status:'invalid',validation_errors:['Needs validation']})]};
 const pending=renderReviewRow(invalid);assert.doesNotMatch(pending,/Revalidate|Clear mapping/);assert.doesNotMatch(pending,/Current mapping requires revalidation/);assert.doesNotMatch(pending,/View candidates|Use candidate/);
});

test('guidance-only results render Suggestions, collapsed by default, without a fake 0%-Direct option',()=>{
 const row={...h.blank(),aiCandidates:[candidate('empty',{source_attributes:[],source_dependencies:[],confidence_score:0,unmatched_reason:'No suitable source <script>alert(1)</script>'})]};
 const html=renderReviewRow(row);assert.match(html,/Suggestions \(1\)/);assert.doesNotMatch(html,/0%|View candidates|No source columns|<script/);
 const expanded=renderReviewRow(row,{open:'suggestions'});assert.match(expanded,/No suitable source/);assert.doesNotMatch(expanded,/<script>/);
});

test('the actual mapping component nests review content only in the Source Column cell',()=>{
 const file=path.resolve(__dirname,'../src/features/sttm/mapping/source-target-attribute-mapping.tsx');
 const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 let source=false,target=false;
 function visit(node){if(ts.isJsxElement(node)) {
  const name=node.openingElement.tagName.getText(ast);
  if(node.children.some(child=>child.getText(ast).includes('MappingRowCandidates'))){if(name==='MappingSourceColumnsCell')source=true;if(name==='MappingTargetColumnCell')target=true;}
 }ts.forEachChild(node,visit);}visit(ast);
 assert.equal(source,true);assert.equal(target,false);
});


test('normal Source review links omit persistent status, confirmation and selected confidence, including expanded Reasoning',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()],status:'MAPPED',aiUndoSnapshot:{sourceColumn:null,sourceColumns:[],expression:null}};
 const normal=renderReviewRow(row);assert.match(normal,/Reasoning/);assert.doesNotMatch(normal,/AI suggested|Unresolved|Confirm mapping|Undo AI change|Clear mapping|Confidence|30%/);
 const reasoning=renderReviewRow(row,{open:'reasoning'});assert.match(reasoning,/Business evidence/);assert.doesNotMatch(reasoning,/Confidence:|30%|Confirm mapping/);
 const noExplanation={...row,confidenceReason:null,nlRule:null,aiCandidates:[candidate('one',{confidence_reason:null,preprocessing_nl_rule:null})]};
 assert.doesNotMatch(renderReviewRow(noExplanation),/Reasoning|View candidates|Suggestions/);
});

test('internal receipt warnings remain stored but have no mapping technical disclosure',()=>{
 const messages=['Precedents were supplied without a precedent_decision.','Review packet evidence and citation receipts.'];
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate('one',{warnings:messages})],aiSuggestions:messages.map((message,index)=>({suggestion_id:String(index),kind:'evidence',message,source_references:[]}))};
 assert.deepEqual(review.guidanceForRow(row),[]);assert.equal(review.technicalGuidanceForRow(row).length,2);
 const before=JSON.stringify(row);const html=renderReviewRow(row,{fullRow:true,open:'reasoning'});assert.doesNotMatch(html,/Technical|precedent_decision|citation receipts|Suggestions \(|Suggested next action|Clear mapping|Revalidate/);assert.equal(row.status,'MAPPED');assert.equal(JSON.stringify(row),before);
});
test('all-invalid populated rows retain confidence and business Reasoning without review or diagnostic labels',()=>{
 const reason='Customer name matches the target meaning. Required Firm Value is unresolved: $FIRM. SQL compilation failed: SELECT secret FROM internal_table. Precedents were supplied without a precedent_decision.';
 const draft=candidate('invalid',{validation_status:'invalid',confidence_score:.49,original_confidence_score:.99,adjusted_confidence_score:.49,
  confidence_reason:reason,validation_errors:['SQLSTATE 42000: SELECT secret FROM internal_table'],
  scoring_issues:[{code:'unresolvedFirmValue',category:'value',severity:'error',message:'Required Firm Value is unresolved: $FIRM'}]});
 const state=stateFor(h.blank());begin(state);deliver(state,[draft]);const row=state.mappings[0];const before=JSON.stringify(row);
 for(const open of [null,'reasoning','suggestions']) {
  const html=renderReviewRow(row,{fullRow:true,open});
  assert.match(html,/49%/);assert.match(html,/>Mapped</);assert.match(html,/Customer name matches/);
  assert.doesNotMatch(html,/Technical|precedent_decision|SQLSTATE|internal_table|SELECT secret|unresolved|review needed|needs validation|validation failed/i);
 }
 const summary=h.helpers.mappingReviewSummary([row],{},[],[],'one');
 assert.match(summary,/49% confidence/);assert.match(summary,/Customer name matches/);
 assert.doesNotMatch(summary,/precedent_decision|SQLSTATE|internal_table|unresolved|review needed|validation failed/i);
 assert.equal(JSON.stringify(row),before);assert.equal(row.status,'MAPPED');assert.equal(row.validation.origin,'generation');
});

test('explicit validation errors render actionable details while no-proposal rows stay empty and neutral',()=>{
 const empty=h.blank();const html=renderReviewRow(empty,{fullRow:true});
 assert.match(html,/>Unmapped</);assert.doesNotMatch(html,/Draft populated|>Mapped<|0%|Unresolved|review needed/i);
 assert.equal(empty.sourceColumn,null);
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()],status:'VALIDATION_FAILED',
  validation:{result:'failed',origin:'explicit',error:'Provide the approved FIRM Value.'}};
 const failed=renderReviewRow(row,{fullRow:true});assert.match(failed,/>Mapped</);assert.doesNotMatch(failed,/Validation failed|Provide the approved FIRM Value|Details/);assert.equal(row.validation.result,'failed');
});

test('bare concrete literal contract populates drafts without accepting word-like prose',()=>{
 for(const expression of ['NULL','TRUE','FALSE','CURRENT_DATE','CURRENT_TIMESTAMP',' null ','true']) {
  const draft=candidate('literal',{source_attributes:[],source_dependencies:[],preprocessing_rule_type:'Custom',preprocessing_rule:expression,validation_status:'unvalidated'});
  assert.equal(review.concreteCandidate(draft),true,expression);
  const state=stateFor(h.blank());begin(state);deliver(state,[draft]);
  assert.equal(state.mappings[0].expression,expression);assert.equal(state.mappings[0].status,'MAPPED');assert.equal(state.mappings[0].validation,null);
 }
 for(const expression of ['NULL is unknown','TRUE customer match','CURRENT_DATE is recommended','CURRENT_TIMESTAMP_extra','customer','Direct']) {
  const draft=candidate('prose',{source_attributes:[],source_dependencies:[],preprocessing_rule:expression});
  assert.equal(review.concreteCandidate(draft),false,expression);
  const state=stateFor(h.blank());begin(state);deliver(state,[draft]);assert.equal(state.mappings[0].sourceColumn,null);assert.equal(state.mappings[0].expression,null);
 }
});

test('business reasoning keeps field names and separates mixed diagnostics without changing stored scores',()=>{
 assert.equal(review.businessReviewText('SI_FIRM identifies the firm. SQL compilation failed: bad tool call.'),'SI_FIRM identifies the firm.');
 for(const diagnostic of ['ValueError: private payload','Traceback: private path','packetreceipt missing','review needed','validation failed','AUTO_MAP_EVIDENCE_REVIEW_REQUIRED'])assert.equal(review.businessReviewText(diagnostic),'',diagnostic);
 assert.equal(review.businessReviewText('Names correspond. Citation receipts are missing.'),'Names correspond.');
 assert.equal(review.businessReviewText('Names correspond. SQL compilation failed:\nSELECT secret\nFROM internal_table\nPrivate diagnostic continuation'),'Names correspond.');
});

test('row join suggestion opens the matching bell recommendation instead of the editor or a saved mutation',()=>{
 const file=path.resolve(__dirname,'../src/features/sttm/mapping/mapping-row-candidates.tsx');const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 const callback=findInitializer(ast,'joinReview');const events=[],storage=[];
 const action=h.compile(`return (${callback.getText(ast)});`,{window:{sessionStorage:{setItem:(...args)=>storage.push(args)},dispatchEvent:event=>events.push(event)},CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}}});
 action({suggestion_id:'join-for-name',kind:'relationship'});assert.deepEqual(storage,[['sttm:focused-join-recommendation','join-for-name']]);assert.equal(events[0].type,'sttm:open-join-recommendation');assert.equal(events[0].detail.suggestionId,'join-for-name');
});
