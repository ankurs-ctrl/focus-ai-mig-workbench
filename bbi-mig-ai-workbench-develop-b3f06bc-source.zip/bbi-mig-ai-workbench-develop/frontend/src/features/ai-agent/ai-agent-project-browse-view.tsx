"use client";

import { useState, type ReactNode } from "react";
import { InputBase } from "@mui/material";
import {
  AiaBox,
  AiaButton,
  AiaDialog,
  AiaDialogActions,
  AiaDialogContent,
  AiaDialogTitle,
  AiaDivider,
  AiaIconButton,
  AiaMenu,
  AiaMenuItem,
  AiaStack,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { AI_AGENT_PAGE_CONTENT_MAX_WIDTH } from "@/features/ai-agent/ai-chat-layout-constants";
import type { StoredChatSession } from "@/features/ai-agent/ai-chat-session-utils";
import {
  CheckCircleRoundedIcon,
  DeleteOutlinedIcon,
  EditOutlinedIcon,
  FolderOpenIcon,
  MoreHorizIcon,
  SettingsOutlinedIcon,
} from "@/utils/icons";

type AiAgentProjectBrowseViewProps = {
  projectId: string;
  projectLabel: string;
  sessions: StoredChatSession[];
  activeSessionId: string | null;
  isUsingProject: boolean;
  canEditProject: boolean;
  composer: ReactNode;
  onSelectSession: (session: StoredChatSession) => void;
  onUseProject: () => void;
  onEditProject?: () => void;
  onRenameSession: (session: StoredChatSession, title: string) => void;
  onDeleteSession: (session: StoredChatSession) => void;
};

function formatSessionListDate(timestamp: number) {
  return new Date(timestamp).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}

function sessionSnippet(session: StoredChatSession) {
  const last = [...session.messages].reverse().find((message) => message.content?.trim());
  if (!last?.content?.trim()) return "No messages yet";
  const trimmed = last.content.trim().replace(/\s+/g, " ");
  return trimmed.length > 110 ? `${trimmed.slice(0, 110)}…` : trimmed;
}

export function AiAgentProjectBrowseView({
  projectId,
  projectLabel,
  sessions,
  activeSessionId,
  isUsingProject,
  canEditProject,
  composer,
  onSelectSession,
  onUseProject,
  onEditProject,
  onRenameSession,
  onDeleteSession,
}: AiAgentProjectBrowseViewProps) {
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null);
  const [chatMenuAnchor, setChatMenuAnchor] = useState<null | HTMLElement>(null);
  const [chatMenuSession, setChatMenuSession] = useState<StoredChatSession | null>(null);
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [renameSession, setRenameSession] = useState<StoredChatSession | null>(null);

  const closeChatMenu = () => {
    setChatMenuAnchor(null);
    setChatMenuSession(null);
  };

  const openRename = (session: StoredChatSession) => {
    setRenameSession(session);
    setRenameValue(session.title);
    setRenameOpen(true);
  };

  const submitRename = () => {
    if (!renameSession) return;
    const next = renameValue.trim();
    if (!next) return;
    onRenameSession(renameSession, next);
    setRenameOpen(false);
    setRenameSession(null);
    setRenameValue("");
  };

  return (
    <AiaBox
      sx={{
        flex: 1,
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        backgroundColor: "#FFFFFF",
      }}
    >
      <AiaBox
        sx={{
          px: { xs: 2.5, md: 4 },
          pt: 3,
          pb: 2,
          flexShrink: 0,
          width: "100%",
          maxWidth: AI_AGENT_PAGE_CONTENT_MAX_WIDTH,
          mx: "auto",
        }}
      >
        <AiaStack
          direction="row"
          sx={{ alignItems: "center", justifyContent: "space-between", gap: 1.5 }}
        >
          <AiaStack direction="row" spacing={1.25} sx={{ alignItems: "center", minWidth: 0 }}>
            <FolderOpenIcon sx={{ fontSize: 28, color: "#64748B", flexShrink: 0 }} />
            <AiaText
              sx={{
                fontSize: { xs: 26, md: 32 },
                fontWeight: 800,
                color: "#0F172A",
                letterSpacing: "-0.03em",
                lineHeight: 1.1,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              {projectLabel}
            </AiaText>
          </AiaStack>

          <AiaIconButton
            aria-label="Project options"
            title="Project options"
            onClick={(event) => setMenuAnchor(event.currentTarget)}
            sx={{
              width: 36,
              height: 36,
              border: "1px solid #E2E8F0",
              borderRadius: "50%",
              color: "#64748B",
              backgroundColor: "#FFFFFF",
              flexShrink: 0,
              "&:hover": { backgroundColor: "#F8FAFC" },
            }}
          >
            <MoreHorizIcon sx={{ fontSize: 20 }} />
          </AiaIconButton>
        </AiaStack>

        <AiaBox sx={{ mt: 2.5, width: "100%" }}>{composer}</AiaBox>

        <AiaStack direction="row" spacing={0.75} sx={{ mt: 2.25, alignItems: "center" }}>
          <AiaBox
            sx={{
              px: 1.5,
              py: 0.65,
              borderRadius: "999px",
              backgroundColor: "#F1F5F9",
            }}
          >
            <AiaText sx={{ fontSize: 13, fontWeight: 650, color: "#0F172A" }}>
              Chats
            </AiaText>
          </AiaBox>
        </AiaStack>
      </AiaBox>

      <AiaBox
        sx={{
          flex: 1,
          minHeight: 0,
          overflowY: "auto",
          px: { xs: 2.5, md: 4 },
          pb: 3,
          width: "100%",
          maxWidth: AI_AGENT_PAGE_CONTENT_MAX_WIDTH,
          mx: "auto",
        }}
      >
        {sessions.length === 0 ? (
          <AiaBox sx={{ py: 6, textAlign: "center" }}>
            <AiaText sx={{ fontSize: 14, color: "#94A3B8" }}>
              No chats in this project yet.
            </AiaText>
          </AiaBox>
        ) : (
          sessions.map((chatSession, index) => {
            const isActive = chatSession.id === activeSessionId;
            return (
              <AiaBox key={`${projectId}:${chatSession.id}`}>
                {index > 0 ? (
                  <AiaDivider sx={{ borderColor: "#EEF2F7", mx: 2 }} />
                ) : null}
                <AiaBox
                  sx={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    gap: 1.5,
                    px: 2,
                    py: 1.75,
                    borderRadius: "10px",
                    backgroundColor: isActive ? "#F8FAFC" : "transparent",
                    "&:hover": { backgroundColor: "#F8FAFC" },
                    "&:hover .chat-row-date": { opacity: 0, pointerEvents: "none" },
                    "&:hover .chat-row-actions": { opacity: 1 },
                  }}
                >
                  <AiaBox
                    component="button"
                    type="button"
                    onClick={() => onSelectSession(chatSession)}
                    sx={{
                      flex: 1,
                      minWidth: 0,
                      border: "none",
                      background: "transparent",
                      cursor: "pointer",
                      textAlign: "left",
                      display: "block",
                      p: 0,
                    }}
                  >
                    <AiaText
                      sx={{
                        fontSize: 15,
                        fontWeight: 700,
                        color: "#0F172A",
                        lineHeight: 1.35,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {chatSession.title}
                    </AiaText>
                    <AiaText
                      sx={{
                        mt: 0.45,
                        fontSize: 13,
                        color: "#94A3B8",
                        lineHeight: 1.45,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {sessionSnippet(chatSession)}
                    </AiaText>
                  </AiaBox>

                  <AiaBox
                    sx={{
                      position: "relative",
                      flexShrink: 0,
                      minWidth: 56,
                      alignSelf: "center",
                      height: 36,
                      display: "flex",
                      justifyContent: "flex-end",
                      alignItems: "center",
                    }}
                  >
                    <AiaText
                      className="chat-row-date"
                      sx={{
                        fontSize: 13,
                        color: "#94A3B8",
                        lineHeight: 1,
                        opacity:
                          chatMenuSession?.id === chatSession.id && Boolean(chatMenuAnchor)
                            ? 0
                            : 1,
                        transition: "opacity 120ms ease",
                        whiteSpace: "nowrap",
                        pr: 0.5,
                      }}
                    >
                      {formatSessionListDate(chatSession.updatedAt)}
                    </AiaText>
                    <AiaIconButton
                      className="chat-row-actions"
                      size="small"
                      aria-label={`${chatSession.title} options`}
                      title="Chat options"
                      onClick={(event) => {
                        event.stopPropagation();
                        setChatMenuSession(chatSession);
                        setChatMenuAnchor(event.currentTarget);
                      }}
                      sx={{
                        position: "absolute",
                        right: 0,
                        top: "50%",
                        transform: "translateY(-50%)",
                        opacity:
                          chatMenuSession?.id === chatSession.id && Boolean(chatMenuAnchor)
                            ? 1
                            : 0,
                        transition: "opacity 120ms ease",
                        color: "#64748B",
                        p: 0.5,
                        borderRadius: "6px",
                        "&:hover": { backgroundColor: "#E2E8F0" },
                      }}
                    >
                      <MoreHorizIcon sx={{ fontSize: 18 }} />
                    </AiaIconButton>
                  </AiaBox>
                </AiaBox>
              </AiaBox>
            );
          })
        )}
      </AiaBox>

      <AiaMenu
        anchorEl={menuAnchor}
        open={Boolean(menuAnchor)}
        onClose={() => setMenuAnchor(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        slotProps={{
          paper: {
            sx: {
              mt: 0.75,
              minWidth: 220,
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              backgroundColor: "#FFFFFF",
              boxShadow: "0 10px 30px rgba(15, 23, 42, 0.12)",
              py: 0.5,
            },
          },
        }}
      >
        <AiaMenuItem
          onClick={() => {
            setMenuAnchor(null);
            onUseProject();
          }}
          sx={{ py: 0.95 }}
        >
          <CheckCircleRoundedIcon
            sx={{
              fontSize: 16,
              color: isUsingProject ? "#2563EB" : "#64748B",
              mr: 1.25,
            }}
          />
          <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#0F172A" }}>
            {isUsingProject ? "Using this project" : "Use this project"}
          </AiaText>
        </AiaMenuItem>
        {canEditProject && onEditProject ? (
          <AiaMenuItem
            onClick={() => {
              setMenuAnchor(null);
              onEditProject();
            }}
            sx={{ py: 0.95 }}
          >
            <SettingsOutlinedIcon sx={{ fontSize: 16, color: "#64748B", mr: 1.25 }} />
            <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#0F172A" }}>
              Edit project
            </AiaText>
          </AiaMenuItem>
        ) : null}
      </AiaMenu>

      <AiaMenu
        anchorEl={chatMenuAnchor}
        open={Boolean(chatMenuAnchor)}
        onClose={closeChatMenu}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        slotProps={{
          paper: {
            sx: {
              mt: 0.5,
              minWidth: 180,
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              backgroundColor: "#FFFFFF",
              boxShadow: "0 10px 30px rgba(15, 23, 42, 0.12)",
              py: 0.5,
            },
          },
        }}
      >
        <AiaMenuItem
          onClick={() => {
            if (chatMenuSession) openRename(chatMenuSession);
            closeChatMenu();
          }}
          sx={{ py: 0.95 }}
        >
          <EditOutlinedIcon sx={{ fontSize: 16, color: "#64748B", mr: 1.25 }} />
          <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#0F172A" }}>
            Rename chat
          </AiaText>
        </AiaMenuItem>
        <AiaMenuItem
          onClick={() => {
            if (chatMenuSession) onDeleteSession(chatMenuSession);
            closeChatMenu();
          }}
          sx={{ py: 0.95 }}
        >
          <DeleteOutlinedIcon sx={{ fontSize: 16, color: "#DC2626", mr: 1.25 }} />
          <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#DC2626" }}>
            Delete chat
          </AiaText>
        </AiaMenuItem>
      </AiaMenu>

      <AiaDialog
        open={renameOpen}
        onClose={() => {
          setRenameOpen(false);
          setRenameSession(null);
        }}
        fullWidth
        maxWidth="xs"
      >
        <AiaDialogTitle sx={{ fontSize: 16, fontWeight: 700, color: "#0F172A" }}>
          Rename chat
        </AiaDialogTitle>
        <AiaDialogContent>
          <InputBase
            autoFocus
            fullWidth
            value={renameValue}
            onChange={(event) => setRenameValue(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                submitRename();
              }
            }}
            placeholder="Chat title"
            sx={{
              mt: 0.5,
              px: 1.25,
              py: 1,
              borderRadius: "10px",
              border: "1px solid #E2E8F0",
              fontSize: 14,
              color: "#0F172A",
            }}
          />
        </AiaDialogContent>
        <AiaDialogActions sx={{ px: 3, pb: 2 }}>
          <AiaButton
            onClick={() => {
              setRenameOpen(false);
              setRenameSession(null);
            }}
            sx={{ textTransform: "none", color: "#64748B" }}
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            onClick={submitRename}
            disabled={!renameValue.trim()}
            sx={{ textTransform: "none", fontWeight: 700 }}
          >
            Save
          </AiaButton>
        </AiaDialogActions>
      </AiaDialog>
    </AiaBox>
  );
}
