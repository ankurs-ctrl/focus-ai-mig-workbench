-- ============================================================
-- SP_FIR_INVOKE_AGENT
-- Bridge procedure called by Snowflake Tasks to invoke AGT_FIR_SYSTEM.
-- Gathers stream state, builds context, and calls the agent.
-- The agent then uses its tools (procedures + cortex search) to
-- intelligently process feedback, parse documents, generate inferences,
-- and create recommendations.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_INVOKE_AGENT(
    "TASK_PAYLOAD" VARIANT DEFAULT NULL
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'invoke_agent'
EXECUTE AS CALLER
AS
$$
import json
import _snowflake
from datetime import datetime


def _current_namespace(session):
    row = session.sql("SELECT CURRENT_DATABASE() AS DB, CURRENT_SCHEMA() AS SCH").collect()[0]
    return str(row["DB"]), str(row["SCH"])


def _check_streams(session, namespace):
    """Check which streams have data to build context for the agent."""
    streams = [
        'STM_FIR_WORKBENCH_FEEDBACK',
        'STM_FIR_STTM_ATTRIBUTES',
        'STM_FIR_DERIVED_SOURCES',
        'STM_FIR_SEM_TABLE_VIEWS',
        'STM_FIR_CONVERSATION_TURNS',
        'STM_FIR_STTM_VERSIONS',
        'STM_FIR_CLIENT_SQL_ASSETS',
    ]
    streams_with_data = []
    for stream_name in streams:
        try:
            result = session.sql(
                f"SELECT SYSTEM$STREAM_HAS_DATA('{namespace}.{stream_name}') AS HAS_DATA"
            ).collect()
            if result and str(result[0]['HAS_DATA']).lower() == 'true':
                streams_with_data.append(stream_name)
        except Exception:
            pass
    return streams_with_data


def _get_pending_counts(session, namespace):
    """Get counts of pending records at each processing stage."""
    counts = {}
    try:
        rows = session.sql(f"""
            SELECT PROCESSING_STAGE, COUNT(*) AS CNT
            FROM {namespace}.TBL_AGENT_FIR_360
            WHERE PROCESSING_STAGE IN ('pending', 'feedback_collected', 'inference_generated')
            GROUP BY PROCESSING_STAGE
        """).collect()
        for row in rows:
            counts[row['PROCESSING_STAGE']] = row['CNT']
    except Exception:
        pass
    return counts


def _get_unprocessed_documents(session, namespace):
    """Check for documents that haven't been processed by the FIR agent yet."""
    try:
        rows = session.sql(f"""
            SELECT
                a.SQL_ASSET_ID,
                a.TITLE,
                a.SQL_KIND,
                a.DIALECT,
                LENGTH(a.SQL_TEXT) AS SQL_LENGTH,
                a.DESCRIPTION,
                a.CREATED_AT
            FROM {namespace}.TBL_WORKBENCH_CLIENT_SQL_ASSETS a
            LEFT JOIN {namespace}.TBL_AGENT_FIR_360 f
                ON f.SOURCE_TYPE = 'document_upload'
                AND f.FEEDBACK_PAYLOAD:sql_asset_id::STRING = a.SQL_ASSET_ID
            WHERE f.FIR_RECORD_ID IS NULL
              AND a.STATUS = 'active'
            ORDER BY a.CREATED_AT DESC
            LIMIT 20
        """).collect()
        return [
            {
                'sql_asset_id': row['SQL_ASSET_ID'],
                'title': row['TITLE'],
                'sql_kind': row['SQL_KIND'],
                'dialect': row['DIALECT'],
                'sql_length': row['SQL_LENGTH'],
                'description': row['DESCRIPTION'],
                'created_at': str(row['CREATED_AT']) if row['CREATED_AT'] else None
            }
            for row in rows
        ]
    except Exception:
        return []


def _get_recent_activity_summary(session, namespace):
    """Get summary of recent FIR activity for agent context."""
    summary = {}
    try:
        rows = session.sql(f"""
            SELECT SOURCE_TYPE, COUNT(*) AS CNT
            FROM {namespace}.TBL_AGENT_FIR_360
            WHERE CREATED_AT > DATEADD('hour', -24, CURRENT_TIMESTAMP())
            GROUP BY SOURCE_TYPE
        """).collect()
        summary['last_24h_by_source'] = {row['SOURCE_TYPE']: row['CNT'] for row in rows}
    except Exception:
        pass

    try:
        rows = session.sql(f"""
            SELECT COUNT(*) AS CNT
            FROM {namespace}.TBL_FIR_AGENT_RECOMMENDATIONS
            WHERE STATUS = 'active'
        """).collect()
        summary['active_recommendations'] = rows[0]['CNT'] if rows else 0
    except Exception:
        pass

    return summary


def invoke_agent(session, task_payload=None) -> dict:
    """Main handler: builds context and invokes AGT_FIR_SYSTEM."""
    current_database, current_schema = _current_namespace(session)
    namespace = f"{current_database}.{current_schema}"

    result = {
        'status': 'success',
        'agent_invoked': False,
        'agent_response': None,
        'context_built': {},
        'started_at': datetime.utcnow().isoformat(),
        'errors': []
    }

    try:
        # Build context for the agent
        streams_with_data = _check_streams(session, namespace)
        pending_counts = _get_pending_counts(session, namespace)
        unprocessed_docs = _get_unprocessed_documents(session, namespace)
        activity_summary = _get_recent_activity_summary(session, namespace)

        # Parse task payload
        payload_opts = {}
        if task_payload:
            if isinstance(task_payload, str):
                try:
                    payload_opts = json.loads(task_payload)
                except Exception:
                    pass
            else:
                payload_opts = dict(task_payload) if task_payload else {}

        # Determine what work needs to be done
        task_type = payload_opts.get('task_type', 'stream_triggered')
        has_stream_data = len(streams_with_data) > 0
        has_pending_records = sum(pending_counts.values()) > 0
        has_unprocessed_docs = len(unprocessed_docs) > 0

        # Manual, document_learning, and semantic_precomputation tasks always proceed
        force_run = task_type in ('manual', 'document_learning', 'semantic_precomputation')

        if not force_run and not has_stream_data and not has_pending_records and not has_unprocessed_docs:
            result['status'] = 'no_work'
            result['context_built'] = {
                'streams_checked': 7,
                'streams_with_data': 0,
                'pending_records': 0,
                'unprocessed_documents': 0
            }
            return result

        # Build the agent message with full context
        processing_options = payload_opts.get('processing_options', {
            'collect_feedback': True,
            'generate_inferences': True,
            'create_semantic_versions': True,
            'generate_recommendations': True,
            'apply_decay': False,
            'parse_documents': has_unprocessed_docs
        })

        base_instructions = (
            'Process the FIR pipeline based on the context provided. '
            'Streams with data indicate new user activity to collect. '
            'Pending records need inference generation and recommendation creation. '
            'Unprocessed documents need to be read with ReadDocuments, '
            'analyzed for mapping patterns, transformations, join logic, '
            'and business rules, then fed into the pipeline as document_upload feedback. '
            'Use SearchFIRInferences to check for duplicates before creating new inferences. '
            'Use SearchFIRRecommendations to avoid duplicate recommendations. '
            'For each document, deeply parse the SQL to extract: '
            '1. Tables referenced (source and target) '
            '2. Column mappings (which source columns map to which target columns) '
            '3. Transformation patterns (CASE, CAST, CONCAT, date functions, etc.) '
            '4. Join patterns (how tables are related) '
            '5. Business rules (WHERE clauses, CASE logic that encodes business meaning) '
            '6. Data quality patterns (TRIM, UPPER, COALESCE for nulls) '
            'Store all extracted knowledge as rich inferences that other agents can use.'
        )

        if task_type == 'document_learning':
            base_instructions += (
                ' PRIORITY: This is a document_learning run triggered by user uploading a file '
                'and choosing "Use as Highest-Priority Learning". Process ALL unprocessed documents '
                'immediately. Generate comprehensive recommendations for ALL agents covering every '
                'pattern found. Also run Phase 2.5 (Semantic Pre-computation) for tables mentioned '
                'in the document. The user is waiting for this to complete — be thorough but efficient.'
            )
            priority_asset = processing_options.get('priority_asset_id')
            if priority_asset:
                base_instructions += f' Priority asset ID: {priority_asset}.'

        agent_message = {
            'task_type': task_type,
            'streams_with_data': streams_with_data,
            'pending_counts': pending_counts,
            'unprocessed_documents': unprocessed_docs,
            'activity_summary': activity_summary,
            'batch_size': payload_opts.get('batch_size', 100),
            'processing_options': processing_options,
            'instructions': base_instructions,
        }

        if payload_opts.get('precomputation_context'):
            agent_message['precomputation_context'] = payload_opts['precomputation_context']

        result['context_built'] = {
            'streams_with_data': streams_with_data,
            'pending_counts': pending_counts,
            'unprocessed_document_count': len(unprocessed_docs),
            'activity_summary': activity_summary
        }

        # Invoke the agent
        agent_payload = {
            'models': {'orchestration': 'claude-sonnet-4-6'},
            'messages': [
                {
                    'role': 'user',
                    'content': [{'type': 'text', 'text': json.dumps(agent_message)}]
                }
            ],
            'stream': False
        }

        response = _snowflake.send_snow_api_request(
            'POST',
            f'/api/v2/databases/{current_database}/schemas/{current_schema}/agents/AGT_FIR_SYSTEM:run',
            {},
            {},
            agent_payload,
            None,
            300000  # 5 minute timeout for batch processing
        )

        result['agent_invoked'] = True

        if response is None:
            result['status'] = 'agent_error'
            result['errors'].append('Null response from Cortex Agent API')
            return result

        status_code = response.get('status', 0)
        body_raw = response.get('content', '{}')
        body = body_raw if isinstance(body_raw, dict) else json.loads(body_raw)

        if status_code not in (200, 201):
            result['status'] = 'agent_error'
            result['errors'].append(f'Agent HTTP {status_code}: {json.dumps(body)[:500]}')
            return result

        # Extract agent response text
        agent_text = ''
        content_blocks = body.get('content', [])
        for block in content_blocks:
            if isinstance(block, dict) and block.get('type') == 'text':
                agent_text = block.get('text', '')
                break

        # Try to parse as JSON (agent should return structured response)
        try:
            result['agent_response'] = json.loads(agent_text)
        except Exception:
            result['agent_response'] = {'raw_text': agent_text[:2000]}

        result['completed_at'] = datetime.utcnow().isoformat()

    except Exception as e:
        result['status'] = 'failed'
        result['errors'].append(str(e))

    return result
$$;
