"""CTEs the agent writes when the data needs them, in the shape a user builds in the UI.

Two patterns are detected from the data and the mapping rules, never from
table or column names:

- **One row per key for a lookup.** A lookup whose join key repeats (a code
  table with the same code on several rows) multiplies the driving rows. The
  lookup is replaced by ``SELECT * FROM <lookup> QUALIFY ROW_NUMBER() OVER
  (PARTITION BY <key> ORDER BY <deterministic columns>) = 1``, joined on the same
  key.
- **An aggregate per driving key.** A rule that combines several child rows
  (``LISTAGG``, ``COUNT``, ``MAX`` ...) cannot run at the driving grain. It
  moves into ``SELECT <key>, <aggregate> FROM <child path> GROUP BY <key>``,
  joined one-to-one to the driving source, and the column reads the CTE's
  output.

Every CTE is returned as a full builder derived-source object (see
``app.core.workspace_snapshot.canonical_derived_source``) plus the edge that
joins it, so the draft opens in the UI like a CTE a user added by hand.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any, Iterable

from sqlglot import exp, parse_one

from app.core.workspace_snapshot import canonical_derived_source, derived_reference_prefix, relation_alias_for

_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*")
_AGGREGATES = (exp.AggFunc,)


def _slug(value: str, limit: int = 48) -> str:
    return re.sub(r"_+", "_", re.sub(r"[^a-z0-9_]", "_", value.lower())).strip("_")[:limit] or "cte"


def _cte_id(*parts: str) -> str:
    return "agent_cte_" + hashlib.sha256("|".join(parts).upper().encode("utf-8")).hexdigest()[:20]


def _column_list(columns: Iterable[str]) -> str:
    return ", ".join(columns)


# ---------------------------------------------------------------------------
# One row per key for a lookup
# ---------------------------------------------------------------------------

def dedup_lookup_sql(table_fqn: str, key_columns: list[str], order_columns: list[str]) -> str:
    if not key_columns or not all(_IDENTIFIER.fullmatch(value) for value in [*key_columns, *order_columns]):
        raise ValueError("Lookup keys and ordering columns must be plain identifiers")
    order = _column_list(order_columns or key_columns)
    return (
        f"SELECT *\nFROM {table_fqn}\n"
        f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {_column_list(key_columns)} ORDER BY {order}) = 1"
    )


def dedup_lookup(
    *,
    table: dict[str, str],
    key_columns: list[str],
    order_columns: list[str],
    columns: list[dict[str, Any]],
    duplicate_keys: int,
    total_rows: int,
) -> dict[str, Any]:
    """A one-row-per-key lookup CTE with its purpose and grain written out."""
    fqn = f"{table['database']}.{table['schema']}.{table['table']}"
    sql = dedup_lookup_sql(fqn, key_columns, order_columns)
    return canonical_derived_source({
        "id": _cte_id(fqn, *key_columns, "dedup"),
        "name": _slug(f"{table['table']}_one_per_{'_'.join(key_columns)}"),
        "sql_text": sql,
        "purpose": (
            f"{table['table']} has {duplicate_keys} {'key' if duplicate_keys == 1 else 'keys'} repeated across "
            f"{total_rows} rows; this keeps one row per {', '.join(key_columns)} (first by "
            f"{', '.join(order_columns or key_columns)}) so the join does not multiply the driving rows."
        ),
        "grain": f"One row per {', '.join(key_columns)}",
        "keys": list(key_columns),
        "output_columns": [
            {"name": column.get("name"), "data_type": column.get("data_type") or column.get("type")}
            for column in columns if isinstance(column, dict) and column.get("name")
        ],
        "base_source_tables": [table],
        "origin": "agent",
    })


def _literal(value: Any) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def reduce_child(
    *,
    table: dict[str, str],
    key_columns: list[str],
    order_columns: list[str],
    filters: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    parent_name: str,
    rows: int,
    keys: int,
) -> dict[str, Any]:
    """One child row per parent key, so a 1:N child does not multiply the driving rows.

    The child's join filter (for example ``ADDRESSABLE_TYPE = 'Crm::Contact'``)
    moves inside the CTE. ``lineage.reduced_from`` records the unreduced table
    and filters, so a rule that combines all child rows can still aggregate
    over every row instead of the one kept here.
    """
    fqn = f"{table['database']}.{table['schema']}.{table['table']}"
    if not key_columns or not all(_IDENTIFIER.fullmatch(value) for value in [*key_columns, *order_columns]):
        raise ValueError("Child keys and ordering columns must be plain identifiers")
    if not all(_IDENTIFIER.fullmatch(str(item.get("column") or "")) for item in filters):
        raise ValueError("Child filter columns must be plain identifiers")
    where = " AND ".join(f"{item['column']} = {_literal(item.get('value'))}" for item in filters)
    order = _column_list(order_columns or key_columns)
    sql = (
        f"SELECT *\nFROM {fqn}\n" + (f"WHERE {where}\n" if where else "")
        + f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {_column_list(key_columns)} ORDER BY {order}) = 1"
    )
    ratio = rows / keys if keys else 0.0
    return canonical_derived_source({
        "id": _cte_id(fqn, *key_columns, where, "one_per_parent"),
        "name": _slug(f"{table['table']}_one_per_{parent_name}"),
        "sql_text": sql,
        "purpose": (
            f"{table['table']} has {rows} rows for {keys} {parent_name} keys ({ratio:.1f} per key)"
            + (f" where {where}" if where else "")
            + f"; this keeps one row per {', '.join(key_columns)} (first by {order}) so each {parent_name} "
            "row appears once. Rules that combine all of its rows aggregate over the full table."
        ),
        "grain": f"One row per {', '.join(key_columns)}",
        "keys": list(key_columns),
        "output_columns": [
            {"name": column.get("name"), "data_type": column.get("data_type") or column.get("type")}
            for column in columns if isinstance(column, dict) and column.get("name")
        ],
        "base_source_tables": [table],
        "lineage": [{"reduced_from": {"table": fqn, "filters": list(filters)}, "origin": "agent"}],
        "origin": "agent",
    })


def dedup_order_columns(contract: dict[str, Any], key_columns: list[str]) -> list[str]:
    """A deterministic order: the table's primary key, else every other column in contract order."""
    keys = {value.upper() for value in key_columns}
    primary = [str(value) for value in contract.get("key_columns") or [] if str(value).upper() not in keys]
    if primary:
        return primary
    return [
        str(column.get("name")) for column in contract.get("column_contracts") or []
        if isinstance(column, dict) and column.get("name") and str(column["name"]).upper() not in keys
        and _IDENTIFIER.fullmatch(str(column["name"]))
    ][:16]


# ---------------------------------------------------------------------------
# An aggregate per driving key
# ---------------------------------------------------------------------------

@dataclass
class AggregatePlan:
    derived_source: dict[str, Any]
    edge: dict[str, Any]
    expression: str
    source_column: str
    explanation: str
    relations: list[str] = field(default_factory=list)


def _relation_resolver(nodes: list[dict[str, Any]], derived_names: dict[str, str]) -> dict[str, str]:
    """Qualifier text (FQN, S.T, T, alias, CTE prefix) to relation id; ambiguous short forms dropped."""
    resolver: dict[str, str] = {}
    ambiguous: set[str] = set()

    def add(key: str, relation_id: str) -> None:
        token = key.replace('"', "").upper()
        if not token:
            return
        if token in resolver and resolver[token] != relation_id:
            ambiguous.add(token)
        resolver[token] = relation_id

    for node in nodes:
        relation_id = node["relation_id"]
        add(relation_id, relation_id)
        add(node.get("alias") or "", relation_id)
        table = node.get("table")
        if table:
            add(f"{table['schema']}.{table['table']}", relation_id)
            add(table["table"], relation_id)
        else:
            add(derived_reference_prefix(derived_names.get(relation_id, relation_id)), relation_id)
    for token in ambiguous:
        resolver.pop(token, None)
    return resolver


def _qualifier(column: exp.Column) -> str:
    return ".".join(part for part in (column.catalog, column.db, column.table) if part)


def _path(edges: list[dict[str, Any]], start: str, goal: str, max_hops: int) -> list[dict[str, Any]] | None:
    frontier: list[tuple[str, list[dict[str, Any]]]] = [(start, [])]
    seen = {start}
    while frontier:
        node, path = frontier.pop(0)
        if node == goal:
            return path
        if len(path) >= max_hops:
            continue
        for edge in edges:
            if node not in (edge["left_relation_id"], edge["right_relation_id"]):
                continue
            other = edge["right_relation_id"] if edge["left_relation_id"] == node else edge["left_relation_id"]
            if other in seen:
                continue
            seen.add(other)
            frontier.append((other, [*path, edge]))
    return None


def _oriented(edge: dict[str, Any], near: str) -> list[tuple[str, str]]:
    """(near column, far column) pairs of an edge seen from ``near``."""
    forward = edge["left_relation_id"] == near
    return [
        (condition["left_column"], condition["right_column"]) if forward
        else (condition["right_column"], condition["left_column"])
        for condition in edge.get("conditions") or []
    ]


def aggregate_per_key(
    *,
    target_column: str,
    target_type: str | None,
    expression: str,
    graph: dict[str, Any],
    driving_id: str,
    derived_names: dict[str, str] | None = None,
    max_hops: int = 2,
    reductions: dict[str, dict[str, Any]] | None = None,
) -> AggregatePlan | None:
    """Move a row-combining rule into a per-driving-key aggregate CTE, or None when it cannot be done safely.

    The rule may read only relations on one join path away from the driving
    source (at most ``max_hops`` joins); the CTE groups by the column that
    joins the path's first table to the driving source, so it joins back one
    row per driving key. ``reductions`` maps a one-row-per-parent child CTE
    to the table (and filters) it was reduced from: an aggregate reads every
    child row, not the one the reduction kept.
    """
    reductions = reductions or {}
    try:
        tree = parse_one(expression, read="snowflake")
    except Exception:
        return None
    if not any(isinstance(node, _AGGREGATES) for node in tree.walk()) or tree.find(exp.Window):
        return None
    nodes = list(graph.get("nodes") or [])
    by_id = {node["relation_id"]: node for node in nodes}
    resolver = _relation_resolver(nodes, derived_names or {})
    columns = list(tree.find_all(exp.Column))
    used: set[str] = set()

    def physical(relation_id: str) -> bool:
        return by_id[relation_id].get("table") is not None or relation_id in reductions

    for column in columns:
        relation_id = resolver.get(_qualifier(column).upper())
        if relation_id is None or relation_id == driving_id or not physical(relation_id):
            return None
        used.add(relation_id)
    if not used:
        return None
    edges = list(graph.get("edges") or [])
    paths = {relation_id: _path(edges, driving_id, relation_id, max_hops) for relation_id in used}
    if any(path is None or not path for path in paths.values()):
        return None
    first_hops = {path[0]["edge_id"] for path in paths.values() if path}
    if len(first_hops) != 1:
        return None
    first_edge = next(iter(paths.values()))[0]
    anchor = first_edge["right_relation_id"] if first_edge["left_relation_id"] == driving_id else first_edge["left_relation_id"]
    key_pairs = _oriented(first_edge, driving_id)  # (driving column, anchor column)
    if not key_pairs or not all(_IDENTIFIER.fullmatch(value) for pair in key_pairs for value in pair):
        return None

    # Tables inside the CTE, with local aliases; joins follow the path edges.
    members: list[str] = [anchor]
    joins: list[tuple[str, dict[str, Any], str]] = []
    for path in paths.values():
        near = anchor
        for edge in path[1:]:
            far = edge["right_relation_id"] if edge["left_relation_id"] == near else edge["left_relation_id"]
            if far not in members:
                if not physical(far):
                    return None
                members.append(far)
                joins.append((near, edge, far))
            near = far
    local = {relation_id: f"t{index + 1}" for index, relation_id in enumerate(members)}

    def localize(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Column):
            relation_id = resolver.get(_qualifier(node).upper())
            if relation_id in local:
                return exp.column(node.name, table=local[relation_id], quoted=node.this.quoted)
        return node

    def source_of(relation_id: str) -> str:
        return str(reductions[relation_id]["table"]) if relation_id in reductions else by_id[relation_id]["relation_id"]

    aggregate_sql = tree.copy().transform(localize).sql(dialect="snowflake")
    output_name = re.sub(r"[^A-Za-z0-9_]", "_", target_column).upper()
    key_select = ", ".join(f"{local[anchor]}.{anchor_column} AS {anchor_column}" for _, anchor_column in key_pairs)
    group_by = ", ".join(f"{local[anchor]}.{anchor_column}" for _, anchor_column in key_pairs)
    from_lines = [f"FROM {source_of(anchor)} AS {local[anchor]}"]
    for near, edge, far in joins:
        predicates = " AND ".join(
            f"{local[near]}.{near_column} = {local[far]}.{far_column}" for near_column, far_column in _oriented(edge, near)
        )
        from_lines.append(f"JOIN {source_of(far)} AS {local[far]}\n  ON {predicates}")
    filters = [
        f"{local[member]}.{item['column']} = {_literal(item.get('value'))}"
        for member in members for item in (reductions.get(member) or {}).get("filters") or []
        if _IDENTIFIER.fullmatch(str(item.get("column") or ""))
    ]
    if filters:
        from_lines.append("WHERE " + " AND ".join(filters))
    sql = "\n".join([f"SELECT {key_select},\n  {aggregate_sql} AS {output_name}", *from_lines, f"GROUP BY {group_by}"])

    driving_table = (by_id[driving_id].get("table") or {}).get("table") or driving_id
    name = _slug(f"{target_column}_per_{driving_table}")
    source_id = _cte_id(driving_id, target_column, sql)
    anchor_types = {
        str(column.get("name") or "").upper(): column.get("data_type")
        for column in by_id[anchor].get("output_columns") or [] if isinstance(column, dict)
    }
    derived = canonical_derived_source({
        "id": source_id,
        "name": name,
        "sql_text": sql,
        "purpose": f"Combines the rows behind {target_column} into one value per {driving_table} key.",
        "grain": f"One row per {', '.join(anchor_column for _, anchor_column in key_pairs)}",
        "keys": [anchor_column for _, anchor_column in key_pairs],
        "output_columns": [
            *({"name": anchor_column, "data_type": anchor_types.get(anchor_column.upper())} for _, anchor_column in key_pairs),
            {"name": output_name, "data_type": target_type},
        ],
        "base_source_tables": [
            table_ref for member in members
            if (table_ref := (by_id[member].get("table") or _ref_of(reductions.get(member, {}).get("table"))))
        ],
        "origin": "agent",
    })
    edge = {
        "edge_id": f"{source_id}:join",
        "left_relation_id": driving_id,
        "right_relation_id": source_id,
        "join_type": "LEFT",
        "provenance": "CTE_DESIGNER",
        "conditions": [
            {"left_column": driving_column, "operator": "=", "right_column": anchor_column}
            for driving_column, anchor_column in key_pairs
        ],
    }
    prefix = derived_reference_prefix(name)
    return AggregatePlan(
        derived_source=derived,
        edge=edge,
        expression=f"{prefix}.{output_name}",
        source_column=f"{prefix}.{output_name}",
        explanation=(
            f"The rule combines several {', '.join(sorted(_leaf_of(source_of(r)) for r in used))} rows, so it "
            f"now runs in CTE {name} (one row per {driving_table} key) and the column reads its result."
        ),
        relations=sorted(used),
    )


def alias_for(derived: dict[str, Any]) -> str:
    return relation_alias_for(derived["id"], derived["name"])


def _ref_of(fqn: Any) -> dict[str, str] | None:
    parts = str(fqn or "").split(".")
    return {"database": parts[0], "schema": parts[1], "table": parts[2]} if len(parts) == 3 else None


def _leaf_of(fqn: str) -> str:
    return str(fqn).rsplit(".", 1)[-1]
