export type AgentSqlArtifact = {
  mappingName?: string;
  sql: string;
  compileValid: boolean;
  previewValid: boolean;
  previewColumns: string[];
  previewRows: string[];
  previewRowCount: number;
  mappedCount: number;
  unresolvedCount: number;
  /** ready | compile_failed | preview_failed | blocked | no_source (from the run's target summary). */
  status?: string;
  targetTable?: string;
  sttmId?: string | null;
  error?: string | null;
  reason?: string | null;
};

type TargetStatus = {
  mapping_name?: string;
  target_table?: string;
  status?: string;
  compile_valid?: boolean;
  preview_valid?: boolean;
  mapped?: number;
  unresolved?: number;
  sttm_id?: string | null;
  error?: string | null;
  reason?: string | null;
};

export const TARGET_STATUS_LABELS: Record<string, string> = {
  ready: 'Draft generated',
  needs_review: 'Draft generated',
  compile_failed: 'Compile failed',
  preview_failed: 'Preview failed',
  blocked: 'Blocked',
  no_source: 'No source',
};

const SUMMARY_MARKER = /\n*<!--aia:mapping-summaries:([\s\S]*?)-->/;

function targetStatuses(content: string): TargetStatus[] {
  const match = content.match(SUMMARY_MARKER);
  if (!match) return [];
  try {
    const parsed = JSON.parse(match[1]) as unknown;
    return Array.isArray(parsed) ? (parsed as TargetStatus[]) : [];
  } catch {
    return [];
  }
}

/** Keep durable transcript content intact; move recognized compiled artifacts to the review pane in the UI. */
export function separateSqlPreview(content: string): {
  message: string;
  artifacts: AgentSqlArtifact[];
  artifact: AgentSqlArtifact | null;
} {
  const statuses = targetStatuses(content);
  let message = content.replace(SUMMARY_MARKER, '');
  const pattern = /\n*### ([^\n]+): compiled SQL\n(Compile (?:passed|needs review|not passed); sample preview (?:passed|needs review|not passed)\.)\n```sql\n([\s\S]*?)\n```(?:\n\nSample results \(up to 5 rows\):\n```text\n([\s\S]*?)\n```)?/g;
  const sections = [...message.matchAll(pattern)];
  if (sections.some((section) => !section[3]?.trim())) {
    return { message: content, artifacts: [], artifact: null };
  }
  const artifacts: AgentSqlArtifact[] = sections.map((section) => {
    const rows = section[4]?.trim().split('\n').filter(Boolean) ?? [];
    message = message.replace(section[0], `\n\n### ${section[1]}\n${section[2]} SQL and sample rows are in the results panel.`);
    return {
      mappingName: section[1], sql: section[3].trim(),
      compileValid: section[2].includes('Compile passed'),
      previewValid: section[2].includes('sample preview passed'),
      previewColumns: [], previewRows: rows, previewRowCount: rows.length,
      mappedCount: 0, unresolvedCount: 0,
    };
  });
  // Every requested target gets a tab, including those with no SQL yet.
  for (const status of statuses) {
    const name = status.mapping_name ?? status.target_table?.split('.').pop() ?? 'Mapping';
    const existing = artifacts.find((artifact) => artifact.mappingName === name);
    const details = {
      status: status.status,
      targetTable: status.target_table,
      sttmId: status.sttm_id ?? null,
      error: status.error ?? null,
      reason: status.reason ?? null,
      mappedCount: status.mapped ?? 0,
      unresolvedCount: status.unresolved ?? 0,
    };
    if (existing) {
      Object.assign(existing, details);
    } else {
      artifacts.push({
        mappingName: name, sql: '', compileValid: Boolean(status.compile_valid), previewValid: Boolean(status.preview_valid),
        previewColumns: [], previewRows: [], previewRowCount: 0, ...details,
      });
    }
  }
  if (!artifacts.length) {
    return { message: message.trim(), artifacts: [], artifact: null };
  }
  return { message: message.trim(), artifacts, artifact: artifacts.find((artifact) => artifact.sql) ?? artifacts[0] };
}
