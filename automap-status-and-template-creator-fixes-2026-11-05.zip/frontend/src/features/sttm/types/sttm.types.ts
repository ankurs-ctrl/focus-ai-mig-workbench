
import type { UserSession } from "@/types/user";
import type {
  AutoMapCandidate,
  AutoMapSuggestion,
  AssistantInferenceRecord,
  AssistantPreferenceState,
  AssistantSignal,
  FIRRecommendation,
  MappingIntent,
  SemanticContextBundleResponse,
  SemanticContextItem,
  TableRef,
} from "@/types/api-contract";

export interface Sttm {
  id?: string;
  name?: string;
  description?: string;
  createdAt?: string;
  updatedAt?: string;
}

// -----------------
// Table relationship / filter builder types
// -----------------
export interface Column {
  name?: string;
  type?: string;
  isPrimaryKey?: boolean;
  isForeignKey?: boolean;
  tableId?: string;
  tableName?: string;
  selected?: boolean;
}

export interface TableMeta {
  id?: string;
  name?: string;
  schema?: string;
  database?: string;
  rowCount?: string;
  colCount?: number;
  columns?: Column[];
  tag?: string;
  /** Soft chip background / text (UX-aligned) */
  tagBg?: string;
  tagFg?: string;
}

export interface JoinConfig {
  id?: string;
  sqlPredicate?: string;
  joinType?: "INNER" | "LEFT" | "RIGHT" | "FULL";
  leftTableId?: string;
  rightTableId?: string;
  constraintName?: string;
  /** LEARNED: confirmed in a published mapping, validated SQL upload or an accepted join. */
  source?: "FOREIGN_KEY" | "USER_DEFINED" | "SEMANTIC_VIEW" | "LEARNED";
  locked?: boolean;
  /** Candidate semantic join. It must not participate in SQL until approved. */
  reviewRequired?: boolean;
  confidence?: number | null;
  reviewReason?: string | null;
  evidence?: Record<string, unknown> | null;
  conditions?: {
    leftColumn?: string;
    operator?: string;
    rightColumn?: string;
    /** How this condition attaches to the previous one. Ignored on the first condition. */
    connector?: "AND" | "OR";
  }[];
}

/** Hierarchical filter / WHERE builder (`FilterConditions`). */
export type RuleLogic = "AND" | "OR" | "NOT";

export type RuleCondition = {
  id: string;
  type: "condition";
  field: string;
  operator: string;
  value: string;
  valueMode?: "literal" | "field";
  valueField?: string;
  secondaryValue?: string;
  secondaryValueMode?: "literal" | "field";
  secondaryValueField?: string;
};

export type RuleGroup = {
  id: string;
  type: "group";
  logic: RuleLogic;
  children: (RuleGroup | RuleCondition)[];
};

export type RuleNode = RuleGroup | RuleCondition;

export interface DerivedSource {
  id: string;
  projectId?: string | null;
  sourceName: string;
  isSelected?: boolean;
  derivedSourceIds?: string[];
  parentDerivedSourceIds?: string[];
  sqlText?: string;
  definitionSql?: string;
  queryScope?: Record<string, unknown>;
  semanticBundleId?: string | null;
  semanticBundleLabel?: string | null;
  semanticViewName?: string | null;
  semanticLevel?: string | null;
  upstreamHash?: string | null;
  sourceDependencyHash?: string | null;
  physicalViewName?: string | null;
  generatedByRequestId?: string | null;
  purpose?: string | null;
  businessDescription?: string | null;
  grain?: string | null;
  keys?: string[];
  outputColumns?: Array<Record<string, unknown>>;
  columnSemantics?: Array<Record<string, unknown>>;
  semanticProjection?: Record<string, unknown>;
  semanticQuality?: string | null;
  lineageDepth?: number;
  alias?: string;
  drivingTableId?: string;
  tableIds?: string[];
  baseSourceTables?: TableRef[];
  selectedColumnsByTable?: Record<string, string[]>;
  joins: {
    id: string;
    sqlPredicate?: string;
    joinType: "INNER" | "LEFT" | "RIGHT" | "FULL";
    leftTableId: string;
    rightTableId: string;
    conditions: {
      id: string;
      leftColumn: string;
      operator: string;
      rightColumn: string;
      connector?: "AND" | "OR";
    }[];
  }[];
  filters: RuleGroup[];
  columns: Column[];
  previewColumns?: Array<{
    name: string;
    dataType: string;
    isPrimaryKey?: boolean;
  }>;
  previewRows?: Array<Record<string, unknown>>;
}

// -----------------
// Builder node types (hierarchical: DB → Schema → Table)
// -----------------
export type SelectionSide = "source" | "target";

export type TableNode = {
  tableId: string;
  tableName: string;
  qualifiedName: string;
  isSelected: boolean;
  tag: string;
  rows: string;
  columns: number;
  columnItems?: Column[];
};

export type SchemaNode = {
  schemaId: string;
  schemaName: string;
  isSelected: boolean;
  tables: TableNode[];
  tablesLoaded: boolean;
};

export type DatabaseNode = {
  dbId: string;
  dbName: string;
  dbType: string;
  connectionId: string;
  isSelected: boolean;
  schemas: SchemaNode[];
  schemasLoaded: boolean;
};

export type SourceTargetInfo = {
  dbName: string;
  schemaName: string;
};

export type ColumnGroup = {
  table: string;
  qualifiedName: string;
  columns: Column[];
};

/** Pre-filled builder workspace used when opening a saved mapping from the list. */
export type MappingWorkspaceSnapshot = {
  sources: TableNode[];
  targets: TableNode[];
  sourceAttributeGroups: ColumnGroup[];
  targetAttributeGroup: ColumnGroup;
  mappings: MappingState[];
  relationships?: JoinConfig[];
  drivingTableId?: string | null;
};

export type MappingSuggestion = {
  targetAttribute: string;
  sourceAttributes: string[];
  confidenceScore: number;
  confidenceReason?: string | null;
  candidateSourceAttributes?: string[];
  unmatchedReason?: string | null;
  preprocessingRule?: string | null;
  preprocessingRuleType?: string | null;
  preprocessingNlRule?: string | null;
  processingOrder?: number | null;
  description?: string | null;
  usedInferenceIds?: string[];
  usedRecommendationIds?: string[];
  usedLearningIds?: string[];
};

export type MappingMode = "source" | "constant" | "attribute";

export type PendingAiMappingReview = {
  autoMapInputSignature?: string;
  autoMapRevisionOrigin?: "run-start-v1";
  autoMapRunId?: string;
  autoMapSharedRevision?: string;
  autoMapValuesRevision?: string;
  generatedByRequestId?: string | null;
  artifactType?: string | null;
  mappingId: string;
  targetColumn: string;
  targetSqlName?: string;
  sourceAttributes: string[];
  confidenceScore: number;
  confidenceReason?: string | null;
  candidateSourceAttributes: string[];
  unmatchedReason?: string | null;
  preprocessingRule?: string | null;
  preprocessingRuleType?: string | null;
  preprocessingNlRule?: string | null;
  processingOrder?: number | null;
  description?: string | null;
  usedInferenceIds?: string[];
  usedRecommendationIds?: string[];
  usedLearningIds?: string[];
  mappingMode?: MappingMode;
  constantValue?: string | null;
  attributeName?: string | null;
  sourceDependencies?: string[];
  valueBindingIds?: string[];
  transformationClassification?: string | null;
  precedentDecision?: string | null;
  precedentMappingId?: string | null;
  overrideEvidence?: string[];
};

export type StreamingStatusPhase =
  | "preparing"
  | "semantic"
  | "learning"
  | "invoking"
  | "processing"
  | "finalizing";

export type ChatMessage = {
  id?: string;
  role: "user" | "assistant";
  content: string;
  streamingSql?: string;
  status?: "completed" | "needs_input" | "failed";
  requestId?: string | null;
  conversationId?: string | null;
  feedbackStatus?: "idle" | "sent" | "failed";
  feedbackRating?: number | null;
  options?: string[];
  isStreaming?: boolean;
  traceSteps?: string[];
  statusPhase?: StreamingStatusPhase | null;
  statusMessage?: string | null;
  elapsedSeconds?: number | null;
};

export type PendingDerivedSourceDraft = {
  sqlText: string;
  sourceNameSuggestion?: string | null;
  semanticViewName?: string | null;
  semanticBundleLabel?: string | null;
  previewRows?: Array<Record<string, unknown>>;
  selectedColumnsByTable?: Record<string, string[]> | null;
  selectedTableIds: string[];
  drivingTableId?: string | null;
  requestSummary?: string | null;
  purpose?: string | null;
  businessDescription?: string | null;
  grain?: string | null;
  keys?: string[];
  outputColumns?: Array<Record<string, unknown>>;
  columnSemantics?: Array<Record<string, unknown>>;
  generatedByRequestId?: string | null;
  /** The same SQL is already saved in the project; the card offers it instead. */
  existingDerivedSource?: { id: string; name: string; version?: number | null } | null;
};

export type LoadStatus = "idle" | "loading" | "success" | "error";

export type BuilderLoadState = {
  initial: LoadStatus;
  schemasByDb: Record<string, LoadStatus>;
  tablesBySchema: Record<string, LoadStatus>;
  attributes: LoadStatus;
  relationships: LoadStatus;
  autoMap: LoadStatus;
  chat: LoadStatus;
};

export type BuilderErrorState = {
  initial?: string;
  schemasByDb: Record<string, string | undefined>;
  tablesBySchema: Record<string, string | undefined>;
  attributes?: string;
  relationships?: string;
  autoMap?: string;
  chat?: string;
};

export type SttmBuilderData = {
  sources: DatabaseNode[];
  targets: DatabaseNode[];
};

export type AutoMapCompletionNotice = {
  id: number;
  reviewCount?: number;
  severity: "success" | "warning" | "error";
  message: string;
};

export type SttmBuilderContextValue = {
  // Tree data
  fullData: SttmBuilderData | null;

  // Flat lists (current schema's tables)
  sources: TableNode[];
  targets: TableNode[];
  sourceInfo: SourceTargetInfo;
  targetInfo: SourceTargetInfo;

  // Attributes
  sourceAttributeGroups: ColumnGroup[];
  targetAttributeGroup: ColumnGroup | null;

  // Mapping
  mappingSuggestions: MappingSuggestion[];
  mappingLoading: boolean;
  autoMapStatusMessage: string | null;
  autoMapProcessingIds: string[];
  autoMapGroupingEnabled: boolean;
  pendingManualEditSnapshots: Record<string, MappingState>;
  autoMapBlockedByManualEdits: boolean;
  /** Set when an Auto-Mapping run settles; cleared when the user dismisses it. */
  autoMapCompletionNotice: AutoMapCompletionNotice | null;

  // Chat
  chatMessages: ChatMessage[];
  chatLoading: boolean;
  assistantSignals: AssistantSignal[];
  assistantInferences: AssistantInferenceRecord[];
  assistantPreferences: AssistantPreferenceState;
  assistantUnreadCount: number;
  firRecommendations: FIRRecommendation[];
  firPrimaryQuestion: FIRRecommendation | null;
  firRecommendationLoading: boolean;
  firRecommendationCheckpoint: string | null;
  firRecommendationContextKey: string | null;
  mappingIntent: MappingIntent | null;
  semanticBundleId: string | null;
  semanticBundleHash: string | null;
  learningContextId: string | null;
  learningContextHash: string | null;
  workspaceContextId: string | null;
  workspaceContextHash: string | null;
  workspaceContextStatus: "idle" | "updating" | "ready" | "partial" | "failed";
  workspaceContextCacheStatus: string | null;
  workspaceContextError: string | null;
  semanticBundleLabel: string | null;
  semanticLevel: string | null;
  semanticStatus: string | null;
  semanticViewName: string | null;
  semanticContextSummary: Record<string, unknown> | null;
  semanticContextItems: SemanticContextItem[] | null;
  semanticLineage: Array<Record<string, unknown>>;
  semanticDatahubContext: Record<string, unknown> | null;
  datahubStatus: string | null;
  pendingDerivedSourceDraft: PendingDerivedSourceDraft | null;
  derivedSourceDraftRequested: boolean;

  // Session
  session: UserSession | null;

  // Project/Mapping identity
  activeProjectId: string | null;
  activeSttmId: string | null;
  activeProjectName: string | null;
  activeSttmName: string | null;
  activeSttmDescription: string | null;
  activeSnapshotId: string | null;
  workspacePersistenceStatus: "idle" | "saving" | "saving_details" | "details_pending" | "saved" | "error";
  workspacePersistenceError: string | null;

  // Saved-workspace hydration lifecycle. Navigation and autosave stay disabled
  // until the backend snapshot and its attributes have finished loading.
  sessionHydrated: boolean;
  openSttmStatus: 'idle' | 'loading' | 'success' | 'error';
  openSttmTargetPage: string | null;
  openSttmErrorMessage: string | null;

  // Loading / error
  loadState: BuilderLoadState;
  errorState: BuilderErrorState;

  // Actions — data loading
  reloadInitialData: () => void;
  loadSchemas: (type: SelectionSide, dbId: string) => void;
  selectSchema: (type: SelectionSide, dbId: string, schemaId: string) => void;

  // Actions — selection
  toggleSource: (tableId: string) => void;
  selectTarget: (tableId: string) => void;
  selectAllSources: () => void;
  clearSources: () => void;
  clearTargets: () => void;
  clearDerivedSources: () => void;

  // Actions — AI
  autoMapAdvancedEnabled?: boolean;
  runAutoMap: (options?: { action?: "complete" | "retry_unresolved" | "reeval_all"; mappingIds?: string[] }) => void;
  dismissAutoMapCompletionNotice: () => void;
  sendChatMessage: (message: string) => void;
  setActiveProjectIdentity: (payload: {
    projectId: string | null;
    projectName?: string | null;
  }) => void;
  resetChatSession: () => void;
  restoreChatSession: (payload: { messages: ChatMessage[] }) => void;
  submitChatFeedback: (payload: {
    messageId: string;
    rating: number;
    comment?: string | null;
  }) => void;
  refreshAssistantSignals: (activityType?: string) => void;
  requestSemanticRefresh: () => Promise<void>;
  refreshPreparedWorkspaceContext: () => Promise<void>;
  flushWorkspace: () => Promise<void>;
  getWorkspaceSnapshot: () => Record<string, unknown>;
  respondToAssistantSignal: (payload: {
    signalId: string;
    status?: "acknowledged" | "responded" | "dismissed";
    optionSelected?: string | null;
    rating?: number | null;
    comment?: string | null;
  }) => void;
  updateAssistantPreferences: (settings: AssistantPreferenceState) => void;
  openPendingDerivedSourceDraft: () => void;
  acknowledgePendingDerivedSourceDraft: () => void;
  dismissPendingDerivedSourceDraft: () => void;
  acknowledgeSourceReconciliation: () => void;
  applyPendingAiMappingReview: () => void;
  skipPendingAiMappingReview: () => void;
  applyAllPendingAiMappingReviews: () => void;
  applySemanticRefresh: (payload: SemanticContextBundleResponse) => void;

  // Computed
  selectedSourceCount: number;
  mappingCount: number;

  // Derived source features
  drivingTableId: string | null;
  setDrivingTable: (tableId: string | null) => void;
  relationships: JoinConfig[];
  setRelationships: (joins: JoinConfig[]) => void;
  relationshipCandidates: JoinConfig[];
  refreshRelationships: () => void;
  approveRelationshipCandidate: (id: string) => void;
  /** Record a recommendation the user added (possibly edited) and drop it from the list. */
  acceptRelationshipCandidate: (join: JoinConfig) => void;
  rejectRelationshipCandidate: (id: string) => void;
  derivedSources: DerivedSource[];
  addDerivedSource: (source: DerivedSource) => void;
  updateDerivedSource: (source: DerivedSource) => void;
  removeDerivedSource: (id: string) => void;
  toggleDerivedSource: (id: string) => void;

  /** SQL fragment from Step 1 filter conditions (`FilterConditions`). */
  sourceFilterSql: string;
  /** Parsed filter tree (keeps UI + preview when navigating away and back). */
  sourceFilterGroups: RuleGroup[];
  sourceQuerySql: string;
  sourcePreviewGate: { validated: boolean; synced: boolean };
  sourceValidationSignature: string;
  sourceValidation: import("../shared/validation-context").SourceValidation | null;
  setSourcePreviewGate: (gate: { validated: boolean; synced: boolean; contextSignature?:string; previewKey?:string; persist?:boolean }) => void;
  sourceGroupBySql: string;
  sourceOrderBySql: string;
  sourceQueryModifiers?: Record<string, string>;
  setSourceFilterConditions: (payload: {
    sql: string;
    groups: RuleGroup[];
    baseSql?: string;
    groupBySql?: string;
    orderBySql?: string;
  }) => void;

  // UI Mapping state
  mappings: MappingState[];
  selectedMappingIds: string[];
  mappingSql: string;
  /** True while `mappingSql` still matches the workspace it was authored against. */
  authoredSqlIsCurrent: boolean;
  authoredSqlSemanticKey: string | null;
  /** Uploaded source identifiers that still need DATABASE.SCHEMA qualification. */
  unresolvedSourceTables: string[];
  mappingPreviewSql: string;
  mappingSqlVariant: "original" | "optimized" | null;
  compiledMappingSql: string;
  compiledMappingScriptSql?: string;
  compiledMappingReady?: boolean;
  compiledMappingPreviewSql: string;
  compiledMappingContextHash: string | null;
  isPreProcessModalOpen: boolean;
  activeMappingId: string | null;
  pendingAiMappingReviews: PendingAiMappingReview[];
  pendingSourceReconciliation: string[];
  
  // Mapping actions
  initializeMappings: (mappings: MappingState[]) => void;
  ensureTargetMappings: (mappings: MappingState[]) => void;
  updateMapping: (
    id: string,
    updates: Partial<MappingState>,
    options?: { skipDirtyTracking?: boolean },
  ) => void;
  selectSheetCandidate: (mappingId: string, candidateId: string, confirm?: boolean, validateOnly?: boolean) => Promise<void>;
  undoSheetSuggestion: (mappingId: string) => void;
  selectJoinReviewSources: (ids: string[]) => void;
  saveReviewedJoin: (join: JoinConfig & {recommendationId?:string}) => void;
  cancelPendingManualMappingEdits: () => void;
  commitPendingManualMappingEdits: () => void;
  toggleMappingSelection: (id: string) => void;
  selectAllMappings: (ids: string[], select: boolean) => void;
  bulkMarkMapped: (ids: string[]) => void;
  bulkClearMappings: (ids: string[]) => void;
  setPreProcessModalOpen: (open: boolean, mappingId?: string | null) => void;
  setMappingSql: (sql: string) => void;
  setMappingPreviewSql: (sql: string) => void;
  setMappingSqlVariant: (variant: "original" | "optimized" | null) => void;
  setCompiledMappingResult: (payload: {
    scriptSql?: string | null;
    ready?: boolean;
    validatedRows?: Array<{id:string;definitionSignature:string}>;
    validationContext?: string;
    generatedSql: string;
    previewSql: string;
    contextHash: string;
  }) => void;
  applyParsedSqlWorkspace: (payload: ParsedSqlWorkspaceApplyPayload) => void;
};

export type ParsedSqlWorkspaceApplyPayload = {
  preserveMappingRows?: boolean;
  sourceQuerySql?: string;
  queryModifiers?: Record<string, string>;
  sourceTableFqns: string[];
  sourceInstances?: Array<{ relationId: string; qualifiedName: string; sqlAlias: string }>;
  /** Source identifiers that could not be qualified to DATABASE.SCHEMA.TABLE. */
  unresolvedSourceTables?: string[];
  targetTableFqn?: string | null;
  /** Relation id (physical FQN or derived-source id) of the SQL's outer FROM. */
  drivingTableId?: string | null;
  relationships: JoinConfig[];
  mappings: MappingState[];
  derivedSources: Array<{
    preserveExistingDefinition?: boolean;
    id?: string;
    name: string;
    isSelected?: boolean;
    sqlText?: string | null;
    definitionSql?: string | null;
    queryScope?: Record<string, unknown>;
    parentDerivedSourceIds?: string[];
    drivingTableId?: string;
    joins?: DerivedSource['joins'];
    filters?: RuleGroup[];
    inputTables?: string[];
    outputColumns?: Array<Record<string, unknown>>;
    purpose?: string | null;
    candidateReasons?: string[];
  }>;
  filterSql: string;
  groupBySql?: string;
  orderBySql?: string;
  sql: string;
};

export type MappingStatus = "MAPPED" | "UNMAPPED" | "PROCESSING" | "NEEDS_VALIDATION" | "VALIDATION_FAILED";
export type MappingRuleType = "Direct" | "Select..." | "Custom" | string;

export interface MappingState {
  validation?: import("../shared/row-validation-state").RowValidation | null;
  aiCandidates?: AutoMapCandidate[];
  aiSuggestions?: AutoMapSuggestion[];
  selectedAiCandidateId?: string | null;
  aiReviewStatus?: "unreviewed" | "confirmed" | "edited" | null;
  aiUndoSnapshot?: Partial<MappingState> | null;
  targetSqlName?: string;
  learningOrigin?: { kind: "assistant_apply"; requestId: string | null; artifactType: string | null } | null;
  id: string;
  targetColumn: string;
  targetType: string;
  sourceColumn: string | null;
  sourceType: string | null;
  sourceColumns?: string[];
  mappingMode?: MappingMode;
  constantValue?: string | null;
  attributeName?: string | null;
  expression: string | null;
  rule: MappingRuleType;
  status: MappingStatus;
  nlRule?: string | null;
  loadOrder?: string | null;
  description?: string | null;
  descriptionEdited?: boolean;
  targetOrdinal?: number;
  confidenceScore?: number | null;
  confidenceReason?: string | null;
  /**
   * True when an auto-mapped row (with confidence) was later edited by the user.
   * Confidence score is preserved for ranking until an explicit manual Save.
   */
  manuallyEditedAfterAutoMap?: boolean;
  /**
   * True after the user explicitly saved a manual mapping.
   * Confidence % is cleared; row stays in the high-confidence group as "Manual".
   */
  manuallySaved?: boolean;
  candidateSourceColumns?: string[];
  unmatchedReason?: string | null;
  usedInferenceIds?: string[];
  usedRecommendationIds?: string[];
  usedLearningIds?: string[];
  aiSuggestedRule?: string | null;
  aiSuggestedRuleType?: string | null;
  sourceDependencies?: string[];
  valueBindingIds?: string[];
  transformationClassification?: string | null;
  precedentDecision?: string | null;
  precedentMappingId?: string | null;
  overrideEvidence?: string[];
}
