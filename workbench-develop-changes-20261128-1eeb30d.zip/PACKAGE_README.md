# Workbench develop changes for November 28, 2026

This cumulative overlay supersedes the November 26 change and dependency ZIPs. Paths are relative to the Workbench repository root. The verified CodeCommit develop head is `1eeb30df2a68081da8aa099c0b7ba4ddd60a2dac`. The comparison baseline is `27c27a39a7dc0f0529cf06e445bfaf5bda0eaef2`. The latest new team changes reachable from that branch were committed November 27 IST. GitHub develop could not be independently verified.

## Included changes

- Abhishek's Firm Values work adds shared values, follows project-level `$Name` references after edits, and blocks deletion of values still in use.
- Kalyani's changes update suggested CTE SQL and table relationship canvas consistency. Ajith's latest reachable commit includes the sign-in spinner and chat composition beside the CTE popup. Earlier team commits are inherited from the baseline.
- Deep Agent includes project and source discovery, saved-mapping and FIR evidence recovery, plan-to-mapping handoff, scoped tool actions, attachment extraction and OCR, document/SQL/spreadsheet skills, and persisted execution state.
- SQL Upload includes target-column hydration, SQL and CTE preservation, and the fix that moves recovery checks and receipt reads onto the existing upload connection path. The metadata DDL adds the existing recovery table's `PROCESSING_ID` to older installations before seeding admission.
- Chat changes cover owner-scoped history, AI titles, timestamps, deduplication, search, pinning, archive/restore, and permanent deletion through the UI.
- There were no Git conflicts. Integration validation identified a Firm Values TypeScript assignment and two test expectations affected by the shared-value SQL changes. The package includes the type correction and regression assertions for the integrated behavior.

## Apply and deploy

1. Apply this overlay in a clean integration checkout. If the target is already at the verified CodeCommit head, the team revisions are present. If its ancestry differs, compare each file using the before and after hashes in `MANIFEST.json` and reconcile overlapping changes before copying. Match paths from the repository root and preserve local environment files.
2. Use the existing client deployment settings and normal bootstrap command. The package includes the updated bootstrap script, Deep Agent metadata chain, conversation pin schema, run knowledge SQL, and upload recovery migration. Bootstrap stages the three packaged Deep Agent skills in the existing `STTM_AGENT_SKILLS` stage. The Python worker loads the same skill files from its image. Deep Agent supervisor instructions and tool definitions ship in Python. Existing native Cortex agent specifications continue through the normal bootstrap.
3. Rebuild and deploy the frontend, API and Deep Agent worker from the same integrated source. The worker Dockerfile installs the existing package's OCR/PDF runtime dependencies, so use a rebuilt image. This overlay introduces no new client environment variables, grants, network rules, or CI/CD jobs. Keep the client's configured namespaces and semantic registry policy.
4. Verify through the client ingress using a regular application role. Upload and reopen a saved SQL file, confirm mappings reach the mapping page, and run one attachment-backed Deep Agent plan through implementation. Check chat history, archive and restore for the signed-in user.

TypeScript, 62 frontend tests, 237 targeted backend tests, and a supplemental 84-test bootstrap and related run passed in the reconciled checkout. The supplemental run overlaps the first backend run. Client SPCS was not deployed or tested in this packaging turn.
