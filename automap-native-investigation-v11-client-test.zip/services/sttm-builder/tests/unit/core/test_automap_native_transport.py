"""Native registered events on the existing real managed transport/admission.

Fake HTTP/Snowflake only. Legacy single-shot behavior remains unchanged.
"""

from copy import deepcopy
from dataclasses import replace
import json
import pytest
from app.core.automap_native_transport import NativeAgentTransport
from app.core.automap_scan_transport import TerminalResponseError, ScanTransportError
from tests.test_automap_fast_transport import harness, build, MESSAGES, SOURCE


def native(h):
    model = build(h)
    old = model.bundle.backend
    backend = NativeAgentTransport(
        agent_client=h.service._agent,
        http_client=old._http_client,
        config=old._config,
        admission=model.bundle.admission,
    )
    model.bundle = replace(model.bundle, backend=backend)
    model._guarded = model.bundle.admission.wrap_backend(backend)
    return model, backend


def reply():
    use = {
        "tool_use_id": "tool1",
        "type": "generic",
        "name": "ReadEvidence",
        "input": {"request_json": "{}"},
        "client_side_execute": False,
    }
    result = {
        "tool_use_id": "tool1",
        "type": "generic",
        "name": "ReadEvidence",
        "status": "success",
        "content": [{"type": "json", "json": {"evidence": []}}],
    }
    return {
        "role": "assistant",
        "status": "completed",
        "content": [
            {"type": "tool_use", "tool_use": use},
            {"type": "tool_result", "tool_result": result},
            {
                "type": "text",
                "text": '{"status":"completed","agent":"AGT_SOURCE_MAPPING","result":{"mappings":{}}}',
            },
        ],
        "metadata": {
            "usage": {
                "tokens_consumed": [
                    {
                        "input_tokens": {"total": 125},
                        "output_tokens": {"total": 20},
                        "context_window": 128000,
                    }
                ]
            }
        },
    }


def test_registered_native_events_are_not_mixed_into_final_mapping_text(harness):
    h = harness
    model, backend = native(h)
    h.state.provider_response = reply()
    raw, _, diagnostics = model.run(MESSAGES, 1)
    assert json.loads(raw)["result"] == {"mappings": {}}
    assert backend.provider_usage == {
        "input_tokens": 125,
        "output_tokens": 20,
        "context_window": 128000,
    }
    assert backend.provider_received_at <= backend.provider_parsed_at
    assert len(h.state.models) == 1 and all(
        slot["STATE"] == "FREE" for slot in h.database.slots
    )
    assert (
        diagnostics["fast_diagnostics"]["agent_fqn"]
        if "agent_fqn" in diagnostics["fast_diagnostics"]
        else True
    )


@pytest.mark.parametrize(
    "poison",
    [
        "foreign",
        "unpaired",
        "duplicate",
        "client",
        "delegation",
        "status",
        "unknown",
        "foreign-type",
    ],
    ids=[
        "foreign-tool",
        "missing-result",
        "duplicate-result",
        "client-execution",
        "nested-actions",
        "nonterminal-result",
        "unknown-block",
        "foreign-tool-type",
    ],
)
def test_native_parser_still_rejects_conflicts_and_unknown_actions(harness, poison):
    h = harness
    model, _ = native(h)
    body = reply()
    if poison == "foreign":
        body["content"][0]["tool_use"]["name"] = "ExecuteAnything"
    elif poison == "unpaired":
        del body["content"][1]
    elif poison == "duplicate":
        body["content"].insert(1, deepcopy(body["content"][1]))
    elif poison == "client":
        body["content"][0]["tool_use"]["client_side_execute"] = True
    elif poison == "delegation":
        body["content"][1]["tool_result"]["delegation"] = {}
    elif poison == "status":
        body["content"][1]["tool_result"]["status"] = "running"
    elif poison == "unknown":
        body["content"].append({"type": "unknown"})
    else:
        body["content"][0]["tool_use"]["type"] = "system_execute_sql"
    h.state.provider_response = body
    with pytest.raises(TerminalResponseError):
        model.run(MESSAGES, 1)
    assert all(
        slot["STATE"] == "FREE" for slot in h.database.slots
    )  # known terminal provider failure


@pytest.mark.parametrize(
    "mode",
    ["timeout", "lost_ack", "invalid_wire"],
    ids=["timeout", "lost-ack", "malformed"],
)
def test_uncertain_native_post_is_not_replayed_and_keeps_its_permit(harness, mode):
    h = harness
    model, _ = native(h)
    h.state.mode = mode
    with pytest.raises(Exception):
        model.run(MESSAGES, 1)
    with pytest.raises(Exception):
        model.run(MESSAGES, 2)
    assert len(h.state.models) == 1
    assert (
        sum(slot["STATE"] in {"HELD", "QUARANTINED"} for slot in h.database.slots) == 1
    )


def test_legacy_single_shot_parser_is_not_weakened_by_native_tools(harness):
    h = harness
    model = build(h)
    h.state.provider_response = reply()
    with pytest.raises(TerminalResponseError):
        model.run(MESSAGES, 1)


def test_native_rule_transport_only_accepts_its_registered_subset(harness):
    h = harness
    model, backend = native(h)
    backend.allowed_tools = frozenset({"ValidateProposal", "SubmitProposals"})
    h.state.provider_response = reply()
    with pytest.raises(TerminalResponseError):
        model.run(MESSAGES, 1)
