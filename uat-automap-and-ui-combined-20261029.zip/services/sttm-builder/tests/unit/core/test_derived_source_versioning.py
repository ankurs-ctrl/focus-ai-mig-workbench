"""Derived sources are reused, versioned and unique by name within a project."""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from app.core.config import Settings
from app.core.derived_source import DerivedSourceService, derived_family_key, derived_sql_hash
from app.core.exceptions import DerivedSourceNameConflictError
from app.schema.common import TableRef
from app.schema.derived_source import (
    DerivedSourceDefinition,
    DerivedSourcePreviewColumn,
    DerivedSourceValidateResponse,
)

SQL = "SELECT ID, NAME FROM DB.SRC.CLIENT"


class _Session:
    def __init__(self, family_rows):
        self.family_rows = family_rows
        self.statements: list[str] = []

    def sql(self, statement: str, *args, **kwargs):
        self.statements.append(statement)
        rows = self.family_rows if "V_FAMILY_KEY =" in statement else []
        return SimpleNamespace(collect=lambda: [SimpleNamespace(as_dict=lambda row=row: row) for row in rows])


def _row(source_id: str, name: str = "CLIENTS", sql: str = SQL, *, version: int = 1, project: str = "p1", latest: bool = True):
    return {
        "DERIVED_SOURCE_ID": source_id,
        "DERIVED_SOURCE_NAME": name,
        "SQL_TEXT": sql,
        "SOURCE_TABLES": '[{"database": "DB", "schema": "SRC", "table": "CLIENT"}]',
        "SEMANTIC_PROJECTION": {"versioning": {"project_id": project, "version": version, "is_latest": latest}},
        "IS_ACTIVE": True,
        "V_PROJECT_ID": project,
        "V_FAMILY_KEY": derived_family_key(name),
        "V_VERSION": version,
        "V_IS_LATEST": latest,
        "V_SQL_HASH": derived_sql_hash(sql),
    }


def _service(family_rows, monkeypatch) -> tuple[DerivedSourceService, _Session, list]:
    session = _Session(family_rows)
    service = DerivedSourceService.__new__(DerivedSourceService)
    service._session = session
    service._settings = Settings(_env_file=None, SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    service._table_selection = MagicMock()
    validated: list = []

    def validate(body):
        validated.append(body)
        return DerivedSourceValidateResponse(
            message="ok",
            sql_text=body.sql_text,
            preview_columns=[DerivedSourcePreviewColumn(name="ID", data_type="NUMBER")],
            preview_rows=[],
        )

    monkeypatch.setattr(service, "ensure_table_exists", lambda: None)
    monkeypatch.setattr(service, "validate_sql", validate)
    monkeypatch.setattr(service, "_materialize_secure_view", lambda source_id: {"physical_view_name": f"DSV_{source_id}"})
    monkeypatch.setattr(service, "_current_user", lambda: "ME")
    monkeypatch.setattr(service, "get_sources_by_ids", lambda ids: [])
    return service, session, validated


def _body(**overrides) -> DerivedSourceDefinition:
    values = {
        "derived_source_name": "Clients",
        "sql_text": SQL + ";",
        "source_tables": [TableRef(database="DB", schema="SRC", table="CLIENT")],
        "project_id": "p1",
        "sttm_id": "s1",
    }
    values.update(overrides)
    return DerivedSourceDefinition(**values)


def test_exactly_identical_sql_returns_existing(monkeypatch) -> None:
    service, session, validated = _service([_row("existing")], monkeypatch)

    record = service.save_source(_body(sql_text="SELECT ID,  NAME\nFROM DB.SRC.CLIENT"))

    assert record.derived_source_id == "existing"
    assert record.reused is True
    assert validated == []
    assert not any("MERGE INTO" in item for item in session.statements)


def test_new_cte_name_creates_distinct_source_even_with_same_sql(monkeypatch) -> None:
    service, _, _ = _service([_row("existing")], monkeypatch)
    record = service.save_source(_body(derived_source_name="Clients_Copy", sql_text=SQL))
    assert record.derived_source_id != "existing"
    assert record.derived_source_name == "Clients_Copy"


def test_save_rebuilds_scope_metadata_from_persisted_sql(monkeypatch):
    service, _, _ = _service([], monkeypatch)
    record = service.save_source(_body(query_scope={"definition_sql": "STALE"}, definition_sql="STALE"))
    assert record.definition_sql == "SELECT ID, NAME FROM DB.SRC.CLIENT"
    assert record.query_scope["definition_sql"] == record.definition_sql
    assert record.semantic_projection["query_scope"] == record.query_scope
    restored = service._row_to_record({"DERIVED_SOURCE_ID": record.derived_source_id,
        "DERIVED_SOURCE_NAME": record.derived_source_name, "SQL_TEXT": record.sql_text,
        "SOURCE_TABLES": [table.model_dump() for table in record.source_tables],
        "SEMANTIC_PROJECTION": record.semantic_projection})
    assert restored.query_scope == record.query_scope
    assert restored.definition_sql == record.definition_sql


def test_cte_sql_comment_survives_save_and_reopen(monkeypatch):
    service, _, _ = _service([], monkeypatch)
    authored = "-- Household review note\nSELECT ID, NAME FROM DB.SRC.CLIENT"
    record = service.save_source(_body(sql_text=authored))
    assert "Household review note" in record.sql_text
    restored = service._row_to_record({
        "DERIVED_SOURCE_ID": record.derived_source_id,
        "DERIVED_SOURCE_NAME": record.derived_source_name,
        "SQL_TEXT": record.sql_text,
        "SOURCE_TABLES": [table.model_dump() for table in record.source_tables],
        "SEMANTIC_PROJECTION": record.semantic_projection,
    })
    assert "Household review note" in restored.sql_text


def test_same_name_different_sql_asks_with_existing_details(monkeypatch) -> None:
    service, _, _ = _service([_row("existing", version=2)], monkeypatch)

    with pytest.raises(DerivedSourceNameConflictError) as caught:
        service.save_source(_body(sql_text="SELECT ID FROM DB.SRC.CLIENT WHERE ACTIVE"))

    details = {item["field"]: item["message"] for item in caught.value.details}
    assert caught.value.status_code == 409
    assert details["existing_derived_source_id"] == "existing"
    assert details["existing_version"] == "2"
    assert details["suggested_name"] == "Clients_v3"


def test_new_version_gets_suffix_and_supersedes_previous(monkeypatch) -> None:
    service, session, _ = _service([_row("existing", version=1)], monkeypatch)

    record = service.save_source(
        _body(sql_text="SELECT ID FROM DB.SRC.CLIENT WHERE ACTIVE", on_conflict="new_version")
    )

    assert record.derived_source_name == "Clients_v2"
    assert record.version == 2 and record.is_latest
    assert record.derived_source_id != "existing"
    update = next(item for item in session.statements if item.lstrip().startswith("UPDATE") and "'is_latest'" in item)
    assert "'existing'" in update


def test_overwrite_keeps_id_and_bumps_version(monkeypatch) -> None:
    service, session, _ = _service([_row("existing", version=3)], monkeypatch)

    record = service.save_source(
        _body(sql_text="SELECT ID FROM DB.SRC.CLIENT WHERE ACTIVE", on_conflict="overwrite")
    )

    assert record.derived_source_id == "existing"
    assert record.version == 4
    merge = next(item for item in session.statements if "MERGE INTO" in item)
    assert "'existing' AS DERIVED_SOURCE_ID" in merge


def test_editing_changes_version_only_when_sql_changes(monkeypatch) -> None:
    service, _, _ = _service([_row("existing", version=2)], monkeypatch)
    same = service.save_source(_body(derived_source_id="existing", sql_text=SQL))
    assert same.version == 2

    service, _, _ = _service([_row("existing", version=2)], monkeypatch)
    with pytest.raises(DerivedSourceNameConflictError):
        service.save_source(_body(derived_source_id="existing", sql_text=SQL + " WHERE 1 = 1"))
    changed = service.save_source(_body(derived_source_id="existing", sql_text=SQL + " WHERE 1 = 1", on_conflict="overwrite"))
    assert changed.version == 3


def test_metadata_only_edit_bumps_version_and_dependency_hash(monkeypatch):
    service, _, _ = _service([_row("existing", version=2)], monkeypatch)
    with pytest.raises(DerivedSourceNameConflictError):
        service.save_source(_body(derived_source_id="existing", sql_text=SQL, grain="One row per client"))
    changed = service.save_source(_body(derived_source_id="existing", sql_text=SQL, grain="One row per client", on_conflict="overwrite"))
    assert changed.version == 3
    assert changed.semantic_projection["materialization"]["status"] == "ready"
    assert service._upstream_hash(_body(grain="client"), []) != service._upstream_hash(_body(grain="household"), [])


def test_parent_revision_changes_dependency_hash(monkeypatch):
    service, _, _ = _service([], monkeypatch)
    parent = service._row_to_record(_row("parent", version=1))
    first = service._upstream_hash(_body(parent_derived_source_ids=["parent"]), [parent])
    second = service._upstream_hash(_body(parent_derived_source_ids=["parent"]), [parent.model_copy(update={"version": 2})])
    assert first != second


def test_failed_materialization_is_recorded_and_same_sql_retry_rebuilds(monkeypatch):
    service, _, _ = _service([], monkeypatch)
    statuses = []
    monkeypatch.setattr(service, "_set_materialization_status", lambda source_id, status: statuses.append(status))
    def fail(source_id):
        raise RuntimeError("materialization unavailable")
    monkeypatch.setattr(service, "_materialize_secure_view", fail)
    with pytest.raises(RuntimeError, match="materialization unavailable"):
        service.save_source(_body())
    assert statuses == ["failed"]
    existing = _row("existing")
    existing["SEMANTIC_PROJECTION"]["materialization"] = {"status": "failed"}
    service, _, validated = _service([existing], monkeypatch)
    calls = []
    monkeypatch.setattr(service, "_materialize_secure_view", lambda source_id: calls.append(source_id) or {"physical_view_name": "DB.S.V"})
    result = service.save_source(_body())
    assert calls == ["existing"]
    assert result.reused and result.physical_view_name == "DB.S.V"
    assert validated == []


def test_missing_parent_is_rejected_before_preview_or_save(monkeypatch):
    service, session, validated = _service([], monkeypatch)
    with pytest.raises(Exception, match="dependencies"):
        service.save_source(_body(parent_derived_source_ids=["missing"]))
    assert validated == []
    assert not any("MERGE INTO" in statement for statement in session.statements)


def test_legacy_rows_without_project_only_collide_by_identical_sql(monkeypatch) -> None:
    service, _, _ = _service([_row("legacy", project="")], monkeypatch)

    record = service.save_source(_body(sql_text="SELECT ID FROM DB.SRC.CLIENT WHERE ACTIVE"))

    assert record.derived_source_id != "legacy"
    assert record.project_id == "p1"


def test_structural_description_when_none_supplied(monkeypatch) -> None:
    service, _, _ = _service([], monkeypatch)
    record = service.save_source(_body())
    assert record.semantic_projection["description"].startswith("Derived from CLIENT")
    assert record.semantic_projection["description_source"] == "structural"
    assert record.semantic_projection["versioning"]["origin_sttm_id"] == "s1"


def test_family_key_and_hash_are_stable() -> None:
    assert derived_family_key("Clients_v7") == derived_family_key("CLIENTS") == "CLIENTS"
    assert derived_sql_hash("SELECT 1\n FROM T ") == derived_sql_hash("SELECT 1 FROM T")
