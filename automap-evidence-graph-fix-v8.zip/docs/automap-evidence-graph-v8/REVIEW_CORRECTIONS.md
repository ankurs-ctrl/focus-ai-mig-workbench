# V7 review findings corrected in V8

This is a cumulative review package for the user-confirmed deployed V5.1 baseline `49c6a576def79e5bb02aa8326502a90d680b9477`. It is not a delta to V7. Apply V8 instead of V6/V7, retaining the client's existing secrets. No commit, push, deployment, live Snowflake run, publication or target-data loading occurred here.

## 1. Late preserved-baseline proposals overwrote saved edits

The preserved-baseline path previously stamped a proposal with the current row signature. An edit received after run start could therefore become the apparent baseline of an old proposal. Explicit reevaluation had a different check, leaving the preserved path exposed.

V8 uses a single proposal-stamping helper for both paths. It compares the current row against the immutable run-start baseline, verifies that no manual edit was recorded for the run, and signs only that original signature. It adds `autoMapRevisionOrigin: run-start-v1` and `autoMapRunId`; V6/V7 proofs cannot be upgraded by signing today's row. Manual edit and Save invalidate existing queued proposals. A row edited and later cancelled or changed back remains excluded from that old run's proposals. UI PROCESSING state settles without overwriting definitions or certifying an unvalidated edited expression.

Regression cases execute the actual thunk and reducers: partial plus terminal responses, single/all acceptance, saved/unsaved/cancelled/edited-back rows, editing after a proposal is already queued, and legacy V7 proofs. Real pinned `@noble/hashes` SHA-256 is used, with independent Node crypto vectors verifying its output; there is no substitute implementation in the harness.

## 2. Unresolved reevaluations erased mappings

V7 allowed explicit reevaluation and block-review proposals to bypass the executable-proposal check. Single/all acceptance then used the general mapping application function even when the item was unresolved.

V8 tests applicability before queuing and again at acceptance. An unresolved response is still shown through the existing suggestion/candidate fields; it cannot become an applicable replacement. Old unresolved items already in a queue are retained/held, and valid siblings in Apply all can proceed independently. Source mappings, explicit empty-string constants and project-attribute mappings retain their complete definitions. Accepting a low-confidence but executable proposal remains possible; no confidence threshold was increased.

## 3. Block-review envelopes failed open

V7 inspected `data.result` and root `meta`, but ignored nested `data.meta.delegation` and conflicting root `result`. V8 validates both envelope levels with a small allowlist, matching agent identities, terminal/error checks, all metadata locations and result equality. Unknown action/tool fields are rejected. Literal quotes, block IDs, size limits, duplicate-JSON-key checks and nonfinite-value checks remain mandatory.

Tests cover helper validation and the real guarded model runtime, with fake HTTP/Snowflake boundaries. Invalid block output never authorizes a source decision; one completed invalid response can be corrected within the existing bound. No delegation is executed. No foreign mapping is applied. Uncertain-call quarantine and no-blind-replay behavior are unchanged.

## 4. Failed continuation erased previously verified alternatives

Terminal failure branches could construct a fresh unresolved mapping and take precedence over the earlier verified unresolved item. V8 restores only its verified candidate list and confidence explanation at terminal assembly when those fields would otherwise be lost. Failure reason/outcome remain current; selected sources, transformations, Values and SQL are never restored from an unresolved alternative.

Tests first read an actual admitted binding from the outgoing model packet, retain it as an alternative, then fail subsequent unknown-source or malformed-source repairs. The valid sibling survives and the verified alternative/explanation remain. A fabricated first alternative never enters that retention set. This verifies binding/evidence identity, not business correctness of the candidate.

## Additional findings investigated

- **Broken frontend harnesses:** `test-mapping-learning-origin.cjs` and `test-mapping-row-recovery.cjs` omitted newly required helper dependencies. They now load the real helpers and current acceptance proof rather than bypassing validation. All frontend harnesses are run, not just the new Auto-map scripts.
- **Missing dependency in client review:** the baseline already declares and locks `@noble/hashes` 1.8.0. No dependency files were changed. Run with the existing locked frontend dependencies installed; a crypto stub is not equivalent validation. V8 checks the installed version and real hash vectors.
- **Preflight timing:** local profiling reproduced substantial repeated packing work on the synthetic 250,000-character datatype fixture (about 33–36 seconds in the ten-blocked-target cases before the fix). V8 recognizes only truly indivisible over-limit identity tokens early. All four timing cases then completed in 0.53–1.08 seconds locally with the unchanged 45-second assertions. This addresses the identified repeated-work path; it does not establish the cause of Coco's particular 50.28-second run or predict live model latency.
- **Cached old preflight results:** the preflight contract version is advanced to `fast-target-preflight-v4-review-safety`. Old frozen results cannot be silently resumed under new acceptance rules. Use a fresh deliberate client acceptance job after updating every web/worker image; never blindly replay an uncertain model POST.

## Client acceptance additions

1. Start Auto-map, change and save an imported expression, let the old job finish and try both acceptance actions. The saved expression must remain intact.
2. Reevaluate an existing source mapping, empty constant and project-attribute mapping. If unresolved, only suggestions/reasons may change; no existing definition is erased.
3. Inject/review nested-delegation and root-result-conflict block responses. Coverage must not mark those blocks reviewed or continue to a mapping decision until a valid bounded correction is acknowledged.
4. Retain a verified alternative, then force a later repair or evidence-read failure. Check that target's alternatives/explanation and the other valid target's result survive.
5. Record end-to-end latency separately from model latency and preparation time. Passing the offline timing fixture is not a two-minute production claim.
