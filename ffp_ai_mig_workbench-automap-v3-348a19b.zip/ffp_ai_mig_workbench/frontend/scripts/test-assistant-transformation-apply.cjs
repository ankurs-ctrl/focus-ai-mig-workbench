const fs=require('fs'), assert=require('assert/strict');
const h=require('./test-automap-preservation.cjs');
const response=JSON.parse(fs.readFileSync(require('path').resolve(__dirname,'../../docs/automap-v3/local-assistant-transformation-validation.json'))).structured_proposal;
const row={...h.blank('fixture-target'),targetColumn:'CALCULATION_LABEL',sourceColumn:'src.AUTO_CALCULATED',sourceColumns:['src.AUTO_CALCULATED'],rule:'Direct',status:'MAPPED'};
const state=h.stateFor(row);state.selectedMappingIds=[row.id];
const reviewFunctions=h.compile(h.functions(h.slice,['inferPreprocessingRuleType','buildPendingAiMappingReviewRows','buildPendingAiMappingReviews'])+';return {buildPendingAiMappingReviews};',Object.fromEntries(Object.entries(h.helpers).filter(([name])=>!['inferPreprocessingRuleType','buildPendingAiMappingReviewRows','buildPendingAiMappingReviews'].includes(name))));
const reviews=reviewFunctions.buildPendingAiMappingReviews(state.mappings,[row.id],row.id,response);
assert.equal(reviews.length,1);assert.equal(reviews[0].mappingId,row.id);
assert.equal(h.helpers.autoMapReviewIsApplicable(row,reviews[0]),true);
assert.equal(row.rule,'Direct','a proposal must not apply itself');
let apply;
function visit(node){if(node.initializer && node.name?.getText(h.slice)==='applyPendingAiMappingReview')apply=node.initializer.getText(h.slice); h.slice.forEachChild && require('typescript').forEachChild(node,visit);}
visit(h.slice);assert.ok(apply);state.pendingAiMappingReviews=reviews;
let accept;
function findAccept(node) {
 if(node.initializer && node.name?.getText(h.slice)==='acceptPendingAiMappingReviews') accept=node.initializer.arguments[1].getText(h.slice);
 require('typescript').forEachChild(node,findAccept);
}
findAccept(h.slice);
const acceptThunk=h.compile(`return (${accept});`,{...h.helpers,listProjectAttributes:async()=>[],applyPendingAiMappingReview:payload=>({payload}),getErrorMessage:(_e,f)=>f});
(async()=>{
const result=await acceptThunk(undefined,{getState:()=>({sttmBuilder:state}),dispatch:action=>h.reducer(apply)(state,action),rejectWithValue:error=>({error})});
assert.equal(result?.error,undefined);
assert.equal(state.errorState.autoMap,undefined);
assert.match(row.expression,/CASE WHEN src.CREATED_TIME IS NULL/);
assert.equal(state.pendingAiMappingReviews.length,0);
console.log('Captured live transformation proposal applies after review:',row.expression);

})().catch(error=>{console.error(error);process.exitCode=1;});
