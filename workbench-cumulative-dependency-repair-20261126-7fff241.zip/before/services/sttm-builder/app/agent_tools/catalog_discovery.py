"""Bounded caller-visible metadata discovery; never enumerate the whole account."""
import re
from sqlglot import exp, parse_one
from app.agent_runs.models import ToolResult
from app.agent_runtime.execution import BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError
from app.core.exceptions import DelegatedSessionRequired, DelegatedCredentialsRotated


def identifier_parts(value):
    if isinstance(value, dict):
        # TableRef fields are literal catalog names, rather than a SQL string.
        # Preserve quoted case and dots inside a component; authorization still
        # resolves the resulting exact identifier against the caller catalog.
        parts = [value.get(key) for key in ('database', 'schema', 'table')]
        return parts if all(isinstance(part, str) and part for part in parts) else []
    try:
        tree=parse_one(str(value),into=exp.Table,dialect='snowflake')
        parts=tree.parts
        if tree.alias or not parts or not all(isinstance(p,exp.Identifier) for p in parts):return []
        return [p.name if p.args.get('quoted') else p.name.upper() for p in parts]
    except Exception:return []


def sql_diagnostics(error):
    result={};seen=set();codes=[]
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        native=getattr(error,'sql_error_code',None)
        wrapper=getattr(error,'errno',None)
        if native is not None:codes.insert(0,str(native))
        elif wrapper is not None:codes.append(str(wrapper))
        for field,names in {'native_code':('sql_error_code','errno'),'sql_state':('sqlstate','sql_state'),'query_id':('sfqid','query_id')}.items():
            for name in names:
                value=getattr(error,name,None)
                if value is not None and field not in result and re.fullmatch(r'[A-Za-z0-9_-]{1,128}',str(value)):
                    result[field]=str(value);break
        error=error.__cause__ or error.__context__
    if codes:result['native_code']=next((code for code in codes if code.lstrip('0')!='1304'),codes[0])
    return result


def _caller_schema_scopes(workbench, context, hints):
    """Resolve schema hints across caller-visible databases, never scan account tables."""
    with workbench._domain_lock:
        cache = getattr(workbench, '_catalog_schema_inventory', None)
        if cache is None:
            rows = workbench._session.sql('SHOW SCHEMAS IN ACCOUNT LIMIT 1000').collect()
            cache = []
            for raw in rows:
                row = raw.as_dict() if hasattr(raw, 'as_dict') else dict(raw)
                row = {str(k).lower(): v for k, v in row.items()}
                db, schema = row.get('database_name'), row.get('name')
                if db and schema and schema != 'INFORMATION_SCHEMA' and db != 'SNOWFLAKE':
                    cache.append((str(db), str(schema)))
            workbench._catalog_schema_inventory = cache
        # A schema shorthand is only a candidate hint. Return exact current FQNs;
        # the agent must inspect contracts before choosing among prefix matches.
        ranked = sorted(set(cache), key=lambda item: (
            0 if any(item[1] == h for h in hints) else 1,
            item[0], item[1]))
        if hints:
            ranked = [item for item in ranked if any(item[1] == h or item[1].startswith(h + '_') for h in hints)]
        return ranked, len(cache) >= 1000


def discover(workbench,terms,limit,*,database=None,schema=None,context=None):
    context=context or {};settings=workbench._settings
    default_db=database or getattr(settings,'snowflake_database',None)
    if default_db and len(identifier_parts(default_db))!=1:
        return ToolResult(status='failed',summary='Provide one database identifier.',error_code='catalog_scope_required')
    if schema and not default_db:
        return ToolResult(status='failed',summary='Specify the database for this schema.',error_code='catalog_scope_required')
    declared={tuple(identifier_parts(value)) for value in context.get('authorized_schemas',[]) if len(identifier_parts(value))==2}
    scopes=set()
    def add(value):
        parts=identifier_parts(value)
        if len(parts)>=2:scopes.add(tuple(parts[:2]))
    def walk(value):
        if isinstance(value,dict):
            db=value.get('database') or value.get('database_name');sc=value.get('schema') or value.get('schema_name')
            if db and sc:add(f'{db}.{sc}')
            for key,item in value.items():
                if key in {'authorized_schemas','authorized_source_scope','authorized_target_scope','source_tables','target_tables','selected_sources','sources','targets','page_context','workspace_context','prepared_context','context'}:walk(item)
                elif key in {'table','table_fqn','qualified_name','qualifiedName'} and isinstance(item,str):add(item)
        elif isinstance(value,list):
            for item in value:walk(item)
        elif isinstance(value,str):add(value)
    walk(context)
    if schema and default_db:
        dbparts=identifier_parts(default_db);scparts=identifier_parts(schema)
        if len(dbparts)!=1 or len(scparts)!=1:return ToolResult(status='failed',summary='Provide one database and schema identifier.',error_code='catalog_scope_required')
        scopes={(dbparts[0],scparts[0])}
    # The application's metadata database is not the user's data universe.
    # Resolve DW/DL-style hints against schema metadata before searching tables.
    inventory_scopes = []; inventory_partial = False
    hints = {identifier_parts(term)[0] for term in terms if len(identifier_parts(term)) == 2}
    prompt = str(context.get('prompt') or context.get('user_request') or '')
    hints.update(re.findall(r'\b([A-Za-z][A-Za-z0-9_]*)\s*\.', prompt))
    hints.update(re.findall(r'\b[A-Z][A-Z0-9_]{1,63}\b', prompt))
    hints = {h.upper() for h in hints}
    if not database and not schema and not declared and hints and (not scopes or not any(sc == h or sc.startswith(h+'_') for _,sc in scopes for h in hints)):
        try:
            inventory_scopes, inventory_partial = _caller_schema_scopes(workbench, context, hints)
        except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated):
            raise
        except Exception as error:
            return ToolResult(status='failed', summary='Caller-visible schema discovery could not complete; no table absence is established.', error_code='catalog_scope_discovery_failed', data={'coverage':'incomplete','diagnostics':sql_diagnostics(error)})
    requests=[]
    for term in terms:
        parts=identifier_parts(term)
        if len(parts)==3:requests.append((term,[(parts[0],parts[1])],parts[2]))
        elif len(parts)==2 and inventory_scopes:requests.append((term,[scope for scope in inventory_scopes if scope[1] == parts[0] or scope[1].startswith(parts[0]+'_')],parts[1]))
        elif len(parts)==2 and default_db:requests.append((term,[(identifier_parts(default_db)[0],parts[0])],parts[1]))
        else:requests.append((term,sorted(scopes) or inventory_scopes or ([(identifier_parts(default_db)[0],None)] if default_db and len(identifier_parts(default_db))==1 else []),None))
    if any(not scope for _,scope,_ in requests):return ToolResult(status='failed',summary='Specify a database/schema or select workspace tables before catalog discovery.',error_code='catalog_scope_required')
    if declared and any(sc is None or (db,sc) not in declared for _,items,_ in requests for db,sc in items):
        return ToolResult(status='denied',summary='This discovery scope is outside the current run schema scope.',error_code='authorization_denied')
    matches={term:[] for term in terms};scans=0; checked_scopes=set(); deferred_scopes=set(); failed_scopes=[]
    # Shared run-local cache also remembers a failed scoped operation. Changing
    # natural-language wording cannot repeat a timed-out schema/database scan.
    with workbench._domain_lock:
        cache=getattr(workbench,'_scoped_catalog_cache',None)
        if cache is None:cache={};workbench._scoped_catalog_cache=cache
        for term,term_scopes,exact in requests:
            for db,sc in term_scopes:
                if (db,sc) not in term_scopes[:8]:
                    deferred_scopes.add((db,sc));continue
                quote=lambda v:'"'+v.replace('"','""')+'"'
                where=[];params=[]
                if sc is not None:where.append('TABLE_SCHEMA = ?');params.append(sc)
                if exact:where.append('TABLE_NAME = ?');params.append(exact)
                else:
                    for token in re.findall(r'[a-z0-9]+',term.casefold()):
                        # Business prompts commonly pluralize singular physical names.
                        token = token[:-1] if len(token)>3 and token.endswith('s') and not token.endswith('ss') else token
                        where.append("LOWER(TABLE_CATALOG || '.' || TABLE_SCHEMA || '.' || TABLE_NAME) LIKE ?");params.append('%'+token+'%')
                query=f'SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME FROM {quote(db)}.INFORMATION_SCHEMA.TABLES'
                query+=(' WHERE '+' AND '.join(where)) if where else ''
                query+=' ORDER BY TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME LIMIT ?';params.append(limit)
                failure_key=('failure',db,sc,exact or 'discovery')
                if failure_key in cache:
                    failed_scopes.append(cache[failure_key].model_copy(deep=True));continue
                key=(query,tuple(params))
                if key not in cache:
                    used = getattr(workbench, '_catalog_discovery_queries', 0)
                    # Shared by single and batch tools; wording changes cannot
                    # cause an unbounded scan loop. Exact three-part lookups remain available.
                    if used >= 24 and len(identifier_parts(term)) != 3:
                        deferred_scopes.add((db,sc));continue
                    workbench._catalog_discovery_queries = used + 1
                    try:cache[key]=workbench._session.sql(query,params=params).collect();scans+=1
                    except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated):raise
                    except Exception as error:
                        diagnostics=sql_diagnostics(error)
                        result=ToolResult(status='failed',summary='Scoped catalog discovery could not complete. Narrow the object or scope before retrying.',error_code='catalog_timeout' if str(diagnostics.get('native_code','')).lstrip('0')=='630' else 'catalog_query_failed',data={'scope':{'database':db,'schema':sc},'diagnostics':diagnostics,'coverage':'incomplete'},metrics={'metadata_scans':scans+1})
                        cache[failure_key]=result;failed_scopes.append(result);continue
                checked_scopes.add((db,sc))
                for raw in cache[key]:
                    row=raw.as_dict() if hasattr(raw,'as_dict') else dict(raw)
                    name=str(row['TABLE_NAME']);database_name=str(row['TABLE_CATALOG']);schema_name=str(row['TABLE_SCHEMA'])
                    fqn='.'.join(quote(v) for v in (database_name,schema_name,name))
                    candidate={'table':fqn,'database':database_name,'schema':schema_name,'name':name}
                    if candidate not in matches[term]:matches[term].append(candidate)
                matches[term]=matches[term][:limit]
    if failed_scopes and not checked_scopes:
        return failed_scopes[0]
    return ToolResult(status='succeeded',summary=f'Searched {len(checked_scopes)} caller-visible scope(s). Results establish matches only in checked scopes; they do not establish account-wide absence. Inspect returned exact names before selecting tables. Do not repeat broad searches after the discovery allowance is exhausted.',data={'coverage':{'checked_scopes':[{'database':db,'schema':sc} for db,sc in sorted(checked_scopes)],'deferred_scopes':[{'database':db,'schema':sc} for db,sc in sorted(deferred_scopes)],'exhaustive':False,'schema_inventory_partial':inventory_partial,'failed_scopes':[failure.data for failure in failed_scopes],'discovery_allowance_exhausted':getattr(workbench,'_catalog_discovery_queries',0)>=24},'terms':terms,'matches':matches,'candidates':sorted({c['table'] for rows in matches.values() for c in rows})},evidence_refs=[f'catalog_search:{term}' for term in terms],metrics={'metadata_scans':scans,'candidate_count':len({c['table'] for rows in matches.values() for c in rows})})
