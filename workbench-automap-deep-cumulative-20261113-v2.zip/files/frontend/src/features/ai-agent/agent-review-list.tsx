'use client';

import { useState, type ReactNode } from 'react';
import { AiaBox, AiaButton, AiaInput, AiaStack } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

export type AgentReviewChoice = { id: string; label: string; description: string; confidence?: number | null };

export type AgentReviewItem = {
  id: string;
  category: string;
  summary: string;
  question: string;
  status: string;
  sttmId: string | null;
  blocking: boolean;
  subject: string | null;
  recommendedChoiceId: string | null;
  allowFreeText: boolean;
  choices: AgentReviewChoice[];
};

type AgentReviewListProps = {
  items: AgentReviewItem[];
  busy: boolean;
  error: string | null;
  onAnswer: (itemId: string, choiceId: string | null, text: string | null) => void;
  footer?: ReactNode;
};

function ReviewCard({ item, busy, onAnswer }: {
  item: AgentReviewItem;
  busy: boolean;
  onAnswer: AgentReviewListProps['onAnswer'];
}) {
  const [text, setText] = useState('');
  const [selectedChoice, setSelectedChoice] = useState<string | null>(item.recommendedChoiceId);
  const answerable = item.choices.length > 0 || item.allowFreeText;
  const heading = item.question && item.question !== item.summary ? item.question : item.summary;
  return (
    <AiaBox component="li" id={`review-card-${item.id}`} sx={{ listStyle: 'none', p: 1.25, border: '1px solid #e2e8f0', borderLeft: `3px solid ${item.blocking ? '#f59e0b' : '#cbd5e1'}`, borderRadius: 1.5, backgroundColor: '#fff', minWidth: 0 }}>
      {item.subject ? <AiaText sx={{ fontSize: 10.5, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.04em', overflowWrap: 'anywhere' }}>{item.subject}</AiaText> : null}
      <AiaText sx={{ mt: 0.25, fontSize: 12.5, fontWeight: 700, color: '#0f172a', overflowWrap: 'anywhere' }}>{heading}</AiaText>
      {heading !== item.summary ? <AiaText sx={{ mt: 0.25, fontSize: 11.5, color: '#475569', overflowWrap: 'anywhere' }}>{item.summary}</AiaText> : null}
      {item.choices.length ? <AiaStack role="radiogroup" aria-label={heading} spacing={0.5} sx={{ mt: 0.9 }}>
        {item.choices.map((choice) => {
          const recommended = choice.id === item.recommendedChoiceId;
          const selected = selectedChoice === choice.id;
          const confidence = choice.confidence == null ? null : Math.round(choice.confidence * 100);
          const confidenceColor = confidence == null ? '#64748b' : confidence >= 80 ? '#166534' : confidence >= 60 ? '#92400e' : '#991b1b';
          const confidenceBackground = confidence == null ? '#f1f5f9' : confidence >= 80 ? '#dcfce7' : confidence >= 60 ? '#fef3c7' : '#fee2e2';
          return <AiaBox key={choice.id} component="button" type="button" role="radio" aria-checked={selected}
            disabled={busy} title={choice.description || choice.label} onClick={() => setSelectedChoice(choice.id)}
            sx={{ width: '100%', minHeight: 44, display: 'grid', gridTemplateColumns: '18px minmax(0, 1fr)', gap: 0.75,
              alignItems: 'start', p: 0.9, border: `1px solid ${selected ? '#60a5fa' : '#e2e8f0'}`, borderRadius: 1,
              backgroundColor: selected ? '#eff6ff' : '#fff', textAlign: 'left', cursor: 'pointer', color: '#0f172a' }}>
            <AiaBox component="span" aria-hidden sx={{ mt: 0.2, width: 14, height: 14, borderRadius: '50%',
              border: `1px solid ${selected ? '#2563eb' : '#94a3b8'}`,
              boxShadow: selected ? 'inset 0 0 0 3px #eff6ff' : 'none',
              backgroundColor: selected ? '#2563eb' : '#fff' }} />
            <AiaBox component="span" sx={{ display: 'block', minWidth: 0 }}>
              <AiaStack component="span" direction="row" spacing={0.5} useFlexGap sx={{ alignItems: 'center', flexWrap: 'wrap' }}>
                <AiaText component="span" sx={{ fontSize: 13, fontWeight: 600 }}>{choice.label}</AiaText>
                {recommended ? <AiaBox component="span" sx={{ px: 0.6, py: 0.1, borderRadius: 999, fontSize: 10,
                  fontWeight: 600, color: '#1d4ed8', backgroundColor: '#dbeafe' }}>Recommended</AiaBox> : null}
              </AiaStack>
              {choice.description ? <AiaText component="span" sx={{ display: 'block', mt: 0.2, fontSize: 12, fontWeight: 400, color: '#64748b' }}>{choice.description}</AiaText> : null}
              {confidence != null ? <AiaBox component="span" sx={{ display: 'inline-block', mt: 0.45, px: 0.65, py: 0.15,
                borderRadius: 999, backgroundColor: confidenceBackground, color: confidenceColor, fontSize: 10.5,
                fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>{confidence}% confidence</AiaBox> : null}
            </AiaBox>
          </AiaBox>;
        })}
        <AiaButton size="small" variant="contained" disabled={busy || !selectedChoice}
          onClick={() => selectedChoice && onAnswer(item.id, selectedChoice, null)} sx={{ alignSelf: 'flex-start', mt: 0.35, textTransform: 'none' }}>
          Apply answer
        </AiaButton>
      </AiaStack> : null}
      {item.allowFreeText && answerable ? <AiaStack direction="row" spacing={0.75} sx={{ mt: 0.9, alignItems: 'flex-start' }}>
        <AiaInput size="small" multiline minRows={1} value={text} onChange={setText}
          placeholder={item.choices.length ? 'Or type a value, source column or instruction' : 'Type your answer'}
          sx={{ flex: 1, '& .MuiInputBase-input': { fontSize: 12 } }} />
        <AiaButton size="small" variant="contained" disabled={busy || !text.trim()} onClick={() => { onAnswer(item.id, null, text.trim()); setText(''); }} sx={{ textTransform: 'none', flexShrink: 0 }}>Send</AiaButton>
      </AiaStack> : null}
    </AiaBox>
  );
}

/** Open review items as answerable cards: needed ones first, then optional. */
export function AgentReviewList({ items, busy, error, onAnswer, footer }: AgentReviewListProps) {
  const needed = items.filter((item) => item.blocking);
  const optional = items.filter((item) => !item.blocking);
  const section = (title: string, list: AgentReviewItem[]) => list.length ? <AiaBox sx={{ mb: 1.5 }}>
    <AiaText sx={{ mb: 0.75, fontSize: 11, fontWeight: 800, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title} · {list.length}</AiaText>
    <AiaStack component="ul" spacing={0.75} sx={{ m: 0, p: 0 }}>
      {list.map((item) => <ReviewCard key={item.id} item={item} busy={busy} onAnswer={onAnswer} />)}
    </AiaStack>
  </AiaBox> : null;
  return (
    <AiaBox>
      {error ? <AiaText role="alert" sx={{ mb: 1, fontSize: 12, color: '#b91c1c' }}>{error}</AiaText> : null}
      {items.length ? <>
        {section('Needed', needed)}
        {section('Optional', optional)}
      </> : <AiaText sx={{ fontSize: 12, color: '#64748b' }}>No open review items.</AiaText>}
      {footer}
      <AiaText sx={{ mt: 1, fontSize: 10.5, color: '#64748b' }}>Answers are recorded on the run; mapping choices update the saved draft. Nothing is published.</AiaText>
    </AiaBox>
  );
}
