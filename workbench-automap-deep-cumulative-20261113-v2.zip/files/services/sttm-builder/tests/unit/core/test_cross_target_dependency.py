"""A column that references another target is built from that target's own key rule."""
from __future__ import annotations

from app.migration_workflow.dependency_resolution import ForeignKey, resolve, translate

CONTACTS = "DB.SRC.CONTACTS"
BUSINESSES = "DB.SRC.BUSINESSES"


def _contract(expression: str, sources: list[str]) -> dict:
    return {
        "artifact_id": "biz_accounts:LEGACY_ID__C",
        "payload": {"mapping_rows": [{"target_column": "LEGACY_ID__C", "expression": expression,
                                      "source_columns": sources, "evidence_ids": ["precedent:1"]}]},
    }


def _edge(**overrides) -> dict:
    return {"consumer_mapping": "biz_contacts", "producer_mapping": "biz_accounts",
            "producer_output": "biz_accounts:LEGACY_ID__C", "producer_columns": ["LEGACY_ID__C"],
            "consumer_columns": ["ACCOUNTID"], "evidence_id": "dependency:1", **overrides}


def _keys(parent_table: str, parent_column: str) -> list[ForeignKey]:
    if (parent_table, parent_column) == (BUSINESSES, "ID"):
        return [ForeignKey(CONTACTS, "BUSINESS_ID", BUSINESSES, "ID", 0.97, "relationship_graph:CONTACTS.BUSINESS_ID")]
    return []


def test_consumer_column_reuses_the_producer_key_rule_over_its_foreign_key() -> None:
    rows = [{"target_column": "ACCOUNTID", "status": "draft", "expression": "<BizAcctMaster>.SF_ACCOUNT_ID",
             "source_columns": [], "confidence": 0.2}]
    resolutions = resolve(
        consumer_key="biz_contacts", rows=rows, edges=[_edge()],
        contracts=[_contract(f"'EN-' || {BUSINESSES}.ID", [f"{BUSINESSES}.ID"])],
        consumer_tables={CONTACTS}, foreign_keys=_keys, min_confidence=0.8,
    )
    assert resolutions[0].status == "resolved"
    assert rows[0]["expression"] == f"'EN-' || {CONTACTS}.BUSINESS_ID"
    assert rows[0]["source_columns"] == [f"{CONTACTS}.BUSINESS_ID"]
    assert rows[0]["confidence"] == 0.97 and "relationship_graph:CONTACTS.BUSINESS_ID" in rows[0]["evidence_ids"]
    assert rows[0]["dependency"]["producer_mapping"] == "biz_accounts"


def test_a_short_form_reference_and_a_plain_producer_column_are_translated() -> None:
    assert translate("CONCAT($Prefix, BUSINESSES.ID)", {("BUSINESSES", "ID"): "DB.SRC.CONTACTS.BUSINESS_ID"}) == \
        "CONCAT($Prefix, DB.SRC.CONTACTS.BUSINESS_ID)"
    assert translate("'BUSINESSES.ID' || BUSINESSES.ID", {("BUSINESSES", "ID"): "X.Y"}) == "'BUSINESSES.ID' || X.Y"
    rows = [{"target_column": "ACCOUNTID", "status": "unresolved", "source_columns": []}]
    resolve(consumer_key="biz_contacts", rows=rows, edges=[_edge()],
            contracts=[_contract("", [f"{BUSINESSES}.ID"])], consumer_tables={CONTACTS},
            foreign_keys=_keys, min_confidence=0.8)
    assert rows[0]["status"] == "draft" and rows[0]["expression"] == f"{CONTACTS}.BUSINESS_ID"


def test_load_time_values_and_missing_joins_are_reported_not_guessed() -> None:
    rows = [{"target_column": "ACCOUNTID", "status": "draft", "expression": "X", "source_columns": ["a.b"]}]
    [load_time] = resolve(consumer_key="biz_contacts", rows=rows, edges=[_edge(availability="load_time")],
                          contracts=[], consumer_tables={CONTACTS}, foreign_keys=_keys, min_confidence=0.8)
    assert load_time.status == "load_time" and rows[0]["status"] == "unresolved"
    assert rows[0]["missing_dependencies"] == ["load_time:biz_accounts.LEGACY_ID__C"]

    rows = [{"target_column": "ACCOUNTID", "status": "draft", "expression": "KEEP", "source_columns": []}]
    [missing] = resolve(consumer_key="biz_contacts", rows=rows, edges=[_edge()],
                        contracts=[_contract("OTHER.ID", ["DB.SRC.OTHER.ID"])], consumer_tables={CONTACTS},
                        foreign_keys=_keys, min_confidence=0.8)
    assert missing.status == "unresolved" and rows[0]["expression"] == "KEEP"

    # A weak join is not used.
    weak = lambda table, column: [ForeignKey(CONTACTS, "BUSINESS_ID", BUSINESSES, "ID", 0.4, "e")]
    [low] = resolve(consumer_key="biz_contacts", rows=rows, edges=[_edge()],
                    contracts=[_contract(f"{BUSINESSES}.ID", [f"{BUSINESSES}.ID"])], consumer_tables={CONTACTS},
                    foreign_keys=weak, min_confidence=0.8)
    assert low.status == "unresolved"


def test_other_consumers_edges_are_ignored() -> None:
    rows = [{"target_column": "ACCOUNTID", "status": "draft"}]
    assert resolve(consumer_key="calls", rows=rows, edges=[_edge()], contracts=[], consumer_tables={CONTACTS},
                   foreign_keys=_keys, min_confidence=0.8) == []
