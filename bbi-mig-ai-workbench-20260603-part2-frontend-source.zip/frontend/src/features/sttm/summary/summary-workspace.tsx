"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import AccountTreeOutlinedIcon from "@mui/icons-material/AccountTreeOutlined";
import AutoAwesomeRoundedIcon from "@mui/icons-material/AutoAwesomeRounded";
import TerminalRoundedIcon from "@mui/icons-material/TerminalRounded";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import { Alert, Box, LinearProgress, Typography } from "@mui/material";
import { MappingSqlPreview } from "@/components/sql";
import LineageTab from "@/features/sttm/lineage/lineage-tab";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import {
  buildMappingInsertSql,
  buildMappingSelectSql,
  parseSourceColumns,
  buildSourceQueryPreviewSql,
} from "@/features/sttm/mapping/mapping-utils";
import { BuilderWorkspaceTabBar } from "@/features/sttm/shared/builder-workspace-tab-bar";
import { dbService } from "@/services/dbService";
import { AiSummaryPanel } from "./ai-summary-panel";
import { DbtConversionTab } from "./dbt-conversion-tab";
import { SummaryExportActions } from "./summary-export-actions";
import { SummaryStatsRow } from "./summary-stats-row";
import { buildSummaryMetrics } from "./summary-utils";
import { SttmSheetTab } from "./sttm-sheet-tab";

type SummaryTab = "sttm-sheet" | "sql-preview" | "data-lineage" | "dbt-conversion";

function qualifiedNameToTableRef(qualifiedName: string) {
  const [database, schema, table] = qualifiedName.split(".", 3);
  if (!database || !schema || !table) return null;
  return { database, schema, table };
}

function countFilterConditions(
  groups: Array<{ type?: string; children?: unknown[] }>,
): number {
  return groups.reduce((count, group) => {
    if (group.type === "condition") {
      return count + 1;
    }
    const children = Array.isArray(group.children)
      ? (group.children as Array<{ type?: string; children?: unknown[] }>)
      : [];
    return count + countFilterConditions(children);
  }, 0);
}

export function SummaryWorkspace() {
  const {
    mappings,
    sources,
    targets,
    relationships,
    derivedSources,
    session,
    semanticBundleLabel,
    semanticViewName,
    sourceFilterGroups,
    sourceQuerySql,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
  } = useSttmBuilderContext();

  const [tab, setTab] = useState<SummaryTab>("sttm-sheet");
  const [excelExportLoading, setExcelExportLoading] = useState(false);
  const [excelExportStage, setExcelExportStage] = useState<string | null>(null);
  const [excelExportProgress, setExcelExportProgress] = useState(0);
  const [excelExportError, setExcelExportError] = useState<string | null>(null);
  const [gitPushNotice, setGitPushNotice] = useState<string | null>(null);
  const exportProgressTimerRef = useRef<number | null>(null);

  const selectedTargetQualifiedName =
    targets.find((table) => table.isSelected)?.qualifiedName ?? null;

  const metrics = useMemo(
    () =>
      buildSummaryMetrics({
        mappings,
        sources,
        joinCount: relationships.length,
      }),
    [mappings, relationships.length, sources],
  );

  const selectedInputCount = useMemo(
    () =>
      sources.filter((table) => table.isSelected).length +
      derivedSources.filter((source) => source.isSelected).length,
    [derivedSources, sources],
  );

  const filterCount = useMemo(
    () => countFilterConditions(sourceFilterGroups as Array<{ type?: string; children?: unknown[] }>),
    [sourceFilterGroups],
  );

  const sourceQueryPreviewSql = useMemo(
    () =>
      buildSourceQueryPreviewSql({
        sourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [sourceFilterSql, sourceGroupBySql, sourceOrderBySql, sourceQuerySql],
  );

  const generatedSql = useMemo(
    () =>
      buildMappingInsertSql({
        mappings,
        targetQualifiedName: selectedTargetQualifiedName,
        sourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [
      mappings,
      selectedTargetQualifiedName,
      sourceQuerySql,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
    ],
  );

  const previewSql = useMemo(
    () =>
      buildMappingSelectSql({
        mappings,
        sourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [mappings, sourceFilterSql, sourceGroupBySql, sourceOrderBySql, sourceQuerySql],
  );

  const narrative = useMemo(() => {
    const targetLabel = selectedTargetQualifiedName ?? "the selected target table";
    const sourceLabels = metrics.sourceTableLabels.join(", ") || "selected source tables";
    const transformText =
      metrics.transformRules.length > 0
        ? ` Transform rules applied: ${metrics.transformRules.join(", ")}.`
        : "";
    return `Mapping ${metrics.mappedCount} of ${metrics.totalCount} target columns from ${sourceLabels} into ${targetLabel}.${transformText} Overall coverage is ${metrics.progressPercent}%.`;
  }, [metrics, selectedTargetQualifiedName]);

  const handleExportSql = () => {
    if (!generatedSql.trim()) {
      return;
    }
    const blob = new Blob([generatedSql], { type: "text/sql;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "mapping.sql";
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const clearExportProgressTimer = () => {
    if (exportProgressTimerRef.current !== null) {
      window.clearInterval(exportProgressTimerRef.current);
      exportProgressTimerRef.current = null;
    }
  };

  useEffect(() => clearExportProgressTimer, []);

  const beginExportProgress = () => {
    clearExportProgressTimer();
    setExcelExportProgress(8);
    exportProgressTimerRef.current = window.setInterval(() => {
      setExcelExportProgress((current) => (current >= 88 ? current : current + 8));
    }, 900);
  };

  const handleExportExcel = async () => {
    setExcelExportLoading(true);
    setGitPushNotice(null);
    setExcelExportError(null);
    setExcelExportStage("Collecting mapping context for the workbook...");
    beginExportProgress();
    const selectedSourceTables = sources
      .filter((table) => table.isSelected)
      .map((table) => qualifiedNameToTableRef(table.qualifiedName))
      .filter((table): table is NonNullable<typeof table> => Boolean(table));
    const targetTable = selectedTargetQualifiedName
      ? qualifiedNameToTableRef(selectedTargetQualifiedName)
      : null;
    const relationshipPayload = relationships
      .filter((join) => join.leftTableId && join.rightTableId && join.conditions?.length)
      .map((join) => {
        const leftTable = qualifiedNameToTableRef(String(join.leftTableId));
        const rightTable = qualifiedNameToTableRef(String(join.rightTableId));
        return leftTable && rightTable
          ? {
              left_table: leftTable,
              right_table: rightTable,
              join_type: join.joinType ?? "INNER",
              constraint_name: join.constraintName ?? null,
              source: join.source ?? "USER_DEFINED",
              locked: join.locked ?? false,
              conditions: (join.conditions ?? [])
                .filter((condition) => condition.leftColumn && condition.rightColumn)
                .map((condition) => ({
                  left_column: String(condition.leftColumn),
                  right_column: String(condition.rightColumn),
                  operator: condition.operator ?? "=",
                })),
            }
          : null;
      })
      .filter((item): item is NonNullable<typeof item> => Boolean(item));

    const payload = {
      project_name: targetTable?.table ? `${targetTable.table} STTM Export` : "STTM Export",
      summary_narrative: narrative,
      created_by:
        session?.display_name ||
        session?.email ||
        (session?.user_id !== undefined && session?.user_id !== null ? String(session.user_id) : "Unknown"),
      created_at: new Date().toISOString(),
      version_label: semanticBundleLabel || semanticViewName || "Current builder session",
      target_table: targetTable,
      source_tables: selectedSourceTables,
      relationships: relationshipPayload,
      derived_sources: derivedSources
        .filter((source) => source.isSelected)
        .map((source) => ({
          derived_source_id: source.id,
          derived_source_name: source.sourceName,
          sql_text: source.sqlText ?? null,
          source_tables: (source.baseSourceTables ?? []).filter(Boolean),
          base_source_tables: (source.baseSourceTables ?? []).filter(Boolean),
          semantic_view_name: source.semanticViewName ?? null,
          semantic_bundle_label: source.semanticBundleLabel ?? null,
        })),
      filters_sql: sourceFilterSql || null,
      source_query_sql: sourceQueryPreviewSql,
      preview_sql: previewSql,
      generated_sql: generatedSql,
      mappings: mappings
        .filter((mapping) => mapping.status === "MAPPED")
        .map((mapping) => ({
          target_column: mapping.targetColumn,
          target_type: mapping.targetType,
          source_column: mapping.sourceColumn,
          source_columns:
            mapping.sourceColumns && mapping.sourceColumns.length
              ? mapping.sourceColumns
              : parseSourceColumns(mapping.sourceColumn),
          expression: mapping.expression,
          rule: mapping.rule,
          status: mapping.status,
          nl_rule: mapping.nlRule ?? null,
          description: mapping.description ?? null,
        })),
    };

    try {
      setExcelExportProgress(28);
      setExcelExportStage("Preparing workbook sheets and sample values...");
      const blob = await dbService.exportSttmWorkbook(payload);
      setExcelExportProgress(95);
      setExcelExportStage("Workbook is ready. Starting the download...");
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${targetTable?.table ?? "sttm"}_export.xlsx`;
      anchor.click();
      URL.revokeObjectURL(url);
      setExcelExportProgress(100);
      setTimeout(() => {
        setExcelExportStage(null);
        setExcelExportProgress(0);
      }, 1200);
    } catch (error) {
      setExcelExportError(
        error instanceof Error ? error.message : "Unable to generate the Excel workbook.",
      );
      setExcelExportStage("Workbook generation failed. Review the error and try again.");
      setExcelExportProgress(0);
    } finally {
      clearExportProgressTimer();
      setExcelExportLoading(false);
    }
  };

  const handlePushToGit = () => {
    setGitPushNotice("Dummy action only for now. The DBT git push wiring is not connected yet.");
  };

  return (
    <Box sx={{ display: "flex", flex: 1, minHeight: 0, minWidth: 0, flexDirection: "column", overflow: "hidden" }}>
      <BuilderWorkspaceTabBar
        backgroundColor="#ffffff"
        tabs={[
          { key: "sttm-sheet", label: "STTM Sheet", icon: <TableChartOutlinedIcon sx={{ fontSize: 17 }} /> },
          {
            key: "sql-preview",
            label: "SQL Preview",
            icon: <TerminalRoundedIcon sx={{ fontSize: 17 }} />,
            badge: metrics.mappedCount > 0 ? metrics.mappedCount : undefined,
          },
          {
            key: "dbt-conversion",
            label: "DBT Conversion",
            icon: <AutoAwesomeRoundedIcon sx={{ fontSize: 17 }} />,
          },
          { key: "data-lineage", label: "Data Lineage", icon: <AccountTreeOutlinedIcon sx={{ fontSize: 17 }} /> },
        ]}
        activeTab={tab}
        onTabChange={setTab}
        trailing={
          <SummaryExportActions
            mappedCount={metrics.mappedCount}
            totalCount={metrics.totalCount}
            excelLoading={excelExportLoading}
            excelLabel={excelExportLoading ? "Generating Excel..." : "Download Excel"}
            onExportExcel={() => {
              void handleExportExcel();
            }}
            onExportSql={handleExportSql}
            onPushToGit={handlePushToGit}
          />
        }
      />

      {excelExportStage || gitPushNotice ? (
        <Box sx={{ px: 2, pt: 1.5, pb: 0.5, backgroundColor: "#ffffff" }}>
          {excelExportStage ? (
            <Alert
              severity={excelExportError ? "error" : excelExportLoading ? "info" : "success"}
              sx={{ borderRadius: 2, alignItems: "center", mb: gitPushNotice ? 1 : 0 }}
            >
              <Typography sx={{ fontSize: "0.82rem", fontWeight: 700, mb: 0.35 }}>
                {excelExportStage}
              </Typography>
              {!excelExportError ? (
                <LinearProgress
                  variant={excelExportProgress > 0 ? "determinate" : "indeterminate"}
                  value={excelExportProgress}
                  sx={{
                    mt: 0.75,
                    height: 6,
                    borderRadius: 999,
                    bgcolor: "rgba(148,163,184,0.18)",
                  }}
                />
              ) : (
                <Typography sx={{ fontSize: "0.78rem", lineHeight: 1.5 }}>
                  {excelExportError}
                </Typography>
              )}
            </Alert>
          ) : null}
          {gitPushNotice ? (
            <Alert severity="info" sx={{ borderRadius: 2 }}>
              <Typography sx={{ fontSize: "0.8rem", lineHeight: 1.5 }}>
                {gitPushNotice}
              </Typography>
            </Alert>
          ) : null}
        </Box>
      ) : null}

      <Box sx={{ display: "flex", flex: 1, minHeight: 0, minWidth: 0, overflow: "hidden" }}>
        <Box sx={{ flex: 1, minWidth: 0, minHeight: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          <SummaryStatsRow metrics={metrics} targetQualifiedName={selectedTargetQualifiedName} />

          {tab === "sttm-sheet" ? <SttmSheetTab mappings={mappings} /> : null}
          {tab === "sql-preview" ? (
            <MappingSqlPreview
              readOnly
              targetLabel={selectedTargetQualifiedName?.split(".").pop() ?? null}
              mappedCount={metrics.mappedCount}
              tableCount={selectedInputCount}
              filterCount={filterCount}
              joinCount={relationships.length}
              sourceQuerySql={sourceQueryPreviewSql}
              generatedSql={generatedSql}
            />
          ) : null}
          {tab === "data-lineage" ? (
            <Box sx={{ flex: 1, minHeight: 0, minWidth: 0, overflow: "hidden" }}>
              <LineageTab />
            </Box>
          ) : null}
          <DbtConversionTab
            active={tab === "dbt-conversion"}
            validatedSql={previewSql}
            generatedSql={generatedSql}
            sourceQuerySql={sourceQueryPreviewSql}
          />
        </Box>

        <AiSummaryPanel
          metrics={metrics}
          targetQualifiedName={selectedTargetQualifiedName}
          narrative={narrative}
        />
      </Box>
    </Box>
  );
}
