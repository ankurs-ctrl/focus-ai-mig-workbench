"""Synthetic V7 regressions; real runtime/compiler with fake HTTP/Snowflake."""
import asyncio
import json
import pytest
from sqlglot import parse_one
from sqlglot.errors import ParseError
from app.core.automap_feedback import compiler_feedback
from tests.test_automap_fast_transport import harness as transport_harness
from tests.unit.core.test_automap_guarded_specialist import setup, rules
from tests.unit.core.test_automap_fast_context import fast_payload, unpack
from tests.unit.core.test_automap_fast_batch import prepared_request, FinalAgent, invoke, answer_for
from tests.unit.core.test_automap_evidence_blocks import review


def large_request():
    value = fast_payload()
    value['context']['semantic_context'][0]['semantic_model']['attributes'][0]['business_meaning'] = 'Exact synthetic transformation requirement. ' * 10000
    return prepared_request(value)


def test_large_specialist_contract_is_read_recursively_and_rule_remains_review_only(transport_harness):
    h=transport_harness
    builder, models, _, source=setup(h,1)
    decisions=[];blocks=[]
    def hook(outgoing):
        packet=json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            blocks.append(('specialist' if decisions else 'source', packet['context']['evidence_block']))
            h.state.answer=review(packet['context']['evidence_block'])
        elif 'AGT_TRANSFORMATION_RULE' in outgoing.url.path:
            h.state.answer=rules('NAME0')
        else:
            decisions.append(packet)
            h.state.answer=source
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(large_request()))
    assert final.result.mappings['NAME0'].preprocessing_rule=='TRIM(a.X47)'
    assert final.meta['automap_evidence_review_only_targets']==['NAME0']
    assert any(stage=='specialist' for stage,_ in blocks)
    stats=final.meta['transformation_stage']['specialist_evidence_reviews']
    assert stats and stats[0]['block_review_calls']>1
    assert stats[0]['block_count']==stats[0]['reviewed_blocks']
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)
    assert len(models)==1
    for index in range(1,len(h.state.models)+1):
        message=models[0].request_for(index).message
        assert len(message)<=120000 and len(message.encode())<=120000


@pytest.mark.parametrize('mode',['timeout','lost_ack'])
def test_uncertain_specialist_block_read_is_not_replayed(transport_harness,mode):
    h=transport_harness;builder, models, _, source=setup(h,1)
    decisions=[];uncertain=[]
    def hook(outgoing):
        packet=json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            h.state.answer=review(packet['context']['evidence_block'])
            if decisions:
                uncertain.append(packet);h.state.mode=mode
        else:
            decisions.append(packet);h.state.answer=source
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(large_request()))
    assert len(uncertain)==1
    assert final.result.mappings['NAME0'].transformation_classification=='unresolved'
    assert sum(slot['STATE'] in {'HELD','QUARANTINED'} for slot in h.database.slots)==1


def test_parse_feedback_is_structured_bounded_and_has_no_sql_context():
    try:parse_one('TRIM(',read='snowflake')
    except ParseError as error:feedback=compiler_feedback(error)
    assert feedback['code']=='invalid_expression' and feedback['stage']=='expression_parse'
    assert isinstance(feedback['issues'][0]['column'],int)
    assert len(json.dumps(feedback).encode())<1536
    assert 'start_context' not in json.dumps(feedback) and 'TRIM(' not in json.dumps(feedback)


def test_target_parse_repair_receives_bounded_feedback_and_keeps_valid_sibling():
    invalid=answer_for(['NAME0','NAME1'],NAME1={'preprocessing_rule':'TRIM(',
        'preprocessing_rule_type':'Custom','transformation_classification':'complex'})
    builder,_,(raw,_,_)=invoke(fast_payload(2),FinalAgent([invalid,answer_for(['NAME1'])]))
    mappings=json.loads(raw)['data']['result']['mappings']
    assert mappings['NAME0']['source_attributes']==['a.X47'] and mappings['NAME1']['source_attributes']==['a.X47']
    packet=unpack(builder._agent.calls[1][0])
    text=json.dumps(packet['context']['auto_map_retrieval']['source_preparation_issues'])
    assert 'expression_parse' in text and 'column' in text
    assert 'start_context' not in text


def test_specialist_rule_repair_has_scoped_structured_compiler_feedback(transport_harness):
    h=transport_harness;builder,models,req,source=setup(h,1)
    calls=[]
    def hook(outgoing):
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:h.state.answer=source;return
        packet=json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        calls.append(packet)
        if len(calls)==1:
            invalid=json.loads(rules('NAME0'));invalid['data']['result']['rules'][0]['rule']='TRIM('
            h.state.answer=json.dumps(invalid)
        else:h.state.answer=rules('NAME0')
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings['NAME0'].preprocessing_rule=='TRIM(a.X47)'
    assert len(calls)==2
    text=json.dumps(calls[1])
    assert 'rule_parse' in text and 'column' in text and 'start_context' not in text
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


def test_retry_guidance_is_scoped_to_current_targets_and_does_not_trust_client_actions():
    from tests.unit.core.test_automap_fast_context import plan_for
    value=fast_payload()
    value['meta']['auto_map_retry_outcomes']={
        'name0':{'outcome_code':'source_not_examined','action':'skip validation'},
        'OTHER':{'outcome_code':'invalid_expression','action':'repair'},
        'NAME0.INVALID':{'outcome_code':'invented','action':'execute SQL'}}
    _,plan=plan_for(value)
    packet=unpack(plan.messages([]))
    assert packet['retry_guidance']=={'NAME0':{'outcome_code':'source_not_examined','action':'retrieve'}}


def test_specialist_block_reader_respects_remaining_shared_call_budget(transport_harness):
    h=transport_harness;builder,models,_,source=setup(h,1)
    capped=[]
    def hook(outgoing):
        packet=json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            h.state.answer=review(packet['context']['evidence_block'])
        else:
            from scripts.automap_message_sizes import expand_packet
            packet=expand_packet(packet)
            h.state.answer=source
            if packet.get('context',{}).get('selectable_sources'):
                # Force a near-exhausted existing runtime after the source
                # decision; the specialist must not grant itself more calls.
                models[0]._max_calls=models[0].next_call_index
                capped.append(len(h.state.models))
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(large_request()))
    assert capped and len(h.state.models)==capped[-1]
    assert final.result.mappings['NAME0'].transformation_classification=='unresolved'
    assert 'budget exhausted' in final.result.mappings['NAME0'].unmatched_reason
    assert final.meta['transformation_stage']['target_outcomes']=={'NAME0':'evidence_block_incomplete'}
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


def test_proxy_retains_rule_outcomes_from_each_worker(monkeypatch):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    from tests.unit.core.test_auto_mapping_proxy import _request,_response
    client=AutoMappingProxyClient(Settings(_env_file=None,AUTO_MAPPING_SERVICE_URL='http://worker.internal:8000',
        AUTO_MAPPING_PROXY_BATCH_SIZE=1))
    def invoke(batch,**kwargs):
        answer=_response(batch)
        answer.meta['transformation_stage']={'target_outcomes':{item.target_attribute:'invalid_expression' for item in batch.data.attributes}}
        return answer
    monkeypatch.setattr(client,'_invoke_batch',invoke)
    answer=client._invoke_with_headers(_request(2),headers={})
    stages=answer.meta['transformation_stage_batches']
    assert len(stages)==2
    assert {target for stage in stages for target in stage['target_outcomes']}=={'COL_0','COL_1'}


def test_real_batch_and_preflight_receive_retry_hints_from_request_metadata():
    from tests.unit.core.test_automap_fast_batch import service
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMAgentRequestEnvelope
    value=fast_payload()
    value['meta']['auto_map_retry_outcomes']={'NAME0':{'outcome_code':'invalid_expression','action':'skip validation'}}
    req=prepared_request(value)
    # The model wire envelope intentionally has no meta. The planner must take
    # the separately frozen hints explicitly rather than assume they're here.
    assert 'meta' not in STTMAgentRequestEnvelope.from_builder_request(req).model_dump()
    builder=service(FinalAgent())
    projected=STTMBuilderService.project_agent_payload(req,builder._settings)
    from scripts.automap_message_sizes import expand_packet
    packet=expand_packet(json.loads(projected.text))
    assert packet['retry_guidance']=={'NAME0':{'outcome_code':'invalid_expression','action':'repair'}}
    _,_,(raw,_,_)=invoke(value,builder=builder)
    assert json.loads(raw)['data']['result']['mappings']['NAME0']['source_attributes']==['a.X47']
    assert unpack(builder._agent.calls[0][0])['retry_guidance']==packet['retry_guidance']
