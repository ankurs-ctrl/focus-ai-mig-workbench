// Run with node; use the project's installed TypeScript compiler, no test dependency.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');

const filename = path.resolve(__dirname, '../src/features/sttm/mapping/mapping-sql-artifact.ts');
const compiled = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
});
const loaded = new Module(filename, module);
loaded.require = require;
loaded._compile(compiled.outputText, filename);
const { selectMappingSqlArtifact, buildMappingCompilerContextHash, normalizeCompilerContextHash, savedCompilerSemanticContext } = loaded.exports;
const base = { relationGraph: {}, mappings: [], targetTable: 'CRM.HOUSEHOLD', projectId: 'firm-a', firmValues: [{ name: 'FirmID', value: 'A' }] };
const currentCompilerHash = buildMappingCompilerContextHash(base);
assert.match(currentCompilerHash, /^sha256:[0-9a-f]{64}$/);
assert.equal(buildMappingCompilerContextHash({ ...base, semanticContext: "x".repeat(74_000) }).length, 71);
const legacySerialized = JSON.stringify({ compilerContractVersion: "physical-column-case-v2",
  projectId: "firm-a", semanticContext: [] });
assert.equal(normalizeCompilerContextHash(legacySerialized),
  `sha256:${require('node:crypto').createHash('sha256').update(legacySerialized).digest('hex')}`);
const legacyCompilerInput = { ...base, compilerContractVersion: "physical-column-case-v1" };
assert.equal(selectMappingSqlArtifact({compiledSql:'SELECT a.BillFrequency', compiledPreviewSql:'SELECT a.BillFrequency',
  compiledReady:true, compiledContextHash:JSON.stringify(legacyCompilerInput), currentContextHash:currentCompilerHash,
  fallbackSql:'draft', fallbackPreviewSql:'draft', allowFallback:false}).source, 'generated');
assert.notEqual(buildMappingCompilerContextHash(base), buildMappingCompilerContextHash({ ...base, projectId: 'firm-b' }));
assert.notEqual(buildMappingCompilerContextHash(base), buildMappingCompilerContextHash({ ...base, firmValues: [{ name: 'FirmID', value: 'B' }] }));
const input = { compiledSql: "INSERT INTO CRM.HOUSEHOLD SELECT 'A'", compiledPreviewSql: "SELECT 'A'", compiledScriptSql: "SET FirmID = 'A';\nSELECT $FirmID;", compiledContextHash: currentCompilerHash, currentContextHash: currentCompilerHash, compiledReady: true, fallbackSql: 'draft', fallbackPreviewSql: 'draft' };
const artifact = selectMappingSqlArtifact(input);
assert.equal(artifact.scriptSql, input.compiledScriptSql);
assert.equal(artifact.previewSql, "SELECT 'A'");
assert.equal(artifact.generatedSql, input.compiledSql);
assert.equal(selectMappingSqlArtifact({ ...input, compiledReady: false }).ready, false);
assert.equal(selectMappingSqlArtifact({ ...input, currentContextHash: 'changed' }).scriptSql, 'draft');
assert.equal(selectMappingSqlArtifact({ ...input, currentContextHash: 'changed', allowFallback:false }).scriptSql, '');
assert.equal(selectMappingSqlArtifact({ ...input, allowFallback:false }).source, 'compiled');
assert.equal(selectMappingSqlArtifact({fallbackSql:'unsafe draft',fallbackPreviewSql:'unsafe draft',
  authoredSql:'SELECT 1',authoredIsCurrent:true,allowFallback:false}).source, 'authored');
assert.equal(selectMappingSqlArtifact({ ...input, currentContextHash: 'changed', authoredIsCurrent: true,
  authoredSql: input.compiledSql, authoredPreviewSql: input.compiledPreviewSql }).source, 'generated');
assert.notEqual(buildMappingCompilerContextHash(base), buildMappingCompilerContextHash({ ...base, semanticContext: { grain: 'household' } }));
console.log('Mapping SQL artifact regressions passed.');
const semantics = [{ table: { database: 'DB', schema: 'SRC', table: 'CONTACTS' }, semantic_model: { grain: 'contact' } }];
const savedHash = buildMappingCompilerContextHash({ ...base, semanticContext: semantics });
assert.deepEqual(savedCompilerSemanticContext(savedHash, 'firm-a', semantics, 'firm-a'), semantics);
assert.equal(savedCompilerSemanticContext(savedHash, 'firm-b', semantics, 'firm-a'), null);
assert.equal(savedCompilerSemanticContext('invalid', 'firm-a'), null);
assert.equal(savedCompilerSemanticContext(JSON.stringify({ projectId: 'firm-a', semanticContext: [{}] }), 'firm-a'), null);
assert.deepEqual(savedCompilerSemanticContext(JSON.stringify({ projectId: 'firm-a', semanticContext: semantics }), 'firm-a'), semantics);
assert.equal(buildMappingCompilerContextHash({ ...base, semanticContext: savedCompilerSemanticContext(savedHash, 'firm-a', semantics, 'firm-a') }), savedHash);
console.log('Saved semantic inputs survive reopen without weakening currency checks.');
const multiSource = { status: 'MAPPED', targetColumn: 'STREET', sourceColumns: ['a.STREET', 'a.UNIT'],
  expression: "CONCAT(a.STREET, a.UNIT)", sourceColumn: 'a.STREET' };
assert.equal(buildMappingCompilerContextHash({ ...base, mappings: [multiSource] }),
  buildMappingCompilerContextHash({ ...base, mappings: [{ ...multiSource, sourceColumn: 'a.STREET, a.UNIT' }] }));

// Exercise the actual rejection reducer without loading the UI/API dependency tree.
const sliceFile = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
const source = ts.createSourceFile(sliceFile, fs.readFileSync(sliceFile, 'utf8'), ts.ScriptTarget.Latest, true);
const predicateFunctions = new Set(['snapshotTableFqn', 'normalizeSnapshotRelationships',
  'normalizedRelationshipSignature', 'deduplicateRelationships']);
const predicateModule = new Module(sliceFile, module);
predicateModule._compile(ts.transpileModule(source.statements
  .filter(node => ts.isFunctionDeclaration(node) && predicateFunctions.has(node.name?.text))
  .map(node => node.getText(source)).join('\n') + '\nmodule.exports = {normalizeSnapshotRelationships,deduplicateRelationships};', {
    compilerOptions: {module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText, sliceFile);
const restoredPredicate = predicateModule.exports.normalizeSnapshotRelationships([{
  edge_id:'edge-preserved',left_relation_id:'D.S.A',right_relation_id:'D.S.B',join_type:'LEFT',conditions:[],
  additional_predicate:'a.ID = b.ID OR b.ID IS NULL',
}]);
assert.equal(restoredPredicate[0].sqlPredicate,'a.ID = b.ID OR b.ID IS NULL');
assert.equal(restoredPredicate[0].id,'edge-preserved');
assert.equal(predicateModule.exports.deduplicateRelationships([
  restoredPredicate[0],{...restoredPredicate[0],sqlPredicate:'a.ID = b.ID AND b.ID IS NOT NULL'},
]).length,2);
console.log('Snapshot reopen and deduplication retain full join predicates.');
const authoredFile = path.resolve(__dirname, '../src/features/sttm/mapping/authored-sql-key.ts');
const authoredModule = new Module(authoredFile,module);
authoredModule._compile(ts.transpileModule(fs.readFileSync(authoredFile,'utf8'), {
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
}).outputText,authoredFile);
const authoredState = {sources:[],derivedSources:[],relationships:restoredPredicate,mappings:[]};
const authoredKey = authoredModule.exports.computeAuthoredSqlSemanticKey(authoredState);
assert.notEqual(authoredKey, authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,
  relationships:[{...restoredPredicate[0],sqlPredicate:'a.ID = b.ID'}]}));
assert.notEqual(authoredKey, authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,
  sourceQueryModifiers:{limit:'LIMIT 2'}}));
console.log('Full predicates and query modifiers invalidate authored SQL currency.');
const placeholder = {id:'catalog-1',targetColumn:'UNUSED',targetType:'VARCHAR',sourceColumn:null,sourceType:null,
  expression:null,rule:'Select...',status:'UNMAPPED',nlRule:null,loadOrder:null,description:null,
  confidenceScore:null,confidenceReason:null,candidateSourceColumns:[],unmatchedReason:null,aiSuggestedRule:null,aiSuggestedRuleType:null};
assert.equal(authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,mappings:[placeholder]}),authoredKey,
  'untouched catalog placeholder must not invalidate uploaded SQL');
for(const change of [{expression:'a.ID'},{sourceColumn:'a.ID'},{sourceColumns:['a.ID']},{constantValue:''},
  {mappingMode:'constant'},{mappingMode:'attribute',attributeName:'Firm'},{rule:'Custom'},{nlRule:'Use ID'},
  {status:'MAPPED'},{manuallySaved:true},{description:'intent'},{sourceDependencies:['D.S.A']},
  {unmatchedReason:'review required'},{valueBindingIds:['value:one']}]) {
  assert.notEqual(authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,mappings:[{...placeholder,...change}]}),authoredKey,
    `meaningful unmapped intent must remain keyed: ${JSON.stringify(change)}`);
}
const mappedState={...authoredState,mappings:[{...placeholder,targetColumn:'ID',status:'MAPPED',sourceColumns:['a.ID'],rule:'Direct'}]};
const mappedKey=authoredModule.exports.computeAuthoredSqlSemanticKey(mappedState);
for(const change of [{targetColumn:'OTHER'},{targetType:'NUMBER'},{sourceColumns:['a.OTHER']},{expression:'TRIM(a.ID)'},
  {mappingMode:'attribute',attributeName:'Other'},{mappingMode:'constant',constantValue:'changed'}]) {
  assert.notEqual(authoredModule.exports.computeAuthoredSqlSemanticKey({...mappedState,mappings:[{...mappedState.mappings[0],...change}]}),mappedKey);
}
console.log('Only empty placeholders are excluded; real mapping, type, constant, attribute and transform changes invalidate.');
assert.equal(authoredModule.exports.authoredSqlIsCurrent('SELECT 1','ask1:1b3dc9ff:4o',authoredState),true);
assert.equal(authoredModule.exports.authoredSqlIsCurrent('SELECT 1','ask1:1b3dc9ff:4o',{...authoredState,mappings:[placeholder]}),true);
assert.equal(authoredModule.exports.authoredSqlIsCurrent('SELECT 1','ask1:1b3dc9ff:4o',mappedState),false);
assert.notEqual(authoredModule.exports.computeAuthoredSqlSemanticKey({...mappedState,targets:[{isSelected:true,qualifiedName:'D.T.ONE'}]}),
  authoredModule.exports.computeAuthoredSqlSemanticKey({...mappedState,targets:[{isSelected:true,qualifiedName:'D.T.TWO'}]}));
console.log('Existing ask1 keys remain readable without treating changed mappings as current.');
const providerFile = path.resolve(__dirname, '../src/features/sttm/context/sttm-builder-context.tsx');
const providerSource = ts.createSourceFile(providerFile,fs.readFileSync(providerFile,'utf8'),ts.ScriptTarget.Latest,true);
let hydrationCleanup;
function findHydrationCleanup(node) {
  if (ts.isReturnStatement(node) && node.expression && ts.isArrowFunction(node.expression)
    && node.expression.getText(providerSource).includes('window.clearTimeout(selectionMetadataTimerRef.current)')) {
    hydrationCleanup=node.expression.getText(providerSource);
  }
  ts.forEachChild(node,findHydrationCleanup);
}
findHydrationCleanup(providerSource);
assert.ok(hydrationCleanup);
const cleanupModule=new Module(providerFile,module);
cleanupModule._compile(ts.transpileModule(`module.exports=(selectionMetadataTimerRef,attributeHydrationSignatureRef,window)=>(${hydrationCleanup})();`,{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
}).outputText,providerFile);
const timerRef={current:42}, signatureRef={current:'unfetched-selection'};
cleanupModule.exports(timerRef,signatureRef,{clearTimeout:id=>assert.equal(id,42)});
assert.equal(timerRef.current,null);
assert.equal(signatureRef.current,null);
console.log('Cancelled column-catalog debounce can be retried on the next render.');
const cteFile=path.resolve(__dirname,'../src/features/sttm/source-target/add-derived-modal.tsx');
const cteSource=ts.createSourceFile(cteFile,fs.readFileSync(cteFile,'utf8'),ts.ScriptTarget.Latest,true);
let previewEffect, previewDependencies;
function findPreviewEffect(node) {
  if(ts.isCallExpression(node) && node.expression.getText(cteSource)==='useEffect'
    && node.arguments[0]?.getText(cteSource).includes('validatedSql.current === effectiveSqlExpression')) {
    previewEffect=node.arguments[0].getText(cteSource);
    previewDependencies=node.arguments[1].getText(cteSource);
  }
  ts.forEachChild(node,findPreviewEffect);
}
findPreviewEffect(cteSource);
assert.equal(previewDependencies,'[effectiveSqlExpression, isOpen]');
const previewModule=new Module(cteFile,module);
previewModule._compile(ts.transpileModule(`module.exports=({isOpen,effectiveSqlExpression,validatedSql,setPreviewColumnsState,setPreviewRowsState,setValidationState})=>(${previewEffect})();`,{
 compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
}).outputText,cteFile);
let changedMessages=0;
const effectInput={isOpen:true,effectiveSqlExpression:'SELECT 2',validatedSql:{current:null},
 setPreviewColumnsState:()=>{},setPreviewRowsState:()=>{},setValidationState:()=>changedMessages++};
previewModule.exports(effectInput);
assert.equal(changedMessages,0);
effectInput.validatedSql.current='SELECT 1';
previewModule.exports(effectInput);
assert.equal(changedMessages,1);
assert.equal(effectInput.validatedSql.current,null);
console.log('CTE Apply status is not overwritten by equivalent hydration state; real SQL changes invalidate preview.');
let rejectionReducer;
let fulfilledReducer;
function visit(node) {
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(source) === 'runAutoMap.rejected') {
    rejectionReducer = node.arguments[1].getText(source);
  }
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(source) === 'runAutoMap.fulfilled') {
    fulfilledReducer = node.arguments[1].getText(source);
  }
  ts.forEachChild(node, visit);
}
visit(source);
assert.ok(rejectionReducer);
const reducerModule = new Module(sliceFile, module);
reducerModule._compile(ts.transpileModule(`module.exports = ${rejectionReducer}`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, sliceFile);
const failedState = { mappingLoading: true, autoMapProcessingIds: ['pending'], autoMapStatusMessage: 'Working',
  mappings: [{ id: 'pending', status: 'PROCESSING' }, { id: 'done', status: 'MAPPED', confidenceScore: 0.9 }], errorState: {} };
reducerModule.exports(failedState, { payload: 'Context preparation failed' });
assert.equal(failedState.mappingLoading, false);
assert.deepEqual(failedState.autoMapProcessingIds, []);
assert.equal(failedState.mappings[0].status, 'UNMAPPED');
assert.equal(failedState.mappings[1].status, 'MAPPED');
assert.equal(failedState.errorState.autoMap, 'Context preparation failed');
console.log('Auto-map rejection state regression passed.');

const fulfilledModule = new Module(sliceFile, module);
fulfilledModule._compile(ts.transpileModule(`module.exports = ${fulfilledReducer}`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, sliceFile);
const completedState = { mappingLoading: true, autoMapProcessingIds: ['review'],
  mappings: [{ id: 'review', status: 'PROCESSING' }, { id: 'done', status: 'MAPPED' }] };
fulfilledModule.exports(completedState, { payload: null });
assert.equal(completedState.mappings[0].status, 'UNMAPPED');
assert.equal(completedState.mappings[1].status, 'MAPPED');
console.log('Completed Auto-map does not leave review rows processing.');

const functionNames = new Set(['isStructuredSqlExpression', 'applyMappingSuggestion']);
const functionSources = source.statements.filter(node => ts.isFunctionDeclaration(node) && functionNames.has(node.name?.text)).map(node => node.getText(source));
const suggestionModule = new Module(sliceFile, module);
suggestionModule._compile(ts.transpileModule(`${functionSources.join('\n')}\nmodule.exports = applyMappingSuggestion;`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, sliceFile);
const directRow = {};
suggestionModule.exports(directRow, { sourceAttributes: ['a.CITY'], confidenceScore: 0.9,
  preprocessingRuleType: 'Direct', preprocessingRule: 'Use source city directly.' });
assert.equal(directRow.expression, null);
assert.equal(directRow.rule, 'Direct');
const transformedRow = {};
suggestionModule.exports(transformedRow, { sourceAttributes: ['a.CITY'], confidenceScore: 0.9,
  preprocessingRuleType: 'Custom', preprocessingRule: 'TRIM(a.CITY)' });
assert.equal(transformedRow.expression, 'TRIM(a.CITY)');
console.log('Direct mapping prose is not executable SQL.');

// Execute the real compiler-request row projection: persisted AI IDs cannot
// override the binding identity owned by the current graph's mapping row.
const pageFile = path.resolve(__dirname, '../src/app/sttm/builder/new/mapping/page.tsx');
const pageSource = ts.createSourceFile(pageFile, fs.readFileSync(pageFile, 'utf8'), ts.ScriptTarget.Latest, true);
let statusPanelSource;
function findStatusPanel(node) {
  if (ts.isJsxAttribute(node) && node.name.getText(pageSource) === 'statusPanel') statusPanelSource = node.getText(pageSource);
  ts.forEachChild(node, findStatusPanel);
}
findStatusPanel(pageSource);
assert.ok(statusPanelSource.includes("cteDraft.status === 'complete' ? 'info' : 'warning'"));
assert.ok(statusPanelSource.includes("fontSize: '0.8rem'"));
assert.ok(statusPanelSource.includes('component="details"'));
assert.ok(statusPanelSource.includes('Review draft issues'));
assert.ok(!pageSource.text.includes('<AiaBox role="status" sx={{px: 2, py: 1'));
console.log('Draft notices use the shared compact status panel with expandable issues.');
let projectCompilerRow;
function visitCompilerRow(node) {
  if (ts.isCallExpression(node) && node.expression.getText(pageSource).startsWith('activeMappings.map')
      && node.arguments[0]?.getText(pageSource).includes('target_column: mapping.targetColumn')) {
    projectCompilerRow = node.arguments[0].getText(pageSource);
  }
  ts.forEachChild(node, visitCompilerRow);
}
visitCompilerRow(pageSource);
assert.ok(projectCompilerRow);
const rowModule = new Module(pageFile, module);
rowModule._compile(ts.transpileModule(`module.exports = ${projectCompilerRow}`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, pageFile);
for (const mode of ['attribute', 'constant']) {
  const row = rowModule.exports({ id: 'parent', mappingMode: mode, sourceColumns: [],
    sourceDependencies: [], valueBindingIds: ['project-attribute:stale-model-id'] });
  assert.deepEqual(row.value_binding_ids, ['value:parent']);
}
console.log('Compiler request uses current row-owned value bindings.');

// Review may obtain a temporary Analyst model, but cannot mutate the prepared
// semantics and thereby invalidate the just-compiled SET artifact.
let validateFunction;
function visitValidation(node) {
  if (ts.isVariableDeclaration(node) && node.name.getText(pageSource) === 'handleValidateSql') {
    validateFunction = node.initializer;
  }
  ts.forEachChild(node, visitValidation);
}
visitValidation(pageSource);
assert.ok(validateFunction);
const validationCalls = [];
function collectCalls(node) {
  if (ts.isCallExpression(node)) validationCalls.push(node.expression.getText(pageSource));
  ts.forEachChild(node, collectCalls);
}
collectCalls(validateFunction);
assert.ok(validationCalls.includes('dbService.refreshSemanticContext'));
assert.ok(!validationCalls.includes('applySemanticRefresh'));
console.log('SQL review preserves compiled artifact semantic currency.');

let restoredSourceColumn;
function visitRestoredColumn(node) {
  if (ts.isPropertyAssignment(node) && node.name.getText(source) === 'sourceColumn'
      && node.initializer.getText(source).includes('sourceColumns.join')) {
    restoredSourceColumn = node.initializer.getText(source);
  }
  ts.forEachChild(node, visitRestoredColumn);
}
visitRestoredColumn(source);
assert.ok(restoredSourceColumn);
const restoredModule = new Module(sliceFile, module);
restoredModule._compile(`module.exports = sourceColumns => (${restoredSourceColumn});`, sliceFile);
assert.equal(restoredModule.exports(['contacts.FIRST_NAME', 'contacts.LAST_NAME']),
  'contacts.FIRST_NAME, contacts.LAST_NAME');
assert.equal(restoredModule.exports([]), null);
console.log('Reopened multi-source mappings preserve their compiler input.');

const aliasFile = path.resolve(__dirname, '../src/features/sttm/mapping/relation-alias.ts');
const aliasModule = new Module(aliasFile, module);
aliasModule._compile(ts.transpileModule(fs.readFileSync(aliasFile, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, aliasFile);
const { relationAliasFor, buildRelationDisplayAliases, formatRelationDisplayText, splitSourceDisplayLabel } = aliasModule.exports;
const identity = 'agent_cte_0fa187a74c142419bb96';
const alias = relationAliasFor(identity, 'addresses_one_per_contacts');
const nodes = [{ identity, alias, displaySeed: 'addresses_one_per_contacts' }];
const labels = buildRelationDisplayAliases(nodes);
assert.equal(formatRelationDisplayText(`${alias}.CITY`, labels), 'addresses_one_per_contacts.CITY');
assert.equal(formatRelationDisplayText(`${identity}.CITY`, labels), 'addresses_one_per_contacts.CITY');
assert.equal(formatRelationDisplayText(`COALESCE(${alias}.CITY, '${alias}.CITY')`, labels),
  `COALESCE(addresses_one_per_contacts.CITY, '${alias}.CITY')`);
assert.equal(formatRelationDisplayText(`-- ${alias}.CITY\n${alias}.CITY`, labels),
  `-- ${alias}.CITY\naddresses_one_per_contacts.CITY`);
assert.equal(nodes[0].alias, alias);
assert.equal(formatRelationDisplayText(`Prepared source ${alias}.`, labels), 'Prepared source addresses_one_per_contacts.');
assert.deepEqual(splitSourceDisplayLabel(formatRelationDisplayText(`${alias}.CITY`, labels)),
  { column: 'CITY', relation: 'addresses_one_per_contacts' });
assert.deepEqual(splitSourceDisplayLabel('DB.SRC.ADDRESSES.CITY'), { column: 'CITY', relation: 'DB.SRC.ADDRESSES' });
assert.deepEqual(splitSourceDisplayLabel('Value'), { column: 'Value', relation: '' });
const duplicateLabels = buildRelationDisplayAliases([...nodes, { identity: 'another',
  alias: relationAliasFor('another', 'addresses_one_per_contacts'), displaySeed: 'addresses_one_per_contacts' }]);
assert.equal(duplicateLabels.get(alias.toUpperCase()), 'addresses_one_per_contacts_1');
assert.equal(duplicateLabels.get(relationAliasFor('another', 'addresses_one_per_contacts').toUpperCase()),
  'addresses_one_per_contacts_2');
assert.equal(buildRelationDisplayAliases([{ ...nodes[0], alias: 'custom_alias_123456' }]).size, 0);
const previewValue = pageSource.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'stringifyPreviewValue');
const valueModule = new Module(pageFile, module);
valueModule._compile(ts.transpileModule(`${previewValue.getText(pageSource)}\nmodule.exports=stringifyPreviewValue;`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, pageFile);
assert.equal(valueModule.exports(null), 'NULL');
assert.equal(valueModule.exports(undefined), 'Not sampled');
assert.equal(valueModule.exports(''), '(empty)');
assert.equal(valueModule.exports(0), '0');
assert.equal(valueModule.exports(false), 'false');
console.log('Preview aliases are display-only; missing, null and empty values remain distinct.');

let automaticCompileEffect;
function visitAutomaticCompile(node) {
  if (ts.isCallExpression(node) && node.expression.getText(pageSource) === 'useEffect'
      && node.arguments[0]?.getText(pageSource).includes('lastAutomaticCompileHash.current')) {
    automaticCompileEffect = node.arguments[0].getText(pageSource);
  }
  ts.forEachChild(node, visitAutomaticCompile);
}
visitAutomaticCompile(pageSource);
assert.ok(automaticCompileEffect);
const autoCompileModule = new Module(pageFile, module);
autoCompileModule._compile(ts.transpileModule(`module.exports = (state) => {
  const { autoCompile, mappingLoading, currentSqlArtifact, isCompilingSql, savedWorkspaceHydrating,
    isLoadingProjectAttributes, pendingManualEditSnapshots,
    reviewLoading, mappedCount, lastAutomaticCompileHash, compilerContextHash, compileCurrentMappingSql, window } = state;
  return (${automaticCompileEffect})();
};`, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText, pageFile);
let pendingCompile;
let automaticCalls = 0;
const autoState = { autoCompile: true, mappingLoading: true, savedWorkspaceHydrating:false, isLoadingProjectAttributes:false,
  pendingManualEditSnapshots:{},
  currentSqlArtifact: { source: 'generated' }, activeTab: 'mapping', isCompilingSql: false,
  reviewLoading: false, mappedCount: 2, lastAutomaticCompileHash: { current: null }, compilerContextHash: 'first',
  compileCurrentMappingSql: () => { automaticCalls += 1; },
  window: { setTimeout: callback => { pendingCompile = callback; return 1; }, clearTimeout: () => { pendingCompile = null; } } };
autoCompileModule.exports(autoState);
assert.equal(pendingCompile, undefined);
autoState.mappingLoading = false;
const cleanup = autoCompileModule.exports(autoState);
cleanup();
assert.equal(pendingCompile, null);
autoState.compilerContextHash = 'settled';
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 1);
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.compilerContextHash = 'new-firm-values';
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 2);
autoState.currentSqlArtifact.source = 'compiled';
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.currentSqlArtifact.source = 'generated';
autoState.compilerContextHash = 'reopened-draft';
autoState.activeTab = 'sql-preview';
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 3);
autoState.compilerContextHash='manual-edit';
autoState.activeTab='mapping';
autoState.pendingManualEditSnapshots={row:{status:'MAPPED'}};
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.pendingManualEditSnapshots={};
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 4);
autoState.compilerContextHash='hydrating';
autoState.savedWorkspaceHydrating=true;
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.savedWorkspaceHydrating=false;
autoState.isLoadingProjectAttributes=true;
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.isLoadingProjectAttributes=false;
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 5);
autoState.autoCompile = false;
autoState.compilerContextHash = 'off-edits';
assert.equal(autoCompileModule.exports(autoState), undefined);
assert.equal(automaticCalls, 5);
autoState.autoCompile = true;
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 6);
console.log('Auto-compile OFF never sends a request; ON compiles the latest edits once.');
console.log('Automatic compile synchronizes saved manual edits and settled Auto-map inputs, avoids loops, and waits for hydration/firm Values.');