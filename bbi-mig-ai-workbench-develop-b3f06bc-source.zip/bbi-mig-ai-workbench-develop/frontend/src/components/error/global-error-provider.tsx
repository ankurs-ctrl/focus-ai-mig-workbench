'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import type { AppErrorPayload } from '@/api/errors/app-error';
import {
  dismissGlobalError,
  registerGlobalErrorListener,
} from '@/api/errors/error-bus';
import { GlobalErrorDialog } from './global-error-dialog';

export function GlobalErrorProvider({ children }: { children: ReactNode }) {
  const [currentError, setCurrentError] = useState<AppErrorPayload | null>(null);
  const [portalReady, setPortalReady] = useState(false);

  useEffect(() => {
    return registerGlobalErrorListener(setCurrentError);
  }, []);

  useEffect(() => {
    setPortalReady(true);
  }, []);

  const dialog = (
    <GlobalErrorDialog
      open={Boolean(currentError)}
      payload={currentError}
      onClose={dismissGlobalError}
    />
  );

  return (
    <>
      {children}
      {/* Portal to document.body so stacking is never trapped by parent stacking contexts. */}
      {portalReady ? createPortal(dialog, document.body) : null}
    </>
  );
}
