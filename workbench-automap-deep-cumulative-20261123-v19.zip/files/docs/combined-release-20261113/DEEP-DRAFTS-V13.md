# Cumulative Deep Agent and Auto-map changes — V13

This is the newest release note; it supersedes V11/V12 notes where they differ. The overlay preserves earlier Auto-map, confidence, citation, semantic-gap, SQL-upload, metadata-only publication, administration, OAuth, PR #63 and Deep Agent files. It is reconstructed against both supplied (2).zip and (3).zip baselines. Environment files and credentials are excluded.

## Changes

Real business questions require two or three researched, distinct implementable choices with evidence, explanations and one recommendation. The UI appends Other last; typed alternatives return to agent research and plan validation rather than becoming unchecked SQL or bindings. Technical findings are readable findings, never empty answer forms. Supported drafts do not pause for low-confidence confirmation. Missing business dependencies remain explicit.

Restore recent chats and the saved plan directly, scoped to the conversation and current turn. Read the latest plan event with a bounded filtered query, including histories beyond 500 activities. Show the existing Implement plan and Update plan controls for a valid current approval. Preserve project identity while using the same chat presentation, Quick/Deep selector, full-width transcript scroll and Jump to latest.

Discovery uses bounded caller-visible database/schema scopes and exact contracts. Reuse verified retained research on continuation. Correct quoted identifiers, CTE boundaries and normal assistant-created CTE public-name bindings in the mapping UI. Deep uses its registered Search/Analyst/Workbench tools and the source/transformation specialists; it does not nest AGT_STTM_BUILDER as a second orchestrator.

Send custom expressions, including approved-plan CASE intent mislabeled direct by the source model, to the transformation specialist. Supply current bindings, Values and target-specific historical evidence without copying redundant full semantic YAML or compiler ASTs. Pack specialist groups with existing bounded parallelism; preserve completed siblings and explicit unfinished outcomes. Model confidence is retained separately from estimated confidence.

Bound idle planning, restrict focused plan submissions to the validation tool, and handle provider responses without IDs. Progress comes from executor receipts without additional narration model calls. Keep population annotations separate from target table selections. Plan edits now use structured revision feedback; legacy text checkpoints normalize safely. This last fix was tested through the real local graph, but its native retry remains pending.

## Installation

1. Extract files/ over the repository root. Preserve client.env and all current secrets. Read MANIFEST.json and verify the adjacent ZIP SHA256. No removals are requested.
2. Run the normal metadata bootstrap in your configured namespace. It now includes and validates the existing 20260929_deep_run_knowledge.sql migration; the earlier project-bootstrap lock remains covered. There is no new V13 table or reset of existing metadata.
3. Build and deploy matching frontend, API and Deep-worker images. Deep supervisor instructions/tool schemas ship in the worker image. Retain earlier source/transformation agent-spec installation steps; V13 adds no Snowflake agent-spec migration.
4. The existing setting MIGRATION_AGENT_MODEL_TIMEOUT_SECONDS now defaults to 180 seconds for Deep. If client.env explicitly sets it to 90, change that existing entry to MIGRATION_AGENT_MODEL_TIMEOUT_SECONDS=180. No additional OAuth login/token or new environment variable is required. Auto-map context limits, shared allowances and ownership-only dispatch remain unchanged.
5. Keep service housekeeping authentication separate from delegated initiating-user execution, using the existing session store/secrets infrastructure. Restart workers at a safe boundary; do not blindly replay uncertain calls. Failed client incident jobs are not modified by this overlay.
6. Local launch remains ./start-ai-workbench.sh on localhost:3000 and localhost:8000. The standard Deep-worker launcher is scripts/start_deep_worker_local.sh. Local diagnostic wrappers are excluded.

## Evidence and remaining gates

See DEEP-DRAFTS-V13-RESULTS.json. The actual isolated Loan Income draft has 33 definitions with numeric confidence, compiler success and three Snowflake preview rows. MNI values are 5730.77, 4215.40 and 7586.05. A separate native transformation test validated three Value/CASE/column-plus-Value expressions with model confidence 0.95/0.92/0.92. No source/target data DML or publishing was performed.

A business-name-only test (with database hint) found the four actual objects and reached a real enabled Implement plan action. It took approximately 20 minutes on the older worker. That is a failed performance gate. The latest loop reductions are covered by regressions, not a fresh native timing pass. The Update plan native test exposed the corrected revision-shape error. Automatic approval review then failed because its quota was exhausted, blocking worker reload and native retest. The latest code must be reloaded before judging this retry; the failed test plan is retained, not silently marked successful.

The original draft's CALCULATION_TYPE followed an incorrect direct selection despite plan CASE intent. The latest specialist routing corrects this boundary in regression tests; native verification remains pending. Do not treat compiler success as full workbook business validation. Exact FIR search returned no cards for this fixture; historical draft precedents were useful but are not claimed published FIR.

Frontend: 562 tests passed and current/reconstructed-baseline-3 TypeScript checks passed. The complete backend run had 4824 passed, 31 skipped and one outdated confidence-confirmation expectation. That expectation was corrected to the requested draft behavior; the final affected suite passed 133 tests and the real graph question/edit suite passed 11. Final native planning/revision and final-image SPCS concurrency acceptance remain open. No under-200-second guarantee, CodeCommit push or SPCS deployment is claimed.

## Local review

Draft: http://localhost:3000/sttm/builder/7601/mapping
Completed chat: http://localhost:3000/ai-agent?conversation=conv_121e3f6e123b4226fddbc37bfc472f2c&artifact=plan
Business-name test chat: http://localhost:3000/ai-agent?conversation=conv_1ffea813492fb92b2655b8bfb9c53449&artifact=plan

The last chat currently retains the failed revision attempt. Its earlier approved-for-implementation plan is historical; do not present that as a successful revised plan.
