# R11 client AVD deployment

This is a cumulative overlay from the R7 baseline. It contains R8, R9, R10,
and R11, so it can be extracted over a client workspace currently on any of
those versions.

R11 adds:

- project-scoped Hardcoded/Project Values integrated with mapping persistence;
- Auto-map and transformation-agent contracts for governed `PROJECT_VALUE`
  bindings without exposing resolved client values to learned patterns;
- Snowflake-validated **Fix with AI** for SQL syntax errors, with review before
  applying the corrected SQL;
- durable, pollable DBT-conversion and test-case jobs so browser/SPCS request
  timeouts do not discard completed agent output;
- content-aware autosave deduplication;
- robust fast-model JSON extraction for SQL-upload explanations;
- a SQL-upload **Hardcoded Values** review tab with typed SET-variable parsing,
  project-value creation, environment-identifier separation, and FIR HITL approval metadata;
- clearer Project Values loading and retry errors.

## Deploy

1. Stop the current client services and back up the client workspace.
2. Extract the ZIP at the repository root. Keep the existing
   `infra/snowflake/env/client.env`.
3. Run the metadata bootstrap. It is idempotent and creates both the R10
   `TBL_PROJECT_ATTRIBUTES` table and the R11 `TBL_AGENT_ARTIFACT_JOBS` table.

   ```powershell
   .\scripts\bootstrap_sttm_metadata_infra.ps1 -EnvFile ".\infra\snowflake\env\client.env"
   ```

4. If the application runtime role is separate from the bootstrap role, apply
   the two grants in `CLIENT_ENV_DELTA.md` as the client administrator.
5. Rebuild and deploy both SPCS services. Do not use `-SkipBuild`; R11 changes
   the frontend image, Python backend, and agent specifications.

   ```powershell
   .\scripts\deploy_spcs_client_snow_safe.ps1 -EnvFile ".\infra\snowflake\env\client.env"
   ```

6. Wait for both services to become healthy, then hard-refresh the browser.

Snowflake FIR streams/tasks do not need to be suspended or resumed for these
interactive features. Existing FIR task state is preserved by the bootstrap.

## Smoke test

1. Open a project’s **Hardcoded Values**, create a value, and confirm it reloads.
2. Run Auto-map and confirm a value recommendation appears as **Project Value**
   with its attribute name, rather than as a source column.
3. Introduce a harmless SQL syntax issue, select **Validate SQL**, then use
   **Fix with AI** and review the original/candidate diff.
4. Start DBT Conversion and Test Cases. Confirm the UI shows background status
   and later receives either the final artifact or the agent’s precise error.
5. Upload a reference SQL and confirm the fast explanation appears; FIR learning
   remains the separate asynchronous workflow. Open **Hardcoded Values** and
   confirm mapping variables are selectable while database/schema/table variables
   are marked as environment-only evidence.
