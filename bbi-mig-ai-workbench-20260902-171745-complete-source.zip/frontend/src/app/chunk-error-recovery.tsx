"use client";

import { useEffect } from "react";

const CHUNK_RELOAD_KEY = "app-chunk-reload-attempt";

function isChunkLoadFailure(message: string) {
  return (
    message.includes("ChunkLoadError")
    || message.includes("Loading chunk")
    || message.includes("Failed to fetch dynamically imported module")
  );
}

export function ChunkErrorRecovery() {
  useEffect(() => {
    sessionStorage.removeItem(CHUNK_RELOAD_KEY);

    const attemptReload = (message: string) => {
      if (!isChunkLoadFailure(message)) {
        return;
      }

      const attempts = Number(sessionStorage.getItem(CHUNK_RELOAD_KEY) || "0");
      if (attempts >= 2) {
        return;
      }

      sessionStorage.setItem(CHUNK_RELOAD_KEY, String(attempts + 1));
      window.location.reload();
    };

    const onError = (event: ErrorEvent) => {
      attemptReload(event.message || String(event.error ?? ""));
    };

    const onUnhandledRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      const message =
        reason instanceof Error
          ? reason.message
          : typeof reason === "string"
            ? reason
            : "";
      attemptReload(message);
    };

    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);

    return () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
    };
  }, []);

  return null;
}
