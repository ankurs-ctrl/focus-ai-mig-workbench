"""Evidence requirements for business-choice questions, separate from approval/authentication."""
from __future__ import annotations
from typing import Any


def question_issues(decision: dict[str, Any], confidence: float = .75, margin: float = .15) -> list[str]:
    uncertain = float(decision.get('confidence') or 0) < confidence or float(decision.get('score_margin') or 0) < margin
    if not uncertain or not (decision.get('alternatives') or decision.get('allow_free_text') or decision.get('question')):
        return []
    options = [{'value': decision.get('selected_value'), 'label': decision.get('selected_label'),
                'description': decision.get('selected_description') or decision.get('rationale'),
                'evidence_ids': decision.get('evidence_ids'), 'recommended': decision.get('recommended')},
               *list(decision.get('alternatives') or [])]
    issues = []
    if not 2 <= len(options) <= 3:
        issues.append('Research two or three concrete alternatives before asking a business-choice question; record missing inputs as dependencies.')
    seen = set()
    for option in options:
        value = str(option.get('value') or option.get('selected_value') or '').strip()
        if not value or value in seen or value == '__provide_current__':
            issues.append('Options must have distinct, concrete selections; requesting an unspecified typed value is not an alternative.')
        seen.add(value)
        if not str(option.get('label') or '').strip() or not str(option.get('description') or '').strip():
            issues.append('Each option needs a readable label and an explanation of its effect.')
        if not option.get('evidence_ids'):
            issues.append('Each option needs evidence references explaining why it is applicable.')
    if sum(option.get('recommended') is True for option in options) != 1:
        issues.append('Mark exactly one evidence-backed option recommended and explain the remaining uncertainty.')
    return list(dict.fromkeys(issues))
