const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const filename = path.resolve(__dirname, '../src/services/workbenchService.ts');
const ast = ts.createSourceFile(filename, fs.readFileSync(filename, 'utf8'), ts.ScriptTarget.Latest, true);
let callback;
function visit(node) {
  if (ts.isPropertyAssignment(node) && node.name.getText(ast) === 'startAutoMapJob') callback = node.initializer.getText(ast);
  ts.forEachChild(node, visit);
}
visit(ast);
function load(context) {
  const moduleUnderTest = new Module(filename, module);
  moduleUnderTest._compile(ts.transpileModule(`module.exports = context => {const {${Object.keys(context)}} = context; return (${callback});};`, {
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText, filename);
  return moduleUnderTest.exports(context);
}
(async () => {
  let posts = 0, reads = 0;
  const context = {
    API_ROUTES:{workbench:{autoMapJobs:'/jobs'}},
    toEnvelope:()=>({request_id:'exact-request'}),
    postEnvelopeData:async()=>{posts++;throw new Error('timed out');},
    getApiData:async(url, config)=>{
      assert.equal(url, '/jobs/by-request/exact-request');
      assert.equal(config.skipGlobalError,true);
      if (++reads === 1) throw Object.assign(new Error('not accepted'),{payload:{statusCode:404}});
      return {job_id:'late-job'};
    },
    setTimeout:resolve=>resolve(),
  };
  assert.equal((await load(context)({})).job_id,'late-job');
  assert.equal(posts,1);
  assert.equal(reads,2);
  context.getApiData = async()=>{throw Object.assign(new Error('forbidden'),{payload:{statusCode:403}});};
  await assert.rejects(load(context)({}), /forbidden/);
  context.postEnvelopeData = async()=>{throw new Error('invalid mapping');};
  await assert.rejects(load(context)({}), /invalid mapping/);
  const recommendationPath = path.resolve(__dirname,'../src/services/recommendationService.ts');
  const recommendationAst = ts.createSourceFile(recommendationPath,fs.readFileSync(recommendationPath,'utf8'),ts.ScriptTarget.Latest,true);
  const methods = {};
  function inspect(node) {
    if (ts.isPropertyAssignment(node)) methods[node.name.getText(recommendationAst)] = node.initializer.getText(recommendationAst);
    ts.forEachChild(node,inspect);
  }
  inspect(recommendationAst);
  assert.match(methods.listApplicable,/skipGlobalError: true/);
  for (const action of ['preview','apply','undo']) assert.doesNotMatch(methods[action],/skipGlobalError/);
  const projectPath = path.resolve(__dirname, '../src/services/projectService.ts');
  const projectAst = ts.createSourceFile(projectPath, fs.readFileSync(projectPath, 'utf8'), ts.ScriptTarget.Latest, true);
  const names = ['listProjectAttributes', 'invalidateProjectAttributeRequests'];
  const source = projectAst.statements.filter(node => ts.isFunctionDeclaration(node)
    && names.includes(node.name?.text)).map(node => node.getText(projectAst)).join('\n');
  const projectModule = new Module(projectPath, module);
  projectModule._compile(ts.transpileModule(`module.exports = context => {
    const {getApiData, getAuthenticatedReadScope} = context;
    const window = {};
    const API_ROUTES = {projects:{attributes:id=>id}};
    const normalizeProjectAttributeRecords = value => value;
    const projectAttributeCache = new Map();
    const projectAttributeRequests = new Map();
    let projectAttributeRevision = 0;
    ${source.replace(/export /g, '')}
    return {listProjectAttributes, invalidateProjectAttributeRequests};
  };`, {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText, projectPath);
  let scope = 'alice:reader', requests = [];
  const projects = projectModule.exports({getAuthenticatedReadScope:()=>scope,
    getApiData: id => new Promise((resolve,reject)=>requests.push({id,resolve,reject}))});
  const one = projects.listProjectAttributes('P');
  const two = projects.listProjectAttributes('P');
  assert.equal(requests.length,1);
  requests[0].resolve([{attribute_name:'VALUE'}]);
  const [first,second] = await Promise.all([one,two]);
  first[0].attribute_name = 'modified';
  assert.equal(second[0].attribute_name,'VALUE');
  const cached = await projects.listProjectAttributes('P');
  assert.equal(cached[0].attribute_name,'VALUE'); assert.equal(requests.length,1);
  projects.invalidateProjectAttributeRequests();
  const old = projects.listProjectAttributes('P');
  scope = 'bob:reader';
  const newer = projects.listProjectAttributes('P');
  requests[1].resolve([]); requests[2].resolve([]);
  await assert.rejects(old,/session changed/); await newer;
  projects.invalidateProjectAttributeRequests();
  const stale = projects.listProjectAttributes('P');
  projects.invalidateProjectAttributeRequests();
  const fresh = projects.listProjectAttributes('P');
  requests[3].resolve([]); requests[4].resolve([]);
  await assert.rejects(stale,/changed during retrieval/); await fresh;
  const failed = projects.listProjectAttributes('Q');
  requests[5].reject(new Error('offline'));
  await assert.rejects(failed,/offline/);
  const retry = projects.listProjectAttributes('Q');
  requests[6].resolve([]); await retry;
  console.log('Project values coalesce in flight, isolate callers, reject stale revisions, and retry failures without cached empties.');
  console.log('Lost acceptance recovers exact request without duplicate POST; permission failures stay visible; only optional recommendations are silent.');
})().catch(error=>{console.error(error);process.exitCode=1;});
