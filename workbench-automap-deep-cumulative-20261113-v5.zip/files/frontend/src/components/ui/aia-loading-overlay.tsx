"use client";

import { Modal } from "@mui/material";
import { AiaCircularProgress } from "./aia-feedback";
import { AiaBox, AiaPaper } from "./aia-layout";
import { AiaText } from "./aia-text";

type AiaLoadingOverlayProps = {
  open: boolean;
  label: string;
  /**
   * Cover the whole app (navigation, header, side panels) and block clicks,
   * keyboard focus and Escape until `open` turns false. Use while a request
   * must finish before the user may go anywhere else.
   */
  blocking?: boolean;
  /** Stacking order for `blocking`; raise it above panels that sit over dialogs. */
  zIndex?: number;
};

function LoadingCard({ label }: { label: string }) {
  return (
    <AiaPaper
      elevation={3}
      sx={{
        px: 3.5,
        py: 3,
        minWidth: 220,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 1.75,
        borderRadius: 2,
        outline: "none",
      }}
    >
      <AiaCircularProgress size={30} />
      <AiaText sx={{ fontSize: 14, fontWeight: 600, color: "#374151" }}>
        {label}
      </AiaText>
    </AiaPaper>
  );
}

export function AiaLoadingOverlay({ open, label, blocking = false, zIndex }: AiaLoadingOverlayProps) {
  if (blocking) {
    return (
      // No onClose: Escape and backdrop clicks cannot dismiss it.
      <Modal
        open={open}
        sx={{ zIndex }}
        slotProps={{
          backdrop: { sx: { bgcolor: "rgba(15, 23, 42, 0.35)", backdropFilter: "blur(1px)" } },
        }}
      >
        <AiaBox
          role="status"
          aria-live="polite"
          aria-label={label}
          tabIndex={-1}
          sx={{
            position: "fixed",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            outline: "none",
          }}
        >
          <LoadingCard label={label} />
        </AiaBox>
      </Modal>
    );
  }

  if (!open) return null;

  return (
    <AiaBox
      role="status"
      aria-live="polite"
      aria-label={label}
      sx={{
        position: "absolute",
        inset: 0,
        zIndex: 20,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        bgcolor: "rgba(247, 248, 250, 0.78)",
        backdropFilter: "blur(1px)",
      }}
    >
      <LoadingCard label={label} />
    </AiaBox>
  );
}
