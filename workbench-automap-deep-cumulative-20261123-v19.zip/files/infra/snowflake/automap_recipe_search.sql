-- Additive, per-column recipe discovery. No grants or replacement of shared services.
-- Canonical PATTERN_PAYLOAD remains in TBL_FIR_TARGET_MAPPING_PATTERNS and is
-- re-read through the caller's session before any search hit enters context.
CREATE CORTEX SEARCH SERVICE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.CSS_AUTOMAP_RECIPES_V1
    ON SEARCH_TEXT
    PRIMARY KEY (PATTERN_ID)
    ATTRIBUTES TARGET_TABLE, TARGET_COLUMN, SCOPE, PROJECT_ID, STTM_ID, SOURCE_SYSTEM_KEY, PUBLISHED_AT
    WAREHOUSE = __WAREHOUSE_NAME__
    TARGET_LAG = '5 minutes'
AS SELECT
    PATTERN_ID,
    UPPER(TARGET_TABLE) AS TARGET_TABLE,
    UPPER(TARGET_COLUMN) AS TARGET_COLUMN,
    LOWER(SCOPE) AS SCOPE,
    COALESCE(PROJECT_ID, '') AS PROJECT_ID,
    COALESCE(STTM_ID, '') AS STTM_ID,
    UPPER(COALESCE(PATTERN_PAYLOAD:source_system_profile:vendor_family::STRING, '')) AS SOURCE_SYSTEM_KEY,
    TRY_TO_TIMESTAMP_NTZ(PATTERN_PAYLOAD:provenance:published_at::STRING) AS PUBLISHED_AT,
    CONCAT(
        TARGET_TABLE, '.', TARGET_COLUMN,
        '\nBusiness rule: ', COALESCE(PATTERN_PAYLOAD:business_rationale::STRING, ''),
        '\nSource system: ', COALESCE(PATTERN_PAYLOAD:source_system_profile:vendor_family::STRING, ''),
        '\nRecipe: ', COALESCE(PATTERN_PAYLOAD:mapping_recipe::STRING, ''),
        '\nApplies when: ', COALESCE(PATTERN_PAYLOAD:applicability_conditions::STRING, ''),
        '\nExclusions: ', COALESCE(PATTERN_PAYLOAD:exclusions::STRING, '')
    ) AS SEARCH_TEXT
FROM __STTM_METADATA_NAMESPACE__.TBL_FIR_TARGET_MAPPING_PATTERNS
WHERE STATUS = 'active'
  AND VALIDATION_STATUS IN ('accepted', 'validated', 'published')
  AND SUPERSEDED_BY IS NULL
  AND COALESCE(PATTERN_PAYLOAD:provenance:evidence_class::STRING, '')
      NOT IN ('unvalidated_authored_sql', 'unvalidated_authored_mapping_workbook')
  AND COALESCE(CONTRADICTION_COUNT, 0) = 0;