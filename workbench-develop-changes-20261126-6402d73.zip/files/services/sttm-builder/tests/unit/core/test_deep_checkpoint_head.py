from app.agent_runs.checkpoint import SnowflakeStageCheckpointSaver


def test_cold_parent_reads_cannot_rewind_latest_checkpoint():
    saver=SnowflakeStageCheckpointSaver(object())
    rows={key:{'CHECKPOINT_ID':key} for key in ['001','002','003']}
    reads=[]
    def fetch(thread, namespace, checkpoint_id=None, **kwargs):
        reads.append(checkpoint_id)
        return [rows[checkpoint_id or '003']]
    saver._rows=fetch
    saver._as_tuple=lambda row:row['CHECKPOINT_ID']
    config={'configurable':{'thread_id':'run:supervisor'}}
    assert saver.get_tuple(config)=='003'
    # LangGraph reconstructs delta channels by reading historical parents.
    assert saver.get_tuple({'configurable':{'thread_id':'run:supervisor','checkpoint_id':'002'}})=='002'
    assert saver.get_tuple({'configurable':{'thread_id':'run:supervisor','checkpoint_id':'001'}})=='001'
    assert saver.get_tuple(config)=='003'
    assert saver._latest_cache[('run:supervisor','')]=='003'
    assert reads==[None,'002','001']


def test_pending_plan_evidence_survives_restart_without_becoming_validated():
    from types import SimpleNamespace
    from app.agent_tools.capability_registry import CapabilityRegistry
    saved={}
    knowledge=SimpleNamespace(put=lambda kind,key,value,**kwargs:saved.update({key:value}),get=lambda kind,key:saved.get(key))
    def registry():
        item=object.__new__(CapabilityRegistry)
        item._knowledge=knowledge;item._active_run_id='run'
        item._validated_supervisor_plan=None;item._prepared_plan_candidate=None
        item._pending_supervisor_plan=None
        item._prepared_plan_candidates={};item._prepared_plan_review=None
        return item
    before=registry()
    before._prepared_plan_candidate={'source_preparation':{'driving_source':'DB.S.T'}}
    before._pending_supervisor_plan={'source_preparation':{'driving_source':'DB.S.T'},'auto_map':{'mapping_evidence':[{'target_column':'TYPE','transformation':"'Automatic'"}]}}
    before._prepared_plan_review={'unresolved':['missing approved Value'],'plan_candidate':before._prepared_plan_candidate}
    before._persist_plan_state()
    after=registry();after._restore_plan_state('run')
    assert after._prepared_plan_candidate==before._prepared_plan_candidate
    assert after._prepared_plan_review==before._prepared_plan_review
    assert after._pending_supervisor_plan==before._pending_supervisor_plan
    assert after._validated_supervisor_plan is None
    foreign=registry();foreign._restore_plan_state('another-run')
    assert foreign._prepared_plan_candidate is None


def test_prepared_plan_reference_materializes_full_definition_without_trusting_foreign_refs():
    import pytest
    from copy import deepcopy
    from app.agent_tools.capability_registry import CapabilityRegistry
    registry=object.__new__(CapabilityRegistry)
    registry._active_run_id='run'
    registry._prepared_plan_candidate={'normalized_intent':'Create draft',
        'source_preparation':{'driving_source':'DB.S.T','supporting_sources':['DB.S.NOTES'],
                              'unresolved_items':['missing business Value']},
        'auto_map':{'mapping_evidence':[{'target_column':'ID','source_columns':['DB.S.T.ID'],'mapping_mode':'direct'}]}}
    original=deepcopy(registry._prepared_plan_candidate)
    reference=registry._prepared_plan_reference()
    complete=registry._materialize_plan_submission({'prepared_plan_ref':reference,
        'source_preparation':{'relationships':[{'left':'DB.S.T.ID','right':'DB.S.NOTES.ID'}]},
        'project_decision':{'force_new':True,'project_name':'Isolated test'}})
    assert complete['auto_map']==original['auto_map']
    assert complete['source_preparation']['unresolved_items']==['missing business Value']
    assert complete['source_preparation']['supporting_sources']==['DB.S.NOTES']
    assert registry._prepared_plan_candidate==original
    short=registry._materialize_plan_submission({'prepared_plan_ref':reference,'changes':{
        'source_preparation':{'relationships':[]},'project_decision':{'force_new':True,'project_name':'Chosen'}}})
    assert short['source_preparation']['driving_source']=='DB.S.T'
    assert short['auto_map']==original['auto_map']
    with pytest.raises(ValueError,match='conflicting'):
        registry._materialize_plan_submission({'prepared_plan_ref':reference,'changes':{'project_decision':{}},'project_decision':{}})
    registry._active_run_id='another-run'
    with pytest.raises(ValueError,match='stale'):
        registry._materialize_plan_submission({'prepared_plan_ref':reference})
    assert registry._materialize_plan_submission({'normalized_intent':'legacy'})=={'normalized_intent':'legacy'}


def test_reference_survives_variant_numeric_roundtrip_and_completed_plan_retry():
    from copy import deepcopy
    from app.agent_tools.capability_registry import CapabilityRegistry
    registry=object.__new__(CapabilityRegistry);registry._active_run_id='run'
    registry._prepared_plan_candidate={'source_preparation':{'driving_source':'DB.S.T'},'auto_map':{'expected_coverage':1.0,'score':0.0}}
    reference=registry._prepared_plan_reference()
    base=deepcopy(registry._prepared_plan_candidate)
    registry._prepared_plan_candidate['auto_map']={'expected_coverage':1,'score':0}
    assert registry._prepared_plan_reference()==reference
    registry._prepared_plan_candidates={'DB.T.TARGET':base}
    registry._prepared_plan_candidate={'normalized_intent':'Completed plan','_deep_supervisor_validated':True}
    result=registry._materialize_plan_submission({'prepared_plan_ref':reference,'changes':{'normalized_intent':'Requested draft'}})
    assert result['auto_map']==base['auto_map']
    registry._prepared_plan_candidate=deepcopy(base)
    registry._prepared_plan_candidate['auto_map']['expected_coverage']='1'
    assert registry._prepared_plan_reference()!=reference


def test_verified_join_receipt_clears_only_stale_join_findings_without_plan_approval():
    from app.agent_tools.capability_registry import CapabilityRegistry
    registry=object.__new__(CapabilityRegistry)
    candidate={'source_preparation':{'driving_source':'DB.S.A','supporting_sources':['DB.S.B'],
        'relationships':[{'left_table':'DB.S.A','right_table':'DB.S.B',
                          'conditions':[{'left_column':'ID','right_column':'A_ID'}]}]}}
    registry._validated_supervisor_plan=None
    registry._prepared_plan_review={'unresolved':['Current relationship evidence has no join path to DB.S.B'],
                                    'plan_candidate':{'source_preparation':{}}}
    registry._refresh_verified_join_review(candidate)
    assert registry._prepared_plan_review is None
    assert registry._validated_supervisor_plan is None
    registry._prepared_plan_review={'unresolved':['Missing current business Value'], 'plan_candidate':{}}
    registry._refresh_verified_join_review(candidate)
    assert registry._prepared_plan_review['unresolved']==['Missing current business Value']
    assert registry._prepared_plan_review['plan_candidate']==candidate


def test_latest_plan_restore_is_not_limited_by_activity_page_or_foreign_turn():
    from app.agent_runs.models import AgentRunEvent
    from app.agent_runs.repository import InMemoryAgentRunRepository
    repository = InMemoryAgentRunRepository()
    def append(kind, turn, number):
        return repository.append_event(AgentRunEvent(event_id=f'e{number}', run_id='run',
            turn_id=turn, event_type=kind, status='succeeded', safe_summary='Activity'))
    old = append('plan.updated', 'current', 0)
    for index in range(1, 550):
        append('tool.completed', 'current', index)
    current = append('plan.updated', 'current', 550)
    append('plan.updated', 'foreign', 551)
    assert repository.latest_event_by_type('run', 'plan.updated', turn_id='current').event_id == current.event_id
    assert repository.latest_event_by_type('run', 'plan.updated', turn_id=None) is None
    assert repository.latest_event_by_type('another-run', 'plan.updated', turn_id='current') is None
    assert old.event_id != current.event_id


def test_latest_native_event_uses_turn_identity_from_existing_event_payload():
    from app.agent_runs.repository import SnowflakeAgentRunRepository
    calls=[]
    class Session:
        def sql(self,query,params):calls.append((query,params));return self
        def collect(self):return []
    repository=SnowflakeAgentRunRepository(Session(),database='D',schema='S')
    assert repository.latest_event_by_type('R','plan.updated',turn_id='T') is None
    query,params=calls[0]
    assert 'EVENT_DATA:turn_id' in query
    assert '(TURN_ID=' not in query
    assert params==['R','plan.updated','T']
