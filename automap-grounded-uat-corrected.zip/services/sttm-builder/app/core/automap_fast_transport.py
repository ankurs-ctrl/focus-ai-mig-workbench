"""Durable final-mapping calls; no scan protocol, model repair, or HTTP replay.

The existing transport validates provider completion, not the model's mapping
schema. A bounded terminal answer (even invalid mapping JSON) releases its permit
before archive I/O and consumer validation. Uncertain exchanges remain occupied.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import logging
from threading import Event, Lock

from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.automap_admission import request_digest
from app.core.automap_parallel import _snapshot
from app.core.automap_scan import ScanRequest
from app.core.automap_scan_transport import _diagnostic_reason, _request_body
from app.core.snowflake_agent import SnowflakeAgentClient


logger = logging.getLogger(__name__)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class FastModelRuntime:
    """One governed batch with a bounded sequence of distinct operations.

    Construct through build_fast_model_runtime. deadline is the existing absolute
    monotonic MODEL cutoff (the batch must subtract its validation reserve once).
    run uses 1-based call_index; a parse repair is a new operation, never a retry.

    Operator recovery uses reconcile_parallel_runtime(bundle, original_request=
    request_for(call_index), snapshot_archive_ref=..., permit=original_permit,
    retired_dispatcher=True, deadline=fresh_deadline). That generic thread proof
    requires the exact archived normalized prompt and structured v2 terminal state;
    neither mapping JSON nor scan markers constitute evidence. No automatic GET,
    release, or reconstruction of an owner capability is performed here.
    """

    def __init__(self, *, bundle, service, req, decision, store, deadline, specialist_backend=None):
        self.bundle = bundle
        self._service, self._decision = service, decision
        self._deadline = deadline
        self._operation = req.operation.value
        self._target_ids = tuple(sorted(store.targets))
        self._budget = bundle.limits.selection_budget
        from app.core.automap_fast_context import MAX_FAST_MODEL_CALLS
        self._max_calls = min(MAX_FAST_MODEL_CALLS, bundle.limits.max_calls)
        self._cancel = bundle.cancellation if bundle.cancellation is not None else Event()
        self._stop = Event()
        self._lock = Lock()
        self._requests = {}
        self._failure_diagnostics = None
        self._snapshot_text = self._archive_text({
            "protocol": "automap_exact_snapshot_v1", "state": _snapshot(vars(store)),
        }, bundle.scope.snapshot_id)
        self.snapshot_archive_ref = _hash(self._snapshot_text)
        self._snapshot_committed = False
        self._guarded = bundle.admission.wrap_backend(bundle.backend)
        self._specialist_backend = specialist_backend

    @property
    def next_call_index(self):
        return max(self._requests, default=0) + 1

    def check_active(self):
        import time
        from app.core.automap_scan import ScanStopped, ScanStatus
        if self._stop.is_set():
            raise ValueError("Fast runtime stopped; transport failures must not be retried")
        if self._cancel.is_set() or time.monotonic() >= self._deadline:
            raise ScanStopped(ScanStatus.CANCELED if self._cancel.is_set() else ScanStatus.TIMED_OUT)

    def _archive_text(self, value, generation):
        return _json({"scope": asdict(self.bundle.scope), "generation": generation, "value": value})

    def _save_text(self, text):
        reference = _hash(text)
        self.bundle.archive.put(reference, text)
        if self.bundle.archive.get(reference) != text:
            raise ValueError("Fast model archive was not durably acknowledged")
        return reference

    def request_for(self, call_index):
        """Original immutable request for explicit same-owner operator recovery."""
        return self._requests[call_index]

    @property
    def failure_diagnostics(self):
        """Safe last failed-call metadata, including whether its archive was ACKed."""
        return deepcopy(self._failure_diagnostics)

    def _metadata(self, request, call_index, request_ref, diagnostics):
        return {"call_index": call_index, "job_id": self.bundle.admission.job_id,
            "generation": request.generation, "shard_id": request.shard_id,
            "request_digest": request_digest(request), "snapshot_archive_ref": self.snapshot_archive_ref,
            "request_archive_ref": request_ref, "transport": [asdict(item) for item in diagnostics]}

    def _record_failure(self, error, request, call_index, request_ref, diagnostics):
        metadata = {**self._metadata(request, call_index, request_ref, diagnostics),
                    "failure_code": _diagnostic_reason(error).value}
        try:
            # Outside admission, on the ORIGINAL scoped archive and deadline.
            # Neither diagnostics nor an archive ACK authorize permit release.
            reference = self._save_text(self._archive_text({
                "protocol": "automap_fast_model_failure_v1", "request_archive_ref": request_ref,
                "fast_diagnostics": metadata,
            }, request.generation))
        except Exception:
            metadata["failure_archive_status"] = "unavailable"
            try:
                logger.warning("Auto-map fast failure diagnostics archive unavailable")
            except Exception:
                pass
        else:
            metadata.update(failure_archive_status="acknowledged", failure_archive_ref=reference)
        self._failure_diagnostics = metadata
        try:
            error.fast_diagnostics = deepcopy(metadata)
        except Exception:
            pass  # Adapter property remains available for exceptions without attributes.

    def run(self, messages, call_index, *, stage="source_mapping"):
        """Return (raw_model_text, None, {fast_diagnostics: ...}) after archive ACK.

        ThreadReference is in the occupied durable permit, not a public gate
        result. Never manufacture a thread ID from the legacy extractor's UUID
        fallback or parse one from model-authored text.
        """
        if not self._lock.acquire(blocking=False):
            raise ValueError("Fast runtime permits only one operation at a time per batch")
        try:
            self.check_active()
            if stage not in {"source_mapping", "transformation_rule"}:
                raise ValueError("Unsupported governed Auto-map model stage")
            backend = self.bundle.backend if stage == "source_mapping" else self._specialist_backend
            if backend is None:
                raise ValueError("Governed transformation specialist is unavailable")
            operation = self._operation if stage == "source_mapping" else "sttm.transform"
            if self._stop.is_set():
                raise ValueError("Fast runtime stopped; transport failures must not be retried")
            if (type(call_index) is not int or not 1 <= call_index <= self._max_calls
                    or call_index in self._requests):
                raise ValueError("Fast call_index must identify an unused operation within the call budget")
            self._service._model_guard.assert_model_target_allowed(
                operation=operation, target="agent", decision=self._decision)
            if type(messages) is not list or any(type(message) is not dict for message in messages):
                raise ValueError("Fast model requires normalized user messages")
            message = _json(SnowflakeAgentClient._normalize_messages(deepcopy(messages)))
            if len(message) > self._budget.max_chars or len(message.encode("utf-8")) > self._budget.max_bytes:
                raise AgentPayloadBudgetError("Complete normalized fast model messages exceed the budget")
            # The namespace includes the trusted factory job, not a request's job
            # or agent override. A second parse attempt gets a different identity.
            shard_id = _hash(_json([self.bundle.admission.job_id, operation, call_index]))
            request = ScanRequest(scope=self.bundle.scope, generation=self.bundle.scope.snapshot_id,
                shard_id=shard_id, target_ids=self._target_ids, record_ids=(),
                message=message, output_budget=self._budget, deadline=self._deadline,
                _cancel=self._cancel, _stop=self._stop)
            request.check_active()
            _request_body(request, new_thread=True)  # Reject history/tools before admission or archive I/O.
            self._requests[call_index] = request
            if not self._snapshot_committed:
                self._save_text(self._snapshot_text)
                self._snapshot_committed = True
            request.check_active()
            request_ref = self._save_text(self._archive_text({
                "protocol": "automap_fast_model_request_v1",
                "snapshot_archive_ref": self.snapshot_archive_ref,
                "job_id": self.bundle.admission.job_id, "call_index": call_index,
                "operation": operation, "agent_fqn": backend._config.agent,
                "request_digest": request_digest(request),
                "request": {"scope": asdict(request.scope), "generation": request.generation,
                    "shard_id": request.shard_id, "target_ids": list(request.target_ids),
                    "record_ids": [], "message": request.message,
                    "output_budget": asdict(request.output_budget), "deadline": request.deadline},
            }, request.generation))
            request.check_active()
            diagnostics = ()
            try:
                with self.bundle.admission(request) as admitted:
                    if admitted is not True:
                        raise ValueError("Fast model dispatch requires global admission")
                    try:
                        raw = (self._guarded if stage == "source_mapping" else
                               self.bundle.admission.wrap_backend(backend))(request)
                    finally:
                        # This API is intentionally unavailable after the gate exits.
                        diagnostics = self.bundle.admission.diagnostics_for(request)
            except BaseException as error:
                self._stop.set()
                self._record_failure(error, request, call_index, request_ref, diagnostics)
                raise
            # Do not put archive writes inside the gate or its diagnostic sink:
            # provider completion and model-schema correctness are separate.
            metadata = {**self._metadata(request, call_index, request_ref, diagnostics),
                "global_admission": True, "pool_capacity": 4, "model_post_attempts": 1}
            response_ref = self._save_text(self._archive_text({
                "protocol": "automap_fast_model_response_v1", "request_archive_ref": request_ref,
                "raw": raw, "fast_diagnostics": metadata,
            }, request.generation))
            request.check_active()
            return raw, None, {"fast_diagnostics": {**metadata, "response_archive_ref": response_ref}}
        except BaseException:
            # A new operation is allowed only after a returned, durably archived
            # terminal answer. HTTP failures, lost ACKs and archive errors stop.
            self._stop.set()
            raise
        finally:
            self._lock.release()
