const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),ts=require('typescript'),Module=require('module');
const modules=new Map();
function load(name){const file=path.resolve(__dirname,'../src',name);if(modules.has(file))return modules.get(file).exports;const m=new Module(file,module);modules.set(file,m);m.require=dep=>dep.startsWith('@/')?load(dep.slice(2)+'.ts'):require(dep);m._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);return m.exports;}
const joins=load('features/sttm/source-target/join-predicate.ts');
const ctx={leftSql:'source_a',rightSql:'source_b',leftAliases:['source_a'],rightAliases:['source_b'],leftColumns:['ID','ALT'],rightColumns:['ID','ALT']};
const terms=joins.parseJoinPredicate('(source_a.ID = source_b.ID OR source_a.ALT = source_b.ALT)',ctx);
assert.ok(terms);const sql=joins.formatJoinTerms(terms,ctx);assert.match(sql,/ OR /);assert.ok(joins.parseJoinPredicate(sql,ctx));
assert.equal(joins.joinOnPredicate([{sql:'A',connector:'OR'},{sql:'B',connector:'OR'}],' '),'A OR B');
const {buildWorkbenchContextSnapshot}=load('features/sttm/context/workbench-context.ts');
const sources=['D.S."Country"','D.S."country"'].map(qn=>({tableId:qn,qualifiedName:qn,tableName:qn,isSelected:true}));
const snapshot=buildWorkbenchContextSnapshot({action:'sttm.autosave',page:'mapping',surface:'merge-test',sourceTables:sources,drivingTableId:sources[0].tableId,
 relationships:[{id:'join',leftTableId:sources[0].tableId,rightTableId:sources[1].tableId,joinType:'LEFT',conditions:[{leftColumn:'ID',rightColumn:'ID',operator:'='},{leftColumn:'ALT',rightColumn:'ALT',operator:'=',connector:'OR'}]}],
 mappings:[{id:'constant',targetColumn:'Import Notes',targetSqlName:'"Import Notes"',targetType:'TEXT',mappingMode:'constant',constantValue:'',sourceColumns:[],status:'MAPPED',rule:'Direct'}]});
const restored=JSON.parse(JSON.stringify(snapshot));
assert.equal(restored.relation_graph.edges[0].conditions[1].connector,'OR');
assert.equal(restored.relationships[0].conditions[1].connector,'OR');
assert.equal(restored.mapping_rows[0].target_sql_name,'"Import Notes"');assert.equal(restored.mapping_rows[0].constant_value,'');
assert.notEqual(restored.source_tables[0].table,restored.source_tables[1].table);
const {getMappingCounts}=load('features/dashboard/mappingStats.ts');
assert.deepEqual(getMappingCounts([{status:'COMPLETE'},{status:'PUBLISHED'},{status:'DRAFT'}]),{total:3,published:2,inProgress:1});
console.log('Merged integration: grouped/OR joins, snapshot connectors, quoted bindings/targets, empty constants and team dashboard counts pass.');
