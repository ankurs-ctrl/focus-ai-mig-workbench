"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import { SummaryWorkspace } from "@/features/sttm/summary/summary-workspace";
import { AiaCircularProgress } from "@/components/ui";

export default function SummaryPage() {
  const router = useRouter();
  const { sources, targets, derivedSources, mappings, loadState, targetAttributeGroup, activeSttmId, sessionHydrated, openSttmStatus } =
    useSttmBuilderContext();
  const routeBase =
    process.env.NEXT_PUBLIC_DURABLE_STTM_ROUTE_V1 !== "false" && activeSttmId
      ? `/sttm/builder/${encodeURIComponent(activeSttmId)}`
      : "/sttm/builder/new";

  const hasSelectedInputs =
    sources.some((table) => table.isSelected) || derivedSources.some((source) => source.isSelected);
  const hasSelectedTarget = targets.some((table) => table.isSelected);
  const hasTargetColumns = (targetAttributeGroup?.columns?.filter((col) => col.name).length ?? 0) > 0;
  const hasSavedMappingRows = Boolean(activeSttmId && mappings.length);
  const hasReadyInputs = hasSelectedInputs || hasSavedMappingRows;
  const hasReadyTarget = hasSelectedTarget || hasSavedMappingRows;
  const savedWorkspaceHydrating = !sessionHydrated || openSttmStatus === "loading";

  useEffect(() => {
    if (savedWorkspaceHydrating) return;
    if (!hasReadyInputs || !hasReadyTarget) {
      router.replace(routeBase);
      return;
    }

    if (loadState.attributes === "loading" || loadState.attributes === "idle") {
      return;
    }

    if (mappings.length === 0 || (!activeSttmId && !hasTargetColumns)) {
      router.replace(`${routeBase}/mapping`);
    }
  }, [
    hasReadyInputs,
    hasReadyTarget,
    hasTargetColumns,
    loadState.attributes,
    mappings.length,
    activeSttmId,
    router,
    routeBase,
    savedWorkspaceHydrating,
  ]);

  // Mirrors the effect above: whenever it declines to settle on a destination,
  // show a loader instead of mounting a half-built workspace the user may be
  // redirected away from a moment later.
  const isResolvingAttributes = savedWorkspaceHydrating || (!activeSttmId && (loadState.attributes === "loading" || loadState.attributes === "idle"));
  const willRedirect =
    !hasReadyInputs ||
    !hasReadyTarget ||
    (!isResolvingAttributes && (mappings.length === 0 || (!activeSttmId && !hasTargetColumns)));

  if (isResolvingAttributes || willRedirect) {
    return (
      <div className="flex h-full min-h-0 w-full min-w-0 flex-1 items-center justify-center gap-2.5 bg-white">
        <AiaCircularProgress size={20} />
        <span className="text-sm text-slate-500">Preparing final mapping &amp; summary…</span>
      </div>
    );
  }

  return (
    <div className="flex h-full min-h-0 w-full min-w-0 flex-1 flex-col overflow-hidden bg-white">
      <SummaryWorkspace />
    </div>
  );
}
