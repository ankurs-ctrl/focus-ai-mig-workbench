const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const Module=require('node:module');
const file=path.resolve(__dirname,'../src/features/sttm/mapping/sql-upload-recovery.ts');
const mod=new Module(file,module);
mod._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);
const {isConfirmedUploadRejection,observeSqlUpload,uploadRecoveryKey,readSqlUploadHandle,sqlUploadFingerprint}=mod.exports;
global.crypto ||= require("node:crypto").webcrypto;
(async()=>{
 for(const status of [408,425,429,500,502,503,504]) assert.equal(isConfirmedUploadRejection(status),false);
 assert.ok(isConfirmedUploadRejection(503,{detail:{accepted:false,code:'sql_upload_dependency_unavailable'}}));
 assert.equal(isConfirmedUploadRejection(503,{detail:{accepted:null,code:'sql_upload_dependency_unavailable'}}),false);
 for(const status of [400,401,403,404,409,413,415,422]) assert.ok(isConfirmedUploadRejection(status));
 const original=global.fetch;
 const signal=new AbortController().signal;
 const delay=async()=>{};
 try {
  const firstHash=await sqlUploadFingerprint(new Blob(['SELECT 1']),[['project','501'],['target','D.S.T']]);
  assert.equal(firstHash,await sqlUploadFingerprint(new Blob(['SELECT 1']),[['target','D.S.T'],['project','501']]));
  assert.notEqual(
    await sqlUploadFingerprint(new Blob(['SELECT 1']),[['filename','first.sql']]),
    await sqlUploadFingerprint(new Blob(['SELECT 1']),[['filename','second.sql']]),
  );
  assert.notEqual(firstHash,await sqlUploadFingerprint(new Blob(['SELECT 2']),[['project','501'],['target','D.S.T']]));
  assert.notEqual(firstHash,await sqlUploadFingerprint(new Blob(['SELECT 1']),[['project','501'],['target','D.S.OTHER']]));
  assert.deepEqual(readSqlUploadHandle(JSON.stringify({requestId:'one',fingerprint:firstHash})),{requestId:'one',fingerprint:firstHash});
  assert.equal(readSqlUploadHandle(null),null);
  assert.notEqual(uploadRecoveryKey('501','a'),uploadRecoveryKey('502','a'));
  assert.notEqual(uploadRecoveryKey('501','a'),uploadRecoveryKey('501','b'));
  assert.notEqual(uploadRecoveryKey('501','a','alice-role1'),uploadRecoveryKey('501','a','alice-role2'));
  assert.notEqual(uploadRecoveryKey('501','a','alice-role1'),uploadRecoveryKey('501','a','bob-role1'));
  const calls=[]; let count=0;
  global.fetch=async(url,options)=>{
   calls.push({url,options});
   if (++count===1) throw new TypeError('network disconnected');
   if(count===2)return {ok:false,status:404};
   if(count===3)return {ok:true,json:async()=>({request_id:'saved',status:'running'})};
   return {ok:true,json:async()=>({request_id:'saved',status:'preview_ready',result:{asset_id:'asset'}})};
  };
  const result=await observeSqlUpload('', '501','saved',signal,{attempts:5,delay});
  assert.equal(result.result.asset_id,'asset');
  assert.equal(calls.length,4);
  assert.ok(calls.every(call=>!call.options.method||call.options.method==='GET'),'recovery cannot re-POST');
  assert.ok(calls.every(call=>call.url.includes('project_id=501')));
  global.fetch=async()=>({ok:true,json:async()=>({request_id:'saved',status:'running'})});
  const pending=await observeSqlUpload('', '501','saved',signal,{attempts:2,delay});
  assert.equal(pending.status,'running','bounded observation leaves a recoverable state');
  global.fetch=async()=>({ok:false,status:404});
  assert.equal((await observeSqlUpload('', '501','not-accepted',signal,{attempts:3,delay})).status,'not_visible');
  global.fetch=async()=>({ok:false,status:403});
  await assert.rejects(observeSqlUpload('', '501','saved',signal,{attempts:2,delay}),/signed-in caller/);
  const aborted=new AbortController(); aborted.abort();
  await assert.rejects(observeSqlUpload('', '501','saved',aborted.signal,{attempts:2,delay}),/Aborted/);
  global.fetch=async()=>({ok:true,json:async()=>({request_id:'saved',status:'failed',error_code:'prepare_failed'})});
  assert.equal((await observeSqlUpload('', '501','saved',signal,{attempts:2,delay})).status,'failed');
  console.log('Durable SQL upload recovers disconnects/reloads with GET only, caller/project scope and bounded observation.');
 } finally {global.fetch=original;}
})().catch(error=>{console.error(error);process.exitCode=1;});
