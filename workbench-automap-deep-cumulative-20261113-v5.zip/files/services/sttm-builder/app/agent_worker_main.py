from __future__ import annotations

import logging
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from contextlib import ExitStack
from pathlib import Path
from typing import Any
from uuid import uuid4

from app.agent_runs.checkpoint import SnowflakeStageCheckpointSaver
from app.agent_runs.knowledge_repository import RunKnowledgeRepository
from app.agent_runs.models import EFFORT_POLICIES, EffortLevel
from app.agent_runs.policy import recovered_elapsed_seconds, resolve_policy, validate_worker_configuration
from app.agent_runs.repository import SnowflakeAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.agent_runs.trace_writer import DurableTraceWriter
from app.agent_runs.wake import WorkerWakeListener
from app.agent_runs.worker import AgentWorker
from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
from app.agent_runtime.execution import ExecutionBudget, BudgetedSession
from app.agent_runtime.model_adapter import build_snowflake_cortex_model
from app.agent_tools.specialists import CortexSpecialistAdapter
from app.agent_runtime.run_knowledge import RunKnowledge, knowledge_scope
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.auth.custom_oauth import resolve_worker_oauth_context
from app.core.config import get_settings
from app.core.conversation_memory import ConversationMemoryService
from app.core.conversation import ConversationService
from app.core.dbt_conversion import DbtConversionService
from app.core.learning_retrieval import LearningRetrievalService
from app.core.mapping_sql import MappingSqlService
from app.core.semantic_context import SemanticContextService
from app.core.semantic_model import SemanticModelService
from app.core.table_selection import TableSelectionService
from app.core.derived_source import DerivedSourceService
from app.core.project_service import ProjectService
from app.core.snowflake import SnowflakeClient, SnowflakeSessionLeasePool
from app.core.warehouse_routing import WarehouseWorkload
from app.core.snowflake_agent import SnowflakeAgentClient
from app.core.snowflake_analyst import SnowflakeAnalystClient
from app.core.test_case_generation import TestCaseGenerationService
from app.migration_workflow.graph import build_migration_graph

logger = logging.getLogger(__name__)


def _open_run_knowledge(settings, run, trace, session, access_scope: str, *, enabled: bool) -> RunKnowledge | None:
    """Hydrate the conversation knowledge store and persist it through ``trace``.

    Reads and writes run on the trace writer's thread, which owns ``session``;
    they are therefore serialized with event appends. A storage failure is
    reported as a run event and the run continues with in-memory knowledge.
    """
    if not (enabled and settings.migration_agent_knowledge_enabled):
        return None
    repository = RunKnowledgeRepository(
        session, database=settings.snowflake_database, schema=settings.snowflake_schema,
        table=settings.migration_agent_knowledge_table,
    )
    knowledge = RunKnowledge(
        scope=knowledge_scope(run.run_id, run.request.conversation_id),
        access_scope=access_scope, run_id=run.run_id,
        ttl_seconds=settings.migration_agent_knowledge_ttl_seconds,
        recheck_seconds=settings.migration_agent_knowledge_recheck_seconds,
    )
    loaded: dict[str, Any] = {}

    def load() -> None:
        try:
            loaded["rows"] = repository.load(knowledge.scope, knowledge.access_scope)
        except Exception as exc:
            loaded["error"] = exc

    trace.submit(load)
    trace.flush()
    if "error" in loaded:
        logger.warning("Run knowledge could not be restored for %s", run.run_id, exc_info=loaded["error"])
        trace("knowledge.restore_failed", "failed",
              "Previously verified knowledge could not be restored; this claim re-reads what it needs.",
              {"error": type(loaded["error"]).__name__, "scope": knowledge.scope})
    else:
        restored = knowledge.hydrate(loaded.get("rows") or [])
        trace("knowledge.restored", "succeeded",
              f"Restored {restored} previously verified item(s) for this conversation." if restored
              else "No previously verified knowledge exists for this conversation yet.",
              {"scope": knowledge.scope, "knowledge": knowledge.snapshot()})

    def persist(rows: list[dict[str, Any]]) -> None:
        def write() -> None:
            try:
                repository.write(knowledge.scope, knowledge.access_scope, run.run_id, rows)
            except Exception as exc:
                logger.warning("Run knowledge could not be saved for %s", run.run_id, exc_info=True)
                # Stop durable writes for this claim; in-memory reuse continues.
                knowledge.set_writer(None)
                trace("knowledge.persist_failed", "failed",
                      "Verified knowledge could not be saved for later turns; this run continues with it in memory.",
                      {"error": type(exc).__name__, "scope": knowledge.scope})

        trace.submit(write)

    knowledge.set_writer(persist)
    return knowledge


def _worker_instance_id() -> str:
    existing = os.environ.get("MIGRATION_AGENT_INSTANCE_ID", "").strip()
    if existing:
        return existing
    value = f"{socket.gethostname()}-{os.getpid()}-{uuid4().hex[:8]}"
    os.environ["MIGRATION_AGENT_INSTANCE_ID"] = value
    return value


def _worker_restart_delay(failures: int) -> float:
    """Bound rapid slot crash loops while still retrying transient failures."""
    return min(30.0, float(2 ** max(0, min(failures - 1, 5))))


def _expired_worker_session(error: BaseException) -> bool:
    """An expired Snowflake session cannot recover by polling with itself."""
    seen: set[int] = set()
    current: BaseException | None = error
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        message = str(current).casefold()
        if "390114" in message or "authentication token has expired" in message:
            return True
        current = current.__cause__ or current.__context__
    return False


def _acquire_local_supervisor_lock(settings: object):
    """Allow one detached worker supervisor per local checkout.

    Production replicas coordinate through durable leases. Local restarts are
    different: the shell launcher used to leave portless worker trees behind,
    so every restart silently added two more consumers. An OS lock is released
    automatically even after a crash and is scoped to this checkout.
    """
    if str(getattr(settings, "app_env", "")).strip().lower() != "local":
        return None

    lock_path = Path(__file__).resolve().parents[2] / ".migration-agent-worker.lock"
    handle = lock_path.open("a+", encoding="utf-8")
    if os.name == "nt":
        # fcntl is POSIX-only; Windows locks byte ranges via msvcrt instead.
        import msvcrt

        handle.seek(0)
        if handle.read(1) == "":
            handle.seek(0)
            handle.write("0")
            handle.flush()
        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            handle.close()
            return False
    else:
        import fcntl

        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            handle.close()
            return False
    handle.seek(0)
    handle.truncate()
    handle.write(str(os.getpid()))
    handle.flush()
    return handle


def _supervise_worker_slots(slot_count: int) -> None:
    """Run isolated worker processes so each slot owns independent sessions.

    Snowpark sessions are not thread-safe. Process slots make the configured
    concurrency real without sharing repository, heartbeat, checkpoint, or
    caller-delegated sessions across simultaneous runs.
    """
    stopping = False
    processes: dict[int, subprocess.Popen[bytes]] = {}
    launched_at: dict[int, float] = {}
    failures: dict[int, int] = {}
    next_launch_at: dict[int, float] = {}

    def request_stop(_signum: int, _frame: object) -> None:
        nonlocal stopping
        stopping = True

    def launch(slot_index: int) -> subprocess.Popen[bytes]:
        environment = os.environ.copy()
        environment["MIGRATION_AGENT_SLOT_INDEX"] = str(slot_index)
        process = subprocess.Popen(
            [sys.executable, "-m", "app.agent_worker_main"],
            env=environment,
        )
        launched_at[slot_index] = time.monotonic()
        return process

    previous_term = signal.signal(signal.SIGTERM, request_stop)
    previous_int = signal.signal(signal.SIGINT, request_stop)
    try:
        for slot_index in range(slot_count):
            processes[slot_index] = launch(slot_index)
        logger.info("Started %s durable Migration Agent worker slots", slot_count)
        while not stopping:
            for slot_index, process in list(processes.items()):
                return_code = process.poll()
                if return_code is None:
                    continue
                if slot_index not in next_launch_at:
                    uptime = time.monotonic() - launched_at.get(slot_index, 0.0)
                    failures[slot_index] = 1 if uptime >= 60 else failures.get(slot_index, 0) + 1
                    delay = _worker_restart_delay(failures[slot_index])
                    next_launch_at[slot_index] = time.monotonic() + delay
                    logger.error(
                        "Migration Agent worker slot %s exited with code %s after %.1fs; restarting in %.1fs",
                        slot_index + 1, return_code, uptime, delay,
                    )
                if not stopping and time.monotonic() >= next_launch_at[slot_index]:
                    next_launch_at.pop(slot_index, None)
                    processes[slot_index] = launch(slot_index)
            time.sleep(1)
    finally:
        for process in processes.values():
            if process.poll() is None:
                process.terminate()
        for process in processes.values():
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
        signal.signal(signal.SIGTERM, previous_term)
        signal.signal(signal.SIGINT, previous_int)


class WorkerShutdown(KeyboardInterrupt):
    """Raised in a slot's main thread when the container asks it to stop."""


def _stop_on_sigterm() -> None:
    """Turn SIGTERM into an interrupt at the slot's current statement.

    The run in progress is not marked failed: ``AgentWorker.run_once`` closes
    its Snowflake sessions (rolling back any open transaction) and releases the
    lease in ``finally``, so another slot or replica resumes the same run from
    its last durable checkpoint instead of waiting for the lease to expire.
    """
    if threading.current_thread() is not threading.main_thread():
        return

    def stop(signum: int, _frame: Any) -> None:
        logger.warning("Migration Agent worker slot received signal %s; releasing its run", signum)
        raise WorkerShutdown(f"signal {signum}")

    signal.signal(signal.SIGTERM, stop)


def _lease_healthy_client(pool: SnowflakeSessionLeasePool, stack) -> SnowflakeClient:
    """Lease a pooled session for a whole run, replacing one that went stale.

    A pooled session may have idled out between runs. One `SELECT 1` is far
    cheaper than a new login (an interactive SSO with externalbrowser).
    """
    for attempt in range(2):
        lease = pool.lease()
        client = lease.__enter__()
        try:
            client.session.sql("SELECT 1").collect()
        except Exception as exc:
            # Exiting with the error makes the pool close the stale session.
            lease.__exit__(type(exc), exc, exc.__traceback__)
            if attempt:
                raise
            continue
        stack.push(lease.__exit__)
        return client
    raise RuntimeError("unreachable")


def main() -> None:
    settings = get_settings()
    if not settings.migration_agent_enabled:
        logger.info("Migration Agent worker is disabled; exiting without acquiring runs")
        return
    validate_worker_configuration(settings)
    slot_value = os.environ.get("MIGRATION_AGENT_SLOT_INDEX")
    local_lock = None
    if slot_value is None:
        local_lock = _acquire_local_supervisor_lock(settings)
        if local_lock is False:
            logger.error(
                "A durable Migration Agent supervisor is already active for this local checkout; exiting"
            )
            return
    instance_id = _worker_instance_id()
    if slot_value is None and settings.migration_agent_max_concurrency > 1:
        _supervise_worker_slots(settings.migration_agent_max_concurrency)
        return
    slot_index = int(slot_value or "0")
    client = SnowflakeClient.for_service(settings)
    # A detached transaction can hold the lease row after a killed replica.
    # Bound lock waits on this worker session so one claim cannot consume the
    # warehouse's full statement timeout before the worker retries.
    client.session.sql(
        f"ALTER SESSION SET LOCK_TIMEOUT = {settings.migration_agent_lock_timeout_seconds}"
    ).collect()
    repository = SnowflakeAgentRunRepository(
        client.session,
        database=settings.snowflake_database,
        schema=settings.snowflake_schema,
    )
    heartbeat_client = SnowflakeClient.for_service(settings)
    heartbeat_repository = SnowflakeAgentRunRepository(
        heartbeat_client.session,
        database=settings.snowflake_database,
        schema=settings.snowflake_schema,
    )
    checkpoint_client = SnowflakeClient.for_service(settings)
    # Sessions are reused across the runs this slot executes serially. With
    # local externalbrowser auth every new session is an interactive SSO, and
    # even key-pair/OAuth logins cost seconds on the critical path.
    shared_trace_client: dict[str, SnowflakeClient] = {}
    local_user_pools: dict[str, SnowflakeSessionLeasePool] = {}
    # One run session plus the most parallel partitions any effort allows.
    local_pool_size = 1 + max(policy.max_parallel_mappings for policy in EFFORT_POLICIES.values())

    def trace_session_client() -> SnowflakeClient:
        client = shared_trace_client.get("client")
        if client is None:
            client = SnowflakeClient.for_service(settings)
            shared_trace_client["client"] = client
        return client

    def discard_trace_client() -> None:
        client = shared_trace_client.pop("client", None)
        if client is not None:
            try:
                client.close()
            except Exception:
                logger.debug("Failed to close discarded trace session", exc_info=True)

    def local_user_pool(role: str) -> SnowflakeSessionLeasePool:
        pool = local_user_pools.get(role)
        if pool is None:
            pool = SnowflakeSessionLeasePool(
                settings=settings, user_token="", role=role,
                workload=WarehouseWorkload.CONTROL, maximum=local_pool_size,
            )
            local_user_pools[role] = pool
        return pool

    def build_runtime(run, run_sessions: ExitStack):
        read_only_qa = str(dict(run.request.page_context or {}).get("continuation_kind") or "") == "READ_ONLY_QA"
        if read_only_qa:
            # A read-only explanation writes nothing and is safely re-asked, so
            # durable checkpoints only add fenced procedure calls (~7s locally)
            # between the model's answer and the user seeing it.
            from langgraph.checkpoint.memory import InMemorySaver

            checkpointer = InMemorySaver()
        else:
            checkpointer = SnowflakeStageCheckpointSaver(
                checkpoint_client.session,
                database=settings.snowflake_database,
                schema=settings.snowflake_schema,
                stage=settings.migration_agent_checkpoint_stage,
                io_timeout_seconds=settings.migration_agent_checkpoint_io_timeout_seconds,
                assume_new_thread=run.started_at is None,
                lease_fence=(run.run_id, run.lease_owner, run.lease_generation),
            )
        if settings.local_dev_auth_enabled:
            delegated_token = ""
            delegated_role = run.actor.effective_role
        elif settings.uses_custom_oauth and run.actor.delegation_ref:
            delegated_token, delegated_role = resolve_worker_oauth_context(
                run.actor.delegation_ref,
                run.actor.snowflake_username or "",
                settings, expected_role=run.actor.effective_role,
            )
        else:
            from app.core.exceptions import DelegatedSessionRequired
            raise DelegatedSessionRequired("Sign in to the application again to resume this run.")
        user_role = delegated_role or run.actor.effective_role
        if settings.local_dev_auth_enabled:
            user_pool = local_user_pool(user_role)
            user_client = _lease_healthy_client(user_pool, run_sessions)
        else:
            # Delegated OAuth tokens are per-run; partitions still share a
            # bounded per-run pool instead of logging in once per partition.
            user_pool = SnowflakeSessionLeasePool(
                settings=settings, user_token=delegated_token, role=user_role,
                workload=WarehouseWorkload.CONTROL, maximum=max(1, run.policy.max_parallel_mappings),
            )
            run_sessions.callback(user_pool.close)
            user_client = SnowflakeClient(
                settings=settings,
                user_token=delegated_token,
                role=user_role,
            )
            run_sessions.callback(user_client.close)
        trace_client = trace_session_client()
        trace_service = AgentRunService(
            SnowflakeAgentRunRepository(
                trace_client.session,
                database=settings.snowflake_database,
                schema=settings.snowflake_schema,
            )
        )
        trace = DurableTraceWriter(trace_service, run)
        trace_service.repository.set_worker_fence(run)
        rest_context = user_client.get_rest_session_context()
        cortex_token = rest_context.token if settings.local_dev_auth_enabled else delegated_token
        cortex_auth_mode = "snowflake_token" if settings.local_dev_auth_enabled else "oauth_bearer"
        effort_order = [EffortLevel.LIGHT, EffortLevel.MEDIUM, EffortLevel.HIGH]
        adaptive_limits: list[dict[str, int]] = []
        if run.request.effort is EffortLevel.AUTO:
            current_index = effort_order.index(run.policy.effort)
            for effort in effort_order[current_index + 1:]:
                policy = resolve_policy(effort, settings)
                adaptive_limits.append({
                    "policy": policy.model_dump(mode="json"),
                    "model_limit": policy.model_call_budget,
                    "tool_limit": policy.tool_call_budget,
                    "finalization_model_reserve": policy.finalization_model_call_budget,
                    "finalization_tool_reserve": policy.finalization_tool_call_budget,
                })
        grant = run.budget_grants[-1] if run.budget_grants else {}
        category_offsets = grant.get("category_offsets", {})
        elapsed_used = recovered_elapsed_seconds(run)
        budget = ExecutionBudget(
            model_limit=run.policy.model_call_budget + int(grant.get("model_offset", 0)),
            tool_limit=run.policy.tool_call_budget + int(grant.get("tool_offset", 0)),
            model_used=run.model_calls_used,
            tool_used=run.tool_calls_used,
            finalization_model_reserve=run.policy.finalization_model_call_budget,
            finalization_tool_reserve=run.policy.finalization_tool_call_budget,
            adaptive_limits=adaptive_limits,
            category_limits={key: value + int(category_offsets.get(key, 0)) for key,value in {
                "domain_operations":run.policy.domain_operation_budget,"cortex_calls":run.policy.cortex_call_budget,
                "specialist_model_calls":run.policy.specialist_model_call_budget,
                "snowflake_queries":run.policy.snowflake_query_budget,"retries":run.policy.retry_budget}.items()},
            category_usage=run.category_usage,
            elapsed_seconds=run.policy.elapsed_seconds + int(grant.get("elapsed_offset", 0)),
            elapsed_used=elapsed_used,
            finalization_seconds=run.policy.finalization_seconds,
            token_limit=settings.migration_agent_token_budget,
        )
        if not settings.local_dev_auth_enabled:
            from app.auth.custom_oauth import delegated_session_guard
            budget.set_authentication_check(delegated_session_guard(
                run.actor.delegation_ref, run.actor.snowflake_username or "", user_role,
                delegated_token, settings))
        domain_session = BudgetedSession(user_client.session, budget)
        derived_source_service = DerivedSourceService(domain_session, settings)
        access_scope = (
            f"{run.actor.tenant_id}:{run.actor.user_id}:"
            f"{delegated_role or run.actor.effective_role}"
        )
        trace.set_usage_provider(budget.structured_snapshot)
        knowledge = _open_run_knowledge(
            settings, run, trace, trace_client.session, access_scope, enabled=not read_only_qa,
        )
        memory_service = ConversationMemoryService(domain_session, settings)
        learning_service = (
            LearningRetrievalService(domain_session, settings, access_scope=access_scope)
            if settings.fir_learning_context_enabled
            else None
        )
        def before_cortex_request(operation, retry):
            if retry:
                budget.consume_category("retries", operation)
            budget.consume_category("cortex_calls", operation)

        specialist_client = SnowflakeAgentClient(
            before_request=before_cortex_request,
            token=cortex_token,
            host=rest_context.host,
            auth_mode=cortex_auth_mode,
            role=delegated_role or run.actor.effective_role,
            warehouse=settings.snowflake_agent_warehouse or None,
        )
        analyst_client = SnowflakeAnalystClient(
            before_request=before_cortex_request,
            token=cortex_token,
            host=rest_context.host,
            auth_mode=cortex_auth_mode,
            role=delegated_role or run.actor.effective_role,
            warehouse=settings.snowflake_agent_warehouse or None,
        )

        from app.agent_runs.capacity import CapacityLeasePool
        capacity_pool = None
        if settings.migration_agent_capacity_scopes:
            table = settings.migration_agent_capacity_table
            if "." not in table:
                table = f"{settings.snowflake_database}.{settings.snowflake_schema}.{table}"
            scope_values = {"account": settings.snowflake_account, "tenant": run.actor.tenant_id,
                            "role": delegated_role or run.actor.effective_role,
                            "project": run.project_id or ""}
            scopes = settings.migration_agent_capacity_scopes
            capacity_pool = CapacityLeasePool(
                client_factory=lambda: SnowflakeClient.for_service(settings),
                table=table, scopes=scopes, scope_values=scope_values,
                scope_limits=settings.migration_agent_capacity_limits,
                provision_procedure=settings.qualify_metadata_object_name(settings.migration_agent_capacity_procedure),
                lease_seconds=settings.migration_agent_lease_seconds,
                wait_seconds=settings.migration_agent_capacity_wait_seconds,
                check_active=lambda: budget.ensure_active("specialist capacity"))
        specialists = CortexSpecialistAdapter(specialist_client, capacity_pool=capacity_pool,
            max_concurrency=run.policy.max_parallel_mappings,
            review_confidence=settings.migration_agent_column_review_confidence,
            source_mapping_agent=settings.migration_agent_source_mapping_agent or settings.resolved_source_mapping_agent,
            transformation_rule_agent=settings.migration_agent_transformation_rule_agent or settings.resolved_transformation_rule_agent)
        def build_handlers(scoped_client):
            domain_session = BudgetedSession(scoped_client.session, budget)
            derived_source_service = DerivedSourceService(domain_session, settings)
            memory_service = ConversationMemoryService(domain_session, settings)
            learning_service = (LearningRetrievalService(domain_session, settings, access_scope=access_scope)
                                if settings.fir_learning_context_enabled else None)
            return WorkbenchWorkflowHandlers(
                settings=settings,
                # Command receipts share the delegated user's Snowflake transaction
                # with domain mutations; the worker lease remains service-owned.
                repository=SnowflakeAgentRunRepository(
                    domain_session,
                    lease_fence=(run.run_id, run.lease_owner, run.lease_generation),
                    database=settings.snowflake_database,
                    schema=settings.snowflake_schema,
                ),
                project_service=ProjectService(
                    session=domain_session,
                    settings=settings,
                    memory_service=memory_service,
                ),
                session=domain_session,
                budget=budget,
                trace=trace,
                learning_retrieval=learning_service,
                mapping_sql=MappingSqlService(
                    session=domain_session,
                    analyst_client=analyst_client,
                    settings=settings,
                ),
                semantic_context=SemanticContextService(
                    session=domain_session,
                    settings=settings,
                    semantic_model_service=SemanticModelService(settings),
                    table_selection_service=TableSelectionService(
                        scoped_client,
                        settings,
                        f"{run.actor.tenant_id}:{run.actor.user_id}:{delegated_role or run.actor.effective_role}",
                    ),
                    derived_source_service=derived_source_service,
                    access_scope=access_scope,
                ),
                derived_sources=derived_source_service,
                dbt_conversion=DbtConversionService(
                    agent_client=specialist_client,
                    settings=settings,
                    learning_service=learning_service,
                    memory_service=memory_service,
                ),
                test_generation=TestCaseGenerationService(
                    agent_client=specialist_client,
                    settings=settings,
                    learning_service=learning_service,
                    memory_service=memory_service,
                ),
                rag_search=ConversationService(
                    None,
                    sttm_builder_service=None,
                    memory_service=memory_service,
                    settings=settings,
                    learning_service=learning_service,
                ),
                analyst=analyst_client,
                sql_preview_max_rows=settings.migration_agent_sql_preview_max_rows,
                sql_timeout_seconds=settings.migration_agent_sql_timeout_seconds,
                sql_result_max_bytes=settings.migration_agent_sql_result_max_bytes,
                specialists=specialists,
                knowledge=knowledge,
            )
        from contextlib import contextmanager
        @contextmanager
        def partition_handlers():
            budget.ensure_active("open delegated partition session")
            # Snowpark sessions are not thread-safe, so each concurrent
            # partition leases its own session; finished partitions return it
            # for the next one instead of closing it.
            with user_pool.lease() as client:
                yield build_handlers(client)

        handlers = build_handlers(user_client)
        handlers.partition_factory = partition_handlers
        # Registry-level reuse confirms stored contracts through the run's
        # primary session (one batched signature query when needed).
        handlers.attach_knowledge_reader()
        graph = build_migration_graph(handlers, checkpointer=checkpointer)
        model_name = run.request.model_name or {
            EffortLevel.LIGHT: settings.migration_agent_model_light,
            EffortLevel.MEDIUM: settings.migration_agent_model_medium,
            EffortLevel.HIGH: settings.migration_agent_model_high,
        }[run.policy.effort]
        model = build_snowflake_cortex_model(
            host=rest_context.host,
            oauth_token=cortex_token,
            auth_mode=cortex_auth_mode,
            model=model_name,
            role=delegated_role or run.actor.effective_role,
            warehouse=settings.snowflake_agent_warehouse or None,
            reasoning_effort=run.policy.reasoning_effort,
            timeout_seconds=settings.migration_agent_model_timeout_seconds,
            # 0 uses the model's Cortex window; a test profile may set it explicitly.
            context_window_tokens=settings.migration_agent_context_window_tokens or None,
            max_completion_tokens=settings.migration_agent_max_completion_tokens,
            # Retry once in model middleware so usage, timing, cancellation,
            # and failure traces remain host-visible. Provider retries here
            # would multiply with middleware retries and could hide a stalled
            # model boundary for many minutes.
            max_retries=0,
        )
        runtime = DeepAgentsRuntime(
            model=model,
            migration_graph=graph,
            budget=budget,
            checkpointer=checkpointer,
            trace=trace,
            workbench=handlers,
            host_terminalization=settings.migration_agent_host_terminalization_v1,
            tool_governance=settings.migration_agent_tool_governance_v1,
            knowledge=knowledge,
        )

        def cleanup_runtime() -> None:
            try:
                trace.close()
            finally:
                if not trace.stopped:
                    # A hung writer may still use the session; never share it.
                    discard_trace_client()
                run_sessions.close()

        return runtime, cleanup_runtime

    def runtime_factory(run):
        # Leased sessions must return to the pool even when construction
        # fails; otherwise the pool's capacity leaks and later runs stall.
        run_sessions = ExitStack()
        try:
            return build_runtime(run, run_sessions)
        except BaseException:
            run_sessions.close()
            raise

    worker = AgentWorker(
        repository,
        None,
        worker_id=(
            f"{settings.migration_agent_worker_id}:{instance_id}:{slot_index + 1}"
        ),
        lease_seconds=settings.migration_agent_lease_seconds,
        heartbeat_seconds=settings.migration_agent_heartbeat_seconds,
        runtime_factory=runtime_factory,
        heartbeat_repository=heartbeat_repository,
        outbox_recovery_interval_seconds=settings.migration_agent_outbox_recovery_interval_seconds,
        outbox_recovery_batch_size=settings.migration_agent_outbox_recovery_batch_size,
    )
    wake = WorkerWakeListener(settings, slot_index)
    _stop_on_sigterm()
    idle_delay = 0.25
    while True:
        try:
            worked = worker.run_once()
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            # Lease polling is infrastructure I/O. A transient Snowflake timeout,
            # failover, or lock left by a terminated replica must not terminate the
            # durable worker process (and therefore the whole service group).
            logger.exception("Migration Agent worker loop failed; retrying after backoff")
            if _expired_worker_session(exc):
                # A fresh process creates new service, heartbeat, and checkpoint
                # sessions. Reusing the expired clients cannot claim new runs.
                raise
            time.sleep(5)
            idle_delay = 0.25
            continue
        if worked:
            idle_delay = 0.25
            continue
        # A wake-up from the API means a run was just queued: claim it now.
        if wake.wait(idle_delay):
            idle_delay = 0.25
            continue
        idle_delay = min(2.0, idle_delay * 1.7)


if __name__ == "__main__":
    main()
