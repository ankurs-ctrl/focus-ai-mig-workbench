"""Carry verified, caller-owned run evidence into a new conversation turn."""
from typing import Any
from app.agent_tools.contract_reader import normalize_fqn
from app.agent_tools.catalog_discovery import identifier_parts

_PRIOR_EVIDENCE_EVENT_TYPES = frozenset({"tool.completed", "tool.reused", "workspace.synced", "run.ready_for_review"})


def _prior_run_evidence(events: list[Any], *, limit: int = 16) -> list[dict[str, Any]]:
    """Carry sanitized durable evidence into a follow-up without replaying tools."""
    evidence: list[dict[str, Any]] = []
    verified_tables: set[str] = set()

    def collect_tables(value: Any, key: str = "") -> None:
        if isinstance(value, dict):
            for child_key, child in value.items():
                collect_tables(child, str(child_key).casefold())
        elif isinstance(value, list):
            for child in value:
                collect_tables(child, key)
        elif key in {"table", "table_fqn", "source_table", "target_table", "candidates"}:
            candidate = normalize_fqn(value)
            if len(identifier_parts(candidate)) == 3:
                verified_tables.add(candidate)

    for event in events:
        if event.event_type not in _PRIOR_EVIDENCE_EVENT_TYPES:
            continue
        data = dict(event.data or {})
        if str(event.status or "").lower() in {"succeeded", "completed", "ready_for_review"}:
            collect_tables(data.get("result_preview"))
        evidence.append({
            "event_type": event.event_type,
            "capability": data.get("label") or data.get("tool") or event.safe_summary,
            "sanitized_input": data.get("sanitized_input") or {},
            "result_preview": data.get("result_preview"),
            "evidence_refs": list(data.get("evidence_refs") or []),
            "artifact_refs": list(event.artifact_refs or []),
        })
    retained = evidence[-limit:]
    if verified_tables:
        retained.append({
            "event_type": "verified.catalog_scope",
            "capability": "Server-verified catalog scope from the preceding run",
            "result_preview": {"candidates": sorted(verified_tables)},
            "sanitized_input": {}, "evidence_refs": [], "artifact_refs": [],
        })
    return retained
