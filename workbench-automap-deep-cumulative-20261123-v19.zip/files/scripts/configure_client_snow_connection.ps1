param(
    [string]$EnvFile = "",
    [switch]$ForceRecreate
)

$ErrorActionPreference = "Stop"
# Windows PowerShell 5.1 does not define the $IsWindows automatic variable.
$runningOnWindows = $env:OS -eq 'Windows_NT'

$RootDir = Split-Path -Parent $PSScriptRoot
if (-not $EnvFile) {
    $EnvFile = Join-Path $RootDir "infra\snowflake\env\client.env"
}

$ToolsVenv = Join-Path $RootDir ".client-tools-venv"
if ($runningOnWindows) {
    $SnowExe = Join-Path $ToolsVenv "Scripts/snow.exe"
} else {
    $SnowExe = Join-Path $ToolsVenv "bin/snow"
}

function Import-ClientEnv {
    param([string]$Path)
    if (-not (Test-Path $Path)) { throw "Env file not found: $Path" }
    $values = @{}
    foreach ($line in Get-Content $Path) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("#")) { continue }
        $parts = $trimmed -split "=", 2
        if ($parts.Count -ne 2) { continue }
        $key = $parts[0].Trim()
        $value = $parts[1].Trim()
        if (($value.StartsWith('"') -and $value.EndsWith('"')) -or
            ($value.StartsWith("'") -and $value.EndsWith("'"))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        $values[$key] = $value
    }
    return $values
}

if (-not (Test-Path $SnowExe)) {
    Write-Host "Snow CLI tools are not bootstrapped yet. Running bootstrap script first."
    & (Join-Path $PSScriptRoot "bootstrap_client_spcs_tools.ps1")
}

$cfg = Import-ClientEnv -Path $EnvFile

$required = @(
    "SNOWFLAKE_CONNECTION",
    "SNOWFLAKE_ACCOUNT",
    "SNOWFLAKE_USER",
    "SNOWFLAKE_ROLE",
    "SNOWFLAKE_WAREHOUSE",
    "SNOWFLAKE_DATABASE"
)
foreach ($name in $required) {
    if (-not $cfg.ContainsKey($name) -or [string]::IsNullOrWhiteSpace($cfg[$name])) {
        throw "$name must be set in $EnvFile"
    }
}

try {
    & $SnowExe connection test -c $cfg["SNOWFLAKE_CONNECTION"] *> $null
    if ($LASTEXITCODE -eq 0 -and -not $ForceRecreate) {
        Write-Host "Snow connection '$($cfg["SNOWFLAKE_CONNECTION"])' already works. Reusing it."
        exit 0
    }
} catch {
}

if ($ForceRecreate) {
    try { & $SnowExe connection remove $cfg["SNOWFLAKE_CONNECTION"] --format TABLE } catch { }
} else {
    try { & $SnowExe connection remove $cfg["SNOWFLAKE_CONNECTION"] --format TABLE *> $null } catch { }
}

# ==============================================================================
# KEY-PAIR AUTHENTICATION (NATIVE PKCS#8)
# ==============================================================================
$pkcs8Content = $env:PKCS8_KEY_CONTENT
$passphrase   = $env:KEY_PASSPHRASE

if ([string]::IsNullOrWhiteSpace($pkcs8Content) -or [string]::IsNullOrWhiteSpace($passphrase)) {
    throw "Missing required ADO environment variables: PKCS8_KEY_CONTENT or KEY_PASSPHRASE."
}

# Persist the key to a STABLE path (NOT a temp file that gets deleted).
# Snow CLI re-reads this file and re-signs the JWT on EVERY invocation, so it
# must survive for the lifetime of the CI job / every later `snow` command.
# The ADO agent is ephemeral, so the key is destroyed when the job ends.
$KeyDir    = Join-Path $RootDir ".secrets"
New-Item -ItemType Directory -Force -Path $KeyDir | Out-Null
$Pkcs8File = Join-Path $KeyDir "client_rsa_pkcs8.p8"

# Clean and re-wrap PKCS#8 PEM format
$cleanBody = $pkcs8Content -replace '-----BEGIN ENCRYPTED PRIVATE KEY-----', '' `
                           -replace '-----END ENCRYPTED PRIVATE KEY-----', '' `
                           -replace '\s+', ''
$wrappedBody = ($cleanBody -replace '.{64}', "`$0`n").TrimEnd()
$formattedKey = "-----BEGIN ENCRYPTED PRIVATE KEY-----`n$wrappedBody`n-----END ENCRYPTED PRIVATE KEY-----`n"

# Write key file to disk
[System.IO.File]::WriteAllText($Pkcs8File, $formattedKey)

# Restrict permissions on Linux/macOS
if (-not $runningOnWindows) { chmod 600 $Pkcs8File }

# Pass passphrase via standard Snow CLI env variable
$env:PRIVATE_KEY_PASSPHRASE = $passphrase

Write-Host "Creating Snow CLI connection '$($cfg["SNOWFLAKE_CONNECTION"])' with Key-Pair Authentication"
$snowArgs = @(
    "connection", "add",
    "--connection-name", $cfg["SNOWFLAKE_CONNECTION"],
    "--account", $cfg["SNOWFLAKE_ACCOUNT"],
    "--user", $cfg["SNOWFLAKE_USER"],
    "--authenticator", "SNOWFLAKE_JWT",
    "--private-key-file", $Pkcs8File,
    "--role", $cfg["SNOWFLAKE_ROLE"],
    "--warehouse", $cfg["SNOWFLAKE_WAREHOUSE"],
    "--database", $cfg["SNOWFLAKE_DATABASE"],
    "--default",
    "--no-interactive",
    "--format", "TABLE"
)
& $SnowExe @snowArgs

Write-Host ""
Write-Host "Testing connection '$($cfg["SNOWFLAKE_CONNECTION"])'"
& $SnowExe connection test -c $cfg["SNOWFLAKE_CONNECTION"]

Write-Host ""
Write-Host "Connection configured successfully."
Write-Host "Private key persisted at: $Pkcs8File (removed when the ephemeral agent is destroyed)."
