# Validation — project bootstrap, admin resource actions and Join Recommendations

## Local results

- Final combined backend selection: **188 passed**. Includes bulk initialization, template targets/creator metadata, transaction failure and retry recovery, Admin-only resource actions, status preservation, publication, confidence/custom rules and real uploaded-SQL fixtures.
- Ten-target/242-attribute bulk fixture verifies **five mapping persistence operations**: headers, inserted identities, snapshots, attributes and final header payloads. This is the initializer's statement count, not the total HTTP endpoint query count or a live Snowflake timing measurement.
- A failed initializer is rolled back by the single outer transaction owner. A missing mutex fails before project creation. Retrying a completed request returns the same mappings without overwriting later project metadata. Existing incomplete shells are explicitly rejected for review.
- Viewer and Publisher removal attempts are rejected before SQL mutation. Admin project removal updates the project and children in one transaction; mapping removal updates only the mapping. Missing resources roll back. Removal uses UPDATE, not physical DELETE/DROP, retaining saved history.
- Frontend mapping/navigation suite: **44 passed**. Candidate/review suite: **79 passed**. SQL-upload workflow assertions passed. Render harness imports and confidence-label expectations were aligned with the prior release's actual component dependencies/output.
- TypeScript, Python parsing, agent-spec checksum and whitespace checks passed.

## UI and integration limits

The application was started locally using sample data and the new admin route served HTTP 200. The browser tool reported that browser use was disabled; native computer-use startup was also unavailable. No genuine rendered screenshot or interactive browser verification is claimed. Restarting the corrected preview was subsequently blocked by automatic approval review because its usage limit was reached. Preview source and commands are provided for local inspection without Snowflake access.

No client Snowflake connection, deletion, archive, backfill, deployment or account/grant change was performed for these changes. The new mutex migration was supplied but not executed. Real Snowflake transaction locking, cross-replica contention, end-to-end creation latency and the component producing the client's 504 remain unverified. Do not infer a specific latency reduction from offline statement-count tests. Existing ingress timeouts were not raised.

The mutex serializes template creation to make the key lookup and commit concurrency-safe across replicas. It intentionally does not parallelize operations on one session. The new bulk path eliminates per-mapping autosave/read/delete/count cycles. Project/template validation may still make metadata queries. New empty mappings do not invoke models or read source data.

AI Recommendations is explicitly enabled for the main Join Definitions invocation; existing loading/empty/error/review/accept behavior is retained. Actual recommendation retrieval in the client environment remains to be verified after deployment.

## Previous release

All prior Auto-map confidence/custom-rule and SQL-upload fixes remain included. Their native acceptance result and limitations are retained under `docs/automap-confidence-rules-20261111/`; that native test does not establish live acceptance of this release's new project or administrative workflows.
