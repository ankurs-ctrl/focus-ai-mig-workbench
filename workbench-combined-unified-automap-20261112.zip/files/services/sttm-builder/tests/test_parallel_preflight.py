"""Offline host -> worker -> merged response checks; no SQL or model service calls."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from app.core.agent_payload_budget import AgentPayloadBudgetError, AgentPayloadBudgetResult
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.config import Settings
from app.core.sttm_builder import STTMBuilderService
from app.schema.contracts import ApiWarning
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
from tests.unit.core.test_automap_parallel_integration import enabled_service, request_payload


def settings_values():
    return dict(AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTOMAP_PARALLEL_CONTEXT_V1=True,
                AUTOMAP_PARALLEL_TEST_AGENT="D.S.AGT_AUTOMAP_SCAN_DEV_TEST",
                AUTOMAP_PARALLEL_PERMIT_TABLE_FQN="D.S.PERMITS",
                AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN="D.S.ARCHIVE",
                AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE="ORG.ACCOUNT",
                AUTOMAP_PARALLEL_POOL_EPOCH="11111111-1111-1111-1111-111111111111",
                AUTOMAP_PARALLEL_POOL_CAPACITY=2,
                AGENT_OUTBOUND_MESSAGE_MAX_CHARS=100000, AGENT_OUTBOUND_MESSAGE_MAX_BYTES=100000)


def settings(**changes):
    return Settings(_env_file=None, **{**settings_values(), **changes})


def isolated_worker(monkeypatch):
    import app.core.sttm_builder as module
    builder, calls = enabled_service()
    builder._settings = settings()
    monkeypatch.setattr(module, "attach_agent_execution_context", lambda req, memory: req)
    builder._conversation_memory = None
    builder._sanitize_request_semantic_context = lambda req: req
    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._govern_request_for_model = lambda req, decision: req
    builder._should_use_analyst = lambda *args: False
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    builder._persist_response_artifact = lambda *args: None
    return builder, calls


def test_host_preflight_is_bounded_no_call_baseline_and_preserves_request(monkeypatch):
    import app.core.automap_retrieval as retrieval
    import app.core.automap_scan_context as scan_context
    request = STTMBuilderEnvelopeRequest.model_validate(request_payload(huge=True))
    before = request.model_dump(mode="json")
    original = scan_context.prepare_scan_context
    prepared_results = []

    def prepare(store, **kwargs):
        assert store.discovered == {} and store.search_rounds == 0
        prepared = original(store, **kwargs)
        prepared_results.append(prepared)
        return prepared

    monkeypatch.setattr(scan_context, "prepare_scan_context", prepare)
    monkeypatch.setattr(retrieval, "batch_packet", lambda *args, **kwargs: pytest.fail("Full registry projected"))
    monkeypatch.setattr(retrieval.AutoMapContext, "discover_batch", lambda *args, **kwargs: pytest.fail("Host discovery"))
    result = STTMBuilderService.project_agent_payload(request, settings())
    assert isinstance(result, AgentPayloadBudgetResult)
    assert json.loads(result.text) == result.payload
    baseline = result.diagnostics["parallel_preflight"]
    assert baseline["baseline_only"] and not baseline["runtime_ready"]
    assert baseline["learning_discovery"] == "not_discovered"
    assert baseline["model_calls"] == 0
    assert baseline["blocked_table_count"] == 1 and baseline["planned_shard_count"] > 0
    assert not baseline["plan_complete_coverage"] and not baseline["scan_complete"]
    assert prepared_results[0].blocked_table_ids == ("D.S.HUGE",)
    assert len(prepared_results[0].exact_store.inventory["D.S.HUGE"]) == 800
    assert "UNSELECTED_0000" not in result.text and len(result.text) < 2000
    wire = json.dumps([{"role": "user", "content": [{"type": "text", "text": result.text}]}], ensure_ascii=False)
    assert len(wire.encode("utf-8")) <= 100000
    assert request.model_dump(mode="json") == before


def test_host_worker_final_result_maps_good_table_with_partial_warning_no_data_changes(monkeypatch):
    builder, calls = isolated_worker(monkeypatch)
    proxy = AutoMappingProxyClient(builder._settings)
    request = STTMBuilderEnvelopeRequest.model_validate(request_payload(huge=True))
    before = request.model_dump(mode="json")
    responses = []
    headers = {"Authorization": "Bearer unchanged-test-credential"}
    decision = SimpleNamespace()

    def worker(req, *, headers, batch_index):
        assert headers == {"Authorization": "Bearer unchanged-test-credential"}
        import asyncio
        response = asyncio.run(builder.invoke_auto_map_parallel(req, governance_decision=decision))
        responses.append(response)
        return response

    monkeypatch.setattr(proxy, "_invoke_batch", worker)
    response = proxy._invoke_with_headers(request, headers=headers)
    assert len(calls) == len(responses) == 1
    assert response.result.mappings["NAME0"].source_attributes == ["a.X47"]
    assert not response.error
    assert response.meta["auto_mapping_dispatch"]["failed_batches"] == []
    assert "scan_incomplete" in {warning.code for warning in response.warnings}
    assert "AUTO_MAPPING_BATCH_FAILED" not in {warning.code for warning in response.warnings}
    assert all(isinstance(warning, ApiWarning) for warning in response.warnings)
    assistant = response.meta["assistant_context"]
    assert assistant["non_exhaustive"]
    assert assistant["warnings"] == [warning.model_dump(mode="json") for warning in response.warnings]
    assert "UNSELECTED_0000" not in json.dumps(assistant)
    assert request.model_dump(mode="json") == before
    assert len(calls[0][0].inventory["D.S.HUGE"]) == 800
    assert response.context == request.context


def test_mandatory_capsule_still_fails_before_worker(monkeypatch):
    value = request_payload()
    value["context"]["workspace_context"]["filters"]["filter_sql"] = "a.X47 IS NOT NULL /*" + "mandatory" * 20000 + "*/"
    request = STTMBuilderEnvelopeRequest.model_validate(value)
    proxy = AutoMappingProxyClient(settings())
    monkeypatch.setattr(proxy, "_invoke_batch", lambda *args, **kwargs: pytest.fail("Worker dispatched"))
    with pytest.raises(AgentPayloadBudgetError, match="mandatory"):
        proxy._invoke_with_headers(request, headers={})


@pytest.mark.parametrize("chars,bytes_limit", [(100000, 2000), (2000, 100000), (200000, 200000)])
def test_preflight_uses_complete_scan_budget_and_runtime_hard_cap(monkeypatch, chars, bytes_limit):
    import app.core.automap_scan_context as scan_context
    original = scan_context.prepare_scan_context
    seen = []

    def prepare(store, **kwargs):
        seen.append(kwargs["budget"])
        return original(store, **kwargs)

    monkeypatch.setattr(scan_context, "prepare_scan_context", prepare)
    request = STTMBuilderEnvelopeRequest.model_validate(request_payload())
    config = settings(AGENT_OUTBOUND_MESSAGE_MAX_CHARS=chars, AGENT_OUTBOUND_MESSAGE_MAX_BYTES=bytes_limit)
    if min(chars, bytes_limit) == 2000:
        with pytest.raises(AgentPayloadBudgetError):
            STTMBuilderService.project_agent_payload(request, config)
    else:
        STTMBuilderService.project_agent_payload(request, config)
    assert seen[0].max_chars == min(chars, 120000)
    assert seen[0].max_bytes == min(bytes_limit, 120000)


def test_fit_baseline_is_not_runtime_ready_and_flag_off_keeps_legacy(monkeypatch):
    request = STTMBuilderEnvelopeRequest.model_validate(request_payload())
    result = STTMBuilderService.project_agent_payload(request, settings())
    assert result.diagnostics["parallel_preflight"]["plan_complete_coverage"]
    assert not result.diagnostics["parallel_preflight"]["runtime_ready"]
    import app.core.automap_scan_context as scan_context
    monkeypatch.setattr(scan_context, "prepare_scan_context", lambda *args, **kwargs: pytest.fail("Flag off"))
    old = STTMBuilderService.project_agent_payload(request, settings(AUTOMAP_PARALLEL_CONTEXT_V1=False))
    assert "parallel_preflight" not in old.payload


@pytest.mark.parametrize("field", ["AUTOMAP_PARALLEL_TEST_AGENT", "AUTOMAP_PARALLEL_PERMIT_TABLE_FQN",
    "AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN", "AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE",
    "AUTOMAP_PARALLEL_POOL_EPOCH", "AUTOMAP_PARALLEL_POOL_CAPACITY"])
def test_explicit_required_config_fails_closed(field, monkeypatch):
    monkeypatch.delenv(field, raising=False)
    values = settings_values()
    del values[field]
    with pytest.raises(ValueError, match=field):
        Settings(_env_file=None, **values)


@pytest.mark.parametrize("field,value", [
    ("AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN", "D.S.ARCHIVE;DROP"),
    ("AUTOMAP_PARALLEL_PERMIT_TABLE_FQN", "DB.SCHEMA.PERMITS"),
    ("AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE", "https://org-account"),
    ("AUTOMAP_PARALLEL_POOL_EPOCH", "invalid"),
    ("AUTOMAP_PARALLEL_POOL_CAPACITY", 0), ("AUTOMAP_PARALLEL_POOL_CAPACITY", 33),
    ("AUTOMAP_PARALLEL_POOL_CAPACITY", True), ("AUTOMAP_PARALLEL_POOL_CAPACITY", 1.0),
    ("AUTOMAP_PARALLEL_MAX_WORKERS", 33), ("AUTOMAP_PARALLEL_MAX_CALLS", 65),
    ("AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS", 33),
])
def test_invalid_runtime_config_fails_closed(field, value):
    with pytest.raises(ValueError):
        settings(**{field: value})


@pytest.mark.parametrize("capacity", [1, 2, 4, 8, 9, 32])
def test_settings_accept_bounded_parallel_capacity_and_workers(capacity):
    actual = settings(AUTOMAP_PARALLEL_POOL_CAPACITY=capacity,
                      AUTOMAP_PARALLEL_MAX_WORKERS=capacity)
    assert actual.automap_parallel_pool_capacity == capacity
    assert actual.automap_parallel_max_workers == capacity


@pytest.mark.parametrize("workers", [9, 32])
@pytest.mark.parametrize("enabled", [False, True])
def test_larger_worker_limit_does_not_change_existing_pool_capacity(workers, enabled):
    actual = settings(AUTOMAP_PARALLEL_MAX_WORKERS=workers,
                      AUTOMAP_PARALLEL_CONTEXT_V1=enabled)
    assert actual.automap_parallel_max_workers == workers
    assert actual.automap_parallel_pool_capacity == 2
    assert actual.automap_parallel_context_v1 is enabled


@pytest.mark.parametrize("workers", [9, 32])
def test_worker_limit_does_not_provision_unset_pool_capacity(monkeypatch, workers):
    monkeypatch.delenv("AUTOMAP_PARALLEL_POOL_CAPACITY", raising=False)
    values = settings_values()
    del values["AUTOMAP_PARALLEL_POOL_CAPACITY"]
    actual = Settings(_env_file=None, **{**values, "AUTOMAP_PARALLEL_CONTEXT_V1": False,
                                       "AUTOMAP_PARALLEL_MAX_WORKERS": workers})
    assert actual.automap_parallel_pool_capacity is None
    assert actual.automap_parallel_max_workers == workers
    actual.automap_parallel_context_v1 = True
    with pytest.raises(ValueError, match="AUTOMAP_PARALLEL_POOL_CAPACITY"):
        actual.validate_parallel_automap()


def test_renderer_disabled_zero_loads_without_provisioning_environment(monkeypatch):
    for name in settings_values():
        if name.startswith("AUTOMAP_"):
            monkeypatch.delenv(name, raising=False)
    monkeypatch.delenv("AUTOMAP_PARALLEL_MAX_WORKERS", raising=False)
    monkeypatch.setenv("AUTOMAP_PARALLEL_CONTEXT_V1", "false")
    monkeypatch.setenv("AUTOMAP_PARALLEL_POOL_CAPACITY", "0")
    actual = Settings(_env_file=None)
    assert not actual.automap_parallel_context_v1
    assert actual.automap_parallel_pool_capacity == 0
    assert actual.automap_parallel_max_workers == 2


@pytest.mark.parametrize("value", [0, "0", None])
def test_disabled_settings_allow_unprovisioned_capacity_but_enabling_rejects(value):
    actual = settings(AUTOMAP_PARALLEL_CONTEXT_V1=False,
                      AUTOMAP_PARALLEL_POOL_CAPACITY=value)
    assert actual.automap_parallel_pool_capacity == (None if value is None else 0)
    assert actual.automap_parallel_max_workers == 2
    actual.automap_parallel_context_v1 = True
    with pytest.raises(ValueError, match="AUTOMAP_PARALLEL_POOL_CAPACITY"):
        actual.validate_parallel_automap()


@pytest.mark.parametrize("field", ["AUTOMAP_PARALLEL_POOL_CAPACITY", "AUTOMAP_PARALLEL_MAX_WORKERS"])
@pytest.mark.parametrize("value", [True, False, 1.0, -1, 33])
@pytest.mark.parametrize("enabled", [False, True])
def test_parallel_capacity_and_workers_reject_invalid_values_even_when_disabled(field, value, enabled):
    with pytest.raises(ValueError, match=field):
        settings(**{field: value, "AUTOMAP_PARALLEL_CONTEXT_V1": enabled})


def test_settings_load_runtime_fields_from_environment_without_enabling_pools(monkeypatch):
    for name, value in settings_values().items():
        monkeypatch.setenv(name, str(value))
    monkeypatch.delenv("SNOWFLAKE_WRITE_LEASE_POOL_V1", raising=False)
    monkeypatch.delenv("SNOWFLAKE_SESSION_LEASE_POOL_V1", raising=False)
    actual = Settings(_env_file=None)
    assert actual.automap_parallel_archive_table_fqn == "D.S.ARCHIVE"
    assert actual.automap_parallel_pool_capacity == 2
    assert actual.automap_parallel_max_workers == 2
    assert actual.automap_parallel_max_calls == 32
    assert actual.automap_parallel_max_reduction_rounds == 16
    assert not actual.snowflake_write_lease_pool_v1 and not actual.snowflake_session_lease_pool_v1


@pytest.fixture
def clean_fast_environment(monkeypatch):
    for name in ("AUTOMAP_FAST_PATH_V1", "AUTOMAP_FAST_PROJECT_IDS", "AUTOMAP_FAST_CANARY_REVISION"):
        monkeypatch.delenv(name, raising=False)


def test_fast_settings_default_off_and_empty_without_provisioning(clean_fast_environment):
    actual = settings()
    assert actual.automap_fast_path_v1 is False
    assert actual.automap_fast_project_ids == actual.automap_fast_canary_revision == ""
    assert actual.automap_parallel_pool_capacity == 2
    assert not actual.snowflake_write_lease_pool_v1


@pytest.mark.parametrize("value,expected", [(True, True), (False, False), ("true", True), ("false", False)])
def test_fast_boolean_accepts_only_canonical_inputs(clean_fast_environment, value, expected):
    actual = settings(AUTOMAP_FAST_PATH_V1=value, AUTOMAP_FAST_PROJECT_IDS="501")
    assert actual.automap_fast_path_v1 is expected
    assert actual.automap_fast_project_ids == "501"


@pytest.mark.parametrize("field,value", [
    ("AUTOMAP_FAST_PATH_V1", value) for value in
    (None, 0, 1, 1.0, "TRUE", "False", "yes", "1", " true", "true\n", [], {})
] + [
    ("AUTOMAP_FAST_PROJECT_IDS", value) for value in
    (None, 501, ["501"], [501], ["*"], "501,*", "*,501", "**", " *", "* ", "*\n", "0", "0501", "+501", "-501", "501.0",
     "5e2", "\u0665\u0660\u0661", "\uff15\uff10\uff11", " 501", "501 ", "501\n", "501,,502", "501,", ",501", "501,501",
     "test-project", "501;502", "501\"\nINJECT: true", "${SECRET}", "[501]", "9" * 39,
     ",".join(str(number) for number in range(1, 34)))
] + [
    ("AUTOMAP_FAST_CANARY_REVISION", value) for value in
    (None, 1, [], "a" * 65, "bad revision", "revision\n", "${SECRET}", "\"\nINJECT: true", "/tmp/revision")
])
def test_fast_settings_reject_noncanonical_values_even_when_disabled(clean_fast_environment, field, value):
    with pytest.raises(ValueError, match=field):
        settings(**{field: value})


@pytest.mark.parametrize("projects", ["1", "501,502", "9" * 38,
    ",".join(str(number) for number in range(1, 33)),
    ",".join("9" * 36 + f"{number:02d}" for number in range(1, 33))])
def test_fast_allowlist_is_a_bounded_exact_csv(clean_fast_environment, projects):
    from app.core.automap_batch import fast_project_enabled
    actual = settings(AUTOMAP_FAST_PATH_V1=True, AUTOMAP_FAST_PROJECT_IDS=projects)
    assert actual.automap_fast_project_ids == projects
    assert all(fast_project_enabled(actual, project) for project in projects.split(","))
    assert fast_project_enabled(actual, "999999")


@pytest.mark.parametrize("enabled", [False, True])
@pytest.mark.parametrize("project", ["301", "501", "502", "9" * 38])
def test_global_scope_capabilities_and_acceptance_agree(clean_fast_environment, monkeypatch, enabled, project):
    import app.api as api
    from fastapi import HTTPException, Request
    from tests.unit.core.test_auto_mapping_proxy import _request

    actual = settings(AUTOMAP_FAST_PATH_V1=enabled, AUTOMAP_FAST_PROJECT_IDS="*")
    proxy = AutoMappingProxyClient(actual)
    caller_request = Request({"type": "http", "headers": []})
    checked_callers = []
    monkeypatch.setattr(api, "get_current_principal", lambda request: checked_callers.append(request))
    capabilities = api.auto_map_capabilities(caller_request, project, proxy).data
    assert checked_callers == [caller_request]
    assert capabilities == {
        "selected_scope": enabled, "reevaluation": enabled,
        "modes": ["preserve_and_complete", "reeval_selected", "reeval_all"] if enabled else ["preserve_and_complete"],
    }
    for mode in capabilities["modes"] if enabled else ["reeval_all", "reeval_selected", "preserve_and_complete"]:
        request = _request(2)
        request.context.project_id = project
        request.meta = {"auto_map_resolution_mode": mode, "auto_map_target_scope": ["COL_0"]}
        if mode == "reeval_selected":
            request.meta["auto_map_reevaluate_targets"] = ["COL_0"]
        before = request.model_dump(mode="json")
        if enabled:
            accepted = proxy._accept_resolution(request)
            assert accepted.meta["auto_map_fast_path"] == "v1"
            assert accepted.meta["auto_map_target_scope"] == ["COL_0"]
        else:
            with pytest.raises(HTTPException) as error:
                proxy._accept_resolution(request)
            assert error.value.status_code == 422
        assert request.model_dump(mode="json") == before


@pytest.mark.parametrize("project", [None, "", " ", "\t", 301, True, [], {},
    "0", "-1", "+301", "0301", " 301", "301 ", "301\n", "3e2", "future-project", "9" * 39])
def test_global_scope_requires_canonical_project_identity(clean_fast_environment, project):
    from app.core.automap_batch import fast_project_enabled
    actual = settings(AUTOMAP_FAST_PATH_V1=True, AUTOMAP_FAST_PROJECT_IDS="*")
    assert not fast_project_enabled(actual, project)


@pytest.mark.parametrize("projects", ["501,*", "*,501", " *", "* ", "*\n", "**", ["*"], ["501", "*"]])
def test_deprecated_rollout_list_does_not_choose_a_different_engine(projects):
    from app.core.automap_batch import fast_project_enabled
    actual = SimpleNamespace(automap_fast_path_v1=True, automap_fast_project_ids=projects)
    assert fast_project_enabled(actual, "501")
    assert fast_project_enabled(actual, "301")


@pytest.mark.parametrize("target_scope", [[], ["COL_0", "COL_0"], ["FOREIGN"]])
def test_global_scope_retains_target_scope_validation(clean_fast_environment, target_scope):
    from fastapi import HTTPException
    from tests.unit.core.test_auto_mapping_proxy import _request
    proxy = AutoMappingProxyClient(settings(AUTOMAP_FAST_PATH_V1=True, AUTOMAP_FAST_PROJECT_IDS="*"))
    request = _request(2)
    request.context.project_id = "301"
    request.meta = {"auto_map_resolution_mode": "reeval_all", "auto_map_target_scope": target_scope}
    with pytest.raises(HTTPException) as error:
        proxy._accept_resolution(request)
    assert error.value.status_code == 422


def test_global_scope_does_not_waive_worker_handoff_or_change_legacy_route(clean_fast_environment):
    from app.core.automap_batch import validate_fast_request
    from tests.unit.core.test_auto_mapping_proxy import _request
    actual = settings(AUTOMAP_FAST_PATH_V1=True, AUTOMAP_FAST_PROJECT_IDS="*")
    proxy = AutoMappingProxyClient(actual)
    request = _request(1)
    request.context.project_id = "301"
    request.meta = {"auto_map_fast_path": "v1"}
    assert "auto_map_fast_path" not in proxy._accept_resolution(request).meta
    request.meta["auto_map_resolution_mode"] = "reeval_all"
    accepted = proxy._accept_resolution(request)
    assert accepted.meta["auto_map_fast_path"] == "v1"
    with pytest.raises(ValueError):
        validate_fast_request(accepted, actual)


def test_enabled_common_engine_does_not_require_project_rollout_list(clean_fast_environment):
    from app.core.automap_batch import fast_project_enabled
    actual=settings(AUTOMAP_FAST_PATH_V1=True)
    assert fast_project_enabled(actual,'501')
    assert fast_project_enabled(actual,'999999')


def test_fast_environment_settings_and_revision_read_receipt(clean_fast_environment, monkeypatch):
    monkeypatch.setenv("AUTOMAP_FAST_PATH_V1", "true")
    monkeypatch.setenv("AUTOMAP_FAST_PROJECT_IDS", "501")
    monkeypatch.setenv("AUTOMAP_FAST_CANARY_REVISION", "uat-fast-501-v1")
    actual = settings()
    assert actual.automap_fast_path_v1 is True
    assert actual.automap_fast_project_ids == "501"
    assert actual.automap_fast_canary_revision == "uat-fast-501-v1"
    assert actual.automap_parallel_pool_capacity == 2
    assert not actual.snowflake_write_lease_pool_v1


@pytest.mark.parametrize("enabled", [False, True])
@pytest.mark.parametrize("project", ["501", "1501", "5010", "0501", "502", "", None])
@pytest.mark.parametrize("opt_in", [False, True])
def test_real_proxy_uses_the_same_enabled_engine_for_every_valid_project(
        clean_fast_environment, enabled, project, opt_in):
    from tests.unit.core.test_auto_mapping_proxy import _request
    actual = settings(AUTOMAP_FAST_PATH_V1=enabled, AUTOMAP_FAST_PROJECT_IDS="501")
    request = _request(1)
    request.context.project_id = project
    request.meta = {"auto_map_fast_path": "v1", "_automap_acceptance": {"forged": True}}
    if opt_in:
        request.meta["auto_map_resolution_mode"] = "preserve_and_complete"
    before = request.model_dump(mode="json")
    accepted = AutoMappingProxyClient(actual)._accept_resolution(request)
    if enabled and project in {"501", "1501", "5010", "502"} and opt_in:
        assert accepted.meta["auto_map_fast_path"] == "v1"
        assert accepted.meta["auto_map_resolution_mode"] == "preserve_and_complete"
        assert "forged" not in accepted.meta["_automap_acceptance"]
    else:
        assert "auto_map_fast_path" not in accepted.meta
        assert "_automap_acceptance" not in accepted.meta
    assert request.model_dump(mode="json") == before


@pytest.mark.parametrize("initial_projects", ["501", "*"])
@pytest.mark.parametrize("enabled,projects", [(False, "501"), (False, "*"), (False, "")])
def test_fast_flag_rollback_blocks_already_frozen_plan(clean_fast_environment, enabled, projects, initial_projects):
    from app.core.automap_batch import validate_fast_request
    from app.core.exceptions import SnowflakeAgentError
    from tests.unit.core.test_auto_mapping_proxy import _request
    proxy = AutoMappingProxyClient(settings(AUTOMAP_FAST_PATH_V1=True, AUTOMAP_FAST_PROJECT_IDS=initial_projects))
    request = _request(1)
    request.context.project_id = "501"
    request.meta = {"auto_map_resolution_mode": "preserve_and_complete"}
    frozen = proxy._freeze_resolution(request)
    assert proxy._trusted_resolution_plan(frozen)
    stored = STTMBuilderEnvelopeRequest.model_validate_json(frozen.model_dump_json())
    assert proxy._trusted_resolution_plan(proxy._restore_resolution(stored))
    proxy._settings = settings(AUTOMAP_FAST_PATH_V1=enabled, AUTOMAP_FAST_PROJECT_IDS=projects)
    with pytest.raises(SnowflakeAgentError, match="no longer enabled"):
        proxy._trusted_resolution_plan(frozen)
    with pytest.raises(SnowflakeAgentError, match="no longer enabled"):
        proxy._restore_resolution(stored)
    with pytest.raises(ValueError, match="not enabled for this project"):
        validate_fast_request(frozen, proxy._settings)


def test_proxy_merges_metadata_only_warnings_as_independent_typed_copies(monkeypatch):
    from tests.unit.core.test_auto_mapping_proxy import _request, _response
    proxy = AutoMappingProxyClient(settings())
    request = _request(4)
    originals = []

    def worker(req, **kwargs):
        response = _response(req)
        warning = {"code": "scan_incomplete", "message": "Partial table coverage", "field": req.data.attributes[0].target_attribute}
        response.meta["auto_map_retrieval"] = {"warnings": [warning],
            "parallel_preparation": {"warnings": [warning]}}
        originals.append((response, deepcopy(response.model_dump(mode="json"))))
        return response

    monkeypatch.setattr(proxy, "_invoke_batch", worker)
    response = proxy._invoke_with_headers(request, headers={})
    assert len(originals) == 4 and len(response.warnings) == 4
    assert {warning.field for warning in response.warnings} == {f"COL_{index}" for index in range(4)}
    assert response.meta["assistant_context"]["warnings"] == [warning.model_dump(mode="json") for warning in response.warnings]
    response.warnings[0].message = "Changed only in merged response"
    for original, before in originals:
        assert original.model_dump(mode="json") == before


def test_worker_request_warnings_are_copied_and_assistant_matches(monkeypatch):
    builder, _ = isolated_worker(monkeypatch)
    request = STTMBuilderEnvelopeRequest.model_validate(request_payload())
    request.warnings = [ApiWarning(code="request_warning", message="Preserve caller warning")]
    response = builder.invoke(request, governance_decision=SimpleNamespace())
    assert response.meta["assistant_context"]["warnings"] == [warning.model_dump(mode="json") for warning in response.warnings]
    next(warning for warning in response.warnings if warning.code == "request_warning").message = "Changed"
    assert request.warnings[0].message == "Preserve caller warning"


def test_child_response_merge_preserves_warning_copies():
    from tests.unit.core.test_auto_mapping_proxy import _request, _response
    first, second = _response(_request(1)), _response(_request(2))
    second.meta["auto_map_retrieval"] = {"parallel_preparation": {"warnings": [
        {"code": "scan_incomplete", "message": "Partial coverage"}]}}
    merged = AutoMappingProxyClient._merge_batch_responses(first, second)
    assert merged.warnings[0].code == "scan_incomplete"
    assert merged.meta["assistant_context"]["warnings"][0]["code"] == "scan_incomplete"
    assert not first.warnings and not second.warnings
