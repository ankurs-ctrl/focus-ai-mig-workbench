from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import subprocess
import time
import zipfile
from pathlib import PurePath
from typing import Any
from uuid import uuid4
from xml.etree import ElementTree

import openpyxl
from PIL import Image, UnidentifiedImageError
from pypdf import PdfReader

from app.agent_runs.attachment_ocr import MAX_OCR_PAGES, recognize_image, recognize_pdf_page
from app.agent_runs.models import AgentAttachment
from app.core.sql_parser import parse_sql_document


MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024
MAX_OOXML_EXPANDED_BYTES = 80 * 1024 * 1024
IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
               ".tif": "image/tiff", ".tiff": "image/tiff"}
SUPPORTED_EXTENSIONS = {
    ".sql",
    ".xlsx",
    ".xls",
    *IMAGE_TYPES,
    ".csv",
    ".txt",
    ".md",
    ".json",
    ".yaml",
    ".yml",
    ".docx",
    ".pdf",
    ".srt",
    ".vtt",
}
MIME_BY_EXTENSION = {
    **IMAGE_TYPES,
    ".xls": "application/vnd.ms-excel",
    ".sql": "application/sql",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".csv": "text/csv",
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".json": "application/json",
    ".yaml": "application/yaml",
    ".yml": "application/yaml",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".pdf": "application/pdf",
    ".srt": "application/x-subrip",
    ".vtt": "text/vtt",
}
PROMPT_INJECTION_PATTERNS = (
    re.compile(r"ignore\s+(all\s+)?(previous|prior|system)\s+instructions", re.I),
    re.compile(r"(system|developer)\s*prompt", re.I),
    re.compile(r"you\s+are\s+(now|an?)", re.I),
    re.compile(r"execute\s+(this|the)\s+(script|command|sql)", re.I),
)


class AttachmentValidationError(ValueError):
    pass


def detect_mime(filename: str, content: bytes) -> tuple[str, str]:
    extension = PurePath(filename).suffix.lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise AttachmentValidationError(
            f"Unsupported attachment type {extension or '<none>'}. "
            f"Supported types: {', '.join(sorted(SUPPORTED_EXTENSIONS))}."
        )
    if extension in {".xlsx", ".docx"}:
        if not content.startswith(b"PK"):
            raise AttachmentValidationError("The file extension does not match an OOXML document")
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                entries = archive.infolist()
                if len(entries) > 5_000 or sum(entry.file_size for entry in entries) > MAX_OOXML_EXPANDED_BYTES:
                    raise AttachmentValidationError("The workbook or document exceeds the expanded archive limit")
                names = {entry.filename for entry in entries}
            required = "xl/workbook.xml" if extension == ".xlsx" else "word/document.xml"
            if required not in names:
                raise AttachmentValidationError("The file contents do not match the declared OOXML type")
        except zipfile.BadZipFile as exc:
            raise AttachmentValidationError("The OOXML attachment is not a valid ZIP container") from exc
    elif extension == ".pdf" and not content.startswith(b"%PDF-"):
        raise AttachmentValidationError("The file contents do not match a PDF document")
    elif extension == ".xls":
        if not content.startswith(bytes.fromhex("d0cf11e0a1b11ae1")):
            raise AttachmentValidationError("The file contents do not match a legacy Excel workbook. Open the original and convert it to .xlsx.")
    elif extension not in {".pdf", *IMAGE_TYPES} and b"\x00" in content[:4096]:
        raise AttachmentValidationError("Binary content is not allowed for this attachment type")
    return extension, MIME_BY_EXTENSION[extension]


def prompt_injection_indicators(text: str) -> list[str]:
    return [pattern.pattern for pattern in PROMPT_INJECTION_PATTERNS if pattern.search(text)]


def _parse_docx(content: bytes) -> dict[str, Any]:
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        root = ElementTree.fromstring(archive.read("word/document.xml"))
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    prefix = "{" + ns["w"] + "}"
    body = root.find("w:body", ns)
    if body is None:
        raise AttachmentValidationError("The Word document has no readable body")

    def text(node):
        return "".join(item.text or "" for item in node.findall(".//w:t", ns)).strip()

    sections = []
    heading = "Document"
    table_number = 0
    for node in body:
        if node.tag == prefix + "p":
            paragraph = text(node)
            if not paragraph:
                continue
            style = node.find("w:pPr/w:pStyle", ns)
            if style is not None and style.get(prefix + "val", "").lower().startswith(("heading", "title")):
                heading = paragraph[:200]
            sections.append({"section": f"{heading}, paragraph {len(sections) + 1}", "text": paragraph})
        elif node.tag == prefix + "tbl":
            table_number += 1
            for index, row in enumerate(node.findall("w:tr", ns), start=1):
                cells = [text(cell) for cell in row.findall("w:tc", ns)]
                if any(cells):
                    sections.append({"section": f"{heading}, table {table_number}, row {index}", "text": " | ".join(cells)})
    result = []
    remaining = 500_000
    for section in sections:
        if len(section["text"]) > remaining or len(result) >= 10_000:
            break
        result.append(section)
        remaining -= len(section["text"])
    if not result:
        raise AttachmentValidationError("The Word document contains no extractable text within the parsing limit")
    return {"document_text": "\n".join(section["text"] for section in result), "sections": result,
            "warnings": ["Document extraction reached its limit"] if len(result) < len(sections) else []}


def _parse_pdf(content: bytes) -> dict[str, Any]:
    try:
        reader = PdfReader(io.BytesIO(content), strict=False)
        if reader.is_encrypted:
            raise AttachmentValidationError("Encrypted PDFs must be decrypted before upload")
        if len(reader.pages) > 250:
            raise AttachmentValidationError("PDF exceeds the 250-page parsing limit")
        pages = []
        omitted_pages = []
        attempted_ocr = 0
        deadline = time.monotonic() + 25
        for number, page in enumerate(reader.pages, start=1):
            try:
                text = (page.extract_text() or "").strip()
            except Exception:
                text = ""
            if not text and attempted_ocr < MAX_OCR_PAGES and time.monotonic() < deadline:
                attempted_ocr += 1
                try:
                    text = recognize_pdf_page(content, number, deadline - time.monotonic())
                except (OSError, ValueError, subprocess.SubprocessError):
                    text = ""
            if not text:
                omitted_pages.append(number)
            else:
                pages.append(f"[page {number}]\n{text}")
            if sum(map(len, pages)) >= 500_000:
                omitted_pages.extend(range(number + 1, len(reader.pages) + 1))
                break
        if not pages:
            raise AttachmentValidationError("This PDF has no extractable text. Upload a readable scan or a text version.")
        document_text = "\n".join(pages)
        warnings = [f"No text extracted or limit reached on pages: {', '.join(map(str, omitted_pages))}"] if omitted_pages else []
        if len(document_text) > 500_000:
            warnings.append("Text extraction reached its character limit")
        return {"document_text": document_text[:500_000], "warnings": warnings}
    except AttachmentValidationError:
        raise
    except Exception as exc:
        raise AttachmentValidationError("The PDF could not be parsed as text") from exc


def _parse_xlsx(content: bytes) -> dict[str, Any]:
    formulas = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=False, keep_links=False)
    try:
        cached = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True, keep_links=False)
        try:
            sheets = []
            warnings = []
            remaining_rows = 10_000
            for sheet in formulas.worksheets[:20]:
                rows = []
                formula_cells = {}
                cached_sheet = cached[sheet.title]
                formula_rows = sheet.iter_rows(max_col=min(sheet.max_column or 100, 100))
                cached_rows = cached_sheet.iter_rows(max_col=min(sheet.max_column or 100, 100), values_only=True)
                for row_index, (row, cached_values) in enumerate(zip(formula_rows, cached_rows), start=1):
                    if remaining_rows == 0:
                        break
                    values = []
                    for column, (cell, cached_value) in enumerate(zip(row, cached_values), start=1):
                        value = cell.value
                        if cell.data_type == "f":
                            coordinate = f"{openpyxl.utils.get_column_letter(column)}{row_index}"
                            formula_cells[coordinate] = {"formula": str(value), "cached_value": cached_value}
                            value = cached_value if cached_value is not None else value
                        values.append(value if value is not None else "")
                    rows.append(values)
                    remaining_rows -= 1
                if (sheet.max_column or 0) > 100 or remaining_rows == 0:
                    warnings.append(f"Extraction limit reached in sheet {sheet.title}")
                sheets.append({"name": sheet.title, "rows": rows, "formula_cells": formula_cells})
                if remaining_rows == 0:
                    break
            if len(formulas.worksheets) > 20:
                warnings.append("Only the first 20 sheets were extracted")
            return {"sheets": sheets, "warnings": warnings}
        finally:
            cached.close()
    finally:
        formulas.close()


def _parse_xls(content: bytes) -> dict[str, Any]:
    import xlrd

    workbook = xlrd.open_workbook(file_contents=content, on_demand=True)
    try:
        sheets = []
        warnings = ["Legacy Excel exposes saved cell values. Formula text may be unavailable."]
        remaining_rows = 10_000
        for index in range(min(workbook.nsheets, 20)):
            sheet = workbook.sheet_by_index(index)
            count = min(sheet.nrows, remaining_rows)
            rows = [sheet.row_values(row, 0, min(100, sheet.ncols)) for row in range(count)]
            sheets.append({"name": sheet.name, "rows": rows})
            remaining_rows -= count
            if count < sheet.nrows or sheet.ncols > 100:
                warnings.append(f"Extraction limit reached in sheet {sheet.name}")
            if not remaining_rows:
                break
        if len(sheets) < workbook.nsheets:
            warnings.append("Some sheets were outside the extraction limit")
        return {"sheets": sheets, "warnings": warnings}
    finally:
        workbook.release_resources()


def _parse_csv(content: bytes) -> dict[str, Any]:
    text = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    rows = [dict(row) for _, row in zip(range(10_000), reader, strict=False)]
    return {"columns": reader.fieldnames or [], "mapping_rows": rows}


def parse_attachment(filename: str, content: bytes) -> tuple[str, str, dict[str, Any], list[str]]:
    extension, mime = detect_mime(filename, content)
    text_for_scan = ""
    if extension == ".sql":
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        # The raw text is kept with its lineage so the agent can quote and
        # reuse the statements, not just the parsed structure.
        parsed = {"sql_text": text_for_scan[:500_000], **parse_sql_document(text_for_scan).to_dict()}
    elif extension in {".xlsx", ".xls"}:
        try:
            parsed = _parse_xlsx(content) if extension == ".xlsx" else _parse_xls(content)
        except Exception as exc:
            raise AttachmentValidationError("Excel could not be read. Open the file and save an unencrypted copy.") from exc
        text_for_scan = json.dumps(parsed, default=str)
    elif extension in IMAGE_TYPES:
        try:
            text_for_scan, omitted = recognize_image(content, extension)
        except (OSError, ValueError, UnidentifiedImageError, Image.DecompressionBombError, subprocess.SubprocessError) as exc:
            raise AttachmentValidationError("OCR could not read this scan. Upload a readable PDF or text version.") from exc
        if not text_for_scan:
            raise AttachmentValidationError("The scan contains no readable text")
        parsed = {"document_text": text_for_scan[:500_000], "extraction": "ocr",
                  "warnings": [f"OCR could not read or skipped image pages {omitted}."] if omitted else []}
    elif extension == ".csv":
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        parsed = _parse_csv(content)
    elif extension == ".json":
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        try:
            parsed = {"json": json.loads(text_for_scan)}
        except (ValueError, RecursionError) as exc:
            raise AttachmentValidationError("The JSON file is malformed") from exc
    elif extension in {".yaml", ".yml", ".txt", ".md", ".srt", ".vtt"}:
        text_for_scan = content.decode("utf-8-sig", errors="replace")
        parsed = {"document_text": text_for_scan[:500_000]}
    elif extension == ".docx":
        try:
            parsed = _parse_docx(content)
        except (ElementTree.ParseError, zipfile.BadZipFile, KeyError) as exc:
            raise AttachmentValidationError("The Word document is malformed") from exc
        text_for_scan = str(parsed.get("document_text") or "")
    elif extension == ".pdf":
        parsed = _parse_pdf(content)
        text_for_scan = str(parsed.get("document_text") or "")
    else:  # pragma: no cover - guarded by detect_mime
        raise AttachmentValidationError("Unsupported attachment type")
    indicators = prompt_injection_indicators(text_for_scan)
    manifest = {
        "parser_version": "3.0",
        "status": "partial" if parsed.get("warnings") or parsed.get("parse_warnings") else "ready",
        "warnings": parsed.get("warnings") or parsed.get("parse_warnings") or [],
        "content_is_untrusted_evidence": True,
        "atomized": parsed,
        "prompt_injection_detected": bool(indicators),
    }
    return extension, mime, manifest, indicators


class AttachmentService:
    """Validate, parse without execution, and persist immutable attachment metadata."""

    def __init__(self, session: Any, *, stage_prefix: str = "@WORKBENCH_AGENT_ATTACHMENTS") -> None:
        self._session = session
        self._stage_prefix = stage_prefix.rstrip("/")

    def ingest(
        self,
        *,
        filename: str,
        content: bytes,
        owner_user_id: str,
        tenant_id: str = "default",
    ) -> AgentAttachment:
        if not filename or PurePath(filename).name != filename:
            raise AttachmentValidationError("Attachment filename must not contain a path")
        if not content:
            raise AttachmentValidationError("Attachment is empty")
        if len(content) > MAX_ATTACHMENT_BYTES:
            raise AttachmentValidationError(
                f"Attachment exceeds the {MAX_ATTACHMENT_BYTES // (1024 * 1024)} MB limit"
            )
        extension, mime = detect_mime(filename, content)
        digest = hashlib.sha256(content).hexdigest()
        existing_rows = self._session.sql(
            """SELECT ATTACHMENT_PAYLOAD FROM TBL_AGENT_ATTACHMENTS
            WHERE TENANT_ID = ? AND OWNER_USER_ID = ? AND CONTENT_HASH = ? ORDER BY CREATED_AT DESC LIMIT 1""",
            [tenant_id, owner_user_id, digest],
        ).collect()
        if existing_rows:
            row = existing_rows[0].as_dict() if hasattr(existing_rows[0], "as_dict") else dict(existing_rows[0])
            payload = row.get("ATTACHMENT_PAYLOAD") or {}
            if isinstance(payload, str):
                payload = json.loads(payload)
            existing = AgentAttachment.model_validate(payload)
            if existing.parsed_manifest.get("parser_version") == "3.0":
                return existing
        _, _, manifest, indicators = parse_attachment(filename, content)
        attachment_id = f"att_{uuid4().hex}"
        safe_tenant = re.sub(r"[^A-Za-z0-9_-]", "_", tenant_id)[:128] or "default"
        immutable_uri = f"{self._stage_prefix}/{safe_tenant}/{digest}/{digest}{extension}"
        # Snowpark file.put_stream performs an immutable content-addressed write;
        # overwrite is disabled so a replay cannot replace original evidence.
        file_api = getattr(self._session, "file", None)
        if file_api is not None and hasattr(file_api, "put_stream"):
            file_api.put_stream(io.BytesIO(content), immutable_uri, overwrite=False, auto_compress=False)
        attachment = AgentAttachment(
            attachment_id=attachment_id,
            owner_user_id=owner_user_id,
            tenant_id=tenant_id,
            filename=filename,
            extension=extension,
            detected_mime=mime,
            size_bytes=len(content),
            content_hash=digest,
            immutable_uri=immutable_uri,
            scan_status="clean",
            parser_status="parsed",
            prompt_injection_indicators=indicators,
            parsed_manifest=manifest,
        )
        self._session.sql(
            """
            INSERT INTO TBL_AGENT_ATTACHMENTS
                (ATTACHMENT_ID, OWNER_USER_ID, TENANT_ID, CONTENT_HASH, IMMUTABLE_URI,
                 FILENAME, DETECTED_MIME, SIZE_BYTES, SCAN_STATUS, PARSER_STATUS,
                 ATTACHMENT_PAYLOAD, CREATED_AT, UPDATED_AT)
            SELECT ?,?,?,?,?,?,?,?,?,?,PARSE_JSON(?),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP()
            """,
            [
                attachment.attachment_id, attachment.owner_user_id, attachment.tenant_id,
                attachment.content_hash, attachment.immutable_uri, attachment.filename,
                attachment.detected_mime, attachment.size_bytes, attachment.scan_status,
                attachment.parser_status, json.dumps(attachment.model_dump(mode="json"), default=str),
            ],
        ).collect()
        return attachment
