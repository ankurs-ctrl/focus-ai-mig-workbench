const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),ts=require('typescript'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../src/features/ai-agent');
const parse=file=>ts.createSourceFile(file,fs.readFileSync(path.join(root,file),'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
function find(tree,predicate){let found;function walk(n){if(predicate(n))found=n;ts.forEachChild(n,walk)}walk(tree);assert.ok(found);return found}
const compile=(source,context)=>(context.exports={},vm.runInNewContext(ts.transpileModule('('+source+')',{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText,context));
test('late local inventory cannot erase server-only conversations',()=>{
 const tree=parse('AiAgentPage.tsx');const declaration=find(tree,n=>ts.isVariableDeclaration(n)&&n.name.getText(tree)==='sessionsByProjectId');
 const server={id:'server',backendConversationId:'conversation',projectId:null,updatedAt:2,title:'Native draft'};
 const context={sessions:[server],storedSessionsByProjectId:{general:[]},GENERAL_PROJECT_VALUE:'general'};
 const group=()=>compile(declaration.initializer.arguments[0].getText(tree),{...context})();
 assert.equal(group().general[0],server);
 context.storedSessionsByProjectId={general:[],another:[]};assert.equal(group().general[0],server);
 context.sessions=[];assert.equal(group().general,undefined);
});
test('restored message renders all content after a partial animation',()=>{
 const tree=parse('deep-agent-panel.tsx');const declaration=find(tree,n=>ts.isFunctionDeclaration(n)&&n.name?.text==='TypewriterMessageContent');
 const component=compile(declaration.getText(tree),{useState:()=>[3,()=>{}],useEffect:()=>{},MessageContent:'MessageContent',require:()=>({jsx:(type,props)=>({type,props})})});
 const content='Complete restored explanation with SQL and conclusions.';
 assert.equal(component({content,animate:false,messageId:'id'}).props.content,content);
 assert.equal(component({content,animate:true,messageId:'id'}).props.content,'Com▌');
});
test('automatic parent-route tour cannot redirect the resources page',()=>{
 const file=path.resolve(root,'../tour/engine/tour-context.tsx');const tree=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 const declaration=find(tree,n=>ts.isVariableDeclaration(n)&&n.name.getText(tree)==='startTour');let actions=[];
 const start=compile(declaration.initializer.arguments[0].getText(tree),{hasSeenTour:()=>false,getTourById:()=>({id:'admin',steps:[{route:'/administration/user-management'}]}),
  pathname:'/administration/resources',localizeTourRoute:r=>r,isSamePath:(a,b)=>a===b,router:{},setActiveTour:()=>actions.push('open'),setStepIndex:()=>{},setIsOpen:()=>{},markTourSeen:()=>actions.push('seen'),navigateToStepRoute:()=>actions.push('navigate')});
 start('admin',{autoLaunch:true});assert.deepEqual(actions,[]);
 start('admin');assert.deepEqual(actions,['open','navigate']);
});
test('technical findings never become free-text questions, including saved legacy findings',()=>{
 const tree=parse('agent-review-list.tsx');const declaration=find(tree,n=>ts.isFunctionDeclaration(n)&&n.name?.text==='ReviewCard');
 const component=compile(declaration.getText(tree),{useState:v=>[v,()=>{}],AiaBox:'Box',AiaText:'Text',AiaStack:'Stack',AiaInput:'Input',AiaButton:'Button',require:()=>({jsx:(type,props)=>({type,props}),jsxs:(type,props)=>({type,props})})});
 const node=component({item:{id:'old',category:'mapping_plan_incomplete',summary:'The plan needs at least one in-scope mapping candidate. Set allow_partial_coverage to present the remaining columns explicitly for review.',question:'',choices:[],allowFreeText:true},busy:false,onAnswer:()=>{throw Error('A finding cannot submit an answer')}});
 assert.doesNotMatch(JSON.stringify(node),/"Input"|Type your answer|allow_partial_coverage/);
 assert.match(JSON.stringify(node),/No answer is required/);
});
test('a real question ends with Other and sends it as a plan revision request',()=>{
 const tree=parse('agent-review-list.tsx');const declaration=find(tree,n=>ts.isFunctionDeclaration(n)&&n.name?.text==='ReviewCard');let state=0,answer;
 const component=compile(declaration.getText(tree),{useState:()=>[++state===1?'Use current effective rows':'__other__',()=>{}],AiaBox:'Box',AiaText:'Text',AiaStack:'Stack',AiaInput:'Input',AiaButton:'Button',require:()=>({jsx:(type,props)=>({type,props}),jsxs:(type,props)=>({type,props})})});
 const node=component({item:{id:'question',category:'confidence_gate',summary:'Both current and history contracts are available.',question:'Which population should this target use?',choices:[{id:'current',label:'Current effective rows',description:'One current record per customer.'},{id:'history',label:'All historical versions',description:'Preserves each effective version.'}],recommendedChoiceId:'current',allowFreeText:false},busy:false,onAnswer:(...args)=>{answer=args}});
 const nodes=[];function visit(v){if(!v||typeof v!=='object')return;if(Array.isArray(v))return v.forEach(visit);nodes.push(v);visit(v.props?.children)}visit(node);
 const radios=nodes.filter(n=>n.props?.role==='radio');assert.equal(radios.length,3);
 assert.match(JSON.stringify(radios[2]),/Other/);
 const apply=nodes.find(n=>n.type==='Button'&&typeof n.props.onClick==='function');apply.props.onClick();
 assert.deepEqual(answer,['question','__other__','Use current effective rows']);
});
