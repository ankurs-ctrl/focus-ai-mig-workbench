import { joinConnectorPayload } from "@/features/sttm/source-target/join-predicate";

export type ScopedJoin = {
  structured?: {
    left_relation_id: string;
    right_relation_id: string;
    conditions: Array<{ left_column: string; operator: string; right_column: string; connector?: "AND" | "OR" }>;
  } | null;
};

/** Only the backend's complete scope-bound AST result can enable pair editing. */
export function scopedJoinEditing(join: ScopedJoin, leftInstance: string, rightInstance: string, predicate: string): {
  conditions: Array<{ id: string; leftColumn: string; operator: string; rightColumn: string; connector?: "AND" | "OR" }>;
  sqlPredicate?: string;
} {
  const structured = join.structured;
  if (!structured || structured.left_relation_id !== leftInstance || structured.right_relation_id !== rightInstance || !structured.conditions.length) {
    return { conditions: [], sqlPredicate: predicate };
  }
  return { conditions: structured.conditions.map((condition, index) => ({
    id: `condition-${index}`,
    leftColumn: condition.left_column, operator: condition.operator, rightColumn: condition.right_column,
    ...joinConnectorPayload(condition.connector),
  })) };
}