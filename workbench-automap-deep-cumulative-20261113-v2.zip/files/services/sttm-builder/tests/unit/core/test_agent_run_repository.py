from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from app.agent_runs.repository import SnowflakeAgentRunRepository
from app.agent_runs.models import AgentRunEvent, EffortPolicy


class _Query:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    def collect(self) -> list[dict[str, Any]]:
        return self._rows


class _Session:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    def sql(self, _query: str, _params: list[Any]) -> _Query:
        return _Query(self._rows)


def test_terminal_outbox_recovery_is_bounded_and_excludes_active_leases():
    calls = []
    class Session:
        def sql(self, query, params):
            calls.append((query, params))
            return _Query([{'RUN_ID': 'failed-run'}] if query.lstrip().startswith('SELECT') else [])
    repository = SnowflakeAgentRunRepository(Session())
    assert repository.recover_terminal_command_outboxes(3) == 1
    query, params = calls[0]
    assert 'LEASE_EXPIRES_AT<CURRENT_TIMESTAMP()' in query
    assert 'NOT COALESCE(c.EVENT_PUBLISHED,FALSE)' in query
    assert params == [3]
    assert calls[1][1] == ['failed-run']


def test_legacy_effort_policy_hydrates_partitioned_budgets() -> None:
    policy = EffortPolicy.model_validate(
        {
            "effort": "medium",
            "reasoning_effort": "medium",
            "planning_depth": 2,
            "retrieval_card_limit": 20,
            "retrieval_token_budget": 6000,
            "profile_row_limit": 100,
            "specialist_retries": 2,
            "relationship_alternatives": 2,
            "preview_row_limit": 100,
            "validation_depth": "preview",
            "cross_mapping_checks": ["contract"],
            "model_call_budget": 30,
            "tool_call_budget": 120,
            "max_parallel_mappings": 2,
        }
    )

    assert policy.working_model_call_budget == 24
    assert policy.finalization_model_call_budget == 6
    assert policy.working_tool_call_budget == 100
    assert policy.finalization_tool_call_budget == 20


def test_list_events_decodes_snowflake_variant_json_strings() -> None:
    created_at = datetime.now(UTC)
    repository = SnowflakeAgentRunRepository(
        _Session(
            [
                {
                    "EVENT_ID": "event-1",
                    "RUN_ID": "run-1",
                    "EVENT_SEQ": 1,
                    "EVENT_TYPE": "trace.tool.completed",
                    "STATUS": "succeeded",
                    "SAFE_SUMMARY": "Read source metadata",
                    "PROJECT_ID": "project-1",
                    "STTM_ID": None,
                    "STEP_ID": "step-1",
                    "SUBJECT_KEYS": '["source.table"]',
                    "ARTIFACT_REFS": '["artifact-1"]',
                    "EVENT_DATA": '{"tool":"read_metadata","row_count":3}',
                    "CREATED_AT": created_at,
                }
            ]
        )
    )

    events = repository.list_events("run-1")

    assert len(events) == 1
    assert events[0].subject_keys == ["source.table"]
    assert events[0].artifact_refs == ["artifact-1"]
    assert events[0].data == {"tool": "read_metadata", "row_count": 3}
    assert events[0].created_at == created_at


def test_list_events_ignores_non_mapping_event_data() -> None:
    repository = SnowflakeAgentRunRepository(
        _Session(
            [
                {
                    "EVENT_ID": "event-2",
                    "RUN_ID": "run-1",
                    "EVENT_SEQ": 2,
                    "EVENT_TYPE": "assistant.status",
                    "STATUS": "running",
                    "SAFE_SUMMARY": "Working",
                    "SUBJECT_KEYS": None,
                    "ARTIFACT_REFS": None,
                    "EVENT_DATA": '"legacy text payload"',
                }
            ]
        )
    )

    event = repository.list_events("run-1")[0]

    assert event.subject_keys == []
    assert event.artifact_refs == []
    assert event.data == {}


class _BatchSession:
    def __init__(self) -> None:
        self.calls: list[tuple[str, list[Any]]] = []

    def sql(self, query: str, params: list[Any] | None = None) -> _Query:
        parameters = params or []
        self.calls.append((query, parameters))
        if query.lstrip().startswith("CALL"):
            return _Query([{"SP_APPEND_AGENT_RUN_EVENTS": {"first_sequence": 11, "final_sequence": 12}}])
        return _Query([])


def test_append_events_reserves_one_ordered_cursor_batch() -> None:
    session = _BatchSession()
    repository = SnowflakeAgentRunRepository(session)
    events = [
        AgentRunEvent(
            event_id=f"event-{index}",
            run_id="run-1",
            event_type="tool.completed",
            status="succeeded",
            safe_summary=f"Completed {index}",
        )
        for index in (1, 2)
    ]

    stored = repository.append_events(events)

    assert [event.sequence for event in stored] == [11, 12]
    assert len(session.calls) == 1
    append_call = session.calls[0]
    assert append_call[0].lstrip().startswith("CALL")
    assert append_call[1][0] == "run-1"
    payload = json.loads(append_call[1][1])
    assert [item["event_id"] for item in payload] == ["event-1", "event-2"]


def test_acquire_lease_claims_candidate_without_preselect_round_trip() -> None:
    session = _BatchSession()
    repository = SnowflakeAgentRunRepository(session)

    assert repository.acquire_lease("worker-1", 120) is None

    assert len(session.calls) == 2
    claim_query, claim_params = session.calls[0]
    assert claim_query.lstrip().startswith("UPDATE")
    assert "SELECT candidate.RUN_ID" in claim_query
    assert claim_params == ["worker-1", 120]
    read_query, read_params = session.calls[1]
    assert read_query.lstrip().startswith("SELECT *")
    assert "LEASE_OWNER = ?" in read_query
    assert read_params == ["worker-1"]


def test_expired_writer_rolls_back_instead_of_publishing_receipt():
    import pytest
    from app.agent_runtime.execution import ExecutionLeaseLostError
    class Session:
        def __init__(self):self.calls=[]
        def sql(self,query,params=None):
            self.calls.append((query,params))
            return _Query([{'number of rows updated':0}])
    session=Session()
    repository=SnowflakeAgentRunRepository(session,lease_fence=('run','old-worker',7))
    with pytest.raises(ExecutionLeaseLostError):
        with repository.command_transaction():
            session.sql('domain write')
    assert session.calls[-1][0]=='ROLLBACK'
    assert not any(query=='COMMIT' for query,_ in session.calls)
    assert session.calls[-2][1]==['run','old-worker',7,False]


def test_stale_worker_step_is_rolled_back_and_nested_fence_has_one_transaction():
    import pytest
    from app.agent_runs.models import AgentRunStep
    from app.agent_runtime.execution import ExecutionLeaseLostError
    class Session:
        def __init__(self): self.calls=[]
        def sql(self, query, params=None):
            self.calls.append(query)
            return _Query([{'number of rows updated':0}])
    session=Session()
    repo=SnowflakeAgentRunRepository(session,lease_fence=('run','worker',1))
    with pytest.raises(ExecutionLeaseLostError):
        with repo.command_transaction():
            repo.save_step(AgentRunStep(run_id='run',step_id='step',node_name='test'))
    assert session.calls.count('BEGIN') == 1
    assert session.calls[-1] == 'ROLLBACK'
    assert 'COMMIT' not in session.calls


def test_worker_events_use_fenced_procedure_and_reject_lost_owner():
    import pytest
    from app.agent_runtime.execution import ExecutionLeaseLostError
    class Session:
        def sql(self, query, params):
            assert 'SP_APPEND_AGENT_RUN_EVENTS_FENCED' in query
            assert params[-2:] == ['worker',2]
            return _Query([{'RESULT': {'error':'worker_lease_lost'}}])
    repo=SnowflakeAgentRunRepository(Session(),lease_fence=('run','worker',2))
    with pytest.raises(ExecutionLeaseLostError):
        repo.append_event(AgentRunEvent(event_id='event',run_id='run',event_type='test',status='running',safe_summary='test'))


def test_snowflake_control_update_rejects_zero_row_compare_and_set():
    import pytest
    from app.agent_runs.models import AgentActor, RunCreateRequest
    from app.agent_runs.repository import InMemoryAgentRunRepository
    from app.agent_runs.service import AgentRunService, RunConflictError
    run = AgentRunService(InMemoryAgentRunRepository()).create_run(
        RunCreateRequest(prompt='Inspect evidence'), AgentActor(user_id='user',tenant_id='tenant',effective_role='role'))
    class Session:
        def sql(self, query, params):
            assert 'EQUAL_NULL(CANCEL_REQUESTED_AT,?)' in query
            assert 'COALESCE(LEASE_GENERATION,0)=?' in query
            assert params[-4:] == [run.status.value,run.run_revision,run.lease_generation,None]
            return _Query([{'updated':0}])
    with pytest.raises(RunConflictError,match='changed'):
        SnowflakeAgentRunRepository(Session()).save_run_if_current(run.model_copy(deep=True),run)
