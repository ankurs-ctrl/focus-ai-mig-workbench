from unittest.mock import MagicMock

from app.core.learning_retrieval import LearningRetrievalService


class _Row:
    def __init__(self, **values):
        self._values = values

    def as_dict(self):
        return self._values


class _Query:
    def __init__(self, rows):
        self._rows = rows

    def collect(self):
        return self._rows


def test_link_scope_is_directed_from_current_workspace_only() -> None:
    session = MagicMock()

    def run(query: str):
        if "TBL_FIR_PROJECT_LINKS" in query:
            assert "PROJECT_ID = 'current_project'" in query
            assert "PRECEDENT_PROJECT_ID = 'current_project'" not in query
            return _Query(
                [
                    _Row(
                        PRECEDENT_PROJECT_ID="precedent_project",
                        PRIORITY=90,
                        KNOWLEDGE_CATEGORIES=["relationships", "mappings"],
                        ALLOW_PROJECT_SPECIFIC_VALUES=False,
                    )
                ]
            )
        assert "STTM_ID = 'current_mapping'" in query
        assert "PRECEDENT_STTM_ID = 'current_mapping'" not in query
        return _Query(
            [
                _Row(
                    PRECEDENT_STTM_ID="precedent_mapping",
                    PRIORITY=95,
                    KNOWLEDGE_CATEGORIES=["transformations"],
                    TARGET_COMPATIBILITY="same_role",
                    CONFIDENCE=0.92,
                    ALLOW_PROJECT_SPECIFIC_VALUES=False,
                )
            ]
        )

    session.sql.side_effect = run
    settings = MagicMock()
    settings.qualify_metadata_object_name.side_effect = lambda name: f"DB.META.{name}"
    service = LearningRetrievalService(session, settings)

    scope = service._get_link_scope(
        project_id="current_project",
        sttm_id="current_mapping",
    )

    assert scope["project_ids"] == ["precedent_project"]
    assert scope["sttm_ids"] == ["precedent_mapping"]
    assert [item["retrieval_mode"] for item in scope["explanations"]] == [
        "linked_project",
        "linked_mapping",
    ]

