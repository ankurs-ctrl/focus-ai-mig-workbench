"""Offline production-factory integration: real lease/admission/HTTP adapters.

Only Snowflake sessions and the HTTP wire are mocked. No credentials, sockets,
Snowflake DDL, or live model calls are used.
"""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import replace
import hashlib
import json
from threading import Barrier, Lock, RLock
from concurrent.futures import ThreadPoolExecutor
import time
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest
import sqlglot

from app.core import automap_runtime as runtime
from app.core import snowflake
from app.core.automap_batch import ParallelRuntimeBundle
from app.core.automap_parallel import prepare_parallel
from app.core.automap_retrieval import AutoMapContext
from app.core.snowflake_agent import SnowflakeAgentClient
from app.core.sttm_builder import STTMBuilderService


HOST = "org-account.snowflakecomputing.com"
EPOCH = "12fcb8bb-d91e-491a-ae30-6cf934017462"
CALLER = runtime.RuntimeCaller("ALICE", "ALICE", "CALLER_ROLE", "ORG.ACCOUNT")


class Database:
    def __init__(self, capacity=2):
        self.lock = RLock()
        self.log = []
        self.blobs = {}
        self.slots = [{"SLOT_ID": index, "POOL_EPOCH": EPOCH, "STATE": "FREE",
                       "OWNER_TOKEN": None, "FENCE": 0} for index in range(1, capacity + 1)]
        self.claims = []
        self.requests_threads = []
        self.fail_sql = None
        self.insert_count = 1
        self.commit_failure = None
        self.fail_release_commit = False
        self.release_result = None


class Session:
    def __init__(self, database, caller=CALLER):
        self.database, self.caller = database, caller
        self.transaction = False
        self.pending = []
        self.before_slots = None
        self.release_pending = False
        self.closed = False
        self._workbench_search_context = {"host": HOST, "token": "caller-only-token", "role": caller.role}

    def close(self):
        assert not self.transaction
        self.closed = True

    def sql(self, query, params=None):
        assert not self.closed
        assert not query.lstrip().upper().startswith(("CREATE", "ALTER", "DROP", "GRANT"))

        def collect(*, statement_params=None):
            self.database.log.append((self, query, deepcopy(params), statement_params))
            if self.database.fail_sql and self.database.fail_sql in query:
                raise RuntimeError("PRIVATE_TOKEN_AND_PAYLOAD")
            if query.startswith("SELECT CURRENT_USER()"):
                return [{"NATIVE_USER": self.caller.native_user, "ROLE_NAME": self.caller.role,
                         "ACCOUNT_NAMESPACE": self.caller.account_namespace,
                         "TRANSACTION_ID": 1 if self.transaction else None}]
            if query.startswith("SELECT CURRENT_ROLE()"):
                return [(self.caller.role, "CONTROL_WH", "DB", "META")]
            if query.startswith("SELECT CURRENT_ORGANIZATION_NAME()"):
                return [{"ACCOUNT_NAMESPACE": self.caller.account_namespace,
                         "TRANSACTION_ID": 1 if self.transaction else None}]
            if query == "BEGIN TRANSACTION":
                self.database.lock.acquire()
                assert not self.transaction
                self.transaction = True
                self.before_slots = deepcopy(self.database.slots)
                return []
            if query in ("ROLLBACK", "COMMIT"):
                if self.transaction:
                    failure = self.database.commit_failure if query == "COMMIT" else None
                    if query == "COMMIT" and self.release_pending and self.database.fail_release_commit:
                        failure = "before"
                    if failure == "before":
                        raise RuntimeError("PRIVATE uncertain commit")
                    if query == "COMMIT":
                        for key, text in self.pending:
                            self.database.blobs.setdefault(key, []).append(text)
                    else:
                        self.database.slots[:] = self.before_slots
                    self.pending.clear()
                    self.transaction = False
                    self.database.lock.release()
                    if failure == "after":
                        raise RuntimeError("PRIVATE lost commit acknowledgement")
                return []
            if query.startswith("SELECT BODY"):
                return [{"BODY": text} for text in self.database.blobs.get(tuple(params), [])[:2]]
            if query.startswith("INSERT INTO"):
                self.pending.append((tuple(params[:4]), params[4]))
                return [{"number of rows inserted": self.database.insert_count}]
            if query.startswith(("SELECT STATE, RECONCILIATION_REF", "SELECT RECONCILIATION_REF")):
                assert query.count("?") == len(params) == 9
                assert "LIMIT 2" in query and "CURRENT_ACCOUNT_NAME()" in query
                return [deepcopy(slot) for slot in self.database.slots if owned_slot(slot, params)][:2]
            if query.startswith("SELECT SLOT_ID"):
                return deepcopy(self.database.slots)
            if query.startswith("UPDATE"):
                if "SET STATE = 'HELD'" in query:
                    owner, job, caller, generation, shard, _, account, epoch, slot_id, fence = params
                    slot = self.database.slots[slot_id - 1]
                    if slot["STATE"] != "FREE" or slot["FENCE"] != fence:
                        return [{"number of rows updated": 0}]
                    slot.update(STATE="HELD", OWNER_TOKEN=owner, FENCE=fence + 1,
                        ACCOUNT_NAMESPACE=account, JOB_ID=job, CALLER_ID=caller,
                        GENERATION=generation, SHARD_ID=shard, RECONCILIATION_REF=None)
                    self.database.claims.append((job, caller, generation, shard))
                else:
                    exact_reconcile = "AND STATE = ? AND RECONCILIATION_REF = ?" in query
                    owner_params = params[2:11] if exact_reconcile else params[-9:]
                    slot_id = owner_params[2]
                    slot = self.database.slots[slot_id - 1]
                    if (not owned_slot(slot, owner_params) or (exact_reconcile and (
                            slot["STATE"] != params[-2] or slot.get("RECONCILIATION_REF") != params[-1]))):
                        return [{"number of rows updated": 0}]
                    if "SET STATE = 'FREE'" in query:
                        self.release_pending = True
                        slot.update(STATE="FREE", OWNER_TOKEN=None, FENCE=slot["FENCE"] + 1,
                            COMPLETION=params[0], RECONCILIATION_REF=params[1])
                    elif "SET RECONCILIATION_REF" in query:
                        assert slot["STATE"] == "HELD"
                        slot["RECONCILIATION_REF"] = params[0]
                    elif "SET STATE = 'QUARANTINED'" in query:
                        slot["STATE"] = "QUARANTINED"
                    if exact_reconcile and self.database.release_result is not None:
                        return self.database.release_result
                return [{"number of rows updated": 1}]
            raise AssertionError(query)

        return SimpleNamespace(collect=collect)


def owned_slot(slot, params):
    keys = ("ACCOUNT_NAMESPACE", "POOL_EPOCH", "SLOT_ID", "OWNER_TOKEN", "FENCE",
            "JOB_ID", "CALLER_ID", "GENERATION", "SHARD_ID")
    return slot["STATE"] in ("HELD", "QUARANTINED") and all(
        slot.get(key) == value for key, value in zip(keys, params))


def settings(**changes):
    values = dict(automap_parallel_context_v1=True, automap_context_retrieval_v1=True,
        validate_parallel_automap=Mock(), resolved_metadata_database="DB", resolved_metadata_schema="META",
        automap_parallel_test_agent="DB.META.AGT_AUTOMAP_SCAN_DEV_TEST",
        automap_parallel_permit_table_fqn="DB.META.PERMITS",
        automap_parallel_archive_table_fqn="DB.META.ARCHIVE",
        automap_parallel_account_namespace="ORG.ACCOUNT", automap_parallel_pool_epoch=EPOCH,
        automap_parallel_pool_capacity=2, agent_outbound_message_max_chars=200_000,
        agent_outbound_message_max_bytes=200_000, uses_custom_oauth=True,
        snowflake_write_lease_pool_v1=True, local_dev_auth_enabled=False,
        rest_snowflake_host=HOST, resolved_snowflake_host=HOST, snowflake_account="ORG-ACCOUNT",
        snowflake_database="DB", snowflake_schema="META", snowflake_warehouse="CONTROL_WH",
        snowflake_control_warehouse="CONTROL_WH", warehouse_routing_v1=False)
    values.update(changes)
    return SimpleNamespace(**values)


def store_for(columns=20):
    columns = [{"name": f"COL_{index}", "data_type": "TEXT", "business_meaning": "Business identifier"}
               for index in range(columns)]
    return AutoMapContext({"operation": "sttm.auto_map", "context": {
        "owner_id": "FORGED", "target_table": {"database": "DB", "schema": "DATA", "table": "TARGET"},
        "relation_graph": {"nodes": [{"relation_id": "source", "kind": "CTE", "alias": "src",
            "output_columns": columns, "column_semantics": columns}], "edges": []},
        "workspace_context": {"driving_relation_id": "source"}},
        "data": {"attributes": [{"target_attribute": "TARGET_ID"}]}})


@pytest.fixture
def harness(monkeypatch):
    database = Database()
    clients = []
    lease_calls = []
    requests = []
    original_lease = snowflake.caller_write_lease
    snowflake.close_write_pools()
    monkeypatch.setattr(snowflake, "_oauth_user_cache_key", lambda *args: "offline-caller-pool")

    class Client:
        def __init__(self, **kwargs):
            assert kwargs["user_token"] == "caller-only-token"
            assert kwargs["role"] == CALLER.role
            self.session = Session(database)
            clients.append(self)

        def close(self):
            self.session.close()

    @contextmanager
    def lease(*args, **kwargs):
        lease_calls.append((args, kwargs))
        with original_lease(*args, **kwargs) as client:
            yield client

    def respond(request):
        assert request.headers["Authorization"] == "Bearer caller-only-token"
        assert request.url.host == HOST
        if request.url.path == "/api/v2/cortex/threads":
            assert request.method == "POST" and request.content == b"{}"
            with database.lock:
                database.requests_threads.append(request)
                thread_id = len(database.requests_threads)
            return httpx.Response(200, stream=httpx.ByteStream(json.dumps({"thread_id": thread_id}).encode()))
        requests.append(request)
        assert request.url.path.endswith("/agents/AGT_AUTOMAP_SCAN_DEV_TEST:run")
        outgoing = json.loads(request.content)
        assert set(outgoing) == {"messages", "stream", "thread_id", "parent_message_id"}
        assert outgoing["parent_message_id"] == 0
        assert any(slot["STATE"] == "HELD" and json.loads(slot.get("RECONCILIATION_REF") or "{}").get(
            "thread_id") == outgoing["thread_id"] for slot in database.slots)
        assert "models" not in outgoing
        body = json.loads(outgoing["messages"][0]["content"][0]["text"])
        if body["protocol"] == "automap_scan_context_v1":
            candidates = [{"record_id": record["record_id"], "role": "source",
                           "evidence_refs": [record["record_id"]]}
                          for record in body["batch"]["records"] if record["kind"] == "source_column"]
            answer = {"generation": body["generation"], "shard_id": body["batch"]["shard_id"],
                      "targets": [{"target_id": target, "candidates": candidates} for target in body["target_ids"]]}
        else:
            count = body["response_schema"]["properties"]["selected_ids"]["maxItems"]
            answer = {"generation": body["generation"], "round_id": body["round_id"], "complete": True,
                      "selected_ids": [item["candidate_id"] for item in body["candidates"][:count]],
                      "mandatory_record_ids": [item["record_id"] for item in body["global_records"]]}
        encoded = json.dumps({"status": "completed", "role": "assistant",
                              "content": [{"type": "text", "text": json.dumps(answer)}]}).encode()
        return httpx.Response(200, stream=httpx.ByteStream(encoded))

    http = httpx.Client(transport=httpx.MockTransport(respond))
    monkeypatch.setattr(snowflake, "SnowflakeClient", Client)
    monkeypatch.setattr(runtime, "caller_write_lease", lease)
    monkeypatch.setattr(runtime, "_shared_http_client", lambda origin: http)
    builder = STTMBuilderService.__new__(STTMBuilderService)
    builder._settings = settings()
    builder._session = Session(database)
    builder._query_session = Session(database)
    builder._agent = SnowflakeAgentClient("caller-only-token", host=HOST, role=CALLER.role)
    builder._model_guard = SimpleNamespace(assert_model_target_allowed=Mock())
    request = SimpleNamespace(operation=SimpleNamespace(value="sttm.auto_map"),
        actor=SimpleNamespace(user_id="FORGED_OWNER"), request_id="FORGED_JOB")
    result = SimpleNamespace(builder=builder, database=database, clients=clients,
        lease_calls=lease_calls, requests=requests, request=request, store=store_for(),
        deadline=time.monotonic() + 60, decision=object(), http=http)
    yield result
    snowflake.close_write_pools()
    http.close()


def build(harness):
    return harness.builder._build_auto_map_parallel_runtime(req=harness.request, decision=harness.decision,
        store=harness.store, deadline=harness.deadline)


def blob(bundle, value="exact"):
    text = json.dumps({"scope": {"owner_id": bundle.scope.owner_id, "snapshot_id": bundle.scope.snapshot_id},
                       "generation": "generation", "value": value}, ensure_ascii=False)
    return hashlib.sha256(text.encode()).hexdigest(), text


@pytest.mark.parametrize("mode", ["success", "encoding", "non200", "malformed", "terminal_error", "disconnect"])
def test_factory_managed_transport_memory_diagnostics_no_postresponse_archive_io(harness, monkeypatch, mode):
    from threading import Event
    from app.core.automap_scan import ScanRequest
    from app.core.automap_scan_transport import ScanTransportError, TerminalCallFailure
    from app.core.automap_shards import MessageBudget

    transport_factory = Mock(wraps=runtime.SnowflakeScanTransport)
    monkeypatch.setattr(runtime, "SnowflakeScanTransport", transport_factory)
    bundle = build(harness)
    transport_factory.assert_called_once()
    assert transport_factory.call_args.kwargs.get("diagnostic_sink") is None
    assert bundle.backend._diagnostic_sink is None
    reference, text = blob(bundle)
    bundle.archive.put(reference, text)
    before_blobs = deepcopy(harness.database.blobs)
    archive_put = Mock(wraps=bundle.archive.put)
    archive_get = Mock(wraps=bundle.archive.get)
    monkeypatch.setattr(bundle.archive, "put", archive_put)
    monkeypatch.setattr(bundle.archive, "get", archive_get)
    before_log = len(harness.database.log)
    before_leases = len(harness.lease_calls)
    provider_id = "12fcb8bb-d91e-491a-ae30-6cf934017462"
    body = {"status": "completed", "role": "assistant", "run_id": "123-456",
            "requestId": provider_id, "content": [{"type": "text", "text": "{}"}],
            "private": "PRIVATE_BODY_TOKEN"}
    attempts = []
    if mode == "terminal_error":
        body["status"] = "error"

    def respond(outgoing):
        attempts.append(outgoing)
        if outgoing.url.path == "/api/v2/cortex/threads":
            return httpx.Response(200, stream=httpx.ByteStream(b'{"thread_id":123}'))
        if mode == "disconnect":
            raise httpx.ReadTimeout("private response")
        return httpx.Response(503 if mode in ("encoding", "non200") else 200,
            headers={"Content-Encoding": "gzip" if mode == "encoding" else "identity",
                     "Content-Type": "application/json", "X-Request-Id": provider_id,
                     "Authorization": "PRIVATE_HEADER_TOKEN"},
            stream=httpx.ByteStream(b"PRIVATE_MALFORMED_BODY" if mode == "malformed" else json.dumps(body).encode()))

    request = ScanRequest(bundle.scope, "generation", "shard", ("target",), ("record",),
        json.dumps([{"role": "user", "status": "completed",
                     "content": [{"type": "text", "text": "PRIVATE_PROMPT"}]}]),
        MessageBudget(1000, 1000), harness.deadline, Event(), Event())
    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        bundle.backend._http_client = client
        with bundle.admission(request):
            guarded = bundle.admission.wrap_backend(bundle.backend)
            if mode == "success":
                assert guarded(request) == "{}"
            else:
                with pytest.raises(TerminalCallFailure if mode == "terminal_error" else ScanTransportError):
                    guarded(request)
            diagnostics = bundle.admission.diagnostics_for(request)
            assert 2 <= len(diagnostics) <= 6
            assert "PRIVATE" not in repr(diagnostics)
            # While admission remains open, terminal recognition has completed.
            after_response_log = len(harness.database.log)
            assert bundle.admission.diagnostics_for(request) == diagnostics
            assert len(harness.database.log) == after_response_log
    assert len(attempts) == 2
    archive_put.assert_not_called()
    archive_get.assert_not_called()
    writes = [sql for _, sql, _, _ in harness.database.log[before_log:] if sql.startswith(("INSERT", "UPDATE"))]
    assert any("SET RECONCILIATION_REF" in sql for sql in writes)
    assert not any("ARCHIVE" in sql for sql in writes)
    assert len(harness.lease_calls) > before_leases
    assert harness.database.blobs == before_blobs
    assert bundle.archive.get(reference) == text


def test_full_factory_real_pool_archive_scan_and_reducer(harness):
    original = deepcopy(vars(harness.store))
    bundle = build(harness)
    assert isinstance(bundle, ParallelRuntimeBundle)
    assert bundle.scope.owner_id == "ALICE"
    assert bundle.backend._agent_client is harness.builder._agent
    assert bundle.admission.job_id != "FORGED_JOB"
    assert bundle.admission.caller_id == "ALICE"
    assert bundle.limits.scan_budget.max_chars == 120_000
    assert bundle.limits.scan_budget.max_bytes == 120_000
    result = prepare_parallel(harness.store, scope=bundle.scope, backend=bundle.backend,
        admission=bundle.admission, archive=bundle.archive, limits=bundle.limits, deadline=harness.deadline)
    assert result.coverage.scan_complete
    assert result.coverage.reduction_complete
    assert result.coverage.reduction_reserved_calls > 0
    assert result.selected_source_identities
    assert len(harness.requests) == result.coverage.scan_reserved_calls + result.coverage.reduction_reserved_calls
    assert len(harness.database.claims) == len(harness.requests)
    assert bundle.backend._diagnostic_sink is None
    assert all(row[1] == "ALICE" for row in harness.database.claims)
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    assert vars(harness.store) == original
    assert bundle.archive.get(result.snapshot_archive_ref)
    assert len(harness.clients) <= 2  # many operations actually reuse the pool
    assert all(call[1]["reusable"] is True for call in harness.lease_calls)
    request_sessions = (harness.builder._session, harness.builder._query_session)
    assert all(session not in request_sessions for session, sql, _, _ in harness.database.log
               if sql.startswith(("INSERT", "UPDATE", "BEGIN")))
    assert len(harness.requests) == len(harness.database.requests_threads)
    assert bundle.backend._admission is bundle.admission
    assert all(len(request.content) <= 120_000 + 120 for request in harness.requests)
    harness.builder._model_guard.assert_model_target_allowed.assert_called_once_with(
        operation="sttm.auto_map", target="agent", decision=harness.decision)


@pytest.mark.parametrize("field", ["automap_parallel_archive_table_fqn", "automap_parallel_pool_epoch",
    "automap_parallel_pool_capacity", "automap_parallel_account_namespace", "automap_parallel_test_agent",
    "automap_parallel_permit_table_fqn"])
def test_missing_required_configuration_fails_before_io(harness, field):
    delattr(harness.builder._settings, field)
    with pytest.raises(runtime.RuntimeConfigurationError, match=field.upper()):
        build(harness)
    assert not harness.database.log and not harness.requests and not harness.clients


@pytest.mark.parametrize("field,value", [
    ("automap_parallel_test_agent", "DB.META.AGT_SOURCE_MAPPING"),
    ("automap_parallel_test_agent", "OTHER.META.AGT_AUTOMAP_SCAN_DEV_TEST"),
    ("automap_parallel_archive_table_fqn", "DB.META.PERMITS"),
    ("automap_parallel_archive_table_fqn", "DB.META.BAD;DROP TABLE X"),
    ("automap_parallel_permit_table_fqn", "OTHER.META.PERMITS"),
    ("automap_parallel_pool_epoch", "not-a-uuid"),
    ("automap_parallel_pool_capacity", True), ("automap_parallel_pool_capacity", 0),
    ("automap_parallel_pool_capacity", 9), ("automap_parallel_max_workers", 9),
    ("automap_parallel_pool_capacity", False), ("automap_parallel_pool_capacity", 1.0),
    ("automap_parallel_max_workers", True), ("automap_parallel_max_workers", False),
    ("automap_parallel_max_workers", 0), ("automap_parallel_max_workers", 1.0),
    ("automap_parallel_max_calls", 0), ("automap_parallel_max_reduction_rounds", -1),
    ("agent_outbound_message_max_chars", 0), ("agent_outbound_message_max_bytes", True),
    ("automap_parallel_account_namespace", "https://org-account"),
    ("rest_snowflake_host", "attacker.invalid"), ("rest_snowflake_host", "user@" + HOST),
    ("rest_snowflake_host", HOST + "/path"), ("rest_snowflake_host", "other-account.snowflakecomputing.com"),
])
def test_unsafe_configuration_fails_before_io(harness, field, value):
    setattr(harness.builder._settings, field, value)
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.database.log and not harness.requests and not harness.clients


@pytest.mark.parametrize("changes", [
    {"uses_custom_oauth": False}, {"snowflake_write_lease_pool_v1": False},
])
def test_credential_and_reuse_blockers_never_fallback(harness, changes):
    for key, value in changes.items():
        setattr(harness.builder._settings, key, value)
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.clients and not harness.requests


@pytest.mark.parametrize("key,value", [("token", "different"), ("token", ""),
    ("host", "other.snowflakecomputing.com"), ("role", "OWNER"), ("role", None)])
def test_existing_agent_must_match_retained_oauth(harness, key, value):
    harness.builder._session._workbench_search_context[key] = value
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.database.log and not harness.clients


def test_session_token_is_not_reused_as_login_credential(harness):
    harness.builder._agent._auth_mode = "snowflake_token"
    harness.builder._settings.local_dev_auth_enabled = True
    with pytest.raises(runtime.RuntimeConfigurationError, match="cannot be shared or cloned"):
        build(harness)
    assert not harness.clients


def test_lease_checks_native_identity_every_time(harness):
    bundle = build(harness)
    harness.clients[0].session.caller = replace(CALLER, native_user="BOB")
    reference, text = blob(bundle)
    with pytest.raises(runtime.RuntimeConfigurationError):
        bundle.archive.put(reference, text)
    assert not harness.database.blobs
    assert harness.clients[0].session.closed


@pytest.mark.parametrize("caller", [replace(CALLER, account_namespace="OTHER.ACCOUNT"),
    replace(CALLER, role="OWNER"), replace(CALLER, native_user="BOB")])
def test_injected_caller_must_match_request_sessions(harness, caller):
    harness.builder._parallel_caller = caller
    harness.builder._parallel_session_factory = lambda: pytest.fail("Mismatched injection was used")
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.requests


def test_explicit_trusted_factory_supports_non_oauth_mode(harness):
    harness.builder._settings.uses_custom_oauth = False
    harness.builder._agent._auth_mode = "snowflake_token"
    harness.builder._parallel_caller = replace(CALLER, actor_id="application-principal-id")
    leased = Session(harness.database)

    @contextmanager
    def provider():
        yield leased

    harness.builder._parallel_session_factory = provider
    bundle = build(harness)
    reference, text = blob(bundle)
    bundle.archive.put(reference, text)
    assert bundle.archive.get(reference) == text
    assert bundle.archive._caller.actor_id == "application-principal-id"
    assert bundle.scope.owner_id == "ALICE"  # native archive owner, not application ID
    assert not harness.clients


@pytest.mark.parametrize("attribute", ["_session", "_query_session"])
def test_injected_request_session_reuse_rejected(harness, attribute):
    harness.builder._parallel_caller = CALLER

    @contextmanager
    def provider():
        yield getattr(harness.builder, attribute)

    harness.builder._parallel_session_factory = provider
    with pytest.raises(runtime.RuntimeConfigurationError, match="exclusive independent"):
        build(harness)


def test_provider_suppressing_identity_error_rejected(harness):
    harness.builder._parallel_caller = CALLER

    @contextmanager
    def provider():
        try:
            yield Session(harness.database, replace(CALLER, native_user="BOB"))
        except Exception:
            pass

    harness.builder._parallel_session_factory = provider
    with pytest.raises(runtime.RuntimeConfigurationError, match="suppressed"):
        build(harness)


def test_real_pool_parallel_operations_have_exclusive_reusable_sessions(harness):
    bundle = build(harness)
    barrier = Barrier(2)
    active = set()
    lock = Lock()

    def operation():
        with bundle.archive._factory() as session:
            with lock:
                assert id(session) not in active
                active.add(id(session))
            barrier.wait(timeout=5)
            with lock:
                active.remove(id(session))
            return session

    with ThreadPoolExecutor(max_workers=2) as executor:
        first = executor.submit(operation)
        second = executor.submit(operation)
        assert first.result() is not second.result()
    assert len(harness.clients) == 2
    with bundle.archive._factory():
        pass
    assert len(harness.clients) == 2


def test_cross_factory_simultaneous_session_reuse_rejected(harness):
    shared = Session(harness.database)

    @contextmanager
    def provider():
        yield shared

    first = runtime._checked_sessions(provider, CALLER, ())
    second = runtime._checked_sessions(provider, CALLER, ())
    with first():
        with pytest.raises(runtime.RuntimeConfigurationError, match="exclusive independent"):
            with second():
                pytest.fail("Shared session accepted")


def test_exact_archive_persists_across_factory_reconstruction(harness):
    bundle = build(harness)
    reference, text = blob(bundle, "private 'quoted' \u4e1a\u52a1 " * 10_000)
    bundle.archive.put(reference, text)
    bundle.archive.put(reference, text)
    reconstructed = build(harness)
    assert reconstructed.archive.get(reference) == text
    assert len(harness.database.blobs) == 1
    assert len(next(iter(harness.database.blobs.values()))) == 1
    inserts = [(sql, params) for _, sql, params, _ in harness.database.log if sql.startswith("INSERT")]
    assert len(inserts) == 1
    assert text not in inserts[0][0] and inserts[0][1][-1] == text
    assert inserts[0][1][:2] == [CALLER.native_user, CALLER.access_scope]
    assert not harness.requests


@pytest.mark.parametrize("changed", ["native_user", "role", "snapshot", "actor_id"])
def test_archive_handles_do_not_authorize_foreign_scope(harness, changed):
    bundle = build(harness)
    reference, text = blob(bundle)
    bundle.archive.put(reference, text)
    caller, scope = CALLER, bundle.scope
    if changed == "snapshot":
        scope = replace(scope, snapshot_id="different")
    elif changed == "native_user":
        caller = replace(caller, native_user="BOB")
        scope = replace(scope, owner_id="BOB")
    else:
        caller = replace(caller, **{changed: "different"})

    @contextmanager
    def provider():
        yield Session(harness.database, caller)

    foreign = runtime.SnowflakeReductionArchive(session_factory=provider, table="DB.META.ARCHIVE",
        caller=caller, scope=scope, deadline=harness.deadline)
    with pytest.raises(runtime.RuntimeConfigurationError, match="read failed"):
        foreign.get(reference)


def test_archive_detects_corrupt_storage_and_wrong_blob_scope(harness):
    bundle = build(harness)
    reference, text = blob(bundle)
    bundle.archive.put(reference, text)
    key = next(iter(harness.database.blobs))
    harness.database.blobs[key] = [text + " "]
    with pytest.raises(runtime.RuntimeConfigurationError):
        bundle.archive.get(reference)
    body = json.loads(text)
    body["scope"]["owner_id"] = "BOB"
    foreign = json.dumps(body)
    with pytest.raises(runtime.RuntimeConfigurationError, match="scope"):
        bundle.archive.put(hashlib.sha256(foreign.encode()).hexdigest(), foreign)


@pytest.mark.parametrize("failed", ["INSERT INTO", "COMMIT", "SELECT BODY"])
def test_archive_failures_rollback_discard_and_hide_sensitive_errors(harness, failed):
    bundle = build(harness)
    reference, text = blob(bundle)
    harness.database.fail_sql = failed
    with pytest.raises(runtime.RuntimeConfigurationError) as error:
        bundle.archive.put(reference, text)
    assert "PRIVATE_TOKEN" not in str(error.value)
    assert not harness.database.blobs
    assert harness.clients[0].session.closed
    assert any(sql == "ROLLBACK" for _, sql, _, _ in harness.database.log)


@pytest.mark.parametrize("count", [0, 2, True, "1"])
def test_bad_archive_insert_acknowledgement_rolls_back(harness, count):
    bundle = build(harness)
    harness.database.insert_count = count
    with pytest.raises(runtime.RuntimeConfigurationError):
        bundle.archive.put(*blob(bundle))
    assert not harness.database.blobs


def test_expired_archive_never_writes(harness):
    bundle = build(harness)
    bundle.archive._deadline = time.monotonic() - 1
    with pytest.raises(runtime.RuntimeConfigurationError):
        bundle.archive.put(*blob(bundle))
    assert not harness.database.blobs


@pytest.mark.parametrize("capacity", [1, 2, 4, 8])
@pytest.mark.parametrize("workers", [1, 2, 4, 8])
def test_runtime_bounded_capacity_clamps_workers_and_uses_matching_inventory(harness, capacity, workers):
    harness.builder._settings.automap_parallel_pool_capacity = capacity
    harness.builder._settings.automap_parallel_max_workers = workers
    harness.database.slots = Database(capacity).slots
    bundle = build(harness)
    assert bundle.admission.store.capacity == capacity
    assert bundle.limits.max_workers == min(workers, capacity)
    result = prepare_parallel(harness.store, scope=bundle.scope, backend=bundle.backend,
        admission=bundle.admission, archive=bundle.archive, limits=bundle.limits, deadline=harness.deadline)
    assert result.coverage.scan_complete and result.coverage.reduction_complete
    assert len(harness.database.claims) == len(harness.requests) > 0
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)


@pytest.mark.parametrize("targets,expected_cap", [(1, 8), (10, 10), (18, 15)])
def test_reduction_capacity_covers_four_batch_target_count(harness, targets, expected_cap):
    payload = deepcopy(harness.store.original)
    payload["data"]["attributes"] = [
        {"target_attribute": f"TARGET_{index}"} for index in range(targets)
    ]
    harness.store = AutoMapContext(payload)
    bundle = build(harness)
    assert bundle.limits.candidate_cap == expected_cap
    assert bundle.limits.fan_in > bundle.limits.candidate_cap


@pytest.mark.parametrize("capacity", [1, 2, 4, 8])
def test_runtime_default_workers_remain_two_and_clamp_to_capacity(harness, capacity):
    harness.builder._settings.automap_parallel_pool_capacity = capacity
    bundle = build(harness)
    assert bundle.limits.max_workers == min(2, capacity)


def test_smaller_configured_budgets_are_not_raised(harness):
    harness.builder._settings.agent_outbound_message_max_chars = 40_000
    harness.builder._settings.agent_outbound_message_max_bytes = 45_000
    bundle = build(harness)
    for budget in (bundle.limits.scan_budget, bundle.limits.reduction_budget, bundle.limits.selection_budget):
        assert (budget.max_chars, budget.max_bytes) == (40_000, 45_000)
    assert bundle.limits.max_workers == 2


@pytest.mark.parametrize("deadline", [float("nan"), float("inf"), 0, True])
def test_invalid_deadlines_before_io(harness, deadline):
    harness.deadline = deadline
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.database.log


@pytest.mark.parametrize("capacity", [None, 0])
def test_flag_off_does_not_initialize_runtime(harness, capacity):
    harness.builder._settings.automap_parallel_context_v1 = False
    harness.builder._settings.automap_parallel_pool_capacity = capacity
    with pytest.raises(runtime.RuntimeConfigurationError, match="disabled"):
        build(harness)
    assert not harness.clients and not harness.database.log


def test_active_request_transaction_is_rejected(harness):
    harness.builder._session.transaction = True
    with pytest.raises(runtime.RuntimeConfigurationError, match="transaction-free"):
        build(harness)
    assert not harness.clients


def test_sql_is_parameterized_bounded_and_parses_offline(harness):
    bundle = build(harness)
    bundle.archive.put(*blob(bundle))
    bundle.archive.get(blob(bundle)[0])
    for _, sql, params, options in harness.database.log:
        sqlglot.parse_one(sql, dialect="snowflake")
        if "AS NATIVE_USER" in sql or sql.startswith(("SELECT BODY", "INSERT INTO")):
            assert 1 <= int(options["STATEMENT_TIMEOUT_IN_SECONDS"]) <= 5
            assert options["LOCK_TIMEOUT"] == "1"
        if params:
            assert sql.count("?") == len(params)


def test_http_disconnect_quarantines_permit_without_retry(harness):
    attempts = []

    def disconnected(request):
        attempts.append(request)
        raise httpx.ReadTimeout("private response")

    with httpx.Client(transport=httpx.MockTransport(disconnected)) as client:
        bundle = build(harness)
        bundle.backend._http_client = client
        result = prepare_parallel(harness.store, scope=bundle.scope, backend=bundle.backend,
            admission=bundle.admission, archive=bundle.archive, limits=bundle.limits, deadline=harness.deadline)
    assert len(attempts) == 1
    assert not result.coverage.scan_complete
    assert any(slot["STATE"] == "QUARANTINED" for slot in harness.database.slots)


def test_missing_factory_is_still_rejected_when_explicitly_unavailable(harness):
    from app.core.automap_batch import invoke_batch
    harness.builder._build_auto_map_parallel_runtime = None
    harness.builder._discover_auto_map_batch_evidence = Mock(side_effect=AssertionError("discovered"))
    with pytest.raises(ValueError, match="_build_auto_map_parallel_runtime"):
        invoke_batch(harness.builder, harness.request, harness.decision)
    harness.builder._discover_auto_map_batch_evidence.assert_not_called()


def test_consistent_but_foreign_host_still_fails_account_binding(harness):
    foreign_host = "other-account.snowflakecomputing.com"
    harness.builder._settings.rest_snowflake_host = foreign_host
    harness.builder._session._workbench_search_context["host"] = foreign_host
    harness.builder._agent._base_url = "https://" + foreign_host
    with pytest.raises(runtime.RuntimeConfigurationError, match="canonical ORG.ACCOUNT"):
        build(harness)
    assert not harness.database.log and not harness.clients


def test_missing_retained_context_requires_explicit_provider(harness):
    del harness.builder._session._workbench_search_context
    with pytest.raises(runtime.RuntimeConfigurationError, match="login credentials unavailable"):
        build(harness)
    assert not harness.clients and not harness.database.log


@pytest.mark.parametrize("field", ["_parallel_caller", "_parallel_session_factory"])
def test_partial_dependency_injection_is_rejected(harness, field):
    setattr(harness.builder, field, CALLER if field == "_parallel_caller" else Mock())
    with pytest.raises(runtime.RuntimeConfigurationError, match="Inject both"):
        build(harness)
    assert not harness.clients


def test_admission_inventory_failure_never_dispatches(harness):
    bundle = build(harness)
    harness.database.slots.clear()
    result = prepare_parallel(harness.store, scope=bundle.scope, backend=bundle.backend,
        admission=bundle.admission, archive=bundle.archive, limits=bundle.limits, deadline=harness.deadline)
    assert not result.coverage.scan_complete
    assert not harness.requests


def test_archive_unavailable_blocks_all_model_dispatch(harness):
    from app.core.automap_parallel import ParallelArchiveError
    bundle = build(harness)
    harness.database.fail_sql = "SELECT BODY"
    with pytest.raises(ParallelArchiveError):
        prepare_parallel(harness.store, scope=bundle.scope, backend=bundle.backend,
            admission=bundle.admission, archive=bundle.archive, limits=bundle.limits, deadline=harness.deadline)
    assert not harness.requests and not harness.database.claims


def test_identical_concurrent_archive_rows_are_readable(harness):
    bundle = build(harness)
    reference, text = blob(bundle)
    bundle.archive.put(reference, text)
    key = next(iter(harness.database.blobs))
    harness.database.blobs[key].append(text)
    assert bundle.archive.get(reference) == text


def test_archive_budget_rejects_without_truncation_or_insert(harness):
    bundle = build(harness)
    bundle.archive._max_bytes = 100
    with pytest.raises(runtime.RuntimeConfigurationError, match="budget"):
        bundle.archive.put(*blob(bundle, "private" * 100))
    assert not harness.database.blobs


def test_model_guard_denial_does_not_initialize_resources(harness):
    harness.builder._model_guard.assert_model_target_allowed.side_effect = ValueError("Denied")
    with pytest.raises(ValueError, match="Denied"):
        build(harness)
    assert not harness.clients and not harness.database.log and not harness.requests


def test_constructor_accepts_server_only_injection_without_network(monkeypatch):
    from app.core import sttm_builder
    config = settings(resolved_sttm_builder_agent="DB.META.BUILDER",
        resolved_source_mapping_agent="DB.META.MAPPING", resolved_transformation_rule_agent="DB.META.TRANSFORM")
    monkeypatch.setattr(sttm_builder, "load_config", lambda **kwargs: object())
    for name in ("ModelBoundaryGuard", "PostflightGuard", "ConversationMemoryService", "ConversationContinuityService"):
        monkeypatch.setattr(sttm_builder, name, Mock())
    monkeypatch.setattr("app.core.learning_retrieval.LearningRetrievalService", Mock())
    provider = Mock()
    service = STTMBuilderService(None, analyst_client=None, settings=config, session=object(),
        semantic_model_service=None, semantic_context_service=None,
        parallel_caller=CALLER, parallel_session_factory=provider)
    assert service._parallel_caller is CALLER
    assert service._parallel_session_factory is provider
    provider.assert_not_called()


@pytest.fixture
def recovery_case(harness, monkeypatch):
    from threading import Event
    from app.core.automap_scan import ScanRequest
    from app.core.automap_shards import MessageBudget
    from app.core.automap_admission import CallIdentity

    bundle = build(harness)
    request = ScanRequest(bundle.scope, "original-generation", "original-shard", ("target",), ("record",),
        '[ {"role":"user","status":"completed","content":[{"type":"text","text":"exact original"}]} ]',
        MessageBudget(1000, 1000), time.monotonic() - 100, Event(), Event())
    request._cancel.set()
    request._stop.set()
    pool = bundle.admission.store
    permit = pool.try_claim(CallIdentity(bundle.admission.job_id, CALLER.native_user,
                                         request.generation, request.shard_id))
    reference = runtime.ThreadReference(123, "DB.META.AGT_AUTOMAP_SCAN_DEV_TEST", runtime.request_digest(request))
    pool.record_reconciliation(permit, reference)
    pool.quarantine(permit)
    snapshot = json.dumps({"scope": {"owner_id": bundle.scope.owner_id, "snapshot_id": bundle.scope.snapshot_id},
        "generation": bundle.scope.snapshot_id,
        "value": {"protocol": "automap_exact_snapshot_v1", "state": {"type": "dict", "items": []}}})
    snapshot_ref = hashlib.sha256(snapshot.encode()).hexdigest()
    bundle.archive.put(snapshot_ref, snapshot)
    bundle.archive._deadline = time.monotonic() - 100
    user = dict(json.loads(request.message)[0], schema_version="v2")
    assistant = {"schema_version": "v2", "role": "assistant", "status": "completed", "content": []}
    data = {"metadata": {"thread_id": 123}, "messages": [
        {"message_id": 11, "parent_id": 0, "role": "user", "message_type": "conversation",
         "message_payload": json.dumps(user)},
        {"message_id": 12, "parent_id": 11, "role": "assistant", "message_type": "conversation",
         "message_payload": json.dumps(assistant)}]}
    case = SimpleNamespace(bundle=bundle, permit=permit, request=request, reference=reference,
        snapshot_ref=snapshot_ref, data=data, sent=[], before_get=None, failure=None)

    def respond(outgoing):
        case.sent.append(outgoing)
        assert outgoing.method == "GET"
        assert str(outgoing.url) == f"https://{HOST}/api/v2/cortex/threads/123?page_size=100"
        assert outgoing.headers["Authorization"] == "Bearer caller-only-token"
        assert outgoing.headers["User-Agent"] == "ffp-ai-migration-workbench/1.0"
        assert 0 < outgoing.extensions["timeout"]["read"] <= 60
        if case.before_get:
            case.before_get()
        if case.failure:
            raise case.failure
        return httpx.Response(200, stream=httpx.ByteStream(json.dumps(case.data).encode()))

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        bundle.backend._http_client = client
        harness.database.log.clear()
        yield case


def reconcile(case, **overrides):
    arguments = dict(permit=case.permit, original_request=case.request,
        snapshot_archive_ref=case.snapshot_ref, retired_dispatcher=True, deadline=time.monotonic() + 30)
    arguments.update(overrides)
    return runtime.reconcile_parallel_runtime(case.bundle, **arguments)


@pytest.mark.parametrize("status", ["completed", "error", "timed_out", "cancelled"])
def test_operator_reconciliation_commits_evidence_before_fenced_release(harness, recovery_case, status):
    case = recovery_case
    payload = json.loads(case.data["messages"][1]["message_payload"])
    payload["status"] = status
    case.data["messages"][1]["message_payload"] = json.dumps(payload)
    result = reconcile(case)
    assert result.status is runtime.ReconciliationStatus.RELEASED
    slot = harness.database.slots[0]
    assert slot["STATE"] == "FREE" and slot["OWNER_TOKEN"] is None
    assert slot["FENCE"] == case.permit.fence + 1
    assert slot["COMPLETION"] == ("SUCCEEDED" if status == "completed" else "FAILED")
    assert slot["RECONCILIATION_REF"] == result.evidence_ref
    assert result.evidence_ref.startswith(f"thread-v2:123-11:12:{status}:")
    assert len(result.evidence_ref) <= 255
    audit_ref = result.evidence_ref.rsplit(":", 1)[1]
    archive = case.bundle.archive.with_deadline(time.monotonic() + 30)
    text = archive.get(audit_ref)
    audit = json.loads(text)["value"]
    assert audit["identity"] == runtime.asdict(case.permit.identity)
    assert audit["state"] == "QUARANTINED" and audit["retired_dispatcher_attested"] is True
    assert audit["thread_reference"]["request_digest"] == runtime.request_digest(case.request)
    assert case.permit.owner not in text and "caller-only-token" not in text
    assert len(case.sent) == 1
    assert case.request._cancel.is_set() and case.request._stop.is_set()
    assert case.request.deadline < time.monotonic()  # Only recovery copy was refreshed.
    queries = [sql for _, sql, _, _ in harness.database.log]
    insert = next(index for index, sql in enumerate(queries) if sql.startswith("INSERT INTO"))
    release = next(index for index, sql in enumerate(queries) if "SET STATE = 'FREE'" in sql)
    assert "COMMIT" in queries[insert:release]
    assert any(sql.startswith("SELECT BODY") for sql in queries[insert + 1:release])
    for _, sql, params, _ in harness.database.log:
        sqlglot.parse_one(sql, dialect="snowflake")
        if params:
            assert sql.count("?") == len(params)
        if sql.startswith("SELECT BODY"):
            assert params[:3] == [CALLER.native_user, CALLER.access_scope, case.bundle.scope.snapshot_id]


@pytest.mark.parametrize("value", [False, None, 1, "true"])
def test_operator_retirement_requires_explicit_boolean_before_io(harness, recovery_case, value):
    with pytest.raises(runtime.RuntimeConfigurationError, match="retired_dispatcher"):
        reconcile(recovery_case, retired_dispatcher=value)
    assert not harness.database.log and not recovery_case.sent


@pytest.mark.parametrize("deadline", [0, float("nan"), float("inf"), True, "tomorrow"])
def test_operator_deadline_rejects_invalid_before_io(harness, recovery_case, deadline):
    with pytest.raises(runtime.RuntimeConfigurationError, match="deadline"):
        reconcile(recovery_case, deadline=deadline)
    assert not harness.database.log and not recovery_case.sent


def test_operator_deadline_cannot_be_unbounded(harness, recovery_case):
    with pytest.raises(runtime.RuntimeConfigurationError, match="deadline"):
        reconcile(recovery_case, deadline=time.monotonic() + 61)
    assert not harness.database.log


@pytest.mark.parametrize("reference", [None, ""])
def test_operator_legacy_untracked_no_archive_http_or_sql_update(harness, recovery_case, reference):
    harness.database.slots[0]["RECONCILIATION_REF"] = reference
    before = deepcopy(harness.database.slots)
    result = reconcile(recovery_case)
    assert result.status is runtime.ReconciliationStatus.UNTRACKED_REQUIRES_OPERATOR
    assert harness.database.slots == before and not recovery_case.sent
    assert all((sql.startswith("SELECT") or sql == "ROLLBACK") and "BODY" not in sql for _, sql, _, _ in harness.database.log)


@pytest.mark.parametrize("field,value", [("OWNER_TOKEN", "foreign"), ("FENCE", 999),
    ("POOL_EPOCH", "foreign"), ("JOB_ID", "foreign"), ("CALLER_ID", "BOB"),
    ("GENERATION", "foreign"), ("SHARD_ID", "foreign"), ("STATE", "FREE")])
def test_operator_stale_owner_scope_never_updates(harness, recovery_case, field, value):
    harness.database.slots[0][field] = value
    before = deepcopy(harness.database.slots)
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.STALE_PERMIT
    assert harness.database.slots == before and not recovery_case.sent
    assert all(sql.startswith("SELECT") or sql == "ROLLBACK" for _, sql, _, _ in harness.database.log)


@pytest.mark.parametrize("field,value", [("message", "forged"), ("message", "[]"),
    ("generation", "new-generation"), ("shard_id", "new-shard")])
def test_operator_rejects_forged_original_request(harness, recovery_case, field, value):
    result = reconcile(recovery_case, original_request=replace(recovery_case.request, **{field: value}))
    assert result.status is runtime.ReconciliationStatus.REJECTED
    assert not recovery_case.sent and harness.database.slots[0]["STATE"] == "QUARANTINED"


@pytest.mark.parametrize("case_name", ["unknown", "missing", "foreign_root", "foreign_thread", "ambiguous", "malformed"])
def test_operator_no_terminal_or_malformed_evidence_never_releases(harness, recovery_case, case_name):
    case = recovery_case
    if case_name == "unknown":
        payload = json.loads(case.data["messages"][1]["message_payload"])
        payload["status"] = "IDLE"
        case.data["messages"][1]["message_payload"] = json.dumps(payload)
    elif case_name == "missing":
        case.data["messages"].pop()
    elif case_name == "foreign_root":
        case.data["messages"][0]["message_payload"] = json.dumps({"schema_version": "v2",
            "role": "user", "content": [{"type": "text", "text": "different prompt"}]})
    elif case_name == "foreign_thread":
        case.data["metadata"]["thread_id"] = 456
    elif case_name == "ambiguous":
        extra = dict(case.data["messages"][1], message_id=13)
        case.data["messages"].append(extra)
    else:
        case.data["messages"][1]["message_payload"] = "not JSON"
    result = reconcile(case)
    assert result.status in (runtime.ReconciliationStatus.NO_TERMINAL_EVIDENCE, runtime.ReconciliationStatus.REJECTED)
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert all(sql.startswith("SELECT") or sql == "ROLLBACK" for _, sql, _, _ in harness.database.log)


@pytest.mark.parametrize("failure", ["INSERT INTO", "COMMIT", "SELECT BODY"])
def test_operator_archive_failure_leaves_quarantined(harness, recovery_case, failure):
    harness.database.fail_sql = failure
    result = reconcile(recovery_case)
    assert result.status is runtime.ReconciliationStatus.REJECTED
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert not any("SET STATE = 'FREE'" in sql for _, sql, _, _ in harness.database.log)
    assert "PRIVATE" not in repr(result)


def test_operator_noop_archive_callback_cannot_release(harness, recovery_case, monkeypatch):
    monkeypatch.setattr(runtime.SnowflakeReductionArchive, "put", lambda *args: None)
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"


@pytest.mark.parametrize("timing", ["during_get", "during_archive"])
def test_operator_stale_fence_race_never_releases(harness, recovery_case, monkeypatch, timing):
    case = recovery_case
    def change():
        harness.database.slots[0]["FENCE"] += 1
    if timing == "during_get":
        case.before_get = change
    else:
        original = runtime.SnowflakeReductionArchive.put
        def put(archive, reference, text):
            original(archive, reference, text)
            change()
        monkeypatch.setattr(runtime.SnowflakeReductionArchive, "put", put)
    assert reconcile(case).status is runtime.ReconciliationStatus.STALE_PERMIT
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert not any("SET STATE = 'FREE'" in sql for _, sql, _, _ in harness.database.log)


def test_operator_release_commit_uncertain_never_reports_success(harness, recovery_case):
    harness.database.fail_release_commit = True
    result = reconcile(recovery_case)
    assert result.status is runtime.ReconciliationStatus.RELEASE_UNCERTAIN
    assert result.evidence_ref and harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert len(recovery_case.sent) == 1


def test_operator_get_timeout_does_not_send_additional_post(harness, recovery_case):
    recovery_case.failure = httpx.ReadTimeout("PRIVATE credential")
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert len(recovery_case.sent) == 1 and recovery_case.sent[0].method == "GET"
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"


def test_operator_missing_durable_snapshot_prevents_get(harness, recovery_case):
    result = reconcile(recovery_case, snapshot_archive_ref="0" * 64)
    assert result.status is runtime.ReconciliationStatus.REJECTED and not recovery_case.sent


def test_operator_foreign_access_scope_cannot_read_snapshot(harness, recovery_case):
    recovery_case.bundle.archive._caller = replace(CALLER, actor_id="foreign-principal")
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert not recovery_case.sent


def test_operator_malformed_reference_never_becomes_untracked(harness, recovery_case):
    harness.database.slots[0]["RECONCILIATION_REF"] = "not a reference"
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert not recovery_case.sent


def test_operator_duplicate_occupied_rows_never_authorize(harness, recovery_case):
    harness.database.slots.append(deepcopy(harness.database.slots[0]))
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.STALE_PERMIT
    assert not recovery_case.sent


@pytest.mark.parametrize("field,value", [("STATE", "HELD"), ("RECONCILIATION_REF", "changed"),
    ("OWNER_TOKEN", "changed"), ("FENCE", 999)])
def test_operator_final_cas_compares_original_state_reference_and_owner(harness, recovery_case, monkeypatch, field, value):
    pool = recovery_case.bundle.admission.store
    original = pool.reconcile_terminal
    def race(*args, **kwargs):
        harness.database.slots[0][field] = value
        return original(*args, **kwargs)
    monkeypatch.setattr(pool, "reconcile_terminal", race)
    result = reconcile(recovery_case)
    assert result.status is runtime.ReconciliationStatus.STALE_PERMIT
    assert harness.database.slots[0]["STATE"] != "FREE"
    assert harness.database.slots[0][field] == value


@pytest.mark.parametrize("stage", ["audit", "release"])
def test_operator_lost_commit_ack_never_claims_release_or_retries(harness, recovery_case, monkeypatch, stage):
    if stage == "audit":
        recovery_case.before_get = lambda: setattr(harness.database, "commit_failure", "after")
    else:
        pool = recovery_case.bundle.admission.store
        original = pool.reconcile_terminal
        def uncertain(*args, **kwargs):
            harness.database.commit_failure = "after"
            return original(*args, **kwargs)
        monkeypatch.setattr(pool, "reconcile_terminal", uncertain)
    result = reconcile(recovery_case)
    assert result.status is (runtime.ReconciliationStatus.REJECTED if stage == "audit"
                            else runtime.ReconciliationStatus.RELEASE_UNCERTAIN)
    assert harness.database.slots[0]["STATE"] == ("QUARANTINED" if stage == "audit" else "FREE")
    # A lost release COMMIT acknowledgement cannot undo an already committed CAS.
    # The result must say uncertain, not manufacture a confirmed occupied/free state.
    assert len(recovery_case.sent) == 1
    assert len(harness.database.blobs) == 2


@pytest.mark.parametrize("kind", ["dict", "foreign", "missing", "wrong_assistant"])
def test_operator_requires_typed_exact_transport_terminal(harness, recovery_case, monkeypatch, kind):
    backend = recovery_case.bundle.backend
    original = backend.recover_thread
    def observe(*args):
        observation = original(*args)
        if kind == "dict":
            return replace(observation, terminal={"status": "completed"})
        if kind == "foreign":
            return replace(observation, terminal=replace(observation.terminal, thread_id=456))
        if kind == "wrong_assistant":
            return replace(observation, assistant_message_ids=(99,))
        return None
    monkeypatch.setattr(backend, "recover_thread", observe)
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert len(harness.database.blobs) == 1


def test_operator_reconstructed_new_job_bundle_cannot_release_old_job(harness, recovery_case):
    case = recovery_case
    case.bundle = build(harness)
    harness.database.log.clear()
    assert reconcile(case).status is runtime.ReconciliationStatus.REJECTED
    assert not harness.database.log and not case.sent


def test_operator_expired_during_get_cannot_archive_or_release(harness, recovery_case, monkeypatch):
    before = time.monotonic()
    recovery_case.before_get = lambda: monkeypatch.setattr(time, "monotonic", lambda: before + 100)
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert len(harness.database.blobs) == 1


@pytest.mark.parametrize("rows", [[], [{"number of rows updated": True}],
    [{"number of rows updated": 2}], [{"number of rows updated": "1"}]])
def test_operator_bad_release_ack_rolls_back(harness, recovery_case, rows):
    harness.database.release_result = rows
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.RELEASE_UNCERTAIN
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
    assert harness.database.slots[0]["OWNER_TOKEN"] == recovery_case.permit.owner
    assert harness.database.slots[0]["FENCE"] == recovery_case.permit.fence


def test_operator_suppressed_archive_failure_cannot_release(harness, recovery_case, monkeypatch):
    original = runtime.SnowflakeReductionArchive.with_deadline
    def archive_with_suppressing_provider(archive, deadline):
        archive = original(archive, deadline)
        @contextmanager
        def provider():
            try:
                yield Session(harness.database)
            except Exception:
                pass
        archive._factory = provider
        return archive
    monkeypatch.setattr(runtime.SnowflakeReductionArchive, "with_deadline", archive_with_suppressing_provider)
    harness.database.fail_sql = "INSERT INTO"
    assert reconcile(recovery_case).status is runtime.ReconciliationStatus.REJECTED
    assert harness.database.slots[0]["STATE"] == "QUARANTINED"
