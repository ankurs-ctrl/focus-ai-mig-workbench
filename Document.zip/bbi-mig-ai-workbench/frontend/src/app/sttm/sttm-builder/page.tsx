export default function Page() {
    return (
        <>
            <h1>STTM BUILDER</h1>
        </>
    )
}