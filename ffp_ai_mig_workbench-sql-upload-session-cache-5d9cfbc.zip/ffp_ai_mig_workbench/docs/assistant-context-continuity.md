# Assistant context continuity

The workspace, a completed Auto-Map proposal, and conversation history are
separate inputs. A proposal does not become an accepted mapping just because
the assistant can explain it.

## Request lifecycle

- Source Selection and Mapping share workspace state. Prepared handles cache
  stable semantics and learning; each assistant turn overlays the actual page,
  checked/active rows, CTE driver, recent conversation, and Auto-Map outcome.
- CTE driver, filters/query modifiers, selected columns, SQL, relationships,
  and dependency definitions participate in preparation identity. Late responses
  cannot install a handle for an obsolete workspace. Explicit null values clear
  a field; omitted overlay fields retain the prepared baseline.
- Warm handles hydrate their saved semantic payload. A changed workspace must
  resolve its own semantics. Missing handles without a complete live fallback
  return a refresh error rather than claiming complete context.
- Completed Auto-Map outcomes include the job/request identity and all target
  decisions, even targets absent from imported mapping rows. Legacy clients can
  recover the latest completed outcome for the authenticated job owner, project,
  and mapping. Recovered results are historical and may predate current edits.
- Questions about recorded unresolved reasons use those outcomes and current
  rows, not unrelated historical recipes or the complete executable source
  graph. The answer must attribute conclusions to the run. A new assessment or
  transformation uses source semantics and dependencies instead.
- Transformation requests carry `selected_mapping`, including derived source
  references, rules, dependencies, mapping mode, and project value bindings.
  Project-attribute retrieval failures are not converted to empty bindings.
  Detailed source semantics follow the existing binding's upstream closure;
  the entire executable population graph remains. Unresolved lineage keeps
  the full semantic context rather than guessing which inputs are irrelevant.

## Retrieval-first assistant context

Ordinary CHAT reaches AGT_STTM_BUILDER with the current selection, live graph,
mapping rows, filters, project context/Values and known correction constraints.
Large semantic/learning bodies, CTE SQL, parsed SQL models, saved graph copies,
and legacy serialized compiler fingerprints are retained in a request-local exact
retrieval store, not preloaded into every message. The workspace's historical
conversation, validation history and Auto-map outcomes are also pageable; recent
conversation is supplied separately by bounded continuity, not duplicated inside
the mandatory current packet. A CTE index preserves names,
selection status and paths; it does not assert semantic suitability.

The deployed orchestrator has SearchWorkbenchRag, SearchFIRKnowledge and two
mapping/transformation specialists. With `AGENT_REQUEST_SCOPED_ANALYST_V1=true`
and an explicit `AGENT_BUNDLE_VIEW_SCHEMA=DATABASE.SCHEMA`, chat reads the agent
specification using the caller's credentials and creates an isolated objectless
run configuration containing `CurrentBundleAnalyst`. The deployed agent and its
grants are not modified. Existing Search and specialist resources are preserved;
old native Analyst bindings are removed only from the request-local copy.

The exact prepared bundle hash must match the durable bundle. Its YAML is validated
before materialization, and the view name incorporates caller scope and semantic
content. Different bundle versions cannot overwrite each other's views. Creation
requires the caller's existing schema privileges; no role switching or grants occur.
Request-scoped runs use bounded application history rather than server thread IDs,
and workspace-context continuations retain the same tool configuration.

Native Analyst can execute SQL (explicitly authorized for the current DEV acceptance).
There is no claimed generation-only guarantee. Query timeout is 60 seconds; applying
a draft, publication, and target loads remain separate workflows. Streaming audit
records actual final tool results, and partial streams are not automatically replayed.
The flag defaults off pending acceptance. When off, legacy request-scoped backend
Analyst delegation remains available. Normal chat does not use CTE keywords to
bypass the orchestrator; the typed sttm.derived_sql.generate path is unchanged.

WORKSPACE_CONTEXT is an application-handled response delegation, not a registered
tool. Its per-request protocol includes exact snapshot/section hashes and bounded
paths/ranges. Initial and continuation packets use identical intent normalization.
Search cannot substitute for unsaved edits or private project values, and specialist
calls must receive resolved task context rather than inaccessible manifest handles.

## Memory and persistence

Source/driver/relationship edits retain logical conversation identity while
resetting stale physical threads. The existing continuity service reseeds a
new segment from scoped history and the current workspace. New Chat and opening
another mapping do not inherit an unrelated thread.

Workspace snapshots persist Auto-Map outcomes and assistant memory separately
from mapping semantics. Completed turns trigger snapshot persistence; the
backend's semantic-equality check preserves mapping publication status. Opening
a saved mapping requests a fresh latest-snapshot pointer, bypassing stale detail
caches. History is restored only for the same user, project, and mapping.
The local development HTTP snapshot cache also honors explicit refresh in
auto/record modes; replay-only mode reports that fresh data is unavailable
without making an unexpected backend request.

Prepared cache identity excludes conversation/outcome updates. Snapshot autosave
baselines reset on workspace loading, not every returned snapshot ID; otherwise
an in-flight save could swallow a newer assistant turn.

## Streaming and limits

Expected budget errors produce `ASSISTANT_CONTEXT_TOO_LARGE` with a request ID
and failed phase. Required context is not clipped to force success. Unexpected
errors remain guarded. Deferred persistence failures cannot emit a second error
after a completed answer.

The frontend batches rendering with one nonblocking timer. The network reader
never awaits that timer: background-tab throttling must not delay draining received
SSE frames or the terminal event. Final/error events synchronously flush and cancel
the pending timer. Buffers clear before dispatch to avoid duplicate text and React
nested-update loops. The regression test holds every timer and verifies that 1,000
deltas still drain and flush exactly once on completion.

## Native Analyst acceptance status

The first live validation of mapping 9901 reached Snowflake's YAML-to-view
validation and failed with a cyclic relationship between CONTACT_FAMILIES and
ADDRESSES (query ID `01c7c483-0009-4c3e-0001-70b251fdd6ba`). No new bundle view
was created and no native Analyst query ran. The local feature flag was disabled
after this test to keep ordinary chat usable. Do not enable globally until the
bundle's relationship graph is made native-view-compatible without silently
removing required mapping relationships. Existing prepared handles may also lack
a bundle hash; the enabled path now resolves the live selection before constructing
both the prompt and tool binding.

Derived-builder SQL hydration now follows parser-provided local CTE scope IDs to
physical dependencies. Queries with local CTEs retain their full SQL in SQL mode;
they are not rebound to physical tables by alias-name guessing. Validation remains
a user action and visual controls stay locked where a lossless conversion is not
available.

## Verification

- `frontend/scripts/test-assistant-continuity.cjs`: outcome separation, hash
  invalidation, transient page state, stale handles, logical memory, selected
  transformation contract, and stream scheduling.
- `tests/unit/core/test_assistant_context_continuity.py`: pre-invocation budget
  failure, terminal events, 37 outcomes versus 32 rows, overlays, warm hydration,
  exact transformation context, and owner-scoped durable outcome recovery.
- Existing prepared-context, conversation-continuity, payload, upload, SQL
  hydration/formatting, and mapping-artifact suites cover shared paths.

No deployment, target loading, mapping publication, Search flag change, or
context-limit increase is required. Generated transformations still require
explicit user acceptance.

Local acceptance so far: the three recorded unresolved outcomes stream to a
completed answer, persist with the logical conversation and job reference,
and survive Source Selection and Mapping reopen with the same 32 authored rows.
An OwnerId proposal also completed with the current CTE source and governed
`$BackupOwnerID` binding. It remained pending review; the authored rule did not
change. This verifies context delivery and proposal isolation, not business
approval of the generated rule. Broad questions requiring more than the request
budget still fail explicitly rather than silently dropping required context.