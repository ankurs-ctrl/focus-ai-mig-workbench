import asyncio
from copy import deepcopy
import hashlib
import json
import logging
import queue
import re
import threading
import time
import uuid
from collections.abc import Iterator
from types import SimpleNamespace
from typing import Any

from pydantic import ValidationError
import sqlglot
from sqlglot import exp
from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.mapping_contracts import column_identity, optional_identifier, semantic_column_profiles, valid_attribute_expression
from app.core.context_audit import attach_citations, payload_audit
from app.core.agent_payload_budget import (
    AgentPayloadBudgetError,
    budget_agent_payload,
)
from app.core.performance import increment, observe
from app.core.agent_execution_context import attach_agent_execution_context
from app.core.conversation_memory import ConversationMemoryService
from app.core.conversation_continuity import (
    ConversationContinuityService,
    ConversationPreparation,
)
from app.core.exceptions import (
    AppError,
    ContextPrecedentUnavailableError,
    SemanticAssetNotFoundError,
    SemanticRelationshipInvalidError,
    SnowflakeAgentError,
)
from app.guardrails.config.loader import load_config
from app.guardrails.contracts.decisions import GovernanceDecision
from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
from app.guardrails.runtime.postflight import PostflightGuard
from app.core.semantic_context import SemanticContextService
from app.core.derived_source import derived_sql_hash
from app.core.semantic_model import SemanticModelService
from app.core.snowflake_agent import SnowflakeAgentClient
from app.core.snowflake_analyst import SnowflakeAnalystClient, SnowflakeAnalystResponse


_ANALYST_RESPONSE_CACHE_TTL_SECONDS = 120.0
_ANALYST_DERIVED_DRAFT_CACHE_TTL_SECONDS = 900.0
_ANALYST_RESPONSE_CACHE_LOCK = threading.Lock()
_ANALYST_RESPONSE_CACHE: dict[str, tuple[float, "STTMBuilderResponse"]] = {}
from app.schema.contracts import ApiError, ApiWarning
from app.schema.common import AttributeRef, TableRef
from app.schema.semantic_context import SemanticContextRefreshRequest, SemanticLevel, SemanticSurface
from app.schema.semantic_context import SemanticBundleStatus, SemanticRefreshStatus
from app.schema.sttm_builder import (
    AttributeMapping,
    Interface,
    SemanticContextItem,
    SourceMappingResult,
    STTMAgentRequestEnvelope,
    STTMAgentResponseEnvelope,
    STTMArtifactType,
    STTMBuilderEnvelopeRequest,
    STTMBuilderResponse,
    STTMStatus,
    STTMOperation,
    SubAgent,
    TransformationRule,
    TransformationResult,
    ValueBinding,
    _coerce_api_error,
)

logger = logging.getLogger(__name__)
_local_chat_threads: dict[str, list[dict[str, Any]]] = {}
_INTENT_ROUTE_DIRECT = "direct_answer"
_INTENT_ROUTE_RAG = "rag_answer"
_INTENT_ROUTE_ANALYST = "analyst_sql_or_derived_source"
_INTENT_ROUTE_SOURCE_MAPPING = "source_mapping"
_INTENT_ROUTE_TRANSFORMATION = "transformation_rule"
_INTENT_ROUTE_DBT = "dbt_conversion"
_INTENT_ROUTE_TESTS = "test_cases"
_INTENT_ROUTE_COCO = "coco_deep_agent"
_INTENT_ROUTE_ALLOWED = {
    _INTENT_ROUTE_DIRECT,
    _INTENT_ROUTE_RAG,
    _INTENT_ROUTE_ANALYST,
    _INTENT_ROUTE_SOURCE_MAPPING,
    _INTENT_ROUTE_TRANSFORMATION,
    _INTENT_ROUTE_DBT,
    _INTENT_ROUTE_TESTS,
    _INTENT_ROUTE_COCO,
}
_LEGACY_CONVERSATION_ROUTE_MAP = {
    "quick_answer": _INTENT_ROUTE_DIRECT,
    "clarification": _INTENT_ROUTE_DIRECT,
    "rag_lookup": _INTENT_ROUTE_RAG,
    "recommendation": _INTENT_ROUTE_RAG,
    "feedback_capture": _INTENT_ROUTE_DIRECT,
}


def classify_sttm_intent_route(req: STTMBuilderEnvelopeRequest) -> str:
    """Fast deterministic route hint before AGT_STTM_BUILDER sees the payload."""
    explicit = (req.data.intent_route or req.context.routing_hint or "").strip().lower()
    if explicit:
        mapped = _LEGACY_CONVERSATION_ROUTE_MAP.get(explicit, explicit)
        if mapped in _INTENT_ROUTE_ALLOWED:
            return mapped
    if req.data.intent == Interface.AUTO_MAP:
        return _INTENT_ROUTE_SOURCE_MAPPING
    if req.data.intent == Interface.TRANSFORM:
        return _INTENT_ROUTE_TRANSFORMATION

    text = (req.data.message or "").strip().lower()
    surface = req.context.surface
    checked_rows = (
        req.context.workspace_context.checked_mapping_row_ids
        if req.context.workspace_context is not None
        else []
    )

    if any(token in text for token in ("coco", "deep agent", "code agent", "edit code", "deploy")):
        return _INTENT_ROUTE_COCO
    if any(token in text for token in ("dbt", "model.sql", "schema.yml", "schema yaml")):
        return _INTENT_ROUTE_DBT
    if any(token in text for token in ("test case", "test cases", "data test", "unit test")):
        return _INTENT_ROUTE_TESTS
    if surface == SemanticSurface.MAPPING and (
        checked_rows
        or any(token in text for token in ("map", "mapping", "source column", "confidence", "why low", "remap", "preprocessing", "pre-processing", "preprocess", "pre-process", "transformation rule", "transform rule"))
    ):
        if any(token in text for token in ("preprocessing", "pre-processing", "rule", "cast", "case ", "preprocess", "pre-process", "transform", "convert", "expression")):
            return _INTENT_ROUTE_TRANSFORMATION
        return _INTENT_ROUTE_SOURCE_MAPPING
    if any(token in text for token in (
        "tell me about", "what can you", "what about", "do you see",
        "describe", "overview", "explain the", "information about",
        "what do you know", "any insight", "any recommendation",
        "why", "explain", "prior", "history", "recommend", "relationship", "semantic", "meaning",
    )):
        return _INTENT_ROUTE_RAG
    if re.search(r"\b(?:derived sources?|ctes?|join the|generate sql|write sql|validate sql)\b", text):
        return _INTENT_ROUTE_ANALYST
    if "query" in text and not any(token in text for token in ("tell", "about", "see", "know", "explain")):
        return _INTENT_ROUTE_ANALYST
    return _INTENT_ROUTE_DIRECT


# Conversations whose previous turn is still writing after response.completed.
# The next turn's continuity read waits for those writes so it sees the bound
# thread and stored turns; normally the user's typing time covers them.
_PENDING_TURN_WRITES: dict[str, threading.Event] = {}
_PENDING_TURN_WRITES_LOCK = threading.Lock()
_PENDING_TURN_WRITE_WAIT_SECONDS = 8.0


def _begin_turn_writes(conversation_id: str | None) -> threading.Event | None:
    if not conversation_id:
        return None
    done = threading.Event()
    with _PENDING_TURN_WRITES_LOCK:
        _PENDING_TURN_WRITES[conversation_id] = done
    return done


def _end_turn_writes(conversation_id: str | None, done: threading.Event | None) -> None:
    if done is None:
        return
    done.set()
    with _PENDING_TURN_WRITES_LOCK:
        if _PENDING_TURN_WRITES.get(conversation_id or "") is done:
            _PENDING_TURN_WRITES.pop(conversation_id or "", None)


def _wait_for_turn_writes(conversation_id: str | None) -> None:
    if not conversation_id:
        return
    with _PENDING_TURN_WRITES_LOCK:
        pending = _PENDING_TURN_WRITES.get(conversation_id)
    if pending is not None and not pending.wait(_PENDING_TURN_WRITE_WAIT_SECONDS):
        logger.warning("Previous turn writes still pending for conversation %s", conversation_id)


def _iter_agent_events_with_heartbeat(
    events: Iterator[tuple[str, Any]],
    *,
    heartbeat_seconds: float = 10.0,
) -> Iterator[tuple[str, Any]]:
    """Consume a blocking Cortex SSE iterator without leaving ingress idle."""
    event_queue: queue.Queue[tuple[str, Any]] = queue.Queue()
    completed = object()

    def consume() -> None:
        try:
            for item in events:
                event_queue.put(("event", item))
        except BaseException as exc:  # re-raised on the request thread
            event_queue.put(("error", exc))
        finally:
            event_queue.put(("completed", completed))

    threading.Thread(target=consume, daemon=True).start()
    started = time.monotonic()
    while True:
        try:
            kind, value = event_queue.get(timeout=heartbeat_seconds)
        except queue.Empty:
            yield "__heartbeat__", {
                "elapsed_seconds": round(time.monotonic() - started, 1),
            }
            continue
        if kind == "event":
            yield value
        elif kind == "error":
            raise value
        else:
            return


class STTMBuilderService:
    """
    Drives the STTM_BUILDER_AGENT orchestration agent.

    The agent routes each request to the appropriate sub-agent
    (SOURCE_MAPPING_AGENT or TRANSFORMATION_AGENT) based on the interface
    tag embedded in the prompt. This service enriches the request with
    semantic context before calling the agent.
    """

    def __init__(
        self,
        agent_client: SnowflakeAgentClient,
        *,
        analyst_client: SnowflakeAnalystClient,
        settings: Settings,
        session: Session,
        semantic_model_service: SemanticModelService,
        semantic_context_service: SemanticContextService,
        access_scope: str = "default",
        query_session: Session | None = None,
        parallel_caller=None,
        parallel_session_factory=None,
        fast_model_runtime_factory=None,
    ) -> None:
        # Server-only injection for auth modes without retained caller OAuth.
        # The provider must yield independent exclusive Snowpark Sessions.
        self._parallel_caller = parallel_caller
        self._parallel_session_factory = parallel_session_factory
        if fast_model_runtime_factory is not None:
            if not callable(fast_model_runtime_factory):
                raise TypeError("Fast runtime factory must be callable")
            self._fast_model_runtime_factory = fast_model_runtime_factory
        self._agent = agent_client
        self._analyst = analyst_client
        self._settings = settings
        self._session = session
        # Durable state and semantic/FIR caches stay on CONTROL via ``session``.
        # Factual assistant/Analyst SQL uses the independently routed AGENT
        # session so routine chat never activates the EXECUTION warehouse.
        self._query_session = query_session or session
        self._semantic_model_service = semantic_model_service
        self._semantic_context_service = semantic_context_service
        self._guardrails_config = load_config(settings=settings)
        self._model_guard = ModelBoundaryGuard(self._guardrails_config)
        self._postflight_guard = PostflightGuard(self._guardrails_config)

        from app.core.learning_retrieval import LearningRetrievalService
        self._learning_service = LearningRetrievalService(
            session,
            settings,
            access_scope=access_scope,
        )
        self._conversation_memory = ConversationMemoryService(session, settings)
        self._conversation_continuity = ConversationContinuityService(
            self._conversation_memory,
            settings,
        )

        builder_agent_name = settings.resolved_sttm_builder_agent.strip()
        if not builder_agent_name:
            raise SnowflakeAgentError(
                "Could not resolve the STTM builder agent. Set "
                "SNOWFLAKE_STTM_BUILDER_AGENT or provide the metadata "
                "database/schema configuration."
            )
        self._agent_name = builder_agent_name

        source_mapping_agent_name = settings.resolved_source_mapping_agent.strip()
        if not source_mapping_agent_name:
            raise SnowflakeAgentError(
                "Could not resolve the source mapping agent. Set "
                "SNOWFLAKE_SOURCE_MAPPING_AGENT or provide the metadata "
                "database/schema configuration."
            )
        self._source_mapping_agent_name = source_mapping_agent_name
        transformation_agent_name = settings.resolved_transformation_rule_agent.strip()
        if not transformation_agent_name:
            raise SnowflakeAgentError(
                "Could not resolve the transformation rule agent from the metadata database/schema configuration."
            )
        self._transformation_agent_name = transformation_agent_name

    def _build_auto_map_parallel_runtime(self, *, req, decision, store, deadline):
        from app.core.automap_runtime import build_parallel_runtime

        return build_parallel_runtime(self, req=req, decision=decision, store=store, deadline=deadline)

    @staticmethod
    def _with_intent_route(req: STTMBuilderEnvelopeRequest) -> STTMBuilderEnvelopeRequest:
        route = classify_sttm_intent_route(req)
        if req.data.intent == Interface.AUTO_MAP:
            guidance = (
                "Select the strongest semantically supported source that is valid in the prepared driving graph, "
                "even when confidence is uncertain. Put the selected binding in source_attributes and the other "
                "plausible choices in candidate_source_attributes, strongest first. Preserve honest confidence_score "
                "and explain the ranking and uncertainty in confidence_reason. Do not suppress a useful shortlist "
                "merely because confidence is low. Use unmatched_reason to explain remaining review questions. "
                "Candidates needing missing joins or unavailable outputs may remain review suggestions, but must "
                "not be selected as executable bindings. If no supported valid choice exists, keep the target "
                "unresolved and return the plausible shortlist. Never invent sources or joins."
            )
            message = req.data.message or ""
            if guidance not in message:
                req = req.model_copy(update={"data": req.data.model_copy(update={
                    "message": f"{message}\n\n{guidance}".strip(),
                })})
        return req.model_copy(
            update={
                "context": req.context.model_copy(update={"routing_hint": route}),
                "data": req.data.model_copy(update={"intent_route": route}),
            }
        )

    def restore_auto_map_outcome(self, req: STTMBuilderEnvelopeRequest, *, owner: str) -> STTMBuilderEnvelopeRequest:
        """Recover legacy clients' missing run outcome, scoped to its owner/workspace."""
        workspace = req.context.workspace_context
        if (req.data.intent != Interface.CHAT or not workspace or workspace.auto_map_outcome
                or not owner or not req.context.project_id or not req.context.sttm_id):
            return req
        table = self._settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
        try:
            rows = self._session.sql(
                f"""SELECT JOB_ID, REQUEST_ID, CONTEXT_HASH, CREATED_AT, STATUS,
                           JOB_STATE:response:result:mappings AS MAPPINGS,
                           JOB_STATE:response:meta:auto_mapping_review AS REVIEW
                    FROM {table}
                    WHERE OWNER_ID = ? AND STATUS IN ('completed', 'partial_failure')
                      AND JOB_STATE:request_envelope:context:project_id::STRING = ?
                      AND JOB_STATE:request_envelope:context:sttm_id::STRING = ?
                    ORDER BY CREATED_AT DESC LIMIT 1""",
                params=[owner, str(req.context.project_id), str(req.context.sttm_id)],
            ).collect()
        except Exception:
            logger.warning("Could not restore Auto-Map outcome: request_id=%s", req.request_id, exc_info=True)
            return req
        if not rows:
            return req
        record = rows[0].as_dict()
        def decode(value):
            return json.loads(value) if isinstance(value, str) else value
        outcome = {
            "job_id": record["JOB_ID"], "request_id": record["REQUEST_ID"],
            "project_id": req.context.project_id, "sttm_id": req.context.sttm_id,
            "prepared_context_hash": record["CONTEXT_HASH"], "created_at": str(record["CREATED_AT"]),
            "status": record.get("STATUS", "completed"), "provenance": "owner_scoped_durable_job",
            "mappings": decode(record["MAPPINGS"]), "review": decode(record["REVIEW"]),
            "current_workspace_may_have_changed": True,
        }
        return req.model_copy(update={"context": req.context.model_copy(update={
            "workspace_context": workspace.model_copy(update={"auto_map_outcome": outcome}),
        })})

    def invoke(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        governance_decision: GovernanceDecision | None = None,
    ) -> STTMBuilderResponse:
        fast = req.meta.get("auto_map_fast_path") == "v1"
        if fast:
            from app.core.automap_batch import canonical_model_wire_request, validate_fast_request
            req = canonical_model_wire_request(req)
            validate_fast_request(req, self._settings)
        req = self._with_intent_route(req)
        if not fast:
            req = self._sanitize_request_semantic_context(req)
        decision = governance_decision or self._build_governance_decision(req)
        started_at = time.perf_counter()
        semantic_started = time.perf_counter()
        if fast:
            semantic_refresh = None
        else:
            req, semantic_refresh = self._with_semantic_context(req)
        semantic_retrieval_ms = (time.perf_counter() - semantic_started) * 1000
        prepared_execution = bool(
            req.context.prepared_context_hash
            and req.context.execution_context is not None
        ) or req.meta.get("auto_map_stage") == "complex_transformation"
        if not prepared_execution:
            req = attach_agent_execution_context(req, self._conversation_memory)
        learning_started = time.perf_counter()
        if not fast:
            req = self._with_learning_context(req)
        learning_retrieval_ms = (time.perf_counter() - learning_started) * 1000
        if not prepared_execution:
            req = attach_agent_execution_context(req, self._conversation_memory)
        req = self._govern_request_for_model(req, decision)
        semantic_context_ms = (time.perf_counter() - started_at) * 1000

        if self._should_use_analyst(req, semantic_refresh):
            logger.info(
                "Answering STTM chat request with Cortex Analyst: request_id=%s surface=%s level=%s semantic_view=%s",
                req.request_id,
                req.context.surface.value,
                req.context.semantic_level_requested.value,
                getattr(semantic_refresh, "semantic_view_name", None),
            )
            response = self._invoke_analyst(req, semantic_refresh, decision)
            response.meta = self._merge_agent_meta(
                response.meta,
                {
                    "timings_ms": {
                        "semantic_context": round(semantic_context_ms, 1),
                        "semantic_retrieval": round(semantic_retrieval_ms, 1),
                        "fir_retrieval": round(learning_retrieval_ms, 1),
                        "total": round((time.perf_counter() - started_at) * 1000, 1),
                    },
                    "routing": {
                        "bypassed_agent_orchestrator": True,
                        "reason": "oauth_safe_direct_analyst_path",
                    },
                },
            )
            artifact_started = time.perf_counter()
            artifact_id = self._persist_response_artifact(req, response)
            artifact_persistence_ms = (time.perf_counter() - artifact_started) * 1000
            self._attach_response_artifact_descriptor(
                response,
                artifact_id=artifact_id,
                artifact_type=str(
                    response.data.artifact_type.value
                    if response.data is not None
                    else "analyst_answer"
                ),
            )
            response.meta = self._merge_agent_meta(
                response.meta,
                {
                    "timings_ms": {
                        "artifact_persistence": round(artifact_persistence_ms, 1),
                        "total": round((time.perf_counter() - started_at) * 1000, 1),
                    }
                },
            )
            return response

        if self._auto_map_retrieval_enabled(req):
            if fast:
                validate_fast_request(req, self._settings)
            raw_text, thread_id, raw_payload = self._invoke_retrieval_auto_map(req, decision)
            parsed = self._parse_envelope(raw_text)
            result = parsed[1]
            warnings = self._auto_map_response_warnings(parsed[3], raw_payload.get("warnings", []))
            parallel = (raw_payload.get("auto_map_retrieval") or {}).get("parallel_preparation")
            unresolved_count = sum(mapping.transformation_classification == "unresolved" for mapping in result.mappings.values())
            response = STTMBuilderResponse.from_invocation(
                req, thread_id=thread_id, parent_message_id=_extract_assistant_message_id(raw_payload),
                agent=SubAgent.SOURCE_MAPPING_AGENT, result=result,
                message=f"Scoped Auto-map returned {len(result.mappings)} targets; {unresolved_count} remain unresolved.",
                status=STTMStatus.NEEDS_INPUT if unresolved_count or any(
                    warning.code in {"parallel_stage_failed", "parallel_read_budget_exceeded",
                                     "parallel_message_budget_exceeded"} for warning in warnings
                ) else STTMStatus.COMPLETED,
                artifact_type=STTMArtifactType.SOURCE_MAPPING,
                warnings=warnings,
                meta={"auto_map_retrieval": raw_payload.get("auto_map_retrieval", {}),
                      "automap_evidence_review_only_targets": raw_payload.get("automap_evidence_review_only_targets", [])},
            )
            response.warnings = self._auto_map_response_warnings(response.warnings)
            if parallel or req.meta.get("auto_map_fast_path") == "v1":
                response.meta["assistant_context"] = self._auto_map_assistant_context(response.warnings)
            finalized = self._postflight_guard.finalize_sttm_response(self._with_semantic_gap_notice(req, response), decision)
            self._persist_response_artifact(req, finalized)
            finalized._auto_map_admitted_evidence = raw_payload.get("auto_map_admitted_evidence", {})
            finalized._auto_map_execution = getattr(raw_payload, "execution", None)
            return finalized

        user_text = self._build_agent_payload(req)
        continuity = self._prepare_conversation_continuity(req, user_text)
        messages = self._messages_with_continuity(user_text, continuity)
        prepared_payload = req.model_dump(mode="json", exclude_none=True)
        payload_attempts = [payload_audit(prepared_payload, user_text, messages=messages)]
        self._capture_prompt_artifact(req, messages, payload_attempts[-1])
        local_thread_id = None
        self._model_guard.assert_model_target_allowed(
            operation=req.operation.value,
            target="agent",
            decision=decision,
        )
        logger.info(
            "Sending STTM agent payload: request_id=%s operation=%s chars=%s surface=%s level=%s bundle=%s agent=%s",
            req.request_id,
            req.operation.value,
            len(user_text),
            req.context.surface.value,
            req.context.semantic_level_requested.value,
            req.context.semantic_bundle_id,
            self._resolved_agent_name(req),
        )

        thread_id_to_use = (
            None
            if self._should_reset_thread(req)
            else (
                continuity.physical_thread_id
                if continuity is not None
                else req.context.thread_id
            )
        )
        parent_message_id_to_use = None if thread_id_to_use is None else req.context.parent_message_id

        agent_started_at = time.perf_counter()
        resolved_agent_name = self._resolved_agent_name(req)
        run_config = self._request_scoped_analyst_config(req, semantic_refresh, decision)
        run_options = {"run_config": run_config} if run_config is not None else {}
        if run_config is not None:
            thread_id_to_use = None
            parent_message_id_to_use = None
        try:
            raw_text, thread_id, raw_payload = self._agent.run_detailed(
                messages,
                agent=None if run_config is not None else resolved_agent_name,
                thread_id=thread_id_to_use,
                parent_message_id=parent_message_id_to_use,
                **run_options,
            )
            observe(
                "agent.invoke",
                (time.perf_counter() - agent_started_at) * 1000,
                agent=resolved_agent_name,
                route=req.context.routing_hint or "unknown",
            )
        except SnowflakeAgentError as exc:
            observe(
                "agent.invoke.failed",
                (time.perf_counter() - agent_started_at) * 1000,
                agent=resolved_agent_name,
                route=req.context.routing_hint or "unknown",
            )
            if (
                self._settings.agent_oversize_retry_v1
                and self._is_agent_oversize_error(exc)
            ):
                emergency_text = self._build_agent_payload(req, emergency=True)
                if emergency_text == user_text:
                    raise AgentPayloadBudgetError(
                        "AGENT_PAYLOAD_REQUIRED_CONTEXT_TOO_LARGE: Cortex rejected "
                        "the already-compacted mandatory request context"
                    ) from exc
                increment("agent.payload.oversize_retry")
                logger.warning(
                    "Retrying Cortex Agent once with emergency payload compaction: "
                    "request_id=%s original_chars=%s retry_chars=%s",
                    req.request_id,
                    len(user_text),
                    len(emergency_text),
                )
                continuity = self._prepare_conversation_continuity(
                    req,
                    emergency_text,
                    force_rollover_reason="remote_payload_limit",
                )
                messages = self._messages_with_continuity(emergency_text, continuity)
                user_text = emergency_text
                payload_attempts.append(payload_audit(
                    prepared_payload, user_text, stage="emergency", messages=messages,
                ))
                self._capture_prompt_artifact(req, messages, payload_attempts[-1])
                raw_text, thread_id, raw_payload = self._agent.run_detailed(
                    messages,
                    agent=None if run_config is not None else self._resolved_agent_name(req),
                    thread_id=None,
                    parent_message_id=None,
                    **run_options,
                )
            elif not self._should_retry_without_thread(exc, thread_id_to_use):
                raise
            else:
                logger.warning(
                    "Checkpointing logical conversation after expired Cortex thread: "
                    "request_id=%s thread_id=%s",
                    req.request_id,
                    thread_id_to_use,
                )
                continuity = self._prepare_conversation_continuity(
                    req,
                    user_text,
                    force_rollover_reason="expired_cortex_thread",
                )
                messages = self._messages_with_continuity(user_text, continuity)
                payload_attempts.append(payload_audit(
                    prepared_payload, user_text, stage="thread_retry", messages=messages,
                ))
                self._capture_prompt_artifact(req, messages, payload_attempts[-1])
                raw_text, thread_id, raw_payload = self._agent.run_detailed(
                    messages,
                    agent=None if run_config is not None else self._resolved_agent_name(req),
                    thread_id=None,
                    parent_message_id=None,
                    **run_options,
                )
        agent_ms = (time.perf_counter() - agent_started_at) * 1000
        parent_message_id = _extract_assistant_message_id(raw_payload)
        response_thread_id = local_thread_id or thread_id
        response_meta = {
            "logical_conversation_id": (
                continuity.logical_conversation_id if continuity else None
            ),
            "thread_segment": continuity.segment_number if continuity else None,
            "thread_rolled_over": continuity.rolled_over if continuity else False,
            "rollover_reason": continuity.rollover_reason if continuity else None,
            "timings_ms": {
                "semantic_context": round(semantic_context_ms, 1),
                "agent": round(agent_ms, 1),
                "total": round((time.perf_counter() - started_at) * 1000, 1),
            },
            "agent_payload": payload_attempts[-1],
            "agent_payload_attempts": payload_attempts,
        }

        if self._uses_exact_context_retrieval(req):
            raw_text, thread_id, raw_payload = self._continue_context_retrieval(req, raw_text, raw_payload, thread_id, seed_messages=messages, run_config=run_config)
            response_thread_id = thread_id or response_thread_id
            parent_message_id = _extract_assistant_message_id(raw_payload) or parent_message_id
        if req.data.intent == Interface.CHAT:
            (
                sub_agent,
                result,
                message,
                warnings,
                error,
                meta,
                status,
                artifact_type,
                artifact,
                semantic_level_achieved,
                semantic_refresh_status,
            ) = self._parse_chat_response(raw_text, raw_payload)
            warnings = self._normalize_response_warnings(warnings)
            final_chat_message = self._sanitize_final_chat_message(message or raw_text.strip())
            if local_thread_id:
                self._store_local_chat_history(
                    thread_id=local_thread_id,
                    messages=messages,
                    assistant_text=final_chat_message or "",
            )
            artifact_type, artifact = self._coerce_chat_artifact(
                req,
                artifact_type=artifact_type,
                artifact=artifact,
                message=final_chat_message,
            )
            response = STTMBuilderResponse.from_invocation(
                req,
                thread_id=response_thread_id,
                parent_message_id=None if local_thread_id else parent_message_id,
                agent=sub_agent,
                result=result,
                message=final_chat_message,
                status=status,
                artifact_type=artifact_type or (
                    STTMArtifactType.SEMANTIC_CONTEXT
                    if semantic_refresh and sub_agent is None and result is None
                    else STTMArtifactType.NONE
                ),
                artifact=artifact if artifact is not None else self._semantic_refresh_to_dict(semantic_refresh),
                semantic_level_achieved=semantic_level_achieved or (
                    semantic_refresh.achieved_level if semantic_refresh else None
                ),
                semantic_refresh_status=semantic_refresh_status or (
                    None if semantic_refresh is None else {
                        "bundle_id": semantic_refresh.bundle_id,
                        "bundle_hash": semantic_refresh.bundle_hash,
                        "bundle_label": semantic_refresh.bundle_label,
                        "requested_level": semantic_refresh.requested_level,
                        "achieved_level": semantic_refresh.achieved_level,
                        "status": semantic_refresh.status,
                        "semantic_view_name": semantic_refresh.semantic_view_name,
                        "promoted": semantic_refresh.promoted,
                        "cache_hit": semantic_refresh.cache_hit,
                        "stale_reason": None,
                    }
                ),
                warnings=warnings,
                error=error,
                meta=self._merge_agent_meta(
                    {**(meta or {}), **response_meta},
                    raw_payload=raw_payload,
                    artifact_type=artifact_type,
                    artifact=artifact,
                ),
            )
            response = self._execute_requested_analyst_delegation(
                req,
                response,
                semantic_refresh=semantic_refresh,
                decision=decision,
            )
            finalized = self._postflight_guard.finalize_sttm_response(self._with_semantic_gap_notice(req, response), decision)
            final_visible_text = self._visible_response_text(finalized)
            artifact_id = self._persist_response_artifact(
                req,
                finalized,
                continuity=continuity,
            )
            self._attach_response_artifact_descriptor(
                finalized,
                artifact_id=artifact_id,
                artifact_type=str(
                    finalized.data.artifact_type.value
                    if finalized.data is not None
                    else "chat"
                ),
            )
            self._complete_conversation_continuity(
                continuity,
                physical_thread_id=response_thread_id,
                user_text=user_text,
                assistant_text=final_visible_text,
            )
            self._persist_continuity_turns(
                req,
                continuity,
                assistant_text=final_visible_text,
            )
            if local_thread_id and final_visible_text != (final_chat_message or ""):
                self._store_local_chat_history(
                    thread_id=local_thread_id,
                    messages=messages,
                    assistant_text=final_visible_text,
                )
            return finalized

        if local_thread_id and req.data.intent == Interface.CHAT:
            self._store_local_chat_history(
                thread_id=local_thread_id,
                messages=messages,
                assistant_text=message or raw_text.strip(),
            )

        (
            sub_agent,
            result,
            message,
            warnings,
            error,
            meta,
            status,
            artifact_type,
            artifact,
            semantic_level_achieved,
            semantic_refresh_status,
        ) = self._parse_envelope(raw_text)
        attach_citations(response_meta["agent_payload"], result)
        warnings = self._normalize_response_warnings(warnings)
        if (
            req.data.intent == Interface.TRANSFORM
            and status == STTMStatus.COMPLETED
            and (not isinstance(result, TransformationResult) or not result.rules)
        ):
            status = STTMStatus.NEEDS_INPUT
            message = (
                "No transformation rule was returned. Select a target mapping and provide "
                "the source columns or business rule needed to generate its SQL expression."
            )
        response = STTMBuilderResponse.from_invocation(
            req,
            thread_id=response_thread_id,
            parent_message_id=None if local_thread_id else parent_message_id,
            agent=sub_agent,
            result=result,
            message=message,
            status=status,
            artifact_type=artifact_type or self._artifact_type_for_response(sub_agent, semantic_refresh),
            artifact=artifact if artifact is not None else self._semantic_refresh_to_dict(semantic_refresh),
            semantic_level_achieved=semantic_level_achieved or (
                semantic_refresh.achieved_level if semantic_refresh else None
            ),
            semantic_refresh_status=semantic_refresh_status or (
                None if semantic_refresh is None else {
                    "bundle_id": semantic_refresh.bundle_id,
                    "bundle_hash": semantic_refresh.bundle_hash,
                    "bundle_label": semantic_refresh.bundle_label,
                    "requested_level": semantic_refresh.requested_level,
                    "achieved_level": semantic_refresh.achieved_level,
                    "status": semantic_refresh.status,
                    "semantic_view_name": semantic_refresh.semantic_view_name,
                    "promoted": semantic_refresh.promoted,
                    "cache_hit": semantic_refresh.cache_hit,
                    "stale_reason": None,
                }
            ),
            warnings=warnings,
            error=error,
            meta=self._merge_agent_meta(
                {**(meta or {}), **response_meta},
                raw_payload=raw_payload,
                artifact_type=artifact_type,
                artifact=artifact,
            ),
        )
        finalized = self._postflight_guard.finalize_sttm_response(self._with_semantic_gap_notice(req, response), decision)
        artifact_id = self._persist_response_artifact(
            req,
            finalized,
            continuity=continuity,
        )
        self._attach_response_artifact_descriptor(
            finalized,
            artifact_id=artifact_id,
            artifact_type=str(
                finalized.data.artifact_type.value
                if finalized.data is not None
                else req.data.intent.value.lower()
            ),
        )
        self._complete_conversation_continuity(
            continuity,
            physical_thread_id=response_thread_id,
            user_text=user_text,
            assistant_text=message or raw_text,
        )
        self._persist_continuity_turns(
            req,
            continuity,
            assistant_text=message or raw_text,
        )
        return finalized

    def _capture_prompt_artifact(self, req, messages, audit) -> None:
        if not getattr(self._settings, "agent_prompt_artifact_capture", False):
            return
        if not req.actor or not req.actor.user_id:
            audit["capture_status"] = "excluded_missing_owner"
            return
        try:
            audit["prompt_artifact_id"] = self._conversation_memory.record_agent_artifact(
                request_id=req.request_id,
                session_id=req.context.session_id,
                thread_id=None,
                agent_name=self._resolved_agent_name(req),
                artifact_type="agent_prompt_diagnostic",
                artifact_status="draft",
                payload={"messages": messages, "audit": dict(audit)},
                created_by=req.actor.user_id,
                project_id=req.context.project_id,
                mapping_id=req.context.sttm_id,
                semantic_bundle_id=req.context.semantic_bundle_id,
                access_fingerprint=hashlib.sha256(req.actor.user_id.encode("utf-8")).hexdigest(),
            )
            audit["capture_status"] = "stored"
        except Exception:
            audit["capture_status"] = "error"
            logger.warning("Prompt diagnostic persistence failed for request_id=%s", req.request_id)

    def _persist_response_artifact(
        self,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
        *,
        continuity: ConversationPreparation | None = None,
        artifact_id: str | None = None,
    ) -> str | None:
        """Persist attributable runtime output without adding request-path retrieval."""
        try:
            response_payload = response.model_dump(mode="json", exclude_none=True)
            used_inference_ids: set[str] = set()
            used_recommendation_ids: set[str] = set()
            learning = req.context.learning_context
            result = response_payload.get("data", {}).get("result") or response_payload.get("result") or {}
            candidates: list[dict[str, Any]] = []
            if isinstance(result, dict):
                mappings = result.get("mappings")
                if isinstance(mappings, dict):
                    candidates.extend(item for item in mappings.values() if isinstance(item, dict))
                rules = result.get("rules")
                if isinstance(rules, list):
                    candidates.extend(item for item in rules if isinstance(item, dict))
            for item in candidates:
                used_inference_ids.update(str(value) for value in item.get("used_inference_ids") or [] if value)
                used_recommendation_ids.update(str(value) for value in item.get("used_recommendation_ids") or [] if value)
            workspace = req.context.workspace_context
            execution = req.context.execution_context
            context_key = (execution.context_key if execution else None) or (workspace.context_key if workspace else "")
            snapshot_id = (execution.snapshot_id if execution else None) or (workspace.snapshot_id if workspace else None)
            artifact_type = str(
                response_payload.get("data", {}).get("artifact_type")
                or response_payload.get("artifact_type")
                or req.data.intent.value.lower()
            )
            agent_name = str(
                response_payload.get("data", {}).get("agent")
                or response_payload.get("agent")
                or self._resolved_agent_name(req)
            )
            artifact_id = self._conversation_memory.record_agent_artifact(
                request_id=req.request_id,
                session_id=req.context.session_id,
                thread_id=response.thread_id,
                agent_name=agent_name,
                artifact_type=artifact_type,
                payload=response_payload,
                artifact_status="completed" if response.error is None else "failed",
                entity_type="sttm",
                entity_ids=[value for value in (req.context.project_id, req.context.sttm_id) if value],
                semantic_bundle_id=req.context.semantic_bundle_id,
                semantic_bundle_hash=(
                    req.context.semantic_bundle_hash
                    or (workspace.semantic.bundle_hash if workspace else None)
                ),
                summary=str(response.message or "")[:1000],
                created_by=req.actor.user_id if req.actor else None,
                logical_conversation_id=(
                    continuity.logical_conversation_id
                    if continuity is not None
                    else req.context.logical_conversation_id
                ),
                thread_segment=(
                    continuity.segment_number
                    if continuity is not None
                    else req.context.physical_thread_segment
                ),
                project_id=req.context.project_id,
                mapping_id=req.context.sttm_id,
                access_fingerprint=hashlib.sha256(
                    str(req.actor.user_id if req.actor else "").encode("utf-8")
                ).hexdigest(),
                context_key=context_key,
                snapshot_id=snapshot_id,
                retrieved_inference_ids=(
                    execution.retrieved_inference_ids if execution else
                    learning.retrieved_inference_ids if learning else []
                ),
                retrieved_recommendation_ids=(
                    execution.retrieved_recommendation_ids if execution else
                    learning.retrieved_recommendation_ids if learning else []
                ),
                used_inference_ids=sorted(used_inference_ids),
                used_recommendation_ids=sorted(used_recommendation_ids),
                artifact_id=artifact_id,
            )
            for recommendation_id in used_recommendation_ids:
                self._conversation_memory.record_fir_recommendation_outcome(
                    recommendation_id=recommendation_id,
                    outcome_type="used",
                    context_key=context_key,
                    snapshot_id=snapshot_id,
                    request_id=req.request_id,
                    artifact_id=artifact_id,
                    user_id=req.actor.user_id if req.actor else None,
                    payload={"agent_name": agent_name, "artifact_type": artifact_type},
                )
            return artifact_id
        except Exception as exc:  # pragma: no cover - FIR audit cannot block an agent response
            logger.warning("Could not persist FIR-attributed agent artifact for %s: %s", req.request_id, exc)
            return None

    @staticmethod
    def _attach_response_artifact_descriptor(
        response: STTMBuilderResponse,
        *,
        artifact_id: str | None,
        artifact_type: str,
    ) -> None:
        """Expose the durable handle without copying the artifact body into metadata."""

        if not artifact_id:
            return
        descriptors = list(response.meta.get("artifact_refs") or [])
        descriptor = {
            "artifact_id": artifact_id,
            "artifact_type": artifact_type,
            "summary": str(response.message or "")[:240],
        }
        if not any(
            isinstance(item, dict) and item.get("artifact_id") == artifact_id
            for item in descriptors
        ):
            descriptors.append(descriptor)
        response.meta = {**response.meta, "artifact_refs": descriptors}

    async def invoke_auto_map_parallel(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        governance_decision: GovernanceDecision | None = None,
        max_concurrency: int | None = None,
    ) -> STTMBuilderResponse:
        if req.data.intent != Interface.AUTO_MAP:
            return self.invoke(req, governance_decision=governance_decision)

        if req.meta.get("auto_map_fast_path") == "v1":
            from app.core.automap_batch import validate_fast_request
            validate_fast_request(req, self._settings)
        attributes = list(req.data.attributes or [])
        logger.info(
            "Auto-map worker invoking source-mapping agent once for request_id=%s "
            "batch_attributes=%s",
            req.request_id,
            len(attributes),
        )
        response = await asyncio.to_thread(
            self.invoke,
            req,
            governance_decision=governance_decision,
        )
        if req.meta.get("auto_map_fast_path") == "v1":
            # The source decision may select a grounded binding that still needs
            # an expression. Run the existing specialist within the same request
            # deadline and retain other valid targets if its rule fails.
            admitted = response._auto_map_admitted_evidence
            response._auto_map_admitted_evidence = {}
            if admitted:
                from app.schema.sttm_builder import LearningContext
                from app.core.automap_policy import POLICY_VERSION
                categories = {}
                for evidence in admitted.values():
                    for category, records in evidence.items():
                        categories.setdefault(category, []).extend(records)
                learning = req.context.learning_context or LearningContext()
                req = req.model_copy(update={"context": req.context.model_copy(update={
                    "learning_context": learning.model_copy(update={
                        "automap_policy_version": POLICY_VERSION,
                        "target_mapping_patterns": categories.get("canonical_target_mapping_patterns", []),
                        "search_evidence": categories.get("search_hydrated_evidence", []),
                        "mandatory_negative_evidence": categories.get("mandatory_negative_evidence", []),
                    }),
                })})
            if req.meta.get('automap_rules_policy') == 'rules-v2' and response._auto_map_execution:
                store = response._auto_map_execution[1]
                if store is not None:
                    from app.schema.sttm_builder import LearningContext
                    learning = req.context.learning_context or LearningContext()
                    records = {}
                    for target in store.targets:
                        for groups in (store.evidence.get(target, {}), store.available_evidence.get(target, {})):
                            for category, entries in groups.items():
                                if 'target_mapping_patterns' in category:
                                    for record in entries:
                                        records[json.dumps(record, sort_keys=True, default=str)] = record
                    req = req.model_copy(update={'context': req.context.model_copy(update={
                        'learning_context': learning.model_copy(update={'target_mapping_patterns': list(records.values())})})})
            started = time.perf_counter()
            response = await self._apply_complex_transformation_stage(
                req, response, governance_decision=governance_decision)
            final_result = response.data.result if response.data else response.result
            retrieval = (response.meta or {}).get("auto_map_retrieval") or {}
            if isinstance(final_result, SourceMappingResult):
                for audit in retrieval.get("targets") or []:
                    mapping = final_result.mappings.get(audit.get("target"))
                    if mapping and isinstance(audit.get("coverage"), dict):
                        audit["coverage"]["transformation_validated"] = (
                            mapping.transformation_classification != "unresolved"
                            and (mapping.transformation_classification not in {"complex", "simple_multi_source"}
                                 or bool(mapping.preprocessing_rule)))
                        audit["status"] = ("unresolved" if mapping.transformation_classification == "unresolved"
                                           else "grounded")
            response.meta = {**(response.meta or {}), "auto_mapping_worker": {
                "batch_strategy": "deterministic_context_final_mapping_v1",
                "complex_transformation_deferred": False,
                "selective_transformation_stage_ms": round((time.perf_counter() - started) * 1000, 1),
            }}
            response._auto_map_execution = None
            from app.core.automap_row_candidates import validate_row_candidates
            return await asyncio.to_thread(validate_row_candidates, self, req, response)
        response = await self._repair_direct_source_bindings(
            req, response, governance_decision=governance_decision,
        )
        if req.meta.get("auto_map_defer_complex_transformation") and not req.meta.get("auto_map_sheet_review_v1"):
            response.meta = {
                **(response.meta or {}),
                "auto_mapping_worker": {
                    **((response.meta or {}).get("auto_mapping_worker") or {}),
                    "complex_transformation_deferred": True,
                },
            }
            return response
        transformation_started = time.perf_counter()
        admitted = response._auto_map_admitted_evidence
        response._auto_map_admitted_evidence = {}
        if admitted:
            from app.schema.sttm_builder import LearningContext
            from app.core.automap_policy import POLICY_VERSION
            categories = {}
            for evidence in admitted.values():
                for category, records in evidence.items():
                    categories.setdefault(category, []).extend(records)
            learning = req.context.learning_context or LearningContext()
            req = req.model_copy(update={"context": req.context.model_copy(update={
                "learning_context": learning.model_copy(update={
                    "automap_policy_version": POLICY_VERSION,
                    "target_mapping_patterns": categories.get("canonical_target_mapping_patterns", []),
                    "search_evidence": categories.get("search_hydrated_evidence", []),
                    "mandatory_negative_evidence": categories.get("mandatory_negative_evidence", []),
                }),
            })})
        response = await self._apply_complex_transformation_stage(
            req,
            response,
            governance_decision=governance_decision,
        )
        transformation_ms = (time.perf_counter() - transformation_started) * 1000
        response.meta = {
            **(response.meta or {}),
            "auto_mapping_worker": {
                **((response.meta or {}).get("auto_mapping_worker") or {}),
                "delegated": True,
                "batch_size": len(attributes),
                "batch_strategy": "single_agent_batch_call",
                "legacy_per_attribute_parallelism": False,
                "requested_max_concurrency": max_concurrency
                or self._settings.auto_mapping_worker_max_concurrency,
                "selective_transformation_stage_ms": round(transformation_ms, 1),
            },
        }
        response._auto_map_execution = None
        from app.core.automap_row_candidates import validate_row_candidates
        return await asyncio.to_thread(validate_row_candidates, self, req, response)

    def _auto_map_retrieval_enabled(self, req) -> bool:
        from app.core.automap_batch import fast_project_enabled
        return req.data.intent == Interface.AUTO_MAP and bool(
            getattr(getattr(self, "_settings", None), "automap_context_retrieval_v1", False)
            or (req.meta.get("auto_map_fast_path") == "v1"
                and fast_project_enabled(self._settings, req.context.project_id))
        )

    def _discover_auto_map_evidence(self, req, target):
        return self._discover_auto_map_batch_evidence(req, [target])[target]

    def _discover_auto_map_batch_evidence(self, req, targets, *, query_refinement="", excluded_ids=None, followup=False):
        from app.core.automap_prepared_evidence import trusted
        artifact = trusted(req)
        if artifact is not None and not followup:
            from app.core.automap_prepared_evidence import discovery_for
            return discovery_for(artifact, targets)
        from app.core.mapping_search import MappingSearchService
        from app.core.target_mapping_patterns import TargetMappingPatternService
        from app.core.mapping_context import _targets
        source_tables = [table.qualified_name for table in req.context.source_tables or []]
        target_table = req.context.target_table.qualified_name
        settings = self._settings
        draft_generation = (getattr(req, 'meta', None) or {}).get('automap_generation_policy') == 'draft-v3'
        retrieval_failures = []
        learning = req.context.learning_context
        linked_projects = list(learning.linked_project_ids) if learning else []
        linked_mappings = list(learning.linked_mapping_ids) if learning else []
        if linked_mappings:
            loaded = {item.precedent_sttm_id for item in learning.mapping_precedents}
            if set(linked_mappings) - loaded:
                if not draft_generation:
                    raise ContextPrecedentUnavailableError("Selected precedent is unavailable; Search cannot replace it")
                retrieval_failures.append({'service': 'selected_precedent', 'error_type': 'ContextPrecedentUnavailableError'})
            covered = {str(row.get("target_column") or "").upper()
                       for item in learning.mapping_precedents
                       if str(item.compatibility or "").lower() not in {"incompatible", "rejected", "different_target"}
                       for row in item.mappings}
            pending = list(targets) if followup else [target for target in targets if target.upper() not in covered]
            result = {target: {"evidence": {}, "source_candidates": {},
                              "diagnostics": {"status": "available", "route": "selected_precedent"}}
                      for target in targets if not followup and target.upper() in covered}
            if not pending:
                return result
            targets = pending
        else:
            result = {}
        columns, profiles, relationships, derived = self._learning_retrieval_inputs(req, target_table)
        from app.core.automap_learning_pack import AutoMapLearningPack
        learning_pack_service = AutoMapLearningPack(self._session, settings)
        try:
            learning_packs = learning_pack_service.retrieve(
                targets=targets, target_table=target_table,
                logical_target_key=(req.context.mapping_intent or {}).get("logical_target_key"),
                project_id=req.context.project_id, linked_projects=linked_projects,
                crm=(req.context.mapping_intent or {}).get("source_system_key"), source_columns=columns,
                excluded_pattern_ids=(excluded_ids or ()) if followup else ())
        except Exception as exc:
            if not draft_generation:
                raise
            learning_packs = {}
            retrieval_failures.append({'service': 'fir_learning_pack', 'error_type': type(exc).__name__})
            logger.warning('Auto-map FIR pack unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)
        fallback_targets = [target for target in targets if not any(
            item.get("applicable") for item in learning_packs.get(target.upper(), []))]
        discovery = {"evidence": [], "source_candidates": {},
                     "diagnostics": {"status": "available", "canonical_read_count": 1, "route": "deterministic_sql"}}
        if fallback_targets:
            from app.core.automap_search_fallback import discover_fallback
            try:
                discovery = discover_fallback(self,
                    project_id=str(req.context.project_id or ""), sttm_id=req.context.sttm_id,
                    target_table=target_table, target_columns=fallback_targets, source_tables=source_tables,
                    linked_project_ids=linked_projects,
                    target_profiles={item.target_attribute: " ".join(filter(None, [item.target_description, item.target_data_type,
                        (req.context.mapping_intent or {}).get("source_system_key")])) for item in req.data.attributes or []},
                    query_refinement=query_refinement, excluded_ids=excluded_ids)
            except Exception as exc:
                if not draft_generation:
                    raise
                retrieval_failures.append({'service': 'fir_search', 'error_type': type(exc).__name__})
                logger.warning('Auto-map fallback search unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)
        # Exact hydration uses the existing lifecycle and source/type/grain checks.
        # Do not turn on the unrelated global hybrid projection flag.
        trusted_settings = settings.model_copy(update={"automap_hybrid_context_v1": True})
        admission_diagnostics = {}
        try:
            patterns = TargetMappingPatternService(self._session, trusted_settings).retrieve_candidates(
                target_table=target_table, target_columns=targets, source_tables=source_tables,
                source_columns=columns, source_column_profiles=profiles,
                relationship_paths=[json.dumps(item.model_dump(mode="json") if hasattr(item, "model_dump") else item,
                                              sort_keys=True, default=str) for item in relationships],
                derived_outputs=[str(item.name) for item in derived if getattr(item, "name", None)],
                workspace_context_id=req.context.sttm_id, project_id=req.context.project_id,
                linked_project_ids=req.context.learning_context.linked_project_ids if req.context.learning_context else [],
                crm_family=(req.context.mapping_intent or {}).get("source_system_key"),
                logical_target_key=(req.context.mapping_intent or {}).get("logical_target_key"),
                additional_pattern_ids=[item["pattern_id"] for item in discovery["evidence"] if item.get("pattern_id")],
                limit=4 * len(targets), per_column_limit=4,
                discovered_only=False,
                eligible_pattern_ids=list({item["pattern_id"] for pack in learning_packs.values() for item in pack}
                    | {item["pattern_id"] for item in discovery["evidence"] if item.get("pattern_id")}),
                hard_positive_limit=True, allow_incomplete_metadata=draft_generation,
                diagnostics=admission_diagnostics,
            )
        except Exception as exc:
            if not draft_generation:
                raise
            patterns = []
            retrieval_failures.append({'service': 'fir_candidate_hydration', 'error_type': type(exc).__name__})
            logger.warning('Auto-map FIR hydration unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)
        latest_ids = {item["pattern_id"] for pack in learning_packs.values() for item in pack}
        fallback_ids = {item["pattern_id"] for item in discovery["evidence"] if item.get("pattern_id")}
        patterns = [item for item in patterns if item.pattern.pattern_id in latest_ids | fallback_ids
                    or item.pattern.provenance.get("evidence_class") == "explicit_user_correction"]
        if any(item.get("pattern_id") for item in discovery["evidence"]):
            discovery["diagnostics"]["canonical_read_count"] += 1
        for target in targets:
            evidence = {}
            relevant = [item.model_dump(mode="json") for item in patterns
                        if target.upper() in _targets(item.model_dump(mode="json"))]
            pack = {item["pattern_id"]: item for item in learning_packs.get(target.upper(), [])}
            for item in relevant:
                pattern = item.get("pattern") or item
                metadata = pack.get(pattern.get("pattern_id"))
                if metadata:
                    item.update({key: metadata[key] for key in ("tier", "matching_columns", "published_at", "mandatory")})
                    item['applicable'] = (item.get('decision') != 'unresolved' and not metadata.get('legacy_guidance')
                        and not (metadata.get('mapping_recipe') or {}).get('requires_current_project_value'))
                    item['guidance_only'] = not item['applicable']
                else:
                    item.update(tier="T4", applicable=False, guidance_only=True)
            present = {(item.get("pattern") or item).get("pattern_id") for item in relevant}
            # Shape-only recipes remain useful without offering historical source names.
            for identifier, metadata in pack.items():
                if identifier not in present:
                    relevant.append({"pattern": metadata, "tier": metadata["tier"],
                        "applicable": False, "guidance_only": True, "decision": "unresolved"})
            if relevant:
                evidence["canonical_target_mapping_patterns"] = relevant
            records = [item for item in discovery["evidence"] if item.get("knowledge_type") != "recipe"
                       and target in item.get("target_columns", [])]
            if records:
                evidence["search_hydrated_evidence"] = records
            from app.core.automap_policy import select_positive_evidence
            selected = select_positive_evidence(evidence, limit=settings.automap_learning_initial_limit)
            diagnostics = {**discovery["diagnostics"], "route": "deterministic_sql" if pack else "search_fallback_guidance",
                "reason": "agent_requested_followup" if followup else
                          "uncovered_or_incompatible_precedent_target" if linked_mappings else
                          "selected_project_has_no_applicable_published_mapping" if linked_projects else
                          "no_selected_mapping_precedent"}
            if retrieval_failures:
                diagnostics.update(status='degraded', errors=retrieval_failures,
                    warning='Historical retrieval is incomplete; review drafts against business rules.')
            diagnostics['retrieved_recipe_count'] = learning_pack_service.counts.get(target.upper(), len(pack))
            diagnostics['initial_recipe_count'] = len(pack)
            diagnostics['deferred_recipe_count'] = max(0, diagnostics['retrieved_recipe_count'] - len(pack))
            diagnostics['available_evidence_count'] = sum(len(records) for records in evidence.values())
            diagnostics['admitted_evidence_count'] = sum(len(records) for records in selected.values())
            diagnostics['deferred_evidence_count'] = max(0, diagnostics['available_evidence_count'] - diagnostics['admitted_evidence_count'])
            diagnostics["inapplicable_pattern_count"] = sum(item.decision == "unresolved" for item in patterns
                if target.upper() in _targets(item.model_dump(mode="json")))
            diagnostics["recipe_admission"] = {"exclusions": [item for item in admission_diagnostics.get("exclusions", [])
                if not item.get("target_column") or str(item["target_column"]).upper() == target.upper()]}
            if diagnostics["status"] == "available" and not selected and not discovery["source_candidates"]:
                diagnostics["status"] = "no_applicable_match"
            result[target] = {"evidence": selected,
                             "available_evidence": evidence,
                             "source_candidates": {target: discovery["source_candidates"].get(target.upper(), [])},
                             "diagnostics": diagnostics}
        return result

    def _invoke_retrieval_auto_map(self, req, decision=None):
        from app.core.automap_batch import invoke_batch
        return invoke_batch(self, req, decision)

    def _validate_auto_map_candidate(self, req, store, attribute, candidate):
        from app.core.automap_retrieval import target_name
        target = target_name(attribute.target_attribute)
        if req.meta.get('automap_generation_policy') == 'draft-v3':
            from app.core.automap_rule_handoff import review_optional_history_claims
            review_optional_history_claims(candidate, recipe_ids=store.recipe_ids(target), precedent_ids=store.precedent_ids(target))
        missing = store.missing_reads(target, candidate.model_dump(mode="json"))
        supplied_ids = store.evidence_ids(target)
        used_ids = set(candidate.used_learning_ids + candidate.used_inference_ids
                       + candidate.used_recommendation_ids + candidate.override_evidence)
        if used_ids - supplied_ids:
            missing.append("cited evidence was not retrieved for this target")
        if candidate.pattern_decision in {"accept_exact_precedent", "adapt_pattern"} and not (
            set(candidate.used_learning_ids) & store.recipe_ids(target)
        ):
            missing.append("unsupported pattern decision: cite a retrieved recipe or remove the precedent claim")
        if candidate.precedent_decision == "accept_precedent" and not (
            candidate.precedent_mapping_id and candidate.precedent_mapping_id in store.precedent_ids(target)
        ):
            missing.append("unsupported linked precedent decision: cite the retrieved linked mapping or remove the precedent claim")
        expression = candidate.preprocessing_rule
        rule_type = str(candidate.preprocessing_rule_type or "DIRECT").upper()
        awaiting_expression = not expression and candidate.transformation_classification in {"complex", "simple_multi_source"}
        if req.meta.get("auto_map_fast_path") == "v1":
            if not req.context.relation_graph or not req.context.relation_graph.nodes:
                missing.append("Fast mapping requires a complete prepared relation graph for compilation")
            # The separate rule stage will produce and compile an expression.
            # The source bindings themselves must already validate here.
            from app.core.mapping_sql import MappingSqlService
            placeholders = MappingSqlService._placeholders_in_sql(expression or "")
            if candidate.mapping_mode == "attribute":
                placeholders.add("$" + str(candidate.attribute_name or "").lstrip("$"))
            resolved = MappingSqlService._resolved_placeholder_sql(req.context.relation_graph)
            if any(value.upper() not in resolved for value in placeholders):
                missing.append("Fast mapping requires authoritative current-project Values; unresolved placeholders are not executable")
        if candidate.mapping_mode == "attribute":
            placeholder = "$" + str(candidate.attribute_name or "").lstrip("$")
            bindings = [binding for binding in (req.context.relation_graph.value_bindings if req.context.relation_graph else [])
                        if binding.value.upper() == placeholder.upper()]
            if (not bindings or candidate.constant_value != placeholder
                    or not candidate.value_binding_ids
                    or any(not any(value in {binding.binding_id, binding.value} for binding in bindings)
                           for value in candidate.value_binding_ids)):
                missing.append("Project Value name, placeholder and approved binding must agree")
                missing.append(f"Project Value requested placeholder={placeholder}; matching binding IDs="
                               + ",".join(binding.binding_id for binding in bindings))
        if expression and rule_type in {"DIRECT", "IDENTITY"} and expression.strip().upper() not in {"DIRECT", "IDENTITY"}:
            missing.append("Direct mapping cannot contain an unvalidated expression")
        if expression and rule_type not in {"DIRECT", "IDENTITY", "VALUE"}:
            try:
                expression_tree = sqlglot.parse_one(expression, read="snowflake")
                references = [column.sql(dialect="snowflake") for column in expression_tree.find_all(exp.Column)]
                missing.extend(store.missing_reads(target, {"source_attributes": references}))
            except Exception as error:
                from app.core.automap_feedback import CompilerFeedbackError, compiler_feedback
                if req.meta.get("auto_map_fast_path") == "v1":
                    raise CompilerFeedbackError(compiler_feedback(error)) from None
                missing.append("unparseable attribute expression")
        if req.context.relation_graph and req.context.relation_graph.nodes and not missing:
            from app.core.mapping_sql import MappingSqlService
            from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
            graph = req.context.relation_graph
            workspace = req.context.workspace_context
            driving = (workspace.driving_relation_id if workspace else None) or (
                req.context.driving_table.qualified_name if req.context.driving_table else graph.nodes[0].relation_id
            )
            scope_error = self._outer_source_binding_error(graph, driving,
                [*candidate.source_attributes, *candidate.source_dependencies,
                 expression if rule_type not in {'DIRECT','IDENTITY','VALUE'} else None])
            if scope_error:
                missing.append(scope_error)
                return sorted(set(missing))
            try:
                selected_value = next((binding.value for binding in graph.value_bindings
                    if binding.resolved_value is not None and {binding.binding_id, binding.value} & set(candidate.value_binding_ids)), None)
                compiled = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
                    relation_graph=graph, driving_relation_id=driving,
                    validate_with_explain=False, allow_unresolved_placeholders=True,
                    mappings=[MappingSqlMappingItem(
                        target_column=target, target_type=attribute.target_data_type,
                        source_columns=candidate.source_attributes, source_dependencies=candidate.source_dependencies,
                        mapping_mode=candidate.mapping_mode, constant_value=candidate.constant_value,
                        attribute_name=candidate.attribute_name, value_binding_ids=candidate.value_binding_ids,
                        # Validate the selected namespace/connectivity now; the
                        # specialist must still supply and compile the final rule.
                        expression=(candidate.source_attributes[0] if awaiting_expression and candidate.source_attributes else
                                    selected_value if awaiting_expression and req.meta.get('automap_generation_policy') == 'draft-v3' else
                                    expression if rule_type not in {"DIRECT", "IDENTITY", "VALUE"} else None),
                        rule="Direct" if awaiting_expression else rule_type,
                    )],
                ))
                if not compiled.ready:
                    from app.core.automap_feedback import CompilerFeedbackError, compiler_feedback
                    if req.meta.get("auto_map_fast_path") == "v1":
                        raise CompilerFeedbackError(compiler_feedback(code="mapping_not_ready", stage="mapping_compile",
                            issues=compiled.warnings))
                    missing.append("compiler binding validation: mapping has no ready executable binding")
            except ValueError as exc:
                from app.core.automap_feedback import CompilerFeedbackError, compiler_feedback
                if req.meta.get("auto_map_fast_path") == "v1":
                    if isinstance(exc, CompilerFeedbackError):
                        raise
                    raise CompilerFeedbackError(compiler_feedback(exc, stage="mapping_compile")) from None
                missing.append("compiler binding validation:" + json.dumps(compiler_feedback(exc, stage="mapping_compile")))
        return sorted(set(missing))

    def _auto_map_analyst_evidence(self, req, delegation, decision, snapshot_hash):
        """Use only an already prepared bundle; never alter a shared native tool."""
        allowed = {"tool", "snapshot_hash", "question", "requires_actual_rows", "reason"}
        if set(delegation) - allowed or delegation.get("snapshot_hash") != snapshot_hash:
            raise ValueError("Invalid Analyst snapshot delegation")
        if delegation.get("requires_actual_rows") is not True or not isinstance(delegation.get("question"), str):
            raise ValueError("Analyst requires an explicit actual-data question")
        # This specialist must not refresh or create a bundle during a tool read.
        semantic = self._prefetched_semantic_refresh(req)
        if semantic is not None and not (semantic.semantic_view_name or getattr(semantic, "semantic_model_yaml", None)):
            record = self._semantic_context_service.get_bundle(bundle_id=req.context.semantic_bundle_id)
            if record and record.get("semantic_model_yaml"):
                from types import SimpleNamespace
                semantic = SimpleNamespace(bundle_id=record["bundle_id"],
                                           semantic_view_name=record.get("semantic_view_name"),
                                           semantic_model_yaml=record["semantic_model_yaml"])
        if semantic is None or not (semantic.semantic_view_name or getattr(semantic, "semantic_model_yaml", None)):
            raise ValueError("Prepared Analyst semantics are unavailable")
        question = delegation["question"].strip()
        if not question or len(question) > 4000:
            raise ValueError("Invalid Analyst question")
        self._model_guard.assert_model_target_allowed(operation=req.operation.value, target="analyst", decision=decision)
        generated = self._analyst.ask(question=question, semantic_view=semantic.semantic_view_name,
                                     semantic_model_yaml=None if semantic.semantic_view_name else semantic.semantic_model_yaml)
        self._model_guard.guard_sql(generated.sql, decision)
        # Validate structure and selected physical scope before any execution.
        # guard_sql records approval requirements; it is not an execution gate.
        if any(warning.code == "UNSAFE_SQL_ARTIFACT" for warning in decision.warnings):
            raise ValueError("Analyst SQL requires approval and was not executed")
        statements = [statement for statement in sqlglot.parse(generated.sql or "", read="snowflake") if statement]
        if len(statements) != 1 or not isinstance(statements[0], exp.Query):
            raise ValueError("Analyst must return one read-only query")
        if any(isinstance(node, (exp.DML, exp.DDL)) for node in statements[0].walk()):
            raise ValueError("Analyst query contains a nested mutation")
        from sqlglot.optimizer.scope import traverse_scope
        allowed_tables = {table.qualified_name.upper() for table in req.context.source_tables or []}
        if req.context.target_table:
            allowed_tables.add(req.context.target_table.qualified_name.upper())
        for scope in traverse_scope(statements[0]):
            for _, (_, source) in scope.selected_sources.items():
                if isinstance(source, exp.Table):
                    physical = ".".join(part.name for part in source.parts).upper()
                    if physical not in allowed_tables:
                        raise ValueError("Analyst query references a table outside the selected workspace")
            if any(isinstance(node, exp.Anonymous) for node in scope.expression.walk()):
                raise ValueError("Unrecognized Analyst function requires explicit review")
        rows = self._preview_sql_rows(generated.sql)
        return {"tool": "CORTEX_ANALYST", "request_id": generated.request_id,
                "semantic_bundle_id": semantic.bundle_id, "sql": generated.sql,
                "rows": rows, "data_result_obtained": bool(rows), "warnings": generated.warnings}

    @staticmethod
    def _outer_source_binding_error(graph, driving_id, references):
        """Fresh proposals must select outer bindings, never internal lineage."""
        from app.core.mapping_sql import MappingSqlService
        from sqlglot import exp, parse_one
        nodes = {node.relation_id: node for node in graph.nodes}
        driver = next((key for key in nodes if key.upper() == str(driving_id).upper()), None)
        if driver is None:
            return None
        connected, _ = MappingSqlService._connected_join_plan(driver, set(nodes), graph.edges)
        aliases = {key: node.alias for key, node in nodes.items()}
        alias_to_id = {value.upper(): key for key, value in aliases.items()}
        for reference in references:
            if not reference:
                continue
            try:
                text = MappingSqlService._normalize_expression_namespace(reference, nodes, aliases)
                tree = parse_one(text, read='snowflake')
                for column in tree.find_all(exp.Column):
                    relation = MappingSqlService._resolve_dependency_relation(
                        column.sql(dialect='snowflake'), nodes, alias_to_id,
                        nodes_by_upper_id={key.upper(): key for key in nodes})
                    if relation is None:
                        return f'Unknown or ambiguous outer source binding: {reference}.'
                    if relation not in connected:
                        return f'{reference} refers to CTE-internal or disconnected lineage. Select an exposed output of {nodes[driver].alias} or an explicitly connected outer relation.'
            except Exception:
                return f'Cannot verify source binding {reference} against the outer CTE graph.'
        return None

    async def _repair_direct_source_bindings(
        self, req: STTMBuilderEnvelopeRequest, response: STTMBuilderResponse,
        *, governance_decision: GovernanceDecision | None,
    ) -> STTMBuilderResponse:
        """One mapping-agent retry for Direct picks outside the prepared graph."""
        from app.core.mapping_sql import MappingSqlService
        from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem

        graph = req.context.relation_graph
        result = response.data.result if response.data else response.result
        if not graph or not graph.nodes or not isinstance(result, SourceMappingResult):
            return response
        workspace = req.context.workspace_context
        driving_id = (workspace.driving_relation_id if workspace else None) or (
            req.context.driving_table.qualified_name if req.context.driving_table else None
        )

        def binding_error(target, mapping):
            if mapping.mapping_mode != "source" or not mapping.source_attributes:
                return None
            scope_error = self._outer_source_binding_error(graph, driving_id,
                [*mapping.source_attributes, *mapping.source_dependencies])
            if scope_error:
                return scope_error
            if str(mapping.preprocessing_rule_type or "DIRECT").upper() not in {"", "DIRECT", "IDENTITY"}:
                return None  # The expression stage validates non-Direct rules.
            try:
                MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
                    relation_graph=graph, driving_relation_id=driving_id,
                    validate_with_explain=False, allow_unresolved_placeholders=True,
                    mappings=[MappingSqlMappingItem(target_column=target.rsplit(".", 1)[-1],
                        source_columns=mapping.source_attributes, source_dependencies=mapping.source_dependencies,
                        rule="Direct")],
                ))
            except ValueError as exc:
                return str(exc)
            return None

        failures = {}
        for target, mapping in result.mappings.items():
            error = binding_error(target, mapping)
            if error:
                failures[target] = error
            elif mapping.mapping_mode == "source" and mapping.candidate_source_attributes and (
                not mapping.source_attributes or mapping.transformation_classification == "unresolved"
            ):
                failures[target] = mapping.unmatched_reason or (
                    "A candidate shortlist exists but no executable selection was returned. "
                    "Select the strongest supported valid binding; retain uncertainty for review."
                )
        if not failures:
            return response
        by_leaf = {target.rsplit(".", 1)[-1].upper(): target for target in failures}
        attributes = []
        for attribute in req.data.attributes or []:
            target = by_leaf.get(attribute.target_attribute.rsplit(".", 1)[-1].upper())
            if target:
                attributes.append(attribute.model_copy(update={"selected_mapping": {
                    **result.mappings[target].model_dump(mode="json"), "compiler_error": failures[target],
                }}))
        repaired_mappings = {}
        if attributes:
            repair_req = req.model_copy(update={"data": req.data.model_copy(update={
                "attributes": attributes,
                "message": "Repair only these source bindings. Each selected_mapping includes its compiler_error. "
                "Choose the strongest semantically supported output from the connected prepared relations, "
                "even if uncertain, with honest confidence and reasoning. Keep other plausible choices in "
                "candidate_source_attributes for user review. Do not add joins, bypass prepared CTE "
                "filters/deduplication, or invent columns. If no valid binding exists, return the target "
                "unresolved while retaining its candidate shortlist and validation blocker.",
            })})
            try:
                repaired = await asyncio.to_thread(self.invoke, repair_req, governance_decision=governance_decision)
                repaired_result = repaired.data.result if repaired.data else repaired.result
                if isinstance(repaired_result, SourceMappingResult) and not repaired.error:
                    from app.core.automap_row_candidates import requested_target
                    if not req.meta.get("_automap_deadline") or time.time() < req.meta["_automap_deadline"]:
                        repaired_mappings = {target.rsplit(".", 1)[-1].upper(): mapping
                            for target, mapping in repaired_result.mappings.items()
                            if requested_target(attributes, target) is not None}
            except Exception as exc:
                logger.warning("Direct source repair failed request_id=%s error_type=%s", req.request_id, type(exc).__name__)
        from app.core.automap_row_candidates import retain_proposals
        merged = dict(result.mappings)
        for target, error in failures.items():
            candidate = repaired_mappings.get(target.rsplit(".", 1)[-1].upper())
            original = result.mappings[target]
            alternatives = list(dict.fromkeys([
                *(candidate.candidate_source_attributes if candidate else []),
                *original.candidate_source_attributes,
                *original.source_attributes,
                *(candidate.source_attributes if candidate else []),
            ]))
            if (candidate and candidate.mapping_mode == "source" and candidate.source_attributes
                    and candidate.transformation_classification != "unresolved"
                    and str(candidate.preprocessing_rule_type or "DIRECT").upper() in {"", "DIRECT", "IDENTITY"}
                    and not binding_error(target, candidate)):
                merged[target] = candidate.model_copy(update={
                    "candidate_source_attributes": [source for source in alternatives
                                                    if source not in candidate.source_attributes],
                })
            else:
                merged[target] = original.model_copy(update={
                    "candidate_source_attributes": alternatives,
                    "transformation_classification": "unresolved",
                    "unmatched_reason": f"Source binding does not fit the prepared graph: {error}",
                })
            merged[target] = retain_proposals(merged[target], original, *([candidate] if candidate else []))
        validated = SourceMappingResult(mappings=merged)
        return response.model_copy(update={"result": validated,
            "data": response.data.model_copy(update={"result": validated}) if response.data else None,
            "meta": {**response.meta, "direct_source_repair": {"target_count": len(failures), "max_attempts": 1}}})

    async def _apply_complex_transformation_stage(
        self,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
        *,
        governance_decision: GovernanceDecision | None,
    ) -> STTMBuilderResponse:
        result = response.data.result if response.data else response.result
        if not isinstance(result, SourceMappingResult):
            return response

        workspace = req.context.workspace_context
        driving_id = (workspace.driving_relation_id if workspace else None) or (
            req.context.driving_table.qualified_name if req.context.driving_table else None
        )
        from app.core.automap_batch import fast_target_identity as identity
        from app.core.automap_retrieval import target_name
        mappings_by_leaf = {
            identity(target): mapping
            for target, mapping in result.mappings.items()
        }

        execution = response._auto_map_execution
        runtime, evidence_store = execution if execution is not None else (None, None)
        fast = req.meta.get("auto_map_fast_path") == "v1"
        admitted_ids = {identity(str(item.get("target", ""))): set(item.get("evidence_ids") or [])
                        for item in (response.meta.get("auto_map_retrieval") or {}).get("targets", []) if item.get("target")}

        draft_rules = req.meta.get('automap_rules_policy') == 'rules-v2'
        from app.core.automap_rule_handoff import rule_route, custom_rule, definition_hash
        routes = {}

        def apply_rule(selected, rule):
            updated = selected.model_copy(update={
                "preprocessing_rule": rule.rule, "preprocessing_rule_type": "Custom",
                "transformation_confidence_score": getattr(rule, 'confidence_score', None),
                "preprocessing_nl_rule": rule.description, "transformation_classification": "complex",
                "source_dependencies": sorted(set(rule.source_dependencies)),
                "source_attributes": sorted(set(rule.source_dependencies)),
                "value_binding_ids": sorted(set(rule.value_binding_ids)),
                "used_learning_ids": sorted({*selected.used_learning_ids, *rule.learning_evidence}),
                "used_inference_ids": sorted({*selected.used_inference_ids, *rule.used_inference_ids}),
                "used_recommendation_ids": sorted({*selected.used_recommendation_ids, *rule.used_recommendation_ids}),
                "override_evidence": sorted({*selected.override_evidence, *rule.override_evidence}),
            })
            if draft_rules:
                updated = updated.model_copy(update={'mapping_mode': 'source', 'constant_value': None,
                    'attribute_name': None, 'rule_stage': selected.rule_stage,
                    'rule_stage_reason': 'Custom expression completed by AGT_TRANSFORMATION_RULE.'})
            if draft_rules and evidence_store is not None:
                from app.core.automap_rule_handoff import review_optional_history_claims, match_retrieved_recipe
                match_retrieved_recipe(updated, evidence_store, target_name(rule.target_attribute), req.context)
                review_optional_history_claims(updated, recipe_ids=evidence_store.recipe_ids(target_name(rule.target_attribute)),
                    precedent_ids=evidence_store.precedent_ids(target_name(rule.target_attribute)))
            return updated

        from app.core.automap_row_candidates import retain_proposals, record_proposal
        retained_rules = {}
        rule_feedback = {}
        specialist_reviews = []
        review_targets = set(response.meta.get("automap_evidence_review_only_targets") or [])

        def usable_rule(rule, *, specialist=False) -> bool:
            key = identity(rule.target_attribute)
            selected = mappings_by_leaf.get(key)
            from app.core.automap_feedback import compiler_feedback
            def reject(code, stage, *, error=None, issues=()):
                rule_feedback[key] = compiler_feedback(error, code=code, stage=stage, issues=issues)
                return False
            if selected is None:
                return False
            if specialist:
                if draft_rules and rule.rule_candidate_id != selected.rule_candidate_id:
                    return reject('candidate_identity_mismatch', 'rule_identity')
                allowed = (evidence_store.evidence_ids(target_name(rule.target_attribute)) if evidence_store else
                           admitted_ids.get(key, set()) | set(selected.used_learning_ids)
                           | set(selected.used_inference_ids) | set(selected.used_recommendation_ids)
                           | set(selected.override_evidence))
                cited = set(rule.learning_evidence + rule.used_inference_ids + rule.used_recommendation_ids + rule.override_evidence)
                if not cited <= allowed:
                    return reject("invalid_evidence_citation", "rule_evidence", issues=[
                        "A returned evidence ID is not authorized for this target. Use only evidence_citation_contract.allowed_evidence_ids; labels, source-agent names and example tags are not citations."])
            if not valid_attribute_expression(rule.rule):
                try:
                    if rule.rule:
                        sqlglot.parse_one(rule.rule, read="snowflake")
                except Exception as error:
                    return reject("invalid_expression", "rule_parse", error=error)
                return reject("invalid_expression", "rule_parse", issues=["Provide one executable scalar SQL expression, not a label or query."])
            if not req.context.relation_graph:
                return True
            from app.core.mapping_sql import MappingSqlService
            from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
            try:
                selected = mappings_by_leaf.get(identity(rule.target_attribute))
                from app.core.mapping_sql import MappingSqlService
                if specialist and fast:
                    references = sorted({column.sql(dialect="snowflake") for column in
                        sqlglot.parse_one(rule.rule, read="snowflake").find_all(exp.Column)})
                    rule.source_dependencies = references
                    rule.value_binding_ids = [binding.binding_id for binding in req.context.relation_graph.value_bindings
                        if binding.value.upper() in {value.upper() for value in MappingSqlService._placeholders_in_sql(rule.rule)}]
                if self._outer_source_binding_error(req.context.relation_graph, driving_id,
                    [rule.rule, *rule.source_dependencies, *(selected.source_attributes if selected else [])]):
                    return reject("out_of_scope_binding", "rule_binding", issues=["Use only exposed selected source bindings and dependencies."])
                if (getattr(getattr(self, "_settings", None), "automap_context_retrieval_v1", False)
                        or req.meta.get("auto_map_fast_path") == "v1") and selected:
                    from app.core.automap_transform import expression_within_selection
                    payload = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
                    if not expression_within_selection(payload, selected, rule):
                        return reject("selection_mismatch", "rule_binding", issues=["Rule references must remain within the selected sources, dependencies and approved Values."])
                compiled = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
                    relation_graph=req.context.relation_graph,
                    driving_relation_id=driving_id,
                    mappings=[MappingSqlMappingItem(target_column=target_name(rule.target_attribute),
                        source_columns=selected.source_attributes if selected else [],
                        expression=rule.rule, source_dependencies=rule.source_dependencies,
                        value_binding_ids=rule.value_binding_ids)],
                    validate_with_explain=False, allow_unresolved_placeholders=True,
                ))
                if compiled is not None and not compiled.ready:
                    return reject("mapping_not_ready", "rule_compile", issues=compiled.warnings)
                if specialist and evidence_store is not None:
                    attribute = next((item for item in req.data.attributes or []
                                      if identity(item.target_attribute) == key), None)
                    missing = self._validate_auto_map_candidate(req, evidence_store, attribute, apply_rule(selected, rule)) if attribute else ["Target is outside this batch"]
                    if missing:
                        return reject("missing_required_evidence", "rule_validation", issues=missing)
                return True
            except Exception as error:
                rule_feedback[key] = getattr(error, "feedback", None) or compiler_feedback(error, stage="rule_compile")
                return False
        # Candidate retention must not strand a source selection before its SQL stage.
        # Promote only a real current binding awaiting an expression, never a shortlist.
        for target, mapping in list(result.mappings.items()):
            if (mapping.source_attributes or mapping.mapping_mode in {'constant', 'attribute'}
                    or valid_attribute_expression(mapping.preprocessing_rule)):
                continue
            candidates = list(mapping.candidates)
            pending = next((candidate for candidate in candidates
                if (candidate.source_attributes or (draft_rules and candidate.value_binding_ids))
                and (custom_rule(candidate) if draft_rules else (candidate.transformation_classification in {'complex', 'simple_multi_source'}
                     or str(candidate.preprocessing_rule_type or '').upper() not in {'', 'DIRECT', 'IDENTITY', 'VALUE'}))
                and not self._outer_source_binding_error(req.context.relation_graph, driving_id,
                    [*candidate.source_attributes, *candidate.source_dependencies])
                ), None) if req.context.relation_graph else None
            if pending is not None and pending is not mapping:
                from app.schema.sttm_builder import MappingOption
                selected = mapping.model_copy(update={key: getattr(pending, key) for key in MappingOption.model_fields})
                result.mappings[target] = selected
                mappings_by_leaf[identity(target)] = selected
        handoff_errors = {}
        if draft_rules and evidence_store is not None:
            from app.core.automap_retrieval import scoped_record
            for target, mapping in result.mappings.items():
                if not custom_rule(mapping):
                    continue
                leaf = target_name(target)
                try:
                    existing = evidence_store.evidence[leaf].get('canonical_target_mapping_patterns', [])
                    available = evidence_store.available_evidence.get(leaf, {}).get('canonical_target_mapping_patterns', [])
                    records = {json.dumps(record, sort_keys=True, default=str): record for record in [*existing, *available]}
                    evidence_store.evidence[leaf]['canonical_target_mapping_patterns'] = list(records.values())
                    # Read exact stored bodies, using the same frozen registry. No
                    # second Search, guessed bindings or model quote certification.
                    for operation in evidence_store.required_operations(leaf, mapping.model_dump(mode='json')):
                        query = {'tool': 'AUTO_MAP_CONTEXT', 'snapshot_hash': evidence_store.snapshot_hash, **operation}
                        while True:
                            page = evidence_store.read(query, max_bytes=32768)
                            if not page.get('next_cursor'):
                                break
                            query = {**query, 'cursor': page['next_cursor']}
                except Exception as exc:
                    handoff_errors[target] = 'Exact historical evidence could not be prepared (' + type(exc).__name__ + '); other targets continue.'
        attributes_by_target = {identity(attribute.target_attribute): attribute for attribute in req.data.attributes or []}
        complex_targets: list[str] = []
        for target, mapping in result.mappings.items():
            if draft_rules:
                from app.core.automap_row_candidates import candidate_identity
                route, reason = rule_route(mapping, req.context)
                mapping.rule_stage, mapping.rule_stage_reason = route, reason
                mapping.rule_candidate_id = definition_hash(mapping, req.context)
                if target in handoff_errors:
                    mapping.rule_stage, mapping.rule_stage_reason = 'missing_dependency', handoff_errors[target]
                elif route == 'rule_pending':
                    scope_error = self._outer_source_binding_error(req.context.relation_graph, driving_id,
                        [*mapping.source_attributes, *mapping.source_dependencies]) if req.context.relation_graph else 'Source graph unavailable'
                    from app.core.mapping_sql import MappingSqlService
                    needed_values = {value.upper() for text in (mapping.preprocessing_rule, mapping.constant_value)
                        for value in MappingSqlService._placeholders_in_sql(text or '')}
                    resolved_values = {binding.value.upper() for binding in req.context.relation_graph.value_bindings
                        if binding.resolved_value is not None} if req.context.relation_graph else set()
                    approved_ids = {identifier for binding in req.context.relation_graph.value_bindings
                        if binding.resolved_value is not None for identifier in (binding.binding_id, binding.value)} if req.context.relation_graph else set()
                    if scope_error or needed_values - resolved_values or set(mapping.value_binding_ids) - approved_ids:
                        mapping.rule_stage = 'missing_dependency'
                        mapping.rule_stage_reason = scope_error or 'Required current-project Firm Value is unavailable.'
                    else:
                        complex_targets.append(target)
                routes[target] = {'status': mapping.rule_stage, 'reason': mapping.rule_stage_reason,
                    'candidate_id': mapping.rule_candidate_id}
                continue
            classification = mapping.transformation_classification
            rule_type = str(mapping.preprocessing_rule_type or "").upper()
            needs_expression = (classification in {"complex", "simple_multi_source"}
                                or rule_type not in {"", "DIRECT", "IDENTITY", "VALUE"}
                                or len(mapping.source_attributes) > 1)
            if needs_expression and (mapping.source_attributes or mapping.preprocessing_rule or mapping.mapping_mode in {'constant', 'attribute'}):
                from types import SimpleNamespace
                supplied = SimpleNamespace(rule=mapping.preprocessing_rule,
                    target_attribute=target, source_dependencies=mapping.source_dependencies,
                    value_binding_ids=mapping.value_binding_ids)
                if not usable_rule(supplied):
                    complex_targets.append(target)
        if not complex_targets:
            if draft_rules:
                response.meta = {**response.meta, 'transformation_stage': {'target_count': 0,
                    'planned_rule_targets': 0, 'target_outcomes': routes}}
            return response

        transform_attributes = []
        for target in complex_targets:
            original = attributes_by_target.get(identity(target))
            mapping = result.mappings[target]
            if original is None:
                continue
            source_mappings: list[AttributeRef] = []
            for source in mapping.source_attributes:
                qualifier, separator, column = source.rpartition(".")
                parts = qualifier.split(".") if separator else []
                if len(parts) == 3 and column:
                    source_mappings.append(
                        AttributeRef(
                            table=TableRef(database=parts[0], schema=parts[1], table=parts[2]),
                            attribute=column,
                        )
                    )
            transform_attributes.append(
                original.model_copy(update={"source_mappings": source_mappings or None,
                    "selected_mapping": mapping.model_dump(mode="json")})
            )
        if not transform_attributes:
            return response

        transform_req = req.model_copy(
            update={
                "operation": STTMOperation.TRANSFORM,
                "context": req.context.model_copy(
                    update={
                        "routing_hint": _INTENT_ROUTE_TRANSFORMATION,
                        "prepared_context_hash": req.context.prepared_context_hash,
                    }
                ),
                "data": req.data.model_copy(
                    update={
                        "intent": Interface.TRANSFORM,
                        "intent_route": _INTENT_ROUTE_TRANSFORMATION,
                        "attributes": transform_attributes,
                        "message": (
                            "Generate one executable attribute-level expression for every requested target. "
                            "data.attributes.selected_mapping contains exact selected sources, intent, "
                            "source/value dependencies and evidence. Preserve those selections and "
                            "prepared CTEs, joins, grain and current-project placeholders. "
                            "Return SQL, never labels such as CAST or Concatenate. "
                            "Copy selected_mapping.rule_candidate_id into each returned rule.rule_candidate_id. "
                            "Use the supplied target-specific FIR, current bindings and approved Firm Value placeholders."
                        ),
                    }
                ),
                "meta": {**req.meta, "auto_map_stage": "complex_transformation",
                         "_automap_fast_specialist": fast},
            }
        )
        valid_rules = {}
        stage_warnings = []
        failure = None
        failure_detail = None
        target_outcomes = {}

        def check_deadline():
            if fast:
                if runtime is None:
                    raise ValueError("Owning Auto-map runtime is unavailable; legacy fallback is forbidden")
                runtime.check_active()
            if req.meta.get("_automap_deadline") and time.time() >= req.meta["_automap_deadline"] - 5:
                raise TimeoutError("Auto-map transformation deadline reached")

        async def invoke_rules(request):
            check_deadline()
            if fast and draft_rules and runtime is not None:
                from app.core.automap_fast_transport import STAGE_CALL_LIMITS
                from app.core.automap_rule_handoff import RuleStageBudgetExhausted
                if (runtime.next_call_index > getattr(runtime, '_max_calls', 8)
                        or getattr(runtime, '_stage_calls', {}).get('transformation_rule', 0) >= STAGE_CALL_LIMITS['transformation_rule']):
                    raise RuleStageBudgetExhausted('Existing transformation call allowance exhausted before dispatch')
            if fast:
                from app.core.automap_specialist import invoke_specialist
                answer = await asyncio.to_thread(invoke_specialist, self, request, runtime)
            else:
                answer = await asyncio.to_thread(self.invoke, request, governance_decision=governance_decision)
            check_deadline()
            review_targets.update(answer.meta.get("automap_evidence_review_only_targets") or [])
            if answer.meta.get("specialist_evidence_review"):
                specialist_reviews.append(answer.meta["specialist_evidence_review"])
            return answer

        def keep_valid(answer, requested):
            if answer.error or (answer.data and answer.data.status == STTMStatus.FAILED):
                return
            rules = answer.data.result if answer.data else answer.result
            if not isinstance(rules, TransformationResult):
                return
            # Reject ambiguous duplicate rules rather than selecting by order.
            counts = {}
            for rule in rules.rules:
                key = identity(rule.target_attribute)
                counts[key] = counts.get(key, 0) + 1
            for rule in rules.rules:
                from app.core.automap_row_candidates import requested_target
                if requested_target(req.data.attributes or [], rule.target_attribute) is None:
                    continue
                key = identity(rule.target_attribute)
                check_deadline()
                if key in requested and counts[key] == 1 and key not in valid_rules:
                    selected = mappings_by_leaf[key]
                    captured = apply_rule(selected, rule)
                    retained_rules[key] = retain_proposals(captured, retained_rules.get(key, selected))
                valid = (key in requested and counts[key] == 1 and key not in valid_rules
                         and usable_rule(rule, specialist=True))
                check_deadline()
                if key in requested and counts[key] == 1 and key not in valid_rules:
                    feedback = rule_feedback.get(key) or {}
                    captured = apply_rule(mappings_by_leaf[key], rule)
                    retained_rules[key] = record_proposal(captured, retained_rules.get(key),
                        messages=[] if valid else [json.dumps(feedback, separators=(",", ":"))],
                        category="validation" if "evidence" in str(feedback) else
                            "source" if any(code in str(feedback) for code in ("out_of_scope_binding", "selection_mismatch")) else "sql")
                if valid:
                    valid_rules[key] = rule

        oversized_targets = set()
        preparation_failed_targets = set()
        preparation_failures = []

        from app.core.automap_specialist_context import TransformationPreparationError
        async def invoke_group(request):
            try:
                answer = await invoke_rules(request)
            except (AgentPayloadBudgetError, TransformationPreparationError) as error:
                if req.meta.get('automap_generation_policy') != 'draft-v3':
                    raise
                attributes = request.data.attributes or []
                preparation_error = not isinstance(error, AgentPayloadBudgetError)
                if preparation_error and len(attributes) <= 1:
                    preparation_failed_targets.update(identity(item.target_attribute) for item in attributes)
                    preparation_failures.append({**error.diagnostic, 'targets': [item.target_attribute for item in attributes]})
                    return
                # This exception occurs before dispatch. Split exact packets without
                # replaying transport failures or raising the shared call allowance.
                if len(attributes) <= 1:
                    oversized_targets.update(identity(item.target_attribute) for item in attributes)
                    return
                middle = len(attributes) // 2
                for group in (attributes[:middle], attributes[middle:]):
                    await invoke_group(request.model_copy(update={'data': request.data.model_copy(update={'attributes': group})}))
                return
            stage_warnings.extend(answer.warnings)
            keep_valid(answer, {identity(item.target_attribute) for item in request.data.attributes or []})

        try:
            await invoke_group(transform_req)
            missing = [item for item in transform_attributes
                       if identity(item.target_attribute) not in valid_rules
                       and identity(item.target_attribute) not in oversized_targets
                       and identity(item.target_attribute) not in preparation_failed_targets]
            if missing:
                repair_req = transform_req.model_copy(update={"data": transform_req.data.model_copy(update={
                    "attributes": missing,
                    "message": (transform_req.data.message or "") + " Repair these missing or invalid expressions only. Compiler feedback: "
                        + json.dumps({item.target_attribute: rule_feedback.get(identity(item.target_attribute), {}) for item in missing}, separators=(",", ":")),
                })})
                await invoke_group(repair_req)
        except Exception as exc:
            failure = type(exc).__name__
            from app.core.automap_evidence_blocks import EvidenceBlockError
            if isinstance(exc, EvidenceBlockError):
                failure_detail = "Transformation evidence incomplete: " + str(exc)
            elif isinstance(exc, AgentPayloadBudgetError):
                failure_detail = "Transformation context framing exceeded the configured message allowance."
            else:
                failure_detail = "Transformation execution stopped (" + failure + "); no uncertain model call was replayed."
            import traceback
            preparation_diagnostic = {
                'code': 'transformation_preparation_failed' if not valid_rules else 'transformation_incomplete',
                'error_type': failure,
                'locations': [{'file': frame.filename.rsplit('/', 1)[-1], 'function': frame.name, 'line': frame.lineno}
                              for frame in traceback.extract_tb(exc.__traceback__)[-8:]],
                'targets': [item.target_attribute for item in transform_attributes],
            }
            logger.warning("Complex transformation stage failed request_id=%s diagnostic=%s",
                           req.request_id, json.dumps(preparation_diagnostic, separators=(',', ':')))
            response.meta = {**(response.meta or {}), 'transformation_preparation_diagnostic': preparation_diagnostic}
            stage_warnings.append(ApiWarning(code="AUTO_MAP_TRANSFORMATION_STAGE_SKIPPED",
                message="Some transformation expressions could not be completed; validated results were retained."))
        if preparation_failures:
            response.meta = {**(response.meta or {}), 'transformation_preparation_failures': preparation_failures}
        # Each initial rule was validated before any repair. A failed or late
        # repair cannot erase it or promote a late response into this collection.
        rule_by_target = valid_rules
        merged = dict(result.mappings)
        for target in complex_targets:
            rule = rule_by_target.get(identity(target))
            if rule is None:
                feedback = rule_feedback.get(identity(target))
                detail = ("Exact transformation evidence exceeds the per-call allowance; narrow this target's context and retry."
                          if identity(target) in oversized_targets else
                          'Transformation preparation failed for this target; verify its current source and Value bindings. No model request was submitted.'
                          if identity(target) in preparation_failed_targets else failure_detail) or ("Compiler feedback: " + json.dumps(feedback, separators=(",", ":")) if feedback else
                    "The specialist did not supply a valid expression after bounded repair.")
                target_outcomes[target] = "transformation_preparation_failed" if identity(target) in preparation_failed_targets else "evidence_block_incomplete" if failure else "invalid_expression"
                merged[target] = merged[target].model_copy(update={
                    "transformation_classification": "unresolved",
                    "unmatched_reason": "A valid transformation expression is still required for this target. " + detail,
                    **({'rule_stage': 'budget_deferred' if identity(target) in oversized_targets or failure == 'RuleStageBudgetExhausted' else 'execution_failed' if failure or identity(target) in preparation_failed_targets else 'rule_pending',
                        'rule_stage_reason': detail} if draft_rules else {}),
                })
                merged[target] = retain_proposals(merged[target], retained_rules.get(identity(target), result.mappings[target]))
                continue
            current = merged[target]
            completed = apply_rule(current, rule)
            if draft_rules:
                completed.rule_stage = 'rule_complete'
                completed.rule_definition_hash = definition_hash(completed, req.context)
            merged[target] = record_proposal(completed,
                retain_proposals(current, retained_rules.get(identity(target), current)))
        merged_result = SourceMappingResult(mappings=merged)
        unresolved = any(mapping.transformation_classification == "unresolved" for mapping in merged.values())
        merged_data = response.data.model_copy(update={"result": merged_result,
            "status": STTMStatus.NEEDS_INPUT if unresolved else response.data.status}) if response.data else None
        retrieval_meta = dict(response.meta.get("auto_map_retrieval") or {})
        diagnostics = None
        if fast and runtime is not None:
            from app.core.automap_batch import _fast_failure_diagnostics
            diagnostics = _fast_failure_diagnostics(runtime, runtime.next_call_index - 1) if failure else None
            stage_calls = getattr(runtime, "_stage_calls", {})
            requests = getattr(runtime, '_requests', {})
            traces = [(getattr(runtime, '_request_stages', {}).get(index), request.runtime_trace)
                for index, request in requests.items() if getattr(request, 'runtime_trace', None) is not None]
            if traces:
                actual_posts = sum(trace.model_post_attempts for _, trace in traces)
                retrieval_meta.update(planned_model_call_count=runtime.next_call_index - 1,
                    actual_model_post_count=actual_posts, model_call_count=actual_posts,
                    completed_model_response_count=sum(trace.terminal_responses for _, trace in traces),
                    **{key:sum(trace.model_post_attempts for kind,trace in traces if kind == stage)
                       for key,stage in (('source_model_call_count','source_mapping'),
                           ('evidence_review_call_count','evidence_review'),('transformation_model_call_count','transformation_rule'))})
            else:
                retrieval_meta.update(source_model_call_count=stage_calls.get("source_mapping", retrieval_meta.get("model_call_count", 0)),
                                      evidence_review_call_count=stage_calls.get("evidence_review", 0),
                                      transformation_model_call_count=stage_calls.get("transformation_rule", 0),
                                      model_call_count=runtime.next_call_index - 1)
        rule_submissions = None
        if runtime is not None:
            scheduled_rules = getattr(runtime, '_stage_calls', {}).get('transformation_rule', 0)
            rule_requests = [request for index, request in getattr(runtime, '_requests', {}).items()
                if getattr(runtime, '_request_stages', {}).get(index) == 'transformation_rule']
            traces = [request.runtime_trace for request in rule_requests if getattr(request, 'runtime_trace', None) is not None]
            rule_submissions = sum(trace.model_post_attempts for trace in traces) if traces else (0 if scheduled_rules == 0 else None)
        return response.model_copy(
            update={
                "data": merged_data,
                "result": merged_result,
                "warnings": [*response.warnings, *stage_warnings],
                "meta": {
                    **response.meta,
                    "automap_evidence_review_only_targets": sorted(review_targets),
                    **({"auto_map_retrieval": retrieval_meta} if retrieval_meta else {}),
                    "transformation_stage": {
                        "target_count": len(transform_attributes),
                        "agent": "AGT_TRANSFORMATION_RULE",
                        "validated_rules": len(valid_rules),
                        "failure_type": failure,
                        "compiler_feedback": {target: rule_feedback[identity(target)] for target in complex_targets if identity(target) in rule_feedback},
                        "specialist_evidence_reviews": specialist_reviews,
                        "target_outcomes": ({target: {'status': mapping.rule_stage,
                            'reason': mapping.rule_stage_reason, 'candidate_id': mapping.rule_candidate_id}
                            for target, mapping in merged.items()} if draft_rules else target_outcomes),
                        "planned_rule_targets": len(transform_attributes),
                        "scheduled_rule_calls": getattr(runtime, '_stage_calls', {}).get('transformation_rule', 0) if runtime else 0,
                        "actual_rule_model_submissions": rule_submissions,
                        "total_model_calls": runtime.next_call_index - 1 if fast and runtime is not None else None,
                        **({"fast_diagnostics": diagnostics} if diagnostics else {}),
                    },
                },
            }
        )

    @staticmethod
    def _auto_map_preparation_identity(value):
        context = value.context.model_dump(mode="json", exclude={"execution_context", "prepared_context_hash"})
        return hashlib.sha256(json.dumps({"context": context,
            "actor": value.actor.model_dump(mode="json") if value.actor else None},
            sort_keys=True, default=str).encode()).hexdigest()

    def _finalize_auto_map_preparation(self, req):
        """Seal server-owned execution context after evidence/Values assembly."""
        from app.core.automap_policy import preparation_hash
        if req.context.execution_context is not None and req.context._automap_finalization == self._auto_map_preparation_identity(req):
            return req
        prepared = attach_agent_execution_context(req, self._conversation_memory)
        # The runtime snapshot belongs in execution_context; keep authored workspace bytes stable.
        prepared.context.workspace_context = req.context.workspace_context
        if prepared.context.execution_context is None:
            from app.core.automap_batch import _FastInvariantError
            raise _FastInvariantError("execution_context_missing", "Auto-map execution context was not prepared")
        prepared.context.prepared_context_hash = preparation_hash(prepared.context)
        prepared.context._automap_finalization = self._auto_map_preparation_identity(prepared)
        return prepared

    def prepare_auto_map_request(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderEnvelopeRequest:
        """Resolve and validate one semantic bundle before worker fan-out.

        Also enriches the request with comprehensive learning context from FIR.
        """
        req = self._with_intent_route(req)
        if req.data.intent != Interface.AUTO_MAP:
            return req
        if (req.context.execution_context is not None
                and req.context._automap_finalization == self._auto_map_preparation_identity(req)):
            return req
        from app.core.automap_prepared_evidence import reuse
        reused = reuse(req)
        if reused is not None:
            return self._finalize_auto_map_preparation(reused)
        draft_generation = req.meta.get('automap_generation_policy') == 'draft-v3'
        semantic_started = time.perf_counter()
        try:
            sanitized = self._sanitize_request_semantic_context(req)
            from app.core.automap_fast_context import hydrate_authored_cte_graph
            sanitized = hydrate_authored_cte_graph(sanitized)
        except Exception as exc:
            if not draft_generation:
                raise
            sanitized = req.model_copy(update={'context': req.context.model_copy(update={
                'semantic_bundle_id': None, 'semantic_bundle_hash': None,
                'semantic_view_name': None, 'semantic_context': None})})
            sanitized.warnings = [*sanitized.warnings, ApiWarning(code='AUTO_MAP_SEMANTIC_PREPARATION_UNAVAILABLE',
                message='Semantic preparation is unavailable; draft generation will use the current source inventory.')]
            logger.warning('Auto-map semantic preparation unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)

        def resolve_semantics():
            selected_relationships = list(sanitized.context.relationships or [])
            try:
                prepared, semantic_refresh = self._with_semantic_context(sanitized)
            except SemanticRelationshipInvalidError as exc:
                # Cortex Analyst requires a provably unique right-hand relationship,
                # while source mapping can still reason over an explicit selected join.
                # Build the table/column semantic context without publishing the join,
                # then restore the join for AGT_SOURCE_MAPPING and FIR evidence.
                semantic_only = sanitized.model_copy(
                    update={
                        "context": sanitized.context.model_copy(
                            update={"relationships": []}
                        )
                    }
                )
                prepared, semantic_refresh = self._with_semantic_context(semantic_only)
                prepared = prepared.model_copy(
                    update={
                        "context": prepared.context.model_copy(
                            update={"relationships": selected_relationships}
                        ),
                        "warnings": [
                            *prepared.warnings,
                            ApiWarning(
                                code="AUTO_MAP_RELATIONSHIP_NOT_PUBLISHED",
                                message=(
                                    "Selected joins were passed directly to source mapping, "
                                    "but were omitted from the Cortex Analyst semantic view "
                                    f"because uniqueness could not be proven: {exc}"
                                ),
                                field="context.relationships",
                            ),
                        ],
                        "meta": {
                            **prepared.meta,
                            "auto_map_relationship_mode": "direct_selected_relationships",
                        },
                    }
                )
            if semantic_refresh is None and not self._should_bypass_semantic_refresh(prepared):
                raise SemanticAssetNotFoundError(
                    "Auto-map requires selected source/target tables with published semantic assets."
                )
            return prepared, semantic_refresh

        try:
            prepared, semantic_refresh = resolve_semantics()
        except Exception as exc:
            if not draft_generation:
                raise
            prepared, semantic_refresh = sanitized, None
            prepared = prepared.model_copy(update={'warnings': [*prepared.warnings,
                ApiWarning(code='AUTO_MAP_SEMANTICS_UNAVAILABLE',
                    message='Stored semantics could not be loaded. Drafts use current source definitions and require business review.')],
                'meta': {**prepared.meta, 'automap_semantics_unavailable': True}})
            logger.warning('Auto-map semantics unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)

        semantic_ms = (time.perf_counter() - semantic_started) * 1000
        learning_started = time.perf_counter()
        prepared = self._with_learning_context(prepared)
        learning_ms = (time.perf_counter() - learning_started) * 1000
        prepared = self._finalize_auto_map_preparation(prepared)
        execution = prepared.context.execution_context
        settings = getattr(self, "_settings", None)
        return prepared.model_copy(
            update={
                "meta": {
                    **prepared.meta,
                    "agent_spec_hashes": {
                        "AGT_SOURCE_MAPPING": getattr(
                            settings, "agent_spec_source_mapping_sha256", ""
                        ),
                        "AGT_TRANSFORMATION_RULE": getattr(
                            settings, "agent_spec_transformation_rule_sha256", ""
                        ),
                    },
                    "context_diagnostics": {
                        "context_hash": prepared.context.prepared_context_hash,
                        "semantic_bundle_id": prepared.context.semantic_bundle_id,
                        "semantic_bundle_label": prepared.context.semantic_bundle_label,
                        "semantic_view_name": prepared.context.semantic_view_name,
                        "retrieved_evidence_ids": execution.evidence_ids if execution else [],
                        "retrieved_recommendation_ids": (
                            execution.retrieved_recommendation_ids if execution else []
                        ),
                        "retrieved_precedent_ids": (
                            prepared.context.learning_context.linked_mapping_ids
                            if prepared.context.learning_context
                            else []
                        ),
                        "timings_ms": {
                            "semantic_refresh": round(semantic_ms, 2),
                            "precedent_and_fir_retrieval": round(learning_ms, 2),
                        },
                    },
                }
            }
        )

    def _with_learning_context(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderEnvelopeRequest:
        """Enrich request with comprehensive learning context from FIR."""
        if req.meta.get("auto_map_stage") == "complex_transformation":
            return req
        if self._auto_map_retrieval_enabled(req):
            from app.core.automap_policy import POLICY_VERSION, preparation_hash
            learning = req.context.learning_context
            if (learning and learning.automap_policy_version == POLICY_VERSION
                    and req.context.prepared_context_hash == preparation_hash(req.context)):
                return req
            if learning is None or learning.automap_policy_version != POLICY_VERSION:
                try:
                    learning = self._learning_service.get_auto_map_context(
                        project_id=str(req.context.project_id or ""), sttm_id=req.context.sttm_id,
                        target_columns=[item.target_attribute for item in req.data.attributes or []],
                        target_table=req.context.target_table.qualified_name if req.context.target_table else "",
                    )
                except Exception as exc:
                    if req.meta.get('automap_generation_policy') != 'draft-v3':
                        raise
                    from app.schema.sttm_builder import LearningContext
                    learning = (learning or LearningContext()).model_copy(update={
                        'automap_policy_version': POLICY_VERSION,
                        'search_diagnostics': {'status': 'degraded', 'error_type': type(exc).__name__}})
                    req = req.model_copy(update={'warnings': [*req.warnings,
                        ApiWarning(code='AUTO_MAP_FIR_CONTEXT_UNAVAILABLE',
                            message='Some FIR context could not be loaded; review drafts against prior business decisions.')],
                        'meta': {**req.meta, 'automap_fir_context_unavailable': True}})
                    logger.warning('Auto-map FIR preparation unavailable request_id=%s error_type=%s', req.request_id, type(exc).__name__)
            graph = self._with_project_firm_values(req.context.relation_graph, str(req.context.project_id or ""))
            context = req.context.model_copy(update={
                "learning_context": learning, "relation_graph": graph,
            })
            prepared_hash = preparation_hash(context)
            return req.model_copy(update={"context": context.model_copy(update={"prepared_context_hash": prepared_hash}),
                "meta": {**req.meta, "prepared_context_hash": prepared_hash, "learning_context_prepared": True}})
        if req.context.prepared_context_hash and req.context.learning_context is not None:
            return req
        try:
            project_id = req.context.project_id or ""
            source_tables = [
                f"{t.database}.{t.schema}.{t.table}"
                for t in (req.context.source_tables or [])
            ]
            target_table = ""
            if req.context.target_table:
                t = req.context.target_table
                target_table = f"{t.database}.{t.schema}.{t.table}"
            target_columns = [
                attr.target_attribute
                for attr in (req.data.attributes or [])
            ]
            workspace = req.context.workspace_context
            target_agent = {
                Interface.AUTO_MAP: "AGT_SOURCE_MAPPING",
                Interface.TRANSFORM: "AGT_TRANSFORMATION_RULE",
                Interface.CHAT: "AGT_STTM_BUILDER",
            }[req.data.intent]
            (
                source_columns,
                source_column_profiles,
                relationships,
                derived_sources,
            ) = self._learning_retrieval_inputs(req, target_table)

            learning_context = self._learning_service.get_comprehensive_learning_context(
                project_id=project_id,
                source_tables=source_tables,
                target_table=target_table,
                target_columns=target_columns,
                mapping_intent=req.context.mapping_intent,
                target_profiles={
                    str(column.get("name")): str(column.get("business_meaning") or column.get("summary") or column.get("description") or "")
                    for item in req.context.semantic_context or []
                    if self._table_qualified_name(item.table.model_dump(mode="json")) == target_table
                    and isinstance(item.semantic_model, dict)
                    for column in item.semantic_model.get("attributes") or [] if isinstance(column, dict)
                },
                sttm_id=req.context.sttm_id,
                context_key=workspace.context_key if workspace else None,
                source_set_hash=workspace.source_set_hash if workspace else None,
                derived_set_hash=workspace.derived_set_hash if workspace else None,
                milestone=workspace.milestone if workspace else None,
                target_agent=target_agent,
                source_columns=source_columns,
                source_column_profiles=source_column_profiles,
                relationship_paths=[
                    json.dumps(
                        item.model_dump(mode="json") if hasattr(item, "model_dump") else item,
                        sort_keys=True,
                        default=str,
                    )
                    for item in relationships
                ],
                derived_outputs=[
                    str(item.name)
                    for item in derived_sources
                    if getattr(item, "name", None)
                ],
                logical_target_key=optional_identifier(
                    (req.context.mapping_intent or {}).get("logical_target_key")
                    if isinstance(req.context.mapping_intent, dict)
                    else ""
                ),
                crm_family=optional_identifier(
                    (req.context.mapping_intent or {}).get("source_system_key")
                    if isinstance(req.context.mapping_intent, dict)
                    else ""
                ),
            )

            if req.context.omit_linked_precedent:
                linked_ids = set(learning_context.linked_mapping_ids)
                learning_context = learning_context.model_copy(
                    update={
                        "similar_mappings": [
                            item
                            for item in learning_context.similar_mappings
                            if item.sttm_id not in linked_ids
                        ],
                        "linked_project_ids": [],
                        "linked_mapping_ids": [],
                        "linked_project_patterns": [],
                        "linked_mapping_precedents": [],
                        "mapping_precedents": [],
                        "retrieval_explanations": [
                            *learning_context.retrieval_explanations,
                            {
                                "source": "shadow_control",
                                "status": "linked_precedent_omitted",
                                "reason": (
                                    "Requested non-publishing shadow inference for measuring "
                                    "agent performance without exact linked-mapping reuse."
                                ),
                            },
                        ],
                    }
                )

            # The project's own firm values first, so a precedent's $Name that the
            # project defines resolves instead of becoming a bare contract.
            relation_graph = self._with_project_firm_values(
                req.context.relation_graph,
                project_id,
            )
            relation_graph = self._add_precedent_value_bindings(
                relation_graph,
                learning_context,
            )

            context_payload = learning_context.model_dump(mode="json", exclude_none=True)
            graph_payload = (
                relation_graph.model_dump(mode="json", exclude_none=True)
                if relation_graph is not None
                else None
            )
            prepared_context_hash = hashlib.sha256(
                json.dumps(
                    {
                        "semantic_bundle_id": req.context.semantic_bundle_id,
                        "semantic_bundle_label": req.context.semantic_bundle_label,
                        "omit_linked_precedent": req.context.omit_linked_precedent,
                        "replay_exact_precedent": req.context.replay_exact_precedent,
                        "relation_graph": graph_payload,
                        "learning_context": context_payload,
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                    default=str,
                ).encode("utf-8")
            ).hexdigest()
            return req.model_copy(
                update={
                    "context": req.context.model_copy(
                        update={
                            "learning_context": learning_context,
                            "relation_graph": relation_graph,
                            "prepared_context_hash": prepared_context_hash,
                        }
                    ),
                    "meta": {
                        **req.meta,
                        "prepared_context_hash": prepared_context_hash,
                        "learning_context_prepared": True,
                        "shadow_without_linked_precedent": req.context.omit_linked_precedent,
                    },
                }
            )
        except ContextPrecedentUnavailableError:
            raise
        except Exception as exc:
            # Without learning context automap silently degrades to semantic-only
            # inference, so this must be loud and countable rather than a warning.
            increment("learning_context.enrich.failed")
            logger.error("Failed to enrich request with learning context: %s", exc, exc_info=True)
            return req

    @staticmethod
    def _learning_retrieval_inputs(
        req: STTMBuilderEnvelopeRequest,
        target_table: str,
    ) -> tuple[list[str], list[dict[str, Any]], list[Any], list[Any]]:
        """Return source columns, column profiles, relationships and derived sources."""
        workspace = req.context.workspace_context
        target_names = {target_table.upper(), target_table.split(".")[-1].upper()} if target_table else set()
        # Qualified as RELATION.COLUMN so learned patterns can be matched on the
        # columns they actually read, not on bare names shared across tables.
        source_columns = [
            f"{table_name}.{column}"
            for table_name, columns in (req.context.selected_columns_by_table or {}).items()
            if str(table_name).upper() not in target_names
            for column in columns
        ]
        for derived in (workspace.derived_sources if workspace else []):
            if not derived.name:
                continue
            for item in derived.output_columns:
                column = str(item.get("name") or item.get("column_name") or "").strip()
                if column:
                    source_columns.append(f"{derived.name}.{column}")
        source_columns = list(dict.fromkeys(source_columns))
        source_grain = (
            (req.context.mapping_intent or {}).get("source_grain")
            if isinstance(req.context.mapping_intent, dict)
            else None
        )
        source_column_profiles = [
            {
                "physical_name": source_column,
                "type": row.source_type,
                "grain": source_grain,
            }
            for row in (workspace.mapping_rows if workspace else [])
            for source_column in row.source_columns
        ]
        def append_profiles(relation, model):
            profiles = semantic_column_profiles(relation, model)
            source_columns.extend(profile["physical_name"] for profile in profiles)
            source_column_profiles.extend(profiles)

        for item in req.context.semantic_context or []:
            semantic = item.model_dump(mode="json") if hasattr(item, "model_dump") else item
            if not isinstance(semantic, dict):
                continue
            table_name = STTMBuilderService._table_qualified_name(semantic.get("table")) or ""
            if not table_name or table_name.upper() in target_names:
                continue
            append_profiles(table_name, semantic.get("semantic_model") or {})
        # Selected derived outputs are legal execution bindings. Preserve only
        # explicit grain/type/role evidence; a PK or description is not grain.
        for node in req.context.relation_graph.nodes if req.context.relation_graph else []:
            raw = node.model_dump(mode="json", exclude_none=True)
            physical = STTMBuilderService._table_qualified_name(raw.get("table")) or ""
            if physical.upper() in target_names:
                continue
            relation = raw.get("alias")
            if relation:
                append_profiles(relation, raw)
        merged_profiles = {}
        for profile in source_column_profiles:
            identity = column_identity(profile["physical_name"])
            current = merged_profiles.setdefault(identity, dict(profile))
            for key, value in profile.items():
                if value is not None and value != [] and value != "":
                    current[key] = value
        source_column_profiles = list(merged_profiles.values())
        source_columns = list(dict.fromkeys(source_columns))
        relationships = list(workspace.relationships) if workspace and workspace.relationships else list(req.context.relationships or [])
        derived_sources = list(workspace.derived_sources) if workspace else []
        return source_columns, source_column_profiles, relationships, derived_sources

    def _with_project_firm_values(self, relation_graph: Any, project_id: str) -> Any:
        """Resolve the project's stored firm values into the graph's Value bindings.

        The UI usually sends them, but the stored project attributes are
        authoritative, so Auto-map validation never depends on what the page loaded.
        """
        if relation_graph is None or not str(project_id or "").strip():
            return relation_graph
        from app.core.mapping_sql import MappingSqlService

        try:
            attributes = self._load_project_firm_values(project_id)
        except Exception as exc:
            logger.warning("Project firm values unavailable project_id=%s", project_id)
            raise ContextPrecedentUnavailableError("Authoritative project Values could not be loaded") from exc
        return MappingSqlService.with_project_values(relation_graph, attributes)

    def _load_project_firm_values(self, project_id):
        """Read existing project-scoped Values without creating or scanning storage."""
        from types import SimpleNamespace
        table = self._settings.qualify_metadata_object_name(self._settings.snowflake_project_attributes_table)
        rows = self._session.sql(
            f"""
            SELECT ATTRIBUTE_NAME, ATTRIBUTE_TYPE, ATTRIBUTE_VALUE
            FROM {table}
            WHERE TO_VARCHAR(PROJECT_ID) = ?
              AND COALESCE(STATUS, 'ACTIVE') = 'ACTIVE'
            ORDER BY UPPER(ATTRIBUTE_NAME), CREATED_AT
            """,
            params=[str(project_id)],
        ).collect()
        return [
            SimpleNamespace(
                attribute_name=str(row["ATTRIBUTE_NAME"] or ""),
                attribute_type=str(row["ATTRIBUTE_TYPE"] or "VARCHAR"),
                attribute_value=row["ATTRIBUTE_VALUE"],
            )
            for row in rows
        ]

    @staticmethod
    def _add_precedent_value_bindings(
        relation_graph: Any,
        learning_context: Any,
    ) -> Any:
        """Materialize linked-precedent placeholders as graph Value contracts.

        Historical mapping rows can use Values both as whole-target constants
        and inside multi-source expressions. The compiler and mapping agents
        share the relation graph as their legal namespace, so keeping those
        placeholders only inside precedent SQL makes the context incomplete.
        """
        if relation_graph is None or learning_context is None:
            return relation_graph
        existing = list(relation_graph.value_bindings)
        # Project value names are unique ignoring case; a precedent's
        # $TRANSACTIONFIRMID is the project's $TransactionFirmID, not a new contract.
        seen_values = {str(item.value).strip().upper() for item in existing if item.value}
        additions: list[ValueBinding] = []
        placeholder_pattern = re.compile(r"\$[A-Za-z_][A-Za-z0-9_]*")
        for precedent in learning_context.mapping_precedents:
            for mapping in precedent.mappings:
                expressions = (
                    mapping.get("constant_value"),
                    mapping.get("preprocessing_rule"),
                )
                for expression in expressions:
                    for placeholder in placeholder_pattern.findall(str(expression or "")):
                        if placeholder.upper() in seen_values:
                            continue
                        seen_values.add(placeholder.upper())
                        additions.append(
                            ValueBinding(
                                binding_id=(
                                    f"precedent:{precedent.precedent_sttm_id}:"
                                    f"{placeholder[1:]}"
                                ),
                                value=placeholder,
                                data_type="VARCHAR",
                                is_placeholder=True,
                                allow_project_specific_value=False,
                                resolution_status="placeholder_contract",
                            )
                        )
        if not additions:
            return relation_graph
        return relation_graph.model_copy(
            update={"value_bindings": [*existing, *additions]}
        )

    @staticmethod
    def _status_event(phase: str, message: str, **extra: Any) -> dict[str, Any]:
        """Build a status event payload with phase and message."""
        return {"phase": phase, "message": message, **extra}

    def invoke_stream(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        governance_decision: GovernanceDecision | None = None,
    ) -> Iterator[str]:
        stream_started = time.perf_counter()
        # Per-stage latency for this request, returned in response.meta.timings_ms
        # and recorded as chat.stream.* metrics.
        stage_ms: dict[str, float] = {}
        stream_phase = "preparing"
        terminal_emitted = False

        def since(started: float) -> float:
            return round((time.perf_counter() - started) * 1000, 1)

        req = self._with_intent_route(req)
        req = self._sanitize_request_semantic_context(req)
        if self._auto_map_retrieval_enabled(req):
            response = self.invoke(req, governance_decision=governance_decision)
            event = "response.completed" if getattr(self._settings, "assistant_streaming_v2", False) else "final"
            return iter([f"event: {event}\ndata: {json.dumps(response.model_dump(mode='json'), default=str)}\n\n"])
        stage_ms["sanitize_ms"] = since(stream_started)
        def emit(event: str, data: dict[str, Any]) -> str:
            nonlocal stream_phase, terminal_emitted
            stream_phase = str(data.get("phase") or stream_phase)
            if event in {"final", "response.completed", "error", "response.failed"}:
                terminal_emitted = True
            return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"

        def out_event(legacy: str, v2: str) -> str:
            settings = getattr(self, "_settings", None)
            return v2 if bool(getattr(settings, "assistant_streaming_v2", False)) else legacy

        def iterator() -> Iterator[str]:
            nonlocal stream_phase
            decision = governance_decision or self._build_governance_decision(req)
            reusing_prefetched_context = self._should_reuse_prefetched_semantic_context(req)
            bypassing_semantic_refresh = self._should_bypass_semantic_refresh(req)

            # Phase 1: Initial preparation status. Do not imply that semantic
            # and FIR context are being rebuilt when the caller supplied the
            # reusable handles and payload.
            stage_ms["first_event_ms"] = since(stream_started)
            yield emit(
                out_event("status", "context.resolved"),
                self._status_event(
                    phase="preparing",
                    message=(
                        "Using the prepared workspace context."
                        if bypassing_semantic_refresh or reusing_prefetched_context
                        else "Preparing context for your request..."
                    ),
                ),
            )

            # Phase 2: Semantic context resolution
            if not bypassing_semantic_refresh and not reusing_prefetched_context:
                yield emit(
                    out_event("status", "activity.started"),
                    self._status_event(
                        phase="semantic",
                        message="Building semantic context from your selected tables...",
                    ),
                )

            semantic_started = time.perf_counter()
            try:
                req_with_context, semantic_refresh = self._with_semantic_context(req)
            except AppError as exc:
                yield emit(
                    "error",
                    self._stream_error_envelope(
                        req,
                        title=exc.message,
                        status=exc.status_code,
                        code=exc.code.value,
                    ),
                )
                return
            except Exception:
                logger.exception(
                    "Streaming semantic context resolution failed: request_id=%s operation=%s",
                    req.request_id,
                    req.operation.value,
                )
                yield emit(
                    "error",
                    self._stream_error_envelope(
                        req,
                        title="Semantic context resolution failed",
                        status=502,
                        code="SEMANTIC_CONTEXT_STREAM_ERROR",
                    ),
                )
                return
            stage_ms["semantic_ms"] = since(semantic_started)
            try:
                req_with_context = self._govern_request_for_model(req_with_context, decision)
            except Exception:
                logger.exception(
                    "Streaming model-governance preparation failed: request_id=%s operation=%s",
                    req_with_context.request_id,
                    req_with_context.operation.value,
                )
                yield emit(
                    "error",
                    self._stream_error_envelope(
                        req_with_context,
                        title="Model request preparation failed",
                        status=502,
                        code="MODEL_REQUEST_PREPARATION_ERROR",
                    ),
                )
                return
            if semantic_refresh is not None:
                yield emit(
                    out_event("status", "activity.completed"),
                    self._status_event(
                        phase="semantic",
                        message=self._semantic_refresh_status_message(semantic_refresh),
                        bundle_id=semantic_refresh.bundle_id,
                        bundle_label=semantic_refresh.bundle_label,
                        semantic_level=semantic_refresh.achieved_level,
                        status=semantic_refresh.status,
                        semantic_view_name=semantic_refresh.semantic_view_name,
                    ),
                )

            # Phase 3: Learning context retrieval (for auto-map and source mapping)
            if req_with_context.data.intent == Interface.AUTO_MAP:
                yield emit(
                    out_event("status", "activity.started"),
                    self._status_event(
                        phase="learning",
                        message="Loading learning context from FIR...",
                    ),
                )

            if self._should_use_analyst(req_with_context, semantic_refresh):
                logger.info(
                    "Answering streaming STTM chat request with Cortex Analyst: request_id=%s surface=%s level=%s semantic_view=%s",
                    req_with_context.request_id,
                    req_with_context.context.surface.value,
                    req_with_context.context.semantic_level_requested.value,
                    getattr(semantic_refresh, "semantic_view_name", None),
                )
                yield emit(
                    out_event("status", "activity.started"),
                    {
                        "phase": "analyst_started",
                        "message": "Cortex Analyst is generating SQL from the saved source and target semantic bundle.",
                        "semantic_view_name": semantic_refresh.semantic_view_name,
                    },
                )
                try:
                    analyst_question = self._build_analyst_question(req_with_context)
                    text_parts: list[str] = []
                    sql_parts: list[str] = []
                    suggestion_parts: dict[int, list[str]] = {}
                    analyst_warnings: list[dict[str, Any]] = []
                    analyst_metadata: dict[str, Any] = {}
                    analyst_request_id: str | None = None
                    verified_query_used: dict[str, Any] | None = None
                    raw_events: list[dict[str, Any]] = []
                    status_labels = {
                        "interpreting_question": "Interpreting the business question.",
                        "generating_sql": "Generating SQL from the prepared semantic context.",
                        "validating_sql": "Validating the generated SQL.",
                        "generating_suggestions": "Preparing relevant follow-up suggestions.",
                    }
                    for analyst_event, analyst_payload in self._analyst.stream_events(
                        question=analyst_question,
                        semantic_view=semantic_refresh.semantic_view_name,
                        semantic_model_yaml=(
                            None
                            if semantic_refresh.semantic_view_name
                            else getattr(semantic_refresh, "semantic_model_yaml", None)
                        ),
                    ):
                        if not isinstance(analyst_payload, dict):
                            continue
                        raw_events.append(
                            {"event": analyst_event, "data": analyst_payload}
                        )
                        request_id = analyst_payload.get("request_id")
                        if isinstance(request_id, str):
                            analyst_request_id = request_id
                        if analyst_event == "status":
                            status = str(
                                analyst_payload.get("status")
                                or analyst_payload.get("message")
                                or ""
                            ).strip()
                            yield emit(
                                out_event("status", "activity.progress"),
                                {
                                    "phase": "analyst_processing",
                                    "message": status_labels.get(
                                        status.lower().replace(" ", "_"),
                                        "Cortex Analyst is processing the prepared semantic model.",
                                    ),
                                    "upstream_status": status or None,
                                },
                            )
                            continue
                        if analyst_event in {"error", "response.error"}:
                            raise SnowflakeAgentError(
                                str(
                                    analyst_payload.get("message")
                                    or analyst_payload.get("error")
                                    or "Cortex Analyst stream failed."
                                )
                            )
                        if analyst_event == "warnings":
                            warnings = analyst_payload.get("warnings")
                            if isinstance(warnings, list):
                                analyst_warnings.extend(
                                    warning for warning in warnings if isinstance(warning, dict)
                                )
                            continue
                        if analyst_event == "response_metadata":
                            metadata = analyst_payload.get("response_metadata")
                            if isinstance(metadata, dict):
                                analyst_metadata.update(metadata)
                            continue

                        content = analyst_payload.get("content")
                        if not isinstance(content, dict):
                            content = analyst_payload
                        content_type = str(content.get("type") or "").lower()
                        text_delta = content.get("text_delta")
                        statement_delta = content.get("statement_delta")
                        if isinstance(text_delta, str) and text_delta:
                            text_parts.append(text_delta)
                            yield emit(
                                out_event("delta", "response.text.delta"),
                                {"text": text_delta},
                            )
                        if isinstance(statement_delta, str) and statement_delta:
                            sql_parts.append(statement_delta)
                            yield emit(
                                out_event("delta", "response.sql.delta"),
                                {"text": statement_delta},
                            )
                        suggestions_delta = content.get("suggestions_delta")
                        if isinstance(suggestions_delta, dict):
                            index = int(suggestions_delta.get("index") or 0)
                            suggestion_delta = suggestions_delta.get("suggestion_delta")
                            if isinstance(suggestion_delta, str) and suggestion_delta:
                                suggestion_parts.setdefault(index, []).append(suggestion_delta)
                                yield emit(
                                    out_event("suggestions", "suggestions.delta"),
                                    {
                                        "index": index,
                                        "text": suggestion_delta,
                                        "items": [
                                            "".join(suggestion_parts[key])
                                            for key in sorted(suggestion_parts)
                                        ],
                                    },
                                )
                        verified = content.get("verified_query_used")
                        if isinstance(verified, dict):
                            verified_query_used = verified
                        if (
                            content_type == "text"
                            and isinstance(content.get("text"), str)
                            and not text_delta
                        ):
                            text_parts.append(content["text"])
                            yield emit(
                                out_event("delta", "response.text.delta"),
                                {"text": content["text"]},
                            )
                        if (
                            content_type == "sql"
                            and isinstance(content.get("statement"), str)
                            and not statement_delta
                        ):
                            sql_parts.append(content["statement"])
                            yield emit(
                                out_event("delta", "response.sql.delta"),
                                {"text": content["statement"]},
                            )
                    analyst_response = SnowflakeAnalystResponse(
                        request_id=analyst_request_id,
                        text="".join(text_parts).strip() or None,
                        sql="".join(sql_parts).strip() or None,
                        suggestions=[
                            "".join(suggestion_parts[key]).strip()
                            for key in sorted(suggestion_parts)
                            if "".join(suggestion_parts[key]).strip()
                        ],
                        warnings=analyst_warnings,
                        response_metadata=analyst_metadata,
                        raw_message={"stream_events": raw_events},
                        verified_query_used=verified_query_used,
                    )
                    response = self._invoke_analyst(
                        req_with_context,
                        semantic_refresh,
                        decision,
                        analyst_response_override=analyst_response,
                    )
                except Exception as exc:
                    logger.exception("Streaming Cortex Analyst request failed")
                    yield emit(
                        out_event("error", "response.failed"),
                        self._stream_error_envelope(
                            req_with_context,
                            title="Cortex Analyst request failed",
                            status=502,
                            code="SNOWFLAKE_ANALYST_STREAM_ERROR",
                            detail=str(exc) or None,
                        ),
                    )
                    return
                response.meta = self._merge_agent_meta(
                    response.meta,
                    {
                        "routing": {
                            "bypassed_agent_orchestrator": True,
                            "reason": "oauth_safe_direct_analyst_path",
                        },
                    },
                )
                yield emit(
                    out_event("final", "response.completed"),
                    response.model_dump(mode="json"),
                )
                return

            payload_started = time.perf_counter()
            stream_phase = "payload"
            user_text = self._build_agent_payload(req_with_context)
            stage_ms["payload_ms"] = since(payload_started)
            continuity_started = time.perf_counter()
            stream_phase = "continuity"
            continuity = self._prepare_conversation_continuity(
                req_with_context,
                user_text,
            )
            stage_ms["continuity_ms"] = since(continuity_started)
            if continuity is None and req_with_context.data.intent == Interface.CHAT:
                yield emit(out_event("status", "activity.progress"), {
                    "phase": "memory", "message": "Durable conversation memory is unavailable; using current workspace and supplied recent history.",
                })
            messages = self._messages_with_continuity(user_text, continuity)
            local_thread_id = None
            if continuity is not None and continuity.checkpoint_artifact_id:
                yield emit(
                    out_event("thread_checkpointed", "thread.checkpointed"),
                    {
                        "logical_conversation_id": continuity.logical_conversation_id,
                        "segment": continuity.segment_number,
                        "artifact_id": continuity.checkpoint_artifact_id,
                    },
                )
            if continuity is not None and continuity.rolled_over:
                yield emit(
                    out_event("thread_rolled_over", "thread.rolled_over"),
                    {
                        "logical_conversation_id": continuity.logical_conversation_id,
                        "segment": continuity.segment_number,
                        "reason": continuity.rollover_reason,
                    },
                )
            self._model_guard.assert_model_target_allowed(
                operation=req_with_context.operation.value,
                target="agent",
                decision=decision,
            )
            thread_id_to_use = (
                None
                if self._should_reset_thread(req_with_context)
                else (
                    continuity.physical_thread_id
                    if continuity is not None
                    else req_with_context.context.thread_id
                )
            )
            parent_message_id_to_use = (
                None if thread_id_to_use is None else req_with_context.context.parent_message_id
            )
            # Phase 4: Sending request to AI agent
            yield emit(
                out_event("status", "activity.started"),
                self._status_event(
                    phase="invoking",
                    message="Sending request to AI agent...",
                    bundle_id=req_with_context.context.semantic_bundle_id,
                    semantic_level=req_with_context.context.semantic_level_requested,
                ),
            )

            yield emit(
                out_event("status", "activity.progress"),
                self._status_event(
                    phase="processing",
                    message=(
                        "AI is analyzing your tables and generating mapping suggestions..."
                        if req_with_context.data.intent == Interface.AUTO_MAP
                        else "AI is analyzing your request..."
                    ),
                    bundle_id=req_with_context.context.semantic_bundle_id,
                    semantic_level=req_with_context.context.semantic_level_requested,
                ),
            )

            run_config = self._request_scoped_analyst_config(req_with_context, semantic_refresh, decision)
            run_options = {"run_config": run_config} if run_config is not None else {}
            if run_config is not None:
                thread_id_to_use = None
                parent_message_id_to_use = None
            final_payload: dict[str, Any] | None = None
            resolved_thread_id = thread_id_to_use
            resolved_parent_message_id = parent_message_id_to_use
            text_parts: list[str] = []
            visible_text = _StructuredAnswerDeltaFilter()
            agent_started = time.perf_counter()

            try:
                def consume_stream(active_thread_id: str | None) -> Iterator[tuple[str, Any]]:
                    return self._agent.stream_events(
                        messages,
                        agent=None if run_config is not None else self._resolved_agent_name(req_with_context),
                        thread_id=active_thread_id,
                        parent_message_id=resolved_parent_message_id if active_thread_id else None,
                        **run_options,
                    )

                try:
                    stream_iterator = _iter_agent_events_with_heartbeat(
                        consume_stream(thread_id_to_use)
                    )
                    for event_name, payload in stream_iterator:
                        if event_name == "__heartbeat__":
                            elapsed = payload.get("elapsed_seconds", 0)
                            # Vary the message based on elapsed time for better UX
                            if elapsed < 5:
                                heartbeat_message = "AI is analyzing your tables..."
                            elif elapsed < 15:
                                heartbeat_message = "Still working on your request..."
                            else:
                                heartbeat_message = "This is taking a bit longer than usual. Please wait..."
                            yield emit(
                                out_event("status", "activity.progress"),
                                self._status_event(
                                    phase="processing",
                                    message=heartbeat_message,
                                    **payload,
                                ),
                            )
                            continue
                        if "agent_first_event_ms" not in stage_ms:
                            stage_ms["agent_first_event_ms"] = since(agent_started)
                        if "tool" in event_name:
                            stage_ms["tool_events"] = stage_ms.get("tool_events", 0) + 1
                        potential_thread = _find_nested_string(payload, "thread_id")
                        if potential_thread:
                            resolved_thread_id = potential_thread
                        metadata = _extract_stream_message_metadata(event_name, payload)
                        if metadata and metadata["role"] == "assistant":
                            resolved_parent_message_id = metadata["message_id"]

                        delta = _extract_stream_text_delta(event_name, payload)
                        if delta:
                            text_parts.append(delta)
                            visible_delta = visible_text.push(delta)
                            if visible_delta:
                                stage_ms.setdefault("first_text_ms", since(stream_started))
                                yield emit(
                                    out_event("delta", "response.text.delta"),
                                    {"text": visible_delta},
                                )

                        suggestions = _extract_stream_suggestions(payload)
                        if suggestions:
                            yield emit(
                                out_event("suggestions", "suggestions.delta"),
                                {"items": suggestions},
                            )

                        status_message = _extract_stream_status(event_name, payload)
                        if status_message:
                            yield emit(
                                out_event("status", "activity.progress"),
                                {"phase": "agent_progress", "message": status_message},
                            )

                        response_payload = _extract_stream_response_payload(event_name, payload)
                        if response_payload is not None:
                            final_payload = response_payload
                except SnowflakeAgentError as exc:
                    rollover_reason = "expired_cortex_thread"
                    retry_text = user_text
                    if (
                        self._settings.agent_oversize_retry_v1
                        and self._is_agent_oversize_error(exc)
                    ):
                        retry_text = self._build_agent_payload(
                            req_with_context, emergency=True
                        )
                        if retry_text == user_text:
                            raise AgentPayloadBudgetError(
                                "AGENT_PAYLOAD_REQUIRED_CONTEXT_TOO_LARGE: Cortex "
                                "rejected the already-compacted mandatory request context"
                            ) from exc
                        rollover_reason = "remote_payload_limit"
                        increment("agent.payload.oversize_stream_retry")
                    elif not self._should_retry_without_thread(exc, thread_id_to_use):
                        raise
                    logger.warning(
                        "Retrying Cortex Agent stream without thread: request_id=%s "
                        "thread_id=%s reason=%s",
                        req_with_context.request_id,
                        thread_id_to_use,
                        rollover_reason,
                    )
                    continuity = self._prepare_conversation_continuity(
                        req_with_context,
                        retry_text,
                        force_rollover_reason=rollover_reason,
                    )
                    messages = self._messages_with_continuity(retry_text, continuity)
                    resolved_thread_id = None
                    resolved_parent_message_id = None
                    text_parts = []
                    visible_text = _StructuredAnswerDeltaFilter()
                    final_payload = None
                    yield emit(
                        out_event("thread_rolled_over", "thread.rolled_over"),
                        {
                            "logical_conversation_id": (
                                continuity.logical_conversation_id
                                if continuity is not None
                                else req_with_context.context.logical_conversation_id
                            ),
                            "segment": continuity.segment_number if continuity else None,
                            "reason": rollover_reason,
                            "message": (
                                "The Cortex conversation was checkpointed and "
                                "continued with safe request context."
                            ),
                        },
                    )
                    stream_iterator = _iter_agent_events_with_heartbeat(consume_stream(None))
                    for event_name, payload in stream_iterator:
                        if event_name == "__heartbeat__":
                            elapsed = payload.get("elapsed_seconds", 0)
                            if elapsed < 5:
                                heartbeat_message = "AI is analyzing your tables..."
                            elif elapsed < 15:
                                heartbeat_message = "Still working on your request..."
                            else:
                                heartbeat_message = "This is taking a bit longer than usual. Please wait..."
                            yield emit(
                                out_event("status", "activity.progress"),
                                self._status_event(
                                    phase="processing",
                                    message=heartbeat_message,
                                    **payload,
                                ),
                            )
                            continue
                        if "agent_first_event_ms" not in stage_ms:
                            stage_ms["agent_first_event_ms"] = since(agent_started)
                        if "tool" in event_name:
                            stage_ms["tool_events"] = stage_ms.get("tool_events", 0) + 1
                        potential_thread = _find_nested_string(payload, "thread_id")
                        if potential_thread:
                            resolved_thread_id = potential_thread
                        metadata = _extract_stream_message_metadata(event_name, payload)
                        if metadata and metadata["role"] == "assistant":
                            resolved_parent_message_id = metadata["message_id"]

                        delta = _extract_stream_text_delta(event_name, payload)
                        if delta:
                            text_parts.append(delta)
                            visible_delta = visible_text.push(delta)
                            if visible_delta:
                                stage_ms.setdefault("first_text_ms", since(stream_started))
                                yield emit(
                                    out_event("delta", "response.text.delta"),
                                    {"text": visible_delta},
                                )

                        suggestions = _extract_stream_suggestions(payload)
                        if suggestions:
                            yield emit(
                                out_event("suggestions", "suggestions.delta"),
                                {"items": suggestions},
                            )

                        status_message = _extract_stream_status(event_name, payload)
                        if status_message:
                            yield emit(
                                out_event("status", "activity.progress"),
                                {"phase": "agent_progress", "message": status_message},
                            )

                        response_payload = _extract_stream_response_payload(event_name, payload)
                        if response_payload is not None:
                            final_payload = response_payload
            except Exception as exc:
                logger.exception("Streaming STTM agent request failed")
                yield emit(
                    out_event("error", "response.failed"),
                    self._stream_error_envelope(
                        req_with_context,
                        title="Cortex Agent request failed",
                        status=502,
                        code="SNOWFLAKE_AGENT_STREAM_ERROR",
                    ),
                )
                return

            # Phase 5: Finalizing response
            stage_ms["agent_ms"] = since(agent_started)
            post_started = time.perf_counter()
            yield emit(
                out_event("status", "activity.completed"),
                self._status_event(
                    phase="finalizing",
                    message=(
                        "Preparing mapping suggestions..."
                        if req_with_context.data.intent == Interface.AUTO_MAP
                        else "Preparing response..."
                    ),
                ),
            )

            raw_payload = final_payload
            raw_text = _extract_stream_message_text(final_payload) or "".join(text_parts).strip()
            raw_text, resolved_thread_id, raw_payload = self._continue_context_retrieval(req_with_context, raw_text, raw_payload, resolved_thread_id, seed_messages=messages, run_config=run_config)
            resolved_parent_message_id = _extract_assistant_message_id(raw_payload) or resolved_parent_message_id
            response_thread_id = local_thread_id or resolved_thread_id or str(uuid.uuid4())
            if local_thread_id and req_with_context.data.intent == Interface.CHAT:
                self._store_local_chat_history(
                    thread_id=local_thread_id,
                    messages=messages,
                    assistant_text=raw_text,
                )
            response = self._build_chat_response(
                req_with_context,
                raw_text=raw_text,
                raw_payload=raw_payload,
                thread_id=response_thread_id,
                parent_message_id=None if local_thread_id else resolved_parent_message_id,
                semantic_refresh=semantic_refresh,
            )
            analyst_delegation = self._analyst_delegation(response)
            analyst_fallback = self._needs_analyst_derived_fallback(
                req_with_context,
                response,
            )
            from app.core.semantic_evidence import missing_semantic_assets
            if (analyst_delegation is not None or analyst_fallback) and not missing_semantic_assets(req_with_context.context, semantic_refresh):
                yield emit(
                    out_event("status", "tool.started"),
                    self._status_event(
                        phase="analyst_execution",
                        message=(
                            "Generating executable derived SQL with Cortex Analyst."
                            if analyst_fallback
                            else "Querying the selected data with Cortex Analyst."
                        ),
                    ),
                )
                response = self._execute_requested_analyst_delegation(
                    req_with_context,
                    response,
                    semantic_refresh=semantic_refresh,
                    decision=decision,
                )
                yield emit(
                    out_event("status", "tool.completed"),
                    self._status_event(
                        phase="analyst_execution",
                        message=(
                            "Cortex Analyst returned SQL ready for the derived-source builder."
                            if analyst_fallback
                            else "Cortex Analyst returned the data result."
                        ),
                    ),
                )
            response = self._postflight_guard.finalize_sttm_response(self._with_semantic_gap_notice(req_with_context, response), decision)
            response.meta = self._merge_agent_meta(
                response.meta,
                {
                    "logical_conversation_id": (
                        continuity.logical_conversation_id if continuity else None
                    ),
                    "thread_segment": continuity.segment_number if continuity else None,
                    "thread_rolled_over": continuity.rolled_over if continuity else False,
                    "rollover_reason": continuity.rollover_reason if continuity else None,
                },
            )
            defer_writes = bool(
                getattr(getattr(self, "_settings", None), "chat_deferred_writes_v1", False)
            )
            response_artifact_type = str(
                response.data.artifact_type.value
                if response.data is not None
                else req_with_context.data.intent.value.lower()
            )
            final_visible_text = self._visible_response_text(response)

            def persist_turn() -> str | None:
                artifact_id = self._persist_response_artifact(
                    req_with_context,
                    response,
                    continuity=continuity,
                    artifact_id=planned_artifact_id,
                )
                self._complete_conversation_continuity(
                    continuity,
                    physical_thread_id=response_thread_id,
                    user_text=user_text,
                    assistant_text=final_visible_text,
                )
                self._persist_continuity_turns(
                    req_with_context,
                    continuity,
                    assistant_text=final_visible_text,
                )
                return artifact_id

            if defer_writes:
                # The id is handed out now and the row is written after the client
                # already has the answer.
                planned_artifact_id: str | None = f"artifact_{uuid.uuid4().hex[:20]}"
                response_artifact_id = planned_artifact_id
            else:
                planned_artifact_id = None
                writes_started = time.perf_counter()
                response_artifact_id = persist_turn()
                stage_ms["writes_ms"] = since(writes_started)
            self._attach_response_artifact_descriptor(
                response,
                artifact_id=response_artifact_id,
                artifact_type=response_artifact_type,
            )
            if local_thread_id and final_visible_text != raw_text:
                self._store_local_chat_history(
                    thread_id=local_thread_id,
                    messages=messages,
                    assistant_text=final_visible_text,
                )
            if continuity is not None and continuity.checkpoint_artifact_id:
                yield emit(
                    out_event("artifact_created", "artifact.created"),
                    {
                        "artifact_id": continuity.checkpoint_artifact_id,
                        "artifact_type": "thread_checkpoint",
                    },
                )
            if response_artifact_id:
                yield emit(
                    out_event("artifact_created", "artifact.created"),
                    {
                        "artifact_id": response_artifact_id,
                        "artifact_type": response_artifact_type,
                    },
                )
            stage_ms["postprocess_ms"] = since(post_started)
            stage_ms["total_ms"] = since(stream_started)
            response.meta = {**response.meta, "timings_ms": dict(stage_ms)}
            if req_with_context.context.workspace_context:
                response.meta["auto_map_outcome"] = req_with_context.context.workspace_context.auto_map_outcome
            writes_pending = (
                _begin_turn_writes(continuity.logical_conversation_id if continuity else None)
                if defer_writes
                else None
            )
            try:
                yield emit(
                    out_event("final", "response.completed"),
                    response.model_dump(mode="json"),
                )
            finally:
                # Runs even when the client disconnects right after the answer.
                if defer_writes:
                    writes_started = time.perf_counter()
                    try:
                        persist_turn()
                    finally:
                        _end_turn_writes(
                            continuity.logical_conversation_id if continuity else None,
                            writes_pending,
                        )
                    stage_ms["writes_ms"] = since(writes_started)
                for name, value in stage_ms.items():
                    if name.endswith("_ms"):
                        observe(f"chat.stream.{name}", value)
                logger.info(
                    "Chat stream timings request_id=%s %s",
                    req_with_context.request_id,
                    " ".join(f"{key}={value}" for key, value in stage_ms.items()),
                )

        def guarded_iterator() -> Iterator[str]:
            """Keep an application failure from looking like a successful empty SSE response.

            StreamingResponse sends the HTTP headers before this generator has finished.
            Without this outer boundary, an exception in any final response enrichment step
            closes the socket with HTTP 200 and the browser can only report an unexplained EOF.
            """
            try:
                yield from iterator()
            except AgentPayloadBudgetError:
                logger.exception("Assistant payload exceeds budget: request_id=%s", req.request_id)
                if not terminal_emitted:
                    error = self._stream_error_envelope(
                        req,
                        title="The required assistant context exceeds the request budget",
                        detail="The assistant could not fit the required workspace context into this request, even with on-demand retrieval. No model answer was generated and your workspace was not changed.",
                        status=413,
                        code="ASSISTANT_CONTEXT_TOO_LARGE",
                    )
                    error["meta"] = {"failed_phase": stream_phase}
                    yield emit(out_event("error", "response.failed"), error)
            except SnowflakeAgentError:
                logger.exception("Assistant model integration failed: request_id=%s", req.request_id)
                if not terminal_emitted:
                    yield emit(out_event("error", "response.failed"), {
                        **self._stream_error_envelope(req,
                            title="The assistant could not prepare or invoke its model tools",
                            detail="Refresh the workspace context and retry. If this persists, inspect the backend trace using this request ID. No mapping changes were applied.",
                            status=502, code="ASSISTANT_MODEL_INTEGRATION_FAILED"),
                        "meta": {"failed_phase": stream_phase},
                    })
            except Exception:
                logger.exception(
                    "Unhandled STTM stream failure: request_id=%s operation=%s",
                    req.request_id,
                    req.operation.value,
                )
                if terminal_emitted:
                    # Persistence after completion must not invalidate an answer.
                    return
                yield emit(
                    out_event("error", "response.failed"),
                    {**self._stream_error_envelope(
                        req,
                        title="The assistant stream ended unexpectedly",
                        status=502,
                        code="STTM_STREAM_INCOMPLETE",
                    ), "meta": {"failed_phase": stream_phase}},
                )

        return guarded_iterator()

    @staticmethod
    def _stream_error_envelope(
        req: STTMBuilderEnvelopeRequest,
        *,
        title: str,
        status: int,
        code: str,
        detail: str | None = None,
    ) -> dict[str, Any]:
        message = detail.strip() if detail and detail.strip() else title
        return {
            "contract_version": "1.0",
            "request_id": req.request_id,
            "operation": req.operation.value,
            "data": None,
            "warnings": [],
            "error": {
                "type": "about:blank",
                "title": title,
                "status": status,
                "detail": message,
                "code": code,
            },
            "message": message,
        }

    @staticmethod
    def _build_governance_decision(req: STTMBuilderEnvelopeRequest) -> GovernanceDecision:
        guardrails_meta = dict(req.meta.get("guardrails") or {})
        return GovernanceDecision(
            trace_id=str(req.context.trace_id or guardrails_meta.get("trace_id") or uuid.uuid4()),
            request_id=req.request_id,
            operation=req.operation.value,
            persona=guardrails_meta.get("persona"),
            redaction_count=int(guardrails_meta.get("redaction_count") or 0),
            detected_pii=list(guardrails_meta.get("detected_pii") or []),
        )

    @staticmethod
    def _govern_request_for_model(
        req: STTMBuilderEnvelopeRequest,
        decision: GovernanceDecision,
    ) -> STTMBuilderEnvelopeRequest:
        guardrails_meta = dict(req.meta.get("guardrails") or {})
        policy = dict((getattr(decision, "meta", None) or {}).get("policy") or guardrails_meta.get("policy") or {})
        allow_samples = policy.get("allow_sample_rows") is True
        from app.core.automap_batch import canonical_model_wire_request
        governed = canonical_model_wire_request(req, allow_sample_rows=allow_samples,
            wire=req.meta.get("auto_map_fast_path") == "v1")
        if not allow_samples:
            decision.add_warning(
                "MODEL_CONTEXT_SANITIZED",
                "Sample data was removed from model-facing context after semantic enrichment.",
            )
        return governed

    def _with_semantic_context(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> tuple[STTMBuilderEnvelopeRequest, Any | None]:
        from app.core.assistant_context import explains_recorded_outcome
        workspace = req.context.workspace_context
        if explains_recorded_outcome(req.data.intent, req.data.message or "", workspace.auto_map_outcome if workspace else None):
            return req, None
        if self._settings.agent_request_scoped_analyst_v1 and req.data.intent == Interface.CHAT:
            # Resolve the live selection before both prompt construction and tool
            # binding. Legacy prepared handles may point to an older bundle.
            return self._refresh_semantic_context_for_explicit_resolve(req)
        if self._should_bypass_semantic_refresh(req):
            return req, self._prefetched_semantic_refresh(req)
        if self._should_reuse_prefetched_semantic_context(req):
            return req, self._prefetched_semantic_refresh(req)
        source_tables = req.context.source_tables or []
        selected_derived_sources = req.context.selected_derived_sources or []
        target_table = req.context.target_table
        if not source_tables and not selected_derived_sources and target_table is None:
            return req, None
        route = req.data.intent_route or req.context.routing_hint or classify_sttm_intent_route(req)
        should_resolve = (
            bool(source_tables or selected_derived_sources or target_table is not None)
            or req.data.intent in {Interface.AUTO_MAP, Interface.TRANSFORM}
            or route in {
                _INTENT_ROUTE_RAG,
                _INTENT_ROUTE_ANALYST,
                _INTENT_ROUTE_SOURCE_MAPPING,
                _INTENT_ROUTE_TRANSFORMATION,
            }
            or req.context.surface in {
                SemanticSurface.DERIVED_SOURCE,
                SemanticSurface.MAPPING,
            }
            or self._is_derived_source_request(req)
            or self._is_analyst_sql_text((req.data.message or "").lower())
        )
        if should_resolve:
            return self._refresh_semantic_context_for_explicit_resolve(req)
        return req, None

    def _refresh_semantic_context_for_explicit_resolve(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> tuple[STTMBuilderEnvelopeRequest, Any]:
        """Create/refresh a bundle only on explicit semantic-context endpoints, never on chat."""
        source_tables = req.context.source_tables or []
        selected_derived_sources = req.context.selected_derived_sources or []
        requested_level = self._determine_semantic_level(req)
        semantic_refresh = self._semantic_context_service.refresh_bundle(
            SemanticContextRefreshRequest(
                project_id=req.context.workspace_context.project_id if req.context.workspace_context else None,
                workspace_derived_sources=req.context.workspace_context.derived_sources if req.context.workspace_context else [],
                selected_source_tables=source_tables,
                selected_derived_sources=selected_derived_sources,
                target_table=req.context.target_table,
                relationships=[
                    item.model_dump(mode="json") if hasattr(item, "model_dump") else item
                    for item in (req.context.relationships or [])
                ],
                selected_columns_by_table=req.context.selected_columns_by_table or {},
                requested_level=requested_level,
                force=False,
            ),
        )
        normalized_semantic_context = self._normalize_nested_semantic_context(
            semantic_context=semantic_refresh.semantic_context,
            semantic_view_name=semantic_refresh.semantic_view_name,
            semantic_bundle_id=semantic_refresh.bundle_id,
        )
        workspace_context = req.context.workspace_context
        if workspace_context is not None:
            summary = semantic_refresh.summary
            workspace_context = workspace_context.model_copy(
                update={
                    "semantic": workspace_context.semantic.model_copy(
                        update={
                            "bundle_id": semantic_refresh.bundle_id,
                            "bundle_hash": semantic_refresh.bundle_hash,
                            "bundle_label": semantic_refresh.bundle_label,
                            "level": semantic_refresh.achieved_level,
                            "status": semantic_refresh.status,
                            "view_name": semantic_refresh.semantic_view_name,
                            "composed_model_hash": getattr(summary, "composed_model_hash", None),
                            "asset_versions": getattr(summary, "asset_versions", {}) or {},
                        }
                    )
                }
            )
        context = req.context.model_copy(
            update={
                "semantic_context": [
                    SemanticContextItem.model_validate(item)
                    for item in normalized_semantic_context
                ],
                "semantic_bundle_id": semantic_refresh.bundle_id,
                "semantic_bundle_label": semantic_refresh.bundle_label,
                "semantic_view_name": semantic_refresh.semantic_view_name,
                "semantic_level_requested": semantic_refresh.achieved_level,
                "derived_source_lineage": [
                    item.model_dump(mode="json") for item in semantic_refresh.lineage
                ],
                "datahub_context": semantic_refresh.datahub_context,
                "workspace_context": workspace_context,
            }
        )
        return req.model_copy(update={"context": context}), semantic_refresh

    def _prefetched_semantic_refresh(self, req: STTMBuilderEnvelopeRequest) -> Any | None:
        if not req.context.semantic_bundle_id:
            return None
        requested_level = req.context.semantic_level_requested or SemanticLevel.FULL_REGISTRY
        workspace_semantic = (
            req.context.workspace_context.semantic
            if req.context.workspace_context is not None
            else None
        )
        semantic_model_yaml: str | None = None
        bundle_hash = (
            workspace_semantic.bundle_hash
            if workspace_semantic is not None
            else ""
        ) or ""
        bundle_label = req.context.semantic_bundle_label
        # Prepared worker requests already carry the complete validated semantic
        # projection and content hash. A composed registry bundle commonly has
        # no physical view name; loading its YAML again here added one durable
        # Snowflake read to every concurrent Auto-map batch.
        if (
            not req.context.semantic_view_name
            and not (
                req.context.prepared_context_hash
                and req.context.semantic_context
            )
        ):
            bundle = self._semantic_context_service.get_bundle(bundle_id=req.context.semantic_bundle_id)
            if bundle:
                candidate_yaml = bundle.get("semantic_model_yaml")
                if isinstance(candidate_yaml, str) and candidate_yaml.strip():
                    semantic_model_yaml = candidate_yaml
                bundle_hash = str(bundle.get("bundle_hash") or bundle_hash or "")
                bundle_label = str(bundle.get("bundle_label") or bundle_label or "")
        from app.core.semantic_evidence import missing_semantic_assets
        missing = missing_semantic_assets(req.context)
        return SimpleNamespace(
            missing_assets=missing, analyst_ready=not missing,
            bundle_id=req.context.semantic_bundle_id,
            bundle_hash=bundle_hash,
            bundle_label=bundle_label,
            requested_level=requested_level,
            achieved_level=requested_level,
            status=SemanticBundleStatus.PARTIAL if missing else SemanticBundleStatus.READY,
            semantic_view_name=None if missing else req.context.semantic_view_name,
            semantic_model_yaml=semantic_model_yaml,
            lineage=[],
            datahub_context=req.context.datahub_context,
            promoted=False,
            cache_hit=True,
            summary={},
        )

    def resolve_usable_semantic_context(
        self,
        *,
        semantic_bundle_id: str | None,
        semantic_view_name: str | None,
    ) -> tuple[str | None, str | None]:
        resolved_bundle_id = (semantic_bundle_id or "").strip()
        resolved_view_name = (semantic_view_name or "").strip()
        if not resolved_bundle_id:
            return None, None
        if resolved_view_name:
            return resolved_bundle_id, resolved_view_name
        bundle = self._semantic_context_service.get_bundle(bundle_id=resolved_bundle_id)
        if not bundle:
            return None, None
        bundle_view_name = str(bundle.get("semantic_view_name") or "").strip()
        if not bundle_view_name:
            bundle_yaml = str(bundle.get("semantic_model_yaml") or "").strip()
            if bundle_yaml:
                return resolved_bundle_id, None
            return None, None
        return resolved_bundle_id, bundle_view_name

    def _sanitize_request_semantic_context(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderEnvelopeRequest:
        # The public host already resolved, validated, and hashed Auto-map
        # context before handing batches to the private worker. Re-reading the
        # durable bundle here adds one Snowflake round trip per concurrent batch.
        # Only reuse a complete prepared payload; ordinary/public chat requests
        # continue through the authoritative registry lookup below.
        if (
            req.data.intent in {Interface.AUTO_MAP, Interface.TRANSFORM}
            and req.context.prepared_context_hash
            and req.context.semantic_bundle_id
            and req.context.semantic_context
            and req.context.learning_context is not None
        ):
            if req.context.datahub_context is None:
                return req
            return req.model_copy(
                update={
                    "context": req.context.model_copy(
                        update={"datahub_context": None}
                    )
                }
            )
        resolved_bundle_id, resolved_view_name = self.resolve_usable_semantic_context(
            semantic_bundle_id=req.context.semantic_bundle_id,
            semantic_view_name=req.context.semantic_view_name,
        )
        normalized_semantic_context = self._normalize_nested_semantic_context(
            semantic_context=req.context.semantic_context,
            semantic_view_name=resolved_view_name,
            semantic_bundle_id=resolved_bundle_id,
        )
        if (
            resolved_bundle_id == req.context.semantic_bundle_id
            and resolved_view_name == req.context.semantic_view_name
            and req.context.datahub_context is None
            and normalized_semantic_context == [
                item.model_dump(mode="json") if hasattr(item, "model_dump") else item
                for item in (req.context.semantic_context or [])
            ]
        ):
            return req
        return req.model_copy(
            update={
                "context": req.context.model_copy(
                    update={
                        "semantic_bundle_id": resolved_bundle_id,
                        "semantic_view_name": resolved_view_name,
                        "semantic_context": [
                            SemanticContextItem.model_validate(item)
                            for item in normalized_semantic_context
                        ],
                        "datahub_context": None,
                    }
                )
            }
        )

    @staticmethod
    def _normalize_nested_semantic_context(
        *,
        semantic_context: Any,
        semantic_view_name: str | None,
        semantic_bundle_id: str | None,
    ) -> list[dict[str, Any]]:
        if not isinstance(semantic_context, list):
            return []

        normalized_items: list[dict[str, Any]] = []
        for item in semantic_context:
            if hasattr(item, "model_dump"):
                item_dict = item.model_dump(mode="json")
            elif isinstance(item, dict):
                item_dict = dict(item)
            else:
                continue

            semantic_model = item_dict.get("semantic_model")
            if isinstance(semantic_model, dict):
                normalized_model = dict(semantic_model)
                nested_view = normalized_model.get("semantic_view")
                if isinstance(nested_view, dict):
                    normalized_view = dict(nested_view)
                    if semantic_view_name:
                        normalized_view["name"] = semantic_view_name
                        if semantic_bundle_id:
                            normalized_view["bundle_id"] = semantic_bundle_id
                        normalized_model["semantic_view"] = normalized_view
                    else:
                        knowledge = normalized_model.pop("semantic_view", None)
                        if knowledge:
                            normalized_model["semantic_knowledge"] = {key: value for key, value in knowledge.items() if key != "name"}
                elif not semantic_view_name:
                    normalized_model.pop("semantic_view", None)
                item_dict["semantic_model"] = normalized_model

            normalized_items.append(item_dict)

        return normalized_items

    def _current_semantic_view_is_usable(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> bool:
        resolved_bundle_id, resolved_view_name = self.resolve_usable_semantic_context(
            semantic_bundle_id=req.context.semantic_bundle_id,
            semantic_view_name=req.context.semantic_view_name,
        )
        return bool(resolved_bundle_id and resolved_view_name)

    @staticmethod
    def _should_reuse_prefetched_semantic_context(req: STTMBuilderEnvelopeRequest) -> bool:
        if not req.context.semantic_bundle_id:
            return False
        semantic_context = req.context.semantic_context or []
        if not semantic_context:
            return False
        if req.data.intent not in {
            Interface.AUTO_MAP,
            Interface.CHAT,
            Interface.TRANSFORM,
        }:
            return False
        return req.context.semantic_level_requested == SemanticLevel.FULL_REGISTRY

    @staticmethod
    def _should_bypass_semantic_refresh(req: STTMBuilderEnvelopeRequest) -> bool:
        return (
            req.data.intent == Interface.AUTO_MAP
            and req.context.surface == SemanticSurface.MAPPING
            and bool(req.context.semantic_bundle_id)
            and bool(req.context.semantic_context)
        )

    def _build_chat_response(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        raw_text: str,
        raw_payload: dict[str, Any] | None,
        thread_id: str,
        parent_message_id: int | None,
        semantic_refresh: Any | None,
    ) -> STTMBuilderResponse:
        (
            sub_agent,
            result,
            message,
            warnings,
            error,
            meta,
            status,
            artifact_type,
            artifact,
            semantic_level_achieved,
            semantic_refresh_status,
        ) = self._parse_chat_response(raw_text, raw_payload)
        warnings = self._normalize_response_warnings(warnings)
        artifact_type, artifact = self._coerce_chat_artifact(
            req,
            artifact_type=artifact_type,
            artifact=artifact,
            message=message or raw_text,
        )
        return STTMBuilderResponse.from_invocation(
            req,
            thread_id=thread_id,
            parent_message_id=parent_message_id,
            agent=sub_agent,
            result=result,
            message=self._sanitize_final_chat_message(message or raw_text.strip()),
            status=status,
            artifact_type=artifact_type or (
                STTMArtifactType.SEMANTIC_CONTEXT
                if semantic_refresh and sub_agent is None and result is None
                else STTMArtifactType.NONE
            ),
            artifact=artifact if artifact is not None else self._semantic_refresh_to_dict(semantic_refresh),
            semantic_level_achieved=semantic_level_achieved or (
                semantic_refresh.achieved_level if semantic_refresh else None
            ),
            semantic_refresh_status=semantic_refresh_status or (
                None if semantic_refresh is None else {
                    "bundle_id": semantic_refresh.bundle_id,
                    "bundle_hash": semantic_refresh.bundle_hash,
                    "bundle_label": semantic_refresh.bundle_label,
                    "requested_level": semantic_refresh.requested_level,
                    "achieved_level": semantic_refresh.achieved_level,
                    "status": semantic_refresh.status,
                    "semantic_view_name": semantic_refresh.semantic_view_name,
                    "promoted": semantic_refresh.promoted,
                    "cache_hit": semantic_refresh.cache_hit,
                    "stale_reason": None,
                }
            ),
            warnings=warnings,
            error=error,
            meta=self._merge_agent_meta(
                meta,
                raw_payload=raw_payload,
                artifact_type=artifact_type,
                artifact=artifact,
            ),
        )

    @staticmethod
    def _semantic_refresh_to_dict(semantic_refresh: Any | None) -> dict[str, Any] | None:
        if semantic_refresh is None:
            return None
        if hasattr(semantic_refresh, "model_dump"):
            return semantic_refresh.model_dump(mode="json")

        data: dict[str, Any] = {}
        for key in (
            "bundle_id",
            "bundle_hash",
            "bundle_label",
            "requested_level",
            "achieved_level",
            "status",
            "semantic_view_name",
            "semantic_model_yaml",
            "lineage",
            "datahub_context",
            "promoted",
            "cache_hit",
            "summary",
        ):
            if not hasattr(semantic_refresh, key):
                continue
            value = getattr(semantic_refresh, key)
            if hasattr(value, "model_dump"):
                value = value.model_dump(mode="json")
            elif isinstance(value, list):
                value = [
                    item.model_dump(mode="json") if hasattr(item, "model_dump") else item
                    for item in value
                ]
            elif hasattr(value, "value"):
                value = value.value
            data[key] = value
        return data

    @staticmethod
    def _visible_response_text(response: STTMBuilderResponse) -> str:
        """Return the finalized user-visible answer for conversation memory.

        The orchestrator response may be replaced by a delegated Analyst result.
        Persisting the pre-delegation text would make a follow-up turn forget the
        answer the user actually saw.
        """

        if response.message:
            return str(response.message).strip()
        if response.data is not None and response.data.message:
            return str(response.data.message).strip()
        artifact = response.data.artifact if response.data is not None else None
        if isinstance(artifact, dict) and artifact.get("answer_text"):
            return str(artifact["answer_text"]).strip()
        return ""

    @classmethod
    def _auto_map_response_warnings(cls, *groups) -> list[ApiWarning]:
        warnings = {}
        for group in groups:
            for warning in cls._normalize_response_warnings(group):
                warnings[(warning.code, warning.message, warning.field)] = warning.model_copy(deep=True)
        return list(warnings.values())

    @staticmethod
    def _auto_map_assistant_context(warnings: list[ApiWarning]) -> dict[str, Any]:
        return {"warnings": [warning.model_dump(mode="json") for warning in warnings],
                "non_exhaustive": True,
                "instruction": "These mappings are proposals from non-exhaustive evidence. Explain coverage warnings; do not infer no-match from omitted tables."}

    @staticmethod
    def _normalize_response_warnings(warnings: list[Any] | None) -> list[ApiWarning]:
        normalized: list[ApiWarning] = []
        for index, warning in enumerate(warnings or []):
            if isinstance(warning, ApiWarning):
                normalized.append(warning)
                continue
            if isinstance(warning, dict):
                code = str(warning.get("code") or "AGENT_WARNING").strip() or "AGENT_WARNING"
                message = str(warning.get("message") or warning.get("detail") or warning).strip()
                if not message:
                    continue
                field_value = warning.get("field")
                normalized.append(
                    ApiWarning(
                        code=code,
                        message=message,
                        field=str(field_value) if field_value else None,
                    )
                )
                continue
            text = str(warning).strip()
            if not text:
                continue
            normalized.append(
                ApiWarning(
                    code=f"AGENT_WARNING_{index + 1}",
                    message=text,
                )
            )
        return normalized

    @staticmethod
    def _artifact_type_for_response(
        sub_agent: SubAgent | None,
        semantic_refresh: Any | None,
    ) -> STTMArtifactType:
        if sub_agent == SubAgent.SOURCE_MAPPING_AGENT:
            return STTMArtifactType.SOURCE_MAPPING
        if sub_agent == SubAgent.TRANSFORMATION_AGENT:
            return STTMArtifactType.TRANSFORMATION_RULES
        if semantic_refresh is not None:
            return STTMArtifactType.SEMANTIC_CONTEXT
        return STTMArtifactType.NONE

    @classmethod
    def _should_reset_thread(cls, req: STTMBuilderEnvelopeRequest) -> bool:
        if req.data.intent != Interface.CHAT:
            return True
        return False

    def _resolved_agent_name(self, req: STTMBuilderEnvelopeRequest) -> str:
        if req.data.intent == Interface.AUTO_MAP:
            return self._source_mapping_agent_name
        if req.data.intent == Interface.TRANSFORM:
            return self._transformation_agent_name
        return self._agent_name

    def _prepare_conversation_continuity(
        self,
        req: STTMBuilderEnvelopeRequest,
        user_text: str,
        *,
        force_rollover_reason: str | None = None,
    ) -> ConversationPreparation | None:
        if req.data.intent != Interface.CHAT:
            return None
        # The previous turn may still be writing its thread binding and turns.
        _wait_for_turn_writes(req.context.logical_conversation_id)
        try:
            return self._conversation_continuity.prepare(
                context=req.context,
                packed_request=user_text,
                request_id=req.request_id,
                user_id=req.actor.user_id if req.actor else None,
                force_rollover_reason=force_rollover_reason,
            )
        except Exception as exc:
            # Durable conversation memory improves continuity but must never
            # prevent the orchestrator from answering. This also keeps older
            # deployments usable while the conversation-segment DDL is being
            # bootstrapped or a configured metadata namespace is unavailable.
            if not getattr(self, "_continuity_warning_emitted", False):
                logger.warning(
                    "Conversation continuity is unavailable; continuing this "
                    "request without durable thread preparation: %s",
                    exc,
                )
                self._continuity_warning_emitted = True
            return None

    def _messages_with_continuity(
        self,
        user_text: str,
        continuity: ConversationPreparation | None,
    ) -> list[dict[str, Any]]:
        messages: list[dict[str, Any]] = []
        if continuity is not None and continuity.checkpoint_message:
            messages.append(
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": continuity.checkpoint_message}
                    ],
                }
            )
            for turn in continuity.recent_turns:
                role = str(turn.get("role") or "user").lower()
                if role not in {"user", "assistant"}:
                    continue
                content = str(turn.get("content") or "").strip()
                if content:
                    messages.append(
                        {
                            "role": role,
                            "content": [{"type": "text", "text": content}],
                        }
                    )
        messages.append(
            {"role": "user", "content": [{"type": "text", "text": user_text}]}
        )
        from app.core.assistant_retrieval import budget_messages
        return budget_messages(messages, max_chars=getattr(self._settings, 'agent_outbound_message_max_chars', 60000),
            max_bytes=getattr(self._settings, 'agent_outbound_message_max_bytes', 65536))

    def _complete_conversation_continuity(
        self,
        continuity: ConversationPreparation | None,
        *,
        physical_thread_id: str | None,
        user_text: str,
        assistant_text: str,
    ) -> None:
        if continuity is None or not physical_thread_id:
            return
        self._conversation_continuity.complete(
            continuity,
            physical_thread_id=physical_thread_id,
            user_text=user_text,
            assistant_text=assistant_text,
        )

    def _persist_continuity_turns(
        self,
        req: STTMBuilderEnvelopeRequest,
        continuity: ConversationPreparation | None,
        *,
        assistant_text: str,
    ) -> None:
        """Persist compact user/assistant turns for restart-safe continuation.

        The complete packed agent request may contain semantic YAML, SQL, and FIR
        evidence. Those values are stored as content-addressed artifacts and context
        handles; the durable conversation log intentionally keeps only the user's
        visible message and the assistant's visible response.
        """

        if continuity is None:
            return
        try:
            user_message = str(req.data.message or "").strip()
            assistant_message = str(assistant_text or "").strip()
            common = {
                "conversation_id": continuity.logical_conversation_id,
                "request_id": req.request_id,
                "trace_id": req.context.trace_id,
                "route": str(req.context.routing_hint or "conversation"),
                "intent_class": req.data.intent.value,
                "citations": [],
                "guardrails_meta": {
                    "logical_conversation_id": continuity.logical_conversation_id,
                    "physical_thread_segment": continuity.segment_number,
                    "semantic_bundle_id": req.context.semantic_bundle_id,
                    "semantic_bundle_hash": req.context.semantic_bundle_hash,
                    "learning_context_id": req.context.learning_context_id,
                    "learning_context_hash": req.context.learning_context_hash,
                },
                "user_id": req.actor.user_id if req.actor else None,
            }
            if user_message:
                self._conversation_memory.record_turn(
                    role="user",
                    message=user_message,
                    **common,
                )
            if assistant_message:
                self._conversation_memory.record_turn(
                    role="assistant",
                    message=assistant_message,
                    **common,
                )
        except Exception as exc:  # pragma: no cover - continuity audit cannot block UX
            logger.warning(
                "Could not persist durable conversation turns for %s: %s",
                req.request_id,
                exc,
            )

    def _prepare_agent_messages(
        self,
        req: STTMBuilderEnvelopeRequest,
        user_text: str,
    ) -> tuple[list[dict[str, Any]], str | None]:
        user_message = {"role": "user", "content": [{"type": "text", "text": user_text}]}
        if not self._should_use_local_chat_history(req):
            return [user_message], None

        local_thread_id = req.context.thread_id or f"local-{uuid.uuid4()}"
        if self._should_reset_thread(req):
            _local_chat_threads.pop(local_thread_id, None)
        history = list(_local_chat_threads.get(local_thread_id, []))
        return [*history, user_message], local_thread_id

    def _store_local_chat_history(
        self,
        *,
        thread_id: str,
        messages: list[dict[str, Any]],
        assistant_text: str,
    ) -> None:
        stored_messages = list(messages)
        if assistant_text.strip():
            stored_messages.append(
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": assistant_text.strip()}],
                }
            )
        _local_chat_threads[thread_id] = stored_messages[-60:]

    def _should_use_local_chat_history(self, req: STTMBuilderEnvelopeRequest) -> bool:
        return self._settings.local_dev_auth_enabled and req.data.intent == Interface.CHAT

    def _run_agent_detailed(
        self,
        *,
        messages: list[dict[str, Any]],
        agent_name: str,
        thread_id: str | None,
        parent_message_id: int | None,
    ) -> tuple[str, str, dict[str, Any] | None]:
        try:
            return self._agent.run_detailed(
                messages,
                agent=agent_name,
                thread_id=thread_id,
                parent_message_id=parent_message_id,
            )
        except SnowflakeAgentError as exc:
            if not self._should_retry_without_thread(exc, thread_id):
                raise
            logger.warning(
                "Retrying Cortex Agent request without thread after HTTP 400: agent=%s thread_id=%s",
                agent_name,
                thread_id,
            )
            return self._agent.run_detailed(
                messages,
                agent=agent_name,
                thread_id=None,
                parent_message_id=None,
            )

    def _invoke_single_auto_map_attribute(
        self,
        req: STTMBuilderEnvelopeRequest,
    ) -> dict[str, Any]:
        if self._auto_map_retrieval_enabled(req):
            raw_text, _, raw_payload = self._invoke_retrieval_auto_map(req)
            result = self._parse_envelope(raw_text)[1]
            return {"result": result, "message": "Scoped evidence mapping", "warnings": [],
                    "meta": {"auto_map_retrieval": raw_payload.get("auto_map_retrieval", {}),
                             "automap_evidence_review_only_targets": raw_payload.get("automap_evidence_review_only_targets", [])},
                    "semantic_level_achieved": None, "semantic_refresh_status": None}
        user_text = self._build_agent_payload(req)
        messages, _ = self._prepare_agent_messages(req, user_text)
        started_at = time.perf_counter()
        raw_text, _, raw_payload = self._run_agent_detailed(
            messages=messages,
            agent_name=self._source_mapping_agent_name,
            thread_id=None,
            parent_message_id=None,
        )
        (
            sub_agent,
            result,
            message,
            warnings,
            error,
            meta,
            status,
            artifact_type,
            artifact,
            semantic_level_achieved,
            semantic_refresh_status,
        ) = self._parse_envelope(raw_text)
        if sub_agent != SubAgent.SOURCE_MAPPING_AGENT:
            raise SnowflakeAgentError(
                f"Expected SOURCE_MAPPING_AGENT response, received {sub_agent}"
            )
        if error is not None or status == STTMStatus.FAILED:
            error_message = (
                (error.detail or error.title)
                if error is not None
                else "Auto-map agent failed"
            )
            raise SnowflakeAgentError(
                error_message
            )
        if not isinstance(result, SourceMappingResult):
            raise SnowflakeAgentError("Auto-map agent returned no mapping result.")

        merged_meta = self._merge_agent_meta(
            {
                **(meta or {}),
                "timings_ms": {
                    "agent": round((time.perf_counter() - started_at) * 1000, 1),
                },
            },
            raw_payload=raw_payload,
            artifact_type=artifact_type,
            artifact=artifact,
        )
        return {
            "result": result,
            "message": message,
            "warnings": self._normalize_response_warnings(warnings),
            "meta": merged_meta,
            "semantic_level_achieved": semantic_level_achieved,
            "semantic_refresh_status": semantic_refresh_status,
        }

    @staticmethod
    def _should_retry_without_thread(
        exc: SnowflakeAgentError,
        thread_id: str | None,
    ) -> bool:
        if not thread_id:
            return False
        message = str(exc)
        return (
            "Cortex Agent returned HTTP 400" in message
            and not STTMBuilderService._is_agent_oversize_error(exc)
        )

    @staticmethod
    def _is_agent_oversize_error(exc: SnowflakeAgentError) -> bool:
        message = str(exc).lower()
        return (
            "token limit" in message
            or "exceeds token" in message
            or "message length" in message
            or "user messages (len" in message
        )

    @staticmethod
    def _semantic_refresh_status_message(semantic_refresh: Any) -> str:
        if semantic_refresh.cache_hit:
            return "Saved semantic assets resolved from the workbench registry."
        if semantic_refresh.status == SemanticBundleStatus.PARTIAL:
            return "Saved semantic assets are partially available. Continuing with the resolved registry context."
        if semantic_refresh.promoted and semantic_refresh.semantic_view_name:
            return (
                f"Semantic view {semantic_refresh.semantic_view_name} is ready from the registry."
            )
        return "Saved semantic context is ready from the registry."

    @staticmethod
    def _determine_semantic_level(req: STTMBuilderEnvelopeRequest) -> SemanticLevel:
        # The registry now stores AGT_SEMANTIC_MODEL_V2 output as the canonical
        # high-context asset. Runtime bundle composition is a read-only merge of
        # those assets, so any selected-table bundle should be treated as the
        # richest available semantic context rather than promoted through levels.
        return SemanticLevel.FULL_REGISTRY

    @staticmethod
    def _is_analyst_sql_text(text: str) -> bool:
        return any(
            token in text
            for token in (
                "sql",
                "query",
                "count",
                "sum",
                "average",
                "avg",
                "group by",
                "how many",
                "total ",
                "top ",
                "trend",
                "revenue",
                "show rows",
                "show records",
            )
        )

    # Word-boundary patterns shared with the frontend
    # (frontend/src/features/sttm/shared/derived-source-intent.ts); both are tested
    # against derived-source-intent.fixture.json. Substring checks matched "cte"
    # inside words such as "selected".
    _DERIVED_SUBJECT = re.compile(
        r"\b(?:derived (?:source|table)s?|ctes?|common table expressions?|reusable (?:source|relation)s?)\b"
    )
    _DERIVED_GENERATION = re.compile(
        r"\b(?:create|build|generate|write|save|make|implement|prepare|draft|compose)\b"
    )
    _DERIVED_DIRECT = re.compile(
        r"\b(?:write|generate|build|create|draft|compose)\s+"
        r"(?:(?:a|an|the|me|us|some|that|this|my|new)\s+)*(?:sql|query|queries|select)\b"
    )
    _DERIVED_EXPLICIT = re.compile(
        r"\b(?:generate|build|create|write)\s+(?:it|this|those|them|all|now)\b"
    )
    # "which" only signals a request for advice when it opens a question; in
    # "a CTE which joins notes" it is a relative pronoun.
    _DERIVED_RECOMMEND = re.compile(
        r"\b(?:advice|advise|recommend\w*|best|what should)\b|(?:^|[.?!]\s*)which\b"
    )
    _DERIVED_MIGRATION = re.compile(
        r"\b(?:reusable household[- ]level source|reusable source for|migration source)\b"
    )
    _DERIVED_MIGRATION_VERB = re.compile(r"\b(?:prepare|create|build|generate|make)\b")

    @classmethod
    def _is_derived_source_generation_text(cls, text: str) -> bool:
        text = " ".join(str(text or "").lower().split())
        direct = bool(cls._DERIVED_DIRECT.search(text))
        if cls._DERIVED_RECOMMEND.search(text) and not (direct or cls._DERIVED_EXPLICIT.search(text)):
            return False
        if direct:
            return True
        if cls._DERIVED_MIGRATION.search(text) and cls._DERIVED_MIGRATION_VERB.search(text):
            return True
        if cls._DERIVED_SUBJECT.search(text) and cls._DERIVED_GENERATION.search(text):
            return True
        return bool(re.search(r"\b(?:generate|build|create)\s+those\b", text))

    @classmethod
    def _is_derived_source_request(cls, req: STTMBuilderEnvelopeRequest) -> bool:
        if req.data.intent != Interface.CHAT:
            return False
        text = (req.data.message or "").lower()
        if req.context.surface == SemanticSurface.DERIVED_SOURCE:
            return True
        return cls._is_derived_source_generation_text(text)

    _FENCED_SQL = re.compile(r"```(?:sql|snowflake)?[ \t]*\n(.*?)```", re.IGNORECASE | re.DOTALL)
    _DATA_QUESTION = re.compile(
        r"\b(?:how many|count|total|sum|average|avg|trend|revenue|top \d+|show (?:me )?(?:rows|records))\b"
    )

    @classmethod
    def _single_select_sql(cls, sql_text: str) -> str | None:
        """Return the SQL when it is exactly one read-only SELECT/WITH statement."""
        candidate = str(sql_text or "").strip().rstrip(";").strip()
        if not re.match(r"^(?:select|with)\b", candidate, re.IGNORECASE):
            return None
        try:
            statements = [item for item in sqlglot.parse(candidate, read="snowflake") if item is not None]
        except Exception:
            return None
        if len(statements) != 1 or not isinstance(statements[0], exp.Query):
            return None
        return candidate

    @staticmethod
    def _single_sql_expression(sql_text: str) -> str | None:
        """Return the text when it is exactly one scalar SQL expression.

        Deliberately rejects full SELECT/WITH statements (those are claimed by
        `_single_select_sql` for the derived-source/CTE path) so the two
        content-based promotions never compete for the same fenced block.
        """
        candidate = str(sql_text or "").strip().rstrip(";").strip()
        if not candidate or re.match(r"^(?:select|with)\b", candidate, re.IGNORECASE):
            return None
        try:
            parsed = sqlglot.parse_one(candidate, read="snowflake")
        except Exception:
            return None
        if parsed is None or isinstance(parsed, exp.Query):
            return None
        return candidate

    @staticmethod
    def _resolve_single_checked_target_column(req: STTMBuilderEnvelopeRequest) -> str | None:
        """Resolve the one target column the user has in context, from the
        workspace snapshot (checked/active mapping row) rather than from the
        wording of the message. Returns None unless exactly one row resolves,
        so this stays a conservative, unambiguous signal.
        """
        workspace = req.context.workspace_context
        if workspace is None:
            return None
        candidate_ids = [str(item) for item in (workspace.checked_mapping_row_ids or []) if item]
        if not candidate_ids and workspace.active_mapping_row_id:
            candidate_ids = [str(workspace.active_mapping_row_id)]
        if len(candidate_ids) != 1:
            return None
        for row in workspace.mapping_rows or []:
            if str(row.id) == candidate_ids[0]:
                return row.target_column or None
        return None

    @classmethod
    def _single_target_transformation_artifact(
        cls, req: STTMBuilderEnvelopeRequest, message: str
    ) -> dict[str, Any] | None:
        """Content-based fallback for transformation rules, mirroring the
        derived-source fenced-SQL promotion above: when a plain CHAT turn's
        own answer contains a scalar SQL expression (not a full SELECT, which
        the derived-source path already claims) and exactly one target
        mapping row is in context (from the workspace snapshot, not the
        user's wording), treat it as a transformation-rule proposal so the
        Apply option is driven by what the agent actually produced rather
        than by keywords in the prompt.
        """
        target_column = cls._resolve_single_checked_target_column(req)
        if not target_column:
            return None
        blocks = [block.strip() for block in cls._FENCED_SQL.findall(message) if block.strip()]
        expressions = [
            expr for expr in (cls._single_sql_expression(block) for block in blocks) if expr
        ]
        if len(expressions) != 1:
            return None
        return {"sql_text": expressions[0], "draft_kind": "fenced_expression"}

    @staticmethod
    def _lift_derived_contract(artifact: dict[str, Any]) -> dict[str, Any]:
        """Copy the agent's nested derived_source_contract into the fields the editor saves."""
        contract = artifact.get("derived_source_contract")
        if not isinstance(contract, dict):
            return artifact
        lifted = dict(artifact)
        for source_key, target_key in (
            ("purpose", "purpose"),
            ("business_description", "business_description"),
            ("row_grain", "grain"),
            ("grain", "grain"),
            ("keys", "keys"),
            ("output_columns", "output_columns"),
        ):
            value = contract.get(source_key)
            if value not in (None, "", [], {}) and lifted.get(target_key) in (None, "", [], {}):
                lifted[target_key] = value
        semantics = contract.get("column_semantics")
        if isinstance(semantics, dict) and semantics and not lifted.get("column_semantics"):
            lifted["column_semantics"] = [
                {"name": str(name), "business_meaning": str(meaning), "semantic_source": "agent_declared"}
                if not isinstance(meaning, dict)
                else {"name": str(name), **meaning}
                for name, meaning in semantics.items()
            ]
        elif isinstance(semantics, list) and semantics and not lifted.get("column_semantics"):
            lifted["column_semantics"] = semantics
        if contract.get("name") and not lifted.get("source_name_suggestion"):
            lifted["source_name_suggestion"] = str(contract["name"])
        return lifted

    @staticmethod
    def _existing_derived_source(req: STTMBuilderEnvelopeRequest, sql_text: str) -> dict[str, Any] | None:
        learning = req.context.learning_context
        catalog = learning.project_derived_sources if learning is not None else []
        if not catalog or not sql_text:
            return None
        sql_hash = derived_sql_hash(sql_text)
        for item in catalog:
            if item.get("sql_hash") == sql_hash:
                return {
                    "derived_source_id": item.get("derived_source_id"),
                    "name": item.get("name"),
                    "version": item.get("version"),
                }
        return None

    @classmethod
    def _coerce_chat_artifact(
        cls,
        req: STTMBuilderEnvelopeRequest,
        *,
        artifact_type: STTMArtifactType | None,
        artifact: dict[str, Any] | None,
        message: str | None = None,
    ) -> tuple[STTMArtifactType | None, dict[str, Any] | None]:
        if req.data.intent != Interface.CHAT:
            return artifact_type, artifact
        derived_request = cls._is_derived_source_request(req)
        request_text = " ".join(str(req.data.message or "").lower().split())
        # Whether to offer the editor is decided by the SQL the agent produced, not by
        # the user's wording; plain data questions (counts, totals) stay answers.
        offer_sql = derived_request or not cls._DATA_QUESTION.search(request_text)
        if artifact is None and offer_sql and message:
            blocks = [block.strip() for block in cls._FENCED_SQL.findall(message) if block.strip()]
            selects = [sql for sql in (cls._single_select_sql(block) for block in blocks) if sql]
            if len(selects) == 1:
                artifact_type = STTMArtifactType.DERIVED_SOURCE_DRAFT
                artifact = {"sql_text": selects[0], "draft_kind": "fenced_sql"}
        if artifact is None and message:
            transformation_artifact = cls._single_target_transformation_artifact(req, message)
            if transformation_artifact is not None:
                return STTMArtifactType.TRANSFORMATION_RULES, transformation_artifact
        if artifact is None:
            return artifact_type, artifact
        artifact = cls._lift_derived_contract(artifact)
        if not derived_request and not (
            offer_sql
            and artifact_type in (STTMArtifactType.ANALYST_ANSWER, STTMArtifactType.DERIVED_SOURCE_DRAFT)
            and cls._single_select_sql(str(artifact.get("sql_text") or ""))
        ):
            return artifact_type, artifact
        def enrich_derived_contract(value: dict[str, Any]) -> dict[str, Any]:
            enriched = dict(value)
            business_request = (req.data.message or "").strip()
            enriched.setdefault("purpose", business_request or "Reusable derived source")
            enriched.setdefault("business_description", business_request)
            preview_rows = enriched.get("preview_rows")
            output_names: list[str] = []
            if isinstance(preview_rows, list) and preview_rows and isinstance(preview_rows[0], dict):
                output_names = [str(name) for name in preview_rows[0]]
            enriched.setdefault(
                "output_columns",
                [{"name": name, "data_type": "UNKNOWN"} for name in output_names],
            )
            enriched.setdefault(
                "column_semantics",
                [
                    {
                        "name": name,
                        "business_meaning": name.replace("_", " ").title(),
                        "semantic_source": "analyst_output_contract",
                    }
                    for name in output_names
                ],
            )
            sql_text = str(enriched.get("sql_text") or "").strip()
            outside_scope = cls._derived_sql_tables_outside_scope(
                sql_text,
                req.context.source_tables or [],
                [
                    *(req.context.selected_derived_sources or []),
                    *[
                        str(value)
                        for item in (req.context.derived_source_lineage or [])
                        if isinstance(item, dict)
                        for key in (
                            "derived_source_id",
                            "derived_source_name",
                            "physical_view_name",
                            "qualified_name",
                        )
                        if (value := item.get(key))
                    ],
                ],
            )
            if outside_scope:
                enriched["open_in_builder"] = False
                enriched["scope_status"] = "outside_selection"
                enriched["out_of_scope_tables"] = outside_scope
                enriched["scope_detail"] = (
                    "The generated SQL references table(s) outside the current source selection: "
                    + ", ".join(outside_scope)
                    + ". Add those tables to the source selection and generate again."
                )
            else:
                enriched.setdefault("scope_status", "validated")
            if existing := cls._existing_derived_source(req, sql_text):
                # Same SQL is already saved in this project: offer it instead of a duplicate.
                enriched["existing_derived_source"] = existing
            return enriched

        if artifact_type == STTMArtifactType.ANALYST_ANSWER and artifact.get("sql_text"):
            enriched_artifact = enrich_derived_contract(artifact)
            enriched_artifact.setdefault("draft_kind", "analyst_generated")
            enriched_artifact.setdefault("open_in_builder", True)
            if suggestion := cls._suggest_derived_source_name(req.data.message or ""):
                enriched_artifact.setdefault("source_name_suggestion", suggestion)
            return STTMArtifactType.DERIVED_SOURCE_DRAFT, enriched_artifact
        if artifact_type == STTMArtifactType.DERIVED_SOURCE_DRAFT:
            enriched_artifact = enrich_derived_contract(artifact)
            enriched_artifact.setdefault("open_in_builder", True)
            if suggestion := cls._suggest_derived_source_name(req.data.message or ""):
                enriched_artifact.setdefault("source_name_suggestion", suggestion)
            return artifact_type, enriched_artifact
        return artifact_type, artifact

    @staticmethod
    def _derived_sql_tables_outside_scope(
        sql_text: str,
        source_tables: list[TableRef],
        additional_allowed_identifiers: list[str] | None = None,
    ) -> list[str]:
        """Return physical SQL tables that are not in the selected source graph.

        CTE aliases are intentionally ignored. Fully-qualified, schema-qualified,
        short, and semantic-model-style table identifiers for selected sources
        are accepted so this guard does not reject valid Cortex Analyst SQL.
        """
        if not sql_text:
            return []
        try:
            from sqlglot import exp, parse_one

            statement = parse_one(sql_text, read="snowflake")
        except Exception:
            # SQL validation remains responsible for syntax errors. A parser
            # failure must not invent an out-of-scope diagnosis.
            return []

        cte_names = {
            str(cte.alias_or_name or "").replace('"', "").upper()
            for cte in statement.find_all(exp.CTE)
            if cte.alias_or_name
        }
        allowed: set[str] = set()
        for table in source_tables:
            database = str(table.database).replace('"', "").upper()
            schema = str(table.schema).replace('"', "").upper()
            name = str(table.table).replace('"', "").upper()
            allowed.update(
                {
                    name,
                    f"{schema}.{name}",
                    f"{database}.{schema}.{name}",
                    f"{schema}_{name}",
                    f"{database}_{schema}_{name}",
                }
            )
        for value in additional_allowed_identifiers or []:
            normalized = str(value).replace('"', "").upper()
            if not normalized:
                continue
            allowed.add(normalized)
            allowed.add(normalized.rsplit(".", 1)[-1])

        outside: list[str] = []
        for table in statement.find_all(exp.Table):
            short_name = str(table.name or "").replace('"', "").upper()
            if not short_name or short_name in cte_names:
                continue
            parts = [
                str(value).replace('"', "").upper()
                for value in (table.catalog, table.db, table.name)
                if value
            ]
            reference = ".".join(parts)
            candidates = {short_name, reference}
            if len(parts) >= 2:
                candidates.add(".".join(parts[-2:]))
            if candidates.isdisjoint(allowed):
                display = ".".join(
                    str(value).replace('"', "")
                    for value in (table.catalog, table.db, table.name)
                    if value
                )
                if display and display not in outside:
                    outside.append(display)
        return outside

    @staticmethod
    def _suggest_derived_source_name(message: str) -> str | None:
        lowered = message.lower()
        phrase_map = [
            (r"\bmetadata mapping report\b", "metadata_mapping_report"),
            (r"\bbusiness attributes?\b", "business_attributes"),
            (r"\bproject status\b", "project_status"),
            (r"\bsource columns?\b", "source_columns"),
            (r"\battribute types?\b", "attribute_types"),
            (r"\btransformation logic\b", "transformation_logic"),
            (r"\bcalculation rules?\b", "calculation_rules"),
            (r"\bcustomer\b", "customer"),
            (r"\border[s]?\b", "orders"),
            (r"\brevenue\b", "revenue"),
        ]
        parts: list[str] = []
        for pattern, replacement in phrase_map:
            if re.search(pattern, lowered) and replacement not in parts:
                parts.append(replacement)

        if not parts:
            cleaned = lowered
            for token in (
                "derived source",
                "derived table",
                "create",
                "generate",
                "build",
                "show",
                "with",
                "that",
                "sql",
                "query",
            ):
                cleaned = cleaned.replace(token, " ")
            stop_words = {
                "a",
                "an",
                "the",
                "all",
                "and",
                "for",
                "their",
                "this",
                "from",
                "into",
                "using",
                "along",
                "include",
                "including",
                "about",
            }
            tokens = [
                token
                for token in re.split(r"[^a-z0-9]+", cleaned)
                if token and token not in stop_words
            ]
            parts = tokens[:5]

        cleaned = "_".join(parts).strip("_")
        if not cleaned:
            return None
        return cleaned[:64]

    @staticmethod
    def _sanitize_final_chat_message(message: str | None) -> str | None:
        if not isinstance(message, str):
            return message

        normalized = message.strip()
        if not normalized:
            return None

        derived_heading_match = re.search(
            r"(?im)^(?:#{1,3}\s*)?derived source\b",
            normalized,
        )
        if derived_heading_match and derived_heading_match.start() > 0:
            anchored = normalized[derived_heading_match.start() :].strip()
            if anchored:
                return anchored

        paragraphs = [part.strip() for part in re.split(r"\n\s*\n", normalized) if part.strip()]
        if len(paragraphs) < 2:
            return normalized

        intro_pattern = re.compile(
            r"^(thank you|thanks|i['’]ll|i will|let me|now i['’]ll|perfect!? now|to answer|i can help)\b",
            re.IGNORECASE,
        )
        heading_pattern = re.compile(
            r"^(derived source\b|summary\b|query logic\b|purpose\b|use cases\b|what this bundle\b|selected tables\b|here['’]s\b|#{1,3}\s)",
            re.IGNORECASE,
        )

        kept: list[str] = []
        dropping = True
        for paragraph in paragraphs:
            first_line = next(
                (line.strip() for line in paragraph.splitlines() if line.strip()),
                "",
            )
            if dropping and intro_pattern.match(first_line):
                continue
            if dropping and heading_pattern.match(first_line):
                dropping = False
            elif dropping:
                dropping = False
            kept.append(paragraph)

        cleaned = "\n\n".join(kept).strip()
        return cleaned or normalized

    @staticmethod
    def _should_use_analyst(
        req: STTMBuilderEnvelopeRequest,
        semantic_refresh: Any | None,
    ) -> bool:
        """Return whether transport may intentionally bypass the orchestrator.

        Normal sidebar chat must always reach AGT_STTM_BUILDER. Analyst is a
        request-scoped backend delegation, not a keyword-based chat route.  The old
        keyword path bypassed the orchestrator for derived-source and broad SQL
        words, which made relationship/readiness/recommendation questions look
        like underspecified data questions.

        Keep a narrowly scoped escape hatch for internal, explicitly governed
        callers.  Browser requests never set it.
        """
        if req.data.intent != Interface.CHAT or semantic_refresh is None:
            return False
        if semantic_refresh.achieved_level != SemanticLevel.FULL_REGISTRY:
            return False
        if not (
            semantic_refresh.semantic_view_name
            or getattr(semantic_refresh, "semantic_model_yaml", None)
        ):
            return False
        # A derived-source intent still belongs to the builder orchestrator.
        # Only an explicitly governed internal bypass may skip that agent.
        return bool(req.meta.get("allow_direct_analyst_bypass"))

    @staticmethod
    def _with_semantic_gap_notice(req, response):
        from app.core.semantic_evidence import missing_semantic_assets
        missing = missing_semantic_assets(req.context)
        if not missing:
            return response
        response.meta = {**(response.meta or {}), "semantic_evidence_coverage": {
            "status": "partial", "missing_assets": missing, "analyst_ready": False}}
        visible = ", ".join(missing[:8]) + (f" and {len(missing) - 8} more selected assets" if len(missing) > 8 else "")
        notice = "Semantic evidence gap: native YAML missing or unusable for " + visible + ". Generate or refresh these assets to improve recommendations; review assumptions against current bindings."
        if not any(item.code == "SEMANTIC_EVIDENCE_GAP" for item in response.warnings):
            response.warnings.append(ApiWarning(code="SEMANTIC_EVIDENCE_GAP", message=notice))
        if req.data.intent == Interface.CHAT and response.data is not None:
            message = response.data.message or ""
            if notice not in message:
                response.data.message = (message.rstrip() + "\n\n" + notice).lstrip()
        return response

    def _request_scoped_analyst_config(self, req, semantic_refresh, decision):
        from app.core.semantic_evidence import missing_semantic_assets
        if req.data.intent == Interface.CHAT and missing_semantic_assets(req.context, semantic_refresh):
            # Use the same caller's deployed builder instructions/tools, without
            # binding an unrelated default Analyst view or materializing partial YAML.
            return SnowflakeAgentClient.without_analyst(
                self._agent.get_specification(self._resolved_agent_name(req)))
        if not self._settings.agent_request_scoped_analyst_v1 or req.data.intent != Interface.CHAT:
            return None
        self._model_guard.assert_model_target_allowed(
            operation=req.operation.value, target="analyst", decision=decision,
        )
        if semantic_refresh is None or not req.context.semantic_bundle_id:
            return None
        bundle_hash = getattr(semantic_refresh, "bundle_hash", None)
        if not bundle_hash:
            # Older prepared handles omitted the hash. Recompose from the live
            # selection rather than accepting an arbitrary client view or hash.
            resolved_req, resolved = self._refresh_semantic_context_for_explicit_resolve(req)
            if resolved_req.context.semantic_bundle_id != req.context.semantic_bundle_id:
                raise SnowflakeAgentError("Prepared selection changed; prepare the workspace again.")
            bundle_hash = resolved.bundle_hash
            if not bundle_hash:
                raise SnowflakeAgentError("Request-scoped Analyst requires the prepared bundle hash.")
        # Fetch under the same caller before any materialization; access failures
        # are terminal, never a reason to switch roles or silently change routes.
        spec = self._agent.get_specification(self._resolved_agent_name(req))
        try:
            view = self._semantic_context_service.materialize_analyst_bundle_view(
                bundle_id=req.context.semantic_bundle_id, bundle_hash=bundle_hash,
                schema_fqn=self._settings.agent_bundle_view_schema,
            )
        except Exception as exc:
            logger.exception("Request-scoped semantic view validation failed: bundle=%s", req.context.semantic_bundle_id)
            raise SnowflakeAgentError(
                "The current semantic bundle could not be validated as a native semantic view. "
                "No Analyst query was executed; review the bundle validation trace."
            ) from exc
        return SnowflakeAgentClient.with_bundle_analyst(
            spec, semantic_view=view, warehouse=self._settings.snowflake_warehouse,
        )

    @staticmethod
    def _uses_exact_context_retrieval(req) -> bool:
        return req.data.intent == Interface.CHAT or (
            req.data.intent == Interface.TRANSFORM
            and req.meta.get("auto_map_stage") != "complex_transformation"
        )

    def _continue_context_retrieval(self, req, raw_text, raw_payload, thread_id, *, seed_messages=None, run_config=None):
        """Execute only an agent-requested bounded read of this request."""
        if not self._uses_exact_context_retrieval(req):
            return raw_text, thread_id, raw_payload
        from app.core.assistant_context import project_assistant_context
        from app.core.assistant_retrieval import scoped_context, retrieve_context, budget_messages
        base, store = scoped_context(project_assistant_context(STTMAgentRequestEnvelope.from_builder_request(self._with_intent_route(req)).model_dump(mode="json", exclude_none=True)))
        results = []
        for _ in range(9):
            parsed = self._parse_chat_response(raw_text, raw_payload)
            meta = parsed[5] or {}
            delegation = meta.get('delegation') if isinstance(meta, dict) else None
            if not isinstance(delegation, dict) or delegation.get('tool') != 'WORKSPACE_CONTEXT':
                return raw_text, thread_id, raw_payload
            if len(results) >= 8:
                raise AgentPayloadBudgetError('Workspace context retrieval exceeded the per-turn limit')
            try:
                result = retrieve_context(store, delegation, min(32768, self._settings.agent_outbound_message_max_bytes // 4))
            except AgentPayloadBudgetError:
                result = {'section': delegation.get('section'), 'error': 'RANGE_TOO_LARGE', 'instruction': 'Request a narrower nested path or smaller string/json_text range.'}
            except ValueError:
                result = {
                    'section': delegation.get('section'), 'error': 'INVALID_CONTEXT_REQUEST',
                    'instruction': 'No content was returned. Use the exact current snapshot and section hashes from the manifest. For raw strings, end must not exceed items; for encoding json_text, end must not exceed json_characters. Paths and ranges must exist exactly; do not guess.',
                }
            results.append(result)
            packet = {**base, 'retrieved_workspace_context': results,
                'continuation_instruction': 'Continue the original user request using these exact backend results. Return the normal final response or a bounded additional WORKSPACE_CONTEXT delegation. Do not re-request supplied ranges.'}
            continuation = {'role': 'user', 'content': [{'type': 'text', 'text': json.dumps(packet, ensure_ascii=False)}]}
            history = list((seed_messages or [])[:-1])
            try:
                messages = budget_messages([*history, continuation], max_chars=self._settings.agent_outbound_message_max_chars, max_bytes=self._settings.agent_outbound_message_max_bytes)
            except AgentPayloadBudgetError:
                results.pop()
                results.append({'section': delegation.get('section'), 'error': 'CONTINUATION_BUDGET_EXCEEDED', 'instruction': 'Previously retrieved data remains authoritative. Request only a narrower required range; if the task requires all omitted content, report this limit explicitly.'})
                packet['retrieved_workspace_context'] = results
                continuation['content'][0]['text'] = json.dumps(packet, ensure_ascii=False)
                messages = budget_messages([*history, continuation], max_chars=self._settings.agent_outbound_message_max_chars, max_bytes=self._settings.agent_outbound_message_max_bytes)
            raw_text, thread_id, raw_payload = self._agent.run_detailed(
                messages, agent=None if run_config is not None else self._resolved_agent_name(req),
                thread_id=None, parent_message_id=None,
                **({"run_config": run_config} if run_config is not None else {}),
            )
        return raw_text, thread_id, raw_payload

    @staticmethod
    def _analyst_delegation(
        response: STTMBuilderResponse,
    ) -> dict[str, Any] | None:
        """Return a validated orchestrator-requested Analyst delegation.

        Routing remains an AGT_STTM_BUILDER decision. This method deliberately
        does not inspect the user's words or infer intent in application code;
        it only executes the typed tool request returned by the orchestrator
        when a dynamic Analyst tool was unavailable in that agent run.
        """

        meta = response.meta if isinstance(response.meta, dict) else {}
        delegation = meta.get("delegation")
        if not isinstance(delegation, dict):
            return None
        if str(delegation.get("tool") or "").strip().upper() != "CORTEX_ANALYST":
            return None
        if delegation.get("requires_actual_rows") is not True and delegation.get("purpose") != "sql_generation":
            return None
        question = str(delegation.get("question") or "").strip()
        if not question:
            return None
        return {
            "tool": "CORTEX_ANALYST",
            "requires_actual_rows": delegation.get("requires_actual_rows") is True and delegation.get("purpose") != "sql_generation",
            **({"purpose": "sql_generation"} if delegation.get("purpose") == "sql_generation" else {}),
            "question": question,
            "reason": str(delegation.get("reason") or "").strip() or None,
        }

    def _execute_requested_analyst_delegation(
        self,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
        *,
        semantic_refresh: Any | None,
        decision: GovernanceDecision,
    ) -> STTMBuilderResponse:
        from app.core.semantic_evidence import missing_semantic_assets
        if missing_semantic_assets(req.context, semantic_refresh):
            return self._with_semantic_gap_notice(req, response)
        if semantic_refresh is not None and not getattr(semantic_refresh, "analyst_ready", True):
            response.warnings.append(ApiWarning(code="SEMANTIC_RELATIONSHIP_GAP",
                message="Analyst execution is unavailable for the incomplete relationship graph. Review the builder draft and confirm missing join/population contracts."))
            response.meta = {**(response.meta or {}), "analyst_delegation_status": "relationship_gap"}
            return response
        if self._settings.agent_request_scoped_analyst_v1:
            # Native tool results have already returned through the orchestrator.
            # Never duplicate execution through the legacy backend fallback.
            return response
        delegation = self._analyst_delegation(response)
        if delegation is None and self._needs_analyst_derived_fallback(req, response):
            delegation = {
                "tool": "CORTEX_ANALYST",
                "requires_actual_rows": True,
                "question": (req.data.message or "").strip(),
                "reason": (
                    "The user requested generated CTE/derived-source SQL, but the "
                    "orchestrator response did not contain executable SQL."
                ),
                "fallback": "derived_source_contract",
            }
        if delegation is None:
            return response

        if (
            semantic_refresh is not None
            and not getattr(semantic_refresh, "semantic_view_name", None)
            and not getattr(semantic_refresh, "semantic_model_yaml", None)
            and req.context.semantic_bundle_id
        ):
            # Prepared chat intentionally omits YAML until Analyst is requested.
            # Resolve only this request's authorized bundle; never rebind a shared tool.
            bundle = self._semantic_context_service.get_bundle(bundle_id=req.context.semantic_bundle_id)
            if bundle and bundle.get("semantic_model_yaml"):
                semantic_refresh = SimpleNamespace(**{
                    **vars(semantic_refresh),
                    "semantic_model_yaml": bundle["semantic_model_yaml"],
                    "bundle_hash": bundle.get("bundle_hash") or getattr(semantic_refresh, "bundle_hash", ""),
                })

        if semantic_refresh is None or not (
            getattr(semantic_refresh, "semantic_view_name", None)
            or getattr(semantic_refresh, "semantic_model_yaml", None)
        ):
            response.meta = self._merge_agent_meta(
                response.meta,
                {
                    "delegation": {
                        **delegation,
                        "status": "unavailable",
                        "detail": (
                            "The prepared workspace has no executable Analyst "
                            "semantic model for this selection."
                        ),
                    }
                },
            )
            return response

        delegated_req = req.model_copy(
            update={
                "meta": {**req.meta, "analyst_generation_only": delegation.get("purpose") == "sql_generation"},
                "data": req.data.model_copy(
                    update={"message": delegation["question"]}
                )
            }
        )
        analyst_response = self._invoke_analyst(
            delegated_req,
            semantic_refresh,
            decision,
        )
        analyst_response.meta = self._merge_agent_meta(
            analyst_response.meta,
            {
                "delegation": {
                    **delegation,
                    "status": "completed",
                    "decided_by": "AGT_STTM_BUILDER",
                    "executed_by": "CORTEX_ANALYST",
                },
                "orchestrator_thread_id": response.thread_id,
                "orchestrator_parent_message_id": response.parent_message_id,
            },
        )
        return analyst_response

    @classmethod
    def _needs_analyst_derived_fallback(
        cls,
        req: STTMBuilderEnvelopeRequest,
        response: STTMBuilderResponse,
    ) -> bool:
        """Guarantee an executable derived-source result for explicit generation asks.

        AGT_STTM_BUILDER remains the first-hop orchestrator. If it returns only prose
        for an explicit CTE/derived-source generation request, the governed host uses
        the already-prepared semantic bundle with Cortex Analyst instead of silently
        finishing without SQL or an Open-in-Builder action.
        """
        from app.core.semantic_evidence import missing_semantic_assets
        if missing_semantic_assets(req.context):
            return False
        if not cls._is_derived_source_request(req):
            return False
        data = response.data
        if data is None:
            return True
        artifact = data.artifact if isinstance(data.artifact, dict) else {}
        return not (
            data.artifact_type == STTMArtifactType.DERIVED_SOURCE_DRAFT
            and isinstance(artifact.get("sql_text"), str)
            and artifact["sql_text"].strip()
        )

    def _invoke_analyst(
        self,
        req: STTMBuilderEnvelopeRequest,
        semantic_refresh: Any,
        decision: GovernanceDecision | None = None,
        *,
        analyst_response_override: SnowflakeAnalystResponse | None = None,
    ) -> STTMBuilderResponse:
        effective_decision = decision or self._build_governance_decision(req)
        if self._is_derived_source_request(req) and not bool(
            getattr(semantic_refresh, "analyst_ready", True)
        ):
            missing_assets = list(getattr(semantic_refresh, "missing_assets", []) or [])
            missing_relationships = list(
                getattr(semantic_refresh, "missing_relationships", []) or []
            )
            raise SemanticRelationshipInvalidError(
                "The complete semantic bundle is not Analyst-ready. Verify the missing "
                "relationship paths before generating derived SQL.",
                details=[
                    *[
                        {"field": "semantic_asset", "message": str(asset)}
                        for asset in missing_assets
                    ],
                    *[
                        {
                            "field": "semantic_relationship",
                            "message": json.dumps(item, sort_keys=True, default=str),
                        }
                        for item in missing_relationships
                    ],
                ],
            )
        self._model_guard.assert_model_target_allowed(
            operation=req.operation.value,
            target="analyst",
            decision=effective_decision,
        )
        analyst_question = self._build_analyst_question(req)
        cache_key = hashlib.sha256(
            json.dumps(
                {
                    "actor": req.actor.model_dump(mode="json") if req.actor else None,
                    "bundle_id": getattr(semantic_refresh, "bundle_id", None),
                    "bundle_hash": getattr(semantic_refresh, "bundle_hash", None),
                    "semantic_view": getattr(semantic_refresh, "semantic_view_name", None),
                    "relationship_hash": hashlib.sha256(
                        json.dumps(
                            req.context.relation_graph.model_dump(mode="json")
                            if req.context.relation_graph is not None
                            else [item.model_dump(mode="json") for item in (req.context.relationships or [])],
                            sort_keys=True,
                            default=str,
                        ).encode("utf-8")
                    ).hexdigest(),
                    "selected_columns": req.context.selected_columns_by_table or {},
                    "learning_context_hash": req.context.learning_context_hash,
                    "question": " ".join(analyst_question.lower().split()),
                },
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            ).encode("utf-8")
        ).hexdigest()
        cache_ttl = (
            _ANALYST_DERIVED_DRAFT_CACHE_TTL_SECONDS
            if self._is_derived_source_request(req)
            else _ANALYST_RESPONSE_CACHE_TTL_SECONDS
        )
        with _ANALYST_RESPONSE_CACHE_LOCK:
            cached = _ANALYST_RESPONSE_CACHE.get(cache_key)
            if cached and time.monotonic() - cached[0] <= cache_ttl:
                cached_response = cached[1].model_copy(deep=True)
                thread_id = req.context.thread_id or cached_response.thread_id
                cached_meta = dict(cached_response.meta)
                cached_meta["analyst_cache"] = {
                    "status": "hit",
                    "age_ms": round((time.monotonic() - cached[0]) * 1000, 1),
                }
                return cached_response.model_copy(
                    update={
                        "request_id": req.request_id,
                        "operation": req.operation,
                        "actor": req.actor,
                        "context": req.context.model_copy(
                            update={
                                "thread_id": thread_id,
                                "parent_message_id": req.context.parent_message_id,
                            }
                        ),
                        "thread_id": thread_id,
                        "parent_message_id": req.context.parent_message_id,
                        "meta": cached_meta,
                    }
                )
            if cached:
                _ANALYST_RESPONSE_CACHE.pop(cache_key, None)
        from app.core.local_model_audit import capture
        analyst_audit_id = capture("request", {
            "agent": "CORTEX_ANALYST", "request_id": req.request_id,
            "question": analyst_question, "bundle_id": getattr(semantic_refresh, "bundle_id", None),
            "semantic_view": getattr(semantic_refresh, "semantic_view_name", None),
        })
        analyst_started = time.perf_counter()
        analyst_response = analyst_response_override or self._analyst.ask(
            question=analyst_question,
            semantic_view=semantic_refresh.semantic_view_name,
            semantic_model_yaml=(
                None
                if semantic_refresh.semantic_view_name
                else getattr(semantic_refresh, "semantic_model_yaml", None)
            ),
        )
        analyst_ms = (time.perf_counter() - analyst_started) * 1000
        if analyst_audit_id:
            capture("response", {"agent": "CORTEX_ANALYST", "request_id": analyst_response.request_id,
                "text": analyst_response.text, "sql": analyst_response.sql,
                "metadata": analyst_response.response_metadata}, correlation_id=analyst_audit_id)
        observe(
            "analyst.invoke",
            analyst_ms,
            operation=req.operation.value,
            model_source=(
                "physical_semantic_view"
                if semantic_refresh.semantic_view_name
                else "composed_registry_yaml"
            ),
        )
        self._model_guard.guard_sql(analyst_response.sql, effective_decision)
        preview_started = time.perf_counter()
        preview_rows = (
            []
            if self._is_derived_source_request(req)
            or req.meta.get("analyst_generation_only")
            or any(warning.code == "UNSAFE_SQL_ARTIFACT" for warning in effective_decision.warnings)
            else self._preview_sql_rows(analyst_response.sql)
        )
        preview_ms = (time.perf_counter() - preview_started) * 1000
        if not self._is_derived_source_request(req):
            observe("analyst.preview", preview_ms, operation=req.operation.value)
        warnings = [
            ApiWarning(code="ANALYST_WARNING", message=warning.get("message", "Cortex Analyst warning"))
            for warning in analyst_response.warnings
            if isinstance(warning, dict)
        ]
        artifact_type = STTMArtifactType.ANALYST_ANSWER
        artifact = {
            "answer_text": analyst_response.text,
            "sql_text": analyst_response.sql,
            "preview_rows": preview_rows,
            "semantic_view_name": semantic_refresh.semantic_view_name,
            "semantic_model_source": (
                "physical_view"
                if semantic_refresh.semantic_view_name
                else "registry_composed_yaml"
            ),
            "semantic_sql_used": bool(analyst_response.sql),
            "fallback_to_standard_sql": not bool(analyst_response.sql),
            "suggestions": analyst_response.suggestions,
            "request_id": analyst_response.request_id,
        }
        if analyst_response.verified_query_used:
            artifact["verified_query_used"] = analyst_response.verified_query_used
        if self._is_derived_source_request(req) and analyst_response.sql:
            artifact_type = STTMArtifactType.DERIVED_SOURCE_DRAFT
            artifact["draft_kind"] = "analyst_generated"
            artifact["open_in_builder"] = True
            if suggestion := self._suggest_derived_source_name(req.data.message or ""):
                artifact["source_name_suggestion"] = suggestion

        response_message = self._analyst_result_message(
            req,
            preview_rows,
        ) or analyst_response.text or (
            "Cortex Analyst generated SQL for the current semantic view."
            if analyst_response.sql
            else "Cortex Analyst could not generate an answer for this request."
        )
        meta = {
            "analyst": {
                "request_id": analyst_response.request_id,
                "response_metadata": analyst_response.response_metadata,
            },
            "derived_sql_generation": {
                "operation": STTMOperation.DERIVED_SQL_GENERATE.value,
                "executed_by": "CORTEX_ANALYST",
                "model_source": (
                    "physical_semantic_view"
                    if semantic_refresh.semantic_view_name
                    else "composed_registry_yaml"
                ),
                "bundle_id": semantic_refresh.bundle_id,
                "bundle_hash": semantic_refresh.bundle_hash,
                "analyst_ready": getattr(semantic_refresh, "analyst_ready", True),
                "missing_assets": getattr(semantic_refresh, "missing_assets", []),
                "missing_relationships": getattr(semantic_refresh, "missing_relationships", []),
                "excluded_relationships": getattr(semantic_refresh, "excluded_relationships", []),
                "open_in_builder": artifact_type == STTMArtifactType.DERIVED_SOURCE_DRAFT,
            },
            "timings_ms": {
                **{
                    str(key): round(float(value), 1)
                    for key, value in (
                        getattr(semantic_refresh, "stage_timings_ms", {}) or {}
                    ).items()
                },
                "analyst": round(analyst_ms, 1),
                "preview": round(preview_ms, 1),
            },
        }
        thread_id = req.context.thread_id or f"analyst-{uuid.uuid4()}"
        error = None
        if not analyst_response.sql and not analyst_response.text:
            error = ApiError(
                title="Cortex Analyst returned no answer",
                detail="No text or SQL was returned for the request.",
                code="ANALYST_EMPTY_RESPONSE",
            )

        response = STTMBuilderResponse.from_invocation(
            req,
            thread_id=thread_id,
            parent_message_id=req.context.parent_message_id,
            agent=None,
            result=None,
            message=response_message,
            status=STTMStatus.COMPLETED,
            artifact_type=artifact_type,
            artifact=artifact,
            semantic_level_achieved=semantic_refresh.achieved_level,
            semantic_refresh_status={
                "bundle_id": semantic_refresh.bundle_id,
                "bundle_hash": semantic_refresh.bundle_hash,
                "bundle_label": semantic_refresh.bundle_label,
                "requested_level": semantic_refresh.requested_level,
                "achieved_level": semantic_refresh.achieved_level,
                "status": semantic_refresh.status,
                "semantic_view_name": semantic_refresh.semantic_view_name,
                "promoted": semantic_refresh.promoted,
                "cache_hit": semantic_refresh.cache_hit,
                "stale_reason": None,
            },
            warnings=warnings,
            error=error,
            meta=meta,
        )
        finalized = self._postflight_guard.finalize_sttm_response(response, effective_decision)
        if finalized.error is None:
            with _ANALYST_RESPONSE_CACHE_LOCK:
                if len(_ANALYST_RESPONSE_CACHE) >= 256:
                    expired = [
                        key
                        for key, (created_at, _response) in _ANALYST_RESPONSE_CACHE.items()
                        if time.monotonic() - created_at > _ANALYST_DERIVED_DRAFT_CACHE_TTL_SECONDS
                    ]
                    for key in expired:
                        _ANALYST_RESPONSE_CACHE.pop(key, None)
                    if len(_ANALYST_RESPONSE_CACHE) >= 256:
                        oldest_key = min(
                            _ANALYST_RESPONSE_CACHE,
                            key=lambda key: _ANALYST_RESPONSE_CACHE[key][0],
                        )
                        _ANALYST_RESPONSE_CACHE.pop(oldest_key, None)
                _ANALYST_RESPONSE_CACHE[cache_key] = (
                    time.monotonic(),
                    finalized.model_copy(deep=True),
                )
        return finalized

    @staticmethod
    def _analyst_result_message(
        req: STTMBuilderEnvelopeRequest,
        preview_rows: list[dict[str, Any]],
    ) -> str | None:
        """Turn a scalar Analyst execution result into the user-facing answer."""

        if len(preview_rows) != 1 or len(preview_rows[0]) != 1:
            return None
        column, value = next(iter(preview_rows[0].items()))
        question = (req.data.message or "").lower()
        if any(
            token in question
            for token in (
                "how many",
                "record count",
                "row count",
                "count of",
                "number of records",
                "total number of",
            )
        ):
            source_name = next(
                (
                    table.table
                    for table in (req.context.source_tables or [])
                    if table.table.lower() in question
                ),
                None,
            )
            if source_name:
                return f"The **{source_name}** table contains **{value} records**."
            return f"The result is **{value} records**."
        label = str(column).replace("_", " ").strip().lower()
        return f"The **{label}** is **{value}**."

    @classmethod
    def _build_analyst_question(cls, req: STTMBuilderEnvelopeRequest) -> str:
        """Preserve the business conversation when a turn is delegated to Analyst."""
        current = (req.data.message or "").strip()
        workspace = req.context.workspace_context
        workspace_payload = (
            workspace.model_dump(mode="json", exclude_none=True)
            if hasattr(workspace, "model_dump")
            else workspace
        )
        history: list[str] = []
        if isinstance(workspace_payload, dict):
            for item in (workspace_payload.get("conversation_history") or [])[-12:]:
                if not isinstance(item, dict):
                    continue
                role = str(item.get("role") or "").strip().lower()
                content = cls._trim_string(item.get("content"), 1800)
                if role in {"user", "assistant"} and content:
                    history.append(f"{role.upper()}: {content}")
        if history and history[-1].startswith("USER:") and history[-1][5:].strip() == current:
            history.pop()
        learning = req.context.learning_context
        evidence_payload: dict[str, Any] = {}
        if learning is not None:
            evidence_payload = {
                "curated_relationships": list(learning.curated_relationships)[:12],
                "target_mapping_patterns": list(learning.target_mapping_patterns)[:12],
                "linked_project_patterns": list(learning.linked_project_patterns)[:8],
                "used_inference_ids": list(learning.used_inference_ids)[:20],
                "used_recommendation_ids": list(learning.used_recommendation_ids)[:20],
            }
            evidence_payload = {
                key: value for key, value in evidence_payload.items() if value
            }
        evidence = (
            "\n\nVerified Workbench/FIR evidence (use as precedent; do not invent joins):\n"
            + json.dumps(evidence_payload, sort_keys=True, default=str)
            if evidence_payload
            else ""
        )
        if not history:
            return current + evidence
        return (
            "Continue the existing STTM conversation. Resolve pronouns such as 'this' or "
            "'those' from the recent turns. Use the current semantic model and only columns "
            "that it actually exposes. Treat prior SQL as learning evidence, not as text to copy. "
            "If the user asks to generate all recommended derived sources one by one, generate "
            "only the next not-yet-generated recommendation as a standalone derived-source draft "
            "and suggest 'Generate the next recommended derived source' for the following turn. "
            "Do not merge different row grains into one draft.\n\n"
            "Recent conversation:\n"
            + "\n".join(history)
            + f"\n\nCURRENT USER REQUEST: {current}"
            + evidence
        )

    @staticmethod
    def _should_answer_from_semantic_context(
        req: STTMBuilderEnvelopeRequest,
        semantic_refresh: Any | None,
    ) -> bool:
        if req.data.intent != Interface.CHAT or semantic_refresh is None:
            return False
        if req.context.surface != SemanticSurface.SOURCE_SELECTION:
            return False
        if STTMBuilderService._is_derived_source_request(req):
            return False
        text = (req.data.message or "").lower()
        analyst_tokens = (
            "sql",
            "query",
            "count",
            "sum",
            "average",
            "avg",
            "group by",
            "how many",
            "top ",
            "total ",
            "trend",
            "revenue",
        )
        if any(token in text for token in analyst_tokens):
            return False
        return any(
            token in text
            for token in (
                "selected tables",
                "tell me about",
                "what can you tell me",
                "relationship",
                "relationships",
                "join",
                "how are",
                "explain",
            )
        )

    def _invoke_semantic_context(
        self,
        req: STTMBuilderEnvelopeRequest,
        semantic_refresh: Any,
    ) -> STTMBuilderResponse:
        message = self._build_semantic_context_message(req, semantic_refresh)
        artifact = self._semantic_refresh_to_dict(semantic_refresh) or {}
        return STTMBuilderResponse.from_invocation(
            req,
            thread_id=req.context.thread_id or f"semantic-{uuid.uuid4()}",
            parent_message_id=req.context.parent_message_id,
            agent=None,
            result=None,
            message=message,
            status=STTMStatus.COMPLETED,
            artifact_type=STTMArtifactType.SEMANTIC_CONTEXT,
            artifact=artifact,
            semantic_level_achieved=semantic_refresh.achieved_level,
            semantic_refresh_status={
                "bundle_id": semantic_refresh.bundle_id,
                "bundle_hash": semantic_refresh.bundle_hash,
                "bundle_label": semantic_refresh.bundle_label,
                "requested_level": semantic_refresh.requested_level,
                "achieved_level": semantic_refresh.achieved_level,
                "status": semantic_refresh.status,
                "semantic_view_name": semantic_refresh.semantic_view_name,
                "promoted": semantic_refresh.promoted,
                "cache_hit": semantic_refresh.cache_hit,
                "stale_reason": None,
            },
            warnings=[],
            error=None,
            meta={"semantic_context_local": True},
        )

    @staticmethod
    def _build_semantic_context_message(
        req: STTMBuilderEnvelopeRequest,
        semantic_refresh: Any,
    ) -> str:
        source_tables = req.context.source_tables or []
        relationships = req.context.relationships or []
        semantic_items = req.context.semantic_context or []
        lines = []
        if semantic_refresh.bundle_label:
            lines.append(f"Here is a summary of `{semantic_refresh.bundle_label}`.")
        else:
            lines.append("Here is a summary of the selected tables.")
        if source_tables:
            table_names = ", ".join(table.table for table in source_tables)
            lines.append(f"Selected tables: {table_names}.")
        if relationships:
            rel = relationships[0]
            left = rel.left_table.table
            right = rel.right_table.table
            join_bits = [
                f"{cond.left_column} {cond.operator} {cond.right_column}"
                for cond in rel.conditions
            ]
            join_text = ", ".join(join_bits) if join_bits else "configured join conditions"
            lines.append(
                f"Primary relationship: `{left}` joins to `{right}` on {join_text}."
            )
            if len(relationships) > 1:
                lines.append(f"There are {len(relationships)} total relationships in the current selection.")
        descriptions = []
        for item in semantic_items[:4]:
            model = item.semantic_model if isinstance(item.semantic_model, dict) else {}
            description = model.get("domain_summary") or model.get("description")
            if isinstance(description, str) and description.strip():
                descriptions.append(f"`{item.table.table}`: {description.strip()}")
        if descriptions:
            lines.append("Table context:")
            lines.extend(descriptions)
        return "\n\n".join(lines)

    def _preview_sql_rows(self, sql_text: str | None) -> list[dict[str, Any]]:
        if not sql_text:
            return []
        preview_query = f"SELECT * FROM ({sql_text.rstrip().rstrip(';')}) AS ANALYST_PREVIEW LIMIT 5"
        try:
            rows = self._query_session.sql(preview_query).collect()
        except Exception as exc:  # pragma: no cover - preview failure should not break the chat path
            logger.warning("Analyst SQL preview failed: %s", exc)
            return []
        return [
            json.loads(json.dumps(row.as_dict(recursive=True), default=str))
            for row in rows
        ]

    @classmethod
    def _build_agent_payload_unbounded(cls, req: STTMBuilderEnvelopeRequest) -> str:
        payload = STTMAgentRequestEnvelope.from_builder_request(req)
        payload_dict = payload.model_dump(mode="json", exclude_none=True)
        context = payload_dict.get("context")
        if isinstance(context, dict):
            # Draft review history is persisted by autosave, not model evidence.
            # Keep the current row definition while avoiding repeated candidate/undo bodies.
            workspace = context.get("workspace_context")
            for row in (workspace.get("mapping_rows") or []) if isinstance(workspace, dict) else []:
                if isinstance(row, dict):
                    for key in ("ai_candidates", "ai_undo_snapshot"):
                        row.pop(key, None)
            # This is guidance to the orchestrator, not a backend-selected
            # execution route. AGT_STTM_BUILDER must decide from the requested
            # outcome and available context whether a tool is necessary.
            context["orchestration_policy"] = {
                "route_owner": "AGT_STTM_BUILDER",
                "routing_hint_is_advisory": True,
                "use_analyst_when": (
                    "The answer requires computing, filtering, aggregating, "
                    "or sampling actual rows from selected data."
                ),
                "answer_from_context_when": (
                    "The answer is available from prepared semantic, FIR, "
                    "precedent, mapping, relationship, or workspace context."
                ),
                "data_answer_contract": (
                    "For actual-data questions, invoke Cortex Analyst and "
                    "report the executed result; do not return SQL alone."
                ),
            }
            requested_target_columns: dict[str, list[str]] = {}
            for attribute in (payload_dict.get("data") or {}).get("attributes") or []:
                if not isinstance(attribute, dict):
                    continue
                target_table = cls._table_qualified_name(attribute.get("target_table"))
                target_attribute = attribute.get("target_attribute")
                if target_table and isinstance(target_attribute, str) and target_attribute:
                    requested_target_columns.setdefault(target_table, []).append(target_attribute)
            selected_columns = cls._precedent_selected_columns(
                context,
                requested_target_columns,
            )
            aliases = {}
            for node in (context.get("relation_graph") or {}).get("nodes") or []:
                table = cls._table_qualified_name(node.get("table")) or node.get("relation_id")
                if table:
                    aliases[str(node.get("alias") or "").upper()] = table
            for attribute in (payload_dict.get("data") or {}).get("attributes") or []:
                selected_mapping = attribute.get("selected_mapping") or {}
                for reference in [*(selected_mapping.get("source_attributes") or []),
                                  *(selected_mapping.get("source_dependencies") or [])]:
                    relation, _, column = str(reference).rpartition(".")
                    relation = aliases.get(relation.upper(), relation)
                    if relation and column:
                        selected_columns.setdefault(relation, []).append(column)
            context["semantic_context"] = cls._compact_semantic_context(
                context.get("semantic_context"),
                selected_columns,
                requested_target_columns,
                context.get("driving_table"),
                context.get("relationships"),
            )
            context["workspace_context"] = cls._compact_workspace_context(
                context.get("workspace_context")
            )
        compact_payload = _prune_empty(payload_dict)
        return json.dumps(compact_payload, separators=(",", ":"))

    def _build_agent_payload(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        emergency: bool = False,
    ) -> str:
        started = time.perf_counter()
        try:
            result = self.project_agent_payload(req, self._settings, emergency=emergency)
            if self._uses_exact_context_retrieval(req):
                from app.core.assistant_retrieval import budget_messages
                budget_messages([{'role': 'user', 'content': [{'type':'text', 'text':result.text}]}],
                    max_chars=self._settings.agent_outbound_message_max_chars, max_bytes=self._settings.agent_outbound_message_max_bytes)
        except AgentPayloadBudgetError:
            if not self._uses_exact_context_retrieval(req):
                raise
            from app.core.assistant_context import project_assistant_context
            from app.core.assistant_retrieval import scoped_context
            raw = STTMAgentRequestEnvelope.from_builder_request(self._with_intent_route(req)).model_dump(mode="json", exclude_none=True)
            projected, store = scoped_context(project_assistant_context(raw))
            logger.warning(
                "Assistant scoped context request_id=%s inline_chars=%s section_chars=%s workspace_chars=%s",
                req.request_id, len(json.dumps(projected, separators=(",", ":"))),
                {key: len(json.dumps(value)) for key, value in projected.get("context", {}).items()},
                {key: len(json.dumps(value)) for key, value in
                 (projected.get("context", {}).get("workspace_context") or {}).items()},
            )
            result = budget_agent_payload(projected, max_chars=self._settings.agent_outbound_message_max_chars - 512,
                max_bytes=self._settings.agent_outbound_message_max_bytes - 512, enabled=False)
            from app.core.assistant_retrieval import budget_messages
            budget_messages([{'role':'user', 'content':[{'type':'text', 'text':result.text}]}],
                max_chars=self._settings.agent_outbound_message_max_chars, max_bytes=self._settings.agent_outbound_message_max_bytes)
        diagnostics = result.diagnostics
        observe("agent.payload.original_chars", diagnostics["original_chars"])
        observe("agent.payload.final_chars", diagnostics["final_chars"])
        observe("agent.payload.budget_ms", (time.perf_counter() - started) * 1000)
        increment(
            "agent.payload.compacted"
            if diagnostics["compacted"]
            else "agent.payload.under_budget"
        )
        if diagnostics["emergency_compaction"]:
            increment("agent.payload.emergency_compaction")
        logger.info(
            "Agent payload budget request_id=%s original_chars=%s final_chars=%s "
            "original_bytes=%s final_bytes=%s compacted=%s emergency=%s "
            "artifact_bodies_removed=%s largest_sections=%s",
            req.request_id,
            diagnostics["original_chars"],
            diagnostics["final_chars"],
            diagnostics["original_bytes"],
            diagnostics["final_bytes"],
            diagnostics["compacted"],
            diagnostics["emergency_compaction"],
            diagnostics["artifact_bodies_removed"],
            diagnostics["largest_context_sections"],
        )
        return result.text

    @classmethod
    def project_agent_payload(cls, req, settings, *, emergency=False):
        """Pure projection shared by batch planning and worker dispatch."""
        from app.core.automap_batch import fast_project_enabled
        fast = req.meta.get("auto_map_fast_path") == "v1" and fast_project_enabled(settings, req.context.project_id)
        req = cls._with_intent_route(req)
        if (req.data.intent == Interface.TRANSFORM and req.meta.get("auto_map_stage") == "complex_transformation"
                and (getattr(settings, "automap_context_retrieval_v1", False)
                     or req.meta.get("_automap_fast_specialist") is True)):
            from app.core.automap_transform import transformation_packet
            raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
            projected = transformation_packet(raw)
            from app.core.assistant_retrieval import budget_messages
            text = json.dumps(projected, ensure_ascii=False, separators=(",", ":"))
            from app.core.automap_input_budget import input_limits, wire_messages
            chars, size = input_limits(settings)
            budget_messages(wire_messages([{"role": "user", "content": [{"type": "text", "text": text}]}]), max_chars=chars, max_bytes=size)
            return budget_agent_payload(projected, max_chars=chars, max_bytes=size, enabled=False)
        if req.data.intent == Interface.AUTO_MAP and (getattr(settings, "automap_context_retrieval_v1", False)
                                                     or fast):
            from app.core.automap_retrieval import AutoMapContext, batch_packet, encoded, digest
            from app.core.assistant_retrieval import budget_messages
            from app.core.automap_packet_policy import source_planning_input
            raw = source_planning_input(req)
            from app.core.automap_batch import _FastAutoMapContext
            from app.core.automap_packet_policy import source_context
            store = source_context(req, fast=fast, raw=raw)
            if fast:
                from app.core.automap_fast_context import FastContextPlan, validate_derived_output_contracts
                store.manifest()
                handoff = req.meta.get("_automap_fast_handoff") or {}
                discovered = isinstance(handoff.get("discovery"), dict)
                if discovered:
                    store.replay_parent_discovery(handoff)
                else:
                    store.discover_batch(lambda targets: {target: {"diagnostics": {"status": "not_prepared"}} for target in targets})
                proofs = validate_derived_output_contracts(req, None)
                plan = FastContextPlan(store, max_chars=settings.agent_outbound_message_max_chars,
                                       max_bytes=settings.agent_outbound_message_max_bytes,
                                       validated_derived=proofs, retry_outcomes=req.meta.get("auto_map_retry_outcomes"))
                from app.core.automap_evidence_tool import enabled, tool_hint
                if enabled(settings, 'source_mapping'):
                    from uuid import uuid4
                    plan.native_tool_hint = tool_hint(uuid4().hex, sorted(store.targets))
                from app.core.automap_exact_reads import initial_operations, read_operations
                from app.core.automap_policy import source_preparation_issues
                results, events = [], []
                from app.core.automap_exact_reads import ExactReadBudgetError
                from app.core.automap_fast_context import FINAL_RESERVE_SECONDS, FastContextDeadlineError
                cutoff = plan.deadline - FINAL_RESERVE_SECONDS if plan.deadline else None
                try:
                    read_operations(store, initial_operations(store, plan), settings=settings, results=results,
                        events=events, remaining=lambda: (cutoff - time.monotonic()) if cutoff else float("inf"))
                except ExactReadBudgetError as exc:
                    if cutoff is not None and time.monotonic() >= cutoff:
                        raise FastContextDeadlineError("Auto-map deadline reached during complete input preflight") from None
                    raise AgentPayloadBudgetError("Required exact-read preparation exceeds the operation budget") from exc
                from app.core.automap_fast_context import FastContextBudgetError
                preflight_groups = [set(store.targets)]
                subdivision_required = False
                while preflight_groups:
                    group = preflight_groups.pop(0)
                    try:
                        messages = plan.messages(results, targets=group,
                            issues=source_preparation_issues(raw.get("context") or {}))
                        break
                    except FastContextBudgetError:
                        subdivision_required = True
                        ordered = sorted(group)
                        if req.meta.get('automap_generation_policy') == 'draft-v3':
                            break
                        if len(ordered) > 1:
                            middle = len(ordered) // 2
                            preflight_groups[:0] = [set(ordered[:middle]), set(ordered[middle:])]
                else:
                    # Host sizing only, never a model prompt. The real worker
                    # returns per-target input outcomes without a provider POST.
                    result = budget_agent_payload({'preflight_only': True,
                        'context_budget': {'essential_contract_overflow': True}},
                        max_chars=plan.max_chars, max_bytes=plan.max_bytes, enabled=False)
                    result.diagnostics['fast_preflight'] = {'requires_target_subdivision': True,
                        'essential_contract_overflow': True, 'input_sizing_ready': False, 'runtime_ready': False}
                    return result
                if subdivision_required and req.meta.get('automap_generation_policy') == 'draft-v3':
                    result = budget_agent_payload({'preflight_only': True, 'context_budget': {'requires_target_subdivision': True}},
                        max_chars=plan.max_chars, max_bytes=plan.max_bytes, enabled=False)
                    result.diagnostics['fast_preflight'] = {'requires_target_subdivision': True,
                        'input_sizing_ready': False, 'runtime_ready': False}
                    return result
                block_manifest = plan.evidence_read_manifest()
                if not block_manifest['evidence_review_feasible']:
                    from app.core.automap_evidence_blocks import EvidenceReviewBudgetError
                    raise EvidenceReviewBudgetError(block_manifest)
                result = budget_agent_payload(json.loads(messages[0]["content"][0]["text"]),
                    max_chars=plan.max_chars, max_bytes=plan.max_bytes, enabled=False)
                if (not subdivision_required and req.meta.get('automap_generation_policy') == 'draft-v3'
                        and isinstance(req.meta.get('_automap_fast_handoff'), dict)):
                    from dataclasses import replace
                    from app.core.automap_frozen_packet import freeze
                    result = replace(result, frozen_packet=freeze(plan, messages, results, events))
                result.diagnostics["fast_preflight"] = {"requires_target_subdivision": subdivision_required, "baseline_only": not discovered, "runtime_ready": False, "input_sizing_ready": True,
                    "exact_reads_included": True, "discovery_complete": discovered, "exact_read_count": len(results),
                    "model_calls": 0, "packet_timings": getattr(plan, 'packet_timings', {}),
                    "complete_message_chars": len(encoded(messages)),
                    "complete_message_bytes": len(encoded(messages).encode("utf-8")), "complete_message_digest": digest(messages),
                    "evidence_review_required": bool(block_manifest["required_block_calls"]),
                    "pending_evidence_blocks": block_manifest["required_block_calls"],
                    "evidence_read_sizing": block_manifest}
                return result
            if getattr(settings, "automap_parallel_context_v1", False) is True:
                from app.core.automap_scan_context import prepare_scan_context
                from app.core.automap_shards import MessageBudget, MessageBudgetError
                settings.validate_parallel_automap()
                budget = MessageBudget(min(120000, settings.agent_outbound_message_max_chars),
                                       min(120000, settings.agent_outbound_message_max_bytes))
                try:
                    # Local sizing identity only, never an authenticated runtime scope.
                    prepared = prepare_scan_context(store, owner_id="host-preflight-placeholder", budget=budget)
                    directory = prepared.registry.directory(scope=prepared.scope, max_entries=1).payload
                    scan_sizes = [prepared.registry.read_shard(scope=prepared.scope, shard_id=shard.shard_id)
                                  for shard in prepared.registry._shards]
                except MessageBudgetError as exc:
                    largest = (getattr(exc, "components", ()) or ())[:3]
                    part = ("; largest components=" + ", ".join(
                        f"{item['part']} ({item['bytes']} bytes)" for item in largest)
                        if largest else "")
                    raise AgentPayloadBudgetError(
                        f"Parallel mandatory preparation cannot fit: {exc}{part}") from exc
                baseline = {
                    "stage": "parallel_preparation_budget_baseline",
                    "baseline_only": True, "runtime_ready": False,
                    "learning_discovery": "not_discovered", "model_calls": 0,
                    "owner_scope": "placeholder_not_authorization",
                    "target_count": len(prepared.target_ids),
                    "planned_shard_count": directory["total_shards"],
                    "max_scan_message_chars": max((message.char_count for message in scan_sizes), default=0),
                    "max_scan_message_bytes": max((message.byte_count for message in scan_sizes), default=0),
                    "plan_complete_coverage": prepared.complete_coverage,
                    "blocked_table_count": len(prepared.blocked_table_ids),
                    "excluded_group_count": directory["excluded_group_count"],
                    "excluded_record_count": directory["excluded_record_count"],
                    "scan_complete": False, "reduction_complete": False,
                    "warnings": ([{"code": "table_context_oversized", "message":
                        "Some whole-table context is blocked by the baseline budget; worker coverage may be partial."}]
                        if prepared.warnings else []),
                }
                result = budget_agent_payload({"parallel_preflight": baseline},
                    max_chars=budget.max_chars, max_bytes=budget.max_bytes, enabled=False)
                budget_messages([{"role": "user", "content": [{"type": "text", "text": result.text}]}],
                                max_chars=budget.max_chars, max_bytes=budget.max_bytes)
                result.diagnostics["parallel_preflight"] = baseline
                return result
            store.manifest()
            results = store.mandatory_results(max_bytes=min(32768, settings.agent_outbound_message_max_bytes // 4),
                                             max_operations=settings.automap_context_max_operations)
            packet = batch_packet(store, results)
            budget_messages([{"role": "user", "content": [{"type": "text", "text": encoded(packet)}]}],
                            max_chars=settings.agent_outbound_message_max_chars, max_bytes=settings.agent_outbound_message_max_bytes)
            return budget_agent_payload(packet, max_chars=settings.agent_outbound_message_max_chars,
                                        max_bytes=settings.agent_outbound_message_max_bytes, enabled=False)
        legacy_auto_map_transform = (
            req.data.intent == Interface.TRANSFORM
            and req.meta.get("auto_map_stage") == "complex_transformation"
        )
        if req.data.intent in {Interface.CHAT, Interface.TRANSFORM} and not legacy_auto_map_transform:
            from app.core.assistant_context import project_assistant_context
            raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
            projected = project_assistant_context(raw)
            if cls._uses_exact_context_retrieval(req):
                from app.core.assistant_retrieval import scoped_context, budget_messages
                projected, _ = scoped_context(projected)
                text = json.dumps(projected, ensure_ascii=False, separators=(",", ":"))
                budget_messages([{"role": "user", "content": [{"type": "text", "text": text}]}],
                                max_chars=settings.agent_outbound_message_max_chars,
                                max_bytes=settings.agent_outbound_message_max_bytes)
            try:
                return budget_agent_payload(
                    projected,
                    max_chars=settings.agent_outbound_message_max_chars,
                    max_bytes=settings.agent_outbound_message_max_bytes,
                    enabled=False,
                )
            except AgentPayloadBudgetError:
                sections = projected.get("context") or {}
                logger.warning("Assistant context budget exceeded: request_id=%s section_chars=%s",
                               req.request_id, {key: len(json.dumps(value, default=str)) for key, value in sections.items()})
                raise
        if getattr(settings, "automap_hybrid_context_v1", False) is True and req.data.intent in {Interface.AUTO_MAP, Interface.TRANSFORM}:
            from app.core.mapping_context import project_mapping_context
            raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
            projected = project_mapping_context(raw)
            # This path selects dependencies before budgeting. Never shorten a
            # required rule or silently discard evidence to make a batch fit.
            return budget_agent_payload(
                projected, max_chars=settings.agent_outbound_message_max_chars,
                max_bytes=settings.agent_outbound_message_max_bytes, enabled=False,
            )
        raw = json.loads(cls._build_agent_payload_unbounded(req))
        if legacy_auto_map_transform:
            # Preserve explicit nulls/empty dependencies in the selected decision.
            raw["data"]["attributes"] = [item.model_dump(mode="json") for item in req.data.attributes or []]
        max_chars = settings.agent_outbound_message_max_chars
        max_bytes = settings.agent_outbound_message_max_bytes
        from app.core.assistant_retrieval import budget_messages
        for _ in range(4):
            result = budget_agent_payload(
                raw, max_chars=max_chars, max_bytes=max_bytes,
                enabled=settings.agent_payload_budget_v1, emergency=emergency,
                # Auto-map packets contain repeated graph/semantic contracts.
                # Use the existing reversible encoding, not semantic truncation.
                compact_encoding=(req.data.intent == Interface.AUTO_MAP or legacy_auto_map_transform
                                  or getattr(settings, "agent_payload_compact_encoding", False)),
            )
            messages = [{"role": "user", "content": [{"type": "text", "text": result.text}]}]
            wire = json.dumps(messages, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            extra_chars = max(0, len(wire) - settings.agent_outbound_message_max_chars)
            extra_bytes = max(0, len(wire.encode("utf-8")) - settings.agent_outbound_message_max_bytes)
            if not extra_chars and not extra_bytes:
                return result
            # Account for escaped JSON inside the message, not just a fixed header.
            max_chars = max(1, max_chars - extra_chars - 64)
            max_bytes = max(1, max_bytes - extra_bytes - 64)
        budget_messages(messages, max_chars=settings.agent_outbound_message_max_chars,
                        max_bytes=settings.agent_outbound_message_max_bytes)
        return result

    @classmethod
    def _precedent_selected_columns(
        cls,
        context: dict[str, Any],
        requested_target_columns: dict[str, list[str]],
    ) -> dict[str, list[str]]:
        """Select batch-relevant source columns without discarding full precedent rules."""
        # "Select all" is a UI contract, not a model-token contract. Starting
        # from the full selected-column set made every shadow batch resend up to
        # 80 attributes for each physical table. Build the model subset from
        # batch precedent, join keys, and lexical target relevance instead.
        selected: dict[str, set[str]] = {}
        target_names = {
            str(column).upper()
            for columns in requested_target_columns.values()
            for column in columns
        }
        source_tables = {
            cls._table_qualified_name(table): table
            for table in (context.get("source_tables") or [])
            if cls._table_qualified_name(table)
        }
        driving_name = cls._table_qualified_name(context.get("driving_table"))
        alias_to_relation: dict[str, str] = {"SOURCE": driving_name or ""}
        graph = context.get("relation_graph")
        if isinstance(graph, dict):
            for node in graph.get("nodes") or []:
                if not isinstance(node, dict):
                    continue
                relation_id = str(node.get("relation_id") or "")
                table_name = cls._table_qualified_name(node.get("table")) or relation_id
                alias = str(node.get("alias") or "")
                if alias and table_name:
                    alias_to_relation[alias.upper()] = table_name
            for edge in graph.get("edges") or []:
                if not isinstance(edge, dict):
                    continue
                left_id = str(edge.get("left_relation_id") or "")
                right_id = str(edge.get("right_relation_id") or "")
                for condition in edge.get("conditions") or []:
                    if not isinstance(condition, dict):
                        continue
                    left_column = condition.get("left_column")
                    right_column = condition.get("right_column")
                    if left_id and left_column:
                        selected.setdefault(left_id, set()).add(str(left_column))
                    if right_id and right_column:
                        selected.setdefault(right_id, set()).add(str(right_column))
        learning = context.get("learning_context")
        precedents = learning.get("mapping_precedents") if isinstance(learning, dict) else []
        dependency_values: list[str] = []
        for precedent in precedents or []:
            if not isinstance(precedent, dict):
                continue
            alias_contract = precedent.get("alias_contract")
            if isinstance(alias_contract, dict):
                for alias, relation in alias_contract.items():
                    if alias and relation:
                        alias_to_relation[str(alias).upper()] = str(relation)
            for mapping in precedent.get("mappings") or []:
                if not isinstance(mapping, dict):
                    continue
                target = str(
                    mapping.get("target_column")
                    or mapping.get("target_attribute")
                    or ""
                ).rsplit(".", 1)[-1].upper()
                if target not in target_names:
                    continue
                for key in ("source_dependencies", "source_columns", "source_attributes"):
                    value = mapping.get(key)
                    if isinstance(value, str):
                        dependency_values.append(value)
                    elif isinstance(value, list):
                        dependency_values.extend(str(item) for item in value if item)
                for key in ("source_column", "preprocessing_rule", "expression"):
                    value = mapping.get(key)
                    if isinstance(value, str):
                        dependency_values.append(value)

        known_upper = {name.upper(): name for name in source_tables}
        # Learned patterns come from other projects' schemas
        # (SCH_EVERNEST_HH_SOURCE.CONTACTS.company_name), so their source columns
        # resolve to this project's tables by table name.
        by_leaf: dict[str, str] = {}
        ambiguous_leaves: set[str] = set()
        for name in source_tables:
            leaf = name.rsplit(".", 1)[-1].upper()
            if leaf in by_leaf:
                ambiguous_leaves.add(leaf)
            by_leaf.setdefault(leaf, name)
        for leaf in ambiguous_leaves:
            by_leaf.pop(leaf, None)
        patterns = learning.get("target_mapping_patterns") if isinstance(learning, dict) else []
        for candidate in patterns or []:
            pattern = candidate.get("pattern") if isinstance(candidate, dict) else None
            if not isinstance(pattern, dict):
                continue
            contract = pattern.get("target_contract") if isinstance(pattern.get("target_contract"), dict) else {}
            if str(contract.get("target_column") or "").rsplit(".", 1)[-1].upper() not in target_names:
                continue
            recipe = pattern.get("mapping_recipe") if isinstance(pattern.get("mapping_recipe"), dict) else {}
            # A profile inventories the precedent's whole source system. It is
            # not this target recipe's dependency list; promoting every profile
            # column defeated batch-specific semantic selection.
            references = [
                *(recipe.get("source_dependencies") or []),
                *(recipe.get("logical_source_dependencies") or []),
                *(recipe.get("source_columns") or []),
            ]
            expression = recipe.get("expression")
            if isinstance(expression, str):
                try:
                    from sqlglot import exp, parse_one
                    references.extend(column.sql(dialect="snowflake") for column in parse_one(expression, read="snowflake").find_all(exp.Column))
                except Exception:
                    # Unknown expressions retain conservative profile coverage.
                    profile = pattern.get("source_system_profile") or {}
                    references.extend(item.get("physical_name") for item in profile.get("source_columns") or [] if isinstance(item, dict))
            for reference in references:
                parts = str(reference or "").replace('"', "").split(".")
                if len(parts) < 2:
                    continue
                relation = by_leaf.get(parts[-2].upper())
                if relation:
                    selected.setdefault(relation, set()).add(parts[-1].upper())
        for value in dependency_values:
            for qualifier, column in re.findall(
                r"([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*){0,2})\.([A-Za-z_$][\w$]*)",
                value,
            ):
                qualifier_upper = qualifier.upper()
                relation = known_upper.get(qualifier_upper) or alias_to_relation.get(qualifier_upper)
                if relation:
                    selected.setdefault(relation, set()).add(column)
                    continue
                # Fully-qualified references arrive as DB.SCHEMA.TABLE.COLUMN.
                for known_key, known_name in known_upper.items():
                    if qualifier_upper == known_key:
                        selected.setdefault(known_name, set()).add(column)
                        break
        return {table: sorted(columns) for table, columns in selected.items() if columns}

    @classmethod
    def _compact_semantic_context(
        cls,
        items: Any,
        selected_columns_by_table: Any,
        requested_target_columns_by_table: Any = None,
        driving_table: Any = None,
        relationships: Any = None,
    ) -> list[dict[str, Any]] | None:
        if not isinstance(items, list) or not items:
            return None
        selected_map = (
            selected_columns_by_table if isinstance(selected_columns_by_table, dict) else {}
        )
        target_map = (
            requested_target_columns_by_table
            if isinstance(requested_target_columns_by_table, dict)
            else {}
        )
        target_names = {str(name).upper() for name in target_map}
        driving_name = (cls._table_qualified_name(driving_table) or "").upper()
        related_names: set[str] = set()
        if isinstance(relationships, list):
            for relationship in relationships:
                if not isinstance(relationship, dict):
                    continue
                for key in ("left_table", "right_table"):
                    name = cls._table_qualified_name(relationship.get(key))
                    if name:
                        related_names.add(name.upper())

        def priority(item: Any) -> tuple[int, str]:
            if not isinstance(item, dict):
                return (9, "")
            name = (cls._table_qualified_name(item.get("table")) or "").upper()
            scope = str(item.get("scope") or "").upper()
            if name in target_names:
                return (0, name)
            if scope in {"DERIVED_SOURCE", "CTE"}:
                return (1, name)
            if driving_name and name == driving_name:
                return (2, name)
            if name in related_names:
                return (3, name)
            if name in {str(key).upper() for key in selected_map}:
                return (4, name)
            return (5, name)

        # Keep every relation's semantics, ordered target, CTEs, driving, joined,
        # selected. The payload budget reduces per-table detail instead of dropping
        # tables (the former positional caps removed the target, CTEs and sources).
        ordered_items = sorted(items, key=priority)
        compact_items: list[dict[str, Any]] = []
        for item in ordered_items:
            if not isinstance(item, dict):
                continue
            table = item.get("table")
            scope = item.get("scope")
            semantic_model = item.get("semantic_model")
            compact_model = cls._compact_semantic_model(
                table,
                semantic_model,
                selected_map,
                target_map,
                preserve_all_attributes=str(scope or "").upper()
                in {"DERIVED_SOURCE", "CTE"},
            )
            compact_items.append(
                _prune_empty(
                    {
                        "table": table,
                        "scope": scope,
                        "semantic_model": compact_model,
                    }
                )
            )
        return compact_items or None

    @classmethod
    def _compact_semantic_model(
        cls,
        table: Any,
        semantic_model: Any,
        selected_columns_by_table: dict[str, Any],
        requested_target_columns_by_table: dict[str, Any] | None = None,
        preserve_all_attributes: bool = False,
    ) -> Any:
        if isinstance(semantic_model, str):
            return cls._trim_string(semantic_model, 500)
        if isinstance(semantic_model, list):
            return semantic_model[:10]
        if not isinstance(semantic_model, dict):
            return semantic_model

        qualified_name = cls._table_qualified_name(table)
        selected_columns = selected_columns_by_table.get(qualified_name)
        requested_target_columns = (requested_target_columns_by_table or {}).get(qualified_name)
        attribute_names = {
            str(name).upper()
            for name in (requested_target_columns or selected_columns or [])
            if isinstance(name, str) and name.strip()
        }
        raw_attributes = semantic_model.get("attributes") or semantic_model.get("columns")
        compact_attributes: list[dict[str, Any]] = []
        if isinstance(raw_attributes, list):
            chosen_attributes = raw_attributes
            exact = [
                attr
                for attr in raw_attributes
                if isinstance(attr, dict)
                and str(attr.get("name", "")).upper() in attribute_names
            ]
            if preserve_all_attributes:
                chosen_attributes = raw_attributes
            elif requested_target_columns:
                chosen_attributes = exact
            elif requested_target_columns_by_table:
                target_tokens = {
                    token
                    for columns in requested_target_columns_by_table.values()
                    for column in columns
                    for token in re.split(r"[^A-Z0-9]+", str(column).upper())
                    if len(token) > 2
                }
                relevant = [
                    attr
                    for attr in raw_attributes
                    if isinstance(attr, dict)
                    and (
                        attr.get("is_primary_key")
                        or attr.get("is_foreign_key")
                        or bool(
                            target_tokens
                            & set(
                                token
                                for token in re.split(
                                    r"[^A-Z0-9]+", " ".join(str(attr.get(key) or "") for key in (
                                        "name", "business_meaning", "semantic_role", "synonyms",
                                    )).upper()
                                )
                                if len(token) > 2
                            )
                        )
                    )
                ]
                # Join keys and learned-pattern columns are additive to lexical
                # relevance: a join-key selection must not hide business columns.
                exact_ids = {id(attr) for attr in exact}
                chosen_attributes = [
                    *exact,
                    *(attr for attr in relevant[:24] if id(attr) not in exact_ids),
                ] or raw_attributes[:8]
            elif attribute_names:
                chosen_attributes = exact
            # Mapping still belongs entirely to AGT_SOURCE_MAPPING. Keep every
            # selected source attribute, while restricting target semantics to the
            # current batch, so the Agent has complete evidence without duplicated
            # full-workspace payloads.
            for attr in chosen_attributes:
                if not isinstance(attr, dict):
                    continue
                compact_attributes.append(
                    _prune_empty(
                        {
                            **{key: attr.get(key) for key in (
                                "business_meaning", "semantic_role", "synonyms", "value_profile",
                                "default_aggregation", "max_length", "nullable", "null_behavior",
                            ) if attr.get(key) is not None},
                            # Registry versions often store meaning only in summary.
                            # Preserve that meaning before any display-prose limits.
                            "business_meaning": attr.get("business_meaning") or attr.get("summary") or attr.get("description"),
                            "name": attr.get("name"),
                            "data_type": attr.get("data_type"),
                            "summary": (
                                attr.get("summary") or attr.get("description")
                                if attr.get("business_meaning")
                                else None
                            ),
                            "constraints": attr.get("constraints"),
                            "is_primary_key": attr.get("is_primary_key"),
                            "is_foreign_key": attr.get("is_foreign_key"),
                        }
                    )
                )

        output_columns: list[dict[str, Any]] = []
        raw_output_columns = semantic_model.get("output_columns")
        raw_column_semantics = semantic_model.get("column_semantics")
        semantic_by_name = {
            str(item.get("name") or item.get("column_name") or "").upper(): item
            for item in (raw_column_semantics if isinstance(raw_column_semantics, list) else [])
            if isinstance(item, dict)
        }
        if isinstance(raw_output_columns, list):
            for output in raw_output_columns[:100]:
                if not isinstance(output, dict):
                    continue
                name = output.get("name") or output.get("column_name")
                semantic = semantic_by_name.get(str(name or "").upper(), {})
                output_columns.append(
                    _prune_empty(
                        {
                            "name": name,
                            "data_type": output.get("data_type") or output.get("type"),
                            "description": cls._trim_string(
                                semantic.get("business_meaning")
                                or semantic.get("description")
                                or output.get("description"),
                                240,
                            ),
                            "source_columns": semantic.get("source_columns")
                            or output.get("source_columns"),
                            "is_primary_key": output.get("is_primary_key"),
                        }
                    )
                )

        relationships = semantic_model.get("relationships")
        compact_relationships = None
        if isinstance(relationships, dict):
            compact_relationships = {}
            for key in ("incoming", "outgoing"):
                rel_list = relationships.get(key)
                if not isinstance(rel_list, list):
                    continue
                compact_relationships[key] = [
                    _prune_empty(
                        {
                            "references_table": rel.get("references_table"),
                            "references_column": rel.get("references_column"),
                            "foreign_key": rel.get("foreign_key"),
                            "cardinality": rel.get("cardinality"),
                            "description": cls._trim_string(rel.get("description"), 160),
                        }
                    )
                    for rel in rel_list[:6]
                    if isinstance(rel, dict)
                ]

        return _prune_empty(
            {
                "description": cls._trim_string(semantic_model.get("description"), 500),
                "domain_summary": cls._trim_string(semantic_model.get("domain_summary"), 300),
                "business_context": cls._trim_string(semantic_model.get("business_context"), 500),
                "table_role_hint": semantic_model.get("table_role_hint"),
                "purpose": cls._trim_string(semantic_model.get("purpose"), 500),
                "grain": cls._trim_string(semantic_model.get("grain"), 240),
                "keys": semantic_model.get("keys"),
                "derived_source_id": semantic_model.get("derived_source_id"),
                "physical_view_name": semantic_model.get("physical_view_name"),
                "upstream_hash": semantic_model.get("upstream_hash"),
                "source_dependency_hash": semantic_model.get("source_dependency_hash"),
                "semantic_quality": semantic_model.get("semantic_quality"),
                "semantic_coverage_issues": semantic_model.get("semantic_coverage_issues"),
                "sql_text": semantic_model.get("sql_text"),
                **{key: semantic_model.get(key) for key in (
                    "semantic_registry", "semantic_view", "custom_instructions", "verified_queries", "metrics",
                ) if semantic_model.get(key) is not None},
                "column_catalog": [{"name": attr.get("name"), "data_type": attr.get("data_type"),
                                    "semantic_role": attr.get("semantic_role")}
                                   for attr in raw_attributes or [] if isinstance(attr, dict)],
                "attributes": compact_attributes or None,
                "output_columns": output_columns or None,
                "relationships": compact_relationships,
                "selected_ui_relationships": semantic_model.get("selected_ui_relationships"),
            }
        )

    @classmethod
    def _compact_workspace_context(
        cls,
        workspace_context: Any,
    ) -> dict[str, Any] | None:
        if not isinstance(workspace_context, dict):
            return None
        mapping_rows = workspace_context.get("mapping_rows")
        checked_ids = {
            str(item)
            for item in (workspace_context.get("checked_mapping_row_ids") or [])
            if item is not None
        }
        active_id = workspace_context.get("active_mapping_row_id")
        accepted_rows = []
        if isinstance(mapping_rows, list):
            accepted_rows = [
                _prune_empty(
                    {
                        "id": row.get("id"),
                        "target_column": row.get("target_column"),
                        "source_columns": row.get("source_columns") or row.get("source_column"),
                        "rule": row.get("rule"),
                        "expression": row.get("expression"),
                        "natural_language_rule": row.get("natural_language_rule"),
                        "description": row.get("description"),
                        "load_order": row.get("load_order"),
                        "confidence": row.get("confidence") or row.get("confidence_score"),
                        "confidence_reason": row.get("confidence_reason"),
                        "status": row.get("status"),
                    }
                )
                for row in mapping_rows
                if isinstance(row, dict)
                and (
                    (checked_ids and str(row.get("id") or "") in checked_ids)
                    or (active_id and str(row.get("id") or "") == str(active_id))
                    or row.get("source_columns") or row.get("source_column")
                    or row.get("expression")
                    or str(row.get("status") or "").lower() in {"accepted", "approved"}
                )
            ][:80]
        semantic = workspace_context.get("semantic")
        compact_semantic = None
        if isinstance(semantic, dict):
            compact_semantic = _prune_empty(
                {
                    "bundle_id": semantic.get("bundle_id"),
                    "bundle_hash": semantic.get("bundle_hash"),
                    "level": semantic.get("level"),
                    "asset_versions": semantic.get("asset_versions"),
                    "composed_model_hash": semantic.get("composed_model_hash"),
                }
            )
        return _prune_empty(
            {
                "context_version": workspace_context.get("context_version"),
                "context_hash": workspace_context.get("context_hash"),
                "page": workspace_context.get("page"),
                "surface": workspace_context.get("surface"),
                "driving_relation_id": workspace_context.get("driving_relation_id"),
                "mapping_intent": workspace_context.get("mapping_intent"),
                "mapping_rows": accepted_rows or None,
                "checked_mapping_row_ids": workspace_context.get("checked_mapping_row_ids"),
                "conversation_history": [
                    _prune_empty(
                        {
                            "role": item.get("role"),
                            "content": cls._trim_string(item.get("content"), 2000),
                        }
                    )
                    for item in (workspace_context.get("conversation_history") or [])[-30:]
                    if isinstance(item, dict)
                    and item.get("role") in {"user", "assistant"}
                    and cls._trim_string(item.get("content"), 2000)
                ] or None,
                "semantic": compact_semantic,
            }
        )

    @staticmethod
    def _table_qualified_name(table: Any) -> str | None:
        if not isinstance(table, dict):
            return None
        database = table.get("database")
        schema = table.get("schema")
        table_name = table.get("table")
        if all(isinstance(part, str) and part for part in (database, schema, table_name)):
            return f"{database}.{schema}.{table_name}"
        return None

    @staticmethod
    def _trim_string(value: Any, limit: int) -> str | None:
        if not isinstance(value, str):
            return None
        stripped = value.strip()
        if not stripped:
            return None
        if len(stripped) <= limit:
            return stripped
        return f"{stripped[:limit - 1].rstrip()}..."

    def _parse_envelope(
        self,
        raw: str,
    ) -> tuple[
        SubAgent | None,
        SourceMappingResult | TransformationResult | None,
        str | None,
        list[Any],
        Any,
        dict[str, Any],
        STTMStatus,
        STTMArtifactType | None,
        dict[str, Any] | None,
        SemanticLevel | None,
        dict[str, Any] | None,
    ]:
        json_str = _extract_json_object(raw)
        try:
            envelope: dict[str, Any] = json.loads(json_str)
        except json.JSONDecodeError as exc:
            raise SnowflakeAgentError(
                f"Orchestration agent response is not valid JSON: {exc} — raw: {raw[:400]}"
            ) from exc

        data = envelope.get("data") if isinstance(envelope.get("data"), dict) else envelope
        refresh_status = data.get("semantic_refresh_status")
        if refresh_status is not None:
            try:
                data["semantic_refresh_status"] = SemanticRefreshStatus.model_validate(
                    refresh_status
                ).model_dump(mode="json")
            except ValidationError:
                # Optional agent metadata is not evidence of a resolved bundle.
                # Keep the answer, but never invent a missing bundle identity.
                data["semantic_refresh_status"] = None
                warnings = envelope.get("warnings")
                envelope["warnings"] = [
                    *(warnings if isinstance(warnings, list) else []),
                    {"code": "INVALID_AGENT_SEMANTIC_STATUS",
                     "message": "The agent returned invalid semantic-refresh metadata; no bundle refresh was confirmed."},
                ]

        try:
            normalized_envelope = dict(envelope)
            if isinstance(normalized_envelope.get("error"), dict):
                normalized_error = _coerce_api_error(normalized_envelope["error"])
                if normalized_error is not None:
                    normalized_envelope["error"] = normalized_error.model_dump(mode="json")
            parsed = STTMAgentResponseEnvelope.model_validate(normalized_envelope)
        except ValidationError:
            parsed = None

        if parsed is not None:
            sub_agent = parsed.data.agent
            result = None
            if sub_agent and parsed.data.result is not None:
                result = self._validate_result(sub_agent, parsed.data.result.model_dump(mode="json"))
            if result is None and sub_agent is None:
                embedded = self._parse_embedded_envelope(parsed.data.message)
                if embedded is not None:
                    logger.info("Unwrapped structured sub-agent response from orchestrator message")
                    return self._merge_embedded_envelope(
                        outer=(
                            parsed.data.agent,
                            result,
                            parsed.data.message,
                            parsed.warnings,
                            parsed.error,
                            parsed.meta,
                            parsed.data.status,
                            parsed.data.artifact_type,
                            parsed.data.artifact,
                            parsed.data.semantic_level_achieved,
                            parsed.data.semantic_refresh_status.model_dump(mode="json")
                            if parsed.data.semantic_refresh_status
                            else None,
                        ),
                        nested=embedded,
                    )
            return (
                sub_agent,
                result,
                parsed.data.message,
                parsed.warnings,
                parsed.error,
                parsed.meta,
                parsed.data.status,
                parsed.data.artifact_type,
                parsed.data.artifact,
                parsed.data.semantic_level_achieved,
                parsed.data.semantic_refresh_status.model_dump(mode="json")
                if parsed.data.semantic_refresh_status
                else None,
            )

        data = envelope.get("data") if isinstance(envelope.get("data"), dict) else envelope
        agent_name: str | None = data.get("agent") or envelope.get("agent")
        raw_result: dict[str, Any] | None = data.get("result") or envelope.get("result")
        message: str | None = data.get("message") or envelope.get("message")
        warnings = envelope.get("warnings") if isinstance(envelope.get("warnings"), list) else []
        raw_error = envelope.get("error")
        error = _coerce_api_error(raw_error if isinstance(raw_error, (dict, ApiError)) else None)
        meta = envelope.get("meta") if isinstance(envelope.get("meta"), dict) else {}
        status = _status_from_payload(data)

        if not agent_name:
            embedded = self._parse_embedded_envelope(message)
            if embedded is not None:
                logger.info("Unwrapped structured sub-agent response from legacy orchestrator message")
                return self._merge_embedded_envelope(
                    outer=(
                        None,
                        None,
                        message,
                        warnings,
                        error,
                        meta,
                        STTMStatus.NEEDS_INPUT if message else status,
                        STTMArtifactType(data.get("artifact_type"))
                        if data.get("artifact_type") in {item.value for item in STTMArtifactType}
                        else None,
                        data.get("artifact") if isinstance(data.get("artifact"), dict) else None,
                        SemanticLevel(data.get("semantic_level_achieved"))
                        if data.get("semantic_level_achieved") in {item.value for item in SemanticLevel}
                        else None,
                        data.get("semantic_refresh_status")
                        if isinstance(data.get("semantic_refresh_status"), dict)
                        else None,
                    ),
                    nested=embedded,
                )
            return (
                None,
                None,
                message,
                warnings,
                error,
                meta,
                STTMStatus.NEEDS_INPUT if message else status,
                STTMArtifactType(data.get("artifact_type"))
                if data.get("artifact_type") in {item.value for item in STTMArtifactType}
                else None,
                data.get("artifact") if isinstance(data.get("artifact"), dict) else None,
                SemanticLevel(data.get("semantic_level_achieved"))
                if data.get("semantic_level_achieved") in {item.value for item in SemanticLevel}
                else None,
                data.get("semantic_refresh_status")
                if isinstance(data.get("semantic_refresh_status"), dict)
                else None,
            )

        sub_agent = _normalize_sub_agent(agent_name)

        if raw_result is None:
            if error is not None or status == STTMStatus.FAILED:
                return (
                    sub_agent,
                    None,
                    message,
                    warnings,
                    error,
                    meta,
                    status,
                    STTMArtifactType(data.get("artifact_type"))
                    if data.get("artifact_type") in {item.value for item in STTMArtifactType}
                    else None,
                    data.get("artifact") if isinstance(data.get("artifact"), dict) else None,
                    SemanticLevel(data.get("semantic_level_achieved"))
                    if data.get("semantic_level_achieved") in {item.value for item in SemanticLevel}
                    else None,
                    data.get("semantic_refresh_status")
                    if isinstance(data.get("semantic_refresh_status"), dict)
                    else None,
                )
            raise SnowflakeAgentError(f"Sub-agent {agent_name!r} returned a null result")

        validated = self._validate_result(sub_agent, raw_result)
        return (
            sub_agent,
            validated,
            message,
            warnings,
            error,
            meta,
            status,
            STTMArtifactType(data.get("artifact_type"))
            if data.get("artifact_type") in {item.value for item in STTMArtifactType}
            else None,
            data.get("artifact") if isinstance(data.get("artifact"), dict) else None,
            SemanticLevel(data.get("semantic_level_achieved"))
            if data.get("semantic_level_achieved") in {item.value for item in SemanticLevel}
            else None,
            data.get("semantic_refresh_status")
            if isinstance(data.get("semantic_refresh_status"), dict)
            else None,
        )

    def _parse_chat_response(
        self,
        raw: str,
        raw_payload: dict[str, Any] | None = None,
    ) -> tuple[
        SubAgent | None,
        SourceMappingResult | TransformationResult | None,
        str | None,
        list[Any],
        Any,
        dict[str, Any],
        STTMStatus,
        STTMArtifactType | None,
        dict[str, Any] | None,
        SemanticLevel | None,
        dict[str, Any] | None,
    ]:
        sse_message = _extract_sse_text(raw)
        if sse_message is not None:
            # A streamed terminal text may itself contain the structured answer.
            # Parse it through the same artifact path rather than displaying JSON.
            if self._parse_embedded_envelope(sse_message) is not None:
                return self._parse_chat_response(sse_message, raw_payload)
            return None, None, sse_message, [], None, {}, STTMStatus.COMPLETED, None, None, None, None

        try:
            parsed = self._parse_envelope(raw)
            if parsed[7] is not None:
                return parsed
            analyst_artifact = self._extract_agentic_analyst_artifact(raw_payload, parsed[2] or raw.strip())
            if analyst_artifact is None:
                return parsed
            return (
                parsed[0],
                parsed[1],
                parsed[2],
                parsed[3],
                parsed[4],
                parsed[5],
                parsed[6],
                STTMArtifactType.ANALYST_ANSWER,
                analyst_artifact,
                SemanticLevel.FULL_REGISTRY,
                None,
            )
        except SnowflakeAgentError:
            text = raw.strip()
            analyst_artifact = self._extract_agentic_analyst_artifact(raw_payload, text)
            if analyst_artifact is not None:
                return (
                    None,
                    None,
                    text or None,
                    [],
                    None,
                    {},
                    STTMStatus.COMPLETED,
                    STTMArtifactType.ANALYST_ANSWER,
                    analyst_artifact,
                    SemanticLevel.FULL_REGISTRY,
                    None,
                )
            return None, None, text or None, [], None, {}, STTMStatus.COMPLETED, None, None, None, None

    def _parse_embedded_envelope(
        self,
        message: str | None,
    ) -> tuple[
        SubAgent | None,
        SourceMappingResult | TransformationResult | None,
        str | None,
        list[Any],
        Any,
        dict[str, Any],
        STTMStatus,
        STTMArtifactType | None,
        dict[str, Any] | None,
        SemanticLevel | None,
        dict[str, Any] | None,
    ] | None:
        embedded_json = _extract_embedded_envelope_json(message)
        if embedded_json is None:
            return None
        try:
            return self._parse_envelope(embedded_json)
        except SnowflakeAgentError:
            logger.debug("Embedded orchestrator message looked like JSON but was not a valid envelope")
            return None

    @staticmethod
    def _merge_embedded_envelope(
        *,
        outer: tuple[
            SubAgent | None,
            SourceMappingResult | TransformationResult | None,
            str | None,
            list[Any],
            Any,
            dict[str, Any],
            STTMStatus,
            STTMArtifactType | None,
            dict[str, Any] | None,
            SemanticLevel | None,
            dict[str, Any] | None,
        ],
        nested: tuple[
            SubAgent | None,
            SourceMappingResult | TransformationResult | None,
            str | None,
            list[Any],
            Any,
            dict[str, Any],
            STTMStatus,
            STTMArtifactType | None,
            dict[str, Any] | None,
            SemanticLevel | None,
            dict[str, Any] | None,
        ],
    ) -> tuple[
        SubAgent | None,
        SourceMappingResult | TransformationResult | None,
        str | None,
        list[Any],
        Any,
        dict[str, Any],
        STTMStatus,
        STTMArtifactType | None,
        dict[str, Any] | None,
        SemanticLevel | None,
        dict[str, Any] | None,
    ]:
        return (
            nested[0] or outer[0],
            nested[1] or outer[1],
            nested[2] or outer[2],
            [*(outer[3] or []), *(nested[3] or [])],
            nested[4] or outer[4],
            {**(outer[5] or {}), **(nested[5] or {})},
            nested[6] or outer[6],
            nested[7] or outer[7],
            nested[8] or outer[8],
            nested[9] or outer[9],
            nested[10] or outer[10],
        )

    @staticmethod
    def _extract_agentic_analyst_artifact(
        raw_payload: dict[str, Any] | None,
        message_text: str | None,
    ) -> dict[str, Any] | None:
        if not isinstance(raw_payload, dict):
            return None
        content = raw_payload.get("content")
        if not isinstance(content, list):
            return None

        sql_result: dict[str, Any] | None = None
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue
            tool_result = block.get("tool_result")
            if not isinstance(tool_result, dict) or tool_result.get("type") != "system_execute_sql":
                continue
            nested_content = tool_result.get("content")
            if not isinstance(nested_content, list):
                continue
            for item in nested_content:
                if not isinstance(item, dict) or item.get("type") != "json":
                    continue
                json_payload = item.get("json")
                if isinstance(json_payload, dict):
                    sql_result = json_payload
                    break
            if sql_result is not None:
                break

        if sql_result is None:
            return None

        preview_rows: list[dict[str, Any]] = []
        result_set = sql_result.get("result_set")
        if isinstance(result_set, dict):
            row_meta = result_set.get("resultSetMetaData", {})
            row_types = row_meta.get("rowType", []) if isinstance(row_meta, dict) else []
            column_names = [
                str(item.get("name"))
                for item in row_types
                if isinstance(item, dict) and item.get("name")
            ]
            rows = result_set.get("data", [])
            if isinstance(rows, list):
                for row in rows[:5]:
                    if isinstance(row, list) and column_names:
                        preview_rows.append(
                            {
                                column_names[index]: row[index]
                                for index in range(min(len(column_names), len(row)))
                            }
                        )

        return {
            "answer_text": message_text or "",
            "sql_text": sql_result.get("sql"),
            "preview_rows": preview_rows,
            "semantic_view_name": sql_result.get("semantic_model_path"),
            "semantic_sql_used": bool(sql_result.get("sql")),
            "fallback_to_standard_sql": False,
            "query_id": sql_result.get("query_id"),
        }

    @staticmethod
    def _merge_agent_meta(
        meta: dict[str, Any],
        extra_meta: dict[str, Any] | None = None,
        *,
        raw_payload: dict[str, Any] | None = None,
        artifact_type: STTMArtifactType | None = None,
        artifact: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        merged = dict(meta or {})
        if extra_meta:
            for key, value in extra_meta.items():
                if isinstance(value, dict) and isinstance(merged.get(key), dict):
                    merged[key] = {**merged[key], **value}
                else:
                    merged[key] = value
        if raw_payload and "agent_run" not in merged:
            merged["agent_run"] = {
                "status": raw_payload.get("status"),
                "schema_version": raw_payload.get("schema_version"),
                "sequence_number": raw_payload.get("sequence_number"),
            }
        if artifact_type == STTMArtifactType.ANALYST_ANSWER and artifact:
            merged.setdefault("analyst", {})
            if artifact.get("query_id"):
                merged["analyst"]["query_id"] = artifact.get("query_id")
            if artifact.get("semantic_view_name"):
                merged["analyst"]["semantic_view_name"] = artifact.get("semantic_view_name")
        return merged

    @staticmethod
    def _validate_result(
        sub_agent: SubAgent,
        raw_result: dict[str, Any],
    ) -> SourceMappingResult | TransformationResult:
        try:
            if sub_agent == SubAgent.SOURCE_MAPPING_AGENT:
                mappings = _normalize_source_mappings(raw_result)
                return SourceMappingResult(mappings=mappings)

            if sub_agent == SubAgent.TRANSFORMATION_AGENT:
                return _normalize_transformation_result(raw_result)
        except (ValidationError, Exception) as exc:
            raise SnowflakeAgentError(
                f"{sub_agent} result failed schema validation: {exc}"
            ) from exc

        raise SnowflakeAgentError(f"Unhandled sub-agent type: {sub_agent}")


def _extract_json_object(text: str) -> str:
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end > start:
        return text[start : end + 1]
    return text.strip()


def _extract_embedded_envelope_json(text: str | None) -> str | None:
    if not isinstance(text, str):
        return None

    candidates: list[str] = []
    stripped = text.strip()
    if not stripped:
        return None

    fenced_blocks = re.findall(r"```(?:json)?\s*([\s\S]*?)```", stripped, flags=re.IGNORECASE)
    candidates.extend(block.strip() for block in fenced_blocks if block.strip())

    if stripped.startswith("{") and stripped.endswith("}"):
        candidates.append(stripped)

    if '"contract_version"' in stripped or '"operation"' in stripped or '"data"' in stripped:
        candidates.append(_extract_json_object(stripped))

    for candidate in candidates:
        json_candidate = _extract_json_object(candidate)
        try:
            payload = json.loads(json_candidate)
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, dict):
            continue
        if (
            payload.get("contract_version") == "1.0"
            or isinstance(payload.get("data"), dict)
            or payload.get("operation")
        ):
            return json.dumps(payload)

    return None


def _prune_empty(value: Any) -> Any:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, nested in value.items():
            pruned = _prune_empty(nested)
            if pruned in (None, [], {}):
                continue
            out[key] = pruned
        return out
    if isinstance(value, list):
        return [_prune_empty(item) for item in value]
    return value


def _status_from_payload(payload: dict[str, Any]) -> STTMStatus:
    raw_status = str(payload.get("status") or STTMStatus.COMPLETED.value).lower()
    try:
        return STTMStatus(raw_status)
    except ValueError:
        return STTMStatus.COMPLETED


def _normalize_sub_agent(agent_name: str) -> SubAgent:
    aliases = {
        "SOURCE_MAPPING_AGENT": SubAgent.SOURCE_MAPPING_AGENT,
        "AGT_SOURCE_MAPPING": SubAgent.SOURCE_MAPPING_AGENT,
        "source_mapping": SubAgent.SOURCE_MAPPING_AGENT,
        "TRANSFORMATION_AGENT": SubAgent.TRANSFORMATION_AGENT,
        "AGT_TRANSFORMATION_RULE": SubAgent.TRANSFORMATION_AGENT,
        "transformation_rules": SubAgent.TRANSFORMATION_AGENT,
    }
    normalized = aliases.get(agent_name) or aliases.get(agent_name.strip())
    if normalized:
        return normalized
    try:
        return SubAgent(agent_name)
    except ValueError as exc:
        raise SnowflakeAgentError(
            f"Unknown sub-agent in orchestration response: {agent_name!r}"
        ) from exc


def _normalize_source_mappings(raw_result: dict[str, Any]) -> dict[str, AttributeMapping]:
    raw_mappings = raw_result.get("mappings", raw_result)
    if not isinstance(raw_mappings, (dict, list)):
        raise ValueError("source mapping result must contain an object or list of mappings")
    result: dict[str, AttributeMapping] = {}
    entries = raw_mappings.items() if isinstance(raw_mappings, dict) else (
        (item.get("target") or item.get("target_attribute"), item)
        for item in raw_mappings if isinstance(item, dict)
    )
    from app.core.automap_row_candidates import capture_raw_proposals, retain_proposals, source_bindings
    for target, row in entries:
        if not isinstance(target, str) or not target:
            continue
        captured = capture_raw_proposals(row, target)
        clean_row = {key: value for key, value in row.items() if key != "candidates"} if isinstance(row, dict) else row
        if isinstance(raw_mappings, list) and isinstance(clean_row, dict) and not clean_row.get("candidate_source_attributes"):
            raw_shortlist = row.get("candidates")
            clean_row["candidate_source_attributes"] = [item for item in (raw_shortlist if isinstance(raw_shortlist, list) else [])
                if isinstance(item, str) or (isinstance(item, dict) and set(item) <= {"table", "column", "attribute"})]
        try:
            if isinstance(clean_row, dict):
                references = source_bindings(clean_row)
                if isinstance(raw_mappings, dict):
                    clean_row["source_attributes"] = references
            single = {target: clean_row} if isinstance(raw_mappings, dict) else [clean_row]
            result.update(_normalize_source_mapping_rows({"mappings": single}))
            if isinstance(row, dict):
                mapping = result[target]
                source_scores = isinstance(row.get("sources"), list) and any(
                    isinstance(item, dict) and any(type(item.get(key)) in (int, float)
                        for key in ("confidence", "confidence_score"))
                    for item in row["sources"])
                original_score = row.get("original_confidence_score", row.get("confidence_score",
                    mapping.confidence_score if source_scores else None))
                mapping.original_confidence_score = (original_score if type(original_score) in (int, float)
                    and 0 <= original_score <= 1 else None)
                raw_rule = row.get("preprocessing_rule", row.get("rule"))
                if isinstance(raw_rule, str):
                    mapping.preprocessing_rule = raw_rule
                    mapping.preprocessing_rule_type = row.get("preprocessing_rule_type", row.get("rule_type"))
                result[target] = retain_proposals(mapping, *captured)
        except (ValidationError, TypeError, ValueError) as exc:
            fields = sorted({".".join(str(part) for part in error["loc"])
                             for error in exc.errors()}) if isinstance(exc, ValidationError) else [
                                 field for field in ("sources", "source_attributes") if str(exc).startswith(field)
                             ] or ["mapping record"]
            result[target] = AttributeMapping(
                source_attributes=[], confidence_score=0,
                transformation_classification="unresolved",
                unmatched_reason="Agent mapping failed schema validation for: " + ", ".join(fields),
                candidates=captured,
                suggestions=[{"origin": "validation", "kind": "evidence", "message": "Unusable proposal fields (not executable): "
                    + json.dumps({key: row.get(key) for key in {field.split('.')[0] for field in fields}},
                                 default=str)[:2000]}] if isinstance(row, dict) else [],
            )
    return result


def _normalize_source_mapping_rows(raw_result: dict[str, Any]) -> dict[str, AttributeMapping]:
    raw_mappings = raw_result.get("mappings", raw_result)

    if isinstance(raw_mappings, dict):
        return {
            attr: AttributeMapping.model_validate(value)
            for attr, value in raw_mappings.items()
        }

    if not isinstance(raw_mappings, list):
        raise ValueError("source mapping result must contain an object or list of mappings")

    mappings: dict[str, AttributeMapping] = {}
    for item in raw_mappings:
        if not isinstance(item, dict):
            continue
        target = item.get("target") or item.get("target_attribute")
        if not isinstance(target, str) or not target:
            continue
        from app.core.automap_row_candidates import source_bindings
        source_attributes = source_bindings(item)
        sources = item["sources"] if "sources" in item else item.get("source_attributes", [])
        confidences: list[float] = []
        for source in sources:
            if not isinstance(source, dict):
                continue
            if "confidence_score" in source:
                confidences.append(float(source["confidence_score"]))
            elif "confidence" in source:
                confidences.append(_confidence_to_score(source["confidence"]))

        candidate_sources = item.get("candidate_source_attributes") or item.get("candidates") or []
        candidate_source_attributes: list[str] = []
        for candidate in candidate_sources:
            if isinstance(candidate, str):
                candidate_source_attributes.append(candidate)
                continue
            if not isinstance(candidate, dict):
                continue
            table_name = candidate.get("table")
            column_name = candidate.get("column") or candidate.get("attribute")
            if table_name and column_name:
                candidate_source_attributes.append(f"{table_name}.{column_name}")
            elif column_name:
                candidate_source_attributes.append(str(column_name))

        processing_order = item.get("processing_order")
        if processing_order is not None:
            try:
                processing_order = int(processing_order)
            except (TypeError, ValueError):
                processing_order = None

        raw_mapping_mode = str(item.get("mapping_mode") or "").strip().lower()
        if raw_mapping_mode in {"attribute", "project_attribute", "project_value"}:
            mapping_mode = "attribute"
        elif raw_mapping_mode in {"value", "constant", "literal", "placeholder"}:
            mapping_mode = "constant"
        else:
            mapping_mode = "source"
        raw_classification = str(item.get("transformation_classification") or "").strip().lower()
        classification_aliases = {
            "simple_multi_source": "simple_multi_source",
            "multi_source": "simple_multi_source",
            "value": "value",
            "direct": "direct",
            "reused": "reused",
            "complex": "complex",
            "unresolved": "unresolved",
        }
        classification = classification_aliases.get(raw_classification)

        mappings[target] = AttributeMapping(
            original_confidence_score=item.get('original_confidence_score', item.get('confidence_score')),
            decision_basis=item.get('decision_basis') or {},
            rule_intent=item.get('rule_intent'),
            admitted_source_attributes=[],  # Backend admission is never a model-authored field.
            precedent_reason=item.get('precedent_reason'),
            source_attributes=source_attributes,
            mapping_mode=mapping_mode,
            constant_value=item.get("constant_value", item.get("value")),
            attribute_name=item.get("attribute_name") or item.get("project_attribute_name"),
            source_dependencies=item.get("source_dependencies") or source_attributes,
            value_binding_ids=item.get("value_binding_ids") or [],
            transformation_classification=classification,
            precedent_decision=item.get("precedent_decision"),
            pattern_decision=item.get("pattern_decision"),
            precedent_mapping_id=item.get("precedent_mapping_id"),
            override_evidence=item.get("override_evidence") or [],
            confidence_score=item.get("confidence_score", max(confidences) if confidences else 0.0),
            confidence_reason=item.get("confidence_reason") or item.get("reason") or item.get("explanation"),
            candidate_source_attributes=candidate_source_attributes,
            suggestions=item.get("suggestions") or [],
            candidates=[option for option in item.get("candidates") or []
                        if isinstance(option, dict) and isinstance(option.get("source_attributes"), list)
                        and isinstance(option.get("confidence_score"), (int, float))],
            unmatched_reason=item.get("unmatched_reason"),
            preprocessing_rule=_sanitize_attribute_level_rule(item.get("preprocessing_rule") or item.get("rule")),
            preprocessing_rule_type=_sanitize_preprocessing_rule_type(
                item.get("preprocessing_rule") or item.get("rule"),
                item.get("preprocessing_rule_type") or item.get("rule_type"),
            ),
            preprocessing_nl_rule=item.get("preprocessing_nl_rule") or item.get("nl_rule"),
            processing_order=processing_order,
            description=item.get("description"),
            used_inference_ids=item.get("used_inference_ids") or item.get("learning_evidence") or [],
            used_recommendation_ids=item.get("used_recommendation_ids") or [],
            used_learning_ids=item.get("used_learning_ids") or [],
        )

    return mappings


def _normalize_transformation_result(raw_result: dict[str, Any]) -> TransformationResult:
    if "rules" not in raw_result or not isinstance(raw_result["rules"], list):
        return TransformationResult.model_validate(raw_result)

    rules: list[TransformationRule] = []
    for item in raw_result["rules"]:
        if not isinstance(item, dict):
            continue
        rules.append(
            TransformationRule(
                confidence_score=item.get('confidence_score') if type(item.get('confidence_score')) in (int, float) and 0 <= item['confidence_score'] <= 1 else None,
                confidence_reason=item.get('confidence_reason'),
                rule_candidate_id=item.get('rule_candidate_id'),
                target_attribute=str(item.get("target_attribute") or item.get("target_id") or ""),
                rule=str(item.get("rule") or item.get("transformation_rule") or ""),
                description=item.get("description"),
                used_inference_ids=item.get("used_inference_ids") or item.get("learning_evidence") or [],
                used_recommendation_ids=item.get("used_recommendation_ids") or [],
                learning_evidence=item.get("learning_evidence") or [],
                pattern_decision=item.get("pattern_decision"),
                precedent_decision=item.get("precedent_decision"),
                source_dependencies=item.get("source_dependencies") or [],
                value_binding_ids=item.get("value_binding_ids") or [],
                override_evidence=item.get("override_evidence") or [],
            )
        )
    return TransformationResult(rules=rules)


def _sanitize_attribute_level_rule(value: Any) -> str:
    rule = str(value or "").strip()
    if not rule:
        return ""

    # Mapping and preprocessing rules must be attribute-level expressions. Step 1 already
    # owns FROM/JOIN/WHERE construction, so we reject query-shaped SQL here instead of
    # applying misleading transformations in the mapping grid.
    scrubbed = re.sub(r"'(?:''|[^'])*'", "''", rule)
    if re.search(
        r"(?i)\b(select|with|from|join|where|qualify|group\s+by|having|order\s+by)\b",
        scrubbed,
    ):
        return ""
    if ";" in scrubbed:
        return ""
    return rule


def _sanitize_preprocessing_rule_type(rule_value: Any, rule_type: Any) -> str | None:
    sanitized_rule = _sanitize_attribute_level_rule(rule_value)
    normalized_type = str(rule_type or "").strip() or None
    if not sanitized_rule:
        return None
    return normalized_type


def _confidence_to_score(value: Any) -> float:
    if isinstance(value, (int, float)):
        return max(0.0, min(1.0, float(value)))
    lookup = {
        "HIGH": 0.9,
        "MEDIUM": 0.6,
        "LOW": 0.3,
    }
    return lookup.get(str(value).upper(), 0.0)


def _extract_sse_text(raw: str) -> str | None:
    text = raw.strip()
    if not text.startswith("event:"):
        return None

    final_payload: dict[str, Any] | None = None
    for chunk in text.split("\n\n"):
        lines = [line for line in chunk.splitlines() if line.strip()]
        if not lines:
            continue

        event_name: str | None = None
        data_parts: list[str] = []
        for line in lines:
            if line.startswith("event:"):
                event_name = line.partition(":")[2].strip()
            elif line.startswith("data:"):
                data_parts.append(line.partition(":")[2].lstrip())

        if event_name != "response" or not data_parts:
            continue

        raw_data = "\n".join(data_parts).strip()
        if raw_data == "[DONE]":
            continue

        try:
            payload = json.loads(raw_data)
        except json.JSONDecodeError:
            continue

        if isinstance(payload, dict):
            final_payload = payload

    if not final_payload:
        return None

    content = final_payload.get("content", [])
    if not isinstance(content, list):
        return None

    text_parts: list[str] = []
    for block in content:
        if not isinstance(block, dict) or block.get("type") != "text":
            continue
        block_text = block.get("text", "")
        if isinstance(block_text, str) and block_text.strip():
            text_parts.append(block_text.strip())

    return "\n\n".join(text_parts).strip() or None


def _find_nested_string(payload: Any, key: str) -> str | None:
    if isinstance(payload, dict):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
        for nested in payload.values():
            found = _find_nested_string(nested, key)
            if found:
                return found
    if isinstance(payload, list):
        for nested in payload:
            found = _find_nested_string(nested, key)
            if found:
                return found
    return None


def _find_nested_int(payload: Any, key: str) -> int | None:
    if isinstance(payload, dict):
        value = payload.get(key)
        if isinstance(value, int):
            return value
        if isinstance(value, str) and value.isdigit():
            return int(value)
        for nested in payload.values():
            found = _find_nested_int(nested, key)
            if found is not None:
                return found
    if isinstance(payload, list):
        for nested in payload:
            found = _find_nested_int(nested, key)
            if found is not None:
                return found
    return None


def _extract_assistant_message_id(payload: dict[str, Any] | None) -> int | None:
    if not isinstance(payload, dict):
        return None
    metadata = payload.get("metadata")
    if isinstance(metadata, dict):
        assistant_message_id = metadata.get("assistant_message_id") or metadata.get("message_id")
        if isinstance(assistant_message_id, int):
            return assistant_message_id
        if isinstance(assistant_message_id, str) and assistant_message_id.isdigit():
            return int(assistant_message_id)
    message = payload.get("message")
    if isinstance(message, dict):
        metadata = message.get("metadata")
        if isinstance(metadata, dict):
            assistant_message_id = metadata.get("assistant_message_id") or metadata.get("message_id")
            role = str(metadata.get("role") or "").strip().lower()
            if role in {"", "assistant"}:
                if isinstance(assistant_message_id, int):
                    return assistant_message_id
                if isinstance(assistant_message_id, str) and assistant_message_id.isdigit():
                    return int(assistant_message_id)

    def visit(node: Any) -> int | None:
        if isinstance(node, dict):
            role = str(node.get("role") or "").strip().lower()
            message_id = (
                node.get("assistant_message_id")
                or node.get("message_id")
            )
            if role == "assistant":
                if isinstance(message_id, int):
                    return message_id
                if isinstance(message_id, str) and message_id.isdigit():
                    return int(message_id)
            for nested in node.values():
                found = visit(nested)
                if found is not None:
                    return found
        if isinstance(node, list):
            for nested in node:
                found = visit(nested)
                if found is not None:
                    return found
        return None

    return visit(payload) or _find_nested_int(payload, "message_id")


def _extract_stream_message_metadata(
    event_name: str,
    payload: Any,
) -> dict[str, int | str] | None:
    if event_name != "metadata" or not isinstance(payload, dict):
        return None
    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        return None
    role = str(metadata.get("role") or "").strip().lower()
    message_id = metadata.get("message_id")
    if not role:
        return None
    if isinstance(message_id, str) and message_id.isdigit():
        return {"role": role, "message_id": int(message_id)}
    if isinstance(message_id, int):
        return {"role": role, "message_id": message_id}
    return None


def _extract_stream_response_payload(event_name: str, payload: Any) -> dict[str, Any] | None:
    if event_name == "response" and isinstance(payload, dict):
        return payload
    if isinstance(payload, dict):
        response = payload.get("response")
        if isinstance(response, dict):
            return response
    return None


def _extract_stream_message_text(payload: dict[str, Any] | None) -> str | None:
    if not isinstance(payload, dict):
        return None
    content = payload.get("content")
    if not isinstance(content, list):
        message = payload.get("message")
        if isinstance(message, dict):
            content = message.get("content")
    if not isinstance(content, list):
        return None
    text_parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "text":
            text_value = block.get("text")
            if isinstance(text_value, str) and text_value:
                text_parts.append(text_value)
        elif block.get("type") == "output_text":
            text_value = block.get("text")
            if isinstance(text_value, str) and text_value:
                text_parts.append(text_value)
    return "".join(text_parts).strip() or None


class _EnvelopeMessageExtractor:
    """Stream ``data.message`` out of the agent's JSON envelope while it is generated.

    The agent answers with one JSON object, so its text deltas are JSON. Rather than
    hiding everything until the final event, this incremental tokenizer tracks the
    object path and emits the decoded characters of the first string value at
    ``data.message``. Escapes, including ``\\uXXXX`` and surrogate pairs, may be
    split across chunks.
    """

    _ESCAPES = {"n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f", "/": "/", '"': '"', "\\": "\\"}

    def __init__(self) -> None:
        self._started = False
        self._done = False
        # One entry per open container: [kind, parent_key, current_key, expecting_key]
        self._stack: list[list[Any]] = []
        self._in_string = False
        self._string_is_key = False
        self._streaming = False
        self._key_buffer: list[str] = []
        self._escape = False
        self._unicode: str | None = None
        self._high_surrogate: int | None = None

    def _at_message(self) -> bool:
        return (
            len(self._stack) == 2
            and self._stack[0][0] == "obj"
            and self._stack[1][0] == "obj"
            and self._stack[1][1] == "data"
            and self._stack[1][2] == "message"
        )

    def _emit_char(self, char: str, out: list[str]) -> None:
        if self._streaming:
            out.append(char)
        elif self._string_is_key:
            self._key_buffer.append(char)

    def _emit_code_point(self, code: int, out: list[str]) -> None:
        if 0xD800 <= code <= 0xDBFF:
            self._high_surrogate = code
            return
        if 0xDC00 <= code <= 0xDFFF and self._high_surrogate is not None:
            code = 0x10000 + ((self._high_surrogate - 0xD800) << 10) + (code - 0xDC00)
        self._high_surrogate = None
        self._emit_char(chr(code), out)

    def push(self, chunk: str) -> str:
        if self._done or not chunk:
            return ""
        out: list[str] = []
        for char in chunk:
            if self._done:
                break
            if not self._started:
                if char == "{":
                    self._started = True
                    self._stack.append(["obj", None, None, True])
                continue
            if self._in_string:
                if self._unicode is not None:
                    self._unicode += char
                    if len(self._unicode) == 4:
                        try:
                            self._emit_code_point(int(self._unicode, 16), out)
                        except ValueError:
                            pass
                        self._unicode = None
                    continue
                if self._escape:
                    self._escape = False
                    if char == "u":
                        self._unicode = ""
                    else:
                        self._emit_char(self._ESCAPES.get(char, char), out)
                    continue
                if char == "\\":
                    self._escape = True
                    continue
                if char == '"':
                    self._in_string = False
                    if self._string_is_key:
                        self._stack[-1][2] = "".join(self._key_buffer)
                        self._stack[-1][3] = False
                    elif self._streaming:
                        self._streaming = False
                        self._done = True
                    continue
                self._emit_char(char, out)
                continue
            if char == '"':
                self._in_string = True
                top = self._stack[-1] if self._stack else None
                self._string_is_key = bool(top and top[0] == "obj" and top[3])
                self._key_buffer = []
                self._streaming = not self._string_is_key and self._at_message()
            elif char in "{[":
                top = self._stack[-1] if self._stack else None
                parent_key = top[2] if top and top[0] == "obj" else None
                self._stack.append(["obj" if char == "{" else "arr", parent_key, None, char == "{"])
            elif char in "}]":
                if self._stack:
                    self._stack.pop()
                if not self._stack:
                    self._done = True
            elif char == ",":
                if self._stack and self._stack[-1][0] == "obj":
                    self._stack[-1][3] = True
                    self._stack[-1][2] = None
        return "".join(out)


class _StructuredAnswerDeltaFilter:
    """Show plain answers as-is and only ``data.message`` of a JSON envelope."""

    def __init__(self) -> None:
        self._pending = ""
        self._mode = "undecided"
        self._envelope = _EnvelopeMessageExtractor()

    def push(self, delta: str) -> str | None:
        if not delta:
            return None
        if self._mode == "structured":
            return self._envelope.push(delta) or None
        if self._mode == "plain":
            return delta

        self._pending += delta
        candidate = self._pending.lstrip()
        if not candidate:
            return None

        structured_prefixes = ("{", "```json", "```JSON")
        if any(candidate.startswith(prefix) for prefix in structured_prefixes):
            self._mode = "structured"
            pending, self._pending = self._pending, ""
            return self._envelope.push(pending) or None
        if any(prefix.startswith(candidate) for prefix in structured_prefixes):
            return None

        self._mode = "plain"
        output = self._pending
        self._pending = ""
        return output


def _extract_stream_text_delta(event_name: str, payload: Any) -> str | None:
    if isinstance(payload, str):
        return payload if event_name.endswith("delta") else None

    if not isinstance(payload, dict):
        return None

    # Cortex Agents emits answer tokens as:
    #   event: response.text.delta
    #   data: {"content_index": 0, "text": "..."}
    # Do not treat response.thinking.delta as answer text.
    if event_name == "response.text.delta":
        text_value = payload.get("text")
        if isinstance(text_value, str) and text_value:
            return text_value

    for key in ("delta", "text_delta", "output_text"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            return value
        if isinstance(value, dict):
            nested_text = value.get("text") or value.get("value")
            if isinstance(nested_text, str) and nested_text:
                return nested_text

    content = payload.get("content")
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if not isinstance(block, dict):
                continue
            if block.get("type") in {"text_delta", "output_text_delta"}:
                text_value = block.get("text") or block.get("value")
                if isinstance(text_value, str) and text_value:
                    parts.append(text_value)
        if parts:
            return "".join(parts)

    return None


def _extract_stream_suggestions(payload: Any) -> list[str]:
    if not isinstance(payload, dict):
        return []

    suggestions = payload.get("suggestions")
    if isinstance(suggestions, list):
        return [str(item) for item in suggestions if item is not None]

    content = payload.get("content")
    if isinstance(content, list):
        items: list[str] = []
        for block in content:
            if (
                isinstance(block, dict)
                and block.get("type") == "suggestions"
                and isinstance(block.get("suggestions"), list)
            ):
                items.extend(str(item) for item in block["suggestions"] if item is not None)
        return items

    return []


def _extract_stream_status(event_name: str, payload: Any) -> str | None:
    if isinstance(payload, dict):
        for key in ("message", "status", "phase", "title"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                if event_name.endswith("delta") and key == "message":
                    continue
                return value.strip()
    return None


def _semantic_summary(payload: Any) -> str:
    if isinstance(payload, dict):
        for key in ("domain_summary", "description", "summary"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    if isinstance(payload, list) and payload:
        return f"{len(payload)} semantic attributes available"
    return "Semantic model available"
