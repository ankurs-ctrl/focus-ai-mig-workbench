# Client AVD R7: Cost Control, Context Caching, and Conversation Rollover

This is a cumulative source overlay for changes made after the
`20260722-selection-query-editor-client-avd-r6` package.

## Included

- Lossless semantic-bundle and FIR-context reuse
- Metadata and concurrent-request deduplication improvements
- Workload-aware Snowflake warehouse routing
- Workload-specific statement timeouts and query tags
- Durable logical conversations with automatic Cortex-thread rollover
- Content-addressed storage for large SQL, YAML, and agent artifacts
- Frontend conversation continuity across rollover and navigation
- Configurable web and auto-map SPCS sizing
- Resource-monitor and cost-observability SQL
- Additive metadata DDL and bootstrap support
- Focused automated tests for the new behavior

## Deliberately excluded

- The real `infra/snowflake/env/client.env`
- Dockerfiles and container images
- `.env` files containing credentials
- `.next`, caches, virtual environments, logs, screenshots, and local build output
- EverNest sample data or client-specific FIR training content
- Unrelated user worktree changes

## Deployment order

1. Back up the current client checkout.
2. Extract this ZIP at the repository root and allow these files to overwrite
   their older versions.
3. Add the variables documented in `CLIENT_ENV_DELTA.md` to the existing
   `infra/snowflake/env/client.env`. Keep existing secrets and client object
   names unchanged.
4. Run the metadata bootstrap once. This creates the conversation-segment
   metadata and secured artifact stage additively.
5. Deploy the web and STTM Builder services. Deploy the separate auto-map
   worker only if that service is enabled in the client environment.
6. Apply the resource-monitor template only after replacing its quota and
   warehouse placeholders with client-approved values.

## Verification performed

- Focused backend tests: 40 passed
- Frontend TypeScript: `npx tsc --noEmit` passed
- The package is validated for path safety and the 25 MB upload limit.

