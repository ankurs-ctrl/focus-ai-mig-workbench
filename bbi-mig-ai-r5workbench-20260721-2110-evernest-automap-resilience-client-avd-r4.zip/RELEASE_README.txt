EverNest reliability client AVD release R4
==========================================

R4 contains the complete verified R3 payload plus Auto-map transport,
SQL-compiler presentation, and confidence-explanation repairs.

Changes
-------
- Auto-map status polling now retries transient network/timeout/502/503/504
  failures against the same durable job, with bounded exponential backoff.
- Already returned partial batches remain applied while polling reconnects.
- A compile failure no longer replaces SQL Preview with an error comment.
- SQL Preview preserves live row-based SQL and displays compile problems in a
  separate actionable warning.
- Disconnected graph errors identify physical relation names and explain that
  users must add validated joins or remap targets to connected derived outputs.
- Confidence tooltips separate business fit from technical/FIR evidence,
  alternatives, and review guidance.

Important behavior
------------------
Selecting a table does not join it. Every relation referenced by a mapped
target must be reachable from the driving relation. A derived-source join only
connects the outputs declared by that derived source; it does not automatically
connect every physical table used inside or alongside it.

Verification
------------
- Mapping compiler and Auto-map backend tests: 30 passed.
- Frontend TypeScript check: passed.
- Archive integrity and per-file SHA-256 manifest are verified after packaging.

Deployment
----------
Extract over the client worktree and rebuild/redeploy the frontend and STTM
Builder services. No metadata bootstrap, FIR retraining, or agent redeployment
is required for the R4 changes.
