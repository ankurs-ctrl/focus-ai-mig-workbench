"""Read existing test registry/FIR and exercise v3 packets without publishing or DDL.

Credentials are read from --credential-env; outputs never include them. --live uses
request-scoped tool-free agent specs, leaving deployed agents unchanged. Generated
identity keys test semantic/transport fidelity, not client business mapping accuracy.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
import json
import logging
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'services/sttm-builder'))
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env', required=True, type=Path)
    parser.add_argument('--profile', type=Path, default=ROOT / 'infra/snowflake/env/local.automap-v3.env')
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--live', action='store_true')
    parser.add_argument('--max-batches', type=int)
    parser.add_argument('--models', nargs='+', default=['claude-haiku-4-5', 'claude-sonnet-4-5'])
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.ERROR)
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    import yaml
    from app.core.config import Settings
    from app.core.semantic_model import SemanticModelService
    from app.core.automap_semantic_catalog import build_catalog
    from app.core.agent_payload_budget import _is_name_echo
    from app.core.automap_retrieval import AutoMapContext
    from app.core.automap_fast_context import FastContextPlan
    from app.core.automap_policy import POLICY_VERSION
    from app.core.automap_learning_pack import AutoMapLearningPack
    from app.core.snowflake_agent import SnowflakeAgentClient
    from app.schema.common import TableRef
    from scripts.automap_message_sizes import expand_packet
    from scripts.benchmark_automap_v3 import score

    values = {**dotenv_values(args.credential_env), **dotenv_values(args.profile)}
    settings = Settings(_env_file=None, **{key: value for key, value in values.items() if value is not None})
    if settings.snowflake_account.upper() != 'A0581299278961-BBINSIGHT_PARTNER':
        raise ValueError('This fixture is restricted to the named local test account')
    if settings.resolved_semantic_native_views_table.upper() != 'FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS':
        raise ValueError('Expected the existing test semantic registry')
    started = time.monotonic()
    session = Session.builder.configs({
        'account': settings.snowflake_account, 'user': settings.snowflake_user,
        'authenticator': 'PROGRAMMATIC_ACCESS_TOKEN', 'token': settings.snowflake_password,
        'role': settings.snowflake_role, 'warehouse': settings.snowflake_warehouse,
        'database': settings.snowflake_database, 'schema': settings.snowflake_schema,
        'login_timeout': 20, 'network_timeout': 60}).create()
    try:
        service = SemanticModelService(settings)
        source_names = ['BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION',
                        'BBI_STTM_TEST_DB.DW_OPS.PORTAL_USER_HISTORY']
        crm_sources = ['SHARED_FFP_FROM_PERSONAL.SCH_REDTAIL_EVERNEST_06_23_2026.CONTACT_FAMILIES',
                       'SHARED_FFP_FROM_PERSONAL.SCH_REDTAIL_EVERNEST_06_23_2026.CONTACT_CATEGORIES']
        crm_target = 'FFP_HDP_CRM_MIG_DB_DEV.SCH_REDTAIL_EVERNEST_TARGET.EVERNEST_HH'
        refs = [TableRef(database=parts[0], schema=parts[1], table=parts[2])
                for parts in [name.split('.') for name in [*source_names, *crm_sources, crm_target]]]
        records = service.get_table_records(session, refs)
        by_fqn = {'.'.join(str(row[key]) for key in ('database', 'schema_name', 'table_name')): row for row in records}
        catalog = build_catalog(records, bundle_hash='live-read-only')
        summary = {'registry': settings.resolved_semantic_native_views_table,
                   'fir_namespace': settings.resolved_metadata_database + '.' + settings.resolved_metadata_schema,
                   'registry_tables': [{'table': name, 'columns': len([item for item in catalog if item['table_fqn'] == name]),
                       'described_columns': sum(not _is_name_echo(item['description'], item['column']) for item in catalog if item['table_fqn'] == name)}
                       for name in [*source_names, *crm_sources, crm_target]]}
        crm_columns = [item['table_fqn'] + '.' + item['column'] for item in catalog if item['table_fqn'] in crm_sources]
        packs = AutoMapLearningPack(session, settings).retrieve(
            targets=['HOUSEHOLD_TYPE__C', 'PARENTID'], target_table=crm_target,
            project_id='2701', crm='REDTAIL', source_columns=crm_columns)
        summary['stored_learning'] = {target: [{'pattern_id': item['pattern_id'], 'tier': item['tier'],
            'legacy_guidance': item.get('legacy_guidance'), 'applicable': item['applicable']} for item in pack]
            for target, pack in packs.items()}
        (args.output_dir / 'crm-learning-packs.json').write_text(json.dumps(packs, indent=2, default=str))
        packets, keys, batches, wire_sizes, description_ratios = [], {}, [], [], []
        remaining = 37
        for case_index, name in enumerate(source_names):
            if name not in by_fqn:
                raise ValueError('Selected registry fixture is unavailable')
            row = by_fqn[name]
            columns = [item for item in catalog if item['table_fqn'] == name and item['provenance'] != 'name_only'][:remaining]
            remaining -= len(columns)
            source = dict(zip(('database', 'schema', 'table'), name.split('.')))
            # A local logical target contract; no physical target object is created.
            target = {'database': 'BBI_STTM_TEST_DB', 'schema': 'DL_AMOUNT', 'table': 'V3_IDENTITY_CONTRACT_' + str(case_index)}
            for start in range(0, len(columns), 4):
                chosen = columns[start:start+4]
                attributes = [{'target_table': target, 'target_attribute': item['column'],
                               'target_data_type': item['data_type'], 'target_description': item['description']} for item in chosen]
                payload = {'request_id': 'v3-test-' + str(len(packets)), 'operation': 'sttm.auto_map',
                    'data': {'intent': 'AUTO_MAP', 'message': 'Identity semantic contract: preserve each requested field meaning from the existing source. Return v3 packet citations.', 'attributes': attributes},
                    'context': {'source_tables': [source], 'driving_table': source, 'target_table': target,
                        'semantic_context': [{'table': source, 'semantic_model': row['semantic_model']}],
                        'learning_context': {'automap_policy_version': POLICY_VERSION},
                        'workspace_context': {'driving_relation_id': 'src'},
                        'relation_graph': {'nodes': [{'relation_id': 'src', 'alias': 'src', 'kind': 'PHYSICAL_TABLE',
                            'table': source, 'output_columns': [{'name': item['column'], 'data_type': item['data_type']} for item in columns]}], 'edges': []}}}
                payload = json.loads(json.dumps(payload, default=str))
                store = AutoMapContext(payload)
                store.manifest()
                store.discover_batch(lambda targets: {t: {'diagnostics': {'status': 'no_match'}} for t in targets})
                plan = FastContextPlan(store, max_chars=150000, max_bytes=150000)
                # Real canonical reads before model projection, not invented read receipts.
                results = []
                for operation in plan.selection_operations():
                    request = {'tool': 'AUTO_MAP_CONTEXT', 'snapshot_hash': store.snapshot_hash, **operation}
                    page = store.read(request, max_bytes=150000)
                    while page.get('next_cursor'):
                        page = store.read({**request, 'cursor': page['next_cursor']}, max_bytes=150000)
                    results.append({'request': operation, 'result': store.exact_completed_result(operation)})
                messages = plan.messages(results)
                packet = expand_packet(json.loads(messages[0]['content'][0]['text']))
                packets.append(packet)
                from app.core.automap_input_budget import wire_text
                wire_sizes.append(len(wire_text(messages).encode('utf-8')))
                admitted = [plan.records[item.record_id].body for item in plan.binding_admissions()]
                from app.core.automap_semantic_catalog import catalog_entry
                descriptions = [catalog_entry(item['binding']['sql_qualifier'], item['column'], item['semantics']) for item in admitted]
                description_ratios.append(sum(not _is_name_echo(item['description'], item['column']) for item in descriptions) / max(1, len(descriptions)))
                from sqlglot import parse_one
                exact_refs = {parse_one(item.source_ref, read='snowflake').name: item.source_ref for item in plan.binding_admissions()}
                local_key = {'mappings': {item['column']: {'source_attributes': [exact_refs[item['column']]], 'mapping_mode': 'source'} for item in chosen}}
                keys[str(len(packets)-1)] = local_key
                batches.append((messages, local_key, packet))
        if args.max_batches:
            batches = batches[:args.max_batches]
        summary['prep_seconds'] = round(time.monotonic() - started, 3)
        summary['identity_target_count'] = sum(len(key['mappings']) for key in keys.values())
        summary['batch_count'] = len(batches)
        summary['packet_wire_bytes'] = wire_sizes
        summary['admitted_non_echo_description_ratios'] = description_ratios
        summary['test_scope'] = 'Registry-backed generated identity contracts; not the client accepted mapping answer key'
        (args.output_dir / 'packets.json').write_text(json.dumps(packets, ensure_ascii=False, default=str))
        (args.output_dir / 'identity-answer-keys.json').write_text(json.dumps(keys, indent=2))
        if args.live:
            # PAT REST authentication. Objectless run_config preserves every deployed agent.
            agent = SnowflakeAgentClient(token=session.connection._rest._token, host=session.connection.host.replace("_", "-"),
                                         auth_mode='snowflake_token', role=settings.snowflake_role,
                                         request_timeout=60)
            agent._retry_attempts = 1
            template = yaml.safe_load((ROOT / 'infra/snowflake/agents/agent_spec_source_mapping.yaml').read_text())
            reports = {}
            for model in args.models:
                spec = {**deepcopy(template), 'models': {'orchestration': model}, 'tools': [], 'tool_resources': {}}
                model_started = time.monotonic()
                def run(index):
                    messages, key, packet = batches[index]
                    call_started = time.monotonic()
                    try:
                        raw, _, _ = agent.run_detailed(messages, run_config=spec, request_timeout=60)
                        from app.core.automap_json import load_json
                        from app.core.sttm_builder import _extract_json_object
                        response = load_json(_extract_json_object(raw))
                        (args.output_dir / (model + '-batch-' + str(index) + '.json')).write_text(json.dumps(response, default=str))
                        response.setdefault('meta', {})['auto_map_retrieval'] = {'model_call_count': 1}
                        report = score(key, response, [packet])
                        report['elapsed_seconds'] = round(time.monotonic() - call_started, 3)
                        return index, report
                    except Exception as error:
                        detail = str(error).replace(settings.snowflake_password, '[credential]').replace(session.connection._rest._token, '[session]')
                        return index, {'error_type': type(error).__name__, 'safe_detail': detail[:500], 'elapsed_seconds': round(time.monotonic() - call_started, 3)}
                with ThreadPoolExecutor(max_workers=8) as executor:
                    outcomes = dict(future.result() for future in as_completed([executor.submit(run, i) for i in range(len(batches))]))
                reports[model] = {'wall_seconds': round(time.monotonic() - model_started, 3), 'batches': outcomes,
                    'exact_matches': sum(report.get('exact_matches', 0) for report in outcomes.values()),
                    'decisions': sum(report.get('decision_records', 0) for report in outcomes.values()),
                    'invalid_citations': sum(report.get('invalid_citations') or 0 for report in outcomes.values()),
                    'targets_without_valid_citation': sum(report.get('targets_without_valid_citation') or 0 for report in outcomes.values())}
            summary['model_reports'] = reports
        (args.output_dir / 'report.json').write_text(json.dumps(summary, indent=2, default=str))
        print(json.dumps(summary, default=str), flush=True)
    finally:
        session.close()


if __name__ == '__main__':
    main()
