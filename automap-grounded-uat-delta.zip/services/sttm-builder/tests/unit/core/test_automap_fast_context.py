"""Offline deterministic table admission and complete packet boundaries."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json
import time

import pytest

from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.automap_fast_context import FastContextPlan, request_deadline, validate_derived_output_contracts
from app.core.automap_policy import focused_learning
from app.core.automap_retrieval import AutoMapContext, encoded
from app.schema.sttm_builder import AttributeMapping
from scripts.automap_message_sizes import expand_packet
from tests.unit.core.test_automap_retrieval import payload


def fast_payload(target_count=1):
    value = payload(target_count=target_count, description_size=0)
    value["context"]["learning_context"]["correction_history"][0].update(
        incorrect_source=["a.CONTACT_NAME"], correct_source=["a.X47"], error_category="wrong_source", correction_count=1)
    value["meta"] = {"auto_map_fast_path": "v1", "auto_map_deadline_at":
                     (datetime.now(timezone.utc) + timedelta(seconds=180)).isoformat()}
    value["context"]["workspace_context"] = {"driving_relation_id": "a"}
    return value


def add_table(value, name="UNUSED", *, columns=4, size=0, connected=False):
    table = {"database": "D", "schema": "S", "table": name}
    records = [{"name": f"OTHER{index}", "data_type": "TEXT", "business_meaning": f"Other {index} " + "x" * size}
               for index in range(columns)]
    value["context"]["source_tables"].append(table)
    value["context"]["semantic_context"].append({"table": table, "semantic_model": {"attributes": records}})
    value["context"]["relation_graph"]["nodes"].append({"relation_id": name, "alias": name,
        "kind": "PHYSICAL_TABLE", "table": table, "output_columns": deepcopy(records)})
    if connected:
        value["context"]["relation_graph"]["edges"].append({"edge_id": name, "left_relation_id": "a",
            "right_relation_id": name, "join_type": "LEFT", "conditions": [
                {"left_column": "X47", "right_column": "OTHER0", "operator": "="}]})


def plan_for(value=None, *, max_chars=120_000, max_bytes=500_000):
    value = deepcopy(value or fast_payload())
    value["context"]["learning_context"] = focused_learning(value["context"].get("learning_context") or {})
    store = AutoMapContext(value)
    store.manifest()
    store.discover_batch(lambda targets: {target: {"diagnostics": {"status": "no_match"}} for target in targets})
    before = deepcopy(vars(store))
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    proofs = validate_derived_output_contracts(STTMBuilderEnvelopeRequest.model_validate(value), None)
    plan = FastContextPlan(store, max_chars=max_chars, max_bytes=max_bytes, validated_derived=proofs)
    assert vars(store) == before
    return store, plan


def unpack(messages):
    return expand_packet(json.loads(messages[0]["content"][0]["text"]))


def test_whole_groups_complete_owners_and_no_read_claims_or_canonical_mutation():
    value = fast_payload()
    add_table(value, columns=800, size=400)
    saved = deepcopy(value)
    store, plan = plan_for(value)
    reads = deepcopy(store.reads)
    messages = plan.messages([])
    packet = unpack(messages)
    assert len(encoded(messages)) < 50_000
    assert value == saved and store.reads == reads
    assert len(store.inventory["D.S.UNUSED"]) == 800
    assert packet["retrieved_auto_map_context"] == []
    cards = packet["context"]["table_records"]
    ids = {card["record_id"] for card in cards + packet["context"]["global_records"]}
    assert all(card["body"]["owner_ref"] in ids for card in cards if "owner_ref" in card["body"])
    assert {card["record_id"] for card in cards} == {identity for group in plan.selected for identity in plan.groups[group]}
    assert len([group for group in plan.omitted if group.startswith("table:D.S.UNUSED:page:")]) > 1
    assert plan.warnings[0]["field"] == "D.S.UNUSED"
    assert "Never use CONTACT_NAME" in encoded(packet)


def test_physical_source_pages_continue_without_claiming_exhaustive_absence():
    value = fast_payload()
    value["context"]["learning_context"] = {}
    add_table(value, name="WIDE", columns=600, size=10, connected=True)
    store, plan = plan_for(value)
    before = deepcopy(vars(store))
    unread = [group for group in plan.rankings["NAME0"] if group not in plan.selected]
    assert unread
    pages, reads = plan.advance_pages(["NAME0"], [])
    assert pages and reads
    assert pages[0] not in plan.omitted
    assert plan.next_pages["NAME0"] != pages[0]
    assert plan.messages([])
    assert unpack(plan.messages([]))["context"]["auto_map_retrieval"]["coverage"]["exhaustive"] is False
    assert vars(store) == before


def test_stable_shortlist_not_affected_by_inventory_order():
    value = fast_payload()
    add_table(value)
    _, first = plan_for(value)
    value["context"]["semantic_context"].reverse()
    value["context"]["relation_graph"]["nodes"].reverse()
    _, second = plan_for(value)
    assert first.selected == second.selected and first.target_groups == second.target_groups


def test_structural_join_dependency_admits_whole_support_table():
    value = fast_payload()
    add_table(value, connected=True)
    _, plan = plan_for(value)
    assert any(group.startswith("table:D.S.UNUSED") for group in plan.selected)
    packet = unpack(plan.messages([]))
    cards = [card for card in packet["context"]["table_records"] if card["kind"] == "source_column"]
    assert {card["body"]["name"] for card in cards} >= {"OTHER0", "OTHER1", "OTHER2", "OTHER3"}


def test_validated_cte_output_does_not_pull_parent_catalog_and_full_sql_is_archived():
    value = fast_payload()
    add_table(value)
    node = value["context"]["relation_graph"]["nodes"][0]
    node.update(kind="DERIVED_SOURCE", sql_text="SELECT OTHER0 AS X47 FROM D.S.UNUSED",
                parent_relation_ids=["UNUSED"])
    _, plan = plan_for(value)
    assert not any(group.startswith("table:D.S.UNUSED") for group in plan.selected)
    assert node["sql_text"] in encoded(plan.store.original)
    assert {"operation": "dependency", "relation_id": "a"} in plan.read_operations


def test_unproved_derived_output_is_never_selectable():
    value = fast_payload()
    value["context"]["relation_graph"]["nodes"][0].update(kind="DERIVED_SOURCE", sql_text="SELECT X47 FROM D.S.A")
    store = AutoMapContext(value)
    store.manifest()
    store.discover_batch(lambda targets: {target: {"diagnostics": {"status": "no_match"}} for target in targets})
    with pytest.raises(ValueError, match="require current server validation"):
        FastContextPlan(store, max_chars=120_000, max_bytes=120_000, validated_derived={})


def test_missing_parent_fails_closed():
    value = fast_payload()
    value["context"]["relation_graph"]["nodes"][0]["parent_relation_ids"] = ["MISSING"]
    with pytest.raises(ValueError, match="parent"):
        plan_for(value)


@pytest.mark.parametrize("kind", ["source", "global"])
def test_oversized_whole_group_or_globals_never_clipped(kind):
    value = fast_payload()
    if kind == "source":
        value["context"]["semantic_context"][0]["semantic_model"]["semantic_notes"] = "Business rule " * 15_000
    else:
        value["data"]["message"] = "Required global rule " * 12_000
    store, plan = plan_for(value)
    with pytest.raises(AgentPayloadBudgetError):
        plan.messages([])
    assert "table:D.S.A" in plan.selected
    assert not store.reads - {("discover", "NAME0")}


def test_utf8_complete_message_byte_budget_enforced():
    value = fast_payload()
    value["data"]["message"] = "\u754c" * 5000
    _, plan = plan_for(value, max_bytes=22_000)
    with pytest.raises(AgentPayloadBudgetError):
        plan.messages([])


@pytest.mark.parametrize("source", ["UNUSED.OTHER0", "T.NAME0", "X47", "a.MISSING", "a.X47; SELECT 1", '"A".X47'])
def test_strict_candidate_namespace_rejects_unadmitted_or_ambiguous_sources(source):
    value = fast_payload()
    add_table(value)
    _, plan = plan_for(value)
    if source == '"A".X47':
        # Unquoted a folds to A, so this exact quoted uppercase alias is valid.
        plan.validate_candidate(AttributeMapping(source_attributes=[source], confidence_score=0.8))
    else:
        with pytest.raises(ValueError):
            plan.validate_candidate(AttributeMapping(source_attributes=[source], confidence_score=0.8))


@pytest.mark.parametrize("expression", ["UPPER(UNUSED.OTHER0)", "UPPER(a.X47); SELECT 1", "(SELECT a.X47)", "UPPER(X47)", "COUNT(*)"])
def test_full_expression_references_and_statements_are_checked(expression):
    _, plan = plan_for()
    candidate = AttributeMapping(source_attributes=["a.X47"], preprocessing_rule=expression,
                                 preprocessing_rule_type="SQL", confidence_score=0.8)
    with pytest.raises(ValueError):
        plan.validate_candidate(candidate)


def test_reading_single_omitted_column_cannot_break_whole_table_contract():
    value = fast_payload()
    add_table(value)
    _, plan = plan_for(value)
    with pytest.raises(ValueError, match="whole table"):
        plan.validate_operations([{"operation": "column", "relation": "UNUSED", "column": "OTHER0"}])


def test_missing_driver_and_target_only_are_not_eligible():
    value = fast_payload()
    value["context"]["workspace_context"] = {}
    with pytest.raises(ValueError, match="eligible"):
        plan_for(value)


@pytest.mark.parametrize("deadline", [None, "not-time", "2026-01-01T00:00:00", "2026-01-01T00:00:00+01:00", 123])
def test_deadline_requires_explicit_absolute_utc(deadline):
    with pytest.raises(ValueError):
        request_deadline({"auto_map_deadline_at": deadline})


def test_deadline_uses_accepted_absolute_cutoff_and_expiry_is_not_reset():
    start = time.monotonic()
    later = datetime.now(timezone.utc) + timedelta(days=1)
    assert 86_390 < request_deadline({"auto_map_deadline_at": later.isoformat()}, started=start) - start < 86_410
    past = datetime.now(timezone.utc) - timedelta(seconds=1)
    assert request_deadline({"auto_map_deadline_at": past.isoformat()}) < time.monotonic()


def test_all_columns_travel_with_lexically_chosen_table():
    value = fast_payload()
    value["context"]["relation_graph"]["nodes"][0]["output_columns"].extend(
        {"name": f"UNRANKED{index}", "data_type": "TEXT"} for index in range(30))
    _, plan = plan_for(value)
    cards = unpack(plan.messages([]))["context"]["table_records"]
    assert len([card for card in cards if card["kind"] == "source_column"]) == 31


def test_self_join_and_quoted_names_preserve_exact_binding_identity():
    value = fast_payload()
    node = value["context"]["relation_graph"]["nodes"][0]
    node["alias"] = '"ExactAlias"'
    node["output_columns"].append({"name": "Mixed.Column", "data_type": "TEXT"})
    other = deepcopy(node)
    other.update(relation_id="b", alias="b")
    value["context"]["relation_graph"]["nodes"].append(other)
    value["context"]["relation_graph"]["edges"].append({"edge_id": "self", "left_relation_id": "a",
        "right_relation_id": "b", "conditions": [{"left_column": "X47", "right_column": "X47"}]})
    _, plan = plan_for(value)
    plan.validate_candidate(AttributeMapping(source_attributes=['"ExactAlias"."Mixed.Column"'], confidence_score=0.8))
    plan.validate_candidate(AttributeMapping(source_attributes=['b."Mixed.Column"'], confidence_score=0.8))
    with pytest.raises(ValueError):
        plan.validate_candidate(AttributeMapping(source_attributes=['exactalias."Mixed.Column"'], confidence_score=0.8))


def test_duplicate_aliases_and_non_output_semantics_are_not_sources():
    value = fast_payload()
    value["context"]["semantic_context"][0]["semantic_model"]["attributes"].append(
        {"name": "PRIVATE", "business_meaning": "NAME0"})
    _, plan = plan_for(value)
    with pytest.raises(ValueError):
        plan.validate_candidate(AttributeMapping(source_attributes=["a.PRIVATE"], confidence_score=0.8))
    node = deepcopy(value["context"]["relation_graph"]["nodes"][0])
    node["relation_id"] = "second"
    value["context"]["relation_graph"]["nodes"].append(node)
    with pytest.raises(ValueError, match="eligible"):
        plan_for(value)


@pytest.mark.parametrize("change", ["evidence", "inventory", "original"])
def test_packet_freezes_authoritative_context_not_read_ledger(change):
    store, plan = plan_for()
    if change == "evidence":
        store.evidence["NAME0"]["new"] = [{"rule": "new"}]
    elif change == "inventory":
        store.inventory["D.S.A"]["NEW"] = "TEXT"
    else:
        store.original["data"]["message"] = "changed"
    with pytest.raises(ValueError, match="Canonical"):
        plan.messages([])


@pytest.fixture(scope="module")
def available_ft_pitt_request():
    from tests.unit.core.test_automap_deterministic import real_ft_pitt_request, real_ft_pitt_upload
    return real_ft_pitt_request(real_ft_pitt_upload.__wrapped__()).model_dump(mode="json", exclude_none=True)


def test_real_ft_pitt_available_fixture_message_measurements(available_ft_pitt_request, monkeypatch):
    import app.core.automap_fast_context as context_module

    store, plan = plan_for(available_ft_pitt_request)
    messages = plan.messages([])
    packet = unpack(messages)
    legacy_messages = context_module.batch_messages(legacy_fast_factoring(packet))
    globals_only = deepcopy(packet)
    globals_only["context"]["table_records"] = []
    group_sizes = []
    for group in sorted(plan.selected):
        sample = deepcopy(globals_only)
        sample["context"]["table_records"] = [plan.records[identity]._payload() for identity in plan.groups[group]]
        group_sizes.append({"group": group, "records": len(plan.groups[group]),
            "columns": sum(plan.records[identity].kind.endswith("column") for identity in plan.groups[group]),
            "globals_plus_whole_group_chars": len(encoded(context_module.batch_messages(
                context_module.factor_fast_packet(sample))))})
    counts = {relation: len(columns) for relation, columns in store.inventory.items()}
    print("FTPITT_AVAILABLE_FIXTURE:", json.dumps({
        "source": "checked-in SQL plus explicit limited offline catalog; NOT mapping 2702 export",
        "inventory_columns": counts, "targets": len(store.targets),
        "admitted_groups": len(plan.selected), "complete_message_chars": len(encoded(messages)),
        "legacy_complete_message_chars": len(encoded(legacy_messages)),
        "global_record_chars": len(encoded(packet["context"]["global_records"])),
        "table_record_chars": len(encoded(packet["context"]["table_records"])),
        "attribution_only_not_executable": {"groups": group_sizes,
            "globals_only_chars": len(encoded(context_module.batch_messages(context_module.factor_fast_packet(globals_only)))),
            "legacy_globals_only_chars": len(encoded(context_module.batch_messages(legacy_fast_factoring(globals_only))))},
    }, sort_keys=True))
    assert len(store.targets) == 35
    assert next(count for relation, count in counts.items() if relation.endswith(".ACCOUNTS")) == 24
    assert len([group for group in plan.groups if group.startswith("table:")]) >= 11
    assert {record["record_id"] for record in packet["context"]["global_records"]} == {
        record.record_id for record in plan.prepared.global_records if record.kind != "workspace_graph"}
    assert len(encoded(messages)) < len(encoded(legacy_messages))
    assert {record["record_id"] for record in packet["context"]["table_records"]} == {
        identity for group in plan.selected for identity in plan.groups[group]}
    monkeypatch.setattr(context_module, "factor_fast_packet", lambda packet, **kwargs: deepcopy(packet))
    assert json.loads(plan._render([])[0]["content"][0]["text"]) == packet


def test_uploaded_cte_graph_is_bound_to_current_sql_and_stale_output_fails(available_ft_pitt_request):
    from app.core.automap_fast_context import hydrate_authored_cte_graph
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    req = STTMBuilderEnvelopeRequest.model_validate(available_ft_pitt_request)
    req.context.relation_graph.nodes[6].sql_text = "SELECT * FROM JimsHH"
    req.context.relation_graph.nodes[6].dependency_hash = None
    original = req.context.relation_graph.nodes[6]
    hydrated = hydrate_authored_cte_graph(req)
    node = hydrated.context.relation_graph.nodes[6]
    assert original.sql_text == "SELECT * FROM JimsHH"
    assert "ACCOUNTS" in node.sql_text and "FROM JimsHH" not in node.sql_text
    assert node.dependency_hash
    assert req.context.relation_graph.nodes[6].sql_text == original.sql_text
    assert hydrate_authored_cte_graph(hydrated) is hydrated
    stale_sql = hydrated.model_copy(deep=True)
    stale_sql.context.workspace_context.mapping_sql += " "
    stale_sql.context.workspace_context.raw_mapping_sql += " "
    with pytest.raises(ValueError, match="dependency hash is stale"):
        hydrate_authored_cte_graph(stale_sql)
    changed = req.model_copy(deep=True)
    changed.context.relation_graph.nodes[6].output_columns.append({"name": "HIDDEN_PARENT_COLUMN"})
    with pytest.raises(ValueError, match="outputs differ"):
        hydrate_authored_cte_graph(changed)


def completed_plan_reads(store, plan):
    results = []
    for operation in plan.read_operations:
        query = {"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash, **operation}
        while True:
            result = store.read(query, max_bytes=32768)
            if not result.get("next_cursor"):
                break
            query = {**query, "cursor": result["next_cursor"]}
        results.append({"read_key": encoded(operation), "request": deepcopy(operation),
                        "result": store.exact_completed_result(operation)})
    return results


@pytest.mark.parametrize("target_count", [1, 35])
def test_available_ft_pitt_complete_exact_reads_roundtrip(available_ft_pitt_request, monkeypatch, target_count):
    import app.core.automap_fast_context as context_module
    value = deepcopy(available_ft_pitt_request)
    # The upload-only resolver fixture has no target semantic catalog. Bind the
    # supplied target requirements explicitly; these are NOT a real catalog export.
    value["context"]["target_table"] = value["data"]["attributes"][0]["target_table"]
    value["context"]["semantic_context"] = [{"table": value["context"]["target_table"],
        "semantic_model": {"attributes": [{"name": attribute["target_attribute"],
            "data_type": attribute["target_data_type"]} for attribute in value["data"]["attributes"]]}}]
    value["data"]["attributes"] = value["data"]["attributes"][:target_count]
    store, plan = plan_for(value)
    frozen = plan.state_hash
    results = completed_plan_reads(store, plan)
    messages = plan._render(results)
    packet = unpack(messages)
    print("FTPITT_AVAILABLE_EXACT_READS:", json.dumps({"targets": target_count,
        "complete_message_chars": len(encoded(messages)), "exact_reads": len(results),
        "legacy_complete_message_chars": len(encoded(context_module.batch_messages(legacy_fast_factoring(packet)))),
        "complete_table_groups": len(plan.selected), "actual_600_column_catalog": False}))
    assert plan._state_hash() == frozen
    assert packet["retrieved_auto_map_context"] == [
        {key: value for key, value in result.items() if key != "read_key"} for result in results]
    if plan._fits(messages):
        assert plan.messages(results) == messages
    else:
        with pytest.raises(context_module.FastContextBudgetError):
            plan.messages(results)
    monkeypatch.setattr(context_module, "factor_fast_packet", lambda packet, **kwargs: deepcopy(packet))
    assert json.loads(plan._render(results)[0]["content"][0]["text"]) == packet


def optional_ranked_table(value, *, size=200_000):
    # This fixture isolates lexical paging; the base fixture's correction
    # positively ranks a.X47 ahead of the optional table.
    value["context"]["learning_context"] = {}
    add_table(value, name="NAME0", columns=4, size=size)
    # Connected, but not a required join-column or population dependency.
    value["context"]["relation_graph"]["edges"].append({
        "edge_id": "optional", "left_relation_id": "a", "right_relation_id": "NAME0",
        "join_type": "INNER", "conditions": [], "additional_predicate": "1 = 1"})
    for attribute in value["context"]["semantic_context"][-1]["semantic_model"]["attributes"]:
        attribute["business_meaning"] = "NAME0 " + attribute["business_meaning"]
    return value


def test_oversized_optional_lexical_winner_is_omitted_whole_without_failing_batch():
    value = optional_ranked_table(fast_payload())
    store, plan = plan_for(value)
    packet = unpack(plan.messages([]))
    assert plan.target_groups["NAME0"] == ("table:D.S.A",)
    assert any(group.startswith("table:D.S.NAME0") for group in plan.omitted)
    assert not any(group.startswith("table:D.S.NAME0") for group in plan.selected)
    assert any(warning["code"] == "auto_map_fast_optional_table_budget_exceeded" for warning in plan.warnings)
    assert all(card["body"].get("relation") != "D.S.NAME0" for card in packet["context"]["table_records"])
    assert len(store.inventory["D.S.NAME0"]) == 4
    assert packet["context"]["auto_map_retrieval"]["coverage"]["exhaustive"] is False
    plan.validate_candidate(AttributeMapping(source_attributes=["a.X47"], confidence_score=0.8))
    with pytest.raises(ValueError):
        plan.validate_candidate(AttributeMapping(source_attributes=["NAME0.OTHER0"], confidence_score=0.8))


def test_required_driver_overflow_has_structured_target_partition_without_reads():
    value = fast_payload(2)
    value["context"]["semantic_context"][0]["semantic_model"]["semantic_notes"] = "Business rule " * 15_000
    store, plan = plan_for(value)
    reads = deepcopy(store.reads)
    with pytest.raises(AgentPayloadBudgetError) as captured:
        plan.messages([])
    error = captured.value
    assert error.target_ids == ("NAME0", "NAME1")
    assert error.diagnostics["code"] == "auto_map_fast_mandatory_context_oversized"
    assert error.diagnostics["model_calls"] == 0
    assert error.diagnostics["complete_message_chars"] > 120_000
    assert error.diagnostics["max_chars"] == 120_000
    assert "table:D.S.A" in error.diagnostics["required_groups"]
    assert error.__cause__.char_count == error.diagnostics["complete_message_chars"]
    assert store.reads == reads


def test_budget_diagnostic_handoff_is_size_only():
    from tests.test_automap_fast_job import proxy
    value = fast_payload()
    value["data"]["message"] = "private mandatory evidence " * 20_000
    _, plan = plan_for(value)
    with pytest.raises(AgentPayloadBudgetError) as captured:
        plan.messages([])
    diagnostic = proxy()._preflight_budget_diagnostic(captured.value)
    assert diagnostic["measured_chars"] == captured.value.diagnostics["complete_message_chars"]
    assert diagnostic["measured_bytes"] == captured.value.diagnostics["complete_message_bytes"]
    assert diagnostic["model_call_count"] == 0
    assert "private mandatory evidence" not in encoded(diagnostic)


def legacy_fast_factoring(packet):
    from app.core.agent_payload_budget import _factor_repeated_context_values
    from app.core.automap_retrieval import factor_exact_records, factor_exact_object_shapes, factor_exact_text_lines
    old = factor_exact_records(deepcopy(packet))
    _factor_repeated_context_values(old)
    return factor_exact_object_shapes(factor_exact_text_lines(old))


def test_exact_factoring_handles_repeated_short_owner_bindings_without_overhead():
    import app.core.automap_fast_context as context_module

    binding = {"relation_id": "ACCOUNTS", "sql_qualifier": "a", "outer_mapping_source": True,
               "unique_qualifier": True}
    packet = {"columns": [{"name": f"COLUMN_{index}", "binding": deepcopy(binding),
                           "owner_ref": "owner" * 13, "nullable": None} for index in range(600)]}
    saved = deepcopy(packet)
    old = legacy_fast_factoring(packet)
    result = context_module.factor_fast_packet(packet)
    assert expand_packet(result) == saved == packet
    assert len(encoded(result)) < len(encoded(old)) * 0.90


def test_optional_parent_closure_rolls_back_as_whole_groups():
    value = optional_ranked_table(fast_payload(), size=0)
    add_table(value, name="LARGE_PARENT", size=200_000)
    value["context"]["relation_graph"]["nodes"][1].update(
        kind="DERIVED_SOURCE", sql_text="SELECT * FROM D.S.LARGE_PARENT",
        parent_relation_ids=["LARGE_PARENT"])
    _, plan = plan_for(value)
    plan.messages([])
    assert any(group.startswith("table:D.S.NAME0") for group in plan.selected)
    assert any(group.startswith("table:D.S.LARGE_PARENT") for group in plan.omitted)
    assert plan.target_groups["NAME0"] == ("table:D.S.NAME0",)
    assert "LARGE_PARENT" not in {operation.get("relation_id") for operation in plan.read_operations}


def test_oversized_join_dependency_cannot_be_demoted_to_optional():
    value = optional_ranked_table(fast_payload())
    value["context"]["relation_graph"]["edges"][-1]["conditions"] = [
        {"left_column": "X47", "right_column": "OTHER0", "operator": "="}]
    _, plan = plan_for(value)
    assert "table:D.S.NAME0:owner" in plan.required_groups
    assert any(group.startswith("table:D.S.NAME0:page:") for group in plan.omitted)
    assert plan.messages([])


def test_optional_whole_table_admission_enforces_utf8_bytes():
    value = optional_ranked_table(fast_payload(), size=0)
    value["context"]["semantic_context"][-1]["semantic_model"]["semantic_notes"] = "\u754c" * 30_000
    _, char_plan = plan_for(value)
    assert any(group.startswith("table:D.S.NAME0") for group in char_plan.selected)
    _, byte_plan = plan_for(value, max_bytes=60_000)
    assert any(group.startswith("table:D.S.NAME0") for group in byte_plan.omitted)
    assert len(encoded(byte_plan.messages([])).encode("utf-8")) <= 60_000


def test_optional_admission_worker_reads_and_singleton_preflight_isolation():
    from tests.unit.core.test_automap_fast_batch import invoke
    from app.core.automap_fast_context import FastContextBudgetError

    value = optional_ranked_table(fast_payload())
    builder, _, (raw, _, _) = invoke(value)
    assert len(builder._agent.calls) == 1
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]
    assert any(group.startswith("table:D.S.NAME0") for group in
               unpack(builder._agent.calls[0][0])["context"]["auto_map_retrieval"]["coverage"]["unscanned_groups"])

    value = fast_payload(2)
    value["data"]["attributes"][1]["target_description"] = "Required rule " * 15_000
    _, combined = plan_for(value)
    with pytest.raises(FastContextBudgetError):
        combined.messages([])
    for attribute in value["data"]["attributes"]:
        single = deepcopy(value)
        single["data"]["attributes"] = [attribute]
        _, plan = plan_for(single)
        if attribute["target_attribute"] == "NAME0":
            plan.messages([])
        else:
            with pytest.raises(FastContextBudgetError) as captured:
                plan.messages([])
            assert captured.value.target_ids == ("NAME1",)


@pytest.mark.parametrize("reserved", ["$exact_record", "exact_record_dictionary", "exact_record_encoding"])
def test_small_record_factor_leaves_reserved_user_data_untouched(reserved):
    from app.core.automap_fast_context import _factor_small_exact_records
    value = {reserved: "ordinary input", "repeated": [{"rule": "a" * 100}] * 10}
    saved = deepcopy(value)
    assert _factor_small_exact_records(value) == saved == value


def test_nested_dictionaries_expand_exactly_without_single_use_child_ids():
    from app.core.automap_fast_context import _factor_small_exact_records, factor_fast_packet
    child = {"complete_rule": "a" * 128, "null": None, "boolean": False, "numeric": 0}
    parent = {"nested": child, "sql": 'one\r\n"two"\\three\t\u754c' * 40}
    value = {"repeated": [deepcopy(parent) for _ in range(40)], "different": {**child, "boolean": True}}
    saved = deepcopy(value)
    intermediate = _factor_small_exact_records(value)
    assert len(intermediate["exact_record_dictionary"]) == 1
    assert expand_packet(intermediate) == saved
    assert expand_packet(factor_fast_packet(value)) == saved == value


@pytest.mark.parametrize("max_chars,max_bytes", [(120_000, 500_000), (120_146, 120_274), (119_999, 120_000)])
def test_factoring_selects_candidate_fitting_both_complete_message_limits(max_chars, max_bytes):
    from app.core.automap_fast_context import factor_fast_packet
    from app.core.automap_retrieval import batch_messages
    from app.core.assistant_retrieval import budget_messages
    packet = {"columns": [{"v": "\u754c" * 64}] * 3, "instructions": ""}
    packet["instructions"] = "x" * (120_000 - len(encoded(batch_messages(packet))))
    saved = deepcopy(packet)
    raw_text = encoded(batch_messages(packet))
    unconstrained = encoded(batch_messages(factor_fast_packet(packet)))
    assert (len(raw_text), len(raw_text.encode("utf-8"))) == (120_000, 120_384)
    assert len(unconstrained) > len(raw_text)
    assert len(unconstrained.encode("utf-8")) < len(raw_text.encode("utf-8"))
    selected = factor_fast_packet(packet, max_chars=max_chars, max_bytes=max_bytes)
    assert expand_packet(selected) == saved == packet
    if max_chars == 119_999:
        with pytest.raises(AgentPayloadBudgetError):
            budget_messages(batch_messages(selected), max_chars=max_chars, max_bytes=max_bytes)
    else:
        budget_messages(batch_messages(selected), max_chars=max_chars, max_bytes=max_bytes)
        text = encoded(batch_messages(selected))
        assert len(text) <= max_chars and len(text.encode("utf-8")) <= max_bytes


@pytest.mark.parametrize("expire_on", [1, 2])
def test_context_checks_deadline_after_required_and_optional_render_without_mutation(monkeypatch, expire_on):
    from app.core import automap_fast_context as context_module
    value = optional_ranked_table(fast_payload(), size=0)
    value["context"]["learning_context"] = focused_learning(value["context"]["learning_context"])
    store = AutoMapContext(value)
    store.manifest()
    before = deepcopy(vars(store))
    clock, calls = [100.0], []
    monkeypatch.setattr(context_module.time, "monotonic", lambda: clock[0])
    original = context_module.factor_fast_packet
    def factor(packet, **kwargs):
        calls.append(packet)
        assert clock[0] < 101
        result = original(packet, **kwargs)
        if len(calls) == expire_on:
            clock[0] = 102.0
        return result
    monkeypatch.setattr(context_module, "factor_fast_packet", factor)
    with pytest.raises(context_module.FastContextDeadlineError):
        FastContextPlan(store, max_chars=120_000, max_bytes=500_000, deadline=101.0)
    assert len(calls) == expire_on
    assert vars(store) == before


def test_context_converts_absolute_deadline_once_and_reuses_monotonic_cutoff(monkeypatch):
    from app.core import automap_fast_context as context_module
    value = fast_payload()
    store = AutoMapContext(value)
    store.manifest()
    before = deepcopy(vars(store))
    clock, conversions = [100.0], []
    utc_now = datetime(2026, 10, 30, tzinfo=timezone.utc)
    store.original["meta"]["auto_map_deadline_at"] = (utc_now + timedelta(seconds=3)).isoformat()
    before = deepcopy(vars(store))
    class ClockDateTime(datetime):
        @classmethod
        def now(cls, tz=None):
            conversions.append(tz)
            return utc_now
    monkeypatch.setattr(context_module, "datetime", ClockDateTime)
    monkeypatch.setattr(context_module.time, "monotonic", lambda: clock[0])
    plan = FastContextPlan(store, max_chars=120_000, max_bytes=500_000)
    assert plan.deadline == 103.0
    clock[0] = 102
    plan.messages([])
    clock[0] = 104
    with pytest.raises(context_module.FastContextDeadlineError):
        plan.messages([])
    assert len(conversions) == 1
    assert vars(store) == before
