"""Native page prepare/job/worker acceptance; never seed execution context.

Invoked by validate_automap_durable_live --prepared-job-path, using that runner's
isolated native admission/agents. Existing business tables remain read-only.
"""
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime, UTC
import json
import time
from uuid import uuid4


def read_saved_job(session, independent, namespace, job_id):
    """Retry only a read-only verification fetch after truncated transport.

    No acceptance/model operation is retried. Use a fresh same-caller connection
    for this optional post-completion read if the original connection broke.
    """
    from app.core.automap_storage_sql import collect_storage_sql
    from snowflake.connector.vendored.requests.exceptions import ChunkedEncodingError, ConnectionError
    sql=f'SELECT JOB_STATE FROM {namespace}.TBL_AUTO_MAP_JOBS WHERE JOB_ID = ?'
    try:
        return collect_storage_sql(session,sql,[job_id])[0]['JOB_STATE']
    except (ChunkedEncodingError,ConnectionError):
        with independent() as fresh:
            return collect_storage_sql(fresh,sql,[job_id])[0]['JOB_STATE']


def run(*, settings, session, independent, payload, agent, caller, report, namespace, control_factory=None):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from app import api
    from app.api import deps
    from app.auth.models import CurrentPrincipal, PermissionSet
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.prepared_context import PreparedWorkspaceContextService, invalidate_prepared_workspace_context_cache
    from app.core.semantic_context import SemanticContextService
    from app.core.semantic_model import SemanticModelService
    from app.core.learning_retrieval import LearningRetrievalService
    from app.core.table_selection import TableSelectionService
    from app.core.derived_source import DerivedSourceService
    from app.core.sttm_builder import STTMBuilderService
    from app.routers import sttm_builder
    from app.auto_mapping_worker import main as worker_main
    worker_app=worker_main.app
    from types import SimpleNamespace
    # Install empty operational tables using existing DDL shapes, never copy data.
    existing=session.sql('SHOW TABLES IN SCHEMA FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA').collect()
    statements=[]
    for row in existing:
        name=row['name']
        if name.startswith('TBL_'):
            statements.append(f'CREATE TABLE IF NOT EXISTS {namespace}.{name} LIKE FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA.{name};')
    # Keep fixture-only DDL setup bounded by the existing statement timeout.
    for start in range(0,len(statements),8):
        session.sql('BEGIN '+' '.join(statements[start:start+8])+' END').collect()
    # Match the existing production bootstrap: large response artifacts use
    # this stage instead of exercising missing-stage fallback on every batch.
    session.sql(f'CREATE STAGE IF NOT EXISTS {namespace}.AI_WORKBENCH_ARTIFACTS').collect()
    settings=settings.model_copy(update={'auto_map_pipeline_v2':True, 'auto_mapping_service_url':'inprocess',
        'auth_mode':'ingress_headers','prepared_context_cache_v2':True,
        'auto_mapping_proxy_batch_size':8})
    print(json.dumps({'stage':'isolated_metadata_tables_ready','tables':len(statements)}),flush=True)
    from app.core.conversation_memory import ConversationMemoryService
    bootstrap_started=time.monotonic()
    ConversationMemoryService(session,settings).ensure_storage_exists()
    report['isolated_runtime_bootstrap_seconds']=round(time.monotonic()-bootstrap_started,2)
    incident = bool(report.get('incident_fixture'))
    if incident:
        # Sanitized published metadata only, inside this disposable namespace.
        from app.core.semantic_model import _merge_row
        settings=settings.model_copy(update={'snowflake_semantic_model_table':namespace+'.TBL_SEMANTIC_MODELS'})
        for item in payload['context']['semantic_context']:
            table=item['table']
            _merge_row(session,namespace+'.TBL_SEMANTIC_MODELS','TABLE',table['database'],table['schema'],table['table'],'',item['semantic_model'],'isolated-published-fixture')
        session.sql(f"INSERT INTO {namespace}.TBL_PROJECT_ATTRIBUTES (ATTRIBUTE_ID,PROJECT_ID,ATTRIBUTE_NAME,ATTRIBUTE_TYPE,ATTRIBUTE_VALUE,STATUS) SELECT 'firm-prefix','1','FirmPrefix','VARCHAR','TEST-','ACTIVE' WHERE NOT EXISTS (SELECT 1 FROM {namespace}.TBL_PROJECT_ATTRIBUTES WHERE ATTRIBUTE_ID='firm-prefix')").collect()
    principal=CurrentPrincipal(user_id=1,snowflake_user=caller.native_user,email='isolated-acceptance@example.test',
        display_name='Isolated acceptance',app_persona='ADMIN',permissions=PermissionSet(can_edit=True,can_publish=True),
        snowflake_user_token='',snowflake_role=caller.role)
    scope='|'.join([str(principal.user_id),principal.app_persona.value,caller.role])
    def semantic(s):
        return SemanticContextService(session=s,settings=settings,semantic_model_service=SemanticModelService(settings),
            table_selection_service=TableSelectionService(SimpleNamespace(session=s),settings,scope),
            derived_source_service=DerivedSourceService(s,settings),access_scope=scope)
    def prepared_dependency():
        with independent() as s:
            yield PreparedWorkspaceContextService(session=s,settings=settings,semantic_service=semantic(s),
                learning_service=LearningRetrievalService(s,settings,scope),access_scope=scope)
    def client_dependency():
        with independent() as s:yield SimpleNamespace(session=s)
    worker_records=[]
    report['worker_endpoint_calls']=worker_records
    def worker_dependency():
        with independent() as s:
            svc=STTMBuilderService(agent,analyst_client=None,settings=settings,session=s,
                semantic_model_service=SemanticModelService(settings),semantic_context_service=semantic(s),
                access_scope=scope,parallel_caller=caller,parallel_session_factory=control_factory or independent)
            original=svc.invoke_auto_map_parallel
            async def observe(req, **kwargs):
                assert req.context.execution_context is not None
                assert req.meta.get('_automap_call_tracking') == 'operation_v3'
                row={'batch':req.meta.get('auto_mapping_batch_index'),'received_at':datetime.now(UTC).isoformat(),
                    'targets':[a.target_attribute for a in req.data.attributes],
                    'snapshot_present':bool(req.context.execution_context.snapshot_id),
                    'call_tracking':req.meta['_automap_call_tracking'],
                    'preparation_hash':req.context.prepared_context_hash}
                worker_records.append(row)
                result=await original(req,**kwargs)
                row['finished_at']=datetime.now(UTC).isoformat()
                row['retrieval']=result.meta.get('auto_map_retrieval',{})
                row['transformation']=result.meta.get('transformation_stage',{})
                row['model_trace']=result.meta.get('fast_diagnostics')
                row['worker_packet_hydration_ms']=result.meta.get('worker_packet_hydration_ms')
                return result
            svc.invoke_auto_map_parallel=observe
            yield svc
    app=FastAPI()
    @app.middleware('http')
    async def authenticated(request,call_next):
        request.state.current_principal=principal
        request.state.workbench_timings_ms={}
        return await call_next(request)
    app.include_router(api.router)
    proxy=AutoMappingProxyClient(settings)
    original_persist=AutoMappingProxyClient._persist_job
    def observed_persist(self,record,**kwargs):
        started=time.monotonic()
        try:return original_persist(self,record,**kwargs)
        finally:
            report.setdefault('job_persistence',[]).append({'job_id':record.get('job_id'),
                'stage':record.get('stage'),'elapsed_ms':round((time.monotonic()-started)*1000,2)})
    AutoMappingProxyClient._persist_job=observed_persist
    app.dependency_overrides[deps.get_auto_mapping_proxy_client]=lambda:proxy
    app.dependency_overrides[deps.get_prepared_workspace_context_service]=prepared_dependency
    app.dependency_overrides[deps.get_snowflake_client]=client_dependency
    app.dependency_overrides[deps.get_settings]=lambda:settings
    worker_app.dependency_overrides[deps.get_sttm_builder_service]=worker_dependency
    previous=sttm_builder.get_settings
    sttm_builder.get_settings=lambda:settings
    body=json.loads(json.dumps(payload, default=str))
    body['context']['execution_context']=None
    for key in ['prepared_context_hash','workspace_context_id','workspace_context_hash']:
        body['context'].pop(key,None)
    workspace=body['context']['workspace_context']
    workspace.update(project_id=body['context']['project_id'],sttm_id=body['context'].get('sttm_id'),
        source_tables=body['context']['source_tables'], target_table=body['context']['target_table'],
        relation_graph=body['context'].get('relation_graph'))
    workspace['mapping_rows']=[{'id':a['target_attribute'],'target_column':a['target_attribute'],
        'target_type':a.get('target_data_type')} for a in body['data']['attributes']]
    body['meta']['auto_map_resolution_mode']='reeval_all'
    body['meta'].update(automap_generation_policy='draft-v3',automap_rules_policy='rules-v2')
    report['acceptance_path']='HTTP prepare -> HTTP durable job -> actual private worker endpoint -> native source/rule agents'
    report['execution_context_seeded']=False
    report['worker_control_session_strategy']='production_reusable_caller_pool' if control_factory is not None else 'independent_native_caller_factory'
    report['operational_fixture_tables']=len(statements)
    report['runs']=[]
    previous_worker_settings=worker_main._settings
    worker_main._settings=settings
    try:
        with TestClient(worker_app) as worker_client,TestClient(app) as client,ThreadPoolExecutor(max_workers=2) as pool:
            proxy._local_worker_client=worker_client
            invalidate_prepared_workspace_context_cache()
            # Two simultaneous page/click prepares must coalesce and share one handle.
            start=time.monotonic()
            future=pool.submit(client.post,'/api/v1/workbench/context/prepare',json={'workspace':workspace})
            second=pool.submit(client.post,'/api/v1/workbench/context/prepare',json={'workspace':workspace})
            results=[f.result() for f in (future,second)]
            for result in results:result.raise_for_status()
            prepared=[r.json()['data'] for r in results]
            assert prepared[0]['workspace_context_id']==prepared[1]['workspace_context_id']
            report['concurrent_page_prepare']={'elapsed_seconds':round(time.monotonic()-start,2),
                'cache_statuses':[r['cache_status'] for r in prepared],
                'semantic_registry_version':prepared[0].get('semantic_registry_version'),
                'durable':all(r.get('cache_persisted') for r in prepared),
                'readiness':prepared[0].get('automap_readiness')}
            for index in range(3 if incident else 2):
                if index:
                    # Emulate another replica: clear memory; hydrate the durable handle.
                    invalidate_prepared_workspace_context_cache()
                    check=client.post('/api/v1/workbench/context/prepare',json={'workspace':workspace})
                    check.raise_for_status()
                    if index < len(prepared):prepared[index]=check.json()['data']
                    else:prepared.append(check.json()['data'])
                active=deepcopy(body);active['request_id']=str(uuid4())
                active['context'].update(workspace_context_id=prepared[index]['workspace_context_id'],
                    workspace_context_hash=prepared[index]['workspace_context_hash'])
                if incident:
                    # Authored query population stays present even when all row
                    # definitions are cleared. Checkbox/row state is not evidence.
                    rows=active['context']['workspace_context']['mapping_rows']
                    for row in rows:
                        name=row['target_column']
                        if index == 0 or (index == 2 and name in {'ID','FIRM_VALUE'}):
                            if name == 'OWNERNAME':row.update(mapping_mode='constant',constant_value='NULL',rule='Value')
                            elif name == 'FIRM_VALUE':row.update(mapping_mode='attribute',attribute_name='FirmPrefix',constant_value='$FirmPrefix',rule='Value')
                            elif name == 'DISPLAY_NAME':row.update(source_columns=['src.NAME'],rule='Custom',expression="$FirmPrefix || COALESCE(TRIM(src.NAME), 'Unknown')")
                            elif name == 'VALUE_CASE':row.update(rule='Custom',expression="CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other firm' END")
                            else:row.update(source_columns=['src.ID'],rule='Direct')
                assert active['context']['execution_context'] is None
                clicked_at=datetime.now(UTC).isoformat()
                started=time.monotonic();post=client.post('/api/v1/workbench/auto-map-jobs',json=active)
                post.raise_for_status();job=post.json()['data'];job_id=job['job_id']
                history=[]
                print(json.dumps({'stage':'native_job_accepted','run':index,'job_id':job_id}),flush=True)
                while job['status'] in {'queued','running'} and time.monotonic()-started<650:
                    time.sleep(2)
                    poll=client.get('/api/v1/workbench/auto-map-jobs/'+job_id);poll.raise_for_status()
                    job=poll.json()['data']
                    stage=job.get('stage')
                    if not history or history[-1]['stage']!=stage:
                        history.append({'stage':stage,'seconds':round(time.monotonic()-started,2)})
                        print(json.dumps({'stage':stage,'run':index,'seconds':history[-1]['seconds']}),flush=True)
                result=job.get('response') or {}
                mappings=((result.get('data') or {}).get('result') or result.get('result') or {}).get('mappings') or {}
                record={'job_id':job_id,'status':job['status'],'clicked_at':clicked_at,'elapsed_seconds':round(time.monotonic()-started,2),
                    'page_cache_status':prepared[index]['cache_status'],'stages':history,
                    'preparation_ms':job.get('preparation_ms'),'error':job.get('error'),
                    'preparation_diagnostics':job.get('preparation_diagnostics'), 'warnings':result.get('warnings'),
                    'mapping_count':len(mappings),'confidence_scores':{k:v.get('confidence_score') for k,v in mappings.items()},
                    'rules':{k:{'stage':v.get('rule_stage'),'sql':v.get('preprocessing_rule')} for k,v in mappings.items()},
                    'returned_mapping_definitions':mappings,'dispatch':result.get('meta',{}).get('auto_mapping_dispatch')}
                report['runs'].append(record)
                assert job['status']=='completed',job.get('error')
                assert len(mappings)==len(active['data']['attributes'])
                assert all(isinstance(v.get('confidence_score'),(int,float)) for v in mappings.values())
                assert any(v.get('confidence_score',0)>0 for v in mappings.values())
                # Verify the durable parent proof, not a synthetic request assembled by this harness.
                saved=read_saved_job(session,independent,namespace,job_id)
                persisted=AutoMappingProxyClient._load_job_state(saved)
                from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
                from app.core.automap_policy import preparation_hash
                frozen=STTMBuilderEnvelopeRequest.model_validate(persisted['request_envelope'])
                assert frozen.meta.get('_automap_call_tracking') == 'operation_v3'
                assert persisted.get('call_tracking') == 'operation_v3'
                assert frozen.context.execution_context is not None
                assert frozen.context.execution_context.snapshot_id
                assert frozen.context.prepared_context_hash==preparation_hash(frozen.context)
                assert frozen.meta['context_diagnostics']['cache_source']=='prepared_workspace'
                if incident:
                    from app.core.mapping_sql import MappingSqlService
                    from app.schema.mapping_sql import MappingSqlCompileRequest,MappingSqlMappingItem
                    graph=frozen.context.relation_graph
                    compiled=MappingSqlService(session=session,analyst_client=None).compile(MappingSqlCompileRequest(
                        relation_graph=graph,driving_relation_id='src',validate_with_explain=True,
                        mappings=[MappingSqlMappingItem(target_column=key,source_columns=value.get('source_attributes') or [],
                            source_dependencies=value.get('source_dependencies') or [],mapping_mode=value.get('mapping_mode') or 'source',
                            constant_value=value.get('constant_value'),attribute_name=value.get('attribute_name'),value_binding_ids=value.get('value_binding_ids') or [],
                            expression=value.get('preprocessing_rule'),rule=value.get('preprocessing_rule_type') or 'Direct') for key,value in mappings.items()]))
                    actual=[row.as_dict() for row in session.sql(compiled.preview_sql).collect()]
                    expected=[{'ID':i,'DISPLAY_NAME':name,'FIRM_VALUE':'TEST-','VALUE_CASE':'Test firm','OWNERNAME':None,
                        **{f'ID_COPY_{n:02d}':i for n in range(1,33)}} for i,name in [(1,'TEST-Alice'),(2,'TEST-Bob'),(3,'TEST-Unknown')]]
                    record['sql_output_matches_expected']=sorted(actual,key=lambda row:row['ID'])==expected
                    record['sample_output_rows']=sorted(actual,key=lambda row:row['ID'])
                    record['expected_output_rows']=expected
                    record['composed_preview_sql']=compiled.preview_sql
                    assert record['sql_output_matches_expected']
                    record['fir_recipe_cited']=bool(set(report.get('persisted_fir_recipe_ids',[])) & set(mappings['DISPLAY_NAME'].get('used_learning_ids') or []))
                    assert record['fir_recipe_cited']
                    assert all(value.get('confidence_score',0)>0 for value in mappings.values())
                    record['scenario']=['existing','blank_with_uploaded_sql','mixed'][index]
                    import subprocess
                    from pathlib import Path
                    root=Path(__file__).resolve().parents[1]
                    ui_rows=[{'id':row['id'],'targetColumn':row['target_column'],'targetType':row.get('target_type'),
                        'sourceColumn':(row.get('source_columns') or [None])[0], 'sourceColumns':row.get('source_columns') or [],
                        'expression':row.get('expression'), 'rule':row.get('rule') or 'Select...',
                        'mappingMode':row.get('mapping_mode') or 'source', 'constantValue':row.get('constant_value'),
                        'attributeName':row.get('attribute_name'), 'manuallySaved':bool(row.get('source_columns') or row.get('expression') or row.get('constant_value')),
                        'status':'MAPPED' if row.get('source_columns') or row.get('expression') or row.get('constant_value') else 'UNMAPPED'}
                        for row in active['context']['workspace_context']['mapping_rows']]
                    replay=subprocess.run(['node',str(root/'frontend/scripts/test-automap-preservation.cjs'),'--proxy-replay'],
                        input=json.dumps({'rows':ui_rows,'partials':[result],'terminal':result}),capture_output=True,text=True,timeout=60)
                    assert replay.returncode==0, replay.stderr[-2000:]
                    ui=json.loads(replay.stdout)
                    record['ui_completion']=ui['completion']
                    record['review_rows']=[{key:row.get(key) for key in ('targetColumn','sourceColumn','sourceColumns',
                        'expression','rule','confidenceScore','aiReviewStatus','aiGeneration')} for row in ui['rows']]
                    assert ui['completion']['supportedProposals']==37
                    assert ui['completion']['newMappings']==(0 if index==0 else 37 if index==1 else 35)
                    assert all(row.get('confidenceScore',0)>0 for row in ui['rows'])

                print(json.dumps({'stage':'verified_run','run':index,'seconds':record['elapsed_seconds'],'proposals':record.get('ui_completion',{}).get('supportedProposals'),'sql_correct':record.get('sql_output_matches_expected'),'confidence_positive':all(value>0 for value in record['confidence_scores'].values())}),flush=True)
                record['handoff_verified']={'execution_context':True,'snapshot':True,'preparation_hash':True,
                    'cache_source':frozen.meta['context_diagnostics']['cache_source']}
                assert not (record['dispatch'] or {}).get('failed_batches')
            tool_rows=session.sql(f'SELECT STAGE, SUM(CALL_COUNT) AS CALLS FROM {namespace}.TBL_AUTOMAP_TOOL_CONTEXT GROUP BY STAGE').collect()
            report['native_tool_calls']=[row.as_dict() for row in tool_rows]
            report['worker_endpoint_calls']=worker_records
            report['status']='passed'
            return 0
    finally:
        worker_main._settings=previous_worker_settings
        proxy._local_worker_client=None
        AutoMappingProxyClient._persist_job=original_persist
        report['worker_endpoint_calls']=worker_records
        worker_app.dependency_overrides.clear()
        sttm_builder.get_settings=previous
