"use client";
import axios from "axios";
import { AiaBox, AiaButton, AiaIconButton, AiaSelect, AiaStack } from '@/components/ui';
import { AiaInput } from '@/components/ui/aia-input';
import { AiaText } from '@/components/ui/aia-text';
import { useEffect, useMemo, useRef, useState } from "react";
import {
  AddRoundedIcon,
  ArrowForwardRoundedIcon,
  CloseRoundedIcon,
  GridOnRoundedIcon,
  TerminalRoundedIcon,
  ViewKanbanRoundedIcon,
} from "@/utils/icons";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import { useTour } from "@/features/tour/engine/tour-context";
import { API_ROUTES } from "@/api/routes";
import { useRouter } from "next/navigation";
import { useStore } from "react-redux";
import { useAppDispatch } from "@/store/hooks";
import type { RootState } from "@/store/store";
import sttmBuilderReducer, {
  applyParsedSqlWorkspace,
  openSttmFromBackend,
  setPublishedMappingIdentity,
  snapshotFromState,
} from "@/features/sttm/store/sttm-builder-slice";
import { observeSqlUpload, uploadRecoveryKey, readSqlUploadHandle, sqlUploadFingerprint } from "@/features/sttm/mapping/sql-upload-recovery";
import { buildSqlUploadWorkspace } from "@/features/sttm/mapping/sql-upload-workspace";
import type { ParsedSqlWorkspaceApplyPayload } from "@/features/sttm/types/sttm.types";
import {
  SqlBundleReviewPanel,
  type SqlUploadResult as UploadResult,
} from "@/features/sttm/mapping/sql-bundle-review-panel";
import { resolveApiBaseUrl } from "@/api/axiosInstance";
import {
  createProjectSttm,
  autosaveSttm,
  getAllProjectsSummary,
  upsertProjectAttributes,
} from "@/services/projectService";

type MappingCreationMode = "sql" | "excel" | "manual" | null;

export type NewMappingManualDetails = {
  name: string;
  description: string;
  linkedMappingIds: string[];
  projectId?: string;
};

export type NewMappingProjectOption = {
  value: string;
  label: string;
};

type NewMappingDialogProps = {
  open: boolean;
  onClose: () => void;
  projectId?: string;
  projectOptions?: NewMappingProjectOption[];
  precedentMappings?: Array<{ id: string; name: string; projectName: string }>;
  existingSttmId?: string;
  fixedTargetTable?: string;
  initialMode?: Exclude<MappingCreationMode, null>;
  logicalTargetKey?: string;
  sourceSystemKey?: string;
};

function isAbortError(err: unknown) {
  return (err instanceof DOMException && err.name === "AbortError")
    || axios.isCancel(err);
}

function tableRefFromQualifiedName(qualifiedName: string | null | undefined) {
  const [database, schema, table] = String(qualifiedName ?? "").split(".", 3);
  return database && schema && table ? { database, schema, table } : null;
}

function targetNamesMatch(expected: string, actual: string | null | undefined) {
  const expectedParts = expected.replaceAll('"', "").toUpperCase().split(".").filter(Boolean);
  const actualParts = String(actual ?? "").replaceAll('"', "").toUpperCase().split(".").filter(Boolean);
  if (!expectedParts.length || !actualParts.length) return false;
  if (expectedParts.length === 3 && actualParts.length === 3) {
    return expectedParts.every((value, index) => value === actualParts[index]);
  }
  return expectedParts.at(-1) === actualParts.at(-1);
}

function uploadWorkspaceSnapshot(
  currentState: RootState["sttmBuilder"],
  workspace: ParsedSqlWorkspaceApplyPayload,
  identity: { projectId: string; sttmId: string | null; sttmName: string },
) {
  // Build the snapshot exactly as later autosaves will, from the state the
  // upload produces, so the first autosave after navigation is a no-op.
  const nextState = sttmBuilderReducer(currentState, applyParsedSqlWorkspace(workspace));
  const snapshot = snapshotFromState(
    {
      ...nextState,
      activeProjectId: identity.projectId,
      activeSttmId: identity.sttmId,
      activeSttmName: identity.sttmName,
      chatMessages: [],
      agentThreadId: null,
    },
    "import.completed",
    {
      page: workspace.targetTableFqn ? "mapping" : "builder",
      surface: workspace.targetTableFqn ? "MAPPING" : "SOURCE_SELECTION",
    },
  );
  return { ...snapshot, raw_mapping_sql: workspace.sql };
}

type MappingOption = {
  id: Exclude<MappingCreationMode, null>;
  label: string;
  badge?: string;
  badgeBg: string;
  badgeFg: string;
  description: string;
  icon: React.ReactNode;
};

const OPTIONS: MappingOption[] = [
  {
    id: "sql",
    label: "SQL Upload",
    badge: "AUTO-GENERATE",
    badgeBg: "#ede9fe",
    badgeFg: "#7c3aed",
    description: "Upload a SQL file and auto-generate the source-to-target mapping from your query.",
    icon: <TerminalRoundedIcon sx={{ fontSize: 24, color: "#64748b" }} />,
  },
  {
    id: "excel",
    label: "Upload Excel File",
    badge: "IMPORT",
    badgeBg: "#dcfce7",
    badgeFg: "#059669",
    description: "Import an existing mapping spreadsheet to populate the STTM grid automatically.",
    icon: <GridOnRoundedIcon sx={{ fontSize: 24, color: "#64748b" }} />,
  },
  {
    id: "manual",
    label: "Build Mapping Manually",
    badgeBg: "transparent",
    badgeFg: "#0f172a",
    description: "Select source tables, define joins, and map columns step by step through the guided workflow.",
    icon: <ViewKanbanRoundedIcon sx={{ fontSize: 24, color: "#64748b" }} />,
  },
];

export default function NewMappingDialog({
  open,
  onClose,
  projectId,
  projectOptions: projectOptionsProp,
  precedentMappings = [],
  existingSttmId,
  fixedTargetTable,
  initialMode,
  logicalTargetKey,
  sourceSystemKey,
}: NewMappingDialogProps) {
  const dispatch = useAppDispatch();
  const store = useStore<RootState>();
  const { registerModalTour, startTour } = useTour();
  const [selectedMode, setSelectedMode] = useState<MappingCreationMode>(null);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [mappingName, setMappingName] = useState("");
  const [mappingDescription, setMappingDescription] = useState("");
  const [sourceTableHints, setSourceTableHints] = useState("");
  const [targetTableHint, setTargetTableHint] = useState("");
  const [linkedMappingIds, setLinkedMappingIds] = useState<string[]>([]);
  const [loadedProjectOptions, setLoadedProjectOptions] = useState<NewMappingProjectOption[]>([]);
  const [isLoadingProjects, setIsLoadingProjects] = useState(false);
  const sqlInputRef = useRef<HTMLInputElement | null>(null);
  const excelInputRef = useRef<HTMLInputElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [uploadingOperation, setUploadingOperation] = useState<string>("");

  useEffect(() => {
    if (!open) {
      registerModalTour(null);
      return;
    }
    registerModalTour("new-mapping");
    return () => registerModalTour(null);
  }, [open, registerModalTour]);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  useEffect(() => {
    if (open) {
      setSelectedProjectId(projectId?.trim() || "");
      setSelectedMode(initialMode ?? null);
      setTargetTableHint(fixedTargetTable ?? "");
    }
  }, [fixedTargetTable, initialMode, open, projectId]);

  useEffect(() => {
    if (!open || (projectOptionsProp && projectOptionsProp.length > 0)) return;
    let cancelled = false;
    setIsLoadingProjects(true);
    getAllProjectsSummary()
      .then(({ projects }) => {
        if (!cancelled) {
          setLoadedProjectOptions(projects.map((project) => ({
            value: project.project_id,
            label: project.project_name,
          })));
        }
      })
      .catch(() => {
        if (!cancelled) setLoadedProjectOptions([]);
      })
      .finally(() => {
        if (!cancelled) setIsLoadingProjects(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, projectOptionsProp]);

  const projectOptions = useMemo(
    () => projectOptionsProp?.length ? projectOptionsProp : loadedProjectOptions,
    [loadedProjectOptions, projectOptionsProp],
  );

  const selectedOption = useMemo(
    () => OPTIONS.find((option) => option.id === selectedMode) ?? null,
    [selectedMode],
  );
  const canSubmitManual = Boolean(
    selectedProjectId.trim() && mappingName.trim() && mappingDescription.trim(),
  );

  const handleClose = () => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setSelectedMode(initialMode ?? null);
    setSelectedProjectId(projectId?.trim() || "");
    setMappingName("");
    setMappingDescription("");
    setSourceTableHints("");
    setTargetTableHint(fixedTargetTable ?? "");
    setLinkedMappingIds([]);
    setUploadResult(null);
    setSelectedProjectValueNames([]);
    setLearningComplete(false);
    setUploadingOperation("");
    onClose();
  };

  const handleUploadSelection = (input: HTMLInputElement | null) => {
    if (!input) {
      return;
    }
    input.value = "";
    input.click();
  };

  const handleProceed = async () => {
    if (!selectedMode) {
      return;
    }

    if (selectedMode === "manual") {
      if (!canSubmitManual) return;
      const details: NewMappingManualDetails = {
        name: mappingName.trim(),
        description: mappingDescription.trim(),
        linkedMappingIds,
        projectId: selectedProjectId.trim(),
      };

      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setUploadingOperation("Creating mapping...");
      setUploading(true);
      try {
        const sttm = await createProjectSttm(details.projectId ?? "", {
          sttm_name: details.name,
          description: details.description || null,
          precedent_links: details.linkedMappingIds.map((sttmId, index) => ({
            precedent_sttm_id: sttmId,
            priority: Math.max(1, 100 - index),
            knowledge_categories: [
              "column_mapping",
              "relationship",
              "transformation",
              "query_shaping",
              "derived_lineage",
            ],
            allow_project_specific_values: false,
          })),
        });
        if (controller.signal.aborted) return;
        await dispatch(openSttmFromBackend({
          sttmId: sttm.sttm_id,
          projectId: details.projectId ?? "",
        })).unwrap();
        setSelectedMode(null);
        setMappingName("");
        setMappingDescription("");
        setLinkedMappingIds([]);
        onClose();
        router.push(
          process.env.NEXT_PUBLIC_DURABLE_STTM_ROUTE_V1 !== "false"
            ? `/sttm/builder/${encodeURIComponent(sttm.sttm_id)}`
            : "/sttm/builder/new",
        );
      } catch (error) {
        if (isAbortError(error)) return;
        alert(error instanceof Error ? error.message : "Unable to create mapping.");
      } finally {
        setUploading(false);
      }
      return;
    }

    handleUploadSelection(selectedMode === "sql" ? sqlInputRef.current : excelInputRef.current);
  };

  const router = useRouter();
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<UploadResult | null>(null);
  const [learningInProgress, setLearningInProgress] = useState(false);
  const [learningComplete, setLearningComplete] = useState(false);
  const [learningStatus, setLearningStatus] = useState("queued");
  const [selectedProjectValueNames, setSelectedProjectValueNames] = useState<string[]>([]);

  const [recoveryIdentity,setRecoveryIdentity] = useState<string | null>(null);
  useEffect(() => {
    if (!open) return;
    setRecoveryIdentity(null);
    const controller = new AbortController();
    fetch(`${resolveApiBaseUrl()}/v1/upload/sql/recovery-identity`, {signal:AbortSignal.any([controller.signal,AbortSignal.timeout(8000)])})
      .then(async response => { if (!response.ok) throw new Error('identity unavailable'); return response.json(); })
      .then(body => { if (!controller.signal.aborted && typeof body.scope === 'string') setRecoveryIdentity(body.scope); })
      .catch(() => {});
    return () => controller.abort();
  },[open]);
  const [uploadRecoveryNotice, setUploadRecoveryNotice] = useState("");
  const recoverSqlUpload = async (requestId: string, project: string, signal: AbortSignal) => {
    const receipt = await observeSqlUpload(resolveApiBaseUrl(), project, requestId, signal);
    if (signal.aborted) return;
    const clearHandle = () => {
      const key = uploadRecoveryKey(project, existingSttmId || '', recoveryIdentity || '');
      if (readSqlUploadHandle(localStorage.getItem(key))?.requestId === requestId) localStorage.removeItem(key);
    };
    if (receipt.result) {
      const uploaded = receipt.result as UploadResult;
      setUploadResult(uploaded);
      const bindings = uploaded.import_preview?.project_value_candidates ?? uploaded.parsed_summary?.variable_bindings ?? [];
      setSelectedProjectValueNames(bindings.filter(item => item.project_value_candidate).map(item => item.name));
      setUploadRecoveryNotice(receipt.status === 'failed' ? 'The preview is saved; background processing failed. You can review the SQL and retry the upload.' : receipt.status !== 'completed' ? 'The preview is saved. Reference and learning preparation continue; Check upload refreshes their status.' : '');
      // Only a known terminal outcome retires the browser's recovery handle.
      // Keep the handle until successful Apply; reload must recover this preview.
    } else if (receipt.status === 'needs_reupload') {
      clearHandle();
      setUploadRecoveryNotice('The upload processor changed. Select the file again for a new processing run; the earlier run remains in history.');
    } else if (receipt.status === 'not_accepted') {
      clearHandle();
      setUploadRecoveryNotice('No accepted upload was found. Select the file again to retry; compatible accepted uploads are deduplicated.');
    } else if (receipt.status === 'failed') {
      clearHandle();
      setUploadRecoveryNotice('SQL processing failed. Select the file again to start a new processing run.');
    } else {
      setUploadRecoveryNotice('SQL processing may still be running. Check the saved request again; no duplicate upload was sent.');
    }
  };
  const checkSavedUpload = async () => {
    abortControllerRef.current?.abort();
    const project = selectedProjectId || projectId || 'default';
    const saved = readSqlUploadHandle(localStorage.getItem(uploadRecoveryKey(project, existingSttmId || '', recoveryIdentity || '')));
    if (!saved) return;
    const controller = new AbortController();
    abortControllerRef.current?.abort(); abortControllerRef.current = controller;
    setUploading(true); setUploadingOperation('Recovering SQL upload...');
    try { await recoverSqlUpload(saved.requestId, project, controller.signal); }
    catch (error) { if (!isAbortError(error)) setUploadRecoveryNotice('Unable to check the saved upload. Sign in and try Check upload again.'); }
    finally { setUploading(false); setUploadingOperation(''); }
  };
  useEffect(() => {
    if (!open || !recoveryIdentity) return;
    setUploadRecoveryNotice('');
    void checkSavedUpload();
    return () => abortControllerRef.current?.abort();
    // Recovery is scoped to the same project and mapping across reloads.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, selectedProjectId, projectId, existingSttmId, recoveryIdentity]);

  const handleFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "sql" | "excel"
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("File exceeds 5MB limit");
      return;
    }

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setUploadingOperation(type === "sql" ? "Uploading SQL file..." : "Uploading Excel file...");
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("project_id", selectedProjectId || projectId || "default");
      formData.append("mode", "auto_populate");
      formData.append("source_table_hints", sourceTableHints.trim());
      formData.append("target_table_hint", targetTableHint.trim());
      if (existingSttmId) formData.append("sttm_id", existingSttmId);
      if (fixedTargetTable) formData.append("expected_target_table", fixedTargetTable);
      if (logicalTargetKey) formData.append("logical_target_key", logicalTargetKey);
      if (sourceSystemKey) formData.append("source_system_key", sourceSystemKey);
      // Tables of the mapping being re-imported qualify partial names in the
      // upload. Another mapping's workspace must never influence resolution.
      const builderState = store.getState().sttmBuilder;
      const knownTables = existingSttmId && builderState.activeSttmId === existingSttmId
        ? builderState.sources
          .map((table) => table.qualifiedName)
          .filter((name) => name.split(".").filter(Boolean).length === 3)
        : [];
      if (knownTables.length) formData.append("known_tables", JSON.stringify(knownTables));

      if (type === 'sql') {
        if (!recoveryIdentity) throw new Error('Your upload identity is not ready. Reopen this dialog after signing in.');
        const project = selectedProjectId || projectId || 'default';
        const key = uploadRecoveryKey(project, existingSttmId || '', recoveryIdentity || '');
        const fingerprint = await sqlUploadFingerprint(file, Array.from(formData.entries())
          .filter(([name])=>name !== 'file').map(([name,value])=>[name,String(value)]));
        if (controller.signal.aborted) return;
        const existing = readSqlUploadHandle(localStorage.getItem(key));
        if (existing?.fingerprint === fingerprint) {
          await recoverSqlUpload(existing.requestId, project, controller.signal);
          return;
        }
        const requestId = crypto.randomUUID();
        localStorage.setItem(key, JSON.stringify({requestId,fingerprint})); // Before POST: its acknowledgment can be lost.
        formData.append('upload_request_id', requestId);
        let accepted: Response | undefined;
        try {
          accepted = await fetch(`${resolveApiBaseUrl()}${API_ROUTES.upload.sql}`, {
            method:'POST', body:formData, signal:AbortSignal.any([controller.signal,AbortSignal.timeout(30000)]),
          });
        } catch (error) {
          if (controller.signal.aborted) throw error;
          // Transport uncertainty and server errors reconcile the durable identity.
        }
        if (accepted && !accepted.ok && accepted.status < 500) {
          localStorage.removeItem(key);
          throw new Error(await accepted.text());
        }
        await recoverSqlUpload(requestId, project, controller.signal);
        return;
      }
      const endpoint = API_ROUTES.upload.excel;
      const response = await fetch(`${resolveApiBaseUrl()}${endpoint}`, {
        method: "POST",
        body: formData,
        signal: controller.signal,
      });

      if (!response.ok) {
        const raw = await response.text();
        let detail = raw;
        try {
          const parsed = JSON.parse(raw);
          detail = typeof parsed?.detail === "string"
            ? parsed.detail
            : JSON.stringify(parsed?.detail ?? parsed);
        } catch {
          // Keep the backend text response.
        }
        alert(detail || `Upload failed (${response.status})`);
        return;
      }

      const result = await response.json() as UploadResult;
      const uploaded = { ...result, project_id: selectedProjectId || projectId || "default", filename: file.name };
      setUploadResult(uploaded);
      const bindings = uploaded.import_preview?.project_value_candidates
        ?? uploaded.parsed_summary?.variable_bindings
        ?? [];
      setSelectedProjectValueNames(
        bindings
          .filter((item) => item.project_value_candidate)
          .map((item) => item.name),
      );
    } catch (error) {
      if (isAbortError(error)) return;
      alert("Upload failed. Please try again.");
    } finally {
      setUploading(false);
      setUploadingOperation("");
    }
  };

  const handleContinueEditing = async () => {
    if (!uploadResult) return;
    const selectedProject = selectedProjectId || projectId || "";
    if (!selectedProject) return;

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setUploadingOperation("Processing mapping...");
    setUploading(true);
    try {
      const workspace = buildSqlUploadWorkspace(uploadResult, {
        approvedProjectValueNames: selectedProjectValueNames,
      });
      if (workspace.unresolvedSourceTables?.length) {
        throw new Error(`Resolve these SQL source identities before continuing: ${workspace.unresolvedSourceTables.join(", ")}`);
      }
      if (fixedTargetTable) {
        if (!targetNamesMatch(fixedTargetTable, workspace.targetTableFqn)) {
          throw new Error(
            workspace.targetTableFqn
              ? `This upload targets ${workspace.targetTableFqn}, but this mapping is locked to ${fixedTargetTable}.`
              : `The uploaded target could not be resolved. This mapping is locked to ${fixedTargetTable}.`,
          );
        }
        workspace.targetTableFqn = fixedTargetTable;
      }
      const parsedBindings = uploadResult.import_preview?.project_value_candidates
        ?? uploadResult.parsed_summary?.variable_bindings
        ?? [];
      const selectedKeys = new Set(selectedProjectValueNames.map((name) => name.toUpperCase()));
      const firmValues = new Map<string, {
        attribute_name: string;
        attribute_type: string;
        attribute_value: string;
      }>();
      for (const binding of parsedBindings) {
        if (!binding.project_value_candidate || !selectedKeys.has(binding.name.toUpperCase())) continue;
        if (binding.resolved_value === null || binding.resolved_value === undefined) continue;
        const key = binding.name.toUpperCase();
        firmValues.set(key, {
          attribute_name: binding.name,
          attribute_type: String(binding.inferred_type || "VARCHAR").toUpperCase(),
          attribute_value: String(binding.resolved_value),
        });
      }
      for (const mapping of workspace.mappings) {
        if (mapping.mappingMode !== "attribute" || !mapping.attributeName) continue;
        const key = mapping.attributeName.toUpperCase();
        if (firmValues.has(key)) continue;
        firmValues.set(key, {
          attribute_name: mapping.attributeName,
          attribute_type:
            !mapping.targetType || mapping.targetType.toUpperCase() === "TEXT"
              ? "VARCHAR"
              : mapping.targetType,
          attribute_value: String(mapping.constantValue ?? ""),
        });
      }
      if (firmValues.size) {
        const upserted = await upsertProjectAttributes(
          selectedProject,
          [...firmValues.values()],
          controller.signal,
        );
        const valuesByName = new Map(
          upserted.attributes.map((attribute) => [
            attribute.attribute_name.toUpperCase(),
            attribute.attribute_value,
          ]),
        );
        for (const mapping of workspace.mappings) {
          if (mapping.attributeName) {
            mapping.constantValue = valuesByName.get(mapping.attributeName.toUpperCase())
              ?? mapping.constantValue;
          }
        }
      }
      const filename = uploadResult.filename || "SQL mapping";
      const sttmName = filename.replace(/\.[^.]+$/, "");
      const builderState = store.getState().sttmBuilder;
      const createdSttm = existingSttmId
        ? null
        : await createProjectSttm(selectedProject, {
            sttm_name: sttmName,
            description: `Imported from ${filename}`,
            target_table: tableRefFromQualifiedName(workspace.targetTableFqn),
            workspace_snapshot: uploadWorkspaceSnapshot(builderState, workspace, {
              projectId: selectedProject,
              sttmId: null,
              sttmName,
            }),
          }, controller.signal);
      const saved = existingSttmId
        ? await autosaveSttm(existingSttmId, {
          workspace_snapshot: uploadWorkspaceSnapshot(builderState, workspace, {
            projectId: selectedProject,
            sttmId: existingSttmId,
            sttmName,
          }),
          action: "import.completed",
          metadata: {
            upload_asset_id: uploadResult.asset_id,
            upload_learning_job_id: uploadResult.learning_job_id,
            upload_filename: filename,
            expected_target_table: fixedTargetTable,
          },
        })
        : null;
      const sttmId = existingSttmId ?? createdSttm!.sttm_id;
      dispatch(applyParsedSqlWorkspace(workspace));
      dispatch(setPublishedMappingIdentity({
        projectId: selectedProject,
        sttmId,
        sttmName: createdSttm?.sttm_name ?? sttmName,
        projectName: projectOptions?.find((option) => option.value === selectedProject)?.label ?? null,
        snapshotId: saved?.snapshot_id ?? createdSttm?.last_snapshot_id ?? null,
      }));
      localStorage.removeItem(uploadRecoveryKey(selectedProject, existingSttmId || '', recoveryIdentity || ''));
      sessionStorage.removeItem("upload_parsed_data");
      setUploadResult(null);
      setSelectedMode(null);
      onClose();
      router.push(
        process.env.NEXT_PUBLIC_DURABLE_STTM_ROUTE_V1 !== "false"
          ? `/sttm/builder/${encodeURIComponent(sttmId)}${workspace.targetTableFqn ? "/mapping" : ""}?source=upload`
          : workspace.targetTableFqn
            ? "/sttm/builder/new/mapping?source=upload"
            : "/sttm/builder/new?source=upload",
      );
    } catch (error) {
      if (isAbortError(error)) return;
      alert(error instanceof Error ? error.message : "Unable to create mapping from SQL.");
    } finally {
      setUploading(false);
      setUploadingOperation("");
    }
  };

  const handleUseAsLearning = async () => {
    if (!uploadResult?.asset_id) return;

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setUploadingOperation("Submitting for offline learning...");
    setLearningInProgress(true);
    setLearningComplete(false);
    try {
      const formData = new FormData();
      formData.append("asset_id", uploadResult.asset_id);
      if (uploadResult.upload_request_id) formData.append('upload_request_id', uploadResult.upload_request_id);
      formData.append("project_id", selectedProjectId || projectId || "default");
      formData.append("approved_project_values", JSON.stringify(selectedProjectValueNames));
      const response = await fetch(
        `${resolveApiBaseUrl()}${API_ROUTES.upload.triggerLearning}`,
        {
        method: "POST",
        body: formData,
        signal: controller.signal,
        },
      );
      if (!response.ok) {
        const err = await response.json().catch(() => ({ detail: "Learning failed" }));
        alert(err.detail || "Failed to create learnings.");
        return;
      }
      const queued = await response.json().catch(() => ({}));
      const jobId = String(
        queued?.learning_job_id
        ?? uploadResult.learning_job_id
        ?? "",
      );
      let status = String(queued?.learning_job?.status ?? "queued").toLowerCase();
      if (jobId) {
        let attempts = 0;
        while (!["completed", "failed"].includes(status) && attempts < 20) {
          if (controller.signal.aborted) return;
          attempts += 1;
          const resume = await fetch(
            `${resolveApiBaseUrl()}${API_ROUTES.workbench.firJobResume(jobId)}`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ max_items: 10 }),
              signal: controller.signal,
            },
          );
          if (!resume.ok) {
            throw new Error("Document submitted, but its learning status could not be checked. Processing may still be running; check FIR jobs before retrying.");
          }
          const envelope = await resume.json().catch(() => ({}));
          status = String(envelope?.data?.status ?? "running").toLowerCase();
        }
      }
      if (controller.signal.aborted) return;
      if (status === "failed") {
        throw new Error("Offline learning failed. Review the FIR job errors; this document is not confirmed as reusable learning.");
      }
      setLearningStatus(status);
      setLearningComplete(true);
    } catch (error) {
      if (isAbortError(error)) return;
      alert(error instanceof Error ? error.message : "Unable to confirm offline learning status. Check FIR jobs before retrying.");
    } finally {
      setLearningInProgress(false);
      setUploadingOperation("");
    }
  };

  const handleLearningDone = () => {
    setUploadResult(null);
    setSelectedProjectValueNames([]);
    setLearningComplete(false);
    setSelectedMode(null);
    onClose();
  };

  if (!open) {
    return (
      <>
        <input
          ref={sqlInputRef}
          type="file"
          accept=".sql,text/sql,application/sql"
          hidden
          onChange={(e) => handleFileUpload(e, "sql")}
        />
        <input
          ref={excelInputRef}
          type="file"
          accept=".xlsx,.xls,.csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
          hidden
          onChange={(e) => handleFileUpload(e, "excel")}
        />
      </>
    );
  }

  return (
    <>
      <AiaBox
        role="dialog"
        aria-modal="true"
        aria-label="New Mapping"
        onClick={(event) => {
          // The precedent multi-select uses a portal. Its option clicks bubble
          // through the React tree and must not close/reset the mapping form.
          if (event.target === event.currentTarget) {
            handleClose();
          }
        }}
        sx={{
          position: "fixed",
          inset: 0,
          zIndex: 1400,
          px: { xs: 1, sm: 2 },
          py: { xs: 1, sm: 2 },
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(15, 23, 42, 0.42)",
          backdropFilter: "blur(4px)",
        }}
      >
        <AiaBox
          data-tour={TOUR_TARGETS.newMappingModal}
          onClick={(event) => event.stopPropagation()}
          sx={{
            width: "100%",
            maxWidth: 728,
            maxHeight: "calc(100dvh - 16px)",
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            borderRadius: "24px",
            border: "1px solid rgba(15, 23, 42, 0.08)",
            boxShadow: "0 30px 60px rgba(15, 23, 42, 0.18)",
            overflow: "hidden",
            backgroundColor: "#fff",
          }}
        >
          <AiaBox
            sx={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: 2,
              px: 4,
              py: 3.25,
              flexShrink: 0,
              borderBottom: "1px solid #edf2f7",
            }}
          >
            <AiaStack direction="row" spacing={2} sx={{ alignItems: "center" }}>
              <AiaBox
                sx={{
                  width: 48,
                  height: 48,
                  borderRadius: "14px",
                  bgcolor: "var(--aia-button-color)",
                  color: "var(--aia-button-text-color)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <AddRoundedIcon sx={{ fontSize: 28 }} />
              </AiaBox>
              <AiaBox>
                <AiaText sx={{ fontSize: 18, fontWeight: 800, color: "#0f172a" }}>
                  New Mapping
                </AiaText>
                <AiaText sx={{ fontSize: 14, color: "#64748b", mt: 0.5 }}>
                  Choose how you&apos;d like to create this mapping
                </AiaText>
              </AiaBox>
            </AiaStack>

            <AiaStack direction="row" spacing={1} sx={{ alignItems: "center", flexShrink: 0 }}>
              <AiaButton
                variant="contained"
                size="small"
                onClick={() => startTour("new-mapping")}
                aria-label="Start New Mapping tour guide"
                sx={{
                  textTransform: "none",
                  fontWeight: 700,
                  fontSize: 13,
                  borderRadius: "10px",
                  px: 1.5,
                  py: 0.6,
                  minHeight: 34,
                  backgroundColor: "var(--aia-primary-bg-color)",
                  color: "var(--aia-primary-bg-text-color)",
                  boxShadow: "none",
                  "&:hover": {
                    backgroundColor: "var(--aia-primary-bg-hover-color)",
                  },
                }}
              >
                Tour Guide
              </AiaButton>
              <AiaIconButton
                onClick={handleClose}
              sx={{
                border: "1px solid #e2e8f0",
                color: "#64748b",
                bgcolor: "#fff",
                "&:hover": {
                  bgcolor: "#f8fafc",
                },
              }}
            >
              <CloseRoundedIcon sx={{ fontSize: 18 }} />
            </AiaIconButton>
            </AiaStack>
          </AiaBox>

          <AiaBox sx={{ minHeight: 0, overflowY: "auto", overflowX: "hidden", position: "relative" }}>
            {uploading && (
              <AiaBox
                sx={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: "rgba(255, 255, 255, 0.2)",
                  backdropFilter: "blur(1px)",
                  zIndex: 10,
                }}
              >
                <AiaStack spacing={2} sx={{ alignItems: "center" }}>
                  <AiaBox
                    sx={{
                      width: 64,
                      height: 64,
                      borderRadius: "50%",
                      border: "4px solid #e2e8f0",
                      borderTopColor: "var(--aia-button-color)",
                      animation: "spin 1s linear infinite",
                      "@keyframes spin": {
                        from: { transform: "rotate(0deg)" },
                        to: { transform: "rotate(360deg)" },
                      },
                    }}
                  />
                  {uploadingOperation && (
                    <AiaText sx={{ fontSize: 14, fontWeight: 600, color: "#0f172a", textAlign: "center" }}>
                      {uploadingOperation}
                    </AiaText>
                  )}
                </AiaStack>
              </AiaBox>
            )}
          {uploadResult ? (
            <AiaBox sx={{ px: { xs: 2, sm: 4 }, py: { xs: 2, sm: 3.5 }, minWidth: 0 }}>
              {learningComplete ? (
                <AiaStack spacing={2} sx={{ alignItems: "center", py: 2 }}>
                  <AiaBox sx={{ width: 56, height: 56, borderRadius: "50%", bgcolor: "#dcfce7", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <AiaText sx={{ fontSize: 28 }}>&#10003;</AiaText>
                  </AiaBox>
                  <AiaText sx={{ fontSize: 16, fontWeight: 700, color: "#0f172a", textAlign: "center" }}>
                    {learningStatus === "completed" ? "Offline Processing Completed" : "Document Submitted for Learning"}
                  </AiaText>
                  <AiaText sx={{ fontSize: 13.5, color: "#64748b", textAlign: "center" }}>
                    {learningStatus === "completed"
                      ? "Processing finished. Extracted SQL remains candidate evidence until validated or explicitly accepted; completion does not confirm Search visibility or Auto-map eligibility."
                      : "Offline processing is not yet confirmed complete. Check FIR jobs for progress. Submission does not approve this SQL as a reusable mapping."}
                  </AiaText>
                  <AiaButton variant="contained" color="primary" rounded="lg" size="medium" onClick={handleLearningDone} sx={{ mt: 1, borderRadius: "14px", fontWeight: 700 }}>
                    Done
                  </AiaButton>
                </AiaStack>
              ) : learningInProgress ? (
                <AiaStack spacing={2} sx={{ alignItems: "center", py: 3 }}>
                  <AiaBox sx={{ width: 48, height: 48, borderRadius: "50%", border: "3px solid #e2e8f0", borderTopColor: "var(--aia-button-color)", animation: "spin 1s linear infinite", "@keyframes spin": { from: { transform: "rotate(0deg)" }, to: { transform: "rotate(360deg)" } } }} />
                  <AiaText sx={{ fontSize: 15, fontWeight: 700, color: "#0f172a" }}>
                    Queueing Document...
                  </AiaText>
                  <AiaText sx={{ fontSize: 13, color: "#64748b", textAlign: "center" }}>
                    Saving this document for the next offline FIR cycle.
                  </AiaText>
                </AiaStack>
              ) : (
                <AiaStack spacing={2.5}>
                  <AiaBox sx={{ p: 2, borderRadius: "12px", bgcolor: "#f8fafc", border: "1px solid #e2e8f0" }}>
                    <AiaText sx={{ fontSize: 13, fontWeight: 700, color: "#334155", mb: 0.5 }}>
                      File uploaded: {uploadResult.filename || "document"}
                    </AiaText>
                    {uploadResult.parsed_summary && (
                      <AiaText sx={{ fontSize: 12.5, color: "#64748b" }}>
                        {uploadResult.parsed_summary.source_tables?.length ?? 0} source table(s)
                        {uploadResult.parsed_summary.target_table ? " • target bound" : " • target needs review"}
                        {uploadResult.parsed_summary.column_mappings?.length
                          ? ` • ${uploadResult.parsed_summary.column_mappings.length} columns`
                          : ""}
                      </AiaText>
                    )}
                  </AiaBox>
                  {uploadResult.import_preview ? (
                    <SqlBundleReviewPanel
                      result={uploadResult}
                      onApplyDraft={handleContinueEditing}
                      selectedProjectValueNames={selectedProjectValueNames}
                      onProjectValueSelectionChange={setSelectedProjectValueNames}
                      onReferencesChange={(assetId, references) => setUploadResult((current) =>
                        current?.asset_id === assetId ? {
                          ...current,
                          import_preview: { ...current.import_preview, table_references: references },
                        } : current)}
                    />
                  ) : null}
                  {uploadResult.learning_coverage ? (
                    <AiaBox sx={{ p: 1.5, borderRadius: "12px", bgcolor: "#F8FAFC", border: "1px solid #E2E8F0" }}>
                      <AiaText sx={{ fontSize: 12.5, fontWeight: 700, color: "#334155" }}>
                        Learning coverage: {uploadResult.learning_coverage.deterministic_learnings_saved} deterministic pattern(s) saved from {uploadResult.learning_coverage.resolved_mapping_rows}/{uploadResult.learning_coverage.parsed_mapping_rows} resolved row(s)
                      </AiaText>
                      {uploadResult.learning_coverage.unresolved_rows.length || uploadResult.learning_coverage.skipped_rows.length ? (
                        <AiaText sx={{ mt: 0.5, fontSize: 11.5, color: "#B45309" }}>
                          {uploadResult.learning_coverage.unresolved_rows.length} unresolved row(s), {uploadResult.learning_coverage.skipped_rows.length} parser warning(s). These are not reported as learned.
                        </AiaText>
                      ) : null}
                    </AiaBox>
                  ) : null}
                  <AiaText sx={{ fontSize: 14, fontWeight: 600, color: "#0f172a" }}>
                    What would you like to do with this file?
                  </AiaText>
                  <AiaButton
                    variant="text"
                    onClick={handleContinueEditing}
                    sx={{ width: "100%", minWidth: 0, overflow: "hidden", textTransform: "none", display: "block", px: 2.25, py: 2, borderRadius: "14px", border: "1px solid #dbe2ea", textAlign: "left", "&:hover": { borderColor: "var(--aia-button-color)", bgcolor: "#fafbff" } }}
                  >
                    <AiaText sx={{ fontSize: 14, fontWeight: 700, color: "#0f172a" }}>
                      {(fixedTargetTable || uploadResult.parsed_summary?.target_table || uploadResult.parsed_summary?.target_tables?.[0])
                        ? "Continue Editing"
                        : "Continue to Target Selection"}
                    </AiaText>
                    <AiaText sx={{ display: "block", maxWidth: "100%", whiteSpace: "normal", overflowWrap: "anywhere", wordBreak: "break-word", fontSize: 12.5, lineHeight: 1.5, color: "#64748b", mt: 0.5 }}>
                      {(fixedTargetTable || uploadResult.parsed_summary?.target_table || uploadResult.parsed_summary?.target_tables?.[0])
                        ? "Auto-populate the mapping builder with parsed tables and columns from this file."
                        : "Keep the parsed sources, joins, CTE candidates, and columns, then choose the target table before mapping."}
                    </AiaText>
                  </AiaButton>
                  <AiaButton
                    variant="text"
                    onClick={handleUseAsLearning}
                    sx={{ width: "100%", minWidth: 0, overflow: "hidden", textTransform: "none", display: "block", px: 2.25, py: 2, borderRadius: "14px", border: "1px solid #dbe2ea", textAlign: "left", "&:hover": { borderColor: "var(--aia-button-color)", bgcolor: "#fafbff" } }}
                  >
                    <AiaText sx={{ fontSize: 14, fontWeight: 700, color: "#0f172a" }}>Submit for Offline Learning</AiaText>
                    <AiaText sx={{ display: "block", maxWidth: "100%", whiteSpace: "normal", overflowWrap: "anywhere", wordBreak: "break-word", fontSize: 12.5, lineHeight: 1.5, color: "#64748b", mt: 0.5 }}>FIR will combine this document with resolved table semantics and existing evidence before generating guidance.</AiaText>
                  </AiaButton>
                </AiaStack>
              )}
            </AiaBox>
          ) : (
          <AiaBox sx={{ px: 4, py: 3.5 }}>
            <AiaStack spacing={2}>
              {OPTIONS.map((option) => {
                const selected = selectedMode === option.id;

                return (
                  <AiaButton
                    key={option.id}
                    variant="text"
                    disabled={uploading}
                    onClick={() => setSelectedMode(option.id)}
                    data-tour={
                      option.id === "sql"
                        ? TOUR_TARGETS.newMappingSqlUpload
                        : option.id === "excel"
                          ? TOUR_TARGETS.newMappingExcelUpload
                          : TOUR_TARGETS.newMappingManual
                    }
                    sx={{
                      width: "100%",
                      textTransform: "none",
                      display: "block",
                      px: 0,
                      py: 0,
                      borderRadius: "18px",
                      border: selected
                        ? "1px solid var(--aia-button-color)"
                        : "1px solid #dbe2ea",
                      boxShadow: selected ? "none" : "0 2px 8px rgba(15, 23, 42, 0.06)",
                      backgroundColor: uploading ? "#f1f5f9" : "#fff",
                      opacity: uploading ? 0.6 : 1,
                      pointerEvents: uploading ? "none" : "auto",
                      cursor: uploading ? "not-allowed" : "pointer",
                      "&:hover": {
                        backgroundColor: uploading ? "#f1f5f9" : "#fff",
                        borderColor: uploading ? "#e2e8f0" : selected ? "var(--aia-button-color)" : "#cbd5e1",
                      },
                    }}
                  >
                    <AiaBox
                      sx={{
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 2,
                        px: 2.25,
                        py: 2.1,
                        textAlign: "left",
                        width: "100%",
                      }}
                    >
                      <AiaBox
                        sx={{
                          width: 54,
                          height: 54,
                          borderRadius: "16px",
                          border: "1px solid #e5e7eb",
                          backgroundColor: "#f8fafc",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        {option.icon}
                      </AiaBox>

                      <AiaBox sx={{ minWidth: 0, flex: 1, overflow: "hidden" }}>
                        <AiaStack
                          direction="row"
                          spacing={1}
                          useFlexGap
                          sx={{ alignItems: "center", flexWrap: "wrap" }}
                        >
                          <AiaText sx={{ fontSize: 15, fontWeight: 800, color: "#0f172a" }}>
                            {option.label}
                          </AiaText>
                          {option.badge ? (
                            <AiaBox
                              component="span"
                              sx={{
                                px: 1,
                                py: 0.35,
                                borderRadius: "999px",
                                backgroundColor: option.badgeBg,
                                color: option.badgeFg,
                                fontSize: 11,
                                fontWeight: 800,
                                letterSpacing: "0.02em",
                              }}
                            >
                              {option.badge}
                            </AiaBox>
                          ) : null}
                        </AiaStack>
                        <AiaText
                          sx={{
                            mt: 0.85,
                            fontSize: 13.5,
                            lineHeight: 1.55,
                            color: "#64748b",
                            display: "block",
                            overflowWrap: "anywhere",
                            wordBreak: "break-word",
                          }}
                        >
                          {option.description}
                        </AiaText>
                      </AiaBox>

                      <AiaBox
                        aria-hidden
                        sx={{
                          width: 26,
                          height: 26,
                          borderRadius: "50%",
                          border: selected
                            ? "7px solid var(--aia-button-color)"
                            : "2px solid #cbd5e1",
                          backgroundColor: selected ? "#fff" : "transparent",
                          boxShadow: selected ? "0 0 0 4px var(--aia-button-color)" : "none",
                          flexShrink: 0,
                          alignSelf: "center",
                          ml: 0.5,
                        }}
                      />
                    </AiaBox>
                  </AiaButton>
                );
              })}
              {(selectedMode === "sql" || selectedMode === "excel") && (
                <AiaBox sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" }, gap: 1.5, pt: 0.5 }}>
                  <AiaBox>
                    <AiaText sx={{ fontSize: 11, fontWeight: 700, color: "#64748B", mb: 0.75 }}>
                      SOURCE TABLES (optional)
                    </AiaText>
                    <AiaInput
                      value={sourceTableHints}
                      onChange={setSourceTableHints}
                      placeholder="e.g. DB.SCHEMA.CUSTOMERS, ORDERS"
                      disabled={uploading}
                      fullWidth
                    />
                  </AiaBox>
                  <AiaBox>
                    <AiaText sx={{ fontSize: 11, fontWeight: 700, color: "#64748B", mb: 0.75 }}>
                      TARGET TABLE (optional)
                    </AiaText>
                    <AiaInput
                      value={targetTableHint}
                      onChange={setTargetTableHint}
                      placeholder="e.g. DB.SCHEMA.CUSTOMER_360"
                      disabled={uploading}
                      fullWidth
                    />
                  </AiaBox>
                  <AiaText sx={{ gridColumn: { sm: "1 / -1" }, fontSize: 12, color: "#94A3B8" }}>
                    FIR discovers table references from the file first. Add hints only for aliases, unqualified names, or missing targets.
                  </AiaText>
                </AiaBox>
              )}
            </AiaStack>
          </AiaBox>
          )}

          {uploadRecoveryNotice && (
            <AiaBox role="status">
              <AiaText>{uploadRecoveryNotice}</AiaText>
              <AiaButton onClick={() => void checkSavedUpload()} disabled={uploading}>Check upload</AiaButton>
              <AiaButton disabled={uploading || !recoveryIdentity} onClick={() => {
                if (!recoveryIdentity) return;
                localStorage.removeItem(uploadRecoveryKey(selectedProjectId || projectId || 'default',existingSttmId || '',recoveryIdentity));
                setUploadResult(null); setUploadRecoveryNotice('');
              }}>Discard pending import</AiaButton>
            </AiaBox>
          )}
          {selectedMode && !uploadResult && (
            <AiaBox sx={{ px: 4, pb: selectedMode === "manual" ? 0 : 3 }}>
              <AiaText sx={{ fontSize: 11, fontWeight: 700, color: "#64748B", mb: 0.75 }}>
                PROJECT NAME
              </AiaText>
              <AiaSelect
                value={selectedProjectId}
                options={projectOptions}
                placeholder={isLoadingProjects ? "Loading projects..." : "Select a project"}
                disabled={uploading || (isLoadingProjects && projectOptions.length === 0)}
                onChange={(value) => setSelectedProjectId(
                  typeof value === "string" ? value : "",
                )}
              />
            </AiaBox>
          )}

          {selectedMode === "manual" && !uploadResult && (
            <AiaBox
              sx={{
                px: 4,
                pb: 3,
                pt: 2,
                display: "flex",
                flexDirection: "column",
                gap: 2,
              }}
            >
              <AiaInput
                label="Mapping Name"
                value={mappingName}
                onChange={setMappingName}
                placeholder="e.g. Customer Orders → DW_ORDERS"
                disabled={uploading}
                fullWidth
              />
              <AiaInput
                label="Mapping Description"
                value={mappingDescription}
                onChange={setMappingDescription}
                placeholder="Briefly describe the purpose of this mapping"
                disabled={uploading}
                multiline
                minRows={2}
                maxRows={4}
                fullWidth
              />
              {precedentMappings.length ? (
                <AiaBox>
                  <AiaText sx={{ fontSize: 11, fontWeight: 700, color: '#64748B', mb: 0.75 }}>
                    REUSE PRECEDENT MAPPINGS (optional)
                  </AiaText>
                  <AiaSelect
                    multiple
                    value={linkedMappingIds}
                    options={precedentMappings.map((mapping) => ({
                      value: mapping.id,
                      label: `${mapping.name} · ${mapping.projectName}`,
                    }))}
                    placeholder="Select precedent mappings"
                    disabled={uploading}
                    onChange={(value) => setLinkedMappingIds(Array.isArray(value) ? value : [])}
                  />
                  <AiaText sx={{ mt: 0.75, fontSize: 11, color: '#94A3B8', lineHeight: 1.45 }}>
                    These precedents are retrieved before fuzzy search and are passed to source mapping, transformation, and builder agents.
                  </AiaText>
                </AiaBox>
              ) : (
                <AiaBox
                  sx={{
                    border: "1px solid #e2e8f0",
                    borderRadius: "8px",
                    bgcolor: "#f8fafc",
                    px: 1.5,
                    py: 1.25,
                  }}
                >
                  <AiaText sx={{ fontSize: 11, fontWeight: 700, color: "#64748B" }}>
                    REUSE PRECEDENT MAPPINGS
                  </AiaText>
                  <AiaText sx={{ mt: 0.6, fontSize: 11.5, color: "#64748b", lineHeight: 1.45 }}>
                    No published mappings are available to link explicitly. FIR knowledge learned from scripts and documents is still retrieved automatically. Import and publish a mapping to make it selectable here.
                  </AiaText>
                </AiaBox>
              )}
            </AiaBox>
          )}

          {!uploadResult && (
          <AiaBox
            sx={{
              px: 4,
              py: 2.25,
              borderTop: "1px solid #edf2f7",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 2,
              backgroundColor: "#fff",
            }}
          >
            <AiaText
              sx={{
                fontSize: 13.5,
                color: "#94a3b8",
                fontWeight: 500,
                flex: 1,
                minWidth: 0,
                pr: 2,
                overflowWrap: "anywhere",
                wordBreak: "break-word",
              }}
            >
              {selectedOption
                ? selectedOption.description
                : "Select an option above to continue"}
            </AiaText>

            <AiaStack direction="row" spacing={1.25} sx={{ flexShrink: 0 }}>
              <AiaButton
                variant="outlined"
                rounded="lg"
                size="medium"
                onClick={handleClose}
                data-tour={TOUR_TARGETS.newMappingCancel}
                sx={{
                  minWidth: 108,
                  height: 44,
                  borderRadius: "14px",
                  color: "#334155",
                  borderColor: "#dbe2ea",
                  fontSize: 14,
                  fontWeight: 700,
                }}
              >
                Cancel
              </AiaButton>
              <AiaButton
                variant="contained"
                color="primary"
                rounded="lg"
                size="medium"
                endIcon={<ArrowForwardRoundedIcon sx={{ fontSize: 16 }} />}
                disabled={
                  uploading ||
                  !selectedMode ||
                  !selectedProjectId.trim() ||
                  (selectedMode === "manual" && !canSubmitManual)
                }
                onClick={handleProceed}
                sx={{
                  minWidth: 156,
                  height: 44,
                  borderRadius: "14px",
                  fontSize: 14,
                  fontWeight: 800,
                }}
              >
                {uploading
                  ? "Uploading…"
                  : selectedMode === "manual"
                    ? "Build Mapping"
                    : "Choose File"}
              </AiaButton>
            </AiaStack>
          </AiaBox>
          )}
          </AiaBox>
        </AiaBox>
      </AiaBox>

      <input
        ref={sqlInputRef}
        type="file"
        accept=".sql,text/sql,application/sql"
        hidden
        onChange={(e) => handleFileUpload(e, "sql")}
      />
      <input
        ref={excelInputRef}
        type="file"
        accept=".xlsx,.xls,.csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
        hidden
        onChange={(e) => handleFileUpload(e, "excel")}
      />
    </>
  );
}
