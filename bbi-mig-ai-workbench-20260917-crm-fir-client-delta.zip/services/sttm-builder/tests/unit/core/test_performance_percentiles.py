from app.core import performance


def test_performance_snapshot_reports_bounded_percentiles() -> None:
    metric = "test.percentiles"
    for value in range(1, 101):
        performance.observe(metric, float(value))

    result = performance.snapshot()["durations"][metric]

    assert result["p50_ms"] == 50.0
    assert result["p95_ms"] == 95.0
    assert result["p99_ms"] == 99.0
    assert result["sample_count"] == 100
