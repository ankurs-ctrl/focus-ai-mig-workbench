import asyncio
import json
from types import SimpleNamespace

from app.core.config import Settings
from app.core.sttm_builder import STTMBuilderService
from app.schema.semantic_context import SemanticBundleStatus, SemanticContextSummary, SemanticLevel
from app.schema.sttm_builder import (
    Interface,
    STTMAgentRequestEnvelope,
    STTMBuilderEnvelopeRequest,
    STTMBuilderResponse,
    STTMOperation,
    STTMStatus,
    SubAgent,
    normalize_sttm_builder_invoke_body,
)
from app.schema.sttm_builder import STTMArtifactType
from app.schema.workspace_context import WorkspaceBrowsingContext


def _table(name: str = "SRC") -> dict:
    return {"database": "DB", "schema": "SCH", "table": name}


def test_browsing_context_normalizes_candidate_table_objects_to_fqns() -> None:
    context = WorkspaceBrowsingContext.model_validate(
        {
            "side": "source",
            "database": "DB",
            "schema": "SCH",
            "visible_candidate_tables": [
                {"database": "DB", "schema": "SCH", "table": "CUSTOMER"},
                {
                    "database_name": "DB",
                    "schema_name": "SCH",
                    "table_name": "NOTE",
                },
                {"qualifiedName": "DB.SCH.LOAN"},
                "DB.SCH.CUSTOMER",
            ],
        }
    )

    assert context.visible_candidate_tables == [
        "DB.SCH.CUSTOMER",
        "DB.SCH.LOAN",
        "DB.SCH.NOTE",
    ]


def test_legacy_workbench_payload_normalizes_to_standard_envelope() -> None:
    envelope = normalize_sttm_builder_invoke_body(
        {
            "interface": "AUTO_MAP",
            "thread_id": "thread-1",
            "source_tables": [_table("SRC")],
            "attributes": [
                {
                    "target_table": _table("TGT"),
                    "target_attribute": "CUSTOMER_ID",
                    "source_mappings": None,
                }
            ],
        }
    )

    assert envelope.contract_version == "1.0"
    assert envelope.operation == STTMOperation.AUTO_MAP
    assert envelope.context.thread_id == "thread-1"
    assert envelope.data.intent == Interface.AUTO_MAP
    assert envelope.warnings[0].code == "LEGACY_PAYLOAD"


def test_standard_envelope_requires_operation_to_match_intent() -> None:
    envelope = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "operation": "sttm.chat",
            "context": {},
            "data": {"intent": "CHAT", "message": "hello"},
            "warnings": [],
            "error": None,
            "meta": {},
        }
    )

    assert envelope.operation == STTMOperation.CHAT
    assert envelope.to_flat_request().interface == Interface.CHAT


def test_chat_envelope_normalizes_empty_source_tables_to_none() -> None:
    envelope = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "operation": "sttm.chat",
            "context": {
                "thread_id": None,
                "source_tables": [],
                "driving_table": None,
                "relationships": [],
                "semantic_context": None,
                "selected_columns_by_table": None,
            },
            "data": {"intent": "CHAT", "message": "hello"},
            "warnings": [],
            "error": None,
            "meta": {},
        }
    )

    assert envelope.context.source_tables is None
    assert envelope.to_flat_request().source_tables is None


def test_workspace_snapshot_hydrates_legacy_context_and_reaches_agent() -> None:
    envelope = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "operation": "sttm.chat",
            "context": {
                "workspace_context": {
                    "context_version": "1.0",
                    "context_hash": "ctx1-test",
                    "captured_at": "2026-06-23T00:00:00Z",
                    "page": "mapping",
                    "surface": "MAPPING",
                    "source_tables": [_table("SRC")],
                    "target_table": _table("TGT"),
                    "selected_columns_by_table": {"DB.SCH.SRC": ["COL_A"]},
                    "derived_sources": [],
                    "relationships": [],
                    "filters": {"groups": []},
                    "mapping_intent": {"business_goal": "Map customer data"},
                    "mapping_rows": [],
                    "checked_mapping_row_ids": [],
                    "semantic": {"asset_versions": {}},
                }
            },
            "data": {"intent": "CHAT", "message": "hello"},
        }
    )

    assert envelope.context.source_tables is not None
    assert envelope.context.source_tables[0].table == "SRC"
    assert envelope.context.mapping_intent == {"business_goal": "Map customer data"}
    agent = STTMAgentRequestEnvelope.from_builder_request(envelope)
    assert agent.context.workspace_context is not None
    assert agent.context.workspace_context.context_hash == "ctx1-test"


def test_v2_snapshot_generates_exact_context_and_survives_subagent_conversion() -> None:
    envelope = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "request_id": "req-v2",
            "operation": "sttm.auto_map",
            "context": {
                "project_id": "project-1",
                "sttm_id": "sttm-1",
                "learning_context": {
                    "used_inference_ids": ["inf-1"],
                    "used_recommendation_ids": ["rec-1"],
                },
                "workspace_context": {
                    "context_version": "2.0",
                    "captured_at": "2026-07-14T00:00:00Z",
                    "page": "mapping",
                    "surface": "MAPPING",
                    "action": "auto_map.requested",
                    "milestone": "before_auto_map",
                    "project_id": "project-1",
                    "sttm_id": "sttm-1",
                    "mapping_lifecycle": "update",
                    "source_tables": [_table("SRC")],
                    "target_table": _table("TGT"),
                    "selected_columns_by_table": {"DB.SCH.SRC": ["CUSTOMER_ID"]},
                    "derived_sources": [],
                    "relationships": [],
                    "filters": {"groups": []},
                    "mapping_rows": [],
                    "checked_mapping_row_ids": [],
                    "semantic": {"bundle_id": "sem-1", "asset_versions": {}},
                },
            },
            "data": {
                "intent": "AUTO_MAP",
                "attributes": [
                    {
                        "target_table": _table("TGT"),
                        "target_attribute": "CUSTOMER_ID",
                    }
                ],
            },
        }
    )

    workspace = envelope.context.workspace_context
    assert workspace is not None
    assert workspace.context_key.startswith("ctx_")
    assert workspace.source_set_hash
    agent = STTMAgentRequestEnvelope.from_builder_request(envelope)
    assert agent.context.project_id == "project-1"
    assert agent.context.sttm_id == "sttm-1"
    assert agent.context.learning_context is not None
    assert agent.context.learning_context.used_recommendation_ids == ["rec-1"]
    assert agent.context.workspace_context is not None
    assert agent.context.workspace_context.context_key == workspace.context_key


def test_with_semantic_context_updates_workspace_snapshot_from_pydantic_summary() -> None:
    service = STTMBuilderService.__new__(STTMBuilderService)
    summary = SemanticContextSummary(
        bundle_id="sem_1",
        bundle_hash="bundle-hash",
        bundle_label="source to target",
        source_table_count=1,
        derived_source_count=0,
        relationship_count=0,
        semantic_level=SemanticLevel.L2_ANALYST_READY,
        asset_versions={"DB.SCH.SRC": "v1"},
        composed_model_hash="model-hash",
    )

    class _SemanticContextService:
        def refresh_bundle(self, *_args, **_kwargs):
            return SimpleNamespace(
                semantic_context=[],
                semantic_view_name=None,
                bundle_id="sem_1",
                bundle_hash="bundle-hash",
                bundle_label="source to target",
                achieved_level=SemanticLevel.L2_ANALYST_READY,
                requested_level=SemanticLevel.L2_ANALYST_READY,
                status=SemanticBundleStatus.READY,
                promoted=False,
                cache_hit=True,
                summary=summary,
                lineage=[],
                datahub_context=None,
            )

    service._semantic_context_service = _SemanticContextService()
    envelope = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "operation": "sttm.chat",
            "context": {
                "source_tables": [_table("SRC")],
                "workspace_context": {
                    "context_version": "1.0",
                    "context_hash": "ctx1-test",
                    "captured_at": "2026-06-23T00:00:00Z",
                    "page": "builder",
                    "surface": "SOURCE_SELECTION",
                    "source_tables": [_table("SRC")],
                    "selected_columns_by_table": {"DB.SCH.SRC": ["COL_A"]},
                    "derived_sources": [],
                    "relationships": [],
                    "filters": {"groups": []},
                    "mapping_rows": [],
                    "checked_mapping_row_ids": [],
                    "semantic": {"asset_versions": {}},
                },
            },
            "data": {"intent": "CHAT", "message": "hello"},
        }
    )

    updated, refresh = service._with_semantic_context(envelope)

    assert refresh is not None
    assert updated.context.workspace_context is not None
    assert updated.context.workspace_context.semantic.composed_model_hash == "model-hash"
    assert updated.context.workspace_context.semantic.asset_versions == {"DB.SCH.SRC": "v1"}


def test_agent_request_omits_transport_only_fields() -> None:
    envelope = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "request_id": "req-1",
            "operation": "sttm.chat",
            "actor": {"user_id": "u1", "role": "admin"},
            "context": {
                "thread_id": "thread-1",
                "source_tables": [_table("SRC")],
                "relationships": [],
            },
            "data": {"intent": "CHAT", "message": "hello"},
            "warnings": [{"code": "LEGACY", "message": "legacy"}],
            "error": None,
            "meta": {"trace": "t1"},
        }
    )

    agent_request = STTMAgentRequestEnvelope.from_builder_request(envelope)
    dumped = agent_request.model_dump(mode="json", exclude_none=True)

    assert dumped["request_id"] == "req-1"
    assert dumped["operation"] == "sttm.chat"
    assert "thread_id" not in dumped["context"]
    assert "actor" not in dumped
    assert "warnings" not in dumped
    assert "meta" not in dumped


def test_canonical_agent_response_parses_to_typed_mapping_result() -> None:
    service = STTMBuilderService.__new__(STTMBuilderService)
    raw = json.dumps(
        {
            "contract_version": "1.0",
            "request_id": "req-1",
            "operation": "sttm.auto_map",
            "context": {},
            "data": {
                "intent": "AUTO_MAP",
                "status": "completed",
                "agent": "SOURCE_MAPPING_AGENT",
                "result": {
                    "mappings": {
                        "DB.SCH.TGT.CUSTOMER_ID": {
                            "source_attributes": ["DB.SCH.SRC.CUST_ID"],
                            "confidence_score": 0.92,
                            "confidence_reason": "Column names and semantic descriptions align.",
                            "candidate_source_attributes": ["DB.SCH.SRC.CUSTOMER_KEY"],
                            "preprocessing_rule": "Direct",
                            "preprocessing_rule_type": "Direct",
                            "preprocessing_nl_rule": "Use the source value directly.",
                            "processing_order": 1,
                            "description": "Customer identifier copied from the source record.",
                        }
                    }
                },
                "message": "Mapped one column.",
            },
            "warnings": [],
            "error": None,
            "meta": {"orchestration_model": "claude-haiku-4-5"},
        }
    )

    agent, result, message, warnings, error, meta, status, *_ = service._parse_envelope(raw)

    assert agent == SubAgent.SOURCE_MAPPING_AGENT
    assert result is not None
    mapping = result.mappings["DB.SCH.TGT.CUSTOMER_ID"]
    assert mapping.confidence_score == 0.92
    assert mapping.confidence_reason == "Column names and semantic descriptions align."
    assert mapping.candidate_source_attributes == ["DB.SCH.SRC.CUSTOMER_KEY"]
    assert mapping.preprocessing_rule == "Direct"
    assert mapping.preprocessing_nl_rule == "Use the source value directly."
    assert mapping.processing_order == 1
    assert message == "Mapped one column."
    assert warnings == []
    assert error is None
    assert meta["orchestration_model"] == "claude-haiku-4-5"
    assert status == STTMStatus.COMPLETED


def test_agent_meta_merge_accepts_extra_routing_meta_for_direct_analyst_path() -> None:
    merged = STTMBuilderService._merge_agent_meta(
        {"existing": True},
        {"routing": {"bypassed_agent_orchestrator": True}},
        raw_payload={"status": "completed", "schema_version": "1.0", "sequence_number": 1},
        artifact_type=STTMArtifactType.ANALYST_ANSWER,
        artifact={"query_id": "01abc", "semantic_sql_used": True},
    )

    assert merged["existing"] is True
    assert merged["routing"]["bypassed_agent_orchestrator"] is True
    assert merged["agent_run"]["status"] == "completed"
    assert merged["analyst"]["query_id"] == "01abc"


def test_auto_map_worker_invokes_source_mapping_agent_once_per_batch() -> None:
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._settings = Settings(_env_file=None, AUTO_MAPPING_WORKER_MAX_CONCURRENCY=5)
    calls: list[int] = []
    req = STTMBuilderEnvelopeRequest.model_validate(
        {
            "contract_version": "1.0",
            "request_id": "req-auto-1",
            "operation": "sttm.auto_map",
            "context": {
                "source_tables": [_table("SRC")],
                "target_table": _table("TGT"),
            },
            "data": {
                "intent": "AUTO_MAP",
                "attributes": [
                    {
                        "target_table": _table("TGT"),
                        "target_attribute": "COL_A",
                    },
                    {
                        "target_table": _table("TGT"),
                        "target_attribute": "COL_B",
                    },
                ],
            },
        }
    )

    def fake_invoke(
        request: STTMBuilderEnvelopeRequest,
        *,
        governance_decision=None,  # type: ignore[no-untyped-def]
    ) -> STTMBuilderResponse:
        calls.append(len(request.data.attributes or []))
        return STTMBuilderResponse.from_invocation(
            request,
            thread_id="thread-1",
            parent_message_id=None,
            agent=SubAgent.SOURCE_MAPPING_AGENT,
            result=None,
            message="ok",
            status=STTMStatus.COMPLETED,
            meta={},
        )

    service.invoke = fake_invoke  # type: ignore[method-assign]

    response = asyncio.run(service.invoke_auto_map_parallel(req))

    assert calls == [2]
    assert response.meta["auto_mapping_worker"]["batch_strategy"] == "single_agent_batch_call"


def test_legacy_agent_mapping_array_is_normalized_temporarily() -> None:
    service = STTMBuilderService.__new__(STTMBuilderService)
    raw = json.dumps(
        {
            "agent": "AGT_SOURCE_MAPPING",
            "result": {
                "mappings": [
                    {
                        "target": "DB.SCH.TGT.CUSTOMER_ID",
                        "sources": [
                            {
                                "table": "DB.SCH.SRC",
                                "column": "CUST_ID",
                                "confidence": "HIGH",
                            }
                        ],
                        "candidates": [{"table": "DB.SCH.SRC", "column": "CUSTOMER_KEY"}],
                        "reason": "Best semantic match for the customer identifier.",
                        "processing_order": "2",
                    }
                ]
            },
        }
    )

    agent, result, *_ = service._parse_envelope(raw)

    assert agent == SubAgent.SOURCE_MAPPING_AGENT
    assert result is not None
    mapping = result.mappings["DB.SCH.TGT.CUSTOMER_ID"]
    assert mapping.source_attributes == ["DB.SCH.SRC.CUST_ID"]
    assert mapping.confidence_score == 0.9
    assert mapping.candidate_source_attributes == ["DB.SCH.SRC.CUSTOMER_KEY"]
    assert mapping.confidence_reason == "Best semantic match for the customer identifier."
    assert mapping.processing_order == 2


def test_chat_response_unwraps_structured_envelope_embedded_in_message() -> None:
    service = STTMBuilderService.__new__(STTMBuilderService)
    nested = {
        "contract_version": "1.0",
        "request_id": "req-transform-1",
        "operation": "sttm.transform",
        "context": {},
        "data": {
            "intent": "TRANSFORM",
            "status": "completed",
            "agent": "TRANSFORMATION_AGENT",
            "result": {
                "rules": [
                    {
                        "target_attribute": "DB.SCH.TGT.NOTE_ID",
                        "rule": "TRY_CAST(DB.SCH.SRC.VERIFIED_INCOME_ID AS NUMBER(20,0))",
                        "description": "Casts the UUID-shaped source into a numeric target with TRY_CAST.",
                    }
                ]
            },
            "message": "Generated transformation rule for NOTE_ID.",
            "artifact_type": "transformation_rules",
            "artifact": {
                "sql_text": "TRY_CAST(DB.SCH.SRC.VERIFIED_INCOME_ID AS NUMBER(20,0))",
            },
            "semantic_level_achieved": "L3_MAPPING_ENRICHED",
        },
        "warnings": [],
        "error": None,
        "meta": {"routed_by": "AGT_STTM_BUILDER"},
    }
    outer = json.dumps(
        {
            "contract_version": "1.0",
            "request_id": "req-chat-1",
            "operation": "sttm.chat",
            "context": {},
            "data": {
                "intent": "CHAT",
                "status": "completed",
                "agent": None,
                "result": None,
                "message": f"```json\n{json.dumps(nested, indent=2)}\n```",
                "artifact_type": "none",
                "artifact": None,
            },
            "warnings": [],
            "error": None,
            "meta": {"orchestration_model": "claude-sonnet-4-6"},
        }
    )

    agent, result, message, warnings, error, meta, status, artifact_type, artifact, *_ = (
        service._parse_chat_response(outer)
    )

    assert agent == SubAgent.TRANSFORMATION_AGENT
    assert result is not None
    assert result.rules[0].target_attribute == "DB.SCH.TGT.NOTE_ID"
    assert result.rules[0].rule == "TRY_CAST(DB.SCH.SRC.VERIFIED_INCOME_ID AS NUMBER(20,0))"
    assert message == "Generated transformation rule for NOTE_ID."
    assert warnings == []
    assert error is None
    assert meta["orchestration_model"] == "claude-sonnet-4-6"
    assert meta["routed_by"] == "AGT_STTM_BUILDER"
    assert status == STTMStatus.COMPLETED
    assert artifact_type is not None and artifact_type.value == "transformation_rules"
    assert artifact == {"sql_text": "TRY_CAST(DB.SCH.SRC.VERIFIED_INCOME_ID AS NUMBER(20,0))"}
