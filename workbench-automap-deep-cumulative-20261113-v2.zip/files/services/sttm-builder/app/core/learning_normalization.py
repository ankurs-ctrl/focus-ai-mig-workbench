"""Lossless classification metadata for existing FIR learnings; no approval promotion."""
from __future__ import annotations
import hashlib
import json
from typing import Any
from app.core.learning_subjects import target_column_subject

STRUCTURED_FIELDS = (
    'target_table','target_column','source_tables','source_columns','correct_source',
    'preprocessing_rule','preprocessing_rule_type','expression','constant_value',
    'relationships','dependencies','provenance','approval_status','contract_version','semantic_version',
    'left_table','right_table','join_type','join_condition','condition','join_keys',
    'cte_name','cte_sql','sql','sql_text','base_tables','tables_referenced','purpose','lineage',
    'grain','filters','exclusions','execution_order','artifact_contract','business_rule',
)


def normalize_legacy_learning(row: dict[str, Any]) -> dict:
    raw=row.get('ATTRIBUTES') or {}
    attributes=json.loads(raw) if isinstance(raw,str) else dict(raw)
    kind=str(row.get('LEARNING_TYPE') or 'evidence')
    target=str(attributes.get('target_table') or '')
    column=str(attributes.get('target_column') or '')
    subject=row.get('SUBJECT_KEY')
    if not subject and target and column:
        subject=target_column_subject(target,column)
    if not subject:
        scope=target.upper() or str(row.get('LEARNING_KEY') or row.get('LEARNING_ID') or '')
        fingerprint=hashlib.sha256(json.dumps(attributes,sort_keys=True,default=str).encode()).hexdigest()
        subject=f'{kind}:{scope}:{fingerprint}'
    evidence=row.get('EVIDENCE_IDS') or []
    if isinstance(evidence,str): evidence=json.loads(evidence)
    return {'learning_id':str(row.get('LEARNING_ID') or ''),
            'subject_type':row.get('SUBJECT_TYPE') or kind,'subject_key':subject,
            'claim_key':row.get('CLAIM_KEY') or kind,'summary':row.get('SUMMARY') or '',
            'confidence':float(row.get('CONFIDENCE') or 0),'trust_stage':row.get('TRUST_STAGE') or 'evidence',
            'evidence_ids':evidence,'structured_rule':{key:attributes[key] for key in STRUCTURED_FIELDS if key in attributes}}
