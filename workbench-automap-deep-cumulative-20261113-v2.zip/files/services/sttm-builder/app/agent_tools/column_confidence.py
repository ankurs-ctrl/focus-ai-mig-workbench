"""Evidence-based confidence for one target-column mapping decision.

A specialist's self-reported score is only one signal. A mapping is more
credible when independent evidence proposes the same lineage: a historical
precedent mapping of the same target column, a governed learning, or stored
semantic knowledge. It is less credible when that evidence names different
source columns, or when a direct mapping moves a value between incompatible
type families.

Lineage is compared by (table name, column name) so a precedent recorded on
another client's copy of the same source system still counts. Evidence of one
kind is counted once (its strongest item), then combined by noisy-OR.
"""
from __future__ import annotations

import json
import re
from typing import Any, Iterable

# Weight per evidence kind, overridable with MIGRATION_AGENT_COLUMN_EVIDENCE_WEIGHTS_JSON.
DEFAULT_WEIGHTS: dict[str, float] = {
    # Upper bound on the specialist's own score: it cannot certify itself.
    "specialist": 0.7,
    # Many historical projects are unfinished experiments; an approved or
    # published one is much stronger evidence.
    "historical_precedent": 0.6,
    "approved_precedent": 0.85,
    "fir_learning": 0.8,
    "semantic": 0.6,
    # A spec, notes or SQL the user attached for this migration: strong, but
    # the catalog and data checks still decide what exists and joins.
    "attachment": 0.75,
    # Unapproved learnings and other leads: enough to offer, not to accept.
    "unverified": 0.3,
    # Multipliers.
    "conflict_penalty": 0.5,
    "type_mismatch_penalty": 0.6,
}

_SEMANTIC_SOURCES = {"workbench_semantic_registry", "workbench_semantic_knowledge_resolver"}
_APPROVED = {"approved", "published", "validated", "outcome", "complete"}


def weights_from_settings(settings: Any) -> dict[str, float]:
    raw = getattr(settings, "migration_agent_column_evidence_weights_json", "") if settings is not None else ""
    weights = dict(DEFAULT_WEIGHTS)
    if raw:
        try:
            supplied = json.loads(raw)
        except (TypeError, ValueError):
            supplied = {}
        for key, value in dict(supplied or {}).items():
            if key in weights:
                weights[key] = min(1.0, max(0.0, float(value)))
    return weights


def _name(value: str) -> str:
    """Identifier compared across client copies regardless of separator style (TARGET_CRM_ID == TARGETCRMID)."""
    return re.sub(r"[^A-Z0-9]", "", value.upper())


def _lineage(values: Iterable[Any]) -> set[tuple[str, str]]:
    pairs = set()
    for value in values or []:
        parts = [part.strip().strip('"').upper() for part in str(value or "").split(".") if part.strip()]
        if len(parts) >= 2:
            pairs.add((_name(parts[-2]), _name(parts[-1])))
        elif parts:
            pairs.add(("", _name(parts[-1])))
    return pairs


def _matches(row: set[tuple[str, str]], evidence: set[tuple[str, str]]) -> bool:
    """Same lineage: most of the combined columns are shared (unqualified evidence matches by column)."""
    if not row or not evidence:
        return False
    def same(a: tuple[str, str], b: tuple[str, str]) -> bool:
        return a[1] == b[1] and (not a[0] or not b[0] or a[0] == b[0])
    shared = sum(1 for item in evidence if any(same(item, other) for other in row))
    return shared / len(row | evidence) >= 0.5 or shared == len(evidence) == len(row)


def _kind(item: dict[str, Any]) -> str | None:
    source = str(item.get("evidence_source") or "")
    approval = str(item.get("approval_state") or "").lower()
    if source == "historical_precedent":
        return "approved_precedent" if approval in _APPROVED else "historical_precedent"
    if source == "fir_learning":
        return "fir_learning" if approval in _APPROVED else "unverified"
    if source in _SEMANTIC_SOURCES:
        return "semantic"
    if source == "attachment":
        return "attachment"
    return "unverified" if source else None


def type_family(data_type: str) -> str:
    value = str(data_type or "").upper()
    if value.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT", "BIGINT", "SMALLINT", "FLOAT", "DOUBLE", "REAL")):
        return "number"
    if value.startswith(("DATE", "TIMESTAMP", "TIME")):
        return "datetime"
    if value.startswith("BOOLEAN"):
        return "boolean"
    if value.startswith(("VARCHAR", "TEXT", "STRING", "CHAR")):
        return "text"
    return value.split("(", 1)[0] or ""


def candidate_confidence(
    target_column: str,
    source_columns: list[str],
    item: dict[str, Any],
    evidence: list[dict[str, Any]],
    weights: dict[str, float] | None = None,
) -> float:
    """Support for an evidence-proposed candidate: every evidence kind proposing the same lineage.

    A constant candidate has no lineage to corroborate and scores its own
    evidence kind's weight.
    """
    weights = weights or DEFAULT_WEIGHTS
    if item.get("confidence") not in (None, ""):
        return min(1.0, max(0.0, float(item["confidence"])))
    if not source_columns:
        return weights.get(_kind(item) or "", 0.0)
    return score_column({"target_column": target_column, "source_columns": source_columns, "confidence": 0.0},
                        evidence, weights=weights)["confidence"]


def score_column(
    row: dict[str, Any],
    evidence: list[dict[str, Any]],
    *,
    target_type: str = "",
    source_types: dict[str, str] | None = None,
    weights: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Confidence and its reasons for one saved mapping row."""
    weights = weights or DEFAULT_WEIGHTS
    lineage = _lineage(row.get("source_columns") or [])
    expression = str(row.get("expression") or "").strip()
    agreeing: dict[str, dict[str, Any]] = {}
    conflicting: list[dict[str, Any]] = []
    for item in evidence:
        if _name(str(item.get("target_column") or "")) != _name(str(row.get("target_column") or "")):
            continue
        kind = _kind(item)
        if kind is None:
            continue
        item_lineage = _lineage(item.get("source_columns") or [])
        if not item_lineage:
            continue  # constant or placeholder evidence says nothing about lineage
        if _matches(lineage, item_lineage):
            agreeing.setdefault(kind, item)
        else:
            conflicting.append(item)
    specialist = min(max(float(row.get("confidence") or 0.0), 0.0), 1.0) * weights["specialist"]
    doubt = 1.0 - specialist
    for kind in agreeing:
        doubt *= 1.0 - weights.get(kind, 0.0)
    confidence = 1.0 - doubt
    reasons = [f"specialist {float(row.get('confidence') or 0):.0%}"]
    if agreeing:
        reasons.append("same lineage in " + ", ".join(sorted(kind.replace("_", " ") for kind in agreeing)))
    if conflicting and not agreeing:
        # Scaled by the strongest disagreeing evidence: an unverified lead
        # barely matters, an approved precedent matters a lot.
        strongest = max(weights.get(_kind(item) or "", 0.0) for item in conflicting)
        confidence *= 1.0 - (1.0 - weights["conflict_penalty"]) * strongest
        leads = sorted({".".join(str(value).strip('"').upper().split(".")[-2:])
                        for item in conflicting for value in item.get("source_columns") or []})[:3]
        reasons.append(f"earlier evidence maps it from {', '.join(leads)} instead")
    if not expression and len(lineage) == 1 and target_type and source_types:
        source = next(iter(row.get("source_columns") or []), "")
        source_family = type_family(source_types.get(str(source).upper(), ""))
        target_family = type_family(target_type)
        if source_family and target_family and source_family != target_family and target_family != "text":
            confidence *= weights["type_mismatch_penalty"]
            reasons.append(f"direct {source_family} value into a {target_family} column")
    return {
        "confidence": round(confidence, 4),
        "reasons": reasons,
        "agreeing_evidence_ids": sorted({str(item.get("evidence_id")) for item in agreeing.values() if item.get("evidence_id")}),
        "conflicting_evidence_ids": sorted({str(item.get("evidence_id")) for item in conflicting if item.get("evidence_id")}),
    }
