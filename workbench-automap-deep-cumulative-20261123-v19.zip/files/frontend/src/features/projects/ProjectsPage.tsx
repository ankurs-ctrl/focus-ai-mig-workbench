"use client";
/* eslint-disable react-hooks/set-state-in-effect -- Project loading state follows the remote request lifecycle. */
import { AiaBox, AiaLoadingOverlay } from '@/components/ui';

import { useEffect, useMemo, useState } from "react";

import { useRouter } from "next/navigation";
import NewProjectModal from "./new-project-modal";
import ProjectCard from "./project-card";
import ProjectsHeader from "./ProjectsHeader";
import ProjectsSummaryFooter from "./projects-summary-footer";
import { type ProjectItem } from "./projects-data";
import { buildProjectsSummary } from "./project-utils";
import { PROJECT_CARD_WIDTH } from "./projects-ui-styles";
import { PROJECT_COLOR_OPTIONS } from "./project-color-options";
import {
  createProjectFromTemplate,
  invalidateProjectSummaries,
  getAllProjectsSummary,
  subscribeProjectMetadata,
  getCachedProjectsSummary,
  projectRecordToItem,
} from "@/services/projectService";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";

export default function ProjectsPage() {
  const router = useRouter();
  const [initialSummary] = useState(() => getCachedProjectsSummary());
  const [projects, setProjects] = useState<ProjectItem[]>(() =>
    (initialSummary?.projects ?? []).map(projectRecordToItem),
  );
  const [isLoadingProjects, setIsLoadingProjects] = useState(!initialSummary);
  const [isNewProjectOpen, setIsNewProjectOpen] = useState(false);

  const summary = useMemo(() => buildProjectsSummary(projects), [projects]);

  useEffect(() => {
    let cancelled = false;
    setIsLoadingProjects(!initialSummary);

    const unsubscribe = subscribeProjectMetadata(() => {
      const summary = getCachedProjectsSummary();
      if (!cancelled && summary) setProjects(summary.projects.map(projectRecordToItem));
    });
    getAllProjectsSummary()
      .then(({ projects: records }) => {
        if (cancelled) {
          return;
        }
        setProjects(records.map(projectRecordToItem));
      })
      .catch((error) => {
        if (process.env.NODE_ENV === "development") {
          console.warn("Project metadata is unavailable; showing no saved projects.", error);
        }
        if (!cancelled) {
          setProjects([]);
        }
      })
      .finally(() => {
        if (!cancelled) setIsLoadingProjects(false);
      });

    return () => {
      cancelled = true; unsubscribe();
    };
  }, [initialSummary]);

  const handleCreateProject = async (project: ProjectItem) => {
    const color = PROJECT_COLOR_OPTIONS.find((option) => option.color === project.themeColor);

    try {
      const result = await createProjectFromTemplate({
        project_name: project.name,
        description: project.description,
        theme_color_id: color?.id,
        domain: project.domain,
        intended_outcome: project.intendedOutcome,
        business_process: project.businessProcess,
        owner: project.owner,
        linked_project_ids: project.linkedProjectIds,
        template_id: project.projectTemplateId || "CRM_MIGRATION",
        source_system_key: project.sourceSystemKey || "OTHER",
        bootstrap_mode: project.bootstrapMode || "AUTO",
        selected_target_tables: project.selectedTargetTables,
        idempotency_key: project.bootstrapIdempotencyKey || `project-${Date.now()}`,
      });
      setProjects((current) => [projectRecordToItem(result.project), ...current]);
      router.push(`/mappings?project=${encodeURIComponent(result.project.project_id)}`);
    } catch (error) {
      invalidateProjectSummaries();
      void getAllProjectsSummary(true).then(result=>setProjects(result.projects.map(projectRecordToItem))).catch(()=>{});
      if (process.env.NODE_ENV === "development") {
        console.warn("Project creation response failed; retry the retained request to recover its committed result.", error);
      }
      throw error;
    }
  };

  return (
    <>
      <AiaBox
        sx={{
          display: "flex",
          position: "relative",
          flex: 1,
          minHeight: 0,
          flexDirection: "column",
          overflow: "hidden",
          bgcolor: "#F7F8FA",
        }}
      >
        <AiaBox
          sx={{
            flex: 1,
            minHeight: 0,
            overflowY: "auto",
            px: { xs: 2.5, md: 3.5 },
            py: 2.5,
          }}
        >
          <ProjectsHeader
            projectCount={summary.projectCount}
            totalMappings={summary.totalMappings}
            onNewProject={() => setIsNewProjectOpen(true)}
          />

          <AiaBox
            data-tour={TOUR_TARGETS.projectsGrid}
            sx={{
              mt: 2.5,
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: 2,
              pb: 2,
            }}
          >
            {projects.length === 0 ? (
              <AiaBox
                sx={{
                  width: "100%",
                  border: "1px dashed #D1D5DB",
                  borderRadius: 3,
                  bgcolor: "#FFFFFF",
                  color: "#6B7280",
                  px: 3,
                  py: 6,
                  textAlign: "center",
                  fontSize: 14,
                }}
              >
                No saved projects found. Create a project to start saving STTMs.
              </AiaBox>
            ) : (
              projects.map((project, index) => (
                <AiaBox
                  key={project.id}
                  sx={{
                    flex: "0 0 auto",
                    width: { xs: "100%", sm: PROJECT_CARD_WIDTH },
                    maxWidth: { xs: "100%", sm: PROJECT_CARD_WIDTH },
                  }}
                >
                  <ProjectCard
                    project={project}
                    isTourAnchor={index === 0}
                    onClick={() => router.push(`/mappings?project=${encodeURIComponent(project.id)}`)}
                    onHardcodedValues={() =>
                      router.push(
                        `/attributes?project_id=${encodeURIComponent(project.id)}&project_name=${encodeURIComponent(project.name)}`,
                      )
                    }
                  />
                </AiaBox>
              ))
            )}
          </AiaBox>
        </AiaBox>

        <ProjectsSummaryFooter
          projectCount={summary.projectCount}
          totalMappings={summary.totalMappings}
          complete={summary.complete}
          inProgress={summary.inProgress}
        />
        <AiaLoadingOverlay open={isLoadingProjects} label="Loading projects…" />
      </AiaBox>

      <NewProjectModal
        open={isNewProjectOpen}
        onClose={() => setIsNewProjectOpen(false)}
        onCreate={handleCreateProject}
        availableProjects={projects}
      />
    </>
  );
}
