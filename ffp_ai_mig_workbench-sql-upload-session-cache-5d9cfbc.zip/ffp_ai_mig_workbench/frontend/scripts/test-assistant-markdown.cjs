const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');
const filename = path.resolve(__dirname, '../src/features/ai-agent/assistant-markdown.tsx');
const loaded = new Module(filename, module);
loaded.filename = filename;
loaded.paths = module.paths;
const baseRequire = loaded.require.bind(loaded);
function Box({component = 'div', sx, children, ...props}) {
  return React.createElement(component, {...props, 'data-style': JSON.stringify(sx)}, children);
}
loaded.require = name => {
  if (name === '@/components/ui') return { AiaBox: Box, AiaIconButton: props => Box({...props, component:'button'}) };
  if (name === '@/components/ui/aia-text') return { AiaText: Box };
  if (name === '@/components/sql') return { SqlHighlight: ({text}) => React.createElement('span', {'data-sql':true}, text) };
  if (name === '@/components/sql/format-sql') return { formatSqlForDisplay: value => value };
  if (name === '@/utils/icons') return new Proxy({}, {get: () => () => null});
  return baseRequire(name);
};
loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: {module:ts.ModuleKind.CommonJS, target:ts.ScriptTarget.ES2020, jsx:ts.JsxEmit.ReactJSX, esModuleInterop:true},
}).outputText, filename);
const render = content => renderToStaticMarkup(React.createElement(loaded.exports.AssistantMarkdown, {content}));
const html = render('# Result\n\n## Summary\n\n**Bold** and *italic* with `column`.\n\n- First\n- Second\n\n1. Start\n2. Finish\n\n> Review this.\n\n| Column | Rule |\n|---|---|\n| NAME | Direct |\n\n```sql\nSELECT NAME FROM SOURCE;\n```');
for (const tag of ['strong','em','ul','ol','li','blockquote','table','th','td','pre','code']) assert.match(html, new RegExp('<'+tag+'[ >]'));
assert.match(html, /listStyleType.*disc/);
assert.match(html, /listStyleType.*decimal/);
assert.match(html, /Copy code/);
assert.match(html, /Wrap table to fit/);
assert.match(html, /data-sql/);
assert.match(render('```sql\nSELECT NAME'), /data-sql/);
const unsafe = render('<script>alert(1)</script>\n\n[unsafe](javascript:alert)');
assert.doesNotMatch(unsafe, /<script|href="javascript:/);
const mappingAnswer = render('**Target:** `FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT.TARGET_TABLES.HOUSEHOLD.NAME`\n\n- **Source:** `ACCOUNTS.NAME_R`\n- **Rule:** `TRIM(accounts_80ydxi.NAME_R)`\n- **Review required:** Not yet accepted.\n\n[Documentation](https://docs.snowflake.com/)');
assert.match(mappingAnswer, /<strong[^>]*>Target:<\/strong>/);
assert.match(mappingAnswer, /<code[^>]*>ACCOUNTS.NAME_R<\/code>/);
assert.match(mappingAnswer, /TRIM\(accounts_80ydxi.NAME_R\)/);
assert.match(mappingAnswer, /overflowWrap.*anywhere/);
assert.match(mappingAnswer, /rel="noopener noreferrer"/);
console.log('PASS rich Markdown, mapping identifiers, wrapping, list markers, table/code controls, streaming fence and unsafe HTML/URL handling');
