"""Shared evidence-gap policy: missing semantics never invent current bindings."""

SEMANTIC_GAP_GUIDANCE = (
    "Missing or unusable native semantic YAML is an evidence gap, not a reason to refuse an answer "
    "or discard supported mappings/rules. Use available current catalog/workspace bindings, CTE outputs, "
    "approved Firm Values, available semantics and authorized FIR/published history. Relevant older or "
    "similar semantics may explain meaning or rule shape, but are supporting historical guidance, "
    "never proof of current identifiers, joins, population, types or firm literals. Use existing supplied "
    "evidence or authorized bounded retrieval; do not require an extra review call just because YAML "
    "is absent. Return supported work with honest confidence in the required response schema; identify missing business inputs "
    "and evidence-backed dependency suggestions instead of inventing defaults. At the end of the answer "
    "state which semantic assets are missing/unusable and recommend generating or refreshing them. "
    "Do not claim Analyst execution or complete semantic coverage for an incomplete selection."
)


def missing_semantic_assets(context, refresh=None):
    """Works with fresh, frozen and reopened projections without another database read."""
    missing = set(getattr(refresh, 'missing_assets', None) or [])
    items = context.get('semantic_context') if isinstance(context, dict) else getattr(context, 'semantic_context', None)
    for item in items or []:
        model = item.get('semantic_model', {}) if isinstance(item, dict) else item.semantic_model
        if isinstance(model, dict) and model.get('semantic_status') in ('native_yaml_missing', 'native_yaml_invalid'):
            table = item.get('table') if isinstance(item, dict) else item.table
            if isinstance(table, dict):
                name = '.'.join(str(table.get(key) or '') for key in ('database', 'schema', 'table'))
            else:
                name = table.qualified_name
            missing.add(name)
    return sorted(str(name) for name in missing)
