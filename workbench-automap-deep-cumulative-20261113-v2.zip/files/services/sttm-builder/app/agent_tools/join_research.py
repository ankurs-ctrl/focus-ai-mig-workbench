"""Bounded, reviewable join paths from current and historical evidence."""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from app.agent_tools.relationship_graph import path_confidence as graph_path_confidence, path_shape
from app.agent_tools.source_readiness import disconnected_plan_sources


def table_name(value: Any) -> str:
    if isinstance(value, dict):
        value = ".".join(str(value.get(key) or "") for key in ("database", "schema", "table"))
    return str(value or "").strip('"').upper()


_FILTER_VALUE_LIMIT = 512


def _literal_filters(raw: Any) -> list[dict[str, str]] | None:
    """Validated ``[{side, column, operator, value}]``; ``None`` if any item is invalid."""
    filters = []
    for item in raw or []:
        if not isinstance(item, dict):
            return None
        side = str(item.get("side") or "").lower()
        column = str(item.get("column") or "").upper()
        value = item.get("value")
        if (side not in {"left", "right"} or not _COLUMN.fullmatch(column) or str(item.get("operator") or "=") != "="
                or value is None or len(str(value)) > _FILTER_VALUE_LIMIT):
            return None
        filters.append({"side": side, "column": column, "operator": "=", "value": str(value)})
    return filters


def normalized_candidate(raw: dict[str, Any]) -> dict[str, Any] | None:
    left, right = table_name(raw.get("left_table")), table_name(raw.get("right_table"))
    raw_conditions = raw.get("conditions") or []
    conditions = [
        {"left_column": str(item.get("left_column") or "").upper(),
         "right_column": str(item.get("right_column") or "").upper(), "operator": "="}
        for item in raw_conditions
        if isinstance(item, dict) and item.get("left_column") and item.get("right_column")
        and str(item.get("operator") or "=") == "="
    ]
    alternative = str(raw.get("normalized_lookup_alternative") or "").upper()
    if alternative and (not _COLUMN.fullmatch(alternative) or len(conditions) != 1):
        return None
    if left.count(".") != 2 or right.count(".") != 2 or not conditions or len(conditions) != len(raw_conditions):
        return None
    filters = _literal_filters(raw.get("literal_filters"))
    if filters is None or (filters and alternative):
        return None
    join_type = str(raw.get("join_type") or "LEFT").upper().removesuffix(" JOIN")
    if join_type not in {"INNER", "LEFT", "RIGHT", "FULL"}:
        return None
    confidence = raw.get("confidence")
    return {"left_table": left, "right_table": right,
            "join_type": join_type,
            "conditions": conditions, "source": str(raw.get("source") or "HISTORICAL_CANDIDATE"),
            **({"normalized_lookup_alternative": alternative} if alternative else {}),
            **({"literal_filters": filters} if filters else {}),
            **({"confidence": float(confidence)} if isinstance(confidence, (int, float)) else {})}


def _contract_candidates(selected: set[str], contracts: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Suggest current-column joins for review; a name match is never verified evidence."""
    def stem(table: str) -> str:
        leaf = table.split(".")[-1].upper()
        return leaf[:-3] + "Y" if leaf.endswith("IES") else leaf.removesuffix("S")

    suggestions: list[tuple[int, dict[str, Any]]] = []
    tables = sorted(selected)
    for index, left in enumerate(tables):
        left_columns = {str(value).upper() for value in contracts.get(left, {}).get("columns") or []}
        for right in tables[index + 1:]:
            right_columns = {str(value).upper() for value in contracts.get(right, {}).get("columns") or []}
            right_stem = stem(right)
            left_stem = stem(left)
            pairs: list[tuple[int, str, str]] = []
            for column in left_columns:
                if column.endswith("_ID") and column in right_columns:
                    pairs.append((2, column, column))
                if column.endswith("_ID") and "ID" in right_columns and (
                    column[:-3] in right_stem or right_stem in column[:-3]
                ):
                    pairs.append((3, column, "ID"))
            for column in right_columns:
                if column.endswith("_ID") and "ID" in left_columns and (
                    column[:-3] in left_stem or left_stem in column[:-3]
                ):
                    pairs.append((3, "ID", column))
            for score, left_column, right_column in sorted(set(pairs), reverse=True)[:3]:
                suggestions.append((score, {"left_table": left, "right_table": right,
                    "conditions": [{"left_column": left_column, "right_column": right_column}],
                    "source": "CURRENT_COLUMN_NAME_PROPOSAL",
                    "review_reason": "Low confidence: inferred from current column names; confirm the business key and row cardinality."}))
    return [candidate for _, candidate in sorted(suggestions, key=lambda entry: -entry[0])]


def candidate_uses_current_columns(
    candidate: dict[str, Any], contracts: dict[str, dict[str, Any]],
) -> bool:
    """Only offer joins whose current columns and known types can be compared."""
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    types: dict[str, dict[str, str]] = {}
    for side in ("left", "right"):
        table = table_name(candidate.get(f"{side}_table"))
        contract = contracts.get(table)
        if not contract:
            return False
        columns = {str(value).upper() for value in contract.get("columns") or []}
        if not columns or any(
            str(condition.get(f"{side}_column") or "").upper() not in columns
            for condition in candidate.get("conditions") or []
        ):
            return False
        if any(str(item.get("column") or "").upper() not in columns
               for item in candidate.get("literal_filters") or [] if item.get("side") == side):
            return False
        if side == "right" and candidate.get("normalized_lookup_alternative") and (
            str(candidate["normalized_lookup_alternative"]).upper() not in columns
        ):
            return False
        types[side] = {
            str(value.get("name") or "").upper(): str(value.get("type") or "")
            for value in contract.get("column_contracts") or [] if isinstance(value, dict)
        }
    for condition in candidate.get("conditions") or []:
        left_type = types["left"].get(str(condition.get("left_column") or "").upper())
        right_type = types["right"].get(str(condition.get("right_column") or "").upper())
        if left_type and right_type and WorkbenchWorkflowHandlers._type_family(left_type) != WorkbenchWorkflowHandlers._type_family(right_type):
            return False
    alternative = str(candidate.get("normalized_lookup_alternative") or "").upper()
    if alternative:
        condition = candidate["conditions"][0]
        source_type = types["left"].get(str(condition.get("left_column") or "").upper())
        code_type = types["right"].get(str(condition.get("right_column") or "").upper())
        alias_type = types["right"].get(alternative)
        if any(value and WorkbenchWorkflowHandlers._type_family(value) != "text" for value in
               (source_type, code_type, alias_type)):
            return False
    return True


def research_questions(prepared: dict[str, Any], contracts: dict[str, dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Find short candidate paths; do not promote candidates to verified joins."""
    data = dict(prepared.get("data") or {})
    source = dict((data.get("plan_candidate") or {}).get("source_preparation") or {})
    driver = table_name(source.get("driving_source"))
    selected = {table_name(item) for item in [source.get("driving_source"), *(source.get("supporting_sources") or [])]}
    selected.discard("")
    if not driver:
        return []
    verified = [item for item in source.get("relationships") or [] if isinstance(item, dict)]
    supporting = [table_name(name) for name in source.get("supporting_sources") or []]
    missing_set = set(disconnected_plan_sources(driver, supporting, verified))
    missing = [name for name in supporting if name in missing_set]
    relationship_graph = data.get("relationship_graph") if isinstance(data.get("relationship_graph"), dict) else None
    graph_edges = [item for item in (relationship_graph or {}).get("edges") or [] if isinstance(item, dict)]
    margin = float(((relationship_graph or {}).get("thresholds") or {}).get("margin") or 0.15)
    if graph_edges:
        # The verified graph already merged registry, precedent, learning and
        # semantic candidates as evidence on the same edges, and name-only
        # proposals were checked against the data.
        raw_candidates = graph_edges
    else:
        raw_candidates = [
            *[item for item in (data.get("current_relationships") or {}).get("recommendations") or [] if isinstance(item, dict)],
            *[item for item in data.get("historical_relationship_candidates") or [] if isinstance(item, dict)],
        ]
        if contracts:
            raw_candidates.extend(_contract_candidates(selected, contracts))
    visible = {table_name(value) for value in data.get("catalog_candidates") or []}
    visible.update(selected)
    visible.update(table_name(value) for value in (relationship_graph or {}).get("tables") or [])
    for bridge in [] if graph_edges else (data.get("current_relationships") or {}).get("expansion_candidates") or []:
        if not isinstance(bridge, dict) or bridge.get("column_contract_status") not in {"verified", "reversed_candidate"}:
            continue
        left, right = table_name(bridge.get("from_table")), table_name(bridge.get("related_table"))
        if not {left, right} <= visible:
            continue
        conditions = [{"left_column": item.get("from_column"), "right_column": item.get("related_column")}
                      for item in bridge.get("candidate_conditions") or [] if isinstance(item, dict)]
        raw_candidates.append({"left_table": left, "right_table": right, "conditions": conditions,
                               "source": "WORKBENCH_SEMANTIC_BRIDGE", "review_reason": "Current semantic bridge candidate"})
    candidates: dict[str, dict[str, Any]] = {}
    for raw in raw_candidates:
        item = normalized_candidate(raw)
        if not item or not {item["left_table"], item["right_table"]} <= visible:
            continue
        if contracts is not None and not candidate_uses_current_columns(item, contracts):
            continue
        identity = json.dumps([item["left_table"], item["right_table"], item["conditions"],
                               item.get("normalized_lookup_alternative"), item.get("literal_filters")], sort_keys=True)
        key = hashlib.sha256(identity.encode()).hexdigest()[:16]
        candidates.setdefault(key, {"id": key, "relationship": item,
                                    "auto_resolvable": bool(raw.get("auto_resolvable")),
                                    "evidence": str(raw.get("review_reason") or _evidence_summary(raw) or item["source"])})
    edges = [(item["left_table"], item["right_table"], None) for raw in verified
             if (item := normalized_candidate(raw))]
    edges.extend((value["relationship"]["left_table"], value["relationship"]["right_table"], key)
                 for key, value in candidates.items())
    questions = []
    for target in missing:
        queue = [(driver, [], {driver})]
        paths: list[list[str]] = []
        explored = 0
        while queue and len(paths) < 24 and explored < 200:
            node, chosen, seen = queue.pop(0)
            explored += 1
            if node == target:
                if chosen and chosen not in paths:
                    paths.append(chosen)
                continue
            if len(seen) > 5:
                continue
            for left, right, candidate_id in edges:
                next_node = right if left == node else left if right == node else None
                if next_node and next_node not in seen:
                    queue.append((next_node, [*chosen, *([candidate_id] if candidate_id else [])], seen | {next_node}))
        def edge_hops(path: list[str]) -> list[tuple[str, str, str]]:
            # Graph relationships are oriented child (left) -> parent (right).
            return [(candidates[key]["relationship"]["left_table"],
                     str(candidates[key]["relationship"]["conditions"][0]["left_column"]).upper(),
                     candidates[key]["relationship"]["right_table"]) for key in path]

        def path_confidence(path: list[str]) -> float | None:
            values = [candidates[key]["relationship"].get("confidence") for key in path]
            if not values or any(value is None for value in values):
                return None
            return graph_path_confidence(values, path_shape(driver, edge_hops(path))[1])

        if graph_edges:
            # One value cannot reference two parents; such routes are not joins.
            paths = [path for path in paths if path_shape(driver, edge_hops(path))[0]]
            paths.sort(key=lambda path: (-(path_confidence(path) or 0.0), len(path)))
        else:
            paths.sort(key=lambda path: (
                any(candidates[key]["relationship"]["source"] == "CURRENT_COLUMN_NAME_PROPOSAL" for key in path),
                -sum(bool(candidates[key]["relationship"].get("normalized_lookup_alternative")) for key in path),
                any(candidates[key]["relationship"]["source"].endswith("_PROPOSAL") for key in path),
                len(path),
            ))
        options = []
        for index, path in enumerate(paths[:3]):
            route = [candidates[key] for key in path]
            def edge_label(value: dict[str, Any]) -> str:
                join = value["relationship"]
                left = join["left_table"].split(".")[-1]
                right = join["right_table"].split(".")[-1]
                condition = join["conditions"][0]
                alternative = join.get("normalized_lookup_alternative")
                if alternative:
                    return (f"{left}.{condition['left_column']} ↔ {right}."
                            f"{condition['right_column']} or {alternative} (trim/uppercase)")
                filters = "".join(
                    f" where {left if item['side'] == 'left' else right}.{item['column']} = '{item['value']}'"
                    for item in join.get("literal_filters") or []
                )
                return f"{left}.{condition['left_column']} = {right}.{condition['right_column']}{filters}"
            summary = " → ".join(edge_label(value) for value in route)
            lookup = next((value["relationship"].get("normalized_lookup_alternative") for value in route
                           if value["relationship"].get("normalized_lookup_alternative")), None)
            confidence = path_confidence(path)
            if graph_edges:
                runner_up = path_confidence(paths[1]) if len(paths) > 1 else 0.0
                # A second strong, coherent route is a genuine business choice.
                recommended = (index == 0 and path_shape(driver, edge_hops(path))[1] == 0
                               and all(value["auto_resolvable"] for value in route)
                               and (confidence or 0.0) - (runner_up or 0.0) >= margin)
                label = f"{'Recommended' if recommended else 'Candidate'} path ({round((confidence or 0) * 100)}% confidence): {summary}"
                description = ("Every join on this path was verified against the current data; the confidence "
                               "compares it with the competing parents of each join column.")
                options.append({"id": f"path_{index + 1}", "label": label, "description": description,
                                "joins": [value["relationship"] for value in route],
                                "evidence": [value["evidence"] for value in route],
                                "confidence": round(confidence or 0.0, 4), "recommended": recommended})
                continue
            inferred = any(value["relationship"]["source"] == "CURRENT_COLUMN_NAME_PROPOSAL" for value in route)
            options.append({"id": f"path_{index + 1}", "label": (f"Match normalized code or alias ({summary})" if lookup else f"Review candidate path: {summary}" if inferred else f"Use candidate path: {summary}"),
                            "description": ("Low confidence: unverified column-name match. Confirm business key and cardinality before selecting." if inferred else "Join columns come from current semantic suggestions or historical SQL. Current contracts are checked now; cardinality is checked during source preparation."),
                            "joins": [value["relationship"] for value in route],
                            "evidence": [value["evidence"] for value in route]})
        no_path_reason = None
        if graph_edges and not options:
            touching = [item for item in graph_edges
                        if target in {table_name(item.get("left_table")), table_name(item.get("right_table"))}]
            checked = [item for item in touching if isinstance(item.get("verification"), dict)]
            no_path_reason = (
                "none of its columns names a key of the other sources with a compatible type" if not touching else
                "its candidate join columns have no values to check" if checked and all(
                    not item["verification"].get("child_values_sampled") for item in checked) else
                "its candidate join columns did not match the other sources' keys in the data"
            )
        questions.append({"target": target, "driver": driver, "options": options,
                          "recommended_option_id": next((option["id"] for option in options if option.get("recommended")), None),
                          **({"no_path_reason": no_path_reason} if no_path_reason else {}),
                          "cte_leads": [str(item.get("name")) for item in source.get("derived_sources") or []
                                        if isinstance(item, dict) and target in [table_name(value) for value in item.get("base_source_tables") or []]][:3]})
    return questions


def _evidence_summary(raw: dict[str, Any]) -> str:
    """One-line provenance for a verified graph edge."""
    parts = []
    verification = raw.get("verification") if isinstance(raw.get("verification"), dict) else {}
    if verification.get("status") == "verified":
        parts.append(f"{round(float(verification.get('coverage') or 0) * 100, 1)}% of sampled keys found in the parent")
    kinds = sorted({str(item.get("kind")) for item in raw.get("evidence") or [] if isinstance(item, dict) and item.get("kind")})
    if kinds:
        parts.append("supported by " + ", ".join(kinds))
    return "; ".join(parts)


_COLUMN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_LITERAL_CLAUSE = re.compile(r"^\s*(?P<table>[A-Za-z0-9_.\"]+)\.(?P<column>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*'(?P<value>(?:''|[^'])*)'\s*$")
# Split on semicolons outside single-quoted literals.
_CLAUSE_SPLIT = re.compile(r";(?=(?:[^']*'[^']*')*[^']*$)")


def parse_join_rules(answer: str, selected: list[str], preferred_schemas: list[str] | None = None) -> list[dict[str, Any]]:
    """Accept scoped equality, normalized code/alias, and literal-filter rules; never raw SQL.

    ``TABLE.COLUMN = 'value'`` scopes the join on TABLE whose key shares the
    filter column's stem (``NOTEABLE_TYPE`` with ``NOTEABLE_ID``), otherwise the
    nearest preceding join on TABLE. A bare table name found in several
    schemas resolves to the one in ``preferred_schemas`` (the question's own
    tables), so a same-named table from a precedent schema is not ambiguous.
    """
    preferred = [str(value).strip('"').upper() for value in preferred_schemas or [] if value]
    by_leaf: dict[str, list[str]] = {}
    for name in selected:
        fqn = table_name(name)
        if not fqn:
            continue
        existing = by_leaf.setdefault(fqn.split(".")[-1], [])
        if fqn not in existing:
            existing.append(fqn)
    for leaf, matches in by_leaf.items():
        if len(matches) > 1:
            for schema in preferred:
                in_schema = [value for value in matches if value.rsplit(".", 1)[0] == schema]
                if len(in_schema) == 1:
                    by_leaf[leaf] = in_schema
                    break
    relationships = []
    literals: list[tuple[int, str, str, str]] = []
    for clause in _CLAUSE_SPLIT.split(answer):
        literal = _LITERAL_CLAUSE.fullmatch(clause)
        if literal:
            table = literal.group("table").strip('"')
            matches = by_leaf.get(table.upper(), []) if "." not in table else [table_name(table)]
            if len(matches) != 1 or matches[0] not in {table_name(item) for item in selected}:
                raise ValueError(f"Filter table is not an unambiguous selected source: {table}")
            value = literal.group("value").replace("''", "'")
            if len(value) > _FILTER_VALUE_LIMIT:
                raise ValueError("A join filter value is too long.")
            literals.append((len(relationships), matches[0], literal.group("column").upper(), value))
            continue
        lookup = re.fullmatch(r"NORMALIZED_OR\(\s*([^,()]+)\s*,\s*([^,()]+)\s*,\s*([^,()]+)\s*\)", clause.strip(), re.I)
        if lookup:
            source, code, alias = (value.strip().upper() for value in lookup.groups())
            source_table, source_column = source.rsplit(".", 1)
            code_table, code_column = code.rsplit(".", 1)
            alias_table, alias_column = alias.rsplit(".", 1)
            if code_table != alias_table or not all(_COLUMN.fullmatch(value) for value in
                    (source_column, code_column, alias_column)):
                raise ValueError("Normalized lookup needs one source column and two columns from the same lookup table.")
            left = by_leaf.get(source_table, []) if "." not in source_table else [table_name(source_table)]
            right = by_leaf.get(code_table, []) if "." not in code_table else [table_name(code_table)]
            if len(left) != 1 or len(right) != 1 or left[0] == right[0] or not {left[0], right[0]} <= {table_name(item) for item in selected}:
                raise ValueError("Normalized lookup tables must be unambiguous selected sources.")
            relationships.append({"left_table": left[0], "right_table": right[0], "join_type": "LEFT",
                "conditions": [{"left_column": source_column, "right_column": code_column, "operator": "="}],
                "normalized_lookup_alternative": alias_column, "source": "USER_CONFIRMED_JOIN_RULE"})
            continue
        parts = [value.strip().strip('"') for value in clause.strip().split("=")]
        if len(parts) != 2 or any("." not in value for value in parts):
            raise ValueError("Enter joins as TABLE.COLUMN = TABLE.COLUMN, separated by semicolons for a bridge path.")
        names = []
        for value in parts:
            table, column = value.rsplit(".", 1)
            if not _COLUMN.fullmatch(column):
                raise ValueError("A join column must be a current column name.")
            matches = by_leaf.get(table.upper(), []) if "." not in table else [table_name(table)]
            if len(matches) != 1 or matches[0] not in {table_name(item) for item in selected}:
                raise ValueError(f"Join table is not an unambiguous selected source: {table}")
            names.append((matches[0], column.upper()))
        if names[0][0] == names[1][0]:
            raise ValueError("A join must connect two different selected tables.")
        relationships.append({"left_table": names[0][0], "right_table": names[1][0],
                              "join_type": "LEFT", "conditions": [{"left_column": names[0][1],
                                                                       "right_column": names[1][1], "operator": "="}],
                              "source": "USER_CONFIRMED_JOIN_RULE"})
    for position, table, column, value in literals:
        stem = column.rsplit("_", 1)[0]
        involved = [index for index, item in enumerate(relationships) if table in (item["left_table"], item["right_table"])]
        if not involved:
            raise ValueError(f"A filter on {table.split('.')[-1]} needs a join on that table in the same answer.")
        by_stem = [index for index in involved if any(
            str(condition["left_column" if relationships[index]["left_table"] == table else "right_column"]).rsplit("_", 1)[0] == stem
            for condition in relationships[index]["conditions"])]
        preceding = [index for index in involved if index < position]
        target = (by_stem or preceding or involved)[-1 if not by_stem and preceding else 0]
        item = relationships[target]
        if item.get("normalized_lookup_alternative"):
            raise ValueError("A normalized code/alias lookup cannot also carry a literal filter.")
        item.setdefault("literal_filters", []).append({
            "side": "left" if item["left_table"] == table else "right",
            "column": column, "operator": "=", "value": value,
        })
    return relationships
