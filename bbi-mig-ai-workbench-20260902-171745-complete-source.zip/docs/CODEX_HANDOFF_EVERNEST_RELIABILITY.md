# Codex Handoff: EverNest Import, Workspace, and FIR Reliability Repair

Continue the existing implementation in:

`/Users/ankurshome/Desktop/storage/Mr-Bucky/bbi-mig-ai-workbench`

Do not restart the investigation or replace existing work. The worktree is intentionally very dirty from ongoing frontend, backend, FIR, and deployment work. Preserve all user changes and work with them. Use `apply_patch` for edits.

## Non-Negotiable Boundary

Do not modify, redeploy, or revert `AGT_SEMANTIC_MODEL_V2`, its prompts, procedures, or generated registry records. Existing diffs touching semantic-agent files predate this repair and must be left alone. This task may only consume what the semantic agent already writes.

## Authoritative Records

- Canonical project: `903`
- Canonical mapping: `1101`
- Status: `COMPLETE`
- Published version: `1`
- Snapshot: `snapshot_cda0404dfce9470eadb5`
- Authoritative SQL: `docs/01-EverNest-HHs-reference.sql`, exactly 13,688 bytes
- Failed duplicate projects: `602`, `902`, `901`, `801`, `701`
- Failed copies each contain one unpublished draft without a valid snapshot.
- Raw SQL is stored correctly. Corruption occurs later during frontend hydration and generated-SQL replacement.

## Original Required Plan

1. Archive failed projects, mark their mappings `SUPERSEDED`, suppress their snapshots/recommendations/FIR evidence from runtime retrieval, and retain audit lineage. Keep `903/1101` canonical.
2. Add an idempotent historical-import key from project, SQL asset hash, target FQN, and import mode. Retries resume/update the same import. Hide incomplete imports as `IMPORTING` or `IMPORT_FAILED`.
3. Implement strict saved-workspace hydration: authenticate, load latest published backend snapshot, hydrate sources/target/mappings/relationships/filters/CTEs/raw SQL/lineage, batch-load attributes, mark ready, then enable navigation/autosave/recommendations/agents.
4. Backend snapshots outrank browser storage. Browser state is scoped by user, project, mapping, and snapshot revision. Never hydrate saved mappings from generic `/new` cache, redirect while loading, autosave transient state, or let stale requests overwrite a newer revision.
5. Preserve separate `raw_mapping_sql` and `parsed_mapping_model`. Generated SQL is preview-only and must never replace imported raw SQL.
6. Parse Snowflake scripts containing `SET`, literal constants, `CONCAT` table variables, `IDENTIFIER($var)`, `USE DATABASE/SCHEMA`, nested CTEs, dependencies, joins, filters, `QUALIFY`, grouping, ordering, deduplication, CASE/casts/date conversions/lookups, hardcoded target values, and SELECT-only target overrides.
7. EverNest acceptance: exact raw bytes, 20 physical sources, 18 CTE lineage nodes, 26 target mappings, constants as `Value`, transformations as preprocessing rules, complete joins/filters, no database/schema pseudo-tables, and no unresolved static master-table variables. Transformation CTEs become derived-source definitions; wrapper CTEs remain lineage nodes.
8. SQL editing flow: Edit raw SQL, Review Changes, parse full script, show structural diff, atomically apply, and refresh Selection/Mapping/SQL/lineage/agent context together. Invalid or ambiguous SQL applies nothing. Editing a published mapping creates a draft; republishing creates immutable version 2.
9. Split structured mapping context from Analyst-safe YAML. Unsafe relationships remain available to Source Mapping/FIR/Builder/Transformation with trust evidence, but are excluded from Analyst YAML and returned in `excluded_relationships`. Auto-map must not fail solely with `SEMANTIC_RELATIONSHIP_INVALID`.
10. Scope recommendations by user, project, mapping, context/scope key, checkpoint, and content version. `/projects` shows no mapping recommendations. Switching scope immediately clears unrelated items. Backend must enforce scope. Archive scopes are excluded. Titles must describe content, with Q1/Q2/Q6/Q7 only as metadata.
11. Add scoped stale-while-revalidate caching and request revision control: projects 30s, metadata 10m by FQN/schema hash, published snapshots immutable by ID, recommendations 60s by context/checkpoint, conversations by user/project/mapping/conversation. Cancel stale requests and deduplicate concurrent calls.
12. Recovery after code deployment: reconcile, archive five duplicates, re-project existing SQL on mapping 1101 without another upload, review structure, publish repaired version 2, retain prior FIR evidence, supersede contradictions, then trigger FIR on the new publication.

## Completed in This Task

Backend parser and projection work is implemented in:

- `services/sttm-builder/app/core/sql_parser.py`
- `services/sttm-builder/app/core/mapping_sql.py`

Implemented behavior includes recursive `CONCAT` variable resolution, `IDENTIFIER($var)`, ignoring `USE` as sources, nested CTE dependencies, physical/logical separation, constant/direct/transformed mapping modes, filters, `QUALIFY`, grouping, ordering, and transformation-bearing derived-source candidates.

The real fixture has been verified locally with these counts:

`13688 bytes / 20 physical sources / 18 CTEs / 26 mappings / 30 joins / 39 rules / 10 derived candidates`

Semantic isolation is implemented in:

- `services/sttm-builder/app/core/semantic_context.py`
- `services/sttm-builder/app/schema/semantic_context.py`

Unsafe relationships are collected into `excluded_relationships` with warnings instead of throwing and blocking the full semantic refresh. No semantic-agent code was changed for this repair.

## Investigation Completed, Edits Still Required

`frontend/src/app/sttm/builder/new/mapping/page.tsx` currently redirects to Selection before saved hydration completes. It also initializes mappings against every target column, which can destroy a valid partial/published 26-row projection when the physical target has more columns. Guard redirects and initialization with `openSttmStatus`, active IDs, and hydration readiness.

The same page seeds the editor from generated preview SQL and calls `setMappingSql(...)` in generated, validation, optimization, and preview flows. Remove those raw-SQL overwrites. `mappingSql` must remain canonical raw SQL; `mappingPreviewSql` remains generated/reviewed preview SQL. Parsed constants must become `Value` mappings, and only `parsed_workspace.derived_sources` should become selectable derived sources.

`frontend/src/components/sql/sql-preview/mapping-sql-preview.tsx` starts Edit mode by replacing editor content with `generatedSql`. Change it to retain canonical `editableSql` when present.

`frontend/src/features/sttm/context/sttm-builder-context.tsx` clears exact `/new` storage and restores saved mappings from a generic `::new` cache. Replace this with backend-first scoped hydration using user/project/mapping/snapshot identity. Do not persist or restore FIR recommendations in generic draft storage. Guard persistence and evaluation while hydration is loading and outside `/sttm`. Require active project/mapping for mapping-scoped recommendations.

`frontend/src/features/sttm/store/sttm-builder-slice.ts` still restores FIR cards from local hydration, retains prior-checkpoint recommendation arrays, defaults `mappingPreviewSql` to raw SQL on saved load, and sets both raw and preview SQL during parsed apply. Correct all four. `clearAssistantSignalsForContext` must also clear `firRecommendations`.

Expose `openSttmStatus`, `openSttmTargetPage`, and errors through `SttmBuilderContextValue`. Ensure explicit New Mapping actions reset draft identity; saved mapping back-navigation must preserve its scoped backend identity.

## Remaining Backend and Data Work

- Add versioned DDL/procedure support for import state, stable import key, supersession, archive/suppression, and raw/parsed SQL fields if not already present.
- Add a read-only reconciliation report and an idempotent recovery script for projects `602/902/901/801/701` and canonical `903/1101`. Do not execute destructive deletes.
- Enforce recommendation scoping and archive suppression in backend retrieval, not only frontend filtering.
- Generate content-specific recommendation titles from the recommendation subject/current understanding.
- Confirm Auto-map consumes structured semantic/FIR context even when Analyst YAML excludes a relationship.
- Add request revision/cancellation and scoped caches where missing.
- Add parser, hydration, SQL atomic-apply, recommendation isolation, unsafe-relationship, and import-idempotency tests.
- Re-project and publish version 2 only after tests and reconciliation; do not create another project.
- Run focused backend tests, frontend TypeScript checks, start with `./start-ai-workbench-dev.sh`, and verify ports 3000/8000.
- Do not create the final release zip until implementation and smoke verification are complete.

## Required Acceptance Tests

Opening or refreshing mapping `1101` stays on Mapping and preserves its 20 sources, target, 18 CTE lineage nodes, joins, filters, 26 mappings, constants, transformations, and exact raw SQL. Selection and Mapping remain consistent. Editing is atomic. Analyst exclusion does not block Auto-map. `/projects` and unrelated mappings never show EverNest/Verified Income recommendations. Re-importing the same SQL creates no new project or mapping. Archived duplicates disappear from UI and FIR runtime retrieval while audit history remains.

## 2026-07-20 Mapping Intelligence V2 Completion Update

Implemented behind `AUTO_MAP_PIPELINE_V2`:

- Durable Snowflake Auto-map jobs, adaptive bounded batch dispatch, idempotent compact partial merging, job diagnostics, and an in-process private-worker compatibility adapter for local/API acceptance. Terminal jobs now guarantee one ordered partial record per planned batch.
- Resume-on-poll recovery persists the token-free request envelope, hides it from public job responses, and uses an expiring atomic Snowflake lease so a replacement SPCS replica can resume with the polling user's current credential without persisting OAuth tokens. The live metadata table now has `LEASE_OWNER`, `LEASE_EXPIRES_AT`, and `ATTEMPT_COUNT`.
- Complete linked precedent retrieval for all 26 rows, including five Value mappings, 18 CTEs, 39 business rules, raw SQL/query-shaping evidence, and completed mappings whose historical attribute rows retained a stale draft flag.
- One retrieval/context preparation per job, visible FIR failure behavior, FIR recommendation-procedure repair, and evidence IDs/hashes. Linked precedents are now agent evidence by default; deterministic exact-precedent replay is diagnostic-only and requires an explicit request flag.
- Unified physical/derived/CTE relation graph, multi-source dependencies, Value bindings, compiler-owned joins/aliases, role-aware semantic packing, and complete derived output contracts.
- Backend authoritative compilation, exact precedent query-shape restoration, explicit Value resolution, physical-table qualification, placeholder blocking, and Snowflake `EXPLAIN`.
- Ordered contextual FIR notification delivery and content-specific display fields.
- Source/Transformation agent instruction and deployment-hash manifests. `AGT_SOURCE_MAPPING` now uses Claude Haiku 4.5 with a 75-second/6,500-token budget. `AGT_TRANSFORMATION_RULE` no longer echoes semantic/learning context and has a 75-second/4,500-token budget. The current local manifest hashes are `df09c9ca9c9f120b018f7f8537c2d92dabad9ea9d03e39d3d0f46e9068e8cda8` and `a9cec5354f68c0790b4c5ba177b43670c9167bc429d2c6708b094ff42a2ce588` respectively. The updated Source Mapping specification must be deployed before an SPCS agent-led canary.
- Worker responses are provenance-checked at the backend boundary. An agent cannot claim `accept_precedent` or `override_precedent` for a semantic/FIR pattern that is not an actual linked mapping ID; the decision is normalized to `unresolved` while its inferred source candidates remain available for review.
- Auto-map relationship serialization now keeps derived-source joins exclusively in the unified relation graph instead of emitting an invalid physical `TableRef` compatibility copy. The backend also normalizes older graph-backed payloads that contain this malformed duplicate, preventing the mapping `1401` 422 validation failure without dropping the real graph edge.
- Local V2 runtime now resolves an omitted `AUTO_MAPPING_SERVICE_URL` to the private in-process worker; non-local/SPCS environments still require an explicit internal service URL. This fixes the subsequent misleading "not an Auto-map operation" response, which was actually caused by a disabled proxy, not by a changed request intent. The job route now reports operation mismatch and missing worker configuration separately.
- `AGT_SEMANTIC_MODEL_V2` was not modified or deployed.

Previous deterministic replay diagnostic for project `1101`, mapping `1401`, linked to `903/1101`:

- 26/26 mappings, 26 `accept_precedent`, five Value rows, no unresolved targets, and no unevidenced override.
- Latest durable job time: 7.70 seconds; one exact-precedent replay batch and zero Cortex calls. This proves precedent retrieval/compiler reuse only and is not evidence that the agent reconstructed the mapping.
- Canonical SQL remains exactly 13,688 bytes with SHA-256 `dbbd859aa75e54d0688c63343102bf788ca1daeb57086cc41b5fb5466097a9f9`.
- Unbound compilation is valid and intentionally not ready while project placeholders remain unresolved.
- Explicit validation bindings produce a ready query with zero unresolved placeholders; Snowflake `EXPLAIN` succeeds.
- Canonical and generated queries return the identical two-row multiset and identical Snowflake multiset hash `-3400457653281809133` on the same snapshot.
- Canonical UDF pivots, mapper lookups, household exceptions, deduplication, and review-frequency rules are restored by the accepted precedent compiler path.

Live precedent-free shadow acceptance (linked precedent deliberately omitted):

- Two durable 26-target jobs completed in 147.68 and 134.21 seconds, both below the three-minute single-run target, using three adaptive batches sized 16/6/4 with maximum Cortex concurrency two.
- The post-fix run returned 17 direct, one simple multi-source, one complex, and seven unresolved targets. It persisted all three partials in order and correctly blocked compilation at an unmapped project-specific Value.
- The earlier run exposed fabricated precedent claims based on non-precedent evidence. In the post-fix run all 26 precedent decisions were correctly `unresolved`; backend provenance enforcement retained useful inferred source candidates while refusing nonexistent precedent IDs.
- Two live samples are not sufficient evidence for a p95 latency claim, and the classification variation is itself useful canary evidence.

Verification:

- Backend unit suite: 184 passed.
- Backend integration suite: 20 passed.
- Frontend TypeScript: `npx tsc --noEmit` passed.
- Focused Mapping SQL, payload, precedent, and proxy tests: 43 passed.
- Mapping agent specification manifest verification passed.
- Live Snowflake metadata migration and column verification passed.

Remaining canary blockers:

1. The precedent-free 26-target shadow path met the three-minute target in one live run, but p95 requires a canary sample set under realistic SPCS load, including throttling and retry cases. Source-stage partials are still emitted after each complete private-worker batch rather than before a novel transformation in that same batch.
2. Durable lease/resume behavior is implemented and covered by simulated new-replica and competing-replica tests. An actual SPCS process-kill/restart canary has not been run; do not claim production restart recovery until that operational test passes.
3. The saved derived source has 33 typed/lineage outputs but lacks declared row grain, business keys, and authored business meanings. It is correctly flagged as non-authoritative L3 evidence; repair must come through the normal UI/agent contract, not manual semantic edits.

Do not enable V2 by default until the SPCS p95 and process-kill canaries pass. The linked-precedent V2 path is ready for shadow comparison and local/integration use.

## 2026-07-20 Agent-Led Precedent Evaluation Correction

Normal V2 Auto-map no longer short-circuits on complete target coverage in a linked mapping. Historical compatibility does not prove that the current source relation graph is identical. Every normal request now invokes `AGT_SOURCE_MAPPING` and supplies the complete linked mapping, project/FIR learning context, target and source semantics, derived lineage, and current unified relation graph as evidence. The agent must evaluate each target and return `accept_precedent`, `override_precedent`, or `unresolved`.

`accept_precedent` is valid only when the historical dependencies and Value bindings exist unchanged in the current graph. A semantically equivalent mapping onto renamed or structurally different current sources is an evidenced `override_precedent`, not a blind copy. Deterministic replay remains available only through `replay_exact_precedent=true` for controlled retrieval/cache/compiler diagnostics; the UI does not set it.

This correction is covered by a regression test proving that an exact completed precedent remains present in the worker request while the source agent is invoked. The current local verification is 184 backend unit tests, 20 backend integration tests, frontend TypeScript, and a valid agent-spec manifest. Do not reuse the earlier 7.70-second replay as evidence of agent reconstruction.

Two non-publishing linked-context agent runs were completed after removing the shortcut. The persisted request contained precedent `1101` with all 26 rows, no similar-mapping fallback, replay disabled, the current relation graph, FIR evidence, semantic context, and derived lineage. The first run took 206.6 seconds and revealed that the model confused historical row `mapping_id` values with the parent `precedent_sttm_id`; 25 decisions were correctly rejected by backend provenance validation. The Source Mapping contract now distinguishes those IDs explicitly, and deployed Source Mapping hash `df09c9ca9c9f120b018f7f8537c2d92dabad9ea9d03e39d3d0f46e9068e8cda8` includes that repair.

The post-repair run took 295.3 seconds and returned 24 accepted precedent decisions, one evidenced override, and one unresolved target. It still did not reconstruct canonical behavior: `BFFS_CLIENTSTARTDATE__C` was sourced from `CLIENT_SINCE` instead of preserving `$ClientStartDate`, `LEGACYPORTFOLIOSYSTEMHHID__C` was unresolved despite the mapper-table precedent, and only four of five canonical Value rows were produced. Compilation also exposed that the agent refers to Value bindings by placeholder value while the graph stores a stable binding ID; the compiler now accepts the unique placeholder value as an alias while continuing to reject ambiguous or missing bindings. Because a required target remains unresolved, no canonical multiset comparison is claimed for the agent-led run.

## 2026-07-20 UI Job `8f39777c` Compile/Partial Repair

The browser submitted one 26-target durable job, not many agent jobs. It produced adaptive batches of 16, 8, and 2 targets with bounded Cortex concurrency two. Batches 0 and 1 overlapped; batch 2 began when one slot became available. All three batches carried the identical prepared context hash, all 26 rows of linked precedent `1101`, 21 graph nodes, one edge, and 22 semantic items.

Three deterministic defects were found and repaired:

1. SQL compilation ran after each partial mapping update and requested full precedent SQL restoration whenever all *currently mapped* rows accepted the same precedent. It now pauses while Auto-map is running and only requests precedent restoration when every target row is mapped and accepts the same precedent. A 24/26 result compiles through the current graph rather than incorrectly comparing 24 targets with the canonical 26-target contract.
2. The terminal partial for `OWNERID` and `LEGACY_ID__C` was empty because batch target names were unqualified while agent result keys were fully qualified. Partial extraction now matches normalized target leaf names, and the frontend reapplies the merged terminal response idempotently. `unresolved` proposals remain visibly unmapped for review.
3. The prepared graph had zero Value bindings even though precedent expressions required `$TransactionFirmID`, `$ParentOfficeID`, `$HHRecordType`, `$ClientStartDate`, `$LegacyHHcPrefix`, and `$BackupOwnerID`. Linked-precedent placeholders are now deterministically materialized as unresolved graph `ValueBinding` contracts before hashing and agent dispatch. The prepared context hash now includes the relation graph, preventing different source/value graphs from sharing a context hash.

Backend provenance validation now also rejects `accept_precedent` when the agent changes the precedent mapping mode, constant Value, or declared preprocessing contract; the inferred candidate is retained but marked unresolved for review. Polling remains one sequential GET for the same durable job, but the cadence is reduced to 2.5 seconds before the first partial and 1.5 seconds afterward. These GETs do not launch agent batches.

## 2026-07-21 Chat, Derived-Contract, and SQL Repair Update

- The mapping assistant now includes the last 30 completed user/assistant turns in structured workbench requests. Follow-ups can resolve a target mentioned in an earlier turn instead of treating each message as an isolated prompt.
- Explicit literal instructions such as setting `RECORDTYPEID` to `1001` produce a deterministic Value-binding proposal and the existing Apply Changes review card. They intentionally do not spend a transformation-agent call. Expression/rule updates are routed through the structured transformation path with the resolved target attributes and conversation context.
- Derived/CTE output contracts are authoritative at both Auto-map merge and SQL compilation. A response referencing a missing derived output is changed to `unresolved`, retains the proposed field only as a review candidate, and emits `AUTO_MAPPING_DERIVED_OUTPUT_NOT_FOUND`. The compiler independently rejects missing derived columns, including when it must infer the output contract from saved SQL.
- A missing required derived output does not silently mutate a saved derived source. The user must explicitly revise and revalidate that artifact through the derived-source workflow because changing it can alter grain, keys, and row counts.
- SQL validation/repair now sends the current relation graph, derived output contracts, and bounded saved derived SQL to Cortex Analyst. When validation fails, the response is classified as a repair, preserves the validation error, and presents the corrected SQL for comparison and explicit application.
- Run Preview is independently enabled. Without a prior validation review it executes the current compiled SQL directly; execution failures remain visible and recommend Validate SQL for a repair.
- Updated/deployed `AGT_SOURCE_MAPPING` hash: `7305680ead06485882e014c25d7ebc015fe019d3a8634c54392e2473fb2939c5`. `AGT_SEMANTIC_MODEL_V2` remains untouched.

Verification: 187 backend unit tests and 20 backend integration tests passed, frontend TypeScript passed, the mapping-agent manifest passed verification, and an in-app browser smoke test confirmed that Run Preview is clickable without a validation review and returns actionable feedback. The browser session did not contain the user's mapping `1401`, so its persisted rows still require an authenticated rerun; old invalid proposals are intentionally not rewritten in place.

Auto-map completion now also returns a structured `auto_mapping_review` rather than only a processed-target count. It reports mapped/unresolved totals, missing derived outputs, low-confidence mappings, and linked-precedent overrides. Each recommendation identifies the target, reason, candidate sources, evidence IDs, and the next UI action. The frontend adds this review as a persistent assistant message and unread notification, including explicit instructions to return to Source Selection, revise and revalidate the derived source, and rerun Auto-map when historical learning requires an output absent from the current contract. Verification after this addition: 188 backend unit tests, 20 integration tests, and frontend TypeScript passed.

Saved, draft, and partial mappings now restore the Mapping-page Source Selected and Target Selected trees without requiring the user to revisit and expand the catalog in Step 1. The hierarchy builder merges persisted attribute groups and flat selected-table fallbacks into the freshly loaded database catalog, whose schema lists are intentionally lazy. Selected physical table names therefore appear immediately while columns load. Selected derived sources are also included using persisted `output_columns` when preview columns are unavailable. Frontend TypeScript verification passed.
