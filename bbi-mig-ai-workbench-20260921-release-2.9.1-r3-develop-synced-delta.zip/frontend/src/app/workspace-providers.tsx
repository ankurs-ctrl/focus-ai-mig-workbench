"use client";

import type { ReactNode } from "react";
import { AiChatLayoutProvider } from "@/features/ai-agent/ai-chat-layout-context";
import { SttmBuilderProvider } from "@/features/sttm/context/sttm-builder-context";
import { AutoMapCompletionToast } from "@/features/sttm/mapping/auto-map-completion-toast";
import { TourOverlay, TourProvider } from "@/features/tour/engine";

export default function WorkspaceProviders({ children }: { children: ReactNode }) {
  return (
    <TourProvider>
      <SttmBuilderProvider>
        <AiChatLayoutProvider>
          {children}
          <TourOverlay />
          <AutoMapCompletionToast />
        </AiChatLayoutProvider>
      </SttmBuilderProvider>
    </TourProvider>
  );
}
