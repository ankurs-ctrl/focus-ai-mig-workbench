"""Export a scoped acceptance backup; SELECT only, never restores or mutates Snowflake."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/sttm-builder"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", required=True)
    parser.add_argument("--sttm-id", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if not args.output_dir.is_absolute() or args.output_dir.exists() or not args.output_dir.parent.is_dir():
        parser.error("Output must be a new absolute directory with an existing parent")
    from app.core.config import Settings
    from app.core.snowflake import SnowflakeClient
    settings = Settings(_env_file=args.env_file)
    client = SnowflakeClient(settings)
    try:
        table = settings.qualify_metadata_object_name
        mappings = client.session.sql(f"SELECT * FROM {table('TBL_STTM')} WHERE TO_VARCHAR(STTM_ID)=?",
                                      params=[args.sttm_id]).collect()
        if len(mappings) != 1:
            raise ValueError("Expected exactly one owned mapping record")
        mapping = mappings[0].as_dict()
        snapshots = client.session.sql(f"SELECT * FROM {table('TBL_WORKSPACE_SNAPSHOTS')} WHERE SNAPSHOT_ID=?",
                                       params=[mapping["LAST_SNAPSHOT_ID"]]).collect()
        if len(snapshots) != 1:
            raise ValueError("Current snapshot could not be backed up")
        versions = client.session.sql(f"SELECT * FROM {table('TBL_STTM_VERSIONS')} WHERE TO_VARCHAR(STTM_ID)=?",
                                      params=[args.sttm_id]).collect()
        backup = {"mapping": mapping, "snapshot": snapshots[0].as_dict(), "versions": [row.as_dict() for row in versions]}
        serialized = json.dumps(backup, ensure_ascii=False, sort_keys=True, default=str)
        args.output_dir.mkdir()
        (args.output_dir / "before.json").write_text(serialized, encoding="utf-8")
        (args.output_dir / "model-calls").mkdir()
        print(json.dumps({"sttm_id": args.sttm_id, "snapshot_id": mapping["LAST_SNAPSHOT_ID"],
                          "backup_sha256": hashlib.sha256(serialized.encode()).hexdigest(), "output_dir": str(args.output_dir)}))
    finally:
        client.close()


if __name__ == "__main__":
    main()