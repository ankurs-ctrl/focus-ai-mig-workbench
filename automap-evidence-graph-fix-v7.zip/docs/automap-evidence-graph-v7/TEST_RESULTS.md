# V7 offline verification

## Recorded results

- Broad selected backend regression suite: **2,342 passed**, 259.37 seconds. Includes Auto-map unit/integration tests, SQL-upload tests, proxy tests, spec-rendering and parallel UAT CI tests.
- Final focused backend run: **358 passed**, 43.89 seconds. It overlaps the broad suite; do not add the counts.
- Combined frontend scope/preservation/retry/acceptance run: **72 passed**. Both scripts run in one process so the shared preservation harness is counted once.
- TypeScript no-emit check: passed with no diagnostics.
- Assistant continuity harness: passed, including stream ingestion and terminal flush behavior.
- CRLF-aware Git whitespace check: passed. ZIP contents and per-file SHA-256 hashes are verified by the packaging script; the final archive SHA-256 is provided separately.

The broad run preceded the final cross-batch outcome aggregation, explicit retry-hint forwarding from request metadata into both preflight and execution, and added remaining-budget/proxy regression probes. The focused run covers those final changes. No source behavior was accepted merely by changing assertions: new tests exercise the real specialist/runtime/batch path, real frontend thunks and reducers, and production compiler code.

## Provenance and limits

New fixtures are synthetic. Native runtime tests use real application admission/archive/transport code with fake HTTP/model and Snowflake boundaries. The existing Ft. Pitt upload tests use actual authored SQL with a limited synthetic catalog; they are not an exact archived job replay. No production job exports, live Snowflake validation, actual model reasoning, browser acceptance or client latency measurement were available here. The offline snapshot replan helper is included for client Coco.

Passing these checks does not certify business mapping accuracy or 2–3 minute performance. Coco will review the ZIP, deploy through the existing client workflow, and perform live acceptance. No local Docker build, push, publication or target loading occurred.

## Windows AVD repeat commands

From the repository root with existing project Python and frontend dependencies installed:

```powershell
$env:PYTHONPATH = "services/sttm-builder"
$files = @(
  Get-ChildItem services/sttm-builder/tests/unit/core/test_automap*.py
  Get-ChildItem services/sttm-builder/tests/unit/core/test_sql_upload*.py
  Get-ChildItem services/sttm-builder/tests/test_automap*.py
  Get-Item services/sttm-builder/tests/unit/core/test_auto_mapping_proxy.py
  Get-Item services/sttm-builder/tests/unit/core/test_render_spcs_spec.py
  Get-Item services/sttm-builder/tests/unit/core/test_parallel_uat_ci.py
) | Sort-Object FullName -Unique | ForEach-Object FullName
python -m pytest -q $files
python -m pytest -q services/sttm-builder/tests/unit/core/test_automap_remaining_v7.py services/sttm-builder/tests/unit/core/test_automap_guarded_specialist.py services/sttm-builder/tests/unit/core/test_automap_admission_v6.py services/sttm-builder/tests/unit/core/test_automap_fast_batch.py services/sttm-builder/tests/unit/core/test_auto_mapping_proxy.py services/sttm-builder/tests/unit/core/test_automap_fast_context.py services/sttm-builder/tests/unit/core/test_automap_input_contract_v5.py
node -e "require('./frontend/scripts/test-automap-scope.cjs'); require('./frontend/scripts/test-automap-remaining-v7.cjs');"
node frontend/scripts/test-assistant-continuity.cjs
npx --prefix frontend tsc --project frontend/tsconfig.json --noEmit --incremental false
git -c core.whitespace=cr-at-eol diff --check
```

Review toolchain: Python 3.11, SQLGlot 30.12.0, existing frontend dependencies and PowerShell 7.5. Test-only local Python dependency paths, conda/readline workaround, temporary Node symlink, caches and shell runners are excluded from the ZIP. Existing secret env files remain authoritative; no new dependency, DB migration or configuration change is required.

Earlier exploratory V6 checks of the separate parallel-deployment environment-wrapper module encountered 16 macOS environment-restoration failures, reproduced on the unchanged V4 worktree. That module is outside the selected suite above; deployment scripts were not rewritten to mask those failures.
