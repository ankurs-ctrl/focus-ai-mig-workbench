'use client';

import { useEffect, useRef, useState, type MouseEvent } from 'react';
import { InputBase, Slider } from '@mui/material';
import { AiaBox, AiaIconButton, AiaMenu, AiaMenuItem, AiaPaper, AiaPopover, AiaSelect, AiaStack } from '@/components/ui';
import { AiaButton } from '@/components/ui/aia-button';
import { AIA_DATA_TABLE_FILTER_SELECT_SX } from '@/components/ui/aia-table/aia-data-table-styles';
import { textStyleCssVars } from '@/config/typography-tokens';
import { AiaText } from '@/components/ui/aia-text';
import type { MigrationEffort, MigrationRunMode } from '@/services/migrationAgentService';
import { AddRoundedIcon, AssignmentOutlinedIcon, NorthIcon, UploadFileRoundedIcon } from '@/utils/icons';
import MicNoneOutlinedIcon from '@mui/icons-material/MicNoneOutlined';
import StopCircleOutlinedIcon from '@mui/icons-material/StopCircleOutlined';
import BoltOutlinedIcon from '@mui/icons-material/BoltOutlined';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

export type AiChatMode = 'quick' | 'deep';

const MODE_OPTIONS = [
    { label: 'Quick Assistant', value: 'quick' },
    { label: 'Deep Agent', value: 'deep' },
];

const QUICK_MODE_OPTION = [
    { label: 'Quick Assistant', value: 'quick' },
];

const EFFORT_OPTIONS: Array<{ label: string; value: MigrationEffort }> = [
    { label: 'Light', value: 'light' }, { label: 'Medium', value: 'medium' }, { label: 'High', value: 'high' },
];

function displayModelName(name: string) {
    return name.replace(/_/g, ' ').replace(/-([a-z])/gi, ' $1').replace(/\b[a-z]/g, (letter) => letter.toUpperCase()).replace(/^Gpt\b/, 'GPT');
}

type SpeechResultEvent = { results: ArrayLike<{ isFinal: boolean; [index: number]: { transcript: string } }> };
type BrowserSpeechRecognition = {
    lang: string;
    continuous: boolean;
    interimResults: boolean;
    onresult: ((event: SpeechResultEvent) => void) | null;
    onerror: ((event: { error: string }) => void) | null;
    onend: (() => void) | null;
    start: () => void;
    stop: () => void;
    abort: () => void;
};

type AiChatComposerProps = {
    value: string;
    onChange: (value: string) => void;
    onSend: () => void;
    mode: AiChatMode;
    onModeChange: (mode: AiChatMode) => void;
    effort: MigrationEffort;
    onEffortChange: (effort: MigrationEffort) => void;
    modelName: string | null;
    onModelNameChange: (modelName: string | null) => void;
    modelOptions?: string[];
    effortModelDefaults?: Record<string, string>;
    runMode: MigrationRunMode;
    onRunModeChange: (mode: MigrationRunMode) => void;
    deepAgentAvailable?: boolean;
    onAttachFile?: (file: File) => void;
    attachmentUploading?: boolean;
    running?: boolean;
    cancelling?: boolean;
    onCancel?: () => void;
    disabled?: boolean;
    loading?: boolean;
};

export function AiChatComposer({
    value,
    onChange,
    onSend,
    mode,
    onModeChange,
    effort,
    onEffortChange,
    modelName,
    onModelNameChange,
    modelOptions = [],
    effortModelDefaults = {},
    runMode,
    onRunModeChange,
    deepAgentAvailable = false,
    onAttachFile,
    attachmentUploading = false,
    running = false,
    cancelling = false,
    onCancel,
    disabled = false,
    loading = false,
}: AiChatComposerProps) {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const recognitionRef = useRef<BrowserSpeechRecognition | null>(null);
    const onChangeRef = useRef(onChange);
    const baseDraftRef = useRef('');
    const finalTranscriptRef = useRef('');
    const latestTranscriptRef = useRef('');
    const [addAnchor, setAddAnchor] = useState<HTMLElement | null>(null);
    const [modelAnchor, setModelAnchor] = useState<HTMLElement | null>(null);
    const [choosingModel, setChoosingModel] = useState(false);
    const [listening, setListening] = useState(false);
    const [speechError, setSpeechError] = useState('');
    useEffect(() => { onChangeRef.current = onChange; }, [onChange]);
    useEffect(() => () => {
        const recognition = recognitionRef.current;
        if (recognition) {
            recognition.onresult = null;
            recognition.onerror = null;
            recognition.onend = null;
            recognition.abort();
        }
    }, []);

    const toggleDictation = () => {
        if (listening) {
            recognitionRef.current?.stop();
            return;
        }
        const speechWindow = window as typeof window & {
            SpeechRecognition?: new () => BrowserSpeechRecognition;
            webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
        };
        const Recognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
        if (!Recognition) {
            setSpeechError('Speech dictation is unavailable in this browser. Try Chrome or Edge.');
            return;
        }
        const recognition = new Recognition();
        recognitionRef.current = recognition;
        baseDraftRef.current = value.trim();
        finalTranscriptRef.current = '';
        latestTranscriptRef.current = '';
        setSpeechError('');
        recognition.lang = navigator.language || 'en-US';
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.onresult = (event) => {
            const finalParts: string[] = [];
            const interimParts: string[] = [];
            for (let index = 0; index < event.results.length; index += 1) {
                const result = event.results[index];
                const transcript = result[0]?.transcript?.trim();
                if (!transcript) continue;
                (result.isFinal ? finalParts : interimParts).push(transcript);
            }
            finalTranscriptRef.current = finalParts.join(' ');
            latestTranscriptRef.current = [finalTranscriptRef.current, interimParts.join(' ')].filter(Boolean).join(' ');
            onChangeRef.current([baseDraftRef.current, latestTranscriptRef.current].filter(Boolean).join(' '));
        };
        recognition.onerror = (event) => {
            setSpeechError(event.error === 'not-allowed' ? 'Microphone access was denied.'
                : event.error === 'no-speech' ? 'No speech was detected. Try again.'
                : `Dictation stopped: ${event.error}.`);
        };
        recognition.onend = () => {
            onChangeRef.current([baseDraftRef.current, latestTranscriptRef.current].filter(Boolean).join(' '));
            recognitionRef.current = null;
            setListening(false);
        };
        try {
            recognition.start();
            setListening(true);
        } catch {
            recognitionRef.current = null;
            setSpeechError('Could not start microphone dictation. Check browser permissions.');
        }
    };

    const editDraft = (nextValue: string) => {
        const recognition = recognitionRef.current;
        if (recognition) {
            recognition.onresult = null;
            recognition.onerror = null;
            recognition.onend = null;
            recognition.abort();
            recognitionRef.current = null;
            setListening(false);
        }
        onChange(nextValue);
    };

    const canSend = !loading && !disabled && !listening && value.trim().length > 0;
    const canAttach = deepAgentAvailable && Boolean(onAttachFile) && !attachmentUploading && !running && !disabled && !loading;
    const selectedEffort = effort === 'auto' ? 'medium' : effort;
    const effortIndex = EFFORT_OPTIONS.findIndex((option) => option.value === selectedEffort);
    const effectiveModel = modelName || effortModelDefaults[selectedEffort] || modelOptions[0] || '';
    const shownModel = effectiveModel ? displayModelName(effectiveModel) : 'Select model';

    return (
        <AiaBox sx={{ flexShrink: 0 }}>
            <AiaPaper
                elevation={0}
                sx={{
                    p: 1.5,
                    borderRadius: '16px',
                    backgroundColor: '#ffffff',
                    border: '1px solid #d1d5db',
                    boxShadow: '0 1px 2px rgba(15, 23, 42, 0.04)',
                }}
            >
                <InputBase
                    multiline
                    minRows={1}
                    maxRows={5}
                    value={value}
                    onChange={(event) => editDraft(event.target.value)}
                    onKeyDown={(event) => {
                        if (event.key === 'Enter' && !event.shiftKey) {
                            event.preventDefault();
                            if (canSend) onSend();
                        }
                    }}
                    placeholder="Ask a question or describe a migration…"
                    disabled={disabled || loading}
                    fullWidth
                    sx={{
                        width: '100%',
                        ...textStyleCssVars('body'),
                        alignItems: 'flex-start',
                        '& .MuiInputBase-input': {
                            padding: 0,
                            minHeight: 45,
                            fontSize: 'inherit',
                            fontWeight: 'inherit',
                            lineHeight: 'inherit',
                            color: 'inherit',
                        },
                        '& .MuiInputBase-input::placeholder': {
                            color: '#94a3b8',
                            opacity: 1,
                        },
                    }}
                />

                <AiaStack
                    direction="row"
                    spacing={0.75}
                    sx={{
                        mt: 0.75,
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        flexWrap: 'wrap',
                        rowGap: 0.75,
                    }}
                >
                    <AiaStack
                        direction="row"
                        spacing={0.75}
                        sx={{ alignItems: 'center', minWidth: 0, flexWrap: 'wrap', rowGap: 0.75 }}
                    >
                        <AiaIconButton
                            size="small"
                            aria-label="Add attachments or plan mode"
                            title="Add attachments or plan mode"
                            aria-expanded={Boolean(addAnchor)}
                            aria-haspopup="menu"
                            onClick={(event) => setAddAnchor(event.currentTarget)}
                            sx={{
                                width: 38,
                                height: 38,
                                border: '1px solid #e2e8f0',
                                borderRadius: '50%',
                                color: '#475569',
                                backgroundColor: '#ffffff',
                                flexShrink: 0,
                                '&:hover': { backgroundColor: '#f8fafc' },
                            }}
                        >
                            <AddRoundedIcon sx={{ fontSize: 22 }} />
                        </AiaIconButton>
                        <input
                            ref={fileInputRef}
                            hidden
                            type="file"
                            accept=".sql,.xlsx,.csv,.json,.yaml,.yml,.txt,.md,.docx,.pdf,.srt,.vtt"
                            onChange={(event) => {
                                const file = event.target.files?.[0];
                                if (file) onAttachFile?.(file);
                                event.target.value = '';
                            }}
                        />

                        <AiaSelect
                            value={mode ?? 'quick'}
                            options={deepAgentAvailable ? MODE_OPTIONS : QUICK_MODE_OPTION}
                            menuItemSx={{ fontSize: 12.5, py: 0.8, '& .MuiListItemText-primary': { fontSize: 12.5, lineHeight: 1.4 } }}
                            menuPlacement="above"
                            onChange={(next) =>
                                onModeChange((Array.isArray(next) ? next[0] : next) as AiChatMode)
                            }
                            disabled={disabled || loading}
                            fullWidth={false}
                            size="small"
                            sx={{
                                ...AIA_DATA_TABLE_FILTER_SELECT_SX,
                                width: 'auto',
                                minWidth: 136,
                                '& .MuiSelect-select': { ...AIA_DATA_TABLE_FILTER_SELECT_SX['& .MuiSelect-select'], fontSize: 12.5 },
                            }}
                        />
                    </AiaStack>

                    <AiaStack direction="row" spacing={0.5} sx={{ alignItems: 'center', minWidth: 0, ml: 'auto !important' }}>
                    {mode === 'deep' ? <AiaBox component="button" type="button"
                        aria-label={`Model ${shownModel}, effort ${EFFORT_OPTIONS[effortIndex]?.label ?? 'Medium'}`}
                        aria-haspopup="dialog"
                        aria-expanded={Boolean(modelAnchor)}
                        disabled={disabled || loading || running}
                        onClick={(event: MouseEvent<HTMLElement>) => { setChoosingModel(false); setModelAnchor(event.currentTarget); }}
                        sx={{ display: 'flex', alignItems: 'center', gap: 0.5, minWidth: 0, maxWidth: 210, px: 1, py: 0.7, border: 'none', borderRadius: '999px', backgroundColor: 'transparent', color: '#334155', cursor: 'pointer', fontSize: 12.5, whiteSpace: 'nowrap', '&:hover': { backgroundColor: '#f1f5f9' } }}>
                        <AiaBox component="span" sx={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{shownModel} <AiaBox component="span" sx={{ color: '#64748b' }}>{EFFORT_OPTIONS[effortIndex]?.label ?? 'Medium'}</AiaBox></AiaBox>
                        <KeyboardArrowDownIcon sx={{ fontSize: 17, flexShrink: 0 }} />
                    </AiaBox> : null}
                    <AiaIconButton
                        size="small" aria-label={listening ? 'Stop dictation' : 'Dictate message'}
                        title={listening ? 'Stop dictation' : 'Dictate with microphone'}
                        aria-pressed={listening}
                        disabled={disabled || loading || running}
                        onClick={toggleDictation}
                        sx={{ width: 38, height: 38, color: listening ? '#dc2626' : '#64748b', borderRadius: '50%', '&:hover': { backgroundColor: '#f1f5f9' } }}>
                        {listening ? <StopCircleOutlinedIcon sx={{ fontSize: 22 }} /> : <MicNoneOutlinedIcon sx={{ fontSize: 22 }} />}
                    </AiaIconButton>
                    {running && onCancel ? (
                        <AiaButton
                            size="small"
                            variant="outlined"
                            onClick={onCancel}
                            disabled={cancelling}
                            sx={{ minWidth: 52, borderRadius: '999px', textTransform: 'none' }}
                        >
                            {cancelling ? 'Stopping…' : 'Stop'}
                        </AiaButton>
                    ) : (
                        <AiaIconButton
                            size="small"
                            aria-label="Send message"
                            onClick={() => onSend()}
                            disabled={!canSend}
                            sx={{
                                width: 38,
                                height: 38,
                                p: 0,
                                color: '#ffffff',
                                backgroundColor: canSend ? 'var(--color-primary, #0073a0)' : '#cbd5e1',
                                borderRadius: '50%',
                                flexShrink: 0,
                                boxShadow: canSend ? '0 1px 2px rgba(0, 115, 160, 0.28)' : 'none',
                                '&:hover': {
                                    backgroundColor: canSend ? 'var(--color-primary, #0073a0)' : '#cbd5e1',
                                },
                                '&.Mui-disabled': {
                                    color: '#ffffff',
                                    backgroundColor: '#cbd5e1',
                                },
                            }}
                        >
                            <NorthIcon sx={{ fontSize: 22 }} />
                        </AiaIconButton>
                    )}
                    </AiaStack>
                </AiaStack>
            </AiaPaper>

            {speechError ? <AiaText role="alert" sx={{ mt: 0.6, px: 0.75, fontSize: 11, color: '#b91c1c' }}>{speechError}</AiaText> : null}
            {listening ? <AiaText role="status" sx={{ mt: 0.6, px: 0.75, fontSize: 11, color: '#475569' }}>Listening… type to stop dictation and edit, or tap the microphone to finish.</AiaText> : null}
            <AiaMenu anchorEl={addAnchor} open={Boolean(addAnchor)} onClose={() => setAddAnchor(null)} anchorOrigin={{ vertical: 'top', horizontal: 'left' }} transformOrigin={{ vertical: 'bottom', horizontal: 'left' }} sx={{ zIndex: 1600 }} slotProps={{ paper: { sx: { minWidth: 200, borderRadius: 2, border: '1px solid #e2e8f0', boxShadow: '0 10px 30px rgba(15,23,42,0.16)' } } }}>
                <AiaMenuItem sx={{ fontSize: 12.5, py: 0.9 }} disabled={!canAttach} onClick={() => { if (mode !== 'deep') onModeChange('deep'); setAddAnchor(null); fileInputRef.current?.click(); }}>
                    <UploadFileRoundedIcon sx={{ fontSize: 18, mr: 1 }} />{mode === 'deep' ? 'Attach file' : 'Attach file in Deep Agent'}
                </AiaMenuItem>
                <AiaMenuItem sx={{ fontSize: 12.5, py: 0.9 }} disabled={!deepAgentAvailable || disabled || loading || running} onClick={() => {
                    if (mode !== 'deep') onModeChange('deep');
                    onRunModeChange(runMode === 'plan' && mode === 'deep' ? 'auto' : 'plan');
                    setAddAnchor(null);
                }}>
                    <AssignmentOutlinedIcon sx={{ fontSize: 18, mr: 1 }} />{runMode === 'plan' && mode === 'deep' ? 'Turn plan mode off' : 'Plan mode'}
                </AiaMenuItem>
            </AiaMenu>
            <AiaPopover
                anchorEl={modelAnchor}
                open={Boolean(modelAnchor)}
                onClose={() => { setModelAnchor(null); setChoosingModel(false); }}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                transformOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                sx={{ zIndex: 1600 }}
                slotProps={{ paper: { sx: { width: 300, maxWidth: 'calc(100vw - 24px)', p: 2, borderRadius: 3, border: '1px solid #dbe2ea', boxShadow: '0 12px 32px rgba(15,23,42,0.18)' } } }}
            >
                {choosingModel ? <>
                    <AiaBox component="button" type="button" onClick={() => setChoosingModel(false)} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, border: 0, background: 'transparent', color: '#475569', cursor: 'pointer', p: 0.5, mb: 1, fontSize: 12.5 }}><ArrowBackIcon sx={{ fontSize: 17 }} /> Models</AiaBox>
                    {modelOptions.length ? modelOptions.map((option) => <AiaBox component="button" type="button" key={option} onClick={() => { onModelNameChange(option); setChoosingModel(false); }} sx={{ width: '100%', textAlign: 'left', px: 1.2, py: 1, mb: 0.3, border: 0, borderRadius: 1.5, backgroundColor: effectiveModel === option ? '#eaf3ff' : 'transparent', color: '#1e293b', cursor: 'pointer', fontSize: 12.5, '&:hover': { backgroundColor: '#f1f5f9' } }}>{displayModelName(option)}</AiaBox>) : <AiaText sx={{ px: 1, py: 1, color: '#64748b', fontSize: 12.5 }}>No models are configured.</AiaText>}
                </> : <>
                    <AiaStack direction="row" sx={{ alignItems: 'center', justifyContent: 'space-between' }}>
                        <BoltOutlinedIcon sx={{ color: '#64748b', fontSize: 21 }} />
                        <AiaText sx={{ fontSize: 17, fontWeight: 700, color: '#2563eb' }}>{EFFORT_OPTIONS[effortIndex]?.label ?? 'Medium'}</AiaText>
                        <AiaIconButton aria-label="Reset model and effort" size="small" onClick={() => { onModelNameChange(null); onEffortChange('medium'); }}><RestartAltIcon sx={{ fontSize: 20 }} /></AiaIconButton>
                    </AiaStack>
                    <AiaBox component="button" type="button" onClick={() => setChoosingModel(true)} sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', mt: 0.2, mb: 1.2, border: 0, background: 'transparent', color: '#475569', cursor: 'pointer', fontSize: 12.5 }}>
                        {shownModel}<ChevronRightIcon sx={{ fontSize: 18 }} />
                    </AiaBox>
                    <Slider value={Math.max(0, effortIndex)} min={0} max={2} step={1} marks aria-label="Effort level" valueLabelDisplay="off" onChange={(_, next) => onEffortChange(EFFORT_OPTIONS[next as number].value)} sx={{ mx: 1, width: 'calc(100% - 16px)', color: '#2563eb', '& .MuiSlider-mark': { width: 6, height: 6, borderRadius: '50%' }, '& .MuiSlider-thumb': { width: 22, height: 22, backgroundColor: '#fff', boxShadow: '0 1px 5px rgba(15,23,42,0.25)' } }} />
                </>}
            </AiaPopover>

            <AiaText sx={{ mt: 1, textAlign: 'center', fontSize: 11, color: '#94a3b8' }}>
                STTM AI can make mistakes. Double-check responses.
            </AiaText>
        </AiaBox>
    );
}
