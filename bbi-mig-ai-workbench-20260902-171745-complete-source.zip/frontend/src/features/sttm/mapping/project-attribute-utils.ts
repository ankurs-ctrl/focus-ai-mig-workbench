import type { ProjectAttributeRecord } from '@/services/projectService';

export const STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT = 'sttm:project-attributes-changed';

export function notifyProjectAttributesChanged(projectId: string) {
  if (typeof window === 'undefined') {
    return;
  }
  window.dispatchEvent(
    new CustomEvent(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, {
      detail: { projectId },
    }),
  );
}

function readField(
  raw: Record<string, unknown>,
  keys: string[],
): string {
  for (const key of keys) {
    const value = raw[key];
    if (value != null && String(value).trim()) {
      return String(value).trim();
    }
  }
  return '';
}

export function normalizeProjectAttributeRecord(
  raw: unknown,
): ProjectAttributeRecord | null {
  if (!raw || typeof raw !== 'object') {
    return null;
  }

  const record = raw as Record<string, unknown>;
  const attribute_name = readField(record, [
    'attribute_name',
    'ATTRIBUTE_NAME',
    'attributeName',
  ]);
  if (!attribute_name) {
    return null;
  }

  const status = readField(record, ['status', 'STATUS']) || 'ACTIVE';
  if (status.toUpperCase() === 'INACTIVE') {
    return null;
  }

  return {
    attribute_id: readField(record, ['attribute_id', 'ATTRIBUTE_ID', 'attributeId']),
    project_id: readField(record, ['project_id', 'PROJECT_ID', 'projectId']),
    project_name: readField(record, ['project_name', 'PROJECT_NAME', 'projectName']) || null,
    attribute_name,
    attribute_type: readField(record, ['attribute_type', 'ATTRIBUTE_TYPE', 'attributeType']) || 'VARCHAR',
    attribute_value: readField(record, ['attribute_value', 'ATTRIBUTE_VALUE', 'attributeValue']),
    source_project_id:
      readField(record, ['source_project_id', 'SOURCE_PROJECT_ID', 'sourceProjectId']) || null,
    source_project_name:
      readField(record, ['source_project_name', 'SOURCE_PROJECT_NAME', 'sourceProjectName']) || null,
    source_attribute_id:
      readField(record, ['source_attribute_id', 'SOURCE_ATTRIBUTE_ID', 'sourceAttributeId']) || null,
    status,
    created_by: readField(record, ['created_by', 'CREATED_BY', 'createdBy']) || null,
    updated_by: readField(record, ['updated_by', 'UPDATED_BY', 'updatedBy']) || null,
    created_at: readField(record, ['created_at', 'CREATED_AT', 'createdAt']) || null,
    updated_at: readField(record, ['updated_at', 'UPDATED_AT', 'updatedAt']) || null,
  };
}

export function belongsToProject(
  attribute: Pick<ProjectAttributeRecord, 'project_id'>,
  projectId: string | null | undefined,
): boolean {
  const normalizedProjectId = projectId?.trim().toLowerCase();
  const attributeProjectId = attribute.project_id?.trim().toLowerCase();
  if (!normalizedProjectId || !attributeProjectId) {
    return false;
  }
  return attributeProjectId === normalizedProjectId;
}

export function filterAttributesForProject(
  attributes: ProjectAttributeRecord[],
  projectId: string | null | undefined,
): ProjectAttributeRecord[] {
  const normalizedProjectId = projectId?.trim();
  if (!normalizedProjectId) {
    return [];
  }

  return attributes.filter((attribute) => belongsToProject(attribute, normalizedProjectId));
}

export function normalizeProjectAttributeRecords(
  payload: unknown,
  projectId?: string | null,
): ProjectAttributeRecord[] {
  const rows = Array.isArray(payload)
    ? payload
    : payload && typeof payload === 'object' && Array.isArray((payload as { items?: unknown[] }).items)
      ? (payload as { items: unknown[] }).items
      : [];

  const normalized = rows
    .map((row) => normalizeProjectAttributeRecord(row))
    .filter((row): row is ProjectAttributeRecord => Boolean(row));

  return filterAttributesForProject(normalized, projectId)
    .sort((left, right) => left.attribute_name.localeCompare(right.attribute_name));
}

export function toProjectAttributeSelectOptions(
  attributes: ProjectAttributeRecord[],
): Array<{ label: string; value: string }> {
  return attributes.map((attribute) => ({
    label: attribute.attribute_name,
    value: attribute.attribute_name,
  }));
}
