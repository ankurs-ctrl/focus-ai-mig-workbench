"""Portable deployment renderer, gated configuration and frozen context setup."""

from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json
import zipfile
import pytest
from scripts.render_automap_native import render
from app.core.automap_native_contract import build_snapshot, encoded, identifier_key
from tests.unit.core.test_automap_native_tools import (
    system,
    MemoryStore,
    call,
    proposal,
    read_required,
    HANDLE,
)
from tests.unit.core.test_automap_fast_context import fast_payload, add_table
from tests.unit.core.test_automap_fast_batch import prepared_request
from app.core.automap_native_tools import NativeTools, NativeToolError


def test_renderer_outputs_versioned_specs_bounded_string_tools_and_caller_rights(
    tmp_path,
):
    result = render("d.meta", "auto_wh", "app_role", "d.meta.code", tmp_path)
    sql = (tmp_path / "install.sql").read_text()
    assert "OR REPLACE" not in sql.split("\n", 1)[1]
    assert (
        sql.count("RETURNS VARCHAR LANGUAGE PYTHON") == 9
        and sql.count("EXECUTE AS CALLER") == 9
    )
    assert "REQUEST_JSON VARCHAR" in sql and "REQUEST_JSON OBJECT" not in sql
    assert (
        "RAP_AUTOMAP_NATIVE_CALLER" in sql
        and "WHERE" not in sql.split("CREATE CORTEX SEARCH SERVICE")[1].split(";")[0]
    )
    source = json.loads((tmp_path / "agent-source.json").read_text())
    rule = json.loads((tmp_path / "agent-rule.json").read_text())
    assert len(source["tools"]) == 7 and len(rule["tools"]) == 4
    assert rule["tool_resources"]["ValidateProposal"]["identifier"].endswith(
        "VALIDATE_RULE"
    )
    assert all(
        item["input_schema"]["properties"]["request_json"]["type"] == "string"
        for tool in source["tools"]
        for item in [tool["tool_spec"]]
    )
    assert (
        json.loads((tmp_path / "configuration.json").read_text())[
            "AUTOMAP_NATIVE_TOOLS_V1"
        ]
        is False
    )
    with zipfile.ZipFile(tmp_path / "automap_native_runtime.zip") as archive:
        assert archive.testzip() is None
        assert "app/core/automap_native_tools.py" in archive.namelist()
        assert not any(
            name.endswith(".env") or "__pycache__" in name or "\\" in name
            for name in archive.namelist()
        )
    again = render("D.META", "AUTO_WH", "APP_ROLE", "D.META.CODE", tmp_path)
    assert again == result


@pytest.mark.parametrize(
    "field,value",
    [
        ("metadata", "D.S;DROP TABLE T"),
        ("role", "APP ROLE"),
        ("stage", "D.S.X/../../env"),
        ("warehouse", '"odd"'),
    ],
    ids=["sql-injection", "role-space", "stage-path", "quoted-warehouse"],
)
def test_renderer_rejects_noncanonical_deployment_names(tmp_path, field, value):
    args = dict(
        metadata="D.META",
        warehouse="WH",
        role="APP",
        stage="D.META.CODE",
        output=tmp_path,
    )
    args[field] = value
    with pytest.raises(ValueError):
        render(**args)


def test_narrow_cte_exposes_outputs_while_600_parent_columns_remain_audit_only():
    value = fast_payload()
    add_table(value, columns=600, size=500)
    node = value["context"]["relation_graph"]["nodes"][0]
    node.update(
        kind="DERIVED_SOURCE",
        sql_text="SELECT OTHER0 AS X47 FROM D.S.UNUSED",
        parent_relation_ids=["UNUSED"],
    )
    req = prepared_request(value)
    with pytest.raises(ValueError, match="validation proofs"):
        build_snapshot(req, validated_derived={})
    snapshot = build_snapshot(req, validated_derived={"a": "synthetic-server-proof"})
    assert (
        len(snapshot["sources"]) == 1
        and next(iter(snapshot["sources"].values()))["source_ref"] == "a.X47"
    )
    assert node["sql_text"] in encoded(snapshot["request"])
    assert any(
        record["kind"] == "lineage_column" for record in snapshot["records"].values()
    )


def test_native_self_join_candidates_remain_distinct():
    value = fast_payload()
    node = value["context"]["relation_graph"]["nodes"][0]
    other = deepcopy(node)
    other.update(relation_id="b", alias="b")
    value["context"]["relation_graph"]["nodes"].append(other)
    value["context"]["relation_graph"]["edges"].append(
        {
            "edge_id": "self",
            "left_relation_id": "a",
            "right_relation_id": "b",
            "conditions": [{"left_column": "X47", "right_column": "X47"}],
        }
    )
    snap = build_snapshot(prepared_request(value), validated_derived={})
    assert {item["source_ref"] for item in snap["sources"].values()} == {
        'a."X47"',
        'b."X47"',
    }
    assert len(snap["sources"]) == 2


def test_analyst_observation_becomes_a_returned_exact_evidence_node():
    req, snap, store, tools = system()
    store.row["SNAPSHOT"]["bundle"] = {
        "id": "bundle",
        "hash": "hash",
        "coverage_validated": True,
    }
    tools.analyst = lambda *a: {
        "status": "executed",
        "data_result_obtained": True,
        "query_id": "q1",
        "rows": [{"N": 2}],
        "bundle": {"id": "bundle", "hash": "hash"},
    }
    result = call(
        tools,
        snap,
        "AskPreparedAnalyst",
        {"binding_ids": list(snap["sources"])},
        question="How many rows?",
    )
    identity = result["evidence_id"]
    state = store.row["STATE"]
    assert identity in state["canonical_records"] and state["reads"][identity]
    assert not state["proposals"]  # observed rows do not decide a mapping


def test_partial_verified_excerpts_and_current_deficits_survive_a_working_window():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    source = next(iter(snap["sources"].values()))
    call(
        tools,
        snap,
        "ReadEvidence",
        {"evidence_ids": [source["evidence_id"]], "page_bytes": 8192},
    )
    item = proposal(snap, target)
    result = call(tools, snap, "ValidateProposal", item)
    assert result["code"] == "missing_exact_evidence"
    from app.core.automap_native import continuation_packet

    packet = json.loads(
        continuation_packet(
            snap,
            HANDLE,
            store.row["STATE"],
            SimpleNamespace(
                agent_outbound_message_max_chars=180000,
                agent_outbound_message_max_bytes=180000,
            ),
        )[0]["content"][0]["text"]
    )
    assert packet["verified_excerpts"][target]["excerpts"][0]["quote"] == "X47"
    assert packet["current_deficits"][target]["code"] == "missing_exact_evidence"
    assert not store.row["STATE"]["proposals"]


def test_agent_sql_literal_preserves_embedded_json_backslashes_and_quotes():
    from scripts.render_automap_native import literal
    from sqlglot import parse_one

    text = json.dumps(
        {"instructions": 'Read a."Exact". Keep \\n literal. Don\'t alter SQL.'}
    )
    parsed = parse_one("SELECT " + literal(text), read="snowflake")
    assert parsed.expressions[0].this == text


@pytest.mark.parametrize("kind", ["DERIVED_SOURCE", "CTE"], ids=["derived", "cte"])
def test_native_cte_kind_cannot_bypass_current_validation_proof(kind):
    value = fast_payload()
    value["context"]["relation_graph"]["nodes"][0].update(
        kind=kind, sql_text="SELECT X47 FROM D.S.A"
    )
    req = prepared_request(value)
    with pytest.raises(ValueError, match="validation proofs"):
        build_snapshot(req, validated_derived={})


def test_snowflake_update_acknowledgement_handles_multijoin_diagnostic_count():
    from app.core.automap_native_store import affected

    assert affected(
        [{"number of rows updated": 1, "number of multi-joined rows updated": 0}]
    )
    assert not affected(
        [{"number of rows updated": 1, "number of multi-joined rows updated": 1}]
    )
    assert not affected(
        [{"number of rows updated": 0, "number of multi-joined rows updated": 0}]
    )
    assert not affected(
        [{"number of rows updated": 2, "number of multi-joined rows updated": 0}]
    )
    assert not affected([{"number of rows updated": 1}, {"number of rows updated": 1}])


def test_every_registered_tool_describes_exact_nested_contract(tmp_path):
    render("D.META", "WH", "APP", "D.META.CODE", tmp_path)
    template = json.loads(
        (
            Path(__file__).resolve().parents[5]
            / "infra/snowflake/automap_native_v1/agent-template.json"
        ).read_text()
    )
    for kind in ("source", "rule"):
        specification = json.loads((tmp_path / ("agent-" + kind + ".json")).read_text())
        for tool in specification["tools"]:
            spec = tool["tool_spec"]
            example = template["tools"][spec["name"]]["request_example"]
            assert set(example) == {
                "job_handle",
                "snapshot_hash",
                "target_ids",
                "question",
                "params",
            }
            assert isinstance(example["params"], dict) and example["target_ids"]
            assert "inside params" in spec["description"]
            assert (
                "target_ids is mandatory"
                in spec["input_schema"]["properties"]["request_json"]["description"]
            )


def test_current_business_guidance_is_required_exact_evidence():
    value = fast_payload()
    intent = (
        "Retain scheduled future payments; never substitute completed deal activity."
    )
    value["context"]["mapping_intent"] = {"intent": intent}
    req = prepared_request(value)
    snap = build_snapshot(req, validated_derived={})
    ids = [
        identity
        for identity in snap["mandatory_evidence"]
        if snap["records"][identity]["kind"] == "current_business_guidance"
    ]
    assert len(ids) == 1 and intent in encoded(snap["records"][ids[0]])
    tools = NativeTools(MemoryStore(snap))
    target = next(iter(snap["targets"]))
    assert ids[0] in tools._required(snap, target, [])
