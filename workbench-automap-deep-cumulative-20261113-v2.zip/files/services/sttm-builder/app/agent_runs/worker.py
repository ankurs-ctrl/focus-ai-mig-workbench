from __future__ import annotations

import json
import logging
import threading
import time
from datetime import UTC, datetime
from collections.abc import Callable
from typing import Any
from uuid import uuid4

from langgraph.types import Command

from app.agent_runtime.execution import BudgetExceededError, ExecutionLeaseLostError, EffortPromotionRequested
from app.agent_runtime.interface import AgentRuntime, RuntimeInvocation
from app.agent_runs.models import AgentReviewItem, AgentRunStep, MappingDagNode, ReviewItemStatus, RunStatus, StepStatus
from app.agent_runs.repository import AgentRunRepository
from app.agent_runs.service import AgentRunService
from app.migration_workflow.manifest import build_manifest
from app.agent_evaluation import AgentEvaluationHarness

logger = logging.getLogger(__name__)


def _exception_chain_contains(error: BaseException, expected: type[BaseException]) -> bool:
    seen: set[int] = set()
    current: BaseException | None = error
    while current is not None and id(current) not in seen:
        if isinstance(current, expected):
            return True
        seen.add(id(current))
        current = current.__cause__ or current.__context__
    return False


def _budget_phase_made_progress(run: Any) -> bool:
    grant = run.budget_grants[-1] if run.budget_grants else {}
    if run.model_calls_used > int(grant.get("model_offset", 0)):
        return True
    if run.tool_calls_used > int(grant.get("tool_offset", 0)):
        return True
    category_offsets = dict(grant.get("category_offsets") or {})
    return any(
        int(used or 0) > int(category_offsets.get(category, 0) or 0)
        for category, used in dict(run.category_usage or {}).items()
    )


def _validated_high_confidence_candidates(
    mapping_results: list[dict[str, Any]],
    threshold: float,
) -> set[tuple[str, str]]:
    approved: set[tuple[str, str]] = set()
    for mapping in mapping_results:
        validation = dict(mapping.get("sql_validation") or {})
        if validation.get("compile_valid") is not True or validation.get("preview_valid") is not True:
            continue
        sttm_id = str(mapping.get("sttm_id") or "")
        for row in mapping.get("mapping_rows") or []:
            confidence = row.get("confidence")
            target_column = str(row.get("target_column") or "").upper()
            if (
                sttm_id
                and target_column
                and str(row.get("status") or "").lower() == "draft"
                and isinstance(confidence, (int, float))
                and confidence >= threshold
            ):
                approved.add((sttm_id, target_column))
    return approved


def _mapping_step_status(raw_status: str) -> StepStatus:
    """A mapping-result status (the broader ``READY_FOR_REVIEW``/``NEEDS_REVIEW`` vocabulary)
    translated to the narrower per-step DAG status.

    A mapping that compiled, previewed and reconciled cleanly is ``READY_FOR_REVIEW``
    at the mapping-result level, which has no literal counterpart in ``StepStatus``
    (that enum's closest meaning is ``SUCCEEDED``). Any other unrecognized value is
    treated as needing review rather than raising, so one odd status string cannot
    crash the whole run's finalization after real drafts were already saved.
    """
    if raw_status == "READY_FOR_REVIEW":
        return StepStatus.SUCCEEDED
    if raw_status in StepStatus.__members__:
        return StepStatus(raw_status)
    return StepStatus.NEEDS_REVIEW


def _lease_is_definitively_lost(
    current: Any | None,
    *,
    worker_id: str,
    seconds_since_confirmed_renewal: float,
    lease_seconds: int,
    generation: int | None = None,
) -> bool:
    """Separate an ownership change from a transient heartbeat failure.

    A failed Snowflake statement is not evidence that the lease changed hands.
    Ownership is lost only when durable state names another owner (including a
    released lease), or when no renewal has been confirmed for the full lease
    duration. This keeps the safety boundary aligned with the lease stored in
    Snowflake instead of an unrelated fixed retry count.
    """
    if current is not None and current.lease_owner != worker_id:
        return True
    if current is not None and generation is not None and current.lease_generation != generation:
        return True
    return seconds_since_confirmed_renewal >= lease_seconds


class AgentWorker:
    """Leased durable worker; browser connections never own execution."""

    def __init__(
        self,
        repository: AgentRunRepository,
        workflow: Any,
        *,
        worker_id: str,
        lease_seconds: int = 120,
        heartbeat_seconds: int = 30,
        workflow_factory: Callable[[Any], tuple[Any, Callable[[], None]]] | None = None,
        runtime_factory: Callable[[Any], tuple[AgentRuntime, Callable[[], None]]] | None = None,
        heartbeat_repository: AgentRunRepository | None = None,
        outbox_recovery_interval_seconds: int = 60,
        outbox_recovery_batch_size: int = 25,
    ) -> None:
        self.repository = repository
        self.service = AgentRunService(repository)
        self.workflow = workflow
        self.worker_id = worker_id
        self.lease_seconds = lease_seconds
        self.heartbeat_seconds = max(
            5,
            min(heartbeat_seconds, 10, max(5, lease_seconds // 2)),
        )
        self.workflow_factory = workflow_factory
        self.runtime_factory = runtime_factory
        # Heartbeats run on a background thread. Snowpark sessions cannot safely
        # execute concurrent statements, so production supplies a repository on
        # an independent session for lease renewal/cancellation observation.
        self.heartbeat_repository = heartbeat_repository or repository
        self.outbox_recovery_interval_seconds = outbox_recovery_interval_seconds
        self.outbox_recovery_batch_size = outbox_recovery_batch_size
        self._last_outbox_recovery = float('-inf')

    def _evaluate(self, run: Any) -> None:
        try:
            report = AgentEvaluationHarness().evaluate(run, self.repository.list_events(run.run_id))
            evaluation_id = f"eval_{uuid4().hex}"
            self.repository.save_evaluation(evaluation_id, run.run_id, report.model_dump(mode="json"))
            self.service.emit(
                run,
                "evaluation.completed",
                "succeeded" if report.passed else "needs_review",
                "Online trajectory evaluation completed.",
                data={"evaluation_id": evaluation_id, "score": report.score, "passed": report.passed},
            )
        except Exception:
            logger.exception("Online migration-agent evaluation failed for run %s", run.run_id)

    def run_once(self) -> bool:
        if (hasattr(self.repository, 'recover_terminal_command_outboxes')
                and time.monotonic() - self._last_outbox_recovery >= self.outbox_recovery_interval_seconds):
            self._last_outbox_recovery = time.monotonic()
            self.repository.recover_terminal_command_outboxes(self.outbox_recovery_batch_size)
        run = self.repository.acquire_lease(self.worker_id, self.lease_seconds)
        if run is None:
            return False
        from app.agent_runs.usage import restore_usage
        restore_usage(run, self.repository.latest_budget_usage(run.run_id))
        if hasattr(self.repository, 'set_worker_fence'):
            self.repository.set_worker_fence(run)
        workflow = self.workflow
        runtime: AgentRuntime | None = None
        step: AgentRunStep | None = None
        cleanup: Callable[[], None] = lambda: None
        heartbeat_stop = threading.Event()
        lease_lost = threading.Event()
        cancellation_seen = threading.Event()
        leased_at = time.perf_counter()
        last_confirmed_renewal = time.monotonic()
        evaluate_after_release: Any = None

        def heartbeat_loop() -> None:
            nonlocal last_confirmed_renewal
            while not heartbeat_stop.wait(self.heartbeat_seconds):
                current = None
                try:
                    renewed = self.heartbeat_repository.renew_lease(
                        run.run_id,
                        self.worker_id,
                        self.lease_seconds,
                        generation=run.lease_generation,
                    )
                except Exception:
                    logger.exception("Migration run heartbeat failed for %s", run.run_id)
                    renewed = False
                if renewed:
                    last_confirmed_renewal = time.monotonic()
                try:
                    current = self.heartbeat_repository.get_run(run.run_id)
                except Exception:
                    logger.exception("Migration run lease verification failed for %s", run.run_id)
                if not renewed and _lease_is_definitively_lost(
                    current,
                    worker_id=self.worker_id,
                    seconds_since_confirmed_renewal=time.monotonic() - last_confirmed_renewal,
                    lease_seconds=self.lease_seconds,
                    generation=run.lease_generation,
                ):
                    lease_lost.set()
                    return
                if current and current.cancel_requested_at:
                    cancellation_seen.set()
                    if runtime is not None:
                        runtime.cancel(run.run_id)

        heartbeat_thread = threading.Thread(
            target=heartbeat_loop,
            name=f"migration-heartbeat-{run.run_id}",
            daemon=True,
        )
        heartbeat_thread.start()
        try:
            if run.cancel_requested_at:
                run.status = RunStatus.CANCELLED
                run.completed_at = datetime.now(UTC)
                self.repository.save_run_owned(run)
                self.service.emit(run, "run.cancelled", "cancelled", "Migration run cancelled at a safe boundary.")
                return True

            # A never-started run cannot own outbox commands yet; skipping the
            # flush saves a procedure call before the first model turn.
            if hasattr(self.repository, "flush_command_outbox") and run.started_at is not None:
                self.repository.flush_command_outbox(run.run_id)
            is_new_run = run.started_at is None
            if self.runtime_factory is not None:
                runtime, cleanup = self.runtime_factory(run)
                if hasattr(runtime, "set_cancellation_check"):
                    runtime.set_cancellation_check(
                        lambda: (
                            "cancelled" if cancellation_seen.is_set()
                            else "lease_lost" if lease_lost.is_set()
                            else None
                        )
                    )
            elif self.workflow_factory is not None:
                workflow, cleanup = self.workflow_factory(run)
            runtime_initialization_ms = round((time.perf_counter() - leased_at) * 1000)

            if is_new_run:
                run.started_at = datetime.now(UTC)
            run.phase_started_at = datetime.now(UTC)
            run.phase_elapsed_start = run.elapsed_seconds_used
            run.status = RunStatus.EXECUTING
            step = AgentRunStep(
                step_id=run.current_step_id or f"step_{uuid4().hex}",
                run_id=run.run_id,
                node_name="migration_workflow",
                status=StepStatus.RUNNING,
                started_at=datetime.now(UTC),
                safe_summary="Executing the compiled migration workflow.",
            )
            run.current_step_id = step.step_id
            # Persist the canonical run/step before model execution, but avoid
            # the former save -> event transaction -> save-step -> save cycle.
            # Runtime-backed lifecycle events use the asynchronous ordered
            # trace writer, so model work can begin without waiting on a second
            # five-query event transaction.
            run = self.repository.save_run_owned(run)
            self.repository.save_step(step)
            if runtime is not None and hasattr(runtime, "emit_event"):
                runtime.emit_event(
                    "run.started" if is_new_run else "run.resumed.execution",
                    "running",
                    (
                        "Migration Agent worker started the durable workflow."
                        if is_new_run
                        else "Migration Agent resumed the same durable workflow checkpoint."
                    ),
                    {
                        "resume_attempt": run.resume_attempt,
                        "checkpoint_thread_id": run.checkpoint_thread_id or run.run_id,
                        "metrics": {
                            "accepted_to_lease_ms": round((datetime.now(UTC) - run.created_at).total_seconds() * 1000),
                            "runtime_initialization_ms": runtime_initialization_ms,
                        }
                    },
                )
            else:
                self.service.emit(
                    run,
                    "run.started" if is_new_run else "run.resumed.execution",
                    "running",
                    "Migration Agent worker started the durable workflow." if is_new_run else "Migration Agent resumed the same durable workflow checkpoint.",
                    data={"resume_attempt": run.resume_attempt, "checkpoint_thread_id": run.checkpoint_thread_id or run.run_id},
                )
            config = {"configurable": {"thread_id": run.checkpoint_thread_id or run.run_id}}

            # A newly queued run cannot have an answered interruption. Avoid a
            # Snowflake read before its first model turn; resume paths retain
            # the durable review lookup.
            answered_items = [] if is_new_run else [
                item for item in self.repository.list_review_items(run.run_id)
                if item.status.value == "ANSWERED" and (not run.current_step_id or item.step_id == run.current_step_id)
            ]
            answered = max(answered_items, key=lambda item: item.answered_at or item.created_at) if answered_items else None
            # A new run in a long conversation starts from the supervisor's last
            # compaction summary, not only from the replayed visible turns.
            conversation_summary = ""
            run_lineage = [run.run_id]
            parent_id = run.request.parent_run_id
            # A follow-up edits drafts its own lineage created. The chain is
            # walked here, never taken from the request, and stops at the first
            # run that belongs to someone else.
            while parent_id and parent_id not in run_lineage and len(run_lineage) < 20:
                parent = self.repository.get_run(parent_id)
                if parent is None or (parent.actor.user_id, parent.actor.tenant_id) != (
                        run.actor.user_id, run.actor.tenant_id):
                    break
                run_lineage.append(parent.run_id)
                parent_id = parent.request.parent_run_id
            if is_new_run and run.request.conversation_id:
                try:
                    conversation_summary = self.repository.latest_conversation_summary(
                        run.request.conversation_id, run.actor.user_id, run.actor.tenant_id,
                        exclude_run_id=run.run_id)
                except Exception:
                    logger.warning("Conversation summary lookup failed; replaying visible turns only", exc_info=True)
            if answered:
                answer_value: Any = answered.answer
                try:
                    parsed = json.loads(answered.answer or "")
                    if isinstance(parsed, dict):
                        answer_value = parsed
                except (TypeError, json.JSONDecodeError):
                    pass
                if not isinstance(answer_value, dict):
                    answer_value = {
                        "answer": answered.answer,
                        "target_tables": {
                            str(item.get("mapping_key")): answered.answer
                            for item in run.mapping_manifest
                            if not item.get("target_table")
                        },
                    }
                graph_input: Any = Command(resume=answer_value)
            else:
                graph_input = {
                    "messages": [],
                    "run_id": run.run_id,
                    "prompt": run.request.prompt,
                    "effort": run.policy.effort.value,
                    "effort_policy": run.policy.model_dump(mode="json"),
                    "run_mode": run.request.run_mode.value,
                    "actor_user_id": run.actor.user_id,
                    "app_user_id": run.actor.app_user_id,
                    "snowflake_username": run.actor.snowflake_username,
                    "effective_role": run.actor.effective_role or "",
                    "tenant_id": run.actor.tenant_id,
                    "conversation_id": run.request.conversation_id,
                    "turn_id": run.request.turn_id,
                    "intent": run.request.intent.value,
                    "page_context": run.request.page_context,
                    "authorized_schemas": run.request.authorized_schemas,
                    "conversation_history": run.request.conversation_history,
                "conversation_summary": conversation_summary,
                "parent_run_id": run_lineage[1] if len(run_lineage) > 1 else "",
                "run_lineage": run_lineage,
                    "authorized_source_scope": run.request.source_scope,
                    "authorized_target_scope": run.request.target_scope,
                    "attachment_ids": run.request.attachment_ids,
                    "requested_mappings": run.request.requested_mappings,
                    "precedent_project_ids": run.request.precedent_project_ids,
                    "precedent_sttm_ids": run.request.precedent_sttm_ids,
                    "project_id": run.project_id,
                    "manifest": run.mapping_manifest,
                    "manifest_version": run.manifest_version,
                    "cancel_requested": bool(run.cancel_requested_at),
                }
            trusted_workflow_input = graph_input if isinstance(graph_input, dict) else {
                "messages": [],
                "run_id": run.run_id,
                "prompt": run.request.prompt,
                "effort": run.policy.effort.value,
                    "effort_policy": run.policy.model_dump(mode="json"),
                "run_mode": run.request.run_mode.value,
                "actor_user_id": run.actor.user_id,
                "app_user_id": run.actor.app_user_id,
                "snowflake_username": run.actor.snowflake_username,
                "effective_role": run.actor.effective_role or "",
                "tenant_id": run.actor.tenant_id,
                "conversation_id": run.request.conversation_id,
                "turn_id": run.request.turn_id,
                "intent": run.request.intent.value,
                "page_context": run.request.page_context,
                "authorized_schemas": run.request.authorized_schemas,
                "conversation_history": run.request.conversation_history,
                "conversation_summary": conversation_summary,
                "parent_run_id": run_lineage[1] if len(run_lineage) > 1 else "",
                "run_lineage": run_lineage,
                "authorized_source_scope": run.request.source_scope,
                "authorized_target_scope": run.request.target_scope,
                "attachment_ids": run.request.attachment_ids,
                "requested_mappings": run.request.requested_mappings,
                "precedent_project_ids": run.request.precedent_project_ids,
                "precedent_sttm_ids": run.request.precedent_sttm_ids,
                "project_id": run.project_id,
                "manifest": run.mapping_manifest,
                "manifest_version": run.manifest_version,
                "cancel_requested": bool(run.cancel_requested_at),
            }
            if runtime is not None:
                runtime_result = runtime.invoke(
                    RuntimeInvocation(
                        run_id=run.run_id,
                        thread_id=run.checkpoint_thread_id or run.run_id,
                        prompt=run.request.prompt,
                        effort=run.policy.effort,
                        context_refs=run.request.attachment_ids,
                        resume_value=answer_value if answered else None,
                        is_resume=bool((run.resume_attempt or run.effort_history) and not answered),
                        workflow_input=trusted_workflow_input,
                    )
                )
                result = runtime_result.workflow_state
                run.elapsed_seconds_used = runtime_result.budget_usage.get("elapsed_seconds", run.elapsed_seconds_used)
                run.category_usage = {key.removeprefix("category_"): value for key, value in runtime_result.budget_usage.items() if key.startswith("category_")}
                run.model_calls_used = runtime_result.model_calls_used
                run.tool_calls_used = runtime_result.tool_calls_used
                run.supervisor_tool_requests_used = runtime_result.budget_usage.get("supervisor_tool_requests", 0)
                run.domain_operations_used = runtime_result.budget_usage.get("domain_operations", run.tool_calls_used)
                run.specialist_calls_used = runtime_result.budget_usage.get("specialist_calls", 0)
                run.cache_hits = runtime_result.budget_usage.get("cache_hits", 0)
                step.model_calls = run.model_calls_used
                step.tool_calls = run.tool_calls_used
            else:
                result = workflow.invoke(graph_input, config=config)
            if lease_lost.is_set():
                raise ExecutionLeaseLostError("Worker lease was lost before the next safe boundary")
            if cancellation_seen.is_set():
                current = self.repository.get_run(run.run_id)
                run.cancel_requested_at = current.cancel_requested_at if current else datetime.now(UTC)
                run.cancel_reason = current.cancel_reason if current else "Cancelled by user"
                run.status = RunStatus.CANCELLED
                run.completed_at = datetime.now(UTC)
                self.repository.save_run_owned(run)
                self.service.emit(run, "run.cancelled", "cancelled", "Migration run cancelled at a safe boundary.")
                return True
            interrupts = result.get("__interrupt__") if isinstance(result, dict) else None
            # A read-only explanation cannot enqueue draft commands.
            read_only_qa = str(dict(run.request.page_context or {}).get("continuation_kind") or "") == "READ_ONLY_QA"
            if hasattr(self.repository, "flush_command_outbox") and not read_only_qa:
                self.repository.flush_command_outbox(run.run_id)

            if interrupts:
                if runtime is not None and hasattr(runtime, "flush_traces"):
                    runtime.flush_traces()
                checkpoint_values = (
                    {}
                    if runtime is not None
                    else getattr(workflow.get_state(config), "values", {})
                )
                run.mapping_manifest = list(
                    result.get("manifest")
                    or checkpoint_values.get("manifest")
                    or build_manifest(
                        run.request.prompt,
                        requested_mappings=run.request.requested_mappings,
                        target_scope=run.request.target_scope,
                    )
                    or run.mapping_manifest
                )
                run.manifest_version = int(
                    result.get("manifest_version")
                    or checkpoint_values.get("manifest_version")
                    or run.manifest_version
                )
                self.repository.save_run_owned(run)
                if answered:
                    answered.status = ReviewItemStatus.RESOLVED
                    self.repository.save_review_item(answered)
                value = getattr(interrupts[0], "value", interrupts[0])
                payload = value if isinstance(value, dict) else {"question": str(value)}
                step.status = StepStatus.AWAITING_INPUT
                step.completed_at = datetime.now(UTC)
                self.repository.save_step(step)
                self.service.create_question(
                    run,
                    worker_owned=True,
                    category=str(payload.get("category") or "workflow_input"),
                    question=str(payload.get("question") or "Additional input is required."),
                    safe_summary=str(payload.get("safe_summary") or "The migration workflow requires user input."),
                    step_id=step.step_id,
                    subject_keys=[str(value) for value in payload.get("subject_keys") or []],
                    choices=list(payload.get("choices") or []),
                    evidence_ids=[str(value) for value in payload.get("evidence_ids") or []],
                    recommended_choice_id=payload.get("recommended_choice_id"),
                    allow_free_text=bool(payload.get("allow_free_text", True)),
                    interrupt_id=str(payload.get("interrupt_id") or f"{run.run_id}:{step.step_id}:{run.manifest_version}"),
                    action_digest=payload.get("action_digest"),
                    artifact_revision=str(
                        payload.get("artifact_revision") or run.manifest_version
                    ),
                    confirmation=str(payload.get("category") or "") in {"plan_approval", "approval"},
                    event_data={
                        "plan": payload.get("plan"),
                        "answer_hint": payload.get("answer_hint"),
                        "artifact_revision": str(payload.get("artifact_revision") or run.manifest_version),
                    },
                )
                return True

            if answered:
                answered.status = ReviewItemStatus.RESOLVED
                self.repository.save_review_item(answered)

            if str(result.get("status") or "") == "COMPLETED":
                run.status = RunStatus.COMPLETED
                run.completed_at = datetime.now(UTC)
                step.status = StepStatus.SUCCEEDED
                step.completed_at = run.completed_at
                step.safe_summary = str(result.get("assistant_message") or "The supervisor completed the requested analysis.")
                if runtime is not None and hasattr(runtime, "emit_event"):
                    # Enqueue the answer first: the trace writer persists it on
                    # its own session while the terminal saves run here, so the
                    # user no longer waits for both round trips in sequence.
                    runtime.emit_event(
                        "assistant.final",
                        "succeeded",
                        step.safe_summary,
                        {"text": step.safe_summary},
                    )
                    self.repository.save_step(step)
                    self.repository.save_run_owned(run)
                    runtime.flush_traces()
                else:
                    self.repository.save_step(step)
                    self.repository.save_run_owned(run)
                    self.service.emit(run, "assistant.final", "succeeded", step.safe_summary, data={"text": step.safe_summary})
                evaluate_after_release = run
                return True

            run.mapping_manifest = list(result.get("manifest") or run.mapping_manifest)
            run.manifest_version = int(result.get("manifest_version") or run.manifest_version)
            run.project_id = result.get("project_id") or run.project_id
            if run.project_id and run.request.conversation_id and hasattr(self.repository, "link_unassigned_conversation_to_project"):
                self.repository.link_unassigned_conversation_to_project(
                    run.request.conversation_id, run.project_id,
                    user_id=run.actor.user_id, tenant_id=run.actor.tenant_id,
                )
            for mapping in run.mapping_manifest:
                self.repository.save_dag_node(
                    MappingDagNode(
                        run_id=run.run_id,
                        mapping_key=str(mapping.get("mapping_key")),
                        mapping_name=str(mapping.get("mapping_name") or mapping.get("mapping_key")),
                        target_table=mapping.get("target_table"),
                        sttm_id=mapping.get("sttm_id"),
                        dependencies=[str(value) for value in mapping.get("dependencies") or []],
                        status=_mapping_step_status(str(mapping.get("status") or "PENDING")),
                        stale_reason=mapping.get("stale_reason"),
                    )
                )
            auto_approved_candidates = _validated_high_confidence_candidates(
                list(result.get("mapping_results") or []),
                float(getattr(self.service.settings, "migration_agent_column_review_confidence", 0.8) or 0.8),
            )
            for item in result.get("review_items") or []:
                details = dict(item.get("details") or {})
                target_column = str(details.get("target_column") or "")
                candidates = list(details.get("candidates") or [])
                is_mapping_candidate = item.get("category") == "mapping_candidate_review" and target_column
                sttm_id = str(item.get("sttm_id") or details.get("sttm_id") or "")
                if is_mapping_candidate and (sttm_id, target_column.upper()) in auto_approved_candidates:
                    continue
                self.repository.save_review_item(AgentReviewItem(
                    review_item_id=f"review_{uuid4().hex}",
                    run_id=run.run_id,
                    step_id=step.step_id,
                    project_id=run.project_id,
                    sttm_id=sttm_id or None,
                    mapping_key=item.get("mapping_key") or details.get("mapping_key"),
                    details=details,
                    subject_keys=[target_column] if is_mapping_candidate else [str(value) for value in item.get("subject_keys") or []],
                    blocking=bool(item.get("blocking", False)),
                    category=str(item.get("category") or "validation"),
                    question=item.get("question") or (f"Which mapping should be used for {target_column}?" if is_mapping_candidate else None),
                    choices=(self.service._mapping_review_choices(candidates) if is_mapping_candidate
                             else list(item.get("choices") or [])),
                    safe_summary=str(item.get("safe_summary") or "Migration result requires review."),
                    evidence_ids=[str(value) for value in item.get("evidence_ids") or []],
                ))
            result_status = str(result.get("status") or "READY_FOR_REVIEW")
            run.status = (
                RunStatus.NEEDS_REVIEW if result_status == "NEEDS_REVIEW" else
                RunStatus.COMPLETED_WITH_REVIEW_ITEMS
                if result_status == "COMPLETED_WITH_REVIEW_ITEMS"
                else RunStatus.READY_FOR_REVIEW
            )
            run.completed_at = datetime.now(UTC)
            step.status = StepStatus.NEEDS_REVIEW if run.status in {RunStatus.COMPLETED_WITH_REVIEW_ITEMS, RunStatus.NEEDS_REVIEW} else StepStatus.SUCCEEDED
            step.completed_at = run.completed_at
            step.safe_summary = (
                "The run stopped at its resumable review boundary. Remaining work is listed in the final answer."
                if run.status is RunStatus.NEEDS_REVIEW else
                "Compiled migration workflow completed and stopped for human review."
            )
            self.repository.save_step(step)
            self.repository.save_run_owned(run)
            final_text = (
                runtime_result.safe_summary
                if runtime is not None
                else "Draft mapping results were saved."
            )
            ready_data = {
                "mapping_results": result.get("mapping_results") or [],
                # One entry per requested target (including unmapped ones), SELECT only.
                "mapping_summaries": result.get("mapping_summaries") or [],
                "validation_report": result.get("validation_report") or {},
                "workbench_result": result.get("workbench_result") or {},
                "model_calls_used": run.model_calls_used,
                "tool_calls_used": run.tool_calls_used,
                "budget_usage": {
                    "model_calls": run.model_calls_used,
                    "supervisor_tool_requests": run.supervisor_tool_requests_used,
                    "domain_operations": run.domain_operations_used,
                    "specialist_calls": run.specialist_calls_used,
                    "cache_hits": run.cache_hits,
                },
                "artifact_refs": list(result.get("validation_artifact_refs") or []),
            }
            first_mapping = next(iter(result.get("mapping_results") or []), {})
            validation_report = dict(result.get("validation_report") or {})
            canonical_receipts = list(
                (result.get("workbench_result") or {}).get("mutation_receipts") or []
            )
            first_receipt = canonical_receipts[0] if canonical_receipts else {}
            has_draft_artifact = bool(
                canonical_receipts
                or first_mapping.get("sttm_id")
                or ready_data["artifact_refs"]
            )
            workspace_sync = {
                "project_id": first_receipt.get("project_id") or run.project_id,
                "sttm_id": first_receipt.get("sttm_id") or first_mapping.get("sttm_id"),
                "snapshot_id": first_receipt.get("snapshot_id") or (f"draft:{first_mapping.get('sttm_id')}" if first_mapping.get("sttm_id") else None),
                "revision": first_receipt.get("new_revision") or run.manifest_version,
                "artifact_hash": first_receipt.get("artifact_hash") or validation_report.get("artifact_digest"),
                "context_hash": str(
                    (result.get("mapping_context_package") or {}).get("context_hash") or ""
                ),
                "changed_entity_types": first_receipt.get("changed_entity_types") or [
                    "project", "sttm", "source_preparation", "mapping_rows", "validation"
                ],
                "route": first_receipt.get("route") or (
                    f"/projects/{run.project_id}/mappings/{first_mapping.get('sttm_id')}"
                    if run.project_id and first_mapping.get("sttm_id") else "/projects"
                ),
            }
            if runtime is not None and hasattr(runtime, "emit_event"):
                runtime.emit_event(
                    "run.ready_for_review" if has_draft_artifact else "run.completed_with_review_items",
                    "succeeded",
                    (
                        ("Draft mapping results were saved." if run.status is RunStatus.READY_FOR_REVIEW else "Draft results were saved; missing results are listed with the affected targets.")
                        if has_draft_artifact else
                        "The run stopped for review; no draft artifact was created."
                    ),
                    ready_data,
                )
                if has_draft_artifact:
                    runtime.emit_event(
                        "workspace.synced",
                        "succeeded",
                        "The run-owned Workbench draft and existing UI state are synchronized.",
                        workspace_sync,
                    )
                runtime.emit_event(
                    "assistant.final",
                    "succeeded",
                    final_text,
                    {
                        "text": final_text,
                        "status": run.status.value,
                        "artifact_refs": ready_data["artifact_refs"],
                        "mapping_summaries": ready_data["mapping_summaries"],
                        "project_id": run.project_id,
                    },
                )
                runtime.flush_traces()
            else:
                if has_draft_artifact:
                    self.service.emit(
                        run,
                        "workspace.synced",
                        "succeeded",
                        "The run-owned Workbench draft and existing UI state are synchronized.",
                        sttm_id=workspace_sync["sttm_id"],
                        data=workspace_sync,
                    )
                self.service.emit(
                    run,
                    "run.ready_for_review" if has_draft_artifact else "run.completed_with_review_items",
                    "succeeded",
                    (
                        ("Draft mapping results were saved." if run.status is RunStatus.READY_FOR_REVIEW else "Draft results were saved; missing results are listed with the affected targets.")
                        if has_draft_artifact else
                        "The run stopped for review; no draft artifact was created."
                    ),
                    artifact_refs=ready_data["artifact_refs"],
                    data=ready_data,
                )
                self.service.emit(
                    run,
                    "assistant.final",
                    "succeeded",
                    final_text,
                    artifact_refs=ready_data["artifact_refs"],
                    data={"text": final_text, "status": run.status.value,
                          "mapping_summaries": ready_data["mapping_summaries"], "project_id": run.project_id},
                )
            evaluate_after_release = run
            return True
        except EffortPromotionRequested as promotion:
            from app.agent_runs.models import EffortPolicy, EffortLevel
            next_policy = EffortPolicy.model_validate(promotion.policy)
            order = [EffortLevel.LIGHT, EffortLevel.MEDIUM, EffortLevel.HIGH]
            if (run.request.effort != EffortLevel.AUTO
                    or order.index(next_policy.effort) != order.index(run.policy.effort) + 1):
                raise ValueError('Invalid effort promotion')
            if runtime is not None:
                runtime.flush_traces()
                run.model_calls_used, run.tool_calls_used = runtime.usage_snapshot()
                usage = runtime.budget_snapshot()
                run.elapsed_seconds_used = usage.get('elapsed_seconds', run.elapsed_seconds_used)
                run.category_usage = {key.removeprefix('category_'): value for key, value in usage.items() if key.startswith('category_')}
            run.effort_history.append({'previous_policy': run.policy.model_dump(mode='json'),
                'policy': next_policy.model_dump(mode='json'), 'reason': 'actionable_budget_exhaustion',
                'at': datetime.now(UTC).isoformat(), 'model_calls_used': run.model_calls_used,
                'tool_calls_used': run.tool_calls_used, 'category_usage': dict(run.category_usage)})
            run.policy = next_policy
            run.run_revision += 1
            run.status = RunStatus.QUEUED
            run.completed_at = None
            self.repository.save_run_owned(run)
            self.service.emit(run, 'run.effort.promoted', 'queued',
                'The next configured effort tier will resume the existing checkpoint.',
                data={'effort': run.policy.effort.value, 'revision': run.run_revision})
            return True
        except ExecutionLeaseLostError as exc:
            # A checkpoint fence can reject work while the durable run still
            # names this worker. Returning it to the lease queue in that case
            # repeats the same startup failure indefinitely. Verify ownership
            # before deciding whether another worker should continue.
            logger.warning(
                "Migration worker %s stopped run %s after a durable lease fence rejected work: %s",
                self.worker_id,
                run.run_id,
                exc,
            )
            try:
                current = self.heartbeat_repository.get_run(run.run_id)
            except Exception:
                logger.exception("Could not verify the rejected lease for run %s", run.run_id)
                return False
            still_owned = (
                current is not None
                and current.lease_owner == self.worker_id
                and current.lease_generation == run.lease_generation
                and current.lease_expires_at is not None
                and current.lease_expires_at > datetime.now(UTC)
            )
            if still_owned and not lease_lost.is_set() and not current.cancel_requested_at:
                run.status = RunStatus.FAILED
                run.error_code = "checkpoint_fence_rejected"
                run.safe_error = (
                    "A checkpoint write was rejected while this worker still held the run lease. "
                    "Check the checkpoint procedure and worker logs before retrying."
                )
                run.completed_at = datetime.now(UTC)
                self.repository.save_run_owned(run)
                if step is not None:
                    step.status = StepStatus.FAILED
                    step.error_code = run.error_code
                    step.safe_summary = run.safe_error
                    step.completed_at = run.completed_at
                    try:
                        self.repository.save_step(step)
                    except Exception:
                        logger.exception("Could not save failed step for terminal run %s", run.run_id)
                self.service.emit(run, "run.failed", "failed", run.safe_error,
                                  data={"error_code": run.error_code})
                return True
            # A different owner or expired lease must never be overwritten.
            return False
        except Exception as exc:
            # Log the original failure before any recovery I/O can fail and
            # replace its traceback. This includes failures before the first
            # model call or checkpoint write.
            logger.exception("Migration worker failed for run %s", run.run_id)
            if runtime is not None and hasattr(runtime, "flush_traces"):
                try:
                    runtime.flush_traces()
                except Exception:
                    logger.exception("Failed to flush runtime traces for run %s", run.run_id)
            try:
                current = self.heartbeat_repository.get_run(run.run_id)
            except Exception:
                logger.exception("Could not read cancellation state while failing run %s", run.run_id)
                current = None
            if cancellation_seen.is_set() or (current and current.cancel_requested_at):
                run.cancel_requested_at = (
                    current.cancel_requested_at if current else datetime.now(UTC)
                )
                run.cancel_reason = current.cancel_reason if current else "Cancelled by user"
                run.status = RunStatus.CANCELLED
                run.completed_at = datetime.now(UTC)
                self.repository.save_run_owned(run)
                if step is not None:
                    step.status = StepStatus.CANCELLED
                    step.completed_at = run.completed_at
                    step.safe_summary = "Migration run cancelled at a safe execution boundary."
                    try:
                        self.repository.save_step(step)
                    except Exception:
                        logger.exception("Could not save cancelled step for terminal run %s", run.run_id)
                self.service.emit(
                    run,
                    "run.cancelled",
                    "cancelled",
                    "Migration run cancelled at a safe execution boundary.",
                )
                return True
            run.status = RunStatus.FAILED
            from app.agent_runs.recovery import failure_code
            run.error_code = failure_code(exc)
            detail = str(exc).strip().replace("\n", " ")[:500]
            run.safe_error = detail or "Migration workflow failed. Completed draft commands remain available for safe resume."
            run.completed_at = datetime.now(UTC)
            if runtime is not None and hasattr(runtime, "usage_snapshot"):
                try:
                    run.model_calls_used, run.tool_calls_used = runtime.usage_snapshot()
                    if hasattr(runtime, "budget_snapshot"):
                        usage = runtime.budget_snapshot()
                        run.elapsed_seconds_used = usage.get("elapsed_seconds", run.elapsed_seconds_used)
                        run.category_usage = {key.removeprefix("category_"):value for key,value in usage.items() if key.startswith("category_")}
                except Exception:
                    logger.exception("Could not snapshot usage while failing run %s", run.run_id)
            if (_exception_chain_contains(exc, BudgetExceededError)
                    and run.resume_attempt < min(2, run.policy.max_resume_attempts)
                    and _budget_phase_made_progress(run)):
                # A durable checkpoint can continue in a fresh bounded phase.
                # Permit at most two automatic grants; a stalled replay or a
                # third exhaustion becomes a visible, manually resumable error.
                run.budget_grants.append({
                    "reason": "automatic_budget_phase",
                    "idempotency_key": f"auto-budget:{run.run_id}:{run.resume_attempt + 1}",
                    "created_at": datetime.now(UTC).isoformat(),
                    "model_offset": run.model_calls_used,
                    "tool_offset": run.tool_calls_used,
                    "category_offsets": dict(run.category_usage),
                    "elapsed_offset": run.elapsed_seconds_used,
                })
                run.resume_attempt += 1
                run.run_revision += 1
                run.status = RunStatus.QUEUED
                run.error_code = None
                run.safe_error = None
                run.completed_at = None
                self.repository.save_run_owned(run)
                if step is not None:
                    step.status = StepStatus.BLOCKED
                    step.safe_summary = "The durable run continues in the next bounded execution phase."
                    step.completed_at = datetime.now(UTC)
                    self.repository.save_step(step)
                self.service.emit(run, "run.budget.phase_extended", "pending",
                                  "The durable run is continuing from its latest checkpoint.",
                                  data={"resume_attempt": run.resume_attempt})
                return True
            # Persist the terminal run before ancillary step/event writes. A
            # failed step upsert must not leave an EXECUTING run eligible for
            # endless lease reacquisition.
            self.repository.save_run_owned(run)
            if step is not None:
                step.status = StepStatus.FAILED
                step.completed_at = run.completed_at
                step.error_code = run.error_code
                step.safe_summary = run.safe_error
                step.model_calls = run.model_calls_used
                step.tool_calls = run.tool_calls_used
                try:
                    self.repository.save_step(step)
                except Exception:
                    logger.exception("Could not save failed step for terminal run %s", run.run_id)
            self.service.emit(run, "run.failed", "failed", run.safe_error, data={"error_code": run.error_code})
            evaluate_after_release = run
            return True
        finally:
            heartbeat_stop.set()
            heartbeat_thread.join(timeout=2)
            try:
                cleanup()
            finally:
                try:
                    self.repository.release_lease(run.run_id, self.worker_id, generation=run.lease_generation)
                finally:
                    if hasattr(self.repository, 'set_worker_fence'):
                        self.repository.set_worker_fence(None)
            # Online evaluation is audit data the user never waits for; run it
            # only after the lease is released and the answer is durable.
            if evaluate_after_release is not None:
                self._evaluate(evaluate_after_release)

    def heartbeat(self, run_id: str) -> bool:
        return self.heartbeat_repository.renew_lease(
            run_id,
            self.worker_id,
            self.lease_seconds,
        )
