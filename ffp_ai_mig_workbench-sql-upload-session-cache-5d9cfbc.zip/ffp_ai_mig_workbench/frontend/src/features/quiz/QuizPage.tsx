"use client";

import { useMemo, useState } from "react";
import { AiaBox, AiaButton } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import {
  BODY_SX,
  CAPTION_SX,
  CARD_TITLE_SX,
  SECONDARY_TEXT_SX,
  SECTION_TITLE_SX,
} from "@/config/typography-tokens";
import {
  ArrowBackRoundedIcon,
  ArrowForwardRoundedIcon,
  CheckCircleRoundedIcon,
  ErrorOutlineRoundedIcon,
  QuizRoundedIcon,
  UndoRoundedIcon,
} from "@/utils/icons";
import {
  buildQuizAttempt,
  QUIZ_CATEGORIES,
  QUIZ_RESULT_LEVELS,
  QUIZ_TITLE,
  type QuizQuestion,
} from "./quiz-data";

type QuizStage = "intro" | "question" | "result";

/** Selected option index per question id. */
type QuizAnswers = Record<string, number>;

const PRIMARY = "var(--aia-primary-bg-color)";
const CORRECT_COLOR = "#16A34A";
const WRONG_COLOR = "#DC2626";

const cardSx = {
  width: "100%",
  maxWidth: 1100,
  mx: "auto",
  p: { xs: 2.5, md: 3.5 },
  borderRadius: "16px",
  border: "1px solid #E8ECF4",
  bgcolor: "#FFFFFF",
} as const;

const areaChipSx = {
  display: "inline-flex",
  alignItems: "center",
  px: 1.25,
  py: 0.4,
  borderRadius: "999px",
  bgcolor: "#F1F5F9",
  color: "#475569",
  fontSize: 12,
  fontWeight: 600,
} as const;

function isCorrect(question: QuizQuestion, answers: QuizAnswers) {
  return answers[question.id] === question.correctOptionIndex;
}


export default function QuizPage() {
  // A fresh random set every attempt (equal questions per category).
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [stage, setStage] = useState<QuizStage>("intro");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswers>({});

  const startQuiz = () => {
    setQuestions((previous) => buildQuizAttempt(previous.map((question) => question.id)));
    setAnswers({});
    setCurrentIndex(0);
    setStage("question");
  };

  return (
    <AiaBox
      sx={{
        display: "flex",
        flex: 1,
        minHeight: 0,
        flexDirection: "column",
        overflow: "hidden",
        bgcolor: "#F7F8FA",
      }}
    >
      <AiaBox sx={{ flex: 1, minHeight: 0, overflowY: "auto", px: { xs: 2.5, md: 3.5 }, py: 2.5 }}>
        <AiaBox sx={{ mb: 2.5 }}>
          <AiaText sx={{ ...SECTION_TITLE_SX, letterSpacing: "-0.02em" }}>Quiz</AiaText>
          <AiaText sx={{ ...SECONDARY_TEXT_SX, mt: 0.75 }}>
            Test how well you know the Migration Workbench
          </AiaText>
        </AiaBox>

        {stage === "intro" ? <QuizIntro onStart={startQuiz} /> : null}

        {stage === "question" && questions[currentIndex] ? (
          <QuizQuestionCard
            question={questions[currentIndex]}
            index={currentIndex}
            total={questions.length}
            selectedOption={answers[questions[currentIndex].id]}
            onSelect={(optionIndex) =>
              setAnswers((previous) => ({ ...previous, [questions[currentIndex].id]: optionIndex }))
            }
            onPrevious={() => setCurrentIndex((index) => Math.max(0, index - 1))}
            onNext={() => {
              if (currentIndex === questions.length - 1) {
                setStage("result");
              } else {
                setCurrentIndex((index) => index + 1);
              }
            }}
          />
        ) : null}

        {stage === "result" ? (
          <QuizResult questions={questions} answers={answers} onRetake={startQuiz} />
        ) : null}
      </AiaBox>
    </AiaBox>
  );
}

function QuizIntro({ onStart }: { onStart: () => void }) {
  return (
    <AiaBox sx={cardSx}>
      <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
        <AiaBox
          sx={{
            width: 44,
            height: 44,
            borderRadius: "12px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            bgcolor: "#EEF2FF",
            color: PRIMARY,
            flexShrink: 0,
          }}
        >
          <QuizRoundedIcon sx={{ fontSize: 24 }} />
        </AiaBox>
        <AiaText sx={CARD_TITLE_SX}>{QUIZ_TITLE}</AiaText>
      </AiaBox>

      <AiaText sx={{ ...BODY_SX, mt: 2 }}>
        Check your understanding of the Migration Workbench and see how well you know each
        area of the app. At the end you get your score and the right answers, so you know
        where you stand.
      </AiaText>

      <AiaText sx={{ ...CAPTION_SX, mt: 2.5, mb: 1 }}>Areas covered</AiaText>
      <AiaBox sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
        {QUIZ_CATEGORIES.map((area) => (
          <AiaBox key={area} component="span" sx={areaChipSx}>
            {area}
          </AiaBox>
        ))}
      </AiaBox>

      <AiaBox sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
        <AiaButton
          variant="contained"
          color="primary"
          size="large"
          endIcon={<ArrowForwardRoundedIcon sx={{ fontSize: 18 }} />}
          onClick={onStart}
        >
          Start Quiz
        </AiaButton>
      </AiaBox>
    </AiaBox>
  );
}

type QuizQuestionCardProps = {
  question: QuizQuestion;
  index: number;
  total: number;
  selectedOption: number | undefined;
  onSelect: (optionIndex: number) => void;
  onPrevious: () => void;
  onNext: () => void;
};

function QuizQuestionCard({
  question,
  index,
  total,
  selectedOption,
  onSelect,
  onPrevious,
  onNext,
}: QuizQuestionCardProps) {
  const isLast = index === total - 1;
  const progress = ((index + 1) / total) * 100;

  return (
    <AiaBox sx={cardSx}>
      <AiaBox sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 1 }}>
        <AiaText sx={{ ...SECONDARY_TEXT_SX, fontWeight: 600 }}>
          Question {index + 1} of {total}
        </AiaText>
        <AiaBox component="span" sx={areaChipSx}>
          {question.area}
        </AiaBox>
      </AiaBox>

      <AiaBox
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={total}
        aria-valuenow={index + 1}
        sx={{ mt: 1.25, height: 6, borderRadius: "999px", bgcolor: "#E2E8F0", overflow: "hidden" }}
      >
        <AiaBox sx={{ width: `${progress}%`, height: "100%", bgcolor: PRIMARY, transition: "width 200ms ease" }} />
      </AiaBox>

      <AiaText sx={{ ...CARD_TITLE_SX, mt: 3, lineHeight: 1.45 }}>{question.question}</AiaText>

      <AiaBox role="radiogroup" aria-label={question.question} sx={{ mt: 2, display: "grid", gap: 1.25 }}>
        {question.options.map((option, optionIndex) => {
          const selected = selectedOption === optionIndex;
          return (
            <AiaBox
              key={option}
              role="radio"
              aria-checked={selected}
              tabIndex={0}
              onClick={() => onSelect(optionIndex)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onSelect(optionIndex);
                }
              }}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1.5,
                px: 2,
                py: 1.5,
                borderRadius: "12px",
                border: `1.5px solid ${selected ? PRIMARY : "#E2E8F0"}`,
                bgcolor: selected ? "#F8FAFC" : "#FFFFFF",
                cursor: "pointer",
                transition: "border-color 120ms ease, background-color 120ms ease",
                "&:hover": { borderColor: selected ? PRIMARY : "#CBD5E1" },
                "&:focus-visible": { outline: `2px solid ${PRIMARY}`, outlineOffset: 2 },
              }}
            >
              <AiaBox
                sx={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 13,
                  fontWeight: 700,
                  color: selected ? "#FFFFFF" : "#475569",
                  bgcolor: selected ? PRIMARY : "#F1F5F9",
                }}
              >
                {String.fromCharCode(65 + optionIndex)}
              </AiaBox>
              <AiaText sx={{ ...BODY_SX, color: "#313131" }}>{option}</AiaText>
            </AiaBox>
          );
        })}
      </AiaBox>

      <AiaBox sx={{ mt: 3, display: "flex", justifyContent: "space-between", gap: 1.5 }}>
        <AiaButton
          variant="outlined"
          size="large"
          startIcon={<ArrowBackRoundedIcon sx={{ fontSize: 18 }} />}
          disabled={index === 0}
          onClick={onPrevious}
          customBorderColor={PRIMARY}
          customColor={PRIMARY}
        >
          Previous
        </AiaButton>
        <AiaButton
          variant="contained"
          color="primary"
          size="large"
          endIcon={isLast ? undefined : <ArrowForwardRoundedIcon sx={{ fontSize: 18 }} />}
          disabled={selectedOption === undefined}
          onClick={onNext}
        >
          {isLast ? "Finish & See Score" : "Next"}
        </AiaButton>
      </AiaBox>
    </AiaBox>
  );
}

type QuizResultProps = {
  questions: QuizQuestion[];
  answers: QuizAnswers;
  onRetake: () => void;
};

function QuizResult({ questions, answers, onRetake }: QuizResultProps) {
  const score = questions.filter((question) => isCorrect(question, answers)).length;
  const percent = Math.round((score / questions.length) * 100);
  const level = QUIZ_RESULT_LEVELS.find((entry) => percent >= entry.minPercent) ?? QUIZ_RESULT_LEVELS.at(-1)!;

  const areaScores = useMemo(
    () =>
      QUIZ_CATEGORIES.map((area) => {
        const inArea = questions.filter((question) => question.area === area);
        return {
          area,
          correct: inArea.filter((question) => isCorrect(question, answers)).length,
          total: inArea.length,
        };
      }),
    [questions, answers],
  );

  return (
    <AiaBox sx={{ display: "grid", gap: 2.5 }}>
      <AiaBox sx={{ ...cardSx, textAlign: "center" }}>
        <AiaText sx={{ ...CAPTION_SX, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          Your score
        </AiaText>
        <AiaText sx={{ mt: 1, fontSize: 48, fontWeight: 800, lineHeight: 1.1, color: "#313131" }}>
          {score}
          <AiaText component="span" sx={{ fontSize: 24, fontWeight: 600, color: "#94A3B8" }}>
            {" "}/ {questions.length}
          </AiaText>
        </AiaText>
        <AiaText sx={{ ...SECONDARY_TEXT_SX, mt: 0.5 }}>{percent}% correct</AiaText>
        <AiaText sx={{ ...CARD_TITLE_SX, mt: 2 }}>{level.title}</AiaText>
        <AiaText sx={{ ...BODY_SX, mt: 0.5 }}>{level.message}</AiaText>

        <AiaBox sx={{ mt: 3, display: "grid", gap: 1, textAlign: "left" }}>
          {areaScores.map(({ area, correct, total }) => (
            <AiaBox key={area} sx={{ display: "grid", gridTemplateColumns: "minmax(0, 1fr) 56px", gap: 1.5, alignItems: "center" }}>
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText sx={{ ...SECONDARY_TEXT_SX, color: "#313131", mb: 0.5 }}>{area}</AiaText>
                <AiaBox sx={{ height: 6, borderRadius: "999px", bgcolor: "#E2E8F0", overflow: "hidden" }}>
                  <AiaBox
                    sx={{
                      width: `${(correct / total) * 100}%`,
                      height: "100%",
                      bgcolor: correct === total ? CORRECT_COLOR : PRIMARY,
                    }}
                  />
                </AiaBox>
              </AiaBox>
              <AiaText sx={{ ...SECONDARY_TEXT_SX, fontWeight: 600, textAlign: "right" }}>
                {correct}/{total}
              </AiaText>
            </AiaBox>
          ))}
        </AiaBox>

        <AiaBox sx={{ mt: 3, display: "flex", justifyContent: "center" }}>
          <AiaButton
            variant="contained"
            color="primary"
            size="large"
            startIcon={<UndoRoundedIcon sx={{ fontSize: 18 }} />}
            onClick={onRetake}
          >
            Retake Quiz
          </AiaButton>
        </AiaBox>
      </AiaBox>

      <AiaBox sx={cardSx}>
        <AiaText sx={CARD_TITLE_SX}>Review your answers</AiaText>
        <AiaBox sx={{ mt: 2, display: "grid", gap: 2 }}>
          {questions.map((question, index) => {
            const correct = isCorrect(question, answers);
            const chosen = answers[question.id];
            return (
              <AiaBox
                key={question.id}
                sx={{
                  p: 2,
                  borderRadius: "12px",
                  border: "1px solid #E8ECF4",
                  borderLeft: `4px solid ${correct ? CORRECT_COLOR : WRONG_COLOR}`,
                }}
              >
                <AiaBox sx={{ display: "flex", alignItems: "flex-start", gap: 1 }}>
                  {correct ? (
                    <CheckCircleRoundedIcon sx={{ fontSize: 20, color: CORRECT_COLOR, mt: "1px", flexShrink: 0 }} />
                  ) : (
                    <ErrorOutlineRoundedIcon sx={{ fontSize: 20, color: WRONG_COLOR, mt: "1px", flexShrink: 0 }} />
                  )}
                  <AiaText sx={{ ...BODY_SX, fontWeight: 600, color: "#313131" }}>
                    {index + 1}. {question.question}
                  </AiaText>
                </AiaBox>
                <AiaBox sx={{ pl: 3.5, mt: 1, display: "grid", gap: 0.5 }}>
                  {!correct ? (
                    <AiaText sx={{ ...SECONDARY_TEXT_SX, color: WRONG_COLOR }}>
                      Your answer: {chosen === undefined ? "Not answered" : question.options[chosen]}
                    </AiaText>
                  ) : null}
                  <AiaText sx={{ ...SECONDARY_TEXT_SX, color: CORRECT_COLOR }}>
                    Correct answer: {question.options[question.correctOptionIndex]}
                  </AiaText>
                  <AiaText sx={{ ...SECONDARY_TEXT_SX, mt: 0.5 }}>{question.explanation}</AiaText>
                </AiaBox>
              </AiaBox>
            );
          })}
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
