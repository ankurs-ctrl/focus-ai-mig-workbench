const assert=require('node:assert/strict'),test=require('node:test'),ts=require('typescript');
const h=require('./test-automap-preservation.cjs');
function reducer(name){let value;function visit(n){if(ts.isPropertyAssignment(n)&&n.name.getText(h.slice)===name)value=n.initializer.getText(h.slice);ts.forEachChild(n,visit);}visit(h.slice);assert.ok(value,name);return h.reducer(value);}
test('progress denominator belongs to requested generation, never worker totals',()=>{
 const state=h.stateFor(...Array.from({length:37},(_,i)=>h.blank('TARGET'+i)));
 h.reducer(h.pendingReducer)(state,{meta:{requestId:'current',arg:{action:'complete'}}});
 const status=reducer('autoMapStreamStatus');
 status(state,{payload:{requestId:'current',stage:'preparing',batchCount:0,text:'0/387'}});
 assert.match(state.autoMapStatusMessage,/0\/37/);assert.doesNotMatch(state.autoMapStatusMessage,/387|0 source batches/);
 state.autoMapRun.processedTargetNames=['TARGET0'];
 status(state,{payload:{requestId:'current',stage:'transformation',batchCount:5,text:'0/10'}});
 assert.match(state.autoMapStatusMessage,/1\/37/);assert.match(state.autoMapStatusMessage,/Transformation/);
 const previous=state.autoMapStatusMessage;
 status(state,{payload:{requestId:'old',stage:'queued',text:'0/999'}});
 assert.equal(state.autoMapStatusMessage,previous);
});
