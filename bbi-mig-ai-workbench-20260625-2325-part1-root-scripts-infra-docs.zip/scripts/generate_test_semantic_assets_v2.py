#!/usr/bin/env python3
"""Generate and verify the three canonical STTM test semantic assets."""

from __future__ import annotations

import argparse
import json
import sys
import uuid
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = REPO_ROOT / "services" / "sttm-builder"
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from app.core.config import Settings
from app.core.snowflake import get_local_cached_connector, get_local_rest_session_context
from app.core.snowflake_agent import SnowflakeAgentClient


TEST_TABLES = (
    ("BBI_STTM_TEST_DB", "DL_AMOUNT", "LOAN_INCOME_AMOUNT_CALCULATION"),
    ("BBI_STTM_TEST_DB", "DL_AMOUNT", "NOTE"),
    ("BBI_STTM_TEST_DB", "DW_OPS", "LOAN_INCOME_AMOUNT_CALCULATION"),
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-file", default=str(APP_ROOT / ".env.local"))
    parser.add_argument("--agent", default="FOCUS_DB_2.STTM_MCP.AGT_SEMANTIC_MODEL_V2")
    parser.add_argument("--registry", default="FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA")
    parser.add_argument(
        "--table",
        action="append",
        help="Limit the run to an exact TABLE name. May be specified more than once.",
    )
    args = parser.parse_args()

    base_settings = Settings(_env_file=args.env_file)
    normalized_host = (
        base_settings.snowflake_host.strip()
        or f"{base_settings.snowflake_account.lower().replace('_', '-')}.snowflakecomputing.com"
    ).replace("_", "-")
    settings = Settings(_env_file=args.env_file, SNOWFLAKE_HOST=normalized_host)
    rest = get_local_rest_session_context(settings)
    agent = SnowflakeAgentClient(
        token=rest.token,
        host=rest.host,
        auth_mode="snowflake_token",
        request_timeout=900.0,
    )
    connection = get_local_cached_connector(settings)
    results: list[dict[str, object]] = []

    selected_tables = tuple(
        item for item in TEST_TABLES if not args.table or item[2] in set(args.table)
    )
    for database, schema, table in selected_tables:
        request_id = str(uuid.uuid4())
        instruction = {
            "scope": "TABLE",
            "database": database,
            "schema": schema,
            "table": table,
            "force": True,
            "publication": {
                "producer_agent": "AGT_SEMANTIC_MODEL_V2",
                "request_id": request_id,
                "change_reason": "Canonical workbench test semantic asset publication",
            },
        }
        prompt = (
            "Generate the complete TABLE-scope semantic asset for this exact table and "
            "publish it through SAVE_SEMANTIC_VIEW. Return only the required JSON response.\n"
            + json.dumps(instruction, separators=(",", ":"))
        )
        text, thread_id, _ = agent.run_detailed(
            [{"role": "user", "content": [{"type": "text", "text": prompt}]}],
            agent=args.agent,
            request_timeout=900.0,
        )
        try:
            agent_result = json.loads(text)
        except json.JSONDecodeError as exc:
            stripped = text.strip()
            if stripped.startswith("```") and stripped.endswith("```"):
                stripped = stripped.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
                agent_result = json.loads(stripped)
            else:
                preview = " ".join(text.split())[:900]
                raise RuntimeError(
                    f"AGT_SEMANTIC_MODEL_V2 returned non-JSON for {database}.{schema}.{table} "
                    f"(thread_id={thread_id}, chars={len(text)}, preview={preview!r})"
                ) from exc
        if not isinstance(agent_result, dict):
            raise RuntimeError(
                f"AGT_SEMANTIC_MODEL_V2 returned a non-object for {database}.{schema}.{table}"
            )
        save_metadata = agent_result.get("save_metadata")
        print(
            json.dumps(
                {
                    "event": "agent_completed",
                    "fqn": f"{database}.{schema}.{table}",
                    "thread_id": thread_id,
                    "scope": agent_result.get("scope"),
                    "keys": sorted(agent_result),
                    "columns": len(agent_result.get("attributes") or []),
                    "save_metadata": save_metadata,
                    "error": agent_result.get("error"),
                },
                separators=(",", ":"),
            ),
            flush=True,
        )
        if not isinstance(save_metadata, dict) or str(save_metadata.get("status") or "").upper() not in {
            "OK",
            "SAVED",
            "SUCCESS",
        }:
            response_preview = json.dumps(agent_result, separators=(",", ":"))[:1800]
            raise RuntimeError(
                f"AGT_SEMANTIC_MODEL_V2 did not acknowledge registry publication for "
                f"{database}.{schema}.{table} (thread_id={thread_id}, "
                f"save_metadata={save_metadata!r}, response={response_preview})"
            )
        with connection.cursor() as cursor:
            cursor.execute(
                f"""
                SELECT VIEW_ID, VERSION, SEMANTIC_VIEW
                FROM {args.registry}.SEM_TABLE_VIEWS
                WHERE DATABASE_NAME = %s
                  AND SCHEMA_NAME = %s
                  AND TABLE_NAME = %s
                  AND REQUEST_ID = %s
                  AND STATUS = 'PENDING'
                ORDER BY GENERATED_AT DESC
                LIMIT 1
                """,
                (database, schema, table, request_id),
            )
            row = cursor.fetchone()
        if not row:
            raise RuntimeError(
                f"Agent acknowledged save but no pending registry asset was found for "
                f"{database}.{schema}.{table} request_id={request_id}"
            )
        pending_view_id, pending_version, semantic_asset = row
        if isinstance(semantic_asset, str):
            semantic_asset = json.loads(semantic_asset)
        with connection.cursor() as cursor:
            cursor.execute(
                f"CALL {args.registry}.SP_PUBLISH_SEMANTIC_ASSET(%s)",
                (json.dumps(semantic_asset, separators=(",", ":")),),
            )
            prepared_row = cursor.fetchone()
        prepared = prepared_row[0] if prepared_row else None
        if isinstance(prepared, str):
            prepared = json.loads(prepared)
        if not isinstance(prepared, dict) or prepared.get("status") != "PREPARED":
            raise RuntimeError(f"Semantic publication preparation failed for {database}.{schema}.{table}: {prepared}")

        yaml_spec = str(prepared["semantic_view_yaml"])
        with connection.cursor() as cursor:
            cursor.execute(
                "CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML(%s, %s, TRUE)",
                (args.registry, yaml_spec),
            )
            cursor.execute(
                "CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML(%s, %s, FALSE)",
                (args.registry, yaml_spec),
            )
            cursor.execute(
                f"CALL {args.registry}.SP_LINK_PHYSICAL_SEMANTIC_VIEW(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (
                    database,
                    schema,
                    table,
                    pending_view_id,
                    prepared["physical_view_name"],
                    yaml_spec,
                    prepared["yaml_hash"],
                    prepared["producer_agent"],
                    prepared["request_id"],
                    prepared["change_reason"],
                ),
            )
            linked_row = cursor.fetchone()
        linked = linked_row[0] if linked_row else None
        if isinstance(linked, str):
            linked = json.loads(linked)
        if not isinstance(linked, dict) or linked.get("status") != "OK":
            raise RuntimeError(f"Physical semantic view link failed for {database}.{schema}.{table}: {linked}")
        results.append(
            {
                "fqn": f"{database}.{schema}.{table}",
                "thread_id": thread_id,
                "view_id": pending_view_id,
                "version": pending_version,
                "physical_view_name": prepared.get("physical_view_name"),
                "agent_response_chars": len(text),
            }
        )

    print(json.dumps({"status": "OK", "assets": results}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
