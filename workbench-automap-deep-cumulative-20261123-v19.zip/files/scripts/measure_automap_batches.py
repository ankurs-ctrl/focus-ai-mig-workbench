"""Read one durable request and measure planner budgets without agent calls or writes."""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "services" / "sttm-builder"))

from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.config import Settings
from app.core.snowflake import SnowflakeClient
from app.core.sttm_builder import STTMBuilderService
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest


def audit_projection(request, projected):
    prepared = request.context.model_dump(mode="json", exclude_none=True)
    sent = projected.payload["context"]
    graph = prepared["relation_graph"]
    sent_graph = sent["relation_graph"]
    nodes = {node["relation_id"]: node for node in sent_graph["nodes"]}

    def clean(value):
        if isinstance(value, dict):
            return {key: clean(child) for key, child in value.items() if child not in (None, "", [], {})}
        if isinstance(value, list):
            return [clean(child) for child in value]
        return value

    def table_name(item):
        table = item.get("table") or {}
        return ".".join(str(table.get(key) or "") for key in ("database", "schema", "table"))

    models = {table_name(item): item.get("semantic_model") or {} for item in sent.get("semantic_context") or []}
    semantic_inventory = []
    for item in prepared.get("semantic_context") or []:
        model = item.get("semantic_model") or {}
        name = table_name(item)
        attributes = model.get("attributes") or model.get("column_semantics") or []
        available = {column.get("name") or column.get("column_name") for column in attributes}
        included = {column.get("name") for column in models.get(name, {}).get("attributes") or []}
        semantic_inventory.append({"table": name, "prepared": len(available), "sent": len(included),
                                   "omitted_names": sorted(available - included)})
    return {
        "node_count": len(nodes), "edge_count": len(sent_graph.get("edges") or []),
        "edges_exact": clean(graph.get("edges")) == clean(sent_graph.get("edges")),
        "cte_sql_exact": all(node.get("sql_text") == nodes.get(node["relation_id"], {}).get("sql_text")
                             for node in graph["nodes"] if node.get("sql_text")),
        "output_names_exact": all(
            [column.get("name") for column in node.get("output_columns") or []] ==
            [column.get("name") for column in nodes.get(node["relation_id"], {}).get("output_columns") or []]
            for node in graph["nodes"]),
        "value_bindings_exact": clean(graph.get("value_bindings")) == clean(sent_graph.get("value_bindings")),
        "driver_exact": prepared.get("driving_table") == sent.get("driving_table"),
        "filters_exact": clean((prepared.get("workspace_context") or {}).get("filters")) ==
                         clean((sent.get("workspace_context") or {}).get("filters")),
        "semantic_inventory": semantic_inventory,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("job_id")
    parser.add_argument("--budgets", nargs="+", type=int, default=[85000, 120000, 160000, 200000])
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--audit", action="store_true", help="Compare reconstructed packets with recorded payload hashes.")
    args = parser.parse_args()
    settings = Settings(_env_file=os.environ["WORKBENCH_TEST_ENV_FILE"])
    client = SnowflakeClient(settings)
    try:
        table = settings.qualify_metadata_object_name("TBL_AUTO_MAP_JOBS")
        rows = client.session.sql(
            f"SELECT JOB_STATE:request_envelope AS REQUEST, JOB_STATE:partial_responses AS BATCHES FROM {table} WHERE JOB_ID = ? LIMIT 1",
            params=[args.job_id],
        ).collect()
        raw = rows[0].as_dict()["REQUEST"] if rows else None
        if not raw:
            raise ValueError("No durable request found; cannot measure an equivalent packet.")
        raw = json.loads(raw) if isinstance(raw, str) else raw
        from app.core.automap_stored_json import context_storage
        request = STTMBuilderEnvelopeRequest.model_validate(context_storage(raw, restore=True))
        recorded = rows[0].as_dict().get("BATCHES") or []
        recorded = json.loads(recorded) if isinstance(recorded, str) else recorded
        print(json.dumps({"targets": len(request.data.attributes), "nodes": len(request.context.relation_graph.nodes),
                          "joins": len(request.context.relation_graph.edges),
                          "has_learning": request.context.learning_context is not None}))
        for budget in args.budgets:
            configured = settings.model_copy(update={"automap_hybrid_context_v1": True,
                "agent_outbound_message_max_chars": budget, "agent_outbound_message_max_bytes": budget * 2})
            if args.batch_size is not None:
                configured = configured.model_copy(update={"auto_mapping_proxy_batch_size": args.batch_size})
            batches = AutoMappingProxyClient(configured)._build_batches(request)
            sizes = []
            for index, attributes in enumerate(batches):
                batch = request.model_copy(update={"data": request.data.model_copy(update={"attributes": attributes})})
                projected = STTMBuilderService.project_agent_payload(batch, configured)
                sizes.append(projected.diagnostics["final_chars"])
                if args.audit:
                    previous = next((item for item in recorded if item.get("batch_index") == index), {})
                    audit = (previous.get("response", {}).get("meta", {}).get("agent_payload") or {})
                    digest = hashlib.sha256(projected.text.encode("utf-8")).hexdigest()
                    print(json.dumps({"batch": index, "matches_recorded_payload": digest == audit.get("sha256"),
                                      **audit_projection(batch, projected)}), flush=True)
            print(json.dumps({"budget_chars": budget, "batch_count": len(batches),
                "batch_size_cap": configured.auto_mapping_proxy_batch_size,
                "batch_sizes": [len(batch) for batch in batches], "max_chars": max(sizes),
                "total_chars": sum(sizes)}), flush=True)
    finally:
        client.close()


if __name__ == "__main__":
    main()