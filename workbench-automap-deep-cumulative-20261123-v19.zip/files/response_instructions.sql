/*
=====================================================================
COPY EVERYTHING BELOW THIS LINE INTO THE CORTEX AGENT
"RESPONSE INSTRUCTIONS" FIELD — NOT THE SYSTEM PROMPT FIELD
=====================================================================
*/

/*

Return a single JSON object. No prose, no markdown, no explanation outside the JSON.

---

## Output Shapes

### TABLE scope
{
  "scope":                    "TABLE",
  "database":                 "DB_NAME",
  "schema":                   "SCHEMA_NAME",
  "table":                    "TABLE_NAME",
  "phase2_enabled":           true,
  "phase2_skip_reason":       null,
  "pk_detection":             { "...": "Copy exactly from GET_TABLE_RELATIONSHIPS output" },
  "semantic_model":           { ...see TABLE — semantic_model... },
  "attribute_semantic_model": [ ...see ATTRIBUTE — attribute_semantic_model... ],
  "save_metadata": {
    "status":        "OK",
    "version":       N,
    "columns_saved": N
  }
}

### SCHEMA scope
{
  "scope":          "SCHEMA",
  "database":       "DB_NAME",
  "schema":         "SCHEMA_NAME",
  "table":          null,
  "semantic_model": { ...see SCHEMA — semantic_model... }
}

---

## SCHEMA — semantic_model

{
  "description":    "What this schema represents as a business domain (2–3 sentences).",
  "domain_summary": "1–2 sentences a data consumer can quote without modification.",
  "tables": [
    {
      "name":         "TABLE_NAME",
      "description":  "What this table stores and its business role.",
      "primary_keys": ["COLUMN_NAME"],
      "relationships": {
        "outgoing": [
          {
            "schema":          "...",
            "table":           "...",
            "type":            "FORMAL | INFERRED",
            "confidence":      "HIGH | MEDIUM | LOW",
            "inferred_method": "FORMAL_CONSTRAINT | EXACT_NAME_MATCH_UNIQUENESS_VERIFIED | PK_COLUMN_MATCH",
            "column_mappings": [{ "fk_column": "...", "pk_column": "..." }]
          }
        ],
        "incoming": [
          {
            "schema":          "...",
            "table":           "...",
            "type":            "FORMAL | INFERRED",
            "confidence":      "HIGH | MEDIUM | LOW",
            "inferred_method": "FORMAL_CONSTRAINT | PK_COLUMN_MATCH",
            "column_mappings": [{ "fk_column": "...", "pk_column": "..." }]
          }
        ]
      }
    }
  ]
}

SCHEMA scope notes:
  - IN_SCHEMA_SWEEP=TRUE is always used in SCHEMA scope — no FUZZY entries will appear.
  - Omit INFERRED LOW entries from SCHEMA scope table entries (Phase 2 not run to validate them).
  - primary_keys: [] when pk_confirmed = false for that table.

---

## TABLE — semantic_model

{
  "description":    "What this table stores and its business role.",
  "domain_summary": "1–2 sentences a data consumer can quote without modification.",
  "relationships": {
    "outgoing": [
      {
        "schema":               "...",
        "table":                "...",
        "type":                 "FORMAL | INFERRED | FUZZY",
        "confidence":           "HIGH | MEDIUM | LOW",
        "inferred_method":      "FORMAL_CONSTRAINT | EXACT_NAME_MATCH_UNIQUENESS_VERIFIED | CORTEX_SEARCH_SEMANTIC",
        "column_mappings":      [{ "fk_column": "...", "pk_column": "..." }],
        "value_overlap_pct":    80.0,
        "relationship_evidence": { ...FUZZY only — see below... },
        "semantic_review":      { ...when reviewed — see below... }
      }
    ],
    "incoming": [
      {
        "schema":               "...",
        "table":                "...",
        "type":                 "FORMAL | INFERRED | FUZZY",
        "confidence":           "HIGH | MEDIUM | LOW | FLAGGED",
        "inferred_method":      "FORMAL_CONSTRAINT | PK_COLUMN_MATCH | CORTEX_SEARCH_SEMANTIC",
        "column_mappings":      [{ "fk_column": "...", "pk_column": "..." }],
        "relationship_evidence": { ...FUZZY only (Phase 2C) — same shape as outgoing... },
        "semantic_review":      { ...FUZZY only (Phase 2C) when Step 8 reviewed — V10 NEW... }
      }
    ],
    "pk_note": null
  },
  "attributes": [
    {
      "name":        "COLUMN_NAME",
      "data_type":   "...",
      "constraints": [],
      "summary":     "One sentence: what this column stores and its business role."
    }
  ]
}

---

## relationship_evidence block (FUZZY entries only — outgoing and incoming)

Present on every FUZZY entry in outgoing[] and incoming[] (Phase 2C).
Never present on FORMAL or INFERRED entries.

Outgoing FUZZY shape:
{
  "semantic_similarity":  0.94,
  "profile_score":        62,
  "distinct_count_ratio": 0.80,
  "fk_null_pct":          0.0,
  "ref_null_pct":         0.0,
  "fk_length_range":      "18-18",
  "ref_length_range":     "18-18",
  "value_overlap_pct":    100.0,
  "pattern_class_fk":     "NUMERIC",
  "pattern_class_ref":    "NUMERIC",
  "pattern_class_match":  true
}

Incoming FUZZY shape (Phase 2C — V10.1: includes length range fields):
{
  "semantic_similarity":  0.62,
  "datatype_match":       true,
  "profile_score":        60,
  "profile_score_max":    100,
  "value_overlap_pct":    100.0,
  "fk_distinct_count":    5009,
  "ref_distinct_count":   23502,
  "fk_null_pct":          0.0,
  "ref_null_pct":         0.0,
  "fk_length_range":      "1-5",
  "ref_length_range":     "1-6",
  "pattern_class_fk":     "NUMERIC",
  "pattern_class_ref":    "NUMERIC",
  "pattern_class_match":  true
}

Field definitions:
  semantic_similarity  : Cortex Search cosine_similarity score (0.0–1.0).
                         Interpret as: >= 0.55 = strong; 0.40–0.54 = moderate.
                         Confidence tier: sim >= 0.55 = MEDIUM.
  profile_score        : Gate 2 structural compatibility score (0–100).
                         >= 70 = strong; 50–69 = moderate; < 50 = weak.
  distinct_count_ratio : (outgoing only) min(d_fk, d_ref) / max(d_fk, d_ref). Range 0.0–1.0.
                         Gate 2.1: hard minimum 0.30. >= 0.80 = closely proportional.
  fk_distinct_count    : (incoming only) distinct values in the FK candidate column.
  ref_distinct_count   : (incoming only) distinct values in the referenced PK column.
                         For a true FK: fk_distinct_count <= ref_distinct_count.
  fk_null_pct          : % NULL values in the FK column. 0 = fully populated.
  ref_null_pct         : % NULL values in the referenced column.
  fk_length_range      : "min-max" string value lengths in FK column.
  ref_length_range     : "min-max" string value lengths in referenced column.
                         Fixed-width match (both "18-18") is a strong ID signal.
  value_overlap_pct    : % of FK sample values found in referenced column.
                         Gate 4: hard minimum 40%. >= 80 = strong integrity.
  pattern_class_fk     : Character class of FK column values.
                         Values: NUMERIC | ALPHA | ALPHANUMERIC | FORMATTED | EMPTY.
  pattern_class_ref    : Character class of referenced column values.
  pattern_class_match  : true when classes match (contributed +25 to profile_score).

---

## semantic_review block (FUZZY outgoing entries + FUZZY incoming entries + INFERRED LOW with overlap < 60)

Present when the relationship was submitted to LLM semantic review OR pre-flagged by SQL cross-check.
  - Outgoing FUZZY entries  → reviewed by Step 7 (outgoing review batch).
  - Incoming FUZZY entries  → two paths:
      (a) reviewed_by='SQL_CROSS_CHECK': pre-flagged by SQL before LLM — deterministic INVALID.
          The candidate (fk_table, fk_column) was already the pk_column in outgoing[].
          confidence=FLAGGED always. No LLM token cost.
      (b) reviewed_by='mixtral-8x7b': sent to Step 8 LLM batch.
          verdict can be VALID | UNCERTAIN | INVALID.
          INVALID → confidence demoted to FLAGGED.
  - INFERRED LOW entries    → reviewed by Step 7 when overlap < 60%.
Never present on FORMAL entries (they are fully trusted, not reviewed).

V10.1: FLAGGED incoming entries may come from SQL_CROSS_CHECK OR LLM Step 8.
Apply the same exclusion rule regardless of reviewed_by:
  - Exclude from incoming[] block in the final output.
  - Move to table-level semantic_notes with a clear warning.
  - For SQL_CROSS_CHECK: note that the direction is already captured in outgoing[].
  - For mixtral-8x7b INVALID: note the LLM flagged it as likely invalid.

{
  "verdict":          "VALID | UNCERTAIN | INVALID",
  "confidence_note":  "One sentence citing specific evidence fields and their values.",
  "source_references": [
    "semantic_similarity:0.94 — strong match",
    "value_overlap_pct:100 — full referential integrity",
    "fk_length_range:18-18 / ref_length_range:18-18 — fixed-width match"
  ],
  "reviewed_by":  "mixtral-8x7b | SQL_CROSS_CHECK",
  "reviewed_at":  "YYYY-MM-DDTHH:MM:SS"
}

---

## ATTRIBUTE — attribute_semantic_model (one entry per column)

[
  {
    "name":             "COLUMN_NAME",
    "data_type":        "...",
    "nullable":         true,
    "constraints":      [],
    "description":      "What this column stores.",
    "business_meaning": "How it is used — joins, aggregations, governance rules.",
    "semantic_role":    "primary_key | foreign_key | metric | dimension | identifier | attribute",
    "data_quality": {
      "row_count":      0,
      "null_count":     0,
      "null_pct":       0.0,
      "distinct_count": 0
    },
    "value_profile": {
      ...see value_profile rules below...
    },
    "semantic_notes": []
  }
]

---

## Rules

### primary_keys
[] when pk_detection.pk_confirmed = false.
Populated from confirmed_pk[].column when pk_detection.pk_confirmed = true.
Never populate from DDL constraints alone — procedure output is the source of truth.

### pk_detection alignment
The full pk_detection object from GET_TABLE_RELATIONSHIPS is available to you.
Key fields you must use:
  pk_confirmed                   : BOOLEAN — true when a single PK was confirmed.
  human_review_required          : BOOLEAN — true when pk_confirmed = false.
  alternate_keys_review_required : BOOLEAN — V8.1+: always false in always-tiered mode.
  confirmed_pk[]                 : Array of { column, confidence, reason, uniqueness_verified }.
  additional_unique_columns[]    : Columns unique but not selected as PK; may have semantic_review.
  eliminated_candidates[]        : Columns that failed uniqueness/null checks.
  composite_pk_candidates[]      : When multiple columns pass (Cases C and E).
  scan_strategy                  : Always "TIERED (col_count=N, Tier1_first, Tier2_fallback, regexp_like_patterns)".
  pk_note                        : Non-null only when pk_confirmed = false (or alternate keys found).
  fuzzy_pk                       : V9 NEW — present only when Phase 2A resolved the PK.
                                   Fields: column, confidence, semantic_similarity,
                                           inferred_method, is_likely_key_verified.
                                   Action: add semantic_note:
                                     "PK column [COL] identified by Phase 2A Cortex Search
                                      (similarity: X.XX, IS_LIKELY_KEY=true). Not formally
                                      constrained — confirm before treating as authoritative PK."

### constraints
A list. Include any of: "PRIMARY_KEY", "NOT_NULL", "UNIQUE" as plain strings.
FOREIGN_KEY is an object:
  { "type": "FOREIGN_KEY", "confidence": "HIGH|MEDIUM|LOW|FLAGGED", "references": { "table": "...", "column": "..." } }
Apply consistently in both semantic_model.attributes[] and attribute_semantic_model[].
Source: confirmed_pk[].column → "PRIMARY_KEY"; outgoing[].column_mappings → "FOREIGN_KEY".
FLAGGED FOREIGN_KEY confidence means LLM review returned INVALID — flag in semantic_notes.

### relationships — confidence and type

type values (copy exactly from procedure output — do not rename):
  FORMAL   — formally declared FK/PK constraint (SHOW IMPORTED/EXPORTED KEYS).
             confidence = HIGH always.
  INFERRED — exact column-name match; uniqueness verified in referenced table by SQL.
             confidence = MEDIUM (overlap >= 80%) or LOW (overlap 40–79%).
  FUZZY    — matched via Cortex Search semantic similarity; all 4 SQL gates passed.
             confidence = MEDIUM (sim >= 0.55)
                        = LOW    (sim >= 0.40 but below 0.55)
             NEVER HIGH (reserved for FORMAL only).

confidence values:
  HIGH    — FORMAL only. Fully trusted. No caveats required.
  MEDIUM  — INFERRED or FUZZY with strong signals. Include as-is.
  LOW     — INFERRED or FUZZY with borderline signals. Always add semantic_note.
  FLAGGED — LLM review returned INVALID for this entry. Relationship kept in output
             for traceability but must be treated as unverified.
             Action: exclude from semantic_model.relationships.outgoing[].
             Move to table-level semantic_notes with explicit warning.

inferred_method values (copy exactly from procedure output — do not rename):
  FORMAL_CONSTRAINT                    — SHOW IMPORTED/EXPORTED KEYS result.
  EXACT_NAME_MATCH_UNIQUENESS_VERIFIED — Phase 1 Step 5: exact column name match + overlap check.
  PK_COLUMN_MATCH                      — Phase 1 Step 4: incoming ref via PK column name.
  CORTEX_SEARCH_SEMANTIC               — Phase 2 Step 6: Cortex Search fuzzy match.

### relationships — rules by pk_confirmed state

pk_confirmed = true:
  - Copy outgoing[] and incoming[] from procedure response.
  - Include FORMAL, INFERRED, and FUZZY entries (subject to confidence rules below).
  - Set pk_note to null.
  - Preserve confidence, type, and inferred_method exactly as returned.

pk_confirmed = false (human_review_required = true):
  - Include ALL relationship entries (FORMAL, INFERRED, and FUZZY).
  - Do not exclude inferred or fuzzy entries.
  - Set pk_note to:
    "Primary key could not be confirmed by data scan or semantic search. Composite PK suspected.
     Human validation required before using any inferred relationship."
  - Surface composite_pk_candidates in semantic_notes:
    "Possible composite PK columns: [COL1, COL2]. Human validation required before joining."

### FUZZY relationships — handling rules

FUZZY entry with confidence = MEDIUM (sim >= 0.90, overlap >= 80%):
  Include in outgoing[] as-is.
  Include relationship_evidence block.
  Include semantic_review block if present.

FUZZY entry with confidence = LOW:
  Include in outgoing[] but add a semantic_note:
  "Relationship to <TABLE>.<COL> inferred via Cortex Search semantic similarity (score: X.XX)
   — lower confidence. Verify before using in joins."

FUZZY entry with confidence = FLAGGED (LLM verdict = INVALID):
  DO NOT include in outgoing[].
  Add to table-level semantic_notes:
  "Relationship to <TABLE>.<COL> was inferred via Cortex Search but was flagged by LLM review
   as likely invalid (verdict: INVALID). Excluded from relationships block.
   Raw evidence: overlap=X%, similarity=X.XX. Manual validation required."

INFERRED entry with confidence = LOW and semantic_review present:
  Include in outgoing[] with semantic_review block attached.
  If verdict = VALID  : confidence stays LOW but note can be softened.
  If verdict = UNCERTAIN : add semantic_note recommending verification.
  If verdict = INVALID   : demote to FLAGGED — apply FLAGGED rules above.

### Phase 2 diagnostics (from summary block) — V9 field names
After any Phase 2 run, the summary block contains:
  phase2_enabled              : true when Phase 2 ran; false when deliberately skipped
                                (see phase2_skip_reason) or Phase 2 failed.
  phase2_skip_reason          : why Phase 2 was skipped (also top-level in response).
                                Values: formal_constraints_sufficient |
                                        infrastructure_not_deployed |
                                        schema_sweep_phase2_deferred | null.
  formal_outgoing_count       : count of FORMAL FK entries from SHOW IMPORTED KEYS.
                                Gate B requires > 0 to allow skipping Phase 2.
  orphan_key_col_count        : count of key-like columns (_ID/_KEY/_CODE/_NO) not
                                covered by formal FK constraints and not the PK.
                                When > 0, Phase 2 ran regardless of formal FKs.
  phase2_fuzzy_outgoing_count : count of FUZZY entries added to outgoing[] (Phase 2B).
  phase2_fuzzy_incoming_count : count of FUZZY entries added to incoming[] (Phase 2C).
  phase2_review_items_sent    : count of items submitted to LLM Step 7 batch
                                (outgoing FUZZY + LOW INFERRED + alternate keys).
  phase2_incoming_review_items_sent : count of incoming FUZZY entries sent to
                                LLM Step 8 batch. Does NOT include entries
                                pre-flagged by SQL cross-check (Fix 2).
                                0 = all candidates pre-flagged by SQL, or
                                    Phase 2C found no qualifying candidates.
  phase2_error                : present only when Phase 2 partially failed.

If phase2_error is non-null: include "save_error" in your response JSON with the error string.
Do not suppress phase2_error silently.

### value_profile — MUTUALLY EXCLUSIVE: pick exactly one form

Form A — when distinct_count <= 15 (unique_values, omit sample_values):
  {
    "unique_values": ["val1", "val2", "val3"],
    "range_stats":   { ... }
  }

Form B — when distinct_count > 15 (sample_values, omit unique_values):
  {
    "sample_values": ["val1", "val2", ...up to 10 values],
    "range_stats":   { ... }
  }

NEVER include both unique_values and sample_values in the same entry.
NEVER omit range_stats regardless of data type.
NEVER include raw sample values from GET_SAMPLE_ROWS in any form of value_profile — that would expose raw data.
The sample values shown here come from COLUMN_PROFILE_CACHE, not the raw sample rows tool.

range_stats shape by data type:
  Numeric (NUMBER, FLOAT, INTEGER, DECIMAL):
    { "min": 0, "max": 0, "mean": 0.0, "stddev": 0.0, "p25": 0, "p50": 0, "p75": 0 }
  Date / Timestamp:
    { "min": "YYYY-MM-DD", "max": "YYYY-MM-DD", "span_days": 0 }
  String (VARCHAR, TEXT, CHAR):
    { "min_len": 0, "max_len": 0 }

### semantic_notes
Always an array of strings. Never a single string. Never a prose paragraph.
Each entry is one independent, qualified observation.
Never paste raw tool output numbers verbatim — synthesise.

Mandatory entries when condition is met:
  null_pct > 20%                   → "High null rate (XX%): <business impact of missing values>."
  PII detected                     → "PII classification: <TYPE> — apply masking before external use."
  Negative numeric values          → "Negative values are valid — do not apply ABS() without business context."
  Fixed-length strings             → "Fixed <N>-character format (e.g. <example>). Use LIKE '<pattern>' for validation."
  High stddev vs mean              → "High value dispersion (stddev <X> vs mean <Y>) — outliers present at upper range."
  LOW confidence FK (INFERRED)     → "Inferred FK to <TABLE>.<COLUMN> (LOW confidence — borderline overlap <N>%). Verify before join."
  LOW confidence FUZZY FK          → "Relationship to <TABLE>.<COL> inferred via Cortex Search (similarity: <X>).
                                      Lower confidence — verify before using in joins."
  LOW confidence FUZZY FK (incoming)  → "Reverse FK to this table from <TABLE>.<COL> inferred
                                          via Phase 2C Cortex Search (similarity: <X>).
                                          Lower confidence — verify before using in joins."
  Phase 2A fuzzy_pk resolved PK      → "Primary key [COL] was identified by Phase 2A Cortex
                                         Search (similarity: X.XX, IS_LIKELY_KEY=true).
                                         Not formally constrained — confirm before authoritative use."
  UNCERTAIN verdict on FUZZY FK      → "Relationship to <TABLE>.<COL> inferred via semantic similarity — LLM review
                                         returned UNCERTAIN. Evidence is mixed. Validate manually before join."
  FLAGGED FK (LLM INVALID verdict)   → "Relationship to <TABLE>.<COL> was inferred but flagged by LLM review as likely
                                         invalid. Excluded from relationships block. Manual verification required."
  pk_confirmed = false             → "Primary key could not be confirmed by data scan. Composite PK suspected:
                                      [COL1, COL2]. Human validation required before joining."
  additional_unique_columns[]      → "Additional unique column(s) detected: [COL1, ...]. These are non-null and unique
                                      but were not selected as PK. Confirm whether they are alternate business keys."

### FRESH column handling (check_column_staleness)
When check_column_staleness returns status=FRESH for a column:
  - Do NOT call get_column_profile for that column.
  - Use the cached ATTRIBUTE_VIEW data for value_profile and data_quality.
  - The column MUST still appear in attribute_semantic_model[] — never skip it.

### Staleness handling — all status values from check_table_staleness

status = MISSING (code=NO_SEMANTIC_VIEW):
  - No cached view exists. Run the FULL pipeline:
    list_columns → get_table_ddl → get_table_relationships(skip_phase2=FALSE) →
    get_table_stats → get_sample_rows → get_column_profile (per column) →
    save_semantic_view.

status = STALE (code=COLUMNS_CHANGED, DDL_ALTERED, or TTL_EXPIRED):
  - Structure changed or TTL expired. Run the FULL pipeline (same as MISSING).
  - get_column_profile must be called for every column (structure may have changed).

status = PHASE2_UPGRADE (code=PHASE2_PREVIOUSLY_FAILED, infrastructure_ready=true):
  - A cached view EXISTS but Phase 2 did not run last time (phase2_enabled=false).
  - Phase 2 infrastructure is NOW deployed (COLUMN_PROFILE_CACHE exists).
  - Action: Run the FULL pipeline with skip_phase2=FALSE.
  - Optimisation: for each column, call check_column_staleness first.
    If FRESH → use cached attribute_view directly. Do NOT re-profile.
    If MISSING or STALE → call get_column_profile for that column only.
  - After pipeline: call save_semantic_view. Version increments (e.g. 1 → 2).
  - Future calls: phase2_enabled=true in new view → returns FRESH permanently.

status = FRESH (code=USE_CACHED):
  Two sub-cases — check the infrastructure_ready field:

  infrastructure_ready=true OR field absent (normal FRESH):
    - Semantic view is current AND phase2_enabled=true.
    - Call get_cached_semantic_view and return the semantic_view field as-is.
    - Do NOT call save_semantic_view. Do NOT run any discovery or profiling.

  infrastructure_ready=false (Phase 2 not yet deployed):
    - Semantic view is current but Phase 1 only (phase2_enabled=false).
    - Phase 2 infrastructure has not been deployed (files 17-20 not run).
    - Call get_cached_semantic_view and return the semantic_view field as-is.
    - Do NOT trigger any re-run or pipeline.
    - Note in your response: "Phase 2 relationship enrichment not yet available.
      Semantic Search Infrastructure not deployed."

status = ERROR:
  - Log the error and proceed with the FULL pipeline (treat as MISSING).

### save_semantic_view — serialisation
The procedure accepts a VARCHAR parameter, not a VARIANT.
Before calling save_semantic_view, serialise the assembled JSON object to a JSON string.
Pass the string — not the JSON object directly.
Expected response: { "status": "OK", "version": N, "columns_saved": N }
If status = ERROR: add "save_error": "<message>" to your response JSON. Never suppress it.
If phase2_error was non-null: also include it in "save_error".
Include save_metadata in the final response using the procedure's return values.

### business_meaning
Required for every column in attribute_semantic_model.
Describe: joins it participates in, aggregations it feeds, governance rules that apply.
Do not repeat the description field verbatim.

### summary (in semantic_model.attributes[])
Single sentence per attribute — do not replicate full attribute_semantic_model detail.
Its purpose is quick navigation for downstream agents and schema browsers.

### domain_summary
1–2 sentences a business analyst can quote without modification.
Avoid technical jargon. Focus on business purpose and the users of this data.

### pk_note
Set to null when pk_detection.pk_confirmed = true AND alternate_keys_review_required = false.
Non-null when:
  pk_confirmed = false          → "No single-column PK detected. Composite PK suspected or human validation required."
  alternate_keys_review_required = true → "PK inferred from data. Additional unique columns detected — see additional_unique_columns. Verify if they are alternate business keys or coincidentally unique."
  confirmed_pk[0].confidence = MEDIUM or LOW → "PK inferred from data — not formally constrained. Phase 2 Cortex Search can improve FK confidence."
Never invent a pk_note when PK is formally confirmed (confidence = HIGH).

### outgoing / incoming arrays
Always include both keys even when empty:
  "outgoing": [], "incoming": []
Never omit either key.

### save_metadata block
Always include in TABLE scope response after calling save_semantic_view:
  "save_metadata": { "status": "OK", "version": N, "columns_saved": N }
On error:
  "save_error": "Error message from procedure"
  (include save_metadata with status=ERROR as well)

---

## Confidence Quick Reference

| confidence | type          | what it means                                    | action                                          |
|------------|---------------|--------------------------------------------------|-------------------------------------------------|
| HIGH       | FORMAL        | Formally declared FK/PK constraint               | Include as-is. No caveat needed.                |
| MEDIUM     | INFERRED      | Exact name match + overlap >= 80%                | Include as-is.                                  |
| MEDIUM     | FUZZY         | Cortex Search sim >= 0.55                        | Include with relationship_evidence block.       |
| LOW        | INFERRED      | Exact name match + overlap 40–79%                | Include + semantic_note required.               |
| LOW        | FUZZY         | Cortex Search match but lower sim or overlap     | Include + semantic_note required.               |
| LOW        | FUZZY(2C)     | Phase 2C incoming fuzzy, lower confidence        | Include in incoming[] + semantic_note required. |
| FLAGGED    | any (outgoing)| LLM Step 7 review verdict = INVALID              | Exclude from relationships block.               |
|            |               |                                                  | Add to semantic_notes with warning.             |
| FLAGGED    | FUZZY(2C)     | LLM Step 8 review verdict = INVALID              | Exclude from incoming[] block.                  |
|            |               |                                                  | Add to table-level semantic_notes with warning. |
| FLAGGED    | FUZZY(2C)     | SQL_CROSS_CHECK: fk_col already in outgoing[]    | Exclude from incoming[] block.                  |
|            |               | as pk_column — reverse direction false positive  | Note direction already in outgoing[].           |

Note: FUZZY incoming[] entries (Phase 2C) go through Step 8 LLM review OR are pre-flagged
      by SQL cross-check (Fix 2) when the candidate is already a pk_column in outgoing[].
      SQL_CROSS_CHECK is deterministic and does not consume LLM tokens.
      Both paths produce confidence=FLAGGED and are handled identically by the agent:
      exclude from incoming[] and add to table-level semantic_notes with a clear warning.
      Distinguish the two in the semantic_note wording (LLM vs SQL_CROSS_CHECK path).

*/
