"""Loopback wake-up signal between the API and co-located worker slots.

The worker's durable lease poll remains the source of truth: a lost datagram
only means the run is claimed on the next poll. The signal removes the idle
poll delay when the API and worker share a host (local dev, one SPCS pod).
Only a fixed, content-free datagram is sent to 127.0.0.1, so nothing about the
run crosses the socket.
"""
from __future__ import annotations

import logging
import socket

logger = logging.getLogger(__name__)

_WAKE_PAYLOAD = b"wake"


def _slot_ports(settings: object) -> list[int]:
    base = int(getattr(settings, "migration_agent_wake_port", 0) or 0)
    if base <= 0:
        return []
    slots = max(1, int(getattr(settings, "migration_agent_max_concurrency", 1) or 1))
    return [base + index for index in range(slots)]


def notify_workers(settings: object) -> None:
    """Best-effort: tell idle worker slots a run is queued. Never raises."""
    ports = _slot_ports(settings)
    if not ports:
        return
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sender:
            for port in ports:
                sender.sendto(_WAKE_PAYLOAD, ("127.0.0.1", port))
    except OSError:
        logger.debug("Migration Agent worker wake-up signal could not be sent", exc_info=True)


class WorkerWakeListener:
    """Blocks a worker slot's idle wait until a wake datagram or the timeout."""

    def __init__(self, settings: object, slot_index: int) -> None:
        self._socket: socket.socket | None = None
        base = int(getattr(settings, "migration_agent_wake_port", 0) or 0)
        if base <= 0:
            return
        listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            listener.bind(("127.0.0.1", base + slot_index))
        except OSError:
            # Another process owns the port; polling alone stays correct.
            listener.close()
            logger.warning("Migration Agent wake port %s is unavailable; using polling only", base + slot_index)
            return
        self._socket = listener

    def wait(self, timeout: float) -> bool:
        """Return True when woken early; False after a plain timeout."""
        if self._socket is None:
            import time

            time.sleep(timeout)
            return False
        self._socket.settimeout(max(0.01, timeout))
        try:
            self._socket.recvfrom(64)
        except (TimeoutError, socket.timeout):
            return False
        except OSError:
            return False
        # Coalesce a burst of wake-ups into one claim attempt.
        self._socket.setblocking(False)
        try:
            while True:
                self._socket.recvfrom(64)
        except OSError:
            pass
        return True

    def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None
