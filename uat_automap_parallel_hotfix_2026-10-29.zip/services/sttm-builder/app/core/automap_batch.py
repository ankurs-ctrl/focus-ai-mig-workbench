"""One bounded model conversation per worker batch, with vectorized exact reads."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass
import json
import logging
import time
from threading import Event
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.core.automap_admission import ScanCallAdmission
    from app.core.automap_parallel import ParallelLimits
    from app.core.automap_reduce import ReductionArchive
    from app.core.automap_scan import ScanBackend
    from app.core.automap_shards import SnapshotScope

from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.assistant_retrieval import budget_messages
from app.core.automap_retrieval import AutoMapContext, STRATEGY_VERSION, batch_messages, batch_packet, encoded, target_name
from app.schema.sttm_builder import AttributeMapping, SourceMappingResult, STTMAgentRequestEnvelope, STTMStatus
from app.schema.contracts import ApiWarning

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ParallelRuntimeBundle:
    """Trusted service-only factory result; never construct from request/model data.

    The factory must supply authenticated scope, a raw single-attempt thread-safe
    backend, its ScanCallAdmission, a durable scoped archive and explicit limits.
    prepare_parallel pairs backend/admission for scan AND reduction.
    """

    scope: SnapshotScope
    backend: ScanBackend
    admission: ScanCallAdmission
    archive: ReductionArchive
    limits: ParallelLimits
    cancellation: Event | None = None


class _BatchReadBudgetError(ValueError):
    """Exact retrieval stopped at a budget boundary, not a validation failure."""


def invoke_batch(service, req, decision=None):
    from app.core.sttm_builder import _extract_json_object

    settings = service._settings
    parallel_enabled = getattr(settings, "automap_parallel_context_v1", False) is True
    runtime_factory = None
    if parallel_enabled:
        settings.validate_parallel_automap()
        runtime_factory = getattr(service, "_build_auto_map_parallel_runtime", None)
        if not callable(runtime_factory):
            raise ValueError("AUTOMAP_PARALLEL_CONTEXT_V1 requires service._build_auto_map_parallel_runtime; legacy fallback is forbidden")
    decision = decision or service._build_governance_decision(req)
    service._model_guard.assert_model_target_allowed(operation=req.operation.value, target="agent", decision=decision)
    started = time.monotonic()
    from app.core.automap_policy import focused_learning, retrieval_diagnostic_summary, source_preparation_issues
    raw_context = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
    raw_context["context"]["learning_context"] = focused_learning(raw_context["context"].get("learning_context") or {})
    store = AutoMapContext(raw_context)
    preparation_issues = source_preparation_issues(raw_context.get("context") or {})
    store.manifest()
    attributes = {target_name(item.target_attribute): item for item in req.data.attributes or []}
    completed, reasons, results, events = {}, {}, [], []
    operation_count, model_calls, peak_bytes = 0, 0, 0
    final_thread, final_payload, deficits = None, {}, {}
    preparation, projection, runtime = None, None, None
    parallel_warnings = []
    agent_warnings = []
    page_bytes = min(32768, settings.agent_outbound_message_max_bytes // 4)
    timings = {"discovery": 0.0, "preparation": 0.0, "retrieval": 0.0, "model": 0.0, "validation": 0.0}

    def remaining():
        return settings.automap_context_target_seconds - (time.monotonic() - started)

    def read_operations(operations):
        nonlocal operation_count
        pending = list({encoded(operation): operation for operation in operations}.values())
        while pending:
            if remaining() <= 0:
                raise _BatchReadBudgetError("Batch reasoning time expired; incomplete evidence was not accepted")
            if operation_count + len(pending) > settings.automap_context_max_operations:
                raise _BatchReadBudgetError("Batch exact-retrieval operation limit reached")
            pending = [operation for operation in pending if not any(
                item.get("request") == {key: value for key, value in operation.items() if key != "cursor"}
                and not item.get("result", {}).get("error") for item in results
            )]
            if not pending:
                break
            chunk, pending = pending[:24], pending[24:]
            retrieval_started = time.monotonic()
            response = store.read_many({"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash,
                                       "operation": "multi_read", "reads": chunk}, max_bytes=page_bytes,
                                       max_total_bytes=settings.agent_outbound_message_max_bytes)
            operation_count += len(chunk)
            timings["retrieval"] += time.monotonic() - retrieval_started
            for item in response["results"]:
                result, operation = item["result"], item["request"]
                exact_operation = {key: value for key, value in operation.items() if key != "cursor"}
                if not result.get("next_cursor") and not result.get("error"):
                    key = encoded(exact_operation)
                    if not any(previous.get("read_key") == key for previous in results):
                        results.append({"read_key": key, "request": exact_operation,
                                        "result": store.exact_completed_result(exact_operation)})
                elif result.get("error"):
                    if parallel_enabled:
                        raise ValueError("Parallel exact evidence hydration failed")
                    results.append(item)
                events.append({**operation, "error": result.get("error"), "page": result.get("page"),
                               "page_count": result.get("page_count")})
                if result.get("next_cursor"):
                    pending.append({**operation, "cursor": result["next_cursor"]})

    def bounded_messages():
        packet = (batch_packet(store, results, missing=deficits, registry_projection=projection)
                  if projection is not None else batch_packet(store, results, missing=deficits))
        packet["source_preparation_issues"] = preparation_issues
        store.check_positive_budget(settings.automap_learning_max_chars)
        return budget_messages(batch_messages(packet), max_chars=settings.agent_outbound_message_max_chars,
                               max_bytes=settings.agent_outbound_message_max_bytes)

    def read_agent_operations(operations):
        if projection is None:
            read_operations(operations)
            return
        # Only agent-requested additions are transactional. Required driver,
        # constraint and candidate reads still use the fail-closed path.
        state = {key: deepcopy(getattr(store, key)) for key in (
            "reads", "cursors", "pages_read", "discovered", "evidence",
            "historical_dependencies", "historical_dependency_owners",
        )}
        result_count = len(results)
        try:
            read_operations(operations)
            bounded_messages()  # Complete bodies must fit before admitting reads.
        except (_BatchReadBudgetError, AgentPayloadBudgetError):
            for key, value in state.items():
                setattr(store, key, value)
            del results[result_count:]
            # Attempted operations remain charged; rollback is not a budget reset.
            detail = ("Insufficient evidence: optional exact reads exceeded the batch budget; "
                      "coverage remains non-exhaustive. Use admitted evidence or return unresolved; "
                      "do not infer absence from unread sources.")
            parallel_warnings.append(ApiWarning(code="parallel_optional_read_budget_exceeded", message=detail))
            for target in attributes.keys() - completed.keys():
                reasons[target] = detail
                deficits[target] = [detail]

    reason = "Batch did not return a grounded mapping"
    stage = "discovery"
    try:
        discovery_started = time.monotonic()
        store.discover_batch(lambda targets: service._discover_auto_map_batch_evidence(req, targets))
        timings["discovery"] = time.monotonic() - discovery_started
        if parallel_enabled:
            stage = "parallel_preparation"
            preparation_started = time.monotonic()
            from app.core.automap_parallel import prepare_parallel
            from app.core.automap_retrieval import ParallelRegistryProjection
            deadline = started + settings.automap_context_target_seconds
            runtime = runtime_factory(req=req, decision=decision, store=store, deadline=deadline)
            if not isinstance(runtime, ParallelRuntimeBundle):
                raise TypeError("Trusted runtime factory must return ParallelRuntimeBundle")
            preparation = prepare_parallel(store, scope=runtime.scope, backend=runtime.backend,
                admission=runtime.admission, archive=runtime.archive, limits=runtime.limits,
                deadline=deadline, cancellation=runtime.cancellation)
            parallel_warnings.extend(preparation.warnings)
            if preparation.coverage.mapping_blocked:
                raise ValueError("Mandatory parallel global context is unavailable; final mapping is blocked")
            projection = ParallelRegistryProjection(store, preparation)
            timings["preparation"] = time.monotonic() - preparation_started
        mandatory = []
        stage = "exact_evidence"
        for target in attributes:
            mandatory.extend(store.required_operations(target, {"source_attributes": []}))
        if projection is not None:
            mandatory.extend(projection.read_operations)
        read_operations(mandatory)
        previous_deficits = None
        for _round in range(settings.automap_context_max_rounds):
            if runtime is not None and runtime.cancellation is not None and runtime.cancellation.is_set():
                raise ValueError("Parallel batch canceled")
            if remaining() <= 0:
                reason = "Batch reasoning time expired; incomplete evidence was not accepted"
                break
            messages = bounded_messages()
            stage = "source_mapping_agent"
            peak_bytes = max(peak_bytes, len(encoded(messages).encode("utf-8")))
            model_started = time.monotonic()
            raw, final_thread, final_payload = service._agent.run_detailed(
                messages, agent=service._source_mapping_agent_name, thread_id=None, parent_message_id=None,
                request_timeout=max(1, min(getattr(service._agent, "_timeout", 240), remaining())),
            )
            model_calls += 1
            timings["model"] += time.monotonic() - model_started
            envelope = json.loads(_extract_json_object(raw))
            stage = "mapping_validation"
            if parallel_enabled:
                agent_warnings.extend(ApiWarning.model_validate(warning) for warning in envelope.get("warnings", []) or [])
                agent_warnings.extend(ApiWarning.model_validate(warning) for warning in (final_payload or {}).get("warnings", []) or [])
            delegation = (envelope.get("meta") or {}).get("delegation")
            if isinstance(delegation, dict):
                if delegation.get("tool") in {"AUTO_MAP_CONTEXT", "ReadAutoMapContext", "SearchMappingEvidence", "ReadMappingEvidence"}:
                    from app.core.automap_tools import normalize_delegation
                    normalized = normalize_delegation(delegation, store.snapshot_hash)
                    if normalized["operation"] == "search_more":
                        if projection is not None:
                            affected = set(normalized["targets"])
                            if not affected <= set(attributes):
                                raise ValueError("Search-more target is outside the owning batch")
                            detail = "Parallel evidence generation is frozen; new discovery requires a new batch with explicit unresolved scope"
                            parallel_warnings.append(ApiWarning(code="parallel_search_more_blocked", message=detail,
                                                                field="context.parallel_preparation"))
                            for target in affected - completed.keys():
                                reasons[target] = detail
                            reason = detail
                            break
                        if any(target in completed for target in normalized["targets"]):
                            raise ValueError("Completed target cannot mix a new evidence generation")
                        search_started = time.monotonic()
                        search_result = store.search_more(normalized,
                            lambda targets, **options: service._discover_auto_map_batch_evidence(req, targets, **options),
                            max_rounds=settings.automap_search_more_rounds, max_bytes=page_bytes,
                            active_limit=settings.automap_learning_active_limit)
                        timings["discovery"] += time.monotonic() - search_started
                        results = [item for item in results if item.get("request", {}).get("operation") not in {"evidence", "discover"}
                                   or item["request"].get("target") not in normalized["targets"]]
                        inactive_dependencies = {identity for identity, (target, _category, ids) in
                            store.historical_dependency_owners.items() if target in normalized["targets"]
                            and not ids & store.active_evidence_ids(target)}
                        results = [item for item in results if not (item.get("request", {}).get("operation") == "dependency"
                                   and item["request"].get("relation_id") in inactive_dependencies)]
                        results.append({"request": {"operation": "search_more"}, "result": search_result})
                        required = [operation for target in normalized["targets"]
                                    for operation in store.required_operations(target, {"source_attributes": []})]
                        # Category contents changed: replay exact active evidence,
                        # not a stale previous candidate body or completion marker.
                        required.extend({"operation": "evidence", "target": target, "category": category}
                                        for target in normalized["targets"] for category in store.mandatory_categories(target))
                        read_operations(required)
                    else:
                        read_agent_operations(normalized["reads"])
                elif delegation.get("tool") == "CORTEX_ANALYST":
                    results.append(service._auto_map_analyst_evidence(req, delegation, decision, store.snapshot_hash))
                else:
                    raise ValueError("Unsupported batch delegation")
                continue
            if projection is not None:
                projection.validate(store)
                if remaining() <= 0 or (runtime.cancellation is not None and runtime.cancellation.is_set()):
                    raise ValueError("Parallel batch expired or canceled before validation")
            parsed = service._parse_envelope(raw)
            result = parsed[1]
            if parsed[4] is not None or parsed[6] == STTMStatus.FAILED or not isinstance(result, SourceMappingResult):
                raise ValueError("Agent did not return a successful structured batch result")
            candidates = {}
            for name, candidate in result.mappings.items():
                target = target_name(name)
                if target not in attributes or target in candidates:
                    raise ValueError("Agent returned a foreign or duplicate batch target")
                candidates[target] = candidate
            deficits, required = {}, []
            validation_started = time.monotonic()
            for target, attribute in attributes.items():
                if target in completed:
                    continue
                candidate = candidates.get(target)
                if candidate is None:
                    deficits[target] = ["Requested target was omitted; return it or explicitly unresolved"]
                    continue
                if str(candidate.unmatched_reason or "").startswith("Agent mapping failed schema validation for:"):
                    deficits[target] = [candidate.unmatched_reason]
                    reasons[target] = candidate.unmatched_reason
                    continue
                if candidate.transformation_classification == "unresolved" and not candidate.source_attributes:
                    if preparation is not None and not preparation.coverage.exhaustive:
                        candidate = candidate.model_copy(update={"unmatched_reason": (
                            "Insufficient evidence: parallel coverage is non-exhaustive; "
                            "no grounded mapping was established for this target. "
                            "Unread or omitted sources may contain a match.")})
                    completed[target] = candidate
                    continue
                missing = service._validate_auto_map_candidate(req, store, attribute, candidate)
                if not missing:
                    completed[target] = candidate
                else:
                    deficits[target] = missing
                    reasons[target] = "Missing exact evidence: " + "; ".join(missing)
                    required.extend(store.required_operations(target, candidate.model_dump(mode="json")))
                    if candidate.preprocessing_rule and str(candidate.preprocessing_rule_type or "DIRECT").upper() not in {"DIRECT", "IDENTITY", "VALUE"}:
                        from sqlglot import exp, parse_one
                        references = [column.sql(dialect="snowflake") for column in
                                      parse_one(candidate.preprocessing_rule, read="snowflake").find_all(exp.Column)]
                        required.extend(store.required_operations(target, {"source_attributes": references}))
            timings["validation"] += time.monotonic() - validation_started
            if len(completed) == len(attributes):
                break
            if deficits == previous_deficits and not required:
                reason = "Agent repeated batch decisions without resolving evidence deficits"
                break
            previous_deficits = deficits.copy()
            read_operations(required)
        else:
            reason = "Batch reached its bounded model-round limit"
    except AgentPayloadBudgetError as exc:
        reason = f"Exact batch evidence exceeds the complete-message budget; no rule was truncated: {exc}"
        if parallel_enabled:
            parallel_warnings.append(ApiWarning(code="parallel_message_budget_exceeded", message=reason))
    except _BatchReadBudgetError as exc:
        if parallel_enabled:
            reason = ("Insufficient exact evidence: batch retrieval budget exhausted; "
                      "remaining targets are unresolved and coverage is non-exhaustive")
            for target in attributes.keys() - completed.keys():
                reasons[target] = reason
            parallel_warnings.append(ApiWarning(code="parallel_read_budget_exceeded", message=reason))
        else:
            reason = f"Batch evidence/reasoning failed (ValueError): {exc}"
    except Exception as exc:
        if parallel_enabled:
            logger.error("Auto-map batch failed request_id=%s batch_index=%s stage=%s error_type=%s completed_targets=%s",
                         req.request_id, req.meta.get("auto_mapping_batch_index"), stage,
                         type(exc).__name__, len(completed))
            reason = f"Auto-map {stage} failed; remaining targets require review."
            parallel_warnings.append(ApiWarning(code="parallel_stage_failed", message=reason, field=stage))
        else:
            reason = f"Batch evidence/reasoning failed ({type(exc).__name__}): {exc}"
    mappings = {}
    audits = []
    for target, attribute in attributes.items():
        candidate = completed.get(target) or AttributeMapping(source_attributes=[], confidence_score=0,
            transformation_classification="unresolved", unmatched_reason=reasons.get(target, reason))
        mappings[attribute.target_attribute] = candidate.model_dump(mode="json")
        audits.append({"target": attribute.target_attribute, "snapshot_hash": store.snapshot_hash,
                       "evidence_ids": sorted(store.evidence_ids(target)),
                       "retrieval_diagnostics": retrieval_diagnostic_summary(
                           store.discovered.get(target, {}).get("diagnostics")),
                       "status": "unresolved" if candidate.transformation_classification == "unresolved" else "grounded"})
    envelope = {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": mappings}}}
    parallel_meta = {}
    if parallel_enabled:
        warnings = list({encoded(warning.model_dump(mode="json")): warning.model_dump(mode="json")
                         for warning in [*agent_warnings, *parallel_warnings]}.values())
        parallel_meta = {"enabled": True, "warnings": warnings,
                         "coverage": asdict(preparation.coverage) if preparation else None,
                         "generation": preparation.candidate_manifest.get("generation") if preparation else None,
                         "search_more_policy": "frozen_generation_requires_new_batch",
                         "assistant_context": {"warnings": warnings, "non_exhaustive": True,
                             "instruction": "These mappings are proposals from non-exhaustive evidence. Explain coverage warnings; do not infer no-match from omitted tables."}}
        envelope["warnings"] = warnings
        envelope["meta"] = {"parallel_preparation": parallel_meta}
        final_payload = {**(final_payload or {}), "warnings": warnings, "parallel_preparation": parallel_meta}
    return json.dumps(envelope), final_thread, {
        **(final_payload or {}),
        "auto_map_admitted_evidence": {target: {category: store.evidence[target][category]
                                             for category in store.mandatory_categories(target)}
                                      for target in store.targets},
        "auto_map_retrieval": {
            **({"parallel_preparation": parallel_meta, "warnings": parallel_meta["warnings"]} if parallel_enabled else {}),
            "strategy": STRATEGY_VERSION, "target_count": len(mappings), "model_call_count": model_calls,
            "operation_count": operation_count, "peak_message_bytes": peak_bytes, "targets": audits,
            "source_preparation_issues": preparation_issues,
            "search_work": store.search_work, "additional_search_rounds": store.search_rounds,
            "completed_reads": [list(identity) for identity in sorted(store.reads)], "read_events": events,
            "timings_ms": {key: round(value * 1000, 1) for key, value in timings.items()},
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "wall_time_enforcement": "between_operations_and_network_timeout_not_hard_job_cancellation",
        },
    }
