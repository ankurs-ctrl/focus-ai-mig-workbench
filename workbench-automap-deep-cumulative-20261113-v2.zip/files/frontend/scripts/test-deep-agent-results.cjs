const assert = require('node:assert/strict');
const ts = require('typescript');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.resolve(__dirname, '../src/features/ai-agent/agent-artifact-text.ts'), 'utf8');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
const exported = {};
vm.runInNewContext(compiled, { exports: exported });
for (const failed of ['needs review', 'not passed']) {
  const text = `Saved draft.\n\n### Customers: compiled SQL\nCompile passed; sample preview ${failed}.\n\`\`\`sql\nSELECT ID FROM DB.S.CUSTOMERS\n\`\`\``;
  const result = exported.separateSqlPreview(text);
  assert.equal(result.artifacts.length, 1);
  assert.equal(result.artifacts[0].sql, 'SELECT ID FROM DB.S.CUSTOMERS');
  assert.equal(result.artifacts[0].compileValid, true);
  assert.equal(result.artifacts[0].previewValid, false);
  assert.equal(result.message.includes('review workspace'), false);
}
assert.equal(exported.TARGET_STATUS_LABELS.ready, 'Draft generated');
assert.equal(exported.TARGET_STATUS_LABELS.needs_review, 'Draft generated');
assert.equal(exported.TARGET_STATUS_LABELS.compile_failed, 'Compile failed');
assert.equal(exported.TARGET_STATUS_LABELS.preview_failed, 'Preview failed');
console.log('Draft results preserve generated SQL, failed checks, and legacy transcript hydration without routine review prompts.');
