# Auto-map scoped retrieval (opt-in)

## Implementation

`AUTOMAP_CONTEXT_RETRIEVAL_V1` defaults to false. When enabled, batch planning
and the worker use the same bounded manifest. The exact governed request remains
in memory/transport; semantic bodies and historical evidence are not truncated.
The manifest contains the full column namespace, current graph, joins, filters,
Value bindings, table contracts, snapshot hash and available evidence identities.

The mapping agent requests application-handled `AUTO_MAP_CONTEXT` operations:
`discover`, `evidence`, `column`, `columns`, `table`, and `dependency`. These are
response delegations, not registered native Snowflake tools. Reads reject foreign
scope arguments, stale snapshots and guessed cursors. Large records are paged as
exact path/value fragments with server-issued cursors and content hashes. Derived
SQL reads include the parent relation closure.

Discovery queries the existing recipe and FIR Search services, then re-reads
canonical evidence with the caller session and checks lifecycle/scope. Recipe
hydration uses the existing source/type/grain/relationship applicability service.
Search failure is not no-match. Corrections and linked precedent are mandatory
regardless of Search ranking. Iterative correction retrieval is project-scoped
and has no top-five cutoff; the legacy path remains unchanged.

Each target gets independent bounded reasoning, up to 24 continuation steps and
240 seconds by default. Worker batches contain one target; the existing in-flight
limit controls concurrency. Raw evidence does not accumulate across targets.
Within one target, exact results remain in the complete-message budget. If all
required evidence cannot fit, the target is explicitly unresolved; it is not
silently summarized or clipped. No-progress responses stop rather than spending
all 24 calls repeating an unsupported mapping.

Backend acceptance checks required reads, retrieved citation IDs, selected source
semantics, structural predicate/join semantics, derived closure and compiler
bindings. These checks are not a proof of business correctness; paired accuracy
evaluation is still required before enabling the path broadly.

## Analyst and bootstrap parity

Analyst remains request-scoped backend delegation, not a shared native tool
rebound to the latest mapping. Auto-map may request an actual-data question only
against an existing prepared semantic view/YAML. SQL is checked as a single
read-only query restricted to selected physical tables before bounded preview.
Unknown functions require review. SQL generation and observed rows are reported
separately. Analyst is not used to read arbitrary registry JSON or mapping history.

The builder and source-mapping YAML specs now describe these protocols. Bootstrap
no longer automatically restores all promoted bundles as native Analyst tools;
`--restore-bundle-analyst-tools` retains that legacy behavior as an explicit opt-in.
The recipe Search definition was already included in bootstrap and is unchanged.

## Acceptance evidence (2026-10-15)

- Latest full backend suite: 825 passed, three inherited failures (two protected
  deploy-script expectations and a POSIX permission assertion on Windows).
  All 25 new scoped-retrieval regressions passed.
- Scripted model tests exercise the actual private worker router and transport:
  all 37 targets returned, 148 isolated calls, exact semantics preserved, no
  mapping saves. This verifies application orchestration, not live-model accuracy.
- Real ACCOUNT registry read: 441,540 serialized characters and 475 attributes.
  The initial 37-target manifest was 52,327 characters before the later small
  explicit protocol addition. Both rich attribute records and nested summary
  records are indexed; original PK/statistical evidence remains available.
- Live isolated ACCOUNT identity mapping did not pass. One run did request
  discovery: both `CSS_AUTOMAP_RECIPES_V1` and `CSS_FIR_KNOWLEDGE` returned HTTP 200,
  canonical scope/trust checks rejected six knowledge IDs, and discovery reported
  no-match. The agent then returned a mapping without reading exact column
  semantics. Backend returned unresolved, not a falsely grounded result.
- Live thread for that diagnostic: `b07c477e-9263-47ce-99ae-c4a78f66d64d`.
  Subsequent explicit-template probe also stopped unresolved after two calls:
  `14f9debb-2d07-47d2-b214-30a0a7f59141`.
- A later probe using the existing `data.message` contract completed discovery
  and exact column retrieval and returned the correct ACCOUNT ID identity binding
  in four calls, about 48 seconds, largest serialized message 56,470 bytes.
  Thread: `d87cf94c-db4d-4699-b4bf-39eb73038e53`. Its unsourced exact-precedent
  labels revealed an additional acceptance gap; strict recipe/linked-precedent
  citation checks were added afterward. This is not a broad accuracy pass.
- The subsequent strict-provenance live probe passed all three identity targets
  (`ID`, `ISDELETED`, `MASTERRECORDID`). Each requested scoped discovery and exact
  column semantics; four calls per target, 42.6/46.2/46.1 seconds, largest message
  55,862 bytes. No unsourced accepted-precedent claims remained. Final thread:
  `aa61faa7-5fe3-47e2-868e-c8c829e625d5`. This validates the real retrieval protocol
  and selected identity bindings, not the full HOUSEHOLD mapping workload.
- Later authorized development acceptance synchronized and published both agent
  instruction specs through `agent-studio` save/publish. Complete live specs were
  backed up and models, budgets, actual tools/resources were preserved. The builder
  still has its four existing tools and no native Analyst tool. A live CLI test
  confirmed its request-scoped Analyst delegation explanation.
- The local backend was enabled with process-only retrieval/in-process-worker
  overrides; the configured environment file was not changed. The frontend remains
  on 3000 and backend on 8000. Existing development mapping 9601/project 2301 is
  authorized for acceptance; its initial browser state is backed up locally.
- The actual multitable HOUSEHOLD manifest exposed an inline contract duplication:
  134,485 characters for one target. Large table contracts now have exact hashed
  handles and mandatory table reads rather than duplicated inline bodies. The same
  saved request measures 77,587 characters. All 26 focused retrieval tests pass.
- Full application acceptance is still in progress. No mapping was published and
  no target data was loaded. Job completion alone will not be counted as accuracy.
- The first full application job `e2e6c20a-17b5-47d9-b661-04cbbda7b271` finished:
  37 targets/37 singleton batches, 1,557 seconds, all 37 unresolved. The browser
  reached its 20-minute safety timeout. This is a failed accuracy and latency
  acceptance. The singleton rollout is rejected and its local process override
  disabled. The replacement must use 3-4 total concurrent batches per mapping job,
  not per service instance; no SPCS instance scaling is part of this change.
- Follow-up fixes deduplicate identical target-scoped learning/execution evidence
  and losslessly intern repeated strings and complete records. Exact round-trip
  tests preserve rules and SQL. Population retrieval excludes unrelated conversation
  and other-target outcomes while retaining exact query-shaping fields. The real
  initial manifest factors to 65,974 characters; 29 focused tests pass. These later
  fixes have not yet been loaded into the running first full-job process.
- Latest broader check before these follow-ups: 826 passed, the same three inherited
  failures. An actual saved LEGACY_ID target replay with follow-up packaging still
  returned unresolved after its reasoning time bound; it is not an accuracy pass.

## Remaining release gates

The supported CLI was obtained from the official Windows package into a temporary
directory and its SHA256 verified; PATH was not changed. The scoped synchronization
helper `scripts/sync_workbench_agent_specs.py` preserves live non-instruction fields
and uses supported workspace-write/save/readback operations. Do not run broad
bootstrap merely to update two agents or bypass restricted-session-scope denials.

After spec synchronization, rerun the live isolated probe, then paired ACCOUNT /
HOUSEHOLD cases covering nonlexical columns, corrections, linked precedent,
complex CTEs, null behavior and current-project Value bindings. Measure mapping
correctness, mandatory evidence recall, dependency completeness, unresolved rate,
latency and full-message size. A passing identity mapping is not sufficient to
assert unchanged accuracy.

`scripts/test_automap_scoped_live.py --env-file <verified-local-env> --targets 37`
checks the real registry/manifest without model invocation. Add `--live` for the
identity probe and `--live-search` for actual scoped discovery. It never saves
mapping rows or publishes agents. Respect the selected connection's existing
permissions and use the trusted CA; never disable TLS verification.

Do not edit `scripts/deploy_spcs_client_snow_safe.ps1`. Its verified SHA256 remains
`486DDC012EFFA2EF7B19C6A1FD40CB7622F8929A15A0C3DA9D2E856B9837BAC6`.