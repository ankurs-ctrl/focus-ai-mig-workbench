# V9 review findings corrected in V10

V10 is a cumulative source delta from the user-confirmed V5.1 baseline `49c6a576def79e5bb02aa8326502a90d680b9477`. It includes V6–V9 and replaces those ZIPs. The client reviewer reports deployed V8 `8b3a37f`; that remote commit was not independently fetched here. No code has been pushed or deployed from this worktree.

## 1. Supported agent aliases rejected during evidence review

V9 compared raw agent labels against `AGT_SOURCE_MAPPING`. The main parser already accepted the additional documented labels `SOURCE_MAPPING_AGENT` and `source_mapping`, so actual live replies could fail the block gate despite representing the correct agent.

V10 calls the existing application `_normalize_sub_agent` for each supplied root/data identity. This also preserves the existing whitespace behavior. Supported aliases may differ across root/data while denoting the same source agent. Every supplied identity must be a string and normalize to the source agent. Unknown labels, missing identities, malformed values and transformation-agent identities remain invalid; root source plus nested transformation is rejected.

This reuses only identity normalization. The permissive legacy completion parser is not involved. The full envelope allowlist, explicit terminal status, errors, conflicting result locations, nested metadata/delegation, block identity, quote literalness, duplicate keys, nonfinite checks and output budget remain enforced. Unknown identity exceptions are converted into a safe static review error, without adding raw response content to logs. No shared agent definition, backend dispatch target, recovery identity or admission permit is changed.

Regression coverage checks the Cartesian combination of absent/canonical/enum/short agent locations, malformed and conflicting agents, and aliases combined with delegation/result/status/fact poisons. Separate tests run each supported alias through the owning guarded runtime and verify that review succeeds once per block, the decision call runs, a validated mapping is returned and fake-runtime permits are released.

## 2. No-checkbox Auto-map still preserved instead of reevaluating

V9's scope helper enumerated every target but used `preserve_and_complete`. Merely including target names did not authorize the backend to reevaluate existing definitions. That default was not the requested behavior.

V10's visible default, including an empty options object, sends `reeval_all` and the exact all-target scope. Both the pending reducer and the actual request thunk use that same helper. Only rows with actual existing definitions are recorded as replacement-review targets in the immutable run; blank rows are not accidentally treated as existing replacements. The backend evaluates all requested targets, while the frontend can apply supported new mappings to empty rows and queue replacements for existing definitions.

The 37-target frontend control uses one existing source definition, one empty-string constant and one project-attribute definition. It executes the actual request thunk, captured wire metadata, partial and terminal reducers, completion counts and explicit acceptance thunk. Its expected result is **34 new mappings plus three queued replacements**, with all three original definitions and statuses unchanged before acceptance. A separate backend test verifies that all 37 targets enter the pending reevaluation partition, including the three authored definitions, and review counts distinguish the 34 new results from three replacements.

Existing mappings retain their original status during reevaluation; a pending replacement is not validation of the saved definition. Originally UNMAPPED/unproven rows remain UNMAPPED until an executable proposal is accepted. The explicit preserve-only compatibility operation still exercises the stricter existing unproven-baseline behavior; no blanket status certification was introduced. Tests covering that old operation now request `action: complete` explicitly instead of relying on a default whose product meaning has intentionally changed.

Checked existing/empty targets still use only the checked scope; unresolved responses preserve existing definitions and verified alternatives. Single/Accept-all, partial/terminal replay, newer saved edits, stale signatures, current Values checks and unsupported capabilities are tested. A server without the required reevaluation capability receives no job POST and no silent preservation fallback. Deployment must have the fast-path capability enabled for the intended project, as in the reviewed UAT setup.

## 3. Windows-compatible pytest display IDs

The two variants of `test_lossless_text_factoring_handles_long_delimiter_free_suffix_in_linear_time` formerly embedded the large literal suffix in the pytest display ID. On Windows, propagating that ID through `PYTEST_CURRENT_TEST` could exceed environment-variable limits before the assertion ran.

They now use the explicit IDs `ascii-delimiter-free` and `unicode-escaped-delimiter-free`. The 150,000-character ASCII and 160,000-character Unicode/escape inputs, lossless roundtrip checks and five-second bound are unchanged. The selected suite is collected without modifying nodes in memory; exact collected counts and maximum ID length are recorded in TEST_RESULTS.md. No production limit or input was reduced to make the tests run.

## Compatibility and rollout

- V8/V9 stale-proposal, preservation, null-binding, CTE boundary, typed profiling, evidence graph and exact-size safeguards remain included.
- Existing `candidate_source_attributes`, confidence score/reason, UI thresholds and specialist SQL validation are unchanged.
- Explicit legacy preservation/retry requests, including already frozen jobs, retain their original meaning. New no-checkbox UI jobs use reevaluation; old jobs are not silently broadened.
- The preflight receipt version remains `fast-target-preflight-v5-typed-evidence`; the V10 corrections do not alter the input-size contract or immutable archive format. Updating from deployed V8 still requires fresh deliberate jobs after all images are updated.
- Rebuild frontend/web and Auto-map worker images together through the client's existing pipeline. No local Docker build, SQL migration, env modification, push or deployment occurred here.
- Client Coco owns independent review and live Snowflake/model/browser acceptance. Synthetic controls do not certify population logic, real mapping accuracy or runtime latency.
