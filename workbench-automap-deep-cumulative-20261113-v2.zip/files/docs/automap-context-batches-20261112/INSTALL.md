# Context packing, batch handoff and diagnostics

This cumulative overlay includes the previous SQL-upload, confidence, transformation, missing-semantic, bootstrap and administration changes. Preserve existing environment files and credentials.

Deploy matching backend and Auto-map worker images to every SPCS replica and rebuild the frontend. Keep the existing bounded parallel scheduler and execution pool; no additional orchestration, admission-table migration, environment settings, SQL timeout, context ceiling or capacity increase is required. Worker batches submit independently as their preparation commits. Shared Snowflake admission still governs actual model concurrency across replicas.

Run `python scripts/verify_mapping_agent_specs.py`. Apply the three updated AGT_STTM_BUILDER, AGT_SOURCE_MAPPING and AGT_TRANSFORMATION_RULE instruction specs and manifest through the existing instruction-only agent deployment process. Preserve client model choices, tools, resources, permissions and budgets. Retain the prior release's semantic-gap instructions on other installed agents. Do not overwrite client agents with test agents or reset slots/quarantines.

The final normalized message array must fit both 180,000 characters and UTF-8 bytes. Optional evidence is deferred atomically; required current contracts, corrections and selected dependencies remain intact. Oversized undispatched target groups subdivide within the same submission allowance and deadline. A target whose essential contracts cannot fit gets a specific unfinished outcome; completed siblings survive. Deferred evidence is disclosed as non-exhaustive coverage, not treated as absent evidence.

Source citations resolve only through the authorized current catalog, including `src:` citation spellings. The same resolver covers selected sources, retained candidates and required rule columns. Unknown or ambiguous references remain unresolved. Specialist preparation isolates invalid targets; it does not discard successful siblings or guess bindings.

The existing request deadline bounds initial control-session queueing. After a checked exclusive session is acquired, preparation uses one shared ten-second database contention window and at most three attempts. Retries acquire fresh leases after acknowledged rollback, retain the same thread/request/permit and never repeat a model POST. The returned provider run ID uses the same persistence discipline. The session queue preserves FIFO order across polling intervals so active batches and heartbeats cannot be repeatedly bypassed. Active and queued callers pin their reusable pool against cache retirement. Statement and lock timeouts remain unchanged. Uncertain commits and remote outcomes require the existing reconciliation process.

Numeric model confidence is required by agent instructions. Backend estimated confidence remains deterministic and available when a model omits or malforms it. Exact target/candidate identity and structured response validation remain enforced; model compliance is checked, not assumed.

Internal generated aliases are replaced with friendly source labels in diagnostic/UI text. SQL execution bindings remain unchanged. Authored source roles remain visible.

## Local review

The local app is served at http://localhost:13812/projects with backend http://localhost:18812/healthz. The launcher accepts `--host localhost` and `--frontend-origin http://localhost:13812` without editing an environment file. Its account guard restricts it to our separate test account. Source code changes require restarting this non-reloading backend.

## Isolated acceptance

`scripts/validate_automap_durable_live.py --generation-policy draft-v3 --mixed-rules --concurrent-batches --large-fixture --fixture-source-count 12` exercises 40 targets on 12 sanitized sources. Supply the existing local credential path and approved warehouse separately. The 287-source scenario is not a release requirement after the user's scope revision. Offline oversized/multibyte cases still exercise the context ceiling.

The runner records actual POST counts, semantics/FIR/Value markers, SQL query IDs, per-call preparation/model times and per-target definitions. A successful return must also compile and verify expected Snowflake output values; HTTP acceptance alone does not pass. Non-successful runs remain investigations, not acceptance evidence. Preserve any uncertain calls for reconciliation rather than rerunning their IDs.

For this cumulative release, follow `docs/combined-release-20261113/INSTALL.md` for the additional optional evidence-tool table/procedure, agent tool registration and Deep Agent deployment steps. Those steps supersede the earlier instruction-only statement above.
