"""Resolve unchanged join keys through row-preserving CTE projections only."""
from __future__ import annotations
from copy import deepcopy
from sqlglot import exp, parse_one
from sqlglot.errors import ParseError, TokenError
from app.agent_tools.catalog_discovery import identifier_parts
from app.agent_tools.contract_reader import normalize_fqn


def resolve_passthrough_joins(source: dict, relationships: list[dict]) -> list[dict]:
    """Keep physical join evidence usable beneath a driving projection.

    This proves a limited equivalence; it never erases filters, deduplication,
    aggregation, secondary tables, key expressions or renamed output keys.
    Other CTE contracts remain explicit SQL, not guessed physical bindings.
    """
    selected = {normalize_fqn(v) for v in [source.get('driving_source'),
        *(source.get('supporting_sources') or [])] if v}
    derived = source.get('derived_sources') or []
    output = []
    for original in relationships:
        if not isinstance(original,dict):
            output.append(original)
            continue
        join = deepcopy(original)
        receipts = list(join.get('cte_passthrough_sources') or [])
        for side in ('left','right'):
            reference = join.get(side+'_table')
            if normalize_fqn(reference) in selected:
                continue
            parts = identifier_parts(reference)
            if len(parts) != 1:
                continue
            candidates = [v for v in derived if isinstance(v,dict)
                and identifier_parts(v.get('name')) == parts]
            if len(candidates) != 1:
                continue
            cte = candidates[0]
            try:
                query = parse_one(str(cte.get('sql') or cte.get('sql_text') or ''),read='snowflake')
                if not isinstance(query,exp.Select):
                    continue
                if any(query.args.get(k) for k in ('joins','where','group','having','qualify','limit','offset','distinct','with_')):
                    continue
                if any(isinstance(v,(exp.AggFunc,exp.Subquery)) for v in query.walk()):
                    continue
                from_clause = query.args.get('from_')
                table = from_clause.this if from_clause is not None else None
                if not isinstance(table,exp.Table) or any(v for k,v in table.args.items() if k not in {'this','db','catalog','alias'}):
                    continue
                physical_table = table.copy()
                physical_table.set('alias',None)
                physical = normalize_fqn(physical_table.sql(dialect='snowflake'))
                if physical not in selected:
                    continue
                keys = [identifier_parts(v.get(side+'_column')) for v in join.get('conditions') or [] if isinstance(v,dict)]
                if not keys or any(len(v)!=1 for v in keys):
                    continue
                projections = {}
                stars = False
                modified_star = False
                for projection in query.expressions:
                    value = projection.this if isinstance(projection,exp.Alias) else projection
                    if isinstance(value,exp.Star) or isinstance(value,exp.Column) and value.is_star:
                        stars = True
                        star = value.this if isinstance(value,exp.Column) else value
                        modified_star = modified_star or any(star.args.values())
                        continue
                    name = projection.args.get('alias') if isinstance(projection,exp.Alias) else value.this if isinstance(value,exp.Column) else None
                    if isinstance(name,exp.Identifier):
                        identity = tuple(identifier_parts(name.sql(dialect='snowflake')))
                        projections.setdefault(identity,[]).append(value)
                if modified_star:
                    continue
                supported = True
                for key in keys:
                    projected = projections.get(tuple(key),[])
                    if stars and projected:
                        supported = False
                        break
                    if not projected and stars:
                        continue
                    if len(projected)!=1 or not isinstance(projected[0],exp.Column):
                        supported = False
                        break
                    column = projected[0]
                    if identifier_parts(column.this.sql(dialect='snowflake')) != key:
                        supported = False
                        break
                    if column.table and column.table != table.alias_or_name:
                        supported = False
                        break
                if not supported:
                    continue
                join[side+'_table'] = physical
                receipts.append({'side':side,'cte':cte['name'],'physical_table':physical,
                    'proof':'single_table_projection_unchanged_join_keys'})
            except (ValueError,TypeError,AttributeError,ParseError,TokenError):
                # A failed proof never authorizes a rewrite. The existing SQL
                # and source checks retain the original unresolved boundary.
                continue
        if receipts:
            join['cte_passthrough_sources'] = receipts
        output.append(join)
    return output
