"""The firm-value catalogue: which firm values a migration needs, and where.

Every firm migrating to the CRM fills the same fixed target tables with the
same kit of firm values (``SET_FIRM_MIGRATION_VARIABLES`` and
``SET_CORE_MIGRATION_VARIABLES`` in the kit's master-tables script): record
type ids, the transaction firm, the backup owner, legacy id prefixes. The
catalogue records each value's name, kind and type, and the target columns
that use it and how (``value``, ``prefix``, ``fallback``, ``rule``); it never
holds values, which belong to each project (``TBL_PROJECT_ATTRIBUTES``).

It is built from a firm's reference scripts (``scripts/ingest_reference_scripts.py
--build-catalog``) and read by the agent as a prior: a target column no earlier
mapping covers still gets the firm value the kit uses for it, and a project
can be told which values its planned targets need before mapping starts.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

from app.agent_tools.firm_values import Choice, norm, usages_from_rows

DEFAULT_CATALOG_PATH = Path(__file__).with_name("firm_value_catalog.json")

# The kit's master script sets these through two procedures; anything else a
# reference script SETs is recorded as ``script``.
FIRM_KIT = ("MigrationDataSchema", "MigrationMasterSchema", "ClientStartDate", "LegacyHHcPrefix",
            "LegacyContactPrefix", "Referral", "BackupOwnerID", "TransactionFirmID", "ParentOfficeID")
CORE_KIT = ("CoreMigrationDatabase", "OrionHHIDPrefix", "OrionIndvIDPrefix", "HHRecordType", "IndvAcctRecordType",
            "IndvContactRecordType", "HHBaseClientCategory", "TaskRecordTypeID", "NoteTaskRecordTypeID",
            "EventTaskRecordTypeID", "Master_Payout_Date")
DESCRIPTIONS = {
    "CLIENTSTARTDATE": "Date the firm became a client (bffs_ClientStartDate__c).",
    "LEGACYHHCPREFIX": "Prefix of household and account legacy ids (keep under 14 characters).",
    "LEGACYCONTACTPREFIX": "Prefix of contact legacy ids.",
    "REFERRAL": "Default referral source.",
    "BACKUPOWNERID": "CRM user that owns a record when the source owner has no CRM user.",
    "TRANSACTIONFIRMID": "CRM account id of the transaction firm.",
    "PARENTOFFICEID": "CRM account id of the parent office.",
    "ORIONHHIDPREFIX": "Prefix of Orion household ids.",
    "ORIONINDVIDPREFIX": "Prefix of Orion individual ids.",
    "HHRECORDTYPE": "Record type id of household accounts.",
    "BIZACCTRECORDTYPE": "Record type id of business accounts.",
    "INDVACCTRECORDTYPE": "Record type id of person accounts.",
    "INDVCONTACTRECORDTYPE": "Record type id of individual contacts.",
    "BIZCONTACTRECORDTYPE": "Record type id of business contacts.",
    "HHBASECLIENTCATEGORY": "Default client category of households.",
    "TASKRECORDTYPEID": "Record type id of tasks (calls and tasks).",
    "NOTETASKRECORDTYPEID": "Record type id of tasks created from notes.",
    "EVENTTASKRECORDTYPEID": "Record type id of events (meetings).",
    "MASTER_PAYOUT_DATE": "Default master payout date.",
    "OTHERROLEID": "Relationship role id used when no specific role applies.",
    "FEESCHEDULEBACKFILL": "Fee schedule used when an agreement has none.",
}
_DATE_NAMES = {"CLIENTSTARTDATE", "MASTER_PAYOUT_DATE"}
_STRUCTURAL = ("SCHEMA", "DATABASE", "TABLE")


@dataclass
class CatalogValue:
    name: str
    kind: str
    type: str
    description: str
    used_for: list[dict[str, str]] = field(default_factory=list)


def kind_of(name: str) -> str:
    key = norm(name)
    if key in {norm(item) for item in FIRM_KIT}:
        return "firm"
    if key in {norm(item) for item in CORE_KIT}:
        return "core"
    return "script"


def build_catalog(scripts: Iterable[tuple[str, str, Any]], names: Iterable[str], *, source: str) -> dict[str, Any]:
    """Catalogue from ``(file, target_table, parsed SqlDocument)`` of reference scripts.

    ``names`` are the firm values the scripts SET (their spelling is kept).
    """
    entries: dict[str, CatalogValue] = {}
    for name in names:
        key = norm(name)
        if any(key.endswith(part) for part in _STRUCTURAL):
            continue
        entries[key] = CatalogValue(
            name=name, kind=kind_of(name), type="DATE" if name.upper() in _DATE_NAMES else "VARCHAR",
            description=DESCRIPTIONS.get(name.upper(), ""),
        )
    for file, target, parsed in scripts:
        rows = [{
            "TARGET_COLUMN": item.target_alias,
            "MAPPING_MODE": "attribute" if str(item.constant_value or "").startswith("$") else item.mapping_mode,
            "ATTRIBUTE_NAME": str(item.constant_value)[1:] if str(item.constant_value or "").startswith("$") else None,
            "CONSTANT_VALUE": item.constant_value, "EXPRESSION": item.transformation,
            "PROJECT_ID": "", "STTM_ID": file, "STATUS": "PUBLISHED",
        } for item in parsed.column_mappings if item.target_alias]
        for usage in usages_from_rows(rows):
            entry = entries.get(norm(usage.name))
            if entry is None:
                continue
            binding = {"target": str(target).split(".")[-1].upper(), "column": usage.target_column,
                       "shape": usage.shape, "script": file}
            if binding not in entry.used_for:
                entry.used_for.append(binding)
    return {
        "version": 1,
        "source": source,
        "values": [entry.__dict__ for entry in sorted(entries.values(), key=lambda item: (item.kind, item.name.upper()))],
    }


@lru_cache(maxsize=4)
def _load(path: str) -> dict[str, Any]:
    file = Path(path)
    if not file.is_file():
        return {"version": 1, "values": []}
    return json.loads(file.read_text(encoding="utf-8"))


def load_catalog(settings: Any = None) -> dict[str, Any]:
    path = str(getattr(settings, "migration_agent_firm_value_catalog_path", "") or "") if settings else ""
    return _load(path or str(DEFAULT_CATALOG_PATH))


def _leaf(table: str) -> str:
    return str(table or "").replace('"', "").split(".")[-1].upper()


def catalog_choices(catalog: dict[str, Any], target_table: str, target_columns: Iterable[str]) -> dict[str, Choice]:
    """The firm value the kit uses for each of these target columns (one per column)."""
    leaf = _leaf(target_table)
    by_column: dict[str, tuple[str, str]] = {}
    for value in catalog.get("values") or []:
        for use in value.get("used_for") or []:
            if str(use.get("target") or "").upper() != leaf:
                continue
            key = norm(use.get("column"))
            # Whole-column values beat prefixes and fallbacks for the same column.
            current = by_column.get(key)
            rank = {"value": 0, "prefix": 1, "fallback": 2, "rule": 3}.get(str(use.get("shape")), 4)
            if current is None or rank < {"value": 0, "prefix": 1, "fallback": 2, "rule": 3}.get(current[1], 4):
                by_column[key] = (str(value["name"]), str(use.get("shape")))
    choices: dict[str, Choice] = {}
    for column in target_columns:
        found = by_column.get(norm(column))
        if found:
            choices[column] = Choice(target_column=column, name=found[0], shape=found[1], support=0,
                                     projects=["the firm-value catalogue"], origin="catalog")
    return choices


def required_values(catalog: dict[str, Any], target_tables: Iterable[str]) -> dict[str, dict[str, Any]]:
    """Firm values the planned target tables use, with the columns that use them."""
    leaves = {_leaf(table) for table in target_tables}
    required: dict[str, dict[str, Any]] = {}
    for value in catalog.get("values") or []:
        uses = [use for use in value.get("used_for") or [] if str(use.get("target") or "").upper() in leaves]
        if uses:
            required[norm(value["name"])] = {**{k: value.get(k) for k in ("name", "kind", "type", "description")},
                                             "used_for": [f"{use['target']}.{use['column']} ({use['shape']})"
                                                          for use in uses]}
    return required


def inventory(
    catalog: dict[str, Any], target_tables: Iterable[str], held: dict[str, dict[str, Any]],
    holders: Iterable[dict[str, Any]] = (), *, project_id: str | None = None,
) -> dict[str, Any]:
    """Which firm values the planned targets need, which the project holds, and who holds the rest.

    ``held`` is the project's usable values by normalized name; ``holders``
    are other projects' active values (``PROJECT_ID``, ``PROJECT_NAME``,
    ``ATTRIBUTE_NAME``, ``ATTRIBUTE_VALUE``).
    """
    required = required_values(catalog, target_tables)
    missing = {key: item for key, item in required.items() if key not in held}
    by_project: dict[str, dict[str, Any]] = {}
    for row in holders:
        pid = str(row.get("PROJECT_ID") or "")
        key = norm(row.get("ATTRIBUTE_NAME"))
        if not pid or pid == str(project_id or "") or key not in missing:
            continue
        entry = by_project.setdefault(pid, {"project_id": pid, "project_name": row.get("PROJECT_NAME"), "names": []})
        entry["names"].append(missing[key]["name"])
    sources = sorted(by_project.values(), key=lambda item: -len(item["names"]))
    return {
        "required": list(required.values()),
        "held": sorted(item["name"] for key, item in held.items() if key in required),
        "held_not_required": sorted(item["name"] for key, item in held.items() if key not in required),
        "missing": list(missing.values()),
        "import_sources": sources[:5],
        "summary": (f"{len(required) - len(missing)} of {len(required)} firm values the planned targets use are set"
                    + (f"; missing {', '.join(item['name'] for item in missing.values())}" if missing else "")
                    + (f". Project {sources[0]['project_id']} ({sources[0]['project_name']}) holds "
                       f"{len(sources[0]['names'])} of the missing ones." if sources else ".")),
    }
