from types import SimpleNamespace

import pytest

from app.core.automap_storage_sql import collect_storage_sql


def test_native_ast_is_disabled_before_execution():
    calls=[]
    def collect(*, _emit_ast=True):
        calls.append(('collect', _emit_ast));return [1]
    def sql(text, params=None, *, _emit_ast=True):
        calls.append(('sql',_emit_ast,text,params));return SimpleNamespace(collect=collect)
    assert collect_storage_sql(SimpleNamespace(sql=sql),'MERGE',[1])==[1]
    assert calls==[('sql',False,'MERGE',[1]),('collect',False)]


def test_sql_failure_is_never_replayed():
    calls=[]
    def sql(text, params=None, *, _emit_ast=True):
        calls.append(text);raise TimeoutError('uncertain')
    with pytest.raises(TimeoutError):collect_storage_sql(SimpleNamespace(sql=sql),'MERGE')
    assert calls==['MERGE']
