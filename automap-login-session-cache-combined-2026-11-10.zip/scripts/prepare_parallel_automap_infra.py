"""Offline, profile-scoped SQL preparation; never connects to Snowflake.

Run the generated stages in order, stopping on any error. Creation is additive;
existing agents and tables are never repaired or replaced. Initialization needs
an externally exclusive CI environment run, with all dispatchers stopped. A
standard-table transaction and conditional INSERT do NOT provide an exclusive
provisioning lock: uniqueness is not enforced. Postvalidation detects observed
races, not writers committing later. Keep the external gate through validation.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import yaml

# Direct script execution and repository-module imports both resolve the existing
# renderer next to this file, not an ambient checkout on PYTHONPATH.
if __package__:
    from .render_spcs_spec import DEPLOYMENT_SCOPES, load_parallel_profile, _unique_json_object
else:
    from render_spcs_spec import DEPLOYMENT_SCOPES, load_parallel_profile, _unique_json_object

ROOT = Path(__file__).resolve().parents[1]
SPEC_PATH = ROOT / "infra/snowflake/agents/agent_spec_automap_scan.yaml"
STAGES = ("create", "validate-agent", "initialize-pool", "expand-pool", "validate-pool")
PERMIT_COLUMNS = """ACCOUNT_NAMESPACE VARCHAR(256) NOT NULL,
    POOL_EPOCH VARCHAR(36) NOT NULL,
    SLOT_ID NUMBER(38, 0) NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    OWNER_TOKEN VARCHAR(32),
    FENCE NUMBER(38, 0) NOT NULL,
    JOB_ID VARCHAR(256),
    CALLER_ID VARCHAR(256),
    GENERATION VARCHAR(256),
    SHARD_ID VARCHAR(256),
    LEASE_EXPIRES_AT TIMESTAMP_LTZ,
    UPDATED_AT TIMESTAMP_LTZ NOT NULL,
    COMPLETION VARCHAR(32),
    RECONCILIATION_REF VARCHAR(256)"""
ARCHIVE_COLUMNS = """OWNER_ID VARCHAR,
    ACCESS_SCOPE VARCHAR,
    SNAPSHOT_ID VARCHAR,
    CONTENT_HASH VARCHAR,
    BODY VARCHAR(16777216),
    CREATED_AT TIMESTAMP_LTZ"""


def literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def load_profile(path: Path, environment: str) -> tuple[dict, dict]:
    """Reuse renderer validation without reading credentials or process settings.

    This validates the profile, NOT a CLI connection or private deployment env.
    Native SQL guards independently verify the actual executing session.
    """
    if environment not in DEPLOYMENT_SCOPES:
        raise ValueError("Only approved DEV and UAT environments are supported")
    try:
        document = json.loads(path.read_text(encoding="utf-8-sig"),
                              object_pairs_hook=_unique_json_object)
        connection = document["scope"]["connection"]
    except (OSError, ValueError, TypeError, KeyError):
        raise ValueError("Profile must be readable, duplicate-free scoped JSON") from None
    scope = dict(DEPLOYMENT_SCOPES[environment], connection=connection)
    host = scope["account_namespace"].lower().replace(".", "-").replace("_", "-") + ".snowflakecomputing.com"
    context = {"SNOWFLAKE_" + key.upper(): scope[key]
               for key in ("database", "schema", "role", "connection")}
    context.update(SNOWFLAKE_ACCOUNT=scope["account_namespace"],
                   SNOWFLAKE_REST_HOST=host,
                   SNOWFLAKE_REGISTRY_HOST=host.replace(".snowflakecomputing.com", ".registry.snowflakecomputing.com"),
                   AUTH_MODE="custom_oauth",
                   SNOWFLAKE_OAUTH_AUTHORIZE_URL=f"https://{host}/oauth/authorize",
                   SNOWFLAKE_OAUTH_TOKEN_URL=f"https://{host}/oauth/token-request")
    settings = load_parallel_profile(path, environment, context)
    if settings["AUTOMAP_PARALLEL_CONTEXT_V1"] != "true":
        raise ValueError("Infrastructure preparation requires an explicit enabled resource profile")
    for key in ("AUTOMAP_PARALLEL_TEST_AGENT", "AUTOMAP_PARALLEL_PERMIT_TABLE_FQN",
                "AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN"):
        if any(len(part) > 255 for part in settings[key].split(".")):
            raise ValueError("Resource identifiers must not exceed 255 characters")
    return scope, settings


def load_spec() -> dict:
    spec = yaml.safe_load(SPEC_PATH.read_text(encoding="utf-8"))
    if (not isinstance(spec, dict)
            or set(spec) != {"models", "orchestration", "instructions", "tools", "tool_resources"}
            or spec["tools"] != [] or spec["tool_resources"] != {}
            or spec["models"] != {"orchestration": "claude-haiku-4-5"}
            or spec["orchestration"] != {"budget": {"seconds": 120, "tokens": 8000}}
            or not isinstance(spec["instructions"], dict)
            or set(spec["instructions"]) != {"response", "orchestration"}
            or any(not isinstance(value, str) or not value.strip()
                   for value in spec["instructions"].values())):
        raise ValueError("Scan specification must preserve the approved tool-free contract")
    return spec


def guard(scope: dict) -> str:
    organization, account = scope["account_namespace"].split(".")
    checks = [("CURRENT_ORGANIZATION_NAME()", organization),
              ("CURRENT_ACCOUNT_NAME()", account), ("CURRENT_ROLE()", scope["role"]),
              ("CURRENT_DATABASE()", scope["database"]), ("CURRENT_SCHEMA()", scope["schema"])]
    condition = "\n      OR ".join(f"COALESCE({function}, '') <> {literal(value)}" for function, value in checks)
    return f"""  IF ({condition}) THEN
    RAISE scope_mismatch;
  END IF;
  IF (CURRENT_TRANSACTION() IS NOT NULL) THEN
    RAISE active_transaction;
  END IF;"""


def block(scope: dict, body: str, *, declarations: str = "") -> str:
    # Quote the entire scripting block rather than using $$: object names may
    # legally contain dollar characters, including two consecutive dollars.
    script = f"""DECLARE
  scope_mismatch EXCEPTION (-20001, 'AUTOMAP_SCOPE_MISMATCH');
  active_transaction EXCEPTION (-20002, 'AUTOMAP_ACTIVE_TRANSACTION');
{declarations}BEGIN
{guard(scope)}
{body}
END;"""
    return "EXECUTE IMMEDIATE " + literal(script) + ";\n"


def inventory_query(settings: dict) -> str:
    table = settings["AUTOMAP_PARALLEL_PERMIT_TABLE_FQN"]
    namespace = literal(settings["AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE"])
    epoch = literal(settings["AUTOMAP_PARALLEL_POOL_EPOCH"])
    capacity = int(settings["AUTOMAP_PARALLEL_POOL_CAPACITY"])
    return f"""SELECT COUNT(*), COUNT(DISTINCT SLOT_ID),
      COALESCE(COUNT_IF(
        ACCOUNT_NAMESPACE IS NULL OR ACCOUNT_NAMESPACE <> {namespace}
        OR POOL_EPOCH IS NULL OR POOL_EPOCH <> {epoch}
        OR SLOT_ID IS NULL OR SLOT_ID NOT BETWEEN 1 AND {capacity}
        OR SLOT_ID <> TRUNC(SLOT_ID)
        OR STATE IS NULL OR STATE NOT IN ('FREE', 'HELD', 'QUARANTINED')
        OR FENCE IS NULL OR FENCE < 0 OR FENCE <> TRUNC(FENCE)
        OR UPDATED_AT IS NULL
        OR (STATE = 'FREE' AND OWNER_TOKEN IS NOT NULL)
        OR (STATE IN ('HELD', 'QUARANTINED') AND OWNER_TOKEN IS NULL)
      ), 0)
    INTO :row_count, :distinct_slots, :invalid_rows
    FROM {table};"""


def inventory_assert(settings: dict) -> str:
    capacity = settings["AUTOMAP_PARALLEL_POOL_CAPACITY"]
    return f"""{inventory_query(settings)}
    IF (row_count <> {capacity} OR distinct_slots <> {capacity} OR invalid_rows <> 0) THEN
      RAISE inventory_mismatch;
    END IF;"""


INVENTORY_DECLARATIONS = """  inventory_mismatch EXCEPTION (-20003, 'AUTOMAP_POOL_INVENTORY_MISMATCH');
  row_count NUMBER;
  distinct_slots NUMBER;
  invalid_rows NUMBER;
"""


def prepare_sql(path: Path, environment: str, stage: str = "create", *,
                initialize_empty_pool: bool = False,
                exclusive_deployment: bool = False,
                previous_capacity: int | None = None) -> str:
    if stage not in STAGES:
        raise ValueError("Unknown preparation stage")
    if initialize_empty_pool != (stage == "initialize-pool"):
        raise ValueError("initialize-pool requires --initialize-empty-pool, only for that stage")
    if stage in {"create", "initialize-pool", "expand-pool"} and not exclusive_deployment:
        raise ValueError("Creation/initialization/expansion requires --exclusive-deployment acknowledgement")
    scope, settings = load_profile(path, environment)
    spec = load_spec()
    agent = settings["AUTOMAP_PARALLEL_TEST_AGENT"]
    table = settings["AUTOMAP_PARALLEL_PERMIT_TABLE_FQN"]
    archive = settings["AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN"]
    capacity = int(settings["AUTOMAP_PARALLEL_POOL_CAPACITY"])
    if stage == "expand-pool":
        if type(previous_capacity) is not int or not 1 <= previous_capacity < capacity:
            raise ValueError("expand-pool requires --previous-capacity smaller than the new profile capacity")
    elif previous_capacity is not None:
        raise ValueError("--previous-capacity is only valid for expand-pool")
    header = f"""-- OFFLINE ONLY: not executed or Snowflake-compiled.
-- Environment: {environment}; stage: {stage}; profile connection label: {scope['connection']}.
-- Native session must already match {scope['account_namespace']} / {scope['role']}
-- database {scope['database']} / schema {scope['schema']}; no USE or grants are emitted.
-- Run create -> validate-agent -> [initialize-pool OR expand-pool] -> validate-pool.
-- Stop on every error; successful creation is NOT readiness or rollout approval.
-- Existing object definitions are never updated. Review existing table schemas separately.
-- External exclusive CI environment run REQUIRED for create/initialize, dispatchers stopped.
-- Standard-table uniqueness is NOT enforced; transaction/conditional INSERT is NOT a lock.
-- Keep the external gate until all stages pass. Postvalidation detects only observed races.
"""
    if stage == "create":
        specification = json.dumps(spec, ensure_ascii=True, separators=(",", ":"))
        statements = [f"CREATE AGENT IF NOT EXISTS {agent} FROM SPECIFICATION {literal(specification)}",
                      f"CREATE TABLE IF NOT EXISTS {table} (\n    {PERMIT_COLUMNS}\n)",
                      f"CREATE TABLE IF NOT EXISTS {archive} (\n    {ARCHIVE_COLUMNS}\n)"]
        return header + "\n".join(block(scope, "  EXECUTE IMMEDIATE " + literal(statement) +
                                      ";\n  RETURN 'AUTOMAP_CREATE_IF_ABSENT_OK';")
                                  for statement in statements)
    if stage == "validate-agent":
        # DESCRIBE's agent_spec is the deployed default, not necessarily LIVE.
        expected = literal(json.dumps(spec, ensure_ascii=True, separators=(",", ":")))
        body = f"""  EXECUTE IMMEDIATE {literal('DESCRIBE AGENT ' + agent)};
  describe_query_id := SQLID;
  SELECT COUNT(*), ANY_VALUE(TRY_PARSE_JSON("agent_spec"::VARCHAR))
    INTO :describe_rows, :deployed_spec
    FROM TABLE(RESULT_SCAN(:describe_query_id));
  IF (describe_rows <> 1 OR deployed_spec IS NULL
      OR COALESCE(IS_ARRAY(deployed_spec:tools), FALSE) = FALSE
      OR COALESCE(ARRAY_SIZE(deployed_spec:tools), -1) <> 0
      OR COALESCE(IS_OBJECT(deployed_spec:tool_resources), FALSE) = FALSE
      OR COALESCE(ARRAY_SIZE(OBJECT_KEYS(deployed_spec:tool_resources)), -1) <> 0
      OR NOT EQUAL_NULL(deployed_spec, PARSE_JSON({expected}))) THEN
    RAISE agent_mismatch;
  END IF;
  RETURN 'AUTOMAP_AGENT_SPEC_VERIFIED';"""
        return header + block(scope, body, declarations="""  agent_mismatch EXCEPTION (-20004, 'AUTOMAP_AGENT_SPEC_MISMATCH');
  describe_query_id VARCHAR;
  describe_rows NUMBER;
  deployed_spec VARIANT;
""")
    if stage == "validate-pool":
        return header + block(scope, "  " + inventory_assert(settings) +
                              "\n  RETURN 'AUTOMAP_POOL_INVENTORY_VERIFIED';",
                              declarations=INVENTORY_DECLARATIONS)
    namespace = literal(settings["AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE"])
    epoch = literal(settings["AUTOMAP_PARALLEL_POOL_EPOCH"])
    columns = ", ".join(line.strip().split()[0] for line in PERMIT_COLUMNS.splitlines())
    if stage == "expand-pool":
        # An external exclusive deployment gate is essential: Snowflake standard
        # table uniqueness is informational, and a transaction is not a lock.
        # Refuse an occupied or foreign inventory rather than resetting permits.
        body = f"""  BEGIN TRANSACTION;
  BEGIN
    SELECT COUNT(*) INTO :row_count FROM {table};
    IF (row_count = {capacity}) THEN
      {inventory_assert(settings)}
      COMMIT;
      RETURN 'AUTOMAP_POOL_ALREADY_EXPANDED_AND_VERIFIED';
    END IF;
    SELECT COUNT(*), COUNT(DISTINCT SLOT_ID),
           COALESCE(COUNT_IF(ACCOUNT_NAMESPACE IS NULL OR ACCOUNT_NAMESPACE <> {namespace}
             OR POOL_EPOCH IS NULL OR POOL_EPOCH <> {epoch}
             OR SLOT_ID IS NULL OR SLOT_ID NOT BETWEEN 1 AND {previous_capacity}
             OR SLOT_ID <> TRUNC(SLOT_ID) OR STATE IS NULL OR STATE <> 'FREE'
             OR OWNER_TOKEN IS NOT NULL OR FENCE IS NULL OR FENCE < 0
             OR FENCE <> TRUNC(FENCE)), 0)
      INTO :row_count, :distinct_slots, :invalid_rows FROM {table};
    IF (row_count <> {previous_capacity} OR distinct_slots <> {previous_capacity}
        OR invalid_rows <> 0) THEN
      RAISE inventory_mismatch;
    END IF;
    INSERT INTO {table} ({columns})
    SELECT {namespace}, {epoch}, {previous_capacity} + ROW_NUMBER() OVER (ORDER BY SEQ4()),
      'FREE', NULL, 0, NULL, NULL, NULL, NULL, NULL, CURRENT_TIMESTAMP(), NULL, NULL
    FROM TABLE(GENERATOR(ROWCOUNT => {capacity - previous_capacity}));
    {inventory_assert(settings)}
    COMMIT;
  EXCEPTION
    WHEN OTHER THEN
      ROLLBACK;
      RAISE;
  END;
  {inventory_assert(settings)}
  RETURN 'AUTOMAP_POOL_EXPANDED_AND_VERIFIED';"""
        return header + block(scope, body, declarations=INVENTORY_DECLARATIONS)
    body = f"""  BEGIN TRANSACTION;
  BEGIN
    SELECT COUNT(*) INTO :row_count FROM {table};
    IF (row_count = 0) THEN
      INSERT INTO {table} ({columns})
      SELECT {namespace}, {epoch}, ROW_NUMBER() OVER (ORDER BY SEQ4()),
        'FREE', NULL, 0, NULL, NULL, NULL, NULL, NULL, CURRENT_TIMESTAMP(), NULL, NULL
      FROM TABLE(GENERATOR(ROWCOUNT => {capacity}))
      WHERE NOT EXISTS (SELECT 1 FROM {table});
    END IF;
    {inventory_assert(settings)}
    COMMIT;
  EXCEPTION
    WHEN OTHER THEN
      ROLLBACK;
      RAISE;
  END;
  {inventory_assert(settings)}
  RETURN 'AUTOMAP_POOL_INITIALIZED_OR_EXISTING_INVENTORY_VERIFIED';"""
    return header + block(scope, body, declarations=INVENTORY_DECLARATIONS)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", type=Path, required=True, help="Existing non-secret parallel deployment JSON")
    parser.add_argument("--environment", choices=tuple(DEPLOYMENT_SCOPES), required=True)
    parser.add_argument("--stage", choices=STAGES, default="create", help="Print exactly one SQL stage; default: create (no seed)")
    parser.add_argument("--initialize-empty-pool", action="store_true", help="Only initialize-pool: seed empty table; valid existing inventory is a no-op; mismatch fails")
    parser.add_argument("--previous-capacity", type=int, help="Only expand-pool: exact existing pool size; all slots must be FREE")
    parser.add_argument("--exclusive-deployment", action="store_true", help="Acknowledge external exclusive CI environment run and stopped dispatchers; NOT a database lock")
    args = parser.parse_args(argv)
    try:
        sql = prepare_sql(args.profile, args.environment, args.stage,
                          initialize_empty_pool=args.initialize_empty_pool,
                          exclusive_deployment=args.exclusive_deployment,
                          previous_capacity=args.previous_capacity)
    except (ValueError, OSError, yaml.YAMLError) as error:
        parser.error(str(error))
    print(sql, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
