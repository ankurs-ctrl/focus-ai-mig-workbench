# Client Semantic + FIR Runbook

This runbook is for the Windows AVD / PowerShell setup.

## 1. What to load before users open the app

Load these in this order:

1. STTM metadata tables / agents / procedures
2. client notes and historical SQL
3. semantic table records for source and target tables
4. semantic bundle views for the most important source-to-target combinations
5. FIR model training / scoring
6. start the app

The goal is:

- semantic views are already warm
- Cortex Search already has client business knowledge
- FIR models already have baseline scores
- the UI only reuses, checks freshness, and updates incrementally

## 2. Historical business knowledge

For the first rollout, the most important assets are:

- historical final migration SQL
- business notes / mapping notes

That is enough to start.

Use extra documents only if they contain business meaning that is **not** already present in:

- notes
- SQL comments
- source / target naming

If a document is mostly a long export of the same SQL or notes, do not add it separately.

## 3. PowerShell commands

From the repo root:

```powershell
cd .\bbi-mig-ai-workbench
```

### 3.1 Load historical notes and SQL

Prepare:

- a folder with `.sql` migration files
- an optional `client_notes.json` file with objects like:

```json
[
  {
    "title": "Loan income target meaning",
    "note_text": "This target stores the downstream snowflake representation of verified income calculations and supporting audit context.",
    "entity_type": "sttm_migration",
    "entity_ids": ["LOAN_INCOME_AMOUNT_CALCULATION"],
    "tags": ["loan_income", "business_definition"]
  }
]
```

Then run:

```powershell
.\services\sttm-builder\.venv\Scripts\python.exe .\scripts\load_client_fir_knowledge.py `
  --project-id CLIENT_MIGRATION_001 `
  --notes-json .\client_notes.json `
  --sql-dir .\historical-sql `
  --entity-type sttm_migration `
  --rebuild-search
```

What this does:

- loads notes into `TBL_WORKBENCH_CLIENT_NOTES`
- loads SQL into `TBL_WORKBENCH_CLIENT_SQL_ASSETS`
- rebuilds the workbench RAG projection
- refreshes the Cortex Search service

### 3.2 Warm semantic table records and bundle views

Copy and edit:

- [client_semantic_bootstrap.example.yaml](/Users/ankurshome/Desktop/storage/Mr-Bucky/bbi-mig-ai-workbench/infra/snowflake/bootstrap/client_semantic_bootstrap.example.yaml)

Then run:

```powershell
.\services\sttm-builder\.venv\Scripts\python.exe .\scripts\bootstrap_client_semantic_views.py `
  --config-file .\infra\snowflake\bootstrap\client_semantic_bootstrap.example.yaml
```

What this does:

- creates / refreshes semantic table records for all configured source and target tables
- creates / refreshes semantic bundle views for the important source-to-target combinations
- uses cached semantics for bundle creation unless you explicitly enable bundle agent refresh

### 3.3 Train and score FIR models

```powershell
.\venv\Scripts\python.exe .\scripts\train_and_score_fir_v2.py --env-file .\services\sttm-builder\.env.local
```

What this does:

- bootstraps FIR feature rows from current history if needed
- trains baseline Snowflake ML models
- writes live scores into `TBL_WORKBENCH_FIR_MODEL_SCORES`

### 3.4 Start the full app

```powershell
powershell -ExecutionPolicy Bypass -File .\start-ai-workbench-dev.ps1
```

## 4. What Cortex Search should index

The workbench search corpus should index:

- semantic views / semantic table records
- relationship facts
- semantic learnings
- approved recommendations
- approved or corrective feedback
- client notes
- historical migration SQL
- derived-source drafts only if they were approved or are still active

Do **not** treat raw transient UI signals as long-term knowledge.

The best retrieval folders are:

- `semantic`
- `relationships`
- `inferences`
- `recommendations`
- `feedback`
- `knowledge_notes`
- `historical_sql`
- `conversations` only as a last-memory layer

## 5. What ML should decide

ML should decide:

- whether to show feedback
- whether to show a recommendation
- what recommendation class to use
- how helpful a recommendation is likely to be
- priority / ranking

ML should **not** be the system of record for business meaning.

## 6. What the agent should do

The UI-facing agent should:

- answer quickly from warm FIR context when possible
- use search only for low confidence, new context, or explicit “why/explain”
- explain recommendations in business language
- use mapping intent and prior SQL examples
- ask focused business questions when meaning is unclear

## 7. Live vs deep semantic generation

Use two modes mentally:

### Live mode

- `claude-sonnet-4-6`
- selective profiling only
- cached semantic reuse first
- only a few targeted profile calls

### Deep mode

- scheduled or explicit refresh
- richer regeneration when tables changed materially
- can afford slower runtimes

The live app should mostly use **live mode**.

## 8. Recommended rollout order for your client case

For the loan income flow:

1. load the real source and target tables
2. load historical SQL and client notes
3. warm semantic table records for:
   - `LOAN_INCOME_AMOUNT_CALCULATION`
   - `NOTE`
   - all target tables in the DW / target schema used by this migration
4. warm bundle views for:
   - `LOAN_INCOME_AMOUNT_CALCULATION + NOTE -> target`
5. train FIR baseline
6. open the app and validate:
   - source selection recommendations
   - automap
   - SQL preview explanation
   - data preview

## 9. Best practice for business knowledge

Best first approach:

- put stable business explanations into `CLIENT_NOTES`
- put real historical migration SQL into `CLIENT_SQL_ASSETS`

That is better than uploading lots of general documents at first.

Only add external documents when they contain:

- business definitions
- target field meaning
- mapping policy
- exception-handling rules

that are not already represented in notes or SQL.
