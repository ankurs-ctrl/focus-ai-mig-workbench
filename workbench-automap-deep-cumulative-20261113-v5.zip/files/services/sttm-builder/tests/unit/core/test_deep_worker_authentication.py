from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from app.core.config import Settings
from app.core.exceptions import DelegatedSessionRequired
from app.agent_runs.models import AgentActor, RunCreateRequest, RunStatus, RunAnswerRequest
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.agent_runs.service import AgentRunService, RunAuthorizationError
from app.agent_runs.worker import AgentWorker


def test_operational_factory_uses_only_service_token_in_custom_oauth(monkeypatch):
    from app.core import snowflake as sf
    session=Mock();builder=Mock();builder.configs.return_value.create.return_value=session
    monkeypatch.setattr(sf,'Session',SimpleNamespace(builder=builder))
    monkeypatch.setattr(sf,'get_service_token',lambda:'mounted-service-token')
    monkeypatch.setattr(sf,'_caller_oauth_attempts',Mock(side_effect=AssertionError('caller authentication used for housekeeping')))
    settings=Settings(_env_file=None,AUTH_MODE='custom_oauth',LOCAL_DEV_AUTH_ENABLED=False,
        SNOWFLAKE_ACCOUNT='test',SNOWFLAKE_DATABASE='DB',SNOWFLAKE_SCHEMA='META')
    client=sf.SnowflakeClient.for_service(settings)
    args=builder.configs.call_args.args[0]
    assert args['authenticator']=='oauth' and args['token']=='mounted-service-token'
    assert 'role' not in args and 'password' not in args
    assert client.session is session


def test_service_token_failure_cannot_fall_back_to_user_or_pat(monkeypatch):
    from app.core import snowflake as sf
    monkeypatch.setattr(sf,'get_service_token',Mock(side_effect=sf.SnowflakeConnectionError('No service token')))
    monkeypatch.setattr(sf,'_direct_connection_kwargs',Mock(side_effect=AssertionError('unexpected PAT fallback')))
    with pytest.raises(sf.SnowflakeConnectionError):
        sf.SnowflakeClient.for_service(Settings(_env_file=None,AUTH_MODE='custom_oauth',LOCAL_DEV_AUTH_ENABLED=False))


def actor(session='old'):
    return AgentActor(app_user_id='1',snowflake_username='ALICE',effective_role='ROLE',delegation_ref=session)


def paused():
    repo=InMemoryAgentRunRepository();service=AgentRunService(repo)
    run=service.create_run(RunCreateRequest(prompt='Inspect metadata'),actor())
    factory=Mock(side_effect=DelegatedSessionRequired('Expired user login'))
    worker=AgentWorker(repo,None,worker_id='worker',runtime_factory=factory)
    assert worker.run_once()
    stored=repo.get_run(run.run_id)
    assert stored.status is RunStatus.AWAITING_INPUT
    assert stored.error_code=='authentication_required'
    assert stored.model_calls_used==0
    assert repo.acquire_lease('second',30) is None
    item=repo.list_review_items(run.run_id)[0]
    assert item.category=='authentication_required'
    return repo,service,stored,item


def test_expiry_pauses_and_authenticated_same_user_can_rebind_without_new_run():
    repo,service,run,item=paused()
    resumed=service.answer(run.run_id,RunAnswerRequest(review_item_id=item.review_item_id,
        choice_id='resume_after_sign_in',idempotency_key='new-login'),actor('fresh-session'))
    assert resumed.status is RunStatus.QUEUED
    assert resumed.run_id==run.run_id and resumed.actor.delegation_ref=='fresh-session'
    assert resumed.error_code is None and resumed.safe_error is None
    assert resumed.checkpoint_thread_id==run.checkpoint_thread_id


def test_reauthentication_cannot_switch_owner_or_reuse_missing_session():
    repo,service,run,item=paused()
    for current in [actor(None),actor('fresh').model_copy(update={'app_user_id':'other'}),
                    actor('fresh').model_copy(update={'effective_role':'OTHER'}),
                    actor('fresh').model_copy(update={'snowflake_username':'BOB'})]:
        with pytest.raises(RunAuthorizationError):
            service.answer(run.run_id,RunAnswerRequest(review_item_id=item.review_item_id,
                choice_id='resume_after_sign_in',idempotency_key='attack'),current)
    assert repo.get_run(run.run_id).status is RunStatus.AWAITING_INPUT
    assert repo.get_run(run.run_id).actor.delegation_ref=='old'


def test_boundary_checks_pause_on_revocation_and_do_not_refresh_or_fall_back(monkeypatch):
    from datetime import datetime,timedelta,UTC
    from app.auth import custom_oauth as oauth
    state={'active':True,'token':'original'}
    record=SimpleNamespace(is_active=True,snowflake_user='ALICE',snowflake_role='ROLE',
        access_token_expires_at=datetime.now(UTC)+timedelta(hours=1))
    lookup=Mock(side_effect=lambda *a:record if state['active'] else None)
    monkeypatch.setattr(oauth,'_session_select_row',lookup)
    monkeypatch.setattr(oauth,'decrypt_access_token',lambda *a:state['token'])
    refresh=Mock();monkeypatch.setattr(oauth,'_refresh_tokens',refresh)
    guard=oauth.delegated_session_guard('session','ALICE','ROLE','original',None,interval_seconds=0)
    guard();state['active']=False
    with pytest.raises(DelegatedSessionRequired):guard()
    refresh.assert_not_called()
    state['active']=True;state['token']='rotated'
    with pytest.raises(DelegatedSessionRequired):guard()
    refresh.assert_not_called()


def test_mid_run_authentication_checkpoint_is_not_sent_as_business_resume_input():
    from datetime import datetime,UTC
    from app.agent_runtime.interface import RuntimeResult
    repo=InMemoryAgentRunRepository();service=AgentRunService(repo)
    run=service.create_run(RunCreateRequest(prompt='Explain the selected metadata'),actor())
    run.started_at=datetime.now(UTC);run.checkpoint_thread_id='retained-checkpoint'
    repo.save_run(run)
    worker=AgentWorker(repo,None,worker_id='worker',runtime_factory=Mock(side_effect=DelegatedSessionRequired('expired')))
    assert worker.run_once()
    paused_run=repo.get_run(run.run_id);item=repo.list_review_items(run.run_id)[0]
    service.answer(run.run_id,RunAnswerRequest(review_item_id=item.review_item_id,choice_id='resume_after_sign_in'),actor('fresh'))
    seen=[]
    class Runtime:
        def invoke(self,invocation):
            seen.append(invocation)
            return RuntimeResult(status='COMPLETED',safe_summary='Done',assistant_message='Done',workflow_state={'status':'COMPLETED'})
    next_worker=AgentWorker(repo,None,worker_id='worker-two',runtime_factory=lambda current:(Runtime(),lambda:None))
    assert next_worker.run_once()
    assert len(seen)==1 and seen[0].is_resume
    assert seen[0].resume_value is None and seen[0].thread_id=='retained-checkpoint'
    assert 'resume_after_sign_in' not in str(seen[0].workflow_input)
