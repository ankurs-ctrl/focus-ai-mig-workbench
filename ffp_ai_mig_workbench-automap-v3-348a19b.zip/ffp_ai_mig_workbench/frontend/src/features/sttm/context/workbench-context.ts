import { sqlTableReference } from '@/features/sttm/shared/sql-identifiers';
import type {
  MappingIntent,
  SemanticContextItem,
  RelationGraphContext,
  RelationshipContextItem,
  TableRef,
  WorkbenchContextSnapshotV2,
} from "@/types/api-contract";
import type {
  ChatMessage,
  ColumnGroup,
  DerivedSource,
  JoinConfig,
  MappingState,
  RuleGroup,
  TableNode,
} from "@/features/sttm/types/sttm.types";
import { relationAliasFor } from "@/features/sttm/mapping/relation-alias";
import { MAPPING_SQL_VALIDATION_KIND } from "@/features/sttm/shared/mapping-validation";
import { selectedDerivedClosure } from "@/features/sttm/shared/derived-source-closure";
import { joinConnectorPayload } from "@/features/sttm/source-target/join-predicate";

export type WorkbenchCheckpoint =
  | "project.created"
  | "mapping.created"
  | "target.selected"
  | "source_set.completed"
  | "join.completed"
  | "derived_source.saved"
  | "auto_map.requested"
  | "transformation.requested"
  | "assistant.requested"
  | "validation.completed"
  | "sttm.published"
  | string;

export type WorkbenchSnapshotInput = {
  action: WorkbenchCheckpoint;
  milestone?: string | null;
  page: string;
  surface: string;
  sessionId?: string | null;
  threadId?: string | null;
  projectId?: string | null;
  projectName?: string | null;
  projectDescription?: string | null;
  projectDomain?: string | null;
  projectOutcome?: string | null;
  sttmId?: string | null;
  sttmName?: string | null;
  sttmDescription?: string | null;
  mappingLifecycle?: string | null;
  businessGoal?: string | null;
  sourceTables: TableNode[];
  targetTable?: TableNode | null;
  drivingTableId?: string | null;
  sourceAttributeGroups?: ColumnGroup[];
  derivedSources?: DerivedSource[];
  relationships?: JoinConfig[];
  sourceFilterSql?: string;
  sourceQuerySql?: string;
  sourceGroupBySql?: string;
  sourceOrderBySql?: string;
  sourceQueryModifiers?: Record<string, string>;
  sourceFilterGroups?: RuleGroup[];
  mappings?: MappingState[];
  selectedMappingIds?: string[];
  activeMappingId?: string | null;
  mappingSql?: string | null;
  authoredSqlSemanticKey?: string | null;
  unresolvedSourceTables?: string[];
  mappingPreviewSql?: string | null;
  mappingSqlVariant?: "original" | "optimized" | null;
  compiledMappingSql?: string | null;
  compiledMappingScriptSql?: string | null;
  compiledMappingReady?: boolean;
  compiledMappingPreviewSql?: string | null;
  compiledMappingContextHash?: string | null;
  semanticContextItems?: SemanticContextItem[] | null;
  sqlValidatedSignature?: string | null;
  mappingIntent?: MappingIntent | null;
  semanticBundleId?: string | null;
  semanticBundleHash?: string | null;
  semanticBundleLabel?: string | null;
  semanticLevel?: string | null;
  semanticStatus?: string | null;
  semanticViewName?: string | null;
  semanticLineage?: Array<Record<string, unknown>>;
  mappingArtifacts?: Array<Record<string, unknown>>;
  validationHistory?: Array<Record<string, unknown>>;
  conversationHistory?: ChatMessage[];
  autoMapOutcome?: Record<string, unknown> | null;
  assistantMemory?: Record<string, unknown> | null;
  scopeType?: WorkbenchContextSnapshotV2["scope_type"];
  candidateAction?: string | null;
  browsingContext?: WorkbenchContextSnapshotV2["browsing_context"];
};

export function tableRefFromQualifiedName(qualifiedName?: string | null): TableRef | null {
  return qualifiedName ? sqlTableReference(qualifiedName) : null;
}

function candidateTableFqn(value: unknown): string | null {
  if (typeof value === "string") {
    const normalized = value.trim();
    return normalized || null;
  }
  if (!value || typeof value !== "object") return null;

  const record = value as Record<string, unknown>;
  const qualifiedName = record.qualifiedName ?? record.qualified_name ?? record.fqn;
  if (typeof qualifiedName === "string" && qualifiedName.trim()) {
    return qualifiedName.trim();
  }

  const database = record.database ?? record.database_name;
  const schema = record.schema ?? record.schema_name;
  const table = record.table ?? record.table_name ?? record.name;
  if (
    typeof database === "string"
    && typeof schema === "string"
    && typeof table === "string"
  ) {
    return `${database}.${schema}.${table}`;
  }
  return null;
}

function normalizeBrowsingContext(
  browsingContext: WorkbenchContextSnapshotV2["browsing_context"],
): WorkbenchContextSnapshotV2["browsing_context"] {
  if (!browsingContext) return null;
  const candidates = (
    browsingContext.visible_candidate_tables ?? []
  ) as unknown[];
  return {
    ...browsingContext,
    visible_candidate_tables: Array.from(
      new Set(candidates.map(candidateTableFqn).filter((value): value is string => Boolean(value))),
    ).sort(),
  };
}

function selectedColumns(groups: ColumnGroup[] = []): Record<string, string[]> {
  return Object.fromEntries(
    groups
      .map((group) => [
        group.qualifiedName,
        group.columns
          .filter((column) => column.selected)
          .map((column) => String(column.name || ""))
          .filter(Boolean)
          .sort(),
      ] as const)
      .filter(([, columns]) => columns.length > 0)
      .sort(([left], [right]) => left.localeCompare(right)),
  );
}

function relationshipItems(relationships: JoinConfig[] = []): RelationshipContextItem[] {
  return relationships.flatMap((relationship) => {
    const leftTable = tableRefFromQualifiedName(relationship.leftTableId);
    const rightTable = tableRefFromQualifiedName(relationship.rightTableId);
    if (!leftTable || !rightTable) return [];
    return [{
      left_table: leftTable,
      right_table: rightTable,
      join_type: relationship.joinType,
      sql_predicate: relationship.sqlPredicate ?? null,
      constraint_name: relationship.constraintName,
      source: relationship.source,
      locked: relationship.locked,
      conditions: (relationship.conditions ?? []).map((condition) => ({
        left_column: condition.leftColumn ?? "",
        operator: condition.operator,
        right_column: condition.rightColumn ?? "",
        ...joinConnectorPayload(condition.connector),
      })),
    }];
  });
}

function relationGraph(
  sourceTables: TableNode[],
  derivedSources: DerivedSource[],
  relationships: JoinConfig[],
  mappings: MappingState[],
): RelationGraphContext {
  const derivedIdByUiId = new Map<string, string>();
  for (const source of derivedSources) {
    derivedIdByUiId.set(source.id, source.id);
    derivedIdByUiId.set(`DERIVED.${source.sourceName}`, source.id);
  }
  const normalizeRelationId = (value?: string | null) =>
    (value && derivedIdByUiId.get(value)) || value || "";
  const nodes: RelationGraphContext["nodes"] = [
    ...sourceTables.map((table) => ({
      relation_id: table.tableId.startsWith("sql-instance:") ? table.tableId : table.qualifiedName,
      kind: "PHYSICAL_TABLE" as const,
      alias: relationAliasFor(table.tableId.startsWith("sql-instance:") ? table.tableId : table.qualifiedName),
      table: tableRefFromQualifiedName(table.qualifiedName),
      output_columns: table.columnItems?.map((column) => ({
        name: column.name,
        data_type: column.type,
        is_primary_key: column.isPrimaryKey,
      })) ?? [],
    })),
    ...derivedSources.map((source) => ({
      relation_id: source.id,
      kind: "DERIVED_SOURCE" as const,
      alias: relationAliasFor(source.id, source.sourceName),
      derived_source_id: source.id,
      physical_view_name: source.physicalViewName ?? null,
      sql_text: source.sqlText ?? null,
      original_cte_name: source.id.startsWith('sql-cte:') ? String(source.queryScope?.name_sql ?? source.queryScope?.name ?? source.sourceName) : null,
      output_columns: source.outputColumns ?? [],
      column_semantics: source.columnSemantics ?? [],
      grain: source.grain ?? null,
      keys: source.keys ?? [],
      dependency_hash: source.sourceDependencyHash ?? source.upstreamHash ?? null,
      parent_relation_ids: source.parentDerivedSourceIds ?? source.derivedSourceIds ?? [],
      base_relation_ids: (source.baseSourceTables ?? []).map((table) =>
        `${table.database}.${table.schema}.${table.table}`.replace(/\.+/g, "."),
      ),
    })),
  ];
  const nodeIds = new Set(nodes.map((node) => node.relation_id));
  return {
    nodes,
    edges: relationships.flatMap((relationship, index) => {
      const leftId = normalizeRelationId(relationship.leftTableId);
      const rightId = normalizeRelationId(relationship.rightTableId);
      if (!nodeIds.has(leftId) || !nodeIds.has(rightId) || (!relationship.conditions?.length && !relationship.sqlPredicate)) return [];
      return [{
        edge_id: relationship.id ?? `relation-edge-${index + 1}`,
        left_relation_id: leftId,
        right_relation_id: rightId,
        join_type: relationship.joinType ?? "INNER",
        provenance: relationship.source ?? "USER_DEFINED",
        validation_status: relationship.locked ? "validated" : "selected",
        additional_predicate: relationship.sqlPredicate ?? null,
        conditions: (relationship.sqlPredicate ? [] : relationship.conditions ?? []).map((condition) => ({
          left_column: condition.leftColumn ?? "",
          operator: condition.operator ?? "=",
          right_column: condition.rightColumn ?? "",
          ...joinConnectorPayload(condition.connector),
        })),
      }];
    }),
    value_bindings: mappings.flatMap((mapping) => {
      if (
        (mapping.mappingMode !== "constant" && mapping.mappingMode !== "attribute")
        || !mapping.constantValue
      ) {
        return [];
      }
      return [{
        binding_id: `value:${mapping.id}`,
        value: mapping.constantValue,
        data_type: mapping.targetType ?? null,
        is_placeholder: mapping.constantValue.startsWith("$"),
        allow_project_specific_value: mapping.mappingMode === "attribute",
        resolution_status: mapping.constantValue.startsWith("$") ? "unresolved" : "resolved",
        attribute_name: mapping.mappingMode === "attribute" ? mapping.attributeName ?? null : null,
      }];
    }),
  };
}

export function buildWorkbenchContextSnapshot(
  input: WorkbenchSnapshotInput,
): WorkbenchContextSnapshotV2 {
  const sourceTables = input.sourceTables
    .map((table) => tableRefFromQualifiedName(table.qualifiedName))
    .filter((table): table is TableRef => Boolean(table))
    .sort((left, right) =>
      `${left.database}.${left.schema}.${left.table}`.localeCompare(
        `${right.database}.${right.schema}.${right.table}`,
      ),
    );
  const selectedDerived = (input.derivedSources ?? []).filter((source) => source.isSelected);
  const persistedDerived = selectedDerivedClosure(input.derivedSources ?? []);
  const relationships = relationshipItems(input.relationships);
  const unifiedRelationGraph = relationGraph(
    input.sourceTables,
    selectedDerived,
    input.relationships ?? [],
    input.mappings ?? [],
  );
  unifiedRelationGraph.query_modifiers = input.sourceQueryModifiers ?? {};

  return {
    context_version: "2.0",
    context_hash: "",
    context_key: "",
    captured_at: new Date().toISOString(),
    page: input.page,
    surface: input.surface,
    action: input.action,
    milestone: input.milestone ?? input.action,
    checkpoint: input.milestone ?? input.action,
    scope_type: input.scopeType ?? (input.browsingContext ? "schema" : "table_set"),
    scope_key: "",
    candidate_action: input.candidateAction ?? null,
    browsing_context: normalizeBrowsingContext(input.browsingContext),
    session_id: input.sessionId ?? null,
    thread_id: input.threadId ?? null,
    project_id: input.projectId ?? null,
    project_name: input.projectName ?? null,
    project_description: input.projectDescription ?? null,
    project_domain: input.projectDomain ?? null,
    project_outcome: input.projectOutcome ?? null,
    sttm_id: input.sttmId ?? null,
    sttm_name: input.sttmName ?? null,
    sttm_description: input.sttmDescription ?? null,
    mapping_lifecycle: input.mappingLifecycle ?? null,
    business_goal: input.businessGoal ?? null,
    source_tables: sourceTables,
    unresolved_source_tables: Array.from(new Set(input.unresolvedSourceTables ?? [])).sort(),
    target_table: input.targetTable
      ? tableRefFromQualifiedName(input.targetTable.qualifiedName)
      : null,
    driving_table: tableRefFromQualifiedName(input.drivingTableId),
    driving_relation_id: input.drivingTableId ?? null,
    selected_columns_by_table: selectedColumns(input.sourceAttributeGroups),
    derived_sources: persistedDerived.map((source) => ({
      id: source.id,
      name: source.sourceName,
      is_selected: Boolean(source.isSelected),
      driving_table_id: source.drivingTableId ?? null,
      sql_text: source.sqlText ?? null,
      definition_sql: source.definitionSql ?? null,
      query_scope: source.queryScope ?? null,
      parent_derived_source_ids: source.parentDerivedSourceIds ?? source.derivedSourceIds ?? [],
      physical_view_name: source.physicalViewName ?? null,
      generated_by_request_id: source.generatedByRequestId ?? null,
      semantic_bundle_id: source.semanticBundleId ?? null,
      semantic_bundle_label: source.semanticBundleLabel ?? null,
      semantic_view_name: source.semanticViewName ?? null,
      semantic_level: source.semanticLevel ?? null,
      upstream_hash: source.upstreamHash ?? null,
      source_dependency_hash: source.sourceDependencyHash ?? null,
      purpose: source.purpose ?? null,
      business_description: source.businessDescription ?? null,
      grain: source.grain ?? null,
      keys: source.keys ?? [],
      output_columns: source.outputColumns ?? [],
      column_semantics: source.columnSemantics ?? [],
      semantic_projection: source.semanticProjection ?? {},
      semantic_quality: source.semanticQuality ?? null,
      lineage_depth: source.lineageDepth ?? 0,
      base_source_tables: source.baseSourceTables ?? [],
      table_ids: source.tableIds ?? [],
      alias: source.alias ?? null,
      columns: source.columns ?? [],
      joins: source.joins ?? [],
      filters: source.filters ?? [],
      selected_columns_by_table: source.selectedColumnsByTable ?? {},
      lineage: (input.semanticLineage ?? []).filter(
        (item) => item.derived_source_id === source.id || item.id === source.id,
      ),
    })),
    relation_graph: unifiedRelationGraph,
    relationships,
    filters: {
      filter_sql: input.sourceFilterSql ?? null,
      base_query_sql: input.sourceQuerySql ?? null,
      group_by_sql: input.sourceGroupBySql ?? null,
      order_by_sql: input.sourceOrderBySql ?? null,
      query_modifiers: input.sourceQueryModifiers ?? {},
      groups: (input.sourceFilterGroups ?? []) as unknown as Array<Record<string, unknown>>,
    },
    mapping_intent: input.mappingIntent ?? null,
    mapping_rows: (input.mappings ?? []).map((mapping, targetOrdinal) => ({
      id: mapping.id,
      target_column: mapping.targetColumn,
      target_sql_name: mapping.targetSqlName,
      target_type: mapping.targetType,
      source_columns: mapping.sourceColumns ?? (mapping.sourceColumn ? [mapping.sourceColumn] : []),
      source_dependencies: mapping.sourceDependencies ?? [],
      source_type: mapping.sourceType,
      mapping_mode: mapping.mappingMode ?? "source",
      constant_value: mapping.constantValue ?? null,
      attribute_name: mapping.attributeName ?? null,
      rule: mapping.rule,
      expression: mapping.expression,
      natural_language_rule: mapping.nlRule,
      description: mapping.description,
      load_order: mapping.loadOrder,
      confidence: mapping.confidenceScore,
      confidence_reason: mapping.confidenceReason,
      unmatched_reason: mapping.unmatchedReason ?? null,
      candidate_source_attributes: mapping.candidateSourceColumns ?? [],
      target_ordinal: mapping.targetOrdinal ?? targetOrdinal,
      manually_saved: mapping.manuallySaved ?? false,
      learning_origin: mapping.learningOrigin ?? null,
      manually_edited_after_auto_map: mapping.manuallyEditedAfterAutoMap ?? false,
      value_binding_ids: mapping.valueBindingIds ?? [],
      transformation_classification: mapping.transformationClassification ?? null,
      precedent_decision: mapping.precedentDecision ?? null,
      precedent_mapping_id: mapping.precedentMappingId ?? null,
      override_evidence: mapping.overrideEvidence ?? [],
      used_inference_ids: mapping.usedInferenceIds ?? [],
      used_recommendation_ids: mapping.usedRecommendationIds ?? [],
      used_learning_ids: mapping.usedLearningIds ?? [],
      status: mapping.status === "PROCESSING" ? "UNMAPPED" : mapping.status,
    })),
    checked_mapping_row_ids: input.selectedMappingIds ?? [],
    active_mapping_row_id: input.activeMappingId ?? null,
    mapping_sql: input.mappingSql ?? null,
    authored_sql_semantic_key: input.mappingSql?.trim()
      ? input.authoredSqlSemanticKey ?? null
      : null,
    mapping_preview_sql: input.mappingPreviewSql ?? null,
    mapping_sql_variant: input.mappingSqlVariant ?? null,
    compiled_mapping_sql: input.compiledMappingSql ?? null,
    compiled_mapping_script_sql: input.compiledMappingScriptSql ?? null,
    compiled_mapping_ready: input.compiledMappingReady ?? false,
    compiled_mapping_preview_sql: input.compiledMappingPreviewSql ?? null,
    compiled_mapping_context_hash: input.compiledMappingContextHash ?? null,
    compiled_mapping_semantic_context: input.compiledMappingContextHash ? input.semanticContextItems ?? null : null,
    semantic: {
      bundle_id: input.semanticBundleId ?? null,
      bundle_hash: input.semanticBundleHash ?? null,
      bundle_label: input.semanticBundleLabel ?? null,
      level: input.semanticLevel ?? null,
      status: input.semanticStatus ?? null,
      view_name: input.semanticViewName ?? null,
    },
    semantic_bundle: {
      bundle_id: input.semanticBundleId ?? null,
      bundle_hash: input.semanticBundleHash ?? null,
      bundle_label: input.semanticBundleLabel ?? null,
      level: input.semanticLevel ?? null,
      status: input.semanticStatus ?? null,
      semantic_view_name: input.semanticViewName ?? null,
      source_tables: sourceTables,
      target_table: input.targetTable
        ? tableRefFromQualifiedName(input.targetTable.qualifiedName)
        : null,
      driving_table: tableRefFromQualifiedName(input.drivingTableId),
      derived_source_ids: selectedDerived.map((source) => source.id).sort(),
    },
    mapping_artifacts: input.mappingArtifacts ?? [],
    auto_map_outcome: input.autoMapOutcome ?? null,
    assistant_memory: input.assistantMemory ?? null,
    validation_history:
      input.validationHistory
      ?? (input.sqlValidatedSignature
        // valid: true marks a passed Compile & Validate (not a failure event).
        ? [{ kind: MAPPING_SQL_VALIDATION_KIND, signature: input.sqlValidatedSignature, valid: true }]
        : []),
    conversation_history: (input.conversationHistory ?? [])
      .filter((message) => !message.isStreaming && message.status !== "failed" && message.content.trim())
      .slice(-30)
      .map((message) => ({ role: message.role, content: message.content.trim() })),
  };
}
