import api from '../api/axiosInstance';
import {
  type MappingIntent,
  type RelationshipContextItem,
  type SemanticLevel,
  type SemanticContextItem,
  type SemanticSurface,
  type STTMBuilderEnvelopeRequest,
  type STTMBuilderEnvelopeResponse,
  type STTMIntent,
  type STTMOperation,
  type TableRef,
  type TargetAttributeItem,
} from '@/types/api-contract';
import { buildApiEnvelope, getApiData, resolveApiBaseUrl } from '@/api/axiosInstance';
import { API_ROUTES } from '@/api/routes';
import { handleApiClientError } from '@/api/errors/error-bus';
import {
  buildMockWorkbenchInvokeResponse,
  mockInvokeStream,
  mockWorkbenchInfo,
} from '@/data/mock/workbench';
import { mockDelay, throwMockError, useMockDb } from './mock/mockConfig';
import { extractSseChunk } from './streaming/sse';

/**
 * Request payload for direct AGT_SOURCE_MAPPING invocation.
 * This bypasses the orchestrator for faster auto-mapping.
 */
export type DirectAutoMapRequest = {
  request_id?: string | null;
  attributes: TargetAttributeItem[];
  source_tables: TableRef[];
  target_table?: TableRef | null;
  driving_table?: TableRef | null;
  relationships?: RelationshipContextItem[] | null;
  semantic_context?: SemanticContextItem[] | null;
  selected_columns_by_table?: Record<string, string[]> | null;
  selected_derived_sources?: string[] | null;
  semantic_bundle_id?: string | null;
  semantic_bundle_label?: string | null;
  semantic_view_name?: string | null;
  derived_source_lineage?: Array<Record<string, unknown>> | null;
  datahub_context?: Record<string, unknown> | null;
  mapping_intent?: MappingIntent | null;
  message?: string | null;
  project_id?: string | null;
  workspace_context?: Record<string, unknown> | null;
};

/**
 * Response from direct AGT_SOURCE_MAPPING invocation.
 */
export type DirectAutoMapResponse = {
  request_id: string;
  status: 'completed' | 'needs_input' | 'failed';
  mappings: Record<string, {
    source_attributes: string[];
    confidence_score: number;
    confidence_reason?: string | null;
    candidate_source_attributes?: string[];
    unmatched_reason?: string | null;
    preprocessing_rule?: string | null;
    preprocessing_rule_type?: string | null;
    preprocessing_nl_rule?: string | null;
    processing_order?: number | null;
    description?: string | null;
  }>;
  message?: string | null;
  warnings?: Array<{ code: string; message: string }>;
  error?: { title: string; detail: string; code: string } | null;
  meta?: Record<string, unknown>;
  semantic_refresh_status?: {
    bundle_id?: string | null;
    bundle_label?: string | null;
    semantic_view_name?: string | null;
  } | null;
};

export type { RelationshipContextItem, TableRef, TargetAttributeItem };

export type WorkbenchRequest = {
  interface: STTMIntent;
  thread_id?: string | null;
  parent_message_id?: number | null;
  session_id?: string | null;
  attributes?: TargetAttributeItem[] | null;
  source_tables?: TableRef[] | null;
  message?: string | null;
  driving_table?: TableRef | null;
  relationships?: RelationshipContextItem[] | null;
  semantic_context?: SemanticContextItem[] | null;
  selected_columns_by_table?: Record<string, string[]> | null;
  surface?: SemanticSurface | null;
  semantic_level_requested?: SemanticLevel | null;
  target_table?: TableRef | null;
  selected_derived_sources?: string[] | null;
  semantic_bundle_id?: string | null;
  semantic_view_name?: string | null;
  derived_source_lineage?: Array<Record<string, unknown>> | null;
  datahub_context?: Record<string, unknown> | null;
  mapping_intent?: MappingIntent | null;
  project_id?: string | null;
  sttm_id?: string | null;
  workspace_context?: Record<string, unknown> | null;
};

const operationByIntent: Record<STTMIntent, STTMOperation> = {
  AUTO_MAP: "sttm.auto_map",
  CHAT: "sttm.chat",
  TRANSFORM: "sttm.transform",
};

function nullableNonEmptyArray<T>(items?: T[] | null): T[] | null {
  return items && items.length > 0 ? items : null;
}

function toEnvelope(payload: WorkbenchRequest): STTMBuilderEnvelopeRequest {
  return buildApiEnvelope(
    operationByIntent[payload.interface],
    {
      intent: payload.interface,
      attributes: nullableNonEmptyArray(payload.attributes),
      message: payload.message ?? null,
    },
    {
      thread_id: payload.thread_id ?? null,
      parent_message_id: payload.parent_message_id ?? null,
      session_id: payload.session_id ?? null,
      source_tables: nullableNonEmptyArray(payload.source_tables),
      driving_table: payload.driving_table ?? null,
      relationships: payload.relationships ?? null,
      semantic_context: payload.semantic_context ?? null,
      selected_columns_by_table: payload.selected_columns_by_table ?? null,
      surface: payload.surface ?? "SOURCE_SELECTION",
      semantic_level_requested: payload.semantic_level_requested ?? "FULL_REGISTRY",
      target_table: payload.target_table ?? null,
      selected_derived_sources: nullableNonEmptyArray(payload.selected_derived_sources),
      semantic_bundle_id: payload.semantic_bundle_id ?? null,
      semantic_view_name: payload.semantic_view_name ?? null,
      derived_source_lineage: payload.derived_source_lineage ?? null,
      datahub_context: payload.datahub_context ?? null,
      mapping_intent: payload.mapping_intent ?? null,
      project_id: payload.project_id ?? null,
      sttm_id: payload.sttm_id ?? null,
      workspace_context: payload.workspace_context ?? null,
    },
  ) as STTMBuilderEnvelopeRequest;
}

export const workbenchService = {
  invoke: async (payload: WorkbenchRequest) => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(buildMockWorkbenchInvokeResponse(payload));
    }

    const response = await api.post<STTMBuilderEnvelopeResponse>(API_ROUTES.workbench.invoke, toEnvelope(payload), {
      timeout: 300000,
    });
    return response.data;
  },

  getInfo: async () => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(mockWorkbenchInfo);
    }
    return getApiData(API_ROUTES.workbench.info);
  },

  invokeStream: async function* (payload: WorkbenchRequest): AsyncGenerator<
    | { event: "status"; data: Record<string, unknown> }
    | { event: "delta"; data: { text: string } }
    | { event: "suggestions"; data: { items: string[] } }
    | { event: "final"; data: STTMBuilderEnvelopeResponse }
    | { event: "error"; data: { message?: string; code?: string } }
  > {
    if (useMockDb) {
      throwMockError();
      yield* mockInvokeStream(payload);
      return;
    }

    const response = await fetch(`${resolveApiBaseUrl()}${API_ROUTES.workbench.invokeStream}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(toEnvelope(payload)),
    });

    if (!response.ok || !response.body) {
      const errorText = await response.text().catch(() => "");
      const streamError = new Error(
        errorText
          ? `Streaming request failed with HTTP ${response.status}: ${errorText}`
          : `Streaming request failed with HTTP ${response.status}`
      );
      handleApiClientError(streamError, {
        title: 'Streaming request failed',
        subHeader: 'Workbench invoke stream',
        fallbackMessage: 'Unable to stream the workbench response.',
      });
      throw streamError;
    }

    const decoder = new TextDecoder();
    const reader = response.body.getReader();
    let buffer = "";

    const parseChunk = (chunk: string) => {
      let eventName = "message";
      const dataParts: string[] = [];
      for (const line of chunk.split(/\r?\n/)) {
        if (!line.trim()) continue;
        if (line.startsWith("event:")) {
          eventName = line.slice(6).trim();
          continue;
        }
        if (line.startsWith("data:")) {
          dataParts.push(line.slice(5).trimStart());
        }
      }
      if (!dataParts.length) return null;
      const raw = dataParts.join("\n");
      try {
        return { event: eventName, data: JSON.parse(raw) };
      } catch {
        return { event: eventName, data: { text: raw } };
      }
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let extracted = extractSseChunk(buffer);
      while (extracted !== null) {
        const parsed = parseChunk(extracted.chunk);
        buffer = extracted.remaining;
        if (parsed) {
          yield parsed as
            | { event: "status"; data: Record<string, unknown> }
            | { event: "delta"; data: { text: string } }
            | { event: "suggestions"; data: { items: string[] } }
            | { event: "final"; data: STTMBuilderEnvelopeResponse }
            | { event: "error"; data: { message?: string; code?: string } };
        }
        extracted = extractSseChunk(buffer);
      }
    }

    if (buffer.trim()) {
      const parsed = parseChunk(buffer);
      if (parsed) {
        yield parsed as
          | { event: "status"; data: Record<string, unknown> }
          | { event: "delta"; data: { text: string } }
          | { event: "suggestions"; data: { items: string[] } }
          | { event: "final"; data: STTMBuilderEnvelopeResponse }
          | { event: "error"; data: { message?: string; code?: string } };
      }
    }
  },

  /**
   * Direct invocation of AGT_SOURCE_MAPPING, bypassing the orchestrator.
   * This provides faster auto-mapping by calling the source mapping agent directly.
   */
  directAutoMap: async (payload: DirectAutoMapRequest): Promise<DirectAutoMapResponse> => {
    if (useMockDb) {
      throwMockError();
      // Return a mock response structure
      return mockDelay({
        request_id: payload.request_id ?? 'mock-request-id',
        status: 'completed' as const,
        mappings: {},
        message: 'Mock direct auto-map response',
        warnings: [],
        error: null,
        meta: { mock: true },
      });
    }

    const response = await api.post<DirectAutoMapResponse>(
      API_ROUTES.workbench.autoMapDirect,
      payload,
      { timeout: 180000 }
    );
    return response.data;
  },

  /**
   * Direct invocation of AGT_SOURCE_MAPPING with SSE streaming.
   * Provides real-time progress updates during auto-mapping.
   */
  directAutoMapStream: async function* (
    payload: DirectAutoMapRequest
  ): AsyncGenerator<
    | { event: "status"; data: Record<string, unknown> }
    | { event: "delta"; data: { text: string } }
    | { event: "final"; data: DirectAutoMapResponse }
    | { event: "error"; data: { message?: string; code?: string } }
  > {
    if (useMockDb) {
      throwMockError();
      yield { event: "status", data: { phase: "mock", message: "Mock streaming" } };
      yield {
        event: "final",
        data: {
          request_id: payload.request_id ?? 'mock-request-id',
          status: 'completed' as const,
          mappings: {},
          message: 'Mock direct auto-map stream response',
          warnings: [],
          error: null,
          meta: { mock: true, streaming: true },
        },
      };
      return;
    }

    const response = await fetch(
      `${resolveApiBaseUrl()}${API_ROUTES.workbench.autoMapDirectStream}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );

    if (!response.ok || !response.body) {
      const errorText = await response.text().catch(() => "");
      const streamError = new Error(
        errorText
          ? `Direct auto-map streaming failed with HTTP ${response.status}: ${errorText}`
          : `Direct auto-map streaming failed with HTTP ${response.status}`
      );
      handleApiClientError(streamError, {
        title: 'Direct auto-map streaming failed',
        subHeader: 'AGT_SOURCE_MAPPING direct invocation',
        fallbackMessage: 'Unable to stream the direct auto-map response.',
      });
      throw streamError;
    }

    const decoder = new TextDecoder();
    const reader = response.body.getReader();
    let buffer = "";

    const parseChunk = (chunk: string) => {
      let eventName = "message";
      const dataParts: string[] = [];
      for (const line of chunk.split(/\r?\n/)) {
        if (!line.trim()) continue;
        if (line.startsWith("event:")) {
          eventName = line.slice(6).trim();
          continue;
        }
        if (line.startsWith("data:")) {
          dataParts.push(line.slice(5).trimStart());
        }
      }
      if (!dataParts.length) return null;
      const raw = dataParts.join("\n");
      try {
        return { event: eventName, data: JSON.parse(raw) };
      } catch {
        return { event: eventName, data: { text: raw } };
      }
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let extracted = extractSseChunk(buffer);
      while (extracted !== null) {
        const parsed = parseChunk(extracted.chunk);
        buffer = extracted.remaining;
        if (parsed) {
          yield parsed as
            | { event: "status"; data: Record<string, unknown> }
            | { event: "delta"; data: { text: string } }
            | { event: "final"; data: DirectAutoMapResponse }
            | { event: "error"; data: { message?: string; code?: string } };
        }
        extracted = extractSseChunk(buffer);
      }
    }

    if (buffer.trim()) {
      const parsed = parseChunk(buffer);
      if (parsed) {
        yield parsed as
          | { event: "status"; data: Record<string, unknown> }
          | { event: "delta"; data: { text: string } }
          | { event: "final"; data: DirectAutoMapResponse }
          | { event: "error"; data: { message?: string; code?: string } };
      }
    }
  },
};
