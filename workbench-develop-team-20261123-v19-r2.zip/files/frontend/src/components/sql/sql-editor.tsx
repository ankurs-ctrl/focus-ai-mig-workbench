'use client';
import { AiaBox } from '@/components/ui';

import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from 'react';

import {
  SQL_FUNCTION_CATEGORIES,
  SQL_FUNCTIONS_BY_CATEGORY,
  SQL_QUICK_ACTIONS,
} from './function-library.config';
import { insertSqlSnippet } from './sql-insert';
import { formatSqlForDisplay } from './format-sql';
import { SqlEditorSurface } from './sql-editor-surface';
import { SqlEditorToolbar } from './sql-editor-toolbar';
import { SqlFunctionLibrary } from './sql-function-library';
import {
  SQL_EDITOR_COLORS,
  SQL_EDITOR_DEFAULT_HEIGHT,
  SQL_EDITOR_FRAME_SX,
  SQL_EDITOR_PANEL_MIN_HEIGHT,
  SQL_FUNCTION_LIBRARY_MIN_HEIGHT,
} from './sql-styles';
import type { SqlEditorProps, SqlFunctionCategoryId, SqlInsertOptions } from './types';

const COPY_FEEDBACK_MS = 1500;

export function SqlEditor({
  value,
  onChange,
  readOnly = false,
  suggestions,
  title = 'SQL Preview',
  subtitle,
  toolbarActions,
  placeholder = '-- Write SQL here',
  emptyText = '-- No SQL to display',
  showCopy = false,
  onCopy,
  onCopySuccess,
  onCopyError,
  showUpload = false,
  onUpload,
  onUploadError,
  showFunctionLibrary = false,
  quickActions = SQL_QUICK_ACTIONS,
  functionCategories = SQL_FUNCTION_CATEGORIES,
  functionsByCategory = SQL_FUNCTIONS_BY_CATEGORY,
  defaultFunctionCategory = 'string',
  functionLibraryTourTargets,
  showLineNumbers = true,
  completionCandidates,
  fillHeight = false,
  minHeight = SQL_EDITOR_DEFAULT_HEIGHT,
  maxHeight,
  className,
  sx,
  insertAtCursorRef,
  undoHistory = false,
  historyKey = null,
}: SqlEditorProps) {
  const editorRef = useRef<HTMLTextAreaElement | null>(null);
  const selectionRef = useRef({ start: 0, end: 0 });
  const pastRef = useRef<string[]>([]);
  const futureRef = useRef<string[]>([]);
  const skipHistoryRef = useRef(false);
  const historyValueRef = useRef(value);
  const historyKeyRef = useRef(historyKey);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<SqlFunctionCategoryId>(
    defaultFunctionCategory,
  );

  const resolvedHeight = maxHeight ?? minHeight ?? SQL_EDITOR_DEFAULT_HEIGHT;
  const panelMinHeight = minHeight ?? SQL_EDITOR_PANEL_MIN_HEIGHT;
  const panelMaxHeight = maxHeight ?? (fillHeight ? '100%' : resolvedHeight);
  const containerHeightSx = fillHeight
    ? {
        height: '100%',
        minHeight: panelMinHeight,
        maxHeight: panelMaxHeight,
        flex: 1,
      }
    : {
        height: resolvedHeight,
        minHeight: panelMinHeight,
        maxHeight: panelMaxHeight,
      };

  useEffect(() => {
    if (!undoHistory) return;
    if (historyKeyRef.current !== historyKey) {
      historyKeyRef.current = historyKey;
      pastRef.current = [];
      futureRef.current = [];
      skipHistoryRef.current = false;
      historyValueRef.current = value;
      return;
    }
    if (skipHistoryRef.current) {
      skipHistoryRef.current = false;
      historyValueRef.current = value;
      return;
    }
    if (value === historyValueRef.current) return;
    pastRef.current.push(historyValueRef.current);
    if (pastRef.current.length > 100) pastRef.current.shift();
    futureRef.current = [];
    historyValueRef.current = value;
  }, [historyKey, undoHistory, value]);

  const handleHistoryKeyDown = useCallback((event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (!undoHistory || readOnly || !onChange) return;
    const modifier = event.ctrlKey || event.metaKey;
    const undo = modifier && !event.shiftKey && event.key.toLowerCase() === 'z';
    const redo = modifier && (event.key.toLowerCase() === 'y' || (event.shiftKey && event.key.toLowerCase() === 'z'));
    if (!undo && !redo) return;
    event.preventDefault();
    if (undo) {
      const previous = pastRef.current.pop();
      if (previous === undefined) return;
      futureRef.current.push(value);
      skipHistoryRef.current = true;
      onChange(previous);
      return;
    }
    const next = futureRef.current.pop();
    if (next === undefined) return;
    pastRef.current.push(value);
    skipHistoryRef.current = true;
    onChange(next);
  }, [onChange, readOnly, undoHistory, value]);

  useEffect(() => {
    if (!copyFeedback) return;
    const timeout = window.setTimeout(() => setCopyFeedback(null), COPY_FEEDBACK_MS);
    return () => window.clearTimeout(timeout);
  }, [copyFeedback]);

  const handleCopyFeedback = useCallback(
    (message: string | null, onNotify?: (message: string) => void) => {
      setCopyFeedback(message);
      if (message && onNotify) {
        onNotify(message);
      }
    },
    [],
  );

  const handleInsert = useCallback(
    (snippet: string, options?: SqlInsertOptions) => {
      if (readOnly || !onChange) return;

      const editor = editorRef.current;
      const start = editor?.selectionStart ?? selectionRef.current.start;
      const end = editor?.selectionEnd ?? selectionRef.current.end;
      const result = insertSqlSnippet(editor?.value ?? value, snippet, start, end, options);
      onChange(result.nextValue);

      requestAnimationFrame(() => {
        const editor = editorRef.current;
        if (!editor) return;
        editor.focus();
        editor.setSelectionRange(result.selectionStart, result.selectionEnd);
        selectionRef.current = {
          start: result.selectionStart,
          end: result.selectionEnd,
        };
      });
    },
    [onChange, readOnly, value],
  );

  const handleSelectionChange = useCallback((start: number, end: number) => {
    selectionRef.current = { start, end };
  }, []);

  // Assigned during render so a sidebar click always sees the latest insert,
  // including after the editor loses focus.
  if (insertAtCursorRef) {
    insertAtCursorRef.current = handleInsert;
  }

  const editorPanel = (
    <>
      <SqlEditorToolbar
        title={title}
        subtitle={subtitle}
        toolbarActions={toolbarActions}
        value={formatSqlForDisplay(value)}
        readOnly={readOnly}
        showCopy={showCopy}
        showUpload={showUpload && !readOnly}
        copyFeedback={copyFeedback}
        onCopy={onCopy}
        onUpload={onUpload}
        onUploadError={onUploadError}
        onCopySuccess={(message) => handleCopyFeedback(message, onCopySuccess)}
        onCopyError={(message) => handleCopyFeedback(message, onCopyError)}
        onCopyFeedback={setCopyFeedback}
      />

      <SqlEditorSurface
        value={value}
        onChange={onChange}
        readOnly={readOnly}
        placeholder={placeholder}
        emptyText={emptyText}
        showLineNumbers={showLineNumbers}
        editorRef={editorRef}
        onSelectionChange={handleSelectionChange}
        completionCandidates={completionCandidates ?? suggestions}
        onEditorKeyDown={undoHistory ? handleHistoryKeyDown : undefined}
      />
    </>
  );

  if (showFunctionLibrary) {
    return (
      <AiaBox
        className={className}
        sx={{
          display: 'flex',
          alignItems: 'stretch',
          gap: 1.5,
          width: '100%',
          flexShrink: 0,
          ...containerHeightSx,
          ...sx,
        }}
      >
        <AiaBox
          sx={{
            ...SQL_EDITOR_FRAME_SX,
            flex: 1,
            minWidth: 0,
            minHeight: panelMinHeight,
            maxHeight: panelMaxHeight,
            flexDirection: 'column',
            bgcolor: SQL_EDITOR_COLORS.panelBg,
            color: SQL_EDITOR_COLORS.text,
            overflow: 'hidden',
          }}
        >
          {editorPanel}
        </AiaBox>

        <AiaBox
          sx={{
            ...SQL_EDITOR_FRAME_SX,
            width: 280,
            flexShrink: 0,
            minHeight: SQL_FUNCTION_LIBRARY_MIN_HEIGHT,
            maxHeight: panelMaxHeight,
            height: '100%',
            flexDirection: 'column',
            bgcolor: '#ffffff',
            overflow: 'hidden',
          }}
        >
          <SqlFunctionLibrary
            onInsert={handleInsert}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
            quickActions={quickActions}
            categories={functionCategories}
            functionsByCategory={functionsByCategory}
            defaultCategory={defaultFunctionCategory}
            rootTourTarget={functionLibraryTourTargets?.root}
            libraryTourTarget={functionLibraryTourTargets?.library}
            tabsTourTarget={functionLibraryTourTargets?.tabs}
            panelTourTarget={functionLibraryTourTargets?.panel}
          />
        </AiaBox>
      </AiaBox>
    );
  }

  return (
    <AiaBox
      className={className}
      sx={{
        ...SQL_EDITOR_FRAME_SX,
        flexDirection: 'column',
        width: '100%',
        flexShrink: 0,
        bgcolor: SQL_EDITOR_COLORS.panelBg,
        color: SQL_EDITOR_COLORS.text,
        overflow: 'hidden',
        ...containerHeightSx,
        ...sx,
      }}
    >
      {editorPanel}
    </AiaBox>
  );
}
