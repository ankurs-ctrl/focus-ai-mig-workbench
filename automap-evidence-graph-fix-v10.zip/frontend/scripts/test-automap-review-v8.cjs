// Client-reported negative probes. Real thunk/reducers and the real pinned SHA-256 implementation.
const assert=require('node:assert/strict');
const test=require('node:test').test;
const ts=require('typescript');
const crypto=require('node:crypto');
const h=require('./test-automap-preservation.cjs');
const {helpers,compile,reducer,stateFor,blank,imported,response,direct}=h;
const functions={};const reducers={};let acceptThunk;
function visit(node){
  if(ts.isFunctionDeclaration(node)&&node.name)functions[node.name.text]=node.getText(h.slice).replace(/^export\s+/,'');
  if(ts.isPropertyAssignment(node))reducers[node.name.getText(h.slice)]=node.initializer.getText(h.slice);
  if(ts.isVariableDeclaration(node)&&node.name.getText(h.slice)==='acceptPendingAiMappingReviews')acceptThunk=node.initializer.arguments[1].getText(h.slice);
  ts.forEachChild(node,visit);
}
visit(h.slice);
const values=[{name:'FirmID',value:'current'}];
const valueRevision=helpers.autoMapRevisionHash(helpers.autoMapValuesSignature(values));
const begin=(state,checked=[])=>{
  state.selectedMappingIds=checked;
  reducer(h.pendingReducer)(state,{meta:{requestId:'run-one'}});
  state.autoMapRun.valuesRevision=valueRevision;
};
function preservation(proposal){return response(proposal,{meta:{
  automap_preserved_targets:['NAME'],automap_baseline_preservation:{version:'v1',instruction:'preserve_frontend_rows',apply_preserved_mappings:false},
  automap_resolution:{mode:'preserve_and_complete',targets:[{target_attribute:'NAME',status:'pending'}]},
  auto_mapping_review:{recommendations:[{category:'baseline_proposal',target_attribute:'NAME',severity:'action_required'}]},
}});}
function editAndSave(state,expression){
  const update=compile(`${functions.captureManualEditSnapshot}; return (${reducers.updateMapping});`,helpers);
  update(state,{payload:{id:'NAME',updates:{expression,status:'MAPPED'}}});
  reducer(reducers.commitPendingManualMappingEdits)(state,{});
}
async function accept(state,all){
  const fn=compile(`return (${acceptThunk});`,{...helpers,listProjectAttributes:async()=>values,getErrorMessage:e=>e.message,
    applyPendingAiMappingReview:payload=>({type:'one',payload}),applyAllPendingAiMappingReviews:payload=>({type:'all',payload})});
  return fn({all},{getState:()=>({sttmBuilder:state}),dispatch:action=>reducer(reducers[action.type==='all'?'applyAllPendingAiMappingReviews':'applyPendingAiMappingReview'])(state,action),rejectWithValue:error=>({error})});
}
for(const all of [false,true])test(`late preserved-baseline response cannot replace a newer saved edit (all=${all})`,async()=>{
  const state=stateFor(imported());begin(state);
  editAndSave(state,"COALESCE(src.UserEdit, 'saved')");
  const saved=structuredClone(state.mappings[0]);
  helpers.applyAutoMapResponseToState(state,preservation(direct));
  helpers.applyAutoMapResponseToState(state,preservation(direct)); // partial and terminal
  await accept(state,all);
  assert.deepEqual(state.mappings[0],saved);
  assert.equal(state.pendingAiMappingReviews.length,0);
});
const originals={
  source:()=>imported(),
  emptyConstant:()=>({...blank(),status:'MAPPED',mappingMode:'constant',constantValue:'',rule:'Value'}),
  attribute:()=>({...blank(),status:'MAPPED',mappingMode:'attribute',constantValue:'$FirmID',attributeName:'FirmID',valueBindingIds:['firm'],rule:'Value'}),
};
const unresolved={source_attributes:[],candidate_source_attributes:['src.Possible'],confidence_score:0,
  confidence_reason:'Plausible alternative, not a selected mapping.',transformation_classification:'unresolved',unmatched_reason:'Business rule is missing'};
for(const [kind,make] of Object.entries(originals))for(const all of [false,true]){
  test(`unresolved reevaluation cannot erase ${kind} (all=${all})`,async()=>{
    const original=make();const state=stateFor(structuredClone(original));begin(state,['NAME']);
    helpers.applyAutoMapResponseToState(state,response(unresolved));
    await accept(state,all);
    assert.deepEqual(state.mappings[0],original);
    assert.equal(state.pendingAiMappingReviews.length,0);
    assert.deepEqual(state.mappingSuggestions[0].candidateSourceAttributes,['src.Possible']);
  });
}
test('SHA-256 vectors use the installed dependency, without a crypto substitute',()=>{
  assert.equal(require('../package.json').dependencies['@noble/hashes'],'1.8.0');
  for(const text of ['', 'abc', '界 quoted "value"', 'a'.repeat(200000)])
    assert.equal(helpers.autoMapRevisionHash(text),crypto.createHash('sha256').update(text).digest('hex'));
});

for(const all of [false,true])test(`previously queued unresolved item is rejected at acceptance, even with a current proof (all=${all})`,async()=>{
  const original=imported();const state=stateFor(structuredClone(original));begin(state,['NAME']);
  helpers.applyAutoMapResponseToState(state,response(direct));
  const review=state.pendingAiMappingReviews[0];
  Object.assign(review,{sourceAttributes:[],transformationClassification:'unresolved',unmatchedReason:'Not established',candidateSourceAttributes:['src.Possible']});
  const before=structuredClone(state.mappings[0]);
  state.autoMapRun=null;
  await accept(state,all);
  assert.deepEqual(state.mappings[0],before);
  assert.equal(state.pendingAiMappingReviews.length,1);
  assert.match(state.errorState.autoMap,/held/);
});
for(const phase of ['unsaved','saved','cancelled','edited_back'])test(`late proposal cannot be legitimized after a ${phase} manual edit`,async()=>{
  const state=stateFor(imported());begin(state);
  const old=state.mappings[0].expression;
  const update=compile(`${functions.captureManualEditSnapshot}; return (${reducers.updateMapping});`,helpers);
  update(state,{payload:{id:'NAME',updates:{expression:'src.UserEdit'}}});
  if(phase==='saved'){state.mappings[0].status='MAPPED';reducer(reducers.commitPendingManualMappingEdits)(state,{});}
  if(phase==='cancelled')reducer(reducers.cancelPendingManualMappingEdits)(state,{});
  if(phase==='edited_back')update(state,{payload:{id:'NAME',updates:{expression:old}}});
  const before=structuredClone(state.mappings[0]);
  if(before.status==='PROCESSING')before.status='UNMAPPED'; // settle UI work, never certify the edited expression
  helpers.applyAutoMapResponseToState(state,preservation(direct));
  assert.equal(state.pendingAiMappingReviews.length,0);
  await accept(state,true);assert.deepEqual(state.mappings[0],before);
});
test('manual edits invalidate already queued proposals before a late terminal response',async()=>{
  const state=stateFor(imported());begin(state);
  helpers.applyAutoMapResponseToState(state,preservation(direct));
  assert.equal(state.pendingAiMappingReviews.length,1);
  editAndSave(state,'src.NewSaved');
  assert.equal(state.pendingAiMappingReviews.length,0);
  helpers.applyAutoMapResponseToState(state,preservation(direct));
  await accept(state,false);assert.equal(state.mappings[0].expression,'src.NewSaved');
  assert.equal(state.pendingAiMappingReviews.length,0);
});
for(const all of [false,true])test(`legacy V7 revision proofs cannot be upgraded to accept stale work (all=${all})`,async()=>{
  const state=stateFor(imported());begin(state,['NAME']);helpers.applyAutoMapResponseToState(state,response(direct));
  const review=state.pendingAiMappingReviews[0];delete review.autoMapRevisionOrigin;delete review.autoMapRunId;
  state.autoMapRun=null;
  const before=structuredClone(state.mappings[0]);await accept(state,all);
  assert.deepEqual(state.mappings[0],before);assert.equal(state.pendingAiMappingReviews.length,1);
});
test('Apply all leaves an informational unresolved item while accepting an executable sibling',async()=>{
  const state=stateFor(imported(),blank('NEW'));begin(state,['NAME','NEW']);
  const answer=response(direct);answer.result.mappings.NEW=direct;
  answer.meta={automap_evidence_review_only_targets:['NAME','NEW']};
  helpers.applyAutoMapResponseToState(state,answer);
  assert.equal(state.pendingAiMappingReviews.length,2);
  const first=state.pendingAiMappingReviews.find(row=>row.mappingId==='NAME');
  Object.assign(first,{sourceAttributes:[],transformationClassification:'unresolved',candidateSourceAttributes:['src.Possible']});
  state.autoMapRun=null;
  await accept(state,true);
  assert.equal(state.mappings[0].expression,imported().expression);
  assert.equal(state.mappings[1].sourceColumn,'src.NewName');
  assert.deepEqual(state.pendingAiMappingReviews.map(row=>row.mappingId),['NAME']);
});
