const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript'),Module=require('node:module'),vm=require('node:vm');
const root=path.resolve(__dirname,'../src');
const sessionValues=new Map();let now=1000000,calls=[],getHandler,postHandler;
const storage={getItem:key=>sessionValues.get(key)??null,setItem:(key,value)=>sessionValues.set(key,value),removeItem:key=>sessionValues.delete(key),get length(){return sessionValues.size},key:index=>[...sessionValues.keys()][index]};
global.window={sessionStorage:storage,location:{hostname:'deployed.example'}};
const originalNow=Date.now;Date.now=()=>now;
const modules=new Map();
function load(rel){const file=path.resolve(root,rel);if(modules.has(file))return modules.get(file).exports;const m=new Module(file,module);modules.set(file,m);m.require=dep=>{
 if(dep==='@/api/axiosInstance')return {getApiData:async(url)=>{calls.push(url);return getHandler(url)},postEnvelopeData:async(url,body)=>{calls.push(url);return postHandler(url,body)},buildApiEnvelope:(_,data)=>({data})};
 if(dep==='@/services/authService')return {getAuthenticatedReadScope:()=>scope.cacheScope()};
 if(dep.startsWith('@/'))return load(dep.slice(2)+'.ts');return require(dep);
};m._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);return m.exports;}
const scope=load('services/session-cache-scope.ts');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
function freshProjectModule(){modules.delete(path.join(root,'services/projectService.ts'));return load('services/projectService.ts');}
function ast(rel){const file=path.join(root,rel);return ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);}
function find(tree,predicate){let found;function visit(node){if(predicate(node))found=node;ts.forEachChild(node,visit)}visit(tree);assert.ok(found);return found;}
function evaluate(text,context){return vm.runInNewContext(ts.transpileModule(`(${text})`,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,context);}
(async()=>{
 scope.setCacheIdentity('alice:ADMIN:ROLE_A');let service=freshProjectModule();
 getHandler=()=>[{project_id:'p',project_name:'Original'}];const initial=await service.listProjects();
 now+=24*60*60*1000;service=freshProjectModule();const refresh=deferred();getHandler=()=>refresh.promise;
 assert.equal((await service.listProjects())[0].project_name,'Original','persisted project cache renders beyond five minutes');
 assert.equal(calls.length,2,'stale persisted project list starts one background refresh');
 refresh.resolve([{project_id:'p',project_name:'Updated'}]);await new Promise(setImmediate);
 assert.equal((await service.listProjects())[0].project_name,'Updated');
 const failed=deferred();now+=6*60*1000;getHandler=()=>failed.promise;
 assert.equal((await service.listProjects())[0].project_name,'Updated');failed.reject(Error('offline'));await new Promise(setImmediate);
 getHandler=()=>new Promise(()=>{});assert.equal((await service.listProjects())[0].project_name,'Updated','transient refresh failure retains session data');
 scope.setCacheIdentity('alice:VIEWER:ROLE_B');assert.equal(service.getCachedProjectsSummary(),null);assert.equal(sessionValues.size,0,'same user with another role cannot reuse prior storage');
 let read=deferred();getHandler=()=>read.promise;const old=service.listProjects();scope.setCacheIdentity('bob:VIEWER:ROLE_B');
 const rejected=assert.rejects(old,/Session changed/);read.resolve(initial);await rejected;
 getHandler=()=>({sttm:{sttm_id:'one',last_snapshot_id:'one-old'},latest_snapshot:{},sources:[],mapping_rows:[]});const one=await service.getSttm('one');
 getHandler=()=>({sttm:{sttm_id:'two',last_snapshot_id:'two-old'},latest_snapshot:{},sources:[],mapping_rows:[]});const two=await service.getSttm('two');
 getHandler=()=>({projects:[],sttms:[{sttm_id:'one',last_snapshot_id:'one-new'},{sttm_id:'two',last_snapshot_id:'two-old'}]});await service.getAllProjectsSummary(true);
 const before=calls.length;assert.equal(await service.getSttm('two'),two);assert.equal(calls.length,before,'server changes to one mapping keep another detail warm');
 getHandler=()=>({...one,sttm:{...one.sttm,last_snapshot_id:'one-new'}});assert.notEqual(await service.getSttm('one'),one);assert.equal(calls.length,before+1,'changed server snapshot invalidates only its mapping');
 const expiry=[...sessionValues].filter(([key])=>key.includes('sttm:detail')&&key.includes('one')).map(([,value])=>JSON.parse(value).expiresAt)[0];
 assert.equal(expiry,now+5*60*1000,'detail freshness is an absolute Date.now + interval, not a duration');
 postHandler=()=>({snapshot_id:'two-saved',has_unpublished_draft:true});
 await service.autosaveSttm('two',{workspace_snapshot:{mapping_rows:[],source_tables:[]}});
 const savedEntry=[...sessionValues].filter(([key])=>key.includes('sttm:detail')&&key.includes('two')).map(([,value])=>JSON.parse(value))[0];
 assert.equal(savedEntry.expiresAt,now+5*60*1000,'autosave also records an absolute freshness deadline');
 const priorSummary=service.getCachedProjectsSummary();const aggregate=deferred();getHandler=()=>aggregate.promise;
 const aggregateRead=service.getAllProjectsSummary(true);
 postHandler=()=>({snapshot_id:'two-newer',has_unpublished_draft:true});
 await service.autosaveSttm('two',{workspace_snapshot:{mapping_rows:[],source_tables:[]}});
 aggregate.resolve(priorSummary);await aggregateRead;
 const afterSaveCalls=calls.length;
 assert.equal((await service.getSttm('two')).sttm.last_snapshot_id,'two-newer');
 assert.equal(calls.length,afterSaveCalls,'late summary metadata cannot discard a newer mapping-only save');
 const provider=ast('features/sttm/context/sttm-builder-context.tsx');const hydrate=find(provider,n=>ts.isVariableDeclaration(n)&&n.name.getText(provider)==='hydrateSession').initializer.getText(provider);
 const draft={activeSttmId:'mapping',openSttmStatus:'success',manualEdit:'keep',sourceColumns:['src.ID']};
 for(const pathname of ['/sttm/builder/mapping','/sttm/builder/mapping/mapping','/sttm/builder/mapping/summary','/sttm/builder/new/mapping']){
  const hydrated=[];const invoke=evaluate(hydrate,{isInSttmBuilder:true,sessionHydrated:true,hasExplicitNewDraftIntent:()=>false,getAuthenticatedReadScope:()=>scope.cacheScope(),state:draft,store:{getState:()=>({sttmBuilder:draft})},pathname,setSessionHydrated:value=>hydrated.push(value),authService:{getSession:()=>new Promise(()=>{})}});
  await invoke();assert.deepEqual(hydrated,[true]);assert.equal(draft.manualEdit,'keep');assert.deepEqual(draft.sourceColumns,['src.ID']);
 }
 for(const explicit of [false,true]){
  const hydrated=[];const state={activeSttmId:null,mappings:[{expression:'manual draft'}],sourceAttributeGroups:[],targetAttributeGroup:null};
  const invoke=evaluate(hydrate,{isInSttmBuilder:true,sessionHydrated:true,hasExplicitNewDraftIntent:()=>explicit,getAuthenticatedReadScope:()=>scope.cacheScope(),state,store:{getState:()=>({sttmBuilder:state})},pathname:'/sttm/builder/new',setSessionHydrated:value=>hydrated.push(value),authService:{getSession:()=>new Promise(()=>{})}});
  const pending=invoke();if(!explicit)await pending;
  assert.deepEqual(hydrated,[!explicit],explicit?'an explicit new/upload flow must not be mistaken for cached step navigation':'unsaved draft edits stay in memory between steps');
 }
 const loader=ast('features/sttm/shared/saved-sttm-loader.tsx');const effect=find(loader,n=>ts.isCallExpression(n)&&n.expression.getText(loader)==='useEffect').arguments[0].getText(loader);
 let dispatched=[];const loaderContext={sttmId:'mapping',activeSttmId:'mapping',status:'success',attemptedId:{current:null},dispatch:value=>dispatched.push(value),openSttmFromBackend:value=>value};
 evaluate(effect,loaderContext)();assert.equal(dispatched.length,0,'same-workspace step navigation does not reopen from Snowflake');
 evaluate(effect,{...loaderContext,sttmId:'different',attemptedId:{current:null}})();assert.equal(dispatched.length,1,'opening another workspace still resolves its authoritative snapshot');
 for(const [rel,flag] of [['features/mappings/AllMappingsPage.tsx','isLoadingMappings'],['features/projects/ProjectDetailPage.tsx','isLoading']]){
  const tree=ast(rel);const node=find(tree,n=>ts.isVariableDeclaration(n)&&ts.isArrayBindingPattern(n.name)&&n.name.elements[0]?.getText(tree)===flag);
  assert.equal(evaluate(node.initializer.arguments[0].getText(tree),{initialSummary:{projects:[],sttms:[]}}),false);
 }
 let requestInterceptor,responseError;const events=[];const unsub=scope.onSessionFailure(error=>events.push(error));

 getHandler=()=>({projects:[{project_id:'p',sttm_count:2,total_mappings:30,mapped_count:15,complete_count:0,partial_count:1,draft_count:1}],sttms:[{sttm_id:'m1',project_id:'p',status:'PARTIAL',mapping_count:20,mapped_count:15},{sttm_id:'m2',project_id:'p',status:'DRAFT',mapping_count:10,mapped_count:0}]});
 await service.getAllProjectsSummary(true);
 const staleRead=deferred();getHandler=()=>staleRead.promise;
 const lateSummary=service.getAllProjectsSummary(true);const blocked=assert.rejects(lateSummary,/Session changed/);
 const callCount=calls.length;let notifications=0;const unsubscribe=service.subscribeProjectMetadata(()=>notifications++);
 service.removeResourceFromListings('mapping','m1');
 assert.equal(calls.length,callCount,'removal patches the cache without fetching the page again');
 assert.equal(service.getCachedProjectsSummary().sttms.length,1);
 assert.equal(service.getCachedProjectsSummary().projects[0].total_mappings,10);
 assert.equal(service.getCachedProjectsSummary().projects[0].partial_count,0);
 staleRead.resolve({projects:[],sttms:[{sttm_id:'m1'}]});await blocked;
 assert.equal(service.getCachedProjectsSummary().sttms[0].sttm_id,'m2','late reads cannot resurrect removed rows');
 service.removeResourceFromListings('project','p');
 assert.equal(service.getCachedProjectsSummary().projects.length,0);assert.equal(service.getCachedProjectsSummary().sttms.length,0);
 assert.equal(notifications,2);unsubscribe();
 const apiFile=path.join(root,'api/axiosInstance.ts'),apiModule=new Module(apiFile,module);
 apiModule.require=dep=>{
  if(dep==='axios'){const client={create:()=>({interceptors:{request:{use:fn=>{requestInterceptor=fn}},response:{use:(_,fn)=>{responseError=fn}}}}),isCancel:()=>false};return {default:client,...client};}
  if(dep==='@/services/session-cache-scope')return scope;
  if(dep==='./axios.types')return {};
  if(dep==='./errors/app-error')return {extractApiErrorMessage:()=>''};
  if(dep==='./errors/error-bus')return {handleApiClientError:error=>error};
  if(dep.startsWith('@/'))return load(dep.slice(2)+'.ts');
  return require(dep);
 };
 apiModule._compile(ts.transpileModule(fs.readFileSync(apiFile,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,apiFile);
 const previous=requestInterceptor({skipGlobalError:true});scope.setCacheIdentity('new-user:ADMIN:NEW_ROLE');
 await assert.rejects(responseError({config:previous,response:{status:401}}));assert.equal(scope.cacheScope(),'new-user:ADMIN:NEW_ROLE');assert.equal(events.length,0);
 const current=requestInterceptor({skipGlobalError:true});await assert.rejects(responseError({config:current,response:{status:401}}));assert.equal(scope.cacheScope(),null);assert.equal(events.length,1);assert.equal(sessionValues.size,0);unsub();
 console.log('PASS session-wide navigation: persisted stale reads, background refresh/failure, mapping snapshot invalidation, retained edits/metadata, cached page initialization and late-401 identity fencing');
})().catch(error=>{console.error(error);process.exitCode=1}).finally(()=>Date.now=originalNow);
