param(
    [string]$EnvFile = "",
    [switch]$SkipComputePool,
    [switch]$SkipEgress
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

if (-not $EnvFile) {
    $EnvFile = Get-DefaultEnvFile
}

$snowExe = Ensure-SnowInstalled
$cfg = Import-DemoEnv -Path $EnvFile

Require-ConfigValues -Config $cfg -RequiredKeys @(
    "SNOWFLAKE_CONNECTION",
    "SNOWFLAKE_DATABASE",
    "SNOWFLAKE_SCHEMA",
    "SNOWFLAKE_IMAGE_REPOSITORY",
    "SNOWFLAKE_DEPLOY_STAGE"
) -EnvFile $EnvFile

$computePool = if ($cfg.ContainsKey("SNOWFLAKE_COMPUTE_POOL")) { [string]$cfg["SNOWFLAKE_COMPUTE_POOL"] } else { "" }
$instanceFamily = if ($cfg.ContainsKey("INSTANCE_FAMILY") -and $cfg["INSTANCE_FAMILY"]) { [string]$cfg["INSTANCE_FAMILY"] } else { "CPU_X64_S" }
$minNodes = if ($cfg.ContainsKey("MIN_NODES") -and $cfg["MIN_NODES"]) { [string]$cfg["MIN_NODES"] } else { "1" }
$maxNodes = if ($cfg.ContainsKey("MAX_NODES") -and $cfg["MAX_NODES"]) { [string]$cfg["MAX_NODES"] } else { "1" }
$egressIntegration = if ($cfg.ContainsKey("SNOWFLAKE_EGRESS_INTEGRATION")) { [string]$cfg["SNOWFLAKE_EGRESS_INTEGRATION"] } else { "" }
$networkRuleName = if ($cfg.ContainsKey("SNOWFLAKE_EGRESS_RULE_NAME") -and $cfg["SNOWFLAKE_EGRESS_RULE_NAME"]) {
    [string]$cfg["SNOWFLAKE_EGRESS_RULE_NAME"]
} else {
    "{0}.{1}.STREAMLIT_DEMO_EGRESS_RULE" -f $cfg["SNOWFLAKE_DATABASE"], $cfg["SNOWFLAKE_SCHEMA"]
}

Write-Host "Creating or verifying schema, image repository, and stage"
Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
CREATE SCHEMA IF NOT EXISTS $($cfg["SNOWFLAKE_DATABASE"]).$($cfg["SNOWFLAKE_SCHEMA"]);
CREATE IMAGE REPOSITORY IF NOT EXISTS $($cfg["SNOWFLAKE_DATABASE"]).$($cfg["SNOWFLAKE_SCHEMA"]).$($cfg["SNOWFLAKE_IMAGE_REPOSITORY"]);
CREATE STAGE IF NOT EXISTS $($cfg["SNOWFLAKE_DEPLOY_STAGE"]);
"@

if (-not $SkipComputePool) {
    Require-ConfigValues -Config $cfg -RequiredKeys @("SNOWFLAKE_COMPUTE_POOL") -EnvFile $EnvFile

    Write-Host ""
    Write-Host "Creating or verifying compute pool"
    Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
CREATE COMPUTE POOL IF NOT EXISTS $computePool
  MIN_NODES = $minNodes
  MAX_NODES = $maxNodes
  INSTANCE_FAMILY = $instanceFamily
  AUTO_RESUME = TRUE
  AUTO_SUSPEND_SECS = 3600;
"@
}

if (-not $SkipEgress -and $egressIntegration) {
    Require-ConfigValues -Config $cfg -RequiredKeys @("SNOWFLAKE_HOST", "SNOWFLAKE_EGRESS_INTEGRATION") -EnvFile $EnvFile

    Write-Host ""
    Write-Host "Creating or verifying network rule and external access integration"
    Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
CREATE OR REPLACE NETWORK RULE $networkRuleName
  TYPE = HOST_PORT
  MODE = EGRESS
  VALUE_LIST = ('$($cfg["SNOWFLAKE_HOST"]):443');

CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION $egressIntegration
  ALLOWED_NETWORK_RULES = ($networkRuleName)
  ENABLED = TRUE;
"@
}

Write-Host ""
Write-Host "Prerequisite setup complete."
