"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AiaBox, AiaResizeHandle } from "@/components/ui";
import { useSidebarSlot } from "@/features/sttm/layout/sidebar-slot-context";
import { SttmSidebarCollapseFooter } from "@/features/sttm/layout/sttm-sidebar-collapse-footer";
import SourceTargetPanel from "@/features/sttm/source-target/source-target-panel";
import SourceTargetDbSelection from "@/features/sttm/source-target/source-target-db-selection";
import SttmTableRelationshipFlow from "@/features/sttm/source-target/table-relationship-flow";
import {
  BuilderWorkspaceTabBar,
  type BuilderWorkspaceTab,
} from "@/features/sttm/shared/builder-workspace-tab-bar";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import {
  AllInclusiveIcon,
  TableChartOutlinedIcon,
  TableRowsRoundedIcon,
  TerminalRoundedIcon,
} from "@/utils/icons";

type SelectTablesTab = "builder" | "query" | "data" | "lineage";

const SELECT_TABLES_TABS: Array<BuilderWorkspaceTab<SelectTablesTab>> = [
  { key: "builder", label: "Select Tables", icon: <TableChartOutlinedIcon sx={{ fontSize: 17 }} /> },
  {
    key: "query",
    label: "SQL",
    icon: <TerminalRoundedIcon sx={{ fontSize: 17 }} />,
    tourTarget: TOUR_TARGETS.sttmQueryPreview,
  },
  {
    key: "data",
    label: "Data Preview",
    icon: <TableRowsRoundedIcon sx={{ fontSize: 17 }} />,
    tourTarget: TOUR_TARGETS.sttmSelectTablesDataPreviewTab,
  },
  {
    key: "lineage",
    label: "Table Relationships",
    icon: <AllInclusiveIcon sx={{ fontSize: 17 }} />,
    tourTarget: TOUR_TARGETS.sttmSelectTablesDataLineageTab,
  },
];

const MIN_SIDEBAR_WIDTH = 248;
// Dragging can widen the sidebar up to half of the window.
const MAX_SIDEBAR_VIEWPORT_RATIO = 0.5;
const COLLAPSED_SIDEBAR_WIDTH = 70;

export default function SttmBuilderPage() {
  const { setContent, collapsed, setCollapsed, width, setWidth } = useSidebarSlot();
  const [activeTab, setActiveTab] = useState<SelectTablesTab>("builder");
  const resizeStateRef = useRef<{ startX: number; startWidth: number } | null>(null);

  // Like the Mapping screen, this page draws its own sidebar under the tab bar,
  // so the layout's sidebar slot stays empty.
  useEffect(() => {
    setContent(null);
  }, [setContent]);

  useEffect(() => {
    const handlePointerMove = (event: MouseEvent) => {
      const state = resizeStateRef.current;
      if (!state) {
        return;
      }
      const maxWidth = Math.max(MIN_SIDEBAR_WIDTH, Math.floor(window.innerWidth * MAX_SIDEBAR_VIEWPORT_RATIO));
      setWidth(Math.min(maxWidth, Math.max(MIN_SIDEBAR_WIDTH, state.startWidth + event.clientX - state.startX)));
    };
    const handlePointerUp = () => {
      resizeStateRef.current = null;
    };
    window.addEventListener("mousemove", handlePointerMove);
    window.addEventListener("mouseup", handlePointerUp);
    return () => {
      window.removeEventListener("mousemove", handlePointerMove);
      window.removeEventListener("mouseup", handlePointerUp);
    };
  }, [setWidth]);

  const isBuilderTab = activeTab === "builder";
  // Stable, so the relationship canvas does not rebuild its lines on every render.
  const openJoinDefinitions = useCallback(() => setActiveTab("builder"), []);

  return (
    <div className="flex h-full min-h-0 w-full min-w-0 flex-1 flex-col overflow-hidden bg-white">
      <BuilderWorkspaceTabBar tabs={SELECT_TABLES_TABS} activeTab={activeTab} onTabChange={setActiveTab} />

      <div className="flex min-h-0 min-w-0 flex-1 overflow-hidden">
        {/* The Source / Target selection and CTE Library sidebar belongs to the Select Tables tab only. */}
        {isBuilderTab ? (
          <aside
            className="flex shrink-0 border-r border-gray-200 bg-white"
            style={{ width: collapsed ? COLLAPSED_SIDEBAR_WIDTH : width }}
          >
            {collapsed ? (
              <AiaBox sx={{ width: "100%", height: "100%", minHeight: 0, display: "flex", flexDirection: "column" }}>
                <AiaBox sx={{ flex: 1, minHeight: 0, overflow: "hidden" }}>
                  <SourceTargetDbSelection />
                </AiaBox>
                <SttmSidebarCollapseFooter
                  collapsed
                  centered
                  expandLabel="Expand source sidebar"
                  onToggle={() => setCollapsed(false)}
                />
              </AiaBox>
            ) : (
              <AiaBox sx={{ display: "flex", width: "100%", minWidth: 0, height: "100%", minHeight: 0 }}>
                <AiaBox sx={{ minWidth: 0, flex: 1, height: "100%", minHeight: 0, overflow: "hidden" }}>
                  <SourceTargetDbSelection />
                </AiaBox>
                <AiaResizeHandle
                  direction="horizontal"
                  onMouseDown={(event) => {
                    resizeStateRef.current = { startX: event.clientX, startWidth: width };
                  }}
                  sx={{ alignSelf: "stretch", height: "100%" }}
                />
              </AiaBox>
            )}
          </aside>
        ) : null}

        {/* Every tab stays mounted, so switching keeps tables, joins, filters, edited SQL and results.
            SQL, Data Preview and Table Relationships fill the screen and scroll inside their own panels. */}
        <div
          className={
            isBuilderTab
              ? "sttm-scroll-pane min-h-0 min-w-0 flex-1 overflow-y-auto overflow-x-hidden bg-white p-3"
              : "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden bg-white"
          }
        >
          <div className={isBuilderTab ? "flex min-w-0 flex-col gap-3 pb-3" : "flex min-h-0 min-w-0 flex-1 flex-col"}>
            <div
              className="grid min-h-[450px] min-w-0 grid-cols-1 overflow-hidden rounded-lg border border-[#e5e7eb] bg-white lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]"
              style={isBuilderTab ? undefined : { display: "none" }}
            >
              <div className="flex min-h-0 min-w-0 border-b border-[#e5e7eb] lg:border-b-0 lg:border-r">
                <SourceTargetPanel type="source" />
              </div>
              <div className="grid min-h-0 min-w-0 grid-rows-[minmax(240px,1fr)_auto]">
                <div className="flex min-h-0 min-w-0 border-b border-[#e5e7eb]">
                  <SourceTargetPanel type="derived" />
                </div>
                <div className="flex min-h-0 min-w-0">
                  <SourceTargetPanel type="target" />
                </div>
              </div>
            </div>

            <SttmTableRelationshipFlow
              section={activeTab}
              onPreviewRun={() => setActiveTab("data")}
              onOpenQueryPreview={() => setActiveTab("query")}
              onOpenJoinDefinitions={openJoinDefinitions}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
