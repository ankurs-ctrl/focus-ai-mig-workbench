/** Durable SQL-upload recovery. Never retries an uncertain POST. */
export type UploadReceipt = {
  request_id: string; status: string; stage?: string; result?: unknown; error_code?: string;
};
export const uploadRecoveryKey = (project: string, mapping: string) =>
  `sql-upload-recovery:v1:${encodeURIComponent(project)}:${encodeURIComponent(mapping || 'new')}`;

export async function observeSqlUpload(
  baseUrl: string, project: string, requestId: string, signal: AbortSignal,
  options?: {attempts?: number; delay?: () => Promise<void>},
): Promise<UploadReceipt> {
  let last: UploadReceipt = {request_id: requestId, status: 'unknown'};
  let notFound = 0;
  const attempts = options?.attempts ?? 30;
  const deadline = Date.now() + 60000;
  for (let attempt = 0; attempt < attempts && Date.now() < deadline; attempt++) {
    if (signal.aborted) throw new DOMException('Aborted', 'AbortError');
    try {
      const response = await fetch(`${baseUrl}/v1/upload/sql/requests/${encodeURIComponent(requestId)}?project_id=${encodeURIComponent(project)}`,
        {signal: AbortSignal.any([signal, AbortSignal.timeout(10000)])});
      if (response.ok) {
        last = await response.json();
        if (last.result || ['completed','failed','needs_reupload'].includes(last.status)) return last;
      } else if (response.status === 404) {
        notFound++;
      } else if ([401,403,409].includes(response.status)) {
        throw new Error('Upload recovery is unavailable for this signed-in caller or request.');
      } // A 404 after a disconnect can precede acceptance. Reconcile, never POST again.
    } catch (error) {
      if (signal.aborted) throw error;
      if (error instanceof Error && error.message.startsWith('Upload recovery')) throw error;
    }
    await (options?.delay?.() ?? new Promise(resolve => setTimeout(resolve, 1500)));
  }
  return notFound === attempts && attempts >= 3 ? {...last, status:'not_accepted'} : last;
}

export type SavedSqlUpload = {requestId: string; fingerprint: string};
export function readSqlUploadHandle(value: string | null): SavedSqlUpload | null {
  if (!value) return null;
  try {
    const item = JSON.parse(value);
    return typeof item?.requestId === 'string' && typeof item?.fingerprint === 'string' ? item : null;
  } catch { return {requestId:value, fingerprint:''}; }
}
export async function sqlUploadFingerprint(file: Blob, options: Array<[string,string]>): Promise<string> {
  const hash = async (bytes: ArrayBuffer) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)))
    .map(value => value.toString(16).padStart(2,'0')).join('');
  const content = await hash(await file.arrayBuffer());
  const canonical = JSON.stringify(['sql-upload-4-instance-bindings',content,[...options].sort(([a],[b])=>a.localeCompare(b))]);
  return hash(new TextEncoder().encode(canonical).buffer);
}
