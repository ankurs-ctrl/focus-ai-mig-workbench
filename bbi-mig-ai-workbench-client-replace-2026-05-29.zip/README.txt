Replace these files in the client repo:
1. frontend/src/app/sttm/builder/new/mapping/page.tsx
2. frontend/src/features/sttm/store/sttm-builder-slice.ts
3. services/sttm-builder/app/core/sttm_builder.py
4. scripts/prewarm_semantic_context_bundle.py

All current infra/snowflake agent specs and SQL files matched the extracted client zip during comparison.
