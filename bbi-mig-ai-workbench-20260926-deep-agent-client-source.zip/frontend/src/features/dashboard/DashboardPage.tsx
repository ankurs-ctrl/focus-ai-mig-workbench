"use client";
import { AiaBox, AiaButton, AiaLoadingOverlay } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { AppError } from '@/api/errors/app-error';

import { useCallback, useEffect, useState } from "react";
import DashboardStats from "./DashboardStats";
import QuickStatsPanel from "./QuickStatsPanel";
import RecentMappingsPanel from "./RecentMappingsPanel";
import DashboardHeader from "./DashboardHeader";
import {
  getAllProjectsSummary,
  type ProjectRecord,
  type STTMRecord,
} from "@/services/projectService";

type DashboardPageProps = {
  initialNewMappingOpen?: boolean;
};

export default function DashboardPage(_props: DashboardPageProps) {
  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [sttms, setSttms] = useState<STTMRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  const loadSummary = useCallback(async (forceRefresh = false) => {
    setIsLoading(true);
    try {
      const summary = await getAllProjectsSummary(forceRefresh).catch((error: unknown) => {
        // A read can hit an expired pooled Snowflake session. The backend drops
        // that connection; retry once against a fresh summary request.
        if (error instanceof AppError && error.payload.statusCode === 500) {
          return getAllProjectsSummary(true);
        }
        throw error;
      });
      setProjects(summary.projects);
      setSttms(summary.sttms);
      setLoadError(false);
    } catch (error) {
      if (process.env.NODE_ENV === "development") {
        console.warn("Dashboard project/STTM metadata is unavailable.", error);
      }
      setLoadError(true);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSummary();
  }, [loadSummary]);

  return (
    <AiaBox
      sx={{
        position: "relative",
        flex: 1,
        minHeight: 0,
        overflowY: "auto",
        px: 3,
        py: 2.5,
      }}
    >
      <DashboardHeader />

      {loadError ? (
        <AiaBox role="alert" sx={{ mt: 3, p: 2.5, border: '1px solid #fbbf24', borderRadius: 2, backgroundColor: '#fffbeb', display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 2 }}>
          <AiaBox sx={{ flex: 1, minWidth: 240 }}>
            <AiaText sx={{ fontWeight: 700, color: '#92400e' }}>Dashboard data could not be loaded</AiaText>
            <AiaText sx={{ mt: 0.5, fontSize: 13, color: '#92400e' }}>The Snowflake connection may need to be refreshed. Project and mapping counts are unavailable.</AiaText>
          </AiaBox>
          <AiaButton variant="outlined" onClick={() => void loadSummary(true)} disabled={isLoading}>Retry</AiaButton>
        </AiaBox>
      ) : !isLoading ? (
        <>
          <AiaBox className="mt-6"><DashboardStats projects={projects} sttms={sttms} /></AiaBox>
          <AiaBox className="mt-8 grid grid-cols-1 gap-6 xl:grid-cols-[1.35fr_1fr]">
            <QuickStatsPanel sttms={sttms} />
            <RecentMappingsPanel projects={projects} sttms={sttms} />
          </AiaBox>
        </>
      ) : null}
      <AiaLoadingOverlay open={isLoading} label="Loading dashboard data…" />
    </AiaBox>
  );
}
