#!/bin/bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_PORT="${BACKEND_PORT:-8000}"
FRONTEND_PORT="${FRONTEND_PORT:-3000}"
BACKEND_DEV_ORIGIN="${BACKEND_DEV_ORIGIN:-http://127.0.0.1:${BACKEND_PORT}}"

free_port() {
  local port="$1"
  local pids=""

  if command -v lsof >/dev/null 2>&1; then
    pids="$(lsof -ti tcp:"${port}" -sTCP:LISTEN 2>/dev/null || true)"
  fi

  if [[ -z "${pids}" ]]; then
    return 0
  fi

  echo "Stopping existing process(es) on port ${port}: ${pids}"
  kill ${pids} 2>/dev/null || true
  sleep 1

  local remaining=""
  if command -v lsof >/dev/null 2>&1; then
    remaining="$(lsof -ti tcp:"${port}" -sTCP:LISTEN 2>/dev/null || true)"
  fi

  if [[ -n "${remaining}" ]]; then
    echo "Force stopping remaining process(es) on port ${port}: ${remaining}"
    kill -9 ${remaining} 2>/dev/null || true
  fi
}

cleanup() {
  if [[ -n "${BACKEND_PID:-}" ]] && kill -0 "${BACKEND_PID}" 2>/dev/null; then
    kill "${BACKEND_PID}" 2>/dev/null || true
  fi
  if [[ -n "${FRONTEND_PID:-}" ]] && kill -0 "${FRONTEND_PID}" 2>/dev/null; then
    kill "${FRONTEND_PID}" 2>/dev/null || true
  fi
}

trap cleanup EXIT INT TERM

free_port "${BACKEND_PORT}"
free_port "${FRONTEND_PORT}"

if [[ ! -d "${ROOT_DIR}/frontend/node_modules" ]]; then
  echo "Installing frontend dependencies..."
  (cd "${ROOT_DIR}/frontend" && npm install)
fi

echo "Starting backend on http://127.0.0.1:${BACKEND_PORT}"
(
  cd "${ROOT_DIR}"
  APP_ENV=local \
  APP_NAME="BBI AI Migration Workbench API" \
  APP_VERSION="0.1.0" \
  PORT="${BACKEND_PORT}" \
  CORS_ALLOWED_ORIGINS="http://127.0.0.1:${FRONTEND_PORT},http://localhost:${FRONTEND_PORT},http://127.0.0.1:8080,http://localhost:8080" \
  ./scripts/start_sttm_backend_local.sh
) &
BACKEND_PID=$!

echo "Starting frontend on http://127.0.0.1:${FRONTEND_PORT}"
(
  cd "${ROOT_DIR}/frontend"
  PORT="${FRONTEND_PORT}" \
  BACKEND_DEV_ORIGIN="${BACKEND_DEV_ORIGIN}" \
  NEXT_PUBLIC_APP_ENV=local \
  npm run dev
) &
FRONTEND_PID=$!

EXIT_STATUS=0

while true; do
  if ! kill -0 "${BACKEND_PID}" 2>/dev/null; then
    if wait "${BACKEND_PID}"; then
      EXIT_STATUS=0
    else
      EXIT_STATUS=$?
    fi
    break
  fi

  if ! kill -0 "${FRONTEND_PID}" 2>/dev/null; then
    if wait "${FRONTEND_PID}"; then
      EXIT_STATUS=0
    else
      EXIT_STATUS=$?
    fi
    break
  fi

  sleep 1
done

cleanup

wait "${BACKEND_PID}" 2>/dev/null || true
wait "${FRONTEND_PID}" 2>/dev/null || true

exit "${EXIT_STATUS}"
