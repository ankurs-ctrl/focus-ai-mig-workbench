"""Attachments are read by role and intent into cited facts the agent uses as evidence."""
from __future__ import annotations

from app.agent_runs.attachment_facts import (
    conflicts,
    facts_for_target,
    mapping_evidence,
    read_attachment,
    records,
    transcript_turns,
    validate_facts,
    value_bindings,
)
from app.agent_runs.attachments import parse_attachment
from app.agent_tools.column_confidence import score_column


def _attachment(filename: str, content: bytes, attachment_id: str = "att_1") -> dict:
    extension, _mime, manifest, _ = parse_attachment(filename, content)
    return {"attachment_id": attachment_id, "filename": filename, "extension": extension,
            "content_hash": "h", "parsed_manifest": manifest}


def test_transcripts_keep_speaker_and_time_per_turn() -> None:
    turns = transcript_turns(
        "WEBVTT\n\n00:00:01.000 --> 00:00:04.000\n<v Dana>Households use the primary contact.</v>\n\n"
        "00:00:05.000 --> 00:00:07.000\nSam: Firm code is EN for this client.\n"
    )
    assert turns == [
        {"speaker": "Dana", "timestamp": "00:00:01.000", "text": "Households use the primary contact."},
        {"speaker": "Sam", "timestamp": "00:00:05.000", "text": "Firm code is EN for this client."},
    ]


def test_sql_attachments_become_lineage_join_value_and_filter_facts_without_a_model() -> None:
    attachment = _attachment("legacy.sql", b"""SET FirmCode = 'EN';
INSERT INTO DB.T.CONTACT (ID, NAME)
SELECT $FirmCode || c.ID AS ID, UPPER(c.NAME) AS NAME FROM DB.S.CONTACTS c
LEFT JOIN DB.S.BUSINESSES b ON b.ID = c.BUSINESS_ID WHERE c.DELETED = FALSE""")
    reading = read_attachment(attachment, request_text="", targets=[], complete=None)
    assert reading.role == "sample_sql" and reading.method == "sql_parser"
    kinds = {fact.kind for fact in reading.facts}
    assert {"column_rule", "join", "value_binding", "filter"} <= kinds
    name = next(fact for fact in reading.facts if fact.kind == "column_rule" and fact.target_column == "NAME")
    assert name.source_columns == ["DB.S.CONTACTS.NAME"] and name.evidence_id == "attachment:att_1#column NAME"
    assert value_bindings([fact.as_dict() for fact in reading.facts])[0] == {
        "name": "FirmCode", "value": "EN", "evidence_id": "attachment:att_1#variable FirmCode",
        "quote": "'EN'", "confidence": 0.8,
    }


def test_spreadsheet_specs_become_candidate_rows_with_cell_references() -> None:
    import io
    import openpyxl
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Contacts"
    sheet.append(["Salesforce field", "Legacy table", "Legacy column", "Logic"])
    sheet.append(["LastName", "CONTACTS", "LAST_NAME", "trim"])
    sheet.append(["Email", "EMAILS", "ADDRESS", "primary only"])
    buffer = io.BytesIO()
    workbook.save(buffer)
    attachment = _attachment("spec.xlsx", buffer.getvalue())

    def complete(_prompt, _schema):
        return {"role": "mapping_spec", "usage_intent": "Use this spec for CONTACT.", "related_targets": ["DB.T.CONTACT"],
                "header_roles": [{"header": "Salesforce field", "role": "target_column"},
                                 {"header": "Legacy table", "role": "source_table"},
                                 {"header": "Legacy column", "role": "source_column"},
                                 {"header": "Logic", "role": "rule"}],
                "facts": []}

    reading = read_attachment(attachment, request_text="map contacts", targets=["DB.T.CONTACT"], complete=complete)
    assert reading.role == "mapping_spec"
    rows = {fact.target_column: fact for fact in reading.facts}
    assert rows["LastName"].source_columns == ["CONTACTS.LAST_NAME"] and rows["LastName"].value == "trim"
    assert rows["Email"].section == "sheet Contacts row 3" and rows["Email"].target_table == "DB.T.CONTACT"


def test_model_facts_must_quote_the_attachment_or_they_are_dropped() -> None:
    attachment = _attachment("call.vtt", b"WEBVTT\n\n00:00:05.000 --> 00:00:07.000\nSam: Firm code is EN for this client.\n")
    items = records(attachment)
    kept, dropped = validate_facts([
        {"kind": "value_binding", "section": "turn 1", "quote": "Firm code is EN", "target_column": "FirmCode",
         "value": "EN", "confidence": 0.9},
        {"kind": "value_binding", "section": "turn 1", "quote": "Firm code is XY", "value": "XY", "confidence": 0.9},
        {"kind": "invented", "section": "turn 1", "quote": "Firm code is EN", "confidence": 0.9},
    ], items, attachment_id="att_1", filename="call.vtt")
    assert dropped == 2 and len(kept) == 1
    assert (kept[0].speaker, kept[0].timestamp) == ("Sam", "00:00:05.000")


def test_attachment_facts_raise_confidence_and_flag_conflicts() -> None:
    readings = [{"role": "mapping_spec", "related_targets": ["DB.T.CONTACT"], "facts": [{
        "kind": "column_rule", "evidence_id": "attachment:a#row 2", "filename": "spec.xlsx", "section": "row 2",
        "quote": "LastName | CONTACTS | LAST_NAME", "target_table": "", "target_column": "LASTNAME",
        "source_columns": ["CONTACTS.LAST_NAME"], "value": "", "confidence": 0.75,
    }]}]
    facts = facts_for_target(readings, "DB.T.CONTACT")
    assert facts and facts_for_target(readings, "DB.T.ACCOUNT") == []
    evidence = mapping_evidence(facts)
    agreeing = score_column({"target_column": "LASTNAME", "source_columns": ["DB.S.CONTACTS.LAST_NAME"], "confidence": 0.5},
                            evidence)
    alone = score_column({"target_column": "LASTNAME", "source_columns": ["DB.S.CONTACTS.LAST_NAME"], "confidence": 0.5}, [])
    assert agreeing["confidence"] > alone["confidence"] and agreeing["agreeing_evidence_ids"] == ["attachment:a#row 2"]
    [conflict] = conflicts([{"target_column": "LASTNAME", "status": "draft", "source_columns": ["DB.S.USERS.NAME"]}], facts)
    assert conflict["stated"] == ["CONTACTS.LAST_NAME"] and conflict["mapped"] == ["USERS.NAME"]
