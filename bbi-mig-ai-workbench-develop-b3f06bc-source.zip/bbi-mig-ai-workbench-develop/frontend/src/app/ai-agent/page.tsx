import AiAgentPage from "@/features/ai-agent/AiAgentPage";

export default function Page() {
  return <AiAgentPage />;
}
