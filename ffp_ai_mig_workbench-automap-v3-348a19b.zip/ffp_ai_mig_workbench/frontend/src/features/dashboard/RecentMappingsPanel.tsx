"use client";
import { AiaBox, AiaLoadingOverlay, AiaPaper } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowForwardRoundedIcon, EditNoteRoundedIcon } from '@/utils/icons';

import { CAPTION_SX, SECONDARY_TEXT_SX } from '@/config/typography-tokens';
import type { ProjectRecord, STTMRecord } from "@/services/projectService";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { clearOpenSttmNavigation } from "@/features/sttm/store/sttm-builder-slice";
import { openMappingInBuilder } from "@/features/mappings/load-mapping-workspace";

function formatCreatedOn(value?: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return `${date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  })} ${date.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

type RecentMappingsPanelProps = {
  projects: ProjectRecord[];
  sttms: STTMRecord[];
};

export default function RecentMappingsPanel({ projects, sttms }: RecentMappingsPanelProps) {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const openSttmStatus = useAppSelector((s) => s.sttmBuilder.openSttmStatus);
  const openSttmTargetPage = useAppSelector((s) => s.sttmBuilder.openSttmTargetPage);
  const [isOpening, setIsOpening] = useState(false);

  useEffect(() => {
    dispatch(clearOpenSttmNavigation());
  }, [dispatch]);

  // Same open flow as All Mappings: load the STTM, then navigate to the builder page it resolves to.
  useEffect(() => {
    if (!isOpening) return;
    if (openSttmStatus === "success" && openSttmTargetPage) {
      const targetPage = openSttmTargetPage;
      dispatch(clearOpenSttmNavigation());
      router.push(targetPage);
      setIsOpening(false);
    } else if (openSttmStatus === "error") {
      setIsOpening(false);
    }
  }, [dispatch, isOpening, openSttmStatus, openSttmTargetPage, router]);

  const projectById = new Map(projects.map((project) => [project.project_id, project]));
  const mappings = sttms
    .map((row) => {
      const project = projectById.get(row.project_id);
      if (!project) return null;
      return {
        id: row.sttm_id,
        projectId: row.project_id,
        title: row.sttm_name || row.target_table || `${project.project_name} STTM`,
        createdOn: formatCreatedOn(row.updated_at ?? row.created_at),
        sortTime: new Date(row.updated_at ?? row.created_at ?? 0).getTime(),
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
    .sort((a, b) => b.sortTime - a.sortTime)
    .slice(0, 5)
    .map(({ sortTime: _sortTime, ...row }) => row);

  const handleOpenMapping = (item: (typeof mappings)[number]) => {
    if (isOpening) return;
    setIsOpening(true);
    openMappingInBuilder(dispatch, { sttmId: item.id, projectId: item.projectId });
  };

  return (
    <AiaPaper
      elevation={0}
      className="flex min-h-[360px] flex-col rounded-[20px] border border-[#EEF2F7] bg-white p-6"
    >
      <AiaBox className="flex items-center justify-between">
        <AiaText sx={{ ...CAPTION_SX, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          Recent Mappings
        </AiaText>
        {mappings.length > 0 && (
          <AiaText
            sx={{
              ...CAPTION_SX,
              fontWeight: 600,
              px: 1.25,
              py: 0.25,
              borderRadius: "999px",
              border: "1px solid #DCE3EC",
              bgcolor: "#FAFBFC",
            }}
          >
            Latest {mappings.length}
          </AiaText>
        )}
      </AiaBox>

      <AiaBox className="mt-4 flex flex-col">
        {mappings.length === 0 ? (
          <AiaText sx={{ ...SECONDARY_TEXT_SX, color: "#6B7280" }}>
            No saved mappings yet.
          </AiaText>
        ) : (
          mappings.map((item, index) => (
            <AiaBox
              key={item.id}
              role="button"
              tabIndex={0}
              aria-label={`Open mapping ${item.title}`}
              onClick={() => handleOpenMapping(item)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  handleOpenMapping(item);
                }
              }}
              className={`group -mx-2 flex cursor-pointer items-center gap-3 rounded-xl px-2 py-3 ${
                index < mappings.length - 1 ? "border-b border-[#F1F5F9]" : ""
              }`}
              sx={{
                transition: "background-color 0.15s ease",
                "&:hover": { bgcolor: "#FAFBFC" },
                "&:focus-visible": { outline: "2px solid #DCE3EC", outlineOffset: "-2px" },
              }}
            >
              <AiaBox
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  p: 0.75,
                  borderRadius: "10px",
                  border: "1px solid #DCE3EC",
                  bgcolor: "#FFFFFF",
                  color: "#374151",
                }}
              >
                <EditNoteRoundedIcon sx={{ fontSize: 20 }} />
              </AiaBox>

              <AiaBox className="min-w-0 flex-1">
                <AiaText sx={{ ...SECONDARY_TEXT_SX, fontWeight: 600, color: "var(--aia-text-color)" }}>
                  {item.title}
                </AiaText>
                <AiaText sx={{ ...CAPTION_SX, mt: 0.5 }}>
                  Created on {item.createdOn}
                </AiaText>
              </AiaBox>

              <ArrowForwardRoundedIcon
                className="opacity-0 transition-opacity group-hover:opacity-100"
                sx={{ fontSize: 18, color: "#6B7280", flexShrink: 0 }}
              />
            </AiaBox>
          ))
        )}
      </AiaBox>
      <AiaLoadingOverlay
        open={isOpening && openSttmStatus !== "error"}
        label="Opening mapping…"
      />
    </AiaPaper>
  );
}
