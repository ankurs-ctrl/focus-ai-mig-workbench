"""Chat progress: host code records facts; only the supervisor writes chat text."""
from __future__ import annotations

from types import SimpleNamespace

from app.agent_runtime.progress import ProgressReporter


class _Clock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


def _reporter(heartbeat: float = 120.0, gap: float = 45.0):
    events: list[tuple[str, str, dict]] = []
    clock = _Clock()
    reporter = ProgressReporter(lambda kind, _status, summary, data: events.append((kind, summary, data)),
                                "run-1", heartbeat_seconds=heartbeat, min_gap_seconds=gap, clock=clock)
    return reporter, events, clock


def _updates(events):
    return [(summary, data) for kind, summary, data in events if kind == "assistant.update"]


def test_facts_never_become_chat_text_on_their_own() -> None:
    reporter, events, clock = _reporter()
    reporter.plan_targets(["DB.T.HOUSEHOLD", "DB.T.CALLS"])
    assert reporter.milestone("DB.T.HOUSEHOLD", "done", mapped_columns=37, target_columns=37)
    assert not reporter.milestone("DB.T.HOUSEHOLD", "done", mapped_columns=37, target_columns=37)
    clock.now += 600
    assert not reporter.narrate()  # no narrator attached: nothing is written for the user
    assert _updates(events) == []
    facts = [data for kind, _, data in events if kind == "automap.progress"]
    assert facts[0]["fact"] == {"target": "HOUSEHOLD", "phase": "done", "mapped_columns": 37, "target_columns": 37}
    assert facts[0]["progress"]["targets"] == {"HOUSEHOLD": "done", "CALLS": "queued"}


def test_supervisor_narrates_grouped_facts_after_the_min_gap() -> None:
    reporter, events, clock = _reporter(gap=45)
    seen: list[dict] = []

    def narrator(update):
        seen.append(update)
        return "HOUSEHOLD and CALLS are ready; I'm compiling BIZ_ACCOUNTS next."

    reporter.plan_targets(["DB.T.HOUSEHOLD", "DB.T.CALLS", "DB.T.BIZ_ACCOUNTS"])
    reporter._narrator = narrator  # attach without the background thread
    reporter.milestone("DB.T.HOUSEHOLD", "done", preview_rows=20)
    clock.now += 10
    assert not reporter.narrate()  # inside the min gap
    reporter.milestone("DB.T.CALLS", "done", preview_rows=12)
    clock.now += 40
    assert reporter.narrate()
    assert [fact["target"] for fact in seen[0]["new_events"]] == ["HOUSEHOLD", "CALLS"]
    text, data = _updates(events)[-1]
    assert text.startswith("HOUSEHOLD and CALLS are ready")
    assert data["source"] == "supervisor" and data["progress"]["done"] == 2
    # Narrated facts are consumed.
    clock.now += 60
    assert not reporter.narrate()


def test_heartbeat_asks_the_supervisor_after_a_quiet_interval() -> None:
    reporter, events, clock = _reporter(heartbeat=120, gap=45)
    reasons: list[str] = []
    reporter.plan_targets(["DB.T.HOUSEHOLD"])
    reporter.set_phase("DB.T.HOUSEHOLD", "mapping")
    reporter._narrator = lambda update: reasons.append(update["reason"]) or "HOUSEHOLD is still mapping, 2 minutes in."
    clock.now += 100
    assert not reporter.narrate()
    clock.now += 21
    assert reporter.narrate() and reasons == ["heartbeat"]
    assert _updates(events)[-1][1]["progress"]["kind"] == "heartbeat"
    # Any supervisor update passing through the reporter resets the quiet timer.
    clock.now += 200
    reporter("assistant.update", "running", "Mapping HOUSEHOLD.", {"text": "Mapping HOUSEHOLD."})
    assert not reporter.overdue


def test_skip_is_respected_and_no_heartbeat_when_everything_finished() -> None:
    reporter, events, clock = _reporter(heartbeat=30, gap=5)
    reporter.plan_targets(["DB.T.CALLS"])
    reporter._narrator = lambda _update: None
    reporter.milestone("DB.T.CALLS", "done")
    clock.now += 10
    assert not reporter.narrate()
    clock.now += 500
    assert not reporter.narrate()
    assert _updates(events) == []


def test_reporter_delegates_writer_methods() -> None:
    flushed = []
    reporter = ProgressReporter(lambda *_args: None, "run-1")
    reporter._trace = SimpleNamespace(flush=lambda: flushed.append(True))  # type: ignore[assignment]
    reporter.flush()
    assert flushed == [True]


def test_partition_state_changes_become_structured_facts() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.migration_workflow.scheduler import Partition, PartitionState

    reporter, events, _ = _reporter()
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler.progress = reporter
    state = {"run_id": "run-1", "manifest": [{"mapping_key": "hh", "target_table": "DB.T.HOUSEHOLD"}]}
    handler._partition_milestone(state, Partition(
        partition_id="hh:map:0", mapping_key="hh", columns=["A", "B", "C"], state=PartitionState.COMPLETED,
        result={"target_columns": ["A", "B", "C"], "mapped_target_columns": ["A", "B"]}))
    compile_running = Partition(partition_id="hh:compile", mapping_key="hh", stage="compile",
                                state=PartitionState.RUNNING)
    handler._partition_milestone(state, compile_running)
    handler._partition_milestone(state, compile_running.model_copy(update={
        "state": PartitionState.NEEDS_REVIEW,
        "result": {"target_columns": ["A", "B", "C"], "mapped_target_columns": ["A", "B"],
                   "unresolved_target_columns": ["C"],
                   "sql_validation": {"compile_valid": True, "preview_row_count": 20,
                                      "population_rules": [{"predicate": "COALESCE(c.DELETED, 0) = 0"}]}}}))
    facts = [data["fact"] for kind, _, data in events if kind == "automap.progress"]
    assert facts[0] == {"target": "HOUSEHOLD", "phase": "compiling", "mapped_columns": 2, "target_columns": 3}
    assert facts[1]["phase"] == "needs_review" and facts[1]["unresolved_columns"] == ["C"]
    assert facts[1]["population_rules"] == ["COALESCE(c.DELETED, 0) = 0"]
    assert _updates(events) == []


def test_supervisor_model_writes_the_update_and_skip_or_cap_suppresses_it() -> None:
    import threading
    from app.agent_runtime.deepagents_runtime import NARRATION_PROMPT, DeepAgentsRuntime
    from app.agent_runtime.execution import ExecutionBudget

    replies = iter(["[PROGRESS] HOUSEHOLD is ready with 20 preview rows; CALLS is compiling.", "SKIP"])
    prompts: list[list[dict]] = []

    class _Model:
        def invoke(self, messages):
            prompts.append(messages)
            return SimpleNamespace(content=next(replies))

    runtime = object.__new__(DeepAgentsRuntime)
    runtime._model = _Model()
    runtime._budget = ExecutionBudget(model_limit=5, tool_limit=5)
    runtime._progress_lock = threading.Lock()
    runtime._active_invocation = SimpleNamespace(prompt="Map all TMD targets")
    runtime._workbench = SimpleNamespace(_settings=SimpleNamespace(migration_agent_progress_narration_limit=2))
    runtime._narrations = 0
    update = {"new_events": [{"target": "HOUSEHOLD", "phase": "done"}], "status": {}, "reason": "milestones"}
    assert runtime._narrate_progress(update) == "HOUSEHOLD is ready with 20 preview rows; CALLS is compiling."
    assert prompts[0][0]["content"] == NARRATION_PROMPT
    assert "Give concise, truthful progress messages" in NARRATION_PROMPT
    assert runtime._narrate_progress(update) is None  # SKIP
    assert runtime._narrate_progress(update) is None  # over the cap: the model is not called
    assert len(prompts) == 2


def test_heartbeat_during_research_uses_recent_activity_and_needs_something_verified() -> None:
    reporter, events, clock = _reporter(heartbeat=120)
    seen: list[dict] = []
    reporter._narrator = lambda update: seen.append(update) or "I've read 12 source contracts; still comparing sources."
    clock.now += 200
    assert not reporter.narrate()  # nothing verified yet: no heartbeat
    reporter("trace.action.completed", "succeeded", "Read 7 columns from SCH_TMD_SOURCE.NOTE_ASSOCIATIONS.", {})
    assert reporter.narrate()
    assert seen[0]["reason"] == "heartbeat"
    assert seen[0]["recent_activity"] == ["Read 7 columns from SCH_TMD_SOURCE.NOTE_ASSOCIATIONS."]
    assert _updates(events)[-1][0].startswith("I've read 12 source contracts")


def test_the_narrator_is_told_whether_the_executor_has_started() -> None:
    reporter, _events, clock = _reporter(heartbeat=120)
    stages: list[str] = []
    reporter._narrator = lambda update: stages.append(update["stage"]) or "text"
    reporter("trace.action.completed", "succeeded", "Prepared migration evidence for CALLS.", {})
    clock.now += 130
    reporter.narrate()
    reporter.plan_targets(["DB.T.CALLS"])
    reporter.milestone("DB.T.CALLS", "mapping")
    clock.now += 60
    reporter.narrate()
    assert stages == ["research", "executing"]
