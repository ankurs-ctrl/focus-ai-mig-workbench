"""Guidance is separate from concrete options; only known evidence can prefill a join."""
from __future__ import annotations

import hashlib
import json
import re

from app.schema.sttm_builder import JoinRecommendation, MappingSuggestion


def concrete_option(option):
    return bool(option.source_attributes or (option.mapping_mode == 'constant' and option.constant_value is not None)
                or (option.mapping_mode == 'attribute' and option.attribute_name)
                or (option.preprocessing_rule and option.preprocessing_rule.strip().upper() not in {'DIRECT', 'IDENTITY', 'VALUE', 'CUSTOM'}))


def suggestion_kind(message):
    text = message.lower()
    if any(word in text for word in ('join', 'relationship', 'lookup')): return 'relationship'
    if any(word in text for word in ('firm value', 'placeholder', 'project value')): return 'value'
    if any(word in text for word in ('null rate', 'coverage', 'empty', 'entirely null')): return 'source_data'
    if any(word in text for word in ('business rule', 'business input', 'decision')): return 'business_rule'
    if 'outside' in text or 'selection' in text: return 'outside_selection'
    return 'evidence'


def known_reference_nodes(req, references):
    from sqlglot import parse_one, exp
    def parts(value):
        try:
            column = parse_one(value, read='snowflake')
            if not isinstance(column, exp.Column): return None
            return tuple(part.name if part.args.get('quoted') else part.name.upper() for part in column.parts)
        except Exception:
            return None
    nodes = req.context.relation_graph.nodes if req.context.relation_graph else []
    result = []
    for reference in references:
        key = parts(reference)
        matches = [node for node in nodes if reference == node.relation_id or (key and any(
            owner and (key == owner or key[:-1] == owner)
            for owner in (parts(node.alias), parts(node.table.qualified_name) if node.table else None)))]
        if len(matches) == 1 and matches[0].relation_id not in result: result.append(matches[0].relation_id)
    return result


def reviewed_join(req, recommendation, references=()):
    graph = req.context.relation_graph
    nodes = {node.relation_id: node for node in graph.nodes} if graph else {}
    left = recommendation.left_relation_id if recommendation.left_relation_id in nodes else None
    right = recommendation.right_relation_id if recommendation.right_relation_id in nodes else None
    referenced = known_reference_nodes(req, references)
    if not left and referenced: left = referenced[0]
    if not right: right = next((identity for identity in referenced if identity != left), None)
    # Conditions/types supplied only by the model are not evidence. Use the
    # current authorized relationship inventory; otherwise leave them unset.
    known = next((edge for edge in (graph.edges if graph else [])
                  if {edge.left_relation_id, edge.right_relation_id} == {left, right}), None) if left and right else None
    if known:
        conditions = [condition.model_dump(mode='json') for condition in known.conditions]
        conditions = [{key: value for key, value in row.items() if isinstance(value, str)} for row in conditions]
        join_type=str(known.join_type).upper().replace(' OUTER','')
        return JoinRecommendation(left_relation_id=known.left_relation_id, right_relation_id=known.right_relation_id,
                                  join_type=join_type if join_type in {'INNER','LEFT','RIGHT','FULL'} else None, conditions=conditions)
    return JoinRecommendation(left_relation_id=left, right_relation_id=right)


def row_suggestions(req, target, mapping, empty_options):
    result = list(mapping.suggestions)
    if empty_options or mapping.unmatched_reason:
        message = mapping.unmatched_reason or 'No complete mapping option was found. Review the source coverage and required business inputs.'
        result.append(MappingSuggestion(kind=suggestion_kind(message), message=message,
                      source_references=list(mapping.candidate_source_attributes)))
    seen = set()
    clean = []
    other_targets = {item.target_attribute.upper() for item in req.data.attributes or []} - {target.upper()}
    for item in result:
        if any(re.search(r'(?<![A-Z0-9_])' + re.escape(name) + r'(?![A-Z0-9_])', item.message.upper()) for name in other_targets) and target.upper() not in item.message.upper():
            continue
        join = reviewed_join(req, item.join_recommendation or JoinRecommendation(), item.source_references) if item.kind == 'relationship' or item.join_recommendation else None
        identity = json.dumps([item.kind, item.message.strip(), item.source_references,
                               join.model_dump(mode='json') if join else None], sort_keys=True)
        if identity in seen: continue
        seen.add(identity)
        clean.append(item.model_copy(update={'suggestion_id': hashlib.sha256(identity.encode()).hexdigest()[:24],
                                             'join_recommendation': join}))
    return clean
