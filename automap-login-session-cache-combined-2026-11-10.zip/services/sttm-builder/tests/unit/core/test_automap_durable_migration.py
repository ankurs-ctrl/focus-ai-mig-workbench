"""Offline migration guards and release-profile consistency."""
from pathlib import Path
import json
import pytest
from scripts.prepare_automap_durable_runs import prepare
from tests.unit.core.test_prepare_parallel_automap_infra import profile,save


def v2_profile(tmp_path):
    doc=profile('UAT',capacity=12)
    s=doc['settings'];s.update(AUTOMAP_DURABLE_RUNS_V2=True,AUTOMAP_RECOVERY_CAPACITY=4)
    legacy=s['AUTOMAP_PARALLEL_PERMIT_TABLE_FQN'];s['AUTOMAP_PARALLEL_PERMIT_TABLE_FQN']+='_V2'
    return save(tmp_path,doc),legacy


def test_migration_has_twelve_foreground_four_recovery_and_no_legacy_reset(tmp_path):
    path,legacy=v2_profile(tmp_path)
    sql=prepare(path,'UAT',legacy_table=legacy,exclusive=True,retired_dispatchers=True)
    assert 'ROWCOUNT=>16' in sql
    assert 'n.ID=12+l.SLOT_ID' in sql
    assert 'V2_ALREADY_MIGRATED_AND_VALIDATED' in sql
    assert 'l.OWNER_TOKEN' in sql and 'COALESCE(l.FENCE,0)' in sql
    assert 'SHA2(OWNER_TOKEN,256)' in sql and 'LEGACY_IMPORT' in sql
    assert 'CURRENT_ACCOUNT_NAME()' in sql and 'CURRENT_ROLE()' in sql
    assert f'UPDATE {legacy} ' not in sql and f'DELETE FROM {legacy}' not in sql
    assert 'TRUNCATE' not in sql and 'OR REPLACE' not in sql
    assert "STATE NOT IN (''FREE'',''QUARANTINED'')" in sql
    assert 'COMMIT;' in sql and 'ROLLBACK;' in sql


@pytest.mark.parametrize('exclusive,retired',[(False,False),(True,False),(False,True)])
def test_migration_requires_quiescence_not_a_live_reset(tmp_path,exclusive,retired):
    path,legacy=v2_profile(tmp_path)
    with pytest.raises(ValueError):prepare(path,'UAT',legacy_table=legacy,exclusive=exclusive,retired_dispatchers=retired)


def test_no_shrink_or_reuse_of_legacy_table(tmp_path):
    path,legacy=v2_profile(tmp_path)
    with pytest.raises(ValueError):prepare(path,'UAT',legacy_table=legacy,legacy_capacity=5,exclusive=True,retired_dispatchers=True)
    doc=json.loads(path.read_text());doc['settings']['AUTOMAP_PARALLEL_PERMIT_TABLE_FQN']=legacy;path.write_text(json.dumps(doc))
    with pytest.raises(ValueError):prepare(path,'UAT',legacy_table=legacy,exclusive=True,retired_dispatchers=True)


def test_release_profile_executes_twelve_with_bounded_recovery():
    root=Path(__file__).resolve().parents[5]
    s=json.loads((root/'infra/snowflake/env/parallel.uat.durable-v2.json').read_text())['settings']
    assert s['AUTOMAP_DURABLE_RUNS_V2'] is True
    assert s['AUTO_MAP_PIPELINE_V2'] is True
    assert s['AUTOMAP_PARALLEL_POOL_CAPACITY']==12
    assert s['AUTOMAP_RECOVERY_CAPACITY']==4
    assert s['AUTOMAP_FAST_MAX_IN_FLIGHT']==s['AUTO_MAPPING_WORKER_MAX_CONCURRENCY']==s['AUTO_MAPPING_PROXY_MAX_IN_FLIGHT']==12
    assert s['AUTOMAP_PARALLEL_PERMIT_TABLE_FQN'].endswith('_V2')
    assert s['AUTOMAP_RUN_SECONDS'] < s['AUTOMAP_FAST_BATCH_SECONDS']


def test_readonly_validation_never_creates_updates_or_resets_inventory(tmp_path):
    path,legacy=v2_profile(tmp_path)
    sql=prepare(path,'UAT',stage='validate')
    assert 'V2_INVENTORY_VERIFIED' in sql
    assert '_CONTROL' in sql and 'row_count <> 64' in sql
    assert '_EVENTS WHERE 1=0' in sql and 'REQUEST_ARCHIVE_REF IS NULL' in sql
    assert 'row_count <> 16' in sql
    for mutation in ('CREATE TABLE','UPDATE ', 'INSERT INTO', 'DELETE FROM', 'TRUNCATE'):
        assert mutation not in sql
