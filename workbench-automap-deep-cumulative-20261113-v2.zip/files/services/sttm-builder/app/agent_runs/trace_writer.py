from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Any, Callable

from app.agent_runs.models import AgentRun, AgentRunEvent
from app.agent_runs.service import AgentRunService


logger = logging.getLogger(__name__)


class _ControlWrite:
    __slots__ = ("operation",)

    def __init__(self, operation: Callable[[], None]) -> None:
        self.operation = operation


class DurableTraceWriter:
    """Persist runtime trace events in ordered transactional batches.

    Agent decisions and tool execution must not wait for several Snowflake
    round trips per lifecycle event. This writer owns a dedicated repository
    session, preserves FIFO order, and exposes an explicit flush boundary before
    terminal run events are committed.
    """

    def __init__(
        self,
        service: AgentRunService,
        run: AgentRun,
        *,
        batch_size: int = 50,
        flush_interval_seconds: float = 0.15,
    ) -> None:
        self._service = service
        self._run = run
        self._batch_size = max(1, batch_size)
        self._flush_interval_seconds = max(0.01, flush_interval_seconds)
        self._queue: queue.Queue[AgentRunEvent | _ControlWrite | None] = queue.Queue()
        self._failure: BaseException | None = None
        self._closed = False
        self._usage_provider: Callable[[], dict[str, int]] | None = None
        self._thread = threading.Thread(
            target=self._run_writer,
            name=f"migration-trace-writer-{run.run_id}",
            daemon=True,
        )
        self._thread.start()

    def set_usage_provider(self, provider: Callable[[], dict[str, int]]) -> None:
        self._usage_provider = provider

    def __call__(self, event_type: str, status: str, summary: str, data: dict[str, Any]) -> None:
        if self._closed:
            raise RuntimeError("Durable trace writer is closed")
        if self._failure is not None:
            raise RuntimeError("Durable trace writer failed") from self._failure
        if self._usage_provider is not None:
            data = {**data, "budget_usage": self._usage_provider()}
        self._queue.put(
            self._service.build_event(
                self._run,
                event_type,
                status,
                summary,
                data=data,
                subject_keys=[str(value) for value in data.get("subject_keys") or []],
                artifact_refs=[str(value) for value in data.get("artifact_refs") or []],
                trace_id=str(data.get("trace_id") or "") or None,
                parent_event_id=str(data.get("parent_event_id") or "") or None,
                span_id=str(data.get("span_id") or "") or None,
            )
        )
        if event_type == "model.started" and self._usage_provider is not None:
            # Commit the attempt before dispatch so a killed worker cannot
            # restart with an artificially unused model-call allowance.
            self.flush()

    def submit(self, operation: Callable[[], None]) -> None:
        """Run a control-plane write on this writer's session, FIFO with events.

        The operation owns its error handling; a failure is logged and does not
        poison the event stream. ``flush`` waits for submitted writes too.
        """
        if self._closed:
            raise RuntimeError("Durable trace writer is closed")
        self._queue.put(_ControlWrite(operation))

    def flush(self, timeout: float = 30.0) -> None:
        """Wait until every queued event and control write is committed.

        ``timeout`` bounds a stall, not total work: a large backlog that keeps
        committing is waited for, while a writer that stops making progress
        for ``timeout`` seconds raises.
        """
        last_remaining = self._queue.unfinished_tasks
        deadline = time.monotonic() + timeout
        while self._queue.unfinished_tasks:
            if self._failure is not None:
                raise RuntimeError("Durable trace writer failed") from self._failure
            remaining = self._queue.unfinished_tasks
            if remaining < last_remaining:
                last_remaining = remaining
                deadline = time.monotonic() + timeout
            if time.monotonic() >= deadline:
                raise TimeoutError("Timed out while flushing durable trace events")
            time.sleep(0.01)

    @property
    def stopped(self) -> bool:
        """True once the writer thread no longer uses the repository session."""
        return not self._thread.is_alive()

    def close(self) -> None:
        if self._closed:
            return
        try:
            self.flush()
        finally:
            self._closed = True
            self._queue.put(None)
            self._thread.join(timeout=5)
        if self._failure is not None:
            raise RuntimeError("Durable trace writer failed") from self._failure

    def _run_control_write(self, item: _ControlWrite) -> None:
        try:
            item.operation()
        except BaseException:
            logger.exception("Control-plane write failed for run %s", self._run.run_id)
        finally:
            self._queue.task_done()

    def _run_writer(self) -> None:
        while True:
            first = self._queue.get()
            if first is None:
                self._queue.task_done()
                return
            if isinstance(first, _ControlWrite):
                self._run_control_write(first)
                continue
            batch = [first]
            deadline = time.monotonic() + self._flush_interval_seconds
            stop_after_batch = False
            deferred: _ControlWrite | None = None
            while len(batch) < self._batch_size:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                try:
                    item = self._queue.get(timeout=remaining)
                except queue.Empty:
                    break
                if item is None:
                    self._queue.task_done()
                    stop_after_batch = True
                    break
                if isinstance(item, _ControlWrite):
                    # Preserve FIFO: events queued before the write commit first.
                    deferred = item
                    break
                batch.append(item)
            try:
                self._service.repository.append_events(batch)
            except BaseException as exc:  # surfaced synchronously at flush/next emit
                self._failure = exc
                logger.exception("Durable trace batch failed for run %s", self._run.run_id)
            finally:
                for _ in batch:
                    self._queue.task_done()
            if deferred is not None:
                self._run_control_write(deferred)
            if stop_after_batch:
                return
