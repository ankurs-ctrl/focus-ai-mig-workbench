"""Recovery and admission contracts; no client operations or credentials."""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import time

import pytest

from app.core import automap_admission as admission
from app.core.automap_recovery import RecoveryRetry, recover_archived_operation
from app.core.automap_fast_transport import RuntimeFailureKind, _runtime_failure_kind
from app.core.automap_runtime import ReconciliationStatus
from tests.unit.core.test_automap_admission import Database, ACCOUNT, EPOCH, TABLE, IDENTITY
from tests.test_automap_runtime import harness, recovery_case  # genuine runtime/GET/SQL fixture


def test_quarantined_production_pool_fails_promptly_without_any_update():
    database = Database(4)
    for row in database.rows:
        row.update(STATE='QUARANTINED', OWNER_TOKEN='old-operation', FENCE=11)
    before = deepcopy(database.rows)
    pool = admission.SnowflakeCallAdmission(session_factory=database.factory, table=TABLE,
        account_namespace=ACCOUNT, pool_epoch=EPOCH, capacity=4, fail_on_quarantined_pool=True)
    with pytest.raises(admission.AdmissionCapacityBlocked):
        pool.try_claim(IDENTITY)
    assert database.rows == before
    assert not any('UPDATE ' in str(s.commands) for s in database.sessions)
    assert _runtime_failure_kind(admission.AdmissionCapacityBlocked()) == RuntimeFailureKind.CAPACITY_BLOCKED


def test_held_pool_keeps_waiting_and_never_takes_over_expired_work():
    database = Database(4)
    for row in database.rows:
        row.update(STATE='HELD', OWNER_TOKEN='old-operation', LEASE_EXPIRES_AT=0)
    pool = admission.SnowflakeCallAdmission(session_factory=database.factory, table=TABLE,
        account_namespace=ACCOUNT, pool_epoch=EPOCH, capacity=4, fail_on_quarantined_pool=True)
    assert pool.try_claim(IDENTITY) is None
    assert all(row['STATE']=='HELD' for row in database.rows)


class HealthSession:
    def __init__(self, rows, account=ACCOUNT):
        self.rows, self.account, self.commands = rows, account, []

    def sql(self, query, params=None):
        self.commands.append(query)
        session = self
        class Result:
            def collect(self, **kwargs):
                if query.startswith('SELECT CURRENT_'):
                    return [dict(ACCOUNT_NAMESPACE=session.account, TRANSACTION_ID=None)]
                return session.rows
        return Result()


def health_pool(rows, account=ACCOUNT):
    session = HealthSession(rows, account)
    @contextmanager
    def factory():
        yield session
    return admission.SnowflakeCallAdmission(session_factory=factory, table=TABLE,
        account_namespace=ACCOUNT, pool_epoch=EPOCH, capacity=2), session


def test_health_is_read_only_and_does_not_disclose_ownership():
    rows = [dict(SLOT_ID=i, POOL_EPOCH=EPOCH, STATE='QUARANTINED', FENCE=5,
        OWNER_MISSING=False, EXPIRED=True, AGE_SECONDS=30*i) for i in (1,2)]
    pool, session = health_pool(rows)
    assert pool.health() == dict(capacity=2,free=0,held=0,quarantined=2,
        expired_held=0,oldest_quarantine_seconds=60)
    assert all(query.startswith('SELECT ') for query in session.commands)


@pytest.mark.parametrize('mutation', ['account','duplicate','epoch','owner','age'])
def test_health_refuses_invalid_or_foreign_inventory(mutation):
    rows=[dict(SLOT_ID=i, POOL_EPOCH=EPOCH, STATE='FREE', FENCE=0,
        OWNER_MISSING=True, EXPIRED=False, AGE_SECONDS=0) for i in (1,2)]
    if mutation=='duplicate': rows[1]['SLOT_ID']=1
    if mutation=='epoch': rows[1]['POOL_EPOCH']='other'
    if mutation=='owner': rows[1]['OWNER_MISSING']=False
    if mutation=='age': rows[1]['AGE_SECONDS']=float('nan')
    pool,session=health_pool(rows, 'OTHER.ACCOUNT' if mutation=='account' else ACCOUNT)
    with pytest.raises(admission.AdmissionInvariantError):pool.health()
    assert all(query.startswith('SELECT ') for query in session.commands)


def archived_request(case, **changes):
    req=case.request
    value=dict(protocol='automap_fast_model_request_v1',job_id=case.permit.identity.job_id,
        agent_fqn=case.reference.agent_fqn,request_digest=admission.request_digest(req),
        snapshot_archive_ref=case.snapshot_ref,request=dict(scope=asdict(req.scope),
        generation=req.generation,shard_id=req.shard_id,target_ids=list(req.target_ids),
        record_ids=list(req.record_ids),message=req.message,output_budget=asdict(req.output_budget)))
    value.update(changes)
    text=json.dumps(dict(scope=asdict(req.scope),generation=req.generation,value=value))
    ref=hashlib.sha256(text.encode()).hexdigest()
    case.bundle.archive.with_deadline(time.monotonic()+30).put(ref,text)
    return ref


@pytest.mark.parametrize('status', ['completed','error','timed_out','cancelled'])
def test_archived_recovery_uses_only_get_and_releases_after_durable_audit(harness,recovery_case,status):
    case=recovery_case
    payload=json.loads(case.data['messages'][1]['message_payload']);payload['status']=status
    case.data['messages'][1]['message_payload']=json.dumps(payload)
    ref=archived_request(case)
    result=recover_archived_operation(case.bundle,permit=case.permit,request_archive_ref=ref,
        retired_dispatcher=True,deadline=time.monotonic()+30)
    assert result.status==ReconciliationStatus.RELEASED
    assert len(case.sent)==1 and case.sent[0].method=='GET'
    assert result.evidence_ref
    again=recover_archived_operation(case.bundle,permit=case.permit,request_archive_ref=ref,
        retired_dispatcher=True,deadline=time.monotonic()+30)
    assert again.status==ReconciliationStatus.STALE_PERMIT
    assert len(case.sent)==1


@pytest.mark.parametrize('change', [dict(job_id='wrong'),dict(agent_fqn='OTHER.DB.AGENT'),dict(request_digest='0'*64)])
def test_archived_recovery_rejects_mismatches_before_remote_get(harness,recovery_case,change):
    case=recovery_case;ref=archived_request(case,**change)
    result=recover_archived_operation(case.bundle,permit=case.permit,request_archive_ref=ref,
        retired_dispatcher=True,deadline=time.monotonic()+30)
    assert result.status==ReconciliationStatus.REJECTED
    assert not case.sent


def test_active_dispatcher_cannot_be_recovered(harness,recovery_case):
    case=recovery_case
    with pytest.raises(ValueError):
        recover_archived_operation(case.bundle,permit=case.permit,request_archive_ref='0'*64,
            retired_dispatcher=False,deadline=time.monotonic()+30)
    assert not case.sent


def test_backoff_is_bounded_and_serializable_across_restarts():
    retry=RecoveryRetry()
    for attempt in range(20):
        new=retry.after_failure(1000,jitter=1)
        assert 0<new.next_attempt_at-1000<=3600
        retry=RecoveryRetry(**json.loads(json.dumps(asdict(new))))
    assert retry.attempts==20
