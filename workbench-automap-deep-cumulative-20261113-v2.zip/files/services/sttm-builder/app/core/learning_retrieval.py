"""Learning Retrieval Service for AGT_SOURCE_MAPPING integration.

This service retrieves and ranks FIR learnings, similar mappings, and
correction history to provide comprehensive learning context to agents.
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import AbstractContextManager
from contextvars import ContextVar
from typing import Callable
from typing import Any

from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.mapping_contracts import optional_identifier, published_expression
from app.core.agent_learning_service import AgentLearningService, AgentLearning
from app.core.exceptions import ContextPrecedentUnavailableError
from app.core.performance import increment, observe
from app.core.target_mapping_patterns import TargetMappingPatternService, compact_candidate_for_agent
from app.core.derived_source import PLACEHOLDER_DESCRIPTION
from app.schema.sttm_builder import (
    LearningContext,
    FIRLearningItem,
    SimilarMappingItem,
    SemanticLearningItem,
    MappingIntentItem,
    ProjectContextItem,
    CrossProjectPatternItem,
    CorrectionHistoryItem,
    MappingPrecedentContext,
)

logger = logging.getLogger(__name__)
_RETRIEVAL_ERRORS: ContextVar[list[str] | None] = ContextVar("retrieval_errors", default=None)


def _record_retrieval_error(exc: Exception) -> None:
    errors = _RETRIEVAL_ERRORS.get()
    if errors is not None:
        errors.append(type(exc).__name__)

_LEARNING_CACHE_IDLE_SECONDS = 3600.0
_LEARNING_DURABLE_REVALIDATE_SECONDS = 86400
_LEARNING_CACHE_LOCK = threading.Lock()
_LEARNING_CACHE: dict[str, tuple[float, LearningContext]] = {}
_LEARNING_BUILD_LOCKS: dict[str, threading.Lock] = {}
# Short-lived so another replica's publish is visible within seconds; the
# local replica clears it immediately through invalidate_learning_context_cache.
_FIR_EPOCH_TTL_SECONDS = 30.0
_FIR_EPOCH_CACHE: dict[str, tuple[float, str]] = {}
# Source CRM and logical target rarely change, so a few minutes is safe.
_MAPPING_SCOPE_TTL_SECONDS = 300.0
_MAPPING_SCOPE_CACHE: dict[str, tuple[float, tuple[str | None, str | None]]] = {}
# Prepared learning contexts are immutable per handle; every warm chat hydrates one.
_HANDLE_CACHE: dict[tuple[str, str, str], tuple[float, LearningContext]] = {}
_HANDLE_CACHE_MAX = 256


def invalidate_learning_context_cache() -> None:
    with _LEARNING_CACHE_LOCK:
        _LEARNING_CACHE.clear()
        _FIR_EPOCH_CACHE.clear()
        _MAPPING_SCOPE_CACHE.clear()
        _HANDLE_CACHE.clear()


_DEPENDENCY_KEYS = (
    "name", "alias", "output", "purpose", "path", "condition", "relationship", "join_type",
    "left_table", "right_table", "left_column", "right_column", "tables_referenced", "output_columns",
    "grain_evidence",
)
_SOURCE_MATCH = {1: "exact_sources", 2: "same_source_system", 3: "semantic_roles", 4: "rule_only"}


def _brief(value: Any, *, text: int = 240, items: int = 12) -> Any:
    """Scalars trimmed, lists shortened, dicts reduced to their naming keys: no SQL bodies."""
    if isinstance(value, str):
        return value if len(value) <= text else value[:text] + "..."
    if isinstance(value, list):
        return [_brief(item, text=text, items=items) for item in value[:items]]
    if isinstance(value, dict):
        return {key: _brief(value[key], text=text, items=items)
                for key in _DEPENDENCY_KEYS if value.get(key) not in (None, "", [], {})}
    return value


def _compact_pattern(candidate: Any) -> dict[str, Any]:
    """One target-column recipe with the signals a specialist weighs, and nothing else.

    ``mode``, ``contradiction_count`` and the dependency lists are the same
    fields FIR uses to decide a pattern needs escalation, so the specialist sees
    what is complex without a second model pass. Dependencies keep their names
    and outputs, never their SQL, so one target stays a few thousand tokens.
    """
    pattern = candidate.pattern
    recipe = pattern.mapping_recipe or {}
    provenance = pattern.provenance or {}
    return {
        key: value for key, value in {
            "pattern_id": pattern.pattern_id,
            "target_column": pattern.target_contract.get("target_column"),
            "learned_target_column": pattern.target_contract.get("learned_target_column"),
            "scope": pattern.scope,
            "vendor_family": pattern.source_system_profile.get("vendor_family"),
            "mode": recipe.get("mode"),
            "source_dependencies": list(recipe.get("source_dependencies") or [])[:12],
            "expression": _brief(recipe.get("expression"), text=1200),
            "placeholder": recipe.get("placeholder"),
            "natural_language_rule": _brief(recipe.get("natural_language_rule"), text=400),
            "relationship_dependencies": _brief(list(pattern.relationship_dependencies or []), items=4),
            "derived_dependencies": _brief(list(pattern.derived_dependencies or []), items=4),
            "business_rationale": _brief(pattern.business_rationale, text=400),
            "confidence": pattern.confidence,
            "support_count": pattern.support_count,
            "contradiction_count": pattern.contradiction_count,
            "validation_status": pattern.validation_status,
            "evidence_class": provenance.get("evidence_class"),
            "source_match": _SOURCE_MATCH.get(candidate.compatibility_tier),
            "compatibility_decision": candidate.decision if candidate.decision != "unresolved" else None,
            "adapted_source_columns": list(candidate.adapted_source_columns or [])[:12],
            "missing_dependencies": list(candidate.missing_dependencies or [])[:6],
        }.items() if value not in (None, "", [], {})
    }


class LearningRetrievalService:
    """Retrieves and ranks FIR learnings for agent context.

    Provides methods to fetch:
    - FIR learnings from inferences
    - Similar mappings from this and other projects
    - Semantic learnings for column disambiguation
    - Mapping intent (captured or inferred)
    - Project context
    - Cross-project patterns
    - Correction history to avoid repeating mistakes
    """

    def __init__(
        self,
        session: Session,
        settings: Settings,
        access_scope: str = "default",
        session_lease: Callable[[], AbstractContextManager[Any]] | None = None,
    ) -> None:
        self._session = session
        self._settings = settings
        self._agent_learning_service = AgentLearningService(session, settings)
        self._target_pattern_service = (
            TargetMappingPatternService(session, settings)
            if settings.fir_target_mapping_patterns_v2
            else None
        )
        self._last_fir_retrieval_error: str | None = None
        self._session_lease = session_lease
        if access_scope != "default":
            effective_scope = access_scope
        else:
            # Server session ids are never reused, unlike Python object ids, so
            # two users can never share a cached context through this fallback.
            session_id = getattr(session, "session_id", None)
            effective_scope = f"session:{session_id}" if session_id else f"session:{id(session)}"
        self._access_fingerprint = hashlib.sha256(effective_scope.encode("utf-8")).hexdigest()

    def _leased_method(self, method_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        if self._session_lease is None:
            raise RuntimeError("No independent Snowflake session lease is configured")
        with self._session_lease() as client:
            worker = LearningRetrievalService(
                client.session,
                self._settings,
                self._access_fingerprint,
            )
            return getattr(worker, method_name)(*args, **kwargs)

    def _retrieve_audited(self, method: str, args: tuple, kwargs: dict, leased: bool) -> tuple:
        errors: list[str] = []
        token = _RETRIEVAL_ERRORS.set(errors)
        started = time.perf_counter()
        try:
            value = self._leased_method(method, args, kwargs) if leased else getattr(self, method)(*args, **kwargs)
        except ContextPrecedentUnavailableError:
            raise
        except Exception as exc:
            errors.append(type(exc).__name__)
            value = None if method in {"_get_or_infer_mapping_intent", "_get_project_context"} else []
        finally:
            _RETRIEVAL_ERRORS.reset(token)
        return value, {
            "status": "error" if errors else "available" if value else "no_match",
            "error_types": sorted(set(errors)),
            "duration_ms": round((time.perf_counter() - started) * 1000, 1),
        }

    @staticmethod
    def _quote(value: Any) -> str:
        return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"

    def _resolve_fir_epoch(self, project_id: str, target_table: str) -> str | None:
        """Version of the target's learned patterns, part of every cache key.

        Without it a durable context prepared before a publish keeps serving
        the pre-publish patterns for up to a day.
        """
        if self._target_pattern_service is None or not target_table:
            return None
        scope = f"{project_id}:{str(target_table).upper()}"
        now = time.monotonic()
        with _LEARNING_CACHE_LOCK:
            cached = _FIR_EPOCH_CACHE.get(scope)
            if cached and now - cached[0] <= _FIR_EPOCH_TTL_SECONDS:
                return cached[1]
        target_leaf = str(target_table).split(".")[-1]
        try:
            rows = self._session.sql(
                f"""
                SELECT COALESCE(TO_VARCHAR(MAX(UPDATED_AT)), 'empty')
                       || ':' || TO_VARCHAR(COUNT(*)) AS FIR_EPOCH
                FROM {self._settings.qualify_table_name(self._settings.snowflake_target_mapping_patterns_table)}
                WHERE STATUS = 'active'
                  AND (
                      UPPER(TARGET_TABLE) = UPPER({self._quote(target_table)})
                      OR UPPER(SPLIT_PART(TARGET_TABLE, '.', -1)) = UPPER({self._quote(target_leaf)})
                  )
                """
            ).collect()
        except Exception as exc:
            logger.debug("Unable to resolve FIR epoch for %s: %s", scope, exc)
            return None
        row = rows[0] if rows else None
        values = row.as_dict() if hasattr(row, "as_dict") else row
        epoch = str((values or {}).get("FIR_EPOCH") or "empty:0")
        with _LEARNING_CACHE_LOCK:
            _FIR_EPOCH_CACHE[scope] = (now, epoch)
        return epoch

    def _resolve_mapping_scope(
        self, project_id: str | None, sttm_id: str | None
    ) -> tuple[str | None, str | None]:
        """Source CRM and logical target recorded when the mapping was created.

        Clients do not always resend the mapping intent (Auto-map never did), and
        without it pattern ranking cannot prefer the same source CRM.
        """
        if not project_id and not sttm_id:
            return None, None
        scope = f"{self._access_fingerprint}:{project_id or ''}:{sttm_id or ''}"
        now = time.monotonic()
        with _LEARNING_CACHE_LOCK:
            cached = _MAPPING_SCOPE_CACHE.get(scope)
            if cached and now - cached[0] <= _MAPPING_SCOPE_TTL_SECONDS:
                return cached[1]
        try:
            rows = self._session.sql(
                f"""
                SELECT
                    COALESCE(
                        NULLIF(s.STTM_METADATA:source_system_key::STRING, ''),
                        NULLIF(p.PROJECT_METADATA:source_system_key::STRING, '')
                    ) AS SOURCE_SYSTEM_KEY,
                    NULLIF(s.STTM_METADATA:logical_target_table_key::STRING, '') AS LOGICAL_TARGET_KEY
                FROM (SELECT 1 AS ANCHOR) a
                LEFT JOIN {self._settings.qualify_table_name(self._settings.snowflake_projects_table)} p
                  ON TO_VARCHAR(p.PROJECT_ID) = ?
                LEFT JOIN {self._settings.qualify_table_name(self._settings.snowflake_sttm_table)} s
                  ON TO_VARCHAR(s.STTM_ID) = ?
                LIMIT 1
                """,
                params=[str(project_id or ""), str(sttm_id or "")],
            ).collect()
        except Exception as exc:
            logger.debug("Unable to resolve mapping scope for %s: %s", scope, exc)
            return None, None
        row = rows[0] if rows else None
        values = (row.as_dict() if hasattr(row, "as_dict") else row) or {}
        resolved = (
            str(values.get("SOURCE_SYSTEM_KEY") or "").strip().upper() or None,
            optional_identifier(values.get("LOGICAL_TARGET_KEY")),
        )
        with _LEARNING_CACHE_LOCK:
            _MAPPING_SCOPE_CACHE[scope] = (now, resolved)
        return resolved

    @classmethod
    def _quote_list(cls, values: list[Any] | None, *, upper: bool = False) -> str:
        """Render an escaped SQL IN-list; an empty list matches nothing."""
        items = [str(value).upper() if upper else str(value) for value in values or [] if value is not None]
        return ", ".join(cls._quote(item) for item in items) if items else "NULL"

    def _load_durable_context(self, cache_key: str) -> LearningContext | None:
        """Hydrate a prepared learning context after a replica change or restart."""
        try:
            table_name = self._settings.qualify_metadata_object_name(
                "TBL_PREPARED_LEARNING_CONTEXTS"
            )
            rows = self._session.sql(
                f"""
                SELECT CONTEXT_PAYLOAD
                FROM {table_name}
                WHERE CONTEXT_KEY = ?
                  AND ACCESS_FINGERPRINT = ?
                  AND UPDATED_AT >= DATEADD(
                      'second', ?, CURRENT_TIMESTAMP()
                  )
                ORDER BY UPDATED_AT DESC
                LIMIT 1
                """,
                params=[
                    cache_key,
                    self._access_fingerprint,
                    -int(_LEARNING_DURABLE_REVALIDATE_SECONDS),
                ],
            ).collect()
            if not rows:
                increment("learning_context.cache.l2_miss")
                return None
            payload = rows[0].as_dict().get("CONTEXT_PAYLOAD")
            if isinstance(payload, str):
                payload = json.loads(payload)
            if not isinstance(payload, dict):
                return None
            result = LearningContext.model_validate(payload)
            result.cache_status = "l2"
            increment("learning_context.cache.l2_hit")
            return result
        except Exception as exc:
            # Older installations may not have this table until the accompanying
            # idempotent DDL is bootstrapped. Retrieval remains functional.
            increment("learning_context.cache.l2_error")
            logger.warning("Prepared FIR context L2 cache unavailable: %s", exc)
            return None

    def get_prepared_learning_context(
        self,
        *,
        learning_context_id: str,
        learning_context_hash: str | None = None,
    ) -> LearningContext | None:
        """Hydrate an immutable prepared context by public handle.

        Warm assistant calls use this path instead of repeating FIR retrieval.
        Access isolation is enforced by the same internal fingerprint used by
        the durable cache.
        """
        if not learning_context_id:
            return None
        handle_key = (learning_context_id, learning_context_hash or "", self._access_fingerprint)
        with _LEARNING_CACHE_LOCK:
            cached = _HANDLE_CACHE.get(handle_key)
            if cached and time.monotonic() - cached[0] <= _LEARNING_CACHE_IDLE_SECONDS:
                _HANDLE_CACHE[handle_key] = (time.monotonic(), cached[1])
                increment("learning_context.handle.l1_hit")
                return cached[1].model_copy(deep=True)
        try:
            table_name = self._settings.qualify_metadata_object_name(
                "TBL_PREPARED_LEARNING_CONTEXTS"
            )
            hash_predicate = "AND LEARNING_CONTEXT_HASH = ?" if learning_context_hash else ""
            params = [learning_context_id, self._access_fingerprint]
            if learning_context_hash:
                params.append(learning_context_hash)
            rows = self._session.sql(
                f"""
                SELECT CONTEXT_PAYLOAD
                FROM {table_name}
                WHERE LEARNING_CONTEXT_ID = ?
                  AND ACCESS_FINGERPRINT = ?
                  {hash_predicate}
                ORDER BY UPDATED_AT DESC
                LIMIT 1
                """,
                params=params,
            ).collect()
            if not rows:
                return None
            payload = rows[0].as_dict().get("CONTEXT_PAYLOAD")
            if isinstance(payload, str):
                payload = json.loads(payload)
            if not isinstance(payload, dict):
                return None
            context = LearningContext.model_validate(payload)
            context.cache_status = "l2-handle"
            with _LEARNING_CACHE_LOCK:
                if len(_HANDLE_CACHE) >= _HANDLE_CACHE_MAX:
                    _HANDLE_CACHE.pop(min(_HANDLE_CACHE, key=lambda key: _HANDLE_CACHE[key][0]))
                _HANDLE_CACHE[handle_key] = (time.monotonic(), context.model_copy(deep=True))
            return context
        except Exception as exc:
            logger.debug("Prepared FIR handle hydration unavailable: %s", exc)
            return None

    def _persist_durable_context(
        self,
        cache_key: str,
        context: LearningContext,
    ) -> bool:
        """Persist the exact prepared object so agents do not repeat retrieval."""
        if not self._settings.prepared_context_cache_v2:
            increment("learning_context.cache.persist_disabled")
            return False
        started = time.perf_counter()
        try:
            table_name = self._settings.qualify_metadata_object_name(
                "TBL_PREPARED_LEARNING_CONTEXTS"
            )
            payload = json.dumps(
                context.model_dump(mode="json"),
                sort_keys=True,
                default=str,
                separators=(",", ":"),
            )
            self._session.sql(
                f"""
                MERGE INTO {table_name} target
                USING (
                    SELECT
                        ? AS CONTEXT_KEY,
                        ? AS ACCESS_FINGERPRINT,
                        ? AS LEARNING_CONTEXT_ID,
                        ? AS LEARNING_CONTEXT_HASH,
                        PARSE_JSON(?) AS CONTEXT_PAYLOAD
                ) source
                ON target.CONTEXT_KEY = source.CONTEXT_KEY
                   AND target.ACCESS_FINGERPRINT = source.ACCESS_FINGERPRINT
                WHEN MATCHED THEN UPDATE SET
                    LEARNING_CONTEXT_ID = source.LEARNING_CONTEXT_ID,
                    LEARNING_CONTEXT_HASH = source.LEARNING_CONTEXT_HASH,
                    CONTEXT_PAYLOAD = source.CONTEXT_PAYLOAD,
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT (
                    CONTEXT_KEY, ACCESS_FINGERPRINT, LEARNING_CONTEXT_ID,
                    LEARNING_CONTEXT_HASH, CONTEXT_PAYLOAD, CREATED_AT, UPDATED_AT
                ) VALUES (
                    source.CONTEXT_KEY, source.ACCESS_FINGERPRINT,
                    source.LEARNING_CONTEXT_ID, source.LEARNING_CONTEXT_HASH,
                    source.CONTEXT_PAYLOAD, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
                )
                """,
                params=[
                    cache_key,
                    self._access_fingerprint,
                    context.learning_context_id or "",
                    context.learning_context_hash or "",
                    payload,
                ],
            ).collect()
            increment("learning_context.cache.persist_success")
            return True
        except Exception as exc:
            increment("learning_context.cache.persist_failure")
            logger.error(
                "Unable to persist prepared FIR context id=%s caller_rights=%s: %s",
                context.learning_context_id,
                self._settings.spcs_execute_as_caller_enabled,
                exc,
            )
            return False
        finally:
            observe(
                "learning_context.cache.persist",
                (time.perf_counter() - started) * 1000,
            )

    def _get_link_scope(self, *, project_id: str, sttm_id: str | None) -> dict[str, Any]:
        """Return only explicitly directed precedent scopes for this workspace."""
        project_ids: list[str] = []
        sttm_ids: list[str] = []
        explanations: list[dict[str, Any]] = []
        errors: list[str] = []
        try:
            rows = self._session.sql(
                f"""
                SELECT PRECEDENT_PROJECT_ID, PRIORITY, KNOWLEDGE_CATEGORIES,
                       ALLOW_PROJECT_SPECIFIC_VALUES
                FROM {self._settings.qualify_metadata_object_name('TBL_FIR_PROJECT_LINKS')}
                WHERE PROJECT_ID = {self._quote(project_id)}
                  AND LOWER(COALESCE(STATUS, 'active')) = 'active'
                ORDER BY PRIORITY DESC
                """
            ).collect()
            for row in rows:
                data = row.as_dict()
                precedent_id = str(data.get("PRECEDENT_PROJECT_ID") or "")
                if not precedent_id:
                    continue
                project_ids.append(precedent_id)
                explanations.append(
                    {
                        "retrieval_mode": "linked_project",
                        "precedent_project_id": precedent_id,
                        "priority": int(data.get("PRIORITY") or 50),
                        "knowledge_categories": self._parse_string_list(
                            data.get("KNOWLEDGE_CATEGORIES")
                        ),
                        "allow_project_specific_values": bool(
                            data.get("ALLOW_PROJECT_SPECIFIC_VALUES")
                        ),
                    }
                )
        except Exception as exc:
            logger.debug("Project precedent links unavailable: %s", exc)
            errors.append(type(exc).__name__)
        if sttm_id:
            try:
                rows = self._session.sql(
                    f"""
                    SELECT PRECEDENT_STTM_ID, PRIORITY, KNOWLEDGE_CATEGORIES,
                           TARGET_COMPATIBILITY, CONFIDENCE,
                           ALLOW_PROJECT_SPECIFIC_VALUES
                    FROM {self._settings.qualify_metadata_object_name('TBL_FIR_MAPPING_LINKS')}
                    WHERE STTM_ID = {self._quote(sttm_id)}
                      AND LOWER(COALESCE(STATUS, 'active')) = 'active'
                    ORDER BY PRIORITY DESC
                    """
                ).collect()
                for row in rows:
                    data = row.as_dict()
                    precedent_id = str(data.get("PRECEDENT_STTM_ID") or "")
                    if not precedent_id:
                        continue
                    sttm_ids.append(precedent_id)
                    explanations.append(
                        {
                            "retrieval_mode": "linked_mapping",
                            "precedent_sttm_id": precedent_id,
                            "priority": int(data.get("PRIORITY") or 75),
                            "confidence": float(data.get("CONFIDENCE") or 1.0),
                            "target_compatibility": data.get("TARGET_COMPATIBILITY"),
                            "knowledge_categories": self._parse_string_list(
                                data.get("KNOWLEDGE_CATEGORIES")
                            ),
                            "allow_project_specific_values": bool(
                                data.get("ALLOW_PROJECT_SPECIFIC_VALUES")
                            ),
                        }
                    )
            except Exception as exc:
                logger.debug("Mapping precedent links unavailable: %s", exc)
                errors.append(type(exc).__name__)
        return {
            "project_ids": sorted(set(project_ids)),
            "sttm_ids": sorted(set(sttm_ids)),
            "explanations": explanations,
            "errors": errors,
        }

    def get_comprehensive_learning_context(
        self,
        project_id: str,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        mapping_intent: dict[str, Any] | None = None,
        sttm_id: str | None = None,
        max_fir_learnings: int = 15,
        max_similar_mappings: int = 10,
        max_corrections: int = 5,
        context_key: str | None = None,
        source_set_hash: str | None = None,
        derived_set_hash: str | None = None,
        fir_epoch: str | None = None,
        milestone: str | None = None,
        target_agent: str = "AGT_SOURCE_MAPPING",
        source_columns: list[str] | None = None,
        source_column_profiles: list[dict[str, Any]] | None = None,
        crm_family: str | None = None,
        relationship_paths: list[str] | None = None,
        derived_outputs: list[str] | None = None,
        logical_target_key: str | None = None,
        target_profiles: dict[str, str] | None = None,
    ) -> LearningContext:
        """Retrieve all relevant learning context for a mapping operation.

        Returns prioritized and deduplicated learning items.

        Args:
            project_id: Current project ID
            source_tables: List of source table qualified names
            target_table: Target table qualified name
            target_columns: List of target column names
            mapping_intent: Optional provided mapping intent
            sttm_id: Optional STTM ID for context retrieval
            max_fir_learnings: Maximum FIR learnings to return
            max_similar_mappings: Maximum similar mappings to return
            max_corrections: Maximum correction history items

        Returns:
            LearningContext with all retrieved learning data
        """
        if fir_epoch is None:
            fir_epoch = self._resolve_fir_epoch(project_id, target_table)
        if not crm_family or not logical_target_key:
            intent = mapping_intent if isinstance(mapping_intent, dict) else {}
            crm_family = crm_family or str(intent.get("source_system_key") or "").strip() or None
            logical_target_key = (
                logical_target_key or str(intent.get("logical_target_key") or "").strip() or None
            )
        if not crm_family or not logical_target_key:
            stored_crm, stored_target = self._resolve_mapping_scope(project_id, sttm_id)
            crm_family = crm_family or stored_crm
            logical_target_key = logical_target_key or stored_target
        cache_payload = {
            "retrieval_contract": "automap-hybrid-v5-shared-search-scopes",
            "hybrid_search": self._settings.automap_hybrid_context_v1 is True,
            "iterative_retrieval": getattr(self._settings, "automap_context_retrieval_v1", False),
            "recipe_search_service": str(self._settings.automap_recipe_search_service),
            "column_search_service": str(self._settings.automap_column_search_service),
            "target_profiles": target_profiles or {},
            "access": self._access_fingerprint,
            "project_id": project_id,
            "sttm_id": sttm_id,
            "source_tables": sorted(str(value).upper() for value in source_tables),
            "target_table": str(target_table).upper(),
            "target_columns": sorted(str(value).upper() for value in target_columns),
            "mapping_intent": mapping_intent or {},
            "context_key": context_key,
            "source_set_hash": source_set_hash,
            "derived_set_hash": derived_set_hash,
            "fir_epoch": fir_epoch,
            "milestone": milestone,
            "target_agent": target_agent,
            "source_columns": sorted(source_columns or []),
            "source_column_profiles": source_column_profiles or [],
            "crm_family": crm_family,
            "relationship_paths": sorted(relationship_paths or []),
            "derived_outputs": sorted(derived_outputs or []),
            "logical_target_key": logical_target_key,
            "max_fir_learnings": max_fir_learnings,
            "max_similar_mappings": max_similar_mappings,
            "max_corrections": max_corrections,
        }
        cache_key = hashlib.sha256(
            json.dumps(cache_payload, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        with _LEARNING_CACHE_LOCK:
            cached = _LEARNING_CACHE.get(cache_key)
            if cached and time.monotonic() - cached[0] <= _LEARNING_CACHE_IDLE_SECONDS:
                result = cached[1].model_copy(deep=True)
                result.cache_status = "l1"
                increment("learning_context.cache.l1_hit")
                return result
            if cached:
                _LEARNING_CACHE.pop(cache_key, None)
            increment("learning_context.cache.l1_miss")
            build_lock = _LEARNING_BUILD_LOCKS.setdefault(cache_key, threading.Lock())
        build_lock.acquire()
        with _LEARNING_CACHE_LOCK:
            cached = _LEARNING_CACHE.get(cache_key)
            if cached and time.monotonic() - cached[0] <= _LEARNING_CACHE_IDLE_SECONDS:
                result = cached[1].model_copy(deep=True)
                result.cache_status = "l1"
                build_lock.release()
                return result
        durable = self._load_durable_context(cache_key)
        if durable is not None:
            with _LEARNING_CACHE_LOCK:
                _LEARNING_CACHE[cache_key] = (
                    time.monotonic(),
                    durable.model_copy(deep=True),
                )
                _LEARNING_BUILD_LOCKS.pop(cache_key, None)
            build_lock.release()
            return durable
        link_scope = self._get_link_scope(project_id=project_id, sttm_id=sttm_id)
        try:
            all_tables = list(source_tables) + ([target_table] if target_table else [])
            jobs: dict[str, tuple[str, tuple[Any, ...], dict[str, Any]]] = {
                "fir_learnings": ("_get_fir_learnings", (source_tables, target_table, target_columns, max_fir_learnings), {"context_key": context_key, "project_id": project_id, "sttm_id": sttm_id, "linked_project_ids": link_scope["project_ids"], "linked_sttm_ids": link_scope["sttm_ids"]}),
                "similar_mappings": ("_get_similar_mappings", (project_id, source_tables, target_table, target_columns, max_similar_mappings), {"linked_project_ids": link_scope["project_ids"], "linked_sttm_ids": link_scope["sttm_ids"]}),
                "semantic_learnings": ("_get_semantic_learnings", (target_columns,), {"project_id": project_id, "target_table": target_table, "context_key": context_key}),
                "intent": ("_get_or_infer_mapping_intent", (project_id, target_table, source_tables, mapping_intent), {"context_key": context_key}),
                "project_context": ("_get_project_context", (project_id, source_tables, sttm_id), {}),
                "cross_project_patterns": ("_get_cross_project_patterns", (source_tables, target_table, target_columns), {"linked_project_ids": link_scope["project_ids"]}),
                "correction_history": ("_get_correction_history", (project_id, target_columns, max_corrections), {"sttm_id": sttm_id}),
                "semantic_version_learnings": ("get_semantic_version_learnings", (all_tables,), {}),
                "fir_recommendations": ("_get_fir_recommendations_for_context", (), {"project_id": project_id, "source_tables": source_tables, "target_table": target_table, "target_columns": target_columns, "context_key": context_key, "source_set_hash": source_set_hash, "derived_set_hash": derived_set_hash, "milestone": milestone, "target_agent": target_agent, "linked_project_ids": link_scope["project_ids"], "linked_sttm_ids": link_scope["sttm_ids"]}),
                "mapping_precedents": ("_get_mapping_precedents", (), {"linked_sttm_ids": link_scope["sttm_ids"], "link_explanations": link_scope["explanations"], "target_columns": target_columns}),
                "source_agent_learnings": ("_get_scoped_agent_evidence", (), {"agent_type": "SOURCE_MAPPING", "project_id": project_id, "target_table": target_table, "target_columns": target_columns}),
                "transformation_patterns": ("_get_scoped_agent_evidence", (), {"agent_type": "TRANSFORMATION_RULE", "project_id": project_id, "target_table": target_table, "target_columns": target_columns}),
            }
            if target_agent == "AGT_STTM_BUILDER" and project_id:
                # Chat writes CTEs, so it needs the existing ones to reuse instead of regenerating.
                jobs["project_derived_sources"] = ("_get_project_derived_sources", (project_id, source_tables), {})
            parallel_enabled = bool(
                self._settings.learning_parallel_v1 and self._session_lease is not None
            )
            if parallel_enabled:
                started_parallel = time.perf_counter()
                try:
                    with ThreadPoolExecutor(
                        max_workers=max(
                            1,
                            min(
                                3 if self._settings.prepare_parallel_v1 else 4,
                                self._settings.learning_parallel_workers,
                            ),
                        )
                    ) as executor:
                        futures = {
                            name: executor.submit(self._retrieve_audited, method, args, kwargs, True)
                            for name, (method, args, kwargs) in jobs.items()
                        }
                        values = {name: futures[name].result() for name in jobs}
                    observe(
                        "learning_context.parallel.duration_ms",
                        (time.perf_counter() - started_parallel) * 1000,
                    )
                except Exception as exc:
                    increment("learning_context.parallel.fallback")
                    logger.warning("Parallel FIR retrieval fell back to sequential execution: %s", exc)
                    values = {
                        name: self._retrieve_audited(method, args, kwargs, False)
                        for name, (method, args, kwargs) in jobs.items()
                    }
            else:
                values = {
                    name: self._retrieve_audited(method, args, kwargs, False)
                    for name, (method, args, kwargs) in jobs.items()
                }
            retrieval_diagnostics = {name: value[1] for name, value in values.items()}
            values = {name: value[0] for name, value in values.items()}
            fir_learnings = values["fir_learnings"]
            similar_mappings = values["similar_mappings"]
            semantic_learnings = values["semantic_learnings"]
            intent = values["intent"]
            project_context = values["project_context"]
            cross_project_patterns = values["cross_project_patterns"]
            correction_history = values["correction_history"]
            semantic_version_learnings = values["semantic_version_learnings"]
            fir_recommendations = values["fir_recommendations"]
            mapping_precedents = values["mapping_precedents"]
            project_derived_sources = values.get("project_derived_sources") or []
            if link_scope["sttm_ids"] and not mapping_precedents:
                raise ContextPrecedentUnavailableError(
                    "The mapping is linked to completed precedent context, but that context could not be loaded."
                )
            target_mapping_patterns: list[dict[str, Any]] = []
            discovery = {"evidence": [], "source_candidates": {}, "diagnostics": {"status": "disabled"}}
            if self._settings.automap_hybrid_context_v1 is True and target_table:
                from app.core.mapping_search import MappingSearchService
                discovery = MappingSearchService(self._session, self._settings).discover(
                    project_id=project_id, sttm_id=sttm_id, target_table=target_table,
                    target_columns=target_columns, source_tables=source_tables, target_profiles=target_profiles,
                )
            retrieval_diagnostics["search_evidence"] = discovery["diagnostics"]
            retrieval_diagnostics["target_mapping_patterns"] = {"status": "excluded", "reason": "not_enabled_or_no_target"}
            if self._target_pattern_service is not None and target_table:
                try:
                    # The per-column cap keeps wide targets from starving later
                    # columns; the total cap only bounds the payload.
                    per_column_limit = 2 if target_agent == "AGT_TRANSFORMATION_RULE" else 4
                    pattern_limit = max(len(target_columns) * per_column_limit, 20)
                    target_mapping_patterns = [
                        compact_candidate_for_agent(candidate.model_dump(mode="json"))
                        for candidate in self._target_pattern_service.retrieve_candidates(
                            target_table=target_table,
                            target_columns=target_columns,
                            source_tables=source_tables,
                            source_columns=source_columns,
                            source_column_profiles=source_column_profiles,
                            crm_family=crm_family,
                            relationship_paths=relationship_paths,
                            derived_outputs=derived_outputs,
                            workspace_context_id=sttm_id,
                            project_id=project_id,
                            linked_project_ids=link_scope["project_ids"],
                            logical_target_key=(
                                logical_target_key
                                or str((mapping_intent or {}).get("logical_target_key") or "")
                                or None
                            ),
                            limit=pattern_limit,
                            per_column_limit=per_column_limit,
                            additional_pattern_ids=[item["pattern_id"] for item in discovery["evidence"]
                                                    if item.get("pattern_id")],
                        )
                    ]
                    retrieval_diagnostics["target_mapping_patterns"] = {
                        "status": "available" if target_mapping_patterns else "no_match",
                    }
                except Exception as exc:
                    retrieval_diagnostics["target_mapping_patterns"] = {"status": "error", "error_types": [type(exc).__name__]}
                    # Compatibility release: an installation may enable the
                    # service before the idempotent V2 DDL is bootstrapped.
                    logger.warning(
                        "Target-column FIR patterns are temporarily unavailable: %s",
                        exc,
                    )

            result = LearningContext(
                search_evidence=[item for item in discovery["evidence"] if item["knowledge_type"] != "recipe"],
                source_candidates=discovery["source_candidates"],
                search_diagnostics=discovery["diagnostics"],
                retrieval_diagnostics=retrieval_diagnostics,
                source_agent_learnings=values.get("source_agent_learnings") or [],
                transformation_patterns=values.get("transformation_patterns") or [],
                project_derived_sources=project_derived_sources,
                fir_learnings=fir_learnings,
                similar_mappings=similar_mappings,
                semantic_learnings=semantic_learnings,
                mapping_intent=intent,
                project_context=project_context,
                cross_project_patterns=cross_project_patterns,
                correction_history=correction_history,
                semantic_version_learnings=semantic_version_learnings,
                fir_recommendations=fir_recommendations,
                retrieved_inference_ids=sorted({
                    item.learning_id for item in fir_learnings if item.learning_id
                }),
                retrieved_recommendation_ids=sorted({
                    str(item.get("recommendation_id") or item.get("RECOMMENDATION_ID") or "")
                    for item in fir_recommendations
                    if item.get("recommendation_id") or item.get("RECOMMENDATION_ID")
                }),
                retrieved_learning_ids=sorted({
                    *(
                        item.learning_id
                        for item in fir_learnings
                        if item.learning_id
                    ),
                    *(
                        str(item.get("pattern", {}).get("pattern_id") or "")
                        for item in target_mapping_patterns
                        if item.get("pattern", {}).get("pattern_id")
                    ),
                    *(
                        item.mapping_id
                        for item in similar_mappings
                        if item.mapping_id
                    ),
                    *(
                        item.learning_id
                        for item in semantic_learnings
                        if item.learning_id
                    ),
                }),
                used_learning_ids=[],
                context_key=context_key,
                retrieval_mode=(
                    str(fir_recommendations[0].get("retrieval_mode"))
                    if fir_recommendations
                    else None
                ),
                linked_project_ids=link_scope["project_ids"],
                linked_mapping_ids=link_scope["sttm_ids"],
                linked_project_patterns=[
                    item.model_dump(mode="json") for item in cross_project_patterns
                ],
                linked_mapping_precedents=[
                    item.model_dump(mode="json")
                    for item in similar_mappings
                    if item.sttm_id in set(link_scope["sttm_ids"])
                ],
                mapping_precedents=mapping_precedents,
                target_mapping_patterns=target_mapping_patterns,
                curated_relationships=[
                    relationship
                    for item in semantic_version_learnings
                    for relationship in self._parse_relationships(item.get("relationship_rules"))
                ],
                retrieval_explanations=[
                    *link_scope["explanations"],
                    *(
                        [{
                            "retrieval_mode": "fir_degraded",
                            "visible_warning": self._last_fir_retrieval_error,
                        }]
                        if self._last_fir_retrieval_error
                        else []
                    ),
                ],
            )
            context_payload = result.model_dump(mode="json", exclude={"learning_context_id", "learning_context_hash", "cache_status"})
            context_hash = hashlib.sha256(
                json.dumps(context_payload, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
            ).hexdigest()
            result.learning_context_hash = context_hash
            result.learning_context_id = f"learn_{context_hash[:16]}"
            self._persist_durable_context(cache_key, result)
            with _LEARNING_CACHE_LOCK:
                _LEARNING_CACHE[cache_key] = (time.monotonic(), result.model_copy(deep=True))
                _LEARNING_BUILD_LOCKS.pop(cache_key, None)
            build_lock.release()
            return result
        except ContextPrecedentUnavailableError:
            with _LEARNING_CACHE_LOCK:
                _LEARNING_BUILD_LOCKS.pop(cache_key, None)
            build_lock.release()
            raise
        except Exception as exc:
            logger.warning("Failed to retrieve learning context: %s", exc)
            if link_scope["sttm_ids"]:
                with _LEARNING_CACHE_LOCK:
                    _LEARNING_BUILD_LOCKS.pop(cache_key, None)
                build_lock.release()
                raise ContextPrecedentUnavailableError(
                    "The linked mapping precedent failed during context preparation."
                ) from exc
            with _LEARNING_CACHE_LOCK:
                _LEARNING_BUILD_LOCKS.pop(cache_key, None)
            build_lock.release()
            return LearningContext(retrieval_diagnostics={"context": {"status": "error", "error_types": [type(exc).__name__]}})

    def _get_fir_learnings(
        self,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        limit: int = 15,
        *,
        context_key: str | None = None,
        project_id: str | None = None,
        sttm_id: str | None = None,
        linked_project_ids: list[str] | None = None,
        linked_sttm_ids: list[str] | None = None,
    ) -> list[FIRLearningItem]:
        """Retrieve exact FIR inferences, then reusable knowledge for the same subjects."""
        try:
            inference_table = self._settings.qualify_table_name(
                self._settings.snowflake_assistant_inferences_table
            )
            subjects = {
                str(value).strip().upper()
                for value in [*source_tables, target_table, *target_columns]
                if value and str(value).strip()
            }
            subjects.update(
                f"{target_table.strip().upper()}.{column.strip().upper()}"
                for column in target_columns
                if target_table and column and column.strip()
            )

            def quote(value: str) -> str:
                return "'" + value.replace("'", "''") + "'"

            select_sql = f"""
            SELECT
                INFERENCE_ID AS LEARNING_ID,
                COALESCE(INFERENCE_GOAL_ID, INFERENCE_TYPE) AS LEARNING_TYPE,
                COALESCE(SUBJECT_KEY, ATTRIBUTES:pattern_key::STRING, '') AS PATTERN_KEY,
                SUMMARY,
                COALESCE(CONFIDENCE, 0.5) AS CONFIDENCE,
                COALESCE(PROVENANCE:agent::STRING, SOURCE) AS SOURCE,
                COALESCE(
                    STRUCTURED_ANSWER:business_purpose::STRING,
                    STRUCTURED_ANSWER:business_definition::STRING,
                    STRUCTURED_ANSWER:business_meaning::STRING,
                    ATTRIBUTES:business_rationale::STRING
                ) AS BUSINESS_RATIONALE,
                COALESCE(STRUCTURED_ANSWER:domain::STRING, ATTRIBUTES:domain_pattern::STRING) AS DOMAIN_PATTERN,
                COALESCE(
                    ATTRIBUTES:reusability::STRING,
                    IFF(INFERENCE_GOAL_ID = 'Q2', 'column_specific',
                        IFF(INFERENCE_GOAL_ID IN ('Q6', 'Q7'), 'table_specific', 'highly_reusable'))
                ) AS REUSABILITY,
                TO_CHAR(CREATED_AT, 'YYYY-MM-DD HH24:MI:SS') AS CREATED_AT
            FROM {inference_table}
            WHERE STATUS = 'active'
              AND COALESCE(VALIDATION_STATUS, 'unvalidated') NOT IN ('rejected', 'superseded')
              AND COALESCE(CONFIDENCE, 0.5) >= 0.3
              {{predicate}}
            ORDER BY COALESCE(CONFIDENCE, 0.5) DESC, CREATED_AT DESC
            LIMIT {limit}
            """

            rows = []
            if context_key:
                rows = self._session.sql(
                    select_sql.format(predicate=f"AND CONTEXT_KEY = {quote(context_key)}")
                ).collect()
            if not rows and subjects:
                subject_literals = ", ".join(quote(subject) for subject in sorted(subjects))
                allowed_scope: list[str] = []
                allowed_projects = [str(project_id)] if project_id else []
                allowed_projects.extend(linked_project_ids or [])
                allowed_sttms = [str(sttm_id)] if sttm_id else []
                allowed_sttms.extend(linked_sttm_ids or [])
                if allowed_projects:
                    values = ", ".join(quote(value) for value in sorted(set(allowed_projects)))
                    allowed_scope.append(f"TO_VARCHAR(PROJECT_ID) IN ({values})")
                if allowed_sttms:
                    values = ", ".join(quote(value) for value in sorted(set(allowed_sttms)))
                    allowed_scope.append(f"TO_VARCHAR(STTM_ID) IN ({values})")
                scope_predicate = (
                    " AND (" + " OR ".join(allowed_scope) + ")"
                    if allowed_scope
                    else ""
                )
                rows = self._session.sql(
                    select_sql.format(
                        predicate=(
                            f"AND UPPER(COALESCE(SUBJECT_KEY, '')) IN ({subject_literals})"
                            f"{scope_predicate}"
                        )
                    )
                ).collect()
            return [
                FIRLearningItem(
                    learning_id=str(row["LEARNING_ID"] or ""),
                    learning_type=str(row["LEARNING_TYPE"] or ""),
                    pattern_key=str(row["PATTERN_KEY"] or ""),
                    summary=str(row["SUMMARY"] or ""),
                    confidence=float(row["CONFIDENCE"]) if row["CONFIDENCE"] else 0.5,
                    source=str(row["SOURCE"] or ""),
                    business_rationale=row["BUSINESS_RATIONALE"],
                    domain_pattern=row["DOMAIN_PATTERN"],
                    reusability=row["REUSABILITY"],
                    created_at=row["CREATED_AT"],
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get FIR learnings: %s", exc)
            _record_retrieval_error(exc)
            return []

    def _get_similar_mappings(
        self,
        project_id: str,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        limit: int = 10,
        *,
        linked_project_ids: list[str] | None = None,
        linked_sttm_ids: list[str] | None = None,
    ) -> list[SimilarMappingItem]:
        """Find similar mappings from this or other projects.

        Prioritizes:
        1. Same project mappings (highest)
        2. Published STTMs in other projects
        3. Exact target column name match
        """
        try:
            target_cols_list = self._quote_list(target_columns, upper=True)

            allowed_projects = sorted(set([project_id, *(linked_project_ids or [])]))
            allowed_sttms = sorted(set(linked_sttm_ids or []))
            project_scope = ", ".join(self._quote(value) for value in allowed_projects)
            sttm_scope = ", ".join(self._quote(value) for value in allowed_sttms) or "NULL"
            trust_filter = ""
            if self._settings.automap_hybrid_context_v1 is True:
                trust_filter = """
                  AND COALESCE(a.IS_DRAFT, FALSE) = FALSE
                  AND UPPER(COALESCE(s.STATUS, '')) IN ('COMPLETE', 'PUBLISHED')
                  AND a.EFFECTIVE_FROM_VERSION IS NOT NULL
                  AND a.EFFECTIVE_FROM_VERSION <= s.CURRENT_VERSION
                  AND (a.EFFECTIVE_THROUGH_VERSION IS NULL OR a.EFFECTIVE_THROUGH_VERSION >= s.CURRENT_VERSION)
                """
            query = f"""
            SELECT
                a.ATTRIBUTE_ID as mapping_id,
                s.PROJECT_ID as project_id,
                COALESCE(p.PROJECT_NAME, TO_VARCHAR(s.PROJECT_ID)) as project_name,
                s.STTM_ID as sttm_id,
                COALESCE(s.STTM_NAME, TO_VARCHAR(s.STTM_ID)) as sttm_name,
                a.ATTRIBUTE_NAME as target_column,
                COALESCE(a.CONDITION:source_columns, TRY_PARSE_JSON(a.SOURCE_COLUMN), ARRAY_CONSTRUCT(a.SOURCE_COLUMN)) as source_columns,
                COALESCE(
                    LOWER(a.CONDITION:mapping_mode::STRING),
                    IFF(a.CONDITION:constant_value IS NOT NULL OR UPPER(a.CONDITION:preprocessing_rule_type::STRING) = 'VALUE', 'constant', 'source')
                ) as mapping_mode,
                a.CONDITION:constant_value::STRING as constant_value,
                a.CONDITION:attribute_name::STRING as project_attribute_name,
                a.TRANSFORMATION_LOGIC as preprocessing_rule,
                COALESCE(a.CONDITION:preprocessing_rule_type::STRING, 'Direct') as preprocessing_rule_type,
                COALESCE(a.CONDITION:confidence::NUMBER, 0.7) as confidence_score,
                UPPER(COALESCE(s.STATUS, '')) IN ('PUBLISHED', 'COMPLETE') as was_published,
                CASE
                    WHEN s.PROJECT_ID = {self._quote(project_id)} THEN 1.0
                    WHEN TO_VARCHAR(s.STTM_ID) IN ({sttm_scope}) THEN 0.95
                    WHEN TO_VARCHAR(s.PROJECT_ID) IN ({project_scope}) AND UPPER(s.STATUS) = 'COMPLETE' THEN 0.85
                    ELSE 0.0
                END as similarity_score
            FROM {self._settings.qualify_table_name('TBL_STTM_ATTRIBUTES')} a
            JOIN {self._settings.qualify_table_name('TBL_STTM')} s ON a.STTM_ID = s.STTM_ID
            LEFT JOIN {self._settings.qualify_table_name('TBL_PROJECTS')} p ON s.PROJECT_ID = p.PROJECT_ID
            WHERE UPPER(a.ATTRIBUTE_NAME) IN ({target_cols_list})
              AND UPPER(s.TARGET_TABLE) = UPPER({self._quote(target_table)})
              {trust_filter}
              AND (
                  TO_VARCHAR(s.PROJECT_ID) = {self._quote(project_id)}
                  OR TO_VARCHAR(s.STTM_ID) IN ({sttm_scope})
                  OR (
                      TO_VARCHAR(s.PROJECT_ID) IN ({project_scope})
                      AND UPPER(COALESCE(s.STATUS, '')) IN ('COMPLETE', 'PUBLISHED')
                  )
              )
            ORDER BY similarity_score DESC, confidence_score DESC
            LIMIT {limit}
            """

            rows = self._session.sql(query).collect()
            return [
                SimilarMappingItem(
                    mapping_id=str(row["MAPPING_ID"] or ""),
                    project_id=str(row["PROJECT_ID"] or ""),
                    project_name=str(row["PROJECT_NAME"] or ""),
                    sttm_id=str(row["STTM_ID"] or ""),
                    sttm_name=str(row["STTM_NAME"] or ""),
                    target_column=str(row["TARGET_COLUMN"] or ""),
                    source_columns=self._parse_source_columns(row["SOURCE_COLUMNS"]),
                    mapping_mode=(
                        str(row["MAPPING_MODE"] or "source").lower()
                        if str(row["MAPPING_MODE"] or "source").lower() in {"constant", "attribute"}
                        else "source"
                    ),
                    constant_value=(str(row["CONSTANT_VALUE"]) if row["CONSTANT_VALUE"] is not None else None),
                    attribute_name=(
                        str(row["PROJECT_ATTRIBUTE_NAME"])
                        if row["PROJECT_ATTRIBUTE_NAME"] is not None
                        else None
                    ),
                    preprocessing_rule=row["PREPROCESSING_RULE"],
                    preprocessing_rule_type=str(row["PREPROCESSING_RULE_TYPE"] or "Direct"),
                    confidence_score=float(row["CONFIDENCE_SCORE"]) if row["CONFIDENCE_SCORE"] else 0.7,
                    was_published=bool(row["WAS_PUBLISHED"]),
                    similarity_score=float(row["SIMILARITY_SCORE"]) if row["SIMILARITY_SCORE"] else 0.5,
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get similar mappings: %s", exc)
            _record_retrieval_error(exc)
            return []

    def get_auto_map_context(self, *, project_id: str, sttm_id: str | None,
                             target_columns: list[str], target_table: str = "") -> LearningContext:
        """Only configured precedents and mandatory local corrections, never curated channels."""
        from app.core.automap_policy import POLICY_VERSION

        links = self._get_link_scope(project_id=project_id, sttm_id=sttm_id)
        if links.get("errors"):
            raise ContextPrecedentUnavailableError("Configured precedent links could not be read")
        if links["project_ids"] and target_table:
            projects = links["project_ids"]
            rows = self._session.sql(
                f"SELECT STTM_ID, PROJECT_ID FROM {self._settings.qualify_table_name('TBL_STTM')} "
                f"WHERE TO_VARCHAR(PROJECT_ID) IN ({','.join('?' for _ in projects)}) "
                "AND UPPER(TARGET_TABLE) = UPPER(?) AND UPPER(STATUS) IN ('COMPLETE', 'PUBLISHED') "
                "AND COALESCE(RUNTIME_SUPPRESSED, FALSE) = FALSE ORDER BY STTM_ID",
                params=[*projects, target_table],
            ).collect()
            for row in rows:
                item = row.as_dict()
                identifier = str(item["STTM_ID"])
                if identifier not in links["sttm_ids"]:
                    links["sttm_ids"].append(identifier)
                    parent = next((value for value in links["explanations"]
                                   if str(value.get("precedent_project_id")) == str(item["PROJECT_ID"])), {})
                    links["explanations"].append({**parent, "precedent_sttm_id": identifier})
        precedents = self._get_mapping_precedents(
            linked_sttm_ids=links["sttm_ids"], link_explanations=links["explanations"],
            target_columns=target_columns, require_published_snapshot=True,
        )
        loaded = {item.precedent_sttm_id for item in precedents}
        if set(links["sttm_ids"]) - loaded:
            raise ContextPrecedentUnavailableError("A selected published precedent could not be loaded")
        for precedent in precedents:
            category_names = {"column_mapping": "mappings", "transformation": "transformations",
                              "relationship": "relationships", "query_shaping": "query_shaping",
                              "derived_lineage": "derived_lineage"}
            categories = {category_names.get(value, value) for value in precedent.knowledge_categories}
            if categories:
                if not categories & {"mappings", "transformations", "all"}:
                    precedent.mappings = []
                elif "mappings" in categories and not categories & {"transformations", "all"}:
                    precedent.mappings = [{key: value for key, value in row.items()
                                           if key not in {"preprocessing_rule", "expression", "transformation_logic", "condition"}}
                                          for row in precedent.mappings]
                if not categories & {"relationships", "all"}:
                    precedent.relationships = []
                if not categories & {"query_shaping", "all"}:
                    precedent.filters = []
                    precedent.business_rules = []
                if not categories & {"derived_lineage", "all"}:
                    precedent.ctes = []
                    precedent.derived_sources = []
            # Preserve placeholder contracts, never offer a historical project literal
            # as a current constant when the configured link prohibits reuse.
            if not precedent.allow_project_specific_values:
                for row in precedent.mappings:
                    if row.get("constant_value") is not None and not str(row["constant_value"]).startswith("$"):
                        row["constant_value"] = None
                        row["historical_literal_reuse_allowed"] = False
                    condition = row.get("condition")
                    if isinstance(condition, dict):
                        row["condition"] = {key: value for key, value in condition.items()
                                            if key not in {"constant_value", "resolved_value", "attribute_value"}}
        corrections, diagnostic = self._retrieve_audited(
            "_get_correction_history", (project_id, target_columns), {"sttm_id": sttm_id}, False,
        )
        if diagnostic["status"] == "error":
            raise ContextPrecedentUnavailableError("Mandatory correction evidence could not be loaded")
        project, project_diagnostic = self._retrieve_audited(
            "_get_auto_map_project_context", (project_id, sttm_id), {}, False,
        )
        if project_diagnostic["status"] == "error":
            raise ContextPrecedentUnavailableError("Authoritative project context could not be loaded")
        return LearningContext(automap_policy_version=POLICY_VERSION,
            linked_project_ids=links["project_ids"], linked_mapping_ids=links["sttm_ids"],
            mapping_precedents=precedents, correction_history=corrections,
            project_context=project or None,
            retrieval_explanations=links["explanations"],
            retrieval_diagnostics={"correction_history": diagnostic, "project_context": project_diagnostic})

    def _get_auto_map_project_context(self, project_id: str, sttm_id: str | None) -> ProjectContextItem | None:
        """One scoped metadata read; no project-wide mapping history or profiling."""
        rows = self._session.sql(
            f"SELECT TO_VARCHAR(p.PROJECT_ID) AS PROJECT_ID, p.PROJECT_NAME, "
            "p.DESCRIPTION AS PROJECT_DESCRIPTION, p.PROJECT_METADATA:domain::STRING AS DOMAIN, "
            "p.PROJECT_METADATA:intended_outcome::STRING AS INTENDED_OUTCOME, "
            "p.PROJECT_METADATA:business_process::STRING AS BUSINESS_PROCESS, "
            "p.PROJECT_METADATA:source_system_key::STRING AS SOURCE_SYSTEM_KEY, "
            "TO_VARCHAR(s.STTM_ID) AS STTM_ID, s.STTM_NAME, s.DESCRIPTION AS STTM_DESCRIPTION, s.STATUS AS STTM_STATUS "
            f"FROM {self._settings.qualify_table_name('TBL_PROJECTS')} p "
            f"LEFT JOIN {self._settings.qualify_table_name('TBL_STTM')} s "
            "ON s.PROJECT_ID = p.PROJECT_ID AND TO_VARCHAR(s.STTM_ID) = ? "
            "WHERE TO_VARCHAR(p.PROJECT_ID) = ?",
            params=[sttm_id, project_id],
        ).collect()
        if not rows:
            return None
        if len(rows) != 1:
            raise ValueError("Ambiguous project context")
        data = rows[0].as_dict()
        if str(data.get("PROJECT_ID")) != project_id or (sttm_id and str(data.get("STTM_ID")) != sttm_id):
            raise ValueError("Mapping does not belong to the requested project")
        return ProjectContextItem(**{key.lower(): value for key, value in data.items()})

    def _get_mapping_precedents(
        self,
        *,
        linked_sttm_ids: list[str],
        link_explanations: list[dict[str, Any]],
        target_columns: list[str],
        require_published_snapshot: bool = False,
    ) -> list[MappingPrecedentContext]:
        if not linked_sttm_ids:
            return []
        sttm_literals = ", ".join(self._quote(value) for value in linked_sttm_ids)
        target_filter = ""
        if target_columns:
            target_literals = ", ".join(self._quote(value.upper()) for value in target_columns)
            target_filter = f"AND UPPER(a.ATTRIBUTE_NAME) IN ({target_literals})"
        metadata_rows = self._session.sql(
            f"""
            SELECT s.STTM_ID, s.PROJECT_ID, s.STATUS, s.CURRENT_VERSION,
                   s.LAST_SNAPSHOT_ID, s.PARSED_MAPPING_MODEL, s.RAW_MAPPING_SQL,
                   v.VERSION_PAYLOAD AS PUBLISHED_SNAPSHOT,
                   v.SNAPSHOT_ID AS PUBLISHED_SNAPSHOT_ID,
                   v.PARSED_MAPPING_MODEL AS PUBLISHED_MAPPING_MODEL,
                   v.RAW_MAPPING_SQL AS PUBLISHED_MAPPING_SQL
            FROM {self._settings.qualify_table_name('TBL_STTM')} s
            JOIN {self._settings.qualify_table_name('TBL_PROJECTS')} p
              ON p.PROJECT_ID = s.PROJECT_ID
            LEFT JOIN {self._settings.qualify_table_name('TBL_STTM_VERSIONS')} v
              ON v.STTM_ID = s.STTM_ID AND v.VERSION_NUMBER = s.CURRENT_VERSION
            WHERE TO_VARCHAR(s.STTM_ID) IN ({sttm_literals})
              AND UPPER(COALESCE(s.STATUS, '')) IN ('COMPLETE', 'PUBLISHED')
              AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE
              AND UPPER(COALESCE(p.STATUS, 'ACTIVE')) <> 'ARCHIVED'
              AND COALESCE(p.RUNTIME_SUPPRESSED, FALSE) = FALSE
            """
        ).collect()
        attribute_rows = self._session.sql(
            f"""
            SELECT a.STTM_ID, a.ATTRIBUTE_ID, a.ATTRIBUTE_NAME, a.SOURCE_COLUMN,
                   a.DATA_TYPE, a.TRANSFORMATION_LOGIC, a.DESCRIPTION, a.CONDITION,
                   a.EFFECTIVE_FROM_VERSION, a.EFFECTIVE_THROUGH_VERSION
            FROM {self._settings.qualify_table_name('TBL_STTM_ATTRIBUTES')} a
            JOIN {self._settings.qualify_table_name('TBL_STTM')} s
              ON s.STTM_ID = a.STTM_ID
            WHERE TO_VARCHAR(a.STTM_ID) IN ({sttm_literals})
              {target_filter}
              AND COALESCE(a.IS_DRAFT, FALSE) = FALSE
              AND (a.EFFECTIVE_FROM_VERSION IS NULL OR a.EFFECTIVE_FROM_VERSION <= s.CURRENT_VERSION)
              AND (a.EFFECTIVE_THROUGH_VERSION IS NULL OR a.EFFECTIVE_THROUGH_VERSION >= s.CURRENT_VERSION)
            QUALIFY ROW_NUMBER() OVER (
                PARTITION BY a.STTM_ID, UPPER(a.ATTRIBUTE_NAME)
                ORDER BY COALESCE(a.EFFECTIVE_FROM_VERSION, 0) DESC, a.ATTRIBUTE_ID DESC
            ) = 1
            ORDER BY a.STTM_ID, a.ATTRIBUTE_ID
            """
        ).collect()
        mappings_by_sttm: dict[str, list[dict[str, Any]]] = {}
        for row in attribute_rows:
            data = row.as_dict()
            condition = self._parse_json(data.get("CONDITION")) or {}
            source_columns = self._parse_string_list(condition.get("source_columns"))
            if not source_columns:
                source_columns = self._parse_source_columns(data.get("SOURCE_COLUMN"))
            constant_value = condition.get("constant_value")
            attribute_name = condition.get("attribute_name")
            mapping_mode = str(condition.get("mapping_mode") or "").lower()
            if not mapping_mode:
                mapping_mode = "constant" if constant_value is not None else "source"
            imported_rule_label = str(condition.get("preprocessing_rule") or "").strip()
            imported_rule_type = str(
                condition.get("preprocessing_rule_type")
                or imported_rule_label
                or ("Value" if mapping_mode in {"constant", "attribute"} else "Direct")
            ).strip()
            transformation_logic = data.get("TRANSFORMATION_LOGIC")
            preprocessing_rule = published_expression({
                **condition, "transformation": transformation_logic,
            }) or ("Direct" if imported_rule_type.upper() == "DIRECT" else None)
            mappings_by_sttm.setdefault(str(data.get("STTM_ID")), []).append(
                {
                    "mapping_id": str(data.get("ATTRIBUTE_ID") or ""),
                    "target_column": str(data.get("ATTRIBUTE_NAME") or ""),
                    "target_type": data.get("DATA_TYPE"),
                    "mapping_mode": (
                        mapping_mode if mapping_mode in {"constant", "attribute"} else "source"
                    ),
                    "source_columns": source_columns,
                    "constant_value": constant_value,
                    "attribute_name": attribute_name,
                    "preprocessing_rule": preprocessing_rule,
                    "preprocessing_rule_type": imported_rule_type,
                    "description": data.get("DESCRIPTION"),
                    "condition": condition,
                }
            )

        explanation_by_sttm = {
            str(item.get("precedent_sttm_id")): item
            for item in link_explanations
            if item.get("precedent_sttm_id")
        }
        precedents: list[MappingPrecedentContext] = []
        for row in metadata_rows:
            data = row.as_dict()
            precedent_id = str(data.get("STTM_ID") or "")
            snapshot = self._parse_json(data.get("PUBLISHED_SNAPSHOT"))
            published = isinstance(snapshot, dict)
            if require_published_snapshot and (not published or "mapping_rows" not in snapshot):
                raise ContextPrecedentUnavailableError("Selected precedent has no canonical published mapping snapshot")
            snapshot = snapshot if published else {}
            parsed = self._parse_json(data.get("PUBLISHED_MAPPING_MODEL") if published else data.get("PARSED_MAPPING_MODEL")) or snapshot.get("parsed_mapping_model") or {}
            explanation = explanation_by_sttm.get(precedent_id, {})
            raw_sql = str(((data.get("PUBLISHED_MAPPING_SQL") or snapshot.get("raw_mapping_sql") or snapshot.get("mapping_sql")) if published else data.get("RAW_MAPPING_SQL")) or "")
            mappings = mappings_by_sttm.get(precedent_id, [])
            if published:
                targets = {str(column).upper() for column in target_columns}
                mappings = []
                for mapping in snapshot.get("mapping_rows") or []:
                    if not isinstance(mapping, dict) or (targets and str(mapping.get("target_column") or "").upper() not in targets):
                        continue
                    rule_type = mapping.get("preprocessing_rule_type") or mapping.get("rule") or "Direct"
                    mappings.append({
                        **mapping,
                        "mapping_id": mapping.get("id"),
                        "preprocessing_rule_type": rule_type,
                        "preprocessing_rule": published_expression(mapping) or ("Direct" if str(rule_type).upper() == "DIRECT" else None),
                    })
            graph = snapshot.get("relation_graph") or {}
            precedents.append(
                MappingPrecedentContext(
                    precedent_sttm_id=precedent_id,
                    precedent_project_id=str(data.get("PROJECT_ID") or "") or None,
                    compatibility=explanation.get("target_compatibility"),
                    confidence=float(explanation.get("confidence") or 1.0),
                    priority=int(explanation.get("priority") or 0),
                    knowledge_categories=explanation.get("knowledge_categories") or [],
                    allow_project_specific_values=bool(
                        explanation.get("allow_project_specific_values")
                    ),
                    mappings=mappings,
                    relationships=graph.get("edges") or snapshot.get("relationships") or parsed.get("join_patterns") or parsed.get("relationships") or [],
                    filters=parsed.get("filters") or (snapshot.get("filters") or {}).get("conditions") or [],
                    ctes=parsed.get("ctes") or [],
                    derived_sources=snapshot.get("derived_sources") or parsed.get("derived_source_candidates")
                    or parsed.get("derived_sources")
                    or [],
                    business_rules=parsed.get("business_rules") or [],
                    alias_contract=parsed.get("table_aliases") or {node["alias"]: node.get("relation_id") for node in graph.get("nodes") or [] if node.get("alias")},
                    raw_sql_hash=(
                        hashlib.sha256(raw_sql.encode("utf-8")).hexdigest()
                        if raw_sql
                        else None
                    ),
                    snapshot_id=optional_identifier(data.get("PUBLISHED_SNAPSHOT_ID") if published else data.get("LAST_SNAPSHOT_ID")),
                )
            )
        return sorted(precedents, key=lambda item: (-item.priority, item.precedent_sttm_id))

    def _get_semantic_learnings(
        self,
        target_columns: list[str],
        limit: int = 10,
        *,
        project_id: str | None = None,
        target_table: str | None = None,
        context_key: str | None = None,
    ) -> list[SemanticLearningItem]:
        """Retrieve explicitly scoped semantic evidence using its stored VARIANT contract."""
        try:
            if not target_columns or not target_table:
                return []
            target_literals = ", ".join(self._quote(column.upper()) for column in target_columns)
            qualified_literals = ", ".join(self._quote(f"{target_table}.{column}".upper()) for column in target_columns)
            scopes = []
            if project_id:
                scopes.append(f"learning.ATTRIBUTES:project_id::STRING = {self._quote(project_id)}")
            if context_key:
                scopes.append(
                    f"(learning.ATTRIBUTES:context_key::STRING = {self._quote(context_key)} "
                    f"AND (NULLIF(learning.ATTRIBUTES:project_id::STRING, '') IS NULL "
                    f"OR learning.ATTRIBUTES:project_id::STRING = {self._quote(project_id or '')}))"
                )
            scopes.append("(LOWER(learning.ATTRIBUTES:scope::STRING) IN ('client', 'global') "
                          "AND NULLIF(learning.ATTRIBUTES:project_id::STRING, '') IS NULL "
                          "AND NULLIF(learning.ATTRIBUTES:context_key::STRING, '') IS NULL)")

            query = f"""
            SELECT DISTINCT
                learning.LEARNING_ID as learning_id,
                learning.LEARNING_TYPE as learning_type,
                learning.SUMMARY as summary,
                COALESCE(learning.CONFIDENCE, 0.7) as confidence,
                COALESCE(learning.ATTRIBUTES:applies_to, ARRAY_CONSTRUCT()) as applies_to,
                learning.ATTRIBUTES:correct_interpretation::STRING as correct_interpretation,
                learning.ATTRIBUTES:incorrect_interpretation::STRING as incorrect_interpretation,
                learning.UPDATED_AT
            FROM {self._settings.qualify_table_name(self._settings.snowflake_semantic_learnings_table)} learning,
                 LATERAL FLATTEN(INPUT => learning.ATTRIBUTES:applies_to, OUTER => TRUE) item
            WHERE COALESCE(LOWER(learning.ATTRIBUTES:status::STRING), 'active') = 'active'
              AND COALESCE(UPPER(learning.ATTRIBUTES:trust_stage::STRING), '') NOT IN ('REJECTED', 'SUPERSEDED')
              AND NULLIF(learning.ATTRIBUTES:superseded_by::STRING, '') IS NULL
              AND learning.LEARNING_TYPE IN ('column_disambiguation', 'transformation_pattern', 'domain_vocabulary')
              AND ({' OR '.join(scopes)})
              AND (UPPER(learning.ATTRIBUTES:target_table::STRING) = {self._quote(target_table.upper())}
                   OR NULLIF(learning.ATTRIBUTES:target_table::STRING, '') IS NULL)
              AND (UPPER(learning.ATTRIBUTES:target_column::STRING) IN ({target_literals})
                   OR UPPER(item.VALUE::STRING) IN ({target_literals}, {qualified_literals}))
            ORDER BY confidence DESC, learning.UPDATED_AT DESC, learning.LEARNING_ID
            LIMIT {max(1, min(limit, 100))}
            """

            rows = self._session.sql(query).collect()
            return [
                SemanticLearningItem(
                    learning_id=str(row["LEARNING_ID"] or ""),
                    learning_type=str(row["LEARNING_TYPE"] or ""),
                    summary=str(row["SUMMARY"] or ""),
                    confidence=float(row["CONFIDENCE"]) if row["CONFIDENCE"] is not None else 0.7,
                    applies_to=self._parse_string_list(row["APPLIES_TO"]),
                    correct_interpretation=row["CORRECT_INTERPRETATION"],
                    incorrect_interpretation=row["INCORRECT_INTERPRETATION"],
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get semantic learnings: %s", exc)
            _record_retrieval_error(exc)
            return []

    def _get_or_infer_mapping_intent(
        self,
        project_id: str,
        target_table: str,
        source_tables: list[str],
        provided_intent: dict[str, Any] | None,
        *,
        context_key: str | None = None,
    ) -> MappingIntentItem | None:
        """Get existing mapping intent or infer from context."""
        if provided_intent:
            return MappingIntentItem(
                intent_id=str(provided_intent.get("intent_id") or ""),
                business_goal=str(provided_intent.get("business_goal") or ""),
                target_outcome=str(provided_intent.get("target_outcome") or ""),
                lifecycle=str(provided_intent.get("lifecycle") or "initial"),
                domain_hints=self._parse_string_list(provided_intent.get("domain_hints")),
                captured_from=str(provided_intent.get("captured_from") or "user_response"),
                # Browser/workspace payloads preserve an explicitly unknown
                # confidence as JSON null.  Treat that the same as an omitted
                # confidence instead of letting float(None) discard the whole
                # linked-precedent context.
                confidence=float(provided_intent.get("confidence") or 0.8),
            )

        if not context_key:
            return None
        try:
            query = f"""
            SELECT
                INTENT_ID as intent_id,
                BUSINESS_GOAL as business_goal,
                TARGET_OUTCOME as target_outcome,
                COALESCE(LIFECYCLE, 'initial') as lifecycle,
                COALESCE(DOMAIN_HINTS, ARRAY_CONSTRUCT()) as domain_hints,
                COALESCE(SOURCE, 'inferred') as captured_from,
                COALESCE(CONFIDENCE, 0.7) as confidence
            FROM {self._settings.qualify_table_name(self._settings.snowflake_mapping_intents_table)}
            WHERE CONTEXT_KEY = {self._quote(context_key)}
              AND TARGET_TABLE = {self._quote(target_table)}
            ORDER BY UPDATED_AT DESC
            LIMIT 1
            """

            rows = self._session.sql(query).collect()
            if rows:
                row = rows[0]
                return MappingIntentItem(
                    intent_id=str(row["INTENT_ID"] or ""),
                    business_goal=str(row["BUSINESS_GOAL"] or ""),
                    target_outcome=str(row["TARGET_OUTCOME"] or ""),
                    lifecycle=str(row["LIFECYCLE"] or "initial"),
                    domain_hints=self._parse_string_list(row["DOMAIN_HINTS"]),
                    captured_from=str(row["CAPTURED_FROM"] or "inferred"),
                    confidence=float(row["CONFIDENCE"]) if row["CONFIDENCE"] else 0.7,
                )
        except Exception as exc:
            logger.debug("Failed to get mapping intent: %s", exc)
            _record_retrieval_error(exc)

        return None

    def _get_project_context(
        self,
        project_id: str,
        source_tables: list[str],
        sttm_id: str | None = None,
    ) -> ProjectContextItem | None:
        """Build project context including stats, common patterns, and STTM details."""
        try:
            query = f"""
            SELECT
                p.PROJECT_ID as project_id,
                p.PROJECT_NAME as project_name,
                p.DESCRIPTION as project_description,
                ANY_VALUE(p.PROJECT_METADATA:domain::STRING) as project_domain,
                ANY_VALUE(p.PROJECT_METADATA:intended_outcome::STRING) as intended_outcome,
                ANY_VALUE(p.PROJECT_METADATA:business_process::STRING) as business_process,
                ANY_VALUE(p.PROJECT_METADATA:source_system_key::STRING) as source_system_key,
                COUNT(DISTINCT s.STTM_ID) as sttm_count,
                COUNT(DISTINCT v.STTM_ID) as published_count
            FROM {self._settings.qualify_table_name('TBL_PROJECTS')} p
            LEFT JOIN {self._settings.qualify_table_name('TBL_STTM')} s ON p.PROJECT_ID = s.PROJECT_ID
            LEFT JOIN (
                SELECT DISTINCT STTM_ID FROM {self._settings.qualify_table_name('TBL_STTM_VERSIONS')}
            ) v ON v.STTM_ID = s.STTM_ID
            WHERE p.PROJECT_ID = {self._quote(project_id)}
            GROUP BY p.PROJECT_ID, p.PROJECT_NAME, p.DESCRIPTION
            """

            rows = self._session.sql(query).collect()
            if not rows:
                return None

            row = rows[0]

            def _text(key: str) -> str | None:
                value = str(row[key] or "").strip() if row[key] is not None else ""
                return value or None

            context = ProjectContextItem(
                project_id=str(row["PROJECT_ID"] or ""),
                project_name=str(row["PROJECT_NAME"] or ""),
                project_description=_text("PROJECT_DESCRIPTION"),
                domain=_text("PROJECT_DOMAIN"),
                intended_outcome=_text("INTENDED_OUTCOME"),
                business_process=_text("BUSINESS_PROCESS"),
                source_system_key=_text("SOURCE_SYSTEM_KEY"),
                sttm_count=int(row["STTM_COUNT"]) if row["STTM_COUNT"] else 0,
                published_count=int(row["PUBLISHED_COUNT"]) if row["PUBLISHED_COUNT"] else 0,
                common_patterns=[],
                common_source_tables=source_tables[:5],
                related_sttms=[],
            )

            # Fetch STTM details if sttm_id is provided
            if sttm_id:
                sttm_query = f"""
                SELECT
                    STTM_ID,
                    STTM_NAME,
                    DESCRIPTION,
                    STATUS
                FROM {self._settings.qualify_table_name('TBL_STTM')}
                WHERE STTM_ID = {self._quote(sttm_id)}
                LIMIT 1
                """
                sttm_rows = self._session.sql(sttm_query).collect()
                if sttm_rows:
                    sttm_row = sttm_rows[0]
                    context.sttm_id = str(sttm_row["STTM_ID"] or "")
                    context.sttm_name = str(sttm_row["STTM_NAME"] or "") if sttm_row["STTM_NAME"] else None
                    context.sttm_description = str(sttm_row["DESCRIPTION"] or "") if sttm_row["DESCRIPTION"] else None
                    context.sttm_status = str(sttm_row["STATUS"] or "") if sttm_row["STATUS"] else None

            return context
        except Exception as exc:
            logger.debug("Failed to get project context: %s", exc)

        return None

    def _get_project_derived_sources(
        self,
        project_id: str,
        source_tables: list[str],
        limit: int = 25,
    ) -> list[dict[str, Any]]:
        """Latest derived sources of the project (and legacy ones over these sources).

        Compact by design: the agent needs names, purpose and outputs to decide
        whether an existing CTE already answers the request, not the SQL itself.
        """
        table = self._settings.qualify_metadata_object_name(
            self._settings.snowflake_derived_sources_table
        )
        sources = self._quote_list(source_tables, upper=True)
        try:
            rows = self._session.sql(
                f"""
                WITH d AS (
                    SELECT DERIVED_SOURCE_ID, DERIVED_SOURCE_NAME, PURPOSE, BUSINESS_DESCRIPTION,
                           SEMANTIC_PROJECTION:description::STRING AS PROJECTED_DESCRIPTION,
                           OUTPUT_COLUMNS, SOURCE_TABLES, PHYSICAL_VIEW_NAME, UPDATED_AT,
                           COALESCE(SEMANTIC_PROJECTION:versioning:version::NUMBER, 1) AS VERSION,
                           COALESCE(SEMANTIC_PROJECTION:versioning:project_id::STRING, '') AS OWNER_PROJECT,
                           COALESCE(
                               SEMANTIC_PROJECTION:versioning:sql_hash::STRING,
                               SHA2(TRIM(REGEXP_REPLACE(SQL_TEXT, '[[:space:]]+', ' ')), 256)
                           ) AS SQL_HASH
                    FROM {table}
                    WHERE IS_ACTIVE = TRUE
                      AND COALESCE(SEMANTIC_PROJECTION:versioning:is_latest::BOOLEAN, TRUE)
                      AND COALESCE(SEMANTIC_PROJECTION:versioning:project_id::STRING, '')
                          IN ({self._quote(project_id)}, '')
                ),
                legacy_overlap AS (
                    SELECT DISTINCT d.DERIVED_SOURCE_ID
                    FROM d, LATERAL FLATTEN(input => d.SOURCE_TABLES) f
                    WHERE d.OWNER_PROJECT = ''
                      AND UPPER(f.value:database::STRING || '.' || f.value:schema::STRING || '.'
                                || f.value:table::STRING) IN ({sources})
                )
                SELECT *
                FROM d
                WHERE OWNER_PROJECT = {self._quote(project_id)}
                   OR DERIVED_SOURCE_ID IN (SELECT DERIVED_SOURCE_ID FROM legacy_overlap)
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY SQL_HASH
                    ORDER BY IFF(OWNER_PROJECT = '', 1, 0), UPDATED_AT DESC
                ) = 1
                ORDER BY IFF(OWNER_PROJECT = '', 1, 0), UPDATED_AT DESC
                LIMIT {max(1, int(limit))}
                """
            ).collect()
        except Exception as exc:
            logger.debug("Project derived-source catalog unavailable: %s", exc)
            return []
        catalog: list[dict[str, Any]] = []
        for row in rows:
            data = row.as_dict()

            def _json(value: Any) -> Any:
                if isinstance(value, str):
                    try:
                        return json.loads(value)
                    except json.JSONDecodeError:
                        return []
                return value or []

            outputs = [
                str(item.get("name") or item.get("column_name"))
                for item in _json(data.get("OUTPUT_COLUMNS"))
                if isinstance(item, dict) and (item.get("name") or item.get("column_name"))
            ]
            tables = [
                ".".join(str(item.get(key) or "") for key in ("database", "schema", "table"))
                for item in _json(data.get("SOURCE_TABLES"))
                if isinstance(item, dict)
            ]
            description = next(
                (
                    str(value).strip()
                    for value in (
                        data.get("BUSINESS_DESCRIPTION"),
                        data.get("PURPOSE"),
                        data.get("PROJECTED_DESCRIPTION"),
                    )
                    if str(value or "").strip()
                    # Older editor builds saved placeholder text that says nothing.
                    and not PLACEHOLDER_DESCRIPTION.match(str(value).strip())
                ),
                "",
            )
            catalog.append(
                {
                    "derived_source_id": str(data.get("DERIVED_SOURCE_ID") or ""),
                    "name": str(data.get("DERIVED_SOURCE_NAME") or ""),
                    "version": int(data.get("VERSION") or 1),
                    "description": description[:240],
                    "source_tables": tables,
                    "output_columns": outputs[:20],
                    "physical_view_name": data.get("PHYSICAL_VIEW_NAME"),
                    "sql_hash": str(data.get("SQL_HASH") or ""),
                    "scope": "project" if data.get("OWNER_PROJECT") else "legacy",
                }
            )
        return catalog

    def _get_cross_project_patterns(
        self,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        limit: int = 5,
        *,
        linked_project_ids: list[str] | None = None,
    ) -> list[CrossProjectPatternItem]:
        """Find reusable patterns from other projects."""
        if not linked_project_ids:
            return []
        try:
            target_cols_list = self._quote_list(target_columns, upper=True)
            project_scope = ", ".join(self._quote(value) for value in linked_project_ids)

            query = f"""
            SELECT
                INFERENCE_ID as pattern_id,
                INFERENCE_TYPE as pattern_type,
                SUMMARY as description,
                ATTRIBUTES as example_mapping,
                ARRAY_CONSTRUCT(ATTRIBUTES:project_id::STRING) as source_projects,
                1 as usage_count,
                COALESCE(CONFIDENCE, 0.8) as avg_confidence,
                ATTRIBUTES:reusability::STRING = 'highly_reusable' as is_recommended
            FROM {self._settings.qualify_table_name(self._settings.snowflake_assistant_inferences_table)}
            WHERE STATUS = 'active'
              AND INFERENCE_TYPE IN ('mapping_acceptance_learning', 'sttm_publish_learning')
              AND ATTRIBUTES:reusability::STRING IN ('highly_reusable', 'table_specific')
              AND UPPER(ATTRIBUTES:target_column::STRING) IN ({target_cols_list})
              AND ATTRIBUTES:project_id::STRING IN ({project_scope})
            ORDER BY avg_confidence DESC
            LIMIT {limit}
            """

            rows = self._session.sql(query).collect()
            return [
                CrossProjectPatternItem(
                    pattern_id=str(row["PATTERN_ID"] or ""),
                    pattern_type=str(row["PATTERN_TYPE"] or "mapping_pattern"),
                    description=str(row["DESCRIPTION"] or ""),
                    example_mapping=self._parse_json(row["EXAMPLE_MAPPING"]) or {},
                    source_projects=self._parse_string_list(row["SOURCE_PROJECTS"]),
                    usage_count=int(row["USAGE_COUNT"]) if row["USAGE_COUNT"] else 1,
                    avg_confidence=float(row["AVG_CONFIDENCE"]) if row["AVG_CONFIDENCE"] else 0.8,
                    is_recommended=bool(row["IS_RECOMMENDED"]),
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get cross-project patterns: %s", exc)
            _record_retrieval_error(exc)
            return []

    def _get_correction_history(
        self,
        project_id: str,
        target_columns: list[str],
        limit: int = 10,
        *,
        sttm_id: str | None = None,
    ) -> list[CorrectionHistoryItem]:
        """Get history of corrections to avoid repeating mistakes."""
        if not project_id or not target_columns:
            return []
        try:
            target_cols_list = self._quote_list(target_columns, upper=True)
            iterative = getattr(self._settings, "automap_context_retrieval_v1", False)
            correction_scope = (
                f"ATTRIBUTES:project_id::STRING = {self._quote(project_id)} "
                f"AND (ATTRIBUTES:target_column IS NULL OR UPPER(ATTRIBUTES:target_column::STRING) IN ({target_cols_list}))"
            )
            if sttm_id:
                correction_scope += f" AND (ATTRIBUTES:sttm_id IS NULL OR ATTRIBUTES:sttm_id::STRING = {self._quote(sttm_id)})"
            limit_clause = "" if iterative else f"LIMIT {limit}"

            query = f"""
            SELECT
                INFERENCE_ID as correction_id,
                ATTRIBUTES:target_column::STRING as target_column,
                COALESCE(ATTRIBUTES:before_source_columns, ARRAY_CONSTRUCT()) as incorrect_source,
                COALESCE(ATTRIBUTES:after_source_columns, ARRAY_CONSTRUCT()) as correct_source,
                COALESCE(ATTRIBUTES:error_category::STRING, 'unknown') as error_category,
                COALESCE(ATTRIBUTES:prevention_hint::STRING, '') as prevention_hint,
                1 as correction_count
            FROM {self._settings.qualify_table_name(self._settings.snowflake_assistant_inferences_table)}
            WHERE INFERENCE_TYPE = 'mapping_edit_learning'
              AND ATTRIBUTES:was_correction::BOOLEAN = TRUE
              AND (
                  {correction_scope}
              )
            ORDER BY CREATED_AT DESC
            {limit_clause}
            """

            rows = self._session.sql(query).collect()
            corrections = [
                CorrectionHistoryItem(
                    correction_id=str(row["CORRECTION_ID"] or ""),
                    target_column=str(row["TARGET_COLUMN"] or ""),
                    incorrect_source=self._parse_string_list(row["INCORRECT_SOURCE"]),
                    correct_source=self._parse_string_list(row["CORRECT_SOURCE"]),
                    error_category=str(row["ERROR_CATEGORY"] or "unknown"),
                    prevention_hint=str(row["PREVENTION_HINT"] or ""),
                    correction_count=int(row["CORRECTION_COUNT"]) if row["CORRECTION_COUNT"] else 1,
                )
                for row in rows
            ]
            if sttm_id:
                corrections.extend(self._get_saved_corrections(project_id, sttm_id, target_columns))
            return corrections
        except Exception as exc:
            logger.debug("Failed to get correction history: %s", exc)
            _record_retrieval_error(exc)
            return []

    def _get_saved_corrections(self, project_id: str, sttm_id: str,
                               target_columns: list[str]) -> list[CorrectionHistoryItem]:
        """Read explicit negatives directly, outside positive Search quotas."""
        from app.core.learning_evidence import capture_attributes

        rows = self._session.sql(
            f"SELECT LEARNING_ID, ATTRIBUTES, ENTITY_IDS FROM "
            f"{self._settings.qualify_table_name('TBL_AGENT_LEARNINGS')} "
            "WHERE AGENT_TYPE = 'SOURCE_MAPPING' AND LEARNING_TYPE = 'mapping_correction' "
            "AND STATUS = 'active' AND SUPERSEDED_BY IS NULL AND TRUST_STAGE = 'corrected' "
            "AND ENTITY_IDS:project_id::STRING = ? AND ENTITY_IDS:sttm_id::STRING = ? "
            f"AND ATTRIBUTES:target_column::STRING IN ({', '.join('?' for _ in target_columns)}) "
            "ORDER BY CREATED_AT DESC, LEARNING_ID DESC",
            params=[project_id, sttm_id, *target_columns],
        ).collect()
        latest_decisions = {}
        corrections = []
        from app.core.learning_receipts import verify_receipts
        records = [row.as_dict() for row in rows]
        verified = verify_receipts(self._session, self._settings, [
            (str(data["LEARNING_ID"]), self._parse_json(data.get("ATTRIBUTES")) or {},
             self._parse_json(data.get("ENTITY_IDS")) or {}) for data in records])
        for data in records:
            if str(data["LEARNING_ID"]) not in verified:
                continue
            attributes = self._parse_json(data.get("ATTRIBUTES")) or {}
            owner = self._parse_json(data.get("ENTITY_IDS")) or {}
            if any(str(owner.get(key) or "") != value for key, value in
                   (("project_id", project_id), ("sttm_id", sttm_id))):
                continue
            if capture_attributes(attributes, owner)["trust_stage"] != "corrected":
                continue
            before, after = attributes.get("incorrect_decision"), attributes.get("correct_decision")
            target, scope = attributes.get("target_column"), attributes.get("scope_hash")
            if target not in target_columns or not scope or not isinstance(before, dict) or not isinstance(after, dict):
                continue
            latest = latest_decisions.setdefault((target, scope), after)
            if before == latest or before == after:
                continue  # A later explicit reversal must not ban its newly accepted decision.
            corrections.append(CorrectionHistoryItem(
                correction_id=str(data["LEARNING_ID"]), target_column=target,
                incorrect_source=before.get("source_columns") or [], correct_source=after.get("source_columns") or [],
                incorrect_decision=before, correct_decision=after, scope_hash=scope,
                error_category=str(attributes.get("error_category") or "explicit_saved_correction"),
                prevention_hint=str(attributes.get("prevention_hint") or ""), correction_count=1,
            ))
        return corrections

    def _parse_source_columns(self, value: Any) -> list[str]:
        """Parse source columns from various formats."""
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value if v]
        if isinstance(value, str):
            try:
                import json
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return [str(v) for v in parsed if v]
            except Exception:
                pass
            return [value] if value else []
        return []

    def _parse_string_list(self, value: Any) -> list[str]:
        """Parse a string list from various formats."""
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value if v]
        if isinstance(value, str):
            try:
                import json
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return [str(v) for v in parsed if v]
            except Exception:
                pass
            return [value] if value else []
        return []

    def _parse_json(self, value: Any) -> dict[str, Any] | None:
        """Parse JSON from various formats."""
        if value is None:
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            try:
                import json
                return json.loads(value)
            except Exception:
                pass
        return None

    def _parse_relationships(self, value: Any) -> list[dict[str, Any]]:
        if value is None:
            return []
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            nested = value.get("relationships")
            if isinstance(nested, list):
                return [item for item in nested if isinstance(item, dict)]
            return [value]
        if isinstance(value, str):
            try:
                import json

                return self._parse_relationships(json.loads(value))
            except Exception:
                return []
        return []

    # ─── Agent-Specific Learning Integration ───────────────────────────

    def get_agent_learnings(
        self,
        agent_type: str,
        query_context: dict[str, Any],
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Retrieve relevant learnings for a specific agent using Cortex Search.

        This is a convenience wrapper around AgentLearningService.

        Args:
            agent_type: The agent type (SOURCE_MAPPING, TRANSFORMATION_RULE, etc.)
            query_context: Context containing target_columns, source_tables, etc.
            max_results: Maximum number of learnings to return

        Returns:
            List of AgentLearning objects sorted by relevance
        """
        return self._agent_learning_service.get_agent_learnings(
            agent_type, query_context, max_results
        )

    def get_source_mapping_learnings(
        self,
        target_columns: list[str],
        source_tables: list[str],
        project_id: str | None = None,
        target_table: str | None = None,
        linked_project_ids: list[str] | None = None,
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Get learnings specific to source mapping operations.

        Combines:
        - Similar mappings from past acceptances
        - Corrections to avoid
        - Transformation patterns
        """
        query_context = {
            "target_columns": target_columns,
            "source_tables": source_tables,
        }
        if project_id:
            query_context["project_id"] = project_id

        learnings = self._agent_learning_service.get_agent_learnings(
            "SOURCE_MAPPING", query_context, max_results
        )

        correction_learnings = self._agent_learning_service.get_correction_history(
            "SOURCE_MAPPING",
            target_columns,
            max_results=5,
            target_table=target_table,
            project_id=project_id,
            linked_project_ids=linked_project_ids,
        )

        all_learnings = learnings + correction_learnings
        seen_ids = set()
        deduped = []
        for learning in all_learnings:
            if learning.learning_id not in seen_ids:
                seen_ids.add(learning.learning_id)
                deduped.append(learning)

        return sorted(deduped, key=lambda x: -x.confidence)[:max_results]

    def _get_scoped_agent_evidence(self, *, agent_type, project_id, target_table, target_columns) -> list[dict]:
        items = self._agent_learning_service.get_scoped_mapping_learnings(
            agent_type=agent_type, project_id=project_id, target_table=target_table,
            target_columns=target_columns,
        )
        results = []
        for item in items:
            attributes = item.attributes
            expression = published_expression({
                **attributes,
                "expression": attributes.get("rule_expression") or attributes.get("expression"),
            })
            results.append({
                "learning_id": item.learning_id,
                "learning_type": item.learning_type,
                "rule_type": attributes.get("rule_type") or attributes.get("preprocessing_rule_type"),
                "rule_expression": expression or None,
                "description": item.summary,
                "source_columns": attributes.get("source_columns") or [],
                "target_column": attributes.get("target_column"),
                "confidence": item.confidence,
                "scope": "project",
                "project_id": project_id,
            })
        return results

    def get_transformation_learnings(
        self,
        target_columns: list[str],
        rule_types: list[str] | None = None,
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Get learnings specific to transformation rules.

        Useful for AGT_TRANSFORMATION_RULE to suggest preprocessing patterns.
        """
        query_context = {
            "target_columns": target_columns,
        }
        if rule_types:
            query_context["rule_types"] = rule_types

        return self._agent_learning_service.get_agent_learnings(
            "TRANSFORMATION_RULE", query_context, max_results
        )

    def record_mapping_acceptance(
        self,
        target_column: str,
        source_columns: list[str],
        preprocessing_rule: str,
        preprocessing_rule_type: str,
        confidence_score: float,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
    ) -> str:
        """Record a mapping acceptance for future learning."""
        return self._agent_learning_service.record_mapping_acceptance(
            target_column=target_column,
            source_columns=source_columns,
            preprocessing_rule=preprocessing_rule,
            preprocessing_rule_type=preprocessing_rule_type,
            confidence_score=confidence_score,
            project_id=project_id,
            sttm_id=sttm_id,
            user_id=user_id,
        )

    def record_mapping_correction(
        self,
        target_column: str,
        incorrect_source: list[str],
        correct_source: list[str],
        error_category: str,
        prevention_hint: str,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
        target_table: str | None = None,
    ) -> str:
        """Record a mapping correction to avoid repeating mistakes."""
        return self._agent_learning_service.record_mapping_correction(
            target_column=target_column,
            incorrect_source=incorrect_source,
            correct_source=correct_source,
            error_category=error_category,
            prevention_hint=prevention_hint,
            project_id=project_id,
            sttm_id=sttm_id,
            user_id=user_id,
            target_table=target_table,
        )

    def record_user_preference(
        self,
        statement: str,
        *,
        scope: str,
        user_id: str,
        project_id: str | None = None,
        subject: str | None = None,
        conversation_id: str | None = None,
        run_id: str | None = None,
    ) -> str:
        """A durable preference the user stated in conversation, applied to later runs.

        ``scope`` is ``user`` (this user everywhere) or ``project`` (anyone
        working in this project). It starts as a candidate: it guides the
        supervisor and is shown to the user, but never overrides evidence.
        """
        owner = project_id if scope == "project" else user_id
        return self._agent_learning_service.record_learning(
            agent_type="DEEP_AGENT",
            learning_type="user_preference",
            summary=statement[:1000],
            attributes={"scope": scope, "subject": subject, "conversation_id": conversation_id, "run_id": run_id},
            entity_type=scope,
            entity_ids={"user_id": user_id, **({"project_id": project_id} if project_id else {})},
            tags=[f"scope:{scope}", *([f"subject:{subject}"] if subject else [])],
            confidence=0.8,
            user_id=user_id,
            subject_type=scope,
            subject_key=f"preference:{scope}:{owner}:{hashlib.sha256(statement.strip().lower().encode()).hexdigest()[:16]}",
            claim_key="user_preference",
            trust_stage="candidate",
        )

    def list_user_preferences(self, *, user_id: str, project_id: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
        """Active preferences for this user and, when given, this project; newest first."""
        schema = self._settings.qualify_metadata_object_name("TBL_AGENT_LEARNINGS")
        rows = self._session.sql(
            f"""SELECT LEARNING_ID, SUMMARY, ATTRIBUTES:scope::STRING SCOPE, ATTRIBUTES:subject::STRING SUBJECT,
                       CREATED_AT
                FROM {schema}
                WHERE LEARNING_TYPE = 'user_preference' AND STATUS = 'active'
                  AND COALESCE(TRUST_STAGE, '') <> 'superseded'
                  AND ((ENTITY_TYPE = 'user' AND ENTITY_IDS:user_id::STRING = ?)
                       OR (ENTITY_TYPE = 'project' AND ENTITY_IDS:project_id::STRING = COALESCE(?, '')))
                ORDER BY CREATED_AT DESC LIMIT ?""",
            [user_id, project_id or "", int(limit)],
        ).collect()
        return [{"learning_id": row["LEARNING_ID"], "statement": row["SUMMARY"], "scope": row["SCOPE"],
                 "subject": row["SUBJECT"]} for row in rows]

    def record_transformation_pattern(
        self,
        rule_type: str,
        rule_expression: str,
        description: str,
        source_columns: list[str],
        target_column: str,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
    ) -> str:
        """Record a transformation pattern for future suggestions."""
        return self._agent_learning_service.record_transformation_pattern(
            rule_type=rule_type,
            rule_expression=rule_expression,
            description=description,
            source_columns=source_columns,
            target_column=target_column,
            project_id=project_id,
            sttm_id=sttm_id,
            user_id=user_id,
        )

    def track_learning_usage(
        self,
        learning_id: str,
        was_successful: bool = True,
    ) -> None:
        """Track that a learning was used and whether it was successful."""
        self._agent_learning_service.track_learning_usage(learning_id, was_successful)

    def _get_fir_recommendations_for_context(
        self,
        project_id: str,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        context_key: str | None = None,
        source_set_hash: str | None = None,
        derived_set_hash: str | None = None,
        milestone: str | None = None,
        target_agent: str = "AGT_SOURCE_MAPPING",
        linked_project_ids: list[str] | None = None,
        linked_sttm_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch pre-computed FIR recommendations relevant to the current mapping context.

        Queries for multiple agent types/triggers to give agents a full picture
        of available pre-computed recommendations for the selected tables.
        """
        all_tables = list(source_tables)
        if target_table:
            all_tables.append(target_table)
        if not all_tables:
            return []

        trigger_type = (
            milestone
            or ("before_auto_map" if target_table else "selection_changed")
        )
        context = {
            "project_id": project_id,
            "table_names": all_tables,
            "column_names": target_columns,
            "context_key": context_key,
            "source_set_hash": source_set_hash,
            "target_fqn": target_table,
            "derived_set_hash": derived_set_hash,
            "milestone": milestone,
            "linked_project_ids": linked_project_ids or [],
            "linked_sttm_ids": linked_sttm_ids or [],
        }

        results = self.get_fir_recommendations(
            agent_type=target_agent,
            trigger_type=trigger_type,
            context=context,
            max_results=15,
        )
        if not results:
            from app.core.conversation_memory import ConversationMemoryService

            memory = ConversationMemoryService(self._session, self._settings)
            fallback = memory.find_fir_recommendations_for_context(
                selected_tables=source_tables,
                target_table=target_table or None,
                project_id=project_id or None,
                context_key=context_key,
                source_set_hash=source_set_hash,
                derived_set_hash=derived_set_hash,
                milestone=trigger_type,
                target_agent=target_agent,
                allow_search_fallback=True,
                limit=15,
            )
            results = [
                {
                    "source": "fir_system",
                    "recommendation_id": item.get("recommendation_id"),
                    "type": item.get("recommendation_type"),
                    "category": item.get("recommendation_category"),
                    "priority": item.get("recommendation_priority"),
                    "score": item.get("recommendation_priority"),
                    "confidence": item.get("confidence"),
                    "context_key": item.get("context_key"),
                    "question_id": item.get("question_id"),
                    "evidence_ids": item.get("evidence_ids") or [],
                    "evidence_summary": item.get("evidence_summary"),
                    "payload": item.get("agent_payload") or {},
                    "retrieval_mode": item.get("retrieval_mode"),
                    "usage_stats": {"used": 0, "successful": 0},
                }
                for item in fallback
            ]

        results.sort(key=lambda r: r.get("score", r.get("priority", 0)), reverse=True)
        return results[:15]

    # ─── FIR System Integration ────────────────────────────────────────

    def get_fir_recommendations(
        self,
        agent_type: str,
        trigger_type: str,
        context: dict[str, Any],
        max_results: int = 10,
    ) -> list[dict[str, Any]]:
        """Retrieve FIR System recommendations for an agent.

        Calls SP_FIR_GET_AGENT_RECOMMENDATIONS to fetch pre-formatted
        recommendations from the FIR batch processing system.

        Args:
            agent_type: Target agent (SOURCE_MAPPING, TRANSFORMATION_RULE, STTM_BUILDER)
            trigger_type: Trigger event (on_mapping_start, on_source_selection, etc.)
            context: Context with project_id, table_names, column_names, sttm_id, etc.
            max_results: Maximum recommendations to return

        Returns:
            List of recommendation payloads formatted for learning_context injection.
            Each recommendation has:
            - source: 'fir_system'
            - recommendation_id: Unique ID for tracking
            - type: Recommendation type (pattern_reuse, correction_warning, etc.)
            - priority: 1-100 priority score
            - confidence: Confidence score
            - payload: Agent-specific formatted data
            - usage_stats: {used: int, successful: int}
        """
        started = time.perf_counter()
        project_metric = str(context.get("project_id") or "none")
        target_metric = str(context.get("target_fqn") or "none")
        increment(
            "fir.recommendations.invocation",
            project=project_metric,
            target=target_metric,
            trigger=trigger_type,
        )
        try:
            agent_name = f"AGT_{agent_type}" if not agent_type.startswith("AGT_") else agent_type
            context_with_max = {**context, "max_results": max_results}

            procedure = (
                "SP_FIR_GET_AGENT_RECOMMENDATIONS_V2"
                if self._settings.fir_query_pruning_v1
                else "SP_FIR_GET_AGENT_RECOMMENDATIONS"
            )
            proc_name = self._settings.qualify_metadata_object_name(procedure)
            try:
                result = self._session.call(
                    proc_name,
                    agent_name,
                    trigger_type,
                    context_with_max,
                )
            except Exception:
                if procedure != "SP_FIR_GET_AGENT_RECOMMENDATIONS_V2":
                    raise
                increment("fir.recommendations.v1_compatibility_fallback")
                logger.warning(
                    "FIR V2 recommendation procedure is unavailable; using V1 for this request",
                    exc_info=True,
                )
                result = self._session.call(
                    self._settings.qualify_metadata_object_name(
                        "SP_FIR_GET_AGENT_RECOMMENDATIONS"
                    ),
                    agent_name,
                    trigger_type,
                    context_with_max,
                )

            if isinstance(result, str):
                import json
                result = json.loads(result)

            # Some client accounts still run an older V2 procedure body that
            # uses ARRAY_TRANSFORM, which is not available in every Snowflake
            # runtime. Preserve the exact source/target hashes and retry without
            # the redundant table-array predicate.
            errors = [str(value) for value in result.get("errors", [])]
            if (
                result.get("status") != "success"
                and context_with_max.get("table_names")
                and any("ARRAY_TRANSFORM" in value.upper() for value in errors)
            ):
                increment("fir.recommendations.array_transform_compatibility_retry")
                compatible_context = {**context_with_max, "table_names": []}
                result = self._session.call(
                    proc_name,
                    agent_name,
                    trigger_type,
                    compatible_context,
                )
                if isinstance(result, str):
                    result = json.loads(result)

            if result.get("status") == "success":
                recommendations = result.get("recommendations", [])
                retrieval_mode = result.get("retrieval_mode")
                for recommendation in recommendations:
                    recommendation["retrieval_mode"] = retrieval_mode
                return recommendations[:max_results]
            else:
                self._last_fir_retrieval_error = "; ".join(
                    str(value) for value in result.get("errors", [])
                ) or "FIR recommendation procedure returned a non-success status."
                logger.warning(
                    "FIR recommendations retrieval failed: %s",
                    result.get("errors", []),
                )
                return []

        except Exception as exc:
            self._last_fir_retrieval_error = str(exc)
            logger.warning("Failed to get FIR recommendations: %s", exc)
            _record_retrieval_error(exc)
            return []
        finally:
            observe(
                "fir.recommendations.duration_ms",
                (time.perf_counter() - started) * 1000,
                project=project_metric,
                target=target_metric,
                trigger=trigger_type,
            )

    def get_semantic_version_learnings(
        self,
        table_fqns: list[str],
        limit: int = 3,
    ) -> list[dict[str, Any]]:
        """Retrieve curated semantic version learnings for the given tables.

        Queries TBL_SEMANTIC_VIEW_VERSIONS for the latest curated version of each
        relevant table's semantic view. Returns BUSINESS_GLOSSARY, RELATIONSHIP_RULES,
        TRANSFORMATION_PATTERNS, COLUMN_SEMANTICS, and QA_PAIRS.
        """
        if not table_fqns:
            return []
        try:
            fqn_list = ", ".join(self._quote(fqn.upper()) for fqn in table_fqns)
            rows = self._session.sql(f"""
                SELECT
                    SEMANTIC_VIEW_FQN,
                    VERSION_LABEL,
                    VERSION_NUMBER,
                    BUSINESS_GLOSSARY,
                    RELATIONSHIP_RULES,
                    TRANSFORMATION_PATTERNS,
                    COLUMN_SEMANTICS,
                    QA_PAIRS,
                    CONFIDENCE
                FROM {self._settings.qualify_metadata_object_name('TBL_SEMANTIC_VIEW_VERSIONS')}
                WHERE UPPER(SEMANTIC_VIEW_FQN) IN ({fqn_list})
                  AND COALESCE(LOWER(VALIDATION_STATUS), 'unvalidated') IN (
                      'validated', 'approved', 'active', 'confirmed'
                  )
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY SEMANTIC_VIEW_FQN
                    ORDER BY VERSION_NUMBER DESC
                ) = 1
                LIMIT {limit}
            """).collect()

            results = []
            for row in rows:
                row_dict = row.as_dict() if hasattr(row, "as_dict") else row
                results.append({
                    "fqn": row_dict.get("SEMANTIC_VIEW_FQN"),
                    "version_label": row_dict.get("VERSION_LABEL"),
                    "version_number": row_dict.get("VERSION_NUMBER"),
                    "business_glossary": row_dict.get("BUSINESS_GLOSSARY"),
                    "relationship_rules": row_dict.get("RELATIONSHIP_RULES"),
                    "transformation_patterns": row_dict.get("TRANSFORMATION_PATTERNS"),
                    "column_semantics": row_dict.get("COLUMN_SEMANTICS"),
                    "qa_pairs": row_dict.get("QA_PAIRS"),
                    "confidence": row_dict.get("CONFIDENCE"),
                })
            return results
        except Exception as exc:
            logger.debug("Failed to get semantic version learnings: %s", exc)
            _record_retrieval_error(exc)
            return []

    def record_fir_recommendation_success(
        self,
        recommendation_id: str,
    ) -> bool:
        """Record that a FIR recommendation was successfully used.

        Called when a user accepts a suggestion that was based on a FIR recommendation.
        This updates the success_count for the recommendation, which influences
        confidence scoring and future recommendation priority.

        Args:
            recommendation_id: The AGENT_RECOMMENDATION_ID from the FIR system

        Returns:
            True if recording succeeded, False otherwise
        """
        try:
            proc_name = self._settings.qualify_metadata_object_name(
                "SP_FIR_RECORD_RECOMMENDATION_SUCCESS"
            )
            self._session.call(proc_name, recommendation_id)
            return True
        except Exception as exc:
            logger.warning("Failed to record FIR recommendation success: %s", exc)
            return False

    def get_learning_context(
        self,
        *,
        task: str,
        subject_keys: list[str],
        project_id: str,
        linked_project_ids: list[str] | None = None,
        budget: int = 20,
    ) -> dict[str, Any]:
        """Return compact, exact learning cards and IDs for one workflow node."""
        if not subject_keys or budget <= 0:
            return {"task": task, "cards": [], "retrieved_learning_ids": []}
        allowed_projects = sorted({project_id, *(linked_project_ids or [])})
        keys_sql = ", ".join(self._quote(value) for value in subject_keys)
        projects_sql = ", ".join(self._quote(value) for value in allowed_projects)
        rows = self._session.sql(
            f"""
            SELECT LEARNING_ID, SUBJECT_TYPE, SUBJECT_KEY, CLAIM_KEY, SUMMARY,
                   CONFIDENCE, TRUST_STAGE, EVIDENCE_IDS, ATTRIBUTES,
                   CASE
                     WHEN LEARNING_TYPE IN ('mapping_correction','mapping_edit') THEN 1
                     WHEN TRUST_STAGE = 'outcome' THEN 2
                     WHEN TRUST_STAGE = 'validated' THEN 3
                     ELSE 7
                   END AS RETRIEVAL_PRIORITY
            FROM {self._settings.qualify_table_name('TBL_AGENT_LEARNINGS')}
            WHERE STATUS = 'active'
              -- Deep Agent learnings start as quarantined candidates; only
              -- validated or outcome-backed ones may inform retrieval.
              AND (COALESCE(AGENT_TYPE, '') <> 'DEEP_MIGRATION' OR TRUST_STAGE IN ('validated', 'outcome'))
              AND SUBJECT_KEY IN ({keys_sql})
              AND ENTITY_IDS:project_id::STRING IN ({projects_sql})
              AND TRUST_STAGE NOT IN ('draft_candidate','contested','superseded')
            ORDER BY RETRIEVAL_PRIORITY, CONFIDENCE DESC, CREATED_AT DESC
            LIMIT {min(int(budget), 100)}
            """
        ).collect()
        cards: list[dict[str, Any]] = []
        ids: list[str] = []
        for row in rows:
            data = row.as_dict()
            learning_id = str(data.get("LEARNING_ID") or "")
            attributes = data.get("ATTRIBUTES") or {}
            if isinstance(attributes, str):
                attributes = json.loads(attributes)
            ids.append(learning_id)
            cards.append(
                {
                    "learning_id": learning_id,
                    "subject_type": data.get("SUBJECT_TYPE"),
                    "subject_key": data.get("SUBJECT_KEY"),
                    "claim_key": data.get("CLAIM_KEY"),
                    "summary": data.get("SUMMARY"),
                    "confidence": float(data.get("CONFIDENCE") or 0),
                    "trust_stage": data.get("TRUST_STAGE"),
                    "evidence_ids": list(data.get("EVIDENCE_IDS") or []),
                    "structured_rule": {key: attributes[key] for key in (
                        "target_table", "target_column", "source_tables", "source_columns",
                        "correct_source", "preprocessing_rule", "preprocessing_rule_type",
                        "expression", "constant_value", "relationships", "dependencies",
                        "provenance", "approval_status", "contract_version", "semantic_version"
                    ) if key in attributes},
                }
            )
        return {"task": task, "cards": cards, "retrieved_learning_ids": ids}


    def get_relationship_learnings(self, *, table_names: list[str], budget: int) -> list[dict]:
        """Join learnings whose two tables are named like current tables, any schema or project.

        Matching is by table name only; callers translate the rows onto
        identically shaped current tables (``structural_precedents``) and
        verify every resulting join against the data. Both the structured FQN
        and the legacy ``str(TableRef)`` attribute forms are matched.
        """
        names = sorted({str(value).strip('"').upper() for value in table_names if str(value or "").strip()})
        if not names or budget <= 0:
            return []
        leaf = ("UPPER(COALESCE(REGEXP_SUBSTR(ATTRIBUTES:{side}::STRING, '''table'': ''([^'']+)''', 1, 1, 'e', 1), "
                "SPLIT_PART(ATTRIBUTES:{side}::STRING, '.', -1)))")
        rows = self._session.sql(
            f"""SELECT LEARNING_ID, CONFIDENCE, TRUST_STAGE, ATTRIBUTES FROM IDENTIFIER(?)
                WHERE STATUS='active' AND LEARNING_TYPE='table_relationship'
                AND (COALESCE(AGENT_TYPE,'') <> 'DEEP_MIGRATION' OR TRUST_STAGE IN ('validated','outcome'))
                AND COALESCE(TRUST_STAGE,'evidence') NOT IN ('draft_candidate','contested','superseded')
                AND ARRAY_CONTAINS(TO_VARIANT({leaf.format(side='left_table')}), PARSE_JSON(?))
                AND ARRAY_CONTAINS(TO_VARIANT({leaf.format(side='right_table')}), PARSE_JSON(?))
                ORDER BY CONFIDENCE DESC, CREATED_AT DESC LIMIT ?""",
            [self._settings.qualify_table_name('TBL_AGENT_LEARNINGS'), json.dumps(names), json.dumps(names),
             min(int(budget), 500)],
        ).collect()
        learnings = []
        for row in rows:
            data = row.as_dict() if hasattr(row, "as_dict") else dict(row)
            attributes = data.get("ATTRIBUTES") or {}
            if isinstance(attributes, str):
                try:
                    attributes = json.loads(attributes)
                except json.JSONDecodeError:
                    continue
            learnings.append({"learning_id": data.get("LEARNING_ID"), "confidence": data.get("CONFIDENCE"),
                              "trust_stage": data.get("TRUST_STAGE"), "attributes": attributes})
        return learnings


    def get_source_design_evidence(self, *, target_table: str, project_ids: list[str], budget: int) -> dict:
        """Retrieve graph-level legacy evidence even when SUBJECT_KEY is absent."""
        from app.core.learning_normalization import normalize_legacy_learning
        if not project_ids or budget <= 0:
            return {"cards": [], "retrieved_learning_ids": []}
        rows = self._session.sql(
            """SELECT * FROM IDENTIFIER(?) WHERE STATUS='active'
                AND (COALESCE(AGENT_TYPE,'') <> 'DEEP_MIGRATION' OR TRUST_STAGE IN ('validated','outcome'))
                AND UPPER(ATTRIBUTES:target_table::STRING)=UPPER(?)
                AND ARRAY_CONTAINS(TO_VARIANT(ENTITY_IDS:project_id::STRING),PARSE_JSON(?))
                AND COALESCE(TRUST_STAGE,'evidence') NOT IN ('draft_candidate','contested','superseded')
                AND LEARNING_TYPE IN ('table_relationship','cte_lineage','transformation_pattern',
                                      'source_selection_pattern','mapping_dependency','column_dependency')
                ORDER BY LEARNING_TYPE, CREATED_AT DESC LIMIT ?""",
            [self._settings.qualify_table_name('TBL_AGENT_LEARNINGS'),target_table,
             json.dumps(sorted(set(project_ids))), min(budget,100)],
        ).collect()
        cards=[normalize_legacy_learning(row.as_dict()) for row in rows]
        return {"cards":cards,"retrieved_learning_ids":[card['learning_id'] for card in cards]}


    def get_specialist_learning(
        self,
        *,
        project_id: str,
        target_table: str,
        target_columns: list[str],
        source_tables: list[str],
        source_columns: list[str] | None = None,
        source_column_profiles: list[dict[str, Any]] | None = None,
        target_agent: str = "AGT_SOURCE_MAPPING",
        linked_project_ids: list[str] | None = None,
        crm_family: str | None = None,
        per_column: int = 2,
        recommendation_limit: int = 8,
    ) -> dict[str, Any]:
        """Target-column recipes and stored FIR recommendations for the mapping specialists.

        The same two sources the Auto Map action sends AGT_SOURCE_MAPPING and
        AGT_TRANSFORMATION_RULE. Both are reads of already-computed rows (one
        query, one procedure call); nothing here calls a model.
        """
        patterns: list[dict[str, Any]] = []
        recommendations: list[dict[str, Any]] = []
        if self._target_pattern_service is not None and target_table and target_columns:
            try:
                candidates = self._target_pattern_service.retrieve_candidates(
                    target_table=target_table, target_columns=target_columns, canonical_target_scope=True,
                    source_tables=source_tables, source_columns=source_columns,
                    source_column_profiles=source_column_profiles,
                    crm_family=crm_family, project_id=project_id or None,
                    limit=min(max(len(target_columns) * per_column * 2, 20), 120),
                )
                kept: dict[str, int] = {}
                for candidate in candidates:
                    compact = _compact_pattern(candidate)
                    column = str(compact.get("target_column") or "").upper()
                    if kept.get(column, 0) >= per_column:
                        continue
                    kept[column] = kept.get(column, 0) + 1
                    patterns.append(compact)
            except Exception as exc:
                logger.warning("Target-column FIR patterns are unavailable for the specialists: %s", exc)
        if source_tables or target_table:
            try:
                recommendations = self._get_fir_recommendations_for_context(
                    project_id=project_id, source_tables=list(source_tables), target_table=target_table,
                    target_columns=list(target_columns), target_agent=target_agent,
                    linked_project_ids=list(linked_project_ids or []),
                )[:recommendation_limit]
            except Exception as exc:
                logger.warning("FIR recommendations are unavailable for the specialists: %s", exc)
        return {
            "target_mapping_patterns": patterns,
            "fir_recommendations": recommendations,
            "retrieved_pattern_ids": [item["pattern_id"] for item in patterns if item.get("pattern_id")],
            "retrieved_recommendation_ids": [
                str(item.get("recommendation_id")) for item in recommendations if item.get("recommendation_id")
            ],
        }


    def record_relationship_learning(self, *, attributes: dict[str, Any], summary: str, confidence: float,
                                     trust_stage: str, entity_ids: dict[str, Any], user_id: str | None,
                                     evidence_ids: list[str]) -> str:
        """Persist one structured, fingerprinted join so later projects can reuse it."""
        identity = json.dumps([attributes.get("left_table"), attributes.get("right_table"),
                               attributes.get("conditions"), attributes.get("literal_filters") or []], sort_keys=True)
        return self._agent_learning_service.record_learning(
            agent_type="DEEP_MIGRATION", learning_type="table_relationship", summary=summary,
            attributes=attributes, entity_type="relationship", entity_ids=entity_ids,
            tags=["relationship", trust_stage], confidence=confidence, user_id=user_id,
            subject_type="relationship",
            subject_key="relationship:" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:32],
            claim_key="table_relationship", trust_stage=trust_stage, evidence_ids=evidence_ids,
        )


    def record_validation_outcome(
        self,
        learning_ids: list[str],
        *,
        passed: bool,
        evidence_id: str,
    ) -> None:
        self._agent_learning_service.record_validation_outcome(
            learning_ids,
            passed=passed,
            evidence_id=evidence_id,
        )
