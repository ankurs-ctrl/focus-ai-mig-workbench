param(
    [string]$EnvFile = ""
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

if (-not $EnvFile) {
    $EnvFile = Join-Path (Get-BundleRoot) ".env"
}

$bundleRoot = Get-BundleRoot
$pythonCmd = Resolve-Python

if (-not (Test-Path $EnvFile)) {
    throw "Env file not found: $EnvFile. Copy .env.example to .env first."
}

# This helper is meant for Windows or PowerShell users rehearsing locally.
# It creates a local venv when needed, imports .env values into the current
# process, runs the smoke test, and then starts Streamlit.
$venvDir = Join-Path $bundleRoot ".venv"
if (-not (Test-Path $venvDir)) {
    Write-Host "Creating local virtualenv at $venvDir"
    & $pythonCmd -m venv $venvDir
}

$venvPython = Join-Path $venvDir "Scripts\python.exe"
if (-not (Test-Path $venvPython)) {
    throw "Expected virtualenv Python at $venvPython"
}

Write-Host "Installing app dependencies"
& $venvPython -m pip install -r (Join-Path $bundleRoot "requirements.txt")

& (Join-Path $PSScriptRoot "import_env_file.ps1") -EnvFile $EnvFile

Write-Host ""
Write-Host "Running Snowflake smoke test"
& $venvPython (Join-Path $PSScriptRoot "local_smoke_test.py")

Write-Host ""
Write-Host "Starting Streamlit app"
& $venvPython -m streamlit run (Join-Path $bundleRoot "app.py")
