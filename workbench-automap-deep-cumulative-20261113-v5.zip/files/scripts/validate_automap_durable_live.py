"""One non-publishing Auto-map acceptance in this system's separate test account.

Uses existing semantic assets. Creates a uniquely named scratch schema/agent and
16-row capacity fixture (12 execution, 4 old quarantine records). Never changes
client account settings, existing admission pools, mappings or semantic assets.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, UTC, timedelta
import hashlib
import json
import logging
from pathlib import Path
import sys
import time
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'services/sttm-builder'),str(ROOT)]


def main():
    main_started=time.monotonic()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--retain-successful-fixture', action='store_true', help='Keep only a successful isolated fixture for local review; never publish')
    parser.add_argument('--review-output', type=Path, help='Save sanitized fixture workspace and returned definitions after success')
    parser.add_argument('--warehouse', help='Existing test warehouse; does not modify the credential file')
    parser.add_argument('--generation-policy', choices=['legacy', 'draft-v3'], default='legacy')
    parser.add_argument('--large-fixture', action='store_true', help='Sanitized 40-target representative-source fixture; requires --mixed-rules')
    parser.add_argument('--fixture-source-count', type=int, default=12, choices=range(2,288), metavar='2..287')
    parser.add_argument('--require-evidence-tool', action='store_true', help='Verify source and rule native retrieval against the retained DISPLAY_NAME FIR fixture')
    parser.add_argument('--prepared-job-path', action='store_true', help='Actual page prepare/job/private worker endpoint acceptance without seeded execution context')
    parser.add_argument('--workspace-request', type=Path, help='Read-only acceptance of an existing authorized test-account workspace; never source/target writes')
    parser.add_argument('--mixed-rules', action='store_true', help='Exercise custom rules, Firm Values and persisted validated FIR in isolated fixtures')
    parser.add_argument('--semantic-coverage', choices=['full','partial','none'], default='full', help='Exercise actual partial bundle resolution plus builder chat; no existing semantic assets are changed')
    parser.add_argument('--session-strategy', choices=['cold','pooled'], default='pooled', help='Use the production reusable caller lease pool by default')
    parser.add_argument('--scenario', choices=['new','partial','sql-upload','cte'], default='new')
    parser.add_argument('--concurrent-batches', action='store_true', help='Exercise the normal concurrent batch scheduler with mixed targets')
    parser.add_argument('--full-mapping',action='store_true',help='Map every physical column of the larger existing semantic fixture, using normal batches')
    args=parser.parse_args();logging.basicConfig(level=logging.ERROR)
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    import yaml
    from app.core.config import Settings
    from app.core.semantic_model import SemanticModelService
    from app.core.sttm_builder import STTMBuilderService
    from app.core.snowflake_agent import SnowflakeAgentClient
    from app.core.automap_runtime import RuntimeCaller, SnowflakeReductionArchive
    from app.core.automap_semantic_catalog import build_catalog
    from app.core.automap_batch import FAST_INTEGRATION_VERSION,canonical_model_wire_request,freeze_fast_handoff
    from app.core.automap_policy import preparation_hash, POLICY_VERSION
    from app.schema.common import TableRef
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest,AgentExecutionContextV2
    from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
    from app.guardrails.config.loader import load_config
    from app.guardrails.contracts.decisions import GovernanceDecision
    from scripts.prepare_parallel_automap_infra import PERMIT_COLUMNS,ARCHIVE_COLUMNS
    from scripts.prepare_automap_durable_runs import EXTRA_COLUMNS
    c=dotenv_values(args.credential_env)
    if c.get('SNOWFLAKE_ACCOUNT','').upper()!='A0581299278961-BBINSIGHT_PARTNER':
        raise ValueError('Restricted to this system test account')
    schema='SCH_AUTOMAP_ACCEPTANCE_'+uuid4().hex[:12].upper()
    db='FFP_HDP_CRM_MIG_DB_DEV';namespace=db+'.'+schema
    table=namespace+'.PERMITS_V2';archive=namespace+'.ARCHIVE'
    epoch=str(uuid4());created=False;report={'status':'started','publishing':False,'execution_slots':12,'legacy_quarantines':4}
    from app.core.automap_admission import SnowflakeCallAdmission
    from app.core.automap_background_transport import BackgroundRunTransport
    original_admission_sql=SnowflakeCallAdmission._sql
    original_exchange=BackgroundRunTransport._json_exchange
    def observed_admission_sql(self,session,query,params=None):
        started=time.monotonic()
        with session.query_history(include_error=True) as history:
            try:return original_admission_sql(self,session,query,params)
            finally:
                report.setdefault('admission_queries',[]).extend({'operation':query.split()[0],
                    'query_id':item.query_id,'elapsed_ms':round((time.monotonic()-started)*1000,2)} for item in history.queries)
    def observed_exchange(self,method,url,request,**kwargs):
        if kwargs.get('model_post'):
            body=kwargs.get('body',b'').decode('utf-8')
            report.setdefault('model_inputs',[]).append({'agent':self._config.agent.split('.')[-1],
                'final_chars':len(request.message),'final_bytes':len(request.message.encode('utf-8')),
                'target_count':len(request.target_ids),
                'shard_id':request.shard_id,'at':datetime.now(UTC).isoformat(),
                'semantic_markers':[value for value in ('Contact name','Stable row identifier','Whether the contact is active') if value in body],
                'fir_ids_in_request':[value for value in report.get('persisted_fir_recipe_ids',[]) if value in body],
                'firm_value_binding_present':'FirmPrefix' in body})
            print(json.dumps({'stage':'model_post','agent':self._config.agent.split('.')[-1],
                'target_count':len(request.target_ids),'final_chars':len(request.message),
                'final_bytes':len(request.message.encode('utf-8'))}),flush=True)
        return original_exchange(self,method,url,request,**kwargs)
    SnowflakeCallAdmission._sql=observed_admission_sql
    BackgroundRunTransport._json_exchange=observed_exchange
    original_collect=SnowflakeReductionArchive._collect_sql
    def observed_collect(self,*args,**kwargs):
        try:return original_collect(self,*args,**kwargs)
        except Exception as exc:
            # Record types/codes only: never query text, binds or error bodies.
            report.setdefault('archive_sql_failures',[]).append({'error_type':type(exc).__name__,
                'error_code':getattr(exc,'sql_error_code',None)})
            raise
    SnowflakeReductionArchive._collect_sql=observed_collect
    config=dict(account=c['SNOWFLAKE_ACCOUNT'],user=c['SNOWFLAKE_USER'],authenticator='PROGRAMMATIC_ACCESS_TOKEN',
        token=c['SNOWFLAKE_PASSWORD'],role=c['SNOWFLAKE_ROLE'],warehouse=args.warehouse or c['SNOWFLAKE_WAREHOUSE'],
        database=db,schema='SCH_STTM_METADATA',login_timeout=20,network_timeout=60)
    session=Session.builder.configs(config).create()
    @contextmanager
    def independent():
        s=Session.builder.configs(config).create()
        try:yield s
        finally:s.close()
    try:
        identity=session.sql('SELECT CURRENT_ORGANIZATION_NAME() O,CURRENT_ACCOUNT_NAME() A,CURRENT_USER() U,CURRENT_ROLE() R').collect()[0]
        assert identity['O']=='A0581299278961' and identity['A']=='BBINSIGHT_PARTNER'
        report['verified_account']=identity['O']+'.'+identity['A'];report['verified_user']=identity['U']
        values={k:v for k,v in c.items() if v is not None}
        values['SNOWFLAKE_WAREHOUSE'] = config['warehouse']
        values.update(APP_ENV='local',LOCAL_DEV_AUTH_ENABLED=True,SNOWFLAKE_AUTHENTICATOR='programmatic_access_token',
            SNOWFLAKE_DATABASE=db,SNOWFLAKE_SCHEMA=schema,
            SNOWFLAKE_SEMANTIC_MODEL_TABLE=db+'.SCH_STTM_METADATA.TBL_SEMANTIC_MODELS',
            SNOWFLAKE_SEMANTIC_VIEWS_DATABASE='FOCUS_DB_2',SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA='STTM_MCP',
            SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE='SEM_NATIVE_VIEWS',
            AUTOMAP_FAST_PATH_V1=True,AUTOMAP_FAST_PROJECT_IDS='*',AUTOMAP_FAST_BATCH_SECONDS=300,
            AUTOMAP_FAST_JOB_SECONDS=600,AUTOMAP_PARALLEL_CONTEXT_V1=True,AUTOMAP_DURABLE_RUNS_V2=True,
            AUTOMAP_RECOVERY_CAPACITY=4,AUTOMAP_PARALLEL_POOL_CAPACITY=12,AUTOMAP_PARALLEL_MAX_WORKERS=12,
            AUTOMAP_PARALLEL_PERMIT_TABLE_FQN=table,AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN=archive,
            AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE=identity['O']+'.'+identity['A'],AUTOMAP_PARALLEL_POOL_EPOCH=epoch,
            AUTOMAP_PARALLEL_TEST_AGENT=namespace+'.AGT_SOURCE_MAPPING',SNOWFLAKE_WRITE_LEASE_POOL_V1=True,
            AUTOMAP_FAST_MAX_IN_FLIGHT=12,AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
            AGENT_OUTBOUND_MESSAGE_MAX_CHARS=180000,AGENT_OUTBOUND_MESSAGE_MAX_BYTES=180000,
            AGENT_SPEC_SOURCE_MAPPING_SHA256=hashlib.sha256((ROOT/'infra/snowflake/agents/agent_spec_source_mapping.yaml').read_bytes()).hexdigest(),
            AGENT_SPEC_TRANSFORMATION_RULE_SHA256=hashlib.sha256((ROOT/'infra/snowflake/agents/agent_spec_transformation_rule.yaml').read_bytes()).hexdigest(),
            SNOWFLAKE_REST_HOST='a0581299278961-bbinsight-partner.snowflakecomputing.com',
            SNOWFLAKE_SOURCE_MAPPING_AGENT=namespace+'.AGT_SOURCE_MAPPING',
            SNOWFLAKE_TRANSFORMATION_AGENT=namespace+'.AGT_TRANSFORMATION_RULE')
        settings=Settings(_env_file=None,**values)
        refs=[TableRef(database='BBI_STTM_TEST_DB',schema='DW_OPS',table=n) for n in ['PORTAL_USER_HISTORY','LOAN_INCOME_AMOUNT_CALCULATION']]
        records=SemanticModelService(settings.model_copy(update={'snowflake_schema': 'SCH_STTM_METADATA'})).get_table_records(session,refs)
        if not records:raise ValueError('Existing semantic fixture unavailable')
        record=max(records,key=lambda r:len(build_catalog([r],bundle_hash='live-existing-semantics'))) if args.full_mapping else records[0]
        fqn='.'.join(record[k] for k in ['database','schema_name','table_name'])
        catalog=[v for v in build_catalog([record],bundle_hash='live-existing-semantics') if v['provenance']!='name_only']
        if not catalog:raise ValueError('Stored semantic descriptions unavailable')
        chosen=catalog[:2]
        if args.full_mapping:
            described=session.sql('DESCRIBE TABLE '+fqn).collect()
            semantic={v['column'].upper():v for v in catalog}
            chosen=[{'column':r['name'],'data_type':r['type'],
                'description':semantic.get(r['name'].upper(),{}).get('description') or r['comment'] or ''}
                for r in described if r['kind']=='COLUMN']
            if not chosen:raise ValueError('Full physical target inventory unavailable')
            report['physical_target_column_count']=len(chosen)
            print(json.dumps({'stage':'full_inventory','source_table':fqn,'target_count':len(chosen)}),flush=True)
        source=dict(zip(['database','schema','table'],fqn.split('.')))
        target={'database':db,'schema':schema,'table':'LOGICAL_IDENTITY_TARGET'}
        session.sql('CREATE TRANSIENT SCHEMA '+namespace).collect();created=True
        mixed_evidence = {}
        if args.mixed_rules:
            from app.core.target_mapping_patterns import TargetMappingPatternService
            source = {'database': db, 'schema': schema, 'table': 'MIXED_SOURCE'}
            fqn = namespace + '.MIXED_SOURCE'
            session.sql(f'CREATE TRANSIENT TABLE {fqn} (ID NUMBER, NAME VARCHAR, ACTIVE BOOLEAN)').collect()
            session.sql(f"INSERT INTO {fqn} VALUES (1,' Alice ',TRUE),(2,'Bob',FALSE),(3,NULL,TRUE)").collect()
            catalog = [{'column': 'ID', 'data_type': 'NUMBER', 'description': 'Stable row identifier'},
                {'column': 'NAME', 'data_type': 'VARCHAR', 'description': 'Contact name'},
                {'column': 'ACTIVE', 'data_type': 'BOOLEAN', 'description': 'Whether the contact is active'}]
            chosen = [{'column': 'ID', 'data_type': 'NUMBER', 'description': 'Direct copy of source ID; no custom transformation'},
                {'column': 'DISPLAY_NAME', 'data_type': 'VARCHAR', 'description': "Custom rule: prepend approved $FirmPrefix to TRIM(NAME), with NULL name replaced by 'Unknown'. Follow the retrieved validated FIR recipe."},
                {'column': 'FIRM_VALUE', 'data_type': 'VARCHAR', 'description': 'Direct assignment: mapping_mode attribute, attribute_name FirmPrefix, constant_value $FirmPrefix, binding firm-prefix. Do not use FIRM_VALUE as the attribute name. No custom transformation.'},
                {'column': 'VALUE_CASE', 'data_type': 'VARCHAR', 'description': "Custom rule using only Firm Values: CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other firm' END"},
                {'column': 'OWNERNAME', 'data_type': 'VARCHAR', 'description': 'Intentional SQL NULL constant; no source or concatenation'}]
            record = {'database': db, 'schema_name': schema, 'table_name': 'MIXED_SOURCE',
                'semantic_model': {'description': 'Sanitized mixed rule acceptance fixture', 'attributes': [
                    {'name': item['column'], 'data_type': item['data_type'], 'description': item['description']} for item in catalog]}}
            session.sql(f'CREATE TRANSIENT TABLE {namespace}.TBL_FIR_TARGET_MAPPING_PATTERNS LIKE {db}.SCH_STTM_METADATA.TBL_FIR_TARGET_MAPPING_PATTERNS').collect()
            patterns = TargetMappingPatternService(session, settings)
            extracted = patterns.extract_document_patterns(asset_id='isolated-mixed-fixture', project_id='1',
                evidence_class='validated_mapping', base_confidence=.9, parsed_document={
                    'target_table': namespace + '.LOGICAL_IDENTITY_TARGET', 'source_tables': [fqn],
                    'column_mappings': [{'target_alias': 'DISPLAY_NAME', 'source_columns': ['src.NAME'],
                        'transformation': "$FirmPrefix || COALESCE(TRIM(src.NAME), 'Unknown')"}]})
            session.sql(f"EXPLAIN USING TEXT SELECT 'TEST-' || COALESCE(TRIM(NAME), 'Unknown') AS DISPLAY_NAME FROM {fqn}").collect()
            extracted = [item.model_copy(update={'validation_status': 'validated'}) for item in extracted]
            patterns.upsert_patterns(extracted)
            stored = session.sql(f'SELECT PATTERN_PAYLOAD FROM {namespace}.TBL_FIR_TARGET_MAPPING_PATTERNS').collect()
            for row in stored:
                pattern = json.loads(row['PATTERN_PAYLOAD']) if isinstance(row['PATTERN_PAYLOAD'], str) else row['PATTERN_PAYLOAD']
                mixed_evidence['DISPLAY_NAME'] = {'canonical_target_mapping_patterns': [{'pattern': pattern,
                    'decision': 'adapt_pattern', 'applicable': True, 'guidance_only': False, 'tier': 'T1'}]}
            report.update(mixed_rules=True, fir_fixture_records=len(stored), fir_fixture_trust='validated_mapping')
            report['persisted_fir_recipe_ids'] = [(item.get('pattern') or item)['pattern_id'] for item in mixed_evidence['DISPLAY_NAME']['canonical_target_mapping_patterns']]
        large_sources=[]
        if args.large_fixture:
            if not args.mixed_rules or args.scenario != 'new' or args.semantic_coverage != 'full':
                raise ValueError('Large fixture requires mixed rules, new mapping and full fixture semantic coverage')
            # Real views make every declared physical source resolvable. They all
            # expose the same sanitized three-row data with a proven unique ID.
            statements=[]
            for index in range(1,args.fixture_source_count):
                extra={'database':db,'schema':schema,'table':f'SOURCE_{index:03d}'}
                large_sources.append(extra)
                statements.append(f"CREATE VIEW {namespace}.{extra['table']} AS SELECT ID,NAME,ACTIVE FROM {fqn};")
            session.sql('BEGIN ' + ' '.join(statements) + ' END').collect()
            chosen.extend({'column':f'ID_COPY_{index:02d}','data_type':'NUMBER',
                'description':'Direct copy of the current src.ID stable identifier; no transformation or historical defaults.'}
                for index in range(1,36))
            report['large_fixture']={'targets':len(chosen),'sources':1+len(large_sources),
                'physical_sources_created':True,'data':'sanitized_three_rows_unique_id'}
        if args.mixed_rules:
            target_columns = ','.join('"' + item['column'] + '" ' + item['data_type'] for item in chosen)
            session.sql(f'CREATE TRANSIENT TABLE {namespace}.LOGICAL_IDENTITY_TARGET ({target_columns})').collect()
        journal=Path('/tmp/automap-durable-fixtures.jsonl')
        with journal.open('a') as entry:entry.write(json.dumps({'schema':schema,'created_at':datetime.now(UTC).isoformat()})+'\n')
        legacy=namespace+'.LEGACY_PERMITS'
        session.sql(f'CREATE TRANSIENT TABLE {legacy} ({PERMIT_COLUMNS})').collect()
        account=report['verified_account']
        session.sql(f"INSERT INTO {legacy} (ACCOUNT_NAMESPACE,POOL_EPOCH,SLOT_ID,STATE,OWNER_TOKEN,FENCE,CALLER_ID,JOB_ID,GENERATION,SHARD_ID,UPDATED_AT) "
            "SELECT ?,?,ROW_NUMBER() OVER (ORDER BY SEQ4()),'QUARANTINED','legacy-fixture',1,'LEGACY_TEST_CALLER','old-test','old-test','old-test',CURRENT_TIMESTAMP() "
            "FROM TABLE(GENERATOR(ROWCOUNT=>4))",params=[account,epoch]).collect()
        session.sql(f'CREATE TRANSIENT TABLE {archive} ({ARCHIVE_COLUMNS})').collect()
        from scripts import prepare_automap_durable_runs as migration
        old_loader=migration.load_profile
        migration.load_profile=lambda *a:({'account_namespace':account,'database':db,'schema':schema,
            'role':identity['R'],'connection':'local-acceptance'}, {
            'AUTOMAP_DURABLE_RUNS_V2':'true','AUTOMAP_PARALLEL_POOL_CAPACITY':'12','AUTOMAP_RECOVERY_CAPACITY':'4',
            'AUTOMAP_PARALLEL_PERMIT_TABLE_FQN':table,'AUTOMAP_PARALLEL_POOL_EPOCH':epoch})
        try:
            migration_sql=migration.prepare(None,'DEV',legacy_table=legacy,exclusive=True,retired_dispatchers=True)
            validation_sql=migration.prepare(None,'DEV',stage='validate')
        finally:migration.load_profile=old_loader
        session.sql('USE SCHEMA '+namespace).collect()
        import io
        from snowflake.connector.util_text import split_statements
        def split_sql_statements(sql):return [part for part,_ in split_statements(io.StringIO(sql)) if part.strip()]
        for statement in split_sql_statements(migration_sql): session.sql(statement).collect()
        # Repeated migration must validate without reseeding owners/fences.
        for statement in split_sql_statements(migration_sql): session.sql(statement).collect()
        for statement in split_sql_statements(validation_sql): session.sql(statement).collect()
        report['migration_repeat_and_readonly_validation']='passed'
        from snowflake.connector.util_text import split_statements
        import io
        tool_sql=(ROOT/'infra/snowflake/automap-evidence-tool.sql').read_text().replace('__STTM_METADATA_NAMESPACE__',namespace)
        for statement,_ in split_statements(io.StringIO(tool_sql)):
            if statement.strip():session.sql(statement).collect()
        report['native_evidence_tool_installed']=True
        spec=yaml.safe_load((ROOT/'infra/snowflake/agents/agent_spec_source_mapping.yaml').read_text())
        report['deployed_agent_specs']={'AGT_SOURCE_MAPPING':{'template_sha256':hashlib.sha256((ROOT/'infra/snowflake/agents/agent_spec_source_mapping.yaml').read_bytes()).hexdigest()}}
        spec['tool_resources']['ReadAutoMapEvidence']['identifier']=namespace+'.SP_AUTOMAP_READ_EVIDENCE'
        spec['tool_resources']['ReadAutoMapEvidence']['execution_environment']['warehouse']=config['warehouse']
        if args.require_evidence_tool:
            spec['instructions']['orchestration'] += ('\nIsolated wiring acceptance only: for DISPLAY_NAME, reading its retained FIR record with ReadAutoMapEvidence is a required contract check before the final response, even when the packet already contains it. Use the supplied handle and exact record ID. This fixture requirement takes precedence over optional-tool guidance.\n')
        spec['orchestration']['budget']['seconds']=180
        report['deployed_agent_specs']['AGT_SOURCE_MAPPING']['fixture_spec_sha256']=hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()
        literal=json.dumps(spec).replace(chr(92),chr(92)*2).replace("'","''")
        session.sql(f"CREATE AGENT {namespace}.AGT_SOURCE_MAPPING FROM SPECIFICATION '{literal}'").collect()
        if args.mixed_rules or args.workspace_request:
            rule_spec = yaml.safe_load((ROOT/'infra/snowflake/agents/agent_spec_transformation_rule.yaml').read_text())
            rule_spec['tool_resources']['ReadAutoMapEvidence']['identifier']=namespace+'.SP_AUTOMAP_READ_EVIDENCE'
            rule_spec['tool_resources']['ReadAutoMapEvidence']['execution_environment']['warehouse']=config['warehouse']
            if args.require_evidence_tool:
                rule_spec['instructions']['orchestration'] += ('\nIsolated wiring acceptance only: for DISPLAY_NAME, call ReadAutoMapEvidence for its exact retained FIR record before the final response, using the supplied handle. This fixture requirement takes precedence over optional-tool guidance.\n')
            report['deployed_agent_specs']['AGT_TRANSFORMATION_RULE']={'template_sha256':hashlib.sha256((ROOT/'infra/snowflake/agents/agent_spec_transformation_rule.yaml').read_bytes()).hexdigest(),'fixture_spec_sha256':hashlib.sha256(json.dumps(rule_spec,sort_keys=True).encode()).hexdigest()}
            rule_literal = json.dumps(rule_spec).replace(chr(92), chr(92)*2).replace("'", "''")
            session.sql(f"CREATE AGENT {namespace}.AGT_TRANSFORMATION_RULE FROM SPECIFICATION '{rule_literal}'").collect()
        if args.semantic_coverage != 'full':
            chat_spec = yaml.safe_load((ROOT/'infra/snowflake/agents/agent_spec_sttm_builder.yaml').read_text())
            chat_spec['tools'] = []; chat_spec['tool_resources'] = {}
            report['deployed_agent_specs']['AGT_STTM_BUILDER']={'template_sha256':hashlib.sha256((ROOT/'infra/snowflake/agents/agent_spec_sttm_builder.yaml').read_bytes()).hexdigest(),'fixture_spec_sha256':hashlib.sha256(json.dumps(chat_spec,sort_keys=True).encode()).hexdigest()}
            chat_literal = json.dumps(chat_spec).replace(chr(92), chr(92)*2).replace("'", "''")
            session.sql(f"CREATE AGENT {namespace}.AGT_STTM_BUILDER FROM SPECIFICATION '{chat_literal}'").collect()
        conn=session.connection
        agent=SnowflakeAgentClient(token=conn._rest._token,host=settings.rest_snowflake_host,auth_mode='snowflake_token',role=identity['R'],request_timeout=300)
        service=STTMBuilderService.__new__(STTMBuilderService)
        service._settings=settings;service._session=session;service._query_session=session;service._agent=agent
        service._source_mapping_agent_name=namespace+'.AGT_SOURCE_MAPPING';service._transformation_agent_name=namespace+'.AGT_TRANSFORMATION_RULE' if args.mixed_rules or args.workspace_request else None
        from types import SimpleNamespace
        service._postflight_guard=SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
        service._parallel_caller=RuntimeCaller(identity['U'],identity['U'],identity['R'],account)
        if args.session_strategy == 'pooled':
            from app.core.snowflake import caller_write_lease
            from app.core.warehouse_routing import WarehouseWorkload
            @contextmanager
            def pooled(deadline=None):
                with caller_write_lease(settings, '', identity['R'], WarehouseWorkload.CONTROL,
                    reusable=True, maximum=settings.automap_admission_session_capacity, deadline=deadline) as client:
                    yield client.session
            pooled.with_deadline=lambda deadline:pooled(deadline=deadline)
            service._parallel_session_factory=pooled
        else:service._parallel_session_factory=independent
        report['session_strategy']=args.session_strategy
        report['control_session_capacity']=settings.automap_admission_session_capacity
        from app.core.automap_runtime import build_fast_model_runtime, RuntimeConfigurationError
        def diagnostic_factory(service,req,decision,store,deadline):
            try:
                runtime=build_fast_model_runtime(service,req,decision,store,deadline,finalization_deadline=deadline+20)
                if args.require_evidence_tool:
                    original_tool_run = runtime.run
                    def require_tool(messages, *call_args, **call_kwargs):
                        import copy
                        outgoing = copy.deepcopy(messages)
                        if 'DISPLAY_NAME' in runtime._target_ids:
                            ids = report.get('persisted_fir_recipe_ids', [])
                            outgoing[0]['content'].append({'type':'text','text':
                                'Isolated tool-contract acceptance: before deciding DISPLAY_NAME, call ReadAutoMapEvidence once '
                                'using the supplied context handle and REQUEST_JSON with targets ["DISPLAY_NAME"] and record_ids '
                                + json.dumps(['fir:'+value for value in ids]) + '. Confirm the retained recipe, then return normal JSON.'})
                        return original_tool_run(outgoing, *call_args, **call_kwargs)
                    runtime.run = require_tool
                if args.semantic_coverage != 'full':
                    original_run=runtime.run
                    def record_fixture_envelope(*call_args, **call_kwargs):
                        result=original_run(*call_args, **call_kwargs)
                        from app.core.sttm_builder import _extract_json_object
                        try:body=json.loads(_extract_json_object(result[0]))
                        except (ValueError, TypeError):body={'unparsed':True}
                        report.setdefault('fixture_model_envelopes',[]).append({'stage':call_kwargs.get('stage'), 'response':body})
                        return result
                    runtime.run=record_fixture_envelope
                return runtime
            except RuntimeConfigurationError as exc:
                report['runtime_configuration_error']=str(exc)
                report['runtime_configuration_diagnostic']={key:getattr(exc,key,None) for key in ('lease_stage','lease_error_type','lease_error_code','sql_failure')}
                raise
        service._fast_model_runtime_factory=diagnostic_factory
        guard_config=load_config(settings=settings);service._model_guard=ModelBoundaryGuard(guard_config)
        # This fixture intentionally has no project history; reads existing semantic
        # assets and exercises full evidence/model/candidate validation, not FIR activation.
        service._discover_auto_map_evidence=lambda request,targets:{'evidence':{},'diagnostics':{'status':'no_match','fixture':True}}
        until=datetime.now(UTC)+timedelta(seconds=600)
        payload={'request_id':str(uuid4()),'operation':'sttm.auto_map',
            'data':{'intent':'AUTO_MAP','message':'Identity semantic contract. Preserve each requested target meaning using its corresponding existing source field. Do not publish.',
                'attributes':[{'target_table':target,'target_attribute':v['column'],'target_data_type':v['data_type'],'target_description':v['description']} for v in chosen]},
            'context':{'project_id':'1','source_tables':[source],'driving_table':source,'target_table':target,
                'semantic_context':[{'table':source,'semantic_model':record['semantic_model']}],
                'learning_context':{'automap_policy_version':POLICY_VERSION},
                'workspace_context':{'driving_relation_id':'src'},
                'relation_graph':{'nodes':[{'relation_id':'src','alias':'src','kind':'PHYSICAL_TABLE','table':source,
                    'output_columns':[{'name':v['column'],'data_type':v['data_type']} for v in (chosen if args.full_mapping else catalog)]}],'edges':[]}},
            'meta':{'auto_map_fast_path':'v1','auto_map_deadline_at':until.isoformat(),'_automap_deadline':until.timestamp()}}
        if args.generation_policy == 'draft-v3':
            payload['meta']['automap_generation_policy'] = 'draft-v3'
        report['generation_policy'] = args.generation_policy
        if args.mixed_rules:
            payload['meta']['automap_rules_policy'] = 'rules-v2'
            payload['data']['message'] = ('Generate a reviewable draft for the requested target contracts only. If ID is requested it is direct; '
                'DISPLAY_NAME must follow the validated FIR expression using NAME and $FirmPrefix; '
                'FIRM_VALUE is the approved FirmPrefix Value; VALUE_CASE needs the transformation agent to generate '
                "CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other firm' END using only the approved Value; "
                'OWNERNAME is intentionally SQL NULL. Do not look for owner source columns or invent an owner name. '
                'Follow each target description. Return rule_intent and required Value binding IDs for custom targets. Do not publish.')
            payload['context']['relation_graph']['value_bindings'] = [{'binding_id': 'firm-prefix', 'value': '$FirmPrefix',
                'data_type': 'VARCHAR', 'resolved_value': 'TEST-', 'attribute_name': 'FirmPrefix',
                'is_placeholder': True, 'allow_project_specific_value': True}]
        if args.semantic_coverage != 'full':
            # Controlled missing-registry fixture through the production resolver.
            # The physical Snowflake catalog/SQL and later model calls remain real.
            from unittest.mock import Mock
            from app.core.semantic_context import SemanticContextService
            from app.schema.semantic_context import SemanticContextRefreshRequest
            semantic_service = object.__new__(SemanticContextService)
            semantic_service._session = session; semantic_service._settings = settings
            semantic_service._access_fingerprint = 'isolated-' + schema
            fixture_record = {**record, 'scope': 'TABLE', 'semantic_model': dict(record['semantic_model'])}
            if args.semantic_coverage == 'partial':
                fixture_record['semantic_model']['semantic_view'] = {'source': 'SEM_NATIVE_VIEWS', 'yaml': yaml.safe_dump({
                    'name': 'fixture', 'tables': [{'name': source['table'], 'base_table': source,
                    'dimensions': [{'name': item['column'], 'expr': item['column'], 'data_type': item['data_type'],
                        'description': item['description']} for item in catalog]}]})}
            else:
                fixture_record['semantic_model']['attributes'] = [{'name': 'OBSOLETE_NAME', 'data_type': 'VARCHAR',
                    'description': 'Prior semantic guidance only: never select this absent current column'}]
            semantic_service._semantic_model_service = SimpleNamespace(get_table_records=Mock(return_value=[fixture_record]))
            semantic_service._derived_source_service = SimpleNamespace(get_sources_by_ids=Mock(return_value=[]))
            semantic_service._table_selection_service = SimpleNamespace(list_attributes_for_tables=Mock(side_effect=AssertionError('Unexpected catalog fallback')))
            semantic_service.get_bundle=Mock(return_value=None); semantic_service.ensure_storage_exists=Mock()
            semantic_service._upsert_bundle=Mock();semantic_service._persist_bundle_artifact=Mock()
            semantic_service._active_curation_overlay=Mock(return_value={})
            semantic_started=time.monotonic()
            bundle=semantic_service.refresh_bundle(SemanticContextRefreshRequest(
                selected_source_tables=[TableRef.model_validate(source)], target_table=TableRef.model_validate(target)))
            payload['context'].update(semantic_context=bundle.semantic_context, semantic_bundle_id=bundle.bundle_id,
                semantic_level_requested=bundle.achieved_level)
            report['semantic_coverage_fixture']={'mode':args.semantic_coverage, 'missing_assets':bundle.missing_assets,
                'analyst_ready':bundle.analyst_ready, 'available_yaml_count':len(bundle.raw_assets),
                'resolver_seconds':round(time.monotonic()-semantic_started,3),
                'production_resolver':True, 'registry_records_controlled_fixture':True}
            service._agent_name=namespace+'.AGT_STTM_BUILDER'
            chat_payload=json.loads(json.dumps(payload))
            chat_payload['operation']='sttm.chat';chat_payload['data']={'intent':'CHAT', 'message':
                'Explain a supported DISPLAY_NAME transformation using the current source NAME column and approved $FirmPrefix. '
                "Use available semantic evidence and this published precedent: $FirmPrefix || COALESCE(TRIM(src.NAME), 'Unknown'). "
                'Do not stop because native YAML is missing. Explain evidence gaps at the end. Do not execute SQL or publish.'}
            chat_req=STTMBuilderEnvelopeRequest.model_validate(chat_payload)
            chat_config=service._request_scoped_analyst_config(chat_req,bundle,None)
            chat_started=time.monotonic()
            chat_messages=[{'role':'user','content':[{'type':'text',
                'text':service.project_agent_payload(chat_req,settings).text}]}]
            chat_raw,chat_thread,chat_diagnostics=agent.run_detailed(chat_messages,run_config=chat_config)
            chat_raw,chat_thread,chat_diagnostics=service._continue_context_retrieval(chat_req,chat_raw,
                chat_diagnostics,chat_thread,seed_messages=chat_messages,run_config=chat_config)
            parsed=service._parse_chat_response(chat_raw,chat_diagnostics)
            assert not (parsed[5] or {}).get('delegation'), 'Chat acceptance requires a final answer after bounded retrieval'
            from app.schema.sttm_builder import STTMBuilderResponse
            chat_response=STTMBuilderResponse.from_invocation(chat_req,thread_id=chat_thread,parent_message_id=None,
                agent=parsed[0],result=parsed[1],message=parsed[2],status=parsed[6])
            service._with_semantic_gap_notice(chat_req,chat_response)
            report['builder_chat_with_semantic_gaps']={'seconds':round(time.monotonic()-chat_started,3),
                'actual_model_submission':True,'message':chat_response.data.message,
                'semantic_evidence_coverage':chat_response.meta.get('semantic_evidence_coverage'),
                'analyst_tools':[tool['tool_spec']['name'] for tool in chat_config['tools']
                    if tool.get('tool_spec',{}).get('type')=='cortex_analyst_text_to_sql'],
                'parsed_error':bool(parsed[4]),'model_message_before_backend_notice':parsed[2]}
            assert parsed[2] and not parsed[4] and 'NAME' in parsed[2].upper()
            assert not report['builder_chat_with_semantic_gaps']['analyst_tools']
        if args.large_fixture:
            payload['context']['source_tables'] += large_sources
            for index, extra in enumerate(large_sources,1):
                alias=f'source_{index:03d}'
                payload['context']['semantic_context'].append({'table':extra,'semantic_model':{
                    'description':'Auxiliary sanitized contact identity reference; primary current driver src retains population.',
                    'attributes':record['semantic_model']['attributes']}})
                payload['context']['relation_graph']['nodes'].append({'relation_id':alias,'alias':alias,
                    'kind':'PHYSICAL_TABLE','table':extra,
                    'output_columns':[{'name':v['column'],'data_type':v['data_type']} for v in catalog]})
                payload['context']['relation_graph']['edges'].append({'edge_id':alias,'left_relation_id':'src',
                    'right_relation_id':alias,'join_type':'LEFT','conditions':[{'left_column':'ID','right_column':'ID','operator':'='}]})
        baseline_row = None
        driving_id = 'src'
        if args.workspace_request:
            if args.mixed_rules or args.large_fixture or args.scenario != 'new':
                raise ValueError('Workspace acceptance is separate from synthetic fixture options')
            external = STTMBuilderEnvelopeRequest.model_validate_json(args.workspace_request.read_text())
            if not external.context.target_table or external.context.target_table.database != 'BBI_STTM_TEST_DB' or any(ref.database != 'BBI_STTM_TEST_DB' for ref in external.context.source_tables or []):
                raise ValueError('Workspace acceptance is restricted to existing BBI_STTM_TEST_DB sources')
            payload = external.model_dump(mode='json')
            # Same logical test project as the existing native runner; no project writes.
            payload['context']['project_id'] = external.context.project_id or '1'
            payload['meta'].update(auto_map_fast_path='v1', auto_map_deadline_at=until.isoformat(), _automap_deadline=until.timestamp())
            chosen = [{'column':a.target_attribute,'data_type':a.target_data_type,'description':a.target_description or ''} for a in external.data.attributes]
            source = external.context.driving_table.model_dump(mode='json')
            target = external.context.target_table.model_dump(mode='json')
            fqn = external.context.driving_table.qualified_name
            driving_id = external.context.workspace_context.driving_relation_id
            actual_records = SemanticModelService(settings.model_copy(update={'snowflake_schema':'SCH_STTM_METADATA'})).get_table_records(session,external.context.source_tables)
            payload['context']['semantic_context'] = [{'table':{'database':r['database'],'schema':r['schema_name'],'table':r['table_name']},'semantic_model':r['semantic_model']} for r in actual_records]
            payload['context']['learning_context'] = {'automap_policy_version':POLICY_VERSION}
            report['external_workspace_acceptance'] = {'sources':len(external.context.source_tables),'targets':len(chosen),'existing_semantic_records':len(actual_records),'history':'No fixture FIR injected; separate mixed acceptance covers FIR reuse.'}

        if args.scenario in {'sql-upload','cte'}:
            import subprocess
            from app.core.sql_parser import parse_sql_document
            sql = (f'WITH src AS (SELECT ID, NAME, ACTIVE FROM {fqn} WHERE ACTIVE = TRUE) SELECT src.ID AS ID FROM src'
                   if args.scenario == 'cte' else f'SELECT src.ID AS ID FROM {fqn} src')
            parsed = parse_sql_document(sql).to_dict()
            uploaded = {'asset_id':'isolated-upload','parsed_summary':parsed,'import_preview':{'sql':sql,'table_references':[{
                'raw_identifier':fqn,'resolved_fqn':fqn,'reference_role':'source','resolution_status':'resolved','catalog_status':'available'}]}}
            imported = subprocess.run(['node',str(ROOT/'frontend/scripts/test-upload-workflow.cjs'),'--upload-json'],
                input=json.dumps({'uploaded':uploaded}),capture_output=True,text=True,timeout=60)
            if imported.returncode:raise RuntimeError('SQL upload importer acceptance failed')
            applied=json.loads(next(line.split(':',1)[1] for line in imported.stdout.splitlines() if line.startswith('UPLOAD_RESULT:')))
            if 'error' in applied:raise RuntimeError('SQL upload workspace rejected')
            snapshot=applied['snapshot'];graph=snapshot['relation_graph']
            graph['value_bindings']=payload['context']['relation_graph']['value_bindings']
            driving_id=snapshot.get('driving_relation_id') or applied['workspace']['drivingTableId']
            for node in graph['nodes']:
                if node['relation_id']==driving_id or node.get('kind')=='PHYSICAL_TABLE':
                    node['output_columns']=[{'name':item['column'],'data_type':item['data_type']} for item in catalog]
            snapshot['target_table']=target;snapshot['target_tables']=[target]
            snapshot['mapping_sql']=sql;snapshot['raw_mapping_sql']=sql
            payload['context'].update(workspace_context=snapshot,relation_graph=graph)
            report['sql_upload_parse_apply_verified']=True
            report['driving_relation_kind']=next(node['kind'] for node in graph['nodes'] if node['relation_id']==driving_id)
        if args.scenario=='partial':
            baseline_row={'id':'retained-id','target_column':'ID','target_type':'NUMBER','source_columns':['src.ID'],
                'mapping_mode':'source','rule':'Direct','status':'MAPPED','confidence':.93,'description':'Manually reviewed existing definition'}
            payload['context']['workspace_context']={'driving_relation_id':'src','target_table':target,'target_tables':[target],'mapping_rows':[baseline_row]}
        if args.scenario in {'sql-upload','cte'}:
            baseline_row=payload['context']['workspace_context']['mapping_rows'][0]
        if args.prepared_job_path:
            if not args.workspace_request:
                raise ValueError('Prepared job acceptance requires an authorized workspace request')
            from scripts.validate_automap_prepared_job import run
            return run(settings=settings, session=session, independent=independent, payload=payload,
                agent=agent, caller=service._parallel_caller, report=report, namespace=namespace)
        payload['context']['workspace_context']['driving_relation_id']=driving_id
        payload['meta']['auto_map_resolution_mode']='preserve_and_complete'
        req=STTMBuilderEnvelopeRequest.model_validate(payload)
        from app.core.auto_mapping_proxy import AutoMappingProxyClient
        resolution_proxy=AutoMappingProxyClient(settings)
        root_request=resolution_proxy._freeze_resolution(req,project_attributes=[])
        req=resolution_proxy._pending_resolution_request(root_request)
        req.context.execution_context=AgentExecutionContextV2(context_key='local-durable-acceptance')
        req.context.prepared_context_hash=preparation_hash(req.context)
        req.meta.update(auto_map_parent_resolution_version=FAST_INTEGRATION_VERSION,auto_map_prepared_readonly=True)
        req=canonical_model_wire_request(STTMBuilderService._with_intent_route(req))
        req.context.prepared_context_hash=preparation_hash(req.context);req.meta['_automap_fast_handoff']=freeze_fast_handoff(req,discovery={v['column']:{'evidence':mixed_evidence.get(v['column'],{}),'diagnostics':{'status':'available' if mixed_evidence.get(v['column']) else 'no_match','fixture':True}} for v in chosen if v['column'] in {item.target_attribute for item in req.data.attributes}})
        frozen_plan=resolution_proxy._trusted_resolution_plan(root_request)
        frozen_plan.update(handoff=req.meta['_automap_fast_handoff'],handoff_hash=resolution_proxy._resolution_digest(req.meta['_automap_fast_handoff']))
        report['scenario']=args.scenario
        report['root_resolution']=[{key:item.get(key) for key in ('target_attribute','status','origin','diagnostics')} for item in frozen_plan['targets']]
        report['preserved_targets']=[item['target_attribute'] for item in resolution_proxy._trusted_resolution_plan(root_request)['targets'] if item['status']=='definition_preserved']
        report['runtime_source_hashes']={name:hashlib.sha256((ROOT/'services/sttm-builder/app/core'/name).read_bytes()).hexdigest() for name in ('automap_admission.py','automap_durable_admission.py','automap_background_transport.py','automap_fast_transport.py','auto_mapping_proxy.py','automap_runtime.py','automap_scan.py','sttm_builder.py','automap_rule_handoff.py','semantic_context.py','semantic_evidence.py','automap_retrieval.py','automap_transform.py','automap_fast_context.py')}
        print(json.dumps({'stage':'scenario_prepared','scenario':args.scenario,'pending_targets':[item.target_attribute for item in req.data.attributes],'preserved_targets':report['preserved_targets'],'generation_policy':req.meta.get('automap_generation_policy'),'rules_policy':req.meta.get('automap_rules_policy'),'resolution':report['root_resolution']}),flush=True)
        decision=GovernanceDecision(trace_id='durable-local-acceptance',request_id=req.request_id,operation=req.operation.value)
        from app.core.auto_mapping_proxy import AutoMappingProxyClient
        from app.schema.sttm_builder import STTMBuilderResponse,SourceMappingResult,SubAgent,STTMStatus
        from app.core.automap_run_recovery import recovery_coordinator
        recovery_coordinator.start()
        invocations=[]
        def invoke(batch_request,**kwargs):
            from copy import copy
            from app.core.automap_row_candidates import validate_row_candidates
            # A batch owns its SQL session; concurrent model batches never share
            # a request Snowpark session. The original REST caller stays alive.
            with independent() as batch_session:
                worker=copy(service);worker._session=batch_session;worker._query_session=batch_session
                raw,thread,metadata=worker._invoke_retrieval_auto_map(batch_request,decision)
                invocations.append(metadata)
                envelope=json.loads(raw)
                response=STTMBuilderResponse.from_invocation(batch_request,thread_id=thread,parent_message_id=None,
                    agent=SubAgent.SOURCE_MAPPING_AGENT,result=SourceMappingResult.model_validate(envelope['data']['result']),
                    message=None,status=STTMStatus.COMPLETED,meta={**envelope.get('meta',{}),**dict(metadata)})
                if args.mixed_rules or args.workspace_request:
                    import asyncio
                    response._auto_map_execution = getattr(metadata, 'execution', None)
                    response = asyncio.run(worker._apply_complex_transformation_stage(batch_request, response, governance_decision=decision))
                    report['rule_stage'] = response.meta.get('transformation_stage')
                    report.setdefault('rule_stages', []).append(report['rule_stage'])
                # Same final row-level validation used by the public worker path.
                response=validate_row_candidates(worker,batch_request,response)
                print(json.dumps({'stage':'batch_returned','batch_index':kwargs.get('batch_index'),
                    'target_count':len(batch_request.data.attributes or [])}),flush=True)
                return response
        proxy=AutoMappingProxyClient(settings);proxy._invoke_batch=invoke
        report['test_setup_seconds']=round(time.monotonic()-main_started,2)
        started=time.monotonic()
        completed_batches=[]
        from threading import Event, Thread
        progress_stop=Event()
        progress_record={'owner':identity['U'],'recovery_role':identity['R'],
            'request_id':req.request_id,'created_at':datetime.now(UTC).isoformat()}
        def observe_progress():
            try:
                with independent() as observer:
                    while not progress_stop.is_set():
                        observed=proxy._with_runtime_progress({'status':'running','stage':'preparing'},progress_record,observer)
                        if observed.get('phase_counts'):
                            report.setdefault('progress_events',[]).append({'at':datetime.now(UTC).isoformat(),
                                'stage':observed['stage'],'phase_counts':observed['phase_counts']})
                        progress_stop.wait(5)
            except Exception as exc:report['progress_observer_error']=type(exc).__name__
        progress_thread=Thread(target=observe_progress,daemon=True);progress_thread.start()
        try:
            if args.full_mapping or args.concurrent_batches:
                response=proxy._invoke_worker_batches(req,headers={},
                    progress_callback=lambda index,attributes,response:completed_batches.append(index))
            else:
                response=proxy._invoke_complete_batch(req,headers={},batch_index=0,planned_model_payload={'fixture':'existing-semantics'})
        finally:
            progress_stop.set();progress_thread.join(timeout=10)
        response=proxy._complete_resolution_response(root_request,response)
        result=response.model_dump(mode='json');meta=invocations[-1]
        mappings=result['data']['result']['mappings']
        traces=[r.runtime_trace for item in invocations for r in getattr(getattr(item,'execution',(None,))[0],'_requests',{}).values() if getattr(r,'runtime_trace',None)]
        report['runtime_calls']=[{'call_index':index,'stage':getattr(runtime,'_request_stages',{}).get(index),
            'target_ids':list(request.target_ids),**request.runtime_trace.snapshot()}
            for item in invocations for runtime in [getattr(item,'execution',(None,))[0]] if runtime is not None
            for index,request in getattr(runtime,'_requests',{}).items() if getattr(request,'runtime_trace',None)]
        report['returned_mapping_definitions']=mappings
        usage=session.sql(f'SELECT STAGE,SUM(CALL_COUNT) CALLS,SUM(RETURNED_BYTES) BYTES,SUM(ARRAY_SIZE(RETURNED_IDS)) RECORDS FROM {namespace}.TBL_AUTOMAP_TOOL_CONTEXT GROUP BY STAGE').collect()
        report['native_evidence_tool_usage']=[row.as_dict() for row in usage]
        report['fir_attribution']={key:{'supported_recipe_ids':value.get('used_learning_ids',[]), 'backend_inferred_recipe_ids':(value.get('decision_basis') or {}).get('backend_inferred_recipe_ids',[])} for key,value in mappings.items()}
        report['mapping_evidence']={key:{field:value.get(field) for field in ('used_learning_ids','used_inference_ids','used_recommendation_ids','confidence_score','confidence_provenance')} for key,value in mappings.items()}
        report['actual_model_post_attempts']=sum(t.model_post_attempts for t in traces)
        report['evidence_review_model_posts']=sum(call['model_post_attempts'] for call in report['runtime_calls'] if call['stage']=='evidence_review')
        report['actual_thread_post_attempts']=sum(t.thread_post_attempts for t in traces)
        report['transport_retries']=response.meta.get('durable_transport_retries',0)
        report['full_mapping']=args.full_mapping
        report['batch_dispatch']=response.meta.get('auto_mapping_dispatch')
        report['completed_batch_indices']=sorted(completed_batches)
        report['batch_results']=[{'targets':v.get('auto_map_retrieval',{}).get('targets'),
            'model_call_count':v.get('auto_map_retrieval',{}).get('model_call_count'),
            'failure':(v.get('auto_map_fast_path') or {}).get('fast_diagnostics'),
            'warnings':(v.get('auto_map_fast_path') or {}).get('warnings',[])} for v in invocations]
        selected_status = {key: next((candidate.get('validation_status') for candidate in value.get('candidates', [])
            if candidate.get('candidate_id') == (value.get('selected_candidate_id') or value.get('draft_candidate_id'))), None)
            for key, value in mappings.items()}
        report.update(source_table=fqn,semantic_registry=settings.resolved_semantic_native_views_table,
            requested_targets=[v['column'] for v in chosen],elapsed_seconds=round(time.monotonic()-started,2),
            proposals=sum(value == 'valid' for value in selected_status.values()),unresolved=sum(value != 'valid' for value in selected_status.values()),
            selected_sources={k:v.get('source_attributes') for k,v in mappings.items()},
            unresolved_reasons={k:v.get('unmatched_reason') for k,v in mappings.items() if selected_status[k] != 'valid'},
            fast_status=meta.get('auto_map_fast_path'),
            validation_errors={k:next((c.get('validation_errors',[]) for c in v.get('candidates',[]) if c.get('candidate_id')==(v.get('selected_candidate_id') or v.get('draft_candidate_id'))),[]) for k,v in mappings.items()},
            validation_status={k:next((c.get('validation_status') for c in v.get('candidates',[]) if c.get('candidate_id')==(v.get('selected_candidate_id') or v.get('draft_candidate_id'))),None) for k,v in mappings.items()},
            review_warning_codes=sorted({w.code for w in proxy._response_warnings(response)}|
                {w['code'] for item in invocations for w in (item.get('auto_map_fast_path') or {}).get('warnings',[])}),
            model_call_count=sum(item.get('auto_map_retrieval',{}).get('model_call_count',0) for item in invocations))
        report['identity_sources_correct']=all(len(sources)==1 and sources[0].split('.')[-1].strip('"').upper()==name.upper()
            for name,sources in report['selected_sources'].items())
        rows=session.sql(f'SELECT SLOT_ID,STATE,MODEL_RUN_ID FROM {table} ORDER BY SLOT_ID').collect()
        report['execution_occupied_after']=sum(r['STATE']!='FREE' for r in rows if r['SLOT_ID']<=12)
        report['old_quarantines_unchanged']=sum(r['STATE']=='QUARANTINED' for r in rows if r['SLOT_ID']>12)==4
        report['status']='passed' if (set(mappings)=={v['column'] for v in chosen}
            and report['proposals']==len(chosen) and report['execution_occupied_after']==0
            and report['old_quarantines_unchanged']
            and report['identity_sources_correct']
            and all(v=='valid' for v in report['validation_status'].values())
            and not (report.get('batch_dispatch') or {}).get('failed_batches')) else 'failed'
        if args.mixed_rules:
            from app.core.mapping_sql import MappingSqlService
            from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
            compiled = MappingSqlService(session=session, analyst_client=None).compile(MappingSqlCompileRequest(
                relation_graph=req.context.relation_graph, driving_relation_id=driving_id, validate_with_explain=True,
                mappings=[MappingSqlMappingItem(target_column='ID',source_columns=baseline_row['source_columns'],mapping_mode='source') if key=='ID' and baseline_row else MappingSqlMappingItem(target_column=key, source_columns=value.source_attributes,
                    source_dependencies=value.source_dependencies, mapping_mode=value.mapping_mode,
                    constant_value=value.constant_value, attribute_name=value.attribute_name,
                    value_binding_ids=value.value_binding_ids, expression=value.preprocessing_rule,
                    rule=value.preprocessing_rule_type or 'Direct') for key, value in response.result.mappings.items()]))
            actual = [row.as_dict() for row in session.sql(compiled.preview_sql).collect()]
            expected = [{'ID': 1, 'DISPLAY_NAME': 'TEST-Alice', 'FIRM_VALUE': 'TEST-', 'VALUE_CASE': 'Test firm', 'OWNERNAME': None},
                {'ID': 2, 'DISPLAY_NAME': 'TEST-Bob', 'FIRM_VALUE': 'TEST-', 'VALUE_CASE': 'Test firm', 'OWNERNAME': None},
                {'ID': 3, 'DISPLAY_NAME': 'TEST-Unknown', 'FIRM_VALUE': 'TEST-', 'VALUE_CASE': 'Test firm', 'OWNERNAME': None}]
            if args.large_fixture:
                for row in expected:
                    row.update({f'ID_COPY_{index:02d}':row['ID'] for index in range(1,36)})
            fixture_ids = {(item.get('pattern') or item)['pattern_id'] for item in mixed_evidence['DISPLAY_NAME']['canonical_target_mapping_patterns']}
            report['fir_recipe_used'] = bool(fixture_ids & set(response.result.mappings['DISPLAY_NAME'].used_learning_ids))
            if args.scenario=='cte':expected=[row for row in expected if row['ID'] != 2]
            report['output_matches_expected'] = sorted(actual, key=lambda row: row['ID']) == expected
            if baseline_row:
                report['baseline_preserved']= 'ID' in report['preserved_targets'] and 'ID' not in {target for call in report['runtime_calls'] for target in call['target_ids']}
            report['confidence_scores'] = {key: value.confidence_score for key, value in response.result.mappings.items() if key not in report['preserved_targets']}
            report['mixed_mapping_definitions'] = {key: value.model_dump(mode='json') for key, value in response.result.mappings.items()}
            report['rule_stages'] = {key: value.rule_stage for key, value in response.result.mappings.items()}
            report['actual_rule_model_posts'] = sum(call['model_post_attempts'] for call in report['runtime_calls'] if call['stage']=='transformation_rule')
            report['status'] = 'passed' if (report['output_matches_expected'] and report['fir_recipe_used'] and report['actual_rule_model_posts'] > 0
                and report['rule_stages'].get('DISPLAY_NAME') == 'rule_complete'
                and report['rule_stages'].get('VALUE_CASE') == 'rule_complete'
                and all(value > 0 for value in report['confidence_scores'].values())
                and report['execution_occupied_after'] == 0 and report['old_quarantines_unchanged']
                and report['evidence_review_model_posts'] == 0 and (not baseline_row or report.get('baseline_preserved'))) else 'failed'
        if args.workspace_request:
            report['status'] = 'passed' if (set(mappings)=={v['column'] for v in chosen}
                and report['proposals'] > 0
                and all(isinstance(v.get('confidence_score'),(int,float)) for v in mappings.values())
                and report['execution_occupied_after']==0 and not (report.get('batch_dispatch') or {}).get('failed_batches')) else 'failed'
            report['rule_stages'] = {key:value.get('rule_stage') for key,value in mappings.items()}
            report['business_approval'] = False
        if args.require_evidence_tool:
            report['required_native_tool_verified']=all(any(row['STAGE']==stage and row['CALLS']>0 and row['RECORDS']>0
                for row in report['native_evidence_tool_usage']) for stage in ('source_mapping','transformation_rule'))
            if not report['required_native_tool_verified']:report['status']='failed'
        report['provider_run_ids']=[r['MODEL_RUN_ID'] for r in rows if r['MODEL_RUN_ID']]
        if report['status']=='passed' and args.review_output:
            # This runner constructs only sanitized fixtures; no connection config,
            # authorization headers or agent-client state enters this artifact.
            args.review_output.parent.mkdir(parents=True,exist_ok=True)
            args.review_output.write_text(json.dumps({'fixture_schema':namespace,
                'relation_graph':req.context.relation_graph.model_dump(mode='json'),
                'workspace_context':req.context.workspace_context.model_dump(mode='json') if req.context.workspace_context else None,
                'target_table':target,'definitions':mappings,
                'expected_output':expected if args.mixed_rules else None},indent=2,default=str))
            report['review_artifact']=str(args.review_output)

    except Exception as exc:
        report.update(status='failed',error_type=type(exc).__name__,error_code=getattr(exc,'errno',None))
        raise
    finally:
        from app.core.automap_run_recovery import recovery_coordinator
        recovery_coordinator.stop()
        from app.core.snowflake import close_write_pools
        close_write_pools()
        SnowflakeReductionArchive._collect_sql=original_collect
        SnowflakeCallAdmission._sql=original_admission_sql
        BackgroundRunTransport._json_exchange=original_exchange
        if created:
            # Preserve unknown real operations and their audit for reconciliation.
            try:
                occupied=session.sql(f"SELECT COUNT(*) C FROM {table} WHERE STATE<>'FREE' AND NOT "
                    "(CALLER_ID='LEGACY_TEST_CALLER' AND JOB_ID='old-test' AND OWNER_TOKEN='legacy-fixture' "
                    "AND RECONCILIATION_REF IS NULL AND MODEL_RUN_ID IS NULL)").collect()[0]['C']
                if not occupied and args.retain_successful_fixture and report['status']=='passed':
                    report.update(scratch_cleanup='retained_for_local_review',scratch_schema=namespace)
                elif not occupied:
                    session.sql('DROP SCHEMA '+namespace+' CASCADE').collect();report['scratch_cleanup']='completed'
                else:report['scratch_cleanup']='retained_for_recovery';report['scratch_schema']=namespace
            except Exception as exc:
                report.update(scratch_cleanup='retained_for_inspection',scratch_schema=namespace,
                    cleanup_error_type=type(exc).__name__)
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2,default=str))
        print(json.dumps(report,default=str),flush=True);session.close()
    return 0 if report['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
