"""Opt-in DEV synthetic parallel preparation or controlled synthetic integration.

No discovery, business-table queries, ad-hoc SQL, DDL, grants, or cleanup.
Only identity/permit/archive methods and full-mode agent metadata reads use SQL.
--full-mapping verifies runtime agent specifications before inference, then runs
real invoke_batch preparation, exact reads, parsing and compiler validation.
Discovery is an explicitly empty synthetic fixture, NOT history acceptance.
No business mappings are persisted. Existing synthetic archives/permits and
agent thread APIs remain allowed. Authentication/shutdown are outside deadlines.
The default preparation-only mode does not inspect the test agent.
Browser authentication and safe shutdown are outside the cooperative 120-second
preparation deadline. Uncertain calls retain/quarantine their runtime permits;
this script never resets them or deletes retained synthetic archive artifacts.
--diagnose-request-validation sends only {} to the approved test agent:run API;
required messages are absent, so this is a server-validation-only diagnostic.
Both diagnostic modes bypass preparation, permits, and archives entirely.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import asdict, replace
import json
import logging
import os
from pathlib import Path
from queue import Empty, Queue
import re
import ssl
from threading import Condition, Event
import time
from types import SimpleNamespace
from uuid import uuid4
import warnings


EXPECTED_ACCOUNT = "MHSUEJT.GD01711"
EXPECTED_ROLE = "FFP_HDP_DLAB_DB_DEPLOY_ROLE_DEV"
EXPECTED_HOST = "mhsuejt-gd01711.snowflakecomputing.com"
METADATA = "FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA"
TEST_AGENT = METADATA + ".AGT_AUTOMAP_SCAN_DEV_TEST"
FINAL_AGENT = METADATA + ".AGT_SOURCE_MAPPING"
FULL_SECONDS = 300
FINAL_ROUNDS = 3
PERMIT_TABLE = METADATA + ".TBL_AUTOMAP_CALL_ADMISSION_DEV_TEST"
ARCHIVE_TABLE = METADATA + ".TBL_AUTOMAP_CONTEXT_ARCHIVE_DEV_TEST"
POOL_EPOCH = "b84e9707-12a3-4aa6-b841-5a1da77e85c8"
WORKERS = 2
MAX_CALLS = 8
SECONDS = 120
MESSAGE_BUDGET = 60_000
TARGETS = ("CUSTOMER_EMAIL", "CUSTOMER_BIRTH_DATE")


class ProbeSafetyError(RuntimeError):
    """Fail closed; exception messages are never printed."""


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--connection", required=True, default=None,
                        help="Explicit named Snowpark connection; no default or owner fallback.")
    result.add_argument("--execute", action="store_true",
                        help="Permit the selected live preparation, full mapping or diagnostic (otherwise refuse).")
    diagnostic = result.add_mutually_exclusive_group()
    diagnostic.add_argument("--full-mapping", action="store_true",
                            help="Controlled synthetic invoke_batch integration; no business history or saves.")
    diagnostic.add_argument("--diagnose-http", action="store_true",
                            help="Read test-agent metadata only; no inference, permit or archive writes.")
    diagnostic.add_argument("--diagnose-request-validation", action="store_true",
                            help="One validation-only POST of {}; no messages, inference, threads, "
                                 "background, tools, permits or archives. Requires --execute.")
    result.add_argument("--ca-bundle", default=None,
                        help="Optional trusted PEM bundle; otherwise honor SSL_CERT_FILE / "
                             "REQUESTS_CA_BUNDLE / CURL_CA_BUNDLE, then system defaults.")
    return result


def configure_tls(bundle):
    bundle = bundle or next((os.environ[name] for name in
        ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE") if os.environ.get(name)), None)
    if bundle:
        path = Path(bundle).expanduser().resolve(strict=True)
        ssl.create_default_context(cafile=str(path))
        for name in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
            os.environ[name] = str(path)
    else:
        ssl.create_default_context()
    # No verify=False, insecure mode, or certificate-error fallback.


def fixture(run_id, *, full_mapping=False):
    """In-memory metadata only: two complete small tables and one oversized table.

    There are no expected matches, example answers, seeded candidates, learned
    mappings, or selected/pinned source columns in the input to the model.
    """
    from app.core.automap_retrieval import AutoMapContext

    definitions = (
        ("synthetic_contact", "contact", (
            ("CONTACT_KEY", "Stable identifier of a customer contact."),
            ("CURRENT_EMAIL", "Current preferred electronic mail address of the contact."),
            ("FORMER_EMAIL", "Obsolete electronic mail address retained for history."),
            ("INGESTED_AT", "Time the metadata record was ingested, not a birth date."))),
        ("synthetic_person", "person", (
            ("PERSON_KEY", "Stable identifier of a person."),
            ("BIRTH_DATE", "Calendar date on which the person was born."),
            ("CREATED_AT", "Time the record was created, not a birth date."),
            ("DISPLAY_NAME", "Preferred display name of the person."))),
        ("synthetic_oversized", "oversized", tuple(
            (f"EXTENDED_FIELD_{index}", "Synthetic extended metadata. " * 6000)
            for index in range(4))),
    )
    nodes = []
    for relation, alias, columns in definitions:
        semantics = [{"name": name, "data_type": "TEXT", "business_meaning": meaning}
                     for name, meaning in columns]
        nodes.append({"relation_id": relation, "alias": alias, "kind": "TABLE",
                      "output_columns": semantics, "column_semantics": deepcopy(semantics),
                      "parent_relation_ids": []})
    payload = {"operation": "sttm.auto_map", "request_id": run_id, "context": {
        "target_table": {"database": "SYNTHETIC_ONLY", "schema": "FIXTURE", "table": "CUSTOMER"},
        "workspace_context": {"driving_relation_id": "synthetic_contact",
                              "filters": {"population": "Synthetic customer population only"}},
        "relation_graph": {"nodes": nodes, "edges": [
            {"left_relation_id": "synthetic_contact", "right_relation_id": "synthetic_person",
             "additional_predicate": "contact.CONTACT_KEY = person.PERSON_KEY"}]},
        "mapping_intent": {"guidance": "Preserve customer grain; do not substitute ingestion or creation dates."},
        "learning_context": {}},
        "data": {"intent": "AUTO_MAP", "attributes": [
            {"target_attribute": TARGETS[0], "description": "Current customer email address"},
            {"target_attribute": TARGETS[1], "description": "Customer date of birth"}]}}
    if full_mapping:
        context = payload["context"]
        context["source_tables"] = []
        context["semantic_context"] = []
        for node in nodes:
            table = {"database": "SYNTHETIC_ONLY", "schema": "FIXTURE",
                     "table": node["alias"].upper()}
            node.update(kind="PHYSICAL_TABLE", table=table)
            for columns in (node["output_columns"], node["column_semantics"]):
                for column in columns:
                    column["data_type"] = "DATE" if column["name"] == "BIRTH_DATE" else "TEXT"
            context["source_tables"].append(table)
            context["semantic_context"].append({"table": table, "semantic_model": {
                "attributes": deepcopy(node["column_semantics"])}})
        context["driving_table"] = nodes[0]["table"]
        context["relation_graph"]["edges"][0].update(edge_id="synthetic_contact_person",
            provenance="synthetic_fixture", validation_status="valid")
        for attribute in payload["data"]["attributes"]:
            attribute["target_table"] = context["target_table"]
            attribute["target_description"] = attribute.pop("description")
            attribute["target_data_type"] = "DATE" if attribute["target_attribute"] == TARGETS[1] else "TEXT"
        context["semantic_context"].append({"table": context["target_table"], "semantic_model": {
            "attributes": [{"name": item["target_attribute"], "data_type": item["target_data_type"],
                            "business_meaning": item["target_description"]}
                           for item in payload["data"]["attributes"]]}})
    return AutoMapContext(payload)


def plan_fixture(store, owner_id):
    """Choose a small budget by checking the actual whole-table planner offline."""
    from app.core.automap_scan_context import prepare_scan_context
    from app.core.automap_shards import MessageBudget, MessageBudgetError

    typed = bool(store.original["context"].get("source_tables"))
    blocked = "SYNTHETIC_ONLY.FIXTURE.OVERSIZED" if typed else "synthetic_oversized"
    target_group = "table:SYNTHETIC_ONLY.FIXTURE.CUSTOMER"
    for size in range(12_000, 30_001, 1000):
        try:
            prepared = prepare_scan_context(store, owner_id=owner_id, budget=MessageBudget(size, size))
            page = prepared.registry.directory(scope=prepared.scope, max_entries=128).payload
        except MessageBudgetError:
            continue
        if (prepared.blocked_table_ids == (blocked,)
                and len(page["entries"]) == WORKERS and page["next_cursor"] is None):
            members = []
            for entry in page["entries"]:
                message = prepared.registry.read_shard(scope=prepared.scope, shard_id=entry["shard_id"])
                ids = {item["record_id"] for item in message.payload["records"]}
                groups = [(key, set(group)) for key, group in prepared.registry.atomic_groups.items()
                          if ids.intersection(group)]
                # Typed targets add their own complete contract group. Permit it
                # alongside exactly one whole source table, never a split group.
                source_groups = [group for key, group in groups if key != target_group]
                if (len(source_groups) != 1 or any(not group <= ids for _, group in groups)
                        or ids != set().union(*(group for _, group in groups))):
                    raise ProbeSafetyError()
                members.extend(ids)
            if len(members) != len(set(members)):
                raise ProbeSafetyError()
            return prepared, MessageBudget(size, size)
    raise ProbeSafetyError()


def validate_identity(session, expected=None):
    from app.core.automap_runtime import _session_identity

    actual = _session_identity(session)
    if actual.account_namespace != EXPECTED_ACCOUNT or actual.role != EXPECTED_ROLE:
        raise ProbeSafetyError()
    if expected is not None and actual != expected:
        raise ProbeSafetyError()
    return actual


class SessionPool:
    """Two pre-created exclusive sessions; never clone tokens or replace failures."""

    def __init__(self, sessions, deadline, cancellation):
        if len(sessions) != WORKERS or len({id(item) for item in sessions}) != WORKERS:
            raise ProbeSafetyError()
        self.available = Queue(maxsize=WORKERS)
        for session in sessions:
            self.available.put_nowait(session)
        self.deadline = deadline
        self.cancellation = cancellation
        self.condition = Condition()
        self.active = 0
        self.closing = False
        self.failed = False

    @contextmanager
    def lease(self):
        session = None
        with self.condition:
            if self.closing or self.failed or self.cancellation.is_set():
                raise ProbeSafetyError()
            self.active += 1
        try:
            while session is None:
                remaining = self.deadline - time.monotonic()
                if remaining <= 0 or self.cancellation.is_set():
                    raise TimeoutError()
                with self.condition:
                    if self.failed or self.closing:
                        raise ProbeSafetyError()
                try:
                    session = self.available.get(timeout=min(0.1, remaining))
                except Empty:
                    continue
            yield session
        except BaseException:
            with self.condition:
                self.failed = True
            raise
        finally:
            if session is not None:
                self.available.put_nowait(session)
            with self.condition:
                self.active -= 1
                self.condition.notify_all()

    def drain(self):
        # Never close a session while a runtime SQL operation still owns it.
        with self.condition:
            self.closing = True
            while self.active:
                self.condition.wait(timeout=0.1)


def settings_for_probe(*, full_mapping=False):
    from app.core.config import Settings

    class ProbeSettings(Settings):
        @classmethod
        def settings_customise_sources(cls, settings_cls, init_settings,
                                       env_settings, dotenv_settings, file_secret_settings):
            # Do not inherit unrelated deployments, credentials, audits or flags.
            return (init_settings,)

    extra = {"SNOWFLAKE_SOURCE_MAPPING_AGENT": FINAL_AGENT,
             "AUTOMAP_CONTEXT_TARGET_SECONDS": FULL_SECONDS,
             "AUTOMAP_CONTEXT_MAX_ROUNDS": FINAL_ROUNDS,
             "SNOWFLAKE_AGENT_RETRY_ATTEMPTS": 1} if full_mapping else {}
    return ProbeSettings(_env_file=None, **extra, SNOWFLAKE_ACCOUNT="MHSUEJT-GD01711",
        SNOWFLAKE_HOST=EXPECTED_HOST, SNOWFLAKE_REST_HOST=EXPECTED_HOST,
        SNOWFLAKE_DATABASE=METADATA.split(".")[0], SNOWFLAKE_SCHEMA=METADATA.split(".")[1],
        SNOWFLAKE_ROLE=EXPECTED_ROLE, FIR_TARGET_MAPPING_PATTERNS_V2=False,
        AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTOMAP_PARALLEL_CONTEXT_V1=True,
        AUTOMAP_PARALLEL_TEST_AGENT=TEST_AGENT, AUTOMAP_PARALLEL_PERMIT_TABLE_FQN=PERMIT_TABLE,
        AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN=ARCHIVE_TABLE,
        AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE=EXPECTED_ACCOUNT, AUTOMAP_PARALLEL_POOL_EPOCH=POOL_EPOCH,
        AUTOMAP_PARALLEL_POOL_CAPACITY=WORKERS, AUTOMAP_PARALLEL_MAX_WORKERS=WORKERS,
        AUTOMAP_PARALLEL_MAX_CALLS=MAX_CALLS, AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS=MAX_CALLS - WORKERS,
        AGENT_OUTBOUND_MESSAGE_MAX_CHARS=MESSAGE_BUDGET, AGENT_OUTBOUND_MESSAGE_MAX_BYTES=MESSAGE_BUDGET)


def summarize(result, prepared, run_id, elapsed):
    from app.core.automap_scan import CandidateRole, ScanStatus

    hits = []
    statuses = Counter()
    if result.scan is not None:
        for shard in result.scan.shards:
            statuses[shard.status.value] += 1
            if shard.status != ScanStatus.SUCCEEDED:
                continue
            for target in shard.targets:
                for candidate in target.candidates:
                    if candidate.role != CandidateRole.SOURCE:
                        continue
                    identity = prepared.resolve_source(candidate, scope=prepared.scope,
                        generation=prepared.registry.generation, shard_id=shard.shard_id).identity
                    hits.append({"target": target.target_id, "relation": identity.relation_id,
                                 "column": identity.name})
    # Only locally resolved synthetic column names and typed counts/status codes;
    # no prompts, headers, token, raw responses, or warning detail bodies.
    return {"status": "preparation_returned", "run_id": run_id,
        "scope": "parallel_preparation_only", "final_full_app_run": False,
        "final_mapping_validation": "not_run", "elapsed_seconds": round(elapsed, 2),
        "scan_budget_bytes": prepared.registry.budget.max_bytes,
        "coverage": asdict(result.coverage), "shard_status_counts": dict(statuses),
        "warnings": sorted({item.code for item in result.warnings}),
        "source_candidate_hits": sorted(hits, key=lambda item: (item["target"], item["relation"], item["column"])),
        "source_candidate_hit_count": len(hits),
        "targets_with_source_hits": len({item["target"] for item in hits}),
        "selected_columns": [{"relation": item.relation_id, "column": item.name}
                             for item in result.selected_source_identities],
        "archive_references": {"snapshot": result.snapshot_archive_ref,
                               "prepared": result.prepared_archive_ref, "outcome": result.outcome_archive_ref}}


def verify_tool_free(spec):
    """NULL/missing tool arrays mean no tools; malformed nonempty values do not."""
    if not isinstance(spec, dict):
        raise ProbeSafetyError()
    if spec.get("tools") is not None and spec["tools"] != []:
        raise ProbeSafetyError()
    if spec.get("tool_resources") is not None and spec["tool_resources"] != {}:
        raise ProbeSafetyError()
    instructions = spec.get("instructions")
    if not isinstance(instructions, dict) or not any(
            isinstance(instructions.get(key), str) and instructions[key].strip()
            for key in ("orchestration", "response", "system")):
        raise ProbeSafetyError()
    orchestration = spec.get("orchestration")
    if orchestration is None:
        orchestration = {}
    if not isinstance(orchestration, dict):
        raise ProbeSafetyError()
    capabilities = orchestration.get("capabilities")
    if capabilities is None:
        capabilities = {}
    if not isinstance(capabilities, dict) or any(value is not False for value in capabilities.values()):
        raise ProbeSafetyError()
    return deepcopy(spec)


def default_specification(session, agent=FINAL_AGENT):
    """DESCRIBE resolves the named run's default, unlike a possibly LIVE REST GET.

    Metadata-only read, no business SQL. Never guess a version from LAST/v3 or
    substitute LIVE instructions when the default specification differs.
    """
    import yaml

    if agent not in (TEST_AGENT, FINAL_AGENT):
        raise ProbeSafetyError()
    rows = session.sql("DESCRIBE AGENT " + agent).collect(
        statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "5", "LOCK_TIMEOUT": "1"})
    if len(rows) != 1:
        raise ProbeSafetyError()
    row = {key.lower(): value for key, value in rows[0].as_dict().items()}
    spec = row.get("agent_spec")
    if isinstance(spec, str):
        spec = yaml.safe_load(spec)
    return verify_tool_free(spec)


def reject_native_tools(payload):
    if isinstance(payload, dict):
        if (any(payload.get(key) for key in ("tool_use", "tool_result", "tool_calls"))
                or str(payload.get("type", "")).lower() in {
                    "tool_use", "tool_result", "tool_call", "cortex_search", "cortex_analyst_text_to_sql"}):
            raise ProbeSafetyError()
        for value in payload.values():
            reject_native_tools(value)
    elif isinstance(payload, list):
        for value in payload:
            reject_native_tools(value)


def guarded_agent_type():
    from app.core.snowflake_agent import SnowflakeAgentClient

    class GuardedAgent(SnowflakeAgentClient):
        def verify_startup(self):
            self._verified_specs = {name: verify_tool_free(self.get_specification(name))
                                    for name in (TEST_AGENT, FINAL_AGENT)}
            default_specification(self.metadata_session, TEST_AGENT)
            self._default_spec = default_specification(self.metadata_session)
            self.final_calls = 0

        def run_detailed(self, messages, *, agent=None, **kwargs):
            if (agent != FINAL_AGENT or self.final_calls >= FINAL_ROUNDS
                    or kwargs.get("thread_id") is not None or kwargs.get("parent_message_id") is not None
                    or kwargs.get("run_config") is not None or self._retry_attempts != 1):
                raise ProbeSafetyError()
            # Revalidate GET and the actual named-default spec immediately before
            # every final call. Divergence between LIVE and default is permitted;
            # neither is substituted and either changing mid-run fails closed.
            end = time.monotonic() + min(self._timeout, kwargs.get("request_timeout") or self._timeout)
            timeout = self._timeout
            try:
                self._timeout = min(30, end - time.monotonic())
                if self._timeout <= 0:
                    raise ProbeSafetyError()
                current = verify_tool_free(self.get_specification(FINAL_AGENT))
            finally:
                self._timeout = timeout
            if (current != self._verified_specs[FINAL_AGENT]
                    or default_specification(self.metadata_session) != self._default_spec):
                raise ProbeSafetyError()
            remaining = end - time.monotonic()
            if remaining <= 0:
                raise ProbeSafetyError()
            kwargs["request_timeout"] = remaining
            self.final_calls += 1
            result = super().run_detailed(messages, agent=agent, **kwargs)
            reject_native_tools(result[2])
            return result

    return GuardedAgent


def synthetic_service_type():
    from app.core.sttm_builder import STTMBuilderService

    class SyntheticService(STTMBuilderService):
        # Only discovery and Analyst are synthetic/denied boundaries. In this
        # checkout invoke_batch constructs STTMAgentRequestEnvelope directly;
        # there is no _build_agent_request_payload hook or semantic-service call.
        def _discover_auto_map_batch_evidence(self, req, targets, **options):
            return {target: {"evidence": {}, "available_evidence": {}, "source_candidates": {},
                             "diagnostics": {"status": "no_applicable_match", "route": "synthetic_empty"}}
                    for target in targets}

        def _auto_map_analyst_evidence(self, *args, **kwargs):
            raise ProbeSafetyError()

        def _build_auto_map_parallel_runtime(self, *, req, decision, store, deadline):
            self.synthetic_store = store
            self.synthetic_original = deepcopy(store.original)
            _prepared, budget = plan_fixture(store, self._parallel_caller.native_user)
            bundle = super()._build_auto_map_parallel_runtime(
                req=req, decision=decision, store=store, deadline=deadline)
            from app.core.automap_scan import CandidateRole
            limits = replace(bundle.limits, scan_budget=budget, role_minima=((CandidateRole.SOURCE, 1),))
            if limits.max_workers != WORKERS or limits.max_calls != MAX_CALLS:
                raise ProbeSafetyError()
            return replace(bundle, limits=limits, cancellation=self.synthetic_cancellation)

    return SyntheticService


def run_full_mapping(service, request, decision):
    """Return only locally resolved identities/codes, never model prose or bodies."""
    from app.core.automap_batch import invoke_batch
    from app.schema.sttm_builder import SourceMappingResult, STTMStatus

    before = request.model_dump(mode="json")
    raw, _thread, metadata = invoke_batch(service, request, decision)
    parsed = service._parse_envelope(raw)
    result = parsed[1]
    store = getattr(service, "synthetic_store", None)
    unchanged = (request.model_dump(mode="json") == before and store is not None
                 and store.original == service.synthetic_original)
    retrieval = metadata.get("auto_map_retrieval", {})
    parallel = retrieval.get("parallel_preparation", {})
    coverage = parallel.get("coverage") or {}
    warnings = parallel.get("warnings", [])
    allowed_codes = {"scan_incomplete", "non_exhaustive_summary", "table_context_oversized",
                     "parallel_preparation_failed", "parallel_message_budget_exceeded",
                     "parallel_read_budget_exceeded", "parallel_optional_read_budget_exceeded",
                     "parallel_search_more_blocked", "reduction_incomplete", "global_context_blocked",
                     "selection_constraints_blocked", "selection_limited", "no_candidate_evidence",
                     "canceled", "timed_out"}
    safe_warnings = sorted({item["code"] if item.get("code") in allowed_codes else "other_warning"
                            for item in warnings})
    excluded = any(item.get("code") == "table_context_oversized"
                   and item.get("field") == "table:SYNTHETIC_ONLY.FIXTURE.OVERSIZED" for item in warnings)
    expected = {TARGETS[0]: ("synthetic_contact", "CURRENT_EMAIL"),
                TARGETS[1]: ("synthetic_person", "BIRTH_DATE")}
    nodes = before["context"]["relation_graph"]["nodes"]
    references = {}
    for node in nodes:
        table = ".".join(node["table"][part] for part in ("database", "schema", "table"))
        for column in node["output_columns"]:
            identity = (node["relation_id"], column["name"])
            for prefix in (node["alias"], node["relation_id"], table):
                references[(prefix + "." + column["name"]).upper()] = identity
    mappings = []
    valid = isinstance(result, SourceMappingResult) and parsed[4] is None and parsed[6] != STTMStatus.FAILED
    valid = valid and set(result.mappings) == set(TARGETS)
    if valid and store is not None:
        for attribute in request.data.attributes:
            candidate = result.mappings[attribute.target_attribute]
            missing = service._validate_auto_map_candidate(request, store, attribute, candidate)
            identities = [references.get(source.replace('"', '').upper()) for source in candidate.source_attributes]
            accepted = (not missing and identities == [expected[attribute.target_attribute]]
                        and candidate.transformation_classification != "unresolved"
                        and candidate.mapping_mode == "source")
            valid = valid and accepted
            mappings.append({"target": attribute.target_attribute,
                "sources": [{"relation": identity[0], "column": identity[1]}
                            for identity in identities if identity is not None],
                "validation": "passed" if not missing else "failed",
                "expected_identity": accepted})
    else:
        valid = False
    accepted = bool(valid and unchanged and excluded
                    and {"scan_incomplete", "non_exhaustive_summary"} <= set(safe_warnings)
                    and coverage.get("succeeded_shards") == WORKERS
                    and coverage.get("excluded_group_count") == 1
                    and coverage.get("mapping_blocked") is False
                    and 0 < retrieval.get("model_call_count", 0) <= FINAL_ROUNDS)
    return {"status": "accepted" if accepted else "not_accepted",
            "scope": "controlled_synthetic_integration", "history_acceptance": False,
            "business_persistence": False, "original_payload_unchanged": unchanged,
            "mappings": mappings, "warnings": safe_warnings,
            "excluded_tables": ["synthetic_oversized"] if excluded else []}, accepted


def execute(connection, run_id, *, full_mapping=False):
    from snowflake.snowpark import Session
    from app.core.automap_parallel import prepare_parallel
    from app.core.automap_scan import CandidateRole
    from app.core.snowflake import SnowflakeClient
    from app.core.snowflake_agent import SnowflakeAgentClient
    from app.core.sttm_builder import STTMBuilderService
    from app.guardrails.contracts.decisions import GovernanceDecision
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest

    sessions = []
    pool = None
    cancellation = Event()
    try:
        if full_mapping:
            os.environ.pop("WORKBENCH_LOCAL_MODEL_AUDIT_DIR", None)
        store = fixture(run_id, full_mapping=full_mapping)
        settings = settings_for_probe(full_mapping=full_mapping)
        settings.validate_parallel_automap()
        request = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map",
            "request_id": run_id, "data": {"intent": "AUTO_MAP", "attributes": [
                {"target_table": store.original["context"]["target_table"], "target_attribute": target}
                for target in TARGETS]}})
        if full_mapping:
            request = STTMBuilderEnvelopeRequest.model_validate(store.original)
        # Login may prompt separately for each session. No worker creates a login.
        caller = None
        for _ in range(WORKERS + 1):
            session = Session.builder.config("connection_name", connection).create()
            sessions.append(session)
            caller = validate_identity(session, caller)
        if len({id(session) for session in sessions}) != WORKERS + 1:
            raise ProbeSafetyError()
        request_session = sessions[0]
        # Reuse the existing extraction helper against this exact request session;
        # do not call SnowflakeClient's credential-discovering constructor.
        rest = SnowflakeClient.get_rest_session_context(SimpleNamespace(_session=request_session))
        if rest.host.lower() != EXPECTED_HOST:
            raise ProbeSafetyError()
        prepared, scan_budget = plan_fixture(store, caller.native_user)
        seconds = FULL_SECONDS if full_mapping else SECONDS
        agent_type = guarded_agent_type() if full_mapping else SnowflakeAgentClient
        agent = agent_type(rest.token, host=rest.host, auth_mode="snowflake_token",
                          role=caller.role, request_timeout=seconds)
        if full_mapping:
            agent._retry_attempts = 1
            agent.metadata_session = request_session
            agent.verify_startup()
        started = time.monotonic()
        deadline = started + seconds
        pool = SessionPool(sessions[1:], deadline, cancellation)
        # These three dependencies are unused by parallel preparation; None makes
        # accidental Analyst/semantic discovery fail rather than query real data.
        service_type = synthetic_service_type() if full_mapping else STTMBuilderService
        service = service_type(agent, analyst_client=None, settings=settings,
            session=request_session, semantic_model_service=None, semantic_context_service=None,
            access_scope=caller.access_scope, parallel_caller=caller, parallel_session_factory=pool.lease)
        decision = GovernanceDecision(trace_id=run_id, request_id=run_id, operation=request.operation.value)
        if full_mapping:
            service.synthetic_cancellation = cancellation
            report, accepted = run_full_mapping(service, request, decision)
            print(json.dumps(report, sort_keys=True), flush=True)
            return 0 if accepted else 1
        bundle = service._build_auto_map_parallel_runtime(req=request, decision=decision,
                                                         store=store, deadline=deadline)
        limits = replace(bundle.limits, scan_budget=scan_budget,
                         role_minima=((CandidateRole.SOURCE, 1),))
        if limits.max_workers > WORKERS or limits.max_calls > MAX_CALLS:
            raise ProbeSafetyError()
        result = prepare_parallel(store, scope=bundle.scope, backend=bundle.backend,
            admission=bundle.admission, archive=bundle.archive, limits=limits,
            deadline=deadline, cancellation=cancellation)
        report = summarize(result, prepared, run_id, time.monotonic() - started)
        print(json.dumps(report, sort_keys=True), flush=True)
        coverage = result.coverage
        return 0 if (coverage.succeeded_shards == WORKERS and coverage.excluded_group_count == 1
                     and not coverage.mapping_blocked and report["targets_with_source_hits"] == len(TARGETS)
                     and result.selected_source_identities) else 1
    finally:
        cancellation.set()
        if pool is not None:
            pool.drain()
        cleanup_failed = False
        for session in reversed(sessions):
            try:
                session.close()
            except Exception as exc:
                cleanup_failed = True
                print(json.dumps({"status": "session_close_failed",
                                  "error_type": "ProbeFailure" if full_mapping else type(exc).__name__}), flush=True)
        if full_mapping and cleanup_failed:
            raise ProbeSafetyError() from None


def diagnose_http(connection):
    """Read-only authenticated metadata probe with no response/body logging."""
    import httpx
    from snowflake.snowpark import Session
    from app.core.automap_scan_transport import AUTOMAP_USER_AGENT
    from app.core.snowflake import SnowflakeClient
    from app.core.snowflake_agent import SnowflakeAgentClient

    session = Session.builder.config("connection_name", connection).create()
    try:
        caller = validate_identity(session)
        rest = SnowflakeClient.get_rest_session_context(SimpleNamespace(_session=session))
        if rest.host.lower() != EXPECTED_HOST:
            raise ProbeSafetyError()
        agent = SnowflakeAgentClient(rest.token, host=rest.host, auth_mode="snowflake_token", role=caller.role)
        url = agent._base_url + '/api/v2/databases/FFP_HDP_DLAB_DB_DEV/schemas/SCH_STTM_METADATA/agents/AGT_AUTOMAP_SCAN_DEV_TEST'
        headers = agent._build_headers()
        headers['Accept-Encoding'] = 'identity'
        headers['User-Agent'] = AUTOMAP_USER_AGENT
        with httpx.Client(timeout=30, follow_redirects=False) as client:
            with client.stream('GET', url, headers=headers) as response:
                encoding = response.headers.get('content-encoding', 'identity').lower()
                print(json.dumps({'status': 'metadata_http_probe', 'http_status': response.status_code,
                    'encoding': encoding if encoding in ('identity', 'gzip', 'br', 'deflate') else 'other'}), flush=True)
        return 0
    except httpx.HTTPError as exc:
        print(json.dumps({'status': 'metadata_http_failed', 'error_type': type(exc).__name__}), flush=True)
        return 1
    finally:
        session.close()


def diagnose_request_validation(connection):
    """One malformed POST, never an inference run or admission/reconciliation probe."""
    import httpx
    from snowflake.snowpark import Session
    from app.core.automap_scan_transport import AUTOMAP_USER_AGENT, _load_json, _provider_request_id
    from app.core.snowflake import SnowflakeClient
    from app.core.snowflake_agent import SnowflakeAgentClient

    session = None
    report = {"status": "request_validation_failed"}
    exit_code = 1
    try:
        session = Session.builder.config("connection_name", connection).create()
        caller = validate_identity(session)
        rest = SnowflakeClient.get_rest_session_context(SimpleNamespace(_session=session))
        if rest.host.lower() != EXPECTED_HOST:
            raise ProbeSafetyError()
        agent = SnowflakeAgentClient(rest.token, host=rest.host,
                                    auth_mode="snowflake_token", role=caller.role)
        url = "https://" + EXPECTED_HOST + agent._build_endpoint(TEST_AGENT)
        headers = agent._build_headers()
        headers["Accept-Encoding"] = "identity"
        headers["User-Agent"] = AUTOMAP_USER_AGENT
        # CommonAgentRequest requires messages (minItems: 1). Do not add even
        # stream/background flags: the entire wire body must remain exactly {}.
        # Never use agent.run(), which can retry, normalize, or process inference.
        timeouts = httpx.Timeout(30).as_dict()
        outgoing = httpx.Request("POST", url, headers=headers, content=b"{}",
                                 extensions={"timeout": timeouts})
        deadline = time.monotonic() + 30
        with httpx.Client(timeout=30, follow_redirects=False) as client:
            # A fresh default HTTPX transport has zero retries. Explicit auth=None
            # excludes challenge/netrc auth flows; Request avoids merged defaults.
            response = client.send(outgoing, stream=True, auth=None, follow_redirects=False)
            try:
                encoding = response.headers.get("content-encoding", "identity").strip().lower()
                media = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                expected = 400 <= response.status_code < 500
                report = {"status": "expected_4xx" if expected else "unexpected_http_status",
                          "http_status": response.status_code,
                          "encoding": encoding if encoding in (
                              "identity", "gzip", "br", "deflate") else "other",
                          "content_type": media if media in (
                              "application/json", "application/problem+json", "text/event-stream",
                              "text/html", "text/plain") else "other",
                          "body_status": "not_read"}
                if 200 <= response.status_code < 300:
                    report["status"] = "unexpected_2xx"
                    # Close immediately: no SSE, result parsing, follow-up or retry.
                elif encoding != "identity":
                    report["body_status"] = "unsupported_encoding"
                else:
                    cap = 32 * 1024
                    length = response.headers.get("content-length")
                    if length is not None and not re.fullmatch(r"[0-9]{1,20}", length):
                        report["body_status"] = "invalid_content_length"
                    elif length is not None and int(length) > cap:
                        report["body_status"] = "raw_limit_exceeded"
                    else:
                        raw = bytearray()
                        chunks = response.iter_raw()
                        report["body_status"] = "complete"
                        while True:
                            remaining = deadline - time.monotonic()
                            if remaining <= 0:
                                report["body_status"] = "deadline_exceeded"
                                break
                            timeouts["read"] = remaining
                            try:
                                chunk = next(chunks)
                            except StopIteration:
                                break
                            if time.monotonic() >= deadline:
                                report["body_status"] = "deadline_exceeded"
                                break
                            if len(chunk) > cap - len(raw):
                                report["body_status"] = "raw_limit_exceeded"
                                break
                            raw.extend(chunk)
                        if report["body_status"] == "complete":
                            if length is not None and len(raw) != int(length):
                                report["body_status"] = "incomplete_body"
                            elif media not in ("application/json", "application/problem+json"):
                                report["body_status"] = "not_json"
                            else:
                                try:
                                    data = _load_json(raw.decode("utf-8"))
                                except (ValueError, UnicodeError, RecursionError):
                                    report["body_status"] = "invalid_json"
                                else:
                                    if type(data) is not dict:
                                        report["body_status"] = "not_json_object"
                                    else:
                                        report["body_status"] = "json_object"
                                        request_id = _provider_request_id(data.get("request_id"))
                                        if request_id is not None:
                                            report["request_id"] = request_id
                                        for key in ("code", "error_code"):
                                            value = data.get(key)
                                            if type(value) is str and re.fullmatch(r"[0-9]{6}", value):
                                                report[key] = value
                                        # Classify known validation/auth concepts locally; never emit server text.
                                        message = data.get("message", "")
                                        if type(message) is str:
                                            # This probe sends only {}; redact its sole credential before
                                            # exposing a bounded provider validation explanation.
                                            sanitized = message.replace(rest.token, "[REDACTED]")
                                            sanitized = re.sub(r'(?i)(bearer\s+|token\s*[=:]\s*)[^\s,;]+', r'\1[REDACTED]', sanitized)
                                            report["validation_message"] = sanitized[:1024]
                                            normalized = message[:8192].lower()
                                            report["error_concepts"] = [term for term in (
                                                "messages", "thread", "request body", "required", "missing",
                                                "invalid", "token", "authentication", "authorization",
                                                "session", "expired", "permission", "role", "json",
                                                "not supported", "empty", "user message"
                                            ) if term in normalized]
                                        exit_code = 0 if expected else 1
            finally:
                response.close()
    except httpx.HTTPError as exc:
        # Exact built-in classes only: neither exception text nor user-defined
        # subclass names (which could contain arbitrary text) may escape.
        allowed = (httpx.ConnectTimeout, httpx.ReadTimeout, httpx.WriteTimeout,
                   httpx.PoolTimeout, httpx.ConnectError, httpx.ReadError,
                   httpx.WriteError, httpx.CloseError, httpx.ProxyError,
                   httpx.LocalProtocolError, httpx.RemoteProtocolError,
                   httpx.UnsupportedProtocol, httpx.DecodingError,
                   httpx.TooManyRedirects, httpx.HTTPStatusError)
        report["error_type"] = type(exc).__name__ if type(exc) in allowed else "HTTPError"
        report["status"] = "request_validation_failed"
        exit_code = 1
    except (Exception, KeyboardInterrupt):
        report["status"] = "request_validation_failed"
        exit_code = 1
    finally:
        if session is not None:
            try:
                session.close()
            except (Exception, KeyboardInterrupt):
                report["cleanup_status"] = "session_close_failed"
                exit_code = 1
    print(json.dumps(report, sort_keys=True), flush=True)
    return exit_code


def main(argv=None):
    args = parser().parse_args(argv)
    if not args.execute:
        print(json.dumps({"status": "not_executed", "reason": "explicit_execute_flag_required"}))
        return 2
    run_id = "parallel-dev-" + uuid4().hex
    # Prevent dependency logs/warnings from echoing credentials or response bodies.
    logging.disable(logging.CRITICAL)
    warnings.filterwarnings("ignore")
    try:
        if not args.connection.strip():
            raise ProbeSafetyError()
        configure_tls(args.ca_bundle)
        if args.diagnose_request_validation:
            return diagnose_request_validation(args.connection)
        if args.diagnose_http:
            return diagnose_http(args.connection)
        if args.full_mapping:
            # The regular client has a process-environment local audit opt-in.
            # Never capture prompts or response bodies in this harness.
            os.environ.pop("WORKBENCH_LOCAL_MODEL_AUDIT_DIR", None)
        print(json.dumps({"status": "starting", "run_id": run_id, "workers": WORKERS,
            "max_calls": MAX_CALLS, "preparation_seconds": FULL_SECONDS if args.full_mapping else SECONDS,
            "authentication": "three_sequential_named_sessions_may_prompt"}), flush=True)
        return execute(args.connection, run_id, full_mapping=True) if args.full_mapping else execute(args.connection, run_id)
    except (Exception, KeyboardInterrupt) as exc:
        if args.diagnose_request_validation:
            print(json.dumps({"status": "request_validation_failed"}), flush=True)
            return 1
        print(json.dumps({"status": "failed", "run_id": run_id,
                          "error_type": "ProbeFailure" if args.full_mapping else type(exc).__name__}), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
