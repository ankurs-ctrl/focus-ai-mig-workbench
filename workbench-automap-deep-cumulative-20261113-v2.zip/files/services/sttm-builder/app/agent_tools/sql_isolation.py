"""Attribute a mapping SQL compile failure to the column expressions that caused it.

One invalid column expression (an invented function, a stale identifier) makes
Snowflake reject the whole generated query. These helpers find the offending
columns so they can go to review with Snowflake's own reason. The remaining
columns still compile and preview.

Attribution uses only the compiler error text and the expressions themselves.
It first matches names quoted in the error, then bisects when the error names
nothing usable. Every step is bounded by an attempt budget.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Hashable, TypeVar

T = TypeVar("T")
K = TypeVar("K", bound=Hashable)

_QUERY_ID = re.compile(r"^\s*[0-9a-f]{8}-[0-9a-f-]{20,}:\s*", re.I)
_ERROR_CODE = re.compile(r"^\s*\(\d+\):\s*|\s*\d{6}\s*\(\w+\):\s*", re.I)
_UNKNOWN_FUNCTIONS = re.compile(r"unknown\s+(?:user-defined\s+)?functions?\s+([^\n]+)", re.I)
_INVALID_IDENTIFIER = re.compile(r"invalid identifier\s+'([^']+)'", re.I)
_QUOTED_LITERAL = re.compile(r"'(?:[^'\\]|\\.)*'")


def compile_error_summary(exc: BaseException | str, *, limit: int = 300) -> str:
    """Snowflake's compile message without query ids, error codes or data literals."""
    text = str(exc)
    marker = text.lower().find("sql compilation error")
    if marker >= 0:
        text = text[marker:]
    lines = []
    for line in text.splitlines():
        line = _QUERY_ID.sub("", line)
        line = _ERROR_CODE.sub(" ", line).strip()
        if line:
            lines.append(line)
    summary = " ".join(lines)
    # Identifiers stay (they are catalog metadata the caller can already see);
    # quoted values other than the identifier in "invalid identifier" are masked.
    identifiers = {match.group(0) for match in _INVALID_IDENTIFIER.finditer(summary)}
    summary = _QUOTED_LITERAL.sub(
        lambda match: match.group(0) if any(match.group(0) in item for item in identifiers) else "'?'",
        summary,
    )
    return summary[:limit].rstrip()


def error_names(message: str) -> tuple[set[str], set[str]]:
    """Function names and identifier names quoted by a compile error."""
    functions: set[str] = set()
    for match in _UNKNOWN_FUNCTIONS.finditer(message):
        for name in re.split(r"[,\s]+", match.group(1).rstrip(". ")):
            name = name.strip().strip('"').rstrip(".")
            if name:
                functions.add(name.split(".")[-1].upper())
    identifiers = {
        match.group(1).strip('"').split(".")[-1].strip('"').upper()
        for match in _INVALID_IDENTIFIER.finditer(message)
    }
    return functions, {value for value in identifiers if value}


def suspects(message: str, expressions: dict[K, str]) -> list[K]:
    """Keys whose expression uses a function or identifier named by the error."""
    functions, identifiers = error_names(message)
    found: list[K] = []
    for key, expression in expressions.items():
        text = expression or ""
        if any(re.search(rf"(?<![\w$.]){re.escape(name)}\s*\(", text, re.I) for name in functions):
            found.append(key)
            continue
        if any(re.search(rf"(?<![\w$]){re.escape(name)}(?![\w$])", text, re.I) for name in identifiers):
            found.append(key)
    return found


@dataclass
class IsolationResult(Generic[T, K]):
    passing: list[T]
    failing: dict[K, str] = field(default_factory=dict)
    compiled: Any = None
    error: BaseException | None = None
    structural: bool = False
    exhausted: bool = False
    attempts: int = 0


def isolate(
    items: list[T],
    attempt: Callable[[list[T]], tuple[Any, BaseException | None]],
    *,
    key: Callable[[T], K],
    expression: Callable[[T], str],
    max_attempts: int,
    first_error: BaseException,
) -> IsolationResult[T, K]:
    """Remove the items whose expressions make ``attempt`` fail.

    ``attempt(subset)`` compiles a subset and returns ``(compiled, None)`` or
    ``(None, error)``. ``first_error`` is the failure of the full set, which
    has already been attempted by the caller.
    """
    result: IsolationResult[T, K] = IsolationResult(passing=list(items), error=first_error)

    def run(subset: list[T]) -> tuple[Any, BaseException | None]:
        result.attempts += 1
        return attempt(subset)

    def fail(item: T, error: BaseException) -> None:
        result.failing[key(item)] = compile_error_summary(error)

    # 1. Columns named by the error text. Repeat while each round removes
    #    something and the remaining set still fails with a new message.
    error = first_error
    while error is not None and result.attempts < max_attempts:
        named = set(suspects(str(error), {key(item): expression(item) for item in result.passing}))
        remaining = [item for item in result.passing if key(item) not in named]
        if not named or not remaining:
            break
        for item in result.passing:
            if key(item) in named:
                fail(item, error)
        result.passing = remaining
        compiled, error = run(remaining)
        if error is None:
            result.compiled, result.error = compiled, None
            return result
        result.error = error
    if error is None or result.attempts >= max_attempts:
        result.exhausted = error is not None
        return result

    # 2. A column that is only a plain source reference cannot be the culprit.
    #    If it fails alone, the problem is in the FROM/JOIN plan, not a column.
    plain = next((item for item in result.passing if not (expression(item) or "").strip()), None)
    if plain is not None:
        _, probe_error = run([plain])
        if probe_error is not None:
            result.structural, result.error = True, probe_error
            return result

    # 3. Bisection over the remaining columns.
    failing: list[tuple[T, BaseException]] = []

    def bisect(group: list[T], group_error: BaseException) -> None:
        if len(group) == 1:
            failing.append((group[0], group_error))
            return
        middle = len(group) // 2
        for half in (group[:middle], group[middle:]):
            if result.attempts >= max_attempts:
                result.exhausted = True
                return
            _, half_error = run(half)
            if half_error is not None:
                bisect(half, half_error)

    bisect(result.passing, error)
    if result.exhausted:
        return result
    if failing and len(failing) == len(result.passing):
        result.structural = True
        return result
    failed_keys = {key(item) for item, _ in failing}
    for item, item_error in failing:
        fail(item, item_error)
    result.passing = [item for item in result.passing if key(item) not in failed_keys]
    if not result.passing or result.attempts >= max_attempts:
        result.exhausted = bool(result.passing)
        return result
    compiled, final_error = run(result.passing)
    result.compiled, result.error = compiled, final_error
    return result
