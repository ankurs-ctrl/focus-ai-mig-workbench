"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AiaBox, AiaCircularProgress } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import { AppError } from "@/api/errors/app-error";
import { authService, clearBrowserWorkbenchSession } from "@/services/authService";

type SessionStatus = "checking" | "ready" | "signed-out";

// Session answers that mean "not signed in to the workbench yet".
const NOT_SIGNED_IN_STATUSES = new Set([401, 403, 404]);

function isNotSignedIn(error: unknown) {
  return error instanceof AppError && NOT_SIGNED_IN_STATUSES.has(error.payload.statusCode ?? 0);
}

/**
 * Blocks signed-in screens until `/api/v1/auth/session` answers.
 * - While it loads: a spinner (screens would otherwise render with empty data).
 * - 401 / 403 / 404: the user has not signed in to the workbench yet (the in-app "Sign in with
 *   Snowflake" on /home, separate from the platform sign-in), so send them to /home.
 * - Any other failure: the app continues and shows its usual error handling.
 */
export default function SessionGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>("checking");

  useEffect(() => {
    let cancelled = false;
    authService
      .getSession()
      .then(() => {
        if (!cancelled) setStatus("ready");
      })
      .catch((error) => {
        if (cancelled) return;
        if (isNotSignedIn(error)) {
          setStatus("signed-out");
          clearBrowserWorkbenchSession();
          window.location.replace("/home");
          return;
        }
        setStatus("ready");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (status === "ready") {
    return <>{children}</>;
  }

  // Checking, or on the way to /home: keep the screen behind a spinner.
  return (
    <AiaBox
      role="status"
      aria-live="polite"
      sx={{
        flex: 1,
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 1.5,
        backgroundColor: "var(--color-app-bg)",
      }}
    >
      <AiaCircularProgress size={32} />
      <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>
        {status === "signed-out" ? "Redirecting to sign in…" : "Checking your session…"}
      </AiaText>
    </AiaBox>
  );
}
