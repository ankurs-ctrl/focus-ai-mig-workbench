"""Native page prepare/job/worker acceptance; never seed execution context.

Invoked by validate_automap_durable_live --prepared-job-path, using that runner's
isolated native admission/agents. Existing business tables remain read-only.
"""
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime, UTC
import json
import time
from uuid import uuid4


def run(*, settings, session, independent, payload, agent, caller, report, namespace):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from app import api
    from app.api import deps
    from app.auth.models import CurrentPrincipal, PermissionSet
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.prepared_context import PreparedWorkspaceContextService, invalidate_prepared_workspace_context_cache
    from app.core.semantic_context import SemanticContextService
    from app.core.semantic_model import SemanticModelService
    from app.core.learning_retrieval import LearningRetrievalService
    from app.core.table_selection import TableSelectionService
    from app.core.derived_source import DerivedSourceService
    from app.core.sttm_builder import STTMBuilderService
    from app.routers import sttm_builder
    from app.auto_mapping_worker.main import app as worker_app
    from types import SimpleNamespace
    # Install empty operational tables using existing DDL shapes, never copy data.
    existing=session.sql('SHOW TABLES IN SCHEMA FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA').collect()
    statements=[]
    for row in existing:
        name=row['name']
        if name.startswith('TBL_'):
            statements.append(f'CREATE TABLE IF NOT EXISTS {namespace}.{name} LIKE FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA.{name};')
    session.sql('BEGIN '+' '.join(statements)+' END').collect()
    settings=settings.model_copy(update={'auto_map_pipeline_v2':True, 'auto_mapping_service_url':'inprocess',
        'auth_mode':'ingress_headers','prepared_context_cache_v2':True,
        'auto_mapping_proxy_batch_size':8})
    principal=CurrentPrincipal(user_id=1,snowflake_user=caller.native_user,email='isolated-acceptance@example.test',
        display_name='Isolated acceptance',app_persona='ADMIN',permissions=PermissionSet(can_edit=True,can_publish=True),
        snowflake_user_token='',snowflake_role=caller.role)
    scope='|'.join([str(principal.user_id),principal.app_persona.value,caller.role])
    def semantic(s):
        return SemanticContextService(session=s,settings=settings,semantic_model_service=SemanticModelService(settings),
            table_selection_service=TableSelectionService(SimpleNamespace(session=s),settings,scope),
            derived_source_service=DerivedSourceService(s,settings),access_scope=scope)
    def prepared_dependency():
        with independent() as s:
            yield PreparedWorkspaceContextService(session=s,settings=settings,semantic_service=semantic(s),
                learning_service=LearningRetrievalService(s,settings,scope),access_scope=scope)
    def client_dependency():
        with independent() as s:yield SimpleNamespace(session=s)
    worker_records=[]
    def worker_dependency():
        with independent() as s:
            svc=STTMBuilderService(agent,analyst_client=None,settings=settings,session=s,
                semantic_model_service=SemanticModelService(settings),semantic_context_service=semantic(s),
                access_scope=scope,parallel_caller=caller,parallel_session_factory=independent)
            original=svc.invoke_auto_map_parallel
            async def observe(req, **kwargs):
                assert req.context.execution_context is not None
                row={'batch':req.meta.get('auto_mapping_batch_index'),'received_at':datetime.now(UTC).isoformat(),
                    'targets':[a.target_attribute for a in req.data.attributes],
                    'snapshot_present':bool(req.context.execution_context.snapshot_id),
                    'preparation_hash':req.context.prepared_context_hash}
                worker_records.append(row)
                result=await original(req,**kwargs)
                row['finished_at']=datetime.now(UTC).isoformat()
                row['retrieval']=result.meta.get('auto_map_retrieval',{})
                row['transformation']=result.meta.get('transformation_stage',{})
                return result
            svc.invoke_auto_map_parallel=observe
            yield svc
    app=FastAPI()
    @app.middleware('http')
    async def authenticated(request,call_next):
        request.state.current_principal=principal
        request.state.workbench_timings_ms={}
        return await call_next(request)
    app.include_router(api.router)
    proxy=AutoMappingProxyClient(settings)
    app.dependency_overrides[deps.get_auto_mapping_proxy_client]=lambda:proxy
    app.dependency_overrides[deps.get_prepared_workspace_context_service]=prepared_dependency
    app.dependency_overrides[deps.get_snowflake_client]=client_dependency
    app.dependency_overrides[deps.get_settings]=lambda:settings
    worker_app.dependency_overrides[deps.get_sttm_builder_service]=worker_dependency
    previous=sttm_builder.get_settings
    sttm_builder.get_settings=lambda:settings
    body=json.loads(json.dumps(payload, default=str))
    body['context']['execution_context']=None
    for key in ['prepared_context_hash','workspace_context_id','workspace_context_hash']:
        body['context'].pop(key,None)
    workspace=body['context']['workspace_context']
    workspace.update(project_id=body['context']['project_id'],sttm_id=body['context'].get('sttm_id'),
        source_tables=body['context']['source_tables'], target_table=body['context']['target_table'],
        relation_graph=body['context'].get('relation_graph'))
    workspace['mapping_rows']=[{'id':a['target_attribute'],'target_column':a['target_attribute'],
        'target_type':a.get('target_data_type')} for a in body['data']['attributes']]
    body['meta']['auto_map_resolution_mode']='reeval_all'
    body['meta'].update(automap_generation_policy='draft-v3',automap_rules_policy='rules-v2')
    report['acceptance_path']='HTTP prepare -> HTTP durable job -> actual private worker endpoint -> native source/rule agents'
    report['execution_context_seeded']=False
    report['worker_control_session_strategy']='independent_native_caller_factory'
    report['operational_fixture_tables']=len(statements)
    report['runs']=[]
    try:
        with TestClient(app) as client,ThreadPoolExecutor(max_workers=2) as pool:
            invalidate_prepared_workspace_context_cache()
            # Two simultaneous page/click prepares must coalesce and share one handle.
            start=time.monotonic()
            future=pool.submit(client.post,'/api/v1/workbench/context/prepare',json={'workspace':workspace})
            second=pool.submit(client.post,'/api/v1/workbench/context/prepare',json={'workspace':workspace})
            results=[f.result() for f in (future,second)]
            for result in results:result.raise_for_status()
            prepared=[r.json()['data'] for r in results]
            assert prepared[0]['workspace_context_id']==prepared[1]['workspace_context_id']
            report['concurrent_page_prepare']={'elapsed_seconds':round(time.monotonic()-start,2),
                'cache_statuses':[r['cache_status'] for r in prepared],
                'semantic_registry_version':prepared[0].get('semantic_registry_version'),
                'durable':all(r.get('cache_persisted') for r in prepared),
                'readiness':prepared[0].get('automap_readiness')}
            for index in range(2):
                if index:
                    # Emulate another replica: clear memory; hydrate the durable handle.
                    invalidate_prepared_workspace_context_cache()
                    check=client.post('/api/v1/workbench/context/prepare',json={'workspace':workspace})
                    check.raise_for_status();prepared[index]=check.json()['data']
                active=deepcopy(body);active['request_id']=str(uuid4())
                active['context'].update(workspace_context_id=prepared[index]['workspace_context_id'],
                    workspace_context_hash=prepared[index]['workspace_context_hash'])
                assert active['context']['execution_context'] is None
                started=time.monotonic();post=client.post('/api/v1/workbench/auto-map-jobs',json=active)
                post.raise_for_status();job=post.json()['data'];job_id=job['job_id']
                history=[]
                print(json.dumps({'stage':'native_job_accepted','run':index,'job_id':job_id}),flush=True)
                while job['status'] in {'queued','running'} and time.monotonic()-started<650:
                    time.sleep(2)
                    poll=client.get('/api/v1/workbench/auto-map-jobs/'+job_id);poll.raise_for_status()
                    job=poll.json()['data']
                    stage=job.get('stage')
                    if not history or history[-1]['stage']!=stage:
                        history.append({'stage':stage,'seconds':round(time.monotonic()-started,2)})
                        print(json.dumps({'stage':stage,'run':index,'seconds':history[-1]['seconds']}),flush=True)
                result=job.get('response') or {}
                mappings=((result.get('data') or {}).get('result') or result.get('result') or {}).get('mappings') or {}
                record={'job_id':job_id,'status':job['status'],'elapsed_seconds':round(time.monotonic()-started,2),
                    'page_cache_status':prepared[index]['cache_status'],'stages':history,
                    'preparation_ms':job.get('preparation_ms'),'error':job.get('error'),
                    'mapping_count':len(mappings),'confidence_scores':{k:v.get('confidence_score') for k,v in mappings.items()},
                    'rules':{k:{'stage':v.get('rule_stage'),'sql':v.get('preprocessing_rule')} for k,v in mappings.items()},
                    'returned_mapping_definitions':mappings,'dispatch':result.get('meta',{}).get('auto_mapping_dispatch')}
                report['runs'].append(record)
                assert job['status']=='completed',job.get('error')
                assert len(mappings)==len(active['data']['attributes'])
                assert all(isinstance(v.get('confidence_score'),(int,float)) for v in mappings.values())
                assert any(v.get('confidence_score',0)>0 for v in mappings.values())
                # Verify the durable parent proof, not a synthetic request assembled by this harness.
                saved=session.sql(f'SELECT JOB_STATE FROM {namespace}.TBL_AUTO_MAP_JOBS WHERE JOB_ID = ?',
                    params=[job_id]).collect()[0]['JOB_STATE']
                persisted=AutoMappingProxyClient._load_job_state(saved)
                from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
                from app.core.automap_policy import preparation_hash
                frozen=STTMBuilderEnvelopeRequest.model_validate(persisted['request_envelope'])
                assert frozen.context.execution_context is not None
                assert frozen.context.execution_context.snapshot_id
                assert frozen.context.prepared_context_hash==preparation_hash(frozen.context)
                assert frozen.meta['context_diagnostics']['cache_source']=='prepared_workspace'
                record['handoff_verified']={'execution_context':True,'snapshot':True,'preparation_hash':True,
                    'cache_source':frozen.meta['context_diagnostics']['cache_source']}
                assert not (record['dispatch'] or {}).get('failed_batches')
            report['worker_endpoint_calls']=worker_records
            report['status']='passed'
            return 0
    finally:
        report['worker_endpoint_calls']=worker_records
        worker_app.dependency_overrides.clear()
        sttm_builder.get_settings=previous
