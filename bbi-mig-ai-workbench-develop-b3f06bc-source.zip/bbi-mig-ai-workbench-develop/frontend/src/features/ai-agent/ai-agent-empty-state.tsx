"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AiaBox, AiaStack } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { CLIENT_CONFIG } from "@/config/client.config";
import { AI_AGENT_PAGE_CONTENT_MAX_WIDTH } from "@/features/ai-agent/ai-chat-layout-constants";
import { authService } from "@/services/authService";

const DEFAULT_PROMPTS = [
  "Create a new STTM mapping",
  "Upload SQL and map sources",
  "Help me manage a project",
  "Explain this workbench",
] as const;

type AiAgentEmptyStateProps = {
  userName?: string | null;
  children?: ReactNode;
  onSelectPrompt?: (prompt: string) => void;
};

function resolveGreetingName(raw: string | null | undefined) {
  const value = (raw || "").trim();
  if (!value) return "";
  const withoutDomain = value.includes("@") ? value.split("@")[0] : value;
  const firstToken = withoutDomain.split(/[\s._-]+/).find(Boolean) || withoutDomain;
  if (!firstToken) return "";
  return `${firstToken.charAt(0).toUpperCase()}${firstToken.slice(1).toLowerCase()}`;
}

export function AiAgentEmptyState({
  userName,
  children,
  onSelectPrompt,
}: AiAgentEmptyStateProps) {
  const workbenchName = CLIENT_CONFIG.app.title || "AIA Migration Workbench";
  const [resolvedName, setResolvedName] = useState(() => resolveGreetingName(userName));

  useEffect(() => {
    const fromProp = resolveGreetingName(userName);
    if (fromProp) {
      setResolvedName(fromProp);
      return;
    }

    let cancelled = false;
    authService
      .getSession()
      .then((session) => {
        if (cancelled) return;
        const next =
          resolveGreetingName(session.display_name) ||
          resolveGreetingName(session.email);
        if (next) setResolvedName(next);
      })
      .catch(() => {
        // Keep whatever we already have.
      });

    return () => {
      cancelled = true;
    };
  }, [userName]);

  const greetingLead = resolvedName ? `Hi ${resolvedName},` : "Hi there,";

  return (
    <AiaBox
      sx={{
        flex: 1,
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        px: 3,
        py: 4,
        overflowY: "auto",
      }}
    >
      <AiaBox sx={{ width: "100%", maxWidth: AI_AGENT_PAGE_CONTENT_MAX_WIDTH, textAlign: "center" }}>
        <AiaBox
          sx={{
            textAlign: "center",
            width: "fit-content",
            maxWidth: "100%",
            mx: "auto",
          }}
        >
          <AiaText
            sx={{
              fontSize: 40,
              fontWeight: 400,
              color: "#0F172A",
              letterSpacing: "-0.02em",
              lineHeight: 1.2,
            }}
          >
            {greetingLead}
          </AiaText>
          <AiaText
            sx={{
              fontSize: 40,
              fontWeight: 400,
              color: "#475569",
              letterSpacing: "-0.02em",
              lineHeight: 1.2,
            }}
          >
            how can I help you?
          </AiaText>
        </AiaBox>

        <AiaText
          sx={{
            mt: 1.5,
            mx: "auto",
            maxWidth: 640,
            fontSize: 14,
            lineHeight: 1.55,
            color: "#64748B",
          }}
        >
          I&apos;m your {workbenchName} AI Agent. Ask me about creating STTMs, uploading SQL,
          managing projects, or anything else in the workbench.
        </AiaText>

        {children ? (
          <AiaBox sx={{ mt: 3.5, width: "100%", textAlign: "left" }}>
            {children}
          </AiaBox>
        ) : null}

        {onSelectPrompt ? (
          <AiaStack
            direction="row"
            useFlexGap
            sx={{
              mt: 2,
              width: "100%",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: 1,
            }}
          >
            {DEFAULT_PROMPTS.map((prompt) => (
              <AiaBox
                key={prompt}
                component="button"
                type="button"
                onClick={() => onSelectPrompt(prompt)}
                sx={{
                  border: "1px solid #0082b5",
                  borderRadius: "9999px",
                  backgroundColor: "transparent",
                  color: "#0082b5",
                  cursor: "pointer",
                  px: 1.75,
                  py: 0.75,
                  fontSize: 13,
                  fontWeight: 500,
                  lineHeight: 1.3,
                  transition: "background-color 120ms ease, color 120ms ease",
                  "&:hover": {
                    backgroundColor: "rgba(0, 130, 181, 0.08)",
                  },
                }}
              >
                {prompt}
              </AiaBox>
            ))}
          </AiaStack>
        ) : null}
      </AiaBox>
    </AiaBox>
  );
}
