import type { MappingSqlReviewRequest } from '@/types/api-contract';

/** Optional Analyst context must never prevent Snowflake validation. */
export async function resolveReviewSemanticContext(
  payload: MappingSqlReviewRequest,
  optimize: boolean,
  resolve: () => Promise<Partial<MappingSqlReviewRequest>>,
): Promise<{ payload: MappingSqlReviewRequest; warning?: string }> {
  if (!optimize || payload.semantic_view_name || payload.semantic_model_yaml) return { payload };
  try {
    return { payload: { ...payload, ...await resolve() } };
  } catch {
    return { payload, warning: 'Semantic context is unavailable. Snowflake validation will run without Analyst optimization.' };
  }
}