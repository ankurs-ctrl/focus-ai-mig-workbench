# Combined release verification — 13 November 2026

## Auto-map correctness

The latest completed mixed acceptance returned **40/40 valid definitions**, confidence **0.79–0.95**, with expected Snowflake output values matching for all three synthetic rows. It exercised twelve sources, five parallel source batches of eight targets, five actual source model POSTs and two actual transformation POSTs. There were zero failed batches and zero occupied execution slots afterward. FIR was cited/reused; direct columns, direct Firm Value assignment, intentional SQL NULL, column-plus-Value custom SQL and Value-only CASE rules were all present.

Elapsed mapping runtime was **184.40 seconds**, excluding 50.25 seconds creating the isolated fixture and test agents. An earlier normal-policy run passed at 179.82 seconds. The 120–140-second performance target and a new SPCS deployment are not claimed as passed. Context sizes fit both the existing 180,000-character and UTF-8-byte limits. No extra evidence-review model call was submitted.

The 184.40-second run used an additional strict wiring assertion requiring both agents to retrieve native evidence even when initial evidence was complete. Transformation retrieval returned one complete FIR record (2,412 bytes). Source retrieval was skipped. Consequently the **overall strict-tool test is recorded as failed**, while the independent mapping/SQL/confidence checks all passed. This distinction is preserved in `NATIVE-MAPPING-RESULTS.json`; the failed assertion is not relabeled as a fully passing acceptance.

A further normal-policy run and a small source-tool test were blocked by Snowflake `CREDIT_LIMIT` (native code 90073) before completion. Source-agent native retrieval with a deliberate evidence gap therefore remains unverified in this release. Complete initial packets work without it. The normal-policy run did not produce a new accepted result or a retained live review fixture. No client mappings were modified.

Representative returned definitions:

| Target | Definition | Estimated mapping confidence | Route |
| --- | --- | --- | --- |
| ID | `src."ID"` | 0.95 | direct |
| DISPLAY_NAME | `$FirmPrefix || COALESCE(TRIM(src.NAME), 'Unknown')` | 0.90 | rule complete |
| FIRM_VALUE | approved `$FirmPrefix` | 0.95 | Value |
| VALUE_CASE | `CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other firm' END` | 0.90 | rule complete |
| OWNERNAME | intentional SQL `NULL` | 0.79 | Value |

Confidence is an estimate for human review. The response retains original source-model and specialist scores separately, plus backend evidence estimates/caps and provenance. It is not an execution approval or a calibrated probability.

## Automated checks

- Combined backend core/runtime/preflight/job suite: **5,416 passed, 31 skipped** on the initial combined run. Six remaining tests were blocked by sandbox UDP access or a missing test-only JSON Schema dependency. Their corrected-environment rerun, including new regressions: **79 passed**. No known failing assertion remains from that suite.
- Final prepared-context/preflight/job regression run after the authored-SQL dependency fix: **409 passed**.
- Original Auto-map full run: 4,800 passed with two obsolete four-target batch assertions; the corrected focused run: **94 passed**.
- All **35 frontend regression scripts** passed across the complete run and the corrected scope rerun (51 scope checks). These include SQL-upload recovery/preview, mapping preservation, confidence/candidates, administration-related integration contracts and Deep Agent composer/results.
- TypeScript passed; production frontend `next build --webpack` passed. Installed dependencies are outside this worktree, so webpack was used for the local build. Built assets are excluded from the overlay.
- Agent specification manifest verified. Offline checks cover exact citation normalization, complete/multibyte context budgeting and subdivision, per-target specialist isolation, confidence fallback, semantic gaps, fenced contention/recovery and native tool scope/response parsing.

## Deep Agent and packaging

All 206 files from the supplied Deep Agent ZIP are included. The seven shared files are merged with Auto-map changes; the other 199 match the supplied ZIP after newline normalization. Existing DataHub settings were restored because its unchanged adapter still reads them. Dedicated regression checks cover this shared configuration boundary.

The supplied Deep Agent verification document retains the team's earlier native acceptance evidence. This combined release reran its automated checks but did not perform a fresh native Deep Agent business workflow. Apply its dependency lock, additive migrations, model settings and worker enablement as described in `INSTALL.md` and the original deployment notes.

The cumulative overlay is relative to the supplied client ZIP, preserves every file from the prior combined Auto-map overlay, and excludes environment files, credentials, private keys, installed dependencies and runtime locks. No CodeCommit branch push or SPCS deployment was performed for this package.
