"""Bounded caller-visible metadata discovery; never enumerate the whole account."""
import re
from sqlglot import exp, parse_one
from app.agent_runs.models import ToolResult
from app.agent_runtime.execution import BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError
from app.core.exceptions import DelegatedSessionRequired, DelegatedCredentialsRotated


def identifier_parts(value):
    if value is None or not isinstance(value,(str,dict)):
        return []
    if isinstance(value, dict):
        # TableRef fields are literal catalog names, rather than a SQL string.
        # Preserve quoted case and dots inside a component; authorization still
        # resolves the resulting exact identifier against the caller catalog.
        parts = [value.get(key) for key in ('database', 'schema', 'table')]
        return parts if all(isinstance(part, str) and part for part in parts) else []
    try:
        tree=parse_one(str(value),into=exp.Table,dialect='snowflake')
        parts=tree.parts
        if tree.alias or not parts or not all(isinstance(p,exp.Identifier) for p in parts):return []
        return [p.name if p.args.get('quoted') else p.name.upper() for p in parts]
    except Exception:return []


def sql_diagnostics(error):
    result={};seen=set();codes=[]
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        native=getattr(error,'sql_error_code',None)
        wrapper=getattr(error,'errno',None)
        if native is not None:codes.insert(0,str(native))
        elif wrapper is not None:codes.append(str(wrapper))
        for field,names in {'native_code':('sql_error_code','errno'),'sql_state':('sqlstate','sql_state'),'query_id':('sfqid','query_id')}.items():
            for name in names:
                value=getattr(error,name,None)
                if value is not None and field not in result and re.fullmatch(r'[A-Za-z0-9_-]{1,128}',str(value)):
                    result[field]=str(value);break
        error=error.__cause__ or error.__context__
    if codes:result['native_code']=next((code for code in codes if code.lstrip('0')!='1304'),codes[0])
    return result


class ScopedCatalogUnavailable(RuntimeError):
    def __init__(self, diagnostics):
        super().__init__('A prior scoped metadata operation failed; narrow the scope before retrying.')
        self.sql_error_code=diagnostics.get('native_code')
        self.sqlstate=diagnostics.get('sql_state')
        self.sfqid=diagnostics.get('query_id')


def _caller_schema_scopes(workbench, context, hints, database=None):
    """Resolve caller-visible schema names without reading outside a declared scope."""
    declared=[tuple(identifier_parts(v)) for v in context.get('authorized_schemas',[])]
    if declared:
        cache=[v for v in declared if len(v)==2]
    else:
        with workbench._domain_lock:
            inventories=workbench.__dict__.setdefault('_catalog_schema_inventories',{})
            key=str(database or 'account')
            cache=inventories.get(key)
            failures=workbench.__dict__.setdefault('_catalog_schema_failures',{})
            if key in failures:raise ScopedCatalogUnavailable(failures[key])
            if cache is None:
                parts=identifier_parts(database) if database else []
                if database and len(parts)!=1: raise ValueError('Expected one database identifier')
                scope='DATABASE '+quote_identifier(parts[0]) if parts else 'ACCOUNT'
                used=getattr(workbench,'_catalog_discovery_queries',0)
                if used>=MAX_DISCOVERY_QUERIES:
                    return [], True
                take=getattr(workbench,'_take_broad_discovery',None)
                if callable(take) and not take():return [],True
                workbench._catalog_discovery_queries=used+1
                try:
                    rows=workbench._session.sql('SHOW SCHEMAS IN '+scope+' LIMIT 1000').collect()
                except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated):raise
                except Exception as error:
                    failures[key]=sql_diagnostics(error)
                    raise
                cache=[]
                for raw in rows:
                    row=raw.as_dict() if hasattr(raw,'as_dict') else dict(raw)
                    row={str(k).lower():v for k,v in row.items()}
                    db,sc=row.get('database_name'),row.get('name')
                    if db and sc and sc!='INFORMATION_SCHEMA' and db!='SNOWFLAKE':cache.append((str(db),str(sc)))
                inventories[key]=cache
    ranked=sorted({tuple(v) for v in cache},key=lambda v:(0 if v[1] in hints else 1,v))
    if database:
        parts=identifier_parts(database)
        ranked=[v for v in ranked if len(parts)==1 and v[0]==parts[0]]
    if hints:ranked=[v for v in ranked if any(v[1]==h or v[1].startswith(h+'_') for h in hints)]
    return ranked,len(cache)>=1000


MAX_DISCOVERY_SCOPES = 8
MAX_DISCOVERY_QUERIES = 24
MAX_BROAD_BATCHES = 2


def authorized_scope(value, context):
    """Application scope is checked before reads; catalog evidence grants nothing."""
    parts = tuple(identifier_parts(value))
    schemas = {tuple(identifier_parts(v)) for v in context.get('authorized_schemas', [])}
    exact = {tuple(identifier_parts(v)) for k in ('authorized_source_scope', 'authorized_target_scope')
             for v in context.get(k, [])}
    return len(parts) in (2, 3) and (not schemas or parts[:2] in schemas or parts in exact)


def quote_identifier(value):
    return '"' + value.replace('"', '""') + '"'


def discover(workbench, terms, limit, *, database=None, schema=None, context=None):
    """Set-based, bounded metadata reads. Unknown business scope stays unknown."""
    import hashlib
    import json
    context = context or {}
    limit = max(1, min(int(limit), 25))
    terms = list(dict.fromkeys(str(t).strip() for t in terms if str(t).strip()))[:12]
    scopes = set()
    def add(value):
        parts = identifier_parts(value)
        if len(parts) >= 2 and authorized_scope(value, context): scopes.add(tuple(parts[:2]))
    for value in context.get('authorized_schemas', []): add(value)
    for key in ('authorized_source_scope', 'authorized_target_scope', 'source_tables', 'target_tables', 'selected_sources', 'resolved_source_scopes'):
        for value in context.get(key, []):
            if isinstance(value, dict) and value.get('database') and value.get('schema'):
                add({'database':value['database'], 'schema':value['schema'], 'table':'_scope'})
            else: add(value)
    # A schema explicitly named by the user must not become a database just
    # because a model filled the wrong argument. Verify it against the caller's
    # inventory below; this is never permission to infer business sources.
    prompt = str(context.get('prompt') or context.get('user_request') or '')
    if database and not schema:
        supplied = identifier_parts(database)
        if len(supplied) == 1:
            name = re.escape(supplied[0])
            schema_hint = re.search(r'(?:\bschema\s+[\"`]?'+name+r'\b|\b'+name+r'[\"`]?\s+schema\b)', prompt, re.I)
            database_hint = re.search(r'\bdatabase\s+[\"`]?'+name+r'\b', prompt, re.I)
            if schema_hint and not database_hint:
                schema, database = database, None
    schema_only = bool(schema and not database)
    dbparts = identifier_parts(database) if database else []
    scparts = identifier_parts(schema) if schema else []
    if (database and len(dbparts) != 1) or (schema and len(scparts) != 1):
        return ToolResult(status='failed', summary='Provide exact database/schema identifiers.', error_code='catalog_scope_required')
    if schema and not database:
        matches = [scope for scope in scopes if scope[1] == scparts[0]]
        if not matches:
            try:
                inventory, _ = _caller_schema_scopes(workbench, context, {scparts[0]})
                matches = [scope for scope in inventory if scope[1] == scparts[0]]
            except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated): raise
            except Exception as error:
                return ToolResult(status='failed', summary='Schema discovery is incomplete; its database is not yet verified.',
                    error_code='catalog_scope_discovery_failed', data={'coverage':'incomplete','diagnostics':sql_diagnostics(error)})
        if not matches:
            return ToolResult(status='failed', summary='No caller-visible database was verified for this schema; unchecked scopes remain unknown.',
                error_code='catalog_scope_required', data={'coverage':'incomplete','schema':scparts[0]})
        # Multiple databases are searched within the existing scope/query bounds.
        # Return exact qualified candidates; do not silently select one database.
        scopes = set(matches)
    if dbparts and scparts and not schema_only: scopes = {(dbparts[0], scparts[0])}
    if not scopes and not database and not schema:
        prompt=str(context.get('prompt') or context.get('user_request') or '')
        hints=set(re.findall(r'\b([A-Za-z][A-Za-z0-9_]*)\s*\.',prompt))
        hints.update(re.findall(r'\b[A-Z][A-Z0-9_]{1,63}\b',prompt))
        if hints:
            try:
                values,_=_caller_schema_scopes(workbench,context,{value.upper() for value in hints})
                scopes.update(tuple(value) for value in values if authorized_scope('.'.join(quote_identifier(v) for v in value),context))
            except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated): raise
            except Exception as error:
                return ToolResult(status='failed',summary='Schema hints could not be resolved; scope remains unknown.',error_code='catalog_scope_discovery_failed',data={'diagnostics':sql_diagnostics(error)})
    requests = []
    for term in terms:
        parts = identifier_parts(term)
        if len(parts) == 3: requests.append((term, (parts[0], parts[1]), parts[2]))
        elif len(parts) == 2:
            candidates = [(dbparts[0], parts[0])] if dbparts else [s for s in scopes if s[1] == parts[0]]
            if not candidates:
                try: candidates, _ = _caller_schema_scopes(workbench, context, {parts[0]})
                except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated): raise
                except Exception as error:
                    return ToolResult(status='failed', summary='Schema discovery is incomplete.', error_code='catalog_scope_discovery_failed', data={'coverage':'incomplete','diagnostics':sql_diagnostics(error)})
            requests.extend((term, s, parts[1]) for s in candidates)
        else:
            candidates = sorted(scopes) or ([(dbparts[0], None)] if dbparts else [])
            requests.extend((term, s, None) for s in candidates)
    if not requests:
        return ToolResult(status='failed', summary='Resolve the business source database/schema first; the Workbench database is not a default source estate.', error_code='catalog_scope_required', data={'coverage':'incomplete','next_tool':'resolve_source_scope'})
    if any(not authorized_scope('.'.join(quote_identifier(v) for v in s), context) if s[1] else bool(context.get('authorized_schemas')) for _,s,_ in requests):
        return ToolResult(status='denied', summary='Requested discovery is outside the run scope.', error_code='authorization_denied')
    selected_scopes = sorted({s for _,s,_ in requests}, key=str)[:MAX_DISCOVERY_SCOPES]
    deferred = {s for _,s,_ in requests if s not in selected_scopes}
    matches = {term:[] for term in terms}; checked = set(); failed = []; scans = 0
    authority = json.dumps({k:context.get(k) for k in ('app_user_id','effective_role','authorized_schemas','authorized_source_scope','authorized_target_scope','evidence_revision')}, sort_keys=True, default=str)
    with workbench._domain_lock:
        cache = workbench.__dict__.setdefault('_scoped_catalog_cache', {})
        failures = workbench.__dict__.setdefault('_catalog_failed_strategies', {})
        by_database = {}
        for term, scope, exact in requests:
            if scope in selected_scopes: by_database.setdefault(scope[0], []).append((term,scope,exact))
        for db, group in by_database.items():
            usable = []
            for term, scope, exact in group:
                strategy = json.dumps([authority,db,scope[1],exact or 'discovery'])
                if strategy in failures: failed.append(ToolResult.model_validate(failures[strategy])); continue
                usable.append((term,scope,exact,strategy))
            if not usable: continue
            sqls=[];params=[]
            for term, (_,sc), exact, _ in usable:
                where=[];bindings=[]
                if sc is not None: where.append('TABLE_SCHEMA = ?');bindings.append(sc)
                if exact: where.append('TABLE_NAME = ?');bindings.append(exact)
                else:
                    for token in re.findall(r'[a-z0-9]+', term.casefold()):
                        token=token[:-1] if len(token)>3 and token.endswith('s') and not token.endswith('ss') else token
                        where.append("LOWER(TABLE_CATALOG || '.' || TABLE_SCHEMA || '.' || TABLE_NAME) LIKE ?");bindings.append('%'+token+'%')
                query=f'SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME FROM {quote_identifier(db)}.INFORMATION_SCHEMA.TABLES'
                query+=(' WHERE '+' AND '.join(where)) if where else ''
                query+=' ORDER BY TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME LIMIT ?';bindings.append(limit)
                if len(usable)>1: query='SELECT ? AS SEARCH_TERM, Q.* FROM ('+query+') Q';bindings=[term,*bindings]
                sqls.append(query);params.extend(bindings)
            query=' UNION ALL '.join(sqls)
            key=hashlib.sha256(json.dumps([authority,query,params],sort_keys=True).encode()).hexdigest()
            if key not in cache:
                used=getattr(workbench,'_catalog_discovery_queries',0)
                if used>=MAX_DISCOVERY_QUERIES:
                    deferred.update(scope for _,scope,_,_ in usable);continue
                workbench._catalog_discovery_queries=used+1;scans+=1
                try:
                    cache[key]=[dict(row.as_dict() if hasattr(row,'as_dict') else row) for row in workbench._session.sql(query,params=params).collect()]
                except (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated): raise
                except Exception as error:
                    diagnostics=sql_diagnostics(error)
                    result=ToolResult(status='failed',summary='Scoped metadata verification failed; unchecked objects remain unknown.',error_code='catalog_timeout' if str(diagnostics.get('native_code','')).lstrip('0')=='630' else 'catalog_query_failed',data={'diagnostics':diagnostics,'coverage':'incomplete','database':db})
                    for _,_,_,strategy in usable: failures[strategy]=result.model_dump(mode='json')
                    failed.append(result);continue
            checked.update(scope for _,scope,_,_ in usable)
            for raw in cache[key]:
                row={k.upper():v for k,v in raw.items()}
                term=row.get('SEARCH_TERM',usable[0][0])
                if term not in matches: continue
                fqn='.'.join(quote_identifier(str(row[k])) for k in ('TABLE_CATALOG','TABLE_SCHEMA','TABLE_NAME'))
                if fqn not in matches[term]: matches[term].append(fqn)
                matches[term]=matches[term][:limit]
    if failed and not checked: return failed[0]
    return ToolResult(status='succeeded',summary='Searched bounded caller-visible metadata; unchecked scopes remain unknown.',data={'matches':matches,'candidates':list(dict.fromkeys(v for group in matches.values() for v in group)), 'coverage':{'checked_scopes':[{'database':d,'schema':s} for d,s in sorted(checked,key=str)],'deferred_scopes':[{'database':d,'schema':s} for d,s in sorted(deferred,key=str)],'failed_scopes':[r.data for r in failed],'exhaustive':False,'discovery_allowance_exhausted':getattr(workbench,'_catalog_discovery_queries',0)>=MAX_DISCOVERY_QUERIES}},metrics={'metadata_scans':scans})
