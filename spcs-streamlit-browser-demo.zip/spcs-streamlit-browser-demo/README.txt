SPCS Streamlit Browser Demo Bundle
==================================

This folder is self-contained. You can copy or unzip just this bundle into a client deployment machine without bringing the whole `bbi-mig-ai-workbench` repo.

Contents
--------

- `app.py`: Streamlit app
- `Dockerfile`: image build for SPCS
- `requirements.txt`: local and container Python dependencies
- `.env.example`: local rehearsal environment example
- `deploy/client.streamlit-demo.env.example`: Snow CLI deployment env example
- `deploy/bootstrap_client_spcs_tools.ps1`: installs Snow CLI into a local tools venv
- `deploy/configure_client_snow_connection.ps1`: creates or reuses the Snow CLI connection
- `deploy/prepare_spcs_prereqs.ps1`: creates schema, image repo, stage, and optional compute pool and egress integration
- `deploy/build_and_push_demo_image.ps1`: builds the Docker image and pushes it to the Snowflake registry
- `deploy/deploy_streamlit_demo_service.ps1`: renders the service spec, stages it, and creates the service
- `deploy/grant_demo_endpoint_access.ps1`: grants `browser_access` to the target role
- `deploy/run_full_streamlit_demo_deploy.ps1`: one-command Windows deploy wrapper
- `deploy/render_spcs_spec.py`: service spec renderer
- `deploy/service-specs/spcs-streamlit-browser.yaml.tmpl`: SPCS service spec template
- `deploy/local_smoke_test.py`: Snowflake connectivity check without needing Streamlit
- `deploy/spcs-streamlit-browser-demo.txt`: step-by-step deployment walkthrough

Local rehearsal
---------------

1. Copy `.env.example` to `.env`.
2. Fill in your local Snowflake credentials.
3. Run:

   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   set -a
   source .env
   set +a
   python deploy/local_smoke_test.py
   streamlit run app.py

Notes
-----

- If `SNOWFLAKE_AUTHENTICATOR=externalbrowser`, the app uses browser auth.
- If `SNOWFLAKE_AUTHENTICATOR` is blank and `SNOWFLAKE_PASSWORD` is set, the app uses password auth. This matches your existing local `.env.local` pattern.
- In deployed SPCS mode, the app ignores local user credentials and uses Snowflake ingress caller-rights auth.

Docker image
------------

Build the image you will push to the Snowflake image repository:

  docker build --platform linux/amd64 -t spcs-streamlit-browser:local .

Deployment walkthrough
----------------------

Use:

  deploy/spcs-streamlit-browser-demo.txt

That file explains the step-by-step SPCS flow: registry, compute pool, stage, spec upload, service create, endpoint grant, and endpoint lookup.

Windows PowerShell flow
-----------------------

For a client AVD or any Windows machine, the bundle now includes `.ps1` scripts for the full flow:

  copy deploy\client.streamlit-demo.env.example deploy\client.streamlit-demo.env
  .\deploy\bootstrap_client_spcs_tools.ps1
  .\deploy\configure_client_snow_connection.ps1
  .\deploy\prepare_spcs_prereqs.ps1
  .\deploy\build_and_push_demo_image.ps1
  .\deploy\deploy_streamlit_demo_service.ps1

Or run the all-in-one wrapper:

  .\deploy\run_full_streamlit_demo_deploy.ps1
