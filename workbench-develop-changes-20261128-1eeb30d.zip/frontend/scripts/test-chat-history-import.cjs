const assert=require('node:assert/strict');
const ts=require('typescript');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const filename=path.resolve(__dirname,'../src/services/migrationAgentService.ts');
const source=fs.readFileSync(filename,'utf8');
const ast=ts.createSourceFile(filename,source,ts.ScriptTarget.Latest,true);
const declaration=ast.statements.find(node=>ts.isFunctionDeclaration(node)&&node.name?.text==='importLegacyQuickHistory');
let calls=[];
const context={exports:{},api:async(url,request)=>{calls.push({url,body:JSON.parse(request.body)});return {confirmed:true};}};
vm.runInNewContext(ts.transpileModule(declaration.getText(ast),{compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}}).outputText,context);
(async()=>{
 const message=[{role:'user',content:'Explain this mapping'}];
 const server=[{id:'local',title:'Saved',backendConversationId:'conv_1',messages:message},
 {id:'conv_2',title:'Saved',messages:message},{id:'deep',mode:'deep',title:'Deep',messages:message},
 {id:'empty',title:'Welcome',messages:[{role:'assistant',content:'Hello'}]}];
 assert.equal(await context.exports.importLegacyQuickHistory('browser',server),true);
 assert.equal(calls.length,0);
 const legacy={id:'legacy',title:'Local Quick',messages:message};
 assert.equal(await context.exports.importLegacyQuickHistory('browser',[...server,legacy]),true);
 assert.equal(calls.length,1);
 assert.deepEqual(calls[0].body.sessions.map(v=>v.legacy_id),['legacy']);
 assert.equal(legacy.messages[0].content,'Explain this mapping');
 console.log('Only local legacy Quick chats are imported; existing durable and empty chats cause no write.');
})().catch(error=>{console.error(error);process.exitCode=1;});

require('node:test')('paginated Recent chats keeps each conversation once and uses its latest metadata', async () => {
 const createRow=(id, title, updated_at='2026-11-27T12:00:00Z')=>({conversation_id:id,title,updated_at});
 const first=Array.from({length:100},(_,i)=>createRow(`chat-${i}`,`Title ${i}`));
 const second=[createRow('chat-99','Renamed','2026-11-27T12:01:00Z'),createRow('chat-100','Last')];
 const offsets=[];
 const runtime={exports:{},URLSearchParams,api:async(url)=>{
  const query=new URL(url,'http://localhost').searchParams;
  assert.equal(query.get('project_id'),'1101');
  offsets.push(query.get('offset'));
  return offsets.length===1?first:second;
 }};
 const historyDeclaration=ast.statements.find(node=>ts.isFunctionDeclaration(node)&&node.name?.text==='fetchAssistantConversationHistory');
 vm.runInNewContext(ts.transpileModule(historyDeclaration.getText(ast),{
  compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS},
 }).outputText,runtime);
 const history=await runtime.exports.fetchAssistantConversationHistory({projectId:'1101'});
 assert.deepEqual(offsets,['0','100']);
 assert.equal(history.length,101);
 assert.equal(new Set(history.map(item=>item.conversation_id)).size,101);
 assert.equal(history[0].title,'Renamed');
});
