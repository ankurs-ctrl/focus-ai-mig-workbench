"""Fast worker offline tests: no scan/reducer, network, SQL execution or deployment."""
import asyncio
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json
import time
from types import SimpleNamespace

import pytest

from app.core.automap_batch import invoke_batch
from app.core.sttm_builder import STTMBuilderService
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMBuilderResponse, STTMStatus, SubAgent, STTMArtifactType
from tests.test_automap_fast_transport import build as build_native_runtime, harness as transport_harness
from tests.unit.core.test_automap_retrieval import service as legacy_service
from tests.unit.core.test_automap_fast_context import add_table, fast_payload, unpack


class FinalAgent:
    def __init__(self, answers=(), *, final_payload=None):
        self.calls = []
        self.answers = list(answers)
        self.final_payload = final_payload

    def run_detailed(self, messages, **kwargs):
        self.calls.append((deepcopy(messages), kwargs))
        if self.answers:
            answer = self.answers.pop(0)
            if isinstance(answer, Exception):
                raise answer
            return answer, None, self.final_payload
        packet = unpack(messages)
        targets = [item["target_attribute"] for item in packet["data"]["attributes"]]
        return answer_for(targets), None, self.final_payload


class TestRuntime:
    __test__ = False
    is_test_runtime = True

    def __init__(self, agent, deadline):
        self.agent, self.deadline = agent, deadline

    def run(self, messages, *, call_index):
        return self.agent.run_detailed(messages, call_index=call_index,
            request_timeout=self.deadline - time.monotonic())


def service(agent):
    builder = legacy_service(agent)
    builder._settings = builder._settings.model_copy(update={
        "automap_fast_path_v1": True, "automap_fast_project_ids": ["allowed"]})
    builder._fast_model_runtime_factory = lambda service, req, decision, store, deadline: TestRuntime(agent, deadline)
    return builder


def prepared_request(value=None):
    from app.core.automap_batch import FAST_INTEGRATION_VERSION, canonical_model_wire_request, freeze_fast_handoff
    from app.core.automap_policy import preparation_hash
    from app.schema.sttm_builder import AgentExecutionContextV2
    req = STTMBuilderEnvelopeRequest.model_validate(value or fast_payload())
    req.context.execution_context = AgentExecutionContextV2(context_key="offline")
    req.context.prepared_context_hash = preparation_hash(req.context)
    deadline = req.meta.get("auto_map_deadline_at")
    req.meta["_automap_deadline"] = datetime.fromisoformat(deadline).timestamp() if deadline else None
    req.meta.update(auto_map_parent_resolution_version=FAST_INTEGRATION_VERSION, auto_map_prepared_readonly=True)
    req = canonical_model_wire_request(STTMBuilderService._with_intent_route(req))
    req.context.prepared_context_hash = preparation_hash(req.context)
    req.meta["_automap_fast_handoff"] = freeze_fast_handoff(req)
    return req


def answer_for(targets, **changes):
    mappings = {target: {"source_attributes": ["a.X47"], "confidence_score": 0.9,
                        "transformation_classification": "direct"} for target in targets}
    for target, update in changes.items():
        mappings[target].update(update)
    return json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": mappings}}})


def invoke(value=None, agent=None, builder=None):
    builder = builder or service(agent or FinalAgent())
    req = prepared_request(value)
    return builder, req, invoke_batch(builder, req, SimpleNamespace())


def test_single_final_call_no_scan_reducer_complete_exact_reads_and_none_thread(monkeypatch):
    monkeypatch.setattr("app.core.automap_parallel.prepare_parallel", lambda *args, **kwargs: pytest.fail("scan/reducer called"))
    value = fast_payload()
    add_table(value, columns=800, size=400)
    builder = service(FinalAgent())
    builder._build_auto_map_parallel_runtime = lambda **kwargs: pytest.fail("scan runtime called")
    builder._settings = builder._settings.model_copy(update={"automap_parallel_context_v1": True})
    saved = deepcopy(value)
    builder, req, (raw, thread, metadata) = invoke(value, builder=builder)
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["source_attributes"] == ["a.X47"], mapping
    assert thread is None and value == saved
    assert len(builder._agent.calls) == 1
    packet = unpack(builder._agent.calls[0][0])
    reads = packet["retrieved_auto_map_context"]
    assert all(item["result"]["complete"] for item in reads)
    assert any(item["request"] == {"operation": "columns", "relation": "D.S.A"} for item in reads)
    fast = metadata["auto_map_retrieval"]["auto_map_fast_path"]
    assert fast["scan_model_calls"] == fast["reducer_model_calls"] == 0
    assert fast["global_admission"] is False
    assert fast["admission"] == "test_runtime"
    assert "auto_map_fast_global_admission_unimplemented" not in {warning["code"] for warning in metadata["warnings"]}
    parsed = builder._parse_envelope(raw)
    response = STTMBuilderResponse.from_invocation(req, thread_id=thread, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=parsed[1], status=STTMStatus.COMPLETED,
        artifact_type=STTMArtifactType.SOURCE_MAPPING, message="Offline test")
    assert response.thread_id is None


def test_wide_parent_catalog_does_not_block_validated_cte_output():
    value = fast_payload()
    add_table(value, name="ACCOUNTS", columns=600, size=400)
    node = value["context"]["relation_graph"]["nodes"][0]
    node.update(kind="DERIVED_SOURCE", sql_text="SELECT OTHER0 AS X47 FROM D.S.ACCOUNTS",
                parent_relation_ids=["ACCOUNTS"])
    builder, _, (raw, _, metadata) = invoke(value)
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["source_attributes"] == ["a.X47"]
    assert metadata["auto_map_retrieval"]["model_call_count"] == 1
    packet = unpack(builder._agent.calls[0][0])
    assert len(json.dumps(builder._agent.calls[0][0]).encode()) < 120_000
    assert {item["source_ref"] for item in packet["context"]["selectable_sources"]} == {'a.X47'}
    assert not any(item.get("body", {}).get("relation") == "D.S.ACCOUNTS"
                   for item in packet["context"]["table_records"])
    from app.schema.sttm_builder import AttributeMapping
    from app.core.automap_fast_context import FastContextPlan, validate_derived_output_contracts
    from app.core.automap_retrieval import AutoMapContext
    store = AutoMapContext(value)
    store.manifest()
    store.discover_batch(lambda targets: {target: {"diagnostics": {"status": "no_match"}} for target in targets})
    plan = FastContextPlan(store, max_chars=120_000, max_bytes=120_000,
        validated_derived=validate_derived_output_contracts(prepared_request(value), None))
    with pytest.raises(ValueError):
        plan.validate_candidate(AttributeMapping(source_attributes=["ACCOUNTS.OTHER1"], confidence_score=.9))


def test_ten_pending_targets_reach_decision_with_wide_parent_and_preserve_input():
    value = fast_payload(10)
    add_table(value, name="ACCOUNTS", columns=600, size=400)
    value["context"]["relation_graph"]["nodes"][0].update(
        kind="DERIVED_SOURCE", sql_text="SELECT OTHER0 AS X47 FROM D.S.ACCOUNTS",
        parent_relation_ids=["ACCOUNTS"])
    saved = deepcopy(value)
    agent = FinalAgent()
    _, _, (raw, _, metadata) = invoke(value, agent)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert len(mappings) == 10
    assert all(item["source_attributes"] == ["a.X47"] for item in mappings.values())
    assert metadata["auto_map_retrieval"]["model_call_count"] == len(agent.calls) == 1
    assert metadata["auto_map_retrieval"]["peak_message_bytes"] < 120_000
    assert value == saved


def test_country_code_positive_control_repairs_false_no_sources():
    value = fast_payload()
    value["context"]["mapping_intent"] = {"intent": "Diagnostic identity projection of COUNTRY_CODES.COUNTRY_CODE into BILLINGCOUNTRY; no household population claim."}
    source = {"database": "D", "schema": "S", "table": "COUNTRY_CODES"}
    target = {"database": "D", "schema": "S", "table": "HOUSEHOLD"}
    value["data"]["attributes"][0].update(target_table=target, target_attribute="BILLINGCOUNTRY",
                                            target_description="Household billing country code")
    value["context"].update(source_tables=[source], target_table=target,
                            workspace_context={"driving_relation_id": "cc"})
    value["context"]["relation_graph"]["nodes"] = [{"relation_id": "cc", "alias": "cc",
        "kind": "PHYSICAL_TABLE", "table": source, "output_columns": [
            {"name": "COUNTRY_CODE", "data_type": "TEXT"},
            {"name": "COUNTRY_ALIAS", "data_type": "TEXT"}]}]
    value["context"]["semantic_context"] = [{"table": source, "semantic_model": {"attributes": [
        {"name": "COUNTRY_CODE", "business_meaning": "ISO country code"},
        {"name": "COUNTRY_ALIAS", "business_meaning": "Alternative country spelling"}]}},
        {"table": target, "semantic_model": {"attributes": [
            {"name": "BILLINGCOUNTRY", "business_meaning": "Household billing country code"}]}}]
    first = answer_for(["BILLINGCOUNTRY"], BILLINGCOUNTRY={
        "source_attributes": [], "confidence_score": 0,
        "transformation_classification": "unresolved",
        "unmatched_reason": "No eligible source columns are available"})
    second = json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
        "BILLINGCOUNTRY": {"source_attributes": ['cc."COUNTRY_CODE"'],
        "candidate_source_attributes": ['cc."COUNTRY_ALIAS"'],
        "confidence_score": .82, "confidence_reason": "Country code matches the target meaning; alias is a lookup alternative.",
        "transformation_classification": "direct"}}}}})
    agent = FinalAgent([first, second])
    builder, _, (raw, _, metadata) = invoke(value, agent)
    mapping = json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]
    assert mapping["source_attributes"] == ['cc."COUNTRY_CODE"']
    assert mapping["candidate_source_attributes"] == ['cc."COUNTRY_ALIAS"']
    assert len(agent.calls) == metadata["auto_map_retrieval"]["model_call_count"] == 2
    assert all(len(json.dumps(messages).encode()) < 120_000 for messages, _ in agent.calls)


def test_thirty_seven_target_country_control_keeps_unrelated_targets_unresolved():
    value = fast_payload(37)
    value["context"]["mapping_intent"] = {"intent": "Diagnostic identity projection of COUNTRY_CODES.COUNTRY_CODE into BILLINGCOUNTRY; no household population claim."}
    source = {"database": "D", "schema": "S", "table": "COUNTRY_CODES"}
    target = {"database": "D", "schema": "S", "table": "HOUSEHOLD"}
    value["context"]["source_tables"] = [source]
    value["context"]["target_table"] = target
    value["context"]["workspace_context"] = {"driving_relation_id": "cc"}
    value["context"]["relation_graph"]["nodes"] = [{"relation_id": "cc", "alias": "cc",
        "kind": "PHYSICAL_TABLE", "table": source, "output_columns": [
            {"name": "COUNTRY_CODE", "data_type": "TEXT"},
            {"name": "COUNTRY_ALIAS", "data_type": "TEXT"}]}]
    value["context"]["semantic_context"] = [{"table": source, "semantic_model": {"attributes": [
        {"name": "COUNTRY_CODE", "business_meaning": "ISO country code"},
        {"name": "COUNTRY_ALIAS", "business_meaning": "Alternative country spelling"}]}},
        {"table": target, "semantic_model": {"attributes": [
            {"name": "BILLINGCOUNTRY", "business_meaning": "Household billing country code"}]}}]
    value["data"]["attributes"][0].update(target_table=target, target_attribute="BILLINGCOUNTRY",
                                            target_description="Household billing country code")
    for item in value["data"]["attributes"][1:]:
        item["target_table"] = target
    names = [item["target_attribute"] for item in value["data"]["attributes"]]
    mappings = {name: {"source_attributes": [], "confidence_score": 0,
        "transformation_classification": "unresolved", "unmatched_reason": "No supported source was established"}
        for name in names}
    mappings["BILLINGCOUNTRY"] = {"source_attributes": ['cc."COUNTRY_CODE"'],
        "candidate_source_attributes": ['cc."COUNTRY_ALIAS"'], "confidence_score": .82,
        "confidence_reason": "Country code matches target meaning; alias remains lookup evidence.",
        "transformation_classification": "direct"}
    agent = FinalAgent([json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": mappings}}})])
    _, _, (raw, _, metadata) = invoke(value, agent)
    result = json.loads(raw)["data"]["result"]["mappings"]
    assert len(result) == 37 and len(set(result)) == 37
    assert result["BILLINGCOUNTRY"]["source_attributes"] == ['cc."COUNTRY_CODE"']
    assert sum(item["transformation_classification"] == "unresolved" for item in result.values()) == 36
    assert metadata["auto_map_retrieval"]["peak_message_bytes"] < 120_000


@pytest.mark.parametrize("kind", ["table", "global"])
def test_oversized_packet_returns_unresolved_without_any_model_call(kind):
    value = fast_payload()
    if kind == "table":
        value["context"]["semantic_context"][0]["semantic_model"]["semantic_notes"] = "Meaning " * 60_000
    else:
        value["data"]["message"] = "Global rule " * 40_000
    builder, _, (raw, thread, metadata) = invoke(value)
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["transformation_classification"] == "unresolved"
    assert not builder._agent.calls and thread is None
    assert "auto_map_fast_message_budget_exceeded" in {item["code"] for item in metadata["warnings"]}


@pytest.mark.parametrize("answer", ["not json", "[]", "{", "x" * 130_000], ids=["prose", "array", "truncated", "oversized"])
def test_invalid_response_gets_only_one_bounded_retry(answer):
    agent = FinalAgent([answer, answer])
    builder, _, (raw, _, metadata) = invoke(agent=agent)
    assert len(agent.calls) == 2
    assert metadata["auto_map_retrieval"]["model_call_count"] == 2
    assert all(0 < call[1]["request_timeout"] <= 160 for call in agent.calls)
    assert agent.calls[1][1]["request_timeout"] <= agent.calls[0][1]["request_timeout"]
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"


def test_retry_can_complete_and_transport_failure_is_not_retried():
    agent = FinalAgent(["not json"])
    _, _, (raw, _, _) = invoke(agent=agent)
    assert len(agent.calls) == 2
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]
    agent = FinalAgent([TimeoutError("uncertain remote completion")])
    _, _, (_, _, metadata) = invoke(agent=agent)
    assert len(agent.calls) == metadata["auto_map_retrieval"]["model_call_count"] == 1


def test_bad_target_does_not_discard_completed_mapping():
    value = fast_payload(2)
    bad = answer_for(["NAME0", "NAME1"], NAME1={"source_attributes": ["unseen.SECRET"]})
    agent = FinalAgent([bad, bad])
    _, _, (raw, _, _) = invoke(value, agent)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert mappings["NAME0"]["source_attributes"] == ["a.X47"]
    assert mappings["NAME1"]["transformation_classification"] == "unresolved"
    assert len(agent.calls) == 1


def test_unresolved_never_claims_absence_from_omitted_tables():
    value = fast_payload()
    add_table(value)
    answer = answer_for(["NAME0"], NAME0={"source_attributes": [], "transformation_classification": "unresolved",
                                        "unmatched_reason": "There is no source anywhere"})
    _, _, (raw, _, _) = invoke(value, FinalAgent([answer]))
    reason = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["unmatched_reason"]
    assert "non-exhaustive" in reason and "There is no source" not in reason


@pytest.mark.parametrize("seconds", [-1, 10, 20])
def test_expired_deadline_or_reserve_prevents_discovery_and_dispatch(seconds):
    value = fast_payload()
    value["meta"]["auto_map_deadline_at"] = (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()
    builder = service(FinalAgent())
    builder._discover_auto_map_batch_evidence = lambda *args: pytest.fail("Discovery after deadline")
    _, _, (_, _, metadata) = invoke(value, builder=builder)
    assert not builder._agent.calls
    assert metadata["auto_map_retrieval"]["model_call_count"] == 0


def test_missing_deadline_fails_without_fallback():
    value = fast_payload()
    value["meta"].pop("auto_map_deadline_at")
    builder, _, (_, _, metadata) = invoke(value)
    assert not builder._agent.calls
    assert metadata["auto_map_retrieval"]["model_call_count"] == 0


def test_worker_runs_rule_stage_without_legacy_source_repair():
    builder = service(FinalAgent())
    req = prepared_request()
    response = SimpleNamespace(meta={}, data=None, result=None, _auto_map_admitted_evidence={})
    builder.invoke = lambda *args, **kwargs: response
    builder._repair_direct_source_bindings = lambda *args, **kwargs: pytest.fail("Legacy repair invoked")
    async def rule_stage(*args, **kwargs):
        return response
    builder._apply_complex_transformation_stage = rule_stage
    result = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert result.meta["auto_mapping_worker"]["selective_transformation_stage_ms"] >= 0


def test_explicit_fast_flag_routes_without_parallel_feature():
    builder = service(FinalAgent())
    builder._settings = builder._settings.model_copy(update={"automap_context_retrieval_v1": False})
    req = STTMBuilderEnvelopeRequest.model_validate(fast_payload())
    assert STTMBuilderService._auto_map_retrieval_enabled(builder, req)
    req.meta["auto_map_fast_path"] = "v2"
    assert not STTMBuilderService._auto_map_retrieval_enabled(builder, req)


def test_invalid_structured_envelope_has_one_retry():
    agent = FinalAgent(['{"agent":"AGT_SOURCE_MAPPING","data":{"result":{}}}'])
    _, _, (raw, _, _) = invoke(agent=agent)
    assert len(agent.calls) == 2
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]


def test_missing_factory_never_falls_back_to_legacy_client(monkeypatch):
    from app.core.snowflake_agent import SnowflakeAgentClient
    client = SnowflakeAgentClient.__new__(SnowflakeAgentClient)
    client._retry_attempts = 7
    client._timeout = 240
    monkeypatch.setattr(SnowflakeAgentClient, "run_detailed", lambda *args, **kwargs: pytest.fail("Legacy client bypass"))
    builder = service(client)
    builder._fast_model_runtime_factory = None
    _, _, (raw, _, metadata) = invoke(builder=builder)
    assert client._retry_attempts == 7
    assert metadata["auto_map_retrieval"]["model_call_count"] == 0
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"


def test_factory_runs_once_after_exact_reads_and_shortlist_for_terminal_repair():
    agent = FinalAgent(["malformed"])
    builder = service(agent)
    factories = []
    def factory(current, req, decision, store, deadline):
        assert store.reads and store.discovered
        assert deadline < time.monotonic() + 160
        factories.append(store)
        return TestRuntime(agent, deadline)
    builder._fast_model_runtime_factory = factory
    invoke(builder=builder)
    assert len(factories) == 1
    assert [options["call_index"] for _, options in agent.calls] == [1, 2]


def test_exhausted_retry_deadline_does_not_reset_network_budget(monkeypatch):
    clock = [time.monotonic()]
    monkeypatch.setattr("app.core.automap_batch.time.monotonic", lambda: clock[0])
    class ExpiringAgent(FinalAgent):
        def run_detailed(self, messages, **kwargs):
            self.calls.append((messages, kwargs))
            clock[0] += 170
            return "not json", None, None
    agent = ExpiringAgent()
    _, _, (_, _, metadata) = invoke(agent=agent)
    assert len(agent.calls) == 1
    assert metadata["auto_map_retrieval"]["model_call_count"] == 1


def test_validation_reserve_keeps_completed_targets_on_deadline(monkeypatch):
    clock = [time.monotonic()]
    monkeypatch.setattr("app.core.automap_batch.time.monotonic", lambda: clock[0])
    builder = service(FinalAgent())
    original = builder._validate_auto_map_candidate
    def validate(*args):
        result = original(*args)
        clock[0] += 190
        return result
    builder._validate_auto_map_candidate = validate
    _, _, (raw, _, _) = invoke(fast_payload(2), builder=builder)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert mappings["NAME0"]["source_attributes"] == ["a.X47"]
    assert mappings["NAME1"]["transformation_classification"] == "unresolved"


def test_full_service_budget_failure_is_needs_input_and_none_thread():
    value = fast_payload()
    value["data"]["message"] = "Mandatory context " * 40_000
    builder = service(FinalAgent())
    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._should_use_analyst = lambda *args: False
    builder._persist_response_artifact = lambda *args: None
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    req = prepared_request(value)
    response = builder.invoke(req)
    assert response.data.status == STTMStatus.NEEDS_INPUT
    assert response.thread_id is None and not builder._agent.calls


def test_fast_preflight_uses_same_bounded_packet_not_scan_plan(monkeypatch):
    value = fast_payload()
    add_table(value, columns=500, size=400)
    builder = service(FinalAgent())
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    projected = builder.project_agent_payload(req, builder._settings)
    assert projected.diagnostics["fast_preflight"]["model_calls"] == 0
    assert projected.diagnostics["fast_preflight"]["runtime_ready"] is False
    assert projected.diagnostics["fast_preflight"]["complete_message_chars"] < 50_000
    assert not builder._agent.calls


def test_read_limit_blocks_before_model_and_does_not_claim_table_was_scanned():
    builder = service(FinalAgent())
    builder._settings = builder._settings.model_copy(update={"automap_context_max_operations": 1})
    _, _, (_, _, metadata) = invoke(builder=builder)
    assert not builder._agent.calls
    fast = metadata["auto_map_retrieval"]["auto_map_fast_path"]
    assert fast["admitted_groups"] == []
    assert "table:D.S.A" in fast["unscanned_groups"]


@pytest.mark.parametrize("tool", ["CORTEX_ANALYST", "SearchMappingEvidence"])
def test_fast_delegation_never_adds_external_model_or_new_discovery(tool):
    class DelegatingAgent(FinalAgent):
        def run_detailed(self, messages, **kwargs):
            self.calls.append((messages, kwargs))
            packet = unpack(messages)
            delegation = {"tool": tool, "snapshot_hash": packet["context"]["auto_map_retrieval"]["snapshot_hash"],
                "operation": "search_more", "targets": ["NAME0"], "reason": "missing_rule"}
            return json.dumps({"meta": {"delegation": delegation}}), None, {}
    builder = service(DelegatingAgent())
    builder._auto_map_analyst_evidence = lambda *args: pytest.fail("Analyst called")
    calls = []
    def discover(req, targets):
        calls.append(targets)
        return {target: {"diagnostics": {"status": "no_match"}} for target in targets}
    builder._discover_auto_map_batch_evidence = discover
    _, _, (raw, _, _) = invoke(builder=builder)
    assert len(calls) == len(builder._agent.calls) == 1
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"


def test_complete_expression_runs_real_compiler_and_unread_citation_stays_unresolved():
    answer = answer_for(["NAME0"], NAME0={"preprocessing_rule": "UPPER(a.X47)",
        "preprocessing_rule_type": "Custom", "transformation_classification": "complex"})
    _, _, (raw, _, _) = invoke(agent=FinalAgent([answer]))
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["preprocessing_rule"] == "UPPER(a.X47)", mapping
    answer = answer_for(["NAME0"], NAME0={"used_learning_ids": ["not-provided"]})
    _, _, (raw, _, _) = invoke(agent=FinalAgent([answer, answer]))
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"


@pytest.mark.parametrize("change", ["disabled", "project", "readonly", "version", "graph", "requirements", "execution", "deadline"])
def test_worker_rejects_untrusted_or_changed_fast_handoff_before_model(change):
    builder = service(FinalAgent())
    req = prepared_request()
    if change == "disabled":
        builder._settings = builder._settings.model_copy(update={"automap_fast_path_v1": False})
    elif change == "project":
        req.context.project_id = "not-allowlisted"
    elif change == "readonly":
        req.meta["auto_map_prepared_readonly"] = False
    elif change == "version":
        req.meta["auto_map_parent_resolution_version"] = "old"
    elif change == "graph":
        req.context.relation_graph.nodes[0].alias = "tampered"
    elif change == "requirements":
        req.data.attributes[0].target_description = "tampered meaning"
    elif change == "deadline":
        req.meta["auto_map_deadline_at"] = "2999-01-01T00:00:00Z"
    else:
        req.context.execution_context = None
    with pytest.raises(ValueError):
        builder.invoke(req)
    assert not builder._agent.calls


def test_fast_unbound_value_expression_remains_unresolved():
    answer = answer_for(["NAME0"], NAME0={"source_attributes": [], "preprocessing_rule": "$MissingValue",
        "preprocessing_rule_type": "Custom", "transformation_classification": "complex"})
    _, _, (raw, _, _) = invoke(agent=FinalAgent([answer]))
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"


def governed_parent_discovery(*, counters=None, actor=True):
    """Live job's metadata shape/counters, never its source values or evidence IDs."""
    from app.core.automap_batch import freeze_fast_handoff, validate_fast_request
    from app.guardrails.config.loader import load_config
    from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
    from app.guardrails.runtime.preflight import PreflightGuard
    from app.guardrails.runtime.postflight import PostflightGuard

    builder = service(FinalAgent())
    config = load_config(settings=builder._settings)
    builder._model_guard = ModelBoundaryGuard(config)
    builder._postflight_guard = PostflightGuard(config)
    builder._persist_response_artifact = lambda *args: None
    builder._discover_auto_map_batch_evidence = lambda *args: pytest.fail("Worker repeated parent Search")
    value = fast_payload(37)
    # Two-column physical source, with no applicable positive historical evidence.
    value["context"]["relation_graph"]["nodes"][0]["output_columns"].append({"name": "CODE", "data_type": "TEXT"})
    value["context"]["learning_context"] = {}
    if actor:
        value["actor"] = {"user_id": "OFFLINE_CALLER", "role": "SAME_CALLER_ROLE"}
        value["context"]["current_role"] = "SAME_CALLER_ROLE"
    raw, decision = PreflightGuard(config).apply_to_sttm_request(value, trace_id="offline-live-shape", persona="ADMIN")
    parent = prepared_request(raw)
    parent = builder._govern_request_for_model(parent, decision)
    diagnostics = {"status": "no_applicable_match", "route": "search", "query_count": 74,
        "returned_hit_count": 188, "returned_id_count": 188, "canonical_read_count": 2,
        "hydrated_ids": [f"offline-id-{index}" for index in range(188)]}
    diagnostics.update(counters or {})
    discovery = {item.target_attribute: {"evidence": {}, "available_evidence": {},
        "source_candidates": {item.target_attribute: []}, "diagnostics": deepcopy(diagnostics)}
        for item in parent.data.attributes}
    parent.meta["_automap_fast_handoff"] = freeze_fast_handoff(parent, discovery=discovery)
    validate_fast_request(parent, builder._settings)
    return builder, parent


@pytest.mark.parametrize("start,count", [(0, 10), (10, 9), (19, 9), (28, 9)])
@pytest.mark.parametrize("actor", [False, True], ids=["stored-null-actor", "same-caller-actor"])
def test_real_governance_replays_parent_search_at_parent_scope(start, count, actor, monkeypatch):
    import socket
    from app.core.automap_batch import validate_fast_request
    from app.core.automap_retrieval import AutoMapContext
    from app.schema.sttm_builder import STTMAgentRequestEnvelope

    monkeypatch.setattr(socket.socket, "connect", lambda *args: pytest.fail("Unexpected network"))
    builder, parent = governed_parent_discovery(actor=actor)
    before = parent.model_dump(mode="json")
    batch = parent.model_copy(deep=True)
    batch.data.attributes = batch.data.attributes[start:start + count]
    batch.meta["auto_mapping_batch_index"] = start
    batch = STTMBuilderEnvelopeRequest.model_validate(json.loads(json.dumps(batch.to_worker_payload(), sort_keys=True)))
    decision = builder._build_governance_decision(batch)
    assert decision.persona == "ADMIN"
    governed = builder._govern_request_for_model(batch, decision)
    assert validate_fast_request(governed, builder._settings) == parent.meta["_automap_fast_handoff"]
    # Exact original failure: 74 parent queries cannot fit a 30/27-query child ceiling.
    original_store = AutoMapContext(STTMAgentRequestEnvelope.from_builder_request(governed).model_dump(mode="json"))
    with pytest.raises(ValueError, match="Physical Search/hydration work exceeded"):
        original_store.discover_batch(lambda targets: {target: parent.meta["_automap_fast_handoff"]["discovery"][target]
                                                     for target in targets})
    response = builder.invoke(batch)
    retrieval = response.meta["auto_map_retrieval"]
    assert len(builder._agent.calls) == 1, response.warnings
    assert retrieval["operation_count"] > 0
    assert retrieval["search_work"] == dict.fromkeys(["query_count", "returned_hit_count", "returned_id_count", "canonical_read_count"], 0)
    assert retrieval["parent_discovery"]["target_count"] == 37
    assert retrieval["parent_discovery"]["search_work"] == {
        "query_count": 74, "returned_hit_count": 188, "returned_id_count": 188, "canonical_read_count": 2}
    assert "parent_discovery" not in json.dumps(builder._agent.calls[0][0])
    assert "offline-id-" not in json.dumps(builder._agent.calls[0][0])
    assert parent.model_dump(mode="json") == before


@pytest.mark.parametrize("key,limit", [("query_count", 111), ("returned_hit_count", 888),
                                    ("returned_id_count", 444), ("canonical_read_count", 5)])
@pytest.mark.parametrize("invalid", [False, True])
def test_frozen_parent_work_keeps_original_ceilings_and_safe_diagnostics(key, limit, invalid, caplog):
    builder, parent = governed_parent_discovery(counters={key: limit + int(invalid)})
    batch = parent.model_copy(deep=True)
    batch.data.attributes = batch.data.attributes[:1]
    response = builder.invoke(batch)
    retrieval = response.meta["auto_map_retrieval"]
    assert not any(retrieval["search_work"].values())
    if invalid:
        assert not builder._agent.calls and retrieval["operation_count"] == 0
        assert "invariant=parent_discovery_work_budget" in caplog.text
        assert "parent_discovery_work_budget" not in " ".join(warning.message for warning in response.warnings)
        assert "offline-id-" not in caplog.text
    else:
        assert len(builder._agent.calls) == 1
        assert retrieval["parent_discovery"]["search_work"][key] == limit


@pytest.mark.parametrize("mutation,code", [
    ("disabled", "project_disabled"), ("parent_version", "parent_version"),
    ("readonly", "prepared_readonly"), ("missing", "handoff_missing"),
    ("handoff_version", "handoff_version"), ("wire_version", "model_wire_version"),
    ("no_prepared_hash", "prepared_hash_missing"), ("no_execution", "execution_context_missing"),
    ("prepared_hash", "prepared_hash_mismatch"), ("handoff_prepared_hash", "handoff_prepared_hash_mismatch"),
    ("context", "context_hash_mismatch"), ("caller", "request_hash_mismatch"),
    ("metadata", "request_hash_mismatch"), ("discovery", "request_hash_mismatch"),
    ("requirements", "target_requirements_mismatch"), ("duplicate", "target_scope"),
])
def test_fast_validation_reports_exact_invariant_without_logging_values(mutation, code, caplog):
    from app.core.automap_batch import validate_fast_request
    builder, req = governed_parent_discovery()
    handoff = req.meta["_automap_fast_handoff"]
    secret = "PRIVATE_DIAGNOSTIC_VALUE"
    if mutation == "disabled":
        builder._settings = builder._settings.model_copy(update={"automap_fast_path_v1": False})
    elif mutation == "parent_version":
        req.meta["auto_map_parent_resolution_version"] = secret
    elif mutation == "readonly":
        req.meta["auto_map_prepared_readonly"] = False
    elif mutation == "missing":
        req.meta.pop("_automap_fast_handoff")
    elif mutation == "handoff_version":
        handoff["version"] = secret
    elif mutation == "wire_version":
        handoff["model_wire_version"] = secret
    elif mutation == "no_prepared_hash":
        req.context.prepared_context_hash = None
    elif mutation == "no_execution":
        req.context.execution_context = None
    elif mutation == "prepared_hash":
        req.context.relation_graph.nodes[0].alias = secret
    elif mutation == "handoff_prepared_hash":
        handoff["prepared_context_hash"] = secret
    elif mutation == "context":
        req.context.execution_context.context_key = secret
    elif mutation == "caller":
        req.actor.user_id = secret
    elif mutation == "metadata":
        req.meta["unknown_private_metadata"] = secret
    elif mutation == "discovery":
        handoff["discovery"]["NAME0"]["diagnostics"]["status"] = secret
    elif mutation == "requirements":
        req.data.attributes[0].target_description = secret
    else:
        req.data.attributes.append(req.data.attributes[0].model_copy(deep=True))
    with pytest.raises(ValueError) as raised:
        validate_fast_request(req, builder._settings)
    assert raised.value.code == code
    assert f"invariant={code}" in caplog.text
    assert secret not in caplog.text and secret not in str(raised.value)
    assert not builder._agent.calls


@pytest.mark.parametrize("value", ["not-a-date", None, "2999-01-01T00:00:00Z"])
def test_frozen_invalid_deadline_has_safe_diagnostic(value, caplog):
    from app.core.automap_batch import freeze_fast_handoff, validate_fast_request
    builder, req = governed_parent_discovery()
    req.meta["auto_map_deadline_at"] = value
    req.meta["_automap_fast_handoff"] = freeze_fast_handoff(req)
    with pytest.raises(ValueError) as raised:
        validate_fast_request(req, builder._settings)
    assert raised.value.code == "deadline_mismatch"
    assert "invariant=deadline_mismatch" in caplog.text


def test_parent_replay_preserves_actual_evidence_and_failure_status_without_audit_bulk():
    from app.core.automap_batch import _FastAutoMapContext
    from app.schema.sttm_builder import STTMAgentRequestEnvelope
    builder, parent = governed_parent_discovery()
    handoff = deepcopy(parent.meta["_automap_fast_handoff"])
    record = {"pattern_id": "real-evidence", "target_column": "NAME0", "summary": "Exact current business rule"}
    negative = {"correction_id": "negative", "prevention_hint": "Never reuse the old source"}
    handoff["discovery"]["NAME0"].update(evidence={"search_hydrated_evidence": [record], "mandatory_negative_evidence": [negative]},
        available_evidence={"search_hydrated_evidence": [record]}, source_candidates={"NAME0": ["a.X47"]})
    handoff["discovery"]["NAME0"]["diagnostics"]["status"] = "degraded"
    before = deepcopy(handoff)
    batch = parent.model_copy(deep=True)
    batch.data.attributes = batch.data.attributes[:1]
    store = _FastAutoMapContext(STTMAgentRequestEnvelope.from_builder_request(batch).model_dump(mode="json"))
    store.replay_parent_discovery(handoff)
    assert store.discovered["NAME0"]["diagnostics"] == {"status": "degraded", "route": "search"}
    assert store.discovered["NAME0"]["source_candidates"] == {"NAME0": ["a.X47"]}
    assert store.evidence["NAME0"]["search_hydrated_evidence"] == [record]
    assert store.evidence["NAME0"]["mandatory_negative_evidence"] == [negative]
    assert store.available_evidence["NAME0"]["search_hydrated_evidence"] == [record]
    assert "historical retrieval unavailable" in store.missing_reads("NAME0", {"source_attributes": []})
    assert handoff == before and not any(store.search_work.values())


def test_parent_audit_ids_exceed_unpaged_discovery_receipt_even_with_correct_parent_ceiling():
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    from app.core.automap_batch import _FastAutoMapContext
    from app.core.automap_retrieval import AutoMapContext
    from app.schema.sttm_builder import STTMAgentRequestEnvelope
    _, parent = governed_parent_discovery()
    handoff = parent.meta["_automap_fast_handoff"]
    payload = STTMAgentRequestEnvelope.from_builder_request(parent).model_dump(mode="json")
    original = AutoMapContext(payload)
    original.discover_batch(lambda targets: {target: handoff["discovery"][target] for target in targets})
    assert original.search_work["query_count"] == 74
    query = {"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": original.snapshot_hash,
        "operation": "discover", "target": "NAME0"}
    with pytest.raises(AgentPayloadBudgetError, match="retrieval allowance"):
        original.read(query, max_bytes=2048)
    replay = _FastAutoMapContext(payload)
    replay.replay_parent_discovery(handoff)
    receipt = replay.read(query, max_bytes=2048)
    assert receipt["complete"] is True and "offline-id-" not in json.dumps(receipt)
    assert len(handoff["discovery"]["NAME0"]["diagnostics"]["hydrated_ids"]) == 188


@pytest.mark.parametrize("value", [-1, "PRIVATE_BAD_COUNTER"])
def test_invalid_parent_counter_never_reaches_worker_reads_or_logs_value(value, caplog):
    builder, parent = governed_parent_discovery(counters={"query_count": value})
    parent.data.attributes = parent.data.attributes[:1]
    response = builder.invoke(parent)
    assert not builder._agent.calls
    assert response.meta["auto_map_retrieval"]["operation_count"] == 0
    assert "invariant=parent_discovery_work_budget" in caplog.text
    assert "PRIVATE_BAD_COUNTER" not in caplog.text


@pytest.mark.parametrize("change,code", [("missing_target", "discovery_target_scope"),
    ("foreign_target", "discovery_target_scope"), ("bad_result", "discovery_shape"), ("bad_diagnostics", "discovery_shape")])
def test_invalid_frozen_discovery_rejected_without_fallback_search(change, code, caplog):
    from app.core.automap_batch import freeze_fast_handoff
    builder, req = governed_parent_discovery()
    discovery = req.meta["_automap_fast_handoff"]["discovery"]
    if change == "missing_target":
        discovery.pop("NAME36")
    elif change == "foreign_target":
        discovery["FOREIGN"] = deepcopy(discovery["NAME0"])
    elif change == "bad_result":
        discovery["NAME36"] = "bad"
    else:
        discovery["NAME36"]["diagnostics"] = "bad"
    req.meta["_automap_fast_handoff"] = freeze_fast_handoff(req, discovery=discovery)
    req.data.attributes = req.data.attributes[:1]
    response = builder.invoke(req)
    assert not builder._agent.calls
    assert response.meta["auto_map_retrieval"]["operation_count"] == 0
    assert f"invariant={code}" in caplog.text


def warning_request(target_count=1):
    value = fast_payload(target_count)
    value["data"]["attributes"][0]["target_attribute"] = "BILLINGCOUNTRY"
    value["context"]["semantic_context"][0]["semantic_model"]["attributes"][0]["business_meaning"] = "Billing country"
    value["context"]["semantic_context"][1]["semantic_model"]["attributes"][0].update(
        name="BILLINGCOUNTRY", business_meaning="Billing country")
    value["context"]["learning_context"] = {}
    return value


def warning_answer(targets, warnings, *, unresolved=False):
    envelope = json.loads(answer_for(targets))
    envelope["warnings"] = deepcopy(warnings)
    if unresolved:
        for candidate in envelope["data"]["result"]["mappings"].values():
            candidate.update(source_attributes=[], confidence_score=0, mapping_mode="UNRESOLVED",
                transformation_classification="unresolved", unmatched_reason="Insufficient exact evidence")
    return envelope


def test_live_warning_shape_nine_unresolved_is_not_batch_validation_failure(caplog):
    # Reconstruct the reported live shape; no private archive or live service is read.
    value = warning_request(9)
    targets = [item["target_attribute"] for item in value["data"]["attributes"]]
    warning = "  Insufficient evidence for the requested targets.\nNo absence established.  "
    answer = warning_answer(targets, [warning], unresolved=True)
    agent = FinalAgent([json.dumps(answer)])
    builder = service(agent)
    parsed = builder._parse_envelope(json.dumps(answer))
    assert parsed[4] is None and parsed[6] != STTMStatus.FAILED
    assert len(parsed[1].mappings) == 9
    assert all(item.mapping_mode == "source" for item in parsed[1].mappings.values())
    _, _, (raw, _, metadata) = invoke(value, builder=builder)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert len(mappings) == 9
    assert all(item["source_attributes"] == [] and item["confidence_score"] == 0
               and item["transformation_classification"] == "unresolved"
               and "non-exhaustive" in item["unmatched_reason"] for item in mappings.values())
    assert len(agent.calls) == metadata["auto_map_retrieval"]["model_call_count"] == 1
    assert "auto_map_fast_stage_failed" not in {item["code"] for item in metadata["warnings"]}
    assert {"code": "agent_warning", "message": warning, "field": None} in metadata["warnings"]
    assert "stage=mapping_validation" not in caplog.text


@pytest.mark.parametrize("location", ["envelope", "transport", "both"])
def test_warning_strings_and_dicts_keep_fully_validated_billingcountry(location, monkeypatch, caplog):
    from app.schema.contracts import ApiWarning

    literal = "  <script>throw new Error('never execute')</script>\n${not_code}  "
    structured = {"code": "coverage_notice", "message": "Exact structured warning", "field": "BILLINGCOUNTRY"}
    warnings = [literal, structured, {"code": ["bad"], "message": {"nested": "PRIVATE_WARNING"}}, None, 17]
    answer = warning_answer(["BILLINGCOUNTRY"], warnings if location != "transport" else [])
    payload = {"warnings": deepcopy(warnings if location != "envelope" else []), "archive_id": "offline-archive"}
    saved = deepcopy(payload)
    agent = FinalAgent([json.dumps(answer)], final_payload=payload)
    builder = service(agent)
    validations, parses = [], []
    original_validate, original_parse = builder._validate_auto_map_candidate, builder._parse_envelope

    def validate(*args):
        missing = original_validate(*args)
        validations.append((args[2].target_attribute, missing))
        return missing

    def parse(raw):
        parses.append(raw)
        return original_parse(raw)

    monkeypatch.setattr(builder, "_validate_auto_map_candidate", validate)
    monkeypatch.setattr(builder, "_parse_envelope", parse)
    _, _, (raw, _, metadata) = invoke(warning_request(), builder=builder)
    result = json.loads(raw)
    mapping = result["data"]["result"]["mappings"]["BILLINGCOUNTRY"]
    assert mapping["source_attributes"] == ["a.X47"] and mapping["confidence_score"] == 0.9
    assert mapping["transformation_classification"] == "direct" and mapping["unmatched_reason"] is None
    assert validations == [("BILLINGCOUNTRY", [])]
    assert len(parses) == len(agent.calls) == 1
    expected = {"code": "agent_warning", "message": literal, "field": None}
    assert result["warnings"].count(expected) == 1
    assert structured in result["warnings"]
    assert any(item["code"] == "agent_warning_invalid" for item in result["warnings"])
    assert all(ApiWarning.model_validate(item) for item in result["warnings"])
    assert metadata["warnings"] == metadata["auto_map_retrieval"]["warnings"] == result["warnings"]
    assert payload == saved and metadata["archive_id"] == "offline-archive"
    assert literal not in caplog.text and "PRIVATE_WARNING" not in json.dumps(result)


@pytest.mark.parametrize("warnings", [
    None, [], "single literal warning", {"message": "singleton warning"}, 23,
    [False, None, 23, ["nested"], {}],
    [{"message": "missing code"}, {"detail": "legacy detail"}],
    [{"code": "valid", "message": "valid", "field": ["bad-field"]}],
    [{"code": {}, "message": ["bad-message"], "field": {"bad": "field"}}],
], ids=["none", "empty", "singleton-string", "singleton-dict", "scalar", "unsupported-entries",
        "legacy-dict", "invalid-field", "nested-fields"])
def test_warning_shapes_are_ancillary_not_schema_repair(warnings):
    agent = FinalAgent([json.dumps(warning_answer(["BILLINGCOUNTRY"], warnings))])
    _, _, (raw, _, metadata) = invoke(warning_request(), agent=agent)
    mapping = json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]
    assert mapping["source_attributes"] == ["a.X47"], mapping
    assert len(agent.calls) == 1
    assert "auto_map_fast_stage_failed" not in {item["code"] for item in metadata["warnings"]}


def test_warning_projection_caps_text_without_mutating_original_transport_payload():
    literal = "  <b>literal</b>\n" + "x" * 3000
    payload = {"warnings": [literal, {"code": "c" * 200, "message": literal, "field": "f" * 500}]}
    saved = deepcopy(payload)
    agent = FinalAgent([answer_for(["BILLINGCOUNTRY"])], final_payload=payload)
    _, _, (raw, _, metadata) = invoke(warning_request(), agent=agent)
    assert json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]["source_attributes"] == ["a.X47"]
    assert {"code": "agent_warning", "message": literal[:2000], "field": None} in metadata["warnings"]
    assert {"code": "c" * 128, "message": literal[:2000], "field": "f" * 256} in metadata["warnings"]
    assert payload == saved


def test_warning_invalid_field_is_none_and_typed_transport_warning_stays_literal():
    from app.schema.contracts import ApiWarning

    typed = ApiWarning(code="typed", message="  <b>literal typed warning</b>  ", field="BILLINGCOUNTRY")
    payload = {"warnings": [typed]}
    answer = warning_answer(["BILLINGCOUNTRY"], [
        {"code": "field_notice", "message": "Keep this warning", "field": {"unsafe": "PRIVATE_FIELD"}},
        {"detail": "Legacy detail"},
    ])
    _, _, (raw, _, metadata) = invoke(warning_request(), FinalAgent([json.dumps(answer)], final_payload=payload))
    assert json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]["source_attributes"] == ["a.X47"]
    assert typed.model_dump(mode="json") in metadata["warnings"]
    assert {"code": "field_notice", "message": "Keep this warning", "field": None} in metadata["warnings"]
    assert {"code": "agent_warning", "message": "Legacy detail", "field": None} in metadata["warnings"]
    assert "PRIVATE_FIELD" not in json.dumps(metadata["warnings"])
    assert payload["warnings"][0] is typed


def test_warning_from_service_parse_is_not_lost_by_raw_envelope_normalization():
    answer = warning_answer(["BILLINGCOUNTRY"], ["Literal warning"])
    answer["data"]["semantic_refresh_status"] = {"invalid": "not-a-bundle"}
    agent = FinalAgent([json.dumps(answer)])
    _, _, (raw, _, metadata) = invoke(warning_request(), agent=agent)
    assert json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]["source_attributes"] == ["a.X47"]
    assert any(item["code"] == "INVALID_AGENT_SEMANTIC_STATUS" for item in metadata["warnings"])
    assert len(agent.calls) == 1


@pytest.mark.parametrize("candidate", [
    {"source_attributes": ["unseen.SECRET"]}, {"confidence_score": 95},
    {"used_learning_ids": ["not-admitted"]},
], ids=["unknown-source", "invalid-schema", "unread-evidence"])
def test_warning_tolerance_never_bypasses_candidate_validation(candidate):
    value = warning_request(2)
    answer = warning_answer(["BILLINGCOUNTRY", "NAME1"], ["Ancillary literal warning"])
    answer["data"]["result"]["mappings"]["NAME1"].update(candidate)
    agent = FinalAgent([json.dumps(answer)])
    _, _, (raw, _, metadata) = invoke(value, agent=agent)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert mappings["BILLINGCOUNTRY"]["source_attributes"] == ["a.X47"]
    if "confidence_score" in candidate:
        # A new, focused format repair must pass the normal validator.
        assert mappings["NAME1"]["source_attributes"] == ["a.X47"]
        assert len(agent.calls) == 2
    else:
        assert mappings["NAME1"]["source_attributes"] == []
        assert mappings["NAME1"]["transformation_classification"] == "unresolved"
        assert len(agent.calls) == 1
    assert "auto_map_fast_stage_failed" not in {item["code"] for item in metadata["warnings"]}


@pytest.mark.parametrize("failure", ["error", "malformed-error", "failed-status", "missing-result"])
def test_warning_tolerance_does_not_accept_failed_envelopes(failure, monkeypatch):
    answer = warning_answer(["BILLINGCOUNTRY"], ["Literal warning", {"message": {"bad": "warning"}}])
    if failure == "error":
        answer["error"] = {"title": "Explicit failure", "status": 500}
    elif failure == "malformed-error":
        answer["error"] = {"message": {"nested": "failure"}, "status": ["not-a-status"]}
    elif failure == "failed-status":
        answer["data"]["status"] = "failed"
    else:
        answer["data"]["result"] = {}
    agent = FinalAgent([json.dumps(answer)] * 2)
    builder = service(agent)
    monkeypatch.setattr(builder, "_validate_auto_map_candidate", lambda *args: pytest.fail("Failed result accepted"))
    _, _, (raw, _, metadata) = invoke(warning_request(), builder=builder)
    assert len(agent.calls) == 2
    assert json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]["source_attributes"] == []
    assert any(item["code"] == "auto_map_fast_stage_failed" for item in metadata["warnings"])


def test_warning_repair_discards_first_answer_and_reuses_only_final_parse(monkeypatch):
    bad = warning_answer(["BILLINGCOUNTRY"], ["warning from rejected answer"])
    bad["data"]["result"] = {}
    good = warning_answer(["BILLINGCOUNTRY"], ["warning from valid answer"])
    agent = FinalAgent([json.dumps(bad), json.dumps(good)])
    builder = service(agent)
    calls, original = [], builder._parse_envelope

    def parse(raw):
        calls.append(raw)
        return original(raw)

    monkeypatch.setattr(builder, "_parse_envelope", parse)
    _, _, (raw, _, metadata) = invoke(warning_request(), builder=builder)
    assert json.loads(raw)["data"]["result"]["mappings"]["BILLINGCOUNTRY"]["source_attributes"] == ["a.X47"]
    assert len(agent.calls) == len(calls) == 2
    assert "warning from rejected answer" not in json.dumps(metadata["warnings"])
    assert any(item["message"] == "warning from valid answer" for item in metadata["warnings"])


def test_parallel_warning_strings_use_same_safe_normalization():
    from tests.unit.core.test_automap_parallel_integration import enabled_service, invoke as parallel_invoke

    warning = "  Legacy parallel literal warning  "
    answer = warning_answer(["NAME0"], [warning, {"code": ["bad"], "message": {"bad": "shape"}}])
    agent = FinalAgent([json.dumps(answer)], final_payload={"warnings": [warning]})
    builder, _ = enabled_service(agent)
    raw, _, metadata = parallel_invoke(builder)
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]
    assert len(agent.calls) == 1
    assert metadata["warnings"].count({"code": "agent_warning", "message": warning, "field": None}) == 1
    assert "parallel_stage_failed" not in {item["code"] for item in metadata["warnings"]}


def test_full_service_warning_billingcountry_is_successful_not_just_counted_unresolved():
    answer = warning_answer(["BILLINGCOUNTRY"], ["Literal coverage warning"])
    builder = service(FinalAgent([json.dumps(answer)]))
    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._should_use_analyst = lambda *args: False
    builder._persist_response_artifact = lambda *args: None
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    response = builder.invoke(prepared_request(warning_request()))
    assert response.error is None and response.data.status == STTMStatus.COMPLETED
    mapping = response.data.result.mappings["BILLINGCOUNTRY"]
    assert mapping.source_attributes == ["a.X47"] and mapping.confidence_score == 0.9
    assert mapping.transformation_classification == "direct" and mapping.unmatched_reason is None
    assert len(builder._agent.calls) == 1
    assert any(item.code == "agent_warning" and item.message == "Literal coverage warning" for item in response.warnings)


def native_failure_builder(transport_harness):
    builder = service(FinalAgent())
    models = []

    def factory(current, req, decision, store, deadline):
        transport_harness.req, transport_harness.store = req, store
        transport_harness.decision = decision
        model = build_native_runtime(transport_harness, deadline=deadline)
        models.append(model)
        return model

    builder._fast_model_runtime_factory = factory
    return builder, models


def test_native_terminal_failure_metadata_survives_batch_and_full_service(transport_harness, caplog):
    secret = "PRIVATE-message-credentials-raw-provider-content"
    transport_harness.state.provider_response = {"role": "assistant", "status": "completed", "content": [
        {"type": "thinking", "thinking": secret}, {"type": "text", "text": secret},
        {"type": secret, "name": secret}]}
    builder, models = native_failure_builder(transport_harness)
    _, _, (raw, thread, payload) = invoke(builder=builder)
    envelope = json.loads(raw)
    diagnostic = payload["auto_map_retrieval"]["auto_map_fast_path"]["fast_diagnostics"]
    assert diagnostic == payload["fast_diagnostics"] == json.loads(json.dumps(models[0].failure_diagnostics))
    assert envelope["meta"]["auto_map_fast_path"]["fast_diagnostics"] == json.loads(json.dumps(diagnostic))
    assert diagnostic["failure_code"] == "terminal_response"
    assert diagnostic["failure_archive_status"] == "acknowledged"
    assert diagnostic["transport"][-1]["response_reason"] == "invalid_content_kind"
    assert diagnostic["transport"][-1]["block_count"] == 3
    assert diagnostic["transport"][-1]["block_types"] == ["text", "thinking", "unknown"]
    assert thread is None and not builder._agent.calls
    assert len(transport_harness.state.models) == payload["auto_map_retrieval"]["model_call_count"] == 1
    assert all(slot["STATE"] == "FREE" for slot in transport_harness.database.slots)
    mapping = envelope["data"]["result"]["mappings"]["NAME0"]
    assert mapping["source_attributes"] == [] and mapping["transformation_classification"] == "unresolved"
    assert "invariant=invalid_content_kind" in caplog.text
    diagnostic["transport"][-1]["block_types"].clear()
    assert models[0].failure_diagnostics["transport"][-1]["block_types"]

    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._should_use_analyst = lambda *args: False
    builder._persist_response_artifact = lambda *args: None
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    response = builder.invoke(prepared_request())
    assert response.error is None and response.data.status == STTMStatus.NEEDS_INPUT
    assert response.data.result.mappings["NAME0"].source_attributes == []
    public = response.model_dump(mode="json")
    assert public["meta"]["auto_map_retrieval"]["auto_map_fast_path"]["fast_diagnostics"]["transport"][-1]["response_reason"] == "invalid_content_kind"
    assert secret not in json.dumps(public) + raw + json.dumps(payload) + caplog.text
    assert len(transport_harness.state.models) == 2


@pytest.mark.parametrize("mode,code,posts", [
    ("lost_ack", "scan_transport_http_read_error", 1), ("thread_lost_ack", "unknown_failure", 0),
    ("release_lost_ack", "unknown_failure", 1), ("unknown_status", "scan_transport_unknown_status", 1),
])
def test_native_failure_metadata_does_not_relabel_or_release_unknown_outcome(transport_harness, mode, code, posts):
    transport_harness.state.mode = mode
    if mode == "release_lost_ack":
        transport_harness.state.provider_response = {"role": "assistant", "status": "completed",
            "content": [{"type": "tool_result", "name": "PRIVATE"}]}
    elif mode == "unknown_status":
        transport_harness.state.provider_response = {"role": "assistant", "status": "running",
            "content": [{"type": "text", "text": "PRIVATE"}]}
    builder, models = native_failure_builder(transport_harness)
    _, _, (raw, _, payload) = invoke(builder=builder)
    diagnostic = payload["auto_map_retrieval"]["auto_map_fast_path"]["fast_diagnostics"]
    assert diagnostic["failure_code"] == code
    assert payload["auto_map_retrieval"]["model_call_count"] == 1
    assert len(transport_harness.state.models) == posts
    assert any(slot["STATE"] in ("HELD", "QUARANTINED") for slot in transport_harness.database.slots)
    if mode == "release_lost_ack":
        assert diagnostic["transport"][-1]["response_reason"] == "invalid_content_kind"
    else:
        assert all(event["response_reason"] is None for event in diagnostic["transport"])
    if mode == "thread_lost_ack":
        assert diagnostic["failure_archive_status"] == "unavailable"
        assert "failure_archive_ref" not in diagnostic
    before = len(transport_harness.wire)
    with pytest.raises(ValueError, match="must not be retried"):
        models[0].run([], 2)
    assert len(transport_harness.wire) == before
    assert "PRIVATE" not in raw + json.dumps(payload)


@pytest.mark.parametrize("runtime_kind", ["declared-test", "spec-mock", "factory-failure"])
def test_failure_metadata_never_trusts_injected_exception_or_mock_attributes(runtime_kind, caplog):
    from unittest.mock import Mock
    from app.core.automap_fast_transport import FastModelRuntime

    error = RuntimeError("PRIVATE exception credentials")
    error.fast_diagnostics = {"failure_code": "PRIVATE injected diagnostic"}
    error.cause_type = "PRIVATE injected cause"
    builder = service(FinalAgent([error]))
    if runtime_kind == "spec-mock":
        model = Mock(spec=FastModelRuntime)
        model.run.side_effect = error
    else:
        model = TestRuntime(builder._agent, time.monotonic() + 100)
    model.failure_diagnostics = error.fast_diagnostics

    def factory(*args):
        if runtime_kind == "factory-failure":
            raise error
        return model

    builder._fast_model_runtime_factory = factory
    _, _, (raw, _, payload) = invoke(builder=builder)
    assert "fast_diagnostics" not in payload
    assert "fast_diagnostics" not in payload["auto_map_retrieval"]["auto_map_fast_path"]
    assert payload["auto_map_retrieval"]["model_call_count"] == int(runtime_kind != "factory-failure")
    assert "PRIVATE" not in raw + json.dumps(payload) + caplog.text


@pytest.mark.parametrize("answers,expected_calls,expected_ms", [
    ([RuntimeError("PRIVATE runtime failure")], 1, 2500),
    (["not json", RuntimeError("PRIVATE repair failure")], 2, 5000),
    (["not json", answer_for(["NAME0"])], 2, 5000),
])
def test_model_failure_timings_count_each_run_once_excluding_factory_and_parsing(monkeypatch, answers, expected_calls, expected_ms):
    clock = [time.monotonic()]
    monkeypatch.setattr("app.core.automap_batch.time.monotonic", lambda: clock[0])

    class TimedAgent(FinalAgent):
        def run_detailed(self, messages, **kwargs):
            clock[0] += 2.5
            return super().run_detailed(messages, **kwargs)

    builder = service(TimedAgent(answers))
    original_parse = builder._parse_envelope

    def parse(raw):
        clock[0] += 4
        return original_parse(raw)

    def factory(current, req, decision, store, deadline):
        clock[0] += 7
        return TestRuntime(builder._agent, deadline)

    builder._parse_envelope = parse
    builder._fast_model_runtime_factory = factory
    _, _, (_, _, payload) = invoke(builder=builder)
    assert payload["auto_map_retrieval"]["model_call_count"] == expected_calls
    assert payload["auto_map_retrieval"]["timings_ms"]["model"] == expected_ms


def failure_metadata_fixture():
    from dataclasses import asdict
    from app.core.automap_scan_transport import (
        DiagnosticBlockType, DiagnosticContentKind, DiagnosticPhase, DiagnosticReason,
        DiagnosticStatus, ScanTransportDiagnostic, TerminalResponseReason,
    )
    from app.core.automap_shards import SnapshotScope

    event = ScanTransportDiagnostic(scope=SnapshotScope("OFFLINE_OWNER", "a" * 64),
        generation="a" * 64, shard_id="b" * 64, phase=DiagnosticPhase.FAILURE,
        http_status=200, status=DiagnosticStatus.COMPLETED, reason=DiagnosticReason.TERMINAL_RESPONSE,
        response_reason=TerminalResponseReason.INVALID_CONTENT_KIND, content_kind=DiagnosticContentKind.LIST,
        block_count=1, block_types=(DiagnosticBlockType.UNKNOWN,),
        request_id="01234567-89ab-cdef-0123-456789abcdef", run_id="123-456")
    return json.loads(json.dumps({"call_index": 1, "job_id": "c" * 32,
        "generation": "a" * 64, "shard_id": "b" * 64, "request_digest": "d" * 64,
        "snapshot_archive_ref": "e" * 64, "request_archive_ref": "f" * 64,
        "failure_code": "terminal_response", "failure_archive_status": "acknowledged",
        "failure_archive_ref": "0" * 64, "transport": [asdict(event)]}))


def test_native_failure_metadata_projection_uses_native_getter_and_whitelisted_plain_values():
    from app.core.automap_batch import _fast_failure_diagnostics
    from app.core.automap_fast_transport import FastModelRuntime

    class OverriddenRuntime(FastModelRuntime):
        @property
        def failure_diagnostics(self):
            pytest.fail("Non-native property was invoked")

    model = OverriddenRuntime.__new__(OverriddenRuntime)
    expected = failure_metadata_fixture()
    model._failure_diagnostics = deepcopy(expected)
    model._failure_diagnostics["raw"] = "PRIVATE top-level payload"
    model._failure_diagnostics["transport"][0]["headers"] = {"Authorization": "PRIVATE"}
    model._failure_diagnostics["transport"][0]["scope"]["token"] = "PRIVATE"
    actual = _fast_failure_diagnostics(model, 1)
    assert actual == expected
    assert type(actual["transport"][0]["response_reason"]) is str
    actual["transport"][0]["block_types"].clear()
    assert model._failure_diagnostics["transport"][0]["block_types"] == ["unknown"]


@pytest.mark.parametrize("mutation", [
    "call-bool", "call-stale", "job", "hash", "archive-ref", "archive-status", "failure-code",
    "transport-mock", "too-many-events", "scope", "generation", "shard", "http-bool", "http-range",
    "count-bool", "count-range", "response-enum", "reason-enum", "status-enum", "content-enum",
    "block-enum", "block-duplicate", "request-id", "run-id",
])
def test_native_failure_metadata_rejects_malformed_dictionary_schema(mutation):
    from unittest.mock import Mock
    from app.core.automap_batch import _fast_failure_diagnostics
    from app.core.automap_fast_transport import FastModelRuntime

    metadata = failure_metadata_fixture()
    event = metadata["transport"][0]
    top_changes = {"call-bool": ("call_index", True), "call-stale": ("call_index", 2),
        "job": ("job_id", "PRIVATE"), "hash": ("request_digest", "PRIVATE"),
        "archive-ref": ("failure_archive_ref", "PRIVATE"), "archive-status": ("failure_archive_status", "PRIVATE"),
        "failure-code": ("failure_code", "PRIVATE"), "transport-mock": ("transport", Mock()),
        "too-many-events": ("transport", [event] * 7)}
    event_changes = {"scope": ("scope", {"owner_id": "PRIVATE\nlog", "snapshot_id": "a" * 64}),
        "generation": ("generation", "0" * 64), "shard": ("shard_id", "0" * 64),
        "http-bool": ("http_status", True), "http-range": ("http_status", 600),
        "count-bool": ("block_count", True), "count-range": ("block_count", 1_000_001),
        "response-enum": ("response_reason", "PRIVATE"), "reason-enum": ("reason", "PRIVATE"),
        "status-enum": ("status", "PRIVATE"), "content-enum": ("content_kind", "PRIVATE"),
        "block-enum": ("block_types", ["PRIVATE"]), "block-duplicate": ("block_types", ["text", "text"]),
        "request-id": ("request_id", "PRIVATE"), "run-id": ("run_id", "PRIVATE")}
    key, value = (top_changes if mutation in top_changes else event_changes)[mutation]
    (metadata if mutation in top_changes else event)[key] = value
    model = FastModelRuntime.__new__(FastModelRuntime)
    model._failure_diagnostics = metadata
    assert _fast_failure_diagnostics(model, 1) is None


def test_failure_metadata_unavailable_archive_never_exposes_unacknowledged_reference():
    from app.core.automap_batch import _fast_failure_diagnostics
    from app.core.automap_fast_transport import FastModelRuntime

    model = FastModelRuntime.__new__(FastModelRuntime)
    model._failure_diagnostics = failure_metadata_fixture()
    model._failure_diagnostics.update(failure_archive_status="unavailable", failure_archive_ref="PRIVATE")
    actual = _fast_failure_diagnostics(model, 1)
    assert actual["failure_archive_status"] == "unavailable"
    assert "failure_archive_ref" not in actual


def test_repair_runtime_failure_drops_previous_success_payload(transport_harness):
    transport_harness.state.answer = "not json"
    calls = []

    def hook(outgoing):
        calls.append(outgoing)
        if len(calls) == 2:
            transport_harness.state.mode = "tool_block"

    transport_harness.state.hook = hook
    builder, _ = native_failure_builder(transport_harness)
    _, _, (_, _, payload) = invoke(builder=builder)
    diagnostic = payload["auto_map_retrieval"]["auto_map_fast_path"]["fast_diagnostics"]
    assert diagnostic["call_index"] == payload["auto_map_retrieval"]["model_call_count"] == 2
    assert diagnostic["failure_code"] == "terminal_response"
    assert "response_archive_ref" not in diagnostic
    assert "model_post_attempts" not in diagnostic
    assert len(transport_harness.state.models) == 2


def test_factory_failure_does_not_charge_a_model_attempt_or_model_time(monkeypatch):
    clock = [time.monotonic()]
    monkeypatch.setattr("app.core.automap_batch.time.monotonic", lambda: clock[0])
    builder = service(FinalAgent())

    def factory(*args):
        clock[0] += 5
        raise ValueError("PRIVATE factory credentials")

    builder._fast_model_runtime_factory = factory
    _, _, (_, _, payload) = invoke(builder=builder)
    assert payload["auto_map_retrieval"]["model_call_count"] == 0
    assert payload["auto_map_retrieval"]["timings_ms"]["model"] == 0
    assert not builder._agent.calls


def test_native_failure_baseexception_is_not_swallowed(transport_harness):
    error = KeyboardInterrupt("PRIVATE interruption")

    def interrupt(outgoing):
        raise error

    transport_harness.state.hook = interrupt
    builder, _ = native_failure_builder(transport_harness)
    with pytest.raises(KeyboardInterrupt) as caught:
        invoke(builder=builder)
    assert caught.value is error
    assert len(transport_harness.state.models) == 1
    assert any(slot["STATE"] == "QUARANTINED" for slot in transport_harness.database.slots)


@pytest.mark.parametrize("invalid_native_metadata", [False, True])
def test_native_failure_ignores_exception_attributes_even_when_getter_metadata_is_invalid(transport_harness, caplog, invalid_native_metadata):
    transport_harness.state.mode = "tool_block"
    builder, models = native_failure_builder(transport_harness)
    original_factory = builder._fast_model_runtime_factory
    caught_errors = []

    def factory(*args):
        model = original_factory(*args)
        original_run = model.run

        def run(*args, **kwargs):
            try:
                return original_run(*args, **kwargs)
            except Exception as error:
                caught_errors.append(error)
                error.fast_diagnostics = {"raw": "PRIVATE injected exception payload"}
                error.cause_type = "PRIVATE injected cause"
                if invalid_native_metadata:
                    model._failure_diagnostics["transport"][-1]["block_count"] = True
                raise

        model.run = run
        return model

    builder._fast_model_runtime_factory = factory
    _, _, (raw, _, payload) = invoke(builder=builder)
    assert len(caught_errors) == len(transport_harness.state.models) == 1
    assert type(caught_errors[0]).__name__ == "TerminalResponseError"
    assert ("fast_diagnostics" in payload) is not invalid_native_metadata
    assert "error_type=TerminalResponseError" in caplog.text
    assert "PRIVATE" not in raw + json.dumps(payload) + caplog.text
    assert models[0]._stop.is_set()
    assert all(slot["STATE"] == "FREE" for slot in transport_harness.database.slots)
