"""Compare agent-generated mapping SQL with a team-authored reference script.

A reference script is what migration engineers run by hand: ``SET`` firm
values, ``USE`` statements, and one final ``WITH ... SELECT``. This module
turns such a script into a runnable query (variables bound, ``IDENTIFIER($x)``
resolved) and builds one read-only SQL statement that measures how closely
an agent's SELECT reproduces it: row counts, key overlap, and per-column
value agreement. Nothing here talks to Snowflake.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp

_VARIABLE = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)")
_SET = re.compile(r"^\s*SET\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$", re.IGNORECASE | re.DOTALL)
_INSERT_HEAD = re.compile(r"^\s*INSERT\s+(?:OVERWRITE\s+)?INTO\s+[^\s(]+\s*", re.IGNORECASE)


@dataclass(frozen=True)
class OutputColumn:
    name: str
    quoted: bool

    @property
    def reference(self) -> str:
        """How a query over this column's relation refers to it."""
        return '"' + self.name.replace('"', '""') + '"' if self.quoted else self.name.upper()


@dataclass
class ReferenceScript:
    variables: dict[str, str]
    query: str
    use_statements: list[str] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)


def _scan(sql: str):
    """Yield ``(kind, text)`` chunks: code, string, or comment (quoted identifiers are code)."""
    i, n, start = 0, len(sql), 0
    while i < n:
        ch, nxt = sql[i], sql[i + 1] if i + 1 < n else ""
        if ch == "'":
            if start < i:
                yield "code", sql[start:i]
            j = i + 1
            while j < n:
                if sql[j] == "\\" and j + 1 < n:
                    j += 2
                    continue
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            yield "string", sql[i:j + 1]
            i = start = j + 1
            continue
        if ch == "$" and nxt == "$":
            end = sql.find("$$", i + 2)
            end = n if end < 0 else end + 2
            if start < i:
                yield "code", sql[start:i]
            yield "string", sql[i:end]
            i = start = end
            continue
        if (ch == "-" and nxt == "-") or (ch == "/" and nxt == "/"):
            end = sql.find("\n", i)
            end = n if end < 0 else end
            if start < i:
                yield "code", sql[start:i]
            yield "comment", sql[i:end]
            i = start = end
            continue
        if ch == "/" and nxt == "*":
            end = sql.find("*/", i + 2)
            end = n if end < 0 else end + 2
            if start < i:
                yield "code", sql[start:i]
            yield "comment", sql[i:end]
            i = start = end
            continue
        i += 1
    if start < n:
        yield "code", sql[start:]


def split_statements(sql: str) -> list[str]:
    """Split on ``;`` outside strings and comments; comments are dropped."""
    statements, current = [], []
    for kind, text in _scan(sql):
        if kind == "comment":
            current.append(" ")
            continue
        if kind == "string":
            current.append(text)
            continue
        parts = text.split(";")
        for index, part in enumerate(parts):
            current.append(part)
            if index < len(parts) - 1:
                statements.append("".join(current).strip())
                current = []
    tail = "".join(current).strip()
    if tail:
        statements.append(tail)
    return [item for item in statements if item]


def _literal(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "''") + "'"


def _unquote(text: str) -> str:
    body = text[1:-1]
    return body.replace("''", "'").replace("\\\\", "\\")


def _evaluate(expression: str, variables: dict[str, str]) -> str | None:
    """Value of a SET right-hand side built from literals, numbers, variables, CONCAT and ``||``."""
    text = expression.strip()
    concat = re.fullmatch(r"CONCAT\s*\((.*)\)", text, re.IGNORECASE | re.DOTALL)
    parts: list[str]
    if concat:
        parts = _split_top_level(concat.group(1), ",")
    else:
        parts = _split_top_level(text, "||")
    values: list[str] = []
    for part in parts:
        part = part.strip()
        if len(part) >= 2 and part[0] == "'" and part[-1] == "'":
            values.append(_unquote(part))
        elif part.startswith("$") and part[1:].upper() in variables:
            values.append(variables[part[1:].upper()])
        elif re.fullmatch(r"-?\d+(?:\.\d+)?", part):
            values.append(part)
        else:
            return None
    return "".join(values)


def _split_top_level(text: str, separator: str) -> list[str]:
    parts, depth, current, i = [], 0, [], 0
    chunks = list(_scan(text))
    for kind, chunk in chunks:
        if kind != "code":
            current.append(chunk)
            continue
        i = 0
        while i < len(chunk):
            if chunk[i] in "(":
                depth += 1
            elif chunk[i] == ")":
                depth -= 1
            if depth == 0 and chunk.startswith(separator, i):
                parts.append("".join(current))
                current = []
                i += len(separator)
                continue
            current.append(chunk[i])
            i += 1
    parts.append("".join(current))
    return parts


def script_variables(statements: list[str], overrides: dict[str, str] | None = None) -> dict[str, str]:
    """``SET`` values in script order, keyed upper-case; overrides win and feed later SETs."""
    forced = {key.upper(): value for key, value in (overrides or {}).items()}
    variables: dict[str, str] = dict(forced)
    for statement in statements:
        match = _SET.match(statement)
        if not match:
            continue
        name = match.group(1).upper()
        if name in forced:
            continue
        value = _evaluate(match.group(2), variables)
        if value is not None:
            variables[name] = value
    return variables


def variable_names(statements: list[str]) -> dict[str, str]:
    """Upper-case variable name -> its spelling in the script's first ``SET``."""
    names: dict[str, str] = {}
    for statement in statements:
        match = _SET.match(statement)
        if match:
            names.setdefault(match.group(1).upper(), match.group(1))
    return names


def bind_variables(sql: str, variables: dict[str, str]) -> tuple[str, list[str]]:
    """Replace ``IDENTIFIER($x)`` with the identifier and ``$x`` with a literal, outside strings."""
    unresolved: list[str] = []
    out: list[str] = []
    for kind, text in _scan(sql):
        if kind != "code":
            out.append(text)
            continue

        def identifier(match: re.Match[str]) -> str:
            name = match.group(1).upper()
            if name not in variables:
                unresolved.append(match.group(1))
                return match.group(0)
            return variables[name]

        text = re.sub(r"IDENTIFIER\s*\(\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*\)", identifier, text, flags=re.IGNORECASE)

        def literal(match: re.Match[str]) -> str:
            name = match.group(1).upper()
            if name not in variables:
                unresolved.append(match.group(1))
                return match.group(0)
            return _literal(variables[name])

        out.append(_VARIABLE.sub(literal, text))
    return "".join(out), sorted(set(unresolved))


def reference_query(script: str, *, overrides: dict[str, str] | None = None) -> ReferenceScript:
    """The script's final query with its SET values bound, plus its USE statements (bound)."""
    statements = split_statements(script)
    variables = script_variables(statements, overrides)
    queries = [item for item in statements if re.match(r"^\s*\(?\s*(WITH|SELECT)\b", item, re.IGNORECASE)]
    if not queries:
        raise ValueError("The reference script has no WITH/SELECT statement.")
    query, unresolved = bind_variables(queries[-1], variables)
    uses = []
    for statement in statements:
        if re.match(r"^\s*USE\s+(DATABASE|SCHEMA)\b", statement, re.IGNORECASE):
            bound, missing = bind_variables(statement, variables)
            uses.append(bound)
            unresolved.extend(missing)
    return ReferenceScript(variables=variables, query=query, use_statements=uses,
                           unresolved=sorted(set(unresolved)))


def select_of(sql: str) -> str:
    """The SELECT of a mapping statement: drops ``INSERT INTO t (cols)`` and a trailing ``;``."""
    text = sql.strip().rstrip(";").strip()
    head = _INSERT_HEAD.match(text)
    if not head:
        return text
    rest = text[head.end():]
    if rest.startswith("("):
        depth = 0
        for index, ch in enumerate(rest):
            depth += ch == "("
            depth -= ch == ")"
            if depth == 0:
                return rest[index + 1:].strip()
    return rest.strip()


@dataclass
class LearningScript:
    sql: str
    firm_values: dict[str, str]
    source_tables: list[str]


# SET variables that only name tables or schemas; they are resolved, not learned as firm values.
_STRUCTURAL_VARIABLE = re.compile(r"(SCHEMA|DATABASE|TABLE)$", re.IGNORECASE)


def prepare_for_learning(
    script: str, *, source_schema: str, overrides: dict[str, str] | None = None,
    table_overrides: dict[str, str] | None = None,
) -> LearningScript:
    """The script's final query in the shape FIR learns from.

    Table variables (``IDENTIFIER($UserMasterTable)``) are resolved and bare
    table names are qualified with ``source_schema``, so every relation is a
    real source; ``table_overrides`` (FQN -> FQN) points shared lookups at the
    project's copies. Firm values stay ``$Name`` so they are learned as
    firm-value bindings rather than as this firm's literals.
    """
    statements = split_statements(script)
    variables = script_variables(statements, overrides)
    queries = [item for item in statements if re.match(r"^\s*\(?\s*(WITH|SELECT)\b", item, re.IGNORECASE)]
    if not queries:
        raise ValueError("The script has no WITH/SELECT statement.")
    query = queries[-1]
    out: list[str] = []
    for kind, text in _scan(query):
        if kind == "code":
            text = re.sub(
                r"IDENTIFIER\s*\(\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*\)",
                lambda m: variables.get(m.group(1).upper(), m.group(0)), text, flags=re.IGNORECASE,
            )
        out.append(text)
    tree = sqlglot.parse_one("".join(out), read="snowflake")
    _expand_final_star(tree)
    cte_names = {cte.alias_or_name.upper() for cte in tree.find_all(exp.CTE)}
    database, schema = source_schema.split(".", 1)
    remap = {key.upper(): value.upper() for key, value in (table_overrides or {}).items()}
    sources: set[str] = set()
    for table in tree.find_all(exp.Table):
        if table.name.upper() in cte_names and not table.args.get("db"):
            continue
        if not table.args.get("db"):
            table.set("db", exp.to_identifier(schema))
            table.set("catalog", exp.to_identifier(database))
        elif not table.args.get("catalog"):
            table.set("catalog", exp.to_identifier(database))
        fqn = ".".join(part.upper() for part in (table.catalog, table.db, table.name))
        schema_key = ".".join(part.upper() for part in (table.catalog, table.db))
        if fqn not in remap and schema_key in remap:
            # A schema override moves every table of that schema.
            remap[fqn] = f"{remap[schema_key]}.{table.name.upper()}"
        if fqn in remap:
            new_catalog, new_db, new_name = remap[fqn].split(".")
            table.set("catalog", exp.to_identifier(new_catalog))
            table.set("db", exp.to_identifier(new_db))
            table.set("this", exp.to_identifier(new_name))
            fqn = remap[fqn]
        sources.add(fqn)
    forced = {k.upper() for k in (overrides or {})}
    spelled = variable_names(statements)
    firm_values = {
        spelled.get(name, name): value for name, value in variables.items()
        if not _STRUCTURAL_VARIABLE.search(name) and name not in forced
    }
    return LearningScript(sql=tree.sql(dialect="snowflake", pretty=True), firm_values=firm_values,
                          source_tables=sorted(sources))


def _expand_final_star(tree: exp.Expression) -> None:
    """``SELECT * FROM cte`` -> the CTE's named output columns, so each target column is visible."""
    if not isinstance(tree, exp.Select) or len(tree.expressions) != 1 or not isinstance(tree.expressions[0], exp.Star):
        return
    source = tree.args.get("from") or tree.args.get("from_")
    table = source.this if source is not None else None
    if not isinstance(table, exp.Table) or table.args.get("db") or tree.args.get("joins"):
        return
    cte = next((item for item in tree.find_all(exp.CTE) if item.alias_or_name.upper() == table.name.upper()), None)
    inner = cte.this if cte is not None else None
    if not isinstance(inner, exp.Select) or any(isinstance(item, exp.Star) for item in inner.expressions):
        return
    columns = []
    for item in inner.expressions:
        identifier = item.args.get("alias") if isinstance(item, exp.Alias) else item.this if isinstance(item, exp.Column) else None
        if not isinstance(identifier, exp.Identifier):
            return
        columns.append(exp.column(exp.Identifier(this=identifier.name, quoted=identifier.quoted), table=table.alias_or_name))
    tree.set("expressions", columns)


def output_columns(sql: str) -> list[OutputColumn]:
    """Names of the outermost SELECT's output columns, with whether each is case-sensitive."""
    tree = sqlglot.parse_one(sql, read="snowflake")
    # A set operation reports its first branch's names, as Snowflake does.
    select = tree if isinstance(tree, exp.Select) else tree.find(exp.Select)
    columns: list[OutputColumn] = []
    for item in select.expressions if select is not None else []:
        if isinstance(item, exp.Alias):
            identifier = item.args.get("alias")
            columns.append(OutputColumn(identifier.name, bool(identifier.quoted)))
        elif isinstance(item, exp.Column):
            identifier = item.this
            columns.append(OutputColumn(identifier.name, bool(getattr(identifier, "quoted", False))))
        elif isinstance(item, exp.Star):
            continue
        else:
            columns.append(OutputColumn(item.alias_or_name, False))
    return columns


def column_key(name: str) -> str:
    """Case, separator and ``XX``-prefix insensitive name used to pair reference and target columns."""
    key = re.sub(r"[^A-Z0-9]", "", name.upper())
    stripped = key.lstrip("X")
    if len(key) - len(stripped) >= 2 and len(stripped) >= 3:
        return stripped
    return key


def pair_columns(
    reference: list[OutputColumn], agent: list[OutputColumn], explicit: dict[str, str] | None = None,
) -> tuple[list[tuple[OutputColumn, OutputColumn]], list[OutputColumn], list[OutputColumn]]:
    """``(pairs, reference_only, agent_only)``; ``explicit`` maps reference name -> agent name."""
    by_key: dict[str, OutputColumn] = {}
    for column in agent:
        by_key.setdefault(column_key(column.name), column)
    explicit_upper = {key.upper(): value.upper() for key, value in (explicit or {}).items()}
    agent_by_upper = {column.name.upper(): column for column in agent}
    pairs, used = [], set()
    reference_only = []
    for column in reference:
        match = None
        if column.name.upper() in explicit_upper:
            match = agent_by_upper.get(explicit_upper[column.name.upper()])
        match = match or by_key.get(column_key(column.name))
        if match is None or match.name.upper() in used:
            reference_only.append(column)
            continue
        used.add(match.name.upper())
        pairs.append((column, match))
    agent_only = [column for column in agent if column.name.upper() not in used]
    return pairs, reference_only, agent_only


def _norm(expression: str) -> str:
    return f"NULLIF(TRIM(TO_VARCHAR({expression})), '')"


def comparison_sql(
    reference_sql: str,
    agent_sql: str,
    pairs: list[tuple[OutputColumn, OutputColumn]],
    *,
    reference_key: OutputColumn | None,
    agent_key: OutputColumn | None,
    reference_key_expr: str | None = None,
    agent_key_expr: str | None = None,
) -> str:
    """One SELECT returning a single VARIANT ``RESULT`` with row, key and per-column agreement."""
    ref_key = reference_key_expr or (reference_key.reference if reference_key else "NULL")
    agt_key = agent_key_expr or (agent_key.reference if agent_key else "NULL")
    ref_cols = ",\n    ".join(f"{_norm(ref.reference)} AS R{i}" for i, (ref, _) in enumerate(pairs)) or "NULL AS R_NONE"
    agt_cols = ",\n    ".join(f"{_norm(agt.reference)} AS A{i}" for i, (_, agt) in enumerate(pairs)) or "NULL AS A_NONE"
    column_objects = []
    for i, (ref, agt) in enumerate(pairs):
        column_objects.append(
            "OBJECT_CONSTRUCT("
            f"'reference', {_literal(ref.name)}, 'agent', {_literal(agt.name)}, "
            f"'reference_non_null', (SELECT COUNT(R{i}) FROM r), "
            f"'agent_non_null', (SELECT COUNT(A{i}) FROM a), "
            f"'matched_rows', (SELECT COUNT(*) FROM j), "
            f"'value_match', (SELECT ROUND(AVG(IFF(EQUAL_NULL(R{i}, A{i}), 1, 0)), 4) FROM j), "
            f"'distinct_overlap', (SELECT ROUND(COUNT(*) / NULLIF((SELECT COUNT(*) FROM "
            f"(SELECT R{i} AS V FROM r WHERE R{i} IS NOT NULL UNION SELECT A{i} FROM a WHERE A{i} IS NOT NULL)), 0), 4) "
            f"FROM (SELECT R{i} AS V FROM r WHERE R{i} IS NOT NULL INTERSECT SELECT A{i} FROM a WHERE A{i} IS NOT NULL)), "
            f"'reference_sample', (SELECT ARRAY_AGG(V) FROM (SELECT DISTINCT R{i} AS V FROM r WHERE R{i} IS NOT NULL LIMIT 5)), "
            f"'agent_sample', (SELECT ARRAY_AGG(V) FROM (SELECT DISTINCT A{i} AS V FROM a WHERE A{i} IS NOT NULL LIMIT 5))"
            ")"
        )
    columns = ",\n    ".join(column_objects) if column_objects else ""
    join_columns = ", ".join([f"r.R{i}" for i in range(len(pairs))] + [f"a.A{i}" for i in range(len(pairs))]) or "r.K"
    return f"""WITH ref AS (
{reference_sql}
),
agt AS (
{agent_sql}
),
r AS (
  SELECT {_norm(ref_key)} AS K,
    {ref_cols}
  FROM ref
),
a AS (
  SELECT {_norm(agt_key)} AS K,
    {agt_cols}
  FROM agt
),
r1 AS (SELECT * FROM r WHERE K IS NOT NULL QUALIFY ROW_NUMBER() OVER (PARTITION BY K ORDER BY K) = 1),
a1 AS (SELECT * FROM a WHERE K IS NOT NULL QUALIFY ROW_NUMBER() OVER (PARTITION BY K ORDER BY K) = 1),
j AS (SELECT {join_columns} FROM r1 AS r JOIN a1 AS a ON r.K = a.K)
SELECT OBJECT_CONSTRUCT(
  'reference_rows', (SELECT COUNT(*) FROM r),
  'agent_rows', (SELECT COUNT(*) FROM a),
  'reference_keys', (SELECT COUNT(*) FROM r1),
  'agent_keys', (SELECT COUNT(*) FROM a1),
  'reference_duplicate_keys', (SELECT COUNT(*) - COUNT(DISTINCT K) FROM r WHERE K IS NOT NULL),
  'agent_duplicate_keys', (SELECT COUNT(*) - COUNT(DISTINCT K) FROM a WHERE K IS NOT NULL),
  'matched_keys', (SELECT COUNT(*) FROM j),
  'reference_key_sample', (SELECT ARRAY_AGG(K) FROM (SELECT K FROM r1 ORDER BY K LIMIT 3)),
  'agent_key_sample', (SELECT ARRAY_AGG(K) FROM (SELECT K FROM a1 ORDER BY K LIMIT 3)),
  'columns', ARRAY_CONSTRUCT(
    {columns}
  )
) AS RESULT"""


def key_column(columns: list[OutputColumn], preferred: str | None = None) -> OutputColumn | None:
    """The column that carries the record's legacy key (``Legacy_ID__c`` style) unless told otherwise."""
    if preferred:
        for column in columns:
            if column.name.upper() == preferred.upper():
                return column
    for column in columns:
        if column_key(column.name) in {"LEGACYIDC", "LEGACYIDPC"}:
            return column
    return None


def summarize(target: str, result: dict[str, Any], reference_only: list[str], agent_only: list[str]) -> dict[str, Any]:
    """Headline numbers for one target from a comparison ``RESULT``."""
    columns = list(result.get("columns") or [])
    matched = int(result.get("matched_keys") or 0)
    agreeing = [c for c in columns if (c.get("value_match") or 0) >= 0.95] if matched else []
    return {
        "target": target,
        "reference_rows": result.get("reference_rows"),
        "agent_rows": result.get("agent_rows"),
        "key_overlap": round(matched / max(1, int(result.get("reference_keys") or 0)), 4),
        "paired_columns": len(columns),
        "columns_agreeing": len(agreeing),
        "mean_value_match": round(sum(float(c.get("value_match") or 0) for c in columns) / len(columns), 4)
        if columns and matched else None,
        "mean_distinct_overlap": round(sum(float(c.get("distinct_overlap") or 0) for c in columns) / len(columns), 4)
        if columns else None,
        "reference_only_columns": reference_only,
        "agent_only_columns": agent_only,
    }
