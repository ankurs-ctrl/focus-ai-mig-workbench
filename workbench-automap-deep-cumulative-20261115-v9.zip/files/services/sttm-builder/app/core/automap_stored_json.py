"""Lossless bounded storage encoding for existing durable Auto-map artifacts.

This encoding never reaches a model. It avoids writing repeated catalogs and
receipt dictionaries as multi-megabyte VARIANT objects on every job checkpoint.
"""
import base64
import zlib
import lzma
import json
from copy import deepcopy

from app.core.automap_json import encoded, digest, load_json

ENCODING = 'xz-json-v1'
MAX_BYTES = 16_000_000
_KEYS = {'storage_encoding','content_sha256','uncompressed_bytes','content'}


def store_json(value, *, public_keys=(), force=False, preserve_order=False):
    text = (json.dumps(value,ensure_ascii=False,separators=(',', ':'),allow_nan=False)
            if preserve_order else encoded(value)).encode('utf-8')
    if len(text) < 16384 and not force:
        return value
    if len(text) > MAX_BYTES:
        raise ValueError('Auto-map artifact exceeds the existing storage allowance')
    return {'storage_encoding':ENCODING,'content_sha256':digest(value),
        'uncompressed_bytes':len(text),'content':base64.b64encode(lzma.compress(text,preset=3)).decode('ascii'),
        **{key:value[key] for key in public_keys}}


def load_stored(value):
    if not isinstance(value, dict) or value.get('storage_encoding') not in {ENCODING,'zlib-json-v1'}:
        return value
    size = value.get('uncompressed_bytes')
    if type(size) is not int or not 0 < size <= MAX_BYTES:
        raise ValueError('Invalid stored Auto-map artifact size')
    content = value.get('content')
    if not isinstance(content, str) or len(content) > (MAX_BYTES * 4 // 3 + 1024):
        raise ValueError('Invalid stored Auto-map artifact encoding')
    try:
        compressed = base64.b64decode(content, validate=True)
        legacy=value['storage_encoding']=='zlib-json-v1'
        decoder = zlib.decompressobj() if legacy else lzma.LZMADecompressor(memlimit=64*1024*1024)
        raw = decoder.decompress(compressed, size + 1) if legacy else decoder.decompress(compressed,max_length=size+1)
        if len(raw) != size or not decoder.eof or decoder.unused_data or (legacy and decoder.unconsumed_tail):
            raise ValueError('Invalid stored Auto-map artifact boundary')
        restored = load_json(raw.decode('utf-8'))
    except (zlib.error, lzma.LZMAError, UnicodeError, ValueError) as error:
        raise ValueError('Invalid stored Auto-map artifact') from error
    if digest(restored) != value.get('content_sha256'):
        raise ValueError('Stored Auto-map artifact integrity mismatch')
    if any(key not in restored or encoded(restored[key]) != encoded(value[key]) for key in value.keys() - _KEYS):
        raise ValueError('Stored Auto-map artifact summary mismatch')
    return restored


CONTEXT_FIELDS = ('semantic_context', 'learning_context', 'execution_context',
                  'workspace_context', 'relation_graph')


def context_storage(value, *, restore=False):
    """Keep SQL-visible identities/results while storing large context atomically.

    Exact section receipts protect these projections too. This representation is
    storage-only and must be expanded before request validation or model input.
    """
    value = deepcopy(value)
    if not isinstance(value, dict):
        return value
    context = value.get('context')
    if isinstance(context, dict):
        for key in CONTEXT_FIELDS:
            if key in context and context[key] is not None:
                context[key] = load_stored(context[key]) if restore else store_json(context[key])
    meta = value.get('meta')
    if isinstance(meta, dict):
        for key in ('_automap_resolution_plan', '_automap_fast_handoff'):
            if key in meta and meta[key] is not None:
                meta[key] = load_stored(meta[key]) if restore else store_json(meta[key])
    return value


def job_section_storage(sections, *, restore=False):
    result = dict(sections)
    for key in ('request_envelope', 'response'):
        if key in result:
            result[key] = context_storage(result[key], restore=restore)
    if isinstance(result.get('partial_responses'), list):
        result['partial_responses'] = [{**item, 'response':context_storage(item['response'], restore=restore)}
            if isinstance(item, dict) and 'response' in item else item for item in result['partial_responses']]
    return result
