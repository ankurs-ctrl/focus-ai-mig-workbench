"""Approval-gated retained-source replay through the canonical FIR collectors.

No CLI auto-execution. Call prepare/replay_batch/cutover explicitly with a reviewed
manifest digest. The fresh stream is established before the baseline is read.
The old offset is never dropped or replaced. Expired deletes are unrecoverable.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from scripts.fir_recovery_preflight import identifier

CONTRACTS = {
    "STM_FIR_WORKBENCH_EVENTS": ("TBL_WORKBENCH_FIR_EVENTS", "EVENT_ID", True, "_collect_ui_events"),
    "STM_FIR_STTM_VERSIONS": ("TBL_STTM_VERSIONS", "VERSION_ID", True, "_collect_publish_feedback"),
    "STM_FIR_CLIENT_SQL_ASSETS": ("TBL_WORKBENCH_CLIENT_SQL_ASSETS", "SQL_ASSET_ID", False, "_collect_document_upload_feedback"),
    "STM_FIR_WORKBENCH_FEEDBACK": ("TBL_WORKBENCH_FEEDBACK", "FEEDBACK_ID", False, "_collect_explicit_feedback"),
    "STM_FIR_STTM_ATTRIBUTES": ("TBL_STTM_ATTRIBUTES", "ATTRIBUTE_ID", False, "_collect_mapping_feedback"),
    "STM_FIR_DERIVED_SOURCES": ("TBL_DERIVED_SOURCES", "DERIVED_SOURCE_ID", False, "_collect_derived_source_feedback"),
    "STM_FIR_SEM_TABLE_VIEWS": ("SEM_TABLE_VIEWS", "VIEW_ID", False, "_collect_semantic_feedback"),
    "STM_FIR_CONVERSATION_TURNS": ("TBL_WORKBENCH_CONVERSATION_TURNS", "TURN_ID", True, "_collect_conversation_feedback"),
    "STM_FIR_RECOMMENDATION_OUTCOMES": ("TBL_FIR_RECOMMENDATION_OUTCOMES", "OUTCOME_ID", True, "_collect_recommendation_outcomes"),
    "STM_FIR_LEARNING_WORK_ITEMS": ("TBL_FIR_LEARNING_WORK_ITEMS", "WORK_ITEM_ID", False, "durable_signal"),
    "STM_FIR_360_CHANGES": ("TBL_AGENT_FIR_360", "FIR_RECORD_ID", False, "durable_signal"),
    "STM_FIR_CONTEXT_EVIDENCE": ("TBL_FIR_CONTEXT_EVIDENCE", "EVIDENCE_CONTEXT_ID", True, "durable_signal"),
    "STM_FIR_RECOMMENDATIONS": ("TBL_FIR_AGENT_RECOMMENDATIONS", "AGENT_RECOMMENDATION_ID", True, "durable_signal"),
    "STM_FIR_PRECOMPUTE_SEM_TABLE_VIEWS": ("SEM_TABLE_VIEWS", "VIEW_ID", False, "durable_signal"),
    "STM_FIR_PRECOMPUTE_SEM_COLUMN_VIEWS": ("SEM_COLUMN_VIEWS", "VIEW_ID", False, "durable_signal"),
    "STM_FIR_PRECOMPUTE_SEMANTIC_VERSIONS": ("TBL_SEMANTIC_VIEW_VERSIONS", "VERSION_ID", True, "durable_signal"),
}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()


def manifest(namespace, stream, *, role, recovery_id, source_verified=False, consumers_suspended=False):
    parts = namespace.split(".")
    if len(parts) != 2:
        raise ValueError("Expected DATABASE.SCHEMA")
    for part in parts:
        identifier(part)
    identifier(role)
    if stream not in CONTRACTS or not re.fullmatch(r"[A-F0-9]{12}", recovery_id):
        raise ValueError("Unsupported source or recovery identity")
    source, key, append, collector = CONTRACTS[stream]
    plan = dict(namespace=namespace, stream=stream, source=source, key=key, append_only=append,
                collector=collector, role=role, recovery_id=recovery_id,
                replay_mode="durable_signal" if collector == "durable_signal" else
                    "snapshot_observation" if stream in {"STM_FIR_STTM_ATTRIBUTES", "STM_FIR_DERIVED_SOURCES", "STM_FIR_SEM_TABLE_VIEWS"} else "retained_evidence",
                source_verified=source_verified, consumers_suspended=consumers_suspended,
                history_gap="Expired deletes and intermediate updates cannot be recovered",
                collector_sha256=hashlib.sha256(_collector_path().read_bytes()).hexdigest())
    return {**plan, "manifest_id": digest(plan)}


def recover_reviewed_uat(session):
    """One-time UAT recovery authorized for the reviewed 2026-10-22 release.

    Preserve every old stream and durable checkpoint. Never resume consumers.
    """
    namespace = "FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT.SCH_STTM_METADATA"
    role = "FFP_HDP_DLAB_MIG_WORKBENCH_DB_DEPLOY_ROLE_UAT"
    recovery_id = "20261022F1A1"
    plans = [manifest(namespace, stream, role=role, recovery_id=recovery_id,
                      source_verified=True, consumers_suspended=True) for stream in CONTRACTS]
    # Establish all source boundaries before any canonical replay changes them.
    for plan in plans:
        streams = session.sql(f"SHOW STREAMS IN SCHEMA {namespace}").collect()
        original = next((row for row in streams if row["name"] == plan["stream"]), None)
        if original and str(original["stale"]).lower() != "true":
            if original["comment"] != "FIR_RECOVERY:" + plan["manifest_id"]:
                raise RuntimeError("Unreviewed healthy stream; refusing automatic recovery")
            continue
        prepare(session, plan, approval=plan["manifest_id"])
    summaries = []
    for plan in plans:
        phase = _require_phase(session, plan, {"CAPTURING", "SPOOLED", "CUTOVER_PENDING", "CUTOVER"})
        if phase in {"CAPTURING", "SPOOLED"}:
            capture_overlap(session, plan, approval=plan["manifest_id"])
            for _ in range(100):
                result = replay_batch(session, plan, approval=plan["manifest_id"], limit=100)
                if result["status"] == "conflict":
                    raise RuntimeError(f"Retained-source conflict: {plan['stream']}; checkpoint preserved")
                if result["completed"] == 0:
                    break
            else:
                raise RuntimeError("Replay budget exhausted; checkpoint preserved")
        result = cutover(session, plan, approval=plan["manifest_id"])
        summaries.append({"stream": plan["stream"], **result})
        print(json.dumps(summaries[-1]))
    return summaries


def _collector_path():
    return Path(__file__).resolve().parents[1] / "infra/snowflake/fir_system/procedures/sp-fir-collect-feedback.sql"


def _gate(session, plan, approval):
    expected = manifest(plan["namespace"], plan["stream"], role=plan["role"], recovery_id=plan["recovery_id"],
                        source_verified=plan["source_verified"], consumers_suspended=plan["consumers_suspended"])
    if plan != expected or approval != plan["manifest_id"]:
        raise PermissionError("Exact current manifest approval required")
    if plan["source_verified"] is not True or plan["consumers_suspended"] is not True:
        raise PermissionError("Verify source contract and suspend all consumers before recovery")
    actual = session.sql("SELECT CURRENT_ROLE() AS ROLE_NAME").collect()[0]["ROLE_NAME"]
    if actual != plan["role"]:
        raise PermissionError("Recovery role mismatch")
    tasks = session.sql(f"SHOW TASKS IN SCHEMA {plan['namespace']}").collect()
    fir_tasks = [row for row in tasks if str(row['name']).startswith('TSK_FIR_')]
    if not fir_tasks or any(str(row['state']).lower() != 'suspended' for row in fir_tasks):
        raise PermissionError("Visible FIR tasks must all remain suspended throughout recovery")
    streams = session.sql(f"SHOW STREAMS IN SCHEMA {plan['namespace']}").collect()
    original = next((row for row in streams if row['name'] == plan['stream']), None)
    archive = next((row for row in streams if row['name'] == plan['stream'] + '_OLD_' + plan['recovery_id']), None)
    reviewed = archive if archive is not None else original
    expected_source = f"{plan['namespace']}.{plan['source']}"
    if reviewed is None or str(reviewed['table_name']).upper() != expected_source:
        raise PermissionError("Live stream source does not match the approved contract")
    if archive is None and str(reviewed['stale']).lower() != 'true':
        raise PermissionError("Healthy streams are preserved; recovery is only for stale offsets")


def _names(plan):
    prefix = f'{plan["namespace"]}.FIR_REC_{plan["recovery_id"]}_{plan["stream"][8:]}'
    return prefix + "_CAPTURE", prefix + "_ROWS", prefix + "_CHECKPOINT"


def prepare(session, plan, *, approval):
    """DDL is deliberately outside transactions; restart never replaces objects.

    SHOW_INITIAL_ROWS supplies a baseline at creation, plus subsequent changes.
    The durable spool is created before capture can ever be consumed.
    """
    _gate(session, plan, approval)
    capture, spool, checkpoint = _names(plan)
    source = f'{plan["namespace"]}.{plan["source"]}'
    session.sql(f"CREATE TABLE IF NOT EXISTS {spool} (ROW_KEY VARCHAR, ROW_HASH VARCHAR, PAYLOAD VARIANT, ACTION VARCHAR, DONE BOOLEAN DEFAULT FALSE)").collect()
    session.sql(f"CREATE TABLE IF NOT EXISTS {checkpoint} (MANIFEST_ID VARCHAR, PHASE VARCHAR, UPDATED_AT TIMESTAMP_LTZ)").collect()
    session.sql(f"CREATE STREAM IF NOT EXISTS {capture} ON TABLE {source} APPEND_ONLY = {str(plan['append_only']).upper()} SHOW_INITIAL_ROWS = TRUE").collect()
    session.sql(f"MERGE INTO {checkpoint} t USING (SELECT ? AS MANIFEST_ID) s ON t.MANIFEST_ID=s.MANIFEST_ID WHEN NOT MATCHED THEN INSERT VALUES (s.MANIFEST_ID, 'CAPTURING', CURRENT_TIMESTAMP())", params=[approval]).collect()
    return {"capture": capture, "spool": spool, "checkpoint": checkpoint, "cutover": False}


def capture_overlap(session, plan, *, approval, max_capture_rows=10000):
    """Atomically spool a complete offset before advancing it, with a hard cap.

    Never use LIMIT while consuming a stream: that would discard its remaining
    rows. Large offsets fail closed for a separately reviewed capacity budget.
    """
    _gate(session, plan, approval)
    if not 1 <= max_capture_rows <= 10000:
        raise ValueError("Capture budget must be 1-10000")
    capture, spool, checkpoint = _names(plan)
    _require_phase(session, plan, {"CAPTURING", "SPOOLED"})
    session.sql("BEGIN TRANSACTION").collect()
    try:
        session.sql(f"UPDATE {checkpoint} SET UPDATED_AT=CURRENT_TIMESTAMP() WHERE MANIFEST_ID=?", params=[approval]).collect()
        _require_phase(session, plan, {"CAPTURING", "SPOOLED"})
        count = int(session.sql(f"SELECT COUNT(*) AS CNT FROM {capture}").collect()[0]["CNT"])
        if count > max_capture_rows:
            raise RuntimeError("Capture exceeds approved budget; offset was not advanced")
        session.sql(f"INSERT INTO {spool} (ROW_KEY, ROW_HASH, PAYLOAD, ACTION) SELECT TO_VARCHAR({plan['key']}), SHA2(TO_JSON(OBJECT_CONSTRUCT_KEEP_NULL(*)), 256), OBJECT_CONSTRUCT_KEEP_NULL(*), METADATA$ACTION FROM {capture}").collect()
        session.sql(f"UPDATE {checkpoint} SET PHASE='SPOOLED', UPDATED_AT=CURRENT_TIMESTAMP() WHERE MANIFEST_ID=?", params=[approval]).collect()
        session.sql("COMMIT").collect()
        return count
    except Exception:
        session.sql("ROLLBACK").collect()
        raise


def _collector(plan):
    # Only the fixed repository handler pinned by the reviewed manifest is loaded.
    if plan["collector"] == "durable_signal":
        # The source table already IS the durable work inventory. Replaying it
        # as feedback would invent evidence. Cutover seeds a new readiness signal.
        return lambda session, result, retained_rows: 0
    text = _collector_path().read_text(encoding="utf-8")
    body = text.split("$$", 2)[1].replace("__STTM_METADATA_NAMESPACE__", plan["namespace"])
    scope = {}
    exec(compile(body, str(_collector_path()), "exec"), scope)
    return scope[plan["collector"]]


def _require_phase(session, plan, allowed):
    _, _, checkpoint = _names(plan)
    rows = session.sql(f"SELECT MANIFEST_ID, PHASE FROM {checkpoint}").collect()
    if len(rows) != 1 or rows[0]["MANIFEST_ID"] != plan["manifest_id"] or rows[0]["PHASE"] not in allowed:
        raise RuntimeError("Recovery checkpoint missing, conflicting, or in an incompatible phase")
    return rows[0]["PHASE"]


def replay_batch(session, plan, *, approval, limit=10):
    _gate(session, plan, approval)
    if not 1 <= limit <= 100:
        raise ValueError("Replay budget must be 1-100")
    _, spool, checkpoint = _names(plan)
    _require_phase(session, plan, {"SPOOLED"})
    # Any changed immutable identity or mutable source state needs human review;
    # never select one side arbitrarily and turn it into historical approval.
    conflict_predicate = "ROW_KEY IS NULL" if plan['collector'] == 'durable_signal' else "ROW_KEY IS NULL OR COUNT(DISTINCT ROW_HASH)>1 OR COUNT_IF(ACTION<>'INSERT' OR ACTION IS NULL)>0"
    conflicts = session.sql(f"SELECT ROW_KEY FROM {spool} GROUP BY ROW_KEY HAVING {conflict_predicate} LIMIT 100").collect()
    if conflicts:
        return {"status": "conflict", "keys": [row["ROW_KEY"] for row in conflicts], "completed": 0}
    rows = session.sql(f"SELECT ROW_KEY, ROW_HASH, PAYLOAD FROM {spool} WHERE NOT DONE QUALIFY ROW_NUMBER() OVER (PARTITION BY ROW_KEY ORDER BY ROW_HASH)=1 ORDER BY ROW_KEY LIMIT {limit}").collect()
    collector = _collector(plan)
    completed = 0
    for row in rows:
        payload = row["PAYLOAD"]
        if isinstance(payload, str):
            payload = json.loads(payload)
        skip = (plan["stream"] == "STM_FIR_CLIENT_SQL_ASSETS" and payload.get("STATUS") != "active") or (
            plan["stream"] == "STM_FIR_DERIVED_SOURCES" and payload.get("IS_ACTIVE") is not True
        ) or (plan["stream"] == "STM_FIR_SEM_TABLE_VIEWS" and payload.get("STATUS") != "ACTIVE") or (
            plan["stream"] == "STM_FIR_CONVERSATION_TURNS" and payload.get("ROLE") != "assistant"
        )
        # A baseline carries no trustworthy insert/update event classification.
        payload = {**payload, "METADATA$ISUPDATE": False}
        if plan["stream"] == "STM_FIR_STTM_VERSIONS" and not payload.get("PUBLISHED_DATETIME"):
            raise RuntimeError("Version lacks publication timestamp")
        session.sql("BEGIN TRANSACTION").collect()
        try:
            # Serialize canonical MERGE + completion on the recovery checkpoint.
            # Recheck after acquiring the DML lock because another worker may
            # have finished a row selected before this transaction began.
            session.sql(f"UPDATE {checkpoint} SET UPDATED_AT=CURRENT_TIMESTAMP() WHERE MANIFEST_ID=?", params=[approval]).collect()
            unfinished = session.sql(f"SELECT COUNT(*) AS CNT FROM {spool} WHERE ROW_KEY=? AND ROW_HASH=? AND NOT DONE", params=[row["ROW_KEY"], row["ROW_HASH"]]).collect()[0]["CNT"]
            if not unfinished:
                session.sql("COMMIT").collect()
                continue
            result = {"errors": []}
            if not skip:
                collector(session, result, retained_rows=[payload])
            if result["errors"]:
                raise RuntimeError("Canonical collector failed; replay checkpoint unchanged")
            session.sql(f"UPDATE {spool} SET DONE=TRUE WHERE ROW_KEY=? AND ROW_HASH=?", params=[row["ROW_KEY"], row["ROW_HASH"]]).collect()
            session.sql("COMMIT").collect()
            completed += 1
        except Exception:
            session.sql("ROLLBACK").collect()
            raise
    return {"status": "replayed", "completed": completed, "search_visibility_verified": False}


def cutover(session, plan, *, approval):
    """Keep old offset as an archive; DDL failures never automatically resume tasks.

    The replacement uses the reviewed capture offset (including any new writes)
    rather than the current time. Consumers must remain suspended throughout.
    """
    _gate(session, plan, approval)
    capture, spool, checkpoint = _names(plan)
    phase = _require_phase(session, plan, {"SPOOLED", "CUTOVER_PENDING", "CUTOVER"})
    if phase == "CUTOVER":
        return {"status": "cutover", "activation_authorized": False}
    pending = int(session.sql(f"SELECT COUNT(*) AS CNT FROM {spool} WHERE NOT DONE").collect()[0]["CNT"])
    if pending:
        raise RuntimeError("Replay is incomplete; cutover blocked")
    # CREATE OR REPLACE would destroy the only surviving old-offset evidence.
    archive = f'{plan["namespace"]}.{plan["stream"]}_OLD_{plan["recovery_id"]}'
    original = f'{plan["namespace"]}.{plan["stream"]}'
    session.sql(f"UPDATE {checkpoint} SET PHASE='CUTOVER_PENDING', UPDATED_AT=CURRENT_TIMESTAMP() WHERE MANIFEST_ID=?", params=[approval]).collect()
    streams = session.sql(f"SHOW STREAMS IN SCHEMA {plan['namespace']}").collect()
    names = {str(row['name']): row for row in streams}
    archive_name = archive.rsplit('.', 1)[1]
    if archive_name not in names:
        if plan['stream'] not in names:
            raise RuntimeError("Original stream missing; cutover requires review")
        session.sql(f"ALTER STREAM {original} RENAME TO {archive}").collect()
    elif plan['stream'] in names:
        replacement = names[plan['stream']]
        replacement = replacement.as_dict() if hasattr(replacement, 'as_dict') else replacement
        if replacement.get('comment') != 'FIR_RECOVERY:' + approval or str(replacement.get('table_name')).upper() != f"{plan['namespace']}.{plan['source']}":
            raise RuntimeError("Unrecognized replacement stream; cutover blocked")
        session.sql(f"UPDATE {checkpoint} SET PHASE='CUTOVER', UPDATED_AT=CURRENT_TIMESTAMP() WHERE MANIFEST_ID=?", params=[approval]).collect()
        return {"status": "cutover", "archived_stream": archive, "activation_authorized": False}
    initial = " SHOW_INITIAL_ROWS = TRUE" if plan['collector'] == 'durable_signal' else ""
    session.sql(f"CREATE STREAM {original} ON TABLE {plan['namespace']}.{plan['source']} AT (STREAM => '{capture}') APPEND_ONLY = {str(plan['append_only']).upper()}{initial} COMMENT = 'FIR_RECOVERY:{approval}'").collect()
    session.sql(f"UPDATE {checkpoint} SET PHASE='CUTOVER', UPDATED_AT=CURRENT_TIMESTAMP() WHERE MANIFEST_ID=?", params=[approval]).collect()
    return {"status": "cutover", "archived_stream": archive, "activation_authorized": False}
