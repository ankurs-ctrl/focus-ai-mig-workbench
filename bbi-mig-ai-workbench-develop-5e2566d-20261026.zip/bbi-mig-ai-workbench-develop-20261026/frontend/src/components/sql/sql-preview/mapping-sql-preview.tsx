'use client';

import { useState, type ReactNode } from 'react';
import { AiaBox, AiaButton, AiaCircularProgress, AiaPaper } from '@/components/ui';

import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { SqlPreviewHeader } from './sql-preview-header';
import { SqlPreviewSqlBlock } from './sql-preview-sql-block';
import { SQL_PREVIEW_WORKSPACE_BG } from './sql-preview-styles';

export type MappingSqlPreviewProps = {
  sqlTitle?: string;
  targetLabel?: string | null;
  mappedCount: number;
  tableCount: number;
  filterCount: number;
  joinCount: number;
  generatedSql: string;
  suggestions?: string[];
  onCompile?: () => void;
  compileDisabled?: boolean;
  compileLoading?: boolean;
  onCopyGeneratedSql?: () => void | Promise<void>;
  onOptimize?: () => void;
  optimizeDisabled?: boolean;
  optimizeLoading?: boolean;
  onRunPreview?: () => void;
  runDisabled?: boolean;
  runLoading?: boolean;
  runLabel?: string;
  readOnly?: boolean;
  statusPanel?: ReactNode;
  editableSql?: string;
  onEditableSqlChange?: (sql: string) => void;
  onReviewSqlChanges?: () => void | boolean | Promise<void | boolean>;
  reviewSqlChangesLoading?: boolean;
};

export function MappingSqlPreview({
  sqlTitle = 'Generated SQL',
  targetLabel,
  mappedCount,
  tableCount,
  filterCount,
  joinCount,
  generatedSql,
  suggestions,
  onCompile,
  compileDisabled = false,
  compileLoading = false,
  onCopyGeneratedSql,
  onOptimize,
  optimizeDisabled,
  optimizeLoading = false,
  onRunPreview,
  runDisabled = true,
  runLoading = false,
  runLabel = 'Run Preview',
  readOnly = false,
  statusPanel,
  editableSql,
  onEditableSqlChange,
  onReviewSqlChanges,
  reviewSqlChangesLoading = false,
}: MappingSqlPreviewProps) {
  const [editing, setEditing] = useState(false);
  return (
    <AiaBox
      sx={{
        flex: 1,
        width: '100%',
        minWidth: 0,
        minHeight: 0,
        overflow: 'hidden',
        backgroundColor: SQL_PREVIEW_WORKSPACE_BG,
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <AiaPaper
        elevation={0}
        sx={{
          height: '100%',
          borderRadius: 0,
          backgroundColor: SQL_PREVIEW_WORKSPACE_BG,
          color: '#e2e8f0',
          border: 'none',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <SqlPreviewHeader
          title={sqlTitle}
          subtitle={targetLabel ?? undefined}
          stats={[
            { id: 'mapped', label: `${mappedCount} MAPPED` },
            { id: 'tables', label: `${tableCount} TABLES` },
            { id: 'filters', label: `${filterCount} FILTERS` },
            { id: 'joins', label: `${joinCount} JOINS` },
          ]}
          copyValue={generatedSql}
          onCopy={onCopyGeneratedSql}
          actions={
            !readOnly ? (
              <>
                <AiaButton
                  data-tour={TOUR_TARGETS.sttmEditSql}
                  variant="outlined"
                  size="small"
                  onClick={() => {
                    if (!editing) {
                      // Seed a new draft from the one canonical query shown in
                      // the preview. Parsed imports and row edits use this same
                      // surface, so there is no second hidden SQL document.
                      if (!(editableSql ?? '').trim()) {
                        onEditableSqlChange?.(generatedSql);
                      }
                      setEditing(true);
                    }
                  }}
                  disabled={editing}
                  customColor="#e2e8f0"
                  customBorderColor="rgba(148,163,184,0.28)"
                >
                  {editing ? 'Editing SQL' : 'Edit SQL'}
                </AiaButton>
                <AiaButton
                  data-tour={TOUR_TARGETS.sttmCompileValidate}
                  variant="outlined"
                  size="small"
                  disabled={
                    editing
                      ? reviewSqlChangesLoading || !(editableSql ?? '').trim()
                      : compileDisabled || compileLoading
                  }
                  onClick={() => {
                    if (editing) {
                      void Promise.resolve(onReviewSqlChanges?.()).then((applied) => {
                        if (applied !== false) setEditing(false);
                      });
                    } else {
                      onCompile?.();
                    }
                  }}
                  startIcon={
                    compileLoading || reviewSqlChangesLoading
                      ? <AiaCircularProgress size={14} color="inherit" />
                      : undefined
                  }
                  customColor="#e2e8f0"
                  customBorderColor="rgba(148,163,184,0.28)"
                >
                  {editing
                    ? reviewSqlChangesLoading
                      ? 'Compiling & validating...'
                      : 'Compile, Validate & Sync'
                    : compileLoading
                      ? 'Compiling & validating...'
                      : 'Compile & Validate'}
                </AiaButton>
                {onOptimize ? (
                  <AiaButton
                    data-tour={TOUR_TARGETS.sttmOptimizeSql}
                    variant="outlined"
                    size="small"
                    disabled={optimizeDisabled}
                    onClick={onOptimize}
                    startIcon={optimizeLoading ? <AiaCircularProgress size={14} color="inherit" /> : undefined}
                    customColor="#e2e8f0"
                    customBorderColor="rgba(148,163,184,0.28)"
                  >
                    {optimizeLoading ? 'Optimizing...' : 'Optimize SQL'}
                  </AiaButton>
                ) : null}
                <AiaButton
                  data-tour={TOUR_TARGETS.sttmRunPreview}
                  variant="outlined"
                  size="small"
                  disabled={runDisabled}
                  onClick={onRunPreview}
                  startIcon={runLoading ? <AiaCircularProgress size={14} color="inherit" /> : undefined}
                  customColor="#e2e8f0"
                  customBorderColor="rgba(148,163,184,0.28)"
                >
                  {runLabel}
                </AiaButton>
              </>
            ) : null
          }
        />

        {statusPanel ? (
          <AiaBox
            sx={{
              flexShrink: 0,
              maxHeight: '40%',
              overflow: 'auto',
              px: 2.5,
              pt: 2.25,
              pb: 0.5,
              '&:empty': { display: 'none' },
            }}
          >
            {statusPanel}
          </AiaBox>
        ) : null}

        <AiaBox sx={{ flex: 1, minHeight: 0, overflow: 'auto', px: 2.5, py: 2.25 }}>
          <SqlPreviewSqlBlock
            sql={editing ? editableSql ?? generatedSql : generatedSql}
            readOnly={!editing}
            onChange={onEditableSqlChange}
            suggestions={suggestions}
            emptyText="-- Select source tables to generate SQL."
          />
        </AiaBox>
      </AiaPaper>
    </AiaBox>
  );
}
