# V19 recovery release — deployment and verification

This develop integration retains the team’s current CodeCommit develop changes through `61d8f54`, including Abhishek’s project custom-rule library and SQL-editor improvements (`57c140a`, `61d8f54`). It merges our V19 Auto-map/Deep fixes, originally tested on V18 (`709de8b`), without replacing the team’s work. Git merged the two shared files—the mapping store and metadata bootstrap—without textual conflicts.

The **full develop source ZIP** contains all tracked source files from the merged develop commit recorded in its outer `MANIFEST.json`. It includes the latest team changes and the complete Auto-map/Deep implementation. Environment files, credentials, installed dependencies, builds, caches and historical ZIP artifacts are excluded. Scripts are included because bootstrap and deployment scripts changed. The two public Zscaler CA certificates required by Docker builds are included; private keys are excluded. Earlier cumulative V19 artifacts retain their original provenance.

The 182.1-second native Auto-map acceptance was run against the V19 implementation before this develop merge. Merged frontend/backend regression results are recorded separately in `V19-RESULTS.json`.

## Apply and deploy

1. Back up the application checkout. Copy the full ZIP's `files/` contents into the repository root; its manifest records the exact merged CodeCommit develop commit. Preserve all existing environment files, secrets and authentication configuration. The three `infra/snowflake/env/parallel*.json` files are public, reviewed deployment profiles; they contain no credentials.
2. Build with the included Python dependency lock and frontend dependency lock. Run the existing metadata bootstrap against the existing metadata namespace using the deployment's normal authentication. It includes the project bootstrap lock, Deep metadata/migrations, evidence tool/context table and ownership-only Auto-map operations table. The existing Deep migration chain is now installed automatically after the FIR schema, with metadata-qualified procedure bodies, stage checks and preservation of existing procedure/view grants. Conditional column additions inspect existing columns before executing to avoid Snowflake repeat-install ambiguity while retaining original defaults and values. Existing valid fences, operational owners and uncertain calls are retained. No slot reset or replacement is required. Where the Snowflake pipeline already owns semantic assets, retain the deployment's `--preserve-semantic-registry` setting; this release does not require semantic regeneration.
3. Bootstrap now synchronizes the three mapping agents' instructions. For source mapping and transformation it installs the named read-only `ReadAutoMapEvidence` tool. Existing agent identities, grants, models, budgets and unrelated tools are preserved. Default LIVE and LAST versions are supported and verified after update. A named pinned default or unpublished LIVE edits stops synchronization so the existing version-promotion process can preserve those changes. Do not bypass that check by replacing the agent.
4. Run `python scripts/verify_mapping_agent_specs.py`. Deploy matching frontend, API, Auto-map workers and Deep workers from this full source release to every replica. Deep supervisor and tool instructions live in the Python runtime (including `services/sttm-builder/app/agent_runtime/deepagents_runtime.py`), so they deploy with the Deep worker image; they are not a separate Snowflake Deep-agent YAML. Deploying only YAML or only the frontend will not install those instructions. The deployment scripts compute the two existing instruction-hash settings from the delivered specifications; the dedicated Auto-map worker now receives them too. Install the evidence procedure/tool before advertising its hash capability.
5. Keep existing caller OAuth/session store, decryption and refresh configuration available to the Deep worker through the established secure deployment. Worker housekeeping continues to use its service identity; user data/model work continues to use the initiating user's delegated identity. No second user login, copied token, new environment variable or broader source/target grant is introduced.

Existing ownership-only Auto-map mode is retained (`AUTOMAP_SHARED_CAPACITY_LIMIT=false` in the durable UAT profile). Legacy admission objects and outstanding operations are preserved for recovery. This release does not increase execution capacity, context ceilings or production timeouts, and does not generate semantic assets.

For local review use `./start-ai-workbench-dev.sh`. The additive `--env-file /absolute/path/to/existing/config` option reads an existing configuration without modifying or copying it. Frontend remains on port 3000 and backend on port 8000.

## Corrections in this overlay

- Citation handles such as `src:ACCOUNTS.ADDRESS1_COUNTRY` resolve uniquely against authorized selected outputs, including dependencies and declared SQL references. Ambiguous instances remain explicit rather than binding to the wrong table.
- Working SQL previews again use readable, collision-safe aliases, including the Copy action. Compiled and preview SQL were checked against Snowflake; internal binding identities are preserved for save/reopen.
- Auto-map completion and SQL messages use “mappings” and “results”. Evidence coverage notes do not create a new business approval step. Unsupported positive historical citations do not suppress otherwise checked current SQL or earn historical confidence. Actual correction overrides remain authorized.
- Cached/cold preparation retains the server-owned execution handoff; physical and CTE bindings use exact authorized output references.
- Independent worker caller sessions prevent one shared Snowpark session from serializing concurrent batches. In-process worker requests no longer repeatedly start/stop application lifespan services.
- Frozen request receipts survive the worker boundary without repeating the full snapshot in its acknowledgement. Population checks avoid treating unrelated saved SELECT projections as every target's dependencies.
- A verified native terminal-result receipt is reused instead of archiving the same result a second time. Terminal persistence uses the already reserved finalization window; uncertain model submissions are not replayed.
- The specialist receives the original user requirements, exact current bindings and relevant frozen evidence. Its returned recipe gets its own exact dependency verification rather than inheriting only the source agent's receipts. Unsupported source-agent citations do not become authority for a repaired specialist result.
- Completed custom expressions retain their stage identity, survive candidate ranking and can replace stale source-stage options. A specialist-repaired classification no longer remains invalid because its source agent previously emitted the label `derived`.
- Progress counts unique requested target outcomes separately from supported proposals and legacy confidence/review thresholds. Backend counts do not claim that the browser applied a proposal; row application/Undo/edit protection remain frontend responsibilities.
- Parent packet readiness and dispatch status are committed together, avoiding a redundant full-state write. Parent evidence handoff, packing and persistence timings are recorded separately, including failed measured phases. SQL MERGE fencing uses scalar parameters from the same immutable record rather than repeatedly folding a multi-megabyte JSON payload in its predicates.
- Actual prepared-cache request time is reported separately from historical cache-build time. Successful as well as failed model calls retain bounded phase timings and actual POST/response counts.
- Recovery logs distinguish provider inspection from terminal-result persistence and retain bounded HTTP/native error codes. Deadline exhaustion does not restart the same worker operation. Original failure diagnostics survive permitted worker retries; uncertain provider calls are reconciled rather than submitted again.
- Deep repository, heartbeat, checkpoint and trace connections retain managed facades. A native internal-session expiry replaces the service connection and retries only a known safe read, with ownership revalidation. Ambiguous writes/commits and uncertain model work require reconciliation; they never trigger blind replay or another user's credentials.

## Test evidence and limits

Read `V19-RESULTS.json` for measured outcomes, timings and remaining acceptance limits. Offline regressions, native Snowflake acceptance and browser/SPCS acceptance are distinct. A passing unit suite does not establish client SPCS performance or mounted service-token rotation.

No failed client job is replayed and no client mapping, project or source/target row is changed by these checks. Existing older result files describe their original deliveries; they must not be used to claim the latest Auto-map performance gate passed.

The isolated Loan Income checks use the existing UAT deployment’s parallel-worker/control-session profile locally, with ownership-only operation tracking. They are not evidence of a new client SPCS deployment. The native FIR search service was unavailable/not authorized in this DEV account; available semantic/catalog and published precedent evidence were retained. Missing-YAML behavior is tested separately.

The address NULL regression executes six Snowflake VALUES cases: missing first line preserves later lines, blank lines are omitted, and all-missing input returns SQL NULL. This is an expression robustness check, not a replay of the client’s unavailable historical model response.

## Local results available

The application remains available on `http://localhost:3000`, with API on port 8000. Open `/sttm/builder/7901/mapping` for the new isolated acceptance mapping. All 33 composed results were saved and reopened with their exact bindings, expressions, numeric confidence and selected candidate identity. They compile together and return the checked preview values. Original mapping 7601 was not changed.

The final single 33-target job (`f80829f7-ce12-512d-831a-3c1214a1bf22`) returned 33 supported mappings with positive numeric confidence in **182.1 seconds** from the warm request through observed completion. It used 10 source submissions and 6 specialist submissions, with zero source repair calls. All 33 results from that job compiled together, returned the expected three preview rows, and survived save/reopen in mapping 7901. Frontend reducer replay applied all 33 to blank rows, replaced all 33 existing rows with Undo, and replaced 12/applied 21 in the partial case.

The earlier Direct/custom validation contradiction is corrected before source repair scheduling. A custom expression mislabeled Direct reaches the specialist rather than consuming more source calls. Exact completed-rule receipts also restore their current custom classification during repeat delivery, while retaining current compiler, binding and Value checks.

The final warm evidence request took 1.25 seconds. Parent evidence handoff was 0.64 seconds, packet packing 14.46 seconds, prepared-envelope persistence 3.26 seconds and ready-packet persistence 4.59 seconds. The first model phase still exceeded the 20-second startup target. The single final 33-target sample passed the overall 200-second target; three 40-target runs and live client SPCS acceptance are not claimed. Earlier slower/partial samples remain in the evidence instead of being discarded.

Original pre-merge backend suite: **5,366 passed, 31 skipped**. Frontend: **562 passed**. TypeScript, bootstrap release parity and agent-spec manifest checks passed. See the JSON evidence for source/specialist counts, overlap, timings and acceptance limits.

## Merged develop verification

The merged source passed **5,390 backend tests across the suite and socket-enabled rerun (31 skipped)**, **563 frontend tests**, TypeScript checking, shell syntax, agent-spec hash verification and offline bootstrap parity. Integration also fixes existing develop TypeScript errors in custom-rule loading and preprocessing SQL editing, and updates the reopen-test harness to use the actual library helper. Team functionality is retained.

The actual Deep bootstrap chain (12 migrations including run knowledge) was applied **twice** to a new isolated DEV metadata schema. Both passes completed, all five procedures and two stages were present, the zero-event fenced procedure returned correctly, and sentinel lease generation, lock revision, published receipt and pinned conversation values survived. No model calls, client changes or execution-capacity rows were created. This checks repeatable installation, not client SPCS/OAuth execution.

Run the existing bootstrap with your existing database, metadata schema, role, warehouse and OAuth/service settings. No new environment variable is introduced by this integration. Preserve client environment files and secrets. The package's `START-HERE.txt` and `MANIFEST.json` describe full-source installation and exclusions.

## Latest team integration and revised package scope

The revised ZIP includes Kalyani's manual-CTE visual-builder correction (`aa313cf`) and Ajith's table-selection tabs/data preview (`94427cf`, `24f6b94`) and side-panel history (`7c16569`). The latter feature branches were not yet on develop when fetched and have been integrated explicitly. Tour and history conflicts were resolved by retaining current custom-rule tours, server-backed Quick/Deep history, user/project scope and saved logical-conversation continuity.

The combined frontend passed **567 tests** and TypeScript checking. Backend and native evidence above predates these frontend-only integrations; no new native/SPCS/browser run is claimed for them.

Per the revised delivery request, only these five root scripts are included: `bootstrap_sttm_metadata_infra.py`, `build_cumulative_overlay.py`, `deploy_spcs_client_direct.sh`, `deploy_spcs_client_snow.ps1`, and `start_sttm_backend_local.sh`. Other root scripts are unchanged by our fixes and are omitted from this ZIP. Apply `files/` over the existing application checkout and retain its omitted scripts and environment settings. The outer manifest records the final develop commit, exact included files and exclusions. The agent/bootstrap deployment instructions above remain applicable.
