"""Conflicting or malformed model references stay isolated to their target."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from app.core.automap_batch import invoke_batch
from app.core.automap_source_format import normalize_source_objects
from tests.unit.core.test_automap_fast_batch import FinalAgent, prepared_request, service
from tests.unit.core.test_automap_fast_context import fast_payload, plan_for, unpack


def source(column="X47", **changes):
    return {"source_column": column, "source_table": "D.S.A", "sql_qualifier": "a", **changes}


def mapping(attributes):
    return {"source_attributes": attributes, "confidence_score": .9,
            "transformation_classification": "direct"}


def envelope(rows):
    return {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": rows}}}


@pytest.mark.parametrize("column", ['b.X47', 'a.X47', 'D.S.A.X47', '"b"."X47"'])
def test_object_requires_unqualified_column_without_silently_dropping_qualifier(column):
    _, plan = plan_for()
    original = envelope({"NAME0": mapping([source(column)])})
    result = normalize_source_objects(original, plan)
    assert result == original
    assert isinstance(result["data"]["result"]["mappings"]["NAME0"]["source_attributes"][0], dict)


@pytest.mark.parametrize("field", ["source_column", "source_table", "sql_qualifier"])
@pytest.mark.parametrize("invalid", ["(", '"unterminated'])
@pytest.mark.parametrize("bad_first", [True, False])
def test_parse_error_keeps_valid_sibling_and_original_envelope(field, invalid, bad_first):
    _, plan = plan_for(fast_payload(2))
    rows = {"NAME0": mapping([source()]), "NAME1": mapping([source(**{field: invalid})])}
    if bad_first:
        rows = dict(reversed(list(rows.items())))
    original = envelope(rows)
    before = deepcopy(original)
    result = normalize_source_objects(original, plan)["data"]["result"]["mappings"]
    assert result["NAME0"]["source_attributes"] == ['a."X47"']
    assert isinstance(result["NAME1"]["source_attributes"][0], dict)
    assert original == before


@pytest.mark.parametrize("field", ["source_attributes", "candidate_source_attributes"])
def test_malformed_candidate_or_selected_object_is_not_silently_dropped(field):
    _, plan = plan_for(fast_payload(2))
    bad = mapping([source()])
    bad[field] = [source("(")]
    result = normalize_source_objects(envelope({"NAME0": mapping([source()]), "NAME1": bad}), plan)
    rows = result["data"]["result"]["mappings"]
    assert rows["NAME0"]["source_attributes"] == ['a."X47"']
    assert isinstance(rows["NAME1"][field][0], dict)


@pytest.mark.parametrize("bad_source", [source("b.X47"), source("("), source(sql_qualifier="("),
                                       source(source_table='"unterminated')])
@pytest.mark.parametrize("repair_succeeds", [True, False])
def test_worker_repairs_only_bad_target_and_preserves_grounded_sibling(bad_source, repair_succeeds):
    first = envelope({"NAME0": mapping([source()]), "NAME1": mapping([bad_source])})
    second = envelope({"NAME1": mapping(["a.X47"] if repair_succeeds else [bad_source])})
    builder = service(FinalAgent([json.dumps(first), json.dumps(second)]))
    raw, _, _ = invoke_batch(builder, prepared_request(fast_payload(2)), SimpleNamespace())
    rows = json.loads(raw)["data"]["result"]["mappings"]
    assert rows["NAME0"]["source_attributes"] == ['a."X47"']
    assert len(builder._agent.calls) == 2
    repair = unpack(builder._agent.calls[1][0])
    assert [item["target_attribute"] for item in repair["data"]["attributes"]] == ["NAME1"]
    if repair_succeeds:
        assert rows["NAME1"]["source_attributes"] == ["a.X47"]
    else:
        assert rows["NAME1"]["source_attributes"] == []
        assert rows["NAME1"]["transformation_classification"] == "unresolved"


@pytest.mark.parametrize("column", ["X47", "x47", '"X47"'])
def test_valid_unqualified_identifiers_still_normalize(column):
    _, plan = plan_for()
    result = normalize_source_objects(envelope({"NAME0": mapping([source(column)])}), plan)
    assert result["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ['a."X47"']


def test_dot_inside_quoted_column_is_not_mistaken_for_qualifier():
    plan = SimpleNamespace(prepared=SimpleNamespace(records=[SimpleNamespace(
        kind="source_column", record_id="one", body={"eligible": True, "name": "X.47", "column": '"X.47"',
            "binding": {"relation_id": "a", "sql_qualifier": "a"}})]),
        record_group={"one": "group"}, selected={"group"}, store=SimpleNamespace(nodes={}))
    result = normalize_source_objects(envelope({"NAME0": mapping([
        {"source_column": '"X.47"', "sql_qualifier": "a"}])}), plan)
    assert result["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ['a."X.47"']
