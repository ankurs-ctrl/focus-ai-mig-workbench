from __future__ import annotations

import inspect
import threading
from types import SimpleNamespace

import pytest


def test_existing_project_accepts_authenticated_legacy_username_owner() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.Lock()
    state = {"project_id": "2701", "actor_user_id": "1", "snowflake_username": "ANKURS"}
    handler._projects = SimpleNamespace(get_project=lambda _id: SimpleNamespace(created_by="ankurs"))
    assert handler.create_project(state) == {"project_id": "2701"}

    handler._projects = SimpleNamespace(get_project=lambda _id: SimpleNamespace(created_by="OTHER_USER"))
    with pytest.raises(PermissionError, match="not owned"):
        handler.create_project(state)


def test_source_mapper_reads_workbench_mappings_when_generic_decisions_are_empty() -> None:
    import json
    from app.agent_tools.specialists import CortexSpecialistAdapter, SpecialistRequest

    request = SpecialistRequest(
        run_id="run-1", step_id="map-1", project_id="project-1", sttm_id="sttm-1",
        snapshot_id="draft:sttm-1", target_contract={"target_table": "DB.TARGET.HH"},
        target_columns=["BILLINGCITY"], allowed_source_tables=["DB.SOURCE.ADDRESSES"],
        allowed_source_columns={"DB.SOURCE.ADDRESSES": ["CITY"]},
        actor_user_id="1", effective_role="EDITOR", tenant_id="default",
    )
    workbench = {"data": {"result": {"mappings": {"DB.TARGET.HH.BILLINGCITY": {
        "source_attributes": ["ADDRESSES.CITY"], "confidence_score": 0.65,
        "confidence_reason": "Current source and precedent", "mapping_mode": "source",
    }}}}}
    parsed = CortexSpecialistAdapter._parse_source_mapping_response(
        {"decisions": []}, json.dumps(workbench), request
    )
    assert len(parsed.decisions) == 1
    assert parsed.decisions[0].decision == "mapped"
    assert parsed.decisions[0].source_columns == ["DB.SOURCE.ADDRESSES.CITY"]
    assert parsed.review_items[0]["blocking"] is False


def test_source_mapper_retains_verified_low_confidence_candidate_for_review() -> None:
    import json
    from app.agent_tools.specialists import CortexSpecialistAdapter, SpecialistRequest

    request = SpecialistRequest(
        run_id="run-1", step_id="map-1", project_id="project-1", sttm_id="sttm-1",
        snapshot_id="draft:sttm-1", target_contract={"target_table": "DB.TARGET.HH"},
        target_columns=["BILLINGCITY"], allowed_source_tables=["DB.SOURCE.ADDRESSES"],
        allowed_source_columns={"DB.SOURCE.ADDRESSES": ["CITY"]},
        actor_user_id="1", effective_role="EDITOR", tenant_id="default",
    )
    workbench = {"data": {"result": {"mappings": {"BILLINGCITY": {
        "source_attributes": [], "candidate_source_attributes": ["ADDRESSES.CITY"],
        "confidence_score": 0.45, "unmatched_reason": "Business applicability needs review",
        "mapping_mode": "source",
    }}}}}
    parsed = CortexSpecialistAdapter._parse_source_mapping_response(None, json.dumps(workbench), request)
    assert parsed.decisions[0].decision == "mapped"
    assert parsed.decisions[0].source_columns == ["DB.SOURCE.ADDRESSES.CITY"]
    assert "Provisional" in parsed.decisions[0].decision_reason
    assert parsed.review_items[0]["blocking"] is False


def test_verified_plan_candidates_become_provisional_executable_drafts() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    rows = [
        {"target_column": "BILLINGCITY", "status": "unresolved", "source_columns": []},
        {"target_column": "RECORDTYPEID", "status": "unresolved", "source_columns": []},
        {"target_column": "COMPLEX_FIELD", "status": "unresolved", "source_columns": []},
    ]
    evidence = [
        {"target_column": "BILLINGCITY", "source_columns": ["DB.SOURCE.ADDRESSES.CITY"],
         "transformation": "Direct", "confidence": 0.45, "evidence_id": "precedent:city"},
        {"target_column": "RECORDTYPEID", "constant_value": "01241000001IBjjAAO",
         "transformation": "Value", "confidence": 0.6, "evidence_id": "project:record_type"},
        {"target_column": "COMPLEX_FIELD", "source_columns": ["DB.SOURCE.ADDRESSES.CITY", "DB.SOURCE.ADDRESSES.ZIP"],
         "transformation": "", "confidence": 0.4},
    ]
    WorkbenchWorkflowHandlers._promote_verified_plan_candidates(
        rows, evidence, {"DB.SOURCE.ADDRESSES": {"columns": ["CITY", "ZIP"]}},
        [{"name": "BILLINGCITY", "type": "VARCHAR"}, {"name": "RECORDTYPEID", "type": "VARCHAR"}],
    )
    assert rows[0]["status"] == "draft"
    assert rows[0]["source_columns"] == ["DB.SOURCE.ADDRESSES.CITY"]
    assert rows[0]["confidence"] == 0.45
    assert rows[1]["status"] == "draft"
    assert rows[1]["expression"] == "'01241000001IBjjAAO'"
    assert rows[2]["status"] == "unresolved"

from app.agent_evaluation import AgentEvaluationHarness
from app.agent_runs.models import (
    AgentActor,
    AgentRunEvent,
    RunCancelRequest,
    RunCreateRequest,
    RunStatus,
    ToolResult,
)
from app.agent_runs.contracts import (
    AgentInvocationResultV1,
    AgentInvocationV1,
    MappingContextPackageV1,
    StoredSemanticContextReference,
)


def test_legacy_approved_plan_hash_survives_optional_partial_coverage_field() -> None:
    import hashlib
    import json
    from app.agent_runs.contracts import MigrationPlanArtifactV1

    payload = {
        "plan_id": "plan-1", "run_id": "run-1", "thread_id": "run-1", "original_request": "Draft mapping",
        "normalized_intent": "Draft mapping", "context_hash": "context-1",
        "source_preparation": {"driving_source": "DB.S.T"},
        "auto_map": {"target_columns": ["ID"]},
    }
    baseline = MigrationPlanArtifactV1.model_validate(payload).model_dump(mode="json")
    from copy import deepcopy
    legacy = deepcopy({key: value for key, value in baseline.items() if key not in {"plan_hash", "created_at"}})
    legacy["auto_map"].pop("allow_partial_coverage")
    old_hash = hashlib.sha256(json.dumps(legacy, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()
    baseline["auto_map"].pop("allow_partial_coverage")
    baseline["plan_hash"] = old_hash
    assert MigrationPlanArtifactV1.model_validate(baseline).plan_hash == old_hash
from app.agent_tools.capability_registry import CapabilityRegistry
from app.agent_tools.specialists import (
    complete_transformation_response,
    CortexSpecialistAdapter,
    MalformedAgentResultError,
    SpecialistDecision,
    SpecialistRequest,
    SpecialistResponse,
)


def test_missing_transformation_cannot_silently_accept_source_expression():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    source = SpecialistResponse(decisions=[SpecialistDecision(
        target_column="LABEL", decision="mapped", source_columns=["DB.SRC.T.NAME"],
        expression="NAME", confidence=0.8, decision_reason="Requires normalization",
        mapping_classification="derived", requires_transformation=True)])
    transformed = complete_transformation_response(SpecialistResponse(), ["LABEL"])
    [row] = WorkbenchWorkflowHandlers._merge_specialist_decisions(source, transformed)
    assert row["status"] == "unresolved"
    assert row["missing_dependencies"] == ["transformation_decision"]


def test_durable_finalize_keeps_unresolved_dependencies_and_assumptions():
    from app.agent_tools.specialists import decision_from_durable_row
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    source = decision_from_durable_row({'target_column':'KEY', 'status':'unresolved',
        'source_columns':['DB.SRC.T.KEY'], 'expression':'KEY', 'confidence':0.8,
        'mapping_classification':'derived', 'assumptions':['requires business review'],
        'missing_dependencies':['approved key rule'], 'evidence_ids':['e1']})
    transformation = SpecialistDecision(target_column='KEY', decision='mapped', confidence=0.9,
        decision_reason='Expression compiled', expression='KEY', mapping_classification='derived')
    [row] = WorkbenchWorkflowHandlers._merge_specialist_decisions(
        SpecialistResponse(decisions=[source]), SpecialistResponse(decisions=[transformation]))
    assert row['status'] == 'unresolved'
    assert row['assumptions'] == ['requires business review']
    assert row['missing_dependencies'] == ['approved key rule']
    assert row['evidence_ids'] == ['e1']


@pytest.mark.parametrize("targets", [["OTHER"], ["LABEL", "LABEL"]])
def test_transformation_rejects_unassigned_or_duplicate_targets(targets):
    response = SpecialistResponse(decisions=[SpecialistDecision(
        target_column=target, decision="mapped", confidence=0.8, decision_reason="candidate")
        for target in targets])
    with pytest.raises(MalformedAgentResultError):
        complete_transformation_response(response, ["LABEL"])
from app.core.exceptions import SemanticAssetNotFoundError
from app.core.workspace_snapshot import relation_alias_for
from app.schema.common import TableRef
from app.schema.mapping_sql import (
    MappingSqlCompileResponse,
    MappingSqlPreviewResponse,
    MappingSqlReviewResponse,
)
from app.schema.semantic_context import SemanticBundleStatus
from app.schema.workspace_context import WorkbenchContextSnapshotV1
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.core.semantic_context import SemanticContextService


def _actor() -> AgentActor:
    return AgentActor(
        app_user_id="42",
        snowflake_username="ANKURS",
        tenant_id="tenant-1",
        effective_role="MIGRATION_EDITOR",
    )


def test_identity_keeps_application_id_separate_from_snowflake_username() -> None:
    actor = _actor()
    assert actor.user_id == "42"
    assert actor.snowflake_username == "ANKURS"
    assert actor.model_dump()["app_user_id"] == "42"


def test_auto_effort_is_resolved_before_the_run_is_persisted() -> None:
    run = AgentRunService(InMemoryAgentRunRepository()).create_run(
        RunCreateRequest(
            prompt="Reconcile all mappings and evaluate blast radius",
            requested_mappings=[f"Mapping {index}" for index in range(6)],
        ),
        _actor(),
    )
    assert run.request.effort.value == "auto"
    assert run.policy.effort.value == "high"


def test_auto_effort_routes_unscoped_multi_tool_discovery_to_medium() -> None:
    run = AgentRunService(InMemoryAgentRunRepository()).create_run(
        RunCreateRequest(
            prompt=(
                "Analyze loan income amount calculation. Inspect the Workbench context, "
                "search the catalog, use FIR evidence, and recommend the best source and target. "
                "This is read-only; do not create, edit, or publish anything."
            ),
        ),
        _actor(),
    )

    assert run.request.effort.value == "auto"
    assert run.policy.effort.value == "medium"


def test_auto_effort_routes_actual_publish_request_to_high() -> None:
    run = AgentRunService(InMemoryAgentRunRepository()).create_run(
        RunCreateRequest(prompt="Validate the mapping and publish the approved artifact."),
        _actor(),
    )

    assert run.policy.effort.value == "high"


def test_latest_run_is_scoped_to_application_user_and_tenant() -> None:
    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    first = service.create_run(RunCreateRequest(prompt="First run"), _actor())
    other = _actor().model_copy(update={"app_user_id": "84"})
    service.create_run(RunCreateRequest(prompt="Other user's run"), other)
    latest = service.create_run(RunCreateRequest(prompt="Latest run"), _actor())

    assert service.get_latest_state(_actor()).run.run_id == latest.run_id
    assert service.get_latest_state(_actor()).run.run_id != first.run_id


def test_catalog_search_matches_natural_language_to_snowflake_identifiers() -> None:
    fqn = "BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION"

    assert WorkbenchWorkflowHandlers._catalog_matches("loan income amount calculation", fqn)
    assert WorkbenchWorkflowHandlers._catalog_matches("income", fqn)
    assert not WorkbenchWorkflowHandlers._catalog_matches("contact status", fqn)


def test_event_cursors_are_contiguous_per_run() -> None:
    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    first = service.create_run(RunCreateRequest(prompt="First"), _actor())
    second = service.create_run(RunCreateRequest(prompt="Second"), _actor())
    service.emit(first, "tool.started", "running", "Started")
    service.emit(second, "tool.started", "running", "Started")
    assert [event.sequence for event in repository.list_events(first.run_id)] == [1, 2]
    assert [event.sequence for event in repository.list_events(second.run_id)] == [1, 2]


def test_queued_run_cancellation_is_immediate_and_idempotent() -> None:
    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    run = service.create_run(RunCreateRequest(prompt="Analyze a mapping"), _actor())

    first = service.cancel(run.run_id, RunCancelRequest(reason="User stopped the run"), _actor())
    second = service.cancel(run.run_id, RunCancelRequest(reason="Duplicate click"), _actor())

    assert first.status is RunStatus.CANCELLED
    assert second.status is RunStatus.CANCELLED
    assert second.cancel_reason == "User stopped the run"
    assert [event.event_type for event in repository.list_events(run.run_id)] == [
        "run.queued",
        "run.cancelled",
    ]


def test_malformed_tool_output_is_a_typed_failure() -> None:
    result = ToolResult.from_untrusted("not-an-object", operation="source_specialist")
    assert result.status == "failed"
    assert result.error_code == "malformed_tool_result"


def test_malformed_specialist_output_is_a_typed_failure() -> None:
    invocation = AgentInvocationV1(
        invocation_id="invoke-1",
        agent_identity="AGT_SOURCE_MAPPING",
        operation="source_mapping",
        context_hash="context-1",
    )

    result = AgentInvocationResultV1.from_untrusted("not-an-object", invocation=invocation)

    assert result.status == "failed"
    assert result.error_code == "malformed_agent_result"


def test_live_specialist_adapter_rejects_malformed_output_with_typed_code() -> None:
    class _MalformedClient:
        def run_detailed(self, *_args, **_kwargs):
            return "not-json", "thread-1", "not-an-object"

    adapter = CortexSpecialistAdapter(
        _MalformedClient(),  # type: ignore[arg-type]
        source_mapping_agent="AGT_SOURCE_MAPPING",
        transformation_rule_agent="AGT_TRANSFORMATION_RULE",
    )
    request = SpecialistRequest(
        run_id="run-1",
        step_id="source-map",
        project_id="project-1",
        sttm_id="sttm-1",
        snapshot_id="snapshot-1",
        target_contract={},
        target_columns=["AMOUNT"],
        allowed_source_tables=["DB.S.LOANS"],
        actor_user_id="42",
        effective_role="MIGRATION_EDITOR",
        tenant_id="tenant-1",
    )

    with pytest.raises(MalformedAgentResultError) as caught:
        adapter.source_mapping(request)

    assert caught.value.error_code == "malformed_agent_result"


def test_source_mapping_keeps_valid_columns_when_one_response_is_malformed() -> None:
    import json

    class _PartialClient:
        def run_detailed(self, messages, **_kwargs):
            targets = json.loads(messages[0]["content"][0]["text"])["request"]["target_columns"]
            if len(targets) != 1 or targets[0] == "BAD":
                return "not-json", "thread-1", "not-an-object"
            return "", "thread-1", {"decisions": [{
                "target_column": targets[0], "decision": "mapped",
                "source_columns": ["DB.S.T.GOOD"], "confidence": 0.8,
                "decision_reason": "Current source contract", "mapping_classification": "direct",
            }]}

    adapter = CortexSpecialistAdapter(
        _PartialClient(), source_mapping_agent="AGT_SOURCE_MAPPING",
        transformation_rule_agent="AGT_TRANSFORMATION_RULE",
    )
    request = SpecialistRequest(
        run_id="run-1", step_id="map-1", project_id="project-1", sttm_id="sttm-1",
        snapshot_id="snapshot-1", target_contract={}, target_columns=["GOOD", "BAD"],
        allowed_source_tables=["DB.S.T"], actor_user_id="42",
        effective_role="MIGRATION_EDITOR", tenant_id="tenant-1",
    )
    source, _ = adapter.map_targets(request, max_workers=1, before_call=lambda _operation: None)
    assert {item.target_column: item.decision for item in source.decisions} == {
        "GOOD": "mapped", "BAD": "unresolved",
    }
    assert any(item["category"] == "mapping_specialist_unresolved" for item in source.review_items)


def test_specialist_reads_json_fence_inside_cortex_message() -> None:
    from app.agent_tools.specialists import _parse_specialist_response
    content = '```json\n{"decisions":[{"target_column":"ID","decision":"mapped","confidence":0.8,"decision_reason":"Current contract"}]}\n```'
    response = _parse_specialist_response({"message": {"content": [{"type": "text", "text": content}]}}, content)
    assert response.decisions[0].target_column == "ID"


def test_specialist_reads_governed_cortex_result_envelope() -> None:
    from app.agent_tools.specialists import _parse_specialist_response
    payload = {"contract_version": "1.0", "data": {"result": {"decisions": [{
        "target_column": "ID", "decision": "mapped", "confidence": 0.9,
        "decision_reason": "Verified current source contract",
    }]}}}
    response = _parse_specialist_response({"content": []}, f"```json\n{__import__('json').dumps(payload)}\n```")
    assert response.decisions[0].decision == "mapped"


def test_specialist_batches_include_only_their_target_contract_columns() -> None:
    import json

    class _ScopedClient:
        seen = []
        def run_detailed(self, messages, **_kwargs):
            request = json.loads(messages[0]["content"][0]["text"])["request"]
            self.seen.append(request)
            return "", "thread-1", {"decisions": [{"target_column": column,
                "decision": "unresolved", "confidence": 0,
                "decision_reason": "Needs current business rule"} for column in request["target_columns"]]}

    client = _ScopedClient()
    adapter = CortexSpecialistAdapter(client, source_mapping_agent="AGT_SOURCE_MAPPING",
                                       transformation_rule_agent="AGT_TRANSFORMATION_RULE")
    request = SpecialistRequest(run_id="run-1", step_id="map", project_id="p", sttm_id="s",
        snapshot_id="draft:s", target_contract={"columns": [
            {"name": name, "type": "VARCHAR"} for name in "ABCDEFG"]},
        target_columns=list("ABCDEFG"), allowed_source_tables=["DB.S.T"],
        current_mapping_rows=[{"target_column": "A"}], actor_user_id="1",
        effective_role="EDITOR", tenant_id="default")
    adapter.map_targets(request, max_workers=1, before_call=lambda _operation: None)
    assert all({item["name"] for item in call["target_contract"]["columns"]}
               == set(call["target_columns"]) for call in client.seen)


def test_specialist_keeps_valid_decisions_from_noisy_agent_response() -> None:
    import json
    from app.agent_tools.specialists import _parse_specialist_response

    mixed = {"decisions": [
        {"target_column": "GOOD", "decision": "mapped", "source_columns": ["DB.S.T.GOOD"],
         "confidence": 0.8, "decision_reason": "Current column", "mapping_classification": "direct"},
        {"target_column": "BAD", "decision": "mapped", "confidence": "unknown"},
    ]}
    parsed = _parse_specialist_response(None, f"Here are the decisions: {json.dumps(mixed)}")
    assert [item.target_column for item in parsed.decisions] == ["GOOD"]

    class _NoisyClient:
        def run_detailed(self, messages, **_kwargs):
            requested = json.loads(messages[0]["content"][0]["text"])["request"]["target_columns"]
            return "", "thread-1", {"decisions": [
                {"target_column": requested[0].lower(), "decision": "mapped",
                 "source_columns": [f"DB.S.T.{requested[0]}"], "confidence": 0.8,
                 "decision_reason": "Current source", "mapping_classification": "direct"},
                {"target_column": "UNREQUESTED", "decision": "unresolved", "confidence": 0,
                 "decision_reason": "Outside this batch"},
            ]}

    adapter = CortexSpecialistAdapter(_NoisyClient(), source_mapping_agent="AGT_SOURCE_MAPPING",
                                      transformation_rule_agent="AGT_TRANSFORMATION_RULE")
    request = SpecialistRequest(run_id="run-1", step_id="map", project_id="p", sttm_id="s",
        snapshot_id="draft:s", target_contract={"columns": [{"name": "GOOD"}]},
        target_columns=["GOOD"], allowed_source_tables=["DB.S.T"],
        actor_user_id="1", effective_role="EDITOR", tenant_id="default")
    response, _ = adapter.map_targets(request, max_workers=1, before_call=lambda _operation: None)
    assert [item.target_column for item in response.decisions] == ["GOOD"]


@pytest.mark.parametrize("missing_dependency", ["specialist_decision", "value_or_attribute_binding"])
def test_recovery_reruns_only_mapping_partition_with_invalid_agent_decision(missing_dependency: str) -> None:
    from threading import RLock
    from app.agent_runs.models import MappingDagNode, StepStatus
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.migration_workflow.scheduler import Partition, PartitionState

    class _Repository:
        def list_dag_nodes(self, _run_id):
            return [MappingDagNode(run_id="run", mapping_key=f"partition:{partition.partition_id}",
                mapping_name="mapping", status=StepStatus.NEEDS_REVIEW if partition.stage == "compile" else StepStatus.SUCCEEDED,
                plan_hash="approved", partition_payload=partition.model_dump(mode="json"))
                for partition in [
                    Partition(partition_id="mapping:map:0", mapping_key="mapping", columns=["GOOD", "BAD"],
                        state=PartitionState.COMPLETED, result={"mapping_rows": [
                            {"target_column": "GOOD", "status": "draft"},
                            {"target_column": "BAD", "status": "unresolved",
                             "missing_dependencies": [missing_dependency]}]}),
                    Partition(partition_id="mapping:compile", mapping_key="mapping", stage="compile",
                        waits_for=["mapping:map:0"], state=PartitionState.NEEDS_REVIEW),
                ]]

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._repository = _Repository()
    handler._domain_lock = RLock()
    handler._describe_table = lambda _table: {"columns": ["GOOD", "BAD"]}
    partitions = handler.build_partitions({"run_id": "run", "project_id": "project",
        "approved_plan_hash": "approved", "manifest": [{"mapping_key": "mapping", "target_table": "DB.S.T"}]})
    assert all(partition.state is PartitionState.READY for partition in partitions)


def test_deep_agent_adapts_workbench_auto_map_candidates_and_confidence() -> None:
    import json

    class _WorkbenchClient:
        payload = None
        def run_detailed(self, messages, **_kwargs):
            self.payload = json.loads(messages[0]["content"][0]["text"])
            result = {"data": {"result": {"mappings": {
                "CITY": {"source_attributes": ["CONTACTS.CITY"], "confidence_score": 0.68,
                         "confidence_reason": "Semantic match needs review",
                         "candidate_source_attributes": ["CONTACTS.MAIL_CITY"],
                         "preprocessing_rule": "UPPER(CONTACTS.CITY)",
                         "transformation_classification": "complex"},
            }}}}
            return json.dumps(result), "thread-1", result

    client = _WorkbenchClient()
    adapter = CortexSpecialistAdapter(client, source_mapping_agent="DB.S.AGT_SOURCE_MAPPING",
                                      transformation_rule_agent="DB.S.AGT_TRANSFORMATION_RULE")
    request = SpecialistRequest(run_id="run-1", step_id="map", project_id="p", sttm_id="s",
        snapshot_id="draft:s", target_contract={"target_table": "DB.S.TARGET",
            "columns": [{"name": "CITY", "type": "VARCHAR"}]},
        target_columns=["CITY"], allowed_source_tables=["DB.S.CONTACTS"],
        allowed_source_columns={"DB.S.CONTACTS": ["CITY", "MAIL_CITY"]},
        compiler_relation_graph={"nodes": [{"relation_id": "source", "kind": "PHYSICAL_TABLE",
            "alias": "S1", "table": {"database": "DB", "schema": "S", "table": "CONTACTS"},
            "output_columns": [{"name": "CITY"}, {"name": "MAIL_CITY"}]}]},
        actor_user_id="1", effective_role="EDITOR", tenant_id="default")
    mapped, transformed = adapter.map_targets(request, max_workers=1, before_call=lambda _operation: None)
    assert client.payload["operation"] == "sttm.auto_map"
    assert client.payload["data"]["intent"] == "AUTO_MAP"
    assert client.payload["context"]["relation_graph"]["nodes"][0]["alias"] == "S1"
    assert mapped.decisions[0].source_columns == ["DB.S.CONTACTS.CITY"]
    assert mapped.decisions[0].confidence == 0.68
    assert mapped.decisions[0].expression == "UPPER(CONTACTS.CITY)"
    assert transformed.decisions == []
    assert mapped.review_items[0]["details"]["candidates"][1]["source_columns"] == ["DB.S.CONTACTS.MAIL_CITY"]


def test_workbench_rule_label_requires_executable_transformation() -> None:
    import json

    class _WorkbenchClient:
        def run_detailed(self, *_args, **_kwargs):
            result = {"data": {"result": {"mappings": {
                "FULL_NAME": {"source_attributes": ["CONTACTS.FIRST_NAME", "CONTACTS.LAST_NAME"],
                              "confidence_score": 0.8, "preprocessing_rule": "Concatenate"},
            }}}}
            return json.dumps(result), "thread-1", result

    adapter = CortexSpecialistAdapter(_WorkbenchClient(), source_mapping_agent="DB.S.AGT_SOURCE_MAPPING",
                                      transformation_rule_agent="DB.S.AGT_TRANSFORMATION_RULE")
    request = SpecialistRequest(run_id="run-1", step_id="map", project_id="p", sttm_id="s",
        snapshot_id="draft:s", target_contract={"target_table": "DB.S.TARGET",
            "columns": [{"name": "FULL_NAME", "type": "VARCHAR"}]},
        target_columns=["FULL_NAME"], allowed_source_tables=["DB.S.CONTACTS"],
        allowed_source_columns={"DB.S.CONTACTS": ["FIRST_NAME", "LAST_NAME"]},
        actor_user_id="1", effective_role="EDITOR", tenant_id="default")
    response = adapter._parse_source_mapping_response(None, _WorkbenchClient().run_detailed()[0], request)
    [decision] = response.decisions
    assert decision.requires_transformation
    assert decision.expression is None


def test_workbench_transformation_response_adapts_to_deep_agent() -> None:
    import json

    payload = {"data": {"result": {"rules": [{
        "target_attribute": "DB.S.TARGET.FULL_NAME",
        "rule": "CONCAT_WS(' ', S1.FIRST_NAME, S1.LAST_NAME)",
        "description": "Combine the declared name columns.",
        "learning_evidence": ["learning:1"],
    }]}}}
    request = SpecialistRequest(run_id="run-1", step_id="map", project_id="p", sttm_id="s",
        snapshot_id="draft:s", target_contract={"target_table": "DB.S.TARGET"},
        target_columns=["FULL_NAME"], allowed_source_tables=["DB.S.CONTACTS"],
        actor_user_id="1", effective_role="EDITOR", tenant_id="default")
    response = CortexSpecialistAdapter._parse_transformation_response(
        payload, json.dumps(payload), request,
    )
    [decision] = response.decisions
    assert decision.expression == "CONCAT_WS(' ', S1.FIRST_NAME, S1.LAST_NAME)"
    assert decision.learning_ids_used == ["learning:1"]


def test_approved_current_project_value_becomes_executable_draft() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    rows = [{"target_column": "SOME_DATE", "status": "unresolved", "confidence": 0.4,
             "missing_dependencies": ["value_or_attribute_binding"]}]
    WorkbenchWorkflowHandlers._promote_approved_value_bindings(rows, [{
        "name": "ProjectDate", "target_columns": ["SOME_DATE"], "resolved_value": "2026-01-01",
        "data_type": "DATE", "resolution_status": "resolved", "approval_state": "approved",
        "evidence_ids": ["project_attribute:1"],
    }], [{"name": "SOME_DATE", "type": "DATE"}])
    assert rows[0]["status"] == "draft"
    assert rows[0]["expression"] == "TO_DATE('2026-01-01')"
    assert rows[0]["missing_dependencies"] == []

    derived = [{"target_column": "DERIVED_ID", "status": "unresolved", "confidence": 0.4,
                "source_columns": ["DB.S.CONTACTS.ID"],
                "missing_dependencies": ["validated_transformation_expression"]}]
    WorkbenchWorkflowHandlers._promote_approved_value_bindings(derived, [{
        "name": "IdPrefix", "target_columns": ["DERIVED_ID"], "resolved_value": "PREFIX_",
        "data_type": "VARCHAR", "resolution_status": "resolved", "approval_state": "approved",
    }], [{"name": "DERIVED_ID", "type": "VARCHAR"}])
    assert derived[0]["status"] == "unresolved"
    assert derived[0].get("expression") is None


def test_mapping_context_hash_includes_the_complete_workspace_snapshot() -> None:
    base = MappingContextPackageV1(
        run_id="run-1",
        thread_id="thread-1",
        app_user_id="42",
        effective_role="MIGRATION_EDITOR",
        workspace=WorkbenchContextSnapshotV1(
            project_id="1501",
            relationships=[{"left": "DB.S.A.ID", "right": "DB.S.B.ID"}],
        ),
        stored_semantic_context=StoredSemanticContextReference(status="unavailable"),
    )
    changed = MappingContextPackageV1(
        run_id="run-1",
        thread_id="thread-1",
        app_user_id="42",
        effective_role="MIGRATION_EDITOR",
        workspace=WorkbenchContextSnapshotV1(
            project_id="1501",
            relationships=[{"left": "DB.S.A.ID", "right": "DB.S.B.CUSTOMER_ID"}],
        ),
        stored_semantic_context=StoredSemanticContextReference(status="unavailable"),
    )

    assert base.context_hash != changed.context_hash


def test_deep_capability_registry_cannot_resolve_semantic_generation() -> None:
    names = {contract.name for contract in CapabilityRegistry.CONTRACTS}

    assert "read_stored_semantic_context" in names
    assert "sttm_builder" not in names
    assert "validate_migration_plan" in names
    assert {
        "source_mapping",
        "transformation_rule",
        "workbench_rag",
        "sql_analyst",
        "convert_mapping_to_dbt",
        "generate_mapping_tests",
    }.issubset(names)
    assert "read_semantic_context" not in names
    assert not any("semantic_model" in name for name in names)


def test_sql_analyst_never_runs_without_a_stored_semantic_view() -> None:
    class _ForbiddenAnalyst:
        def ask(self, **_kwargs):
            raise AssertionError("Analyst must not run without a stored semantic view")

    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=object(),
        analyst=_ForbiddenAnalyst(),  # type: ignore[arg-type]
    )

    result = handlers.ask_sql_analyst({"page_context": {}}, "What is loan income?")

    assert result.status == "failed"
    assert result.error_code == "semantic_context_unavailable"
    assert result.warnings == ["semantic_context_unavailable"]


def test_sql_analyst_uses_composed_yaml_for_verified_multi_table_bundle() -> None:
    calls: list[dict[str, object]] = []

    class _Analyst:
        def ask(self, **kwargs):
            calls.append(kwargs)
            return SimpleNamespace(
                text="Verified answer",
                sql="SELECT 1",
                suggestions=[],
                warnings=[],
                verified_query_used=None,
            )

    class _SemanticContext:
        def refresh_bundle(self, _request, **_kwargs):
            return SimpleNamespace(
                semantic_view_name=None,
                semantic_model_yaml="name: composed_household",
                bundle_id="sem-household",
                bundle_hash="hash-household",
            )

    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=object(),
        analyst=_Analyst(),  # type: ignore[arg-type]
        semantic_context=_SemanticContext(),  # type: ignore[arg-type]
    )

    result = handlers.ask_sql_analyst(
        {"page_context": {}},
        "Show household join coverage",
        source_tables=["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"],
        target_table="DB.TGT.HOUSEHOLD",
    )

    assert result.status == "succeeded"
    assert calls == [{
        "question": "Show household join coverage",
        "semantic_view": None,
        "semantic_model_yaml": "name: composed_household",
    }]
    assert result.data["semantic_bundle_id"] == "sem-household"


def test_deep_analyst_uses_stored_workbench_model_and_current_joins_not_physical_view() -> None:
    calls = []
    requests = []

    class _Analyst:
        def ask(self, **kwargs):
            calls.append(kwargs)
            return SimpleNamespace(text="Draft", sql="SELECT 1", suggestions=[], warnings=[], verified_query_used=None)

    class _SemanticContext:
        def refresh_bundle(self, request, **_kwargs):
            requests.append(request)
            return SimpleNamespace(semantic_view_name="DB.SEMANTIC.HOUSEHOLD",
                semantic_model_yaml="name: workbench_household", bundle_id="bundle", bundle_hash="hash")

    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object(),
        analyst=_Analyst(), semantic_context=_SemanticContext())
    join = {"left_table":"DB.SRC.FAMILIES", "right_table":"DB.SRC.CONTACTS",
            "conditions":[{"left_column":"ID", "right_column":"FAMILY_ID"}]}
    result = handlers.ask_sql_analyst({"page_context": {}}, "Propose Household draft",
        source_tables=["DB.SRC.FAMILIES","DB.SRC.CONTACTS"], target_table="DB.TGT.HOUSEHOLD",
        relationships=[join], prefer_stored_model=True)

    assert result.status == "succeeded"
    assert requests[0].relationships == [join]
    assert calls[0]["semantic_view"] is None
    assert calls[0]["semantic_model_yaml"] == "name: workbench_household"


def test_deep_reader_returns_composed_stored_semantic_bundle() -> None:
    class _SemanticContext:
        def refresh_bundle(self, _request, **_kwargs):
            return SimpleNamespace(
                bundle_id="sem-household",
                bundle_hash="hash-household",
                semantic_view_name=None,
                status=SemanticBundleStatus.READY,
                summary=SimpleNamespace(
                    source_table_count=2,
                    relationship_count=1,
                    composed_model_hash="model-hash",
                    tables=["DB.SRC.FAMILIES", "DB.SRC.CONTACTS", "DB.TGT.HOUSEHOLD"],
                ),
                semantic_context=[{"kind": "relationship", "name": "family_contact"}],
                reading_instructions=None,
                warnings=[],
            )

    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=object(),
        semantic_context=_SemanticContext(),  # type: ignore[arg-type]
    )

    result = handlers.read_stored_semantic_context(
        {
            "run_id": "run-semantic-reader",
            "app_user_id": "42",
            "effective_role": "MIGRATION_EDITOR",
            "page_context": {},
        },
        source_tables=["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"],
        target_table="DB.TGT.HOUSEHOLD",
    )

    assert result.status == "succeeded"
    assert result.data["status"] == "available"
    assert result.data["bundle_id"] == "sem-household"
    assert result.data["coverage"] == {"table_count": 2, "relationship_count": 1}
    assert result.data["covered_tables"] == [
        "DB.SRC.FAMILIES",
        "DB.SRC.CONTACTS",
        "DB.TGT.HOUSEHOLD",
    ]


def test_deep_reader_does_not_reuse_stale_workspace_sources_for_explicit_empty_selection() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    captured = []

    class _SemanticContext:
        def refresh_bundle(self, request, **_kwargs):
            captured.append(request)
            return SimpleNamespace(
                bundle_id="target-only", bundle_hash="hash", semantic_view_name=None,
                status=SemanticBundleStatus.READY,
                summary=SimpleNamespace(source_table_count=0, relationship_count=0,
                                        composed_model_hash="hash", tables=["DB.TGT.HOUSEHOLD"]),
                semantic_context=[], reading_instructions=None, warnings=[],
            )

    handlers = WorkbenchWorkflowHandlers(
        repository=object(), project_service=object(), session=object(),
        semantic_context=_SemanticContext(),
    )
    result = handlers.read_stored_semantic_context({
        "run_id": "run-current-selection", "app_user_id": "42",
        "effective_role": "MIGRATION_EDITOR",
        "mapping_context_package": {
            "run_id": "run-current-selection", "thread_id": "run-current-selection",
            "app_user_id": "42", "effective_role": "MIGRATION_EDITOR",
            "workspace": {
                "source_tables": [{"database": "DB", "schema": "SRC", "table": "OLD"}],
                "relationships": [{"left_table": "DB.SRC.OLD", "right_table": "DB.SRC.OTHER"}],
            },
        },
    }, source_tables=[], target_table="DB.TGT.HOUSEHOLD")

    assert captured[0].selected_source_tables == []
    assert captured[0].relationships == []
    assert result.data["status"] == "partial"
    assert result.data["analyst_ready"] is False


def test_deep_reader_reports_missing_native_semantic_assets_without_partial_bundle() -> None:
    class _SemanticContext:
        def refresh_bundle(self, _request, **_kwargs):
            raise SemanticAssetNotFoundError(
                "Missing semantic assets",
                details=[
                    {"field": "semantic_asset", "message": "DB.SRC.CONTACTS"},
                    {"field": "semantic_native_registry", "message": "META.LATEST_NATIVE_VIEWS"},
                ],
            )

    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=object(),
        semantic_context=_SemanticContext(),  # type: ignore[arg-type]
    )

    result = handlers.read_stored_semantic_context(
        {
            "run_id": "run-missing-semantic",
            "app_user_id": "42",
            "effective_role": "MIGRATION_EDITOR",
            "page_context": {},
        },
        source_tables=["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"],
        target_table="DB.TGT.HOUSEHOLD",
    )

    assert result.status == "succeeded"
    assert result.warnings == ["semantic_context_incomplete"]
    assert result.data["missing_semantic_assets"] == ["DB.SRC.CONTACTS"]
    assert result.data["registry"] == "META.LATEST_NATIVE_VIEWS"


def test_deep_reader_keeps_available_workbench_semantics_when_one_asset_is_missing(monkeypatch) -> None:
    from app.core import semantic_knowledge_resolver

    class _SemanticContext:
        def refresh_bundle(self, _request, **_kwargs):
            raise SemanticAssetNotFoundError("Missing asset", details=[
                {"field": "semantic_asset", "message": "DB.SRC.ADDRESSES"},
            ])

    class _Resolver:
        def __init__(self, _settings):
            pass
        def resolve(self, _session, _tables):
            return [{"fqn":"DB.SRC.CONTACTS", "semantic_model": {
                "description":"Current contact source", "grain":"one contact",
                "attributes":[{"name":"ID", "business_meaning":"Contact identifier", "is_primary_key":True}],
            }}]

    monkeypatch.setattr(semantic_knowledge_resolver, "SemanticKnowledgeResolver", _Resolver)
    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object(),
        settings=SimpleNamespace(), semantic_context=_SemanticContext())
    result = handlers.read_stored_semantic_context({
        "run_id":"run-partial", "app_user_id":"user", "effective_role":"EDITOR",
    }, source_tables=["DB.SRC.CONTACTS","DB.SRC.ADDRESSES"], target_table="DB.TGT.HOUSEHOLD")

    assert result.data["status"] == "partial"
    assert result.data["analyst_ready"] is False
    assert result.data["covered_tables"] == ["DB.SRC.CONTACTS"]
    assert result.data["semantic_context"]["tables"][0]["attributes"][0]["business_meaning"] == "Contact identifier"


def test_mapping_context_carries_compact_semantic_projection_to_specialists() -> None:
    reference = StoredSemanticContextReference(
        status="available",
        bundle_id="sem-household",
        bundle_hash="hash-household",
        covered_tables=["DB.SRC.FAMILIES", "DB.TGT.HOUSEHOLD"],
        projection_id="proj-household",
        projection_hash="projection-hash",
        mapping_projection={
            "roles": {"DB.SRC.FAMILIES": "source", "DB.TGT.HOUSEHOLD": "target"},
            "relationships": [{"left": "FAMILIES.ID", "right": "HOUSEHOLD.LEGACY_ID"}],
        },
        reading_instructions={"reading_order": ["DB.SRC.FAMILIES", "DB.TGT.HOUSEHOLD"]},
    )

    dumped = reference.model_dump(mode="json")

    assert dumped["projection_id"] == "proj-household"
    assert dumped["mapping_projection"]["roles"]["DB.TGT.HOUSEHOLD"] == "target"


def test_deep_sql_validation_keeps_compiler_sql_and_offers_the_optimization() -> None:
    """The draft keeps the SELECT the mapping page regenerates; an optimization stays a suggestion."""
    compiled = []
    reviewed = []
    previewed = []
    compiled_sql_preview = 'SELECT S1."ID" AS "LEGACY_ID" FROM "DB"."SRC"."FAMILIES" AS S1'

    class _MappingSql:
        def compile(self, _request):
            compiled.append(_request)
            return MappingSqlCompileResponse(
                valid=True,
                ready=True,
                preview_sql=compiled_sql_preview,
                generated_sql='INSERT INTO "DB"."TGT"."HOUSEHOLD" SELECT S1."ID" AS "LEGACY_ID" FROM "DB"."SRC"."FAMILIES" AS S1',
            )

        def review(self, request):
            reviewed.append(request)
            return MappingSqlReviewResponse(
                valid=True,
                review_agent="CORTEX_ANALYST",
                syntax_valid=True,
                execution_ready=True,
                review_summary="Validated optimization.",
                review_kind="optimization",
                optimized=True,
                requires_approval=True,
                original_preview_sql=request.preview_sql,
                original_generated_sql=request.generated_sql,
                optimized_preview_sql='SELECT S1."ID" AS "LEGACY_ID" FROM "DB"."SRC"."FAMILIES" AS S1 WHERE S1."ID" IS NOT NULL',
                optimized_generated_sql='INSERT INTO "DB"."TGT"."HOUSEHOLD" SELECT S1."ID" AS "LEGACY_ID" FROM "DB"."SRC"."FAMILIES" AS S1 WHERE S1."ID" IS NOT NULL',
            )

        def preview(self, request):
            previewed.append(request)
            return MappingSqlPreviewResponse(
                valid=True,
                variant_used=request.chosen_variant,
                executed_preview_sql=request.approved_preview_sql or request.preview_sql,
                executed_generated_sql=request.approved_generated_sql or request.generated_sql,
            )

    source = TableRef(database="DB", schema="SRC", table="FAMILIES")
    target = TableRef(database="DB", schema="TGT", table="HOUSEHOLD")
    context = MappingContextPackageV1(
        run_id="run-review",
        thread_id="run-review",
        app_user_id="42",
        effective_role="MIGRATION_EDITOR",
        workspace=WorkbenchContextSnapshotV1(
            source_tables=[source],
            driving_table=source,
            target_table=target,
        ),
    )
    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=object(),
        mapping_sql=_MappingSql(),  # type: ignore[arg-type]
    )

    result = handlers._validate_generated_sql(
        state={"run_id": "run-review", "mapping_context_package": context.model_dump(mode="json")},
        target_table=target.qualified_name,
        source_tables=[source.qualified_name],
        source_columns={source.qualified_name: ["ID", "NAME"]},
        rows=[{
            "target_column": "LEGACY_ID",
            "source_columns": [f"{source.qualified_name}.ID"],
            "expression": None,
            "status": "draft",
        }, {
            "target_column": "DISPLAY_NAME",
            "source_columns": [f"{source.qualified_name}.ID", f"{source.qualified_name}.NAME"],
            "expression": "COALESCE(old_alias.NAME, old_alias.ID)",
            "status": "draft",
        }],
        policy=SimpleNamespace(validation_depth="preview", preview_row_limit=20),
    )

    assert len(reviewed) == 1
    assert [mapping.target_column for mapping in compiled[0].mappings] == ["LEGACY_ID"]
    assert len(previewed) == 1
    assert previewed[0].chosen_variant == "original"
    assert result["optimization_applied"] is False
    assert result["optimization_available"] is True
    assert result["compiled_mapping_preview_sql"] == compiled_sql_preview
    assert result["preview_valid"] is True
    receipt = result["validation_receipt"]
    assert receipt["execution_ready"] is True and receipt["preview_valid"] is True
    assert receipt["review"]["original_preview_sql"] == compiled_sql_preview


def test_deep_sql_validation_holds_back_rejected_columns_and_previews_the_rest() -> None:
    """One invented function must not cost the SQL and preview of every other column."""
    compiled = []

    class _MappingSql:
        def compile(self, request):
            compiled.append([mapping.target_column for mapping in request.mappings])
            if any("lookup_owner(" in (mapping.expression or "") for mapping in request.mappings):
                raise RuntimeError(
                    "(1304): 01c7-aa: 002139 (02000): SQL compilation error:\nUnknown function LOOKUP_OWNER."
                )
            columns = ", ".join(f'S1."{m.target_column}"' for m in request.mappings)
            return MappingSqlCompileResponse(
                valid=True, ready=True,
                preview_sql=f'SELECT {columns} FROM "DB"."SRC"."FAMILIES" AS S1',
                generated_sql=f'INSERT INTO "DB"."TGT"."HOUSEHOLD" SELECT {columns} FROM "DB"."SRC"."FAMILIES" AS S1',
            )

        def review(self, request):
            return MappingSqlReviewResponse(
                valid=True, review_agent="CORTEX_ANALYST", syntax_valid=True, execution_ready=True,
                review_summary="ok", review_kind="none", optimized=False, requires_approval=False,
                original_preview_sql=request.preview_sql, original_generated_sql=request.generated_sql,
            )

        def preview(self, request):
            return MappingSqlPreviewResponse(
                valid=True, variant_used=request.chosen_variant,
                executed_preview_sql=request.preview_sql, executed_generated_sql=request.generated_sql,
            )

    source = TableRef(database="DB", schema="SRC", table="FAMILIES")
    target = TableRef(database="DB", schema="TGT", table="HOUSEHOLD")
    context = MappingContextPackageV1(
        run_id="run-isolate", thread_id="run-isolate", app_user_id="42", effective_role="MIGRATION_EDITOR",
        workspace=WorkbenchContextSnapshotV1(source_tables=[source], driving_table=source, target_table=target),
    )
    events = []
    handlers = WorkbenchWorkflowHandlers(
        repository=object(), project_service=object(), session=object(),  # type: ignore[arg-type]
        mapping_sql=_MappingSql(),  # type: ignore[arg-type]
        trace=lambda event_type, status, summary, data: events.append((event_type, summary, data)),
    )
    fqn = source.qualified_name
    rows = [
        {"target_column": "LEGACY_ID", "source_columns": [f"{fqn}.ID"], "expression": None, "status": "draft"},
        {"target_column": "OWNERID", "source_columns": [f"{fqn}.OWNER_ID"],
         "expression": f"lookup_owner({fqn}.OWNER_ID)", "status": "draft"},
        {"target_column": "NAME", "source_columns": [f"{fqn}.NAME"], "expression": f"TRIM({fqn}.NAME)",
         "status": "draft"},
    ]

    result = handlers._validate_generated_sql(
        state={"run_id": "run-isolate", "mapping_context_package": context.model_dump(mode="json")},
        target_table=target.qualified_name,
        source_tables=[fqn],
        source_columns={fqn: ["ID", "OWNER_ID", "NAME"]},
        rows=rows,
        policy=SimpleNamespace(validation_depth="preview", preview_row_limit=20),
    )

    assert result["compile_valid"] is True and result["preview_valid"] is True
    assert '"OWNERID"' not in result["compiled_mapping_sql"]
    assert compiled[-1] == ["LEGACY_ID", "NAME"]
    held = {item["target_column"]: item for item in result["columns_held_for_review"]}
    assert set(held) == {"OWNERID"}
    assert "Unknown function LOOKUP_OWNER" in held["OWNERID"]["reason"]
    assert "01c7-aa" not in held["OWNERID"]["reason"]
    owner = rows[1]
    assert owner["status"] == "unresolved" and owner["expression"] is None
    assert owner["rejected_expression"].startswith("lookup_owner(")
    assert any("Held OWNERID back" in summary for _, summary, _ in events)


def test_deep_sql_validation_reports_join_plan_errors_without_dropping_columns() -> None:
    class _MappingSql:
        def compile(self, _request):
            raise RuntimeError("SQL compilation error: invalid identifier 'J.MISSING_KEY'")

    source = TableRef(database="DB", schema="SRC", table="FAMILIES")
    target = TableRef(database="DB", schema="TGT", table="HOUSEHOLD")
    context = MappingContextPackageV1(
        run_id="run-structural", thread_id="run-structural", app_user_id="42", effective_role="MIGRATION_EDITOR",
        workspace=WorkbenchContextSnapshotV1(source_tables=[source], driving_table=source, target_table=target),
    )
    handlers = WorkbenchWorkflowHandlers(
        repository=object(), project_service=object(), session=object(),  # type: ignore[arg-type]
        mapping_sql=_MappingSql(),  # type: ignore[arg-type]
    )
    fqn = source.qualified_name
    rows = [
        {"target_column": "LEGACY_ID", "source_columns": [f"{fqn}.ID"], "expression": None, "status": "draft"},
        {"target_column": "NAME", "source_columns": [f"{fqn}.NAME"], "expression": f"TRIM({fqn}.NAME)",
         "status": "draft"},
    ]

    result = handlers._validate_generated_sql(
        state={"run_id": "run-structural", "mapping_context_package": context.model_dump(mode="json")},
        target_table=target.qualified_name,
        source_tables=[fqn],
        source_columns={fqn: ["ID", "NAME"]},
        rows=rows,
        policy=SimpleNamespace(validation_depth="preview", preview_row_limit=20),
    )

    assert result["compile_valid"] is False and result["failed_phase"] == "compile"
    assert "invalid identifier 'J.MISSING_KEY'" in result["error_summary"]
    assert result["isolation"]["structural"] is True
    assert all(row["status"] == "draft" for row in rows)


def test_stored_semantic_bundle_composition_disables_agent_refresh_by_default() -> None:
    signature = inspect.signature(SemanticContextService.refresh_bundle)

    assert signature.parameters["allow_agent_refresh"].default is False


def test_compiler_graph_preserves_prepared_relationships_and_driving_source() -> None:
    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=object(),
    )
    left = TableRef(database="DB", schema="SRC", table="LOANS")
    right = TableRef(database="DB", schema="SRC", table="CUSTOMERS")
    context = MappingContextPackageV1(
        run_id="run-graph",
        thread_id="thread-graph",
        app_user_id="42",
        effective_role="MIGRATION_EDITOR",
        workspace=WorkbenchContextSnapshotV1(
            source_tables=[left, right],
            driving_table=left,
            selected_columns_by_table={
                left.qualified_name: ["LOAN_ID", "CUSTOMER_ID"],
                right.qualified_name: ["CUSTOMER_ID", "NAME"],
            },
            relationships=[{
                "left_table": left.model_dump(mode="json"),
                "right_table": right.model_dump(mode="json"),
                "join_type": "LEFT",
                "conditions": [{"left_column": "CUSTOMER_ID", "right_column": "CUSTOMER_ID"}],
                "source": "APPROVED_PLAN",
            }],
        ),
        stored_semantic_context=StoredSemanticContextReference(status="available"),
    )

    graph, aliases, driving_id, _derived = handlers._compiler_graph(
        state={"mapping_context_package": context.model_dump(mode="json")},
        source_tables=[left.qualified_name, right.qualified_name],
        source_columns={
            left.qualified_name: ["LOAN_ID", "CUSTOMER_ID"],
            right.qualified_name: ["CUSTOMER_ID", "NAME"],
        },
    )

    assert len(graph.nodes) == 2
    assert len(graph.edges) == 1
    assert graph.edges[0].join_type == "LEFT"
    assert graph.edges[0].conditions[0].left_column == "CUSTOMER_ID"
    # Canonical identities: the relation id is the table FQN and the alias is
    # the frontend's stable identity alias, exactly as the mapping page builds it.
    assert driving_id == left.qualified_name
    assert aliases[left.qualified_name] == relation_alias_for(left.qualified_name)


def test_transformation_merge_preserves_all_many_to_one_dependencies() -> None:
    source = SpecialistResponse(decisions=[SpecialistDecision(
        target_column="FULL_NAME",
        decision="mapped",
        source_columns=["DB.S.CUSTOMER.FIRST_NAME", "DB.S.CUSTOMER.LAST_NAME"],
        expression=None,
        confidence=0.91,
        decision_reason="Both source attributes are required.",
        evidence_ids_used=["semantic:full-name"],
        learning_ids_used=["fir:full-name"],
        requires_transformation=True,
        mapping_classification="many_to_one",
    )])
    transformation = SpecialistResponse(decisions=[SpecialistDecision(
        target_column="FULL_NAME",
        decision="mapped",
        source_columns=["DB.S.CUSTOMER.MIDDLE_NAME"],
        expression="TRIM(CONCAT_WS(' ', FIRST_NAME, MIDDLE_NAME, LAST_NAME))",
        confidence=0.84,
        decision_reason="Normalize optional middle name.",
        evidence_ids_used=["contract:full-name"],
        learning_ids_used=["fir:name-normalization"],
        mapping_classification="many_to_one",
    )])

    [row] = WorkbenchWorkflowHandlers._merge_specialist_decisions(source, transformation)

    assert row["source_columns"] == [
        "DB.S.CUSTOMER.FIRST_NAME",
        "DB.S.CUSTOMER.LAST_NAME",
        "DB.S.CUSTOMER.MIDDLE_NAME",
    ]
    assert row["expression"].startswith("TRIM(CONCAT_WS")
    assert row["mapping_classification"] == "many_to_one"
    assert row["status"] == "draft"
    assert row["used_learning_ids"] == ["fir:full-name", "fir:name-normalization"]


def test_online_evaluation_enforces_questions_budgets_and_terminal_integrity() -> None:
    service = AgentRunService(InMemoryAgentRunRepository())
    run = service.create_run(RunCreateRequest(prompt="Draft Contact"), _actor())
    events = [
        AgentRunEvent(event_id="1", run_id=run.run_id, sequence=1, event_type="run.queued", status="queued", safe_summary="Queued"),
        AgentRunEvent(event_id="2", run_id=run.run_id, sequence=2, event_type="tool.started", status="running", safe_summary="Inspecting"),
        AgentRunEvent(event_id="3", run_id=run.run_id, sequence=3, event_type="assistant.final", status="succeeded", safe_summary="Ready"),
    ]
    report = AgentEvaluationHarness().evaluate(run, events)
    assert report.passed is True
    assert report.score == 1.0


def test_online_evaluation_rejects_terminal_run_with_unfinished_plan() -> None:
    service = AgentRunService(InMemoryAgentRunRepository())
    run = service.create_run(RunCreateRequest(prompt="Draft Contact"), _actor())
    events = [
        AgentRunEvent(event_id="1", run_id=run.run_id, sequence=1, event_type="run.queued", status="queued", safe_summary="Queued"),
        AgentRunEvent(
            event_id="2",
            run_id=run.run_id,
            sequence=2,
            event_type="plan.updated",
            status="running",
            safe_summary="Plan updated",
            data={"details": {"todos": [{"content": "Retrieve FIR", "status": "pending"}]}},
        ),
        AgentRunEvent(event_id="3", run_id=run.run_id, sequence=3, event_type="tool.started", status="running", safe_summary="Inspecting"),
        AgentRunEvent(event_id="4", run_id=run.run_id, sequence=4, event_type="assistant.final", status="succeeded", safe_summary="I will retrieve FIR next"),
    ]

    report = AgentEvaluationHarness().evaluate(run, events)

    assert report.passed is False
    assert next(item for item in report.findings if item.evaluator == "plan_completion").passed is False
