from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.schema.workspace_context import WorkbenchContextSnapshotV1


def _stable_hash(value: Any) -> str:
    payload = value.model_dump(mode="json", exclude={"plan_hash", "context_hash"}) if hasattr(value, "model_dump") else value
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class EvidenceReference(BaseModel):
    evidence_id: str
    kind: str
    subject: str | None = None
    provenance: str | None = None
    artifact_ref: str | None = None
    validated: bool = False
    used: bool = False
    confidence: float | None = Field(default=None, ge=0, le=1)


class StoredSemanticContextReference(BaseModel):
    status: Literal["available", "partial", "unavailable"] = "unavailable"
    bundle_id: str | None = None
    bundle_hash: str | None = None
    semantic_view_name: str | None = None
    composed_model_hash: str | None = None
    freshness: str | None = None
    coverage: float | None = Field(default=None, ge=0, le=1)
    provenance: list[str] = Field(default_factory=list)
    covered_tables: list[str] = Field(default_factory=list)
    projection_id: str | None = None
    projection_hash: str | None = None
    mapping_projection: dict[str, Any] = Field(default_factory=dict)
    reading_instructions: dict[str, Any] = Field(default_factory=dict)
    source: Literal["stored_registry"] = "stored_registry"
    generation_allowed: Literal[False] = False


class PlanValueBindingV1(BaseModel):
    name: str
    placeholder: str
    candidate_value: str | None = None
    resolved_value: str | None = None
    data_type: str | None = None
    target_columns: list[str] = Field(default_factory=list)
    source: Literal["historical_sql", "project_attribute", "approved_learning", "user_answer", "user_prompt"]
    evidence_ids: list[str] = Field(default_factory=list)
    applicability: str = "unverified"
    approval_state: Literal["candidate", "approved", "rejected"] = "candidate"
    resolution_status: Literal["unresolved", "resolved"] = "unresolved"


class SourcePreparationSpecV1(BaseModel):
    driving_source: str | None = None
    intended_grain: str | None = None
    supporting_sources: list[str] = Field(default_factory=list)
    source_rationale: dict[str, str] = Field(default_factory=dict)
    selected_columns_by_table: dict[str, list[str]] = Field(default_factory=dict)
    relationships: list[dict[str, Any]] = Field(default_factory=list)
    derived_sources: list[dict[str, Any]] = Field(default_factory=list)
    value_bindings: list[PlanValueBindingV1] = Field(default_factory=list)
    precedent_reference: dict[str, str] = Field(default_factory=dict)
    filters: dict[str, Any] = Field(default_factory=dict)
    grouping: list[str] = Field(default_factory=list)
    aggregation: list[dict[str, Any]] = Field(default_factory=list)
    sorting: list[str] = Field(default_factory=list)
    deduplicate: bool = False
    target_table: str | None = None
    unresolved_items: list[str] = Field(default_factory=list)


class AutoMapExecutionSpecV1(BaseModel):
    target_columns: list[str] = Field(default_factory=list)
    evidence_gaps: list[str] = Field(default_factory=list)
    allow_partial_coverage: bool = False
    mapping_evidence: list[dict[str, Any]] = Field(default_factory=list)
    requested_mappings: list[str] = Field(default_factory=list)
    mapping_classifications: dict[str, Literal[
        "direct", "many_to_one", "derived", "constant", "excluded", "unresolved"
    ]] = Field(default_factory=dict)
    required_specialists: list[str] = Field(default_factory=list)
    validation_gates: list[str] = Field(default_factory=list)
    expected_coverage: float | None = Field(default=None, ge=0, le=1)


class PlanDecisionV1(BaseModel):
    """Evidence-backed supervisor selection used by the host confidence gate."""

    subject: Literal[
        "project", "source", "target", "join", "derived_source", "value_binding", "value_binding_import", "grain"
    ]
    selected_value: str
    selected_label: str | None = None
    selected_description: str | None = None
    selected_impact: str | None = None
    confidence: float = Field(ge=0, le=1)
    score_margin: float = Field(default=1.0, ge=0, le=1)
    rationale: str
    evidence_ids: list[str] = Field(default_factory=list)
    alternatives: list[dict[str, Any]] = Field(default_factory=list, max_length=3)
    question: str | None = None
    allow_free_text: bool = False
    decision_key: str | None = None
    recommended: bool = False
    names: list[str] = Field(default_factory=list)


class PlanExecutionStepV1(BaseModel):
    sequence: int = Field(ge=1)
    title: str
    description: str
    phase: Literal["plan_analysis", "draft_execution", "validation", "preview", "delivery"]
    query_kind: Literal["none", "metadata", "profile", "join_check", "derived_source", "mapping", "explain", "preview", "reconciliation"] = "none"
    sql: str | None = None
    dynamic_sql: bool = False
    runs_before_approval: bool = False
    runs_after_approval: bool = True
    draft_writes: list[str] = Field(default_factory=list)


class MappingContextPackageV1(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    run_id: str
    thread_id: str
    app_user_id: str
    snowflake_username: str | None = None
    tenant_id: str = "default"
    effective_role: str
    authorized_schemas: list[str] = Field(default_factory=list)
    workspace: WorkbenchContextSnapshotV1
    stored_semantic_context: StoredSemanticContextReference = Field(
        default_factory=StoredSemanticContextReference
    )
    fir_evidence: list[EvidenceReference] = Field(default_factory=list)
    precedent_evidence: list[EvidenceReference] = Field(default_factory=list)
    context_hash: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @model_validator(mode="after")
    def derive_context_hash(self) -> "MappingContextPackageV1":
        expected = _stable_hash(
            self.model_dump(mode="json", exclude={"context_hash", "created_at"})
        )
        if self.context_hash and self.context_hash != expected:
            raise ValueError("context_hash does not match MappingContextPackageV1")
        self.context_hash = expected
        return self


class MappingExecutionSpec(BaseModel):
    mapping_key: str
    target_table: str
    source_preparation: SourcePreparationSpecV1
    dependencies: list[dict[str, Any]] = Field(default_factory=list)
    # Per-target display name and Auto Map evidence. Optional so plans
    # approved before multi-target support keep their exact plan hash.
    mapping_name: str | None = None
    auto_map: AutoMapExecutionSpecV1 | None = None


class ProjectDecisionV1(BaseModel):
    """Supervisor choice between reusing the open project and creating one.

    `operation="create"` alone is the historical default meaning "create a
    run-owned project when none is open". Only `force_new=True` overrides an
    open project, which is what a "create a new project" request needs.
    Validated separately and stored as a plain dict on the plan so hashes of
    plans approved before this contract existed are unchanged.
    """

    model_config = ConfigDict(extra="allow")

    operation: Literal["create", "reuse"] | None = None
    force_new: bool = False
    project_id: str | None = None
    project_name: str | None = Field(default=None, max_length=255)
    description: str | None = Field(default=None, max_length=2_000)
    template_id: str | None = None
    source_system_key: str | None = None
    target_database: str | None = None
    target_schema: str | None = None

    @model_validator(mode="after")
    def require_operation_fields(self) -> "ProjectDecisionV1":
        if self.force_new:
            self.operation = "create"
            if not (self.project_name or "").strip():
                raise ValueError("project_name is required when force_new is true")
        if self.template_id and not self.source_system_key:
            raise ValueError("source_system_key is required when template_id is set")
        return self


class MigrationPlanArtifactV1(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    plan_id: str
    revision: int = Field(default=1, ge=1)
    run_id: str
    thread_id: str
    original_request: str
    normalized_intent: str
    context_hash: str
    mapping_specs: list[MappingExecutionSpec] = Field(default_factory=list)
    dependencies: list[dict[str, Any]] = Field(default_factory=list)
    project_decision: dict[str, Any] = Field(default_factory=dict)
    source_preparation: SourcePreparationSpecV1
    auto_map: AutoMapExecutionSpecV1
    agents: list[str] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    evidence_refs: list[str] = Field(default_factory=list)
    planned_writes: list[str] = Field(default_factory=list)
    validation_plan: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    budgets: dict[str, int | float | str] = Field(default_factory=dict)
    decisions: list[PlanDecisionV1] = Field(default_factory=list)
    execution_steps: list[PlanExecutionStepV1] = Field(default_factory=list)
    plan_hash: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @model_validator(mode="after")
    def derive_plan_hash(self) -> "MigrationPlanArtifactV1":
        payload = self.model_dump(mode="json", exclude={"plan_hash", "created_at"})
        # Older approved plans predate partial coverage. Keep their hash stable
        # when the new optional flag has its default value.
        if not self.auto_map.allow_partial_coverage:
            payload["auto_map"].pop("allow_partial_coverage", None)
        for spec in payload.get("mapping_specs") or []:
            for optional in ("mapping_name", "auto_map"):
                if spec.get(optional) is None:
                    spec.pop(optional, None)
        expected = _stable_hash(payload)
        if self.plan_hash and self.plan_hash != expected:
            raise ValueError("plan_hash does not match MigrationPlanArtifactV1")
        self.plan_hash = expected
        return self


class PlanDelta(BaseModel):
    prior_plan_hash: str
    changed_fields: list[str]
    reason: str
    evidence_refs: list[str] = Field(default_factory=list)


class AgentInvocationV1(BaseModel):
    invocation_id: str
    agent_identity: str
    operation: str
    context_hash: str
    input: dict[str, Any] = Field(default_factory=dict)
    evidence_refs: list[str] = Field(default_factory=list)


class AgentInvocationResultV1(BaseModel):
    invocation_id: str
    agent_identity: str
    deployed_spec_hash: str | None = None
    status: Literal["succeeded", "partial", "failed", "denied"]
    canonical_response: dict[str, Any] = Field(default_factory=dict)
    mappings: list[dict[str, Any]] = Field(default_factory=list)
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    semantic_evidence: list[EvidenceReference] = Field(default_factory=list)
    fir_evidence: list[EvidenceReference] = Field(default_factory=list)
    caller_context: dict[str, Any] = Field(default_factory=dict)
    latency_ms: int | None = None
    usage: dict[str, int | float | str] = Field(default_factory=dict)
    retries: int = 0
    raw_response_artifact_ref: str | None = None
    user_summary: str
    error_code: str | None = None
    safe_error: str | None = None

    @classmethod
    def from_untrusted(
        cls, value: Any, *, invocation: AgentInvocationV1
    ) -> "AgentInvocationResultV1":
        if isinstance(value, cls):
            return value
        if not isinstance(value, dict):
            return cls(
                invocation_id=invocation.invocation_id,
                agent_identity=invocation.agent_identity,
                status="failed",
                user_summary=f"{invocation.agent_identity} returned an invalid response.",
                error_code="malformed_agent_result",
                safe_error="The specialist response did not match its production contract.",
            )
        try:
            return cls.model_validate({
                "invocation_id": invocation.invocation_id,
                "agent_identity": invocation.agent_identity,
                **value,
            })
        except Exception:
            return cls(
                invocation_id=invocation.invocation_id,
                agent_identity=invocation.agent_identity,
                status="failed",
                user_summary=f"{invocation.agent_identity} returned an invalid response.",
                error_code="malformed_agent_result",
                safe_error="The specialist response did not match its production contract.",
            )


class WorkbenchMutationReceipt(BaseModel):
    operation: str
    project_id: str | None = None
    sttm_id: str | None = None
    snapshot_id: str | None = None
    prior_revision: int | None = None
    new_revision: int | None = None
    context_hash: str
    artifact_hash: str | None = None
    changed_entity_types: list[str] = Field(default_factory=list)
    route: str | None = None


class WorkspaceSyncEvent(BaseModel):
    event_type: Literal["workspace.synced"] = "workspace.synced"
    project_id: str | None = None
    sttm_id: str | None = None
    snapshot_id: str | None = None
    revision: int | None = None
    artifact_hash: str | None = None
    context_hash: str
    changed_entity_types: list[str] = Field(default_factory=list)
    route: str | None = None


class WorkbenchAgentResultV1(BaseModel):
    operation: str
    route: str | None = None
    contributing_agents: list[str] = Field(default_factory=list)
    domain_result: dict[str, Any] = Field(default_factory=dict)
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    semantic_evidence: list[EvidenceReference] = Field(default_factory=list)
    fir_evidence: list[EvidenceReference] = Field(default_factory=list)
    validation_findings: list[dict[str, Any]] = Field(default_factory=list)
    mutation_receipts: list[WorkbenchMutationReceipt] = Field(default_factory=list)
    user_summary: str
    recommended_next_actions: list[str] = Field(default_factory=list)
    metrics: dict[str, int | float | str] = Field(default_factory=dict)
    error_code: str | None = None
    safe_error: str | None = None


class FIRMappingRecipeV1(BaseModel):
    recipe_id: str
    target_fqn: str
    target_column: str
    source_tables: list[str]
    source_columns: list[str]
    driving_source: str | None = None
    row_grain: str | None = None
    relationship_dependencies: list[str] = Field(default_factory=list)
    derived_source_dependencies: list[str] = Field(default_factory=list)
    transformation_expression: str | None = None
    conditions: list[str] = Field(default_factory=list)
    retrieved_evidence_ids: list[str] = Field(default_factory=list)
    used_evidence_ids: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0, le=1)
    validation_outcome: str
    human_outcome: str | None = None
    artifact_version: str | None = None
    supersedes_recipe_id: str | None = None
    quarantined: bool = False
