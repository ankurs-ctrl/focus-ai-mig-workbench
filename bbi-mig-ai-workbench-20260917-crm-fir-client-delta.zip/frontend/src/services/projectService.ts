import { API_ROUTES } from "@/api/routes";
import {
  buildApiEnvelope,
  deleteApiData,
  getApiData,
  postEnvelopeData,
  putEnvelopeData,
} from "@/api/axiosInstance";
import { normalizeProjectAttributeRecords } from "@/features/sttm/mapping/project-attribute-utils";
import { getProjectColorById, PROJECT_COLOR_OPTIONS } from "@/features/projects/project-color-options";
import type { ProjectItem, ProjectPerson } from "@/features/projects/projects-data";

type JsonRecord = Record<string, unknown>;

export type ProjectRecord = {
  project_id: string;
  project_name: string;
  description?: string | null;
  status: string;
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  sttm_count: number;
  complete_count: number;
  partial_count: number;
  draft_count: number;
  total_mappings: number;
  mapped_count: number;
  coverage_percent: number;
  metadata?: JsonRecord | null;
  linked_project_ids?: string[];
};

export type STTMRecord = {
  sttm_id: string;
  project_id: string;
  sttm_name?: string | null;
  description?: string | null;
  target_table?: string | null;
  current_version: number;
  has_unpublished_draft: boolean;
  status: string;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  last_snapshot_id?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  mapping_count: number;
  mapped_count: number;
  coverage_percent: number;
  metadata?: JsonRecord | null;
  linked_mapping_ids?: string[];
};

export type STTMDetail = {
  project?: ProjectRecord | null;
  sttm: STTMRecord;
  latest_snapshot?: JsonRecord | null;
  sources: JsonRecord[];
  mapping_rows: JsonRecord[];
  versions: JsonRecord[];
  agent_artifacts: JsonRecord[];
};

export type STTMAutosavePayload = {
  workspace_snapshot: JsonRecord;
  action?: string;
  session_id?: string | null;
  thread_id?: string | null;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  mapping_version?: string | null;
  agent_artifacts?: JsonRecord[];
  fir_events?: JsonRecord[];
  metadata?: JsonRecord;
};

export type STTMAutosaveResult = {
  project_id: string;
  sttm_id: string;
  snapshot_id: string;
  post_save_job_id?: string | null;
  post_save_job_status?: string | null;
  [key: string]: unknown;
};

export type STTMPostSaveJobStatus = {
  job_id: string;
  snapshot_id: string;
  sttm_id: string;
  project_id: string;
  job_type: string;
  status: string;
  attempt_count: number;
  error_details?: JsonRecord | null;
};

export type STTMPublishPayload = {
  revision_note?: string | null;
  workspace_snapshot?: JsonRecord | null;
  session_id?: string | null;
  thread_id?: string | null;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  mapping_version?: string | null;
  metadata?: JsonRecord;
};

export type ProjectsSummary = {
  projects: ProjectRecord[];
  sttms: STTMRecord[];
};

export type ProjectTemplateTarget = {
  logical_target_key: string;
  table_name: string;
  physical_fqn: string;
  available: boolean;
  column_count: number;
  columns: Array<Record<string, unknown>>;
  missing_columns: string[];
};

export type ProjectTemplateRecord = {
  template_id: string;
  template_version: string;
  label: string;
  source_systems: string[];
  target_contract_id: string;
  target_contract_version: string;
  target_database: string;
  target_schema: string;
  available_targets: ProjectTemplateTarget[];
  missing_targets: ProjectTemplateTarget[];
  unexpected_tables: string[];
};

export type ProjectBootstrapResponse = {
  project: ProjectRecord;
  mappings: STTMRecord[];
  template: ProjectTemplateRecord;
  bootstrap_status: string;
  unavailable_target_tables: string[];
};

export type ProjectAttributeRecord = {
  attribute_id: string;
  project_id: string;
  project_name?: string | null;
  attribute_name: string;
  attribute_type: string;
  attribute_value: string;
  source_project_id?: string | null;
  source_project_name?: string | null;
  source_attribute_id?: string | null;
  status: string;
  created_by?: string | null;
  updated_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
};

// Keep project lists, summaries, and immutable STTM snapshot pointers warm across
// normal page navigation and same-tab refreshes. Mutations explicitly invalidate
// the affected entries, so a short polling-style TTL only caused unnecessary
// Snowflake round trips without improving correctness.
const PROJECT_METADATA_CACHE_TTL_MS = Number.MAX_SAFE_INTEGER;
const PROJECTS_SESSION_CACHE_KEY = "aia-workbench:projects:list:v2";
const PROJECT_SUMMARY_SESSION_CACHE_KEY = "aia-workbench:projects:summary:v2";
const STTM_DETAIL_SESSION_PREFIX = "aia-workbench:sttm:detail:v2:";

let projectsCache: { data: ProjectRecord[]; expiresAt: number } | null = null;
let projectsInFlight: Promise<ProjectRecord[]> | null = null;
let summaryCache: { data: ProjectsSummary; expiresAt: number } | null = null;
let summaryInFlight: Promise<ProjectsSummary> | null = null;
const sttmDetailBySnapshotId = new Map<string, STTMDetail>();
const sttmLatestPointers = new Map<string, { snapshotId: string; expiresAt: number }>();
const sttmDetailRequests = new Map<string, Promise<STTMDetail>>();

function isFresh<T>(entry: { data: T; expiresAt: number } | null): entry is { data: T; expiresAt: number } {
  return Boolean(entry && entry.expiresAt > Date.now());
}

function readSessionCache<T>(key: string): { data: T; expiresAt: number } | null {
  if (typeof window === "undefined") {
    return null;
  }
  try {
    const raw = window.sessionStorage.getItem(key);
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw) as { data?: T; expiresAt?: number };
    if (!parsed || typeof parsed.expiresAt !== "number" || parsed.expiresAt <= Date.now()) {
      window.sessionStorage.removeItem(key);
      return null;
    }
    return { data: parsed.data as T, expiresAt: parsed.expiresAt };
  } catch {
    window.sessionStorage.removeItem(key);
    return null;
  }
}

function writeSessionCache<T>(key: string, entry: { data: T; expiresAt: number }) {
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.sessionStorage.setItem(key, JSON.stringify(entry));
  } catch {
    // Session storage is an optimization only. Ignore quota/security failures.
  }
}

function clearSessionProjectCaches() {
  if (typeof window === "undefined") {
    return;
  }
  window.sessionStorage.removeItem(PROJECTS_SESSION_CACHE_KEY);
  window.sessionStorage.removeItem(PROJECT_SUMMARY_SESSION_CACHE_KEY);
  for (let index = window.sessionStorage.length - 1; index >= 0; index -= 1) {
    const key = window.sessionStorage.key(index);
    if (key?.startsWith(STTM_DETAIL_SESSION_PREFIX)) {
      window.sessionStorage.removeItem(key);
    }
  }
}

export function invalidateProjectMetadataCache() {
  projectsCache = null;
  projectsInFlight = null;
  summaryCache = null;
  summaryInFlight = null;
  sttmDetailBySnapshotId.clear();
  sttmLatestPointers.clear();
  sttmDetailRequests.clear();
  clearSessionProjectCaches();
}

/** Return the already-loaded project/STTM summary without starting a request. */
export function getCachedProjectsSummary(): ProjectsSummary | null {
  if (isFresh(summaryCache)) {
    return summaryCache.data;
  }
  const cachedSummary = readSessionCache<ProjectsSummary>(PROJECT_SUMMARY_SESSION_CACHE_KEY);
  if (!isFresh(cachedSummary)) {
    return null;
  }
  summaryCache = cachedSummary;
  projectsCache = {
    data: cachedSummary.data.projects,
    expiresAt: cachedSummary.expiresAt,
  };
  return cachedSummary.data;
}

function initialsFor(name?: string | null) {
  const value = (name || "AI Workbench").trim();
  const parts = value.split(/\s+/).filter(Boolean);
  return (parts.length > 1 ? `${parts[0][0]}${parts[1][0]}` : value.slice(0, 2)).toUpperCase();
}

function formatTimestamp(value?: string | null) {
  if (!value) {
    return "—";
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "—";
  }
  const day = date.getDate().toString().padStart(2, "0");
  const month = date.toLocaleString("en-GB", { month: "short" });
  const year = date.getFullYear();
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  return `${day} ${month} ${year} · ${hours}:${minutes}`;
}

function personFor(name?: string | null, timestamp?: string | null): ProjectPerson {
  return {
    initials: initialsFor(name),
    name: name || "AI Workbench",
    timestamp: formatTimestamp(timestamp),
  };
}

function colorForRecord(record: ProjectRecord) {
  const metadata = record.metadata ?? {};
  const configuredId = typeof metadata.theme_color_id === "string" ? metadata.theme_color_id : "";
  if (configuredId) {
    return getProjectColorById(configuredId);
  }
  const index = Math.abs(
    Array.from(record.project_id || record.project_name).reduce(
      (hash, char) => (hash * 31 + char.charCodeAt(0)) | 0,
      0,
    ),
  ) % PROJECT_COLOR_OPTIONS.length;
  return PROJECT_COLOR_OPTIONS[index];
}

export function projectRecordToItem(record: ProjectRecord): ProjectItem {
  const color = colorForRecord(record);
  const createdBy = personFor(record.created_by, record.created_at);
  const modifiedBy = personFor(record.created_by, record.updated_at ?? record.created_at);

  return {
    id: record.project_id,
    name: record.project_name,
    description: record.description || "No description yet.",
    themeColor: color.color,
    themeBg: color.bg,
    themeBorder: color.color,
    coveragePercent: Math.round(record.coverage_percent || 0),
    coverageBarColor: color.color,
    totalMappings: record.total_mappings || record.sttm_count || 0,
    completeCount: record.complete_count || 0,
    partialCount: record.partial_count || 0,
    draftCount: record.draft_count || 0,
    createdBy,
    lastModifiedBy: modifiedBy,
    domain: typeof record.metadata?.domain === "string" ? record.metadata.domain : undefined,
    intendedOutcome: typeof record.metadata?.intended_outcome === "string" ? record.metadata.intended_outcome : undefined,
    businessProcess: typeof record.metadata?.business_process === "string" ? record.metadata.business_process : undefined,
    owner: typeof record.metadata?.owner === "string" ? record.metadata.owner : undefined,
    linkedProjectIds: record.linked_project_ids ?? [],
  };
}

export async function listProjects(): Promise<ProjectRecord[]> {
  if (isFresh(projectsCache)) {
    return projectsCache.data;
  }
  if (isFresh(summaryCache)) {
    projectsCache = {
      data: summaryCache.data.projects,
      expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
    };
    return projectsCache.data;
  }
  const cachedSummary = readSessionCache<ProjectsSummary>(PROJECT_SUMMARY_SESSION_CACHE_KEY);
  if (isFresh(cachedSummary)) {
    summaryCache = cachedSummary;
    projectsCache = {
      data: cachedSummary.data.projects,
      expiresAt: cachedSummary.expiresAt,
    };
    return projectsCache.data;
  }
  const cachedProjects = readSessionCache<ProjectRecord[]>(PROJECTS_SESSION_CACHE_KEY);
  if (isFresh(cachedProjects)) {
    projectsCache = cachedProjects;
    return cachedProjects.data;
  }
  if (projectsInFlight) {
    return projectsInFlight;
  }
  projectsInFlight = getApiData<ProjectRecord[]>(API_ROUTES.projects.list, {
    skipGlobalError: true,
    timeout: 25000,
  })
    .then((projects) => {
      projectsCache = {
        data: projects,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      };
      writeSessionCache(PROJECTS_SESSION_CACHE_KEY, projectsCache);
      return projects;
    })
    .finally(() => {
      projectsInFlight = null;
    });
  return projectsInFlight;
}

export async function createProject(params: {
  project_name: string;
  description?: string | null;
  theme_color_id?: string;
  domain?: string | null;
  intended_outcome?: string | null;
  business_process?: string | null;
  owner?: string | null;
  linked_project_ids?: string[];
}): Promise<ProjectRecord> {
  const project = await postEnvelopeData<ProjectRecord>(
    API_ROUTES.projects.create,
    buildApiEnvelope(
      "projects.create",
      {
        project_name: params.project_name,
        description: params.description ?? "",
        metadata: {
          theme_color_id: params.theme_color_id,
          domain: params.domain,
          intended_outcome: params.intended_outcome,
          business_process: params.business_process,
          owner: params.owner,
        },
        precedent_links: (params.linked_project_ids ?? []).map((projectId, index) => ({
          precedent_project_id: projectId,
          priority: Math.max(1, 100 - index),
          knowledge_categories: [
            "column_mapping",
            "relationship",
            "transformation",
            "query_shaping",
            "derived_lineage",
          ],
          allow_project_specific_values: false,
        })),
      },
      {},
    ),
    { timeout: 90000 },
  );
  invalidateProjectMetadataCache();
  return project;
}

export async function listProjectTemplates(): Promise<ProjectTemplateRecord[]> {
  return getApiData<ProjectTemplateRecord[]>(API_ROUTES.projects.templates, {
    skipGlobalError: true,
    timeout: 30000,
  });
}

export async function createProjectFromTemplate(params: {
  project_name: string;
  description?: string | null;
  theme_color_id?: string;
  domain?: string | null;
  intended_outcome?: string | null;
  business_process?: string | null;
  owner?: string | null;
  linked_project_ids?: string[];
  template_id: string;
  source_system_key: string;
  bootstrap_mode: "AUTO" | "EMPTY";
  idempotency_key: string;
}): Promise<ProjectBootstrapResponse> {
  const result = await postEnvelopeData<ProjectBootstrapResponse>(
    API_ROUTES.projects.createFromTemplate,
    buildApiEnvelope("projects.create_from_template", {
      project_name: params.project_name,
      description: params.description ?? "",
      template_id: params.template_id,
      source_system_key: params.source_system_key,
      bootstrap_mode: params.bootstrap_mode,
      idempotency_key: params.idempotency_key,
      metadata: {
        theme_color_id: params.theme_color_id,
        domain: params.domain,
        intended_outcome: params.intended_outcome,
        business_process: params.business_process,
        owner: params.owner,
      },
      precedent_links: (params.linked_project_ids ?? []).map((projectId, index) => ({
        precedent_project_id: projectId,
        priority: Math.max(1, 100 - index),
        knowledge_categories: [
          "column_mapping", "relationship", "transformation", "query_shaping", "derived_lineage",
        ],
        allow_project_specific_values: false,
      })),
    }),
    { timeout: 90000 },
  );
  invalidateProjectMetadataCache();
  return result;
}

export async function listProjectSttms(projectId: string): Promise<STTMRecord[]> {
  return getApiData<STTMRecord[]>(API_ROUTES.projects.sttms(projectId), {
    skipGlobalError: true,
    timeout: 15000,
  });
}

export async function listProjectAttributes(projectId: string, signal?: AbortSignal): Promise<ProjectAttributeRecord[]> {
  const payload = await getApiData<unknown>(API_ROUTES.projects.attributes(projectId), {
    skipGlobalError: true,
    timeout: 30000,
    signal,
  });
  return normalizeProjectAttributeRecords(payload, projectId);
}

export async function createProjectAttribute(
  projectId: string,
  payload: { attribute_name: string; attribute_type: string; attribute_value: string },
  signal?: AbortSignal,
): Promise<ProjectAttributeRecord> {
  return postEnvelopeData<ProjectAttributeRecord>(
    API_ROUTES.projects.attributes(projectId),
    buildApiEnvelope("projects.attributes.create", payload, { project_id: projectId }),
    { signal },
  );
}

export async function updateProjectAttribute(
  projectId: string,
  attributeId: string,
  payload: {
    attribute_name?: string;
    attribute_type?: string;
    attribute_value?: string;
    status?: "ACTIVE" | "INACTIVE";
  },
): Promise<ProjectAttributeRecord> {
  return putEnvelopeData<ProjectAttributeRecord>(
    API_ROUTES.projects.attribute(projectId, attributeId),
    buildApiEnvelope("projects.attributes.update", payload, {
      project_id: projectId,
      attribute_id: attributeId,
    }),
  );
}

export async function deleteProjectAttribute(
  projectId: string,
  attributeId: string,
): Promise<void> {
  await deleteApiData(API_ROUTES.projects.attribute(projectId, attributeId));
}

export async function importProjectAttributes(
  projectId: string,
  payload: {
    source_project_id: string;
    attribute_ids: string[];
    overwrite_existing?: boolean;
  },
): Promise<ProjectAttributeRecord[]> {
  return postEnvelopeData<ProjectAttributeRecord[]>(
    API_ROUTES.projects.importAttributes(projectId),
    buildApiEnvelope("projects.attributes.import", payload, { project_id: projectId }),
  );
}

/**
 * Fetch all projects and all STTMs in a single request.
 * Avoids the N+1 pattern of listing projects then fetching per-project STTMs.
 * The caller groups STTMs by project_id client-side.
 */
export async function getAllProjectsSummary(): Promise<ProjectsSummary> {
  const cachedSummary = getCachedProjectsSummary();
  if (cachedSummary) return cachedSummary;
  if (summaryInFlight) {
    return summaryInFlight;
  }
  summaryInFlight = getApiData<ProjectsSummary>(API_ROUTES.projects.summary, {
    skipGlobalError: true,
    timeout: 45000,
  })
    .then((summary) => {
      summaryCache = {
        data: summary,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      };
      projectsCache = {
        data: summary.projects,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      };
      writeSessionCache(PROJECT_SUMMARY_SESSION_CACHE_KEY, summaryCache);
      writeSessionCache(PROJECTS_SESSION_CACHE_KEY, projectsCache);
      return summary;
    })
    .finally(() => {
      summaryInFlight = null;
    });
  return summaryInFlight;
}

export async function createProjectSttm(
  projectId: string,
  payload: JsonRecord,
  signal?: AbortSignal,
): Promise<STTMRecord> {
  const sttm = await postEnvelopeData<STTMRecord>(
    API_ROUTES.projects.sttms(projectId),
    buildApiEnvelope("projects.sttms.create", payload, { project_id: projectId }),
    { timeout: 90000, signal },
  );
  invalidateProjectMetadataCache();
  return sttm;
}

export async function getSttm(sttmId: string): Promise<STTMDetail> {
  const pointer = sttmLatestPointers.get(sttmId);
  if (pointer && pointer.expiresAt > Date.now()) {
    const immutableSnapshot = sttmDetailBySnapshotId.get(pointer.snapshotId);
    if (immutableSnapshot) return immutableSnapshot;
  }
  const sessionDetail = readSessionCache<STTMDetail>(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`);
  if (isFresh(sessionDetail)) {
    const snapshot = sessionDetail.data.latest_snapshot ?? {};
    const snapshotId = String(
      sessionDetail.data.sttm.last_snapshot_id ?? snapshot.snapshot_id ?? `draft:${sttmId}`,
    );
    sttmDetailBySnapshotId.set(snapshotId, sessionDetail.data);
    sttmLatestPointers.set(sttmId, { snapshotId, expiresAt: sessionDetail.expiresAt });
    return sessionDetail.data;
  }
  const pending = sttmDetailRequests.get(sttmId);
  if (pending) return pending;
  const request = getApiData<STTMDetail>(API_ROUTES.sttms.get(sttmId))
    .then((detail) => {
      const snapshot = detail.latest_snapshot ?? {};
      const snapshotId = String(
        detail.sttm.last_snapshot_id ?? snapshot.snapshot_id ?? `draft:${sttmId}`,
      );
      sttmDetailBySnapshotId.set(snapshotId, detail);
      sttmLatestPointers.set(sttmId, {
        snapshotId,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      });
      writeSessionCache(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`, {
        data: detail,
        expiresAt: PROJECT_METADATA_CACHE_TTL_MS,
      });
      if (sttmDetailBySnapshotId.size > 50) {
        const oldestSnapshotId = sttmDetailBySnapshotId.keys().next().value;
        if (oldestSnapshotId) sttmDetailBySnapshotId.delete(oldestSnapshotId);
      }
      return detail;
    })
    .finally(() => sttmDetailRequests.delete(sttmId));
  sttmDetailRequests.set(sttmId, request);
  return request;
}

export async function autosaveSttm(
  sttmId: string,
  payload: STTMAutosavePayload,
): Promise<STTMAutosaveResult> {
  const result = await postEnvelopeData<STTMAutosaveResult>(
    API_ROUTES.sttms.autosave(sttmId),
    buildApiEnvelope("sttms.autosave", payload, { sttm_id: sttmId }),
    // Snowflake-backed autosaves update the durable snapshot plus normalized
    // source/mapping/FIR projections. Allow that write to finish instead of
    // reporting a false failure at the global 30-second request limit.
    { skipGlobalError: true, timeout: 120_000 },
  );
  invalidateProjectMetadataCache();
  sttmLatestPointers.delete(sttmId);
  return result;
}

export async function getPostSaveJobStatus(
  sttmId: string,
  jobId: string,
): Promise<STTMPostSaveJobStatus> {
  return getApiData<STTMPostSaveJobStatus>(API_ROUTES.sttms.postSaveJob(sttmId, jobId));
}

export async function publishSttm(
  sttmId: string,
  payload: STTMPublishPayload,
): Promise<JsonRecord> {
  const result = await postEnvelopeData<JsonRecord>(
    API_ROUTES.sttms.publish(sttmId),
    buildApiEnvelope("sttms.publish", payload, { sttm_id: sttmId }),
  );
  invalidateProjectMetadataCache();
  sttmLatestPointers.delete(sttmId);
  return result;
}
