"""Attribute actual serialized message characters without dumping customer content."""
from collections import defaultdict
import json


DICTIONARIES = {
    "$ctx": "context_value_dictionary",
    "$exact_record": "exact_record_dictionary",
    "$exact_line": "exact_text_lines",
}


def expand_packet(packet):
    """Resolve only encodings emitted by the local exact-packet builder."""
    metadata = {*DICTIONARIES.values(), "exact_object_shapes", "exact_record_encoding",
                "context_value_encoding", "exact_object_encoding", "exact_text_encoding"}
    def expand(value):
        if isinstance(value, dict):
            for marker, field in DICTIONARIES.items():
                if set(value) == {marker}:
                    return expand(packet[field][value[marker]])
            if set(value) == {"$exact_object"}:
                index, children = value["$exact_object"]
                keys = packet["exact_object_shapes"][index]
                if len(keys) != len(children):
                    raise ValueError("Invalid exact object shape")
                return dict(zip(keys, map(expand, children)))
            if set(value) == {"$exact_text"}:
                return "".join(map(expand, value["$exact_text"]))
            return {key: expand(child) for key, child in value.items()}
        return list(map(expand, value)) if isinstance(value, list) else value
    return {key: expand(value) for key, value in packet.items() if key not in metadata}


def export_review(folder, index, store, packet, encoded):
    """User-requested private local artifact; never log its customer contents."""
    from pathlib import Path
    folder = Path(folder)
    name = f"batch-{index + 1:02d}"
    destination = folder / name
    destination.mkdir(parents=True, exist_ok=False)
    def write(path, value):
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    readable = expand_packet(packet)
    # Verify expansion against the unfactored request and completed exact reads.
    expected = store.manifest()
    expected["retrieved_auto_map_context"] = readable["retrieved_auto_map_context"]
    from app.core.automap_retrieval import PROTOCOL
    if not store.focused:
        expected["data"]["message"] = ((expected["data"].get("message") or "")
                                        + "\nApplication batch retrieval contract: " + PROTOCOL)
    if expected != readable:
        raise ValueError("Readable export did not match the exact unfactored manifest")
    write(destination / "01-complete-readable-context.json", readable)
    (destination / "02-exact-model-packet.json").write_text(encoded(packet), encoding="utf-8")
    (destination / "03-exact-complete-message.json").write_text(encoded([
        {"role": "user", "content": [{"type": "text", "text": encoded(packet)}]}
    ]), encoding="utf-8")
    context = readable["context"]
    retrieval = context.get("auto_map_retrieval", {})
    groups = {"learning": {"inline": context.get("learning_context", {}), "reads": []},
              "semantics": {"relation_registry": retrieval.get("relation_registry"),
                            "column_catalog": retrieval.get("column_catalog"),
                            "table_contracts": retrieval.get("table_contracts"), "reads": []},
              "workspace-graph": {"inline": {key: value for key, value in context.items()
                                              if key not in {"learning_context", "auto_map_retrieval"}}, "reads": []}}
    for item in readable.get("retrieved_auto_map_context", []):
        request = item.get("request", {})
        operation = request.get("operation")
        group = ("learning" if operation in {"evidence", "discover"} else
                 "semantics" if operation in {"column", "columns", "table", "contract"} else
                 "learning" if str(request.get("relation_id", "")).startswith("historical:") else
                 "workspace-graph")
        groups[group]["reads"].append(item)
    for category, value in groups.items():
        write(destination / f"review-{category}.json", value)
    write(destination / "review-targets-and-instructions.json", {"data": readable["data"],
        "retrieval_instruction": readable.get("retrieval_instruction"), "retrieval_manifest": {
            key: value for key, value in retrieval.items() if key not in {"column_catalog", "table_contracts"}}})
    write(destination / "NOT-SENT-historical-dependency-bodies.json", {
        "notice": "Stored exact bodies behind recipe handles. Not present in this model message unless read later.",
        "dependencies": store.historical_dependencies,
    })
    sizes = breakdown(packet, encoded)
    write(destination / "sizes.json", {"targets": list(store.targets), **sizes})
    if index == 0:
        write(folder / "NOT-SENT-original-semantic-bundle.json", {
            "notice": "Original semantic_context from the saved request. NOT all sent in the current batch messages.",
            "semantic_context": (store.original.get("context") or {}).get("semantic_context"),
        })
    return {"folder": str(destination), "verified_exact_expansion": True,
            "targets": list(store.targets), **sizes}


def breakdown(packet, encoded):
    def wire_size(value):
        # The packet is itself serialized as a JSON string inside content.text.
        return len(json.dumps(encoded(value), ensure_ascii=False)) - 2

    owners = defaultdict(set)
    groups = defaultdict(int)

    def expanded(value):
        if isinstance(value, dict):
            for marker, field in DICTIONARIES.items():
                if set(value) == {marker}:
                    return expanded(packet[field][value[marker]])
            if set(value) == {"$exact_object"}:
                index, children = value["$exact_object"]
                return dict(zip(packet["exact_object_shapes"][index], map(expanded, children)))
            if set(value) == {"$exact_text"}:
                return "".join(map(expanded, value["$exact_text"]))
            return {key: expanded(child) for key, child in value.items()}
        return list(map(expanded, value)) if isinstance(value, list) else value

    def references(value, owner):
        if isinstance(value, dict):
            for marker, field in DICTIONARIES.items():
                if set(value) == {marker}:
                    identity = (field, value[marker])
                    if owner not in owners[identity]:
                        owners[identity].add(owner)
                        references(packet[field][value[marker]], owner)
                    return
            if set(value) == {"$exact_object"}:
                index, children = value["$exact_object"]
                owners[("exact_object_shapes", index)].add(owner)
                for child in children:
                    references(child, owner)
                return
            for child in value.values():
                references(child, owner)
        elif isinstance(value, list):
            for child in value:
                references(child, owner)

    def charge(value, owner):
        groups[owner] += wire_size(value)
        references(value, owner)

    def fields(value):
        # Open only structural object encoding; preserve value dictionaries.
        if isinstance(value, dict) and set(value) == {"$exact_object"}:
            index, children = value["$exact_object"]
            return dict(zip(packet["exact_object_shapes"][index], children))
        return value if isinstance(value, dict) else {}

    for key, value in fields(packet.get("context", {})).items():
        if key == "learning_context":
            charge(value, "learning")
        elif key == "auto_map_retrieval":
            for field, child in fields(value).items():
                if field in {"column_catalog", "table_contracts", "relation_registry"}:
                    charge(child, "semantics")
                else:
                    charge(child, "protocol_overhead")
        else:
            charge(value, "workspace_graph")
    for item in packet.get("retrieved_auto_map_context", []):
        request = expanded(fields(item).get("request", {}))
        operation = request.get("operation")
        owner = ("learning" if operation in {"evidence", "discover"} else
                 "semantics" if operation in {"column", "columns", "table", "contract"} else
                 "learning" if str(request.get("relation_id", "")).startswith("historical:") else
                 "workspace_graph")
        charge(item, owner)
    for key, value in packet.items():
        if key in {"data"}:
            charge(value, "target_request")
        elif key not in {"context", "retrieved_auto_map_context", *DICTIONARIES.values(),
                         "exact_object_shapes", "exact_record_encoding", "context_value_encoding",
                         "exact_object_encoding", "exact_text_encoding"}:
            charge(value, "protocol_overhead")
    dictionary_sizes = defaultdict(int)
    for (field, index), categories in owners.items():
        owner = next(iter(categories)) if len(categories) == 1 else "shared_dictionaries"
        cost = wire_size(packet[field][index])
        groups[owner] += cost
        dictionary_sizes[owner] += cost
    total = len(encoded([{"role": "user", "content": [{"type": "text", "text": encoded(packet)}]}]))
    # Field keys, separators, dictionary metadata and outer-message syntax.
    remainder = total - sum(groups.values())
    if remainder < 0:
        raise ValueError("Message attribution overlaps serialized content")
    groups["protocol_overhead"] += remainder
    return {"total_message_chars": total, "chars": dict(groups),
            "percent": {key: round(value * 100 / total, 2) for key, value in groups.items()},
            "dictionary_chars": dict(dictionary_sizes),
            "method": "Exclusive encoded payload plus exclusively owned dictionaries; cross-category dictionaries reported separately; JSON escaping included"}