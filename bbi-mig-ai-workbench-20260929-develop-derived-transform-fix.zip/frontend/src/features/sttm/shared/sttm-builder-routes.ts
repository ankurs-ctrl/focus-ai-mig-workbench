/**
 * STTM builder route helpers.
 *
 * Durable STTM ids can include the substring "mapping" (e.g. `mapping-1`).
 * Never use `pathname.includes('/mapping')` — it treats selection routes as
 * workspace routes and hides the source/target sidebar.
 */

/** True for `/…/mapping` or `/…/summary` workspace steps (optional trailing slash). */
export function isSttmBuilderWorkspacePath(pathname: string): boolean {
  return /\/(?:mapping|summary)\/?$/.test(pathname);
}

export function isSttmBuilderSummaryPath(pathname: string): boolean {
  return /\/summary\/?$/.test(pathname);
}

export function isSttmBuilderMappingPath(pathname: string): boolean {
  return /\/mapping\/?$/.test(pathname);
}

export type SttmBuilderAssistantPage = "builder" | "mapping" | "summary";

export function getSttmBuilderAssistantPage(pathname: string): SttmBuilderAssistantPage {
  if (isSttmBuilderSummaryPath(pathname)) return "summary";
  if (isSttmBuilderMappingPath(pathname)) return "mapping";
  return "builder";
}
