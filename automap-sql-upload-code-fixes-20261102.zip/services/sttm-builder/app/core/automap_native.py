"""Opt-in native agent investigation and independent checkpoint delivery.

The backend has no candidate-pagination/reasoning loop here. One agent run owns
its registered tool calls; a bounded new working window requires recorded new
evidence and an explicit unresolved evidence question. Model text never applies
mappings in place of a validated durable SubmitProposals checkpoint.
"""

import asyncio
from copy import deepcopy
from dataclasses import replace
import json
import time
from app.core.automap_native_contract import (
    VERSION,
    TOOLS,
    build_snapshot,
    digest,
    encoded,
    enabled,
    seed_packet,
    target_id,
    frozen_request,
    identifier_key,
)
from app.core.automap_native_store import NativeJobStore, NativeStoreError


def batch_identity(req):
    return digest(
        [
            VERSION,
            str(req.request_id),
            str(req.context.project_id),
            str(req.context.sttm_id),
            req.context.prepared_context_hash,
            req.meta.get("auto_map_shared_input_revision"),
            sorted(
                target_id(item.target_table.qualified_name, item.target_attribute)
                for item in req.data.attributes
            ),
            req.meta.get("auto_map_resolution_mode"),
        ]
    )


def native_config(settings, metadata, *, kind="source"):
    return {
        "version": VERSION,
        "kind": kind,
        "metadata": metadata,
        "column_search_service": metadata + ".CSS_AUTOMAP_SOURCE_COLUMNS_V2",
        "max_tool_calls": getattr(settings, "automap_native_max_tool_calls", 64),
        "window_tool_calls": getattr(settings, "automap_native_window_tool_calls", 32),
        "tool_output_bytes": 32768,
        "evidence_budget_bytes": min(160000, settings.agent_outbound_message_max_bytes),
        "validation_seconds": 10,
        "analyst_seconds": 30,
        "analyst_query_seconds": 15,
        "analyst_slots": 4,
    }


def make_response(req, row, *, incomplete_reason=None):
    from app.schema.sttm_builder import (
        STTMBuilderResponse,
        SourceMappingResult,
        AttributeMapping,
        SubAgent,
        STTMStatus,
    )

    mappings = {}
    review = []
    coverage = []
    checkpointed = []
    for identity, target in row["SNAPSHOT"]["targets"].items():
        proposal = row["STATE"]["proposals"].get(identity)
        valid = proposal and proposal.get("stage") == "validated"
        if valid:
            expected = proposal.get("proposal_hash")
            if expected != digest(
                {
                    key: value
                    for key, value in proposal.items()
                    if key != "proposal_hash"
                }
            ):
                raise NativeStoreError("Native checkpoint hash changed")
            if (
                proposal["snapshot_hash"] != row["SNAPSHOT_HASH"]
                or proposal["at"] > row["DEADLINE_EPOCH"]
            ):
                raise NativeStoreError("Native checkpoint is stale or late")
            mapping = AttributeMapping.model_validate(proposal["mapping"])
            checkpointed.append(target["name"])
            if proposal.get("review_only"):
                review.append(target["name"])
        else:
            alternatives = (
                (proposal or {})
                .get("mapping", {})
                .get("candidate_source_attributes", [])
            )
            mapping = AttributeMapping(
                source_attributes=[],
                candidate_source_attributes=alternatives,
                confidence_score=0,
                transformation_classification="unresolved",
                unmatched_reason=incomplete_reason
                or "Native investigation did not checkpoint a validated proposal for this target.",
            )
        mappings[target["name"]] = mapping
        coverage.append(
            {
                "target": target["name"],
                "target_binding_id": identity,
                "status": (
                    ("review_required" if proposal.get("review_only") else "grounded")
                    if valid and mapping.transformation_classification != "unresolved"
                    else "unresolved"
                ),
                "outcome_code": (
                    (
                        "uncertain_semantic_support"
                        if proposal.get("review_only")
                        else "grounded"
                    )
                    if valid and mapping.transformation_classification != "unresolved"
                    else (
                        row["STATE"]["deficits"].get(identity, {}).get("code")
                        or "no_supported_mapping"
                    )
                ),
                "coverage": {
                    "model_decision": bool(proposal),
                    "transformation_validated": bool(
                        valid and mapping.transformation_classification != "unresolved"
                    ),
                    "source_inventory": True,
                    "cte_contract": True,
                    "learning_evidence": any(
                        action.get("tool") == "SearchPrecedents"
                        and action.get("status") == "done"
                        and identity in action.get("target_ids", [])
                        for action in row["STATE"]["actions"].values()
                    ),
                },
            }
        )
    result = STTMBuilderResponse.from_invocation(
        req,
        thread_id=None,
        parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT,
        result=SourceMappingResult(mappings=mappings),
        message="Native Auto-map checkpoints; unsupported targets remain explicit.",
        status=(
            STTMStatus.NEEDS_INPUT
            if review
            or any(
                mapping.transformation_classification == "unresolved"
                for mapping in mappings.values()
            )
            else STTMStatus.COMPLETED
        ),
        meta={
            "auto_map_retrieval": {
                "strategy": VERSION,
                "target_count": len(mappings),
                "model_call_count": row["STATE"].get("provider_calls", 0),
                "agent_run_count": row["STATE"].get("provider_calls", 0),
                "analyst_request_count": sum(
                    item.get("operation") == "analyst"
                    and item.get("started_at") is not None
                    for item in row["STATE"].get("rpc", {}).values()
                ),
                "operation_count": row["STATE"]["tool_calls"],
                "model_call_count_scope": "Agent Run HTTP submissions; internal orchestration usage is reported in provider trace metadata.",
                "targets": coverage,
                "native_trace": row["STATE"]["trace"],
                "native_checkpoint_revision": row["STATE"]["revision"],
                "coverage_exhaustive": False,
            },
            "automap_evidence_review_only_targets": review,
            "auto_map_target_bindings": {
                target["name"]: identity
                for identity, target in row["SNAPSHOT"]["targets"].items()
            },
            "auto_map_native_checkpoint_targets": checkpointed,
            "auto_map_native_identity": {
                "batch_identity": batch_identity(req),
                "snapshot_hash": row["SNAPSHOT_HASH"],
                "input_revision": req.meta.get("auto_map_shared_input_revision"),
            },
            "auto_map_native_proposal_hashes": {
                identity: proposal["proposal_hash"]
                for identity, proposal in row["STATE"]["proposals"].items()
                if proposal["stage"] == "validated"
            },
            "auto_map_native_checkpoint_token": digest(
                {
                    identity: proposal["proposal_hash"]
                    for identity, proposal in row["STATE"]["proposals"].items()
                    if proposal["stage"] == "validated"
                }
            ),
            "auto_map_native_provisional": row["STATE"]["dispatcher"]
            not in {"terminal", "uncertain"},
        },
    )
    return result


def _bundle(service, req, decision, store, deadline):
    # Explicit local PAT login is server configuration, never a request/model
    # credential. Verify the existing agent session and native user before
    # provisioning independent same-caller leases. No session token is cloned.
    from copy import copy

    service = copy(service)
    settings = service._settings
    if settings.automap_native_pool_capacity:
        service._settings = settings.model_copy(
            update={
                "automap_parallel_context_v1": True,
                "automap_context_retrieval_v1": True,
                "automap_parallel_test_agent": settings.resolved_metadata_database
                + "."
                + settings.resolved_metadata_schema
                + ".AGT_AUTOMAP_SCAN_DEV_TEST",
                "automap_parallel_permit_table_fqn": settings.automap_native_permit_table_fqn,
                "automap_parallel_archive_table_fqn": settings.automap_native_archive_table_fqn,
                "automap_parallel_account_namespace": settings.automap_native_account_namespace,
                "automap_parallel_pool_epoch": settings.automap_native_pool_epoch,
                "automap_parallel_pool_capacity": settings.automap_native_pool_capacity,
            }
        )
    if (
        settings.local_dev_auth_enabled
        and settings.app_env == "local"
        and settings.normalized_snowflake_authenticator == "programmatic_access_token"
    ):
        import hmac
        from contextlib import contextmanager
        from app.core.snowflake import SnowflakeClient, get_local_transaction_pool
        from app.core.automap_runtime import _session_identity
        from app.core.warehouse_routing import WarehouseWorkload

        caller = _session_identity(service._session)
        model_session = (
            service._query_session
            if service._query_session is not None
            else service._session
        )
        model_caller = _session_identity(model_session)
        wrapper = SnowflakeClient.__new__(SnowflakeClient)
        wrapper._session = model_session
        auth = wrapper.get_rest_session_context()
        if (
            service._agent._auth_mode != "snowflake_token"
            or not hmac.compare_digest(auth.token, service._agent._token)
            or caller != model_caller
            or caller.native_user != settings.snowflake_user.upper()
            or (service._agent._role and caller.role != service._agent._role)
        ):
            raise NativeStoreError("Local PAT caller and model session do not match")
        service._agent = copy(service._agent)
        service._agent._role = caller.role
        pool = get_local_transaction_pool(
            settings,
            caller.role,
            WarehouseWorkload.AUTOMAP,
            purpose="native-automap-v1",
            maximum=min(32, max(16, 2 * (settings.automap_native_pool_capacity or 4))),
        )

        @contextmanager
        def sessions():
            with pool.lease() as client:
                yield client.session

        service._parallel_caller = caller
        service._parallel_session_factory = sessions
    from app.core.automap_runtime import build_parallel_runtime

    return build_parallel_runtime(
        service, req=req, decision=decision, store=store, deadline=deadline
    )


def _runtime(
    service, req, decision, store, bundle, deadline, *, kind="source", target_ids=None
):
    from app.core.automap_native_transport import NativeAgentTransport
    from app.core.automap_scan_transport import ScanTransportConfig
    from app.core.automap_fast_transport import FastModelRuntime
    from app.core.automap_shards import MessageBudget
    from app.core.automap_input_budget import input_limits
    from app.core.automap_native_store import namespace

    metadata = namespace(
        service._settings.resolved_metadata_database
        + "."
        + service._settings.resolved_metadata_schema
    )
    agent = metadata + (
        ".AGT_AUTOMAP_INVESTIGATOR_V1"
        if kind == "source"
        else ".AGT_AUTOMAP_TRANSFORMATION_V1"
    )
    # A configuration GET cannot consume the entire mapping deadline.
    from app.core.snowflake_agent import _shared_http_client

    response = _shared_http_client(service._agent._base_url).get(
        service._agent._base_url
        + service._agent._build_endpoint(agent).removesuffix(":run"),
        headers=service._agent._build_headers(),
        timeout=15,
    )
    if response.status_code != 200 or len(response.content) > 256000:
        raise NativeStoreError("Native agent specification unavailable or oversized")
    spec = response.json().get("agent_spec")
    if isinstance(spec, str):
        import yaml

        spec = yaml.safe_load(spec)
    if not isinstance(spec, dict):
        raise NativeStoreError("Native agent specification is malformed")
    names = {item.get("tool_spec", {}).get("name") for item in spec.get("tools", [])}
    expected = (
        set(TOOLS)
        if kind == "source"
        else {
            "ReadEvidence",
            "InspectRelationships",
            "ValidateProposal",
            "SubmitProposals",
        }
    )
    if names != expected:
        raise NativeStoreError(
            "Native agent registered tools do not match deployed protocol"
        )
    resources = spec.get("tool_resources") or {}
    for name in expected:
        identifier = (
            metadata
            + ".SP_AUTOMAP_"
            + {
                "SearchSources": "SEARCH_SOURCES",
                "ReadEvidence": "READ_EVIDENCE",
                "InspectRelationships": "INSPECT_RELATIONSHIPS",
                "SearchPrecedents": "SEARCH_PRECEDENTS",
                "AskPreparedAnalyst": "ASK_PREPARED_ANALYST",
                "ValidateProposal": (
                    "VALIDATE_RULE" if kind == "rule" else "VALIDATE_PROPOSAL"
                ),
                "SubmitProposals": (
                    "SUBMIT_RULE" if kind == "rule" else "SUBMIT_PROPOSALS"
                ),
            }[name]
        )
        if (
            resources.get(name, {}).get("identifier") != identifier
            or resources[name].get("type") != "procedure"
        ):
            raise NativeStoreError(
                "Native tool resources do not match trusted metadata procedures"
            )
    if kind == "rule":
        from app.core.automap_admission import ScanCallAdmission
        from uuid import uuid4

        gate = ScanCallAdmission(
            bundle.admission.store,
            job_id=uuid4().hex,
            caller_id=bundle.admission.caller_id,
        )
        bundle = replace(bundle, admission=gate)
    # Check deployment resources with a separate caller lease, before a model
    # permit/thread is acquired. Probes contain no evidence or credentials.
    try:
        with bundle.archive._factory() as session:

            def sql(query, params=None):
                return session.sql(query, params=params or []).collect(
                    statement_params={
                        "STATEMENT_TIMEOUT_IN_SECONDS": "5",
                        "LOCK_TIMEOUT": "1",
                    }
                )

            probe = sql(
                "CALL "
                + resources["ReadEvidence"]["identifier"]
                + "(REQUEST_JSON => ?)",
                ['{"protocol_probe":"automap_native_v1"}'],
            )
            from app.core.automap_native_store import plain

            body = json.loads(next(iter(plain(probe[0]).values())))
            if body != {
                "protocol": VERSION,
                "tool": "ReadEvidence",
                "phase": "source",
                "metadata": metadata,
            }:
                raise NativeStoreError("Native procedure protocol mismatch")
            names = {
                str(plain(row).get("name") or plain(row).get("NAME"))
                for row in sql("SHOW PROCEDURES IN SCHEMA " + metadata)
            }
            if (
                not {
                    resources[name]["identifier"].rsplit(".", 1)[1] for name in expected
                }
                <= names
            ):
                raise NativeStoreError("Required registered procedures are unavailable")
            if kind == "source":
                sql(
                    "DESC CORTEX SEARCH SERVICE "
                    + metadata
                    + ".CSS_AUTOMAP_SOURCE_COLUMNS_V2"
                )
                inventory = [
                    plain(row)
                    for row in sql(
                        "SELECT SLOT_ID,STATE FROM "
                        + metadata
                        + ".TBL_AUTOMAP_NATIVE_ANALYST_SLOTS"
                    )
                ]
                if len(inventory) != 4 or {row["SLOT_ID"] for row in inventory} != {
                    0,
                    1,
                    2,
                    3,
                }:
                    raise NativeStoreError("Analyst pool inventory mismatch")
    except Exception:
        raise NativeStoreError(
            "Native tool configuration, caller grants or required Search index are unavailable"
        ) from None
    configured_hash = getattr(
        service._settings,
        "automap_native_" + ("source" if kind == "source" else "rule") + "_spec_sha256",
        "",
    )
    if digest(spec) != configured_hash:
        raise NativeStoreError("Pinned native agent specification changed")
    backend = NativeAgentTransport(
        allowed_tools=expected,
        agent_client=service._agent,
        http_client=bundle.backend._http_client,
        config=ScanTransportConfig(agent=agent, max_response_bytes=2000000),
        admission=bundle.admission,
    )
    bundle = replace(
        bundle,
        backend=backend,
        limits=replace(
            bundle.limits,
            selection_budget=MessageBudget(*input_limits(service._settings)),
        ),
    )
    model = FastModelRuntime(
        bundle=bundle,
        service=service,
        req=req,
        decision=decision,
        store=store,
        deadline=deadline,
        specialist_backend=backend if kind == "rule" else None,
    )
    model._target_ids = tuple(
        target_ids
        or sorted(
            target_id(item.target_table.qualified_name, item.target_attribute)
            for item in req.data.attributes
        )
    )
    return model, digest(spec)


def validate_final(raw, *, kind="source"):
    from app.core.automap_native_tools import load_json
    from app.core.sttm_builder import _normalize_sub_agent
    from app.schema.sttm_builder import SubAgent

    data = load_json(raw)
    allowed = {"status", "agent", "result"}
    expected = (
        SubAgent.SOURCE_MAPPING_AGENT
        if kind == "source"
        else SubAgent.TRANSFORMATION_AGENT
    )
    if (
        type(data) is not dict
        or set(data) != allowed
        or data["status"] != "completed"
        or type(data["agent"]) is not str
        or _normalize_sub_agent(data["agent"]) != expected
        or data["result"] != {"mappings": {}}
    ):
        raise NativeStoreError(
            "Native final answer must be a completed checkpoint summary, not an alternate mapping result"
        )


def project_native(req, settings):
    from app.core.agent_payload_budget import (
        AgentPayloadBudgetResult,
        AgentPayloadBudgetError,
    )
    from app.core.automap_input_budget import input_limits, wire_text

    try:
        from app.core.automap_batch import canonical_model_wire_request

        req = canonical_model_wire_request(req)
        snapshot = build_snapshot(req, validated_derived=[], strict_contracts=False)
        chars, bytes_ = input_limits(settings)
        messages = seed_packet(snapshot, "0" * 64, max_chars=chars, max_bytes=bytes_)
        text = wire_text(messages)
        if len(text) > chars or len(text.encode()) > bytes_:
            raise ValueError("Complete native seed exceeds input budget")
    except ValueError as error:
        raise AgentPayloadBudgetError(str(error)) from error
    return AgentPayloadBudgetResult(
        {"messages": messages},
        text,
        {
            "original_chars": len(text),
            "final_chars": len(text),
            "final_bytes": len(text.encode()),
            "compacted": False,
            "emergency_compaction": False,
            "fast_preflight": {
                "strategy": VERSION,
                "target_count": len(req.data.attributes),
                "source_inventory_count": len(snapshot["sources"]),
                "seed_bytes": len(text.encode()),
                "excluded_group_count": 0,
                "excluded_record_count": 0,
            },
        },
    )


def recover_checkpoints(store, req):
    """Same-caller parent recovery. This never dispatches/retries a model call."""
    handle = store.lookup(batch_identity(req))
    if not handle:
        return None
    row = store.load(handle, allow_expired=True)
    if row["SNAPSHOT"]["request"] != frozen_request(req):
        raise NativeStoreError(
            "Native checkpoint request/revision does not match frozen worker inputs"
        )
    # Successful specialist child checkpoints can be recovered even if the
    # source worker stopped before copying them into its parent checkpoint.
    for identity, proposal in list(row["STATE"]["proposals"].items()):
        if proposal["stage"] not in {"needs_rule", "rule_failed"}:
            continue
        child_handle = store.lookup(
            digest(
                [
                    handle,
                    identity,
                    proposal.get("source_proposal_hash", proposal["proposal_hash"]),
                    "rule",
                ]
            )
        )
        if not child_handle:
            continue
        child = store.load(child_handle, allow_expired=True)
        final = child["STATE"]["proposals"].get(identity)
        if not final or final["stage"] != "validated":
            continue
        if child["CONFIG"].get("parent_proposal_hash") != proposal["proposal_hash"]:
            continue
        make_response(req, child)
        _merge_rule(
            store, handle, row["SNAPSHOT"], identity, proposal, final, child_handle
        )
    return make_response(req, store.load(handle, allow_expired=True))


def _merge_rule(store, parent_handle, parent, identity, proposal, final, child_handle):
    if final["proposal_hash"] != digest(
        {k: v for k, v in final.items() if k != "proposal_hash"}
    ):
        raise NativeStoreError("Specialist checkpoint changed")
    with store.edit(parent_handle, allow_expired=True) as state:
        current = state["proposals"].get(identity)
        if not current or current["proposal_hash"] != proposal["proposal_hash"]:
            raise NativeStoreError("Source selection changed while specialist ran")
        final_parent = deepcopy(final)
        final_parent["snapshot_hash"] = parent["snapshot_hash"]
        final_parent["source_proposal_hash"] = proposal["proposal_hash"]
        final_parent["specialist_handle_hash"] = digest(child_handle)
        final_parent["proposal_hash"] = digest(
            {
                key: value
                for key, value in final_parent.items()
                if key != "proposal_hash"
            }
        )
        state["proposals"][identity] = final_parent
        state["trace"].append(
            {
                "stage": "specialist_checkpoint_validated",
                "at": time.time(),
                "counts": {"targets": 1},
            }
        )


def continuation_packet(snapshot, handle, state, settings):
    """Only target-specific active dependencies and literal reviewed excerpts."""
    active = {
        identity: target
        for identity, target in snapshot["targets"].items()
        if state["proposals"].get(identity, {}).get("stage")
        not in {"validated", "needs_rule", "rule_failed"}
    }
    if not active:
        return None
    focused = deepcopy(snapshot)
    focused["targets"] = active
    refs = {
        source
        for identity in active
        for source in state["candidates"].get(identity, [])
    }
    focused["sources"] = {
        identity: source
        for identity, source in snapshot["sources"].items()
        if identity in refs
    }
    # Frozen snapshot hash/handle remain the same; never present focused state
    # as a different authority or lose evidence dependencies in the tool store.
    from app.core.automap_input_budget import input_limits, wire_text

    messages = seed_packet(
        focused,
        handle,
        max_chars=input_limits(settings)[0],
        max_bytes=input_limits(settings)[1],
    )
    packet = json.loads(messages[0]["content"][0]["text"])
    packet.pop("existing_definitions", None)
    packet.pop("learning_evidence_index", None)
    packet["active_candidates"] = {
        key: state["candidates"].get(key, []) for key in active
    }
    packet["current_deficits"] = {
        key: state["deficits"][key] for key in active if key in state["deficits"]
    }
    packet["prior_decisions"] = {
        key: value for key, value in state["proposals"].items() if key in active
    }
    relevant = {
        evidence
        for target in active
        for dependency in state.get("dependencies", {}).get(target, {}).values()
        for evidence in dependency["evidence_ids"]
    }
    for source in focused["sources"].values():
        relevant.update([source["evidence_id"], source["owner_id"]])
    target_names = {identifier_key(target["name"]) for target in active.values()}
    mandatory = [
        identity
        for identity in snapshot["mandatory_evidence"]
        if not snapshot["records"][identity]["body"].get("target_id")
        or identifier_key(snapshot["records"][identity]["body"]["target_id"])
        in target_names
    ]
    packet["mandatory_evidence_ids"] = mandatory
    relevant.update(mandatory)
    packet["read_coverage"] = {
        identity: spans
        for identity, spans in state["reads"].items()
        if identity in relevant
    }
    packet["verified_excerpts"] = {
        key: value
        for key, value in state.get("verified_notes", {}).items()
        if key in active
    }
    packet["unresolved_question"] = (
        "Resolve only the listed evidence/validation deficits using new evidence or a specific proposal repair. Stop on unchanged missing business input."
    )
    messages[0]["content"][0]["text"] = encoded(packet)
    text = wire_text(messages)
    chars, bytes_ = input_limits(settings)
    if len(text) > chars or len(text.encode()) > bytes_:
        return None
    return messages


async def invoke_native(service, req, *, governance_decision=None):
    """Private worker entrypoint. Its store is recoverable without HTTP delivery."""
    if not enabled(service._settings, req.context.project_id):
        raise NativeStoreError("Native Auto-map is not enabled for this project")
    from app.core.automap_batch import validate_fast_request
    from app.core.automap_retrieval import AutoMapContext
    from app.core.automap_fast_context import (
        request_deadline,
        validate_derived_output_contracts,
    )

    validate_fast_request(req, service._settings)
    decision = governance_decision or service._build_governance_decision(req)
    service._model_guard.assert_model_target_allowed(
        operation=req.operation.value, target="agent", decision=decision
    )
    req = service._govern_request_for_model(req, decision)
    validate_fast_request(req, service._settings)
    deadline = request_deadline(req.meta) - 5
    proof = req.meta.get("_automap_native_validation")
    graph = req.context.relation_graph
    if graph is None or not graph.nodes:
        raise NativeStoreError("Native investigation requires a prepared source graph")
    derived = {
        node.relation_id
        for node in graph.nodes
        if node.kind.value in {"DERIVED_SOURCE", "CTE"}
    }
    if (
        isinstance(proof, dict)
        and proof.get("graph_hash") == digest(graph.model_dump(mode="json"))
        and isinstance(proof.get("proofs"), dict)
        and derived <= proof["proofs"].keys()
    ):
        from app.core.automap_fast_context import hydrate_authored_cte_graph

        if hydrate_authored_cte_graph(req).context.relation_graph != graph:
            raise NativeStoreError(
                "Current authored CTE SQL no longer matches validated graph"
            )
        proofs = proof["proofs"]
    else:
        if derived and service._query_session is None:
            raise NativeStoreError("Server CTE validation session is unavailable")
        proofs = validate_derived_output_contracts(req, service._query_session)
    snapshot = await asyncio.to_thread(build_snapshot, req, validated_derived=proofs)
    legacy = AutoMapContext(snapshot["request"])
    legacy.manifest()
    bundle = await asyncio.to_thread(_bundle, service, req, decision, legacy, deadline)
    source_runtime, spec_hash = await asyncio.to_thread(
        _runtime, service, req, decision, legacy, bundle, deadline
    )
    sessions = bundle.archive._factory
    from app.core.automap_native_store import namespace

    metadata = namespace(
        service._settings.resolved_metadata_database
        + "."
        + service._settings.resolved_metadata_schema
    )
    config = native_config(service._settings, metadata)
    config["agent_spec_hash"] = spec_hash
    # Bundle identity is verified once from existing prepared storage. Do not
    # refresh semantics during tool reads or accept an arbitrary client hash.
    if snapshot["bundle"].get("id"):
        record = service._semantic_context_service.get_bundle(
            bundle_id=snapshot["bundle"]["id"]
        )
        if not record:
            raise NativeStoreError("Prepared semantic bundle is unavailable")

        def table_key(table):
            if isinstance(table, dict):
                table = ".".join(
                    str(table.get(key) or "") for key in ("database", "schema", "table")
                )
            from sqlglot import exp, parse_one

            node = parse_one(table, read="snowflake", into=exp.Table)
            return tuple(
                part.name if part.args.get("quoted") else part.name.upper()
                for part in node.parts
            )

        expected = {
            table_key(table.qualified_name) for table in req.context.source_tables
        }
        actual_sources = {table_key(table) for table in record.get("source_tables", [])}
        covered = expected == actual_sources and set(
            req.context.selected_derived_sources or []
        ) == set(record.get("derived_source_ids") or [])
        snapshot["bundle"]["coverage_validated"] = covered
        actual = record.get("bundle_hash")
        if snapshot["bundle"].get("hash") and actual != snapshot["bundle"]["hash"]:
            raise NativeStoreError("Prepared semantic bundle hash changed")
        snapshot["bundle"]["hash"] = actual
        snapshot["snapshot_hash"] = digest(
            {key: value for key, value in snapshot.items() if key != "snapshot_hash"}
        )

    def db(fn):
        with sessions() as session:
            return fn(NativeJobStore(session, metadata))

    handle = db(
        lambda store: store.create(
            snapshot,
            config,
            batch_identity=batch_identity(req),
            deadline_at=req.meta["_automap_deadline"] - 5,
        )
    )
    should_dispatch = False

    def claim(store):
        nonlocal should_dispatch
        with store.edit(handle) as state:
            if state["dispatcher"] == "new":
                state["dispatcher"] = "running"
                should_dispatch = True

    db(claim)
    if not should_dispatch:
        return service._postflight_guard.finalize_sttm_response(
            make_response(
                req,
                db(lambda store: store.load(handle, allow_expired=True)),
                incomplete_reason="Native job already dispatched; existing checkpoints recovered without replaying a model POST.",
            ),
            decision,
        )
    db(
        lambda store: store.trace(
            handle,
            "worker_native_started",
            counts={"targets": len(req.data.attributes)},
        )
    )
    from app.core.automap_input_budget import input_limits

    chars, bytes_ = input_limits(service._settings)
    messages = seed_packet(snapshot, handle, max_chars=chars, max_bytes=bytes_)
    source_error = None

    async def source():
        nonlocal source_error
        outgoing = messages
        progress = None
        for window in range(
            getattr(service._settings, "automap_native_max_windows", 2)
        ):
            try:
                raw, _, diagnostics = await asyncio.to_thread(
                    source_runtime.run,
                    outgoing,
                    call_index=source_runtime.next_call_index,
                )
                validate_final(raw)
                await asyncio.to_thread(
                    db, lambda store: store.trace(handle, "provider_response_archived")
                )
            except Exception as error:
                source_error = type(error).__name__

                def record_failure(store):
                    with store.edit(handle, allow_expired=True) as failed_state:
                        for identity in snapshot["targets"]:
                            if identity not in failed_state["proposals"]:
                                failed_state["deficits"][identity] = {
                                    "code": "native_runtime_failure",
                                    "stage": "source_investigation",
                                    "failure_type": source_error,
                                }
                        failed_state["trace"].append(
                            {
                                "stage": "source_investigation_failed",
                                "at": time.time(),
                                "counts": {"failure_type": source_error},
                            }
                        )

                await asyncio.to_thread(db, record_failure)
                return  # No replay of an uncertain POST.
            row = await asyncio.to_thread(
                db, lambda store: store.load(handle, allow_expired=True)
            )
            state = row["STATE"]
            current = digest(
                [
                    state["reads"],
                    state["candidates"],
                    {
                        key: {"mapping": value["mapping"], "stage": value["stage"]}
                        for key, value in state["proposals"].items()
                    },
                ]
            )
            deficits = state["deficits"] or any(
                item.get("stage") == "needs_evidence"
                for item in state["proposals"].values()
            )
            exhausted = state.get("window_exhausted", False)
            if not (deficits or exhausted) or current == progress or not state["reads"]:
                return
            if window + 1 >= getattr(
                service._settings, "automap_native_max_windows", 2
            ):
                return
            outgoing = continuation_packet(snapshot, handle, state, service._settings)
            if not outgoing:
                return
            progress = current

            def advance(store):
                with store.edit(handle) as current_state:
                    current_state["window"] += 1
                    current_state["window_calls"] = 0
                    current_state["delivered_bytes"] = 0
                    current_state["window_exhausted"] = False
                    current_state["trace"].append(
                        {
                            "stage": "focused_window_started",
                            "at": time.time(),
                            "counts": {"window": window + 1},
                        }
                    )

            await asyncio.to_thread(db, advance)

    source_task = asyncio.create_task(source())
    pending_rules = {}
    rpc_tasks = {}
    processed = set()
    telemetry = set()

    def consume(task):
        try:
            task.result()
        except BaseException:
            pass

    from app.core.automap_native_rpc import execute as execute_rpc, http_port

    api = http_port(service._agent)

    async def rule(identity, proposal):
        # Separate batch child stores and independent caller sessions permit
        # early specialist execution without sharing a Snowpark session.
        try:
            await _run_rule(
                service,
                req,
                decision,
                legacy,
                bundle,
                sessions,
                metadata,
                handle,
                snapshot,
                identity,
                proposal,
                deadline,
            )
        except Exception:

            def failed(store):
                with store.edit(handle, allow_expired=True) as state:
                    current = state["proposals"].get(identity)
                    if (
                        current
                        and current["proposal_hash"] == proposal["proposal_hash"]
                    ):
                        state["deficits"][identity] = {
                            "code": "specialist_not_checkpointed"
                        }

            await asyncio.to_thread(db, failed)

    while time.monotonic() < deadline:
        row = await asyncio.to_thread(
            db, lambda store: store.load(handle, allow_expired=True)
        )
        transport = source_runtime.bundle.backend
        receipt = transport.provider_received_at
        if receipt is not None and receipt not in telemetry:
            telemetry.add(receipt)

            def receipt_trace(store):
                with store.edit(handle, allow_expired=True) as state:
                    state["trace"].append(
                        {
                            "stage": "provider_received",
                            "at": receipt,
                            "counts": transport.provider_usage,
                        }
                    )
                    if transport.provider_parsed_at is not None:
                        state["trace"].append(
                            {
                                "stage": "provider_parsed",
                                "at": transport.provider_parsed_at,
                                "counts": {},
                            }
                        )

            await asyncio.to_thread(db, receipt_trace)
        for key, operation in row["STATE"].get("rpc", {}).items():
            if (
                operation["stage"] == "pending"
                and key not in rpc_tasks
                and sum(not task.done() for task in rpc_tasks.values()) < 4
            ):
                rpc_tasks[key] = asyncio.create_task(
                    asyncio.to_thread(
                        db, lambda store, key=key: execute_rpc(store, handle, key, api)
                    )
                )
                rpc_tasks[key].add_done_callback(consume)
        for identity, proposal in row["STATE"]["proposals"].items():
            if proposal["stage"] == "needs_rule" and identity not in processed:
                processed.add(identity)
                pending_rules[identity] = asyncio.create_task(
                    rule(identity, deepcopy(proposal))
                )
        if source_task.done() and all(task.done() for task in pending_rules.values()):
            break
        await asyncio.sleep(0.5)
    # Deadline is cooperative; never wait for a timed-out HTTP/thread operation
    # merely to construct the result or recycle its uncertain remote permit.
    tasks = [source_task, *pending_rules.values()]
    for task in tasks:
        if task.done():
            try:
                task.result()
            except Exception:
                pass

    def finish(store):
        with store.edit(handle, allow_expired=True) as state:
            state["dispatcher"] = (
                "terminal" if all(task.done() for task in tasks) else "uncertain"
            )
            state["provider_calls"] = (
                source_runtime.next_call_index - 1 + len(pending_rules)
            )
            state["trace"].append(
                {
                    "stage": "worker_response_ready",
                    "at": time.time(),
                    "counts": {"source_error": source_error is not None},
                }
            )

    await asyncio.to_thread(db, finish)
    response = make_response(
        req,
        await asyncio.to_thread(
            db, lambda store: store.load(handle, allow_expired=True)
        ),
        incomplete_reason=(
            "Native investigation or specialist did not complete; validated sibling checkpoints were retained."
            if source_error
            else None
        ),
    )
    return service._postflight_guard.finalize_sttm_response(response, decision)


async def _run_rule(
    service,
    req,
    decision,
    legacy,
    bundle,
    sessions,
    metadata,
    parent_handle,
    parent,
    identity,
    proposal,
    deadline,
):
    from app.core.automap_input_budget import input_limits

    child = deepcopy(parent)
    child["targets"] = {identity: child["targets"][identity]}
    selected = proposal["mapping"]
    refs = set(
        selected["source_attributes"]
        + selected["source_dependencies"]
        + selected["candidate_source_attributes"]
    )
    child["sources"] = {
        key: value
        for key, value in child["sources"].items()
        if value["source_ref"] in refs
    }
    child["existing_rows"] = [
        row
        for row in child["existing_rows"]
        if identifier_key(row.get("target_column") or row.get("target_attribute"))
        == identifier_key(child["targets"][identity]["name"])
    ]
    child["parent_snapshot_hash"] = parent["snapshot_hash"]
    child["snapshot_hash"] = digest(
        {key: value for key, value in child.items() if key != "snapshot_hash"}
    )
    config = native_config(service._settings, metadata, kind="rule")
    config["selected_mapping"] = selected
    config["parent_proposal_hash"] = proposal["proposal_hash"]
    config["parent_handle"] = parent_handle

    def db(fn):
        with sessions() as session:
            return fn(NativeJobStore(session, metadata))

    runtime, spec_hash = await asyncio.to_thread(
        _runtime,
        service,
        req,
        decision,
        legacy,
        bundle,
        deadline,
        kind="rule",
        target_ids=(identity,),
    )
    config["agent_spec_hash"] = spec_hash
    handle = await asyncio.to_thread(
        db,
        lambda store: store.create(
            child,
            config,
            batch_identity=digest(
                [parent_handle, identity, proposal["proposal_hash"], "rule"]
            ),
            deadline_at=req.meta["_automap_deadline"] - 5,
        ),
    )
    messages = seed_packet(
        child,
        handle,
        max_chars=input_limits(service._settings)[0],
        max_bytes=input_limits(service._settings)[1],
    )
    packet = json.loads(messages[0]["content"][0]["text"])
    packet["selected_mapping"] = selected
    packet["instruction"] = (
        "Generate an executable rule for the frozen selected mapping. Do not change selected bindings or Values. Read exact evidence with native tools and SubmitProposals with the final expression. "
        + packet["instruction"]
    )
    messages[0]["content"][0]["text"] = encoded(packet)
    wire = encoded(messages)
    chars, bytes_ = input_limits(service._settings)
    if len(wire) > chars or len(wire.encode()) > bytes_:
        raise NativeStoreError("Focused specialist packet exceeds input budget")
    claimed = False

    def claim(store):
        nonlocal claimed
        with store.edit(handle) as state:
            if state["dispatcher"] == "new":
                state["dispatcher"] = "running"
                claimed = True

    await asyncio.to_thread(db, claim)
    if claimed:
        from app.core.automap_native_rpc import execute as execute_rpc, http_port

        api = http_port(service._agent)
        tasks = {}

        def consume(task):
            try:
                task.result()
            except BaseException:
                pass

        model = asyncio.create_task(
            asyncio.to_thread(
                runtime.run, messages, call_index=1, stage="transformation_rule"
            )
        )
        model.add_done_callback(consume)
        while not model.done() and time.monotonic() < deadline:
            child_row = await asyncio.to_thread(
                db, lambda store: store.load(handle, allow_expired=True)
            )
            for key, operation in child_row["STATE"].get("rpc", {}).items():
                if (
                    operation["stage"] == "pending"
                    and key not in tasks
                    and sum(not task.done() for task in tasks.values()) < 4
                ):
                    tasks[key] = asyncio.create_task(
                        asyncio.to_thread(
                            db,
                            lambda store, key=key: execute_rpc(store, handle, key, api),
                        )
                    )
                    tasks[key].add_done_callback(consume)
            await asyncio.sleep(0.25)
        if not model.done():
            raise NativeStoreError(
                "Specialist deadline exceeded; no uncertain call was replayed"
            )
        raw, _, _ = model.result()
        validate_final(raw, kind="rule")
    row = await asyncio.to_thread(
        db, lambda store: store.load(handle, allow_expired=True)
    )
    make_response(req, row)
    final = row["STATE"]["proposals"].get(identity)
    if not final or final["stage"] != "validated":
        raise NativeStoreError("Specialist did not checkpoint a validated rule")
    await asyncio.to_thread(
        db,
        lambda store: _merge_rule(
            store, parent_handle, parent, identity, proposal, final, handle
        ),
    )
