import json
import logging
import time
from collections.abc import Iterator

import httpx
from fastapi import Request

from app.auth.models import AppPersona
from app.core.config import Settings
from app.core.exceptions import SnowflakeAgentError
from app.schema.sttm_builder import Interface, STTMBuilderEnvelopeRequest, STTMBuilderResponse

logger = logging.getLogger(__name__)

_FORWARDED_HEADER_NAMES = (
    "Sf-Context-Current-User",
    "Sf-Context-Current-User-Email",
    "Sf-Context-Current-User-Token",
    "X-Request-Id",
    "X-Trace-Id",
)


class AutoMappingProxyClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._base_url = settings.auto_mapping_service_url.strip().rstrip("/")
        self._timeout = settings.auto_mapping_service_timeout_seconds
        self._retry_attempts = max(1, settings.auto_mapping_service_retry_attempts)

    @property
    def enabled(self) -> bool:
        return bool(self._base_url)

    def should_delegate(self, req: STTMBuilderEnvelopeRequest) -> bool:
        return self.enabled and req.data.intent == Interface.AUTO_MAP

    def invoke(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderResponse:
        if not self.should_delegate(req):
            raise SnowflakeAgentError("Auto-mapping worker service is not configured.")

        payload = req.model_dump(mode="json")
        headers = self._forward_headers(request)
        last_error: Exception | None = None
        endpoint = f"{self._base_url}/api/v1/auto-mapping/invoke"
        logger.info(
            "Dispatching auto-map request_id=%s to worker endpoint=%s",
            req.request_id,
            endpoint,
        )

        for attempt in range(1, self._retry_attempts + 1):
            try:
                with httpx.Client(timeout=self._timeout) as client:
                    response = client.post(
                        endpoint,
                        headers=headers,
                        json=payload,
                    )
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt >= self._retry_attempts:
                    break
                logger.warning(
                    "Auto-mapping worker call failed (attempt %s/%s). Retrying: %s",
                    attempt,
                    self._retry_attempts,
                    exc,
                )
                time.sleep(1.0)
                continue

            if response.status_code == 200:
                logger.info(
                    "Auto-mapping worker request_id=%s completed with HTTP 200",
                    req.request_id,
                )
                try:
                    return STTMBuilderResponse.model_validate(response.json())
                except Exception as exc:
                    raise SnowflakeAgentError(
                        f"Auto-mapping worker returned an invalid response payload: {exc}"
                    ) from exc

            if response.status_code < 500 and response.status_code != 429:
                logger.warning(
                    "Auto-mapping worker request_id=%s failed with HTTP %s: %s",
                    req.request_id,
                    response.status_code,
                    response.text,
                )
                raise SnowflakeAgentError(
                    f"Auto-mapping worker returned HTTP {response.status_code}: {response.text}"
                )

            last_error = SnowflakeAgentError(
                f"Auto-mapping worker returned HTTP {response.status_code}: {response.text}"
            )
            if attempt >= self._retry_attempts:
                break
            logger.warning(
                "Auto-mapping worker returned a transient error (attempt %s/%s). Retrying: %s",
                attempt,
                self._retry_attempts,
                response.text,
            )
            time.sleep(1.0)

        raise SnowflakeAgentError(
            f"Auto-mapping worker request failed: {last_error}"
        ) from last_error

    def invoke_stream(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
    ) -> Iterator[str]:
        def emit(event: str, data: dict[str, object]) -> str:
            return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"

        try:
            yield emit(
                "status",
                {
                    "phase": "automap_worker_started",
                    "message": (
                        "Dispatching the current auto-map batch to the dedicated "
                        "auto-mapping service."
                    ),
                },
            )
            response = self.invoke(request, req)
            yield emit(
                "status",
                {
                    "phase": "automap_worker_completed",
                    "message": "Auto-mapping worker completed the batch.",
                },
            )
            yield emit("final", response.model_dump(mode="json"))
        except Exception as exc:
            yield emit(
                "error",
                {
                    "message": str(exc),
                    "code": "AUTO_MAPPING_WORKER_ERROR",
                },
            )

    def _forward_headers(self, request: Request) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        for header_name in _FORWARDED_HEADER_NAMES:
            value = request.headers.get(header_name)
            if value:
                headers[header_name] = value
        principal = getattr(request.state, "current_principal", None)
        if principal is not None:
            caller_role = None
            if principal.app_persona is AppPersona.ADMIN:
                caller_role = self._settings.app_role_admin
            elif principal.app_persona is AppPersona.PUBLISHER:
                caller_role = self._settings.app_role_publisher
            elif principal.app_persona is AppPersona.VIEWER:
                caller_role = self._settings.app_role_viewer
            if caller_role:
                headers["X-Workbench-Caller-Role"] = caller_role
        return headers
