from types import SimpleNamespace
from unittest.mock import Mock

from fastapi import BackgroundTasks, Depends, FastAPI
from fastapi.testclient import TestClient


def test_transaction_session_remains_open_through_background_work(monkeypatch):
    import app.api
    from app.api import deps

    events = []
    session = object()
    client = SimpleNamespace(session=session, close=lambda: events.append("closed"))
    factory = Mock(return_value=client)
    monkeypatch.setattr(deps, "SnowflakeClient", factory)
    monkeypatch.setattr(deps, "_request_user_token", lambda *args: "caller-token")
    monkeypatch.setattr(deps, "_default_role_for_principal", lambda *args: "CALLER_ROLE")
    monkeypatch.setattr(deps, "ConversationMemoryService", lambda *args: "memory")
    monkeypatch.setattr(deps, "ProjectService", lambda **kwargs: SimpleNamespace(**kwargs))
    application = FastAPI()
    application.dependency_overrides[deps.get_settings] = lambda: SimpleNamespace()

    @application.post("/capture")
    def capture(background: BackgroundTasks, service=Depends(deps.get_transactional_project_service)):
        assert service.session is session
        assert "closed" not in events
        events.append("captured")

        def project():
            assert "closed" not in events
            events.append("projected")

        background.add_task(project)
        return {"saved": True}

    with TestClient(application) as browser:
        assert browser.post("/capture").json() == {"saved": True}
    assert events == ["captured", "projected", "closed"]
    assert factory.call_args.kwargs["user_token"] == "caller-token"
    assert factory.call_args.kwargs["role"] == "CALLER_ROLE"


def test_foreground_session_released_before_independent_background_projection(monkeypatch):
    from app.api import deps
    from fastapi import Request
    events = []
    def client_factory(**kwargs):
        identity = len(events)
        events.append(("open", identity, kwargs["role"]))
        return SimpleNamespace(session=identity, close=lambda: events.append(("close", identity)))
    monkeypatch.setattr(deps, "SnowflakeClient", client_factory)
    monkeypatch.setattr(deps, "_request_user_token", lambda *args: "caller-token")
    monkeypatch.setattr(deps, "_default_role_for_principal", lambda *args: "CALLER_ROLE")
    monkeypatch.setattr(deps, "ConversationMemoryService", lambda *args: None)
    monkeypatch.setattr(deps, "ProjectService", lambda **kwargs: SimpleNamespace(
        session=kwargs["session"], process_postsave_jobs=lambda **_: events.append(("project", kwargs["session"]))))
    application = FastAPI()
    application.dependency_overrides[deps.get_settings] = lambda: SimpleNamespace()
    @application.post("/capture")
    def capture(request: Request, background: BackgroundTasks,
                service=Depends(deps.get_transactional_project_service, scope="function"),
                runner=Depends(deps.get_postsave_projection_runner)):
        events.append(("capture", service.session))
        background.add_task(runner, sttm_id="test", max_jobs=1)
        return {"saved": True}
    with TestClient(application) as browser:
        assert browser.post("/capture").json() == {"saved": True}
    assert [event[0] for event in events] == ["open", "capture", "close", "open", "project", "close"]
    assert events[0][2] == events[3][2] == "CALLER_ROLE"
    assert events[1][1] != events[4][1]


def test_upload_enrichment_constructs_services_on_exclusive_session(monkeypatch):
    from contextlib import contextmanager
    from app.routers import upload
    from app.core import semantic_model, table_selection, derived_source
    events = []
    @contextmanager
    def lease():
        events.append("acquired")
        try:
            yield SimpleNamespace(session="exclusive")
        finally:
            events.append("released")
    monkeypatch.setattr(semantic_model, "SemanticModelService", lambda *_: None)
    monkeypatch.setattr(table_selection, "TableSelectionService", lambda client, _: client.session)
    monkeypatch.setattr(derived_source, "DerivedSourceService", lambda session, _: session)
    monkeypatch.setattr(upload, "SemanticContextService", lambda **kwargs: kwargs)
    monkeypatch.setattr(upload, "BundleCurationService", lambda session, _: session)
    def finish(**kwargs):
        assert events == ["acquired"]
        assert kwargs["session"] == kwargs["curation_service"] == "exclusive"
        assert kwargs["semantic_service"]["session"] == "exclusive"
        events.append("finished")
    monkeypatch.setattr(upload, "_finish_sql_upload_enrichment", finish)
    upload._finish_sql_upload_on_lease(session_lease=lease, settings=object(), asset_id="asset")
    assert events == ["acquired", "finished", "released"]


def test_session_slot_released_even_when_client_cleanup_fails(monkeypatch):
    import pytest
    from app.core import snowflake
    from app.core.warehouse_routing import WarehouseWorkload
    client = SimpleNamespace(close=Mock(side_effect=RuntimeError("close failed")))
    monkeypatch.setattr(snowflake, "SnowflakeClient", lambda **_: client)
    pool = snowflake.SnowflakeSessionLeasePool(settings=object(), user_token="", role="r",
                                             workload=WarehouseWorkload.CONTROL, maximum=1)
    with pytest.raises(RuntimeError, match="close failed"):
        with pool.lease():
            raise ValueError("work failed")
    import time
    assert snowflake._acquire_lease_capacity(pool._limit, time.monotonic() + 1)
    pool._limit.release()


def test_lease_reuses_clean_session_and_rolls_back_before_return(monkeypatch):
    from app.core import snowflake
    from app.core.warehouse_routing import WarehouseWorkload
    session = Mock()
    session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
    client = SimpleNamespace(session=session, close=Mock())
    factory = Mock(return_value=client)
    monkeypatch.setattr(snowflake, 'SnowflakeClient', factory)
    pool = snowflake.SnowflakeSessionLeasePool(settings=object(), user_token='caller', role='ROLE',
                                             workload=WarehouseWorkload.CONTROL, maximum=1)
    with pool.lease() as first:
        assert first is client
    with pool.lease() as second:
        assert second is first
    assert factory.call_count == 1
    assert [call.args[0] for call in session.sql.call_args_list].count('ROLLBACK') == 2
    pool.close()
    client.close.assert_called_once()


def test_retirement_never_closes_active_lease_or_reuses_it(monkeypatch):
    import pytest
    from app.core import snowflake
    from app.core.warehouse_routing import WarehouseWorkload
    session = Mock()
    session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
    client = SimpleNamespace(session=session, close=Mock())
    monkeypatch.setattr(snowflake, 'SnowflakeClient', lambda **_: client)
    pool = snowflake.SnowflakeSessionLeasePool(settings=object(), user_token='caller', role='ROLE',
                                             workload=WarehouseWorkload.CONTROL, maximum=1)
    with pool.lease():
        pool.close()
        client.close.assert_not_called()
    client.close.assert_called_once()
    with pytest.raises(snowflake.SnowflakeConnectionError, match='retired'):
        with pool.lease():
            raise AssertionError('retired session yielded')


def test_lease_failure_discards_without_replaying_work(monkeypatch):
    import pytest
    from app.core import snowflake
    from app.core.warehouse_routing import WarehouseWorkload
    session = Mock()
    session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
    clients = [SimpleNamespace(session=session, close=Mock()) for _ in range(2)]
    factory = Mock(side_effect=clients)
    monkeypatch.setattr(snowflake, 'SnowflakeClient', factory)
    pool = snowflake.SnowflakeSessionLeasePool(settings=object(), user_token='caller', role='ROLE',
                                             workload=WarehouseWorkload.CONTROL, maximum=1)
    with pytest.raises(ValueError, match='uncertain commit'):
        with pool.lease():
            raise ValueError('uncertain commit')
    clients[0].close.assert_called_once()
    with pool.lease() as next_client:
        assert next_client is clients[1]
    pool.close()


def test_caller_pool_scopes_and_fail_closed_credentials(monkeypatch):
    import pytest
    from app.core import snowflake
    from app.core.config import Settings
    settings = Settings(_env_file=None, snowflake_write_lease_pool_v1=True,
                        local_dev_auth_enabled=False, auth_mode='custom_oauth')
    clients = []
    def create(**kwargs):
        session = Mock()
        session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
        client = SimpleNamespace(session=session, close=Mock())
        clients.append(client)
        return client
    monkeypatch.setattr(snowflake, 'SnowflakeClient', create)
    snowflake.close_write_pools()
    with pytest.raises(snowflake.AuthenticationError):
        with snowflake.caller_write_lease(settings, '', 'ROLE', reusable=True):
            raise AssertionError('missing credential yielded')
    with snowflake.caller_write_lease(settings, 'token-a', 'ROLE', reusable=True) as first:
        with snowflake.caller_write_lease(settings, 'token-a', 'ROLE', reusable=True) as concurrent:
            assert first is not concurrent
    with snowflake.caller_write_lease(settings, 'token-b', 'ROLE', reusable=True) as other_user:
        assert other_user not in (first, concurrent)
    with snowflake.caller_write_lease(settings, 'token-a', 'OTHER', reusable=True) as other_role:
        assert other_role not in (first, concurrent, other_user)
    snowflake.close_write_pools()
    assert all(client.close.call_count == 1 for client in clients)


def test_cleanup_failure_discards_instead_of_failing_committed_save(monkeypatch):
    from app.core import snowflake
    from app.core.warehouse_routing import WarehouseWorkload
    session = Mock()
    session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
    client = SimpleNamespace(session=session, close=Mock())
    monkeypatch.setattr(snowflake, 'SnowflakeClient', lambda **_: client)
    pool = snowflake.SnowflakeSessionLeasePool(settings=object(), user_token='caller', role='ROLE',
                                             workload=WarehouseWorkload.CONTROL, maximum=1)
    with pool.lease():
        session.sql.side_effect = RuntimeError('connection lost after commit')
    assert not pool._idle
    client.close.assert_called_once()


def test_write_dependency_reuses_only_audited_autosave(monkeypatch):
    from contextlib import contextmanager
    from fastapi import Request
    from app.api import deps
    from app.core.config import Settings
    settings = Settings(_env_file=None, snowflake_write_lease_pool_v1=True)
    captures = []
    @contextmanager
    def lease(settings, token, role, **kwargs):
        captures.append((token, role, kwargs))
        yield SimpleNamespace(session='isolated')
    monkeypatch.setattr(deps, 'caller_write_lease', lease)
    monkeypatch.setattr(deps, '_request_user_token', lambda *_: 'caller')
    monkeypatch.setattr(deps, '_default_role_for_principal', lambda *_: 'ROLE')
    monkeypatch.setattr(deps, 'ConversationMemoryService', lambda *_: None)
    monkeypatch.setattr(deps, 'ProjectService', lambda **kwargs: SimpleNamespace(**kwargs))
    for suffix in ['autosave', 'publish']:
        request = Request({'type': 'http', 'path': f'/api/v1/projects/sttms/903/{suffix}', 'headers': []})
        generator = deps.get_transactional_project_service(request, settings)
        assert next(generator).session == 'isolated'
        generator.close()
    assert captures == [('caller', 'ROLE', {'reusable': True}), ('caller', 'ROLE', {'reusable': False})]


def test_expired_idle_lease_is_replaced(monkeypatch):
    from app.core import snowflake
    from app.core.warehouse_routing import WarehouseWorkload
    clock = [0.0]
    monkeypatch.setattr(snowflake.time, 'monotonic', lambda: clock[0])
    clients = []
    def create(**kwargs):
        session = Mock()
        session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
        client = SimpleNamespace(session=session, close=Mock())
        clients.append(client)
        return client
    monkeypatch.setattr(snowflake, 'SnowflakeClient', create)
    pool = snowflake.SnowflakeSessionLeasePool(settings=object(), user_token='caller', role='ROLE',
                                             workload=WarehouseWorkload.CONTROL, maximum=1)
    with pool.lease() as first:
        pass
    clock[0] = 31.0
    with pool.lease() as second:
        assert second is not first
    clients[0].close.assert_called_once()
    pool.close()


def test_all_api_paths_that_can_autosave_use_dedicated_project_session():
    import app.api
    from app.api import deps
    from app.routers import projects
    from inspect import signature
    from typing import get_args, get_type_hints

    for function in (projects.autosave_sttm, projects.publish_sttm,
                     projects.create_project_sttm, projects.create_project_from_template,
                     deps.get_recommendation_action_service):
        name = "project_service" if "project_service" in signature(function).parameters else "service"
        annotation = get_type_hints(function, include_extras=True)[name]
        assert get_args(annotation)[1].dependency is deps.get_transactional_project_service


def test_local_transactional_requests_reuse_exclusive_pool_not_shared_client(monkeypatch):
    from app.api import deps
    from contextlib import contextmanager
    from app.core.config import Settings
    events = []
    @contextmanager
    def lease():
        events.append("acquired")
        try:
            yield SimpleNamespace(session="exclusive")
        finally:
            events.append("released")
    monkeypatch.setattr(deps, "_request_user_token", lambda *args: "")
    monkeypatch.setattr(deps, "_default_role_for_principal", lambda *args: "DEV_ROLE")
    monkeypatch.setattr(deps, "get_local_transaction_pool", lambda settings, role: SimpleNamespace(lease=lease))
    monkeypatch.setattr(deps, "SnowflakeClient", lambda **kwargs: (_ for _ in ()).throw(AssertionError("fresh session")))
    monkeypatch.setattr(deps, "ConversationMemoryService", lambda *args: "memory")
    monkeypatch.setattr(deps, "ProjectService", lambda **kwargs: SimpleNamespace(**kwargs))
    generator = deps.get_transactional_project_service(object(), Settings(_env_file=None, local_dev_auth_enabled=True))
    assert next(generator).session == "exclusive"
    assert events == ["acquired"]
    generator.close()
    assert events == ["acquired", "released"]


def test_upload_routes_use_exclusive_caller_sessions(monkeypatch):
    from app.api import deps
    from app.routers import upload
    from typing import get_args, get_type_hints
    assert get_args(get_type_hints(upload.upload_sql, include_extras=True)["client"])[1].dependency is upload._sql_upload_client_guard
    assert get_args(get_type_hints(upload.upload_excel, include_extras=True)["client"])[1].dependency is deps.get_upload_snowflake_client
    client = SimpleNamespace(close=Mock())
    factory = Mock(return_value=client)
    monkeypatch.setattr(deps, "SnowflakeClient", factory)
    monkeypatch.setattr(deps, "_request_user_token", lambda *_: "caller-token")
    monkeypatch.setattr(deps, "_default_role_for_principal", lambda *_: "CALLER_ROLE")
    monkeypatch.setattr(deps, "using_local_dev_auth", lambda *_: False)
    generator = deps.get_upload_snowflake_client(object(), object())
    assert next(generator) is client
    generator.close()
    client.close.assert_called_once()
    assert factory.call_args.kwargs["user_token"] == "caller-token"
    assert factory.call_args.kwargs["role"] == "CALLER_ROLE"


def test_optional_recommendation_listing_uses_only_read_dependencies():
    import app.api
    from app.api import deps
    from app.routers import recommendation_actions
    from typing import get_args, get_type_hints
    hints = get_type_hints(recommendation_actions.list_applicable_recommendations, include_extras=True)
    assert get_args(hints["actions"])[1].dependency is deps.get_recommendation_read_service
    hints = get_type_hints(deps.get_recommendation_read_service, include_extras=True)
    assert get_args(hints["project_service"])[1].dependency is deps.get_project_service
    assert "derived_source_service" not in hints


def test_autosave_http_route_defers_and_schedules_durable_projections(monkeypatch):
    from app.routers import projects
    from app.schema.project import STTMAutosaveRequest, STTMAutosaveResponse

    monkeypatch.setattr(projects, "_require_edit", lambda _: None)
    monkeypatch.setattr(projects, "_user_id", lambda _: "caller")
    monkeypatch.setattr(projects, "_actor_from_request", lambda _: None)
    monkeypatch.setattr(projects, "build_response_envelope", lambda **kwargs: kwargs["data"])
    service = SimpleNamespace(
        autosave_sttm=Mock(return_value=STTMAutosaveResponse(
            project_id="p", sttm_id="42", snapshot_id="snap", post_save_job_id="job",
            post_save_job_status="queued",
        )),
        process_postsave_jobs=Mock(),
    )
    background = BackgroundTasks()
    request = STTMAutosaveRequest(workspace_snapshot={})
    runner = Mock()
    response = projects.autosave_sttm(object(), background, "42", request, service, runner)
    service.autosave_sttm.assert_called_once_with("42", request, user_id="caller", defer_postsave=True)
    assert response.post_save_job_status == "queued"
    assert len(background.tasks) == 1
    assert background.tasks[0].func == runner
    service.process_postsave_jobs.assert_not_called()