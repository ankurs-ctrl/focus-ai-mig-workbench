export type PreviewClauses = {
  whereSql?: string;
  groupBySql?: string;
  orderBySql?: string;
  modifiers?: Record<string, string>;
};

/** The caller supplies a scope-owned FROM query, not SQL with appended clauses. */
export function appendPreviewClauses(baseSql: string, clauses: PreviewClauses) {
  return [baseSql.trim(),
    clauses.whereSql?.trim() ? `WHERE\n${clauses.whereSql.trim()}` : "",
    clauses.groupBySql?.trim() ? `GROUP BY\n${clauses.groupBySql.trim()}` : "",
    clauses.modifiers?.having ?? "",
    clauses.modifiers?.qualify ?? "",
    clauses.orderBySql?.trim() ? `ORDER BY\n${clauses.orderBySql.trim()}` : "",
    clauses.modifiers?.limit ?? "",
    clauses.modifiers?.offset ?? "",
  ].filter(Boolean).join("\n\n");
}