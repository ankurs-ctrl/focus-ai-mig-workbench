-- Conversation-scoped knowledge verified by the Deep migration agent:
-- table contracts, catalog candidates, reusable read-tool results and
-- decisions. Rows are partitioned by the caller's access scope
-- (tenant:user:role) so knowledge never crosses an authorization boundary.
-- Every derived row records the contract fingerprints it depends on; the
-- worker revalidates contracts on each claim and ignores stale rows.
CREATE TABLE IF NOT EXISTS TBL_AGENT_RUN_KNOWLEDGE (
    KNOWLEDGE_SCOPE VARCHAR(300) NOT NULL,
    ACCESS_SCOPE VARCHAR(1000) NOT NULL,
    KIND VARCHAR(64) NOT NULL,
    ITEM_KEY VARCHAR(4000) NOT NULL,
    FINGERPRINT VARCHAR(128),
    PAYLOAD VARIANT,
    RUN_ID VARCHAR(64),
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    CONSTRAINT PK_AGENT_RUN_KNOWLEDGE PRIMARY KEY (KNOWLEDGE_SCOPE, ACCESS_SCOPE, KIND, ITEM_KEY)
);
