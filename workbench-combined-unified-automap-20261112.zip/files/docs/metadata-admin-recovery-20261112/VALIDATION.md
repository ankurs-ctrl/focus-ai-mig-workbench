# Validation

Local validation on 12 November 2026:

- 194 backend regression tests passed: lock bootstrap inventory/order/rendering, concurrent catalog reads, table metadata recovery, admin permissions/removal/restore guards, template bootstrap, Auto-map rules/confidence, publication capture and real SQL-upload fixtures.
- Frontend regressions cover calculated confidence and candidate handling, SQL upload/preview retention, metadata batching (57-table mixed-success case), individual retry, legitimate zero counts, stale responses and loading across concurrent requests.
- Session navigation/cache regression passed, including immediate removal without refetch, aggregate updates, project-child removal, subscriber notification and fencing an older in-flight summary so it cannot resurrect removed rows.
- TypeScript no-emit check passed. Agent specification manifest verification passed. Whitespace check passed with existing repository CRLF conventions.

No new native Snowflake deployment, client-data mutation, or browser screenshot was performed for these metadata/admin changes. Backend restore SQL and the deletion recovery-window predicates have local contract/unit coverage, not fresh live Snowflake acceptance. Previous native mixed Auto-map acceptance remains documented in the earlier release evidence; it does not prove these new admin operations.

Remote UAT and develop were fetched and checked before integration; both were based on 9f6b16f, with no newer team changes or merge conflicts. Environment files were excluded from synchronization and packaging.
