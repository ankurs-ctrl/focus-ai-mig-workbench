import yaml

from app.core.semantic_context import SemanticContextService
from app.schema.common import TableRef
from app.schema.semantic_context import SemanticLevel


class _SemanticModels:
    def __init__(self, records):  # type: ignore[no-untyped-def]
        self.records = records

    def get_table_records(self, session, tables):  # type: ignore[no-untyped-def]
        return self.records


def _record(table: TableRef, *, primary_key: str, relationship=None):  # type: ignore[no-untyped-def]
    logical_name = f"{table.schema}_{table.table}".lower()
    saved = {
        "name": f"SV_{table.table}",
        "description": table.table,
        "tables": [
            {
                "name": logical_name,
                "base_table": {
                    "database": table.database,
                    "schema": table.schema,
                    "table": table.table,
                },
                "primary_key": {"columns": [primary_key]},
                "dimensions": [
                    {
                        "name": primary_key,
                        "expr": primary_key,
                        "data_type": "NUMBER",
                        "unique": True,
                    }
                ],
                "facts": [
                    {
                        "name": "AMOUNT",
                        "expr": "AMOUNT",
                        "data_type": "NUMBER",
                    }
                ],
                "metrics": [{"name": "sum_amount", "expr": "SUM(AMOUNT)"}],
            }
        ],
        "verified_queries": [
            {"name": f"sample_{table.table.lower()}", "question": "sample", "sql": "SELECT 1"}
        ],
    }
    return {
        "database": table.database,
        "schema_name": table.schema,
        "table_name": table.table,
        "semantic_model": {
            "attributes": [
                {
                    "name": primary_key,
                    "data_type": "NUMBER",
                    "semantic_role": "primary_key",
                    "constraints": ["PRIMARY_KEY"],
                },
                {
                    "name": "AMOUNT",
                    "data_type": "NUMBER",
                    "semantic_role": "metric",
                    "default_aggregation": "sum",
                },
            ],
            "relationships": relationship or {"outgoing": [], "incoming": []},
            "semantic_view": {"yaml": yaml.safe_dump(saved), "yaml_hash": table.table},
        },
        "updated_at": "2026-06-23",
    }


def test_composer_preserves_saved_tables_metrics_and_relationships() -> None:
    calculation = TableRef(database="DB", schema="SRC", table="CALCULATION")
    note = TableRef(database="DB", schema="SRC", table="NOTE")
    service = SemanticContextService.__new__(SemanticContextService)
    service._session = object()
    service._semantic_model_service = _SemanticModels(
        [
            _record(calculation, primary_key="INCOME_ID"),
            _record(note, primary_key="NOTE_ID"),
        ]
    )

    output = service._build_semantic_view_yaml(
        bundle_id="sem_test",
        semantic_view_name="INLINE_TEST",
        selected_source_tables=[calculation, note],
        derived_records=[],
        relationships=[
            {
                "left_table": note.model_dump(mode="json"),
                "right_table": calculation.model_dump(mode="json"),
                "conditions": [{"left_column": "INCOME_ID", "right_column": "INCOME_ID"}],
            }
        ],
        target_table=None,
        semantic_level=SemanticLevel.L2_ANALYST_READY,
    )

    composed = yaml.safe_load(output)
    assert len(composed["tables"]) == 2
    assert composed["tables"][0]["metrics"][0]["name"] == "sum_amount"
    assert composed["relationships"][0]["right_table"].endswith("calculation")
    assert len(composed["verified_queries"]) == 2

