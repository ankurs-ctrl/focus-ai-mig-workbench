# Validation scope and limitations

The release includes the pre-submission contention fix, unified draft policy handoff, confidence/rule handoff and partial semantic evidence behavior. It is cumulative relative to the supplied client ZIP, including SQL-upload preview/publication, metadata counts, project-bootstrap and administration recovery changes from prior releases.

## Automated checks

The backend/core/runtime suite passed 4,762 tests (31 skipped). The final source-packet/NULL clarification then passed 86 focused fast-context and confidence/rule tests; semantic, scan-protocol and chat/stream release checks passed 152 tests. Frontend checks passed 128 tests; TypeScript passed. Full logs and native results are included alongside this document. The core/runtime suites exercise fenced preparation and rollback handling, uncertain commit/no replay, heartbeats, sibling progress, policy propagation, direct/custom/Value/FIR confidence and persistence, uploaded SQL preview/publication, metadata and administration flows. Focused semantic tests cover partial/all/invalid YAML, available evidence retention, historical guidance isolation, cache/reopen, caller permission failures and request-scoped tool preservation. Frontend checks cover the existing mapping and administration behavior; TypeScript and agent manifest validation pass.

A historical strict scan-spec assertion was updated because the requested instruction changes intentionally change its text. Its original model, budgets, tool-free contract and response protocol remain checked.

## Native acceptance

See NATIVE-RESULTS.md, NATIVE-SEMANTIC-RESULTS.md and the NATIVE-*.json files for timings, per-call phases, actual model submissions, SQL query IDs, FIR IDs, output-value comparisons and cleanup. Separate missing-semantics fixtures exercise the production semantic resolver with controlled registry records, real Cortex builder/source/rule calls, and actual Snowflake compiler/output checks. The controlled registry input makes absence deterministic without removing any installed semantic assets.

These are isolated test-account engine/transport integrations, not a deployed SPCS browser session or a reproduction of the full client workspace. Fixture postflight persistence/publication is disabled; publication and frontend behavior are covered by local regressions. No client mapping was modified or rerun, no mapping was published, and no client objects or semantic assets were deleted. Temporary test schemas were removed. Models can still return unsupported/invalid or unfinished proposals; those remain explicit reviewable outcomes, not claimed complete work.

## Limits

- Exact SQL blocker in the historical client incident remains unknown because its original code/query ID was discarded. New safe diagnostics preserve native identifiers and transaction outcomes without SQL text/bindings.
- Five-target native fixtures do not establish latency or complete coverage for 37 targets and 287 sources. Individual phase durations overlap across batches.
- Historical/similar semantics are guidance under existing caller access. They do not establish missing current bindings, business defaults or population compatibility. No exhaustive automatic scan of every old semantic view is introduced.
- All agent YAML templates contain instruction changes only; live resources, model choices, budgets and permission boundaries must be preserved on deployment. No environment settings or new admission-table migration are required.

## Additional finding during acceptance

A repeated partial-coverage run returned four supported definitions but left the intended OWNERNAME NULL unusable. Its warnings described an intentional NULL, while the compiler correctly refused the returned definition. The test did not replace the incomplete result with an invented owner rule or default. The source instructions and shared packet now specify the canonical SQL NULL constant form explicitly. The earlier diagnostic report is retained as INVESTIGATION-partial-null-contract.json; the release acceptance report is identified separately. An agent's prose/warning alone is never considered executable SQL.

The final partial-coverage acceptance passed with all five expected values and canonical OWNERNAME NULL. The all-missing CTE acceptance also passed, with retained ID and filter. Missing-semantic behavior was verified with actual builder answers as well as actual source/rule agent submissions.
