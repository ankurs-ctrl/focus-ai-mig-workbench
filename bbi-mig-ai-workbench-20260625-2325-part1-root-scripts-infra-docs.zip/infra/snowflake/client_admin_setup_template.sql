-- Client IT/admin setup template for AIA Migration Workbench on SPCS.
--
-- Replace all <PLACEHOLDER> values before running. This file is intentionally
-- conservative: it documents the object classes and grants needed by the
-- current OAuth + Auto-map + CoCo architecture without hiding admin decisions.

USE ROLE ACCOUNTADMIN;

-- ---------------------------------------------------------------------------
-- 1. Core database/schema/warehouse
-- ---------------------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS <WORKBENCH_DB>;
CREATE SCHEMA IF NOT EXISTS <WORKBENCH_DB>.<WORKBENCH_SCHEMA>;
CREATE WAREHOUSE IF NOT EXISTS <WORKBENCH_WAREHOUSE>
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE;

GRANT USAGE ON DATABASE <WORKBENCH_DB> TO ROLE <APP_RUNTIME_ROLE>;
GRANT USAGE ON SCHEMA <WORKBENCH_DB>.<WORKBENCH_SCHEMA> TO ROLE <APP_RUNTIME_ROLE>;
GRANT USAGE ON WAREHOUSE <WORKBENCH_WAREHOUSE> TO ROLE <APP_RUNTIME_ROLE>;

-- ---------------------------------------------------------------------------
-- 2. SPCS compute pools and image repository
-- ---------------------------------------------------------------------------

CREATE COMPUTE POOL IF NOT EXISTS <WEBAPP_COMPUTE_POOL>
  MIN_NODES = 1
  MAX_NODES = <WEBAPP_MAX_NODES>
  INSTANCE_FAMILY = <WEBAPP_INSTANCE_FAMILY>
  AUTO_RESUME = TRUE;

CREATE COMPUTE POOL IF NOT EXISTS <AUTOMAP_COMPUTE_POOL>
  MIN_NODES = 1
  MAX_NODES = <AUTOMAP_MAX_NODES>
  INSTANCE_FAMILY = <AUTOMAP_INSTANCE_FAMILY>
  AUTO_RESUME = TRUE;

CREATE IMAGE REPOSITORY IF NOT EXISTS <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<IMAGE_REPOSITORY>;

GRANT USAGE ON COMPUTE POOL <WEBAPP_COMPUTE_POOL> TO ROLE <DEPLOY_ROLE>;
GRANT USAGE ON COMPUTE POOL <AUTOMAP_COMPUTE_POOL> TO ROLE <DEPLOY_ROLE>;
GRANT READ, WRITE ON IMAGE REPOSITORY <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<IMAGE_REPOSITORY> TO ROLE <DEPLOY_ROLE>;

-- Required for public ingress endpoint binding.
GRANT BIND SERVICE ENDPOINT ON ACCOUNT TO ROLE <DEPLOY_ROLE>;

-- ---------------------------------------------------------------------------
-- 3. External access integration
-- ---------------------------------------------------------------------------

CREATE OR REPLACE NETWORK RULE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<EGRESS_NETWORK_RULE>
  MODE = EGRESS
  TYPE = HOST_PORT
  VALUE_LIST = (
    '<ACCOUNT_HOST>:443',
    '<ACCOUNT_REGION_OAUTH_HOST>:443'
  );

CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION <EGRESS_INTEGRATION>
  ALLOWED_NETWORK_RULES = (<WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<EGRESS_NETWORK_RULE>)
  ENABLED = TRUE;

GRANT USAGE ON INTEGRATION <EGRESS_INTEGRATION> TO ROLE <DEPLOY_ROLE>;

-- ---------------------------------------------------------------------------
-- 4. OAuth integration and secrets
-- ---------------------------------------------------------------------------

CREATE OR REPLACE SECURITY INTEGRATION <OAUTH_SECURITY_INTEGRATION>
  TYPE = OAUTH
  ENABLED = TRUE
  OAUTH_CLIENT = CUSTOM
  OAUTH_CLIENT_TYPE = 'CONFIDENTIAL'
  OAUTH_REDIRECT_URI = 'https://<WEBAPP_INGRESS_HOST>/api/v1/auth/callback'
  OAUTH_ISSUE_REFRESH_TOKENS = TRUE
  OAUTH_REFRESH_TOKEN_VALIDITY = 7776000
  OAUTH_ALLOWED_SCOPES = ('session:role:<APP_USER_ROLE>');

-- Capture generated client id/secret from DESCRIBE INTEGRATION and store them
-- in a password secret. Do not put the values in service YAML.
--
-- DESC SECURITY INTEGRATION <OAUTH_SECURITY_INTEGRATION>;

CREATE OR REPLACE SECRET <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<OAUTH_CLIENT_SECRET>
  TYPE = PASSWORD
  USERNAME = '<OAUTH_CLIENT_ID>'
  PASSWORD = '<OAUTH_CLIENT_SECRET>';

CREATE OR REPLACE SECRET <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<OAUTH_SESSION_SECRET>
  TYPE = PASSWORD
  USERNAME = '<AUTH_SESSION_SECRET>'
  PASSWORD = '<AUTH_SESSION_ENCRYPTION_KEY>';

GRANT READ ON SECRET <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<OAUTH_CLIENT_SECRET> TO ROLE <DEPLOY_ROLE>;
GRANT READ ON SECRET <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<OAUTH_SESSION_SECRET> TO ROLE <DEPLOY_ROLE>;

-- ---------------------------------------------------------------------------
-- 5. Metadata table write/read grants
-- ---------------------------------------------------------------------------

GRANT SELECT ON ALL TABLES IN SCHEMA <WORKBENCH_DB>.<WORKBENCH_SCHEMA> TO ROLE <APP_RUNTIME_ROLE>;
GRANT SELECT ON FUTURE TABLES IN SCHEMA <WORKBENCH_DB>.<WORKBENCH_SCHEMA> TO ROLE <APP_RUNTIME_ROLE>;

-- The app writes only controlled metadata such as OAuth sessions, conversation
-- turns, derived-source records, Auto-map jobs/results, feedback, and caches.
-- Prefer procedure-mediated writes where possible.
GRANT INSERT, UPDATE, DELETE ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_WORKBENCH_OAUTH_SESSIONS TO ROLE <APP_RUNTIME_ROLE>;
GRANT INSERT, UPDATE, DELETE ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_WORKBENCH_CONVERSATION_TURNS TO ROLE <APP_RUNTIME_ROLE>;
GRANT INSERT, UPDATE, DELETE ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_WORKBENCH_FEEDBACK TO ROLE <APP_RUNTIME_ROLE>;
GRANT INSERT, UPDATE, DELETE ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_DERIVED_SOURCES TO ROLE <APP_RUNTIME_ROLE>;

-- Needed when a restricted caller-rights executable touches derived sources.
GRANT CALLER MODIFY ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_DERIVED_SOURCES TO ROLE <PROCEDURE_OWNER_ROLE>;

-- Do not grant direct app writes to semantic registry tables.
GRANT SELECT ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.SEM_TABLE_VIEWS TO ROLE <APP_RUNTIME_ROLE>;
GRANT SELECT ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.SEM_COLUMN_VIEWS TO ROLE <APP_RUNTIME_ROLE>;
GRANT SELECT ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_SEMANTIC_MODELS TO ROLE <APP_RUNTIME_ROLE>;
GRANT SELECT ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_SEMANTIC_BUNDLES TO ROLE <APP_RUNTIME_ROLE>;
GRANT SELECT ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_SEMANTIC_OVERRIDES TO ROLE <APP_RUNTIME_ROLE>;

-- ---------------------------------------------------------------------------
-- 6. Source/target data access
-- ---------------------------------------------------------------------------

GRANT USAGE ON DATABASE <SOURCE_DB> TO ROLE <APP_USER_ROLE>;
GRANT USAGE ON ALL SCHEMAS IN DATABASE <SOURCE_DB> TO ROLE <APP_USER_ROLE>;
GRANT SELECT ON ALL TABLES IN DATABASE <SOURCE_DB> TO ROLE <APP_USER_ROLE>;
GRANT SELECT ON FUTURE TABLES IN DATABASE <SOURCE_DB> TO ROLE <APP_USER_ROLE>;

-- Repeat for every target/source database approved for the migration.

-- ---------------------------------------------------------------------------
-- 7. Service role access after services are created
-- ---------------------------------------------------------------------------

-- Run after CREATE SERVICE / deploy script succeeds.
-- GRANT SERVICE ROLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<WEBAPP_SERVICE_NAME>!backend_access TO ROLE <APP_USER_ROLE>;
-- GRANT SERVICE ROLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.<WEBAPP_SERVICE_NAME>!backend_access TO ROLE <APP_RUNTIME_ROLE>;

-- ---------------------------------------------------------------------------
-- 8. Post-create redirect maintenance
-- ---------------------------------------------------------------------------

-- If SHOW ENDPOINTS returns a different host after the first service deploy,
-- update the OAuth integration with:
--
-- ALTER SECURITY INTEGRATION <OAUTH_SECURITY_INTEGRATION>
--   SET OAUTH_REDIRECT_URI = 'https://<NEW_WEBAPP_INGRESS_HOST>/api/v1/auth/callback';
