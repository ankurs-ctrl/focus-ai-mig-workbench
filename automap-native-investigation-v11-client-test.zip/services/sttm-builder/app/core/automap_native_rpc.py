"""Registered-tool execution bridge, not an investigation/pagination strategy.

Snowflake procedures cannot assume Streamlit's private REST helper exists. A
procedure enqueues one authenticated frozen-job operation and waits boundedly.
The worker executes exactly that operation with its existing same-caller HTTP
client and an exclusive Snowpark lease. Unknown in-flight operations are never
reclaimed/reposted on a timer. Only SubmitProposals publishes target checkpoints.
"""

from contextvars import ContextVar
from copy import deepcopy
import time
from app.core.automap_native_contract import digest, encoded
from app.core.automap_native_store import NativeJobStore
from app.core.automap_native_tools import NativeToolError

HTTP = ContextVar("native_same_caller_http", default=None)


def request(store, handle, operation, payload, *, seconds=45):
    if operation not in {"sources", "precedents", "analyst", "compile"}:
        raise NativeToolError("unsupported_native_rpc")
    row = store.load(handle)
    key = digest([row["SNAPSHOT_HASH"], operation, payload])
    with store.edit(handle) as state:
        existing = state.setdefault("rpc", {}).get(key)
        if not existing:
            state["rpc"][key] = {
                "operation": operation,
                "payload": deepcopy(payload),
                "stage": "pending",
                "at": time.time(),
            }
    stop = min(
        time.monotonic() + seconds,
        time.monotonic() + max(0, row["DEADLINE_EPOCH"] - time.time() - 1),
    )
    while time.monotonic() < stop:
        current = store.load(handle)["STATE"].get("rpc", {}).get(key, {})
        if current.get("stage") == "done":
            return deepcopy(current["result"])
        if current.get("stage") in {"failed", "uncertain"}:
            raise NativeToolError(current.get("code", "native_rpc_failed"))
        time.sleep(0.25)
    # A timeout does not recycle an Analyst permit or replay its remote POST.
    raise NativeToolError("native_tool_execution_timeout")


def execute(store, handle, key, api):
    row = store.load(handle)
    job = row["STATE"].get("rpc", {}).get(key)
    if not job or job["stage"] != "pending":
        return
    with store.edit(handle) as state:
        item = state.get("rpc", {}).get(key)
        if not item or item["stage"] != "pending":
            return
        item["stage"] = "running"
        item["started_at"] = time.time()
    token = HTTP.set(api)
    try:
        from app.core.automap_native_ports import (
            search_sources,
            search_precedents,
            ask_analyst,
            compile_proposal,
        )
        from app.schema.sttm_builder import AttributeMapping

        payload = job["payload"]
        snap = row["SNAPSHOT"]
        config = row["CONFIG"]
        operation = job["operation"]
        if operation == "sources":
            result = search_sources(snap, payload["question"], config)
        elif operation == "precedents":
            result = search_precedents(
                store.session, snap, payload["targets"], payload["question"], config
            )
        elif operation == "analyst":
            result = ask_analyst(
                store.session, snap, payload["ids"], payload["question"], config
            )
        elif operation == "compile":
            result = compile_proposal(
                store.session,
                snap,
                payload["target"],
                AttributeMapping.model_validate(payload["mapping"]),
                payload["requires_rule"],
                config,
            )
        else:
            raise NativeToolError("unregistered_rpc_operation")
        if len(encoded(result).encode()) > 32768:
            raise NativeToolError("native_rpc_result_budget")
    except Exception as error:
        code = (
            str(error)
            if isinstance(error, NativeToolError)
            else "native_tool_execution_failed"
        )
        with store.edit(handle, allow_expired=True) as state:
            state["rpc"][key].update(stage="failed", code=code, finished_at=time.time())
    else:
        with store.edit(handle, allow_expired=True) as state:
            state["rpc"][key].update(
                stage="done", result=result, finished_at=time.time()
            )
    finally:
        HTTP.reset(token)


def http_port(agent):
    """One POST, fixed Snowflake origin, existing caller auth; no fresh login."""

    def send(method, path, payload, *, timeout=30000):
        import httpx
        from app.core.snowflake_agent import _shared_http_client

        if method != "POST" or not (
            path == "/api/v2/cortex/analyst/message"
            or (path.startswith("/api/v2/databases/") and path.endswith(":query"))
        ):
            raise NativeToolError("native_rpc_endpoint_forbidden")
        response = _shared_http_client(agent._base_url).post(
            agent._base_url + path,
            json=payload,
            headers=agent._build_headers(),
            timeout=max(0.1, min(45, timeout / 1000)),
        )
        if response.status_code != 200:
            raise NativeToolError(
                "provider_request_failed"
                if response.status_code in {400, 401, 403, 404, 429}
                else "provider_completion_unknown"
            )
        raw = response.content
        if len(raw) > 1000000:
            raise NativeToolError("provider_entity_budget")
        body = response.json()
        if not isinstance(body, dict):
            raise NativeToolError("invalid_provider_body")
        return body

    return send
