"""Target-only initialization: bounded bulk DML, owned by the caller transaction."""
import json
from uuid import uuid4


def initialize_blank_mappings(service, project, payloads, *, user_id, display_name):
    if not payloads:
        return []
    entries = []
    for payload in payloads:
        snapshot = service._snapshot_to_dict(payload.workspace_snapshot)
        if snapshot.get('source_tables') or snapshot.get('derived_sources') or any(
                row.get('source_columns') for row in snapshot.get('mapping_rows') or []):
            raise ValueError('Blank initialization accepts target-only mappings')
        metadata = {**payload.metadata, 'actor_user_id': user_id or '',
            'created_by_name': display_name or '', 'mapping_name': payload.sttm_name,
            'mapping_description': payload.description or ''}
        entries.append({'name': payload.sttm_name, 'description': payload.description or '',
            'target': service._table_ref_to_fqn(payload.target_table), 'metadata': metadata,
            'snapshot': snapshot, 'snapshot_id': str(uuid4())})
    encoded = json.dumps(entries)
    actors = service._actor_column_values(service._sttm_table, user_id)
    actor_columns = ''.join(', ' + column for column in actors)
    actor_values = ''.join(', ' + value for value in actors.values())
    service._session.sql(f'''INSERT INTO {service._sttm_table}
        (PROJECT_ID, STTM_NAME, DESCRIPTION, TARGET_TABLE, STATUS, HAS_UNPUBLISHED_DRAFT,
         DRAFT_PAYLOAD, STTM_METADATA, LAST_SNAPSHOT_ID{actor_columns})
        SELECT ?, v.value:name::STRING, v.value:description::STRING, v.value:target::STRING,
               'DRAFT', TRUE, v.value:snapshot, v.value:metadata, v.value:snapshot_id::STRING{actor_values}
        FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) v''', params=[project.project_id, encoded]).collect()
    key = payloads[0].metadata['bootstrap_idempotency_key']
    rows = service._session.sql(f'''SELECT * FROM {service._sttm_table} WHERE TO_VARCHAR(PROJECT_ID) = ?
        AND STTM_METADATA:bootstrap_idempotency_key::STRING = ?''', params=[project.project_id, key]).collect()
    by_key = {str(row.as_dict()['STTM_ID']): row.as_dict() for row in rows}
    by_snapshot = {str(row['LAST_SNAPSHOT_ID']): row for row in by_key.values()}
    if any(entry['snapshot_id'] not in by_snapshot for entry in entries):
        raise ValueError('Bulk initialization could not resolve every inserted mapping')
    for entry in entries:
        row = by_snapshot[entry['snapshot_id']]
        snapshot = entry['snapshot']
        snapshot.update(sttm_id=str(row['STTM_ID']), snapshot_id=entry['snapshot_id'])
        snapshot['context_hash'] = service._normalized_workspace_hash(snapshot)
        entry['sttm_id'] = str(row['STTM_ID'])
    encoded = json.dumps(entries)
    service._session.sql(f'''INSERT INTO {service._snapshots_table}
        (SNAPSHOT_ID, PROJECT_ID, STTM_ID, CONTEXT_HASH, ACTION, PAGE, SURFACE, SNAPSHOT_PAYLOAD, USER_ID)
        SELECT v.value:snapshot_id::STRING, ?, v.value:sttm_id::STRING, v.value:snapshot:context_hash::STRING,
        'sttm.created', 'builder', 'SOURCE_SELECTION', v.value:snapshot, ?
        FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) v''', params=[project.project_id, user_id or '', encoded]).collect()
    service._session.sql(f'''INSERT INTO {service._attributes_table}
        (STTM_ID, ATTRIBUTE_NAME, ATTRIBUTE_TYPE, DATA_TYPE, IS_DRAFT)
        SELECT v.value:sttm_id::NUMBER, a.value:target_column::STRING, 'RAW', a.value:target_type::STRING, TRUE
        FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) v,
             LATERAL FLATTEN(INPUT => v.value:snapshot:mapping_rows) a''', params=[encoded]).collect()
    service._session.sql(f'''UPDATE {service._sttm_table} t SET DRAFT_PAYLOAD = v.value:snapshot
        FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) v WHERE TO_VARCHAR(t.STTM_ID) = v.value:sttm_id::STRING''', params=[encoded]).collect()
    return [service._sttm_from_row({**by_snapshot[entry['snapshot_id']], 'DRAFT_PAYLOAD': entry['snapshot']},
        mapping_counts={'MAPPING_COUNT': len(entry['snapshot'].get('mapping_rows') or []), 'MAPPED_COUNT': 0}) for entry in entries]
