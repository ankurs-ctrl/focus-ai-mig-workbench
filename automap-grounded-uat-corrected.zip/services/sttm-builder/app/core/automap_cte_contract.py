"""Bind uploaded CTE definitions by SQL scope, independent of incoming hashes."""
from sqlglot import exp
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.scope import Scope, build_scope

from app.core.automap_deterministic import _equivalent, _identifier, _key, _one, _query_output_identifiers
from app.core.automap_retrieval import digest


def _scoped(sql):
    tree = normalize_identifiers(_one(sql), dialect="snowflake")
    root = build_scope(tree)
    if root is None:
        raise ValueError("Selected CTE has no query scope")
    with_clause = tree.args.get("with") or tree.args.get("with_")
    scopes = {id(scope.expression): scope for scope in root.traverse()}
    definitions = {}
    for cte in with_clause.expressions if with_clause else []:
        name = _key(cte.args["alias"].this)
        if name in definitions or cte.args["alias"].args.get("columns"):
            raise ValueError("Selected CTE has ambiguous or positional output aliases")
        definitions[name] = scopes[id(cte.this)]
    return tree, root, definitions


def _wrapper(tree):
    """Only a plain full-output SELECT is a wrapper; filters are definitions."""
    if not isinstance(tree, exp.Select) or len(tree.expressions) != 1:
        return None
    if not isinstance(tree.expressions[0], exp.Star) or any(tree.expressions[0].args.values()):
        return None
    permitted = {"expressions", "from", "from_", "with", "with_"}
    if any(value for key, value in tree.args.items() if key not in permitted):
        return None
    source = tree.args.get("from") or tree.args.get("from_")
    table = source.this if source else None
    return table if isinstance(table, exp.Table) and not table.db and not table.catalog else None


def _reachable(scope):
    seen = set()
    def visit(current):
        if id(current) in seen:
            return
        seen.add(id(current))
        for child in current.traverse():
            for _table, source in child.selected_sources.values():
                if isinstance(source, Scope):
                    yield source
                    yield from visit(source)
    return list(visit(scope))


def _rebind(root, definitions, aliases):
    """Rename only references bound to top-level CTEs, preserving qualifiers."""
    identities = {id(scope): name for name, scope in definitions.items()}
    for scope in root.traverse():
        for table, source in scope.selected_sources.values():
            name = identities.get(id(source)) if isinstance(source, Scope) else None
            if name not in aliases or not isinstance(table, exp.Table):
                continue
            # FROM p becomes FROM runtime_p AS p. Explicit aliases and their
            # bound column references remain intact, including quoted names.
            if not table.args.get("alias"):
                table.set("alias", exp.TableAlias(this=table.this.copy()))
            table.set("this", exp.to_identifier(aliases[name]))


def hydrate_authored_cte_graph(req):
    graph, workspace = req.context.relation_graph, req.context.workspace_context
    if graph is None or workspace is None:
        return req
    named = [node for node in graph.nodes
             if node.kind.value == "DERIVED_SOURCE" and node.original_cte_name]
    if not named:
        return req
    sql = workspace.mapping_sql or workspace.raw_mapping_sql
    if not sql:
        raise ValueError("Current authored SQL is absent for uploaded CTEs")
    if workspace.mapping_sql and workspace.raw_mapping_sql and workspace.mapping_sql != workspace.raw_mapping_sql:
        raise ValueError("Current authored SQL conflicts with the CTE graph")
    _tree, root, definitions = _scoped(sql)
    aliases = {_key(_identifier(node.original_cte_name)): node.alias for node in named}
    if len(aliases) != len(named):
        raise ValueError("Selected CTE names are ambiguous")
    if not set(aliases) <= definitions.keys():
        raise ValueError("A selected CTE is missing from the current authored SQL")
    # Capture the authored dependency bodies before changing their table names.
    original_bodies = {name: scope.expression.copy() for name, scope in definitions.items()}
    _rebind(root, definitions, aliases)
    updated = []
    for node in graph.nodes:
        if node not in named:
            updated.append(node)
            continue
        name = _key(_identifier(node.original_cte_name))
        expected = definitions[name].expression
        identifiers = _query_output_identifiers(original_bodies[name])
        def matches(item):
            if item.get("sql_name"):
                return _key(_identifier(item["sql_name"])) in {_key(value) for value in identifiers}
            text = str(item.get("name") or "")
            return any(text == value.name or (not value.args.get("quoted") and text.upper() == value.name.upper())
                       for value in identifiers)
        if not node.output_columns or any(not matches(item) for item in node.output_columns):
            raise ValueError("Selected CTE outputs differ from current authored SQL")
        actual_tree, actual_root, actual_defs = _scoped(node.sql_text or "")
        wrapper = _wrapper(actual_tree)
        if wrapper is not None:
            source_name = _key(wrapper.this)
            if source_name != name:
                raise ValueError("Selected CTE wrapper refers to a different definition")
            if actual_defs:
                selected = actual_root.selected_sources.get(wrapper.alias_or_name)
                actual_scope = selected[1] if selected else None
                if not isinstance(actual_scope, Scope) or actual_scope is not actual_defs.get(name):
                    raise ValueError("Selected CTE wrapper is not bound to its definition")
                relevant = {id(actual_scope), *(id(scope) for scope in _reachable(actual_scope))}
                for dependency, scope in actual_defs.items():
                    if id(scope) in relevant and (dependency not in original_bodies
                            or not _equivalent(scope.expression, original_bodies[dependency])):
                        raise ValueError("Selected CTE body or dependency differs from current authored SQL")
            # A bare frontend name wrapper resolves only in this authored scope.
        elif not (_equivalent(actual_tree, expected) or _equivalent(actual_tree, original_bodies[name])):
            # Hashes are never a substitute for this comparison of actual SQL.
            raise ValueError("Selected CTE body differs from the current authored SQL")
        body_sql = expected.sql(dialect="snowflake")
        current_hash = digest({"sql": body_sql, "parents": node.parent_relation_ids,
                               "authored_sql": digest(sql)})
        updated.append(node.model_copy(update={"sql_text": body_sql, "dependency_hash": current_hash}))
    return req.model_copy(update={"context": req.context.model_copy(update={
        "relation_graph": graph.model_copy(update={"nodes": updated})})})
