"""The final answer, per-target summaries, review choices applied to drafts, and the project name."""
from __future__ import annotations

import json
from types import SimpleNamespace

from app.agent_runtime.final_summary import dedupe_review_items, mapping_summaries, render_answer
from app.assistant_intent_classifier import requested_project_name
from app.core.workspace_snapshot import apply_review_choice


def _result() -> dict:
    return {
        "mapping_results": [
            {"target_table": "DB.T.CALLS", "mapping_key": "calls", "mapping_name": "CALLS", "sttm_id": "11",
             "mapping_rows": [{"target_column": "A", "status": "draft", "confidence": 0.9},
                              {"target_column": "B", "status": "unresolved"}],
             "sql_validation": {"compile_valid": True, "preview_valid": True, "compiled_mapping_preview_sql": "SELECT 1 AS A",
                                "compiled_mapping_sql": "INSERT INTO DB.T.CALLS (A)\nSELECT 1 AS A;",
                                "sql_repairs": [{"target_column": "A", "root_cause": "ambiguous_column",
                                                 "explanation": "Qualified ID with CONTACTS."}]},
             "dependency_resolutions": [{"target_column": "WHOID", "producer_mapping": "contacts",
                                         "producer_column": "LEGACY_ID", "status": "resolved", "reason": "Same key rule."}],
             "review_items": [
                 {"category": "mapping_candidate_review", "blocking": False, "safe_summary": "B: maybe",
                  "details": {"target_column": "B", "target_table": "DB.T.CALLS"}},
                 {"category": "mapping_candidate_review", "blocking": True, "safe_summary": "B: pick a source",
                  "details": {"target_column": "B", "target_table": "DB.T.CALLS"}},
             ]},
            {"target_table": "DB.T.MEETINGS", "mapping_key": "meetings", "mapping_name": "MEETINGS", "mapping_rows": [],
             "sql_validation": {"compile_valid": True, "preview_valid": False, "compiled_mapping_preview_sql": "SELECT 2 AS X",
                                "error_summary": "String too long", "failed_phase": "preview"}},
        ],
        "manifest": [{"mapping_key": "household", "mapping_name": "HOUSEHOLD", "target_table": "DB.T.HOUSEHOLD"}],
    }


def test_every_requested_target_gets_a_summary_and_status() -> None:
    summaries = mapping_summaries(_result(), ["DB.T.CALLS", "DB.T.MEETINGS", "DB.T.HOUSEHOLD", "DB.T.ALERTS"])
    assert [(item["mapping_name"], item["status"]) for item in summaries] == [
        ("CALLS", "needs_review"), ("MEETINGS", "preview_failed"), ("HOUSEHOLD", "blocked"), ("ALERTS", "no_source"),
    ]
    calls = summaries[0]
    assert (calls["mapped"], calls["unresolved"], calls["total"]) == (1, 1, 2)
    assert calls["select_sql"] == "SELECT 1 AS A" and calls["dependencies"][0]["producer_mapping"] == "contacts"
    # Prompt targets arrive as SCHEMA.TABLE: one summary per table, requested order.
    named = mapping_summaries(_result(), ["T.ALERTS", "T.CALLS", "T.MEETINGS", "T.HOUSEHOLD"])
    assert [(item["target_table"], item["status"]) for item in named] == [
        ("T.ALERTS", "no_source"), ("DB.T.CALLS", "needs_review"), ("DB.T.MEETINGS", "preview_failed"),
        ("DB.T.HOUSEHOLD", "blocked"),
    ]


def test_named_firm_value_script_is_preferred_over_resolved_preview() -> None:
    result = _result()
    result["mapping_results"][0]["sql_validation"]["compiled_mapping_script"] = (
        "-- Firm values\n"
        "SET TransactionFirmID = '001-firm';\n\n"
        "-- Read-only extraction query\n"
        "SELECT $TransactionFirmID AS TRANSACTION_FIRM__C;"
    )

    [calls, *_] = mapping_summaries(result, ["DB.T.CALLS"])

    assert "SET TransactionFirmID = '001-firm';" in calls["select_sql"]
    assert "$TransactionFirmID AS TRANSACTION_FIRM__C" in calls["select_sql"]
    assert "INSERT INTO" not in calls["select_sql"]


def test_answer_leads_with_saved_draft_counts_and_keeps_gaps_without_review_prompts() -> None:
    result = _result()
    summaries = mapping_summaries(result, ["DB.T.CALLS", "DB.T.MEETINGS", "DB.T.HOUSEHOLD", "DB.T.ALERTS"])
    items = [item for mapping in result["mapping_results"] for item in mapping.get("review_items") or []]
    assert len(dedupe_review_items(items)) == 1 and dedupe_review_items(items)[0]["blocking"] is True
    text = render_answer(summaries, items, project_name="Deep Agent Test TMD Baseline")
    assert text.startswith("**1 draft mapping generated; 1/2 target columns mapped.** Project: Deep Agent Test TMD Baseline.")
    assert "INSERT INTO" not in text
    assert "### What I fixed automatically\n- CALLS.A: Qualified ID with CONTACTS." in text
    assert "### Dependencies between targets" in text and "Missing results:" in text
    # Decisions are counted, not listed: they are answered in the review pane.
    assert "Needs review" not in text and "Decisions to make" not in text and "B: pick a source" not in text
    # Items without a target table are counted under their mapping, run-level ones under the target they name.
    grouped = render_answer(summaries, [
        {"category": "mapping_candidate_review", "blocking": True, "safe_summary": "x", "mapping_name": "NOTES",
         "subject_keys": ["TITLE"], "details": {"target_column": "TITLE"}},
        {"category": "key_validation", "blocking": False, "safe_summary": "y", "subject_keys": ["household"]},
    ])
    assert "Needs review" not in grouped and "Draft generated" in grouped
    assert "Which should I start with?" not in text and "No driving source was found for this target." in text
    # The block the chat UI lifts into the review pane keeps its exact form.
    assert "### CALLS: compiled SQL\nCompile passed; sample preview passed.\n```sql\nSELECT 1 AS A\n```" in text
    marker = text.split("<!--aia:mapping-summaries:")[1].rsplit("-->", 1)[0]
    assert [item["status"] for item in json.loads(marker)] == ["needs_review", "preview_failed", "blocked", "no_source"]


def test_a_review_choice_updates_the_draft_row_and_marks_the_sql_for_recompile() -> None:
    snapshot = {
        "mapping_rows": [{"id": "r1", "target_column": "OWNERID", "status": "UNMAPPED", "review_status": "unresolved",
                          "rule_status": "sql_rejected", "rejected_expression": "LOOKUP(X)", "source_columns": []}],
        "compiled_mapping_context_hash": "abc", "context_hash": "old", "page": "builder",
    }
    updated = apply_review_choice(snapshot, "ownerid", {
        "source_columns": ["DB.S.USERS.TARGET_CRM_ID"], "transformation": None, "confidence": 0.82,
        "reason": "Mapper table", "evidence_ids": ["precedent:9"],
    }, answered_by="42")
    row = updated["mapping_rows"][0]
    assert (row["status"], row["rule"], row["review_status"]) == ("MAPPED", "Direct", "draft")
    assert row["source_columns"] == ["DB.S.USERS.TARGET_CRM_ID"] and row["rejected_expression"] is None
    assert updated["compiled_mapping_context_hash"] is None and "context_hash" not in updated
    assert updated["checked_mapping_row_ids"] == ["r1"] and updated["page"] == "mapping"
    constant = apply_review_choice(snapshot, "OWNERID", {"constant_value": "Call", "source_columns": []}, answered_by="42")
    assert (constant["mapping_rows"][0]["mapping_mode"], constant["mapping_rows"][0]["rule"]) == ("constant", "Value")
    assert snapshot["mapping_rows"][0]["status"] == "UNMAPPED"  # the input is not changed


class _Session:
    def __init__(self, response: dict) -> None:
        self.response = response

    def sql(self, _text, params=None):
        return SimpleNamespace(collect=lambda statement_params=None: [[json.dumps(self.response)]])


def test_the_requested_project_name_must_appear_in_the_request() -> None:
    settings = SimpleNamespace(migration_agent_model_light="claude-haiku", assistant_intent_min_confidence=0.7,
                               assistant_intent_timeout_seconds=5)
    message = 'Create a new project called "Deep Agent Test TMD Baseline" and map all ten targets.'
    assert requested_project_name(_Session({"project_name": "Deep Agent Test TMD Baseline", "confidence": 0.95}),
                                  settings, message) == "Deep Agent Test TMD Baseline"
    assert requested_project_name(_Session({"project_name": "TMD Migration", "confidence": 0.95}), settings, message) is None
    assert requested_project_name(_Session({"project_name": "", "confidence": 0.95}), settings, "map calls") is None
    assert requested_project_name(_Session({"project_name": "Deep Agent Test TMD Baseline", "confidence": 0.3}),
                                  settings, message) is None
