"""Reproductions of V7 client review; synthetic data, real batch/runtime/compiler."""
import asyncio
import json
import pytest
from app.core.automap_evidence_blocks import EvidenceBlocks,EvidenceBlockError
from tests.unit.core.test_automap_evidence_blocks import review
from tests.unit.core.test_automap_fast_context import fast_payload,plan_for
from tests.unit.core.test_automap_fast_batch import prepared_request,answer_for
from tests.unit.core.test_automap_admission_v6 import wide_value,run
from tests.unit.core.test_automap_guarded_specialist import setup
from tests.test_automap_fast_transport import harness as transport_harness


def poison(body,kind):
    if kind=='nested_delegation':body['data']['meta']={'delegation':{'tool':'CORTEX_ANALYST'}}
    elif kind=='root_result':body['result']={'mappings':{'FOREIGN':{'source_attributes':['fake.PRIVATE']}}}
    elif kind=='nested_agent':body['data']['agent']='AGT_TRANSFORMATION_RULE'
    elif kind=='nested_error':body['data']['meta']={'error':'failed to read'}
    elif kind=='unknown_tool':body['tool_calls']=[{'name':'foreign tool'}]
    return body


@pytest.mark.parametrize('kind',['nested_delegation','root_result','nested_agent','nested_error','unknown_tool'])
def test_block_review_envelope_cannot_hide_actions_or_conflicting_answers(kind):
    registry=EvidenceBlocks('snapshot',120000,120000);registry.enabled=True;registry.begin()
    registry.project('Synthetic contract. '*20000)
    identity=registry.pending[0]
    raw=json.dumps(poison(json.loads(review(registry.blocks[identity])),kind))
    with pytest.raises(EvidenceBlockError):registry.accept(identity,raw)
    assert not registry.reviews


@pytest.mark.parametrize('kind',['nested_delegation','root_result'])
def test_bad_reviews_cannot_open_the_durable_evidence_gate(transport_harness,kind):
    h=transport_harness;builder,models,_,_=setup(h,1)
    value=fast_payload();value['data']['message']='Mandatory synthetic global contract. '*15000
    req=prepared_request(value);calls=[]
    def hook(outgoing):
        packet=json.JSONDecoder().raw_decode(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])[0]
        calls.append(packet['protocol'])
        assert packet['protocol']=='auto_map_exact_evidence_block_v1'
        h.state.answer=json.dumps(poison(json.loads(review(packet['context']['evidence_block'])),kind))
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(req))
    assert calls==['auto_map_exact_evidence_block_v1']*2
    assert final.result.mappings['NAME0'].transformation_classification=='unresolved'
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


@pytest.mark.parametrize('failure',['unknown_binding','malformed_response'])
def test_failed_continuation_retains_only_previously_verified_alternatives(failure):
    value=wide_value(2)
    _,plan=plan_for(value,max_chars=180000,max_bytes=180000)
    admitted=plan.binding_admissions()[0].source_ref
    actual_admitted=[]
    unread=next(f'{card.body["binding"]["sql_qualifier"]}.{card.body["column"]}'
        for key,cards in plan.eligible_by_ref.items() for card in cards if key not in plan.allowed)
    first=json.loads(answer_for(['NAME0','NAME1'],NAME0={'source_attributes':[admitted]},NAME1={
        'source_attributes':[],'candidate_source_attributes':[admitted],'confidence_score':0,
        'confidence_reason':'Verified alternative requires review.','transformation_classification':'unresolved',
        'unmatched_reason':'Inspect another existing source before choosing.'}))
    first['meta']={'evidence_requests':[{'snapshot_hash':None,'target':'NAME1','source_refs':[unread]}]}
    # Request envelopes remove local-only meta before hashing. Recover the exact
    # runtime snapshot as seen by the batch from its first outgoing packet.
    from tests.unit.core.test_automap_fast_batch import FinalAgent,service
    from tests.unit.core.test_automap_fast_context import unpack
    from app.core.automap_batch import invoke_batch
    from types import SimpleNamespace
    class Agent(FinalAgent):
        def run_detailed(self,messages,**kwargs):
            packet=unpack(messages)
            if not self.calls:
                current=packet['context']['selectable_sources'][0]['source_ref']
                actual_admitted.append(current)
                first['data']['result']['mappings']['NAME0']['source_attributes']=[current]
                first['data']['result']['mappings']['NAME1']['candidate_source_attributes']=[current]
                first['meta']['evidence_requests'][0]['snapshot_hash']=packet['context']['auto_map_retrieval']['snapshot_hash']
                self.answers=[json.dumps(first),*self.answers]
            return super().run_detailed(messages,**kwargs)
    bad=answer_for(['NAME1'],NAME1={'source_attributes':['a.RECORDTYPEID'],
        'candidate_source_attributes':['a.FABRICATED']}) if failure=='unknown_binding' else answer_for(['NAME1'],NAME1={
            'source_attributes':[{'source_column':'(','sql_qualifier':'a'}]})
    builder=service(Agent([bad]*8));builder._settings=builder._settings.model_copy(update={
        'agent_outbound_message_max_chars':180000,'agent_outbound_message_max_bytes':180000})
    raw,_,_=invoke_batch(builder,prepared_request(value),SimpleNamespace())
    rows=json.loads(raw)['data']['result']['mappings']
    assert len(builder._agent.calls)>=3
    assert rows['NAME0']['source_attributes']==actual_admitted
    assert rows['NAME1']['transformation_classification']=='unresolved'
    assert rows['NAME1']['source_attributes']==[]
    assert rows['NAME1']['candidate_source_attributes']==actual_admitted
    assert rows['NAME1']['confidence_reason']=='Verified alternative requires review.'


def test_oversized_atomic_identity_is_rejected_before_expensive_evidence_packing(monkeypatch):
    import app.core.automap_fast_context as module
    from app.core.automap_retrieval import AutoMapContext
    from tests.test_automap_fast_job import proxy
    value=fast_payload()
    value['data']['attributes'][0]['target_data_type']='x'*250000
    store=AutoMapContext(value);store.manifest()
    monkeypatch.setattr(module,'prepare_scan_context',lambda *args,**kwargs:pytest.fail('Unnecessary evidence projection'))
    with pytest.raises(module.FastIdentityBudgetError) as caught:
        module.FastContextPlan(store,max_chars=180000,max_bytes=180000)
    diagnostic=proxy()._preflight_budget_diagnostic(caught.value)
    assert diagnostic['measurement_kind']=='indivisible_identity_lower_bound'
    assert diagnostic['measured_chars']==250000 and diagnostic['model_call_count']==0
    assert diagnostic['reason']=='indivisible_identity_oversized'
    assert 'x'*100 not in json.dumps(diagnostic)


def test_large_semantic_text_does_not_take_the_atomic_identity_shortcut():
    value=fast_payload();value['data']['attributes'][0]['target_description']='x'*250000
    _,plan=plan_for(value,max_chars=180000,max_bytes=180000)
    assert plan.messages([]) and plan.required_pending_blocks()


@pytest.mark.parametrize('kind',['nested_delegation','root_result'])
def test_one_completed_bad_block_review_can_be_repaired_without_accepting_its_content(transport_harness,kind):
    h=transport_harness;builder,models,_,_=setup(h,1)
    value=fast_payload();value['data']['message']='Mandatory synthetic contract. '*9000
    calls=[];corrupted=[]
    def hook(outgoing):
        text=json.loads(outgoing.content)['messages'][0]['content'][0]['text']
        packet=json.JSONDecoder().raw_decode(text)[0]
        calls.append(packet.get('protocol'))
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            body=json.loads(review(packet['context']['evidence_block']))
            if not corrupted:
                corrupted.append(packet['context']['evidence_block']['block_id'])
                body=poison(body,kind)
            h.state.answer=json.dumps(body)
        else:h.state.answer=answer_for(['NAME0'])
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(prepared_request(value)))
    assert final.result.mappings['NAME0'].source_attributes==['a.X47']
    assert final.meta['automap_evidence_review_only_targets']==['NAME0']
    assert calls[:2]==['auto_map_exact_evidence_block_v1']*2
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


def test_matching_duplicate_result_and_metadata_locations_are_unambiguous():
    from copy import deepcopy
    registry=EvidenceBlocks('snapshot',120000,120000);registry.enabled=True;registry.begin()
    registry.project('Synthetic contract. '*10000)
    identity=registry.pending[0];body=json.loads(review(registry.blocks[identity]))
    body['result']=deepcopy(body['data']['result'])
    body['data']['meta']=deepcopy(body['meta']);body['data']['agent']=body['agent']
    registry.accept(identity,json.dumps(body))
    assert identity in registry.reviews


def test_bad_first_alternative_never_becomes_a_retained_verified_candidate():
    first=answer_for(['NAME0'],NAME0={'source_attributes':[],
        'candidate_source_attributes':['a.FABRICATED'],'confidence_score':0,
        'confidence_reason':'Unsupported claim must not survive.',
        'transformation_classification':'unresolved','unmatched_reason':'Need more evidence'})
    _,rows,_=run(wide_value(),[first]*8)
    assert rows['NAME0']['candidate_source_attributes']==[]
    assert rows['NAME0']['confidence_reason'] is None


def test_old_preflight_version_cannot_resume_under_v8(monkeypatch):
    from copy import deepcopy
    from app.core import auto_mapping_proxy as module
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from app.core.exceptions import SnowflakeAgentError
    from tests.test_automap_fast_job import proxy,authored
    client=proxy();frozen=client._freeze_resolution(authored(pending=1));client._build_batches(frozen)
    raw=frozen.model_dump(mode='json');plan=raw['meta'][module._RESOLUTION_PLAN_KEY]
    plan['preflight']['version']='fast-target-preflight-v3-admission'
    plan['preflight_hash']=client._resolution_digest(plan['preflight'])
    with pytest.raises(SnowflakeAgentError,match='preflight'):
        client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(raw))
