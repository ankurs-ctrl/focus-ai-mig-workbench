"""Offline runtime pipeline tests. No SQL, sockets, or live model requests."""
from copy import deepcopy
from dataclasses import asdict, replace
import hashlib
import json
from threading import Barrier, Event, Lock, Thread
import time

import httpx
import pytest

from app.core.automap_admission import Completion, Permit, ScanCallAdmission
from app.core.automap_parallel import ParallelArchiveError, ParallelLimits, prepare_parallel
from app.core.automap_reduce import CandidateKey
from app.core.automap_retrieval import AutoMapContext
from app.core.automap_scan import CandidateRole
from app.core.automap_scan_context import prepare_scan_context
from app.core.automap_scan_transport import ScanTransportConfig, SnowflakeScanTransport
from app.core.automap_shards import MessageBudget, ScopeMismatchError, SnapshotScope
from app.core.snowflake_agent import SnowflakeAgentClient
from app.schema.contracts import ApiWarning


BUDGET = MessageBudget(100_000, 100_000)


class Archive:
    def __init__(self):
        self.blobs = {}

    def put(self, reference, text):
        assert hashlib.sha256(text.encode("utf-8")).hexdigest() == reference
        assert reference not in self.blobs or self.blobs[reference] == text
        self.blobs[reference] = text

    def get(self, reference):
        return self.blobs[reference]

    def value(self, reference):
        return json.loads(self.get(reference))["value"]


class Pool:
    """Test-only permit store; exercise the real paired ScanCallAdmission."""
    lease_seconds = 120

    def __init__(self, capacity=2):
        self.capacity = capacity
        self.lock = Lock()
        self.held = {}
        self.serial = 0
        self.peak = 0
        self.completions = []
        self.quarantined = []
        self.claims = []
        self.deny = False

    def try_claim(self, identity):
        if self.deny:
            raise RuntimeError("private admission failure")
        with self.lock:
            if len(self.held) >= self.capacity:
                return None
            self.serial += 1
            permit = Permit("ORG.ACCOUNT", "epoch", self.serial, str(self.serial), 1, identity)
            self.held[permit.owner] = permit
            self.claims.append(identity)
            self.peak = max(self.peak, len(self.held))
            return permit

    def renew(self, permit):
        assert self.held[permit.owner] == permit

    def complete(self, permit, completion):
        with self.lock:
            self.held.pop(permit.owner)
            self.completions.append(completion)

    def quarantine(self, permit):
        self.quarantined.append(permit)


def make_store(*, tables=2, huge=True, all_huge=False, columns=4, targets=1):
    nodes = []
    for index in range(tables + int(huge)):
        oversized = all_huge or index == tables
        names = [{"name": f"COL_{column}", "data_type": "TEXT", "business_meaning":
                  "HUGE_PRIVATE_RECORD" * 5000 if oversized else "Business concept " + str(column)}
                 for column in range(columns)]
        nodes.append({"relation_id": f"source_{index}", "alias": f"s{index}", "kind": "TABLE",
                      "output_columns": names, "column_semantics": deepcopy(names), "parent_relation_ids": []})
    store = AutoMapContext({"operation": "sttm.auto_map", "context": {
        "owner_id": "untrusted-owner", "target_table": {"database": "D", "schema": "S", "table": "TARGET"},
        "workspace_context": {"driving_relation_id": "source_0", "filters": {"population": "business-only"}},
        "relation_graph": {"nodes": nodes, "edges": [
            {"left_relation_id": "source_0", "right_relation_id": node["relation_id"],
             "additional_predicate": "matched-business-key"} for node in nodes[1:]]},
        "learning_context": {"correction_history": [{"correction_id": "negative", "prevention_hint": "never use personal IDs"}],
                             "observations": [{"relation_id": "source_0", "rule": "preserve business grain"}]},
        "mapping_intent": {"guidance": "Keep leading zeros"}},
        "data": {"attributes": [{"target_attribute": f"TARGET_{index}"} for index in range(targets)]}})
    # Runtime preparation can have state not represented in the original payload.
    store.reads.add(("exact", "unrelated"))
    store.cursors["existing"] = ("read-key", 2, 500)
    store.available_evidence["TARGET_0"] = {"unadmitted": [{"secret": "not an admitted candidate"}]}
    return store


def limits_for(store, **changes):
    # Fit each normal whole table but force two tables into separate requests.
    prepared = prepare_scan_context(store, owner_id="caller", budget=MessageBudget(10_000_000, 10_000_000))
    messages = []
    for group_id, members in prepared.registry.atomic_groups.items():
        if group_id == "table:source_2":
            continue
        records = [record._payload() for record in prepared.records if record.record_id in members]
        text = prepared.registry._builder({"operation": "shard", "scope": asdict(prepared.scope),
                                           "shard_id": "0" * 64, "records": records})
        if "HUGE_PRIVATE_RECORD" not in text:
            messages.append(len(text.encode("utf-8")))
    scan_size = max(messages, default=10_000) + 100
    return replace(ParallelLimits(MessageBudget(scan_size, scan_size), BUDGET, BUDGET, BUDGET,
        max_workers=2, max_calls=30, max_reduction_rounds=20, candidate_cap=3, fan_in=6,
        max_selected_sources=3, max_selected_records=100), **changes)


def packet(request):
    return json.loads(json.loads(request.message)[0]["content"][0]["text"])


class Backend:
    def __init__(self, *, barrier=None, support=True):
        self.requests = []
        self.barrier = barrier
        self.support = support
        self.lock = Lock()

    def __call__(self, request):
        with self.lock:
            self.requests.append(request)
        body = packet(request)
        if body["protocol"] == "automap_scan_context_v1":
            if self.barrier:
                self.barrier.wait(timeout=5)
            candidates = []
            for record in body["batch"]["records"]:
                if record["kind"] == "source_column":
                    candidates.append({"record_id": record["record_id"], "role": "source",
                                       "evidence_refs": [record["record_id"]]})
                elif self.support and record["kind"] == "learning_evidence":
                    candidates.append({"record_id": record["record_id"], "role": "grain",
                                       "evidence_refs": [record["record_id"]]})
            return json.dumps({"generation": request.generation, "shard_id": request.shard_id,
                               "targets": [{"target_id": target, "candidates": candidates} for target in request.target_ids]})
        chosen = list(body["required_ids"])
        for target, role, minimum in body["role_minima"]:
            matches = [item["candidate_id"] for item in body["candidates"] if item["target_id"] == target and item["role"] == role]
            selected = sum(identity in chosen for identity in matches)
            chosen.extend([identity for identity in matches if identity not in chosen][:max(0, minimum - selected)])
        cap = body["response_schema"]["properties"]["selected_ids"]["maxItems"]
        if not chosen:
            chosen = [item["candidate_id"] for item in body["candidates"][:cap]]
        return json.dumps({"generation": request.generation, "round_id": body["round_id"], "complete": True,
                           "selected_ids": chosen, "mandatory_record_ids": [item["record_id"] for item in body["global_records"]]})


def run(store=None, *, backend=None, pool=None, archive=None, limits=None, deadline=None, cancellation=None):
    store = store if store is not None else make_store()
    backend = backend if backend is not None else Backend()
    pool = pool if pool is not None else Pool()
    archive = archive if archive is not None else Archive()
    gate = ScanCallAdmission(pool, job_id="job", caller_id="caller", heartbeat_seconds=30, poll_seconds=0.001)
    result = prepare_parallel(store, scope=SnapshotScope("caller", store.snapshot_hash), backend=backend,
        admission=gate, archive=archive, limits=limits or limits_for(store),
        deadline=deadline if deadline is not None else time.monotonic() + 30, cancellation=cancellation)
    return result, backend, pool, archive


def restore(value):
    if not isinstance(value, dict):
        return value
    items = value["items"]
    if value["type"] == "dict":
        return {restore(key): restore(item) for key, item in items}
    return {"list": list, "tuple": tuple, "set": set, "frozenset": frozenset}[value["type"]](restore(item) for item in items)


def test_real_pipeline_two_tables_plus_huge_parallel_scan_reduction_preserves_everything():
    store = make_store()
    original = deepcopy(vars(store))
    deadline = time.monotonic() + 30
    result, backend, pool, archive = run(store, backend=Backend(barrier=Barrier(2)), deadline=deadline)
    assert result.store is store and vars(store) == original
    assert pool.peak == 2 and not pool.held and not pool.quarantined
    scans = [request for request in backend.requests if packet(request)["protocol"] == "automap_scan_context_v1"]
    reductions = [request for request in backend.requests if packet(request)["protocol"] == "automap_reduce_v1"]
    assert len(scans) == 2 and reductions
    assert all(request.deadline == deadline for request in backend.requests)
    assert len(pool.claims) == len(backend.requests) == result.coverage.scan_reserved_calls + result.coverage.reduction_reserved_calls
    assert set(pool.completions) == {Completion.SUCCEEDED}
    assert result.coverage.initial_candidates == 9
    assert result.coverage.excluded_group_count == 1 and not result.coverage.scan_complete
    assert result.coverage.reduction_complete and result.selected_source_identities
    assert not result.coverage.mapping_blocked and result.coverage.review_required
    assert not result.coverage.exhaustive and not result.coverage.global_decision_complete
    assert result.coverage.incomplete_target_ids == ("TARGET_0",)
    assert all(item.relation != "source_2" for item in result.selected_source_identities)
    assert "HUGE_PRIVATE_RECORD" not in json.dumps(result.candidate_manifest)
    assert "not an admitted candidate" not in json.dumps(result.candidate_manifest)
    assert "non-exhaustive" in result.candidate_manifest["summary"]
    assert restore(archive.value(result.snapshot_archive_ref)["state"]) == original
    prepared = archive.value(result.prepared_archive_ref)
    assert "HUGE_PRIVATE_RECORD" in json.dumps(prepared)
    assert prepared["excluded_groups"][0]["group_id"] == "table:source_2"
    outcome = archive.value(result.outcome_archive_ref)
    assert outcome["scan"]["reserved_calls"] == 2 and outcome["reduction"]["candidate_archive_ref"]
    assert len(json.dumps(result.candidate_manifest, ensure_ascii=False).encode("utf-8")) < BUDGET.max_bytes
    assert all(ApiWarning.model_validate(item.model_dump(mode="json")) == item for item in result.warnings)
    exposed = result.candidate_manifest
    exposed.clear()
    assert result.candidate_manifest["candidates"]


def test_all_tables_oversized_is_partial_review_not_exception_or_global_no_match():
    store = make_store(all_huge=True)
    result, backend, pool, archive = run(store)
    assert not backend.requests and not pool.claims
    assert result.coverage.excluded_group_count == 3
    assert result.coverage.reduction_complete and not result.coverage.scan_complete
    assert not result.coverage.mapping_blocked and result.coverage.review_required
    assert not result.selected_source_identities
    assert "no_candidate_evidence" in {item.code for item in result.warnings}
    assert "HUGE_PRIVATE_RECORD" in archive.get(result.prepared_archive_ref)


def test_global_capsule_cannot_fit_blocks_before_any_call_and_archives_exact_state():
    store = make_store()
    limits = limits_for(store, scan_budget=MessageBudget(100, 100))
    result, backend, pool, archive = run(store, limits=limits)
    assert not backend.requests and not pool.claims
    assert result.coverage.mapping_blocked and not result.selected_source_identities
    assert "global_context_blocked" in {item.code for item in result.warnings}
    assert restore(archive.value(result.snapshot_archive_ref)["state"]) == vars(store)


@pytest.mark.parametrize("rounds,budget", [(0, 30), (1, 30), (20, 2), (20, 3), (20, 0)])
def test_exact_reserved_call_subtraction_and_round_limit(rounds, budget):
    store = make_store()
    result, backend, pool, _ = run(store, limits=limits_for(store, max_calls=budget, max_reduction_rounds=rounds))
    scan_calls = result.coverage.scan_reserved_calls
    reduce_calls = result.coverage.reduction_reserved_calls
    assert scan_calls == min(2, budget)
    assert reduce_calls <= min(rounds, budget - scan_calls)
    assert result.coverage.remaining_calls == budget - scan_calls - reduce_calls
    assert len(backend.requests) == scan_calls + reduce_calls == len(pool.claims)
    if budget >= 2 and rounds == 0:
        assert result.selected_source_identities and not result.coverage.reduction_complete


def test_failed_admission_reservations_are_not_refunded():
    pool = Pool()
    pool.deny = True
    store = make_store()
    result, backend, _, _ = run(store, pool=pool, limits=limits_for(store, max_calls=2))
    assert not backend.requests and result.coverage.scan_reserved_calls == 2
    assert result.coverage.remaining_calls == 0 and not result.coverage.mapping_blocked


@pytest.mark.parametrize("failure", ["invalid", "exception"])
def test_failed_reduction_keeps_original_candidates_and_archived_scan(failure):
    store = make_store()
    original = Backend()

    def backend(request):
        if packet(request)["protocol"] == "automap_reduce_v1":
            if failure == "invalid":
                return '{"private":"invalid model response"}'
            raise RuntimeError("private backend credential")
        return original(request)

    result, _, pool, archive = run(store, backend=backend)
    assert result.coverage.initial_candidates == 9 and not result.coverage.reduction_complete
    assert result.coverage.reduction_reserved_calls == 1
    assert result.selected_source_identities and not result.coverage.mapping_blocked
    assert result.reduction.candidate_archive_ref
    assert "private" not in json.dumps(result.candidate_manifest)
    assert len(pool.quarantined) == (failure == "exception")
    assert archive.value(result.outcome_archive_ref)["scan"]["reserved_calls"] == 2


@pytest.mark.parametrize("cancel", [True, False])
def test_canceled_or_expired_job_does_not_dispatch(cancel):
    event = Event()
    if cancel:
        event.set()
    result, backend, pool, _ = run(deadline=time.monotonic() + (30 if cancel else -1), cancellation=event)
    assert not backend.requests and not pool.claims
    assert result.coverage.scan_reserved_calls == result.coverage.reduction_reserved_calls == 0
    assert ("canceled" if cancel else "timed_out") in {item.code for item in result.warnings}


def test_selection_preserves_whole_dependency_bundles_and_non_source_roles():
    store = make_store()
    prepared = prepare_scan_context(store, owner_id="caller", budget=BUDGET)
    source = next(record for record in prepared.records if record.kind == "source_column" and record.body["relation"] == "source_0")
    grain = next(record for record in prepared.records if record.kind == "learning_evidence")
    pins = (CandidateKey("TARGET_0", CandidateRole.SOURCE, source.record_id),
            CandidateKey("TARGET_0", CandidateRole.GRAIN, grain.record_id))
    result, _, _, _ = run(store, limits=limits_for(store, pinned=pins, candidate_cap=2))
    assert result.coverage.reduction_complete
    assert {item["role"] for item in result.candidate_manifest["candidates"]} == {"source", "grain"}
    assert result.learning_candidates and result.support_cards
    assert grain.record_id in {record.record_id for record in result.support_cards}
    group = set(prepared.registry.atomic_groups["table:source_0"])
    selected = {record["record_id"] for record in result.candidate_manifest["records"]}
    assert group <= selected


def test_too_small_record_cap_never_clips_dependency_bundle():
    store = make_store()
    result, _, _, _ = run(store, limits=limits_for(store, max_selected_records=1))
    assert not result.candidate_manifest["candidates"]
    assert not result.candidate_manifest["records"]
    assert not result.coverage.selection_complete and not result.coverage.mapping_blocked


def test_source_cap_applies_without_promoting_support_columns_to_selected_sources():
    store = make_store()
    result, _, _, _ = run(store, limits=limits_for(store, max_selected_sources=1))
    assert len(result.selected_source_identities) == 1
    assert len(result.bounded_source_cards) == 1
    assert any(record.kind == "source_column" for record in result.support_cards)
    assert not result.coverage.selection_complete


def test_foreign_scope_and_missing_injections_fail_before_archive_or_dispatch():
    store = make_store()
    archive, backend, pool = Archive(), Backend(), Pool()
    gate = ScanCallAdmission(pool, job_id="job", caller_id="caller")
    arguments = dict(scope=SnapshotScope("caller", store.snapshot_hash), backend=backend,
                     admission=gate, archive=archive, limits=limits_for(store), deadline=time.monotonic() + 30)
    for changed in ({"scope": SnapshotScope("foreign", store.snapshot_hash)},
                    {"scope": SnapshotScope("caller", "old")}, {"admission": None},
                    {"archive": None}, {"backend": None}):
        with pytest.raises((ScopeMismatchError, TypeError)):
            prepare_parallel(store, **{**arguments, **changed})
    assert not backend.requests and not archive.blobs and not pool.claims


def test_archive_failure_is_fail_closed_before_calls():
    class BrokenArchive(Archive):
        def put(self, reference, text):
            raise OSError("private storage credential")

    backend = Backend()
    with pytest.raises(ParallelArchiveError, match="write failed"):
        run(backend=backend, archive=BrokenArchive())
    assert not backend.requests


@pytest.mark.parametrize("field,value", [("max_calls", -1), ("max_workers", 0), ("fan_in", 2),
    ("candidate_cap", True), ("max_selected_sources", 0), ("max_selected_records", 0),
    ("max_reduction_rounds", -1), ("selection_budget", None)])
def test_invalid_configuration_rejected(field, value):
    with pytest.raises((TypeError, ValueError)):
        limits_for(make_store(), **{field: value})


def test_real_transport_with_mock_http_runs_scan_and_reduce_without_old_agent_path(monkeypatch):
    store, backend = make_store(), Backend()
    agent = SnowflakeAgentClient(token="test-only-token", host="account.snowflakecomputing.com", role="CALLER")
    monkeypatch.setattr(agent, "run_detailed", lambda *args, **kwargs: pytest.fail("Old retrying path used"))
    protocols = []

    def handler(request):
        assert request.headers["Authorization"] == "Bearer test-only-token"
        messages = json.loads(request.content)["messages"]
        body = json.loads(messages[0]["content"][0]["text"])
        protocols.append(body["protocol"])
        # Exercise real transport serialization/extraction; backend receives the
        # same checked logical request from the dispatch-side test wrapper.
        raw = backend(active_requests[body.get("round_id", body.get("batch", {}).get("shard_id"))])
        data = json.dumps({"role": "assistant", "status": "completed", "content": [{"type": "text", "text": raw}]})
        return httpx.Response(200, stream=httpx.ByteStream(data.encode("utf-8")))

    active_requests = {}
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        transport = SnowflakeScanTransport(agent_client=agent, http_client=client,
                                          config=ScanTransportConfig("D.S.SCAN", 100_000))

        def raw_backend(request):
            active_requests[request.shard_id] = request
            return transport(request)

        result, _, pool, _ = run(store, backend=raw_backend)
    assert set(protocols) == {"automap_scan_context_v1", "automap_reduce_v1"}
    assert result.coverage.reduction_complete and len(protocols) == len(pool.claims)


def test_reduction_timeout_returns_without_releasing_running_workers_permit():
    entered, release, finished = Event(), Event(), Event()
    backend = Backend()
    pool = Pool()
    outputs = []
    store = make_store()
    limits = limits_for(store)

    def slow(request):
        if packet(request)["protocol"] == "automap_reduce_v1":
            entered.set()
            release.wait(5)
            try:
                request.check_active()
            finally:
                finished.set()
        return backend(request)

    def coordinate():
        outputs.append(run(store, backend=slow, pool=pool, limits=limits, deadline=time.monotonic() + 1)[0])

    thread = Thread(target=coordinate)
    thread.start()
    try:
        assert entered.wait(3)
        thread.join(3)
        assert not thread.is_alive() and outputs
        assert pool.held and not pool.quarantined
        assert outputs[0].coverage.reduction_reserved_calls == 1
        assert not outputs[0].coverage.reduction_complete
    finally:
        release.set()
        thread.join(5)
    assert finished.wait(2)
    deadline = time.monotonic() + 2
    while not pool.quarantined and time.monotonic() < deadline:
        time.sleep(0.01)
    assert pool.quarantined and pool.held


def test_fallback_reserves_complementary_roles_across_targets():
    store = make_store(targets=2)
    limits = limits_for(store, max_reduction_rounds=0, candidate_cap=4, fan_in=8,
                        role_minima=((CandidateRole.SOURCE, 1), (CandidateRole.GRAIN, 1)))
    result, _, _, _ = run(store, limits=limits)
    assert {(item["target_id"], item["role"]) for item in result.candidate_manifest["candidates"]} == {
        (target, role) for target in ("TARGET_0", "TARGET_1") for role in ("source", "grain")}
    assert "selection_constraints_blocked" not in {warning.code for warning in result.warnings}


def test_candidate_selection_spreads_sources_across_targets_before_alternatives():
    store = make_store(tables=1, huge=False, columns=3, targets=4)
    limits = limits_for(store, max_reduction_rounds=0, candidate_cap=4,
                        fan_in=8, max_selected_sources=4)
    result, _, _, _ = run(store, limits=limits)
    chosen = result.candidate_manifest["candidates"]
    assert len(chosen) == 4
    assert {item["target_id"] for item in chosen} == {f"TARGET_{index}" for index in range(4)}
    assert all(item["role"] == "source" for item in chosen)


def test_source_warning_schema_retains_oversized_table_identity_and_counts():
    result, _, _, _ = run()
    warning = next(warning for warning in result.warnings if warning.code == "table_context_oversized")
    assert warning.field == "table:source_2" and "records" in warning.message
    assert result.candidate_manifest["omitted_scan_warning_count"] == 0
    assert ApiWarning.model_validate(warning.model_dump(mode="json")) == warning


def test_parent_dependency_that_cannot_fit_does_not_discard_independent_table():
    store = make_store()
    store.nodes["source_0"]["parent_relation_ids"] = ["source_2"]
    result, _, _, _ = run(store, limits=limits_for(store, max_reduction_rounds=0, candidate_cap=9, fan_in=10))
    assert result.selected_source_identities
    assert {identity.relation for identity in result.selected_source_identities} == {"source_1"}
    assert not result.coverage.mapping_blocked and not result.coverage.selection_complete


def test_pin_that_cannot_fit_blocks_selection_not_unknown_global_mapping():
    store = make_store()
    prepared = prepare_scan_context(store, owner_id="caller", budget=BUDGET)
    record = next(record for record in prepared.records if record.kind == "source_column")
    key = CandidateKey("TARGET_0", CandidateRole.SOURCE, record.record_id)
    result, _, _, _ = run(store, limits=limits_for(store, pinned=(key,), max_selected_records=1))
    assert not result.selected_source_identities
    assert "selection_constraints_blocked" in {warning.code for warning in result.warnings}
    assert not result.coverage.mapping_blocked


def test_byte_budget_is_checked_for_complete_manifest_with_unicode():
    store = make_store(huge=False)
    store.original["context"]["mapping_intent"]["guidance"] = "\u4e1a\u52a1" * 1000
    result, _, _, _ = run(store, limits=limits_for(store, selection_budget=MessageBudget(100_000, 30_000)))
    text = json.dumps(result.candidate_manifest, separators=(",", ":"), ensure_ascii=False)
    assert len(text.encode("utf-8")) <= 30_000 and len(text) <= 100_000


def test_reduction_arbitrary_backend_failure_remains_bounded_review():
    real = Backend()

    def failing(request):
        if packet(request)["protocol"] == "automap_reduce_v1":
            raise OSError("private transport detail")
        return real(request)

    result, _, pool, _ = run(backend=failing)
    assert result.coverage.reduction_reserved_calls == 1
    assert result.selected_source_identities and pool.quarantined
    assert "private" not in json.dumps(result.candidate_manifest)


def test_archive_failure_during_reduction_is_not_downgraded_to_partial():
    class LaterFailure(Archive):
        def put(self, reference, text):
            body = json.loads(text)["value"]
            if isinstance(body, dict) and "row" in body:
                raise OSError("private archive failure")
            super().put(reference, text)

    with pytest.raises(ParallelArchiveError):
        run(archive=LaterFailure())


def test_complete_empty_scan_is_still_unknown_not_no_match():
    def empty(request):
        return json.dumps({"generation": request.generation, "shard_id": request.shard_id,
                           "targets": [{"target_id": target, "candidates": []} for target in request.target_ids]})

    result, _, _, _ = run(make_store(huge=False), backend=empty)
    assert result.coverage.scan_complete and result.coverage.reduction_complete
    assert not result.coverage.mapping_blocked and not result.coverage.exhaustive
    assert result.coverage.review_required and not result.selected_source_identities


def test_shared_archive_scopes_every_snapshot_and_result_to_authenticated_owner():
    store = make_store()
    archive = Archive()
    first, _, _, _ = run(store, archive=archive)
    gate = ScanCallAdmission(Pool(), job_id="other-job", caller_id="other-caller")
    second = prepare_parallel(store, scope=SnapshotScope("other-caller", store.snapshot_hash), backend=Backend(),
        admission=gate, archive=archive, limits=limits_for(store), deadline=time.monotonic() + 30)
    assert first.snapshot_archive_ref != second.snapshot_archive_ref
    assert first.prepared_archive_ref != second.prepared_archive_ref
    assert first.outcome_archive_ref != second.outcome_archive_ref
    for result in (first, second):
        for reference in (result.snapshot_archive_ref, result.prepared_archive_ref, result.outcome_archive_ref):
            assert json.loads(archive.get(reference))["scope"] == asdict(result.scope)


def test_corrupt_archive_read_is_not_silently_accepted():
    class CorruptArchive(Archive):
        def get(self, reference):
            return super().get(reference) + " "

    with pytest.raises(ParallelArchiveError, match="integrity"):
        run(archive=CorruptArchive())


def test_global_selection_capsule_overflow_returns_blocked_manifest_without_clipping():
    store = make_store()
    result, _, _, _ = run(store, limits=limits_for(store, selection_budget=MessageBudget(4000, 4000)))
    assert result.coverage.mapping_blocked
    assert not result.candidate_manifest["global_records"] and not result.candidate_manifest["candidates"]
    assert not result.coverage.selection_complete
    assert "Do not invoke" in result.candidate_manifest["instructions"]
