'use client';
import { AiaBox, AiaButton, AiaIconButton, AiaChip, AiaPaper, AiaTableBody, AiaTableCellPrimitive, AiaTableContainer, AiaTableHead, AiaTablePagination, AiaTablePrimitive, AiaTableRowPrimitive } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useEffect, useMemo, useState } from 'react';
import { ArrowForwardRoundedIcon, CheckRoundedIcon, CloseRoundedIcon, FileUploadOutlinedIcon, UndoRoundedIcon } from '@/utils/icons';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { useTour } from '@/features/tour/engine/tour-context';

import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import type { MappingMode } from '@/features/sttm/types/sttm.types';
import {
  buildSourceColumnOptions,
  formatSqlType,
  generateMappingDescription,
  parseSourceColumns,
} from './mapping-utils';
import { toProjectAttributeSelectOptions, filterAttributesForProject } from './project-attribute-utils';
import { useProjectAttributes } from './use-project-attributes';
import { AiaCheckbox } from '@/components/ui/aia-checkbox';
import { AiaInput } from '@/components/ui/aia-input';
import { AiaCheckboxCell, AiaInputCell } from '@/components/ui/aia-table';
import {
  MappingConfidenceCell,
  MappingExpandableTextCell,
  MappingRuleCell,
  MappingSourceColumnsCell,
  MappingStatusCell,
  MappingTargetColumnCell,
  MappingTypePreviewCell,
} from './cells';
import type { FIRMappingCandidate } from './cells/mapping-source-columns-cell';
import {
  recommendationService,
  type ApplicableRecommendation,
} from '@/services/recommendationService';
import { MappingDataPreviewCell } from './data-preview';
import {
  MAPPING_TABLE_CHECKBOX_SX,
  MAPPING_TABLE_CONTAINER_SX,
  MAPPING_SELECTION_BAR_SX,
  MAPPING_TABLE_HEADER_CELL_SX,
  MAPPING_TABLE_HEADER_ROW_HEIGHT,
  MAPPING_TABLE_PAGINATION_SX,
  MAPPING_TABLE_ROW_SX,
  MAPPING_TABLE_SECONDARY_INPUT_SX,
  MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
  mappingTableSx,
} from './mapping-table-styles';
import { MappingResizableHeaderCell } from './mapping-resizable-header-cell';
import { MappingHeaderSearchLabel } from './mapping-header-search-label';
import { mappingColumnDividerSx } from './mapping-column-divider';
import {
  getVisibleMappingColumnKeys,
  useMappingColumnWidths,
} from './use-mapping-column-widths';
import {
  CONFIDENCE_GROUP_ORDER,
  countMappingsByConfidenceGroup,
  getConfidenceGroup,
  hasConfidenceScore,
  sortMappingsByConfidenceGroups,
  type ConfidenceGroupId,
} from './mapping-confidence-groups';
import { MappingConfidenceGroupHeaderRow } from './mapping-confidence-group-header';
import { MappingChangeConfirmDialog } from './mapping-change-confirm-dialog';
import {
  MAPPED_ROW_CHANGE_MESSAGES,
  useConfirmMappedRowChange,
} from './use-confirm-mapped-row-change';
import { useMappingUndo } from './use-mapping-undo';
import DirectSourcePickerModal from './direct-source-picker-modal';

const MAPPING_ACTION_OUTLINED_BUTTON_SX = {
  color: '#0f172a',
  textTransform: 'none',
  fontSize: '0.78rem',
  fontWeight: 600,
  px: 1.25,
  borderColor: '#cbd5e1',
  borderRadius: '8px',
  bgcolor: 'transparent',
  '&:hover': {
    bgcolor: 'rgba(15, 23, 42, 0.06)',
    borderColor: '#94a3b8',
  },
} as const;

const DEFAULT_EXPANDED_CONFIDENCE_GROUPS: Record<ConfidenceGroupId, boolean> = {
  high: true,
  medium: true,
  low: true,
};

const MAPPING_TYPE_DIRECT = 'direct';
const MAPPING_TYPE_ATTRIBUTE = 'attribute';
const MAPPING_TYPE_CUSTOM = 'custom';

const MAPPING_TYPE_OPTIONS = [
  { label: 'Attribute', value: MAPPING_TYPE_ATTRIBUTE },
  { label: 'Custom', value: MAPPING_TYPE_CUSTOM },
  { label: 'Direct', value: MAPPING_TYPE_DIRECT },
];

const MAPPING_TYPE_FILTER_OPTIONS = [
  { label: 'All', value: '' },
  ...MAPPING_TYPE_OPTIONS,
];

function resolveMappingRuleSelectValue(rule: string | null | undefined): string {
  return rule && rule !== 'Select...' ? rule : '';
}

function resolveMappingTypeSelectValue(row: {
  rule?: string | null;
  mappingMode?: MappingMode | null;
}): string {
  const resolvedRule = resolveMappingRuleSelectValue(row.rule);
  if (resolvedRule === 'Custom') {
    return MAPPING_TYPE_CUSTOM;
  }
  if (row.mappingMode === 'attribute') {
    return MAPPING_TYPE_ATTRIBUTE;
  }
  return MAPPING_TYPE_DIRECT;
}

function resolveMappingDescription(
  row: {
    targetColumn: string;
    expression?: string | null;
    description?: string | null;
    descriptionEdited?: boolean;
  },
  sourceColumns: string[],
  resolvedRule: string,
): string {
  const autoDescription = resolvedRule
    ? generateMappingDescription({
        rule: resolvedRule,
        sourceColumns,
        targetColumn: row.targetColumn,
        expression: row.expression,
      })
    : '';

  return row.descriptionEdited ? (row.description ?? '') : autoDescription;
}

const DEFAULT_ROWS_PER_PAGE = 25;
const ROWS_PER_PAGE_OPTIONS = [10, 25, 50, 100];

type MappingColumnFilters = {
  targetColumn: string;
  sourceColumn: string;
  typePreview: string;
  preProcessRule: string;
  nlRule: string;
  order: string;
  description: string;
  status: string;
};

const EMPTY_COLUMN_FILTERS: MappingColumnFilters = {
  targetColumn: '',
  sourceColumn: '',
  typePreview: '',
  preProcessRule: '',
  nlRule: '',
  order: '',
  description: '',
  status: '',
};

const STATUS_FILTER_OPTIONS = [
  { label: 'All', value: '' },
  { label: 'Mapped', value: 'MAPPED' },
  { label: 'Unmapped', value: 'UNMAPPED' },
];

const headerCellSx = MAPPING_TABLE_HEADER_CELL_SX;

/** Default column widths on first render. */
const MAPPING_COLUMN_DEFAULT_WIDTH = {
  checkbox: 52,
  targetColumn: 320,
  sourceColumn: 320,
  preProcessRule: 200,
  confidence: 140,
  typePreview: 190,
  nlRule: 240,
  order: 150,
  description: 280,
  status: 170,
  dataPreview: 180,
} as const;

/** Resize floor — columns can shrink below the default down to these values. */
const MAPPING_COLUMN_MIN_WIDTH = {
  checkbox: 48,
  targetColumn: 220,
  sourceColumn: 200,
  preProcessRule: 180,
  confidence: 120,
  typePreview: 160,
  nlRule: 140,
  order: 120,
  description: 200,
  status: 150,
  dataPreview: 150,
} as const;

const FROZEN_CHECKBOX_LEFT = 0;

const multilineCellInputSx = {
  ...MAPPING_TABLE_SECONDARY_INPUT_SX,
  '& .MuiOutlinedInput-root': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    alignItems: 'flex-start',
    minHeight: 0,
    height: 'auto',
  },
  '& .MuiInputBase-input, & .MuiInputBase-inputMultiline': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    whiteSpace: 'pre-wrap',
    overflowWrap: 'anywhere',
    overflow: 'hidden !important',
  },
} as const;

const mappingBodyInputSx = {
  ...MAPPING_TABLE_SECONDARY_INPUT_SX,
  '& .MuiOutlinedInput-root': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    minHeight: 36,
    borderRadius: '6px',
    bgcolor: '#fff',
  },
  '& .MuiInputBase-input': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    paddingY: '8px !important',
  },
} as const;

function mappingFrozenCellSx(
  left: number,
  options: { header?: boolean; lastFrozen?: boolean; searchRow?: boolean } = {},
) {
  const { header = false, lastFrozen = false, searchRow = false } = options;
  const backgroundColor = header || searchRow ? '#fafafa' : '#fff';

  const zIndex = (() => {
    if (header) {
      return lastFrozen ? 9 : 8;
    }
    if (searchRow) {
      return lastFrozen ? 9 : 8;
    }
    return lastFrozen ? 5 : 4;
  })();

  return {
    position: 'sticky' as const,
    left,
    top: header ? 0 : searchRow ? MAPPING_TABLE_HEADER_ROW_HEIGHT : undefined,
    zIndex,
    bgcolor: backgroundColor,
    backgroundColor,
  };
}

const scrollableBodyCellSx = {
  position: 'relative' as const,
  zIndex: 1,
  bgcolor: '#fff',
  backgroundColor: '#fff',
  ...mappingColumnDividerSx,
} as const;

const scrollableHeaderCellSx = {
  position: 'sticky' as const,
  top: 0,
  zIndex: 2,
  bgcolor: '#fafafa',
  backgroundColor: '#fafafa',
} as const;

const SourceTargetAttributeMapping = () => {
  const {
    mappings,
    selectedMappingIds,
    toggleMappingSelection,
    selectAllMappings,
    bulkMarkMapped,
    bulkSetDirect,
    updateMapping,
    setPreProcessModalOpen,
    mappingLoading,
    autoMapStatusMessage,
    autoMapProcessingIds,
    autoMapGroupingEnabled,
    sourceAttributeGroups,
    derivedSources,
    fullData,
    activeProjectId,
    activeProjectName,
    activeSttmId,
    flushWorkspace,
    getWorkspaceSnapshot,
  } = useSttmBuilderContext();
  const { notifyTourContextChanged } = useTour();

  const [columnFilters, setColumnFilters] = useState<MappingColumnFilters>(EMPTY_COLUMN_FILTERS);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(DEFAULT_ROWS_PER_PAGE);
  const [expandedConfidenceGroups, setExpandedConfidenceGroups] = useState<
    Record<ConfidenceGroupId, boolean>
  >(DEFAULT_EXPANDED_CONFIDENCE_GROUPS);
  const [applicableRecommendations, setApplicableRecommendations] = useState<ApplicableRecommendation[]>([]);
  const [recommendationUndoByRow, setRecommendationUndoByRow] = useState<Record<string, {
    sourceColumn: string | null;
    sourceColumns: string[];
    status: "MAPPED" | "UNMAPPED" | "PROCESSING";
    confidenceScore: number | null;
    confidenceReason: string | null;
    usedRecommendationIds: string[];
  }>>({});
  const [recommendationActionErrors, setRecommendationActionErrors] = useState<Record<string, string>>({});
  const [directPickerMappingId, setDirectPickerMappingId] = useState<string | null>(null);
  const {
    projectAttributes,
    isLoadingProjectAttributes,
    reloadProjectAttributes,
  } = useProjectAttributes(activeProjectId);
  const {
    pendingChange: pendingMappedRowChange,
    confirmIfMappedRowChange,
    closeConfirm: closeMappedRowChangeConfirm,
    confirmChange: confirmMappedRowChange,
  } = useConfirmMappedRowChange();
  const {
    undoCount,
    canUndo,
    updateMappingWithUndo,
    undoLastChange,
    clearUndoStack,
  } = useMappingUndo(mappings, updateMapping);
  const directPickerMapping = useMemo(
    () => mappings.find((mapping) => mapping.id === directPickerMappingId) ?? null,
    [directPickerMappingId, mappings],
  );
  const showConfidenceColumn = useMemo(
    () =>
      autoMapGroupingEnabled
      || mappings.some((row) => hasConfidenceScore(row.confidenceScore)),
    [autoMapGroupingEnabled, mappings],
  );
  const confidenceGroupingActive = showConfidenceColumn;
  const visibleColumnKeys = useMemo(
    () => getVisibleMappingColumnKeys(showConfidenceColumn),
    [showConfidenceColumn],
  );
  const { columnWidths, onResizeStart, tableMinWidth, frozenTargetColumnLeft } =
    useMappingColumnWidths(
      MAPPING_COLUMN_DEFAULT_WIDTH,
      MAPPING_COLUMN_MIN_WIDTH,
      visibleColumnKeys,
    );

  const sortedMappings = mappings;
  const sourceColumnOptions = buildSourceColumnOptions(sourceAttributeGroups, derivedSources);
  const projectAttributesForActiveProject = useMemo(
    () => filterAttributesForProject(projectAttributes, activeProjectId),
    [projectAttributes, activeProjectId],
  );
  const attributeOptions = useMemo(
    () => toProjectAttributeSelectOptions(projectAttributesForActiveProject),
    [projectAttributesForActiveProject],
  );

  useEffect(() => {
    clearUndoStack();
  }, [activeSttmId, clearUndoStack]);

  const allSelected = mappings.length > 0 && selectedMappingIds.length === mappings.length;
  const someSelected = selectedMappingIds.length > 0 && selectedMappingIds.length < mappings.length;
  const selectedMappedCount = mappings.filter(
    (row) => selectedMappingIds.includes(row.id) && row.status === 'MAPPED',
  ).length;
  const clearSelection = () =>
    selectAllMappings(
      mappings.map((row) => row.id),
      false,
    );

  const handleMappingTypeChange = (id: string, mappingType: string) => {
    const row = mappings.find((mapping) => mapping.id === id);
    if (!row) return;

    const sourceColumns =
      row.sourceColumns && row.sourceColumns.length
        ? row.sourceColumns
        : parseSourceColumns(row.sourceColumn);

    const updates: Partial<typeof row> = {};

    if (mappingType === MAPPING_TYPE_CUSTOM) {
      updates.rule = 'Custom';
      updates.mappingMode = 'source';
      updates.constantValue = null;
      updates.attributeName = null;
    } else if (mappingType === MAPPING_TYPE_ATTRIBUTE) {
      updates.rule = 'Direct';
      updates.mappingMode = 'attribute';
      updates.sourceColumn = null;
      updates.sourceColumns = [];
      updates.sourceType = null;
      updates.expression = null;
      updates.constantValue = row.attributeName
        ? row.constantValue
        : null;
      updates.attributeName = row.attributeName ?? null;
      updates.status = (row.attributeName ?? '').trim() ? 'MAPPED' : 'UNMAPPED';
      updates.confidenceScore = null;
      updates.confidenceReason = (row.attributeName ?? '').trim()
        ? 'A firm value was assigned manually.'
        : null;
    } else {
      updates.rule = 'Direct';
      updates.mappingMode = 'source';
      updates.constantValue = null;
      updates.attributeName = null;
      updates.status =
        row.sourceColumns?.length || row.sourceColumn ? 'MAPPED' : 'UNMAPPED';
      updates.confidenceScore = null;
      updates.confidenceReason = null;
    }

    const nextRule = (updates.rule ?? row.rule) as string;
    if (!row.descriptionEdited) {
      updates.description =
        generateMappingDescription({
          rule: nextRule,
          sourceColumns:
            mappingType === MAPPING_TYPE_ATTRIBUTE ? [] : sourceColumns,
          targetColumn: row.targetColumn,
          expression: mappingType === MAPPING_TYPE_CUSTOM ? row.expression : null,
        }) || null;
    }

    updateMappingWithUndo(id, updates);
  };

  const filteredMappings = useMemo(() => {
    const includes = (value: string | null | undefined, query: string) =>
      String(value ?? '').toLowerCase().includes(query.trim().toLowerCase());

    return sortedMappings.filter((row) => {
      const previewType = formatSqlType(row.sourceType ?? row.targetType ?? undefined);
      const sourceColumns =
        row.sourceColumns && row.sourceColumns.length
          ? row.sourceColumns
          : parseSourceColumns(row.sourceColumn);
      const resolvedRule = resolveMappingRuleSelectValue(row.rule);
      const descriptionValue = resolveMappingDescription(row, sourceColumns, resolvedRule);

      if (columnFilters.targetColumn && !includes(row.targetColumn, columnFilters.targetColumn)) {
        return false;
      }
      if (
        columnFilters.sourceColumn
        && !includes(
          row.mappingMode === "constant"
            ? row.constantValue
            : row.mappingMode === "attribute"
              ? row.attributeName
              : row.sourceColumn,
          columnFilters.sourceColumn,
        )
      ) {
        return false;
      }
      if (columnFilters.typePreview && !includes(previewType, columnFilters.typePreview)) {
        return false;
      }
      if (columnFilters.preProcessRule) {
        if (resolveMappingTypeSelectValue(row) !== columnFilters.preProcessRule) {
          return false;
        }
      }
      if (columnFilters.nlRule && !includes(row.nlRule, columnFilters.nlRule)) {
        return false;
      }
      if (columnFilters.order && !includes(row.loadOrder, columnFilters.order)) {
        return false;
      }
      if (columnFilters.description && !includes(descriptionValue, columnFilters.description)) {
        return false;
      }
      if (columnFilters.status && row.status !== columnFilters.status) {
        return false;
      }
      return true;
    });
  }, [columnFilters, sortedMappings]);

  useEffect(() => {
    if (selectedMappingIds.length > 0) {
      notifyTourContextChanged();
    }
  }, [notifyTourContextChanged, selectedMappingIds.length]);

  const sortedForDisplay = useMemo(() => {
    if (!confidenceGroupingActive) {
      return filteredMappings;
    }
    return sortMappingsByConfidenceGroups(filteredMappings);
  }, [confidenceGroupingActive, filteredMappings]);

  const confidenceGroupCounts = useMemo(
    () => countMappingsByConfidenceGroup(filteredMappings),
    [filteredMappings],
  );

  const toggleConfidenceGroup = (groupId: ConfidenceGroupId) => {
    setExpandedConfidenceGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
    setPage(0);
  };

  /** Rows that remain visible after collapsing confidence groups (pagination counts these). */
  const expandableRowsForDisplay = useMemo(() => {
    if (!confidenceGroupingActive) {
      return sortedForDisplay;
    }
    return sortedForDisplay.filter((row) => {
      const groupId = getConfidenceGroup(row.confidenceScore, row.status);
      return expandedConfidenceGroups[groupId] !== false;
    });
  }, [confidenceGroupingActive, sortedForDisplay, expandedConfidenceGroups]);

  type MappingTableBodyItem =
    | { kind: 'header'; groupId: ConfidenceGroupId }
    | { kind: 'row'; row: (typeof sortedForDisplay)[number] };

  const mappingTableBodyItems = useMemo((): MappingTableBodyItem[] => {
    if (!confidenceGroupingActive) {
      return expandableRowsForDisplay.map((row) => ({ kind: 'row' as const, row }));
    }

    const items: MappingTableBodyItem[] = [];
    for (const groupId of CONFIDENCE_GROUP_ORDER) {
      const groupRows = sortedForDisplay.filter(
        (row) => getConfidenceGroup(row.confidenceScore, row.status) === groupId,
      );
      if (!groupRows.length) {
        continue;
      }
      items.push({ kind: 'header', groupId });
      if (expandedConfidenceGroups[groupId] !== false) {
        for (const row of groupRows) {
          items.push({ kind: 'row', row });
        }
      }
    }
    return items;
  }, [
    confidenceGroupingActive,
    expandableRowsForDisplay,
    sortedForDisplay,
    expandedConfidenceGroups,
  ]);

  useEffect(() => {
    if (confidenceGroupingActive) {
      setPage(0);
    }
  }, [confidenceGroupingActive]);

  const maxPage = Math.max(0, Math.ceil(expandableRowsForDisplay.length / rowsPerPage) - 1);
  const safePage = Math.min(page, maxPage);

  const paginatedBodyItems = useMemo((): MappingTableBodyItem[] => {
    if (!confidenceGroupingActive) {
      const start = safePage * rowsPerPage;
      return mappingTableBodyItems.slice(start, start + rowsPerPage);
    }

    const start = safePage * rowsPerPage;
    const end = start + rowsPerPage;
    const pageItems: MappingTableBodyItem[] = [];
    let rowIndex = 0;
    let pendingHeader: MappingTableBodyItem | null = null;

    for (const item of mappingTableBodyItems) {
      if (item.kind === 'header') {
        const isExpanded = expandedConfidenceGroups[item.groupId] !== false;
        if (!isExpanded) {
          // Collapsed groups still show their header in the correct order without using a row slot.
          const isOnPage =
            (rowIndex >= start && rowIndex < end)
            || (
              rowIndex === end
              && end === expandableRowsForDisplay.length
              && end > start
              && safePage === maxPage
            );
          if (isOnPage) {
            pageItems.push(item);
          }
          pendingHeader = null;
          continue;
        }
        pendingHeader = item;
        continue;
      }

      if (rowIndex >= start && rowIndex < end) {
        if (pendingHeader) {
          pageItems.push(pendingHeader);
          pendingHeader = null;
        }
        pageItems.push(item);
      } else {
        pendingHeader = null;
      }
      rowIndex += 1;
    }

    return pageItems;
  }, [
    confidenceGroupingActive,
    mappingTableBodyItems,
    safePage,
    rowsPerPage,
    expandedConfidenceGroups,
    expandableRowsForDisplay.length,
    maxPage,
  ]);

  const paginatedMappings = useMemo(
    () =>
      paginatedBodyItems
        .filter((item): item is Extract<MappingTableBodyItem, { kind: 'row' }> => item.kind === 'row')
        .map((item) => item.row),
    [paginatedBodyItems],
  );

  useEffect(() => {
    if (!activeProjectId || !activeSttmId || !paginatedMappings.length) {
      return;
    }
    const controller = new AbortController();
    void recommendationService.listApplicable({
      projectId: activeProjectId,
      sttmId: activeSttmId,
      workflowStage: 'mapping',
      targetColumns: paginatedMappings.map((row) => row.targetColumn),
      limit: Math.min(200, paginatedMappings.length * 3),
      signal: controller.signal,
    }).then(setApplicableRecommendations).catch((error: unknown) => {
      if (!(error instanceof DOMException && error.name === 'AbortError')) {
        setApplicableRecommendations([]);
      }
    });
    return () => controller.abort();
  }, [activeProjectId, activeSttmId, paginatedMappings]);

  const firCandidatesByTarget = useMemo(() => {
    const result = new Map<string, FIRMappingCandidate[]>();
    if (!activeProjectId || !activeSttmId) return result;
    for (const recommendation of applicableRecommendations) {
      const target = String(
        recommendation.target_entity.target_column
        ?? recommendation.target_entity.column
        ?? '',
      ).toUpperCase();
      if (!target) continue;
      const payload = recommendation.action_payload;
      const rawSources = payload.source_columns
        ?? payload.candidate_source_columns
        ?? (payload.source_column
          ? [payload.source_column]
          : recommendation.candidate_sources);
      const sources = Array.isArray(rawSources) ? rawSources : [rawSources];
      const sourceColumn = sources
        .map((item) => (
          typeof item === 'string'
            ? item
            : item && typeof item === 'object'
              ? String(
                  (item as Record<string, unknown>).source_column
                  ?? (item as Record<string, unknown>).column
                  ?? (item as Record<string, unknown>).fqn
                  ?? '',
                )
              : ''
        ))
        .find(Boolean);
      const candidate: FIRMappingCandidate = {
        recommendationId: recommendation.recommendation_id,
        sourceColumn: sourceColumn ?? null,
        title: recommendation.title,
        businessRationale: recommendation.business_rationale,
        evidenceSummary: recommendation.evidence_summary,
        confidence: recommendation.confidence,
        compatibilityTier: recommendation.compatibility_tier,
        missingDependencies: recommendation.missing_dependencies,
        canApply: recommendation.can_apply,
        blockedReasons: recommendation.blocked_reasons,
        actionKind: recommendation.action_kind,
        expectedWorkspaceHash: recommendation.expected_workspace_hash,
      };
      result.set(target, [...(result.get(target) ?? []), candidate].slice(0, 3));
    }
    return result;
  }, [activeProjectId, activeSttmId, applicableRecommendations]);

  const updateColumnFilter = (key: keyof MappingColumnFilters, value: string) => {
    setPage(0);
    setColumnFilters((current) => ({
      ...current,
      [key]: value,
    }));
  };

  return (
    <AiaBox
      sx={{
        width: '100%',
        flex: 1,
        minHeight: 0,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {(selectedMappingIds.length > 0 || canUndo) && (
      <AiaBox data-tour={TOUR_TARGETS.sttmRowSelectionBar} sx={MAPPING_SELECTION_BAR_SX}>
        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1.25, minWidth: 0 }}>
          {selectedMappingIds.length > 0 ? (
            <>
              <AiaText sx={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', whiteSpace: 'nowrap' }}>
                {selectedMappingIds.length} row{selectedMappingIds.length === 1 ? '' : 's'} selected
              </AiaText>
              <AiaText
                sx={{ fontSize: '0.78rem', fontWeight: 500, color: '#64748b', whiteSpace: 'nowrap' }}
              >
                ({selectedMappedCount} mapped)
              </AiaText>
            </>
          ) : null}
        </AiaBox>

        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
          <AiaButton
            variant="outlined"
            size="small"
            disabled={!canUndo}
            startIcon={<UndoRoundedIcon sx={{ fontSize: 16 }} />}
            onClick={undoLastChange}
            sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
          >
            Undo{undoCount > 0 ? ` (${undoCount})` : ''}
          </AiaButton>
          {selectedMappingIds.length > 0 ? (
            <>
            <AiaButton
              data-tour={TOUR_TARGETS.sttmMarkMapped}
              variant="outlined"
              size="small"
              startIcon={<CheckRoundedIcon sx={{ fontSize: 16 }} />}
              onClick={() => bulkMarkMapped(selectedMappingIds)}
              sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
            >
              Mark Mapped
            </AiaButton>
            <AiaButton
              data-tour={TOUR_TARGETS.sttmSetDirect}
              variant="outlined"
              size="small"
              startIcon={<ArrowForwardRoundedIcon sx={{ fontSize: 16 }} />}
              onClick={() => bulkSetDirect(selectedMappingIds)}
              sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
            >
              Set Direct
            </AiaButton>
            <AiaButton
              data-tour={TOUR_TARGETS.sttmPublishRowMapping}
              size="small"
              startIcon={<FileUploadOutlinedIcon sx={{ fontSize: 16 }} />}
              sx={{
                color: 'var(--aia-primary-bg-text-color)',
                bgcolor: 'var(--aia-primary-bg-color)',
                textTransform: 'none',
                fontSize: '0.78rem',
                fontWeight: 700,
                px: 1.5,
                ml: 0.5,
                borderRadius: '8px',
                boxShadow: 'none',
                '&:hover': {
                  bgcolor: 'var(--aia-primary-bg-hover-color)',
                  boxShadow: 'none',
                },
              }}
            >
              Publish {selectedMappingIds.length} Mapping{selectedMappingIds.length === 1 ? '' : 's'}
            </AiaButton>
            <AiaIconButton
              size="small"
              onClick={clearSelection}
              sx={{ color: '#64748b', ml: 0.25, '&:hover': { color: '#0f172a', bgcolor: 'rgba(15, 23, 42, 0.06)' } }}
            >
              <CloseRoundedIcon sx={{ fontSize: 18 }} />
            </AiaIconButton>
            </>
          ) : null}
        </AiaBox>
      </AiaBox>
      )}

      <AiaTableContainer
        component={AiaPaper}
        elevation={0}
        data-tour={TOUR_TARGETS.sttmMappingGrid}
        sx={MAPPING_TABLE_CONTAINER_SX}
      >
          <AiaTablePrimitive
            stickyHeader
            size="small"
            sx={mappingTableSx(tableMinWidth)}
          >
          <colgroup>
            {visibleColumnKeys.map((key) => (
              <col key={key} style={{ width: columnWidths[key] }} />
            ))}
          </colgroup>
          <AiaTableHead>
            <AiaTableRowPrimitive>
              <MappingResizableHeaderCell
                padding="none"
                width={columnWidths.checkbox}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.checkbox}
                resizeKey="checkbox"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...mappingFrozenCellSx(FROZEN_CHECKBOX_LEFT, { header: true }),
                  px: 0,
                  textAlign: 'center',
                  verticalAlign: 'middle',
                }}
              >
                <AiaBox
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '100%',
                    minHeight: MAPPING_TABLE_HEADER_ROW_HEIGHT,
                  }}
                >
                  <AiaCheckbox
                    checked={allSelected}
                    indeterminate={someSelected}
                    checkHandler={(checked: boolean) =>
                      selectAllMappings(
                        mappings.map((row) => row.id),
                        checked,
                      )
                    }
                    sx={MAPPING_TABLE_CHECKBOX_SX}
                  />
                </AiaBox>
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmTargetColumn}
                width={columnWidths.targetColumn}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.targetColumn}
                resizeKey="targetColumn"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...mappingFrozenCellSx(frozenTargetColumnLeft, {
                    header: true,
                    lastFrozen: true,
                  }),
                }}
              >
                <MappingHeaderSearchLabel
                  title="Target Column"
                  value={columnFilters.targetColumn}
                  onChange={(value) => updateColumnFilter('targetColumn', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.preProcessRule}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.preProcessRule}
                resizeKey="preProcessRule"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Transform Rule"
                  value={columnFilters.preProcessRule}
                  mode="select"
                  options={MAPPING_TYPE_FILTER_OPTIONS}
                  placeholder="All"
                  onChange={(value) => updateColumnFilter('preProcessRule', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.sourceColumn}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.sourceColumn}
                resizeKey="sourceColumn"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Source Column"
                  value={columnFilters.sourceColumn}
                  onChange={(value) => updateColumnFilter('sourceColumn', value)}
                />
              </MappingResizableHeaderCell>
              {showConfidenceColumn ? (
                <MappingResizableHeaderCell
                  width={columnWidths.confidence}
                  minWidth={MAPPING_COLUMN_MIN_WIDTH.confidence}
                  resizeKey="confidence"
                  onResizeStart={onResizeStart}
                  sx={{
                    ...headerCellSx,
                    ...scrollableHeaderCellSx,
                  }}
                >
                  Confidence
                </MappingResizableHeaderCell>
              ) : null}
              <MappingResizableHeaderCell
                width={columnWidths.typePreview}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.typePreview}
                resizeKey="typePreview"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                  whiteSpace: 'nowrap',
                }}
              >
                <MappingHeaderSearchLabel
                  title="Type (Preview)"
                  value={columnFilters.typePreview}
                  onChange={(value) => updateColumnFilter('typePreview', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.nlRule}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.nlRule}
                resizeKey="nlRule"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="NL Rule"
                  value={columnFilters.nlRule}
                  onChange={(value) => updateColumnFilter('nlRule', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.order}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.order}
                resizeKey="order"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Order"
                  value={columnFilters.order}
                  onChange={(value) => updateColumnFilter('order', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmDescriptionAi}
                width={columnWidths.description}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.description}
                resizeKey="description"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title={(
                    <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 0.75, minWidth: 0 }}>
                      <AiaText
                        component="span"
                        sx={{
                          fontSize: 'inherit',
                          fontWeight: 'inherit',
                          color: 'inherit',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        Description
                      </AiaText>
                      <AiaChip label="AI" size="small" color="primary" sx={{ height: 18, fontSize: '0.6rem', fontWeight: 800 }} />
                    </AiaBox>
                  )}
                  value={columnFilters.description}
                  onChange={(value) => updateColumnFilter('description', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmMappedStatus}
                width={columnWidths.status}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.status}
                resizeKey="status"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Status"
                  value={columnFilters.status}
                  mode="select"
                  options={STATUS_FILTER_OPTIONS}
                  placeholder="All"
                  onChange={(value) => updateColumnFilter('status', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.dataPreview}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.dataPreview}
                resizeKey="dataPreview"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                  whiteSpace: 'nowrap',
                }}
              >
                Data Preview
              </MappingResizableHeaderCell>
            </AiaTableRowPrimitive>
          </AiaTableHead>
          <AiaTableBody>
            {paginatedBodyItems.map((item) => {
              if (item.kind === 'header') {
                return (
                  <MappingConfidenceGroupHeaderRow
                    key={`confidence-group-${item.groupId}`}
                    groupId={item.groupId}
                    rowCount={confidenceGroupCounts[item.groupId]}
                    colSpan={visibleColumnKeys.length}
                    expanded={expandedConfidenceGroups[item.groupId] !== false}
                    onToggle={() => toggleConfidenceGroup(item.groupId)}
                  />
                );
              }

              const row = item.row;
              const isSelected = selectedMappingIds.includes(row.id);
              const isProcessing =
                autoMapProcessingIds.includes(row.id) || row.status === 'PROCESSING';
              const previewType = row.sourceType ?? row.targetType ?? undefined;
              const sourceColumns =
                row.sourceColumns && row.sourceColumns.length
                  ? row.sourceColumns
                  : parseSourceColumns(row.sourceColumn);
              const resolvedRule = resolveMappingRuleSelectValue(row.rule);
              const descriptionValue = resolveMappingDescription(row, sourceColumns, resolvedRule);
              const descriptionPlaceholder = 'Add description...';
              return (
                <AiaTableRowPrimitive
                  key={row.id}
                  sx={MAPPING_TABLE_ROW_SX}
                >
                  <AiaCheckboxCell
                    checked={isSelected}
                    onChange={() => toggleMappingSelection(row.id)}
                    width={columnWidths.checkbox}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.checkbox}
                    checkboxSx={MAPPING_TABLE_CHECKBOX_SX}
                    sx={{
                      ...mappingFrozenCellSx(FROZEN_CHECKBOX_LEFT),
                      ...mappingColumnDividerSx,
                    }}
                  />

                  <MappingTargetColumnCell
                    name={row.targetColumn}
                    isMapped={row.status === 'MAPPED'}
                    isProcessing={isProcessing}
                    width={columnWidths.targetColumn}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.targetColumn}
                    sx={{
                      ...mappingFrozenCellSx(frozenTargetColumnLeft, {
                        lastFrozen: true,
                      }),
                      ...mappingColumnDividerSx,
                    }}
                  />

                  <MappingRuleCell
                    value={resolveMappingTypeSelectValue(row)}
                    options={MAPPING_TYPE_OPTIONS}
                    placeholder="Select transform rule..."
                    width={columnWidths.preProcessRule}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.preProcessRule}
                    onRuleChange={(value) => {
                      const nextType = value || MAPPING_TYPE_DIRECT;
                      if (nextType === resolveMappingTypeSelectValue(row)) {
                        return;
                      }
                      confirmIfMappedRowChange(
                        row,
                        MAPPED_ROW_CHANGE_MESSAGES.transformRule,
                        () => handleMappingTypeChange(row.id, nextType),
                      );
                    }}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingSourceColumnsCell
                    mappingType={
                      resolveMappingTypeSelectValue(row) as 'direct' | 'attribute' | 'custom'
                    }
                    value={row.sourceColumn}
                    sourceColumns={row.sourceColumns}
                    options={sourceColumnOptions}
                    attributeName={row.attributeName}
                    attributeOptions={attributeOptions}
                    isLoadingAttributeOptions={isLoadingProjectAttributes}
                    onAttributeMenuOpen={() => {
                      void reloadProjectAttributes();
                    }}
                    onPreProcess={() => {
                      confirmIfMappedRowChange(
                        row,
                        MAPPED_ROW_CHANGE_MESSAGES.preProcess,
                        () => setPreProcessModalOpen(true, row.id),
                      );
                    }}
                    onDirectSourcePick={() => setDirectPickerMappingId(row.id)}
                    onAttributeChange={(nextAttributeName) => {
                      if ((row.attributeName ?? '') === (nextAttributeName ?? '')) {
                        return;
                      }
                      const applyAttributeChange = () => {
                      const selectedAttribute = projectAttributesForActiveProject.find(
                        (attribute) => attribute.attribute_name === nextAttributeName,
                      );
                      updateMappingWithUndo(row.id, {
                        mappingMode: "attribute",
                        attributeName: nextAttributeName || null,
                        constantValue: selectedAttribute?.attribute_value ?? null,
                        sourceColumn: null,
                        sourceColumns: [],
                        sourceType: selectedAttribute?.attribute_type ?? null,
                        expression: null,
                        rule: "Direct",
                        status: nextAttributeName.trim() ? "MAPPED" : "UNMAPPED",
                        confidenceScore: null,
                        confidenceReason: nextAttributeName.trim()
                          ? "A firm value was assigned manually."
                          : null,
                        usedInferenceIds: [],
                        usedRecommendationIds: [],
                        usedLearningIds: [],
                        description: row.descriptionEdited
                          ? row.description
                          : nextAttributeName.trim()
                            ? `Assign the firm value ${nextAttributeName.trim()} to ${row.targetColumn}.`
                            : null,
                      });
                      };
                      confirmIfMappedRowChange(
                        row,
                        MAPPED_ROW_CHANGE_MESSAGES.projectAttribute,
                        applyAttributeChange,
                      );
                    }}
                    onChange={(nextValue) => {
                      if ((row.sourceColumn ?? '').trim() === nextValue.trim()) {
                        return;
                      }
                      const applySourceChange = () => {
                      const nextColumns = parseSourceColumns(nextValue);
                      const rule = resolveMappingRuleSelectValue(row.rule);
                      const updates: Partial<typeof row> = {
                        sourceColumn: nextValue.trim() || null,
                        sourceColumns: nextColumns,
                        mappingMode: "source",
                        constantValue: null,
                        attributeName: null,
                        status: nextColumns.length > 0 ? 'MAPPED' : 'UNMAPPED',
                        confidenceScore: null,
                        confidenceReason: nextColumns.length
                          ? 'Source columns were edited manually after the AI suggestion.'
                          : null,
                        usedInferenceIds: [],
                        usedRecommendationIds: [],
                        usedLearningIds: [],
                        sourceType:
                          sourceColumnOptions.find(
                            (option) => option.value.toLowerCase() === nextColumns[0]?.toLowerCase(),
                          )?.dataType ?? row.sourceType ?? null,
                      };

                      if (!row.descriptionEdited && rule) {
                        updates.description =
                          generateMappingDescription({
                            rule,
                            sourceColumns: nextColumns,
                            targetColumn: row.targetColumn,
                            expression: row.expression,
                          }) || null;
                      }

                      updateMappingWithUndo(row.id, updates);
                      };
                      confirmIfMappedRowChange(
                        row,
                        MAPPED_ROW_CHANGE_MESSAGES.sourceColumn,
                        applySourceChange,
                      );
                    }}
                    firCandidates={firCandidatesByTarget.get(row.targetColumn.toUpperCase()) ?? []}
                    onApplyFirCandidate={(candidate) => {
                      if (!candidate.sourceColumn) return;
                      const applyRecommendation = () => {
                      void (async () => {
                        try {
                          await flushWorkspace();
                          const refreshed = await recommendationService.listApplicable({
                            projectId: activeProjectId || '',
                            sttmId: activeSttmId || '',
                            workflowStage: 'mapping',
                            targetColumns: [row.targetColumn],
                            limit: 3,
                          });
                          const currentRecommendation = refreshed.find(
                            (item) => item.recommendation_id === candidate.recommendationId,
                          );
                          const expectedWorkspaceHash =
                            currentRecommendation?.expected_workspace_hash
                            || candidate.expectedWorkspaceHash
                            || '';
                          if (!expectedWorkspaceHash) {
                            throw new Error('The current workspace hash is unavailable. Refresh the mapping and try again.');
                          }
                          const workspaceSnapshot = {
                            ...getWorkspaceSnapshot(),
                            context_hash: expectedWorkspaceHash,
                          };
                          const preview = await recommendationService.preview(
                            candidate.recommendationId,
                            {
                              sttm_id: activeSttmId || '',
                              workspace_snapshot: workspaceSnapshot,
                              expected_workspace_hash: expectedWorkspaceHash,
                            },
                          );
                          if (!preview.can_apply) {
                            throw new Error(preview.blocked_reasons.join(' '));
                          }
                          setRecommendationUndoByRow((current) => ({
                            ...current,
                            [row.id]: {
                              sourceColumn: row.sourceColumn,
                              sourceColumns: row.sourceColumns ?? [],
                              status: row.status,
                              confidenceScore: row.confidenceScore ?? null,
                              confidenceReason: row.confidenceReason ?? null,
                              usedRecommendationIds: row.usedRecommendationIds ?? [],
                            },
                          }));
                          const nextColumns = parseSourceColumns(candidate.sourceColumn!);
                          updateMappingWithUndo(row.id, {
                            sourceColumn: candidate.sourceColumn,
                            sourceColumns: nextColumns,
                            mappingMode: "source",
                            constantValue: null,
                            status: nextColumns.length ? "MAPPED" : "UNMAPPED",
                            confidenceScore: candidate.confidence ?? null,
                            confidenceReason:
                              candidate.businessRationale
                              || candidate.evidenceSummary
                              || candidate.title,
                            usedRecommendationIds: Array.from(new Set([
                              ...(row.usedRecommendationIds ?? []),
                              candidate.recommendationId,
                            ])),
                          });
                          setRecommendationActionErrors((current) => {
                            const next = { ...current };
                            delete next[row.id];
                            return next;
                          });
                        } catch (error) {
                          setRecommendationActionErrors((current) => ({
                            ...current,
                            [row.id]: error instanceof Error
                              ? error.message
                              : 'The recommendation could not be previewed against the current workspace.',
                          }));
                        }
                      })();
                      };
                      confirmIfMappedRowChange(
                        row,
                        MAPPED_ROW_CHANGE_MESSAGES.recommendation,
                        applyRecommendation,
                      );
                    }}
                    onPrepareSource={(candidate) => {
                      window.dispatchEvent(new CustomEvent('sttm:prepare-source', {
                        detail: {
                          targetColumn: row.targetColumn,
                          recommendationId: candidate.recommendationId,
                          missingDependencies: candidate.missingDependencies,
                        },
                      }));
                    }}
                    onKeepUnresolved={() => undefined}
                    recommendationUndoAvailable={Boolean(recommendationUndoByRow[row.id])}
                    recommendationActionError={recommendationActionErrors[row.id] ?? null}
                    onUndoRecommendation={() => {
                      const previous = recommendationUndoByRow[row.id];
                      if (!previous) return;
                      updateMapping(row.id, previous);
                      setRecommendationUndoByRow((current) => {
                        const next = { ...current };
                        delete next[row.id];
                        return next;
                      });
                    }}
                    width={columnWidths.sourceColumn}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.sourceColumn}
                    confidenceReason={row.confidenceReason}
                    businessMeaning={row.description ?? row.nlRule ?? null}
                    candidateSourceColumns={row.candidateSourceColumns}
                    sx={scrollableBodyCellSx}
                  />

                  {showConfidenceColumn ? (
                    <MappingConfidenceCell
                      confidenceScore={row.confidenceScore}
                      status={row.status}
                      reason={row.confidenceReason}
                      businessMeaning={row.description ?? row.nlRule ?? null}
                      width={columnWidths.confidence}
                      minWidth={MAPPING_COLUMN_MIN_WIDTH.confidence}
                      sx={scrollableBodyCellSx}
                    />
                  ) : null}

                  <MappingTypePreviewCell
                    dataType={previewType}
                    width={columnWidths.typePreview}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.typePreview}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingExpandableTextCell
                    placeholder="Add NL rule..."
                    value={row.nlRule ?? ''}
                    onChange={(value) => updateMappingWithUndo(row.id, { nlRule: value })}
                    width={columnWidths.nlRule}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.nlRule}
                    inputSx={multilineCellInputSx}
                    sx={scrollableBodyCellSx}
                  />

                  <AiaInputCell
                    placeholder="Order..."
                    value={row.loadOrder ?? ''}
                    onChange={(value) => updateMappingWithUndo(row.id, { loadOrder: value })}
                    width={columnWidths.order}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.order}
                    inputSx={mappingBodyInputSx}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingExpandableTextCell
                    placeholder={descriptionPlaceholder}
                    value={descriptionValue}
                    onChange={(value) =>
                      updateMappingWithUndo(row.id, {
                        description: value,
                        descriptionEdited: value.trim().length > 0,
                      })
                    }
                    width={columnWidths.description}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.description}
                    inputSx={multilineCellInputSx}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingStatusCell
                    status={isProcessing ? 'PROCESSING' : row.status}
                    align="left"
                    width={columnWidths.status}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.status}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingDataPreviewCell
                    mapping={row}
                    width={columnWidths.dataPreview}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.dataPreview}
                    sx={scrollableBodyCellSx}
                  />
                </AiaTableRowPrimitive>
              );
            })}
            {!paginatedBodyItems.length ? (
              <AiaTableRowPrimitive>
                <AiaTableCellPrimitive colSpan={visibleColumnKeys.length} sx={{ py: 4, textAlign: 'center' }}>
                  <AiaText sx={{ fontSize: '0.82rem', color: '#64748b' }}>
                    No mapping rows match the current column filters.
                  </AiaText>
                </AiaTableCellPrimitive>
              </AiaTableRowPrimitive>
            ) : null}
          </AiaTableBody>
        </AiaTablePrimitive>
      </AiaTableContainer>

      <AiaTablePagination
        component="div"
        count={expandableRowsForDisplay.length}
        page={safePage}
        onPageChange={(_, nextPage) => setPage(nextPage)}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={(event) => {
          setRowsPerPage(Number.parseInt(event.target.value, 10));
          setPage(0);
        }}
        rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
        sx={MAPPING_TABLE_PAGINATION_SX}
      />

      {mappingLoading && (
        <AiaBox
          sx={{
            position: 'absolute',
            top: 12,
            right: 16,
            maxWidth: 320,
            px: 1.5,
            py: 1,
            bgcolor: 'rgba(15,23,42,0.92)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            gap: 1,
            zIndex: 5,
            borderRadius: '12px',
            boxShadow: '0 12px 28px rgba(15,23,42,0.18)',
            pointerEvents: 'none',
          }}
        >
          <AiaBox
            sx={{
              width: 18,
              height: 18,
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '999px',
              bgcolor: 'rgba(37,99,235,0.16)',
              flexShrink: 0,
            }}
          >
            <AiaBox
              component="span"
              sx={{
                width: 10,
                height: 10,
                borderRadius: '999px',
                border: '2px solid #93c5fd',
                borderTopColor: '#eff6ff',
                display: 'inline-block',
                animation: 'sttm-auto-map-spin 0.9s linear infinite',
                '@keyframes sttm-auto-map-spin': {
                  from: { transform: 'rotate(0deg)' },
                  to: { transform: 'rotate(360deg)' },
                },
              }}
            />
          </AiaBox>
          <AiaText sx={{ fontSize: '0.8rem', color: '#e2e8f0', fontWeight: 600 }}>
            {autoMapStatusMessage || 'Running auto-map...'}
          </AiaText>
        </AiaBox>
      )}

      <DirectSourcePickerModal
        open={Boolean(directPickerMapping)}
        onClose={() => setDirectPickerMappingId(null)}
        targetColumn={directPickerMapping?.targetColumn ?? ''}
        targetType={directPickerMapping?.targetType}
        initialSourceColumn={directPickerMapping?.sourceColumn}
        sourceDatabases={fullData?.sources ?? []}
        sourceAttributeGroups={sourceAttributeGroups}
        derivedSources={derivedSources}
        onApply={({ sourceColumn, sourceType }) => {
          if (!directPickerMapping) return;
          const applyDirectPick = () => {
            const nextColumns = parseSourceColumns(sourceColumn);
            updateMappingWithUndo(directPickerMapping.id, {
              sourceColumn: sourceColumn.trim() || null,
              sourceColumns: nextColumns,
              mappingMode: 'source',
              constantValue: null,
              attributeName: null,
              expression: null,
              rule: 'Direct',
              status: nextColumns.length > 0 ? 'MAPPED' : 'UNMAPPED',
              confidenceScore: null,
              confidenceReason: nextColumns.length
                ? 'Source column was selected via Direct pick.'
                : null,
              usedInferenceIds: [],
              usedRecommendationIds: [],
              usedLearningIds: [],
              sourceType: sourceType ?? directPickerMapping.sourceType ?? null,
              description: directPickerMapping.descriptionEdited
                ? directPickerMapping.description
                : generateMappingDescription({
                    rule: 'Direct',
                    sourceColumns: nextColumns,
                    targetColumn: directPickerMapping.targetColumn,
                    expression: null,
                  }) || null,
            });
            setDirectPickerMappingId(null);
          };

          const currentSource = (directPickerMapping.sourceColumn ?? '').trim();
          const nextSource = sourceColumn.trim();
          if (currentSource === nextSource) {
            applyDirectPick();
            return;
          }

          confirmIfMappedRowChange(
            directPickerMapping,
            MAPPED_ROW_CHANGE_MESSAGES.directPick,
            applyDirectPick,
          );
        }}
      />

      <MappingChangeConfirmDialog
        open={Boolean(pendingMappedRowChange)}
        targetColumn={pendingMappedRowChange?.targetColumn ?? ''}
        actionDescription={pendingMappedRowChange?.actionDescription ?? ''}
        onClose={closeMappedRowChangeConfirm}
        onConfirm={confirmMappedRowChange}
      />
    </AiaBox>
  );
};

export default SourceTargetAttributeMapping;
