'use client';

import { useEffect, useId, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { AiaBox, AiaButton, AiaCollapse, AiaTooltip, AiaMenu, AiaMenuItem } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useSttmBuilderContext } from '../context/sttm-builder-context';
import type { MappingState } from '../types/sttm.types';
import type { AutoMapCandidate, AutoMapSuggestion } from '@/types/api-contract';
import { MAPPING_TABLE_BODY_TEXT_SX } from './mapping-table-styles';
import { joinOnPredicate } from '../source-target/join-predicate';
import { candidateConfidence, candidatePolicyCompatible } from './sheet-candidates';
import { recoverableAiUndo }  from '../shared/row-validation-state';
import { alternativeCandidates, currentCandidate, previousMappingCandidate, relevantWarnings, guidanceForRow, businessReviewText, reviewCatalog, type ReviewCatalog } from './mapping-review-model';


const MONO = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';
const textSx = {...MAPPING_TABLE_BODY_TEXT_SX, overflowWrap: 'anywhere' as const};
function Exact({text, catalog}: {text: string; catalog: ReviewCatalog}) {
  return <AiaTooltip title={catalog.reference(text)?.title || text} arrow><AiaBox component="code" sx={{fontFamily: MONO, overflowWrap:'anywhere', whiteSpace:'pre-wrap'}}>{catalog.display(text)}</AiaBox></AiaTooltip>;
}
function ReviewText({text,catalog}:{text:string;catalog:ReviewCatalog}) {
  const friendly=catalog.display(text);
  return <>{friendly.split(/(`[^`]+`|\$[A-Za-z_][\w$]*|\b\d+(?:\.\d+)?%|(?:"[^"]+"|[A-Z_][A-Z0-9_$]*)(?:\s+\([^)]*\))?(?:\.(?:"[^"]+"|[A-Z_][A-Z0-9_$]*))+)/g).map((part,index)=> /^\d+(?:\.\d+)?%$/.test(part)
    ? <strong key={index}>{part}</strong> : /^`[^`]+`$|^\$[A-Za-z_][\w$]*$|^(?:"[^"]+"|[A-Z_][A-Z0-9_$]*)(?:\s+\([^)]*\))?(?:\.(?:"[^"]+"|[A-Z_][A-Z0-9_$]*))+$/.test(part)
      ? <AiaBox key={index} component="code" sx={{fontFamily:MONO}}>{part.replace(/^`|`$/g,'')}</AiaBox> : part)}</>;
}
function dependencyJoinText(join: Record<string, unknown>): string {
  const relation = (value: unknown): string => typeof value === 'string' ? value : value && typeof value === 'object'
    ? ['database','schema','table'].map(key=>String((value as Record<string, unknown>)[key]??'')).filter(Boolean).join('.') : '';
  const left=relation(join.left_table??join.left_relation_id),right=relation(join.right_table??join.right_relation_id);
  const predicate=join.sql_predicate??join.predicate??join.condition??join.additional_predicate;
  const conditions=Array.isArray(join.conditions)?joinOnPredicate(join.conditions.map(value=>{const row=value as Record<string, unknown>;return {sql:`${row.left_column??''} ${row.operator??'='} ${row.right_column??''}`,connector:row.connector};}), ' '):'';
  return `${left?left+' ':''}${String(join.join_type??'').trim()} JOIN ${right||'required relation'} ON ${typeof predicate==='string'?predicate:conditions||'Review the stored relationship condition'}`;
}
function Bullets({items,catalog}:{items:string[];catalog:ReviewCatalog}) {
  const unique=Array.from(new Set(items.map(item=>item.trim()).filter(Boolean)));
  if(!unique.length)return null;
  return <AiaBox component="ul" sx={{m:0,pl:2}}>{unique.map((text,index)=><AiaBox component="li" key={index} sx={textSx}><ReviewText text={text} catalog={catalog}/></AiaBox>)}</AiaBox>;
}
function Details({option,catalog,selected=false}:{option:AutoMapCandidate;catalog:ReviewCatalog;selected?:boolean}) {
  const reasons=(businessReviewText(option.confidence_reason)||businessReviewText(option.preprocessing_nl_rule)).split(/\r?\n|(?<=[.!?])\s+(?=[A-Z])/).filter(Boolean);
  const limitations=Array.from(new Set((option.warnings??[]).map(businessReviewText).filter(Boolean)));
  return <AiaBox sx={{display:'grid',gap:.5,minWidth:0}}>
    <AiaText sx={textSx}><strong>{option.mapping_mode==='attribute'||option.mapping_mode==='constant'?'Value:':'Source:'}</strong>{' '}
      {option.mapping_mode==='attribute'?<Exact text={`$${option.attribute_name||''}`} catalog={catalog}/>:option.mapping_mode==='constant'?<AiaBox component="code" sx={{fontFamily:MONO}}>{option.constant_value??'Unavailable'}</AiaBox>
        :option.source_attributes.map((ref,index)=><span key={index}>{index?', ':''}<Exact text={ref} catalog={catalog}/></span>)}</AiaText>
    <AiaText sx={textSx}><strong>Mapping:</strong> {option.origin==='manual'?'Manual mapping · ':''}{option.mapping_mode==='attribute'?'Firm Value':option.mapping_mode==='constant'?'Constant':option.preprocessing_rule_type||'Direct'}</AiaText>
    {!selected?<AiaText sx={textSx}><strong>Estimated mapping confidence: {candidateConfidence(option)==null?'not available':`${Math.round(candidateConfidence(option)!*100)}%`}</strong></AiaText>:null}
    {option.preprocessing_rule?<AiaText sx={textSx}><strong>Transformation:</strong>{' '}<Exact text={option.preprocessing_rule} catalog={catalog}/></AiaText>:null}
    <AiaText sx={textSx}><strong>Why suggested</strong></AiaText>
    {reasons.length?<Bullets items={reasons.slice(0,3)} catalog={catalog}/>:<AiaText sx={textSx}>{option.origin==='manual'?'Original manually authored definition; no AI explanation was recorded.':'No explanation was supplied.'}</AiaText>}
    {limitations.length?<><AiaText sx={textSx}><strong>Considerations</strong></AiaText><Bullets items={limitations} catalog={catalog}/></>:null}
    {option.source_dependencies?.length?<AiaText sx={textSx}><strong>Dependencies:</strong>{' '}{option.source_dependencies.map((ref,index)=><span key={index}>{index?', ':''}<Exact text={ref} catalog={catalog}/></span>)}</AiaText>:null}
  </AiaBox>;
}

/** All review controls belong beneath the selected source, within that cell. */
export function MappingRowCandidates({row}:{row:MappingState}) {
  const context=useSttmBuilderContext();
  const {selectSheetCandidate,undoSheetSuggestion,mappingLoading,sources,derivedSources}=context;
  const search=useSearchParams();const id=useId();
  const [section,setSection]=useState<'candidates'|'suggestions'|null>(null);
  const [actionAnchor,setActionAnchor]=useState<HTMLElement|null>(null);
  const [currentOpen,setCurrentOpen]=useState(false);const [busy,setBusy]=useState(false);const [error,setError]=useState<string|null>(null);
  const catalog=useMemo(()=>reviewCatalog(sources,derivedSources),[sources,derivedSources]);
  const alternatives=alternativeCandidates(row,catalog);const current=currentCandidate(row,catalog);const manualCurrent=!current&&row.status==='MAPPED'?previousMappingCandidate(row):null;const suggestions=guidanceForRow(row).filter(item=>relevantWarnings(row,[item.message],context.mappings.map(item=>item.targetColumn)).length);
  useEffect(()=>{
    const focus=(event?:Event)=>{const detail=(event as CustomEvent)?.detail;const mappingId=detail?.mappingId??search.get('reviewRow');
      if(mappingId===row.id)setSection((detail?.section??search.get('reviewSection'))==='suggestions'?'suggestions':'candidates');};
    focus();window.addEventListener('sttm:review-row',focus);return()=>window.removeEventListener('sttm:review-row',focus);
  },[row.id,search]);
  if(!row.aiCandidates?.length&&!suggestions.length&&!row.aiReviewStatus&&!row.confidenceReason&&!row.nlRule)return null;
  const disabled=busy||mappingLoading;
  const clean=(option:AutoMapCandidate)=>({...option,warnings:[]});
  const act=async(candidateId:string,confirm=false,validateOnly=false)=>{setBusy(true);setError(null);
    try{await selectSheetCandidate(row.id,candidateId,confirm,validateOnly);}catch(cause){setError(cause&&typeof cause==='object'&&'message'in cause?String(cause.message):'Unable to validate this mapping.');}finally{setBusy(false);}};
  const joinReview=(suggestion:AutoMapSuggestion)=>{
    window.sessionStorage.setItem('sttm:focused-join-recommendation',suggestion.suggestion_id);
    window.dispatchEvent(new CustomEvent('sttm:open-join-recommendation',{detail:{suggestionId:suggestion.suggestion_id}}));
  };
  const reason=[current?.confidence_reason,current?.preprocessing_nl_rule,row.confidenceReason,row.nlRule].map(businessReviewText).find(Boolean);

  return <AiaBox id={`review-${row.id}`} sx={{...textSx,width:'100%',minWidth:0,mt:.5,display:'grid',gap:.5}}>
    <AiaBox sx={{display:'flex',gap:.5,flexWrap:'wrap'}}>
      {reason?<AiaButton size="small" variant="text" onClick={()=>setCurrentOpen(!currentOpen)} aria-expanded={currentOpen} sx={{fontFamily:'inherit',textTransform:'none',p:.25,color:'#2563eb'}}>Reasoning</AiaButton>:null}
      {alternatives.length?<AiaButton size="small" variant="text" aria-expanded={section==='candidates'} aria-controls={`${id}-candidates`} onClick={()=>setSection(section==='candidates'?null:'candidates')} sx={{fontFamily:'inherit',textTransform:'none',p:.25,color:'#2563eb'}}>View candidates ({alternatives.length})</AiaButton>:null}
      {suggestions.length?<AiaButton size="small" variant="text" aria-expanded={section==='suggestions'} aria-controls={`${id}-suggestions`} onClick={()=>setSection(section==='suggestions'?null:'suggestions')} sx={{fontFamily:'inherit',textTransform:'none',p:.25,color:'#2563eb'}}>Suggestions ({suggestions.length})</AiaButton>:null}

      {recoverableAiUndo(row)?<AiaButton size="small" variant="text" onClick={event=>setActionAnchor(event.currentTarget)} aria-haspopup="menu" aria-expanded={Boolean(actionAnchor)} aria-label="Mapping actions" sx={{fontFamily:'inherit',minWidth:24,p:.25}}>···</AiaButton>:null}
      <AiaMenu anchorEl={actionAnchor} open={Boolean(actionAnchor)} onClose={()=>setActionAnchor(null)} slotProps={{paper:{sx:{fontFamily:'inherit'}}}}>
        {recoverableAiUndo(row)?<AiaMenuItem disabled={disabled} onClick={()=>{setActionAnchor(null);undoSheetSuggestion(row.id);}} sx={textSx}>Undo AI change</AiaMenuItem>:null}
      </AiaMenu>
    </AiaBox>
    {reason?<AiaCollapse in={currentOpen}>{current?<Details option={clean(current)} catalog={catalog} selected/>:manualCurrent?<Details option={clean(manualCurrent)} catalog={catalog} selected/>:<Bullets items={[reason]} catalog={catalog}/>}</AiaCollapse>:null}
    {error?<AiaText role="alert" sx={{...textSx,color:'#b91c1c'}}>{error}</AiaText>:null}
    <AiaCollapse in={section==='candidates'}><AiaBox id={`${id}-candidates`} sx={{display:'grid',gap:1,minWidth:0}}>
      {alternatives.map(option=><AiaBox key={option.candidate_id} sx={{p:1,border:'1px solid #e2e8f0',borderRadius:'6px',minWidth:0,maxWidth:'100%',overflowWrap:'anywhere'}}>
        {option.previously_applied?<AiaText sx={textSx}><strong>Previously applied</strong></AiaText>:null}
        <Details option={clean(option)} catalog={catalog}/>
        {!candidatePolicyCompatible(option)?<AiaText sx={textSx}>Historical suggestion. Generate a fresh candidate to use it.</AiaText>:null}
        <AiaButton size="small" variant="contained" disabled={disabled || !candidatePolicyCompatible(option)} onClick={()=>void act(option.candidate_id)} sx={{fontFamily:'inherit',textTransform:'none',mt:.5,color:'#fff',backgroundColor:'#1d4ed8','&:hover':{backgroundColor:'#1e40af'}}}>Use candidate</AiaButton>
      </AiaBox>)}
    </AiaBox></AiaCollapse>
    <AiaCollapse in={section==='suggestions'}><AiaBox id={`${id}-suggestions`} sx={{display:'grid',gap:1,minWidth:0}}>
      {suggestions.map(item=><AiaBox key={item.suggestion_id} role={item.kind==='relationship'?'button':undefined} tabIndex={item.kind==='relationship'?0:undefined}
        onClick={item.kind==='relationship'?()=>joinReview(item):undefined}
        onKeyDown={item.kind==='relationship'?event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();joinReview(item);}}:undefined}
        aria-label={item.kind==='relationship'?'Open relationship recommendation in the bell panel':undefined}
        sx={{cursor:item.kind==='relationship'?'pointer':undefined,p:1,border:'1px solid #e2e8f0',borderRadius:'6px'}}>
        <AiaText sx={textSx}><strong>{item.kind==='relationship'?'Suggested relationship':'Suggested next action'}</strong></AiaText>
        <Bullets items={item.message.split(/\r?\n|(?<=[.!?])\s+(?=[A-Z])/).filter(Boolean).slice(0,3)} catalog={catalog}/>
        {item.message.length>400?<AiaBox component="details" sx={textSx}><summary>More context</summary><ReviewText text={item.message} catalog={catalog}/></AiaBox>:null}
        {item.source_references?.length?<AiaText sx={textSx}>Relevant sources:{' '}{item.source_references.map((ref,index)=><span key={index}>{index?', ':''}<Exact text={ref} catalog={catalog}/></span>)}</AiaText>:null}
        {item.dependency_proposal?<AiaBox component="details" sx={{...textSx,minWidth:0}} onClick={event=>event.stopPropagation()}>
          <summary>Review previous mapping recipe</summary>
          <AiaText sx={textSx}>Evidence: {item.dependency_proposal.evidence_ids.join(', ')}{item.dependency_proposal.publication_version_id?` · Published version ${item.dependency_proposal.publication_version_id}`:''}</AiaText>
          {item.dependency_proposal.ctes.map((cte,index)=><AiaBox key={index}>
            <AiaText sx={textSx}><strong>{String(cte.name??cte.alias??'Required CTE')}</strong></AiaText>
            <AiaBox component="pre" sx={{fontFamily:MONO,whiteSpace:'pre-wrap',overflowWrap:'anywhere',fontSize:'0.75rem'}}>{String(cte.sql_text??cte.cte_sql??cte.sql_body??cte.definition_sql??'The stored recipe has no complete CTE SQL.')}</AiaBox>
          </AiaBox>)}
          {item.dependency_proposal.joins.length?<AiaBox component="pre" sx={{fontFamily:MONO,whiteSpace:'pre-wrap',overflowWrap:'anywhere',fontSize:'0.75rem'}}>{item.dependency_proposal.joins.map(dependencyJoinText).join('\n')}</AiaBox>:null}
          {item.dependency_proposal.transformation?<AiaBox component="pre" sx={{fontFamily:MONO,whiteSpace:'pre-wrap',overflowWrap:'anywhere',fontSize:'0.75rem'}}>{item.dependency_proposal.transformation}</AiaBox>:null}
          <AiaText sx={textSx}>Review and add these dependencies in Source Selection, then rerun the affected targets.</AiaText>
        </AiaBox>:null}
        {item.recommendation_status==='saved'?<AiaText sx={textSx}><strong>Join saved.</strong> The mapping includes this relationship.</AiaText>:null}
      </AiaBox>)}
    </AiaBox></AiaCollapse>
  </AiaBox>;
}
