import type { Column, ColumnGroup, DerivedSource } from '../types/sttm.types';
import { sqlIdentifierKey } from './sql-identifiers';

/** Remove only catalog output representations reproducible from an owned wildcard scope. */
export function durableDerivedColumns(sources: DerivedSource[], groups: ColumnGroup[]) {
  const wildcardIds = new Set(sources.filter(source => {
    const outputs = source.queryScope?.outputs as Array<Record<string, unknown>> | undefined;
    return outputs?.length && outputs.every(output => output.star && output.plain_star);
  }).map(source => source.id));
  const inferred = hydrateDerivedColumns(sources.map(source => wildcardIds.has(source.id)
    ? {...source, columns: [], outputColumns: [], previewColumns: []} : source), groups);
  const columnsWithoutOwnership = (columns: Column[]) => columns.map(({tableId: _tableId, tableName: _tableName, ...column}) => column);
  return sources.map((source, index) => {
    const columns = columnsWithoutOwnership(source.columns ?? []);
    const outputColumns = source.outputColumns ?? [];
    if (!wildcardIds.has(source.id)) {
      const outputs = source.queryScope?.outputs as Array<Record<string, unknown>> | undefined;
      const ownedNames = new Set(outputs?.filter(output => !output.star).map(output => output.name));
      return {
        columns: columns.map(column => ownedNames.has(column.name) && (!column.type || column.type === "—")
          ? {...column, type: 'TEXT'} : column),
        outputColumns: outputColumns.map(column => ownedNames.has(column.name) && column.data_type == null
          ? {...column, data_type: 'TEXT'} : column),
      };
    }
    const expectedColumns = columnsWithoutOwnership(inferred[index].columns ?? []);
    const expectedOutputs = inferred[index].outputColumns ?? [];
    // Unknown/edited types, names and extra annotations remain durable intent.
    return {
      columns: JSON.stringify(columns) === JSON.stringify(expectedColumns) ? [] : columns,
      outputColumns: JSON.stringify(outputColumns) === JSON.stringify(expectedOutputs) ? [] : outputColumns,
    };
  });
}

/** Resolve output catalogs from owned scopes, without executing or rewriting CTE SQL. */
export function hydrateDerivedColumns(sources: DerivedSource[], groups: ColumnGroup[]): DerivedSource[] {
  const physical = new Map(groups.map(group => [sqlIdentifierKey(group.qualifiedName), group.columns]));
  const byId = new Map(sources.map(source => [source.id, source]));
  const resolved = new Map<string, Column[] | null>();
  const visiting = new Set<string>();
  const resolve = (source: DerivedSource): Column[] | null => {
    if (resolved.has(source.id)) return resolved.get(source.id)!;
    if (visiting.has(source.id)) return null;
    visiting.add(source.id);
    const outputs = source.queryScope?.outputs as Array<Record<string, unknown>> | undefined;
    const relations = (source.queryScope?.relations ?? []) as Array<Record<string, unknown>>;
    let columns: Column[] | null;
    if (!outputs?.length) {
      columns = source.outputColumns?.length
        ? source.outputColumns.filter(item => String(item.name ?? '') !== '*')
          .map(item => ({name: String(item.name ?? item.column_name ?? ''), type: String(item.data_type ?? item.type ?? 'TEXT')}))
        : source.previewColumns?.length
          ? source.previewColumns.map(item => ({name:item.name, type:item.dataType}))
          : source.columns?.length ? source.columns : null;
    } else {
      columns = [];
      for (const output of outputs) {
        if (!output.star) {
          const existing = source.outputColumns?.find(item => item.name === output.name);
          columns.push({name:String(output.name ?? ''), type:String(existing?.data_type ?? 'TEXT')});
          continue;
        }
        if (!output.plain_star) { columns = null; break; }
        const inputs = relations.filter(relation => !output.star_qualifier || relation.alias === output.star_qualifier);
        if (!inputs.length) { columns = null; break; }
        for (const relation of inputs) {
          const parent = relation.source_scope_id ? (source.parentDerivedSourceIds ?? source.derivedSourceIds ?? [])
            .map(id => byId.get(id)).find(candidate => candidate?.queryScope?.scope_id === relation.source_scope_id) : undefined;
          const input = parent ? resolve(parent) : physical.get(sqlIdentifierKey(relation.relation_name));
          if (!input?.length) { columns = null; break; }
          columns.push(...input);
        }
        if (!columns) break;
      }
    }
    visiting.delete(source.id);
    resolved.set(source.id, columns);
    return columns;
  };
  return sources.map(source => {
    const columns = resolve(source);
    if (!columns?.length) return source;
    const owned = columns.map(column => ({...column, tableId:source.id, tableName:source.sourceName}));
    const outputColumns = owned.map(column => ({
      ...(source.outputColumns?.find(item => item.name === column.name) ?? {}),
      name:column.name, data_type:column.type ?? 'TEXT',
    }));
    return JSON.stringify(owned) === JSON.stringify(source.columns)
      && JSON.stringify(outputColumns) === JSON.stringify(source.outputColumns)
      ? source : {...source, columns:owned, outputColumns};
  });
}