#!/usr/bin/env python3
"""Bind AGT_SEMANTIC_MODEL_V2 persistence tools to the workbench registry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import snowflake.connector
import yaml


def _load_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def _connect(env: dict[str, str], role: str):
    kwargs: dict[str, str] = {
        "account": env["SNOWFLAKE_ACCOUNT"],
        "user": env["SNOWFLAKE_USER"],
        "role": role,
        "warehouse": env.get("SNOWFLAKE_WAREHOUSE", ""),
    }
    host = env.get("SNOWFLAKE_HOST", "").strip()
    if not host:
        host = f"{env['SNOWFLAKE_ACCOUNT'].lower().replace('_', '-')}.snowflakecomputing.com"
    kwargs["host"] = host.replace("_", "-")
    if env.get("SNOWFLAKE_AUTHENTICATOR", "").strip().lower() == "externalbrowser":
        kwargs["authenticator"] = "externalbrowser"
    else:
        kwargs["password"] = env["SNOWFLAKE_PASSWORD"]
    return snowflake.connector.connect(**kwargs)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-file", default="services/sttm-builder/.env.local")
    parser.add_argument("--agent", default="FOCUS_DB_2.STTM_MCP.AGT_SEMANTIC_MODEL_V2")
    parser.add_argument(
        "--registry",
        default="FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA",
    )
    parser.add_argument("--administrative-role", default="ACCOUNTADMIN")
    args = parser.parse_args()

    env = _load_env(Path(args.env_file))
    connection = _connect(env, args.administrative_role)
    original_owner = "AIA_AGENT_ROLE"
    try:
        with connection.cursor() as cursor:
            cursor.execute(f"SHOW GRANTS ON AGENT {args.agent}")
            grant_rows = cursor.fetchall()
            grant_columns = [str(item[0]).lower() for item in cursor.description or []]
        role_grants = {
            str(dict(zip(grant_columns, row)).get("grantee_name") or "")
            for row in grant_rows
            if str(dict(zip(grant_columns, row)).get("privilege") or "").upper() == "USAGE"
        }
        role_grants.update({"ACCOUNTADMIN", "FOCUS_ADMIN", "WORKBENCH_ADMIN"})
        with connection.cursor() as cursor:
            cursor.execute(f"DESCRIBE AGENT {args.agent}")
            row = cursor.fetchone()
            columns = [str(item[0]).lower() for item in cursor.description or []]
            described = dict(zip(columns, row or []))
        original_owner = str(described.get("owner") or original_owner)
        raw_spec = described.get("agent_spec")
        spec = json.loads(raw_spec) if isinstance(raw_spec, str) else raw_spec
        if not isinstance(spec, dict):
            raise RuntimeError("AGT_SEMANTIC_MODEL_V2 specification is not a JSON object")
        resources = spec.setdefault("tool_resources", {})
        if not isinstance(resources, dict):
            raise RuntimeError("Agent tool_resources is not an object")
        warehouse = env.get("SNOWFLAKE_WAREHOUSE", "AIA_WH") or "AIA_WH"
        execution_environment = {"type": "warehouse", "warehouse": warehouse}
        bindings = {
            "SAVE_SEMANTIC_VIEW": (
                f"{args.registry}.SP_SAVE_SEMANTIC_VIEW",
                "SP_SAVE_SEMANTIC_VIEW(VARCHAR)",
            ),
            "GET_CACHED_SEMANTIC_VIEW": (
                f"{args.registry}.SP_GET_SEMANTIC_ASSET",
                "SP_GET_SEMANTIC_ASSET(VARCHAR, VARCHAR, VARCHAR)",
            ),
            "CHECK_TABLE_STALENESS": (
                f"{args.registry}.SP_CHECK_TABLE_STALENESS",
                "SP_CHECK_TABLE_STALENESS(VARCHAR, VARCHAR, VARCHAR)",
            ),
            "CHECK_COLUMN_STALENESS": (
                f"{args.registry}.SP_CHECK_COLUMN_STALENESS",
                "SP_CHECK_COLUMN_STALENESS(VARCHAR, VARCHAR, VARCHAR, VARCHAR)",
            ),
        }
        for tool_name, (identifier, signature) in bindings.items():
            resources[tool_name] = {
                "type": "procedure",
                "identifier": identifier,
                "name": signature,
                "execution_environment": dict(execution_environment),
            }

        instructions = spec.setdefault("instructions", {})
        orchestration = str(instructions.get("orchestration") or "")
        registry_instruction = (
            "\n\nCanonical registry rule: SAVE_SEMANTIC_VIEW versions the completed TABLE "
            f"asset in {args.registry}. Call it exactly once "
            "for every generated or refreshed table asset. Do not persist semantics in "
            "FOCUS_DB_2.STTM_MCP. The scheduled publisher creates and links the physical semantic view."
        )
        if "Canonical registry rule:" not in orchestration:
            instructions["orchestration"] = orchestration + registry_instruction

        profile = str(described.get("profile") or '{"display_name":"AGT_SEMANTIC_MODEL_V2"}')
        spec_yaml = yaml.safe_dump(spec, sort_keys=False, allow_unicode=False)
        escaped_profile = profile.replace("'", "''")
        statement = (
            f"CREATE OR REPLACE AGENT {args.agent}\n"
            f"PROFILE = '{escaped_profile}'\n"
            "FROM SPECIFICATION\n$$\n"
            f"{spec_yaml.rstrip()}\n$$"
        )
        with connection.cursor() as cursor:
            if original_owner.upper() != args.administrative_role.upper():
                cursor.execute(
                    f"GRANT OWNERSHIP ON AGENT {args.agent} TO ROLE {args.administrative_role} COPY CURRENT GRANTS"
                )
            cursor.execute(statement)
            if original_owner.upper() != args.administrative_role.upper():
                cursor.execute(
                    f"GRANT OWNERSHIP ON AGENT {args.agent} TO ROLE {original_owner} COPY CURRENT GRANTS"
                )
            for role_name in sorted(role for role in role_grants if role and role.upper() != original_owner.upper()):
                cursor.execute(f"GRANT USAGE ON AGENT {args.agent} TO ROLE {role_name}")
        print(f"Rebound {args.agent} to canonical registry {args.registry}")
        return 0
    finally:
        connection.close()


if __name__ == "__main__":
    raise SystemExit(main())
