from __future__ import annotations

from app.agent_tools.sql_isolation import compile_error_summary, error_names, isolate, suspects

UNKNOWN_FUNCTIONS = (
    "(1304): 01c76563-0009-0217-0001-70b25023032a: 002139 (02000): SQL compilation error:\n"
    "Unknown functions ADVISOR_SF_USER_MAPPER, REFERRAL_MASTER_MAPPER_LOOKUP, SOURCE_LOOKUP_NAME."
)


def _compiler(bad: dict[str, str], structural: bool = False):
    """A fake EXPLAIN: fails with the message of the first bad expression present."""
    calls: list[list[str]] = []

    def attempt(items):
        calls.append([item["target"] for item in items])
        if structural:
            return None, RuntimeError("SQL compilation error: invalid identifier 'J.JOIN_KEY'")
        for item in items:
            for token, message in bad.items():
                if token in (item.get("expression") or ""):
                    return None, RuntimeError(message)
        return {"targets": [item["target"] for item in items]}, None

    return attempt, calls


def _items(**expressions: str):
    return [{"target": target, "expression": expression} for target, expression in expressions.items()]


def test_summary_strips_query_id_and_code():
    summary = compile_error_summary(UNKNOWN_FUNCTIONS)
    assert summary.startswith("SQL compilation error:")
    assert "01c76563" not in summary and "002139" not in summary
    assert "ADVISOR_SF_USER_MAPPER" in summary


def test_summary_masks_data_literals_but_keeps_identifier():
    summary = compile_error_summary("SQL compilation error: invalid identifier 'C.EMAIL' near 'secret@x.com'")
    assert "'C.EMAIL'" in summary
    assert "secret@x.com" not in summary


def test_error_names_parses_functions_and_identifiers():
    functions, identifiers = error_names(UNKNOWN_FUNCTIONS)
    assert functions == {"ADVISOR_SF_USER_MAPPER", "REFERRAL_MASTER_MAPPER_LOOKUP", "SOURCE_LOOKUP_NAME"}
    assert identifiers == set()
    _, identifiers = error_names("error line 6 at position 23\ninvalid identifier 'C.COLUMN_DESCRIPTION'")
    assert identifiers == {"COLUMN_DESCRIPTION"}


def test_suspects_match_calls_not_substrings():
    expressions = {
        "OWNERID": "advisor_sf_user_mapper(CONTACTS.WRITING_ADVISOR_ID)",
        "OTHER": "CONTACTS.ADVISOR_SF_USER_MAPPER_ID",  # same letters, not a call
        "SRC": "source_lookup_name(SOURCE_ID)",
    }
    assert suspects(UNKNOWN_FUNCTIONS, expressions) == ["OWNERID", "SRC"]


def test_named_functions_removed_in_one_round():
    items = _items(
        NAME="",
        OWNERID="advisor_sf_user_mapper(C.X)",
        REFERRAL="referral_master_mapper_lookup(C.Y)",
        CITY="TRIM(A.CITY)",
    )
    attempt, calls = _compiler({"advisor_sf": UNKNOWN_FUNCTIONS, "referral_master": UNKNOWN_FUNCTIONS})
    result = isolate(items, attempt, key=lambda i: i["target"], expression=lambda i: i["expression"],
                     max_attempts=10, first_error=RuntimeError(UNKNOWN_FUNCTIONS))
    assert set(result.failing) == {"OWNERID", "REFERRAL"}
    assert [i["target"] for i in result.passing] == ["NAME", "CITY"]
    assert result.compiled == {"targets": ["NAME", "CITY"]}
    assert result.error is None and len(calls) == 1


def test_bisection_when_error_names_nothing():
    message = "SQL compilation error: argument 1 to function TRIM needs to be text"
    items = _items(A="", B="TRIM(X.N)", C="X.C", D="X.D", E="UPPER(X.E)")
    attempt, _ = _compiler({"TRIM(X.N)": message})
    result = isolate(items, attempt, key=lambda i: i["target"], expression=lambda i: i["expression"],
                     max_attempts=20, first_error=RuntimeError(message))
    assert list(result.failing) == ["B"]
    assert result.compiled == {"targets": ["A", "C", "D", "E"]}


def test_structural_failure_keeps_every_column():
    items = _items(A="", B="X.B")
    attempt, _ = _compiler({}, structural=True)
    result = isolate(items, attempt, key=lambda i: i["target"], expression=lambda i: i["expression"],
                     max_attempts=10, first_error=RuntimeError("SQL compilation error: invalid identifier 'J.JOIN_KEY'"))
    assert result.structural and not result.failing
    assert [i["target"] for i in result.passing] == ["A", "B"]


def test_attempt_budget_is_respected():
    message = "SQL compilation error: something opaque"
    items = _items(**{f"C{i}": f"F{i}(X.V)" for i in range(16)})
    attempt, calls = _compiler({f"F{i}(": message for i in range(0, 16, 3)})
    result = isolate(items, attempt, key=lambda i: i["target"], expression=lambda i: i["expression"],
                     max_attempts=4, first_error=RuntimeError(message))
    assert result.exhausted
    assert len(calls) <= 4
