from __future__ import annotations

from app.agent_runs.models import AgentActor, AgentCommand


class AgentToolAuthorizationError(PermissionError):
    pass


class AgentToolAuthorizer:
    """Fail-closed authorization for every model-proposed domain operation."""

    PUBLISH_OPERATIONS = {"publish", "publish_mapping", "publish_project", "sttm.publish"}

    def authorize(self, command: AgentCommand) -> None:
        operation = command.operation.lower().strip()
        if operation in self.PUBLISH_OPERATIONS or "publish" in operation:
            raise AgentToolAuthorizationError(
                "Publication is user-only and is not available to the migration agent"
            )
        if command.actor.actor_type != "agent-worker":
            raise AgentToolAuthorizationError("Agent domain commands require an agent-worker actor")
        if not command.actor.user_id or not command.actor.effective_role:
            raise AgentToolAuthorizationError("Agent commands require an authenticated user and effective role")
        if command.project_id and not command.subject_key:
            raise AgentToolAuthorizationError("Project-scoped commands require a canonical subject key")

    @staticmethod
    def assert_user_publish_actor(actor: AgentActor | str | None) -> None:
        actor_type = actor.actor_type if isinstance(actor, AgentActor) else str(actor or "user")
        if actor_type != "user":
            raise AgentToolAuthorizationError(
                "Publication is restricted to an authenticated human user"
            )
