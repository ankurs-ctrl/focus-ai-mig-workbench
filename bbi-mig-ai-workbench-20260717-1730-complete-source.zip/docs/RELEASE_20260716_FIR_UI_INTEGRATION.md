# FIR UI and Client AVD Release

## Included

- Snowflake-style assistant shell with persistent notification inbox.
- FIR recommendations and questions remain available until resolved or dismissed.
- Selecting an inbox item opens it in the assistant with its actions and evidence.
- Constant-value target mappings with typed Snowflake SQL generation.
- Wrapped source-column labels.
- Drag-and-drop source, target, schema, database, and derived-source selection.
- Responsive final-summary lineage rendering.
- Exact FIR context and attribution for Auto-map, Builder, conversation, DBT conversion,
  and test-generation paths.
- Restored `AGT_WORKBENCH_CONVERSATION` with exact FIR-first retrieval and
  `CSS_FIR_KNOWLEDGE` fallback.
- Unified authoritative FIR Cortex Search service; duplicate FIR search services retired.
- Repository-managed `CSS_WORKBENCH_RAG` creation before Builder and Conversation agents.
- Cross-platform metadata bootstrap now deploys FIR tables, streams, procedures,
  search, agents, suspended tasks, and grants from repository definitions.
- Mapping-aware client SQL/Excel ingestion command that can create a project,
  materialize named CTEs, autosave a canonical STTM, and publish it as FIR precedent.

## Client Deployment Order

1. Configure `infra/snowflake/env/client.env`.
2. Set `SNOWFLAKE_SEMANTIC_VIEWS_DATABASE` and
   `SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA` to the registry containing
   `SEM_TABLE_VIEWS`, `SEM_COLUMN_VIEWS`, and `SEM_NATIVE_VIEWS`.
3. Run `scripts/bootstrap_sttm_metadata_infra.ps1` on Windows or
   `scripts/bootstrap_sttm_metadata_infra.sh` on macOS/Linux.
4. Verify the FIR objects and agent specifications.
5. Resume the FIR graph with
   `infra/snowflake/fir_system/tasks/fir_tasks_resume.sql`.
6. Ingest historical scripts and workbooks using
   `scripts/load_client_fir_knowledge.py`.
7. Deploy the application services.

## Important Runtime Behavior

- Browsing and selection use precomputed table-backed FIR retrieval.
- Exact context is checked before compatible structured matches.
- Cortex Search is a fallback for similar validated contexts.
- Source Mapping and Transformation Rule remain tool-free; the backend supplies
  their complete FIR context.
- Similar-context search results carry lower confidence and cannot be applied
  without user confirmation.
- Tasks are intentionally not resumed by bootstrap. This allows schema, stream,
  procedure, and semantic-registry verification before offline processing begins.
