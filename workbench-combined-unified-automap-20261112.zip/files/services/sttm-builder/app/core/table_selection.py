import json
import hashlib
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from typing import Callable, TypeVar

from snowflake.connector.constants import FIELD_ID_TO_NAME
from snowflake.connector.cursor import ResultMetadata
from snowflake.snowpark.functions import col

from app.core.config import Settings
from app.core.exceptions import SnowflakeQueryError
from app.core.performance import increment, observe
from app.core.snowflake import SnowflakeClient
from app.core.semantic_knowledge_resolver import SemanticKnowledgeResolver
from app.schema.common import TableRef

logger = logging.getLogger(__name__)
from app.schema.table_selection import (
    ColumnItem,
    DatabaseItem,
    RelationshipColumnMapping,
    RelationshipItem,
    SchemaItem,
    TableAttributes,
    TableItem,
)

_T = TypeVar("_T")
_CACHE_LOCK = Lock()
_CACHE: dict[str, tuple[float, float, object]] = {}
_CACHE_INFLIGHT: dict[str, threading.Event] = {}


def _cached(
    key: str,
    loader: Callable[[], _T],
    *,
    ttl_seconds: float,
    stale_if_error_seconds: float,
) -> _T:
    now = time.monotonic()
    with _CACHE_LOCK:
        cached = _CACHE.get(key)
        if cached and cached[0] > now:
            increment("table_selection.cache.hit")
            return cached[2]  # type: ignore[return-value]
        event = _CACHE_INFLIGHT.get(key)
        if event is None:
            event = threading.Event()
            _CACHE_INFLIGHT[key] = event
            owner = True
        else:
            owner = False
    if not owner:
        event.wait(timeout=120)
        with _CACHE_LOCK:
            cached = _CACHE.get(key)
            if cached and cached[0] > time.monotonic():
                increment("table_selection.cache.coalesced")
                return cached[2]  # type: ignore[return-value]
    increment("table_selection.cache.miss")
    try:
        value = loader()
        stored_at = time.monotonic()
        with _CACHE_LOCK:
            _CACHE[key] = (stored_at + max(1.0, ttl_seconds), stored_at, value)
        return value
    except Exception:
        with _CACHE_LOCK:
            stale = _CACHE.get(key)
        if stale and stale_if_error_seconds > 0 and time.monotonic() - stale[1] <= stale_if_error_seconds:
            increment("table_selection.cache.stale_fallback")
            logger.warning("Serving stale authorized catalog metadata for cache key %s", key)
            return stale[2]  # type: ignore[return-value]
        raise
    finally:
        if owner:
            with _CACHE_LOCK:
                completed = _CACHE_INFLIGHT.pop(key, None)
                if completed is not None:
                    completed.set()


def invalidate_relationship_cache() -> None:
    """Drop cached relationship lists so newly learned joins appear immediately."""
    with _CACHE_LOCK:
        for key in [key for key in _CACHE if ":relationships:" in key]:
            _CACHE.pop(key, None)


class TableSelectionService:
    def __init__(self, client: SnowflakeClient, settings: Settings, access_scope: str = "default") -> None:
        self._session = client.session
        self._settings = settings
        self._semantic_knowledge = SemanticKnowledgeResolver(settings)
        self._cache_ttl_seconds = max(1.0, float(settings.table_selection_cache_seconds))
        self._stale_if_error_seconds = max(
            0.0,
            float(settings.table_selection_stale_if_error_seconds),
        )
        effective_scope = access_scope if access_scope != "default" else f"session:{id(client.session)}"
        self._cache_prefix = hashlib.sha256(effective_scope.encode("utf-8")).hexdigest()

    def _cache_key(self, value: str) -> str:
        return f"{self._cache_prefix}:{value}"

    @staticmethod
    def _quote_identifier(identifier: str) -> str:
        return '"' + identifier.replace('"', '""') + '"'

    @staticmethod
    def _quote_literal(value: str) -> str:
        return "'" + value.replace("'", "''") + "'"

    @staticmethod
    def _row_value(row, *names: str):
        values = row.as_dict() if hasattr(row, "as_dict") else dict(row)
        for name in names:
            for candidate in (name, name.upper(), name.lower()):
                if candidate in values:
                    return values[candidate]
        return None

    def list_databases(self) -> list[DatabaseItem]:
        return self._cached_catalog("databases", self._list_databases_uncached)

    def _cached_catalog(self, key: str, loader: Callable[[], _T]) -> _T:
        return _cached(
            self._cache_key(key),
            loader,
            ttl_seconds=self._cache_ttl_seconds,
            stale_if_error_seconds=self._stale_if_error_seconds,
        )

    def _list_databases_uncached(self) -> list[DatabaseItem]:
        try:
            db_rows = self._session.sql("SHOW TERSE DATABASES").collect()
        except Exception as e:
            raise SnowflakeQueryError(f"Failed to list databases: {e}") from e

        result = []
        for row in db_rows:
            db_name = self._row_value(row, "name", "database_name")
            if not db_name:
                continue
            result.append(
                DatabaseItem(
                    database_name=str(db_name),
                    created=self._row_value(row, "created_on", "created"),
                    schemas=[],
                )
            )
        return sorted(result, key=lambda item: item.database_name)

    def list_schemas(self, db_name: str) -> list[SchemaItem]:
        return self._cached_catalog(
            f"schemas:{db_name.upper()}",
            lambda: self._list_schemas_uncached(db_name),
        )

    def _list_schemas_uncached(self, db_name: str) -> list[SchemaItem]:
        try:
            rows = self._session.sql(
                "SHOW TERSE SCHEMAS IN DATABASE "
                f"{self._quote_identifier(db_name)}"
            ).collect()
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to list schemas in {db_name!r}: {e}"
            ) from e

        schemas = []
        for row in rows:
            schema_name = self._row_value(row, "name", "schema_name")
            if not schema_name:
                continue
            schemas.append(
                SchemaItem(
                    schema_name=str(schema_name),
                    created=self._row_value(row, "created_on", "created"),
                )
            )
        return sorted(schemas, key=lambda item: item.schema_name)

    def list_tables(self, db_name: str, schema_name: str) -> list[TableItem]:
        return self._cached_catalog(
            f"tables:{db_name.upper()}.{schema_name.upper()}",
            lambda: self._list_tables_uncached(db_name, schema_name),
        )

    def _list_tables_uncached(self, db_name: str, schema_name: str) -> list[TableItem]:
        # Independent catalog reads run together. Neither scans source data.
        table_query = self._session.sql(
            f"SHOW TABLES IN SCHEMA {self._quote_identifier(db_name)}.{self._quote_identifier(schema_name)}"
        )
        count_query = self._session.sql(
            f"SELECT TABLE_NAME, COUNT(*) AS COLUMN_COUNT FROM {self._quote_identifier(db_name)}.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? GROUP BY TABLE_NAME",
            params=[schema_name],
        )
        column_counts = {}
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="sttm-catalog-counts") as executor:
            tables_future = executor.submit(table_query.collect)
            counts_future = executor.submit(count_query.collect)
            try:
                table_rows = tables_future.result()
            except Exception as exc:
                raise SnowflakeQueryError(f"Failed to list tables in {db_name!r}.{schema_name!r}: {exc}") from exc
            try:
                rows = counts_future.result()
                column_counts = {str(self._row_value(row, 'TABLE_NAME')): int(self._row_value(row, 'COLUMN_COUNT') or 0) for row in rows}
            except Exception:
                logger.warning('Catalog column counts unavailable for %s.%s; selected-table hydration will retry', db_name, schema_name, exc_info=True)

        result: list[TableItem] = []
        for row in table_rows:
            table_name = self._row_value(row, "name", "table_name")
            if not table_name:
                continue
            name = str(table_name)
            row_count = self._row_value(row, "rows", "row_count")
            result.append(TableItem(table_name=name,
                row_count=int(row_count) if row_count is not None else None,
                column_count=column_counts.get(name, 0)))
        return sorted(result, key=lambda item: item.table_name)

    def list_attributes_for_tables(self, qualified_names: list[str]) -> list[TableAttributes]:
        # Ignore older empty-schema cache entries and never mask a new access failure.
        key = "attributes:v2:" + "|".join(sorted(qn.upper() for qn in qualified_names))
        return _cached(
            self._cache_key(key),
            lambda: self._list_attributes_for_tables_uncached(qualified_names),
            ttl_seconds=self._cache_ttl_seconds,
            stale_if_error_seconds=0,
        )

    def _list_attributes_for_tables_uncached(self, qualified_names: list[str]) -> list[TableAttributes]:
        from app.core.exceptions import AppValidationError

        parsed: list[tuple[str, str, str]] = []
        for qn in qualified_names:
            parts = qn.split(".", 2)
            if len(parts) != 3:
                raise AppValidationError(
                    f"Invalid table reference {qn!r}. Expected format: DATABASE.SCHEMA.TABLE"
                )
            parsed.append((parts[0], parts[1], parts[2]))

        by_database: dict[str, list[tuple[str, str]]] = {}
        for db, schema, table in parsed:
            by_database.setdefault(db, []).append((schema, table))

        columns_by_fqn: dict[str, list[ColumnItem]] = {}
        for database, tables in by_database.items():
            columns_by_fqn.update(self._bulk_columns(database, tables))

        return [
            TableAttributes(
                table=TableRef(database=db, schema=schema, table=table),
                columns=columns_by_fqn[f"{db}.{schema}.{table}".upper()],
            )
            for db, schema, table in parsed
        ]

    def _bulk_columns(
        self,
        database: str,
        tables: list[tuple[str, str]],
    ) -> dict[str, list[ColumnItem]]:
        """Load columns and key flags with two concurrent set-based queries."""
        if not tables:
            return {}
        pair_predicate = " OR ".join(
            "(UPPER(TABLE_SCHEMA) = "
            f"{self._quote_literal(schema.upper())} AND UPPER(TABLE_NAME) = "
            f"{self._quote_literal(table.upper())})"
            for schema, table in sorted(set(tables))
        )
        information_schema = (
            f"{self._quote_identifier(database)}.INFORMATION_SCHEMA"
        )
        column_query = self._session.sql(
            f"""
            SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE,
                   IS_NULLABLE, ORDINAL_POSITION, COMMENT
            FROM {information_schema}.COLUMNS
            WHERE {pair_predicate}
            ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION
            """
        )
        key_query = self._session.sql(
            f"""
            SELECT k.TABLE_SCHEMA, k.TABLE_NAME, k.COLUMN_NAME,
                   c.CONSTRAINT_TYPE
            FROM {information_schema}.KEY_COLUMN_USAGE k
            JOIN {information_schema}.TABLE_CONSTRAINTS c
              ON c.CONSTRAINT_CATALOG = k.CONSTRAINT_CATALOG
             AND c.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA
             AND c.CONSTRAINT_NAME = k.CONSTRAINT_NAME
            WHERE {pair_predicate.replace('TABLE_SCHEMA', 'k.TABLE_SCHEMA').replace('TABLE_NAME', 'k.TABLE_NAME')}
            """
        )
        import time
        started = time.perf_counter()
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="sttm-metadata") as executor:
            column_future = executor.submit(column_query.collect)
            key_future = executor.submit(key_query.collect)
            try:
                column_rows = column_future.result()
            except Exception as exc:
                logger.warning('Column metadata failed: database=%s tables=%d elapsed_ms=%.1f query_id=%s', database, len(tables), (time.perf_counter()-started)*1000, getattr(exc, 'sfqid', None) or getattr(exc, 'query_id', None))
                raise SnowflakeQueryError(
                    f"Failed to list columns for {len(tables)} tables in {database!r}: {exc}"
                ) from exc
            try:
                key_rows = key_future.result()
            except Exception:
                key_rows = []
                # Key metadata can be restricted independently of column metadata.
                # Columns remain authoritative and usable without key decorations.
                logger.info("Bulk key metadata unavailable for %s", database, exc_info=True)

        logger.info("Column metadata loaded: database=%s tables=%d elapsed_ms=%.1f", database, len(tables), (time.perf_counter()-started)*1000)
        key_types: dict[tuple[str, str], set[str]] = {}
        if key_rows:
            for row in key_rows:
                schema = str(self._row_value(row, "TABLE_SCHEMA") or "").upper()
                table = str(self._row_value(row, "TABLE_NAME") or "").upper()
                column = str(self._row_value(row, "COLUMN_NAME") or "").upper()
                constraint_type = str(
                    self._row_value(row, "CONSTRAINT_TYPE") or ""
                ).upper()
                key_types.setdefault((f"{database}.{schema}.{table}".upper(), column), set()).add(
                    constraint_type
                )

        result: dict[str, list[ColumnItem]] = {}
        for row in column_rows:
            schema = str(self._row_value(row, "TABLE_SCHEMA") or "")
            table = str(self._row_value(row, "TABLE_NAME") or "")
            column = str(self._row_value(row, "COLUMN_NAME") or "")
            fqn = f"{database}.{schema}.{table}".upper()
            constraints = key_types.get((fqn, column.upper()), set())
            result.setdefault(fqn, []).append(
                ColumnItem(
                    column_name=column,
                    data_type=str(self._row_value(row, "DATA_TYPE") or ""),
                    is_nullable=str(self._row_value(row, "IS_NULLABLE") or ""),
                    ordinal_position=int(self._row_value(row, "ORDINAL_POSITION") or 0),
                    comment=self._row_value(row, "COMMENT"),
                    is_primary_key="PRIMARY KEY" in constraints,
                    is_foreign_key="FOREIGN KEY" in constraints,
                )
            )
        for schema, table in sorted(set(tables)):
            fqn = f"{database}.{schema}.{table}".upper()
            if not result.get(fqn):
                columns = self._columns_from_query_result(database, schema, table)
                primary_keys = self._primary_key_columns(database, schema, table)
                foreign_keys = self._foreign_key_columns(database, schema, table)
                for column in columns:
                    constraints = key_types.get((fqn, column.column_name.upper()), set())
                    column.is_primary_key = (
                        column.column_name in primary_keys or "PRIMARY KEY" in constraints
                    )
                    column.is_foreign_key = (
                        column.column_name in foreign_keys or "FOREIGN KEY" in constraints
                    )
                result[fqn] = columns
        return result

    def _columns_from_query_result(
        self, database: str, schema: str, table: str
    ) -> list[ColumnItem]:
        """Recover physical columns when Information Schema filters out a readable table."""
        qualified_name = ".".join(
            self._quote_identifier(part) for part in (database, schema, table)
        )
        try:
            # Use a dedicated cursor on the SAME caller connection. No data rows,
            # alternate credentials, or shared Snowpark result cursor are needed.
            with self._session.connection.cursor() as cursor:
                cursor.execute(f"SELECT * FROM {qualified_name} WHERE 1=0")
                fields = cursor.description
                if not fields:
                    raise ValueError("Snowflake returned no column definitions")
                columns = [
                    ColumnItem(
                        column_name=field.name,
                        data_type=self._query_result_type(field),
                        is_nullable="YES" if field.is_nullable else "NO",
                        ordinal_position=position,
                        # Query-result metadata does not contain column comments.
                        comment=None,
                    )
                    for position, field in enumerate(fields, start=1)
                ]
        except Exception as exc:
            raise SnowflakeQueryError(
                f"Column metadata unavailable for {qualified_name}: Information Schema "
                f"returned no columns and same-caller schema discovery failed: {exc}"
            ) from exc
        increment("table_selection.columns.query_result_fallback")
        logger.warning(
            "Recovered %d columns for %s from same-caller query metadata; column comments unavailable",
            len(columns),
            qualified_name,
        )
        return columns

    @staticmethod
    def _query_result_type(field: ResultMetadata) -> str:
        type_name = FIELD_ID_TO_NAME.get(field.type_code)
        if not type_name:
            raise ValueError(f"Unsupported Snowflake result type code: {field.type_code}")
        if type_name == "FIXED":
            if field.scale is None:
                return "DECFLOAT"
            if field.precision is not None:
                return f"NUMBER({field.precision},{field.scale})"
            return "NUMBER"
        if type_name == "REAL":
            return "FLOAT"
        if type_name in {"TEXT", "BINARY"}:
            sql_type = "VARCHAR" if type_name == "TEXT" else "BINARY"
            return f"{sql_type}({field.internal_size})" if field.internal_size else sql_type
        if type_name == "TIME" or type_name.startswith("TIMESTAMP"):
            return f"{type_name}({field.scale})" if field.scale is not None else type_name
        return type_name

    def list_relationships_for_tables(self, tables: list[TableRef]) -> list[RelationshipItem]:
        key = "relationships:" + "|".join(sorted(table.qualified_name.upper() for table in tables))
        return _cached(
            self._cache_key(key),
            lambda: self._list_relationships_for_tables_uncached(tables),
            ttl_seconds=self._cache_ttl_seconds,
            stale_if_error_seconds=self._stale_if_error_seconds,
        )

    def list_relationship_discovery_for_tables(
        self,
        tables: list[TableRef],
    ) -> tuple[list[RelationshipItem], list[RelationshipItem]]:
        """Return active joins and every semantic recommendation.

        The legacy list endpoint and this endpoint share the same cached result,
        so rendering both Join and AI Recommendation tabs does not trigger a
        second semantic-view query.
        """
        relationships = self.list_relationships_for_tables(tables)
        return [item for item in relationships if not item.review_required], relationships

    def _list_relationships_for_tables_uncached(self, tables: list[TableRef]) -> list[RelationshipItem]:
        started = time.perf_counter()
        selected = {table.qualified_name.upper(): table for table in tables}
        relationships: dict[str, RelationshipItem] = {}
        logger.info("Relationship lookup for %d tables: %s", len(tables), list(selected.keys()))
        try:
            semantic_payloads = self._semantic_knowledge.relationship_payloads(
                self._session,
                tables,
            )
        except Exception:
            logger.warning("Unified semantic relationship resolution failed", exc_info=True)
            semantic_payloads = self._get_relationships_from_semantic_views(tables)

        for table in tables:
            payload = semantic_payloads.get(table.qualified_name.upper())
            logger.info("Semantic view for %s: %s", table.qualified_name, "found" if payload else "not found")
            if payload:
                logger.info("  outgoing=%d incoming=%d", len(payload.get("outgoing", [])), len(payload.get("incoming", [])))
            # The legacy relationship procedure is table-at-a-time. Keep it for
            # compact selections, but never fan it out across a large workspace.
            if (
                not payload
                and len(tables) <= 3
                and self._schema_may_have_foreign_keys(table)
            ):
                try:
                    increment("relationships.legacy_procedure_call")
                    payload = self._get_relationship_payload(table)
                except Exception:
                    continue
                if str(payload.get("status", "")).upper() != "OK":
                    continue
            if not payload:
                continue

            # Process both outgoing and incoming relationships
            directions = ["outgoing", "incoming"]
            if self._settings.low_confidence_join_review_v1:
                directions.extend(["review_outgoing", "review_incoming"])
            for direction in directions:
                for item in payload.get(direction, []) or []:
                    # For outgoing: table is left, target is right
                    # For incoming: target is left, table is right
                    normalized_direction = direction.removeprefix("review_")
                    review_required = direction.startswith("review_")
                    if normalized_direction == "outgoing":
                        left_table = table
                        right_table = TableRef(
                            database=str(item.get("database") or table.database),
                            schema=str(item.get("schema", "")),
                            table=str(item.get("table", "")),
                        )
                        left_col_key, right_col_key = "fk_column", "pk_column"
                    else:
                        right_table = table
                        left_table = TableRef(
                            database=str(item.get("database") or table.database),
                            schema=str(item.get("schema", "")),
                            table=str(item.get("table", "")),
                        )
                        left_col_key, right_col_key = "pk_column", "fk_column"

                    # Only include if both tables are selected
                    if left_table.qualified_name.upper() not in selected:
                        continue
                    if right_table.qualified_name.upper() not in selected:
                        continue

                    conditions = [
                        RelationshipColumnMapping(
                            left_column=str(mapping.get(left_col_key, "")),
                            right_column=str(mapping.get(right_col_key, "")),
                        )
                        for mapping in item.get("column_mappings", []) or []
                        if mapping.get(left_col_key) and mapping.get(right_col_key)
                    ]
                    if not conditions:
                        continue

                    constraint_name = (
                        str(item.get("constraint_name"))
                        if item.get("constraint_name") is not None
                        else None
                    )
                    # A table pair can have several independent joins. Include
                    # normalized predicates so one active edge cannot conceal a
                    # lower-confidence candidate between the same two tables.
                    condition_signature = "&".join(
                        sorted(
                            f"{condition.left_column}{condition.operator}{condition.right_column}"
                            for condition in conditions
                        )
                    )
                    edge_id = constraint_name or hashlib.sha256(
                        (
                            f"{left_table.qualified_name.upper()}|"
                            f"{right_table.qualified_name.upper()}|{condition_signature.upper()}"
                        ).encode("utf-8")
                    ).hexdigest()[:24]

                    # Don't overwrite existing relationships (dedup)
                    if edge_id not in relationships:
                        relationships[edge_id] = RelationshipItem(
                            id=edge_id,
                            left_table=left_table,
                            right_table=right_table,
                            constraint_name=constraint_name,
                            conditions=conditions,
                            source=str(item.get("source") or "SEMANTIC_VIEW"),
                            locked=not review_required,
                            review_required=review_required,
                            confidence=(
                                (
                                    {"HIGH": 0.9, "MEDIUM": 0.6, "LOW": 0.3}.get(
                                        str(item.get("confidence")).upper(),
                                        0.3,
                                    )
                                    if isinstance(item.get("confidence"), str)
                                    else float(item.get("confidence"))
                                )
                                if item.get("confidence") is not None
                                else None
                            ),
                            review_reason=(
                                str(item.get("review_reason"))
                                if item.get("review_reason")
                                else None
                            ),
                            evidence=(
                                item.get("evidence")
                                if isinstance(item.get("evidence"), dict)
                                else None
                            ),
                        )

        observe(
            "relationships.resolve.total",
            (time.perf_counter() - started) * 1000,
        )
        return self._with_learned_relationships(tables, list(relationships.values()))

    def _with_learned_relationships(
        self,
        tables: list[TableRef],
        relationships: list[RelationshipItem],
    ) -> list[RelationshipItem]:
        """Reinforce semantic joins that users have confirmed and add the rest."""
        from app.core.relationship_learning import RelationshipLearningService, canonical_edge

        learned = RelationshipLearningService(self._session, self._settings).learned_edges(tables)
        if not learned:
            return relationships

        def key(item: RelationshipItem) -> str | None:
            edge = canonical_edge(
                item.left_table,
                item.right_table,
                [condition.model_dump() for condition in item.conditions],
                item.join_type,
            )
            return edge["edge_key"] if edge else None

        by_key = {key(item): item for item in relationships}
        for item in learned:
            existing = by_key.get(key(item))
            if existing is None:
                relationships.append(item)
                continue
            existing.confidence = max(existing.confidence or 0.0, item.confidence or 0.0)
            existing.review_reason = " ".join(
                value for value in (existing.review_reason, item.review_reason) if value
            )
            existing.evidence = {**(existing.evidence or {}), **(item.evidence or {})}
        return relationships

    def record_relationship_review(
        self,
        relationship: RelationshipItem,
        outcome: str,
        *,
        sttm_id: str | None,
        user_id: str | None,
    ) -> None:
        """Turn an Add Join decision into learned-edge evidence."""
        from app.core.relationship_learning import RelationshipLearningService

        store = RelationshipLearningService(self._session, self._settings)
        edge = relationship.model_dump(mode="json")
        if outcome == "accepted":
            # One mapping accepting the same join repeatedly is one piece of evidence.
            support_key = f"sttm:{sttm_id}" if sttm_id else f"user:{user_id}" if user_id else ""
            store.record([edge], evidence_class="accepted_review", support_key=support_key)
        elif outcome == "rejected":
            store.record_rejection(edge)

    def _schema_may_have_foreign_keys(self, table: TableRef) -> bool:
        """Return a cached capability decision without calling ACCOUNT_USAGE."""

        if not self._settings.relationship_capability_cache_v1:
            return True
        cache_key = self._cache_key(
            f"fk-capability:{table.database.upper()}.{table.schema.upper()}"
        )

        def load() -> bool:
            started = time.perf_counter()
            try:
                rows = self._session.sql(
                    f"""
                    SELECT COUNT(*) AS FK_COUNT
                    FROM {self._quote_identifier(table.database)}.INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                    WHERE UPPER(CONSTRAINT_SCHEMA) = {self._quote_literal(table.schema.upper())}
                      AND CONSTRAINT_TYPE = 'FOREIGN KEY'
                    """
                ).collect()
                count = int(self._row_value(rows[0], "FK_COUNT") or 0) if rows else 0
                increment(
                    "relationships.fk_capability.present"
                    if count > 0
                    else "relationships.fk_capability.absent"
                )
                return count > 0
            except Exception as exc:
                logger.warning(
                    "Foreign-key capability lookup failed for %s.%s; preserving legacy fallback: %s",
                    table.database,
                    table.schema,
                    exc,
                )
                increment("relationships.fk_capability.error")
                return True
            finally:
                observe(
                    "relationships.fk_capability.lookup",
                    (time.perf_counter() - started) * 1000,
                )

        return _cached(
            cache_key,
            load,
            ttl_seconds=float(self._settings.relationship_capability_cache_seconds),
            stale_if_error_seconds=float(self._settings.relationship_capability_cache_seconds),
        )

    def _get_relationships_from_semantic_views(
        self,
        tables: list[TableRef],
    ) -> dict[str, dict]:
        """Fetch relationship payloads for a selection in one registry query.

        Extracts FK references from two locations:
        1. SEMANTIC_VIEW:semantic_model:relationships (top-level, if present)
        2. SEMANTIC_VIEW:semantic_model:attributes[].constraints (FK refs in column metadata)
        """
        if not tables:
            return {}
        try:
            sem_table = self._settings.resolved_semantic_views_table
            fqns = ", ".join(
                self._quote_literal(table.qualified_name.upper())
                for table in tables
            )
            rows = self._session.sql(f"""
                SELECT FQN,
                       SEMANTIC_VIEW:semantic_model:relationships AS RELATIONSHIPS,
                       SEMANTIC_VIEW:semantic_model:attributes AS ATTRIBUTES
                FROM {sem_table}
                WHERE UPPER(FQN) IN ({fqns})
                  AND COALESCE(UPPER(STATUS), 'ACTIVE') IN ('ACTIVE', 'PENDING')
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY UPPER(FQN)
                    ORDER BY GENERATED_AT DESC
                ) = 1
            """).collect()
        except Exception:
            logger.warning(
                "Bulk semantic relationship lookup failed at %s",
                self._settings.resolved_semantic_views_table,
                exc_info=True,
            )
            return {}

        table_by_fqn = {
            table.qualified_name.upper(): table
            for table in tables
        }
        result: dict[str, dict] = {}
        for row in rows:
            fqn = str(self._row_value(row, "FQN") or "").upper()
            table = table_by_fqn.get(fqn)
            if table is None:
                continue
            raw_rels = self._row_value(row, "RELATIONSHIPS")
            if raw_rels:
                if isinstance(raw_rels, str):
                    try:
                        raw_rels = json.loads(raw_rels)
                    except json.JSONDecodeError:
                        raw_rels = None
                if isinstance(raw_rels, dict) and (raw_rels.get("outgoing") or raw_rels.get("incoming")):
                    confirmed = {
                        direction: [
                            item
                            for item in (raw_rels.get(direction) or [])
                            if isinstance(item, dict)
                            and self._semantic_knowledge._relationship_is_confirmed(
                                item,
                                curated=False,
                            )
                        ]
                        for direction in ("outgoing", "incoming")
                    }
                    if confirmed["outgoing"] or confirmed["incoming"]:
                        result[fqn] = confirmed
                        continue

            # Extract FK relationships from attributes constraints
            raw_attrs = self._row_value(row, "ATTRIBUTES")
            if isinstance(raw_attrs, str):
                try:
                    raw_attrs = json.loads(raw_attrs)
                except json.JSONDecodeError:
                    raw_attrs = None
            if not isinstance(raw_attrs, list):
                continue

            outgoing = []
            for attr in raw_attrs:
                if not isinstance(attr, dict):
                    continue
                col_name = attr.get("name", "")
                for constraint in attr.get("constraints", []):
                    if not isinstance(constraint, dict):
                        continue
                    if constraint.get("type") != "FOREIGN_KEY":
                        continue
                    confidence = (constraint.get("confidence") or "LOW").upper()
                    if confidence != "HIGH":
                        continue
                    refs = constraint.get("references", {})
                    ref_table = refs.get("table", "")
                    ref_col = refs.get("column", "")
                    if not ref_table or not ref_col:
                        continue
                    outgoing.append({
                        "schema": table.schema,
                        "table": ref_table,
                        "constraint_name": f"FK_{col_name}_{ref_table}_{ref_col}",
                        "column_mappings": [
                            {"fk_column": col_name, "pk_column": ref_col}
                        ],
                    })

            if outgoing:
                result[fqn] = {
                    "status": "OK",
                    "outgoing": outgoing,
                    "incoming": [],
                }
        return result

    def _list_columns(self, db_name: str, schema_name: str, table_name: str) -> list[ColumnItem]:
        primary_key_columns = self._primary_key_columns(db_name, schema_name, table_name)
        foreign_key_columns = self._foreign_key_columns(db_name, schema_name, table_name)
        try:
            rows = (
                self._session.table(f"{db_name}.INFORMATION_SCHEMA.COLUMNS")
                .select(
                    "COLUMN_NAME",
                    "DATA_TYPE",
                    "IS_NULLABLE",
                    "ORDINAL_POSITION",
                    "COMMENT",
                )
                .filter(
                    (col("TABLE_SCHEMA") == schema_name.upper())
                    & (col("TABLE_NAME") == table_name.upper())
                )
                .sort("ORDINAL_POSITION")
                .collect()
            )
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to list columns in {db_name!r}.{schema_name!r}.{table_name!r}: {e}"
            ) from e
        if not rows:
            columns = self._columns_from_query_result(db_name, schema_name, table_name)
            for column in columns:
                column.is_primary_key = column.column_name in primary_key_columns
                column.is_foreign_key = column.column_name in foreign_key_columns
            return columns
        return [
            ColumnItem(
                column_name=r["COLUMN_NAME"],
                data_type=r["DATA_TYPE"],
                is_nullable=r["IS_NULLABLE"],
                ordinal_position=r["ORDINAL_POSITION"],
                comment=r["COMMENT"],
                is_primary_key=r["COLUMN_NAME"] in primary_key_columns,
                is_foreign_key=r["COLUMN_NAME"] in foreign_key_columns,
            )
            for r in rows
        ]

    def _primary_key_columns(
        self,
        db_name: str,
        schema_name: str,
        table_name: str,
    ) -> set[str]:
        try:
            rows = self._session.sql(
                "SHOW PRIMARY KEYS IN TABLE "
                f"{self._quote_identifier(db_name)}."
                f"{self._quote_identifier(schema_name)}."
                f"{self._quote_identifier(table_name)}"
            ).collect()
        except Exception:
            return set()

        return {
            str(column_name)
            for row in rows
            if (column_name := self._row_value(row, "column_name", "COLUMN_NAME"))
        }

    def _foreign_key_columns(
        self,
        db_name: str,
        schema_name: str,
        table_name: str,
    ) -> set[str]:
        try:
            rows = self._session.sql(
                "SHOW IMPORTED KEYS IN TABLE "
                f"{self._quote_identifier(db_name)}."
                f"{self._quote_identifier(schema_name)}."
                f"{self._quote_identifier(table_name)}"
            ).collect()
        except Exception:
            return set()

        return {
            str(column_name)
            for row in rows
            if (
                column_name := self._row_value(
                    row,
                    "fk_column_name",
                    "FK_COLUMN_NAME",
                    "column_name",
                    "COLUMN_NAME",
                )
            )
        }

    def _get_relationship_payload(self, table: TableRef) -> dict:
        proc_name = self._settings.resolved_relationships_procedure
        if not proc_name:
            raise SnowflakeQueryError(
                "Could not resolve the table relationship procedure. "
                "Set SNOWFLAKE_RELATIONSHIPS_PROCEDURE or provide "
                "SNOWFLAKE_DATABASE/SNOWFLAKE_SCHEMA."
            )

        procedures = [proc_name]
        if proc_name.upper().endswith(".SP_GET_TABLE_RELATIONSHIPS_V2"):
            procedures.append(proc_name[:-3])
        rows = None
        for candidate in procedures:
            proc_parts = candidate.split(".", 2)
            quoted_proc_name = ".".join(
                self._quote_identifier(part) for part in proc_parts if part
            )
            try:
                rows = self._session.sql(
                    "CALL "
                    f"{quoted_proc_name}("
                    f"{self._quote_literal(table.database)}, "
                    f"{self._quote_literal(table.schema)}, "
                    f"{self._quote_literal(table.table)})"
                ).collect()
                if candidate != proc_name:
                    increment("relationships.fast_proc.compatibility_fallback")
                break
            except Exception as exc:
                if candidate == procedures[-1]:
                    raise SnowflakeQueryError(
                        f"Failed to fetch table relationships for {table.qualified_name!r}: {exc}"
                    ) from exc

        if not rows:
            return {}

        raw_result = list(rows[0].as_dict().values())[0]
        if isinstance(raw_result, dict):
            return raw_result
        if isinstance(raw_result, str):
            try:
                return json.loads(raw_result)
            except json.JSONDecodeError:
                return {}
        return raw_result or {}
