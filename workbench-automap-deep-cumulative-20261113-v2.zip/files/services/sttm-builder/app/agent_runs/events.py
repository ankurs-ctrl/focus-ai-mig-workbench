from __future__ import annotations

import json
from collections.abc import Iterable

from app.agent_runs.models import AgentRunEvent


def encode_sse(events: Iterable[AgentRunEvent]) -> str:
    """Encode durable application events without exposing model reasoning."""
    chunks: list[str] = []
    for event in events:
        chunks.append(f"id: {event.sequence}")
        chunks.append(f"event: {event.event_type}")
        chunks.append(f"data: {json.dumps(event.model_dump(mode='json'), separators=(',', ':'))}")
        chunks.append("")
    return "\n".join(chunks) + ("\n" if chunks else "")
