"""Find why a generated mapping query fails, fix the cause, and prove the fix.

Snowflake reports one error at a time. For each error the debugger:

1. classifies it: a placeholder the specialist left in the rule, an ambiguous or
   unknown column, an unknown function, a syntax error, a value that does not
   convert, a division by zero, a text value longer than the target, an
   aggregate at the wrong grain, or a join problem;
2. finds the target columns responsible, from the names in the message, from the
   error's line number, or by running the failing step on smaller column sets;
3. applies the standard fix for that cause, or asks a model for one corrected
   expression when there is no standard fix; and
4. verifies the fix, first on the column alone and then on the whole query.

A column that still fails is left for the caller to hold back with the
diagnosis, so the other columns still compile and preview. Every repair is
returned as a receipt (cause, before, after, method) for the trace, the row and
the review.

The module never talks to Snowflake itself: the caller passes the compile,
render, probe and model functions, so the logic is testable without a session.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Protocol

from sqlglot import exp, parse_one

from app.agent_tools.sql_isolation import compile_error_summary

PLACEHOLDER = "placeholder"
AMBIGUOUS_COLUMN = "ambiguous_column"
INVALID_IDENTIFIER = "invalid_identifier"
UNDEFINED_DEPENDENCY = "undefined_dependency"
UNKNOWN_FUNCTION = "unknown_function"
SYNTAX = "syntax"
NUMERIC_CONVERSION = "numeric_conversion"
DATE_CONVERSION = "date_conversion"
STRING_TRUNCATION = "string_truncation"
DIVISION_BY_ZERO = "division_by_zero"
AGGREGATE_GRAIN = "aggregate_grain"
JOIN_STRUCTURAL = "join_structural"
UNKNOWN = "unknown"

DATA_ERRORS = {NUMERIC_CONVERSION, DATE_CONVERSION, STRING_TRUNCATION, DIVISION_BY_ZERO}

_ROOT_CAUSES = {
    PLACEHOLDER: "the rule contains a placeholder instead of a real value",
    AMBIGUOUS_COLUMN: "a column name exists in more than one joined source and was not qualified",
    INVALID_IDENTIFIER: "the rule names a column the source does not have",
    UNDEFINED_DEPENDENCY: "the rule reads a relation that is not in the source design",
    UNKNOWN_FUNCTION: "the rule calls a function Snowflake does not have",
    SYNTAX: "the rule is not valid Snowflake SQL",
    NUMERIC_CONVERSION: "some source values cannot be converted to a number",
    DATE_CONVERSION: "some source values cannot be converted to a date or timestamp",
    STRING_TRUNCATION: "some values are longer than the target column allows",
    DIVISION_BY_ZERO: "the rule divides by a value that can be zero",
    AGGREGATE_GRAIN: "the rule aggregates rows, but the mapping is at row grain",
    JOIN_STRUCTURAL: "the join plan itself is invalid",
    UNKNOWN: "Snowflake rejected the query",
}

_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (AMBIGUOUS_COLUMN, re.compile(r"ambiguous column name '([^']+)'", re.I)),
    (INVALID_IDENTIFIER, re.compile(r"invalid identifier '([^']+)'", re.I)),
    (UNDEFINED_DEPENDENCY, re.compile(r"undefined (?:relation or alias|sql alias)[^:]*:\s*([^\s(]+)", re.I)),
    (UNKNOWN_FUNCTION, re.compile(r"unknown\s+(?:user-defined\s+)?functions?\s+([A-Za-z_][\w$.]*)", re.I)),
    (NUMERIC_CONVERSION, re.compile(r"numeric value '([^']*)' is not recognized", re.I)),
    (DATE_CONVERSION, re.compile(
        r"(?:date|timestamp|time) '([^']*)' is not recognized|can't parse '([^']*)' as (?:date|timestamp|time)", re.I)),
    (STRING_TRUNCATION, re.compile(r"string '([^']*)' is too long", re.I)),
    (DIVISION_BY_ZERO, re.compile(r"division by zero", re.I)),
    (AGGREGATE_GRAIN, re.compile(
        r"is not a valid group by expression|must appear in the group by|nested aggregate|"
        r"aggregate functions? (?:cannot|are not allowed)", re.I)),
    (SYNTAX, re.compile(r"syntax error line (\d+) at position (\d+)(?: unexpected '([^']*)')?", re.I)),
    (JOIN_STRUCTURAL, re.compile(r"disconnected|join edge|driving relation|duplicate relation alias", re.I)),
]
_TARGET_IN_MESSAGE = re.compile(r"\(target:\s*([^)]+)\)", re.I)
_SYNTAX_POSITION = re.compile(r"syntax error line (\d+) at position (\d+)", re.I)
_ANGLE_PLACEHOLDER = re.compile(r"<\s*([A-Za-z_][A-Za-z0-9_ .:-]{0,60}?)\s*>")
_STRING_LITERAL = re.compile(r"('(?:''|[^'])*')")
_AGGREGATE_CALL = re.compile(
    r"\b(LISTAGG|ARRAY_AGG|OBJECT_AGG|COUNT|SUM|AVG|MIN|MAX|MEDIAN|STDDEV|VARIANCE|ANY_VALUE)\s*\(", re.I)
_OVER = re.compile(r"\bOVER\s*\(", re.I)
_CONVERSION_FUNCTIONS = ("NUMBER", "DECIMAL", "NUMERIC", "DOUBLE", "DATE", "TIME", "TIMESTAMP",
                         "TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "BOOLEAN")
_TO_FUNCTION = re.compile(
    r"(?<![A-Za-z0-9_$])TO_(" + "|".join(sorted(_CONVERSION_FUNCTIONS, key=len, reverse=True)) + r")\s*\(", re.I)
_CONVERTIBLE_TYPES = re.compile(r"^(NUMBER|DECIMAL|NUMERIC|INT|INTEGER|BIGINT|SMALLINT|TINYINT|BYTEINT|FLOAT|DOUBLE|"
                                r"REAL|DATE|TIME|TIMESTAMP|DATETIME|BOOLEAN)", re.I)
_VARCHAR_LENGTH = re.compile(r"^(?:VARCHAR|STRING|TEXT|CHAR|CHARACTER|NVARCHAR|NCHAR)\s*\(\s*(\d+)\s*\)", re.I)


def _norm(name: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(name or "").upper())


@dataclass
class Diagnosis:
    category: str
    targets: list[str] = field(default_factory=list)
    subject: str = ""
    message: str = ""

    @property
    def root_cause(self) -> str:
        return _ROOT_CAUSES.get(self.category, _ROOT_CAUSES[UNKNOWN])


@dataclass
class Repair:
    target_column: str
    category: str
    before: str | None
    after: str | None
    method: str
    explanation: str
    evidence: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "target_column": self.target_column,
            "root_cause": self.category,
            "before": self.before,
            "after": self.after,
            "method": self.method,
            "explanation": self.explanation,
            "evidence": self.evidence,
        }


@dataclass
class DebugContext:
    """What the debugger may use to fix a rule.

    ``relation_columns`` maps each qualifier a rule may use (a table FQN, a
    table name, a CTE reference prefix, an alias) to the columns it produces.
    ``placeholder_values`` maps a normalized project-value name to
    ``(sql_literal, raw_value)`` for values that are resolved, or ``None`` for
    values known but not yet supplied.
    """

    relation_columns: dict[str, set[str]] = field(default_factory=dict)
    placeholder_values: dict[str, tuple[str, str] | None] = field(default_factory=dict)
    target_types: dict[str, str] = field(default_factory=dict)


class Item(Protocol):
    target_column: str
    expression: str | None
    source_dependencies: list[str]

    def model_copy(self, *, update: dict[str, Any]) -> "Item": ...


@dataclass
class DebugOutcome:
    items: list[Any]
    compiled: Any = None
    error: BaseException | None = None
    repairs: list[Repair] = field(default_factory=list)
    held: dict[str, str] = field(default_factory=dict)
    diagnoses: list[Diagnosis] = field(default_factory=list)
    attempts: int = 0


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------

def classify(error: BaseException | str) -> Diagnosis:
    """Category and subject of a compile or execution error."""
    text = str(error)
    summary = compile_error_summary(error)
    for category, pattern in _PATTERNS:
        match = pattern.search(text)
        if match:
            subject = next((group for group in match.groups() if group), "") if match.groups() else ""
            if category in DATA_ERRORS:
                subject = ""  # never carry source values into traces or prompts
            diagnosis = Diagnosis(category=category, subject=subject.strip().strip('"'), message=summary)
            named = _TARGET_IN_MESSAGE.search(text)
            if named:
                diagnosis.targets = [named.group(1).strip()]
            return diagnosis
    return Diagnosis(category=UNKNOWN, message=summary)


def _outside_literals(expression: str) -> str:
    return _STRING_LITERAL.sub("''", expression or "")


def _references_bare(expression: str, name: str) -> bool:
    return bool(re.search(
        rf'(?<![A-Za-z0-9_$."])"?{re.escape(name)}"?(?![A-Za-z0-9_$]|\s*\()', _outside_literals(expression), re.I))


def _references(expression: str, name: str) -> bool:
    return bool(re.search(rf'(?<![A-Za-z0-9_$])"?{re.escape(name)}"?(?![A-Za-z0-9_$])',
                          _outside_literals(expression), re.I))


def locate_by_name(diagnosis: Diagnosis, items: Iterable[Any]) -> list[str]:
    """Targets whose rule uses the identifier or function the error names."""
    name = diagnosis.subject.split(".")[-1].strip('"')
    if not name:
        return []
    found = []
    for item in items:
        expression = item.expression or ""
        if diagnosis.category == AMBIGUOUS_COLUMN and _references_bare(expression, name):
            found.append(item.target_column)
        elif diagnosis.category == UNKNOWN_FUNCTION and re.search(
                rf"(?<![\w$.]){re.escape(name)}\s*\(", _outside_literals(expression), re.I):
            found.append(item.target_column)
        elif diagnosis.category in {INVALID_IDENTIFIER, UNDEFINED_DEPENDENCY} and (
                _references(expression, name) or any(
                    str(value).split(".")[-2 if diagnosis.category == UNDEFINED_DEPENDENCY else -1].strip('"').upper()
                    == name.upper() for value in item.source_dependencies if "." in str(value))):
            found.append(item.target_column)
    return found


def locate_by_line(diagnosis: Diagnosis, rendered_sql: str, targets: Iterable[str]) -> list[str]:
    """The target whose select item contains the error's line."""
    match = _SYNTAX_POSITION.search(diagnosis.message or "")
    if not match or not rendered_sql:
        return []
    line_number = int(match.group(1))
    lines = rendered_sql.split("\n")
    wanted = {str(target).upper(): target for target in targets}
    for line in lines[max(0, line_number - 1):]:
        found = re.search(r'\bAS\s+"?([A-Za-z_][A-Za-z0-9_$]*)"?\s*,?\s*$', line, re.I)
        if found and found.group(1).upper() in wanted:
            return [wanted[found.group(1).upper()]]
    return []


# ---------------------------------------------------------------------------
# Standard fixes
# ---------------------------------------------------------------------------

def placeholders_in(expression: str) -> list[str]:
    return [match.group(1).strip() for match in _ANGLE_PLACEHOLDER.finditer(expression or "")]


def replace_placeholders(expression: str, values: dict[str, tuple[str, str] | None]) -> tuple[str | None, list[str]]:
    """Substitute resolved project values for ``<NAME>`` placeholders.

    Inside a string literal the raw value is spliced into the literal; outside
    one, the value's SQL literal is used. Returns ``(expression, missing)``;
    ``expression`` is None when any placeholder has no resolved value.
    """
    missing: list[str] = []

    def value_for(name: str) -> tuple[str, str] | None:
        found = values.get(_norm(name))
        if found is None:
            missing.append(name)
        return found

    segments = _STRING_LITERAL.split(expression or "")
    rebuilt = []
    for index, segment in enumerate(segments):
        if index % 2:
            def in_literal(match: re.Match[str]) -> str:
                found = value_for(match.group(1))
                return found[1].replace("'", "''") if found else match.group(0)
            rebuilt.append(_ANGLE_PLACEHOLDER.sub(in_literal, segment))
        else:
            def outside(match: re.Match[str]) -> str:
                found = value_for(match.group(1))
                return found[0] if found else match.group(0)
            rebuilt.append(_ANGLE_PLACEHOLDER.sub(outside, segment))
    return (None, missing) if missing else ("".join(rebuilt), [])


def _owners(name: str, context: DebugContext, dependencies: Iterable[str]) -> list[str]:
    """Qualifiers that produce ``name``, preferring the row's own dependencies."""
    own = []
    for value in dependencies:
        qualifier, _, column = str(value).rpartition(".")
        if qualifier and column.strip('"').upper() == name.upper():
            own.append(qualifier)
    if own:
        return list(dict.fromkeys(own))
    return [qualifier for qualifier, columns in context.relation_columns.items()
            if name.upper() in {column.upper() for column in columns}]


def qualify_column(expression: str, name: str, qualifier: str) -> str:
    segments = _STRING_LITERAL.split(expression)
    pattern = re.compile(rf'(?<![A-Za-z0-9_$."])("?){re.escape(name)}\1(?![A-Za-z0-9_$]|\s*\()', re.I)
    return "".join(
        segment if index % 2 else pattern.sub(lambda m: f"{qualifier}.{m.group(0)}", segment)
        for index, segment in enumerate(segments)
    )


def requalify(expression: str, name: str, qualifier: str) -> str:
    """Point every ``<something>.name`` reference at ``qualifier``."""
    segments = _STRING_LITERAL.split(expression)
    pattern = re.compile(
        rf'(?<![A-Za-z0-9_$])(?:"?[A-Za-z_][A-Za-z0-9_$]*"?\s*\.\s*)+("?){re.escape(name)}\1(?![A-Za-z0-9_$])', re.I)
    return "".join(
        segment if index % 2 else pattern.sub(lambda m: f"{qualifier}.{name}", segment)
        for index, segment in enumerate(segments)
    )


def _closing_paren(text: str, start: int) -> int:
    depth, index, in_string = 0, start, False
    while index < len(text):
        char = text[index]
        if char == "'":
            in_string = not in_string
        elif not in_string:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
                if depth == 0:
                    return index
        index += 1
    return -1


def _first_argument_end(text: str, open_index: int, close_index: int) -> int:
    depth, in_string = 0, False
    for index in range(open_index + 1, close_index):
        char = text[index]
        if char == "'":
            in_string = not in_string
        elif not in_string:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                return index
    return close_index


def try_conversions(expression: str) -> str | None:
    """Make failing conversions return NULL instead of stopping the load.

    ``TO_NUMBER(x)`` becomes ``TRY_TO_NUMBER(TO_VARCHAR(x))`` and
    ``CAST(x AS NUMBER)`` / ``x::NUMBER`` become ``TRY_CAST(TO_VARCHAR(x) AS
    NUMBER)``: the ``TRY_`` forms accept text input only. Returns None when the
    rule has no explicit conversion to change.
    """
    text = expression
    changed = False
    position = 0
    while True:
        match = _TO_FUNCTION.search(text, position)
        if not match:
            break
        preceding = text[max(0, match.start() - 4):match.start()].upper()
        open_index = match.end() - 1
        close_index = _closing_paren(text, open_index)
        if preceding == "TRY_" or close_index < 0:
            position = match.end()
            continue
        argument_end = _first_argument_end(text, open_index, close_index)
        argument = text[open_index + 1:argument_end].strip()
        replacement = f"TRY_TO_{match.group(1).upper()}(TO_VARCHAR({argument})" + text[argument_end:close_index + 1]
        text = text[:match.start()] + replacement + text[close_index + 1:]
        position = match.start() + len(replacement)
        changed = True
    try:
        tree = parse_one(text, read="snowflake")
    except Exception:
        return text if changed else None
    found = False

    def to_try_cast(node: exp.Expression) -> exp.Expression:
        nonlocal found
        if (isinstance(node, exp.Cast) and not isinstance(node, exp.TryCast)
                and _CONVERTIBLE_TYPES.match(node.to.sql(dialect="snowflake"))):
            found = True
            return exp.TryCast(this=exp.func("TO_VARCHAR", node.this.copy()), to=node.to.copy(), requires_string=True)
        return node

    tree = tree.transform(to_try_cast)
    if found:
        return tree.sql(dialect="snowflake")
    return text if changed else None


def guard_divisors(expression: str) -> str | None:
    """Wrap each divisor in ``NULLIF(divisor, 0)``."""
    try:
        tree = parse_one(expression, read="snowflake")
    except Exception:
        return None
    divisions = [node for node in tree.find_all(exp.Div)
                 if not (isinstance(node.expression, exp.Nullif))]
    if not divisions:
        return None
    for node in divisions:
        node.set("expression", exp.Nullif(this=node.expression.copy(), expression=exp.Literal.number(0)))
    return tree.sql(dialect="snowflake")


def fit_length(expression: str, target_type: str | None) -> str | None:
    """Cut values to the target length instead of failing the load.

    A cast to a shorter text type fails on long values before any outer
    function runs, so such casts are rewritten to ``LEFT(TO_VARCHAR(x), n)``;
    otherwise the whole rule is wrapped in ``LEFT(…, n)``.
    """
    match = _VARCHAR_LENGTH.match(str(target_type or "").strip())
    try:
        tree = parse_one(expression, read="snowflake")
    except Exception:
        tree = None
    if tree is not None:
        found = False

        def to_left(node: exp.Expression) -> exp.Expression:
            nonlocal found
            if isinstance(node, exp.Cast):
                length = _VARCHAR_LENGTH.match(node.to.sql(dialect="snowflake"))
                if length:
                    found = True
                    return exp.func("LEFT", exp.func("TO_VARCHAR", node.this.copy()), exp.Literal.number(int(length.group(1))))
            return node

        rewritten = tree.transform(to_left)
        if found:
            return rewritten.sql(dialect="snowflake")
    if not match or re.match(r"^\s*LEFT\s*\(", expression, re.I):
        return None
    return f"LEFT({expression}, {int(match.group(1))})"


def standard_fix(diagnosis: Diagnosis, item: Any, context: DebugContext) -> tuple[str | None, str]:
    """The conventional fix for ``diagnosis`` on ``item``, with its explanation."""
    expression = item.expression or ""
    name = diagnosis.subject.split(".")[-1].strip('"')
    if diagnosis.category == AMBIGUOUS_COLUMN and name:
        owners = _owners(name, context, item.source_dependencies)
        if len(owners) == 1:
            return qualify_column(expression, name, owners[0]), f"Qualified {name} with {owners[0]}."
    if diagnosis.category == INVALID_IDENTIFIER and name:
        owners = _owners(name, context, [])
        if len(owners) == 1:
            qualified = re.search(rf'\.\s*"?{re.escape(name)}"?(?![A-Za-z0-9_$])', _outside_literals(expression), re.I)
            fixed = requalify(expression, name, owners[0]) if qualified else qualify_column(expression, name, owners[0])
            return fixed, f"{name} is produced by {owners[0]}; the rule now reads it there."
        near = sorted({
            (qualifier, column) for qualifier, columns in context.relation_columns.items()
            for column in columns if _norm(column) == _norm(name) and column.upper() != name.upper()
        })
        if len({column.upper() for _, column in near}) == 1 and len({q for q, _ in near}) == 1:
            qualifier, column = near[0]
            fixed = re.sub(rf'(?<![A-Za-z0-9_$])"?{re.escape(name)}"?(?![A-Za-z0-9_$])', column, expression, flags=re.I)
            return fixed, f"{name} does not exist; the source column is {column}."
    if diagnosis.category in {NUMERIC_CONVERSION, DATE_CONVERSION}:
        fixed = try_conversions(expression)
        if fixed:
            return fixed, "Values that do not convert now load as NULL instead of failing the whole load."
    if diagnosis.category == DIVISION_BY_ZERO:
        fixed = guard_divisors(expression)
        if fixed:
            return fixed, "A zero divisor now gives NULL instead of failing the load."
    if diagnosis.category == STRING_TRUNCATION:
        target_type = context.target_types.get(str(item.target_column).upper())
        fixed = fit_length(expression, target_type)
        if fixed:
            return fixed, f"Values are cut to the target length ({target_type}); confirm this is acceptable."
    if diagnosis.category == PLACEHOLDER:
        fixed, missing = replace_placeholders(expression, context.placeholder_values)
        if fixed is not None:
            return fixed, "Replaced the placeholder with the project's value."
    return None, ""


# ---------------------------------------------------------------------------
# The debugging loops
# ---------------------------------------------------------------------------

ModelFix = Callable[[Any, Diagnosis], tuple[str | None, str]]


class SqlDebugger:
    """Diagnose, fix and verify one mapping's column rules within a budget."""

    def __init__(
        self,
        *,
        context: DebugContext,
        compile_subset: Callable[[list[Any]], tuple[Any, BaseException | None]],
        render_subset: Callable[[list[Any]], str] | None = None,
        probe_subset: Callable[[list[Any]], BaseException | None] | None = None,
        model_fix: ModelFix | None = None,
        max_attempts: int = 12,
        max_model_repairs_per_column: int = 1,
        on_event: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> None:
        self._context = context
        self._compile = compile_subset
        self._render = render_subset
        self._probe = probe_subset
        self._model_fix = model_fix
        self._max_attempts = max(0, int(max_attempts))
        self._model_budget = max(0, int(max_model_repairs_per_column))
        self._model_used: dict[str, int] = {}
        self._on_event = on_event or (lambda _kind, _details: None)
        self.attempts = 0

    # -- lint --------------------------------------------------------------
    def lint(self, items: list[Any]) -> DebugOutcome:
        """Fix what is certain before any Snowflake call; hold back what needs a value.

        Only problems visible in the text are handled here: placeholders, and
        bare column names that more than one selected relation produces.
        """
        outcome = DebugOutcome(items=[])
        for item in items:
            expression = item.expression or ""
            names = placeholders_in(expression)
            if names:
                diagnosis = Diagnosis(PLACEHOLDER, [item.target_column], ", ".join(names))
                fixed, missing = replace_placeholders(expression, self._context.placeholder_values)
                outcome.diagnoses.append(diagnosis)
                if fixed is None:
                    outcome.held[item.target_column] = (
                        "The rule uses a placeholder for a project value that is not set: "
                        + ", ".join(f"<{name}>" for name in missing) + ".")
                    self._on_event("diagnosed", {"target_column": item.target_column, "category": PLACEHOLDER,
                                                 "root_cause": diagnosis.root_cause, "subject": diagnosis.subject})
                    continue
                outcome.repairs.append(Repair(item.target_column, PLACEHOLDER, expression, fixed, "standard",
                                              "Replaced the placeholder with the project's value."))
                item = item.model_copy(update={"expression": fixed})
                expression = fixed
            for name in self._ambiguous_names(expression):
                owners = _owners(name, self._context, item.source_dependencies)
                if len(owners) == 1:
                    fixed = qualify_column(expression, name, owners[0])
                    outcome.repairs.append(Repair(item.target_column, AMBIGUOUS_COLUMN, expression, fixed, "standard",
                                                  f"Qualified {name} with {owners[0]}."))
                    item = item.model_copy(update={"expression": fixed})
                    expression = fixed
            outcome.items.append(item)
        for repair in outcome.repairs:
            self._on_event("repaired", repair.as_dict())
        return outcome

    def _ambiguous_names(self, expression: str) -> list[str]:
        if not expression:
            return []
        try:
            tree = parse_one(expression, read="snowflake")
        except Exception:
            return []
        produced: dict[str, int] = {}
        for columns in self._context.relation_columns.values():
            for column in {value.upper() for value in columns}:
                produced[column] = produced.get(column, 0) + 1
        names = []
        for column in tree.find_all(exp.Column):
            if column.table:
                continue
            name = column.name
            if name and produced.get(name.upper(), 0) > 1 and name not in names:
                names.append(name)
        return names

    # -- compile -----------------------------------------------------------
    def repair_compile(self, items: list[Any], error: BaseException) -> DebugOutcome:
        """Repair column rules until the query compiles or no fix is left."""
        outcome = DebugOutcome(items=list(items), error=error)
        while outcome.error is not None and self.attempts < self._max_attempts:
            diagnosis = classify(outcome.error)
            if not diagnosis.targets:
                diagnosis.targets = locate_by_name(diagnosis, outcome.items)
            if not diagnosis.targets and diagnosis.category == SYNTAX and self._render is not None:
                try:
                    rendered = self._render(outcome.items)
                except Exception:  # noqa: BLE001 - rendering is best effort
                    rendered = ""
                diagnosis.targets = locate_by_line(diagnosis, rendered, [item.target_column for item in outcome.items])
            if not diagnosis.targets and diagnosis.category == AGGREGATE_GRAIN:
                diagnosis.targets = [item.target_column for item in outcome.items
                                     if _AGGREGATE_CALL.search(item.expression or "")
                                     and not _OVER.search(item.expression or "")]
            outcome.diagnoses.append(diagnosis)
            if not diagnosis.targets or diagnosis.category in {JOIN_STRUCTURAL, AGGREGATE_GRAIN}:
                break
            if not self._fix_targets(outcome, diagnosis, verify=self._verify_compiles):
                break
            self.attempts += 1
            outcome.compiled, outcome.error = self._compile(outcome.items)
        outcome.attempts = self.attempts
        return outcome

    def _verify_compiles(self, candidate: Any) -> BaseException | None:
        self.attempts += 1
        return self._compile([candidate])[1]

    # -- preview -----------------------------------------------------------
    def repair_preview(self, items: list[Any], error: BaseException) -> DebugOutcome:
        """Repair the rules that make the preview fail on real values.

        A data error names a value, not a column, so the failing columns are
        found by probing smaller column sets with the preview's own query.
        """
        outcome = DebugOutcome(items=list(items), error=error)
        if self._probe is None:
            return outcome
        while outcome.error is not None and self.attempts < self._max_attempts:
            diagnosis = classify(outcome.error)
            if not diagnosis.targets:
                diagnosis.targets = locate_by_name(diagnosis, outcome.items)
            if not diagnosis.targets:
                candidates = [item for item in outcome.items if (item.expression or "").strip()]
                diagnosis.targets = self._locate_by_probe(candidates)
            outcome.diagnoses.append(diagnosis)
            if not diagnosis.targets:
                break
            if not self._fix_targets(outcome, diagnosis, verify=self._verify_previews):
                break
            self.attempts += 1
            outcome.error = self._probe(outcome.items)
        outcome.attempts = self.attempts
        return outcome

    def _verify_previews(self, candidate: Any) -> BaseException | None:
        self.attempts += 1
        return self._probe([candidate]) if self._probe else None

    def _locate_by_probe(self, candidates: list[Any]) -> list[str]:
        failing: list[str] = []

        def search(group: list[Any]) -> None:
            if not group or self.attempts >= self._max_attempts:
                return
            self.attempts += 1
            if self._probe([*group]) is None:
                return
            if len(group) == 1:
                failing.append(group[0].target_column)
                return
            middle = len(group) // 2
            search(group[:middle])
            search(group[middle:])

        search(candidates)
        return failing

    # -- shared ------------------------------------------------------------
    def _fix_targets(self, outcome: DebugOutcome, diagnosis: Diagnosis, *, verify: Callable[[Any], BaseException | None]) -> bool:
        progressed = False
        by_target = {item.target_column: index for index, item in enumerate(outcome.items)}
        for target in diagnosis.targets:
            index = by_target.get(target)
            if index is None or self.attempts >= self._max_attempts:
                continue
            item = outcome.items[index]
            self._on_event("diagnosed", {"target_column": target, "category": diagnosis.category,
                                         "root_cause": diagnosis.root_cause, "subject": diagnosis.subject,
                                         "message": diagnosis.message})
            for method in ("standard", "model"):
                if method == "standard":
                    fixed, explanation = standard_fix(diagnosis, item, self._context)
                else:
                    if self._model_fix is None or self._model_used.get(target, 0) >= self._model_budget:
                        break
                    self._model_used[target] = self._model_used.get(target, 0) + 1
                    try:
                        fixed, explanation = self._model_fix(item, diagnosis)
                    except Exception:  # noqa: BLE001 - a failed model call leaves the column for review
                        fixed, explanation = None, ""
                if not fixed or fixed.strip() == (item.expression or "").strip():
                    continue
                candidate = item.model_copy(update={"expression": fixed, "rule": "Custom"})
                failure = verify(candidate)
                if failure is not None:
                    self._on_event("repair_rejected", {"target_column": target, "method": method,
                                                       "category": diagnosis.category,
                                                       "reason": compile_error_summary(failure)})
                    continue
                repair = Repair(target, diagnosis.category, item.expression, fixed, method, explanation,
                                {"error": diagnosis.message})
                outcome.repairs.append(repair)
                outcome.items[index] = candidate
                self._on_event("repaired", repair.as_dict())
                progressed = True
                break
        return progressed


def model_fix_prompt(item: Any, diagnosis: Diagnosis, *, target_type: str | None,
                     relation_columns: dict[str, set[str]], samples: dict[str, list[str]] | None = None) -> str:
    """The prompt for one corrected expression; the caller runs it as a structured completion."""
    relations = "\n".join(
        f"- {qualifier}: {', '.join(sorted(columns)[:80])}" for qualifier, columns in sorted(relation_columns.items())
    )
    sample_text = "\n".join(f"- {name}: {', '.join(values)}" for name, values in (samples or {}).items())
    return (
        "You repair one Snowflake SELECT-list expression for a data migration.\n"
        f"Target column: {item.target_column} ({target_type or 'unknown type'})\n"
        f"Current expression: {item.expression}\n"
        f"Snowflake error: {diagnosis.message}\n"
        f"Diagnosed cause: {diagnosis.root_cause}\n"
        f"Relations and their columns (qualify every column with one of these names):\n{relations}\n"
        + (f"Sample source values:\n{sample_text}\n" if sample_text else "")
        + "Return an expression that keeps the rule's intent and fixes only the cause. Use Snowflake built-in "
        "functions only; never invent functions, tables or columns; no subqueries, no aggregates without OVER, "
        "no placeholders. If the intent cannot be kept, return an empty expression."
    )


MODEL_FIX_SCHEMA = {
    "type": "json",
    "schema": {
        "type": "object",
        "properties": {
            "expression": {"type": "string"},
            "root_cause": {"type": "string"},
            "fix_explanation": {"type": "string"},
            "confidence": {"type": "number"},
        },
        "required": ["expression", "root_cause", "fix_explanation", "confidence"],
    },
}
