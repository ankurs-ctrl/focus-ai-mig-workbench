# V8 offline verification

## Final results

- **2,361 backend tests passed**, 153.69 seconds, with zero failures/skips in the final selected suite. Includes Auto-map unit/integration tests, SQL-upload tests, proxy tests, spec rendering and parallel UAT CI tests. This run used all final production changes and the new V8 regressions.
- **All 18 frontend harnesses passed** individually, including the previously broken `test-mapping-learning-origin.cjs` and `test-mapping-row-recovery.cjs`.
- **91 combined frontend checks passed** in one process, covering preservation, scope, acceptance/retries and the new V8 review probes. The shared preservation harness is counted once. This overlaps the individual harness runs; counts must not be added.
- TypeScript no-emit validation: passed with no diagnostics.
- CRLF-aware Git whitespace validation: passed.
- Packaging verifies the ZIP's entry names, Windows-compatible entry metadata, byte-for-byte source parity and every manifest SHA-256. The final ZIP hash is provided separately.

The four reported blockers were reproduced before correction. Added negative cases cover newer saved/unsaved edits, cancelled/edited-back edits, partial-plus-terminal replay, stale V7 review proofs, unresolved source/empty-constant/project-attribute reevaluations, existing unresolved queue items, mixed Apply-all siblings, nested delegation, conflicting root results, nested agent/errors, unknown tool fields, and failed continuation after a verified alternative. Matching duplicate inert result/meta locations and one bounded valid block-review correction are positive controls. Tests also reject fabricated alternatives and old preflight versions.

The real declared/locked `@noble/hashes` **1.8.0** dependency is installed for these checks. A new test compares its actual SHA-256 output against independent Node crypto vectors, including Unicode and large input. No in-memory crypto substitute was used. No package.json/package-lock.json changes were needed.

## Timing investigation

The same four durable preflight cases retained their original `finished.wait(45)` and `< 45` assertions. Local profiling before the atomic-identity guard found roughly 33–36 seconds in the two ten-blocked-target cases, with repeated full renders/factoring of a 250,000-character synthetic datatype. After the guard handled the over-limit atomic token, a focused run completed the four cases in **0.53, 0.59, 0.72 and 1.08 seconds**. The combined 20-test timing/review run passed in 7.80 seconds.

These measurements identify and remove repeated work in this local fixture. They do not establish environment-versus-code attribution for Coco's exact 50.28-second observation and do not certify production end-to-end latency. The early guard never applies to SQL, descriptions or semantic evidence; a regression confirms that large target descriptions still become mandatory exact blocks.

## Fixture provenance and limits

V8 fixtures are synthetic. Native runtime tests use the real application/archive/admission/transport/compiler code against fake HTTP/model and Snowflake boundaries. Existing Ft. Pitt tests use actual authored SQL with a limited synthetic catalog; they are not an exact archived job replay. The included replay helper replans scoped archive snapshots offline; it makes no model calls and does not perform Snowflake compilation.

No live UAT/browser/Snowflake/model-accuracy acceptance occurred here. Passing offline tests does not guarantee all targets have supported mappings or a 2–3 minute live run. Client Coco owns independent review, deployment and final acceptance. No shared agent definitions, secrets, migrations, pool/deadline limits or output limits were changed for V8. No local Docker build, commit, push, publication or target loading occurred.

## Windows AVD repeat commands

From the repository root with the existing locked Python/frontend dependencies installed:

```powershell
$env:PYTHONPATH = "services/sttm-builder"
$files = @(
  Get-ChildItem services/sttm-builder/tests/unit/core/test_automap*.py
  Get-ChildItem services/sttm-builder/tests/unit/core/test_sql_upload*.py
  Get-ChildItem services/sttm-builder/tests/test_automap*.py
  Get-Item services/sttm-builder/tests/unit/core/test_auto_mapping_proxy.py
  Get-Item services/sttm-builder/tests/unit/core/test_render_spcs_spec.py
  Get-Item services/sttm-builder/tests/unit/core/test_parallel_uat_ci.py
) | Sort-Object FullName -Unique | ForEach-Object FullName
python -m pytest -q --durations=8 $files
python -m pytest -q services/sttm-builder/tests/unit/core/test_automap_review_v8.py
node -e "require('./frontend/scripts/test-automap-scope.cjs'); require('./frontend/scripts/test-automap-remaining-v7.cjs'); require('./frontend/scripts/test-automap-review-v8.cjs');"
Get-ChildItem frontend/scripts/test-*.cjs | ForEach-Object {
  node $_.FullName
  if ($LASTEXITCODE -ne 0) { throw "Frontend harness failed: $($_.Name)" }
}
npx --prefix frontend tsc --project frontend/tsconfig.json --noEmit --incremental false
git -c core.whitespace=cr-at-eol diff --check
```

Review toolchain: Python 3.11, SQLGlot 30.12.0, existing frontend dependencies and PowerShell 7.5 for configuration-render tests. Local dependency symlinks, runner paths, caches, Python/readline workaround and raw test outputs are excluded from the ZIP.

Earlier exploratory V6 checks of the separate parallel-deployment environment-wrapper module encountered 16 macOS environment-restoration failures, reproduced on the unchanged V4 worktree. That separate module is outside the selected backend suite; deployment scripts were not rewritten to mask it. The selected spec-render and parallel UAT CI checks pass.
