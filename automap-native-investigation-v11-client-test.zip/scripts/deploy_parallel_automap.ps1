<#
.SYNOPSIS
Validate/render or deploy with an account-scoped, non-secret parallel JSON overlay.
.DESCRIPTION
ProfileFile (alias ParallelConfigFile) contains environment, scope, and settings.
EnvFile is the existing approved deployment env file; it is never rewritten.
ValidateOnly renders both specs in temporary storage, then removes them. It does
not bootstrap tools, invoke Docker, contact Snowflake, or verify live provisioning.
Without ValidateOnly, delegates to the unchanged DEV safe / UAT single-service
pipeline. Consumer OAuth write leases must be explicitly enabled in the JSON.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('DEV', 'UAT')][string]$Environment,
    [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][string]$EnvFile,
    [Parameter(Mandatory = $true)][ValidatePattern('^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$')][string]$ImageTag,
    [Parameter(Mandatory = $true)][Alias('ParallelConfigFile')][ValidateNotNullOrEmpty()][string]$ProfileFile,
    [switch]$ValidateOnly,
    [switch]$SkipBuild,
    [switch]$SkipLogin
)

$ErrorActionPreference = 'Stop'
$RootDir = Split-Path -Parent $PSScriptRoot
$DeployerName = if ($Environment -eq 'DEV') { 'deploy_spcs_client_snow_safe.ps1' } else { 'deploy_spcs_client_snow_single_service.ps1' }
$Deployer = Join-Path $PSScriptRoot $DeployerName
$RenderScript = Join-Path $PSScriptRoot 'render_spcs_spec.py'
$BeforeEnvironment = @{}
foreach ($entry in [System.Environment]::GetEnvironmentVariables('Process').GetEnumerator()) {
    $BeforeEnvironment[$entry.Key] = $entry.Value
}
$TemporaryDirectory = $null

function Get-ConfigurationSlice {
    param($Statements, [string]$Start, [string]$End)
    $starts = @($Statements | Where-Object { $_.Extent.Text.StartsWith($Start) })
    $ends = @($Statements | Where-Object { $_.Extent.Text.StartsWith($End) })
    if ($starts.Count -ne 1 -or $ends.Count -ne 1 -or $starts[0].Extent.StartOffset -ge $ends[0].Extent.StartOffset) {
        throw 'Protected deployer preparation layout changed; review required.'
    }
    $selected = @($Statements | Where-Object {
        $_.Extent.StartOffset -ge $starts[0].Extent.StartOffset -and $_.Extent.StartOffset -lt $ends[0].Extent.StartOffset
    })
    # Reuse only the reviewed pure configuration preparation, not the deployment.
    # Fail closed if an upstream change adds bootstrap, Docker, SQL or other I/O.
    $allowedCommands = @('Join-Path', 'Test-Path', 'Get-FileHash', 'Convert-ToDnsLabel')
    foreach ($statement in $selected) {
        foreach ($command in $statement.FindAll({ param($node) $node -is [System.Management.Automation.Language.CommandAst] }, $true)) {
            $isCrmEnvironmentAssignment = $command.Extent.Text -ceq 'Set-Item -Path "Env:$name" -Value $cfg[$name]'
            if ($command.GetCommandName() -notin $allowedCommands -and -not $isCrmEnvironmentAssignment) {
                throw 'Protected deployer preparation contains an unapproved command; review required.'
            }
        }
    }
    return [scriptblock]::Create(($selected | ForEach-Object { $_.Extent.Text }) -join "`n")
}

try {
    $EnvFile = (Resolve-Path -LiteralPath $EnvFile).ProviderPath
    $ProfileFile = (Resolve-Path -LiteralPath $ProfileFile).ProviderPath
    if (-not (Test-Path -LiteralPath $EnvFile -PathType Leaf) -or -not (Test-Path -LiteralPath $ProfileFile -PathType Leaf)) {
        throw 'EnvFile and ProfileFile must be existing files.'
    }
    $PythonExe = Join-Path $RootDir '.client-tools-venv/Scripts/python.exe'
    if (-not (Test-Path -LiteralPath $PythonExe)) {
        $PythonExe = (Get-Command python -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
    }
    $parseErrors = $null
    $tokens = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($Deployer, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw 'Protected deployer could not be parsed.' }
    $statements = @($ast.EndBlock.Statements)
    # Import only these existing helper definitions. Never dot-source a deployer:
    # its top-level bootstrap and deployment commands have external side effects.
    foreach ($name in @('Import-ClientEnv', 'Convert-ToDnsLabel')) {
        $helper = @($statements | Where-Object {
            $_ -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $_.Name -eq $name
        })
        if ($helper.Count -ne 1) { throw 'Protected deployment helper is missing or ambiguous.' }
        . ([scriptblock]::Create($helper[0].Extent.Text))
    }
    $cfg = Import-ClientEnv -Path $EnvFile
    $deployAutomap = $cfg.ContainsKey('AUTO_MAPPING_SERVICE_NAME') -and -not [string]::IsNullOrWhiteSpace($cfg['AUTO_MAPPING_SERVICE_NAME'])
    # Do not inherit rollout flags or unrelated render overrides from the shell.
    foreach ($key in @([System.Environment]::GetEnvironmentVariables('Process').Keys)) {
        if ($key -match '^(AUTOMAP_|AUTO_MAPPING_|AUTO_MAP_|SNOWFLAKE_WRITE_LEASE_POOL_V1$|PUBLICATION_RECOVERY_)') {
            Remove-Item -LiteralPath ('Env:' + $key) -ErrorAction SilentlyContinue
        }
    }
    $templates = @('webapp', 'automap-worker') | ForEach-Object {
        Join-Path $RootDir "infra/snowflake/service-specs/$_.yaml.tmpl"
    }
    foreach ($template in $templates) {
        $text = [System.IO.File]::ReadAllText($template)
        foreach ($match in [regex]::Matches($text, '\$\{([A-Z][A-Z0-9_]*)\}')) {
            $key = $match.Groups[1].Value
            Remove-Item -LiteralPath ('Env:' + $key) -ErrorAction SilentlyContinue
            if ($cfg.ContainsKey($key)) {
                [System.Environment]::SetEnvironmentVariable($key, $cfg[$key], 'Process')
            }
        }
    }
    foreach ($key in @('SNOWFLAKE_ACCOUNT', 'SNOWFLAKE_CONNECTION', 'SNOWFLAKE_DATABASE', 'SNOWFLAKE_SCHEMA', 'SNOWFLAKE_ROLE', 'SNOWFLAKE_REGISTRY_HOST')) {
        [System.Environment]::SetEnvironmentVariable($key, $cfg[$key], 'Process')
    }
    $env:AUTOMAP_DEPLOY_PROFILE_FILE = $ProfileFile
    $env:AUTOMAP_DEPLOY_ENVIRONMENT = $Environment
    & $PythonExe $RenderScript --validate-parallel-profile
    if ($LASTEXITCODE -ne 0) { throw 'Parallel profile validation failed; nothing deployed.' }

    if ($Environment -eq 'DEV') {
        . (Get-ConfigurationSlice $statements '$appName =' 'Invoke-Checked -Description "Checking Docker daemon"')
        . (Get-ConfigurationSlice $statements '$env:SNOWFLAKE_DATABASE_LOWER =' 'if (-not $SkipBuild)')
        . (Get-ConfigurationSlice $statements '$env:APP_NAME =' 'New-Item -ItemType Directory')
    } else {
        . (Get-ConfigurationSlice $statements '$appName =' 'if (-not (Get-Command docker')
        . (Get-ConfigurationSlice $statements '$env:SNOWFLAKE_DATABASE_LOWER =' 'function Build-AndPushImage')
    }
    $TemporaryDirectory = Join-Path ([System.IO.Path]::GetTempPath()) ('automap-render-' + [guid]::NewGuid().ToString('N'))
    [System.IO.Directory]::CreateDirectory($TemporaryDirectory) | Out-Null
    foreach ($template in $templates) {
        $output = Join-Path $TemporaryDirectory ([System.IO.Path]::GetFileNameWithoutExtension($template))
        & $PythonExe $RenderScript --template $template --output $output
        if ($LASTEXITCODE -ne 0) { throw 'Parallel service spec validation failed; nothing deployed.' }
    }
    Write-Host 'Parallel configuration validated; webapp and worker specs rendered. Live provisioning was not checked.'
    if (-not $ValidateOnly) {
        # Keep the original EnvFile and protected deployment entry point intact.
        & $Deployer -EnvFile $EnvFile -ImageTag $ImageTag -SkipBuild:$SkipBuild -SkipLogin:$SkipLogin
        if (-not $?) { throw 'Protected deployment failed.' }
    }
} finally {
    try {
        if ($TemporaryDirectory -and (Test-Path -LiteralPath $TemporaryDirectory)) {
            Remove-Item -LiteralPath $TemporaryDirectory -Recurse -Force
        }
    } finally {
        foreach ($key in @([System.Environment]::GetEnvironmentVariables('Process').Keys)) {
            if (-not $BeforeEnvironment.ContainsKey($key)) {
                Remove-Item -LiteralPath ('Env:' + $key) -ErrorAction SilentlyContinue
            }
        }
        $CurrentEnvironment = [System.Environment]::GetEnvironmentVariables('Process')
        foreach ($key in $BeforeEnvironment.Keys) {
            # Windows PowerShell 5.1 removes variables assigned an empty string.
            # Preserve untouched blanks; use the OS API to restore changed blanks.
            if (-not $CurrentEnvironment.Contains($key) -or $CurrentEnvironment[$key] -cne $BeforeEnvironment[$key]) {
                if ($BeforeEnvironment[$key] -ceq '' -and $env:OS -eq 'Windows_NT') {
                    if (-not ('AutomapDeployment.NativeEnvironment' -as [type])) {
                        Add-Type -TypeDefinition @'
namespace AutomapDeployment {
    public static class NativeEnvironment {
        [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode, SetLastError = true)]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        public static extern bool SetEnvironmentVariable(string name, string value);
    }
}
'@
                    }
                    if (-not [AutomapDeployment.NativeEnvironment]::SetEnvironmentVariable($key, '')) {
                        throw 'Unable to restore an empty process environment variable.'
                    }
                } else {
                    [System.Environment]::SetEnvironmentVariable($key, $BeforeEnvironment[$key], 'Process')
                }
            }
        }
    }
}
