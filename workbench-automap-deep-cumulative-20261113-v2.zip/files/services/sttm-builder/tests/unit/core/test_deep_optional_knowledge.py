from types import SimpleNamespace

import pytest

from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.core.exceptions import SnowflakeQueryError


def handler(error):
    def unavailable(*args):
        raise error
    value = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object(),
                                      rag_search=SimpleNamespace(search=unavailable))
    return value


def test_unavailable_search_is_explicit_without_discarding_verified_contracts():
    result = handler(SnowflakeQueryError("Search service unavailable")).search_workbench_rag({}, "customer mappings")
    assert result.status == "failed"
    assert result.error_code == "knowledge_search_unavailable"
    assert result.data == {"hits": []}
    assert result.warnings == ["knowledge_search_unavailable"]


def test_authorization_failure_is_not_reclassified_as_optional_search():
    with pytest.raises(PermissionError):
        handler(PermissionError("Denied role")).search_workbench_rag({}, "customer mappings")
