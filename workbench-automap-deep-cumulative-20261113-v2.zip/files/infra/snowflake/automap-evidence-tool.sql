-- Runtime contexts are registered by the backend, not by model-supplied JSON.
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.TBL_AUTOMAP_TOOL_CONTEXT (
 CONTEXT_HANDLE VARCHAR NOT NULL, OWNER_USER VARCHAR NOT NULL, OWNER_ROLE VARCHAR NOT NULL,
 ACCOUNT_NAMESPACE VARCHAR NOT NULL, ACCESS_SCOPE VARCHAR NOT NULL, JOB_ID VARCHAR NOT NULL,
 BATCH_ID VARCHAR NOT NULL, STAGE VARCHAR NOT NULL, CONTEXT_BODY VARIANT NOT NULL,
 EXPIRES_AT TIMESTAMP_LTZ NOT NULL, MAX_CHARS NUMBER NOT NULL, MAX_BYTES NUMBER NOT NULL,
 CALL_COUNT NUMBER DEFAULT 0 NOT NULL, RETURNED_CHARS NUMBER DEFAULT 0 NOT NULL,
 RETURNED_BYTES NUMBER DEFAULT 0 NOT NULL, RETURNED_IDS ARRAY DEFAULT ARRAY_CONSTRUCT(),
 CREATED_AT TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_AUTOMAP_READ_EVIDENCE(CONTEXT_HANDLE VARCHAR, REQUEST_JSON VARCHAR)
RETURNS VARCHAR
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'read_evidence'
EXECUTE AS CALLER
AS $$
import json
import re

TABLE = '__STTM_METADATA_NAMESPACE__.TBL_AUTOMAP_TOOL_CONTEXT'

def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def select_records(body, request, max_chars, max_bytes):
    if type(request) is not dict or set(request) - {'targets','record_ids','kind','cursor'}:
        raise ValueError('Invalid evidence request')
    targets = request.get('targets', [])
    identities = request.get('record_ids', [])
    if (type(targets) is not list or not 1 <= len(targets) <= 8
            or any(type(t) is not str or t not in body['targets'] for t in targets)
            or type(identities) is not list or len(identities) > 16
            or any(type(i) is not str for i in identities)):
        raise ValueError('Evidence outside target scope')
    kind = request.get('kind')
    if kind not in (None, 'semantic', 'fir', 'correction', 'dependency'):
        raise ValueError('Invalid evidence kind')
    records = [record for record in body['records'] if set(targets).intersection(record['targets'])
               and (not identities or record['record_id'] in identities)
               and (kind is None or record['kind'] == kind)]
    allowed = {record['record_id'] for record in records}
    if set(identities) - allowed:
        raise ValueError('Unknown evidence identity')
    cursor = request.get('cursor', 0)
    if type(cursor) is not int or not 0 <= cursor <= len(records):
        raise ValueError('Invalid evidence cursor')
    result = {'status':'complete', 'records':[], 'deferred_ids':[], 'next_cursor':None,
              'coverage_exhaustive':True}
    for index, record in enumerate(records[cursor:], cursor):
        trial = {**result, 'records':result['records'] + [record]}
        text = encoded(trial)
        if len(text) > max_chars or len(text.encode('utf-8')) > max_bytes:
            result.update(status='deferred', coverage_exhaustive=False, next_cursor=index,
                          deferred_ids=[record['record_id']])
            break
        result = trial
    text = encoded(result)
    if len(text) > max_chars or len(text.encode('utf-8')) > max_bytes:
        return {'status':'budget_exhausted', 'records':[], 'coverage_exhaustive':False}
    return result

def read_evidence(session, context_handle, request_json):
    if not re.fullmatch('[0-9a-f]{32}', context_handle or '') or type(request_json) is not str or len(request_json.encode('utf-8')) > 8192:
        return encoded({'status':'invalid_request','records':[]})
    active = False
    try:
        request = json.loads(request_json)
        session.sql('BEGIN TRANSACTION').collect()
        active = True
        # Updating first serializes simultaneous tool calls for this exact context.
        updated = session.sql(f'''UPDATE {TABLE} SET CALL_COUNT=CALL_COUNT+1
          WHERE CONTEXT_HANDLE=? AND OWNER_USER=CURRENT_USER() AND OWNER_ROLE=CURRENT_ROLE()
            AND ACCOUNT_NAMESPACE=CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME()
            AND EXPIRES_AT>CURRENT_TIMESTAMP() AND CALL_COUNT<2
            AND RETURNED_CHARS<MAX_CHARS AND RETURNED_BYTES<MAX_BYTES''', params=[context_handle]).collect()
        if len(updated) != 1 or dict(updated[0].as_dict()).get('number of rows updated') != 1:
            session.sql('ROLLBACK').collect();active=False
            return encoded({'status':'unavailable_or_exhausted','records':[]})
        rows = session.sql(f'''SELECT CONTEXT_BODY, MAX_CHARS-RETURNED_CHARS AS REMAINING_CHARS,
            MAX_BYTES-RETURNED_BYTES AS REMAINING_BYTES FROM {TABLE}
            WHERE CONTEXT_HANDLE=? AND OWNER_USER=CURRENT_USER() AND OWNER_ROLE=CURRENT_ROLE()
              AND ACCOUNT_NAMESPACE=CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME()''', params=[context_handle]).collect()
        if len(rows) != 1:
            raise ValueError('Invalid context inventory')
        row = rows[0].as_dict();body = row['CONTEXT_BODY']
        if isinstance(body, str):body=json.loads(body)
        result = select_records(body, request, int(row['REMAINING_CHARS']), int(row['REMAINING_BYTES']))
        text = encoded(result)
        session.sql(f'''UPDATE {TABLE} SET RETURNED_CHARS=RETURNED_CHARS+?,
            RETURNED_BYTES=RETURNED_BYTES+?, RETURNED_IDS=ARRAY_DISTINCT(ARRAY_CAT(RETURNED_IDS, PARSE_JSON(?)))
            WHERE CONTEXT_HANDLE=? AND OWNER_USER=CURRENT_USER() AND OWNER_ROLE=CURRENT_ROLE()''',
            params=[len(text),len(text.encode('utf-8')),encoded([r['record_id'] for r in result.get('records',[])]),context_handle]).collect()
        session.sql('COMMIT').collect();active=False
        return text
    except Exception:
        if active:
            try:session.sql('ROLLBACK').collect()
            except Exception:pass
        # Never return database error text, credentials or unrestricted bodies.
        return encoded({'status':'evidence_unavailable','records':[], 'coverage_exhaustive':False})
$$;
