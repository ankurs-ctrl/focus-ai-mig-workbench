"""Notifications router — REST API for FIR user notifications.

Provides endpoints for:
- Fetching pending notifications (for initial page load / reconnection)
- Getting notification history for a project
- Marking notifications as seen
"""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Query

from ..core.notification_scorer import score_notifications

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/notifications", tags=["Notifications"])


def _get_session():
    from ..core.snowflake import get_snowflake_client
    return get_snowflake_client().session


@router.get("/pending")
async def get_pending_notifications(
    project_id: str | None = Query(None, description="Filter by project"),
    limit: int = Query(5, ge=1, le=20),
):
    """Get pending user notifications, scored and ranked.

    Returns notifications from TBL_FIR_AGENT_RECOMMENDATIONS where
    TARGET_AGENT = 'APP_USER_NOTIFICATION' and STATUS = 'active'.
    """
    try:
        session = _get_session()
    except Exception as exc:
        logger.warning("Notifications endpoint: Snowflake session unavailable: %s", exc)
        return {"notifications": [], "total": 0}

    try:
        rows = session.sql("""
            SELECT
                AGENT_RECOMMENDATION_ID,
                FIR_RECORD_ID,
                RECOMMENDATION_TYPE,
                RECOMMENDATION_PRIORITY,
                AGENT_PAYLOAD,
                AGENT_NOTES,
                DISPLAY_MESSAGE,
                DISPLAY_OPTIONS,
                NOTIFICATION_LAYER,
                CONFIDENCE,
                APPLICABLE_PROJECTS,
                APPLICABLE_TABLES,
                CREATED_AT
            FROM TBL_FIR_AGENT_RECOMMENDATIONS
            WHERE TARGET_AGENT = 'APP_USER_NOTIFICATION'
              AND STATUS = 'active'
            ORDER BY CREATED_AT DESC
            LIMIT ?
        """, [limit * 3]).collect()
    except Exception as exc:
        logger.warning("Notifications endpoint: query failed: %s", exc)
        return {"notifications": [], "total": 0}

    if not rows:
        return {"notifications": [], "total": 0}

    notifications = []
    for row in rows:
        row_dict = row.as_dict() if hasattr(row, "as_dict") else row
        created_at = row_dict.get("CREATED_AT")

        options = row_dict.get("DISPLAY_OPTIONS")
        if isinstance(options, str):
            try:
                options = json.loads(options)
            except (json.JSONDecodeError, TypeError):
                options = None

        applicable_projects = row_dict.get("APPLICABLE_PROJECTS")
        if isinstance(applicable_projects, str):
            try:
                applicable_projects = json.loads(applicable_projects)
            except (json.JSONDecodeError, TypeError):
                applicable_projects = None

        notifications.append({
            "recommendation_id": row_dict.get("AGENT_RECOMMENDATION_ID"),
            "fir_record_id": row_dict.get("FIR_RECORD_ID"),
            "recommendation_type": row_dict.get("RECOMMENDATION_TYPE"),
            "recommendation_priority": row_dict.get("RECOMMENDATION_PRIORITY", 50),
            "confidence": (row_dict.get("CONFIDENCE") or 0.5) * 100,
            "display_message": row_dict.get("DISPLAY_MESSAGE") or row_dict.get("AGENT_NOTES") or "",
            "display_options": options,
            "notification_layer": row_dict.get("NOTIFICATION_LAYER"),
            "applicable_projects": applicable_projects,
            "agent_notes": row_dict.get("AGENT_NOTES"),
            "created_at": created_at.timestamp() if hasattr(created_at, "timestamp") else None,
        })

    scored = score_notifications(
        notifications,
        active_project_id=project_id,
        max_notifications=limit,
    )

    return {
        "notifications": [
            {
                "id": n["recommendation_id"],
                "type": n["recommendation_type"],
                "priority": n["recommendation_priority"],
                "confidence": n["confidence"],
                "message": n["display_message"],
                "options": n["display_options"],
                "layer": n["notification_layer"],
                "score": n["_score"],
                "created_at": n["created_at"],
            }
            for n in scored
        ],
        "total": len(notifications),
    }
