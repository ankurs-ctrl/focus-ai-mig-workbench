const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),ts=require('typescript'),Module=require('module');
const file=path.resolve(__dirname,'../middleware.ts'),m=new Module(file,module);m.require=()=>({NextResponse:{next:()=>({next:true}),redirect:url=>({redirect:url.pathname})}});m._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,file);
function request(pathname,cookie){const url={pathname,hostname:'deployed.example',clone(){return {...this}}};return {nextUrl:url,cookies:{get:()=>cookie?{value:'expired'}:undefined}};}
assert.ok(m.exports.middleware(request('/home',true)).next,'expired cookie cannot hide sign-in');assert.equal(m.exports.middleware(request('/dashboard',false)).redirect,'/home');assert.ok(m.exports.middleware(request('/api/v1/auth/clear-session',true)).next);
assert.equal(m.exports.middleware(request('/',true)).redirect,'/dashboard','session-bearing entry URL goes to dashboard for validation');
assert.equal(m.exports.middleware(request('/',false)).redirect,'/home','missing session goes to sign-in');
const gateFile=path.resolve(__dirname,'../src/features/layout/session-gate.tsx'),ast=ts.createSourceFile(gateFile,fs.readFileSync(gateFile,'utf8'),ts.ScriptTarget.Latest,true);let effect;
function scan(n){if(ts.isCallExpression(n)&&n.expression.getText(ast)==='useEffect')effect=n.arguments[0].getText(ast);ts.forEachChild(n,scan)}scan(ast);
class AppError extends Error{constructor(status){super();this.payload={statusCode:status}}}
async function probe(status,clearFails=false,backgroundStatus){const events=[];let listener;const c={onSessionFailure:fn=>{listener=fn;return ()=>{}},authService:{getSession:()=>backgroundStatus===undefined?Promise.reject(new AppError(status)):Promise.resolve({user_id:1})},setStatus:s=>events.push(s),isNotSignedIn:e=>e.payload.statusCode===401,clearBrowserWorkbenchSession:()=>events.push('local-clear'),fetch:async()=>{events.push('cookie-clear');if(clearFails)throw Error('offline')},AbortSignal:{timeout:()=>undefined},window:{location:{replace:path=>events.push(path)}},AppError};
const n=new Module(gateFile,module);n._compile(ts.transpileModule(`module.exports=c=>{const {${Object.keys(c).join(',')}}=c;return (${effect})();}`,{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,gateFile);n.exports(c);for(let i=0;i<15;i++)await Promise.resolve();if(backgroundStatus!==undefined){listener(new AppError(backgroundStatus));for(let i=0;i<15;i++)await Promise.resolve();}return events;}
async function homeProbe(valid){
 const homeFile=path.resolve(__dirname,'../src/app/home/page.tsx');
 const homeAst=ts.createSourceFile(homeFile,fs.readFileSync(homeFile,'utf8'),ts.ScriptTarget.Latest,true);let homeEffect;
 function find(n){if(ts.isCallExpression(n)&&n.expression.getText(homeAst)==='useEffect')homeEffect=n.arguments[0].getText(homeAst);ts.forEachChild(n,find)}find(homeAst);
 const events=[];const c={authService:{getSession:(...args)=>{assert.equal(args.length,0,'home must reuse shared cache without forcing another check');return valid?Promise.resolve({user_id:1}):Promise.reject(new AppError(401))}},router:{replace:path=>events.push(path)},setCheckingSession:value=>events.push(value)};
 const n=new Module(homeFile,module);n._compile(ts.transpileModule(`module.exports=c=>{const {${Object.keys(c).join(',')}}=c;return (${homeEffect})();}`,{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,homeFile);n.exports(c);
 for(let i=0;i<15;i++)await Promise.resolve();return events;
}
(async()=>{for(const fails of [false,true]){const events=await probe(401,fails);assert.ok(events.indexOf('cookie-clear')<events.indexOf('/home'));}assert.deepEqual(await probe(403),['denied']);assert.deepEqual(await probe(503),['unavailable']);assert.deepEqual(await probe(200,false,401),['ready','signed-out','local-clear','cookie-clear','/home']);assert.deepEqual(await probe(200,false,403),['ready','denied']);assert.deepEqual(await homeProbe(true),['/dashboard']);assert.deepEqual(await homeProbe(false),[false]);console.log('Session redirect: valid session goes to dashboard; expired cookie, backend clearing, offline clearing, permissions and service failures pass.');})().catch(e=>{console.error(e);process.exitCode=1});
// The app shell must never be replaced by the initial token-check screen.
const gateSource=fs.readFileSync(gateFile,'utf8');
assert.doesNotMatch(gateSource,/Checking your session|Redirecting to sign in|AiaCircularProgress/);
assert.match(gateSource,/status === "checking" \|\| status === "signed-out"\) return null/);
const shellSource=fs.readFileSync(path.resolve(__dirname,'../src/app/workspace-shell.tsx'),'utf8');
assert.match(shellSource,/<AppShellGate>\s*\{showHeader \? <SessionGate>\{children\}<\/SessionGate> : children\}/);
assert.doesNotMatch(shellSource,/<SessionGate>\{shell\}<\/SessionGate>/);
