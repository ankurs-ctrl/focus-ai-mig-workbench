"""Offline admission replan from a scoped exact snapshot export; no model/SQL calls.

The export may be archive BODY JSON (scope/generation/value) or its decoded
value. Outputs contain identifiers/counts/sizes only, never semantic or SQL bodies.
Historical ledgers are reset deliberately to measure a fresh preflight. This is
NOT a replay of provider reasoning or Snowflake validation.
"""
import argparse
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'services/sttm-builder'))


def decode_snapshot(value):
    if value is None or type(value) in (str, bool, int, float):
        return value
    if type(value) is not dict or set(value) != {'type', 'items'} or type(value['items']) is not list:
        raise ValueError('Invalid tagged exact snapshot')
    kind, items = value['type'], value['items']
    if kind == 'dict':
        result = {}
        for pair in items:
            if type(pair) is not list or len(pair) != 2:
                raise ValueError('Invalid tagged dictionary')
            key, item = map(decode_snapshot, pair)
            if key in result:
                raise ValueError('Duplicate tagged dictionary key')
            result[key] = item
        return result
    constructors = {'list': list, 'tuple': tuple, 'set': set, 'frozenset': frozenset}
    if kind not in constructors:
        raise ValueError('Unsupported exact snapshot tag')
    return constructors[kind](decode_snapshot(item) for item in items)


def replay(body, *, chars=180000, size=180000, seconds=120, operations=512):
    from app.core.automap_batch import _FastAutoMapContext
    from app.core.automap_fast_context import FastContextPlan, validate_derived_output_contracts
    from app.core.automap_exact_reads import read_operations, initial_operations
    from app.core.automap_input_budget import wire_text
    from app.core.automap_retrieval import digest
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    value = body.get('value', body)
    if value.get('protocol') != 'automap_exact_snapshot_v1':
        raise ValueError('Expected a scoped exact Auto-map snapshot')
    state = decode_snapshot(value['state'])
    if not isinstance(state, dict) or state.get('snapshot_hash') != digest(state.get('original')):
        raise ValueError('Snapshot identity does not match its frozen request')
    store = _FastAutoMapContext.__new__(_FastAutoMapContext)
    vars(store).update(state)
    store.reads, store.cursors, store.pages_read = set(), {}, {}
    original = store.original
    req = STTMBuilderEnvelopeRequest.model_validate({'operation': 'sttm.auto_map',
        'data': original.get('data', {}), 'context': original.get('context', {})})
    proofs = validate_derived_output_contracts(req, None)
    deadline = time.monotonic() + seconds
    plan = FastContextPlan(store, max_chars=chars, max_bytes=size, validated_derived=proofs, deadline=deadline)
    settings = SimpleNamespace(agent_outbound_message_max_bytes=size, automap_context_max_operations=operations)
    results, events = [], []
    count = read_operations(store, initial_operations(store, plan), settings=settings, results=results,
        events=events, remaining=lambda: deadline-time.monotonic())
    text = wire_text(plan.messages(results))
    return {'mode': 'offline_replan_from_exact_snapshot', 'snapshot_hash': store.snapshot_hash,
        'historical_read_ledger_reset': True, 'snowflake_validation': 'not_performed', 'model_calls': 0,
        'chars': len(text), 'bytes': len(text.encode('utf-8')), 'exact_read_operations': count,
        'targets': list(store.targets), 'inventory_columns': {key: len(columns) for key, columns in store.inventory.items()},
        'admitted_bindings': [item.__dict__ for item in plan.binding_admissions()],
        'source_admission': plan.admission_manifest(), 'packing_attempts': plan.admission_events}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--max-chars', type=int, default=180000)
    parser.add_argument('--max-bytes', type=int, default=180000)
    args = parser.parse_args()
    result = replay(json.loads(args.snapshot.read_text(encoding='utf-8')),
                    chars=args.max_chars, size=args.max_bytes)
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('Offline admission manifest written; no Snowflake, browser or model acceptance performed.')


if __name__ == '__main__':
    main()
