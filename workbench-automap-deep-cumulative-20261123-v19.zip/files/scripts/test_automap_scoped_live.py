"""Non-publishing isolated retrieval acceptance against the existing mapping agent.

Read one existing registry asset; never write mappings, jobs, bundles or specs.
The test uses application authentication/configuration, not a privilege workaround.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/sttm-builder"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-file", required=True)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--live-search", action="store_true")
    parser.add_argument("--targets", type=int, default=1, choices=range(1, 38))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    from app.core.config import Settings
    from app.core.snowflake import SnowflakeClient
    from app.core.snowflake_agent import SnowflakeAgentClient
    from app.core.sttm_builder import STTMBuilderService
    from app.core.automap_retrieval import AutoMapContext, encoded
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
    from app.guardrails.config.loader import load_config

    settings = Settings(_env_file=args.env_file, APP_ENV="local", AUTOMAP_CONTEXT_RETRIEVAL_V1=True)
    client = SnowflakeClient(settings=settings)
    table = {"database": "FFP_HDP_DLAB_DB_DEV", "schema": "SCH_TRANSFORM_SOURCE", "table": "ACCOUNT"}
    fqn = ".".join(table.values())
    row = client.session.sql(
        "SELECT SEMANTIC_VIEW FROM FFP_HDP_DLAB_DB_DEV.SCH_STTM_MCP.LATEST_TABLE_REGISTRY_V WHERE FQN = ? LIMIT 1",
        params=[fqn],
    ).collect()[0]
    model = row["SEMANTIC_VIEW"]
    if isinstance(model, str):
        model = json.loads(model)
    rich = model.get("attribute_semantic_model") or []
    names = list(dict.fromkeys(item["name"] for item in rich if isinstance(item, dict) and item.get("name")))
    targets = names[:args.targets]
    value = {"operation": "sttm.auto_map", "request_id": "isolated-scoped-account-acceptance", "context": {
        "source_tables": [table], "driving_table": table, "target_table": table,
        "semantic_context": [{"table": table, "semantic_model": model}],
        "relation_graph": {"nodes": [{"relation_id": fqn, "alias": "account", "kind": "PHYSICAL_TABLE", "table": table,
                                      "output_columns": [{"name": name} for name in names]}], "edges": []},
        "learning_context": {},
    }, "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": table, "target_attribute": name} for name in targets],
                "message": "Isolated identity-mapping acceptance. Map each requested ACCOUNT target from its same exact source column. Do not write or apply anything."}}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    store = AutoMapContext(value)
    manifest = store.manifest()
    projected = STTMBuilderService.project_agent_payload(req, settings)
    print(json.dumps({"registry_model_chars": len(encoded(model)), "columns": len(names),
                      "targets": targets, "manifest_chars": len(projected.text),
                      "exact_snapshot_hash": store.snapshot_hash,
                      "rich_first_column_indexed": "business_meaning" in encoded(store.columns[fqn][targets[0]])}))
    if not args.live:
        return 0
    rest = client.get_rest_session_context()
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._settings = settings
    os.environ["SNOWFLAKE_AGENT_RETRY_ATTEMPTS"] = "1"
    service._agent = SnowflakeAgentClient(token=rest.token, host=rest.host, auth_mode="snowflake_token", request_timeout=60)
    service._source_mapping_agent_name = settings.resolved_source_mapping_agent
    config = load_config(settings=settings)
    service._model_guard = ModelBoundaryGuard(config)
    from app.guardrails.contracts.decisions import GovernanceDecision
    decision = GovernanceDecision(trace_id="isolated-scoped-acceptance", request_id=req.request_id, operation=req.operation.value)
    # This fixture has no project or historical mapping. Discovery is explicitly
    # unavailable in this isolated accuracy probe; test only exact current semantics.
    service._discover_auto_map_evidence = lambda request, target: {"evidence": {}, "diagnostics": {"status": "no_match", "fixture": True}}
    if args.live_search:
        service._session = client.session
        service._discover_auto_map_evidence = lambda request, target: STTMBuilderService._discover_auto_map_evidence(service, request, target)
    raw, thread, metadata = service._invoke_retrieval_auto_map(req, decision)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    correct = sum(mapping["source_attributes"] in ([f"account.{target}"], [f"{fqn}.{target}"])
                  for target, mapping in mappings.items())
    print(json.dumps({"thread_id": thread, "correct_identity_mappings": correct, "target_count": len(targets),
                      "mappings": mappings, "retrieval": metadata["auto_map_retrieval"]}, default=str))
    return 0 if correct == len(targets) else 1


if __name__ == "__main__":
    raise SystemExit(main())