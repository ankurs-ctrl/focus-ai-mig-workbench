"""Read-only smoke test of Search discovery and hydration for a saved mapping."""
import argparse
import json
import os
import sys
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "services" / "sttm-builder"))

from app.core.config import Settings
from app.core.mapping_search import MappingSearchService
from app.core.snowflake import SnowflakeClient


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mapping_id")
    parser.add_argument("--api", default="http://127.0.0.1:8001")
    parser.add_argument("--targets", nargs="+", default=["BILLINGCITY", "NAME", "OWNERID"])
    args = parser.parse_args()
    response = httpx.get(f"{args.api}/api/v1/sttms/{args.mapping_id}", timeout=60)
    response.raise_for_status()
    snapshot = response.json()["data"]["latest_snapshot"]
    qualified = lambda table: ".".join(table[key] for key in ("database", "schema", "table"))
    settings = Settings(_env_file=os.environ["WORKBENCH_TEST_ENV_FILE"])
    client = SnowflakeClient(settings)
    try:
        result = MappingSearchService(client.session, settings).discover(
            project_id=str(snapshot["project_id"]), sttm_id=args.mapping_id,
            target_table=qualified(snapshot["target_table"]), target_columns=args.targets,
            source_tables=[qualified(table) for table in snapshot["source_tables"]],
        )
        print(json.dumps({"diagnostics": result["diagnostics"], "recipes": [
            {"id": item["pattern_id"], "targets": item["target_columns"],
             "requires_applicability_check": item["requires_applicability_check"]}
            for item in result["evidence"] if item.get("pattern_id")
        ]}, indent=2), flush=True)
    finally:
        client.close()


if __name__ == "__main__":
    main()