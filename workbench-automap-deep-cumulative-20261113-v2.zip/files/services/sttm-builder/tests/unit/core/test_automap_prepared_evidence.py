from copy import deepcopy
from unittest.mock import Mock
from app.core.automap_prepared_evidence import TrustedPreparedAutoMap, revision, trusted, reuse, VERSION
from app.schema.workspace_context import WorkbenchContextSnapshotV1
from tests.unit.core.test_auto_mapping_proxy import _request


def prepared():
    req=_request(2)
    req.context.workspace_context=WorkbenchContextSnapshotV1(project_id=req.context.project_id,
        sttm_id=req.context.sttm_id,source_tables=req.context.source_tables,target_table=req.context.target_table,
        mapping_rows=[{'id':str(i),'target_column':a.target_attribute} for i,a in enumerate(req.data.attributes)])
    from app.core.automap_retrieval import target_name
    body={'version':VERSION,'input_revision':revision(req.context.workspace_context),'learning':{},
          'discovery':{target_name(a.target_attribute):{'evidence':{},'diagnostics':{'status':'no_match'}} for a in req.data.attributes}}
    req.context._prepared_automap=TrustedPreparedAutoMap(body)
    return req


def test_warm_reuse_does_not_call_semantic_or_learning_services():
    from app.core.sttm_builder import STTMBuilderService
    req=prepared();service=STTMBuilderService.__new__(STTMBuilderService)
    service._with_semantic_context=Mock(side_effect=AssertionError('warm semantics must not refresh'))
    service._with_learning_context=Mock(side_effect=AssertionError('warm learning must not repeat'))
    result=service.prepare_auto_map_request(req)
    assert result.meta['automap_prepared_revision']==revision(req.context.workspace_context)
    assert result.context.learning_context is not None
    assert service._discover_auto_map_batch_evidence(result,list(trusted(req)['discovery']))==trusted(req)['discovery']


def test_wire_input_cannot_create_private_preparation_authority():
    req=prepared();payload=req.model_dump(mode='json')
    payload['context']['_prepared_automap']=req.context._prepared_automap.body
    payload['meta']['automap_prepared_revision']=revision(req.context.workspace_context)
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    assert trusted(STTMBuilderEnvelopeRequest.model_validate(payload)) is None


def test_evidence_revision_ignores_ui_results_but_checks_real_dependencies():
    req=prepared();old=revision(req.context.workspace_context)
    req.context.workspace_context.checked_mapping_row_ids=['first']
    req.context.workspace_context.mapping_rows[0].confidence=.9
    req.context.workspace_context.mapping_rows[0].source_columns=['a.X']
    assert revision(req.context.workspace_context)==old
    req.context.workspace_context.raw_mapping_sql='WITH a AS (SELECT 1 AS X) SELECT X FROM a'
    assert trusted(req) is None


def test_subset_reuses_evidence_but_missing_target_does_not():
    req=prepared();req.data.attributes=req.data.attributes[:1]
    assert reuse(req) is not None
    req.data.attributes[0].target_attribute='FOREIGN_TARGET'
    assert reuse(req) is None


def test_projection_retains_private_marker_only_in_memory():
    from app.core.automap_batch import canonical_model_wire_request
    req=prepared();projected=canonical_model_wire_request(req)
    assert isinstance(projected.context._prepared_automap,TrustedPreparedAutoMap)
    assert '_prepared_automap' not in projected.model_dump(mode='json')['context']


def test_legacy_authored_sql_invalidates_but_generated_results_do_not():
    req=prepared();before=revision(req.context.workspace_context)
    req.context.workspace_context.mapping_sql='SELECT changed_authored_input'
    assert trusted(req) is None and revision(req.context.workspace_context)!=before
    req.context.workspace_context.compiled_mapping_sql=req.context.workspace_context.mapping_sql
    assert revision(req.context.workspace_context)==before
    req.context.workspace_context.mapping_sql='SELECT regenerated_output'
    req.context.workspace_context.compiled_mapping_sql=req.context.workspace_context.mapping_sql
    assert revision(req.context.workspace_context)==before
