const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const vm = require('node:vm');
const panelPath = path.resolve(__dirname, '../src/features/ai-agent/deep-agent-panel.tsx');
const source = fs.readFileSync(panelPath, 'utf8');
const ast = ts.createSourceFile(panelPath, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
let transition;
function visit(node) {
  if (ts.isCaseClause(node) && node.expression.text === 'assistant.final') {
    function find(child) {
      if (ts.isCallExpression(child) && child.expression.getText(ast) === 'setMigrationAgentState') transition = child.arguments[0].getText(ast);
      ts.forEachChild(child, find);
    }
    node.statements.forEach(find);
  }
  ts.forEachChild(node, visit);
}
visit(ast);
assert.ok(transition, 'Use the actual final-message state transition');
function apply(researchQuestion) {
  const context = { researchQuestion, result: null };
  vm.runInNewContext(ts.transpileModule(`result = (${transition})`, {compilerOptions:{target:ts.ScriptTarget.ES2020}}).outputText, context);
  const pending = {permission_id:'scope-question', questions:[{question:'Which source estate?', options:[{id:'a',label:'DB.RAW'},{id:'b',label:'DB.CURATED'}]}]};
  return {pending, state: context.result({isRunning:true, pendingPermission:pending, streamingText:'old progress'})};
}
const pause = apply(true);
assert.equal(pause.state.pendingPermission, pause.pending, 'A readable research summary must preserve the answer options');
assert.equal(pause.state.isRunning, false);
assert.equal(pause.state.streamingText, '');
assert.equal(apply(false).state.pendingPermission, null, 'Ordinary final answers still clear completed questions');
const servicePath = path.resolve(__dirname, '../src/services/migrationAgentService.ts');
const service = fs.readFileSync(servicePath, 'utf8');
const parsed = ts.createSourceFile(servicePath, service, ts.ScriptTarget.Latest, true);
let method;
function findMethod(node) {
  if (ts.isMethodDeclaration(node) && node.name.getText(parsed) === 'handleRunEvent') method=node.getText(parsed);
  ts.forEachChild(node, findMethod);
}
findMethod(parsed);
const emitted = [];
const context = {exports:{}, emitted};
vm.runInNewContext(ts.transpileModule(`exports.Client = class {runId='r'; ${method}}`, {compilerOptions:{target:ts.ScriptTarget.ES2020}}).outputText, context);
const client = new context.exports.Client();
client.emit=(...args)=>emitted.push(args);
client.handleRunEvent({event_type:'assistant.final',event_id:'e',status:'awaiting_input',safe_summary:'Research saved',data:{response_kind:'research_question'}},'scope');
assert.equal(emitted[0][2].response_kind,'research_question');
assert.equal(emitted[0][2].status,'awaiting_input');
console.log('Research summaries preserve pending choices; ordinary final answers and transport provenance remain correct.');

let answerMethod;
function findAnswer(node) {
  if (ts.isMethodDeclaration(node) && node.name.getText(parsed) === 'answerReviewDecision') answerMethod = node.getText(parsed);
  ts.forEachChild(node, findAnswer);
}
findAnswer(parsed);
const answerCalls = [];
let settled = false;
let loseAcknowledgement = false;
const answerContext = {
  exports: {},
  crypto: { randomUUID: () => 'stable-answer-key' },
  api: async (url, options) => {
    if (options?.method === 'POST') {
      answerCalls.push(JSON.parse(options.body));
      if (loseAcknowledgement) settled = true;
      throw new Error('network interruption');
    }
    return { run: { status: settled ? 'QUEUED' : 'AWAITING_INPUT' }, review_items: [{
      status: settled ? 'ANSWERED' : 'OPEN', review_item_id: 'question',
      interrupt_id: 'saved-interrupt', action_digest: 'saved-digest', artifact_revision: '2',
    }] };
  },
};
vm.runInNewContext(ts.transpileModule(`exports.Client = class { runId='r'; answerKeys=new Map(); streamGeneration=0; ${answerMethod} }`,
  { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText, answerContext);
(async () => {
  const transport = new answerContext.exports.Client();
  const updates = [];
  transport.emit = (...args) => updates.push(args);
  transport.stream = async (...args) => updates.push(['stream', ...args]);
  transport.refreshReviewItems = async () => {};
  await assert.rejects(transport.answerReviewDecision('scope', 'question', null, 'Use the saved Loan Income mapping'), /network interruption/);
  assert.equal(updates.length, 0);
  loseAcknowledgement = true;
  await transport.answerReviewDecision('scope', 'question', null, 'Use the saved Loan Income mapping');
  assert.equal(answerCalls[0].idempotency_key, answerCalls[1].idempotency_key);
  assert.equal(answerCalls[1].artifact_revision, '2');
  assert.deepEqual(updates.map(row => row[0]), ['permission.resolved', 'assistant.status', 'stream']);
})().catch(error => { console.error(error); process.exitCode = 1; });
