"""Task 7: learning from Deep Agent outcomes, follow-up corrections and stated preferences."""
from __future__ import annotations

import threading
from types import SimpleNamespace

REC = "cc6c1cf8-e46c-47aa-af33-fa3979131d46"


class _Learning:
    def __init__(self) -> None:
        self.usage: list[tuple[str, bool]] = []
        self.corrections: list[dict] = []
        self.preferences: list[dict] = []

    def track_learning_usage(self, learning_id, was_successful=True):
        self.usage.append((learning_id, was_successful))

    def record_mapping_correction(self, **kwargs):
        self.corrections.append(kwargs)
        return f"lrn_{len(self.corrections)}"

    def record_user_preference(self, statement, **kwargs):
        self.preferences.append({"statement": statement, **kwargs})
        return "lrn_pref"


class _Session:
    def __init__(self) -> None:
        self.statements: list[tuple[str, list]] = []

    def sql(self, statement, params=None):
        self.statements.append((statement, list(params or [])))
        return SimpleNamespace(collect=lambda: [])


def _handler(monkeypatch=None):
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.RLock()
    handler._learning = _Learning()
    handler._session = _Session()
    handler._settings = SimpleNamespace(qualify_metadata_object_name=lambda name: f"DB.META.{name}")
    handler._actor = lambda _state: SimpleNamespace(user_id="u1")
    handler._tool = lambda _name: None
    handler.events = []
    handler._emit = lambda event_type, status, summary, **kw: handler.events.append((event_type, kw))
    return handler


def test_outcomes_are_recorded_after_validation_and_split_by_id_space(monkeypatch) -> None:
    recorded = []

    class _Memory:
        def __init__(self, *_args):
            pass

        def record_fir_recommendation_outcome(self, **kwargs):
            recorded.append(kwargs)

    monkeypatch.setattr("app.core.conversation_memory.ConversationMemoryService", _Memory)
    handler = _handler()
    rows = [
        {"target_column": "A", "status": "draft", "used_learning_ids": ["lrn_1", "tmp_p1"], "evidence_ids": [REC]},
        {"target_column": "B", "status": "unresolved", "used_learning_ids": ["lrn_2"], "evidence_ids": ["tmp_p2"]},
    ]
    state = {"run_id": "r1"}
    mapping = {"mapping_key": "calls", "sttm_id": "s1", "target_table": "DB.T.CALLS"}
    handler._record_learning_outcomes(state, mapping, rows, validated=True)
    assert sorted(handler._learning.usage) == [("lrn_1", True), ("lrn_2", False)]
    assert [(item["recommendation_id"], item["outcome_type"]) for item in recorded] == [(REC, "validated")]
    update = [sql for sql, params in handler._session.statements if "SUPPORT_COUNT" in sql]
    assert len(update) == 1 and handler._session.statements[-1][1] == ["tmp_p1"]  # only the validated pattern

    recorded.clear()
    handler = _handler()
    handler._record_learning_outcomes(state, mapping, rows, validated=False)
    assert sorted(handler._learning.usage) == [("lrn_1", False), ("lrn_2", False)]
    assert [item["outcome_type"] for item in recorded] == ["used"]
    assert not [sql for sql, _ in handler._session.statements if "SUPPORT_COUNT" in sql]


def test_a_follow_up_change_becomes_a_correction_but_a_re_spelled_row_does_not() -> None:
    handler = _handler()
    previous = [
        {"target_column": "OWNER", "source_columns": ["DB.S.CONTACTS.OWNER_ID"], "mapping_mode": "source",
         "rule": "Direct", "expression": None, "status": "MAPPED"},
        {"target_column": "CALL_ID", "source_columns": ["DB.S.CALLS.ID"], "mapping_mode": "source",
         "rule": "Direct", "expression": None, "status": "MAPPED"},
    ]
    rows = [
        {"target_column": "OWNER", "status": "draft", "source_columns": ["C.CRM_OWNER"], "expression": "C.CRM_OWNER"},
        {"target_column": "CALL_ID", "status": "draft", "source_columns": ["CALLS.ID"], "expression": "CALLS.ID"},
    ]
    state = {"run_id": "child", "parent_run_id": "parent", "project_id": "p1", "prompt": "Use the CRM owner for OWNER"}
    handler._record_follow_up_corrections(state, {"mapping_key": "calls", "sttm_id": "s1",
                                                  "target_table": "DB.T.CALLS"}, previous, rows)
    assert [item["target_column"] for item in handler._learning.corrections] == ["OWNER"]
    correction = handler._learning.corrections[0]
    assert correction["incorrect_source"] == ["OWNER_ID"] and correction["correct_source"] == ["CRM_OWNER"]
    assert correction["target_table"] == "DB.T.CALLS" and correction["error_category"] == "follow_up_change"
    event_type, kwargs = handler.events[-1]
    assert event_type == "learning.recorded" and kwargs["kind"] == "learning"


def test_carried_rows_never_count_as_corrections() -> None:
    handler = _handler()
    previous = [{"target_column": "OWNER", "source_columns": ["S.OLD"], "status": "MAPPED"}]
    rows = [{"target_column": "OWNER", "status": "draft", "source_columns": ["S.NEW"], "carried_from_run_id": "parent"}]
    handler._record_follow_up_corrections({"run_id": "child", "parent_run_id": "parent"},
                                          {"mapping_key": "k", "sttm_id": "s1", "target_table": "T"}, previous, rows)
    assert handler._learning.corrections == []


def test_preferences_need_a_valid_scope_and_a_project_for_project_scope() -> None:
    handler = _handler()
    assert handler.remember_user_preference({"run_id": "r"}, "Never map soft-deleted rows", "team").status == "failed"
    assert handler.remember_user_preference({"run_id": "r"}, "Never map soft-deleted rows",
                                            "project").error_code == "project_not_found"
    result = handler.remember_user_preference({"run_id": "r", "project_id": "p1", "conversation_id": "c1"},
                                              "Never map soft-deleted rows", "project", "population")
    assert result.status == "succeeded" and result.data["learning_id"] == "lrn_pref"
    saved = handler._learning.preferences[0]
    assert saved["scope"] == "project" and saved["project_id"] == "p1" and saved["user_id"] == "u1"
    assert handler.events[-1][1]["details"]["kind"] == "user_preference"


def test_cited_recommendations_are_kept_on_saved_rows_for_publish_credit() -> None:
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    row = WorkbenchWorkflowHandlers._canonical_row(
        {"target_column": "A", "source_columns": ["S.A"], "status": "draft", "evidence_ids": [REC, "ev_1"]},
        {"source_columns": {"S": ["A"]}})
    assert row["used_recommendation_ids"] == [REC]


def test_supervisor_context_loads_preferences_once_per_invocation() -> None:
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime

    calls = []
    runtime = object.__new__(DeepAgentsRuntime)
    runtime._workbench = SimpleNamespace(user_preferences=lambda state: calls.append(state) or [
        {"learning_id": "lrn_pref", "statement": "Never map soft-deleted rows", "scope": "project"}])
    runtime._active_invocation = object()
    state = {"project_id": "p1"}
    assert runtime._user_preferences(state)[0]["statement"] == "Never map soft-deleted rows"
    assert runtime._user_preferences(state) and len(calls) == 1
    runtime._active_invocation = object()
    runtime._user_preferences(state)
    assert len(calls) == 2


def test_precedent_details_are_read_once_per_run_but_drafts_are_always_fresh() -> None:
    reads: list[str] = []

    def detail(sttm_id):
        reads.append(sttm_id)
        metadata = {"draft_only": True, "migration_run_id": "r1"} if sttm_id == "draft" else {}
        return SimpleNamespace(sttm=SimpleNamespace(metadata=metadata), latest_snapshot={})

    handler = _handler()
    handler._projects = SimpleNamespace(get_sttm_detail=detail)
    for _ in range(3):
        handler._precedent_detail("6606")
        handler._precedent_detail("draft")
    assert reads.count("6606") == 1 and reads.count("draft") == 3
    assert handler._precedent_detail("") is None


def test_semantic_storage_ddl_runs_once_per_session() -> None:
    from app.core.semantic_context import SemanticContextService

    session = _Session()
    service = object.__new__(SemanticContextService)
    service._session = session
    service._settings = SimpleNamespace(uses_custom_oauth=False, spcs_execute_as_caller_enabled=False)
    service._bundle_table, service._projection_table, service._overrides_table = "DB.S.B", "DB.S.P", "DB.S.O"
    service.ensure_storage_exists()
    first = len(session.statements)
    service.ensure_storage_exists()
    assert first == 9 and len(session.statements) == first
    other = _Session()
    service._session = other
    service.ensure_storage_exists()
    assert len(other.statements) == 9


def test_precedent_project_context_is_read_once_per_run_but_the_runs_project_is_fresh() -> None:
    reads: list[str] = []
    handler = _handler()
    handler.get_project_context = lambda project_id: reads.append(project_id) or SimpleNamespace(
        status="succeeded", data={"mappings": []})
    state = {"project_id": "own"}
    for _ in range(3):
        handler._precedent_project_context(state, "101")
        handler._precedent_project_context(state, "own")
    assert reads.count("101") == 1 and reads.count("own") == 3


def test_a_rule_using_an_unheld_firm_value_is_held_back_so_the_sql_still_compiles() -> None:
    handler = _handler()
    handler._setting = lambda name, default=None: default
    handler._emit = lambda *args, **kwargs: None
    rows = [
        {"target_column": "LEGACY_ID__C", "status": "draft", "source_columns": ["C.ID"],
         "expression": "$LegacyHHcPrefix || 'HH_' || C.ID"},
        {"target_column": "BIZ_LEGACY__C", "status": "draft", "source_columns": ["C.ID"],
         "expression": "$LegacyHHcPrefix || 'BAID_' || C.ID"},
        {"target_column": "START__C", "status": "draft", "source_columns": [], "expression": "$ClientStartDate"},
    ]
    context = {"choices": {}, "held": {"CLIENTSTARTDATE": {"name": "ClientStartDate", "value": "2024-01-01"}},
               "values": []}
    reviews = handler._apply_firm_values({"project_id": "p1"}, rows, context, target_table="DB.T.HOUSEHOLD",
                                         target_column_contracts=[])
    assert [row["status"] for row in rows[:2]] == ["unresolved", "unresolved"]
    assert rows[0]["held_back_expression"].startswith("$LegacyHHcPrefix")
    assert "firm_value:LegacyHHcPrefix" in rows[0]["missing_dependencies"]
    asked = [item for item in reviews if item["details"].get("firm_value_name") == "LegacyHHcPrefix"]
    assert len(asked) == 1  # one question for the value, not one per column
    assert rows[2]["status"] == "draft"  # a held value is bound, not held back


def test_a_firm_value_row_the_project_lacks_is_saved_as_an_unresolved_source_row() -> None:
    """The draft save rejects attribute rows naming an unknown project value, even unresolved."""
    handler = _handler()
    handler._setting = lambda name, default=None: default
    rows = [{"target_column": "RECORDTYPEID", "status": "unresolved", "mapping_mode": "attribute",
             "attribute_name": "HHRecordType", "constant_value": "$HHRecordType", "source_columns": []}]
    reviews = handler._apply_firm_values({"project_id": "p1"}, rows, {"choices": {}, "held": {}, "values": []},
                                         target_table="DB.T.HOUSEHOLD", target_column_contracts=[])
    assert rows[0]["mapping_mode"] == "source" and rows[0]["attribute_name"] is None
    assert rows[0]["status"] == "unresolved" and rows[0]["held_back_expression"] == "$HHRecordType"
    assert [item["details"]["firm_value_name"] for item in reviews] == ["HHRecordType"]


def test_a_promoted_value_binding_row_the_project_lacks_is_held_back() -> None:
    """Value-binding promotion runs after _apply_firm_values; the hold-back runs again after it."""
    handler = _handler()
    handler._setting = lambda name, default=None: default
    rows = [{"target_column": "OWNERID", "status": "draft", "mapping_mode": "attribute",
             "attribute_name": "BackupOwnerID", "constant_value": "$BackupOwnerID"},
            {"target_column": "START__C", "status": "draft", "mapping_mode": "attribute",
             "attribute_name": "ClientStartDate", "constant_value": "2024-01-01"}]
    reviews: list[dict] = []
    held = {"CLIENTSTARTDATE": {"name": "ClientStartDate", "value": "2024-01-01"}}
    needed = handler._hold_back_unheld_firm_values({"project_id": "p1"}, rows, held, [], reviews)
    assert needed == ["BackupOwnerID"]
    assert rows[0]["mapping_mode"] == "source" and rows[0]["status"] == "unresolved"
    assert rows[1]["mapping_mode"] == "attribute" and rows[1]["status"] == "draft"
    assert handler._hold_back_unheld_firm_values({"project_id": "p1"}, rows, held, [], reviews) == []
    assert len(reviews) == 1


def test_an_unresolved_source_row_with_a_bare_unheld_firm_value_is_sanitized() -> None:
    """A held-back source expression must not be resurrected as an attribute binding."""
    handler = _handler()
    handler._setting = lambda name, default=None: default
    rows = [{"target_column": "RECORDTYPEID", "status": "unresolved", "mapping_mode": "source",
             "expression": "$HHRecordType", "source_columns": []}]
    reviews: list[dict] = []

    needed = handler._hold_back_unheld_firm_values({"project_id": "p1"}, rows, {}, [], reviews)

    assert needed == ["HHRecordType"]
    assert rows[0]["status"] == "unresolved"
    assert rows[0]["mapping_mode"] == "source"
    assert rows[0]["expression"] is None
    assert rows[0]["held_back_expression"] == "$HHRecordType"
    assert reviews[0]["details"]["firm_value_name"] == "HHRecordType"
