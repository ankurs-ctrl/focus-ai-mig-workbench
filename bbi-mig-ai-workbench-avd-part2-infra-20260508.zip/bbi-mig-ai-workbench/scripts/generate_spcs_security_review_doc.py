from __future__ import annotations

from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont


ROOT = Path("/Users/ankurshome/Desktop/storage/Mr-Bucky/bbi-mig-ai-workbench")
OUT_DIR = ROOT / "artifacts" / "security_review_doc"
DOCX_PATH = ROOT / "SPCS_Security_Review_Overview.docx"
ARCH_PATH = OUT_DIR / "spcs_architecture_flow.png"
DEPLOY_PATH = OUT_DIR / "spcs_deployment_flow.png"


NAVY = (15, 23, 42)
BLUE = (37, 99, 235)
CYAN = (56, 189, 248)
TEAL = (20, 184, 166)
SLATE = (71, 85, 105)
MID = (100, 116, 139)
LIGHT = (248, 250, 252)
LIGHT2 = (226, 232, 240)
WHITE = (255, 255, 255)
AMBER = (245, 158, 11)
GREEN = (34, 197, 94)


def font(size: int, bold: bool = False):
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial Bold.ttf" if bold else "/Library/Fonts/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Helvetica.ttc",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except Exception:
            continue
    return ImageFont.load_default()


def draw_round_box(draw: ImageDraw.ImageDraw, xy, radius: int, fill, outline=None, width=2):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def draw_centered_text(draw: ImageDraw.ImageDraw, box, text: str, fnt, fill):
    x1, y1, x2, y2 = box
    bbox = draw.multiline_textbbox((0, 0), text, font=fnt, spacing=4, align="center")
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    x = x1 + ((x2 - x1) - tw) / 2
    y = y1 + ((y2 - y1) - th) / 2
    draw.multiline_text((x, y), text, font=fnt, fill=fill, spacing=4, align="center")


def draw_left_text(draw: ImageDraw.ImageDraw, xy, text: str, fnt, fill, spacing=4):
    draw.multiline_text(xy, text, font=fnt, fill=fill, spacing=spacing)


def draw_arrow(draw: ImageDraw.ImageDraw, start, end, fill, width=5):
    draw.line([start, end], fill=fill, width=width)
    ex, ey = end
    sx, sy = start
    if abs(ex - sx) >= abs(ey - sy):
        # horizontal-ish
        direction = 1 if ex > sx else -1
        draw.polygon(
            [(ex, ey), (ex - 16 * direction, ey - 10), (ex - 16 * direction, ey + 10)],
            fill=fill,
        )
    else:
        direction = 1 if ey > sy else -1
        draw.polygon(
            [(ex, ey), (ex - 10, ey - 16 * direction), (ex + 10, ey - 16 * direction)],
            fill=fill,
        )


def create_architecture_diagram(path: Path) -> None:
    img = Image.new("RGB", (1500, 620), WHITE)
    draw = ImageDraw.Draw(img)

    title_font = font(34, bold=True)
    heading_font = font(18, bold=True)
    body_font = font(18)
    small_font = font(15)
    micro_font = font(13)

    draw_left_text(draw, (70, 35), "SPCS web application access model", title_font, NAVY)
    draw_left_text(
        draw,
        (70, 82),
        "Snowflake-managed ingress, federated sign-in, internal service routing, and Snowflake data access.",
        body_font,
        SLATE,
    )

    boxes = [
        ((80, 180, 290, 270), CYAN, "User / Browser", NAVY),
        ((345, 180, 595, 270), BLUE, "Snowflake public\ningress", WHITE),
        ((650, 180, 905, 270), TEAL, "Snowflake sign-in\nand federated IdP", WHITE),
        ((960, 150, 1430, 315), (241, 245, 249), "", NAVY),
    ]

    for box, fill, text, text_color in boxes:
        draw_round_box(draw, box, radius=28, fill=fill, outline=LIGHT2, width=2)
        if text:
            draw_centered_text(draw, box, text, heading_font, text_color)

    draw_left_text(draw, (1000, 170), "SPCS service", heading_font, NAVY)

    # Internal boxes
    internal = [
        ((1010, 195, 1150, 255), BLUE, "Proxy", WHITE),
        ((1185, 175, 1335, 235), GREEN, "Frontend", NAVY),
        ((1185, 245, 1335, 305), NAVY, "Backend API", WHITE),
    ]
    for box, fill, text, text_color in internal:
        draw_round_box(draw, box, radius=20, fill=fill, outline=None, width=2)
        draw_centered_text(draw, box, text, small_font, text_color)

    data_box = (1010, 390, 1350, 500)
    draw_round_box(draw, data_box, radius=24, fill=LIGHT, outline=LIGHT2, width=2)
    draw_centered_text(draw, data_box, "Snowflake data access\n(SQL through governed\nSnowflake roles)", heading_font, NAVY)

    auth_box = (80, 390, 690, 525)
    draw_round_box(draw, auth_box, radius=24, fill=LIGHT, outline=LIGHT2, width=2)
    draw_left_text(
        draw,
        (105, 418),
        "Key points\n• “Public” means Snowflake-managed reachable ingress,\n  not anonymous access.\n• Snowflake performs sign-in before requests reach\n  the service.\n• Endpoint access and data access remain controlled\n  by Snowflake roles and service configuration.",
        micro_font,
        SLATE,
        spacing=6,
    )

    draw_arrow(draw, (290, 225), (345, 225), MID, width=5)
    draw_arrow(draw, (595, 225), (650, 225), MID, width=5)
    draw_arrow(draw, (905, 225), (960, 225), MID, width=5)
    draw_arrow(draw, (1150, 225), (1185, 205), MID, width=4)
    draw_arrow(draw, (1150, 225), (1185, 275), MID, width=4)
    draw_arrow(draw, (1260, 305), (1260, 390), MID, width=4)

    img.save(path)


def create_deployment_diagram(path: Path) -> None:
    img = Image.new("RGB", (1500, 520), WHITE)
    draw = ImageDraw.Draw(img)

    title_font = font(34, bold=True)
    heading_font = font(18, bold=True)
    body_font = font(15)
    num_font = font(18, bold=True)

    draw_left_text(draw, (70, 35), "SPCS deployment lifecycle", title_font, NAVY)
    draw_left_text(
        draw,
        (70, 82),
        "A practical deployment sequence for containerized web applications on Snowflake.",
        body_font,
        SLATE,
    )

    steps = [
        ("1", "Build images"),
        ("2", "Registry login"),
        ("3", "Push images"),
        ("4", "Render spec"),
        ("5", "Create or\nupgrade service"),
        ("6", "Validate endpoint"),
    ]
    x_positions = [90, 320, 550, 780, 1010, 1240]
    colors = [BLUE, TEAL, CYAN, AMBER, GREEN, NAVY]

    for (num, label), x, fill in zip(steps, x_positions, colors):
        circ = (x, 185, x + 70, 255)
        draw_round_box(draw, circ, radius=35, fill=fill, outline=None, width=2)
        draw_centered_text(draw, circ, num, num_font, WHITE if fill != CYAN else NAVY)
        box = (x - 25, 285, x + 145, 385)
        draw_round_box(draw, box, radius=20, fill=LIGHT, outline=LIGHT2, width=2)
        draw_centered_text(draw, box, label, heading_font, NAVY)

    for i in range(len(x_positions) - 1):
        draw_arrow(draw, (x_positions[i] + 70, 220), (x_positions[i + 1] - 25, 220), MID, width=4)

    footer_box = (90, 420, 1410, 485)
    draw_round_box(draw, footer_box, radius=22, fill=LIGHT, outline=LIGHT2, width=2)
    draw_left_text(
        draw,
        (115, 438),
        "Required controls across the lifecycle: repository permissions, compute pool access, service create/alter privileges, service spec values, and final endpoint validation.",
        body_font,
        SLATE,
    )

    img.save(path)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def style_run(run, size=11, bold=False, color: RGBColor | None = None, name="Aptos"):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = color


def style_paragraph(paragraph, spacing_after=6, spacing_before=0, line_spacing=1.15):
    fmt = paragraph.paragraph_format
    fmt.space_after = Pt(spacing_after)
    fmt.space_before = Pt(spacing_before)
    fmt.line_spacing = line_spacing


def add_bullets(doc: Document, items: Iterable[str], level=0):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        if level:
            p.paragraph_format.left_indent = Inches(0.25 * level)
        r = p.add_run(item)
        style_run(r, size=11, color=RGBColor(*SLATE))
        style_paragraph(p, spacing_after=4)


def add_section_heading(doc: Document, text: str):
    p = doc.add_paragraph()
    p.style = doc.styles["Heading 1"]
    r = p.add_run(text)
    style_run(r, size=14, bold=True, color=RGBColor(*NAVY))
    style_paragraph(p, spacing_after=4, spacing_before=8)


def add_sub_heading(doc: Document, text: str):
    p = doc.add_paragraph()
    r = p.add_run(text)
    style_run(r, size=11, bold=True, color=RGBColor(*BLUE))
    style_paragraph(p, spacing_after=4, spacing_before=4)


def add_body(doc: Document, text: str):
    p = doc.add_paragraph()
    r = p.add_run(text)
    style_run(r, size=11, color=RGBColor(*SLATE))
    style_paragraph(p, spacing_after=6)


def build_doc() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    create_architecture_diagram(ARCH_PATH)
    create_deployment_diagram(DEPLOY_PATH)

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.6)
    section.left_margin = Inches(0.75)
    section.right_margin = Inches(0.75)

    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    styles["Normal"]._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    styles["Normal"].font.size = Pt(11)

    # Header
    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    hr = hp.add_run("Internal draft for architecture and security review")
    style_run(hr, size=9, color=RGBColor(*MID))

    # Title
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run("Snowpark Container Services (SPCS)\nWeb Application Deployment Overview")
    style_run(r, size=20, bold=True, color=RGBColor(*NAVY))
    style_paragraph(p, spacing_after=2)

    p = doc.add_paragraph()
    r = p.add_run("Architecture, Authentication, and Access Controls")
    style_run(r, size=11, bold=True, color=RGBColor(*BLUE))
    style_paragraph(p, spacing_after=10)

    # Summary callout
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    cell.width = Inches(6.8)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    set_cell_shading(cell, "F8FAFC")
    p = cell.paragraphs[0]
    r = p.add_run(
        "Executive summary. Snowpark Container Services provides a Snowflake-managed way to host containerized web applications "
        "while keeping identity, governance, and data access within the Snowflake operating model. In this deployment pattern, "
        "a web application can expose a Snowflake-managed public endpoint without becoming an anonymous or unmanaged internet service."
    )
    style_run(r, size=11, color=RGBColor(*NAVY))
    style_paragraph(p, spacing_after=0, line_spacing=1.15)
    doc.add_paragraph()

    add_section_heading(doc, "1. What SPCS Is")
    add_body(
        doc,
        "Snowpark Container Services is Snowflake’s managed container runtime for long-running services and job services. "
        "It allows teams to package standard application components such as a frontend, reverse proxy, and backend API into OCI-compatible containers and run them on Snowflake-managed compute pool nodes."
    )
    add_body(
        doc,
        "For web applications, SPCS is useful when teams want application runtime, Snowflake data access, and identity controls to stay within the same platform boundary. "
        "Instead of treating Snowflake only as a database, SPCS lets Snowflake also act as the controlled runtime for service-hosted application components."
    )

    add_section_heading(doc, "2. Typical Web Application Deployment Pattern")
    add_body(
        doc,
        "A common web application pattern is to run three logical components inside one SPCS service instance: a frontend container, "
        "a reverse proxy container, and a backend API container. The reverse proxy routes browser traffic to the frontend and routes API traffic to the backend, "
        "while Snowflake exposes a single public HTTP endpoint for the service."
    )
    doc.add_picture(str(ARCH_PATH), width=Inches(6.8))
    p = doc.paragraphs[-1]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    style_paragraph(p, spacing_after=6)
    add_body(
        doc,
        "This pattern is attractive because it gives users one Snowflake-generated URL, keeps browser routing simple, and allows internal ports to remain inside the service boundary. "
        "It also reduces the amount of cross-origin and multi-endpoint complexity that would otherwise need to be handled at the application layer."
    )

    add_section_heading(doc, "3. Public Ingress and Authentication")
    add_sub_heading(doc, "What “public ingress” means")
    add_body(
        doc,
        "In SPCS, a service endpoint marked as public becomes reachable through Snowflake-managed ingress. "
        "This means Snowflake generates the externally reachable application URL and mediates access to it. "
        "It does not mean the service is anonymously open to the internet in the way a standalone unmanaged web host would be."
    )
    add_sub_heading(doc, "How authentication works")
    add_body(
        doc,
        "When a user accesses a public endpoint in a browser, Snowflake handles the sign-in flow before the request reaches the application service. "
        "If the Snowflake account uses a federated identity provider such as Okta, Snowflake handles that federation step as part of the login experience. "
        "The application itself does not need to accept raw browser-provided identity tokens directly from the frontend in order to participate in that sign-in flow."
    )
    add_bullets(
        doc,
        [
            "Public endpoint access is still subject to Snowflake authentication.",
            "Access to the endpoint is governed by Snowflake service-role and role-grant configuration.",
            "Application behavior can still apply its own app-role or persona model on top of Snowflake roles where needed.",
        ],
    )

    add_section_heading(doc, "4. Authorization and Access Boundaries")
    add_body(
        doc,
        "From a security perspective, it is helpful to separate three different questions: who can reach the application endpoint, who can use particular application functions, "
        "and what Snowflake data the backend can access. These controls are related, but they are not identical."
    )
    tbl = doc.add_table(rows=4, cols=3)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.style = "Table Grid"
    hdr = tbl.rows[0]
    set_repeat_table_header(hdr)
    headers = ["Control layer", "Purpose", "Typical mechanism"]
    for i, h in enumerate(headers):
        c = hdr.cells[i]
        set_cell_shading(c, "E2E8F0")
        p = c.paragraphs[0]
        r = p.add_run(h)
        style_run(r, size=10, bold=True, color=RGBColor(*NAVY))
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    rows = [
        ("Endpoint access", "Controls who can reach the service URL.", "Snowflake service roles / endpoint grants"),
        ("Application access", "Controls who can use specific functions in the app.", "App roles, personas, or route-level checks"),
        ("Data access", "Controls what Snowflake objects the backend can read or modify.", "Snowflake data roles and grants"),
    ]
    for row_data in rows:
        row = tbl.add_row().cells
        for idx, value in enumerate(row_data):
            p = row[idx].paragraphs[0]
            r = p.add_run(value)
            style_run(r, size=10, color=RGBColor(*SLATE))
            row[idx].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    doc.add_paragraph()
    add_body(
        doc,
        "Where a backend also connects back to Snowflake in a user-aware way, teams should design that access path deliberately. "
        "The important control point for security review is that user-aware access and Snowflake data access should still remain governed by Snowflake-native roles, tokens, and service capabilities rather than ad hoc browser-side trust."
    )

    add_section_heading(doc, "5. Role Model and User-Aware Snowflake Access")
    add_body(
        doc,
        "In practice, SPCS deployments usually involve several distinct role layers. A platform administration role typically creates or governs shared infrastructure such as compute pools, image repositories, and optional network controls. "
        "A deployer role is then responsible for building or referencing approved images, creating or upgrading the service, and maintaining the service specification for a given environment."
    )
    add_body(
        doc,
        "Access to the running application is separate from deployment privileges. To reach a public service endpoint, a user must be a Snowflake user in the same account and must be granted a role that has been granted the appropriate service role for that endpoint. "
        "This means endpoint reachability is still role-controlled even though the URL is publicly reachable through Snowflake ingress."
    )
    add_body(
        doc,
        "Where the backend is designed to create Snowflake sessions by using Snowflake-provided user context from ingress, the application can operate with user-aware data access rather than broad shared service access. "
        "In that pattern, the effective data visibility remains bounded by the signed-in user’s Snowflake role configuration and by any caller-grants explicitly allowed to the service owner role. As a result, a user can only query databases, schemas, tables, and other objects that their Snowflake privileges permit the application to access on their behalf."
    )
    add_bullets(
        doc,
        [
            "Platform roles govern infrastructure objects such as compute pools, repositories, and optional network controls.",
            "Deployer roles govern service creation, upgrade, and environment-specific configuration.",
            "Service roles govern who may access a public endpoint.",
            "Snowflake data roles and caller-grants govern what data the backend may access on behalf of a signed-in user.",
        ],
    )

    add_section_heading(doc, "6. Required Platform Objects and Deployment Flow")
    add_body(
        doc,
        "A successful SPCS deployment depends on a small set of explicit platform objects and a repeatable deployment sequence. "
        "The exact naming may vary by environment, but the operating model is generally the same."
    )
    add_bullets(
        doc,
        [
            "Runtime database and schema for service objects and optional metadata tables",
            "Image registry and repository for application images",
            "Compute pool where service instances run",
            "Service specification defining containers, resources, and endpoint exposure",
            "Roles and grants for platform administration, deployment, endpoint access, and Snowflake data access",
            "Optional external access integration where the application must call internet endpoints or external APIs",
        ],
    )
    doc.add_picture(str(DEPLOY_PATH), width=Inches(6.8))
    p = doc.paragraphs[-1]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    style_paragraph(p, spacing_after=6)
    add_body(
        doc,
        "A typical deployment lifecycle is: build images, authenticate Docker to the Snowflake image registry, push images to the repository, render the environment-specific service specification, "
        "create or upgrade the service, and finally validate the endpoint and service state."
    )

    add_section_heading(doc, "7. Security and Operational Considerations")
    add_bullets(
        doc,
        [
            "A public endpoint should be understood as authenticated Snowflake-managed ingress, not anonymous public exposure.",
            "Outbound internet access is not implicit. If the application must call external APIs, that access should be explicitly reviewed and enabled through the appropriate Snowflake controls.",
            "Compute pool sizing affects availability and readiness. An undersized pool can leave services pending or unstable even if application code is otherwise correct.",
            "Repository privileges, service roles, data roles, and deployer privileges must all align for a deployment to function end to end.",
            "If frontend and backend are split into separate services, additional care is required when the backend also connects back to Snowflake and needs a user-aware access model.",
        ],
    )
    add_body(
        doc,
        "For most first deployments, the lowest-risk pattern is to keep the architecture simple: a single service, a single public endpoint, explicit role assignments, and minimal optional networking features until the core access path is validated."
    )

    add_section_heading(doc, "8. Conclusion")
    add_body(
        doc,
        "Snowpark Container Services can support a controlled and reviewable web application deployment model when used with the appropriate Snowflake platform objects, service configuration, and role-based access controls. "
        "The presence of a public endpoint does not by itself imply open anonymous exposure; rather, the endpoint remains mediated by Snowflake ingress, authentication, and service access configuration."
    )
    add_body(
        doc,
        "For security review, the most important questions are therefore not simply whether an endpoint is public, but how Snowflake authentication is enforced, which roles can access the endpoint, how backend data access is governed, "
        "and whether any outbound integrations or split-service patterns introduce additional control requirements."
    )

    add_section_heading(doc, "References")
    refs = [
        "Snowflake Documentation — Snowpark Container Services: Working with services",
        "Snowflake Documentation — Snowpark Container Services: SQL execution",
        "Snowflake Documentation — Snowpark Container Services: Working with compute pools",
        "Snowflake Documentation — Snowpark Container Services: Working with an image registry and repository",
        "Snowflake Documentation — Snowpark Container Services: Service specification reference",
        "Snowflake Documentation — Snowpark Container Services: Configuring private connectivity",
    ]
    add_bullets(doc, refs)

    # Footer with page numbers
    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    fr = fp.add_run("SPCS Security Review Overview")
    style_run(fr, size=9, color=RGBColor(*MID))
    fr.add_break(WD_BREAK.LINE)
    page_run = fp.add_run("Page ")
    style_run(page_run, size=9, color=RGBColor(*MID))
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    r = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "1"
    r.append(t)
    fld.append(r)
    fp._p.append(fld)

    doc.save(DOCX_PATH)


if __name__ == "__main__":
    build_doc()
    print(DOCX_PATH)
