from app.agent_runs.attachment_retrieval import load_scoped_attachments, retrieve_attachment_evidence
import pytest
from app.agent_runs.attachments import AttachmentValidationError, parse_attachment
from pypdf import PdfWriter
from io import BytesIO


def test_uploaded_evidence_is_ranked_and_cited() -> None:
    attachments = [{"attachment_id": "att_1", "filename": "mapping.xlsx", "content_hash": "abc",
                    "parsed_manifest": {"atomized": {"sheets": [{"name": "Rules", "rows": [
                        ["target", "source", "transformation"],
                        ["PAYOUT_DATE", "CONTACTS.DATE", "use current date"],
                        ["COUNTRY", "ADDRESS.COUNTRY", "normalize code"],
                    ]}]}}}]
    result = retrieve_attachment_evidence(attachments, "COUNTRY ADDRESS", limit=1)
    assert result[0]["attachment_id"] == "att_1"
    assert result[0]["content_hash"] == "abc"
    assert "COUNTRY" in result[0]["text"]


def test_image_only_pdf_requires_ocr() -> None:
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    stream = BytesIO()
    writer.write(stream)
    with pytest.raises(AttachmentValidationError, match="no extractable text"):
        parse_attachment("notes.pdf", stream.getvalue())


def test_call_transcript_keeps_speaker_and_timestamp_context() -> None:
    _, _, manifest, _ = parse_attachment(
        "client-call.vtt", b"WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nClient: Household means primary contact.\n",
    )
    evidence = retrieve_attachment_evidence([{"attachment_id": "att_call", "filename": "client-call.vtt",
                                             "parsed_manifest": manifest}], "household primary contact")
    assert "00:00:01.000" in evidence[0]["text"]
    assert "Client:" in evidence[0]["text"]


def test_scoped_attachment_loader_batches_ids_and_rejects_missing() -> None:
    class Session:
        calls = 0
        def sql(self, _query, params):
            self.calls += 1
            assert params[-2:] == ["user", "tenant"]
            return self
        def collect(self):
            return [{"ATTACHMENT_ID": "att_1", "ATTACHMENT_PAYLOAD": '{"filename":"one.txt"}'},
                    {"ATTACHMENT_ID": "att_2", "ATTACHMENT_PAYLOAD": '{"filename":"two.txt"}'}]
    session = Session()
    assert [item["filename"] for item in load_scoped_attachments(session, ["att_1", "att_2"], "user", "tenant")] == ["one.txt", "two.txt"]
    assert session.calls == 1
    with pytest.raises(PermissionError):
        load_scoped_attachments(session, ["att_1", "att_2", "att_3"], "user", "tenant")
