import { AiaBox, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import React from 'react';

export type ContextUsage = {
  usedTokens: number;
  windowTokens: number;
  categories: Record<string, number>;
  compactionAtTokens: number | null;
  summarized: boolean;
  estimated: boolean;
};

const CATEGORY_LABELS: Array<[string, string, string]> = [
  ['system', 'System prompt', '#6366f1'],
  ['tools', 'Tool definitions', '#0ea5e9'],
  ['messages', 'Messages', '#22c55e'],
  ['tool_results', 'Tool results', '#f59e0b'],
];

function tokens(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value % 1_000_000 ? 1 : 0)}M`;
  if (value >= 1_000) return `${Math.round(value / 1_000)}K`;
  return String(value);
}

/** Parse a `context.usage` stream message into the meter's shape. */
export function contextUsageFromEvent(data: Record<string, unknown> | undefined): ContextUsage | null {
  if (!data) return null;
  const used = Number(data.used_tokens ?? 0);
  const window = Number(data.window_tokens ?? 0);
  if (!used || !window) return null;
  const categories = (data.categories && typeof data.categories === 'object' ? data.categories : {}) as Record<string, unknown>;
  return {
    usedTokens: used,
    windowTokens: window,
    categories: Object.fromEntries(Object.entries(categories).map(([key, value]) => [key, Number(value ?? 0)])),
    compactionAtTokens: data.compaction_at_tokens == null ? null : Number(data.compaction_at_tokens),
    summarized: data.summarized === true,
    estimated: data.estimated === true,
  };
}

/** A small ring beside the model and effort label; the hover card breaks the context down. */
export function ContextMeter({ usage }: { usage: ContextUsage }) {
  const share = Math.min(1, usage.usedTokens / usage.windowTokens);
  const nearLimit = usage.compactionAtTokens != null && usage.usedTokens >= usage.compactionAtTokens * 0.9;
  const color = nearLimit ? '#b45309' : '#2563eb';
  const radius = 7;
  const circumference = 2 * Math.PI * radius;
  const free = Math.max(0, usage.windowTokens - usage.usedTokens);
  const card = (
    <AiaBox sx={{ p: 0.5, minWidth: 220 }}>
      <AiaText sx={{ fontSize: 12, fontWeight: 600, mb: 0.5 }}>
        Context: {tokens(usage.usedTokens)} / {tokens(usage.windowTokens)} tokens ({Math.round(share * 100)}%)
        {usage.estimated ? ' · estimated' : ''}
      </AiaText>
      {CATEGORY_LABELS.map(([key, label, swatch]) => (
        <AiaBox key={key} sx={{ display: 'flex', alignItems: 'center', gap: 0.75, fontSize: 11, lineHeight: '18px' }}>
          <AiaBox component="span" sx={{ width: 8, height: 8, borderRadius: '2px', backgroundColor: swatch }} />
          <AiaBox component="span" sx={{ flex: 1 }}>{label}</AiaBox>
          <AiaBox component="span">{tokens(usage.categories[key] ?? 0)}</AiaBox>
        </AiaBox>
      ))}
      <AiaBox sx={{ display: 'flex', gap: 0.75, fontSize: 11, lineHeight: '18px', color: '#64748b' }}>
        <AiaBox component="span" sx={{ flex: 1, pl: '14px' }}>Free space</AiaBox>
        <AiaBox component="span">{tokens(free)}</AiaBox>
      </AiaBox>
      {usage.compactionAtTokens != null ? (
        <AiaText sx={{ fontSize: 11, color: '#64748b', mt: 0.5 }}>
          Older turns are summarized automatically at {tokens(usage.compactionAtTokens)}.
        </AiaText>
      ) : null}
      {usage.summarized ? (
        <AiaText sx={{ fontSize: 11, color: '#b45309', mt: 0.25 }}>This session was summarized.</AiaText>
      ) : null}
    </AiaBox>
  );
  return (
    <AiaTooltip title={card}>
      <AiaBox component="span" role="img" aria-label={`Context ${Math.round(share * 100)}% used`}
        sx={{ display: 'inline-flex', alignItems: 'center', px: 0.25, cursor: 'default' }}>
        <svg width="18" height="18" viewBox="0 0 18 18">
          <circle cx="9" cy="9" r={radius} fill="none" stroke="#e2e8f0" strokeWidth="2.5" />
          <circle cx="9" cy="9" r={radius} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
            strokeDasharray={`${circumference * share} ${circumference}`} transform="rotate(-90 9 9)" />
        </svg>
      </AiaBox>
    </AiaTooltip>
  );
}
