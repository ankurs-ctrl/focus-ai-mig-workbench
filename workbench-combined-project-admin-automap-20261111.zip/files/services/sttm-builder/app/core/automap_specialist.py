"""Transformation calls on the owning Auto-map runtime, without legacy replay."""
import json

from app.core.automap_fast_transport import FastModelRuntime
from app.schema.sttm_builder import STTMBuilderResponse, STTMStatus, SubAgent, TransformationResult


def _completed_model_envelope(raw, *, allow_partial=False):
    def invalid_constant(_value):
        raise ValueError("Specialist envelope contains a nonfinite JSON constant")
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Specialist envelope contains duplicate fields")
            result[key] = value
        return result
    if isinstance(raw, str):
        # Models occasionally wrap the envelope in a fence or a sentence; the
        # strict duplicate/constant checks below still apply to the object.
        from app.core.sttm_builder import _extract_json_object
        raw = _extract_json_object(raw)
    envelope = json.loads(raw, object_pairs_hook=unique_object, parse_constant=invalid_constant)
    if type(envelope) is not dict or ("data" in envelope and type(envelope["data"]) is not dict):
        raise ValueError("Specialist requires a structured model envelope")
    # Provider completion does not establish model-envelope completion. Check
    # both levels before the compatibility parser can default or coerce them.
    for level in [envelope, *([envelope["data"]] if "data" in envelope else [])]:
        if "status" in level and level["status"] not in ({"completed", "needs_input"} if allow_partial else {"completed"}):
            raise ValueError("Specialist model status is not completed")
        if any(key in level and level[key] is not None for key in ("error", "error_code", "code")):
            raise ValueError("Specialist model envelope reports an error")
        meta = level.get("meta")
        if meta is not None and (type(meta) is not dict or "delegation" in meta):
            raise ValueError("Specialist returned invalid metadata or delegation")
    levels = [envelope, *([envelope["data"]] if "data" in envelope else [])]
    results = [level["result"] for level in levels if "result" in level]
    if (not results or any(type(result) is not dict for result in results)
            or any(result != results[0] for result in results[1:])):
        raise ValueError("Specialist requires one unambiguous direct rule result")
    from app.core.sttm_builder import _normalize_sub_agent
    agents = [level["agent"] for level in levels if "agent" in level]
    if not agents or any(type(agent) is not str or _normalize_sub_agent(agent) != SubAgent.TRANSFORMATION_AGENT
                         for agent in agents):
        raise ValueError("Specialist requires an unambiguous transformation agent")
    return envelope


def invoke_specialist(service, req, runtime):
    if not isinstance(runtime, FastModelRuntime) and getattr(runtime, "is_test_runtime", False) is not True:
        raise ValueError("Transformation requires the owning guarded Auto-map runtime")
    runtime.check_active()
    from app.core.automap_specialist_context import specialist_messages
    messages, evidence_review = specialist_messages(service, req, runtime)
    raw, _thread, diagnostics = runtime.run(messages, runtime.next_call_index, stage="transformation_rule")
    runtime.check_active()
    # Completion is enforced by the transport. Delegation is not a completed
    # rule and cannot be smuggled through the legacy envelope normalizer.
    draft_rules = req.meta.get('automap_rules_policy') == 'rules-v2'
    envelope = _completed_model_envelope(raw, allow_partial=draft_rules)
    if draft_rules:
        from app.core.sttm_builder import _normalize_transformation_result
        for level in [envelope, *([envelope['data']] if 'data' in envelope else [])]:
            result = level.get('result')
            if isinstance(result, dict) and isinstance(result.get('rules'), list):
                valid = []
                for item in result['rules']:
                    if not isinstance(item, dict):
                        continue
                    try:
                        valid.extend(_normalize_transformation_result({'rules': [item]}).rules)
                    except (ValueError, TypeError):
                        continue  # A malformed sibling is repaired in the missing-target pass.
                result['rules'] = [rule.model_dump(mode='json') for rule in valid]
    parsed = service._parse_envelope(json.dumps(envelope))
    if parsed[4] is not None or parsed[6] not in ({STTMStatus.COMPLETED, STTMStatus.NEEDS_INPUT} if draft_rules else {STTMStatus.COMPLETED}) or not isinstance(parsed[1], TransformationResult):
        raise ValueError("Specialist did not return completed structured rules")
    runtime.check_active()
    answer = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.TRANSFORMATION_AGENT, result=parsed[1], message=parsed[2],
        warnings=service._auto_map_response_warnings(parsed[3]), status=STTMStatus.COMPLETED,
        meta={"fast_diagnostics": diagnostics.get("fast_diagnostics", {}),
              **({"specialist_evidence_review": evidence_review, "automap_evidence_review_only_targets":
                  [item.target_attribute for item in req.data.attributes]} if evidence_review else {})})
    answer = service._postflight_guard.finalize_sttm_response(answer, runtime._decision)
    runtime.check_active()
    if answer.error is not None or answer.data.status not in ({STTMStatus.COMPLETED, STTMStatus.NEEDS_INPUT} if draft_rules else {STTMStatus.COMPLETED}):
        raise ValueError("Specialist rule did not pass response governance")
    return answer
