"use client";
import { AiaAvatar, AiaBox, AiaButton, AiaCircularProgress, AiaIconButton, AiaInput, AiaPaper, AiaStack, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  AutoAwesomeRoundedIcon,
  BoltIcon,
  ContentCopyRoundedIcon,
  EditNoteRoundedIcon,
  HelpOutlineOutlinedIcon,
  KeyboardArrowDownIcon,
  KeyboardArrowRightIcon,
  OpenInFullIcon,
  TableChartIcon,
  ThumbDownAltOutlinedIcon,
  ThumbUpAltOutlinedIcon,
  TipsAndUpdatesOutlinedIcon,
  VolumeUpIcon,
  WarningAmberRoundedIcon,
} from '@/utils/icons';
import { MigrationAgentSessionClient, type MigrationAgentServerMessage, type MigrationAgentPermissionRequest, type MigrationEffort, type MigrationRunMode, type MigrationConversationMessage, fetchMigrationAgentDiagnostics } from '@/services/migrationAgentService';
import { recommendationService } from "@/services/recommendationService";
import { AiChatComposer } from "@/features/ai-agent/ai-chat-composer";
import { AgentArtifactPane, type AgentArtifactTab, type AgentSqlArtifact } from "@/features/ai-agent/agent-artifact-pane";
import { useAiChatLayout } from "@/features/ai-agent/ai-chat-layout-context";
import type {
  FIRRecommendation,
  FIRRecommendationAction,
  WorkbenchContextSnapshotV1,
} from '@/types/api-contract';






import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import type { StreamingStatusPhase } from "@/features/sttm/types/sttm.types";
import { usePathname, useRouter } from "next/navigation";
import { buildWorkbenchContextSnapshot } from "@/features/sttm/context/workbench-context";
import { getSttmBuilderAssistantPage } from "@/features/sttm/shared/sttm-builder-routes";
import { authService } from '@/services/authService';
import type { UserSession } from '@/types/user';

// User-friendly labels for each streaming phase
const STATUS_PHASE_LABELS: Record<StreamingStatusPhase, string> = {
  preparing: "Preparing context...",
  semantic: "Loading semantic data...",
  learning: "Retrieving learnings...",
  invoking: "Connecting to AI...",
  processing: "Analyzing tables...",
  finalizing: "Generating suggestions...",
};

// Progress percentage for each phase (for visual feedback)
const STATUS_PHASE_PROGRESS: Record<StreamingStatusPhase, number> = {
  preparing: 10,
  semantic: 25,
  learning: 40,
  invoking: 55,
  processing: 75,
  finalizing: 90,
};

const APPROVAL_RESPONSE_PATTERN =
  /^(yes|yep|yeah|ok|okay|sure|approve|approved|apply|apply it|please apply|go ahead|looks good|do it|use it)[.! ]*$/i;
const SKIP_RESPONSE_PATTERN = /^(skip|pass|next one|next)[.! ]*$/i;

// Migration Agent mode types
type MigrationAgentToolExecution = {
  toolId: string;
  tool: string;
  resource?: string;
  status: 'started' | 'completed' | 'error';
  startedAt: string;
  completedAt?: string;
  result?: string;
};

type MigrationAgentTraceEvent = {
  traceId: string;
  parentTraceId: string | null;
  kind: string;
  label: string;
  status: string;
  summary: string;
  timestamp: string;
  details: Record<string, unknown>;
};

type MigrationAgentMessage = {
  role: 'user' | 'assistant';
  content: string;
  id: string;
  kind?: 'progress' | 'final';
  animate?: boolean;
  question?: { prompt: string; options: Array<{ label: string; description: string }> };
};

function QuestionChoiceButton({ label, description, recommended = false, disabled = false, onClick }: {
  label: string;
  description?: string;
  recommended?: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <AiaButton
      variant="contained"
      title={description || label}
      customColor="#0f172a"
      customBackgroundColor={recommended ? "#eff6ff" : "#ffffff"}
      customHoverBackgroundColor="#f8fafc"
      customBorderColor={recommended ? "#93c5fd" : "#cbd5e1"}
      disabled={disabled}
      onClick={onClick}
      sx={{
        width: "100%", minWidth: 0, maxWidth: "100%", height: "auto", px: 1.5, py: 1,
        display: "block", textAlign: "left", textTransform: "none", whiteSpace: "normal",
        overflowWrap: "anywhere", wordBreak: "break-word", borderRadius: 1.5,
        "&:hover": { borderColor: "#60a5fa" },
      }}
    >
      <AiaBox component="span" sx={{ display: "block", minWidth: 0, maxWidth: "100%" }}>
        <AiaText component="span" sx={{ display: "block", fontSize: 13, fontWeight: 700, lineHeight: 1.4, overflowWrap: "anywhere" }}>
          {label}
        </AiaText>
        {description ? (
          <AiaText component="span" sx={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", mt: 0.25, fontSize: 11.5, lineHeight: 1.4, color: "#64748b", overflowWrap: "anywhere" }}>
            {description}
          </AiaText>
        ) : null}
        {recommended ? <AiaText component="span" sx={{ display: "block", mt: 0.3, fontSize: 10.5, color: "#2563eb", fontWeight: 700 }}>Recommended</AiaText> : null}
      </AiaBox>
    </AiaButton>
  );
}

function progressWords(value: string): Set<string> {
  const ignored = new Set([
    'i', 'ill', 'will', 'let', 'me', 'now', 'continue', 'continuing', 'by', 'then',
    'the', 'a', 'an', 'and', 'with', 'proper', 'necessary', 'remaining', 'actual',
    'key', 'tables', 'table', 'get', 'getting', 'help', 'you', 'your', 'for', 'to',
  ]);
  return new Set(
    value.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/)
      .filter((word) => word && !ignored.has(word)),
  );
}

function isSimilarProgress(left: string, right: string): boolean {
  const leftWords = progressWords(left);
  const rightWords = progressWords(right);
  const union = new Set([...leftWords, ...rightWords]);
  if (!union.size) return true;
  const overlap = [...leftWords].filter((word) => rightWords.has(word)).length;
  return overlap / union.size >= 0.55;
}

function isSameVisibleMessage(left: string, right: string): boolean {
  const normalize = (value: string) => value.replace(/^\s*\[FINAL\]\s*/i, '').replace(/\s+/g, ' ').trim();
  return normalize(left) === normalize(right);
}

type MigrationPlanTodo = {
  content: string;
  status: string;
};

type MigrationAgentPendingPermission = MigrationAgentPermissionRequest & {
  contextHash: string;
};

type MigrationAgentModeState = {
  isActive: boolean;
  isConnecting: boolean;
  isConnected: boolean;
  isRunning: boolean;
  isCancelling: boolean;
  streamingText: string;
  statusMessage: string | null;
  toolExecutions: MigrationAgentToolExecution[];
  traceEvents: MigrationAgentTraceEvent[];
  pendingPermission: MigrationAgentPendingPermission | null;
  reviewItems: Array<{ id: string; category: string; summary: string; question: string;
    status: string; sttmId: string | null; choices: Array<{ id: string; label: string; description: string }> }>;
  reviewContextHash: string;
  reviewArtifact: AgentSqlArtifact | null;
  error: string | null;
  resolvedEffort: Exclude<MigrationEffort, "auto"> | null;
};

const initialMigrationAgentState: MigrationAgentModeState = {
  isActive: false,
  isConnecting: false,
  isConnected: false,
  isRunning: false,
  isCancelling: false,
  streamingText: '',
  statusMessage: null,
  toolExecutions: [],
  traceEvents: [],
  pendingPermission: null,
  reviewItems: [],
  reviewContextHash: '',
  reviewArtifact: null,
  error: null,
  resolvedEffort: null,
};

function planTodosFromEvent(event: MigrationAgentTraceEvent | undefined): MigrationPlanTodo[] {
  if (!event || !Array.isArray(event.details.todos)) return [];
  return event.details.todos
    .filter((item): item is Record<string, unknown> => !!item && typeof item === "object")
    .map((item) => ({
      content: String(item.content ?? item.label ?? "Planned work"),
      status: String(item.status ?? "pending").toLowerCase(),
    }));
}

function latestPlanEvent(events: MigrationAgentTraceEvent[]): MigrationAgentTraceEvent | undefined {
  return [...events].reverse().find((event) => event.kind === "plan" || Array.isArray(event.details.todos));
}

function activeExecutionLabel(events: MigrationAgentTraceEvent[], fallback: string | null): string {
  const activeTodo = planTodosFromEvent(latestPlanEvent(events)).find((todo) => todo.status === "in_progress");
  if (activeTodo) return activeTodo.content;
  const runningEvent = [...events].reverse().find((event) => event.status === "running" && event.kind !== "run" && event.kind !== "plan");
  return runningEvent?.label || fallback || "Starting agent";
}

function MigrationPlanRows({ event, running }: { event: MigrationAgentTraceEvent; running: boolean }) {
  const todos = planTodosFromEvent(event);
  if (!todos.length) return null;
  return (
    <AiaBox sx={{ px: 1.25, py: 1.1 }}>
      <AiaStack spacing={0.8}>
        {todos.map((todo, index) => {
          const completed = todo.status === "completed";
          const active = todo.status === "in_progress";
          return (
            <AiaBox
              key={`${event.traceId}-plan-${index}`}
              sx={{
                position: "relative",
                overflow: "hidden",
                borderRadius: 1,
                px: active ? 0.85 : 0,
                py: active ? 0.65 : 0.15,
                ml: active ? -0.85 : 0,
                backgroundColor: active ? "color-mix(in srgb, var(--aia-button-color) 7%, #ffffff)" : "transparent",
                borderLeft: active ? "2px solid var(--aia-button-color)" : "2px solid transparent",
              }}
            >
              {active && running ? (
                <AiaBox
                  aria-hidden="true"
                  sx={{
                    position: "absolute",
                    inset: 0,
                    width: "38%",
                    background: "linear-gradient(90deg, transparent, color-mix(in srgb, var(--aia-button-color) 15%, transparent), transparent)",
                    animation: "agentStepSweep 1.8s ease-in-out infinite",
                    "@keyframes agentStepSweep": {
                      from: { transform: "translateX(-120%)" },
                      to: { transform: "translateX(360%)" },
                    },
                  }}
                />
              ) : null}
              <AiaStack direction="row" spacing={0.85} sx={{ position: "relative", alignItems: "flex-start" }}>
                <AiaBox
                  sx={{
                    mt: 0.28,
                    width: 14,
                    height: 14,
                    borderRadius: "50%",
                    display: "grid",
                    placeItems: "center",
                    flexShrink: 0,
                    border: completed ? "none" : `1px solid ${active ? "var(--aia-button-color)" : "#94a3b8"}`,
                    backgroundColor: completed ? "var(--aia-button-color)" : "#ffffff",
                    color: "#ffffff",
                  }}
                >
                  {completed ? "✓" : active && running ? (
                    <AiaBox sx={{ width: 6, height: 2, borderRadius: 999, backgroundColor: "var(--aia-button-color)" }} />
                  ) : null}
                </AiaBox>
                <AiaText
                  sx={{
                    fontSize: 11.75,
                    lineHeight: 1.45,
                    fontWeight: active ? 750 : 500,
                    color: completed ? "#64748b" : active ? "#0f172a" : "#475569",
                    textDecoration: completed ? "line-through" : "none",
                  }}
                >
                  {todo.content}
                </AiaText>
              </AiaStack>
            </AiaBox>
          );
        })}
      </AiaStack>
    </AiaBox>
  );
}

function planRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

function planList(value: unknown): string[] {
  return Array.isArray(value)
    ? value.map((item) => typeof item === "string" ? item : JSON.stringify(item)).filter(Boolean)
    : [];
}

function planRecords(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.map(planRecord).filter((item) => Object.keys(item).length > 0) : [];
}

function planTableLabel(value: unknown): string {
  if (typeof value === "string") return value;
  const table = planRecord(value);
  return [table.database, table.schema, table.table].filter(Boolean).map(String).join(".");
}

function PlanName({ value, fallback = "—" }: { value: unknown; fallback?: string }) {
  const full = planTableLabel(value);
  const parts = full.split(".");
  return <AiaBox sx={{ minWidth: 0, overflowWrap: "anywhere" }}>
    <AiaText sx={{ fontSize: 12, fontWeight: 750, color: "#0f172a", lineHeight: 1.3 }}>
      {parts.pop() || fallback}
    </AiaText>
    {parts.length > 0 && <AiaText sx={{ fontSize: 10, color: "#64748b", lineHeight: 1.35 }}>
      {parts.join(" · ")}
    </AiaText>}
  </AiaBox>;
}

function PlanDataTable({ title, headers, rows, empty }: {
  title: string; headers: string[]; rows: React.ReactNode[][]; empty: string;
}) {
  return <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #e2e8f0" }}>
    <AiaText sx={{ mb: 0.65, fontSize: 12, fontWeight: 800, color: "#334155" }}>{title}</AiaText>
    {rows.length ? <AiaBox sx={{ width: "100%", overflowX: "auto", border: "1px solid #e2e8f0", borderRadius: 1 }}>
      <AiaBox component="table" sx={{ width: "100%", minWidth: 480, borderCollapse: "collapse", tableLayout: "fixed" }}>
        <AiaBox component="thead" sx={{ backgroundColor: "#f8fafc" }}>
          <AiaBox component="tr">{headers.map((header) => <AiaBox component="th" scope="col" key={header} sx={{ px: 1, py: 0.7, textAlign: "left", fontSize: 10, fontWeight: 800, color: "#64748b", borderBottom: "1px solid #e2e8f0" }}>{header}</AiaBox>)}</AiaBox>
        </AiaBox>
        <AiaBox component="tbody">{rows.map((cells, index) => <AiaBox component="tr" key={index} sx={{ borderBottom: index === rows.length - 1 ? "none" : "1px solid #e2e8f0" }}>
          {cells.map((cell, cellIndex) => <AiaBox component="td" key={cellIndex} sx={{ px: 1, py: 0.75, verticalAlign: "top", fontSize: 11, color: "#334155", lineHeight: 1.4, overflowWrap: "anywhere" }}>{cell}</AiaBox>)}
        </AiaBox>)}</AiaBox>
      </AiaBox>
    </AiaBox> : <AiaText sx={{ fontSize: 11, color: "#64748b" }}>{empty}</AiaText>}
  </AiaBox>;
}

function MigrationPlanApprovalSummary({ plan }: { plan: Record<string, unknown> }) {
  const project = planRecord(plan.project_decision);
  const preparation = planRecord(plan.source_preparation);
  const autoMap = planRecord(plan.auto_map);
  const drivingSource = String(preparation.driving_source ?? "To be selected from verified evidence");
  const target = String(preparation.target_table ?? autoMap.target_table ?? "To be selected from verified evidence");
  const supportingSources = planList(preparation.supporting_sources);
  const specialists = planList(autoMap.required_specialists ?? plan.agents);
  const validation = planList(autoMap.validation_gates ?? plan.validation_plan);
  const writes = planList(plan.planned_writes);
  const risks = planList(plan.risks);
  const executionSteps = planRecords(plan.execution_steps).sort(
    (left, right) => Number(left.sequence ?? 0) - Number(right.sequence ?? 0),
  );
  const relationships = planRecords(preparation.relationships);
  const derivedSources = planRecords(preparation.derived_sources);
  const valueBindings = planRecords(preparation.value_bindings);
  const targetColumns = planList(autoMap.target_columns);
  const mappingEvidence = planRecords(autoMap.mapping_evidence);
  const evidenceGaps = new Set(planList(autoMap.evidence_gaps).map((value) => value.toUpperCase()));
  const classifications = planRecord(autoMap.mapping_classifications);
  const selectedColumns = planRecord(preparation.selected_columns_by_table);
  const sourceRationale = planRecord(preparation.source_rationale);
  const precedent = planRecord(preparation.precedent_reference);

  const sourceRows: React.ReactNode[][] = [drivingSource, ...supportingSources].map((table, index) => [
    index === 0 ? "Driving" : "Supporting",
    <PlanName key={table} value={table} />,
    planList(selectedColumns[table]).length ? planList(selectedColumns[table]).join(", ") : "Columns to verify",
    String(sourceRationale[table] ?? (index === 0 ? "Defines the target row" : "Supporting evidence")),
  ]);
  const resultRows: React.ReactNode[][] = [[
    <PlanName key={target} value={target} />,
    `${targetColumns.length} target columns`,
    `${mappingEvidence.length} mapping candidates`,
    evidenceGaps.size ? `${evidenceGaps.size} evidence gaps` : "Pending validation",
  ]];
  const mappingRows: React.ReactNode[][] = targetColumns.map((column) => {
    const candidates = mappingEvidence.filter((item) => String(item.target_column ?? "").toUpperCase() === column.toUpperCase());
    return [
      <PlanName key={column} value={column} />,
      candidates.length ? <AiaStack key={`${column}-sources`} spacing={0.4}>{candidates.map((item, index) =>
        <AiaBox key={index}>{planList(item.source_columns).length
          ? planList(item.source_columns).map((sourceColumn) => <PlanName key={sourceColumn} value={sourceColumn} />)
          : String(item.mapping_mode ?? "Candidate rule")}</AiaBox>)}</AiaStack> : "Specialist research required",
      String(classifications[column] ?? classifications[column.toUpperCase()] ?? "To classify"),
      evidenceGaps.has(column.toUpperCase()) ? "Evidence gap" : candidates.length
        ? candidates.map((item) => String(item.approval_state ?? item.evidence_source ?? "Unverified")).join(" · ")
        : "Unverified",
    ];
  });
  const joinRows: React.ReactNode[][] = relationships.map((relationship) => [
    <PlanName key="left" value={relationship.left_table} />,
    planRecords(relationship.conditions).map((condition) => {
      const left = String(condition.left_column ?? "?");
      const right = String(condition.right_column ?? "?");
      const alias = String(relationship.normalized_lookup_alternative ?? "");
      return alias ? `${left} matches ${right} or ${alias} (trim/uppercase)` : `${left} = ${right}`;
    }).join(" AND ") || "Keys to verify",
    <PlanName key="right" value={relationship.right_table} />,
    String(relationship.join_type ?? "JOIN"),
  ]);
  const cteRows: React.ReactNode[][] = derivedSources.map((derived) => [
    <PlanName key="name" value={derived.name} />,
    planList(derived.base_source_tables).map((table) => <PlanName key={table} value={table} />),
    String(derived.purpose ?? "Historical candidate"),
  ]);

  return (
    <AiaBox
      sx={{
        mt: 1,
        overflow: "hidden",
        border: "1px solid #fde68a",
        borderRadius: 1.5,
        backgroundColor: "#ffffff",
      }}
    >
      <AiaBox sx={{ px: 1.25, py: 0.8, borderBottom: "1px solid #fef3c7", backgroundColor: "#fffbeb" }}>
        <AiaText sx={{ fontSize: 11.5, fontWeight: 800, color: "#78350f" }}>
          Plan revision {String(plan.revision ?? 1)} · {String(plan.plan_hash ?? "pending hash").slice(0, 14)}
        </AiaText>
      </AiaBox>
      <AiaBox sx={{ px: 1.25, py: 0.8 }}>
        <AiaText sx={{ fontSize: 11, color: "#475569" }}>
          Project: {String(project.project_id ?? project.operation ?? "Create a draft")}
          {precedent.sttm_id ? ` · Precedent STTM ${String(precedent.sttm_id)} (${String(precedent.status ?? "unverified")})` : ""}
        </AiaText>
        <AiaText sx={{ mt: 0.25, fontSize: 10.5, color: "#64748b" }}>
          Sources, joins, and mappings below are proposed for review. {specialists.length ? `Specialists: ${specialists.join(", ")}.` : ""}
        </AiaText>
      </AiaBox>
      <PlanDataTable title="Source tables" headers={["Role", "Table", "Selected columns", "Reason"]} rows={sourceRows} empty="No sources selected" />
      <PlanDataTable title="Result table" headers={["Target", "Columns", "Mappings", "Readiness"]} rows={resultRows} empty="No result table selected" />
      <PlanDataTable title={`Column mappings · ${targetColumns.length}`} headers={["Target column", "Source column or rule", "Classification", "Evidence"]} rows={mappingRows} empty="Target columns will be researched" />
      <PlanDataTable title={`Joins · ${relationships.length}`} headers={["From table", "Join keys", "To table", "Type"]} rows={joinRows} empty="No verified joins in this plan" />
      <PlanDataTable title={`Derived CTEs · ${derivedSources.length}`} headers={["CTE", "Source tables", "Purpose"]} rows={cteRows} empty="No derived CTE is planned" />
      {derivedSources.some((derived) => typeof derived.sql === "string" && derived.sql.trim()) &&
        <AiaBox sx={{ px: 1.25, pb: 1 }}>
          {derivedSources.filter((derived) => typeof derived.sql === "string" && derived.sql.trim()).map((derived, index) =>
            <AiaBox component="details" key={`${String(derived.name ?? "cte")}-${index}`} sx={{ mt: 0.5, fontSize: 11 }}>
              <AiaBox component="summary" sx={{ cursor: "pointer", fontWeight: 700 }}>{String(derived.name ?? "CTE")} SQL</AiaBox>
              <AiaBox component="pre" sx={{ p: 1, maxHeight: 200, overflow: "auto", whiteSpace: "pre-wrap", backgroundColor: "#0f172a", color: "#e2e8f0", fontSize: 10 }}>{String(derived.sql)}</AiaBox>
            </AiaBox>)}
        </AiaBox>}
      {valueBindings.length > 0 ? <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #f1f5f9" }}>
        <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Firm and project values · {valueBindings.length}</AiaText>
        {valueBindings.map((binding) => <AiaText key={String(binding.name)} sx={{ mt: 0.45, fontSize: 10.5, lineHeight: 1.45, overflowWrap: "anywhere" }}>
          {String(binding.name)} → {planList(binding.target_columns).join(", ")} · {String(binding.resolution_status ?? "unresolved")}
          {binding.resolved_value != null ? ` · current value ${String(binding.resolved_value)}` : binding.candidate_value != null ? " · historical candidate requires review" : " · value required"}
          {` · ${String(binding.source ?? "unknown source")}`}
        </AiaText>)}
      </AiaBox> : null}
      <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #f1f5f9" }}>
        <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>
          Derived CTE candidates · {derivedSources.length}
        </AiaText>
        {derivedSources.length ? derivedSources.map((derived, index) => (
          <AiaBox key={`${String(derived.name ?? "cte")}-${index}`} sx={{ mt: 0.6 }}>
            <AiaText sx={{ fontSize: 10.75, fontWeight: 700, color: "#334155" }}>
              {String(derived.name ?? "Unnamed CTE")} · {String(derived.purpose ?? "Historical candidate")}
            </AiaText>
            {typeof derived.sql === "string" && derived.sql.trim() ? (
              <AiaBox component="pre" sx={{ mt: 0.35, mb: 0, p: 0.75, maxHeight: 160, overflow: "auto", whiteSpace: "pre-wrap", overflowWrap: "anywhere", backgroundColor: "#0f172a", color: "#e2e8f0", fontSize: 9.5 }}>
                {derived.sql}
              </AiaBox>
            ) : null}
          </AiaBox>
        )) : <AiaText sx={{ mt: 0.3, fontSize: 10.5, color: "#64748b" }}>No derived CTE is planned.</AiaText>}
      </AiaBox>
      {writes.length ? (
        <AiaBox sx={{ px: 1.25, py: 0.8, borderBottom: risks.length ? "1px solid #f1f5f9" : "none" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Planned draft writes</AiaText>
          <AiaText sx={{ mt: 0.2, fontSize: 11, lineHeight: 1.45, color: "#334155" }}>{writes.join(" · ")}</AiaText>
        </AiaBox>
      ) : null}
      {validation.length ? (
        <AiaBox sx={{ px: 1.25, py: 0.8, borderTop: "1px solid #f1f5f9" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Validation gates</AiaText>
          <AiaText sx={{ mt: 0.2, fontSize: 11, lineHeight: 1.45, color: "#334155" }}>{validation.join(" · ")}</AiaText>
        </AiaBox>
      ) : null}
      {executionSteps.length ? (
        <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #f1f5f9" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Step-by-step execution plan</AiaText>
          <AiaText sx={{ mt: 0.2, mb: 0.8, fontSize: 10.5, lineHeight: 1.4, color: "#64748b" }}>
            Plan analysis is read-only. After approval, only run-owned drafts are created or updated.
          </AiaText>
          <AiaStack spacing={0.75}>
            {executionSteps.map((step, index) => {
              const sql = typeof step.sql === "string" ? step.sql.trim() : "";
              const beforeApproval = Boolean(step.runs_before_approval);
              const dynamicSql = Boolean(step.dynamic_sql);
              return (
                <AiaBox key={`${String(step.sequence ?? index)}-${String(step.title ?? "step")}`} sx={{ border: "1px solid #e2e8f0", borderRadius: 1, overflow: "hidden" }}>
                  <AiaBox sx={{ px: 1, py: 0.7, backgroundColor: beforeApproval ? "#f0f9ff" : "#f8fafc" }}>
                    <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#0f172a" }}>
                      {String(step.sequence ?? index + 1)}. {String(step.title ?? "Migration step")}
                    </AiaText>
                    <AiaText sx={{ mt: 0.15, fontSize: 10.5, lineHeight: 1.4, color: "#475569" }}>
                      {String(step.description ?? "")}
                    </AiaText>
                    <AiaText sx={{ mt: 0.35, fontSize: 9.75, fontWeight: 700, color: beforeApproval ? "#0369a1" : "#64748b" }}>
                      {beforeApproval ? "Read-only plan analysis" : "Runs after approval"}
                      {dynamicSql ? " · SQL generated from approved mappings" : ""}
                    </AiaText>
                  </AiaBox>
                  {sql ? (
                    <AiaBox
                      component="pre"
                      sx={{ m: 0, px: 1, py: 0.8, overflowX: "auto", whiteSpace: "pre-wrap", overflowWrap: "anywhere", backgroundColor: "#0f172a", color: "#e2e8f0", fontSize: 10, lineHeight: 1.45, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}
                    >
                      {sql}
                    </AiaBox>
                  ) : null}
                </AiaBox>
              );
            })}
          </AiaStack>
        </AiaBox>
      ) : null}
      {risks.length ? (
        <AiaBox sx={{ px: 1.25, py: 0.8, borderTop: "1px solid #fef3c7", backgroundColor: "#fffbeb" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#92400e" }}>Risks requiring attention</AiaText>
          <AiaText sx={{ mt: 0.2, fontSize: 11, lineHeight: 1.45, color: "#78350f" }}>{risks.join(" · ")}</AiaText>
        </AiaBox>
      ) : null}
      <AiaBox sx={{ px: 1.25, py: 0.8, borderTop: "1px solid #bbf7d0", backgroundColor: "#f0fdf4" }}>
        <AiaText sx={{ fontSize: 10.75, lineHeight: 1.4, fontWeight: 750, color: "#166534" }}>
          Approval does not publish the STTM and does not permit target-table DML.
        </AiaText>
      </AiaBox>
    </AiaBox>
  );
}

function MigrationPlanStatusChip({
  event,
  running,
  needsReview,
  activeLabel,
}: {
  event: MigrationAgentTraceEvent;
  running: boolean;
  needsReview: boolean;
  activeLabel: string;
}) {
  const todos = planTodosFromEvent(event);
  if (!todos.length) return null;
  const activeIndex = todos.findIndex((todo) => todo.status === "in_progress");
  const firstPendingIndex = todos.findIndex((todo) => todo.status !== "completed");
  const currentStep = Math.max(1, (activeIndex >= 0 ? activeIndex : firstPendingIndex >= 0 ? firstPendingIndex : todos.length - 1) + 1);
  const allComplete = todos.every((todo) => todo.status === "completed");

  return (
    <AiaBox
      sx={{
        position: "relative",
        zIndex: 5,
        display: "flex",
        justifyContent: "center",
        px: 1,
        pb: 0.75,
        "&:hover .migration-plan-popover, &:focus-within .migration-plan-popover": {
          opacity: 1,
          visibility: "visible",
          transform: "translate(-50%, 0)",
          pointerEvents: "auto",
        },
      }}
    >
      <AiaButton
        size="small"
        variant="outlined"
        aria-label={`Show execution plan. Step ${currentStep} of ${todos.length}: ${activeLabel}`}
        sx={{
          maxWidth: "92%",
          minHeight: 30,
          px: 1.25,
          borderRadius: 999,
          borderColor: "#cbd5e1",
          backgroundColor: "#ffffff",
          color: "#334155",
          textTransform: "none",
          boxShadow: "0 2px 8px rgba(15, 23, 42, 0.06)",
          "&:hover": { borderColor: "#94a3b8", backgroundColor: "#f8fafc" },
        }}
      >
        <AiaStack direction="row" spacing={0.75} sx={{ minWidth: 0, alignItems: "center" }}>
          {running ? (
            <AiaBox sx={{ width: 16, height: 3, borderRadius: 999, overflow: "hidden", backgroundColor: "#dbe2ea", flexShrink: 0 }}>
              <AiaBox
                aria-hidden="true"
                sx={{
                  width: "55%",
                  height: "100%",
                  borderRadius: 999,
                  backgroundColor: "var(--aia-button-color)",
                  animation: "agentPlanChipSweep 1.45s ease-in-out infinite alternate",
                  "@keyframes agentPlanChipSweep": {
                    from: { transform: "translateX(0)" },
                    to: { transform: "translateX(82%)" },
                  },
                }}
              />
            </AiaBox>
          ) : (
            <AiaBox sx={{ color: needsReview ? "#b45309" : allComplete ? "#15803d" : "#64748b", fontSize: 12, fontWeight: 800, lineHeight: 1 }}>
              {needsReview ? "!" : allComplete ? "✓" : "·"}
            </AiaBox>
          )}
          <AiaText sx={{ fontSize: 11.5, fontWeight: 750, whiteSpace: "nowrap" }}>
            Step {currentStep} / {todos.length}
          </AiaText>
          <AiaText noWrap sx={{ minWidth: 0, maxWidth: 190, fontSize: 11, color: "#64748b" }}>
            · {running ? activeLabel : needsReview ? "Needs review" : allComplete ? "Complete" : "Stopped"}
          </AiaText>
        </AiaStack>
      </AiaButton>
      <AiaPaper
        className="migration-plan-popover"
        role="tooltip"
        elevation={8}
        sx={{
          position: "absolute",
          left: "50%",
          bottom: "calc(100% + 6px)",
          width: "min(430px, calc(100vw - 40px))",
          maxHeight: "min(430px, 55vh)",
          overflowY: "auto",
          overscrollBehavior: "contain",
          opacity: 0,
          visibility: "hidden",
          pointerEvents: "none",
          transform: "translate(-50%, 6px)",
          transition: "opacity 140ms ease, transform 140ms ease, visibility 140ms ease",
          border: "1px solid #dbe2ea",
          borderRadius: 2,
          backgroundColor: "#ffffff",
        }}
      >
        <AiaBox sx={{ px: 1.5, pt: 1.25 }}>
          <AiaText sx={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>Execution plan</AiaText>
          <AiaText sx={{ mt: 0.15, fontSize: 10.5, color: "#64748b" }}>
            {running ? `Currently working on ${activeLabel}` : needsReview ? "Execution stopped for review; remaining steps were not run." : allComplete ? "All planned steps are complete." : "Execution stopped before all steps completed."}
          </AiaText>
        </AiaBox>
        <MigrationPlanRows event={event} running={running} />
      </AiaPaper>
    </AiaBox>
  );
}

function MigrationRunStatusChip({ label }: { label: string }) {
  return (
    <AiaBox sx={{ display: "flex", justifyContent: "center", px: 1, pb: 0.75 }}>
      <AiaPaper
        elevation={0}
        role="status"
        aria-live="polite"
        sx={{
          position: "relative",
          maxWidth: "92%",
          minHeight: 30,
          px: 1.25,
          display: "flex",
          alignItems: "center",
          overflow: "hidden",
          borderRadius: 999,
          border: "1px solid #cbd5e1",
          backgroundColor: "#ffffff",
          boxShadow: "0 2px 8px rgba(15, 23, 42, 0.06)",
        }}
      >
        <AiaBox
          aria-hidden="true"
          sx={{
            position: "absolute",
            inset: 0,
            width: "36%",
            background: "linear-gradient(90deg, transparent, color-mix(in srgb, var(--aia-button-color) 12%, transparent), transparent)",
            animation: "agentRunStatusSweep 1.6s ease-in-out infinite",
            "@keyframes agentRunStatusSweep": {
              from: { transform: "translateX(-120%)" },
              to: { transform: "translateX(360%)" },
            },
          }}
        />
        <AiaStack direction="row" spacing={0.75} sx={{ position: "relative", minWidth: 0, alignItems: "center" }}>
          <AiaBox sx={{ width: 16, height: 3, borderRadius: 999, overflow: "hidden", backgroundColor: "#dbe2ea", flexShrink: 0 }}>
            <AiaBox sx={{ width: "55%", height: "100%", borderRadius: 999, backgroundColor: "var(--aia-button-color)" }} />
          </AiaBox>
          <AiaText noWrap sx={{ minWidth: 0, maxWidth: 280, fontSize: 11.5, fontWeight: 750, color: "#334155" }}>
            {label}
          </AiaText>
        </AiaStack>
      </AiaPaper>
    </AiaBox>
  );
}

function MigrationTraceTree({
  events,
  parentTraceId = null,
  depth = 0,
}: {
  events: MigrationAgentTraceEvent[];
  parentTraceId?: string | null;
  depth?: number;
}) {
  const knownTraceIds = new Set(events.map((event) => event.traceId));
  const nodes = events.filter((event) =>
    event.parentTraceId === parentTraceId
    || (parentTraceId === null && event.parentTraceId !== null && !knownTraceIds.has(event.parentTraceId)),
  );
  if (!nodes.length) return null;
  return (
    <AiaStack spacing={0.5} sx={{ pl: depth ? 1.5 : 0 }}>
      {nodes.map((event) => {
        const children = events.some((candidate) => candidate.parentTraceId === event.traceId);
        const detailEntries = Object.entries(event.details).filter(([key, value]) => key !== "todos" && value !== undefined && value !== null);
        const expandable = children || detailEntries.length > 0;
        return (
          <AiaBox
            key={event.traceId}
            component={expandable ? "details" : "div"}
            sx={{ borderLeft: depth ? "1px solid #dbe2ea" : "none", pl: depth ? 1 : 0 }}
          >
            <AiaBox
              component={expandable ? "summary" : "div"}
              sx={{ cursor: expandable ? "pointer" : "default", listStyle: "none", py: 0.5 }}
            >
              <AiaStack direction="row" spacing={0.8} sx={{ alignItems: "center" }}>
                {event.status === "running" ? (
                  <AiaBox
                    sx={{
                      width: 8,
                      height: 8,
                      borderRadius: "50%",
                      flexShrink: 0,
                      backgroundColor: "var(--aia-button-color)",
                      animation: "agentEventPulse 1.25s ease-in-out infinite alternate",
                      "@keyframes agentEventPulse": { from: { opacity: 0.35 }, to: { opacity: 1 } },
                    }}
                  />
                ) : (
                  <AiaBox sx={{ width: 8, height: 8, borderRadius: "50%", flexShrink: 0, backgroundColor: event.status === "succeeded" ? "#22c55e" : event.status === "needs_review" ? "#f59e0b" : event.status === "failed" ? "#ef4444" : "#64748b" }} />
                )}
                <AiaText sx={{ fontSize: 12, fontWeight: 700, color: "var(--aia-primary-text-color)" }}>{event.label}</AiaText>
                <AiaText sx={{ fontSize: 11, color: "#64748b" }}>{event.kind}</AiaText>
              </AiaStack>
              <AiaText sx={{ ml: 2, fontSize: 11, color: "#6b7280" }}>{event.summary}</AiaText>
            </AiaBox>
            {detailEntries.length > 0 && (
              <AiaBox sx={{ ml: 2, my: 0.5, p: 1, maxHeight: 220, borderRadius: 1, backgroundColor: "#1f2937", color: "#e5e7eb", fontFamily: "monospace", fontSize: 10, whiteSpace: "pre-wrap", overflow: "auto", overscrollBehavior: "contain" }}>
                {detailEntries.map(([key, value]) => `${key}: ${typeof value === "string" ? value : JSON.stringify(value, null, 2)}`).join("\n")}
              </AiaBox>
            )}
            {children && <MigrationTraceTree events={events} parentTraceId={event.traceId} depth={depth + 1} />}
          </AiaBox>
        );
      })}
    </AiaStack>
  );
}

function formatInterpretationMessage(content: string) {
  const normalized = content.replace(/\r\n/g, "\n").trim();
  const prefix = "This is our interpretation of your question:";
  if (!normalized.startsWith(prefix)) {
    return content;
  }

  const body = normalized.slice(prefix.length).trim();
  if (!body) return content;

  const sentences = body
    .split(/(?<=[.!?])\s+/)
    .map((sentence) => sentence.trim())
    .filter(Boolean);

  if (sentences.length === 0) return content;

  const lines = ["## Interpretation"];
  if (sentences[0]) {
    lines.push(`- **Goal:** ${sentences[0]}`);
  }
  if (sentences[1]) {
    lines.push(`- **Approach:** ${sentences[1]}`);
  }
  if (sentences.length > 2) {
    lines.push(`- **Notes:** ${sentences.slice(2).join(" ")}`);
  }
  return lines.join("\n");
}

function MessageContent({ content, formatPlainText = false }: { content: string; formatPlainText?: boolean }) {
  const normalized = formatInterpretationMessage(content).replace(/\r\n/g, "\n").trim();
  void formatPlainText;
  return (
    <AiaBox
      sx={{
        minWidth: 0,
        maxWidth: "100%",
        overflowX: "hidden",
        overflowWrap: "anywhere",
        wordBreak: "break-word",
      }}
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ children }) => <AiaText component="h1" sx={{ m: 0, mb: 1.25, fontSize: 19, lineHeight: 1.3, fontWeight: 800, color: "#0f172a" }}>{children}</AiaText>,
          h2: ({ children }) => <AiaText component="h2" sx={{ mt: 2.25, mb: 1, pb: 0.75, borderBottom: "1px solid #e2e8f0", fontSize: 16, lineHeight: 1.35, fontWeight: 800, color: "#0f172a", "&:first-of-type": { mt: 0 } }}>{children}</AiaText>,
          h3: ({ children }) => <AiaText component="h3" sx={{ mt: 1.75, mb: 0.75, fontSize: 13, lineHeight: 1.4, fontWeight: 800, letterSpacing: "0.045em", textTransform: "uppercase", color: "#334155" }}>{children}</AiaText>,
          p: ({ children }) => <AiaText component="p" sx={{ my: 1, fontSize: 13.5, lineHeight: 1.7, color: "#334155", "&:first-of-type": { mt: 0 }, "&:last-child": { mb: 0 } }}>{children}</AiaText>,
          strong: ({ children }) => <AiaBox component="strong" sx={{ fontWeight: 800, color: "#0f172a" }}>{children}</AiaBox>,
          em: ({ children }) => <AiaBox component="em" sx={{ color: "#475569" }}>{children}</AiaBox>,
          ul: ({ children }) => <AiaBox component="ul" sx={{ my: 1.1, pl: 2.5, display: "grid", gap: 0.55, color: "#334155", "& ::marker": { color: "var(--aia-button-color)" } }}>{children}</AiaBox>,
          ol: ({ children }) => <AiaBox component="ol" sx={{ my: 1.1, pl: 2.75, display: "grid", gap: 0.55, color: "#334155", "& ::marker": { color: "var(--aia-button-color)", fontWeight: 700 } }}>{children}</AiaBox>,
          li: ({ children }) => <AiaBox component="li" sx={{ pl: 0.25, fontSize: 13.5, lineHeight: 1.65, "& > p": { my: 0 } }}>{children}</AiaBox>,
          blockquote: ({ children }) => <AiaBox component="blockquote" sx={{ my: 1.5, mx: 0, px: 1.5, py: 0.75, borderLeft: "3px solid var(--aia-button-color)", borderRadius: "0 8px 8px 0", backgroundColor: "#f8fafc", color: "#334155", "& > p": { my: 0 } }}>{children}</AiaBox>,
          table: ({ children }) => <AiaBox sx={{ my: 1.5, maxWidth: "100%", overflowX: "auto", border: "1px solid #dbe2ea", borderRadius: 1.5, "& td code": { fontSize: 10, color: "#64748b", backgroundColor: "transparent", p: 0 } }}><AiaBox component="table" sx={{ width: "100%", minWidth: 520, borderCollapse: "collapse", fontSize: 12 }}>{children}</AiaBox></AiaBox>,
          thead: ({ children }) => <AiaBox component="thead" sx={{ backgroundColor: "#f1f5f9" }}>{children}</AiaBox>,
          th: ({ children }) => <AiaBox component="th" sx={{ px: 1.25, py: 1, borderBottom: "1px solid #cbd5e1", textAlign: "left", verticalAlign: "top", fontWeight: 800, color: "#0f172a", whiteSpace: "nowrap" }}>{children}</AiaBox>,
          td: ({ children }) => <AiaBox component="td" sx={{ px: 1.25, py: 1, borderBottom: "1px solid #e2e8f0", textAlign: "left", verticalAlign: "top", color: "#334155", overflowWrap: "anywhere" }}>{children}</AiaBox>,
          pre: ({ children }) => <AiaBox component="pre" sx={{ my: 1.5, p: 1.5, maxWidth: "100%", overflowX: "auto", borderRadius: 1.5, border: "1px solid #334155", backgroundColor: "#111827", color: "#e5e7eb", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 11.5, lineHeight: 1.65, whiteSpace: "pre" }}>{children}</AiaBox>,
          code: ({ children }) => <AiaBox component="code" sx={{ px: 0.55, py: 0.15, borderRadius: 0.75, backgroundColor: "#f1f5f9", color: "#334155", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: "0.9em", "pre &": { p: 0, backgroundColor: "transparent", color: "inherit", fontSize: "inherit" } }}>{children}</AiaBox>,
          a: ({ href, children }) => <AiaBox component="a" href={href} target="_blank" rel="noreferrer" sx={{ color: "var(--aia-button-color)", fontWeight: 700, textDecoration: "underline", textUnderlineOffset: 2 }}>{children}</AiaBox>,
          hr: () => <AiaBox component="hr" sx={{ my: 2, border: 0, borderTop: "1px solid #e2e8f0" }} />,
          input: (props) => <input {...props} disabled style={{ marginRight: 7, accentColor: "var(--aia-button-color)" }} />,
        }}
      >
        {normalized}
      </ReactMarkdown>
    </AiaBox>
  );
}

function TypewriterMessageContent({
  content,
  animate,
  messageId,
  onComplete,
  onProgress,
}: {
  content: string;
  animate: boolean;
  messageId: string;
  onComplete: (messageId: string) => void;
  onProgress: () => void;
}) {
  const [visibleLength, setVisibleLength] = useState(animate ? 0 : content.length);

  useEffect(() => {
    if (!animate || !content) return;
    const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    let animationFrame = 0;
    if (reduceMotion) {
      animationFrame = window.requestAnimationFrame(() => {
        setVisibleLength(content.length);
        onComplete(messageId);
      });
      return () => window.cancelAnimationFrame(animationFrame);
    }

    const startedAt = performance.now();
    // Keep short updates visibly character-streamed while preventing a long,
    // Markdown-rich final answer from taking minutes to finish rendering.
    const durationMs = Math.min(8_000, Math.max(320, content.length * 11));
    const reveal = (now: number) => {
      const progress = Math.min(1, (now - startedAt) / durationMs);
      const nextLength = Math.min(content.length, Math.max(1, Math.ceil(content.length * progress)));
      setVisibleLength(nextLength);
      onProgress();
      if (progress < 1) {
        animationFrame = window.requestAnimationFrame(reveal);
      } else {
        onComplete(messageId);
      }
    };

    animationFrame = window.requestAnimationFrame(reveal);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [animate, content, messageId, onComplete, onProgress]);

  const typing = animate && visibleLength < content.length;
  return <MessageContent content={`${content.slice(0, visibleLength)}${typing ? "▌" : ""}`} />;
}

function buildSignalUnderstandingText(signal: {
  attributes?: Record<string, unknown>;
  message?: string;
}) {
  const value = signal.attributes?.current_understanding;
  if (typeof value === "string" && value.trim()) {
    const understanding = value.trim();
    const normalize = (text: string) =>
      text
        .toLowerCase()
        .replace(/[`*_#>]/g, "")
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
    const normalizedUnderstanding = normalize(understanding);
    const normalizedMessage = normalize(signal.message ?? "");
    const repeatsMessage =
      normalizedUnderstanding.length >= 48 &&
      (normalizedMessage === normalizedUnderstanding ||
        normalizedMessage.includes(normalizedUnderstanding) ||
        normalizedUnderstanding.includes(normalizedMessage));
    return repeatsMessage ? null : understanding;
  }
  return null;
}

function shouldSuppressSignalForCurrentState(
  signal: {
    attributes?: Record<string, unknown>;
  },
  relationshipCount: number,
) {
  if (relationshipCount === 0) return false;
  const actionType = typeof signal.attributes?.action_type === "string" ? signal.attributes.action_type : "";
  return actionType === "refresh_semantic_context";
}

function StreamingProgressIndicator({
  phase,
  message,
  elapsedSeconds,
}: {
  phase?: StreamingStatusPhase | null;
  message?: string | null;
  elapsedSeconds?: number | null;
}) {
  const label = phase ? STATUS_PHASE_LABELS[phase] : "Working...";
  const progress = phase ? STATUS_PHASE_PROGRESS[phase] : 50;

  return (
    <AiaStack spacing={1} sx={{ mt: 1.25 }}>
      <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
        <AiaCircularProgress
          size={16}
          thickness={5}
          variant="determinate"
          value={progress}
          sx={{ color: "#2563eb" }}
        />
        <AiaText variant="caption" sx={{ color: "#1d4ed8", fontWeight: 600 }}>
          {label}
        </AiaText>
        {elapsedSeconds != null && elapsedSeconds > 0 ? (
          <AiaText variant="caption" sx={{ color: "#94a3b8", fontSize: 11 }}>
            ({Math.round(elapsedSeconds)}s)
          </AiaText>
        ) : null}
      </AiaStack>
      {message && message !== label ? (
        <AiaText variant="caption" sx={{ color: "#64748b", fontSize: 12, lineHeight: 1.4 }}>
          {message}
        </AiaText>
      ) : null}
      <AiaBox sx={{ width: "100%", height: 3, backgroundColor: "#e2e8f0", borderRadius: 2, overflow: "hidden" }}>
        <AiaBox
          sx={{
            width: `${progress}%`,
            height: "100%",
            backgroundColor: "#2563eb",
            borderRadius: 2,
            transition: "width 0.3s ease-in-out",
          }}
        />
      </AiaBox>
    </AiaStack>
  );
}

function TracePanel({
  messageId,
  steps,
  expanded,
  onToggle,
}: {
  messageId: string;
  steps: string[];
  expanded: boolean;
  onToggle: (messageId: string) => void;
}) {
  return (
    <AiaBox
      sx={{
        mt: 1.25,
        borderRadius: 1.5,
        border: "1px solid #e2e8f0",
        backgroundColor: "#f8fafc",
        overflow: "hidden",
      }}
    >
      <AiaButton
        onClick={() => onToggle(messageId)}
        variant="text"
        sx={{
          width: "100%",
          px: 1.25,
          py: 0.9,
          justifyContent: "space-between",
          textTransform: "none",
          color: "#334155",
          borderRadius: 0,
          "&:hover": { backgroundColor: "#f1f5f9" },
        }}
      >
        <AiaStack direction="row" spacing={0.75} sx={{ alignItems: "center" }}>
          {expanded ? (
            <KeyboardArrowDownIcon sx={{ fontSize: 16, color: "#64748b" }} />
          ) : (
            <KeyboardArrowRightIcon sx={{ fontSize: 16, color: "#64748b" }} />
          )}
          <AiaText sx={{ fontSize: 12, fontWeight: 700, color: "#334155" }}>
            Execution
          </AiaText>
          <AiaText sx={{ fontSize: 12, color: "#64748b" }}>
            {steps.length} step{steps.length === 1 ? "" : "s"}
          </AiaText>
        </AiaStack>
      </AiaButton>
      {expanded ? (
        <AiaStack spacing={0.8} sx={{ px: 1.5, pb: 1.25, pt: 0.25 }}>
          {steps.map((step, stepIndex) => (
            <AiaStack
              key={`${messageId}-trace-${stepIndex}`}
              direction="row"
              spacing={1}
              sx={{ alignItems: "flex-start" }}
            >
              <AiaBox
                sx={{
                  mt: 0.6,
                  width: 5,
                  height: 5,
                  borderRadius: "50%",
                  backgroundColor: "#94a3b8",
                  flexShrink: 0,
                }}
              />
              <AiaText sx={{ fontSize: 12, lineHeight: 1.6, color: "#475569" }}>
                {step}
              </AiaText>
            </AiaStack>
          ))}
        </AiaStack>
      ) : null}
    </AiaBox>
  );
}

export default function AIAgentPanel({
  expanded = false,
  variant = "standalone",
  pageMode = false,
}: {
  expanded?: boolean;
  onToggleExpanded?: () => void;
  variant?: "standalone" | "sidebar";
  pageMode?: boolean;
}) {
  const router = useRouter();
  const {
    assistantSignals,
    firRecommendations,
    firPrimaryQuestion,
    firRecommendationLoading,
    firRecommendationContextKey,
    chatLoading,
    chatMessages,
    dismissPendingDerivedSourceDraft,
    applyPendingAiMappingReview,
    skipPendingAiMappingReview,
    mappingCount,
    openPendingDerivedSourceDraft,
    pendingDerivedSourceDraft,
    pendingAiMappingReviews,
    relationships,
    semanticBundleLabel,
    semanticBundleId,
    semanticBundleHash,
    semanticContextItems,
    semanticLineage,
    semanticDatahubContext,
    learningContextId,
    learningContextHash,
    workspaceContextId,
    workspaceContextHash,
    workspaceContextStatus,
    workspaceContextCacheStatus,
    workspaceContextError,
    semanticLevel,
    semanticStatus,
    semanticViewName,
    selectedSourceCount,
    respondToAssistantSignal,
    requestSemanticRefresh,
    refreshPreparedWorkspaceContext,
    sendChatMessage,
    resetChatSession,
    submitChatFeedback,
    // For Migration Agent snapshot building
    sources,
    targets,
    drivingTableId,
    derivedSources,
    mappings,
    selectedMappingIds,
    session,
    sourceAttributeGroups,
    activeProjectId,
    activeSttmId,
    activeProjectName,
    activeSttmName,
    mappingIntent,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    mappingSql,
    mappingPreviewSql,
    activeMappingId,
  } = useSttmBuilderContext();
  const {
    selectedRecommendationId,
    resolvedRecommendationIds,
    markRecommendationResolved,
    newChatVersion,
    sessions,
    activeSessionId,
  } = useAiChatLayout();
  const pathname = usePathname();
  const [draft, setDraft] = useState("");
  const [otherAnswerOpen, setOtherAnswerOpen] = useState(false);
  const [otherAnswer, setOtherAnswer] = useState("");
  const [greetingSession, setGreetingSession] = useState<UserSession | null>(null);
  const [panelMode, setPanelMode] = useState<"assistant" | "recommendations">("assistant");
  const [pendingCorrectionRecommendation, setPendingCorrectionRecommendation] =
    useState<FIRRecommendation | null>(null);
  const [expandedTraces, setExpandedTraces] = useState<Record<string, boolean>>({});
  const [pendingSignalResponses, setPendingSignalResponses] = useState<Record<string, { optionSelected?: string | null; rating?: number | null; comment: string }>>({});
  const [signalActionBusyId, setSignalActionBusyId] = useState<string | null>(null);
  const messagesRef = useRef<HTMLDivElement | null>(null);
  const shouldAutoScrollRef = useRef(true);
  const shownRecommendationIdsRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    let cancelled = false;
    void authService.getSession()
      .then((current) => { if (!cancelled) setGreetingSession(current); })
      .catch(() => undefined);
    return () => { cancelled = true; };
  }, []);
  const assistantFirstName = useMemo(() => {
    const rawName =
      session?.display_name?.trim()
      || greetingSession?.display_name?.trim()
      || session?.email?.split("@")[0]?.trim()
      || greetingSession?.email?.split("@")[0]?.trim()
      || "";
    const firstToken = rawName.split(/[\s._-]+/).find(Boolean) || "";
    if (!firstToken) return "";
    return `${firstToken.charAt(0).toUpperCase()}${firstToken.slice(1).toLowerCase()}`;
  }, [session?.display_name, session?.email, greetingSession?.display_name, greetingSession?.email]);
  const hasStartedStandardConversation = useMemo(
    () => chatMessages.some((message) => message.role === "user"),
    [chatMessages],
  );
  const visibleStandardChatMessages = useMemo(
    () => (
      hasStartedStandardConversation
        ? chatMessages.filter(
            (message) => !(
              message.role === "assistant"
              && (
                message.id === "sttm-assistant-welcome"
                || message.content.includes(
                  "I can use the selected source and target semantics",
                )
              )
            ),
          )
        : chatMessages
    ),
    [chatMessages, hasStartedStandardConversation],
  );

  // Migration Agent mode state
  const [migrationAgentState, setMigrationAgentState] = useState<MigrationAgentModeState>(initialMigrationAgentState);
  const [reviewQuestionIndex, setReviewQuestionIndex] = useState(0);
  const [reviewDecisionBusy, setReviewDecisionBusy] = useState(false);
  const [reviewDecisionError, setReviewDecisionError] = useState<string | null>(null);
  const [reviewSuggestion, setReviewSuggestion] = useState("");
  const [migrationAgentMessages, setMigrationAgentMessages] = useState<MigrationAgentMessage[]>([]);
  const [expandedToolExecutions, setExpandedToolExecutions] = useState(true);
  const migrationAgentClientRef = useRef<MigrationAgentSessionClient | null>(null);
  const animateMigrationAgentMessagesRef = useRef(false);
  const [migrationAgentAvailable, setMigrationAgentAvailable] = useState<boolean | null>(null); // null = loading
  const [migrationEffort, setMigrationEffort] = useState<MigrationEffort>("medium");
  const [migrationModelName, setMigrationModelName] = useState<string | null>(null);
  const [migrationModelOptions, setMigrationModelOptions] = useState<string[]>([]);
  const [migrationEffortModels, setMigrationEffortModels] = useState<Record<string, string>>({});
  const [migrationRunMode, setMigrationRunMode] = useState<MigrationRunMode>("auto");
  const [planDocument, setPlanDocument] = useState<Record<string, unknown> | null>(null);
  const [planSidebarOpen, setPlanSidebarOpen] = useState(false);
  const [artifactTab, setArtifactTab] = useState<AgentArtifactTab>('plan');
  const [sqlArtifact, setSqlArtifact] = useState<AgentSqlArtifact | null>(null);
  const [artifactVersion, setArtifactVersion] = useState(0);
  const requestedArtifactRef = useRef<AgentArtifactTab | null>(null);
  const researchReport = useMemo(() => [...migrationAgentMessages].reverse().find(
    (message) => message.role === 'assistant' && message.kind === 'final'
      && message.content.includes('## Migration plan research'),
  )?.content ?? '', [migrationAgentMessages]);
  const openReviewArtifact = useCallback((tab: AgentArtifactTab) => {
    if (pageMode) {
      setArtifactTab(tab);
      setPlanSidebarOpen(true);
      return;
    }
    const conversationId = migrationAgentClientRef.current?.getConversationId()
      || sessions.find((session) => session.id === activeSessionId)?.backendConversationId;
    const params = new URLSearchParams({ artifact: tab });
    if (conversationId) params.set('conversation', conversationId);
    router.push(`/ai-agent?${params.toString()}`);
  }, [pageMode, router, sessions, activeSessionId]);
  const [pendingPlanOffer, setPendingPlanOffer] = useState<{ reason: string } | null>(null);
  const [migrationAttachments, setMigrationAttachments] = useState<Array<{ id: string; name: string }>>([]);
  const [migrationAttachmentUploading, setMigrationAttachmentUploading] = useState(false);
  const migrationPlanEvent = useMemo(
    () => latestPlanEvent(migrationAgentState.traceEvents),
    [migrationAgentState.traceEvents],
  );
  const migrationActiveLabel = useMemo(
    () => activeExecutionLabel(migrationAgentState.traceEvents, migrationAgentState.statusMessage),
    [migrationAgentState.statusMessage, migrationAgentState.traceEvents],
  );
  const groupedMigrationAgentMessages = useMemo(() => {
    const groups: Array<{
      role: 'user' | 'assistant';
      id: string;
      messages: MigrationAgentMessage[];
    }> = [];
    for (const message of migrationAgentMessages) {
      const previous = groups[groups.length - 1];
      if (message.role === 'assistant' && previous?.role === 'assistant') {
        previous.messages.push(message);
      } else {
        groups.push({ role: message.role, id: message.id, messages: [message] });
      }
    }
    return groups;
  }, [migrationAgentMessages]);
  const completeMigrationAgentMessageAnimation = useCallback((messageId: string) => {
    setMigrationAgentMessages((messages) => messages.map((message) => (
      message.id === messageId && message.animate
        ? { ...message, animate: false }
        : message
    )));
  }, []);
  const followMigrationAgentMessageAnimation = useCallback(() => {
    const node = messagesRef.current;
    if (!node || !shouldAutoScrollRef.current) return;
    node.scrollTop = node.scrollHeight;
  }, []);

  // Check Migration Agent availability on mount
  useEffect(() => {
    const checkMigrationAgentStatus = async () => {
      const diagnostics = await fetchMigrationAgentDiagnostics();
      setMigrationAgentAvailable(diagnostics.status === "ok" && diagnostics.enabled);
      setMigrationModelOptions(diagnostics.model_options ?? []);
      setMigrationEffortModels(diagnostics.effort_model_defaults ?? {});
    };
    void checkMigrationAgentStatus();
  }, []);

  const statsLabel = useMemo(() => {
    const joinCount = relationships.length;
    const joinLabel = joinCount === 1 ? "1 relationship" : `${joinCount} relationships`;
    return `${selectedSourceCount} tables · ${mappingCount} mappings · ${joinLabel}`;
  }, [mappingCount, relationships.length, selectedSourceCount]);
  const hasStreamingMessage = useMemo(
    () => chatMessages.some((message) => message.isStreaming),
    [chatMessages]
  );
  const activeReview = pendingAiMappingReviews[0] ?? null;
  const isTransformationReview = !!activeReview?.preprocessingRule;
  const activeSignal = useMemo(
    () =>
      assistantSignals.find(
        (signal) =>
          signal.source !== "conversation_agent" &&
          signal.status !== "dismissed" &&
          signal.status !== "responded" &&
          signal.status !== "acknowledged" &&
          !shouldSuppressSignalForCurrentState(signal, relationships.length),
      ) ?? null,
    [assistantSignals, relationships.length],
  );
  const showWelcomeHero =
    (migrationAgentState.isActive ? migrationAgentMessages.length === 0 : !hasStartedStandardConversation)
    && !selectedRecommendationId
    && !activeSignal
    && !activeReview
    && (variant === "sidebar" || panelMode === "assistant");
  const visibleFirRecommendations = useMemo(
    () =>
      firRecommendations.filter(
        (item) =>
          !resolvedRecommendationIds.has(item.recommendation_id),
      ),
    [
      firRecommendations,
      resolvedRecommendationIds,
    ],
  );
  const selectedRecommendation = useMemo(() => {
    if (!selectedRecommendationId) return null;
    if (
      firPrimaryQuestion?.recommendation_id === selectedRecommendationId
      && !resolvedRecommendationIds.has(selectedRecommendationId)
    ) {
      return firPrimaryQuestion;
    }
    return (
      firRecommendations.find(
        (item) =>
          item.recommendation_id === selectedRecommendationId
          && !resolvedRecommendationIds.has(item.recommendation_id),
      ) ?? null
    );
  }, [
    firPrimaryQuestion,
    firRecommendations,
    resolvedRecommendationIds,
    selectedRecommendationId,
  ]);

  const recordRecommendationOutcome = useCallback(
    async (
      recommendation: FIRRecommendation,
      outcomeType: string,
      payload: Record<string, unknown> = {},
    ) => {
      try {
        await recommendationService.recordOutcome(recommendation.recommendation_id, {
          outcome_type: outcomeType,
          context_key: firRecommendationContextKey,
          user_id: session ? String(session.user_id) : null,
          payload,
        });
      } catch (error) {
        console.warn("Could not record FIR recommendation outcome", error);
      }
    },
    [firRecommendationContextKey, session],
  );

  const handleFirRecommendationAction = useCallback(
    async (recommendation: FIRRecommendation, action: FIRRecommendationAction) => {
      if (action.action === "dismiss") {
        markRecommendationResolved(recommendation.recommendation_id);
        await recordRecommendationOutcome(recommendation, "dismissed", {
          action_id: action.id,
          checkpoint: recommendation.checkpoint,
        });
        return;
      }
      if (action.action === "confirm") {
        await recordRecommendationOutcome(recommendation, "accepted", {
          action_id: action.id,
          checkpoint: recommendation.checkpoint,
        });
        markRecommendationResolved(recommendation.recommendation_id);
        return;
      }

      let recommendationWithEvidence = recommendation;
      if (
        action.action === "open_assistant_explanation"
        && !(recommendation.evidence ?? []).length
      ) {
        try {
          recommendationWithEvidence = await recommendationService.get(
            recommendation.recommendation_id,
          );
        } catch (error) {
          console.warn("Could not load detailed FIR evidence", error);
        }
      }
      const evidenceText = (recommendationWithEvidence.evidence ?? [])
        .slice(0, 3)
        .map((item) => `${item.title}: ${item.summary}`)
        .join("\n");
      const prompt =
        action.action === "correct"
          ? `I want to correct this FIR understanding:\n${recommendation.current_understanding || recommendation.display_message}\n\nMy correction is: `
          : `Explain this FIR recommendation in the current mapping context:\n${recommendationWithEvidence.current_understanding || recommendationWithEvidence.display_message}${evidenceText ? `\n\nEvidence:\n${evidenceText}` : recommendationWithEvidence.evidence_summary ? `\n\nEvidence summary:\n${recommendationWithEvidence.evidence_summary}` : ""}`;
      setPanelMode("assistant");
      if (action.action === "correct") {
        setDraft(prompt);
        setPendingCorrectionRecommendation(recommendation);
        await recordRecommendationOutcome(recommendation, "opened", {
          action_id: action.id,
          intent: "correct",
        });
      } else {
        sendChatMessage(prompt);
        await recordRecommendationOutcome(recommendation, "explained", {
          action_id: action.id,
        });
      }
    },
    [markRecommendationResolved, recordRecommendationOutcome, sendChatMessage, setDraft],
  );

  useEffect(() => {
    const newlyShown = visibleFirRecommendations.filter((recommendation) => {
      const shownKey = `${recommendation.recommendation_id}:${recommendation.content_version ?? 1}:${firRecommendationContextKey ?? ""}`;
      if (shownRecommendationIdsRef.current.has(shownKey)) return false;
      shownRecommendationIdsRef.current.add(shownKey);
      return true;
    });
    if (!newlyShown.length) return;
    void recommendationService.recordShownOutcomes(
      newlyShown.map((recommendation) => ({
        recommendation_id: recommendation.recommendation_id,
        context_key: firRecommendationContextKey,
        user_id: session ? String(session.user_id) : null,
        payload: {
          checkpoint: recommendation.checkpoint,
          retrieval_mode: recommendation.retrieval_mode,
        },
      })),
    ).catch((error) => {
      console.warn("Could not record FIR recommendation impressions", error);
    });
  }, [
    firRecommendationContextKey,
    session,
    visibleFirRecommendations,
  ]);

  const renderFirRecommendationCard = (
    recommendation: FIRRecommendation,
    interruptive = false,
  ) => {
    const confidence =
      recommendation.confidence == null
        ? null
        : `${Math.round(recommendation.confidence * 100)}% confidence`;
    const retrievalMode = String(recommendation.retrieval_mode || "structured")
      .replaceAll("_", " ");
    return (
      <AiaPaper
        key={`${recommendation.recommendation_id}:${recommendation.content_version ?? 1}`}
        elevation={0}
        sx={{
          p: 1.5,
          borderRadius: 2,
          border: interruptive ? "1px solid #fecaca" : "1px solid #bfdbfe",
          backgroundColor: interruptive ? "#fff7f7" : "#f8fbff",
        }}
      >
        <AiaStack spacing={1.1}>
          <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
            {interruptive ? (
              <HelpOutlineOutlinedIcon sx={{ fontSize: 18, color: "#dc2626" }} />
            ) : (
              <TipsAndUpdatesOutlinedIcon sx={{ fontSize: 18, color: "#2563eb" }} />
            )}
            <AiaBox sx={{ minWidth: 0, flex: 1 }}>
              <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
                {recommendation.title ||
                  String(recommendation.recommendation_category || "Recommendation")
                    .replaceAll("_", " ")}
              </AiaText>
              <AiaText sx={{ fontSize: 11, color: "#64748b", textTransform: "capitalize" }}>
                {[recommendation.question_id, confidence, retrievalMode].filter(Boolean).join(" · ")}
              </AiaText>
            </AiaBox>
          </AiaStack>

          <AiaText sx={{ fontSize: 13, color: "#334155", lineHeight: 1.55 }}>
            {recommendation.display_message}
          </AiaText>

          {recommendation.current_understanding ? (
            <AiaBox
              sx={{
                px: 1.25,
                py: 1,
                borderRadius: 1.5,
                border: "1px solid #dbeafe",
                backgroundColor: "#ffffff",
              }}
            >
              <AiaText sx={{ fontSize: 11.5, fontWeight: 800, color: "#1d4ed8", mb: 0.4 }}>
                Current understanding
              </AiaText>
              <AiaText sx={{ fontSize: 12.5, color: "#334155", lineHeight: 1.55 }}>
                {recommendation.current_understanding}
              </AiaText>
            </AiaBox>
          ) : null}

          {recommendation.evidence?.length ? (
            <AiaBox sx={{ display: "grid", gap: 0.5 }}>
              <AiaText sx={{ fontSize: 11.5, fontWeight: 800, color: "#475569" }}>
                Evidence
              </AiaText>
              {recommendation.evidence.slice(0, 3).map((evidence) => (
                <AiaText
                  key={evidence.evidence_id}
                  sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.45 }}
                >
                  <strong>{evidence.title}:</strong> {evidence.summary}
                </AiaText>
              ))}
            </AiaBox>
          ) : recommendation.evidence_summary ? (
            <AiaText sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.45 }}>
              <strong>Evidence:</strong> {recommendation.evidence_summary}
            </AiaText>
          ) : (
            <AiaText sx={{ fontSize: 11.5, color: "#94a3b8" }}>
              Semantic-only guidance; no readable evidence item is linked yet.
            </AiaText>
          )}

          <AiaStack direction="row" spacing={0.75} useFlexGap sx={{ flexWrap: "wrap" }}>
            {recommendation.actions.map((action) => (
              <AiaButton
                key={action.id}
                size="small"
                variant={action.action === "confirm" ? "contained" : "outlined"}
                onClick={() => {
                  void handleFirRecommendationAction(recommendation, action);
                }}
                sx={{ textTransform: "none", borderRadius: "999px" }}
              >
                {action.label}
              </AiaButton>
            ))}
          </AiaStack>
        </AiaStack>
      </AiaPaper>
    );
  };

  const handleSend = (rawMessage?: string): boolean => {
    const message = (typeof rawMessage === "string" ? rawMessage : draft).trim();
    if (!message) return false;

    // Check if we should block due to loading state
    const isLoading = migrationAgentState.isActive
      ? migrationAgentState.isConnecting || (migrationAgentState.isRunning && !migrationAgentState.pendingPermission)
      : chatLoading;
    if (isLoading || pendingPlanOffer || migrationAgentState.pendingPermission?.allow_free_text === false) return false;

    if (migrationAgentState.isActive && migrationAgentState.pendingPermission) {
      migrationAgentClientRef.current?.answerQuestion(
        migrationAgentState.pendingPermission.contextHash,
        migrationAgentState.pendingPermission.permission_id,
        { answer: message },
      );
      setMigrationAgentMessages((messages) => [
        ...messages,
        { role: "user", content: message, id: `answer-${Date.now()}` },
      ]);
      setMigrationAgentState((state) => ({ ...state, pendingPermission: null, isRunning: true }));
      setDraft("");
      return true;
    }

    // If Migration Agent mode is active, use Migration Agent
    if (migrationAgentState.isActive) {
      void connectAndSendMigrationAgentMessage(message);
      setDraft("");
      return true;
    }

    if (pendingAiMappingReviews[0] && APPROVAL_RESPONSE_PATTERN.test(message)) {
      applyPendingAiMappingReview();
      setDraft("");
      return true;
    }

    if (pendingAiMappingReviews[0] && SKIP_RESPONSE_PATTERN.test(message)) {
      skipPendingAiMappingReview();
      setDraft("");
      return true;
    }

    if (pendingCorrectionRecommendation) {
      void recordRecommendationOutcome(pendingCorrectionRecommendation, "corrected", {
        correction: message,
        checkpoint: pendingCorrectionRecommendation.checkpoint,
      });
      markRecommendationResolved(pendingCorrectionRecommendation.recommendation_id);
      setPendingCorrectionRecommendation(null);
    }

    sendChatMessage(message);
    setDraft("");
    return true;
  };

  useEffect(() => {
    const node = messagesRef.current;
    if (!node || !shouldAutoScrollRef.current) return;
    node.scrollTop = node.scrollHeight;
  }, [chatLoading, chatMessages, migrationAgentMessages, migrationAgentState.streamingText, migrationAgentState.traceEvents.length]);

  // Build workspace snapshot for Migration Agent
  const buildWorkspaceSnapshot = useCallback((): WorkbenchContextSnapshotV1 => {
    // The full-page agent changes projects without remounting the workbench.
    // Its saved project identity is authoritative; old in-memory table and
    // semantic selections may belong to another project.
    const projectChat = pathname?.startsWith('/ai-agent') ?? false;
    const selectedSourceTables = projectChat ? [] : sources.filter((s) => s.isSelected);
    const selectedTargetTable = projectChat ? null : targets.find((t) => t.isSelected) ?? null;

    const currentPage = getSttmBuilderAssistantPage(pathname);
    const surface = currentPage === 'mapping' ? 'MAPPING' : 'SOURCE_SELECTION';

    const snapshot = buildWorkbenchContextSnapshot({
      action: 'assistant.requested',
      page: currentPage,
      surface,
      sessionId: session ? String(session.user_id) : null,
      projectId: activeProjectId,
      projectName: activeProjectName,
      sttmId: activeSttmId,
      sttmName: activeSttmName,
      scopeType: projectChat && activeProjectId ? 'project' : undefined,
      mappingLifecycle: projectChat ? (activeSttmId ? 'update' : 'new') : mappingIntent?.lifecycle ?? (activeSttmId ? 'update' : 'new'),
      businessGoal: projectChat ? null : mappingIntent?.business_goal ?? mappingIntent?.target_outcome ?? null,
      sourceTables: selectedSourceTables,
      targetTable: selectedTargetTable,
      drivingTableId: projectChat ? null : drivingTableId,
      sourceAttributeGroups: projectChat ? [] : sourceAttributeGroups,
      derivedSources: projectChat ? [] : derivedSources,
      relationships: projectChat ? [] : relationships,
      sourceFilterSql: projectChat ? '' : sourceFilterSql,
      sourceFilterGroups: projectChat ? [] : sourceFilterGroups,
      sourceQuerySql: projectChat ? '' : sourceQuerySql,
      sourceGroupBySql: projectChat ? '' : sourceGroupBySql,
      sourceOrderBySql: projectChat ? '' : sourceOrderBySql,
      mappings: projectChat ? [] : mappings,
      selectedMappingIds: projectChat ? [] : selectedMappingIds,
      activeMappingId: projectChat ? null : activeMappingId,
      mappingSql: projectChat ? null : mappingSql,
      mappingPreviewSql: projectChat ? null : mappingPreviewSql,
      mappingIntent: projectChat ? null : mappingIntent,
      semanticBundleId: projectChat ? null : semanticBundleId,
      semanticBundleLabel: projectChat ? null : semanticBundleLabel,
      semanticLevel: projectChat ? null : semanticLevel,
      semanticStatus: projectChat ? null : semanticStatus,
      semanticViewName: projectChat ? null : semanticViewName,
    });
    return {
      ...snapshot,
      // Quick and Deep receive the same prepared/semantic context handles and
      // live overlays. Deep tools still enforce their own authorization rules.
      workspace_context_id: projectChat ? null : workspaceContextId,
      workspace_context_hash: projectChat ? null : workspaceContextHash,
      workspace_context_status: projectChat ? null : workspaceContextStatus,
      workspace_context_cache_status: projectChat ? null : workspaceContextCacheStatus,
      semantic_bundle_hash: projectChat ? null : semanticBundleHash,
      semantic_context: projectChat ? [] : semanticContextItems,
      semantic_lineage: projectChat ? [] : semanticLineage,
      datahub_context: projectChat ? null : semanticDatahubContext,
      learning_context_id: projectChat ? null : learningContextId,
      learning_context_hash: projectChat ? null : learningContextHash,
    } as WorkbenchContextSnapshotV1;
  }, [
    sources,
    targets,
    derivedSources,
    pathname,
    session,
    sourceAttributeGroups,
    drivingTableId,
    relationships,
    semanticBundleId,
    semanticBundleLabel,
    semanticBundleHash,
    semanticContextItems,
    semanticLineage,
    semanticDatahubContext,
    learningContextId,
    learningContextHash,
    workspaceContextId,
    workspaceContextHash,
    workspaceContextStatus,
    workspaceContextCacheStatus,
    semanticViewName,
    mappings,
    selectedMappingIds,
    activeProjectId,
    activeSttmId,
    activeProjectName,
    activeSttmName,
    mappingIntent,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    mappingSql,
    mappingPreviewSql,
    activeMappingId,
    semanticLevel,
    semanticStatus,
  ]);

  // Handle Migration Agent WebSocket messages
  const handleMigrationAgentMessage = useCallback((message: MigrationAgentServerMessage) => {
    switch (message.type) {
      case 'session.ready':
        setMigrationAgentState((prev) => ({
          ...prev,
          isConnecting: false,
          isConnected: true,
          statusMessage: 'Migration Agent session ready',
        }));
        break;

      case 'session.restored': {
        animateMigrationAgentMessagesRef.current = false;
        if (Array.isArray(message.data?.attachments)) {
          setMigrationAttachments((message.data.attachments as Array<{ id: string; name: string }>).filter(
            (attachment) => Boolean(attachment.id && attachment.name),
          ));
        }
        const runId = String(message.data?.run_id ?? message.session_id);
        const prompt = String(message.data?.prompt ?? '').trim();
        const status = String(message.data?.status ?? '');
        const restoredHistory = Array.isArray(message.data?.conversation_history)
          ? (message.data.conversation_history as Array<Record<string, unknown>>)
              .map((item, index) => ({
                role: item.role === "assistant" ? "assistant" as const : "user" as const,
                content: String(item.content ?? "").trim(),
                id: `${runId}:history:${index}`,
                kind: item.role === "assistant" ? "final" as const : undefined,
                question: item.question && typeof item.question === "object"
                  ? item.question as { prompt: string; options: Array<{ label: string; description: string }> }
                  : undefined,
              }))
              .filter((item) => item.content)
          : [];
        const terminal = ['COMPLETED', 'NEEDS_REVIEW', 'COMPLETED_WITH_REVIEW_ITEMS', 'READY_FOR_REVIEW', 'FAILED', 'CANCELLED', 'EXPIRED'].includes(status);
        setMigrationAgentMessages((messages) => {
          const byId = new Map(messages.map((item) => [item.id, item]));
          for (const item of restoredHistory) if (!byId.has(item.id)) byId.set(item.id, item);
          if (prompt && !byId.has(`${runId}:user`)) {
            byId.set(`${runId}:user`, { role: 'user', content: prompt, id: `${runId}:user` });
          }
          return Array.from(byId.values());
        });
        setMigrationAgentState((prev) => ({
          ...prev,
          isConnecting: false,
          isConnected: true,
          isRunning: !terminal && !['AWAITING_INPUT', 'AWAITING_CONFIRMATION'].includes(status),
          isCancelling: false,
          streamingText: '',
          // History restoration is a background hydration operation, not a
          // newly started agent response. The durable trace itself will show
          // the current active step as soon as replay completes.
          statusMessage: null,
          traceEvents: [],
          toolExecutions: [],
          reviewItems: [],
          reviewArtifact: null,
          error: null,
        }));
        break;
      }

      case 'session.caught_up':
        // Durable history is already painted in full. Text received after this
        // boundary is new live output and may use the typewriter presentation.
        animateMigrationAgentMessagesRef.current = true;
        break;

      case 'assistant.progress':
        {
          const update = String(message.data?.text ?? '').trim();
          const durableId = String(message.data?.durable_event_id ?? message.event_id);
          const animate = animateMigrationAgentMessagesRef.current;
          if (update) {
            setMigrationAgentMessages((messages) => {
              if (messages.some((item) => item.id === durableId)) return messages;
              const recentProgress = [...messages].reverse().find((item) => item.kind === 'progress');
              if (recentProgress && isSimilarProgress(recentProgress.content, update)) return messages;
              return [...messages, { role: 'assistant', content: update, id: durableId, kind: 'progress', animate }];
            });
          }
          setMigrationAgentState((prev) => ({ ...prev, streamingText: '', statusMessage: null }));
        }
        break;

      case 'review.items': {
        const items = Array.isArray(message.data?.items) ? message.data.items : [];
        const artifact = message.data?.artifact && typeof message.data.artifact === "object"
          ? message.data.artifact as Record<string, unknown> : null;
        const nextSqlArtifact: AgentSqlArtifact | null = artifact ? {
          sql: String(artifact.sql ?? ''),
          compileValid: artifact.compileValid === true,
          previewValid: artifact.previewValid === true,
          previewColumns: Array.isArray(artifact.previewColumns) ? artifact.previewColumns.map(String) : [],
          previewRows: Array.isArray(artifact.previewRows) ? artifact.previewRows.map((row) =>
            typeof row === 'string' ? row : JSON.stringify(row)) : [],
          previewRowCount: Number(artifact.previewRowCount ?? 0),
          mappedCount: Number(artifact.mappedCount ?? 0),
          unresolvedCount: Number(artifact.unresolvedCount ?? 0),
        } : null;
        if (nextSqlArtifact?.sql) {
          setSqlArtifact(nextSqlArtifact);
          setArtifactVersion((version) => version + 1);
          setArtifactTab('sql');
          if (pageMode) setPlanSidebarOpen(true);
        }
        setMigrationAgentState((prev) => ({
          ...prev,
          reviewContextHash: message.context_hash,
          reviewItems: items
            .filter((item): item is Record<string, unknown> => !!item && typeof item === 'object')
            .map((item) => ({
              id: String(item.review_item_id ?? ''),
              category: String(item.category ?? 'review'),
              summary: String(item.summary ?? ''),
              question: String(item.question ?? item.summary ?? ''),
              status: String(item.status ?? 'OPEN'),
              sttmId: typeof item.sttm_id === 'string' ? item.sttm_id : null,
              choices: (Array.isArray(item.choices) ? item.choices : [])
                .filter((choice): choice is Record<string, unknown> => !!choice && typeof choice === 'object')
                .map((choice) => ({ id: String(choice.choice_id ?? ''), label: String(choice.label ?? ''),
                  description: String(choice.description ?? '') })).filter((choice) => choice.id && choice.label),
            }))
            .filter((item) => item.id && item.summary),
          reviewArtifact: nextSqlArtifact,
        }));
        break;
      }

      case 'plan.mode.recommended':
        setPendingPlanOffer({ reason: String(message.data?.reason ?? "This request has several dependent migration steps.") });
        setMigrationAgentState((prev) => ({ ...prev, isRunning: false, statusMessage: null }));
        break;

      case 'assistant.status':
        setMigrationAgentState((prev) => ({
          ...prev,
          isRunning: !prev.pendingPermission,
          statusMessage: prev.pendingPermission ? null : String(message.data?.status ?? message.data?.message ?? 'Working...'),
        }));
        break;

      case 'trace.event': {
        const data = message.data ?? {};
        const traceId = String(data.trace_id ?? message.event_id);
        const eventDetails = { ...data };
        const explicitDetails = eventDetails.details;
        for (const key of ['trace_id', 'parent_trace_id', 'kind', 'label', 'status', 'safe_summary', 'created_at', 'event_type', 'details']) {
          delete eventDetails[key];
        }
        setMigrationAgentState((prev) => {
          const next: MigrationAgentTraceEvent = {
            traceId,
            parentTraceId: data.parent_trace_id ? String(data.parent_trace_id) : null,
            kind: String(data.kind ?? 'action'),
            label: String(data.label ?? data.safe_summary ?? 'Migration activity'),
            status: String(data.status ?? 'running'),
            summary: String(data.safe_summary ?? ''),
            timestamp: String(data.created_at ?? message.timestamp),
            details: {
              ...eventDetails,
              ...(explicitDetails && typeof explicitDetails === 'object' ? explicitDetails : {}),
            } as Record<string, unknown>,
          };
          const index = prev.traceEvents.findIndex((event) => event.traceId === traceId);
          const current = index >= 0 ? prev.traceEvents[index] : null;
          const merged = current
            ? {
                ...next,
                parentTraceId: next.parentTraceId ?? current.parentTraceId,
                details: { ...current.details, ...next.details },
              }
            : next;
          return {
            ...prev,
            // Tool lifecycle belongs in the expandable activity tree. Keep the
            // compact receipt stable until genuine model-authored narration
            // arrives instead of echoing every low-level step above the tree.
            statusMessage: data.event_type === "run.queued"
              ? "Waiting for the Deep Agent worker…"
              : data.event_type === "run.started"
                ? "Worker started. Preparing the first step…"
                : prev.statusMessage,
            resolvedEffort: ["light", "medium", "high"].includes(String(data.resolved_effort))
              ? String(data.resolved_effort) as Exclude<MigrationEffort, "auto">
              : prev.resolvedEffort,
            traceEvents: index < 0
              ? [...prev.traceEvents, merged]
              : prev.traceEvents.map((event, candidate) => candidate === index ? merged : event),
          };
        });
        break;
      }

      case 'assistant.final':
        {
          window.dispatchEvent(new Event('aia:refresh-assistant-history'));
          const finalText = String(message.data?.text ?? '');
          const durableId = String(message.data?.durable_event_id ?? message.event_id);
          const animate = animateMigrationAgentMessagesRef.current;
          const question = message.data?.question && typeof message.data.question === 'object'
            ? message.data.question as { prompt: string; options: Array<{ label: string; description: string }> }
            : undefined;
          animateMigrationAgentMessagesRef.current = false;
          if (finalText) {
            setMigrationAgentMessages((msgs) => {
              const withoutTransientCopy = msgs.filter((item) => !(
                item.kind === 'progress' && isSameVisibleMessage(item.content, finalText)
              ));
              return withoutTransientCopy.some((item) => item.id === durableId)
                ? withoutTransientCopy
                : [...withoutTransientCopy, { role: 'assistant', content: finalText, id: durableId, kind: 'final', animate, question }];
            });
          }
          setMigrationAgentState((prev) => ({
            ...prev,
            isRunning: false,
            isCancelling: false,
            pendingPermission: null,
            streamingText: '',
            statusMessage: null,
          }));
          setOtherAnswerOpen(false);
          setOtherAnswer("");
        }
        break;

      case 'assistant.cancelled':
        animateMigrationAgentMessagesRef.current = false;
        setMigrationAgentState((prev) => ({
          ...prev,
          isRunning: false,
          isCancelling: false,
          pendingPermission: null,
          streamingText: '',
          statusMessage: null,
          error: null,
        }));
        break;

      case 'assistant.error':
        animateMigrationAgentMessagesRef.current = false;
        setMigrationAgentState((prev) => ({
          ...prev,
          isRunning: false,
          isCancelling: false,
          pendingPermission: message.error?.code === 'migration_agent_transport_error' ? prev.pendingPermission : null,
          streamingText: '',
          statusMessage: null,
          error: message.error?.detail ?? 'An error occurred',
        }));
        break;

      case 'permission.requested': {
        const permData = message.data as MigrationAgentPermissionRequest | undefined;
        if (permData) {
          setOtherAnswerOpen(false);
          setOtherAnswer("");
          if (permData.tool === "approve_migration_plan" && permData.plan) {
            setPlanDocument(permData.plan);
            setArtifactVersion((version) => version + 1);
            setArtifactTab('plan');
            if (pageMode) setPlanSidebarOpen(true);
          }
          setMigrationAgentState((prev) => ({
            ...prev,
            isRunning: false,
            isConnecting: false,
            statusMessage: null,
            pendingPermission: {
              ...permData,
              contextHash: message.context_hash,
            },
          }));
        }
        break;
      }

      case 'tool.started': {
        const toolData = message.data as { tool_id?: string; tool?: string; resource?: string } | undefined;
        if (toolData) {
          setMigrationAgentState((prev) => ({
            ...prev,
            toolExecutions: [
              ...prev.toolExecutions,
              {
                toolId: toolData.tool_id ?? message.event_id,
                tool: toolData.tool ?? 'unknown',
                resource: toolData.resource,
                status: 'started',
                startedAt: message.timestamp,
              },
            ],
          }));
        }
        break;
      }

      case 'tool.completed': {
        const toolData = message.data as { tool_id?: string; result?: string } | undefined;
        if (toolData) {
          setMigrationAgentState((prev) => ({
            ...prev,
            toolExecutions: prev.toolExecutions.map((exec) =>
              exec.toolId === toolData.tool_id
                ? { ...exec, status: 'completed', completedAt: message.timestamp, result: toolData.result }
                : exec
            ),
          }));
        }
        break;
      }

      default:
        // Handle any other message types gracefully
        break;
    }
  }, [pageMode]);

  // Handle Migration Agent disconnect
  const handleMigrationAgentDisconnect = useCallback(() => {
    setMigrationAgentState((prev) => ({
      ...prev,
      isConnected: false,
      isConnecting: false,
      statusMessage: null,
      error: prev.isActive ? 'Connection lost' : null,
    }));
  }, []);

  // Toggle Migration Agent mode
  const toggleMigrationAgentMode = useCallback(() => {
    // A mode switch is an explicit new-chat boundary. History restoration is
    // the only path that may reopen an earlier conversation.
    resetChatSession();
    if (migrationAgentState.isActive) {
      // Turn off Migration Agent mode
      migrationAgentClientRef.current?.close();
      migrationAgentClientRef.current = null;
      setMigrationAgentState(initialMigrationAgentState);
      setMigrationAgentMessages([]);
      setSqlArtifact(null);
      setPlanDocument(null);
      setPlanSidebarOpen(false);
    } else {
      // Enter Deep mode as a genuinely blank chat. Only an explicit History
      // selection may restore durable turns from an earlier conversation.
      const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
      migrationAgentClientRef.current = client;
      client.startNewConversation();
      animateMigrationAgentMessagesRef.current = false;
      setMigrationAgentMessages([]);
      setMigrationAttachments([]);
      setExpandedToolExecutions(false);
      const snapshot = buildWorkspaceSnapshot();
      setMigrationAgentState((prev) => ({
        ...prev,
        isActive: true,
        isConnecting: true,
        statusMessage: null,
        error: null,
      }));
      void client.connect(snapshot, handleMigrationAgentMessage, handleMigrationAgentDisconnect)
        .catch((error) => {
          setMigrationAgentState((prev) => ({
            ...prev,
            isConnecting: false,
            isConnected: false,
            statusMessage: null,
            error: error instanceof Error ? error.message : 'Failed to connect to Migration Agent',
          }));
        });
    }
  }, [buildWorkspaceSnapshot, handleMigrationAgentDisconnect, handleMigrationAgentMessage, migrationAgentState.isActive, resetChatSession]);

  // Open the dedicated agent page in Deep mode when there is no conversation
  // to preserve. The user can still switch modes from the shared composer.
  const wasOnAgentPageRef = useRef(false);
  useEffect(() => {
    const onAgentPage = pathname.startsWith("/ai-agent");
    if (onAgentPage && !wasOnAgentPageRef.current
      && !migrationAgentState.isActive
      && migrationAgentMessages.length === 0) {
      toggleMigrationAgentMode();
    }
    wasOnAgentPageRef.current = onAgentPage;
  }, [migrationAgentMessages.length, migrationAgentState.isActive, pathname, toggleMigrationAgentMode]);

  const startNewMigrationAgentChat = useCallback(() => {
    if (!migrationAgentState.isActive) return;
    const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
    migrationAgentClientRef.current = client;
    if (migrationAgentState.isRunning || migrationAgentState.isCancelling) {
      client.cancel("");
    }
    client.startNewConversation();
    animateMigrationAgentMessagesRef.current = false;
    setMigrationAgentMessages([]);
    setPlanDocument(null);
    setPlanSidebarOpen(false);
    setSqlArtifact(null);
    setPendingPlanOffer(null);
    setMigrationAttachments([]);
    setExpandedToolExecutions(false);
    setMigrationAgentState((prev) => ({
      ...initialMigrationAgentState,
      isActive: true,
      isConnected: prev.isConnected,
      isConnecting: false,
    }));
    setDraft("");
  }, [migrationAgentState.isActive, migrationAgentState.isCancelling, migrationAgentState.isRunning, setDraft]);

  const observedNewChatVersionRef = useRef(newChatVersion);
  useEffect(() => {
    if (observedNewChatVersionRef.current === newChatVersion) return;
    observedNewChatVersionRef.current = newChatVersion;
    if (migrationAgentState.isActive) startNewMigrationAgentChat();
  }, [migrationAgentState.isActive, newChatVersion, startNewMigrationAgentChat]);

  useEffect(() => {
    const restore = (event: Event) => {
      const detail = (event as CustomEvent<{ conversationId?: string }>).detail;
      if (!detail?.conversationId) return;
      const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
      migrationAgentClientRef.current = client;
      resetChatSession();
      setMigrationAgentMessages([]);
      setPlanDocument(null);
      setPlanSidebarOpen(false);
      setSqlArtifact(null);
      setPendingPlanOffer(null);
      setMigrationAgentState((previous) => ({
        ...initialMigrationAgentState,
        isActive: true,
        isConnecting: true,
        isConnected: previous.isConnected,
      }));
      void client.restoreConversation(
        detail.conversationId,
        buildWorkspaceSnapshot(),
        handleMigrationAgentMessage,
        handleMigrationAgentDisconnect,
      ).catch((error) => {
        setMigrationAgentState((previous) => ({
          ...previous,
          isConnecting: false,
          error: error instanceof Error ? error.message : 'Failed to restore conversation',
        }));
      });
    };
    window.addEventListener('aia:restore-assistant-conversation', restore);
    return () => window.removeEventListener('aia:restore-assistant-conversation', restore);
  }, [buildWorkspaceSnapshot, handleMigrationAgentDisconnect, handleMigrationAgentMessage, resetChatSession]);

  useEffect(() => {
    if (!pageMode) return;
    const params = new URLSearchParams(window.location.search);
    const artifact = params.get('artifact');
    const conversationId = params.get('conversation');
    if (!conversationId || !['research', 'plan', 'sql', 'results'].includes(artifact ?? '')) return;
    requestedArtifactRef.current = artifact as AgentArtifactTab;
    window.dispatchEvent(new CustomEvent('aia:restore-assistant-conversation', {
      detail: { conversationId },
    }));
  }, [pageMode]);

  useEffect(() => {
    const requested = requestedArtifactRef.current;
    if (!requested) return;
    if ((requested === 'research' && researchReport)
      || (requested === 'plan' && planDocument)
      || (requested === 'sql' && sqlArtifact?.sql)
      || (requested === 'results' && sqlArtifact?.previewRows.length)) {
      setArtifactTab(requested);
      setPlanSidebarOpen(true);
      requestedArtifactRef.current = null;
    }
  }, [researchReport, planDocument, sqlArtifact]);

  useEffect(() => {
    const selectMode = (event: Event) => {
      const detail = (event as CustomEvent<{ mode?: 'quick' | 'deep' }>).detail;
      if (detail?.mode !== 'quick') return;
      migrationAgentClientRef.current?.close();
      migrationAgentClientRef.current = null;
      setMigrationAgentState(initialMigrationAgentState);
      setMigrationAgentMessages([]);
      setPlanDocument(null);
      setPlanSidebarOpen(false);
      setSqlArtifact(null);
      setPendingPlanOffer(null);
      setMigrationAttachments([]);
      setExpandedToolExecutions(false);
    };
    window.addEventListener('aia:select-assistant-mode', selectMode);
    return () => window.removeEventListener('aia:select-assistant-mode', selectMode);
  }, []);

  // Connect to Migration Agent when sending first message in Migration Agent mode
  const connectAndSendMigrationAgentMessage = useCallback(async (message: string) => {
    if (!migrationAgentClientRef.current) {
      migrationAgentClientRef.current = new MigrationAgentSessionClient();
    }

    const snapshot = buildWorkspaceSnapshot();
    const readingAttachment = migrationAttachments.length > 0
      && /\b(summarize|summary|identify|explain|what|which|who|when|why|how|compare|review|ask|question|tell me)\b/i.test(message)
      && !/\b(create|build|draft|save|publish|execute|run|generate|implement|migrate|map|update|modify|compile|preview)\b/i.test(message);
    const conversationHistory: MigrationConversationMessage[] = migrationAgentMessages
      .slice(-40)
      .map(({ role, content }) => ({ role, content }));
    shouldAutoScrollRef.current = true;
    animateMigrationAgentMessagesRef.current = true;

    // Add user message to chat
    setMigrationAgentMessages((msgs) => [
      ...msgs,
      { role: 'user', content: message, id: `user-${Date.now()}` },
    ]);

    try {
      setMigrationAgentState((prev) => ({
        ...prev,
        isRunning: true,
        isCancelling: false,
        traceEvents: [],
        toolExecutions: [],
        reviewItems: [],
        reviewArtifact: null,
        statusMessage: readingAttachment ? 'Reading uploaded evidence…' : 'Submitting request…',
        error: null,
      }));
      if (!migrationAgentState.isConnected) {
        setMigrationAgentState((prev) => ({ ...prev, isRunning: true, isConnecting: true, error: null, statusMessage: 'Checking Migration Agent service...' }));
        setMigrationAgentState((prev) => ({ ...prev, statusMessage: 'Connecting…' }));
        await migrationAgentClientRef.current.connect(snapshot, handleMigrationAgentMessage, handleMigrationAgentDisconnect);
      }
      setMigrationAgentState((prev) => ({ ...prev, isRunning: true, statusMessage: readingAttachment ? 'Reading uploaded evidence…' : 'Submitting request…' }));
      migrationAgentClientRef.current.setOptions({
        effort: migrationEffort,
        modelName: migrationModelName,
        runMode: migrationRunMode,
        attachmentIds: migrationAttachments.map((attachment) => attachment.id),
      });
      migrationAgentClientRef.current.sendMessage(message, snapshot, conversationHistory);
    } catch (err) {
      setMigrationAgentState((prev) => ({
        ...prev,
        isRunning: false,
        isConnecting: false,
        statusMessage: null,
        error: err instanceof Error ? err.message : 'Failed to connect to Migration Agent',
      }));
    }
  }, [buildWorkspaceSnapshot, migrationAgentState.isConnected, migrationEffort, migrationModelName, migrationRunMode, migrationAttachments, migrationAgentMessages, handleMigrationAgentMessage, handleMigrationAgentDisconnect]);

  const handleMigrationAttachment = useCallback(async (file: File | null) => {
    if (!file) return;
    const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
    migrationAgentClientRef.current = client;
    setMigrationAttachmentUploading(true);
    setMigrationAgentState((state) => ({ ...state, error: null }));
    try {
      const id = await client.uploadAttachment(file);
      setMigrationAttachments((attachments) => [...attachments, { id, name: file.name }]);
    } catch (error) {
      setMigrationAgentState((state) => ({
        ...state,
        error: error instanceof Error ? error.message : "Attachment upload failed",
      }));
    } finally {
      setMigrationAttachmentUploading(false);
    }
  }, []);

  // Handle permission decision
  const handlePermissionDecision = useCallback(
    (decision: 'allow_once' | 'allow_session' | 'deny' | 'cancel', feedback = '') => {
      const perm = migrationAgentState.pendingPermission;
      if (!perm || !migrationAgentClientRef.current) return;

      migrationAgentClientRef.current.decidePermission(
        perm.contextHash,
        perm.permission_id,
        decision,
        feedback
      );
      setMigrationAgentState((prev) => ({ ...prev, pendingPermission: null }));
    },
    [migrationAgentState.pendingPermission]
  );

  const handlePermissionChoice = useCallback((choiceId: string, label: string) => {
    const perm = migrationAgentState.pendingPermission;
    if (!perm || !migrationAgentClientRef.current) return;
    migrationAgentClientRef.current.chooseOption(
      perm.contextHash,
      perm.permission_id,
      choiceId,
    );
    setMigrationAgentMessages((messages) => [
      ...messages,
      { role: "user", content: label, id: `choice-${Date.now()}` },
    ]);
    setMigrationAgentState((previous) => ({
      ...previous,
      pendingPermission: null,
      isRunning: true,
      statusMessage: "Choice recorded; resuming the durable run…",
    }));
  }, [migrationAgentState.pendingPermission]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      migrationAgentClientRef.current?.close();
    };
  }, []);

  const toggleTrace = (messageId: string) => {
    setExpandedTraces((current) => ({
      ...current,
      [messageId]: !current[messageId],
    }));
  };

  const startSignalRating = (signalId: string, rating: number) => {
    setPendingSignalResponses((current) => ({
      ...current,
      [signalId]: {
        rating,
        optionSelected: current[signalId]?.optionSelected ?? null,
        comment: current[signalId]?.comment ?? "",
      },
    }));
  };

  const selectSignalOption = (signalId: string, optionSelected: string) => {
    setPendingSignalResponses((current) => ({
      ...current,
      [signalId]: {
        rating: current[signalId]?.rating ?? null,
        optionSelected,
        comment: current[signalId]?.comment ?? "",
      },
    }));
  };

  const changeSignalComment = (signalId: string, comment: string) => {
    setPendingSignalResponses((current) => ({
      ...current,
      [signalId]: {
        rating: current[signalId]?.rating ?? null,
        optionSelected: current[signalId]?.optionSelected ?? null,
        comment,
      },
    }));
  };

  const submitSignalResponse = (signalId: string) => {
    const pending = pendingSignalResponses[signalId];
    respondToAssistantSignal({
      signalId,
      status: "responded",
      optionSelected: pending?.optionSelected ?? null,
      rating: pending?.rating ?? null,
      comment: pending?.comment?.trim() || null,
    });
    setPendingSignalResponses((current) => {
      const next = { ...current };
      delete next[signalId];
      return next;
    });
  };

  const dismissSignal = (signalId: string) => {
    respondToAssistantSignal({ signalId, status: "dismissed" });
    setPendingSignalResponses((current) => {
      const next = { ...current };
      delete next[signalId];
      return next;
    });
  };

  const confirmSignalOption = (signalId: string, optionSelected: string) => {
    respondToAssistantSignal({
      signalId,
      status: "responded",
      optionSelected,
    });
    setPendingSignalResponses((current) => {
      const next = { ...current };
      delete next[signalId];
      return next;
    });
  };

  const explainSignal = async (signal: (typeof assistantSignals)[number], optionLabel?: string) => {
    const signalTables =
      Array.isArray(signal.entity_ids) && signal.entity_ids.length >= 2
        ? signal.entity_ids.filter((entityId) => entityId.split(".").length === 3).slice(0, 2)
        : [];
    const fallbackPrompt =
      signalTables.length >= 2
        ? `Explain the relationship between ${signalTables[0]} and ${signalTables[1]} in simple business terms and tell me whether it looks reliable for mapping.`
        : "Explain the relationship between the selected tables in simple business terms and tell me whether it looks reliable for mapping.";
    const suggestedPrompt =
      typeof signal.attributes?.suggested_prompt === "string" && signal.attributes.suggested_prompt.trim()
        ? signal.attributes.suggested_prompt.trim()
        : fallbackPrompt;
    const currentUnderstanding = buildSignalUnderstandingText(signal);
    const explanationPrompt = currentUnderstanding
      ? `${suggestedPrompt}\n\nThis is your current understanding so far:\n${currentUnderstanding}\n\nPlease explain this in simple business terms, tell me what looks reliable, and call out the specific assumption or join detail the user should confirm or correct.`
      : suggestedPrompt;
    sendChatMessage(explanationPrompt);
    respondToAssistantSignal({
      signalId: signal.signal_id,
      status: "acknowledged",
      optionSelected: optionLabel ?? "Ask AI to explain first",
    });
  };

  const applySignalAction = async (signal: (typeof assistantSignals)[number]) => {
    const actionType = typeof signal.attributes?.action_type === "string" ? signal.attributes.action_type : "";
    if (actionType === "refresh_semantic_context") {
      try {
        setSignalActionBusyId(signal.signal_id);
        await requestSemanticRefresh();
        respondToAssistantSignal({
          signalId: signal.signal_id,
          status: "acknowledged",
          optionSelected: "Refresh semantic context",
        });
      } finally {
        setSignalActionBusyId(null);
      }
      return;
    }
    if (actionType === "explain_relationship") {
      await explainSignal(signal, "Explain this relationship");
    }
  };

  const handleSignalOption = async (signal: (typeof assistantSignals)[number], option: string) => {
    const normalized = option.trim().toLowerCase();
    if (normalized === "refresh semantic context" || normalized === "build stronger context") {
      await applySignalAction(signal);
      return;
    }
    const requestsExplanation =
      normalized === "ask ai to explain first" ||
      normalized === "explain this relationship" ||
      normalized === "explain this join" ||
      normalized === "tell me more" ||
      normalized.includes("explain") ||
      (normalized.includes("show me") &&
        ["join", "relationship", "pattern", "correct", "how", "why"].some((word) => normalized.includes(word)));
    if (requestsExplanation) {
      await explainSignal(signal, option);
      return;
    }
    if (normalized === "dismiss" || normalized === "not now") {
      dismissSignal(signal.signal_id);
      return;
    }
    if (
      normalized === "looks right" ||
      normalized.startsWith("understood") ||
      normalized.includes("i'll handle it") ||
      normalized.includes("i will handle it") ||
      normalized === "yes, that is correct" ||
      normalized === "this relationship looks right"
    ) {
      confirmSignalOption(signal.signal_id, option);
      return;
    }
    if (normalized === "needs correction") {
      const currentUnderstanding = buildSignalUnderstandingText(signal);
      setPendingSignalResponses((current) => ({
        ...current,
        [signal.signal_id]: {
          rating: current[signal.signal_id]?.rating ?? null,
          optionSelected: option,
          comment: current[signal.signal_id]?.comment ?? "",
        },
      }));
      sendChatMessage(
        currentUnderstanding
          ? `This current understanding needs correction:\n${currentUnderstanding}\n\nPlease ask me what looks wrong, what the right business meaning is, and what join or relationship should be used instead.`
          : "I think the current join needs correction. Please ask me what looks wrong and help me capture the right business relationship.",
      );
      return;
    }
    if (normalized === "i will type it manually" || normalized === "i want to describe it") {
      setPendingSignalResponses((current) => ({
        ...current,
        [signal.signal_id]: {
          rating: current[signal.signal_id]?.rating ?? null,
          optionSelected: option,
          comment: current[signal.signal_id]?.comment ?? "",
        },
      }));
      return;
    }
    selectSignalOption(signal.signal_id, option);
  };

  const openMappingReviews = migrationAgentState.reviewItems.filter(
    (item) => item.category === "mapping_candidate_review" && item.status === "OPEN",
  );
  const activeReviewIndex = Math.min(reviewQuestionIndex, Math.max(0, openMappingReviews.length - 1));
  const activeMappingReview = openMappingReviews[activeReviewIndex];
  const reviewDraftId = migrationAgentState.reviewItems.find((item) => item.sttmId)?.sttmId;

  return (
    <AiaBox sx={{ width: '100%', height: '100%', minWidth: 0, minHeight: 0, display: 'flex', overflow: 'hidden' }}>
    <AiaPaper
      elevation={0}
      sx={{
        flex: 1,
        minWidth: 0,
        height: "100%",
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        borderRadius: "12px",
        border: variant === "sidebar" ? "none" : "1px solid #e2e8f0",
        overflow: "hidden",
        backgroundColor: "#ffffff",
      }}
    >
      {variant !== "sidebar" ? <AiaBox
        sx={{
          p: 2.25,
          backgroundColor: "var(--aia-assitant-header-color)",
          color: "var(--aia-assitant-header-textColor)",
        }}
      >
        <AiaStack
          sx={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "flex-start",
            gap: 1.5,
          }}
        >
          <AiaStack sx={{ flexDirection: "row", gap: 1.5, alignItems: "center" }}>
            <AiaAvatar
              sx={{
                bgcolor: 'var(--aia-assitant-avatar-bgColor)',
                width: 36,
                height: 36,
              }}
            >
              <AutoAwesomeRoundedIcon sx={{ fontSize: 20 }} />
            </AiaAvatar>
            <AiaBox>
              <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                <AiaText
                  variant="subtitle1"
                  sx={{ fontWeight: 700, lineHeight: 1.2, color: 'var(--aia-assitant-textColor)' }}
                >
                  STTM AI
                </AiaText>
              </AiaStack>
              <AiaText
                variant="caption"
                sx={{
                  color: "#94a3b8",
                  display: "flex",
                  alignItems: "center",
                  gap: 0.75,
                }}
              >
                <AiaBox
                  component="span"
                  sx={{
                    width: 6,
                    height: 6,
                    borderRadius: "50%",
                    bgcolor: migrationAgentState.isActive
                      ? migrationAgentState.isConnecting
                        ? "#f59e0b"
                        : migrationAgentState.isConnected
                          ? "#22c55e"
                          : "#94a3b8"
                      : chatLoading
                        ? "#f59e0b"
                        : "#22c55e",
                  }}
                />
                {migrationAgentState.isActive
                  ? migrationAgentState.isConnecting
                    ? "Restoring history..."
                    : migrationAgentState.isConnected
                      ? "Connected"
                      : "Ready"
                  : chatLoading
                    ? "Working"
                    : "Active"}{" "}
                · {migrationAgentState.isActive ? "Deep Agent" : "Quick Assistant"}
              </AiaText>
            </AiaBox>
          </AiaStack>
          <AiaStack direction="row" spacing={0.5}>
            <AiaTooltip title={migrationAgentState.isActive && (migrationAgentState.isRunning || migrationAgentState.isCancelling) ? "Stop the active run before starting a new chat" : "New chat"}>
                <span>
                  <AiaIconButton
                    size="small"
                    aria-label="Start a new chat"
                    disabled={migrationAgentState.isActive && (migrationAgentState.isRunning || migrationAgentState.isCancelling)}
                    onClick={migrationAgentState.isActive ? startNewMigrationAgentChat : resetChatSession}
                    sx={{ color: 'var(--aia-assitant-textColor)' }}
                  >
                    <EditNoteRoundedIcon fontSize="small" />
                  </AiaIconButton>
                </span>
            </AiaTooltip>
            {/* Only show Migration Agent toggle if Migration Agent is available */}
            {migrationAgentAvailable && (
              <AiaTooltip title={migrationAgentState.isActive ? "Switch to Quick Assistant" : "Switch to Migration Agent"}>
                <AiaIconButton
                  size="small"
                  onClick={toggleMigrationAgentMode}
                  sx={{
                    color: migrationAgentState.isActive ? 'var(--aia-primary-bg-color)' : 'var(--aia-assitant-textColor)',
                    backgroundColor: migrationAgentState.isActive ? 'color-mix(in srgb, var(--aia-button-color) 12%, transparent)' : 'transparent',
                    '&:hover': {
                      backgroundColor: migrationAgentState.isActive ? 'color-mix(in srgb, var(--aia-button-color) 20%, transparent)' : 'rgba(255,255,255,0.1)',
                    },
                  }}
                >
                  <AutoAwesomeRoundedIcon fontSize="small" />
                </AiaIconButton>
              </AiaTooltip>
            )}
            {/* Show disabled state when Migration Agent is not available but checking is done */}
            {migrationAgentAvailable === false && (
              <AiaTooltip title="Migration Agent is not available">
                <AiaBox sx={{ opacity: 0.4 }}>
                  <AiaIconButton
                    size="small"
                    disabled
                    sx={{ color: 'var(--aia-assitant-textColor)' }}
                  >
                    <AutoAwesomeRoundedIcon fontSize="small" />
                  </AiaIconButton>
                </AiaBox>
              </AiaTooltip>
            )}
            <AiaIconButton
              size="small"
              aria-label="Open AI Agent page"
              title="Open AI Agent page"
              onClick={() => router.push('/ai-agent')}
              sx={{ color: 'var(--aia-assitant-textColor)' }}
            >
              <OpenInFullIcon fontSize="small" />
            </AiaIconButton>
            <AiaIconButton size="small" sx={{ color: 'var(--aia-assitant-textColor)' }}>
              <VolumeUpIcon fontSize="small" />
            </AiaIconButton>
          </AiaStack>
        </AiaStack>

        <AiaBox
          sx={{
            mt: 2,
            p: 1.25,
            borderRadius: "8px",
            backgroundColor: 'var(--aia-assitant-subheader-color)',
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          <TableChartIcon sx={{ fontSize: 16, color: 'var(--aia-assitant-table-textColor)'  }} />
          <AiaText variant="caption" sx={{ color: 'var(--aia-assitant-table-textColor)' }}>
            {statsLabel}
          </AiaText>
        </AiaBox>

        {semanticStatus || semanticLevel || semanticViewName || semanticBundleLabel ? (
          <AiaStack
            direction="row"
            spacing={0.75}
            useFlexGap
            sx={{ mt: 1.25, flexWrap: "wrap" }}
          >
            {semanticBundleLabel ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#1f2937",
                  color: "#e5e7eb",
                  fontSize: 11,
                  fontWeight: 700,
                  maxWidth: "100%",
                }}
              >
                {semanticBundleLabel}
              </AiaBox>
            ) : null}
            {semanticLevel ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#1e293b",
                  color: "#e2e8f0",
                  fontSize: 11,
                  fontWeight: 700,
                }}
              >
                {semanticLevel}
              </AiaBox>
            ) : null}
            {semanticStatus ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#052e16",
                  color: "#86efac",
                  fontSize: 11,
                  fontWeight: 700,
                  textTransform: "capitalize",
                }}
              >
                {semanticStatus}
              </AiaBox>
            ) : null}
            {semanticViewName ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#172554",
                  color: "#bfdbfe",
                  fontSize: 11,
                  fontWeight: 700,
                }}
              >
                Semantic view
              </AiaBox>
            ) : null}

          </AiaStack>
        ) : null}
      </AiaBox> : !pageMode ? (
        <AiaBox
          sx={{
            px: 2,
            py: 1,
            borderBottom: "1px solid #e2e8f0",
            backgroundColor: "#f8fafc",
            flexShrink: 0,
          }}
        >
          <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
            <TableChartIcon sx={{ fontSize: 16, color: "#64748b" }} />
            <AiaText sx={{ fontSize: 12, color: "#64748b" }}>{statsLabel}</AiaText>
          </AiaStack>
        </AiaBox>
      ) : null}

      {!pageMode ? <AiaStack
        direction="row"
        spacing={0.75}
        sx={{
          px: 2,
          py: 0.65,
          alignItems: "center",
          borderBottom: "1px solid #e2e8f0",
          backgroundColor:
            workspaceContextStatus === "failed" ? "#fff7ed" : "#f8fafc",
          flexShrink: 0,
        }}
      >
        {workspaceContextStatus === "updating" ? (
          <AiaCircularProgress size={12} />
        ) : (
          <AiaBox
            sx={{
              width: 7,
              height: 7,
              borderRadius: "50%",
              backgroundColor:
                workspaceContextStatus === "ready"
                  ? "#22c55e"
                  : workspaceContextStatus === "partial"
                    ? "#f59e0b"
                    : workspaceContextStatus === "failed"
                      ? "#ef4444"
                      : "#94a3b8",
            }}
          />
        )}
        <AiaText
          sx={{
            minWidth: 0,
            flex: 1,
            fontSize: 11,
            color: workspaceContextStatus === "failed" ? "#9a3412" : "#64748b",
          }}
          title={workspaceContextError ?? undefined}
        >
          AI context:{" "}
          {workspaceContextStatus === "updating"
            ? "Updating"
            : workspaceContextStatus === "ready"
              ? "Ready"
              : workspaceContextStatus === "partial"
                ? "Ready with warnings"
                : workspaceContextStatus === "failed"
                  ? "Failed"
                  : "Waiting for a selection"}
          {workspaceContextCacheStatus
            ? ` · ${({
                l1: "Memory cache",
                l2: "Durable cache",
                miss: "Fresh",
                coalesced: "Reused",
                memory: "Memory cache",
                durable: "Durable cache",
                fresh: "Fresh",
              } as Record<string, string>)[workspaceContextCacheStatus.toLowerCase()] ?? workspaceContextCacheStatus}`
            : ""}
        </AiaText>
        <AiaButton
          size="small"
          variant="text"
          disabled={workspaceContextStatus === "updating"}
          onClick={() => {
            void refreshPreparedWorkspaceContext().catch(() => undefined);
          }}
          sx={{
            minWidth: 0,
            px: 0.75,
            py: 0.25,
            fontSize: 11,
            textTransform: "none",
          }}
        >
          Refresh
        </AiaButton>
      </AiaStack> : null}

      {variant !== "sidebar" ? <AiaStack
        direction="row"
        sx={{
          px: 1,
          py: 0.75,
          gap: 0.5,
          borderBottom: "1px solid #e2e8f0",
          backgroundColor: "#ffffff",
        }}
      >
        <AiaButton
          size="small"
          variant={panelMode === "assistant" ? "contained" : "text"}
          onClick={() => setPanelMode("assistant")}
          sx={{
            minHeight: 32,
            textTransform: "none",
            borderRadius: 1.5,
            boxShadow: "none",
          }}
        >
          Assistant
          {firPrimaryQuestion ? (
            <AiaBox
              component="span"
              sx={{
                ml: 0.75,
                minWidth: 18,
                height: 18,
                px: 0.5,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "999px",
                backgroundColor: panelMode === "assistant" ? "#ffffff" : "#fee2e2",
                color: "#dc2626",
                fontSize: 10,
                fontWeight: 800,
              }}
            >
              1
            </AiaBox>
          ) : null}
        </AiaButton>
        <AiaButton
          size="small"
          variant={panelMode === "recommendations" ? "contained" : "text"}
          onClick={() => setPanelMode("recommendations")}
          sx={{
            minHeight: 32,
            textTransform: "none",
            borderRadius: 1.5,
            boxShadow: "none",
          }}
        >
          Recommendations
          <AiaBox
            component="span"
            sx={{
              ml: 0.75,
              minWidth: 18,
              height: 18,
              px: 0.5,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "999px",
              backgroundColor: panelMode === "recommendations" ? "#ffffff" : "#dbeafe",
              color: "#1d4ed8",
              fontSize: 10,
              fontWeight: 800,
            }}
          >
            {visibleFirRecommendations.length}
          </AiaBox>
        </AiaButton>
      </AiaStack> : null}

      <AiaBox
        ref={messagesRef}
        onScroll={(event) => {
          const node = event.currentTarget;
          shouldAutoScrollRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 48;
        }}
        sx={{
          p: 2,
          flex: "1 1 0",
          minHeight: 0,
          maxHeight: "100%",
          display: "flex",
          flexDirection: "column",
          gap: 2,
          overflowY: "scroll",
          overflowX: "hidden",
          overscrollBehavior: "contain",
          scrollbarGutter: "stable",
          touchAction: "pan-y",
          WebkitOverflowScrolling: "touch",
          backgroundColor: "#ffffff",
          ...(showWelcomeHero && (!migrationAgentState.isActive || (
            migrationAgentMessages.length === 0 && !migrationAgentState.isRunning
          ))
            ? {
                justifyContent: "center",
                alignItems: "center",
              }
            : {}),
        }}
      >
        {variant !== "sidebar" && panelMode === "recommendations" ? (
          firRecommendationLoading ? (
            <AiaStack direction="row" spacing={1} sx={{ alignItems: "center", color: "#64748b" }}>
              <AiaCircularProgress size={16} />
              <AiaText sx={{ fontSize: 13 }}>Loading applicable guidance...</AiaText>
            </AiaStack>
          ) : visibleFirRecommendations.length ? (
            <AiaStack spacing={1.25}>
              {visibleFirRecommendations.map((recommendation) =>
                renderFirRecommendationCard(recommendation),
              )}
            </AiaStack>
          ) : (
            <AiaBox sx={{ py: 4, textAlign: "center" }}>
              <TipsAndUpdatesOutlinedIcon sx={{ color: "#94a3b8", mb: 1 }} />
              <AiaText sx={{ fontSize: 13, fontWeight: 700, color: "#475569" }}>
                No guidance applies to this checkpoint yet.
              </AiaText>
              <AiaText sx={{ fontSize: 12, color: "#94a3b8", mt: 0.5 }}>
                New FIR results will appear here as the mapping context changes.
              </AiaText>
            </AiaBox>
          )
        ) : null}

        {(variant === "sidebar" || panelMode === "assistant") ? (
          <>
        {variant === "sidebar"
          ? selectedRecommendation
            ? renderFirRecommendationCard(selectedRecommendation, !!selectedRecommendation.question_id)
            : null
          : firPrimaryQuestion &&
              !resolvedRecommendationIds.has(firPrimaryQuestion.recommendation_id)
            ? renderFirRecommendationCard(firPrimaryQuestion, true)
            : null}
        {activeSignal ? (
          <AiaStack spacing={1.5}>
            {[activeSignal].map((signal) => {
              const draftResponse = pendingSignalResponses[signal.signal_id];
              const thumbsUpSelected = draftResponse?.rating === 5;
              const thumbsDownSelected = draftResponse?.rating === 1;
              const isRefreshSignal = signal.attributes?.action_type === "refresh_semantic_context";
              const currentUnderstanding = buildSignalUnderstandingText(signal);
              const actionLabel =
                isRefreshSignal
                  ? "Refresh now"
                  : signal.attributes?.action_type === "explain_relationship"
                    ? "Explain now"
                    : null;
              return (
                <AiaPaper
                  key={signal.signal_id}
                  elevation={0}
                  sx={{
                    p: 1.5,
                    borderRadius: 2,
                    border: signal.signal_type === "recommendation" ? "1px solid #bfdbfe" : "1px solid #fecaca",
                    backgroundColor: signal.signal_type === "recommendation" ? "#eff6ff" : "#fff7f7",
                  }}
                >
                  <AiaStack spacing={1}>
                    <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                      {signal.signal_type === "recommendation" ? (
                        <TipsAndUpdatesOutlinedIcon sx={{ fontSize: 18, color: "#2563eb" }} />
                      ) : (
                        <HelpOutlineOutlinedIcon sx={{ fontSize: 18, color: "#dc2626" }} />
                      )}
                      <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
                        {signal.title}
                      </AiaText>
                    </AiaStack>
                    <AiaText
                      sx={{
                        fontSize: 13,
                        color: "#334155",
                        lineHeight: 1.55,
                        overflowWrap: "anywhere",
                        wordBreak: "break-word",
                      }}
                    >
                      {signal.message}
                    </AiaText>
                    {currentUnderstanding ? (
                      <AiaBox
                        sx={{
                          borderRadius: 1.5,
                          border: "1px solid #dbeafe",
                          backgroundColor: "#ffffff",
                          px: 1.25,
                          py: 1,
                        }}
                      >
                        <AiaText sx={{ fontSize: 12, fontWeight: 800, color: "#1d4ed8", mb: 0.5 }}>
                          Current understanding
                        </AiaText>
                        <AiaText
                          sx={{
                            fontSize: 12.5,
                            color: "#334155",
                            lineHeight: 1.6,
                            whiteSpace: "pre-wrap",
                            overflowWrap: "anywhere",
                            wordBreak: "break-word",
                          }}
                        >
                          {currentUnderstanding}
                        </AiaText>
                      </AiaBox>
                    ) : null}
                    {signal.options?.length ? (
                      <AiaStack direction="row" spacing={1} useFlexGap sx={{ flexWrap: "wrap" }}>
                        {signal.options.map((option) => {
                          const selected = draftResponse?.optionSelected === option;
                          return (
                            <AiaButton
                              key={option}
                              size="small"
                              variant={selected ? "contained" : "outlined"}
                              onClick={() => {
                                void handleSignalOption(signal, option);
                              }}
                              sx={{ borderRadius: 999, textTransform: "none" }}
                            >
                              {option}
                            </AiaButton>
                          );
                        })}
                      </AiaStack>
                    ) : null}
                    {signal.signal_type === "recommendation" ? (
                      <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                        <AiaIconButton
                          size="small"
                          onClick={() => startSignalRating(signal.signal_id, 5)}
                          sx={{ color: thumbsUpSelected ? "#16a34a" : "#64748b" }}
                        >
                          <ThumbUpAltOutlinedIcon fontSize="small" />
                        </AiaIconButton>
                        <AiaIconButton
                          size="small"
                          onClick={() => startSignalRating(signal.signal_id, 1)}
                          sx={{ color: thumbsDownSelected ? "#dc2626" : "#64748b" }}
                        >
                          <ThumbDownAltOutlinedIcon fontSize="small" />
                        </AiaIconButton>
                        <AiaText sx={{ fontSize: 12, color: "#64748b" }}>
                          Was this recommendation useful?
                        </AiaText>
                      </AiaStack>
                    ) : null}
                    {(!isRefreshSignal && (signal.allow_free_text || draftResponse?.rating || draftResponse?.optionSelected)) ? (
                      <AiaInput
                        size="small"
                        placeholder="Add a business comment or type your own answer"
                        value={draftResponse?.comment ?? ""}
                        onChange={(value) => changeSignalComment(signal.signal_id, value)}
                        multiline
                        minRows={2}
                      />
                    ) : null}
                    <AiaStack direction="row" spacing={1}>
                      {actionLabel ? (
                        <AiaButton
                          size="small"
                          variant="outlined"
                          onClick={() => {
                            void applySignalAction(signal);
                          }}
                          disabled={signalActionBusyId === signal.signal_id}
                          sx={{ textTransform: "none" }}
                        >
                          {signalActionBusyId === signal.signal_id ? "Working..." : actionLabel}
                        </AiaButton>
                      ) : null}
                      {!isRefreshSignal ? (
                        <AiaButton
                          size="small"
                          variant="contained"
                          onClick={() => submitSignalResponse(signal.signal_id)}
                          sx={{ textTransform: "none" }}
                        >
                          Send response
                        </AiaButton>
                      ) : null}
                      <AiaButton
                        size="small"
                        variant="text"
                        onClick={() => dismissSignal(signal.signal_id)}
                        sx={{ textTransform: "none" }}
                      >
                        Dismiss
                      </AiaButton>
                    </AiaStack>
                  </AiaStack>
                </AiaPaper>
              );
            })}
          </AiaStack>
        ) : null}
        {/* Migration Agent Mode Messages */}
        {migrationAgentState.isActive ? (
          <>
            {groupedMigrationAgentMessages.length === 0 && !migrationAgentState.isRunning ? (
              <AiaBox
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  px: expanded ? 8 : 6,
                  py: 3,
                  textAlign: "center",
                }}
              >
                <AiaText sx={{ maxWidth: 520, fontSize: expanded ? 58 : 50, lineHeight: 1.04, fontWeight: 500, color: "#0f172a", letterSpacing: "-0.035em" }}>
                  Hi{assistantFirstName ? ` ${assistantFirstName}` : ""},
                </AiaText>
                <AiaText sx={{ maxWidth: 520, mt: 0.5, fontSize: expanded ? 58 : 50, lineHeight: 1.04, fontWeight: 400, color: "#64748b", letterSpacing: "-0.035em" }}>
                  How can I help?
                </AiaText>
                <AiaText sx={{ mt: 2, maxWidth: 520, fontSize: 13.5, color: "#475569", lineHeight: 1.6 }}>
                  Ask about your data or describe the migration you want to build.
                </AiaText>
              </AiaBox>
            ) : null}

            {/* Show the durable execution receipt before any streamed/model text. */}
            {migrationAgentState.isRunning && migrationAgentState.statusMessage && migrationAgentState.traceEvents.length === 0 && (
              <AiaStack direction="row" spacing={1.25} sx={{ alignItems: "center", px: 0.5, py: 0.75 }}>
                <AiaCircularProgress size={16} sx={{ color: "var(--aia-button-color)" }} />
                <AiaBox>
                  <AiaText sx={{ fontSize: 12, fontWeight: 700, color: "var(--aia-primary-text-color)" }}>
                    {migrationAgentState.statusMessage}
                  </AiaText>
                </AiaBox>
              </AiaStack>
            )}

            {/* Keep observable execution before model-authored narration so the
                user can inspect what ran before reading its interpretation. */}
            {migrationAgentState.traceEvents.length > 0 && (
              <AiaBox
                sx={{
                  position: "sticky",
                  top: 0,
                  zIndex: 6,
                  flexShrink: 0,
                  borderRadius: 2,
                  border: "1px solid #dbe2ea",
                  backgroundColor: "#ffffff",
                  boxShadow: "0 4px 14px rgba(15, 23, 42, 0.06)",
                  overflow: "hidden",
                }}
              >
                <AiaButton
                  onClick={() => setExpandedToolExecutions((prev) => !prev)}
                  variant="text"
                  sx={{
                    width: "100%",
                    px: 1.5,
                    py: 1,
                    justifyContent: "space-between",
                    textTransform: "none",
                    color: "var(--aia-primary-text-color)",
                    borderRadius: 0,
                    "&:hover": { backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)" },
                  }}
                >
                  <AiaStack direction="row" spacing={0.75} sx={{ minWidth: 0, alignItems: "center" }}>
                    {expandedToolExecutions ? (
                      <KeyboardArrowDownIcon sx={{ fontSize: 16, color: "var(--aia-button-color)" }} />
                    ) : (
                      <KeyboardArrowRightIcon sx={{ fontSize: 16, color: "var(--aia-button-color)" }} />
                    )}
                    <AiaBox sx={{ minWidth: 0, textAlign: "left" }}>
                      <AiaText noWrap sx={{ fontSize: 12, fontWeight: 750, color: "var(--aia-primary-text-color)" }}>
                        {migrationAgentState.isRunning
                          ? migrationActiveLabel
                          : migrationAgentState.error
                            ? "Execution failed"
                            : migrationAgentState.traceEvents.some((event) => event.status === "needs_review")
                              ? "Execution needs review"
                            : "Execution complete"}
                      </AiaText>
                      <AiaText noWrap sx={{ fontSize: 10.5, color: "#64748b" }}>
                        {migrationAgentState.traceEvents.length} update{migrationAgentState.traceEvents.length === 1 ? "" : "s"}
                        {migrationAgentState.resolvedEffort ? ` · ${migrationAgentState.resolvedEffort} effort` : ""}
                      </AiaText>
                    </AiaBox>
                  </AiaStack>
                </AiaButton>
                {migrationAgentState.isRunning ? (
                  <AiaBox sx={{ height: 2, overflow: "hidden", backgroundColor: "#e2e8f0" }}>
                    <AiaBox
                      aria-hidden="true"
                      sx={{
                        width: "34%",
                        height: "100%",
                        background: "linear-gradient(90deg, transparent, var(--aia-button-color), transparent)",
                        animation: "agentHeaderSweep 1.55s ease-in-out infinite",
                        "@keyframes agentHeaderSweep": {
                          from: { transform: "translateX(-110%)" },
                          to: { transform: "translateX(310%)" },
                        },
                      }}
                    />
                  </AiaBox>
                ) : null}
                {expandedToolExecutions && (
                  <AiaBox
                    onWheel={(event) => event.stopPropagation()}
                    sx={{
                      px: 1.5,
                      pb: 1.25,
                      pt: 0.55,
                      // This is a nested scroll region inside a flex-column
                      // message viewport. flexShrink: 0 is essential; without
                      // it, the browser can compress a 300px activity feed to
                      // a single visible row as conversation messages grow.
                      height: "clamp(340px, 48vh, 620px)",
                      minHeight: 340,
                      maxHeight: "min(620px, 62vh)",
                      flexShrink: 0,
                      overflowY: "auto",
                      overscrollBehavior: "contain",
                      scrollbarGutter: "stable",
                      touchAction: "pan-y",
                      WebkitOverflowScrolling: "touch",
                    }}
                  >
                    <MigrationTraceTree events={migrationAgentState.traceEvents.filter((event) => event.traceId !== migrationPlanEvent?.traceId)} />
                  </AiaBox>
                )}
              </AiaBox>
            )}

            {groupedMigrationAgentMessages.map((group) => {
              const isAssistant = group.role === "assistant";
              return (
                <AiaStack
                  key={group.id}
                  direction="row"
                  spacing={1.5}
                  sx={{ justifyContent: isAssistant ? "flex-start" : "flex-end" }}
                >
                  {isAssistant ? (
                    <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
                      <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
                    </AiaAvatar>
                  ) : null}

                  <AiaPaper
                    elevation={0}
                    sx={{
                      p: 1.5,
                      borderRadius: isAssistant ? "0 12px 12px 12px" : "12px 0 12px 12px",
                      border: isAssistant ? "1px solid #dbe2ea" : "1px solid #e2e8f0",
                      maxWidth: expanded ? "92%" : "85%",
                      minWidth: 0,
                      backgroundColor: isAssistant ? "#ffffff" : "#f8fafc",
                    }}
                  >
                    <AiaBox sx={{ minWidth: 0, maxWidth: "100%", fontSize: 14, overflowX: "hidden" }}>
                      {group.messages.map((message, index) => (
                        <AiaBox
                          key={message.id}
                          sx={{
                            pt: index ? 1.25 : 0,
                            mt: index ? 1.25 : 0,
                            borderTop: index ? "1px solid #e2e8f0" : "none",
                          }}
                        >
                          {isAssistant && message.kind === "final" && group.messages.length > 1 ? (
                            <AiaText sx={{ mb: 0.75, fontSize: 10.5, fontWeight: 800, letterSpacing: "0.06em", textTransform: "uppercase", color: "#64748b" }}>
                              Result
                            </AiaText>
                          ) : null}
                          {isAssistant ? (
                            <TypewriterMessageContent
                              content={message.content}
                              animate={message.animate === true}
                              messageId={message.id}
                              onComplete={completeMigrationAgentMessageAnimation}
                              onProgress={followMigrationAgentMessageAnimation}
                            />
                          ) : (
                            <MessageContent content={message.content} />
                          )}
                          {isAssistant && message.kind === 'final' && message.content.includes('## Migration plan research') ? (
                            <AiaButton size="small" variant="outlined" onClick={() => openReviewArtifact('research')}
                              sx={{ mt: 1, textTransform: 'none' }}>Open research and gaps in review workspace</AiaButton>
                          ) : null}
                          {isAssistant && message.kind === 'final' && /```sql\s*\n[\s\S]+?```/i.test(message.content) ? (
                            <AiaButton size="small" variant="outlined" onClick={() => {
                              const sql = message.content.match(/```sql\s*\n([\s\S]+?)```/i)?.[1]?.trim();
                              if (!sql) return;
                              setSqlArtifact({ sql, compileValid: false, previewValid: false, previewColumns: [], previewRows: [], previewRowCount: 0, mappedCount: 0, unresolvedCount: 0 });
                              openReviewArtifact('sql');
                            }} sx={{ mt: 1, textTransform: 'none' }}>Open SQL in review workspace</AiaButton>
                          ) : null}
                          {isAssistant && message.question?.options?.length ? (
                            <AiaStack spacing={0.75} sx={{ mt: 1.25, width: "100%", minWidth: 0, maxWidth: "100%" }}>
                              <AiaText sx={{ fontSize: 13, fontWeight: 700, overflowWrap: "anywhere" }}>{message.question.prompt}</AiaText>
                              {message.question.options.map((option, optionIndex) => (
                                <QuestionChoiceButton
                                  key={`${message.id}:option:${optionIndex}`}
                                  label={option.label}
                                  description={option.description}
                                  disabled={migrationAgentState.isRunning}
                                  onClick={() => void connectAndSendMigrationAgentMessage(
                                    `For the transcript question "${message.question?.prompt}", I choose "${option.label}". Summarize what this choice means and what remains unresolved.`,
                                  )}
                                />
                              ))}
                            </AiaStack>
                          ) : null}
                        </AiaBox>
                      ))}
                    </AiaBox>
                  </AiaPaper>
                </AiaStack>
              );
            })}

            {(migrationAgentState.reviewItems.length > 0 || migrationAgentState.reviewArtifact) && !migrationAgentState.isRunning && (
              <AiaPaper
                elevation={0}
                sx={{ p: 1.5, borderRadius: 2, border: "1px solid #cbd5e1", backgroundColor: "#ffffff", minWidth: 0 }}
              >
                <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
                  Draft implementation review
                </AiaText>
                {migrationAgentState.reviewArtifact && (
                  <AiaBox sx={{ mt: 0.7 }}>
                    <AiaText sx={{ fontSize: 12, color: "#78350f" }}>
                      {migrationAgentState.reviewArtifact.mappedCount} mapped · {migrationAgentState.reviewArtifact.unresolvedCount} unresolved ·
                      SQL compile {migrationAgentState.reviewArtifact.compileValid ? "passed" : "not passed"} ·
                      sample preview {migrationAgentState.reviewArtifact.previewValid ? "passed" : "not passed"}
                    </AiaText>
                    {migrationAgentState.reviewArtifact.sql ? <AiaStack direction="row" spacing={0.75} sx={{ mt: 1, flexWrap: 'wrap', rowGap: 0.5 }}>
                      <AiaButton size="small" variant="outlined" onClick={() => openReviewArtifact('sql')} sx={{ textTransform: 'none' }}>Open SQL preview</AiaButton>
                      {migrationAgentState.reviewArtifact.previewRows.length > 0 ? <AiaButton size="small" variant="outlined" onClick={() => openReviewArtifact('results')} sx={{ textTransform: 'none' }}>Open sample results</AiaButton> : null}
                    </AiaStack> : null}
                  </AiaBox>
                )}
                {activeMappingReview ? <AiaBox sx={{ mt: 1.2, p: 1.2, border: "1px solid #e2e8f0", borderRadius: 1, backgroundColor: "#fff", minWidth: 0 }}>
                  <AiaText sx={{ fontSize: 12, fontWeight: 800 }}>
                    Mapping question {activeReviewIndex + 1} of {openMappingReviews.length}
                  </AiaText>
                  <AiaText sx={{ mt: 0.5, fontSize: 13, fontWeight: 700, overflowWrap: "anywhere" }}>{activeMappingReview.question}</AiaText>
                  <AiaStack spacing={0.7} sx={{ mt: 1, minWidth: 0 }}>
                    {activeMappingReview.choices.map((choice) => <QuestionChoiceButton key={choice.id}
                      label={choice.label}
                      description={choice.description}
                      disabled={reviewDecisionBusy}
                      onClick={() => {
                        const client = migrationAgentClientRef.current;
                        if (!client) return;
                        setReviewDecisionBusy(true);
                        setReviewDecisionError(null);
                        void client.answerReviewDecision(migrationAgentState.reviewContextHash, activeMappingReview.id, choice.id)
                          .then(() => setReviewQuestionIndex(0))
                          .catch((error) => setReviewDecisionError(error instanceof Error ? error.message : "Could not record decision"))
                          .finally(() => setReviewDecisionBusy(false));
                      }} />)}
                  </AiaStack>
                  <AiaInput size="small" multiline minRows={2} value={reviewSuggestion} onChange={setReviewSuggestion}
                    placeholder="Suggest source columns, a transformation, or why these candidates are unsuitable"
                    sx={{ mt: 1 }} />
                  <AiaButton size="small" variant="outlined" disabled={reviewDecisionBusy || !reviewSuggestion.trim()}
                    onClick={() => {
                      const client = migrationAgentClientRef.current;
                      if (!client) return;
                      setReviewDecisionBusy(true);
                      setReviewDecisionError(null);
                      void client.answerReviewDecision(migrationAgentState.reviewContextHash, activeMappingReview.id,
                        null, reviewSuggestion.trim())
                        .then(() => { setReviewSuggestion(""); setReviewQuestionIndex(0); })
                        .catch((error) => setReviewDecisionError(error instanceof Error ? error.message : "Could not record suggestion"))
                        .finally(() => setReviewDecisionBusy(false));
                    }} sx={{ mt: 0.7, textTransform: "none" }}>Record suggestion</AiaButton>
                  <AiaStack direction="row" spacing={1} sx={{ mt: 1 }}>
                    <AiaButton size="small" disabled={activeReviewIndex === 0} onClick={() => setReviewQuestionIndex(activeReviewIndex - 1)}>Previous</AiaButton>
                    <AiaButton size="small" disabled={activeReviewIndex >= openMappingReviews.length - 1} onClick={() => setReviewQuestionIndex(activeReviewIndex + 1)}>Next</AiaButton>
                  </AiaStack>
                  {reviewDecisionError && <AiaText sx={{ fontSize: 12, color: "#b91c1c" }}>{reviewDecisionError}</AiaText>}
                  <AiaText sx={{ mt: 0.7, fontSize: 11, color: "#78350f" }}>Your choice is recorded for review. Apply or revise the rule in the saved draft before full validation.</AiaText>
                </AiaBox> : null}
                {reviewDraftId && <AiaBox component="a" href={`/sttm/builder/${encodeURIComponent(reviewDraftId)}/mapping`}
                  sx={{ display: "inline-block", mt: 1, fontSize: 12, fontWeight: 700, color: "#1d4ed8" }}>Open saved mapping draft</AiaBox>}
                {!activeMappingReview && migrationAgentState.reviewItems.some((item) => item.status === 'OPEN') ? <AiaBox sx={{ mt: 1 }}>
                  {migrationAgentState.reviewItems.filter((item) => item.status === 'OPEN').map((item) => (
                    <AiaText key={item.id} sx={{ mt: 0.5, fontSize: 12, color: '#78350f' }}>{item.summary}</AiaText>
                  ))}
                  <AiaButton size="small" variant="outlined" onClick={() => handleSend(
                    'Continue the source research from the previous run. Use the current verified table contracts and all available migration evidence to propose the supported driving source and join options. Ask me one structured question with the viable choices before drafting the mapping.'
                  )} sx={{ mt: 0.8, textTransform: 'none' }}>Continue source research</AiaButton>
                </AiaBox> : null}
              </AiaPaper>
            )}

            {/* Streaming Migration Agent response */}
            {migrationAgentState.streamingText && (
              <AiaStack direction="row" spacing={1.5} sx={{ justifyContent: "flex-start" }}>
                <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
                  <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
                </AiaAvatar>
                <AiaPaper
                  elevation={0}
                  sx={{
                    p: 1.5,
                    borderRadius: "0 12px 12px 12px",
                    border: "1px solid #dbe2ea",
                    maxWidth: expanded ? "92%" : "85%",
                    minWidth: 0,
                    backgroundColor: "#ffffff",
                  }}
                >
                  <AiaBox sx={{ minWidth: 0, maxWidth: "100%", fontSize: 14, overflowX: "hidden" }}>
                    <MessageContent content={migrationAgentState.streamingText} />
                  </AiaBox>
                </AiaPaper>
              </AiaStack>
            )}

            {/* Migration Agent Permission Request Dialog */}
            {migrationAgentState.pendingPermission && migrationAgentState.pendingPermission.category !== "plan_mode_recommendation" && migrationAgentState.pendingPermission.tool !== "approve_migration_plan" && (
              <AiaPaper
                elevation={0}
                sx={{
                  p: 1.75,
                  borderRadius: 2,
                  border: "1px solid #cbd5e1",
                  backgroundColor: "#ffffff",
                  maxWidth: "100%",
                  minWidth: 0,
                }}
              >
                <AiaStack spacing={1.25} sx={{ minWidth: 0 }}>
                  <AiaBox sx={{ minWidth: 0 }}>
                    <AiaText sx={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                      Question
                    </AiaText>
                    <AiaText sx={{ mt: 0.5, fontSize: 14, fontWeight: 700, color: "#0f172a", lineHeight: 1.5, overflowWrap: "anywhere" }}>
                      {migrationAgentState.pendingPermission.questions?.[0]?.question || migrationAgentState.pendingPermission.reason}
                    </AiaText>
                  </AiaBox>
                  <AiaStack spacing={0.75} sx={{ minWidth: 0 }}>
                    {(migrationAgentState.pendingPermission.questions?.[0]?.options ?? []).map((option) => (
                      <QuestionChoiceButton
                        key={option.id ?? option.label}
                        label={option.label}
                        description={option.description}
                        recommended={option.recommended}
                        onClick={() => handlePermissionChoice(String(option.id), option.label)}
                      />
                    ))}
                    {migrationAgentState.pendingPermission.allow_free_text && (
                      <AiaStack spacing={0.75} sx={{ mt: 0.5, minWidth: 0 }}>
                        {(migrationAgentState.pendingPermission.questions?.[0]?.options ?? []).length === 0 && (
                          <AiaText sx={{ fontSize: 12, color: "#64748b" }}>
                            No verified path was found. You can provide the business join rule.
                          </AiaText>
                        )}
                        <QuestionChoiceButton label="Other" description="Enter a different answer or join rule" onClick={() => setOtherAnswerOpen((open) => !open)} />
                        {otherAnswerOpen && (
                          <AiaStack spacing={0.75} sx={{ minWidth: 0 }}>
                            <AiaInput
                              value={otherAnswer}
                              onChange={setOtherAnswer}
                              multiline
                              minRows={2}
                              placeholder={migrationAgentState.pendingPermission.answer_hint || "Type your answer"}
                              sx={{ "& .MuiInputBase-input": { fontSize: 13, lineHeight: 1.5 } }}
                            />
                            <AiaButton size="small" variant="outlined" disabled={!otherAnswer.trim()}
                              onClick={() => { if (handleSend(otherAnswer)) { setOtherAnswer(""); setOtherAnswerOpen(false); } }}
                              sx={{ alignSelf: "flex-start", textTransform: "none", fontSize: 13 }}>
                              Submit answer
                            </AiaButton>
                          </AiaStack>
                        )}
                      </AiaStack>
                    )}
                    <AiaButton
                      size="small"
                      variant="text"
                      onClick={() => handlePermissionDecision("cancel")}
                      sx={{ alignSelf: "flex-start", textTransform: "none", color: "#64748b" }}
                    >
                      Cancel
                    </AiaButton>
                  </AiaStack>
                </AiaStack>
              </AiaPaper>
            )}

            {/* Migration Agent Error Display */}
            {migrationAgentState.error && (
              <AiaPaper
                elevation={0}
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  border: "1px solid #fecaca",
                  backgroundColor: "#fef2f2",
                }}
              >
                <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                  <WarningAmberRoundedIcon sx={{ fontSize: 18, color: "#dc2626" }} />
                  <AiaText sx={{ fontSize: 13, color: "#991b1b" }}>{migrationAgentState.error}</AiaText>
                </AiaStack>
              </AiaPaper>
            )}

          </>
        ) : (
          /* Quick Assistant messages */
          visibleStandardChatMessages.map((message, index) => {
            const isAssistant = message.role === "assistant";
            const messageId = message.id ?? `${message.role}-${index}-${message.content.slice(0, 24)}`;
            const isWelcome =
              isAssistant
              && (
                message.id === "sttm-assistant-welcome"
                || message.content.includes(
                  "I can use the selected source and target semantics",
                )
              );
            const traceSteps = message.traceSteps ?? [];
            const isTraceExpanded = message.isStreaming || !!expandedTraces[messageId];
            return (
              <AiaStack
                key={messageId}
                direction="column"
                spacing={0.5}
                sx={{
                  alignItems: isAssistant ? "flex-start" : "flex-end",
                  ...(isWelcome
                    ? {
                        width: "100%",
                        maxWidth: 520,
                        alignItems: "center",
                        justifyContent: "center",
                      }
                    : {}),
                }}
              >
                <AiaStack
                  direction="row"
                  spacing={1.5}
                  sx={{
                    justifyContent: isWelcome ? "center" : isAssistant ? "flex-start" : "flex-end",
                    width: "100%",
                  }}
                >
                  {isAssistant && !isWelcome ? (
                    <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
                      <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
                    </AiaAvatar>
                  ) : null}

                  <AiaPaper
                  elevation={0}
                  sx={{
                    p: 1.5,
                    borderRadius: isAssistant ? "0 12px 12px 12px" : "12px 0 12px 12px",
                    border: "1px solid #e2e8f0",
                    maxWidth: expanded ? "92%" : "85%",
                    minWidth: 0,
                    overflow: "hidden",
                    backgroundColor: isAssistant ? "#ffffff" : "#f8fafc",
                    ...(isWelcome
                      ? {
                          width: "100%",
                          maxWidth: "100%",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          justifyContent: "center",
                          border: "none",
                          borderRadius: 0,
                          px: expanded ? 8 : 6,
                          py: 3,
                          backgroundColor: "transparent",
                        }
                      : {}),
                  }}
                >
                  <AiaBox sx={{ minWidth: 0, maxWidth: "100%", fontSize: 14, overflowX: "hidden" }}>
                    {isWelcome ? (
                      <AiaBox sx={{ width: "100%", maxWidth: 520, mb: 2.5, textAlign: "center" }}>
                        <AiaText
                          sx={{
                            fontSize: expanded ? 58 : 50,
                            lineHeight: 1.04,
                            fontWeight: 500,
                            color: "#0f172a",
                            letterSpacing: "-0.035em",
                          }}
                        >
                          Hi{assistantFirstName ? ` ${assistantFirstName}` : ""},
                        </AiaText>
                        <AiaText
                          sx={{
                            mt: 0.5,
                            fontSize: expanded ? 58 : 50,
                            lineHeight: 1.04,
                            fontWeight: 400,
                            color: "#64748b",
                            letterSpacing: "-0.035em",
                          }}
                        >
                          How can I help?
                        </AiaText>
                        {message.content.trim() ? (
                          <AiaText sx={{ mt: 2, fontSize: 13.5, color: "#475569", lineHeight: 1.6 }}>
                            {message.content}
                          </AiaText>
                        ) : null}
                      </AiaBox>
                    ) : (
                      <MessageContent content={message.content} formatPlainText={isAssistant} />
                    )}
                    {message.streamingSql ? (
                      <MessageContent
                        content={`\`\`\`sql\n${message.streamingSql}\n\`\`\``}
                        formatPlainText={false}
                      />
                    ) : null}
                  </AiaBox>
                  {traceSteps.length ? (
                    <TracePanel
                      messageId={messageId}
                      steps={traceSteps}
                      expanded={isTraceExpanded}
                      onToggle={toggleTrace}
                    />
                  ) : null}
                  {message.isStreaming ? (
                    <StreamingProgressIndicator
                      phase={message.statusPhase}
                      message={message.statusMessage}
                      elapsedSeconds={message.elapsedSeconds}
                    />
                  ) : null}
                  {message.options?.length ? (
                    <AiaStack
                      direction={isWelcome ? "column" : "row"}
                      spacing={0.75}
                      useFlexGap
                      sx={{
                        mt: 1.25,
                        // Column layout must not wrap: wrapping a column flex
                        // container pushes the extra options into off-screen
                        // columns instead of stacking them.
                        flexWrap: isWelcome ? "nowrap" : "wrap",
                        width: "100%",
                        maxWidth: isWelcome ? 460 : "100%",
                        alignItems: isWelcome ? "center" : undefined,
                        mx: 0,
                        minWidth: 0,
                        overflow: "hidden",
                      }}
                    >
                      {message.options.map((option) => (
                        <AiaButton
                          key={option}
                          size="small"
                          variant="outlined"
                          onClick={() => sendChatMessage(option)}
                          disabled={chatLoading}
                          sx={{
                            textTransform: "none",
                            borderRadius: "999px",
                            borderColor: "#bfdbfe",
                            color: "#1d4ed8",
                            fontSize: isWelcome ? 13 : 12,
                            lineHeight: 1.4,
                            minWidth: 0,
                            maxWidth: "100%",
                            height: "auto",
                            // In a column stack `flex-basis: 100%` resolves
                            // against the container height, so keep the pills
                            // sized by their content and full-width via `width`.
                            flex: isWelcome ? "0 0 auto" : "0 1 auto",
                            width: isWelcome ? "100%" : "auto",
                            whiteSpace: "normal",
                            overflowWrap: "anywhere",
                            wordBreak: "break-word",
                            textAlign: "left",
                            justifyContent: "flex-start",
                            py: isWelcome ? 1.15 : 0.75,
                            px: isWelcome ? 1.75 : undefined,
                            "&:hover": {
                              borderColor: "#93c5fd",
                              backgroundColor: "#eff6ff",
                            },
                          }}
                        >
                          {option}
                        </AiaButton>
                      ))}
                    </AiaStack>
                  ) : null}
                </AiaPaper>
                </AiaStack>
                {isAssistant && !isWelcome && !message.isStreaming ? (
                  <AiaStack direction="row" spacing={0.75} sx={{ mt: 0.5, ml: 3.5 }}>
                    <AiaIconButton
                      size="small"
                      onClick={() => {
                        navigator.clipboard.writeText(message.content);
                      }}
                      sx={{ color: "#94a3b8", "&:hover": { color: "#64748b" } }}
                      title="Copy response"
                    >
                      <ContentCopyRoundedIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                    <AiaIconButton
                      size="small"
                      onClick={() => {
                        if (message.id) {
                          submitChatFeedback({ messageId: message.id, rating: 5 });
                        }
                      }}
                      disabled={!message.id || message.feedbackStatus === "sent"}
                      sx={{
                        color: message.feedbackRating === 5 ? "#16a34a" : "#94a3b8",
                        "&:hover": { color: "#16a34a" },
                      }}
                      title="This was helpful"
                    >
                      <ThumbUpAltOutlinedIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                    <AiaIconButton
                      size="small"
                      onClick={() => {
                        if (message.id) {
                          submitChatFeedback({ messageId: message.id, rating: 1 });
                        }
                      }}
                      disabled={!message.id || message.feedbackStatus === "sent"}
                      sx={{
                        color: message.feedbackRating === 1 ? "#dc2626" : "#94a3b8",
                        "&:hover": { color: "#dc2626" },
                      }}
                      title="This wasn't helpful"
                    >
                      <ThumbDownAltOutlinedIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                    <AiaIconButton
                      size="small"
                      onClick={() => sendChatMessage("Can you provide an alternative response?")}
                      disabled={chatLoading}
                      sx={{ color: "#94a3b8", "&:hover": { color: "#2563eb" } }}
                      title="Regenerate response"
                    >
                      <BoltIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                  </AiaStack>
                ) : null}
              </AiaStack>
            );
          })
        )}

        {/* Standard mode loading indicator - only show when not in Migration Agent mode */}
        {!migrationAgentState.isActive && chatLoading && !hasStreamingMessage ? (
          <AiaStack direction="row" spacing={1.5} sx={{ alignItems: "center" }}>
            <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
              <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
            </AiaAvatar>
            <AiaPaper
              elevation={0}
              sx={{
                px: 1.5,
                py: 1.25,
                borderRadius: "0 12px 12px 12px",
                border: "1px solid #e2e8f0",
                backgroundColor: "#ffffff",
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              <AiaCircularProgress size={14} thickness={5} sx={{ color: "#2563eb" }} />
              <AiaText variant="body1" sx={{ color: "#475569" }}>
                Thinking…
              </AiaText>
            </AiaPaper>
          </AiaStack>
        ) : null}

        {activeReview ? (
          <AiaPaper
            elevation={0}
            sx={{
              p: 1.5,
              borderRadius: "12px",
              border: "1px solid #fde68a",
              backgroundColor: "#fffbeb",
              display: "grid",
              gap: 1,
            }}
          >
            <AiaBox>
              <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#92400e" }}>
                {isTransformationReview
                  ? "Review AI transformation suggestion"
                  : "Review AI mapping suggestion"}
              </AiaText>
              <AiaText sx={{ fontSize: 12, color: "#475569", mt: 0.35 }}>
                {activeReview.targetColumn} · {Math.round(activeReview.confidenceScore * 100)}% confidence
              </AiaText>
            </AiaBox>
            <AiaBox sx={{ display: "grid", gap: 0.75 }}>
              <AiaText sx={{ fontSize: 12.5, color: "#0f172a" }}>
                <strong>Suggested source:</strong> {activeReview.sourceAttributes.join(", ") || "No confident source found"}
              </AiaText>
              {activeReview.preprocessingRule ? (
                <AiaBox
                  component="pre"
                  sx={{
                    m: 0,
                    px: 1.25,
                    py: 1,
                    borderRadius: 1.5,
                    backgroundColor: "#fff7ed",
                    border: "1px solid #fed7aa",
                    color: "#7c2d12",
                    fontSize: 12,
                    whiteSpace: "pre-wrap",
                    overflowX: "auto",
                  }}
                >
                  <strong>Suggested SQL rule:</strong>
                  {"\n"}
                  {activeReview.preprocessingRule}
                </AiaBox>
              ) : null}
              {activeReview.preprocessingNlRule ? (
                <AiaText sx={{ fontSize: 12.5, color: "#0f172a" }}>
                  <strong>Why:</strong> {activeReview.preprocessingNlRule}
                </AiaText>
              ) : null}
              {activeReview.confidenceReason ? (
                <AiaText sx={{ fontSize: 12.5, color: "#475569", lineHeight: 1.6 }}>
                  {activeReview.confidenceReason}
                </AiaText>
              ) : null}
              {!activeReview.confidenceReason && activeReview.unmatchedReason ? (
                <AiaText sx={{ fontSize: 12.5, color: "#b45309", lineHeight: 1.6 }}>
                  {activeReview.unmatchedReason}
                </AiaText>
              ) : null}
              {activeReview.candidateSourceAttributes.length > 0 ? (
                <AiaText sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.6 }}>
                  Alternatives: {activeReview.candidateSourceAttributes.join(", ")}
                </AiaText>
              ) : null}
            </AiaBox>
            <AiaStack direction="row" spacing={1} useFlexGap sx={{ flexWrap: "wrap" }}>
              <AiaButton
                size="small"
                variant="contained"
                onClick={applyPendingAiMappingReview}
                sx={{
                  textTransform: "none",
                  borderRadius: "999px",
                  boxShadow: "none",
                  backgroundColor: "#1d4ed8",
                  "&:hover": { backgroundColor: "#1e40af", boxShadow: "none" },
                }}
              >
                Apply Changes
              </AiaButton>
              <AiaButton
                size="small"
                variant="outlined"
                onClick={() =>
                  setDraft(
                    isTransformationReview
                      ? `Revise the transformation rule for ${activeReview.targetColumn}. Use these notes: `
                      : `Revise the mapping for ${activeReview.targetColumn}. Use these notes: `,
                  )
                }
                sx={{
                  textTransform: "none",
                  borderRadius: "999px",
                }}
              >
                Make Further Changes
              </AiaButton>
              <AiaButton
                size="small"
                variant="text"
                onClick={skipPendingAiMappingReview}
                sx={{ textTransform: "none", color: "#64748b" }}
              >
                Dismiss
              </AiaButton>
            </AiaStack>
          </AiaPaper>
        ) : null}

        {pendingDerivedSourceDraft ? (
          <AiaPaper
            elevation={0}
            sx={{
              p: 1.5,
              borderRadius: "12px",
              border: "1px solid #dbeafe",
              backgroundColor: "#eff6ff",
              display: "grid",
              gap: 1,
            }}
          >
            <AiaBox>
              <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#1d4ed8" }}>
                Analyst-generated derived SQL is ready
              </AiaText>
              <AiaText sx={{ fontSize: 12, color: "#334155", mt: 0.25 }}>
                Open it in the derived-source builder to validate, preview, and save it through the existing flow.
              </AiaText>
            </AiaBox>
            <AiaStack direction="row" spacing={1}>
              <AiaButton
                size="small"
                variant="contained"
                onClick={openPendingDerivedSourceDraft}
                sx={{
                  textTransform: "none",
                  borderRadius: "999px",
                  boxShadow: "none",
                  backgroundColor: "#1d4ed8",
                  "&:hover": { backgroundColor: "#1e40af", boxShadow: "none" },
                }}
              >
                Open In Derived Builder
              </AiaButton>
              <AiaButton
                size="small"
                variant="text"
                onClick={dismissPendingDerivedSourceDraft}
                sx={{ textTransform: "none", color: "#475569" }}
              >
                Dismiss
              </AiaButton>
            </AiaStack>
          </AiaPaper>
        ) : null}
          </>
        ) : null}
      </AiaBox>

      <AiaBox sx={{ p: 1, backgroundColor: "#ffffff", borderTop: "1px solid #e2e8f0" }}>
        {migrationAgentState.isActive && planDocument ? (
          <AiaButton size="small" variant="outlined" onClick={() => openReviewArtifact('plan')} sx={{ mb: 0.75, mr: 0.75, textTransform: "none", borderRadius: "999px" }}>
            View plan revision {String(planDocument.revision ?? 1)}
          </AiaButton>
        ) : null}
        {migrationAgentState.isActive && sqlArtifact?.sql ? (
          <AiaButton size="small" variant="outlined" onClick={() => openReviewArtifact('sql')} sx={{ mb: 0.75, textTransform: "none", borderRadius: "999px" }}>
            View SQL preview
          </AiaButton>
        ) : null}
        {migrationAgentState.isActive && researchReport ? <AiaButton size="small" variant="outlined" onClick={() => openReviewArtifact('research')}
          sx={{ mb: 0.75, mr: 0.75, textTransform: 'none', borderRadius: '999px' }}>View research and gaps</AiaButton> : null}
        {migrationAgentState.isActive && migrationPlanEvent ? (
          <MigrationPlanStatusChip
            event={migrationPlanEvent}
            running={migrationAgentState.isRunning}
            needsReview={migrationAgentState.traceEvents.some((event) => event.status === "needs_review")}
            activeLabel={migrationActiveLabel}
          />
        ) : null}
        {migrationAgentState.isActive && migrationAgentState.isRunning && !migrationPlanEvent ? (
          <MigrationRunStatusChip
            label={
              migrationAgentMessages[migrationAgentMessages.length - 1]?.animate
                ? "Streaming response"
                : migrationAgentState.statusMessage || "Agent is working"
            }
          />
        ) : null}
        {migrationAgentState.isActive && migrationAttachments.length > 0 && (
          <AiaText sx={{ px: 1, pb: 0.5, fontSize: 10, color: "#64748b" }}>
            Attachments: {migrationAttachments.map((attachment) => attachment.name).join(", ")}
          </AiaText>
        )}
        <AiChatComposer
          value={draft}
          onChange={setDraft}
          onSend={handleSend}
          mode={migrationAgentState.isActive ? "deep" : "quick"}
          onModeChange={(mode) => {
            if ((mode === "deep") !== migrationAgentState.isActive) {
              toggleMigrationAgentMode();
            }
          }}
          effort={migrationEffort}
          onEffortChange={setMigrationEffort}
          modelName={migrationModelName}
          onModelNameChange={setMigrationModelName}
          modelOptions={migrationModelOptions}
          effortModelDefaults={migrationEffortModels}
          runMode={migrationRunMode}
          onRunModeChange={setMigrationRunMode}
          deepAgentAvailable={migrationAgentAvailable !== false}
          onAttachFile={(file) => void handleMigrationAttachment(file)}
          attachmentUploading={migrationAttachmentUploading}
          running={migrationAgentState.isRunning && !migrationAgentState.pendingPermission}
          cancelling={migrationAgentState.isCancelling}
          onCancel={() => {
            if (migrationAgentState.isCancelling) return;
            setMigrationAgentState((state) => ({
              ...state,
              isCancelling: true,
              statusMessage: "Stopping at the next safe boundary…",
            }));
            migrationAgentClientRef.current?.cancel("");
          }}
          disabled={migrationAgentState.isActive
            ? migrationAgentState.isConnecting
              || (migrationAgentState.isRunning && !migrationAgentState.pendingPermission)
              || Boolean(pendingPlanOffer)
              || migrationAgentState.pendingPermission?.allow_free_text === false
            : false}
          loading={migrationAgentState.isActive ? migrationAgentState.isRunning && !migrationAgentState.pendingPermission : chatLoading}
        />
      </AiaBox>
      {pendingPlanOffer ? (
        <AiaBox role="dialog" aria-modal="true" aria-label="Choose planning mode" sx={{ position: "fixed", inset: 0, zIndex: 1600, display: "grid", placeItems: "center", p: 2, backgroundColor: "rgba(15, 23, 42, 0.45)" }}>
          <AiaPaper sx={{ width: "min(520px, 100%)", p: 2.5, borderRadius: 2, boxShadow: "0 24px 64px rgba(15,23,42,0.25)" }}>
            <AiaText sx={{ fontSize: 17, fontWeight: 800, color: "#0f172a" }}>Review a plan first?</AiaText>
            <AiaText sx={{ mt: 0.7, fontSize: 13, lineHeight: 1.5, color: "#475569" }}>{pendingPlanOffer.reason}</AiaText>
            <AiaStack spacing={0.8} sx={{ mt: 2 }}>
              <AiaButton variant="contained" onClick={() => {
                setPendingPlanOffer(null);
                setMigrationRunMode("plan");
                setMigrationAgentState((prev) => ({ ...prev, isRunning: true, statusMessage: "Preparing a reviewable plan…" }));
                migrationAgentClientRef.current?.resumePlanOffer("plan");
              }} sx={{ textTransform: "none" }}>Switch to Plan mode</AiaButton>
              <AiaButton variant="outlined" onClick={() => {
                setPendingPlanOffer(null);
                setMigrationRunMode("auto");
                setMigrationAgentState((prev) => ({ ...prev, isRunning: true, statusMessage: "Continuing automatically…" }));
                migrationAgentClientRef.current?.resumePlanOffer("auto");
              }} sx={{ textTransform: "none" }}>Continue automatically</AiaButton>
              <AiaButton variant="text" onClick={() => {
                migrationAgentClientRef.current?.dismissPlanOffer();
                setPendingPlanOffer(null);
                setMigrationAgentState((prev) => ({ ...prev, isRunning: false, statusMessage: null }));
              }} sx={{ textTransform: "none" }}>Cancel request</AiaButton>
            </AiaStack>
          </AiaPaper>
        </AiaBox>
      ) : null}
      {migrationAgentState.pendingPermission?.category === "plan_mode_recommendation" ? (
        <AiaBox role="dialog" aria-modal="true" aria-label="Choose planning mode" sx={{ position: "fixed", inset: 0, zIndex: 1600, display: "grid", placeItems: "center", p: 2, backgroundColor: "rgba(15, 23, 42, 0.45)" }}>
          <AiaPaper sx={{ width: "min(520px, 100%)", p: 2.5, borderRadius: 2, boxShadow: "0 24px 64px rgba(15,23,42,0.25)" }}>
            <AiaText sx={{ fontSize: 17, fontWeight: 800, color: "#0f172a" }}>Review a plan first?</AiaText>
            <AiaText sx={{ mt: 0.7, fontSize: 13, lineHeight: 1.5, color: "#475569" }}>{migrationAgentState.pendingPermission.reason}</AiaText>
            <AiaStack spacing={0.8} sx={{ mt: 2 }}>
              {(migrationAgentState.pendingPermission.questions?.[0]?.options ?? []).map((option) => (
                <QuestionChoiceButton
                  key={option.id ?? option.label}
                  label={option.label}
                  description={option.description}
                  recommended={option.recommended}
                  onClick={() => handlePermissionChoice(String(option.id), option.label)}
                />
              ))}
            </AiaStack>
          </AiaPaper>
        </AiaBox>
      ) : null}
    </AiaPaper>
    {planSidebarOpen && (planDocument || sqlArtifact || researchReport) ? <AgentArtifactPane
      key={artifactVersion}
      pageMode={pageMode}
      tab={artifactTab}
      onTabChange={setArtifactTab}
      onClose={() => setPlanSidebarOpen(false)}
      plan={planDocument}
      planContent={planDocument ? <MigrationPlanApprovalSummary plan={planDocument} /> : null}
      hasResearch={Boolean(researchReport)}
      researchText={researchReport}
      researchContent={researchReport ? <MessageContent content={researchReport} /> : null}
      sqlArtifact={sqlArtifact}
      planChoices={migrationAgentState.pendingPermission?.tool === 'approve_migration_plan'
        ? migrationAgentState.pendingPermission.questions?.[0]?.options ?? [] : []}
      planEditQuestion={migrationAgentState.pendingPermission?.category === 'plan_edit'
        ? migrationAgentState.pendingPermission.questions?.[0]?.question || migrationAgentState.pendingPermission.reason : null}
      busy={migrationAgentState.isRunning || migrationAgentState.isConnecting || Boolean(migrationAgentState.pendingPermission && migrationAgentState.pendingPermission.tool !== 'approve_migration_plan' && migrationAgentState.pendingPermission.category !== 'plan_edit')}
      sqlActionDisabled={migrationAgentState.isRunning || migrationAgentState.isConnecting || Boolean(migrationAgentState.pendingPermission)}
      onPlanChoice={(id, label) => handlePermissionChoice(id, label)}
      onPlanFeedback={(feedback) => { handleSend(feedback); }}
      onSqlRevision={(sql, note) => { handleSend(`Revise the latest generated mapping SQL to use the following edited SQL. Compile it and run a bounded preview before returning the new SQL and results. ${note ? `Review note: ${note}\n\n` : ''}\`\`\`sql\n${sql}\n\`\`\``); }}
      onSqlReject={(reason) => { handleSend(`I reject the latest generated mapping SQL because: ${reason}. Revise the SQL, compile it, and return a bounded sample preview for review.`); }}
    /> : null}
    </AiaBox>
  );
}
