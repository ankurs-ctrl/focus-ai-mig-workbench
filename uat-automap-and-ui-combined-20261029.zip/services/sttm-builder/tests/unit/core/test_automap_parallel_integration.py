"""Offline production batch hook tests; no SQL, network or live agents."""
from copy import deepcopy
from dataclasses import replace
import json
import time
from types import SimpleNamespace

import pytest

from app.core.automap_admission import ScanCallAdmission
from app.core.automap_batch import ParallelRuntimeBundle, invoke_batch
from app.core.automap_parallel import ParallelLimits, prepare_parallel
from app.core.automap_policy import focused_learning
from app.core.automap_retrieval import AutoMapContext, ParallelRegistryProjection, batch_packet
from app.core.automap_shards import MessageBudget, SnapshotScope
from app.core.config import Settings
from app.schema.contracts import ApiWarning
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMStatus
from scripts.automap_message_sizes import expand_packet
from tests.unit.core.test_automap_parallel import Archive, Backend, Pool
from tests.unit.core.test_automap_retrieval import ScriptedAgent, payload, service


def request_payload(*, huge=False, target_count=1):
    value = payload(target_count=target_count, description_size=0)
    value["context"]["learning_context"]["correction_history"][0].update(
        incorrect_source=["a.CONTACT_NAME"], correct_source=["a.X47"], error_category="wrong_source", correction_count=1)
    value["context"]["workspace_context"] = {"driving_relation_id": "a", "filters": {"filter_sql": "a.X47 IS NOT NULL"}}
    if huge:
        table = {"database": "D", "schema": "S", "table": "HUGE"}
        columns = [{"name": f"UNSELECTED_{index:04d}", "data_type": "TEXT",
                    "business_meaning": "huge unrelated business meaning " * 10} for index in range(800)]
        value["context"]["source_tables"].append(table)
        value["context"]["semantic_context"].append({"table": table, "semantic_model": {"attributes": columns}})
        value["context"]["relation_graph"]["nodes"].append({"relation_id": "huge", "alias": "huge",
            "kind": "PHYSICAL_TABLE", "table": table, "output_columns": deepcopy(columns)})
    return value


def runtime(store, *, scan_size=100_000):
    budget = MessageBudget(100_000, 100_000)
    pool, archive, backend = Pool(), Archive(), Backend()
    return ParallelRuntimeBundle(SnapshotScope("caller", store.snapshot_hash), backend,
        ScanCallAdmission(pool, job_id="job", caller_id="caller", heartbeat_seconds=30, poll_seconds=0.001),
        archive, ParallelLimits(MessageBudget(scan_size, scan_size), budget, budget, budget,
            max_workers=2, max_calls=20, max_reduction_rounds=10, candidate_cap=4, fan_in=6,
            max_selected_sources=4, max_selected_records=100))


def enabled_service(agent=None):
    builder = service(agent or ScriptedAgent())
    builder._settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
        AUTOMAP_PARALLEL_CONTEXT_V1=True, AUTOMAP_PARALLEL_TEST_AGENT="D.S.SCAN_AGENT",
        AUTOMAP_PARALLEL_PERMIT_TABLE_FQN="D.S.PERMITS",
        AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN="D.S.ARCHIVE",
        AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE="ORG.ACCOUNT",
        AUTOMAP_PARALLEL_POOL_EPOCH="11111111-1111-1111-1111-111111111111",
        AUTOMAP_PARALLEL_POOL_CAPACITY=2)
    calls = []
    def factory(*, req, decision, store, deadline):
        assert set(store.discovered) == set(store.targets)
        assert deadline > time.monotonic()
        bundle = runtime(store)
        calls.append((store, bundle, deadline))
        return bundle
    builder._build_auto_map_parallel_runtime = factory
    return builder, calls


def invoke(builder, value=None):
    return invoke_batch(builder, STTMBuilderEnvelopeRequest.model_validate(value or request_payload()), SimpleNamespace())


def prepared_projection(value=None):
    value = value or request_payload()
    value["context"]["learning_context"] = focused_learning(value["context"].get("learning_context") or {})
    store = AutoMapContext(value)
    store.manifest()
    store.discover_batch(lambda targets: {target: {"diagnostics": {"status": "no_match"}} for target in targets})
    bundle = runtime(store)
    prepared = prepare_parallel(store, scope=bundle.scope, backend=bundle.backend, admission=bundle.admission,
        archive=bundle.archive, limits=bundle.limits, deadline=time.monotonic() + 30)
    return store, prepared, ParallelRegistryProjection(store, prepared)


def test_flag_defaults_off_and_invalid_initial_configuration_fails_closed():
    assert Settings(_env_file=None).automap_parallel_context_v1 is False
    with pytest.raises(ValueError, match="AUTOMAP_CONTEXT_RETRIEVAL_V1"):
        Settings(_env_file=None, AUTOMAP_PARALLEL_CONTEXT_V1=True)
    with pytest.raises(ValueError, match="AUTOMAP_PARALLEL_TEST_AGENT"):
        Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTOMAP_PARALLEL_CONTEXT_V1=True)
    with pytest.raises(ValueError, match="AUTOMAP_PARALLEL_PERMIT_TABLE_FQN"):
        Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTOMAP_PARALLEL_CONTEXT_V1=True,
                 AUTOMAP_PARALLEL_TEST_AGENT="D.S.SCAN_AGENT")


def test_enabled_without_service_factory_raises_before_discovery_or_model():
    builder, _ = enabled_service()
    builder._build_auto_map_parallel_runtime = None
    builder._discover_auto_map_batch_evidence = lambda *args: pytest.fail("Discovery before configuration check")
    with pytest.raises(ValueError, match="_build_auto_map_parallel_runtime"):
        invoke(builder)
    assert not builder._agent.calls


def test_real_parallel_batch_maps_with_huge_table_excluded_and_typed_warnings():
    builder, calls = enabled_service()
    raw, thread, metadata = invoke(builder, request_payload(huge=True))
    result = json.loads(raw)
    mapping = result["data"]["result"]["mappings"]["NAME0"]
    assert mapping["source_attributes"] == ["a.X47"], mapping
    assert thread and len(builder._agent.calls) == 1
    store, bundle, deadline = calls[0]
    assert len(calls) == 1 and bundle.backend.requests
    assert all(request.deadline == deadline for request in bundle.backend.requests)
    assert len(store.inventory["D.S.HUGE"]) == 800
    packet = expand_packet(json.loads(builder._agent.calls[0][0][0]["content"][0]["text"]))
    registry = packet["context"]["auto_map_retrieval"]["relation_registry"]
    assert registry["D.S.HUGE"]["columns"] == {}
    assert registry["D.S.HUGE"]["omitted_column_count"] == 800
    assert "UNSELECTED_0000" not in json.dumps(packet)
    assert "Never use CONTACT_NAME" in json.dumps(packet)
    assert "a.X47 IS NOT NULL" in json.dumps(packet)
    assert any(item["request"].get("operation") == "column" and item["request"].get("relation") == "a"
               for item in packet["retrieved_auto_map_context"])
    warnings = [ApiWarning.model_validate(warning) for warning in result["warnings"]]
    assert {warning.code for warning in warnings} >= {"scan_incomplete", "non_exhaustive_summary"}
    assert metadata["warnings"] == result["warnings"]
    parallel = metadata["auto_map_retrieval"]["parallel_preparation"]
    assert parallel["coverage"]["excluded_group_count"] == 1
    assert parallel["assistant_context"]["warnings"] == result["warnings"]
    assert builder._parse_envelope(raw)[3]  # Existing parser can carry the envelope warnings.


def test_projection_is_serialization_only_and_preserves_support_columns():
    value = request_payload(huge=True)
    source = value["context"]["relation_graph"]["nodes"][0]
    source["output_columns"].append({"name": "JOIN_KEY", "data_type": "TEXT"})
    value["context"]["semantic_context"][0]["semantic_model"]["attributes"].append({"name": "JOIN_KEY", "business_meaning": "Grain key"})
    value["context"]["workspace_context"]["filters"]["filter_sql"] = "a.JOIN_KEY IS NOT NULL"
    store, prepared, projection = prepared_projection(value)
    before = deepcopy(vars(store))
    result = expand_packet(batch_packet(store, [], registry_projection=projection))
    assert set(result["context"]["auto_map_retrieval"]["relation_registry"]["D.S.A"]["columns"]) == {"X47", "JOIN_KEY"}
    assert vars(store) == before
    assert store._value({"operation": "column", "relation": "huge", "column": "UNSELECTED_0000"})[1]
    assert prepared.store is store


@pytest.mark.parametrize("change", ["alias", "column", "evidence", "discovery", "scope", "generation"])
def test_projection_revalidates_bindings_and_generation_on_every_packet(change):
    store, prepared, projection = prepared_projection()
    if change == "alias":
        store.original["context"]["relation_graph"]["nodes"][0]["alias"] = "forged"
    elif change == "column":
        del store.inventory["D.S.A"]["X47"]
    elif change == "evidence":
        store.evidence["NAME0"]["new"] = [{"rule": "changed"}]
    elif change == "discovery":
        store.discovered["NAME0"]["diagnostics"] = {"status": "changed"}
    elif change == "scope":
        projection.preparation = replace(prepared, scope=SnapshotScope("foreign", store.snapshot_hash))
    else:
        manifest = prepared.candidate_manifest
        manifest["generation"] = "f" * 64
        projection.preparation = replace(prepared, _manifest_json=json.dumps(manifest))
    with pytest.raises(ValueError):
        batch_packet(store, [], registry_projection=projection)


def test_search_more_never_resets_preparation_call_budget_and_returns_unresolved_scope():
    class SearchAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            self.calls.append((deepcopy(messages), kwargs))
            packet = expand_packet(json.loads(messages[0]["content"][0]["text"]))
            return json.dumps({"meta": {"delegation": {"tool": "SearchMappingEvidence",
                "snapshot_hash": packet["context"]["auto_map_retrieval"]["snapshot_hash"],
                "operation": "search_more", "targets": ["NAME0"], "reason": "missing_rule"}}}), "thread", {}
    builder, calls = enabled_service(SearchAgent())
    discoveries = []
    def discover(req, targets, **kwargs):
        discoveries.append(kwargs)
        return {target: {"diagnostics": {"status": "no_match"}} for target in targets}
    builder._discover_auto_map_batch_evidence = discover
    raw, _, metadata = invoke(builder)
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["transformation_classification"] == "unresolved"
    assert "frozen" in mapping["unmatched_reason"]
    assert len(calls) == 1 and discoveries == [{}]
    assert metadata["auto_map_retrieval"]["additional_search_rounds"] == 0
    assert "parallel_search_more_blocked" in {warning["code"] for warning in metadata["warnings"]}


def test_search_more_preserves_completed_mapping_and_marks_pending_target_unresolved():
    class SearchAfterMappingAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            if not self.calls:
                raw, thread, metadata = super().run_detailed(messages, **kwargs)
                envelope = json.loads(raw)
                envelope["data"]["result"]["mappings"].pop("NAME1")
                self.first_raw = json.dumps(envelope)
                self.preparation_requests = list(calls[0][1].backend.requests)
                return self.first_raw, thread, metadata
            assert len(self.calls) == 1, "Frozen search_more must not dispatch another model call"
            self.calls.append((deepcopy(messages), kwargs))
            packet = expand_packet(json.loads(messages[0]["content"][0]["text"]))
            assert set(packet["batch_evidence_deficits"]) == {"NAME1"}
            return json.dumps({"meta": {"delegation": {"tool": "SearchMappingEvidence",
                "snapshot_hash": packet["context"]["auto_map_retrieval"]["snapshot_hash"],
                "operation": "search_more", "targets": ["NAME0", "NAME1"],
                "reason": "missing_rule"}}}), "thread", {}

    agent = SearchAfterMappingAgent()
    builder, calls = enabled_service(agent)
    discoveries = []
    def discover(req, targets, **kwargs):
        discoveries.append(kwargs)
        return {target: {"diagnostics": {"status": "no_match"}} for target in targets}
    builder._discover_auto_map_batch_evidence = discover
    raw, _, metadata = invoke(builder, request_payload(target_count=2))
    envelope = json.loads(raw)
    mappings = envelope["data"]["result"]["mappings"]
    expected = builder._parse_envelope(agent.first_raw)[1].mappings["NAME0"].model_dump(mode="json")
    assert mappings["NAME0"] == expected
    assert mappings["NAME0"]["source_attributes"] == ["a.X47"]
    assert mappings["NAME0"]["transformation_classification"] != "unresolved"
    assert mappings["NAME1"]["source_attributes"] == []
    assert mappings["NAME1"]["transformation_classification"] == "unresolved"
    assert "frozen" in mappings["NAME1"]["unmatched_reason"]
    warning = next(warning for warning in envelope["warnings"]
                   if warning["code"] == "parallel_search_more_blocked")
    assert mappings["NAME1"]["unmatched_reason"] == warning["message"]
    assert warning in metadata["warnings"]
    assert len(calls) == 1 and discoveries == [{}]
    assert calls[0][1].backend.requests == agent.preparation_requests
    assert len(agent.calls) == metadata["auto_map_retrieval"]["model_call_count"] == 2
    assert metadata["auto_map_retrieval"]["additional_search_rounds"] == 0
    assert metadata["parallel_preparation"]["assistant_context"]["non_exhaustive"] is True
    assert {audit["target"]: audit["status"] for audit in metadata["auto_map_retrieval"]["targets"]} == {
        "NAME0": "grounded", "NAME1": "unresolved"}


@pytest.mark.parametrize("failure", ["wrong_bundle", "factory_error", "global_blocked"])
def test_runtime_failure_is_explicit_and_never_uses_legacy_mapping(failure):
    builder, _ = enabled_service()
    original = builder._build_auto_map_parallel_runtime
    def factory(**kwargs):
        if failure == "wrong_bundle":
            return {}
        if failure == "factory_error":
            raise RuntimeError("private credential details")
        bundle = original(**kwargs)
        return replace(bundle, limits=replace(bundle.limits, scan_budget=MessageBudget(2000, 2000)))
    builder._build_auto_map_parallel_runtime = factory
    raw, _, metadata = invoke(builder)
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"
    assert not builder._agent.calls
    assert metadata["warnings"] and "private credential details" not in json.dumps(metadata)


def test_mandatory_driver_contract_cannot_be_skipped_when_huge():
    value = request_payload()
    value["context"]["semantic_context"][0]["semantic_model"]["business_rules"] = ["Preserve mandatory population " * 10000]
    builder, _ = enabled_service()
    raw, _, metadata = invoke(builder, value)
    assert not builder._agent.calls
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"
    assert metadata["warnings"]


def test_agent_warnings_merge_with_preparation_in_metadata_and_envelope():
    class WarningAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            raw, thread, meta = super().run_detailed(messages, **kwargs)
            envelope = json.loads(raw)
            envelope["warnings"] = [{"code": "agent_warning", "message": "Review source"}]
            meta["warnings"] = [{"code": "transport_warning", "message": "Transport review"}]
            return json.dumps(envelope), thread, meta
    builder, _ = enabled_service(WarningAgent())
    raw, _, metadata = invoke(builder)
    assert {warning["code"] for warning in json.loads(raw)["warnings"]} >= {
        "agent_warning", "transport_warning", "non_exhaustive_summary"}
    assert metadata["auto_map_retrieval"]["warnings"] == metadata["warnings"]


def test_selected_source_hydrated_before_first_mapping_without_structural_read():
    value = request_payload()
    value["context"]["workspace_context"]["filters"] = {}
    builder, _ = enabled_service()
    raw, _, metadata = invoke(builder, value)
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]
    assert len(builder._agent.calls) == 1
    packet = expand_packet(json.loads(builder._agent.calls[0][0][0]["content"][0]["text"]))
    assert any(item["request"] == {"operation": "column", "relation": "a", "column": '"X47"'}
               and item["result"]["complete"] for item in packet["retrieved_auto_map_context"])
    assert metadata["auto_map_retrieval"]["model_call_count"] == 1


def test_failed_exact_hydration_never_dispatches_final_mapping(monkeypatch):
    original = AutoMapContext.read_many
    def fail_column(self, request, **kwargs):
        result = original(self, request, **kwargs)
        for item in result["results"]:
            if item["request"].get("relation") == "a":
                item["result"] = {"error": "unavailable"}
        return result
    monkeypatch.setattr(AutoMapContext, "read_many", fail_column)
    builder, _ = enabled_service()
    raw, _, metadata = invoke(builder)
    assert not builder._agent.calls
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"
    assert "parallel_stage_failed" in {warning["code"] for warning in metadata["warnings"]}


def test_invoke_with_no_model_call_returns_partial_response_not_http_500(monkeypatch):
    import app.core.sttm_builder as module
    original = AutoMapContext.read_many
    def fail_column(self, request, **kwargs):
        result = original(self, request, **kwargs)
        for item in result["results"]:
            if item["request"].get("relation") == "a":
                item["result"] = {"error": "unavailable"}
        return result
    monkeypatch.setattr(AutoMapContext, "read_many", fail_column)
    monkeypatch.setattr(module, "attach_agent_execution_context", lambda req, memory: req)
    builder, _ = enabled_service()
    builder._conversation_memory = None
    builder._with_intent_route = lambda req: req
    builder._sanitize_request_semantic_context = lambda req: req
    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._govern_request_for_model = lambda req, decision: req
    builder._should_use_analyst = lambda *args: False
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    builder._persist_response_artifact = lambda req, response: None
    response = builder.invoke(STTMBuilderEnvelopeRequest.model_validate(request_payload()),
                              governance_decision=SimpleNamespace())
    assert response.thread_id is None
    assert response.data.status == STTMStatus.NEEDS_INPUT
    assert response.meta["auto_map_retrieval"]["model_call_count"] == 0
    assert "parallel_stage_failed" in {warning.code for warning in response.warnings}
    assert not builder._agent.calls


def test_canceled_preparation_does_not_dispatch_final_mapping():
    from threading import Event
    builder, _ = enabled_service()
    factory = builder._build_auto_map_parallel_runtime
    def canceled(**kwargs):
        stop = Event()
        stop.set()
        return replace(factory(**kwargs), cancellation=stop)
    builder._build_auto_map_parallel_runtime = canceled
    raw, _, metadata = invoke(builder)
    assert not builder._agent.calls
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"
    assert "canceled" in {warning["code"] for warning in metadata["warnings"]}


def test_existing_service_response_wrapper_preserves_warning_metadata(monkeypatch):
    import app.core.sttm_builder as module
    builder, _ = enabled_service()
    monkeypatch.setattr(module, "attach_agent_execution_context", lambda req, memory: req)
    builder._conversation_memory = None
    builder._with_intent_route = lambda req: req
    builder._sanitize_request_semantic_context = lambda req: req
    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._govern_request_for_model = lambda req, decision: req
    builder._should_use_analyst = lambda *args: False
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    saved = []
    builder._persist_response_artifact = lambda req, response: saved.append(response)
    response = builder.invoke(STTMBuilderEnvelopeRequest.model_validate(request_payload(huge=True)),
                              governance_decision=SimpleNamespace())
    metadata = response.model_dump(mode="json")["meta"]["auto_map_retrieval"]
    assert "scan_incomplete" in {warning["code"] for warning in metadata["warnings"]}
    assert metadata["parallel_preparation"]["assistant_context"]["warnings"] == metadata["warnings"]
    assert "scan_incomplete" in {warning.code for warning in response.warnings}
    assert all(isinstance(warning, ApiWarning) for warning in response.warnings)
    assert response.meta["assistant_context"]["warnings"] == [warning.model_dump(mode="json") for warning in response.warnings]
    assert saved == [response]


@pytest.mark.parametrize("budget", ["operations", "message"])
@pytest.mark.parametrize("recover", [False, True])
def test_optional_excluded_read_rolls_back_without_losing_valid_mapping(budget, recover):
    class OptionalReadAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            if len(self.calls) == 1:
                self.calls.append((deepcopy(messages), kwargs))
                packet = expand_packet(json.loads(messages[0]["content"][0]["text"]))
                return json.dumps({"meta": {"delegation": {"tool": "AUTO_MAP_CONTEXT",
                    "snapshot_hash": packet["context"]["auto_map_retrieval"]["snapshot_hash"],
                    "operation": "multi_read", "reads": [{"operation": "columns", "relation": "huge"}]}}}), "thread", {}
            raw, thread, metadata = super().run_detailed(messages, **kwargs)
            if len(self.calls) == 1:
                envelope = json.loads(raw)
                envelope["data"]["result"]["mappings"].pop("NAME1")
                raw = json.dumps(envelope)
            return raw, thread, metadata

    builder, calls = enabled_service(OptionalReadAgent())
    builder._settings.automap_context_max_rounds = 3 if recover else 2
    builder._settings.automap_context_max_operations = 16 if budget == "operations" else 256
    value = request_payload(huge=True, target_count=2)
    # Unique text prevents lossless dictionary factoring from hiding packet overflow.
    for index, column in enumerate(value["context"]["semantic_context"][-1]["semantic_model"]["attributes"]):
        column["business_meaning"] = " ".join(f"meaning_{index}_{part}" for part in range(30))
    raw, _, metadata = invoke(builder, value)
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert mappings["NAME0"]["source_attributes"] == ["a.X47"]
    if recover:
        assert mappings["NAME1"]["source_attributes"] == ["a.X47"]
        packet = expand_packet(json.loads(builder._agent.calls[-1][0][0]["content"][0]["text"]))
        assert "optional exact reads" in packet["batch_evidence_deficits"]["NAME1"][0]
        assert all(item["request"].get("relation") != "huge" for item in packet["retrieved_auto_map_context"])
        assert "a.X47 IS NOT NULL" in json.dumps(packet)
        assert "Never use CONTACT_NAME" in json.dumps(packet)
    else:
        assert mappings["NAME1"]["transformation_classification"] == "unresolved"
        assert "Insufficient evidence" in mappings["NAME1"]["unmatched_reason"]
        assert "non-exhaustive" in mappings["NAME1"]["unmatched_reason"]
    assert len(builder._agent.calls) == (3 if recover else 2)
    assert "parallel_optional_read_budget_exceeded" in {warning["code"] for warning in metadata["warnings"]}
    assert "parallel_preparation_failed" not in {warning["code"] for warning in metadata["warnings"]}
    store = calls[0][0]
    assert ("columns", "huge") not in store.reads
    assert not store.cursors  # Optional paging/completion markers were rolled back too.
    events = metadata["auto_map_retrieval"]["read_events"]
    optional_events = [event for event in events if event.get("relation") == "huge"]
    assert optional_events
    assert bool(optional_events[-1]["page"] + 1 == optional_events[-1]["page_count"]) == (budget == "message")
    if budget == "operations":
        assert metadata["auto_map_retrieval"]["operation_count"] == 16
    assert metadata["auto_map_retrieval"]["parallel_preparation"]["coverage"]["exhaustive"] is False


@pytest.mark.parametrize("parallel", [False, True])
@pytest.mark.parametrize("no_match_reason", [
    "No source exists anywhere in the source schema",
    "All source tables were checked and none can provide this field",
    "Source metadata was unavailable",
])
def test_non_exhaustive_unresolved_reason_never_asserts_global_absence(parallel, no_match_reason):
    class UnresolvedAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            self.calls.append((deepcopy(messages), kwargs))
            return json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
                "NAME0": {"source_attributes": [], "confidence_score": 0,
                    "transformation_classification": "unresolved", "unmatched_reason": no_match_reason}
            }}}}), "thread", {}
    builder = enabled_service(UnresolvedAgent())[0] if parallel else service(UnresolvedAgent())
    raw, _, metadata = invoke(builder, request_payload(huge=parallel))
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["transformation_classification"] == "unresolved"
    if parallel:
        assert mapping["unmatched_reason"] == (
            "Insufficient evidence: parallel coverage is non-exhaustive; "
            "no grounded mapping was established for this target. "
            "Unread or omitted sources may contain a match.")
        assert metadata["parallel_preparation"]["coverage"]["excluded_group_count"] == 1
    else:
        assert mapping["unmatched_reason"] == no_match_reason
        assert "parallel_preparation" not in metadata


def test_required_global_constraint_on_excluded_table_still_blocks():
    value = request_payload(huge=True)
    value["context"]["workspace_context"]["filters"]["filter_sql"] = "huge.UNSELECTED_0000 IS NOT NULL"
    value["context"]["semantic_context"][-1]["semantic_model"]["attributes"][0]["business_meaning"] = (
        "Required population constraint " * 10000)
    builder, _ = enabled_service()
    raw, _, metadata = invoke(builder, value)
    assert not builder._agent.calls
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"
    assert "parallel_message_budget_exceeded" in {warning["code"] for warning in metadata["warnings"]}
    assert "parallel_optional_read_budget_exceeded" not in {warning["code"] for warning in metadata["warnings"]}


def test_flag_off_does_not_touch_runtime_and_retains_old_route():
    builder = service(ScriptedAgent())
    builder._build_auto_map_parallel_runtime = lambda **kwargs: pytest.fail("Flag-off factory called")
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    raw, _, metadata = invoke(builder, value)
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]
    assert len(builder._agent.calls) == 2
    assert "warnings" not in json.loads(raw) and "parallel_preparation" not in metadata["auto_map_retrieval"]
    packet = expand_packet(json.loads(builder._agent.calls[0][0][0]["content"][0]["text"]))
    assert "parallel_preparation" not in packet["context"]["auto_map_retrieval"]
