"""One bounded model conversation per worker batch, with vectorized exact reads."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, fields
import json
import logging
import re
import time
from threading import Event
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.core.automap_admission import ScanCallAdmission
    from app.core.automap_parallel import ParallelLimits
    from app.core.automap_reduce import ReductionArchive
    from app.core.automap_scan import ScanBackend
    from app.core.automap_shards import SnapshotScope

from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.assistant_retrieval import budget_messages
from app.core.automap_retrieval import AutoMapContext, STRATEGY_VERSION, batch_messages, batch_packet, encoded, target_name
from app.schema.sttm_builder import AttributeMapping, SourceMappingResult, STTMAgentRequestEnvelope, STTMStatus
from app.schema.contracts import ApiWarning

logger = logging.getLogger(__name__)


class BatchPayload(dict):
    """JSON payload with an in-process execution handoff that never serializes."""

    execution = None


@dataclass(frozen=True)
class ParallelRuntimeBundle:
    """Trusted service-only factory result; never construct from request/model data.

    The factory must supply authenticated scope, a raw single-attempt thread-safe
    backend, its ScanCallAdmission, a durable scoped archive and explicit limits.
    prepare_parallel pairs backend/admission for scan AND reduction.
    """

    scope: SnapshotScope
    backend: ScanBackend
    admission: ScanCallAdmission
    archive: ReductionArchive
    limits: ParallelLimits
    cancellation: Event | None = None


from app.core.automap_exact_reads import ExactReadBudgetError as _BatchReadBudgetError


def _batch_response_warnings(service, *groups):
    """Project ancillary warnings as bounded literal text, never mapping evidence."""
    normalized = []
    invalid = False
    for group in groups:
        if group is None:
            continue
        for warning in group if isinstance(group, (list, tuple)) else [group]:
            if isinstance(warning, ApiWarning):
                warning = warning.model_dump(mode="json")
            if isinstance(warning, str):
                code, message, field = "agent_warning", warning, None
            elif isinstance(warning, dict):
                code = warning.get("code") or "agent_warning"
                message = warning.get("message") or warning.get("detail")
                field = warning.get("field")
                if field is not None and not isinstance(field, str):
                    invalid, field = True, None
            else:
                invalid = True
                continue
            if not isinstance(code, str) or not isinstance(message, str):
                invalid = True
                continue
            if message:
                # Typed input keeps the shared normalizer from stripping literals
                # or stringifying unsupported objects. The backend archive is unchanged.
                normalized.append(ApiWarning(code=code[:128], message=message[:2000],
                                             field=field[:256] if field is not None else None))
    if invalid:
        normalized.append(ApiWarning(code="agent_warning_invalid",
            message="Unsupported agent warning metadata was ignored; mapping validation was unchanged."))
    return service._auto_map_response_warnings(normalized)


FAST_INTEGRATION_VERSION = "authored-proxy-fast-v3-draft-caps"


class _FastInvariantError(ValueError):
    """Fixed diagnostic code; exception details never enter model context."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _fast_failure_diagnostics(runtime, call_index):
    """Copy only native failed-call diagnostics, never exception/test attributes."""
    from app.core.automap_fast_transport import FastModelRuntime
    from app.core.automap_scan import ScanTransportReason
    from app.core.automap_scan_transport import (
        DiagnosticBlockType, DiagnosticContentKind, DiagnosticEncoding, DiagnosticMedia,
        DiagnosticOperation, DiagnosticPhase, DiagnosticReason, DiagnosticStatus,
        ScanTransportDiagnostic, TerminalResponseReason,
    )
    from app.core.automap_shards import SnapshotScope

    # Mock(spec=FastModelRuntime) can pass isinstance; an overridden property is
    # not the native defensive-copy getter either.
    if not issubclass(type(runtime), FastModelRuntime):
        return None

    def enum_value(value, *kinds):
        for kind in kinds:
            if type(value) is kind:
                return value
            if type(value) is str:
                for member in kind:
                    if value == member.value:
                        return member
        raise ValueError("Invalid diagnostic enum")

    def hash_value(value, length=64):
        if type(value) is not str or re.fullmatch(r"[0-9a-f]{%d}" % length, value) is None:
            raise ValueError("Invalid diagnostic hash")
        return value

    try:
        metadata = FastModelRuntime.failure_diagnostics.fget(runtime)
        from app.core.automap_fast_transport import MAX_RUNTIME_CALLS, RuntimeFailureKind
        from app.core.automap_scan import RuntimePhase, ScanStopReason
        if (type(metadata) is not dict or type(metadata.get("call_index")) is not int
                or metadata["call_index"] != call_index or not 1 <= call_index <= MAX_RUNTIME_CALLS):
            return None
        safe = {"call_index": call_index, "job_id": hash_value(metadata["job_id"], 32)}
        for key in ("generation", "shard_id", "request_digest", "snapshot_archive_ref", "request_archive_ref"):
            safe[key] = hash_value(metadata[key])
        for key,expected in (('generation_policy','draft-v3'),('rules_policy','rules-v2')):
            if metadata.get(key) == expected:safe[key]=expected
        outcome = metadata.get('control_outcome')
        if outcome in {'rolled_back', 'commit_uncertain', 'rollback_uncertain', 'unavailable'}:
            safe['control_outcome'] = outcome
        if metadata.get('pre_submission_failure') is True:
            safe['pre_submission_failure'] = True
        if type(metadata.get('sql_failure')) is dict:
            from app.core.sql_failure import sql_failure_details
            safe['sql_failure'] = sql_failure_details(type('Diagnostic', (), {'sql_failure': metadata['sql_failure']})())
        if metadata.get('failure_operation') in {'thread_reconciliation', 'request_record', 'dispatch_preparation'}:
            safe['failure_operation'] = metadata['failure_operation']
        retries = metadata.get('control_retries')
        if type(retries) is dict:
            safe['control_retries'] = {key: value for key, value in retries.items()
                if key in {'dispatch_preparation', 'permit_renewal', 'operation_claim'} and type(value) is int and 0 <= value <= 3}
        timestamps = metadata.get('phase_started_at')
        if type(timestamps) is dict:
            import math
            safe['phase_started_at'] = {key: value for key, value in timestamps.items()
                if key in {phase.value for phase in RuntimePhase} and type(value) in (int,float) and math.isfinite(value) and 0 <= value <= 4102444800}
        safe["failure_code"] = enum_value(metadata["failure_code"], ScanTransportReason, DiagnosticReason).value
        for key, kind in (("runtime_phase", RuntimePhase), ("stop_reason", ScanStopReason), ("failure_kind", RuntimeFailureKind)):
            if key in metadata:
                safe[key] = enum_value(metadata[key], kind).value
        if "cleanup_failure_code" in metadata:
            cleanup = metadata["cleanup_failure_code"]
            if type(cleanup) is not str or cleanup not in {"admission_unavailable", "admission_claim_uncertain", "admission_contended", "admission_invariant", "admission_cleanup_failed"}:
                return None
            safe["cleanup_failure_code"] = cleanup
        for key in ("runtime_attempts", "thread_post_attempts", "model_post_attempts", "terminal_responses", "archived_responses"):
            if key in metadata:
                value = metadata[key]
                if type(value) is not int or value not in (0, 1):
                    return None
                safe[key] = value
        import math
        def duration(value):
            if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 86400:
                raise ValueError("Invalid runtime duration")
            return value
        if "runtime_seconds" in metadata:
            safe["runtime_seconds"] = duration(metadata["runtime_seconds"])
        for key in ("admission_claim_attempts", "admission_contention_count"):
            if key in metadata:
                value = metadata[key]
                if type(value) is not int or not 0 <= value <= 10000: return None
                safe[key] = value
        if type(metadata.get("admission_backoff_seconds")) is dict:
            safe["admission_backoff_seconds"] = {key: duration(value) for key,value in metadata["admission_backoff_seconds"].items()
                if key in {"database_contention", "claim_unavailable"}}
        if "control_session_wait_seconds" in metadata:
            safe["control_session_wait_seconds"] = duration(metadata["control_session_wait_seconds"])
        if "phase_seconds" in metadata:
            phases = metadata["phase_seconds"]
            if type(phases) is not dict or len(phases) > len(RuntimePhase):
                return None
            safe["phase_seconds"] = {enum_value(key, RuntimePhase).value: duration(value) for key, value in phases.items()}
        status = metadata["failure_archive_status"]
        if type(status) is not str or status not in ("acknowledged", "unavailable"):
            return None
        safe["failure_archive_status"] = status
        if status == "acknowledged":
            safe["failure_archive_ref"] = hash_value(metadata["failure_archive_ref"])
        transport = metadata["transport"]
        if type(transport) is not list or len(transport) > 6:
            return None
        safe["transport"] = []
        enum_fields = {"phase": (DiagnosticPhase,), "operation": (DiagnosticOperation,),
            "encoding": (DiagnosticEncoding,), "media": (DiagnosticMedia,), "status": (DiagnosticStatus,),
            "reason": (ScanTransportReason, DiagnosticReason), "response_reason": (TerminalResponseReason,),
            "content_kind": (DiagnosticContentKind,)}
        for event in transport:
            if type(event) is not dict or type(event.get("scope")) is not dict:
                return None
            projected = {field.name: event[field.name] for field in fields(ScanTransportDiagnostic) if field.name in event}
            projected["scope"] = SnapshotScope(event["scope"]["owner_id"], hash_value(event["scope"]["snapshot_id"]))
            if (projected["scope"].snapshot_id != safe["generation"]
                    or event["generation"] != safe["generation"] or event["shard_id"] != safe["shard_id"]):
                return None
            for key, kinds in enum_fields.items():
                value = projected.get(key)
                if value is not None or key not in ("reason", "response_reason"):
                    projected[key] = enum_value(value, *kinds)
            block_types = projected.get("block_types")
            if type(block_types) not in (list, tuple) or len(block_types) > len(DiagnosticBlockType):
                return None
            projected["block_types"] = tuple(enum_value(value, DiagnosticBlockType) for value in block_types)
            # Reuse the transport's exact integer, ID and shape validation.
            safe_event = asdict(ScanTransportDiagnostic(**projected))
            for key in enum_fields:
                if safe_event[key] is not None:
                    safe_event[key] = safe_event[key].value
            safe_event["block_types"] = [value.value for value in safe_event["block_types"]]
            safe["transport"].append(safe_event)
        return safe
    except Exception:
        # Metadata must not mask or reclassify a transport/COMMIT failure.
        return None


class _FastAutoMapContext(AutoMapContext):
    """Replay frozen parent evidence without charging its I/O to each worker."""

    def replay_parent_discovery(self, handoff):
        discovery = handoff.get("discovery")
        parent_targets = {target_name(name) for name in handoff["target_requirements"]}
        if (not isinstance(discovery, dict) or set(discovery) != parent_targets
                or not set(self.targets) <= parent_targets):
            raise _FastInvariantError("discovery_target_scope", "Frozen discovery does not cover its parent targets")
        if any(not isinstance(result, dict) or not isinstance(result.get("diagnostics", {}), dict)
               for result in discovery.values()):
            raise _FastInvariantError("discovery_shape", "Frozen discovery has an invalid result shape")

        def replay(targets):
            from app.core.automap_policy import retrieval_diagnostic_summary
            results = {target: deepcopy(discovery[target]) for target in targets}
            for result in results.values():
                # Physical counters and hydrated-but-inapplicable IDs are audit
                # metadata, not evidence. Repeating them makes an unpaged exact
                # discovery receipt overflow even when no pattern is applicable.
                result["diagnostics"] = retrieval_diagnostic_summary(result.get("diagnostics"))
            return results

        self._parent_discovery_scope = (discovery, len(parent_targets))
        try:
            self.discover_batch(replay)
        finally:
            self._parent_discovery_scope = None

    def _record_search_work(self, discovered, target_count):
        parent_scope = getattr(self, "_parent_discovery_scope", None)
        if parent_scope is None:
            return super()._record_search_work(discovered, target_count)
        # Keep the original bounded contract, but use the authenticated frozen
        # parent scope that actually incurred the Search/hydration work.
        worker_work = self.search_work.copy()
        try:
            super()._record_search_work(*parent_scope)
            self.parent_discovery = {"target_count": parent_scope[1],
                "search_work": {key: value - worker_work[key] for key, value in self.search_work.items()}}
        except (ValueError, TypeError, OverflowError) as exc:
            raise _FastInvariantError("parent_discovery_work_budget", "Frozen parent discovery exceeds its work contract") from exc
        finally:
            self.search_work = worker_work


def fast_project_enabled(settings, project_id):
    """One configured Auto-map engine for all projects; authorization is upstream.

    The former project rollout list is retained as a compatibility setting, not
    a selector for different mapping algorithms. The installation switch remains.
    """
    if getattr(settings, "automap_fast_path_v1", False) is not True or type(project_id) is not str:
        return False
    if re.fullmatch(r"[1-9][0-9]{0,37}", project_id):
        return True
    legacy_scopes = getattr(settings, 'automap_fast_project_ids', ())
    return isinstance(legacy_scopes, (list,tuple)) and project_id in legacy_scopes and bool(project_id.strip())


def canonical_model_wire_request(req, *, allow_sample_rows=None, wire=True):
    """Pure privacy projection and typed worker round trip, never a new proof.

    Only known sample fields in enrichment and echoed output bodies are removed.
    SQL, graph, constraints, reviews and other metadata remain exact. The caller
    retains the original request; a worker must still compare the frozen proof.
    """
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from app.guardrails.adapters.snowflake import strip_sample_data
    if allow_sample_rows is None:
        allow_sample_rows = ((req.meta.get("guardrails") or {}).get("policy") or {}).get("allow_sample_rows") is True
    payload = req.model_dump(mode="json", exclude_none=wire)
    if not allow_sample_rows:
        for key in ("semantic_context", "datahub_context", "derived_source_lineage", "execution_context"):
            if key in payload["context"]:
                payload["context"][key] = strip_sample_data(payload["context"][key])
    from app.core.agent_payload_budget import _remove_echoed_artifacts
    _remove_echoed_artifacts(payload)
    projected = STTMBuilderEnvelopeRequest.model_validate(payload)
    result = STTMBuilderEnvelopeRequest.model_validate(projected.to_worker_payload()) if wire else projected
    # Private provenance is never deserialized from a caller or a worker body.
    # Keep it only within this server-owned pure projection.
    result.context._prepared_automap = req.context._prepared_automap
    result._automap_durable_receipt = req._automap_durable_receipt
    return result


def fast_handoff_context_hash(req):
    from app.core.automap_retrieval import digest
    context = canonical_model_wire_request(req).context.model_dump(mode="json")
    context.pop("prepared_context_hash", None)  # Derived proof, not input data.
    return digest(context)


def fast_handoff_request_hash(req, discovery, target_requirements):
    from app.core.automap_retrieval import digest
    payload = canonical_model_wire_request(req).model_dump(mode="json")
    payload["context"].pop("prepared_context_hash", None)
    payload["data"].pop("attributes", None)  # Compared separately per owning batch.
    payload["meta"].pop("_automap_fast_handoff", None)
    payload["meta"].pop("_automap_frozen_packet", None)
    payload["meta"].pop("auto_mapping_batch_index", None)
    return digest({"request": payload, "discovery": discovery, "target_requirements": target_requirements})


def freeze_fast_handoff(req, *, discovery=None):
    """Capture expected proof only after all permitted model-wire transforms."""
    from app.core.automap_policy import preparation_hash
    from app.guardrails.adapters.snowflake import strip_sample_data
    projected = canonical_model_wire_request(req)
    allow_samples = ((projected.meta.get("guardrails") or {}).get("policy") or {}).get("allow_sample_rows") is True
    discovery = deepcopy(discovery) if allow_samples else strip_sample_data(discovery)
    requirements = {item.target_attribute: item.model_dump(mode="json") for item in projected.data.attributes or []}
    return {"version": FAST_INTEGRATION_VERSION, "model_wire_version": "v1",
        "context_hash": fast_handoff_context_hash(projected),
        "request_hash": fast_handoff_request_hash(projected, discovery, requirements),
        "prepared_context_hash": preparation_hash(projected.context),
        "deadline_at": projected.meta.get("auto_map_deadline_at"),
        "target_requirements": requirements,
        "discovery": discovery}


def fast_target_identity(name):
    from app.core.automap_retrieval import target_name
    name = target_name(name)
    return name[1:-1].replace('""', '"') if name.startswith('"') and name.endswith('"') else name.upper()


def validate_fast_request(req, settings):
    """Validate a prepared same-caller proxy packet, not caller-selected resources.

    The JSON hash is an integrity check, not authentication. HTTP caller validation
    and the runtime's independently authenticated caller remain mandatory.
    """
    from app.core.automap_policy import preparation_hash
    req = canonical_model_wire_request(req)

    def require(condition, code, message="Fast Auto-map requires the frozen prepared proxy handoff"):
        if not condition:
            logger.error("Auto-map fast validation rejected request_id=%s batch_index=%s invariant=%s",
                         req.request_id, req.meta.get("auto_mapping_batch_index"), code)
            raise _FastInvariantError(code, message)

    require(fast_project_enabled(settings, req.context.project_id), "project_disabled",
            "Fast Auto-map is not enabled for this project")
    handoff = req.meta.get("_automap_fast_handoff")
    require(req.meta.get("auto_map_parent_resolution_version") == FAST_INTEGRATION_VERSION, "parent_version")
    require(req.meta.get("auto_map_prepared_readonly") is True, "prepared_readonly")
    require(isinstance(handoff, dict), "handoff_missing")
    require(handoff.get("version") == FAST_INTEGRATION_VERSION, "handoff_version")
    require(handoff.get("model_wire_version") == "v1", "model_wire_version")
    require(bool(req.context.prepared_context_hash), "prepared_hash_missing")
    require(req.context.execution_context is not None, "execution_context_missing")
    require(req.context.prepared_context_hash == preparation_hash(req.context), "prepared_hash_mismatch")
    require(handoff.get("prepared_context_hash") == req.context.prepared_context_hash, "handoff_prepared_hash_mismatch")
    require(handoff.get("context_hash") == fast_handoff_context_hash(req), "context_hash_mismatch")
    require(handoff.get("request_hash") == fast_handoff_request_hash(req, handoff.get("discovery"), handoff.get("target_requirements")),
            "request_hash_mismatch")
    requirements = handoff.get("target_requirements")
    require(isinstance(requirements, dict) and not any(
            encoded(requirements.get(item.target_attribute)) != encoded(item.model_dump(mode="json"))
            for item in req.data.attributes or []), "target_requirements_mismatch",
            "Fast target requirements differ from the frozen handoff")
    from datetime import datetime
    try:
        deadline_matches = (handoff.get("deadline_at") == req.meta.get("auto_map_deadline_at")
            and type(req.meta.get("_automap_deadline")) in (int, float)
            and abs(datetime.fromisoformat(str(handoff.get("deadline_at")).replace("Z", "+00:00")).timestamp()
                    - req.meta["_automap_deadline"]) <= 0.000001)
    except (ValueError, TypeError, OverflowError):
        deadline_matches = False
    require(deadline_matches, "deadline_mismatch", "Fast deadline differs from the frozen handoff")
    names = [fast_target_identity(item.target_attribute) for item in req.data.attributes or []]
    require(names and len(names) == len(set(names)) and len({item.target_table.qualified_name for item in req.data.attributes}) == 1,
            "target_scope", "Fast mapping requires unambiguous targets in one table")
    return handoff


def invoke_batch(service, req, decision=None):
    from app.core.sttm_builder import _extract_json_object

    settings = service._settings
    fast_enabled = getattr(req, "meta", {}).get("auto_map_fast_path") == "v1"
    parallel_enabled = not fast_enabled and getattr(settings, "automap_parallel_context_v1", False) is True
    runtime_factory = None
    if parallel_enabled:
        settings.validate_parallel_automap()
        runtime_factory = getattr(service, "_build_auto_map_parallel_runtime", None)
        if not callable(runtime_factory):
            raise ValueError("AUTOMAP_PARALLEL_CONTEXT_V1 requires service._build_auto_map_parallel_runtime; legacy fallback is forbidden")
    decision = decision or service._build_governance_decision(req)
    service._model_guard.assert_model_target_allowed(operation=req.operation.value, target="agent", decision=decision)
    if fast_enabled:
        req = canonical_model_wire_request(req)
    started = time.monotonic()
    from app.core.automap_policy import focused_learning, retrieval_diagnostic_summary, source_preparation_issues
    from app.core.automap_packet_policy import source_planning_input
    raw_context = source_planning_input(req)
    from app.core.automap_packet_policy import source_context
    store = source_context(req, fast=fast_enabled, raw=raw_context)
    preparation_issues = source_preparation_issues(raw_context.get("context") or {})
    model_issues = list(preparation_issues)
    eligibility_repair_attempted = False
    format_repair_attempted = False
    repair_targets = None
    pending_budget_groups = []
    budget_deferred_targets = set()
    queried_targets = set()
    budget_subdivision = False
    from app.core.automap_row_candidates import record_proposal, requested_target
    retained_proposals = {}
    last_unresolved = {}
    recovery_attempts = {}
    outcome_codes = {}
    review_only_targets = set()
    reviewed_unresolved = {}
    block_review_calls = 0
    store.manifest()
    attributes = {target_name(item.target_attribute): item for item in req.data.attributes or []}
    completed, reasons, results, events = {}, {}, [], []
    operation_count, model_calls, peak_bytes, peak_chars = 0, 0, 0, 0
    final_thread, final_payload, deficits = None, {}, {}
    preparation, projection, runtime = None, None, None
    fast_plan, fast_runtime = None, None
    fast_failure = None
    frozen_messages = None
    frozen_receipt = None
    deadline = started + settings.automap_context_target_seconds
    fast_warnings = []
    parallel_warnings = []
    agent_warnings = []
    page_bytes = min(32768, settings.agent_outbound_message_max_bytes // 4)
    timings = {"discovery": 0.0, "preparation": 0.0, "retrieval": 0.0, "model": 0.0, "validation": 0.0}

    def remaining():
        if fast_enabled:
            from app.core.automap_fast_context import FINAL_RESERVE_SECONDS
            return deadline + (getattr(fast_runtime,"admission_wait_seconds",0) if fast_runtime is not None else 0) - FINAL_RESERVE_SECONDS - time.monotonic()
        return settings.automap_context_target_seconds - (time.monotonic() - started)

    def read_operations(operations):
        nonlocal operation_count
        from app.core.automap_exact_reads import read_operations as hydrate
        retrieval_started = time.monotonic()
        counter = {"count": operation_count}
        try:
            operation_count = hydrate(store, operations, settings=settings, results=results, events=events,
                operation_count=operation_count, remaining=remaining, strict=parallel_enabled or fast_enabled, counter=counter)
        finally:
            operation_count = counter["count"]
            timings["retrieval"] += time.monotonic() - retrieval_started

    def owning_fast_runtime():
        nonlocal fast_runtime
        if fast_runtime is None:
            from app.core.automap_fast_context import FINAL_RESERVE_SECONDS
            from app.core.automap_runtime import build_fast_model_runtime
            factory = getattr(service, "_fast_model_runtime_factory", build_fast_model_runtime)
            if not callable(factory):
                raise ValueError("Fast model runtime factory is unavailable; fallback is forbidden")
            factory_options = {"finalization_deadline": deadline} if factory is build_fast_model_runtime else {}
            fast_runtime = factory(service, req, decision, store, deadline - FINAL_RESERVE_SECONDS, **factory_options)
            from app.core.automap_fast_transport import FastModelRuntime
            if not isinstance(fast_runtime, FastModelRuntime) and getattr(fast_runtime, "is_test_runtime", False) is not True:
                raise TypeError("Fast factory must return the durable adapter or an explicitly declared test runtime")
        return fast_runtime

    def bounded_messages():
        nonlocal repair_targets, budget_subdivision
        if frozen_messages is not None and model_calls == 0 and not deficits and not repair_targets:
            return deepcopy(frozen_messages)
        if fast_plan is not None:
            # The complete serialized model message is the governing budget.
            # A separate aggregate FIR ceiling can fail an otherwise small,
            # relevant target batch as the archive grows.
            from app.core.automap_fast_context import FastContextBudgetError
            while True:
                try:
                    return fast_plan.messages(results, missing=deficits, issues=model_issues, targets=repair_targets)
                except FastContextBudgetError:
                    targets = sorted(set(repair_targets or attributes) - set(completed) - budget_deferred_targets)
                    if len(targets) > 1:
                        budget_subdivision = True
                        middle = len(targets) // 2
                        pending_budget_groups.insert(0, set(targets[middle:]))
                        repair_targets = set(targets[:middle])
                        continue
                    if targets:
                        target = targets[0]
                        budget_deferred_targets.add(target)
                        reasons[target] = 'Essential current contracts cannot fit this target; supported sibling drafts are retained. Narrow its source or rule scope.'
                        outcome_codes[target] = 'required_evidence_budget_exceeded'
                    if pending_budget_groups:
                        repair_targets = pending_budget_groups.pop(0)
                        continue
                    raise
        packet = (batch_packet(store, results, missing=deficits, registry_projection=projection)
                  if projection is not None else batch_packet(store, results, missing=deficits))
        packet["source_preparation_issues"] = preparation_issues
        store.check_positive_budget(settings.automap_learning_max_chars)
        return budget_messages(batch_messages(packet), max_chars=settings.agent_outbound_message_max_chars,
                               max_bytes=settings.agent_outbound_message_max_bytes)

    def read_agent_operations(operations):
        if fast_plan is not None:
            fast_plan.validate_operations(operations)
        if projection is None and fast_plan is None:
            read_operations(operations)
            return True
        # Only agent-requested additions are transactional. Required driver,
        # constraint and candidate reads still use the fail-closed path.
        state = {key: deepcopy(getattr(store, key)) for key in (
            "reads", "cursors", "pages_read", "discovered", "evidence",
            "historical_dependencies", "historical_dependency_owners",
        )}
        result_count = len(results)
        try:
            read_operations(operations)
            bounded_messages()  # Complete bodies must fit before admitting reads.
            return True
        except (_BatchReadBudgetError, AgentPayloadBudgetError, ValueError):
            for key, value in state.items():
                setattr(store, key, value)
            del results[result_count:]
            # Attempted operations remain charged; rollback is not a budget reset.
            detail = ("Insufficient evidence: optional exact reads exceeded the batch budget; "
                      "coverage remains non-exhaustive. Use admitted evidence or return unresolved; "
                      "do not infer absence from unread sources.")
            (fast_warnings if fast_enabled else parallel_warnings).append(ApiWarning(
                code="auto_map_fast_optional_read_budget_exceeded" if fast_enabled else "parallel_optional_read_budget_exceeded", message=detail))
            for target in attributes.keys() - completed.keys():
                reasons[target] = detail
                deficits[target] = [detail]
            return False

    reason = "Batch did not return a grounded mapping"
    stage = "discovery"
    logger.info("Auto-map evidence preparation request_id=%s at=%.6f", req.request_id, time.time())
    try:
        if fast_enabled:
            from app.core.automap_fast_context import FastContextPlan, request_deadline, validate_derived_output_contracts
            handoff = validate_fast_request(req, settings)
            if getattr(settings,'automap_durable_runs_v2',False):
                # Queue time has a separate parent limit; this fresh batch owns
                # only its execution budget. Immutable handoff is still validated.
                deadline = started + settings.automap_fast_batch_seconds
            else:
                deadline = min(request_deadline(req.meta, started=started), started + getattr(settings, "automap_fast_batch_seconds", 60))
            if remaining() <= 0:
                raise _BatchReadBudgetError("Fast request deadline exhausted before discovery")
        discovery_started = time.monotonic()
        discovery = handoff.get("discovery") if fast_enabled else None
        if discovery is not None:
            store.replay_parent_discovery(handoff)
        else:
            store.discover_batch(lambda targets: service._discover_auto_map_batch_evidence(req, targets))
        timings["discovery"] = time.monotonic() - discovery_started
        if fast_enabled:
            stage = "fast_preparation"
            preparation_started = time.monotonic()
            if remaining() <= 0:
                raise _BatchReadBudgetError("Fast request deadline exhausted during discovery")
            try:
                packet = req.meta.get('_automap_frozen_packet')
                if packet is not None:
                    from app.core.automap_frozen_packet import hydrate
                    fast_plan, frozen_messages, results, events = hydrate(packet, store,
                        expected_digest=handoff.get('packet_digest'),
                        max_chars=settings.agent_outbound_message_max_chars,
                        max_bytes=settings.agent_outbound_message_max_bytes, deadline=deadline)
                    operation_count = len(events)
                    frozen_receipt = {'packet_version': packet['version'], 'packet_digest': packet['receipt_digest'],
                        'message_digest': packet['message_digest'], 'final_chars': packet['final_chars'],
                        'final_bytes': packet['final_bytes'], 'worker_verified': True}
                else:
                    validated_derived = validate_derived_output_contracts(req, getattr(service, "_session", None))
                    fast_plan = FastContextPlan(store, max_chars=settings.agent_outbound_message_max_chars,
                                               max_bytes=settings.agent_outbound_message_max_bytes,
                                               validated_derived=validated_derived, retry_outcomes=req.meta.get("auto_map_retry_outcomes"))
                fast_warnings.extend(ApiWarning.model_validate(item) for item in fast_plan.warnings)
                bounded_messages()
            finally:
                timings["preparation"] = time.monotonic() - preparation_started
        elif parallel_enabled:
            stage = "parallel_preparation"
            preparation_started = time.monotonic()
            from app.core.automap_parallel import prepare_parallel
            from app.core.automap_retrieval import ParallelRegistryProjection
            deadline = started + settings.automap_context_target_seconds
            runtime = runtime_factory(req=req, decision=decision, store=store, deadline=deadline)
            if not isinstance(runtime, ParallelRuntimeBundle):
                raise TypeError("Trusted runtime factory must return ParallelRuntimeBundle")
            preparation = prepare_parallel(store, scope=runtime.scope, backend=runtime.backend,
                admission=runtime.admission, archive=runtime.archive, limits=runtime.limits,
                deadline=deadline, cancellation=runtime.cancellation)
            parallel_warnings.extend(preparation.warnings)
            if preparation.coverage.mapping_blocked:
                raise ValueError("Mandatory parallel global context is unavailable; final mapping is blocked")
            projection = ParallelRegistryProjection(store, preparation)
            timings["preparation"] = time.monotonic() - preparation_started
        mandatory = []
        stage = "exact_evidence"
        for target in attributes:
            mandatory.extend(store.required_operations(target, {"source_attributes": []}))
        if projection is not None:
            mandatory.extend(projection.read_operations)
        if fast_plan is not None:
            from app.core.automap_exact_reads import initial_operations
            mandatory = initial_operations(store, fast_plan)
        if frozen_messages is None:
            read_operations(mandatory)
        previous_deficits = None
        from app.core.automap_fast_context import MAX_FAST_MODEL_CALLS
        from app.core.automap_fast_context import MAX_FAST_DECISION_ROUNDS
        rounds = MAX_FAST_DECISION_ROUNDS if fast_enabled else settings.automap_context_max_rounds
        for _round in range(rounds):
            if runtime is not None and runtime.cancellation is not None and runtime.cancellation.is_set():
                raise ValueError("Parallel batch canceled")
            if remaining() <= 0 or (fast_enabled and model_calls >= MAX_FAST_MODEL_CALLS):
                reason = "Batch reasoning time expired; incomplete evidence was not accepted"
                break
            messages = bounded_messages()
            if fast_enabled:
                from app.core.automap_evidence_blocks import EvidenceBlockError, MAX_EVIDENCE_REVIEW_CALLS
                block_failed = None
                block_manifest = fast_plan.evidence_read_manifest()
                if block_manifest["required_block_calls"] > MAX_EVIDENCE_REVIEW_CALLS - block_review_calls:
                    block_failed = "Mandatory exact evidence exceeds the remaining review-call budget; replan the batch. No absence was established."
                while block_failed is None and fast_plan.required_pending_blocks():
                    stage = "evidence_block_review"
                    runtime_for_blocks = owning_fast_runtime()
                    if remaining() <= 1 or block_review_calls >= MAX_EVIDENCE_REVIEW_CALLS:
                        block_failed = "Exact evidence blocks remain unread because the shared call or time budget ended. Resume or rerun with sufficient resources; no absence was established."
                        break
                    identity = fast_plan.required_pending_blocks()[0]
                    block_messages = fast_plan.blocks.request(identity)
                    if block_messages is None:
                        continue  # Finer split, not evidence loss.
                    accepted = False
                    block_error = ""
                    for block_attempt in range(2):
                        if remaining() <= 1 or block_review_calls >= MAX_EVIDENCE_REVIEW_CALLS:
                            break
                        if block_attempt:
                            # Explicit format repair after a completed response;
                            # transport failures never enter this retry path.
                            block_messages = deepcopy(block_messages)
                            block_messages[0]["content"].append({"type": "text", "text": "Format correction: " + block_error + ". Return the exact completed evidence_review response_template with valid verbatim quotes only; facts may be empty. No observations or extra fact fields."})
                        block_review_calls += 1
                        call_index = model_calls + block_review_calls
                        model_started = time.monotonic()
                        try:
                            block_raw, _, _ = runtime_for_blocks.run(block_messages, call_index=call_index, stage="evidence_review")
                        except Exception:
                            fast_failure = _fast_failure_diagnostics(runtime_for_blocks, call_index)
                            raise
                        finally:
                            timings["model"] += time.monotonic() - model_started
                        peak_bytes = max(peak_bytes, len(encoded(block_messages).encode("utf-8")))
                        peak_chars = max(peak_chars, len(encoded(block_messages)))
                        try:
                            fast_plan.blocks.accept(identity, block_raw)
                            accepted = True
                            break
                        except EvidenceBlockError as invalid_review:
                            block_error = str(invalid_review)
                    if not accepted:
                        block_failed = "An exact evidence block could not be verified after bounded response repair: " + block_error + ". Valid sibling results were retained."
                        break
                    messages = bounded_messages()
                if block_failed:
                    for target in attributes.keys() - completed.keys():
                        reasons[target] = block_failed
                        outcome_codes[target] = "evidence_block_incomplete"
                    break
                if fast_plan.blocks.active & fast_plan.blocks.reviews.keys():
                    review_only_targets.update(repair_targets or attributes)
            response_targets = repair_targets
            queried_targets.update(response_targets or attributes)
            logger.info("Auto-map evidence ready request_id=%s at=%.6f", req.request_id, time.time())
            stage = "source_mapping_agent"
            peak_bytes = max(peak_bytes, len(encoded(messages).encode("utf-8")))
            peak_chars = max(peak_chars, len(encoded(messages)))
            for parse_attempt in range(2):
                if fast_enabled:
                    if remaining() <= 0 or model_calls >= MAX_FAST_MODEL_CALLS:
                        raise _BatchReadBudgetError("Fast final-mapping call budget exhausted")
                    fast_runtime = owning_fast_runtime()
                    model_started = time.monotonic()
                    model_calls += 1
                    try:
                        try:
                            if frozen_messages is not None and model_calls == 1:
                                from app.core.automap_retrieval import digest
                                if digest(messages) != frozen_receipt['message_digest']:
                                    raise ValueError('Frozen Auto-map packet changed before model dispatch')
                            raw, final_thread, final_payload = fast_runtime.run(messages, call_index=model_calls + block_review_calls)
                        finally:
                            timings["model"] += time.monotonic() - model_started
                    except Exception:
                        fast_failure = _fast_failure_diagnostics(fast_runtime, model_calls + block_review_calls)
                        # Do not retain a previous parse-repair response as this
                        # failed operation's payload, or trust exception fields.
                        final_payload = {"fast_diagnostics": fast_failure} if fast_failure is not None else {}
                        raise
                else:
                    model_started = time.monotonic()
                    raw, final_thread, final_payload = service._agent.run_detailed(
                        messages, agent=service._source_mapping_agent_name, thread_id=None, parent_message_id=None,
                        request_timeout=max(1, min(getattr(service._agent, "_timeout", 240), remaining())),
                    )
                    model_calls += 1
                    timings["model"] += time.monotonic() - model_started
                if remaining() <= 0 or (runtime is not None and runtime.cancellation is not None and runtime.cancellation.is_set()):
                    raise _BatchReadBudgetError("Batch response arrived after deadline or cancellation")
                parsed = None
                try:
                    if fast_enabled and (not isinstance(raw, str) or len(raw) > 120_000
                            or len(raw.encode("utf-8")) > min(120_000, settings.agent_outbound_message_max_bytes)):
                        raise ValueError("Fast response exceeds the bounded output allowance")
                    from app.core.automap_json import load_json
                    envelope = load_json(_extract_json_object(raw))
                    if not isinstance(envelope, dict):
                        raise ValueError("Agent output must be a JSON object")
                    if fast_enabled and not isinstance(envelope.get("meta") or {}, dict):
                        raise ValueError("Fast response metadata must be an object")
                    if fast_enabled and not isinstance((envelope.get("meta") or {}).get("delegation"), dict):
                        try:
                            from app.core.automap_source_format import normalize_source_objects
                            envelope = normalize_source_objects(envelope, fast_plan)
                            parsed = service._parse_envelope(json.dumps(envelope))
                        except Exception as parse_error:
                            raise ValueError("Fast response schema validation failed") from parse_error
                        if parsed[4] is not None or parsed[6] == STTMStatus.FAILED or not isinstance(parsed[1], SourceMappingResult):
                            raise ValueError("Fast response requires a structured mapping result")
                    break
                except (json.JSONDecodeError, ValueError) as parse_error:
                    logger.warning(
                        "Auto-map model response invalid request_id=%s batch_index=%s bytes=%s "
                        "first_char=%s attempt=%s error_type=%s",
                        req.request_id, req.meta.get("auto_mapping_batch_index"),
                        len(raw.encode("utf-8")) if isinstance(raw, str) else 0,
                        "object" if isinstance(raw, str) and raw.lstrip().startswith("{") else "other",
                        parse_attempt + 1, type(parse_error).__name__,
                    )
                    if parse_attempt or remaining() <= 1 or (fast_enabled and model_calls >= MAX_FAST_MODEL_CALLS):
                        raise
            if fast_plan is not None:
                fast_plan.native_tool_hint = None
                fast_plan.mark_dispatched(response_targets)
            stage = "mapping_validation"
            if parallel_enabled or fast_enabled:
                agent_warnings.extend(_batch_response_warnings(service,
                    parsed[3] if parsed is not None and parsed[3] else envelope.get("warnings"),
                    (final_payload or {}).get("warnings")))
            delegation = (envelope.get("meta") or {}).get("delegation")
            if isinstance(delegation, dict) and fast_enabled:
                agent_warnings.append(ApiWarning(code="auto_map_legacy_delegation",
                    message="The agent requested legacy delegation; unresolved targets require review."))
                delegation = None
            if isinstance(delegation, dict):
                if delegation.get("tool") in {"AUTO_MAP_CONTEXT", "ReadAutoMapContext", "SearchMappingEvidence", "ReadMappingEvidence"}:
                    from app.core.automap_tools import normalize_delegation
                    normalized = normalize_delegation(delegation, store.snapshot_hash)
                    if normalized["operation"] == "search_more":
                        if projection is not None or fast_enabled:
                            affected = set(normalized["targets"])
                            if not affected <= set(attributes):
                                raise ValueError("Search-more target is outside the owning batch")
                            detail = "Parallel evidence generation is frozen; new discovery requires a new batch with explicit unresolved scope"
                            (fast_warnings if fast_enabled else parallel_warnings).append(ApiWarning(
                                code="auto_map_fast_search_more_blocked" if fast_enabled else "parallel_search_more_blocked",
                                message=detail, field="context.parallel_preparation"))
                            for target in affected - completed.keys():
                                reasons[target] = detail
                            reason = detail
                            break
                        if any(target in completed for target in normalized["targets"]):
                            raise ValueError("Completed target cannot mix a new evidence generation")
                        search_started = time.monotonic()
                        search_result = store.search_more(normalized,
                            lambda targets, **options: service._discover_auto_map_batch_evidence(req, targets, **options),
                            max_rounds=settings.automap_search_more_rounds, max_bytes=page_bytes,
                            active_limit=settings.automap_learning_active_limit)
                        timings["discovery"] += time.monotonic() - search_started
                        results = [item for item in results if item.get("request", {}).get("operation") not in {"evidence", "discover"}
                                   or item["request"].get("target") not in normalized["targets"]]
                        inactive_dependencies = {identity for identity, (target, _category, ids) in
                            store.historical_dependency_owners.items() if target in normalized["targets"]
                            and not ids & store.active_evidence_ids(target)}
                        results = [item for item in results if not (item.get("request", {}).get("operation") == "dependency"
                                   and item["request"].get("relation_id") in inactive_dependencies)]
                        results.append({"request": {"operation": "search_more"}, "result": search_result})
                        required = [operation for target in normalized["targets"]
                                    for operation in store.required_operations(target, {"source_attributes": []})]
                        # Category contents changed: replay exact active evidence,
                        # not a stale previous candidate body or completion marker.
                        required.extend({"operation": "evidence", "target": target, "category": category}
                                        for target in normalized["targets"] for category in store.mandatory_categories(target))
                        read_operations(required)
                    else:
                        read_agent_operations(normalized["reads"])
                elif delegation.get("tool") == "CORTEX_ANALYST":
                    if fast_enabled:
                        raise ValueError("Fast final mapping cannot delegate to an unbounded Analyst call")
                    results.append(service._auto_map_analyst_evidence(req, delegation, decision, store.snapshot_hash))
                else:
                    raise ValueError("Unsupported batch delegation")
                continue
            if projection is not None:
                projection.validate(store)
                if remaining() <= 0 or (runtime.cancellation is not None and runtime.cancellation.is_set()):
                    raise ValueError("Parallel batch expired or canceled before validation")
            if parsed is None:
                parsed = service._parse_envelope(raw)
            result = parsed[1]
            if parsed[4] is not None or parsed[6] == STTMStatus.FAILED or not isinstance(result, SourceMappingResult):
                raise ValueError("Agent did not return a successful structured batch result")
            candidates = {}
            for name, candidate in result.mappings.items():
                try:
                    target = requested_target(attributes.values(), name)
                except ValueError:
                    target = None
                if target is None or target not in attributes:
                    # A malformed or foreign key (e.g. "A, B") answers no requested
                    # target; the omitted-target path below keeps the rest of the batch.
                    agent_warnings.append(ApiWarning(code="auto_map_foreign_target_ignored",
                        message=f"Ignored agent result key that is not one requested target: {str(name)[:120]}"))
                    continue
                if target in candidates:
                    raise ValueError("Agent returned a duplicate batch target")
                if target in completed or (response_targets is not None and target not in response_targets):
                    continue
                from app.schema.sttm_builder import CandidateScoringIssue
                candidate = candidate.model_copy(update={"candidates": [option.model_copy(update={
                    "scoring_policy_version": None, "scoring_issues": [CandidateScoringIssue(
                        code="capture_validation", category="validation", severity="error",
                        message="Alternative requires exact admission and evidence validation.")]})
                    for option in candidate.candidates]})
                retained_proposals[target] = record_proposal(candidate, retained_proposals.get(target),
                    messages=["Required admission and evidence validation is incomplete."])
                if candidate.rule_intent:
                    if req.meta.get('automap_rules_policy') == 'rules-v2':
                        required_columns = candidate.rule_intent.get('required_columns') or []
                        if isinstance(required_columns, list) and all(isinstance(reference, str) for reference in required_columns):
                            candidate = candidate.model_copy(update={'source_dependencies':
                                list(dict.fromkeys([*candidate.source_dependencies, *required_columns]))})
                    candidate = candidate.model_copy(update={
                        "preprocessing_nl_rule": candidate.preprocessing_nl_rule or candidate.rule_intent.get("description"),
                        "transformation_classification": "complex"})
                candidates[target] = candidate
            last_unresolved.update({target: candidate for target, candidate in candidates.items()
                if candidate.transformation_classification == "unresolved" and not candidate.source_attributes})
            repair_targets = None
            deficits, required = {}, []
            format_failures = set()
            recovery_requests = {}
            contradictory_eligibility = set()
            unresolved_response = {}
            response_text = json.dumps({"warnings": envelope.get("warnings") or []}, default=str).lower()
            blanket_no_sources = bool(re.search(r"no (?:eligible|available|selectable) source columns?", response_text))
            validation_started = time.monotonic()
            for target, attribute in attributes.items():
                if target in completed:
                    continue
                if fast_enabled and time.monotonic() >= deadline:
                    raise _BatchReadBudgetError("Fast validation deadline exhausted")
                candidate = candidates.get(target)
                if candidate is None and response_targets is not None and target not in response_targets:
                    candidate = last_unresolved.get(target)
                if candidate is None:
                    deficits[target] = ["Requested target was omitted; return it or explicitly unresolved"]
                    continue
                if str(candidate.unmatched_reason or "").startswith("Agent mapping failed schema validation for:"):
                    format_failures.add(target)
                    deficits[target] = [candidate.unmatched_reason]
                    reasons[target] = candidate.unmatched_reason
                    continue
                if candidate.transformation_classification == "unresolved" and not candidate.source_attributes:
                    if fast_enabled and candidate.candidate_source_attributes:
                        from app.core.automap_admission_context import CandidateAdmissionError
                        try:
                            fast_plan.validate_candidate(candidate)
                        except CandidateAdmissionError as candidate_error:
                            outcome_codes[target] = candidate_error.code
                            reasons[target] = str(candidate_error)
                            deficits[target] = [str(candidate_error)]
                            recovery_requests[target] = (candidate_error.code, list(candidate_error.references), candidate)
                            continue
                        except Exception:
                            format_failures.add(target)
                            deficits[target] = ["Unresolved alternatives contain an invalid expression or source reference"]
                            reasons[target] = deficits[target][0]
                            continue
                    if (fast_enabled and fast_plan is not None and fast_plan.allowed
                            and (blanket_no_sources or re.search(
                                r"no (?:eligible|available|selectable) source columns?",
                                str(candidate.unmatched_reason or "").lower()))):
                        contradictory_eligibility.add(target)
                        deficits[target] = ["Agent denied the explicit selectable source roster"]
                        reasons[target] = "Agent contradicted the validated source roster; review required"
                        continue
                    if preparation is not None and not preparation.coverage.exhaustive:
                        candidate = candidate.model_copy(update={"unmatched_reason": (
                            "Insufficient evidence: parallel coverage is non-exhaustive; "
                            "no grounded mapping was established for this target. "
                            "Unread or omitted sources may contain a match.")})
                    if fast_enabled:
                        detail = candidate.unmatched_reason or "No supported source was selected from the examined evidence."
                        if re.search(r"no source (?:anywhere|exists)|no matching.*anywhere", detail.lower()):
                            detail = "No supported source was selected from the examined evidence; coverage is non-exhaustive."
                        detail += " Decision coverage is non-exhaustive and limited to supplied evidence."
                        if fast_plan.next_pages.get(target):
                            detail += " Additional source evidence remains unread."
                        candidate = AttributeMapping(source_attributes=[], confidence_score=0,
                            candidate_source_attributes=candidate.candidate_source_attributes,
                            confidence_reason=candidate.confidence_reason,
                            transformation_classification="unresolved", unmatched_reason=detail)
                        if not candidate.candidate_source_attributes and target in reviewed_unresolved:
                            candidate = candidate.model_copy(update={
                                "candidate_source_attributes": reviewed_unresolved[target].candidate_source_attributes,
                                "confidence_reason": candidate.confidence_reason or reviewed_unresolved[target].confidence_reason})
                        reviewed_unresolved[target] = candidate
                    if fast_enabled:
                        detail = candidate.unmatched_reason or ""
                        placeholders = set(re.findall(r"\$[A-Za-z_][A-Za-z0-9_]*", detail))
                        graph = req.context.relation_graph
                        resolved = {binding.value.upper() for binding in (graph.value_bindings if graph else [])
                                    if binding.resolved_value is not None}
                        missing_values = sorted(value for value in placeholders if value.upper() not in resolved)
                        needs_rule = bool(re.search(r"business rule.*(?:missing|not provided|required)|missing.*business rule", detail, re.I))
                        if missing_values or needs_rule:
                            outcome_codes[target] = "missing_business_input"
                            completed[target] = candidate
                        else:
                            unresolved_response[target] = candidate
                    else:
                        completed[target] = candidate
                    continue
                receipts = []
                try:
                    if fast_plan is not None:
                        fast_plan.validate_candidate(candidate)
                        admitted = [item for item in fast_plan.binding_admissions()
                                    if item.record_id in fast_plan.column_rankings[target][:15]
                                    and fast_plan.source_evidence_ready(item.record_id)]
                        candidate = candidate.model_copy(update={
                            "admitted_source_attributes": [item.source_ref for item in admitted]})
                        from app.core.automap_citations import citation_deficits, source_record_id
                        receipts = citation_deficits(candidate,
                            source_ids={item.record_id for item in admitted} | {"src:" + item.source_ref for item in admitted}
                                | {source_record_id(item.source_ref) for item in admitted},
                            evidence_ids=store.evidence_ids(target),
                            value_ids={"val:" + binding.value for binding in (req.context.relation_graph.value_bindings if req.context.relation_graph else [])},
                            has_precedents=bool(store.recipe_ids(target) or store.precedent_ids(target)))
                        if receipts:
                            review_only_targets.add(target)
                            agent_warnings.append(ApiWarning(code="auto_map_read_receipt_review", field=target,
                                message="; ".join(receipts)))
                            # Invalid IDs cannot survive as apparent supporting citations.
                            if any("outside" in item for item in receipts):
                                candidate = candidate.model_copy(update={"decision_basis": {"citations": [],
                                    "semantic_reason": "Invalid packet citations removed; review required"}})
                        candidates[target] = candidate
                    missing = service._validate_auto_map_candidate(req, store, attribute, candidate)
                except Exception as validation_error:
                    # One malformed proposed expression must not discard grounded
                    # mappings for the other targets in this batch. Keep the
                    # provider's text out of logs because it may contain SQL.
                    logger.warning("Auto-map target validation rejected request_id=%s batch_index=%s "
                                   "target=%s error_type=%s", req.request_id,
                                   req.meta.get("auto_mapping_batch_index"), target,
                                   type(validation_error).__name__)
                    from app.core.automap_admission_context import CandidateAdmissionError
                    code = validation_error.code if isinstance(validation_error, CandidateAdmissionError) else "invalid_expression"
                    outcome_codes[target] = code
                    from app.core.automap_feedback import compiler_feedback
                    detail = (str(validation_error) if isinstance(validation_error, CandidateAdmissionError) else
                              encoded(getattr(validation_error, "feedback", None) or compiler_feedback(validation_error, stage="mapping_compile")))
                    retained_proposals[target] = record_proposal(candidate, retained_proposals.get(target),
                        messages=[detail], category="source" if isinstance(validation_error, CandidateAdmissionError) else "sql")
                    deficits[target] = [detail]
                    reasons[target] = detail
                    recovery_requests[target] = (code, list(getattr(validation_error, "references", ())), candidate)
                    continue
                citation_notes = receipts
                if block_review_calls and target in review_only_targets:
                    citation_notes = [*citation_notes, "Exact evidence was examined in blocks; review the original contract."]
                retained_proposals[target] = record_proposal(candidate, retained_proposals.get(target),
                    messages=missing or citation_notes, category="validation" if missing else "evidence",
                    warning=not missing)
                if not missing:
                    completed[target] = candidate
                else:
                    deficits[target] = missing
                    reasons[target] = "Missing exact evidence: " + "; ".join(missing)
                    required.extend(store.required_operations(target, candidate.model_dump(mode="json")))
                    if fast_enabled:
                        code = ("missing_business_input" if any("Value" in item or "placeholder" in item for item in missing)
                            else "invalid_evidence_citation" if any("cited evidence" in item or "unsupported pattern" in item or "unsupported linked precedent" in item for item in missing)
                            else "missing_exact_evidence")
                        outcome_codes[target] = code
                        if code == "missing_business_input":
                            completed[target] = AttributeMapping(source_attributes=[], confidence_score=0,
                                transformation_classification="unresolved", unmatched_reason=reasons[target])
                        else:
                            recovery_requests[target] = (code, [*candidate.source_attributes, *candidate.source_dependencies,
                                *candidate.candidate_source_attributes], candidate)
                    if candidate.preprocessing_rule and str(candidate.preprocessing_rule_type or "DIRECT").upper() not in {"DIRECT", "IDENTITY", "VALUE"}:
                        from sqlglot import exp, parse_one
                        try:
                            references = [column.sql(dialect="snowflake") for column in
                                          parse_one(candidate.preprocessing_rule, read="snowflake").find_all(exp.Column)]
                        except Exception:
                            deficits[target] = ["Candidate transformation could not be parsed"]
                            reasons[target] = "Candidate transformation could not be parsed; review required"
                            continue
                        required.extend(store.required_operations(target, {"source_attributes": references}))
            if fast_enabled:
                evidence_requests = (envelope.get("meta") or {}).get("evidence_requests", [])
                analyst_question_used = False
                if isinstance(evidence_requests, list) and _round == 0:
                    for request in evidence_requests[:len(attributes)]:
                        if not isinstance(request, dict):
                            continue
                        try:
                            key = fast_target_identity(request["target"]) if isinstance(request.get("target"), str) else None
                            matches = [current for current in attributes if fast_target_identity(current) == key]
                            target = matches[0] if len(matches) == 1 else None
                        except (ValueError, TypeError):
                            continue
                        question = request.get("data_question")
                        if (target in attributes and target not in completed and not analyst_question_used
                                and request.get("snapshot_hash") == store.snapshot_hash
                                and isinstance(question, str) and 0 < len(question) <= 1000 and remaining() > 15):
                            analyst_question_used = True
                            try:
                                answer = service._auto_map_analyst_evidence(req, {
                                    "tool": "CORTEX_ANALYST", "snapshot_hash": store.snapshot_hash,
                                    "requires_actual_rows": True, "question": question,
                                    "reason": "Explicit value-distribution question for a CASE rule"}, decision, store.snapshot_hash)
                            except Exception:
                                reasons[target] = "Prepared value-distribution evidence is unavailable; review required"
                            else:
                                fast_plan.data_question_evidence = {"target": target, "answer": answer}
                                deficits[target] = ["Reevaluate using the prepared value-distribution evidence"]
                                reasons[target] = deficits[target][0]
                                unresolved_response.pop(target, None)
                                recovery_requests[target] = ("data_question_evidence", [], candidates.get(target)
                                    or AttributeMapping(source_attributes=[], confidence_score=0, transformation_classification="unresolved"))
                        refs = request.get("source_refs")
                        if (target not in attributes or target in completed
                                or request.get("snapshot_hash") != store.snapshot_hash
                                or not isinstance(refs, list) or not refs or len(refs) > 10
                                or any(type(ref) is not str for ref in refs)):
                            continue
                        roots = request.get("evidence_roots", [])
                        if not fast_plan.request_optional_evidence_roots(refs, roots):
                            continue
                        deficits[target] = ["Requested exact source evidence has not yet been admitted", *sorted(set(roots))]
                        reasons[target] = "Requested source evidence requires current binding verification and reevaluation"
                        unresolved_response.pop(target, None)
                        recovery_requests[target] = ("requested_evidence", refs, candidates.get(target)
                            or AttributeMapping(source_attributes=[], confidence_score=0, transformation_classification="unresolved"))
            timings["validation"] += time.monotonic() - validation_started
            if pending_budget_groups:
                repair_targets = pending_budget_groups.pop(0)
                continue
            if len(completed) == len(attributes):
                break
            if fast_enabled:
                from app.core.automap_admission_context import CandidateAdmissionError
                focused = set()
                feedback = []
                # Recovery is keyed by target and deficit identity. Repeating the
                # same invalid decision without new evidence never loops.
                for target, (code, references, candidate) in recovery_requests.items():
                    signature = encoded([code, references, deficits.get(target)])
                    attempts = recovery_attempts.setdefault(target, set())
                    if signature in attempts or (code != "requested_evidence" and len(attempts) >= 2) or model_calls >= MAX_FAST_MODEL_CALLS:
                        completed[target] = AttributeMapping(source_attributes=[], confidence_score=0,
                            transformation_classification="unresolved", unmatched_reason=reasons[target])
                        continue
                    attempts.add(signature)
                    detail = f"Target {target}: {code}. {reasons[target][:1536]}"
                    if code in {"requested_evidence", "unadmitted_binding", "missing_exact_evidence"}:
                        before = fast_plan.admission_state()
                        repair_targets = {target}
                        try:
                            admitted, reads = fast_plan.recover_references(references, targets=repair_targets,
                                missing={target: deficits[target]}, issues=[*model_issues, detail])
                            if admitted:
                                extra = store.required_operations(target, candidate.model_dump(mode="json"))
                                fast_plan.base_operations = list({encoded(item): item for item in
                                    [*fast_plan.base_operations, *extra]}.values())
                                reads = fast_plan.selection_operations()
                                fast_plan.read_operations = reads
                            if not admitted or not read_agent_operations(reads):
                                fast_plan.restore_admission(before)
                                outcome_codes[target] = "required_evidence_budget_exceeded"
                                reasons[target] = "Required binding evidence cannot fit the complete-message or exact-read budget; split this target or review its source contract."
                                continue
                        except CandidateAdmissionError as admission_error:
                            fast_plan.restore_admission(before)
                            outcome_codes[target] = admission_error.code
                            reasons[target] = str(admission_error)
                            focused.add(target)
                            feedback.append(f"Target {target}: {admission_error.code}. Correct the evidence request using the frozen inventory.")
                            continue
                        except (ValueError, AgentPayloadBudgetError):
                            fast_plan.restore_admission(before)
                            outcome_codes[target] = "required_evidence_unavailable"
                            reasons[target] = "Required source evidence could not be retrieved; the earlier proposal was not accepted."
                            continue
                    focused.add(target)
                    feedback.append(detail)
                if focused and _round == 0 and remaining() > 1 and model_calls < MAX_FAST_MODEL_CALLS:
                    repair_targets = focused
                    model_issues = [*preparation_issues, *feedback,
                        "Reevaluate only the requested targets using admitted bindings and exact evidence. "
                        "For a transformation, select valid source bindings before asking for a complex rule. "
                        "Unknown or ambiguous references must be corrected, never guessed. Valid siblings are retained."]
                    continue
                repair_targets = None
                if format_failures and not format_repair_attempted and model_calls < MAX_FAST_MODEL_CALLS and remaining() > 1:
                    format_repair_attempted = True
                    repair_targets = format_failures
                    model_issues.append("Repair response format for only these targets: " + ", ".join(sorted(format_failures))
                        + ". Return source_attributes as strings copied exactly from selectable_sources[].source_ref; "
                        "preserve evidence IDs and confidence. Never invent a source. Already validated targets are retained.")
                    continue
                if format_failures:
                    for target in format_failures:
                        completed[target] = AttributeMapping(source_attributes=[], confidence_score=0,
                            transformation_classification="unresolved",
                            unmatched_reason="Response source-reference format could not be validated against an unambiguous admitted binding.")
                if (contradictory_eligibility and not eligibility_repair_attempted
                        and model_calls < MAX_FAST_MODEL_CALLS and remaining() > 1):
                    eligibility_repair_attempted = True
                    model_issues.append(
                        "The previous answer claimed there are no eligible source columns. "
                        f"That is factually incorrect: {len(fast_plan.allowed)} exact bindings are listed "
                        "in context.selectable_sources. Re-evaluate the unresolved targets against those "
                        "bindings; propose a mapping only when its target meaning and graph support it.")
                    continue
                pending = [target for target in attributes if target not in completed]
                if pending and _round == 0 and model_calls < MAX_FAST_MODEL_CALLS and remaining() > 1:
                    saved_admission = fast_plan.admission_state()
                    repair_targets = set(pending)
                    continuation = "New source evidence is admitted for the requested unresolved targets. Reevaluate these targets only; earlier absence claims were not exhaustive."
                    pages, page_reads = fast_plan.advance_pages(pending, results, missing=deficits,
                        issues=[*preparation_issues, continuation])
                    if pages:
                        if read_agent_operations(page_reads):
                            model_issues = [*preparation_issues, continuation]
                            continue
                        fast_plan.restore_admission(saved_admission)
                repair_targets = None
                for target, candidate in unresolved_response.items():
                    cursor = fast_plan.next_pages.get(target)
                    if cursor:
                        candidate = candidate.model_copy(update={"unmatched_reason":
                            f"{candidate.unmatched_reason or 'No grounded source was selected.'} "
                            f"Additional source inventory remains unread (next page: {cursor})."})
                    completed.setdefault(target, candidate)
                reason = "Terminal mapping left unresolved targets; no evidence or transport replay was attempted"
                break
            if deficits == previous_deficits and not required:
                reason = "Agent repeated batch decisions without resolving evidence deficits"
                break
            previous_deficits = deficits.copy()
            read_operations(required)
        else:
            reason = "Batch reached its bounded model-round limit"
    except AgentPayloadBudgetError as exc:
        reason = f"Exact batch evidence exceeds the complete-message budget; no rule was truncated: {exc}"
        if parallel_enabled:
            parallel_warnings.append(ApiWarning(code="parallel_message_budget_exceeded", message=reason))
        if fast_enabled:
            fast_warnings.append(ApiWarning(code="auto_map_context_deferred", message=reason))
    except _BatchReadBudgetError as exc:
        if parallel_enabled or fast_enabled:
            reason = ("Insufficient exact evidence: batch retrieval budget exhausted; "
                      "remaining targets are unresolved and coverage is non-exhaustive")
            for target in attributes.keys() - completed.keys():
                reasons[target] = reason
            (fast_warnings if fast_enabled else parallel_warnings).append(ApiWarning(
                code="auto_map_fast_read_budget_exceeded" if fast_enabled else "parallel_read_budget_exceeded", message=reason))
        else:
            reason = f"Batch evidence/reasoning failed (ValueError): {exc}"
    except Exception as exc:
        if parallel_enabled or fast_enabled:
            if stage in {"parallel_preparation", "fast_preparation"}:
                timings["preparation"] = time.monotonic() - preparation_started
            invariant = exc.code if isinstance(exc, _FastInvariantError) else "unspecified"
            if fast_failure is not None:
                invariant = next((event["response_reason"] for event in reversed(fast_failure["transport"])
                                  if event["response_reason"] is not None), fast_failure["failure_code"])
            logger.error("Auto-map batch failed request_id=%s batch_index=%s stage=%s "
                         "error_type=%s cause_type=%s invariant=%s elapsed_ms=%s completed_targets=%s",
                         req.request_id, req.meta.get("auto_mapping_batch_index"), stage,
                         type(exc).__name__, "none" if fast_enabled else getattr(exc, "cause_type", "none"), invariant,
                         round((time.monotonic() - started) * 1000, 1), len(completed))
            if fast_failure is not None and fast_failure.get("runtime_phase") == "admission_wait":
                reason = ("Remaining targets could not obtain Auto-map execution capacity; no suggestion was produced for them. "
                          "Retry after capacity is available or ask an administrator to review quarantined permits.")
            else:
                reason = f"Auto-map {stage} failed; remaining targets require review."
            (fast_warnings if fast_enabled else parallel_warnings).append(ApiWarning(
                code="auto_map_fast_stage_failed" if fast_enabled else "parallel_stage_failed", message=reason, field=stage))
        else:
            reason = f"Batch evidence/reasoning failed ({type(exc).__name__}): {exc}"
    if fast_enabled and budget_subdivision:
        for target in set(attributes) - queried_targets - set(completed):
            budget_deferred_targets.add(target)
            reasons[target] = 'The shared source-call or time allowance ended after context subdivision; this target was not examined. Completed drafts are retained.'
            outcome_codes[target] = 'required_evidence_budget_exceeded'
    mappings = {}
    audits = []
    for target, attribute in attributes.items():
        candidate = completed.get(target) or reviewed_unresolved.get(target) or AttributeMapping(source_attributes=[], confidence_score=0,
            transformation_classification="unresolved", unmatched_reason=reasons.get(target, reason))
        prior = reviewed_unresolved.get(target)
        if candidate.transformation_classification == "unresolved" and prior is not None:
            # Terminal repair/format/retrieval failures may replace the outcome,
            # but cannot delete alternatives already verified against this frozen
            # graph. Restore only review fields, never selected sources or SQL.
            candidate = candidate.model_copy(update={
                "candidate_source_attributes": candidate.candidate_source_attributes or prior.candidate_source_attributes,
                "confidence_reason": candidate.confidence_reason or prior.confidence_reason,
            })
        if target in retained_proposals:
            # Keep legacy outcome fields unresolved; only the draft roster retains rejected definitions.
            candidate = candidate.model_copy(update={"candidates": retained_proposals[target].candidates})
        if target in review_only_targets and candidate.transformation_classification != "unresolved":
            if block_review_calls:
                candidate = candidate.model_copy(update={"confidence_reason": (candidate.confidence_reason or "") +
                    " Exact evidence was examined in blocks; review the original contract before accepting this proposal."})
            fast_warnings.append(ApiWarning(code="AUTO_MAP_EVIDENCE_REVIEW_REQUIRED", field=attribute.target_attribute,
                message="This mapping requires human review of packet evidence and citation receipts."))
        mappings[attribute.target_attribute] = candidate.model_dump(mode="json")
        audits.append({"target": attribute.target_attribute, "snapshot_hash": store.snapshot_hash,
                       "evidence_ids": sorted(store.evidence_ids(target)),
                       "retrieval_diagnostics": retrieval_diagnostic_summary(
                           store.discovered.get(target, {}).get("diagnostics")),
                       **({"coverage": {"source_inventory_indexed": bool(fast_plan.inventory_ids),
                            "learning_evidence_discovered": target in store.discovered,
                            "cte_contract_validated": bool(fast_plan.validated_derived) or not any(
                                node.get("kind") == "DERIVED_SOURCE" for node in store.nodes.values()),
                            "model_decision_calls": model_calls,
                            "next_source_page": fast_plan.next_pages.get(target),
                            "transformation_validated": bool(candidate.preprocessing_rule)
                                if candidate.transformation_classification in {"complex", "simple_multi_source"}
                                else candidate.transformation_classification != "unresolved"}}
                           if fast_plan else {}),
                       "outcome_code": "grounded" if candidate.transformation_classification != "unresolved" else outcome_codes.get(target,
                           "source_not_examined" if fast_plan and fast_plan.next_pages.get(target) else "no_supported_mapping"),
                       "recovery_code": outcome_codes.get(target),
                       "status": "unresolved" if candidate.transformation_classification == "unresolved" else "grounded"})
    envelope = {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": mappings}}}
    fast_meta = {}
    if fast_enabled:
        from app.core.automap_fast_transport import FastModelRuntime
        durable_runtime = isinstance(fast_runtime, FastModelRuntime) and hasattr(fast_runtime, "bundle")
        call_store = getattr(getattr(getattr(fast_runtime,"bundle",None),"admission",None),"store",None)
        ownership_only = durable_runtime and getattr(call_store,"shared_capacity_limit",True) is False
        global_admission = durable_runtime and not ownership_only
        unscanned = (sorted(group for group in fast_plan.groups if group.startswith("table:") and fast_plan.group_relation.get(group) != store.target_table) if model_calls == 0 else list(fast_plan.omitted_source_groups)) if fast_plan else None
        if fast_plan is not None and model_calls == 0:
            fast_warnings.extend(ApiWarning(code="auto_map_fast_table_unscanned", field=group.removeprefix("table:"),
                message="Whole table was not dispatched because fast preparation did not complete; no absence was established.")
                for group in sorted(fast_plan.selected) if group.startswith("table:") and fast_plan.group_relation.get(group) != store.target_table)
        if fast_plan is not None and any(event.get('stage') == 'final_message_repack' for event in fast_plan.admission_events):
            fast_warnings.append(ApiWarning(code='auto_map_context_reduced', message=
                'Auto-map used the highest-priority evidence that fits. Additional source evidence remains unexamined; review the draft and its confidence.'))
        warnings = list({encoded(warning.model_dump(mode="json")): warning.model_dump(mode="json")
                         for warning in [*agent_warnings, *fast_warnings]}.values())
        from app.schema.sttm_builder import AutoMapContextBudget
        fast_meta = {"version": "v1", "warnings": warnings, "exhaustive": False,
            "context_budget": AutoMapContextBudget.model_validate({"policy_version": "final-message-v1", "exhaustive": False,
                "final_chars": peak_chars, "final_bytes": peak_bytes,
                "max_chars": min(180000, settings.agent_outbound_message_max_chars),
                "max_bytes": min(180000, settings.agent_outbound_message_max_bytes),
                "included_evidence_ids": sorted(fast_plan.rendered_record_ids) if fast_plan else [],
                "deferred_group_ids": list(fast_plan.omitted) if fast_plan else [],
                "budget_deferred_targets": sorted(budget_deferred_targets)}).model_dump(mode='json'),
            "scan_model_calls": 0, "reducer_model_calls": 0, "global_admission": global_admission,
            "operation_tracking": ownership_only,
            "admission": "durable_operation_tracking" if ownership_only else "durable_global_pool" if global_admission else "process_semaphore" if fast_runtime and not getattr(fast_runtime, "is_test_runtime", False) else "test_runtime" if fast_runtime else "not_started",
            "deadline_at": req.meta.get("auto_map_deadline_at"), "validation_reserve_seconds": 20,
            "unscanned_groups": unscanned,
            "planned_groups": sorted(fast_plan.selected) if fast_plan else [],
            "admitted_groups": sorted(fast_plan.selected) if fast_plan and model_calls else [],
            "peak_message_chars": peak_chars, "soft_budget_exceeded": peak_chars > 50_000,
            "soft_message_chars": 50_000, "hard_message_chars": min(180_000, settings.agent_outbound_message_max_chars),
            "hard_message_bytes": min(180_000, settings.agent_outbound_message_max_bytes),
            "omitted_target_groups": list(fast_plan.omitted_target_groups) if fast_plan else [],
            "admission_events": fast_plan.admission_events if fast_plan else [],
            "source_admission": fast_plan.admission_manifest() if fast_plan else {},
            "context_manifest": getattr(fast_plan, "context_manifest", None),
            "shown_source_counts": {target: len(ids) for target, ids in fast_plan.shown.items()} if fast_plan else {}}
        if fast_failure is not None:
            fast_meta["fast_diagnostics"] = fast_failure
        envelope["warnings"] = warnings
        fast_meta["evidence_review_calls"] = block_review_calls
        if frozen_receipt is not None:
            fast_meta['frozen_packet'] = frozen_receipt
            fast_meta['context_budget'].update({key:frozen_receipt[key]
                for key in ('packet_version','packet_digest','message_digest')})
        fast_meta["evidence_blocks"] = {"total": len(fast_plan.blocks.blocks), "reviewed": len(fast_plan.blocks.reviews),
            "pending": len(fast_plan.blocks.pending)} if fast_plan else {}
        envelope["meta"] = {"auto_map_fast_path": fast_meta,
            "automap_evidence_review_only_targets": sorted(attributes[target].target_attribute for target in review_only_targets)}
        final_payload = {**(final_payload or {}), "warnings": warnings, "auto_map_fast_path": fast_meta,
            "automap_evidence_review_only_targets": sorted(attributes[target].target_attribute for target in review_only_targets)}
    parallel_meta = {}
    if parallel_enabled:
        warnings = list({encoded(warning.model_dump(mode="json")): warning.model_dump(mode="json")
                         for warning in [*agent_warnings, *parallel_warnings]}.values())
        parallel_meta = {"enabled": True, "warnings": warnings,
                         "coverage": asdict(preparation.coverage) if preparation else None,
                         "generation": preparation.candidate_manifest.get("generation") if preparation else None,
                         "search_more_policy": "frozen_generation_requires_new_batch",
                         "assistant_context": {"warnings": warnings, "non_exhaustive": True,
                             "instruction": "These mappings are proposals from non-exhaustive evidence. Explain coverage warnings; do not infer no-match from omitted tables."}}
        envelope["warnings"] = warnings
        envelope["meta"] = {"parallel_preparation": parallel_meta}
        final_payload = {**(final_payload or {}), "warnings": warnings, "parallel_preparation": parallel_meta}
    actual_posts = None
    completed_responses = None
    from app.core.automap_fast_transport import FastModelRuntime, FastSessionModelRuntime
    if issubclass(type(fast_runtime), FastModelRuntime) and not issubclass(type(fast_runtime), FastSessionModelRuntime):
        traces = [request.runtime_trace for request in fast_runtime._requests.values() if getattr(request, 'runtime_trace', None) is not None]
        actual_posts = sum(trace.model_post_attempts for trace in traces)
        completed_responses = sum(trace.terminal_responses for trace in traces)
    payload = BatchPayload({
        **(final_payload or {}),
        "auto_map_admitted_evidence": {target: {category: store.evidence[target][category]
                                             for category in store.mandatory_categories(target)}
                                      for target in store.targets},
        "auto_map_retrieval": {
            **({"auto_map_fast_path": fast_meta, "warnings": fast_meta["warnings"]} if fast_enabled else {}),
            **({"parallel_preparation": parallel_meta, "warnings": parallel_meta["warnings"]} if parallel_enabled else {}),
            "strategy": STRATEGY_VERSION, "target_count": len(mappings),
            "planned_model_call_count": model_calls + block_review_calls,
            "actual_model_post_count": actual_posts, "completed_model_response_count": completed_responses,
            "model_call_count": actual_posts if actual_posts is not None else model_calls + block_review_calls,
            "operation_count": operation_count, "peak_message_bytes": peak_bytes, "targets": audits,
            "source_preparation_issues": preparation_issues,
            "search_work": store.search_work, "additional_search_rounds": store.search_rounds,
            **({"parent_discovery": store.parent_discovery} if hasattr(store, "parent_discovery") else {}),
            "completed_reads": [list(identity) for identity in sorted(store.reads)], "read_events": events,
            "timings_ms": {key: round(value * 1000, 1) for key, value in timings.items()},
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "wall_time_enforcement": "between_operations_and_network_timeout_not_hard_job_cancellation",
        },
    })
    payload.execution = (fast_runtime, store)
    return json.dumps(envelope), final_thread, payload
