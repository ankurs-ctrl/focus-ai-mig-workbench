"""Offline FIR recovery manifest. Never connects, executes SQL, or resets offsets.

Input is an administrator-reviewed JSON inventory containing streams, tasks and
permission evidence. Missing permission evidence remains unknown, not granted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from typing import Any

CORE_TASKS = frozenset({"TSK_FIR_CAPTURE", "TSK_FIR_ENRICH_CONTEXT", "TSK_FIR_PROCESS_BATCH",
                        "TSK_FIR_PROMOTE_INDEX", "TSK_FIR_LEARNING_QUEUE"})


def identifier(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Z_][A-Z0-9_$]*", value):
        raise ValueError("Expected an uppercase Snowflake identifier")
    return value


def stream_contract(name: str) -> dict:
    from scripts.fir_stream_recovery import CONTRACTS
    if name not in CONTRACTS:
        return {"mode": "blocked", "reason": "Unknown stream; not allowlisted"}
    source, key, append, collector = CONTRACTS[name]
    return {"mode": "durable_signal" if collector == "durable_signal" else "retained_replay",
            "source": source, "identity": key, "append_only": append,
            "executor": "scripts.fir_stream_recovery", "approval_required": True,
            "reason": "Retained mutable snapshots are observations, never reconstructed approvals; expired history is not recoverable"}


def build_manifest(inventory: dict[str, Any]) -> dict[str, Any]:
    namespace = inventory["namespace"]
    parts = namespace.split(".")
    if len(parts) != 2:
        raise ValueError("Expected DATABASE.SCHEMA")
    for part in parts:
        identifier(part)
    owner = identifier(inventory["task_owner"])
    streams = [{str(key).lower(): value for key, value in row.items()} for row in inventory.get("streams", [])]
    tasks = [{str(key).lower(): value for key, value in row.items()} for row in inventory.get("tasks", [])]
    stale = sorted(str(row["name"]) for row in streams if str(row.get("stale")).lower() == "true")
    missing = sorted(CORE_TASKS - {row.get("name") for row in tasks})
    permission = inventory.get("effective_execute_task")
    blockers = []
    if permission is not True:
        blockers.append("EXECUTE_TASK_MISSING" if permission is False else "EXECUTE_TASK_UNVERIFIED")
    if not streams:
        blockers.append("STREAM_INVENTORY_UNAVAILABLE")
    if stale:
        blockers.append("STALE_STREAM_RECONCILIATION_REQUIRED")
    if missing:
        blockers.append("CORE_TASKS_MISSING_OR_NOT_VISIBLE")
    mismatch = sorted(str(row.get("name")) for row in tasks
                      if row.get("name") in CORE_TASKS and row.get("owner") != owner)
    if mismatch:
        blockers.append("TASK_OWNER_MISMATCH_OR_UNVERIFIED")
    return {
        "mode": "dry_run", "namespace": namespace, "task_owner": owner,
        "blockers": blockers, "activation_authorized": False,
        "permission_evidence": "effective_verified" if permission is True else "missing" if permission is False else "unknown",
        "grant_for_admin_review": f"GRANT EXECUTE TASK ON ACCOUNT TO ROLE {owner};" if permission is False else None,
        "missing_core_tasks": missing, "owner_mismatches": mismatch,
        "stale_streams": stale,
        "stream_recovery": [{"name": row.get("name"), "source": row.get("table_name"),
            "replay_contract": stream_contract(str(row.get("name"))),
            "mode": row.get("mode"), "stale_after": str(row.get("stale_after") or ""),
            "action": "review_retained_source_backfill_before_new_capture",
            "expired_history_recoverable": False} for row in streams if row.get("name") in stale],
        "required_steps": ["verify_effective_owner_and_object_permissions", "review_consumer_keys_and_deletion_semantics",
            "establish_capture_boundary_before_snapshot", "reconcile_retained_rows_idempotently",
            "drain_capture_overlap", "verify_counts_and_checkpoints", "approve_bounded_canary_then_activation"],
        "limitations": ["Current snapshots cannot reconstruct expired deletes or intermediate updates.",
            "Permission evidence must include inherited roles and object privileges; direct grants alone are insufficient.",
            "This manifest authorizes no mutation. Source-specific cutover SQL requires separate review."],
    }


def reconcile_retained_records(records: list[dict], completed_keys: set[str], *, limit: int = 10) -> dict:
    """Bounded pure replay plan; identity must come from the reviewed consumer contract.

    A changed payload under the same idempotency key is a conflict, never an
    automatic overwrite. Completion checkpoints, not arrival order, govern replay.
    """
    if not 1 <= limit <= 100:
        raise ValueError("Recovery limit must be between 1 and 100")
    unique = {}
    conflicts = set()
    for record in records:
        key = record.get("idempotency_key")
        if not isinstance(key, str) or not key.strip():
            raise ValueError("Recovery requires explicit stable idempotency keys")
        digest = hashlib.sha256(json.dumps(record.get("payload"), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if key in unique and unique[key][0] != digest:
            conflicts.add(key)
        unique[key] = (digest, record)
    pending = sorted(set(unique) - completed_keys - conflicts)
    return {"records": [unique[key][1] for key in pending[:limit]],
            "remaining": max(0, len(pending) - limit), "conflicts": sorted(conflicts),
            "apply_allowed": False}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", required=True, help="Local JSON inventory; no Snowflake connection is made")
    args = parser.parse_args()
    with open(args.inventory, encoding="utf-8") as source:
        inventory = json.load(source)
    print(json.dumps(build_manifest(inventory), indent=2))


if __name__ == "__main__":
    main()
