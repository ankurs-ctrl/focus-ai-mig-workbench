#!/usr/bin/env python3
"""Build and verify a cumulative overlay without exporting local configuration."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

PUBLIC_PROFILES = {
    'infra/snowflake/env/parallel.dev.json',
    'infra/snowflake/env/parallel.uat.json',
    'infra/snowflake/env/parallel.uat.durable-v2.json',
}
DENIED_PARTS = {'.git', '.venv', 'venv', 'node_modules', '__pycache__', '.pytest_cache',
                '.next', '.dev-cache', '.cache', 'dist', 'build', '.aws', '.codex'}


def digest(body):
    return hashlib.sha256(body).hexdigest()


def allowed(name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or not path.parts:
        return False
    if set(path.parts) & DENIED_PARTS:
        return False
    if 'env' in path.parts and name not in PUBLIC_PROFILES:
        return False
    base = path.name.lower()
    return not (base.startswith('.env') or base == 'client.env'
        or path.suffix.lower() in {'.env', '.pem', '.key', '.p12', '.pfx', '.pyc', '.zip'}
        or (base.endswith('.lock') and base != 'uv.lock') or base.endswith('.tsbuildinfo') or base == '.ds_store'
        or 'credential' in base or 'private-key' in base)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', action='append', required=True, type=Path)
    parser.add_argument('--previous-overlay', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--release', required=True)
    parser.add_argument('--results', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    # Only Git-inventoried files are eligible, never recursively copy a checkout.
    names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=root).decode().split('\0')
    current = {name: (root/name).read_bytes() for name in names
               if name and allowed(name) and (root/name).is_file() and not (root/name).is_symlink()}
    previous = zipfile.ZipFile(args.previous_overlay)
    old_names = {name[6:] for name in previous.namelist() if name.startswith('files/') and not name.endswith('/')}
    absent = sorted(old_names - current.keys())
    if absent:
        raise SystemExit('Previous overlay files absent or ineligible: ' + ', '.join(absent))
    for profile in PUBLIC_PROFILES:
        settings = json.loads(current[profile])
        assert set(settings) <= {'environment', 'scope', 'settings'}, profile
        for key in settings.get('settings', {}):
            if any(secret in key.upper() for secret in ('PASSWORD', 'SECRET', 'ACCESS_TOKEN', 'PRIVATE_KEY')):
                raise SystemExit('Credential setting in public profile: ' + key)
    baselines = [zipfile.ZipFile(path) for path in args.baseline]
    if len(baselines) != 2:
        raise SystemExit('Exactly the two supplied client baselines are required')
    included = set(old_names)
    for base in baselines:
        for name, body in current.items():
            try:
                original = base.read('ffp_ai_mig_workbench/' + name)
            except KeyError:
                original = None
            if original != body:
                included.add(name)
    included.update(PUBLIC_PROFILES)
    manifest = {
        'release': args.release,
        'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'previous_overlay': {'name': args.previous_overlay.name, 'sha256': digest(args.previous_overlay.read_bytes()), 'preserved_file_count':len(old_names)},
        'files': {name:{'sha256':digest(current[name]), 'bytes':len(current[name]),
            'mode': oct((root/name).stat().st_mode & 0o777)} for name in sorted(included)},
        'baselines': [], 'deletions': [],
        'public_deployment_profiles': sorted(PUBLIC_PROFILES),
        'excluded': ['environment/credential files', 'dependencies', 'Git metadata', 'private captures', 'compiled assets'],
        'results': json.loads(args.results.read_text()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    start = ('Cumulative release '+args.release+'\n\nApply files/ at the repository root. Read '
             'docs/combined-release-20261113/V19-RELEASE.md before deployment.\n'
             'Keep client.env, .env files and credentials. The three env/*.json files are public deployment profiles, not secrets.\n'
             'Newer team custom-rule-library commits are intentionally excluded.\n')
    for file, base in zip(args.baseline, baselines):
        reconstructed = 0
        for name, body in current.items():
            actual = current[name] if name in included else base.read('ffp_ai_mig_workbench/' + name)
            if actual != body:
                raise SystemExit('Reconstruction mismatch: ' + name)
            reconstructed += 1
        manifest['baselines'].append({'name':file.name,'sha256':digest(file.read_bytes()),
            'verified_current_files':reconstructed,'additional_baseline_files_deleted':False})
    with zipfile.ZipFile(args.output, 'w', zipfile.ZIP_DEFLATED) as output:
        output.writestr('START-HERE.txt', start)
        for name in sorted(included):
            info = zipfile.ZipInfo('files/'+name)
            info.create_system = 3
            info.external_attr = (0o100000 | ((root/name).stat().st_mode & 0o777)) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(info, current[name])
        output.writestr('MANIFEST.json', json.dumps(manifest, indent=2)+'\n')
    # Verify the actual ZIP bytes, not only the planned manifest.
    with zipfile.ZipFile(args.output) as output:
        if output.testzip() is not None:
            raise SystemExit('ZIP integrity verification failed')
        for name in included:
            if (output.getinfo('files/'+name).external_attr >> 16) & 0o777 != (root/name).stat().st_mode & 0o777:
                raise SystemExit('ZIP permission mismatch: '+name)
            if digest(output.read('files/'+name)) != manifest['files'][name]['sha256']:
                raise SystemExit('ZIP content mismatch: '+name)
    checksum = digest(args.output.read_bytes())
    args.output.with_suffix(args.output.suffix+'.sha256').write_text(checksum+'  '+args.output.name+'\n')
    print(json.dumps({'zip':str(args.output),'sha256':checksum,'files':len(included),
        'previous_files_preserved':len(old_names),'verified_baselines':manifest['baselines']},indent=2))


if __name__ == '__main__':
    main()
