import pytest
from app.core.sql_execution_guard import validate_relations,sql_hash


def test_ctes_are_resolved_without_allowing_unselected_sources():
    assert validate_relations('WITH c AS (SELECT ID FROM DB.SRC.A) SELECT * FROM c',{'DB.SRC.A'}) == ['DB.SRC.A']
    with pytest.raises(PermissionError):
        validate_relations('WITH c AS (SELECT ID FROM DB.SECRET.A) SELECT * FROM c',{'DB.SRC.A'})

@pytest.mark.parametrize('sql',['SELECT * FROM A','SELECT * FROM TABLE(RESULT_SCAN(1))','SELECT * FROM DB.SRC.B'])
def test_unqualified_external_and_unselected_relations_are_denied(sql):
    with pytest.raises((ValueError,PermissionError)):validate_relations(sql,{'DB.SRC.A'})

@pytest.mark.parametrize('sql',['DELETE FROM DB.SRC.A','SELECT * FROM DB.SRC.A; SELECT 1','CALL DB.SRC.P()'])
def test_mutating_and_multi_statement_sql_are_denied(sql):
    with pytest.raises(ValueError):validate_relations(sql,{'DB.SRC.A'})


def test_hash_changes_when_edited_sql_changes():
    assert sql_hash('SELECT 1') != sql_hash('SELECT 2')


@pytest.mark.parametrize('sql',[
    'SELECT ID INTO DB.SRC.NEW_TABLE FROM DB.SRC.A',
    "SELECT SYSTEM$ABORT_SESSION('123') FROM DB.SRC.A",
    'SELECT DB.SRC.EXTERNAL_SEND(ID) FROM DB.SRC.A',
])
def test_select_cannot_hide_writes_or_external_function_calls(sql):
    with pytest.raises((ValueError,PermissionError)):
        validate_relations(sql,{'DB.SRC.A'})
