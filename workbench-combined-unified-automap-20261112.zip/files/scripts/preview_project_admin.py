"""Local UI sample-data API. Never connects to Snowflake or reads credentials.

Run with Python, then start the frontend with the command in the release notes.
Only loopback connections are accepted. Archive/delete affect in-memory samples.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import re
from datetime import datetime, timedelta, timezone

PROJECTS = [{'project_id': '101', 'project_name': 'CRM Migration — Preview',
    'description': 'Local sample data; no Snowflake connection', 'status': 'ACTIVE',
    'sttm_count': 2, 'complete_count': 0, 'partial_count': 0, 'draft_count': 2,
    'total_mappings': 24, 'mapped_count': 0, 'coverage_percent': 0}]
MAPPINGS = [{'sttm_id': str(201+i), 'project_id': '101', 'sttm_name': name,
    'status': 'DRAFT', 'current_version': 0, 'has_unpublished_draft': True,
    'mapping_count': 12, 'mapped_count': 0, 'coverage_percent': 0}
    for i, name in enumerate(['Contacts', 'Households'])]


class Handler(BaseHTTPRequestHandler):
    def reply(self, data, status=200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.endswith('/auth/session') or self.path.endswith('/auth/permissions'):
            self.reply({'user_id': 1, 'display_name': 'Local Admin Preview', 'snowflake_user': 'LOCAL_PREVIEW',
                'app_persona': 'ADMIN', 'snowflake_role': 'ADMIN', 'email': 'preview@example.test',
                'permissions': {'can_read': True, 'can_edit': True, 'can_publish': True,
                                'can_manage_users': True, 'can_view_audit': True}, 'auth_mode': 'local'})
        elif self.path.endswith('/projects/summary'):
            self.reply({'projects': [row for row in PROJECTS if row['status'] not in ('ARCHIVED','DELETED')], 'sttms': [row for row in MAPPINGS if row['status'] not in ('ARCHIVED','DELETED')]})
        elif self.path.endswith('/admin/resources/removed'):
            self.reply([{'id':row[key], 'name':row[name], 'kind':kind, 'status':row['status'], 'recoverable_until':row.get('recoverable_until','')} for kind, rows, key, name in [('project',PROJECTS,'project_id','project_name'),('mapping',MAPPINGS,'sttm_id','sttm_name')] for row in rows if row['status'] in ('ARCHIVED','DELETED')])
        else:
            self.reply([])

    def do_POST(self):
        match = re.fullmatch(r'/api/v1/admin/resources/(project|mapping)/(\d+)/(archive|delete|restore)', self.path)
        if not match:
            self.reply({'message': 'Preview supports sample archive/delete/restore actions only.'}, 404)
            return
        kind, identifier, action = match.groups()
        rows = PROJECTS if kind == 'project' else MAPPINGS
        key = 'project_id' if kind == 'project' else 'sttm_id'
        selected = next((row for row in rows if row[key] == identifier), None)
        if not selected:
            self.reply({'message':'Sample item not found'},404)
            return
        if kind == 'mapping' and action == 'restore' and any(row['project_id']==selected['project_id'] and row['status'] in ('ARCHIVED','DELETED') for row in PROJECTS):
            self.reply({'message':'Restore the project first'},409)
            return
        affected = [selected]
        if kind == 'project':
            affected += [row for row in MAPPINGS if row['project_id']==identifier and (row.get('removed_with_project')==identifier if action=='restore' else row['status'] not in ('ARCHIVED','DELETED'))]
        for row in affected:
            if action == 'restore':
                row['status'] = row.pop('previous_status', 'DRAFT')
                row.pop('removed_with_project',None)
                row.pop('recoverable_until',None)
            else:
                row['previous_status'] = row['status']
                row['status'] = 'ARCHIVED' if action == 'archive' else 'DELETED'
                if action == 'delete': row['recoverable_until'] = (datetime.now(timezone.utc)+timedelta(days=30)).isoformat()
                if kind == 'project' and row is not selected: row['removed_with_project'] = identifier
        self.reply({'status': selected['status'], 'history_retained': True})



if __name__ == '__main__':
    print('Sample-data preview API: http://127.0.0.1:8016', flush=True)
    HTTPServer(('127.0.0.1', 8016), Handler).serve_forever()
