import type { AutoMapCandidate } from '@/types/api-contract';
import type { MappingState, MappingRuleType } from '../types/sttm.types';

/** A complete option, never a names-only alternative with an invented score. */
export function rankedRowCandidates(values: AutoMapCandidate[]): AutoMapCandidate[] {
  const seen = new Set<string>();
  return values.filter(value => {
    if (!value || !value.candidate_id || seen.has(value.candidate_id)
      || !Array.isArray(value.source_attributes) || (value.confidence_score !== null && (!Number.isFinite(value.confidence_score)
      || value.confidence_score < 0 || value.confidence_score > 1))) return false;
    seen.add(value.candidate_id);
    return true;
  }).sort((a, b) => (b.confidence_score ?? -1) - (a.confidence_score ?? -1)).slice(0, 4);
}

export function candidateRowUpdates(candidate: AutoMapCandidate): Partial<MappingState> {
  const mode = candidate.mapping_mode ?? 'source';
  const value = mode === 'constant' || mode === 'attribute';
  const rule = value ? 'Value' : candidate.preprocessing_rule_type || (candidate.preprocessing_rule ? 'Custom' : 'Direct');
  return {
    sourceColumns: [...candidate.source_attributes],
    sourceColumn: candidate.source_attributes.join(', ') || null,
    sourceType: null,
    mappingMode: mode, constantValue: candidate.constant_value ?? null,
    attributeName: candidate.attribute_name ?? null,
    rule: rule as MappingRuleType,
    expression: value || ['DIRECT', 'IDENTITY'].includes(rule.toUpperCase()) ? null : candidate.preprocessing_rule ?? null,
    nlRule: candidate.preprocessing_nl_rule ?? null,
    sourceDependencies: [...(candidate.source_dependencies ?? candidate.source_attributes)],
    valueBindingIds: [...(candidate.value_binding_ids ?? [])],
    transformationClassification: candidate.transformation_classification ?? null,
    confidenceScore: candidate.confidence_score, confidenceReason: candidate.confidence_reason ?? null,
    unmatchedReason: candidate.validation_errors?.join(' ') || candidate.unmatched_reason || null,
    aiSuggestedRule: candidate.preprocessing_rule ?? null, aiSuggestedRuleType: rule,
    usedInferenceIds: candidate.used_inference_ids ?? [], usedRecommendationIds: candidate.used_recommendation_ids ?? [],
    usedLearningIds: candidate.used_learning_ids ?? [],
    precedentDecision: candidate.precedent_decision ?? null, precedentMappingId: candidate.precedent_mapping_id ?? null,
    overrideEvidence: candidate.override_evidence ?? [],
    status: candidate.validation_status === 'valid' ? 'MAPPED' : 'UNMAPPED',
    manuallySaved: false, manuallyEditedAfterAutoMap: false, learningOrigin: null,
    selectedAiCandidateId: candidate.candidate_id, aiReviewStatus: 'unreviewed',
  };
}

export function candidateMatchesRow(row: MappingState, candidate: AutoMapCandidate): boolean {
  const proposed = candidateRowUpdates(candidate);
  return ['sourceColumns', 'mappingMode', 'constantValue', 'attributeName', 'rule', 'expression', 'sourceDependencies', 'valueBindingIds']
    .every(key => JSON.stringify(row[key as keyof MappingState] ?? null) === JSON.stringify(proposed[key as keyof MappingState] ?? null));
}

export function aiUndoSnapshot(row: MappingState): Partial<MappingState> {
  // No recursive history. Persist the previous draft definition, including its review state.
  const { aiUndoSnapshot: _history, ...snapshot } = row;
  void _history;
  return {
    sourceColumns: [], sourceColumn: null, sourceType: null, mappingMode: 'source', constantValue: null,
    attributeName: null, expression: null, nlRule: null, sourceDependencies: [], valueBindingIds: [],
    transformationClassification: null, confidenceScore: null, confidenceReason: null, unmatchedReason: null,
    aiSuggestedRule: null, aiSuggestedRuleType: null, usedInferenceIds: [], usedRecommendationIds: [],
    usedLearningIds: [], precedentDecision: null, precedentMappingId: null, overrideEvidence: [],
    manuallySaved: false, manuallyEditedAfterAutoMap: false, learningOrigin: null,
    selectedAiCandidateId: null, aiReviewStatus: null,
    ...JSON.parse(JSON.stringify(snapshot)),
  } as Partial<MappingState>;
}
