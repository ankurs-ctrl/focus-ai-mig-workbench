const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const { createRequire } = require('node:module');

// Compile the actual reducer and its pure helpers without a browser or network.
// Service imports are deliberately unavailable: hydration reduction must be pure.
const root = path.resolve(__dirname, '..');
const nativeRequire = createRequire(path.join(root, 'package.json'));
const cache = new Map();
function load(filename) {
  if (cache.has(filename)) return cache.get(filename).exports;
  const module = { exports: {} };
  cache.set(filename, module);
  const source = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
  }).outputText;
  function localRequire(name) {
    if (name.startsWith('@/services/') || name.startsWith('@/api/')) return {};
    if (name.startsWith('@/') || name.startsWith('.')) {
      const base = name.startsWith('@/') ? path.join(root, 'src', name.slice(2)) : path.resolve(path.dirname(filename), name);
      const found = [base, `${base}.ts`, `${base}.tsx`, path.join(base, 'index.ts')].find(p => fs.existsSync(p) && fs.statSync(p).isFile());
      if (!found) throw new Error(`Unresolved local test dependency: ${name}`);
      return load(found);
    }
    return nativeRequire(name);
  }
  vm.runInThisContext(`(function(require,module,exports){${source}\n})`, { filename })(localRequire, module, module.exports);
  return module.exports;
}
const slice = load(path.join(root, 'src/features/sttm/store/sttm-builder-slice.ts'));
const reducer = slice.default;
const open = slice.openSttmFromBackend;

test('a late mapping response cannot hydrate over the newly selected project', () => {
  let state = reducer(undefined, { type: 'test/init' });
  state = reducer(state, open.pending('old-request', { projectId: 'project-a', sttmId: 'mapping-a' }));
  state = reducer(state, open.pending('new-request', { projectId: 'project-b', sttmId: 'mapping-b' }));
  const current = state;
  state = reducer(state, open.fulfilled({}, 'old-request', { projectId: 'project-a', sttmId: 'mapping-a' }));
  assert.equal(state, current);
  assert.equal(state.activeProjectId, 'project-b');
  assert.equal(state.activeSttmId, 'mapping-b');
  state = reducer(state, open.rejected(new Error('old failure'), 'old-request', { sttmId: 'mapping-a' }));
  assert.equal(state, current);
});

test('starting a new mapping invalidates outstanding hydration', () => {
  let state = reducer(undefined, open.pending('old-request', { projectId: 'project-a', sttmId: 'mapping-a' }));
  state = reducer(state, slice.resetBuilderForNewMapping());
  const current = state;
  state = reducer(state, open.fulfilled({}, 'old-request', { sttmId: 'mapping-a' }));
  assert.equal(state, current);
  assert.equal(state.openSttmRequestId, null);
});
