"""Offline reducer tests: real prepared contexts, no SQL/network/model calls."""
from contextlib import contextmanager
from dataclasses import FrozenInstanceError, asdict, replace
import hashlib
import json
import random
import time

import pytest

from app.core.automap_reduce import (
    CandidateKey, CandidateReduction, ReductionBlocked, ReductionPolicy,
)
from app.core.automap_retrieval import AutoMapContext
from app.core.automap_scan import (
    CandidateRole, ScanCandidate, ScanResult, ScanStatus, ShardScanResult, TargetCandidates,
    scan_registry, summarize_scan_coverage,
)
from app.core.automap_scan_context import prepare_scan_context
from app.core.automap_scan_transport import _request_body
from app.core.automap_shards import ContextRecord, MessageBudget, MessageBudgetError, ScopeMismatchError, SnapshotScope
from app.core.snowflake_agent import SnowflakeAgentClient


BUDGET = MessageBudget(200_000, 200_000)


class Archive:
    """Test-only memory archive; production must inject external durable storage."""

    def __init__(self):
        self.blobs = {}
        self.max_blob_bytes = 0

    def put(self, reference, text):
        assert hashlib.sha256(text.encode("utf-8")).hexdigest() == reference
        assert reference not in self.blobs or self.blobs[reference] == text
        self.blobs[reference] = text
        self.max_blob_bytes = max(self.max_blob_bytes, len(text.encode("utf-8")))

    def get(self, reference):
        return self.blobs[reference]


def context(count=12, *, scan_budget=BUDGET, unicode=False, targets=1, tables=1, oversized=False):
    names = [f"SOURCE_{index}" for index in range(count)]
    columns = [{"name": name, "data_type": "TEXT", "business_meaning":
                ("\u4e1a\u52a1\u6807\u8bc6" * 20 if unicode else "Business identifier") + str(index)}
               for index, name in enumerate(names)]
    payload = {"operation": "sttm.auto_map", "context": {
        "target_table": {"database": "D", "schema": "S", "table": "T"},
        "relation_graph": {"nodes": [{"relation_id": "source", "kind": "CTE", "alias": "src",
            "output_columns": columns, "column_semantics": columns}], "edges": []},
        "workspace_context": {"driving_relation_id": "source"},
        "learning_context": {"correction_history": [{"correction_id": "pinned-negative",
            "prevention_hint": "Never use contact identifiers"}]},
        "mapping_intent": {"guidance": "Preserve grain and negatives"}},
        "data": {"attributes": [{"target_attribute": f"TARGET_{index}", "target_data_type": "TEXT"}
                                for index in range(targets)]}}
    if tables > 1:
        nodes = [{"relation_id": f"source_{index}", "kind": "CTE", "alias": f"src_{index}",
                  "output_columns": columns[index::tables], "column_semantics": columns[index::tables]}
                 for index in range(tables)]
        payload["context"]["relation_graph"] = {"nodes": nodes, "edges": [
            {"left_relation_id": "source_0", "right_relation_id": node["relation_id"],
             "additional_predicate": "TRUE"} for node in nodes[1:]]}
        payload["context"]["workspace_context"]["driving_relation_id"] = "source_0"
    if oversized:
        nodes = payload["context"]["relation_graph"]["nodes"]
        nodes[-1]["column_semantics"][0]["business_meaning"] = "OVERSIZED_EXACT_BODY" * 2000
    return prepare_scan_context(AutoMapContext(payload), owner_id="trusted", budget=scan_budget)


def scan_for(prepared, *, roles=(CandidateRole.SOURCE,), duplicate=False):
    results = []
    cursor = None
    while True:
        page = prepared.registry.directory(scope=prepared.scope, cursor=cursor).payload
        for entry in page["entries"]:
            shard_id = entry["shard_id"]
            records = prepared.registry.read_shard(scope=prepared.scope, shard_id=shard_id).payload["records"]
            candidates = []
            for record in records:
                if record["kind"] == "source_column":
                    for role in roles:
                        candidate = ScanCandidate(record["record_id"], role, (record["record_id"],))
                        candidates.append(candidate)
                        if duplicate:
                            candidates.append(candidate)
                            candidates.append(replace(candidate, evidence_refs=tuple(item["record_id"] for item in records)))
            results.append(ShardScanResult(prepared.scope, prepared.registry.generation, shard_id,
                prepared.target_ids, ScanStatus.SUCCEEDED,
                tuple(TargetCandidates(target, tuple(candidates)) for target in prepared.target_ids), call_reserved=True))
        cursor = page["next_cursor"]
        if cursor is None:
            break
    shards = tuple(results)
    coverage = summarize_scan_coverage(registry=prepared.registry, target_ids=prepared.target_ids,
                                      shards=shards, expected_shards=len(shards))
    return ScanResult(prepared.scope, prepared.registry.generation, prepared.target_ids, shards, len(results), coverage)


def policy(**overrides):
    defaults = dict(candidate_cap=2, fan_in=5, input_budget=BUDGET, output_budget=BUDGET,
                    max_calls=500, deadline=time.monotonic() + 120)
    defaults.update(overrides)
    return ReductionPolicy(**defaults)


def job(prepared=None, scan=None, rules=None, archive=None):
    prepared = prepared or context()
    scan = scan or scan_for(prepared)
    return CandidateReduction(scan, prepared, scope=prepared.scope, archive=archive or Archive(),
                              policy=rules or policy())


def packet(reduction_round):
    messages = json.loads(reduction_round.request.message)
    assert messages == SnowflakeAgentClient._normalize_messages(messages)
    assert messages[0]["status"] == "completed"
    assert json.loads(_request_body(reduction_round.request))["messages"] == messages
    return json.loads(messages[0]["content"][0]["text"])


def response(reduction_round, selected=None, **overrides):
    body = {"generation": reduction_round.request.generation, "round_id": reduction_round.request.shard_id,
            "complete": True, "selected_ids": selected or [reduction_round.candidates[0].candidate_id],
            "mandatory_record_ids": list(reduction_round.mandatory_record_ids)}
    body.update(overrides)
    return json.dumps(body, ensure_ascii=False)


def finish(reduction, chooser=None):
    rounds = []
    while True:
        current = reduction.prepare_reduction_round()
        if current is None:
            return rounds
        rounds.append(current)
        prompt = packet(current)
        assert current.coverage.reduction_calls == len(rounds)
        assert prompt["coverage"]["reduction_calls"] == current.coverage.reduction_calls
        assert current.warnings == reduction.result.warnings
        selection = chooser(current) if chooser else [current.candidates[0].candidate_id]
        reduction.apply_reduction_result(current, response(current, selection))
        assert len(rounds) < 200


def test_tree_is_bounded_and_archive_contains_all_candidates_and_outputs():
    prepared = context(73)
    archive = Archive()
    reduction = job(prepared, archive=archive)
    before = tuple(reduction.iter_candidates(scope=prepared.scope))
    rounds = finish(reduction)
    for current in rounds:
        prompt = packet(current)
        owners = {record["record_id"]: record for record in
                  [*prompt["global_records"], *prompt["owner_records"]]}
        assert len(prompt["owner_records"]) == len({record["record_id"] for record in prompt["owner_records"]})
        for candidate in prompt["candidates"]:
            owner_id = candidate["record"]["body"].get("owner_ref")
            if owner_id:
                assert owners[owner_id]["kind"] in {"relation_semantics", "target_table_semantics"}
    assert len(before) == 73
    assert len(rounds) > 1 and max(item.level for item in rounds) > 0
    assert all(2 < len(item.candidates) <= 5 for item in rounds)
    assert all(len(item.request.message.encode("utf-8")) <= BUDGET.max_bytes for item in rounds)
    result = reduction.result
    assert result.coverage.scan_complete and result.coverage.reduction_complete
    assert result.coverage.pruned and not result.coverage.global_decision_complete
    assert result.coverage.retained_candidates <= 2
    assert result.coverage.initial_candidates == 73
    assert tuple(reduction.iter_candidates(scope=prepared.scope)) == before
    history = list(reduction._blobs.rows(result.history_archive_ref))
    assert len([row for row in history if row["event"] == "response"]) == len(rounds)
    assert all(json.loads(reduction._blobs.get(row["output_ref"]))["complete"]
               for row in history if row["event"] == "response")
    assert result.scan_archive_ref and result.candidate_archive_ref
    # No aggregate candidate/body list hidden behind the archive facade.
    assert len(reduction._next.levels) <= 7
    for text in archive.blobs.values():
        value = json.loads(text)["value"]
        if isinstance(value, dict) and "row" in value:
            assert isinstance(value["row"], dict)
    assert reduction.prepare_reduction_round() is None


def test_stable_input_order_and_lossless_merge_complementary_roles():
    prepared = context(9, targets=2)
    scan = scan_for(prepared, roles=(CandidateRole.SOURCE, CandidateRole.JOIN), duplicate=True)
    first = job(prepared, scan, policy(candidate_cap=4, fan_in=8))
    shuffled = []
    randomizer = random.Random(9)
    for shard in reversed(scan.shards):
        targets = []
        for target in reversed(shard.targets):
            candidates = list(target.candidates)
            randomizer.shuffle(candidates)
            targets.append(replace(target, candidates=tuple(candidates)))
        shuffled.append(replace(shard, targets=tuple(targets), target_ids=tuple(reversed(shard.target_ids))))
    second = job(prepared, replace(scan, shards=tuple(shuffled), target_ids=tuple(reversed(scan.target_ids))),
                 policy(candidate_cap=4, fan_in=8))
    left = tuple(first.iter_candidates(scope=prepared.scope))
    right = tuple(second.iter_candidates(scope=prepared.scope))
    assert left == right and len(left) == 36
    assert first.result.candidate_archive_ref == second.result.candidate_archive_ref
    assert {candidate.key.role for candidate in left} == {CandidateRole.SOURCE, CandidateRole.JOIN}
    for candidate in left:
        origins = list(first.iter_origins(candidate, scope=prepared.scope))
        assert len(origins) == candidate.origin_count == 2
        members = prepared.registry.read_shard(scope=prepared.scope, shard_id=origins[0]["shard_id"]).payload["records"]
        assert {len(origin["candidate"]["evidence_refs"]) for origin in origins} == {1, len(members)}
    assert first.prepare_reduction_round().request.message == second.prepare_reduction_round().request.message


@pytest.mark.parametrize("field", ["owner", "snapshot", "generation", "shard_owner", "shard_generation",
                                  "targets", "shard_targets", "foreign_record", "foreign_evidence"])
def test_scope_forgery_and_scan_membership_rejected(field):
    prepared = context()
    scan = scan_for(prepared)
    shard = scan.shards[0]
    if field == "owner":
        scan = replace(scan, scope=SnapshotScope("attacker", scan.scope.snapshot_id))
    elif field == "snapshot":
        scan = replace(scan, scope=SnapshotScope(scan.scope.owner_id, "old"))
    elif field == "generation":
        scan = replace(scan, generation="old")
    elif field == "shard_owner":
        shard = replace(shard, scope=SnapshotScope("attacker", scan.scope.snapshot_id))
    elif field == "shard_generation":
        shard = replace(shard, generation="old")
    elif field == "targets":
        scan = replace(scan, target_ids=("OTHER",))
    elif field == "shard_targets":
        shard = replace(shard, target_ids=("OTHER",))
    else:
        candidate = shard.targets[0].candidates[0]
        candidate = replace(candidate, **({"record_id": "outside"} if field == "foreign_record"
                                         else {"evidence_refs": ("outside",)}))
        shard = replace(shard, targets=(replace(shard.targets[0], candidates=(candidate,)),))
    scan = replace(scan, shards=(shard,) + scan.shards[1:])
    with pytest.raises(ValueError):
        job(prepared, scan)


@pytest.mark.parametrize("change", ["missing", "extra", "duplicate", "missing_target", "call_count"])
def test_complete_flag_cannot_substitute_exact_coverage(change):
    prepared = context()
    scan = scan_for(prepared)
    assert scan.complete
    if change == "missing":
        scan = replace(scan, shards=(), reserved_calls=0)
        assert not scan.complete  # Expected shard count prevents vacuous completeness.
    elif change == "extra":
        scan = replace(scan, shards=scan.shards + (replace(scan.shards[0], shard_id="foreign"),),
                       reserved_calls=scan.reserved_calls + 1)
    elif change == "duplicate":
        scan = replace(scan, shards=scan.shards * 2, reserved_calls=scan.reserved_calls * 2)
    elif change == "missing_target":
        scan = replace(scan, shards=(replace(scan.shards[0], targets=()),) + scan.shards[1:])
    else:
        scan = replace(scan, reserved_calls=0)
    with pytest.raises(ValueError):
        job(prepared, scan)


@pytest.mark.parametrize("status", [status for status in ScanStatus if status != ScanStatus.SUCCEEDED])
def test_shard_failures_are_archived_with_incomplete_empty_provisional_result(status):
    prepared = context()
    scan = scan_for(prepared)
    scan = replace(scan, shards=(replace(scan.shards[0], status=status, targets=(), error_code=status.value),)
                   + scan.shards[1:], coverage=None)
    reduction = job(prepared, scan)
    assert not reduction.result.coverage.scan_complete
    assert not reduction.result.coverage.reduction_complete
    assert not reduction.result.coverage.global_decision_complete
    assert reduction.prepare_reduction_round() is None
    assert reduction.result.coverage.reduction_complete
    assert not reduction.result.coverage.scan_complete
    assert not reduction.result.candidates
    assert reduction.result.warnings.entries[0].shard_id == scan.shards[0].shard_id
    assert reduction.result.scan_archive_ref


def test_failed_shard_must_not_smuggle_partial_candidates():
    prepared = context()
    scan = scan_for(prepared)
    scan = replace(scan, shards=(replace(scan.shards[0], status=ScanStatus.BACKEND_FAILED),))
    with pytest.raises(ValueError, match="Failed shard"):
        job(prepared, scan)


@pytest.mark.parametrize("change", ["foreign", "outside_batch", "record_id", "duplicate", "empty", "over_cap",
                                  "false", "numeric_true", "missing_complete", "generation", "round", "mapping",
                                  "confidence", "mandatory", "duplicate_json", "not_json", "nonfinite"])
def test_reducer_rejects_entire_invalid_output_without_eviction(change):
    prepared = context(20)
    reduction = job(prepared)
    before = tuple(reduction.iter_candidates(scope=prepared.scope))
    current = reduction.prepare_reduction_round()
    body = json.loads(response(current))
    if change == "foreign":
        body["selected_ids"] = ["invented"]
    elif change == "outside_batch":
        body["selected_ids"] = [next(candidate.candidate_id for candidate in before
            if candidate.candidate_id not in current.request.record_ids)]
    elif change == "record_id":
        body["selected_ids"] = [current.candidates[0].key.record_id]
    elif change == "duplicate":
        body["selected_ids"] *= 2
    elif change == "empty":
        body["selected_ids"] = []
    elif change == "over_cap":
        body["selected_ids"] = list(current.request.record_ids[:3])
    elif change in ("false", "numeric_true"):
        body["complete"] = False if change == "false" else 1
    elif change == "missing_complete":
        del body["complete"]
    elif change in ("generation", "round"):
        body["generation" if change == "generation" else "round_id"] = "foreign"
    elif change in ("mapping", "confidence"):
        body[change] = "never allowed"
    elif change == "mandatory":
        body["mandatory_record_ids"] = []
    raw = json.dumps(body)
    if change == "duplicate_json":
        raw = raw[:-1] + ',"complete":true}'
    elif change == "not_json":
        raw = "not JSON"
    elif change == "nonfinite":
        raw = raw.replace('"complete": true', '"complete": NaN')
    with pytest.raises(ValueError):
        reduction.apply_reduction_result(current, raw)
    assert tuple(reduction.iter_candidates(scope=prepared.scope)) == before
    assert not reduction.result.coverage.reduction_complete
    with pytest.raises(ReductionBlocked):
        reduction.prepare_reduction_round()
    history = list(reduction._blobs.rows(reduction.result.history_archive_ref))
    assert reduction._blobs.get(history[-1]["output_ref"]) == raw


def test_pinned_candidates_and_mandatory_negatives_cannot_be_evicted():
    prepared = context(10)
    scan = scan_for(prepared)
    base = job(prepared, scan)
    pin = next(base.iter_candidates(scope=prepared.scope)).key
    reduction = job(prepared, scan, policy(pinned=(pin,)))
    current = reduction.prepare_reduction_round()
    prompt = packet(current)
    assert "Never use contact identifiers" in json.dumps(prompt["global_records"])
    assert current.required_ids
    unpinned = next(candidate.candidate_id for candidate in current.candidates if candidate.key != pin)
    with pytest.raises(ValueError, match="Pinned"):
        reduction.apply_reduction_result(current, response(current, [unpinned]))
    reduction = job(prepared, scan, policy(pinned=(pin,)))
    finish(reduction, lambda current: list(current.required_ids) or [current.candidates[0].candidate_id])
    assert pin in {candidate.key for candidate in reduction.result.candidates}


def test_role_minima_retained_at_each_level_and_final_result():
    prepared = context(12, targets=2)
    scan = scan_for(prepared, roles=(CandidateRole.SOURCE, CandidateRole.JOIN, CandidateRole.FILTER))
    rules = policy(candidate_cap=6, fan_in=12, role_minima=tuple((role, 1) for role in
                   (CandidateRole.SOURCE, CandidateRole.JOIN, CandidateRole.FILTER)))
    reduction = job(prepared, scan, rules)

    def choose(current):
        selected = {}
        for candidate in current.candidates:
            selected.setdefault((candidate.key.target_id, candidate.key.role), candidate.candidate_id)
        return list(selected.values())

    rounds = finish(reduction, choose)
    assert len(rounds) > 1
    assert len(reduction.result.candidates) == 6
    assert {(candidate.key.target_id, candidate.key.role) for candidate in reduction.result.candidates} == {
        (target, role) for target in prepared.target_ids for role in
        (CandidateRole.SOURCE, CandidateRole.JOIN, CandidateRole.FILTER)}
    reduction = job(prepared, scan, rules)
    current = reduction.prepare_reduction_round()
    with pytest.raises(ValueError, match="role"):
        reduction.apply_reduction_result(current, response(current, [current.candidates[0].candidate_id]))


def test_impossible_pins_or_role_budget_rejected_before_selection():
    prepared = context(4)
    scan = scan_for(prepared)
    keys = tuple(candidate.key for candidate in job(prepared, scan).iter_candidates(scope=prepared.scope))
    with pytest.raises(ReductionBlocked, match="exceed"):
        job(prepared, scan, policy(pinned=keys))
    with pytest.raises(ValueError, match="absent"):
        job(prepared, scan, policy(pinned=(CandidateKey(prepared.target_ids[0], CandidateRole.SOURCE, "unknown"),)))
    scan = scan_for(prepared, roles=(CandidateRole.SOURCE, CandidateRole.JOIN, CandidateRole.FILTER))
    with pytest.raises(ReductionBlocked):
        job(prepared, scan, policy(role_minima=tuple((role, 1) for role in
            (CandidateRole.SOURCE, CandidateRole.JOIN, CandidateRole.FILTER))))


def test_normalized_full_message_schema_and_utf8_bounds():
    jsonschema = pytest.importorskip("jsonschema")
    prepared = context(15, unicode=True)
    reduction = job(prepared)
    current = reduction.prepare_reduction_round()
    prompt = packet(current)
    jsonschema.Draft202012Validator.check_schema(prompt["response_schema"])
    jsonschema.validate(json.loads(response(current)), prompt["response_schema"])
    text = current.request.message
    assert len(text.encode("utf-8")) > len(text)
    # A byte cap at the complete 3-candidate envelope splits fan-in, not evidence.
    candidates = tuple(reduction.iter_candidates(scope=prepared.scope))
    three, _ = reduction._message(candidates[:3])
    byte_cap = three.byte_count + 100
    limited = job(prepared, rules=policy(input_budget=MessageBudget(200_000, byte_cap)))
    rounds = finish(limited)
    assert all(len(item.candidates) == 3 for item in rounds)
    assert all(len(item.request.message.encode("utf-8")) <= byte_cap for item in rounds)
    too_small = job(prepared, rules=policy(input_budget=MessageBudget(200_000, three.char_count)))
    with pytest.raises(MessageBudgetError):
        too_small.prepare_reduction_round()
    assert len(tuple(too_small.iter_candidates(scope=prepared.scope))) == 15


def test_output_utf8_limit_checks_raw_bytes_and_keeps_rejected_text():
    prepared = context()
    probe = job(prepared)
    current = probe.prepare_reduction_round()
    # Legal JSON whitespace is ASCII; Unicode in a string tests raw-byte limiting
    # before semantic checks, without needing Unicode opaque hash identifiers.
    raw = response(current)[:-1] + ',"extra":"' + '\u4e1a' * 100 + '"}'
    reduction = job(prepared, rules=policy(output_budget=MessageBudget(10_000, len(raw))))
    current = reduction.prepare_reduction_round()
    with pytest.raises(ValueError, match="output budget"):
        reduction.apply_reduction_result(current, raw)
    history = list(reduction._blobs.rows(reduction.result.history_archive_ref))
    assert reduction._blobs.get(history[-1]["output_ref"]) == raw


def test_budget_includes_scan_reservations_pending_attempt_and_failures():
    prepared = context()
    scan = scan_for(prepared)
    reduction = job(prepared, scan, policy(max_calls=scan.reserved_calls))
    with pytest.raises(ReductionBlocked, match="call budget"):
        reduction.prepare_reduction_round()
    assert reduction.result.coverage.reduction_calls == 0
    reduction = job(prepared, scan, policy(max_calls=scan.reserved_calls + 1))
    current = reduction.prepare_reduction_round()
    with pytest.raises(ReductionBlocked, match="pending"):
        reduction.prepare_reduction_round()
    assert reduction.result.coverage.reduction_calls == 1
    reduction.apply_reduction_result(current, response(current))
    with pytest.raises(ReductionBlocked, match="call budget"):
        reduction.prepare_reduction_round()


def test_deadline_preparation_and_late_output_do_not_complete(monkeypatch):
    prepared = context()
    clock = [100.0]
    monkeypatch.setattr("app.core.automap_reduce.time.monotonic", lambda: clock[0])
    with pytest.raises(ReductionBlocked, match="deadline"):
        job(prepared, rules=policy(deadline=99))
    reduction = job(prepared, rules=policy(deadline=101))
    current = reduction.prepare_reduction_round()
    clock[0] = 102
    with pytest.raises(ReductionBlocked, match="deadline"):
        reduction.apply_reduction_result(current, response(current))
    assert not reduction.result.coverage.reduction_complete
    assert any(row["event"] == "response" for row in reduction._blobs.rows(reduction.result.history_archive_ref))


def test_late_winner_from_another_shard_is_not_prefix_truncated():
    prepared = context(30, tables=6, scan_budget=MessageBudget(12_000, 12_000))
    scan = scan_for(prepared)
    assert len(scan.shards) > 1
    assert prepared.complete_coverage and scan.complete
    reduction = job(prepared, scan)
    candidates = tuple(reduction.iter_candidates(scope=prepared.scope))
    winner = candidates[-1]
    first_shard = next(reduction.iter_origins(candidates[0], scope=prepared.scope))["shard_id"]
    winner_shard = next(reduction.iter_origins(winner, scope=prepared.scope))["shard_id"]
    if winner_shard == first_shard:
        winner = next(candidate for candidate in reversed(candidates)
                      if next(reduction.iter_origins(candidate, scope=prepared.scope))["shard_id"] != first_shard)
    seen = set()

    def choose(current):
        seen.update(current.request.record_ids)
        return [winner.candidate_id] if winner.candidate_id in current.request.record_ids else [current.candidates[0].candidate_id]

    finish(reduction, choose)
    assert seen == {candidate.candidate_id for candidate in candidates}
    assert winner in reduction.result.candidates
    assert not reduction.result.coverage.global_decision_complete


def test_small_and_empty_inputs_need_no_reducer_calls_and_stay_provisional():
    prepared = context(1)
    reduction = job(prepared)
    assert reduction.prepare_reduction_round() is None
    assert len(reduction.result.candidates) == 1
    assert reduction.result.coverage.reduction_calls == 0
    assert not reduction.result.coverage.global_decision_complete
    scan = scan_for(prepared)
    scan = replace(scan, shards=tuple(replace(shard, targets=tuple(replace(target, candidates=())
        for target in shard.targets)) for shard in scan.shards))
    empty = job(prepared, scan)
    assert empty.prepare_reduction_round() is None
    assert empty.result.coverage.scan_complete and empty.result.coverage.reduction_complete
    assert not empty.result.candidates and not empty.result.coverage.global_decision_complete


def test_scope_checks_archive_tampering_and_immutable_inputs():
    prepared = context()
    scan = scan_for(prepared)
    archive = Archive()
    reduction = job(prepared, scan, archive=archive)
    original = tuple(reduction.iter_candidates(scope=prepared.scope))
    with pytest.raises(ScopeMismatchError):
        tuple(reduction.iter_candidates(scope=SnapshotScope("other", "snapshot")))
    with pytest.raises(FrozenInstanceError):
        original[0].origin_count = 0
    with pytest.raises(FrozenInstanceError):
        scan.generation = "changed"
    root = reduction.result.candidate_archive_ref
    archive.blobs[root] += " "
    with pytest.raises(ScopeMismatchError, match="changed"):
        tuple(reduction.iter_candidates(scope=prepared.scope))


def test_prepared_globals_cannot_be_forged_or_removed():
    prepared = context()
    scan = scan_for(prepared)
    with pytest.raises(ScopeMismatchError):
        job(replace(prepared, global_records=prepared.global_records[:-1]), scan)
    with pytest.raises(ScopeMismatchError):
        job(replace(prepared, context_id="forged"), scan)
    foreign = ContextRecord(scope=SnapshotScope("other", "snapshot"), record_id="x", kind="mandatory", body={})
    with pytest.raises(ScopeMismatchError):
        job(replace(prepared, global_records=(foreign,)), scan)


def test_replay_and_foreign_round_rejected():
    reduction = job()
    current = reduction.prepare_reduction_round()
    with pytest.raises(ReductionBlocked, match="Foreign"):
        reduction.apply_reduction_result(replace(current, level=99), response(current))
    reduction.apply_reduction_result(current, response(current))
    with pytest.raises(ReductionBlocked, match="already"):
        reduction.apply_reduction_result(current, response(current))


def test_reordered_shards_produce_identical_tree_and_finalists():
    prepared = context(30, tables=6, scan_budget=MessageBudget(12_000, 12_000))
    scan = scan_for(prepared)
    assert len(scan.shards) > 1
    assert prepared.complete_coverage and scan.complete
    left = job(prepared, scan)
    right = job(prepared, replace(scan, shards=tuple(reversed(scan.shards))))
    left_rounds, right_rounds = finish(left), finish(right)
    assert [current.request.message for current in left_rounds] == [current.request.message for current in right_rounds]
    assert left.result == right.result


def test_scan_archive_retains_exact_evidence_bodies_for_recovery():
    prepared = context(8)
    reduction = job(prepared, scan_for(prepared, duplicate=True))
    archived = {}
    for shard in reduction._blobs.rows(reduction.result.scan_archive_ref):
        for record in reduction._blobs.rows(shard["records_ref"]):
            archived[record["record_id"]] = record
    assert archived == {record.record_id: record._payload() for record in prepared.records}
    for candidate in reduction.iter_candidates(scope=prepared.scope):
        for origin in reduction.iter_origins(candidate, scope=prepared.scope):
            assert set(origin["candidate"]["evidence_refs"]) <= archived.keys()


def test_no_model_or_network_execution_entrypoint_and_explicit_archive_required():
    import inspect
    prepared = context(1)
    with pytest.raises(TypeError, match="archive"):
        CandidateReduction(scan_for(prepared), prepared, scope=prepared.scope, archive=None, policy=policy())
    assert "backend" not in inspect.signature(CandidateReduction).parameters
    assert "admission" not in inspect.signature(CandidateReduction).parameters
    with pytest.raises(ReductionBlocked, match="already exceed"):
        job(prepared, rules=policy(max_calls=0))


def test_archive_failure_after_iterator_advance_blocks_retry(monkeypatch):
    reduction = job()
    original = reduction._blobs.get
    calls = [0]

    def broken(reference):
        calls[0] += 1
        if calls[0] == 5:
            raise OSError("archive temporarily unavailable")
        return original(reference)

    monkeypatch.setattr(reduction._blobs, "get", broken)
    with pytest.raises(OSError):
        reduction.prepare_reduction_round()
    monkeypatch.setattr(reduction._blobs, "get", original)
    with pytest.raises(ReductionBlocked, match="preparation failed"):
        reduction.prepare_reduction_round()
    assert len(tuple(reduction.iter_candidates(scope=reduction.scope))) == 12
    assert not reduction.result.coverage.reduction_complete


def test_archive_write_failure_during_apply_never_accepts_partial_round(monkeypatch):
    reduction = job()
    current = reduction.prepare_reduction_round()
    original = reduction._blobs.put

    def broken(value):
        raise OSError("archive temporarily unavailable")

    monkeypatch.setattr(reduction._blobs, "put", broken)
    with pytest.raises(OSError):
        reduction.apply_reduction_result(current, response(current))
    monkeypatch.setattr(reduction._blobs, "put", original)
    with pytest.raises(ReductionBlocked):
        reduction.prepare_reduction_round()
    assert not reduction.result.coverage.reduction_complete


def test_noneligible_lineage_cannot_be_promoted_to_source():
    prepared = context()
    scan = scan_for(prepared)
    shard = scan.shards[0]
    records = prepared.registry.read_shard(scope=prepared.scope, shard_id=shard.shard_id).payload["records"]
    record = next(record for record in records if record["kind"] != "source_column")
    forged = ScanCandidate(record["record_id"], CandidateRole.SOURCE, (record["record_id"],))
    scan = replace(scan, shards=(replace(shard, targets=(replace(shard.targets[0], candidates=(forged,)),)),))
    with pytest.raises(ValueError, match="eligible source"):
        job(prepared, scan)


def test_successful_other_shards_do_not_hide_one_failed_shard():
    prepared = context(30, tables=6, scan_budget=MessageBudget(12_000, 12_000))
    scan = scan_for(prepared)
    assert len(scan.shards) > 1
    assert prepared.complete_coverage and scan.complete
    shard = replace(scan.shards[-1], status=ScanStatus.TIMED_OUT, targets=(), error_code="timed_out")
    reduction = job(prepared, replace(scan, shards=scan.shards[:-1] + (shard,), coverage=None))
    assert tuple(reduction.iter_candidates(scope=prepared.scope))
    assert reduction.result.coverage.succeeded_shards == len(scan.shards) - 1
    rounds = finish(reduction)
    assert rounds
    assert reduction.result.candidates
    assert reduction.result.coverage.reduction_complete
    assert not reduction.result.coverage.scan_complete
    assert not reduction.result.coverage.global_decision_complete
    for current in rounds:
        assert not current.coverage.scan_complete
        assert current.warnings.entries[0].shard_id == shard.shard_id
        assert packet(current)["warnings"]["entries"][0]["shard_id"] == shard.shard_id


def test_schema_enforces_pins_roles_mandatory_and_complete():
    import jsonschema
    prepared = context(5)
    scan = scan_for(prepared, roles=(CandidateRole.SOURCE, CandidateRole.JOIN))
    pin = next(job(prepared, scan).iter_candidates(scope=prepared.scope)).key
    reduction = job(prepared, scan, policy(candidate_cap=3, fan_in=8, pinned=(pin,),
                    role_minima=((CandidateRole.SOURCE, 1), (CandidateRole.JOIN, 1))))
    current = reduction.prepare_reduction_round()
    schema = packet(current)["response_schema"]
    jsonschema.Draft202012Validator.check_schema(schema)
    selected = set(current.required_ids)
    for role in (CandidateRole.SOURCE, CandidateRole.JOIN):
        selected.add(next(candidate.candidate_id for candidate in current.candidates if candidate.key.role == role))
    body = json.loads(response(current, sorted(selected)))
    jsonschema.validate(body, schema)
    reduction.apply_reduction_result(current, json.dumps(body))
    for key, value in (("complete", False), ("mandatory_record_ids", []), ("selected_ids", ["foreign"])):
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate({**body, key: value}, schema)


def test_small_result_deadline_checked_after_archive_read(monkeypatch):
    prepared = context(1)
    clock = [100.0]
    monkeypatch.setattr("app.core.automap_reduce.time.monotonic", lambda: clock[0])
    reduction = job(prepared, rules=policy(deadline=101))
    original = reduction._blobs.get

    def delayed(reference):
        value = original(reference)
        clock[0] = 102
        return value

    monkeypatch.setattr(reduction._blobs, "get", delayed)
    with pytest.raises(ReductionBlocked, match="deadline"):
        reduction.prepare_reduction_round()
    assert not reduction.result.coverage.reduction_complete


@contextmanager
def mock_admission(request):
    request.check_active()
    yield True


def mock_scan(prepared, *, failed_shard=None, empty=False):
    calls = []

    def backend(request):
        calls.append(request)
        assert "OVERSIZED_EXACT_BODY" not in request.message
        if request.shard_id == failed_shard:
            raise RuntimeError("PRIVATE_BACKEND_BODY")
        return json.dumps({"generation": request.generation, "shard_id": request.shard_id,
            "targets": [{"target_id": target, "candidates": [] if empty else [
                {"record_id": identity, "role": "source", "evidence_refs": [identity]}
                for identity in request.eligible_source_record_ids]} for target in request.target_ids]})

    scan = scan_registry(registry=prepared.registry, scope=prepared.scope, target_ids=prepared.target_ids,
                         backend=backend, admission=mock_admission, max_workers=2, max_calls=100,
                         total_seconds=10, output_budget=BUDGET)
    return scan, calls


def test_two_good_tables_one_oversized_mock_scan_reduce_preserves_warnings_every_round():
    prepared = context(18, tables=3, oversized=True, scan_budget=MessageBudget(14_000, 14_000))
    assert prepared.blocked_table_ids == ("source_2",)
    scan, calls = mock_scan(prepared)
    assert calls and not scan.complete
    assert all(shard.status == ScanStatus.SUCCEEDED for shard in scan.shards)
    assert scan.coverage.blocked_table_ids == prepared.blocked_table_ids
    assert scan.coverage.incomplete_target_ids == prepared.incomplete_target_ids
    warning, = scan.warnings
    expected, = prepared.warnings
    assert warning.group_id == expected.group_id
    assert warning.scope_hash == expected.scope_hash
    assert warning.affected_target_ids == expected.affected_target_ids
    reduction = job(prepared, scan, policy(candidate_cap=1, fan_in=3))
    initial = tuple(reduction.iter_candidates(scope=prepared.scope))
    assert len(initial) == 12
    blocked_records = set(prepared.registry.excluded_groups[0].record_ids)
    assert not blocked_records.intersection(candidate.key.record_id for candidate in initial)
    rounds = finish(reduction)
    assert len(rounds) > 1 and max(current.level for current in rounds) > 0
    for current in rounds:
        prompt = packet(current)
        assert not current.coverage.scan_complete and not current.coverage.plan_complete
        assert not current.coverage.global_decision_complete
        assert current.warnings.entries == (warning,)
        assert prompt["warnings"]["entries"][0]["group_id"] == expected.group_id
        assert prompt["warnings"]["entries"][0]["table_id"] == expected.table_id
        assert not prompt["coverage"]["scan_complete"]
        assert not prompt["coverage"]["global_decision_complete"]
        assert "NOT exhaustive absence" in prompt["instructions"]
        assert "OVERSIZED_EXACT_BODY" not in current.request.message
        assert len(current.request.message.encode("utf-8")) <= BUDGET.max_bytes
    result = reduction.result
    assert len(result.candidates) == 1 and result.coverage.reduction_complete
    assert not result.coverage.scan_complete and not result.coverage.global_decision_complete
    assert result.coverage.excluded_group_count == 1
    assert result.coverage.incomplete_target_ids == prepared.target_ids
    assert result.warnings.entries == (warning,)
    assert tuple(reduction.iter_warnings(scope=prepared.scope)) == scan.warnings
    assert "OVERSIZED_EXACT_BODY" not in repr(result)


def test_all_oversized_mock_scan_no_calls_empty_reduction_is_not_exhaustive_absence():
    prepared = context(10, oversized=True, scan_budget=MessageBudget(12_000, 12_000))
    # The target inventory is also a whole group. Block its local lineage too,
    # without inflating or weakening the mandatory global target capsule.
    target_lineage = ContextRecord(scope=prepared.scope, record_id="target-lineage", kind="lineage",
                                   body={"exact": "OVERSIZED_EXACT_BODY" * 2000})
    records = prepared.records + (target_lineage,)
    groups = dict(prepared.registry.atomic_groups)
    groups["table:D.S.T"] += (target_lineage.record_id,)
    registry = type(prepared.registry)(scope=prepared.scope, records=records,
        budget=prepared.registry.budget, message_builder=prepared.registry._builder,
        atomic_groups=groups, skip_oversized_groups=True)
    prepared = replace(prepared, records=records, registry=registry)
    assert not prepared.complete_coverage
    scan, calls = mock_scan(prepared)
    assert calls == [] and scan.shards == () and scan.reserved_calls == 0
    assert not scan.complete
    reduction = job(prepared, scan, policy(max_calls=0))
    assert reduction.prepare_reduction_round() is None
    result = reduction.result
    assert result.candidates == () and result.coverage.reduction_calls == 0
    assert result.coverage.reduction_complete and not result.coverage.scan_complete
    assert not result.coverage.global_decision_complete
    assert result.coverage.expected_shards == result.coverage.succeeded_shards == 0
    assert result.warnings.total_count == 2
    assert {warning.table_id for warning in result.warnings.entries} == {"source", "D.S.T"}


@pytest.mark.parametrize("empty", [False, True])
def test_mock_partial_failed_scan_reduces_only_safe_candidates_without_authority(empty):
    prepared = context(30, tables=6, scan_budget=MessageBudget(12_000, 12_000))
    first = prepared.registry.directory(scope=prepared.scope).payload["entries"][0]["shard_id"]
    scan, calls = mock_scan(prepared, failed_shard=first, empty=empty)
    assert len(calls) > 1 and not scan.complete
    reduction = job(prepared, scan)
    safe = {candidate.key for candidate in reduction.iter_candidates(scope=prepared.scope)}
    rounds = finish(reduction)
    assert bool(rounds) is not empty
    assert {candidate.key for candidate in reduction.result.candidates} <= safe
    assert bool(reduction.result.candidates) is not empty
    assert reduction.result.coverage.reduction_complete
    assert not reduction.result.coverage.scan_complete
    assert not reduction.result.coverage.global_decision_complete
    assert reduction.result.warnings.entries[0].shard_id == first
    assert "PRIVATE_BACKEND_BODY" not in repr(reduction.result)
    for current in rounds:
        assert packet(current)["warnings"]["entries"][0]["shard_id"] == first
        assert not current.coverage.scan_complete


@pytest.mark.parametrize("change", ["missing", "unknown", "blocked_as_shard", "blocked_candidate", "blocked_evidence",
                                    "warnings", "complete"])
def test_declared_blocked_group_does_not_excuse_invalid_membership_or_metadata(change):
    prepared = context(18, tables=3, oversized=True, scan_budget=MessageBudget(14_000, 14_000))
    scan, _ = mock_scan(prepared)
    blocked = prepared.registry.excluded_groups[0]
    if change == "missing":
        scan = replace(scan, shards=scan.shards[1:], reserved_calls=scan.reserved_calls - 1, coverage=None)
    elif change in ("unknown", "blocked_as_shard"):
        forged = replace(scan.shards[0], shard_id="unknown" if change == "unknown" else blocked.group_id)
        scan = replace(scan, shards=scan.shards + (forged,), reserved_calls=scan.reserved_calls + 1, coverage=None)
    elif change in ("blocked_candidate", "blocked_evidence"):
        shard = scan.shards[0]
        target = shard.targets[0]
        candidate = target.candidates[0]
        candidate = replace(candidate, **({"record_id": blocked.record_ids[0]} if change == "blocked_candidate"
                            else {"evidence_refs": (blocked.record_ids[0],)}))
        shard = replace(shard, targets=(replace(target, candidates=(candidate,)),))
        scan = replace(scan, shards=(shard,) + scan.shards[1:])
    elif change == "warnings":
        scan = replace(scan, coverage=replace(scan.coverage, warnings=()))
    else:
        scan = replace(scan, coverage=replace(scan.coverage, plan_complete=True))
    with pytest.raises(ValueError):
        job(prepared, scan)


def test_unreadable_failed_shard_does_not_block_other_validated_proposals(monkeypatch):
    prepared = context(30, tables=6, scan_budget=MessageBudget(12_000, 12_000))
    failed = prepared.registry.directory(scope=prepared.scope).payload["entries"][0]["shard_id"]
    registry_type = type(prepared.registry)
    original = registry_type.read_shard

    def read(registry, *, scope, shard_id, member_ids=None):
        if shard_id == failed:
            raise OSError("UNREADABLE_PRIVATE_BODY")
        return original(registry, scope=scope, shard_id=shard_id, member_ids=member_ids)

    monkeypatch.setattr(registry_type, "read_shard", read)
    scan, calls = mock_scan(prepared)
    assert calls and scan.shards[0].status == ScanStatus.READ_FAILED
    reduction = job(prepared, scan)
    finish(reduction)
    assert reduction.result.candidates and reduction.result.coverage.reduction_complete
    assert not reduction.result.coverage.scan_complete
    warning, = reduction.result.warnings.entries
    assert warning.shard_id == failed and warning.error_code == "read_failed"
    failed_archive = next(row for row in reduction._blobs.rows(reduction.result.scan_archive_ref)
                          if row["shard_id"] == failed)
    assert failed_archive["records_ref"] is None


def test_warning_envelope_counts_toward_complete_message_budget_without_eviction():
    prepared = context(18, tables=3, oversized=True, scan_budget=MessageBudget(14_000, 14_000))
    scan, _ = mock_scan(prepared)
    probe = job(prepared, scan)
    candidates = tuple(probe.iter_candidates(scope=prepared.scope))
    message, _ = probe._message(candidates[:3])
    baseline_rounds = finish(probe)
    cap = MessageBudget(max(len(current.request.message) for current in baseline_rounds),
                        max(len(current.request.message.encode("utf-8")) for current in baseline_rounds))
    reduction = job(prepared, scan, policy(input_budget=cap))
    rounds = finish(reduction)
    assert rounds
    for current in rounds:
        assert len(current.request.message) <= cap.max_chars
        assert len(current.request.message.encode("utf-8")) <= cap.max_bytes
        assert current.warnings.entries == scan.warnings
    too_small = job(prepared, scan, policy(input_budget=MessageBudget(message.char_count - 1, message.byte_count - 1)))
    with pytest.raises(MessageBudgetError):
        too_small.prepare_reduction_round()
    assert too_small.result.warnings.entries == scan.warnings
    assert len(tuple(too_small.iter_candidates(scope=prepared.scope))) == 12


def test_legacy_partial_envelope_reconstructs_blocked_warning_from_trusted_registry():
    prepared = context(18, tables=3, oversized=True, scan_budget=MessageBudget(14_000, 14_000))
    scan, _ = mock_scan(prepared)
    reduction = job(prepared, replace(scan, coverage=None))
    finish(reduction)
    assert not reduction.result.coverage.scan_complete
    assert reduction.result.warnings.entries == scan.warnings


def test_many_warning_source_ids_are_bounded_and_losslessly_archived():
    prepared = context(4)
    records = list(prepared.records)
    groups = dict(prepared.registry.atomic_groups)
    for index in range(80):
        record = ContextRecord(scope=prepared.scope, record_id=f"blocked-{index}", kind="lineage",
                               body={"exact": "OVERSIZED_EXACT_BODY" * 1000})
        records.append(record)
        groups[f"table:blocked-{index}"] = (record.record_id,)
    registry = type(prepared.registry)(scope=prepared.scope, records=records,
        budget=MessageBudget(12_000, 12_000), message_builder=prepared.registry._builder,
        atomic_groups=groups, skip_oversized_groups=True)
    prepared = replace(prepared, records=tuple(records), registry=registry)
    scan, _ = mock_scan(prepared)
    assert len(scan.warnings) == 80
    reduction = job(prepared, scan)
    rounds = finish(reduction)
    assert rounds
    result = reduction.result
    warnings = result.warnings
    assert warnings.total_count == 80
    assert 0 < len(warnings.entries) <= 16
    assert warnings.omitted_count == 80 - len(warnings.entries)
    assert sum(len(json.dumps(asdict(entry), ensure_ascii=False, sort_keys=True,
                             separators=(",", ":")).encode("utf-8")) for entry in warnings.entries) <= 4096
    assert tuple(reduction.iter_warnings(scope=prepared.scope)) == scan.warnings
    assert {warning.source_id for warning in reduction.iter_warnings(scope=prepared.scope)} == {
        f"table:blocked-{index}" for index in range(80)}
    with pytest.raises(ScopeMismatchError):
        tuple(reduction.iter_warnings(scope=SnapshotScope("foreign", "snapshot")))
    for current in rounds:
        prompt = packet(current)
        assert prompt["warnings"]["archive_ref"] == warnings.archive_ref
        assert prompt["warnings"]["omitted_count"] == warnings.omitted_count
        assert "OVERSIZED_EXACT_BODY" not in current.request.message


@pytest.mark.parametrize("overrides", [{"candidate_cap": 0}, {"candidate_cap": True}, {"fan_in": 2},
    {"fan_in": 0}, {"max_calls": -1}, {"max_calls": True}, {"deadline": float("inf")},
    {"pinned": []}, {"role_minima": ((CandidateRole.SOURCE, -1),)},
    {"role_minima": ((CandidateRole.SOURCE, 1), (CandidateRole.SOURCE, 2))}])
def test_invalid_policy_rejected(overrides):
    with pytest.raises((ValueError, TypeError)):
        policy(**overrides)
