from __future__ import annotations

import importlib.util
from pathlib import Path

import yaml

from app.core.config import Settings


REPO_ROOT = Path(__file__).resolve().parents[5]
BOOTSTRAP_PATH = REPO_ROOT / "scripts/bootstrap_sttm_metadata_infra.py"


def _load_bootstrap_module():
    spec = importlib.util.spec_from_file_location("bootstrap_sttm_metadata_infra", BOOTSTRAP_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_semantic_v2_assets_render_for_client_namespace() -> None:
    bootstrap = _load_bootstrap_module()
    rendered_assets: list[str] = []

    for path in bootstrap.SEMANTIC_V2_SQL_FILES:
        rendered_assets.append(
            bootstrap.render_sql(
                path.read_text(encoding="utf-8-sig"),
                "CLIENT_DB.CLIENT_SEMANTIC",
                warehouse="CLIENT_WH",
                database="CLIENT_DB",
                semantic_namespace="CLIENT_DB.CLIENT_SEMANTIC",
            )
        )

    rendered = "\n".join(rendered_assets)
    assert rendered.upper().count("CREATE OR REPLACE PROCEDURE") == 16
    assert "CLIENT_DB.CLIENT_SEMANTIC" in rendered
    assert "CLIENT_WH" in rendered
    for forbidden in ("__STTM_", "__WAREHOUSE_", "FOCUS_DB_2", "STTM_MCP", "AIA_WH"):
        assert forbidden not in rendered


def test_semantic_v2_agent_matches_verified_tool_contract() -> None:
    bootstrap = _load_bootstrap_module()
    _agent_name, path = bootstrap.SEMANTIC_V2_AGENT_SPEC
    rendered = bootstrap.render_sql(
        path.read_text(encoding="utf-8-sig"),
        "CLIENT_DB.CLIENT_SEMANTIC",
        warehouse="CLIENT_WH",
    )
    agent_spec = yaml.safe_load(rendered)
    tools = {
        item["tool_spec"]["name"]
        for item in agent_spec["tools"]
    }

    assert tools == bootstrap.SEMANTIC_V2_AGENT_TOOLS
    assert set(agent_spec["tool_resources"]) == tools
    for resource in agent_spec["tool_resources"].values():
        assert resource["execution_environment"]["warehouse"] == "CLIENT_WH"
        assert resource["identifier"].startswith("CLIENT_DB.CLIENT_SEMANTIC.")


def test_legacy_semantic_agent_is_not_in_bootstrap_registry() -> None:
    bootstrap = _load_bootstrap_module()
    agent_names = {name for name, _path in bootstrap.AGENT_SPECS}

    assert "AGT_SEMANTIC_MODEL" not in agent_names
    assert bootstrap.SEMANTIC_V2_AGENT_SPEC[0] == "AGT_SEMANTIC_MODEL_V2"


def test_semantic_subagent_routes_to_v2_in_semantic_namespace() -> None:
    bootstrap = _load_bootstrap_module()
    path = REPO_ROOT / "infra/snowflake/agentic_tools/sp-subagent-semantic-model.sql"
    rendered = bootstrap.render_sql(
        path.read_text(encoding="utf-8-sig"),
        "CLIENT_DB.WORKBENCH",
        semantic_namespace="CLIENT_DB.CLIENT_SEMANTIC",
    )

    assert "/schemas/{semantic_schema}/agents/AGT_SEMANTIC_MODEL_V2:run" in rendered
    assert '"CLIENT_DB.CLIENT_SEMANTIC".split' in rendered
    assert "agents/AGT_SEMANTIC_MODEL:run" not in rendered


def test_app_defaults_to_v2_in_configured_semantic_namespace() -> None:
    settings = Settings(
        _env_file=None,
        SNOWFLAKE_DATABASE="CLIENT_DB",
        SNOWFLAKE_SCHEMA="WORKBENCH",
        SNOWFLAKE_SEMANTIC_VIEWS_DATABASE="CLIENT_DB",
        SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA="CLIENT_SEMANTIC",
        SNOWFLAKE_SEMANTIC_MODEL_AGENT="",
    )

    assert (
        settings.resolved_semantic_model_agent
        == "CLIENT_DB.CLIENT_SEMANTIC.AGT_SEMANTIC_MODEL_V2"
    )
