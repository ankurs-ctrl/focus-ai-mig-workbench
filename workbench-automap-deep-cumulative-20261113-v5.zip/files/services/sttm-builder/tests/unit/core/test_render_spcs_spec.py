from scripts.render_spcs_spec import render_template


TEMPLATE = """spec:
  containers:
    - name: backend
    # BEGIN COCO_SIDECAR
    - name: coco-agent
      image: ${IMAGE}
    # END COCO_SIDECAR
    - name: frontend
      image: ${IMAGE}
"""


def test_publication_worker_is_explicit_and_has_no_caller_secrets():
    import yaml
    template = """spec:
  containers:
    - name: sttm-builder
      image: backend:release
      env:
        SNOWFLAKE_DATABASE: UAT
        SNOWFLAKE_SCHEMA: METADATA
        SNOWFLAKE_OAUTH_CLIENT_SECRET: never-copy
"""
    assert len(yaml.safe_load(render_template(template, {}))["spec"]["containers"]) == 1
    spec = yaml.safe_load(render_template(template, {"PUBLICATION_RECOVERY_ENABLED": "true",
                                                   "PUBLICATION_RECOVERY_ROLE": "APPROVED"}))
    worker = spec["spec"]["containers"][1]
    assert worker["name"] == "publication-recovery"
    assert worker["command"] == ["/app/.venv/bin/python"]
    assert worker["args"][:2] == ["-m", "app.core.publication_recovery"]
    assert "--all-projects" in worker["args"]
    assert "SNOWFLAKE_OAUTH_CLIENT_SECRET" not in worker["env"]
    assert worker["image"] == "backend:release"


def test_coco_sidecar_is_removed_by_default():
    rendered = render_template(TEMPLATE, {"IMAGE": "workbench:latest"})

    assert "coco-agent" not in rendered
    assert "frontend" in rendered


def test_coco_sidecar_can_be_restored_explicitly():
    rendered = render_template(
        TEMPLATE,
        {"IMAGE": "workbench:latest", "COCO_SIDECAR_ENABLED": "true"},
    )

    assert "coco-agent" in rendered
    assert "BEGIN COCO_SIDECAR" not in rendered


def test_deep_settings_come_from_client_env_without_copying_credentials(tmp_path):
    import yaml
    from scripts.render_spcs_spec import deep_runtime_environment
    path=tmp_path/'client.env'
    path.write_text('MIGRATION_AGENT_ENABLED=true\nMIGRATION_AGENT_MODEL_LIGHT="available-model"\n'
        'MIGRATION_AGENT_CAPACITY_LIMITS=\'{"account:{account}":1}\'\n'
        'SNOWFLAKE_PASSWORD=must-not-copy\nAUTH_SESSION_ENCRYPTION_KEY=must-not-copy\n')
    environment=deep_runtime_environment({'MIGRATION_AGENT_ENABLED':'false'},path)
    template='spec:\n  containers:\n    - name: sttm-builder\n      env:\n${DEEP_AGENT_RUNTIME_ENV}\n'
    env=yaml.safe_load(render_template(template,environment))['spec']['containers'][0]['env']
    assert env['MIGRATION_AGENT_ENABLED']=='true'
    assert env['MIGRATION_AGENT_MODEL_LIGHT']=='available-model'
    assert env['MIGRATION_AGENT_CAPACITY_LIMITS']=='{"account:{account}":1}'
    assert env['MIGRATION_AGENT_WAKE_PORT']=='0'
    assert 'SNOWFLAKE_PASSWORD' not in env and 'AUTH_SESSION_ENCRYPTION_KEY' not in env
    assert 'must-not-copy' not in str(env)


def test_deep_defaults_remain_disabled_and_both_backend_specs_mount_service_token():
    from pathlib import Path
    import yaml
    root=Path(__file__).resolve().parents[5]
    template='spec:\n  containers:\n    - name: sttm-builder\n      env:\n${DEEP_AGENT_RUNTIME_ENV}\n'
    env=yaml.safe_load(render_template(template,{}))['spec']['containers'][0]['env']
    assert env['MIGRATION_AGENT_ENABLED']=='false'
    for name in ['webapp','sttm-builder']:
        spec=(root/'infra/snowflake/service-specs'/f'{name}.yaml.tmpl').read_text()
        assert 'mountSessionToken: true' in spec and '${DEEP_AGENT_RUNTIME_ENV}' in spec
    for name in ['deploy_spcs_client_direct.sh','deploy_spcs_client_snow.sh','deploy_spcs_client_snow.ps1',
                 'deploy_spcs_client_snow_safe.ps1','deploy_spcs_client_snow_single_service.ps1']:
        assert '--runtime-env-file' in (root/'scripts'/name).read_text()



def test_deep_runtime_defaults_are_valid_for_settings_and_preserve_numeric_zero():
    import yaml
    from app.core.config import Settings
    template='spec:\n  containers:\n    - name: sttm-builder\n      env:\n${DEEP_AGENT_RUNTIME_ENV}\n'
    env=yaml.safe_load(render_template(template,{}))['spec']['containers'][0]['env']
    settings=Settings(_env_file=None,**env)
    assert settings.migration_agent_context_window_tokens==0
    assert settings.migration_agent_token_budget==0
    assert settings.migration_agent_capacity_limits=={}
    assert settings.migration_agent_capacity_scopes==[]
