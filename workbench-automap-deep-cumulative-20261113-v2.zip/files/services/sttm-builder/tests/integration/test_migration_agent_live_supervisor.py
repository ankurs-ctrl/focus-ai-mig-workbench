from __future__ import annotations

import os
from uuid import uuid4

import pytest

from app.agent_runs.checkpoint import SnowflakeStageCheckpointSaver
from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
from app.agent_runtime.execution import ExecutionBudget
from app.agent_runtime.interface import RuntimeInvocation
from app.agent_runtime.model_adapter import build_snowflake_cortex_model
from app.agent_runs.models import EFFORT_POLICIES, EffortLevel
from app.core.config import get_settings
from app.core.snowflake import SnowflakeClient
from app.migration_workflow.graph import build_migration_graph


pytestmark = pytest.mark.skipif(
    os.getenv("RUN_MIGRATION_AGENT_LIVE_TEST") != "1",
    reason="Set RUN_MIGRATION_AGENT_LIVE_TEST=1 with a delegated OAuth token to run the live Cortex gate.",
)


def test_live_cortex_supervisor_delegates_and_resumes_after_runtime_restart() -> None:
    """Release gate: live model -> task tool -> compiled graph -> durable resume."""
    settings = get_settings()
    token = os.environ["MIGRATION_AGENT_TEST_OAUTH_TOKEN"]
    role = os.getenv("MIGRATION_AGENT_TEST_ROLE") or settings.snowflake_role
    client = SnowflakeClient(settings=settings, user_token=token, role=role or None)
    try:
        rest = client.get_rest_session_context()
        saver = SnowflakeStageCheckpointSaver(
            client.session,
            database=settings.snowflake_database,
            schema=settings.snowflake_schema,
            stage=settings.migration_agent_checkpoint_stage,
        )
        graph = build_migration_graph(checkpointer=saver)
        run_id = f"live_gate_{uuid4().hex}"
        policy = EFFORT_POLICIES[EffortLevel.LIGHT]

        def runtime(model_used: int = 0, tool_used: int = 0) -> DeepAgentsRuntime:
            return DeepAgentsRuntime(
                model=build_snowflake_cortex_model(
                    host=rest.host,
                    oauth_token=token,
                    model=settings.migration_agent_model_light,
                    role=role or None,
                    warehouse=settings.snowflake_agent_warehouse or None,
                    reasoning_effort=policy.reasoning_effort,
                    max_retries=0,
                ),
                migration_graph=graph,
                budget=ExecutionBudget(
                    model_limit=policy.model_call_budget,
                    tool_limit=policy.tool_call_budget,
                    model_used=model_used,
                    tool_used=tool_used,
                ),
                checkpointer=saver,
            )

        first = runtime().invoke(RuntimeInvocation(
            run_id=run_id,
            thread_id=run_id,
            prompt="Create a Household draft mapping.",
            effort=EffortLevel.LIGHT,
            workflow_input={
                "messages": [], "run_id": run_id, "prompt": "Create a Household draft mapping.",
                "effort": "light", "actor_user_id": "live-gate", "effective_role": role or "PUBLIC",
                "tenant_id": "live-gate", "requested_mappings": ["Household"],
                "authorized_target_scope": [], "attachment_ids": [],
            },
        ))
        assert first.status == "AWAITING_INPUT"
        assert first.interrupt and first.interrupt["category"] == "target_scope"

        resumed = runtime(first.model_calls_used, first.tool_calls_used).invoke(RuntimeInvocation(
            run_id=run_id,
            thread_id=run_id,
            prompt="Create a Household draft mapping.",
            effort=EffortLevel.LIGHT,
            resume_value={"target_tables": {"household": "LIVE_GATE.PUBLIC.HOUSEHOLD"}},
        ))
        assert resumed.status == "READY_FOR_REVIEW"
        assert resumed.workflow_state["manifest"][0]["target_table"] == "LIVE_GATE.PUBLIC.HOUSEHOLD"
    finally:
        client.close()
