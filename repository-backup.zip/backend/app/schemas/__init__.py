"""Pydantic schemas."""

