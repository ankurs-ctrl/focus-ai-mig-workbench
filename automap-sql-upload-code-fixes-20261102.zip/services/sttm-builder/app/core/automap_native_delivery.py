"""Independent bounded parent delivery from durable native target checkpoints.

One daemon reader owns its connection. A slow connection/read cannot block ready
HTTP responses, checkpoints or the parent deadline. No replay or permit recycling.
"""

from concurrent.futures import Future, TimeoutError, wait, FIRST_COMPLETED
import logging
from threading import Thread
import time
from app.core.automap_native import recover_checkpoints
from app.core.automap_native_store import NativeJobStore

logger = logging.getLogger(__name__)


def _read_checkpoints(proxy, req, batches, indices, headers):
    client = None
    try:
        client = proxy._open_job_client(headers)
        metadata = (
            proxy._settings.resolved_metadata_database
            + "."
            + proxy._settings.resolved_metadata_schema
        )
        store = NativeJobStore(client.session, metadata, timeout=5)
        results = []
        for index in indices:
            batch_req = req.model_copy(
                update={
                    "data": req.data.model_copy(update={"attributes": batches[index]}),
                    "meta": {**req.meta, "auto_mapping_batch_index": index},
                }
            )
            batch_req, _ = proxy._budget_batch_request(batch_req)
            recovered = recover_checkpoints(store, batch_req)
            if recovered is not None:
                results.append((index, batch_req, recovered))
        return results
    finally:
        if client is not None:
            client.close()


def reconcile_checkpoint(recovered, worker):
    """Only combine authenticated equivalent native generations, never choose
    an older partial over a successful complete worker response."""
    identity = recovered.meta.get("auto_map_native_identity")
    if not identity or identity != worker.meta.get("auto_map_native_identity"):
        raise ValueError("Native result generation or input revision mismatch")
    bindings = recovered.meta.get("auto_map_target_bindings", {})
    if bindings != worker.meta.get("auto_map_target_bindings", {}):
        raise ValueError("Native target bindings changed")
    result = worker.model_copy(deep=True)
    mappings = result.result.mappings
    checkpointed = set(worker.meta.get("auto_map_native_checkpoint_targets", []))
    hashes = dict(worker.meta.get("auto_map_native_proposal_hashes", {}))
    conflicts = []
    for name in recovered.meta.get("auto_map_native_checkpoint_targets", []):
        binding = bindings.get(name)
        old_hash = recovered.meta.get("auto_map_native_proposal_hashes", {}).get(
            binding
        )
        if not binding or not old_hash:
            raise ValueError("Native checkpoint provenance missing")
        if name in checkpointed:
            if (
                hashes.get(binding) != old_hash
                or mappings.get(name) != recovered.result.mappings[name]
            ):
                # Keep the independently accepted checkpoint for this target;
                # do not discard compatible newer siblings in the worker result.
                conflicts.append(name)
                mappings[name] = recovered.result.mappings[name].model_copy(deep=True)
                hashes[binding] = old_hash
        else:
            mappings[name] = recovered.result.mappings[name].model_copy(deep=True)
            checkpointed.add(name)
            hashes[binding] = old_hash
    from app.schema.sttm_builder import STTMStatus
    recovered_coverage = {item['target']: item for item in recovered.meta.get('auto_map_retrieval', {}).get('targets', [])}
    retrieval = dict(result.meta.get('auto_map_retrieval', {}))
    retrieval['targets'] = [recovered_coverage.get(item['target'], item)
        if item['target'] in checkpointed and item['target'] not in worker.meta.get('auto_map_native_checkpoint_targets', [])
        else item for item in retrieval.get('targets', [])]
    review_targets = sorted(set(result.meta.get('automap_evidence_review_only_targets', []))
        | (set(recovered.meta.get('automap_evidence_review_only_targets', [])) & checkpointed))
    if conflicts:
        from app.schema.contracts import ApiWarning
        result.warnings.append(ApiWarning(code='AUTO_MAPPING_NATIVE_DELIVERY_CONFLICT',
            message='Conflicting worker delivery was rejected for previously checkpointed targets; accepted checkpoints and compatible sibling results were retained.'))
    status = STTMStatus.NEEDS_INPUT if conflicts or review_targets or any(
        item.transformation_classification == 'unresolved' for item in mappings.values()) else STTMStatus.COMPLETED
    result.data = result.data.model_copy(update={"result": result.result, 'status': status})
    result.meta = {
        **result.meta,
        "auto_map_native_checkpoint_targets": sorted(checkpointed),
        **({'auto_map_native_delivery_conflict': True, 'auto_map_native_delivery_conflict_targets': sorted(conflicts)} if conflicts else {}),
        'auto_map_retrieval': retrieval,
        'automap_evidence_review_only_targets': review_targets,
        "auto_map_native_proposal_hashes": hashes,
    }
    return result


def completed_with_checkpoints(
    proxy,
    futures,
    req,
    batches,
    headers,
    *,
    resolution_root=None,
    progress_callback=None,
    deadline=None,
    poll_seconds=2
):
    remaining = dict(futures)
    latest, tokens = {}, {}
    last_poll = 0
    reader = None
    reader_started = 0
    reader_warned = False
    while remaining:
        now = time.time()
        if reader is not None and reader.done():
            try:
                rows = reader.result()
            except Exception as error:
                logger.warning(
                    "Native checkpoint recovery unavailable stage=parent_read failure=%s",
                    type(error).__name__,
                )
                rows = []
            reader = None
            for index, batch_req, recovered in rows:
                if index not in remaining.values():
                    continue
                if resolution_root is not None:
                    recovered = proxy._resolution_batch_response(
                        batch_req, recovered, index
                    )
                    recovered = proxy._resolution_partial_metadata(
                        resolution_root, recovered, batches[index]
                    )
                recovered.meta = {
                    **recovered.meta,
                    "batch_identity": proxy._batch_identity(
                        resolution_root or req, batches[index]
                    ),
                    "auto_map_native_parent_received_at": time.time(),
                }
                if deadline and time.time() >= deadline:
                    continue  # do not admit a newly observed late checkpoint
                latest[index] = recovered
                token = recovered.meta["auto_map_native_checkpoint_token"]
                targets = recovered.meta["auto_map_native_checkpoint_targets"]
                if (
                    targets
                    and tokens.get(index) != token
                    and progress_callback is not None
                    and (not deadline or time.time() < deadline)
                ):
                    # Caller must persist this receipt before making it visible.
                    # Do not catch persistence failures as optional read failures.
                    tokens[index] = token
                    yield ("checkpoint", index, recovered)
        if reader is not None and now - reader_started > 10 and not reader_warned:
            reader_warned = True
            logger.warning(
                "Native checkpoint recovery delayed stage=parent_read timeout_seconds=10"
            )
        if (
            reader is None
            and now - last_poll >= poll_seconds
            and (not deadline or now < deadline)
        ):
            last_poll = now
            reader_started = now
            reader_warned = False
            reader = Future()

            # Capture immutable arguments and the future, never a loop variable.
            def read(result=reader, indices=tuple(remaining.values())):
                try:
                    value = _read_checkpoints(proxy, req, batches, indices, headers)
                except BaseException as error:
                    result.set_exception(error)
                else:
                    result.set_result(value)

            Thread(
                target=read, name="automap-native-checkpoint-reader", daemon=True
            ).start()
        for future, index in list(remaining.items()):
            recovered = latest.get(index)
            all_checkpointed = recovered and len(
                recovered.meta["auto_map_native_checkpoint_targets"]
            ) == len(batches[index])
            if (
                future.done()
                and future.exception() is not None
                and recovered is None
                and reader is not None
                and time.time() - reader_started < 10
                and (not deadline or time.time() < deadline)
            ):
                continue  # bounded recovery grace for a lost worker response
            if (
                future.done()
                or all_checkpointed
                or (deadline and time.time() >= deadline)
            ):
                if recovered is not None:
                    terminal = recovered.model_copy(deep=True)
                    if (
                        future.done()
                        and future.exception() is None
                        and (not deadline or time.time() < deadline)
                    ):
                        # Successful worker output can contain checkpoints newer
                        # than the most recent parent poll.
                        try:
                            terminal = reconcile_checkpoint(recovered, future.result())
                        except ValueError:
                            from app.schema.contracts import ApiWarning
                            terminal.warnings.append(ApiWarning(code='AUTO_MAPPING_NATIVE_IDENTITY_CONFLICT',
                                message='Worker delivery did not match the accepted checkpoint identity; only accepted checkpoints were retained.'))
                            # Preserve the accepted checkpoint, but surface the
                            # incompatible worker rather than overwrite it.
                            terminal.meta = {
                                **terminal.meta,
                                "auto_map_native_delivery_conflict": True,
                            }
                    terminal.meta = {
                        **terminal.meta,
                        "auto_map_native_provisional": False,
                    }
                    ready = Future()
                    ready.set_result(terminal)
                    # Server-only receipt: parent may finalize this already
                    # admitted checkpoint after cutoff; no late worker is trusted.
                    ready.native_accepted_before_deadline = terminal
                    futures[ready] = index
                    del remaining[future]
                    yield ready
                elif future.done():
                    del remaining[future]
                    yield future
                else:
                    raise TimeoutError(
                        "Native parent deadline reached; no checkpoint available"
                    )
        if remaining:
            pending = [future for future in remaining if not future.done()]
            if reader is not None:
                pending.append(reader)
            wait(
                pending,
                timeout=(
                    min(poll_seconds, max(0, deadline - time.time()))
                    if deadline
                    else poll_seconds
                ),
                return_when=FIRST_COMPLETED,
            )
