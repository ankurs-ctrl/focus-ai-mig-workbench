"""Phase 1: verified knowledge is read once and reused across claims and turns."""
from __future__ import annotations

import hashlib
import re
from typing import Any
from unittest.mock import Mock

import pytest

from app.agent_runs.knowledge_repository import RunKnowledgeRepository
from app.agent_runs.models import ToolResult
from app.agent_runtime.execution import ExecutionBudget
from app.agent_runtime.run_knowledge import CATALOG_CANDIDATE, CONTRACT, TOOL_RESULT, RunKnowledge, knowledge_scope
from app.agent_tools.capability_registry import CapabilityRegistry
from app.agent_tools.contract_reader import (
    TableContractUnavailable,
    catalog_signatures,
    contract_fingerprint,
    describe_type,
    read_contracts,
)
from app.agent_tools.workbench import WorkbenchWorkflowHandlers


class _Result:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    def collect(self) -> list[dict[str, Any]]:
        return self._rows


class _Catalog:
    """Snowflake session double serving DESC TABLE and the signature query."""

    def __init__(self, tables: dict[str, list[tuple[str, str, int | None]]], keys: dict[str, list[str]] | None = None):
        self.tables = tables
        self.keys = keys or {}
        self.queries: list[str] = []

    @staticmethod
    def _type(data_type: str, length: int | None) -> str:
        return describe_type(data_type, length, 38 if data_type == "NUMBER" else None,
                             0 if data_type == "NUMBER" else None)

    def sql(self, query: str, params: list[Any] | None = None, **_: Any) -> _Result:
        self.queries.append(query)
        if query.startswith("DESC TABLE"):
            fqn = ".".join(re.findall(r'"([^"]+)"', query))
            if fqn not in self.tables:
                raise RuntimeError(f"SQL compilation error: Table '{fqn}' does not exist or not authorized.")
            return _Result([
                {"name": name, "type": self._type(data_type, length), "null?": "Y",
                 "primary key": "Y" if name in self.keys.get(fqn, []) else "N"}
                for name, data_type, length in self.tables[fqn]
            ])
        if "INFORMATION_SCHEMA.COLUMNS" in query:
            database = re.search(r'FROM "([^"]+)"\.INFORMATION_SCHEMA', query).group(1)
            pairs = set(zip(params[::2], params[1::2]))
            rows = []
            for fqn, columns in self.tables.items():
                db, schema, table = fqn.split(".")
                if db == database and (schema, table) in pairs:
                    text = "|".join(f"{name}:{self._type(data_type, length)}:Y" for name, data_type, length in columns)
                    rows.append({"TABLE_SCHEMA": schema, "TABLE_NAME": table,
                                 "SIGNATURE": hashlib.md5(text.encode()).hexdigest()})
            return _Result(rows)
        raise AssertionError(f"Unexpected query: {query}")

    def count(self, prefix: str) -> int:
        return sum(1 for query in self.queries if prefix in query)


_TABLES = {
    "DB.SRC.CONTACTS": [("ID", "NUMBER", None), ("FIRST_NAME", "TEXT", 255)],
    "DB.SRC.CONTACT_FAMILIES": [("ID", "NUMBER", None), ("NAME", "TEXT", 100)],
    "DB.SRC.CONTACT_FAMILY_MEMBERS": [("ID", "NUMBER", None), ("FAMILY_ID", "NUMBER", None), ("CONTACT_ID", "NUMBER", None)],
    "DB.TGT.HOUSEHOLD": [("ID", "TEXT", 18), ("NAME", "TEXT", 255)],
}
_JOIN_TABLES = ["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES", "DB.SRC.CONTACT_FAMILY_MEMBERS"]


def _catalog() -> _Catalog:
    return _Catalog({key: list(value) for key, value in _TABLES.items()}, {"DB.SRC.CONTACTS": ["ID"]})


class _Clock:
    def __init__(self, start: float = 10_000.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now


def _knowledge(rows: list[dict[str, Any]] | None = None, *, clock: _Clock | None = None,
               recheck: float = 0.0) -> tuple[RunKnowledge, list[dict[str, Any]]]:
    persisted: list[dict[str, Any]] = []
    knowledge = RunKnowledge(scope=knowledge_scope("run-1", "conversation-1"), access_scope="t:u:ROLE",
                             run_id="run-1", ttl_seconds=3600, recheck_seconds=recheck,
                             writer=persisted.extend, clock=clock or _Clock())
    knowledge.hydrate(rows or [])
    return knowledge, persisted


def _handlers(session: _Catalog, knowledge: RunKnowledge | None) -> WorkbenchWorkflowHandlers:
    handlers = WorkbenchWorkflowHandlers(repository=Mock(), project_service=Mock(), session=session, knowledge=knowledge)
    handlers.attach_knowledge_reader()
    return handlers


def _durable(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """What the next claim loads: the latest write per key, deletions applied."""
    latest: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        latest[(row["kind"], row["key"])] = row
    return [row for row in latest.values() if row["payload"] is not None]


def test_information_schema_types_render_exactly_like_desc_table() -> None:
    assert describe_type("TEXT", 255) == "VARCHAR(255)"
    assert describe_type("TEXT", 16777216) == "VARCHAR(16777216)"
    assert describe_type("NUMBER", None, 38, 0) == "NUMBER(38,0)"
    assert describe_type("TIMESTAMP_NTZ", datetime_precision=9) == "TIMESTAMP_NTZ(9)"
    assert describe_type("BOOLEAN") == "BOOLEAN"


def test_contract_fingerprint_equals_the_server_side_signature_and_is_order_sensitive() -> None:
    session = _catalog()
    contract = read_contracts(session.sql, ["DB.SRC.CONTACTS"])["DB.SRC.CONTACTS"]
    assert catalog_signatures(session.sql, ["DB.SRC.CONTACTS"]) == {"DB.SRC.CONTACTS": contract_fingerprint(contract)}
    reordered = {"column_contracts": list(reversed(contract["column_contracts"]))}
    assert contract_fingerprint(reordered) != contract_fingerprint(contract)


def test_signature_query_binds_identifiers_and_skips_invisible_tables() -> None:
    session = _catalog()
    signatures = catalog_signatures(session.sql, ["DB.SRC.CONTACTS", "db.src.contact_families", "DB.SRC.GONE"])
    assert set(signatures) == {"DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES"}
    assert session.count("INFORMATION_SCHEMA.COLUMNS") == 1
    assert "CONTACTS" not in session.queries[0]
    with pytest.raises(ValueError):
        catalog_signatures(session.sql, ["DB.SRC.CONTACTS; DROP TABLE X"])


def test_describe_table_contract_matches_the_previous_shape_and_reports_missing_tables() -> None:
    session = _catalog()
    handlers = _handlers(session, None)
    assert handlers._describe_table("DB.SRC.CONTACTS") == {
        "columns": ["ID", "FIRST_NAME"], "key_columns": ["ID"],
        "column_contracts": [
            {"name": "ID", "type": "NUMBER(38,0)", "nullable": True, "primary_key": True},
            {"name": "FIRST_NAME", "type": "VARCHAR(255)", "nullable": True, "primary_key": False},
        ],
    }
    handlers._describe_table("db.src.contacts")
    assert session.count("DESC TABLE") == 1
    with pytest.raises(TableContractUnavailable):
        handlers._describe_table("DB.SRC.MISSING")


def test_resume_after_a_join_answer_reads_no_contract_again() -> None:
    clock = _Clock()
    first, persisted = _knowledge(clock=clock, recheck=600)
    _handlers(_catalog(), first)._describe_tables(_JOIN_TABLES)

    clock.now += 90  # the user answers the join question
    session = _catalog()
    resumed, _ = _knowledge(_durable(persisted), clock=clock, recheck=600)
    handlers = _handlers(session, resumed)
    for table in _JOIN_TABLES:
        handlers.inspect_table_contract(table)

    assert session.queries == []
    assert resumed.metrics["contracts_confirmed_without_query"] == 3


def test_stale_confirmation_costs_one_signature_query_not_one_read_per_table() -> None:
    clock = _Clock()
    first, persisted = _knowledge(clock=clock, recheck=600)
    _handlers(_catalog(), first)._describe_tables(_JOIN_TABLES)

    clock.now += 1200
    session = _catalog()
    resumed, _ = _knowledge(_durable(persisted), clock=clock, recheck=600)
    handlers = _handlers(session, resumed)
    handlers._describe_tables(_JOIN_TABLES)
    handlers._describe_tables(_JOIN_TABLES)

    assert session.count("INFORMATION_SCHEMA.COLUMNS") == 1
    assert session.count("DESC TABLE") == 0


def test_changed_contract_is_reread_and_invalidates_exactly_its_dependents() -> None:
    first, persisted = _knowledge()
    _handlers(_catalog(), first)._describe_tables(["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES"])
    first.put(TOOL_RESULT, "evidence:contacts", {"result": {"n": 1}}, depends_on_tables=["DB.SRC.CONTACTS"])
    first.put(TOOL_RESULT, "evidence:families", {"result": {"n": 2}}, depends_on_tables=["DB.SRC.CONTACT_FAMILIES"])

    changed = _catalog()
    changed.tables["DB.SRC.CONTACTS"].append(("EMAIL", "TEXT", 255))
    resumed, persisted_again = _knowledge(_durable(persisted))
    contracts = _handlers(changed, resumed)._describe_tables(["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES"])

    assert contracts["DB.SRC.CONTACTS"]["columns"] == ["ID", "FIRST_NAME", "EMAIL"]
    assert [query for query in changed.queries if query.startswith("DESC TABLE")] == [
        'DESC TABLE "DB"."SRC"."CONTACTS"']
    assert resumed.get(TOOL_RESULT, "evidence:contacts") is None
    assert resumed.get(TOOL_RESULT, "evidence:families") == {"result": {"n": 2}}
    assert {"kind": TOOL_RESULT, "key": "evidence:contacts", "fingerprint": "", "payload": None} in persisted_again


def test_table_that_is_no_longer_visible_is_dropped_with_its_dependents() -> None:
    first, persisted = _knowledge()
    _handlers(_catalog(), first)._describe_tables(["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES"])
    first.put(TOOL_RESULT, "evidence:families", {"result": {}}, depends_on_tables=["DB.SRC.CONTACT_FAMILIES"])

    revoked = _catalog()
    del revoked.tables["DB.SRC.CONTACT_FAMILIES"]
    resumed, _ = _knowledge(_durable(persisted))
    summary = resumed.ensure_verified(["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES"],
                                      reader=lambda tables: catalog_signatures(revoked.sql, tables))

    assert summary == {"confirmed": ["DB.SRC.CONTACTS"], "changed": [], "unavailable": ["DB.SRC.CONTACT_FAMILIES"]}
    assert resumed.contract("DB.SRC.CONTACT_FAMILIES") is None
    assert resumed.get(TOOL_RESULT, "evidence:families") is None


def test_everything_expires_after_the_ttl_and_is_read_again() -> None:
    clock = _Clock()
    knowledge, persisted = _knowledge(clock=clock, recheck=600)
    _handlers(_catalog(), knowledge)._describe_tables(["DB.SRC.CONTACTS"])
    knowledge.put(CATALOG_CANDIDATE, "DB.SRC.CONTACTS", {"table": "DB.SRC.CONTACTS"})

    clock.now += 3601
    session = _catalog()
    resumed, _ = _knowledge(_durable(persisted), clock=clock, recheck=600)
    assert resumed.get(CATALOG_CANDIDATE, "DB.SRC.CONTACTS") is None
    _handlers(session, resumed)._describe_tables(["DB.SRC.CONTACTS"])
    assert session.count("DESC TABLE") == 1
    assert session.count("INFORMATION_SCHEMA") == 0


def test_batched_puts_flush_once() -> None:
    writes: list[list[dict[str, Any]]] = []
    knowledge = RunKnowledge(scope="run:r", access_scope="a", run_id="r", ttl_seconds=60, writer=writes.append)
    knowledge.put_many(CATALOG_CANDIDATE, [(f"DB.S.T{i}", {"table": f"DB.S.T{i}"}, []) for i in range(5)])
    assert len(writes) == 1 and len(writes[0]) == 5


class _EvidenceWorkbench:
    def __init__(self, session: _Catalog, knowledge: RunKnowledge) -> None:
        self.adapter = _handlers(session, knowledge)
        self.calls = 0

    def inspect_table_contract(self, table_fqn: str) -> ToolResult:
        return self.adapter.inspect_table_contract(table_fqn)

    def prepare_migration_evidence(self, _context, *, source_tables, target_table, precedent_project_ids) -> ToolResult:
        self.calls += 1
        self.adapter._describe_tables([target_table, *source_tables])
        return ToolResult(status="succeeded", summary="Prepared evidence.", data={
            "target_table": target_table, "source_tables": list(source_tables),
        }, evidence_refs=[f"table_contract:{target_table}"])


def _registry(workbench: _EvidenceWorkbench, knowledge: RunKnowledge, traces: list[tuple[str, dict]],
              effort: str = "medium") -> CapabilityRegistry:
    context = {"intent": "NEW_MIGRATION_TASK", "effort": effort, "authorized_schemas": ["DB.SRC", "DB.TGT"]}
    registry = CapabilityRegistry(
        context_provider=lambda: context, workflow_executor=lambda *_: {}, workbench=workbench,
        budget=ExecutionBudget(model_limit=5, tool_limit=20), knowledge=knowledge,
        trace=lambda event_type, _status, _summary, data: traces.append((event_type, data)),
    )
    registry.begin_run({**context, "run_id": "run-1"})
    return registry


def _evidence(registry: CapabilityRegistry) -> dict[str, Any]:
    tool = next(item for item in registry.tools() if item.name == "prepare_migration_evidence")
    return tool.invoke({"source_tables": ["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES"],
                        "target_table": "DB.TGT.HOUSEHOLD", "precedent_project_ids": []})


def _first_turn() -> list[dict[str, Any]]:
    knowledge, persisted = _knowledge()
    workbench = _EvidenceWorkbench(_catalog(), knowledge)
    registry = _registry(workbench, knowledge, [])
    registry._catalog_candidates.update(["DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES", "DB.TGT.HOUSEHOLD"])
    assert _evidence(registry)["status"] == "succeeded"
    assert workbench.calls == 1
    return _durable(persisted)


def test_evidence_and_catalog_scope_survive_a_worker_restart_and_a_new_turn() -> None:
    session = _catalog()
    knowledge, _ = _knowledge(_first_turn())
    workbench = _EvidenceWorkbench(session, knowledge)
    traces: list[tuple[str, dict]] = []
    registry = _registry(workbench, knowledge, traces)

    assert {"DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILIES", "DB.TGT.HOUSEHOLD"} <= registry._catalog_candidates
    assert _evidence(registry)["status"] == "succeeded"
    assert workbench.calls == 0
    reused = [data for event_type, data in traces if event_type == "tool.reused"]
    assert reused and reused[0]["reuse_scope"] == "conversation"
    # The evidence's three contracts were confirmed with one signature query.
    assert session.count("INFORMATION_SCHEMA.COLUMNS") == 1
    assert session.count("DESC TABLE") == 0


def test_evidence_is_rebuilt_when_a_source_contract_changed() -> None:
    changed = _catalog()
    changed.tables["DB.SRC.CONTACT_FAMILIES"].append(("HEAD_ID", "NUMBER", None))
    knowledge, _ = _knowledge(_first_turn())
    workbench = _EvidenceWorkbench(changed, knowledge)
    _evidence(_registry(workbench, knowledge, []))
    assert workbench.calls == 1


def test_evidence_is_not_reused_under_a_different_effort_policy() -> None:
    knowledge, _ = _knowledge(_first_turn())
    workbench = _EvidenceWorkbench(_catalog(), knowledge)
    _evidence(_registry(workbench, knowledge, [], effort="high"))
    assert workbench.calls == 1


def test_restored_candidates_are_reauthorized_against_the_current_scope() -> None:
    first_knowledge, persisted = _knowledge()
    first = _registry(_EvidenceWorkbench(_catalog(), first_knowledge), first_knowledge, [])
    first._catalog_candidates.update(["DB.SRC.CONTACTS", "DB.OTHER.SECRET"])

    knowledge, _ = _knowledge(_durable(persisted))
    registry = CapabilityRegistry(
        context_provider=lambda: {"intent": "NEW_MIGRATION_TASK", "authorized_schemas": ["DB.SRC"]},
        workflow_executor=lambda *_: {}, workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20), knowledge=knowledge,
    )
    registry.begin_run({"run_id": "run-2", "authorized_schemas": ["DB.SRC"]})
    assert "DB.SRC.CONTACTS" in registry._catalog_candidates
    assert "DB.OTHER.SECRET" not in registry._catalog_candidates


def test_repository_upserts_and_deletes_in_bounded_set_based_statements() -> None:
    session = Mock()
    session.sql.return_value.collect.return_value = []
    repository = RunKnowledgeRepository(session, database="DB", schema="META")
    rows = [
        {"kind": CONTRACT, "key": "DB.S.A", "fingerprint": "f", "payload": {"value": {"columns": ["ID"]}}},
        {"kind": TOOL_RESULT, "key": "k", "fingerprint": "", "payload": None},
    ]
    repository.write("conversation:c", "t:u:r", "run-1", rows)

    statements = [call.args[0] for call in session.sql.call_args_list]
    assert len(statements) == 2
    assert "MERGE INTO DB.META.TBL_AGENT_RUN_KNOWLEDGE" in statements[0] and "FLATTEN" in statements[0]
    assert statements[1].strip().startswith("DELETE FROM DB.META.TBL_AGENT_RUN_KNOWLEDGE")
    assert session.sql.call_args_list[0].kwargs["params"][1:3] == ["conversation:c", "t:u:r"]
    with pytest.raises(ValueError):
        RunKnowledgeRepository(session, database="DB", schema="META; DROP")


def test_trace_writer_runs_control_writes_in_order_with_events_and_survives_their_failure() -> None:
    from types import SimpleNamespace

    from app.agent_runs.trace_writer import DurableTraceWriter

    order: list[str] = []
    service = SimpleNamespace(
        build_event=lambda _run, event_type, *_args, **_kwargs: event_type,
        repository=SimpleNamespace(append_events=lambda batch: order.extend(batch)),
    )
    writer = DurableTraceWriter(service, SimpleNamespace(run_id="run-1"), flush_interval_seconds=0.05)
    writer("event.one", "running", "One", {})
    writer.submit(lambda: order.append("knowledge.write"))
    writer.submit(lambda: (_ for _ in ()).throw(RuntimeError("storage unavailable")))
    writer("event.two", "running", "Two", {})
    writer.close()

    assert order == ["event.one", "knowledge.write", "event.two"]


def test_trace_flush_waits_for_a_progressing_backlog_but_fails_on_a_stall() -> None:
    import threading
    import time
    from types import SimpleNamespace

    from app.agent_runs.trace_writer import DurableTraceWriter

    def slow_append(batch):
        time.sleep(0.05)

    service = SimpleNamespace(build_event=lambda _run, event_type, *_a, **_k: event_type,
                              repository=SimpleNamespace(append_events=slow_append))
    writer = DurableTraceWriter(service, SimpleNamespace(run_id="run-1"), batch_size=1, flush_interval_seconds=0.01)
    for index in range(20):
        writer(f"event.{index}", "running", "E", {})
    # About 1s of work, twice the stall timeout, but always progressing.
    writer.flush(timeout=0.5)
    assert writer._queue.unfinished_tasks == 0

    release = threading.Event()
    stuck = DurableTraceWriter(SimpleNamespace(build_event=service.build_event,
                                               repository=SimpleNamespace(append_events=lambda _b: release.wait())),
                               SimpleNamespace(run_id="run-2"), batch_size=1, flush_interval_seconds=0.01)
    stuck("event.blocked", "running", "E", {})
    try:
        started = time.monotonic()
        try:
            stuck.flush(timeout=0.2)
        except TimeoutError:
            assert time.monotonic() - started < 2
        else:
            raise AssertionError("a stalled writer must time out")
    finally:
        release.set()
