/**
 * The one font used across the whole application (UI text, titles, SQL and code).
 * Self-hosted Inter, registered with @font-face in app/globals.css.
 * Keep in sync with --font-body in app/globals.css.
 */
export const APP_FONT_FAMILY = 'Inter, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
