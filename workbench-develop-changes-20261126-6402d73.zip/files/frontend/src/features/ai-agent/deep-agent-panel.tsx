"use client";

import { AiaAvatar, AiaBox, AiaButton, AiaCircularProgress, AiaIconButton, AiaInput, AiaPaper, AiaStack, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useRegisterAiAgentSend, type AiAgentSendOptions } from "./use-ai-agent-send";
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { updateAssistantScroll, type AssistantScrollEvent, type AssistantScrollState } from "./assistant-scroll";
import { AI_AGENT_PAGE_CONTENT_MAX_WIDTH, GENERAL_PROJECT_VALUE } from './ai-chat-layout-constants';
import { AssistantMarkdown } from "@/features/ai-agent/assistant-markdown";
import {
  AutoAwesomeRoundedIcon,
  BoltIcon,
  CloseIcon,
  ContentCopyRoundedIcon,
  EditNoteRoundedIcon,
  HelpOutlineOutlinedIcon,
  KeyboardArrowDownIcon,
  KeyboardArrowRightIcon,
  OpenInFullIcon,
  TableChartIcon,
  ThumbDownAltOutlinedIcon,
  ThumbUpAltOutlinedIcon,
  TipsAndUpdatesOutlinedIcon,
  VolumeUpIcon,
  WarningAmberRoundedIcon,
} from '@/utils/icons';
import { MigrationAgentSessionClient, type MigrationAgentServerMessage, type MigrationAgentPermissionRequest, type PendingDeepMessage, type MigrationEffort, type MigrationRunMode, type MigrationConversationMessage, type ReviewTable, fetchMigrationAgentDiagnostics } from '@/services/migrationAgentService';
import { AgentReviewTable } from "@/features/ai-agent/agent-review-table";
import { AgentLearnedList, learnedItems } from "@/features/ai-agent/agent-learned-list";
import { recommendationService } from "@/services/recommendationService";
import { AiChatComposer } from "@/features/ai-agent/deep-chat-composer";
import { AgentArtifactPane, type AgentArtifactTab, type AgentSqlArtifact } from "@/features/ai-agent/agent-artifact-pane";
import { AgentReviewList, type AgentReviewItem } from "@/features/ai-agent/agent-review-list";
import { separateSqlPreview } from '@/features/ai-agent/agent-artifact-text';
import { publishSttm } from '@/services/projectService';
import { appendOrReplaceFinal, insertProgressBeforeFinal } from '@/features/ai-agent/agent-message-order';
import { useAiChatLayout } from "@/features/ai-agent/ai-chat-layout-context";
import { MigrationProgressStrip, latestRunProgress } from "@/features/ai-agent/migration-progress-strip";
import { contextUsageFromEvent, type ContextUsage } from "@/features/ai-agent/context-meter";
import type {
  FIRRecommendation,
  FIRRecommendationAction,
  WorkbenchContextSnapshotV1,
} from '@/types/api-contract';






import { useStore } from "react-redux";
import type { RootState } from "@/store/store";
import { selectAssistantMappingSql } from "@/features/sttm/store/sttm-builder-slice";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import type { StreamingStatusPhase } from "@/features/sttm/types/sttm.types";
import { usePathname, useRouter } from "next/navigation";
import { buildWorkbenchContextSnapshot } from "@/features/sttm/context/workbench-context";
import { getSttmBuilderAssistantPage } from "@/features/sttm/shared/sttm-builder-routes";
import { authService } from '@/services/authService';
import type { UserSession } from '@/types/user';

// User-friendly labels for each streaming phase
const STATUS_PHASE_LABELS: Record<StreamingStatusPhase, string> = {
  preparing: "Preparing context...",
  semantic: "Loading semantic data...",
  learning: "Retrieving learnings...",
  invoking: "Connecting to AI...",
  processing: "Analyzing tables...",
  finalizing: "Generating suggestions...",
};

// Progress percentage for each phase (for visual feedback)
const STATUS_PHASE_PROGRESS: Record<StreamingStatusPhase, number> = {
  preparing: 10,
  semantic: 25,
  learning: 40,
  invoking: 55,
  processing: 75,
  finalizing: 90,
};

const APPROVAL_RESPONSE_PATTERN =
  /^(yes|yep|yeah|ok|okay|sure|approve|approved|apply|apply it|please apply|go ahead|looks good|do it|use it)[.! ]*$/i;
const SKIP_RESPONSE_PATTERN = /^(skip|pass|next one|next)[.! ]*$/i;

// Migration Agent mode types
type MigrationAgentToolExecution = {
  toolId: string;
  tool: string;
  resource?: string;
  status: 'started' | 'completed' | 'error';
  startedAt: string;
  completedAt?: string;
  result?: string;
};

type MigrationAgentTraceEvent = {
  traceId: string;
  parentTraceId: string | null;
  kind: string;
  label: string;
  status: string;
  summary: string;
  timestamp: string;
  details: Record<string, unknown>;
};

type MigrationAgentMessage = {
  role: 'user' | 'assistant';
  content: string;
  id: string;
  kind?: 'progress' | 'final';
  researchQuestion?: boolean;
  // A supervisor heartbeat: live status that the next heartbeat replaces.
  heartbeat?: boolean;
  animate?: boolean;
  question?: { prompt: string; options: Array<{ label: string; description: string }> };
};

function confidenceColor(value: number): string {
  return value >= 0.9 ? "#15803d" : value >= 0.6 ? "#b45309" : "#b91c1c";
}

function QuestionChoiceButton({ label, description, recommended = false, confidence = null, disabled = false, onClick }: {
  label: string;
  description?: string;
  recommended?: boolean;
  confidence?: number | null;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <AiaButton
      variant="contained"
      title={description || label}
      customColor="#0f172a"
      customBackgroundColor={recommended ? "#eff6ff" : "#ffffff"}
      customHoverBackgroundColor="#f8fafc"
      customBorderColor={recommended ? "#93c5fd" : "#cbd5e1"}
      disabled={disabled}
      onClick={onClick}
      sx={{
        width: "100%", minWidth: 0, maxWidth: "100%", height: "auto", px: 1.5, py: 1,
        display: "block", textAlign: "left", textTransform: "none", whiteSpace: "normal",
        overflowWrap: "anywhere", wordBreak: "break-word", borderRadius: 1.5,
        "&:hover": { borderColor: "#60a5fa" },
      }}
    >
      <AiaBox component="span" sx={{ display: "block", minWidth: 0, maxWidth: "100%" }}>
        <AiaText component="span" sx={{ display: "block", fontSize: 13, fontWeight: 700, lineHeight: 1.4, overflowWrap: "anywhere" }}>
          {label}
        </AiaText>
        {description ? (
          <AiaText component="span" sx={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", mt: 0.25, fontSize: 11.5, lineHeight: 1.4, color: "#64748b", overflowWrap: "anywhere" }}>
            {description}
          </AiaText>
        ) : null}
        {recommended || confidence != null ? (
          <AiaBox component="span" sx={{ display: "flex", gap: 1, alignItems: "center", mt: 0.3 }}>
            {recommended ? <AiaText component="span" sx={{ fontSize: 10.5, color: "#2563eb", fontWeight: 700 }}>Recommended</AiaText> : null}
            {confidence != null ? (
              <AiaText component="span" sx={{ fontSize: 10.5, fontWeight: 700, color: confidenceColor(confidence) }}>
                {Math.round(confidence * 100)}% confidence
              </AiaText>
            ) : null}
          </AiaBox>
        ) : null}
      </AiaBox>
    </AiaButton>
  );
}

function progressWords(value: string): Set<string> {
  const ignored = new Set([
    'i', 'ill', 'will', 'let', 'me', 'now', 'continue', 'continuing', 'by', 'then',
    'the', 'a', 'an', 'and', 'with', 'proper', 'necessary', 'remaining', 'actual',
    'key', 'tables', 'table', 'get', 'getting', 'help', 'you', 'your', 'for', 'to',
  ]);
  return new Set(
    value.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/)
      .filter((word) => word && !ignored.has(word)),
  );
}

function isSimilarProgress(left: string, right: string): boolean {
  const leftWords = progressWords(left);
  const rightWords = progressWords(right);
  const union = new Set([...leftWords, ...rightWords]);
  if (!union.size) return true;
  const overlap = [...leftWords].filter((word) => rightWords.has(word)).length;
  return overlap / union.size >= 0.55;
}

function isSameVisibleMessage(left: string, right: string): boolean {
  const normalize = (value: string) => value.replace(/^\s*\[FINAL\]\s*/i, '').replace(/\s+/g, ' ').trim();
  return normalize(left) === normalize(right);
}

type MigrationPlanTodo = {
  content: string;
  status: string;
};

type MigrationAgentPendingPermission = MigrationAgentPermissionRequest & {
  contextHash: string;
};

type MigrationAgentModeState = {
  isActive: boolean;
  isConnecting: boolean;
  isConnected: boolean;
  isRunning: boolean;
  isCancelling: boolean;
  streamingText: string;
  statusMessage: string | null;
  toolExecutions: MigrationAgentToolExecution[];
  traceEvents: MigrationAgentTraceEvent[];
  pendingPermission: MigrationAgentPendingPermission | null;
  reviewItems: AgentReviewItem[];
  reviewContextHash: string;
  reviewArtifact: AgentSqlArtifact | null;
  error: string | null;
  resolvedEffort: Exclude<MigrationEffort, "auto"> | null;
};

// Only these review outcomes come from incomplete source research; other
// blocking items (e.g. a missing checkpoint) must not offer to resume research.
const SOURCE_RESEARCH_REVIEW_CATEGORIES = new Set([
  'source_preparation', 'source_research_choice', 'source_research_unavailable', 'source_join_path',
  'source_design_incomplete', 'supervisor_plan_required', 'research_boundary', 'evidence_preparation_failed',
]);

const initialMigrationAgentState: MigrationAgentModeState = {
  isActive: false,
  isConnecting: false,
  isConnected: false,
  isRunning: false,
  isCancelling: false,
  streamingText: '',
  statusMessage: null,
  toolExecutions: [],
  traceEvents: [],
  pendingPermission: null,
  reviewItems: [],
  reviewContextHash: '',
  reviewArtifact: null,
  error: null,
  resolvedEffort: null,
};

function planTodosFromEvent(event: MigrationAgentTraceEvent | undefined): MigrationPlanTodo[] {
  if (!event || !Array.isArray(event.details.todos)) return [];
  return event.details.todos
    .filter((item): item is Record<string, unknown> => !!item && typeof item === "object")
    .map((item) => ({
      content: String(item.content ?? item.label ?? "Planned work"),
      status: String(item.status ?? "pending").toLowerCase(),
    }));
}

function latestPlanEvent(events: MigrationAgentTraceEvent[]): MigrationAgentTraceEvent | undefined {
  return [...events].reverse().find((event) => Array.isArray(event.details.todos) && event.details.todos.length > 0);
}

function activeExecutionLabel(events: MigrationAgentTraceEvent[], fallback: string | null): string {
  const activeTodo = planTodosFromEvent(latestPlanEvent(events)).find((todo) => todo.status === "in_progress");
  if (activeTodo) return activeTodo.content;
  const runningEvent = [...events].reverse().find((event) => event.status === "running" && event.kind !== "run" && event.kind !== "plan");
  return runningEvent?.label || fallback || "Starting agent";
}

function MigrationPlanRows({ event, running }: { event: MigrationAgentTraceEvent; running: boolean }) {
  const todos = planTodosFromEvent(event);
  if (!todos.length) return null;
  return (
    <AiaBox sx={{ px: 1.25, py: 1.1 }}>
      <AiaStack spacing={0.8}>
        {todos.map((todo, index) => {
          const completed = todo.status === "completed";
          const active = todo.status === "in_progress";
          return (
            <AiaBox
              key={`${event.traceId}-plan-${index}`}
              sx={{
                position: "relative",
                overflow: "hidden",
                borderRadius: 1,
                px: active ? 0.85 : 0,
                py: active ? 0.65 : 0.15,
                ml: active ? -0.85 : 0,
                backgroundColor: active ? "color-mix(in srgb, var(--aia-button-color) 7%, #ffffff)" : "transparent",
                borderLeft: active ? "2px solid var(--aia-button-color)" : "2px solid transparent",
              }}
            >
              {active && running ? (
                <AiaBox
                  aria-hidden="true"
                  sx={{
                    position: "absolute",
                    inset: 0,
                    width: "38%",
                    background: "linear-gradient(90deg, transparent, color-mix(in srgb, var(--aia-button-color) 15%, transparent), transparent)",
                    animation: "agentStepSweep 1.8s ease-in-out infinite",
                    "@keyframes agentStepSweep": {
                      from: { transform: "translateX(-120%)" },
                      to: { transform: "translateX(360%)" },
                    },
                  }}
                />
              ) : null}
              <AiaStack direction="row" spacing={0.85} sx={{ position: "relative", alignItems: "flex-start" }}>
                <AiaBox
                  sx={{
                    mt: 0.28,
                    width: 14,
                    height: 14,
                    borderRadius: "50%",
                    display: "grid",
                    placeItems: "center",
                    flexShrink: 0,
                    border: completed ? "none" : `1px solid ${active ? "var(--aia-button-color)" : "#94a3b8"}`,
                    backgroundColor: completed ? "var(--aia-button-color)" : "#ffffff",
                    color: "#ffffff",
                  }}
                >
                  {completed ? "✓" : active && running ? (
                    <AiaBox sx={{ width: 6, height: 2, borderRadius: 999, backgroundColor: "var(--aia-button-color)" }} />
                  ) : null}
                </AiaBox>
                <AiaText
                  sx={{
                    fontSize: 11.75,
                    lineHeight: 1.45,
                    fontWeight: active ? 750 : 500,
                    color: completed ? "#64748b" : active ? "#0f172a" : "#475569",
                    textDecoration: completed ? "line-through" : "none",
                  }}
                >
                  {todo.content}
                </AiaText>
              </AiaStack>
            </AiaBox>
          );
        })}
      </AiaStack>
    </AiaBox>
  );
}

function planRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

function planList(value: unknown): string[] {
  return Array.isArray(value)
    ? value.map((item) => typeof item === "string" ? item : JSON.stringify(item)).filter(Boolean)
    : [];
}

function planRecords(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.map(planRecord).filter((item) => Object.keys(item).length > 0) : [];
}

function planTableLabel(value: unknown): string {
  if (typeof value === "string") return value;
  const table = planRecord(value);
  return [table.database, table.schema, table.table].filter(Boolean).map(String).join(".");
}

function migrationPlanTitle(plan: Record<string, unknown>): string {
  const mappings = planRecords(plan.mapping_specs);
  if (mappings.length > 1) return `Migration plan for ${mappings.length} mappings`;
  const target = planTableLabel(planRecord(plan.source_preparation).target_table);
  const name = target.split('.').at(-1)?.replace(/^"|"$/g, '').replace(/_/g, ' ').trim();
  if (!name || name.length > 72) return 'Migration plan';
  const readable = name === name.toUpperCase()
    ? name.toLowerCase().replace(/\b\w/g, letter => letter.toUpperCase())
    : name;
  return `${readable} mapping plan`;
}

function PlanName({ value, fallback = "—" }: { value: unknown; fallback?: string }) {
  const full = planTableLabel(value);
  const parts = full.split(".");
  return <AiaBox sx={{ minWidth: 0, overflowWrap: "anywhere" }}>
    <AiaText sx={{ fontSize: 12, fontWeight: 750, color: "#0f172a", lineHeight: 1.3 }}>
      {parts.pop() || fallback}
    </AiaText>
    {parts.length > 0 && <AiaText sx={{ fontSize: 10, color: "#64748b", lineHeight: 1.35 }}>
      {parts.join(" · ")}
    </AiaText>}
  </AiaBox>;
}

function PlanDataTable({ title, headers, rows, empty }: {
  title: string; headers: string[]; rows: React.ReactNode[][]; empty: string;
}) {
  return <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #e2e8f0" }}>
    <AiaText sx={{ mb: 0.65, fontSize: 12, fontWeight: 800, color: "#334155" }}>{title}</AiaText>
    {rows.length ? <AiaBox sx={{ width: "100%", overflowX: "auto", border: "1px solid #e2e8f0", borderRadius: 1 }}>
      <AiaBox component="table" sx={{ width: "100%", minWidth: 480, borderCollapse: "collapse", tableLayout: "fixed" }}>
        <AiaBox component="thead" sx={{ backgroundColor: "#f8fafc" }}>
          <AiaBox component="tr">{headers.map((header) => <AiaBox component="th" scope="col" key={header} sx={{ px: 1, py: 0.7, textAlign: "left", fontSize: 10, fontWeight: 800, color: "#64748b", borderBottom: "1px solid #e2e8f0" }}>{header}</AiaBox>)}</AiaBox>
        </AiaBox>
        <AiaBox component="tbody">{rows.map((cells, index) => <AiaBox component="tr" key={index} sx={{ borderBottom: index === rows.length - 1 ? "none" : "1px solid #e2e8f0" }}>
          {cells.map((cell, cellIndex) => <AiaBox component="td" key={cellIndex} sx={{ px: 1, py: 0.75, verticalAlign: "top", fontSize: 11, color: "#334155", lineHeight: 1.4, overflowWrap: "anywhere" }}>{cell}</AiaBox>)}
        </AiaBox>)}</AiaBox>
      </AiaBox>
    </AiaBox> : <AiaText sx={{ fontSize: 11, color: "#64748b" }}>{empty}</AiaText>}
  </AiaBox>;
}

function MigrationPlanApprovalSummary({ plan }: { plan: Record<string, unknown> }) {
  const project = planRecord(plan.project_decision);
  const preparation = planRecord(plan.source_preparation);
  const autoMap = planRecord(plan.auto_map);
  const drivingSource = String(preparation.driving_source ?? "To be selected from verified evidence");
  const target = String(preparation.target_table ?? autoMap.target_table ?? "To be selected from verified evidence");
  const supportingSources = planList(preparation.supporting_sources);
  const specialists = planList(autoMap.required_specialists ?? plan.agents);
  const validation = planList(autoMap.validation_gates ?? plan.validation_plan);
  const writes = planList(plan.planned_writes);
  const risks = planList(plan.risks);
  const executionSteps = planRecords(plan.execution_steps).sort(
    (left, right) => Number(left.sequence ?? 0) - Number(right.sequence ?? 0),
  );
  const relationships = planRecords(preparation.relationships);
  const derivedSources = planRecords(preparation.derived_sources);
  const valueBindings = planRecords(preparation.value_bindings);
  const targetColumns = planList(autoMap.target_columns);
  const mappingEvidence = planRecords(autoMap.mapping_evidence);
  const evidenceGaps = new Set(planList(autoMap.evidence_gaps).map((value) => value.toUpperCase()));
  const classifications = planRecord(autoMap.mapping_classifications);
  const selectedColumns = planRecord(preparation.selected_columns_by_table);
  const sourceRationale = planRecord(preparation.source_rationale);
  const precedent = planRecord(preparation.precedent_reference);

  const sourceRows: React.ReactNode[][] = [drivingSource, ...supportingSources].map((table, index) => [
    index === 0 ? "Driving" : "Supporting",
    <PlanName key={table} value={table} />,
    planList(selectedColumns[table]).length ? planList(selectedColumns[table]).join(", ") : "Columns to verify",
    String(sourceRationale[table] ?? (index === 0 ? "Defines the target row" : "Supporting evidence")),
  ]);
  const resultRows: React.ReactNode[][] = [[
    <PlanName key={target} value={target} />,
    `${targetColumns.length} target columns`,
    `${mappingEvidence.length} mapping candidates`,
    evidenceGaps.size ? `${evidenceGaps.size} evidence gaps` : "Evidence prepared",
  ]];
  const mappingRows: React.ReactNode[][] = targetColumns.map((column) => {
    const candidates = mappingEvidence.filter((item) => String(item.target_column ?? "").toUpperCase() === column.toUpperCase());
    return [
      <PlanName key={column} value={column} />,
      candidates.length ? <AiaStack key={`${column}-sources`} spacing={0.4}>{candidates.map((item, index) =>
        <AiaBox key={index}>{planList(item.source_columns).length
          ? planList(item.source_columns).map((sourceColumn) => <PlanName key={sourceColumn} value={sourceColumn} />)
          : String(item.mapping_mode ?? "Candidate rule")}</AiaBox>)}</AiaStack> : "Specialist research required",
      candidates.map((item) => String(item.transformation ?? item.transformation_rule ?? item.constant_value ?? "Direct")).join(" · ") || "—",
      String(classifications[column] ?? classifications[column.toUpperCase()] ?? "To classify"),
      candidates.map((item) => typeof item.confidence === "number" ? `${Math.round(item.confidence * 100)}%` : "—").join(" · ") || "—",
      candidates.map((item) => String(item.reasoning ?? item.rationale ?? item.reason ?? "")).filter(Boolean).join(" · ") || "—",
      evidenceGaps.has(column.toUpperCase()) ? "Evidence gap" : candidates.length
        ? candidates.map((item) => String(item.approval_state ?? item.evidence_source ?? "Proposed")).join(" · ")
        : "Proposed",
    ];
  });
  const joinRows: React.ReactNode[][] = relationships.map((relationship) => [
    <PlanName key="left" value={relationship.left_table} />,
    planRecords(relationship.conditions).map((condition) => {
      const left = String(condition.left_column ?? "?");
      const right = String(condition.right_column ?? "?");
      const alias = String(relationship.normalized_lookup_alternative ?? "");
      return alias ? `${left} matches ${right} or ${alias} (trim/uppercase)` : `${left} = ${right}`;
    }).join(" AND ") || "Keys to verify",
    <PlanName key="right" value={relationship.right_table} />,
    String(relationship.join_type ?? "JOIN"),
  ]);
  const cteRows: React.ReactNode[][] = derivedSources.map((derived) => [
    <PlanName key="name" value={derived.name} />,
    planList(derived.base_source_tables).map((table) => <PlanName key={table} value={table} />),
    String(derived.purpose ?? "Historical candidate"),
  ]);

  return (
    <AiaBox
      sx={{
        mt: 1,
        overflow: "hidden",
        border: "1px solid #e2e8f0",
        borderRadius: 1.5,
        backgroundColor: "#ffffff",
      }}
    >
      <AiaBox sx={{ px: 1.25, py: 0.8, borderBottom: "1px solid #e2e8f0", backgroundColor: "#f8fafc" }}>
        <AiaText sx={{ fontSize: 11.5, fontWeight: 800, color: "#475569" }}>
          Plan revision {String(plan.revision ?? 1)}
        </AiaText>
      </AiaBox>
      <AiaBox sx={{ px: 1.25, py: 0.8 }}>
        <AiaText sx={{ fontSize: 11, color: "#475569" }}>
          Project: {String(project.project_name ?? project.project_id ?? project.operation ?? "Create a draft")}
          {precedent.sttm_id ? ` · Precedent STTM ${String(precedent.sttm_id)} (${String(precedent.status ?? "unverified")})` : ""}
        </AiaText>
        <AiaText sx={{ mt: 0.25, fontSize: 10.5, color: "#64748b" }}>
          Sources, joins, mappings, and execution steps below define this plan. {specialists.length ? `Specialists: ${specialists.join(", ")}.` : ""}
        </AiaText>
      </AiaBox>
      {executionSteps.length ? (
        <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #f1f5f9" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Step-by-step execution plan</AiaText>
          <AiaText sx={{ mt: 0.2, mb: 0.8, fontSize: 10.5, lineHeight: 1.4, color: "#64748b" }}>
            Plan analysis is read-only. After approval, only run-owned drafts are created or updated.
          </AiaText>
          <AiaStack spacing={0.75}>
            {executionSteps.map((step, index) => {
              const sql = typeof step.sql === "string" ? step.sql.trim() : "";
              const beforeApproval = Boolean(step.runs_before_approval);
              const dynamicSql = Boolean(step.dynamic_sql);
              return (
                <AiaBox key={`${String(step.sequence ?? index)}-${String(step.title ?? "step")}`} sx={{ border: "1px solid #e2e8f0", borderRadius: 1, overflow: "hidden" }}>
                  <AiaBox sx={{ px: 1, py: 0.7, backgroundColor: beforeApproval ? "#f0f9ff" : "#f8fafc" }}>
                    <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#0f172a" }}>
                      {String(step.sequence ?? index + 1)}. {String(step.title ?? "Migration step")}
                    </AiaText>
                    <AiaText sx={{ mt: 0.15, fontSize: 10.5, lineHeight: 1.4, color: "#475569" }}>
                      {String(step.description ?? "")}
                    </AiaText>
                    <AiaText sx={{ mt: 0.35, fontSize: 9.75, fontWeight: 700, color: beforeApproval ? "#0369a1" : "#64748b" }}>
                      {beforeApproval ? "Read-only plan analysis" : "Runs after approval"}
                      {dynamicSql ? " · SQL generated from approved mappings" : ""}
                    </AiaText>
                  </AiaBox>
                  {sql ? (
                    <AiaBox component="details" sx={{ px: 1, py: 0.5 }}>
                      <AiaBox component="summary" sx={{ cursor: "pointer", fontSize: 11, color: "#475569" }}>View SQL</AiaBox>
                      <AiaBox
                        component="pre"
                        sx={{ m: 0, px: 1, py: 0.8, overflowX: "auto", whiteSpace: "pre-wrap", overflowWrap: "anywhere", backgroundColor: "#0f172a", color: "#e2e8f0", fontSize: 10, lineHeight: 1.45, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}
                      >
                        {sql}
                      </AiaBox>
                    </AiaBox>
                  ) : null}
                </AiaBox>
              );
            })}
          </AiaStack>
        </AiaBox>
      ) : null}
      {risks.length ? (
        <AiaBox sx={{ px: 1.25, py: 0.8, borderTop: "1px solid #fef3c7", backgroundColor: "#fffbeb" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#92400e" }}>Risks requiring attention</AiaText>
          <AiaBox component="ul" sx={{ mt: 0.35, mb: 0, pl: 2, fontSize: 12, lineHeight: 1.55, color: "#78350f" }}>
            {risks.map((item, index) => <li key={index}>{item}</li>)}
          </AiaBox>
        </AiaBox>
      ) : null}
      <AiaBox sx={{ px: 1.25, py: 0.8, borderTop: "1px solid #bbf7d0", backgroundColor: "#f0fdf4" }}>
        <AiaText sx={{ fontSize: 10.75, lineHeight: 1.4, fontWeight: 750, color: "#166534" }}>
          Approval does not publish the STTM and does not permit target-table DML.
        </AiaText>
      </AiaBox>
      <PlanDataTable title="Source tables" headers={["Role", "Table", "Selected columns", "Reason"]} rows={sourceRows} empty="No sources selected" />
      <PlanDataTable title="Result table" headers={["Target", "Columns", "Mappings", "Readiness"]} rows={resultRows} empty="No result table selected" />
      <PlanDataTable title={`Column mappings · ${targetColumns.length}`} headers={["Target column", "Source columns", "Rule or Firm Value", "Classification", "Confidence", "Reason", "Evidence"]} rows={mappingRows} empty="Target columns will be researched" />
      <PlanDataTable title={`Joins · ${relationships.length}`} headers={["From table", "Join keys", "To table", "Type"]} rows={joinRows} empty="No verified joins in this plan" />
      <PlanDataTable title={`Derived CTEs · ${derivedSources.length}`} headers={["CTE", "Source tables", "Purpose"]} rows={cteRows} empty="No derived CTE is planned" />
      {derivedSources.some((derived) => typeof derived.sql === "string" && derived.sql.trim()) &&
        <AiaBox sx={{ px: 1.25, pb: 1 }}>
          {derivedSources.filter((derived) => typeof derived.sql === "string" && derived.sql.trim()).map((derived, index) =>
            <AiaBox component="details" key={`${String(derived.name ?? "cte")}-${index}`} sx={{ mt: 0.5, fontSize: 11 }}>
              <AiaBox component="summary" sx={{ cursor: "pointer", fontWeight: 700 }}>{String(derived.name ?? "CTE")} SQL</AiaBox>
              <AiaBox component="pre" sx={{ p: 1, maxHeight: 200, overflow: "auto", whiteSpace: "pre-wrap", backgroundColor: "#0f172a", color: "#e2e8f0", fontSize: 10 }}>{String(derived.sql)}</AiaBox>
            </AiaBox>)}
        </AiaBox>}
      {valueBindings.length > 0 ? <AiaBox sx={{ px: 1.25, py: 1, borderTop: "1px solid #f1f5f9" }}>
        <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Firm and project values · {valueBindings.length}</AiaText>
        {valueBindings.map((binding) => <AiaText key={String(binding.name)} sx={{ mt: 0.45, fontSize: 10.5, lineHeight: 1.45, overflowWrap: "anywhere" }}>
          {String(binding.name)} → {planList(binding.target_columns).join(", ")} · {String(binding.resolution_status ?? "unresolved")}
          {binding.resolved_value != null ? ` · current value ${String(binding.resolved_value)}` : binding.candidate_value != null ? " · historical candidate requires review" : " · value required"}
          {` · ${String(binding.source ?? "unknown source")}`}
        </AiaText>)}
      </AiaBox> : null}
      {writes.length ? (
        <AiaBox sx={{ px: 1.25, py: 0.8, borderBottom: risks.length ? "1px solid #f1f5f9" : "none" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Planned draft writes</AiaText>
          <AiaBox component="ul" sx={{ mt: 0.35, mb: 0, pl: 2, fontSize: 12, lineHeight: 1.55, color: "#334155" }}>
            {writes.map((item, index) => <li key={index}>{item}</li>)}
          </AiaBox>
        </AiaBox>
      ) : null}
      {validation.length ? (
        <AiaBox sx={{ px: 1.25, py: 0.8, borderTop: "1px solid #f1f5f9" }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 800, color: "#475569" }}>Validation gates</AiaText>
          <AiaBox component="ul" sx={{ mt: 0.35, mb: 0, pl: 2, fontSize: 12, lineHeight: 1.55, color: "#334155" }}>
            {validation.map((item, index) => <li key={index}>{item}</li>)}
          </AiaBox>
        </AiaBox>
      ) : null}

    </AiaBox>
  );
}

function MigrationPlanStatusChip({
  event,
  running,
  waitingForAnswer,
  needsReview,
  hasDraft,
  activeLabel,
}: {
  event: MigrationAgentTraceEvent;
  running: boolean;
  waitingForAnswer: boolean;
  needsReview: boolean;
  hasDraft: boolean;
  activeLabel: string;
}) {
  const todos = planTodosFromEvent(event);
  if (!todos.length) return null;
  const activeIndex = todos.findIndex((todo) => todo.status === "in_progress");
  const firstPendingIndex = todos.findIndex((todo) => todo.status !== "completed");
  const currentStep = Math.max(1, (activeIndex >= 0 ? activeIndex : firstPendingIndex >= 0 ? firstPendingIndex : todos.length - 1) + 1);
  const allComplete = todos.every((todo) => todo.status === "completed");

  return (
    <AiaBox
      sx={{
        position: "relative",
        zIndex: 5,
        display: "flex",
        justifyContent: "center",
        px: 1,
        pb: 0.75,
        "&:hover .migration-plan-popover, &:focus-within .migration-plan-popover": {
          opacity: 1,
          visibility: "visible",
          transform: "translate(-50%, 0)",
          pointerEvents: "auto",
        },
      }}
    >
      <AiaButton
        size="small"
        variant="outlined"
        aria-label={`Show execution plan. Step ${currentStep} of ${todos.length}: ${activeLabel}`}
        sx={{
          maxWidth: "92%",
          minHeight: 30,
          px: 1.25,
          borderRadius: 999,
          borderColor: "#cbd5e1",
          backgroundColor: "#ffffff",
          color: "#334155",
          textTransform: "none",
          boxShadow: "0 2px 8px rgba(15, 23, 42, 0.06)",
          "&:hover": { borderColor: "#94a3b8", backgroundColor: "#f8fafc" },
        }}
      >
        <AiaStack direction="row" spacing={0.75} sx={{ minWidth: 0, alignItems: "center" }}>
          {running ? (
            <AiaBox sx={{ width: 16, height: 3, borderRadius: 999, overflow: "hidden", backgroundColor: "#dbe2ea", flexShrink: 0 }}>
              <AiaBox
                aria-hidden="true"
                sx={{
                  width: "55%",
                  height: "100%",
                  borderRadius: 999,
                  backgroundColor: "var(--aia-button-color)",
                  animation: "agentPlanChipSweep 1.45s ease-in-out infinite alternate",
                  "@keyframes agentPlanChipSweep": {
                    from: { transform: "translateX(0)" },
                    to: { transform: "translateX(82%)" },
                  },
                }}
              />
            </AiaBox>
          ) : (
            <AiaBox sx={{ color: needsReview ? "#b45309" : allComplete ? "#15803d" : "#64748b", fontSize: 12, fontWeight: 800, lineHeight: 1 }}>
              {needsReview ? "!" : allComplete ? "✓" : "·"}
            </AiaBox>
          )}
          <AiaText sx={{ fontSize: 11.5, fontWeight: 750, whiteSpace: "nowrap" }}>
            Step {currentStep} / {todos.length}
          </AiaText>
          <AiaText noWrap sx={{ minWidth: 0, maxWidth: 190, fontSize: 11, color: "#64748b" }}>
            · {running ? activeLabel : waitingForAnswer ? "Waiting for your answer" : needsReview ? (hasDraft ? "Draft results" : "Research findings") : allComplete ? "Complete" : "Stopped"}
          </AiaText>
        </AiaStack>
      </AiaButton>
      <AiaPaper
        className="migration-plan-popover"
        role="tooltip"
        elevation={8}
        sx={{
          position: "absolute",
          left: "50%",
          bottom: "calc(100% + 6px)",
          width: "min(430px, calc(100vw - 40px))",
          maxHeight: "min(430px, 55vh)",
          overflowY: "auto",
          overscrollBehavior: "contain",
          opacity: 0,
          visibility: "hidden",
          pointerEvents: "none",
          transform: "translate(-50%, 6px)",
          transition: "opacity 140ms ease, transform 140ms ease, visibility 140ms ease",
          border: "1px solid #dbe2ea",
          borderRadius: 2,
          backgroundColor: "#ffffff",
        }}
      >
        <AiaBox sx={{ px: 1.5, pt: 1.25 }}>
          <AiaText sx={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>Execution plan</AiaText>
          <AiaText sx={{ mt: 0.15, fontSize: 10.5, color: "#64748b" }}>
            {running ? `Currently working on ${activeLabel}` : waitingForAnswer ? "The agent will continue from this step after your answer." : needsReview ? "Execution stopped for review; remaining steps were not run." : allComplete ? "All planned steps are complete." : "Execution stopped before all steps completed."}
          </AiaText>
        </AiaBox>
        <MigrationPlanRows event={event} running={running} />
      </AiaPaper>
    </AiaBox>
  );
}

function MigrationRunStatusChip({ label }: { label: string }) {
  return (
    <AiaBox sx={{ display: "flex", justifyContent: "center", px: 1, pb: 0.75 }}>
      <AiaPaper
        elevation={0}
        role="status"
        aria-live="polite"
        sx={{
          position: "relative",
          maxWidth: "92%",
          minHeight: 30,
          px: 1.25,
          display: "flex",
          alignItems: "center",
          overflow: "hidden",
          borderRadius: 999,
          border: "1px solid #cbd5e1",
          backgroundColor: "#ffffff",
          boxShadow: "0 2px 8px rgba(15, 23, 42, 0.06)",
        }}
      >
        <AiaBox
          aria-hidden="true"
          sx={{
            position: "absolute",
            inset: 0,
            width: "36%",
            background: "linear-gradient(90deg, transparent, color-mix(in srgb, var(--aia-button-color) 12%, transparent), transparent)",
            animation: "agentRunStatusSweep 1.6s ease-in-out infinite",
            "@keyframes agentRunStatusSweep": {
              from: { transform: "translateX(-120%)" },
              to: { transform: "translateX(360%)" },
            },
          }}
        />
        <AiaStack direction="row" spacing={0.75} sx={{ position: "relative", minWidth: 0, alignItems: "center" }}>
          <AiaBox sx={{ width: 16, height: 3, borderRadius: 999, overflow: "hidden", backgroundColor: "#dbe2ea", flexShrink: 0 }}>
            <AiaBox sx={{ width: "55%", height: "100%", borderRadius: 999, backgroundColor: "var(--aia-button-color)" }} />
          </AiaBox>
          <AiaText noWrap sx={{ minWidth: 0, maxWidth: 280, fontSize: 11.5, fontWeight: 750, color: "#334155" }}>
            {label}
          </AiaText>
        </AiaStack>
      </AiaPaper>
    </AiaBox>
  );
}

function TraceDetailValue({ value, depth = 0 }: { value: unknown; depth?: number }) {
  if (value == null) return <AiaText sx={{ fontSize: 11, color: '#64748b' }}>Not supplied</AiaText>;
  if (typeof value !== 'object') return <AiaText sx={{ fontSize: 11, color: '#475569', whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{String(value)}</AiaText>;
  const entries = Object.entries(value);
  if (depth >= 4) return <AiaText sx={{ fontSize: 11, color: '#64748b' }}>{entries.length} detail fields</AiaText>;
  return <AiaStack spacing={0.5} sx={{ minWidth: 0 }}>
    {entries.map(([key, item]) => <AiaBox key={key} sx={{ minWidth: 0, pl: depth ? 1 : 0 }}>
      {!Array.isArray(value) ? <AiaText sx={{ fontSize: 10.5, fontWeight: 600, color: '#64748b' }}>{key.replace(/_/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2')}</AiaText> : null}
      <TraceDetailValue value={item} depth={depth + 1} />
    </AiaBox>)}
  </AiaStack>;
}

function MigrationTraceTree({
  events,
  running,
  parentTraceId = null,
  depth = 0,
}: {
  events: MigrationAgentTraceEvent[];
  running: boolean;
  parentTraceId?: string | null;
  depth?: number;
}) {
  const knownTraceIds = new Set(events.map((event) => event.traceId));
  const nodes = events.filter((event) =>
    event.parentTraceId === parentTraceId
    || (parentTraceId === null && event.parentTraceId !== null && !knownTraceIds.has(event.parentTraceId)),
  );
  if (!nodes.length) return null;
  return (
    <AiaStack spacing={0.5} sx={{ pl: depth ? 1.5 : 0 }}>
      {nodes.map((event) => {
        const children = events.some((candidate) => candidate.parentTraceId === event.traceId);
        const detailEntries = Object.entries(event.details).filter(([key, value]) => key !== "todos" && !/(?:hash|digest)$/i.test(key) && value !== undefined && value !== null);
        const expandable = children || detailEntries.length > 0;
        return (
          <AiaBox
            key={event.traceId}
            component={expandable ? "details" : "div"}
            sx={{ borderLeft: depth ? "1px solid #dbe2ea" : "none", pl: depth ? 1 : 0 }}
          >
            <AiaBox
              component={expandable ? "summary" : "div"}
              sx={{ cursor: expandable ? "pointer" : "default", listStyle: "none", py: 0.5 }}
            >
              <AiaStack direction="row" spacing={0.8} sx={{ alignItems: "center" }}>
                {event.status === "running" && running ? (
                  <AiaBox
                    sx={{
                      width: 8,
                      height: 8,
                      borderRadius: "50%",
                      flexShrink: 0,
                      backgroundColor: "var(--aia-button-color)",
                      animation: "agentEventPulse 1.25s ease-in-out infinite alternate",
                      "@keyframes agentEventPulse": { from: { opacity: 0.35 }, to: { opacity: 1 } },
                    }}
                  />
                ) : (
                  <AiaBox sx={{ width: 8, height: 8, borderRadius: "50%", flexShrink: 0, backgroundColor: event.status === "succeeded" ? "#22c55e" : event.status === "needs_review" ? "#f59e0b" : event.status === "failed" ? "#ef4444" : "#64748b" }} />
                )}
                <AiaText sx={{ fontSize: 12, fontWeight: 700, color: "var(--aia-primary-text-color)" }}>{event.label}</AiaText>
                <AiaText sx={{ fontSize: 11, color: "#64748b" }}>{event.kind}</AiaText>
              </AiaStack>
              <AiaText sx={{ ml: 2, fontSize: 11, color: "#6b7280" }}>{event.summary}</AiaText>
            </AiaBox>
            {detailEntries.length > 0 && (
              <AiaBox sx={{ ml: 2, my: 0.5, p: 1, maxHeight: 300, borderRadius: 1, backgroundColor: '#f8fafc', overflow: 'auto', overscrollBehavior: 'contain' }}>
                <TraceDetailValue value={Object.fromEntries(detailEntries)} />
              </AiaBox>
            )}
            {children && <MigrationTraceTree events={events} running={running} parentTraceId={event.traceId} depth={depth + 1} />}
          </AiaBox>
        );
      })}
    </AiaStack>
  );
}

function formatInterpretationMessage(content: string) {
  const normalized = content.replace(/\r\n/g, "\n").trim();
  const prefix = "This is our interpretation of your question:";
  if (!normalized.startsWith(prefix)) {
    return content;
  }

  const body = normalized.slice(prefix.length).trim();
  if (!body) return content;

  const sentences = body
    .split(/(?<=[.!?])\s+/)
    .map((sentence) => sentence.trim())
    .filter(Boolean);

  if (sentences.length === 0) return content;

  const lines = ["## Interpretation"];
  if (sentences[0]) {
    lines.push(`- **Goal:** ${sentences[0]}`);
  }
  if (sentences[1]) {
    lines.push(`- **Approach:** ${sentences[1]}`);
  }
  if (sentences.length > 2) {
    lines.push(`- **Notes:** ${sentences.slice(2).join(" ")}`);
  }
  return lines.join("\n");
}

function MessageContent({ content, formatPlainText = false }: { content: string; formatPlainText?: boolean }) {
  const normalized = formatInterpretationMessage(content).replace(/\r\n/g, "\n").trim();
  void formatPlainText;
  return <AssistantMarkdown content={normalized} />;
}

function TypewriterMessageContent({
  content,
  animate,
  messageId,
  onComplete,
  onProgress,
}: {
  content: string;
  animate: boolean;
  messageId: string;
  onComplete: (messageId: string) => void;
  onProgress: () => void;
}) {
  const [visibleLength, setVisibleLength] = useState(animate ? 0 : content.length);

  useEffect(() => {
    if (!animate || !content) return;
    const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    let animationFrame = 0;
    if (reduceMotion) {
      animationFrame = window.requestAnimationFrame(() => {
        setVisibleLength(content.length);
        onComplete(messageId);
      });
      return () => window.cancelAnimationFrame(animationFrame);
    }

    const startedAt = performance.now();
    // Keep short updates visibly character-streamed while preventing a long,
    // Markdown-rich final answer from taking minutes to finish rendering.
    const durationMs = Math.min(8_000, Math.max(320, content.length * 11));
    const reveal = (now: number) => {
      const progress = Math.min(1, (now - startedAt) / durationMs);
      const nextLength = Math.min(content.length, Math.max(1, Math.ceil(content.length * progress)));
      setVisibleLength(nextLength);
      onProgress();
      if (progress < 1) {
        animationFrame = window.requestAnimationFrame(reveal);
      } else {
        onComplete(messageId);
      }
    };

    animationFrame = window.requestAnimationFrame(reveal);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [animate, content, messageId, onComplete, onProgress]);

  const typing = animate && visibleLength < content.length;
  return <MessageContent content={`${animate ? content.slice(0, visibleLength) : content}${typing ? "▌" : ""}`} />;
}

function buildSignalUnderstandingText(signal: {
  attributes?: Record<string, unknown>;
  message?: string;
}) {
  const value = signal.attributes?.current_understanding;
  if (typeof value === "string" && value.trim()) {
    const understanding = value.trim();
    const normalize = (text: string) =>
      text
        .toLowerCase()
        .replace(/[`*_#>]/g, "")
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
    const normalizedUnderstanding = normalize(understanding);
    const normalizedMessage = normalize(signal.message ?? "");
    const repeatsMessage =
      normalizedUnderstanding.length >= 48 &&
      (normalizedMessage === normalizedUnderstanding ||
        normalizedMessage.includes(normalizedUnderstanding) ||
        normalizedUnderstanding.includes(normalizedMessage));
    return repeatsMessage ? null : understanding;
  }
  return null;
}

function shouldSuppressSignalForCurrentState(
  signal: {
    attributes?: Record<string, unknown>;
  },
  relationshipCount: number,
) {
  if (relationshipCount === 0) return false;
  const actionType = typeof signal.attributes?.action_type === "string" ? signal.attributes.action_type : "";
  return actionType === "refresh_semantic_context";
}

function StreamingProgressIndicator({
  phase,
  message,
  elapsedSeconds,
}: {
  phase?: StreamingStatusPhase | null;
  message?: string | null;
  elapsedSeconds?: number | null;
}) {
  const label = phase ? STATUS_PHASE_LABELS[phase] : "Working...";
  const progress = phase ? STATUS_PHASE_PROGRESS[phase] : 50;

  return (
    <AiaStack spacing={1} sx={{ mt: 1.25 }}>
      <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
        <AiaCircularProgress
          size={16}
          thickness={5}
          variant="determinate"
          value={progress}
          sx={{ color: "#2563eb" }}
        />
        <AiaText variant="caption" sx={{ color: "#1d4ed8", fontWeight: 600 }}>
          {label}
        </AiaText>
        {elapsedSeconds != null && elapsedSeconds > 0 ? (
          <AiaText variant="caption" sx={{ color: "#94a3b8", fontSize: 11 }}>
            ({Math.round(elapsedSeconds)}s)
          </AiaText>
        ) : null}
      </AiaStack>
      {message && message !== label ? (
        <AiaText variant="caption" sx={{ color: "#64748b", fontSize: 12, lineHeight: 1.4 }}>
          {message}
        </AiaText>
      ) : null}
      <AiaBox sx={{ width: "100%", height: 3, backgroundColor: "#e2e8f0", borderRadius: 2, overflow: "hidden" }}>
        <AiaBox
          sx={{
            width: `${progress}%`,
            height: "100%",
            backgroundColor: "#2563eb",
            borderRadius: 2,
            transition: "width 0.3s ease-in-out",
          }}
        />
      </AiaBox>
    </AiaStack>
  );
}

function TracePanel({
  messageId,
  steps,
  expanded,
  onToggle,
}: {
  messageId: string;
  steps: string[];
  expanded: boolean;
  onToggle: (messageId: string) => void;
}) {
  return (
    <AiaBox
      sx={{
        mt: 1.25,
        borderRadius: 1.5,
        border: "1px solid #e2e8f0",
        backgroundColor: "#f8fafc",
        overflow: "hidden",
      }}
    >
      <AiaButton
        onClick={() => onToggle(messageId)}
        variant="text"
        sx={{
          width: "100%",
          px: 1.25,
          py: 0.9,
          justifyContent: "space-between",
          textTransform: "none",
          color: "#334155",
          borderRadius: 0,
          "&:hover": { backgroundColor: "#f1f5f9" },
        }}
      >
        <AiaStack direction="row" spacing={0.75} sx={{ alignItems: "center" }}>
          {expanded ? (
            <KeyboardArrowDownIcon sx={{ fontSize: 16, color: "#64748b" }} />
          ) : (
            <KeyboardArrowRightIcon sx={{ fontSize: 16, color: "#64748b" }} />
          )}
          <AiaText sx={{ fontSize: 12, fontWeight: 700, color: "#334155" }}>
            Execution
          </AiaText>
          <AiaText sx={{ fontSize: 12, color: "#64748b" }}>
            {steps.length} step{steps.length === 1 ? "" : "s"}
          </AiaText>
        </AiaStack>
      </AiaButton>
      {expanded ? (
        <AiaStack spacing={0.8} sx={{ px: 1.5, pb: 1.25, pt: 0.25 }}>
          {steps.map((step, stepIndex) => (
            <AiaStack
              key={`${messageId}-trace-${stepIndex}`}
              direction="row"
              spacing={1}
              sx={{ alignItems: "flex-start" }}
            >
              <AiaBox
                sx={{
                  mt: 0.6,
                  width: 5,
                  height: 5,
                  borderRadius: "50%",
                  backgroundColor: "#94a3b8",
                  flexShrink: 0,
                }}
              />
              <AiaText sx={{ fontSize: 12, lineHeight: 1.6, color: "#475569" }}>
                {step}
              </AiaText>
            </AiaStack>
          ))}
        </AiaStack>
      ) : null}
    </AiaBox>
  );
}

export default function AIAgentPanel({
  expanded = false,
  variant = "standalone",
  pageMode = false,
  hideComposer = false,
}: {
  expanded?: boolean;
  onToggleExpanded?: () => void;
  variant?: "standalone" | "sidebar";
  pageMode?: boolean;
  hideComposer?: boolean;
}) {
  const router = useRouter();
  const {
    assistantSignals,
    firRecommendations,
    firPrimaryQuestion,
    firRecommendationLoading,
    firRecommendationContextKey,
    chatLoading,
    chatMessages,
    dismissPendingDerivedSourceDraft,
    applyPendingAiMappingReview,
    skipPendingAiMappingReview,
    mappingCount,
    openPendingDerivedSourceDraft,
    pendingDerivedSourceDraft,
    pendingAiMappingReviews,
    relationships,
    semanticBundleLabel,
    semanticBundleId,
    semanticBundleHash,
    semanticContextItems,
    semanticLineage,
    semanticDatahubContext,
    learningContextId,
    learningContextHash,
    workspaceContextId,
    workspaceContextHash,
    workspaceContextStatus,
    workspaceContextCacheStatus,
    workspaceContextError,
    semanticLevel,
    semanticStatus,
    semanticViewName,
    selectedSourceCount,
    respondToAssistantSignal,
    requestSemanticRefresh,
    refreshPreparedWorkspaceContext,
    sendChatMessage,
    resetChatSession,
    submitChatFeedback,
    // For Migration Agent snapshot building
    sources,
    targets,
    drivingTableId,
    derivedSources,
    mappings,
    selectedMappingIds,
    session,
    sourceAttributeGroups,
    activeProjectId,
    activeSttmId,
    activeProjectName,
    activeSttmName,
    mappingIntent,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    activeMappingId,
  } = useSttmBuilderContext();
  const store = useStore<RootState>();
  const {
    selectedRecommendationId,
    resolvedRecommendationIds,
    markRecommendationResolved,
    newChatVersion,
    agentPageProjectId,
    sessions,
    activeSessionId,
  } = useAiChatLayout();
  const pathname = usePathname();
  const [draft, setDraft] = useState("");
  const [otherAnswerOpen, setOtherAnswerOpen] = useState(false);
  const [otherAnswer, setOtherAnswer] = useState("");
  const [greetingSession, setGreetingSession] = useState<UserSession | null>(null);
  const [panelMode, setPanelMode] = useState<"assistant" | "recommendations">("assistant");
  const [pendingCorrectionRecommendation, setPendingCorrectionRecommendation] =
    useState<FIRRecommendation | null>(null);
  const [expandedTraces, setExpandedTraces] = useState<Record<string, boolean>>({});
  const [pendingSignalResponses, setPendingSignalResponses] = useState<Record<string, { optionSelected?: string | null; rating?: number | null; comment: string }>>({});
  const [signalActionBusyId, setSignalActionBusyId] = useState<string | null>(null);
  const messagesRef = useRef<HTMLDivElement | null>(null);
  const messageContentRef = useRef<HTMLDivElement | null>(null);
  const scrollStatesRef = useRef(new Map<string, AssistantScrollState>());
  const [showJumpToLatest, setShowJumpToLatest] = useState(false);
  const scrollScope = JSON.stringify([activeProjectId, activeSttmId, variant, pageMode]);
  const syncMessageScroll = useCallback((event: AssistantScrollEvent = 'layout') => {
    const node = messagesRef.current;
    if (!node) return;
    const next = updateAssistantScroll(scrollStatesRef.current.get(scrollScope), {
      scrollTop:node.scrollTop,scrollHeight:node.scrollHeight,clientHeight:node.clientHeight,
    },event);
    scrollStatesRef.current.set(scrollScope,next.state);
    if(Math.abs(node.scrollTop-next.scrollTop)>1)node.scrollTop=next.scrollTop;
    setShowJumpToLatest(next.showJump);
  },[scrollScope]);
  useLayoutEffect(()=>{syncMessageScroll();});
  useEffect(()=>{
    const node=messagesRef.current,content=messageContentRef.current;
    if(!node||!content||typeof ResizeObserver==='undefined')return;
    const observer=new ResizeObserver(()=>syncMessageScroll());
    observer.observe(node);observer.observe(content);
    return()=>observer.disconnect();
  },[syncMessageScroll]);
  const shownRecommendationIdsRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    let cancelled = false;
    void authService.getSession()
      .then((current) => { if (!cancelled) setGreetingSession(current); })
      .catch(() => undefined);
    return () => { cancelled = true; };
  }, []);
  const assistantFirstName = useMemo(() => {
    const rawName =
      session?.display_name?.trim()
      || greetingSession?.display_name?.trim()
      || session?.email?.split("@")[0]?.trim()
      || greetingSession?.email?.split("@")[0]?.trim()
      || "";
    const firstToken = rawName.split(/[\s._-]+/).find(Boolean) || "";
    if (!firstToken) return "";
    return `${firstToken.charAt(0).toUpperCase()}${firstToken.slice(1).toLowerCase()}`;
  }, [session?.display_name, session?.email, greetingSession?.display_name, greetingSession?.email]);
  const hasStartedStandardConversation = useMemo(
    () => chatMessages.some((message) => message.role === "user"),
    [chatMessages],
  );
  const visibleStandardChatMessages = useMemo(
    () => (
      hasStartedStandardConversation
        ? chatMessages.filter(
            (message) => !(
              message.role === "assistant"
              && (
                message.id === "sttm-assistant-welcome"
                || message.content.includes(
                  "I can use the selected source and target semantics",
                )
              )
            ),
          )
        : chatMessages
    ),
    [chatMessages, hasStartedStandardConversation],
  );

  // Migration Agent mode state
  const [migrationAgentState, setMigrationAgentState] = useState<MigrationAgentModeState>(initialMigrationAgentState);
  const [publishConfirmOpen, setPublishConfirmOpen] = useState(false);
  const [publishBusy, setPublishBusy] = useState(false);
  const [publishMessage, setPublishMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [reviewDecisionBusy, setReviewDecisionBusy] = useState(false);
  const reviewAnswerInFlight = useRef(false);
  const lastQuestionIdRef = useRef<string | null>(null);
  const [pendingDeepMessages, setPendingDeepMessages] = useState<PendingDeepMessage[]>([]);
  const [inboxError, setInboxError] = useState<string | null>(null);
  const [reviewDecisionError, setReviewDecisionError] = useState<string | null>(null);
  const [reviewTable, setReviewTable] = useState<ReviewTable | null>(null);
  const [selectedReviewItemId, setSelectedReviewItemId] = useState<string | null>(null);
  // The review table is read once a run stops, and again after each answer.
  useEffect(() => {
    const client = migrationAgentClientRef.current;
    if (!migrationAgentState.isActive || migrationAgentState.isRunning || !client) return;
    let cancelled = false;
    void client.fetchReviewTable()
      .then((table) => { if (!cancelled) setReviewTable(table); })
      .catch(() => { if (!cancelled) setReviewTable(null); });
    return () => { cancelled = true; };
  }, [migrationAgentState.isActive, migrationAgentState.isRunning, migrationAgentState.reviewItems]);
  const [migrationAgentMessages, setMigrationAgentMessages] = useState<MigrationAgentMessage[]>([]);
  const [expandedToolExecutions, setExpandedToolExecutions] = useState(true);
  const migrationAgentClientRef = useRef<MigrationAgentSessionClient | null>(null);
  const animateMigrationAgentMessagesRef = useRef(false);
  const [migrationAgentAvailable, setMigrationAgentAvailable] = useState<boolean | null>(null); // null = loading
  const [migrationEffort, setMigrationEffort] = useState<MigrationEffort>("medium");
  const [migrationModelName, setMigrationModelName] = useState<string | null>(null);
  const [migrationModelOptions, setMigrationModelOptions] = useState<string[]>([]);
  const [migrationEffortModels, setMigrationEffortModels] = useState<Record<string, string>>({});
  const [migrationRunMode, setMigrationRunMode] = useState<MigrationRunMode>("auto");
  const [planDocument, setPlanDocument] = useState<Record<string, unknown> | null>(null);
  const [dismissedPlanKey, setDismissedPlanKey] = useState<string | null>(null);
  const planKey = planDocument ? String(planDocument.plan_hash || planDocument.plan_id || planDocument.revision || '') : null;
  const planTitle = planDocument ? migrationPlanTitle(planDocument) : '';
  const showPlanPreview = dismissedPlanKey !== planKey;
  const [planSidebarOpen, setPlanSidebarOpen] = useState(false);
  const [artifactTab, setArtifactTab] = useState<AgentArtifactTab>('plan');
  const [sqlArtifact, setSqlArtifact] = useState<AgentSqlArtifact | null>(null);
  const [artifactVersion, setArtifactVersion] = useState(0);
  const requestedArtifactRef = useRef<AgentArtifactTab | null>(null);
  const researchReport = useMemo(() => [...migrationAgentMessages].reverse().find(
    (message) => message.role === 'assistant' && message.kind === 'final',
  )?.content?.replace(/Questions to resolve/g, 'Remaining research')
    .replace(/The plan needs at least one in-scope mapping candidate\. Set allow_partial_coverage to present the remaining columns explicitly for review\./g, 'The agent has not finished preparing supported column mappings. The researched tables are saved.') ?? '', [migrationAgentMessages]);
  const projectCreation = [...migrationAgentState.traceEvents].reverse().find((event) =>
    event.status === 'succeeded' && event.traceId.startsWith('tool:create_project_setup:'),
  );
  const createdProject = planRecord(planRecord(projectCreation?.details.result_preview).project);
  const createdProjectId = String(createdProject.project_id ?? '');
  const finalSqlArtifacts = useMemo(() => [...migrationAgentMessages].reverse()
    .filter((message) => message.role === 'assistant' && message.kind === 'final')
    .map((message) => separateSqlPreview(message.content).artifacts)
    .find((artifacts) => artifacts.length > 0) ?? [], [migrationAgentMessages]);
  const standaloneSql = researchReport.match(/```sql\s*\n([\s\S]+?)```/i)?.[1]?.trim();
  const visibleSqlArtifact = useMemo<AgentSqlArtifact | null>(() => {
    if (sqlArtifact || finalSqlArtifacts.length) return sqlArtifact ?? finalSqlArtifacts[0];
    if (!standaloneSql) return null;
    return {
      sql: standaloneSql, compileValid: false, previewValid: false,
      previewColumns: [], previewRows: [], previewRowCount: 0, mappedCount: 0, unresolvedCount: 0,
    };
  }, [sqlArtifact, finalSqlArtifacts, standaloneSql]);
  const openReviewArtifact = useCallback((tab: AgentArtifactTab) => {
    if (pageMode) {
      setArtifactTab(tab);
      setPlanSidebarOpen(true);
      return;
    }
    const conversationId = migrationAgentClientRef.current?.getConversationId()
      || sessions.find((session) => session.id === activeSessionId)?.backendConversationId;
    const params = new URLSearchParams({ artifact: tab });
    if (conversationId) params.set('conversation', conversationId);
    router.push(`/ai-agent?${params.toString()}`);
  }, [pageMode, router, sessions, activeSessionId]);
  const [pendingPlanOffer, setPendingPlanOffer] = useState<{ reason: string } | null>(null);
  const [migrationAttachments, setMigrationAttachments] = useState<Array<{ id: string; name: string }>>([]);
  const [migrationAttachmentUploading, setMigrationAttachmentUploading] = useState(false);
  const migrationPlanEvent = useMemo(
    () => latestPlanEvent(migrationAgentState.traceEvents),
    [migrationAgentState.traceEvents],
  );
  const migrationActiveLabel = useMemo(
    () => activeExecutionLabel(migrationAgentState.traceEvents, migrationAgentState.statusMessage),
    [migrationAgentState.statusMessage, migrationAgentState.traceEvents],
  );
  const migrationRunProgress = useMemo(
    () => latestRunProgress(migrationAgentState.traceEvents),
    [migrationAgentState.traceEvents],
  );
  const [migrationContextUsage, setMigrationContextUsage] = useState<ContextUsage | null>(null);
  const groupedMigrationAgentMessages = useMemo(() => {
    const groups: Array<{
      role: 'user' | 'assistant';
      id: string;
      messages: MigrationAgentMessage[];
    }> = [];
    for (const message of migrationAgentMessages) {
      const previous = groups[groups.length - 1];
      if (message.role === 'assistant' && previous?.role === 'assistant') {
        previous.messages.push(message);
      } else {
        groups.push({ role: message.role, id: message.id, messages: [message] });
      }
    }
    for (const group of groups) {
      if (group.role === 'assistant') {
        group.messages.sort((left, right) => Number(left.kind === 'final') - Number(right.kind === 'final'));
      }
    }
    return groups;
  }, [migrationAgentMessages]);
  const completeMigrationAgentMessageAnimation = useCallback((messageId: string) => {
    setMigrationAgentMessages((messages) => messages.map((message) => (
      message.id === messageId && message.animate
        ? { ...message, animate: false }
        : message
    )));
  }, []);
  const followMigrationAgentMessageAnimation = useCallback(() => {
    syncMessageScroll();
  }, [syncMessageScroll]);

  // Check Migration Agent availability on mount
  useEffect(() => {
    const checkMigrationAgentStatus = async () => {
      const diagnostics = await fetchMigrationAgentDiagnostics();
      setMigrationAgentAvailable(diagnostics.status === "ok" && diagnostics.enabled);
      setMigrationModelOptions(diagnostics.model_options ?? []);
      setMigrationEffortModels(diagnostics.effort_model_defaults ?? {});
    };
    void checkMigrationAgentStatus();
  }, []);

  const statsLabel = useMemo(() => {
    const joinCount = relationships.length;
    const joinLabel = joinCount === 1 ? "1 relationship" : `${joinCount} relationships`;
    return `${selectedSourceCount} tables · ${mappingCount} mappings · ${joinLabel}`;
  }, [mappingCount, relationships.length, selectedSourceCount]);
  const hasStreamingMessage = useMemo(
    () => chatMessages.some((message) => message.isStreaming),
    [chatMessages]
  );
  const activeReview = pendingAiMappingReviews[0] ?? null;
  const isTransformationReview = !!activeReview?.preprocessingRule;
  const activeSignal = useMemo(
    () =>
      assistantSignals.find(
        (signal) =>
          signal.source !== "conversation_agent" &&
          signal.status !== "dismissed" &&
          signal.status !== "responded" &&
          signal.status !== "acknowledged" &&
          !shouldSuppressSignalForCurrentState(signal, relationships.length),
      ) ?? null,
    [assistantSignals, relationships.length],
  );
  const showWelcomeHero =
    (migrationAgentState.isActive ? migrationAgentMessages.length === 0 : !hasStartedStandardConversation)
    && !selectedRecommendationId
    && !activeSignal
    && !activeReview
    && (variant === "sidebar" || panelMode === "assistant");
  const visibleFirRecommendations = useMemo(
    () =>
      firRecommendations.filter(
        (item) =>
          !resolvedRecommendationIds.has(item.recommendation_id),
      ),
    [
      firRecommendations,
      resolvedRecommendationIds,
    ],
  );
  const selectedRecommendation = useMemo(() => {
    if (!selectedRecommendationId) return null;
    if (
      firPrimaryQuestion?.recommendation_id === selectedRecommendationId
      && !resolvedRecommendationIds.has(selectedRecommendationId)
    ) {
      return firPrimaryQuestion;
    }
    return (
      firRecommendations.find(
        (item) =>
          item.recommendation_id === selectedRecommendationId
          && !resolvedRecommendationIds.has(item.recommendation_id),
      ) ?? null
    );
  }, [
    firPrimaryQuestion,
    firRecommendations,
    resolvedRecommendationIds,
    selectedRecommendationId,
  ]);

  const recordRecommendationOutcome = useCallback(
    async (
      recommendation: FIRRecommendation,
      outcomeType: string,
      payload: Record<string, unknown> = {},
    ) => {
      try {
        await recommendationService.recordOutcome(recommendation.recommendation_id, {
          outcome_type: outcomeType,
          context_key: firRecommendationContextKey,
          user_id: session ? String(session.user_id) : null,
          payload,
        });
      } catch (error) {
        console.warn("Could not record FIR recommendation outcome", error);
      }
    },
    [firRecommendationContextKey, session],
  );

  const handleFirRecommendationAction = useCallback(
    async (recommendation: FIRRecommendation, action: FIRRecommendationAction) => {
      if (action.action === "dismiss") {
        markRecommendationResolved(recommendation.recommendation_id);
        await recordRecommendationOutcome(recommendation, "dismissed", {
          action_id: action.id,
          checkpoint: recommendation.checkpoint,
        });
        return;
      }
      if (action.action === "confirm") {
        await recordRecommendationOutcome(recommendation, "accepted", {
          action_id: action.id,
          checkpoint: recommendation.checkpoint,
        });
        markRecommendationResolved(recommendation.recommendation_id);
        return;
      }

      let recommendationWithEvidence = recommendation;
      if (
        action.action === "open_assistant_explanation"
        && !(recommendation.evidence ?? []).length
      ) {
        try {
          recommendationWithEvidence = await recommendationService.get(
            recommendation.recommendation_id,
          );
        } catch (error) {
          console.warn("Could not load detailed FIR evidence", error);
        }
      }
      const evidenceText = (recommendationWithEvidence.evidence ?? [])
        .slice(0, 3)
        .map((item) => `${item.title}: ${item.summary}`)
        .join("\n");
      const prompt =
        action.action === "correct"
          ? `I want to correct this FIR understanding:\n${recommendation.current_understanding || recommendation.display_message}\n\nMy correction is: `
          : `Explain this FIR recommendation in the current mapping context:\n${recommendationWithEvidence.current_understanding || recommendationWithEvidence.display_message}${evidenceText ? `\n\nEvidence:\n${evidenceText}` : recommendationWithEvidence.evidence_summary ? `\n\nEvidence summary:\n${recommendationWithEvidence.evidence_summary}` : ""}`;
      setPanelMode("assistant");
      if (action.action === "correct") {
        setDraft(prompt);
        setPendingCorrectionRecommendation(recommendation);
        await recordRecommendationOutcome(recommendation, "opened", {
          action_id: action.id,
          intent: "correct",
        });
      } else {
        sendChatMessage(prompt);
        await recordRecommendationOutcome(recommendation, "explained", {
          action_id: action.id,
        });
      }
    },
    [markRecommendationResolved, recordRecommendationOutcome, sendChatMessage, setDraft],
  );

  useEffect(() => {
    const newlyShown = visibleFirRecommendations.filter((recommendation) => {
      const shownKey = `${recommendation.recommendation_id}:${recommendation.content_version ?? 1}:${firRecommendationContextKey ?? ""}`;
      if (shownRecommendationIdsRef.current.has(shownKey)) return false;
      shownRecommendationIdsRef.current.add(shownKey);
      return true;
    });
    if (!newlyShown.length) return;
    void recommendationService.recordShownOutcomes(
      newlyShown.map((recommendation) => ({
        recommendation_id: recommendation.recommendation_id,
        context_key: firRecommendationContextKey,
        user_id: session ? String(session.user_id) : null,
        payload: {
          checkpoint: recommendation.checkpoint,
          retrieval_mode: recommendation.retrieval_mode,
        },
      })),
    ).catch((error) => {
      console.warn("Could not record FIR recommendation impressions", error);
    });
  }, [
    firRecommendationContextKey,
    session,
    visibleFirRecommendations,
  ]);

  const renderFirRecommendationCard = (
    recommendation: FIRRecommendation,
    interruptive = false,
  ) => {
    const confidence =
      recommendation.confidence == null
        ? null
        : `${Math.round(recommendation.confidence * 100)}% confidence`;
    const retrievalMode = String(recommendation.retrieval_mode || "structured")
      .replaceAll("_", " ");
    return (
      <AiaPaper
        key={`${recommendation.recommendation_id}:${recommendation.content_version ?? 1}`}
        elevation={0}
        sx={{
          p: 1.5,
          borderRadius: 2,
          border: interruptive ? "1px solid #fecaca" : "1px solid #bfdbfe",
          backgroundColor: interruptive ? "#fff7f7" : "#f8fbff",
        }}
      >
        <AiaStack spacing={1.1}>
          <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
            {interruptive ? (
              <HelpOutlineOutlinedIcon sx={{ fontSize: 18, color: "#dc2626" }} />
            ) : (
              <TipsAndUpdatesOutlinedIcon sx={{ fontSize: 18, color: "#2563eb" }} />
            )}
            <AiaBox sx={{ minWidth: 0, flex: 1 }}>
              <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
                {recommendation.title ||
                  String(recommendation.recommendation_category || "Recommendation")
                    .replaceAll("_", " ")}
              </AiaText>
              <AiaText sx={{ fontSize: 11, color: "#64748b", textTransform: "capitalize" }}>
                {[recommendation.question_id, confidence, retrievalMode].filter(Boolean).join(" · ")}
              </AiaText>
            </AiaBox>
          </AiaStack>

          <AiaText sx={{ fontSize: 13, color: "#334155", lineHeight: 1.55 }}>
            {recommendation.display_message}
          </AiaText>

          {recommendation.current_understanding ? (
            <AiaBox
              sx={{
                px: 1.25,
                py: 1,
                borderRadius: 1.5,
                border: "1px solid #dbeafe",
                backgroundColor: "#ffffff",
              }}
            >
              <AiaText sx={{ fontSize: 11.5, fontWeight: 800, color: "#1d4ed8", mb: 0.4 }}>
                Current understanding
              </AiaText>
              <AiaText sx={{ fontSize: 12.5, color: "#334155", lineHeight: 1.55 }}>
                {recommendation.current_understanding}
              </AiaText>
            </AiaBox>
          ) : null}

          {recommendation.evidence?.length ? (
            <AiaBox sx={{ display: "grid", gap: 0.5 }}>
              <AiaText sx={{ fontSize: 11.5, fontWeight: 800, color: "#475569" }}>
                Evidence
              </AiaText>
              {recommendation.evidence.slice(0, 3).map((evidence) => (
                <AiaText
                  key={evidence.evidence_id}
                  sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.45 }}
                >
                  <strong>{evidence.title}:</strong> {evidence.summary}
                </AiaText>
              ))}
            </AiaBox>
          ) : recommendation.evidence_summary ? (
            <AiaText sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.45 }}>
              <strong>Evidence:</strong> {recommendation.evidence_summary}
            </AiaText>
          ) : (
            <AiaText sx={{ fontSize: 11.5, color: "#94a3b8" }}>
              Semantic-only guidance; no readable evidence item is linked yet.
            </AiaText>
          )}

          <AiaStack direction="row" spacing={0.75} useFlexGap sx={{ flexWrap: "wrap" }}>
            {recommendation.actions.map((action) => (
              <AiaButton
                key={action.id}
                size="small"
                variant={action.action === "confirm" ? "contained" : "outlined"}
                onClick={() => {
                  void handleFirRecommendationAction(recommendation, action);
                }}
                sx={{ textTransform: "none", borderRadius: "999px" }}
              >
                {action.label}
              </AiaButton>
            ))}
          </AiaStack>
        </AiaStack>
      </AiaPaper>
    );
  };

  const handleSend = (rawMessage?: string): boolean => {
    const message = (typeof rawMessage === "string" ? rawMessage : draft).trim();
    if (!message) return false;

    // Check if we should block due to loading state
    const isLoading = migrationAgentState.isActive
      ? migrationAgentState.isConnecting || (migrationAgentState.isRunning && !migrationAgentState.pendingPermission)
      : chatLoading;
    if (isLoading || pendingPlanOffer || migrationAgentState.pendingPermission) return false;

    // If Migration Agent mode is active, use Migration Agent
    if (migrationAgentState.isActive) {
      void connectAndSendMigrationAgentMessage(message);
      setDraft("");
      return true;
    }

    if (pendingAiMappingReviews[0] && APPROVAL_RESPONSE_PATTERN.test(message)) {
      applyPendingAiMappingReview();
      setDraft("");
      return true;
    }

    if (pendingAiMappingReviews[0] && SKIP_RESPONSE_PATTERN.test(message)) {
      skipPendingAiMappingReview();
      setDraft("");
      return true;
    }

    if (pendingCorrectionRecommendation) {
      void recordRecommendationOutcome(pendingCorrectionRecommendation, "corrected", {
        correction: message,
        checkpoint: pendingCorrectionRecommendation.checkpoint,
      });
      markRecommendationResolved(pendingCorrectionRecommendation.recommendation_id);
      setPendingCorrectionRecommendation(null);
    }

    sendChatMessage(message);
    setDraft("");
    return true;
  };

  useEffect(() => {
    syncMessageScroll();
  }, [chatLoading, chatMessages, migrationAgentMessages, migrationAgentState.streamingText, migrationAgentState.traceEvents.length]);

  const projectChat = pageMode || (pathname?.startsWith('/ai-agent') ?? false);
  const selectedChatProjectId = agentPageProjectId === GENERAL_PROJECT_VALUE ? null : agentPageProjectId;
  const chatProjectId = projectChat ? selectedChatProjectId : activeProjectId;

  // Build workspace snapshot for Migration Agent
  const buildWorkspaceSnapshot = useCallback((): WorkbenchContextSnapshotV1 => {
    // The full-page agent changes projects without remounting the workbench.
    // Its saved project identity is authoritative; old in-memory table and
    // semantic selections may belong to another project.
    const selectedSourceTables = projectChat ? [] : sources.filter((s) => s.isSelected);
    const selectedTargetTable = projectChat ? null : targets.find((t) => t.isSelected) ?? null;

    const currentPage = getSttmBuilderAssistantPage(pathname);
    const surface = currentPage === 'mapping' ? 'MAPPING' : 'SOURCE_SELECTION';

    const sql = projectChat ? null : selectAssistantMappingSql(store.getState().sttmBuilder);
    const snapshot = buildWorkbenchContextSnapshot({
      action: 'assistant.requested',
      page: currentPage,
      surface,
      sessionId: session ? String(session.user_id) : null,
      projectId: chatProjectId,
      projectName: chatProjectId === activeProjectId ? activeProjectName : null,
      sttmId: projectChat ? null : activeSttmId,
      sttmName: projectChat ? null : activeSttmName,
      scopeType: projectChat && chatProjectId ? 'project' : undefined,
      mappingLifecycle: projectChat ? 'new' : mappingIntent?.lifecycle ?? (activeSttmId ? 'update' : 'new'),
      businessGoal: projectChat ? null : mappingIntent?.business_goal ?? mappingIntent?.target_outcome ?? null,
      sourceTables: selectedSourceTables,
      targetTable: selectedTargetTable,
      drivingTableId: projectChat ? null : drivingTableId,
      sourceAttributeGroups: projectChat ? [] : sourceAttributeGroups,
      derivedSources: projectChat ? [] : derivedSources,
      relationships: projectChat ? [] : relationships,
      sourceFilterSql: projectChat ? '' : sourceFilterSql,
      sourceFilterGroups: projectChat ? [] : sourceFilterGroups,
      sourceQuerySql: projectChat ? '' : sourceQuerySql,
      sourceGroupBySql: projectChat ? '' : sourceGroupBySql,
      sourceOrderBySql: projectChat ? '' : sourceOrderBySql,
      mappings: projectChat ? [] : mappings,
      selectedMappingIds: projectChat ? [] : selectedMappingIds,
      activeMappingId: projectChat ? null : activeMappingId,
      mappingSql: sql?.mappingSql ?? null,
      mappingPreviewSql: sql?.mappingPreviewSql ?? null,
      mappingIntent: projectChat ? null : mappingIntent,
      semanticBundleId: projectChat ? null : semanticBundleId,
      semanticBundleLabel: projectChat ? null : semanticBundleLabel,
      semanticLevel: projectChat ? null : semanticLevel,
      semanticStatus: projectChat ? null : semanticStatus,
      semanticViewName: projectChat ? null : semanticViewName,
    });
    return {
      ...snapshot,
      // Quick and Deep receive the same prepared/semantic context handles and
      // live overlays. Deep tools still enforce their own authorization rules.
      workspace_context_id: projectChat ? null : workspaceContextId,
      workspace_context_hash: projectChat ? null : workspaceContextHash,
      workspace_context_status: projectChat ? null : workspaceContextStatus,
      workspace_context_cache_status: projectChat ? null : workspaceContextCacheStatus,
      semantic_bundle_hash: projectChat ? null : semanticBundleHash,
      semantic_context: projectChat ? [] : semanticContextItems,
      semantic_lineage: projectChat ? [] : semanticLineage,
      datahub_context: projectChat ? null : semanticDatahubContext,
      learning_context_id: projectChat ? null : learningContextId,
      learning_context_hash: projectChat ? null : learningContextHash,
    } as WorkbenchContextSnapshotV1;
  }, [
    sources,
    targets,
    derivedSources,
    projectChat,
    chatProjectId,
    session,
    sourceAttributeGroups,
    drivingTableId,
    relationships,
    semanticBundleId,
    semanticBundleLabel,
    semanticBundleHash,
    semanticContextItems,
    semanticLineage,
    semanticDatahubContext,
    learningContextId,
    learningContextHash,
    workspaceContextId,
    workspaceContextHash,
    workspaceContextStatus,
    workspaceContextCacheStatus,
    semanticViewName,
    mappings,
    selectedMappingIds,
    activeProjectId,
    activeSttmId,
    activeProjectName,
    activeSttmName,
    mappingIntent,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    store,
    activeMappingId,
    semanticLevel,
    semanticStatus,
  ]);

  // Handle Migration Agent WebSocket messages
  const handleMigrationAgentMessage = useCallback((message: MigrationAgentServerMessage) => {
    switch (message.type) {
      case 'inbox.updated':
        setPendingDeepMessages(Array.isArray(message.data?.rows) ? message.data.rows as PendingDeepMessage[] : []);
        break;
      case 'inbox.steered': {
        const id = String(message.data?.id ?? '');
        if (id && message.data?.message) {
          setMigrationAgentMessages(messages => messages.some(item => item.id === id) ? messages : [
            ...messages, { id, role: 'user', content: String(message.data?.message) },
          ]);
        }
        break;
      }
      case 'inbox.delivered':
        setPendingDeepMessages(rows => rows.filter(row => row.id !== message.data?.id));
        setInboxError(null);
        setMigrationAgentMessages(messages => [
          ...messages, { id: String(message.data?.id), role: 'user', content: String(message.data?.message ?? '') },
        ]);
        setMigrationAgentState(previous => ({ ...previous, traceEvents: [], toolExecutions: [], reviewItems: [], reviewArtifact: null }));
        setPlanDocument(null);
        setPlanSidebarOpen(false);
        setSqlArtifact(null);
        break;
      case 'inbox.error':
        setInboxError(String(message.data?.message ?? 'The queued message could not be submitted.'));
        break;
      case 'session.ready':
        setMigrationAgentState((prev) => ({
          ...prev,
          isConnecting: false,
          isConnected: true,
          statusMessage: 'Migration Agent session ready',
        }));
        break;

      case 'session.restored': {
        animateMigrationAgentMessagesRef.current = false;
        const restoredPlanEvent = message.data?.current_plan;
        if (restoredPlanEvent && typeof restoredPlanEvent === 'object') {
          const plan = (restoredPlanEvent as Record<string, unknown>).plan;
          if (plan && typeof plan === 'object' && 'plan_hash' in plan) {
            setPlanDocument(plan as Record<string, unknown>);
          }
        }
        if (Array.isArray(message.data?.attachments)) {
          setMigrationAttachments((message.data.attachments as Array<{ id: string; name: string }>).filter(
            (attachment) => Boolean(attachment.id && attachment.name),
          ));
        }
        const runId = String(message.data?.run_id ?? message.session_id);
        const prompt = String(message.data?.prompt ?? '').trim();
        const status = String(message.data?.status ?? '');
        const restoredHistory = Array.isArray(message.data?.conversation_history)
          ? (message.data.conversation_history as Array<Record<string, unknown>>)
              .map((item, index) => ({
                role: item.role === "assistant" ? "assistant" as const : "user" as const,
                content: String(item.content ?? "").trim(),
                id: String(item.turn_id || `${runId}:history:${index}`),
                kind: item.role === "assistant" ? "final" as const : undefined,
                question: item.question && typeof item.question === "object"
                  ? item.question as { prompt: string; options: Array<{ label: string; description: string }> }
                  : undefined,
              }))
              .filter((item) => item.content)
          : [];
        const restoredArtifact = [...restoredHistory].reverse()
          .filter((item) => item.role === 'assistant')
          .map((item) => separateSqlPreview(item.content).artifact)
          .find((artifact) => artifact !== null);
        if (restoredArtifact) setSqlArtifact(restoredArtifact);
        const terminal = ['COMPLETED', 'NEEDS_REVIEW', 'COMPLETED_WITH_REVIEW_ITEMS', 'READY_FOR_REVIEW', 'FAILED', 'CANCELLED', 'EXPIRED'].includes(status);
        setMigrationAgentMessages((messages) => {
          const byId = new Map(messages.map((item) => [item.id, item]));
          for (const item of restoredHistory) if (!byId.has(item.id)) byId.set(item.id, item);
          if (prompt && !byId.has(`${runId}:user`)) {
            byId.set(`${runId}:user`, { role: 'user', content: prompt, id: `${runId}:user` });
          }
          return Array.from(byId.values());
        });
        setMigrationAgentState((prev) => ({
          ...prev,
          isConnecting: false,
          isConnected: true,
          isRunning: !terminal && !['AWAITING_INPUT', 'AWAITING_CONFIRMATION'].includes(status),
          isCancelling: false,
          streamingText: '',
          // History restoration is a background hydration operation, not a
          // newly started agent response. The durable trace itself will show
          // the current active step as soon as replay completes.
          statusMessage: null,
          traceEvents: [],
          toolExecutions: [],
          reviewItems: [],
          reviewArtifact: null,
          error: null,
        }));
        break;
      }

      case 'session.caught_up':
        // Durable history is already painted in full. Text received after this
        // boundary is new live output and may use the typewriter presentation.
        animateMigrationAgentMessagesRef.current = true;
        if (message.data?.terminal === true) {
          // A finished run: replayed status lines must not leave it "running".
          setMigrationAgentState((prev) => ({
            ...prev, isRunning: false, isCancelling: false, isConnecting: false, statusMessage: null, streamingText: '',
          }));
        }
        break;

      case 'context.usage': {
        const usage = contextUsageFromEvent(message.data as Record<string, unknown> | undefined);
        if (usage) setMigrationContextUsage(usage);
        break;
      }

      case 'assistant.progress':
        {
          const update = String(message.data?.text ?? '').trim();
          const durableId = String(message.data?.durable_event_id ?? message.event_id);
          const animate = animateMigrationAgentMessagesRef.current;
          const heartbeat = (message.data?.progress as { kind?: string } | null)?.kind === 'heartbeat';
          if (update) {
            setMigrationAgentMessages((messages) => {
              if (messages.some((item) => item.id === durableId)) return messages;
              const current = heartbeat ? messages.filter((item) => !item.heartbeat) : messages;
              const recentProgress = [...current].reverse().find((item) => item.kind === 'progress');
              if (recentProgress && isSimilarProgress(recentProgress.content, update)) return current;
              return insertProgressBeforeFinal(current, {
                role: 'assistant', content: update, id: durableId, kind: 'progress', animate, heartbeat,
              });
            });
          }
          setMigrationAgentState((prev) => ({ ...prev, streamingText: '', statusMessage: null }));
        }
        break;

      case 'review.items': {
        const items = Array.isArray(message.data?.items) ? message.data.items : [];
        const artifact = message.data?.artifact && typeof message.data.artifact === "object"
          ? message.data.artifact as Record<string, unknown> : null;
        const nextSqlArtifact: AgentSqlArtifact | null = artifact ? {
          sql: String(artifact.sql ?? ''),
          compileValid: artifact.compileValid === true,
          previewValid: artifact.previewValid === true,
          previewColumns: Array.isArray(artifact.previewColumns) ? artifact.previewColumns.map(String) : [],
          previewRows: Array.isArray(artifact.previewRows) ? artifact.previewRows.map((row) =>
            typeof row === 'string' ? row : JSON.stringify(row)) : [],
          previewRowCount: Number(artifact.previewRowCount ?? 0),
          mappedCount: Number(artifact.mappedCount ?? 0),
          unresolvedCount: Number(artifact.unresolvedCount ?? 0),
        } : null;
        if (nextSqlArtifact?.sql) {
          setSqlArtifact(nextSqlArtifact);
          setArtifactVersion((version) => version + 1);
        }
        setMigrationAgentState((prev) => ({
          ...prev,
          reviewContextHash: message.context_hash,
          reviewItems: items
            .filter((item): item is Record<string, unknown> => !!item && typeof item === 'object')
            .map((item): AgentReviewItem => {
              const subjects = Array.isArray(item.subject_keys) ? item.subject_keys.map(String).filter(Boolean) : [];
              return {
                id: String(item.review_item_id ?? ''),
                category: String(item.category ?? 'review'),
                summary: String(item.summary ?? ''),
                question: String(item.question ?? item.summary ?? ''),
                status: String(item.status ?? 'OPEN'),
                sttmId: typeof item.sttm_id === 'string' ? item.sttm_id : null,
                blocking: item.blocking === true,
                subject: subjects.length ? subjects.join(', ') : null,
                recommendedChoiceId: typeof item.recommended_choice_id === 'string' ? item.recommended_choice_id : null,
                allowFreeText: item.allow_free_text !== false,
                choices: (Array.isArray(item.choices) ? item.choices : [])
                  .filter((choice): choice is Record<string, unknown> => !!choice && typeof choice === 'object')
                  .map((choice) => ({ id: String(choice.choice_id ?? ''), label: String(choice.label ?? ''),
                    description: String(choice.description ?? ''),
                    confidence: typeof choice.confidence === 'number' ? choice.confidence : null }))
                  .filter((choice) => choice.id && choice.label),
              };
            })
            .filter((item) => item.id && item.summary),
          reviewArtifact: nextSqlArtifact,
        }));
        break;
      }

      case 'plan.mode.recommended':
        setPendingPlanOffer({ reason: String(message.data?.reason ?? "This request has several dependent migration steps.") });
        setMigrationAgentState((prev) => ({ ...prev, isRunning: false, statusMessage: null }));
        break;

      case 'assistant.status':
        setMigrationAgentState((prev) => ({
          ...prev,
          isRunning: !prev.pendingPermission,
          statusMessage: prev.pendingPermission ? null : String(message.data?.status ?? message.data?.message ?? 'Working...'),
        }));
        break;

      case 'trace.event': {
        const data = message.data ?? {};
        if (data.plan && typeof data.plan === "object" && !Array.isArray(data.plan)) {
          setPlanDocument(data.plan as Record<string, unknown>);
        }
        const traceId = String(data.trace_id ?? message.event_id);
        const eventDetails = { ...data };
        const explicitDetails = eventDetails.details;
        for (const key of ['trace_id', 'parent_trace_id', 'kind', 'label', 'status', 'safe_summary', 'created_at', 'event_type', 'details']) {
          delete eventDetails[key];
        }
        setMigrationAgentState((prev) => {
          const next: MigrationAgentTraceEvent = {
            traceId,
            parentTraceId: data.parent_trace_id ? String(data.parent_trace_id) : null,
            kind: String(data.kind ?? 'action'),
            label: String(data.label ?? data.safe_summary ?? 'Migration activity'),
            status: String(data.status ?? 'running'),
            summary: String(data.safe_summary ?? ''),
            timestamp: String(data.created_at ?? message.timestamp),
            details: {
              ...eventDetails,
              ...(explicitDetails && typeof explicitDetails === 'object' ? explicitDetails : {}),
            } as Record<string, unknown>,
          };
          const index = prev.traceEvents.findIndex((event) => event.traceId === traceId);
          const current = index >= 0 ? prev.traceEvents[index] : null;
          const merged = current
            ? {
                ...next,
                parentTraceId: next.parentTraceId ?? current.parentTraceId,
                details: { ...current.details, ...next.details },
              }
            : next;
          return {
            ...prev,
            // Tool lifecycle belongs in the expandable activity tree. Keep the
            // compact receipt stable until genuine model-authored narration
            // arrives instead of echoing every low-level step above the tree.
            statusMessage: data.event_type === "run.queued"
              ? "Waiting for the Deep Agent worker…"
              : data.event_type === "run.started"
                ? "Worker started. Preparing the first step…"
                : /(?:\.started|\.completed|\.progress)$/.test(String(data.event_type ?? "")) && data.safe_summary
                  ? String(data.safe_summary)
                  : prev.statusMessage,
            resolvedEffort: ["light", "medium", "high"].includes(String(data.resolved_effort))
              ? String(data.resolved_effort) as Exclude<MigrationEffort, "auto">
              : prev.resolvedEffort,
            traceEvents: index < 0
              ? [...prev.traceEvents, merged]
              : prev.traceEvents.map((event, candidate) => candidate === index ? merged : event),
          };
        });
        break;
      }

      case 'assistant.final':
        {
          window.dispatchEvent(new Event('aia:refresh-assistant-history'));
          const researchQuestion = message.data?.response_kind === 'research_question';
          const finalText = String(message.data?.text ?? '');
          const finalArtifact = separateSqlPreview(finalText).artifact;
          if (finalArtifact) {
            setSqlArtifact((current) => current?.sql.startsWith(finalArtifact.sql) ? current : finalArtifact);
          }
          const durableId = String(message.data?.durable_event_id ?? message.event_id);
          const animate = animateMigrationAgentMessagesRef.current;
          const question = message.data?.question && typeof message.data.question === 'object'
            ? message.data.question as { prompt: string; options: Array<{ label: string; description: string }> }
            : undefined;
          animateMigrationAgentMessagesRef.current = false;
          if (finalText) {
            setMigrationAgentMessages((msgs) => {
              const withoutTransientCopy = msgs.filter((item) => !(
                item.kind === 'progress' && isSameVisibleMessage(item.content, finalText)
              ));
              return withoutTransientCopy.some((item) => item.id === durableId)
                ? withoutTransientCopy
                : appendOrReplaceFinal(withoutTransientCopy, { role: 'assistant', content: finalText, id: durableId, kind: 'final', animate, question, researchQuestion });
            });
          }
          setMigrationAgentState((prev) => ({
            ...prev,
            isRunning: false,
            isCancelling: false,
            pendingPermission: researchQuestion ? prev.pendingPermission : null,
            streamingText: '',
            statusMessage: researchQuestion ? 'Waiting for your answer' : null,
          }));
          if (!researchQuestion) {
            setOtherAnswerOpen(false);
            setOtherAnswer("");
          }
        }
        break;

      case 'assistant.cancelled':
        animateMigrationAgentMessagesRef.current = false;
        setMigrationAgentState((prev) => ({
          ...prev,
          isRunning: false,
          isCancelling: false,
          pendingPermission: null,
          streamingText: '',
          statusMessage: null,
          error: null,
        }));
        break;

      case 'assistant.error':
        animateMigrationAgentMessagesRef.current = false;
        setMigrationAgentState((prev) => ({
          ...prev,
          isRunning: false,
          isCancelling: false,
          pendingPermission: message.error?.code === 'migration_agent_transport_error' ? prev.pendingPermission : null,
          streamingText: '',
          statusMessage: null,
          error: message.error?.detail ?? 'An error occurred',
        }));
        break;

      case 'permission.requested': {
        const permData = message.data as MigrationAgentPermissionRequest | undefined;
        if (permData) {
          if (lastQuestionIdRef.current !== permData.permission_id) {
            lastQuestionIdRef.current = permData.permission_id;
            setOtherAnswer('');
            setOtherAnswerOpen(false);
            setReviewDecisionError(null);
          }
          if (permData.tool === "approve_migration_plan" && permData.plan) {
            setPlanDocument(permData.plan);
            setArtifactVersion((version) => version + 1);
          }
          setMigrationAgentState((prev) => ({
            ...prev,
            isRunning: false,
            isConnecting: false,
            statusMessage: "Waiting for your answer",
            pendingPermission: {
              ...permData,
              contextHash: message.context_hash,
            },
          }));
        }
        break;
      }

      case 'permission.resolved':
        setMigrationAgentState((prev) => ({
          ...prev,
          pendingPermission: !prev.pendingPermission
            || prev.pendingPermission.permission_id === String(message.data?.permission_id ?? '')
            ? null : prev.pendingPermission,
        }));
        break;

      case 'tool.started': {
        const toolData = message.data as { tool_id?: string; tool?: string; resource?: string } | undefined;
        if (toolData) {
          setMigrationAgentState((prev) => ({
            ...prev,
            toolExecutions: [
              ...prev.toolExecutions,
              {
                toolId: toolData.tool_id ?? message.event_id,
                tool: toolData.tool ?? 'unknown',
                resource: toolData.resource,
                status: 'started',
                startedAt: message.timestamp,
              },
            ],
          }));
        }
        break;
      }

      case 'tool.completed': {
        const toolData = message.data as { tool_id?: string; result?: string } | undefined;
        if (toolData) {
          setMigrationAgentState((prev) => ({
            ...prev,
            toolExecutions: prev.toolExecutions.map((exec) =>
              exec.toolId === toolData.tool_id
                ? { ...exec, status: 'completed', completedAt: message.timestamp, result: toolData.result }
                : exec
            ),
          }));
        }
        break;
      }

      default:
        // Handle any other message types gracefully
        break;
    }
  }, [pageMode]);

  // Handle Migration Agent disconnect
  const handleMigrationAgentDisconnect = useCallback(() => {
    setMigrationAgentState((prev) => ({
      ...prev,
      isConnected: false,
      isConnecting: false,
      statusMessage: null,
      error: prev.isActive ? 'Connection lost' : null,
    }));
  }, []);

  // Toggle Migration Agent mode
  const toggleMigrationAgentMode = useCallback(() => {
    if (chatLoading || migrationAgentState.isRunning || migrationAgentState.isCancelling || migrationAgentState.isConnecting) return;
    // A mode switch is an explicit new-chat boundary. History restoration is
    // the only path that may reopen an earlier conversation.
    resetChatSession();
    if (migrationAgentState.isActive) {
      // Turn off Migration Agent mode
      migrationAgentClientRef.current?.close();
      migrationAgentClientRef.current = null;
      setMigrationAgentState(initialMigrationAgentState);
      setMigrationAgentMessages([]);
      setSqlArtifact(null);
      setPlanDocument(null);
      setPlanSidebarOpen(false);
    } else {
      // Enter Deep mode as a genuinely blank chat. Only an explicit History
      // selection may restore durable turns from an earlier conversation.
      const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
      migrationAgentClientRef.current = client;
      client.startNewConversation();
      animateMigrationAgentMessagesRef.current = false;
      setMigrationAgentMessages([]);
      setMigrationAttachments([]);
      setExpandedToolExecutions(false);
      const snapshot = buildWorkspaceSnapshot();
      setMigrationAgentState((prev) => ({
        ...prev,
        isActive: true,
        isConnecting: true,
        statusMessage: null,
        error: null,
      }));
      void client.connect(snapshot, handleMigrationAgentMessage, handleMigrationAgentDisconnect)
        .catch((error) => {
          setMigrationAgentState((prev) => ({
            ...prev,
            isConnecting: false,
            isConnected: false,
            statusMessage: null,
            error: error instanceof Error ? error.message : 'Failed to connect to Migration Agent',
          }));
        });
    }
  }, [buildWorkspaceSnapshot, handleMigrationAgentDisconnect, handleMigrationAgentMessage, migrationAgentState.isActive, migrationAgentState.isRunning, migrationAgentState.isCancelling, migrationAgentState.isConnecting, chatLoading, resetChatSession]);

  // Open the dedicated agent page in Deep mode when there is no conversation
  // to preserve. The user can still switch modes from the shared composer.
  const wasOnAgentPageRef = useRef(false);
  useEffect(() => {
    const onAgentPage = pathname.startsWith("/ai-agent");
    if (onAgentPage && !wasOnAgentPageRef.current
      && !migrationAgentState.isActive
      && migrationAgentMessages.length === 0) {
      toggleMigrationAgentMode();
    }
    wasOnAgentPageRef.current = onAgentPage;
  }, [migrationAgentMessages.length, migrationAgentState.isActive, pathname, toggleMigrationAgentMode]);

  const startNewMigrationAgentChat = useCallback(() => {
    if (!migrationAgentState.isActive) return;
    const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
    migrationAgentClientRef.current = client;
    if (migrationAgentState.isRunning || migrationAgentState.isCancelling) {
      client.cancel("");
    }
    client.startNewConversation();
    animateMigrationAgentMessagesRef.current = false;
    setMigrationAgentMessages([]);
    setPlanDocument(null);
    setPlanSidebarOpen(false);
    setSqlArtifact(null);
    setPendingPlanOffer(null);
    setMigrationAttachments([]);
    setExpandedToolExecutions(false);
    setMigrationAgentState((prev) => ({
      ...initialMigrationAgentState,
      isActive: true,
      isConnected: prev.isConnected,
      isConnecting: false,
    }));
    setDraft("");
  }, [migrationAgentState.isActive, migrationAgentState.isCancelling, migrationAgentState.isRunning, setDraft]);

  const observedNewChatVersionRef = useRef(newChatVersion);
  useEffect(() => {
    if (observedNewChatVersionRef.current === newChatVersion) return;
    observedNewChatVersionRef.current = newChatVersion;
    if (migrationAgentState.isActive) startNewMigrationAgentChat();
  }, [migrationAgentState.isActive, newChatVersion, startNewMigrationAgentChat]);

  useEffect(() => {
    const restore = (event: Event) => {
      // The dedicated page owns restoration while the hidden shell sidebar
      // remains mounted. Only one presentation should fetch and replay a run.
      if (!pageMode && window.location.pathname === '/ai-agent') return;
      const detail = (event as CustomEvent<{ conversationId?: string }>).detail;
      if (!detail?.conversationId) return;
      const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
      migrationAgentClientRef.current = client;
      resetChatSession();
      setMigrationAgentMessages([]);
      setPlanDocument(null);
      setPlanSidebarOpen(false);
      setSqlArtifact(null);
      setPendingPlanOffer(null);
      setMigrationAgentState((previous) => ({
        ...initialMigrationAgentState,
        isActive: true,
        isConnecting: true,
        isConnected: previous.isConnected,
      }));
      void client.restoreConversation(
        detail.conversationId,
        buildWorkspaceSnapshot(),
        handleMigrationAgentMessage,
        handleMigrationAgentDisconnect,
      ).catch((error) => {
        setMigrationAgentState((previous) => ({
          ...previous,
          isConnecting: false,
          error: error instanceof Error ? error.message : 'Failed to restore conversation',
        }));
      });
    };
    window.addEventListener('aia:restore-assistant-conversation', restore);
    return () => window.removeEventListener('aia:restore-assistant-conversation', restore);
  }, [pageMode, buildWorkspaceSnapshot, handleMigrationAgentDisconnect, handleMigrationAgentMessage, resetChatSession]);

  useEffect(() => {
    if (!pageMode) return;
    const params = new URLSearchParams(window.location.search);
    const artifact = params.get('artifact');
    const conversationId = params.get('conversation');
    if (!conversationId || !['research', 'plan', 'review', 'sql', 'results'].includes(artifact ?? '')) return;
    requestedArtifactRef.current = artifact as AgentArtifactTab;
    window.dispatchEvent(new CustomEvent('aia:restore-assistant-conversation', {
      detail: { conversationId },
    }));
  }, [pageMode]);

  useEffect(() => {
    const requested = requestedArtifactRef.current;
    if (!requested) return;
    if ((requested === 'research' && researchReport)
      || (requested === 'plan' && planDocument)
      || (requested === 'review' && migrationAgentState.reviewItems.some((item) => item.status === 'OPEN'))
      || (requested === 'sql' && visibleSqlArtifact?.sql)
      || (requested === 'results' && (visibleSqlArtifact || researchReport || migrationAgentState.reviewItems.length))) {
      setArtifactTab(requested);
      setPlanSidebarOpen(true);
      requestedArtifactRef.current = null;
    }
  }, [researchReport, planDocument, visibleSqlArtifact, migrationAgentState.reviewItems]);

  useEffect(() => {
    const selectMode = (event: Event) => {
      const detail = (event as CustomEvent<{ mode?: 'quick' | 'deep' }>).detail;
      if (detail?.mode !== 'quick') return;
      migrationAgentClientRef.current?.close();
      migrationAgentClientRef.current = null;
      setMigrationAgentState(initialMigrationAgentState);
      setMigrationAgentMessages([]);
      setPlanDocument(null);
      setPlanSidebarOpen(false);
      setSqlArtifact(null);
      setPendingPlanOffer(null);
      setMigrationAttachments([]);
      setExpandedToolExecutions(false);
    };
    window.addEventListener('aia:select-assistant-mode', selectMode);
    return () => window.removeEventListener('aia:select-assistant-mode', selectMode);
  }, []);

  // Connect to Migration Agent when sending first message in Migration Agent mode
  const connectAndSendMigrationAgentMessage = useCallback(async (message: string, options?: AiAgentSendOptions) => {
    if (!migrationAgentClientRef.current) {
      migrationAgentClientRef.current = new MigrationAgentSessionClient();
    }

    const snapshot = buildWorkspaceSnapshot();
    const readingAttachment = migrationAttachments.length > 0
      && /\b(summarize|summary|identify|explain|what|which|who|when|why|how|compare|review|ask|question|tell me)\b/i.test(message)
      && !/\b(create|build|draft|save|publish|execute|run|generate|implement|migrate|map|update|modify|compile|preview)\b/i.test(message);
    // Progress bubbles are live status; the next run needs the conversation, not them.
    const conversationHistory: MigrationConversationMessage[] = migrationAgentMessages
      .filter((item) => item.kind !== 'progress')
      .slice(-40)
      .map(({ role, content }) => ({ role, content }));
    syncMessageScroll('jump');
    animateMigrationAgentMessagesRef.current = true;

    // Add user message to chat
    setMigrationAgentMessages((msgs) => [
      ...msgs,
      { role: 'user', content: message, id: `user-${Date.now()}` },
    ]);

    try {
      setMigrationAgentState((prev) => ({
        ...prev,
        isRunning: true,
        isCancelling: false,
        traceEvents: [],
        toolExecutions: [],
        reviewItems: [],
        reviewArtifact: null,
        statusMessage: readingAttachment ? 'Reading uploaded evidence…' : 'Sending request…',
        error: null,
      }));
      if (!migrationAgentState.isConnected || !migrationAgentClientRef.current.isConnected) {
        setMigrationAgentState((prev) => ({ ...prev, isRunning: true, isConnecting: true, error: null, statusMessage: 'Checking Migration Agent service...' }));
        setMigrationAgentState((prev) => ({ ...prev, statusMessage: 'Connecting…' }));
        await migrationAgentClientRef.current.connect(snapshot, handleMigrationAgentMessage, handleMigrationAgentDisconnect);
      }
      setMigrationAgentState((prev) => ({ ...prev, isRunning: true, statusMessage: readingAttachment ? 'Reading uploaded evidence…' : 'Sending request…' }));
      migrationAgentClientRef.current.setOptions({
        effort: options?.effort ?? migrationEffort,
        modelName: options ? options.modelName : migrationModelName,
        runMode: options?.runMode ?? migrationRunMode,
        attachmentIds: migrationAttachments.map((attachment) => attachment.id),
      });
      migrationAgentClientRef.current.sendMessage(message, snapshot, conversationHistory);
    } catch (err) {
      setMigrationAgentState((prev) => ({
        ...prev,
        isRunning: false,
        isConnecting: false,
        statusMessage: null,
        error: err instanceof Error ? err.message : 'Failed to connect to Migration Agent',
      }));
    }
  }, [buildWorkspaceSnapshot, migrationAgentState.isConnected, migrationEffort, migrationModelName, migrationRunMode, migrationAttachments, migrationAgentMessages, handleMigrationAgentMessage, handleMigrationAgentDisconnect]);

  const handleMigrationAttachment = useCallback(async (file: File | null) => {
    if (!file) return;
    const client = migrationAgentClientRef.current ?? new MigrationAgentSessionClient();
    migrationAgentClientRef.current = client;
    setMigrationAttachmentUploading(true);
    setMigrationAgentState((state) => ({ ...state, error: null }));
    try {
      const id = await client.uploadAttachment(file);
      setMigrationAttachments((attachments) => [...attachments, { id, name: file.name }]);
    } catch (error) {
      setMigrationAgentState((state) => ({
        ...state,
        error: error instanceof Error ? error.message : "Attachment upload failed",
      }));
    } finally {
      setMigrationAttachmentUploading(false);
    }
  }, []);

  // Handle permission decision
  const handlePermissionDecision = useCallback(
    (decision: 'allow_once' | 'allow_session' | 'deny' | 'cancel', feedback = '') => {
      const perm = migrationAgentState.pendingPermission;
      if (!perm || !migrationAgentClientRef.current) return;

      migrationAgentClientRef.current.decidePermission(
        perm.contextHash,
        perm.permission_id,
        decision,
        feedback
      );
      setMigrationAgentState((prev) => ({ ...prev, pendingPermission: null }));
    },
    [migrationAgentState.pendingPermission]
  );

  const submitQuestionAnswer = useCallback(async (choiceId: string | null, text: string | null, label: string) => {
    const permission = migrationAgentState.pendingPermission;
    const client = migrationAgentClientRef.current;
    if (!permission || !client || reviewAnswerInFlight.current) return;
    reviewAnswerInFlight.current = true;
    setReviewDecisionBusy(true);
    setReviewDecisionError(null);
    try {
      await client.answerReviewDecision(permission.contextHash, permission.permission_id, choiceId, text);
      if (migrationAgentClientRef.current !== client) return;
      if (permission.tool === 'approve_migration_plan' && choiceId === 'approve') {
        setDismissedPlanKey(planKey);
        if (artifactTab === 'plan') setPlanSidebarOpen(false);
      }
      setMigrationAgentMessages(messages => [
        ...messages, { role: 'user', content: label, id: `answer-${permission.permission_id}` },
      ]);
      setOtherAnswer('');
      setOtherAnswerOpen(false);
    } catch (error) {
      if (migrationAgentClientRef.current === client) {
        setReviewDecisionError(error instanceof Error ? error.message : 'The answer could not be saved.');
      }
    } finally {
      reviewAnswerInFlight.current = false;
      setReviewDecisionBusy(false);
    }
  }, [migrationAgentState.pendingPermission, artifactTab, planKey]);

  const handlePermissionChoice = (choiceId: string, label: string) => {
    void submitQuestionAnswer(choiceId, null, label);
  };

  const queueDeepMessage = useCallback(async (message: string, mode: 'queue' | 'steer', options: AiAgentSendOptions) => {
    const client = migrationAgentClientRef.current;
    if (!client) throw new Error('Wait for the current request to be saved.');
    setInboxError(null);
    await client.queueMessage(message, mode, buildWorkspaceSnapshot(), options);
  }, [buildWorkspaceSnapshot]);

  const removeQueuedMessage = useCallback(async (id: string) => {
    try {
      await migrationAgentClientRef.current?.removeQueuedMessage(id);
      setInboxError(null);
    } catch (error) {
      setInboxError(error instanceof Error ? error.message : 'Could not remove the queued message.');
      void migrationAgentClientRef.current?.refreshInbox();
    }
  }, []);

  useEffect(() => {
    if (!pendingDeepMessages.length || !migrationAgentState.isActive) return;
    const tick = () => {
      const mayDeliver = !migrationAgentState.isRunning && !migrationAgentState.pendingPermission && !migrationAgentState.error;
      void migrationAgentClientRef.current?.refreshInbox(mayDeliver);
    };
    const timer = window.setInterval(tick, 5000);
    return () => window.clearInterval(timer);
  }, [pendingDeepMessages.length, migrationAgentState.isActive, migrationAgentState.isRunning, migrationAgentState.pendingPermission, migrationAgentState.error]);

  // The page's registered sender must use current Quick review/edit state.
  const currentSendRef = useRef(handleSend);
  currentSendRef.current = handleSend;
  const deepSendApi = useMemo(() => ({
    send: (message: string, options?: AiAgentSendOptions) => {
      if (!migrationAgentState.isActive) return currentSendRef.current(message);
      if (!message.trim() || migrationAttachmentUploading || migrationAgentState.isConnecting || migrationAgentState.isCancelling) return false;
      if (migrationAgentState.pendingPermission) return false;
      if (migrationAgentState.isRunning || pendingPlanOffer || !migrationAgentAvailable) return false;
      void connectAndSendMigrationAgentMessage(message.trim(), options);
      return true;
    },
    assistantMode: migrationAgentState.isActive ? "deep" as const : "quick" as const,
    onAssistantModeChange: (mode: "quick" | "deep") => {
      if ((mode === "deep") !== migrationAgentState.isActive && (mode === "quick" || migrationAgentAvailable)) toggleMigrationAgentMode();
    },
    isLoading: migrationAgentState.isActive
      ? migrationAgentState.isConnecting || migrationAgentState.isCancelling || migrationAgentState.isRunning && !migrationAgentState.pendingPermission
      : chatLoading,
    hasConversation: migrationAgentState.isActive ? migrationAgentMessages.some(message => message.role === 'user') : chatMessages.some(message => message.role === 'user'),
    scopeProjectId: chatProjectId,
    isRunning: migrationAgentState.isActive && migrationAgentState.isRunning,
    inputBlocked: migrationAgentState.isActive && Boolean(pendingPlanOffer),
    canQueue: migrationAgentState.isActive && migrationAgentClientRef.current?.canQueueMessage === true,
    waitingForAnswer: migrationAgentState.isActive && Boolean(migrationAgentState.pendingPermission),
    queueMessage: queueDeepMessage,
    removeQueuedMessage,
    pendingMessages: pendingDeepMessages,
    inboxError,
    deepAvailable: migrationAgentAvailable === true,
    modelOptions: migrationModelOptions,
    attachFile: (file: File) => handleMigrationAttachment(file),
    attachmentUploading: migrationAttachmentUploading,
    attachments: migrationAttachments,
    contextUsage: migrationContextUsage,
    cancel: () => {
      setMigrationAgentState(state => ({ ...state, isCancelling: true, statusMessage: 'Stopping…' }));
      migrationAgentClientRef.current?.cancel("");
    },
  }), [chatLoading, chatMessages, toggleMigrationAgentMode, chatProjectId, migrationAgentMessages, migrationAgentState, migrationAgentAvailable, migrationModelOptions, migrationAttachmentUploading, migrationAttachments, migrationContextUsage, pendingPlanOffer, connectAndSendMigrationAgentMessage, handleMigrationAttachment, queueDeepMessage, removeQueuedMessage, pendingDeepMessages, inboxError]);
  useRegisterAiAgentSend(deepSendApi);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      migrationAgentClientRef.current?.close();
    };
  }, []);

  const toggleTrace = (messageId: string) => {
    setExpandedTraces((current) => ({
      ...current,
      [messageId]: !current[messageId],
    }));
  };

  const startSignalRating = (signalId: string, rating: number) => {
    setPendingSignalResponses((current) => ({
      ...current,
      [signalId]: {
        rating,
        optionSelected: current[signalId]?.optionSelected ?? null,
        comment: current[signalId]?.comment ?? "",
      },
    }));
  };

  const selectSignalOption = (signalId: string, optionSelected: string) => {
    setPendingSignalResponses((current) => ({
      ...current,
      [signalId]: {
        rating: current[signalId]?.rating ?? null,
        optionSelected,
        comment: current[signalId]?.comment ?? "",
      },
    }));
  };

  const changeSignalComment = (signalId: string, comment: string) => {
    setPendingSignalResponses((current) => ({
      ...current,
      [signalId]: {
        rating: current[signalId]?.rating ?? null,
        optionSelected: current[signalId]?.optionSelected ?? null,
        comment,
      },
    }));
  };

  const submitSignalResponse = (signalId: string) => {
    const pending = pendingSignalResponses[signalId];
    respondToAssistantSignal({
      signalId,
      status: "responded",
      optionSelected: pending?.optionSelected ?? null,
      rating: pending?.rating ?? null,
      comment: pending?.comment?.trim() || null,
    });
    setPendingSignalResponses((current) => {
      const next = { ...current };
      delete next[signalId];
      return next;
    });
  };

  const dismissSignal = (signalId: string) => {
    respondToAssistantSignal({ signalId, status: "dismissed" });
    setPendingSignalResponses((current) => {
      const next = { ...current };
      delete next[signalId];
      return next;
    });
  };

  const confirmSignalOption = (signalId: string, optionSelected: string) => {
    respondToAssistantSignal({
      signalId,
      status: "responded",
      optionSelected,
    });
    setPendingSignalResponses((current) => {
      const next = { ...current };
      delete next[signalId];
      return next;
    });
  };

  const explainSignal = async (signal: (typeof assistantSignals)[number], optionLabel?: string) => {
    const signalTables =
      Array.isArray(signal.entity_ids) && signal.entity_ids.length >= 2
        ? signal.entity_ids.filter((entityId) => entityId.split(".").length === 3).slice(0, 2)
        : [];
    const fallbackPrompt =
      signalTables.length >= 2
        ? `Explain the relationship between ${signalTables[0]} and ${signalTables[1]} in simple business terms and tell me whether it looks reliable for mapping.`
        : "Explain the relationship between the selected tables in simple business terms and tell me whether it looks reliable for mapping.";
    const suggestedPrompt =
      typeof signal.attributes?.suggested_prompt === "string" && signal.attributes.suggested_prompt.trim()
        ? signal.attributes.suggested_prompt.trim()
        : fallbackPrompt;
    const currentUnderstanding = buildSignalUnderstandingText(signal);
    const explanationPrompt = currentUnderstanding
      ? `${suggestedPrompt}\n\nThis is your current understanding so far:\n${currentUnderstanding}\n\nPlease explain this in simple business terms, tell me what looks reliable, and call out the specific assumption or join detail the user should confirm or correct.`
      : suggestedPrompt;
    sendChatMessage(explanationPrompt);
    respondToAssistantSignal({
      signalId: signal.signal_id,
      status: "acknowledged",
      optionSelected: optionLabel ?? "Ask AI to explain first",
    });
  };

  const applySignalAction = async (signal: (typeof assistantSignals)[number]) => {
    const actionType = typeof signal.attributes?.action_type === "string" ? signal.attributes.action_type : "";
    if (actionType === "refresh_semantic_context") {
      try {
        setSignalActionBusyId(signal.signal_id);
        await requestSemanticRefresh();
        respondToAssistantSignal({
          signalId: signal.signal_id,
          status: "acknowledged",
          optionSelected: "Refresh semantic context",
        });
      } finally {
        setSignalActionBusyId(null);
      }
      return;
    }
    if (actionType === "explain_relationship") {
      await explainSignal(signal, "Explain this relationship");
    }
  };

  const handleSignalOption = async (signal: (typeof assistantSignals)[number], option: string) => {
    const normalized = option.trim().toLowerCase();
    if (normalized === "refresh semantic context" || normalized === "build stronger context") {
      await applySignalAction(signal);
      return;
    }
    const requestsExplanation =
      normalized === "ask ai to explain first" ||
      normalized === "explain this relationship" ||
      normalized === "explain this join" ||
      normalized === "tell me more" ||
      normalized.includes("explain") ||
      (normalized.includes("show me") &&
        ["join", "relationship", "pattern", "correct", "how", "why"].some((word) => normalized.includes(word)));
    if (requestsExplanation) {
      await explainSignal(signal, option);
      return;
    }
    if (normalized === "dismiss" || normalized === "not now") {
      dismissSignal(signal.signal_id);
      return;
    }
    if (
      normalized === "looks right" ||
      normalized.startsWith("understood") ||
      normalized.includes("i'll handle it") ||
      normalized.includes("i will handle it") ||
      normalized === "yes, that is correct" ||
      normalized === "this relationship looks right"
    ) {
      confirmSignalOption(signal.signal_id, option);
      return;
    }
    if (normalized === "needs correction") {
      const currentUnderstanding = buildSignalUnderstandingText(signal);
      setPendingSignalResponses((current) => ({
        ...current,
        [signal.signal_id]: {
          rating: current[signal.signal_id]?.rating ?? null,
          optionSelected: option,
          comment: current[signal.signal_id]?.comment ?? "",
        },
      }));
      sendChatMessage(
        currentUnderstanding
          ? `This current understanding needs correction:\n${currentUnderstanding}\n\nPlease ask me what looks wrong, what the right business meaning is, and what join or relationship should be used instead.`
          : "I think the current join needs correction. Please ask me what looks wrong and help me capture the right business relationship.",
      );
      return;
    }
    if (normalized === "i will type it manually" || normalized === "i want to describe it") {
      setPendingSignalResponses((current) => ({
        ...current,
        [signal.signal_id]: {
          rating: current[signal.signal_id]?.rating ?? null,
          optionSelected: option,
          comment: current[signal.signal_id]?.comment ?? "",
        },
      }));
      return;
    }
    selectSignalOption(signal.signal_id, option);
  };

  const openReviewItems = migrationAgentState.reviewItems.filter((item) => item.status === 'OPEN');
  const reviewDraftId = migrationAgentState.reviewItems.find((item) => item.sttmId)?.sttmId;
  const answerReviewItem = (itemId: string, choiceId: string | null, text: string | null) => {
    const client = migrationAgentClientRef.current;
    if (!client) return;
    setReviewDecisionBusy(true);
    setReviewDecisionError(null);
    void client.answerReviewDecision(migrationAgentState.reviewContextHash, itemId, choiceId, text)
      .catch((error) => setReviewDecisionError(error instanceof Error ? error.message : 'Could not record the answer'))
      .finally(() => setReviewDecisionBusy(false));
  };
  const acceptReviewRows = (rows: ReviewTable['rows']) => {
    const client = migrationAgentClientRef.current;
    if (!client || !rows.length) return;
    setReviewDecisionBusy(true);
    setReviewDecisionError(null);
    void client.acceptReviewRows(rows)
      .then(() => client.fetchReviewTable())
      .then((table) => setReviewTable(table))
      .catch((error) => setReviewDecisionError(error instanceof Error ? error.message : 'Could not accept the rows'))
      .finally(() => setReviewDecisionBusy(false));
  };
  const openReviewCard = (reviewItemId: string) => {
    setSelectedReviewItemId((current) => current === reviewItemId ? null : reviewItemId);
  };
  const learned = learnedItems(migrationAgentState.traceEvents);
  const hasResults = Boolean(visibleSqlArtifact || projectCreation || reviewDraftId
    || openReviewItems.length || reviewTable?.rows.length || learned.length
    || researchReport.startsWith('## Migration plan research'));
  // Publishing stays a user action: only targets whose SQL compiled and
  // previewed are offered, and each is published through the normal route.
  const cleanMappings = finalSqlArtifacts.filter(
    (artifact) => artifact.status === 'ready' && artifact.compileValid && artifact.previewValid && artifact.sttmId,
  );
  const publishCleanMappings = async () => {
    setPublishBusy(true);
    setPublishMessage(null);
    const failed: string[] = [];
    for (const artifact of cleanMappings) {
      try {
        await publishSttm(String(artifact.sttmId), {
          revision_note: 'Published from the Deep Agent review after SQL compile and preview passed.',
        });
      } catch {
        failed.push(artifact.mappingName ?? String(artifact.sttmId));
      }
    }
    setPublishBusy(false);
    setPublishConfirmOpen(false);
    setPublishMessage(failed.length
      ? { ok: false, text: `Could not publish ${failed.join(', ')}. Publishing needs the publisher permission; open the mapping to publish it there.` }
      : { ok: true, text: `Published ${cleanMappings.length} mapping${cleanMappings.length === 1 ? '' : 's'}.` });
  };

  return (
    <AiaBox sx={{ width: '100%', height: '100%', minWidth: 0, minHeight: 0, display: 'flex', overflow: 'hidden' }}>
    <AiaPaper
      elevation={0}
      sx={{
        flex: 1,
        minWidth: 0,
        height: "100%",
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        borderRadius: "12px",
        border: variant === "sidebar" ? "none" : "1px solid #e2e8f0",
        overflow: "hidden",
        backgroundColor: "#ffffff",
      }}
    >
      {variant !== "sidebar" ? <AiaBox
        sx={{
          p: 2.25,
          backgroundColor: "var(--aia-assitant-header-color)",
          color: "var(--aia-assitant-header-textColor)",
        }}
      >
        <AiaStack
          sx={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "flex-start",
            gap: 1.5,
          }}
        >
          <AiaStack sx={{ flexDirection: "row", gap: 1.5, alignItems: "center" }}>
            <AiaAvatar
              sx={{
                bgcolor: 'var(--aia-assitant-avatar-bgColor)',
                width: 36,
                height: 36,
              }}
            >
              <AutoAwesomeRoundedIcon sx={{ fontSize: 20 }} />
            </AiaAvatar>
            <AiaBox>
              <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                <AiaText
                  variant="subtitle1"
                  sx={{ fontWeight: 700, lineHeight: 1.2, color: 'var(--aia-assitant-textColor)' }}
                >
                  STTM AI
                </AiaText>
              </AiaStack>
              <AiaText
                variant="caption"
                sx={{
                  color: "#94a3b8",
                  display: "flex",
                  alignItems: "center",
                  gap: 0.75,
                }}
              >
                <AiaBox
                  component="span"
                  sx={{
                    width: 6,
                    height: 6,
                    borderRadius: "50%",
                    bgcolor: migrationAgentState.isActive
                      ? migrationAgentState.isConnecting
                        ? "#f59e0b"
                        : migrationAgentState.isConnected
                          ? "#22c55e"
                          : "#94a3b8"
                      : chatLoading
                        ? "#f59e0b"
                        : "#22c55e",
                  }}
                />
                {migrationAgentState.isActive
                  ? migrationAgentState.isConnecting
                    ? "Restoring history..."
                    : migrationAgentState.isConnected
                      ? "Connected"
                      : "Ready"
                  : chatLoading
                    ? "Working"
                    : "Active"}{" "}
                · {migrationAgentState.isActive ? "Deep Agent" : "Quick Assistant"}
              </AiaText>
            </AiaBox>
          </AiaStack>
          <AiaStack direction="row" spacing={0.5}>
            <AiaTooltip title={migrationAgentState.isActive && (migrationAgentState.isRunning || migrationAgentState.isCancelling) ? "Stop the active run before starting a new chat" : "New chat"}>
                <span>
                  <AiaIconButton
                    size="small"
                    aria-label="Start a new chat"
                    disabled={migrationAgentState.isActive && (migrationAgentState.isRunning || migrationAgentState.isCancelling)}
                    onClick={migrationAgentState.isActive ? startNewMigrationAgentChat : resetChatSession}
                    sx={{ color: 'var(--aia-assitant-textColor)' }}
                  >
                    <EditNoteRoundedIcon fontSize="small" />
                  </AiaIconButton>
                </span>
            </AiaTooltip>
            {/* Only show Migration Agent toggle if Migration Agent is available */}
            {migrationAgentAvailable && (
              <AiaTooltip title={migrationAgentState.isActive ? "Switch to Quick Assistant" : "Switch to Migration Agent"}>
                <AiaIconButton
                  size="small"
                  onClick={toggleMigrationAgentMode}
                  sx={{
                    color: migrationAgentState.isActive ? 'var(--aia-primary-bg-color)' : 'var(--aia-assitant-textColor)',
                    backgroundColor: migrationAgentState.isActive ? 'color-mix(in srgb, var(--aia-button-color) 12%, transparent)' : 'transparent',
                    '&:hover': {
                      backgroundColor: migrationAgentState.isActive ? 'color-mix(in srgb, var(--aia-button-color) 20%, transparent)' : 'rgba(255,255,255,0.1)',
                    },
                  }}
                >
                  <AutoAwesomeRoundedIcon fontSize="small" />
                </AiaIconButton>
              </AiaTooltip>
            )}
            {/* Show disabled state when Migration Agent is not available but checking is done */}
            {migrationAgentAvailable === false && (
              <AiaTooltip title="Migration Agent is not available">
                <AiaBox sx={{ opacity: 0.4 }}>
                  <AiaIconButton
                    size="small"
                    disabled
                    sx={{ color: 'var(--aia-assitant-textColor)' }}
                  >
                    <AutoAwesomeRoundedIcon fontSize="small" />
                  </AiaIconButton>
                </AiaBox>
              </AiaTooltip>
            )}
            <AiaIconButton
              size="small"
              aria-label="Open AI Agent page"
              title="Open AI Agent page"
              onClick={() => router.push('/ai-agent')}
              sx={{ color: 'var(--aia-assitant-textColor)' }}
            >
              <OpenInFullIcon fontSize="small" />
            </AiaIconButton>
            <AiaIconButton size="small" sx={{ color: 'var(--aia-assitant-textColor)' }}>
              <VolumeUpIcon fontSize="small" />
            </AiaIconButton>
          </AiaStack>
        </AiaStack>

        <AiaBox
          sx={{
            mt: 2,
            p: 1.25,
            borderRadius: "8px",
            backgroundColor: 'var(--aia-assitant-subheader-color)',
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          <TableChartIcon sx={{ fontSize: 16, color: 'var(--aia-assitant-table-textColor)'  }} />
          <AiaText variant="caption" sx={{ color: 'var(--aia-assitant-table-textColor)' }}>
            {statsLabel}
          </AiaText>
        </AiaBox>

        {semanticStatus || semanticLevel || semanticViewName || semanticBundleLabel ? (
          <AiaStack
            direction="row"
            spacing={0.75}
            useFlexGap
            sx={{ mt: 1.25, flexWrap: "wrap" }}
          >
            {semanticBundleLabel ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#1f2937",
                  color: "#e5e7eb",
                  fontSize: 11,
                  fontWeight: 700,
                  maxWidth: "100%",
                }}
              >
                {semanticBundleLabel}
              </AiaBox>
            ) : null}
            {semanticLevel ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#1e293b",
                  color: "#e2e8f0",
                  fontSize: 11,
                  fontWeight: 700,
                }}
              >
                {semanticLevel}
              </AiaBox>
            ) : null}
            {semanticStatus ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#052e16",
                  color: "#86efac",
                  fontSize: 11,
                  fontWeight: 700,
                  textTransform: "capitalize",
                }}
              >
                {semanticStatus}
              </AiaBox>
            ) : null}
            {semanticViewName ? (
              <AiaBox
                sx={{
                  px: 1,
                  py: 0.4,
                  borderRadius: "999px",
                  backgroundColor: "#172554",
                  color: "#bfdbfe",
                  fontSize: 11,
                  fontWeight: 700,
                }}
              >
                Semantic view
              </AiaBox>
            ) : null}

          </AiaStack>
        ) : null}
      </AiaBox> : !pageMode ? (
        <AiaBox
          sx={{
            px: 2,
            py: 1,
            borderBottom: "1px solid #e2e8f0",
            backgroundColor: "#f8fafc",
            flexShrink: 0,
          }}
        >
          <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
            <TableChartIcon sx={{ fontSize: 16, color: "#64748b" }} />
            <AiaText sx={{ fontSize: 12, color: "#64748b" }}>{statsLabel}</AiaText>
          </AiaStack>
        </AiaBox>
      ) : null}

      {!pageMode ? <AiaStack
        direction="row"
        spacing={0.75}
        sx={{
          px: 2,
          py: 0.65,
          alignItems: "center",
          borderBottom: "1px solid #e2e8f0",
          backgroundColor:
            workspaceContextStatus === "failed" ? "#fff7ed" : "#f8fafc",
          flexShrink: 0,
        }}
      >
        {workspaceContextStatus === "updating" ? (
          <AiaCircularProgress size={12} />
        ) : (
          <AiaBox
            sx={{
              width: 7,
              height: 7,
              borderRadius: "50%",
              backgroundColor:
                workspaceContextStatus === "ready"
                  ? "#22c55e"
                  : workspaceContextStatus === "partial"
                    ? "#f59e0b"
                    : workspaceContextStatus === "failed"
                      ? "#ef4444"
                      : "#94a3b8",
            }}
          />
        )}
        <AiaText
          sx={{
            minWidth: 0,
            flex: 1,
            fontSize: 11,
            color: workspaceContextStatus === "failed" ? "#9a3412" : "#64748b",
          }}
          title={workspaceContextError ?? undefined}
        >
          AI context:{" "}
          {workspaceContextStatus === "updating"
            ? "Updating"
            : workspaceContextStatus === "ready"
              ? "Ready"
              : workspaceContextStatus === "partial"
                ? "Ready with warnings"
                : workspaceContextStatus === "failed"
                  ? "Failed"
                  : "Waiting for a selection"}
          {workspaceContextCacheStatus
            ? ` · ${({
                l1: "Memory cache",
                l2: "Durable cache",
                miss: "Fresh",
                coalesced: "Reused",
                memory: "Memory cache",
                durable: "Durable cache",
                fresh: "Fresh",
              } as Record<string, string>)[workspaceContextCacheStatus.toLowerCase()] ?? workspaceContextCacheStatus}`
            : ""}
        </AiaText>
        <AiaButton
          size="small"
          variant="text"
          disabled={workspaceContextStatus === "updating"}
          onClick={() => {
            void refreshPreparedWorkspaceContext().catch(() => undefined);
          }}
          sx={{
            minWidth: 0,
            px: 0.75,
            py: 0.25,
            fontSize: 11,
            textTransform: "none",
          }}
        >
          Refresh
        </AiaButton>
      </AiaStack> : null}

      {variant !== "sidebar" ? <AiaStack
        direction="row"
        sx={{
          px: 1,
          py: 0.75,
          gap: 0.5,
          borderBottom: "1px solid #e2e8f0",
          backgroundColor: "#ffffff",
        }}
      >
        <AiaButton
          size="small"
          variant={panelMode === "assistant" ? "contained" : "text"}
          onClick={() => setPanelMode("assistant")}
          sx={{
            minHeight: 32,
            textTransform: "none",
            borderRadius: 1.5,
            boxShadow: "none",
          }}
        >
          Assistant
          {firPrimaryQuestion ? (
            <AiaBox
              component="span"
              sx={{
                ml: 0.75,
                minWidth: 18,
                height: 18,
                px: 0.5,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "999px",
                backgroundColor: panelMode === "assistant" ? "#ffffff" : "#fee2e2",
                color: "#dc2626",
                fontSize: 10,
                fontWeight: 800,
              }}
            >
              1
            </AiaBox>
          ) : null}
        </AiaButton>
        <AiaButton
          size="small"
          variant={panelMode === "recommendations" ? "contained" : "text"}
          onClick={() => setPanelMode("recommendations")}
          sx={{
            minHeight: 32,
            textTransform: "none",
            borderRadius: 1.5,
            boxShadow: "none",
          }}
        >
          Recommendations
          <AiaBox
            component="span"
            sx={{
              ml: 0.75,
              minWidth: 18,
              height: 18,
              px: 0.5,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "999px",
              backgroundColor: panelMode === "recommendations" ? "#ffffff" : "#dbeafe",
              color: "#1d4ed8",
              fontSize: 10,
              fontWeight: 800,
            }}
          >
            {visibleFirRecommendations.length}
          </AiaBox>
        </AiaButton>
      </AiaStack> : null}

      <AiaBox
        ref={messagesRef}
        role="log"
        aria-label="Assistant conversation"
        aria-live="off"
        onScroll={() => syncMessageScroll('scroll')}
        sx={{
          flex: "1 1 0",
          minHeight: 0,
          overflowAnchor: 'none',
          overflowY: "auto",
          overflowX: "hidden",
          overscrollBehavior: "contain",
          scrollbarGutter: "stable",
          touchAction: "pan-y",
          WebkitOverflowScrolling: "touch",
          backgroundColor: "#ffffff",
        }}
      >
        <AiaBox ref={messageContentRef} sx={{p:2,width:'100%',maxWidth:pageMode?AI_AGENT_PAGE_CONTENT_MAX_WIDTH:undefined,mx:pageMode?'auto':undefined,minHeight:'100%',boxSizing:'border-box',display:'flex',flexDirection:'column',gap:2,
          ...(showWelcomeHero && (!migrationAgentState.isActive || (
            migrationAgentMessages.length === 0 && !migrationAgentState.isRunning
          ))
            ? {
                justifyContent: "center",
                alignItems: "center",
              }
            : {}),
        }}
      >
        {variant !== "sidebar" && panelMode === "recommendations" ? (
          firRecommendationLoading ? (
            <AiaStack direction="row" spacing={1} sx={{ alignItems: "center", color: "#64748b" }}>
              <AiaCircularProgress size={16} />
              <AiaText sx={{ fontSize: 13 }}>Loading applicable guidance...</AiaText>
            </AiaStack>
          ) : visibleFirRecommendations.length ? (
            <AiaStack spacing={1.25}>
              {visibleFirRecommendations.map((recommendation) =>
                renderFirRecommendationCard(recommendation),
              )}
            </AiaStack>
          ) : (
            <AiaBox sx={{ py: 4, textAlign: "center" }}>
              <TipsAndUpdatesOutlinedIcon sx={{ color: "#94a3b8", mb: 1 }} />
              <AiaText sx={{ fontSize: 13, fontWeight: 700, color: "#475569" }}>
                No guidance applies to this checkpoint yet.
              </AiaText>
              <AiaText sx={{ fontSize: 12, color: "#94a3b8", mt: 0.5 }}>
                New FIR results will appear here as the mapping context changes.
              </AiaText>
            </AiaBox>
          )
        ) : null}

        {(variant === "sidebar" || panelMode === "assistant") ? (
          <>
        {variant === "sidebar"
          ? selectedRecommendation
            ? renderFirRecommendationCard(selectedRecommendation, !!selectedRecommendation.question_id)
            : null
          : firPrimaryQuestion &&
              !resolvedRecommendationIds.has(firPrimaryQuestion.recommendation_id)
            ? renderFirRecommendationCard(firPrimaryQuestion, true)
            : null}
        {activeSignal ? (
          <AiaStack spacing={1.5}>
            {[activeSignal].map((signal) => {
              const draftResponse = pendingSignalResponses[signal.signal_id];
              const thumbsUpSelected = draftResponse?.rating === 5;
              const thumbsDownSelected = draftResponse?.rating === 1;
              const isRefreshSignal = signal.attributes?.action_type === "refresh_semantic_context";
              const currentUnderstanding = buildSignalUnderstandingText(signal);
              const actionLabel =
                isRefreshSignal
                  ? "Refresh now"
                  : signal.attributes?.action_type === "explain_relationship"
                    ? "Explain now"
                    : null;
              return (
                <AiaPaper
                  key={signal.signal_id}
                  elevation={0}
                  sx={{
                    p: 1.5,
                    borderRadius: 2,
                    border: signal.signal_type === "recommendation" ? "1px solid #bfdbfe" : "1px solid #fecaca",
                    backgroundColor: signal.signal_type === "recommendation" ? "#eff6ff" : "#fff7f7",
                  }}
                >
                  <AiaStack spacing={1}>
                    <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                      {signal.signal_type === "recommendation" ? (
                        <TipsAndUpdatesOutlinedIcon sx={{ fontSize: 18, color: "#2563eb" }} />
                      ) : (
                        <HelpOutlineOutlinedIcon sx={{ fontSize: 18, color: "#dc2626" }} />
                      )}
                      <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
                        {signal.title}
                      </AiaText>
                    </AiaStack>
                    <AiaText
                      sx={{
                        fontSize: 13,
                        color: "#334155",
                        lineHeight: 1.55,
                        overflowWrap: "anywhere",
                        wordBreak: "break-word",
                      }}
                    >
                      {signal.message}
                    </AiaText>
                    {currentUnderstanding ? (
                      <AiaBox
                        sx={{
                          borderRadius: 1.5,
                          border: "1px solid #dbeafe",
                          backgroundColor: "#ffffff",
                          px: 1.25,
                          py: 1,
                        }}
                      >
                        <AiaText sx={{ fontSize: 12, fontWeight: 800, color: "#1d4ed8", mb: 0.5 }}>
                          Current understanding
                        </AiaText>
                        <AiaText
                          sx={{
                            fontSize: 12.5,
                            color: "#334155",
                            lineHeight: 1.6,
                            whiteSpace: "pre-wrap",
                            overflowWrap: "anywhere",
                            wordBreak: "break-word",
                          }}
                        >
                          {currentUnderstanding}
                        </AiaText>
                      </AiaBox>
                    ) : null}
                    {signal.options?.length ? (
                      <AiaStack direction="row" spacing={1} useFlexGap sx={{ flexWrap: "wrap" }}>
                        {signal.options.map((option) => {
                          const selected = draftResponse?.optionSelected === option;
                          return (
                            <AiaButton
                              key={option}
                              size="small"
                              variant={selected ? "contained" : "outlined"}
                              onClick={() => {
                                void handleSignalOption(signal, option);
                              }}
                              sx={{ borderRadius: 999, textTransform: "none" }}
                            >
                              {option}
                            </AiaButton>
                          );
                        })}
                      </AiaStack>
                    ) : null}
                    {signal.signal_type === "recommendation" ? (
                      <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                        <AiaIconButton
                          size="small"
                          onClick={() => startSignalRating(signal.signal_id, 5)}
                          sx={{ color: thumbsUpSelected ? "#16a34a" : "#64748b" }}
                        >
                          <ThumbUpAltOutlinedIcon fontSize="small" />
                        </AiaIconButton>
                        <AiaIconButton
                          size="small"
                          onClick={() => startSignalRating(signal.signal_id, 1)}
                          sx={{ color: thumbsDownSelected ? "#dc2626" : "#64748b" }}
                        >
                          <ThumbDownAltOutlinedIcon fontSize="small" />
                        </AiaIconButton>
                        <AiaText sx={{ fontSize: 12, color: "#64748b" }}>
                          Was this recommendation useful?
                        </AiaText>
                      </AiaStack>
                    ) : null}
                    {(!isRefreshSignal && (signal.allow_free_text || draftResponse?.rating || draftResponse?.optionSelected)) ? (
                      <AiaInput
                        size="small"
                        placeholder="Add a business comment or type your own answer"
                        value={draftResponse?.comment ?? ""}
                        onChange={(value) => changeSignalComment(signal.signal_id, value)}
                        multiline
                        minRows={2}
                      />
                    ) : null}
                    <AiaStack direction="row" spacing={1}>
                      {actionLabel ? (
                        <AiaButton
                          size="small"
                          variant="outlined"
                          onClick={() => {
                            void applySignalAction(signal);
                          }}
                          disabled={signalActionBusyId === signal.signal_id}
                          sx={{ textTransform: "none" }}
                        >
                          {signalActionBusyId === signal.signal_id ? "Working..." : actionLabel}
                        </AiaButton>
                      ) : null}
                      {!isRefreshSignal ? (
                        <AiaButton
                          size="small"
                          variant="contained"
                          onClick={() => submitSignalResponse(signal.signal_id)}
                          sx={{ textTransform: "none" }}
                        >
                          Send response
                        </AiaButton>
                      ) : null}
                      <AiaButton
                        size="small"
                        variant="text"
                        onClick={() => dismissSignal(signal.signal_id)}
                        sx={{ textTransform: "none" }}
                      >
                        Dismiss
                      </AiaButton>
                    </AiaStack>
                  </AiaStack>
                </AiaPaper>
              );
            })}
          </AiaStack>
        ) : null}
        {/* Migration Agent Mode Messages */}
        {migrationAgentState.isActive ? (
          <>
            {!hideComposer && groupedMigrationAgentMessages.length === 0 && !migrationAgentState.isRunning ? (
              <AiaBox
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  px: expanded ? 8 : 6,
                  py: 3,
                  textAlign: "center",
                }}
              >
                <AiaText sx={{ maxWidth: 520, fontSize: expanded ? 58 : 50, lineHeight: 1.04, fontWeight: 500, color: "#0f172a", letterSpacing: "-0.035em" }}>
                  Hi{assistantFirstName ? ` ${assistantFirstName}` : ""},
                </AiaText>
                <AiaText sx={{ maxWidth: 520, mt: 0.5, fontSize: expanded ? 58 : 50, lineHeight: 1.04, fontWeight: 400, color: "#64748b", letterSpacing: "-0.035em" }}>
                  How can I help?
                </AiaText>
                <AiaText sx={{ mt: 2, maxWidth: 520, fontSize: 13.5, color: "#475569", lineHeight: 1.6 }}>
                  Ask about your data or describe the migration you want to build.
                </AiaText>
              </AiaBox>
            ) : null}

            {/* Show the durable execution receipt before any streamed/model text. */}
            {migrationAgentState.isRunning && migrationAgentState.statusMessage && migrationAgentState.traceEvents.length === 0 && (
              <AiaStack direction="row" spacing={1.25} sx={{ alignItems: "center", px: 0.5, py: 0.75 }}>
                <AiaCircularProgress size={16} sx={{ color: "var(--aia-button-color)" }} />
                <AiaBox>
                  <AiaText sx={{ fontSize: 12, fontWeight: 700, color: "var(--aia-primary-text-color)" }}>
                    {migrationAgentState.statusMessage}
                  </AiaText>
                </AiaBox>
              </AiaStack>
            )}

            {/* Keep observable execution before model-authored narration so the
                user can inspect what ran before reading its interpretation. */}
            {migrationAgentState.traceEvents.length > 0 && (
              <AiaBox
                sx={{
                  position: "sticky",
                  top: 0,
                  zIndex: 6,
                  flexShrink: 0,
                  borderRadius: 2,
                  border: "1px solid #dbe2ea",
                  backgroundColor: "#ffffff",
                  boxShadow: "0 4px 14px rgba(15, 23, 42, 0.06)",
                  overflow: "hidden",
                }}
              >
                <AiaButton
                  onClick={() => setExpandedToolExecutions((prev) => !prev)}
                  variant="text"
                  sx={{
                    width: "100%",
                    px: 1.5,
                    py: 1,
                    justifyContent: "space-between",
                    textTransform: "none",
                    color: "var(--aia-primary-text-color)",
                    borderRadius: 0,
                    "&:hover": { backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)" },
                  }}
                >
                  <AiaStack direction="row" spacing={0.75} sx={{ minWidth: 0, alignItems: "center" }}>
                    {expandedToolExecutions ? (
                      <KeyboardArrowDownIcon sx={{ fontSize: 16, color: "var(--aia-button-color)" }} />
                    ) : (
                      <KeyboardArrowRightIcon sx={{ fontSize: 16, color: "var(--aia-button-color)" }} />
                    )}
                    <AiaBox sx={{ minWidth: 0, textAlign: "left" }}>
                      <AiaText noWrap sx={{ fontSize: 12, fontWeight: 750, color: "var(--aia-primary-text-color)" }}>
                        {migrationAgentState.pendingPermission
                          ? "Waiting for your answer"
                          : migrationAgentState.isRunning
                          ? migrationActiveLabel
                          : migrationAgentState.error
                            ? "Execution failed"
                            : migrationAgentState.traceEvents.some((event) => event.status === "needs_review")
                              ? (reviewDraftId ? "Draft results saved" : "Research finished with findings")
                            : "Execution complete"}
                      </AiaText>
                      <AiaText noWrap sx={{ fontSize: 10.5, color: "#64748b" }}>
                        {migrationAgentState.traceEvents.length} update{migrationAgentState.traceEvents.length === 1 ? "" : "s"}
                        {migrationAgentState.resolvedEffort ? ` · ${migrationAgentState.resolvedEffort} effort` : ""}
                      </AiaText>
                    </AiaBox>
                  </AiaStack>
                </AiaButton>
                {migrationAgentState.isRunning ? (
                  <AiaBox sx={{ height: 2, overflow: "hidden", backgroundColor: "#e2e8f0" }}>
                    <AiaBox
                      aria-hidden="true"
                      sx={{
                        width: "34%",
                        height: "100%",
                        background: "linear-gradient(90deg, transparent, var(--aia-button-color), transparent)",
                        animation: "agentHeaderSweep 1.55s ease-in-out infinite",
                        "@keyframes agentHeaderSweep": {
                          from: { transform: "translateX(-110%)" },
                          to: { transform: "translateX(310%)" },
                        },
                      }}
                    />
                  </AiaBox>
                ) : null}
                {expandedToolExecutions && (
                  <AiaBox
                    onWheel={(event) => event.stopPropagation()}
                    sx={{
                      px: 1.5,
                      pb: 1.25,
                      pt: 0.55,
                      // This is a nested scroll region inside a flex-column
                      // message viewport. flexShrink: 0 is essential; without
                      // it, the browser can compress a 300px activity feed to
                      // a single visible row as conversation messages grow.
                      height: "clamp(340px, 48vh, 620px)",
                      minHeight: 340,
                      maxHeight: "min(620px, 62vh)",
                      flexShrink: 0,
                      overflowY: "auto",
                      overscrollBehavior: "contain",
                      scrollbarGutter: "stable",
                      touchAction: "pan-y",
                      WebkitOverflowScrolling: "touch",
                    }}
                  >
                    <MigrationTraceTree running={migrationAgentState.isRunning && !migrationAgentState.pendingPermission}
                      events={migrationAgentState.traceEvents.filter((event) => event.traceId !== migrationPlanEvent?.traceId)} />
                  </AiaBox>
                )}
              </AiaBox>
            )}

            {groupedMigrationAgentMessages.map((group) => {
              const isAssistant = group.role === "assistant";
              return (
                <AiaStack
                  key={group.id}
                  direction="row"
                  spacing={1.5}
                  sx={{ justifyContent: isAssistant ? "flex-start" : "flex-end" }}
                >
                  {isAssistant ? (
                    <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
                      <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
                    </AiaAvatar>
                  ) : null}

                  <AiaPaper
                    elevation={0}
                    sx={{
                      p: 1.5,
                      borderRadius: isAssistant ? "0 12px 12px 12px" : "12px 0 12px 12px",
                      border: isAssistant ? "1px solid #dbe2ea" : "1px solid #e2e8f0",
                      maxWidth: expanded ? "92%" : "85%",
                      minWidth: 0,
                      backgroundColor: isAssistant ? "#ffffff" : "#f8fafc",
                    }}
                  >
                    <AiaBox sx={{ minWidth: 0, maxWidth: "100%", fontSize: 14, overflowX: "hidden" }}>
                      {group.messages.map((message, index) => (
                        <AiaBox
                          key={message.id}
                          sx={{
                            pt: index ? 1.25 : 0,
                            mt: index ? 1.25 : 0,
                            borderTop: index ? "1px solid #e2e8f0" : "none",
                          }}
                        >
                          {isAssistant && message.kind === "final" && group.messages.length > 1 ? (
                            <AiaText sx={{ mb: 0.75, fontSize: 10.5, fontWeight: 800, letterSpacing: "0.06em", textTransform: "uppercase", color: "#64748b" }}>
                              {message.researchQuestion ? "Research so far" : "Result"}
                            </AiaText>
                          ) : null}
                          {isAssistant ? (
                            <TypewriterMessageContent
                              content={message.kind === 'final' ? separateSqlPreview(message.content).message : message.content}
                              animate={migrationAgentState.isRunning && message.animate === true}
                              messageId={message.id}
                              onComplete={completeMigrationAgentMessageAnimation}
                              onProgress={followMigrationAgentMessageAnimation}
                            />
                          ) : (
                            <MessageContent content={message.content} />
                          )}
                          {isAssistant && message.question?.options?.length ? (
                            <AiaStack spacing={0.75} sx={{ mt: 1.25, width: "100%", minWidth: 0, maxWidth: "100%" }}>
                              <AiaText sx={{ fontSize: 13, fontWeight: 700, overflowWrap: "anywhere" }}>{message.question.prompt}</AiaText>
                              {message.question.options.map((option, optionIndex) => (
                                <QuestionChoiceButton
                                  key={`${message.id}:option:${optionIndex}`}
                                  label={option.label}
                                  description={option.description}
                                  disabled={migrationAgentState.isRunning}
                                  onClick={() => void connectAndSendMigrationAgentMessage(
                                    `For the transcript question "${message.question?.prompt}", I choose "${option.label}". Summarize what this choice means and what remains unresolved.`,
                                  )}
                                />
                              ))}
                            </AiaStack>
                          ) : null}
                        </AiaBox>
                      ))}
                    </AiaBox>
                  </AiaPaper>
                </AiaStack>
              );
            })}

            {planDocument && showPlanPreview ? (
              <AiaPaper elevation={0} data-testid="chat-plan-artifact"
                sx={{ border: '1px solid #dbe2ea', borderRadius: 2.5, backgroundColor: '#fff' }}>
                <AiaStack direction="row" spacing={0.75} sx={{ px: 1.5, py: 0.75, alignItems: 'center' }}>
                  <TipsAndUpdatesOutlinedIcon sx={{ fontSize: 18, color: '#64748b' }} />
                  <AiaText component="h3" sx={{ flex: 1, minWidth: 0, m: 0, fontSize: 15, lineHeight: 1.4, fontWeight: 650, overflowWrap: 'anywhere' }}>
                    {planTitle}
                  </AiaText>
                  <AiaIconButton size="small" aria-label="Dismiss plan preview" title="Dismiss plan preview" onClick={() => setDismissedPlanKey(planKey)}>
                    <CloseIcon sx={{ fontSize: 17 }} />
                  </AiaIconButton>
                  <AiaIconButton size="small" aria-label="Expand plan" title="Expand plan" onClick={() => openReviewArtifact('plan')}>
                    <OpenInFullIcon sx={{ fontSize: 17 }} />
                  </AiaIconButton>
                </AiaStack>
                <AiaBox component="ol" sx={{ m: 0, pl: 4.75, pr: 1.5, pb: 1.25, color: '#475569', fontSize: 13, lineHeight: 1.55, overflowWrap: 'anywhere' }}>
                  {planRecords(planDocument.execution_steps).slice(0, 4).map((step, index) => (
                    <li key={index}>{String(step.title || step.description || 'Prepare mapping')}</li>
                  ))}
                </AiaBox>
              </AiaPaper>
            ) : null}
            {planDocument && migrationAgentState.pendingPermission?.tool === 'approve_migration_plan' ? <AiaPaper elevation={0}
              sx={{p:2,border:'1px solid #dbe2ea',borderRadius:2.5,backgroundColor:'#f8fafc'}}>
              <AiaText sx={{fontSize:16,fontWeight:600,mb:1.25}}>Implement this plan?</AiaText>
              <AiaStack spacing={.75}>
                {(migrationAgentState.pendingPermission.questions?.[0]?.options || []).filter(option=>['approve', 'edit', 'reject', 'cancel'].includes(String(option.id))).map(option=>
                  <AiaButton key={option.id} variant={option.id==='approve'?'contained':'text'} disabled={migrationAgentState.isRunning || migrationAgentState.isConnecting || reviewDecisionBusy}
                    onClick={()=>handlePermissionChoice(String(option.id),option.label)}
                    sx={{textTransform:'none',justifyContent:'flex-start',py:1,fontSize:14,borderRadius:1.5,boxShadow:'none'}}>
                    {option.id==='approve'?'Yes, implement this plan':option.id==='edit'?'Update this plan':option.label}
                  </AiaButton>)}
              </AiaStack>
              {reviewDecisionError ? <AiaText role="alert" sx={{ color: "#b91c1c", fontSize: 12 }}>{reviewDecisionError}</AiaText> : null}
            </AiaPaper> : null}
            {!migrationAgentState.isRunning && <>
                {pageMode && openReviewItems.some((item) => item.choices.length || item.allowFreeText) ? <AiaBox sx={{mt:1.2}}>
                  <AgentReviewList items={openReviewItems.filter((item) => item.id !== migrationAgentState.pendingPermission?.permission_id && (item.choices.length || item.allowFreeText))}
                    busy={reviewDecisionBusy} error={reviewDecisionError} onAnswer={answerReviewItem} />
                </AiaBox> : null}
                  {openReviewItems.some((item) => SOURCE_RESEARCH_REVIEW_CATEGORIES.has(item.category)) ? <AiaButton size="small" variant="outlined" onClick={() => handleSend(
                    'Continue the source research from the previous run. Use the current verified table contracts and all available migration evidence to propose the supported driving source and join options. Ask me one structured question with the viable choices before drafting the mapping.'
                  )} sx={{ textTransform: 'none' }}>Continue source research</AiaButton> : null}
              {hasResults && !migrationAgentState.pendingPermission ? (
                <AiaButton variant="outlined" onClick={() => openReviewArtifact('results')}
                  sx={{ alignSelf: 'flex-start', textTransform: 'none', borderRadius: 2, px: 2 }}>
                  Results
                </AiaButton>
              ) : null}
            </>}

            {/* Streaming Migration Agent response */}
            {migrationAgentState.streamingText && (
              <AiaStack direction="row" spacing={1.5} sx={{ justifyContent: "flex-start" }}>
                <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
                  <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
                </AiaAvatar>
                <AiaPaper
                  elevation={0}
                  sx={{
                    p: 1.5,
                    borderRadius: "0 12px 12px 12px",
                    border: "1px solid #dbe2ea",
                    maxWidth: expanded ? "92%" : "85%",
                    minWidth: 0,
                    backgroundColor: "#ffffff",
                  }}
                >
                  <AiaBox sx={{ minWidth: 0, maxWidth: "100%", fontSize: 14, overflowX: "hidden" }}>
                    <MessageContent content={migrationAgentState.streamingText} />
                  </AiaBox>
                </AiaPaper>
              </AiaStack>
            )}

            {/* Migration Agent Permission Request Dialog */}
            {migrationAgentState.pendingPermission && migrationAgentState.pendingPermission.category !== "plan_mode_recommendation" && migrationAgentState.pendingPermission.tool !== "approve_migration_plan" && (
              <AiaPaper
                elevation={0}
                sx={{
                  p: 1.75,
                  borderRadius: 2,
                  border: "1px solid #cbd5e1",
                  backgroundColor: "#ffffff",
                  maxWidth: "100%",
                  minWidth: 0,
                }}
              >
                <AiaStack spacing={1.25} sx={{ minWidth: 0 }}>
                  <AiaBox sx={{ minWidth: 0 }}>
                    <AiaText sx={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                      Question
                    </AiaText>
                    <AiaText sx={{ mt: 0.5, fontSize: 14, fontWeight: 700, color: "#0f172a", lineHeight: 1.5, overflowWrap: "anywhere" }}>
                      {migrationAgentState.pendingPermission.questions?.[0]?.question || migrationAgentState.pendingPermission.reason}
                    </AiaText>
                  </AiaBox>
                  <AiaStack spacing={0.75} sx={{ minWidth: 0 }}>
                    {(migrationAgentState.pendingPermission.questions?.[0]?.options ?? []).map((option) => (
                      <QuestionChoiceButton
                        key={option.id ?? option.label}
                        label={option.label}
                        description={option.description}
                        recommended={option.recommended}
                        confidence={option.confidence ?? null}
                        disabled={reviewDecisionBusy}
                        onClick={() => handlePermissionChoice(String(option.id), option.label)}
                      />
                    ))}
                    {migrationAgentState.pendingPermission.allow_free_text !== false && (() => {
                      const count = migrationAgentState.pendingPermission?.questions?.[0]?.options?.length ?? 0;
                      return <AiaStack spacing={0.75} sx={{ minWidth: 0 }}>
                        {count > 0 && <QuestionChoiceButton label="Other" disabled={reviewDecisionBusy}
                          onClick={() => setOtherAnswerOpen(open => !open)} />}
                        {(count === 0 || otherAnswerOpen) && <>
                          <AiaInput value={otherAnswer} onChange={setOtherAnswer} multiline minRows={2}
                            placeholder={migrationAgentState.pendingPermission.answer_hint || 'Answer this question'} />
                          <AiaButton size="small" variant="outlined" disabled={!otherAnswer.trim() || reviewDecisionBusy}
                            onClick={() => void submitQuestionAnswer(null, otherAnswer.trim(), otherAnswer.trim())}
                            sx={{ alignSelf: 'flex-start', textTransform: 'none' }}>
                            {reviewDecisionBusy ? 'Saving…' : 'Send answer'}
                          </AiaButton>
                        </>}
                      </AiaStack>;
                    })()}
                    {reviewDecisionError ? <AiaText role="alert" sx={{ color: '#b91c1c', fontSize: 12 }}>{reviewDecisionError}</AiaText> : null}
                    <AiaButton
                      size="small"
                      variant="text"
                      onClick={() => handlePermissionDecision("cancel")}
                      sx={{ alignSelf: "flex-start", textTransform: "none", color: "#64748b" }}
                    >
                      Cancel
                    </AiaButton>
                  </AiaStack>
                </AiaStack>
              </AiaPaper>
            )}

            {/* Migration Agent Error Display */}
            {migrationAgentState.error && (
              <AiaPaper
                elevation={0}
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  border: "1px solid #fecaca",
                  backgroundColor: "#fef2f2",
                }}
              >
                <AiaStack direction="row" spacing={1} sx={{ alignItems: "center" }}>
                  <WarningAmberRoundedIcon sx={{ fontSize: 18, color: "#dc2626" }} />
                  <AiaText sx={{ fontSize: 13, color: "#991b1b" }}>{migrationAgentState.error}</AiaText>
                </AiaStack>
              </AiaPaper>
            )}

          </>
        ) : (
          /* Quick Assistant messages */
          visibleStandardChatMessages.map((message, index) => {
            const isAssistant = message.role === "assistant";
            const messageId = message.id ?? `${message.role}-${index}-${message.content.slice(0, 24)}`;
            const isWelcome =
              isAssistant
              && (
                message.id === "sttm-assistant-welcome"
                || message.content.includes(
                  "I can use the selected source and target semantics",
                )
              );
            if (hideComposer && isWelcome) return null;
            const traceSteps = message.traceSteps ?? [];
            const isTraceExpanded = message.isStreaming || !!expandedTraces[messageId];
            return (
              <AiaStack
                key={messageId}
                direction="column"
                spacing={0.5}
                sx={{
                  alignItems: isAssistant ? "flex-start" : "flex-end",
                  ...(isWelcome
                    ? {
                        width: "100%",
                        maxWidth: 520,
                        alignItems: "center",
                        justifyContent: "center",
                      }
                    : {}),
                }}
              >
                <AiaStack
                  direction="row"
                  spacing={1.5}
                  sx={{
                    justifyContent: isWelcome ? "center" : isAssistant ? "flex-start" : "flex-end",
                    width: "100%",
                  }}
                >
                  {isAssistant && !isWelcome ? (
                    <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
                      <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
                    </AiaAvatar>
                  ) : null}

                  <AiaPaper
                  elevation={0}
                  sx={{
                    p: 1.5,
                    borderRadius: isAssistant ? "0 12px 12px 12px" : "12px 0 12px 12px",
                    border: "1px solid #e2e8f0",
                    maxWidth: expanded ? "92%" : "85%",
                    minWidth: 0,
                    overflow: "hidden",
                    backgroundColor: isAssistant ? "#ffffff" : "#f8fafc",
                    ...(isWelcome
                      ? {
                          width: "100%",
                          maxWidth: "100%",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          justifyContent: "center",
                          border: "none",
                          borderRadius: 0,
                          px: expanded ? 8 : 6,
                          py: 3,
                          backgroundColor: "transparent",
                        }
                      : {}),
                  }}
                >
                  <AiaBox sx={{ minWidth: 0, maxWidth: "100%", fontSize: 14, overflowX: "hidden" }}>
                    {isWelcome ? (
                      <AiaBox sx={{ width: "100%", maxWidth: 520, mb: 2.5, textAlign: "center" }}>
                        <AiaText
                          sx={{
                            fontSize: expanded ? 58 : 50,
                            lineHeight: 1.04,
                            fontWeight: 500,
                            color: "#0f172a",
                            letterSpacing: "-0.035em",
                          }}
                        >
                          Hi{assistantFirstName ? ` ${assistantFirstName}` : ""},
                        </AiaText>
                        <AiaText
                          sx={{
                            mt: 0.5,
                            fontSize: expanded ? 58 : 50,
                            lineHeight: 1.04,
                            fontWeight: 400,
                            color: "#64748b",
                            letterSpacing: "-0.035em",
                          }}
                        >
                          How can I help?
                        </AiaText>
                        {message.content.trim() ? (
                          <AiaText sx={{ mt: 2, fontSize: 13.5, color: "#475569", lineHeight: 1.6 }}>
                            {message.content}
                          </AiaText>
                        ) : null}
                      </AiaBox>
                    ) : (
                      <MessageContent content={message.content} formatPlainText={isAssistant} />
                    )}
                    {message.streamingSql ? (
                      <MessageContent
                        content={`\`\`\`sql\n${message.streamingSql}\n\`\`\``}
                        formatPlainText={false}
                      />
                    ) : null}
                  </AiaBox>
                  {traceSteps.length ? (
                    <TracePanel
                      messageId={messageId}
                      steps={traceSteps}
                      expanded={isTraceExpanded}
                      onToggle={toggleTrace}
                    />
                  ) : null}
                  {message.isStreaming ? (
                    <StreamingProgressIndicator
                      phase={message.statusPhase}
                      message={message.statusMessage}
                      elapsedSeconds={message.elapsedSeconds}
                    />
                  ) : null}
                  {message.options?.length ? (
                    <AiaStack
                      direction={isWelcome ? "column" : "row"}
                      spacing={0.75}
                      useFlexGap
                      sx={{
                        mt: 1.25,
                        // Column layout must not wrap: wrapping a column flex
                        // container pushes the extra options into off-screen
                        // columns instead of stacking them.
                        flexWrap: isWelcome ? "nowrap" : "wrap",
                        width: "100%",
                        maxWidth: isWelcome ? 460 : "100%",
                        alignItems: isWelcome ? "center" : undefined,
                        mx: 0,
                        minWidth: 0,
                        overflow: "hidden",
                      }}
                    >
                      {message.options.map((option) => (
                        <AiaButton
                          key={option}
                          size="small"
                          variant="outlined"
                          onClick={() => sendChatMessage(option)}
                          disabled={chatLoading}
                          sx={{
                            textTransform: "none",
                            borderRadius: "999px",
                            borderColor: "#bfdbfe",
                            color: "#1d4ed8",
                            fontSize: isWelcome ? 13 : 12,
                            lineHeight: 1.4,
                            minWidth: 0,
                            maxWidth: "100%",
                            height: "auto",
                            // In a column stack `flex-basis: 100%` resolves
                            // against the container height, so keep the pills
                            // sized by their content and full-width via `width`.
                            flex: isWelcome ? "0 0 auto" : "0 1 auto",
                            width: isWelcome ? "100%" : "auto",
                            whiteSpace: "normal",
                            overflowWrap: "anywhere",
                            wordBreak: "break-word",
                            textAlign: "left",
                            justifyContent: "flex-start",
                            py: isWelcome ? 1.15 : 0.75,
                            px: isWelcome ? 1.75 : undefined,
                            "&:hover": {
                              borderColor: "#93c5fd",
                              backgroundColor: "#eff6ff",
                            },
                          }}
                        >
                          {option}
                        </AiaButton>
                      ))}
                    </AiaStack>
                  ) : null}
                </AiaPaper>
                </AiaStack>
                {isAssistant && !isWelcome && !message.isStreaming ? (
                  <AiaStack direction="row" spacing={0.75} sx={{ mt: 0.5, ml: 3.5 }}>
                    <AiaIconButton
                      size="small"
                      onClick={() => {
                        navigator.clipboard.writeText(message.content);
                      }}
                      sx={{ color: "#94a3b8", "&:hover": { color: "#64748b" } }}
                      title="Copy response"
                    >
                      <ContentCopyRoundedIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                    <AiaIconButton
                      size="small"
                      onClick={() => {
                        if (message.id) {
                          submitChatFeedback({ messageId: message.id, rating: 5 });
                        }
                      }}
                      disabled={!message.id || message.feedbackStatus === "sent"}
                      sx={{
                        color: message.feedbackRating === 5 ? "#16a34a" : "#94a3b8",
                        "&:hover": { color: "#16a34a" },
                      }}
                      title="This was helpful"
                    >
                      <ThumbUpAltOutlinedIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                    <AiaIconButton
                      size="small"
                      onClick={() => {
                        if (message.id) {
                          submitChatFeedback({ messageId: message.id, rating: 1 });
                        }
                      }}
                      disabled={!message.id || message.feedbackStatus === "sent"}
                      sx={{
                        color: message.feedbackRating === 1 ? "#dc2626" : "#94a3b8",
                        "&:hover": { color: "#dc2626" },
                      }}
                      title="This wasn't helpful"
                    >
                      <ThumbDownAltOutlinedIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                    <AiaIconButton
                      size="small"
                      onClick={() => sendChatMessage("Can you provide an alternative response?")}
                      disabled={chatLoading}
                      sx={{ color: "#94a3b8", "&:hover": { color: "#2563eb" } }}
                      title="Regenerate response"
                    >
                      <BoltIcon sx={{ fontSize: 16 }} />
                    </AiaIconButton>
                  </AiaStack>
                ) : null}
              </AiaStack>
            );
          })
        )}

        {/* Standard mode loading indicator - only show when not in Migration Agent mode */}
        {!migrationAgentState.isActive && chatLoading && !hasStreamingMessage ? (
          <AiaStack direction="row" spacing={1.5} sx={{ alignItems: "center" }}>
            <AiaAvatar sx={{ bgcolor: 'var(--aia-assitant-header-color)', width: 28, height: 28 }}>
              <AutoAwesomeRoundedIcon sx={{ fontSize: 16 }} />
            </AiaAvatar>
            <AiaPaper
              elevation={0}
              sx={{
                px: 1.5,
                py: 1.25,
                borderRadius: "0 12px 12px 12px",
                border: "1px solid #e2e8f0",
                backgroundColor: "#ffffff",
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              <AiaCircularProgress size={14} thickness={5} sx={{ color: "#2563eb" }} />
              <AiaText variant="body1" sx={{ color: "#475569" }}>
                Thinking…
              </AiaText>
            </AiaPaper>
          </AiaStack>
        ) : null}

        {activeReview ? (
          <AiaPaper
            elevation={0}
            sx={{
              p: 1.5,
              borderRadius: "12px",
              border: "1px solid #e2e8f0",
              backgroundColor: "#fffbeb",
              display: "grid",
              gap: 1,
            }}
          >
            <AiaBox>
              <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#92400e" }}>
                {isTransformationReview
                  ? "Review AI transformation suggestion"
                  : "Review AI mapping suggestion"}
              </AiaText>
              <AiaText sx={{ fontSize: 12, color: "#475569", mt: 0.35 }}>
                {activeReview.targetColumn} · {Math.round(activeReview.confidenceScore * 100)}% confidence
              </AiaText>
            </AiaBox>
            <AiaBox sx={{ display: "grid", gap: 0.75 }}>
              <AiaText sx={{ fontSize: 12.5, color: "#0f172a" }}>
                <strong>Suggested source:</strong> {activeReview.sourceAttributes.join(", ") || "No confident source found"}
              </AiaText>
              {activeReview.preprocessingRule ? (
                <AiaBox
                  component="pre"
                  sx={{
                    m: 0,
                    px: 1.25,
                    py: 1,
                    borderRadius: 1.5,
                    backgroundColor: "#fff7ed",
                    border: "1px solid #fed7aa",
                    color: "#7c2d12",
                    fontSize: 12,
                    whiteSpace: "pre-wrap",
                    overflowX: "auto",
                  }}
                >
                  <strong>Suggested SQL rule:</strong>
                  {"\n"}
                  {activeReview.preprocessingRule}
                </AiaBox>
              ) : null}
              {activeReview.preprocessingNlRule ? (
                <AiaText sx={{ fontSize: 12.5, color: "#0f172a" }}>
                  <strong>Why:</strong> {activeReview.preprocessingNlRule}
                </AiaText>
              ) : null}
              {activeReview.confidenceReason ? (
                <AiaText sx={{ fontSize: 12.5, color: "#475569", lineHeight: 1.6 }}>
                  {activeReview.confidenceReason}
                </AiaText>
              ) : null}
              {!activeReview.confidenceReason && activeReview.unmatchedReason ? (
                <AiaText sx={{ fontSize: 12.5, color: "#b45309", lineHeight: 1.6 }}>
                  {activeReview.unmatchedReason}
                </AiaText>
              ) : null}
              {activeReview.candidateSourceAttributes.length > 0 ? (
                <AiaText sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.6 }}>
                  Alternatives: {activeReview.candidateSourceAttributes.join(", ")}
                </AiaText>
              ) : null}
            </AiaBox>
            <AiaStack direction="row" spacing={1} useFlexGap sx={{ flexWrap: "wrap" }}>
              <AiaButton
                size="small"
                variant="contained"
                onClick={applyPendingAiMappingReview}
                sx={{
                  textTransform: "none",
                  borderRadius: "999px",
                  boxShadow: "none",
                  backgroundColor: "#1d4ed8",
                  "&:hover": { backgroundColor: "#1e40af", boxShadow: "none" },
                }}
              >
                Apply Changes
              </AiaButton>
              <AiaButton
                size="small"
                variant="outlined"
                onClick={() =>
                  setDraft(
                    isTransformationReview
                      ? `Revise the transformation rule for ${activeReview.targetColumn}. Use these notes: `
                      : `Revise the mapping for ${activeReview.targetColumn}. Use these notes: `,
                  )
                }
                sx={{
                  textTransform: "none",
                  borderRadius: "999px",
                }}
              >
                Make Further Changes
              </AiaButton>
              <AiaButton
                size="small"
                variant="text"
                onClick={skipPendingAiMappingReview}
                sx={{ textTransform: "none", color: "#64748b" }}
              >
                Dismiss
              </AiaButton>
            </AiaStack>
          </AiaPaper>
        ) : null}

        {pendingDerivedSourceDraft ? (
          <AiaPaper
            elevation={0}
            sx={{
              p: 1.5,
              borderRadius: "12px",
              border: "1px solid #dbeafe",
              backgroundColor: "#eff6ff",
              display: "grid",
              gap: 1,
            }}
          >
            <AiaBox>
              <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#1d4ed8" }}>
                Analyst-generated derived SQL is ready
              </AiaText>
              <AiaText sx={{ fontSize: 12, color: "#334155", mt: 0.25 }}>
                Open it in the derived-source builder to validate, preview, and save it through the existing flow.
              </AiaText>
            </AiaBox>
            <AiaStack direction="row" spacing={1}>
              <AiaButton
                size="small"
                variant="contained"
                onClick={openPendingDerivedSourceDraft}
                sx={{
                  textTransform: "none",
                  borderRadius: "999px",
                  boxShadow: "none",
                  backgroundColor: "#1d4ed8",
                  "&:hover": { backgroundColor: "#1e40af", boxShadow: "none" },
                }}
              >
                Open In Derived Builder
              </AiaButton>
              <AiaButton
                size="small"
                variant="text"
                onClick={dismissPendingDerivedSourceDraft}
                sx={{ textTransform: "none", color: "#475569" }}
              >
                Dismiss
              </AiaButton>
            </AiaStack>
          </AiaPaper>
        ) : null}
          </>
        ) : null}
        </AiaBox>
      </AiaBox>
      {showJumpToLatest ? <AiaBox sx={{px:2,py:.75,flexShrink:0,width:'100%',maxWidth:pageMode?AI_AGENT_PAGE_CONTENT_MAX_WIDTH:undefined,mx:pageMode?'auto':undefined,borderTop:'1px solid #e2e8f0'}}>
        <AiaButton size="small" variant="outlined" onClick={()=>syncMessageScroll('jump')} startIcon={<KeyboardArrowDownIcon/>}
          sx={{width:'100%',textTransform:'none'}}>Jump to latest</AiaButton>
      </AiaBox> : null}
      <AiaBox sx={{ p: 1, backgroundColor: "#ffffff", borderTop: "1px solid #e2e8f0" }}>
        {migrationAgentState.isActive && migrationPlanEvent ? (
          <MigrationPlanStatusChip
            event={migrationPlanEvent}
            waitingForAnswer={Boolean(migrationAgentState.pendingPermission)}
            hasDraft={Boolean(reviewDraftId)}
            running={migrationAgentState.isRunning}
            needsReview={migrationAgentState.traceEvents.some((event) => event.status === "needs_review")}
            activeLabel={migrationActiveLabel}
          />
        ) : null}
        {migrationAgentState.isActive && migrationAgentState.isRunning && !migrationPlanEvent ? (
          <MigrationRunStatusChip
            label={
              migrationAgentMessages[migrationAgentMessages.length - 1]?.animate
                ? "Streaming response"
                : migrationAgentState.statusMessage || "Agent is working"
            }
          />
        ) : null}
        {migrationAgentState.isActive && migrationAgentState.isRunning && migrationRunProgress ? (
          <MigrationProgressStrip progress={migrationRunProgress} />
        ) : null}
        {migrationAgentState.isActive && migrationAttachments.length > 0 && (
          <AiaText sx={{ px: 1, pb: 0.5, fontSize: 10, color: "#64748b" }}>
            Attachments: {migrationAttachments.map((attachment) => attachment.name).join(", ")}
          </AiaText>
        )}
        {!hideComposer && pendingDeepMessages.map(item => (
          <AiaStack key={item.id} direction="row" sx={{ gap: 1, alignItems: 'center', px: 1 }}>
            <AiaText noWrap sx={{ flex: 1, fontSize: 12 }}>{item.status === 'pending' ? 'Queued' : 'In progress'} · {item.message}</AiaText>
            {item.status === 'pending' && <AiaButton size="small" onClick={() => void removeQueuedMessage(item.id)}
              sx={{ textTransform: 'none' }}>Remove</AiaButton>}
          </AiaStack>
        ))}
        {!hideComposer && inboxError && <AiaText role="alert" sx={{ px: 1, color: '#b91c1c', fontSize: 12 }}>{inboxError}</AiaText>}
        {!hideComposer && <AiChatComposer
          value={draft}
          onChange={setDraft}
          onSend={handleSend}
          onQueue={deepSendApi.canQueue && (migrationAgentState.isRunning || migrationAgentState.pendingPermission) ? async (mode) => {
            try {
              await queueDeepMessage(draft.trim(), mode, { effort: migrationEffort, modelName: migrationModelName, runMode: migrationRunMode });
              setDraft("");
            } catch (error) {
              setInboxError(error instanceof Error ? error.message : 'Could not queue the message.');
            }
          } : undefined}
          mode={migrationAgentState.isActive ? "deep" : "quick"}
          onModeChange={(mode) => {
            if ((mode === "deep") !== migrationAgentState.isActive) {
              toggleMigrationAgentMode();
            }
          }}
          effort={migrationEffort}
          onEffortChange={setMigrationEffort}
          contextUsage={migrationAgentState.isActive ? migrationContextUsage : null}
          modelName={migrationModelName}
          onModelNameChange={setMigrationModelName}
          modelOptions={migrationModelOptions}
          effortModelDefaults={migrationEffortModels}
          runMode={migrationRunMode}
          onRunModeChange={setMigrationRunMode}
          deepAgentAvailable={migrationAgentAvailable !== false}
          onAttachFile={(file) => void handleMigrationAttachment(file)}
          attachmentUploading={migrationAttachmentUploading}
          running={migrationAgentState.isRunning && !migrationAgentState.pendingPermission}
          cancelling={migrationAgentState.isCancelling}
          onCancel={() => {
            if (migrationAgentState.isCancelling) return;
            setMigrationAgentState((state) => ({
              ...state,
              isCancelling: true,
              statusMessage: "Stopping at the next safe boundary…",
            }));
            migrationAgentClientRef.current?.cancel("");
          }}
          disabled={migrationAgentState.isActive
            ? migrationAgentState.isConnecting
              || Boolean(pendingPlanOffer)
              || (Boolean(migrationAgentState.pendingPermission) && !deepSendApi.canQueue)
            : false}
          loading={migrationAgentState.isActive ? migrationAgentState.isRunning && !migrationAgentState.pendingPermission : chatLoading}
        />}
      </AiaBox>
      {pendingPlanOffer ? (
        <AiaBox role="dialog" aria-modal="true" aria-label="Choose planning mode" sx={{ position: "fixed", inset: 0, zIndex: 1600, display: "grid", placeItems: "center", p: 2, backgroundColor: "rgba(15, 23, 42, 0.45)" }}>
          <AiaPaper sx={{ width: "min(520px, 100%)", p: 2.5, borderRadius: 2, boxShadow: "0 24px 64px rgba(15,23,42,0.25)" }}>
            <AiaText sx={{ fontSize: 17, fontWeight: 800, color: "#0f172a" }}>Review a plan first?</AiaText>
            <AiaText sx={{ mt: 0.7, fontSize: 13, lineHeight: 1.5, color: "#475569" }}>{pendingPlanOffer.reason}</AiaText>
            <AiaStack spacing={0.8} sx={{ mt: 2 }}>
              <AiaButton variant="contained" onClick={() => {
                setPendingPlanOffer(null);
                setMigrationRunMode("plan");
                setMigrationAgentState((prev) => ({ ...prev, isRunning: true, statusMessage: "Preparing a reviewable plan…" }));
                migrationAgentClientRef.current?.resumePlanOffer("plan");
              }} sx={{ textTransform: "none" }}>Switch to Plan mode</AiaButton>
              <AiaButton variant="outlined" onClick={() => {
                setPendingPlanOffer(null);
                setMigrationRunMode("auto");
                setMigrationAgentState((prev) => ({ ...prev, isRunning: true, statusMessage: "Continuing automatically…" }));
                migrationAgentClientRef.current?.resumePlanOffer("auto");
              }} sx={{ textTransform: "none" }}>Continue automatically</AiaButton>
              <AiaButton variant="text" onClick={() => {
                migrationAgentClientRef.current?.dismissPlanOffer();
                setPendingPlanOffer(null);
                setMigrationAgentState((prev) => ({ ...prev, isRunning: false, statusMessage: null }));
              }} sx={{ textTransform: "none" }}>Cancel request</AiaButton>
            </AiaStack>
          </AiaPaper>
        </AiaBox>
      ) : null}
      {migrationAgentState.pendingPermission?.category === "plan_mode_recommendation" ? (
        <AiaBox role="dialog" aria-modal="true" aria-label="Choose planning mode" sx={{ position: "fixed", inset: 0, zIndex: 1600, display: "grid", placeItems: "center", p: 2, backgroundColor: "rgba(15, 23, 42, 0.45)" }}>
          <AiaPaper sx={{ width: "min(520px, 100%)", p: 2.5, borderRadius: 2, boxShadow: "0 24px 64px rgba(15,23,42,0.25)" }}>
            <AiaText sx={{ fontSize: 17, fontWeight: 800, color: "#0f172a" }}>Review a plan first?</AiaText>
            <AiaText sx={{ mt: 0.7, fontSize: 13, lineHeight: 1.5, color: "#475569" }}>{migrationAgentState.pendingPermission.reason}</AiaText>
            <AiaStack spacing={0.8} sx={{ mt: 2 }}>
              {(migrationAgentState.pendingPermission.questions?.[0]?.options ?? []).map((option) => (
                <QuestionChoiceButton
                  key={option.id ?? option.label}
                  label={option.label}
                  description={option.description}
                  recommended={option.recommended}
                  onClick={() => handlePermissionChoice(String(option.id), option.label)}
                />
              ))}
            </AiaStack>
          </AiaPaper>
        </AiaBox>
      ) : null}
    </AiaPaper>
    {planSidebarOpen && (planDocument || hasResults || researchReport) ? <AgentArtifactPane
      key={artifactVersion}
      pageMode={pageMode}
      tab={artifactTab}
      onClose={() => setPlanSidebarOpen(false)}
      plan={planDocument}
      planContent={planDocument ? <>
        <AiaText component="h2" sx={{ mx: 1, my: 1.5, fontSize: 18, lineHeight: 1.4, fontWeight: 650, overflowWrap: 'anywhere' }}>
          {planTitle}
        </AiaText>
        <MigrationPlanApprovalSummary plan={planDocument} />
      </> : null}
      hasResearch={Boolean(researchReport)}
      researchText={researchReport}
      researchContent={researchReport ? <MessageContent content={researchReport} /> : null}
      sqlArtifact={visibleSqlArtifact}
      sqlArtifacts={finalSqlArtifacts.length > 1 ? finalSqlArtifacts : undefined}
      sqlActionDisabled={migrationAgentState.isRunning || migrationAgentState.isConnecting || Boolean(migrationAgentState.pendingPermission)}
      sqlActionBlockReason={migrationAgentState.pendingPermission
        ? 'Answer the current agent question before requesting another SQL revision.'
        : migrationAgentState.isRunning || migrationAgentState.isConnecting
          ? 'You can draft feedback now. Send it after this agent run stops.' : null}
      onSqlRevision={(sql, note, mappingName) => { handleSend(`Revise the generated SQL for ${mappingName || 'the current mapping'} to use the following edited SQL. Compile it and run a bounded preview before returning the new SQL and results. ${note ? `Review note: ${note}\n\n` : ''}\`\`\`sql\n${sql}\n\`\`\``); }}
      onSqlReject={(reason, mappingName) => { handleSend(`I reject the generated SQL for ${mappingName || 'the current mapping'} because: ${reason}. Revise the SQL, compile it, and return a bounded sample preview for review.`); }}
      reviewContent={<>
        {createdProjectId ? (
          <AiaBox component="a" href={`/projects/${encodeURIComponent(createdProjectId)}`}
            sx={{ display: 'inline-block', my: 1, fontSize: 13, fontWeight: 600, color: '#1d4ed8' }}>
            {createdProject.project_name ? `Open project: ${String(createdProject.project_name)}` : 'Open created project'}
          </AiaBox>
        ) : null}
        {pageMode ? <AiaStack spacing={1.25}>
          {openReviewItems.map((item) => <AiaBox key={item.id} sx={{p:1.25,border:'1px solid #e2e8f0',borderRadius:1.5}}>
            <AiaText sx={{fontSize:13,lineHeight:1.6,color:'#334155'}}>{item.summary.replace(/The plan needs at least one in-scope mapping candidate\. Set allow_partial_coverage to present the remaining columns explicitly for review\./g, 'The agent has not finished preparing supported column mappings. The researched tables are saved.')}</AiaText>
            {item.question && item.question !== item.summary ? <AiaText sx={{mt:0.5,fontSize:12,color:'#64748b'}}>{item.question}</AiaText> : null}
            {item.choices.length >= 2 ? <AiaText sx={{mt:0.75,fontSize:12,color:'#64748b'}}>You can respond in the main conversation.</AiaText> : null}
          </AiaBox>)}
        </AiaStack> : null}
        {!pageMode && reviewTable?.rows.some((row) => row.mapping_key || row.sttm_id) ? <AiaBox>
          <AgentReviewTable table={reviewTable} busy={reviewDecisionBusy || migrationAgentState.isRunning}
            error={reviewDecisionError} selectedReviewItemId={selectedReviewItemId}
            decisionContent={selectedReviewItemId ? <AgentReviewList
              items={openReviewItems.filter((item) => item.id === selectedReviewItemId)}
              busy={reviewDecisionBusy || migrationAgentState.isRunning} error={reviewDecisionError}
              onAnswer={(itemId, choiceId, text) => {
                answerReviewItem(itemId, choiceId, text);
                setSelectedReviewItemId(null);
              }} /> : null}
            onAccept={acceptReviewRows} onOpenDecision={openReviewCard} />
        </AiaBox> : null}
        {!pageMode && !reviewTable?.rows.some((row) => row.mapping_key || row.sttm_id) ? <AgentReviewList items={openReviewItems} busy={reviewDecisionBusy || migrationAgentState.isRunning}
          error={reviewDecisionError} onAnswer={answerReviewItem} /> : null}
        {reviewDraftId && !visibleSqlArtifact?.sttmId && !finalSqlArtifacts.some((artifact) => artifact.sttmId) ? <AiaBox component="a" href={`/sttm/builder/${encodeURIComponent(reviewDraftId)}/mapping`}
          sx={{ display: 'inline-block', mt: 1, fontSize: 12, fontWeight: 600, color: '#1d4ed8' }}>Open saved mapping draft</AiaBox> : null}
        <AgentLearnedList items={learned} />
        {cleanMappings.length ? <AiaBox sx={{ mt: 1 }}>
          {publishConfirmOpen ? <>
            <AiaText sx={{ fontSize: 12, color: "#0f172a" }}>
              Publish {cleanMappings.map((item) => item.mappingName).join(", ")}? Their SQL compiled and previewed; each becomes a published version you can load.
            </AiaText>
            <AiaStack direction="row" spacing={0.75} sx={{ mt: 0.75 }}>
              <AiaButton size="small" variant="contained" disabled={publishBusy} onClick={() => void publishCleanMappings()} sx={{ textTransform: 'none' }}>
                {publishBusy ? 'Publishing…' : 'Publish'}
              </AiaButton>
              <AiaButton size="small" variant="text" disabled={publishBusy} onClick={() => setPublishConfirmOpen(false)} sx={{ textTransform: 'none' }}>Cancel</AiaButton>
            </AiaStack>
          </> : <AiaButton size="small" variant="outlined" onClick={() => setPublishConfirmOpen(true)} sx={{ textTransform: 'none' }}>
            Publish {cleanMappings.length} clean mapping{cleanMappings.length === 1 ? '' : 's'}
          </AiaButton>}
          {publishMessage ? <AiaText sx={{ mt: 0.5, fontSize: 11, color: publishMessage.ok ? '#047857' : '#b91c1c' }}>{publishMessage.text}</AiaText> : null}
        </AiaBox> : null}

      </>}
    /> : null}
    </AiaBox>
  );
}
