"use client";

import { AiaBox, AiaStack } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import type { StoredChatSession } from "@/features/ai-agent/ai-chat-session-utils";
import { formatSessionRelativeTime } from "@/features/ai-agent/ai-chat-session-utils";
import { ChatBubbleOutlineRoundedIcon, DeleteOutlinedIcon } from "@/utils/icons";

type AiChatHistoryPanelProps = {
  sessions: StoredChatSession[];
  searchQuery: string;
  activeSessionId: string | null;
  onSelectSession: (session: StoredChatSession) => void;
  onDeleteSession: (session: StoredChatSession) => Promise<void>;
};

export function AiChatHistoryPanel({
  sessions,
  searchQuery,
  activeSessionId,
  onSelectSession,
  onDeleteSession,
}: AiChatHistoryPanelProps) {
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const filteredSessions = normalizedQuery
    ? sessions.filter((session) => session.title.toLowerCase().includes(normalizedQuery))
    : sessions;

  return (
    <AiaBox
      sx={{
        flex: 1,
        minHeight: 0,
        overflowY: "auto",
        backgroundColor: "#ffffff",
        px: 1.5,
        py: 1.5,
      }}
    >
      {filteredSessions.length === 0 ? (
        <AiaBox sx={{ py: 6, textAlign: "center" }}>
          <AiaText sx={{ fontSize: 14, color: "#64748b" }}>
            {normalizedQuery ? "No chats match your search." : "No chat history yet."}
          </AiaText>
        </AiaBox>
      ) : (
        <AiaStack spacing={0.5}>
          {filteredSessions.map((session) => {
            const isActive = session.id === activeSessionId;
            return (
              <AiaBox
                key={session.id}
                sx={{
                  width: "100%",
                  borderRadius: "12px",
                  display: "flex",
                  alignItems: "center",
                  backgroundColor: isActive ? "#eff6ff" : "transparent",
                  "&:hover": { backgroundColor: isActive ? "#eff6ff" : "#f8fafc" },
                }}
              >
                <AiaBox component="button" type="button" onClick={() => onSelectSession(session)} sx={{ flex: 1, minWidth: 0, display: "flex", alignItems: "flex-start", gap: 1.25, textAlign: "left", border: "none", cursor: "pointer", background: "transparent", px: 1.25, py: 1.25 }}>
                  <ChatBubbleOutlineRoundedIcon sx={{ fontSize: 18, color: "#64748b", mt: 0.25, flexShrink: 0 }} />
                  <AiaBox sx={{ minWidth: 0, flex: 1 }}>
                    <AiaText sx={{ fontSize: 14, fontWeight: 700, color: "#0f172a", lineHeight: 1.35, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {session.title}
                    </AiaText>
                    <AiaStack direction="row" spacing={0.75} sx={{ mt: 0.35, alignItems: "center" }}>
                      <AiaText sx={{ fontSize: 12, color: "#94a3b8" }}>
                        {formatSessionRelativeTime(session.updatedAt)}
                      </AiaText>
                      <AiaText
                        component="span"
                        sx={{
                          px: 0.65,
                          py: 0.1,
                          borderRadius: "999px",
                          fontSize: 10,
                          fontWeight: 700,
                          color: session.mode === "deep" ? "#1d4ed8" : "#475569",
                          backgroundColor: session.mode === "deep" ? "#dbeafe" : "#f1f5f9",
                        }}
                      >
                        {session.mode === "deep" ? "Deep" : "Quick"}
                      </AiaText>
                    </AiaStack>
                  </AiaBox>
                </AiaBox>
                <AiaBox component="button" type="button" aria-label={`Delete ${session.title}`} title="Delete conversation" onClick={() => {
                  if (window.confirm(`Delete “${session.title}” from chat history?`)) {
                    void onDeleteSession(session);
                  }
                }} sx={{ border: "none", background: "transparent", color: "#94a3b8", cursor: "pointer", p: 1, mr: 0.5, borderRadius: 1.5, "&:hover": { color: "#dc2626", backgroundColor: "#fee2e2" } }}>
                  <DeleteOutlinedIcon sx={{ fontSize: 18 }} />
                </AiaBox>
              </AiaBox>
            );
          })}
        </AiaStack>
      )}
    </AiaBox>
  );
}
