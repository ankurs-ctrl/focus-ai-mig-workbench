from app.routers.notifications import _apply_checkpoint_policy


def test_q6_source_set_warning_is_canonicalized_as_relationship() -> None:
    items, questions = _apply_checkpoint_policy(
        [
            {
                "recommendation_id": "rec-q6",
                "milestone": "source_set_completed",
                "recommendation_category": "validation",
                "recommendation_type": "correction_warning",
                "question_id": "Q6",
            }
        ],
        {
            "eligible_goals": ["Q6", "Q9"],
            "recommendation_categories": ["relationship", "query_shaping"],
            "max_inline_items": 8,
            "max_interruptive_questions": 1,
            "display_surfaces": ["inline", "inbox", "assistant"],
        },
        8,
    )

    assert [item["recommendation_id"] for item in items] == ["rec-q6"]
    assert items[0]["recommendation_category"] == "relationship"
    assert [item["recommendation_id"] for item in questions] == ["rec-q6"]


def test_schema_candidate_guidance_is_visible_but_not_interruptive() -> None:
    items, questions = _apply_checkpoint_policy(
        [
            {
                "recommendation_id": "rec-table",
                "milestone": "schema_browsed",
                "recommendation_category": "source_discovery",
                "recommendation_type": "context_enrichment",
                "question_id": "Q1",
            }
        ],
        {
            "eligible_goals": ["Q1", "Q6"],
            "recommendation_categories": ["source_discovery", "relationship"],
            "max_inline_items": 8,
            "max_interruptive_questions": 1,
            "display_surfaces": ["inline", "inbox"],
        },
        8,
    )

    assert [item["recommendation_id"] for item in items] == ["rec-table"]
    assert questions == []


def test_persistent_inbox_can_return_more_than_inline_limit() -> None:
    items, questions = _apply_checkpoint_policy(
        [
            {
                "recommendation_id": f"rec-{index}",
                "milestone": "source_set_completed",
                "recommendation_category": "relationship",
                "recommendation_type": "relationship_hint",
            }
            for index in range(6)
        ],
        {
            "eligible_goals": ["Q6", "Q9"],
            "recommendation_categories": ["relationship", "query_shaping"],
            "max_inline_items": 2,
            "max_interruptive_questions": 1,
            "display_surfaces": ["inline", "inbox", "assistant"],
        },
        10,
        respect_inline_limit=False,
    )

    assert len(items) == 6
    assert questions == []
