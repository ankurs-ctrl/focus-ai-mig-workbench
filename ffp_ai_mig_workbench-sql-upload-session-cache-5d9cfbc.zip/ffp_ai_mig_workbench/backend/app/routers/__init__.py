"""FastAPI routers."""

