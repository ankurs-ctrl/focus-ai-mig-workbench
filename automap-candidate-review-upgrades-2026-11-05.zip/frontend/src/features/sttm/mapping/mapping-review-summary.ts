import type { MappingState, DerivedSource, TableNode } from '../types/sttm.types';
import { alternativeCandidates, currentCandidate, definitionKey, guidanceForRow, reviewCatalog } from './mapping-review-model';
import { rowReviewUrl, mappingBase } from './review-navigation';

const escape = (text: string) => text.replace(/[\\`*_{}[\]<>#|]/g, '\\$&').replace(/\s+/g, ' ').trim();
const code = (text: string) => {const ticks='`'.repeat(Math.max(0,...Array.from(text.matchAll(/`+/g),match=>match[0].length))+1);return `${ticks}${text.replace(/[\r\n]/g,' ')}${ticks}`;};
export function mappingReviewSummary(rows: MappingState[], baseline: Record<string, MappingState>, sources: TableNode[], derived: DerivedSource[], sttmId: string | null) {
  const catalog=reviewCatalog(sources,derived);
  const hasDefinition=(row: MappingState)=>Boolean(row.sourceColumn || row.sourceColumns?.length || row.expression || row.attributeName || row.constantValue != null);
  const retained=rows.filter(row=>baseline[row.id] && hasDefinition(baseline[row.id]) && definitionKey(row,catalog)===definitionKey(baseline[row.id],catalog));
  const applied=rows.filter(row=>row.aiReviewStatus==='unreviewed' && row.selectedAiCandidateId
    && (!baseline[row.id] || !hasDefinition(baseline[row.id]) || definitionKey(row,catalog)!==definitionKey(baseline[row.id],catalog)));
  const alternatives=rows.filter(row=>alternativeCandidates(row,catalog).length);
  const unresolved=rows.filter(row=>row.status!=='MAPPED');
  const needsInput=rows.filter(row=>guidanceForRow(row).some(item=>['relationship','value','business_rule','outside_selection','evidence'].includes(item.kind))
    || (hasDefinition(row) && currentCandidate(row,catalog)?.validation_status !== 'valid' && row.aiReviewStatus === 'unreviewed'));
  const low=rows.filter(row=>row.confidenceScore!=null && row.confidenceScore<.6 && row.aiReviewStatus==='unreviewed');
  const base=mappingBase(sttmId);
  const link=(row:MappingState,section:'candidates'|'suggestions'='candidates')=>`[View row](${rowReviewUrl(base,row.id,section)})`;
  const lines=['### Auto-map results','',
    `- **Targets evaluated:** ${rows.length}.`, `- **New draft mappings applied:** ${applied.length}.`,
    `- **Existing definitions retained:** ${retained.length} (retention does not certify validation).`,
    `- **Rows with alternative candidates:** ${alternatives.length}.`, `- **Rows still unresolved:** ${unresolved.length}.`,
    `- **Rows requiring validation or business input:** ${needsInput.length}.`,
    `- **Low-confidence draft suggestions:** ${low.length}.`, '',
    'These categories can overlap.','', '### Notable mappings and alternatives',''];
  const notable=rows.filter(row=>applied.includes(row)||alternatives.includes(row)||unresolved.includes(row)).slice(0,4);
  for(const row of notable) {
    const option=currentCandidate(row,catalog);
    const source=row.mappingMode==='attribute' ? `$${row.attributeName}` : row.mappingMode==='constant' ? String(row.constantValue ?? '')
      : (row.sourceColumns ?? (row.sourceColumn?[row.sourceColumn]:[])).map(catalog.display).join(', ');
    lines.push(`- **${escape(row.targetColumn)}:** ${source ? code(source) : '**Unresolved**'}; ${escape(row.rule || 'Direct')}`
      + (row.confidenceScore==null ? '; confidence not available.' : `; **${Math.round(row.confidenceScore*100)}% confidence**.`)+` ${link(row,unresolved.includes(row)?'suggestions':'candidates')}`);
    const reason=option?.confidence_reason||row.confidenceReason;
    if(reason) lines.push(`  - Why: ${escape(catalog.display(reason).slice(0,300))}`);
    for(const alternative of alternativeCandidates(row,catalog).slice(0,2)) {
      const source=alternative.mapping_mode==='attribute' ? `$${alternative.attribute_name}` : alternative.mapping_mode==='constant' ? String(alternative.constant_value ?? '') : alternative.source_attributes.map(catalog.display).join(', ');
      lines.push(`  - Alternative: ${code(source)} — ${escape(alternative.preprocessing_rule_type || 'Direct')}`
        +(alternative.preprocessing_rule?`; ${code(catalog.display(alternative.preprocessing_rule))}`:'')+'.');
    }
  }
  if(!notable.length)lines.push('The current definitions were retained. Review their validation status in the sheet.');
  lines.push('','### Suggestions and next actions','');
  const groups=[['Relationships to review',['relationship']],['Firm Values or business rules required',['value','business_rule']],
    ['Source-data limitations',['source_data','outside_selection']],['Mappings requiring closer review',['evidence']]] as const;
  for(const [title,kinds] of groups) {
    const items=rows.flatMap(row=>guidanceForRow(row).filter(item=>(kinds as readonly string[]).includes(item.kind)).map(item=>({row,message:item.message})));
    if(title==='Mappings requiring closer review')for(const row of low)items.push({row,message:'Review the low-confidence suggestion against the target meaning.'});
    lines.push(`**${title}**`);
    if(!items.length)lines.push('- No additional action identified in these results.');
    else for(const {row,message} of items.slice(0,4))lines.push(`- ${code(row.targetColumn)}: ${escape(catalog.display(message).slice(0,300))} ${link(row,'suggestions')}`);
    if(items.length>4)lines.push(`- ${items.length-4} more recommendations are available in the mapping sheet.`);
    lines.push('');
  }
  lines.push('### Review reminder','','These changes are saved as draft suggestions. Review the highlighted rows before confirming or publishing.');
  return lines.join('\n');
}
