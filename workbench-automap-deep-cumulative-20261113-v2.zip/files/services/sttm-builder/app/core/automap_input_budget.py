"""Auto-map input limits; provider output and recovery limits are independent."""
from copy import deepcopy

from app.core.automap_retrieval import encoded
from app.core.snowflake_agent import SnowflakeAgentClient


INPUT_HARD_LIMIT = 180_000
OUTPUT_HARD_LIMIT = 120_000


def input_limits(settings):
    return (min(INPUT_HARD_LIMIT, settings.agent_outbound_message_max_chars),
            min(INPUT_HARD_LIMIT, settings.agent_outbound_message_max_bytes))


def wire_messages(messages):
    return SnowflakeAgentClient._normalize_messages(deepcopy(messages))


def wire_text(messages):
    return encoded(wire_messages(messages))


def fit_optional_history(packet, render, *, max_chars, max_bytes):
    """Fit complete serialized messages; defer optional recipes, never contracts."""
    from app.core.automap_policy import negative_evidence
    from app.core.automap_retrieval import digest
    packet = deepcopy(packet)
    deferred = []
    def messages():
        packet['context_budget'] = {'policy_version': 'final-message-v1', 'exhaustive': False,
            'deferred_evidence_count': len(deferred), 'deferred_evidence_ids': deferred[:32],
            'deferred_evidence_hash': digest(deferred), 'max_chars': max_chars, 'max_bytes': max_bytes}
        return render(packet)
    def fits(value):
        text = wire_text(value)
        return len(text) <= int(max_chars * .98) and len(text.encode('utf-8')) <= int(max_bytes * .98)
    result = messages()
    if fits(result):
        return result, packet['context_budget']
    evidence = (packet.get('context') or {}).get('mapping_evidence') or {}
    selected_ids = {identifier for attribute in (packet.get('data') or {}).get('attributes', [])
                    for identifier in (attribute.get('selected_mapping') or {}).get('used_learning_ids', [])}
    optional = []
    for target, categories in evidence.items():
        for category, records in categories.items():
            if not isinstance(records, list):
                continue
            for index, record in enumerate(records):
                if not isinstance(record, dict) or record.get('mandatory') or negative_evidence(record):
                    continue
                pattern = record.get('pattern') or record
                if pattern.get('pattern_id') in selected_ids or pattern.get('mandatory') or (pattern.get('provenance') or {}).get('evidence_class') == 'explicit_user_correction':
                    continue
                optional.append((str(record.get('tier') or 'T4'), index, records, record,
                                 str(pattern.get('pattern_id') or record.get('record_id') or digest(record))))
    for _, _, records, record, identifier in sorted(optional, key=lambda item:(item[0],item[1]), reverse=True):
        records.remove(record)
        deferred.append(identifier)
        result = messages()
        if fits(result):
            return result, packet['context_budget']
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    raise AgentPayloadBudgetError('Essential transformation contracts exceed the final serialized message budget')
