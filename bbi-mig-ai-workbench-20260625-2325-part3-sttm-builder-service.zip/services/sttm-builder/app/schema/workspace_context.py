from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, model_validator

from app.schema.common import TableRef


WORKBENCH_CONTEXT_VERSION = "1.0"


class WorkspaceDerivedSourceRef(BaseModel):
    id: str
    name: str | None = None
    sql_hash: str | None = None
    selected_columns_by_table: dict[str, list[str]] = Field(default_factory=dict)
    lineage: list[dict[str, Any]] = Field(default_factory=list)


class WorkspaceMappingRow(BaseModel):
    id: str
    target_column: str
    target_type: str | None = None
    source_columns: list[str] = Field(default_factory=list)
    source_type: str | None = None
    rule: str | None = None
    expression: str | None = None
    natural_language_rule: str | None = None
    description: str | None = None
    load_order: str | None = None
    confidence: float | None = None
    confidence_reason: str | None = None
    status: str | None = None


class WorkspaceFilterState(BaseModel):
    filter_sql: str | None = None
    base_query_sql: str | None = None
    group_by_sql: str | None = None
    order_by_sql: str | None = None
    groups: list[dict[str, Any]] = Field(default_factory=list)


class WorkspaceSemanticRef(BaseModel):
    bundle_id: str | None = None
    bundle_hash: str | None = None
    bundle_label: str | None = None
    level: str | None = None
    status: str | None = None
    view_name: str | None = None
    composed_model_hash: str | None = None
    asset_versions: dict[str, str] = Field(default_factory=dict)


class WorkspaceSemanticBundleRef(BaseModel):
    bundle_id: str | None = None
    bundle_hash: str | None = None
    bundle_label: str | None = None
    level: str | None = None
    status: str | None = None
    semantic_view_name: str | None = None
    composed_model_hash: str | None = None
    asset_versions: dict[str, str] = Field(default_factory=dict)
    source_tables: list[TableRef] = Field(default_factory=list)
    target_table: TableRef | None = None
    driving_table: TableRef | None = None
    derived_source_ids: list[str] = Field(default_factory=list)
    relationship_hash: str | None = None


class WorkbenchContextSnapshotV1(BaseModel):
    """Canonical UI state attached to all assistant and worker requests."""

    context_version: str = WORKBENCH_CONTEXT_VERSION
    context_hash: str
    captured_at: datetime
    page: str
    surface: str
    source_tables: list[TableRef] = Field(default_factory=list)
    driving_table: TableRef | None = None
    target_table: TableRef | None = None
    selected_columns_by_table: dict[str, list[str]] = Field(default_factory=dict)
    derived_sources: list[WorkspaceDerivedSourceRef] = Field(default_factory=list)
    relationships: list[dict[str, Any]] = Field(default_factory=list)
    filters: WorkspaceFilterState = Field(default_factory=WorkspaceFilterState)
    mapping_intent: dict[str, Any] | None = None
    mapping_rows: list[WorkspaceMappingRow] = Field(default_factory=list)
    checked_mapping_row_ids: list[str] = Field(default_factory=list)
    active_mapping_row_id: str | None = None
    mapping_sql: str | None = None
    mapping_preview_sql: str | None = None
    semantic: WorkspaceSemanticRef = Field(default_factory=WorkspaceSemanticRef)
    semantic_bundle: WorkspaceSemanticBundleRef | None = None
    mapping_artifacts: list[dict[str, Any]] = Field(default_factory=list)
    validation_history: list[dict[str, Any]] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_version(self) -> "WorkbenchContextSnapshotV1":
        if self.context_version != WORKBENCH_CONTEXT_VERSION:
            raise ValueError(
                "WORKSPACE_CONTEXT_VERSION_UNSUPPORTED: expected context_version '1.0'"
            )
        return self

    def selected_derived_source_ids(self) -> list[str]:
        return [item.id for item in self.derived_sources]
