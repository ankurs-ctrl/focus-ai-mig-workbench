from app.agent_tools.specialists import CortexSpecialistAdapter, SpecialistRequest, SpecialistResponse, SpecialistDecision


def test_batched_specialist_outputs_keep_original_provider_trace_receipts():
    columns = [f'C{index}' for index in range(17)]
    request = SpecialistRequest(run_id='run', step_id='map', project_id='p', sttm_id='s', snapshot_id='snapshot',
        target_contract={'target_table': 'DB.T.TARGET', 'columns': [{'name': name} for name in columns]},
        target_columns=columns, allowed_source_tables=['DB.S.SOURCE'],
        allowed_source_columns={'DB.S.SOURCE': columns}, actor_user_id='user', effective_role='ROLE', tenant_id='tenant')
    adapter = object.__new__(CortexSpecialistAdapter)
    calls = []
    def source(scoped):
        calls.append(list(scoped.target_columns))
        return SpecialistResponse(raw_trace_id=f'provider-{len(calls)}', decisions=[
            SpecialistDecision(target_column=name, decision='mapped', source_columns=[f'DB.S.SOURCE.{name}'],
                confidence=0.4, decision_reason='Actual specialist candidate', mapping_classification='direct')
            for name in scoped.target_columns])
    adapter.source_mapping = source
    source_result, transformation_result = adapter.map_targets(request, max_workers=1, before_call=lambda _: None)
    assert len(calls) == 2
    assert source_result.raw_trace_ids == ['provider-1', 'provider-2']
    assert [decision.target_column for decision in source_result.decisions] == columns
    assert all(decision.confidence == 0.4 and decision.decision == 'mapped' for decision in source_result.decisions)
    assert not transformation_result.decisions


def test_source_sql_proposals_still_reach_rule_specialist():
    request = SpecialistRequest(run_id='run', step_id='map', project_id='p', sttm_id='s', snapshot_id='snapshot',
        target_columns=['DIRECT', 'AMOUNT', 'VALUE_RULE'],
        target_contract={}, allowed_source_tables=['DB.S.T'],
        actor_user_id='user', effective_role='ROLE', tenant_id='tenant')
    adapter = object.__new__(CortexSpecialistAdapter)
    decisions = [
        SpecialistDecision(target_column='DIRECT', decision='mapped', source_columns=['DB.S.T.ID'],
                           confidence=.8, decision_reason='Verified direct column', mapping_classification='direct'),
        SpecialistDecision(target_column='AMOUNT', decision='mapped', source_columns=['DB.S.T.CENTS'],
                           expression='TRY_TO_NUMBER(DB.S.T.CENTS) / 100', confidence=.8,
                           decision_reason='Convert verified cents', mapping_classification='derived'),
        SpecialistDecision(target_column='VALUE_RULE', decision='mapped', source_columns=[],
                           expression="CASE WHEN $Flag = 'Y' THEN $Code ELSE NULL END", confidence=.8,
                           decision_reason='Approved Value expression',
                           mapping_classification='derived'),
    ]
    adapter.source_mapping = lambda scoped: SpecialistResponse(decisions=[d for d in decisions if d.target_column in scoped.target_columns])
    calls = []
    def transform(scoped, **kwargs):
        calls.append(scoped)
        return SpecialistResponse(decisions=[d for d in decisions if d.target_column in scoped.target_columns])
    adapter.transformation_rule = transform
    source, rules = adapter.map_targets(request, max_workers=1, before_call=lambda _: None)
    assert len(calls) == 1
    assert calls[0].target_columns == ['AMOUNT', 'VALUE_RULE']
    assert calls[0].current_mapping_rows[1]['expression'] == decisions[1].expression
    assert [d.target_column for d in rules.decisions] == ['AMOUNT', 'VALUE_RULE']
    assert len(source.decisions) == 3


def test_source_mapper_accepts_only_verified_cte_outputs_and_routes_transformations():
    import json
    request = SpecialistRequest(run_id='run', step_id='step', project_id='project', sttm_id='mapping',
        snapshot_id='snapshot', target_contract={}, target_columns=['FULL_NAME', 'MISSING'],
        allowed_source_tables=['DB.S.CUSTOMERS'], allowed_source_columns={'DB.S.CUSTOMERS': ['FIRST_NAME']},
        derived_outputs=[{'id': 'cte-1', 'name': 'active_customers', 'alias': 'active_customers_abc'}],
        compiler_relation_graph={'nodes': [{'relation_id': 'cte-1', 'kind': 'DERIVED_SOURCE',
            'alias': 'active_customers_abc', 'output_columns': [{'name': 'FIRST_NAME'}, {'name': 'LAST_NAME'}]}]},
        actor_user_id='user', effective_role='ROLE', tenant_id='tenant')
    mappings = {'FULL_NAME': {'source_attributes': ['active_customers.FIRST_NAME', 'active_customers.LAST_NAME'],
        'preprocessing_rule': 'Concatenate', 'mapping_mode': 'source', 'confidence_score': .99},
        'MISSING': {'source_attributes': ['active_customers.UNKNOWN'], 'preprocessing_rule': 'Direct',
                    'mapping_mode': 'source', 'confidence_score': .99}}
    result = CortexSpecialistAdapter._parse_source_mapping_response(None, json.dumps({'data': {'result': {'mappings': mappings}}}), request)
    assert result.decisions[0].decision == 'mapped'
    assert result.decisions[0].source_columns == ['ACTIVE_CUSTOMERS.FIRST_NAME', 'ACTIVE_CUSTOMERS.LAST_NAME']
    assert result.decisions[0].requires_transformation is True
    assert result.decisions[1].decision == 'unresolved'
    request.compiler_relation_graph = {}
    denied = CortexSpecialistAdapter._parse_source_mapping_response(None, json.dumps({'data': {'result': {'mappings': mappings}}}), request)
    assert all(decision.decision == 'unresolved' for decision in denied.decisions)


def test_value_only_custom_rule_is_not_collapsed_to_direct_value():
    import json
    request = SpecialistRequest(run_id='run', step_id='map', project_id='p', sttm_id='s', snapshot_id='snapshot',
        target_contract={}, allowed_source_tables=[], target_columns=['DIRECT_VALUE', 'CUSTOM_VALUE'],
        project_value_placeholders=[{'name': 'Code'}, {'name': 'Flag'}],
        actor_user_id='user', effective_role='ROLE', tenant_id='tenant')
    expression = "CASE WHEN $Flag = 'Y' THEN $Code ELSE NULL END"
    mappings = {
        'DIRECT_VALUE': {'source_attributes': [], 'mapping_mode': 'attribute', 'attribute_name': 'Code', 'confidence_score': .8},
        'CUSTOM_VALUE': {'source_attributes': [], 'mapping_mode': 'attribute', 'attribute_name': 'Code',
                         'preprocessing_rule': expression, 'confidence_score': .7,
                         'preprocessing_nl_rule': 'Use Code only when Flag is enabled'},
    }
    result = CortexSpecialistAdapter._parse_source_mapping_response(None, json.dumps({'data': {'result': {'mappings': mappings}}}), request)
    direct, custom = result.decisions
    assert direct.expression == '$Code' and not direct.requires_transformation
    assert custom.decision == 'mapped' and custom.source_columns == []
    assert custom.expression == expression and custom.requires_transformation
    assert custom.assumptions == ['Use Code only when Flag is enabled']


def test_constant_preserves_literal_and_skips_rule_specialist():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={'columns':[{'name':'LABEL','type':'VARCHAR'}]},allowed_source_tables=[],target_columns=['LABEL'],
        actor_user_id='u',effective_role='ROLE',tenant_id='t')
    result=CortexSpecialistAdapter._parse_source_mapping_response(None,json.dumps({'data':{'result':{'mappings':{
        'LABEL':{'source_attributes':[],'mapping_mode':'constant','constant_value':"O'Reilly",'confidence_score':.8}
    }}}}),request)
    row=result.decisions[0]
    assert row.decision=='mapped' and row.expression=="'O''Reilly'"
    assert row.mapping_classification=='constant' and not row.requires_transformation


def test_direct_label_does_not_hide_natural_language_rule_intent():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={},allowed_source_tables=['DB.S.T'],allowed_source_columns={'DB.S.T':['CENTS']},
        target_columns=['AMOUNT'],actor_user_id='u',effective_role='ROLE',tenant_id='t')
    result=CortexSpecialistAdapter._parse_source_mapping_response(None,json.dumps({'data':{'result':{'mappings':{
        'AMOUNT':{'source_attributes':['DB.S.T.CENTS'],'preprocessing_rule':'Direct',
                  'preprocessing_nl_rule':'Convert cents to dollars','rule_intent':{'operation':'divide','divisor':100},
                  'confidence_score':.8}
    }}}}),request)
    row=result.decisions[0]
    assert row.requires_transformation and row.expression is None
    assert row.assumptions[0]=='Convert cents to dollars'
    assert 'divide' in row.assumptions[1]


def test_draft_identity_is_run_scoped_and_same_target_mappings_stay_separate():
    from types import SimpleNamespace
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    handler = object.__new__(WorkbenchWorkflowHandlers)
    records = []
    commands = []
    handler._projects = SimpleNamespace(ensure_storage_exists=lambda: None, list_sttms=lambda _: records)
    handler._tool = lambda *_: None
    handler._emit = lambda *_args, **_kwargs: None
    def execute(command, _callback):
        commands.append(command)
        return SimpleNamespace(result={'sttm_id': str(len(commands))})
    handler._commands = SimpleNamespace(execute=execute)
    def run(run_id, key='primary', name='Requested name'):
        return handler.create_mappings({'run_id': run_id, 'project_id': '101',
            'actor_user_id': 'user', 'effective_role': 'ROLE',
            'authorized_target_scope': ['DB.T.TARGET'],
            'mapping_context_package': {'run_id': run_id, 'thread_id': run_id, 'app_user_id': 'user', 'effective_role': 'ROLE', 'workspace': {'source_tables': [{'database': 'DB', 'schema': 'S', 'table': 'SOURCE'}]}},
            'manifest': [{'mapping_key': key, 'mapping_name': name, 'target_table': 'DB.T.TARGET'}]})
    run('first')
    run('second')
    assert commands[0].payload['metadata']['agent_external_key'] != commands[1].payload['metadata']['agent_external_key']
    assert commands[0].payload['sttm_name'] == 'Requested name'
    records.append(SimpleNamespace(sttm_id='saved', target_table='DB.T.TARGET', sttm_name='Requested name',
        metadata={'draft_only': True, 'migration_run_id': 'second', 'mapping_key': 'primary'}))
    assert run('second')['manifest'][0]['sttm_id'] == 'saved'
    assert len(commands) == 2
    run('second', 'different', 'Another mapping')
    assert len(commands) == 3
    records[0].metadata['draft_only'] = False
    run('second')
    assert len(commands) == 4


def test_identical_visible_cte_is_reused_without_replacing_human_definition():
    from types import SimpleNamespace
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.derived_source import DerivedSourceDefinition, DerivedSourceRecord
    from app.schema.common import TableRef
    ref = TableRef(database='DB', schema='S', table='CUSTOMERS')
    definition = DerivedSourceDefinition(derived_source_id='new', derived_source_name='active_customers',
        sql_text='SELECT * FROM DB.S.CUSTOMERS WHERE ACTIVE = TRUE', source_tables=[ref], project_id='101')
    existing = DerivedSourceRecord(**definition.model_copy(update={'derived_source_id': 'human',
        'business_description': 'Human-authored description'}).model_dump())
    writes = []
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._derived_sources = SimpleNamespace(list_sources=lambda **_: [existing],
        save_source=lambda body, **kwargs: writes.append(body) or body)
    assert handler._save_planned_derived_source(definition).derived_source_id == 'human'
    assert not writes and existing.business_description == 'Human-authored description'
    existing.sql_text = 'SELECT * FROM DB.S.CUSTOMERS WHERE ACTIVE = FALSE'
    handler._save_planned_derived_source(definition)
    assert len(writes) == 1  # Conflict policy remains with the normal service.
    existing.sql_text = definition.sql_text
    existing.project_id = 'other-project'
    handler._save_planned_derived_source(definition)
    assert len(writes) == 2


def test_zero_confidence_does_not_hold_a_complete_verified_direct_candidate():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    rows = [{'target_column': 'STATUS_LABEL', 'source_columns': [], 'status': 'unresolved'}]
    WorkbenchWorkflowHandlers._promote_verified_plan_candidates(rows,
        [{'target_column': 'STATUS_LABEL', 'source_columns': ['DB.S.STATUSES.LABEL'], 'mapping_mode': 'direct', 'confidence': 0}],
        {'DB.S.STATUSES': {'columns': ['LABEL']}}, [{'name': 'STATUS_LABEL', 'type': 'VARCHAR'}])
    assert rows[0]['status'] == 'draft'
    assert rows[0]['source_columns'] == ['DB.S.STATUSES.LABEL']
    assert rows[0]['confidence'] == 0
    assert not rows[0]['missing_dependencies']


def test_compile_retry_reuses_completed_rules_without_replacing_unfinished_decisions():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.migration_workflow.scheduler import Partition, PartitionState
    handler = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object())
    key = 'customers'
    context = {'run_id': 'r', 'thread_id': 'r', 'app_user_id': 'u', 'effective_role': 'ROLE',
               'workspace': {'source_tables': [{'database': 'DB', 'schema': 'S', 'table': 'CUSTOMERS'}]}}
    state = {'project_id': '101', 'mapping_context_packages': {key: context}}
    source = Partition(partition_id='customers:map:0', mapping_key=key, state=PartitionState.COMPLETED,
        columns=['EMAIL', 'STATUS_LABEL'], result={'mapping_rows': [
            {'target_column': 'EMAIL', 'status': 'draft', 'mapping_classification': 'derived'},
            {'target_column': 'STATUS_LABEL', 'status': 'unresolved'}]})
    completed = {'target_column': 'EMAIL', 'status': 'draft', 'mapping_classification': 'derived',
                 'expression': 'LOWER(active_customers.EMAIL)', 'source_columns': ['active_customers.EMAIL']}
    compile_part = Partition(partition_id='customers:compile', mapping_key=key, stage='compile',
        result={'retry_mapping_rows': [completed]})
    observed = []
    handler.execute_mapping = lambda _state, mapping: observed.append(mapping['finalize_rows']) or {'status': 'READY_FOR_REVIEW'}
    handler.execute_partition(state, {'mapping_key': key, 'sttm_id': '401'}, compile_part, [source, compile_part])
    assert observed[0][0] == completed
    assert observed[0][1] == {'target_column': 'STATUS_LABEL', 'status': 'unresolved'}


def test_deployed_transformation_packet_uses_actual_agent_input_contract():
    request = SpecialistRequest(run_id='run', step_id='compile', project_id='p', sttm_id='s', snapshot_id='snap',
        target_contract={'target_table':'DB.T.OUT','columns':[{'name':'AMOUNT','type':'FLOAT'}]},
        target_columns=['AMOUNT'],allowed_source_tables=['DB.S.INCOME'],allowed_source_columns={'DB.S.INCOME':['CENTS']},
        current_mapping_rows=[{'target_column':'AMOUNT','source_columns':['PARSED.NUMERIC_CENTS'],
            'confidence_reason':'Convert numeric cents to dollars','candidates':[{'transformation':'PARSED.NUMERIC_CENTS / 100.0'}]}],
        derived_outputs=[{'name':'PARSED','sql':'SELECT TRY_CAST(CENTS AS NUMBER) AS NUMERIC_CENTS FROM DB.S.INCOME'}],
        actor_user_id='u',effective_role='ROLE',tenant_id='t')
    payload=CortexSpecialistAdapter._transformation_payload(request)
    assert payload['operation']=='sttm.transform' and payload['data']['intent']=='TRANSFORM'
    selected=payload['data']['attributes'][0]['selected_mapping']
    assert selected['source_attributes']==['PARSED.NUMERIC_CENTS']
    assert selected['candidates'][0]['transformation']=='PARSED.NUMERIC_CENTS / 100.0'
    assert selected['rule_candidate_id']
    assert payload['context']['cte_dependencies']==request.derived_outputs
    assert 'workspace_context' not in payload['context']
    assert 'rules' in payload['output_contract']['properties']


def test_workbench_rule_parser_keeps_declared_dependencies_and_explicit_zero():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={},target_columns=['AMOUNT'],allowed_source_tables=[],
        actor_user_id='u',effective_role='ROLE',tenant_id='t')
    response=CortexSpecialistAdapter._parse_transformation_response(None,json.dumps({'data':{'result':{'rules':[
        {'target_attribute':'AMOUNT','rule':'PARSED.NUMERIC_CENTS / 100.0',
         'confidence_score':0,'source_dependencies':['PARSED.NUMERIC_CENTS']}]}}}),request)
    assert response.decisions[0].source_columns==['PARSED.NUMERIC_CENTS']
    assert response.decisions[0].confidence==0


def test_transformation_semantics_keep_meanings_and_cte_sql_without_duplicate_native_serializations():
    import json
    from app.core.automap_input_budget import fit_optional_history,wire_text
    native_sql='CREATE SEMANTIC VIEW redundant_definition ' * 4000
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={'target_table':'DB.T.OUT','columns':[{'name':'AMOUNT','type':'FLOAT'}]},
        target_columns=['AMOUNT'],allowed_source_tables=['DB.S.INCOME'],
        stored_semantic_context={'mapping_projection':{'tables':[{'fqn':'DB.S.INCOME',
            'attributes':[{'name':'CENTS','business_meaning':'Amount in cents','data_type':'NUMBER'}],
            'semantic_view':{'name':'SEM_INCOME','yaml_hash':'asset-version','yaml':native_sql,'ddl':native_sql}}],
            'derived_sources':[{'name':'PARSED','sql_text':'SELECT CENTS AS NUMERIC_CENTS FROM DB.S.INCOME',
                                'output_columns':[{'name':'NUMERIC_CENTS'}],'query_scope':{'duplicate_ast':native_sql}}]}},
        actor_user_id='u',effective_role='ROLE',tenant_id='t')
    packet=CortexSpecialistAdapter._transformation_payload(request)
    projection=packet['context']['source_semantics']['mapping_projection']
    assert projection['tables'][0]['attributes'][0]['business_meaning']=='Amount in cents'
    assert projection['tables'][0]['semantic_view']=={'name':'SEM_INCOME','yaml_hash':'asset-version'}
    assert projection['derived_sources'][0]['sql_text']=='SELECT CENTS AS NUMERIC_CENTS FROM DB.S.INCOME'
    assert request.stored_semantic_context['mapping_projection']['tables'][0]['semantic_view']['yaml']==native_sql
    messages,coverage=fit_optional_history(packet,lambda p:[{'role':'user','content':json.dumps(p)}],max_chars=180000,max_bytes=180000)
    assert len(wire_text(messages).encode())<=180000 and coverage['deferred_evidence_count']==0


def test_rule_batches_submit_in_parallel_with_exact_target_scopes():
    import json,threading
    barrier=threading.Barrier(3);calls=[];lock=threading.Lock()
    class Client:
        def run_detailed(self,messages,**kwargs):
            packet=json.loads(messages[0]['content'][0]['text'])
            names=[a['target_attribute'] for a in packet['data']['attributes']]
            with lock:calls.append(names)
            barrier.wait(timeout=5)
            return json.dumps({'rules':[{'target_attribute':name,'rule':'INCOME.CENTS / 100.0','confidence_score':.8} for name in names]}),'trace-'+names[0],{}
    columns=[f'C{i}' for i in range(17)]
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={'target_table':'DB.T.OUT','columns':[{'name':name,'type':'FLOAT'} for name in columns]},
        target_columns=columns,allowed_source_tables=['DB.S.INCOME'],actor_user_id='u',effective_role='ROLE',tenant_id='t')
    adapter=CortexSpecialistAdapter(Client(),source_mapping_agent='source',transformation_rule_agent='rule')
    result=adapter.transformation_rule(request)
    assert sorted(map(len,calls))==[1,8,8]
    assert [decision.target_column for decision in result.decisions]==columns
    assert len(result.raw_trace_ids)==3


def test_rule_parser_accepts_provider_text_blocks_and_prose_wrapped_json():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={},target_columns=['A','B'],allowed_source_tables=[],actor_user_id='u',effective_role='R',tenant_id='t')
    rules={'data':{'result':{'rules':[{'target_attribute':'A','rule':'COALESCE(S.A, 0)','confidence_score':'unknown'},
                                   {'target_attribute':'B','rule':'S.B','confidence_score':0.8}]}}}
    for raw,text in [({'content':[{'type':'text','text':json.dumps(rules)}]},''), (None,'Here are the requested rules:\n'+json.dumps(rules)+'\nDone.')]:
        result=CortexSpecialistAdapter._parse_transformation_response(raw,text,request)
        assert len(result.decisions)==2
        assert result.decisions[0].expression=='COALESCE(S.A, 0)'
        assert result.decisions[1].confidence==0.8


def test_rule_repair_is_focused_once_and_preserves_successful_siblings():
    from app.agent_tools.specialists import SpecialistResponse,SpecialistDecision
    from unittest.mock import Mock
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={},target_columns=['A','B'],allowed_source_tables=[],actor_user_id='u',effective_role='R',tenant_id='t')
    adapter=CortexSpecialistAdapter(Mock(),source_mapping_agent='src',transformation_rule_agent='rule')
    good=lambda name:SpecialistDecision(target_column=name,decision='mapped',expression='S.'+name,confidence=.8,decision_reason='evidence')
    adapter._invoke=Mock(side_effect=[SpecialistResponse(decisions=[good('A')]),SpecialistResponse(decisions=[good('B')])])
    submitted=[];result=adapter.transformation_rule(request,before_call=submitted.append)
    assert {d.target_column for d in result.decisions}=={'A','B'}
    assert adapter._invoke.call_args_list[1].args[2].target_columns==['B']
    assert submitted==['cortex_agent.transformation_rule','cortex_agent.transformation_rule.repair']


def test_rule_transport_uncertainty_is_never_repaired_or_replayed():
    from unittest.mock import Mock
    import pytest
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='snap',
        target_contract={},target_columns=['A'],allowed_source_tables=[],actor_user_id='u',effective_role='R',tenant_id='t')
    adapter=CortexSpecialistAdapter(Mock(),source_mapping_agent='src',transformation_rule_agent='rule')
    adapter._invoke=Mock(side_effect=TimeoutError('unknown provider outcome'))
    with pytest.raises(TimeoutError):adapter.transformation_rule(request)
    assert adapter._invoke.call_count==1


def test_model_constant_classification_keeps_intentional_null_and_good_siblings():
    import json
    from app.routers.auto_mapping import _parse_mapping_response
    mappings={'NULL_FIELD':{'source_attributes':[],'mapping_mode':'constant','constant_value':'NULL','transformation_classification':'constant','confidence_score':.9},
              'GOOD':{'source_attributes':['S.ID'],'confidence_score':.8},
              'BAD':{'source_attributes':['S.ID'],'transformation_classification':'not_a_known_classification'}}
    parsed,_,warnings,error=_parse_mapping_response(json.dumps({'data':{'result':{'mappings':mappings}}}))
    assert error is None and set(parsed)=={'NULL_FIELD','GOOD'}
    assert parsed['NULL_FIELD'].constant_value=='NULL' and parsed['NULL_FIELD'].transformation_classification=='value'
    assert warnings[0].code=='AGENT_TARGET_FORMAT_INVALID' and warnings[0].field=='BAD'


def test_optional_model_suggestion_shape_cannot_discard_supported_null_definition():
    import json
    from app.routers.auto_mapping import _parse_mapping_response
    body={'source_attributes':[],'mapping_mode':'constant','constant_value':'NULL',
          'transformation_classification':'value','confidence_score':.9,
          'suggestions':[{'type':'business_review_required','description':'Supported historical NULL assignment.'},
                         {'options':[]} ]}
    mappings,_,warnings,error=_parse_mapping_response(json.dumps({'data':{'result':{'mappings':{'DOCUMENT':body}}}}))
    assert error is None and mappings['DOCUMENT'].constant_value=='NULL'
    assert mappings['DOCUMENT'].suggestions[0].message=='Supported historical NULL assignment.'
    assert [warning.code for warning in warnings]==['AGENT_SUGGESTION_FORMAT_INVALID']


def test_historical_plan_evidence_does_not_become_a_mandatory_user_rule():
    from app.agent_tools.workbench import _plan_evidence_pattern
    historical={'target_column':'TYPE','evidence_source':'historical_precedent','approval_state':'candidate',
                'transformation':"CASE WHEN FLAG THEN 'old' ELSE 'legacy' END"}
    assert not _plan_evidence_pattern(historical,'map')['mandatory']
    assert _plan_evidence_pattern(historical,'map')['evidence_source']=='historical_precedent'
    assert _plan_evidence_pattern({**historical,'mandatory':True},'map')['mandatory']
    assert _plan_evidence_pattern({'target_column':'TYPE','transformation':"'current'"},'map')['mandatory']
    assert 'mandatory' not in historical


def test_current_physical_alias_and_citation_resolve_before_rule_handoff():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='s',
        target_contract={},target_columns=['DOC'],allowed_source_tables=['DB.S.NOTE'],
        allowed_source_columns={'DB.S.NOTE':['ACTIVITY','NOTE_TEXT']},
        compiler_relation_graph={'nodes':[{'relation_id':'DB.S.NOTE','kind':'PHYSICAL_TABLE','alias':'note_current'}]},
        actor_user_id='u',effective_role='r',tenant_id='t')
    body={'source_attributes':['src:note_current.ACTIVITY','note_current.NOTE_TEXT'],
          'confidence_score':.9,'transformation_classification':'complex',
          'rule_intent':{'required_columns':['note_current.ACTIVITY'],'description':'Return matching documentation notes.'}}
    response=CortexSpecialistAdapter._parse_source_mapping_response({},json.dumps({'data':{'result':{'mappings':{'DOC':body}}}}),request)
    row=response.decisions[0]
    assert row.decision=='mapped' and not row.missing_dependencies and row.requires_transformation
    assert row.source_columns==['DB.S.NOTE.ACTIVITY','DB.S.NOTE.NOTE_TEXT']
    bad={**body,'source_attributes':['src:foreign.ACTIVITY'],'rule_intent':None}
    denied=CortexSpecialistAdapter._parse_source_mapping_response({},json.dumps({'data':{'result':{'mappings':{'DOC':bad}}}}),request)
    assert denied.decisions[0].decision=='unresolved'


def test_quoted_column_case_and_source_free_custom_intent_remain_distinct():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='s',
        target_contract={},target_columns=['OUT'],allowed_source_tables=['DB.S.T'],
        allowed_source_columns={'DB.S.T':['MiXeD']},compiler_relation_graph={'nodes':[{'relation_id':'DB.S.T','kind':'PHYSICAL_TABLE','alias':'t_current'}]},
        actor_user_id='u',effective_role='r',tenant_id='t')
    def read(body):return CortexSpecialistAdapter._parse_source_mapping_response({},json.dumps({'data':{'result':{'mappings':{'OUT':body}}}}),request).decisions[0]
    assert read({'source_attributes':['t_current."MiXeD"'],'confidence_score':.8}).source_columns==['DB.S.T."MiXeD"']
    assert read({'source_attributes':['t_current.MiXeD'],'confidence_score':.8}).decision=='unresolved'
    custom=read({'source_attributes':[],'mapping_mode':'constant','confidence_score':.8,
        'transformation_classification':'complex','rule_intent':{'description':'CASE using supplied approved Values'}})
    assert custom.requires_transformation and custom.decision=='mapped' and not custom.missing_dependencies


def test_self_join_alias_keeps_the_exact_table_instance_and_fqn_stays_ambiguous():
    import json
    request=SpecialistRequest(run_id='r',step_id='s',project_id='p',sttm_id='m',snapshot_id='s',
        target_contract={},target_columns=['OUT'],allowed_source_tables=['DB.S.ACCOUNTS'],
        allowed_source_columns={'DB.S.ACCOUNTS':['ID']},compiler_relation_graph={'nodes':[
            {'relation_id':'instance:left','kind':'PHYSICAL_TABLE','alias':'left_account','table':{'database':'DB','schema':'S','table':'ACCOUNTS'}},
            {'relation_id':'instance:right','kind':'PHYSICAL_TABLE','alias':'right_account','table':{'database':'DB','schema':'S','table':'ACCOUNTS'}}]},
        actor_user_id='u',effective_role='r',tenant_id='t')
    def read(ref):return CortexSpecialistAdapter._parse_source_mapping_response({},json.dumps({'data':{'result':{'mappings':{'OUT':{'source_attributes':[ref],'confidence_score':.9}}}}}),request).decisions[0]
    assert read('left_account.ID').source_columns==['left_account.ID']
    assert read('DB.S.ACCOUNTS.ID').decision=='unresolved'
