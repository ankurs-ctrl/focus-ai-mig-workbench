import type {
  JoinConfig,
  MappingState,
  ParsedSqlWorkspaceApplyPayload,
} from "@/features/sttm/types/sttm.types";
import type { SqlUploadResult } from "@/features/sttm/mapping/sql-bundle-review-panel";
import { relationAliasFor } from "@/features/sttm/mapping/relation-alias";

export function buildSqlUploadWorkspace(
  uploaded: SqlUploadResult,
  options?: { approvedProjectValueNames?: string[] },
): ParsedSqlWorkspaceApplyPayload {
  const parsed = uploaded.parsed_summary;
  const sqlVariables = Object.fromEntries(
    Object.entries(parsed?.variables ?? {}).map(([name, value]) => [
      name.trim().replace(/^\$/, "").toUpperCase(),
      String(value),
    ]),
  );
  const approvedProjectValueKeys = options?.approvedProjectValueNames
    ? new Set(options.approvedProjectValueNames.map((name) => name.toUpperCase()))
    : null;
  const rows = uploaded.import_preview?.mapping_rows ?? parsed?.column_mappings ?? [];
  const ctes = parsed?.ctes ?? [];
  const importedQueryName = "Imported Mapping Result";
  const hasImportedQuery = Boolean(parsed?.preview_sql?.trim() && rows.length);
  const finalCteNames = new Set(ctes
    .filter((item) => Array.isArray(item.downstream_consumers)
      && item.downstream_consumers.includes("FINAL_PROJECTION"))
    .map((item) => String(item.name ?? "").toUpperCase()));
  const selectedCteNames = finalCteNames.size
    ? finalCteNames
    : new Set(ctes.slice(-1).map((item) => String(item.name ?? "").toUpperCase()));
  const prettyCteSql = new Map((uploaded.import_preview?.cte_summary ?? [])
    .map((item) => [String(item.name ?? "").toUpperCase(), String(item.sql_text ?? "")]));
  const variableBindings = new Map((parsed?.variable_bindings ?? [])
    .map((binding) => [binding.name.toUpperCase(), binding]));
  const mappings: MappingState[] = rows.map((item, index) => {
    const targetColumn = String(
      item.target_alias ?? item.target_field ?? item.target_column ?? `COLUMN_${index + 1}`,
    );
    const physical = Array.isArray(item.physical_source_columns)
      ? item.physical_source_columns.map(String)
      : [];
    const logical = Array.isArray(item.source_columns)
      ? item.source_columns.map(String)
      : item.source_field
        ? String(item.source_field).split(",").map((value) => value.trim()).filter(Boolean)
        : [];
    const cteOutput = Array.isArray(item.lineage_path)
      ? item.lineage_path.find((node) =>
          node && typeof node === "object"
          && String(node.kind ?? "") === "cte_output"
          && selectedCteNames.has(String(node.relation ?? "").toUpperCase()))
      : null;
    const cteName = cteOutput ? String(cteOutput.relation ?? "") : "";
    const cteColumn = cteOutput ? String(cteOutput.column ?? "") : "";
    const isConstant = String(item.mapping_mode ?? "").toLowerCase() === "constant";
    const sourceColumns = hasImportedQuery && !isConstant
      ? [`${relationAliasFor(`sql-cte:${importedQueryName}`, importedQueryName)}.${targetColumn}`]
      : cteName && cteColumn
      ? [`${relationAliasFor(`sql-cte:${cteName}`, cteName)}.${cteColumn}`]
      : physical.length ? physical : logical;
    const rawConstantValue = isConstant ? String(item.constant_value ?? "") : "";
    const variableName = rawConstantValue.match(/^\$([A-Za-z_][A-Za-z0-9_]*)$/)?.[1];
    const resolvedVariableValue = variableName
      ? sqlVariables[variableName.toUpperCase()]
      : undefined;
    const hasResolvedSqlVariable = resolvedVariableValue !== undefined;
    const isProjectAttribute = hasResolvedSqlVariable
      && (!approvedProjectValueKeys || approvedProjectValueKeys.has(String(variableName).toUpperCase()));
    const transformation = item.transformation ?? item.expression ?? item.preprocessing_rule;
    const normalizedTransformation = transformation ? String(transformation)
      .replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (match, name: string) => {
        const binding = variableBindings.get(name.toUpperCase());
        if (!binding || binding.resolved_value == null) return match;
        const value = String(binding.resolved_value);
        return ["INT", "DECIMAL", "FLOAT", "NUMBER", "BOOLEAN"].includes(String(binding.inferred_type).toUpperCase())
          ? value
          : `'${value.replace(/'/g, "''")}'`;
      })
      .replace(/\b([A-Za-z_][A-Za-z0-9_]*)\s*\./g, (match, qualifier: string) =>
        !hasImportedQuery && cteName && qualifier.toUpperCase() === cteName.toUpperCase()
          ? `${relationAliasFor(`sql-cte:${cteName}`, cteName)}.`
          : match)
      : null;

    return {
      id: `upload:${targetColumn}:${index}`,
      targetColumn,
      targetType: String(item.target_data_type ?? item.target_type ?? "TEXT"),
      sourceColumn: isConstant ? null : sourceColumns[0] ?? null,
      sourceColumns,
      sourceType: null,
      mappingMode: isProjectAttribute ? "attribute" : isConstant ? "constant" : "source",
      constantValue:
        isProjectAttribute
          ? resolvedVariableValue
          : isConstant
            ? resolvedVariableValue ?? rawConstantValue
            : null,
      attributeName: isProjectAttribute ? variableName ?? null : null,
      expression: isConstant ? null : hasImportedQuery ? sourceColumns[0] : normalizedTransformation,
      rule: isConstant ? "Value" : transformation ? "Custom" : "Direct",
      status: sourceColumns.length || isConstant ? "MAPPED" : "UNMAPPED",
      nlRule: normalizedTransformation,
    };
  });

  const relationships: JoinConfig[] = (parsed?.join_patterns ?? []).map((item, index) => {
    const keys = Array.isArray(item.keys) ? item.keys.map(String) : [];
    const conditionColumns = keys.length >= 2
      ? keys.slice(0, 2)
      : String(item.condition ?? "")
        .split("=")
        .map((value) => value.trim())
        .filter(Boolean)
        .slice(0, 2);
    const joinType = String(item.join_type ?? "INNER")
      .replace(/\s+JOIN$/i, "")
      .toUpperCase();

    return {
      id: `upload-join:${index}`,
      joinType: (["INNER", "LEFT", "RIGHT", "FULL"].includes(joinType)
        ? joinType
        : "INNER") as JoinConfig["joinType"],
      leftTableId: String(item.left_table ?? ""),
      rightTableId: String(item.right_table ?? ""),
      source: "USER_DEFINED",
      conditions: conditionColumns.length >= 2
        ? [{
            leftColumn: conditionColumns[0].split(".").pop(),
            operator: "=",
            rightColumn: conditionColumns[1].split(".").pop(),
          }]
        : [],
    };
  });

  const resolvedReferences = uploaded.import_preview?.table_references ?? [];
  const resolvedSources = resolvedReferences
    .filter((item) =>
      String(item.reference_role ?? "") === "source"
      && String(item.resolution_status ?? "") === "resolved"
      && Boolean(item.resolved_fqn),
    )
    .map((item) => String(item.resolved_fqn));
  const resolvedTarget = resolvedReferences.find((item) =>
    String(item.reference_role ?? "") === "target"
    && String(item.resolution_status ?? "") === "resolved"
    && Boolean(item.resolved_fqn),
  );
  const sourceTableFqns = resolvedSources.length
    ? resolvedSources
    : parsed?.source_tables ?? parsed?.source_datasets ?? [];
  const resolveInputTable = (value: string) => {
    const normalized = value.trim().replace(/^"|"$/g, "").toUpperCase();
    if (normalized.split(".").length === 3) return value;
    return sourceTableFqns.find((candidate) => {
      const candidateUpper = candidate.toUpperCase();
      return candidateUpper === normalized || candidateUpper.endsWith(`.${normalized}`);
    }) ?? value;
  };

  return {
    sourceTableFqns,
    targetTableFqn: resolvedTarget
      ? String(resolvedTarget.resolved_fqn)
      : parsed?.target_table ?? parsed?.target_tables?.[0] ?? null,
    relationships,
    mappings,
    derivedSources: [
      ...ctes
      .map((item) => ({
        name: String(item.name ?? "derived_source"),
        isSelected: !hasImportedQuery && selectedCteNames.has(String(item.name ?? "").toUpperCase()),
        sqlText: prettyCteSql.get(String(item.name ?? "").toUpperCase()) || (item.sql_text ? String(item.sql_text) : null),
        inputTables: Array.isArray(item.tables_referenced)
          ? Array.from(
              new Set(item.tables_referenced.map(String).map(resolveInputTable)),
            )
          : [],
        outputColumns: Array.isArray(item.output_columns)
          ? item.output_columns
            .filter((column) =>
              column
              && typeof column === "object"
              && String((column as Record<string, unknown>).name ?? "") !== "*",
            )
            .map((column) => column as Record<string, unknown>)
          : [],
        purpose: item.purpose ? String(item.purpose) : null,
        candidateReasons: Array.isArray(item.derived_source_reasons)
          ? item.derived_source_reasons.map(String)
          : [],
      })),
      ...(hasImportedQuery ? [{
        name: importedQueryName,
        isSelected: true,
        sqlText: parsed!.preview_sql ?? null,
        inputTables: sourceTableFqns,
        outputColumns: mappings.map((mapping) => ({ name: mapping.targetColumn, data_type: mapping.targetType })),
        purpose: "Complete result of the uploaded SQL, including its CTEs, joins, filters, and final projection.",
        candidateReasons: [],
      }] : []),
    ],
    filterSql: "",
    sql: parsed?.preview_sql ?? uploaded.import_preview?.sql ?? "",
  };
}
