import type { MappingState } from '@/features/sttm/types/sttm.types';

export type ConfidenceGroupId = 'high' | 'medium' | 'low';

export type ConfidenceGroupConfig = {
  id: ConfidenceGroupId;
  title: string;
  rangeLabel: string;
  backgroundColor: string;
  dotColor: string;
  titleColor: string;
  badgeBackground: string;
  badgeColor: string;
};

export const CONFIDENCE_GROUP_ORDER: ConfidenceGroupId[] = ['high', 'medium', 'low'];

export const CONFIDENCE_GROUP_CONFIG: Record<ConfidenceGroupId, ConfidenceGroupConfig> = {
  high: {
    id: 'high',
    title: 'HIGH CONFIDENCE',
    rangeLabel: 'Confidence: 80-100% · Manual',
    backgroundColor: '#ecfdf5',
    dotColor: '#16a34a',
    titleColor: '#15803d',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
  medium: {
    id: 'medium',
    title: 'MEDIUM CONFIDENCE',
    rangeLabel: 'Confidence: 60-80%',
    backgroundColor: '#fefce8',
    dotColor: '#d97706',
    titleColor: '#b45309',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
  low: {
    id: 'low',
    title: 'LOW CONFIDENCE / UNMAPPED',
    rangeLabel: 'Confidence: 0-60%',
    backgroundColor: '#fef2f2',
    dotColor: '#dc2626',
    titleColor: '#b91c1c',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
};

/** Normalize API scores that may arrive as 0-1 fractions or 0-100 percentages. */
export function normalizeConfidencePercent(
  confidenceScore: number | null | undefined,
): number | null {
  if (confidenceScore == null || Number.isNaN(Number(confidenceScore))) {
    return null;
  }
  const raw = Number(confidenceScore);
  const percent = raw <= 1 ? raw * 100 : raw;
  return Math.max(0, Math.min(100, percent));
}

export function hasConfidenceScore(
  confidenceScore: number | null | undefined,
): boolean {
  return normalizeConfidencePercent(confidenceScore) != null;
}

type ConfidenceGroupInput = {
  confidenceScore?: number | null;
  status?: MappingState['status'] | null;
  manuallySaved?: boolean;
};

/**
 * Resolve confidence band for sorting/grouping.
 * Manually saved mapped rows always belong in high confidence.
 */
export function getConfidenceGroup(
  mappingOrScore:
    | ConfidenceGroupInput
    | number
    | null
    | undefined,
  status?: MappingState['status'],
): ConfidenceGroupId {
  if (
    mappingOrScore != null
    && typeof mappingOrScore === 'object'
  ) {
    if (mappingOrScore.manuallySaved && mappingOrScore.status === 'MAPPED') {
      return 'high';
    }
    const percent = normalizeConfidencePercent(mappingOrScore.confidenceScore);
    if (percent == null) {
      return 'low';
    }
    if (percent >= 80) return 'high';
    if (percent >= 60) return 'medium';
    return 'low';
  }

  void status;
  const percent = normalizeConfidencePercent(mappingOrScore);
  if (percent == null) {
    return 'low';
  }
  if (percent >= 80) return 'high';
  if (percent >= 60) return 'medium';
  return 'low';
}

function mappingSortScore(mapping: MappingState): number {
  if (mapping.manuallySaved && mapping.status === 'MAPPED') {
    return 100;
  }
  return normalizeConfidencePercent(mapping.confidenceScore) ?? -1;
}

export function sortMappingsByConfidenceGroups(mappings: MappingState[]): MappingState[] {
  return [...mappings].sort((left, right) => {
    const leftGroup = getConfidenceGroup(left);
    const rightGroup = getConfidenceGroup(right);
    const groupOrder =
      CONFIDENCE_GROUP_ORDER.indexOf(leftGroup) - CONFIDENCE_GROUP_ORDER.indexOf(rightGroup);
    if (groupOrder !== 0) return groupOrder;

    const leftScore = mappingSortScore(left);
    const rightScore = mappingSortScore(right);
    if (rightScore !== leftScore) return rightScore - leftScore;

    return left.targetColumn.localeCompare(right.targetColumn);
  });
}

export function countMappingsByConfidenceGroup(
  mappings: MappingState[],
): Record<ConfidenceGroupId, number> {
  return mappings.reduce(
    (counts, mapping) => {
      const group = getConfidenceGroup(mapping);
      counts[group] += 1;
      return counts;
    },
    { high: 0, medium: 0, low: 0 } satisfies Record<ConfidenceGroupId, number>,
  );
}

/**
 * When the user edits an auto-mapped row, keep its confidence score (and sort
 * position) and mark it as manually edited after auto-map.
 * Score is only replaced when an explicit confidenceScore update is provided
 * (auto-map / FIR / recommendation), or when the mapping is fully cleared.
 */
export function withPreservedAutoMapConfidence(
  row: Pick<
    MappingState,
    | 'confidenceScore'
    | 'confidenceReason'
    | 'manuallyEditedAfterAutoMap'
    | 'manuallySaved'
    | 'mappingMode'
    | 'expression'
  >,
  updates: Partial<MappingState>,
): Partial<MappingState> {
  // Explicit confidence updates (auto-map / FIR / recommendation) replace prior score.
  if (Object.prototype.hasOwnProperty.call(updates, 'confidenceScore')) {
    return {
      ...updates,
      manuallyEditedAfterAutoMap: false,
      manuallySaved: false,
    };
  }

  if (!hasConfidenceScore(row.confidenceScore) && !row.manuallySaved) {
    return {
      ...updates,
      manuallyEditedAfterAutoMap: false,
    };
  }

  const priorMode = row.mappingMode ?? 'source';
  const nextMode = updates.mappingMode ?? priorMode;
  // Keep score/group while dirty — even if sources were cleared — until Save.
  // Mode switches (e.g. Direct → Attribute) also keep the auto-map score.
  void priorMode;
  void nextMode;

  return {
    ...updates,
    confidenceScore: row.confidenceScore ?? null,
    confidenceReason: row.confidenceReason ?? updates.confidenceReason ?? null,
    manuallyEditedAfterAutoMap: true,
    // Keep prior manuallySaved until explicit Save commit replaces it.
    manuallySaved: row.manuallySaved ?? false,
  };
}
