-- ============================================================
-- SP_FIR_STORE_INFERENCE
-- Thin CRUD tool for AGT_FIR_SYSTEM: stores the agent's inference analysis.
-- The agent provides ALL content (type, summary, understanding, reasoning).
-- This procedure just writes to the database.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_STORE_INFERENCE(
    "FIR_RECORD_ID" VARCHAR,
    "INFERENCE_TYPE" VARCHAR,
    "SUMMARY" VARCHAR,
    "BUSINESS_UNDERSTANDING" VARCHAR,
    "CONFIDENCE" FLOAT,
    "AGENT_NOTES" VARCHAR,
    "AGENT_REASONING_PAYLOAD" VARCHAR DEFAULT NULL
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'store_inference'
EXECUTE AS OWNER
AS
$$
import json
import uuid
from datetime import datetime


def store_inference(
    session,
    fir_record_id: str,
    inference_type: str,
    summary: str,
    business_understanding: str,
    confidence: float,
    agent_notes: str,
    agent_reasoning_payload: str = None
) -> dict:
    """Store the agent's inference analysis into TBL_AGENT_FIR_360 and TBL_WORKBENCH_INFERENCES."""

    inference_id = str(uuid.uuid4())

    # Parse the business_understanding JSON string
    try:
        bu_parsed = json.loads(business_understanding) if business_understanding else {}
    except (json.JSONDecodeError, TypeError):
        bu_parsed = {'raw': business_understanding}

    # Parse agent_reasoning_payload if provided
    try:
        reasoning_parsed = json.loads(agent_reasoning_payload) if agent_reasoning_payload else None
    except (json.JSONDecodeError, TypeError):
        reasoning_parsed = {'raw': agent_reasoning_payload}

    inference_payload = {
        'inference_id': inference_id,
        'inference_type': inference_type,
        'summary': summary,
        'confidence': confidence,
        'business_understanding': bu_parsed,
        'generated_by': 'AGT_FIR_SYSTEM',
        'generated_at': datetime.utcnow().isoformat()
    }

    # Update TBL_AGENT_FIR_360 with inference data
    reasoning_json = json.dumps(reasoning_parsed) if reasoning_parsed else '{}'
    session.sql("""
        UPDATE __STTM_METADATA_NAMESPACE__.TBL_AGENT_FIR_360
        SET INFERENCE_ID = ?,
            INFERENCE_PAYLOAD = PARSE_JSON(?),
            PROCESSING_STAGE = 'inference_generated',
            CURRENT_CONFIDENCE = ?,
            AGENT_NOTES = ?,
            AGENT_REASONING_PAYLOAD = PARSE_JSON(?),
            PROCESSED_BY = 'AGT_FIR_SYSTEM',
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE FIR_RECORD_ID = ?
    """, [
        inference_id,
        json.dumps(inference_payload),
        confidence,
        agent_notes,
        reasoning_json,
        fir_record_id
    ]).collect()

    # Also store in TBL_WORKBENCH_INFERENCES for Cortex Search indexing
    session.sql("""
        INSERT INTO __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_INFERENCES (
            INFERENCE_ID, INFERENCE_KEY, REQUEST_ID, SOURCE,
            INFERENCE_TYPE, SUMMARY, CONFIDENCE,
            ENTITY_TYPE, ATTRIBUTES,
            AGENT_NOTES, STATUS, CREATED_AT, UPDATED_AT
        )
        SELECT ?, ?, ?, 'AGT_FIR_SYSTEM',
               ?, ?, ?,
               ?, PARSE_JSON(?),
               ?, 'active', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
        WHERE NOT EXISTS (
            SELECT 1 FROM __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_INFERENCES
            WHERE INFERENCE_ID = ?
        )
    """, [
        inference_id, f"fir_{fir_record_id}", fir_record_id,
        inference_type, summary, confidence,
        inference_type, json.dumps(bu_parsed),
        agent_notes,
        inference_id
    ]).collect()

    return {
        'status': 'success',
        'inference_id': inference_id,
        'fir_record_id': fir_record_id,
        'inference_type': inference_type,
        'confidence': confidence
    }
$$;
