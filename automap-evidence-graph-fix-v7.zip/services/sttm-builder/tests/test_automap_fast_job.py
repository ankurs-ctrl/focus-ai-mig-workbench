"""Offline integration of resolver, proxy, batching and durable runner.

Budget-rejection fixtures deliberately use an oversized identity field: ordinary
large descriptions are now blockable evidence and must no longer be rejected.
"""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json
import shutil
import subprocess
import threading
import time
import uuid

import httpx
import pytest
from fastapi import HTTPException, Request

from app.core import auto_mapping_proxy as module
from app.core import automap_deterministic as deterministic
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.config import Settings
from app.core.exceptions import SnowflakeAgentError
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMStatus, ValueBinding
from tests.unit.core.test_auto_mapping_proxy import _request, _response
from tests.unit.core.test_automap_deterministic import real_ft_pitt_upload, real_ft_pitt_request
from tests.test_automap_fast_transport import harness


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    import socket
    monkeypatch.setattr(socket.socket, "connect", lambda *args: pytest.fail("Unexpected network access"))
    monkeypatch.setattr(socket, "getaddrinfo", lambda *args, **kwargs: pytest.fail("Unexpected DNS access"))


def authored(*, pending=0, expressions=("src.COL_0", "CURRENT_TIMESTAMP()")):
    req = _request(len(expressions) + pending)
    raw = req.model_dump(mode="json")
    raw["context"]["project_id"] = "501"
    raw["request_id"] = str(uuid.uuid4())
    raw["meta"] = {"auto_map_resolution_mode": "preserve_and_complete"}
    raw["context"]["relation_graph"] = {"nodes": [{"relation_id": "source", "kind": "PHYSICAL_TABLE",
        "alias": "src", "table": raw["context"]["source_tables"][0],
        "output_columns": [{"name": f"COL_{index}"} for index in range(len(expressions) + pending)]}]}
    raw["context"]["workspace_context"] = {"target_table": raw["context"]["target_table"], "driving_relation_id": "source",
        "mapping_rows": [{"id": f"original-row-{index}", "target_column": f"COL_{index}",
            "expression": expression, "rule": "Custom", "status": "MAPPED",
            "manual_note": "Keep exactly", "source_columns": [expression] if expression.startswith("src.") else []}
            for index, expression in enumerate(expressions)]}
    return STTMBuilderEnvelopeRequest.model_validate(raw)


def proxy(**settings):
    return AutoMappingProxyClient(Settings(_env_file=None, AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=2, **settings).model_copy(update={
            "automap_fast_path_v1": True, "automap_fast_project_ids": ["501", "allowed", "test-project"]}))


def expire_plan(req, deadline):
    req.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"] = deadline
    req.meta["_automap_acceptance"].update(deadline_at=deadline, accepted_at=deadline - module._RESOLUTION_DEADLINE_SECONDS)


def deny(*args, **kwargs):
    pytest.fail("Fully preserved job attempted worker or model preflight")


def test_owned_modules_import_from_target_worktree():
    assert Path(module.__file__).resolve().parents[2] == Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("retrieval", [False, True])
def test_all_preserved_real_invoke_skips_preflight_and_worker(monkeypatch, retrieval):
    client = proxy(AUTOMAP_CONTEXT_RETRIEVAL_V1=retrieval)
    req = authored()
    before = req.model_dump(mode="json")
    monkeypatch.setattr(client, "_invoke_batch", deny)
    monkeypatch.setattr(client, "_build_batches", deny)
    response = client._invoke_with_headers(req, headers={})
    assert list(response.result.mappings) == ["COL_0", "COL_1"]
    assert response.data.result == response.result
    assert response.agent is None and response.thread_id is None
    assert response.data.status == STTMStatus.COMPLETED
    review = response.meta["auto_mapping_review"]
    assert (review["mapped_count"], review["newly_mapped_count"], review["preserved_count"]) == (0, 0, 2)
    assert review["completed_without_review_count"] == 0
    assert review["unresolved_count"] == 0
    assert response.meta["auto_mapping_dispatch"]["batch_count"] == 0
    assert response.meta["automap_preserved_targets"] == ["COL_0", "COL_1"]
    assert response.meta["automap_baseline_preservation"]["apply_preserved_mappings"] is False
    assert response.meta["automap_resolution"]["execution_status"] == "not_validated"
    assert module._RESOLUTION_PLAN_KEY not in response.meta
    assert req.model_dump(mode="json") == before
    assert response.context.workspace_context == req.context.workspace_context
    assert all(not mapping.source_attributes and mapping.preprocessing_rule is None
               and mapping.constant_value is None for mapping in response.result.mappings.values())


@pytest.mark.parametrize("expression", ["NULL", "'NULL'", "''", "CURRENT_TIMESTAMP()", "COALESCE('a','b')"])
def test_scalar_definition_is_reference_only_not_fake_source_or_null(monkeypatch, expression):
    req = authored(expressions=(expression,))
    client = proxy()
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(req, headers={})
    assert response.meta["auto_mapping_review"]["preserved_count"] == 1
    assert response.result.mappings["COL_0"].constant_value is None
    assert response.result.mappings["COL_0"].source_attributes == []
    assert response.context.workspace_context.mapping_rows[0].expression == expression


@pytest.mark.parametrize("retrieval", [False, True])
def test_one_pending_only_preflighted_and_dispatched_same_caller(monkeypatch, retrieval):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy(AUTOMAP_CONTEXT_RETRIEVAL_V1=retrieval)
    req = authored(pending=1)
    before = req.model_dump(mode="json")
    original = STTMBuilderService.project_agent_payload
    preflight = []
    calls = []
    resolutions = []
    resolve = deterministic.resolve_authored_targets
    monkeypatch.setattr(deterministic, "resolve_authored_targets", lambda request, **kwargs:
        (resolutions.append(request), resolve(request, **kwargs))[1])
    def project(request, settings):
        names = [item.target_attribute for item in request.data.attributes]
        preflight.append(names)
        assert names == ["COL_2"]
        return original(request, settings)
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", project)
    headers = {"X-Workbench-OAuth-User": "ALICE", "X-Workbench-OAuth-Role": "READER"}
    def invoke(batch, **kwargs):
        calls.append(batch)
        assert kwargs["headers"] is headers
        assert module._RESOLUTION_PLAN_KEY not in batch.meta
        assert [item.target_attribute for item in batch.data.attributes] == ["COL_2"]
        return _response(batch)
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    partials = []
    response = client._invoke_with_headers(req, headers=headers,
        progress_callback=lambda index, attributes, result: partials.append(result))
    assert len(resolutions) == len(calls) == len(partials) == 1
    assert preflight
    assert list(partials[0].result.mappings) == ["COL_2"]
    assert partials[0].meta["batch_identity"]["resolution_version"] == module._RESOLUTION_VERSION
    assert list(response.result.mappings) == ["COL_0", "COL_1", "COL_2"]
    review = response.meta["auto_mapping_review"]
    assert (review["preserved_count"], review["mapped_count"], review["proposed_count"], review["unresolved_count"]) == (2, 1, 1, 0)
    assert req.model_dump(mode="json") == before


@pytest.mark.parametrize("blocked", [("COL_2",), ("COL_2", "COL_3")])
def test_fast_preflight_oversize_is_local_partial_not_job_failure(monkeypatch, blocked):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy()
    req = authored(pending=2)
    for attribute in req.data.attributes:
        if attribute.target_attribute in blocked:
            attribute.target_data_type = "Irreducible synthetic identity. " + "e" * 250_000
    before = req.model_dump(mode="json")
    projections, calls, partials = [], [], []
    original = STTMBuilderService.project_agent_payload
    def project(request, settings):
        projections.append(tuple(item.target_attribute for item in request.data.attributes))
        return original(request, settings)
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", project)
    headers = {"X-Workbench-OAuth-User": "ALICE", "X-Workbench-OAuth-Role": "READER"}
    def invoke(batch, **kwargs):
        assert kwargs["headers"] is headers
        calls.extend(item.target_attribute for item in batch.data.attributes)
        assert not set(calls) & set(blocked)
        return _response(batch)
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    result = client._invoke_with_headers(req, headers=headers,
        progress_callback=lambda *args: partials.append(args[-1]))
    assert req.model_dump(mode="json") == before
    assert result.context.workspace_context == req.context.workspace_context
    assert result.data.status == STTMStatus.NEEDS_INPUT
    assert list(result.result.mappings) == ["COL_0", "COL_1", "COL_2", "COL_3"]
    assert sorted(calls) == sorted({"COL_2", "COL_3"} - set(blocked))
    assert len(partials) == len(calls)
    assert len(projections) == len(set(projections)) == 2
    assert result.meta["auto_mapping_review"]["preserved_count"] == 2
    assert result.meta["auto_mapping_review"]["newly_mapped_count"] == 2 - len(blocked)
    assert result.meta["auto_mapping_review"]["unresolved_count"] == len(blocked)
    assert result.meta["auto_mapping_review"]["action_required_count"] == len(blocked)
    assert result.meta["auto_mapping_coverage"]["complete_coverage"] is False
    assert result.meta["auto_mapping_coverage"]["requested"] == 4
    assert result.meta["auto_mapping_coverage"]["returned"] == 4
    assert set(result.meta["auto_mapping_coverage"]["preflight_rejected_targets"]) == set(blocked)
    assert {warning.field for warning in result.warnings
        if warning.code == "AUTO_MAP_PREFLIGHT_BUDGET_EXCEEDED"} == set(blocked)
    for target in blocked:
        mapping = result.result.mappings[target]
        assert mapping.transformation_classification == "unresolved"
        assert "not a model no-match" in mapping.unmatched_reason
    assert "e" * 100 not in json.dumps(result.meta)


@pytest.mark.parametrize("prepare", [False, True])
@pytest.mark.parametrize("blocked_count", [1, 10])
def test_durable_preflight_preserves_27_and_terminates_with_blocked_targets(monkeypatch, prepare, blocked_count):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy(AUTO_MAP_PIPELINE_V2=True, SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    req = authored(pending=10, expressions=tuple(f"src.COL_{index}" for index in range(27)))
    blocked = {f"COL_{index}" for index in range(27, 27 + blocked_count)}
    for attribute in req.data.attributes:
        if attribute.target_attribute in blocked:
            attribute.target_data_type = "Irreducible synthetic identity " + "x" * 250_000
    before = req.model_dump(mode="json")
    original = STTMBuilderService.project_agent_payload
    projections, persisted, posts, freezes = [], [], [], []
    finished = threading.Event()
    def project(request, settings):
        projections.append(tuple(item.target_attribute for item in request.data.attributes))
        return original(request, settings)
    resolver = deterministic.resolve_authored_targets
    def resolve(request, **kwargs):
        freezes.append(request)
        return resolver(request, **kwargs)
    monkeypatch.setattr(deterministic, "resolve_authored_targets", resolve)
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", project)
    def prepare_context(self, request):
        from app.schema.sttm_builder import AgentExecutionContextV2
        request.context.execution_context = AgentExecutionContextV2(context_key="preflight-test")
        return request
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", prepare_context)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence",
        lambda self, request, targets: {target: {"diagnostics": {"status": "no_match"}} for target in targets})
    headers = {"X-Workbench-OAuth-User": "ALICE", "X-Workbench-OAuth-Role": "READER"}
    monkeypatch.setattr(client, "_forward_headers", lambda request: headers)
    monkeypatch.setattr(client, "_load_persisted_job", lambda *args, **kwargs: deepcopy(persisted[-1]) if persisted else None)
    def persist(record, **kwargs):
        assert kwargs["required"] is True
        persisted.append(deepcopy(record))
    monkeypatch.setattr(client, "_persist_job", persist)
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    class WorkerHTTP:
        def __init__(self, **kwargs):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def post(self, url, **kwargs):
            assert kwargs["headers"] == headers
            batch = STTMBuilderEnvelopeRequest.model_validate(kwargs["json"])
            names = {item.target_attribute for item in batch.data.attributes}
            assert not names & blocked
            assert all(name not in names for name in (f"COL_{index}" for index in range(27)))
            saved = persisted[-1]["request_envelope"]["meta"][module._RESOLUTION_PLAN_KEY]
            assert saved["preflight_hash"] == client._resolution_digest(saved["preflight"])
            assert batch.meta["_automap_deadline"] == saved["deadline_at"]
            assert module._RESOLUTION_PLAN_KEY not in batch.meta
            posts.append(names)
            return httpx.Response(200, json=_response(batch).model_dump(mode="json"))
    monkeypatch.setattr(module.httpx, "Client", WorkerHTTP)
    start = time.perf_counter()
    accepted = client.start_job(request_context(), req, session=object(), prepare=prepare)
    try:
        assert finished.wait(45)
        assert time.perf_counter() - start < 45
        terminal = persisted[-1]
        assert terminal["status"] == terminal["stage"] == "partial_failure"
        assert terminal["error"] is None
        result = STTMBuilderEnvelopeRequest.model_validate(terminal["request_envelope"])
        plan = result.meta[module._RESOLUTION_PLAN_KEY]
        response = terminal["response"]
        assert response["data"]["status"] == "needs_input"
        assert len(response["result"]["mappings"]) == 37
        review = response["meta"]["auto_mapping_review"]
        assert (review["preserved_count"], review["newly_mapped_count"], review["unresolved_count"]) == (27, 10 - blocked_count, blocked_count)
        assert terminal["completed_attribute_count"] == 37 - blocked_count
        assert terminal["completed_batch_count"] == len(terminal["partial_responses"]) == len(posts)
        assert terminal["batch_count"] == len(posts) + blocked_count
        assert len(freezes) == 1
        assert len(projections) == len(set(projections))
        assert plan["partition_hash"] == client._resolution_digest(plan["targets"])
        assert len({item["preflight_hash"] for item in terminal["preparation_diagnostics"]["batches"]}) == 1
        assert result.context.workspace_context.model_dump(mode="json") == before["context"]["workspace_context"]
        assert result.data.model_dump(mode="json") == before["data"]
        assert req.model_dump(mode="json") == before
        if blocked_count == 10:
            assert posts == terminal["partial_responses"] == []
            assert response["thread_id"] is response["agent"] is None
        assert all(not set(partial["target_attributes"]) & blocked for partial in terminal["partial_responses"])
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)


@pytest.mark.parametrize("change", [None, "preflight_hash", "rejection", "budget", "context", "revision"])
def test_frozen_preflight_restart_reuses_only_unchanged_authority(monkeypatch, change):
    from app.core.sttm_builder import STTMBuilderService
    first = proxy()
    request = authored(pending=2)
    request.data.attributes[2].target_data_type = "q" * 250_000
    frozen = first._freeze_resolution(request)
    batches = first._build_batches(frozen)
    original_deadline = frozen.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"]
    raw = frozen.model_dump(mode="json")
    plan = raw["meta"][module._RESOLUTION_PLAN_KEY]
    if change == "preflight_hash":
        plan["preflight_hash"] = "wrong"
    elif change == "rejection":
        plan["preflight"]["batches"][0]["rejection"] = None
    elif change == "context":
        raw["context"]["semantic_bundle_label"] = "different"
    second = proxy()
    if change == "budget":
        second._settings.agent_outbound_message_max_chars += 1
    elif change == "revision":
        second._settings.automap_fast_canary_revision = "changed"
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", deny)
    monkeypatch.setattr(deterministic, "resolve_authored_targets", deny)
    monkeypatch.setattr(second, "_invoke_batch", deny)
    if change is not None:
        with pytest.raises(SnowflakeAgentError, match="preflight"):
            restored = second._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(raw))
            second._invoke_with_headers(restored, headers={})
        return
    pending = first._pending_resolution_request(frozen)
    # Even a structurally valid claimed success for the rejected batch cannot
    # override the frozen local rejection. Only the fitting receipt is reused.
    partials = [{"batch_index": index, "batch_identity": first._batch_identity(frozen, batch),
        "response": _response(pending.model_copy(update={"data": pending.data.model_copy(update={"attributes": batch})})).model_dump(mode="json")}
        for index, batch in enumerate(batches)]
    restored = second._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(raw))
    response = second._invoke_with_headers(restored, headers={}, resume_partials=partials)
    assert restored.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"] == original_deadline
    assert response.meta["auto_mapping_dispatch"]["resumed_batch_indices"] == [1]
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == 1
    assert response.result.mappings["COL_2"].transformation_classification == "unresolved"


@pytest.mark.parametrize("invalid", ["blocked", "partition", "wrong_target", "wrong_request", "duplicate"])
@pytest.mark.parametrize("ack_fails", [False, True])
def test_runner_quarantines_invalid_resume_receipts_before_publication(monkeypatch, invalid, ack_fails):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    req = authored(pending=2)
    req.data.attributes[2].target_data_type = "q" * 250_000
    root = client._freeze_resolution(req)
    batches = client._build_batches(root)
    pending = client._pending_resolution_request(root)
    def receipt(index):
        batch = batches[index]
        response = _response(pending.model_copy(update={"data": pending.data.model_copy(update={"attributes": batch})}))
        return {"batch_index": index, "batch_identity": client._batch_identity(root, batch),
            "target_attributes": [item.target_attribute for item in batch], "attribute_count": len(batch),
            "response": response.model_dump(mode="json")}
    valid = receipt(1)
    bad = receipt(0 if invalid == "blocked" else 1)
    if invalid == "partition":
        bad["batch_identity"]["partition_hash"] = "old"
    elif invalid == "wrong_target":
        for result in (bad["response"]["result"], bad["response"]["data"]["result"]):
            result["mappings"]["COL_2"] = result["mappings"].pop("COL_3")
    elif invalid == "wrong_request":
        bad["response"]["request_id"] = "wrong-request"
    for result in (bad["response"]["result"], bad["response"]["data"]["result"]):
        next(iter(result["mappings"].values()))["source_attributes"] = ["WRONG_SOURCE_PRIVATE_MARKER"]
    job_id = str(uuid.uuid4())
    record = {"job_id": job_id, "request_id": req.request_id, "owner": "ALICE", "status": "running",
        "stage": "source_mapping", "request_envelope": root.model_dump(mode="json"),
        "partial_responses": [valid, bad], "completed_batch_count": 2, "completed_attribute_count": 4,
        "batch_count": 2, "state_version": 0, "response": None, "error": None}
    saved = deepcopy(record)
    persisted, public_snapshots = [], []
    finished = threading.Event()
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", deny)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    def persist(snapshot, **kwargs):
        assert kwargs["required"] is True
        public_snapshots.append(deepcopy(client._public_job(record)))
        assert snapshot["partial_responses"] == [valid]
        if ack_fails:
            raise module._AutoMapPersistenceError("quarantine ACK failed")
        persisted.append(deepcopy(snapshot))
    monkeypatch.setattr(client, "_persist_job", persist)
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS[job_id] = record
    try:
        public_snapshots.append(deepcopy(client._public_job(record)))
        client._launch_job_runner(job_id, req=STTMBuilderEnvelopeRequest.model_validate(record["request_envelope"]),
            headers={}, owner="ALICE", record=record)
        assert finished.wait(10)
        public_snapshots.append(client._public_job(record))
        for public in public_snapshots:
            assert public["partial_responses"] == [valid]
            assert "WRONG_SOURCE_PRIVATE_MARKER" not in json.dumps(public)
            assert "rejected_partial_receipts" not in public
            assert public["completed_batch_count"] == 1
            assert public["completed_attribute_count"] == 3
        if ack_fails:
            assert persisted == [] and record == saved
        else:
            assert record == persisted[-1]
            assert record["status"] == "partial_failure"
            assert record["partial_responses"] == [valid]
            assert record["rejected_partial_receipts"] == [{"receipt_hash": client._resolution_digest(bad),
                "reason": "invalid_frozen_partition_receipt"}]
            response = record["response"]
            assert response["meta"]["auto_mapping_dispatch"]["resumed_batch_indices"] == [1]
            assert response["meta"]["auto_mapping_review"]["newly_mapped_count"] == 1
            assert response["result"]["mappings"]["COL_2"]["transformation_classification"] == "unresolved"
            assert "WRONG_SOURCE_PRIVATE_MARKER" not in json.dumps(record)
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(job_id, None)


@pytest.mark.parametrize("outcome", ["fits", "budget", "already_expired"])
def test_shared_deadline_stops_host_preflight_candidates_without_post(monkeypatch, outcome):
    from app.core.sttm_builder import STTMBuilderService
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    client = proxy()
    root = client._freeze_resolution(authored(pending=10))
    deadline = root.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"]
    before = deepcopy(root.model_dump(mode="json"))
    clock = [deadline + 1 if outcome == "already_expired" else deadline - 1]
    projections = []
    monkeypatch.setattr(module.time, "time", lambda: clock[0])
    original = STTMBuilderService.project_agent_payload
    def project(request, settings):
        assert clock[0] < deadline
        assert request.meta["_automap_deadline"] == deadline
        projections.append(request)
        result = original(request, settings)
        clock[0] = deadline + 1
        if outcome == "budget":
            raise AgentPayloadBudgetError("not proof of size once the deadline expired")
        return result
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", project)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    partials = []
    response = client._invoke_with_headers(root, headers={}, progress_callback=lambda *args: partials.append(args))
    assert len(projections) == (0 if outcome == "already_expired" else 1)
    assert partials == []
    assert response.data.status == STTMStatus.NEEDS_INPUT
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2
    assert response.meta["auto_mapping_review"]["unresolved_count"] == 10
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == 0
    assert {warning.field for warning in response.warnings if warning.code == module._PREFLIGHT_DEADLINE_CODE} == {
        f"COL_{index}" for index in range(2, 12)}
    assert not any(warning.code == module._PREFLIGHT_BUDGET_CODE for warning in response.warnings)
    assert {item["category"] for item in response.meta["auto_mapping_review"]["recommendations"]} == {"preflight_deadline_exceeded"}
    after = root.model_dump(mode="json")
    for key in ("preflight", "preflight_hash"):
        after["meta"][module._RESOLUTION_PLAN_KEY].pop(key)
    assert after == before


def test_preflight_authorization_error_is_not_relabelled_or_frozen_after_deadline(monkeypatch):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy()
    root = client._freeze_resolution(authored(pending=10))
    before = root.model_dump(mode="json")
    deadline = root.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"]
    clock = [deadline - 1]
    monkeypatch.setattr(module.time, "time", lambda: clock[0])
    def denied(*args, **kwargs):
        clock[0] = deadline + 1
        raise PermissionError("authorization failed")
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", denied)
    with pytest.raises(PermissionError, match="authorization failed"):
        client._build_batches(root)
    assert root.model_dump(mode="json") == before
    from app.core.automap_fast_context import _PROJECTION_DEADLINE
    assert _PROJECTION_DEADLINE.get() is None


def test_host_passes_one_monotonic_deadline_through_real_metadata_free_projection(monkeypatch):
    from app.core import automap_fast_context as context_module
    client = proxy()
    root = client._freeze_resolution(authored(pending=10))
    original_meta = deepcopy(root.meta)
    utc_now = module.datetime.fromtimestamp(root.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"] - 2, module.UTC)
    clock, conversions, renders = [100.0], [], []
    class ClockDateTime(module.datetime):
        @classmethod
        def now(cls, tz=None):
            conversions.append(tz)
            return utc_now
    monkeypatch.setattr(context_module, "datetime", ClockDateTime)
    monkeypatch.setattr(context_module.time, "monotonic", lambda: clock[0])
    original = context_module.factor_fast_packet
    def factor(packet, **kwargs):
        assert context_module._PROJECTION_DEADLINE.get() == pytest.approx(102.0, abs=0.00001)
        renders.append(packet)
        result = original(packet, **kwargs)
        clock[0] = 103.0
        return result
    monkeypatch.setattr(context_module, "factor_fast_packet", factor)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(root, headers={})
    assert len(conversions) == len(renders) == 1
    assert context_module._PROJECTION_DEADLINE.get() is None
    assert response.meta["auto_mapping_review"]["unresolved_count"] == 10
    assert {warning.code for warning in response.warnings} == {module._PREFLIGHT_DEADLINE_CODE}
    assert root.meta["_automap_acceptance"] == original_meta["_automap_acceptance"]
    assert root.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"] == original_meta[module._RESOLUTION_PLAN_KEY]["deadline_at"]


@pytest.mark.parametrize("resume_valid", [False, True])
def test_durable_runner_deadline_retains_completed_receipt_and_truthful_counts(monkeypatch, resume_valid):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    root = client._freeze_resolution(authored(pending=10))
    deadline = root.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"]
    clock, projections = [deadline - 1], []
    monkeypatch.setattr(module.time, "time", lambda: clock[0])
    original = STTMBuilderService.project_agent_payload
    def project(request, settings):
        projections.append(request)
        assert clock[0] < deadline
        result = original(request, settings)
        if not resume_valid or len(projections) == 2:
            clock[0] = deadline + 1
        return result
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", project)
    batches = client._build_batches(root)
    partials = []
    if resume_valid:
        pending = client._pending_resolution_request(root)
        response = _response(pending.model_copy(update={"data": pending.data.model_copy(update={"attributes": batches[0]})}))
        partials = [{"batch_index": 0, "batch_identity": client._batch_identity(root, batches[0]),
            "target_attributes": [item.target_attribute for item in batches[0]], "attribute_count": len(batches[0]),
            "response": response.model_dump(mode="json")}]
    record = {"job_id": str(uuid.uuid4()), "request_id": root.request_id, "owner": "ALICE",
        "status": "running", "stage": "source_mapping", "request_envelope": root.model_dump(mode="json"),
        "partial_responses": partials, "completed_batch_count": len(partials),
        "completed_attribute_count": 2 + (len(batches[0]) if resume_valid else 0), "state_version": 0}
    finished, persisted = threading.Event(), []
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "_persist_job", lambda snapshot, **kwargs: persisted.append(deepcopy(snapshot)))
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", deny)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS[record["job_id"]] = record
    try:
        client._launch_job_runner(record["job_id"], req=STTMBuilderEnvelopeRequest.model_validate(record["request_envelope"]),
            headers={}, owner="ALICE", record=record)
        assert finished.wait(10)
        assert len(projections) == (2 if resume_valid else 1)
        terminal = persisted[-1]
        public = client._public_job(terminal)
        assert terminal["status"] == terminal["stage"] == "partial_failure"
        assert terminal["partial_responses"] == public["partial_responses"] == partials
        assert terminal["completed_batch_count"] == public["completed_batch_count"] == len(partials)
        mapped = len(batches[0]) if resume_valid else 0
        assert terminal["completed_attribute_count"] == 2 + mapped
        review = terminal["response"]["meta"]["auto_mapping_review"]
        assert (review["preserved_count"], review["newly_mapped_count"], review["unresolved_count"]) == (2, mapped, 10 - mapped)
        assert terminal["response"]["data"]["status"] == "needs_input"
        assert terminal["request_envelope"]["meta"][module._RESOLUTION_PLAN_KEY]["deadline_at"] == deadline
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(record["job_id"], None)


@pytest.mark.parametrize("outcome", ["success", "wrong_request", "wrong_target", "failed", "omitted"])
def test_mixed_preflight_block_does_not_bypass_worker_result_validation(monkeypatch, outcome):
    request = authored(pending=2)
    request.data.attributes[2].target_data_type = "z" * 250_000
    client = proxy()
    partials = []
    def invoke(batch, **kwargs):
        assert [item.target_attribute for item in batch.data.attributes] == ["COL_3"]
        response = _response(batch)
        if outcome == "wrong_request":
            response.request_id = "other-request"
        elif outcome == "wrong_target":
            response.result.mappings["COL_2"] = response.result.mappings.pop("COL_3")
        elif outcome == "failed":
            response.data.status = STTMStatus.FAILED
        elif outcome == "omitted":
            response.result.mappings.clear()
        return response
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_with_headers(request, headers={}, progress_callback=lambda *args: partials.append(args[-1]))
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == int(outcome == "success")
    assert response.meta["auto_mapping_review"]["unresolved_count"] == 2 - int(outcome == "success")
    assert len(partials) == int(outcome == "success")
    assert response.result.mappings["COL_2"].transformation_classification == "unresolved"
    assert response.data.status == STTMStatus.NEEDS_INPUT
    if outcome == "success":
        assert response.thread_id == _response(request).thread_id
        assert response.agent == _response(request).agent


def test_preflight_ack_failure_cannot_dispatch_or_publish_locally_blocked_receipt(monkeypatch):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    req = authored(pending=2)
    req.data.attributes[2].target_data_type = "x" * 250_000
    finished = threading.Event()
    persisted = []
    monkeypatch.setattr(client, "_prepare_job_request", lambda request, **kwargs: client._freeze_resolution(request))
    monkeypatch.setattr(client, "_forward_headers", lambda request: {})
    monkeypatch.setattr(client, "_load_persisted_job", lambda *args, **kwargs: deepcopy(persisted[-1]) if persisted else None)
    def persist(record, **kwargs):
        if record.get("preparation_diagnostics", {}).get("stage") == "ready":
            raise module._AutoMapPersistenceError("preflight acknowledgement failed")
        persisted.append(deepcopy(record))
    monkeypatch.setattr(client, "_persist_job", persist)
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    accepted = client.start_job(request_context(), req, session=object(), prepare=True)
    try:
        assert finished.wait(5)
        assert persisted[-1]["response"] is None
        assert not persisted[-1]["partial_responses"]
        assert module._AUTO_MAP_JOBS[accepted["job_id"]] == persisted[-1]
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)


def test_preflight_rejected_invalid_baseline_keeps_original_rows_and_sql(monkeypatch):
    client = proxy()
    req = authored(expressions=("src.COL_0", "src.UNKNOWN_COLUMN"))
    sql = "SELECT src.COL_0 AS COL_0\r\nFROM DB.SRC.SOURCE src;\n"
    req.context.workspace_context.mapping_sql = sql
    req.context.workspace_context.raw_mapping_sql = sql
    req.data.attributes[1].target_data_type = "e" * 250_000
    before = req.model_dump(mode="json")
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(req, headers={})
    assert response.meta["auto_mapping_review"]["preserved_count"] == 1
    assert response.meta["auto_mapping_review"]["baseline_retained_count"] == 2
    assert response.meta["auto_mapping_review"]["action_required_count"] == 1
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == 0
    assert response.meta["automap_preserved_targets"] == ["COL_0", "COL_1"]
    assert response.meta["automap_baseline_preservation"]["preserve_raw_mapping_sql"] is True
    assert response.meta["auto_mapping_review"]["recommendations"][0]["category"] == "preflight_budget_exceeded"
    assert response.context.workspace_context.raw_mapping_sql.encode() == sql.encode()
    assert response.context.workspace_context.mapping_sql.encode() == sql.encode()
    assert response.context.workspace_context.model_dump(mode="json") == before["context"]["workspace_context"]
    assert req.model_dump(mode="json") == before


def test_caller_json_cannot_reuse_a_backend_preflight_to_skip_work(monkeypatch):
    client = proxy()
    frozen = client._freeze_resolution(authored(pending=1))
    client._build_batches(frozen)
    raw = frozen.model_dump(mode="json")
    raw["data"]["attributes"][2]["target_data_type"] = "e" * 250_000
    request = STTMBuilderEnvelopeRequest.model_validate(raw)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(request, headers={})
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == 0
    assert response.meta["auto_mapping_dispatch"]["preflight_rejected_batches"] == [0]


@pytest.mark.parametrize("outcome", ["exception", "wrong_request", "wrong_operation", "error_envelope", "wrong_target"])
def test_agent_failure_or_mismatch_keeps_every_target_unresolved(monkeypatch, outcome):
    client = proxy()
    req = authored(pending=1)
    def invoke(batch, **kwargs):
        if outcome == "exception":
            raise httpx.ReadTimeout("worker stalled")
        result = _response(batch)
        if outcome == "wrong_request":
            result.request_id = "unrelated"
        elif outcome == "wrong_operation":
            result.operation = "sttm.transform"
        elif outcome == "error_envelope":
            result.data.status = STTMStatus.FAILED
        else:
            result.result.mappings = {"FOREIGN.TABLE.COL_2": next(iter(result.result.mappings.values()))}
        return result
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_with_headers(req, headers={})
    assert response.data.status == STTMStatus.NEEDS_INPUT
    assert list(response.result.mappings) == ["COL_0", "COL_1", "COL_2"]
    assert response.result.mappings["COL_2"].transformation_classification == "unresolved"
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == 0
    assert response.meta["auto_mapping_review"]["unresolved_count"] == 1
    assert response.context.workspace_context == req.context.workspace_context


def test_unbound_values_keep_definition_and_block_execution_even_with_stale_graph(monkeypatch):
    req = authored(expressions=("$Firm",))
    req.context.relation_graph.value_bindings = [ValueBinding(binding_id="stale", value="$Firm",
        attribute_name="Firm", resolved_value="wrong-project", is_placeholder=True, resolution_status="project_attribute")]
    client = proxy()
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(req, headers={})
    assert response.data.status == STTMStatus.NEEDS_INPUT
    assert response.meta["auto_mapping_review"]["preserved_count"] == 1
    assert response.meta["auto_mapping_review"]["execution_blocked_count"] == 1
    assert response.meta["automap_resolution"]["execution_status"] == "blocked"
    assert response.meta["automap_resolution"]["targets"][0]["unresolved_values"] == ["$Firm"]
    assert response.context.workspace_context.mapping_rows[0].expression == "$Firm"
    assert response.result.mappings["COL_0"].constant_value is None


def test_backend_supplied_project_values_are_frozen_not_reread(monkeypatch):
    client = proxy()
    req = client._freeze_resolution(authored(expressions=("$Firm",)), project_attributes=[
        SimpleNamespace(attribute_name="Firm", attribute_type="VARCHAR", attribute_value="Acme")])
    monkeypatch.setattr(deterministic, "resolve_authored_targets", deny)
    response = client._invoke_with_headers(req, headers={})
    assert response.meta["auto_mapping_review"]["execution_blocked_count"] == 0
    assert response.context.workspace_context.mapping_rows[0].expression == "$Firm"


@pytest.mark.parametrize("mode, selected, expected", [
    ("reeval_selected", ["COL_1"], ["COL_1"]), ("reeval_all", None, ["COL_0", "COL_1"])])
def test_explicit_reevaluation_calls_worker_and_counts_replacements_not_new(monkeypatch, mode, selected, expected):
    client = proxy()
    req = authored()
    req.meta["auto_map_resolution_mode"] = mode
    if selected:
        req.meta["auto_map_reevaluate_targets"] = selected
    calls = []
    monkeypatch.setattr(client, "_invoke_batch", lambda batch, **kwargs: (calls.extend(
        item.target_attribute for item in batch.data.attributes), _response(batch))[1])
    result = client._invoke_with_headers(req, headers={})
    assert sorted(calls) == sorted(expected)
    assert result.meta["auto_mapping_review"]["newly_mapped_count"] == 0
    assert result.meta["auto_mapping_review"]["proposed_count"] == len(expected)
    assert result.meta["auto_mapping_review"]["preserved_count"] == 2 - len(expected)
    assert result.meta["automap_preserved_targets"] == [name for name in ["COL_0", "COL_1"] if name not in expected]


@pytest.mark.parametrize("mode, choices", [("bogus", None), ({}, None), ("reeval_selected", None),
    ("reeval_selected", []), ("reeval_selected", ["COL_99"]), ("reeval_selected", ["COL_0", "COL_0"]),
    ("preserve_and_complete", ["COL_0"]), ("reeval_all", ["COL_0"])])
def test_invalid_modes_and_selections_fail_before_preflight(monkeypatch, mode, choices):
    client = proxy()
    req = authored()
    req.meta = {"auto_map_resolution_mode": mode}
    if choices is not None:
        req.meta["auto_map_reevaluate_targets"] = choices
    monkeypatch.setattr(client, "_build_batches", deny)
    with pytest.raises(HTTPException) as caught:
        client._invoke_with_headers(req, headers={})
    assert caught.value.status_code == 422


def test_client_json_cannot_supply_a_plan_or_extend_deadline(monkeypatch):
    client = proxy()
    req = authored(pending=1)
    req.meta[module._RESOLUTION_PLAN_KEY] = {"version": module._RESOLUTION_VERSION, "targets": []}
    req.meta["_automap_deadline"] = time.time() + 10000
    calls = []
    def invoke(batch, **kwargs):
        calls.append(batch)
        assert 0 < batch.meta["_automap_deadline"] - time.time() <= 180
        return _response(batch)
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_with_headers(req, headers={})
    assert len(calls) == 1
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2


@pytest.mark.parametrize("field", ["version", "baseline_hash", "partition_hash", "input_hash"])
def test_bad_durable_plan_rejected_without_reinterpreting(monkeypatch, field):
    client = proxy()
    raw = client._freeze_resolution(authored()).model_dump(mode="json")
    raw["meta"][module._RESOLUTION_PLAN_KEY][field] = "mismatch"
    monkeypatch.setattr(deterministic, "resolve_authored_targets", deny)
    with pytest.raises(SnowflakeAgentError):
        client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(raw))


def test_old_legacy_envelope_not_reinterpreted_on_restore():
    client = proxy()
    req = authored()
    req.meta = {}
    restored = client._restore_resolution(req)
    assert restored is req
    assert client._trusted_resolution_plan(restored) is None


@pytest.mark.parametrize("identity_change", [None, "baseline_hash", "partition_hash", "resolution_version"])
def test_restart_reuses_only_exact_pending_partition(monkeypatch, identity_change):
    first = proxy()
    req = first._freeze_resolution(authored(pending=1))
    pending = first._pending_resolution_request(req)
    identity = first._batch_identity(req, pending.data.attributes)
    partial = {"batch_index": 0, "batch_identity": identity, "response": _response(pending).model_dump(mode="json")}
    if identity_change:
        partial["batch_identity"][identity_change] = "old"
    second = proxy()
    restored = second._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(req.model_dump(mode="json")))
    monkeypatch.setattr(deterministic, "resolve_authored_targets", deny)
    calls = []
    monkeypatch.setattr(second, "_invoke_batch", lambda batch, **kwargs: (calls.append(batch), _response(batch))[1])
    response = second._invoke_with_headers(restored, headers={}, resume_partials=[partial])
    assert len(calls) == int(identity_change is not None)
    assert response.meta["automap_preserved_targets"] == ["COL_0", "COL_1"]
    assert response.context.workspace_context == req.context.workspace_context
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2


def test_deadline_returns_without_waiting_or_persisting_late_results(monkeypatch):
    client = proxy()
    req = client._freeze_resolution(authored(pending=1))
    expire_plan(req, time.time() + 0.4)
    # Isolate the dispatch deadline: complete preflight now correctly reserves
    # the model/validation window and refuses to start work with 0.4s left.
    monkeypatch.setattr(client, "_build_batches", lambda request, **kwargs: [client._pending_resolution_request(request).data.attributes])
    started, release, finished = threading.Event(), threading.Event(), threading.Event()
    partials = []
    def invoke(batch, **kwargs):
        started.set()
        try:
            assert release.wait(3)
            return _response(batch)
        finally:
            finished.set()
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    begin = time.perf_counter()
    try:
        response = client._invoke_with_headers(req, headers={}, progress_callback=lambda *args: partials.append(args))
        assert started.is_set()
        assert time.perf_counter() - begin < 1.5
        assert response.data.status == STTMStatus.NEEDS_INPUT
        assert response.meta["auto_mapping_dispatch"]["failed_batches"] == [0]
        assert response.meta["auto_mapping_review"]["preserved_count"] == 2
        assert not partials
    finally:
        release.set()
    assert finished.wait(1)
    assert not partials


def test_already_expired_plan_makes_no_worker_call(monkeypatch):
    client = proxy()
    req = client._freeze_resolution(authored(pending=1))
    expire_plan(req, time.time() - 1)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(req, headers={})
    assert response.meta["auto_mapping_review"]["unresolved_count"] == 1


def request_context():
    request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    request.state.current_principal = SimpleNamespace(snowflake_user="ALICE", user_id=1)
    return request


def test_real_prepare_and_durable_runner_all_preserved(monkeypatch):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    finished = threading.Event()
    persisted = []
    calls = []
    resolve = deterministic.resolve_authored_targets
    monkeypatch.setattr(deterministic, "resolve_authored_targets", lambda req, **kwargs:
        (calls.append(req), resolve(req, **kwargs))[1])
    monkeypatch.setattr(client, "_forward_headers", lambda request: {})
    monkeypatch.setattr(client, "_load_persisted_job", lambda *args, **kwargs: deepcopy(persisted[-1]) if persisted else None)
    def persist(record, **kwargs):
        assert kwargs["required"] is True
        persisted.append(deepcopy(record))
    monkeypatch.setattr(client, "_persist_job", persist)
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    req = authored()
    accepted = client.start_job(request_context(), req, session=object(), prepare=True)
    try:
        assert finished.wait(4)
        terminal = persisted[-1]
        assert terminal["status"] == "completed"
        assert terminal["batch_count"] == terminal["completed_batch_count"] == 0
        assert terminal["completed_attribute_count"] == 2
        assert terminal["partial_responses"] == []
        assert terminal["response"]["agent"] is None
        assert len(calls) == 1
        assert module._RESOLUTION_PLAN_KEY in terminal["request_envelope"]["meta"]
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)


@pytest.mark.parametrize("counts, accepted", [([], False), ([(0, 0)], False), ([(1, 0)], True), ([(0, 1)], True), ([(1, 1)], False)])
def test_fast_durable_write_checks_affected_row_ack(counts, accepted):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    req = client._freeze_resolution(authored())
    record = {"job_id": "ack-test", "owner": "ALICE", "state_version": 1,
              "request_envelope": req.model_dump(mode="json")}
    session = SimpleNamespace(sql=lambda *args, **kwargs: SimpleNamespace(collect=lambda: counts))
    if accepted:
        client._persist_job(record, headers={}, session=session, required=True)
    else:
        with pytest.raises(module._AutoMapPersistenceError):
            client._persist_job(record, headers={}, session=session, required=True)


@pytest.mark.parametrize("partial", [False, True])
def test_failed_persistence_cannot_publish_partial_or_terminal_in_memory(monkeypatch, partial):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    req = client._freeze_resolution(authored(pending=1))
    job_id = str(uuid.uuid4())
    record = {"job_id": job_id, "owner": "ALICE", "state_version": 2, "status": "running",
              "request_envelope": req.model_dump(mode="json"), "partial_responses": []}
    before = deepcopy(record)
    def fail(*args, **kwargs):
        assert kwargs["required"] is True
        raise module._AutoMapPersistenceError("unacknowledged")
    monkeypatch.setattr(client, "_persist_job", fail)
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS[job_id] = record
    try:
        with pytest.raises(module._AutoMapPersistenceError):
            if partial:
                pending = client._pending_resolution_request(req)
                client._record_partial_response(job_id, batch_index=0, batch_attributes=pending.data.attributes,
                    response=_response(pending), headers={}, session=object())
            else:
                client._update_job(job_id, status="completed", response={"fake": "completion"}, headers={}, session=object())
        assert module._AUTO_MAP_JOBS[job_id] == before
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(job_id, None)


def test_real_ft_pitt_full_parser_frontend_snapshot_skips_all_workers(monkeypatch, real_ft_pitt_upload):
    client = proxy()
    req = real_ft_pitt_request(real_ft_pitt_upload)
    req.context.project_id = "test-project"
    req.meta["auto_map_resolution_mode"] = "preserve_and_complete"
    before = req.model_dump(mode="json")
    monkeypatch.setattr(client, "_build_batches", deny)
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(req, headers={})
    review = response.meta["auto_mapping_review"]
    assert len(response.result.mappings) == 35
    assert review["preserved_count"] == 35
    assert review["newly_mapped_count"] == review["mapped_count"] == 0
    assert response.meta["auto_mapping_dispatch"]["batch_count"] == 0
    assert response.agent is None and response.thread_id is None
    assert req.model_dump(mode="json") == before
    assert response.context.workspace_context.model_dump(mode="json") == before["context"]["workspace_context"]
    assert review["execution_blocked_count"] > 0
    assert response.data.status == STTMStatus.NEEDS_INPUT


def test_pending_existing_definition_partial_carries_do_not_overwrite_accounting(monkeypatch):
    client = proxy()
    req = authored(expressions=("src.UNKNOWN_COLUMN",))
    before = req.model_dump(mode="json")
    monkeypatch.setattr(client, "_invoke_batch", lambda batch, **kwargs: _response(batch))
    partials = []
    response = client._invoke_with_headers(req, headers={}, progress_callback=lambda *args: partials.append(args[-1]))
    for result in [response, *partials]:
        assert result.meta["automap_preserved_targets"] == ["COL_0"]
        assert result.meta["auto_mapping_review"]["newly_mapped_count"] == 0
        assert result.meta["auto_mapping_review"]["mapped_count"] == 0
        assert result.meta["auto_mapping_review"]["proposed_count"] == 1
        assert result.meta["automap_baseline_preservation"]["apply_preserved_mappings"] is False
        assert result.data.status == STTMStatus.NEEDS_INPUT
        assert result.meta["auto_mapping_review"]["unresolved_count"] == 1
    assert req.model_dump(mode="json") == before


def replay_proxy_in_frontend(req, partials, terminal):
    node = shutil.which("node")
    assert node, "Node is required for the actual frontend reducer regression"
    rows = [{"id": row.id, "targetColumn": row.target_column, "targetType": row.target_type or "VARCHAR",
        "status": row.status, "sourceColumn": ", ".join(row.source_columns) or None,
        "sourceColumns": row.source_columns, "expression": row.expression, "rule": row.rule,
        "nlRule": row.natural_language_rule, "mappingMode": row.mapping_mode,
        "constantValue": row.constant_value, "attributeName": row.attribute_name}
        for row in req.context.workspace_context.mapping_rows]
    script = Path(__file__).resolve().parents[3] / "frontend/scripts/test-automap-preservation.cjs"
    process = subprocess.run([node, str(script), "--proxy-replay"], input=json.dumps({
        "rows": rows, "partials": [result.model_dump(mode="json") for result in partials],
        "terminal": terminal.model_dump(mode="json")}), text=True, encoding="utf-8",
        capture_output=True, timeout=30, check=False)
    assert process.returncode == 0, process.stderr
    return rows, json.loads(process.stdout)


@pytest.mark.parametrize("legacy_partial", [False, True])
def test_invalid_baseline_real_proxy_partial_then_terminal_reducer(monkeypatch, legacy_partial):
    client = proxy()
    req = authored(expressions=("src.MISSING", "CURRENT_TIMESTAMP()"))
    def unresolved(batch, **kwargs):
        result = _response(batch)
        for mapping in result.result.mappings.values():
            mapping.source_attributes = []
            mapping.transformation_classification = "unresolved"
            mapping.unmatched_reason = "Current source column is unavailable"
        return result
    monkeypatch.setattr(client, "_invoke_batch", unresolved)
    partials = []
    terminal = client._invoke_with_headers(req, headers={}, progress_callback=lambda *args: partials.append(args[-1]))
    assert len(partials) == 1
    assert terminal.meta["automap_resolution"]["targets"][0]["diagnostics"][0]["code"] == "unknown_column"
    if legacy_partial:
        partials[0].meta.pop("automap_resolution", None)
    original, replay = replay_proxy_in_frontend(req, partials, terminal)
    assert replay["rows"] == [{**original[0], "status": "UNMAPPED"}, original[1]]
    assert replay["trace"][-1][0]["status"] == "UNMAPPED"
    assert not replay["reviews"]
    assert terminal.data.status == STTMStatus.NEEDS_INPUT
    assert terminal.meta["auto_mapping_review"]["unresolved_count"] == 1
    assert terminal.meta["automap_resolution"]["execution_status"] == "blocked"
    if not legacy_partial:
        assert replay["trace"][0][0]["status"] == "UNMAPPED"
        diagnostics = partials[0].meta["automap_resolution"]
        assert diagnostics["targets"] == terminal.meta["automap_resolution"]["targets"][:1]
        assert diagnostics["mode"] == "preserve_and_complete"
        assert diagnostics["execution_status"] == "blocked"


@pytest.mark.parametrize("mode", ["preserve_and_complete", "reeval_selected", "reeval_all"])
def test_authored_rule_presence_not_validity_controls_baseline_and_actual_apply(monkeypatch, mode):
    cases = [
        ({"rule": "COALESCE(src.COL_0, 'authored')", "status": "MAPPED"}, True, True),
        ({"rule": "CASE WHEN"}, True, False),
        ({"rule": "Custom", "natural_language_rule": "Keep the business-approved fallback"}, True, False),
        ({"rule": "Select..."}, False, False),
        ({"rule": "Direct"}, False, False),
        ({"rule": "VALUE", "mapping_mode": "constant", "constant_value": None}, False, False),
        ({"rule": "VALUE", "mapping_mode": "constant", "constant_value": ""}, True, False),
        ({"rule": "VALUE", "mapping_mode": "constant", "constant_value": "0", "status": "MAPPED"}, True, True),
        ({"rule": "VALUE", "mapping_mode": "constant", "constant_value": "false", "status": "MAPPED"}, True, True),
        ({"rule": "UPPER"}, True, False),
        ({"rule": "  Select...  ", "expression": "  ", "natural_language_rule": "  "}, False, False),
        ({"rule": "Identity"}, False, False),
    ]
    raw = authored(pending=len(cases), expressions=()).model_dump(mode="json")
    raw["context"]["workspace_context"]["mapping_rows"] = [
        {"id": f"row-{index}", "target_column": f"COL_{index}", "status": "UNMAPPED",
         "source_columns": [], "expression": None, **fields} for index, (fields, _, _) in enumerate(cases)]
    raw["meta"]["auto_map_resolution_mode"] = mode
    if mode == "reeval_selected":
        raw["meta"]["auto_map_reevaluate_targets"] = ["COL_1"]
    req = STTMBuilderEnvelopeRequest.model_validate(raw)
    before = req.model_dump(mode="json")
    client = proxy()
    frozen = client._freeze_resolution(req)
    entries = frozen.meta[module._RESOLUTION_PLAN_KEY]["targets"]
    assert [entry["had_baseline"] for entry in entries] == [baseline for _, baseline, _ in cases]
    reevaluated = {f"COL_{index}" for index in range(len(cases)) if mode == "reeval_all"
                   or mode == "reeval_selected" and index == 1}
    pending = {f"COL_{index}" for index, (_, _, valid) in enumerate(cases)
               if f"COL_{index}" in reevaluated or mode == "preserve_and_complete" and not valid}
    retained = {f"COL_{index}" for index, (_, baseline, _) in enumerate(cases)
                if baseline and f"COL_{index}" not in reevaluated}
    calls, partials = [], []
    monkeypatch.setattr(client, "_invoke_batch", lambda batch, **kwargs: (
        calls.extend(item.target_attribute for item in batch.data.attributes), _response(batch))[1])
    terminal = client._invoke_with_headers(frozen, headers={}, progress_callback=lambda *args: partials.append(args[-1]))
    assert set(calls) == pending
    assert set(terminal.meta["automap_preserved_targets"]) == retained
    review = terminal.meta["auto_mapping_review"]
    new_count = sum(f"COL_{index}" in pending and not baseline for index, (_, baseline, _) in enumerate(cases))
    preserved_count = sum(valid and f"COL_{index}" not in reevaluated for index, (_, _, valid) in enumerate(cases))
    unresolved_count = len(retained & pending) + sum(not valid and f"COL_{index}" not in pending
                                                   for index, (_, _, valid) in enumerate(cases))
    assert review["preserved_count"] == preserved_count
    assert review["baseline_retained_count"] == len(retained)
    assert review["unresolved_count"] == unresolved_count
    assert review["proposed_count"] == len(pending)
    assert review["newly_mapped_count"] == review["mapped_count"] == new_count
    assert review["completed_without_review_count"] == new_count
    assert sum(result.meta["auto_mapping_review"]["proposed_count"] for result in partials) == len(pending)
    assert sum(result.meta["auto_mapping_review"]["newly_mapped_count"] for result in partials) == new_count
    for partial in partials:
        resolution = partial.meta["automap_resolution"]
        assert resolution["mode"] == mode
        assert {entry["target_attribute"] for entry in resolution["targets"]} == set(partial.result.mappings)
        assert resolution["execution_status"] == (
            "blocked" if partial.meta["auto_mapping_review"]["unresolved_count"] else "not_validated")
    original, replay = replay_proxy_in_frontend(req, partials, terminal)
    assert {item["mappingId"] for item in replay["reviews"]} == {
        f"row-{index}" for index in range(len(cases)) if f"COL_{index}" in retained & pending}
    for index, row in enumerate(replay["rows"]):
        target = f"COL_{index}"
        if target in retained:
            expected = {**original[index], "status": "UNMAPPED"} if target in pending else original[index]
            assert row == expected
            assert all(snapshot[index]["rule"] == original[index]["rule"] for snapshot in replay["trace"])
        elif target in pending:
            assert row["status"] == "MAPPED"
            assert row["sourceColumn"] == f"DB.SRC.SOURCE.{target}"
            assert row["rule"] == "Direct"
    assert req.model_dump(mode="json") == before


def test_reeval_selected_does_not_silently_include_other_pending_targets(monkeypatch):
    client = proxy()
    req = authored(pending=1)
    req.meta.update(auto_map_resolution_mode="reeval_selected", auto_map_reevaluate_targets=["COL_0"])
    calls = []
    monkeypatch.setattr(client, "_invoke_batch", lambda batch, **kwargs: (
        calls.extend(item.target_attribute for item in batch.data.attributes), _response(batch))[1])
    response = client._invoke_with_headers(req, headers={})
    assert calls == ["COL_0"]
    assert list(response.result.mappings) == ["COL_0", "COL_1", "COL_2"]
    assert response.result.mappings["COL_2"].transformation_classification == "unresolved"
    assert response.meta["auto_mapping_dispatch"]["pending_attribute_count"] == 1
    assert response.data.status == STTMStatus.NEEDS_INPUT


def test_pending_omission_is_never_persisted_as_complete_batch(monkeypatch):
    client = proxy()
    monkeypatch.setattr(client, "_balanced_retrieval_batches", lambda req: [req.data.attributes])
    req = authored(pending=2)
    def invoke(batch, **kwargs):
        result = _response(batch)
        result.result.mappings.pop("COL_3")
        return result
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    partials = []
    response = client._invoke_with_headers(req, headers={}, progress_callback=lambda *args: partials.append(args))
    assert response.meta["auto_mapping_dispatch"]["failed_batches"] == [0]
    assert len(response.result.mappings) == 4
    assert response.result.mappings["COL_3"].transformation_classification == "unresolved"
    assert not partials


def test_http_timeout_is_bounded_by_remaining_parent_deadline(monkeypatch):
    client = proxy()
    req = client._pending_resolution_request(client._freeze_resolution(authored(pending=1)))
    req.meta["_automap_deadline"] = time.time() + 5
    captured = []
    class HTTPClient:
        def __init__(self, *, timeout):
            captured.append(timeout)
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def post(self, url, *, headers, json):
            return SimpleNamespace(status_code=200, json=lambda: _response(req).model_dump(mode="json"))
    monkeypatch.setattr(module.httpx, "Client", HTTPClient)
    result = client._invoke_batch(req, headers={}, batch_index=0)
    assert result.result.mappings
    assert len(captured) == 1 and 0 < captured[0] <= 5


@pytest.mark.parametrize("failure", [False, True])
def test_actual_durable_mixed_job_freezes_and_counts_truthfully(monkeypatch, failure):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy(AUTO_MAP_PIPELINE_V2=True, SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    finished = threading.Event()
    persisted = []
    calls = []
    # Only the unrelated semantic/FIR fetch is stubbed; run the real preparation,
    # resolver, preflight, runner, callback, and final merge.
    def prepare(self, request):
        from app.schema.sttm_builder import AgentExecutionContextV2
        request.context.execution_context = AgentExecutionContextV2(context_key="durable-mixed")
        return request
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", prepare)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence", lambda self, req, targets:
        {target: {"diagnostics": {"status": "no_match"}} for target in targets})
    monkeypatch.setattr(client, "_forward_headers", lambda request: {})
    monkeypatch.setattr(client, "_load_persisted_job", lambda *args, **kwargs: deepcopy(persisted[-1]) if persisted else None)
    def persist(record, **kwargs):
        assert kwargs["required"] is True
        persisted.append(deepcopy(record))
    monkeypatch.setattr(client, "_persist_job", persist)
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    def invoke(batch, **kwargs):
        calls.append([item.target_attribute for item in batch.data.attributes])
        assert any(module._RESOLUTION_PLAN_KEY in (item.get("request_envelope") or {}).get("meta", {}) for item in persisted)
        if failure:
            raise SnowflakeAgentError("worker failed")
        return _response(batch)
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    accepted = client.start_job(request_context(), authored(pending=1), session=object(), prepare=True)
    try:
        assert finished.wait(5)
        terminal = persisted[-1]
        assert calls == [["COL_2"]]
        assert terminal["status"] == ("partial_failure" if failure else "completed")
        assert terminal["batch_count"] == 1
        assert terminal["completed_batch_count"] == int(not failure)
        assert terminal["completed_attribute_count"] == (2 if failure else 3)
        assert len(terminal["partial_responses"]) == int(not failure)
        assert terminal["response"]["meta"]["auto_mapping_review"]["preserved_count"] == 2
        assert terminal["response"]["meta"]["auto_mapping_review"]["newly_mapped_count"] == int(not failure)
        assert terminal["batch_strategy"]["resolution_version"] == module._RESOLUTION_VERSION
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)


def test_blank_frontend_direct_row_counts_as_new_not_preserved(monkeypatch):
    from app.schema.workspace_context import WorkspaceMappingRow
    req = authored(pending=1)
    req.context.workspace_context.mapping_rows.append(WorkspaceMappingRow(id="blank", target_column="COL_2", rule="Direct", status="UNMAPPED"))
    client = proxy()
    monkeypatch.setattr(client, "_invoke_batch", lambda batch, **kwargs: _response(batch))
    response = client._invoke_with_headers(req, headers={})
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == 1
    assert response.meta["automap_preserved_targets"] == ["COL_0", "COL_1"]


def test_raw_sql_and_frontend_rows_remain_byte_exact(monkeypatch):
    req = authored(expressions=("src.COL_0",))
    sql = " SELECT  src.COL_0 AS COL_0\r\nFROM DB.SRC.SOURCE src WHERE src.COL_0 IS NOT NULL;\n"
    req.context.workspace_context.mapping_sql = sql
    req.context.workspace_context.raw_mapping_sql = sql
    client = proxy()
    monkeypatch.setattr(client, "_invoke_batch", deny)
    response = client._invoke_with_headers(req, headers={})
    assert response.context.workspace_context.mapping_sql.encode() == sql.encode()
    assert response.context.workspace_context.raw_mapping_sql.encode() == sql.encode()
    assert response.context.workspace_context.mapping_rows == req.context.workspace_context.mapping_rows
    assert response.meta["auto_mapping_review"]["preserved_count"] == 1


def test_new_replica_poll_restores_backend_plan_without_resolving_again(monkeypatch):
    first = proxy(AUTO_MAP_PIPELINE_V2=True)
    req = first._freeze_resolution(authored(pending=1))
    pending = first._pending_resolution_request(req)
    job_id = str(uuid.uuid4())
    record = {"job_id": job_id, "request_id": req.request_id, "owner": "ALICE", "status": "running",
        "preparation_pending": False, "batch_count": 1, "attribute_count": 3, "state_version": 5,
        "request_envelope": req.model_dump(mode="json"), "partial_responses": [{"batch_index": 0,
            "batch_identity": first._batch_identity(req, pending.data.attributes),
            "response": _response(pending).model_dump(mode="json")}], "response": None}
    second = proxy(AUTO_MAP_PIPELINE_V2=True)
    finished = threading.Event()
    persisted = []
    monkeypatch.setattr(deterministic, "resolve_authored_targets", deny)
    monkeypatch.setattr(second, "_invoke_batch", deny)
    monkeypatch.setattr(second, "_forward_headers", lambda request: {})
    monkeypatch.setattr(second, "_load_persisted_job", lambda *args, **kwargs: deepcopy(record))
    monkeypatch.setattr(second, "_persist_job", lambda snapshot, **kwargs: persisted.append(deepcopy(snapshot)))
    monkeypatch.setattr(second, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(second, "_claim_job_lease", lambda *args, **kwargs: True)
    try:
        second.get_job(request_context(), job_id, session=object())
        assert finished.wait(4)
        terminal = persisted[-1]
        assert terminal["status"] == "completed"
        assert terminal["response"]["meta"]["automap_preserved_targets"] == ["COL_0", "COL_1"]
        assert terminal["response"]["meta"]["auto_mapping_dispatch"]["resumed_batch_indices"] == [0]
        assert terminal["response"]["context"]["workspace_context"] == req.context.workspace_context.model_dump(mode="json")
        assert terminal["completed_attribute_count"] == 3
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(job_id, None)


@pytest.mark.parametrize("mismatch", ["request", "no_model", "omitted"])
def test_resume_rejects_unrelated_or_incomplete_response_even_with_matching_identity(monkeypatch, mismatch):
    client = proxy()
    req = client._freeze_resolution(authored(pending=1))
    pending = client._pending_resolution_request(req)
    partial = _response(pending)
    if mismatch == "request":
        partial.request_id = "other"
    elif mismatch == "no_model":
        partial.meta["auto_map_retrieval"] = {"parallel_preparation": {"enabled": True}, "model_call_count": 0}
    else:
        from app.schema.contracts import ApiWarning
        partial.warnings.append(ApiWarning(code="AUTO_MAPPING_TARGET_OMITTED", message="missing"))
    calls = []
    monkeypatch.setattr(client, "_invoke_batch", lambda batch, **kwargs: (calls.append(batch), _response(batch))[1])
    response = client._invoke_with_headers(req, headers={}, resume_partials=[{"batch_index": 0,
        "batch_identity": client._batch_identity(req, pending.data.attributes), "response": partial.model_dump(mode="json")}])
    assert len(calls) == 1
    assert response.meta["auto_mapping_dispatch"]["resumed_batch_indices"] == []


def test_deadline_wire_contract_matches_direct_context_helper():
    from app.core.automap_fast_context import request_deadline
    client = proxy()
    request = authored(pending=1)
    request.meta["auto_map_deadline_at"] = "2999-01-01T00:00:00Z"
    req = client._freeze_resolution(request)
    pending = client._pending_resolution_request(req)
    remaining = request_deadline(pending.meta) - time.monotonic()
    assert 0 < remaining <= module._RESOLUTION_DEADLINE_SECONDS
    assert pending.meta["auto_map_deadline_at"] != request.meta["auto_map_deadline_at"]


@pytest.mark.parametrize("change", ["targets", "table", "graph", "raw_sql", "actor", "worker_variant"])
def test_live_frozen_plan_rejects_request_mutation(change):
    from app.schema.contracts import ApiActor
    client = proxy()
    req = client._freeze_resolution(authored())
    if change == "targets":
        req.data.attributes.reverse()
    elif change == "table":
        req.context.workspace_context.target_table.table = "FOREIGN"
    elif change == "graph":
        req.context.relation_graph.nodes[0].alias = "other"
    elif change == "raw_sql":
        req.context.workspace_context.raw_mapping_sql = "SELECT 1 AS COL_0"
    elif change == "worker_variant":
        req.meta["auto_map_fast_path"] = "v2"
    else:
        req.actor = ApiActor(user_id="different-user")
    with pytest.raises(SnowflakeAgentError):
        client._invoke_with_headers(req, headers={})


def test_no_agent_preparation_cannot_claim_new_mappings(monkeypatch):
    client = proxy()
    def invoke(batch, **kwargs):
        response = _response(batch)
        response.meta["auto_map_retrieval"] = {"parallel_preparation": {"enabled": True}, "model_call_count": 0}
        return response
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    partials = []
    response = client._invoke_with_headers(authored(pending=1), headers={}, progress_callback=lambda *args: partials.append(args))
    assert response.meta["auto_mapping_review"]["mapped_count"] == 0
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2
    assert response.result.mappings["COL_2"].transformation_classification == "unresolved"
    assert response.meta["auto_mapping_dispatch"]["failed_batches"] == [0]
    assert not partials


@pytest.mark.parametrize("outcome, posts, mapped", [
    ("success", 1, 1), ("repair", 2, 1), ("lost_ack", 1, 0),
    ("output_archive_failure", 1, 0), ("invalid_wire", 1, 0), ("http429", 1, 0),
    ("success_many", 4, 5), ("profile_samples", 1, 1), ("mapping_artifacts", 1, 1),
    ("VIEWER", 1, 1), ("PUBLISHER", 1, 1)])
def test_proxy_to_real_batch_durable_adapter_with_fake_boundaries(harness, monkeypatch, outcome, posts, mapped):
    import json
    from app.core.automap_policy import preparation_hash
    from app.schema.sttm_builder import AgentExecutionContextV2
    from tests.unit.core.test_automap_retrieval import service
    from tests.unit.core.test_automap_fast_context import unpack

    client = proxy()
    pending = 5 if outcome == "success_many" else 1
    req = enriched_wire_request(outcome) if outcome in {"VIEWER", "PUBLISHER"} else authored(pending=pending)
    if outcome == "profile_samples":
        from app.schema.sttm_builder import SemanticContextItem
        req.context.semantic_context = [SemanticContextItem(table=req.context.source_tables[0], semantic_model={
            "attributes": [{"name": "COL_2", "value_profile": {"sample_values": ["PRIVATE_PROFILE_SAMPLE"],
                "nullable": False, "distinct_count": 7}}]})]
    if outcome == "mapping_artifacts":
        req.context.workspace_context.mapping_artifacts = [{"artifact_id": "prior-output", "result": {"body": "prior mapping"}}]
    req.context.execution_context = req.context.execution_context or AgentExecutionContextV2(context_key="actual-adapter-test")
    req.context.prepared_context_hash = preparation_hash(req.context)
    root = client._freeze_resolution(req)
    root = client._bind_fast_handoff(root, discovery={f"COL_{index}": {"diagnostics": {"status": "no_match"}}
        for index in range(2, 2 + pending)})
    worker = service(harness.service._agent)
    settings = {**worker._settings.model_dump(), **vars(harness.service._settings),
        "automap_fast_path_v1": True, "automap_fast_project_ids": ["501"]}
    worker._settings = SimpleNamespace(**settings)
    for key in ("_source_mapping_agent_name", "_parallel_caller", "_parallel_session_factory", "_session", "_query_session", "_model_guard"):
        setattr(worker, key, getattr(harness.service, key))
    worker._with_semantic_context = worker._with_learning_context = lambda *args: pytest.fail("Readonly worker refreshed context")
    worker._discover_auto_map_batch_evidence = lambda *args: pytest.fail("Worker repeated parent discovery")
    worker._should_use_analyst = lambda *args: False
    worker._persist_response_artifact = lambda *args: None
    worker._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    answer = json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
        "COL_2": {"source_attributes": ["src.COL_2"], "confidence_score": 0.9,
            "transformation_classification": "direct"}}}}})
    harness.state.mode = "success" if outcome in {"repair", "success_many", "profile_samples", "mapping_artifacts", "VIEWER", "PUBLISHER"} else outcome
    harness.state.answer = answer
    if outcome == "repair":
        harness.state.hook = lambda outgoing: setattr(harness.state, "answer",
            "terminal malformed mapping" if len(harness.state.models) == 1 else answer)
    workers = []
    original_send = httpx.Client.send
    worker_failures = []
    def send(http, outgoing, **kwargs):
        if outgoing.url.host != "worker.internal":
            return original_send(http, outgoing, **kwargs)
        assert b"PRIVATE_" not in outgoing.content
        batch = STTMBuilderEnvelopeRequest.model_validate(json.loads(outgoing.content))
        workers.append(batch)
        if pending > 1:
            harness.state.answer = json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
                item.target_attribute: {"source_attributes": [f"src.{item.target_attribute}"], "confidence_score": 0.9,
                    "transformation_classification": "direct"} for item in batch.data.attributes}}}})
        try:
            response = worker.invoke(batch)
        except Exception as exc:
            worker_failures.append(type(exc).__name__)
            return httpx.Response(422, json={"detail": "Worker handoff rejected"}, request=outgoing)
        return httpx.Response(200, json=response.model_dump(mode="json"), request=outgoing)
    if pending > 1:
        client._max_in_flight = 1
    monkeypatch.setattr(httpx.Client, "send", send)
    monkeypatch.setattr("app.core.automap_parallel.prepare_parallel", lambda *args, **kwargs: pytest.fail("scan/reduce"))
    partials = []
    response = client._invoke_with_headers(root, headers={"Sf-Context-Current-User": "ALICE"},
        progress_callback=lambda index, targets, response: partials.append({"batch_index": index,
            "batch_identity": response.meta["batch_identity"], "response": response.model_dump(mode="json")}))
    batch_count = 4 if pending > 1 else 1
    assert len(workers) == batch_count
    assert worker_failures == []
    assert len(harness.state.models) == posts
    assert len(response.result.mappings) == 2 + pending
    assert response.meta["auto_mapping_review"]["preserved_count"] == 2
    assert response.meta["auto_mapping_review"]["newly_mapped_count"] == mapped
    assert response.meta["auto_mapping_review"]["unresolved_count"] == pending - mapped
    from app.core.automap_batch import canonical_model_wire_request
    assert response.context.workspace_context == canonical_model_wire_request(req).context.workspace_context
    assert "PRIVATE_" not in response.model_dump_json()
    for outgoing in harness.state.models:
        assert b"PRIVATE_" not in outgoing.content
        packet = unpack(json.loads(outgoing.content)["messages"])
        assert {item["target_attribute"] for item in packet["data"]["attributes"]} <= {f"COL_{index}" for index in range(2, 2 + pending)}
        assert packet["protocol"] == "auto_map_fast_path_v1"
        assert packet["retrieved_auto_map_context"]
    if mapped:
        assert response.result.mappings["COL_2"].source_attributes == ["src.COL_2"]
        assert response.meta["auto_map_retrieval"]["auto_map_fast_path"]["global_admission"] is True
        assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    elif outcome in {"lost_ack", "invalid_wire"}:
        assert any(slot["STATE"] != "FREE" for slot in harness.database.slots)
    elif outcome == "http429":
        assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    assert response.meta["auto_mapping_dispatch"]["failed_batches"] == ([] if mapped else [0])
    assert len(partials) == batch_count
    workers_before_resume = len(workers)
    resumed = client._invoke_with_headers(root, headers={}, resume_partials=partials)
    assert resumed.meta["auto_mapping_dispatch"]["resumed_batch_indices"] == list(range(batch_count))
    assert len(harness.state.models) == posts
    assert len(workers) == workers_before_resume


def test_acceptance_clock_charges_queue_and_expired_resolution_never_renews(monkeypatch):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    captured = []
    monkeypatch.setattr(client, "_forward_headers", lambda *args: {})
    monkeypatch.setattr(client, "_persist_job", lambda record, **kwargs: captured.append(deepcopy(record)))
    monkeypatch.setattr(client, "_launch_job_runner", lambda *args, **kwargs: None)
    accepted = client._start_job(request_context(), authored(pending=1), session=object(), prepare=True)
    try:
        envelope = captured[0]["request_envelope"]
        clock = envelope["meta"]["_automap_acceptance"]
        assert 899 < clock["deadline_at"] - time.time() <= module._RESOLUTION_DEADLINE_SECONDS
        monkeypatch.setattr(module.time, "time", lambda: clock["deadline_at"] + 30)
        restored = client._restore_acceptance(STTMBuilderEnvelopeRequest.model_validate(envelope))
        frozen = client._freeze_resolution(restored)
        assert frozen.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"] == clock["deadline_at"]
        assert client._pending_resolution_request(frozen).meta["_automap_deadline"] < time.time()
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)


def test_parent_discovers_pending_once_and_preserves_prepared_graph(monkeypatch):
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import AgentExecutionContextV2
    client = proxy(SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    values, discovery = [], []
    def load(self, project_id):
        values.append(project_id)
        return []
    def prepare(self, req):
        req.context.relation_graph.nodes[0].output_columns.append({"name": "FRESH"})
        req.context.execution_context = AgentExecutionContextV2(context_key="parent")
        return req
    def discover(self, req, targets):
        discovery.append(list(targets))
        return {target: {"diagnostics": {"status": "no_match"}} for target in targets}
    monkeypatch.setattr(STTMBuilderService, "_load_project_firm_values", load)
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", prepare)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence", discover)
    root = client._prepare_job_request(authored(pending=2), session=object(), owner="ALICE", headers={})
    assert values == ["501"] and discovery == [["COL_2", "COL_3"]]
    assert root.context.relation_graph.nodes[0].output_columns[-1] == {"name": "FRESH"}
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(root.model_dump(mode="json")))
    assert restored.meta[module._RESOLUTION_PLAN_KEY]["handoff"]["discovery"]
    restored.meta[module._RESOLUTION_PLAN_KEY]["handoff"]["discovery"].clear()
    with pytest.raises(SnowflakeAgentError, match="handoff"):
        client._pending_resolution_request(restored)


def test_project_value_loader_uses_existing_parameterized_metadata_only():
    from app.core.sttm_builder import STTMBuilderService
    queries = []
    def sql(query, params):
        queries.append((query, params))
        return SimpleNamespace(collect=lambda: [{"ATTRIBUTE_NAME": "Firm", "ATTRIBUTE_TYPE": "VARCHAR", "ATTRIBUTE_VALUE": "Current"}])
    builder = STTMBuilderService.__new__(STTMBuilderService)
    builder._settings = Settings(_env_file=None, SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    builder._session = SimpleNamespace(sql=sql)
    values = builder._load_project_firm_values("501")
    assert values[0].attribute_value == "Current"
    assert len(queries) == 1 and queries[0][1] == ["501"]
    assert queries[0][0].strip().startswith("SELECT")
    assert "WHERE TO_VARCHAR(PROJECT_ID) = ?" in queries[0][0]


def test_expired_accepted_job_skips_values_semantic_preparation_and_search(monkeypatch):
    from app.core.sttm_builder import STTMBuilderService
    client = proxy()
    req = client._accept_resolution(authored(pending=1))
    deadline = time.time() - 1
    req.meta["_automap_acceptance"].update(deadline_at=deadline, accepted_at=deadline - module._RESOLUTION_DEADLINE_SECONDS)
    monkeypatch.setattr(STTMBuilderService, "_load_project_firm_values", deny)
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", deny)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence", deny)
    result = client._prepare_job_request(req, session=object(), owner="ALICE", headers={})
    assert result.meta[module._RESOLUTION_PLAN_KEY]["deadline_at"] == deadline


def test_case_colliding_targets_are_rejected_before_resolution(monkeypatch):
    client = proxy()
    req = authored(pending=1)
    req.data.attributes[1].target_attribute = "col_0"
    monkeypatch.setattr(deterministic, "resolve_authored_targets", deny)
    with pytest.raises(HTTPException, match="unique targets"):
        client._freeze_resolution(req)


def test_durable_fast_runner_does_not_retry_typeerror_after_dispatch(monkeypatch):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    root = client._freeze_resolution(authored(pending=1))
    job_id = str(uuid.uuid4())
    record = {"job_id": job_id, "owner": "ALICE", "status": "queued", "state_version": 0,
        "request_envelope": root.model_dump(mode="json"), "partial_responses": []}
    finished, calls = threading.Event(), []
    def invoke(*args, **kwargs):
        calls.append(kwargs)
        raise TypeError("progress_callback failed after dispatch")
    monkeypatch.setattr(client, "_invoke_with_headers", invoke)
    monkeypatch.setattr(client, "_persist_job", lambda *args, **kwargs: None)
    monkeypatch.setattr(client, "_open_job_client", lambda *args: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(client, "_claim_job_lease", lambda *args, **kwargs: True)
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS[job_id] = record
    try:
        client._launch_job_runner(job_id, req=root, owner="ALICE", headers={}, record=record)
        assert finished.wait(3)
        assert len(calls) == 1
        assert module._AUTO_MAP_JOBS[job_id]["status"] == "failed"
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(job_id, None)


def enriched_wire_request(persona="VIEWER", *, project_id="501"):
    from app.guardrails.config.loader import load_config
    from app.guardrails.runtime.preflight import PreflightGuard
    req = authored(pending=1)
    raw, _ = PreflightGuard(load_config(settings=proxy()._settings)).apply_to_sttm_request(
        req.model_dump(mode="json"), trace_id="wire-audit", persona=persona)
    raw["context"]["project_id"] = project_id
    raw["actor"] = {"user_id": "ALICE", "role": "CALLER_ROLE"}
    raw["meta"]["review_metadata"] = {"enabled": False, "revision": 0, "optional": None, "unknown": "retain"}
    raw["context"]["semantic_context"] = [{"table": raw["context"]["source_tables"][0], "semantic_model": {
        "attributes": [{"name": "COL_2", "data_type": "VARCHAR", "nullable": False,
            "constraints": [{"type": "NOT_NULL", "authority": "catalog"}],
            "value_profile": {"sample_values": ["PRIVATE_SEMANTIC_SAMPLE"], "distinct_count": 7, "null_fraction": 0.0}}],
        "pending_reviews": [{"id": "meaning-review", "accepted": False, "priority": 1, "note": None}]}}]
    raw["context"]["datahub_context"] = {"preview_rows": [{"value": "PRIVATE_DATAHUB_SAMPLE"}],
        "pending_reviews": [{"id": "catalog-review", "required": True}], "authority": "catalog", "optional": None}
    raw["context"]["derived_source_lineage"] = [{"id": "lineage", "raw_rows": ["PRIVATE_LINEAGE_SAMPLE"],
        "sql": "SELECT COL_2 FROM DB.SRC.SOURCE", "evidence_id": "lineage-evidence", "optional": None}]
    raw["context"]["workspace_context"]["mapping_artifacts"] = [{"artifact_id": "previous-output",
        "result": {"mapped": 1, "original_request": {"sample_values": ["PRIVATE_ECHO_SAMPLE"]}}}]
    raw["context"]["workspace_context"]["assistant_memory"] = {"pending_reviews": [{"id": "manual-review", "accepted": False}]}
    raw["context"]["execution_context"] = {"context_key": "wire-audit", "evidence_ids": ["lineage-evidence"],
        "semantic_bundle_summary": {"reviewed": False, "revision": 1, "optional": None}}
    return STTMBuilderEnvelopeRequest.model_validate(raw)


@pytest.mark.parametrize("persona", ["VIEWER", "PUBLISHER"])
def test_parent_governs_discovery_freezes_typed_wire_and_preserves_durable_original(monkeypatch, persona):
    import json
    from app.core.sttm_builder import STTMBuilderService
    from app.core.automap_batch import canonical_model_wire_request, validate_fast_request
    from app.core.automap_policy import preparation_hash
    from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
    req = enriched_wire_request(persona)
    before = req.model_dump(mode="json")
    client = proxy(SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    events = []
    def load(self, project_id):
        events.append("values")
        return []
    def prepare(self, request):
        events.append("prepare")
        return request
    original_guard = ModelBoundaryGuard.assert_model_target_allowed
    def guard(self, **kwargs):
        events.append("guard")
        assert kwargs["decision"].persona == persona
        return original_guard(self, **kwargs)
    def discover(self, request, targets):
        events.append("discovery")
        assert events == ["values", "prepare", "guard", "discovery"]
        assert "PRIVATE_" not in request.model_dump_json()
        assert request.context.semantic_context[0].semantic_model["pending_reviews"]
        return {target: {"diagnostics": {"status": "no_match"}} for target in targets}
    monkeypatch.setattr(STTMBuilderService, "_load_project_firm_values", load)
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", prepare)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence", discover)
    monkeypatch.setattr(ModelBoundaryGuard, "assert_model_target_allowed", guard)
    root = client._prepare_job_request(req, session=SimpleNamespace(sql=deny), owner="ALICE",
        headers={"X-Workbench-OAuth-Role": "CALLER_ROLE"})
    assert root.context.semantic_context == req.context.semantic_context
    assert root.context.workspace_context == req.context.workspace_context
    assert req.model_dump(mode="json") == before
    durable = root.model_dump(mode="json")
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(json.loads(json.dumps(durable))))
    pending = client._pending_resolution_request(restored)
    wire, diagnostics = client._budget_batch_request(pending)
    serialized = STTMBuilderEnvelopeRequest.model_validate(json.loads(json.dumps(wire.to_worker_payload())))
    validate_fast_request(serialized, client._settings)
    assert serialized.context.prepared_context_hash == preparation_hash(serialized.context)
    assert canonical_model_wire_request(serialized).model_dump(mode="json") == serialized.model_dump(mode="json")
    assert serialized.context.workspace_context.mapping_artifacts == []
    assert serialized.context.artifact_refs[0]["content_omitted"] is True
    assert serialized.meta["review_metadata"] == before["meta"]["review_metadata"]
    profile = serialized.context.semantic_context[0].semantic_model["attributes"][0]
    assert profile["nullable"] is False and profile["constraints"] == [{"type": "NOT_NULL", "authority": "catalog"}]
    assert profile["value_profile"] == {"sample_values": [], "distinct_count": 7, "null_fraction": 0.0}
    assert serialized.context.workspace_context.assistant_memory == req.context.workspace_context.assistant_memory
    assert diagnostics["compacted"] is False
    assert "PRIVATE_" not in serialized.model_dump_json()
    assert "PRIVATE_" not in client._complete_resolution_response(root, _response(pending)).model_dump_json()
    assert "PRIVATE_" in json.dumps(durable)
    assert events == ["values", "prepare", "guard", "discovery"]


@pytest.mark.parametrize("mutation", ["graph", "sql", "target", "evidence", "deadline", "caller", "policy", "profile_authority",
    "review", "metadata", "scalar_type", "discovery", "requirements"])
@pytest.mark.parametrize("boundary", ["proxy", "worker"])
def test_frozen_wire_rejects_every_non_projection_mutation_before_http(monkeypatch, mutation, boundary):
    from app.core.automap_policy import preparation_hash
    client = proxy()
    req = enriched_wire_request()
    req.context.prepared_context_hash = preparation_hash(req.context)
    root = client._bind_fast_handoff(client._freeze_resolution(req), discovery={"COL_2": {"diagnostics": {"status": "no_match"}}})
    pending = client._pending_resolution_request(root)
    if mutation == "graph":
        pending.context.relation_graph.nodes[0].alias = "changed"
    elif mutation == "sql":
        pending.context.workspace_context.raw_mapping_sql = "SELECT 1"
    elif mutation == "target":
        pending.data.attributes[0].target_description = "changed"
    elif mutation == "evidence":
        pending.context.execution_context.evidence_ids = ["foreign"]
    elif mutation == "deadline":
        pending.meta["_automap_deadline"] += 1
    elif mutation == "caller":
        pending.actor.user_id = "BOB"
    elif mutation == "policy":
        pending.meta["guardrails"]["policy"]["allow_sample_rows"] = True
    elif mutation == "profile_authority":
        pending.context.semantic_context[0].semantic_model["attributes"][0]["constraints"] = []
    elif mutation == "review":
        pending.context.datahub_context["pending_reviews"].clear()
    elif mutation == "metadata":
        pending.meta["review_metadata"]["unknown"] = "changed"
    elif mutation == "scalar_type":
        pending.context.execution_context.semantic_bundle_summary["reviewed"] = 0
    elif mutation == "discovery":
        pending.meta["_automap_fast_handoff"]["discovery"]["COL_2"]["diagnostics"]["status"] = "changed"
    else:
        pending.meta["_automap_fast_handoff"]["target_requirements"]["COL_2"]["target_description"] = "changed"
    monkeypatch.setattr(httpx.Client, "send", deny)
    with pytest.raises(ValueError, match="frozen|requirements|deadline"):
        if boundary == "proxy":
            client._invoke_batch(pending, headers={}, batch_index=0)
        else:
            from app.core.sttm_builder import STTMBuilderService
            worker = STTMBuilderService.__new__(STTMBuilderService)
            worker._settings = client._settings
            worker.invoke(pending)


@pytest.mark.parametrize("persona", ["VIEWER", "PUBLISHER"])
def test_noncanary_legacy_transport_and_real_governor_do_not_leak_enrichment(monkeypatch, persona):
    import json
    from app.core.sttm_builder import STTMBuilderService
    client = proxy()
    req = client._accept_resolution(enriched_wire_request(persona, project_id="noncanary"))
    before = req.model_dump(mode="json")
    seen = []
    def send(http, outgoing, **kwargs):
        assert outgoing.url.host == "worker.internal"
        assert b"PRIVATE_" not in outgoing.content
        incoming = STTMBuilderEnvelopeRequest.model_validate(json.loads(outgoing.content))
        assert "auto_map_fast_path" not in incoming.meta
        decision = STTMBuilderService._build_governance_decision(incoming)
        governed = STTMBuilderService._govern_request_for_model(incoming, decision)
        assert "PRIVATE_" not in governed.model_dump_json()
        seen.append(governed)
        return httpx.Response(200, json=_response(governed).model_dump(mode="json"), request=outgoing)
    monkeypatch.setattr(httpx.Client, "send", send)
    result = client._invoke_batch(req, headers={}, batch_index=0)
    assert len(seen) == 1 and "PRIVATE_" not in result.model_dump_json()
    merged = client._invoke_with_headers(req, headers={})
    assert len(seen) > 1 and "PRIVATE_" not in merged.model_dump_json()
    assert req.model_dump(mode="json") == before


def test_allowed_sample_policy_is_preserved_and_hash_still_binds_sample_authority():
    from app.core.automap_policy import preparation_hash
    from app.core.automap_batch import validate_fast_request
    client = proxy()
    req = enriched_wire_request("ADMIN")
    req.context.prepared_context_hash = preparation_hash(req.context)
    root = client._bind_fast_handoff(client._freeze_resolution(req))
    pending = client._pending_resolution_request(root)
    assert "PRIVATE_SEMANTIC_SAMPLE" in pending.model_dump_json()
    validate_fast_request(pending, client._settings)
    pending.context.semantic_context[0].semantic_model["attributes"][0]["value_profile"]["sample_values"] = ["changed"]
    pending.context.prepared_context_hash = preparation_hash(pending.context)
    with pytest.raises(ValueError, match="frozen"):
        validate_fast_request(pending, client._settings)


def test_exact_worker_pattern_reference_and_nullable_metadata_survive_canonical_roundtrip():
    import json
    from app.core.automap_policy import preparation_hash
    from app.core.automap_batch import canonical_model_wire_request, validate_fast_request
    from app.schema.sttm_builder import LearningContext
    client = proxy()
    req = enriched_wire_request()
    patterns = [{"pattern_id": "exact-recipe", "approved": False, "revision": 0, "optional": None,
        "rule": "COALESCE(src.COL_2, 'Exact Case')"}]
    req.context.learning_context = LearningContext(target_mapping_patterns=deepcopy(patterns))
    req.context.execution_context.target_mapping_patterns = deepcopy(patterns)
    req.context.prepared_context_hash = preparation_hash(req.context)
    root = client._bind_fast_handoff(client._freeze_resolution(req))
    pending = client._pending_resolution_request(root)
    raw = pending.to_worker_payload()
    assert raw["meta"]["execution_patterns_from_learning_v1"] is True
    assert "target_mapping_patterns" not in raw["context"]["execution_context"]
    incoming = STTMBuilderEnvelopeRequest.model_validate(json.loads(json.dumps(raw)))
    validate_fast_request(incoming, client._settings)
    assert incoming.context.learning_context.target_mapping_patterns == patterns
    assert incoming.context.execution_context.target_mapping_patterns == patterns
    assert canonical_model_wire_request(incoming).model_dump(mode="json") == pending.model_dump(mode="json")


def test_parent_model_guard_denial_stops_before_discovery_or_freeze(monkeypatch):
    from app.core.sttm_builder import STTMBuilderService
    from app.core.exceptions import AuthorizationError
    from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
    client = proxy(SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    monkeypatch.setattr(STTMBuilderService, "_load_project_firm_values", lambda *args: [])
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", lambda self, request: request)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence", deny)
    monkeypatch.setattr(client, "_bind_fast_handoff", deny)
    def reject(*args, **kwargs):
        raise AuthorizationError("Model target denied")
    monkeypatch.setattr(ModelBoundaryGuard, "assert_model_target_allowed", reject)
    with pytest.raises(AuthorizationError, match="denied"):
        client._prepare_job_request(enriched_wire_request(), session=SimpleNamespace(sql=deny), owner="ALICE", headers={})


def test_real_parent_prepare_restore_proxy_wire_and_governed_worker_reuse_37_target_discovery(monkeypatch):
    from app.core.sttm_builder import STTMBuilderService
    from app.core.automap_batch import validate_fast_request
    from tests.unit.core.test_automap_fast_batch import governed_parent_discovery

    worker, req = governed_parent_discovery()
    discovery = deepcopy(req.meta.pop("_automap_fast_handoff")["discovery"])
    req.meta["auto_map_resolution_mode"] = "preserve_and_complete"
    client = proxy(AUTOMAP_CONTEXT_BATCH_COUNT=4, SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    events = []

    def discover(self, current, targets):
        events.append("parent_discovery")
        assert current.actor == req.actor and current.context.current_role == "SAME_CALLER_ROLE"
        assert current.meta["guardrails"]["persona"] == "ADMIN"
        assert len(targets) == 37
        return deepcopy(discovery)

    monkeypatch.setattr(STTMBuilderService, "_load_project_firm_values", lambda *args: [])
    monkeypatch.setattr(STTMBuilderService, "prepare_auto_map_request", lambda self, current: current)
    monkeypatch.setattr(STTMBuilderService, "_discover_auto_map_batch_evidence", discover)
    headers = {"X-Workbench-OAuth-Role": "SAME_CALLER_ROLE", "X-Workbench-OAuth-User": "OFFLINE_CALLER"}
    root = client._prepare_job_request(req, session=SimpleNamespace(sql=deny), owner="OFFLINE_CALLER", headers=headers)
    frozen = root.model_dump(mode="json")
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(json.loads(json.dumps(frozen, sort_keys=True))))
    responses = []

    def send(http, outgoing, **kwargs):
        assert outgoing.headers["X-Workbench-OAuth-Role"] == "SAME_CALLER_ROLE"
        assert outgoing.headers["X-Workbench-OAuth-User"] == "OFFLINE_CALLER"
        incoming = STTMBuilderEnvelopeRequest.model_validate(json.loads(outgoing.content))
        assert incoming.actor == req.actor and incoming.context.current_role == "SAME_CALLER_ROLE"
        validate_fast_request(incoming, worker._settings)
        response = worker.invoke(incoming)
        responses.append(response)
        return httpx.Response(200, json=response.model_dump(mode="json"), request=outgoing)

    monkeypatch.setattr(httpx.Client, "send", send)
    response = client._invoke_with_headers(restored, headers=headers)
    assert events == ["parent_discovery"]
    assert sorted(item.meta["auto_map_retrieval"]["target_count"] for item in responses) == [9, 9, 9, 10]
    assert len(worker._agent.calls) == 4
    assert response.meta["auto_mapping_dispatch"]["failed_batches"] == []
    assert len(response.result.mappings) == 37
    for result in responses:
        retrieval = result.meta["auto_map_retrieval"]
        assert retrieval["parent_discovery"]["target_count"] == 37
        assert retrieval["parent_discovery"]["search_work"]["query_count"] == 74
        assert not any(retrieval["search_work"].values())
    assert root.model_dump(mode="json") == frozen
    assert frozen["meta"][module._RESOLUTION_PLAN_KEY]["handoff"]["discovery"] == discovery
