import logging
import hashlib
import math
import time
from contextlib import contextmanager
from dataclasses import dataclass
from threading import BoundedSemaphore, Lock
from typing import Any, Optional

import snowflake.connector
from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.exceptions import AuthenticationError, SnowflakeConnectionError
from app.core.warehouse_routing import (
    WarehouseWorkload,
    connection_session_parameters,
    resolve_warehouse,
)

logger = logging.getLogger(__name__)

_SERVICE_TOKEN_PATH = "/snowflake/session/token"
_LOCAL_CLIENT_CACHE: dict[str, "SnowflakeClient"] = {}
_LOCAL_CLIENT_LAST_VALIDATED: dict[str, float] = {}
_LOCAL_CLIENT_LOCK = Lock()
_LOCAL_CLIENT_KEY_LOCKS: dict[str, Any] = {}
_LOCAL_SESSION_WAIT_SECONDS = 20.0
_LOCAL_TRANSACTION_POOLS: dict[str, "SnowflakeSessionLeasePool"] = {}
_LOCAL_CONNECTOR_CACHE: dict[str, snowflake.connector.SnowflakeConnection] = {}
_LOCAL_CONNECTOR_LAST_VALIDATED: dict[str, float] = {}
_LOCAL_CONNECTOR_LOCK = Lock()
_LOCAL_CONNECTOR_KEY_LOCKS: dict[str, Any] = {}
_USER_CLIENT_CACHE: dict[str, tuple["SnowflakeClient", float]] = {}
_USER_CLIENT_LOCK = Lock()


@dataclass
class RestSessionContext:
    token: str
    host: str


def _read_token_file(token_path: str) -> str | None:
    try:
        with open(token_path) as f:
            token = f.read().strip()
    except OSError:
        return None
    return token or None


def get_service_token() -> str:
    """Read this container's own SPCS service OAuth token."""
    token = _read_token_file(_SERVICE_TOKEN_PATH)
    if token:
        logger.debug("Using SPCS service token from %s", _SERVICE_TOKEN_PATH)
        return token

    raise SnowflakeConnectionError(
        f"Cannot read the SPCS service token from {_SERVICE_TOKEN_PATH}"
    )


def get_caller_oauth_token(user_token: str) -> str:
    """
    Resolve the OAuth token to use for caller-rights sessions.

    Snowflake execute-as-caller services authenticate the user's session with
    a combined OAuth token in the form <service_token>.<ingress_user_token>.
    """
    if not user_token or not user_token.strip():
        raise AuthenticationError(
            "Sf-Context-Current-User-Token header is absent — "
            "request must arrive through SPCS ingress"
        )

    return f"{get_service_token()}.{user_token.strip()}"


def get_effective_oauth_token(settings: Settings, user_token: str | None) -> str:
    if settings.uses_custom_oauth and (user_token or "").strip():
        return (user_token or "").strip()
    if settings.spcs_execute_as_caller_enabled:
        return get_caller_oauth_token((user_token or "").strip())
    return get_service_token()


def get_runtime_snowflake_host(settings: Settings) -> str:
    return _normalize_host(settings.resolved_snowflake_host, settings.snowflake_account)


def _oauth_base_kwargs(
    settings: Settings,
    *,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "authenticator": "oauth",
    }
    if settings.snowflake_account:
        kwargs["account"] = settings.snowflake_account
    if settings.resolved_snowflake_host:
        kwargs["host"] = settings.resolved_snowflake_host
    warehouse = resolve_warehouse(settings, workload)
    if warehouse:
        kwargs["warehouse"] = warehouse
    if settings.snowflake_database:
        kwargs["database"] = settings.snowflake_database
    if settings.snowflake_schema:
        kwargs["schema"] = settings.snowflake_schema
    if role:
        kwargs["role"] = role
    kwargs["session_parameters"] = connection_session_parameters(settings, workload)
    return kwargs


def _caller_oauth_attempts(
    settings: Settings,
    user_token: str,
    *,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> list[tuple[str, dict[str, Any]]]:
    base = _oauth_base_kwargs(settings, role=role, workload=workload)
    attempts: list[tuple[str, dict[str, Any]]] = []

    if settings.uses_custom_oauth:
        normalized_user_token = (user_token or "").strip()
        if normalized_user_token:
            attempts.append(
                (
                    "oauth_user_token",
                    {**base, "token": normalized_user_token},
                )
            )
    elif settings.spcs_execute_as_caller_enabled:
        normalized_user_token = (user_token or "").strip()
        if normalized_user_token:
            attempts.append(
                (
                    "combined_service_user_token",
                    {**base, "token": get_caller_oauth_token(normalized_user_token)},
                )
            )
    else:
        attempts.append(
            (
                "service_oauth_token",
                {**base, "token": get_service_token()},
            )
        )

    deduped: list[tuple[str, dict[str, Any]]] = []
    seen: set[tuple[tuple[str, str], ...]] = set()
    for label, config in attempts:
        signature = tuple(sorted((key, str(value)) for key, value in config.items()))
        if signature in seen:
            continue
        seen.add(signature)
        deduped.append((label, config))
    return deduped


def _create_session_with_attempts(
    attempts: list[tuple[str, dict[str, Any]]],
) -> Session:
    errors: list[str] = []
    for label, config in attempts:
        try:
            session = Session.builder.configs(config).create()
            logger.info("Snowpark caller-rights session created using %s", label)
            return session
        except Exception as exc:
            logger.warning("Snowpark caller-rights attempt %s failed: %s", label, exc)
            errors.append(f"{label}: {exc}")
    raise SnowflakeConnectionError(
        "Failed to create Snowpark session via caller-rights attempts: "
        + " | ".join(errors)
    )


def _connect_with_attempts(
    attempts: list[tuple[str, dict[str, Any]]],
) -> snowflake.connector.SnowflakeConnection:
    errors: list[str] = []
    for label, config in attempts:
        try:
            connection = snowflake.connector.connect(**config)
            logger.info("Snowflake caller-rights connector created using %s", label)
            return connection
        except Exception as exc:
            logger.warning("Snowflake caller-rights connector attempt %s failed: %s", label, exc)
            errors.append(f"{label}: {exc}")
    raise SnowflakeConnectionError(
        "Failed to create Snowflake connection via caller-rights attempts: "
        + " | ".join(errors)
    )


def build_caller_token(settings: Settings, user_token: str) -> str:
    """
    Resolve the OAuth token used for REST-style Snowflake calls.

    In execute-as-caller ingress mode this is the combined
    ``<service_token>.<ingress_user_token>`` token.
    In custom OAuth mode this is the raw Snowflake OAuth access token.
    In temporary service-auth mode this falls back to the service token only.
    """
    token = get_effective_oauth_token(settings, user_token)
    logger.debug("Resolved Snowflake OAuth token for SPCS request (length=%d)", len(token))
    return token


def _direct_connection_kwargs(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> dict[str, Any]:
    if not settings.snowflake_user:
        raise SnowflakeConnectionError(
            "Local development auth is enabled, but SNOWFLAKE_USER is not configured."
        )

    kwargs: dict[str, Any] = {
        "account": settings.snowflake_account,
        "user": settings.snowflake_user,
    }
    if settings.normalized_snowflake_authenticator == "programmatic_access_token":
        if not settings.snowflake_password:
            raise SnowflakeConnectionError("Explicit PAT authentication requires the configured local credential.")
        kwargs.update(authenticator="PROGRAMMATIC_ACCESS_TOKEN", token=settings.snowflake_password)
    elif settings.local_dev_uses_externalbrowser:
        kwargs["authenticator"] = "externalbrowser"
    else:
        if not settings.snowflake_password:
            raise SnowflakeConnectionError(
                "Local development auth is enabled, but SNOWFLAKE_PASSWORD is not configured."
            )
        kwargs["password"] = settings.snowflake_password

    warehouse = resolve_warehouse(settings, workload)
    if warehouse:
        kwargs["warehouse"] = warehouse
    if settings.snowflake_database:
        kwargs["database"] = settings.snowflake_database
    if settings.snowflake_schema:
        kwargs["schema"] = settings.snowflake_schema
    effective_role = role or settings.snowflake_role
    if effective_role:
        kwargs["role"] = effective_role
    if settings.resolved_snowflake_host:
        kwargs["host"] = settings.resolved_snowflake_host
    kwargs["session_parameters"] = connection_session_parameters(settings, workload)
    return kwargs


def using_local_dev_auth(settings: Settings, user_token: str | None = None) -> bool:
    return settings.local_dev_auth_enabled and not (user_token or "").strip()


def _normalize_host(host: str, account: str) -> str:
    resolved_host = (host or "").strip().replace("_", "-").lower()
    if resolved_host.endswith(".snowflakecomputing.com"):
        return resolved_host

    normalized_account = (account or "").strip().replace("_", "-").lower()
    if normalized_account.endswith(".snowflakecomputing.com"):
        return normalized_account
    if normalized_account:
        return f"{normalized_account}.snowflakecomputing.com"
    return resolved_host


def rest_session_context_from_session(session: Session) -> RestSessionContext:
    """Extract REST credentials from an already-held Snowpark session."""
    server_connection = getattr(session, "_conn", None)
    connector_connection = getattr(server_connection, "_conn", None) if server_connection else None
    rest = getattr(connector_connection, "_rest", None) if connector_connection else None
    token = getattr(rest, "_token", None) if rest else None
    if not token:
        raise SnowflakeConnectionError(
            "Failed to extract the Snowflake connector session token from the active session."
        )
    host = _normalize_host(
        getattr(connector_connection, "host", ""),
        getattr(connector_connection, "account", ""),
    )
    if not host:
        raise SnowflakeConnectionError(
            "Failed to determine the Snowflake host from the active session."
        )
    return RestSessionContext(token=token, host=host)


def _local_cache_key(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> str:
    effective_role = role or settings.snowflake_role or ""
    return "|".join(
        [
            settings.snowflake_account or "",
            settings.snowflake_user or "",
            effective_role,
            workload.value,
            resolve_warehouse(settings, workload),
            settings.snowflake_database or "",
            settings.snowflake_schema or "",
            "externalbrowser" if settings.local_dev_uses_externalbrowser else "password",
        ]
    )


@contextmanager
def _local_session_singleflight(key: str, locks: dict, registry_lock: Any):
    # Authentication/health I/O must not hold the registry lock: an AUTOMAP
    # browser login must never block an already authenticated CONTROL request.
    with registry_lock:
        key_lock = locks.setdefault(key, Lock())
    started = time.monotonic()
    if not key_lock.acquire(timeout=_LOCAL_SESSION_WAIT_SECONDS):
        raise SnowflakeConnectionError(
            "Snowflake session initialization is still in progress for this workload. "
            "Complete any pending sign-in, then retry."
        )
    try:
        yield
    finally:
        key_lock.release()
        logger.info("Local Snowflake session acquisition finished elapsed_ms=%.1f", (time.monotonic() - started) * 1000)


def get_local_cached_client(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> "SnowflakeClient":
    key = _local_cache_key(settings, role, workload)
    with _local_session_singleflight(key, _LOCAL_CLIENT_KEY_LOCKS, _LOCAL_CLIENT_LOCK):
        client = _LOCAL_CLIENT_CACHE.get(key)
        if client is not None:
            health_interval = max(
                0, int(settings.snowflake_session_healthcheck_interval_seconds)
            )
            if health_interval == 0 or (
                time.monotonic() - _LOCAL_CLIENT_LAST_VALIDATED.get(key, 0.0)
                < health_interval
            ):
                return client
            try:
                client.session.sql("SELECT 1").collect()
                _LOCAL_CLIENT_LAST_VALIDATED[key] = time.monotonic()
                return client
            except Exception:
                try:
                    client.close()
                except Exception:
                    logger.debug("Failed to close stale cached Snowpark session", exc_info=True)
                _LOCAL_CLIENT_CACHE.pop(key, None)
                _LOCAL_CLIENT_LAST_VALIDATED.pop(key, None)

        client = SnowflakeClient(
            settings=settings,
            user_token="",
            role=role,
            workload=workload,
        )
        _LOCAL_CLIENT_CACHE[key] = client
        _LOCAL_CLIENT_LAST_VALIDATED[key] = time.monotonic()
        return client


def _oauth_user_cache_key(
    settings: Settings,
    user_token: str,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> str:
    token_fingerprint = hashlib.sha256(user_token.encode("utf-8")).hexdigest()
    effective_role = role or settings.snowflake_role or ""
    return "|".join(
        [
            token_fingerprint,
            effective_role,
            workload.value,
            resolve_warehouse(settings, workload),
            settings.snowflake_database or "",
            settings.snowflake_schema or "",
            settings.resolved_snowflake_host or "",
            settings.snowflake_account or "",
        ]
    )


def get_oauth_cached_client(
    settings: Settings,
    user_token: str,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> "SnowflakeClient":
    """
    Reuse short-lived Snowpark sessions for the same signed-in OAuth user/role.

    In SPCS, establishing a fresh OAuth Snowpark session can cost many seconds,
    which made metadata endpoints feel slow even when the SQL itself was tiny.
    The cache stores only a token fingerprint in the key and keeps the live
    connector object in memory for the current service process.
    """
    normalized_token = (user_token or "").strip()
    ttl_seconds = max(0, int(settings.snowflake_user_session_cache_ttl_seconds))
    if not normalized_token or ttl_seconds <= 0:
        return SnowflakeClient(
            settings=settings,
            user_token=normalized_token,
            role=role,
            workload=workload,
        )

    key = _oauth_user_cache_key(settings, normalized_token, role, workload)
    now = time.monotonic()
    with _USER_CLIENT_LOCK:
        expired_keys = [
            cache_key
            for cache_key, (_client, expires_at) in _USER_CLIENT_CACHE.items()
            if expires_at <= now
        ]
        for cache_key in expired_keys:
            client, _expires_at = _USER_CLIENT_CACHE.pop(cache_key)
            try:
                client.close()
            except Exception:
                logger.debug("Failed to close expired cached OAuth Snowpark session", exc_info=True)

        cached = _USER_CLIENT_CACHE.get(key)
        if cached is not None:
            client, _expires_at = cached
            _USER_CLIENT_CACHE[key] = (client, now + ttl_seconds)
            return client

        client = SnowflakeClient(
            settings=settings,
            user_token=normalized_token,
            role=role,
            workload=workload,
        )
        _USER_CLIENT_CACHE[key] = (client, now + ttl_seconds)
        return client


def _local_connector_cache_key(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> str:
    effective_role = role or settings.snowflake_role or ""
    return "|".join(
        [
            settings.snowflake_account or "",
            settings.snowflake_user or "",
            effective_role,
            workload.value,
            resolve_warehouse(settings, workload),
            settings.snowflake_database or "",
            settings.snowflake_schema or "",
            "externalbrowser" if settings.local_dev_uses_externalbrowser else "password",
            "connector",
        ]
    )


def get_local_cached_connector(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> snowflake.connector.SnowflakeConnection:
    key = _local_connector_cache_key(settings, role, workload)
    with _local_session_singleflight(key, _LOCAL_CONNECTOR_KEY_LOCKS, _LOCAL_CONNECTOR_LOCK):
        connection = _LOCAL_CONNECTOR_CACHE.get(key)
        if connection is not None:
            health_interval = max(
                0, int(settings.snowflake_session_healthcheck_interval_seconds)
            )
            if health_interval == 0 or (
                time.monotonic() - _LOCAL_CONNECTOR_LAST_VALIDATED.get(key, 0.0)
                < health_interval
            ):
                return connection
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                cursor.close()
                _LOCAL_CONNECTOR_LAST_VALIDATED[key] = time.monotonic()
                return connection
            except Exception:
                try:
                    connection.close()
                except Exception:
                    logger.debug("Failed to close stale cached connector session", exc_info=True)
                _LOCAL_CONNECTOR_CACHE.pop(key, None)
                _LOCAL_CONNECTOR_LAST_VALIDATED.pop(key, None)

        connection = snowflake.connector.connect(
            **_direct_connection_kwargs(settings, role, workload)
        )
        _LOCAL_CONNECTOR_CACHE[key] = connection
        _LOCAL_CONNECTOR_LAST_VALIDATED[key] = time.monotonic()
        return connection


@contextmanager
def get_local_cached_connector_context(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
):
    connection = get_local_cached_connector(settings, role, workload)
    yield connection


def get_local_rest_session_context(
    settings: Settings,
    role: Optional[str] = None,
    workload: WarehouseWorkload = WarehouseWorkload.AGENT,
) -> RestSessionContext:
    try:
        connection = get_local_cached_connector(settings, role, workload)
        rest = getattr(connection, "_rest", None)
        token = getattr(rest, "_token", None) if rest else None
        if not token:
            raise SnowflakeConnectionError(
                "Failed to extract the Snowflake connector session token for local REST calls."
            )

        host = _normalize_host(
            getattr(connection, "host", "") or settings.resolved_snowflake_host,
            settings.snowflake_account,
        )
        if not host:
            raise SnowflakeConnectionError(
                "Failed to determine the Snowflake host for local REST calls."
            )

        return RestSessionContext(token=token, host=host)
    except Exception as exc:
        if isinstance(exc, SnowflakeConnectionError):
            raise
        raise SnowflakeConnectionError(
            f"Failed to initialize local Snowflake REST session context: {exc}"
        ) from exc


class SnowflakeClient:
    """
    Wraps a Snowpark Session authenticated as the current application user.

    In ingress-header mode it uses SPCS caller's rights with the combined
    service-token plus ingress-token format. In custom OAuth mode it uses the
    Snowflake OAuth access token directly.
    """

    def __init__(
        self,
        settings: Settings,
        user_token: str | None = None,
        role: Optional[str] = None,
        workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
    ) -> None:
        self._workload = workload
        self._warehouse = resolve_warehouse(settings, workload)
        if using_local_dev_auth(settings, user_token):
            config = _direct_connection_kwargs(settings, role, workload)
            retry_attempts = max(1, settings.snowflake_session_retry_attempts)
            backoff_seconds = max(0.0, settings.snowflake_session_retry_backoff_seconds)
            last_error: Exception | None = None
            for attempt in range(1, retry_attempts + 1):
                try:
                    self._session = Session.builder.configs(config).create()
                    return
                except Exception as exc:
                    last_error = exc
                    if attempt >= retry_attempts:
                        break
                    logger.warning(
                        "Snowpark session creation failed (attempt %s/%s). Retrying in %.1fs: %s",
                        attempt,
                        retry_attempts,
                        backoff_seconds,
                        exc,
                    )
                    if backoff_seconds > 0:
                        time.sleep(backoff_seconds)

            raise SnowflakeConnectionError(
                f"Failed to create Snowpark session: {last_error}"
            ) from last_error
        else:
            attempts = _caller_oauth_attempts(
                settings,
                user_token or "",
                role=role,
                workload=workload,
            )
            if not attempts:
                raise SnowflakeConnectionError("No caller-rights OAuth attempts could be constructed")
            retry_attempts = max(1, settings.snowflake_session_retry_attempts)
            backoff_seconds = max(0.0, settings.snowflake_session_retry_backoff_seconds)
            last_error: Exception | None = None
            for attempt in range(1, retry_attempts + 1):
                try:
                    self._session = _create_session_with_attempts(attempts)
                    if settings.uses_custom_oauth:
                        # Search uses the same user OAuth/public-host contract
                        # as Agent/Analyst. Keep credentials only on this caller
                        # session; never persist or fall back to an owner token.
                        self._session._workbench_search_context = {
                            "host": settings.rest_snowflake_host,
                            "token": user_token,
                            "role": role,
                        }
                    return
                except Exception as exc:
                    last_error = exc
                    if attempt >= retry_attempts:
                        break
                    logger.warning(
                        "Snowpark caller-rights session creation failed (attempt %s/%s). Retrying in %.1fs: %s",
                        attempt,
                        retry_attempts,
                        backoff_seconds,
                        exc,
                    )
                    if backoff_seconds > 0:
                        time.sleep(backoff_seconds)

            raise SnowflakeConnectionError(
                f"Failed to create Snowpark session: {last_error}"
            ) from last_error

    @property
    def session(self) -> Session:
        return self._session

    @property
    def workload(self) -> WarehouseWorkload:
        return self._workload

    @property
    def warehouse(self) -> str:
        return self._warehouse

    def get_rest_session_context(self) -> RestSessionContext:
        return rest_session_context_from_session(self._session)

    def close(self) -> None:
        self._session.close()


def get_local_transaction_pool(settings: Settings, role: str | None,
                               workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
                               *, purpose: str = "request", maximum: int = 2) -> "SnowflakeSessionLeasePool":
    if type(maximum)is not int or not 1<=maximum<=32:
        raise SnowflakeConnectionError("Local caller pool capacity must be in 1..32")
    key = f"{_local_cache_key(settings, role, workload)}:{purpose}:{maximum}"
    with _LOCAL_CLIENT_LOCK:
        pool = _LOCAL_TRANSACTION_POOLS.get(key)
        if pool is None:
            pool = SnowflakeSessionLeasePool(settings=settings, user_token="", role=role,
                                            workload=workload, maximum=maximum)
            _LOCAL_TRANSACTION_POOLS[key] = pool
        return pool


_WRITE_POOLS: dict[str, tuple["SnowflakeSessionLeasePool", float]] = {}
_WRITE_POOLS_LOCK = Lock()
# Separate foreground capacity from slow enrichment and arbitrary execution.
_WRITE_CAPACITY = BoundedSemaphore(16)
_AUTOMAP_RECOVERY_WRITE_CAPACITY = BoundedSemaphore(2)


def close_write_pools() -> None:
    with _WRITE_POOLS_LOCK:
        pools = [pool for pool, _ in _WRITE_POOLS.values()]
        _WRITE_POOLS.clear()
    for pool in pools:
        pool.close()


class SnowflakeLeaseDeadlineExpired(SnowflakeConnectionError):
    """No remaining budget for caller lease acquisition or setup."""


def _lease_remaining(deadline):
    if deadline is None:
        return 5.0
    if type(deadline) not in (int, float) or not math.isfinite(deadline):
        raise SnowflakeConnectionError("Caller lease requires a finite deadline")
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise SnowflakeLeaseDeadlineExpired("Caller lease deadline expired")
    return min(5.0, remaining)


@contextmanager
def caller_write_lease(settings: Settings, user_token: str, role: str | None,
                       workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
                       *, reusable: bool = False, maximum: int = 2, deadline: float | None = None, purpose: str = "request"):
    """Only audited, session-state-neutral operations opt into cross-request reuse.

    ``maximum`` sizes the reusable per-caller pool; callers that fan out must
    request at least their concurrency so workers never wait on each other.
    ``deadline`` is absolute monotonic time: waits and setup SQL use its remaining
    budget. Synchronous connection creation/SQL cannot be forcibly cancelled here;
    checks reject late results, not guarantee a hard wall-clock return. Cleanup
    must still run after expiry and is deliberately not gated by this deadline.
    """
    _lease_remaining(deadline)
    if purpose not in {"request", "automap-recovery"}:
        raise SnowflakeConnectionError("Unrecognized caller pool purpose")
    capacity = _AUTOMAP_RECOVERY_WRITE_CAPACITY if purpose == "automap-recovery" else _WRITE_CAPACITY
    if type(maximum) is not int or not 1 <= maximum <= 8:
        raise SnowflakeConnectionError("Caller lease pool capacity must be in 1..8")
    if not user_token.strip() and not settings.local_dev_auth_enabled:
        raise AuthenticationError("A caller token is required for a write lease")
    if not getattr(settings, "snowflake_write_lease_pool_v1", False):
        client = SnowflakeClient(settings=settings, user_token=user_token, role=role, workload=workload)
        try:
            _lease_remaining(deadline)
            yield client
        finally:
            client.close()
        return
    if not capacity.acquire(timeout=_lease_remaining(deadline)):
        _lease_remaining(deadline)
        raise SnowflakeConnectionError("Write connection capacity is exhausted; retry later")
    try:
        _lease_remaining(deadline)
        if not reusable:
            client = SnowflakeClient(settings=settings, user_token=user_token, role=role, workload=workload)
            try:
                _lease_remaining(deadline)
                yield client
            finally:
                client.close()
            return
        # Authentication is performed by the caller before entering this function.
        # Fingerprints isolate refreshed credentials without retaining them in logs.
        key = (_oauth_user_cache_key(settings, user_token, role, workload) if user_token
               else _local_cache_key(settings, role, workload))
        key = f"{key}:{maximum}" + (":automap-recovery" if purpose == "automap-recovery" else "")
        now = time.monotonic()
        with _WRITE_POOLS_LOCK:
            expired = [key for key, (_, created) in _WRITE_POOLS.items() if now - created >= 120]
            for old_key in expired:
                old_pool, _ = _WRITE_POOLS.pop(old_key)
                old_pool.close()
            if key not in _WRITE_POOLS:
                if len(_WRITE_POOLS) >= 16:
                    oldest = min(_WRITE_POOLS, key=lambda item: _WRITE_POOLS[item][1])
                    old_pool, _ = _WRITE_POOLS.pop(oldest)
                    old_pool.close()
                _WRITE_POOLS[key] = (SnowflakeSessionLeasePool(
                    settings=settings, user_token=user_token, role=role,
                    workload=workload, maximum=maximum), now)
            pool = _WRITE_POOLS[key][0]
        with pool.lease(deadline=deadline) as client:
            yield client
    finally:
        capacity.release()


class SnowflakeSessionLeasePool:
    """Bound independent Snowpark sessions; a session is never shared concurrently."""

    def __init__(
        self,
        *,
        settings: Settings,
        user_token: str | None,
        role: str | None,
        workload: WarehouseWorkload,
        maximum: int,
    ) -> None:
        self._settings = settings
        self._user_token = user_token
        self._role = role
        self._workload = workload
        self._limit = BoundedSemaphore(max(1, maximum))
        self._idle: list[tuple[SnowflakeClient, float, float, tuple]] = []
        self._lock = Lock()
        self._closed = False

    @staticmethod
    def _context(client, *, deadline=None):
        remaining = _lease_remaining(deadline)
        options = {"statement_params": {
            "STATEMENT_TIMEOUT_IN_SECONDS": str(max(1, math.ceil(remaining))), "LOCK_TIMEOUT": "1"}
        } if deadline is not None else {}
        try:
            row = client.session.sql(
                "SELECT CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_SCHEMA()"
            ).collect(**options)[0]
        except Exception:
            _lease_remaining(deadline)
            raise
        _lease_remaining(deadline)
        return tuple(row)

    @contextmanager
    def lease(self, *, deadline: float | None = None):
        started = time.monotonic()
        acquired = self._limit.acquire(timeout=_lease_remaining(deadline))
        if not acquired:
            _lease_remaining(deadline)
            logger.warning("Session lease saturated workload=%s wait_ms=%.1f", self._workload, (time.monotonic() - started) * 1000)
            raise SnowflakeConnectionError("Snowflake session lease capacity is exhausted")
        acquired_at = time.monotonic()
        logger.info("Session lease acquired workload=%s wait_ms=%.1f", self._workload, (acquired_at - started) * 1000)
        client: SnowflakeClient | None = None
        born = time.monotonic()
        baseline = None
        work_succeeded = False
        try:
            _lease_remaining(deadline)
            with self._lock:
                if self._closed:
                    raise SnowflakeConnectionError("Session pool has been retired")
                entry = self._idle.pop() if self._idle else None
            if entry is not None:
                client, born, returned, baseline = entry
                if time.monotonic() - born >= 120 or time.monotonic() - returned >= 30:
                    client.close()
                    client = None
                else:
                    try:
                        if self._context(client, deadline=deadline) != baseline:
                            raise SnowflakeConnectionError("Session context changed")
                    except SnowflakeLeaseDeadlineExpired:
                        raise
                    except Exception:
                        client.close()
                        client = None
            reused = client is not None
            if client is None:
                _lease_remaining(deadline)
                client = SnowflakeClient(
                    settings=self._settings,
                    user_token=self._user_token,
                    role=self._role,
                    workload=self._workload,
                )
                born = time.monotonic()
                baseline = self._context(client, deadline=deadline)
            _lease_remaining(deadline)
            logger.info("Session lease ready workload=%s reused=%s setup_ms=%.1f",
                        self._workload, reused, (time.monotonic() - acquired_at) * 1000)
            yield client
            work_succeeded = True
            # Never commit on return. Only audited state-neutral work may reuse
            # this pool; arbitrary SQL/DDL uses a disposable connection instead.
            try:
                client.session.sql("ROLLBACK").collect()
                clean = self._context(client) == baseline
            except Exception:
                clean = False
            with self._lock:
                if clean and not self._closed and time.monotonic() - born < 120:
                    self._idle.append((client, born, time.monotonic(), baseline))
                    client = None
        finally:
            try:
                if client is not None:
                    try:
                        client.close()
                    except Exception:
                        if not work_succeeded:
                            raise
                        logger.warning("Discarded session failed to close after successful work", exc_info=True)
            finally:
                self._limit.release()
                logger.info("Session lease released workload=%s hold_ms=%.1f", self._workload, (time.monotonic() - acquired_at) * 1000)

    def close(self) -> None:
        with self._lock:
            self._closed = True
            clients, self._idle = self._idle, []
        # Active leases close themselves on return; never interrupt their work.
        for client, *_ in clients:
            try:
                client.close()
            except Exception:
                logger.warning("Failed to close retired idle session", exc_info=True)


def _oauth_connection_kwargs(
    settings: Settings,
    token: str,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "account": settings.snowflake_account,
        "authenticator": "oauth",
        "token": token,
    }
    warehouse = resolve_warehouse(settings, workload)
    if warehouse:
        kwargs["warehouse"] = warehouse
    if settings.snowflake_database:
        kwargs["database"] = settings.snowflake_database
    if settings.snowflake_schema:
        kwargs["schema"] = settings.snowflake_schema
    if settings.resolved_snowflake_host:
        kwargs["host"] = settings.resolved_snowflake_host
    kwargs["session_parameters"] = connection_session_parameters(settings, workload)
    return kwargs


def get_user_connection(
    ingress_user_token: str | None,
    settings: Settings,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> snowflake.connector.SnowflakeConnection:
    if using_local_dev_auth(settings, ingress_user_token):
        if settings.local_dev_uses_externalbrowser:
            return get_local_cached_connector_context(settings, workload=workload)
        return snowflake.connector.connect(
            **_direct_connection_kwargs(settings, workload=workload)
        )
    attempts = _caller_oauth_attempts(
        settings,
        ingress_user_token or "",
        workload=workload,
    )
    if not attempts:
        raise SnowflakeConnectionError("No caller-rights OAuth attempts could be constructed")
    return _connect_with_attempts(attempts)


def get_service_connection(
    settings: Settings,
    workload: WarehouseWorkload = WarehouseWorkload.CONTROL,
) -> snowflake.connector.SnowflakeConnection:
    if settings.local_dev_auth_enabled:
        if settings.local_dev_uses_externalbrowser:
            return get_local_cached_connector_context(settings, workload=workload)
        return snowflake.connector.connect(
            **_direct_connection_kwargs(settings, workload=workload)
        )
    return snowflake.connector.connect(
        **_oauth_connection_kwargs(settings, get_service_token(), workload)
    )
