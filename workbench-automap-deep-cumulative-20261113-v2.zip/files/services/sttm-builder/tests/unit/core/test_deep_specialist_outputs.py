from app.agent_tools.specialists import CortexSpecialistAdapter, SpecialistRequest, SpecialistResponse, SpecialistDecision


def test_batched_specialist_outputs_keep_original_provider_trace_receipts():
    columns = [f'C{index}' for index in range(17)]
    request = SpecialistRequest(run_id='run', step_id='map', project_id='p', sttm_id='s', snapshot_id='snapshot',
        target_contract={'target_table': 'DB.T.TARGET', 'columns': [{'name': name} for name in columns]},
        target_columns=columns, allowed_source_tables=['DB.S.SOURCE'],
        allowed_source_columns={'DB.S.SOURCE': columns}, actor_user_id='user', effective_role='ROLE', tenant_id='tenant')
    adapter = object.__new__(CortexSpecialistAdapter)
    calls = []
    def source(scoped):
        calls.append(list(scoped.target_columns))
        return SpecialistResponse(raw_trace_id=f'provider-{len(calls)}', decisions=[
            SpecialistDecision(target_column=name, decision='mapped', source_columns=[f'DB.S.SOURCE.{name}'],
                confidence=0.4, decision_reason='Actual specialist candidate', mapping_classification='direct')
            for name in scoped.target_columns])
    adapter.source_mapping = source
    source_result, transformation_result = adapter.map_targets(request, max_workers=1, before_call=lambda _: None)
    assert len(calls) == 2
    assert source_result.raw_trace_ids == ['provider-1', 'provider-2']
    assert [decision.target_column for decision in source_result.decisions] == columns
    assert all(decision.confidence == 0.4 and decision.decision == 'mapped' for decision in source_result.decisions)
    assert not transformation_result.decisions


def test_source_mapper_accepts_only_verified_cte_outputs_and_routes_transformations():
    import json
    request = SpecialistRequest(run_id='run', step_id='step', project_id='project', sttm_id='mapping',
        snapshot_id='snapshot', target_contract={}, target_columns=['FULL_NAME', 'MISSING'],
        allowed_source_tables=['DB.S.CUSTOMERS'], allowed_source_columns={'DB.S.CUSTOMERS': ['FIRST_NAME']},
        derived_outputs=[{'id': 'cte-1', 'name': 'active_customers', 'alias': 'active_customers_abc'}],
        compiler_relation_graph={'nodes': [{'relation_id': 'cte-1', 'kind': 'DERIVED_SOURCE',
            'alias': 'active_customers_abc', 'output_columns': [{'name': 'FIRST_NAME'}, {'name': 'LAST_NAME'}]}]},
        actor_user_id='user', effective_role='ROLE', tenant_id='tenant')
    mappings = {'FULL_NAME': {'source_attributes': ['active_customers.FIRST_NAME', 'active_customers.LAST_NAME'],
        'preprocessing_rule': 'Concatenate', 'mapping_mode': 'source', 'confidence_score': .99},
        'MISSING': {'source_attributes': ['active_customers.UNKNOWN'], 'preprocessing_rule': 'Direct',
                    'mapping_mode': 'source', 'confidence_score': .99}}
    result = CortexSpecialistAdapter._parse_source_mapping_response(None, json.dumps({'data': {'result': {'mappings': mappings}}}), request)
    assert result.decisions[0].decision == 'mapped'
    assert result.decisions[0].source_columns == ['ACTIVE_CUSTOMERS.FIRST_NAME', 'ACTIVE_CUSTOMERS.LAST_NAME']
    assert result.decisions[0].requires_transformation is True
    assert result.decisions[1].decision == 'unresolved'
    request.compiler_relation_graph = {}
    denied = CortexSpecialistAdapter._parse_source_mapping_response(None, json.dumps({'data': {'result': {'mappings': mappings}}}), request)
    assert all(decision.decision == 'unresolved' for decision in denied.decisions)


def test_draft_identity_is_run_scoped_and_same_target_mappings_stay_separate():
    from types import SimpleNamespace
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    handler = object.__new__(WorkbenchWorkflowHandlers)
    records = []
    commands = []
    handler._projects = SimpleNamespace(ensure_storage_exists=lambda: None, list_sttms=lambda _: records)
    handler._tool = lambda *_: None
    handler._emit = lambda *_args, **_kwargs: None
    def execute(command, _callback):
        commands.append(command)
        return SimpleNamespace(result={'sttm_id': str(len(commands))})
    handler._commands = SimpleNamespace(execute=execute)
    def run(run_id, key='primary', name='Requested name'):
        return handler.create_mappings({'run_id': run_id, 'project_id': '101',
            'actor_user_id': 'user', 'effective_role': 'ROLE',
            'authorized_target_scope': ['DB.T.TARGET'],
            'mapping_context_package': {'run_id': run_id, 'thread_id': run_id, 'app_user_id': 'user', 'effective_role': 'ROLE', 'workspace': {'source_tables': [{'database': 'DB', 'schema': 'S', 'table': 'SOURCE'}]}},
            'manifest': [{'mapping_key': key, 'mapping_name': name, 'target_table': 'DB.T.TARGET'}]})
    run('first')
    run('second')
    assert commands[0].payload['metadata']['agent_external_key'] != commands[1].payload['metadata']['agent_external_key']
    assert commands[0].payload['sttm_name'] == 'Requested name'
    records.append(SimpleNamespace(sttm_id='saved', target_table='DB.T.TARGET', sttm_name='Requested name',
        metadata={'draft_only': True, 'migration_run_id': 'second', 'mapping_key': 'primary'}))
    assert run('second')['manifest'][0]['sttm_id'] == 'saved'
    assert len(commands) == 2
    run('second', 'different', 'Another mapping')
    assert len(commands) == 3
    records[0].metadata['draft_only'] = False
    run('second')
    assert len(commands) == 4


def test_identical_visible_cte_is_reused_without_replacing_human_definition():
    from types import SimpleNamespace
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.derived_source import DerivedSourceDefinition, DerivedSourceRecord
    from app.schema.common import TableRef
    ref = TableRef(database='DB', schema='S', table='CUSTOMERS')
    definition = DerivedSourceDefinition(derived_source_id='new', derived_source_name='active_customers',
        sql_text='SELECT * FROM DB.S.CUSTOMERS WHERE ACTIVE = TRUE', source_tables=[ref], project_id='101')
    existing = DerivedSourceRecord(**definition.model_copy(update={'derived_source_id': 'human',
        'business_description': 'Human-authored description'}).model_dump())
    writes = []
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._derived_sources = SimpleNamespace(list_sources=lambda **_: [existing],
        save_source=lambda body, **kwargs: writes.append(body) or body)
    assert handler._save_planned_derived_source(definition).derived_source_id == 'human'
    assert not writes and existing.business_description == 'Human-authored description'
    existing.sql_text = 'SELECT * FROM DB.S.CUSTOMERS WHERE ACTIVE = FALSE'
    handler._save_planned_derived_source(definition)
    assert len(writes) == 1  # Conflict policy remains with the normal service.
    existing.sql_text = definition.sql_text
    existing.project_id = 'other-project'
    handler._save_planned_derived_source(definition)
    assert len(writes) == 2


def test_zero_confidence_does_not_hold_a_complete_verified_direct_candidate():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    rows = [{'target_column': 'STATUS_LABEL', 'source_columns': [], 'status': 'unresolved'}]
    WorkbenchWorkflowHandlers._promote_verified_plan_candidates(rows,
        [{'target_column': 'STATUS_LABEL', 'source_columns': ['DB.S.STATUSES.LABEL'], 'mapping_mode': 'direct', 'confidence': 0}],
        {'DB.S.STATUSES': {'columns': ['LABEL']}}, [{'name': 'STATUS_LABEL', 'type': 'VARCHAR'}])
    assert rows[0]['status'] == 'draft'
    assert rows[0]['source_columns'] == ['DB.S.STATUSES.LABEL']
    assert rows[0]['confidence'] == 0
    assert not rows[0]['missing_dependencies']


def test_compile_retry_reuses_completed_rules_without_replacing_unfinished_decisions():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.migration_workflow.scheduler import Partition, PartitionState
    handler = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object())
    key = 'customers'
    context = {'run_id': 'r', 'thread_id': 'r', 'app_user_id': 'u', 'effective_role': 'ROLE',
               'workspace': {'source_tables': [{'database': 'DB', 'schema': 'S', 'table': 'CUSTOMERS'}]}}
    state = {'project_id': '101', 'mapping_context_packages': {key: context}}
    source = Partition(partition_id='customers:map:0', mapping_key=key, state=PartitionState.COMPLETED,
        columns=['EMAIL', 'STATUS_LABEL'], result={'mapping_rows': [
            {'target_column': 'EMAIL', 'status': 'draft', 'mapping_classification': 'derived'},
            {'target_column': 'STATUS_LABEL', 'status': 'unresolved'}]})
    completed = {'target_column': 'EMAIL', 'status': 'draft', 'mapping_classification': 'derived',
                 'expression': 'LOWER(active_customers.EMAIL)', 'source_columns': ['active_customers.EMAIL']}
    compile_part = Partition(partition_id='customers:compile', mapping_key=key, stage='compile',
        result={'retry_mapping_rows': [completed]})
    observed = []
    handler.execute_mapping = lambda _state, mapping: observed.append(mapping['finalize_rows']) or {'status': 'READY_FOR_REVIEW'}
    handler.execute_partition(state, {'mapping_key': key, 'sttm_id': '401'}, compile_part, [source, compile_part])
    assert observed[0][0] == completed
    assert observed[0][1] == {'target_column': 'STATUS_LABEL', 'status': 'unresolved'}
