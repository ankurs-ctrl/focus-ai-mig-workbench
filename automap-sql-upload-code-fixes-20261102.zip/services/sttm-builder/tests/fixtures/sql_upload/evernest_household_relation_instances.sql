-- Synthetic regression based on 01-EverNest-HHs-reference.sql.
-- Not client migration instructions. No source/target writes.
-- Tests two address populations, repeated lookup-table instances, quoted
-- aliases, eleven physical tables and CTE output boundaries.
USE DATABASE REGRESSION_DB;
USE SCHEMA EVERNEST;
WITH BillingAddress AS (
 SELECT ad.addressable_id AS contact_id, ad.country AS billing_country,
        ad.state AS billing_state, ad.city AS "BillingCity"
 FROM ADDRESSES ad
 WHERE ad.deleted = 0 AND ad.is_primary = 1
 QUALIFY ROW_NUMBER() OVER (PARTITION BY ad.addressable_id ORDER BY ad.id) = 1
), OtherAddress AS (
 SELECT ad.addressable_id AS contact_id, ad.country AS other_country,
        ad.state AS other_state, ad.city AS other_city
 FROM ADDRESSES ad
 WHERE ad.deleted = 0 AND ad.is_primary = 0
 QUALIFY ROW_NUMBER() OVER (PARTITION BY ad.addressable_id ORDER BY ad.id) = 1
), SOURCE AS (
 SELECT c.id, ba.billing_country, ba.billing_state, ba."BillingCity",
        oa.other_country, oa.other_state, oa.other_city,
        c.first_name, c.last_name, cs.name AS status_name
 FROM CONTACTS c
 LEFT JOIN CONTACT_STATUSES cs ON cs.id = c.status_id
 LEFT JOIN BillingAddress ba ON ba.contact_id = c.id
 LEFT JOIN OtherAddress oa ON oa.contact_id = c.id
 LEFT JOIN CONTACT_FAMILY_MEMBERS cfm ON cfm.contact_id = c.id AND cfm.deleted = 0
 LEFT JOIN CONTACT_FAMILIES cf ON cf.id = cfm.family_id AND cf.deleted = 0
 LEFT JOIN SERVICING_ADVISORS sa ON sa.id = c.servicing_advisor_id
 LEFT JOIN WRITING_ADVISORS wa ON wa.id = c.writing_advisor_id
 LEFT JOIN CONTACT_CATEGORIES cat ON cat.id = c.category_id
 LEFT JOIN CONTACT_UDFS udf ON udf.contact_id = c.id AND udf.deleted = 0
 WHERE c.deleted = 0 AND (cs.name = 'Client' OR c.id IN (1193,1441))
)
SELECT s.id AS Legacy_ID__c, s."BillingCity" AS "BillingCity",
 ccMail.country_code AS BillingCountry, "ccOther".country_code AS OtherCountry,
 scMail.state_code AS BillingState, scOther.state_code AS OtherState,
 TRIM(s.first_name || ' ' || COALESCE(s.last_name,'')) AS Name,
 '' AS EmptyConstant
FROM SOURCE s
LEFT JOIN COUNTRY_CODES ccMail
 ON TRIM(UPPER(ccMail.country_alias)) = TRIM(UPPER(s.billing_country))
 OR TRIM(UPPER(ccMail.country_code)) = TRIM(UPPER(s.billing_country))
LEFT JOIN COUNTRY_CODES "ccOther"
 ON TRIM(UPPER("ccOther".country_alias)) = TRIM(UPPER(s.other_country))
 OR TRIM(UPPER("ccOther".country_code)) = TRIM(UPPER(s.other_country))
LEFT JOIN STATE_CODES scMail
 ON TRIM(UPPER(scMail.state_alias)) = TRIM(UPPER(s.billing_state))
 OR TRIM(UPPER(scMail.state_code)) = TRIM(UPPER(s.billing_state))
LEFT JOIN STATE_CODES scOther
 ON TRIM(UPPER(scOther.state_alias)) = TRIM(UPPER(s.other_state))
 OR TRIM(UPPER(scOther.state_code)) = TRIM(UPPER(s.other_state))
WHERE s.status_name = 'Client'
ORDER BY s.id;
