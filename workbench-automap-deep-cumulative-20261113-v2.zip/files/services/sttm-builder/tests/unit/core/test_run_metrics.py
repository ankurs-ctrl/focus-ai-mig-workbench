from datetime import UTC, datetime, timedelta

from app.agent_runs.run_metrics import contract_read_table, contract_read_tables, segment_events, summarize_run

_START = datetime(2026, 9, 29, 10, 0, tzinfo=UTC)


def _event(sequence: int, seconds: float, event_type: str, summary: str = "", **extra):
    return {"sequence": sequence, "event_type": event_type, "status": "running",
            "safe_summary": summary, "created_at": (_START + timedelta(seconds=seconds)).isoformat(),
            "data": extra.pop("data", {}), **extra}


def test_contract_reads_are_recognized_from_summary_or_structured_data() -> None:
    assert contract_read_table(_event(1, 0, "trace.action.started",
                                      "Reading the contract for DB.SRC.CONTACTS.")) == "DB.SRC.CONTACTS"
    assert contract_read_table(_event(2, 0, "trace.action.started", "Reading the contract for x.",
                                      data={"table_fqn": "db.src.notes"})) == "DB.SRC.NOTES"
    assert contract_read_table(_event(3, 0, "trace.action.completed",
                                      "Reading the contract for DB.SRC.CONTACTS.")) is None
    assert contract_read_table(_event(4, 0, "trace.action.started", "Searching the catalog.")) is None


def test_batched_reads_and_revalidations_are_counted_per_table() -> None:
    batch = _event(1, 0, "trace.action.started", "Reading the contracts for 3 tables.",
                   data={"details": {"tables": ["db.src.a", "DB.SRC.B", "DB.SRC.C"]}})
    confirm = _event(2, 1, "trace.action.started", "Confirming 2 table contracts verified earlier in this conversation.",
                     data={"details": {"tables": ["DB.SRC.A", "DB.SRC.B"]}})
    reused = _event(3, 2, "tool.reused", "Reused the verified prepare migration evidence result from this conversation.",
                    data={"reuse_scope": "conversation"})
    assert contract_read_tables(batch) == ["DB.SRC.A", "DB.SRC.B", "DB.SRC.C"]
    assert contract_read_tables(confirm) == []
    summary = summarize_run({"run_id": "r3", "status": "EXECUTING"}, [batch, confirm, reused])
    assert summary["contract_reads"]["total"] == 3
    assert summary["contract_reads"]["queries"] == 1
    assert summary["contract_reads"]["revalidated_tables"] == 2
    assert summary["contract_reads"]["revalidation_queries"] == 1
    assert summary["knowledge_reuses"] == 1
    assert summary["segments"][0]["revalidated_contracts"] == 2


def test_run_summary_separates_user_wait_from_active_time_and_counts_rereads() -> None:
    events = [
        _event(1, 0, "run.queued"),
        _event(2, 5, "run.started"),
        _event(3, 6, "trace.action.started", "Reading the contract for DB.TGT.TASKS."),
        _event(4, 7, "trace.action.started", "Reading the contract for DB.SRC.ACTIVITIES."),
        _event(5, 8, "model.started"),
        _event(6, 9, "tool.started"),
        _event(7, 10, "tool.failed"),
        _event(8, 20, "run.question.required", "Join path 1 of 1 needs a business decision."),
        _event(9, 80, "run.question.answered"),
        _event(10, 85, "run.resumed.execution"),
        _event(11, 86, "trace.action.started", "Reading the contract for DB.TGT.TASKS."),
        _event(12, 87, "model.started"),
        _event(13, 100, "assistant.final", project_id="1101", sttm_id="5501"),
    ]
    run = {"run_id": "r1", "status": "NEEDS_REVIEW", "model_calls_used": 2, "tool_calls_used": 1,
           "elapsed_seconds_used": 150.0,
           "mapping_manifest": [{"status": "NEEDS_REVIEW"}, {"status": "PENDING"}, {"status": "PENDING"}]}
    items = [{"category": "source_join_path", "status": "ANSWERED"},
             {"category": "mapping_candidate_review", "status": "OPEN"}]

    summary = summarize_run(run, list(reversed(events)), items)

    assert summary["timing"] == {"wall_seconds": 100.0, "waiting_on_user_seconds": 60.0,
                                 "active_seconds": 40.0, "recorded_elapsed_seconds": 150.0}
    assert summary["resumes"] == 1
    assert [segment["model_calls"] for segment in summary["segments"]] == [1, 1]
    assert [(segment["waiting_seconds"], segment["active_seconds"]) for segment in summary["segments"]] == [
        (60.0, 20.0), (0.0, 15.0)]
    assert summary["contract_reads"] == {"total": 3, "queries": 3, "distinct_tables": 2, "redundant_reads": 1,
                                         "tables_reread_across_segments": ["DB.TGT.TASKS"], "revalidated_tables": 0,
                                         "revalidation_queries": 0}
    assert summary["questions"]["asked"] == 1
    assert summary["questions"]["review_items_open"] == 1
    assert summary["questions"]["by_category"] == {"mapping_candidate_review": 1, "source_join_path": 1}
    assert summary["events"]["tool_failed"] == 1
    assert summary["project_id"] == "1101"
    assert summary["sttm_ids"] == ["5501"]
    assert summary["mappings"] == {"requested": 3, "by_status": {"NEEDS_REVIEW": 1, "PENDING": 2}}


def test_unanswered_question_is_reported_without_counting_wait_time() -> None:
    events = [_event(1, 0, "run.started"), _event(2, 30, "run.question.required", "Pick a driver.")]
    summary = summarize_run({"run_id": "r2", "status": "AWAITING_INPUT"}, events)

    assert summary["questions"]["waits"] == [{"question": "Pick a driver.", "asked_sequence": 2,
                                              "answered_sequence": None, "wait_seconds": None}]
    assert summary["timing"]["waiting_on_user_seconds"] == 0.0
    assert len(segment_events(events)) == 1
