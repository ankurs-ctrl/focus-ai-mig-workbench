/**
 * Relation alias generation - single source of truth.
 *
 * Aliases used to be POSITIONAL (`${name}_${index + 1}`, with derived sources
 * offset by `sourceTables.length`) and the generator was duplicated in three
 * places. Two consequences made mapping work unrecoverable:
 *
 *  1. Adding, removing or reordering any physical source renumbered every derived
 *     alias, so aliases already frozen into persisted `source_columns` stopped
 *     matching anything.
 *  2. The snapshot writer and the compiler payload builder each had their own copy
 *     of the generator, free to drift apart.
 *
 * The alias is now derived only from the relation's own stable identity, so it
 * does not depend on how many other relations exist or what order they are in.
 * A short hash keeps aliases unique when two schemas contain the same table name,
 * without reintroducing positional coupling.
 */

/** Lower-cased, SQL-safe form of the last dotted segment. */
function aliasStem(seed: string): string {
  const stem = seed
    .split(".")
    .pop()
    ?.replace(/[^A-Za-z0-9_]/g, "_")
    .replace(/^_+|_+$/g, "")
    .toLowerCase();
  return stem || "source";
}

/**
 * Short, stable, non-cryptographic digest of the full identity.
 * FNV-1a: deterministic across sessions and machines, which matters because the
 * alias it produces gets persisted.
 */
function identityDigest(identity: string): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < identity.length; index += 1) {
    hash ^= identity.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(36).padStart(6, "0").slice(-6);
}

/**
 * Alias for a relation, derived purely from its stable identity.
 *
 * `identity` must be the relation's durable key - a fully qualified table name for
 * physical tables, or the derived-source id for derived sources. Never pass an
 * array index or anything else that varies with unrelated workspace edits.
 */
export function relationAliasFor(identity: string, displaySeed?: string | null): string {
  const key = String(identity || "").trim();
  if (!key) return "source";
  return `${aliasStem(displaySeed || key)}_${identityDigest(key)}`;
}

/**
 * Map superseded aliases onto the aliases the generator produces today.
 *
 * Mappings saved while aliases were positional persisted qualifiers such as
 * `servicing_advisors_15`. Physical-table aliases are regenerated from identity
 * on every load, so those stored qualifiers now resolve to nothing. Derived
 * sources restore their persisted alias verbatim and therefore never drift.
 *
 * The persisted relation graph is the authoritative record of which alias a
 * stored reference was written against, so pair each persisted node alias with
 * the alias its identity yields now. Entries are only emitted where the two
 * actually differ.
 */
export function buildLegacyAliasRewrites(
  nodes: Array<{ alias?: unknown; identity?: unknown; displaySeed?: unknown }>,
): Map<string, string> {
  const rewrites = new Map<string, string>();
  const ambiguous = new Set<string>();
  for (const node of nodes) {
    const storedAlias = String(node.alias ?? "").trim();
    const identity = String(node.identity ?? "").trim();
    if (!storedAlias || !identity) continue;
    const displaySeed = String(node.displaySeed ?? "").trim() || null;
    const currentAlias = relationAliasFor(identity, displaySeed);
    if (currentAlias === storedAlias) continue;
    const key = storedAlias.toUpperCase();
    const existing = rewrites.get(key);
    if (existing && existing !== currentAlias) {
      // One stored alias cannot stand for two relations. Guessing would
      // silently rewrite a reference onto the wrong table.
      ambiguous.add(key);
      continue;
    }
    rewrites.set(key, currentAlias);
  }
  for (const key of ambiguous) rewrites.delete(key);
  return rewrites;
}

/**
 * Rewrite `<legacyAlias>.COLUMN` qualifiers onto current aliases.
 *
 * Only a single-token qualifier is rewritten. A dotted reference is already a
 * fully qualified name, which the compiler resolves directly, so touching it
 * would risk corrupting a valid reference.
 */
export function rewriteLegacyAliasReference(
  value: string,
  rewrites: Map<string, string>,
): string {
  if (!rewrites.size) return value;
  const text = String(value ?? "");
  if (!text.trim()) return text;
  return text.replace(
    /(?<![A-Za-z0-9_$.])([A-Za-z_][A-Za-z0-9_$]*)(?=\s*\.\s*[A-Za-z_])/g,
    (match, qualifier: string) => rewrites.get(qualifier.toUpperCase()) ?? match,
  );
}
