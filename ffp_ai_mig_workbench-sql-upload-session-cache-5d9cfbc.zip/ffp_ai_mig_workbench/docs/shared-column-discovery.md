# Shared-table column discovery

When Snowflake Information Schema returns no columns for a selected table, the
workbench now executes a zero-row query on the existing caller connection and
reads its result metadata. This covers the observed imported-database/RCR
visibility mismatch without changing roles, caller grants, or semantic registries.

The bulk Information Schema query remains the normal path. Only missing tables
use recovery, through a dedicated cursor. Recovery retains column names, order,
SQL types (including numeric precision/scale and string length), and nullability.
The existing primary/foreign-key SHOW helpers supply optional key flags. Query
metadata has no comments; recovered columns therefore have `comment: null`.
Unavailable key metadata is not evidence that a table has no constraints.

Failed recovery raises a metadata error rather than returning `columns: []`.
The attributes cache uses a new `attributes:v2` namespace, so old empty entries
cannot hide recovery after deployment. Expired attribute results are not served
on refresh errors, including access denials. Existing successful-cache TTL and
user/persona/role scoping remain unchanged; unexpired entries are not reauthorized
on every read. Other catalog caches retain their existing stale-on-error behavior.

## Verification

- Focused tests cover 500/591-column recovery, mixed native/shared selections,
  SQL identifier quoting, literal column names, SQL types, single-table lookup,
  optional keys, failures, old cache entries, and expired-cache denial handling.
- Before implementation, live UAT zero-row queries returned all 500 ACCOUNTS and
  591 CONTACTS columns; ordered-name fingerprints, types, and nullability matched
  Desktop Information Schema. A native view without caller access still failed.
- These live probes validate the recovery mechanism, not deployment of this code.
  The updated service must still be deployed and its attributes API checked.

## Release acceptance

After the authorized backend deployment, select both source tables through the
app and verify 500 and 591 columns, no data rows fetched for discovery, and
correct behavior on repeated requests. Include a native table as a control.
Recovery logs a warning with the table and count and increments
`table_selection.columns.query_result_fallback`.

No grant, authentication, `SEM_*`, deployment-script, or frontend change is
required by this patch. It does not fix Snowflake's underlying Information Schema
behavior; track that separately against BCR 2416 (bundle 2026_07).