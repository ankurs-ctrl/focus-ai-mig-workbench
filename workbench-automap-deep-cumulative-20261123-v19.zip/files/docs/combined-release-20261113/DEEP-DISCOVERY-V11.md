# Deep Agent discovery and readable findings — V11

This cumulative release preserves V10, earlier Auto-map fixes, Deep Agent and PR #63. No environment files or credentials are included. These changes are not yet pushed to CodeCommit or deployed to SPCS.

## Confirmed incident

Run `run_b8fb74cc48c34b50b1724b2b9d0efb96` was queued at 03:20:40 UTC on November 16, started at 03:35:22, and finished with review items at 03:58:20. Thus there was also a 14m42s worker queue interval before the approximately 23-minute execution. The saved events contain 23 model calls, 13 completed domain-tool calls and 58 reported Snowflake queries. Eight catalog operations took 0.97–9.13 seconds each; the full execution time must not be described as catalog SQL time alone.

Discovery used the configured CRM metadata database for DW/DL shorthand. It did not establish account-wide absence. The role can see the real Loan Income objects in BBI_STTM_TEST_DB. Batch discovery bypassed the single-search guard; empty/irrelevant searches could continue across many model turns. Plan validation then rejected normalized_intent and decision subject/selected_value fields on three correction attempts. No usable mapping was created by that incident.

A new read-only UI test additionally exposed quoted/unquoted candidate mismatch at batch contract inspection. Correcting discovery alone was insufficient: the inspection handoff also needed SQL-aware identifier normalization.

Local logs also exposed a missing TBL_AGENT_RUN_KNOWLEDGE table. The worker continued in memory but could not durably retain its conversation research. Its existing migration is now part of the main bootstrap with namespace qualification and immediate column-contract validation.

## Changes

- Resolve schema hints against bounded caller-visible schema inventory across databases. Search only resolved database/schema scopes; no account-wide table enumeration. DW and DL prefixes produce candidate scopes such as DW_OPS and DL_AMOUNT, not automatic business-table choices.
- Match plural business terms such as notes/portal users to singular physical candidates. Return exact FQNs for subsequent contract inspection.
- Share single/batch discovery allowance and query cache. Bound broad table queries to 24 per Workbench handler. Exact qualified inspections remain available. Preserve checked, deferred and failed scope coverage; never interpret a scoped empty result as global absence. A failed scope preserves successful sibling matches.
- Normalize identifiers at contract handoff with the SQL parser. Equivalent quoting deduplicates, while quoted case and embedded dots remain distinct. Authorization remains caller/run scoped.
- Explicit read-only research can finish after its supported answer without being forced through a draft-migration checkpoint. Requests to create a mapping still require governed execution.
- Instruct the supervisor to inspect concrete candidates after bounded discovery, avoid unrelated synonym loops, respect research-only requests, and use the actual plan decision contract.
- Display the agent’s live working-plan steps independently of a formal approval artifact. Display ordinary final research summaries without requiring a special heading. Business questions appear in the main conversation; run-only findings do not display 0/0 mapping counters. Auto mode continues authorized draft work without a forced mode-switch recommendation; explicit Plan mode still honors approval.
- Replace the page-only raw diagnostic JSON pane with the same formatted findings/review components as the sidebar. Relabel the tab Findings and next steps. Do not label research-only findings as saved mapping drafts.
- Retain the post-V10 local fixes: full-width transcript scroll viewport, centered message content/composer, Cache-Control CORS allowance and executable LF shell launchers.

## Verified

Real Snowflake discovery through the registered search tool: 7.821 seconds. Registered batch contract inspection: 1.558 seconds. Total discovery-to-inspected-contract handoff: 9.379 seconds. All four succeeded:

| Object | Columns |
| --- | ---: |
| BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION | 33 |
| BBI_STTM_TEST_DB.DL_AMOUNT.LOAN_INCOME_AMOUNT_CALCULATION | 31 |
| BBI_STTM_TEST_DB.DL_AMOUNT.NOTE | 11 |
| BBI_STTM_TEST_DB.DW_OPS.PORTAL_USER_HISTORY | 12 |

These are real tool/SQL metadata checks, not a claim of complete mapping or preview acceptance. No business rows were read or modified, and the failed incident was not replayed. The existing knowledge migration was installed and its columns verified only in our DEV metadata namespace.

Focused backend, frontend and TypeScript results are recorded in DEEP-DISCOVERY-V11-RESULTS.json. The new live chat test found all four tables and displayed readable findings. It exposed the identifier handoff and an unnecessary migration-checkpoint requirement for read-only research; both are now fixed and regression tested. The live test ran on the worker before those final two corrections, so it is not a clean end-to-end acceptance of the final image. Full SPCS acceptance and end-to-end creation of a new Loan Income mapping with the final changes remain separate release checks. Earlier V10 timing limitations still apply; this release makes no new Auto-map completion-time guarantee.

## Deployment

1. Overlay files at the repository root; preserve client.env and all environment/credential files.
2. Run the existing scripts/bootstrap_sttm_metadata_infra.py deployment command against the configured metadata database/schema. It now includes infra/snowflake/migrations/20260929_deep_run_knowledge.sql. It uses CREATE TABLE IF NOT EXISTS and validates existing columns without replacing saved research. Use the existing metadata service-role grants; do not grant source/target INSERT for this change.
3. Rebuild and deploy matching frontend, API and Deep worker images. The supervisor instructions are Python runtime instructions shipped in the worker image; this change requires no new Snowflake agent specification, environment variable, model, OAuth login or context limit.
4. Keep the existing Deep worker service and delegated OAuth configuration from V10. Restart workers only at a safe boundary; do not replay uncertain calls or the failed incident.
5. Locally, frontend is on http://localhost:3000 and API on http://localhost:8000 via ./start-ai-workbench.sh. Deep execution additionally uses APP_ENV=local bash scripts/start_deep_worker_local.sh; a corrected worker is running for review. The UI does not substitute a mock API.

## Specialist wiring

The Deep worker configures CortexSpecialistAdapter with AGT_SOURCE_MAPPING and AGT_TRANSFORMATION_RULE (or the existing configured agent names). Source selection precedes custom-expression generation. AGT_STTM_BUILDER remains the Quick Agent orchestrator and is explicitly excluded from Deep delegation. Deep authors and validates its own evidence-backed source-preparation plan before invoking the governed mapping workflow. The read-only discovery test called neither mapping specialist; it did not request mappings.
