"""Compiler-owned, one-row-per-key code-or-alias lookup relation."""
from __future__ import annotations

import hashlib


def normalized_lookup_relation(table_sql: str, code_column: str, alias_column: str) -> tuple[str, str]:
    """Return a keyed relation that preserves aliases without lookup fanout.

    Callers validate table and column identifiers against current contracts.
    The two key forms are unioned, then one deterministic row is kept for each
    normalized key. This handles duplicate codes with distinct aliases.
    """
    digest = hashlib.sha256(
        f"{table_sql}|{code_column}|{alias_column}".upper().encode()
    ).hexdigest()[:12].upper()
    match_key = f"__AIA_LOOKUP_KEY_{digest}"
    sql = f"""(
        SELECT * FROM (
            SELECT T.*, TRIM(UPPER(T.{code_column})) AS {match_key}
            FROM {table_sql} AS T
            UNION ALL
            SELECT T.*, TRIM(UPPER(T.{alias_column})) AS {match_key}
            FROM {table_sql} AS T
        )
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY {match_key}
            ORDER BY {code_column}, {alias_column}
        ) = 1
    )"""
    return sql, match_key
