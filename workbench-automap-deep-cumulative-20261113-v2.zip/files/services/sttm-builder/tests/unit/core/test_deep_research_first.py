from datetime import timedelta
from typing import Any

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from app.agent_runs.models import AgentActor, AgentReviewItem, ReviewItemStatus, RunCreateRequest
from app.agent_runs.models import ToolResult
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.migration_workflow.graph import DefaultWorkflowHandlers, build_migration_graph


def _input(decisions: list[dict[str, Any]], *, run_id: str = "run-1") -> dict[str, Any]:
    return {
        "messages": [], "run_id": run_id, "prompt": "Build Household", "effort": "light",
        "actor_user_id": "user-1", "effective_role": "MIGRATION_EDITOR", "tenant_id": "tenant-1",
        "requested_mappings": ["Household"], "attachment_ids": [], "run_mode": "auto",
        "authorized_source_scope": ["DB.SRC.CUSTOMER", "DB.SRC.PARTY", "DB.SRC.ADDRESS"],
        "authorized_target_scope": ["DB.TGT.CUSTOMER"],
        "supervisor_plan": {
            "normalized_intent": "Build customer mapping",
            "source_preparation": {"driving_source": "DB.SRC.CUSTOMER", "target_table": "DB.TGT.CUSTOMER"},
            "auto_map": {"requested_mappings": ["Customer"]},
            "decisions": decisions,
        },
    }


def _source_decision(*, recommended: bool = True, confidence: float = 0.6) -> dict[str, Any]:
    return {
        "subject": "source", "selected_value": "DB.SRC.CUSTOMER", "confidence": confidence, "score_margin": 0.05,
        "rationale": "Closest contract.", "recommended": recommended,
        "alternatives": [{"value": "DB.SRC.PARTY", "label": "DB.SRC.PARTY"}],
    }


def _grain_decision() -> dict[str, Any]:
    return {
        "subject": "grain", "selected_value": "one row per customer", "confidence": 0.6, "score_margin": 0.05,
        "rationale": "Precedent grain.", "recommended": True,
        "alternatives": [{"value": "one row per account", "label": "Account grain"}],
    }


def _firm_value_import_decision() -> dict[str, Any]:
    return {
        "subject": "value_binding_import",
        "decision_key": "101",
        "selected_value": "import:101",
        "selected_label": "Import firm values from project 101",
        "confidence": 0.3,
        "score_margin": 0.0,
        "recommended": True,
        "rationale": "The precedent project holds all required values.",
        "question": "Import the required firm values available from this precedent project?",
        "names": ["HHRecordType", "BackupOwnerID"],
        "alternatives": [{"value": "review_individually", "label": "Review individually"}],
    }


def _graph(handlers: Any = None):
    return build_migration_graph(handlers, checkpointer=InMemorySaver())


def test_recommended_decisions_are_asked_together_and_applied_at_once() -> None:
    graph = _graph()
    config = {"configurable": {"thread_id": "batch"}}
    first = graph.invoke(_input([_source_decision(), _grain_decision()]), config=config)

    payload = first["__interrupt__"][0].value
    assert payload["category"] == "confidence_gate_batch"
    assert payload["recommended_choice_id"] == "accept_recommended"
    assert len(payload["subject_keys"]) == 2

    done = graph.invoke(Command(resume=payload["choices"][0]["selection_payload"]), config=config)
    assert "__interrupt__" not in done or done["__interrupt__"][0].value["category"] != "confidence_gate"
    source = done["migration_plan"]["source_preparation"]
    assert source["driving_source"] == "DB.SRC.CUSTOMER"
    assert source["intended_grain"] == "one row per customer"


def test_confirmed_firm_values_are_imported_after_project_creation() -> None:
    class Handlers(DefaultWorkflowHandlers):
        def __init__(self) -> None:
            self.imports: list[tuple[str, str, list[str]]] = []

        def create_project(self, _state):
            return {"project_id": "new-project"}

        def import_firm_values(self, state, source_project_id, names, *, overwrite=False):
            assert overwrite is False
            self.imports.append((state["project_id"], source_project_id, names))
            return ToolResult(status="succeeded", summary="Imported")

    handlers = Handlers()
    graph = _graph(handlers)
    config = {"configurable": {"thread_id": "firm-value-import"}}

    first = graph.invoke(_input([_firm_value_import_decision()]), config=config)

    assert handlers.imports == []
    question = first["__interrupt__"][0].value
    assert question["category"] == "confidence_gate"
    done = graph.invoke(Command(resume=question["choices"][0]["selection_payload"]), config=config)
    assert done["project_id"] == "new-project"
    assert handlers.imports == [
        ("new-project", "101", ["HHRecordType", "BackupOwnerID"]),
    ]


def test_confirmed_firm_value_import_suppresses_covered_value_questions() -> None:
    class Handlers(DefaultWorkflowHandlers):
        def create_project(self, _state):
            return {"project_id": "new-project"}

        def import_firm_values(self, state, source_project_id, names, *, overwrite=False):
            assert (state["project_id"], source_project_id, names, overwrite) == (
                "new-project", "101", ["HHRecordType", "BackupOwnerID"], False,
            )
            return ToolResult(status="succeeded", summary="Imported")

    value_decision = {
        "subject": "value_binding",
        "decision_key": "HHRecordType",
        "selected_value": "__provide_current__",
        "confidence": 0.3,
        "score_margin": 0.0,
        "rationale": "The current project value is not set yet.",
        "question": "Which household record type should this project use?",
        "allow_free_text": True,
    }
    graph = _graph(Handlers())
    config = {"configurable": {"thread_id": "firm-value-import-with-covered-question"}}

    first = graph.invoke(_input([_firm_value_import_decision(), value_decision]), config=config)
    question = first["__interrupt__"][0].value
    assert question["question"] == "Import the required firm values available from this precedent project?"

    done = graph.invoke(Command(resume=question["choices"][0]["selection_payload"]), config=config)

    assert done["project_id"] == "new-project"
    assert "__interrupt__" not in done


def test_review_each_falls_back_to_one_question_per_decision() -> None:
    graph = _graph()
    config = {"configurable": {"thread_id": "review-each"}}
    first = graph.invoke(_input([_source_decision(), _grain_decision()]), config=config)
    second = graph.invoke(Command(resume=first["__interrupt__"][0].value["choices"][1]["selection_payload"]), config=config)

    question = second["__interrupt__"][0].value
    assert question["category"] == "confidence_gate"
    third = graph.invoke(Command(resume=question["choices"][1]["selection_payload"]), config=config)
    assert third["__interrupt__"][0].value["category"] == "confidence_gate"
    done = graph.invoke(Command(resume=third["__interrupt__"][0].value["choices"][0]["selection_payload"]), config=config)
    assert done["migration_plan"]["source_preparation"]["driving_source"] == "DB.SRC.PARTY"


class _RememberingHandlers(DefaultWorkflowHandlers):
    def __init__(self, remembered: dict[str, str], thresholds: tuple[float, float] = (0.75, 0.15)) -> None:
        self.remembered = remembered
        self.thresholds = thresholds
        self.lookups: list[list[str]] = []

    def decision_thresholds(self) -> tuple[float, float]:
        return self.thresholds

    def remembered_decisions(self, state, subject_keys):
        self.lookups.append(list(subject_keys))
        return {key: value for key, value in self.remembered.items() if key in subject_keys}


def test_an_earlier_answer_to_the_same_question_is_reused_without_asking() -> None:
    key = "decision:source:DB.TGT.CUSTOMER:"
    handlers = _RememberingHandlers({key: "DB.SRC.PARTY"})
    done = _graph(handlers).invoke(_input([_source_decision(recommended=False)]),
                                   config={"configurable": {"thread_id": "remembered"}})

    assert handlers.lookups == [[key]]
    assert "__interrupt__" not in done or done["__interrupt__"][0].value["category"] not in {
        "confidence_gate", "confidence_gate_batch"}
    assert done["migration_plan"]["source_preparation"]["driving_source"] == "DB.SRC.PARTY"


def test_a_remembered_answer_that_is_no_longer_offered_is_asked_again() -> None:
    handlers = _RememberingHandlers({"decision:source:DB.TGT.CUSTOMER:": "DB.SRC.RETIRED"})
    first = _graph(handlers).invoke(_input([_source_decision(recommended=False)]),
                                    config={"configurable": {"thread_id": "stale-memory"}})

    assert first["__interrupt__"][0].value["category"] == "confidence_gate"


def test_configured_thresholds_let_a_supported_decision_pass_without_a_question() -> None:
    handlers = _RememberingHandlers({}, thresholds=(0.55, 0.0))
    done = _graph(handlers).invoke(_input([_source_decision(recommended=False, confidence=0.6)]),
                                   config={"configurable": {"thread_id": "threshold"}})

    assert handlers.lookups == []
    assert done["migration_plan"]["source_preparation"]["driving_source"] == "DB.SRC.CUSTOMER"


def test_firm_values_are_never_batched_with_recommendations() -> None:
    value = {
        "subject": "value_binding", "decision_key": "FirmId", "selected_value": "1101",
        "confidence": 0.3, "score_margin": 0, "rationale": "Historical value.",
        "alternatives": [{"value": "__provide_current__", "label": "Enter current firm ID"}],
        "allow_free_text": True,
    }
    first = _graph().invoke(_input([_source_decision(), value]), config={"configurable": {"thread_id": "firm"}})

    # One recommendation alone is not a batch; the firm value is asked on its own.
    assert first["__interrupt__"][0].value["category"] == "confidence_gate"


def test_decision_memory_excludes_the_current_run_and_later_answers() -> None:
    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    actor = AgentActor(user_id="user-1", tenant_id="tenant-1")
    earlier = service.create_run(RunCreateRequest(prompt="Build household"), actor)
    current = service.create_run(RunCreateRequest(prompt="Build household again"), actor)
    key = "decision:source:DB.TGT.CUSTOMER:"
    answered_at = earlier.created_at - timedelta(seconds=1)
    for run in (earlier, current):
        repository.save_review_item(AgentReviewItem(
            review_item_id=f"review-{run.run_id}", run_id=run.run_id, category="confidence_gate",
            safe_summary="Source choice", subject_keys=["source", key], status=ReviewItemStatus.ANSWERED,
            answer='{"selected_value": "DB.SRC.PARTY"}', answered_at=answered_at,
        ))

    found = repository.find_answered_decisions("user-1", "tenant-1", [key], exclude_run_id=current.run_id)

    assert [item.run_id for item in found] == [earlier.run_id]
    assert repository.find_answered_decisions("other-user", "tenant-1", [key]) == []
