"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AiaBox,
  AiaDivider,
  AiaIconButton,
  AiaMenu,
  AiaMenuItem,
  AiaStack,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import type { StoredChatSession } from "@/features/ai-agent/ai-chat-session-utils";
import type { ProjectRecord } from "@/services/projectService";
import {
  AddRoundedIcon,
  ChatBubbleOutlineRoundedIcon,
  EditNoteRoundedIcon,
  FolderOpenIcon,
  FolderOutlinedIcon,
  KeyboardArrowDownRoundedIcon,
  KeyboardArrowRightRoundedIcon,
  MoreHorizIcon,
  PushPinIcon,
  PushPinOutlinedIcon,
  SettingsOutlinedIcon,
} from "@/utils/icons";

export const GENERAL_PROJECT_VALUE = "general";

const PROJECT_PREVIEW_LIMIT = 5;
const PINNED_PROJECTS_STORAGE_KEY = "ai-agent-pinned-project-ids";

const ellipsisSx = {
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
} as const;

const sectionHeadingTextSx = {
  fontSize: 13.5,
  fontWeight: 550,
  letterSpacing: 0,
  color: "#475569",
} as const;

function loadPinnedProjectIds(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(PINNED_PROJECTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((id): id is string => typeof id === "string" && id.length > 0);
  } catch {
    return [];
  }
}

function persistPinnedProjectIds(ids: string[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PINNED_PROJECTS_STORAGE_KEY, JSON.stringify(ids));
  } catch {
    // Ignore storage write failures (private mode / quota).
  }
}

export type ProjectTreeNode = {
  projectId: string;
  label: string;
  description?: string | null;
  sessions: StoredChatSession[];
};

type ChatListItem = {
  projectId: string;
  session: StoredChatSession;
};

type AiAgentProjectTreeProps = {
  projects: ProjectRecord[];
  sessionsByProjectId: Record<string, StoredChatSession[]>;
  selectedProjectId: string;
  activeSessionId: string | null;
  onViewProjectChats: (projectId: string) => void;
  onSelectSession: (projectId: string, session: StoredChatSession) => void;
  onNewProject: () => void;
  onNewChat: () => void;
  onEditProject?: (projectId: string) => void;
};

function ProjectRow({
  node,
  isSelected,
  isExpanded,
  isPinned,
  activeSessionId,
  onToggle,
  onTogglePin,
  onViewProjectChats,
  onSelectSession,
  onEditProject,
}: {
  node: ProjectTreeNode;
  isSelected: boolean;
  isExpanded: boolean;
  isPinned: boolean;
  activeSessionId: string | null;
  onToggle: () => void;
  onTogglePin: () => void;
  onViewProjectChats: () => void;
  onSelectSession: (session: StoredChatSession) => void;
  onEditProject?: () => void;
}) {
  const [detailsAnchor, setDetailsAnchor] = useState<null | HTMLElement>(null);
  const [showAllChats, setShowAllChats] = useState(false);
  const FolderIcon = isExpanded ? FolderOpenIcon : FolderOutlinedIcon;
  const visibleSessions = showAllChats ? node.sessions : node.sessions.slice(0, 5);
  const hiddenChatCount = Math.max(0, node.sessions.length - 5);
  const showSelectedHighlight =
    isSelected && node.projectId !== GENERAL_PROJECT_VALUE;

  return (
    <AiaBox sx={{ mb: 0.35 }}>
      <AiaBox
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.15,
          borderRadius: "8px",
          px: 0.5,
          py: 0.45,
          backgroundColor: showSelectedHighlight ? "#E8EEF7" : "transparent",
          "&:hover": {
            backgroundColor: showSelectedHighlight ? "#E8EEF7" : "#F3F4F6",
          },
          "&:hover .project-row-actions": { opacity: 1 },
        }}
      >
        <AiaBox
          component="button"
          type="button"
          onClick={onToggle}
          sx={{
            flex: 1,
            minWidth: 0,
            border: "none",
            background: "transparent",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 0.85,
            textAlign: "left",
            px: 0.5,
            py: 0.35,
          }}
        >
          <FolderIcon
            sx={{
              fontSize: 16,
              color: isExpanded || isSelected ? "#334155" : "#64748B",
              flexShrink: 0,
            }}
          />
          <AiaText
            sx={{
              fontSize: 13,
              fontWeight: 400,
              color: "#0F172A",
              minWidth: 0,
              ...ellipsisSx,
            }}
          >
            {node.label}
          </AiaText>
          {isPinned ? (
            <PushPinIcon sx={{ fontSize: 13, color: "#64748B", flexShrink: 0, ml: 0.25 }} />
          ) : null}
        </AiaBox>

        <AiaStack
          className="project-row-actions"
          direction="row"
          spacing={0}
          sx={{
            opacity: 0,
            transition: "opacity 120ms ease",
            flexShrink: 0,
            alignItems: "center",
            ml: "auto",
          }}
        >
          <AiaIconButton
            size="small"
            aria-label={`View chats in ${node.label}`}
            title="View chats"
            onClick={(event) => {
              event.stopPropagation();
              onViewProjectChats();
            }}
            sx={{
              color: "#64748B",
              p: 0.3,
              borderRadius: "6px",
              "&:hover": { backgroundColor: "#E2E8F0" },
            }}
          >
            <EditNoteRoundedIcon sx={{ fontSize: 16 }} />
          </AiaIconButton>
          <AiaIconButton
            size="small"
            aria-label={`${node.label} details`}
            title="Project details"
            onClick={(event) => {
              event.stopPropagation();
              setDetailsAnchor(event.currentTarget);
            }}
            sx={{
              color: "#64748B",
              p: 0.3,
              borderRadius: "6px",
              "&:hover": { backgroundColor: "#E2E8F0" },
            }}
          >
            <MoreHorizIcon sx={{ fontSize: 16 }} />
          </AiaIconButton>
        </AiaStack>
      </AiaBox>

      <AiaMenu
        anchorEl={detailsAnchor}
        open={Boolean(detailsAnchor)}
        onClose={() => setDetailsAnchor(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        transformOrigin={{ vertical: "top", horizontal: "left" }}
        slotProps={{
          paper: {
            sx: {
              mt: 0.5,
              minWidth: 240,
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              backgroundColor: "#FFFFFF",
              boxShadow: "0 10px 30px rgba(15, 23, 42, 0.12)",
              py: 0.5,
            },
          },
        }}
      >
        <AiaBox sx={{ px: 1.75, pt: 1.25, pb: 1 }}>
          <AiaStack
            direction="row"
            sx={{ alignItems: "center", justifyContent: "space-between", gap: 1 }}
          >
            <AiaText sx={{ fontSize: 14, fontWeight: 700, color: "#0F172A", ...ellipsisSx }}>
              {node.label}
            </AiaText>
            <AiaIconButton
              size="small"
              aria-label={isPinned ? `Unpin ${node.label}` : `Pin ${node.label}`}
              title={isPinned ? "Unpin project" : "Pin project"}
              onClick={(event) => {
                event.stopPropagation();
                onTogglePin();
              }}
              sx={{
                color: isPinned ? "#0082b5" : "#94A3B8",
                p: 0.35,
                borderRadius: "6px",
                flexShrink: 0,
                "&:hover": { backgroundColor: "#F1F5F9" },
              }}
            >
              {isPinned ? (
                <PushPinIcon sx={{ fontSize: 15 }} />
              ) : (
                <PushPinOutlinedIcon sx={{ fontSize: 15 }} />
              )}
            </AiaIconButton>
          </AiaStack>
        </AiaBox>
        <AiaMenuItem disabled sx={{ opacity: "1 !important", py: 0.85 }}>
          <ChatBubbleOutlineRoundedIcon sx={{ fontSize: 15, color: "#64748B", mr: 1.25 }} />
          <AiaText sx={{ fontSize: 13, color: "#334155" }}>
            {node.sessions.length} {node.sessions.length === 1 ? "chat" : "chats"}
          </AiaText>
        </AiaMenuItem>
        {node.description ? (
          <AiaMenuItem disabled sx={{ opacity: "1 !important", py: 0.85, alignItems: "flex-start" }}>
            <FolderOutlinedIcon sx={{ fontSize: 15, color: "#64748B", mr: 1.25, mt: 0.15 }} />
            <AiaText
              sx={{
                fontSize: 12.5,
                color: "#64748B",
                whiteSpace: "normal",
                lineHeight: 1.4,
              }}
            >
              {node.description}
            </AiaText>
          </AiaMenuItem>
        ) : null}
        <AiaDivider sx={{ my: 0.5 }} />
        <AiaMenuItem
          onClick={() => {
            setDetailsAnchor(null);
            onTogglePin();
          }}
          sx={{ py: 0.9 }}
        >
          {isPinned ? (
            <PushPinIcon sx={{ fontSize: 15, color: "#0082b5", mr: 1.25 }} />
          ) : (
            <PushPinOutlinedIcon sx={{ fontSize: 15, color: "#64748B", mr: 1.25 }} />
          )}
          <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#0F172A" }}>
            {isPinned ? "Unpin project" : "Pin project"}
          </AiaText>
        </AiaMenuItem>
        {onEditProject ? (
          <AiaMenuItem
            onClick={() => {
              setDetailsAnchor(null);
              onEditProject();
            }}
            sx={{ py: 0.9 }}
          >
            <SettingsOutlinedIcon sx={{ fontSize: 15, color: "#64748B", mr: 1.25 }} />
            <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#0F172A" }}>
              Edit project
            </AiaText>
          </AiaMenuItem>
        ) : null}
      </AiaMenu>

      {isExpanded ? (
        <AiaBox sx={{ ml: 2.75, mt: 0.15, mb: 0.35 }}>
          {node.sessions.length === 0 ? (
            <AiaText sx={{ px: 1, py: 0.65, fontSize: 12, color: "#94A3B8" }}>
              No chats
            </AiaText>
          ) : (
            <>
              {visibleSessions.map((session) => {
                const isActive = session.id === activeSessionId;
                return (
                  <AiaBox
                    key={session.id}
                    component="button"
                    type="button"
                    title={session.title}
                    onClick={() => onSelectSession(session)}
                    sx={{
                      width: "100%",
                      textAlign: "left",
                      border: "none",
                      cursor: "pointer",
                      borderRadius: "6px",
                      px: 1,
                      py: 0.55,
                      backgroundColor: isActive ? "#E8EEF7" : "transparent",
                      "&:hover": { backgroundColor: isActive ? "#E8EEF7" : "#F3F4F6" },
                    }}
                  >
                    <AiaText
                      sx={{
                        fontSize: 12.5,
                        fontWeight: isActive ? 600 : 500,
                        color: isActive ? "#0F172A" : "#475569",
                        lineHeight: 1.35,
                        ...ellipsisSx,
                      }}
                    >
                      {session.title}
                    </AiaText>
                  </AiaBox>
                );
              })}
              {!showAllChats && hiddenChatCount > 0 ? (
                <AiaBox
                  component="button"
                  type="button"
                  onClick={() => setShowAllChats(true)}
                  sx={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    px: 1,
                    py: 0.45,
                    color: "#94A3B8",
                    fontSize: 12,
                    fontWeight: 600,
                    "&:hover": { color: "#64748B" },
                  }}
                >
                  See more
                </AiaBox>
              ) : null}
              {showAllChats && hiddenChatCount > 0 ? (
                <AiaBox
                  component="button"
                  type="button"
                  onClick={() => setShowAllChats(false)}
                  sx={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    px: 1,
                    py: 0.45,
                    color: "#94A3B8",
                    fontSize: 12,
                    fontWeight: 600,
                    "&:hover": { color: "#64748B" },
                  }}
                >
                  See less
                </AiaBox>
              ) : null}
            </>
          )}
        </AiaBox>
      ) : null}
    </AiaBox>
  );
}

export function AiAgentProjectTree({
  projects,
  sessionsByProjectId,
  selectedProjectId,
  activeSessionId,
  onViewProjectChats,
  onSelectSession,
  onNewProject,
  onNewChat,
  onEditProject,
}: AiAgentProjectTreeProps) {
  const [showAllProjects, setShowAllProjects] = useState(false);
  const [pinnedSectionOpen, setPinnedSectionOpen] = useState(true);
  const [projectsSectionOpen, setProjectsSectionOpen] = useState(true);
  const [chatsSectionOpen, setChatsSectionOpen] = useState(true);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(() => new Set());
  const [pinnedIds, setPinnedIds] = useState<string[]>([]);
  const [pinnedHydrated, setPinnedHydrated] = useState(false);

  useEffect(() => {
    setPinnedIds(loadPinnedProjectIds());
    setPinnedHydrated(true);
  }, []);

  useEffect(() => {
    if (!pinnedHydrated) return;
    persistPinnedProjectIds(pinnedIds);
  }, [pinnedIds, pinnedHydrated]);

  const nodes = useMemo<ProjectTreeNode[]>(() => {
    const generalSessions = sessionsByProjectId[GENERAL_PROJECT_VALUE] ?? [];
    const projectNodes = projects.map((project) => ({
      projectId: project.project_id,
      label: project.project_name || project.project_id,
      description: project.description,
      sessions: [...(sessionsByProjectId[project.project_id] ?? [])].sort(
        (a, b) => b.updatedAt - a.updatedAt,
      ),
    }));
    return [
      {
        projectId: GENERAL_PROJECT_VALUE,
        label: "General",
        description: "Chats not tied to a project",
        sessions: [...generalSessions].sort((a, b) => b.updatedAt - a.updatedAt),
      },
      ...projectNodes,
    ];
  }, [projects, sessionsByProjectId]);

  const nodeById = useMemo(() => {
    const map = new Map<string, ProjectTreeNode>();
    for (const node of nodes) map.set(node.projectId, node);
    return map;
  }, [nodes]);

  const pinnedNodes = useMemo(
    () =>
      pinnedIds
        .map((id) => nodeById.get(id))
        .filter((node): node is ProjectTreeNode => Boolean(node)),
    [pinnedIds, nodeById],
  );

  const visibleProjects = showAllProjects
    ? nodes
    : nodes.slice(0, PROJECT_PREVIEW_LIMIT);
  const hiddenProjectCount = Math.max(0, nodes.length - PROJECT_PREVIEW_LIMIT);

  const allChats = useMemo<ChatListItem[]>(() => {
    const items: ChatListItem[] = [];
    for (const node of nodes) {
      for (const session of node.sessions) {
        items.push({ projectId: node.projectId, session });
      }
    }
    return items.sort((a, b) => b.session.updatedAt - a.session.updatedAt);
  }, [nodes]);

  const toggleExpanded = (projectId: string) => {
    setExpandedIds((current) => {
      const next = new Set(current);
      if (next.has(projectId)) next.delete(projectId);
      else next.add(projectId);
      return next;
    });
  };

  const togglePinned = (projectId: string) => {
    setPinnedIds((current) => {
      if (current.includes(projectId)) {
        return current.filter((id) => id !== projectId);
      }
      return [projectId, ...current];
    });
  };

  const renderProjectRow = (node: ProjectTreeNode, rowKey: string) => {
    const isExpanded = expandedIds.has(node.projectId);
    const isPinned = pinnedIds.includes(node.projectId);
    return (
      <ProjectRow
        key={`${rowKey}:${node.projectId}`}
        node={node}
        isSelected={node.projectId === selectedProjectId}
        isExpanded={isExpanded}
        isPinned={isPinned}
        activeSessionId={activeSessionId}
        onToggle={() => toggleExpanded(node.projectId)}
        onTogglePin={() => togglePinned(node.projectId)}
        onViewProjectChats={() => onViewProjectChats(node.projectId)}
        onSelectSession={(session) => onSelectSession(node.projectId, session)}
        onEditProject={
          node.projectId === GENERAL_PROJECT_VALUE
            ? undefined
            : () => onEditProject?.(node.projectId)
        }
      />
    );
  };

  return (
    <AiaBox sx={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
      <AiaBox sx={{ flex: 1, minHeight: 0, overflowY: "auto", pb: 1.5 }}>
        <AiaBox
          sx={{
            px: 1.75,
            pt: 1.25,
            pb: 0.5,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <AiaBox
            component="button"
            type="button"
            onClick={() => setPinnedSectionOpen((open) => !open)}
            sx={{
              border: "none",
              background: "transparent",
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 0.15,
              p: 0,
              minWidth: 0,
            }}
          >
            <AiaText sx={sectionHeadingTextSx}>Pinned</AiaText>
            {pinnedSectionOpen ? (
              <KeyboardArrowDownRoundedIcon
                sx={{ fontSize: 16, color: "#475569", flexShrink: 0 }}
              />
            ) : (
              <KeyboardArrowRightRoundedIcon
                sx={{ fontSize: 16, color: "#475569", flexShrink: 0 }}
              />
            )}
          </AiaBox>
        </AiaBox>

        {pinnedSectionOpen ? (
          <AiaBox sx={{ px: 1 }}>
            {pinnedNodes.length === 0 ? (
              <AiaText sx={{ px: 1, py: 0.65, fontSize: 12, color: "#94A3B8" }}>
                No pinned projects
              </AiaText>
            ) : (
              pinnedNodes.map((node) => renderProjectRow(node, "pinned"))
            )}
          </AiaBox>
        ) : null}

        <AiaBox
          sx={{
            px: 1.75,
            pt: 1.25,
            pb: 0.5,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            "&:hover .projects-heading-action": { opacity: 1 },
          }}
        >
          <AiaBox
            component="button"
            type="button"
            onClick={() => setProjectsSectionOpen((open) => !open)}
            sx={{
              border: "none",
              background: "transparent",
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 0.15,
              p: 0,
              minWidth: 0,
            }}
          >
            <AiaText sx={sectionHeadingTextSx}>Projects</AiaText>
            {projectsSectionOpen ? (
              <KeyboardArrowDownRoundedIcon
                sx={{ fontSize: 16, color: "#475569", flexShrink: 0 }}
              />
            ) : (
              <KeyboardArrowRightRoundedIcon
                sx={{ fontSize: 16, color: "#475569", flexShrink: 0 }}
              />
            )}
          </AiaBox>
          <AiaIconButton
            className="projects-heading-action"
            size="small"
            aria-label="New project"
            title="New project"
            onClick={onNewProject}
            sx={{
              opacity: 0,
              transition: "opacity 120ms ease",
              color: "#64748B",
              p: 0.3,
              borderRadius: "6px",
              "&:hover": { backgroundColor: "#E2E8F0", opacity: 1 },
            }}
          >
            <AddRoundedIcon sx={{ fontSize: 16 }} />
          </AiaIconButton>
        </AiaBox>

        {projectsSectionOpen ? (
        <AiaBox sx={{ px: 1 }}>
          {visibleProjects.map((node) => renderProjectRow(node, "projects"))}
          {!showAllProjects && hiddenProjectCount > 0 ? (
            <AiaBox
              component="button"
              type="button"
              onClick={() => setShowAllProjects(true)}
              sx={{
                border: "none",
                background: "transparent",
                cursor: "pointer",
                px: 1,
                py: 0.55,
                color: "#94A3B8",
                fontSize: 12,
                fontWeight: 600,
                "&:hover": { color: "#64748B" },
              }}
            >
              See more
            </AiaBox>
          ) : null}
          {showAllProjects && hiddenProjectCount > 0 ? (
            <AiaBox
              component="button"
              type="button"
              onClick={() => setShowAllProjects(false)}
              sx={{
                border: "none",
                background: "transparent",
                cursor: "pointer",
                px: 1,
                py: 0.55,
                color: "#94A3B8",
                fontSize: 12,
                fontWeight: 600,
                "&:hover": { color: "#64748B" },
              }}
            >
              See less
            </AiaBox>
          ) : null}
        </AiaBox>
        ) : null}

        <AiaBox
          sx={{
            px: 1.75,
            pt: 1.25,
            pb: 0.5,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            "&:hover .chats-heading-action": { opacity: 1 },
          }}
        >
          <AiaBox
            component="button"
            type="button"
            onClick={() => setChatsSectionOpen((open) => !open)}
            sx={{
              border: "none",
              background: "transparent",
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 0.15,
              p: 0,
              minWidth: 0,
            }}
          >
            <AiaText sx={sectionHeadingTextSx}>Recent chats</AiaText>
            {chatsSectionOpen ? (
              <KeyboardArrowDownRoundedIcon
                sx={{ fontSize: 16, color: "#475569", flexShrink: 0 }}
              />
            ) : (
              <KeyboardArrowRightRoundedIcon
                sx={{ fontSize: 16, color: "#475569", flexShrink: 0 }}
              />
            )}
          </AiaBox>
          <AiaIconButton
            className="chats-heading-action"
            size="small"
            aria-label="New chat"
            title="New chat"
            onClick={onNewChat}
            sx={{
              opacity: 0,
              transition: "opacity 120ms ease",
              color: "#64748B",
              p: 0.3,
              borderRadius: "6px",
              "&:hover": { backgroundColor: "#E2E8F0", opacity: 1 },
            }}
          >
            <EditNoteRoundedIcon sx={{ fontSize: 16 }} />
          </AiaIconButton>
        </AiaBox>

        {chatsSectionOpen ? (
          <AiaBox sx={{ px: 1 }}>
            {allChats.length === 0 ? (
              <AiaText sx={{ px: 1, py: 0.65, fontSize: 12, color: "#94A3B8" }}>
                No chats yet
              </AiaText>
            ) : (
              allChats.map(({ projectId, session }) => {
                const isActive = session.id === activeSessionId;
                return (
                  <AiaBox
                    key={`${projectId}:${session.id}`}
                    component="button"
                    type="button"
                    title={session.title}
                    onClick={() => onSelectSession(projectId, session)}
                    sx={{
                      width: "100%",
                      textAlign: "left",
                      border: "none",
                      cursor: "pointer",
                      borderRadius: "6px",
                      px: 1,
                      py: 0.65,
                      backgroundColor: isActive ? "#E8EEF7" : "transparent",
                      "&:hover": { backgroundColor: isActive ? "#E8EEF7" : "#F3F4F6" },
                    }}
                  >
                    <AiaText
                      sx={{
                        fontSize: 12.5,
                        fontWeight: isActive ? 600 : 500,
                        color: isActive ? "#0F172A" : "#475569",
                        lineHeight: 1.35,
                        ...ellipsisSx,
                      }}
                    >
                      {session.title}
                    </AiaText>
                  </AiaBox>
                );
              })
            )}
          </AiaBox>
        ) : null}
      </AiaBox>
    </AiaBox>
  );
}
