from types import SimpleNamespace
import re
import pytest
import scripts.bootstrap_sttm_metadata_infra as bootstrap


def rendered(path):
    sql = bootstrap.render_sql(path.read_text(), 'CLIENT.METADATA', warehouse='WH', role='APP_ROLE', database='CLIENT')
    return bootstrap.qualify_deep_agent_sql(sql, 'CLIENT.METADATA')


def test_deep_chain_orders_control_plane_before_dependent_schema_and_procedures():
    names = [path.name for path in bootstrap.DEEP_AGENT_SQL_FILES]
    assert names[0] == '20260830_migration_agent_control_plane.sql'
    assert names.index('20260922_deep_lease_fencing.sql') < names.index('20260924_deep_checkpoint_batch.sql')
    assert names.index('20260901_assistant_conversation_reliability.sql') < names.index('20260927_assistant_conversation_pins.sql')
    all_sql = '\n'.join(rendered(path) for path in bootstrap.DEEP_AGENT_SQL_FILES)
    for name in ('TBL_AGENT_RUNS', 'TBL_AGENT_CHECKPOINT_REFS', 'TBL_AGENT_CHECKPOINT_WRITES',
                 'SP_APPEND_AGENT_RUN_EVENTS', 'SP_FLUSH_AGENT_COMMAND_OUTBOX',
                 'SP_APPEND_AGENT_RUN_EVENTS_FENCED', 'SP_WRITE_AGENT_CHECKPOINT_FENCED',
                 'WORKBENCH_AGENT_ATTACHMENTS', 'WORKBENCH_AGENT_CHECKPOINTS'):
        assert 'CLIENT.METADATA.' + name in all_sql
    assert not re.search(r'(?<![\w$.])(?:FROM|UPDATE|INTO|TABLE(?: IF (?:NOT )?EXISTS)?)\s+TBL_AGENT_', all_sql, re.I)


def test_deep_qualification_preserves_literals_comments_quoted_and_foreign_references():
    raw = "SELECT 'TBL_AGENT_RUNS', \"TBL_AGENT_RUNS\" FROM TBL_AGENT_RUNS; -- TBL_AGENT_RUNS\nSELECT * FROM OTHER.META.TBL_AGENT_RUNS;"
    actual = bootstrap.qualify_deep_agent_sql(raw, 'CLIENT.METADATA')
    assert "'TBL_AGENT_RUNS'" in actual and '"TBL_AGENT_RUNS"' in actual
    assert '-- TBL_AGENT_RUNS\n' in actual and 'OTHER.META.TBL_AGENT_RUNS' in actual
    assert 'FROM CLIENT.METADATA.TBL_AGENT_RUNS;' in actual


def test_deep_procedure_grants_and_caller_mode_survive_repeat_rendering():
    for path in bootstrap.DEEP_AGENT_SQL_FILES:
        sql = rendered(path)
        assert bootstrap.qualify_deep_agent_sql(sql, 'CLIENT.METADATA') == sql
        if 'CREATE OR REPLACE PROCEDURE' in sql:
            assert ') COPY GRANTS' in sql
            assert 'EXECUTE AS CALLER' in sql
        if 'CREATE OR REPLACE VIEW' in sql:
            assert ' COPY GRANTS AS' in sql


def test_bootstrap_deep_statements_use_configured_namespace(monkeypatch):
    captured = []
    monkeypatch.setattr(bootstrap, 'execute_multi_statement', lambda conn, sql, label: captured.append((sql, label)))
    bootstrap.apply_sql_files(object(), bootstrap.DEEP_AGENT_SQL_FILES, namespace='CLIENT.METADATA',
        warehouse='WH', role='APP_ROLE', database='CLIENT', semantic_namespace='SEM.REGISTRY',
        semantic_table_object='TABLES', semantic_column_object='COLUMNS', semantic_native_object='NATIVE')
    assert len(captured) == len(bootstrap.DEEP_AGENT_SQL_FILES)
    assert all(sql == rendered(path) for (sql, _), path in zip(captured, bootstrap.DEEP_AGENT_SQL_FILES))


@pytest.mark.parametrize('missing', [None, 'SP_WRITE_AGENT_CHECKPOINT_FENCED'])
def test_deep_installation_verifies_contracts_and_requires_all_procedures(missing):
    statements = []
    procedures = {'SP_APPEND_AGENT_RUN_EVENTS', 'SP_FLUSH_AGENT_COMMAND_OUTBOX', 'SP_ENSURE_AGENT_CAPACITY',
                  'SP_APPEND_AGENT_RUN_EVENTS_FENCED', 'SP_WRITE_AGENT_CHECKPOINT_FENCED'} - {missing}
    class Cursor:
        description = [('name',)]
        def __enter__(self): return self
        def __exit__(self, *_): pass
        def execute(self, sql): statements.append(sql)
        def fetchall(self):
            return [(name,) for name in ({'WORKBENCH_AGENT_ATTACHMENTS', 'WORKBENCH_AGENT_CHECKPOINTS'}
                if statements[-1].startswith('SHOW STAGES') else procedures)]
    connection = SimpleNamespace(cursor=Cursor)
    if missing:
        with pytest.raises(RuntimeError, match=missing): bootstrap.validate_deep_agent_install(connection, 'CLIENT.METADATA')
    else:
        bootstrap.validate_deep_agent_install(connection, 'CLIENT.METADATA')
    assert all(sql.startswith(('SELECT ', 'SHOW ')) for sql in statements)


@pytest.mark.parametrize('existing,expected', [({'EVENT_PUBLISHED'}, True), (set(), False)])
def test_repeat_deep_add_skips_only_existing_column(monkeypatch, existing, expected):
    monkeypatch.setattr(bootstrap, '_existing_column_names', lambda *_: existing)
    sql = '-- existing migration\nALTER TABLE CLIENT.METADATA.TBL_AGENT_COMMANDS ADD COLUMN IF NOT EXISTS EVENT_PUBLISHED BOOLEAN DEFAULT FALSE;'
    assert bootstrap._skip_existing_deep_column_add(object(), sql, 'infra/snowflake/migrations/20260922_deep_command_outbox.sql') is expected
    assert not bootstrap._skip_existing_deep_column_add(object(), sql, 'unrelated.sql')


def test_repeat_deep_add_with_optional_table_guard(monkeypatch):
    monkeypatch.setattr(bootstrap, '_existing_column_names', lambda *_: {'PINNED'})
    sql = '-- organization metadata\nALTER TABLE IF EXISTS CLIENT.METADATA.TBL_ASSISTANT_CONVERSATIONS\n ADD COLUMN IF NOT EXISTS PINNED BOOLEAN DEFAULT FALSE;'
    assert bootstrap._skip_existing_deep_column_add(object(), sql, '20260927_assistant_conversation_pins.sql')


def test_bootstrap_stages_packaged_deep_agent_skills():
    statements = []

    class Cursor:
        def __enter__(self):
            return self

        def __exit__(self, *_):
            pass

        def execute(self, sql):
            statements.append(sql)

    bootstrap.upload_skills(SimpleNamespace(cursor=Cursor), 'CLIENT', 'METADATA')
    stage = '@"CLIENT"."METADATA"."STTM_AGENT_SKILLS"/skills'
    for name in ('workbench-documents', 'workbench-spreadsheets', 'workbench-sql'):
        assert any(f'/{name}/SKILL.md {stage}/{name}/' in sql for sql in statements)
    assert any(f'/workbench-documents/LICENSE.txt {stage}/workbench-documents/' in sql for sql in statements)
