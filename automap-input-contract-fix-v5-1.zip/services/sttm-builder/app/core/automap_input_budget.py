"""Auto-map input limits; provider output and recovery limits are independent."""
from copy import deepcopy

from app.core.automap_retrieval import encoded
from app.core.snowflake_agent import SnowflakeAgentClient


INPUT_HARD_LIMIT = 180_000
OUTPUT_HARD_LIMIT = 120_000


def input_limits(settings):
    return (min(INPUT_HARD_LIMIT, settings.agent_outbound_message_max_chars),
            min(INPUT_HARD_LIMIT, settings.agent_outbound_message_max_bytes))


def wire_messages(messages):
    return SnowflakeAgentClient._normalize_messages(deepcopy(messages))


def wire_text(messages):
    return encoded(wire_messages(messages))
