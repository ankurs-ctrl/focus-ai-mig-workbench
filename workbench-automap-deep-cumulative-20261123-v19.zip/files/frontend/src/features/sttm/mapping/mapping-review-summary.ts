import { hasMappingDefinition } from '../shared/row-validation-state';
import type { MappingState, DerivedSource, TableNode } from '../types/sttm.types';
import { businessReviewText, alternativeCandidates, currentCandidate, definitionKey, guidanceForRow, reviewCatalog } from './mapping-review-model';
import { rowReviewUrl, mappingBase } from './review-navigation';

const escape = (text: string) => text.replace(/[\\`*_{}[\]<>#|]/g, '\\$&').replace(/\s+/g, ' ').trim();
const code = (text: string) => {const ticks='`'.repeat(Math.max(0,...Array.from(text.matchAll(/`+/g),match=>match[0].length))+1);return `${ticks}${text.replace(/[\r\n]/g,' ')}${ticks}`;};
export function mappingReviewSummary(rows: MappingState[], baseline: Record<string, MappingState>, sources: TableNode[], derived: DerivedSource[], sttmId: string | null, generationId?: string) {
  const catalog=reviewCatalog(sources,derived);
  const hasDefinition=hasMappingDefinition;
  const retained=rows.filter(row=>baseline[row.id] && hasDefinition(baseline[row.id]) && definitionKey(row,catalog)===definitionKey(baseline[row.id],catalog));
  const generated=rows.filter(row=>row.aiGeneration?.generationId===generationId && generationId);
  const count=(outcome:string)=>generated.filter(row=>row.aiGeneration?.outcome===outcome).length;
  const applied=rows.filter(row=>row.aiReviewStatus==='unreviewed' && row.selectedAiCandidateId
    && (!baseline[row.id] || !hasDefinition(baseline[row.id]) || definitionKey(row,catalog)!==definitionKey(baseline[row.id],catalog)));
  const alternatives=rows.filter(row=>alternativeCandidates(row,catalog).length);
  const unresolved=rows.filter(row=>!hasDefinition(row));
  const low=rows.filter(row=>row.confidenceScore!=null && row.confidenceScore<.6 && row.aiReviewStatus==='unreviewed');
  const base=mappingBase(sttmId);
  const link=(row:MappingState,section:'candidates'|'suggestions'='candidates')=>`[View row](${rowReviewUrl(base,row.id,section)})`;
  const lines=['### Auto-map results','',
    `- **Targets evaluated:** ${rows.length}.`, `- **New draft mappings applied:** ${generationId ? count('applied') : applied.length}.`, `- **Mapped:** ${rows.filter(hasDefinition).length}.`,
    ...(generationId ? [`- **Definitions replaced:** ${count('replaced')}.`,
      `- **Reevaluated and unchanged:** ${count('unchanged')}.`, `- **Held for your edits:** ${count('held')}.`,
      `- **Without a supported proposal:** ${rows.length-generated.filter(row=>row.aiGeneration?.supportedProposal).length}.`] : []),
    `- **Existing definitions retained:** ${retained.length} (retention does not certify validation).`,
    `- **Rows with alternative candidates:** ${alternatives.length}.`, `- **Unmapped:** ${unresolved.length}.`,
    `- **Low-confidence draft suggestions:** ${low.length}.`, '',
    'These categories can overlap.','', '### Notable mappings and alternatives',''];
  const notable=rows.filter(row=>applied.includes(row)||alternatives.includes(row)||unresolved.includes(row)).slice(0,4);
  for(const row of notable) {
    const option=currentCandidate(row,catalog);
    const source=row.mappingMode==='attribute' ? `$${row.attributeName}` : row.mappingMode==='constant' ? String(row.constantValue ?? '')
      : (row.sourceColumns ?? (row.sourceColumn?[row.sourceColumn]:[])).map(catalog.display).join(', ') || row.expression || '';
    lines.push(`- **${escape(row.targetColumn)}:** ${source ? code(source) : '**No suggestion returned**'}; ${escape(row.rule || 'Direct')}`
      + (row.confidenceScore==null ? '; confidence not available.' : `; **${Math.round(row.confidenceScore*100)}% confidence**.`)+` ${link(row,unresolved.includes(row)?'suggestions':'candidates')}`);
    const reason=businessReviewText(option?.confidence_reason)||businessReviewText(row.confidenceReason)||businessReviewText(option?.preprocessing_nl_rule);
    if(reason) lines.push(`  - Why: ${escape(catalog.display(reason).slice(0,300))}`);
    for(const alternative of alternativeCandidates(row,catalog).slice(0,2)) {
      const source=alternative.mapping_mode==='attribute' ? `$${alternative.attribute_name}` : alternative.mapping_mode==='constant' ? String(alternative.constant_value ?? '') : alternative.source_attributes.map(catalog.display).join(', ');
      lines.push(`  - Alternative: ${code(source)} — ${escape(alternative.preprocessing_rule_type || 'Direct')}`
        +(alternative.preprocessing_rule?`; ${code(catalog.display(alternative.preprocessing_rule))}`:'')+'.');
    }
  }
  if(!notable.length)lines.push('The current definitions were retained.');
  lines.push('','### Suggestions and next actions','');
  const groups=[['Relationship suggestions',['relationship']],['Project Values and business rules',['value','business_rule']],
    ['Source-data considerations',['source_data','outside_selection']],['Mapping considerations',['evidence']]] as const;
  for(const [title,kinds] of groups) {
    const items=rows.flatMap(row=>guidanceForRow(row).filter(item=>(kinds as readonly string[]).includes(item.kind)).map(item=>({row,message:item.message})));
    lines.push(`**${title}**`);
    if(title==='Relationship suggestions'&&items.length) {
      lines.push(`- ${items.length} relationship recommendation${items.length===1?' is':'s are'} available in the affected row’s Suggestions and the bell recommendations panel.`);
      lines.push('');continue;
    }
    if(!items.length)lines.push('- No additional action identified in these results.');
    else for(const {row,message} of items.slice(0,4))lines.push(`- ${code(row.targetColumn)}: ${escape(catalog.display(message).slice(0,300))} ${link(row,'suggestions')}`);
    if(items.length>4)lines.push(`- ${items.length-4} more recommendations are available in the mapping sheet.`);
    lines.push('');
  }
  lines.push('### Draft results','','Draft population does not change execution or publication checks.');
  return lines.join('\n');
}
