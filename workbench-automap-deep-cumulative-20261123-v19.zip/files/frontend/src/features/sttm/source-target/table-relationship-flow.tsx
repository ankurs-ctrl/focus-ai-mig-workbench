"use client";
import { useStore } from "react-redux";
import type { RootState } from "@/store/store";
import { selectionValidationSignature } from "../shared/validation-context";
import { sttmSelectTablesTitleSx } from '@/features/sttm/layout/sttm-sidebar-text-styles';
import { useRouter, useSearchParams } from 'next/navigation';
import { JOIN_REVIEW_KEY, joinReviewDraft, readJoinReview, rowReviewUrl, type JoinReviewIntent } from '../mapping/review-navigation';
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  AllInclusiveIcon,
  KeyboardArrowDownRoundedIcon,
  KeyboardArrowRightRoundedIcon,
  KeyIcon,
  LinkIcon,
} from '@/utils/icons';
import { AiaIconButton, AiaResizeHandle } from '@/components/ui';
import { AIA_RESIZE_HANDLE_THICKNESS } from '@/components/ui/aia-resize-handle';
import { AiaButton } from '@/components/ui/aia-button';
import { AiaChip } from '@/components/ui/aia-chip';
import { AiaText } from '@/components/ui/aia-text';
import {
  MarkerType,
  type Connection,
  type Edge,
  useEdgesState,
  useNodesState,
} from "@xyflow/react";




import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import { joinOnPredicate } from "@/features/sttm/source-target/join-predicate";
import {
  getTableCardTheme,
  LINEAGE_SOURCE_ACCENTS,
} from "@/features/sttm/lineage/lineage-utils";
import { resolveSelectedSourceTables } from "@/features/sttm/shared/sttm-selection-utils";
import type { Column, DerivedSource, JoinConfig, RuleCondition, RuleGroup, TableMeta } from "@/features/sttm/types/sttm.types";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import { relationAliasFor } from "@/features/sttm/mapping/relation-alias";
import api from "@/api/axiosInstance";
import { buildSqlUploadWorkspace } from "@/features/sttm/mapping/sql-upload-workspace";
import { renderSqlIdentifier, sqlIdentifierSuffixMatches } from "@/features/sttm/shared/sql-identifiers";
import { hydrateBuilderFromSql } from "./sql-hydration";
import { appendPreviewClauses } from "./query-preview-clauses";

import { FilterConditions } from "./filter-conditions";
import { JoinDefinitionsModal } from "./join-definitions-modal";
import { JoinModal } from "./join-modal";
import type { TableNodeData } from "./table-node";
import { WorkspaceRemoveConfirmDialog } from "./workspace-remove-confirm-dialog";
import { AddDerivedModal } from "./add-derived-modal";
import { RelationshipFlowView } from "./relationship-flow-view";
import {
  isTableHeaderHandle,
  resolveTableHeaderHandleId,
} from "./relationship-handles";
import {
  buildRelationshipLayout,
  mergeRelationshipNodePositions,
  RELATIONSHIP_LAYOUT_FULL,
} from "./relationship-layout";
const EMPTY_SELECTED_COLUMNS: Record<string, string[]> = {};
const CANVAS_AREA_MIN_HEIGHT = 660;
const CANVAS_FLOW_HOST_DEFAULT_HEIGHT = 560;

function renderSqlTableReference(table: TableMeta) {
  return `${table.database ?? ""}.${table.schema ?? ""}.${table.name ?? ""}`.replace(/\.+/g, ".");
}

type RelationReference = { source: string; alias: string };

function defaultRelationReference(table: TableMeta): RelationReference {
  const source = renderSqlTableReference(table);
  return { source, alias: relationAliasFor(String(table.id).startsWith('sql-instance:') ? String(table.id) : source) };
}

function buildRelationshipQuery(
  tables: TableMeta[],
  joins: JoinConfig[],
  drivingTableId: string | null | undefined,
  relationReference: (table: TableMeta) => RelationReference = defaultRelationReference,
  distinct = false,
) {
  if (!tables.length) return "";
  const tableById = new Map(tables.map((table) => [table.id as string, table]));
  const seedTable =
    (drivingTableId ? tableById.get(drivingTableId) : undefined) ??
    (joins[0]?.leftTableId ? tableById.get(joins[0].leftTableId) : undefined) ??
    tables[0];
  if (!seedTable) return "";
  const renderFrom = (table: TableMeta) => {
    const { source, alias } = relationReference(table);
    return source === alias ? source : `${source} AS ${alias}`;
  };
  const columnReference = (table: TableMeta, column: string) =>
    `${relationReference(table).alias}.${column}`;
  const lines = [distinct ? "SELECT DISTINCT" : "SELECT", "  *", `FROM ${renderFrom(seedTable)}`];
  const visited = new Set<string>([seedTable.id as string]);
  const remaining = [...joins];
  while (remaining.length > 0) {
    const nextIndex = remaining.findIndex((join) => {
      const leftVisited = !!join.leftTableId && visited.has(join.leftTableId);
      const rightVisited = !!join.rightTableId && visited.has(join.rightTableId);
      return leftVisited !== rightVisited;
    });
    if (nextIndex === -1) break;
    const [join] = remaining.splice(nextIndex, 1);
    const leftTable = join.leftTableId ? tableById.get(join.leftTableId) : undefined;
    const rightTable = join.rightTableId ? tableById.get(join.rightTableId) : undefined;
    if (!leftTable || !rightTable) continue;
    const attachRight = visited.has(join.leftTableId as string) && !visited.has(join.rightTableId as string);
    const attachingTable = attachRight ? rightTable : leftTable;
    const validConditions = (join.conditions ?? []).filter(
      (condition) => condition.leftColumn && condition.rightColumn,
    );
    if (!validConditions.length && !join.sqlPredicate) continue;
    const joinType = attachRight ? join.joinType ?? "INNER"
      : join.joinType === "LEFT" ? "RIGHT" : join.joinType === "RIGHT" ? "LEFT" : join.joinType ?? "INNER";
    lines.push(`${joinType} JOIN ${renderFrom(attachingTable)}`);
    lines.push(
      `  ON ${join.sqlPredicate || joinOnPredicate(validConditions.map((condition) => ({
        sql: `${columnReference(leftTable, condition.leftColumn as string)} ${condition.operator ?? "="} ${columnReference(rightTable, condition.rightColumn as string)}`,
        connector: condition.connector,
      })), "\n  ")}`,
    );
    visited.add(attachingTable.id as string);
  }
  return lines.join("\n");
}

/** True when the filter builder holds at least one structured condition. */
function hasStructuredConditions(groups: RuleGroup[] | null | undefined): boolean {
  const visit = (node: RuleGroup | RuleCondition): boolean =>
    node.type === "condition"
      ? Boolean(node.field)
      : (node.children ?? []).some(visit);
  return (groups ?? []).some(visit);
}

function orientJoinToDrivingLeft(join: JoinConfig, drivingTableId: string): JoinConfig {
  if (join.rightTableId !== drivingTableId || join.leftTableId === drivingTableId) return join;
  return {
    ...join,
    leftTableId: join.rightTableId,
    rightTableId: join.leftTableId,
    joinType: join.joinType === "LEFT" ? "RIGHT" : join.joinType === "RIGHT" ? "LEFT" : join.joinType,
    conditions: (join.conditions ?? []).map((condition) => ({
      ...condition,
      leftColumn: condition.rightColumn,
      rightColumn: condition.leftColumn,
      operator: ({ ">": "<", "<": ">", ">=": "<=", "<=": ">=" } as Record<string, string>)[condition.operator ?? "="] ?? condition.operator ?? "=",
    })),
  };
}

function parseHandleId(
  handleId: string | null | undefined,
  kind: "source" | "target"
) {
  if (!handleId) return null;
  const suffix = `-${kind}`;
  if (!handleId.endsWith(suffix)) return null;
  const withoutKind = handleId.slice(0, -suffix.length);
  const columnPart = withoutKind.slice(withoutKind.lastIndexOf(".") + 1);
  return columnPart.replace(/-\d+$/, "");
}

function tagChipPalette(tag?: string) {
  const t = (tag || "").toLowerCase();
  if (t.includes("driving")) return { tagBg: "#fef3c7", tagFg: "#854d0e" };
  if (t.includes("derived") || t.includes("cte")) return { tagBg: "#dcfce3", tagFg: "#166534" };
  if (t.includes("staging")) return { tagBg: "#f3e8ff", tagFg: "#7c3aed" };
  if (t.includes("sales")) return { tagBg: "#dbeafe", tagFg: "#1d4ed8" };
  if (t.includes("core")) return { tagBg: "#f3f4f6", tagFg: "#4b5563" };
  if (t.includes("transaction")) return { tagBg: "#ffedd5", tagFg: "#c2410c" };
  if (t.includes("master")) return { tagBg: "#e0e7ff", tagFg: "#4338ca" };
  if (t.includes("billing") || t.includes("finance")) {
    return { tagBg: "#ecfdf5", tagFg: "#047857" };
  }
  return { tagBg: "#f1f5f9", tagFg: "#475569" };
}

function normalizeColumns(
  columns: Column[] | undefined,
  tableId: string,
  tableName: string
): Column[] {
  const uniqueColumns = new Map<string, Column>();
  (columns ?? []).forEach((column, index) => {
    const normalized = {
      ...column,
      tableId: column.tableId ?? tableId,
      tableName: column.tableName ?? tableName,
    };
    const columnName = String(column.name ?? "").trim();
    const key = columnName ? columnName.toUpperCase() : `__UNNAMED_${index}`;
    const existing = uniqueColumns.get(key);
    uniqueColumns.set(
      key,
      existing
        ? {
            ...existing,
            ...normalized,
            isPrimaryKey: Boolean(existing.isPrimaryKey || normalized.isPrimaryKey),
            isForeignKey: Boolean(existing.isForeignKey || normalized.isForeignKey),
            selected: Boolean(existing.selected || normalized.selected),
          }
        : normalized,
    );
  });
  return [...uniqueColumns.values()];
}

/** All joins between one pair of tables, collapsed into a single canvas edge. */
type JoinPairGroup = {
  key: string;
  leftTableId: string;
  rightTableId: string;
  joins: JoinConfig[];
};

type TableRelationshipFlowProps = {
  tables?: TableMeta[];
  joins?: JoinConfig[];
  onJoinsChange?: (joins: JoinConfig[]) => void;
  showFilters?: boolean;
  selectableColumns?: boolean;
  selectedColumnsByTable?: Record<string, string[]>;
  onToggleColumn?: (tableId: string, columnName: string, checked: boolean) => void;
  drivingTableId?: string | null;
  allowDerivedEditing?: boolean;
  emptyStateText?: string;
};

export default function SttmTableRelationshipFlow({
  tables,
  joins,
  onJoinsChange,
  showFilters = true,
  selectableColumns = false,
  selectedColumnsByTable = EMPTY_SELECTED_COLUMNS,
  onToggleColumn,
  drivingTableId: controlledDrivingTableId,
  allowDerivedEditing = true,
  emptyStateText = "Select one or more tables from Source selection. They will appear here so you can define joins and relationships.",
}: TableRelationshipFlowProps) {
  const reviewRouter = useRouter();
  const reviewSearch = useSearchParams();
  const isRowJoinReview = !tables && !onJoinsChange && reviewSearch.get('joinReview') === '1';
  const [rowJoinIntent, setRowJoinIntent] = useState<JoinReviewIntent | null>(null);
  const openedRowJoinIntent = useRef<string | null>(null);
  const savedRowJoinIntent = useRef<string | null>(null);
  const {
    fullData,
    sources,
    drivingTableId,
    relationships,
    setRelationships,
    relationshipCandidates,
    refreshRelationships,
    loadState,
    errorState,
    acceptRelationshipCandidate,
    derivedSources,
    sourceAttributeGroups,
    updateDerivedSource,
    setSourceFilterConditions,
    sourceFilterGroups,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    sourceQuerySql,
    unresolvedSourceTables,
    sourceQueryModifiers,
    refreshAssistantSignals,
    applyParsedSqlWorkspace,
    activeSttmId,
    activeProjectId,
    saveReviewedJoin,
  } = useSttmBuilderContext();

  const [editingDerivedSource, setEditingDerivedSource] = useState<DerivedSource | null>(null);
  const [isDerivedModalOpen, setIsDerivedModalOpen] = useState(false);
  const [isJoinDefinitionsOpen, setIsJoinDefinitionsOpen] = useState(false);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [inspectedTableId, setInspectedTableId] = useState<string | null>(null);
  const [joinFilterPair, setJoinFilterPair] = useState<JoinPairGroup | null>(null);
  const [pendingPairDelete, setPendingPairDelete] = useState<JoinPairGroup | null>(null);
  const [flowHostHeight, setFlowHostHeight] = useState(CANVAS_FLOW_HOST_DEFAULT_HEIGHT);
  const [isRelationshipsExpanded, setIsRelationshipsExpanded] = useState(true);
  const headerRef = useRef<HTMLDivElement>(null);
  // Set once the user builds GROUP BY / ORDER BY items in the builder; until
  // then clauses authored in SQL are preserved.
  const builderOwnsGroupByRef = useRef(false);
  const builderOwnsOrderByRef = useRef(false);
  const legendRef = useRef<HTMLDivElement>(null);
  const sourceApplySequence = useRef(0);
  const sourceApplyMapping = useRef(activeSttmId);
  useLayoutEffect(() => {
    sourceApplyMapping.current = activeSttmId;
    sourceApplySequence.current += 1;
  }, [activeSttmId]);
  useEffect(() => () => { sourceApplySequence.current += 1; }, []);

  const resolveMinFlowHostHeight = useCallback(() => {
    const headerHeight = headerRef.current?.offsetHeight ?? 48;
    const legendHeight = legendRef.current?.offsetHeight ?? 58;
    return Math.max(
      160,
      CANVAS_AREA_MIN_HEIGHT - headerHeight - legendHeight - AIA_RESIZE_HANDLE_THICKNESS,
    );
  }, []);

  const handleCanvasResizeMouseDown = useCallback(
    (event: React.MouseEvent<HTMLDivElement>) => {
      event.preventDefault();
      const startY = event.clientY;
      const startHeight = flowHostHeight;
      const minHeight = resolveMinFlowHostHeight();

      const handleMouseMove = (moveEvent: MouseEvent) => {
        const nextHeight = startHeight + (moveEvent.clientY - startY);
        setFlowHostHeight(Math.max(minHeight, nextHeight));
      };

      const handleMouseUp = () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
        document.body.style.removeProperty("cursor");
        document.body.style.removeProperty("user-select");
      };

      document.body.style.cursor = "row-resize";
      document.body.style.userSelect = "none";
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [flowHostHeight, resolveMinFlowHostHeight],
  );
  const [editingJoin, setEditingJoin] = useState<JoinConfig | null>(null);
  const effectiveDrivingTableId = controlledDrivingTableId ?? drivingTableId;

  const allPhysicalTables = useMemo<TableMeta[]>(() => {
    const groupsByQualifiedName = new Map(
      sourceAttributeGroups.map((group) => [group.qualifiedName.toUpperCase(), group.columns]),
    );
    const tablesById = new Map<string, TableMeta>();
    const addTable = (table: {
      tableId: string;
      tableName: string;
      qualifiedName: string;
      rows?: string;
      columns?: number;
      columnItems?: Column[];
      tag?: string;
    }) => {
      const parts = table.qualifiedName.split(".");
      const database = parts.at(-3) ?? "";
      const schema = parts.at(-2) ?? "";
      const columns = normalizeColumns(
        table.columnItems?.length
          ? table.columnItems
          : groupsByQualifiedName.get(table.qualifiedName.toUpperCase()),
        table.tableId,
        table.tableName,
      );
      const chip = tagChipPalette(table.tag);
      tablesById.set(table.tableId, {
        id: table.tableId,
        name: table.tableName,
        schema,
        database,
        rowCount: table.rows ?? "—",
        colCount: columns.length || table.columns || 0,
        columns,
        tag: table.tag ?? "Source",
        tagBg: chip.tagBg,
        tagFg: chip.tagFg,
      });
    };

    for (const database of fullData?.sources ?? []) {
      for (const schema of database.schemas) {
        for (const table of schema.tables) addTable(table);
      }
    }
    for (const table of sources) addTable(table);
    return Array.from(tablesById.values());
  }, [fullData, sourceAttributeGroups, sources]);

  const sqlCatalogTables = useMemo<TableMeta[]>(() => {
    const derivedTables = (derivedSources ?? []).map((source) => ({
      id: source.id,
      name: source.sourceName,
      schema: "DERIVED",
      database: "DERIVED",
      tag: "Derived",
      columns: normalizeColumns(source.columns, source.id, source.sourceName),
    }));
    return [...allPhysicalTables, ...derivedTables];
  }, [allPhysicalTables, derivedSources]);

  const contextTables: TableMeta[] = useMemo(() => {
    const groupsByQualifiedName = new Map(
      sourceAttributeGroups.map((group) => [group.qualifiedName, group.columns])
    );
    const selectedTables: TableMeta[] = [];

    for (const table of resolveSelectedSourceTables({
      sourceDatabases: fullData?.sources ?? [],
      sources,
    })) {
      const qualifiedName = table.qualifiedName;
      const [database = "", schema = ""] = qualifiedName.split(".");
      const columnItems = normalizeColumns(
        table.columnItems?.length ? table.columnItems : groupsByQualifiedName.get(qualifiedName),
        table.tableId,
        table.tableName
      );
      const chip = tagChipPalette(table.tag);

      selectedTables.push({
        id: table.tableId,
        name: table.tableName,
        schema,
        database,
        rowCount: table.rows ?? "—",
        colCount: columnItems.length || table.columns || 0,
        columns: columnItems,
        tag: table.tag ?? "Source",
            tagBg: chip.tagBg,
            tagFg: chip.tagFg,
          });
        }

    const derived: TableMeta[] = (derivedSources || [])
      .filter((source) => source.isSelected)
      .map((source) => {
        const chip = tagChipPalette("Derived");
        const columns = normalizeColumns(source.columns, source.id, source.sourceName);
        return {
          id: source.id,
          name: source.sourceName,
          schema: "DERIVED",
          database: "DERIVED",
          rowCount: "—",
          colCount: columns.length,
          columns,
          tag: "Derived",
          tagBg: chip.tagBg,
          tagFg: chip.tagFg,
        };
      });

    return [...selectedTables, ...derived];
  }, [derivedSources, fullData, sourceAttributeGroups, sources]);

  const activeTables = useMemo(() => {
    const source = tables ?? contextTables;
    return source.map((table, idx) => {
      const tableId =
        table.id ?? `${table.database ?? "db"}:${table.schema ?? "schema"}:${table.name ?? idx}`;
      const tag = table.tag ?? "Source";
      const chip = tagChipPalette(tag);
      const tableName = table.name ?? "—";

      return {
        ...table,
        id: tableId,
        tag,
        tagBg: table.tagBg ?? chip.tagBg,
        tagFg: table.tagFg ?? chip.tagFg,
        rowCount: table.rowCount ?? "—",
        colCount: table.colCount ?? table.columns?.length ?? 0,
        columns: normalizeColumns(table.columns, tableId, tableName),
      };
    });
  }, [contextTables, tables]);

  const sourceStore = useStore<RootState>();
  const handleApplyPreviewSql = useCallback(async (sqlText: string) => {
    const inputSignature = selectionValidationSignature(sourceStore.getState().sttmBuilder);
    if (tables || onJoinsChange) {
      throw new Error("SQL-to-UI sync is only available in the main source-selection workspace.");
    }
    const sequence = ++sourceApplySequence.current;
    const response = await api.post("/v1/derived-sources/parse", { sql: sqlText,
      existing_derived_sources: derivedSources.filter(source => source.isSelected).map(source => ({
        relation_id: source.id, alias: relationAliasFor(source.id, source.sourceName), sql_text: source.sqlText,
      })),
    });
    if (sequence !== sourceApplySequence.current || activeSttmId !== sourceApplyMapping.current || selectionValidationSignature(sourceStore.getState().sttmBuilder) !== inputSignature) {
      throw new Error("The workspace changed while SQL was being parsed. No changes were applied.");
    }
    const parsed = response.data;
    const references = (parsed.source_tables as string[]).map((identifier) => {
      const matches = allPhysicalTables.filter((table) => {
        const fqn = renderSqlIdentifier([table.database ?? '', table.schema ?? '', table.name ?? '']);
        return sqlIdentifierSuffixMatches(fqn, identifier);
      });
      if (matches.length !== 1) throw new Error(`Resolve source identity before applying SQL: ${identifier}`);
      return {raw_identifier: identifier, resolved_fqn: renderSqlIdentifier([matches[0].database ?? '', matches[0].schema ?? '', matches[0].name ?? '']),
        resolution_status: "resolved", reference_role: "source"};
    });
    const workspace = buildSqlUploadWorkspace({asset_id: `source-${activeSttmId ?? 'new'}`, parsed_summary: parsed,
      import_preview: {sql: sqlText, table_references: references}}, {existingDerivedSources: derivedSources});
    applyParsedSqlWorkspace({...workspace, preserveMappingRows: true, sourceQuerySql: sqlText});
    return {
      validationContext: selectionValidationSignature(sourceStore.getState().sttmBuilder),
      message: `Applied ${workspace.sourceTableFqns.length} sources, ${workspace.derivedSources.length} CTEs and ${workspace.relationships.length} outer joins. CTE-internal predicates remain in their own scopes.`,
    };
  }, [
    activeSttmId,
    applyParsedSqlWorkspace,
    sourceStore,
    allPhysicalTables,
    derivedSources,
    onJoinsChange,
    tables,
  ]);

  const currentJoins = joins ?? relationships;
  const setJoinState = useCallback(
    (next: JoinConfig[] | ((prev: JoinConfig[]) => JoinConfig[])) => {
      if (onJoinsChange) {
        const resolved = typeof next === "function" ? next(currentJoins) : next;
        onJoinsChange(resolved);
        return;
      }
      setRelationships(typeof next === "function" ? next(currentJoins) : next);
    },
    [currentJoins, onJoinsChange, setRelationships]
  );

  useEffect(() => {
    if (isRowJoinReview) return;
    if (!effectiveDrivingTableId || !currentJoins.some((join) => join.rightTableId === effectiveDrivingTableId)) {
      return;
    }
    setJoinState(currentJoins.map((join) => orientJoinToDrivingLeft(join, effectiveDrivingTableId)));
  }, [currentJoins, effectiveDrivingTableId, setJoinState, isRowJoinReview]);

  useEffect(() => {
    if (isRowJoinReview) return;
    const ids = new Set(activeTables.map((table) => table.id));
    const filterJoins = (prev: JoinConfig[]) =>
      prev.filter(
        (join) =>
          !!join.leftTableId &&
          !!join.rightTableId &&
          ids.has(join.leftTableId) &&
          ids.has(join.rightTableId)
      );

    if (onJoinsChange) {
      const filtered = filterJoins(currentJoins);
      if (filtered.length !== currentJoins.length) {
        onJoinsChange(filtered);
      }
      return;
    }

    const filtered = filterJoins(currentJoins);
    if (filtered.length !== currentJoins.length) {
      setRelationships(filtered);
    }
  }, [activeTables, currentJoins, onJoinsChange, setRelationships, isRowJoinReview]);

  useEffect(() => {
    if (!isRowJoinReview) return;
    const intent = readJoinReview(window.sessionStorage, activeProjectId, activeSttmId);
    if (!intent || intent.status !== 'pending' || openedRowJoinIntent.current === intent.id) return;
    // Restore the external navigation intent after the canvas has mounted.
    const timer = window.setTimeout(() => {
      if (openedRowJoinIntent.current === intent.id) return;
      openedRowJoinIntent.current = intent.id;
      setRowJoinIntent(intent);
      setEditingJoin(joinReviewDraft(intent, sqlCatalogTables.map(table => String(table.id)), currentJoins));
      setIsJoinModalOpen(true);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [isRowJoinReview, activeProjectId, activeSttmId, activeTables, currentJoins, sqlCatalogTables]);

  const inspectedTable = useMemo(
    () => activeTables.find((table) => table.id === inspectedTableId) ?? null,
    [activeTables, inspectedTableId],
  );
  // Derived rather than stored: if the inspected table is deselected, inspect
  // mode falls away on its own instead of leaving every card dimmed.
  const activeInspectedId = (inspectedTable?.id as string | undefined) ?? null;

  const inspectorJoinChips = useMemo(() => {
    if (!inspectedTableId) return [];
    const nameById = new Map(
      activeTables.map((table) => [table.id as string, table.name ?? "—"]),
    );
    // A table pair can carry many joins (one per condition set), so collapse
    // them into a single chip per counterpart + join type with a count.
    const grouped = new Map<string, { id: string; label: string; count: number }>();

    for (const join of currentJoins) {
      const isLeft = join.leftTableId === inspectedTableId;
      const isRight = join.rightTableId === inspectedTableId;
      if (!isLeft && !isRight) continue;

      const otherId = isLeft ? join.rightTableId : join.leftTableId;
      const joinType = join.joinType ?? "INNER";
      const key = `${joinType}:${otherId ?? ""}`;
      const existing = grouped.get(key);
      if (existing) {
        existing.count += 1;
        continue;
      }
      grouped.set(key, {
        id: key,
        label: `${joinType} → ${nameById.get(otherId as string) ?? otherId ?? "—"}`,
        count: 1,
      });
    }

    return [...grouped.values()];
  }, [activeTables, currentJoins, inspectedTableId]);

  const inspectorJoinConditionColumns = useMemo(() => {
    if (!inspectedTableId) return [];
    const columns = new Set<string>();
    for (const join of currentJoins) {
      const isLeft = join.leftTableId === inspectedTableId;
      const isRight = join.rightTableId === inspectedTableId;
      if (!isLeft && !isRight) continue;
      for (const condition of join.conditions ?? []) {
        const column = isLeft ? condition.leftColumn : condition.rightColumn;
        if (column) columns.add(column);
      }
    }
    return [...columns];
  }, [currentJoins, inspectedTableId]);

  const layoutPositions = useMemo(
    () =>
      buildRelationshipLayout(
        activeTables.map((table) => table.id as string),
        effectiveDrivingTableId,
        currentJoins,
        RELATIONSHIP_LAYOUT_FULL,
      ),
    [activeTables, currentJoins, effectiveDrivingTableId],
  );

  const initialNodes = useMemo(() => {
    return activeTables.map((table, tableIndex) => {
      const isDriving = table.id === effectiveDrivingTableId;
      const chip = tagChipPalette(table.tag ?? "Source");
      // Same palette the Data Lineage cards use: driving reads as the focal
      // (blue) card, derived sources amber, the rest cycle the source accents.
      const cardKind = isDriving
        ? "target"
        : table.schema === "DERIVED"
          ? "derived"
          : "source";
      const cardTheme = getTableCardTheme(
        cardKind,
        LINEAGE_SOURCE_ACCENTS[tableIndex % LINEAGE_SOURCE_ACCENTS.length],
      );

      return {
      id: table.id as string,
      type: "tableNode",
      position: layoutPositions[table.id as string] ?? { x: 48, y: 48 },
      data: {
        label: table.name ?? "—",
        schema: table.schema ?? "—",
        database: table.database ?? "—",
        tag: isDriving ? "Driving" : table.tag ?? "Source",
        tagBg: table.tagBg ?? chip.tagBg,
        tagFg: table.tagFg ?? chip.tagFg,
        rowCount: table.rowCount ?? "—",
        colCount: table.colCount ?? table.columns?.length ?? 0,
        columns: table.columns ?? [],
        selectableColumns,
        selectedColumns: selectedColumnsByTable[table.id as string] ?? [],
        onToggleColumn:
          selectableColumns && onToggleColumn
            ? (columnName: string, checked: boolean) =>
                onToggleColumn(table.id as string, columnName, checked)
            : undefined,
        onEdit:
          allowDerivedEditing && table.schema === "DERIVED"
            ? () => {
                const source = derivedSources.find((item) => item.id === table.id);
                if (source) {
                  setEditingDerivedSource(source);
                  setIsDerivedModalOpen(true);
                }
              }
            : undefined,
        variant: "lineage" as const,
        metaLabel: `${table.schema ?? "—"} · ${table.database ?? "—"}`,
        hideBadge: true,
        showTagChip: true,
        accentColor: cardTheme.accentColor,
        surfaceTint: "#ffffff",
        headerBg: cardTheme.headerBg,
        iconBg: cardTheme.iconBg,
        iconColor: cardTheme.iconColor,
        badgeBg: cardTheme.badgeBg,
        badgeFg: cardTheme.badgeFg,
        pillBg: cardTheme.pillBg,
        pillBorder: cardTheme.pillBorder,
        pillFg: cardTheme.pillFg,
        // Clicking the open card again collapses it back to the summary pill.
        onInspect: () =>
          setInspectedTableId((previous) =>
            previous === (table.id as string) ? null : (table.id as string),
          ),
        inspected: activeInspectedId === table.id,
        dimmed: activeInspectedId !== null && activeInspectedId !== table.id,
        // The column browser opens inside the card instead of a side panel.
        inlineInspector: true,
        joinChips: activeInspectedId === table.id ? inspectorJoinChips : undefined,
        joinConditionColumns:
          activeInspectedId === table.id ? inspectorJoinConditionColumns : undefined,
      } satisfies TableNodeData,
    };
    });
  }, [
    activeInspectedId,
    activeTables,
    allowDerivedEditing,
    derivedSources,
    effectiveDrivingTableId,
    inspectorJoinChips,
    inspectorJoinConditionColumns,
    layoutPositions,
    onToggleColumn,
    selectableColumns,
    selectedColumnsByTable,
  ]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);

  useEffect(() => {
    setNodes((previousNodes) =>
      mergeRelationshipNodePositions(
        initialNodes,
        previousNodes,
        layoutPositions,
        RELATIONSHIP_LAYOUT_FULL,
        {
          joins: currentJoins,
          drivingTableId: effectiveDrivingTableId,
        },
      ),
    );
  }, [currentJoins, effectiveDrivingTableId, initialNodes, layoutPositions, setNodes]);

  /**
   * One canvas line per table pair. A dense mapping can carry hundreds of joins
   * between a handful of tables, and drawing each one turns the graph into a
   * hairball — the count lives on the edge instead.
   */
  const joinPairGroups = useMemo(() => {
    const groups = new Map<string, JoinPairGroup>();

    for (const join of currentJoins) {
      const first = join.conditions?.[0];
      if (!join.id || !join.leftTableId || !join.rightTableId) continue;
      if ((!first?.leftColumn || !first?.rightColumn) && !join.sqlPredicate) continue;

      const key = [join.leftTableId, join.rightTableId].sort().join("|");
      const existing = groups.get(key);
      if (existing) {
        existing.joins.push(join);
        continue;
      }
      groups.set(key, {
        key,
        leftTableId: join.leftTableId,
        rightTableId: join.rightTableId,
        joins: [join],
      });
    }

    return [...groups.values()];
  }, [currentJoins]);

  const joinPairLabel = useCallback(
    (group: JoinPairGroup) => {
      const nameOf = (tableId: string) =>
        activeTables.find((table) => table.id === tableId)?.name ?? tableId;
      return `${nameOf(group.leftTableId)} ↔ ${nameOf(group.rightTableId)}`;
    },
    [activeTables],
  );

  const derivedEdges: Edge[] = useMemo(() => {
    const nodeXById = new Map(nodes.map((node) => [node.id, node.position.x]));
    const touchesInspected = (...tableIds: Array<string | undefined>) =>
      activeInspectedId === null || tableIds.includes(activeInspectedId);

    const joinEdges = joinPairGroups
      .map((group) => {
        const leftTable = activeTables.find((table) => table.id === group.leftTableId);
        const rightTable = activeTables.find((table) => table.id === group.rightTableId);

        // Attach on the near side so a right-to-left join stops looping around.
        const forward =
          (nodeXById.get(group.rightTableId) ?? 0) >= (nodeXById.get(group.leftTableId) ?? 0);
        const sourceHandle = resolveTableHeaderHandleId(
          leftTable,
          "source",
          forward ? "right" : "left",
        );
        const targetHandle = resolveTableHeaderHandleId(
          rightTable,
          "target",
          forward ? "left" : "right",
        );
        if (!sourceHandle || !targetHandle) return null;

        const joinTypes = new Set(group.joins.map((join) => join.joinType ?? "INNER"));
        const joinType = joinTypes.size === 1 ? [...joinTypes][0] : "MIXED";
        const joinCount = group.joins.length;
        const leftName = leftTable?.name ?? group.leftTableId;
        const rightName = rightTable?.name ?? group.rightTableId;

        return {
          id: `pair:${group.key}`,
          source: group.leftTableId,
          target: group.rightTableId,
          sourceHandle,
          targetHandle,
          type: "tableEdge",
          data: {
            joinType,
            joinCount,
            conditionCount: group.joins.reduce(
              (total, join) => total + (join.sqlPredicate && !join.conditions?.length ? 1 : (join.conditions?.length ?? 0)),
              0,
            ),
            muted: !touchesInspected(group.leftTableId, group.rightTableId),
            label: `${leftName} → ${rightName} · ${joinCount} ${joinType} join${
              joinCount === 1 ? "" : "s"
            }`,
            onDelete: () => setPendingPairDelete(group),
            onEdit: () => {
              if (joinCount === 1) {
                setEditingJoin(group.joins[0]);
                setIsJoinModalOpen(true);
                return;
              }
              setJoinFilterPair(group);
              setIsJoinDefinitionsOpen(true);
            },
          },
          markerEnd: { type: MarkerType.ArrowClosed, color: "#cbd5e1" },
        } satisfies Edge;
      })
      .filter(Boolean) as Edge[];

    const lineageEdges: Edge[] = (derivedSources || [])
      .filter((source) => source.isSelected)
      .flatMap((source) => {
        const sourceTableIds = source.tableIds ?? [];
        return sourceTableIds
          .filter((tableId) => activeTables.some((table) => table.id === tableId))
          .map((tableId, index) => ({
            id: `derived-lineage:${source.id}:${tableId}:${index}`,
            source: tableId,
            target: source.id,
            type: "tableEdge",
            data: {
              joinType: "DERIVED",
              label: tableId === source.drivingTableId ? "DRIVING → DERIVED" : "SOURCE → DERIVED",
              readOnly: true,
              muted: !touchesInspected(tableId, source.id),
              conditionCount: 1,
            },
            markerEnd: { type: MarkerType.ArrowClosed, color: "#16a34a" },
          }));
      });

    // Lineage first so real joins paint on top of the dashed hints.
    return [...lineageEdges, ...joinEdges];
  }, [activeInspectedId, activeTables, derivedSources, joinPairGroups, nodes]);

  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([]);

  useEffect(() => {
    setEdges(derivedEdges);
  }, [derivedEdges, setEdges]);

  const onConnect = useCallback(
    (params: Connection) => {
    const leftTableId = params.source;
    const rightTableId = params.target;
      const leftColumn = parseHandleId(params.sourceHandle, "source");
      const rightColumn = parseHandleId(params.targetHandle, "target");
      const fromHeader =
        isTableHeaderHandle(params.sourceHandle) || isTableHeaderHandle(params.targetHandle);

      if (!leftTableId || !rightTableId) return;
      if (!fromHeader && (!leftColumn || !rightColumn)) return;

      const existing = currentJoins.find(
        (join) => join.leftTableId === leftTableId && join.rightTableId === rightTableId
    );
    setEditingJoin(
      existing ?? {
        id: `${leftTableId}__${rightTableId}`,
        leftTableId,
        rightTableId,
        joinType: "LEFT",
          source: "USER_DEFINED",
          locked: false,
          conditions:
            leftColumn && rightColumn
              ? [{ leftColumn, operator: "=", rightColumn }]
              : [{ leftColumn: "", operator: "=", rightColumn: "" }],
      }
    );
    setIsJoinModalOpen(true);
    },
    [currentJoins]
  );

  const joinLegend = [
    { label: "INNER JOIN", bg: "#111827" },
    { label: "LEFT JOIN", bg: "#1e40af" },
    { label: "RIGHT JOIN", bg: "#0d9488" },
    { label: "FULL JOIN", bg: "#9333ea" },
    { label: "DERIVED", bg: "#16a34a" },
  ];

  const joinCount = currentJoins.length;
  // Uploaded names stop needing qualification once a same-named table is added.
  const pendingQualification = unresolvedSourceTables.filter((identifier) => {
    const tableName = identifier.split(".").pop()?.replace(/"/g, "").toUpperCase() ?? "";
    return !activeTables.some((table) => String(table.name ?? "").toUpperCase() === tableName);
  });
  const joinBadgeLabel = joinCount === 1 ? "1 join" : `${joinCount} joins`;
  const selectedDerivedById = useMemo(
    () => new Map((derivedSources ?? []).filter((source) => source.isSelected).map((source) => [source.id, source])),
    [derivedSources],
  );
  const unresolvedDerived = [...selectedDerivedById.values()].find(
    (source) => !source.sqlText?.trim() && !source.physicalViewName?.trim(),
  );
  const previewRelations = activeTables.map((table) => {
    const derived = selectedDerivedById.get(table.id as string);
    const identity = derived?.id ?? (String(table.id).startsWith('sql-instance:') ? String(table.id) : renderSqlTableReference(table));
    return { identity, alias: relationAliasFor(identity, derived?.sourceName), displaySeed: derived?.sourceName };
  });
  const relationshipQueryPreviewSql = useMemo(() => {
    return buildRelationshipQuery(activeTables, currentJoins, effectiveDrivingTableId, (table) => {
      const derived = selectedDerivedById.get(table.id as string);
      const source = derived?.physicalViewName?.trim() || renderSqlTableReference(table);
      return { source, alias: relationAliasFor(derived?.id ?? (String(table.id).startsWith('sql-instance:') ? String(table.id) : source), derived?.sourceName) };
    }, Boolean(sourceQueryModifiers?.distinct));
  }, [activeTables, currentJoins, effectiveDrivingTableId, selectedDerivedById, sourceQueryModifiers]);

  const expandedPreview = useMemo(() => {
    const selectedDerived = (derivedSources ?? []).filter(
      (source) => source.isSelected && source.sqlText?.trim() && activeTables.some((table) => table.id === source.id),
    );
    if (!selectedDerived.length) return null;
    const aliases = new Map<string, string>();
    for (const source of selectedDerived) {
      aliases.set(source.id, relationAliasFor(source.id, source.sourceName));
    }
    const query = buildRelationshipQuery(
      activeTables,
      currentJoins,
      effectiveDrivingTableId,
      (table) => {
        const derivedAlias = aliases.get(table.id as string);
        if (derivedAlias) return { source: derivedAlias, alias: derivedAlias };
        const derived = selectedDerivedById.get(table.id as string);
        const source = derived?.physicalViewName?.trim() || renderSqlTableReference(table);
        return { source, alias: relationAliasFor(derived?.id ?? (String(table.id).startsWith('sql-instance:') ? String(table.id) : source), derived?.sourceName) };
      },
      Boolean(sourceQueryModifiers?.distinct),
    );
    const ctes = selectedDerived.map((source) => {
      const sql = (source.sqlText ?? "").trim().replace(/;\s*$/, "");
      return `${aliases.get(source.id)} AS (\n${sql.split("\n").map((line) => `  ${line}`).join("\n")}\n)`;
    });
    const replacements = Object.fromEntries(
      selectedDerived.flatMap((source) => [
        [`CTE.CTE.${source.sourceName}`, aliases.get(source.id) as string],
        [`DERIVED.DERIVED.${source.sourceName.replace(/\s+/g, '_')}`, aliases.get(source.id) as string],
      ]),
    );
    return { sql: `WITH\n${ctes.join(",\n")}\n${query}`, replacements };
  }, [activeTables, currentJoins, derivedSources, effectiveDrivingTableId, selectedDerivedById, sourceQueryModifiers]);

  // Inline derived SQL/CTEs in the default runtime query. A synthetic
  // CTE.CTE reference is a canvas identity, not an executable object.
  const queryPreviewSql = unresolvedDerived
    ? `-- Derived source ${unresolvedDerived.sourceName} needs SQL or a physical view before validation.`
    : expandedPreview?.sql ?? relationshipQueryPreviewSql;

  const projectionRevision = JSON.stringify([activeTables.map(table=>table.id), currentJoins.map(join=>({left:join.leftTableId,right:join.rightTableId,type:join.joinType,conditions:join.conditions,predicate:join.sqlPredicate})), effectiveDrivingTableId,
    derivedSources.filter(source=>source.isSelected).map(source=>({id:source.id,sql:source.sqlText,view:source.physicalViewName})),sourceQueryModifiers]);
  const lastProjectionRevision = useRef(projectionRevision);
  useEffect(() => {
    const changed = lastProjectionRevision.current !== projectionRevision;
    lastProjectionRevision.current = projectionRevision;
    // Mounting, inspecting, and returning from Mapping do not author new SQL.
    if (isRowJoinReview || !changed) return;
    if (queryPreviewSql === sourceQuerySql) {
      return;
    }

    setSourceFilterConditions({
      sql: sourceFilterSql,
      groups: sourceFilterGroups,
      baseSql: queryPreviewSql,
      groupBySql: sourceGroupBySql,
      orderBySql: sourceOrderBySql,
    });
  }, [
    queryPreviewSql,
    setSourceFilterConditions,
    sourceFilterGroups,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    sourceQuerySql,
    projectionRevision,
    isRowJoinReview,
  ]);

  // SQL uploads and "Validate & Run" on directly-edited preview SQL only ever
  // populate sourceFilterSql (the raw WHERE text). Mirror it into structured
  // Filters/Grouping/Sorting groups whenever that WHERE text is fully
  // representable, so the Filters tab does not show "0 root groups" for a
  // predicate that already has real conditions. The raw SQL stays authoritative;
  // this only runs once per distinct WHERE text and never overwrites groups the
  // user has already built or cleared.
  const lastHydratedFilterSqlRef = useRef<string | null>(null);
  useEffect(() => {
    if (isRowJoinReview) return;
    const trimmedFilterSql = sourceFilterSql.trim();
    if (!trimmedFilterSql || sourceFilterGroups.length > 0) {
      lastHydratedFilterSqlRef.current = trimmedFilterSql || null;
      return;
    }
    if (lastHydratedFilterSqlRef.current === trimmedFilterSql) return;
    lastHydratedFilterSqlRef.current = trimmedFilterSql;
    const sqlForHydration = appendPreviewClauses(queryPreviewSql, { whereSql: sourceFilterSql });
    const hydrated = hydrateBuilderFromSql(sqlForHydration, allPhysicalTables);
    if (!hydrated || !hydrated.filterGroups.length) return;
    const hasUnrepresentedLeaf = (groups: RuleGroup[]): boolean => groups.some((group) =>
      group.children.some((child) => (child.type === "group" ? hasUnrepresentedLeaf([child]) : !child.field)));
    if (hasUnrepresentedLeaf(hydrated.filterGroups)) return;
    setSourceFilterConditions({
      sql: sourceFilterSql,
      groups: hydrated.filterGroups,
      baseSql: sourceQuerySql || queryPreviewSql,
      groupBySql: sourceGroupBySql,
      orderBySql: sourceOrderBySql,
    });
  }, [
    isRowJoinReview,
    sourceQuerySql,
    allPhysicalTables,
    queryPreviewSql,
    setSourceFilterConditions,
    sourceFilterGroups,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
  ]);

  return (
    <div className="flex w-full flex-col gap-3">
      {!tables && pendingQualification.length ? (
        <div
          role="status"
          style={{
            border: "1px solid #fcd34d",
            background: "#fffbeb",
            borderRadius: 8,
            padding: "8px 12px",
          }}
        >
          <AiaText sx={{ fontSize: 12, color: "#92400e" }}>
            {`Needs qualification: ${pendingQualification.join(", ")}. `}
            These uploaded tables could not be matched to a DATABASE.SCHEMA. Add them from the
            source catalog to include them in the workspace.
          </AiaText>
        </div>
      ) : null}
      <div
        className="canvas-area"
        style={isRelationshipsExpanded ? undefined : { minHeight: 0 }}
      >
        <div ref={headerRef} className="canvas-area__header">
          <div className="canvas-area__title">
            <AllInclusiveIcon
              sx={{
                fontSize: "calc(var(--aia-card-title-font-size) + 2px)",
                color: "var(--aia-card-title-color)",
                flexShrink: 0,
              }}
              aria-hidden
            />
            <AiaText
              sx={{
                ...sttmSelectTablesTitleSx,
                textTransform: "capitalize",
                ...sttmSelectTablesTitleSx,
              }}
            >
              Table relationships
            </AiaText>
            <AiaChip size="small" color="primary" label={joinBadgeLabel} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <AiaButton
              data-tour={TOUR_TARGETS.sttmAddJoin}
              size="small"
              variant="outlined"
              startIcon={<AllInclusiveIcon sx={{ fontSize: 18 }} />}
            onClick={() => {
              setEditingJoin(null);
                setIsJoinDefinitionsOpen(true);
              }}
              disabled={activeTables.length === 0}
              sx={{ minWidth: 0, boxShadow: "none" }}
              customBorderColor="var(--aia-state-success-color)"
              customColor="var(--aia-state-success-color)"
              customHoverBackgroundColor="var(--aia-state-success-hover-bg)"
            >
              Join Definition
            </AiaButton>
            <AiaIconButton
              size="small"
              onClick={() => setIsRelationshipsExpanded((expanded) => !expanded)}
              aria-expanded={isRelationshipsExpanded}
              aria-label={
                isRelationshipsExpanded
                  ? "Collapse table relationships"
                  : "Expand table relationships"
              }
            >
              {isRelationshipsExpanded ? (
                <KeyboardArrowDownRoundedIcon sx={{ fontSize: 20, color: "#6b7280" }} />
              ) : (
                <KeyboardArrowRightRoundedIcon sx={{ fontSize: 20, color: "#6b7280" }} />
              )}
            </AiaIconButton>
          </div>
        </div>

        {isRelationshipsExpanded ? (
          <>
            <div className="canvas-area__flow-host" style={{ height: flowHostHeight }}>
          {nodes.length === 0 ? (
            <div className="canvas-area__empty" aria-hidden>
                  <div className="canvas-area__empty-inner">{emptyStateText}</div>
            </div>
          ) : null}
              <RelationshipFlowView
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
              />
        </div>

            <AiaResizeHandle
              className="canvas-area__resize-handle"
              direction="vertical"
              onMouseDown={handleCanvasResizeMouseDown}
            />

            <div ref={legendRef} className="canvas-legend">
          <div className="canvas-legend__row">
            <span className="canvas-legend__label">LEGEND:</span>
                {joinLegend.map((item) => (
                  <AiaChip
                    key={item.label}
                    label={item.label}
                    size="small"
                    customColor={item.bg}
                    customBackgroundColor={`color-mix(in srgb, ${item.bg} 12%, #ffffff)`}
                    customBorderColor={`color-mix(in srgb, ${item.bg} 30%, #ffffff)`}
                  />
            ))}
            <span className="canvas-legend__hint">
              <span className="canvas-legend__dash" />
                  No join — click Join Definition or connect column handles
            </span>
            <span className="canvas-legend__key">
              <KeyIcon sx={{ fontSize: 18, color: "#ca8a04" }} />
              Primary Key
            </span>
            <span className="canvas-legend__key">
              <LinkIcon sx={{ fontSize: 18, color: "#9ca3af" }} />
              Foreign Key
            </span>
          </div>
        </div>
          </>
        ) : null}
      </div>

      {showFilters ? (
        <FilterConditions
          tables={activeTables}
          sqlCatalogTables={sqlCatalogTables}
          titleSx={sttmSelectTablesTitleSx}
          initialGroups={sourceFilterGroups}
          previewSql={queryPreviewSql}
          previewRelations={previewRelations}
          preservedClauses={{whereSql: sourceFilterSql, groupBySql: sourceGroupBySql,
            orderBySql: sourceOrderBySql, modifiers: sourceQueryModifiers}}
          previewTourTarget={TOUR_TARGETS.sttmQueryPreview}
          expandedPreviewSql={
            expandedPreview?.sql !== queryPreviewSql ? expandedPreview?.sql : undefined
          }
          expandedReferenceReplacements={expandedPreview?.replacements}
          relationships={currentJoins}
          drivingTableId={effectiveDrivingTableId}
          onApplySql={!tables && !onJoinsChange ? handleApplyPreviewSql : undefined}
          requireSyncForNext={!tables && !onJoinsChange}
          previewRevision={JSON.stringify([activeSttmId, activeTables.map((table) => table.id), currentJoins, effectiveDrivingTableId])}
          onChange={(groups, sql) =>
            setSourceFilterConditions({
              groups,
              // The builder only knows structured conditions. Keep a WHERE
              // clause authored in SQL (for example from an upload) until the
              // user builds structured conditions.
              sql: hasStructuredConditions(groups) || hasStructuredConditions(sourceFilterGroups)
                ? sql
                : sourceFilterSql,
              baseSql: queryPreviewSql,
              groupBySql: sourceGroupBySql,
              orderBySql: sourceOrderBySql,
            })
          }
          onQueryChange={(payload) => {
            if (payload.groupBy.some((item) => item.field)) builderOwnsGroupByRef.current = true;
            if (payload.orderBy.some((item) => item.field)) builderOwnsOrderByRef.current = true;
            setSourceFilterConditions({
              groups: payload.groups,
              sql: hasStructuredConditions(payload.groups) || hasStructuredConditions(sourceFilterGroups)
                ? payload.whereSql
                : sourceFilterSql,
              baseSql: queryPreviewSql,
              // GROUP BY / ORDER BY written in SQL are not represented as
              // builder items; keep them until the user edits these clauses.
              groupBySql: builderOwnsGroupByRef.current ? payload.groupBySql : sourceGroupBySql,
              orderBySql: builderOwnsOrderByRef.current ? payload.orderBySql : sourceOrderBySql,
            });
          }}
        />
      ) : null}

      <JoinDefinitionsModal
        showRecommendations={true}
        isOpen={isJoinDefinitionsOpen}
        onClose={() => {
          setIsJoinDefinitionsOpen(false);
          setJoinFilterPair(null);
        }}
        joins={joinFilterPair ? joinFilterPair.joins : currentJoins}
        filterLabel={joinFilterPair ? joinPairLabel(joinFilterPair) : undefined}
        onClearFilter={joinFilterPair ? () => setJoinFilterPair(null) : undefined}
        tables={activeTables}
        drivingTableId={effectiveDrivingTableId}
        recommendations={relationshipCandidates}
        recommendationsLoading={loadState.relationships === "loading"}
        recommendationsError={errorState.relationships}
        onRetryRecommendations={refreshRelationships}
        onCreateJoin={() => {
          setEditingJoin(null);
          setIsJoinModalOpen(true);
        }}
        onEditJoin={(join) => {
          setEditingJoin(join);
          setIsJoinModalOpen(true);
        }}
        onDeleteJoin={(joinId) => {
          setJoinState((prev) => prev.filter((item) => item.id !== joinId));
        }}
        onAcceptRecommendation={(join) => {
          setJoinState((prev) => {
            const next = prev.filter((item) => item.id !== join.id);
            return [
              ...next,
              {
                ...join,
                source: join.source ?? "SEMANTIC_VIEW",
                reviewRequired: false,
                locked: join.locked ?? false,
              },
            ];
          });
          acceptRelationshipCandidate(join);
          window.setTimeout(() => refreshAssistantSignals("join_completed"), 0);
        }}
      />

      <JoinModal
        requireJoinTypeSelection={Boolean(rowJoinIntent)}
        isOpen={isJoinModalOpen}
        onClose={() => {
          setIsJoinModalOpen(false);
          setEditingJoin(null);
          if (rowJoinIntent && savedRowJoinIntent.current !== rowJoinIntent.id) {
            window.sessionStorage.removeItem(JOIN_REVIEW_KEY);
            reviewRouter.push(rowReviewUrl(rowJoinIntent.base,rowJoinIntent.mappingId,'suggestions'));
          }
        }}
        onBack={rowJoinIntent ? undefined : () => {
          setIsJoinModalOpen(false);
          setEditingJoin(null);
          setIsJoinDefinitionsOpen(true);
        }}
        tables={rowJoinIntent ? sqlCatalogTables : activeTables}
        drivingTableIdOverride={effectiveDrivingTableId}
        editingJoin={editingJoin}
        previewRelations={previewRelations}
        allowSqlPredicate
        confirmAddsJoin={
          !!editingJoin
          && !currentJoins.some((item) => item.id === editingJoin.id)
        }
        onConfirm={(join: JoinConfig) => {
            if (rowJoinIntent) {
              savedRowJoinIntent.current = rowJoinIntent.id;
              saveReviewedJoin({...join,recommendationId:rowJoinIntent.suggestionId});
            }
            else setJoinState((prev) => {
              const updated = {...join, reviewRequired: false, source: join.source ?? "USER_DEFINED" as const};
              if (prev.some((item) => item.id === join.id)) return prev.map((item) => item.id === join.id ? updated : item);
              const next = prev;
              return [
                ...next,
                {
                  ...join,
                  source: join.source ?? "USER_DEFINED",
                  locked: join.locked ?? false,
                },
              ];
            });
            window.setTimeout(() => refreshAssistantSignals("join_completed"), 0);
            if (rowJoinIntent) {
              window.sessionStorage.setItem(JOIN_REVIEW_KEY,JSON.stringify({...rowJoinIntent,status:'saved'}));
              reviewRouter.push(`${rowReviewUrl(rowJoinIntent.base,rowJoinIntent.mappingId,'suggestions')}&joinReviewed=1`);
            }
          }}
        />

      <WorkspaceRemoveConfirmDialog
        open={pendingPairDelete !== null}
        kind="join"
        mode="selected"
        count={pendingPairDelete?.joins.length ?? 0}
        onClose={() => setPendingPairDelete(null)}
        onConfirm={() => {
          const removedIds = new Set(
            (pendingPairDelete?.joins ?? []).map((join) => join.id),
          );
          setJoinState((prev) => prev.filter((item) => !removedIds.has(item.id)));
          setPendingPairDelete(null);
        }}
      />

      {allowDerivedEditing ? (
        <AddDerivedModal
          isOpen={isDerivedModalOpen}
          onClose={() => {
            setIsDerivedModalOpen(false);
            setEditingDerivedSource(null);
          }}
          editingSource={editingDerivedSource}
          onConfirm={(source) => {
            updateDerivedSource(source);
            setIsDerivedModalOpen(false);
            setEditingDerivedSource(null);
          }}
        />
      ) : null}
    </div>
  );
}
