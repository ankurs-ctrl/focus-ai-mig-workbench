"""Executable smoke tests for the dependency contracts in the cumulative overlay."""

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from app.agent_runtime.execution import ExecutionBudget
from app.agent_tools.source_readiness import declared_derived_bindings, resolve_proposal_reference
from app.auth import custom_oauth
from app.core.exceptions import DelegatedCredentialsRotated, DelegatedSessionRequired


def test_delegated_guard_uses_supplied_reader_and_checks_rotated_or_revoked_session(monkeypatch):
    fallback = Mock(side_effect=AssertionError("Unexpected standalone session lookup"))
    monkeypatch.setattr(custom_oauth, "_session_select_row", fallback)
    monkeypatch.setattr(custom_oauth, "decrypt_access_token", lambda record, _: record.test_token)
    record = SimpleNamespace(
        is_active=True,
        snowflake_user="ALICE",
        snowflake_role="ROLE",
        access_token_expires_at=datetime.now(UTC) + timedelta(hours=1),
        test_token="original",
    )
    reader = Mock(return_value=record)
    guard = custom_oauth.delegated_session_guard(
        "session", "ALICE", "ROLE", "original", None, interval_seconds=0, record_reader=reader,
    )
    guard()
    reader.assert_called_once_with("session")
    record.test_token = "rotated"
    with pytest.raises(DelegatedCredentialsRotated):
        guard()
    reader.return_value = None
    with pytest.raises(DelegatedSessionRequired):
        guard()
    fallback.assert_not_called()


def test_execution_counters_continue_from_restored_usage():
    budget = ExecutionBudget(
        model_limit=2, tool_limit=2,
        category_usage={"meaningful_progress": 3, "source_discovery": 1},
    )
    budget.record_progress()
    budget.record_execution_marker("source_discovery")
    budget.record_execution_marker("source_discovery")
    usage = budget.structured_snapshot()
    assert usage["category_meaningful_progress"] == 4
    assert usage["category_source_discovery"] == 3
    assert budget.snapshot() == (0, 0)


def test_source_readiness_accepts_current_alias_and_rejects_foreign_reference():
    from app.core.workspace_snapshot import relation_alias_for

    table = "DB.S.CONTACTS"
    alias = relation_alias_for(table)
    assert resolve_proposal_reference(f"src:{alias}.NAME", {table}, set()) == f"{table}.NAME"
    assert resolve_proposal_reference("src:unverified.NAME", {table}, set()) is None
    assert declared_derived_bindings([], {table}, verified_source_columns={"DB.S.CONTACTS": {"NAME": "VARCHAR"}}) == set()
