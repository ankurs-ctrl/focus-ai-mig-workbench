'use client';

import { AiaBox, AiaButton, AiaIconButton } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { CloseOutlinedIcon } from '@/utils/icons';
import { textStyleCssVars } from '@/config/typography-tokens';

type MappingChangeConfirmDialogProps = {
  open: boolean;
  targetColumn: string;
  actionDescription: string;
  title?: string;
  leadIn?: string;
  confirmLabel?: string;
  busy?: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

export function MappingChangeConfirmDialog({
  open,
  targetColumn,
  actionDescription,
  title = 'Change transform rule?',
  leadIn = 'already has Source Column values.',
  confirmLabel = 'Continue',
  busy = false,
  onClose,
  onConfirm,
}: MappingChangeConfirmDialogProps) {
  if (!open) {
    return null;
  }

  return (
    <AiaBox
      role="dialog"
      aria-modal="true"
      aria-busy={busy}
      aria-label={title}
      onClick={busy ? undefined : onClose}
      sx={{
        position: 'fixed',
        inset: 0,
        zIndex: 1400,
        px: 2,
        py: 4,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(15, 23, 42, 0.42)',
        backdropFilter: 'blur(4px)',
      }}
    >
      <AiaBox
        onClick={(event) => event.stopPropagation()}
        sx={{
          width: '100%',
          maxWidth: 480,
          borderRadius: '16px',
          border: '1px solid rgba(15, 23, 42, 0.08)',
          boxShadow: '0 30px 60px rgba(15, 23, 42, 0.18)',
          overflow: 'hidden',
          backgroundColor: '#FFFFFF',
        }}
      >
        <AiaBox
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: 1.5,
            px: 2.5,
            py: 2,
            borderBottom: '1px solid #EEF2F7',
          }}
        >
          <AiaText
            sx={{
              ...textStyleCssVars('cardTitle'),
              letterSpacing: '-0.01em',
            }}
          >
            {title}
          </AiaText>
          <AiaIconButton
            onClick={busy ? undefined : onClose}
            disabled={busy}
            aria-label="Close"
            sx={{
              width: 32,
              height: 32,
              border: '1px solid #E2E8F0',
              color: '#64748B',
              bgcolor: '#FFFFFF',
              '&:hover': { bgcolor: '#F8FAFC' },
            }}
          >
            <CloseOutlinedIcon sx={{ fontSize: 18 }} />
          </AiaIconButton>
        </AiaBox>

        <AiaBox sx={{ px: 2.5, py: 2.25 }}>
          <AiaText sx={{ fontSize: 14, color: '#334155', lineHeight: 1.6 }}>
            <AiaText component="span" sx={{ fontWeight: 700, color: '#0f172a' }}>
              {targetColumn}
            </AiaText>
            {leadIn ? (
              <>
                {' '}
                {leadIn}
              </>
            ) : null}
            {' '}
            {actionDescription}
          </AiaText>
        </AiaBox>

        <AiaBox
          sx={{
            px: 2.5,
            py: 2,
            borderTop: '1px solid #EEF2F7',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            gap: 1.25,
          }}
        >
          <AiaButton
            variant="outlined"
            disabled={busy}
            onClick={busy ? undefined : onClose}
            sx={{
              minWidth: 96,
              height: 38,
              borderRadius: '10px',
              borderColor: '#dbe2ea',
              color: '#334155',
              fontSize: 14,
              fontWeight: 600,
              textTransform: 'none',
            }}
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            color="primary"
            onClick={onConfirm}
            disabled={busy}
            sx={{
              minWidth: 120,
              height: 38,
              borderRadius: '10px',
              fontSize: 14,
              fontWeight: 700,
              textTransform: 'none',
            }}
          >
            {busy ? 'Saving…' : confirmLabel}
          </AiaButton>
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
