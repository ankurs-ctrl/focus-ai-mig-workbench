"""Rebuild FIR recipes from immutable current publications; dry-run by default."""
import argparse
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'services/sttm-builder'))


def reproject_publications(session, settings, *, after_version=0, limit=50, execute=False):
    from app.core.project_service import ProjectService
    from app.core.learning_retrieval import invalidate_learning_context_cache
    limit = max(1, min(int(limit), 100))
    rows = session.sql(f'''
        SELECT v.VERSION_ID, v.STTM_ID, s.PROJECT_ID, v.VERSION_PAYLOAD
        FROM {settings.qualify_table_name('TBL_STTM_VERSIONS')} v
        JOIN {settings.qualify_table_name('TBL_STTM')} s
          ON v.STTM_ID = s.STTM_ID AND v.VERSION_NUMBER = s.CURRENT_VERSION
        WHERE v.VERSION_ID > ? AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE
        ORDER BY v.VERSION_ID LIMIT {limit}
    ''', params=[int(after_version)]).collect()
    # Existing published evidence is the only input; no mutable draft or inferred grain.
    service = ProjectService(session=session, settings=settings.model_copy(update={'fir_durable_jobs_v2': False}),
                             memory_service=None)
    report = {'execute': execute, 'versions': [], 'next_after_version': int(after_version)}
    for row in rows:
        value = row.as_dict() if hasattr(row, 'as_dict') else dict(row)
        snapshot = value['VERSION_PAYLOAD']
        snapshot = json.loads(snapshot) if isinstance(snapshot, str) else snapshot
        if not isinstance(snapshot, dict) or not isinstance(snapshot.get('mapping_rows'), list):
            raise ValueError('Published version has no recoverable mapping snapshot.')
        count = None
        if execute:
            count = service._record_target_mapping_patterns(project_id=str(value['PROJECT_ID']),
                sttm_id=str(value['STTM_ID']), snapshot=snapshot, evidence_class='published_mapping',
                validation_status='published', base_confidence=.97, strict=True,
                publication_version_id=str(value['VERSION_ID']))
        report['versions'].append({'version_id': str(value['VERSION_ID']), 'sttm_id': str(value['STTM_ID']),
                                   'mapping_rows': len(snapshot['mapping_rows']), 'projected_patterns': count})
        report['next_after_version'] = int(value['VERSION_ID'])
    if execute and rows:
        invalidate_learning_context_cache()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env', type=Path, required=True)
    parser.add_argument('--namespace', required=True)
    parser.add_argument('--expected-account', required=True)
    parser.add_argument('--after-version', type=int, default=0)
    parser.add_argument('--limit', type=int, default=50)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Z_][A-Z0-9_]*\.[A-Z_][A-Z0-9_]*', args.namespace):
        parser.error('namespace must be canonical DATABASE.SCHEMA')
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    from app.core.config import Settings
    credentials = dotenv_values(args.credential_env)
    database, schema = args.namespace.split('.')
    if credentials.get('SNOWFLAKE_ACCOUNT', '').upper().replace('-', '.') != args.expected_account.upper().replace('-', '.'):
        parser.error('Configured account does not match expected-account')
    token = credentials.get('SNOWFLAKE_PASSWORD', '')
    authenticator = credentials.get('SNOWFLAKE_AUTHENTICATOR') or ('PROGRAMMATIC_ACCESS_TOKEN' if token.startswith('eyJ') else 'snowflake')
    config = dict(account=credentials['SNOWFLAKE_ACCOUNT'], user=credentials['SNOWFLAKE_USER'],
        role=credentials['SNOWFLAKE_ROLE'], warehouse=credentials['SNOWFLAKE_WAREHOUSE'],
        database=database, schema=schema, authenticator=authenticator)
    config['token' if authenticator.lower() == 'programmatic_access_token' else 'password'] = token
    session = Session.builder.configs(config).create()
    try:
        identity = session.sql('SELECT CURRENT_ORGANIZATION_NAME() O, CURRENT_ACCOUNT_NAME() A').collect()[0]
        if f"{identity['O']}.{identity['A']}".upper() != args.expected_account.upper().replace('-', '.'):
            raise PermissionError('Connected account does not match expected-account')
        settings = Settings(_env_file=None, SNOWFLAKE_DATABASE=database, SNOWFLAKE_SCHEMA=schema)
        report = reproject_publications(session, settings, after_version=args.after_version, limit=args.limit, execute=args.execute)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'execute': args.execute, 'versions': len(report['versions']),
                          'next_after_version': report['next_after_version']}))
    finally:
        session.close()


if __name__ == '__main__':
    main()
