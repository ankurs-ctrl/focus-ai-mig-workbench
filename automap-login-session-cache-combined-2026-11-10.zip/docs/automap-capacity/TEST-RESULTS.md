# Verification — 10 November 2026

## Live full mapping: passed

- Separate system test account: `A0581299278961.BBINSIGHT_PARTNER`, warehouse `COMPUTE_WH`; existing PAT read from its local credential file. No credential file is delivered or modified.
- Existing source: `BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION`; existing semantics read from `FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS`.
- All 33 physical columns were targeted, using a logical identity target and nine normal batches: `[3,3,3,4,4,4,4,4,4]`. Each batch owned its SQL session and used the application runtime, model transport, compiler checks and final row-candidate validator. The proxy's normal concurrent batch orchestration and merge were exercised.
- Twelve execution reservations, plus four preserved synthetic legacy quarantines. Actual provider traffic: nine model POSTs and nine thread creations. No transport retries. No failed/incomplete batches. All nine batch callbacks returned.
- 33 proposals, zero unresolved targets, all 33 selected candidates independently `valid`, all selected source names matched the identity target names, and no candidate validation errors.
- All execution reservations were free afterward; the four old quarantine fixtures were unchanged. The dedicated schema/agent fixture was removed after confirming no outstanding real test operations. No business mapping was saved or published.
- Native migration ran twice safely; read-only validation also passed. Wall time for the final full mapping was **140.49 seconds**. The raw report and independently verified aggregate fields are in `LIVE-FULL-MAPPING-RESULT.json`.

This proves local full-table dispatch, complete draft output and capacity cleanup for this fixture. It does not prove client OAuth/SPCS operation, arbitrary business transformation correctness, twelve simultaneous provider calls, or client throughput. Some source evidence pages remained outside the admitted shortlist; that warning is not evidence of absence or a publishing approval. The recorded report's warning-code field was last-batch scoped; it is not an exhaustive business-review checklist.

## Failures found and fixed during live testing

1. A completed model call encountered an archive COMMIT/receipt failure. V2 archive operations now retry content-addressed operations with fresh sessions and unchanged deadlines. Offline tests verify failures before/after commit, no duplicate stored content and no model dispatch from the archive retry. The subsequent two-column rerun passed with one model POST and free execution capacity.
2. Concurrent full-table admission encountered native SQL timeout 630 inside a Snowpark wrapper with `errno=1304`. Both native error attributes are now handled under the existing narrow allowlist, only after acknowledged rollback. Commit/rollback uncertainty remains unreplayable.
3. The first full-table run obtained 33 valid proposals, but stale transient warnings labelled recovered batches failed. Recovery status now requires complete selected valid candidates and a clean current attempt. Invalid replacements keep failure warnings; business/validation warnings are preserved. The final full run passed without transport retries or failed batches.

Three earlier retained scratch operations were inspected using their exact original requests/threads, confirmed terminal and reconciled with no additional model POSTs. Their fixture schemas were then removed; no permits were reset to pretend a remote call had stopped.

## Automated regression checks

Final complete backend suite: **4,771 passed, 31 environment-dependent tests skipped**. Subsequent focused verification of the latest session-reference, recovery, administrator and proxy changes: **312 passed**. Final migration and PowerShell/CI deployment guard verification: **104 passed**. Native Snowpark contention tests and recovered-batch tests also passed. No assertions were removed or weakened.

All 32 frontend regression scripts passed, including 446 tests reported by Node's test runner and the scripts' additional direct assertions. TypeScript `tsc --noEmit --incremental false` passed. No frontend files changed. Existing assertions were retained.

Offline checks cover twelve concurrent execution reservations with four quarantines; the sixteen-call ceiling; duplicate operation identity; fenced handoff rollback; expired dispatcher transfer; exact request/archive reconstruction; lost submission acknowledgements; terminal cancellation inspection; restart recovery; OAuth revocation/user/role boundaries; hashed session references; protocol cutover; durable progress; migration repeatability and read-only validation; administrator authorization; and recovered-batch status without hiding genuine validation failures.

Test environment: existing Python virtualenv, temporary dependency overlay pinned to repository SQLGlot 30.12.0, and official checksum-verified PowerShell 7.6.9 in temporary storage. No repository dependencies, lock files, `.env` files or Snowflake resource monitors were changed for the tests. Existing deprecation/model-field warnings are reported by the suite.
