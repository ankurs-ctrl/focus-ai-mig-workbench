'use client';

import { AiaBox, AiaTableCellPrimitive, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { InfoOutlinedIcon } from '@/utils/icons';
import type { SxProps, Theme } from '@mui/material/styles';
import type { ReactNode } from 'react';

import { getConfidenceGroup, normalizeConfidencePercent } from '../mapping-confidence-groups';

type MappingConfidenceCellProps = {
  confidenceScore?: number | null;
  status?: 'MAPPED' | 'UNMAPPED' | 'PROCESSING';
  reason?: string | null;
  businessMeaning?: string | null;
  manuallyEditedAfterAutoMap?: boolean;
  width?: number | string;
  minWidth?: number | string;
  sx?: SxProps<Theme>;
};

const BAND_COLORS = {
  high: { text: '#166534', bar: '#22c55e', track: '#dcfce7' },
  medium: { text: '#92400e', bar: '#f59e0b', track: '#fef3c7' },
  low: { text: '#b91c1c', bar: '#ef4444', track: '#fee2e2' },
} as const;

function buildTooltipContent({
  confidenceScore,
  reason,
  businessMeaning,
  manuallyEditedAfterAutoMap,
}: {
  confidenceScore: number | null | undefined;
  reason?: string | null;
  businessMeaning?: string | null;
  manuallyEditedAfterAutoMap?: boolean;
}): ReactNode {
  if (confidenceScore == null && !reason && !businessMeaning && !manuallyEditedAfterAutoMap) {
    return null;
  }

  const band =
    confidenceScore == null
      ? null
      : (() => {
          const percent = normalizeConfidencePercent(confidenceScore);
          if (percent == null) return null;
          if (percent >= 80) return 'High confidence';
          if (percent >= 60) return 'Medium confidence';
          return 'Low confidence';
        })();

  return (
    <AiaBox sx={{ display: 'grid', gap: 0.7, whiteSpace: 'normal', overflowWrap: 'anywhere' }}>
      {band ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit', fontWeight: 800 }}>
          {band}
        </AiaText>
      ) : null}
      {manuallyEditedAfterAutoMap ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Manual:</strong> Auto-mapped, then edited manually. Original confidence is kept.
        </AiaText>
      ) : null}
      {businessMeaning ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Business fit:</strong> {businessMeaning}
        </AiaText>
      ) : null}
      {reason ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Why:</strong> {reason}
        </AiaText>
      ) : null}
    </AiaBox>
  );
}

export function MappingConfidenceCell({
  confidenceScore,
  status,
  reason,
  businessMeaning,
  manuallyEditedAfterAutoMap = false,
  width,
  minWidth,
  sx,
}: MappingConfidenceCellProps) {
  const group = getConfidenceGroup(confidenceScore, status);
  const colors = BAND_COLORS[group];
  const percent = normalizeConfidencePercent(confidenceScore);
  const tooltipContent = buildTooltipContent({
    confidenceScore,
    reason,
    businessMeaning,
    manuallyEditedAfterAutoMap,
  });

  return (
    <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx })}>
      {percent == null ? null : (
        <AiaBox
          data-tour={TOUR_TARGETS.sttmConfidenceScore}
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            gap: 0.6,
            minWidth: 0,
            width: '100%',
          }}
        >
          <AiaBox sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: 0.5, flexWrap: 'wrap' }}>
            <AiaText
              sx={{
                fontSize: '0.75rem',
                fontWeight: 800,
                color: colors.text,
                lineHeight: 1.2,
                textAlign: 'left',
              }}
            >
              {`${Math.round(percent)}%`}
            </AiaText>
            {manuallyEditedAfterAutoMap ? (
              <AiaText
                component="span"
                sx={{
                  fontSize: '0.62rem',
                  fontWeight: 700,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                  color: '#475569',
                  bgcolor: '#e2e8f0',
                  borderRadius: '4px',
                  px: 0.55,
                  py: 0.15,
                  lineHeight: 1.3,
                }}
              >
                Manual
              </AiaText>
            ) : null}
            {tooltipContent ? (
              <AiaTooltip
                title={tooltipContent}
                placement="top"
                arrow
                enterDelay={200}
                slotProps={{
                  tooltip: {
                    sx: {
                      fontSize: '0.72rem',
                      maxWidth: 360,
                      lineHeight: 1.5,
                    },
                  },
                }}
              >
                <InfoOutlinedIcon sx={{ fontSize: 15, color: '#64748b', cursor: 'help' }} />
              </AiaTooltip>
            ) : null}
          </AiaBox>
          <AiaBox
            sx={{
              width: '100%',
              height: 6,
              borderRadius: 999,
              bgcolor: colors.track,
              overflow: 'hidden',
            }}
          >
            <AiaBox
              sx={{
                width: `${percent}%`,
                height: '100%',
                borderRadius: 999,
                bgcolor: colors.bar,
                transition: 'width 160ms ease',
              }}
            />
          </AiaBox>
        </AiaBox>
      )}
    </AiaTableCellPrimitive>
  );
}
