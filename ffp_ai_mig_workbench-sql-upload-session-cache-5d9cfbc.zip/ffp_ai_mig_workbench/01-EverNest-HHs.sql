-- EverNest Households migration script re-pointed to cloned sources in FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.
-- Co-authored with CoCo

---- EverNest Households
----****----****----****----****----****----****----****----****----****----****----****----****
//****                      Variables to Update for each new firm:                        ****//
----****----****----****----****----****----****----****----****----****----****----****----****

SET SourceDatabase = 'FFP_HDP_DLAB_DB_DEV';
SET SourceSchema = 'SCH_EVERNEST_HH_SOURCE';

SET ClientStartDate = '2026-01-01';
SET LegacyHHcPrefix = 'EVR_RT_';
SET LegacyContactPrefix = 'EVR_RT_'; -- Legacy_ID__c fields are text (50), SF IDs are 18 char, MSDYNA GUIDs are 36... keep this under 14!

SET Referral = '';
SET BackupOwnerID = '005Qi00000ZBGiAIAX';  -- EverNest default: Niki Woodworth
SET TransactionFirmID = '001PL00000lcYvIYAU'; -- EverNest Ends in ...cYvIYAU transaction firm (needed to create AS a "firm record")
SET ParentOfficeID = '001Qi00001K9yCDIAZ'; -- EverNest Office/Business/Broker Dealer


----****----****----****----****----****----****----****----****----****----****----****----****
//****                                  END SECTION                                       ****//
----****----****----****----****----****----****----****----****----****----****----****----****


----****----****----****----****----****----****----****----****----****----****----****----****
//****                      Core Variables (Generally remain unchanged)                   ****//
----****----****----****----****----****----****----****----****----****----****----****----****

SET CoreMigrationDatabase = 'FFP_HDP_CRM_MIG_DB_DEV';

SET OrionHHIDPrefix = 'Household-1525-';
SET OrionIndvIDPrefix = 'Person-1525-';
SET HHRecordType = '01241000001IBjiAAG'; 
SET BizAcctRecordType = '01241000001IBjhAAG';
SET IndvAcctRecordType = '01241000001IBjjAAG';
SET IndvContactRecordType = '01241000001IBjoAAG';
SET BizContactRecordType = '01241000001IBjnAAG';
SET HHBASeClientCategory = 'Wealth Management Client'; 
SET TASkRecordTypeID = '01241000001IBk4AAG';
SET NoteTASkRecordTypeID = '01241000001IBk4AAG';
SET EventTASkRecordTypeID = '01241000001IBk4AAG';
SET Master_Payout_Date ='1900-01-01';

----****----****----****----****----****----****----****----****----****----****----****----****
//****                                  END SECTION                                       ****//
----****----****----****----****----****----****----****----****----****----****----****----****

USE DATABASE IDENTIFIER($SourceDatabase);
USE SCHEMA   IDENTIFIER($SourceSchema);


----****----****----****----****----****----****----****----****----****----****----****----****
//****                                  Code to Run:                                       ****//
----****----****----****----****----****----****----****----****----****----****----****----****

SET UserMasterTable = CONCAT($SourceSchema , '.MAPPER_USER');
SET HHMasterTable = CONCAT($SourceSchema , '.MAPPER_HH_MASTER');

// Added by Joihn G.
SET ReferralMasterTable = CONCAT($SourceSchema , '.MAPPER_REFERRAL_MASTER');

WITH   UserMaster AS (
    SELECT  * 
    FROM    FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.MAPPER_USER
)

,   HHMaster AS (
        SELECT  *
        FROM FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.MAPPER_HH_MASTER
)

// Added by John G.
,   ReferralMaster AS (
        SELECT  *
        FROM FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.MAPPER_REFERRAL_MASTER
)

,   SOURCE AS (
---------------------------------------------------------------------------------------------------
---- JIM's Code Start------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
    with
    BillingAddress AS (
        SELECT 
            ad.addressable_id AS contact_id,
            COALESCE(ad.street_address, '') || COALESCE(CHR(10) || ad.secondary_address, '') AS billing_street,
            COALESCE(ad.city, '') AS billing_city,
            COALESCE(ad.state, '') AS billing_state,
            COALESCE(ad.zip, '') AS billing_postal_code,
            COALESCE(ad.country, '') AS billing_country // added by John G.
        FROM FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.ADDRESSES ad
        WHERE ad.deleted = 0
          AND ad.is_primary = 1
        QUALIFY ROW_NUMBER() OVER (PARTITION BY ad.addressable_id ORDER BY ad.street_address) = 1
    ),
    FamilyHOH AS (
      SELECT
        cfam2.family_id,
        cfam.id AS hoh_contact_id,
        cs.name as hoh_status
      FROM FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACTS cfam
      JOIN FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILY_MEMBERS cfam2 ON cfam2.contact_id = cfam.id
      join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_STATUSES cs on cs.id = cfam.status_id
       AND COALESCE(cfam2.hoh, 0) = 1
       AND cfam2.deleted = 0
       and cfam.deleted = 0
       and cfam2.family_id not in (2176,2431) //Bug in RT in which contacts are members of multple families
    ),
PrefContactMethod AS (
   select  a.contact_id, 
           a.field_value as pref_contact_method
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 11
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
),
Drinks AS (
   select  a.contact_id, 
           a.field_value as drinks
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 1
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
),
PetName AS (
   select  a.contact_id, 
           a.field_value as petName
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 10
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
),
ContactMadeAwareofFocus AS (
   select  a.contact_id, 
           a.field_value as ContactMadeAwareofFocus
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 13
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
),
AllTaxIDsHaveClientContactRecord AS (
   select  a.contact_id, 
           a.field_value as AllTaxIDsHaveClientContactRecord
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 14
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
),
SIGNEDAdvisoryAgreement AS (
   select  a.contact_id, 
           a.field_value as SIGNEDAdvisoryAgreement
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 15
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
),
FocusLanguageInvestmentAgreement AS (
   select  a.contact_id, 
           a.field_value as FocusLanguageInvestmentAgreement
   from FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDFs a 
   left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_UDF_FIELDS b on a.contact_udf_field_id = b.id
   where b.id = 16
   and a.deleted = 0
   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.contact_id ORDER BY a.created_at) = 1
)
    
    select 
           'HH_' || to_char(c.id) as LegacyHHID,
           c.type,
           cf.id as family_id,
           COALESCE(cf.name, NULLIF(CONCAT(c.last_name, ', ', c.first_name), ', '), c.last_name, c.company_name, '') as family_name, --Added by John G.
           c.first_name, 
           iff(c.last_name is null or c.last_name = '',c.company_name,c.last_name) as LastName,
           cs.id as statusid,
           cs.name as status,
           cfm.hoh,
           c.servicing_advisor_id as AWA,
           sa.name as zzzAWAName,
           COALESCE(c.writing_advisor_id, 2) as PWA,
           COALESCE(wa.name, 'Frank Esposito') as zzzPWAName,
           case 
                when cs.name in ('Client') and c.type = 'Crm::Contact::Individual' then 'Client Relationship'
                when cs.name in ('Client') and c.type = 'Crm::Contact::Business' then 'Institutional Client'
                when cs.name in ('Client') and c.type = 'Crm::Contact::Trust' then 'Institutional Client'
                when cs.name in ('Client') and c.type = 'Crm::Contact::ContactAssociation' then 'Institutional Client'
                else null
           end
           as Household_Type,
            case 
                when cs.name in ('Client') and c.type = 'Crm::Contact::Individual' then 'Wealth Management Client'
                when cs.name in ('Client') and c.type = 'Crm::Contact::Business' then null
                when cs.name in ('Client') and c.type = 'Crm::Contact::Trust' then null
                when cs.name in ('Client') and c.type = 'Crm::Contact::ContactAssociation' then null
                when c.id in (1193,1441) then 'Financial Planning' //Financial Planning Only
                else null
           end as Category,
           b.billing_street,
           b.billing_city,
           b.billing_state,
           b.billing_postal_code,
           b.billing_country, // added by John G.
           'No' as ISRCPClient,
           case 
                when s.name = 'Client Referral' then 'Client Sourced'
                when s.name = 'Networking' then 'Advisor Sourced'
                when s.name = 'COI Referral' then 'COI - Firm Sourced'
                else 'Advisor Sourced'
            end as SourceofBusiness,
           c.referred_by as ReferredBy,
           c.First_Name || ' ' ||iff(c.last_name is null,c.company_name,c.last_name) as mail_merge_first_last,
           iff(c.last_name is null,c.company_name,c.first_name) as mail_merge_first_only,
           c.client_since, 
           c.writing_advisor_id as Owner,
           wa.name as zzzOwnerName,
           case
            when c.id in (444,619,702,1288,1290,1291,168,326,658,659,55,195,1636,2060,1639,1640,1844,2535,1853,1854) then 'Yes' //Make independent HH due to Orion setup
            when c.id in (679,1695,1247,1201,2018,1419,1331,2635,1554,2861,2037,2036,13,2853,2730,1657,2749,2854,1302,2728,1435,1608)  then 'No' //Fold into another HH due to Orion Setup
            when cfm.hoh = 1  then 'Yes' //Is a head of Household
            when cf.id is null then 'Yes' //Belongs to no family
            when cf.id is not null and cfm.hoh = 0 and cfm.relationship = 1 and hoh.hoh_status <> 'Deceased' then 'No' //spouse to Living HOHH
            when cf.id is not null and cfm.hoh = 0 and cfm.relationship = 1 and hoh.hoh_status = 'Deceased' then 'Yes' //spouse to Deceased HOHH
            when cf.id is not null and cfm.hoh = 0 and cfm.relationship != 1 and ((current_date() - c.dob)/365) >= 21.0 then 'Yes'// Belongs to a family; is not the head of household; is not a spouse, and is over 21
            else 'No'
           end as includeHH,
           cpp.next_review_at,
           cc.name,
           case 
            when cc.name = 'Client - 1 Meeting' then 'Annually'
            when cc.name = 'Client - 3 Meetings' then 'Triannually'
            when cc.name = 'Client - 2 Meetings' then 'Semiannually'
            when cc.name = 'Client - 4 Meetings' then 'Quarterly'
            when cc.name = 'Client - 0 Meetings' then 'Only as Needed'
            when cc.name = 'Client - Spouse' then 'Only as Needed'
            when cc.name = 'Client - Employee' then 'Only as Needed'
            when cc.name = 'Inactive - Former Client' then 'Only as Needed'
            when cc.name = 'Client - Related Entity' then 'Only as Needed'
            when cc.name = 'Client - Retirement Plan' then 'Only as Needed'
            else 'Only as Needed'
           end as ReviewFrequency,
           //cpp.review_schedule,
           null as LegacyPortfolioSystemHHID,
           'Preferred Contact Method: ' || coalesce(pm.pref_contact_method ,'') || chr(10) ||
           'Drinks: ' || coalesce(dr.Drinks,'') || chr(10) || 
           'Pet Name: ' || coalesce(pn.PetName,'') || chr(10) ||
           'Contact made aware of Focus: ' || coalesce(af.ContactMadeAwareofFocus,'') || chr(10) ||
           'Do all additional Tax IDs have Client Contact record?: ' || coalesce(ti.AllTaxIDsHaveClientContactRecord,'') || chr(10) ||
           'SIGNED Advisory Agreement: ' ||  coalesce(saa.SIGNEDAdvisoryAgreement,'') || chr(10) ||
           'Focus Language Investment Agreement: ' ||  coalesce(fl.FocusLanguageInvestmentAgreement,'') || chr(10) ||
           'Referred By: ' || c.referred_by
           as LegacyFirmInfo
    from 
    FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACTS c
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_STATUSES cs on cs.id = c.status_id
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILY_MEMBERS cfm on cfm.contact_id = c.id and cfm.deleted = 0
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILIES cf on cf.id = cfm.family_id and cf.deleted = 0
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.SERVICING_ADVISORS sa on sa.id = c.servicing_advisor_id
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.WRITING_ADVISORS wa on wa.id = c.writing_advisor_id
    left join BillingAddress b on b.contact_id = c.id
    left join FamilyHOH hoh on hoh.family_id = cfm.family_id
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.SOURCES s on s.id = c.source_id and s.deleted = 0
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_PERSONAL_PROFILES cpp on cpp.contact_id = c.id
    left join FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.CONTACT_CATEGORIES cc on cc.id = c.category_id
    left join PrefContactMethod as pm on pm.contact_id = c.id
    left join Drinks as dr on dr.contact_id = c.id
    left join PetName as pn on pn.contact_id = c.id
    left join ContactMadeAwareofFocus as af on af.contact_id = c.id
    left join AllTaxIDsHaveClientContactRecord as ti on ti.contact_id = c.id
    left join SIGNEDAdvisoryAgreement as saa on saa.contact_id = c.id
    left join FocusLanguageInvestmentAgreement as fl on fl.contact_id = c.id
    
    where (cs.name in ('Client') or c.id in (1193,1441)) //Planning Only)
    and case
            when c.id in (444,619,702,1288,1290,1291,168,326,658,659,55,195,1636,2060,1639,1640,1844,2535,1853,1854)  then 'Yes' //Make independent HH due to Orion setup
            when c.id in (679,1695,1247,1201,2018,1419,1331,2635,1554,2861,2037,2036,13,2853,2730,1657,2749,2854,1302,2728,1435,1608)  then 'No' //Fold into another HH due to Orion Setup
            when cfm.hoh = 1  then 'Yes' //Is a head of Household
            when cf.id is null then 'Yes' //Belongs to no family
            when cf.id is not null and cfm.hoh = 0 and cfm.relationship = 1 and hoh.hoh_status <> 'Deceased' then 'No' //spouse to Living HOHH
            when cf.id is not null and cfm.hoh = 0 and cfm.relationship = 1 and hoh.hoh_status = 'Deceased' then 'Yes' //spouse to Deceased HOHH
            when cf.id is not null and cfm.hoh = 0 and cfm.relationship != 1 and ((current_date() - c.dob)/365) >= 21.0 then 'Yes'// Belongs to a family; is not the head of household; is not a spouse, and is over 21
            else 'No'
       end = 'Yes'
    and c.deleted = 0
    order by cf.id
---------------------------------------------------------------------------------------------------
---- JIM's Code End--------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
)
-- SELECT * FROM SOURCE


SELECT  DISTINCT     
    ---  START CORE FIELDS ***************************************************************************
        $TransactionFirmID AS "Transaction_Firm__c"
    ,   $ParentOfficeID AS "ParentID"
    ,   $LegacyHHcPrefix || SOURCE.LegacyHHID AS "Legacy_ID__c"
    ,   $ClientStartDate AS "bffs_clientstartdate__c"
    ,   COALESCE(mu.TARGETCRMID, $BackupOwnerID) AS "OwnerId"
    ,   COALESCE(mu.first_name ||  ' ' || mu.last_name, 'Niki Woodworth') AS "xxxOwnerName"
    ,   $HHRecordType AS "RecordTypeId"
    ,   SOURCE.Household_Type AS "Household_Type__c"
    ,   'Current Client' AS "FINSERV__STATUS__C"
    ,   TO_CHAR(TRY_TO_DATE($Master_Payout_Date), 'YYYY-MM-DD') AS "Master_Payout_Date__c"
    ,   SOURCE.CATEGORY "FinServ__ClientCategory__c"
    ,   LEFT(COALESCE(mhm.legacyhhname, SOURCE.family_name),100) AS Name -- LASTNAME || ', ' || FIRSTNAME
    ,   SOURCE.billing_street AS "BillingStreet" 
    ,   SOURCE.billing_city AS "BillingCity"
    ,   sc.state_code AS "BillingState"  
    ,   SOURCE.billing_state AS "xxOGStateCode"
    ,   SOURCE.billing_postal_code AS "BillingPostalCode"
    ,   cc.country_code AS "BillingCountry"
    ,   SOURCE.billing_country AS "xxOGCountryCode"
    ,   mhm.targetcrmhouseholdsourcesystemid AS "DoSeparate__FinServ__SourceSystemId__c"
    ,   SOURCE.LegacyPortfolioSystemHHID as "xxLegacyPortfolioSystemHHID"
    ,   SOURCE.ReviewFrequency AS "FinServ__ReviewFrequency__c"
    ,   client_since AS "bffs_legacystartdate__c"
    -- ,   lAStreview AS "FinServ__LAStReview__c" 
    ,   TO_DATE(NEXT_REVIEW_AT) AS "FinServ__NextReview__c"
    ,   'Electronic' AS "Delivery_Consent__c" 
    ,   'Negative' AS "WAA_Consent__c"
    ,   mail_merge_first_last AS "Mail_Merge_First_and_LASt__c"
    ,   mail_merge_first_only AS "Mail_Merge_First_Only__c"
    ,   IsRCPClient AS "IS_RCP_Client__c"    
    ---  END CORE FIELDS *****************************************************************************
    ,   mrm.salesforceid AS "Referral__c"
    ,   SourceofBusiness AS "xxSourceForReferral"
    ,   SOURCE.LegacyFirmInfo AS "Legacy_Firm_Info__c"
    -- ,   CASE
    --         WHEN SOURCE.ReferredBy IS NOT NULL AND SOURCE.ReferredBy <> '' THEN 'Referred By: ' || ReferredBy 
    --         ELSE NULL 
    --     END AS "Legacy_Firm_Info__c"
FROM SOURCE
LEFT JOIN UserMaster mu
    ON   SOURCE.Owner = mu.WRITING_ADVISOR_ID   
LEFT JOIN FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.COUNTRY_CODES cc
    ON  TRIM(UPPER(cc.COUNTRY_ALIAS)) = TRIM(UPPER(SOURCE.billing_country))
    OR  TRIM(UPPER(cc.country_code)) = TRIM(UPPER(SOURCE.billing_country))
LEFT JOIN FFP_HDP_DLAB_DB_DEV.SCH_EVERNEST_HH_SOURCE.STATE_CODES sc
    ON TRIM(UPPER(SOURCE.billing_state)) = TRIM(UPPER(sc.STATE_ALIAS))
    OR TRIM(UPPER(SOURCE.billing_state)) = TRIM(UPPER(sc.STATE_CODE))
LEFT JOIN HHMaster mhm 
    ON $LegacyHHcPrefix || SOURCE.LegacyHHID = mhm.TargetCRMLegacyID
    -- ON UPPER(SOURCE.LegacyPortfolioSystemHHID) = UPPER('Household-1161-' || TO_VARCHAR(mhm.LEGACYPORTFOLIOACCOUNTID))
    -- ON $LegacyHHcPrefix || SOURCE.LegacyHHID = mhm.LegacyCRMID 
LEFT JOIN ReferralMASter mrm
    ON  SOURCE.SOURCEOFBUSINESS = mrm.REFERRAL_SOURCE__C
    AND mrm.LEGACY_ID__C NOT LIKE '%CustodianReferralNetwork%'
WHERE (
    "DoSeparate__FinServ__SourceSystemId__c" IS NOT NULL
    OR "Legacy_ID__c" IN ('EVR_RT_HH_1441','EVR_RT_HH_1193') // Planning Only
    )
