from __future__ import annotations

from pydantic import BaseModel, Field

from app.schema.common import TableRef
from app.schema.sttm_builder import RelationshipContextItem
from app.schema.mapping_sql import MappingSqlMappingItem


class WorkbookDerivedSourceItem(BaseModel):
    derived_source_id: str
    derived_source_name: str
    sql_text: str | None = None
    source_tables: list[TableRef] = Field(default_factory=list)
    base_source_tables: list[TableRef] = Field(default_factory=list)
    semantic_view_name: str | None = None
    semantic_bundle_label: str | None = None


class WorkbookExportRequest(BaseModel):
    project_name: str | None = None
    summary_narrative: str | None = None
    created_by: str | None = None
    created_at: str | None = None
    version_label: str | None = None
    target_table: TableRef | None = None
    source_tables: list[TableRef] = Field(default_factory=list)
    relationships: list[RelationshipContextItem] = Field(default_factory=list)
    derived_sources: list[WorkbookDerivedSourceItem] = Field(default_factory=list)
    filters_sql: str | None = None
    source_query_sql: str = Field(default="")
    preview_sql: str = Field(default="")
    generated_sql: str = Field(default="")
    mappings: list[MappingSqlMappingItem] = Field(default_factory=list)
