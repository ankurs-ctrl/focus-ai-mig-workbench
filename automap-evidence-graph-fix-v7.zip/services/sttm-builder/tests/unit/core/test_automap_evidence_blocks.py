"""Synthetic large evidence. Provider/Snowflake boundaries are fake, SQL/compiler are real."""
import asyncio
from copy import deepcopy
import json

import pytest

from app.core.automap_evidence_blocks import EvidenceBlocks, EvidenceBlockError
from app.core.automap_input_budget import wire_text
from tests.unit.core.test_automap_fast_batch import prepared_request
from tests.unit.core.test_automap_fast_context import fast_payload
from tests.unit.core.test_automap_guarded_specialist import setup, rules
from tests.test_automap_fast_transport import harness as transport_harness


def review(block, *, facts=None):
    return json.dumps({'agent': 'AGT_SOURCE_MAPPING', 'data': {'status': 'completed', 'result': {'mappings': {}}},
        'meta': {'evidence_review': {'block_id': block['block_id'], 'facts': facts if facts is not None else [
            {'quote': block['text'][:60]}]}}})


def test_recursively_split_utf8_evidence_reassembles_exactly_and_every_message_fits():
    original='abc界\\"'*20000
    registry=EvidenceBlocks('snapshot',3000,3000);registry.enabled=True
    registry.begin();registry.project(original)
    pieces=[]
    while registry.pending:
        identity=registry.pending[0];message=registry.request(identity)
        if message is None:continue
        assert len(wire_text(message))<=3000 and len(wire_text(message).encode())<=3000
        pieces.append(deepcopy(registry.blocks[identity]))
        registry.accept(identity,review(registry.blocks[identity],facts=[]))
    assert ''.join(piece['text'] for piece in sorted(pieces,key=lambda value:value['text_start']))==original
    assert len(pieces)>2


@pytest.mark.parametrize('change', ['quote','status','mapping','identity','error'])
def test_block_reviews_cannot_forge_evidence_or_apply_mappings(change):
    registry=EvidenceBlocks('snapshot',120000,120000);registry.enabled=True
    registry.begin();registry.project('private exact clause '*20000)
    identity=registry.pending[0];block=registry.blocks[identity];body=json.loads(review(block))
    if change=='quote':body['meta']['evidence_review']['facts']=[{'quote':'invented fact'}]
    elif change=='status':body['data']['status']='failed'
    elif change=='mapping':body['data']['result']['mappings']={'TARGET':{'source_attributes':['bad.SECRET']}}
    elif change=='identity':body['meta']['evidence_review']['block_id']='foreign'
    else:body['error']='failed'
    with pytest.raises(EvidenceBlockError):registry.accept(identity,json.dumps(body))
    assert not registry.reviews


@pytest.mark.parametrize("target", ["NAME0", "Name0"])
def test_large_source_is_read_in_blocks_on_guarded_runtime_and_returned_for_review(transport_harness, target):
    h=transport_harness
    builder,models,_req,_source=setup(h,1)
    value=fast_payload()
    value['data']['attributes'][0]['target_attribute'] = target
    value['context']['semantic_context'][0]['semantic_model']['attributes'][0]['business_meaning']='Exact synthetic business evidence. '*18000
    req=prepared_request(value);before=req.model_dump()
    blocks=[]
    def hook(outgoing):
        packet=json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            block=packet['context']['evidence_block'];blocks.append(block)
            h.state.answer=review(block)
        else:
            h.state.answer=json.dumps({'agent':'AGT_SOURCE_MAPPING','data':{'result':{'mappings':{
                target:{'source_attributes':['a.X47'],'confidence_score':.8,'transformation_classification':'direct'}}}}})
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(req))
    assert req.model_dump()==before
    assert len(blocks)>1
    assert final.result.mappings[target].source_attributes==['a.X47']
    assert final.meta['automap_evidence_review_only_targets']==[target]
    assert len(h.state.models)==len(blocks)+2
    assert len(models)==1
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)
    for index in range(1,len(h.state.models)+1):
        message=models[0].request_for(index).message
        assert len(message)<=120000 and len(message.encode())<=120000


def test_empty_complex_source_is_repaired_before_guarded_rule_generation(transport_harness):
    h=transport_harness;builder,models,req,valid=setup(h,1)
    calls=[]
    def hook(outgoing):
        calls.append(outgoing.url.path)
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:
            if len(calls)==1:
                body=json.loads(valid);body['data']['result']['mappings']['NAME0']['source_attributes']=[]
                h.state.answer=json.dumps(body)
            else:h.state.answer=valid
        else:h.state.answer=rules('NAME0')
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings['NAME0'].preprocessing_rule=='TRIM(a.X47)'
    assert len(calls)==3 and 'AGT_TRANSFORMATION_RULE' in calls[-1]
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


def test_graph_links_join_topology_to_exact_evidence_and_instructs_scoped_reads():
    from tests.unit.core.test_automap_fast_context import add_table, plan_for, unpack
    value = fast_payload()
    add_table(value, name='LOOKUP', connected=True)
    store, plan = plan_for(value)
    packet = unpack(plan.messages([]))
    graph = packet['context']['evidence_graph']
    edge = next(edge for edge in graph['relationship_edges'] if edge['edge_id'] == 'LOOKUP')
    assert edge['left_relation_id'] == 'a' and edge['right_relation_id'] == 'LOOKUP'
    assert edge['evidence_record_ids']
    globals_by_id = {record.record_id: record for record in plan.prepared.global_records}
    assert all(globals_by_id[identity].kind == 'source_graph' for identity in edge['evidence_record_ids'])
    assert graph['snapshot_hash'] == store.snapshot_hash
    example = packet['evidence_read_response_example']
    assert example['meta']['evidence_requests'][0]['snapshot_hash'] == store.snapshot_hash
    assert 'ranking is a search hint, not proof' in packet['instructions']
    assert 'parent lineage field is not a selectable CTE output' in packet['instructions']


def test_three_distinct_agent_requested_expansions_are_not_treated_as_invalid_repairs(transport_harness):
    h = transport_harness
    builder, models, req, _source = setup(h, 1)
    value = fast_payload()
    value['context']['relation_graph']['nodes'][0]['output_columns'].extend(
        {'name': f'X{index}', 'data_type': 'TEXT'} for index in range(1, 4))
    req = prepared_request(value)
    seen = []
    def hook(outgoing):
        packet = json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        from scripts.automap_message_sizes import expand_packet
        packet = expand_packet(packet)
        seen.append(packet)
        if len(seen) <= 3:
            h.state.answer = json.dumps({'agent': 'AGT_SOURCE_MAPPING', 'data': {'result': {'mappings': {
                'NAME0': {'source_attributes': [], 'confidence_score': 0,
                    'transformation_classification': 'unresolved', 'unmatched_reason': 'Need another indexed source'}}}},
                'meta': {'evidence_requests': [{'snapshot_hash': packet['context']['auto_map_retrieval']['snapshot_hash'],
                    'target': 'NAME0', 'source_refs': [f'a.X{len(seen)}']}]}})
        else:
            h.state.answer = json.dumps({'agent': 'AGT_SOURCE_MAPPING', 'data': {'result': {'mappings': {
                'NAME0': {'source_attributes': ['a.X47'], 'confidence_score': .8,
                    'transformation_classification': 'direct'}}}}})
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings['NAME0'].source_attributes == ['a.X47']
    assert len(seen) == 4
    for index in range(1, 4):
        assert f'a."X{index}"' in {row['source_ref'] for row in seen[index]['context']['selectable_sources']}
    assert all(slot['STATE'] == 'FREE' for slot in h.database.slots)


@pytest.mark.parametrize('failure', ['timeout', 'lost_ack'])
def test_uncertain_block_read_does_not_replay_model_or_release_its_permit(transport_harness, failure):
    h = transport_harness
    builder, models, _, _ = setup(h, 1)
    value = fast_payload()
    value['data']['message'] = 'Mandatory synthetic rule. ' * 20000
    req = prepared_request(value)
    calls = []
    def hook(outgoing):
        packet = json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        calls.append(packet['protocol'])
        assert packet['protocol'] == 'auto_map_exact_evidence_block_v1'
        h.state.mode = failure
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert calls == ['auto_map_exact_evidence_block_v1']
    assert final.result.mappings['NAME0'].transformation_classification == 'unresolved'
    assert sum(slot['STATE'] in {'HELD', 'QUARANTINED'} for slot in h.database.slots) == 1
    assert len(h.state.models) == 1


def test_offline_archive_replan_preserves_identity_and_does_not_report_model_acceptance():
    from app.core.automap_parallel import _snapshot
    from scripts.replay_automap_admission import replay, decode_snapshot
    from tests.unit.core.test_automap_fast_context import plan_for
    store, _ = plan_for()
    tagged = _snapshot(vars(store))
    assert decode_snapshot(tagged) == vars(store)
    result = replay({'value': {'protocol': 'automap_exact_snapshot_v1', 'state': tagged}})
    assert result['snapshot_hash'] == store.snapshot_hash
    assert result['model_calls'] == 0 and result['snowflake_validation'] == 'not_performed'
    assert result['historical_read_ledger_reset'] is True
    assert result['chars'] <= 180000 and result['bytes'] <= 180000
    assert 'semantic_context' not in result and 'original' not in result


def test_failed_exact_read_attempt_is_still_charged():
    from types import SimpleNamespace
    from app.core.automap_exact_reads import read_operations
    def fail(*args, **kwargs):
        raise ValueError('Synthetic optional failure')
    store = SimpleNamespace(snapshot_hash='snapshot', read_many=fail)
    counter = {'count': 3}
    with pytest.raises(ValueError):
        read_operations(store, [{'operation': 'column', 'relation': 'a', 'column': 'X47'}],
            settings=SimpleNamespace(agent_outbound_message_max_bytes=180000, automap_context_max_operations=64),
            results=[], events=[], operation_count=3, counter=counter, remaining=lambda: 100)
    assert counter['count'] == 4


def test_preflight_sizes_block_messages_without_claiming_reviews_or_reading_the_ledger():
    from tests.unit.core.test_automap_fast_context import plan_for
    value = fast_payload()
    value['data']['message'] = 'Mandatory global rule. ' * 20000
    store, plan = plan_for(value)
    plan.messages([])
    before = deepcopy(store.reads)
    manifest = plan.evidence_read_manifest()
    assert manifest['required_block_calls'] > 1
    assert manifest['max_block_message_chars'] <= plan.max_chars
    assert manifest['max_block_message_bytes'] <= plan.max_bytes
    assert manifest['model_calls'] == 0 and manifest['evidence_review_completed'] is False
    assert not plan.blocks.reviews and store.reads == before
