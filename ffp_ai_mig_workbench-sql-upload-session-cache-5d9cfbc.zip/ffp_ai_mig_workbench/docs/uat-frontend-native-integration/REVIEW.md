# UAT frontend/native integration

Feature branch: codex/uat-frontend-native-integration. UAT itself is unchanged.

Inputs:
- CodeCommit UAT: 12be33f358b6a2a90da37a2d257d427ffd396454.
- Team sync/uat-plus-develop-frontend: 176119d1d1267b439bb8fb36cc0978c16fe9acfa.
- Latest local application delta from bbi-workbench-automap-v6, including native V11 investigation. Original worktree retained.

The first commit merges the team branch into current UAT, retaining the later UAT CTE/specialist correction. The next commit integrates local application work. UAT and the team branch were not reset or overwritten.

## Frontend preservation audit

81 files differ between the team's UAT base 636079e and their sync head. All 81 are present. 79 retain their exact normalized team content. The other two combine both parties' changes:

- source-target-attribute-list.tsx: retain team title/icon styling and add local Auto-map scope, capability gating and protection text.
- source-target-attribute-mapping.tsx: retain firmValueNamesInExpression integration and NL-rule tour marker; add local proposal-review panel action.

Other local production frontend changes apply to the store, context provider, types, API service and completion toast, which the team branch had not changed. Existing checked scope, all-target reevaluation, preserved definitions, stale-revision fencing, incremental checkpoints and canonical target identities stay together.

The tour parity assertion now permits the configurable Query Preview data-tour expression with the same required default; it still checks the target registry. No runtime tour behavior was changed for that test.

Team Quiz, sign-in redirect, tours, LEFT JOIN defaults, driving-table selection and saved-filter compatibility remain in their branch content.

## Validation and limits

- All 21 frontend harnesses pass on the combined source.
- TypeScript noEmit passes.
- Automated preservation audit: no missing team files; only the two intended combined production frontend files differ from team edits.
- Native package backend/config files match the latest local code; additional committed local backend fixes missing from remote UAT were brought over as well.
- No client.env, .env.local, credentials, dependency directories, ZIPs, temporary launch adapters or PowerShell profiling artifacts included.
- Full backend suite result is recorded in the integration commit after completion.

This branch is an integration candidate, not a declaration of live Auto-map acceptance. Native direct mapping passed in DEV; Analyst, specialist and full client UI acceptance remain as documented in docs/automap-native-investigation-v11/TEST_RESULTS.md. Native flags default off. Existing client environment configuration remains authoritative.

The prior V11 ZIP remains an unmerged client-test artifact. Do not extract it over this feature branch: that would undo the combined frontend edits. Deploy/test from this branch or generate a new reviewed delta from it.

## Packaging correction found during integration

The prior V11 ZIP omitted investigator.md and transformation.md because these new files matched a repository ignore rule. The clean worktree exposed the missing inputs in renderer tests. Both versioned instruction files are now explicitly tracked in this feature branch; the renderer tests pass. Use this branch rather than overlaying the older ZIP.

Final integration checks: full backend run reported 4,092 passed, 31 skipped and two renderer failures caused by the omitted Markdown inputs. After explicitly including those inputs, all 15 native deployment tests passed, including both failed tests. No backend behavior was changed for this correction. All 21 frontend harnesses and TypeScript passed. Skipped checks include the unavailable external client.env; live client accuracy remains outstanding.
