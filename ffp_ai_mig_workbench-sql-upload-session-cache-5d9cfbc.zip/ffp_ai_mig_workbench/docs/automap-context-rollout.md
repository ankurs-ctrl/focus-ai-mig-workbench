# Auto-map context integration: local implementation and rollout gates

## Uploaded SQL transport regression (2026-10-14)

Failed job `442f7054-9787-4128-9c4b-56c272dd4a9a` belongs to project 2301,
mapping 9601. It has 37 targets, 21 graph nodes and five graph edges. This is
not the previously completed mapping 9101 (project 1701, 20 nodes, 15 edges).
The previous success therefore does not establish acceptance for this upload.

Read-only inspection of its durable request found 4,647,201 serialized bytes.
Its 93 historical pattern candidates occupy 1,938,003 characters and occur
identically in both learning and execution context. None identifies mapping
9601 as its origin; none targets ADDR1. Fifty-five have
`unvalidated_authored_sql` provenance. Derived dependencies account for 1,175,052
characters per pattern-list copy, with repeated historical CTE definitions.
The current relation graph is only 58,019 characters. The ADDR1 error reports
the whole shared worker envelope, not a column-specific fetch or Cortex prompt.

Compared with parent `d0b6c5f`, checkpoint `dad856f` preserves complete recipe
dependencies and disables lossy host-to-worker compaction. Earlier branches
trimmed CTE excerpts, limited dependency lists and could drop semantics during
compaction. Target subdivision changes attributes but retains the shared
context, so it cannot repair this transport overflow.

The local fix sends an exactly equal execution-pattern list once in learning
context, with an explicit transport reference. Request validation restores an
independent exact copy before worker logic/model projection. Unequal lists are
never combined; malformed references fail validation. Saved requests and model
contracts are unchanged. Transport overflows are distinguished from model
overflows and no longer trigger ineffective target subdivision.

A Snowflake read-only reconstruction reduced the saved request to 2,709,171
bytes and confirmed exact context restoration, unchanged graph/semantics and
all 93 candidates retained. This is transport evidence, not live model or
mapping-accuracy acceptance. Regression tests cover manual and uploaded-source
shapes, 93-pattern overflow, unequal lists, invalid references, private worker
dispatch, and unchanged model projection. Host and worker must receive the
schema change together; no deployment, backend restart, Search toggle, source
graph change or live mapping rerun was performed during this investigation.

Verification: all 11 transport regressions and 110 existing batching/payload
checks pass. The full backend suite reports 721 passed and four previously
documented deployment-example/Windows-permission failures. Those deployment
inputs and the protected safe-deployment script are unchanged.

## Hybrid retrieval experiment (2026-10-13, not release-approved)

`AUTOMAP_HYBRID_CONTEXT_V1` is off by default. The local test enables it with
`AUTOMAP_COLUMN_SEARCH_SERVICE=FFP_HDP_DLAB_DB_DEV.SCH_STTM_MCP.COLUMN_SEARCH_SVC`.
Exact linked published snapshots remain mandatory. Search supplements them using
the serving REST API, pre-ranking scope filters, caller-session hydration and
current lifecycle checks. Search errors are recorded separately from no matches.
Client recipes remain reusable; project and mapping overrides stay local.

The first additive `infra/snowflake/automap_recipe_search.sql` creation attempt
reported an embedding-access error. Subsequent diagnostics found that the deploy
role itself was authorized but the chat's runtime-managed restricted session
excluded object creation and AI-function calls. No grants or roles were changed.
The user ran the script directly in Snowflake; the service now has 91 indexed
recipes, ACTIVE indexing/serving and no indexing error.

Initial coverage inspection found that most HOUSEHOLD recipes use `source_system`
scope, omitted by the new Search client's scope filter. Discovery now includes
`source_system` and `target_standard` candidate IDs alongside client/local scopes.
Live hydration still rejects other projects' or mappings' local overrides. Shared
IDs go through the existing source/type/grain/dependency applicability checks;
Search does not approve their SQL. Cache contract v5 avoids old degraded retrieval
results. Native runtime-role access and production owner-rights isolation remain
deployment checks.
The application serving/hydration smoke test for mapping 9101 queried BILLINGCITY,
NAME and OWNERID: nine requests, zero errors, 12 column candidates per target,
and published BillingCity recipe `tmp_664cb720189d44b7e599f962` from mapping 6606
retrieved and hydrated. No recipe was returned for the other two test targets.
This proves transport/hydration, not full mapping quality or comprehensive recall.
The stopped local backend was started with the same 120K/two-in-flight settings
and the scope fix; no Auto-map job or saved-mapping mutation was performed.

The readable context projection filters target evidence, preserves complete
selected meanings and rules, resolves expression dependencies, and factors exact
duplicate structured context. It never modifies the saved execution graph.
The initial graph-output projection was reverted after live output showed the
agent misread a separate available-column list; `output_columns` now retains
the full namespace. Native YAML projection, recall, unknown dependencies and
expanded retry behavior still require review before enabling this flag broadly.

The first full graph job `da6428ac-c310-4393-a083-e3cd1cb2661f` completed all
37 targets across 25 batches with max in-flight 2, using 16 physical sources,
4 CTEs and 15 joins. This is execution evidence, NOT an accuracy acceptance:
the response review reported 9 unresolved targets and the UI showed 21 mapped.
Output review found draft-evidence contamination and Direct-rule prose persisted
as SQL. Both were corrected locally. Four full-graph runs have now completed;
the fourth (`219221a5-2305-4b8a-b888-ee0a8bf4dd22`) used 85,000 characters/94,208
bytes and 24 batches. Its response reported 11 unresolved targets; the UI retained
24 mapped targets and 13 unmapped/review targets. This remains partial business
coverage, not accuracy acceptance.

Live SQL lifecycle checks now pass for those 24 mapped targets: compile/validation,
five-row read-only preview without source-comparison warnings, SET display/copy,
save/reopen, summary display and Download SQL. Download contains SET plus SELECT,
not INSERT. The saved graph still has 16 physical sources, four CTEs and 15 joins.
Readable compiler aliases were already implemented; stale artifact fallback hid
them. Fixes align compiler request bindings with row-owned graph identities, keep
review-only semantic discovery from invalidating the compiled artifact, and restore
the compiler's saved semantic input on reopen. Source comparison now preserves
CTE scope and normalizes qualified source references. Separate sampled source/output
queries still do not prove row correspondence or business grain.

Exact durable-request planning (no agent calls) reproduced 24 batches at 85K.
120K with the local five-target cap planned eight batches; 120K with cap 16 planned
five batches (7/9/8/9/4). The first live attempt failed before Cortex because the
internal host/worker envelope exceeded its separate 1 MB allowance after SQL was
saved. With a local 4 MiB transport allowance, run
`7bf73917-33da-4530-ad41-5fceb309c23d` completed 37 targets in five batches at
120,000 characters/131,072 bytes, cap 16 and max in-flight two. Observed model
prompts reached 118,370 characters. Its SQL check caught four Direct address
bindings using disconnected physical inputs instead of the prepared CTE.
The prepared graph was not changed. A compiler-backed, one-attempt Direct-source
repair was added; invalid repairs remain unresolved. Follow-up run
`cebae50a-bb3d-45a0-aa1d-01aed87faa31` completed 37 targets in five batches. All four
address targets now reference the connected prepared CTE. The response reports
27 mapped/10 unresolved/five override proposals; the UI has 26 mapped/11 remaining
with previous accepted rows and pending reviews retained. These are different
counts, not evidence that all suggestions were accepted.

The final run's displayed script has SET and readable CTE names, Snowflake SQL
validation succeeds, and the read-only preview returns five rows without warnings.
Provider acceptance and the SQL lifecycle pass, but full business accuracy is not
accepted: some missing-source explanations contradict available graph columns and
need focused recall/applicability evaluation. Household grain and cross-project
reuse acceptance are also still open. The earlier run's save/reopen/copy/download
checks passed; no mapping was published or loaded.
Final reload testing also exposed inconsistent `sourceColumn` display strings for
multi-source mappings (first column versus comma-joined columns). Restore now keeps
all selected columns and artifact hashing uses the canonical `sourceColumns` list.
After recompilation and another full reload, the final run retains SET declarations
and `addresses_one_per_contacts` with no digest suffix in the SQL panel.
Production defaults remain
60,000/65,536; packed encoding remains off.

Latest full backend suite: 599 passes, four known deployment/Windows baseline
failures, three warnings. Node artifact/reducer/compiler-request/reopen regressions
and frontend type checking pass. No target load, publication, deployment, grants,
commit or push was performed.

### Full recipe-Search acceptance and dependency handoff (2026-10-13)

Job `f2324c2d-124d-408e-9542-27eb05f61ef6` completed 37 targets in five batches
with two in flight, approximately 247 seconds after job creation. Search diagnostics
reported 111 requests, zero errors, 12 hydrated recipe IDs and 12 column candidates
per target. The linked published mapping 6606 was retained. Available per-batch
audits show target-specific recipes in model payloads; structured recipe citations
were empty, so retrieval is not proof of reasoning use. Only four partial response
records were present despite five completed batches; complete per-batch audit
retention remains to be checked.

The response proposed 27 mappings, left 10 unresolved and flagged three overrides.
The UI retained 26 mapped rows and did not automatically accept the NAME override.
The proposed family-name expression now references the existing CONTACT_FAMILIES
column. All 16 physical sources, four CTEs and 15 joins remained unchanged.

Compilation caught a transformation-stage bug: validated state/country expressions
used the prepared CTEs, but their repaired dependencies were unioned with obsolete
raw-table dependencies. The merge now replaces the executable dependency/value
contract while preserving evidence citations. Expression validation also uses the
prepared driver and the selected source columns. Regression tests exercise the real
compiler, failed repair, unchanged graph and idempotent revalidation (73 focused
tests passed). Failed compilation exposes the uncompiled fallback, which explains
the reappearance of internal aliases and absence of SET in that screenshot.

Accuracy is not accepted. Read-only source checks found that the generated
`CONCAT_WS` address expression loses 488 otherwise non-null street addresses when
the secondary line is NULL. State/country targets require standardized codes, but
the response selected lookup aliases. The prepared family join produces 7,360 rows
for 7,036 contacts and 974 families, with 4,822 rows missing a family. These are
business/SQL correctness risks, not solved by Search availability or a successful
SELECT preview. The prepared population and deduplication rules were not changed.

### Four-way timing, preview UI, and context audit

Dependency-fix run `6ca98b03-3caf-4315-a764-02d9f7672d27` completed in 182.273
seconds with two concurrent batches. Run `eb3797fa-9e2f-4eaa-a979-8b8408a2852f`
used four concurrent batches and completed in 117.479 seconds (five batches, no
failed batches). This is a single-run comparison, approximately 36% shorter job
runtime, not a controlled quality benchmark. The browser's job-creation request
also took 56.71 seconds for preparation; job runtime excludes that preparation.
An exact Auto-click timestamp was not captured. Five-way concurrency was not tested.

The four-way response contains 22 non-unresolved proposals and 15 unresolved targets;
the final UI retained 25 mapped rows from current and previous decisions. Coverage
must not be interpreted as accuracy. Its generated address expression handles a NULL
secondary line and selects state/country codes, but other decisions remain unstable.

Local UI changes compile settled mapping inputs rather than only the first transition
out of Auto-map, retry a superseded context once per changed input, and label fallback
SQL as an uncompiled draft. Preview names are display-only: column name on the first
line, readable CTE/table below in lighter text. Stored identities are unchanged.
NULL, empty strings and unavailable samples now have distinct labels; the UI explains
that confidence is not completeness and independent source samples are not guaranteed
to correspond to the selected output row. Node regression tests and TypeScript pass.
Live validation returned five rows, with SET and readable SQL CTEs, and no tested
internal aliases remaining in the preview text. No load or publication was executed.

All five recorded source-agent payloads used the normal 95-119K-character stage,
not emergency truncation. All 12 retrieved recipes were distributed across their
target batches (5/2/4/0/1). Batch 3 has no matching target rows in the 28-row published
precedent, so its omission there is target filtering. Other FIR categories returned
`no_match` before projection, with no recorded retrieval SQL errors; this does not
prove that all applicable account knowledge was found.

Zero semantic loss is NOT established. The address CTE had 20 prepared column
semantics but no detailed attributes in the sent source-agent payloads; the UDF CTE
similarly lost all eight detailed attributes. Physical meanings remain available
for some corresponding columns, and CTE SQL/output names remain, but they are not
equivalent to preserving CTE-specific meanings. Candidate selection also omitted
SOURCES.NAME in the referral batch and MAPPER_USER first/last name meanings in the
owner-name batch. These omissions can affect reasoning. No semantic projection fix
was applied during this audit.

`measure_automap_batches.py --audit` reconstructs packets without agent calls or
writes and compares graph contracts. It preserves all 20 nodes, 15 edges, four CTE
SQL definitions, output names, bindings, driver and filters. Only one reconstructed
whole-payload hash matched the recorded hash; therefore reconstruction must not be
presented as byte-for-byte proof for every actual request. Recorded semantic
inventories independently confirm the CTE omissions.

### SPCS concurrency and FIR health (read-only inspection)

SPCS uses the same concurrent dispatcher. Existing templates/scripts expose
`AUTO_MAPPING_PROXY_MAX_IN_FLIGHT` on the web app and
`AUTO_MAPPING_WORKER_MAX_CONCURRENCY` on the worker. Four is the tested local value;
the worker service currently has two running instances. The current restricted chat
session can discover the services but DESCRIBE returns a NULL spec, so live deployed
environment values were not verified. No deployment/settings/grant change was made,
and the protected safe-deployment script remains unchanged.

All 11 FIR tasks are started and all 16 streams are non-stale. ACCOUNT_USAGE task
history confirms successful capture, enrichment, agent processing, promotion and
queue runs on October 13. INFORMATION_SCHEMA task history returned no visible rows
in this session; the account history is the supporting execution evidence.
However, the durable queue has 459 pending and 82 dead-letter items (818 completed).
Dead letters include missing pattern IDs and agent-enrichment errors. Publish and
outcome streams still report pending changes. Main catch-up runs twice daily at
02:00/14:00 UTC with independently scheduled downstream stages; enrichment today
finished after the agent-processing stage had started, so same-cycle consumption
cannot be assumed. Monitor backlog/dead letters, not only task success.

The local publish code directly records immutable versions, mapping learnings,
typed patterns and learned relationships, while feedback/outcomes enter durable
capture paths. Mapping 6606's existing published snapshot and recipes were actually
retrieved in these tests. A fresh publish-to-next-run acceptance was NOT performed.
Pattern-write failures are logged without failing the publish, Search is asynchronous,
and source/target/grain/trust applicability can exclude a prior mapping. Similar or
better next-run results are therefore a goal, not a verified guarantee.

### Recipe Search access investigation and creation

The creation attempt reported missing access to `snowflake.cortex.embed_text_768`.
`EXPLAIN_PRIVILEGES` for `FFP_HDP_DLAB_DB_DEPLOY_ROLE_DEV` returned authorized;
the effective chat session reported missing CREATE CORTEX SEARCH SERVICE and
USE AI FUNCTIONS. `ACTIVE_RESTRICTED_SESSION_SCOPES` confirmed a runtime-managed
read/discovery/existing-service-usage restriction. The same user and role had
created the two existing Search services successfully. Therefore the earlier
recommendation to request an embedding-role grant was premature. The user has now
created the recipe service directly in Snowflake; no new grant was required by
this workflow. Do not bypass chat restrictions using a different connection.

Also verify CREATE CORTEX SEARCH SERVICE on `FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA`,
SELECT on `TBL_FIR_TARGET_MAPPING_PATTERNS`, warehouse USAGE, database/schema access
and source change-tracking prerequisites. After creation, the runtime querying role
needs USAGE on the service and its database/schema; owner-rights exposure and
caller-session hydration must be reviewed separately. Do not assume SQL connection
and application roles have identical grants. Definition:
`infra/snowflake/automap_recipe_search.sql`.

Reference: https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-search/cortex-search-overview

## Workflow contract

Source selection and source preparation own the chosen physical sources, CTEs,
relationships and source population. Auto-map consumes that prepared graph with
project/mapping intent, saved semantics, applicable FIR evidence and current-project
firm-value contracts. It does not silently change joins or deduplicate the population.

Shared destination tables are intentional. Recipe identity does not include project
identity unless the evidence is explicitly project-scoped. Different target entities,
contract versions, SQL literals and source dependency recipes remain distinct.

## Implemented behavior

- Invocation-local audit records distinguish prepared and sent evidence, semantic
  fields and payload hashes, including emergency/thread retries. Full prompt capture
  defaults off (`AGENT_PROMPT_ARTIFACT_CAPTURE`); enabled capture uses owner-scoped
  draft artifacts and existing retention. Do not enable it casually: prompts contain
  source information and firm values.
- Null-like logical identities fall back to canonical targets. Publication prefers
  parsed expressions to rule labels. Reusable patterns remain cross-project; raw
  source/transformation-agent records use explicit current-project scope.
- Saved business meanings, roles, synonyms, profiles and selected SQL survive worker
  and budget projection. Name/column overlap alone cannot prove CTE equivalence.
- Planner and worker use the same pure model projection. Worker transport preserves
  context. Remote oversized batches automatically subdivide inside the existing
  concurrency limit; omitted target responses use bounded repair. Resumed jobs also
  subdivide after a local budget change, retaining all child payload audit attempts.
- Workers own transformation. Missing simple or complex expressions are requested
  with exact source selections, graph/value contracts and evidence, then parsed and
  checked against the graph. One targeted repair is allowed. Invalid results remain
  reviewable instead of silently becoming Direct mappings.
- Compiler Direct projections use selected columns, not join-dependency order.
  Non-Direct rows require expressions. Grain checking is conservative metadata
  comparison, not proof of row uniqueness or population correctness.
- `script_sql` is the extraction script for display/copy/export; `preview_sql` is a
  single resolved query; `generated_sql` remains the separate load artifact. Editing
  SET declarations cannot change project settings: values must match stored values.
  Optimization keeps named placeholders or the original SQL is retained. Deterministic
  and AI repair also retain canonical scripts and resolve values only for validation.
- Project identity, firm values and semantic context participate in artifact currency.
  Missing current-project values cannot inherit a stale frontend resolution. Stale
  compiled SQL cannot reappear through its authored copy; late review/preview responses
  cannot overwrite a changed workspace. Validation includes semantic context.

## Actual Snowflake storage checks

Read-only schema inspection and compile validation exposed three retrieval defects:

- Scoped agent learnings used nonexistent `UPDATED_AT`; corrected to `CREATED_AT`.
- Semantic learnings used nonexistent top-level `STATUS`; corrected to optional
  lifecycle fields in `ATTRIBUTES`, explicit local or client/global scope and target
  applicability. Lateral flatten plus DISTINCT prevents duplicate returned evidence.
- Stored intents used nonexistent `PROJECT_ID` and wrong lifecycle/domain fields;
  corrected to exact `CONTEXT_KEY` and top-level `LIFECYCLE`/`DOMAIN_HINTS`.

All three corrected SELECTs compiled against the actual metadata namespace. Both
semantic-learning and stored-intent tables reported zero rows. Retrieval repairs do
not create missing historical evidence. Prepared retrieval cache salt is now v4.
Template semantic-learning producers also had a mismatched method call: unsupported
`status` and missing `source`. Local code now uses the actual signature and carries
project/context scope; signature-checked tests cover both producer actions.

The target-pattern MERGE compile check was denied by the restricted read-only
session, which excludes INSERT access. It remains unverified in Snowflake. The
restriction was not bypassed and no live write executed.

## Local verification

Use the existing service lockfile:

```powershell
uv run --project <worktree>/services/sttm-builder --locked --with pytest python -X utf8 -m pytest <worktree>/services/sttm-builder/tests/unit -q -p no:cacheprovider
node <worktree>/frontend/scripts/test-mapping-artifact.cjs
python <worktree>/scripts/verify_mapping_agent_specs.py
npm --prefix <worktree>/frontend run build -- --webpack
```

The latest backend unit run reached 597 passed / 4 failures. The four
failures concern unchanged deployment example/default checks and POSIX mode 0600 on
Windows. Those inputs and the protected deployment script were verified unchanged
against `d0b6c5f`. The full lint baseline has errors outside this change; modified
frontend files had zero lint errors (seven existing hook warnings remain). Type checking,
artifact regression checks and webpack production build passed. Default Turbopack
cannot build this worktree's external `node_modules` symlink.

## Remaining release gates

1. Complete target-pattern MERGE validation in a separately authorized environment;
   corrected semantic/intent/scoped-agent SELECTs already compiled successfully.
2. Snapshot current deployed services/config/spec fingerprints. Validate changed specs
   on approved non-production agents or clones; no live agent has been altered.
3. Run isolated, non-publishing acquisition examples against a shared target with
   different firm values/source recipes. Compare evidence coverage, expressions,
   output grain and business population, not just mapped counts or syntax.
4. Verify browser save/reopen, optimized SQL, script edits, value changes, preview and
   export with those isolated mappings. Local type/build tests are not browser proof.
5. Review identity repair proposals from all relevant active/inactive supersession
   chains and original published snapshots. `scripts/plan_fir_identity_repair.py` is
   read-only and has no apply option. It produces rollback rows; it does not establish
   historical truth without independently verified published inputs. Do not run the
   older active-only backfill to restore collisions. The planner preserves known
   support keys, verifies original target column and collision key, and does not
   misclassify blank Direct expressions as lost SQL. Idempotence is unit-tested.
6. Resolve deployment prerequisites separately; never edit
   `scripts/deploy_spcs_client_snow_safe.ps1`. Deployment, data repair DML, commits and
   pushes require separate authorization.

Mapping 6210 has not been overwritten or rerun. Its contact-versus-household grain
issue requires business/source-plan validation. Project 1701's stored ClientStartDate
is 2026-01-01 while its description says 2024-01-01; this change does not choose or
modify that business value.

## Limits to evaluate before release

Historical lineage matching deliberately favors exact SQL over speculative renamed
CTE equivalence. Rich source recipes may therefore be supplied as unresolved evidence
for agent adaptation, not auto-certified. A single target whose essential graph cannot
fit still needs diagnosis; automatic subdivision cannot solve an oversized singleton.
The audit covers the main structured invocation path; conversational streaming has
its existing separate diagnostics. No claim of zero model failures or live mapping
accuracy is made by local regression tests.

Full published-snapshot reconstruction, semantic registry identity resolution,
exhaustive per-target exclusion reasons, target-coverage publish gating and complete
dependency-closure equivalence remain acceptance gaps. Implementation is local;
end-to-end/live acceptance and rollout are not complete. No commit or push was made.