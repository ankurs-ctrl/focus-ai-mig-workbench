# SQL upload, session redirects and session read-cache corrections

Base: local integration commit `31b2546`, on `sync/uat-frontend-native-integration`.
This package includes the combined frontend team work already present at that base.
No environment files, live infrastructure, deployed agents or remote branches were changed.

## Application changes

- SQL upload admission distinguishes a confirmed configuration/access rejection (`503`, `detail.code=sql_upload_dependency_unavailable`, `accepted=false`) from an ambiguous transport outcome. Recovery-read failures retain the original request ID; they cannot establish that an upload was rejected.
- Readiness checks inspect every required request-table column and its type, and require exactly one admission-lock row. No table creation or permission grant occurs in an upload request. The existing authenticated `/api/v1/upload/sql/recovery-identity` endpoint also checks feature readiness before enabling SQL uploads. `/health` remains a process-liveness endpoint, not a declaration that Snowflake dependencies are ready.
- Bootstrap includes the recovery migration. A restricted upgrade mode installs only that migration and verifies it. Existing requests, receipt history and worker leases are retained. Adding an absent `PROCESSING_ID` column does not invent identifiers for historical rows.
- Processor identity is now `sql-upload-5-scoped-lineage`, consistently on both sides. Older processor receipts require explicit re-upload rather than silently reusing previously incorrect lineage. Failed requests can be retried under a new ID without deleting their server history. Uncertain submissions are observed under their original ID and are never automatically reposted.
- The upload dialog automatically observes request progress. Removed Check upload, Discard pending import and their old ambiguous-processing wording. Confirmed terminal failures expose Retry SQL upload. Closing the dialog stops browser observation, not server processing. Reopening resumes observation.
- Recovery hydrates the exact caller/project/request reference snapshot. Existing verified frontend references survive stale receipt delivery. Source-reference polling and optional enrichment receipt observation are independent; a stalled status read does not prevent reading exact persisted references. Every request is bounded by remaining observation time; cleanup aborts outstanding reads and timers. Ready references stop being reread while optional job status continues to be observed within the bounded window.
- Durable previews use provisional deterministic references instead of waiting for repeated Snowflake metadata checks inside the asset transaction. Existing hints are carried to background resolution. Positive metadata proofs are reused by the existing verifier; optional enrichment failure retains the preview. Canonical FIR winner hydration batches up to 50 rows per statement, retaining status, contract, project and mapping scope filters and ambiguity rejection.
- SQLGlot binds actual Column nodes in their SQL scopes. Function names, strings, aliases and nested scopes are not rewritten using a global bare-name replacement map. Backend lineage follows the resolved CTE scopes, and frontend compilation consumes the server-bound expression. Quoted identifier case is retained in reopened source deduplication and catalog read-cache keys.
- The public sign-in page remains reachable with an expired cookie. A rejected session (401) clears browser state and asks the backend to expire both host and configured-domain session/state cookies before redirecting. Permission denial (403) and temporary service failures remain distinct and do not trigger the redirect loop.
- Loaded project summaries, opened mapping details, project Values and workspace/catalog metadata remain reusable during the verified browser session. Summary expiry means background refresh, not removal of renderable data. Summaries notify mounted pages when fresh data arrives. Metadata caches retain stale entries while refreshing them. Explicit refresh and relevant mutations invalidate caches.
- Cache identity includes user, application role and Snowflake role. Logout/identity changes clear caches and fence older responses; switching a verified identity also clears the previous persisted builder draft and reloads page/Redux state. API 401 responses retire the verified cache identity. Caches remain an optimization; server authorization still applies to every network operation.
- Autosave updates the affected detail immediately. Expression-only saves retain the summary objects when visible summary fields have not changed; changed counts patch the affected mapping and project aggregates. Unrelated mapping reads remain valid during another mapping's autosave. Saved detail expiry uses `Date.now() + TTL`. Opening more than 50 mappings does not evict earlier current details; superseded autosave detail versions are discarded.

## Required administrator deployment steps

1. Deploy backend and frontend together from this combined source. Retain the client's own `client.env`, `.env.local` and authentication configuration.
2. Before enabling SQL upload, use the established Snowflake bootstrap credentials/connection, with an authorized metadata migration role:

   ```text
   python scripts/bootstrap_sttm_metadata_infra.py --sql-upload-recovery-only --database <CLIENT_DB> --schema <METADATA_SCHEMA> --role <MIGRATION_ROLE> --warehouse <WAREHOUSE>
   ```

   This uses the existing account/user/authentication arguments or environment configuration. It applies `infra/snowflake/sql_upload_recovery_v1.sql`, then verifies the schema and singleton lock. It does not deploy agents/tasks/streams/stages or add grants. The target metadata namespace must already exist. Run migrations with one administrator process at a time. Duplicate lock rows cause verification to fail; do not delete arbitrary historical request rows to resolve that condition.
3. The runtime caller role needs existing database/schema USAGE plus SELECT, INSERT and UPDATE on `TBL_SQL_UPLOAD_REQUESTS`. Reference/FIR access still uses the application's existing scoped permissions. Have the administrator review any missing object access; no broad runtime grants were added.
4. Verify the authenticated upload recovery-identity endpoint succeeds under the actual runtime role. Verify expired sessions can reach `/home`, and test permission denial separately. Do not use `/health` alone as upload readiness.
5. Re-select files whose saved requests were created under the previous processor version. The old server history is preserved; the new processor never resumes an incompatible receipt.

## Local verification

- Full backend suite: **4,169 passed, 31 skipped**, 246.89 seconds. Warnings are existing SQLGlot/pandas/Pydantic warnings. No live Snowflake validation is included in this result.
- TypeScript: `tsc --noEmit --incremental false` passed.
- All **27 frontend harnesses** passed, including session redirect, session cache lifecycle, real source deduplication, interrupted upload recovery and bounded polling.
- Actual Contacts SQL: 49 output rows, 11 physical sources, four CTEs, seven outer joins and 49 extracted FIR patterns. The supplied SQL and `ccOther` predicate are unchanged. Household SET values are test fixtures, not production defaults.
- Local five-run medians: parsing **0.539 s**, full 49-output compilation **0.176 s**. Separate FIR extraction **0.044 s**. A frontend Apply/graph child process took **0.590 s**, including Node startup and the harness. These are offline measurements under concurrent test load, not client response-time predictions.
- Added coverage includes missing/wrong recovery schema, missing/duplicate admission locks, confirmed rejection vs transport uncertainty, stale receipts, stale-generation fencing, nested CTE shadowing, function/column collisions in either projection order, case-sensitive quoted sources, role changes, cache quota failures, more than 50 opened mappings and concurrent autosave/read fencing.

## Remaining client acceptance

No account installation, deployment or live Snowflake execution was performed. Validate actual runtime-role access, migration execution, service routing/cookie domains and query compilation against the client's objects. Check business correctness separately from syntactic/lineage compilation. The intentionally retained Contacts country predicate still needs its separate business review.

Observation windows are bounded. A server outage may leave an upload retained with an explicit observation warning; reopening automatically resumes the same request rather than creating a duplicate. Browser storage can be unavailable or exceed quota; memory caching still works during that page session, while reload may require a server fetch. Background changes made by other users become visible through summary revalidation or explicit refresh; an open mapping's authored workspace is never silently replaced by a background read.
