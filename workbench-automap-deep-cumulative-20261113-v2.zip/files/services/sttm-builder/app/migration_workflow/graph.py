from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Protocol
from uuid import uuid5, NAMESPACE_URL

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from app.agent_runs.contracts import (
    AutoMapExecutionSpecV1,
    EvidenceReference,
    MappingContextPackageV1,
    MigrationPlanArtifactV1,
    SourcePreparationSpecV1,
    StoredSemanticContextReference,
)
from app.agent_runs.models import EFFORT_POLICIES, EffortLevel
from app.agent_runs.policy import policy_from_state
from app.agent_runs.value_bindings import normalize_typed_project_value, valid_typed_project_value
from app.migration_workflow.manifest import build_manifest, topological_order
from app.migration_workflow.state import MigrationState
from app.schema.workspace_context import WorkbenchContextSnapshotV1


class WorkflowHandlers(Protocol):
    def authorize_scope(self, state: MigrationState) -> dict[str, Any]: ...
    def ingest_attachments(self, state: MigrationState) -> dict[str, Any]: ...
    def coordinate_plan(self, state: MigrationState) -> dict[str, Any]: ...
    def create_project(self, state: MigrationState) -> dict[str, Any]: ...
    def revise_plan(self, state: MigrationState, feedback: str) -> dict[str, Any]: ...
    def prepare_sources(self, state: MigrationState) -> dict[str, Any]: ...
    def create_mappings(self, state: MigrationState) -> dict[str, Any]: ...
    def execute_mapping(self, state: MigrationState, mapping: dict[str, Any]) -> dict[str, Any]: ...
    def cross_validate(self, state: MigrationState) -> dict[str, Any]: ...


class DefaultWorkflowHandlers:
    """Safe deterministic handlers used for contract tests and shadow runs."""

    def authorize_scope(self, state: MigrationState) -> dict[str, Any]:
        if not state.get("actor_user_id") or not state.get("effective_role"):
            raise PermissionError("An authenticated user and effective role are required")
        return {}

    def ingest_attachments(self, state: MigrationState) -> dict[str, Any]:
        return {"attachment_ids": list(state.get("attachment_ids") or [])}

    def coordinate_plan(self, state: MigrationState) -> dict[str, Any]:
        return {"supervisor_plan": dict(state.get("supervisor_plan") or {})}

    def create_project(self, state: MigrationState) -> dict[str, Any]:
        return {"project_id": state.get("project_id")}

    def revise_plan(self, state: MigrationState, feedback: str) -> dict[str, Any]:
        existing = dict(state.get("supervisor_plan") or {})
        existing["revision_feedback"] = feedback
        return {"supervisor_plan": existing}

    def prepare_sources(self, state: MigrationState) -> dict[str, Any]:
        return {
            "source_preparation_result": {
                "status": "succeeded",
                "safe_summary": "Source preparation was validated in shadow mode.",
            }
        }

    def create_mappings(self, state: MigrationState) -> dict[str, Any]:
        return {}

    def execute_mapping(self, state: MigrationState, mapping: dict[str, Any]) -> dict[str, Any]:
        return {
            "mapping_key": mapping["mapping_key"],
            "mapping_name": mapping["mapping_name"],
            "status": "NEEDS_REVIEW",
            "safe_summary": "Shadow workflow prepared the mapping contract; domain adapters were not configured.",
        }

    def cross_validate(self, state: MigrationState) -> dict[str, Any]:
        return {"validation_artifact_refs": []}


def _creates_new_project(supervisor_plan: dict[str, Any]) -> bool:
    # operation="create" alone means "create one if none is open"; only an
    # explicit force_new overrides the project open in the browser.
    return bool(dict(supervisor_plan.get("project_decision") or {}).get("force_new"))


def _project_decision(supervisor_plan: dict[str, Any], open_project_id: str | None) -> dict[str, Any]:
    """Honor an explicit supervisor "create"; otherwise reuse the open project.

    Before this, the open page's project always won, so "create a new TMD
    project" silently added every draft to whatever project was on screen.
    """
    decision = dict(supervisor_plan.get("project_decision") or {})
    if _creates_new_project(supervisor_plan):
        return {**decision, "project_id": None, "operation": "create", "force_new": True}
    return {
        **decision,
        "project_id": open_project_id,
        "operation": "reuse" if open_project_id else "create",
    }


def _default_execution_steps(source: SourcePreparationSpecV1, effort: EffortLevel, policy=None) -> list[dict[str, Any]]:
    """Create a truthful fallback plan when the supervisor leaves presentation steps implicit."""
    policy = policy or EFFORT_POLICIES[effort]
    steps: list[dict[str, Any]] = []
    sequence = 1
    tables = [value for value in [source.driving_source, *source.supporting_sources, source.target_table] if value]
    for table in dict.fromkeys(tables):
        steps.append({
            "sequence": sequence, "title": f"Inspect {table}",
            "description": "Read the caller-visible table contract and column metadata used by this plan.",
            "phase": "plan_analysis", "query_kind": "metadata", "sql": f"DESCRIBE TABLE {table}",
            "runs_before_approval": True, "runs_after_approval": False,
        })
        sequence += 1
    if effort is not EffortLevel.LIGHT and source.driving_source:
        steps.append({
            "sequence": sequence, "title": "Profile the driving source",
            "description": f"Run a bounded Snowflake sample (up to {policy.profile_row_limit} rows) to assess nulls, keys, and source suitability.",
            "phase": "plan_analysis", "query_kind": "profile",
            "sql": f"SELECT * FROM {source.driving_source} LIMIT {policy.profile_row_limit}",
            "runs_before_approval": True, "runs_after_approval": False,
        })
        sequence += 1
    for derived in source.derived_sources:
        sql = str(derived.get("sql") or derived.get("sql_outline") or "").strip()
        steps.append({
            "sequence": sequence, "title": f"Validate derived source {derived.get('name') or derived.get('id') or sequence}",
            "description": "Compile and preview this CTE/derived-source query before saving it to the run-owned draft.",
            "phase": "validation", "query_kind": "derived_source", "sql": sql or None,
            "dynamic_sql": not bool(sql), "runs_before_approval": False, "runs_after_approval": True,
            "draft_writes": ["derived-source draft"],
        })
        sequence += 1
    steps.extend([
        {"sequence": sequence, "title": "Create or reuse the run-owned drafts", "description": "Create the project and STTM drafts, then save sources, joins, CTEs, and preprocessing rules. Publishing is excluded.", "phase": "draft_execution", "query_kind": "none", "runs_before_approval": False, "runs_after_approval": True, "draft_writes": ["project draft", "STTM draft", "source-preparation rules"]},
        {"sequence": sequence + 1, "title": "Auto Map and apply complex transformations", "description": "Generate source-to-target mappings with FIR evidence; invoke the transformation specialist only for complex mappings, then autosave draft rows.", "phase": "draft_execution", "query_kind": "mapping", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True, "draft_writes": ["mapping rows", "transformation rules"]},
        {"sequence": sequence + 2, "title": "Compile and explain the generated SQL", "description": "Compile the mapping query, run EXPLAIN, and repair or optimize a candidate only after revalidation.", "phase": "validation", "query_kind": "explain", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True},
    ])
    sequence += 3
    if policy.validation_depth in {"preview", "reconcile"}:
        steps.append({"sequence": sequence, "title": "Run a bounded Snowflake preview", "description": f"Execute only the generated SELECT/WITH query, limited to {policy.preview_row_limit} rows and configured timeout/result-size caps.", "phase": "preview", "query_kind": "preview", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True})
        sequence += 1
    if policy.validation_depth == "reconcile":
        steps.append({"sequence": sequence, "title": "Reconcile the preview output", "description": "Run bounded row, key, relationship, contract, and blast-radius checks at High effort.", "phase": "validation", "query_kind": "reconciliation", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True})
        sequence += 1
    steps.append({"sequence": sequence, "title": "Return the unpublished draft", "description": "Return draft links, lineage, evidence, receipts, preview results, and unresolved items without publishing the STTM.", "phase": "delivery", "query_kind": "none", "runs_before_approval": False, "runs_after_approval": True})
    return steps


def build_migration_graph(
    handlers: WorkflowHandlers | None = None,
    *,
    checkpointer: Any = None,
) -> Any:
    domain = handlers or DefaultWorkflowHandlers()

    def normalize(state: MigrationState) -> dict[str, Any]:
        prompt = str(state.get("prompt") or "").strip()
        if not prompt:
            messages = state.get("messages") or []
            prompt = str(getattr(messages[-1], "content", "") if messages else "").strip()
        return {
            "prompt": prompt,
            "status": "INTAKE",
            "review_items": list(state.get("review_items") or []),
            "mapping_results": list(state.get("mapping_results") or []),
            "retrieved_learning_ids": list(state.get("retrieved_learning_ids") or []),
            "used_learning_ids": list(state.get("used_learning_ids") or []),
            "validation_artifact_refs": list(state.get("validation_artifact_refs") or []),
            "messages": [AIMessage(content="Migration request normalized.")],
        }

    def authorize(state: MigrationState) -> dict[str, Any]:
        updates = domain.authorize_scope(state)
        return {**updates, "status": "PLANNING", "messages": [AIMessage(content="Requested scope authorized.")]}

    def ingest(state: MigrationState) -> dict[str, Any]:
        updates = domain.ingest_attachments(state)
        return {**updates, "messages": [AIMessage(content="Attachments parsed as untrusted evidence.")]}

    def manifest(state: MigrationState) -> dict[str, Any]:
        existing = list(state.get("manifest") or [])
        planned = existing or build_manifest(
            str(state.get("prompt") or ""),
            requested_mappings=list(state.get("requested_mappings") or []),
            target_scope=list(state.get("authorized_target_scope") or []),
        )
        missing_targets = [item["mapping_name"] for item in planned if not item.get("target_table")]
        authorized_targets = list(state.get("authorized_target_scope") or [])
        if missing_targets:
            # Authorized target scope is itself verified input. A resumed or
            # prebuilt manifest can still have an empty target_table even when
            # that scope contains the target selected by the supervisor. Do
            # not discard it and fall back to a generic search interrupt.
            candidate_tables = [
                str(value)
                for value in (
                    state.get("target_candidates")
                    or authorized_targets
                )
                if str(value).strip()
            ][:3]
            if len(candidate_tables) == 1:
                for item in planned:
                    if not item.get("target_table"):
                        item["target_table"] = candidate_tables[0]
                authorized_targets = list(dict.fromkeys([*authorized_targets, candidate_tables[0]]))
                missing_targets = []
            choices = [
                {
                    "choice_id": f"target_{index + 1}",
                    "label": table,
                    "description": "Use this caller-visible table as the target contract.",
                    "impact": "Creates the run-owned STTM draft against this exact contract.",
                    "selection_payload": {
                        "target_tables": {
                            item["mapping_key"]: table for item in planned if not item.get("target_table")
                        }
                    },
                    "recommended": index == 0,
                }
                for index, table in enumerate(candidate_tables)
            ]
            if not choices:
                # Catalog discovery is autonomous supervisor work, not a user
                # decision. Reaching the compiled executor without candidates
                # means discovery/validation was incomplete. Ask only for a
                # concrete override; never offer a button that resumes with no
                # target and recreates this same interrupt.
                choices = []
            answer = interrupt(
                {
                    "category": "target_scope",
                    "question": (
                        "Which schema-qualified target table should this migration use?"
                        if missing_targets == ["Mapping"]
                        else "Which schema-qualified target table should each requested mapping use?"
                    ),
                    "affected_mappings": missing_targets,
                    "safe_summary": "Target contracts are required before draft mappings can be created.",
                    "choices": choices,
                    "recommended_choice_id": choices[0]["choice_id"] if choices else None,
                    "allow_free_text": True,
                }
            ) if missing_targets else None
            if isinstance(answer, dict):
                targets = answer.get("target_tables") or {}
                for item in planned:
                    item["target_table"] = targets.get(item["mapping_key"], item.get("target_table"))
                # This answer is an explicit authenticated human-in-the-loop
                # scope grant. Domain adapters still validate FQNs and the
                # delegated Snowflake role remains the final authority.
                authorized_targets = list(dict.fromkeys([
                    *authorized_targets,
                    *[str(value) for value in targets.values() if value],
                ]))
        return {
            "manifest": planned,
            "authorized_target_scope": authorized_targets,
            "manifest_version": int(state.get("manifest_version") or 0) + 1,
            "messages": [AIMessage(content=f"Migration manifest contains {len(planned)} mapping(s).")],
        }

    def prepare_plan(state: MigrationState) -> dict[str, Any]:
        page_context = dict(state.get("page_context") or {})
        if not page_context.get("source_tables") and state.get("authorized_source_scope"):
            page_context["source_tables"] = [
                {
                    "database": parts[0],
                    "schema": parts[1],
                    "table": parts[2],
                }
                for value in state.get("authorized_source_scope") or []
                if len(parts := str(value).strip('"').split(".")) == 3
            ]
        if not page_context.get("target_table"):
            target = next(
                (
                    str(item.get("target_table"))
                    for item in state.get("manifest") or []
                    if item.get("target_table")
                ),
                None,
            )
            if target and len(parts := target.strip('"').split(".")) == 3:
                page_context["target_table"] = {
                    "database": parts[0], "schema": parts[1], "table": parts[2]
                }
        workspace = WorkbenchContextSnapshotV1.model_validate(page_context)
        semantic = workspace.semantic_bundle or workspace.semantic
        semantic_status = "available" if getattr(semantic, "bundle_hash", None) else "unavailable"
        prior_evidence: list[EvidenceReference] = []
        for index, item in enumerate(page_context.get("prior_run_evidence") or []):
            if not isinstance(item, dict):
                continue
            refs = [*(item.get("evidence_refs") or []), *(item.get("artifact_refs") or [])]
            prior_evidence.append(EvidenceReference(
                evidence_id=str(refs[0] if refs else f"prior-run:{index + 1}"),
                kind=str(item.get("event_type") or "prior_run_receipt"),
                subject=str(item.get("capability") or "durable prior-run evidence"),
                provenance="assistant_conversation:prior_run_evidence",
                artifact_ref=str((item.get("artifact_refs") or [None])[0] or "") or None,
                validated=True,
                used=False,
            ))
        context = MappingContextPackageV1(
            run_id=str(state.get("run_id") or ""),
            thread_id=str(state.get("run_id") or ""),
            app_user_id=str(state.get("app_user_id") or state.get("actor_user_id") or ""),
            snowflake_username=str(state.get("snowflake_username") or "") or None,
            tenant_id=str(state.get("tenant_id") or "default"),
            effective_role=str(state.get("effective_role") or ""),
            authorized_schemas=list(state.get("authorized_schemas") or []),
            workspace=workspace,
            stored_semantic_context=StoredSemanticContextReference(
                status=semantic_status,
                bundle_id=getattr(semantic, "bundle_id", None),
                bundle_hash=getattr(semantic, "bundle_hash", None),
                semantic_view_name=(
                    getattr(semantic, "semantic_view_name", None)
                    or getattr(semantic, "view_name", None)
                ),
                composed_model_hash=getattr(semantic, "composed_model_hash", None),
                provenance=["SemanticContextService:stored_registry"] if semantic_status == "available" else [],
            ),
            precedent_evidence=prior_evidence,
        )
        supervisor_plan = dict(state.get("supervisor_plan") or {})
        source_preparation = SourcePreparationSpecV1.model_validate(
            supervisor_plan.get("source_preparation") or {
            "driving_source": (workspace.driving_table.qualified_name if workspace.driving_table else None),
            "supporting_sources": [
                table.qualified_name
                for table in workspace.source_tables
                if not workspace.driving_table
                or table.qualified_name.upper() != workspace.driving_table.qualified_name.upper()
            ],
            "selected_columns_by_table": workspace.selected_columns_by_table,
            "relationships": workspace.relationships,
            "derived_sources": [item.model_dump(mode="json") for item in workspace.derived_sources],
            "filters": workspace.filters.model_dump(mode="json"),
            "grouping": [workspace.filters.group_by_sql] if workspace.filters.group_by_sql else [],
            "sorting": [workspace.filters.order_by_sql] if workspace.filters.order_by_sql else [],
            "target_table": workspace.target_table.qualified_name if workspace.target_table else None,
            }
        )
        manifest_value = list(state.get("manifest") or [])
        revision = int(state.get("plan_revision") or 0) + 1
        run_id = str(state.get("run_id") or "")
        effort = EffortLevel(str(state.get("effort") or EffortLevel.MEDIUM.value))
        execution_steps = list(supervisor_plan.get("execution_steps") or [])
        if not execution_steps:
            execution_steps = _default_execution_steps(source_preparation, effort, policy_from_state(state))
        plan = MigrationPlanArtifactV1(
            plan_id=f"plan_{uuid5(NAMESPACE_URL, f'{run_id}:{revision}').hex}",
            revision=revision,
            run_id=run_id,
            thread_id=run_id,
            original_request=str(state.get("prompt") or ""),
            normalized_intent=str(supervisor_plan.get("normalized_intent") or state.get("prompt") or "").strip(),
            context_hash=context.context_hash,
            mapping_specs=supervisor_plan.get("mapping_specs") or [],
            dependencies=supervisor_plan.get("dependencies") or [],
            project_decision=_project_decision(supervisor_plan, state.get("project_id") or workspace.project_id),
            source_preparation=source_preparation,
            auto_map=AutoMapExecutionSpecV1.model_validate(supervisor_plan.get("auto_map") or {
                "requested_mappings": list(state.get("requested_mappings") or []),
                "required_specialists": ["AGT_SOURCE_MAPPING", "AGT_TRANSFORMATION_RULE"],
                "validation_gates": list(
                    policy_from_state(state).cross_mapping_checks
                ),
            }),
            agents=["DEEP_MIGRATION_SUPERVISOR", "AGT_SOURCE_MAPPING", "AGT_TRANSFORMATION_RULE"],
            tools=["catalog_discovery", "read_stored_semantic_context", "fir_retrieval", "migration_executor"],
            planned_writes=[
                "run-owned project"
                if not state.get("project_id") or _creates_new_project(supervisor_plan)
                else "run-owned STTM draft",
                "source-preparation workspace snapshot",
                "target-column mapping rows",
                "validation artifacts",
            ],
            validation_plan=list(
                policy_from_state(state).cross_mapping_checks
            ),
            risks=list(dict.fromkeys([
                *(["Multiple source tables require validated join definitions."]
                  if len(workspace.source_tables) > 1 and not workspace.relationships
                  else []),
                # Host findings on the supervisor plan (e.g. targets or sources
                # a multi-target plan leaves out) stay on the approval card.
                *[str(value) for value in supervisor_plan.get("risks") or [] if str(value).strip()][:20],
            ])),
            budgets={
                "policy_snapshot": policy_from_state(state).model_dump_json(),
                "effort": str(state.get("effort") or EffortLevel.MEDIUM.value),
                "mapping_count": len(manifest_value),
            },
            decisions=list(supervisor_plan.get("decisions") or []),
            execution_steps=execution_steps,
        )
        return {
            "mapping_context_package": context.model_dump(mode="json"),
            "migration_plan": plan.model_dump(mode="json"),
            "plan_revision": revision,
            "plan_approval_required": str(state.get("run_mode") or "auto") == "plan",
            "approved_plan_hash": None if str(state.get("run_mode") or "auto") == "plan" else plan.plan_hash,
            "status": "AWAITING_CONFIRMATION" if str(state.get("run_mode") or "auto") == "plan" else "EXECUTING",
            "messages": [AIMessage(content="Prepared an immutable evidence-backed draft plan for approval.")],
        }

    def coordinate_plan(state: MigrationState) -> dict[str, Any]:
        updates = domain.coordinate_plan(state)
        return {
            **updates,
            "status": "PLANNING",
            "messages": [AIMessage(content="The Deep supervisor supplied a host-validated migration plan.")],
        }

    def clarify_research(state: MigrationState) -> dict[str, Any]:
        request = dict(state.get("research_clarification") or {})
        if not request:
            return {}
        choices = list(request.get("choices") or [])[:3]
        selected = str(request.get("selected_source") or "").strip()
        if selected:
            known = {str(value).upper() for value in [
                *(state.get("discovered_catalog_tables") or []),
                *(state.get("authorized_source_scope") or []),
            ]}
            if selected.upper() not in known:
                raise ValueError("The selected driving source is not in the verified current catalog")
        else:
            answer = interrupt({
                "category": "source_research_choice",
                "question": str(request.get("question") or "Which current source defines one target row?"),
                "safe_summary": str(request.get("safe_summary") or "Current source evidence needs a business-grain decision."),
                "choices": choices,
                "recommended_choice_id": None,
                "allow_free_text": False,
                "subject_keys": ["source"],
                "evidence_ids": list(request.get("evidence_ids") or []),
                "action_digest": str(request.get("action_digest") or ""),
                "artifact_revision": str(request.get("artifact_revision") or "1"),
            })
            selected = str(answer.get("selected_value") or "") if isinstance(answer, dict) else ""
            if selected not in {str(item.get("selection_payload", {}).get("selected_value") or "") for item in choices}:
                raise ValueError("The source answer does not match this research checkpoint")
        resolver = getattr(domain, "resolve_source_clarification", None)
        if not callable(resolver):
            return {"status": "NEEDS_REVIEW", "review_items": [{"category": "source_research_unavailable",
                "blocking": True, "safe_summary": "The source research resolver is unavailable."}]}
        resolved = dict(resolver(state, selected) or {})
        join_resolver = getattr(domain, "resolve_join_clarifications", None)
        join_questions = list(resolved.get("join_questions") or []) if callable(join_resolver) else []
        if join_questions:
            answers: list[dict[str, Any]] = []
            validator = getattr(domain, "validate_join_candidate", None)
            # A path whose every join was verified against the data and cleared
            # the confidence and margin thresholds needs no question. It is
            # applied, shown as a step with its confidence, and stays reviewable
            # in the draft's joins. The graph node replays deterministically.
            auto_policy = getattr(domain, "auto_apply_verified_joins", None)
            auto_enabled = bool(auto_policy()) if callable(auto_policy) else False
            auto_recorder = getattr(domain, "record_auto_resolved_join", None)
            # Confirm every contract these paths touch with one batched read
            # instead of one catalog query per join check (and per replay).
            warm = getattr(domain, "prepare_join_validation", None)
            if callable(warm):
                warm([join for question in join_questions for option in list(question.get("options") or [])[:3]
                      for join in option.get("joins") or [] if isinstance(join, dict)])
            asked: list[dict[str, Any]] = []
            for question in join_questions:
                options = list(question.get("options") or [])[:3]
                best = next((option for option in options if option.get("recommended")), None)
                if auto_enabled and best and best.get("joins"):
                    checked = validator(list(best["joins"])) if callable(validator) else {"status": "succeeded"}
                    if checked.get("status") == "succeeded":
                        answers.append({"joins": list(best["joins"]), "auto": True})
                        if callable(auto_recorder):
                            auto_recorder(state, question, best)
                        continue
                asked.append(question)
            join_questions = asked
            # A join a user already confirmed for these (or identically shaped)
            # tables is reused instead of asked again, after the same contract
            # check. It connects to the driver or an already applied table.
            remember = getattr(domain, "remembered_join_paths", None)
            if callable(remember) and join_questions:
                applied_tables = [join[side] for answer in answers for join in answer.get("joins") or []
                                  for side in ("left_table", "right_table") if isinstance(join, dict)]
                remembered = remember(state, [str(question.get("target") or "") for question in join_questions],
                                      [selected, *applied_tables])
                reuse_recorder = getattr(domain, "record_remembered_join", None)
                still_open: list[dict[str, Any]] = []
                for question in join_questions:
                    target_key = str(question.get("target") or "").strip('"').upper()
                    path = remembered.get(target_key)
                    checked = (validator(list(path["joins"])) if callable(validator) else {"status": "succeeded"}) if path else None
                    if path and checked.get("status") == "succeeded":
                        # "auto": already a stored learning, not a new confirmation.
                        answers.append({"joins": list(path["joins"]), "auto": True})
                        if callable(reuse_recorder):
                            reuse_recorder(state, target_key, path)
                        continue
                    still_open.append(question)
                join_questions = still_open
            # Without auto-apply, questions whose best path is recommended are
            # confirmed together; only the genuinely split ones are asked singly.
            recommended_paths = [
                (question, next(option for option in list(question.get("options") or [])[:3] if option.get("recommended")))
                for question in join_questions
                if any(option.get("recommended") and option.get("joins") for option in list(question.get("options") or [])[:3])
            ]
            if not auto_enabled and len(recommended_paths) >= 2:
                lines = [f"- {str(question.get('target') or '').split('.')[-1]}: {best.get('label')}"
                         for question, best in recommended_paths]
                batch = {str(question.get("target") or ""): str(best.get("id") or "") for question, best in recommended_paths}
                batch_answer = interrupt({
                    "category": "source_join_path_batch",
                    "question": f"Use the recommended, data-verified join for these {len(recommended_paths)} tables?\n" + "\n".join(lines),
                    "safe_summary": "\n".join(lines),
                    "choices": [
                        {"choice_id": "accept_recommended_joins", "label": "Use all recommended joins",
                         "description": "Apply every recommended join listed above.",
                         "impact": "Each join was verified against the current data.", "recommended": True,
                         "selection_payload": {"batch_decision": "accept_recommended", "values": batch}},
                        {"choice_id": "review_each_join", "label": "Review each join",
                         "description": "Ask about each join separately.", "impact": "One question per table.",
                         "recommended": False, "selection_payload": {"batch_decision": "review_each"}},
                    ],
                    "recommended_choice_id": "accept_recommended_joins",
                    "allow_free_text": False,
                    "subject_keys": ["join", *batch],
                    "action_digest": hashlib.sha256(json.dumps({"driver": selected, "batch": sorted(batch.items())},
                                                               sort_keys=True).encode()).hexdigest(),
                    "artifact_revision": str(int(state.get("plan_revision") or 0) + 1),
                })
                if isinstance(batch_answer, dict) and batch_answer.get("batch_decision") == "accept_recommended":
                    accepted = set()
                    for question, best in recommended_paths:
                        checked = validator(list(best["joins"])) if callable(validator) else {"status": "succeeded"}
                        if checked.get("status") == "succeeded":
                            answers.append({"joins": list(best["joins"])})
                            accepted.add(id(question))
                    join_questions = [question for question in join_questions if id(question) not in accepted]
            for index, question in enumerate(join_questions):
                target = str(question.get("target") or "")
                options = list(question.get("options") or [])[:3]
                rejection = ""
                while True:
                    choices = [{
                        "choice_id": f"join_path_{index}_{option_index}",
                        "label": str(option.get("label") or "Use this candidate path"),
                        "description": str(option.get("description") or "Review this evidence-backed path."),
                        "impact": ("Every join on this path was verified against the current data."
                                   if option.get("confidence") is not None else
                                   "The current join columns have been checked; row cardinality is validated during preparation."),
                        "recommended": bool(option.get("recommended")),
                        **({"confidence": float(option["confidence"])} if option.get("confidence") is not None else {}),
                        "selection_payload": {"join_question_index": index, "option_id": option.get("id"),
                                              **({"confidence": option["confidence"]} if option.get("confidence") is not None else {})},
                    } for option_index, option in enumerate(options)]
                    target_leaf = target.split(".")[-1]
                    choices.append({
                        "choice_id": f"join_exclude_{index}",
                        "label": f"Leave {target_leaf} out of this mapping",
                        "description": (f"Map the target without {target_leaf}; target columns that only it "
                                        "could supply are reported for review."),
                        "impact": f"{target_leaf} is removed from the source graph for this target.",
                        # Without any verified path, excluding is the only safe default.
                        "recommended": not options,
                        "selection_payload": {"join_question_index": index, "exclude_source": target},
                    })
                    recommended_choice = next((choice["choice_id"] for choice in choices if choice["recommended"]), None)
                    no_path = (f"No verified join connects {target_leaf} to {str(question.get('driver') or '').split('.')[-1]}: "
                               f"{question.get('no_path_reason') or 'no column pair matched by name, type and data'}. "
                               "Enter the join columns, or leave it out of this mapping.")
                    response = interrupt({
                        "category": "source_join_path",
                        "question": f"Join path {index + 1} of {len(join_questions)}: How should {target} connect to {question.get('driver')}?"
                                    + (f" Historical CTE leads: {', '.join(question['cte_leads'])}." if question.get("cte_leads") else ""),
                        "safe_summary": rejection or (no_path if not options else
                                                      f"Join path {index + 1} of {len(join_questions)} needs a business decision."),
                        "choices": choices,
                        "recommended_choice_id": recommended_choice,
                        "allow_free_text": True,
                        "answer_hint": ("TABLE.COLUMN = TABLE.COLUMN; add TABLE.COLUMN = 'value' to filter a join (for example "
                                        "a polymorphic type column); for code/alias lookups: NORMALIZED_OR(SOURCE.VALUE, LOOKUP.CODE, LOOKUP.ALIAS)"),
                        "subject_keys": ["join", target],
                        "action_digest": hashlib.sha256(json.dumps({"driver": selected, "question": question,
                            "remaining_options": [option.get("id") for option in options], "finding": rejection}, sort_keys=True).encode()).hexdigest(),
                        "artifact_revision": str(int(state.get("plan_revision") or 0) + 1),
                    })
                    if isinstance(response, dict) and response.get("exclude_source"):
                        if response.get("join_question_index") != index or str(response["exclude_source"]) != target:
                            raise ValueError("The join answer does not match this research checkpoint")
                        answers.append({"exclude": target})
                        break
                    if isinstance(response, dict) and response.get("option_id"):
                        chosen = next((option for option in options if option.get("id") == response["option_id"]), None)
                        if chosen is None or response.get("join_question_index") != index:
                            raise ValueError("The join answer does not match this research checkpoint")
                        joins = list(chosen.get("joins") or [])
                        answer = {"joins": joins}
                    else:
                        rule = str(response.get("answer") or "").strip() if isinstance(response, dict) else str(response or "").strip()
                        if not rule:
                            raise ValueError("A join path answer is required")
                        joins = []
                        if callable(validator):
                            try:
                                from app.agent_tools.join_research import parse_join_rules
                                selected_tables = list(dict.fromkeys(value for value in [
                                    question.get("driver"), target,
                                    *(state.get("authorized_source_scope") or []),
                                    *(state.get("discovered_catalog_tables") or []),
                                ] if value))
                                joins = parse_join_rules(rule, selected_tables, preferred_schemas=[
                                    str(value).rsplit(".", 1)[0] for value in (target, question.get("driver")) if value])
                            except ValueError as exc:
                                rejection = str(exc)
                                continue
                        answer = {"rule": rule}
                    checked = validator(joins) if callable(validator) else {"status": "succeeded"}
                    if checked.get("status") == "succeeded":
                        answers.append(answer)
                        break
                    rejection = str(checked.get("summary") or "That join is not supported by the current table contracts.")
                    if isinstance(response, dict) and response.get("option_id"):
                        options = [option for option in options if option.get("id") != response["option_id"]]
            resolved = dict(join_resolver(state, answers) or {})
        if resolved.get("status") == "succeeded" and isinstance(resolved.get("supervisor_plan"), dict):
            source_plan = dict(resolved["supervisor_plan"].get("source_preparation") or {})
            verified_sources = [source_plan.get("driving_source"), *(source_plan.get("supporting_sources") or [])]
            return {"supervisor_plan": resolved["supervisor_plan"], "research_clarification": {},
                    "authorized_source_scope": list(dict.fromkeys([
                        *(state.get("authorized_source_scope") or []),
                        *(str(value) for value in verified_sources if value),
                    ])),
                    "status": "PLAN_REVISION_REQUIRED" if request.get("require_supervisor_completion") else "PLANNING",
                    "plan_revision_request": {"category": "complete_requested_design",
                                              "instruction": "Reuse the verified source and joins. Complete all requested CTEs, filters, Firm Values and column transformations before draft execution."}
                    if request.get("require_supervisor_completion") else {}}
        details = dict(resolved.get("data") or {})
        findings = list(dict.fromkeys(
            str(item).strip() for item in [
                *(details.get("unresolved") or []),
                *[f"Target column {column} has no verified current source or value candidate."
                  for column in details.get("uncovered_target_columns") or []],
            ] if str(item).strip()
        ))[:20]
        category = str(resolved.get("error_code") or "source_design_incomplete")
        fallback = str(resolved.get("summary") or "The selected source still lacks a complete verified graph.")
        if findings:
            join_findings = all("join path" in item.casefold() for item in findings)
            assistant_message = (
                f"Your choice of {selected} was recorded. The plan cannot proceed until these "
                "evidence gaps are resolved:\n\n"
                + "\n".join(f"- {item}" for item in findings)
                + ("\n\nCheck current joins and stored semantic relationships in Workbench, or provide "
                   "the business join columns and cardinality in a new Plan request. "
                   if join_findings else "\n\nReview this evidence and revise the Plan request. ")
                + "The agent has not created a project or draft."
            )
        else:
            assistant_message = (
                f"Your choice of {selected} was recorded, but the plan could not be validated: "
                f"{fallback} No project or draft was created."
            )
        return {"status": "NEEDS_REVIEW", "assistant_message": assistant_message,
                "review_items": [{
                    "category": category,
                    "blocking": True,
                    "safe_summary": finding,
                } for finding in (findings or [fallback])]}

    def resolve_ambiguities(state: MigrationState) -> dict[str, Any]:
        plan = dict(state.get("supervisor_plan") or {})
        decisions = list(plan.get("decisions") or [])
        changed = False
        thresholds = getattr(domain, "decision_thresholds", None)
        min_confidence, min_margin = thresholds() if callable(thresholds) else (0.75, 0.15)
        project_scope = str(state.get("project_id") or "")
        imported_value_names: set[str] = set()

        def value_name(value: Any) -> str:
            return "".join(character for character in str(value or "").upper() if character.isalnum())

        def gated(decision: dict[str, Any]) -> bool:
            return bool(decision.get("alternatives") or decision.get("allow_free_text")) and not (
                float(decision.get("confidence") or 0) >= min_confidence
                and float(decision.get("score_margin") or 0) >= min_margin
            )

        def fingerprint(decision: dict[str, Any]) -> str:
            subject = str(decision.get("subject") or "selection")
            target = str(dict(plan.get("source_preparation") or {}).get("target_table") or "").strip('"').upper()
            key = str(decision.get("decision_key") or "").upper()
            # Firm-specific values are only ever remembered within one project.
            scope = f":project={project_scope}" if subject in {"value_binding", "value_binding_import"} else ""
            return f"decision:{subject}:{target}:{key}{scope}"

        def options(decision: dict[str, Any]) -> list[dict[str, Any]]:
            return [{
                "value": decision.get("selected_value"),
                "label": decision.get("selected_label") or decision.get("selected_value"),
                "description": decision.get("selected_description") or decision.get("rationale"),
                "impact": decision.get("selected_impact") or "Use this cited candidate in the draft plan.",
                "evidence_ids": decision.get("evidence_ids") or [],
                "recommended": decision.get("recommended") is True,
            }, *list(decision.get("alternatives") or [])]

        def option_value(option: dict[str, Any]) -> str:
            return str(option.get("value") or option.get("selected_value") or "")

        def recommended_value(decision: dict[str, Any]) -> str | None:
            flagged = [option for option in options(decision)[:3] if option.get("recommended") is True]
            value = option_value(flagged[0]) if len(flagged) == 1 else ""
            return value if value and value != "__provide_current__" else None

        def digest_for(index: int) -> str:
            return hashlib.sha256(json.dumps(
                {"plan": plan, "decision_index": index}, sort_keys=True, default=str,
                separators=(",", ":"),
            ).encode()).hexdigest()

        def apply_selection(index: int, decision: dict[str, Any], selected: str, digest: str) -> None:
            nonlocal changed
            subject = str(decision.get("subject") or "selection")
            values = options(decision)
            source = dict(plan.get("source_preparation") or {})
            if subject == "target":
                source["target_table"] = selected
            elif subject == "source":
                source["driving_source"] = selected
            elif subject == "grain":
                source["intended_grain"] = selected
            elif subject == "join":
                chosen = next((value for value in values if str(value.get("value") or "") == selected), None)
                replacement = chosen.get("relationship") if chosen else None
                if selected != str(decision.get("selected_value") or "") and not isinstance(replacement, dict):
                    raise ValueError("A join choice must carry a verified relationship contract")
                if isinstance(replacement, dict):
                    def table_name(raw: Any) -> str:
                        if isinstance(raw, dict):
                            raw = ".".join(str(raw.get(key) or "") for key in ("database", "schema", "table"))
                        return str(raw or "").strip('"').upper()

                    key = str(decision.get("decision_key") or "")
                    existing = [dict(item) for item in source.get("relationships") or []]
                    replaced = False
                    for position, item in enumerate(existing):
                        pair = " / ".join(sorted((table_name(item.get("left_table")), table_name(item.get("right_table")))))
                        if pair == key:
                            existing[position] = replacement
                            replaced = True
                    if not replaced:
                        raise ValueError("The selected join no longer matches this plan revision")
                    source["relationships"] = existing
            elif subject == "value_binding":
                bindings = [dict(item) for item in source.get("value_bindings") or []]
                name = str(decision.get("decision_key") or "")
                for binding in bindings:
                    if str(binding.get("name") or "") == name:
                        data_type = str(binding.get("data_type") or "").upper()

                        selected = normalize_typed_project_value(selected, data_type)

                        while not valid_typed_project_value(selected, data_type):
                            correction = interrupt({
                                "category": "value_binding_input",
                                "question": f"Enter a valid {data_type or 'current'} value for {name}.",
                                "safe_summary": "The supplied value does not match the typed project-value contract.",
                                "choices": [], "allow_free_text": True,
                                "subject_keys": [subject], "action_digest": digest,
                                "artifact_revision": str(int(state.get("plan_revision") or 0) + 1),
                            })
                            selected = str(correction.get("answer") or "").strip() if isinstance(correction, dict) else str(correction or "").strip()
                            selected = normalize_typed_project_value(selected, data_type)
                        binding.update({"resolved_value": selected, "source": "user_answer",
                                        "applicability": "current_project", "approval_state": "approved",
                                        "resolution_status": "resolved"})
                source["value_bindings"] = bindings
            elif subject == "value_binding_import":
                if not selected.startswith("import:") and selected != "review_individually":
                    raise ValueError("Select the reviewed source project or review values individually")
                if selected.startswith("import:"):
                    imported_value_names.update(
                        value_name(name) for name in decision.get("names") or [] if value_name(name)
                    )
            plan["source_preparation"] = source
            decisions[index] = {**decision, "selected_value": selected, "confidence": 1.0,
                                "score_margin": 1.0, "alternatives": []}
            changed = True

        pending = [index for index, decision in enumerate(decisions) if gated(decision)]
        if not pending:
            return {}

        # 1. Reuse this user's earlier answer to the same question. A remembered
        #    choice counts only while it is still one of the current options;
        #    a remembered free-text value applies only to the same project.
        remembered_lookup = getattr(domain, "remembered_decisions", None)
        remembered = remembered_lookup(state, [fingerprint(decisions[index]) for index in pending]) if callable(remembered_lookup) else {}
        for index in list(pending):
            decision = decisions[index]
            prior = remembered.get(fingerprint(decision))
            if not prior:
                continue
            offered = {option_value(option) for option in options(decision)}
            if prior in offered or (str(decision.get("subject")) == "value_binding" and decision.get("allow_free_text")):
                apply_selection(index, decision, prior, digest_for(index))
                pending.remove(index)

        # 2. Ask once for every decision the evidence already recommends.
        batchable = [index for index in pending if recommended_value(decisions[index])]
        if len(batchable) >= 2:
            lines = [
                f"- {str(decisions[index].get('subject') or 'selection').replace('_', ' ')}"
                f"{(' ' + str(decisions[index].get('decision_key'))) if decisions[index].get('decision_key') else ''}: "
                + str(next(option.get("label") or option_value(option) for option in options(decisions[index])
                           if option_value(option) == recommended_value(decisions[index])))
                for index in batchable
            ]
            batch_values = {fingerprint(decisions[index]): recommended_value(decisions[index]) for index in batchable}
            batch_digest = hashlib.sha256(json.dumps(
                {"plan": plan, "batch": sorted(batch_values.items())}, sort_keys=True, default=str,
                separators=(",", ":"),
            ).encode()).hexdigest()
            answer = interrupt({
                "category": "confidence_gate_batch",
                "question": (
                    f"Use the recommended, evidence-backed choice for these {len(batchable)} decisions?\n"
                    + "\n".join(lines)
                ),
                "safe_summary": "\n".join(lines),
                "choices": [
                    {"choice_id": "accept_recommended", "label": "Use all recommendations",
                     "description": "Apply every recommended choice listed above.",
                     "impact": "The plan continues without further questions for these decisions.",
                     "recommended": True,
                     "selection_payload": {"batch_decision": "accept_recommended", "values": batch_values}},
                    {"choice_id": "review_each", "label": "Review each decision",
                     "description": "Ask about each decision separately.",
                     "impact": "One question per decision.", "recommended": False,
                     "selection_payload": {"batch_decision": "review_each"}},
                ],
                "recommended_choice_id": "accept_recommended",
                "allow_free_text": False,
                "subject_keys": list(batch_values),
                "action_digest": batch_digest,
                "artifact_revision": str(int(state.get("plan_revision") or 0) + 1),
            })
            if isinstance(answer, dict) and answer.get("batch_decision") == "accept_recommended":
                for index in batchable:
                    apply_selection(index, decisions[index], str(recommended_value(decisions[index])), batch_digest)
                    pending.remove(index)

        # 3. Only what evidence cannot settle is asked one at a time.
        for index in pending:
            decision = decisions[index]
            subject = str(decision.get("subject") or "selection")
            if subject == "value_binding" and value_name(decision.get("decision_key")) in imported_value_names:
                decisions[index] = {
                    **decision,
                    "confidence": 1.0,
                    "score_margin": 1.0,
                    "alternatives": [],
                }
                changed = True
                continue
            values = options(decision)
            recommended_indices = [
                position for position, option in enumerate(values[:3])
                if option.get("recommended") is True
            ]
            recommended_index = recommended_indices[0] if len(recommended_indices) == 1 else None
            choices = []
            for option_index, value in enumerate(values[:3]):
                selected = option_value(value)
                choices.append({
                    "choice_id": f"{subject}_{index}_{option_index}",
                    "label": str(value.get("label") or selected),
                    "description": str(value.get("description") or "Evidence-backed alternative."),
                    "impact": str(value.get("impact") or "Changes this draft plan selection."),
                    "evidence_ids": list(value.get("evidence_ids") or decision.get("evidence_ids") or []),
                    "recommended": option_index == recommended_index,
                    "selection_payload": {"decision_subject": subject, "selected_value": selected},
                })
            digest = digest_for(index)
            answer = interrupt({
                "category": "confidence_gate",
                "question": str(decision.get("question") or f"Which {subject.replace('_', ' ')} candidate should this migration use?"),
                "safe_summary": str(decision.get("rationale") or "A business decision requires review."),
                "choices": choices,
                "recommended_choice_id": next((item["choice_id"] for item in choices if item["recommended"]), None),
                "allow_free_text": bool(decision.get("allow_free_text")),
                # The fingerprint lets a later run reuse this answer.
                "subject_keys": [subject, fingerprint(decision)],
                "evidence_ids": list(decision.get("evidence_ids") or []),
                "action_digest": digest,
                "artifact_revision": str(int(state.get("plan_revision") or 0) + 1),
            })
            selected = str(answer.get("selected_value") or answer.get("answer") or "").strip() if isinstance(answer, dict) else str(answer or "").strip()
            if selected == "__provide_current__":
                supplied = interrupt({
                    "category": "value_binding_input",
                    "question": str(decision.get("question") or "Enter the current project value."),
                    "safe_summary": "The historical value will not be reused without a current-project value.",
                    "choices": [], "allow_free_text": True,
                    "subject_keys": [subject], "action_digest": digest,
                    "artifact_revision": str(int(state.get("plan_revision") or 0) + 1),
                })
                selected = str(supplied.get("answer") or "").strip() if isinstance(supplied, dict) else str(supplied or "").strip()
            if not selected or selected == "__provide_current__":
                raise ValueError("A current value or cited choice is required to resolve this decision")
            apply_selection(index, decision, selected, digest)
        if changed:
            plan["decisions"] = decisions
            return {"supervisor_plan": plan}
        return {}

    def offer_plan_mode(state: MigrationState) -> dict[str, Any]:
        # The user already selected Plan or Agent mode. A complexity suggestion
        # is informative and must not add another mode-selection interruption.
        # Explicit Plan mode still reaches the immutable approval node.
        return {}

    def approve_plan(state: MigrationState) -> dict[str, Any]:
        plan = MigrationPlanArtifactV1.model_validate(state.get("migration_plan") or {})
        answer = interrupt(
            {
                "category": "plan_approval",
                "question": "Implement this run-owned draft workflow plan or make further changes?",
                "safe_summary": "The researched draft plan is ready for approval; no Workbench records have been changed.",
                "business_reason": "Approval freezes the exact evidence-backed plan revision before any Workbench draft mutation.",
                "affected_resources": list(plan.planned_writes),
                "evidence_ids": list(plan.evidence_refs),
                "choices": [
                    {
                        "choice_id": "approve",
                        "label": "Implement plan",
                        "description": "Execute this exact plan against a run-owned draft.",
                        "impact": "Creates or updates only the displayed run-owned drafts; publishing and target DML remain blocked.",
                        "recommended": True,
                        "selection_payload": {"decision": "approve"},
                    },
                    {
                        "choice_id": "edit",
                        "label": "Update plan",
                        "description": "Return requested changes and produce a superseding plan revision.",
                        "impact": "No draft execution occurs until the revised plan is approved.",
                        "selection_payload": {"decision": "edit"},
                    },
                    {
                        "choice_id": "reject",
                        "label": "Reject",
                        "description": "Stop without creating or changing Workbench records.",
                        "impact": "Ends this run with no draft mutations.",
                        "selection_payload": {"decision": "reject"},
                    },
                    {"choice_id": "cancel", "label": "Cancel", "description": "Cancel this run without creating drafts.", "impact": "The plan remains available as evidence.", "selection_payload": {"decision": "cancel"}},
            ],
                "recommended_choice_id": "approve",
                "allow_free_text": False,
                "action_digest": plan.plan_hash,
                "artifact_revision": str(plan.revision),
                "plan": plan.model_dump(mode="json"),
            }
        )
        if isinstance(answer, dict):
            decision = str(answer.get("decision") or answer.get("choice_id") or answer.get("answer") or "").lower()
        else:
            decision = str(answer or "").lower()
        if decision in {"edit", "edit plan", "revise", "revise plan"}:
            revision_answer = interrupt({
                "category": "plan_edit",
                "question": "What should change in this plan revision?",
                "safe_summary": "Describe the source, target, join, CTE, mapping, or validation changes. The current approval will be superseded.",
                "subject_keys": [plan.plan_id],
                "choices": [
                    {
                        "choice_id": "change_sources",
                        "label": "Change sources or joins",
                        "description": "Revise the driving source, supporting sources, relationships, grain, or derived CTEs.",
                        "recommended": True,
                    },
                    {
                        "choice_id": "change_target",
                        "label": "Change target",
                        "description": "Research and select a different target contract.",
                    },
                    {
                        "choice_id": "change_validation",
                        "label": "Change validation",
                        "description": "Revise mapping coverage, reconciliation, or validation requirements.",
                    },
                ],
                "recommended_choice_id": "change_sources",
                "allow_free_text": True,
                "action_digest": plan.plan_hash,
                "artifact_revision": str(plan.revision),
            })
            if isinstance(revision_answer, dict):
                feedback = str(
                    revision_answer.get("feedback")
                    or revision_answer.get("answer")
                    or revision_answer.get("choice_id")
                    or ""
                ).strip()
            else:
                feedback = str(revision_answer or "").strip()
            if not feedback:
                feedback = "Re-evaluate the current plan and return evidence-backed alternatives."
            return {
                "status": "PLAN_REVISION_REQUIRED",
                "approved_plan_hash": None,
                "plan_revision_request": feedback,
                "messages": [AIMessage(content="The previous plan approval was superseded; a revised plan is being prepared.")],
            }
        if decision not in {"approve", "approved", "approve plan"}:
            return {
                "status": "CANCELLED",
                "approved_plan_hash": None,
                "messages": [AIMessage(content="The draft plan was not approved; no Workbench records were changed.")],
            }
        return {
            "approved_plan_hash": plan.plan_hash,
            "status": "EXECUTING",
            "messages": [AIMessage(content="The exact plan revision was approved for run-owned draft execution.")],
        }

    def create_project(state: MigrationState) -> dict[str, Any]:
        updates = domain.create_project(state)
        project_state = {**state, **updates}
        for decision in list(dict(state.get("supervisor_plan") or {}).get("decisions") or []):
            if str(decision.get("subject") or "") != "value_binding_import":
                continue
            selected = str(decision.get("selected_value") or "")
            if not selected.startswith("import:"):
                continue
            importer = getattr(domain, "import_firm_values", None)
            if not callable(importer):
                raise ValueError("Firm-value import is unavailable")
            imported = importer(
                project_state,
                selected.split(":", 1)[1],
                [str(value) for value in decision.get("names") or [] if str(value).strip()],
                overwrite=False,
            )
            if getattr(imported, "status", None) != "succeeded":
                raise ValueError(getattr(imported, "summary", None) or "Firm-value import failed")
        return {**updates, "status": "EXECUTING", "messages": [AIMessage(content="Draft project created or reused idempotently.")]}

    def create_mappings(state: MigrationState) -> dict[str, Any]:
        updates = domain.create_mappings(state)
        return {**updates, "messages": [AIMessage(content="Draft mappings and dependency DAG created or reused.")]}

    def prepare_sources(state: MigrationState) -> dict[str, Any]:
        plan = MigrationPlanArtifactV1.model_validate(state.get("migration_plan") or {})
        if state.get("approved_plan_hash") != plan.plan_hash:
            raise PermissionError("The source-preparation plan is not approved or has changed")
        updates = domain.prepare_sources(state)
        preparation = dict(updates.get("source_preparation_result") or {})
        if preparation.get("status") == "needs_input":
            # The supervisor must investigate these diagnostics and choose whether
            # a question is necessary. A user response cannot waive source validity.
            return {
                **updates,
                "status": "PLAN_REVISION_REQUIRED",
                "approved_plan_hash": None,
                "plan_revision_request": {
                    "category": "source_preparation",
                    "diagnostics": preparation,
                    "evidence_ids": plan.evidence_refs,
                    "instruction": "Resolve from authorized evidence first; ask only for missing business decisions or authority. Revalidate the source graph before mapping.",
                },
                "messages": [AIMessage(content="Source preparation requires evidence-backed revision before Auto Map can start.")],
            }
        return {
            **updates,
            "messages": [AIMessage(content="Source preparation was persisted and validated before Auto Map.")],
        }

    def execute_mappings(state: MigrationState) -> dict[str, Any]:
        from app.agent_runs.policy import policy_from_state
        from app.migration_workflow.scheduler import Partition, PartitionScheduler, PartitionState, merge_column_partitions
        manifest_value = list(state.get("manifest") or [])
        by_key = {str(item["mapping_key"]): item for item in manifest_value}
        # A mapping whose own source-preparation diagnostics were blocking
        # (e.g. a high-fanout join) skips Auto Map/compile entirely; its
        # sibling mappings still run through the partition scheduler.
        preparation = dict(state.get("source_preparation_result") or {})
        blocked_diagnostics = {
            key: dict(preparation.get("mappings", {}).get(key) or {})
            for key in preparation.get("blocked_mapping_keys") or [] if key in by_key
        }
        if hasattr(domain, "build_partitions"):
            partitions = domain.build_partitions(state)
        else:
            partitions = [Partition(partition_id=item["mapping_key"], mapping_key=item["mapping_key"], waits_for=item.get("dependencies") or []) for item in manifest_value]
        partitions = [partition for partition in partitions if partition.mapping_key not in blocked_diagnostics]
        def persist(partition):
            if hasattr(domain, "save_partition"):
                domain.save_partition(state, partition)
        def active():
            if state.get("cancel_requested"):
                from app.agent_runtime.execution import ExecutionCancelledError
                raise ExecutionCancelledError("Run cancelled")
            if hasattr(domain, "check_active"):
                domain.check_active()
        def execute(partition):
            mapping = dict(by_key[partition.mapping_key])
            if hasattr(domain, "execute_partition"):
                return domain.execute_partition(state, mapping, partition, partitions)
            result = domain.execute_mapping(state, mapping)
            return {**result, "partition_state": "COMPLETED" if result.get("status") == "READY_FOR_REVIEW" else "NEEDS_REVIEW"}
        completed = PartitionScheduler(max_workers=policy_from_state(state).max_parallel_mappings, persist=persist, check_active=active).run(partitions, execute)
        results = []
        for key, mapping in by_key.items():
            if key in blocked_diagnostics:
                diagnostics = blocked_diagnostics[key]
                result = {
                    "status": "NEEDS_REVIEW",
                    "safe_summary": f"Source preparation for {mapping.get('mapping_name') or key} found a blocking finding; "
                                    "mapping SQL was not generated for it.",
                    "unresolved": list(diagnostics.get("unresolved") or []),
                    "partitions": [],
                }
                result.update(mapping_key=key, mapping_name=mapping["mapping_name"], sttm_id=mapping.get("sttm_id"))
                results.append(result)
                mapping["status"] = "NEEDS_REVIEW"
                continue
            owned = [p for p in completed if p.mapping_key == key]
            final = next((p for p in owned if p.stage == "compile"), owned[-1] if owned else None)
            result = dict(final.result) if final else {}
            if not owned or any(p.state != PartitionState.COMPLETED for p in owned):
                result.update(status="NEEDS_REVIEW", safe_summary="Required mapping partitions or dependencies remain unresolved.")
            result.update(mapping_key=key, mapping_name=mapping["mapping_name"], sttm_id=mapping.get("sttm_id"))
            result["partitions"] = [p.model_dump(mode="json") for p in owned]
            results.append(result)
            mapping["status"] = result.get("status", "NEEDS_REVIEW")
        return {"manifest": list(by_key.values()), "mapping_results": results, "status": "VALIDATING"}

    def validate(state: MigrationState) -> dict[str, Any]:
        updates = domain.cross_validate(state)
        review_items = list(state.get("review_items") or []) + list(updates.pop("review_items", []) or [])
        blocked = any(item.get("blocking", True) for item in review_items) or any(
            item.get("status") != "READY_FOR_REVIEW" for item in state.get("mapping_results") or [])
        status = "NEEDS_REVIEW" if blocked else "COMPLETED_WITH_REVIEW_ITEMS" if review_items else "READY_FOR_REVIEW"
        return {
            **updates,
            "review_items": review_items,
            "status": status,
            "messages": [AIMessage(content="Validation results recorded. Required unresolved work remains incomplete; nothing was published.")],
        }

    graph = StateGraph(MigrationState)
    graph.add_node("normalize_request", normalize)
    graph.add_node("authorize_scope", authorize)
    graph.add_node("ingest_attachments", ingest)
    graph.add_node("create_manifest", manifest)
    graph.add_node("clarify_research", clarify_research)
    graph.add_node("coordinate_plan", coordinate_plan)
    graph.add_node("resolve_ambiguities", resolve_ambiguities)
    graph.add_node("offer_plan_mode", offer_plan_mode)
    graph.add_node("prepare_plan", prepare_plan)
    graph.add_node("approve_plan", approve_plan)
    graph.add_node("create_draft_project", create_project)
    graph.add_node("prepare_sources", prepare_sources)
    graph.add_node("create_draft_mappings", create_mappings)
    graph.add_node("execute_mapping_dag", execute_mappings)
    graph.add_node("cross_mapping_validation", validate)
    graph.add_edge(START, "normalize_request")
    graph.add_edge("normalize_request", "authorize_scope")
    graph.add_edge("authorize_scope", "ingest_attachments")
    graph.add_edge("ingest_attachments", "create_manifest")
    graph.add_edge("create_manifest", "clarify_research")
    graph.add_conditional_edges(
        "clarify_research",
        lambda state: "review" if state.get("status") in {"NEEDS_REVIEW", "PLAN_REVISION_REQUIRED"} else "continue",
        {"review": END, "continue": "coordinate_plan"},
    )
    graph.add_edge("coordinate_plan", "resolve_ambiguities")
    graph.add_edge("resolve_ambiguities", "offer_plan_mode")
    graph.add_conditional_edges(
        "offer_plan_mode",
        lambda state: "cancel" if state.get("status") == "CANCELLED" else "prepare",
        {"cancel": END, "prepare": "prepare_plan"},
    )
    graph.add_conditional_edges(
        "prepare_plan",
        lambda state: "approval" if state.get("plan_approval_required") else "execute",
        {"approval": "approve_plan", "execute": "create_draft_project"},
    )
    graph.add_conditional_edges(
        "approve_plan",
        lambda state: (
            "cancelled" if state.get("status") == "CANCELLED"
            else "revise" if state.get("status") == "PLAN_REVISION_REQUIRED"
            else "approved"
        ),
        {"cancelled": END, "revise": END, "approved": "create_draft_project"},
    )
    graph.add_edge("create_draft_project", "create_draft_mappings")
    graph.add_edge("create_draft_mappings", "prepare_sources")
    graph.add_conditional_edges(
        "prepare_sources",
        lambda state: "blocked" if state.get("status") in {"CANCELLED", "PLAN_REVISION_REQUIRED"} else "ready",
        {"blocked": END, "ready": "execute_mapping_dag"},
    )
    graph.add_edge("execute_mapping_dag", "cross_mapping_validation")
    graph.add_edge("cross_mapping_validation", END)
    return graph.compile(checkpointer=checkpointer)
