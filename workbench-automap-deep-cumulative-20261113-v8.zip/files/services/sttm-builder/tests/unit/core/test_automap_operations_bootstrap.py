"""Bootstrap contract: fail on incompatible ownership inventory without repairs."""
from contextlib import contextmanager
from pathlib import Path
import pytest
from scripts.bootstrap_sttm_metadata_infra import BASE_SQL_FILES, validate_automap_operations
ROOT=Path(__file__).resolve().parents[5]


class Connection:
    def __init__(self,hybrid=True,primary='OPERATION_KEY',unique='SLOT_ID',invalid=0):
        self.hybrid=hybrid;self.primary=primary;self.unique=unique;self.invalid=invalid;self.sql=[]
    @contextmanager
    def cursor(self):
        connection=self
        class Cursor:
            description=[('column_name',)]
            def execute(self,query):self.query=query;connection.sql.append(query)
            def fetchall(self):
                if self.query.startswith('SHOW HYBRID'):return [('operations',)] if connection.hybrid else []
                if self.query.startswith('SHOW PRIMARY'):return [(connection.primary,)]
                if self.query.startswith('SHOW UNIQUE'):return [(connection.unique,)]
                if self.query.startswith('SELECT COUNT'):return [(connection.invalid,)]
                return []
        yield Cursor()


def test_bootstrap_installs_enforced_key_ownership_table_without_slots_or_control_updates():
    filename=ROOT/'infra/snowflake/automap-call-operations.sql'
    assert filename in BASE_SQL_FILES
    sql=filename.read_text()
    assert 'CREATE HYBRID TABLE IF NOT EXISTS' in sql
    assert 'OPERATION_KEY VARCHAR(64) PRIMARY KEY' in sql
    assert 'AUTOINCREMENT START 1 INCREMENT 1 NOORDER UNIQUE' in sql
    assert 'OPERATIONS_CONTROL' not in sql
    assert 'GENERATOR(ROWCOUNT' not in sql
    connection=Connection();validate_automap_operations(connection,'TEST.METADATA')
    assert all(query.startswith(('SHOW ','SELECT ')) for query in connection.sql)


@pytest.mark.parametrize('options',[{'hybrid':False},{'primary':'WRONG_KEY'},{'unique':'WRONG_ID'},{'invalid':1}])
def test_bootstrap_rejects_incompatible_inventory_without_resetting_it(options):
    connection=Connection(**options)
    with pytest.raises(RuntimeError):validate_automap_operations(connection,'TEST.METADATA')
    assert all(query.startswith(('SHOW ','SELECT ')) for query in connection.sql)
