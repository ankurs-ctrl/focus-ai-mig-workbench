'use client';
import {useEffect,useState} from 'react';
import {Box,Typography,Paper,Table,TableHead,TableBody,TableRow,TableCell,TextField,Alert,Chip} from '@mui/material';
import {authService} from '@/services/authService';
import {getAllProjectsSummary,type ProjectsSummary} from '@/services/projectService';
import AdminResourceActions from './AdminResourceActions';
export default function ResourcesPage(){
 const [data,setData]=useState<ProjectsSummary>({projects:[],sttms:[]}),[admin,setAdmin]=useState(false),[search,setSearch]=useState(''),[error,setError]=useState('');
 const load=()=>{void getAllProjectsSummary(true).then(setData).catch(cause=>setError(cause.message));};
 useEffect(()=>{void authService.getSession().then(session=>{if(session.app_persona==='ADMIN'){setAdmin(true);load();}else setError('Only the Admin persona can manage projects and mappings.');}).catch(()=>setError('Sign in as an administrator to continue.'));},[]);
 return <Box sx={{p:4,overflow:'auto',width:'100%',bgcolor:'#f7f8fa'}}><Typography variant="h5" sx={{fontWeight:700}}>Projects & Mappings</Typography><Typography sx={{mt:1,color:'#64748b'}}>Admin controls for keeping your workspace organized.</Typography>
 {error?<Alert severity="error" sx={{my:2}}>{error}</Alert>:null}{admin?<><Alert severity="info" sx={{my:3}}>Archive or delete items from listings. Saved versions and published history are retained. Removing a project also hides its mappings.</Alert><TextField size="small" label="Search projects and mappings" value={search} onChange={event=>setSearch(event.target.value)} sx={{mb:2,width:360}}/>
 <Paper variant="outlined"><Table><TableHead><TableRow><TableCell>Name</TableCell><TableCell>Type</TableCell><TableCell>Status</TableCell><TableCell align="right">Admin actions</TableCell></TableRow></TableHead><TableBody>
 {[...data.projects.map(project=>({id:project.project_id,name:project.project_name,kind:'project' as const,status:project.status})),...data.sttms.map(mapping=>({id:mapping.sttm_id,name:mapping.sttm_name||mapping.sttm_id,kind:'mapping' as const,status:mapping.status}))].filter(item=>item.name.toLowerCase().includes(search.toLowerCase())).map(item=><TableRow key={`${item.kind}:${item.id}`}><TableCell><strong>{item.name}</strong></TableCell><TableCell sx={{textTransform:'capitalize'}}>{item.kind}</TableCell><TableCell><Chip size="small" label={item.status}/></TableCell><TableCell align="right"><AdminResourceActions {...item} onRemoved={load}/></TableCell></TableRow>)}
 </TableBody></Table></Paper></>:null}</Box>;
}
