import type {
  DerivedSource,
  JoinConfig,
  MappingState,
  ParsedSqlWorkspaceApplyPayload,
} from "@/features/sttm/types/sttm.types";
import type { SqlUploadResult } from "@/features/sttm/mapping/sql-bundle-review-panel";
import { relationAliasFor } from "@/features/sttm/mapping/relation-alias";
import { sqlIdentifierKey, sqlIdentifierParts, sqlIdentifierSuffixMatches, renderSqlIdentifier } from "@/features/sttm/shared/sql-identifiers";
import { scopedJoinEditing, type ScopedJoin } from '@/features/sttm/shared/scoped-join';

const normalizeIdentifier = sqlIdentifierKey;

function uploadedConstantValue(sql: string): string {
  // Parser constants are SQL tokens; mapping constants are raw values. Decode
  // one complete literal only, including SQLGlot's escaped-quote rendering.
  if (!/^'(?:''|\\['\\]|[^'\\])*'$/.test(sql)) return sql;
  return sql.slice(1, -1).replace(/''|\\(['\\])/g, (_match, escaped: string | undefined) => escaped ?? "'");
}

/**
 * Derived-source identity for an uploaded CTE. Scoped to the uploaded asset so
 * two uploads that both contain a CTE named `base` never share a catalog id.
 */
export function uploadedCteId(scope: string, name: string): string {
  return `sql-cte:${scope}:${name}`;
}

/** Rewrite `<sqlAlias>.` qualifiers onto workspace relation aliases, outside literals. */
function rewriteQualifiers(sql: string, qualifiers: Map<string, string>): string {
  if (!qualifiers.size || !sql) return sql;
  const tokens = sql.match(/'(?:''|\\[\s\S]|[^'\\])*'|"(?:""|[^"])*"|--[^\r\n]*|\/\*[\s\S]*?\*\/|\$\$[\s\S]*?\$\$|[A-Za-z_][A-Za-z0-9_$]*|\s+|[\s\S]/g) ?? [];
  const isTrivia = (token: string) => /^(?:\s|--|\/\*)/.test(token);
  const significant = tokens.flatMap((token, index) => isTrivia(token) ? [] : [index]);
  for (let position = 0; position < significant.length; position += 1) {
    const index = significant[position];
    const token = tokens[index];
    const previous = tokens[significant[position - 1]];
    if (previous === '.' || previous === '$' || tokens[significant[position + 1]] !== '.') continue;
    if (sqlIdentifierParts(token).length !== 1) continue;
    // Identifier keys preserve quoted case and fold only unquoted names.
    tokens[index] = qualifiers.get(sqlIdentifierKey(token)) ?? token;
  }
  return tokens.join('');
}

/**
 * Convert an uploaded SQL document into an editable workspace.
 *
 * The workspace mirrors the SQL's own structure instead of wrapping the whole
 * query in one opaque relation: CTEs read by the outer query become selected
 * derived sources, physical tables become sources, outer joins become canvas
 * relationships, and every target column is bound to those relations through
 * workspace aliases. The full uploaded SQL is kept as the authored mapping SQL
 * until the user edits the graph.
 */
export function buildSqlUploadWorkspace(
  uploaded: SqlUploadResult,
  options?: { approvedProjectValueNames?: string[]; existingDerivedSources?: DerivedSource[] },
): ParsedSqlWorkspaceApplyPayload {
  const parsed = uploaded.parsed_summary;
  const scope = String(uploaded.asset_id ?? "").slice(0, 12) || "upload";
  const sqlVariables = Object.fromEntries(
    Object.entries(parsed?.variables ?? {}).map(([name, value]) => [
      name.trim().replace(/^\$/, "").toUpperCase(),
      String(value),
    ]),
  );
  const approvedProjectValueKeys = options?.approvedProjectValueNames
    ? new Set(options.approvedProjectValueNames.map((name) => name.toUpperCase()))
    : null;
  const rows = uploaded.import_preview?.mapping_rows ?? parsed?.column_mappings ?? [];
  const ctes = parsed?.ctes ?? [];
  if (ctes.some((cte) => {
    const contract = cte.scope_contract as Record<string, unknown> | undefined;
    return Array.isArray(contract?.diagnostics) && contract.diagnostics.length > 0;
  })) throw new Error("A CTE has recursive or conflicting scoped dependencies. The original SQL is preserved; it cannot be applied as a partial dependency graph.");
  const existingById = new Map((options?.existingDerivedSources ?? []).map(source => [source.id, source]));
  const matchedSource = (item: Record<string, unknown>) => {
    const source = existingById.get(String(item.existing_relation_id ?? ''));
    return source && String(item.name) === relationAliasFor(source.id, source.sourceName) ? source : undefined;
  };
  for (const item of ctes) {
    const contract = item.scope_contract as Record<string, unknown> | undefined;
    if (!contract?.parent_scope_id || contract.parent_scope_id === (parsed?.query_scopes ?? []).find(scope => !scope.parent_scope_id)?.scope_id) {
      const existingAlias = [...existingById.values()].some(source => relationAliasFor(source.id, source.sourceName) === item.name);
      if (existingAlias && !matchedSource(item)) {
        throw new Error('The generated CTE definition changed. Edit the existing derived source to update its definition; no replacement identities or mapping changes were applied.');
      }
    }
  }
  const retainedCtes = ctes.filter(item => {
    // Definitions nested inside a proven existing envelope already belong to
    // that source's exact SQL. Do not add them again as independent canvas tags.
    let parent = (item.scope_contract as Record<string, unknown> | undefined)?.parent_scope_id;
    const visited = new Set<string>();
    while (parent && !visited.has(String(parent))) {
      visited.add(String(parent));
      const ancestor = ctes.find(candidate => String(candidate.scope_id) === String(parent));
      if (ancestor && matchedSource(ancestor)) return false;
      const parentScope = (parsed?.query_scopes ?? []).find(candidate => String(candidate.scope_id) === String(parent));
      parent = parentScope?.parent_scope_id
        ?? (ancestor?.scope_contract as Record<string, unknown> | undefined)?.parent_scope_id;
    }
    return true;
  });
  const cteIdByScope = new Map(ctes.filter((item) => item.scope_id).map((item) => [
    String(item.scope_id), matchedSource(item)?.id ?? uploadedCteId(scope, `${String(item.scope_id)}:${String(item.name)}`),
  ]));
  const outerScopes = (parsed?.query_scopes ?? []).filter((item) => !item.parent_scope_id);
  if (outerScopes.length > 1) throw new Error("Select one query before applying SQL to the builder; multiple query scopes cannot be merged safely.");
  if (outerScopes.some((item) => item.query_kind !== "select")) throw new Error("Set-operation SQL is retained in SQL mode; its branches cannot be flattened into one mapping graph.");
  for (const queryScope of outerScopes) {
    const relations = (queryScope.relations ?? []) as Array<Record<string, unknown>>;
    const identities = relations.map((item) => String(item.source_scope_id ?? normalizeIdentifier(item.relation_name)));
    // Repeated CTE occurrences still need independent derived-source instances.
    if (relations.some((item, index) => item.source_scope_id && identities.indexOf(identities[index]) !== index))
      throw new Error("Repeated derived sources require separate relation-instance controls. SQL is unchanged; no partial graph was applied.");
  }
  const outerCteScopes = new Set(outerScopes.flatMap((item) => (item.relations as Array<Record<string, unknown>> ?? [])
    .map((relation) => String(relation.source_scope_id ?? ""))));
  if (ctes.length && !outerScopes.length) {
    throw new Error("The upload response is missing CTE query scopes. Check that the backend is up to date and upload again; no partial mapping was applied.");
  }
  const canonicalCteId = (item: Record<string, unknown>) => cteIdByScope.get(String(item.scope_id))
    ?? uploadedCteId(scope, String(item.name ?? "derived_source"));
  const cteNameByUpper = new Map(
    ctes
      .map((item) => String(item.name ?? "").trim())
      .filter(Boolean)
      .map((name) => [name.toUpperCase(), name] as const),
  );

  // Table identity: synchronous qualification results keyed by the identifier
  // exactly as the SQL wrote it (after USE context was applied).
  const references = uploaded.import_preview?.table_references ?? [];
  const hasCatalogEvidence = uploaded.import_preview?.table_references !== undefined;
  // Apply retains identities, not execution authorization. An exact FQN does
  // not need a successful metadata lookup; unavailable catalog checks stay warnings.
  const isResolvedReference = (reference: Record<string, unknown>) =>
    reference.resolution_status === "resolved"
    && sqlIdentifierParts(reference.resolved_fqn).length === 3;
  const rejectedIdentifiers = new Set(references
    .filter((reference) => !isResolvedReference(reference) && reference.resolution_status !== "lookup_failed")
    .flatMap((reference) => [reference.raw_identifier, reference.resolved_fqn])
    .filter(Boolean).map(normalizeIdentifier));
  const resolvedByIdentifier = new Map<string, string>();
  for (const reference of references) {
    const resolved = String(reference.resolved_fqn ?? "").trim();
    if (!isResolvedReference(reference)) continue;
    resolvedByIdentifier.set(normalizeIdentifier(reference.raw_identifier), resolved);
    resolvedByIdentifier.set(normalizeIdentifier(resolved), resolved);
  }
  const resolvedValues = Array.from(new Set(resolvedByIdentifier.values()));
  const resolvePhysical = (value: unknown): string | null => {
    const normalized = normalizeIdentifier(value);
    if (!sqlIdentifierParts(value).length) return null;
    if (rejectedIdentifiers.has(normalized)) return null;
    const direct = resolvedByIdentifier.get(normalized);
    if (direct) return renderSqlIdentifier(sqlIdentifierParts(direct));
    if (sqlIdentifierParts(value).length === 3) return renderSqlIdentifier(sqlIdentifierParts(value));
    // Unknown short names cannot borrow a candidate or another table's suffix.
    if (references.some(reference => normalizeIdentifier(reference.raw_identifier) === normalized
      && !isResolvedReference(reference))) return null;
    const suffixMatches = resolvedValues.filter((candidate) =>
      sqlIdentifierSuffixMatches(candidate, value));
    return suffixMatches.length === 1 ? suffixMatches[0] : null;
  };
  const outerPhysicalRelations = ((outerScopes[0]?.relations ?? []) as Array<Record<string, unknown>>)
    .filter(relation => !relation.source_scope_id);
  const sourceInstances = outerPhysicalRelations.flatMap(relation => {
    const qualifiedName = resolvePhysical(relation.relation_name);
    if (!qualifiedName || outerPhysicalRelations.filter(other =>
      normalizeIdentifier(other.relation_name) === normalizeIdentifier(relation.relation_name)).length < 2) return [];
    const sqlAlias = String(relation.alias_sql ?? (relation.alias_quoted
      ? `"${String(relation.alias).replaceAll('"', '""')}"` : relation.alias));
    const relationId = `sql-instance:${scope}:${encodeURIComponent(qualifiedName)}:${encodeURIComponent(String(relation.relation_instance_id))}:${encodeURIComponent(sqlAlias)}`;
    return [{relationId, qualifiedName, sqlAlias, parserInstanceId: String(relation.relation_instance_id)}];
  });
  const resolveScopedRelation = (relation: Record<string, unknown>): string | null => {
    if (relation.source_scope_id) {
      const id = cteIdByScope.get(String(relation.source_scope_id));
      if (!id) throw new Error(`The SQL relation scope ${relation.source_scope_id} is unavailable. The original SQL is preserved; no partial graph was applied.`);
      return id;
    }
    return sourceInstances.find(instance => instance.parserInstanceId === String(relation.relation_instance_id))?.relationId
      ?? resolvePhysical(relation.relation_name);
  };
  const resolveRelation = (value: unknown): string | null => {
    const name = String(value ?? "").trim();
    if (!name) return null;
    if (outerScopes.length) {
      const matches = ((outerScopes[0].relations ?? []) as Array<Record<string, unknown>>)
        .filter((relation) => normalizeIdentifier(relation.relation_name) === normalizeIdentifier(name));
      return matches.length === 1 ? resolveScopedRelation(matches[0]) : null;
    }
    const nameParts = sqlIdentifierParts(name);
    const cteName = nameParts.length === 1 ? cteNameByUpper.get(nameParts[0].toUpperCase()) : undefined;
    const matches = ctes.filter((item) => String(item.name).toUpperCase() === cteName?.toUpperCase());
    const outerMatch = matches.find((item) => outerCteScopes.has(String(item.scope_id)));
    return cteName ? (outerMatch ? canonicalCteId(outerMatch) : matches.length === 1 ? canonicalCteId(matches[0]) : null) : resolvePhysical(name);
  };
  const workspaceAliasFor = (relationId: string): string => {
    if (relationId.startsWith("sql-cte:")) {
      return relationAliasFor(relationId, existingById.get(relationId)?.sourceName ?? relationId.split(":").pop() ?? relationId);
    }
    return relationAliasFor(relationId);
  };

  const parsedSources = parsed?.source_tables ?? parsed?.source_datasets ?? [];
  const sourceTableFqns: string[] = [];
  const unresolvedSourceTables: string[] = [];
  const unresolvedIdentities: string[] = [];
  for (const identifier of parsedSources) {
    const resolved = resolvePhysical(identifier);
    if (resolved) {
      if (!sourceTableFqns.some((value) => normalizeIdentifier(value) === normalizeIdentifier(resolved))) {
        sourceTableFqns.push(resolved);
      }
      if (hasCatalogEvidence && !references.some(reference =>
        isResolvedReference(reference) && reference.catalog_status === "available"
        && normalizeIdentifier(reference.resolved_fqn) === normalizeIdentifier(resolved))) {
        unresolvedSourceTables.push(String(identifier));
      }
    } else if (!unresolvedSourceTables.includes(String(identifier))) {
      unresolvedSourceTables.push(String(identifier));
      unresolvedIdentities.push(String(identifier));
    }
  }
  for (const reference of references) {
    const resolved = String(reference.resolved_fqn ?? "").trim();
    if (
      String(reference.reference_role ?? "") === "source"
      && isResolvedReference(reference)
      && resolved
      && !sourceTableFqns.some((value) => normalizeIdentifier(value) === normalizeIdentifier(resolved))
    ) {
      sourceTableFqns.push(resolved);
    }
  }

  if (hasCatalogEvidence && unresolvedIdentities.length) {
    // The workspace has an unresolved-name list, but no unresolved relation
    // nodes that could safely carry these edges. Do not create a partial graph.
    throw new Error(`Resolve these SQL source identities before continuing: ${unresolvedIdentities.join(", ")}. Catalog verification is unavailable or qualification is incomplete; the original SQL is preserved and no partial graph was applied.`);
  }

  // Outer-query relations and SQL alias -> workspace alias rewrites.
  const outerAliases = outerScopes.length
    ? Object.fromEntries(((outerScopes[0].relations ?? []) as Array<Record<string, unknown>>)
      .map((relation) => [String(relation.alias_sql ?? (relation.alias_quoted
        ? `"${String(relation.alias).replaceAll('"', '""')}"` : relation.alias)), String(relation.relation_name)]))
    : (parsed?.outer_relation_aliases ?? {}) as Record<string, string>;
  const qualifierRewrites = new Map<string, string>();
  const outerRelationIds: string[] = [];
  for (const [sqlAlias, relation] of Object.entries(outerAliases)) {
    const scoped = ((outerScopes[0]?.relations ?? []) as Array<Record<string, unknown>>).find(item =>
      sqlIdentifierKey(item.alias_sql ?? (item.alias_quoted ? `"${String(item.alias).replaceAll('"', '""')}"` : item.alias)) === sqlIdentifierKey(sqlAlias));
    const relationId = scoped ? resolveScopedRelation(scoped) : resolveRelation(relation);
    if (!relationId) continue;
    qualifierRewrites.set(sqlIdentifierKey(sqlAlias), workspaceAliasFor(relationId));
    if (!outerRelationIds.includes(relationId)) outerRelationIds.push(relationId);
  }
  const drivingTableId = resolveRelation(parsed?.driving_relation)
    ?? outerRelationIds[0]
    ?? sourceTableFqns[0]
    ?? null;
  if (drivingTableId && !outerRelationIds.includes(drivingTableId)) {
    outerRelationIds.unshift(drivingTableId);
  }
  const singleRelationAlias = outerRelationIds.length === 1
    ? workspaceAliasFor(outerRelationIds[0])
    : null;
  const selectedCteIds = new Set(outerRelationIds.filter((id) => id.startsWith("sql-cte:")));
  for (const scopeId of outerCteScopes) {
    const id = cteIdByScope.get(scopeId);
    if (id) selectedCteIds.add(id);
  }

  const variableBindings = new Map((parsed?.variable_bindings ?? [])
    .map((binding) => [binding.name.toUpperCase(), binding]));
  const inlineVariables = (sql: string) => sql.replace(
    /'(?:''|[^'])*'|"(?:""|[^"])*"|--[^\r\n]*|\/\*[\s\S]*?\*\/|\$\$[\s\S]*?\$\$|\$([A-Za-z_][A-Za-z0-9_]*)/g,
    (match, name: string | undefined) => {
      if (!name) return match;
      const binding = variableBindings.get(name.toUpperCase());
      if (!binding || binding.resolved_value == null) return match;
      const value = String(binding.resolved_value);
      return ["INT", "DECIMAL", "FLOAT", "NUMBER", "BOOLEAN"].includes(String(binding.inferred_type).toUpperCase())
        ? value
        : `'${value.replace(/'/g, "''")}'`;
    },
  );
  const toWorkspaceSql = (sql: unknown) =>
    rewriteQualifiers(inlineVariables(String(sql ?? "")), qualifierRewrites);
  const bareOwners = new Map<string,string[]>();
  for (const relation of (outerScopes[0]?.relations ?? []) as Array<Record<string,unknown>>) {
    const owner = resolveScopedRelation(relation);
    if (!owner) continue;
    const source = ctes.find(cte => String(cte.scope_id) === String(relation.source_scope_id));
    const outputs = (source?.output_columns ?? []) as Array<Record<string,unknown>>;
    for (const column of outputs) {
      const key = sqlIdentifierKey(column.sql_name ?? column.name);
      bareOwners.set(key,[...(bareOwners.get(key) ?? []),owner]);
    }
  }
  const toWorkspaceColumn = (column: string) => {
    const rewritten = toWorkspaceSql(column);
    if (sqlIdentifierParts(rewritten).length === 1) {
      const matches = bareOwners.get(sqlIdentifierKey(rewritten)) ?? [];
      // Physical contracts are not necessarily available at upload. Only bind
      // a unique proven CTE output; server compilation still verifies its scope.
      if (matches.length > 1) throw new Error(`Ambiguous unqualified SQL column: ${rewritten}`);
      const alias = matches.length === 1 ? workspaceAliasFor(matches[0]) : singleRelationAlias;
      if (alias) {
        return `${alias}.${rewritten}`;
      }
    }
    return rewritten;
  };

  const mappings: MappingState[] = rows.map((item, index) => {
    const targetColumn = String(
      item.target_alias ?? item.target_field ?? item.target_column ?? `COLUMN_${index + 1}`,
    );
    const physical = Array.isArray(item.physical_source_columns)
      ? item.physical_source_columns.map(String)
      : [];
    const logical = Array.isArray(item.source_columns)
      ? item.source_columns.map(String)
      : item.source_field
        ? String(item.source_field).split(",").map((value) => value.trim()).filter(Boolean)
        : [];
    const isConstant = String(item.mapping_mode ?? "").toLowerCase() === "constant";
    const sourceColumns = isConstant
      ? []
      : logical.length
        ? Array.from(new Set(logical.map(toWorkspaceColumn)))
        : physical;
    const rawConstantValue = isConstant ? String(item.constant_value ?? "") : "";
    const decodedConstant = uploadedConstantValue(rawConstantValue);
    // The text NULL collides with the legacy UI's SQL-NULL sentinel. Preserve
    // an authored NULL string as an exact expression instead of changing its value.
    const literalNeedsExpression = isConstant && rawConstantValue.startsWith("'")
      && decodedConstant.trim().toUpperCase() === 'NULL';
    const variableName = rawConstantValue.match(/^\$([A-Za-z_][A-Za-z0-9_]*)$/)?.[1];
    const resolvedVariableValue = variableName
      ? sqlVariables[variableName.toUpperCase()]
      : undefined;
    const hasResolvedSqlVariable = resolvedVariableValue !== undefined;
    const isProjectAttribute = hasResolvedSqlVariable
      && (!approvedProjectValueKeys || approvedProjectValueKeys.has(String(variableName).toUpperCase()));
    const authoredTransformation = item.transformation ?? item.expression ?? item.preprocessing_rule;
    const transformation = authoredTransformation ? item.bound_expression ?? authoredTransformation : null;
    // The server binds actual Column AST nodes within their SQL scope. Do not
    // perform bare-token substitutions: function and nested-scope names differ.
    const workspaceTransformation = transformation ? toWorkspaceSql(transformation) : null;

    return {
      id: `upload:${targetColumn}:${index}`,
      targetColumn,
      targetSqlName: String(item.target_sql_name ?? '') || undefined,
      targetType: String(item.target_data_type ?? item.target_type ?? "TEXT"),
      sourceColumn: isConstant ? null : sourceColumns[0] ?? null,
      sourceColumns,
      sourceDependencies: sourceColumns,
      sourceType: null,
      mappingMode: literalNeedsExpression ? "source" : isProjectAttribute ? "attribute" : isConstant ? "constant" : "source",
      constantValue:
        literalNeedsExpression ? null : isProjectAttribute
          ? resolvedVariableValue
          : isConstant
            ? resolvedVariableValue ?? uploadedConstantValue(rawConstantValue)
            : null,
      attributeName: isProjectAttribute ? variableName ?? null : null,
      expression: literalNeedsExpression ? rawConstantValue : isConstant ? null : workspaceTransformation,
      rule: literalNeedsExpression ? "Custom" : isConstant ? "Value" : transformation ? "Custom" : "Direct",
      status: sourceColumns.length || isConstant ? "MAPPED" : "UNMAPPED",
      nlRule: workspaceTransformation,
    };
  });

  // Only outer-query joins belong on the canvas; joins inside a CTE are part of
  // that CTE's SQL and stay editable through the derived-source editor.
  let relationships: JoinConfig[] = (parsed?.join_patterns ?? [])
    .filter((item) => String(item.scope ?? "outer") === "outer")
    .flatMap((item, index) => {
      const pairs = Array.isArray(item.key_pairs)
        ? (item.key_pairs as Array<Record<string, unknown>>)
        : [];
      const rightId = resolveRelation(item.right_table);
      const leftId = resolveRelation(pairs[0]?.left_table ?? item.left_table);
      if (!leftId || !rightId || leftId === rightId) return [];
      const conditions = pairs
        .filter((pair) => resolveRelation(pair.left_table) === leftId)
        .map((pair) => ({
          leftColumn: String(pair.left_column ?? ""),
          operator: "=",
          rightColumn: String(pair.right_column ?? ""),
        }))
        .filter((condition) => condition.leftColumn && condition.rightColumn);
      const joinType = String(item.join_type ?? "INNER")
        .replace(/\s+(OUTER\s+)?JOIN$/i, "")
        .trim()
        .toUpperCase();
      return [{
        id: `upload-join:${scope}:${index}`,
        joinType: (["INNER", "LEFT", "RIGHT", "FULL"].includes(joinType)
          ? joinType
          : "INNER") as JoinConfig["joinType"],
        leftTableId: leftId,
        rightTableId: rightId,
        source: "USER_DEFINED" as const,
        sqlPredicate: item.condition ? toWorkspaceSql(item.condition) : undefined,
        conditions: item.condition ? [] : conditions,
      }];
    });

  if (outerScopes.length) {
    const outer = outerScopes[0];
    const relations = (outer.relations ?? []) as Array<Record<string, unknown>>;
    const byInstance = new Map(relations.map((relation) => [String(relation.relation_instance_id),
      resolveScopedRelation(relation)]));
    relationships = ((outer.joins ?? []) as Array<Record<string, unknown>>).map((join, index) => {
      const rightInstance = String(join.right_relation_id);
      const referenced = (join.referenced_relation_ids ?? []) as string[];
      const structured = (join as ScopedJoin).structured;
      const leftInstance = structured?.left_relation_id ?? referenced.find((id) => id !== rightInstance) ?? String(relations[index]?.relation_instance_id);
      const leftTableId = byInstance.get(leftInstance);
      const rightTableId = byInstance.get(rightInstance);
      const joinType = String(join.join_type).replace(/\s+OUTER$/, "");
      if (!leftTableId || !rightTableId || !join.predicate || !["INNER", "LEFT", "RIGHT", "FULL"].includes(joinType)) {
        throw new Error("This join cannot be represented without changing its SQL. No partial graph was applied.");
      }
      return {id: `upload-join:${scope}:${index}`, joinType: joinType as JoinConfig["joinType"], leftTableId, rightTableId,
        ...scopedJoinEditing(join as ScopedJoin, leftInstance, rightInstance, toWorkspaceSql(join.predicate)), source: "USER_DEFINED"};
    });
  }

  const prettyCteSql = new Map((uploaded.import_preview?.cte_summary ?? [])
    .map((item) => [String(item.name ?? "").toUpperCase(), String(item.sql_text ?? "")]));
  const resolvedTarget = references.find((item) =>
    String(item.reference_role ?? "") === "target"
    && String(item.resolution_status ?? "") === "resolved"
    && Boolean(item.resolved_fqn),
  );

  return {
    sourceTableFqns,
    sourceInstances: sourceInstances.map(({relationId, qualifiedName, sqlAlias}) => ({relationId, qualifiedName, sqlAlias})),
    queryModifiers: Object.fromEntries(Object.entries((outerScopes[0]?.clauses ?? {}) as Record<string, string>)
      .filter(([key, value]) => ['having', 'qualify', 'distinct', 'limit', 'offset'].includes(key) && value)
      .map(([key, value]) => [key, toWorkspaceSql(value)])),
    unresolvedSourceTables,
    targetTableFqn: resolvedTarget
      ? String(resolvedTarget.resolved_fqn)
      : parsed?.target_table ?? parsed?.target_tables?.[0] ?? null,
    drivingTableId,
    relationships,
    mappings,
    derivedSources: retainedCtes.map((item) => {
      const existing = matchedSource(item);
      const name = existing?.sourceName ?? String(item.name ?? "derived_source");
      const id = canonicalCteId(item);
      if (existing) {
        // The SQL body is unchanged. Its original scope IDs, lineage and
        // provenance belong together; wrapper scopes must not replace them.
        return {
          id, name, isSelected: selectedCteIds.has(id),
          preserveExistingDefinition: true,
          sqlText: existing.sqlText,
          definitionSql: existing.definitionSql,
          queryScope: existing.queryScope,
          parentDerivedSourceIds: existing.parentDerivedSourceIds ?? existing.derivedSourceIds ?? [],
          drivingTableId: existing.drivingTableId,
          inputTables: existing.tableIds ?? (existing.baseSourceTables ?? []).map(table => `${table.database}.${table.schema}.${table.table}`),
          outputColumns: existing.outputColumns ?? [],
          joins: existing.joins, filters: existing.filters, purpose: existing.purpose,
        };
      }
      const queryScope = item.scope_contract && typeof item.scope_contract === "object"
        ? item.scope_contract as Record<string, unknown> : {};
      const scopeRelations = (queryScope.relations ?? []) as Array<Record<string, unknown>>;
      // UNION roots have no relations: their inputs live in child branches and
      // nested join scopes. Follow lexical parent IDs, never global CTE names.
      const ownedScopes = [queryScope];
      const ownedScopeIds = new Set([String(queryScope.scope_id ?? item.scope_id)]);
      for (let index = 0; index < ownedScopes.length; index += 1) {
        const ownerId = String(ownedScopes[index].scope_id ?? item.scope_id);
        for (const child of parsed?.query_scopes ?? []) {
          const childId = String(child.scope_id);
          if (String(child.parent_scope_id) === ownerId && !ownedScopeIds.has(childId)) {
            ownedScopeIds.add(childId);
            ownedScopes.push(child);
          }
        }
      }
      const parentIds = Array.from(new Set(ownedScopes.flatMap(owned =>
        ((owned.relations ?? []) as Array<Record<string, unknown>>).flatMap(relation => {
          const sourceScopeId = String(relation.source_scope_id ?? "");
          // Nested WITH definitions are already inside this source's SQL body.
          const parent = !ownedScopeIds.has(sourceScopeId) && cteIdByScope.get(sourceScopeId);
          return parent ? [parent] : [];
        }))));
      const relationIds = new Map(scopeRelations.map((relation) => [String(relation.relation_instance_id),
        resolveScopedRelation(relation)]));
      const joins = ((queryScope.joins ?? []) as Array<Record<string, unknown>>).flatMap((join, index) => {
        const rightId = String(join.right_relation_id);
        const structured = (join as ScopedJoin).structured;
        const leftId = structured?.left_relation_id ?? ((join.referenced_relation_ids ?? []) as string[]).find((relationId) => relationId !== rightId)
          ?? String(scopeRelations[index]?.relation_instance_id);
        const leftTableId = relationIds.get(leftId);
        const rightTableId = relationIds.get(rightId);
        const joinType = String(join.join_type).replace(/\s+OUTER$/, "");
        if (!leftTableId || !rightTableId || !join.predicate || !['INNER', 'LEFT', 'RIGHT', 'FULL'].includes(joinType)) return [];
        return [{id: String(join.join_id), joinType: joinType as 'INNER' | 'LEFT' | 'RIGHT' | 'FULL',
          leftTableId, rightTableId,
          ...scopedJoinEditing(join as ScopedJoin, leftId, rightId, String(join.predicate))}];
      });
      return {
        id,
        name,
        isSelected: selectedCteIds.has(id),
        sqlText: item.sql_text ? String(item.sql_text) : prettyCteSql.get(name.toUpperCase()) || null,
        definitionSql: item.definition_sql ? String(item.definition_sql) : null,
        queryScope,
        joins,
        parentDerivedSourceIds: Array.from(new Set(parentIds)),
        drivingTableId: scopeRelations[0]?.source_scope_id
          ? cteIdByScope.get(String(scopeRelations[0].source_scope_id))
          : resolvePhysical(item.driving_relation) ?? undefined,
        inputTables: Array.isArray(item.tables_referenced)
          ? Array.from(new Set(
              [...parentIds, ...item.tables_referenced
                .map(resolvePhysical)
                .filter((value): value is string => Boolean(value))],
            ))
          : parentIds,
        outputColumns: Array.isArray(item.output_columns)
          ? item.output_columns
            .filter((column) =>
              column
              && typeof column === "object"
              && String((column as Record<string, unknown>).name ?? "") !== "*",
            )
            .map((column) => column as Record<string, unknown>)
          : [],
        purpose: item.purpose ? String(item.purpose) : null,
        candidateReasons: Array.isArray(item.derived_source_reasons)
          ? item.derived_source_reasons.map(String)
          : [],
      };
    }),
    filterSql: parsed?.outer_where_sql ? toWorkspaceSql(parsed.outer_where_sql) : "",
    groupBySql: parsed?.outer_group_by_sql ? toWorkspaceSql(parsed.outer_group_by_sql) : "",
    orderBySql: parsed?.outer_order_by_sql ? toWorkspaceSql(parsed.outer_order_by_sql) : "",
    sql: uploaded.import_preview?.sql ?? parsed?.preview_sql ?? "",
  };
}
