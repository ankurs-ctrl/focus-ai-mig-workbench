"use client";

import { AiaBox, AiaButton, AiaContainer, AiaGrid, AiaIconButton, AiaPaper, AiaStack } from '@/components/ui';


import { AiaText } from '@/components/ui/aia-text';
import React from 'react';

import { AutoFixHighIcon, BoltIcon, CloseIcon, OpenInFullIcon, SmartToyIcon, VisibilityIcon } from '@/utils/icons';
import Footer from '@/features/layout/app-footer';
import AppHeader from '@/features/layout/app-header';
import { CLIENT_CONFIG as config } from '@/config/client.config';
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import { API_ROUTES } from "@/api/routes";

/* --- FEATURE CARD SUB-COMPONENT --- */
const FeatureCard = ({ icon, title }: { icon: any, title: string }) => (
  <AiaPaper
    elevation={0}
    sx={{
      bgcolor: '#e5e5e5',
      borderRadius: '16px',
      width: '160px',
      height: '160px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      gap: 1.5
    }}
  >
    <AiaBox sx={{ bgcolor: '#fff', p: 1, borderRadius: '50%', display: 'flex', border: '1px solid #ccc' }}>
      {React.cloneElement(icon, { sx: { fontSize: 24, color: '#000' } })}
    </AiaBox>
    <AiaText sx={{ fontWeight: 600, fontSize: '0.8rem', color: '#000', textAlign: 'center' }}>
      {title}
    </AiaText>
  </AiaPaper>
);

export default function LandingPage() {
  const startSnowflakeLogin = () => {
    const next = encodeURIComponent("/dashboard");
    window.location.href = `/api${API_ROUTES.auth.login}?next=${next}`;
  };

  return (
  <>
     <AppHeader/>

    <AiaBox sx={{ minHeight: '100vh', bgcolor: '#fff', position: 'relative', p: 4 }}>

      {/* 1. TOP HEADER (Welcome Message) */}
      <AiaBox sx={{ display: 'flex', justifyContent: 'flex-end', mb: 4 }}>
        <AiaBox sx={{
          backgroundColor: '#e5e5e5', // Light gray background
          px: 2,
          py: 0.5,
          borderRadius: '20px',
          border: '1px solid #e2e8f0', // Optional light border
          display: 'flex',
          alignItems: 'center'
        }}>
          <AiaText variant="caption" sx={{ color: '#555' }}>
            Welcome User!
          </AiaText>
        </AiaBox>
      </AiaBox>

      <AiaContainer sx={{ mt: 8, 'max-width': '90%' }}>
        <AiaBox sx={{
          display: 'flex',
          flexDirection: 'row !important',
          gap: 10, // Equivalent to spacing={10}
          width: '100%'
        }}>

          {/* LEFT COLUMN: Text Content */}
          <AiaGrid
            sx={{
              // This replaces 'item' logic
              flexGrow: 0,
              // This replaces xs={12} and md={10}
              flexBasis: {
                xs: '100%',
                md: '83.33%'
              },
              // Your custom constraint
              maxWidth: '70% !important'
            }}
          >
            <AiaText sx={{ fontWeight: 800, fontSize: '0.9rem', mb: 2 }}>
              {config.app.clientTitle}
            </AiaText>
            <AiaText variant="h1" sx={{ fontWeight: 900, fontSize: '4rem', lineHeight: 1, mb: 3 }}>
              AI-Assisted <br /> Migration Workbench
            </AiaText>
            <AiaText sx={{ color: '#666', fontSize: '1.1rem', mb: 4, maxWidth: '500px' }}>
              STTM Builder brings clarity to complex data pipelines—making ETL documentation faster, collaborative, and always up to date.
            </AiaText>

            <AiaStack spacing={1.5} sx={{ mb: 5 }}>
              {['Design.Document.Map', 'Define transformation logic', 'Collaborate in real-time'].map((text) => (
                <AiaStack
                  key={text}
                  sx={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 2 // gap: 2 is the sx equivalent of spacing={2}
                  }}
                >
                  <AiaBox sx={{ width: 5, height: 5, bgcolor: '#000', borderRadius: '50%' }} />
                  <AiaText sx={{ fontSize: '0.95rem', fontWeight: 500 }}>{text}</AiaText>
                </AiaStack>
              ))}
            </AiaStack>

            <AiaButton
              data-tour={TOUR_TARGETS.landingGetStarted}
              variant="contained"
              sx={{ bgcolor: '#007bb2', textTransform: 'none', px: 5, py: 1.5, borderRadius: '10px', fontWeight: 700 }}
              onClick={startSnowflakeLogin} >
              Sign in with Snowflake
            </AiaButton>
          </AiaGrid>

          {/* RIGHT COLUMN: Feature Cards */}
          <AiaGrid
            sx={{
              display: 'flex',
              alignItems: 'flex-start',
              justifyContent: 'flex-start'
            }}
          >
            <AiaBox sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, justifyContent: 'flex-start' }}>
              <FeatureCard icon={<VisibilityIcon />} title="STTM Viewer" />
              <FeatureCard icon={<AutoFixHighIcon />} title="STTM Builder" />
              <FeatureCard icon={<BoltIcon />} title="SQL Generation" />
            </AiaBox>
          </AiaGrid>
        </AiaBox>
      </AiaContainer>

      {/* FLOATING AI WIDGET (Bottom Right) */}
      {/* <AiaBox sx={{ position: 'fixed', bottom: 70, right: 24 }}>
        <AiaPaper elevation={4} sx={{ bgcolor: '#000', color: '#fff', borderRadius: '12px', px: 2, py: 1, display: 'flex', alignItems: 'center', gap: 6 }}>
          <AiaStack
            sx={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 1
            }}
          >
            <SmartToyIcon sx={{ fontSize: 18 }} />
            <AiaText sx={{ fontSize: '0.8rem', fontWeight: 600 }}>AI Assistant</AiaText>
          </AiaStack>
          <AiaStack direction="row" spacing={1}>
            <OpenInFullIcon sx={{ fontSize: 14, cursor: 'pointer' }} />
            <CloseIcon sx={{ fontSize: 14, cursor: 'pointer' }} />
          </AiaStack>
        </AiaPaper>
      </AiaBox> */}

      {/* FOOTER */}
        <Footer />
    </AiaBox>
    </>   
  );
}
