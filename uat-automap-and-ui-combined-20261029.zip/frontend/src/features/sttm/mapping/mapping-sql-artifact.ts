import { sha256 } from "@noble/hashes/sha256";
import type { MappingState } from "@/features/sttm/types/sttm.types";
import type { SemanticContextItem } from "@/types/api-contract";

function compilerDigest(serialized: string): string {
  const bytes = sha256(new TextEncoder().encode(serialized));
  return `sha256:${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}

export function normalizeCompilerContextHash(value: string | null | undefined): string | null {
  if (!value) return null;
  if (/^sha256:[0-9a-f]{64}$/.test(value)) return value;
  try {
    // Old snapshots stored the serialized compiler input in this field.
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? compilerDigest(value) : null;
  } catch {
    return null;
  }
}

export function savedCompilerSemanticContext(
  contextHash: string | null | undefined, projectId: string | null | undefined,
  savedSemanticContext?: unknown, savedProjectId?: string | null,
): SemanticContextItem[] | null {
  if (!projectId) return null;
  const valid = (items: unknown): items is SemanticContextItem[] =>
    Array.isArray(items) && items.every((item) =>
      item && typeof item === "object" && item.table && item.semantic_model);
  if (valid(savedSemanticContext) && String(savedProjectId) === String(projectId)) return savedSemanticContext;
  if (!contextHash) return null;
  try {
    // Compatibility with snapshots that embedded the semantic input in the hash.
    const input = JSON.parse(contextHash);
    return String(input.projectId) === String(projectId) && valid(input.semanticContext)
      ? input.semanticContext : null;
  } catch {
    return null;
  }
}

export type MappingSqlArtifactInput = {
  authoredSql?: string | null;
  authoredPreviewSql?: string | null;
  authoredContextHash?: string | null;
  /** When provided, decides authored SQL currency instead of context hashes. */
  authoredIsCurrent?: boolean;
  compiledSql?: string | null;
  compiledPreviewSql?: string | null;
  compiledScriptSql?: string | null;
  compiledReady?: boolean;
  compiledContextHash?: string | null;
  currentContextHash?: string | null;
  fallbackSql: string;
  fallbackPreviewSql: string;
  /** SQL preview can require canonical compilation instead of a row-built draft. */
  allowFallback?: boolean;
};

export type MappingCompilerContextHashInput = {
  projectId?: string | null;
  firmValues?: unknown;
  semanticContext?: unknown;
  relationGraph: unknown;
  mappings: MappingState[];
  targetTable: unknown;
  drivingTableId?: string | null;
  sourceFilterSql?: string | null;
  sourceGroupBySql?: string | null;
  sourceOrderBySql?: string | null;
};

export function buildMappingCompilerContextHash(
  input: MappingCompilerContextHashInput,
): string {
  return compilerDigest(JSON.stringify({
    compilerContractVersion: "physical-column-case-v2",
    projectId: input.projectId,
    firmValues: input.firmValues,
    semanticContext: input.semanticContext,
    relationGraph: input.relationGraph,
    mappings: input.mappings
      .filter((mapping) => mapping.status === "MAPPED")
      .map((mapping) => ({
        targetColumn: mapping.targetColumn,
        targetType: mapping.targetType,
        sourceColumn: mapping.sourceColumns?.length
          ? mapping.sourceColumns.join(", ") : mapping.sourceColumn,
        sourceColumns: mapping.sourceColumns,
        mappingMode: mapping.mappingMode,
        constantValue: mapping.constantValue,
        expression: mapping.expression,
        rule: mapping.rule,
        sourceDependencies: mapping.sourceDependencies,
        valueBindingIds: mapping.valueBindingIds,
      })),
    targetTable: input.targetTable,
    drivingTableId: input.drivingTableId,
    sourceFilterSql: input.sourceFilterSql,
    sourceGroupBySql: input.sourceGroupBySql,
    sourceOrderBySql: input.sourceOrderBySql,
  }));
}

export type MappingSqlArtifact = {
  generatedSql: string;
  previewSql: string;
  scriptSql: string;
  ready: boolean;
  source: "compiled" | "authored" | "generated";
};

export function selectMappingSqlArtifact(input: MappingSqlArtifactInput): MappingSqlArtifact {
  const compiledHash = normalizeCompilerContextHash(input.compiledContextHash);
  const compiledIsCurrent = Boolean(
    input.currentContextHash && compiledHash === input.currentContextHash,
  );
  if (compiledIsCurrent && input.compiledSql?.trim() && input.compiledPreviewSql?.trim()) {
    return {
      generatedSql: input.compiledSql ?? input.fallbackSql,
      previewSql: input.compiledPreviewSql ?? input.fallbackPreviewSql,
      scriptSql: input.compiledScriptSql?.trim() || input.compiledPreviewSql || "",
      ready: input.compiledReady === true,
      source: "compiled" as const,
    };
  }
  const authoredIsCurrent = input.authoredIsCurrent !== undefined
    ? Boolean(input.authoredIsCurrent && input.authoredSql?.trim())
    : Boolean(
        input.authoredSql?.trim()
        && (
          !input.currentContextHash
          || !input.authoredContextHash
          || input.authoredContextHash === input.currentContextHash
        ),
      );
  // An optimized/compiled query also lives in authored state. Do not resurrect
  // that copy after its project, values or semantic context became stale.
  const staleCompiledContext = Boolean(input.compiledContextHash && input.currentContextHash
    && compiledHash !== input.currentContextHash);
  if (authoredIsCurrent && !staleCompiledContext) {
    return {
      generatedSql: input.authoredSql ?? input.fallbackSql,
      previewSql: input.authoredPreviewSql?.trim() || input.fallbackPreviewSql,
      scriptSql: input.authoredPreviewSql?.trim() || input.authoredSql || "",
      ready: true,
      source: "authored" as const,
    };
  }
  return {
    generatedSql: input.allowFallback === false ? "" : input.fallbackSql,
    previewSql: input.allowFallback === false ? "" : input.fallbackPreviewSql,
    scriptSql: input.allowFallback === false ? "" : input.fallbackPreviewSql,
    ready: false,
    source: "generated" as const,
  };
}