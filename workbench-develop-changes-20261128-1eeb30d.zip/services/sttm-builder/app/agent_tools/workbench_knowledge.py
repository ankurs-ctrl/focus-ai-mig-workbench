"""Application-owned storage guide; describes routes, never grants data access."""
from __future__ import annotations
import re

# Descriptions reflect the services' storage contracts, not guessed live inventory.
ROUTES = {
 'projects': ('snowflake_projects_table', 'Project identity, lifecycle and metadata; use get_project_context for an ID, list_projects only for discovery.'),
 'mappings': ('snowflake_sttm_table', 'Mapping identity, project, status and saved SQL; get_project_context locates project mappings.'),
 'mapping_rows': ('snowflake_sttm_attributes_table', 'Current target-row definitions including CONDITION JSON; there is no separate active mapping-row table.'),
 'sources': ('snowflake_sttm_sources_table', 'Saved selected sources for a mapping; source business data stays in its own database.'),
 'versions': ('snowflake_sttm_versions_table', 'Saved mapping versions and snapshots; distinguish current drafts from published versions.'),
 'values': ('snowflake_project_attributes_table', 'Project business/Firm Values; use firm_values_inventory, never reuse another firm literal silently.'),
 'semantics': ('snowflake_semantic_native_views_table', 'Pipeline-published native semantic assets including CA_YAML_MODEL; use read_stored_semantic_context then sql_analyst when needed. Never generate or refresh semantics.'),
 'semantic_versions': ('snowflake_semantic_versions_table', 'Versioned curated semantic knowledge; available history is guidance, not proof of a current binding.'),
 'learnings': ('snowflake_semantic_learnings_table', 'Stored semantic learnings; retrieve authorized relevant records through workbench_rag and retrieve_fir_evidence.'),
 'fir': ('snowflake_fir_360_table', 'FIR lineage linking feedback, inference and recommendation; use retrieve_fir_evidence for target-specific evidence.'),
 'fir_events': ('snowflake_fir_events_table', 'Feedback/learning event records; event presence alone is not an accepted mapping recipe.'),
 'recommendations': ('snowflake_fir_agent_recommendations_table', 'Agent-specific recommendations and triggers; preserve provenance and applicability.'),
 'relationships': ('snowflake_relationship_facts_table', 'Stored relationship evidence; verify current bindings and cardinality before applying a new join.'),
 'derived_sources': ('snowflake_derived_sources_table', 'Saved derived-source definitions; preserve CTE output boundaries and population rules.'),
 'sql_assets': ('snowflake_client_sql_assets_table', 'Retained client SQL evidence; distinguish historical expressions from current executable definitions.'),
 'rag': ('snowflake_rag_documents_table', 'Searchable Workbench knowledge documents; use workbench_rag for cited relevant passages.'),
}

def metadata_guide(settings, topic: str = '') -> dict:
    wanted = topic.strip().casefold()
    records = []
    for key, (field, purpose) in ROUTES.items():
        name = str(getattr(settings, field, '') or '')
        if wanted and wanted not in key and wanted not in purpose.casefold() and wanted not in name.casefold():
            continue
        object_name = (settings.resolved_semantic_native_views_table if key == 'semantics'
                       else settings.qualify_metadata_object_name(name)) if name else None
        records.append({'topic': key, 'configured_object': object_name, 'purpose': purpose})
    return {'records': records, 'inventory_verified': False,
            'access': 'Documentation only; use existing caller-authorized services for records. No arbitrary metadata SQL or credentials.',
            'remaining_tables': 'This guide covers documented core stores; do not infer roles for unknown tables.'}

def project_setup_request(prompt: str) -> bool:
    """Conservative gate for an explicit small project action, not a full migration."""
    text = prompt.casefold()
    if not re.search(r'\b(create|add|start|make)\b.{0,35}\bproject\b', text):
        return False
    if re.search(r'\b(explain|how|what|why|could it|plan only|do not create|don.t create)\b', text):
        return False
    # Target-only template shells are setup; actual source/rule generation uses the workflow.
    if re.search(r'\b(delete|archive|publish|deploy|cte|join|transform\w*|automap|auto-map|map|source tables?|implement the plan)\b', text):
        return False
    return not re.search(r'\b(generate|populate|fill)\b.{0,25}\bmappings?\b', text)


def requested_project_id(prompt: str) -> str | None:
    """Read a destination ID from an explicit project reference."""
    pattern = (
        r"\b(?:in|into|within|under|for|to|use)\s+(?:the\s+)?(?:existing\s+)?"
        r"(?:project\s+(?:id\s*[:#]?\s*)?(\d+)\b|"
        r"[^.;\n]{1,120}?\s+project\s*(?:\(\s*)?(\d+)\b(?:\s*\))?)"
    )
    candidates = {next(value for value in pair if value) for pair in re.findall(pattern, prompt, re.I)}
    return next(iter(candidates)) if len(candidates) == 1 else None


def explicit_new_project_request(prompt: str) -> bool:
    return bool(re.search(
        r"\b(?:create|start|make|set up)\s+(?:(?:a|another)\s+)?new\s+"
        r"(?:(?:isolated|test|qa|workbench|migration|sandbox|separate)\s+){0,2}project\b", prompt, re.I,
    )) and not bool(re.search(r"\b(?:do not|don.t|never)\s+(?:create|start|make|set up)\b", prompt, re.I))


def selected_mapping_name(prompt: str) -> str | None:
    """Recognize an imperative setup-only request with an explicit mapping name."""
    text = prompt.strip()
    match = re.match(
        r"""(?:please\s+)?(?:create|set up|start)\s+(?:a\s+)?(?:new\s+)?"""
        r"""mapping\s+(?:called|named)\s+["']?([^"'.\n]+?)["']?"""
        r"""(?=\s+(?:in|under|within|with|using|for)\b|[.!]|$)""",
        text, re.I,
    )
    if not match or not re.search(r"\b(?:only|just|setup)\b|\b(?:leave|save)\b.{0,40}\bedit\b", text, re.I):
        return None
    if re.search(r"\b(?:auto[- ]?map|publish|research|plan|(?:add|build|create|generate)\s+(?:joins?|ctes?|rules?))\b", text, re.I):
        return None
    return match[1].strip()[:255] or None


def explicit_firm_value_copy(prompt: str) -> tuple[str, list[str] | None, bool | None] | None:
    """Recognize an explicit project-to-project copy with a collision policy."""
    match = re.match(
        r"(?:please\s+)?(?:copy|import)\s+(all\s+)?(?:the\s+)?(?:firm|project)\s+values\s*"
        r"(?P<names>.*?)\bfrom\s+(?:the\s+)?(?:[^.;\n]{0,100}?\s+)?"
        r"project\s+(?:id\s*[:#]?\s*)?(?P<source>\d+)\b",
        prompt.strip(), re.I,
    )
    keep = re.search(r"\b(?:keep|preserve)\b.{0,24}\b(?:existing|original)\b", prompt, re.I)
    replace = re.search(r"\b(?:overwrite|replace)\b.{0,24}\b(?:existing|original|differing)\b", prompt, re.I)
    if not match or (keep and replace):
        return None
    names = [name.strip().strip("'\"") for name in re.split(r",|\band\b", match["names"], flags=re.I) if name.strip()]
    if not match[1] and (not names or any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name) for name in names)):
        return None
    return match["source"], None if match[1] else names, True if replace else False if keep else None


def requested_project_name(prompt: str) -> str | None:
    """Extract unambiguous destination phrases before catalog research."""
    match = re.search(
        r"""\b(?:in|into|within|under|use)\s+(?:the\s+)?(?:project\s+["']([^"']+)["']|"""
        r"""["']([^"']+)["']\s+project\b)|"""
        r"""\b(?:in|into|within|under|use)\s+the\s+([A-Za-z][A-Za-z0-9 _-]{0,80}?)\s+project\b""",
        prompt, re.I,
    )
    return next((group.strip() for group in match.groups() if group), None) if match else None


def exclusive_source_scope(context: dict) -> set[str]:
    """Honor an explicit request to limit the design to selected sources."""
    from app.agent_tools.contract_reader import normalize_fqn

    if not re.search(
        r"\b(?:use|include|select)\s+only\s+(?:the\s+)?"
        r"(?:(?:one|two|three|four|five|six|seven|eight|\d+)\s+)?"
        r"(?:currently\s+)?selected\s+source(?:\s+tables?)?\b",
        str(context.get("prompt") or ""), re.I,
    ):
        return set()
    return {normalize_fqn(value) for value in context.get("authorized_source_scope") or [] if value}


def latest_note_plan_issues(prompt: str, source: dict) -> list[str]:
    """Require a latest-note design when the user made it an explicit deliverable."""
    derived = source.get("derived_sources") or []
    note_sql = [
        str(cte.get("definition_sql") or cte.get("sql_text") or cte.get("sql") or "")
        for cte in derived
    ]
    selected = [sql for sql in note_sql if re.search(r"\bNOTE\b|\bNOTE_ID\b", sql, re.I)
                and re.search(r"\b(?:ROW_NUMBER|MAX_BY)\s*\(", sql, re.I)]
    issues = []
    if not selected:
        issues.append("Define a derived source that chooses the latest note per driving key.")
    if re.search(r"\b(?:tie[- ]break|greatest note id|highest note id)", prompt, re.I) and not any(
        re.search(r"\bNOTE_ID\b", sql, re.I) and re.search(r"\bORDER\s+BY\b", sql, re.I)
        for sql in selected
    ):
        issues.append("Order tied note timestamps by the requested note identifier.")
    preserve = re.search(r"\b(?:no[- ]note|without (?:a )?note|no note|keep (?:all )?driving rows)\b", prompt, re.I)
    # Check explicitly named note relationships. A raw INNER join can discard driving rows.
    if preserve and any(
        str(join.get("join_type", "")).upper().startswith("INNER")
        and re.search(r"\bNOTE\b|\blatest_note\b", str([join.get("left_table"), join.get("right_table")]), re.I)
        for join in source.get("relationships", [])
    ):
        issues.append("Use a LEFT join so rows without a note remain in the mapping.")
    return issues


def explicit_project_setup_name(prompt: str) -> str | None:
    if not project_setup_request(prompt):
        return None
    match = re.match(
        r"""\s*(?:please\s+)?(?:create|add|start|make)\s+(?:a\s+)?(?:new\s+)?project\s+"""
        r"""(?:named|called)\s+(?:"([^"\n]+)"|'([^'\n]+)'|([^.!?;\n]+))""", prompt, re.I,
    )
    if not match:
        return None
    name = next(group.strip() for group in match.groups() if group)
    if not name or len(name) > 255 or re.search(r"\b(?:with|and|using|from|based on)\b", name, re.I):
        return None
    return name
