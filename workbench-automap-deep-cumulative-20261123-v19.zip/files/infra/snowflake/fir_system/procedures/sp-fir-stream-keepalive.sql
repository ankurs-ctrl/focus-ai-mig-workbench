-- Keeps every FIR stream inside its retention window and records pipeline health.
-- Runs from TSK_FIR_STREAM_KEEPALIVE (every 6 hours) and once after bootstrap.
--   * SYSTEM$STREAM_HAS_DATA on an empty stream prevents it from going stale.
--   * A ready-signal stream near STALE_AFTER is drained: its source table is the
--     durable work inventory, so only the trigger offset is advanced.
--   * A data-carrying stream near STALE_AFTER runs TSK_FIR_CAPTURE, whose
--     canonical collector consumes those changes; nothing is discarded here.
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.TBL_FIR_STREAM_HEALTH_LOG (
    CHECKED_AT TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP(),
    HEALTHY BOOLEAN,
    REPORT VARIANT
)
DATA_RETENTION_TIME_IN_DAYS = 1
COMMENT = 'Append-only FIR stream/task health snapshots written by SP_FIR_STREAM_KEEPALIVE.';

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_STREAM_KEEPALIVE(
    "HORIZON_DAYS" INTEGER DEFAULT 4
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'keepalive'
EXECUTE AS OWNER
AS
$$
import json
from datetime import datetime, timedelta, timezone

NS = "__STTM_METADATA_NAMESPACE__"

# Must match scripts/fir_stream_recovery.CONTRACTS ("durable_signal" entries).
SIGNAL_STREAMS = (
    "STM_FIR_LEARNING_WORK_ITEMS", "STM_FIR_360_CHANGES", "STM_FIR_CONTEXT_EVIDENCE",
    "STM_FIR_RECOMMENDATIONS", "STM_FIR_PRECOMPUTE_SEM_TABLE_VIEWS",
    "STM_FIR_PRECOMPUTE_SEM_COLUMN_VIEWS", "STM_FIR_PRECOMPUTE_SEMANTIC_VERSIONS",
)
# Consumed only by SP_FIR_COLLECT_FEEDBACK through TSK_FIR_CAPTURE.
CAPTURE_STREAMS = (
    "STM_FIR_WORKBENCH_FEEDBACK", "STM_FIR_WORKBENCH_EVENTS", "STM_FIR_RECOMMENDATION_OUTCOMES",
    "STM_FIR_STTM_ATTRIBUTES", "STM_FIR_DERIVED_SOURCES", "STM_FIR_SEM_TABLE_VIEWS",
    "STM_FIR_CONVERSATION_TURNS", "STM_FIR_STTM_VERSIONS", "STM_FIR_CLIENT_SQL_ASSETS",
)


def _rows(session, statement):
    return [row.as_dict() if hasattr(row, "as_dict") else dict(row) for row in session.sql(statement).collect()]


def _aware(value):
    if not isinstance(value, datetime):
        return None
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def keepalive(session, horizon_days=4):
    horizon = max(1, min(int(horizon_days or 4), 13))
    cutoff = datetime.now(timezone.utc) + timedelta(days=horizon)
    report = {"horizon_days": horizon, "stale": [], "missing": [], "drained": [],
              "refreshed": [], "near_stale": [], "capture_triggered": False,
              "suspended_tasks": [], "errors": []}
    streams = {str(row.get("name")): row for row in _rows(session, f"SHOW STREAMS LIKE 'STM_FIR%' IN SCHEMA {NS}")}
    capture_needed = False
    for name in (*SIGNAL_STREAMS, *CAPTURE_STREAMS):
        row = streams.get(name)
        if row is None:
            report["missing"].append(name)
            continue
        if str(row.get("stale")).lower() == "true":
            report["stale"].append(name)
            continue
        try:
            has_data = session.sql(f"SELECT SYSTEM$STREAM_HAS_DATA('{NS}.{name}') AS HAS_DATA").collect()[0]["HAS_DATA"]
            if not has_data:
                report["refreshed"].append(name)
        except Exception as exc:
            report["errors"].append(f"{name}: {type(exc).__name__}: {exc}"[:300])
            continue
        stale_after = _aware(row.get("stale_after"))
        if not has_data or stale_after is None or stale_after > cutoff:
            continue
        report["near_stale"].append(name)
        if name in SIGNAL_STREAMS:
            try:
                session.sql(
                    f"INSERT INTO {NS}.TBL_FIR_STREAM_DRAIN "
                    f"SELECT '{name}', CURRENT_TIMESTAMP() FROM {NS}.{name} WHERE 0 = 1"
                ).collect()
                report["drained"].append(name)
            except Exception as exc:
                report["errors"].append(f"{name}: {type(exc).__name__}: {exc}"[:300])
        else:
            capture_needed = True
    if capture_needed:
        try:
            session.sql(f"EXECUTE TASK {NS}.TSK_FIR_CAPTURE").collect()
            report["capture_triggered"] = True
        except Exception as exc:
            report["errors"].append(f"TSK_FIR_CAPTURE: {type(exc).__name__}: {exc}"[:300])
    try:
        report["suspended_tasks"] = sorted(
            str(row.get("name")) for row in _rows(session, f"SHOW TASKS LIKE 'TSK_FIR%' IN SCHEMA {NS}")
            if str(row.get("state")).lower() != "started")
    except Exception as exc:
        report["errors"].append(f"SHOW TASKS: {type(exc).__name__}: {exc}"[:300])
    healthy = not (report["stale"] or report["missing"] or report["errors"] or report["suspended_tasks"])
    report["healthy"] = healthy
    session.sql(
        f"INSERT INTO {NS}.TBL_FIR_STREAM_HEALTH_LOG (HEALTHY, REPORT) SELECT ?, PARSE_JSON(?)",
        params=[healthy, json.dumps(report)],
    ).collect()
    return report
$$;
