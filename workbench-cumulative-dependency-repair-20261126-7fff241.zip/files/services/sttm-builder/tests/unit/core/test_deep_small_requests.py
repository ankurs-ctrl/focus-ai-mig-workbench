from types import SimpleNamespace
from threading import RLock
import pytest
from app.agent_tools.workbench_knowledge import metadata_guide, project_setup_request
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.agent_tools.commands import AgentCommandExecutor
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.schema.project import ProjectRecord


def handler():
    h=object.__new__(WorkbenchWorkflowHandlers)
    h._domain_lock=RLock()
    h._commands=AgentCommandExecutor(InMemoryAgentRunRepository())
    h.calls=[]
    def create(request, **kwargs):
        h.calls.append((request,kwargs))
        return ProjectRecord(project_id='17',project_name=request.project_name,status='ACTIVE')
    def template(request, **kwargs):
        h.calls.append((request,kwargs))
        return SimpleNamespace(model_dump=lambda **kw:{'project':{'project_id':'18','project_name':request.project_name},'mappings':[{'sttm_id':'20'}]})
    h._projects=SimpleNamespace(create_project=create,create_project_from_template=template)
    return h


def state(prompt='Create a new project called Small Test'):
    return {'run_id':'small','prompt':prompt,'app_user_id':'user','effective_role':'ROLE','run_mode':'auto'}


def test_project_setup_is_short_idempotent_and_uses_current_actor():
    h=handler()
    for _ in range(2):
        result=h.create_project_setup(state(), 'Small Test')
        assert result.status=='succeeded' and result.data['project']['project_id']=='17'
    assert len(h.calls)==1
    assert h.calls[0][1]['user_id']=='user'


def test_template_setup_uses_existing_automatic_target_shell_bootstrap():
    h=handler()
    result=h.create_project_setup(state('Create project Small Test with automatic target mappings'),
        'Small Test','CRM_MIGRATION','DYNAMICS','DB','TARGET')
    assert result.status=='succeeded'
    request=h.calls[0][0]
    assert request.bootstrap_mode=='AUTO' and request.target_schema=='TARGET'
    assert request.idempotency_key=='deep-project-setup:small'
    assert 'target-only' in result.summary


@pytest.mark.parametrize('prompt',[
    'Explain how to create a project Small Test', 'Create project Small Test and generate CTE joins',
    'Do not create project Small Test', 'Create project Small Test and automap the sources',
    'What happens when I create project Small Test?',
])
def test_questions_or_complex_tasks_cannot_use_project_setup(prompt):
    h=handler()
    assert not project_setup_request(prompt)
    assert h.create_project_setup(state(prompt),'Small Test').status=='denied'
    assert not h.calls


def test_plan_only_and_invented_names_create_nothing():
    h=handler();s=state();s['effective_run_mode']='plan'
    assert h.create_project_setup(s,'Small Test').status=='denied'
    assert h.create_project_setup(state(),'Invented Name').status=='denied'
    assert not h.calls


def test_storage_guide_is_configuration_aware_and_not_live_inventory():
    settings=SimpleNamespace(snowflake_sttm_attributes_table='CUSTOM_ATTRIBUTES',
        snowflake_semantic_native_views_table='SEM_NATIVE_VIEWS',
        resolved_semantic_native_views_table='PIPELINE.PUBLIC.SEM_NATIVE_VIEWS',
        qualify_metadata_object_name=lambda n:'META.PUBLIC.'+n)
    guide=metadata_guide(settings,'mapping_rows')
    assert guide['records'][0]['configured_object']=='META.PUBLIC.CUSTOM_ATTRIBUTES'
    assert 'CONDITION' in guide['records'][0]['purpose']
    assert guide['inventory_verified'] is False
    assert metadata_guide(settings,'semantics')['records'][0]['configured_object']=='PIPELINE.PUBLIC.SEM_NATIVE_VIEWS'
    assert metadata_guide(settings,'unknown')['records']==[]


def test_small_action_receipt_satisfies_workflow_but_cannot_hide_migration_request():
    from app.agent_runtime.deepagents_runtime import _migration_workflow_required
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    def invocation(prompt):
        return RuntimeInvocation(run_id='small',thread_id='small',prompt=prompt,effort=EffortLevel.LIGHT,
            workflow_input={'intent':'NEW_MIGRATION_TASK'})
    registry=SimpleNamespace(_project_setup_result={'status':'succeeded'})
    assert not _migration_workflow_required(invocation('Create project Small Test'),registry)
    assert _migration_workflow_required(invocation('Create project Small Test and automap source tables'),registry)


def test_actual_governed_runtime_executes_small_project_without_migration_planning():
    from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
    from langchain_core.messages import AIMessage
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    class Model(FakeMessagesListChatModel):
        def bind_tools(self, tools, **kwargs): return self
    class ForbiddenGraph:
        def invoke(self, *args, **kwargs): raise AssertionError('Simple setup must not enter migration graph')
    h=handler()
    model=Model(responses=[AIMessage(content='',tool_calls=[{'id':'setup','name':'create_project_setup',
        'args':{'project_name':'Small Test'}}]),AIMessage(content='[FINAL] Created Small Test.')])
    runtime=DeepAgentsRuntime(model=model,migration_graph=ForbiddenGraph(),workbench=h,
        budget=ExecutionBudget(model_limit=6,tool_limit=8))
    result=runtime.invoke(RuntimeInvocation(run_id='small',thread_id='small',prompt=state()['prompt'],
        effort=EffortLevel.LIGHT,workflow_input={'intent':'NEW_MIGRATION_TASK',
            'app_user_id':'user','effective_role':'ROLE','run_mode':'auto'}))
    assert len(h.calls)==1
    assert result.status=='COMPLETED'
    assert result.workflow_state['project_id']=='17'
    assert not result.interrupt


def test_saved_mapping_read_checks_project_membership_and_preserves_complete_sql():
    from app.agent_runs.models import ToolResult
    h=handler();reads=[]
    h._tool=lambda operation:None
    h._projects.get_project=lambda project,**kwargs:SimpleNamespace(project_id=project)
    h._projects.get_sttm_record=lambda sttm,**kw:SimpleNamespace(project_id='18' if sttm=='20' else 'other',status='DRAFT',target_table='DB.T.OUT',last_snapshot_id='s')
    def detail(sttm, operation):
        reads.append(sttm)
        return SimpleNamespace(sttm=SimpleNamespace(status='DRAFT',target_table='DB.T.OUT'),
            latest_snapshot={'mapping_sql':'SELECT CASE WHEN A = 1 THEN B ELSE NULL END FROM DB.S.T'})
    h._projects._latest_snapshot=lambda sttm,**kw:detail(sttm,'read').latest_snapshot
    assert h.read_mapping_definition('18','foreign').status=='denied' and not reads
    result=h.read_mapping_definition('18','20')
    assert result.status=='succeeded' and 'CASE WHEN' in result.data['mapping_sql']
    assert result.data['status']=='DRAFT' and result.evidence_refs==['saved_mapping:20']
    h._projects._latest_snapshot=lambda *args,**kw:{'mapping_sql':'字'*20000}
    result=h.read_mapping_definition('18','20')
    assert result.data['sql_deferred'] and result.data['mapping_sql'] is None


def test_only_receipted_short_actions_and_read_only_qa_use_exit_checkpointing():
    from app.agent_runtime.deepagents_runtime import _supervisor_durability
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    def request(prompt,mode='auto'):
        return RuntimeInvocation(run_id='r',thread_id='r',prompt=prompt,effort=EffortLevel.LIGHT,workflow_input={'run_mode':mode})
    assert _supervisor_durability(request('Create project Small Test'))=='exit'
    assert _supervisor_durability(request('Create project Small Test','plan')) is None
    assert _supervisor_durability(request('Create project Small Test and generate CTE joins')) is None
