"""Native isolated publication/refresh checks using existing test permissions.

No roles or grants change. OAuth-provider responses are synthetic; there are no
user sessions, model requests, client mappings or business-data writes involved.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime, timedelta, UTC
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from uuid import uuid4
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'services/sttm-builder'),str(ROOT)]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    import snowflake.connector
    from app.core.config import Settings
    from app.core.mapping_sql import MappingSqlService
    from app.auth import custom_oauth as oauth
    c=dotenv_values(args.credential_env)
    assert c['SNOWFLAKE_ACCOUNT'].upper()=='A0581299278961-BBINSIGHT_PARTNER'
    db='FFP_HDP_CRM_MIG_DB_DEV';schema='SCH_PUBLISH_OAUTH_TEST_'+uuid4().hex[:12].upper();ns=db+'.'+schema
    cfg=dict(account=c['SNOWFLAKE_ACCOUNT'],user=c['SNOWFLAKE_USER'],authenticator='PROGRAMMATIC_ACCESS_TOKEN',
        token=c['SNOWFLAKE_PASSWORD'],role=c['SNOWFLAKE_ROLE'],warehouse='FFP_HDP_CRM_MIG_WH_DEV',database=db,
        schema='SCH_STTM_METADATA',login_timeout=20,network_timeout=60)
    s=Session.builder.configs(cfg).create();created=False
    report={'status':'started','data':'sanitized_three_row_fixture','oauth_provider':'synthetic_rotation_only',
        'client_changes':False,'model_posts':0,'roles_or_grants_changed':False,
        'denied_target_dml':'Covered offline; no role or grant changes are authorized for native testing.'}
    try:
        identity=s.sql('SELECT CURRENT_ORGANIZATION_NAME() O,CURRENT_ACCOUNT_NAME() A,CURRENT_USER() U,CURRENT_ROLE() R').collect()[0]
        assert (identity['O'],identity['A'])==('A0581299278961','BBINSIGHT_PARTNER')
        s.sql('CREATE SCHEMA '+ns).collect();created=True
        s.sql(f'CREATE TABLE {ns}.SOURCE (ID NUMBER, NAME VARCHAR)').collect()
        s.sql(f"INSERT INTO {ns}.SOURCE VALUES (1,'Alpha'),(2,'Beta'),(3,'Gamma')").collect()
        s.sql(f'CREATE TABLE {ns}.TARGET (NAME VARCHAR)').collect()
        s.sql(f'CREATE TABLE {ns}.PUBLISHED_DEFINITIONS (MAPPING_ID VARCHAR, SQL_TEXT VARCHAR)').collect()
        source={'database':db,'schema':schema,'table':'SOURCE'};target={'database':db,'schema':schema,'table':'TARGET'}
        insert=f'INSERT INTO {ns}.TARGET (NAME) SELECT src.NAME AS NAME FROM {ns}.SOURCE src'
        snapshot={'target_table':target,'source_tables':[source],
            'relation_graph':{'nodes':[{'relation_id':'source','alias':'src','kind':'PHYSICAL_TABLE','table':source,
                'output_columns':[{'name':'NAME','data_type':'VARCHAR'}]}]},'driving_relation_id':'source',
            'mapping_rows':[{'id':'name','target_column':'NAME','target_type':'VARCHAR','source_columns':['src.NAME'],
                'mapping_mode':'source','rule':'Direct','status':'MAPPED'}], 'mapping_sql':insert}
        with s.query_history(include_error=True) as queries:
            validated=MappingSqlService(session=s,analyst_client=None).validate_publication(snapshot,project_id='isolated',project_attributes=[])
        explained=[q for q in queries.queries if q.sql_text.lstrip().upper().startswith('EXPLAIN')]
        assert explained and all('INSERT INTO' not in q.sql_text.upper() for q in explained)
        assert validated['execution_permissions_validated'] is False
        s.sql(f'INSERT INTO {ns}.PUBLISHED_DEFINITIONS SELECT ?,?',params=['isolated',validated['sql']]).collect()
        report['metadata_definitions']=s.sql(f'SELECT COUNT(*) C FROM {ns}.PUBLISHED_DEFINITIONS').collect()[0]['C']
        report['target_rows']=s.sql(f'SELECT COUNT(*) C FROM {ns}.TARGET').collect()[0]['C']
        assert report['metadata_definitions']==1 and report['target_rows']==0
        report['publication_explain_query_ids']=[q.query_id for q in explained]
        report['publication_validation_kind']=validated['validation_kind']
        s.sql(f'''CREATE TABLE {ns}.OAUTH_SESSIONS (SESSION_ID VARCHAR, SNOWFLAKE_USER VARCHAR, SNOWFLAKE_ROLE VARCHAR,
            EMAIL VARCHAR, DISPLAY_NAME VARCHAR, APP_USER_ID VARCHAR, ACCESS_TOKEN_ENCRYPTED VARCHAR,
            REFRESH_TOKEN_ENCRYPTED VARCHAR, ACCESS_TOKEN_EXPIRES_AT TIMESTAMP_TZ, REFRESH_TOKEN_EXPIRES_AT TIMESTAMP_TZ,
            CREATED_AT TIMESTAMP_TZ,LAST_ACCESSED_AT TIMESTAMP_TZ,LAST_REFRESHED_AT TIMESTAMP_TZ,IS_ACTIVE BOOLEAN)''').collect()
        settings=Settings(_env_file=None,AUTH_MODE='custom_oauth',SNOWFLAKE_DATABASE=db,SNOWFLAKE_SCHEMA=schema,
            SNOWFLAKE_OAUTH_SESSIONS_TABLE=ns+'.OAUTH_SESSIONS',AUTH_SESSION_ENCRYPTION_KEY='isolated-synthetic-fixture-key')
        now=datetime.now(UTC)
        row={'SESSION_ID':'synthetic-session','SNOWFLAKE_USER':identity['U'],'SNOWFLAKE_ROLE':identity['R'],
            'EMAIL':'synthetic@example.test','DISPLAY_NAME':'Synthetic','APP_USER_ID':'1',
            'ACCESS_TOKEN_ENCRYPTED':oauth._encrypt(settings,'synthetic-old-access'),
            'REFRESH_TOKEN_ENCRYPTED':oauth._encrypt(settings,'synthetic-old-refresh'),
            'ACCESS_TOKEN_EXPIRES_AT':now-timedelta(minutes=1),'REFRESH_TOKEN_EXPIRES_AT':now+timedelta(days=1),
            'IS_ACTIVE':True}
        columns=list(row)
        s.sql(f"INSERT INTO {ns}.OAUTH_SESSIONS ({','.join(columns)}) SELECT "+','.join('TO_TIMESTAMP_TZ(?)' if isinstance(row[column],datetime) else '?' for column in columns),
            params=[value.isoformat() if isinstance(value,datetime) else value for value in row.values()]).collect()
        persisted=s.sql(f'SELECT * FROM {ns}.OAUTH_SESSIONS').collect()[0].as_dict()
        assert oauth._session_record(persisted).access_token_expires_at < datetime.now(UTC), 'Synthetic fixture must actually be expired'
        original={name:getattr(oauth,name) for name in ['get_service_connection','resolve_and_upsert','_refresh_tokens']}
        query_ids=[];exchanges=[]
        @contextmanager
        def service_connection(_settings):
            conn=snowflake.connector.connect(**cfg)
            class Connection:
                def cursor(self,*a,**kw):
                    underlying=conn.cursor(*a,**kw)
                    class Cursor:
                        @property
                        def rowcount(self):return underlying.rowcount
                        def execute(self,*a,**kw):
                            result=underlying.execute(*a,**kw);query_ids.append(underlying.sfqid);return result
                        def fetchone(self):return underlying.fetchone()
                        def close(self):underlying.close()
                    return Cursor()
                def commit(self):return conn.commit()
                def rollback(self):return conn.rollback()
            try:yield Connection()
            finally:conn.close()
        def refresh(token,_settings):
            exchanges.append(True);assert token=='synthetic-old-refresh';time.sleep(2)
            return oauth.OAuthTokens(access_token='synthetic-new-access',refresh_token='synthetic-new-refresh',
                access_token_expires_at=datetime.now(UTC)+timedelta(hours=1),refresh_token_expires_at=now+timedelta(days=1))
        oauth.get_service_connection=service_connection
        oauth.resolve_and_upsert=lambda *a,**k:SimpleNamespace(snowflake_user=identity['U'],snowflake_role=identity['R'])
        oauth._refresh_tokens=refresh
        try:
            with ThreadPoolExecutor(max_workers=2) as pool:
                results=list(pool.map(lambda _:oauth._refresh_session_if_needed(oauth._session_record(row),settings),range(2)))
            report.update(refresh_exchanges=len(exchanges),refresh_query_ids=query_ids)
            assert len(exchanges)==1
            assert all(oauth.decrypt_access_token(record,settings)=='synthetic-new-access' for record in results)
        finally:
            for name,value in original.items():setattr(oauth,name,value)
        report.update(status='passed',refresh_connections=2,refresh_exchanges=len(exchanges),refresh_query_ids=query_ids,
            service_identity_note='Mounted SPCS-token factory is covered offline; local native refresh uses existing authorized test-account connections.')
    finally:
        if created:s.sql('DROP SCHEMA '+ns+' CASCADE').collect()
        s.close();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2,default=str))
        print(json.dumps({k:v for k,v in report.items() if not k.endswith('query_ids')},default=str))
    return 0


if __name__=='__main__':raise SystemExit(main())
