'use client';

import { AiaAlert, AiaSnackbar } from '@/components/ui';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';

const AUTO_HIDE_MS = 8000;

export function AutoMapCompletionToast() {
  const { autoMapCompletionNotice: notice, dismissAutoMapCompletionNotice } = useSttmBuilderContext();

  if (!notice) return null;

  return (
    <AiaSnackbar
      key={notice.id}
      open
      // Failures and results needing review stay until dismissed.
      autoHideDuration={notice.severity === 'success' ? AUTO_HIDE_MS : null}
      onClose={(_, reason) => {
        if (reason === 'clickaway') return;
        dismissAutoMapCompletionNotice();
      }}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
    >
      <AiaAlert
        severity={notice.severity}
        variant="filled"
        onClose={dismissAutoMapCompletionNotice}
        sx={{ width: '100%', maxWidth: 420, fontSize: '0.82rem' }}
      >
        {notice.message}
      </AiaAlert>
    </AiaSnackbar>
  );
}
