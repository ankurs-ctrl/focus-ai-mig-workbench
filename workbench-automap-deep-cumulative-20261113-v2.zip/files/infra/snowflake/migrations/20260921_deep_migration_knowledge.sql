-- Additive projection over existing FIR storage. Render the metadata namespace
-- using the same deployment substitution as existing FIR migrations.
-- No historical record is promoted to approved by this migration.
CREATE OR REPLACE VIEW __STTM_METADATA_NAMESPACE__.VW_DEEP_LEARNING_SEARCH AS
SELECT LEARNING_ID, LEARNING_TYPE, ATTRIBUTES:search_projection:text::STRING AS SEARCH_TEXT,
       ATTRIBUTES:scope:tenant_id::STRING AS TENANT_ID,
       ATTRIBUTES:scope:account::STRING AS ACCOUNT_ID,
       ATTRIBUTES:scope:authorization_fingerprint::STRING AS AUTHORIZATION_FINGERPRINT,
       ATTRIBUTES:scope:project_id::STRING AS PROJECT_ID,
       ATTRIBUTES:approval_status::STRING AS APPROVAL_STATUS,
       ATTRIBUTES:evidence_ids AS EVIDENCE_IDS,
       ATTRIBUTES:semantic_version::STRING AS SEMANTIC_VERSION,
       ATTRIBUTES:contract_version::STRING AS CONTRACT_VERSION,
       ATTRIBUTES:revision::INT AS REVISION,
       CREATED_AT AS UPDATED_AT
FROM __STTM_METADATA_NAMESPACE__.TBL_AGENT_LEARNINGS
WHERE AGENT_TYPE = 'DEEP_MIGRATION'
  AND ATTRIBUTES:scope:tenant_id IS NOT NULL
  AND ATTRIBUTES:scope:authorization_fingerprint IS NOT NULL
  AND ATTRIBUTES:approval_status::STRING = 'APPROVED_BUSINESS_RULE'
  AND COALESCE(ATTRIBUTES:search_projection:text::STRING, '') <> ''
  AND NOT COALESCE(ATTRIBUTES:search_projection:excluded_sensitive::BOOLEAN,FALSE)
  AND COALESCE(ATTRIBUTES:superseded_by::STRING, '') = '';
-- Cortex automatically refreshes this projection from the existing FIR table.
-- Deploy the configurable deep-learning-search.sql.tmpl against a chosen service.
