$ErrorActionPreference = "Stop"

$RootDir = Split-Path -Parent $PSScriptRoot
$ServiceDir = Join-Path $RootDir "services\sttm-builder"

$PythonExe = if ($env:DEEP_WORKER_PYTHON) { $env:DEEP_WORKER_PYTHON } else { Join-Path $ServiceDir ".venv\Scripts\python.exe" }

if (-not (Test-Path $PythonExe)) {
    Write-Error "Set DEEP_WORKER_PYTHON to an environment with the locked backend dependencies."
    exit 1
}

Push-Location $ServiceDir
try {
    Write-Host "Starting Deep worker from $RootDir"
    # Relax ErrorActionPreference for the worker invocation only: when this
    # script runs inside a background Start-Job (as start_sttm_backend_local.ps1
    # does), PowerShell treats ANY stderr line from a native process (even
    # benign INFO/warning logs from Python logging) as a terminating error
    # when ErrorActionPreference is "Stop", which would otherwise kill the job.
    $ErrorActionPreference = "Continue"
    & $PythonExe -m app.agent_worker_main
}
finally {
    Pop-Location
}
