# Deep Agent verification

Status: implementation and local verification complete. Native controlled acceptance passed. No client deployment verification is claimed.

## Integration scope

Source: ZIP feature commit `022191db6f9c79e680be20c353341098e61344ef`.
Base: CodeCommit develop `e0c0af26305cc163c7b4fde59f520db2c88c42d8`.
The feature was imported selectively. Older ZIP authentication, cache, Auto-map,
standard mapping-assistant and shared parser behavior were not copied wholesale.
Application configuration logic and dependencies were merged; credentials and
client deployment values were excluded. Standard mapping-assistant UI remains
unchanged. Dedicated `/ai-agent` uses develop's page and composer.

## Confirmed defects corrected

1. Composer mode, effort and model were not sent. They now reach run creation;
   attachments, cancellation, project-scoped submission and backend capabilities
   are connected. One conversation state owns the dedicated flow. Browse-view
   submission waits for the matching project sender. Durable rename/delete/history
   preserve project associations and ignore superseded identity-cache responses.
2. Shared merge compatibility: preserved template ownership display names,
   publication checks, Auto-map retrieval defaults, session handling, cache behavior,
   parser classifications and human-authored mapping protections. Deep-specific
   canonical learning scope and CTE lineage are opt-in to that flow.
3. A rejected transformation could fall back to a direct mapping. Invalid rules
   now remain unresolved; ambiguous SQL is retained for bounded repair.
4. Repeated rejected plan corrections could loop until quota exhaustion. Three
   same-code rejected corrections now pause without unapproved business writes.
   Complete SQL-step, decision, source and mapping-candidate shapes are exposed to
   the model. Explicit singular source references are canonicalized without
   inventing or replacing source references.
5. Default Cortex Chat Completions output truncated full plans at 4096 tokens.
   The worker explicitly requests a configurable 16384-token allowance. Truncated
   responses are counted and stopped before incomplete actions can execute; they
   are not silently retried. See the linked provider documentation in deployment notes.
6. Verified source evidence incorrectly triggered a source-research nudge during
   plan assembly. That nudge now applies only when no driving source is selected;
   unresolved join checkpoints remain mandatory.
7. Model attempts and token/query accounting were not durable during a phase.
   The attempt is flushed before dispatch; every trace carries a usage snapshot.
   Restart restores monotonic usage, with legacy event-based recovery.
8. Optional knowledge search failure blocked evidence preparation. A Snowflake
   search failure now returns explicit unavailability with zero hits; permission
   errors still propagate. Semantic override storage initializes once per session
   and only records success after all required DDL succeeds.
9. API-only startup could accept work with no worker. Enabled container startup
   supervises API and worker together, terminating owned children on failure.
10. Source/target scope parsing treated a trailing “as the source” label as a
    target and double-counted a target's bare alias and FQN. Explicit target scope
    now controls the single/multiple-target handoff; aliases are deduplicated.
    Tables with the same leaf in distinct schemas remain separate.
11. Handoff revalidated the earlier evidence-only candidate and discarded a
    supervisor's repaired full plan. It now revalidates the repaired plan.
12. A crash after durable node writes but before the next checkpoint left
    `get_state().next` empty. The runtime mistook that for no resumable workflow
    and restarted model reasoning. Recovery now recognizes completed pending
    task results and continues the graph. Tests interrupt before the question,
    after the question, and between node writes and checkpoint persistence.
    Approval and an approved boundary before the project receipt resume without
    a model call or a synthesized answer.
13. Additive migration reapplication failed on the pre-existing event sequence
    column. Corrected nullable ADD plus null backfill reapplies successfully.

## Automated and UI checks

- Final full backend suite: **5682 passed, 32 skipped**, 355.01 seconds. Skips remain skips.
- All 35 frontend regression scripts passed, including actual composer handlers,
  execution options, attachments, cancellation and project-scope handoff.
- TypeScript passed. Production frontend build passed with `next build --webpack`.
  The workspace links dependencies outside the frontend root; plain Turbopack
  build rejects that local link. The build script was not changed to hide this.
- Browser smoke check: existing layout/navigation and Plan/Agent, effort, model
  menu displayed. Removed the imported panel's duplicate welcome message.
- Changed-file scan: no test PAT or `.env` paths in the integration. Runtime lock
  files and local test scripts are excluded from delivery.

The suite covers pre-approval draft denial, stale action/plan revisions, rejection,
project/STTM receipt idempotency, scoped follow-up preservation, cross-mapping
separation, restart/checkpoint fencing, missing/failed evidence, SQL compilation,
preview receipts and prevention of false completion. These are automated checks;
separate native evidence below distinguishes actual account execution.

## Native account evidence

Account: this system's approved test account; warehouse `COMPUTE_WH`.
Scratch namespace: `BBI_STTM_TEST_DB.DEEP_VERIFY_20261112`.
Source: `BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION`.
Target: scratch `VERIFY_IDENTITY_TARGET` (33 columns).
Existing semantics: `FOCUS_DB_2.STTM_MCP`; no semantic regeneration.
Authentication: local PAT-backed Snowpark session, then native session-token
Cortex access. This does not test client SPCS delegated OAuth.

- Real Cortex model preflight passed using `claude-sonnet-4-5`.
- Both full contracts were read and all 33 columns verified. No target sampling.
- Native reapplication of the control-plane migration: 37 statements succeeded.
- Before approval: direct SQL counted 0 projects, 0 STTMs and 0 target data rows.
- Pre-fix run `run_bdf770dc0f6342869f4a783baf8c6c82` exposed optional-evidence
  setup and repeated plan-validation failures. It consumed the test quota before
  the loop was stopped. User restored quota. It is CANCELLED with no lease;
  no draft artifact was created. This is a failure baseline, not a passed run.
- Full-scope run `run_57980581c51a4a5b9f99e9ce6a53d71e` exposed output truncation
  and candidate-field mismatch. Durable restart restored 11 verified research
  items. Corrections paused safely after three repeated coverage rejections.
  A real stored approval plan now covers 33/33 columns with 33 exact same-name
  direct candidates and no evidence gaps. Plan hash
  `9783d1af81100a2c7b3517d47c7e226603de8e9d009ef220ba4ae598f0d32689`.
  Before approval, run-owned project/STTM counts and target rows were all zero.
  Stale digest returned 409; exact approval and its duplicate returned 200.
  After approval the governed executor resumed directly with no supervisor
  research. Draft creation exposed missing baseline FIR columns in the freshly
  created test schema; existing additive baseline DDL was reconciled (zero errors
  in the final pass), then the same approved run completed.
  Saved project **1**, STTM **201**, **33/33 MAPPED (100%)** with every exact direct
  source independently asserted. Native saved SQL EXPLAIN query
  `01c85bd3-0109-c332-0004-c62a0bc7895a`; bounded preview query
  `01c85bd3-0109-c332-0004-c62a0bc7895e` returned 3 rows/33 columns.
  No target rows or published versions. Draft receipts and hashes are in
  NATIVE_EVIDENCE.json. All 32 supervisor calls occurred before approval while
  diagnosing pre-fix defects; after approval: **zero supervisor model calls**,
  zero repeated discovery tools. Two batched catalog-signature confirmations
  checked freshness of the stored source contract; they did not re-read the
  contract. Working/finalization compilation phases emit two Auto-map started
  events but classified the 33 targets once and reused those durable rows.
- Controlled run `run_798e9b76f29a40b7ba1d19f05aa04c87`: 10 target columns, 9-column
  customer contract and 2-column status contract verified. Actual data confirmed
  the requested `STATUS_ID = ID` join at 90% confidence. Research unnecessarily
  read 67 tables/974 columns and verified 48 candidates in 21 queries before
  choosing that join. It reached draft creation and encountered the same missing
  test-schema baseline column. It has not passed final mapping-quality checks.

## Remaining improvements ranked by impact

- Compact plan submission: reference verified per-column candidate IDs instead of
  repeatedly generating a full JSON plan. Traces showed 33 legitimate candidates
  rejected solely for singular reference field names, and repeated 4096-token
  outputs before the adapter fix. Normalization/schema fixes are included; the
  broader protocol redesign is not.
- Bulk delta-checkpoint reconstruction: the LangGraph saver follows ancestor
  checkpoints and message writes on restart. Long research histories incur many
  Snowflake reads before the next model call. Preserve parent-chain/fence semantics
  if optimizing this; do not prune to only the latest checkpoint.
- Account-specific semantic/knowledge coverage: unavailable search and absent
  applicable FIR evidence must remain visible as missing evidence, not fabricated
  supporting claims. A system-specific account capability check should precede
  expensive runs.

See DEPLOYMENT.md for runtime prerequisites. UAT is outside this change.


## Additional requested workflow upgrades

- Plan mode retains the exact approval boundary and exposes the full ordered
  research/plan in the existing right panel: source rationale, target scope,
  per-column sources, proposed SQL/Firm Values, confidence/reasoning, joins,
  CTE SQL and execution steps. Trace replay restores the structured plan.
- Agent mode no longer adds an optional “switch to Plan mode” question solely
  because a migration is complex. The selected mode is respected; genuine
  missing source/value/rule evidence is never invented.
- Dedicated-page progress uses one activity strip with real queued/started/tool
  events instead of appending narration bubbles. Complete/failing SQL receipts
  and diagnostics remain available in the result panel.
- Final delivery describes saved drafts and mapped counts without routine
  “needs review” headings, acceptance queues, or “what next” questions. Generated
  SQL/results hydrate from both older and new transcript formats. Failed SQL
  checks and missing results retain their factual state.
- A verified join checkpoint used to skip the rest of the source design in
  Agent mode. It now returns to complete the requested CTE, filter, values and
  transformations with the already verified join. A test refuses any business
  draft write at this incomplete-design handoff.
- Connected selected source graphs are inspected before expanding the schema.
  For the controlled test this reduced join verification from **48 candidates /
  21 queries / 67 table contracts** to **1 candidate / 1 query / 2 selected
  source contracts**. Disconnected graphs retain bounded bridge discovery.
- Valid low-confidence candidates remain saved in the draft; confidence alone
  does not require acceptance before a draft can exist. Missing columns, unsafe
  rules and unheld Firm Values stay explicit gaps, rather than executable SQL.


## Final contract corrections

- Model fields `used_as_driving_source` and `use_as_driving_source` are normalized to the canonical driving-CTE flag. Canonical false remains authoritative. The selected CTE drives the reopened mapping, not an unused WITH definition over a physical-table SELECT.
- Identical visible CTEs are reused by matching name, canonical SQL and authorized sources; their definitions and human descriptions are not overwritten. New definitions record project/STTM ownership. Reused CTE IDs update the driving relation correctly.
- Specialist source resolution accepts only output columns of persisted derived sources present in the compiler relation graph. Proposed or unknown CTE columns remain unresolved. Valid derived-column transformations reach the transformation specialist instead of losing their source contract.
- A complete verified candidate is saved even when computed confidence is zero. Invalid dependencies and SQL still prevent execution. CTE join counts come from the canonical relation graph, not only the physical-table relationship list.
- Compile retries retain already generated valid expressions and rerun the compiler/preview against current contracts; unfinished targets remain eligible for correction. Regression coverage prevents another transformation call solely because a sibling target was unresolved.
- Draft external identities include run/project/mapping/target. Retries reuse the same owned mapping key; distinct mappings to one target remain separate. Human mappings are excluded from reuse.
- Explicit draft provenance is captured through the durable post-save outbox even when the learning gate is closed. The projection stores specialist artifacts and returns without FIR feedback/approved learning; ordinary draft-only edits still enqueue no job.
- An explicit single-mapping name is preserved through the typed plan and draft manifest.
- The dedicated page's technical panel contains expandable diagnostics and a link to the existing mapping sheet. It does not introduce an acceptance queue or a duplicate generated-mappings tab. Plan approval controls remain in Plan mode.

## Verification matrix and limits

| Scenario | Evidence |
| --- | --- |
| New project and full mapping | Native project 1 / STTM 201: 33/33 direct columns saved and independently checked. |
| Controlled transformations, join, CTE, Firm Value | Final native run tracked separately below; earlier 4/10 and 7/10 runs are failure baselines. |
| Plan then approval | Native zero business drafts before exact approval; stale digest 409, exact and duplicate approval 200; zero supervisor research calls afterward. |
| Edit/reject boundaries | Automated real workflow/checkpoint tests reject superseded approvals and prevent business writes. Separate native plan-edit/reject scenario not executed. |
| Follow-up and human definitions | Automated column-scope and lineage tests preserve unrelated/human definitions; native distinct-draft isolation checked separately. |
| Multiple mappings | Automated dependency/target-scope tests; native distinct drafts/projects. A ten-target client template is not exercised in this account. |
| Restart/reconnect/retry | Native restart of the 33-column run restored research and resumed saved artifacts; automated lost-ack/checkpoint/fencing tests cover both approval boundaries. |
| Missing evidence/failed tools | Native absent optional FIR/search capabilities reported unavailable; automated invalid/missing source/value/SQL tests preserve unresolved targets. |
| UI controls/history | Frontend handler tests, TypeScript/build and browser control smoke check. Full client SPCS OAuth/history e2e requires the client deployment. |

No mapping was published. Native SQL verification executes bounded SELECT and EXPLAIN only. Client grants, delegated OAuth, template resources and account-specific semantic/FIR coverage remain client-environment checks; no client deployment verification is claimed.


## Final native acceptance

Run `run_70ee2ee454c447d19e56ea90eea000c2`, project **101**, STTM **401**: **10/10 MAPPED**. Independent EXPLAIN `01c85c47-0109-cd3a-0004-c62a0bc9b756` and bounded SELECT `01c85c47-0109-cd34-0004-c62a0bc9f716` confirmed exactly two active customers, correct full names, lowercased emails, status labels, numeric amounts, string keys and `VERIFY_FIRM`. The saved CTE drives the reopened mapping. Earlier STTMs 201 and 301 remained unchanged; target tables remain empty and no versions were published.

Specialist artifact `artifact_6e4c24e4cdea419fb84c` persists six source decisions and three transformation decisions. Native provenance-only autosave/outbox processing retained mapping definitions and produced zero FIR feedback events; existing autosave regenerated database attribute row IDs. Artifact reuse returned the same ID. Operational events also retain provider trace IDs and complete specialist outputs.

The run retains internal NEEDS_REVIEW because this synthetic target has no declared target-key metadata. This does not hold any mapping: all ten are saved and executable SQL compiled/previewed successfully. Key reconciliation remains unavailable rather than fabricated. The UI reports draft counts and concrete missing facts without a separate acceptance queue.

The final native attempt included two plan-schema corrections and development restarts. Those timings are diagnostic, not a clean performance benchmark. Its first evidence call omitted sources, then the supervisor corrected it; no unrelated catalog expansion followed. Restart restored ten research items. Catalog signature checks on resume are freshness checks. A compile retry before the final reuse fix repeated the three transformation rules; the included regression now preserves completed valid expressions while correcting unfinished targets. Detailed counters, timing, tokens, cache hits, retry events, artifact IDs and hashes are in NATIVE_EVIDENCE.json. Broader compact-plan/checkpoint optimizations remain ranked improvements, not claimed implementations.
