"""Read-only upload identity verification and semantic availability checks."""
from __future__ import annotations

from dataclasses import dataclass, field
import logging
import re
import time
from typing import Any

from sqlglot import exp, parse_one

logger = logging.getLogger(__name__)

# Shared by exact verification, qualification discovery and semantic inspection.
_LOOKUP_BUDGET_SECONDS = 5.0
_MAX_UNIQUE_REFERENCES = 200
_MAX_LOOKUP_CALLS = 8
_LOOKUP_CHUNK_SIZE = 100


@dataclass
class UploadLookupContext:
    """Request-local evidence and admission budget, bound to one caller session."""

    session: Any
    deadline: float = field(default_factory=lambda: time.monotonic() + _LOOKUP_BUDGET_SECONDS)
    calls: int = 0
    catalog: dict[tuple[str, ...], str | None] = field(default_factory=dict)
    attempted: set[tuple[str, ...]] = field(default_factory=set)

    def next_pass(self):
        """Retain positive identity proofs; retry failures only after unread
        references receive priority. A new pass has a new bounded SQL budget."""
        self.catalog = {key: value for key, value in self.catalog.items() if value is None}
        self.calls = 0
        self.deadline = time.monotonic() + _LOOKUP_BUDGET_SECONDS

    def require_session(self, session: Any) -> None:
        if session is not self.session:
            raise ValueError("Upload lookup context belongs to a different caller session")

    def collect(
        self, query: str, params: list[Any], *, timeout_seconds: int = 5,
        reserve_calls: int = 0,
    ) -> tuple[list[Any] | None, str | None]:
        remaining = int(self.deadline - time.monotonic())
        if self.calls >= _MAX_LOOKUP_CALLS or remaining < 1:
            return None, "call_limit" if self.calls >= _MAX_LOOKUP_CALLS else "deadline_exhausted"
        self.calls += 1
        # Exact checks share the remaining time rather than allowing the first
        # object to consume the whole budget. Snowflake's minimum timeout is 1s.
        timeout = min(timeout_seconds, max(1, remaining // (1 + reserve_calls)))
        try:
            return self.session.sql(query, params).collect(
                statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": timeout}
            ), None
        except Exception as exc:
            reason = _failure_reason(exc)
            logger.warning("Upload metadata check unavailable (%s)", reason)
            return None, reason

    def describe(self, parts: tuple[str, ...], *, reserve_calls: int = 0) -> str | None:
        if parts not in self.catalog:
            # Leave capacity for the two independent semantic registries.
            if self.calls >= _MAX_LOOKUP_CALLS - 2:
                return 'call_limit'
            self.attempted.add(parts)
            rows, reason = self.collect(
                "DESCRIBE TABLE IDENTIFIER(?)", [qualified_identifier(parts)],
                reserve_calls=reserve_calls,
            )
            # An empty DESCRIBE is not proof of absence (normally an object has
            # columns or raises an access/absence error).
            self.catalog[parts] = reason if rows is None else None if rows else "lookup_failed"
        return self.catalog[parts]


def identifier_parts(value: str) -> tuple[str, ...]:
    """Snowflake unquoted identifiers fold to upper case; quoted ones do not."""
    try:
        table = parse_one(value, read="snowflake", into=exp.Table)
    except Exception:
        return ()
    if not isinstance(table, exp.Table) or table.args.get("alias"):
        return ()
    if not 1 <= len(table.parts) <= 3 or not all(isinstance(part, exp.Identifier) for part in table.parts):
        return ()
    return tuple(part.name if part.args.get("quoted") else part.name.upper() for part in table.parts)


def qualified_identifier(parts: tuple[str, ...]) -> str:
    return ".".join(
        exp.to_identifier(part, quoted=not bool(re.fullmatch(r"[A-Z_][A-Z0-9_$]*", part)))
        .sql(dialect="snowflake")
        for part in parts
    )


def classify_reference(item: dict[str, Any]) -> str:
    resolution = str(item.get("resolution_status") or "unresolved")
    if resolution != "resolved":
        return resolution
    semantic = str(item.get("semantic_status") or "pending")
    return {
        "active": "semantic_available",
        "pending": "semantic_checking",
        "missing": "semantic_missing",
        "stale": "semantic_stale",
        "lookup_failed": "semantic_lookup_failed",
    }.get(semantic, "semantic_checking")


def _failure_reason(exc: Exception) -> str:
    code = str(getattr(exc, "sql_error_code", "") or getattr(exc, "errno", "")).lstrip("0")
    message = str(exc).lower()
    if message in {"call_limit", "deadline_exhausted", "reference_limit"}:
        return message
    if code == "630" or "timeout" in message or "timed out" in message:
        return "timeout"
    if any(text in message for text in ("not authorized", "insufficient privilege", "permission", "access denied")):
        return "permission_denied"
    return "lookup_failed"


def inspect_upload_references(
    session: Any, settings: Any, references: list[dict[str, Any]], *,
    lookup_context: UploadLookupContext | None = None,
) -> list[dict[str, Any]]:
    """Verify only requested identities, preserving UNKNOWN on incomplete checks.

    The deadline controls admission and each server statement timeout; it cannot
    interrupt connector/network stalls. No detached query uses the caller session.
    Missing registry entries are reported only after both exact lookups succeed.
    """
    context = lookup_context if lookup_context is not None else UploadLookupContext(session)
    context.require_session(session)
    result = [dict(item) for item in references]
    requested = {
        identifier_parts(str(item.get("resolved_fqn") or ""))
        for item in result if item.get("resolution_status") in {"resolved", "lookup_failed"}
    }
    requested = {parts for parts in requested if len(parts) == 3}
    # Resume durable positive proofs and attempts from this processing snapshot.
    prior_semantics = {}
    for item in result:
        parts = identifier_parts(str(item.get('resolved_fqn') or ''))
        if item.get('catalog_status') == 'available':
            context.catalog[parts] = None
        if item.get('catalog_attempted'):
            context.attempted.add(parts)
        if item.get('semantic_status') in {'active','missing','stale'}:
            prior_semantics[parts] = {key: item.get(key) for key in (
                'semantic_status','semantic_table_view_id','semantic_version','semantic_view_name','semantic_registry')}
    # Preserve already verified identities even when later qualification expands
    # the candidate set past the reference cap.
    requested_list = sorted(requested, key=lambda parts: (
        parts in context.catalog and context.catalog[parts] is None,
        parts in context.attempted, parts in prior_semantics, parts,
    ))[:_MAX_UNIQUE_REFERENCES]
    selected = set(requested_list)
    visible: set[tuple[str, ...]] = {parts for parts, reason in context.catalog.items() if reason is None}
    catalog_errors: dict[tuple[str, ...], str] = {}
    semantic_errors: dict[tuple[str, ...], str] = {}
    collect = context.collect
    for index, parts in enumerate(requested_list):
        reason = context.describe(parts, reserve_calls=len(requested_list) - index - 1)
        if reason is None:
            visible.add(parts)
        else:
            catalog_errors[parts] = reason

    semantics: dict[tuple[str, ...], dict[str, Any]] = dict(prior_semantics)
    semantic_requested = [parts for parts in requested_list if parts not in prior_semantics]
    registries = [
        (settings.resolved_semantic_views_table, "VIEW_ID", "GENERATED_AT", "NULL"),
        (settings.resolved_semantic_native_views_table, "NATIVE_VIEW_ID", "CREATED_AT", "TARGET_FQN"),
    ] if requested_list else []
    checked_registries: dict[tuple[str, ...], int] = {}
    for registry, id_column, time_column, view_column in registries:
        for start in range(0, len(semantic_requested), _LOOKUP_CHUNK_SIZE):
            chunk = semantic_requested[start:start + _LOOKUP_CHUNK_SIZE]
            values = ", ".join("(?, ?, ?)" for _ in chunk)
            rows, reason = collect(
                f"""WITH requested(DATABASE_NAME, SCHEMA_NAME, TABLE_NAME) AS (
                    SELECT column1, column2, column3 FROM VALUES {values}
                )
                SELECT s.DATABASE_NAME, s.SCHEMA_NAME, s.TABLE_NAME,
                       s.{id_column} AS ASSET_ID, s.STATUS,
                       s.{time_column} AS ASSET_VERSION, {view_column} AS SEMANTIC_VIEW_NAME
                FROM {registry} s JOIN requested r
                  ON s.DATABASE_NAME = r.DATABASE_NAME
                 AND s.SCHEMA_NAME = r.SCHEMA_NAME AND s.TABLE_NAME = r.TABLE_NAME
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY s.DATABASE_NAME, s.SCHEMA_NAME, s.TABLE_NAME
                    ORDER BY IFF(UPPER(s.STATUS) = 'ACTIVE', 0, 1), s.{time_column} DESC
                ) = 1""",
                [value for parts in chunk for value in parts],
            )
            if rows is None:
                semantic_errors.update({parts: reason for parts in semantic_requested[start:]})
                break
            for parts in chunk:
                checked_registries[parts] = checked_registries.get(parts, 0) + 1
            for row in rows:
                data = row.as_dict() if hasattr(row, "as_dict") else row
                key = tuple(str(data[name]) for name in ("DATABASE_NAME", "SCHEMA_NAME", "TABLE_NAME"))
                if key not in chunk:
                    continue
                status = "active" if str(data.get("STATUS") or "").upper() in {"ACTIVE", "CURRENT", "READY", "PUBLISHED"} else "stale"
                if key not in semantics or status == "active":
                    semantics[key] = {
                        "semantic_status": status,
                        "semantic_table_view_id": data.get("ASSET_ID"),
                        "semantic_version": str(data.get("ASSET_VERSION") or ""),
                        "semantic_view_name": data.get("SEMANTIC_VIEW_NAME"),
                        "semantic_registry": registry,
                    }

    for item in result:
        parts = identifier_parts(str(item.get("resolved_fqn") or ""))
        warnings = [warning for warning in item.get('metadata_warnings') or []
                    if warning.get('code') not in {'UPLOAD_CATALOG_UNKNOWN','UPLOAD_SEMANTIC_UNKNOWN','UPLOAD_METADATA_UNKNOWN'}]
        if parts in requested:
            item['catalog_attempted'] = parts in context.attempted
            item.update(database_name=parts[0], schema_name=parts[1], table_name=parts[2])
            item["resolved_fqn"] = qualified_identifier(parts)
            if parts in visible:
                item["catalog_status"] = "available"
                item["resolution_status"] = "resolved"
                item["resolution_confidence"] = 1.0
                item.pop('resolution_error', None)
                warnings = [warning for warning in warnings if warning.get('code') not in {
                    'UPLOAD_CATALOG_UNKNOWN','UPLOAD_SEMANTIC_UNKNOWN','UPLOAD_METADATA_UNKNOWN'}]
            else:
                reason = "reference_limit" if parts not in selected else catalog_errors.get(parts, "deadline_exhausted")
                item["catalog_status"] = "lookup_failed"
                item["resolution_status"] = "lookup_failed"
                item["resolution_confidence"] = 0.0
                item["resolution_error"] = "Catalog availability is unknown; the identifier has not been proven missing."
                warnings.append({"code": "UPLOAD_CATALOG_UNKNOWN", "scope": "catalog", "reason": reason,
                                 "status": "unknown", "message": item["resolution_error"]})
            semantic = semantics.get(parts)
            if parts not in prior_semantics and checked_registries.get(parts) != 2 and (not semantic or semantic["semantic_status"] != "active"):
                semantic = None
            item.update(semantic or {
                "semantic_status": "missing" if checked_registries.get(parts) == 2 else "lookup_failed",
                "semantic_table_view_id": None,
                "semantic_version": None,
                "semantic_view_name": None,
                "semantic_registry": None,
            })
            if item["semantic_status"] == "lookup_failed":
                reason = "reference_limit" if parts not in selected else semantic_errors.get(parts, "lookup_failed")
                warnings.append({"code": "UPLOAD_SEMANTIC_UNKNOWN", "scope": "semantic", "reason": reason,
                                 "status": "unknown", "message": "Semantic availability is unknown, not confirmed missing. No SQL was evaluated."})
            item["metadata_warnings"] = warnings
        item["classification"] = classify_reference(item)
    return result
