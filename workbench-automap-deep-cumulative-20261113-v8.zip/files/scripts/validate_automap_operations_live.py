"""Native DEV-only ownership/concurrency test. No models, client mappings or grants."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
import json
from pathlib import Path
import sys
from threading import Barrier, Event, Lock, local
import time
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'services/sttm-builder'),str(ROOT)]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    from app.core.automap_operation_tracking import OperationCallTracking, OperationAlreadyRecorded
    from app.core.automap_admission import ScanCallAdmission, CallIdentity
    from app.core.sql_failure import sql_failure_details
    from app.core.automap_scan import ScanRequest, RuntimeCallTrace
    from app.core.automap_shards import SnapshotScope, MessageBudget
    from scripts.bootstrap_sttm_metadata_infra import execute_multi_statement, validate_automap_operations
    c=dotenv_values(args.credential_env)
    assert c['SNOWFLAKE_ACCOUNT'].upper()=='A0581299278961-BBINSIGHT_PARTNER'
    cfg=dict(account=c['SNOWFLAKE_ACCOUNT'],user=c['SNOWFLAKE_USER'],authenticator='PROGRAMMATIC_ACCESS_TOKEN',
        token=c['SNOWFLAKE_PASSWORD'],role=c['SNOWFLAKE_ROLE'],warehouse='FFP_HDP_CRM_MIG_WH_DEV',
        database='FFP_HDP_CRM_MIG_DB_DEV',schema='SCH_STTM_METADATA',login_timeout=20,network_timeout=30)
    schema='SCH_AUTOMAP_OPERATIONS_TEST_'+uuid4().hex[:12].upper()
    ns='FFP_HDP_CRM_MIG_DB_DEV.'+schema
    s=Session.builder.configs(cfg).create()
    report={'status':'started','namespace':ns,'models_called':0,'client_changes':False,
            'roles_or_grants_changed':False,'concurrent_operations':6,'legacy_capacity_argument':1}
    sessions=[];lock=Lock();thread=local();barrier=Barrier(6,timeout=40);observed=[];epoch=str(uuid4())
    try:
        native=s.sql('SELECT CURRENT_ORGANIZATION_NAME() O,CURRENT_ACCOUNT_NAME() A,CURRENT_USER() U').collect()[0]
        assert (native['O'],native['A'])==('A0581299278961','BBINSIGHT_PARTNER')
        account=native['O']+'.'+native['A'];owner=native['U']
        s.sql('CREATE SCHEMA '+ns).collect()
        ddl=(ROOT/'infra/snowflake/automap-call-operations.sql').read_text().replace('__STTM_METADATA_NAMESPACE__',ns)
        connection=s._conn._conn
        execute_multi_statement(connection,ddl,'isolated operation tracking')
        validate_automap_operations(connection,ns)
        @contextmanager
        def factory():
            if not hasattr(thread,'session'):
                thread.session=Session.builder.configs(cfg).create()
                with lock:sessions.append(thread.session)
            try:yield thread.session
            except BaseException:
                try:thread.session.sql('ROLLBACK').collect()
                finally:thread.session.close();del thread.session
                raise
        tracking=OperationCallTracking(session_factory=factory,table=ns+'.TBL_AUTOMAP_CALL_OPERATIONS',
            account_namespace=account,pool_epoch=epoch,capacity=1,recovery_capacity=1)
        original_sql=tracking._sql
        def measured_sql(session, query, params=None):
            started=time.monotonic()
            try:return original_sql(session,query,params)
            finally:
                row={'operation':query.split()[0], 'seconds':round(time.monotonic()-started,3)}
                with lock:report.setdefault('control_queries',[]).append(row)
        tracking._sql=measured_sql
        print(json.dumps({'stage':'bootstrap_complete'}),flush=True)
        def run(index):
            # Preopen caller-owned sessions outside measured dispatch preparation.
            with factory():pass
            barrier.wait()
            started=time.monotonic();trace=RuntimeCallTrace()
            req=ScanRequest(SnapshotScope(owner,'native-snapshot'),'native-generation',str(index),('T',),(),
                '[]',MessageBudget(2000,2000),time.monotonic()+60,Event(),Event(),runtime_trace=trace)
            gate=ScanCallAdmission(tracking,job_id='native-'+str(index),caller_id=owner)
            print(json.dumps({"stage":"claim_started","index":index}),flush=True)
            with gate(req):
                prepared=time.monotonic()-started
                print(json.dumps({"stage":"claim_complete","index":index,"seconds":round(prepared,3)}),flush=True)
                with lock:report.setdefault("claims",[]).append({"index":index,"seconds":round(prepared,3)})
                # All six must own operations before any completes. A slot pool
                # with capacity=1 cannot satisfy this barrier.
                barrier.wait()
                raw=gate.wrap_backend(lambda unused:'synthetic terminal response')(req)
                assert raw=='synthetic terminal response'
            with lock:observed.append({'index':index,'preparation_seconds':round(prepared,3),'total_seconds':round(time.monotonic()-started,3),'trace':trace.snapshot()})
        errors=[]
        with ThreadPoolExecutor(max_workers=6) as workers:
            futures={workers.submit(run,n):n for n in range(6)}
            for future in as_completed(futures):
                try:future.result()
                except Exception as error:
                    item={'index':futures[future],'error_type':type(error).__name__,'sql_failure':sql_failure_details(error)}
                    errors.append(item)
                    print(json.dumps({'stage':'call_failed',**item}),flush=True)
        report['errors']=errors
        if errors:raise RuntimeError('Native concurrency acceptance did not complete')
        health=tracking.health();assert health['completed']==6 and health['held']==0 and health['shared_capacity_limit'] is False
        with factory():
            try:tracking.try_claim(CallIdentity('native-0',owner,'native-generation','0'))
            except OperationAlreadyRecorded:pass
            else:raise AssertionError('Completed operation must not be resubmitted')
        duplicate_barrier=Barrier(6,timeout=40)
        def duplicate(index):
            with factory():pass
            duplicate_barrier.wait()
            try:
                return tracking.try_claim(CallIdentity('duplicate',owner,'native-generation','same'))
            except OperationAlreadyRecorded:return None
        with ThreadPoolExecutor(max_workers=6) as workers:
            duplicate_results=list(workers.map(duplicate,range(6)))
        claimed=[p for p in duplicate_results if p is not None]
        assert len(claimed)==1
        from app.core.automap_admission import Completion
        tracking.complete(claimed[0],Completion.SUCCEEDED)
        report.update(status='passed',runs=sorted(observed,key=lambda row:row['index']),health=health,
            concurrent_duplicate_attempts=6,concurrent_duplicate_owners=len(claimed))
    except Exception as error:
        report.update(status='failed',error_type=type(error).__name__,sql_failure=sql_failure_details(error))
        raise
    finally:
        report['elapsed_fixture_scope']='Session initialization excluded from per-call preparation; no model execution.'
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,indent=2)+'\n')
        for session in sessions:session.close()
        s.close()
    print(json.dumps({'status':report['status'],'report':str(args.output),'namespace':ns}))


if __name__=='__main__':main()
