# SPCS OAuth, Semantic Registry, Auto-map, and CoCo Notes

## OAuth repair

The original SPCS failure was not caused by the OAuth integration name, redirect URI, client ID, or network reachability. The same token request worked outside SPCS. Inside SPCS it failed because the service did not enable `capabilities.securityContext.enableCustomCredentials`, so Snowflake rejected custom credential use from the service context.

The fix keeps layered user OAuth. SPCS ingress identity is still useful for service access, but Cortex Agent and Analyst REST endpoints need a normal Snowflake OAuth bearer token for the signed-in user. The app now:

- keeps `executeAsCaller` for ingress compatibility;
- enables custom credentials for custom OAuth deployments;
- uses Basic-only token exchange with PKCE;
- stores OAuth client credentials in Snowflake password-type secrets instead of rendered YAML;
- stops overriding Snowflake runtime account/host values for connector traffic;
- requires Snowflake Connector `>=4.5.0,<5`;
- returns sanitized envelope `1.0` OAuth errors without upstream bodies, codes, tokens, or secrets.

The localhost redirect happened because the rendered SPCS environment still had the local callback URI. The SPCS callback must be the public SPCS app callback URL. Localhost is valid only for local dev and must remain an alternate redirect in the OAuth integration.

## Client AVD / repeated deployments

For a new client environment, create or configure:

- the Snowflake custom OAuth security integration;
- SPCS external access integration for Snowflake token/API hosts;
- password-type secret containing OAuth client ID/secret;
- service spec with `enableCustomCredentials: true` when `AUTH_MODE=custom_oauth`;
- callback redirect URI for the exact public SPCS endpoint;
- local alternate callback only for local developer mode;
- app/persona roles and grants for registry reads, worker service access, and admin-only CoCo.

If Snowflake creates a new public endpoint hostname, update the OAuth integration redirect list with the new callback URI. If the service is upgraded in-place and the public endpoint stays the same, no redirect update is needed.

## Semantic registry and bundling

`AGT_SEMANTIC_MODEL_V2` remains the semantic producer. The application does not generate baseline semantics. The app now consumes the registry and preserves the full v2 model instead of flattening it into a simplified column-role YAML.

Canonical registry tables live in `FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA`:

- `SEM_TABLE_VIEWS`
- `SEM_COLUMN_VIEWS`
- `TBL_SEMANTIC_MODELS`

Single-table assets store the physical semantic view and relationship candidates. A multi-table chat/Auto-map request composes one inline Analyst model from selected source/target assets, selected derived sources, and explicit UI relationships. UI relationships override saved candidates but still validate against selected endpoints.

Chat and Auto-map requests do not run semantic generation, freshness checks, promotion, or semantic DDL. Missing assets return semantic errors for the pipeline to repair.

## Auto-map dispatch

The main app resolves and validates the semantic bundle before dispatching to the private Auto-map worker service. Workers receive the same canonical context hash, bundle hash, OAuth identity, compact semantic context, ordered target-attribute batch, mapping intent, and accepted mappings.

The proxy keeps at most two batches in flight so the two worker instances can process concurrently. Each worker calls `AGT_SOURCE_MAPPING` once for its batch. Results are schema-validated and merged back in the original target order.

## CoCo deep-agent mode

CoCo is isolated behind an admin-only WebSocket route and sidecar runtime. It uses the signed-in admin's refreshed OAuth token through a temporary mode-0600 token file and an isolated Snowflake CLI OAuth connection.

The SDK runs in `permission_mode="plan"` and uses native `can_use_tool`. Read-only Workbench knowledge and diagnostics can auto-approve. Mutating SQL, DDL/DML, procedure/task/agent/service changes, semantic publication, file writes, deployments, Git operations, mapping commits, derived-source commits, and mutating MCP tools pause and request approval in the UI. Account/security/production operations remain blocked even after session approval.

CoCo receives `WorkbenchContextSnapshotV1` at session start and at each turn, and can use the Workbench MCP server for live context, product knowledge, bundle inspection, health checks, and explicit STTM orchestrator calls.
