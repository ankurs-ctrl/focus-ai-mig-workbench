"""FIR System integration tests."""
