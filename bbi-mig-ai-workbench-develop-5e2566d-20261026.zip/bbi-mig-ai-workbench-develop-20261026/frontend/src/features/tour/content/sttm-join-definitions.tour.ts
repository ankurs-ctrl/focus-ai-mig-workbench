import type { TourDefinition } from "../types/tour.types";
import { TOUR_TARGETS, tourSelector } from "../constants/tour-targets";

export const sttmJoinDefinitionsTour: TourDefinition = {
  id: "sttm-join-definitions",
  label: "Join Definitions",
  description: "View, select, and create joins between source datasets.",
  routes: ["/sttm/builder/new"],
  steps: [
    {
      id: "sttm-join-definitions-intro",
      title: "Join Definition",
      body: "The Join Definition section allows users to view existing joins, select required joins, and create new joins between source datasets.",
      placement: "center",
      isModal: true,
    },
    {
      id: "sttm-join-definitions-driving",
      title: "Driving Joins",
      body: "View joins involving the driving table.",
      target: tourSelector(TOUR_TARGETS.sttmJoinDrivingTab),
      placement: "bottom",
      isModal: true,
    },
    {
      id: "sttm-join-definitions-additional",
      title: "Additional Joins",
      body: "View joins from other source tables.",
      target: tourSelector(TOUR_TARGETS.sttmJoinAdditionalTab),
      placement: "bottom",
      isModal: true,
    },
    {
      id: "sttm-join-definitions-recommendations",
      title: "AI Recommendations",
      body: "Review AI-suggested joins based on similar mappings and the current mapping context. Recommendations are grouped as High, Medium, and Low confidence to help you quickly identify the most relevant joins.",
      target: tourSelector(TOUR_TARGETS.sttmJoinRecommendationsTab),
      placement: "bottom",
      isModal: true,
    },
    {
      id: "sttm-join-definitions-edit-delete",
      title: "Edit and Delete",
      body: "Use the Edit icon to modify a join or the Delete option to remove it.",
      target: tourSelector(TOUR_TARGETS.sttmJoinCardActions),
      placement: "left",
      isModal: true,
    },
  ],
};
