# Frontend Persona and Access-Control Handoff

## Purpose

Use the authenticated session response to control frontend navigation, routes, and actions. The UI should consume permission flags instead of duplicating a role-to-permission matrix in components.

UI hiding is a usability measure, not the security boundary. Backend endpoints must continue to reject unauthorized operations.

## Primary endpoint

```http
GET /api/v1/auth/session
```

The frontend route constant is `/v1/auth/session`; the shared API client adds the `/api` proxy prefix.

The backend returns the standard response envelope:

```json
{
  "contract_version": "1.0",
  "request_id": "...",
  "operation": "auth.session",
  "actor": {
    "user_id": "7",
    "role": "PUBLISHER"
  },
  "context": {},
  "data": {
    "user_id": 7,
    "email": "publisher@example.com",
    "display_name": "Shane Watson",
    "app_persona": "PUBLISHER",
    "ui_permissions": {
      "can_read": true,
      "can_edit": true,
      "can_publish": true,
      "can_manage_users": false,
      "can_view_audit": false
    }
  },
  "warnings": [],
  "error": null,
  "meta": {}
}
```

`authService.getSession()` already unwraps the envelope and returns the `data` object as `UserSession`:

```ts
import { authService } from '@/services/authService';

const session = await authService.getSession();
```

Do not call `/snowflake-context` to decide UI access. It reports the active Snowflake execution role, while `/auth/session` returns the application persona and effective UI permissions.

## Supported personas

The backend currently supports exactly these application personas:

- `ADMIN`
- `PUBLISHER`
- `VIEWER`

`EDITOR` appears in mock Administration data but is not a supported backend persona. It must not be added to production UI decisions until the backend model explicitly supports it.

The current backend permission defaults are:

| Persona | Read | Edit | Publish | Manage users | View audit |
| --- | ---: | ---: | ---: | ---: | ---: |
| `ADMIN` | Yes | Yes | Yes | Yes | Yes |
| `PUBLISHER` | Yes | Yes | Yes | No | No |
| `VIEWER` | Yes | No | No | No | No |

These defaults are explanatory only. Frontend code should use `ui_permissions`, not recreate this table.

## Required frontend behavior

| UI capability | Permission check | Expected behavior when false |
| --- | --- | --- |
| Read/list/view pages | `can_read` | Show an access-denied state or redirect to an allowed landing page |
| Create or edit projects/mappings | `can_edit` | Hide create/edit/autosave actions and render data read-only |
| Auto-map or other mapping mutations | `can_edit` | Hide or disable mutation controls |
| Publish mapping | `can_publish` | Hide the Publish action |
| Administration/user management | `can_manage_users` | Hide navigation and block direct route access |
| Audit log | `can_view_audit` | Hide navigation and block direct route access |

For the current product decision that the entire Administration area is Admin-only, show its navigation and permit its route when:

```ts
const canAccessAdministration =
  session.ui_permissions.can_manage_users ||
  session.ui_permissions.can_view_audit;
```

This avoids hardcoding `session.app_persona === 'ADMIN'` and remains correct if permissions become configurable later.

## Recommended integration pattern

Load the session once near the application root and expose three explicit states: loading, authenticated, and denied/unauthenticated. Avoid fetching the session independently in every page.

```ts
type AccessRequirement = keyof UserSession['ui_permissions'];

function hasPermission(
  session: UserSession | null,
  permission: AccessRequirement,
): boolean {
  return session?.ui_permissions[permission] === true;
}
```

Navigation example:

```tsx
{hasPermission(session, 'can_manage_users') ? (
  <AdministrationNavItem />
) : null}
```

Edit-action example:

```tsx
{hasPermission(session, 'can_edit') ? (
  <EditMappingButton />
) : null}
```

Route guards must be applied as well as navigation filtering. A Publisher or Viewer who manually enters an Administration URL should receive an access-denied page and should not see the Administration screen briefly while the session is loading.

For read-only mapping pages, prefer keeping the page visible to a Viewer while removing mutation actions. Inputs should be read-only/disabled, and background autosave or mutation requests must not run.

## Related endpoints

```http
GET /api/v1/auth/permissions
```

Returns only the effective `PermissionSet`. Prefer `/auth/session` for initial application bootstrap because it provides identity, persona, and permissions in one request.

```http
GET /api/v1/auth/snowflake-context
```

Returns `CURRENT_USER`, `CURRENT_ROLE`, warehouse, database, and schema for diagnostics. Do not use it for application authorization.

```http
GET /api/v1/user/roles
```

Returns granted/active Snowflake roles. This is useful for role diagnostics or role switching, not as a replacement for `ui_permissions`.

## Persona resolution

In OAuth/SPCS execute-as-caller mode, the backend checks the configured Snowflake application roles with `IS_ROLE_IN_SESSION`. If several application roles are active, precedence is:

1. `ADMIN`
2. `PUBLISHER`
3. `VIEWER`

A user with none of these roles receives HTTP 403.

## Error handling

- `401`: authentication/session is missing or expired. Send the user through the login flow.
- `403`: the user is authenticated but lacks an application persona or required permission. Show access denied; do not retry as though it were a transient failure.
- `5xx`: show a recoverable session-loading error and allow retry.
- Never temporarily default to Admin or Publisher while the session request is pending or failing.

## Current implementation gaps

The session contract and permission model exist, but authorization is not yet consistently wired through the frontend:

- The global sidebar currently shows Administration to every authenticated persona.
- Administration pages currently use mock/local data and include an unsupported mock `Editor` persona.
- The existing screen-permissions UI is not the authoritative backend permission source.
- Several backend mutation routes authenticate users but do not yet enforce `can_edit` or `can_publish` consistently. Frontend gating must not be treated as a substitute for completing those backend checks.

## Frontend acceptance checks

- Admin sees Administration, edit, publish, user-management, and audit controls.
- Publisher does not see Administration, user-management, or audit; Publisher can edit and publish.
- Viewer does not see Administration, create, edit, auto-map, autosave, or publish controls.
- Viewer can open supported read-only project and mapping views.
- Direct navigation to a forbidden page produces access denied without rendering protected content first.
- Refreshing a protected route preserves the correct authorization result.
- A failed session request never exposes privileged controls.
- Components use permission flags rather than comparing role strings.

## Source references

- Frontend endpoint registry: `frontend/src/api/routes.ts`
- Frontend client: `frontend/src/services/authService.ts`
- Frontend types: `frontend/src/types/user.ts`
- Backend session endpoint: `services/sttm-builder/app/auth/router.py`
- Persona resolution: `services/sttm-builder/app/auth/persona/resolver.py`
- Permission matrix: `services/sttm-builder/app/auth/persona/permissions.py`
- Backend authorization dependency: `services/sttm-builder/app/auth/dependencies.py`

