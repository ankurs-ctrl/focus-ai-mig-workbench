export type AppNavItem =
  | "Dashboard"
  | "Administration"
  | "Projects"
  | "Mappings"
  | "AI Agent";

export const APP_NAV_ROUTES: Record<AppNavItem, string> = {
  Dashboard: "/dashboard",
  Administration: "/administration",
  Projects: "/projects",
  Mappings: "/mappings",
  "AI Agent": "/ai-agent",
};

export const APP_SIDEBAR_STORAGE_KEY = "app-sidebar-collapsed";

export const APP_SIDEBAR_EXCLUDED_PATHS = ["/home"] as const;

export function shouldShowAppSidebar(pathname: string): boolean {
  return !APP_SIDEBAR_EXCLUDED_PATHS.some(
    (path) => pathname === path || pathname.startsWith(`${path}/`),
  );
}

export function resolveAppNavItem(pathname: string): AppNavItem | undefined {
  if (pathname === APP_NAV_ROUTES.Dashboard || pathname.startsWith(`${APP_NAV_ROUTES.Dashboard}/`)) {
    return "Dashboard";
  }
  if (
    pathname === APP_NAV_ROUTES.Administration ||
    pathname.startsWith(`${APP_NAV_ROUTES.Administration}/`)
  ) {
    return "Administration";
  }
  if (pathname === APP_NAV_ROUTES.Projects || pathname.startsWith(`${APP_NAV_ROUTES.Projects}/`)) {
    return "Projects";
  }
  if (pathname === "/attributes" || pathname.startsWith("/attributes/")) {
    return "Projects";
  }
  if (pathname === APP_NAV_ROUTES.Mappings || pathname.startsWith(`${APP_NAV_ROUTES.Mappings}/`)) {
    return "Mappings";
  }
  if (
    pathname === APP_NAV_ROUTES["AI Agent"]
    || pathname.startsWith(`${APP_NAV_ROUTES["AI Agent"]}/`)
  ) {
    return "AI Agent";
  }
  return undefined;
}
