import json
import logging
import threading
import time
import uuid
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError, as_completed
from datetime import UTC, datetime
from typing import Any

import httpx
from fastapi import HTTPException, Request

from app.auth.models import AppPersona
from app.core.config import Settings
from app.core.exceptions import SnowflakeAgentError
from app.schema.contracts import ApiWarning
from app.schema.sttm_builder import (
    AttributeMapping,
    Interface,
    SourceMappingResult,
    STTMBuilderEnvelopeRequest,
    STTMBuilderResponse,
)

logger = logging.getLogger(__name__)

_AUTO_MAP_JOBS: dict[str, dict[str, Any]] = {}
_AUTO_MAP_JOBS_LOCK = threading.Lock()
_AUTO_MAP_JOB_TTL_SECONDS = 60 * 60

_FORWARDED_HEADER_NAMES = (
    "Sf-Context-Current-User",
    "Sf-Context-Current-User-Email",
    "Sf-Context-Current-User-Token",
    "X-Request-Id",
    "X-Trace-Id",
)
_OAUTH_FORWARDED_HEADER_NAMES = (
    "X-Workbench-OAuth-Access-Token",
    "X-Workbench-OAuth-User",
    "X-Workbench-OAuth-Email",
    "X-Workbench-OAuth-Role",
)


class AutoMappingProxyClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._base_url = settings.auto_mapping_service_url.strip().rstrip("/")
        self._timeout = settings.auto_mapping_service_timeout_seconds
        self._retry_attempts = max(1, settings.auto_mapping_service_retry_attempts)
        self._batch_size = max(1, settings.auto_mapping_proxy_batch_size)
        self._max_in_flight = max(1, settings.auto_mapping_proxy_max_in_flight)

    @property
    def enabled(self) -> bool:
        return bool(self._base_url)

    def should_delegate(self, req: STTMBuilderEnvelopeRequest) -> bool:
        return self.enabled and req.data.intent == Interface.AUTO_MAP

    def start_job(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
    ) -> dict[str, Any]:
        """Run long Cortex mapping work outside the public ingress request."""
        principal = getattr(request.state, "current_principal", None)
        owner = str(
            getattr(principal, "snowflake_user", None)
            or getattr(principal, "user_id", None)
            or ""
        )
        headers = self._forward_headers(request)
        job_id = str(uuid.uuid4())
        created_at = datetime.now(UTC)
        record: dict[str, Any] = {
            "job_id": job_id,
            "request_id": req.request_id,
            "owner": owner,
            "status": "queued",
            "created_at": created_at.isoformat(),
            "updated_at": created_at.isoformat(),
            "attribute_count": len(req.data.attributes or []),
            "batch_count": max(
                1,
                (len(req.data.attributes or []) + self._batch_size - 1) // self._batch_size,
            ),
            "completed_batch_count": 0,
            "completed_attribute_count": 0,
            "partial_responses": [],
            "response": None,
            "error": None,
        }
        self._prune_jobs()
        with _AUTO_MAP_JOBS_LOCK:
            _AUTO_MAP_JOBS[job_id] = record

        def run() -> None:
            self._update_job(job_id, status="running")
            try:
                try:
                    response = self._invoke_with_headers(
                        req,
                        headers=headers,
                        progress_callback=lambda batch_index, batch_attributes, batch_response: self._record_partial_response(
                            job_id,
                            batch_index=batch_index,
                            batch_attributes=batch_attributes,
                            response=batch_response,
                        ),
                    )
                except TypeError as exc:
                    # Some unit tests and legacy integrations monkeypatch this
                    # internal method without the progress_callback kwarg. Keep
                    # that compatibility while production calls still receive
                    # partial batch updates.
                    if "progress_callback" not in str(exc):
                        raise
                    response = self._invoke_with_headers(req, headers=headers)
            except Exception as exc:
                logger.exception(
                    "Async Auto-map job failed: job_id=%s request_id=%s error_type=%s",
                    job_id,
                    req.request_id,
                    type(exc).__name__,
                )
                self._update_job(
                    job_id,
                    status="failed",
                    error={
                        "code": "AUTO_MAPPING_JOB_FAILED",
                        "message": "The Auto-map Agent job could not be completed.",
                    },
                )
                return
            self._update_job(
                job_id,
                status="completed",
                response=response.model_dump(mode="json"),
                completed_batch_count=record.get("batch_count"),
                completed_attribute_count=record.get("attribute_count"),
            )

        threading.Thread(
            target=run,
            name=f"auto-map-job-{job_id[:8]}",
            daemon=True,
        ).start()
        return self._public_job(record)

    def get_job(self, request: Request, job_id: str) -> dict[str, Any]:
        principal = getattr(request.state, "current_principal", None)
        owner = str(
            getattr(principal, "snowflake_user", None)
            or getattr(principal, "user_id", None)
            or ""
        )
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS.get(job_id)
            if record is None:
                raise HTTPException(status_code=404, detail="Auto-map job was not found")
            if record.get("owner") != owner:
                raise HTTPException(status_code=403, detail="Auto-map job belongs to another user")
            return self._public_job(record)

    @staticmethod
    def _public_job(record: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in record.items() if key != "owner"}

    @staticmethod
    def _update_job(job_id: str, **updates: Any) -> None:
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS.get(job_id)
            if record is None:
                return
            record.update(updates)
            record["updated_at"] = datetime.now(UTC).isoformat()

    @staticmethod
    def _record_partial_response(
        job_id: str,
        *,
        batch_index: int,
        batch_attributes: list[Any],
        response: STTMBuilderResponse,
    ) -> None:
        with _AUTO_MAP_JOBS_LOCK:
            record = _AUTO_MAP_JOBS.get(job_id)
            if record is None:
                return
            partials = list(record.get("partial_responses") or [])
            partials = [
                item
                for item in partials
                if int(item.get("batch_index", -1)) != batch_index
            ]
            partials.append(
                {
                    "batch_index": batch_index,
                    "attribute_count": len(batch_attributes),
                    "target_attributes": [
                        getattr(attribute, "target_attribute", None)
                        for attribute in batch_attributes
                    ],
                    "response": response.model_dump(mode="json"),
                    "completed_at": datetime.now(UTC).isoformat(),
                }
            )
            partials.sort(key=lambda item: int(item.get("batch_index", 0)))
            record["partial_responses"] = partials
            record["completed_batch_count"] = len(partials)
            record["completed_attribute_count"] = sum(
                int(item.get("attribute_count") or 0) for item in partials
            )
            record["updated_at"] = datetime.now(UTC).isoformat()

    @staticmethod
    def _prune_jobs() -> None:
        cutoff = time.time() - _AUTO_MAP_JOB_TTL_SECONDS
        with _AUTO_MAP_JOBS_LOCK:
            expired = []
            for job_id, record in _AUTO_MAP_JOBS.items():
                created_at = str(record.get("created_at") or "")
                try:
                    timestamp = datetime.fromisoformat(created_at).timestamp()
                except ValueError:
                    timestamp = 0
                if timestamp < cutoff:
                    expired.append(job_id)
            for job_id in expired:
                _AUTO_MAP_JOBS.pop(job_id, None)

    def invoke(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
    ) -> STTMBuilderResponse:
        if not self.should_delegate(req):
            raise SnowflakeAgentError("Auto-mapping worker service is not configured.")

        headers = self._forward_headers(request)
        return self._invoke_with_headers(req, headers=headers)

    def _invoke_with_headers(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        headers: dict[str, str],
        progress_callback: Callable[[int, list[Any], STTMBuilderResponse], None] | None = None,
    ) -> STTMBuilderResponse:
        attributes = list(req.data.attributes or [])
        if len(attributes) <= self._batch_size:
            response = self._invoke_batch(req, headers=headers, batch_index=0)
            if progress_callback is not None:
                progress_callback(0, attributes, response)
            return response

        batches = [
            attributes[index:index + self._batch_size]
            for index in range(0, len(attributes), self._batch_size)
        ]
        logger.info(
            "Dispatching auto-map request_id=%s attributes=%s batches=%s max_in_flight=%s",
            req.request_id,
            len(attributes),
            len(batches),
            self._max_in_flight,
        )
        responses: dict[int, STTMBuilderResponse] = {}
        failures: dict[int, Exception] = {}
        with ThreadPoolExecutor(max_workers=min(self._max_in_flight, len(batches))) as executor:
            futures = {
                executor.submit(
                    self._invoke_batch,
                    req.model_copy(
                        update={
                            "data": req.data.model_copy(update={"attributes": batch}),
                            "meta": {**req.meta, "auto_mapping_batch_index": index},
                        }
                    ),
                    headers=headers,
                    batch_index=index,
                ): index
                for index, batch in enumerate(batches)
            }
            for future in as_completed(futures):
                index = futures[future]
                try:
                    responses[index] = future.result()
                    if progress_callback is not None:
                        progress_callback(index, batches[index], responses[index])
                except Exception as exc:
                    failures[index] = exc

        if not responses:
            first_failure = failures[min(failures)]
            raise SnowflakeAgentError(
                f"All Auto-map worker batches failed: {first_failure}"
            ) from first_failure

        first = responses[min(responses)]
        merged_mappings: dict[str, AttributeMapping] = {}
        merged_warnings = list(first.warnings)
        for index, batch in enumerate(batches):
            response = responses.get(index)
            response_result = response.data.result if response and response.data else None
            if not isinstance(response_result, SourceMappingResult):
                response_result = response.result if response else None
            if isinstance(response_result, SourceMappingResult):
                merged_mappings.update(response_result.mappings)
                if response is not first:
                    merged_warnings.extend(response.warnings)
                continue
            failure = failures.get(index)
            for attribute in batch:
                key = attribute.target_attribute
                merged_mappings[key] = AttributeMapping(
                    source_attributes=[],
                    confidence_score=0.0,
                    unmatched_reason=(
                        "The dedicated Auto-map worker could not process this target attribute."
                    ),
                )
                merged_warnings.append(
                    ApiWarning(
                        code="AUTO_MAPPING_BATCH_FAILED",
                        message=f"Auto-map batch {index + 1} failed: {failure}",
                        field=key,
                    )
                )

        merged_result = SourceMappingResult(mappings=merged_mappings)
        merged_data = first.data.model_copy(
            update={
                "result": merged_result,
                "message": (
                    f"Auto-mapped {len(attributes)} target attributes across "
                    f"{len(batches)} worker batches."
                ),
            }
        ) if first.data else None
        return first.model_copy(
            update={
                "data": merged_data,
                "result": merged_result,
                "message": (
                    f"Auto-mapped {len(attributes)} target attributes across "
                    f"{len(batches)} worker batches."
                ),
                "warnings": merged_warnings,
                "meta": {
                    **first.meta,
                    "auto_mapping_dispatch": {
                        "attribute_count": len(attributes),
                        "batch_count": len(batches),
                        "batch_size": self._batch_size,
                        "max_in_flight": self._max_in_flight,
                        "failed_batches": sorted(failures),
                    },
                },
            }
        )

    def _invoke_batch(
        self,
        req: STTMBuilderEnvelopeRequest,
        *,
        headers: dict[str, str],
        batch_index: int,
    ) -> STTMBuilderResponse:
        payload = req.model_dump(mode="json")
        last_error: Exception | None = None
        endpoint = f"{self._base_url}/api/v1/auto-mapping/invoke"
        logger.info(
            "Dispatching auto-map request_id=%s batch=%s to worker endpoint=%s",
            req.request_id,
            batch_index + 1,
            endpoint,
        )

        for attempt in range(1, self._retry_attempts + 1):
            try:
                with httpx.Client(timeout=self._timeout) as client:
                    response = client.post(
                        endpoint,
                        headers=headers,
                        json=payload,
                    )
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt >= self._retry_attempts:
                    break
                logger.warning(
                    "Auto-mapping worker call failed (attempt %s/%s). Retrying: %s",
                    attempt,
                    self._retry_attempts,
                    exc,
                )
                time.sleep(1.0)
                continue

            if response.status_code == 200:
                logger.info(
                    "Auto-mapping worker request_id=%s completed with HTTP 200",
                    req.request_id,
                )
                try:
                    parsed = STTMBuilderResponse.model_validate(response.json())
                except Exception as exc:
                    raise SnowflakeAgentError(
                        f"Auto-mapping worker returned an invalid response payload: {exc}"
                    ) from exc
                self._validate_worker_response(parsed, batch_index=batch_index)
                return parsed

            if response.status_code < 500 and response.status_code != 429:
                logger.warning(
                    "Auto-mapping worker request_id=%s failed with HTTP %s",
                    req.request_id,
                    response.status_code,
                )
                raise SnowflakeAgentError(
                    f"Auto-mapping worker returned HTTP {response.status_code}"
                )

            last_error = SnowflakeAgentError(
                f"Auto-mapping worker returned HTTP {response.status_code}"
            )
            if attempt >= self._retry_attempts:
                break
            logger.warning(
                "Auto-mapping worker returned a transient error (attempt %s/%s). Retrying: %s",
                attempt,
                self._retry_attempts,
                response.status_code,
            )
            time.sleep(1.0)

        raise SnowflakeAgentError(
            f"Auto-mapping worker request failed: {last_error}"
        ) from last_error

    @staticmethod
    def _validate_worker_response(
        response: STTMBuilderResponse,
        *,
        batch_index: int,
    ) -> None:
        """Reject HTTP-200 envelopes that contain an Agent or contract failure."""
        if response.error is not None:
            code = response.error.code or "AUTO_MAPPING_AGENT_ERROR"
            raise SnowflakeAgentError(
                f"Auto-map batch {batch_index + 1} failed with {code}: "
                f"{response.error.title}"
            )
        response_data = response.data
        if response_data is None or response_data.status.value == "failed":
            raise SnowflakeAgentError(
                f"Auto-map batch {batch_index + 1} returned a failed response envelope."
            )
        result = response_data.result
        if not isinstance(result, SourceMappingResult):
            result = response.result
        if not isinstance(result, SourceMappingResult) or not result.mappings:
            raise SnowflakeAgentError(
                f"Auto-map batch {batch_index + 1} returned no source-mapping result."
            )

    def invoke_stream(
        self,
        request: Request,
        req: STTMBuilderEnvelopeRequest,
        *,
        prepare_request: Callable[[STTMBuilderEnvelopeRequest], STTMBuilderEnvelopeRequest] | None = None,
    ) -> Iterator[str]:
        def emit(event: str, data: dict[str, object]) -> str:
            return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"

        try:
            if prepare_request is not None:
                yield emit(
                    "status",
                    {
                        "phase": "automap_bundle_resolution",
                        "message": "Resolving the saved source and target semantic assets.",
                    },
                )
                req = prepare_request(req)
                semantic = req.context.workspace_context.semantic if req.context.workspace_context else None
                yield emit(
                    "status",
                    {
                        "phase": "automap_bundle_validated",
                        "message": "The composed semantic bundle is valid and ready for worker dispatch.",
                        "bundle_id": req.context.semantic_bundle_id,
                        "bundle_hash": semantic.bundle_hash if semantic else None,
                        "context_hash": (
                            req.context.workspace_context.context_hash
                            if req.context.workspace_context
                            else None
                        ),
                    },
                )
            yield emit(
                "status",
                {
                    "phase": "automap_batch_assignment",
                    "message": (
                        "Assigning ordered target-attribute batches across up to two "
                        "Auto-map service instances."
                    ),
                    "attribute_count": len(req.data.attributes or []),
                    "batch_size": self._batch_size,
                    "max_in_flight": self._max_in_flight,
                },
            )
            # Keep the browser-facing SSE connection active while the two private
            # service instances wait for their Cortex Agent responses.
            started_at = time.monotonic()
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(self.invoke, request, req)
                while True:
                    try:
                        response = future.result(timeout=10.0)
                        break
                    except FutureTimeoutError:
                        yield emit(
                            "status",
                            {
                                "phase": "automap_workers_running",
                                "message": (
                                    "AGT_SOURCE_MAPPING is processing semantic mapping batches "
                                    "across the Auto-map service instances."
                                ),
                                "elapsed_seconds": int(time.monotonic() - started_at),
                                "max_in_flight": self._max_in_flight,
                            },
                        )
            yield emit(
                "status",
                {
                    "phase": "automap_worker_completed",
                    "message": "All completed worker batches were merged in target order.",
                },
            )
            yield emit("final", response.model_dump(mode="json"))
        except Exception as exc:
            logger.exception(
                "Auto-map stream failed: request_id=%s error_type=%s",
                req.request_id,
                type(exc).__name__,
            )
            yield emit(
                "error",
                {
                    "contract_version": "1.0",
                    "request_id": req.request_id,
                    "operation": req.operation.value,
                    "data": None,
                    "warnings": [],
                    "error": {
                        "type": "about:blank",
                        "title": "Auto-map worker request failed",
                        "status": 502,
                        "detail": "The Auto-map worker could not complete the request.",
                        "code": "AUTO_MAPPING_WORKER_ERROR",
                    },
                    "message": "The Auto-map worker could not complete the request.",
                },
            )

    def _forward_headers(self, request: Request) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        forwarded_header_names = (
            _OAUTH_FORWARDED_HEADER_NAMES if self._settings.uses_custom_oauth else _FORWARDED_HEADER_NAMES
        )
        for header_name in forwarded_header_names:
            value = request.headers.get(header_name)
            if value:
                headers[header_name] = value
        principal = getattr(request.state, "current_principal", None)
        if principal is not None:
            if self._settings.uses_custom_oauth and principal.snowflake_user_token:
                headers["X-Workbench-OAuth-Access-Token"] = principal.snowflake_user_token
                headers["X-Workbench-OAuth-User"] = principal.snowflake_user
                headers["X-Workbench-OAuth-Email"] = principal.email
                if principal.snowflake_role:
                    headers["X-Workbench-OAuth-Role"] = principal.snowflake_role
            caller_role = None
            if principal.app_persona is AppPersona.ADMIN:
                caller_role = self._settings.app_role_admin
            elif principal.app_persona is AppPersona.PUBLISHER:
                caller_role = self._settings.app_role_publisher
            elif principal.app_persona is AppPersona.VIEWER:
                caller_role = self._settings.app_role_viewer
            if caller_role:
                headers["X-Workbench-Caller-Role"] = caller_role
        return headers
