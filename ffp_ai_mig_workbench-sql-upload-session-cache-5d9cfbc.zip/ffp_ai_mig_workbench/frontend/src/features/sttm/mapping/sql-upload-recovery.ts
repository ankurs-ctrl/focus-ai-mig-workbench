/** Durable SQL-upload recovery. Never retries an uncertain POST. */
export type UploadReceipt = {
  request_id: string; status: string; stage?: string; result?: unknown; error_code?: string;
};
export const uploadRecoveryKey = (project: string, mapping: string, identity = 'legacy') =>
  `sql-upload-recovery:v2:${encodeURIComponent(identity)}:${encodeURIComponent(project)}:${encodeURIComponent(mapping || 'new')}`;

export async function observeSqlUpload(
  baseUrl: string, project: string, requestId: string, signal: AbortSignal,
  options?: {attempts?: number; delay?: () => Promise<void>; onProgress?: (receipt: UploadReceipt) => void},
): Promise<UploadReceipt> {
  let last: UploadReceipt = {request_id: requestId, status: 'unknown'};
  let notFound = 0;
  const attempts = options?.attempts ?? 30;
  const deadline = Date.now() + 60000;
  for (let attempt = 0; attempt < attempts && Date.now() < deadline; attempt++) {
    if (signal.aborted) throw new DOMException('Aborted', 'AbortError');
    try {
      const response = await fetch(`${baseUrl}/v1/upload/sql/requests/${encodeURIComponent(requestId)}?project_id=${encodeURIComponent(project)}`,
        {cache:'no-store', signal: AbortSignal.any([signal, AbortSignal.timeout(Math.max(1, Math.min(10000, deadline - Date.now())))])});
      if (response.ok) {
        last = await response.json();
        if (!signal.aborted) options?.onProgress?.(last);
        if (last.result || ['completed','failed','needs_reupload'].includes(last.status)) return last;
      } else if (response.status === 503) {
        const body = await response.json().catch(() => null);
        if (body?.detail?.code === 'sql_upload_dependency_unavailable')
          throw new Error('Upload recovery dependencies are unavailable. Ask an administrator to verify migration and access; your request identity is retained.');
      } else if (response.status === 404) {
        notFound++;
      } else if ([401,403,409].includes(response.status)) {
        throw new Error('Upload recovery is unavailable for this signed-in caller or request.');
      } // A 404 after a disconnect can precede acceptance. Reconcile, never POST again.
    } catch (error) {
      if (signal.aborted) throw error;
      if (error instanceof Error && error.message.startsWith('Upload recovery')) throw error;
    }
    await (options?.delay?.() ?? new Promise(resolve => setTimeout(resolve, Math.max(0, Math.min(1500, deadline - Date.now())))));
  }
  return notFound && last.status === 'unknown' ? {...last, status:'not_visible'} : last;
}

export type SavedSqlUpload = {requestId: string; fingerprint: string};
export function readSqlUploadHandle(value: string | null): SavedSqlUpload | null {
  if (!value) return null;
  try {
    const item = JSON.parse(value);
    return typeof item?.requestId === 'string' && typeof item?.fingerprint === 'string' ? item : null;
  } catch { return {requestId:value, fingerprint:''}; }
}
export async function sqlUploadFingerprint(file: Blob, options: Array<[string,string]>): Promise<string> {
  const hash = async (bytes: ArrayBuffer) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)))
    .map(value => value.toString(16).padStart(2,'0')).join('');
  const content = await hash(await file.arrayBuffer());
  const canonical = JSON.stringify(['sql-upload-5-scoped-lineage',content,[...options].sort(([a],[b])=>a.localeCompare(b))]);
  return hash(new TextEncoder().encode(canonical).buffer);
}

/** Only documented validation/auth rejection proves a request was not admitted. */
export function isConfirmedUploadRejection(status: number, body?: unknown) {
  if ([400,401,403,404,409,413,415,422].includes(status)) return true;
  const detail = (body as {detail?: {accepted?: unknown; code?: unknown}} | null)?.detail;
  return status === 503 && detail?.accepted === false && detail?.code === 'sql_upload_dependency_unavailable';
}
