import { hasMappingDefinition } from './row-validation-state';
import { validationDigest } from './validation-context';
import type { DatabaseNode, DerivedSource, JoinConfig, MappingState, TableNode } from "@/features/sttm/types/sttm.types";
import {
  resolveSelectedSourceTables,
  resolveSelectedTargetTable,
} from "@/features/sttm/shared/sttm-selection-utils";

/** Entry kind written to the snapshot's `validation_history`. */
export const MAPPING_SQL_VALIDATION_KIND = "mapping_sql_validation";

/** One-shot sessionStorage hint: which tab the mapping page should open on. */
export const OPEN_MAPPING_TAB_STORAGE_KEY = "sttm:open-mapping-tab";

type ValidationSignatureInput = {
  projectId?: string | null;
  firmValues?: unknown;
  semanticContext?: unknown;
  sourceAttributeGroups?: unknown;
  targetAttributeGroup?: unknown;
  sourceQuerySql?: string;
  sourceQueryModifiers?: unknown;
  validationValuesSignature?: string | null;
  mappingSql?: string;
  mappingPreviewSql?: string;
  mappingSqlVariant?: string | null;
  compiledMappingSql?: string;
  compiledMappingPreviewSql?: string;
  compiledMappingContextHash?: string | null;
  pendingManualEditSnapshots?: Record<string, unknown>;
  sourceDatabases: DatabaseNode[];
  sources: TableNode[];
  targetDatabases: DatabaseNode[];
  targets: TableNode[];
  drivingTableId: string | null;
  derivedSources: DerivedSource[];
  relationships: JoinConfig[];
  mappings: MappingState[];
  sourceFilterSql: string;
  sourceGroupBySql: string;
  sourceOrderBySql: string;
};

/**
 * Fingerprint of everything that changes the generated SQL: Select Tables (sources,
 * CTEs, target, driving table, joins, filters) and Map · Transform · Validate (mapped
 * rows). A successful Compile & Validate stores it; any edit afterwards changes it,
 * which means the SQL must be validated again before publishing.
 *
 * It deliberately excludes the snapshot id so a validation survives page reloads.
 */
export function computeMappingValidationSignature(state: ValidationSignatureInput): string {
  const sources = resolveSelectedSourceTables(state)
    .map((table) => table.qualifiedName)
    .sort();
  const target = resolveSelectedTargetTable(state)?.qualifiedName ?? null;
  const derived = state.derivedSources
    .filter((source) => source.isSelected)
    .map((source) => ({ id: source.id, sql: source.sqlText ?? "" }))
    .sort((left, right) => left.id.localeCompare(right.id));
  const mappings = state.mappings
    .filter(hasMappingDefinition)
    .map((mapping) => ({
      targetColumn: mapping.targetColumn,
      targetSqlName: mapping.targetSqlName,
      attributeName: mapping.attributeName,
      nlRule: mapping.nlRule,
      targetType: mapping.targetType,
      sourceColumn: mapping.sourceColumn,
      sourceColumns: mapping.sourceColumns,
      mappingMode: mapping.mappingMode,
      constantValue: mapping.constantValue,
      expression: mapping.expression,
      rule: mapping.rule,
      sourceDependencies: mapping.sourceDependencies,
      valueBindingIds: mapping.valueBindingIds,
    }));
  return 'artifact-v2:' + validationDigest(
    JSON.stringify({
      projectId: state.projectId,
      sourceAttributeGroups: state.sourceAttributeGroups,
      targetAttributeGroup: state.targetAttributeGroup,
      sourceQuerySql: state.sourceQuerySql,
      sourceQueryModifiers: state.sourceQueryModifiers,
      contextValues: state.validationValuesSignature,
      mappingSql: state.mappingSql,
      mappingPreviewSql: state.mappingPreviewSql,
      mappingSqlVariant: state.mappingSqlVariant,
      compiledMappingSql: state.compiledMappingSql,
      compiledMappingPreviewSql: state.compiledMappingPreviewSql,
      compiledMappingContextHash: state.compiledMappingContextHash,
      firmValues: state.firmValues,
      semanticContext: state.semanticContext,
      sources,
      target,
      drivingTableId: state.drivingTableId,
      derived,
      relationships: state.relationships,
      mappings,
      filter: state.sourceFilterSql ?? "",
      groupBy: state.sourceGroupBySql ?? "",
      orderBy: state.sourceOrderBySql ?? "",
    }),
  );
}

export function currentMappingIsValidated(state: ValidationSignatureInput & {sqlValidatedSignature?: string | null}): boolean {
  return !Object.keys(state.pendingManualEditSnapshots ?? {}).length
    && Boolean(state.sqlValidatedSignature && state.sqlValidatedSignature === computeMappingValidationSignature(state));
}

export function readValidatedSignature(
  validationHistory: unknown,
): string | null {
  if (!Array.isArray(validationHistory)) return null;
  for (let index = validationHistory.length - 1; index >= 0; index -= 1) {
    const entry = validationHistory[index] as Record<string, unknown> | null;
    if (entry && entry.kind === MAPPING_SQL_VALIDATION_KIND && entry.valid !== false && typeof entry.signature === "string") {
      return entry.signature;
    }
  }
  return null;
}
