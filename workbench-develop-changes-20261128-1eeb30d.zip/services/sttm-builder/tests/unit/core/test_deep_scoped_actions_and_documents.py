from io import BytesIO
from types import SimpleNamespace
from zipfile import ZipFile

import openpyxl
from pypdf import PdfWriter

from app.agent_runs.attachment_facts import records
from app.agent_runs.attachments import parse_attachment
from app.agent_runtime.skill_backend import workbench_skill_backend
from app.agent_tools.capability_registry import CapabilityRegistry
from app.agent_tools.workbench_knowledge import (
    explicit_firm_value_copy,
    explicit_new_project_request,
    latest_note_plan_issues,
    requested_project_id,
    selected_mapping_name,
)


def test_explicit_destination_and_setup_do_not_confuse_source_project():
    request = ("Import the Firm Values QA_RATE and QA_TAG from the Source project 102 "
               "into QA Target project 301 now. Keep any existing values.")
    assert requested_project_id(request) == "301"
    assert explicit_firm_value_copy(request) == ("102", ["QA_RATE", "QA_TAG"], False)
    assert explicit_firm_value_copy("Can you explain how to import Firm Values?") is None
    setup = "Create a new mapping called QA Target in the existing project 301. Use the selections only."
    assert selected_mapping_name(setup) == "QA Target"
    assert not explicit_new_project_request("Create a new mapping in Test Map project.")
    assert explicit_new_project_request("Create a new isolated project for this mapping.")
    assert selected_mapping_name(setup + " Generate CTEs.") is None


def test_attachment_progress_counts_new_passages_once():
    registry = object.__new__(CapabilityRegistry)
    progress = []
    registry._budget = SimpleNamespace(record_progress=lambda: progress.append("new"))

    def result(*numbers):
        return SimpleNamespace(status="succeeded", data={"passages": [
            {"evidence_id": f"attachment:a#page {number}", "content_hash": "sha", "text": "a verified citation"}
            for number in numbers
        ]})

    assert registry._meaningful_progress("search_run_attachments", result(1, 2), {})
    assert not registry._meaningful_progress("search_run_attachments", result(2, 1), {})
    assert registry._meaningful_progress("search_run_attachments", result(2, 3), {})
    assert len(progress) == 2


def test_document_sections_and_ocr_citations(monkeypatch):
    doc = BytesIO()
    with ZipFile(doc, "w") as archive:
        archive.writestr("word/document.xml", '''
          <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>
            <w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Rules</w:t></w:r></w:p>
            <w:tbl><w:tr><w:tc><w:p><w:r><w:t>Preserve no-note rows</w:t></w:r></w:p></w:tc></w:tr></w:tbl>
          </w:body></w:document>''')
    ext, _, manifest, _ = parse_attachment("notes.docx", doc.getvalue())
    assert records({"extension": ext, "parsed_manifest": manifest})[1] == {
        "section": "Rules, table 1, row 1", "text": "Preserve no-note rows",
    }

    pdf = BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=144, height=144)
    writer.add_blank_page(width=144, height=144)
    writer.write(pdf)
    monkeypatch.setattr("app.agent_runs.attachments.recognize_pdf_page",
                        lambda _content, number, _timeout: "OCR from second page" if number == 2 else "")
    ext, _, manifest, _ = parse_attachment("scanned.pdf", pdf.getvalue())
    assert manifest["status"] == "partial"
    assert records({"extension": ext, "parsed_manifest": manifest}) == [
        {"section": "page 2", "text": "OCR from second page"},
    ]


def test_workbook_retains_formulas_and_sheet_citations():
    workbook = openpyxl.Workbook()
    workbook.active.title = "Mapping"
    workbook.active.append(["Target", "Rule"])
    workbook.active.append(["AMOUNT", "=A2/100"])
    workbook.create_sheet("Values").append(["Name", "Value"])
    stream = BytesIO()
    workbook.save(stream)

    ext, _, manifest, _ = parse_attachment("fixtures.xlsx", stream.getvalue())
    sheets = manifest["atomized"]["sheets"]
    assert [sheet["name"] for sheet in sheets] == ["Mapping", "Values"]
    assert sheets[0]["formula_cells"]["B2"] == {"formula": "=A2/100", "cached_value": None}
    assert records({"extension": ext, "parsed_manifest": manifest})[0]["section"] == "sheet Mapping row 2"


def test_statement_citations_respect_quoted_semicolons():
    ext, _, manifest, _ = parse_attachment("formula.sql", b"SELECT 'a;b' AS LABEL; SELECT 1 AS ID;")
    assert [record["text"] for record in records({"extension": ext, "parsed_manifest": manifest})] == [
        "SELECT 'a;b' AS LABEL;", "SELECT 1 AS ID;",
    ]


def test_packaged_skills_are_readable_but_immutable():
    backend = workbench_skill_backend()
    path = "/skills/workbench-documents/SKILL.md"
    assert "search_run_attachments" in backend.read(path).file_data["content"]
    assert backend.write(path, "unexpected").error
    assert backend.delete(path).error


def test_latest_note_is_checked_before_approval():
    prompt = "Use a latest-note CTE. Keep no-note rows. Break ties by greatest note ID."
    assert latest_note_plan_issues(prompt, {"derived_sources": [{"sql": "SELECT INCOME_ID FROM INCOME"}]})
    design = {
        "derived_sources": [{"sql": "SELECT NOTE_ID FROM NOTE QUALIFY ROW_NUMBER() OVER "
                                   "(PARTITION BY INCOME_ID ORDER BY CREATED_AT DESC, NOTE_ID DESC) = 1"}],
        "relationships": [{"left_table": "INCOME", "right_table": "LATEST_NOTE", "join_type": "LEFT"}],
    }
    assert latest_note_plan_issues(prompt, design) == []


def test_target_shortlist_uses_authorized_sources_without_preparing_evidence():
    from threading import RLock

    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._budget = None
    handler._domain_lock = RLock()
    handler._settings = SimpleNamespace()
    handler._projects = SimpleNamespace(find_target_mapping_designs=lambda _: [
        {"PROJECT_ID": "101", "STTM_ID": "201", "TARGET_TABLE": "DB.TGT.INCOME", "SOURCES": '[{"database":"DB","schema":"SRC","table":"INCOME"}]',
         "DRIVER": '{"database":"DB","schema":"SRC","table":"INCOME"}'},
        {"PROJECT_ID": "102", "STTM_ID": "202", "TARGET_TABLE": "DB.TGT.INCOME", "SOURCES": '[{"database":"DB","schema":"OTHER","table":"INCOME"}]'},
        {"PROJECT_ID": "103", "STTM_ID": "203", "TARGET_TABLE": 'DB.TGT."Income"',
         "SOURCES": ["DB.SRC.INCOME"]},
        {"PROJECT_ID": "104", "STTM_ID": "204", "TARGET_TABLE": "DB.TGT.INCOME", "SOURCES": '{invalid'},
    ])

    result = handler.find_saved_target_mappings({"authorized_schemas": ["DB.SRC"]}, "DB.TGT.INCOME")
    assert result.status == "succeeded"
    assert [design["sttm_id"] for design in result.data["designs"]] == ["201"]
    assert result.evidence_refs == ["saved_mapping:201"]


def test_exclusive_source_selection_rejects_expansion_before_evidence_reads():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_tools.workbench_knowledge import exclusive_source_scope

    handler = object.__new__(WorkbenchWorkflowHandlers)
    context = {
        "prompt": "Use only the selected source table and show a plan.",
        "authorized_source_scope": ["DB.SRC.INCOME"],
    }
    assert exclusive_source_scope(context) == {"DB.SRC.INCOME"}
    assert exclusive_source_scope({**context, "prompt": "Start with the selected source table."}) == set()

    result = handler.prepare_migration_evidence(
        context, source_tables=["DB.SRC.INCOME", "DB.SRC.NOTES"], target_table="DB.TGT.INCOME",
    )
    assert result.error_code == "exclusive_source_scope"
    assert result.data["selected_sources"] == ["DB.SRC.INCOME"]


def test_ranked_lookup_preserves_derived_relation_and_physical_input():
    from app.agent_tools.cte_join_bindings import resolve_passthrough_joins

    source = {
        "driving_source": "DB.SRC.INCOME",
        "supporting_sources": ["DB.SRC.NOTE"],
        "derived_sources": [{
            "name": "LATEST_NOTE",
            "sql": "SELECT INCOME_ID, NOTE_ID FROM DB.SRC.NOTE "
                   "QUALIFY ROW_NUMBER() OVER (PARTITION BY INCOME_ID "
                   "ORDER BY CREATED_TIME DESC NULLS LAST, NOTE_ID DESC) = 1",
        }],
    }
    join = {
        "left_table": "DB.SRC.INCOME", "right_table": "LATEST_NOTE", "join_type": "LEFT",
        "conditions": [{"left_column": "INCOME_ID", "right_column": "INCOME_ID"}],
    }
    assert resolve_passthrough_joins(source, [join]) == [join]
    resolved = resolve_passthrough_joins(source, [join], keep_derived=True)
    assert resolved == [{**join, "right_table": "DB.SRC.NOTE", "right_relation_override": "LATEST_NOTE"}]

    source["derived_sources"][0]["sql"] = "SELECT OTHER_ID AS INCOME_ID, NOTE_ID FROM DB.SRC.NOTE"
    assert resolve_passthrough_joins(source, [join], keep_derived=True) == [join]


def test_attachment_select_keeps_derived_binding_and_exact_target_names():
    from app.agent_tools.attachment_sql_plan import attachment_select_design

    sql = """
        WITH latest_note AS (
            SELECT INCOME_ID, NOTE_ID FROM DB.SRC.NOTE
            QUALIFY ROW_NUMBER() OVER (PARTITION BY INCOME_ID ORDER BY CREATED_TIME DESC, NOTE_ID DESC) = 1
        )
        SELECT i.CENTS / 100.0 AS AMOUNT, n.NOTE_ID
        FROM DB.SRC.INCOME i LEFT JOIN latest_note n ON i.INCOME_ID = n.INCOME_ID
    """
    tables = {"DB.SRC.INCOME", "DB.SRC.NOTE"}
    design = attachment_select_design(sql, ["AMOUNT", "NOTE_ID"], tables, set(), "attachment:fixture#statement 1")
    assert design["driving_source"] == "DB.SRC.INCOME"
    assert design["supporting_sources"] == ["DB.SRC.NOTE"]
    assert design["relationships"][0]["right_table"] == "LATEST_NOTE"
    assert design["mapping_evidence"][0]["expression"] == "DB.SRC.INCOME.CENTS / 100.0"
    assert design["mapping_evidence"][1]["source_columns"] == ["LATEST_NOTE.NOTE_ID"]
    assert attachment_select_design(sql, ["NOTE_ID"], tables, set(), "fixture") is None
    assert attachment_select_design(sql.replace("LEFT JOIN", "FULL JOIN"), ["AMOUNT", "NOTE_ID"], tables, set(), "fixture") is None


def test_source_reconciliation_queries_ranked_cte_instead_of_raw_lookup():
    from threading import RLock
    from unittest.mock import Mock

    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.schema.common import TableRef

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._settings = SimpleNamespace()
    handler._budget = None
    handler._domain_lock = RLock()
    handler._describe_table = Mock(return_value={"column_contracts": [{"name": "INCOME_ID", "type": "NUMBER"}]})
    handler._session = Mock()
    handler._session.sql.return_value.collect.return_value = [{
        "LEFT_ROW_COUNT": 3, "LEFT_UNIQUE_KEY_COUNT": 3, "RIGHT_ROW_COUNT": 2,
        "RIGHT_UNIQUE_KEY_COUNT": 2, "JOINED_ROW_COUNT": 3, "ORPHAN_ROW_COUNT": 1,
        "MATCHED_LEFT_KEY_COUNT": 2,
    }]
    tables = [TableRef(database="DB", schema="SRC", table=name) for name in ("INCOME", "NOTE")]
    sql = ("SELECT INCOME_ID FROM DB.SRC.NOTE QUALIFY ROW_NUMBER() OVER "
           "(PARTITION BY INCOME_ID ORDER BY CREATED_TIME DESC, NOTE_ID DESC) = 1")
    relationships, findings, metrics = handler._validate_source_relationships(
        state={}, source_tables=tables, reconcile=True, derived_queries={"ranked-note": sql},
        raw_relationships=[{
            "left_table": tables[0].model_dump(), "right_table": tables[1].model_dump(),
            "join_type": "LEFT", "right_relation_override": "ranked-note",
            "conditions": [{"left_column": "INCOME_ID", "right_column": "INCOME_ID", "operator": "="}],
        }],
    )
    assert f"LEFT JOIN ({sql}) AS R" in handler._session.sql.call_args.args[0]
    assert relationships[0].right_relation_override == "ranked-note"
    assert all(not item["blocking"] for item in findings)
    assert metrics["join_1"]["fanout_ratio"] == 1


def test_call_notes_build_ranked_join_from_verified_precedent_and_contracts():
    from app.agent_tools.attachment_sql_plan import ranked_note_design
    from app.core.sql_parser import parse_sql_document

    driver, notes = "DB.SRC.INCOME", "DB.SRC.NOTE"
    precedent = parse_sql_document(
        "SELECT i.TOTAL_AMOUNT_CENTS / 100.0 AS AMOUNT, n.NOTE_ID "
        "FROM DB.SRC.INCOME i INNER JOIN DB.SRC.NOTE n ON i.INCOME_ID = n.INCOME_ID"
    )
    facts = [{"quote": "Use the latest note with the greatest note ID for a tie. Keep rows with no note.",
              "evidence_id": "attachment:call#turn 1"},
             {"quote": "Divide cents by 100 and keep null amounts.", "evidence_id": "attachment:call#turn 2"}]
    columns = {
        driver: {"INCOME_ID": "NUMBER", "TOTAL_AMOUNT_CENTS": "VARCHAR"},
        notes: {"INCOME_ID": "NUMBER", "NOTE_ID": "NUMBER", "CREATED_TIME": "TIMESTAMP_NTZ"},
    }

    design = ranked_note_design(driver, columns, ["AMOUNT", "NOTE_ID"], precedent, facts)

    assert design["supporting_sources"] == [notes]
    assert design["relationships"][0]["join_type"] == "LEFT"
    assert 'ORDER BY "CREATED_TIME" DESC NULLS LAST, "NOTE_ID" DESC' in design["derived_sources"][0]["sql"]
    assert design["mapping_evidence"][1]["evidence_id"] == "attachment:call#turn 2"
    assert design["mapping_evidence"][1]["expression"].endswith(" / 100.0")
    columns[notes]["CREATED_AT"] = "TIMESTAMP_NTZ"
    assert ranked_note_design(driver, columns, ["AMOUNT", "NOTE_ID"], precedent, facts) is None
