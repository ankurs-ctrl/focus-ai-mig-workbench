FIR 2.0 cumulative hotfix for the 20260717-1730 client source release

Included fixes
- Project and mapping precedent-link storage and creation UI.
- Recommendation impressions are recorded in one batch instead of one Snowflake request per card.
- Background outcome telemetry no longer opens blocking global error dialogs.
- Duplicate global errors are shown once instead of being queued repeatedly.
- SQL Edit starts with the exact displayed SQL, not an empty INSERT buffer.
- SELECT preview edits retain the currently selected target table.
- SQL aliases resolve to their physical source table during parse and diff.
- The preprocessing-rule dialog reserves space for the docked AI Assistant.

Apply
1. Extract this ZIP over the already extracted 20260717-1730 source tree.
2. Apply only the new linking schema migration:
   .\scripts\bootstrap_sttm_metadata_infra.ps1 -EnvFile ".\infra\snowflake\env\client.env" -LinkingMigrationOnly
3. Rebuild and redeploy SPCS using the existing client deployment command.

Notes
- Do not run the full bootstrap again for this overlay.
- No semantic-agent specification or semantic-agent write procedure is included or changed.
- Existing FIR inferences, recommendations, mappings, and learnings must not be deleted.
