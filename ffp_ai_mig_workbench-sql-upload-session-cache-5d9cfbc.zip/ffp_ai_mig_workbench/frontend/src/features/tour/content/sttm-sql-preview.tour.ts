import type { TourDefinition } from "../types/tour.types";
import { TOUR_TARGETS, tourSelector } from "../constants/tour-targets";

export const sttmSqlPreviewTour: TourDefinition = {
  id: "sttm-sql-preview",
  label: "STTM — SQL Preview",
  description: "View, edit, validate, and copy the generated SQL from current mappings.",
  routes: ["/sttm/builder/new/mapping", "/sttm/builder/new/summary"],
  steps: [
    ...([
      ['sttm-edit-sql', 'Edit SQL', 'Modify the generated query, then compile, validate and synchronize it before continuing.', TOUR_TARGETS.sttmEditSql],
      ['sttm-compile-validate', 'Compile & Validate', 'Validate the current mappings and query with Snowflake. Review any errors before previewing.', TOUR_TARGETS.sttmCompileValidate],
      ['sttm-optimize-sql', 'Optimize SQL', 'Request an optimization suggestion. Review and approve any proposed change before using it.', TOUR_TARGETS.sttmOptimizeSql],
      ['sttm-run-preview', 'Run Preview', 'Preview the validated extraction query without loading the target table.', TOUR_TARGETS.sttmRunPreview],
    ] as const).map(([id, title, body, target]) => ({id, title, body, target: tourSelector(target), placement: 'bottom' as const, route: '/sttm/builder/new/mapping'})),
    {
      id: "sttm-sql-preview-intro",
      screen: "SQL Preview tab",
      title: "SQL Preview Tab",
      body: "The SQL Preview tab shows the complete SQL generated from the current mapping configuration, built in real time from your mappings, joins, filters, and transformation rules.",
      target: tourSelector(TOUR_TARGETS.sttmSqlPreviewPanel),
      placement: "top",
    },
    {
      id: "sttm-edit-sql",
      screen: "SQL Preview tab",
      title: "Edit SQL",
      body: "Modify the generated SQL query to meet specific business or technical requirements.",
      target: tourSelector(TOUR_TARGETS.sttmEditSql),
      placement: "bottom",
    },
    {
      id: "sttm-compile-validate",
      screen: "SQL Preview tab",
      title: "Compile & Validate",
      body: "Validates the SQL query against the defined source preparation, mappings, joins, and transformation rules. Any validation errors are highlighted for review and correction.",
      target: tourSelector(TOUR_TARGETS.sttmCompileValidate),
      placement: "bottom",
    },
    {
      id: "sttm-optimize-sql",
      screen: "SQL Preview tab",
      title: "Optimize SQL",
      body: "Optimizes the generated SQL query to improve performance and readability.",
      target: tourSelector(TOUR_TARGETS.sttmOptimizeSql),
      placement: "bottom",
    },
    {
      id: "sttm-run-preview",
      screen: "SQL Preview tab",
      title: "Run Preview",
      body: "After the SQL has been successfully validated, click Run Preview to navigate to the Data Preview screen and verify the mapping results before proceeding.",
      target: tourSelector(TOUR_TARGETS.sttmRunPreview),
      placement: "bottom",
    },
    {
      id: "sttm-copy-sql",
      screen: "SQL Preview tab",
      title: "Copy SQL",
      body: "Copies the complete generated SQL query to the clipboard.",
      target: tourSelector(TOUR_TARGETS.sttmCopySql),
      placement: "bottom",
    },
  ],
};
