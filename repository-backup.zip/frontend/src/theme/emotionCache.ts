import createCache from '@emotion/cache';

export function createEmotionCache() {
  return createCache({
    key: 'mui',
    prepend: true, // ✅ fixes hydration order
  });
}