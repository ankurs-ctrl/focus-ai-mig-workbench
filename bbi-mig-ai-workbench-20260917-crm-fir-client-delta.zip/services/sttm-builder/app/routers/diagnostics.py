from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request

from app.api.deps import get_conversation_memory_service
from app.auth.dependencies import get_current_principal
from app.auth.models import AppPersona
from app.core.conversation_memory import ConversationMemoryService
from app.core.performance import snapshot
from app.core.read_cache import cache_snapshot
from app.core.config import get_settings
from app.core.warehouse_routing import WarehouseWorkload, resolve_warehouse
from app.schema.contracts import ApiResponseEnvelope, build_response_envelope


router = APIRouter(prefix="/diagnostics", tags=["Diagnostics"])


@router.get("/readiness", response_model=ApiResponseEnvelope[dict])
def runtime_readiness(
    request: Request,
    memory: Annotated[
        ConversationMemoryService,
        Depends(get_conversation_memory_service),
    ],
):
    principal = get_current_principal(request)
    if principal.app_persona is not AppPersona.ADMIN:
        raise HTTPException(
            status_code=403,
            detail="Performance diagnostics require the admin persona",
        )
    settings = get_settings()
    data = {
        **memory.readiness(),
        "durable_context_caches": memory.prepared_cache_readiness(),
        "performance": snapshot(),
        "backend_read_cache": cache_snapshot(),
        "runtime_optimization": {
            "warehouse_routing": {
                workload.value: resolve_warehouse(settings, workload)
                for workload in WarehouseWorkload
            },
            "session_lease_pool": settings.snowflake_session_lease_pool_v1,
            "prepare_parallel": settings.prepare_parallel_v1,
            "learning_parallel": settings.learning_parallel_v1,
            "async_postsave": settings.autosave_postsave_async_v1,
            "automap_max_in_flight": settings.auto_mapping_proxy_max_in_flight,
            "automap_worker_concurrency": settings.auto_mapping_worker_max_concurrency,
        },
    }
    return build_response_envelope(
        operation="diagnostics.readiness",
        request=request,
        data=data,
    )
