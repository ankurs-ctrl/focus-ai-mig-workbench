"use client";

import { useAppSelector } from "@/store/hooks";
import { computeMappingValidationSignature, currentMappingIsValidated } from "./mapping-validation";
import { useProjectAttributes } from "@/features/sttm/mapping/use-project-attributes";
import type { SttmBuilderState } from "../store/sttm-builder-slice";

/** Client freshness check only. Publication independently validates on the server. */
export function useMappingValidationStatus() {
  const builder = useAppSelector((state) => state.sttmBuilder);
  const { isLoadingProjectAttributes, projectAttributesError } = useProjectAttributes(builder.activeProjectId);
  const input = (state: SttmBuilderState) => ({ ...state,
    projectId: state.activeProjectId, semanticContext: state.semanticContextItems });
  const isCurrent = (state: SttmBuilderState) => !isLoadingProjectAttributes && !projectAttributesError
    && currentMappingIsValidated(input(state));
  return {
    signature: computeMappingValidationSignature(input(builder)),
    isValidated: isCurrent(builder),
    isCurrent,
  };
}
