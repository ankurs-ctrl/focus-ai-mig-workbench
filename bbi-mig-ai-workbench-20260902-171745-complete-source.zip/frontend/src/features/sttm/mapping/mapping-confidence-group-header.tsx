'use client';

import { AiaBox, AiaChip, AiaTableCellPrimitive, AiaTableRowPrimitive } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import {
  KeyboardArrowDownRoundedIcon,
  KeyboardArrowRightRoundedIcon,
} from '@/utils/icons';

import {
  CONFIDENCE_GROUP_CONFIG,
  type ConfidenceGroupId,
} from './mapping-confidence-groups';

type MappingConfidenceGroupHeaderRowProps = {
  groupId: ConfidenceGroupId;
  rowCount: number;
  colSpan: number;
  expanded: boolean;
  onToggle: () => void;
};

export function MappingConfidenceGroupHeaderRow({
  groupId,
  rowCount,
  colSpan,
  expanded,
  onToggle,
}: MappingConfidenceGroupHeaderRowProps) {
  const config = CONFIDENCE_GROUP_CONFIG[groupId];
  const rowLabel = `${rowCount} row${rowCount === 1 ? '' : 's'}`;
  const ChevronIcon = expanded
    ? KeyboardArrowDownRoundedIcon
    : KeyboardArrowRightRoundedIcon;

  return (
    <AiaTableRowPrimitive>
      <AiaTableCellPrimitive
        colSpan={colSpan}
        onClick={onToggle}
        role="button"
        tabIndex={0}
        aria-expanded={expanded}
        aria-label={`${expanded ? 'Collapse' : 'Expand'} ${config.title}`}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            onToggle();
          }
        }}
        sx={{
          backgroundColor: config.backgroundColor,
          borderBottom: '1px solid #edf2f7',
          py: 1.1,
          px: 2,
          cursor: 'pointer',
          userSelect: 'none',
          '&:hover': {
            filter: 'brightness(0.985)',
          },
        }}
      >
        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1.25, minWidth: 0 }}>
          <ChevronIcon
            sx={{
              fontSize: 18,
              color: config.titleColor,
              flexShrink: 0,
            }}
            aria-hidden
          />
          <AiaBox
            sx={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              bgcolor: config.dotColor,
              flexShrink: 0,
            }}
          />
          <AiaText
            sx={{
              fontWeight: 800,
              fontSize: '0.72rem',
              letterSpacing: '0.06em',
              color: config.titleColor,
              textTransform: 'uppercase',
              flexShrink: 0,
            }}
          >
            {config.title}
          </AiaText>
          <AiaChip
            label={rowLabel}
            size="small"
            sx={{
              height: 22,
              bgcolor: config.badgeBackground,
              color: config.badgeColor,
              fontSize: '0.68rem',
              fontWeight: 600,
              borderRadius: '999px',
              '& .MuiChip-label': { px: 1.1 },
            }}
          />
          <AiaText
            sx={{
              color: '#94a3b8',
              fontSize: '0.72rem',
              fontWeight: 500,
              whiteSpace: 'nowrap',
            }}
          >
            {config.rangeLabel}
          </AiaText>
        </AiaBox>
      </AiaTableCellPrimitive>
    </AiaTableRowPrimitive>
  );
}
