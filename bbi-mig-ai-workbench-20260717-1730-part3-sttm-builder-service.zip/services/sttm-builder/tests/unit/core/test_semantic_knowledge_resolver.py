import json
from unittest.mock import MagicMock

from app.core.semantic_knowledge_resolver import SemanticKnowledgeResolver
from app.schema.common import TableRef


def test_relationships_are_resolved_for_all_tables_in_one_query() -> None:
    settings = MagicMock()
    settings.resolved_semantic_views_table = "REGISTRY.DB.LATEST_TABLE_REGISTRY_V"
    settings.qualify_metadata_object_name.return_value = "APP.META.TBL_SEMANTIC_VIEW_VERSIONS"
    session = MagicMock()
    query = MagicMock()
    query.collect.return_value = [
        {
            "FQN": "DB.CRM.CONTACT",
            "RELATIONSHIPS": json.dumps(
                [
                    {
                        "left_table": "DB.CRM.CONTACT",
                        "right_table": "DB.CRM.ADDRESS",
                        "column_mappings": [
                            {"left_column": "ID", "right_column": "CONTACT_ID"}
                        ],
                        "business_purpose": "Attach contact addresses",
                    }
                ]
            ),
            "ATTRIBUTES": None,
        },
        {"FQN": "DB.CRM.ADDRESS", "RELATIONSHIPS": None, "ATTRIBUTES": None},
    ]
    session.sql.return_value = query
    resolver = SemanticKnowledgeResolver(settings)

    result = resolver.relationship_payloads(
        session,
        [
            TableRef(database="DB", schema="CRM", table="CONTACT"),
            TableRef(database="DB", schema="CRM", table="ADDRESS"),
        ],
    )

    assert session.sql.call_count == 1
    assert result["DB.CRM.CONTACT"]["outgoing"][0]["table"] == "ADDRESS"
    assert result["DB.CRM.ADDRESS"]["incoming"][0]["table"] == "CONTACT"
    assert (
        result["DB.CRM.CONTACT"]["outgoing"][0]["business_meaning"]
        == "Attach contact addresses"
    )

