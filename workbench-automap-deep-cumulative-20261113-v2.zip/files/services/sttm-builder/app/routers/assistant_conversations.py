from __future__ import annotations

import logging
import json
from typing import Annotated, Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from app.agent_runs.document_qa import answer_uploaded_document
from app.agent_runs.recovery import can_resume
from app.agent_runs.models import (
    AgentActor,
    AssistantIntent,
    ExecutionPath,
    RunAnswerRequest,
    RunCancelRequest,
    RunCreateRequest,
    RunResumeRequest,
    RunStatus,
    TERMINAL_RUN_STATUSES,
)
from app.agent_runs.repository import SnowflakeAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.api.deps import get_conversation_service, get_project_service, get_snowflake_client
from app.assistant_conversations import (
    AssistantConversation,
    AssistantTurn,
    ConversationCreateRequest,
    ConversationUpdateRequest,
    ConversationDetail,
    ConversationRunSummary,
    ConversationTurnRequest,
    ConversationTurnResponse,
    LegacyConversationImportRequest,
    SnowflakeAssistantConversationRepository,
    build_conversational_fast_answer, capability_answer, intent_from_classification, resolves_deterministically,
    is_explicit_migration_request, is_greeting_or_capability_question,
    resolve_assistant_intent, is_read_only_document_question, is_read_only_sql_followup,
)
from app.auth.dependencies import get_current_principal
from app.core.config import Settings, get_settings
from app.core.conversation import ConversationService
from app.core.project_service import ProjectService
from app.core.snowflake import SnowflakeClient
from app.routers.conversation import _apply_conversation_preflight
from app.schema.contracts import ApiResponseEnvelope, build_response_envelope
from app.schema.conversation import (
    ConversationContext,
    ConversationOperation,
    ConversationRequestData,
    ConversationRequestEnvelope,
)


router = APIRouter(prefix="/assistant-conversations", tags=["Assistant Conversations"])
logger = logging.getLogger(__name__)


def _identity(request: Request) -> tuple[str, str, AgentActor]:
    principal = get_current_principal(request)
    user_id = str(principal.user_id)
    tenant_id = str(getattr(principal, "tenant_id", None) or "default")
    return user_id, tenant_id, AgentActor(
        app_user_id=user_id,
        snowflake_username=principal.snowflake_user,
        tenant_id=tenant_id,
        effective_role=principal.snowflake_role or principal.app_persona.value,
        actor_type="user",
        delegation_ref=principal.oauth_session_id,
    )


def _repositories(client: SnowflakeClient, settings: Settings):
    conversations = SnowflakeAssistantConversationRepository(
        client.session, database=settings.snowflake_database, schema=settings.snowflake_schema
    )
    runs = SnowflakeAgentRunRepository(
        client.session, database=settings.snowflake_database, schema=settings.snowflake_schema
    )
    return conversations, runs


def _require_conversation(repository: SnowflakeAssistantConversationRepository, conversation_id: str, user_id: str, tenant_id: str) -> AssistantConversation:
    conversation = repository.get(conversation_id, user_id=user_id, tenant_id=tenant_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Assistant conversation was not found")
    return conversation


def _diagnostic_message(run: Any, events: list[Any]) -> str:
    failure = next((event for event in reversed(events) if event.event_type == "run.failed"), None)
    code = run.error_code or (failure.data.get("error_code") if failure else None) or "unknown_failure"
    detail = run.safe_error or (failure.safe_summary if failure else None) or "The run ended without a durable failure explanation."
    resumable = can_resume(run)
    next_step = (
        "You can say “continue” to resume this exact run from its checkpoint."
        if resumable else
        "This failure requires correction before recovery; retrying it unchanged will not resolve it."
    )
    return f"The run stopped with `{code}`. {detail}\n\n{next_step}"


_PRIOR_EVIDENCE_EVENT_TYPES = frozenset({"tool.completed", "tool.reused", "workspace.synced", "run.ready_for_review"})


def _prior_run_evidence(events: list[Any], *, limit: int = 16) -> list[dict[str, Any]]:
    """Carry sanitized durable evidence into a follow-up without replaying tools."""
    evidence: list[dict[str, Any]] = []
    verified_tables: set[str] = set()

    def collect_tables(value: Any, key: str = "") -> None:
        if isinstance(value, dict):
            for child_key, child in value.items():
                collect_tables(child, str(child_key).casefold())
        elif isinstance(value, list):
            for child in value:
                collect_tables(child, key)
        elif key in {"table", "table_fqn", "source_table", "target_table", "candidates"}:
            candidate = str(value).strip('"').upper()
            if candidate.count(".") == 2:
                verified_tables.add(candidate)

    for event in events:
        if event.event_type not in _PRIOR_EVIDENCE_EVENT_TYPES:
            continue
        data = dict(event.data or {})
        collect_tables(data.get("result_preview"))
        evidence.append({
            "event_type": event.event_type,
            "capability": data.get("label") or data.get("tool") or event.safe_summary,
            "sanitized_input": data.get("sanitized_input") or {},
            "result_preview": data.get("result_preview"),
            "evidence_refs": list(event.evidence_refs or []),
            "artifact_refs": list(event.artifact_refs or []),
        })
    retained = evidence[-limit:]
    if verified_tables:
        retained.append({
            "event_type": "verified.catalog_scope",
            "capability": "Server-verified catalog scope from the preceding run",
            "result_preview": {"candidates": sorted(verified_tables)},
            "sanitized_input": {}, "evidence_refs": [], "artifact_refs": [],
        })
    return retained


@router.post("", status_code=201, response_model=ApiResponseEnvelope[AssistantConversation])
def create_conversation(request: Request, body: ConversationCreateRequest,
                        client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                        settings: Annotated[Settings, Depends(get_settings)]):
    user_id, tenant_id, _ = _identity(request)
    repository, _ = _repositories(client, settings)
    conversation = repository.create(body, user_id=user_id, tenant_id=tenant_id)
    return build_response_envelope(operation="assistant_conversations.create", request=request, data=conversation)


@router.get("", response_model=ApiResponseEnvelope[list[AssistantConversation]])
def list_conversations(request: Request,
                       client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                       settings: Annotated[Settings, Depends(get_settings)],
                       limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0),
                       project_id: str | None = None, sttm_id: str | None = None):
    user_id, tenant_id, _ = _identity(request)
    repository, _ = _repositories(client, settings)
    data = repository.list(user_id=user_id, tenant_id=tenant_id, limit=limit, offset=offset,
                           project_id=project_id, sttm_id=sttm_id)
    return build_response_envelope(operation="assistant_conversations.list", request=request, data=data)


@router.post("/import", response_model=ApiResponseEnvelope[dict[str, Any]])
def import_legacy_quick_history(request: Request, body: LegacyConversationImportRequest,
                                client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                                settings: Annotated[Settings, Depends(get_settings)]):
    """One-time idempotent browser-history upload; local deletion is never requested."""
    user_id, tenant_id, _ = _identity(request)
    repository, _ = _repositories(client, settings)
    imported = 0
    for legacy in body.sessions:
        marker = f"legacy:{body.browser_migration_id}:{legacy.legacy_id}"
        # A marker turn makes retries idempotent without another migration table.
        if repository.has_idempotency_key(marker):
            continue
        conversation = repository.create(ConversationCreateRequest(
            mode="quick", title=legacy.title, project_id=legacy.project_id, sttm_id=legacy.sttm_id
        ), user_id=user_id, tenant_id=tenant_id)
        sequence = 1
        marker_written = False
        for item in legacy.messages:
            role = str(item.get("role") or "").lower()
            message = str(item.get("content") or "").strip()
            if role not in {"user", "assistant"} or not message:
                continue
            repository.append_turn(AssistantTurn(
                turn_id=f"turn_{uuid4().hex}", conversation_id=conversation.conversation_id,
                sequence=sequence, role=role, mode="quick", message_kind="imported",
                message=message, intent=AssistantIntent.CONVERSATIONAL_QA,
                idempotency_key=(marker if not marker_written else None), metadata={"legacy_id": legacy.legacy_id},
            ))
            marker_written = True
            sequence += 1
        imported += 1
    return build_response_envelope(
        operation="assistant_conversations.import", request=request,
        data={"confirmed": True, "imported": imported, "browser_migration_id": body.browser_migration_id},
    )


@router.get("/{conversation_id}", response_model=ApiResponseEnvelope[ConversationDetail])
def get_conversation(request: Request, conversation_id: str,
                     client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                     settings: Annotated[Settings, Depends(get_settings)]):
    user_id, tenant_id, _ = _identity(request)
    conversations, runs = _repositories(client, settings)
    conversation = _require_conversation(conversations, conversation_id, user_id, tenant_id)
    restore_rows = runs.list_conversation_restore_rows(conversation_id, user_id, tenant_id)
    linked_runs = [
        ConversationRunSummary(
            run_id=row["RUN_ID"], status=row["STATUS"], turn_id=row.get("TURN_ID"),
            intent=row.get("INTENT") or AssistantIntent.NEW_MIGRATION_TASK,
            resume_attempt=int(row.get("RESUME_ATTEMPT") or 0),
            run_revision=int(row.get("RUN_REVISION") or 0),
            error_code=row.get("ERROR_CODE"), safe_error=row.get("SAFE_ERROR"),
            prompt=row.get("PROMPT") or "", created_at=row["CREATED_AT"], updated_at=row["UPDATED_AT"],
        )
        for row in restore_rows
    ]
    attachment_ids: list[str] = []
    for row in reversed(restore_rows):
        raw_ids = row.get("ATTACHMENT_IDS") or []
        if isinstance(raw_ids, str):
            try:
                raw_ids = json.loads(raw_ids)
            except ValueError:
                raw_ids = []
        if isinstance(raw_ids, list) and raw_ids:
            attachment_ids = [str(value) for value in raw_ids[:20]]
            break
    attachments: list[dict[str, str]] = []
    for attachment_id in attachment_ids:
        rows = client.session.sql(
            """SELECT ATTACHMENT_ID, FILENAME FROM TBL_AGENT_ATTACHMENTS
            WHERE ATTACHMENT_ID = ? AND OWNER_USER_ID = ? AND TENANT_ID = ? LIMIT 1""",
            [attachment_id, user_id, tenant_id],
        ).collect()
        if rows:
            item = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
            attachments.append({"id": str(item["ATTACHMENT_ID"]), "name": str(item["FILENAME"])})
    latest = linked_runs[-1] if linked_runs else None
    events = runs.list_events(latest.run_id) if latest else []
    plan_event = next((event for event in reversed(events) if event.event_type == "plan.updated" and event.turn_id == latest.turn_id), None) if latest else None
    turns = conversations.list_turns(conversation_id)
    # The Deep-run backfill predates normalized turns. Reconstruct only the
    # compact user/error transcript for those conversations at read time; do
    # not send their very large workspace/run snapshots to the browser.
    if not turns and linked_runs:
        sequence = 1
        for item in linked_runs:
            turns.append(AssistantTurn(
                turn_id=item.turn_id or f"legacy-user-{item.run_id}",
                conversation_id=conversation_id,
                sequence=sequence,
                role="user",
                mode=conversation.mode,
                message_kind="legacy_run_prompt",
                message=item.prompt,
                intent=item.intent,
                run_id=item.run_id,
            ))
            sequence += 1
            if item.safe_error:
                turns.append(AssistantTurn(
                    turn_id=f"legacy-error-{item.run_id}",
                    conversation_id=conversation_id,
                    sequence=sequence,
                    role="assistant",
                    mode=conversation.mode,
                    message_kind="legacy_run_error",
                    message=item.safe_error,
                    intent=item.intent,
                    run_id=item.run_id,
                ))
                sequence += 1
    data = ConversationDetail(
        conversation=conversation,
        turns=turns,
        linked_runs=linked_runs,
        resumable=bool(latest and can_resume(latest)),
        current_plan=plan_event.data if plan_event else None,
        attachments=attachments,
    )
    return build_response_envelope(operation="assistant_conversations.get", request=request, data=data)


@router.patch("/{conversation_id}", response_model=ApiResponseEnvelope[AssistantConversation])
def update_conversation(request: Request, conversation_id: str, body: ConversationUpdateRequest,
                        client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                        settings: Annotated[Settings, Depends(get_settings)],
                        project_service: Annotated[ProjectService, Depends(get_project_service)]):
    """Rename, pin, or explicitly assign one owned conversation to a project."""
    user_id, tenant_id, _ = _identity(request)
    conversations, _ = _repositories(client, settings)
    if "project_id" in body.model_fields_set and body.project_id:
        if project_service.get_project(body.project_id) is None:
            raise HTTPException(status_code=404, detail="Project was not found")
    try:
        updated = conversations.update_metadata(conversation_id, body, user_id=user_id, tenant_id=tenant_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if updated is None:
        raise HTTPException(status_code=404, detail="Assistant conversation was not found")
    return build_response_envelope(operation="assistant_conversations.update", request=request, data=updated)


@router.delete("/{conversation_id}", response_model=ApiResponseEnvelope[dict[str, Any]])
def delete_conversation(request: Request, conversation_id: str,
                        client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                        settings: Annotated[Settings, Depends(get_settings)]):
    """Remove a conversation from History while retaining its audit records."""
    user_id, tenant_id, _ = _identity(request)
    conversations, _ = _repositories(client, settings)
    _require_conversation(conversations, conversation_id, user_id, tenant_id)
    conversations.archive(conversation_id, user_id=user_id, tenant_id=tenant_id)
    return build_response_envelope(
        operation="assistant_conversations.delete", request=request,
        data={"conversation_id": conversation_id, "deleted": True, "recoverable": True},
    )


@router.post("/{conversation_id}/turns", status_code=202, response_model=ApiResponseEnvelope[ConversationTurnResponse])
def submit_turn(request: Request, conversation_id: str, body: ConversationTurnRequest,
                client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
                settings: Annotated[Settings, Depends(get_settings)],
                quick_service: Annotated[ConversationService, Depends(get_conversation_service)]):
    if not settings.assistant_intent_routing_v1:
        raise HTTPException(status_code=503, detail="Assistant intent routing is not enabled")
    user_id, tenant_id, actor = _identity(request)
    conversations, run_repository = _repositories(client, settings)
    conversation = _require_conversation(conversations, conversation_id, user_id, tenant_id)
    if body.model_name and body.model_name not in {
        settings.migration_agent_model_light,
        settings.migration_agent_model_medium,
        settings.migration_agent_model_high,
    }:
        raise HTTPException(status_code=400, detail="Selected model is not configured for this deployment")
    existing = conversations.find_turn_by_idempotency(conversation_id, body.idempotency_key)
    if existing:
        existing_runs = run_repository.list_runs_for_conversation(conversation_id, user_id, tenant_id)
        existing_run = next((item for item in existing_runs if item.run_id == existing.run_id), None)
        data = ConversationTurnResponse(
            conversation_id=conversation_id, turn_id=existing.turn_id, intent=existing.intent,
            execution_path=ExecutionPath(existing.metadata.get("execution_path") or "fast_path"),
            message=existing.metadata.get("response"), question=existing.metadata.get("question"), run=existing_run,
        )
        return build_response_envelope(operation="assistant_conversations.turns.create", request=request, data=data)

    latest = run_repository.get_latest_run_for_conversation(conversation_id, user_id, tenant_id)
    intent = resolve_assistant_intent(
        body.message, latest_run=latest, mode=conversation.mode
    )
    capability_question = is_greeting_or_capability_question(body.message)
    explicit_task = is_explicit_migration_request(body.message)
    intent_metadata: dict[str, object] = {"intent_source": "rules"}
    # Free text the deterministic rules cannot place is classified by the
    # light model; any failure or low confidence keeps the rule-based intent.
    if not body.attachment_ids and not resolves_deterministically(body.message, intent, latest_run=latest):
        from app.assistant_intent_classifier import classify_message

        classified = classify_message(
            client.session, settings, body.message, has_run=latest is not None,
            awaiting=bool(latest and latest.status.value in {"AWAITING_INPUT", "AWAITING_CONFIRMATION"}),
        )
        if classified is not None:
            intent, capability_question, explicit_task = intent_from_classification(
                classified.label, latest_run=latest, fallback=intent)
            intent_metadata = {"intent_source": "model", "intent_label": classified.label,
                               "intent_confidence": classified.confidence, "intent_latency_ms": classified.latency_ms}
    deep_mode = str(getattr(conversation.mode, "value", conversation.mode)) == "deep"
    # Greetings and "what can you do" have a complete local answer; starting a
    # durable supervisor run for them only adds queue, login, and model latency.
    deep_capability_answer = (
        deep_mode
        and settings.assistant_local_capability_answers
        and not body.attachment_ids
        and intent is AssistantIntent.CONVERSATIONAL_QA
        and capability_question
    )
    deep_read_only_question = deep_mode and intent is AssistantIntent.CONVERSATIONAL_QA and not deep_capability_answer
    # Unfamiliar Deep phrasing is delegated to the supervisor, but it is not an
    # explicit migration request: the host must not force a governed migration
    # checkpoint unless the supervisor itself enters the migration workflow.
    deep_open_request = (
        deep_mode
        and intent is AssistantIntent.NEW_MIGRATION_TASK
        and not explicit_task
        and not is_read_only_sql_followup(body.message, latest_run=latest)
    )
    document_question = not deep_mode and is_read_only_document_question(
        body.message, has_attachments=bool(body.attachment_ids)
    )
    if document_question:
        intent = AssistantIntent.CONVERSATIONAL_QA
    elif deep_read_only_question:
        # Every ordinary Deep turn belongs to the same supervisor, including
        # explanations and attachment questions. It decides whether tools are
        # needed after writing its own first response.
        intent = AssistantIntent.NEW_MIGRATION_TASK
    document_answer = None
    response_question = None
    if document_question:
        try:
            document_answer, response_question = answer_uploaded_document(body.message, body.attachment_ids, client, settings, actor)
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Deep attachment question failed")
            raise HTTPException(status_code=503, detail="The uploaded document could not be answered right now; retry this question") from exc
    turn_id = f"turn_{uuid4().hex}"
    user_turn = AssistantTurn(
        turn_id=turn_id, conversation_id=conversation_id,
        sequence=conversations.next_sequence(conversation_id), role="user", mode=conversation.mode,
        message_kind="message", message=body.message, intent=intent,
        idempotency_key=body.idempotency_key,
    )
    conversations.append_turn(user_turn)
    from app.agent_runs.review_apply import make_draft_writer
    service = AgentRunService(run_repository, settings=settings,
                              draft_writer=make_draft_writer(client.session, settings))
    execution_path = ExecutionPath.FAST_PATH
    response_message: str | None = None
    run = None

    if intent is AssistantIntent.RUN_DIAGNOSTIC:
        if latest is None:
            response_message = "There is no earlier Deep run in this conversation to diagnose."
        else:
            response_message = _diagnostic_message(latest, run_repository.list_events(latest.run_id))
    elif intent is AssistantIntent.CONTINUE_RUN:
        if not settings.migration_agent_true_resume_v1:
            raise HTTPException(status_code=503, detail="Durable run resume is not enabled")
        if latest is None:
            raise HTTPException(status_code=409, detail="There is no run in this conversation to resume")
        run = service.resume(latest.run_id, RunResumeRequest(
            idempotency_key=body.idempotency_key, expected_revision=latest.run_revision
        ), actor)
        # The checkpoint and run identity remain unchanged, but newly emitted
        # activity belongs to this explicit continuation turn. Without this
        # rebind the browser correctly rejects the events as stale and shows
        # only the previously known plan.
        run.request.turn_id = turn_id
        run = run_repository.save_run(run)
        execution_path = ExecutionPath.RESUME
    elif intent is AssistantIntent.CANCEL_RUN:
        if latest is None:
            response_message = "There is no active run in this conversation to cancel."
        else:
            run = service.cancel(latest.run_id, RunCancelRequest(reason=body.message), actor)
            execution_path = ExecutionPath.CONTROL
    elif intent is AssistantIntent.ANSWER_INTERRUPT:
        if latest is None:
            raise HTTPException(status_code=409, detail="There is no interrupted run to answer")
        item = next((item for item in reversed(run_repository.list_review_items(latest.run_id)) if item.status.value == "OPEN"), None)
        if item is None:
            raise HTTPException(status_code=409, detail="The run is not awaiting an answer")
        run = service.answer(latest.run_id, RunAnswerRequest(
            review_item_id=item.review_item_id, answer=body.message, idempotency_key=body.idempotency_key,
            interrupt_id=item.interrupt_id, action_digest=item.action_digest, artifact_revision=item.artifact_revision,
        ), actor)
        run.request.turn_id = turn_id
        run = run_repository.save_run(run)
        execution_path = ExecutionPath.RESUME
    elif intent is AssistantIntent.NEW_MIGRATION_TASK:
        if not settings.migration_agent_enabled or not get_current_principal(request).permissions.can_edit:
            raise HTTPException(status_code=403, detail="Deep draft execution is disabled or not authorized")
        # Newest turns, oldest first; the last one is this user turn.
        recent = conversations.list_recent_turns(conversation_id, limit=30)
        page_context = dict(body.page_context)
        if latest is not None:
            prior_evidence = _prior_run_evidence(
                run_repository.list_events_by_type(latest.run_id, _PRIOR_EVIDENCE_EVENT_TYPES)
            )
            page_context["prior_run_evidence"] = prior_evidence
            # This server-owned copy may be used to restore the extra SQL
            # allow-list. The similarly named client field is presentation
            # context only and is never trusted for authorization.
            page_context["trusted_prior_run_evidence"] = prior_evidence
            page_context["prior_run"] = {
                "run_id": latest.run_id,
                "status": latest.status.value,
                "current_sttm_id": latest.current_sttm_id,
                "current_mapping_name": latest.current_mapping_name,
            }
        else:
            page_context["trusted_prior_run_evidence"] = []
        page_context["continuation_kind"] = (
            "READ_ONLY_QA" if deep_read_only_question else
            "READ_ONLY_SQL" if is_read_only_sql_followup(body.message, latest_run=latest) else
            "OPEN_REQUEST" if deep_open_request else ""
        )
        # A message after a finished run is a follow-up: the new run is its
        # child, so it can edit that run's drafts in place instead of
        # rebuilding every target.
        follow_up_parent = latest if (
            latest is not None and latest.status in TERMINAL_RUN_STATUSES
            and latest.status not in {RunStatus.FAILED, RunStatus.CANCELLED, RunStatus.EXPIRED}
            and latest.mapping_manifest
        ) else None
        if follow_up_parent is not None:
            page_context["parent_mappings"] = [
                {"mapping_key": item.get("mapping_key"), "target_table": item.get("target_table"),
                 "mapping_name": item.get("mapping_name"), "sttm_id": item.get("sttm_id")}
                for item in follow_up_parent.mapping_manifest
            ]
        run = service.create_run(RunCreateRequest(
            prompt=body.message, effort=body.effort, model_name=body.model_name, run_mode=body.run_mode,
            conversation_id=conversation_id, turn_id=turn_id,
            conversation_history=[{"role": item.role, "content": item.message} for item in recent[:-1] if item.role in {"user", "assistant"}],
            page_context=page_context, authorized_schemas=body.authorized_schemas,
            project_id=body.project_id or conversation.project_id
            or (follow_up_parent.project_id if follow_up_parent else None), source_scope=body.source_scope,
            target_scope=body.target_scope, attachment_ids=body.attachment_ids,
            requested_mappings=body.requested_mappings, idempotency_key=body.idempotency_key,
            intent=intent, parent_run_id=follow_up_parent.run_id if follow_up_parent else None,
        ), actor)
        execution_path = ExecutionPath.NEW_RUN
    else:
        response_message = document_answer or (capability_answer() if capability_question else None) \
            or build_conversational_fast_answer(body.message)
        if response_message is None:
            envelope = ConversationRequestEnvelope(
                request_id=body.idempotency_key, operation=ConversationOperation.ASK,
                # A durable assistant conversation ID is logical, not a Cortex
                # physical thread ID. Passing it as thread_id causes every first
                # turn to make a doomed remote continuation call before retrying.
                context=ConversationContext(logical_conversation_id=conversation_id),
                data=ConversationRequestData(message=body.message),
            )
            normalized, decision = _apply_conversation_preflight(request, envelope)
            quick_result = quick_service.invoke(normalized, governance_decision=decision)
            response_message = getattr(getattr(quick_result, "data", None), "message", None)

    user_turn.metadata.update({"execution_path": execution_path.value, "response": response_message,
                               "question": response_question, **intent_metadata})
    user_turn.run_id = run.run_id if run else None
    conversations.append_turn(user_turn)
    if response_message:
        conversations.append_turn(AssistantTurn(
            turn_id=f"turn_{uuid4().hex}", conversation_id=conversation_id,
            sequence=conversations.next_sequence(conversation_id), role="assistant", mode=conversation.mode,
            message_kind="final", message=response_message, intent=intent,
            run_id=run.run_id if run else None, metadata={"question": response_question} if response_question else {},
        ))
    data = ConversationTurnResponse(
        conversation_id=conversation_id, turn_id=turn_id, intent=intent,
        execution_path=execution_path, message=response_message, question=response_question, run=run,
        resumable=bool(run and can_resume(run)),
    )
    return build_response_envelope(operation="assistant_conversations.turns.create", request=request, data=data)
