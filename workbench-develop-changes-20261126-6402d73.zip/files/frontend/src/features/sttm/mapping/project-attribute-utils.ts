import type { ProjectAttributeRecord } from '@/services/projectService';

export const STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT = 'sttm:project-attributes-changed';

const FIRM_VALUE_EDIT_STORAGE_KEY = 'sttm-firm-value-edits';

export type FirmValueEditNote = {
  projectId: string;
  previousName: string;
  nextName: string;
};

export function notifyProjectAttributesChanged(projectId: string) {
  if (typeof window === 'undefined') {
    return;
  }
  window.dispatchEvent(
    new CustomEvent(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, {
      detail: { projectId },
    }),
  );
}

export function rememberFirmValueEdit(note: FirmValueEditNote) {
  if (typeof window === 'undefined') {
    return;
  }
  const previousName = note.previousName.trim();
  const nextName = note.nextName.trim();
  if (!previousName || !nextName) {
    return;
  }
  const notes = readFirmValueEdits().filter(
    (item) =>
      item.projectId !== note.projectId
      || item.previousName.trim().toUpperCase() !== previousName.toUpperCase(),
  );
  notes.push({ projectId: note.projectId, previousName, nextName });
  window.sessionStorage.setItem(
    FIRM_VALUE_EDIT_STORAGE_KEY,
    JSON.stringify(notes.slice(-50)),
  );
}

export function readFirmValueEdits(projectId?: string): FirmValueEditNote[] {
  if (typeof window === 'undefined') {
    return [];
  }
  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(FIRM_VALUE_EDIT_STORAGE_KEY) || '[]');
    if (!Array.isArray(parsed)) {
      return [];
    }
    return parsed.filter((item): item is FirmValueEditNote => {
      if (!item || typeof item !== 'object') {
        return false;
      }
      const note = item as FirmValueEditNote;
      return Boolean(
        note.projectId
        && note.previousName
        && note.nextName
        && (!projectId || note.projectId === projectId),
      );
    });
  } catch {
    return [];
  }
}

export function resolveMappedFirmValue(
  attributeName: string,
  attributes: ProjectAttributeRecord[],
  notes: FirmValueEditNote[],
): ProjectAttributeRecord | null {
  const byName = new Map(
    attributes.map((attribute) => [attribute.attribute_name.trim().toUpperCase(), attribute]),
  );
  let current = attributeName.trim();
  const seen = new Set<string>();
  while (current && !seen.has(current.toUpperCase())) {
    seen.add(current.toUpperCase());
    const live = byName.get(current.toUpperCase());
    if (live) {
      return live;
    }
    const note = notes.find((item) => item.previousName.trim().toUpperCase() === current.toUpperCase());
    if (!note) {
      return null;
    }
    current = note.nextName.trim();
  }
  return byName.get(current.toUpperCase()) ?? null;
}

function readField(
  raw: Record<string, unknown>,
  keys: string[],
): string {
  for (const key of keys) {
    const value = raw[key];
    if (value != null && String(value).trim()) {
      return String(value).trim();
    }
  }
  return '';
}

export function normalizeProjectAttributeRecord(
  raw: unknown,
): ProjectAttributeRecord | null {
  if (!raw || typeof raw !== 'object') {
    return null;
  }

  const record = raw as Record<string, unknown>;
  const attribute_name = readField(record, [
    'attribute_name',
    'ATTRIBUTE_NAME',
    'attributeName',
  ]);
  if (!attribute_name) {
    return null;
  }

  const status = readField(record, ['status', 'STATUS']) || 'ACTIVE';
  if (status.toUpperCase() === 'INACTIVE') {
    return null;
  }

  return {
    attribute_id: readField(record, ['attribute_id', 'ATTRIBUTE_ID', 'attributeId']),
    project_id: readField(record, ['project_id', 'PROJECT_ID', 'projectId']),
    project_name: readField(record, ['project_name', 'PROJECT_NAME', 'projectName']) || null,
    attribute_name,
    attribute_type: readField(record, ['attribute_type', 'ATTRIBUTE_TYPE', 'attributeType']) || 'VARCHAR',
    attribute_value: readField(record, ['attribute_value', 'ATTRIBUTE_VALUE', 'attributeValue']),
    source_project_id:
      readField(record, ['source_project_id', 'SOURCE_PROJECT_ID', 'sourceProjectId']) || null,
    source_project_name:
      readField(record, ['source_project_name', 'SOURCE_PROJECT_NAME', 'sourceProjectName']) || null,
    source_attribute_id:
      readField(record, ['source_attribute_id', 'SOURCE_ATTRIBUTE_ID', 'sourceAttributeId']) || null,
    status,
    created_by: readField(record, ['created_by', 'CREATED_BY', 'createdBy']) || null,
    updated_by: readField(record, ['updated_by', 'UPDATED_BY', 'updatedBy']) || null,
    created_at: readField(record, ['created_at', 'CREATED_AT', 'createdAt']) || null,
    updated_at: readField(record, ['updated_at', 'UPDATED_AT', 'updatedAt']) || null,
  };
}

export function belongsToProject(
  attribute: Pick<ProjectAttributeRecord, 'project_id'>,
  projectId: string | null | undefined,
): boolean {
  const normalizedProjectId = projectId?.trim().toLowerCase();
  const attributeProjectId = attribute.project_id?.trim().toLowerCase();
  if (!normalizedProjectId || !attributeProjectId) {
    return false;
  }
  return attributeProjectId === normalizedProjectId;
}

export function filterAttributesForProject(
  attributes: ProjectAttributeRecord[],
  projectId: string | null | undefined,
): ProjectAttributeRecord[] {
  const normalizedProjectId = projectId?.trim();
  if (!normalizedProjectId) {
    return [];
  }

  return attributes.filter((attribute) => belongsToProject(attribute, normalizedProjectId));
}

export function normalizeProjectAttributeRecords(
  payload: unknown,
  projectId?: string | null,
): ProjectAttributeRecord[] {
  const rows = Array.isArray(payload)
    ? payload
    : payload && typeof payload === 'object' && Array.isArray((payload as { items?: unknown[] }).items)
      ? (payload as { items: unknown[] }).items
      : [];

  const normalized = rows
    .map((row) => normalizeProjectAttributeRecord(row))
    .filter((row): row is ProjectAttributeRecord => Boolean(row));

  return filterAttributesForProject(normalized, projectId)
    .sort((left, right) => left.attribute_name.localeCompare(right.attribute_name));
}

export function toProjectAttributeSelectOptions(
  attributes: ProjectAttributeRecord[],
): Array<{ label: string; value: string }> {
  return attributes.map((attribute) => ({
    label: attribute.attribute_name,
    value: attribute.attribute_name,
    hint: attribute.attribute_value ?? '',
  }));
}

const PLACEHOLDER_PATTERN = /^\$[A-Za-z_][A-Za-z0-9_]*$/;
// String literals and quoted identifiers match first, so placeholders are only
// replaced in SQL code. Mirrors MappingSqlService._SQL_PLACEHOLDER_SCAN.
const SQL_PLACEHOLDER_SCAN =
  /--[^\r\n]*|\/\*[\s\S]*?\*\/|\$\$[\s\S]*?\$\$|('(?:[^']|'')*')|("(?:[^"]|"")*")|(?<![A-Za-z0-9_$])(\$[A-Za-z_][A-Za-z0-9_]*)(?![A-Za-z0-9_$])/g;

export function isValuePlaceholder(value: string | null | undefined): boolean {
  return PLACEHOLDER_PATTERN.test(String(value ?? '').trim());
}

/** Named variables in executable SQL. Ignore comments and quoted text. */
export function referencedSqlProjectValues(sql: string): string[] {
  const references = Array.from(sql.matchAll(SQL_PLACEHOLDER_SCAN), match => match[3]?.toUpperCase());
  return [...new Set(references.filter((reference): reference is string => Boolean(reference)))];
}

/** Firm value as a SQL literal, typed by its project attribute type. */
export function projectValueSqlLiteral(attribute: Pick<ProjectAttributeRecord, 'attribute_type' | 'attribute_value'>): string {
  let value = String(attribute.attribute_value ?? '').trim();
  // Firm values imported from SQL can keep their quotes (SET X = 'Active').
  if (value.length >= 2 && value.startsWith("'") && value.endsWith("'")) {
    value = value.slice(1, -1).replaceAll("''", "'");
  }
  if (!value || value.toUpperCase() === 'NULL') return 'NULL';
  const type = String(attribute.attribute_type ?? '').trim().toUpperCase();
  if (/^(NUMBER|DECIMAL|NUMERIC|INT|INTEGER|BIGINT|FLOAT|DOUBLE)/.test(type) && /^[-+]?(?:\d+\.?\d*|\.\d+)$/.test(value)) {
    return value;
  }
  if (/^(BOOLEAN|BOOL)/.test(type) && /^(TRUE|FALSE)$/i.test(value)) return value.toUpperCase();
  return `'${value.replaceAll("'", "''")}'`;
}

/**
 * Replace $FirmValue placeholders with the project's stored values (names match
 * ignoring case). A quoted '$Name' is replaced whole; other text is never touched.
 */
export function resolveProjectValuePlaceholders(
  sql: string,
  attributes: ProjectAttributeRecord[],
): string {
  if (!sql.includes('$') || !attributes.length) return sql;
  const byName = new Map<string, string>();
  for (const attribute of attributes) {
    const key = `$${attribute.attribute_name}`.toUpperCase();
    if (!byName.has(key)) byName.set(key, projectValueSqlLiteral(attribute));
  }
  return sql.replace(SQL_PLACEHOLDER_SCAN, (match, literal?: string, _identifier?: string, placeholder?: string) => {
    if (placeholder) return byName.get(placeholder.toUpperCase()) ?? placeholder;
    if (literal) {
      const inner = literal.slice(1, -1).trim();
      if (isValuePlaceholder(inner)) return byName.get(inner.toUpperCase()) ?? match;
    }
    return match;
  });
}
