"""Evidence coverage is separate from column counts and model confidence."""
from __future__ import annotations
from typing import Any


def declared_derived_bindings(definitions: list[dict[str, Any]], allowed_tables: set[str],
                              allowed_functions: set[str] | None = None,
                              verified_source_columns: dict[str, dict[str, str]] | None = None) -> set[str]:
    """Expose explicit SELECT outputs after checking the entire CTE dependency SQL.

    This establishes proposal scope, not Snowflake compilation or row readiness.
    Wildcards do not authorize invented columns; execution resolves their catalog.
    """
    from sqlglot import exp, parse_one
    from sqlglot.errors import ParseError
    from app.agent_tools.catalog_discovery import identifier_parts
    from app.agent_tools.contract_reader import normalize_fqn
    from app.core.sql_execution_guard import validate_relations

    if not definitions:
        return set()
    bodies, outputs, names = [], set(), set()
    for definition in definitions:
        name = normalize_fqn(definition.get('name'))
        sql = str(definition.get('sql') or definition.get('sql_outline') or '').strip().rstrip(';')
        if len(identifier_parts(name)) != 1 or name in names or not sql:
            raise ValueError('Each derived source needs a unique name and complete SELECT SQL')
        names.add(name)
        try:
            query = parse_one(sql, read='snowflake')
        except ParseError as error:
            raise ValueError('Derived SELECT SQL could not be parsed') from error
        if not isinstance(query, exp.Query):
            raise ValueError('Derived sources must be SELECT or WITH queries')
        bodies.append(f'{name} AS ({sql})')
        for projection in query.selects:
            identifier = projection.args.get('alias') if isinstance(projection, exp.Alias) else projection.this if isinstance(projection, exp.Column) else None
            if isinstance(identifier, exp.Identifier):
                outputs.add(f'{name}.{normalize_fqn(identifier.sql(dialect="snowflake"))}')
    combined='WITH ' + ', '.join(bodies) + ' SELECT * FROM ' + next(iter(names))
    validate_relations(combined, allowed_tables, allowed_functions=allowed_functions)
    if verified_source_columns:
        from sqlglot.schema import MappingSchema
        from sqlglot.optimizer.qualify import qualify
        from sqlglot.errors import OptimizeError, SchemaError
        schema=MappingSchema(dialect='snowflake')
        for table,columns in verified_source_columns.items():
            if normalize_fqn(table) not in {normalize_fqn(value) for value in allowed_tables} or not columns:
                continue
            schema.add_table(table,{exp.to_identifier(name,quoted=True):kind or 'UNKNOWN'
                                    for name,kind in columns.items()},dialect='snowflake')
        try:
            expanded=qualify(parse_one(combined,read='snowflake'),dialect='snowflake',schema=schema,
                             infer_schema=False,expand_stars=True,validate_qualify_columns=True)
        except (OptimizeError,SchemaError):
            # No wildcard permission is inferred from incomplete contracts.
            # Explicit outputs retain the conservative legacy behavior.
            expanded=None
        if expanded is not None:
            for cte in expanded.find_all(exp.CTE):
                name=normalize_fqn(cte.alias_or_name)
                if name not in names:continue
                for projection in cte.this.selects:
                    identifier=projection.args.get('alias') if isinstance(projection,exp.Alias) else projection.this if isinstance(projection,exp.Column) else None
                    if isinstance(identifier,exp.Identifier):outputs.add(f'{name}.{normalize_fqn(identifier.sql(dialect="snowflake"))}')
    aliases={}
    for definition in definitions:
        name=normalize_fqn(definition.get('name'))
        for value in (definition.get('name'),definition.get('id'),definition.get('alias')):
            if value:aliases.setdefault(normalize_fqn(value),set()).add(name)
    for alias,owners in aliases.items():
        if len(owners)==1:
            owner=next(iter(owners))
            outputs.update(alias+value[len(owner):] for value in list(outputs) if value.startswith(owner+'.'))
    return outputs


def resolve_proposal_reference(reference: str, tables: set[str], derived_outputs: set[str]) -> str | None:
    """Resolve SQL-aware current names/aliases; evidence IDs never grant scope."""
    from sqlglot import exp, parse_one
    from app.agent_tools.catalog_discovery import identifier_parts
    from app.agent_tools.contract_reader import normalize_fqn
    from app.core.workspace_snapshot import relation_alias_for
    if not isinstance(reference,str):return None
    candidate=reference[4:] if reference.startswith('src:') else reference
    try:
        column = parse_one(candidate, into=exp.Column, dialect='snowflake')
    except Exception:
        return None
    if not isinstance(column, exp.Column) or len(column.parts) < 2:
        return None
    relation = normalize_fqn('.'.join(part.sql(dialect='snowflake') for part in column.parts[:-1]))
    field = normalize_fqn(column.this.sql(dialect='snowflake'))
    if f'{relation}.{field}' in derived_outputs:
        return f'{relation}.{field}'
    normalized = {normalize_fqn(table) for table in tables}
    parts = identifier_parts(relation)
    matches=[table for table in normalized if relation==table or len(parts)==1 and (
        identifier_parts(table)[-1:]==parts or normalize_fqn(relation_alias_for(table))==relation)]
    return f'{matches[0]}.{field}' if len(matches)==1 else None


def proposal_reference_in_scope(reference: str, tables: set[str], derived_outputs: set[str]) -> bool:
    return resolve_proposal_reference(reference,tables,derived_outputs) is not None


def disconnected_plan_sources(driving_source: str | None, supporting_sources: list[str],
                              relationships: list[dict[str, Any]]) -> list[str]:
    """Find selected physical sources without a verified join path to the driver."""
    def table_name(value: Any) -> str:
        if isinstance(value, dict):
            value = ".".join(str(value.get(key) or "") for key in ("database", "schema", "table"))
        return str(value or "").strip('"').upper()

    driving = table_name(driving_source)
    selected = {table_name(value) for value in supporting_sources if table_name(value)}
    connected = {driving} if driving else set()
    edges = []
    for relationship in relationships:
        conditions = relationship.get("conditions") or []
        if not any(isinstance(condition, dict) and condition.get("left_column")
                   and condition.get("right_column") for condition in conditions):
            continue
        left = table_name(relationship.get("left_table"))
        right = table_name(relationship.get("right_table"))
        if left and right:
            edges.append((left, right))
    changed = True
    while changed:
        before = len(connected)
        for left, right in edges:
            if left in connected:
                connected.add(right)
            if right in connected:
                connected.add(left)
        changed = len(connected) > before
    return sorted(selected - connected)


def assess_source_readiness(target_columns: list[str], selected_sources: list[str],
                            mapping_rows: list[dict[str, Any]], rules: list[dict[str, Any]]) -> dict:
    selected = {v.upper() for v in selected_sources}
    coverage = {}
    missing_sources = set()
    for target in target_columns:
        candidates = [row for row in [*mapping_rows, *rules]
                      if str(row.get('target_column', '')).upper() == target.upper()]
        accounted = []
        for row in candidates:
            columns = row.get('source_columns') or row.get('correct_source') or []
            tables = {str(v).upper() for v in row.get('source_tables', []) if isinstance(v,str)}
            tables.update(v.rsplit('.',1)[0].upper() for v in columns if isinstance(v,str) and len(v.split('.')) == 4)
            missing_sources.update(tables - selected)
            mode = str(row.get('mapping_mode') or row.get('mapping_classification') or '').lower()
            explicit_constant = mode == 'constant' and ('constant_value' in row or row.get('expression'))
            explicit_exclusion = mode == 'excluded' and bool(row.get('reason') or row.get('summary'))
            # Unqualified lineage and transformations without lineage require research.
            if explicit_constant or explicit_exclusion or (columns and tables and tables <= selected):
                accounted.append(row)
        coverage[target] = {'status': 'evidence_candidate' if accounted else 'unresolved',
                            'candidate_count': len(accounted), 'business_approval_verified': False}
    unresolved_columns = [key for key,value in coverage.items() if value['status'] == 'unresolved']
    unresolved = [f'Target column requires source/rule evidence: {column}' for column in unresolved_columns]
    unresolved += [f'Referenced source requires discovery/authorization: {table}' for table in sorted(missing_sources)]
    return {'ready_for_analyst': bool(target_columns) and bool(selected_sources) and not unresolved,
            'business_correctness_verified': False, 'target_columns': coverage,
            'unresolved_columns': unresolved_columns, 'missing_source_tables': sorted(missing_sources),
            'unresolved': unresolved}


def resolve_visible_references(references: list[str], visible_tables: list[str],
                               preferred_tables: list[str] | None = None) -> tuple[list[str], list[str]]:
    """Resolve lineage against current visibility, preferring verified precedent scope.

    An unqualified historical name can exist in several caller-visible schemas.
    A single already-verified source from the selected precedent disambiguates
    it; a genuinely ambiguous reference still requires review.
    """
    from app.agent_tools.catalog_discovery import identifier_parts
    selected, unresolved = [], []
    preferred = {tuple(identifier_parts(value)) for value in preferred_tables or []}
    for reference in references:
        parts=tuple(identifier_parts(reference))
        candidates=sorted({table for table in visible_tables if parts and tuple(identifier_parts(table))[-len(parts):]==parts})
        preferred_candidates=[table for table in candidates if tuple(identifier_parts(table)) in preferred]
        if len(preferred_candidates)==1:selected.append(preferred_candidates[0])
        elif len(candidates)==1:selected.append(candidates[0])
        else:unresolved.append(reference)
    return list(dict.fromkeys(selected)), unresolved
