Single-service SPCS caller-token fix

Purpose:
- Fix the SPCS caller-rights OAuth/session issue without bringing in the separate auto-mapping worker service.
- Keep deployment as a single service with backend + frontend + nginx together.

Files included:
- infra/snowflake/service-specs/webapp.yaml.tmpl
- services/sttm-builder/app/core/config.py
- services/sttm-builder/app/core/snowflake.py
- services/sttm-builder/app/core/snowflake_agent.py

Why these files:
- webapp.yaml.tmpl stops forcing deploy-time SNOWFLAKE_ACCOUNT and SNOWFLAKE_HOST into the backend container.
- snowflake.py hardens caller-rights Snowpark / connector session creation around the SPCS token path.
- config.py adds the retry settings used by snowflake.py and snowflake_agent.py.
- snowflake_agent.py adds retry handling for transient Cortex/Snowflake agent failures.

How to apply:
1. Extract this archive at the repo root.
2. Let the files replace the existing ones.
3. Rebuild and redeploy the single service.

Notes:
- This package intentionally does NOT include the separate auto-mapping worker service files.
- This package intentionally does NOT include deploy scripts from the newer split-service work.
