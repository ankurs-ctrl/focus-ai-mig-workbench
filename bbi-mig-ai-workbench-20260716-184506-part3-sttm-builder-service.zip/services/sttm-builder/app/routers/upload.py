"""Upload router for builder hydration and offline FIR evidence capture."""
from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, File, Form, UploadFile, HTTPException, Depends

from app.api.deps import get_snowflake_client
from app.core.config import Settings, get_settings
from app.core.snowflake import SnowflakeClient

from ..core.sql_parser import parse_sql_document, ParsedSqlDocument
from ..core.excel_parser import parse_excel_mapping, ParsedExcelMapping
from ..core.fir_asset_resolver import FIRAssetTableResolver

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/upload", tags=["Upload"])

MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB


@router.post("/sql")
async def upload_sql(
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
    file: UploadFile = File(...),
    project_id: str = Form(...),
    mode: str = Form("auto_populate"),
    source_table_hints: str = Form(""),
    target_table_hint: str = Form(""),
):
    """Upload a SQL file for parsing and FIR learning.

    Args:
        file: The SQL file (.sql)
        project_id: Project context
        mode: 'auto_populate' (fill builder) or 'learn_from_it' (background learning)

    Returns:
        Parsed summary with tables, columns, joins, transformations
    """
    if not file.filename or not file.filename.lower().endswith(".sql"):
        raise HTTPException(400, "Only .sql files are accepted")

    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(413, f"File exceeds {MAX_FILE_SIZE // (1024*1024)}MB limit")

    sql_text = content.decode("utf-8", errors="replace")
    asset_id = hashlib.sha256(content).hexdigest()[:32]

    parsed = parse_sql_document(sql_text)

    session = client.session
    try:
        _store_sql_asset(session, asset_id, file.filename, sql_text, project_id, parsed)
        source_candidates = _merge_table_hints(parsed.source_tables, source_table_hints)
        target_candidates = _merge_table_hints(
            [parsed.target_table] if parsed.target_table else [], target_table_hint
        )
        references = FIRAssetTableResolver(session, settings).resolve_and_store(
            asset_id=asset_id,
            project_id=project_id,
            references=[
                *[(table, "source") for table in source_candidates],
                *[(table, "target") for table in target_candidates],
            ],
        )
        _enqueue_fir_document_event(
            session,
            asset_id,
            project_id,
            references,
            event_type="document.sql_upload",
            priority=mode == "learn_from_it",
        )
    except Exception as exc:
        logger.exception("Failed to store or queue SQL asset")
        raise HTTPException(500, "The SQL asset could not be stored for FIR processing") from exc

    return {
        "status": "success",
        "asset_id": asset_id,
        "filename": file.filename,
        "mode": mode,
        "parsed_summary": parsed.to_dict(),
        "table_references": references,
    }


@router.post("/excel")
async def upload_excel(
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
    file: UploadFile = File(...),
    project_id: str = Form(...),
    mode: str = Form("auto_populate"),
    source_table_hints: str = Form(""),
    target_table_hint: str = Form(""),
):
    """Upload an Excel/CSV mapping file for parsing and FIR learning.

    Args:
        file: The Excel file (.xlsx, .xls, .csv)
        project_id: Project context
        mode: 'auto_populate' or 'learn_from_it'

    Returns:
        Parsed mapping summary with source/target columns and rules
    """
    valid_exts = (".xlsx", ".xls", ".csv")
    if not file.filename or not any(file.filename.lower().endswith(ext) for ext in valid_exts):
        raise HTTPException(400, f"Accepted formats: {', '.join(valid_exts)}")

    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(413, f"File exceeds {MAX_FILE_SIZE // (1024*1024)}MB limit")

    parsed = parse_excel_mapping(content, file.filename)
    asset_id = hashlib.sha256(content).hexdigest()[:32]

    session = client.session
    try:
        _store_excel_asset(session, asset_id, file.filename, parsed, project_id)
        source_candidates = _merge_table_hints(parsed.source_datasets, source_table_hints)
        target_candidates = _merge_table_hints(parsed.target_tables, target_table_hint)
        references = FIRAssetTableResolver(session, settings).resolve_and_store(
            asset_id=asset_id,
            project_id=project_id,
            references=[
                *[(table, "source") for table in source_candidates],
                *[(table, "target") for table in target_candidates],
            ],
        )
        _enqueue_fir_document_event(
            session,
            asset_id,
            project_id,
            references,
            event_type=(
                "document.csv_upload"
                if file.filename.lower().endswith(".csv")
                else "document.excel_upload"
            ),
            priority=mode == "learn_from_it",
        )
    except Exception as exc:
        logger.exception("Failed to store or queue Excel asset")
        raise HTTPException(500, "The mapping asset could not be stored for FIR processing") from exc

    return {
        "status": "success",
        "asset_id": asset_id,
        "filename": file.filename,
        "mode": mode,
        "parsed_summary": parsed.to_dict(),
        "table_references": references,
    }


def _merge_table_hints(detected: list[str], hints: str) -> list[str]:
    hint_values = _split_table_values([hints])
    # Explicit physical selections are authoritative. The detected identifiers
    # remain preserved in the parsed asset as document evidence, but they must
    # not keep a correctly resolved upload in a deferred state.
    values = hint_values or _split_table_values(detected)
    seen: set[str] = set()
    merged: list[str] = []
    for normalized in values:
        key = normalized.upper()
        if key in seen:
            continue
        seen.add(key)
        merged.append(normalized)
    return merged


def _split_table_values(raw_values: list[str]) -> list[str]:
    values: list[str] = []
    for raw_value in raw_values:
        values.extend(
            part.strip()
            for part in str(raw_value or "").replace("\r", "\n").replace("\n", ",").split(",")
        )
    normalized_values: list[str] = []
    for value in values:
        normalized = str(value or "").strip()
        key = normalized.upper()
        # Mapping workbooks use these values for self-derived fields, not
        # physical table references that should enter FIR resolution.
        if not normalized or key in {"/", "SELF"}:
            continue
        normalized_values.append(normalized)
    return normalized_values


@router.post("/trigger-learning")
async def trigger_learning(
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    asset_id: str = Form(...),
    project_id: str = Form(...),
):
    """Prioritize a previously uploaded document for an offline FIR cycle."""
    session = client.session

    rows = session.sql(
        "SELECT SQL_ASSET_ID FROM TBL_WORKBENCH_CLIENT_SQL_ASSETS WHERE SQL_ASSET_ID = ?",
        [asset_id],
    ).collect()
    if not rows:
        raise HTTPException(404, "Asset not found. Please re-upload the file.")

    _enqueue_fir_document_event(session, asset_id, project_id, [], priority=True)

    return {
        "status": "queued",
        "asset_id": asset_id,
        "recommendations_generated": 0,
        "details": {"processing": "offline", "latency_added_to_request": False},
    }


def _store_sql_asset(
    session, asset_id: str, filename: str, sql_text: str, project_id: str, parsed: ParsedSqlDocument
) -> None:
    """Store uploaded SQL in TBL_WORKBENCH_CLIENT_SQL_ASSETS."""
    attributes_payload = parsed.to_dict()
    attributes_payload["fir_evidence"] = {
        "evidence_class": "authored_historical_mapping",
        "authoritative_mapping": True,
        "base_confidence": 0.96,
        "provenance": "client_provided_sql",
        "meaning": (
            "A previously created mapping implementation. Treat its source/target mappings, "
            "CTE structure, joins, filters, transformations, and comments as authoritative "
            "historical evidence unless table resolution is ambiguous or stronger evidence "
            "explicitly contradicts it."
        ),
    }
    attributes = json.dumps(attributes_payload)
    session.sql("""
        MERGE INTO TBL_WORKBENCH_CLIENT_SQL_ASSETS target
        USING (SELECT ? AS SQL_ASSET_ID) source
        ON target.SQL_ASSET_ID = source.SQL_ASSET_ID
        WHEN NOT MATCHED THEN INSERT (
            SQL_ASSET_ID, TITLE, SQL_TEXT, SQL_KIND, DIALECT,
            DESCRIPTION, TAGS, ATTRIBUTES, PROJECT_ID,
            STATUS, CREATED_AT, UPDATED_AT
        ) VALUES (?, ?, ?, 'historical_mapping', 'snowflake',
                  ?, PARSE_JSON('[]'), PARSE_JSON(?), ?,
                  'active', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())
    """, [
        asset_id,
        asset_id, filename, sql_text,
        f"Uploaded SQL: {filename}", attributes, project_id,
    ]).collect()


def _store_excel_asset(
    session, asset_id: str, filename: str, parsed: ParsedExcelMapping, project_id: str
) -> None:
    """Store uploaded Excel mapping in TBL_WORKBENCH_CLIENT_SQL_ASSETS as a mapping document."""
    attributes_payload = parsed.to_dict()
    is_csv = filename.lower().endswith(".csv")
    attributes_payload["fir_evidence"] = {
        "evidence_class": (
            "authored_csv_mapping_specification"
            if is_csv
            else "authored_mapping_workbook"
        ),
        "authoritative_mapping": True,
        "base_confidence": 0.97 if is_csv else 0.99,
        "provenance": (
            "client_provided_mapping_csv"
            if is_csv
            else "client_provided_mapping_workbook"
        ),
        "meaning": (
            "A previously created source-to-target mapping specification. Treat its column "
            "mappings, definitions, processing rules, dependencies, and ordering as "
            "authoritative historical evidence unless table resolution is ambiguous or "
            "stronger evidence explicitly contradicts it."
        ),
    }
    attributes = json.dumps(attributes_payload)
    session.sql("""
        MERGE INTO TBL_WORKBENCH_CLIENT_SQL_ASSETS target
        USING (SELECT ? AS SQL_ASSET_ID) source
        ON target.SQL_ASSET_ID = source.SQL_ASSET_ID
        WHEN NOT MATCHED THEN INSERT (
            SQL_ASSET_ID, TITLE, SQL_TEXT, SQL_KIND, DIALECT,
            DESCRIPTION, TAGS, ATTRIBUTES, PROJECT_ID,
            STATUS, CREATED_AT, UPDATED_AT
        ) VALUES (?, ?, ?, 'MAPPING', 'excel',
                  ?, PARSE_JSON('["excel_mapping"]'), PARSE_JSON(?), ?,
                  'active', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())
    """, [
        asset_id,
        asset_id, filename, json.dumps(parsed.to_dict()),
        f"Uploaded mapping: {filename}", attributes, project_id,
    ]).collect()


def _enqueue_fir_document_event(
    session,
    asset_id: str,
    project_id: str,
    references: list[dict[str, Any]],
    *,
    event_type: str = "document.uploaded",
    priority: bool = False,
) -> None:
    unresolved = [item for item in references if item.get("resolution_status") != "resolved"]
    payload = {
        "asset_id": asset_id,
        "project_id": project_id,
        "priority": priority,
        "table_references": references,
        "inference_status": "deferred_for_resolution" if unresolved else "ready_for_enrichment",
    }
    session.sql("""
        INSERT INTO TBL_WORKBENCH_FIR_EVENTS (
            EVENT_ID, EVENT_TYPE, PAGE, SURFACE, ENTITY_TYPE, ENTITY_IDS, EVENT_PAYLOAD, MILESTONE
        ) SELECT UUID_STRING(), ?, 'upload', 'DOCUMENT', 'sql_asset',
                 PARSE_JSON(?), PARSE_JSON(?), 'document_resolved'
    """, [
        event_type,
        json.dumps([asset_id]),
        json.dumps(payload),
    ]).collect()
