"""One non-publishing Auto-map acceptance in this system's separate test account.

Uses existing semantic assets. Creates a uniquely named scratch schema/agent and
16-row capacity fixture (12 execution, 4 old quarantine records). Never changes
client account settings, existing admission pools, mappings or semantic assets.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, UTC, timedelta
import hashlib
import json
import logging
from pathlib import Path
import sys
import time
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'services/sttm-builder'),str(ROOT)]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--warehouse', help='Existing test warehouse; does not modify the credential file')
    parser.add_argument('--generation-policy', choices=['legacy', 'draft-v3'], default='legacy')
    parser.add_argument('--full-mapping',action='store_true',help='Map every physical column of the larger existing semantic fixture, using normal batches')
    args=parser.parse_args();logging.basicConfig(level=logging.ERROR)
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    import yaml
    from app.core.config import Settings
    from app.core.semantic_model import SemanticModelService
    from app.core.sttm_builder import STTMBuilderService
    from app.core.snowflake_agent import SnowflakeAgentClient
    from app.core.automap_runtime import RuntimeCaller, SnowflakeReductionArchive
    from app.core.automap_semantic_catalog import build_catalog
    from app.core.automap_batch import FAST_INTEGRATION_VERSION,canonical_model_wire_request,freeze_fast_handoff
    from app.core.automap_policy import preparation_hash, POLICY_VERSION
    from app.schema.common import TableRef
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest,AgentExecutionContextV2
    from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
    from app.guardrails.config.loader import load_config
    from app.guardrails.contracts.decisions import GovernanceDecision
    from scripts.prepare_parallel_automap_infra import PERMIT_COLUMNS,ARCHIVE_COLUMNS
    from scripts.prepare_automap_durable_runs import EXTRA_COLUMNS
    c=dotenv_values(args.credential_env)
    if c.get('SNOWFLAKE_ACCOUNT','').upper()!='A0581299278961-BBINSIGHT_PARTNER':
        raise ValueError('Restricted to this system test account')
    schema='SCH_AUTOMAP_ACCEPTANCE_'+uuid4().hex[:12].upper()
    db='FFP_HDP_CRM_MIG_DB_DEV';namespace=db+'.'+schema
    table=namespace+'.PERMITS_V2';archive=namespace+'.ARCHIVE'
    epoch=str(uuid4());created=False;report={'status':'started','publishing':False,'execution_slots':12,'legacy_quarantines':4}
    original_collect=SnowflakeReductionArchive._collect_sql
    def observed_collect(self,*args,**kwargs):
        try:return original_collect(self,*args,**kwargs)
        except Exception as exc:
            # Record types/codes only: never query text, binds or error bodies.
            report.setdefault('archive_sql_failures',[]).append({'error_type':type(exc).__name__,
                'error_code':getattr(exc,'sql_error_code',None)})
            raise
    SnowflakeReductionArchive._collect_sql=observed_collect
    config=dict(account=c['SNOWFLAKE_ACCOUNT'],user=c['SNOWFLAKE_USER'],authenticator='PROGRAMMATIC_ACCESS_TOKEN',
        token=c['SNOWFLAKE_PASSWORD'],role=c['SNOWFLAKE_ROLE'],warehouse=args.warehouse or c['SNOWFLAKE_WAREHOUSE'],
        database=db,schema='SCH_STTM_METADATA',login_timeout=20,network_timeout=60)
    session=Session.builder.configs(config).create()
    @contextmanager
    def independent():
        s=Session.builder.configs(config).create()
        try:yield s
        finally:s.close()
    try:
        identity=session.sql('SELECT CURRENT_ORGANIZATION_NAME() O,CURRENT_ACCOUNT_NAME() A,CURRENT_USER() U,CURRENT_ROLE() R').collect()[0]
        assert identity['O']=='A0581299278961' and identity['A']=='BBINSIGHT_PARTNER'
        report['verified_account']=identity['O']+'.'+identity['A'];report['verified_user']=identity['U']
        values={k:v for k,v in c.items() if v is not None}
        values['SNOWFLAKE_WAREHOUSE'] = config['warehouse']
        values.update(APP_ENV='local',LOCAL_DEV_AUTH_ENABLED=True,SNOWFLAKE_AUTHENTICATOR='programmatic_access_token',
            SNOWFLAKE_DATABASE=db,SNOWFLAKE_SCHEMA=schema,
            SNOWFLAKE_SEMANTIC_MODEL_TABLE=db+'.SCH_STTM_METADATA.TBL_SEMANTIC_MODELS',
            SNOWFLAKE_SEMANTIC_VIEWS_DATABASE='FOCUS_DB_2',SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA='STTM_MCP',
            SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE='SEM_NATIVE_VIEWS',
            AUTOMAP_FAST_PATH_V1=True,AUTOMAP_FAST_PROJECT_IDS='*',AUTOMAP_FAST_BATCH_SECONDS=300,
            AUTOMAP_FAST_JOB_SECONDS=600,AUTOMAP_PARALLEL_CONTEXT_V1=True,AUTOMAP_DURABLE_RUNS_V2=True,
            AUTOMAP_RECOVERY_CAPACITY=4,AUTOMAP_PARALLEL_POOL_CAPACITY=12,AUTOMAP_PARALLEL_MAX_WORKERS=12,
            AUTOMAP_PARALLEL_PERMIT_TABLE_FQN=table,AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN=archive,
            AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE=identity['O']+'.'+identity['A'],AUTOMAP_PARALLEL_POOL_EPOCH=epoch,
            AUTOMAP_PARALLEL_TEST_AGENT=namespace+'.AGT_SOURCE_MAPPING',SNOWFLAKE_WRITE_LEASE_POOL_V1=True,
            AUTOMAP_FAST_MAX_IN_FLIGHT=12,AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
            AGENT_OUTBOUND_MESSAGE_MAX_CHARS=180000,AGENT_OUTBOUND_MESSAGE_MAX_BYTES=180000,
            SNOWFLAKE_REST_HOST='a0581299278961-bbinsight-partner.snowflakecomputing.com',
            SNOWFLAKE_SOURCE_MAPPING_AGENT=namespace+'.AGT_SOURCE_MAPPING',
            SNOWFLAKE_TRANSFORMATION_AGENT=namespace+'.AGT_TRANSFORMATION_RULE')
        settings=Settings(_env_file=None,**values)
        refs=[TableRef(database='BBI_STTM_TEST_DB',schema='DW_OPS',table=n) for n in ['PORTAL_USER_HISTORY','LOAN_INCOME_AMOUNT_CALCULATION']]
        records=SemanticModelService(settings.model_copy(update={'snowflake_schema': 'SCH_STTM_METADATA'})).get_table_records(session,refs)
        if not records:raise ValueError('Existing semantic fixture unavailable')
        record=max(records,key=lambda r:len(build_catalog([r],bundle_hash='live-existing-semantics'))) if args.full_mapping else records[0]
        fqn='.'.join(record[k] for k in ['database','schema_name','table_name'])
        catalog=[v for v in build_catalog([record],bundle_hash='live-existing-semantics') if v['provenance']!='name_only']
        if not catalog:raise ValueError('Stored semantic descriptions unavailable')
        chosen=catalog[:2]
        if args.full_mapping:
            described=session.sql('DESCRIBE TABLE '+fqn).collect()
            semantic={v['column'].upper():v for v in catalog}
            chosen=[{'column':r['name'],'data_type':r['type'],
                'description':semantic.get(r['name'].upper(),{}).get('description') or r['comment'] or ''}
                for r in described if r['kind']=='COLUMN']
            if not chosen:raise ValueError('Full physical target inventory unavailable')
            report['physical_target_column_count']=len(chosen)
            print(json.dumps({'stage':'full_inventory','source_table':fqn,'target_count':len(chosen)}),flush=True)
        source=dict(zip(['database','schema','table'],fqn.split('.')))
        target={'database':db,'schema':schema,'table':'LOGICAL_IDENTITY_TARGET'}
        session.sql('CREATE TRANSIENT SCHEMA '+namespace).collect();created=True
        journal=Path('/tmp/automap-durable-fixtures.jsonl')
        with journal.open('a') as entry:entry.write(json.dumps({'schema':schema,'created_at':datetime.now(UTC).isoformat()})+'\n')
        legacy=namespace+'.LEGACY_PERMITS'
        session.sql(f'CREATE TRANSIENT TABLE {legacy} ({PERMIT_COLUMNS})').collect()
        account=report['verified_account']
        session.sql(f"INSERT INTO {legacy} (ACCOUNT_NAMESPACE,POOL_EPOCH,SLOT_ID,STATE,OWNER_TOKEN,FENCE,CALLER_ID,JOB_ID,GENERATION,SHARD_ID,UPDATED_AT) "
            "SELECT ?,?,ROW_NUMBER() OVER (ORDER BY SEQ4()),'QUARANTINED','legacy-fixture',1,'LEGACY_TEST_CALLER','old-test','old-test','old-test',CURRENT_TIMESTAMP() "
            "FROM TABLE(GENERATOR(ROWCOUNT=>4))",params=[account,epoch]).collect()
        session.sql(f'CREATE TRANSIENT TABLE {archive} ({ARCHIVE_COLUMNS})').collect()
        from scripts import prepare_automap_durable_runs as migration
        old_loader=migration.load_profile
        migration.load_profile=lambda *a:({'account_namespace':account,'database':db,'schema':schema,
            'role':identity['R'],'connection':'local-acceptance'}, {
            'AUTOMAP_DURABLE_RUNS_V2':'true','AUTOMAP_PARALLEL_POOL_CAPACITY':'12','AUTOMAP_RECOVERY_CAPACITY':'4',
            'AUTOMAP_PARALLEL_PERMIT_TABLE_FQN':table,'AUTOMAP_PARALLEL_POOL_EPOCH':epoch})
        try:
            migration_sql=migration.prepare(None,'DEV',legacy_table=legacy,exclusive=True,retired_dispatchers=True)
            validation_sql=migration.prepare(None,'DEV',stage='validate')
        finally:migration.load_profile=old_loader
        session.sql('USE SCHEMA '+namespace).collect()
        import io
        from snowflake.connector.util_text import split_statements
        def split_sql_statements(sql):return [part for part,_ in split_statements(io.StringIO(sql)) if part.strip()]
        for statement in split_sql_statements(migration_sql): session.sql(statement).collect()
        # Repeated migration must validate without reseeding owners/fences.
        for statement in split_sql_statements(migration_sql): session.sql(statement).collect()
        for statement in split_sql_statements(validation_sql): session.sql(statement).collect()
        report['migration_repeat_and_readonly_validation']='passed'
        spec=yaml.safe_load((ROOT/'infra/snowflake/agents/agent_spec_source_mapping.yaml').read_text())
        spec.pop('tools',None);spec.pop('tool_resources',None);spec['orchestration']['budget']['seconds']=180
        literal=json.dumps(spec).replace(chr(92),chr(92)*2).replace("'","''")
        session.sql(f"CREATE AGENT {namespace}.AGT_SOURCE_MAPPING FROM SPECIFICATION '{literal}'").collect()
        conn=session.connection
        agent=SnowflakeAgentClient(token=conn._rest._token,host=settings.rest_snowflake_host,auth_mode='snowflake_token',role=identity['R'],request_timeout=300)
        service=STTMBuilderService.__new__(STTMBuilderService)
        service._settings=settings;service._session=session;service._query_session=session;service._agent=agent
        service._source_mapping_agent_name=namespace+'.AGT_SOURCE_MAPPING';service._transformation_agent_name=None
        service._parallel_caller=RuntimeCaller(identity['U'],identity['U'],identity['R'],account)
        service._parallel_session_factory=independent
        from app.core.automap_runtime import build_fast_model_runtime, RuntimeConfigurationError
        def diagnostic_factory(service,req,decision,store,deadline):
            try:return build_fast_model_runtime(service,req,decision,store,deadline,finalization_deadline=deadline+20)
            except RuntimeConfigurationError as exc:
                report['runtime_configuration_error']=str(exc)
                raise
        service._fast_model_runtime_factory=diagnostic_factory
        guard_config=load_config(settings=settings);service._model_guard=ModelBoundaryGuard(guard_config)
        # This fixture intentionally has no project history; reads existing semantic
        # assets and exercises full evidence/model/candidate validation, not FIR activation.
        service._discover_auto_map_evidence=lambda request,targets:{'evidence':{},'diagnostics':{'status':'no_match','fixture':True}}
        until=datetime.now(UTC)+timedelta(seconds=600)
        payload={'request_id':str(uuid4()),'operation':'sttm.auto_map',
            'data':{'intent':'AUTO_MAP','message':'Identity semantic contract. Preserve each requested target meaning using its corresponding existing source field. Do not publish.',
                'attributes':[{'target_table':target,'target_attribute':v['column'],'target_data_type':v['data_type'],'target_description':v['description']} for v in chosen]},
            'context':{'project_id':'1','source_tables':[source],'driving_table':source,'target_table':target,
                'semantic_context':[{'table':source,'semantic_model':record['semantic_model']}],
                'learning_context':{'automap_policy_version':POLICY_VERSION},
                'workspace_context':{'driving_relation_id':'src'},
                'relation_graph':{'nodes':[{'relation_id':'src','alias':'src','kind':'PHYSICAL_TABLE','table':source,
                    'output_columns':[{'name':v['column'],'data_type':v['data_type']} for v in (chosen if args.full_mapping else catalog)]}],'edges':[]}},
            'meta':{'auto_map_fast_path':'v1','auto_map_deadline_at':until.isoformat(),'_automap_deadline':until.timestamp()}}
        if args.generation_policy == 'draft-v3':
            payload['meta']['automap_generation_policy'] = 'draft-v3'
        report['generation_policy'] = args.generation_policy
        req=STTMBuilderEnvelopeRequest.model_validate(payload)
        req.context.execution_context=AgentExecutionContextV2(context_key='local-durable-acceptance')
        req.context.prepared_context_hash=preparation_hash(req.context)
        req.meta.update(auto_map_parent_resolution_version=FAST_INTEGRATION_VERSION,auto_map_prepared_readonly=True)
        req=canonical_model_wire_request(STTMBuilderService._with_intent_route(req))
        req.context.prepared_context_hash=preparation_hash(req.context);req.meta['_automap_fast_handoff']=freeze_fast_handoff(req,discovery={v['column']:{'evidence':{},'diagnostics':{'status':'no_match','fixture':True}} for v in chosen})
        decision=GovernanceDecision(trace_id='durable-local-acceptance',request_id=req.request_id,operation=req.operation.value)
        from app.core.auto_mapping_proxy import AutoMappingProxyClient
        from app.schema.sttm_builder import STTMBuilderResponse,SourceMappingResult,SubAgent,STTMStatus
        from app.core.automap_run_recovery import recovery_coordinator
        recovery_coordinator.start()
        invocations=[]
        def invoke(batch_request,**kwargs):
            from copy import copy
            from app.core.automap_row_candidates import validate_row_candidates
            # A batch owns its SQL session; concurrent model batches never share
            # a request Snowpark session. The original REST caller stays alive.
            with independent() as batch_session:
                worker=copy(service);worker._session=batch_session;worker._query_session=batch_session
                raw,thread,metadata=worker._invoke_retrieval_auto_map(batch_request,decision)
                invocations.append(metadata)
                envelope=json.loads(raw)
                response=STTMBuilderResponse.from_invocation(batch_request,thread_id=thread,parent_message_id=None,
                    agent=SubAgent.SOURCE_MAPPING_AGENT,result=SourceMappingResult.model_validate(envelope['data']['result']),
                    message=None,status=STTMStatus.COMPLETED,meta={**envelope.get('meta',{}),**dict(metadata)})
                # Same final row-level validation used by the public worker path.
                response=validate_row_candidates(worker,batch_request,response)
                print(json.dumps({'stage':'batch_returned','batch_index':kwargs.get('batch_index'),
                    'target_count':len(batch_request.data.attributes or [])}),flush=True)
                return response
        proxy=AutoMappingProxyClient(settings);proxy._invoke_batch=invoke
        started=time.monotonic()
        completed_batches=[]
        if args.full_mapping:
            response=proxy._invoke_worker_batches(req,headers={},
                progress_callback=lambda index,attributes,response:completed_batches.append(index))
        else:
            response=proxy._invoke_complete_batch(req,headers={},batch_index=0,planned_model_payload={'fixture':'existing-semantics'})
        result=response.model_dump(mode='json');meta=invocations[-1]
        mappings=result['data']['result']['mappings']
        traces=[r.runtime_trace for item in invocations for r in getattr(getattr(item,'execution',(None,))[0],'_requests',{}).values() if getattr(r,'runtime_trace',None)]
        report['actual_model_post_attempts']=sum(t.model_post_attempts for t in traces)
        report['actual_thread_post_attempts']=sum(t.thread_post_attempts for t in traces)
        report['transport_retries']=response.meta.get('durable_transport_retries',0)
        report['full_mapping']=args.full_mapping
        report['batch_dispatch']=response.meta.get('auto_mapping_dispatch')
        report['completed_batch_indices']=sorted(completed_batches)
        report['batch_results']=[{'targets':v.get('auto_map_retrieval',{}).get('targets'),
            'model_call_count':v.get('auto_map_retrieval',{}).get('model_call_count'),
            'failure':(v.get('auto_map_fast_path') or {}).get('fast_diagnostics'),
            'warnings':(v.get('auto_map_fast_path') or {}).get('warnings',[])} for v in invocations]
        report.update(source_table=fqn,semantic_registry=settings.resolved_semantic_native_views_table,
            requested_targets=[v['column'] for v in chosen],elapsed_seconds=round(time.monotonic()-started,2),
            proposals=sum(bool(v.get('source_attributes')) for v in mappings.values()),unresolved=sum(not v.get('source_attributes') for v in mappings.values()),
            selected_sources={k:v.get('source_attributes') for k,v in mappings.items()},
            unresolved_reasons={k:v.get('unmatched_reason') for k,v in mappings.items() if not v.get('source_attributes')},
            fast_status=meta.get('auto_map_fast_path'),
            validation_errors={k:next((c.get('validation_errors',[]) for c in v.get('candidates',[]) if c.get('candidate_id')==(v.get('selected_candidate_id') or v.get('draft_candidate_id'))),[]) for k,v in mappings.items()},
            validation_status={k:next((c.get('validation_status') for c in v.get('candidates',[]) if c.get('candidate_id')==(v.get('selected_candidate_id') or v.get('draft_candidate_id'))),None) for k,v in mappings.items()},
            review_warning_codes=sorted({w.code for w in proxy._response_warnings(response)}|
                {w['code'] for item in invocations for w in (item.get('auto_map_fast_path') or {}).get('warnings',[])}),
            model_call_count=sum(item.get('auto_map_retrieval',{}).get('model_call_count',0) for item in invocations))
        report['identity_sources_correct']=all(len(sources)==1 and sources[0].split('.')[-1].strip('"').upper()==name.upper()
            for name,sources in report['selected_sources'].items())
        rows=session.sql(f'SELECT SLOT_ID,STATE,MODEL_RUN_ID FROM {table} ORDER BY SLOT_ID').collect()
        report['execution_occupied_after']=sum(r['STATE']!='FREE' for r in rows if r['SLOT_ID']<=12)
        report['old_quarantines_unchanged']=sum(r['STATE']=='QUARANTINED' for r in rows if r['SLOT_ID']>12)==4
        report['status']='passed' if (set(mappings)=={v['column'] for v in chosen}
            and report['proposals']==len(chosen) and report['execution_occupied_after']==0
            and report['old_quarantines_unchanged']
            and report['identity_sources_correct']
            and all(v=='valid' for v in report['validation_status'].values())
            and not (report.get('batch_dispatch') or {}).get('failed_batches')) else 'failed'
        report['provider_run_ids']=[r['MODEL_RUN_ID'] for r in rows if r['MODEL_RUN_ID']]
    except Exception as exc:
        report.update(status='failed',error_type=type(exc).__name__,error_code=getattr(exc,'errno',None))
        raise
    finally:
        from app.core.automap_run_recovery import recovery_coordinator
        recovery_coordinator.stop()
        SnowflakeReductionArchive._collect_sql=original_collect
        if created:
            # Preserve unknown real operations and their audit for reconciliation.
            try:
                occupied=session.sql(f"SELECT COUNT(*) C FROM {table} WHERE STATE<>'FREE' AND NOT "
                    "(CALLER_ID='LEGACY_TEST_CALLER' AND JOB_ID='old-test' AND OWNER_TOKEN='legacy-fixture' "
                    "AND RECONCILIATION_REF IS NULL AND MODEL_RUN_ID IS NULL)").collect()[0]['C']
                if not occupied:
                    session.sql('DROP SCHEMA '+namespace+' CASCADE').collect();report['scratch_cleanup']='completed'
                else:report['scratch_cleanup']='retained_for_recovery';report['scratch_schema']=namespace
            except Exception as exc:
                report.update(scratch_cleanup='retained_for_inspection',scratch_schema=namespace,
                    cleanup_error_type=type(exc).__name__)
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2,default=str))
        print(json.dumps(report,default=str),flush=True);session.close()
    return 0 if report['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
