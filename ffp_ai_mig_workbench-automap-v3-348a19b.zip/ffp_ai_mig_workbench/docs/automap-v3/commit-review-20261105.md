# Review for CodeCommit sync publication — 5 November 2026

Base: `09e39f3`, branch `sync/uat-frontend-native-integration`.

The reviewed local changes replace the experimental native Auto-map path with v3 semantic candidate ranking, bounded evidence packets, applicable learning packs, source/rule call budgets and existing proposal validation. They also add the global/project CTE Library filter, assistant transformation Apply regression coverage and manual-save busy/count handling. Earlier SQL-upload, session-cache and frontend team integration fixes remain in the base.

Source and transformation agent template hashes match the checked-in manifest. Active application/deployment sources contain no references to removed native modules. A direct-import check passed for changed Auto-map Python modules. The new validation artifacts were checked for credential assignments, JWTs, private keys and AWS access keys; no matches were found. No local credential/env files are included.

The initial full run found seven stale regression failures: the old five-call dispatcher cap, five assertions for the previous rollout revision/capacity, and an inventory regression importing a deliberately removed native module. These were updated to assert the current dispatcher/profile contract and to exercise repeated self-join binding identities through v3's actual FastContextPlan admission. The affected three test files then passed all 177 tests. No application behavior was changed during this review.

Final verification: **4,067 backend tests passed, 31 skipped** in 249.26 seconds; **29 frontend harnesses passed**; TypeScript passed (`tsc --noEmit --incremental false`). Counts differ from the earlier release because retired native tests were removed and v3 regressions added. No live model requests, Snowflake mutations, agent updates or deployment were performed during this review. Earlier test-account checks supplied with the changes are documented separately; client accepted-answer-key accuracy and client DEV/UAT acceptance remain pending.

## Deployment considerations

- Deploy backend/frontend together and prepare/review/synchronize the source and transformation agent instructions using the supplied spec synchronization workflow. A Git push or ZIP alone does not install these Snowflake specifications.
- The checked-in UAT rollout is scoped to project 501. It configures process/dispatcher limits of eight, four targets per batch and 150k outbound input limits. Thirty-seven targets therefore require ten batches. Durable admission remains provisioned for four slots; eight process calls does not establish eight simultaneous account-wide calls. Resize the permit pool and its matching configuration together if required.
- Recipe Search SQL changes and any learning backfill require their own deployment/review. Generated test-account backfill SQL is evidence/preparation, not an automatic migration.
- Native source modules are removed; historical implementations remain in Git. Deployed native Snowflake objects are not dropped. The teardown utility prepares reviewable statements and does not execute DROP operations.
- `infra/snowflake/env/local.automap-v3.env` and client environment files are excluded. Local-only launch/benchmark scripts require an operator-provided compatible profile/credentials; they are not client deployment configuration.
- Keep the prior upload-recovery migration prerequisite documented under `docs/uat-frontend-native-integration/SQL_UPLOAD_SESSION_CACHE_CORRECTIONS.md`.
