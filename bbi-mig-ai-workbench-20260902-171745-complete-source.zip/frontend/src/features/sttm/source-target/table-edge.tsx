"use client";

import React, { useState } from "react";
import {
  BaseEdge,
  EdgeLabelRenderer,
  getBezierPath,
  type EdgeProps,
} from "@xyflow/react";

import { AiaTooltip } from "@/components/ui/aia-tooltip";

export interface TableEdgeData {
  joinType?: string;
  conditionCount?: number;
  /** How many joins this edge stands for once bundled by table pair. */
  joinCount?: number;
  label?: string;
  readOnly?: boolean;
  dashed?: boolean;
  /** Another card is focused and this edge does not touch it. */
  muted?: boolean;
  onDelete?: (id: string) => void;
  onEdit?: (id: string) => void;
  [key: string]: unknown;
}

function joinStrokeColor(joinType?: string) {
  switch ((joinType ?? "INNER").toUpperCase()) {
    case "LEFT":
      return "#1d4ed8";
    case "RIGHT":
      return "#0f766e";
    case "FULL":
      return "#7c3aed";
    case "MIXED":
      return "#475569";
    case "DERIVED":
      return "#16a34a";
    default:
      return "#111827";
  }
}

/** Heavier pairs read as heavier lines, but only up to a point. */
function joinStrokeWidth(joinCount: number, dashed: boolean) {
  if (dashed) return 1;
  return 1.5 + Math.min(joinCount / 12, 1.5);
}

export function TableEdge({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
  selected,
}: EdgeProps) {
  const [edgeHovered, setEdgeHovered] = useState(false);

  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

  const edgeData = data as TableEdgeData | undefined;
  const joinType = edgeData?.joinType || "INNER";
  const joinCount = edgeData?.joinCount ?? 1;
  const tooltipLabel =
    edgeData?.label ?? `${joinType} · ${edgeData?.conditionCount ?? 1}`;
  const stroke = joinStrokeColor(joinType);
  const readOnly = edgeData?.readOnly ?? false;
  // Joins render as solid connectors; only lineage hints opt into a dashed stroke.
  const dashed = edgeData?.dashed ?? false;
  const muted = edgeData?.muted ?? false;
  // Controls are noise at rest — hundreds of edges would each show a pair.
  const showActions = !readOnly && !muted && (edgeHovered || Boolean(selected));
  const showCountPill = !muted && !showActions && joinCount > 1;

  return (
    <>
      <BaseEdge
        id={id}
        path={edgePath}
        style={{
          stroke: selected ? "#4f46e5" : stroke,
          strokeWidth: joinStrokeWidth(joinCount, dashed),
          strokeDasharray: dashed ? "6 4" : "none",
          strokeLinecap: "round",
          opacity: muted ? 0.12 : dashed ? 0.45 : 1,
          pointerEvents: "none",
        }}
      />

      {!muted ? (
        <path
          d={edgePath}
          fill="none"
          stroke="transparent"
          strokeWidth={14}
          style={{ cursor: "pointer", pointerEvents: "stroke" }}
          onMouseEnter={() => setEdgeHovered(true)}
          onMouseLeave={() => setEdgeHovered(false)}
        />
      ) : null}

      <EdgeLabelRenderer>
        {!muted ? (
          <AiaTooltip
            title={tooltipLabel}
            open={edgeHovered}
            disableFocusListener
            disableTouchListener
            placement="top"
            arrow
          >
            <span
              className="tedge-tooltip-anchor"
              style={{
                position: "absolute",
                transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
                width: 1,
                height: 1,
                pointerEvents: "none",
              }}
            />
          </AiaTooltip>
        ) : null}

        {showCountPill ? (
          <div
            className="tedge-count"
            style={{
              transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
              borderColor: stroke,
              color: stroke,
            }}
            onMouseEnter={() => setEdgeHovered(true)}
            onMouseLeave={() => setEdgeHovered(false)}
          >
            {joinCount}
          </div>
        ) : null}

        {showActions ? (
          <div
            className="tedge-actions"
            style={{
              transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
            }}
            onMouseEnter={() => setEdgeHovered(true)}
            onMouseLeave={() => setEdgeHovered(false)}
          >
            <button
              type="button"
              className="tedge-label__icon-btn tedge-label__icon-btn--edit"
              onClick={(event) => {
                event.stopPropagation();
                edgeData?.onEdit?.(id);
              }}
              aria-label="Edit join"
            >
              ✎
            </button>
            <button
              type="button"
              className="tedge-label__icon-btn tedge-label__icon-btn--delete"
              onClick={(event) => {
                event.stopPropagation();
                edgeData?.onDelete?.(id);
              }}
              aria-label="Delete join"
            >
              ✕
            </button>
          </div>
        ) : null}
      </EdgeLabelRenderer>
    </>
  );
}
