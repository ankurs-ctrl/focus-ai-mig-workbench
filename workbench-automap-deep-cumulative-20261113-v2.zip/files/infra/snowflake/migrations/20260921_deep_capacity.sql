-- Apply once through the serialized deployment migration runner.
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.TBL_AGENT_CAPACITY_SLOTS (
    SCOPE_KEY STRING NOT NULL,
    SLOT_ID STRING NOT NULL,
    ENABLED BOOLEAN NOT NULL DEFAULT TRUE,
    OWNER_TOKEN STRING,
    LEASE_UNTIL TIMESTAMP_TZ,
    GENERATION INTEGER NOT NULL DEFAULT 0
);
-- Deployment provisions unique (SCOPE_KEY,SLOT_ID) rows from its capacity config.
-- No tenant, account, role, or project is seeded by the application migration.
