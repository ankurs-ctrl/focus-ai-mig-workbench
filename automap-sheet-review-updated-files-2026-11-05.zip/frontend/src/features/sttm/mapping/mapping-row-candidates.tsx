'use client';

import { useId, useState } from 'react';
import { AiaBox, AiaButton, AiaCollapse } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useSttmBuilderContext } from '../context/sttm-builder-context';
import type { MappingState } from '../types/sttm.types';
import { MAPPING_TABLE_BODY_TEXT_SX } from './mapping-table-styles';
import { aiUndoSnapshot, candidateMatchesRow } from './sheet-candidates';

/** Row-local draft review using the sheet's existing typography and controls. */
export function MappingRowCandidates({ row }: { row: MappingState }) {
  const { selectSheetCandidate, undoSheetSuggestion, updateMapping, mappingLoading } = useSttmBuilderContext();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const panelId = useId();
  const candidates = row.aiCandidates ?? [];
  if (!candidates.length && !row.aiReviewStatus) return null;
  const current = candidates.find(candidate => candidate.candidate_id === row.selectedAiCandidateId && candidateMatchesRow(row, candidate));
  const disabled = busy || mappingLoading;
  const select = async (id: string, confirm = false) => {
    setBusy(true);
    setError(null);
    try { await selectSheetCandidate(row.id, id, confirm); }
    catch (cause) {
      const detail = cause && typeof cause === 'object' && 'message' in cause ? String(cause.message) : null;
      setError(detail || 'Unable to validate this candidate.');
    }
    finally { setBusy(false); }
  };
  return (
    <AiaBox sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, width: '100%', mt: 0.5, minWidth: 0 }}>
      {row.aiReviewStatus ? (
        <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block', color: row.aiReviewStatus === 'unreviewed' ? '#92400e' : '#475569' }}>
          {row.aiReviewStatus === 'unreviewed' ? 'AI suggested — not reviewed'
            : row.aiReviewStatus === 'confirmed' ? 'User confirmed' : 'Manually edited — draft'}
        </AiaText>
      ) : candidates.length ? <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block', color: '#475569' }}>
        {row.status === 'MAPPED' ? 'Existing mapping preserved' : 'Unresolved — review candidates'}
      </AiaText> : null}
      <AiaBox sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
        {candidates.length ? <AiaButton size="small" variant="text" aria-expanded={open} aria-controls={panelId}
          onClick={() => setOpen(!open)} sx={{ fontFamily: 'inherit', textTransform: 'none', p: 0.25 }}>
          {open ? 'Hide candidates' : 'View candidates'} ({candidates.length})
        </AiaButton> : null}
        {current && row.aiReviewStatus === 'unreviewed' ? <AiaButton size="small" variant="text" disabled={disabled}
          onClick={() => void select(current.candidate_id, true)} sx={{ fontFamily: 'inherit', textTransform: 'none', p: 0.25 }}>
          {busy ? 'Validating…' : 'Confirm mapping'}
        </AiaButton> : null}
        {row.aiUndoSnapshot ? <AiaButton size="small" variant="text" disabled={disabled}
          onClick={() => { setError(null); undoSheetSuggestion(row.id); }} sx={{ fontFamily: 'inherit', textTransform: 'none', p: 0.25 }}>
          Undo AI change
        </AiaButton> : null}
        {row.selectedAiCandidateId ? <AiaButton size="small" variant="text" disabled={disabled}
          onClick={() => updateMapping(row.id, {aiUndoSnapshot: aiUndoSnapshot(row), sourceColumn: null, sourceColumns: [],
            mappingMode: 'source', constantValue: null, attributeName: null, expression: null, rule: 'Direct',
            sourceDependencies: [], valueBindingIds: [], status: 'UNMAPPED', selectedAiCandidateId: null,
            transformationClassification: 'unresolved'})} sx={{ fontFamily: 'inherit', textTransform: 'none', p: 0.25 }}>
          Clear suggestion
        </AiaButton> : null}
      </AiaBox>
      {current?.warnings?.length ? <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block', color: '#92400e' }}>
        Warning: {current.warnings[0]}{current.warnings.length > 1 ? ` (${current.warnings.length} warnings — view candidates)` : ''}
      </AiaText> : null}
      {error ? <AiaText role="alert" sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block', color: '#b91c1c' }}>{error}</AiaText> : null}
      <AiaCollapse in={open}>
        <AiaBox id={panelId} aria-label={`Candidates for ${row.targetColumn}`} sx={{ display: 'grid', gap: 1, mt: 0.75 }}>
          {candidates.map((candidate, index) => {
            const selected = current?.candidate_id === candidate.candidate_id;
            return <AiaBox key={candidate.candidate_id} sx={{ p: 1, border: '1px solid', borderColor: selected ? '#86efac' : '#e2e8f0', borderRadius: '6px', bgcolor: selected ? '#f0fdf4' : 'var(--color-surface)', overflowWrap: 'anywhere' }}>
              <AiaText sx={MAPPING_TABLE_BODY_TEXT_SX}>
                {index + 1}. {selected ? 'Currently selected · ' : ''}{Math.round(candidate.confidence_score * 100)}% · {candidate.mapping_mode === 'attribute' ? 'Firm Value' : candidate.mapping_mode === 'constant' ? 'Constant' : candidate.preprocessing_rule_type || 'Source'}
              </AiaText>
              <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block' }}>{candidate.source_attributes.join(', ') || 'No source columns'}</AiaText>
              {candidate.mapping_mode === 'attribute' || candidate.mapping_mode === 'constant' ? <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block' }}>
                Value: {candidate.mapping_mode === 'attribute' ? `$${candidate.attribute_name || ''}` : candidate.constant_value ?? 'Unavailable'}
              </AiaText> : null}
              {candidate.preprocessing_rule ? <AiaBox component="pre" sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, m: 0, whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{candidate.preprocessing_rule}</AiaBox> : null}
              <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block' }}>{candidate.confidence_reason || 'No reasoning supplied.'}</AiaText>
              {!!candidate.source_dependencies?.length ? <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block' }}>Dependencies: {candidate.source_dependencies.join(', ')}</AiaText> : null}
              {!!candidate.value_binding_ids?.length ? <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block' }}>Values: {candidate.value_binding_ids.join(', ')}</AiaText> : null}
              {[...(candidate.validation_errors ?? []), ...(candidate.warnings ?? [])].map((warning, warningIndex) => <AiaText key={warningIndex} sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, display: 'block', color: '#92400e' }}>{warning}</AiaText>)}
              <AiaButton size="small" variant="outlined" disabled={disabled || selected || candidate.validation_status !== 'valid'}
                onClick={() => void select(candidate.candidate_id)} sx={{ fontFamily: 'inherit', textTransform: 'none', mt: 0.5 }}>
                {selected ? 'Selected' : candidate.validation_status !== 'valid' ? 'Unresolved — cannot select' : busy ? 'Validating…' : 'Use candidate'}
              </AiaButton>
            </AiaBox>;
          })}
        </AiaBox>
      </AiaCollapse>
    </AiaBox>
  );
}
