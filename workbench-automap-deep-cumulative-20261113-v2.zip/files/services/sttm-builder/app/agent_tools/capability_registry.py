from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from collections.abc import Callable, Iterable
from copy import deepcopy
from typing import Any
from uuid import uuid4

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field, ValidationError

from app.agent_runs.models import AssistantIntent, ToolContract, ToolResult, ToolRisk
from app.agent_runs.contracts import (
    AutoMapExecutionSpecV1,
    PlanDecisionV1,
    PlanExecutionStepV1,
    ProjectDecisionV1,
    SourcePreparationSpecV1,
)
from app.agent_runtime.execution import (
    BudgetExceededError,
    ExecutionBudget,
    ExecutionCancelledError,
    TraceEmitter,
    null_trace,
)
from app.agent_runtime.run_knowledge import CATALOG_CANDIDATE, DECISION, TOOL_RESULT, RunKnowledge
from app.agent_tools.contract_reader import normalize_fqn


def _inline_contract_schema(model: type[BaseModel]) -> dict[str, Any]:
    """Expose nested field contracts without dangling local $ref paths in tool schemas."""
    schema = model.model_json_schema()
    definitions = schema.get("$defs", {})
    def inline(value: Any) -> Any:
        if isinstance(value, list):
            return [inline(item) for item in value]
        if isinstance(value, dict):
            if "$ref" in value:
                return inline(definitions[value["$ref"].rsplit("/", 1)[-1]])
            return {key: inline(item) for key, item in value.items() if key != "$defs"}
        return value
    return inline(schema)


def _normalize_mapping_evidence(items: list[Any]) -> list[Any]:
    """Canonicalize an explicit singular reference without inventing a source."""
    normalized = []
    for raw in items:
        if not isinstance(raw, dict):
            normalized.append(raw)
            continue
        item = dict(raw)
        if "transformation" not in item and isinstance(item.get("transformation_rule"), str):
            item["transformation"] = item["transformation_rule"]
        column = item.get("source_column")
        table = item.get("source_table")
        if "source_columns" not in item and isinstance(column, str) and column.strip():
            column = column.strip()
            if "." not in column and isinstance(table, str) and table.strip():
                column = f"{table.strip()}.{column}"
            item["source_columns"] = [column]
        normalized.append(item)
    return normalized


def _auto_map_tool_schema() -> dict[str, Any]:
    schema = _inline_contract_schema(AutoMapExecutionSpecV1)
    schema["properties"]["mapping_evidence"]["items"] = {
        "type": "object",
        "properties": {
            "target_column": {"type": "string", "description": "Exact target column from the verified contract."},
            "source_columns": {"type": "array", "items": {"type": "string"}, "description": "Verified source columns, preferably DATABASE.SCHEMA.TABLE.COLUMN."},
            "mapping_mode": {"type": "string", "description": "direct, transformation, constant or attribute."},
            "constant_value": {"description": "User-supplied or evidence-supported literal for a constant mapping."},
            "transformation": {"type": "string", "description": "Proposed executable Snowflake expression; never a prose rule label."},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "evidence_ids": {"type": "array", "items": {"type": "string"}},
            "reasoning": {"type": "string"},
        },
        "required": ["target_column", "source_columns", "mapping_mode"],
    }
    return schema


def _canonical_source_decision(value: str, source: dict[str, Any]) -> str:
    """A descriptive verified graph list is not a different driving-table choice."""
    driver = str(source.get("driving_source") or "")
    planned = {str(table).upper() for table in [driver, *(source.get("supporting_sources") or [])] if table}
    tables = {token.upper() for token in re.findall(r"[A-Za-z_][\w$]*\.[A-Za-z_][\w$]*\.[A-Za-z_][\w$]*", value)}
    if driver and tables and driver.upper() in tables and tables <= planned:
        return driver
    return value


def _source_preparation_tool_schema() -> dict[str, Any]:
    schema = _inline_contract_schema(SourcePreparationSpecV1)
    schema["properties"]["derived_sources"]["items"] = {
        "type": "object", "properties": {
            "name": {"type": "string"}, "sql": {"type": "string"},
            "base_source_tables": {"type": "array", "items": {"type": "object", "properties": {
                "database": {"type": "string"}, "schema": {"type": "string"}, "table": {"type": "string"}},
                "required": ["database", "schema", "table"]}},
            "is_driving_source": {"type": "boolean", "description": "Use this CTE as the mapping's driving relation."},
            "purpose": {"type": "string"},
        }, "required": ["name", "sql", "base_source_tables"],
    }
    schema["properties"]["filters"]["description"] = "Workspace filter fields: filter_sql (executable WHERE predicate), group_by_sql, order_by_sql. Filters already inside a driving CTE need not be duplicated."
    bindings = schema["properties"]["value_bindings"]["items"]["properties"]
    bindings["placeholder"]["description"] = "Firm Value reference $Name."
    bindings["resolved_value"]["description"] = "The current value explicitly supplied by the user or a current project attribute. If supplied, set resolution_status=resolved and approval_state=approved; never resolve a historical candidate without approval."
    return schema


def _normalize_source_preparation(value: dict[str, Any], *, prompt: str = "") -> dict[str, Any]:
    source = dict(value)
    derived = []
    for raw in source.get("derived_sources") or []:
        item = dict(raw)
        if "name" not in item and "cte_name" in item:
            item["name"] = item["cte_name"]
        if "base_source_tables" not in item and isinstance(item.get("base_table"), str):
            parts = item["base_table"].split(".")
            if len(parts) == 3:
                item["base_source_tables"] = [dict(zip(("database", "schema", "table"), parts))]
        if "is_driving_source" not in item:
            for alias in ("is_driving", "used_as_driving_source", "use_as_driving_source"):
                if alias in item:
                    item["is_driving_source"] = item[alias]
                    break
        derived.append(item)
    source["derived_sources"] = derived
    bindings = []
    for raw in source.get("value_bindings") or []:
        binding = dict(raw)
        if "candidate_value" not in binding and "value" in binding:
            binding["candidate_value"] = binding["value"]
        if not binding.get("name") and re.fullmatch(r"\$?[A-Za-z_][A-Za-z0-9_]*", str(binding.get("placeholder") or "")):
            binding["name"] = str(binding["placeholder"]).lstrip("$")
        if binding.get("name") and not str(binding.get("placeholder") or "").startswith("$"):
            binding["placeholder"] = "$" + str(binding["name"]).lstrip("$")
        binding["source"] = {"user_specified": "user_prompt", "user_provided": "user_prompt"}.get(binding.get("source"), binding.get("source"))
        # A current literal/target pair explicitly present in the request is
        # an available user-supplied value, not a historical-value approval.
        literal = binding.get("value")
        if binding.get("source") == "user_prompt" and isinstance(literal, (str, int, float, bool)):
            text = str(literal)
            quoted = "'" + text.replace("'", "''") + "'"
            explicit = any(re.search(
                rf"(?i)(?:{re.escape(quoted)}\s+AS\s+\"?{re.escape(str(column))}\"?(?![\w$])|"
                rf"(?<![\w$]){re.escape(str(column))}\s*(?:=|:)\s*{re.escape(quoted)}(?![\w$]))", prompt)
                for column in binding.get("target_columns") or [])
            if explicit and not binding.get("resolved_value"):
                binding.update(resolved_value=text, resolution_status="resolved", approval_state="approved",
                               applicability="current_project")
        bindings.append(binding)
    source["value_bindings"] = bindings
    return source


class PlanValidationArguments(BaseModel):
    plan: dict[str, Any] = Field(
        description="Complete evidence-backed plan. Each SQL step must set query_kind and either sql or dynamic_sql.",
        json_schema_extra={"properties": {
            "execution_steps": {"type": "array", "items": PlanExecutionStepV1.model_json_schema()},
            "normalized_intent": {"type": "string"},
            "source_preparation": _source_preparation_tool_schema(),
            "auto_map": _auto_map_tool_schema(),
            "project_decision": _inline_contract_schema(ProjectDecisionV1),
            "decisions": {"type": "array", "items": _inline_contract_schema(PlanDecisionV1)},
            "evidence_ids_used": {"type": "array", "items": {"type": "string"}},
        }},
    )


def only_join_paths_open(review: dict[str, Any] | None) -> bool:
    """A prepared plan with its sources chosen whose blocking findings include missing join paths.

    Such a plan waits on decisions the join checkpoint makes (verified joins,
    earlier confirmations, or a user answer), not on further model research.
    """
    evidence = dict(review or {})
    source = dict(dict(evidence.get("plan_candidate") or {}).get("source_preparation") or {})
    unresolved = [str(value) for value in evidence.get("unresolved") or []]
    return bool(source.get("driving_source") and source.get("supporting_sources")
                and any("join path" in value.casefold() for value in unresolved))

class _RecordedSet(set):
    """A set whose new members are also recorded in conversation knowledge."""

    def __init__(self, record: Callable[[list[str]], None] | None = None) -> None:
        super().__init__()
        self._record = record

    def add(self, value: Any) -> None:
        is_new = value not in self
        super().add(value)
        if is_new and self._record is not None:
            self._record([value])

    def update(self, *groups: Iterable[Any]) -> None:
        values = [value for group in groups for value in group]
        new = [value for value in dict.fromkeys(values) if value not in self]
        super().update(values)
        if new and self._record is not None:
            self._record(new)

    def restore(self, values: Iterable[Any]) -> None:
        """Add members that are already recorded, without re-recording them."""
        super().update(values)


class CapabilityRegistry:
    """Production capability index and the bounded tools exposed to the supervisor.

    The registry is deliberately explicit: a model never receives an unrestricted
    SQL, HTTP, or service-dispatch tool. Every callable has a risk class and a
    host-side authorization boundary.
    """

    # Per-thread "this tool call reached _execute" flag (see _trace_early_refusals).
    _execute_depth = threading.local()

    CONTRACTS = (
        ToolContract(name="inspect_workbench_context", description="Read the authenticated run and UI context.", risk=ToolRisk.READ),
        ToolContract(name="search_catalog", description="Search caller-visible Snowflake table metadata.", risk=ToolRisk.READ, required_scopes=["catalog:read"], durable_reuse=True),
        ToolContract(name="search_catalog_batch", description="Resolve several source/target naming variants in one caller-visible Snowflake metadata scan.", risk=ToolRisk.READ, required_scopes=["catalog:read"], durable_reuse=True),
        ToolContract(name="inspect_table_contract", description="Read a schema-qualified table contract.", risk=ToolRisk.READ, required_scopes=["catalog:read"]),
        ToolContract(name="inspect_table_contracts_batch", description="Read a bounded set of independently verified table contracts in one supervisor turn.", risk=ToolRisk.READ, required_scopes=["catalog:read"]),
        ToolContract(name="profile_table", description="Collect bounded profile metrics inside an approved schema.", risk=ToolRisk.READ, required_scopes=["data:profile"], data_sensitivity="business", timeout_seconds=90, cost_class="medium"),
        ToolContract(name="execute_read_only_sql", description="Execute one bounded SELECT/CTE query against tables authorized or discovered in this run.", risk=ToolRisk.READ, required_scopes=["data:profile"], data_sensitivity="business", timeout_seconds=120, cost_class="medium"),
        ToolContract(name="retrieve_fir_evidence", description="Retrieve exact governed FIR evidence for a target contract.", risk=ToolRisk.READ, required_scopes=["fir:read"], durable_reuse=True),
        ToolContract(name="prepare_migration_evidence", description="Prepare one compact target-contract, stored-semantic, FIR, and precedent evidence package.", risk=ToolRisk.READ, required_scopes=["catalog:read", "semantic:read", "fir:read", "project:read"], durable_reuse=True),
        ToolContract(name="prepare_multi_target_evidence", description="Prepare evidence for several targets, infer cross-mapping dependencies, and stage one combined plan.", risk=ToolRisk.READ, required_scopes=["catalog:read", "semantic:read", "fir:read", "project:read"], cost_class="high"),
        ToolContract(name="list_project_templates", description="Inspect configured target templates before choosing project scope.", risk=ToolRisk.READ, required_scopes=["project:read"], durable_reuse=True),
        ToolContract(name="list_projects", description="List caller-visible migration projects and their status.", risk=ToolRisk.READ, required_scopes=["project:read"]),
        ToolContract(name="search_precedents", description="Rank earlier migration projects by exact target, same-named source tables and project text, with match reasons.", risk=ToolRisk.READ, required_scopes=["project:read"], durable_reuse=True),
        ToolContract(name="get_project_context", description="Read a project, its mappings, and configured precedents.", risk=ToolRisk.READ, required_scopes=["project:read"]),
        ToolContract(name="firm_values_inventory", description="List the firm values the planned target tables use, which the run's project holds, which are missing, and which projects hold them.", risk=ToolRisk.READ, required_scopes=["project:read"]),
        ToolContract(name="import_firm_values", description="Copy firm values from another project into the run's project after the user confirmed it.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"]),
        ToolContract(name="remember_preference", description="Save a standing preference or rule the user stated, for this user or everyone in the project.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"]),
        ToolContract(name="inspect_precedent_mapping", description="Inspect the active SQL lineage, joins, and CTEs of an exact-target historical mapping.", risk=ToolRisk.READ, required_scopes=["project:read"], durable_reuse=True),
        ToolContract(name="validate_migration_plan", description="Validate and stage the Deep supervisor's evidence-backed source-preparation and Auto Map plan before guarded execution.", risk=ToolRisk.READ, required_scopes=["sttm:read"]),
        ToolContract(name="source_mapping", description="Invoke the existing AGT_SOURCE_MAPPING through the prepared Auto Map execution stage.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], executor="execute_migration_workflow"),
        ToolContract(name="transformation_rule", description="Invoke the existing AGT_TRANSFORMATION_RULE only for prepared complex mappings after source selection.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], executor="execute_migration_workflow"),
        ToolContract(name="discover_relationships", description="Read active and semantic relationship candidates for selected tables.", risk=ToolRisk.READ, required_scopes=["catalog:read"], executor="execute_migration_workflow"),
        ToolContract(name="read_stored_semantic_context", description="Read stored semantic views, bundles, and projections already attached to the active workspace; generation is prohibited.", risk=ToolRisk.READ, required_scopes=["semantic:read"]),
        ToolContract(name="workbench_rag", description="Search the existing governed Workbench RAG sources and return cited knowledge results.", risk=ToolRisk.READ, required_scopes=["sttm:read"], durable_reuse=True),
        ToolContract(name="search_run_attachments", description="Retrieve cited passages from parsed files uploaded to this Deep Agent run.", risk=ToolRisk.READ, required_scopes=["sttm:read"]),
        ToolContract(name="sql_analyst", description="Ask Cortex Analyst using an already-stored semantic view; semantic generation is prohibited.", risk=ToolRisk.READ, required_scopes=["semantic:read"]),
        ToolContract(name="validate_derived_source", description="Validate a derived source or CTE without materializing it.", risk=ToolRisk.READ, required_scopes=["sttm:edit"], executor="execute_migration_workflow"),
        ToolContract(name="save_derived_source", description="Save a run-owned derived source draft.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], requires_expected_revision=True, executor="execute_migration_workflow"),
        ToolContract(name="save_join_definition", description="Save a run-owned join definition draft.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], requires_expected_revision=True, executor="execute_migration_workflow"),
        ToolContract(name="save_query_rules", description="Save run-owned filters, grouping, ordering, and source query rules.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], requires_expected_revision=True, executor="execute_migration_workflow"),
        ToolContract(name="compile_mapping_sql", description="Compile mapping SQL through deterministic Workbench validation.", risk=ToolRisk.READ, required_scopes=["sttm:read"], executor="execute_migration_workflow"),
        ToolContract(name="preview_mapping_sql", description="Execute a bounded caller-authorized mapping preview.", risk=ToolRisk.READ, required_scopes=["data:profile"], data_sensitivity="business", cost_class="medium", executor="execute_migration_workflow"),
        ToolContract(name="reconcile_mapping_output", description="Execute row, key, and contract reconciliation gates.", risk=ToolRisk.READ, required_scopes=["data:profile"], data_sensitivity="business", cost_class="high", executor="execute_migration_workflow"),
        ToolContract(name="generate_mapping_tests", description="Generate specialist test candidates and audit target coverage; generation does not execute tests.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], executor="execute_migration_workflow"),
        ToolContract(name="run_mapping_contract_tests", description="Execute current-revision nullability and key assertions with read-only SQL and durable receipts.", risk=ToolRisk.READ, required_scopes=["data:profile", "sttm:read"], data_sensitivity="business", cost_class="high", executor="execute_migration_workflow"),
        ToolContract(name="convert_mapping_to_dbt", description="Create a run-owned dbt conversion artifact.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], executor="execute_migration_workflow"),
        ToolContract(name="inspect_run", description="Read current durable run, plan, budgets, artifacts, and approvals.", risk=ToolRisk.READ, executor="inspect_workbench_context"),
        ToolContract(name="retry_failed_action", description="Retry a classified transient run-owned action using the same idempotency key.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], executor="execute_migration_workflow"),
        ToolContract(name="cancel_run", description="Request cooperative cancellation at the next safe boundary.", risk=ToolRisk.DRAFT_WRITE, executor="control_plane"),
        ToolContract(name="execute_migration_workflow", description="Create or update run-owned draft mappings and execute validation gates.", risk=ToolRisk.DRAFT_WRITE, required_scopes=["sttm:edit"], requires_expected_revision=True, timeout_seconds=1800, cost_class="high"),
        ToolContract(name="prepare_publish_approval", description="Prepare an immutable artifact digest for human approval.", risk=ToolRisk.APPROVAL_REQUIRED, required_scopes=["sttm:publish"], requires_expected_revision=True),
        ToolContract(name="publish_approved_artifact", description="Publish only the exact human-approved artifact revision.", risk=ToolRisk.PUBLISH, required_scopes=["sttm:publish"], requires_expected_revision=True),
    )

    BUSINESS_METADATA: dict[str, dict[str, Any]] = {
        "inspect_workbench_context": {"business_label": "Read current Workbench context", "purpose": "Read authenticated project, page, and authorization scope.", "owning_agent": "supervisor", "prerequisites": ["authenticated user context"], "when_to_use": "First step for migration work.", "when_not_to_use": "Not needed for ordinary conversational answers.", "expected_output": "Authorized scope and current workspace references"},
        "search_catalog": {"business_label": "Discover Snowflake objects", "purpose": "Find caller-visible source and target candidates.", "owning_agent": "catalog discovery", "prerequisites": ["authenticated Snowflake session"], "when_to_use": "When concrete table names are unknown.", "when_not_to_use": "After viable candidates have already been verified.", "expected_output": "Ranked schema-qualified table candidates"},
        "search_catalog_batch": {"business_label": "Resolve source and target candidates", "purpose": "Test bounded business-name variants using one Snowflake metadata scan.", "owning_agent": "catalog discovery", "prerequisites": ["authenticated Snowflake session", "unknown concrete table names"], "when_to_use": "Once when no source or target is selected and several naming variants are plausible.", "when_not_to_use": "After concrete candidates have been verified.", "expected_output": "Candidates grouped by naming variant with one-scan metrics"},
        "inspect_table_contract": {"business_label": "Verify table contract", "purpose": "Inspect columns, data types, nullability, and keys.", "owning_agent": "catalog discovery", "prerequisites": ["schema-qualified candidate"], "when_to_use": "After catalog discovery.", "when_not_to_use": "For filesystem paths or unknown object names.", "expected_output": "Verified table contract"},
        "inspect_table_contracts_batch": {"business_label": "Verify table contracts", "purpose": "Inspect several independent source contracts in one bounded read.", "owning_agent": "catalog discovery", "prerequisites": ["caller-visible schema-qualified candidates"], "when_to_use": "When several source candidates need comparison.", "when_not_to_use": "For tables outside the authenticated catalog or source scope.", "expected_output": "Current contracts and per-table verification results"},
        "retrieve_fir_evidence": {"business_label": "Retrieve governed mapping evidence", "purpose": "Load FIR precedent evidence for target columns.", "owning_agent": "evidence retrieval", "prerequisites": ["verified target contract"], "when_to_use": "Before proposing source mappings.", "when_not_to_use": "For unrelated conversational questions.", "expected_output": "Cited governed evidence"},
        "prepare_migration_evidence": {"business_label": "Prepare migration evidence", "purpose": "Bundle the verified target contract, stored semantic context, FIR cards, and selected precedent projects in one read-only operation.", "owning_agent": "supervisor", "prerequisites": ["verified source and target candidates"], "when_to_use": "Immediately after catalog discovery for a new mapping plan.", "when_not_to_use": "When an unchanged prior-run evidence package is already available.", "expected_output": "Compact evidence package ready for planning and specialist handoff"},
        "prepare_multi_target_evidence": {"business_label": "Prepare evidence for several targets", "purpose": "Prepare each requested target's evidence, infer cross-mapping dependencies from old mappings and governed learnings, and stage one combined multi-mapping plan.", "owning_agent": "supervisor", "prerequisites": ["two or more fully qualified target tables"], "when_to_use": "Once, when a request names several target tables or a whole target schema.", "when_not_to_use": "For a single target; use prepare_migration_evidence.", "expected_output": "Per-target readiness, inferred dependencies, and a staged combined plan"},
        "inspect_precedent_mapping": {"business_label": "Inspect historical mapping design", "purpose": "Compare saved source metadata with active historical SQL lineage and CTEs.", "owning_agent": "evidence retrieval", "prerequisites": ["exact-target precedent found in this run"], "when_to_use": "When the driving source or joins remain unresolved after evidence preparation.", "when_not_to_use": "For unrelated or out-of-scope mappings.", "expected_output": "Bounded historical source, join, CTE, and target-column evidence"},
        "search_precedents": {"business_label": "Find earlier projects to learn from", "purpose": "Rank earlier migration projects that mapped the same targets or used the same kind of source tables (another client's copy of the same source system), with the reason for each match.", "owning_agent": "evidence retrieval", "prerequisites": ["target tables or source tables or a description of the earlier work"], "when_to_use": "When the user refers to earlier work by name or description, or when current evidence lacks joins, CTEs or transformations that a similar earlier project may have solved.", "when_not_to_use": "When the evidence package already lists structural_precedent_projects that answer the need.", "expected_output": "Ranked project ids with match reasons, to pass as precedent_project_ids"},
        "list_projects": {"business_label": "List migration projects", "purpose": "List every caller-visible project with status.", "owning_agent": "evidence retrieval", "prerequisites": ["authenticated user context"], "when_to_use": "When the user asks what projects exist or wants to pick one by name.", "when_not_to_use": "To find precedents for a migration; use search_precedents, which ranks by relevance.", "expected_output": "Project list"},
        "get_project_context": {"business_label": "Read a project", "purpose": "Read one project's mappings and configured precedent links.", "owning_agent": "evidence retrieval", "prerequisites": ["a project id from the user, search_precedents or list_projects"], "when_to_use": "Before reusing or extending a specific project's mappings.", "when_not_to_use": "For ranking many candidate projects.", "expected_output": "Project, mappings and precedent links"},
        "firm_values_inventory": {"business_label": "Check firm values", "purpose": "Say which firm values (record type ids, transaction firm, backup owner, legacy id prefixes, ...) the planned targets use, which this project already holds, which are missing, and which projects hold the missing ones.", "owning_agent": "supervisor", "prerequisites": ["the planned target tables"], "when_to_use": "Once while planning, before asking the user anything about firm values.", "when_not_to_use": "When the plan has no target tables yet.", "expected_output": "Required, held and missing firm values with import sources"},
        "import_firm_values": {"business_label": "Import firm values", "purpose": "Copy firm values from another project into this one.", "owning_agent": "supervisor", "prerequisites": ["firm_values_inventory", "the user confirmed the import (a planning answer or an explicit request)"], "when_to_use": "Only after the user said to import from that project.", "when_not_to_use": "On your own judgement; values differ per firm.", "side_effects": "Creates project firm values (existing ones are kept unless overwrite is confirmed)", "expected_output": "Created, kept and unchanged firm values"},
        "remember_preference": {"business_label": "Remember a preference", "purpose": "Keep a standing rule the user stated so later runs apply it (listed in user_preferences).", "owning_agent": "supervisor", "prerequisites": ["the user asked to remember it, or stated it as a rule that applies beyond this request"], "when_to_use": "Once per stated rule, with scope project when it is about this firm's data and user when it is about how this person works.", "when_not_to_use": "For a one-off answer, a single column choice, or anything already in user_preferences.", "side_effects": "Adds a candidate learning shown in What the agent learned", "expected_output": "The saved preference id"},
        "validate_migration_plan": {"business_label": "Validate migration plan", "purpose": "Schema-check the Deep supervisor's evidence-backed source, target, join, CTE, preprocessing, and Auto Map decisions.", "owning_agent": "supervisor", "prerequisites": ["verified catalog candidates", "inspected contracts", "retrieved evidence"], "when_to_use": "Immediately before delegating a draft mutation workflow.", "when_not_to_use": "Read-only questions or incomplete discovery.", "expected_output": "A host-validated supervisor plan ready for guarded execution"},
        "source_mapping": {"business_label": "Propose source mappings", "purpose": "Generate source-to-target candidates.", "owning_agent": "AGT_SOURCE_MAPPING", "prerequisites": ["verified contracts", "governed evidence"], "when_to_use": "Within the compiled migration workflow.", "when_not_to_use": "Directly from the supervisor.", "side_effects": "Creates run-owned draft artifacts", "expected_output": "Source mapping proposals"},
        "transformation_rule": {"business_label": "Derive transformation rules", "purpose": "Resolve complex, derived, or many-to-one mappings.", "owning_agent": "AGT_TRANSFORMATION_RULE", "prerequisites": ["source mapping proposal", "complex transformation need"], "when_to_use": "Only for complex mappings.", "when_not_to_use": "Simple one-to-one mappings.", "side_effects": "Creates run-owned draft artifacts", "expected_output": "Transformation rules with evidence"},
        "execute_migration_workflow": {"business_label": "Compile migration draft", "purpose": "Create, compile, preview, reconcile, and validate run-owned drafts.", "owning_agent": "migration-workflow", "prerequisites": ["supervisor plan", "verified scope"], "when_to_use": "Through compiled sub-agent delegation only.", "when_not_to_use": "Never expose directly to the supervisor.", "side_effects": "Creates or updates run-owned drafts", "expected_output": "Validated draft and immutable receipts"},
        "generate_mapping_tests": {"business_label": "Generate mapping tests", "purpose": "Create governed test artifacts.", "owning_agent": "test specialist", "prerequisites": ["mapping SQL compiled and validated"], "when_to_use": "After validation gates pass.", "when_not_to_use": "Before mapping SQL compiles.", "side_effects": "Creates run-owned test artifacts"},
        "convert_mapping_to_dbt": {"business_label": "Create dbt artifact", "purpose": "Convert a validated mapping to dbt.", "owning_agent": "dbt specialist", "prerequisites": ["mapping SQL compiled and validated"], "when_to_use": "After validation gates pass.", "when_not_to_use": "Before mapping SQL compiles.", "side_effects": "Creates a run-owned dbt artifact"},
    }

    def __init__(
        self,
        *,
        context_provider: Callable[[], dict[str, Any]],
        workflow_executor: Callable[[list[str], list[str], dict[str, Any] | None], dict[str, Any]],
        workbench: Any | None,
        budget: ExecutionBudget,
        trace: TraceEmitter | None = None,
        allow_direct_mutation: bool = False,
        knowledge: RunKnowledge | None = None,
    ) -> None:
        self._context_provider = context_provider
        self._workflow_executor = workflow_executor
        self._workbench = workbench
        self._budget = budget
        self._trace = trace or null_trace
        self._knowledge = knowledge
        self._catalog_lock = threading.Lock()
        self._catalog_searches: dict[str, ToolResult] = {}
        self._catalog_candidates: _RecordedSet = _RecordedSet(
            self._record_catalog_candidates if knowledge is not None else None
        )
        self._catalog_search_limit = (
            2 if budget.model_limit <= 20 else 3 if budget.model_limit <= 30 else 5
        )
        self._validated_supervisor_plan: dict[str, Any] | None = None
        self._prepared_plan_candidate: dict[str, Any] | None = None
        # Per-target evidence for multi-target plans, keyed by upper-case FQN.
        self._prepared_plan_candidates: dict[str, dict[str, Any]] = {}
        self._multi_target_active = False
        self._prepared_plan_review: dict[str, Any] | None = None
        self._evidence_failure: dict[str, Any] | None = None
        self._plan_validation_failure: dict[str, Any] | None = None
        self._inspected_contracts: set[str] = set()
        self._precedent_targets: set[str] = set()
        self._automatic_evidence_targets: set[str] = set()
        self._plan_validator: Callable[[dict[str, Any]], dict[str, Any]] | None = None
        self._active_run_id: str | None = None
        self._read_cache_lock = threading.Lock()
        self._read_cache: dict[str, ToolResult] = {}
        self._allow_direct_mutation = allow_direct_mutation

    def _plan_state_key(self, run_id: str) -> str:
        return f"plan_state:{run_id}"

    def _persist_plan_state(self) -> None:
        """Keep the validated plan and prepared candidates with the run.

        A budget re-queue starts a new process: without this, the validated
        plan is lost and the supervisor researches every target again.
        """
        if self._knowledge is None or not self._active_run_id:
            return
        self._knowledge.put(DECISION, self._plan_state_key(self._active_run_id), {
            "run_id": self._active_run_id,
            "validated_supervisor_plan": self._validated_supervisor_plan,
            "prepared_plan_candidate": self._prepared_plan_candidate,
            "prepared_plan_candidates": self._prepared_plan_candidates,
        }, provenance={"run_id": self._active_run_id})

    def _restore_plan_state(self, run_id: str) -> None:
        """Restore this run's validated plan after a re-queue; never another run's."""
        if self._knowledge is None or not run_id or self._validated_supervisor_plan is not None:
            return
        stored = self._knowledge.get(DECISION, self._plan_state_key(run_id))
        if not stored or str(stored.get("run_id") or "") != run_id:
            return
        plan = stored.get("validated_supervisor_plan")
        if isinstance(plan, dict) and plan.get("_deep_supervisor_validated"):
            self._validated_supervisor_plan = dict(plan)
        if isinstance(stored.get("prepared_plan_candidate"), dict):
            self._prepared_plan_candidate = dict(stored["prepared_plan_candidate"])
        if isinstance(stored.get("prepared_plan_candidates"), dict):
            self._prepared_plan_candidates = {str(key): dict(value) for key, value in stored["prepared_plan_candidates"].items()
                                              if isinstance(value, dict)}

    def _record_catalog_candidates(self, tables: list[str]) -> None:
        if self._knowledge is None:
            return
        entries: list[tuple[str, dict[str, Any], list[str]]] = []
        for table in tables:
            key = normalize_fqn(table)
            if key.count(".") == 2:
                # Membership does not depend on the column contract; existence
                # and authorization are rechecked whenever the table is used.
                entries.append((key, {"table": key}, []))
        self._knowledge.put_many(CATALOG_CANDIDATE, entries, provenance={"run_id": self._active_run_id})

    def _restore_knowledge(self, trusted_context: dict[str, Any]) -> None:
        """Reload catalog scope verified earlier in this conversation.

        Called with the catalog lock held. Stored candidates are re-authorized
        against the current context; their contracts are revalidated against
        the live catalog when first used in this claim.
        """
        if self._knowledge is None:
            return
        restored = [key for key, _ in self._knowledge.values(CATALOG_CANDIDATE)
                    if self._within_authorized_table_scope(key, trusted_context)]
        stored = [key for key in self._knowledge.stored_contract_keys()
                  if self._within_authorized_table_scope(key, trusted_context)]
        self._catalog_candidates.restore([*restored, *stored])

    def _research_target_sources(
        self,
        target: str,
        prepare_evidence: Callable[..., dict[str, Any]],
        precedent_project_ids: list[str],
        hint_scope: list[str],
        research_summary: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Current sources for one target, translated from its strongest precedent.

        Research evidence (no sources) names the target's exact or
        output-equivalent precedent; an already prepared research summary is
        reused. Its source tables are located in the schema the user asked
        for, by name and column signature. Returns the driving source first,
        or None when there is no precedent or no copy of it in a requested
        schema; the caller then reports the target instead of guessing.
        """
        if self._workbench is None:
            return None
        context = self._context_provider()
        summary = dict(research_summary or {})
        if not summary:
            research = prepare_evidence(source_tables=[], target_table=target, precedent_project_ids=precedent_project_ids)
            summary = dict(dict(research.get("data") or {}).get("research_summary") or {})
        exact = dict(summary.get("strongest_precedent_graph") or {})
        equivalents = list(summary.get("output_equivalent_precedents") or [])
        sttm_id = str(exact.get("sttm_id") or (equivalents[0] if equivalents else {}).get("sttm_id") or "")
        if not sttm_id:
            return None
        try:
            inspection = ToolResult.from_untrusted(self._workbench.inspect_precedent_mapping(
                sttm_id, target, output_equivalent=not exact.get("sttm_id"),
                requested_text=str(context.get("prompt") or ""),
                selected_scope=[*(context.get("authorized_source_scope") or []), *hint_scope],
            ), operation="inspect_precedent_mapping")
        except Exception:  # noqa: BLE001 - the target is reported as needing research
            return None
        data = dict(inspection.data or {})
        requested = next((item for item in data.get("current_schema_counterparts") or []
                          if item.get("named_in_request")), None)
        if requested is None:
            return None
        pairs = [*(requested.get("identical") or []), *(requested.get("different_columns") or [])]
        by_leaf = {str(item["historical_table"]).rsplit(".", 1)[-1]: str(item["current_table"]).upper() for item in pairs}
        historical_driver = str(data.get("sql_driving_source_candidate") or data.get("saved_driving_source") or "")
        driver = by_leaf.get(historical_driver.strip('"').upper().rsplit(".", 1)[-1])
        tables = [str(item["current_table"]).upper() for item in pairs]
        with self._catalog_lock:
            self._catalog_candidates.update(
                table for table in tables if table.count(".") == 2 and self._within_authorized_table_scope(table, context))
        ordered = list(dict.fromkeys([driver, *tables] if driver else tables))
        self._trace("trace.action.completed", "succeeded",
                    f"Selected {len(ordered)} current source(s) for {target.rsplit('.', 1)[-1]} from precedent STTM "
                    f"{sttm_id}: {requested.get('identical_count')} identical in {requested.get('schema')}"
                    + (f", driving source {driver.rsplit('.', 1)[-1]}." if driver else "."),
                    {"trace_id": f"target-sources:{target}", "kind": "decision", "label": "Select sources per target",
                     "details": {"target": target, "precedent_sttm_id": sttm_id, "schema": requested.get("schema"),
                                 "driver": driver, "sources": ordered[:30]}})
        return {"precedent_sttm_id": sttm_id, "schema": requested.get("schema"), "driver": driver,
                "identical_count": requested.get("identical_count"),
                "different_columns": [item["current_table"] for item in requested.get("different_columns") or []],
                "sources": [table for table in ordered if table]}

    def _settle_target_joins(self, target: str, prepared: dict[str, Any]) -> dict[str, Any]:
        """Resolve one target's open join paths while several targets are prepared together.

        The same decisions the single-target join checkpoint makes, in the same
        order: a data-verified path above the confidence and margin thresholds
        is applied (when auto-apply is on), then a join the user confirmed
        earlier for these (or identically shaped) tables. A table that neither
        connects is left out of this target under the ``exclude`` policy, so
        the other targets are not held back; its columns become reviewable
        gaps and the decision is listed with the target. Under ``ask`` the
        target stays in needs_research. Every step is traced.
        """
        from app.agent_tools.join_research import research_questions, table_name

        workbench = self._workbench
        if workbench is None or not self._prepared_plan_candidate:
            return {}
        context = self._context_provider()
        state = {"run_id": context.get("run_id")}
        policy = str(getattr(getattr(workbench, "_settings", None), "migration_agent_multi_target_unjoined_policy", "exclude"))
        source = dict(self._prepared_plan_candidate.get("source_preparation") or {})
        driver = table_name(source.get("driving_source"))
        contracts: dict[str, dict[str, Any]] = {}
        tables = [source.get("driving_source"), *(source.get("supporting_sources") or [])]
        tables.extend(edge.get(side) for edge in dict(dict(prepared.get("data") or {}).get("relationship_graph") or {}).get("edges") or []
                      if isinstance(edge, dict) for side in ("left_table", "right_table"))
        for table in dict.fromkeys(table_name(value) for value in tables if value):
            try:
                inspected = workbench.inspect_table_contract(table)
            except Exception:  # noqa: BLE001 - an unreadable table cannot carry a join
                continue
            if getattr(inspected, "status", "") == "succeeded":
                contracts[table] = dict(inspected.data or {})
        questions = research_questions(prepared, contracts)
        auto = bool(workbench.auto_apply_verified_joins()) if callable(getattr(workbench, "auto_apply_verified_joins", None)) else False
        joins: list[dict[str, Any]] = []
        applied: list[dict[str, str]] = []
        resolved_tables = {driver}
        remaining: list[dict[str, Any]] = []
        for question in questions:
            best = next((option for option in list(question.get("options") or [])[:3] if option.get("recommended")), None)
            if auto and best and best.get("joins"):
                joins.extend(best["joins"])
                resolved_tables.update(table_name(join.get(side)) for join in best["joins"] for side in ("left_table", "right_table"))
                applied.append({"table": str(question.get("target")), "decision": "verified", "confidence": best.get("confidence")})
                if callable(getattr(workbench, "record_auto_resolved_join", None)):
                    workbench.record_auto_resolved_join(state, question, best)
            else:
                remaining.append(question)
        # Earlier confirmations may chain (A→B→driver): repeat while tables resolve.
        remember = getattr(workbench, "remembered_join_paths", None)
        while remaining and callable(remember):
            found = remember(state, [str(question.get("target") or "") for question in remaining], sorted(resolved_tables))
            progressed = False
            still: list[dict[str, Any]] = []
            for question in remaining:
                key = table_name(question.get("target"))
                path = found.get(key)
                if path and path.get("joins"):
                    joins.extend(path["joins"])
                    resolved_tables.add(key)
                    applied.append({"table": key, "decision": "remembered"})
                    if callable(getattr(workbench, "record_remembered_join", None)):
                        workbench.record_remembered_join(state, key, path)
                    progressed = True
                else:
                    still.append(question)
            remaining = still
            if not progressed:
                break
        excluded = [str(question.get("target") or "") for question in remaining]
        resolution = {"applied": applied, "left_out": [value.rsplit(".", 1)[-1] for value in excluded], "policy": policy}
        if excluded and policy != "exclude":
            return {"status": "needs_input", "join_resolution": resolution}
        if not joins and not excluded:
            return {}
        validation = self.apply_reviewed_join_path(joins, excluded=excluded)
        if validation.get("status") != "succeeded" and joins:
            # A reused join that no longer fits leaves only the verified ones.
            verified = [join for question in questions for option in list(question.get("options") or [])[:1]
                        if auto and option.get("recommended") for join in option.get("joins") or []]
            dropped = [str(question.get("target") or "") for question in questions
                       if not (auto and any(option.get("recommended") for option in list(question.get("options") or [])[:1]))]
            validation = self.apply_reviewed_join_path(verified, excluded=dropped)
            resolution["left_out"] = [value.rsplit(".", 1)[-1] for value in dropped]
            resolution["applied"] = [item for item in applied if item["decision"] == "verified"]
        if excluded:
            self._trace("trace.action.completed", "needs_review",
                        f"Left {', '.join(resolution['left_out'])} out of {target.rsplit('.', 1)[-1]}: no verified or "
                        "earlier-confirmed join connects it; its columns are listed for review.",
                        {"trace_id": f"multi-target-joins:{target}", "kind": "decision", "label": "Settle joins per target",
                         "details": {"target": target, **resolution}})
        return {**validation, "join_resolution": resolution}

    def prepare_evidence_from_precedent_design(self) -> dict[str, Any] | None:
        """Host fallback after a stalled source decision: use the precedent's design on current tables.

        Takes the target of the pending plan review, selects the current copies
        of its strongest precedent's sources in the requested schema, and
        prepares evidence with them (driving source first). Every step is a
        normal traced tool call; the plan still goes through host validation.
        """
        review = dict(self._prepared_plan_review or {})
        target = str(review.get("target_table") or "").strip('"').upper()
        prepare = getattr(self, "_prepare_evidence", None)
        if not target or not callable(prepare):
            return None
        research = self._research_target_sources(
            target, prepare, [], [], research_summary=dict(review.get("research_summary") or {}))
        if not research or not research.get("sources"):
            return None
        return prepare(source_tables=list(research["sources"]), target_table=target, precedent_project_ids=[])

    def _precedent_search_defaults(
        self, query: str, source_tables: list[str], target_tables: list[str],
    ) -> tuple[str, list[str], list[str]]:
        """Fill precedent-search arguments the model left empty from the run itself.

        An empty search can only return nothing. The user's own request and the
        caller-visible tables already resolved in this run are the best
        description of the work, so they stand in for omitted arguments.
        """
        context = self._context_provider()
        query = query.strip() or str(context.get("prompt") or "")
        with self._catalog_lock:
            known = sorted(str(value) for value in self._catalog_candidates)
        if not target_tables:
            named = [str(value).strip('"').upper() for value in context.get("prompt_named_targets") or []]
            for name in named:
                # A name may be a leaf, SCHEMA.TABLE or a full FQN; match on its trailing parts.
                matches = [table for table in known if table == name or table.endswith("." + name)]
                target_tables.extend(matches or [name])
            target_tables = list(dict.fromkeys(target_tables))
        if not source_tables:
            target_leaves = {value.rsplit(".", 1)[-1] for value in target_tables}
            source_tables = [table for table in known if table.rsplit(".", 1)[-1] not in target_leaves]
        return query, source_tables, target_tables

    def _durable_key(self, name: str, safe_input: dict[str, Any] | None) -> str:
        context = self._context_provider()
        signature = {
            "tool": name,
            "input": safe_input or {},
            # The same input can legitimately produce different results under
            # another effort policy or authorization scope.
            "effort": context.get("effort"),
            "schemas": sorted(str(value).upper() for value in context.get("authorized_schemas") or []),
        }
        encoded = json.dumps(signature, sort_keys=True, default=str, separators=(",", ":"))
        return f"{name}:{hashlib.sha256(encoded.encode('utf-8')).hexdigest()}"

    @staticmethod
    def _result_tables(result: ToolResult, safe_input: dict[str, Any] | None) -> list[str]:
        """Tables whose current contracts a read result was derived from."""
        tables: list[str] = [
            ref.split(":", 1)[1] for ref in result.evidence_refs if ref.startswith("table_contract:")
        ]
        for payload in (safe_input or {}, result.data or {}):
            for key in ("table_fqn", "target_table"):
                if isinstance(payload.get(key), str):
                    tables.append(payload[key])
            for key in ("source_tables", "table_fqns"):
                if isinstance(payload.get(key), list):
                    tables.extend(str(value) for value in payload[key])
        return sorted({normalize_fqn(value) for value in tables if str(value).count(".") == 2})

    def begin_run(self, trusted_context: dict[str, Any]) -> None:
        """Reset run-local caches and restore only server-verified catalog scope."""
        next_run_id = str(trusted_context.get("run_id") or "")
        if self._active_run_id is not None and self._active_run_id != next_run_id:
            self._validated_supervisor_plan = None
            self._prepared_plan_candidate = None
            self._prepared_plan_candidates = {}
            self._prepared_plan_review = None
            self._evidence_failure = None
        self._active_run_id = next_run_id
        self._prepared_plan_review = None
        self._evidence_failure = None
        with self._catalog_lock:
            self._catalog_searches.clear()
            self._catalog_candidates.clear()
            self._inspected_contracts.clear()
            self._precedent_targets.clear()
            self._automatic_evidence_targets.clear()
            prior = dict(trusted_context.get("page_context") or {}).get(
                "trusted_prior_run_evidence"
            ) or []

            def collect(value: Any, key: str = "") -> None:
                if isinstance(value, dict):
                    for child_key, child in value.items():
                        collect(child, str(child_key).casefold())
                elif isinstance(value, list):
                    for child in value:
                        collect(child, key)
                elif key in {"table", "table_fqn", "source_table", "target_table", "candidates"}:
                    candidate = str(value).strip('"').upper()
                    if self._within_authorized_table_scope(candidate, trusted_context):
                        self._catalog_candidates.add(candidate)

            collect(prior)
            self._restore_knowledge(trusted_context)
        self._restore_plan_state(next_run_id)
        with self._read_cache_lock:
            self._read_cache.clear()

    def prepare_configured_target(self) -> dict[str, Any] | None:
        """Resolve an exact requested mapping through caller-visible target templates.

        Ambiguous or unavailable template targets remain a supervisor decision.
        This is a read-only fast path; the evidence builder still checks the
        physical contract, current authority, and complete source readiness.
        """
        context = self._context_provider()
        requested = [
            str(value).strip().upper()
            for value in context.get("requested_mappings") or []
            if str(value).strip()
        ]
        if (
            str(context.get("intent") or "") != AssistantIntent.NEW_MIGRATION_TASK.value
            or not requested
            or len(set(requested)) != len(requested)
            or self._workbench is None
            or str(dict(context.get("page_context") or {}).get("continuation_kind") or "") in {"READ_ONLY_SQL", "READ_ONLY_QA"}
        ):
            return None
        available = {tool.name: tool for tool in self.tools()}
        templates = available["list_project_templates"].invoke({})
        if templates.get("status") != "succeeded":
            return None
        matches: dict[str, set[str]] = {name: set() for name in requested}
        for template in dict(templates.get("data") or {}).get("templates") or []:
            for target in template.get("available_targets") or []:
                fqn = str(target.get("physical_fqn") or "").strip('"').upper()
                names = {
                    str(target.get("table_name") or "").upper(),
                    str(target.get("logical_target_key") or "").upper(),
                    str(target.get("logical_target_key") or "").split(".")[-1].upper(),
                }
                if (
                    fqn.count(".") == 2
                    and self._within_authorized_table_scope(fqn, context)
                ):
                    for name in requested:
                        if name in names:
                            matches[name].add(fqn)
        if any(len(matches[name]) != 1 for name in requested):
            return None
        selected = [next(iter(matches[name])) for name in requested]
        if len(set(selected)) != len(selected):
            return None
        candidates: list[dict[str, Any]] = []
        result: dict[str, Any] | None = None
        for target in selected:
            with self._catalog_lock:
                self._precedent_targets.add(target)
            result = available["inspect_table_contract"].invoke({"table_fqn": target})
            if result.get("status") != "succeeded":
                if len(selected) > 1:
                    self._prepared_plan_candidate = None
                    self._validated_supervisor_plan = None
                return result
            if len(selected) > 1:
                prepared = available["prepare_migration_evidence"].invoke({
                    "source_tables": [], "target_table": target, "precedent_project_ids": [],
                })
                if prepared.get("status") != "succeeded" or not isinstance(
                    dict(prepared.get("data") or {}).get("plan_candidate"), dict
                ):
                    self._prepared_plan_candidate = None
                    self._validated_supervisor_plan = None
                    return prepared
                candidates.append(dict(prepared["data"]["plan_candidate"]))
        if len(selected) > 1:
            combined = dict(candidates[0])
            combined["mapping_specs"] = [
                {
                    "mapping_key": re.sub(r"[^a-z0-9]+", "_", name.casefold()).strip("_"),
                    "target_table": target,
                    "source_preparation": candidate["source_preparation"],
                }
                for name, target, candidate in zip(requested, selected, candidates, strict=True)
            ]
            combined["auto_map"] = {
                **dict(combined.get("auto_map") or {}),
                "requested_mappings": list(context.get("requested_mappings") or []),
            }
            combined["evidence_ids_used"] = list(dict.fromkeys(
                evidence for candidate in candidates
                for evidence in candidate.get("evidence_ids_used") or []
            ))
            self._prepared_plan_candidate = combined
            self._validated_supervisor_plan = None
            self.validate_prepared_plan()
        return result

    def _search_catalog(self, search_term: str, limit: int) -> ToolResult:
        """Bound broad discovery once the run already has viable candidates.

        The supervisor still chooses its own search terms. This host-side ceiling
        prevents a model loop from repeatedly scanning account metadata after it
        has enough evidence to inspect and rank concrete tables.
        """
        key = " ".join(search_term.strip().casefold().split())
        with self._catalog_lock:
            cached = self._catalog_searches.get(key)
            if cached is not None:
                return cached.model_copy(deep=True)
            if (
                len(self._catalog_searches) >= self._catalog_search_limit
                and len(self._catalog_candidates) >= 2
            ):
                return ToolResult(
                    status="succeeded",
                    summary="Catalog discovery is complete; rank the verified candidates already returned.",
                    data={
                        "searches_used": len(self._catalog_searches),
                        "candidate_count": len(self._catalog_candidates),
                        "discovery_complete": True,
                    },
                    metrics={"searches_used": len(self._catalog_searches)},
                )

        raw_result = (
            self._workbench.search_catalog(search_term, limit)
            if self._workbench
            else ToolResult(
                status="failed",
                summary="Catalog discovery is unavailable.",
                error_code="capability_unavailable",
            )
        )
        result = ToolResult.from_untrusted(raw_result, operation="search_catalog")
        with self._catalog_lock:
            self._catalog_searches[key] = result.model_copy(deep=True)
            context = self._context_provider()
            for candidate in result.data.get("candidates") or []:
                if (
                    isinstance(candidate, dict)
                    and candidate.get("table")
                    and self._within_authorized_table_scope(str(candidate["table"]), context)
                ):
                    self._catalog_candidates.add(str(candidate["table"]).upper())
        return result

    @staticmethod
    def _within_authorized_table_scope(candidate: str, context: dict[str, Any]) -> bool:
        """Catalog/RAG evidence must never expand the run's table authority."""
        normalized = str(candidate).strip('"').upper()
        if normalized.count(".") != 2:
            return False
        explicitly_authorized = {
            str(value).strip('"').upper()
            for value in [
                *(context.get("authorized_source_scope") or []),
                *(context.get("authorized_target_scope") or []),
            ]
        }
        if normalized in explicitly_authorized:
            return True
        authorized_schemas = {
            str(value).strip('"').upper()
            for value in context.get("authorized_schemas") or []
        }
        # Some internal callers/tests use a pre-authorized Snowflake session
        # without declaring an additional run scope. Preserve that established
        # behavior; when a run scope is declared, enforce it strictly.
        if not authorized_schemas:
            return True
        return ".".join(normalized.split(".")[:2]) in authorized_schemas

    @staticmethod
    def _result_preview(data: dict[str, Any], *, limit: int = 12_000) -> dict[str, Any] | str:
        """Keep authorized tool evidence inspectable without bloating the event stream."""
        try:
            encoded = json.dumps(data, default=str, separators=(",", ":"))
        except (TypeError, ValueError):
            return "Result preview is unavailable."
        if len(encoded) <= limit:
            return data
        return f"{encoded[:limit]}… [truncated; full result remains in the durable run state]"

    def _execute(
        self,
        name: str,
        operation: Callable[[], Any],
        *,
        safe_input: dict[str, Any] | None = None,
        cache_read: bool = False,
    ) -> dict[str, Any]:
        # Marks this thread's tool call as recorded (see _trace_early_refusals).
        self._execute_depth.value = 1
        contract = next((item for item in self.CONTRACTS if item.name == name), None)
        responsibility = {
            **(contract.model_dump(mode="json") if contract else {}),
            **self.BUSINESS_METADATA.get(name, {}),
        }
        label = str(responsibility.get("business_label") or name.replace("_", " ").capitalize())
        intent = str(self._context_provider().get("intent") or AssistantIntent.NEW_MIGRATION_TASK.value)
        allowed = {str(value) for value in responsibility.get("allowed_intents") or []}
        if allowed and intent not in allowed:
            return ToolResult(
                status="denied",
                summary=f"{label} is not compatible with the current {intent} intent.",
                error_code="intent_tool_mismatch",
            ).model_dump(mode="json")
        activity = {
            "owning_specialist": responsibility.get("owning_agent"),
            "why_selected": responsibility.get("purpose"),
            "risk": responsibility.get("risk"),
        }
        cache_key = ""
        durable_key = ""
        reuse_scope = "run"
        if cache_read:
            cache_key = f"{name}:{json.dumps(safe_input or {}, sort_keys=True, default=str, separators=(',', ':'))}"
            with self._read_cache_lock:
                cached = self._read_cache.get(cache_key)
            if self._knowledge is not None and contract is not None and contract.durable_reuse:
                durable_key = self._durable_key(name, safe_input)
                if cached is None:
                    # Confirm, in one batched read, every contract the stored
                    # result was derived from before trusting it.
                    self._knowledge.ensure_verified(self._knowledge.dependencies(TOOL_RESULT, durable_key))
                    stored = self._knowledge.get(TOOL_RESULT, durable_key)
                    if stored is not None:
                        try:
                            cached = ToolResult.model_validate(stored.get("result") or {})
                        except ValidationError:
                            cached = None
                        if cached is not None:
                            reuse_scope = "conversation"
                            with self._read_cache_lock:
                                self._read_cache[cache_key] = cached.model_copy(deep=True)
            if cached is not None:
                self._budget.record_cache_hit()
                self._trace(
                    "tool.reused",
                    "succeeded",
                    f"Reused the verified {name.replace('_', ' ')} result from this {reuse_scope}.",
                    {
                        "trace_id": f"tool:{name}:reused:{uuid4().hex}",
                        "kind": "tool",
                        "label": label,
                        **activity,
                        "budget_cost": 0,
                        "reuse_scope": reuse_scope,
                        "sanitized_input": safe_input or {},
                        "evidence_refs": cached.evidence_refs,
                        "artifact_refs": cached.artifact_refs,
                        "metrics": {**cached.metrics, "cache_hit": True},
                        "result_preview": self._result_preview(cached.data),
                    },
                )
                return cached.model_dump(mode="json")
        trace_id = f"tool:{name}:{uuid4().hex}"
        self._trace(
            "tool.started",
            "running",
            f"{name.replace('_', ' ').capitalize()} started.",
            {
                "trace_id": trace_id,
                "kind": "tool",
                "label": label,
                **activity,
                "budget_cost": 1,
                "sanitized_input": safe_input or {},
            },
        )
        event_type = "tool.completed"
        event_status = "succeeded"
        started_at = time.perf_counter()
        budget_boundary: BudgetExceededError | None = None
        try:
            value = operation()
            result = ToolResult.from_untrusted(value, operation=name)
        except ExecutionCancelledError:
            result = ToolResult(
                status="failed",
                summary=f"{name.replace('_', ' ').capitalize()} stopped because the run was cancelled.",
                error_code="execution_cancelled",
            )
            event_type = "tool.cancelled"
            event_status = "cancelled"
        except BudgetExceededError as exc:
            # Traced as a failed call, then raised: the run continues in its
            # next bounded phase from the checkpoint instead of carrying on
            # with this tool's work (a target's evidence, say) silently missing.
            budget_boundary = exc
            result = ToolResult(
                status="failed",
                summary=f"{name.replace('_', ' ').capitalize()} stopped at the run's execution budget.",
                error_code="budget_exhausted",
            )
        except PermissionError as exc:
            result = ToolResult(status="denied", summary=str(exc), error_code="authorization_denied")
        except Exception as exc:
            result = ToolResult(
                status="failed",
                summary=f"{name.replace('_', ' ').capitalize()} failed safely.",
                error_code=str(getattr(exc, "error_code", type(exc).__name__)),
            )
        if event_type != "tool.cancelled" and result.status != "succeeded":
            event_type = "tool.failed"
            event_status = result.status
        if cache_read and cache_key and result.status == "succeeded":
            with self._read_cache_lock:
                self._read_cache[cache_key] = result.model_copy(deep=True)
            if durable_key and self._knowledge is not None:
                self._knowledge.put(
                    TOOL_RESULT, durable_key, {"result": result.model_dump(mode="json")},
                    depends_on_tables=self._result_tables(result, safe_input),
                    provenance={"tool": name, "input": safe_input or {}, "run_id": self._active_run_id},
                )
        self._trace(
            event_type,
            event_status,
            result.summary,
            {
                "trace_id": trace_id,
                "kind": "tool",
                "label": label,
                **activity,
                "budget_cost": 1,
                "artifact_refs": result.artifact_refs,
                "evidence_refs": result.evidence_refs,
                "metrics": {
                    **result.metrics,
                    "duration_ms": round((time.perf_counter() - started_at) * 1000),
                },
                "error_code": result.error_code,
                "result_preview": self._result_preview(result.data),
            },
        )
        if budget_boundary is not None:
            raise budget_boundary
        return result.model_dump(mode="json")

    def tools(self) -> list[StructuredTool]:
        def prepare_verified_target_evidence() -> dict[str, Any] | None:
            """Use an unambiguous verified target to recover its full source graph."""
            context = self._context_provider()
            if (
                str(context.get("intent") or "") != AssistantIntent.NEW_MIGRATION_TASK.value
                or str(dict(context.get("page_context") or {}).get("continuation_kind") or "") in {"READ_ONLY_SQL", "READ_ONLY_QA"}
                or self._validated_supervisor_plan is not None
                or len(context.get("requested_mappings") or []) > 1
                # Several named targets are prepared together by
                # prepare_multi_target_evidence; one inspected contract must
                # not trigger single-target evidence for whichever came first.
                or self._multi_target_active
                or len(context.get("prompt_named_targets") or []) > 1
            ):
                return None
            with self._catalog_lock:
                known_targets = {
                    str(value).strip('"').upper()
                    for value in context.get("authorized_target_scope") or []
                } | self._precedent_targets
                ready = sorted(self._inspected_contracts & known_targets)
                if len(ready) != 1 or ready[0] in self._automatic_evidence_targets:
                    return None
                target = ready[0]
                self._automatic_evidence_targets.add(target)
            return prepare_migration_evidence([], target)

        def inspect_workbench_context() -> dict[str, Any]:
            """Inspect the user request, page context, authorized scope, and run budgets."""
            return self._execute(
                "inspect_workbench_context",
                lambda: ToolResult(status="succeeded", summary="Read the authenticated Workbench context.", data=self._context_provider()),
            )

        def search_catalog(search_term: str, limit: int = 10) -> dict[str, Any]:
            """Search caller-visible Snowflake table metadata for source or target candidates."""
            bounded_limit = max(1, min(limit, 25))
            return self._execute(
                "search_catalog",
                lambda: self._search_catalog(search_term, bounded_limit),
                safe_input={"search_term": search_term, "limit": bounded_limit},
                cache_read=True,
            )

        def search_catalog_batch(search_terms: list[str], limit_per_term: int = 8) -> dict[str, Any]:
            """Resolve up to eight source/target naming variants with one metadata scan."""
            terms = list(dict.fromkeys(
                " ".join(str(term).strip().split())
                for term in search_terms
                if str(term).strip()
            ))[:8]
            bounded_limit = max(1, min(limit_per_term, 15))
            def discover() -> ToolResult:
                result = ToolResult.from_untrusted(
                    self._workbench.search_catalog_batch(terms, bounded_limit) if self._workbench else ToolResult(status="failed", summary="Catalog discovery is unavailable.", error_code="capability_unavailable"),
                    operation="search_catalog_batch",
                )
                with self._catalog_lock:
                    context = self._context_provider()
                    self._catalog_candidates.update(
                        str(value).upper()
                        for value in result.data.get("candidates") or []
                        if self._within_authorized_table_scope(str(value), context)
                    )
                return result
            return self._execute(
                "search_catalog_batch",
                discover,
                safe_input={"search_terms": terms, "limit_per_term": bounded_limit},
                cache_read=True,
            )

        def inspect_table_contract(table_fqn: str) -> dict[str, Any]:
            """Read columns, types, nullability, and keys for a schema-qualified table."""
            result = self._execute(
                "inspect_table_contract",
                lambda: self._workbench.inspect_table_contract(table_fqn) if self._workbench else ToolResult(status="failed", summary="Table inspection is unavailable.", error_code="capability_unavailable"),
                safe_input={"table_fqn": table_fqn},
                cache_read=True,
            )
            context = self._context_provider()
            if result.get("status") == "succeeded" and self._within_authorized_table_scope(table_fqn, context):
                with self._catalog_lock:
                    verified = str(table_fqn).strip('"').upper()
                    self._inspected_contracts.add(verified)
                    self._catalog_candidates.add(verified)
                prepared = prepare_verified_target_evidence()
                if prepared is not None:
                    result["prepared_evidence"] = {
                        "status": prepared.get("status"),
                        "summary": prepared.get("summary"),
                        "plan_validation": dict(prepared.get("data") or {}).get("plan_validation"),
                    }
            return result

        def inspect_table_contracts_batch(table_fqns: list[str]) -> dict[str, Any]:
            """Compare independent caller-visible source contracts in one turn."""
            tables = list(dict.fromkeys(str(value).strip('"').upper() for value in table_fqns if str(value).strip()))
            limit = int(getattr(getattr(self._workbench, "_settings", None),
                                "migration_agent_contract_batch_limit", 8))
            if not tables or len(tables) > limit:
                return ToolResult(status="failed", summary=f"Select between 1 and {limit} tables for contract inspection.",
                                  error_code="contract_batch_limit").model_dump(mode="json")
            context = self._context_provider()
            with self._catalog_lock:
                known = set(self._catalog_candidates)
                known.update(str(value).strip('"').upper() for value in
                             (context.get("authorized_source_scope") or []) + (context.get("authorized_target_scope") or []))
                known.update(str(value).strip('"').upper() for value in
                             dict(self._prepared_plan_review or {}).get("historical_source_candidates") or [])
            unknown = [table for table in tables
                       if table not in known or not self._within_authorized_table_scope(table, context)]
            if unknown:
                return ToolResult(status="needs_input",
                                  summary=("Inspect only current caller-visible table candidates. Find these tables "
                                           "with search_catalog_batch first."),
                                  data={"unknown_tables": unknown},
                                  error_code="unverified_evidence_selection").model_dump(mode="json")

            def inspect() -> ToolResult:
                if self._workbench is None:
                    return ToolResult(status="failed", summary="Table inspection is unavailable.",
                                      error_code="capability_unavailable")
                contracts = []
                failures = []
                for table in tables:
                    try:
                        item = ToolResult.from_untrusted(
                            self._workbench.inspect_table_contract(table), operation="inspect_table_contract"
                        )
                    except Exception as exc:
                        failures.append({"table": table, "error": type(exc).__name__})
                        continue
                    if item.status == "succeeded":
                        contracts.append({"table": table, **item.data})
                    else:
                        failures.append({"table": table, "error_code": item.error_code})
                return ToolResult(
                    status="succeeded" if contracts else "failed",
                    summary=f"Verified {len(contracts)} of {len(tables)} current table contract(s).",
                    data={"contracts": contracts, "failures": failures},
                    metrics={"requested_count": len(tables), "verified_count": len(contracts)},
                    evidence_refs=[f"table_contract:{item['table']}" for item in contracts],
                )

            result = self._execute(
                "inspect_table_contracts_batch", inspect,
                safe_input={"table_fqns": tables}, cache_read=True,
            )
            if result.get("status") == "succeeded":
                with self._catalog_lock:
                    for item in dict(result.get("data") or {}).get("contracts") or []:
                        table = str(item.get("table") or "").upper()
                        self._inspected_contracts.add(table)
                        self._catalog_candidates.add(table)
                prepared = prepare_verified_target_evidence()
                if prepared is not None:
                    result["prepared_evidence"] = {
                        "status": prepared.get("status"),
                        "summary": prepared.get("summary"),
                        "plan_validation": dict(prepared.get("data") or {}).get("plan_validation"),
                    }
            return result

        def profile_table(table_fqn: str) -> dict[str, Any]:
            """Collect bounded metadata-only profile metrics for a table in an approved schema."""
            return self._execute(
                "profile_table",
                lambda: self._workbench.profile_table(self._context_provider(), table_fqn) if self._workbench else ToolResult(status="failed", summary="Table profiling is unavailable.", error_code="capability_unavailable"),
                safe_input={"table_fqn": table_fqn},
            )

        def execute_read_only_sql(sql: str, max_rows: int = 20) -> dict[str, Any]:
            """Run a generated SELECT/CTE as a bounded caller-authorized preview."""
            configured_limit = int(getattr(self._workbench, "_sql_preview_max_rows", 20))
            bounded_rows = max(1, min(max_rows, configured_limit, 1000))
            context = self._context_provider()
            allowed_tables = {
                str(value).strip('"').upper()
                for value in [
                    *(context.get("authorized_source_scope") or []),
                    *(context.get("authorized_target_scope") or []),
                    *self._catalog_candidates,
                ]
                if str(value).count(".") == 2
            }
            safe_query = sql.strip()
            return self._execute(
                "execute_read_only_sql",
                lambda: self._workbench.execute_read_only_sql(
                    context,
                    safe_query,
                    max_rows=bounded_rows,
                    allowed_tables=allowed_tables,
                ) if self._workbench else ToolResult(
                    status="failed",
                    summary="Read-only SQL execution is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={
                    "sql_preview": re.sub(r"'(?:''|[^'])*'", "'<redacted>'", safe_query)[:12_000],
                    "max_rows": bounded_rows,
                },
            )

        def retrieve_fir_evidence(target_table: str, target_columns: list[str]) -> dict[str, Any]:
            """Retrieve exact governed FIR evidence for target columns before proposing mappings."""
            return self._execute(
                "retrieve_fir_evidence",
                lambda: self._workbench.retrieve_fir_evidence(self._context_provider(), target_table, target_columns) if self._workbench else ToolResult(status="failed", summary="FIR retrieval is unavailable.", error_code="capability_unavailable"),
                safe_input={"target_table": target_table, "target_columns": target_columns},
                cache_read=True,
            )

        def prepare_migration_evidence(
            source_tables: list[str],
            target_table: str,
            precedent_project_ids: list[str] | None = None,
        ) -> dict[str, Any]:
            """Bundle target contract, stored semantics, FIR, and selected precedents."""
            context = self._context_provider()
            # Only the first source is meaningful by position (it defines the
            # row grain); a canonical order for the rest lets an identical
            # selection reuse the stored evidence instead of rebuilding it.
            listed = list(dict.fromkeys(str(value).strip().strip('"').upper() for value in source_tables or []
                                        if str(value).strip()))
            source_tables = listed[:1] + sorted(listed[1:])
            selected = [*source_tables, target_table]
            known_tables = {
                str(value).strip('"').upper()
                for value in [
                    *(context.get("authorized_source_scope") or []),
                    *(context.get("authorized_target_scope") or []),
                    *self._catalog_candidates,
                ]
                if str(value).count(".") == 2
                and self._within_authorized_table_scope(str(value), context)
            }
            unknown = sorted({
                value for value in selected
                if str(value).strip('"').upper() not in known_tables
            })
            if unknown:
                return ToolResult(
                    status="needs_input",
                    summary="Migration evidence can only be prepared for verified table candidates.",
                    data={"unknown_tables": unknown},
                    error_code="unverified_evidence_selection",
                ).model_dump(mode="json")
            projects = list(dict.fromkeys(precedent_project_ids or []))[:3]
            result = self._execute(
                "prepare_migration_evidence",
                lambda: self._workbench.prepare_migration_evidence(
                    context,
                    source_tables=source_tables,
                    target_table=target_table,
                    precedent_project_ids=projects,
                ) if self._workbench else ToolResult(
                    status="failed",
                    summary="Migration evidence preparation is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={
                    "source_tables": source_tables,
                    "target_table": target_table,
                    "precedent_project_ids": projects,
                },
                cache_read=True,
            )
            data = result.get("data") if isinstance(result, dict) else None
            if result.get("status") != "succeeded":
                previous = self._evidence_failure or {}
                self._evidence_failure = {
                    "attempts": int(previous.get("attempts") or 0) + 1,
                    "error_code": result.get("error_code"),
                    "summary": result.get("summary"),
                }
            else:
                self._evidence_failure = None
            if isinstance(data, dict):
                candidate = data.get("plan_candidate")
                if isinstance(candidate, dict):
                    self._prepared_plan_candidate = dict(candidate)
                    self._prepared_plan_candidates[str(target_table).strip('"').upper()] = dict(candidate)
                    self._validated_supervisor_plan = None
                # Tables recovered from an exact caller-visible precedent were
                # rechecked against SHOW TERSE TABLES by the Workbench adapter.
                # Promote them into this run's verified catalog set so the
                # subsequent plan validator can accept the complete source graph.
                with self._catalog_lock:
                    for value in data.get("source_tables") or []:
                        table = str(value).strip('"').upper()
                        if table.count(".") == 2:
                            self._catalog_candidates.add(table)
                    for bridge in dict(data.get("current_relationships") or {}).get("expansion_candidates") or []:
                        if not isinstance(bridge, dict) or bridge.get("column_contract_status") not in {"verified", "reversed_candidate"}:
                            continue
                        for value in (bridge.get("from_table"), bridge.get("related_table")):
                            table = str(value or "").strip('"').upper()
                            if table.count(".") == 2 and self._within_authorized_table_scope(table, context):
                                self._catalog_candidates.add(table)
                    # Tables on data-verified join candidates (bridges included)
                    # were read from the caller's current catalog.
                    graph_tables = {
                        str(edge.get(side) or "").strip('"').upper()
                        for edge in dict(data.get("relationship_graph") or {}).get("edges") or []
                        if isinstance(edge, dict) and dict(edge.get("verification") or {}).get("status") == "verified"
                        for side in ("left_table", "right_table")
                    }
                    self._catalog_candidates.update(
                        table for table in sorted(graph_tables)
                        if table.count(".") == 2 and self._within_authorized_table_scope(table, context)
                    )
                if isinstance(candidate, dict) and self._plan_validator is not None:
                    validation = self._plan_validator(candidate)
                    self._prepared_plan_review = None
                    data["plan_validation"] = {
                        key: validation.get(key)
                        for key in ("status", "summary", "error_code")
                        if validation.get(key) not in (None, "")
                    }
                    if validation.get("status") == "succeeded":
                        data["next_action"] = (
                            "Delegate the staged plan to migration-workflow now; in Plan mode it will stop at "
                            "the immutable Approve/Edit/Reject checkpoint before any draft write."
                        )
                    else:
                        details = dict(validation.get("data") or {})
                        unresolved = list(details.get("unresolved") or [])
                        unresolved.extend(
                            f"Derived source has no executable SQL: {name}"
                            for name in details.get("missing_sql") or []
                        )
                        unresolved.extend(
                            f"{item.get('path')}: {item.get('message')}"
                            for item in details.get("validation_errors") or []
                            if isinstance(item, dict)
                        )
                        if not unresolved:
                            unresolved = [str(validation.get("summary") or "Prepared plan validation failed.")]
                        self._prepared_plan_review = {
                            "target_table": target_table,
                            "error_code": validation.get("error_code"),
                            "summary": validation.get("summary"),
                            "unresolved": unresolved,
                            "evidence_refs": list(result.get("evidence_refs") or []),
                            "plan_candidate": dict(candidate),
                            "target_columns": list(dict(data.get("source_readiness") or {}).get("target_columns") or {}),
                            "target_column_contracts": list(dict(data.get("target_contract") or {}).get("column_contracts") or []),
                            "source_readiness": dict(data.get("source_readiness") or {}),
                            "historical_source_candidates": list(data.get("historical_source_candidates") or []),
                            "source_candidate_evidence": list(data.get("source_candidate_evidence") or []),
                            "research_summary": dict(data.get("research_summary") or {}),
                            "catalog_candidates": sorted(self._catalog_candidates),
                            "fir_cards": list(dict(data.get("fir") or {}).get("cards") or []),
                            "semantic_context": dict(data.get("stored_semantic_context") or {}),
                            "current_relationships": dict(data.get("current_relationships") or {}),
                            "relationship_graph": dict(data.get("relationship_graph") or {}),
                            "historical_relationship_candidates": list(data.get("historical_relationship_candidates") or []),
                            "precedents": list(data.get("exact_target_precedents") or []),
                        }
            return result

        def prepare_multi_target_evidence(
            target_tables: list[str],
            source_tables: list[str] | None = None,
            precedent_project_ids: list[str] | None = None,
            sources_by_target: dict[str, list[str]] | None = None,
        ) -> dict[str, Any]:
            """Prepare evidence for several targets and stage one multi-mapping plan.

            Every target gets its own sources, never one shared list: the
            sources_by_target entry when given (driving source first), otherwise
            the current copies of its strongest precedent's sources in the
            requested source schema. Evidence is then prepared exactly like
            prepare_migration_evidence. Cross-mapping dependencies are inferred
            from declared keys, governed learnings and old mappings, and one
            combined plan is staged with a mapping_spec per ready target.
            Targets whose evidence is incomplete are reported instead of
            blocking the rest.
            """
            from app.migration_workflow.dependency_inference import infer_mapping_dependencies

            limit = int(getattr(getattr(self._workbench, "_settings", None), "migration_agent_multi_target_limit", 10))
            targets = list(dict.fromkeys(str(value).strip().strip('"').upper() for value in target_tables or [] if str(value).strip()))
            explicit_sources = {
                str(key).strip().strip('"').upper(): [str(value) for value in values or [] if str(value).strip()]
                for key, values in dict(sources_by_target or {}).items()
            }
            if len(targets) < 2 or len(targets) > limit:
                return ToolResult(
                    status="failed",
                    summary=f"Provide between 2 and {limit} target tables; use prepare_migration_evidence for one target.",
                    error_code="multi_target_limit",
                ).model_dump(mode="json")
            not_qualified = [value for value in targets if value.count(".") != 2]
            if not_qualified:
                return ToolResult(
                    status="needs_input",
                    summary="Every target must be fully qualified as DATABASE.SCHEMA.TABLE; resolve names with search_catalog_batch first.",
                    data={"unqualified_targets": not_qualified},
                    error_code="unqualified_targets",
                ).model_dump(mode="json")
            self._multi_target_active = True
            per_target: list[dict[str, Any]] = []
            ready: list[tuple[str, dict[str, Any], dict[str, Any]]] = []
            # Pass 1: sources per target from the request or the target's precedent.
            chosen: list[dict[str, Any]] = []
            for target in targets:
                contract = inspect_table_contract(target)
                if contract.get("status") != "succeeded":
                    per_target.append({
                        "target_table": target, "status": "unavailable",
                        "summary": contract.get("summary"), "error_code": contract.get("error_code"),
                    })
                    continue
                selection = "explicit"
                research: dict[str, Any] | None = None
                target_sources = explicit_sources.get(target) or explicit_sources.get(target.rsplit(".", 1)[-1]) or []
                if not target_sources:
                    research = self._research_target_sources(
                        target, prepare_migration_evidence, list(precedent_project_ids or []), list(source_tables or []))
                    target_sources = list((research or {}).get("sources") or [])
                    selection = "precedent_counterparts" if target_sources else "shared"
                chosen.append({"target": target, "contract": dict(contract.get("data") or {}), "selection": selection,
                               "research": research, "sources": target_sources})
            # Pass 2: a target with no precedent gets sources proposed from the
            # schemas the request named or the other targets resolved to.
            context = self._context_provider()
            schemas = {
                str(item["research"].get("schema") or "").upper() for item in chosen if item["research"]
            } | {
                str(value).strip('"').upper().rsplit(".", 1)[0]
                for item in chosen for value in item["sources"] if str(value).count(".") == 2
            } | {
                str(value).strip('"').upper().rsplit(".", 1)[0] if str(value).count(".") == 2 else str(value).strip('"').upper()
                for value in [*(source_tables or []), *(context.get("authorized_source_scope") or []),
                              *(context.get("authorized_schemas") or [])] if str(value).count(".") in (1, 2)
            }
            schemas.discard("")
            designs = [{"target": item["target"], "driving_source": item["sources"][0]} for item in chosen if item["sources"]]
            scout = getattr(self._workbench, "scout_target_sources", None)
            for item in chosen:
                if item["sources"] or not callable(scout):
                    continue
                proposal = dict(scout(item["target"], item["contract"], schemas=sorted(schemas),
                                      requested_text=str(context.get("prompt") or ""), known_designs=designs) or {})
                item["scout"] = proposal
                proposed = [str(value).upper() for value in proposal.get("sources") or []
                            if self._within_authorized_table_scope(str(value), context)]
                if proposed and not proposal.get("reason"):
                    with self._catalog_lock:
                        self._catalog_candidates.update(proposed)
                    item["sources"] = proposed
                    item["selection"] = "scouted"
            # Pass 3: evidence per target; open join paths are settled per target.
            min_joined = float(getattr(getattr(self._workbench, "_settings", None),
                                       "migration_agent_multi_target_min_joined_fraction", 0.5))

            def prepare_target(target: str, target_sources: list[str]) -> dict[str, Any]:
                prepared = prepare_migration_evidence(
                    source_tables=target_sources,
                    target_table=target,
                    precedent_project_ids=list(precedent_project_ids or []),
                )
                data = dict(prepared.get("data") or {})
                candidate = data.get("plan_candidate")
                validation = dict(data.get("plan_validation") or {})
                settled: dict[str, Any] = {}
                if (prepared.get("status") == "succeeded" and validation.get("status") != "succeeded"
                        and only_join_paths_open(self._prepared_plan_review)):
                    settled = self._settle_target_joins(target, prepared)
                    if settled.get("status") == "succeeded" and self._prepared_plan_candidate:
                        candidate = dict(self._prepared_plan_candidate)
                        validation = {key: settled.get(key) for key in ("status", "summary", "error_code")
                                      if settled.get(key) not in (None, "")}
                        # The spec is checked against this target's evidence: the settled graph.
                        self._prepared_plan_candidates[target] = dict(candidate)
                supporting = len(dict(dict(candidate or {}).get("source_preparation") or {}).get("supporting_sources") or [])
                left_out = len(dict(settled.get("join_resolution") or {}).get("left_out") or [])
                return {"prepared": prepared, "data": data, "candidate": candidate, "validation": validation,
                        "settled": settled, "sources": target_sources, "unresolved": list(
                            dict(self._prepared_plan_review or {}).get("unresolved") or [])[:8],
                        "joined_fraction": supporting / (supporting + left_out) if supporting + left_out else 1.0}

            for item in chosen:
                target, selection, research = item["target"], item["selection"], item["research"]
                outcome_for = prepare_target(target, list(item["sources"]) or list(source_tables or []))
                # A reused design whose tables mostly do not join here was built
                # for another client's shape; one fresh proposal is compared.
                if (outcome_for["joined_fraction"] < min_joined and selection != "scouted" and callable(scout)
                        and not explicit_sources.get(target)):
                    proposal = dict(scout(target, item["contract"], schemas=sorted(schemas),
                                          requested_text=str(context.get("prompt") or ""),
                                          known_designs=[value for value in designs if value["target"] != target]) or {})
                    item["scout"] = proposal
                    proposed = [str(value).upper() for value in proposal.get("sources") or []
                                if self._within_authorized_table_scope(str(value), context)]
                    if proposed and not proposal.get("reason"):
                        with self._catalog_lock:
                            self._catalog_candidates.update(proposed)
                        retry = prepare_target(target, proposed)
                        if retry["validation"].get("status") == "succeeded" and (
                                retry["joined_fraction"] > outcome_for["joined_fraction"]
                                or outcome_for["validation"].get("status") != "succeeded"):
                            outcome_for, selection = retry, "scouted_after_unjoinable_design"
                        elif outcome_for["candidate"]:
                            # Keep the first design; its evidence is the one to check against.
                            self._prepared_plan_candidates[target] = dict(outcome_for["candidate"])
                prepared, data, candidate, validation, settled = (
                    outcome_for["prepared"], outcome_for["data"], outcome_for["candidate"],
                    outcome_for["validation"], outcome_for["settled"])
                summary = dict(data.get("research_summary") or {})
                entry: dict[str, Any] = {
                    "target_table": target,
                    "summary": prepared.get("summary"),
                    "source_selection": selection,
                    "selected_sources": list(outcome_for["sources"])[:30],
                    **({"source_research": {key: research.get(key) for key in ("precedent_sttm_id", "schema", "driver",
                                                                              "identical_count", "different_columns")}}
                       if research else {}),
                    **({"source_scout": {key: item["scout"].get(key) for key in (
                        "reason", "confidence", "driving_source", "sources", "rationale", "rejected_names")}}
                       if item.get("scout") else {}),
                    **({"join_resolution": settled.get("join_resolution")} if settled.get("join_resolution") else {}),
                    "plan_validation": validation,
                    # Bounded: the full research stays in the per-target evidence.
                    "research_summary": {key: summary.get(key) for key in (
                        "target_column_count", "current_source_count", "next_action") if key in summary},
                }
                if prepared.get("status") == "succeeded" and isinstance(candidate, dict) and validation.get("status") == "succeeded":
                    entry["status"] = "ready"
                    ready.append((target, dict(candidate), data))
                else:
                    entry["status"] = "needs_research"
                    entry["unresolved"] = outcome_for["unresolved"]
                    entry["error_code"] = validation.get("error_code") or prepared.get("error_code")
                per_target.append(entry)

            specs: list[dict[str, Any]] = []
            used_keys: set[str] = set()
            target_columns: dict[str, list[str]] = {}
            precedent_lineage: dict[str, list[dict[str, Any]]] = {}
            fir_cards: dict[str, list[dict[str, Any]]] = {}
            for target, candidate, data in ready:
                leaf = target.split(".")[-1]
                key = re.sub(r"[^a-z0-9]+", "_", leaf.casefold()).strip("_") or "mapping"
                if key in used_keys:
                    key = re.sub(r"[^a-z0-9]+", "_", target.casefold()).strip("_")
                used_keys.add(key)
                source_preparation = dict(candidate.get("source_preparation") or {})
                source_preparation["target_table"] = target
                specs.append({
                    "mapping_key": key,
                    "mapping_name": leaf,
                    "target_table": target,
                    "source_preparation": source_preparation,
                    "auto_map": dict(candidate.get("auto_map") or {}),
                })
                columns = dict(data.get("target_contract") or {}).get("columns") or []
                target_columns[target] = [
                    str(column.get("name") if isinstance(column, dict) else column) for column in columns
                ]
                precedent_lineage[target] = list(data.get("exact_target_precedents") or [])
                fir_cards[target] = list(dict(data.get("fir") or {}).get("cards") or [])
            edges, dependency_candidates = infer_mapping_dependencies(
                specs,
                target_columns=target_columns,
                precedent_lineage=precedent_lineage,
                fir_cards=fir_cards,
            )
            needs_research = [item for item in per_target if item["status"] != "ready"]
            inventory_reader = getattr(self._workbench, "firm_values_inventory", None)
            firm_inventory = inventory_reader(context, targets) if callable(inventory_reader) else ToolResult(
                status="succeeded", summary="Firm-value inventory is unavailable in this runtime.", data={})
            firm_inventory_data = dict(firm_inventory.data or {}) if firm_inventory.status == "succeeded" else {}
            import_sources = list(firm_inventory_data.get("import_sources") or [])
            missing_firm_values = [str(item.get("name") or "") for item in firm_inventory_data.get("missing") or []
                                   if str(item.get("name") or "").strip()]
            firm_import_decision: dict[str, Any] | None = None
            if missing_firm_values and import_sources:
                source = dict(import_sources[0])
                source_project_id = str(source.get("project_id") or "")
                covered = [str(value) for value in source.get("names") or [] if str(value).strip()]
                if source_project_id and covered:
                    firm_import_decision = {
                        "subject": "value_binding_import",
                        "decision_key": source_project_id,
                        "selected_value": f"import:{source_project_id}",
                        "selected_label": f"Import {len(covered)} values from {source.get('project_name') or source_project_id}",
                        "selected_description": ", ".join(covered),
                        "selected_impact": "Copies only the reviewed missing values; existing project values are kept.",
                        "confidence": 0.3,
                        "score_margin": 0.0,
                        "recommended": True,
                        "rationale": firm_inventory_data.get("summary") or "A precedent project holds required firm values.",
                        "question": "Import the required firm values available from this precedent project?",
                        "allow_free_text": False,
                        "names": covered,
                        "alternatives": [{
                            "value": "review_individually", "label": "Review values individually",
                            "description": "Do not import now; keep each missing firm value as a review action.",
                            "impact": "Mapping continues only after the required values are provided.",
                        }],
                    }
            outcome = {"targets": [
                {"target_table": item["target_table"], "status": item["status"],
                 "source_selection": item.get("source_selection"),
                 "selected_sources": list(item.get("selected_sources") or [])[:8],
                 "unresolved": list(item.get("unresolved") or [])[:4], "error_code": item.get("error_code"),
                 **({"source_scout": {key: item["source_scout"].get(key) for key in ("reason", "confidence", "driving_source")}}
                    if item.get("source_scout") else {}),
                 **({"join_resolution": item["join_resolution"]} if item.get("join_resolution") else {})}
                for item in per_target]}
            if not specs:
                # Per-target reviews describe only the last target prepared;
                # the run reports every target instead.
                self._prepared_plan_review = {"target_table": "", "multi_target_outcome": outcome,
                                              "unresolved": [f"{item['target_table']}: {item.get('error_code') or item['status']}"
                                                             for item in needs_research]}
            plan_validation: dict[str, Any] = {}
            if specs:
                first_candidate = ready[0][1]
                combined = {
                    **first_candidate,
                    "normalized_intent": (
                        f"Create {len(specs)} draft STTM mappings for "
                        + ", ".join(spec["mapping_name"] for spec in specs)
                    ),
                    "source_preparation": specs[0]["source_preparation"],
                    "auto_map": specs[0]["auto_map"],
                    "mapping_specs": specs,
                    "dependencies": edges,
                    "decisions": [*([firm_import_decision] if firm_import_decision else []), *list({
                        (str(item.get("subject")), str(item.get("decision_key") or item.get("selected_value"))): item
                        for _target, candidate, _data in ready
                        for item in candidate.get("decisions") or [] if isinstance(item, dict)
                    }.values())],
                    "evidence_ids_used": list(dict.fromkeys(
                        evidence for _target, candidate, _data in ready
                        for evidence in candidate.get("evidence_ids_used") or []
                    )),
                    # Targets not in this plan and sources left out of a target
                    # stay visible on the approval card and in the summary.
                    "risks": list(dict.fromkeys([
                        *[str(value) for value in first_candidate.get("risks") or []],
                        *[f"{item['target_table'].rsplit('.', 1)[-1]} is not in this plan: "
                          f"{item.get('error_code') or 'needs source research'}" for item in needs_research],
                        *[f"{item['target_table'].rsplit('.', 1)[-1]}: left out {', '.join(item['join_resolution']['left_out'])} "
                          "(no verified or earlier-confirmed join); its columns need review"
                          for item in per_target if item["status"] == "ready"
                          and dict(item.get("join_resolution") or {}).get("left_out")],
                    ])),
                }
                self._prepared_plan_candidate = combined
                self._validated_supervisor_plan = None
                self._persist_plan_state()
                if self._plan_validator is not None:
                    validation = self._plan_validator(combined)
                    plan_validation = {
                        key: validation.get(key)
                        for key in ("status", "summary", "error_code")
                        if validation.get(key) not in (None, "")
                    }
                    if validation.get("status") != "succeeded":
                        plan_validation["details"] = dict(validation.get("data") or {})
                    else:
                        # Per-target reviews describe targets now reported in
                        # needs_research; they must not steer the host toward a
                        # single-target source-research checkpoint.
                        self._prepared_plan_review = None

            def summarize() -> ToolResult:
                return ToolResult(
                    status="succeeded" if specs else "needs_input",
                    summary=(
                        f"Prepared {len(specs)} of {len(targets)} target(s) with {len(edges)} inferred "
                        f"cross-mapping dependenc{'y' if len(edges) == 1 else 'ies'}; "
                        f"{len(needs_research)} target(s) need more source research."
                    ),
                    data={
                        "per_target": per_target,
                        "ready_mappings": [
                            {"mapping_key": spec["mapping_key"], "target_table": spec["target_table"],
                             "driving_source": spec["source_preparation"].get("driving_source")}
                            for spec in specs
                        ],
                        "needs_research": [
                            {key: item.get(key) for key in ("target_table", "status", "error_code", "unresolved")}
                            for item in needs_research
                        ],
                        "dependencies": [
                            {key: edge[key] for key in ("consumer_mapping", "consumer_columns", "producer_mapping",
                                                        "producer_columns", "confidence", "evidence_id")}
                            for edge in edges
                        ],
                        "dependency_candidates": dependency_candidates[:30],
                        "plan_validation": plan_validation,
                        "next_action": (
                            "The combined plan is staged. If project_decision is needed (for example the user asked "
                            "for a new project), call validate_migration_plan with this plan plus project_decision; "
                            "then delegate to migration-workflow. Report needs_research targets and low-confidence "
                            "dependency_candidates in the final answer instead of asking about each one."
                            if plan_validation.get("status") == "succeeded" else
                            "Repair the combined plan from plan_validation.details, or research the listed targets."
                        ),
                    },
                    evidence_refs=list(dict.fromkeys(
                        evidence for _target, candidate, _data in ready
                        for evidence in candidate.get("evidence_ids_used") or []
                    )),
                    metrics={"target_count": len(targets), "ready_count": len(specs),
                             "dependency_count": len(edges)},
                )

            return self._execute(
                "prepare_multi_target_evidence", summarize,
                safe_input={"target_tables": targets, "source_tables": list(source_tables or []),
                            "sources_by_target": {key: values[:30] for key, values in explicit_sources.items()},
                            "precedent_project_ids": list(precedent_project_ids or [])},
            )

        def list_project_templates(target_database: str | None = None, target_schema: str | None = None) -> dict[str, Any]:
            """Inspect available configured templates and verified target entities."""
            return self._execute("list_project_templates", lambda: self._workbench.list_project_templates(target_database,target_schema),
                safe_input={"target_database":target_database,"target_schema":target_schema}, cache_read=True)

        def list_projects() -> dict[str, Any]:
            """List caller-visible migration projects for precedent and scope discovery."""
            return self._execute(
                "list_projects",
                lambda: self._workbench.list_projects() if self._workbench else ToolResult(status="failed", summary="Project discovery is unavailable.", error_code="capability_unavailable"),
                cache_read=True,
            )

        def search_precedents(query: str = "", source_tables: list[str] | None = None,
                              target_tables: list[str] | None = None) -> dict[str, Any]:
            """Find earlier projects to learn from: exact targets, same-named sources, or the user's words.

            Use when the user refers to earlier work ("like the Evernest migration",
            "learnings from earlier TMD mappings") or when current evidence lacks
            joins or transformations. Pass the returned project ids as
            precedent_project_ids to evidence preparation. Omitted arguments
            default to the user's request and the tables resolved so far.
            """
            query, source_tables, target_tables = self._precedent_search_defaults(
                query, list(source_tables or []), list(target_tables or [])
            )
            return self._execute(
                "search_precedents",
                lambda: self._workbench.search_precedents(
                    query=query, source_tables=list(source_tables or [])[:50],
                    target_tables=list(target_tables or [])[:50],
                ) if self._workbench else ToolResult(status="failed", summary="Precedent search is unavailable.",
                                                     error_code="capability_unavailable"),
                safe_input={"query": query[:500], "source_tables": list(source_tables or [])[:50],
                            "target_tables": list(target_tables or [])[:50]},
                cache_read=True,
            )

        def get_project_context(project_id: str) -> dict[str, Any]:
            """Read one project, its draft mappings, and explicitly linked precedents."""
            result = self._execute(
                "get_project_context",
                lambda: self._workbench.get_project_context(project_id) if self._workbench else ToolResult(status="failed", summary="Project context is unavailable.", error_code="capability_unavailable"),
                safe_input={"project_id": project_id},
                cache_read=True,
            )
            if result.get("status") == "succeeded":
                context = self._context_provider()
                with self._catalog_lock:
                    self._precedent_targets.update(
                        str(mapping.get("target_table") or "").strip('"').upper()
                        for mapping in dict(result.get("data") or {}).get("mappings") or []
                        if isinstance(mapping, dict)
                        and self._within_authorized_table_scope(str(mapping.get("target_table") or ""), context)
                    )
                prepared = prepare_verified_target_evidence()
                if prepared is not None:
                    result["prepared_evidence"] = {
                        "status": prepared.get("status"),
                        "summary": prepared.get("summary"),
                        "plan_validation": dict(prepared.get("data") or {}).get("plan_validation"),
                    }
            return result

        def inspect_precedent_mapping(sttm_id: str) -> dict[str, Any]:
            """Inspect active source, join and CTE lineage of a precedent found in this run.

            Allowed for exact-target precedents and for output-equivalent
            precedents (older mappings whose SQL produces this target's columns).
            """
            review = dict(self._prepared_plan_review or {})
            target = str(review.get("target_table") or "").strip('"').upper()
            allowed_ids = {
                str(item.get("sttm_id") or "")
                for item in review.get("precedents") or [] if isinstance(item, dict)
            }
            equivalent_ids = {
                str(item.get("sttm_id") or "")
                for item in dict(review.get("research_summary") or {}).get("output_equivalent_precedents") or []
                if isinstance(item, dict)
            }
            context = self._context_provider()
            if not target or sttm_id not in allowed_ids | equivalent_ids or not self._within_authorized_table_scope(target, context):
                return ToolResult(status="denied", summary="This mapping was not found as a precedent for the current target in this run.", error_code="precedent_out_of_scope").model_dump(mode="json")
            output_equivalent = sttm_id in equivalent_ids and sttm_id not in allowed_ids
            result = self._execute(
                "inspect_precedent_mapping",
                lambda: self._workbench.inspect_precedent_mapping(
                    sttm_id, target, output_equivalent=output_equivalent,
                    requested_text=str(context.get("prompt") or ""),
                    selected_scope=list(context.get("authorized_source_scope") or []),
                ) if self._workbench else ToolResult(status="failed", summary="Precedent inspection is unavailable.", error_code="capability_unavailable"),
                safe_input={"sttm_id": sttm_id, "target_table": target}, cache_read=True,
            )
            # Counterpart tables were found by a catalog query under the
            # caller's role, so they are verified candidates for inspection.
            found = [str(item.get("current_table") or "").upper()
                     for entry in dict(result.get("data") or {}).get("current_schema_counterparts") or []
                     for item in [*(entry.get("identical") or []), *(entry.get("different_columns") or [])]]
            with self._catalog_lock:
                self._catalog_candidates.update(
                    table for table in found if table.count(".") == 2 and self._within_authorized_table_scope(table, context))
            return result

        def validate_migration_plan(plan: dict[str, Any]) -> dict[str, Any]:
            """Validate and stage an evidence-backed plan before draft execution.

            auto_map.mapping_evidence must contain a complete candidate for
            each target column: {"target_column": "ID", "source_columns":
            ["DB.SCHEMA.SOURCE.ID"], "mapping_mode": "direct"}. Classifications
            alone do not establish candidate coverage. Use only verified columns.
            execution_steps must include an SQL step with query_kind="mapping",
            "derived_source", "explain", "preview", or "reconciliation". Set sql
            to the exact known SQL, or dynamic_sql=true ONLY when specialist
            output after approval determines it. A SQL step example is
            {"sequence": 2, "title": "Compile mapping", "description": "Compile
            the approved rules", "phase": "validation", "query_kind": "mapping",
            "dynamic_sql": true, "runs_before_approval": false,
            "runs_after_approval": true}. Phase alone does not set query_kind.
            """
            plan_input = dict(plan or {})
            normalized_intent = str(plan_input.get("normalized_intent") or "").strip()
            source_preparation = dict(plan_input.get("source_preparation") or {})
            auto_map = dict(plan_input.get("auto_map") or {})
            raw_specs = [dict(item) for item in plan_input.get("mapping_specs") or [] if isinstance(item, dict)]
            if raw_specs:
                # A multi-target plan may omit the top-level single-target
                # fields; they mirror the first mapping for legacy consumers.
                first_spec = raw_specs[0]
                if not source_preparation:
                    source_preparation = dict(first_spec.get("source_preparation") or {})
                    source_preparation.setdefault("target_table", first_spec.get("target_table"))
                if not auto_map and isinstance(first_spec.get("auto_map"), dict):
                    auto_map = dict(first_spec["auto_map"])
                first_prepared = self._prepared_plan_candidates.get(
                    str(first_spec.get("target_table") or "").strip('"').upper()
                )
                if first_prepared is not None and not (self._prepared_plan_candidate or {}).get("mapping_specs"):
                    self._prepared_plan_candidate = dict(first_prepared)
            project_decision = dict(plan_input.get("project_decision") or {})
            decisions = list(plan_input.get("decisions") or [])
            execution_steps = list(plan_input.get("execution_steps") or [])
            recommend_plan_review = bool(plan_input.get("recommend_plan_review", False))
            plan_review_reason = str(plan_input.get("plan_review_reason") or "").strip()
            evidence_ids_used = list(
                plan_input.get("evidence_ids_used")
                or plan_input.get("evidence_refs")
                or []
            )
            if not normalized_intent:
                return ToolResult(
                    status="needs_input",
                    summary="The migration plan must describe its normalized intent.",
                    data={"validation_errors": [{
                        "path": "normalized_intent",
                        "message": "Provide a concise business outcome for the plan.",
                    }]},
                    error_code="invalid_plan_contract",
                ).model_dump(mode="json")
            context = self._context_provider()
            normalized_source = dict(source_preparation or {})
            for alias, canonical in {
                "driving_table": "driving_source",
                "target": "target_table",
                "joins": "relationships",
                "ctes": "derived_sources",
                "selected_columns": "selected_columns_by_table",
                "group_by": "grouping",
                "aggregations": "aggregation",
                "order_by": "sorting",
            }.items():
                if canonical not in normalized_source and alias in normalized_source:
                    normalized_source[canonical] = normalized_source.pop(alias)

            normalized_source = _normalize_source_preparation(normalized_source, prompt=str(context.get("prompt") or ""))
            normalized_auto_map = dict(auto_map or {})
            if not raw_specs and (name := str(plan_input.get("mapping_name") or normalized_auto_map.get("mapping_name") or "").strip()):
                normalized_auto_map["requested_mappings"] = [name]
            normalized_auto_map["mapping_evidence"] = _normalize_mapping_evidence(list(normalized_auto_map.get("mapping_evidence") or []))
            if "requested_mappings" not in normalized_auto_map and "mappings" in normalized_auto_map:
                normalized_auto_map["requested_mappings"] = normalized_auto_map.pop("mappings")
            raw_classifications = dict(
                normalized_auto_map.get("mapping_classifications")
                or normalized_auto_map.get("classifications")
                or {}
            )
            classification_aliases = {
                "lookup": "direct",
                "transformation": "derived",
                "transform": "derived",
                "calculated": "derived",
                "concatenation": "derived",
                "boolean_conversion": "derived",
                "many-to-one": "many_to_one",
                "many to one": "many_to_one",
            }
            normalized_auto_map["mapping_classifications"] = {
                str(key): classification_aliases.get(str(value).strip().lower(), str(value).strip().lower())
                for key, value in raw_classifications.items()
            }
            normalized_auto_map.pop("classifications", None)

            phase_aliases = {
                "planning": "plan_analysis",
                "analysis": "plan_analysis",
                "discovery": "plan_analysis",
                "execution": "draft_execution",
                "draft": "draft_execution",
                "sql_validation": "validation",
                "optimization": "validation",
                "reconciliation": "validation",
                "results": "delivery",
            }
            query_aliases = {
                "sql": "mapping",
                "contract": "metadata",
                "profiling": "profile",
                "join": "join_check",
                "cte": "derived_source",
                "validate": "explain",
                "optimize": "explain",
                "reconcile": "reconciliation",
            }
            normalized_steps: list[dict[str, Any]] = []
            for index, raw_step in enumerate(execution_steps or [], start=1):
                step = dict(raw_step or {})
                step.setdefault("sequence", step.pop("step", index))
                step.setdefault("title", step.pop("name", f"Migration step {index}"))
                step.setdefault("description", step.pop("action", step["title"]))
                raw_phase = str(step.get("phase") or step.pop("stage", "draft_execution")).strip().lower()
                step["phase"] = phase_aliases.get(raw_phase, raw_phase)
                raw_query = str(step.get("query_kind") or step.pop("query_type", "none")).strip().lower()
                step["query_kind"] = query_aliases.get(raw_query, raw_query)
                normalized_steps.append(step)

            normalized_decisions: list[dict[str, Any]] = []
            for raw_decision in decisions or []:
                decision = dict(raw_decision or {})
                subject = str(decision.get("subject") or "").strip().lower()
                decision["subject"] = {"cte": "derived_source", "driving_source": "source", "driving_table": "source",
                                       "join_design": "join", "relationship": "join", "firm_value": "value_binding"}.get(subject, subject)
                if decision["subject"] == "source" and not decision.get("alternatives") and not decision.get("allow_free_text"):
                    decision["selected_value"] = _canonical_source_decision(str(decision.get("selected_value") or ""), normalized_source)
                decision.setdefault("confidence", 0.5)
                decision.setdefault("rationale", "Selected from verified migration evidence.")
                normalized_decisions.append(decision)

            try:
                source_spec = SourcePreparationSpecV1.model_validate(normalized_source)
                auto_map_spec = AutoMapExecutionSpecV1.model_validate(normalized_auto_map)
                decision_specs = [PlanDecisionV1.model_validate(value) for value in normalized_decisions]
                step_specs = [PlanExecutionStepV1.model_validate(value) for value in normalized_steps]
                project_decision = ProjectDecisionV1.model_validate(project_decision).model_dump(
                    mode="json", exclude_defaults=True
                ) if project_decision else {}
            except ValidationError as exc:
                return ToolResult(
                    status="needs_input",
                    summary="The migration plan has fields that do not match the governed plan contract.",
                    data={
                        "validation_errors": [
                            {"path": ".".join(str(part) for part in error["loc"]), "message": error["msg"]}
                            for error in exc.errors(include_url=False, include_input=False)[:12]
                        ],
                        "allowed_mapping_classifications": [
                            "direct", "many_to_one", "derived", "constant", "excluded", "unresolved"
                        ],
                    },
                    error_code="invalid_plan_contract",
                ).model_dump(mode="json")
            if len({step.sequence for step in step_specs}) != len(step_specs):
                return ToolResult(status="needs_input", summary="Every execution step needs a unique sequence number.", error_code="duplicate_plan_step").model_dump(mode="json")
            if (
                str(context.get("effective_run_mode") or context.get("requested_run_mode") or "").casefold()
                == "plan"
                and not any(
                    str(step.sql or "").strip() or step.dynamic_sql
                    for step in step_specs
                    if step.query_kind in {"derived_source", "mapping", "explain", "preview", "reconciliation"}
                )
            ):
                return ToolResult(
                    status="needs_input",
                    summary="A Plan-mode approval must include proposed SQL or identify the query as dynamic.",
                    data={"validation_errors": [{
                        "path": "execution_steps",
                        "message": "Set query_kind on the SQL step as well as sql or dynamic_sql. Phase does not imply query_kind. Use dynamic_sql only when specialist output after approval determines the query.",
                        "required_query_kinds": ["derived_source", "mapping", "explain", "preview", "reconciliation"],
                    }]},
                    error_code="planned_sql_required",
                ).model_dump(mode="json")
            known_tables = {
                str(value).strip('"').upper()
                for value in [
                    *(context.get("authorized_source_scope") or []),
                    *(context.get("authorized_target_scope") or []),
                    *self._catalog_candidates,
                ]
                if str(value).count(".") == 2
            }
            referenced = [
                value for value in [
                    source_spec.driving_source,
                    *source_spec.supporting_sources,
                    source_spec.target_table,
                ] if value
            ]
            unknown = sorted({value for value in referenced if value.strip('"').upper() not in known_tables})
            if unknown:
                return ToolResult(
                    status="needs_input",
                    summary="The plan references tables that were not authorized or verified in this run.",
                    data={"unknown_tables": unknown},
                    error_code="unverified_plan_selection",
                ).model_dump(mode="json")
            if not source_spec.driving_source:
                return ToolResult(
                    status="needs_input",
                    summary="A migration plan must select one verified driving source.",
                    error_code="driving_source_required",
                ).model_dump(mode="json")
            if not source_spec.target_table and not context.get("authorized_target_scope"):
                return ToolResult(
                    status="needs_input",
                    summary="A migration plan must select a verified target contract.",
                    error_code="target_required",
                ).model_dump(mode="json")
            prepared_source = dict((self._prepared_plan_candidate or {}).get("source_preparation") or {})
            if prepared_source:
                prepared_tables = {
                    str(value).strip('"').upper()
                    for value in [prepared_source.get("driving_source"), *(prepared_source.get("supporting_sources") or [])]
                    if value
                }
                planned_tables = {
                    str(value).strip('"').upper()
                    for value in [source_spec.driving_source, *source_spec.supporting_sources]
                    if value
                }
                if prepared_tables != planned_tables:
                    return ToolResult(
                        status="needs_input",
                        summary="The selected source graph changed after evidence preparation; refresh current semantic and lineage evidence for this selection.",
                        data={"prepared_sources": sorted(prepared_tables), "planned_sources": sorted(planned_tables)},
                        error_code="source_graph_evidence_stale",
                    ).model_dump(mode="json")

                def join_identity(value: dict[str, Any]) -> tuple[Any, ...]:
                    def fqn(raw: Any) -> str:
                        if isinstance(raw, dict):
                            raw = ".".join(str(raw.get(key) or "") for key in ("database", "schema", "table"))
                        return str(raw or "").strip('"').upper()
                    return (
                        fqn(value.get("left_table")), fqn(value.get("right_table")),
                        str(value.get("join_type") or "INNER").upper(),
                        tuple(sorted((str(item.get("left_column") or "").upper(),
                                      str(item.get("right_column") or "").upper(),
                                      str(item.get("operator") or "=").upper())
                                     for item in value.get("conditions") or [] if isinstance(item, dict))),
                    )

                prepared_joins = {join_identity(item) for item in prepared_source.get("relationships") or []
                                  if isinstance(item, dict)}
                unsupported_joins = [item for item in source_spec.relationships
                                     if join_identity(item) not in prepared_joins]
                if unsupported_joins:
                    return ToolResult(
                        status="needs_input",
                        summary="The plan includes joins that were not verified in the current semantic evidence package.",
                        data={"unverified_join_count": len(unsupported_joins),
                              "next_action": "verify_relationships_or_request_business_review"},
                        error_code="unverified_plan_relationship",
                    ).model_dump(mode="json")
            if source_spec.unresolved_items:
                return ToolResult(status="needs_input",
                    summary="Source design has unresolved evidence; investigate before draft execution.",
                    data={"unresolved": source_spec.unresolved_items, "next_action": "research_source_design"},
                    error_code="source_design_incomplete").model_dump(mode="json")
            plan_review_mode = str(context.get("effective_run_mode") or context.get("requested_run_mode") or "").casefold() == "plan"
            unresolved_bindings = [
                binding.name for binding in source_spec.value_bindings
                if binding.resolution_status != "resolved" or not binding.resolved_value
            ]
            pending_binding_decisions = {
                decision.decision_key for decision in decision_specs
                if decision.subject == "value_binding" and (decision.alternatives or decision.allow_free_text) and decision.question
            }
            if plan_review_mode and any(name not in pending_binding_decisions for name in unresolved_bindings):
                return ToolResult(
                    status="needs_input",
                    summary="Firm-specific values require current-project evidence or an explicit user decision before plan approval.",
                    data={"unresolved_value_bindings": unresolved_bindings,
                          "next_action": "ask_evidence_backed_value_questions"},
                    error_code="value_bindings_unresolved",
                ).model_dump(mode="json")
            target_columns = {str(value).upper() for value in auto_map_spec.target_columns}
            prepared_targets = {
                str(value).upper() for value in
                ((self._prepared_plan_candidate or {}).get("auto_map") or {}).get("target_columns") or []
            }
            if plan_review_mode and prepared_targets and target_columns != prepared_targets:
                return ToolResult(
                    status="needs_input",
                    summary="The plan target columns no longer match the verified target contract; refresh the evidence package.",
                    data={"missing": sorted(prepared_targets - target_columns),
                          "unexpected": sorted(target_columns - prepared_targets)},
                    error_code="target_contract_mismatch",
                ).model_dump(mode="json")
            selected_tables = {str(value).upper() for value in [source_spec.driving_source, *source_spec.supporting_sources] if value}
            selected_leaves = {value.split(".")[-1] for value in selected_tables}
            covered_columns: set[str] = set()
            for item in auto_map_spec.mapping_evidence:
                if not isinstance(item, dict):
                    continue
                target_column = str(item.get("target_column") or "").upper()
                columns = [str(value).upper() for value in item.get("source_columns") or []]
                source_tables = {
                    value.rsplit(".", 1)[0] for value in columns if "." in value
                }
                in_scope = all(
                    value in selected_tables or value.split(".")[-1] in selected_leaves
                    for value in source_tables
                )
                is_constant = str(item.get("mapping_mode") or "").lower() in {"constant", "attribute"}
                has_value = item.get("constant_value") is not None or any(
                    target_column in {value.upper() for value in binding.target_columns}
                    for binding in source_spec.value_bindings
                )
                if target_column in target_columns and in_scope and (columns or (is_constant and has_value)):
                    covered_columns.add(target_column)
            missing_coverage = sorted(target_columns - covered_columns)
            if plan_review_mode and (not target_columns or (missing_coverage and (
                not auto_map_spec.allow_partial_coverage or not covered_columns
            ))):
                return ToolResult(
                    status="needs_input",
                    summary="The plan needs at least one in-scope mapping candidate. Set allow_partial_coverage to present the remaining columns explicitly for review.",
                    data={"uncovered_target_columns": missing_coverage or ["target contract missing"],
                          "covered_count": len(covered_columns), "target_count": len(target_columns),
                          "expected_candidate_format": {"target_column": "TARGET_COLUMN", "source_columns": ["DATABASE.SCHEMA.TABLE.COLUMN"], "mapping_mode": "direct"}},
                    error_code="mapping_plan_incomplete",
                ).model_dump(mode="json")
            if missing_coverage:
                auto_map_spec.evidence_gaps = sorted(set(auto_map_spec.evidence_gaps) | set(missing_coverage))
                auto_map_spec.mapping_classifications.update({column: "unresolved" for column in missing_coverage})
                auto_map_spec.expected_coverage = len(covered_columns) / len(target_columns)
            verified_precedent = False
            if source_spec.precedent_reference:
                candidate_source = (self._prepared_plan_candidate or {}).get("source_preparation") or {}
                verified_precedent = (
                    SourcePreparationSpecV1.model_validate(candidate_source).model_dump(mode="json")
                    == source_spec.model_dump(mode="json")
                )
                if not verified_precedent:
                    return ToolResult(
                        status="denied",
                        summary="Completed-precedent reuse must match the exact host-retrieved source plan.",
                        error_code="precedent_plan_changed",
                    ).model_dump(mode="json")
            if source_spec.supporting_sources and not source_spec.relationships and not verified_precedent:
                return ToolResult(
                    status="needs_input",
                    summary="Every multi-source plan must include verified join definitions.",
                    error_code="join_definitions_required",
                ).model_dump(mode="json")
            if source_spec.supporting_sources and not verified_precedent:
                from app.agent_tools.source_readiness import disconnected_plan_sources
                disconnected = disconnected_plan_sources(
                    source_spec.driving_source,
                    source_spec.supporting_sources,
                    source_spec.relationships,
                )
                if disconnected:
                    return ToolResult(
                        status="needs_input",
                        summary="Some selected sources have no verified join path to the driving source.",
                        data={"unresolved": [
                            f"Source has no verified join path to {source_spec.driving_source}: {table}"
                            for table in disconnected
                        ], "disconnected_sources": disconnected},
                        error_code="join_graph_incomplete",
                    ).model_dump(mode="json")
            prepared_join_decisions = {
                str(item.get("decision_key") or ""): item
                for item in (self._prepared_plan_candidate or {}).get("decisions") or []
                if isinstance(item, dict) and item.get("subject") == "join"
            }
            for decision in decision_specs:
                if decision.subject != "join" or not decision.alternatives:
                    continue
                prepared = prepared_join_decisions.get(str(decision.decision_key or ""))
                if prepared is None or decision.selected_value != prepared.get("selected_value") or (
                    decision.alternatives != prepared.get("alternatives")
                ):
                    return ToolResult(
                        status="denied",
                        summary="Join choices must match the current host-verified relationship alternatives.",
                        error_code="unverified_join_choice",
                    ).model_dump(mode="json")
            missing_derived_sql = [
                str(item.get("name") or item.get("id") or "derived source")
                for item in source_spec.derived_sources
                if not str(item.get("sql") or item.get("sql_outline") or "").strip()
            ]
            if missing_derived_sql:
                return ToolResult(
                    status="needs_input",
                    summary="Every proposed derived source must contain executable SELECT/CTE SQL.",
                    data={"missing_sql": missing_derived_sql},
                    error_code="derived_source_sql_required",
                ).model_dump(mode="json")
            for step in step_specs:
                sql = str(step.sql or "").strip().rstrip(";")
                if not sql:
                    continue
                without_literals = re.sub(r"'(?:''|[^'])*'", "''", sql)
                if ";" in sql or not re.match(
                    r"^(?:SELECT|WITH|SHOW|DESC(?:RIBE)?|EXPLAIN)\b",
                    without_literals,
                    flags=re.IGNORECASE,
                ):
                    return ToolResult(
                        status="denied",
                        summary="A planned query is outside the read-only Snowflake sandbox.",
                        data={"sequence": step.sequence},
                        error_code="unsafe_planned_query",
                    ).model_dump(mode="json")
            for decision_model in decision_specs:
                decision = decision_model.model_dump(mode="json")
                values = [
                    str(decision.get("selected_value") or ""),
                    *[
                        str(option.get("value") or option.get("selected_value") or "")
                        for option in decision.get("alternatives") or []
                        if isinstance(option, dict)
                    ],
                ]
                if str(decision.get("subject") or "") in {"source", "target"}:
                    unverified_options = [
                        value for value in values
                        if value and value.strip('"').upper() not in known_tables
                    ]
                    if unverified_options:
                        return ToolResult(
                            status="needs_input",
                            summary="A confidence-gated choice contains an unverified table candidate.",
                            data={"unknown_tables": unverified_options},
                            error_code="unverified_choice",
                        ).model_dump(mode="json")
            from app.agent_runs.contracts import MappingExecutionSpec
            from app.migration_workflow.scheduler import Dependency
            mapping_specs = [MappingExecutionSpec.model_validate(item).model_dump(mode="json") for item in plan_input.get("mapping_specs", [])]
            dependencies = [Dependency.model_validate(item).model_dump(mode="json") for item in plan_input.get("dependencies", [])]
            for spec in mapping_specs:
                tables = [spec["target_table"], spec["source_preparation"].get("driving_source"), *spec["source_preparation"].get("supporting_sources", [])]
                if any(str(table).strip('"').upper() not in known_tables for table in tables if table):
                    return ToolResult(status="denied", summary="Mapping scope contains undiscovered tables", error_code="unverified_mapping_scope").model_dump(mode="json")
            if mapping_specs:
                spec_issues = self._mapping_spec_issues(mapping_specs, dependencies)
                if spec_issues:
                    return ToolResult(
                        status="needs_input",
                        summary="Some mapping specs are not supported by their own prepared evidence.",
                        data={
                            "mapping_spec_issues": spec_issues[:12],
                            "next_action": (
                                "Repair each listed spec from that target's prepared evidence, or remove it from "
                                "mapping_specs (and its dependencies) and report it as a target needing research. "
                                "The remaining mappings can proceed."
                            ),
                        },
                        error_code="mapping_spec_invalid",
                    ).model_dump(mode="json")
            plan = {
                "mapping_specs": mapping_specs,
                "dependencies": dependencies,
                "normalized_intent": normalized_intent.strip(),
                "project_decision": project_decision,
                "source_preparation": source_spec.model_dump(mode="json"),
                "auto_map": auto_map_spec.model_dump(mode="json"),
                "decisions": [value.model_dump(mode="json") for value in decision_specs],
                "execution_steps": [value.model_dump(mode="json") for value in sorted(step_specs, key=lambda item: item.sequence)],
                "recommend_plan_review": bool(recommend_plan_review),
                "plan_review_reason": plan_review_reason,
                "evidence_ids_used": list(dict.fromkeys(evidence_ids_used or [])),
                "risks": [str(value)[:300] for value in plan_input.get("risks") or [] if str(value).strip()][:20],
                "_deep_supervisor_validated": True,
                "_discovered_catalog_tables": sorted(self._catalog_candidates),
            }
            self._validated_supervisor_plan = plan
            self._persist_plan_state()
            return self._execute(
                "validate_migration_plan",
                lambda: ToolResult(
                    status="succeeded",
                    summary="The Deep supervisor plan passed host schema and table-scope validation.",
                    data=plan,
                    evidence_refs=plan["evidence_ids_used"],
                ),
                safe_input={
                    "source_count": len(referenced) - int(bool(source_spec.target_table)),
                    "has_target": bool(source_spec.target_table),
                    "decision_count": len(decisions or []),
                    "execution_step_count": len(execution_steps or []),
                },
            )

        def read_stored_semantic_context(
            source_tables: list[str] | None = None,
            target_table: str | None = None,
        ) -> dict[str, Any]:
            """Read stored semantic records for verified source and target tables."""
            context = self._context_provider()
            selected = [
                *[str(value) for value in (source_tables or []) if str(value).strip()],
                *([str(target_table)] if target_table else []),
            ]
            known_tables = {
                str(value).strip('"').upper()
                for value in [
                    *(context.get("authorized_source_scope") or []),
                    *(context.get("authorized_target_scope") or []),
                    *self._catalog_candidates,
                ]
                if str(value).count(".") == 2
            }
            unknown = sorted({
                value for value in selected
                if value.strip('"').upper() not in known_tables
            })
            if unknown:
                return ToolResult(
                    status="needs_input",
                    summary="Semantic context can only be read for verified table candidates.",
                    data={"unknown_tables": unknown},
                    error_code="unverified_semantic_selection",
                ).model_dump(mode="json")
            if self._workbench and hasattr(self._workbench, "read_stored_semantic_context"):
                return self._execute(
                    "read_stored_semantic_context",
                    lambda: self._workbench.read_stored_semantic_context(
                        context, source_tables or [], target_table
                    ),
                    safe_input={
                        "source_tables": source_tables or [],
                        "target_table": target_table,
                    },
                    cache_read=True,
                )
            page = dict(context.get("page_context") or {})
            semantic = dict(page.get("semantic_bundle") or page.get("semantic") or {})
            available = bool(
                semantic.get("bundle_hash")
                or semantic.get("composed_model_hash")
                or semantic.get("semantic_view_name")
                or semantic.get("view_name")
            )
            status = "available" if available else "unavailable"
            return self._execute(
                "read_stored_semantic_context",
                lambda: ToolResult(
                    status="succeeded",
                    summary=(
                        "Read the stored semantic context attached to this Workbench snapshot."
                        if available
                        else "Stored semantic context is unavailable; no semantic generation was attempted."
                    ),
                    data={
                        "status": status,
                        "source": "stored_registry",
                        "generation_allowed": False,
                        "semantic": semantic,
                    },
                    warnings=[] if available else ["semantic_context_unavailable"],
                    evidence_refs=[str(value) for value in [semantic.get("bundle_id"), semantic.get("bundle_hash")] if value],
                ),
                cache_read=True,
            )

        def workbench_rag(query: str, limit: int = 5) -> dict[str, Any]:
            """Search the existing governed Workbench RAG corpus with citations."""
            bounded_limit = max(1, min(limit, 10))
            return self._execute(
                "workbench_rag",
                lambda: self._workbench.search_workbench_rag(
                    self._context_provider(), query, bounded_limit
                ) if self._workbench else ToolResult(
                    status="failed",
                    summary="Workbench RAG search is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={"query": query[:4_000], "limit": bounded_limit},
                cache_read=True,
            )

        def search_run_attachments(query: str, limit: int = 8) -> dict[str, Any]:
            """Search only parsed files attached by the current user to this run."""
            bounded_limit = max(1, min(limit, 12))
            return self._execute(
                "search_run_attachments",
                lambda: ToolResult(
                    status="succeeded",
                    summary="Retrieved cited passages from run-owned uploaded evidence.",
                    data={"passages": self._workbench.search_run_attachments(
                        self._context_provider(), query, limit=bounded_limit)},
                ) if self._workbench else ToolResult(
                    status="failed", summary="Uploaded evidence search is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={"query": query[:4_000], "limit": bounded_limit},
                cache_read=True,
            )

        def sql_analyst(
            question: str,
            source_tables: list[str] | None = None,
            target_table: str | None = None,
        ) -> dict[str, Any]:
            """Ask Cortex Analyst through a stored view or composed stored bundle."""
            context = self._context_provider()
            selected = [
                *[str(value) for value in (source_tables or []) if str(value).strip()],
                *([str(target_table)] if target_table else []),
            ]
            known_tables = {
                str(value).strip('"').upper()
                for value in [
                    *(context.get("authorized_source_scope") or []),
                    *(context.get("authorized_target_scope") or []),
                    *self._catalog_candidates,
                ]
                if str(value).count(".") == 2
            }
            unknown = sorted({
                value for value in selected
                if value.strip('"').upper() not in known_tables
            })
            if unknown:
                return ToolResult(
                    status="needs_input",
                    summary="Cortex Analyst can only use verified table candidates.",
                    data={"unknown_tables": unknown},
                    error_code="unverified_semantic_selection",
                ).model_dump(mode="json")
            prepared_source = dict((self._prepared_plan_candidate or {}).get("source_preparation") or {})
            prepared_tables = {str(value).strip('"').upper() for value in [
                prepared_source.get("driving_source"), *(prepared_source.get("supporting_sources") or [])
            ] if value}
            requested_tables = {str(value).strip('"').upper() for value in source_tables or []}
            prepared_relationships = (
                list(prepared_source.get("relationships") or [])
                if requested_tables and requested_tables == prepared_tables
                and str(prepared_source.get("target_table") or "").upper() == str(target_table or "").upper()
                else None
            )
            return self._execute(
                "sql_analyst",
                lambda: self._workbench.ask_sql_analyst(
                    context,
                    question,
                    source_tables=source_tables or [],
                    target_table=target_table,
                    relationships=prepared_relationships,
                    prefer_stored_model=True,
                ) if self._workbench else ToolResult(
                    status="failed",
                    summary="Cortex Analyst is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={
                    "question": question[:4_000],
                    "source_tables": source_tables or [],
                    "target_table": target_table,
                },
            )

        def convert_mapping_to_dbt(mapping_key: str = "") -> dict[str, Any]:
            """Convert a completed, validated run-owned mapping to canonical dbt artifacts."""
            return self._execute(
                "convert_mapping_to_dbt",
                lambda: self._workbench.convert_mapping_to_dbt(
                    self._context_provider(), mapping_key or None
                ) if self._workbench else ToolResult(
                    status="failed",
                    summary="dbt conversion is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={"mapping_key": mapping_key or None},
            )

        def generate_mapping_tests(mapping_key: str = "") -> dict[str, Any]:
            """Generate canonical test artifacts for a completed, validated mapping."""
            return self._execute(
                "generate_mapping_tests",
                lambda: self._workbench.generate_mapping_tests(
                    self._context_provider(), mapping_key or None
                ) if self._workbench else ToolResult(
                    status="failed",
                    summary="Mapping test generation is unavailable.",
                    error_code="capability_unavailable",
                ),
                safe_input={"mapping_key": mapping_key or None},
            )

        def run_mapping_contract_tests(mapping_key: str = "") -> dict[str, Any]:
            """Run host-owned contract assertions against a validated, unchanged mapping draft."""
            return self._execute("run_mapping_contract_tests",
                lambda: self._workbench.run_mapping_contract_tests(self._context_provider(), mapping_key or None)
                if self._workbench else ToolResult(status="failed", summary="Contract testing unavailable.", error_code="capability_unavailable"),
                safe_input={"mapping_key": mapping_key or None})

        def execute_migration_workflow(
            target_tables: list[str] | None = None,
            requested_mappings: list[str] | None = None,
            supervisor_plan: dict[str, Any] | None = None,
        ) -> dict[str, Any]:
            """Execute the guarded draft-only migration workflow after discovery and planning."""
            governed_plan = dict(self._validated_supervisor_plan or supervisor_plan or {})
            governed_plan["_discovered_catalog_tables"] = sorted(self._catalog_candidates)
            return self._execute(
                "execute_migration_workflow",
                lambda: ToolResult(
                    status="succeeded",
                    summary="The guarded migration executor returned control to the supervisor.",
                    data=self._workflow_executor(
                        target_tables or [], requested_mappings or [], governed_plan
                    ),
                ),
                safe_input={
                    "target_tables": target_tables or [],
                    "requested_mappings": requested_mappings or [],
                    "plan_summary": {
                        "has_source_preparation": bool(governed_plan.get("source_preparation")),
                        "has_auto_map": bool(governed_plan.get("auto_map")),
                    },
                },
            )

        def firm_values_inventory(target_tables: list[str]) -> dict[str, Any]:
            """Which firm values the planned target tables use, which this project holds, and who holds the rest."""
            return self._execute(
                "firm_values_inventory",
                lambda: self._workbench.firm_values_inventory(self._context_provider(), list(target_tables or []))
                if self._workbench else ToolResult(status="failed", summary="Firm values are unavailable.",
                                                   error_code="capability_unavailable"),
                safe_input={"target_tables": list(target_tables or [])},
            )

        def import_firm_values(
            source_project_id: str, names: list[str] | None = None, overwrite: bool = False,
            user_confirmed: bool = False,
        ) -> dict[str, Any]:
            """Copy firm values from another project into this one. Set user_confirmed only when the user said
            to import from that project (a planning answer or the request itself); values differ per firm."""
            def run() -> ToolResult:
                if not self._workbench:
                    return ToolResult(status="failed", summary="Firm values are unavailable.",
                                      error_code="capability_unavailable")
                if not self._allow_direct_mutation or not user_confirmed:
                    return ToolResult(
                        status="failed", error_code="confirmation_required",
                        summary=(f"Ask the user whether to import firm values from project {source_project_id} "
                                 "(one planning question listing the values), then call again with user_confirmed."),
                    )
                return self._workbench.import_firm_values(
                    self._context_provider(), source_project_id, names or None, overwrite=overwrite)
            return self._execute(
                "import_firm_values", run,
                safe_input={"source_project_id": source_project_id, "names": names or [], "overwrite": overwrite,
                            "user_confirmed": user_confirmed},
            )

        def remember_preference(statement: str, scope: str, subject: str | None = None) -> dict[str, Any]:
            """Save a durable preference or rule the user stated ("we never map soft-deleted rows", "always use
            the CRM owner for OWNER_ID"). scope: user (this user everywhere) or project (everyone in the project).
            Only for something the user asked to be remembered or stated as a standing rule, not a one-off answer."""
            return self._execute(
                "remember_preference",
                lambda: self._workbench.remember_user_preference(self._context_provider(), statement, scope, subject)
                if self._workbench else ToolResult(status="failed", summary="Preferences are unavailable.",
                                                   error_code="capability_unavailable"),
                safe_input={"scope": scope, "subject": subject, "statement": str(statement or "")[:300]},
            )

        self._plan_validator = validate_migration_plan
        self._prepare_evidence = prepare_migration_evidence
        functions = [
            inspect_workbench_context, search_catalog, search_catalog_batch, inspect_table_contract,
            inspect_table_contracts_batch, profile_table, execute_read_only_sql, retrieve_fir_evidence,
            prepare_migration_evidence, prepare_multi_target_evidence, list_projects, search_precedents,
            list_project_templates, get_project_context, inspect_precedent_mapping, validate_migration_plan,
            read_stored_semantic_context, workbench_rag, search_run_attachments, sql_analyst,
            convert_mapping_to_dbt, generate_mapping_tests, run_mapping_contract_tests, firm_values_inventory,
            import_firm_values, remember_preference,
        ]
        if self._allow_direct_mutation:
            functions.append(execute_migration_workflow)
        return [StructuredTool.from_function(self._trace_early_refusals(function),
                    args_schema=PlanValidationArguments if function.__name__ == "validate_migration_plan" else None)
                for function in functions]

    def _trace_early_refusals(self, function: Callable[..., Any]) -> Callable[..., Any]:
        """Trace a tool refusal that returns before ``_execute`` records the call.

        Scope and input checks return early. Without an event the refusal is
        invisible in the chat and the run looks stalled while the model retries.
        """
        import functools

        @functools.wraps(function)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            self._execute_depth.value = 0
            result = function(*args, **kwargs)
            if function.__name__ == "validate_migration_plan" and isinstance(result, dict):
                with self._read_cache_lock:
                    if result.get("status") == "succeeded":
                        self._plan_validation_failure = None
                    elif result.get("status") in {"denied", "needs_input", "failed"}:
                        code = str(result.get("error_code") or "invalid_plan_contract")
                        prior = self._plan_validation_failure or {}
                        attempts = int(prior.get("attempts", 0)) + 1 if prior.get("error_code") == code else 1
                        self._plan_validation_failure = {
                            "error_code": code, "attempts": attempts,
                            "summary": result.get("summary"),
                            "validation_errors": dict(result.get("data") or {}).get("validation_errors") or [],
                        }
            if (not getattr(self._execute_depth, "value", 0) and isinstance(result, dict)
                    and result.get("status") in {"denied", "needs_input", "failed"}):
                name = function.__name__
                label = str(self.BUSINESS_METADATA.get(name, {}).get("business_label")
                            or name.replace("_", " ").capitalize())
                self._trace("tool.denied", "needs_review", f"{label}: {result.get('summary') or 'refused.'}", {
                    "trace_id": f"tool:{name}:refused:{uuid4().hex}", "kind": "tool", "label": label,
                    "error_code": result.get("error_code"),
                    "details": {key: value for key, value in dict(result.get("data") or {}).items()
                                if key in {"unknown_tables", "issues", "missing", "validation_errors"}},
                })
            return result

        return wrapper

    @property
    def plan_validation_failure(self) -> dict[str, Any] | None:
        return dict(self._plan_validation_failure) if self._plan_validation_failure else None

    @property
    def validated_supervisor_plan(self) -> dict[str, Any] | None:
        return dict(self._validated_supervisor_plan) if self._validated_supervisor_plan else None

    @staticmethod
    def _join_identity(value: dict[str, Any]) -> tuple[Any, ...]:
        def fqn(raw: Any) -> str:
            if isinstance(raw, dict):
                raw = ".".join(str(raw.get(key) or "") for key in ("database", "schema", "table"))
            return str(raw or "").strip('"').upper()
        return (
            fqn(value.get("left_table")), fqn(value.get("right_table")),
            str(value.get("join_type") or "INNER").upper(),
            tuple(sorted((str(item.get("left_column") or "").upper(),
                          str(item.get("right_column") or "").upper(),
                          str(item.get("operator") or "=").upper())
                         for item in value.get("conditions") or [] if isinstance(item, dict))),
        )

    def _mapping_spec_issues(
        self, mapping_specs: list[dict[str, Any]], dependencies: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Hold every mapping to the same evidence bar as a single-target plan.

        Each spec is compared with the evidence prepared for its own target, so
        one mapping's verified joins can never justify another mapping.
        """
        from app.agent_tools.source_readiness import disconnected_plan_sources

        issues: list[dict[str, Any]] = []

        def issue(spec: dict[str, Any], code: str, message: str, **details: Any) -> None:
            issues.append({"mapping_key": spec.get("mapping_key"), "target_table": spec.get("target_table"),
                           "error_code": code, "message": message, **details})

        keys = [str(spec.get("mapping_key") or "") for spec in mapping_specs]
        if len(set(keys)) != len(keys):
            issues.append({"error_code": "duplicate_mapping_key", "message": "Every mapping_spec needs a unique mapping_key."})
        targets = [str(spec.get("target_table") or "").strip('"').upper() for spec in mapping_specs]
        if len(set(targets)) != len(targets):
            issues.append({"error_code": "duplicate_target", "message": "Each target table may appear in only one mapping_spec."})
        for spec in mapping_specs:
            source = dict(spec.get("source_preparation") or {})
            driving = source.get("driving_source")
            supporting = list(source.get("supporting_sources") or [])
            prepared = self._prepared_plan_candidates.get(str(spec.get("target_table") or "").strip('"').upper())
            if prepared is None:
                issue(spec, "mapping_evidence_missing",
                      "Prepare evidence for this target (prepare_multi_target_evidence) before planning it.")
                continue
            if not driving:
                issue(spec, "driving_source_required", "Select one verified driving source.")
                continue
            if source.get("unresolved_items"):
                issue(spec, "source_design_incomplete", "Source design has unresolved evidence.",
                      unresolved=list(source.get("unresolved_items") or [])[:6])
                continue
            prepared_source = dict(prepared.get("source_preparation") or {})
            planned_tables = {str(value).strip('"').upper() for value in [driving, *supporting] if value}
            prepared_tables = {
                str(value).strip('"').upper()
                for value in [prepared_source.get("driving_source"), *(prepared_source.get("supporting_sources") or [])]
                if value
            }
            if prepared_tables and planned_tables != prepared_tables:
                issue(spec, "source_graph_evidence_stale",
                      "The selected sources differ from this target's prepared evidence.",
                      prepared_sources=sorted(prepared_tables), planned_sources=sorted(planned_tables))
                continue
            prepared_joins = {self._join_identity(item) for item in prepared_source.get("relationships") or []
                              if isinstance(item, dict)}
            if any(self._join_identity(item) not in prepared_joins
                   for item in source.get("relationships") or [] if isinstance(item, dict)):
                issue(spec, "unverified_plan_relationship",
                      "A join was not verified in this target's evidence package.")
                continue
            if supporting and not source.get("relationships") and not source.get("precedent_reference"):
                issue(spec, "join_definitions_required", "Every multi-source mapping needs verified joins.")
                continue
            if supporting and not source.get("precedent_reference"):
                disconnected = disconnected_plan_sources(driving, supporting, list(source.get("relationships") or []))
                if disconnected:
                    issue(spec, "join_graph_incomplete", "Some sources have no verified join path.",
                          disconnected_sources=disconnected)
                    continue
            missing_sql = [
                str(item.get("name") or item.get("id") or "derived source")
                for item in source.get("derived_sources") or []
                if isinstance(item, dict) and not str(item.get("sql") or item.get("sql_outline") or "").strip()
            ]
            if missing_sql:
                issue(spec, "derived_source_sql_required", "Derived sources need executable SQL.", missing_sql=missing_sql)
        known_keys = set(keys)
        consumers: dict[str, set[str]] = {}
        for edge in dependencies:
            consumer, producer = str(edge.get("consumer_mapping") or ""), str(edge.get("producer_mapping") or "")
            if consumer not in known_keys or producer not in known_keys:
                issues.append({"error_code": "unknown_dependency_mapping",
                               "message": f"Dependency {producer} -> {consumer} names a mapping that is not planned."})
            elif edge.get("required", True) and not edge.get("producer_columns"):
                # An edge without producer columns can never be satisfied and
                # would leave the consumer waiting until review.
                issues.append({"error_code": "dependency_producer_columns_required",
                               "message": f"Dependency {producer} -> {consumer} must name producer_columns."})
            consumers.setdefault(consumer, set()).add(producer)
        from app.migration_workflow.dependency_inference import find_cycle
        cycle = find_cycle(consumers)
        if cycle:
            issues.append({"error_code": "dependency_cycle",
                           "message": "Mapping dependencies form a cycle: " + ", ".join(sorted(cycle))})
        return issues

    @property
    def prepared_plan_candidate(self) -> dict[str, Any] | None:
        return dict(self._prepared_plan_candidate) if self._prepared_plan_candidate else None

    @property
    def prepared_plan_review(self) -> dict[str, Any] | None:
        return dict(self._prepared_plan_review) if self._prepared_plan_review else None

    @property
    def evidence_failure(self) -> dict[str, Any] | None:
        return dict(self._evidence_failure) if self._evidence_failure else None

    def validate_prepared_plan(self) -> dict[str, Any]:
        """Host fallback for a model that stalls after evidence preparation."""
        if self._plan_validator is None or self._prepared_plan_candidate is None:
            return ToolResult(
                status="needs_input",
                summary="No prepared migration plan candidate is available.",
                error_code="prepared_plan_unavailable",
            ).model_dump(mode="json")
        # Keep supervisor repairs (coverage, SQL steps, explicit project choice).
        # Revalidating the earlier evidence-only candidate would discard them.
        return self._plan_validator(dict(self._validated_supervisor_plan or self._prepared_plan_candidate))

    def restore_prepared_plan_for_checkpoint(
        self, candidate: dict[str, Any], catalog_candidates: list[str],
    ) -> bool:
        """Restore only the server-stored, scoped plan while resuming a question."""
        from app.agent_tools.join_research import table_name

        source = dict(candidate.get("source_preparation") or {})
        selected = {table_name(value) for value in [
            source.get("driving_source"), *(source.get("supporting_sources") or []),
        ] if value}
        visible = {table_name(value) for value in catalog_candidates}
        context = self._context_provider()
        if not selected or not selected <= visible or not all(
            self._within_authorized_table_scope(table, context) for table in visible
        ):
            return False
        with self._catalog_lock:
            self._catalog_candidates.update(visible)
        self._prepared_plan_candidate = deepcopy(candidate)
        self._validated_supervisor_plan = None
        return True

    def apply_reviewed_join_path(self, joins: list[dict[str, Any]],
                                 excluded: list[str] | None = None) -> dict[str, Any]:
        """Stage explicitly reviewed joins (and user-excluded sources) after checking current contracts."""
        from app.agent_tools.join_research import normalized_candidate, table_name
        from app.agent_tools.source_readiness import disconnected_plan_sources

        candidate = dict(self._prepared_plan_candidate or {})
        source = dict(candidate.get("source_preparation") or {})
        removed = {table_name(value) for value in excluded or []} - {table_name(source.get("driving_source"))}
        removed.discard("")
        if removed:
            source = self._without_sources(source, removed)
        selected = {table_name(value) for value in [source.get("driving_source"), *(source.get("supporting_sources") or [])]}
        selected.discard("")
        visible = {table_name(value) for value in self._catalog_candidates}
        if not selected or self._workbench is None:
            return ToolResult(status="needs_input", summary="The current source selection is unavailable.",
                              error_code="source_selection_unavailable").model_dump(mode="json")
        verified = []
        contracts: dict[str, dict[str, Any]] = {}
        for raw in joins:
            item = normalized_candidate(raw)
            if not item or not {item["left_table"], item["right_table"]} <= visible | selected:
                return ToolResult(status="needs_input", summary="A proposed join is outside the selected source graph.",
                                  error_code="join_scope_invalid").model_dump(mode="json")
            for side in ("left", "right"):
                table = item[f"{side}_table"]
                inspected = self._workbench.inspect_table_contract(table)
                if inspected.status != "succeeded":
                    return inspected.model_dump(mode="json")
                columns = {str(value).upper() for value in inspected.data.get("columns") or []}
                contracts[table] = {str(value.get("name") or "").upper(): str(value.get("type") or "").upper()
                                    for value in inspected.data.get("column_contracts") or [] if isinstance(value, dict)}
                if any(condition[f"{side}_column"].upper() not in columns for condition in item["conditions"]):
                    return ToolResult(status="needs_input", summary=f"A proposed join column is absent from {table}.",
                                      error_code="join_column_invalid").model_dump(mode="json")
                if side == "right" and item.get("normalized_lookup_alternative") not in (None, *columns):
                    return ToolResult(status="needs_input", summary=f"The lookup alias column is absent from {table}.",
                                      error_code="join_column_invalid").model_dump(mode="json")
                if any(entry["column"] not in columns for entry in item.get("literal_filters") or [] if entry["side"] == side):
                    return ToolResult(status="needs_input", summary=f"A proposed join filter column is absent from {table}.",
                                      error_code="join_column_invalid").model_dump(mode="json")
            for condition in item["conditions"]:
                left_type = contracts[item["left_table"]].get(condition["left_column"])
                right_type = contracts[item["right_table"]].get(condition["right_column"])
                if left_type and right_type and (
                    self._workbench._type_family(left_type) != self._workbench._type_family(right_type)
                ):
                    return ToolResult(status="needs_input", summary="The proposed join columns have different current types.",
                                      error_code="join_type_mismatch").model_dump(mode="json")
            if item.get("normalized_lookup_alternative"):
                left_type = contracts[item["left_table"]].get(item["conditions"][0]["left_column"])
                alias_type = contracts[item["right_table"]].get(item["normalized_lookup_alternative"])
                if left_type and alias_type and (self._workbench._type_family(left_type) != "text" or
                                                 self._workbench._type_family(alias_type) != "text"):
                    return ToolResult(status="needs_input", summary="Normalized lookup columns must be text.",
                                      error_code="join_type_mismatch").model_dump(mode="json")
            verified.append(item)
        bridge_tables = {item[f"{side}_table"] for item in verified for side in ("left", "right")} - selected
        if bridge_tables:
            source["supporting_sources"] = list(dict.fromkeys([
                *list(source.get("supporting_sources") or []), *sorted(bridge_tables)]))
            rationale = dict(source.get("source_rationale") or {})
            for table in bridge_tables:
                rationale[table] = "User-reviewed bridge in the current source graph."
            source["source_rationale"] = rationale
        selected_columns = {table_name(table): list(columns) for table, columns in
                            dict(source.get("selected_columns_by_table") or {}).items()}
        for item in verified:
            for side in ("left", "right"):
                table = item[f"{side}_table"]
                selected_columns[table] = list(dict.fromkeys([
                    *selected_columns.get(table, []),
                    *(condition[f"{side}_column"] for condition in item["conditions"]),
                    *([item["normalized_lookup_alternative"]] if side == "right" and item.get("normalized_lookup_alternative") else []),
                    *(entry["column"] for entry in item.get("literal_filters") or [] if entry["side"] == side),
                ]))
        source["selected_columns_by_table"] = selected_columns
        # The resulting graph includes a user-reviewed decision and is no
        # longer an exact reuse of the historical source snapshot.
        source["precedent_reference"] = {}
        source["relationships"] = list({json.dumps(item, sort_keys=True): item
                                        for item in [*list(source.get("relationships") or []), *verified]}.values())
        missing = disconnected_plan_sources(source.get("driving_source"),
                                            list(source.get("supporting_sources") or []), source["relationships"])
        if missing:
            return ToolResult(status="needs_input", summary="The reviewed joins still leave sources disconnected.",
                              data={"disconnected_sources": missing}, error_code="join_graph_incomplete").model_dump(mode="json")
        source["unresolved_items"] = [value for value in source.get("unresolved_items") or []
                                      if not str(value).startswith("Current relationship evidence has no join path")]
        candidate["source_preparation"] = source
        # With every join now resolved, columns still lacking an in-scope
        # candidate are shown in the plan as explicit, reviewable gaps rather
        # than blocking approval (validation still refuses a plan covering none).
        candidate["auto_map"] = {**dict(candidate.get("auto_map") or {}), "allow_partial_coverage": True}
        self._prepared_plan_candidate = candidate
        self._validated_supervisor_plan = None
        return self.validate_prepared_plan()

    @staticmethod
    def _without_sources(source: dict[str, Any], removed: set[str]) -> dict[str, Any]:
        """``source_preparation`` with user-excluded supporting tables and everything built on them removed."""
        from app.agent_tools.join_research import table_name

        def uses_removed(item: Any) -> bool:
            return isinstance(item, dict) and bool(
                {table_name(item.get("left_table")), table_name(item.get("right_table"))} & removed)

        source = dict(source)
        source["supporting_sources"] = [value for value in source.get("supporting_sources") or []
                                        if table_name(value) not in removed]
        for key in ("source_rationale", "selected_columns_by_table", "filters"):
            if isinstance(source.get(key), dict):
                source[key] = {name: value for name, value in source[key].items() if table_name(name) not in removed}
        source["relationships"] = [item for item in source.get("relationships") or [] if not uses_removed(item)]
        # A CTE over an excluded table cannot be built; its columns become gaps.
        source["derived_sources"] = [
            item for item in source.get("derived_sources") or []
            if not (isinstance(item, dict) and {table_name(value) for value in item.get("base_source_tables") or []} & removed)
        ]
        source["unresolved_items"] = [value for value in source.get("unresolved_items") or []
                                      if not any(str(value).upper().endswith(table) for table in removed)]
        source["excluded_sources"] = sorted({*(source.get("excluded_sources") or []), *removed})
        # The graph no longer matches the historical snapshot exactly.
        source["precedent_reference"] = {}
        return source

    @classmethod
    def public_contracts(cls) -> list[dict[str, Any]]:
        contracts: list[dict[str, Any]] = []
        for contract in cls.CONTRACTS:
            data = contract.model_dump(mode="json")
            data.update(cls.BUSINESS_METADATA.get(contract.name, {}))
            data["business_label"] = data.get("business_label") or contract.name.replace("_", " ").title()
            data["purpose"] = data.get("purpose") or contract.description
            data["when_to_use"] = data.get("when_to_use") or "When the active migration plan requires this capability."
            data["when_not_to_use"] = data.get("when_not_to_use") or "For conversational or diagnostic turns that do not require migration execution."
            data["expected_output"] = data.get("expected_output") or "A structured, traceable capability result"
            contracts.append(data)
        return contracts

    @classmethod
    def capability_answer(cls) -> str:
        """The "what can you do" answer, generated from the registered capabilities.

        Grouped by what a capability may change (its declared risk), so the
        answer stays accurate when tools are added or removed. Only
        capabilities with business metadata are user-facing.
        """
        groups = (
            ({ToolRisk.READ}, "Research and answer (read-only)"),
            ({ToolRisk.DRAFT_WRITE}, "Create and validate run-owned drafts"),
            ({ToolRisk.APPROVAL_REQUIRED, ToolRisk.PUBLISH}, "Publish (only after your explicit approval)"),
        )
        sections = []
        for risks, heading in groups:
            lines = [f"- **{meta['business_label']}**: {meta['purpose']}"
                     for contract in cls.CONTRACTS
                     if contract.risk in risks and (meta := cls.BUSINESS_METADATA.get(contract.name))
                     and meta.get("business_label") and meta.get("purpose")]
            if lines:
                sections.append(f"**{heading}**\n" + "\n".join(lines))
        return (
            "I'm the AIA Migration Workbench agent. These are the capabilities I can use:\n\n"
            + "\n\n".join(sections)
            + "\n\nI pause only for low-confidence decisions, publication, or changes to your own work. "
              "Name a target table and its source schema to start a mapping, or turn on **Plan** to review "
              "the plan before anything is drafted."
        )
