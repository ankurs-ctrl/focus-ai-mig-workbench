# Auto-map reconciliation execution record

## 2026-10-16 published-learning focus

- User narrowed the immediate scope to published mapping learning; Offline
  Learning investigation is paused. No new publication or historical repair ran.
- Verified live mapping 6606, version 1001/1: its immutable version stores 33 rows
  and 14,036 characters of authored SQL (SHA256
  `e757ff31d619953b52fe74a78a74fd5ef674791ffd983dabb7043fc028f332f3`).
  That historical payload has no relation graph or compiled SQL. New local code
  cannot retroactively recover missing historical contracts without scoped repair.
- Publication already captures the full snapshot, authored SQL, compiled SQL
  fields, version header and durable projection intent. Added a 137-row regression
  proving exact SQL/whitespace and all rows survive the version/outbox capture.
- Local recipe projection now preserves per-source type/grain/semantic contracts
  from the captured relation graph, supports attribute-only Project Value rows,
  and references the snapshot/version/capture plus hashes of captured SQL artifacts.
  Full SQL remains in the version record, not duplicated into every agent recipe.
- Published project context comes from the immutable snapshot, not a later project
  lookup. Missing mapped-row extraction now fails strict projection rather than
  claiming complete learning; the durable outbox can retry against the same capture.
- Writer-to-reader regression verifies a published recipe is eligible with matching
  source contracts and remains unresolved for incompatible grain. Quoted profile
  identities remain distinct; conflicting nested contracts stay unknown.
- Full backend run before the final added coverage check: 1022 passed, three
  inherited failures (two protected-deployer assertions and Windows POSIX modes).
  Frontend TypeScript passed. Live Search visibility and next Auto-map reuse of a
  new publication remain unverified; no deployment, FIR activation or trust promotion.

## 2026-10-16 timeout continuation and real UI evidence

- Reconciled late job `28bddcd6-1abb-4f46-811b-f3b801115f8d` before retry:
  completed in 234.506 seconds; 37 targets, four overlapping groups, 13 grouped
  source-agent calls and two transformation-specialist calls. All 40 audit files
  passed content hashes. Its result never reached the old UI/draft (11/42 rows).
- Local fixes: per-key bounded local session acquisition; exclusive local
  transaction session reuse; lightweight recommendation listing; nonblocking
  optional errors with retry; target-identity fetch dependencies; transient status
  normalization and identical in-flight autosave coalescing; durable acceptance
  before semantic preparation and request-ID recovery without duplicate POST.
- Actual UI job `2e276746-61f2-5180-9ec5-48cdeec34259` accepted in 2.630 seconds,
  finished in 243.889 seconds and delivered partial/final results. UI 33/42 mapped,
  37 processed, nine requiring review. This exceeds the two-minute goal.
- Autosave during this run measured 1.997 seconds initially and 5-10.2 seconds
  for changed partial/final/compiler states. Idle processing did not continuously
  write. Recommendation reads after restart took 1.9-2.5 seconds without modal.
- Actual Compile & Validate passed for mapped columns; saved snapshot
  `snapshot_76cfddbc6ac149b085e3` retained the job and compiler-ready state.
  Browser refresh/reopen retained 33/42 and compiler-ready state; its one 4.924s
  save settled. No mapping publication or target load occurred.
- Runtime testing found an older poll could overwrite the dispatcher's newer
  in-memory preparation revision and lease fence. Fixed locally and regression
  tested and loaded after the job completed; the above run predates that fix and
  showed zero batches in progress. Another live run is still needed to verify it.
- Verification: final UTF-8 backend suite 1016 passed/three inherited failures;
  focused proxy/transaction 43 passed;
  persistence 15/15, timeout recovery, row recovery, Apply origin, artifact,
  SQL hydration, assistant continuity and optional semantics harnesses passed.
  TypeScript and production frontend build (23 static pages) passed. Local backend
  and frontend were restored afterward; no deployment was performed.
- The 42-versus-37 count is reconciled: five saved-only rows remain outside the
  current target list (`xxxOwnerName`, `xxOGStateCode`, `xxOGCountryCode`,
  `xxLegacyPortfolioSystemHHID`, `xxSourceForReferral`). They were preserved,
  not silently removed. Therefore 33/42 includes five pre-existing extra rows.
- Business correctness is NOT established: LASTREVIEW was proposed from a
  next-review source; NEXTREVIEW became unresolved compared with the original
  imported expression. Do not equate compiler validation with accepted learning.
  Target review, manual correction/future reuse, cross-replica acceptance race
  verification, complete held-out workflow and FIR activation gates remain open.
- Protected deployment script unchanged; no deployment, agent change, FIR
  activation, historical repair, commit or push.

## Baseline

Implementation: FEATURE `ffp_ai_mig_workbench_zip_review`, HEAD `dad856f`,
branch `feature/automap-context-firm-values-2.9.6`, extensive inherited dirty work.
Comparison refs: cached `origin/develop` = `6cf8f93`, `origin/Master` = `fa449c4`.
Both retain 24/12 semantic caps and a minimal fallback without semantic bodies or
learning. Historical results have not been rerun with their original live agent
versions; no claim of equivalent business accuracy is made.

At execution start neither 8000 nor 3000 was listening. Runtime restart and live
acceptance are pending. Protected deployer hash remains
`486DDC012EFFA2EF7B19C6A1FD40CB7622F8929A15A0C3DA9D2E856B9837BAC6`.

## Authoring and learning paths

| Path | Observed implementation | Gap |
| --- | --- | --- |
| Auto-map | Page -> durable batches -> normalized rows -> autosave | Generated/MAPPED is not user acceptance |
| Manual edit | Mapping reducer -> debounced `workspace.autosaved` | Explicit action-based learning projection cannot assume edit/acceptance metadata was supplied |
| Assistant Apply | Artifact -> mapping row -> same snapshot persistence | Origin and user acceptance must be distinct; expression must survive save and next retrieval |
| Publication | Durable version -> publish outbox -> agent learnings, structural projector and recipe writer | Projector records outcome but writers omit TRUST_STAGE/version evidence |
| Correction | Agent-learning writer and inference correction reader use different stores/shapes | Mandatory negative evidence needs explicit bridge/coverage |
| FIR queue | Pattern MERGE retains existing canonical ID; job uses input pattern ID | Suspected source of orphaned work; verify exact matching before repair |

Acceptance inventory: 9601 HOUSEHOLD (37 targets), 7401 AGREEMENTS (16 targets),
8201 or another prior successful published mapping, plus held-out direct, constant,
project Value, quoted identifier, complex expression and >24-relation fixtures.
7401 baseline: 7 compiler-ready, 6 disconnected derived bindings, 3 no executable
binding. These diagnostics are not a completed target-level business gold set.

## Live planning evidence (read-only)

- Search services active. Recipes: 91 index-eligible of 974 stored.
- Live queue still globally marks alternate target-column reuse keys contradicted;
  356 active flags match this formula. Local queue already has a narrower rule.
- Both live SQL and Python learning writers omit trust. 27 project2105 source
  learnings say published but lack snapshot/version/validation evidence fields.
- 265 active recipe relational/payload validation mismatches.
- 16 streams non-stale, 11 tasks started; successful task wrappers coexist with
  32 failed/26 running jobs, 337 pending semantic items and 89 dead letters.
- 59/60 semantic dead letters have missing canonical pattern IDs.

## Gates

No live procedure/agent publication, stored-data repair, task rescheduling, stream
replacement, mapping publication, target load, commit/push or deployment is part
of an implicit local change. Prepare exact reviewable mutations first. Keep
experimental retrieval and independent FIR history flags disabled until accepted.

Further baseline gold-set review and full live instruction comparison are part of
controlled verification; writer repairs can proceed independently of those gates.

## Local implementation checkpoint

- Versioned capture attributes and published/manual-save receipts now flow through
  Python learning writes, the local SQL helper, Search labels and canonical reads.
  Receipt-shape checks are not a substitute for checking durable authority at every
  external writer boundary. Cross-writer identity parity remains open.
- Explicit saved row changes capture exact before/after executable decisions and a
  deterministic FIR event ID before trusted projection. Unchanged saves, generated
  rows, confidence-only churn and unsaved edits do not become accepted decisions.
  Row-only projections do not promote unrelated joins/CTEs/query rules.
- Mandatory saved corrections are read directly by project/mapping/target, outside
  positive Search quotas. Rule-only corrections do not prohibit the unchanged valid
  source. Exact new negatives are population-scoped; a later explicit reversal does
  not ban its newly accepted decision. Legacy negative reconciliation remains open.
- Pattern MERGE and canonical queue lookup now agree on exact target and ownership
  scope. Job identity is versioned with persisted IDs, preventing reuse of an older
  transient-ID inventory. Row/payload lifecycle updates share one expression;
  explicit correction means accepted, not automatically SQL validated.
- FIR invocation keeps model-reported counts as metadata, not persisted outcomes.
  Queue enrichment counts join completed work to actual coherent canonical rows;
  telemetry is attached to the exact run ID. Search visibility remains unverified.
  Both application and SQL workers stop claiming queued inventory was promoted.
  Failed/in-progress queue jobs no longer return unconditional outer success.
- Focused preparation reads small authoritative project/mapping metadata once. The
  packet preserves project details, saved intent, owned current decisions and
  selected mapping proposals without treating proposals as historical proof.
- Release manifest selection now includes FIR procedures, Search/bootstrap inputs
  and tests, not just the application and agent YAML. Private env/cache/log content
  remains excluded. This inventory does not authorize deployment.

## Verification at this checkpoint

- Latest full backend unit suite: **976 passed, 3 known failures, 3 warnings**.
  Failures remain the protected deployer's missing bulk-write export and legacy
  batch default, plus Windows POSIX `0600` assertion. Protected deployer unchanged.
- TypeScript check passed. Manual-save/cancel/reopen harness passed; persistence
  harness 12/12 passed. Apply/artifact, SQL hydration, assistant continuity and
  independent semantic-review harnesses passed. Frontend production build passed
  (Next.js 16.2.2; all 23 static pages generated).
- Offline saved 9601 replay: four groups of **9/9/9/10**; complete mandatory message
  sizes **79,523 / 80,818 / 81,117 / 80,356 characters**. This reuses archived
  evidence, not new live discovery or proven model comprehension/accuracy.
- Read-only live project query and saved-correction query shape execute successfully.
  SQL procedures have NOT been Snowflake compile-validated or deployed. Embedded
  handler tests and SQLGlot parsing are local verification only. A compile-only
  attempt for SP_RECORD_AGENT_LEARNING was denied by the chat's USER SPECIFIED
  restricted session scope (procedure OWNERSHIP). No alternate connection, grant,
  procedure execution or deployment was attempted.

## Read-only legacy reconciliation inventory

Project 2105 has 47 active null-trust learnings with published outcome and an
associated mapping version snapshot: 27 column mappings, 11 CTE lineage records,
4 joins, 1 filter and 4 transformation patterns. Existence of a version alone is
not proof of the learning's contents.

For the 27 column mappings, exact target/source-array/expression matching against
mapped source-mode rows of published snapshots gives:

| Candidate class | Records |
| --- | ---: |
| Latest published binding match | 15 |
| Historical published binding match | 10 |
| No exact binding match | 2 |

These are candidates, not approved repairs. Full source/population/target contract,
version chronology, lifecycle and provenance validation is still required. No
records were changed or promoted.

Live definition SHA256 values (read-only observation):

| Procedure | Definition hash |
| --- | --- |
| SP_FIR_INVOKE_AGENT | 5abfe94ba3844a456bddebc86ce1542f20f701c82a5668378bdc305e4518187c |
| SP_FIR_PROCESS_LEARNING_QUEUE | 9437cbad9749d545ed9329b191538dd3d4ff8f79fdb2bee9da9a0511ba522292 |
| SP_RECORD_AGENT_LEARNING | e1797a174b97f6db0b2ce5a747cc5b39ccaba8fd4e10fab61c29642d1eda27e0 |

None contains the corresponding new capture/explicit-negative/search-visibility
markers. A local passing test does not establish live parity.

## Subsequent local lifecycle implementation

- Assistant Apply preserves request/artifact origin through the review, row,
  snapshot, persistence signature and reopen paths. It stays an `applied_draft`
  observation, not manual acceptance. Generation clears obsolete Apply origin.
- A new browser validation marker triggers independent compilation of the saved
  mapped rows with current project Values and a read-only Snowflake EXPLAIN.
  Client SQL/signatures are not proof. A durable `mapping.compiler_validated`
  event binds exact targets, contract/SQL hashes and snapshot before row-only
  promotion. SQL validation explicitly does not establish business correctness.
- Manual/publication receipts now use actual deterministic FIR event primary keys,
  keeping request/idempotency identity separate. New versioned Python writes,
  scoped readers, Search hydration and saved negatives verify the durable event,
  owning snapshot, target decision and applicable publication/validation authority.
  Acceptance is target-bound; negative records are bound to their saved population.
- The SQL helper has conservative event/snapshot/row checks, but remains local and
  uncompiled on Snowflake because of the previously recorded RSS restriction.
  Its legacy-expression normalization is not yet equivalent to Python. Structural
  receipts require the application-side path; do not declare every writer reconciled.
- Trusted row identity uses a shared ordered-array SHA256 definition. One ASCII
  test vector matches an actual read-only Snowflake SELECT and Python. This is not
  comprehensive Unicode/legacy serialization validation.
- The local scheduled queue no longer depends solely on stream readiness. Its
  existing 02:40/14:40 UTC schedule and one-job/ten-item bounds are unchanged.
  Nothing was activated live, and the broad task file must not be deployed blindly.
- Recipe extraction now retains saved `target_type` and an explicitly known
  single-source `source_type`/`source_grain`; it does not copy target types onto
  unknown sources or guess types for multi-source expressions. Saved dictionary
  filters/grouping/query modifiers now survive recipe projection as an exact
  population contract rather than being dropped by list iteration. Both fixes
  have focused regressions; they do not backfill existing incomplete recipes.

## Complete live agent inspection

`scripts/audit_workbench_agents.py` uses supported Agent Studio `agent-read` only.
All four orchestration instruction sections differ from the local templates.

| Agent | Model | Live budget | Native tools | Response instructions match |
| --- | --- | --- | --- | --- |
| Source Mapping | claude-haiku-4-5 | 200s / 16000 tokens | None | No |
| Builder | claude-haiku-4-5 | No explicit budget in returned orchestration | SearchWorkbenchRag, SearchFIRKnowledge, AGT_SOURCE_MAPPING, AGT_TRANSFORMATION_RULE | Yes |
| Transformation | auto | 75s / 4500 tokens | None | No |
| FIR | claude-sonnet-4-6 | 600s / 120000 tokens | Ten inspected native tools | Yes |

Full-spec hashes:

- Source Mapping: `258eeb11a9ac2efd54c8b06d83ee4c222088c214c3e56b61f4f36dc989bab25f`
- Builder: `a20763c8a4861057472558f46119a12d388e2e028f37a9a405857d42aa0e9880`
- Transformation: `b9d78354803a1898c49c44d066721f5f5c0a962c4eb43063bbf8be7a4e834f0e`
- FIR: `baf8a557be0a5db20c4e10a9b33e532beb9db478d79803b7cdb2194ac8d37dd4`

No agent was saved, published or deployed. Model budgets were not increased.

## Current-evidence four-group preflight

The saved 9601 request supplies its archived source/semantic snapshot. The
`--prepare-current` path reloads current project metadata, Values, links,
corrections and Search/canonical evidence. It does not claim the archived source
semantics are newly refreshed. No model calls or mapping writes were made.

| Group | Targets | Complete initial chars / UTF-8 bytes | Applicable recipes |
| --- | ---: | ---: | ---: |
| 0 | 9 | 75340 / 75346 | 0 |
| 1 | 9 | 76008 / 76014 | 0 |
| 2 | 9 | 77535 / 77541 | 0 |
| 3 | 10 | 76989 / 76995 | 0 |

Exact reconstruction passes and all packets fit existing configured limits.
Continuation sizes are identical because no positive recipe was admitted; this
does NOT satisfy the admitted-history/specialist continuation-pressure gate.

Twelve published recipes were hydrated and rejected at applicability for missing
compatible source roles/types/grain; one also lacks a required relationship.
For `tmp_23b927187a98bd6ae39dd9be`, the stored source is TMD ADDRESSES and the
current request selects EverNest sources. Neither source-family equivalence nor
business/grain compatibility is established. The request supplies 316 retrieved
column identities and 253 typed profiles, but zero grained profiles.

The original compact console summary printed the FIRST target's inapplicable
count (NAME = 0), not the batch total. The Mail Merge target had one unresolved
recipe. No evidence proved that this row was silently lost in SQL or schema
parsing. The script now aggregates batch exclusions, and retrieval exposes
schema, canonical-filter, duplicate, quota and applicability reasons explicitly.
Cached summaries are readable with `--summary-only` without printing packet bodies.

## Verification update

- Final backend unit suite: **1004 passed, 3 known failures, 3 warnings in 24.08s**.
  The failures are the two protected-deployer assertions and Windows `0600`
  assertion described above. No tests were weakened and the deployer is unchanged.
- New focused suite: **52 passed**, including Apply-as-observation -> actual
  compiler -> durable event -> trusted projection -> Search hydration preserving
  exact expression/origin. Sessions are fakes; this is not a live outbox test.
- Latest frontend production build passed after Apply-origin changes: Next.js
  16.2.2, TypeScript and all 23 static pages. Standalone TypeScript passed.
- Persistence 12/12, Apply-origin, mapping-row recovery, artifact and assistant
  continuity harnesses passed. `git diff --check` passed (checkout CRLF warnings).
- No backend/frontend server restart, live procedure calls, task edits, historical
  repairs, mapping publications, loads, commits, pushes or SPCS deployments.

## Reviewable activation order and remaining gates

This is preparation, not execution authorization. Keep both SPCS instances and
experimental retrieval/canonical-history rollout off until acceptance.

1. Preserve exact existing procedure/task/agent definitions and row-level rollback
   records. Obtain scoped approval before pausing or changing the offending queue.
2. Validate and review the helper, queue and invocation procedure changes. Do not
   run broad bootstrap or `fir_tasks.sql`; they contain unrelated object lifecycle
   actions. Do not replace streams or reset offsets. The old standalone learning
   helper definition must not overwrite the reviewed modern helper afterwards.
3. Activate only separately approved definitions and the queue's stream-gate
   correction; preserve cadence and limits. Verify definition hashes and durable
   pending-work eligibility, not just SQL task success.
4. Complete the evidence-backed legacy trust/contradiction/orphan inventory with
   exact old/new rows, guards and rollback proof. Historical repairs remain a
   separate approval. Do not clear all contradictions or promote all null trust.
5. Review exact agent instruction changes while preserving live tools/models/
   budgets, then obtain approval for isolated current-spec evaluation or live
   activation. Current live specs cannot establish local contract acceptance.
6. Finish the reviewed multi-mapping/held-out business gold set, equivalent
   historical replay, current semantic/source applicability, real admitted-history
   continuation and specialist packet tests, then a bounded grouped model probe.
   Only viable grounded results permit the full application/future-learning loop.
7. Build the complete frontend, host, worker, supporting services and Snowflake
   artifact inventory from the dirty FEATURE source. Manifest generation excludes
   private envs, caches, logs and key material, covers FIR/Search/bootstrap/tests,
   and labels the release `not_approved_for_deployment`. Runtime values in that
   manifest come from the client profile, not a claim about running services.

No complete plan milestone is accepted yet: legacy reconciliation, real scheduled
processing, agent parity, business accuracy, actual save/reopen/reuse and UAT
release gates remain open. HTTP success is not persisted learning completion;
Search-ready processing is not verified index visibility.