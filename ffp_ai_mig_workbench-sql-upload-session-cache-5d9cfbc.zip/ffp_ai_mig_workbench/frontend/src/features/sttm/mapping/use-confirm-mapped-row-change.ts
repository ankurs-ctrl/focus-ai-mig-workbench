'use client';

import { useCallback, useRef, useState } from 'react';

import type { MappingState } from '@/features/sttm/types/sttm.types';

export type PendingMappedRowChange = {
  targetColumn: string;
  actionDescription: string;
  onConfirm: () => void;
};

export const MAPPED_ROW_CHANGE_MESSAGES = {
  transformRule:
    'Changing the transform rule will clear all Source Column values for this row (including Direct pick and pre-process). Auto-map confidence is cleared.',
  transformRuleKeepSource:
    'Changing the transform rule will update how this source column is applied. Auto-map confidence is cleared.',
  sourceColumn:
    'Changing the source will replace the current mapping and clear the confidence score.',
  projectAttribute:
    'Changing the firm value will replace the current mapping and clear the confidence score.',
  directPick:
    'Selecting a new source column will replace the current mapping and clear the confidence score.',
  preProcess:
    'Editing pre-process will modify the current mapping and clear the confidence score.',
  recommendation:
    'Applying this recommendation will replace the current mapping.',
} as const;

export function hasFilledMappingSourceColumn(
  row: Pick<MappingState, 'sourceColumn' | 'sourceColumns'>,
) {
  if (String(row.sourceColumn ?? '').trim()) {
    return true;
  }
  return (row.sourceColumns ?? []).some((column) => Boolean(String(column ?? '').trim()));
}

export function useConfirmMappedRowChange() {
  const [pendingChange, setPendingChange] = useState<PendingMappedRowChange | null>(null);
  const pendingChangeRef = useRef<PendingMappedRowChange | null>(null);
  pendingChangeRef.current = pendingChange;

  /**
   * Confirm only when switching transform rule and the row already has source values.
   * Pre-process / Direct pick / source edits must not use this dialog.
   */
  const confirmIfMappedRowChange = useCallback((
    row: Pick<MappingState, 'targetColumn' | 'sourceColumn' | 'sourceColumns'>,
    actionDescription: string,
    onConfirm: () => void,
    options?: {
      onlyWhenSourceFilled?: boolean;
    },
  ) => {
    if (options?.onlyWhenSourceFilled && !hasFilledMappingSourceColumn(row)) {
      onConfirm();
      return;
    }
    if (!options?.onlyWhenSourceFilled) {
      onConfirm();
      return;
    }

    setPendingChange({
      targetColumn: row.targetColumn,
      actionDescription,
      onConfirm,
    });
  }, []);

  const closeConfirm = useCallback(() => {
    setPendingChange(null);
  }, []);

  const confirmChange = useCallback(() => {
    const pending = pendingChangeRef.current;
    setPendingChange(null);
    pending?.onConfirm();
  }, []);

  return {
    pendingChange,
    confirmIfMappedRowChange,
    closeConfirm,
    confirmChange,
  };
}
