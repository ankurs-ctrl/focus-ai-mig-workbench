from __future__ import annotations

import hashlib
import zlib
import json
import logging
import math
import re
import uuid
import time
from datetime import datetime, timezone
from functools import wraps
from threading import Lock, RLock
from typing import Any, Callable

from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.join_connector import join_connector
from app.core.conversation_memory import ConversationMemoryService
from app.core.exceptions import AppValidationError, ConflictError, SnowflakeQueryError
from app.core.agent_learning_service import AgentLearningService
from app.core.async_jobs import AsyncJobService
from app.core.mapping_knowledge_projector import MappingKnowledgeProjector
from app.core.performance import increment, observe
from app.core.relationship_learning import RelationshipLearningService
from app.core.target_mapping_patterns import TargetMappingPatternService
from app.core.mapping_contracts import column_identity, optional_identifier, semantic_column_profiles, published_expression
from app.schema.common import TableRef
from app.schema.project import (
    MappingPrecedentLinkInput,
    MappingPrecedentLinkRecord,
    MappingPrecedentLinksUpdate,
    ProjectCreateRequest,
    ProjectCreateFromTemplateRequest,
    ProjectBootstrapResponse,
    ProjectTemplateRecord,
    ProjectTemplateTarget,
    ProjectAttributeBatchUpsertRequest,
    ProjectAttributeBatchUpsertResponse,
    ProjectAttributeCreateRequest,
    ProjectAttributeImportRequest,
    ProjectAttributeRecord,
    ProjectAttributeUpdateRequest,
    ProjectPrecedentLinkInput,
    ProjectPrecedentLinkRecord,
    ProjectPrecedentLinksUpdate,
    ProjectRecord,
    STTMAutosaveRequest,
    STTMAutosaveResponse,
    STTMCreateRequest,
    STTMDetailResponse,
    STTMPublishRequest,
    STTMPublishResponse,
    STTMRecord,
)
from app.schema.workspace_context import WorkbenchContextSnapshotV1

logger = logging.getLogger(__name__)

_autosave_locks_guard = Lock()
_autosave_locks: dict[str, RLock] = {}
_attribute_upsert_locks_guard = Lock()
_attribute_upsert_locks: dict[str, RLock] = {}
# Project business context changes rarely; caching keeps publish/save fast.
_PROJECT_CONTEXT_TTL_SECONDS = 300.0
_project_context_cache: dict[str, tuple[float, dict[str, Any]]] = {}
_project_context_lock = Lock()


def _serialize_autosave(function):
    @wraps(function)
    def wrapped(self, sttm_id, *args, **kwargs):
        started = time.perf_counter()
        if not self._settings.autosave_singleflight_v1:
            try:
                return function(self, sttm_id, *args, **kwargs)
            finally:
                observe("autosave.duration_ms", (time.perf_counter() - started) * 1000)
        with _autosave_locks_guard:
            lock = _autosave_locks.setdefault(str(sttm_id), RLock())
        with lock:
            increment("autosave.singleflight.executed")
            try:
                return function(self, sttm_id, *args, **kwargs)
            finally:
                observe("autosave.duration_ms", (time.perf_counter() - started) * 1000)
    return wrapped


class ProjectService:
    """Project/STTM persistence facade.

    This service intentionally stores both:
    - normalized rows for project/STTM/source/mapping queries; and
    - full workspace snapshots for lossless resume/autosave.
    """

    _ensured_storage_keys: set[str] = set()
    _table_column_cache: dict[str, set[str]] = {}
    _table_column_type_cache: dict[str, dict[str, str]] = {}

    _LINK_STORAGE_MESSAGE = (
        "Precedent linking is not deployed in this environment. Run the versioned "
        "FIR linking migration and ensure the application role can access the link tables."
    )
    _MEANINGFUL_AUTOSAVE_FIR_EVENTS = {
        "import.completed",
        "historical_import",
        "mapping.edited",
        "join.accepted",
        "derived_source.accepted",
        "derived_source.saved",
        "sql.applied",
        "sql.validation_passed",
        "sql.validation_failed",
    }

    def __init__(
        self,
        *,
        session: Session,
        settings: Settings,
        memory_service: ConversationMemoryService,
    ) -> None:
        self._session = session
        self._settings = settings
        self._memory = memory_service
        self._agent_learning = AgentLearningService(session, settings)
        self._knowledge_projector = MappingKnowledgeProjector(self._agent_learning)
        self._async_jobs = AsyncJobService(session, settings)

    @staticmethod
    def _quote_identifier(identifier: str) -> str:
        return '"' + identifier.replace('"', '""') + '"'

    @staticmethod
    def _quote_literal(value: Any) -> str:
        return "'" + str(value).replace("'", "''") + "'"

    @staticmethod
    def _normalize_json_value(value: Any) -> Any:
        if isinstance(value, float):
            if math.isnan(value) or math.isinf(value):
                return None
            return value
        if isinstance(value, str):
            return "".join(ch for ch in value if ch >= " " or ch in "\t\n\r")
        if isinstance(value, dict):
            return {str(k): ProjectService._normalize_json_value(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [ProjectService._normalize_json_value(v) for v in value]
        if isinstance(value, datetime):
            return value.isoformat()
        if hasattr(value, "model_dump"):
            return ProjectService._normalize_json_value(value.model_dump(mode="json"))
        return value

    @staticmethod
    def _json_literal(value: Any) -> str:
        normalized = ProjectService._normalize_json_value(value)
        payload = json.dumps(normalized, default=str, allow_nan=False).replace("$$", "$ $")
        return f"$${payload}$$"

    @staticmethod
    def _coerce_json(value: Any, default: Any) -> Any:
        if value is None:
            return default
        if isinstance(value, (dict, list)):
            return value
        if isinstance(value, str):
            if not value:
                return default
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return default
        try:
            return json.loads(str(value))
        except Exception:
            return default

    @staticmethod
    def _snapshot_to_dict(snapshot: WorkbenchContextSnapshotV1 | dict[str, Any] | None) -> dict[str, Any]:
        if snapshot is None:
            return {}
        if isinstance(snapshot, WorkbenchContextSnapshotV1):
            return snapshot.model_dump(mode="json")
        return ProjectService._normalize_json_value(snapshot) if isinstance(snapshot, dict) else {}

    @staticmethod
    def _snapshot_hash(payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @staticmethod
    def _normalized_workspace_hash(payload: dict[str, Any]) -> str:
        normalized = dict(payload)
        for key in (
            "context_hash",
            "snapshot_id",
            "captured_at",
            "created_at",
            "updated_at",
            "last_saved_at",
            "action",
            "milestone",
            "checkpoint",
            "page",
            "surface",
        ):
            normalized.pop(key, None)
        return ProjectService._snapshot_hash(normalized)

    @staticmethod
    def _semantic_workspace_hash(payload: dict[str, Any] | None) -> str:
        """Hash only what defines the mapping, not how or where it was viewed.

        Session, thread, conversation, page, lifecycle labels, descriptions,
        compiled/preview SQL, semantic bundle metadata, and UI selections are
        excluded so reopening a mapping is never mistaken for an edit. Fields are
        read from shapes that both legacy and current snapshots retain (derived
        SQL and joins come from relation_graph).
        """
        if not payload:
            return ""

        def text(value: Any) -> str:
            return " ".join(str(value or "").split())

        def sql_identity(value: Any) -> list[str] | str:
            from sqlglot.dialects import Dialect
            sql = str(value or "")
            try:
                return [sql[token.start:token.end + 1] for token in Dialect.get_or_raise("snowflake").tokenize(sql)]
            except Exception:
                return sql

        def fqn(value: Any) -> str:
            if isinstance(value, str):
                return value.replace('"', "").upper()
            if not isinstance(value, (dict, TableRef)):
                return ""
            return ProjectService._table_ref_to_fqn(value).replace('"', "").upper()

        def edge_condition_identity(conditions: Any) -> list[list[str]]:
            rows = [item for item in conditions or [] if isinstance(item, dict)]
            rendered = []
            has_or = False
            for index, condition in enumerate(rows):
                triple = [
                    text(condition.get("left_column")).upper(),
                    text(condition.get("operator") or "="),
                    text(condition.get("right_column")).upper(),
                ]
                if join_connector(condition.get("connector"), applies=index > 0) == "OR":
                    has_or = True
                    triple.append("OR")
                rendered.append(triple)
            return rendered if has_or else sorted(rendered)

        graph = payload.get("relation_graph") if isinstance(payload.get("relation_graph"), dict) else {}
        nodes = [node for node in graph.get("nodes") or [] if isinstance(node, dict)]
        edges = [edge for edge in graph.get("edges") or [] if isinstance(edge, dict)]
        filters = payload.get("filters") if isinstance(payload.get("filters"), dict) else {}
        driving = text(payload.get("driving_relation_id")) or fqn(payload.get("driving_table"))
        if not driving.startswith("sql-cte:"):
            driving = driving.upper()
        semantic = {
            "sources": sorted(
                fqn(table) for table in payload.get("source_tables") or [] if fqn(table)
            ),
            "unresolved": sorted(
                text(value).upper() for value in payload.get("unresolved_source_tables") or []
            ),
            "target": fqn(payload.get("target_table")),
            "driving": driving,
            "derived": sorted(
                [text(node.get("relation_id")), sql_identity(node.get("sql_text") or node.get("physical_view_name"))]
                for node in nodes
                if str(node.get("kind") or "") == "DERIVED_SOURCE"
            ),
            "edges": sorted(
                json.dumps(
                    [
                        text(edge.get("left_relation_id")),
                        text(edge.get("right_relation_id")),
                        text(edge.get("join_type") or "INNER").upper(),
                        sql_identity(edge.get("additional_predicate") or edge.get("sql_predicate")),
                        edge_condition_identity(edge.get("conditions")),
                    ],
                    sort_keys=True,
                )
                for edge in edges
            ),
            "mappings": sorted(
                json.dumps(
                    {
                        "target_column": text(row.get("target_column")).upper(),
                        "source_columns": [text(value) for value in row.get("source_columns") or []],
                        "source_dependencies": row.get("source_dependencies") or [],
                        "value_binding_ids": row.get("value_binding_ids") or [],
                        "mapping_mode": text(row.get("mapping_mode") or "source"),
                        "constant_value": row.get("constant_value"),
                        "attribute_name": text(row.get("attribute_name")),
                        "expression": sql_identity(row.get("expression")),
                        "rule": sql_identity(row.get("rule")),
                        "natural_language_rule": row.get("natural_language_rule"),
                    },
                    sort_keys=True,
                )
                for row in payload.get("mapping_rows") or []
                if isinstance(row, dict)
            ),
            "filters": [
                sql_identity(filters.get("filter_sql")),
                sql_identity(filters.get("group_by_sql")),
                sql_identity(filters.get("order_by_sql")),
            ],
            "query_modifiers": graph.get("query_modifiers") or filters.get("query_modifiers") or {},
            "authored_sql": sql_identity(payload.get("raw_mapping_sql") or payload.get("mapping_sql")),
        }
        return ProjectService._snapshot_hash(semantic)

    @staticmethod
    def _table_ref_to_fqn(table: TableRef | dict[str, Any] | None) -> str:
        if table is None:
            return ""
        if isinstance(table, TableRef):
            return table.qualified_name
        database = str(table.get("database") or "")
        schema = str(table.get("schema") or "")
        name = str(table.get("table") or "")
        return ".".join(part for part in (database, schema, name) if part)

    @staticmethod
    def _snapshot_tables(snapshot: dict[str, Any], key: str) -> list[dict[str, Any]]:
        values = snapshot.get(key) if isinstance(snapshot.get(key), list) else []
        return [item for item in values if isinstance(item, dict)]

    def _qualified_name(self, name: str) -> str:
        qualified_name = self._settings.qualify_metadata_object_name(name)
        parts = [part.strip() for part in qualified_name.split(".")]
        if len(parts) != 3 or not all(parts):
            raise SnowflakeQueryError(
                f"Expected fully qualified DATABASE.SCHEMA.OBJECT name, got '{qualified_name}'."
            )
        return ".".join(self._quote_identifier(part) for part in parts)

    def _table_columns(self, table_name: str) -> set[str]:
        """Return existing Snowflake columns for a metadata table.

        Client environments may already have older metadata tables. Request-time DDL is
        intentionally skipped in restricted OAuth/SPCS mode, so persistence must adapt to
        the columns that actually exist instead of assuming the latest local DDL.
        """

        cached = self._table_column_cache.get(table_name)
        if cached is not None:
            return cached
        try:
            rows = self._session.sql(f"DESCRIBE TABLE {table_name}").collect()
            columns: set[str] = set()
            column_types: dict[str, str] = {}
            for row in rows:
                data = row.as_dict()
                name = data.get("name") or data.get("NAME") or data.get("Name")
                if name:
                    normalized_name = str(name).upper()
                    columns.add(normalized_name)
                    column_types[normalized_name] = str(
                        data.get("type") or data.get("TYPE") or data.get("Type") or ""
                    ).upper()
            self._table_column_cache[table_name] = columns
            self._table_column_type_cache[table_name] = column_types
            return columns
        except Exception as exc:
            logger.warning("Unable to inspect metadata table columns for %s: %s", table_name, exc)
            self._table_column_cache[table_name] = set()
            self._table_column_type_cache[table_name] = {}
            return set()

    def _column_type(self, table_name: str, column: str) -> str:
        self._table_columns(table_name)
        return self._table_column_type_cache.get(table_name, {}).get(column.upper(), "")

    def _quote_text_for_column(self, table_name: str, column: str, value: Any) -> str:
        """Fit legacy display text without truncating authoritative JSON state."""
        text = str(value or "")
        column_type = self._column_type(table_name, column)
        size_match = re.search(r"(?:VAR)?CHAR\s*\(\s*(\d+)\s*\)", column_type)
        if size_match:
            text = text[: int(size_match.group(1))]
        return self._quote_literal(text)

    def _actor_column_values(self, table_name: str, user_id: str | None) -> dict[str, str]:
        """Persist string identities without breaking older numeric metadata schemas."""
        actor = str(user_id or "")
        actor_type = self._column_type(table_name, "LAST_MODIFIED_BY")
        is_numeric_column = actor_type.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT"))
        is_numeric_actor = actor.lstrip("+-").isdigit()
        values = {
            "LAST_MODIFIED_BY": (
                self._quote_literal(actor) if not is_numeric_column or is_numeric_actor else "NULL"
            ),
            "ACTOR_USER_ID": self._quote_literal(actor),
        }
        return self._existing_column_exprs(table_name, values)

    def _existing_column_exprs(self, table_name: str, values: dict[str, str]) -> dict[str, str]:
        columns = self._table_columns(table_name)
        if not columns:
            return values
        return {column: expression for column, expression in values.items() if column.upper() in columns}

    def _has_column(self, table_name: str, column: str) -> bool:
        columns = self._table_columns(table_name)
        return not columns or column.upper() in columns

    def _order_by_expr(self, table_name: str, candidates: list[str], fallback: str) -> str:
        columns = self._table_columns(table_name)
        for column in candidates:
            if not columns or column.upper() in columns:
                return column
        return fallback

    @staticmethod
    def _is_missing_link_storage_error(exc: Exception) -> bool:
        message = str(exc).lower()
        names_link_table = (
            "tbl_fir_project_links" in message or "tbl_fir_mapping_links" in message
        )
        missing_or_forbidden = any(
            marker in message
            for marker in (
                "does not exist or not authorized",
                "does not exist",
                "object does not exist",
                "not authorized",
                "insufficient privileges",
            )
        )
        return names_link_table and missing_or_forbidden

    def _require_link_storage(self, table_name: str, *, field: str) -> None:
        try:
            self._session.sql(f"DESCRIBE TABLE {table_name}").collect()
        except Exception as exc:
            if self._is_missing_link_storage_error(exc):
                raise AppValidationError(
                    self._LINK_STORAGE_MESSAGE,
                    details=[{"field": field, "message": self._LINK_STORAGE_MESSAGE}],
                ) from exc
            raise SnowflakeQueryError(
                f"Unable to verify precedent-link storage {table_name}: {exc}"
            ) from exc

    def _insert_existing_columns(self, table_name: str, values: dict[str, str]) -> None:
        filtered = self._existing_column_exprs(table_name, values)
        if not filtered:
            raise SnowflakeQueryError(f"No writable columns found for metadata table {table_name}.")
        column_sql = ", ".join(filtered.keys())
        value_sql = ",\n                ".join(filtered.values())
        try:
            self._session.sql(
                f"""
                INSERT INTO {table_name} (
                    {column_sql}
                )
                SELECT
                    {value_sql}
                """
            ).collect()
        except Exception as exc:
            raise SnowflakeQueryError(f"Failed to insert metadata into {table_name}: {exc}") from exc

    def _insert_existing_columns_bound(
        self,
        table_name: str,
        values: dict[str, str | tuple[str, list[Any]]],
    ) -> None:
        """Insert into a version-compatible table with bound large values."""
        columns = self._table_columns(table_name)
        filtered = {
            column: expression
            for column, expression in values.items()
            if not columns or column.upper() in columns
        }
        if not filtered:
            raise SnowflakeQueryError(f"No writable columns found for metadata table {table_name}.")
        expressions: list[str] = []
        params: list[Any] = []
        for value in filtered.values():
            if isinstance(value, tuple):
                expressions.append(value[0])
                params.extend(value[1])
            else:
                expressions.append(value)
        try:
            self._session.sql(
                f"INSERT INTO {table_name} ({', '.join(filtered)}) "
                f"SELECT {', '.join(expressions)}",
                params=params or None,
            ).collect()
        except Exception as exc:
            raise SnowflakeQueryError(f"Failed to insert metadata into {table_name}: {exc}") from exc

    def _update_existing_columns_bound(
        self,
        table_name: str,
        assignments: dict[str, str | tuple[str, list[Any]]],
        where_sql: str,
        *,
        where_params: list[Any] | None = None,
    ) -> None:
        columns = self._table_columns(table_name)
        filtered = {
            column: expression
            for column, expression in assignments.items()
            if not columns or column.upper() in columns
        }
        if not filtered:
            return
        clauses: list[str] = []
        params: list[Any] = []
        for column, value in filtered.items():
            if isinstance(value, tuple):
                clauses.append(f"{column} = {value[0]}")
                params.extend(value[1])
            else:
                clauses.append(f"{column} = {value}")
        params.extend(where_params or [])
        try:
            self._session.sql(
                f"UPDATE {table_name} SET {', '.join(clauses)} WHERE {where_sql}",
                params=params or None,
            ).collect()
        except Exception as exc:
            raise SnowflakeQueryError(f"Failed to update metadata in {table_name}: {exc}") from exc

    def _update_existing_columns(self, table_name: str, assignments: dict[str, str], where_sql: str) -> None:
        filtered = self._existing_column_exprs(table_name, assignments)
        if not filtered:
            return
        set_sql = ",\n                ".join(
            f"{column} = {expression}" for column, expression in filtered.items()
        )
        try:
            self._session.sql(
                f"""
                UPDATE {table_name}
                SET {set_sql}
                WHERE {where_sql}
                """
            ).collect()
        except Exception as exc:
            raise SnowflakeQueryError(f"Failed to update metadata in {table_name}: {exc}") from exc

    def _update_sttm_draft_payload(
        self,
        *,
        sttm_id: str,
        snapshot: dict[str, Any],
        snapshot_id: str,
        semantic_bundle_id: str | None,
        semantic_bundle_hash: str | None,
        user_id: str | None,
        preserve_status: bool = False,
    ) -> None:
        """Persist large draft values as binds while retaining legacy columns.

        ``preserve_status`` records a newer snapshot of unchanged mapping
        content without marking the mapping as having an unpublished draft.
        """
        snapshot_json = json.dumps(
            self._normalize_json_value(snapshot), default=str, allow_nan=False
        )
        parsed_json = json.dumps(
            self._normalize_json_value(snapshot.get("parsed_mapping_model") or {}),
            default=str,
            allow_nan=False,
        )
        assignments: list[str] = []
        params: list[Any] = []

        def bind(column: str, expression: str, value: Any) -> None:
            if self._has_column(self._sttm_table, column):
                assignments.append(f"{column} = {expression}")
                params.append(value)

        if not preserve_status and self._has_column(self._sttm_table, "HAS_UNPUBLISHED_DRAFT"):
            assignments.append("HAS_UNPUBLISHED_DRAFT = TRUE")
        if not preserve_status and self._has_column(self._sttm_table, "STATUS"):
            assignments.append(
                "STATUS = IFF(STATUS = 'IMPORTING', 'IMPORTING', "
                "IFF(STATUS = 'DRAFT', 'DRAFT', 'IN_PROGRESS'))"
            )
        for column, expression in self._actor_column_values(
            self._sttm_table, user_id
        ).items():
            assignments.append(f"{column} = {expression}")
        if self._has_column(self._sttm_table, "LAST_MODIFIED_DATETIME"):
            assignments.append("LAST_MODIFIED_DATETIME = CURRENT_TIMESTAMP()")
        bind("DRAFT_PAYLOAD", "PARSE_JSON(?)", snapshot_json)
        # The dashboard reads TARGET_TABLE from the STTM row. Keep it in step
        # with the selected target in the saved workspace snapshot.
        target_fqn = self._table_ref_to_fqn(snapshot.get("target_table"))
        if "target_table" in snapshot:
            bind("TARGET_TABLE", "?", target_fqn)
        bind(
            "RAW_MAPPING_SQL",
            "?",
            str(snapshot.get("raw_mapping_sql") or snapshot.get("mapping_sql") or ""),
        )
        bind("PARSED_MAPPING_MODEL", "PARSE_JSON(?)", parsed_json)
        bind("SEMANTIC_BUNDLE_ID", "?", semantic_bundle_id or "")
        bind("SEMANTIC_BUNDLE_HASH", "?", semantic_bundle_hash or "")
        bind("LAST_SNAPSHOT_ID", "?", snapshot_id)
        params.append(sttm_id)
        try:
            self._session.sql(
                f"UPDATE {self._sttm_table} SET {', '.join(assignments)} "
                "WHERE TO_VARCHAR(STTM_ID) = ?",
                params=params,
            ).collect()
            increment("autosave.sttm_payload.statement")
            observe("autosave.sttm_payload.bytes", len(snapshot_json.encode("utf-8")))
        except Exception as exc:
            raise SnowflakeQueryError(
                f"Failed to update bound draft metadata in {self._sttm_table}: {exc}"
            ) from exc

    @property
    def _projects_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_projects_table)

    def _project_business_context(self, project_id: str) -> dict[str, Any]:
        """Domain, outcome, process and source CRM captured on New Project."""
        now = time.monotonic()
        with _project_context_lock:
            cached = _project_context_cache.get(project_id)
            if cached and now - cached[0] <= _PROJECT_CONTEXT_TTL_SECONDS:
                return cached[1]
        context: dict[str, Any] = {}
        try:
            rows = self._session.sql(
                f"SELECT PROJECT_METADATA FROM {self._projects_table} WHERE TO_VARCHAR(PROJECT_ID) = ?",
                params=[str(project_id)],
            ).collect()
            metadata = self._coerce_json(rows[0]["PROJECT_METADATA"], {}) if rows else {}
            context = {
                key: str(metadata.get(key)).strip()
                for key in ("domain", "intended_outcome", "business_process", "source_system_key", "logical_target_table_key")
                if str(metadata.get(key) or "").strip()
            }
        except Exception as exc:
            logger.debug("Project business context unavailable for %s: %s", project_id, exc)
            return {}
        with _project_context_lock:
            _project_context_cache[project_id] = (now, context)
        return context

    @property
    def _project_attributes_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_project_attributes_table)

    @property
    def _sttm_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_sttm_table)

    @property
    def _versions_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_sttm_versions_table)

    @property
    def _sources_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_sttm_sources_table)

    @property
    def _attributes_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_sttm_attributes_table)

    @property
    def _snapshots_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_workspace_snapshots_table)

    @property
    def _artifacts_table(self) -> str:
        return self._qualified_name(self._settings.snowflake_agent_artifacts_table)

    @property
    def _project_links_table(self) -> str:
        return self._qualified_name("TBL_FIR_PROJECT_LINKS")

    @property
    def _mapping_links_table(self) -> str:
        return self._qualified_name("TBL_FIR_MAPPING_LINKS")

    def ensure_storage_exists(self) -> None:
        storage_key = "|".join(
            [
                self._projects_table,
                self._project_attributes_table,
                self._sttm_table,
                self._versions_table,
                self._sources_table,
                self._attributes_table,
            ]
        )
        if storage_key in self._ensured_storage_keys:
            return
        if self._settings.uses_custom_oauth and self._settings.spcs_execute_as_caller_enabled:
            logger.info(
                "Skipping ProjectService DDL bootstrap at request time for restricted custom OAuth runtime."
            )
            self._ensured_storage_keys.add(storage_key)
            return
        statements = [
            f"""
            CREATE TABLE IF NOT EXISTS {self._projects_table} (
                PROJECT_ID NUMBER AUTOINCREMENT NOT NULL PRIMARY KEY,
                PROJECT_NAME VARCHAR(255) NOT NULL,
                DESCRIPTION TEXT,
                STATUS VARCHAR(50) DEFAULT 'ACTIVE',
                RUNTIME_SUPPRESSED BOOLEAN DEFAULT FALSE,
                ARCHIVED_AT TIMESTAMP_NTZ,
                CREATED_BY VARCHAR(128),
                PROJECT_METADATA VARIANT,
                CREATED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                LAST_MODIFIED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
            )
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self._project_attributes_table} (
                ATTRIBUTE_ID STRING NOT NULL,
                PROJECT_ID STRING NOT NULL,
                ATTRIBUTE_NAME VARCHAR(255) NOT NULL,
                ATTRIBUTE_TYPE VARCHAR(50) NOT NULL,
                ATTRIBUTE_VALUE TEXT,
                SOURCE_PROJECT_ID STRING,
                SOURCE_ATTRIBUTE_ID STRING,
                STATUS VARCHAR(20) DEFAULT 'ACTIVE',
                CREATED_BY VARCHAR(128),
                UPDATED_BY VARCHAR(128),
                CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                UPDATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                CONSTRAINT PK_PROJECT_ATTRIBUTES PRIMARY KEY (ATTRIBUTE_ID)
            )
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self._sttm_table} (
                STTM_ID NUMBER AUTOINCREMENT NOT NULL PRIMARY KEY,
                PROJECT_ID NUMBER NOT NULL,
                STTM_NAME VARCHAR(255),
                DESCRIPTION TEXT,
                TARGET_TABLE STRING,
                CURRENT_VERSION INT DEFAULT 0,
                HAS_UNPUBLISHED_DRAFT BOOLEAN DEFAULT FALSE,
                STATUS VARCHAR(50) DEFAULT 'DRAFT',
                IMPORT_KEY STRING,
                IMPORT_STATE STRING,
                RUNTIME_SUPPRESSED BOOLEAN DEFAULT FALSE,
                SUPERSEDED_BY STRING,
                RAW_MAPPING_SQL TEXT,
                PARSED_MAPPING_MODEL VARIANT,
                DRAFT_PAYLOAD VARIANT,
                SEMANTIC_BUNDLE_ID STRING,
                SEMANTIC_BUNDLE_HASH STRING,
                LAST_SNAPSHOT_ID STRING,
                STTM_METADATA VARIANT,
                LAST_MODIFIED_BY VARCHAR(128),
                CREATED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                LAST_MODIFIED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
            )
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self._versions_table} (
                VERSION_ID NUMBER AUTOINCREMENT NOT NULL PRIMARY KEY,
                STTM_ID NUMBER NOT NULL,
                VERSION_NUMBER INT NOT NULL,
                REVISION_NOTE TEXT,
                SNAPSHOT_ID STRING,
                VERSION_PAYLOAD VARIANT,
                RAW_MAPPING_SQL TEXT,
                PARSED_MAPPING_MODEL VARIANT,
                SEMANTIC_BUNDLE_ID STRING,
                SEMANTIC_BUNDLE_HASH STRING,
                MAPPING_VERSION STRING,
                AGENT_ARTIFACT_IDS VARIANT,
                PUBLISHED_BY VARCHAR(128),
                PUBLISHED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
            )
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self._sources_table} (
                SOURCE_ID NUMBER AUTOINCREMENT NOT NULL PRIMARY KEY,
                STTM_ID NUMBER NOT NULL,
                SOURCE_NAME VARCHAR(255) NOT NULL,
                DATABASE_NAME VARCHAR(255),
                SCHEMA_NAME VARCHAR(255),
                TABLE_NAME VARCHAR(255),
                DESCRIPTION TEXT,
                IS_DRAFT BOOLEAN DEFAULT FALSE,
                EFFECTIVE_FROM_VERSION INT,
                EFFECTIVE_THROUGH_VERSION INT,
                LAST_MODIFIED_BY VARCHAR(128),
                CREATED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                LAST_MODIFIED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
            )
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self._attributes_table} (
                ATTRIBUTE_ID NUMBER AUTOINCREMENT NOT NULL PRIMARY KEY,
                STTM_ID NUMBER NOT NULL,
                SOURCE_ID NUMBER,
                ATTRIBUTE_NAME VARCHAR(255) NOT NULL,
                ATTRIBUTE_TYPE VARCHAR(50) NOT NULL,
                SOURCE_COLUMN VARCHAR(255),
                DATA_TYPE VARCHAR(100),
                TRANSFORMATION_LOGIC TEXT,
                DESCRIPTION TEXT,
                CONDITION VARIANT,
                CALCULATION VARIANT,
                MEASURE VARIANT,
                AGGREGATION VARIANT,
                IS_NULLABLE BOOLEAN DEFAULT TRUE,
                IS_PK BOOLEAN DEFAULT FALSE,
                IS_FK BOOLEAN DEFAULT FALSE,
                IS_DRAFT BOOLEAN DEFAULT FALSE,
                EFFECTIVE_FROM_VERSION INT,
                EFFECTIVE_THROUGH_VERSION INT,
                LAST_MODIFIED_BY VARCHAR(128),
                CREATED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
                LAST_MODIFIED_DATETIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
            )
            """,
        ]
        try:
            for statement in statements:
                self._session.sql(statement).collect()
            self._ensured_storage_keys.add(storage_key)
        except Exception as exc:
            logger.warning(
                "DDL bootstrap failed; storage will be retried on next request: %s", exc
            )

    def create_project(
        self,
        payload: ProjectCreateRequest,
        *,
        user_id: str | None,
        display_name: str | None = None,
        emit_fir: bool = True,
    ) -> ProjectRecord:
        if payload.precedent_links:
            # Validate before inserting so a missing migration cannot leave an
            # orphan project behind after a partial request.
            self._require_link_storage(
                self._project_links_table,
                field="precedent_links",
            )

        # Older client schemas keep CREATED_BY as NUMBER. Persist the stable user
        # id there and keep the human-readable name in metadata across schemas.
        created_by_value = user_id or ""
        project_metadata = dict(payload.metadata)
        migration_run_id = str(project_metadata.get("created_by_migration_run") or "").strip()
        agent_external_key = str(project_metadata.get("agent_external_key") or "").strip()
        if migration_run_id and not agent_external_key:
            agent_external_key = f"agent-run:{migration_run_id}:project"
            project_metadata["agent_external_key"] = agent_external_key
        if display_name:
            project_metadata["created_by_name"] = display_name
        self.ensure_storage_exists()
        self._insert_existing_columns(
            self._projects_table,
            {
                "PROJECT_NAME": self._quote_literal(payload.project_name.strip()),
                "DESCRIPTION": self._quote_literal(payload.description or ""),
                "STATUS": self._quote_literal(payload.status),
                "CREATED_BY": self._quote_literal(created_by_value),
                "CREATED_BY_NAME": self._quote_literal(display_name or ""),
                "PROJECT_METADATA": f"PARSE_JSON({self._json_literal(project_metadata)})",
                "AGENT_EXTERNAL_KEY": self._quote_literal(agent_external_key),
            },
        )
        bootstrap_key = str(payload.metadata.get('bootstrap_idempotency_key') or '')
        bootstrap_predicate = (f"AND PROJECT_METADATA:bootstrap_idempotency_key::STRING = {self._quote_literal(bootstrap_key)}"
                               if bootstrap_key else '')
        if agent_external_key and self._has_column(self._projects_table, "AGENT_EXTERNAL_KEY"):
            bootstrap_predicate += f" AND AGENT_EXTERNAL_KEY = {self._quote_literal(agent_external_key)}"
        project = self._session.sql(
            f"""
            SELECT *
            FROM {self._projects_table}
            WHERE PROJECT_NAME = {self._quote_literal(payload.project_name.strip())}
              AND COALESCE(TO_VARCHAR(CREATED_BY), '') = {self._quote_literal(created_by_value)}
              {bootstrap_predicate}
            ORDER BY {self._order_by_expr(self._projects_table, ["CREATED_DATETIME", "PROJECT_ID"], "PROJECT_ID")} DESC
            LIMIT 1
            """
        ).collect()[0]
        record = self._project_from_row(project.as_dict(), counts={})
        if payload.precedent_links:
            links = self.replace_project_links(
                record.project_id,
                ProjectPrecedentLinksUpdate(links=payload.precedent_links),
                user_id=user_id,
            )
            record = record.model_copy(
                update={"linked_project_ids": [item.precedent_project_id for item in links]}
            )
        if emit_fir:
            self._record_fir(
                event_type="project.created",
                user_id=user_id,
                session_id=None,
                request_id=None,
                page="projects",
                surface="dashboard",
                entity_type="project",
                entity_ids=[record.project_id],
                payload=record.model_dump(mode="json"),
            )
        return record

    def get_project_templates(
        self,
        *,
        target_database: str | None = None,
        target_schema: str | None = None,
    ) -> list[ProjectTemplateRecord]:
        database = str(
            target_database
            or self._settings.crm_target_database
            or self._settings.snowflake_database
        ).strip()
        schema = str(
            target_schema
            or self._settings.crm_target_schema
            or self._settings.snowflake_schema
        ).strip()
        approved, approved_columns = self._crm_target_contract()
        physical: dict[str, int] = {}
        if database and schema:
            try:
                rows = self._session.sql(
                    "SHOW TABLES IN SCHEMA "
                    f"{self._quote_identifier(database)}.{self._quote_identifier(schema)}"
                ).collect()
                for row in rows:
                    data = row.as_dict()
                    name = data.get("name") or data.get("NAME")
                    if name:
                        physical[str(name).upper()] = int(
                            data.get("rows") or data.get("ROWS") or 0
                        )
            except Exception as exc:
                logger.warning("CRM target schema discovery failed: %s", exc)
        available = [name for name in approved if name in physical]
        missing = [name for name in approved if name not in physical]
        columns_by_table = self._discover_target_contract_columns(
            database=database,
            schema=schema,
            table_names=available,
        )

        def target(name: str, present: bool) -> ProjectTemplateTarget:
            physical_columns = columns_by_table.get(name, [])
            contract_columns = approved_columns.get(name, [])
            physical_by_name = {
                str(column.get("name") or "").upper(): column
                for column in physical_columns
                if column.get("name")
            }
            if contract_columns:
                columns = []
                missing_columns = []
                for contract_column in contract_columns:
                    column_name = str(contract_column.get("name") or "").upper()
                    physical_column = physical_by_name.get(column_name)
                    if physical_column is None:
                        missing_columns.append(column_name)
                        continue
                    columns.append({**physical_column, **contract_column, "name": column_name})
            else:
                columns = physical_columns
                missing_columns = []
            return ProjectTemplateTarget(
                logical_target_key=f"CRM.{name}",
                table_name=name,
                physical_fqn=".".join(part for part in (database, schema, name) if part),
                available=present,
                column_count=len(columns),
                columns=columns,
                missing_columns=missing_columns,
            )

        discovered_targets = [target(name, True) for name in available]
        ready_targets = [item for item in discovered_targets if not item.missing_columns]
        unavailable_targets = [
            item.model_copy(update={"available": False})
            for item in discovered_targets
            if item.missing_columns
        ]
        unavailable_targets.extend(target(name, False) for name in missing)
        return [
            ProjectTemplateRecord(
                template_id="CRM_MIGRATION",
                template_version="1.0",
                label="CRM Migration",
                source_systems=["REDTAIL", "WEALTHBOX", "HUBSPOT", "SALESFORCE", "OTHER"],
                target_contract_id="CRM_COMMON_TARGET",
                target_contract_version=self._settings.crm_target_contract_version,
                target_database=database,
                target_schema=schema,
                available_targets=ready_targets,
                missing_targets=unavailable_targets,
                unexpected_tables=sorted(set(physical) - set(approved)),
            )
        ]

    def _crm_target_contract(self) -> tuple[list[str], dict[str, list[dict[str, Any]]]]:
        approved = [
            value.strip().upper()
            for value in self._settings.crm_target_tables.split(",")
            if value.strip()
        ]
        raw = str(self._settings.crm_target_contract_json or "").strip()
        if not raw:
            return approved, {}
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise AppValidationError(
                "CRM_TARGET_CONTRACT_JSON is not valid JSON."
            ) from exc
        tables = payload.get("tables") if isinstance(payload, dict) else None
        if not isinstance(tables, dict) or not tables:
            raise AppValidationError(
                "CRM_TARGET_CONTRACT_JSON must contain a non-empty tables object."
            )
        columns_by_table: dict[str, list[dict[str, Any]]] = {}
        for table_name, table_contract in tables.items():
            name = str(table_name).strip().upper()
            if not name:
                continue
            raw_columns = (
                table_contract.get("columns", [])
                if isinstance(table_contract, dict)
                else table_contract
            )
            columns: list[dict[str, Any]] = []
            if isinstance(raw_columns, list):
                for item in raw_columns:
                    column = {"name": item} if isinstance(item, str) else item
                    if not isinstance(column, dict) or not column.get("name"):
                        continue
                    columns.append({
                        **column,
                        "name": str(column["name"]).strip().upper(),
                        "logical_target_key": str(
                            column.get("logical_target_key")
                            or f"CRM.{name}.{str(column['name']).strip().upper()}"
                        ),
                    })
            columns_by_table[name] = columns
        return list(columns_by_table), columns_by_table

    def _discover_target_contract_columns(
        self,
        *,
        database: str,
        schema: str,
        table_names: list[str],
    ) -> dict[str, list[dict[str, Any]]]:
        if not database or not schema or not table_names:
            return {}
        table_values = ", ".join(self._quote_literal(name) for name in table_names)
        try:
            rows = self._session.sql(
                f"""
                SELECT c.TABLE_NAME, c.COLUMN_NAME, c.DATA_TYPE, c.IS_NULLABLE,
                       c.ORDINAL_POSITION,
                       FALSE AS IS_PRIMARY_KEY
                FROM {self._quote_identifier(database)}.INFORMATION_SCHEMA.COLUMNS c
                WHERE c.TABLE_SCHEMA = {self._quote_literal(schema)}
                  AND c.TABLE_NAME IN ({table_values})
                ORDER BY c.TABLE_NAME, c.ORDINAL_POSITION
                """
            ).collect()
        except Exception as exc:
            logger.warning("CRM target column discovery failed: %s", exc)
            return {}
        primary_keys: set[tuple[str, str]] = set()
        try:
            for row in self._session.sql(
                f"SHOW PRIMARY KEYS IN SCHEMA {self._quote_identifier(database)}.{self._quote_identifier(schema)}"
            ).collect():
                data = row.as_dict()
                primary_keys.add((str(data.get('table_name') or data.get('TABLE_NAME') or '').upper(),
                                  str(data.get('column_name') or data.get('COLUMN_NAME') or '')))
        except Exception as exc:
            logger.warning('CRM target primary-key discovery unavailable; retaining column metadata: %s', exc)
        result: dict[str, list[dict[str, Any]]] = {}
        for row in rows:
            data = row.as_dict()
            table_name = str(data.get("TABLE_NAME") or data.get("table_name") or "").upper()
            column_name = str(data.get("COLUMN_NAME") or data.get("column_name") or "")
            if not table_name or not column_name:
                continue
            result.setdefault(table_name, []).append(
                {
                    "name": column_name,
                    "type": str(data.get("DATA_TYPE") or data.get("data_type") or ""),
                    "nullable": str(data.get("IS_NULLABLE") or data.get("is_nullable") or "YES").upper() == "YES",
                    "primary_key": (table_name, column_name) in primary_keys,
                    "logical_target_key": f"CRM.{table_name}.{column_name.upper()}",
                }
            )
        return result

    def create_project_from_template(
        self,
        payload: ProjectCreateFromTemplateRequest,
        *,
        user_id: str | None,
        display_name: str | None = None,
    ) -> ProjectBootstrapResponse:
        self.ensure_storage_exists()
        # Resolve table metadata/DDL before taking transaction ownership.
        snapshot_columns = self._table_columns(self._snapshots_table)
        if not {'SNAPSHOT_ID', 'SNAPSHOT_PAYLOAD', 'STTM_ID'} <= snapshot_columns:
            raise AppValidationError('Workspace snapshot storage must be provisioned before creating projects.')
        started = time.perf_counter()
        self._session.sql("BEGIN").collect()
        try:
            try:
                locked = self._session.sql(f"UPDATE {self._qualified_name('TBL_PROJECT_BOOTSTRAP_LOCK')} SET FENCE = FENCE + 1 WHERE LOCK_KEY = 'project-bootstrap'").collect()
            except Exception:
                raise AppValidationError('Project initialization requires the project-bootstrap-lock.sql deployment step and caller SELECT/UPDATE grants.') from None
            changed = locked[0].as_dict() if locked and hasattr(locked[0], 'as_dict') else dict(locked[0]) if locked else {}
            if sum(int(value) for value in changed.values() if isinstance(value, (int, float))) != 1:
                raise AppValidationError('Project bootstrap lock is not initialized. Run the deployment SQL before creating projects.')
            result = self._create_project_from_template(
                payload,
                user_id=user_id,
                display_name=display_name,
            )
            self._session.sql("COMMIT").collect()
            from app.core.read_cache import invalidate_read_cache
            invalidate_read_cache('projects:', 'recommendations:')
            logger.info(
                "project_template_bootstrap completed project_id=%s template=%s "
                "source_system=%s mappings=%s idempotency_key=%s elapsed_ms=%.1f",
                result.project.project_id,
                result.template.template_id,
                payload.source_system_key,
                len(result.mappings),
                payload.idempotency_key,
                (time.perf_counter() - started) * 1000,
            )
            return result
        except Exception:
            try:
                self._session.sql("ROLLBACK").collect()
            except Exception:
                logger.exception("Project-template bootstrap rollback failed")
            raise

    def _initialize_blank_mappings(self, project, payloads, *, user_id, display_name):
        from app.core.project_bootstrap import initialize_blank_mappings
        return initialize_blank_mappings(self, project, payloads, user_id=user_id, display_name=display_name)

    def _create_project_from_template(
        self,
        payload: ProjectCreateFromTemplateRequest,
        *,
        user_id: str | None,
        display_name: str | None = None,
    ) -> ProjectBootstrapResponse:
        templates = self.get_project_templates(
            target_database=payload.target_database,
            target_schema=payload.target_schema,
        )
        template = next(
            (item for item in templates if item.template_id == payload.template_id.upper()),
            None,
        )
        if template is None:
            raise AppValidationError(f"Unknown project template: {payload.template_id}")
        if payload.bootstrap_mode == "AUTO" and not template.available_targets:
            raise AppValidationError(
                "No approved target tables are available in the configured target schema. "
                "Choose Empty project or correct the CRM target binding."
            )
        selected_targets = template.available_targets
        if payload.bootstrap_mode == "AUTO" and payload.selected_target_tables is not None:
            requested = {name.strip().upper() for name in payload.selected_target_tables}
            available = {target.table_name.upper() for target in template.available_targets}
            if not requested or requested - available:
                raise AppValidationError("Select at least one available approved target table; unknown targets cannot be created.")
            selected_targets = [target for target in template.available_targets if target.table_name.upper() in requested]
        source_system = payload.source_system_key.strip().upper()
        if source_system not in template.source_systems:
            raise AppValidationError(
                f"Unsupported source CRM {payload.source_system_key!r}."
            )
        existing_rows = self._session.sql(f"SELECT * FROM {self._projects_table} WHERE PROJECT_METADATA:bootstrap_idempotency_key::STRING = ?",
            params=[payload.idempotency_key]).collect()
        if len(existing_rows) > 1:
            raise AppValidationError('This request has duplicate legacy projects; an administrator must review them. No records were changed.')
        existing_project = self._project_from_row(existing_rows[0].as_dict(), counts={}) if existing_rows else None
        request_contract = payload.model_dump(mode='json', exclude={'idempotency_key'})
        if request_contract.get('selected_target_tables') is not None:
            request_contract['selected_target_tables'] = sorted(request_contract['selected_target_tables'])
        request_hash = self._snapshot_hash(request_contract)
        if existing_project and (existing_project.status in {'ARCHIVED', 'DELETED'}
                or str(existing_project.created_by or '') != str(user_id or '')
                or existing_project.project_name != payload.project_name
                or existing_project.metadata.get('source_system_key') != source_system
                or existing_project.metadata.get('bootstrap_request_hash', request_hash) != request_hash):
            raise AppValidationError('This request was already used with different project details or has been removed. Start a new request.')
        if existing_project and (
            existing_project.metadata.get('target_database') != template.target_database
            or existing_project.metadata.get('target_schema') != template.target_schema
            or (existing_project.metadata.get('selected_target_tables') is not None
                and set(existing_project.metadata['selected_target_tables']) !=
                    ({target.table_name for target in selected_targets} if payload.bootstrap_mode == 'AUTO' else set()))
        ):
            raise AppValidationError('This project creation request was already used with different targets. Start a new project request.')
        metadata = {
            **(existing_project.metadata if existing_project else {}),
            **payload.metadata,
            "project_template_id": template.template_id,
            "project_template_version": template.template_version,
            "source_system_key": source_system,
            "target_contract_id": template.target_contract_id,
            "target_contract_version": template.target_contract_version,
            "target_database": template.target_database,
            "target_schema": template.target_schema,
            "selected_target_tables": [target.table_name for target in selected_targets] if payload.bootstrap_mode == "AUTO" else [],
            "bootstrap_mode": payload.bootstrap_mode,
            "bootstrap_status": "INITIALIZING",
            "bootstrap_idempotency_key": payload.idempotency_key,
            "bootstrap_request_hash": request_hash,
            "agent_external_key": f"project-template:{payload.idempotency_key}",
        }
        project = existing_project or self.create_project(
            ProjectCreateRequest(
                project_name=payload.project_name,
                description=payload.description,
                status=payload.status,
                metadata=metadata,
                precedent_links=payload.precedent_links,
            ),
            user_id=user_id,
            display_name=display_name,
            emit_fir=False,
        )
        mappings = self.list_sttms(project.project_id) if existing_project else []
        existing_target_keys = {
            str(item.metadata.get("logical_target_table_key") or "").upper()
            for item in mappings
        }
        bootstrap_items = []
        if payload.bootstrap_mode == "AUTO":
            for target in selected_targets:
                if target.logical_target_key.upper() in existing_target_keys:
                    continue
                table_ref = TableRef(
                    database=template.target_database,
                    schema=template.target_schema,
                    table=target.table_name,
                )
                bootstrap_items.append(
                        STTMCreateRequest(
                            sttm_name=f"{source_system.title()} → {target.table_name.title()}",
                            description=f"Template mapping for {target.logical_target_key}",
                            target_table=table_ref,
                            workspace_snapshot={
                                "page": "builder",
                                "surface": "SOURCE_SELECTION",
                                "project_id": project.project_id,
                                "project_name": project.project_name,
                                "target_table": table_ref.model_dump(mode="json"),
                                "selected_columns_by_table": {
                                    target.physical_fqn: [
                                        str(column.get("name") or "")
                                        for column in target.columns
                                        if column.get("name")
                                    ]
                                },
                                "mapping_rows": [
                                    {
                                        "id": f"bootstrap:{target.logical_target_key}:{column.get('name')}",
                                        "target_column": str(column.get("name") or ""),
                                        "target_type": str(column.get("type") or "") or None,
                                        "source_columns": [],
                                        "status": "UNMAPPED",
                                        "provenance": "target_contract",
                                    }
                                    for column in target.columns
                                    if column.get("name")
                                ],
                                "mapping_intent": {
                                    "name": f"{source_system.title()} → {target.table_name.title()}",
                                    "logical_target_key": target.logical_target_key,
                                    "source_system_key": source_system,
                                },
                            },
                            metadata={
                                "bootstrap_origin": "project_template",
                                "logical_target_table_key": target.logical_target_key,
                                "physical_target_fqn": target.physical_fqn,
                                "target_contract_id": template.target_contract_id,
                                "target_contract_version": template.target_contract_version,
                                "target_contract_columns": target.columns,
                                "source_system_key": source_system,
                                "bootstrap_idempotency_key": payload.idempotency_key,
                                "agent_external_key": (
                                    f"project-template:{payload.idempotency_key}:"
                                    f"{target.logical_target_key.upper()}"
                                ),
                            },
                        )
                )
        if existing_project:
            for mapping in mappings:
                expected_columns = next((len(target.columns) for target in selected_targets if target.logical_target_key.upper() == str(mapping.metadata.get('logical_target_table_key') or '').upper()), 0)
                if not mapping.last_snapshot_id or mapping.mapping_count < expected_columns:
                    raise AppValidationError('An existing template mapping is incomplete. Review it before retrying; existing work was preserved.')
        if existing_project and existing_project.metadata.get('bootstrap_status') == 'COMPLETE' and not bootstrap_items:
            # Idempotent recovery of a lost response must not overwrite later
            # project metadata or any mapping edits with the initial request.
            return ProjectBootstrapResponse(project=existing_project, mappings=mappings, template=template,
                bootstrap_status='COMPLETE', unavailable_target_tables=[item.table_name for item in template.missing_targets])
        mappings.extend(self._initialize_blank_mappings(project, bootstrap_items, user_id=user_id, display_name=display_name))
        metadata['bootstrap_status'] = 'COMPLETE'
        self._session.sql(f"UPDATE {self._projects_table} SET PROJECT_METADATA = PARSE_JSON(?) WHERE TO_VARCHAR(PROJECT_ID) = ?",
            params=[json.dumps(metadata), project.project_id]).collect()
        project = project.model_copy(update={'metadata': metadata, 'sttm_count': len(mappings),
            'draft_count': sum(item.status == 'DRAFT' for item in mappings),
            'total_mappings': sum(item.mapping_count for item in mappings),
            'mapped_count': sum(item.mapped_count for item in mappings)})
        return ProjectBootstrapResponse(
            project=project,
            mappings=mappings,
            template=template,
            bootstrap_status="COMPLETE",
            unavailable_target_tables=[item.table_name for item in template.missing_targets],
        )

    def list_projects(self) -> list[ProjectRecord]:
        self.ensure_storage_exists()
        order_by = self._order_by_expr(
            self._projects_table,
            ["LAST_MODIFIED_DATETIME", "CREATED_DATETIME", "PROJECT_ID"],
            "PROJECT_ID",
        )
        projects = [
            row.as_dict()
            for row in self._session.sql(
                f"SELECT * FROM {self._projects_table} "
                "WHERE COALESCE(STATUS, 'ACTIVE') NOT IN ('ARCHIVED', 'DELETED') "
                f"ORDER BY {order_by} DESC"
            ).collect()
        ]
        counts = self._project_counts()
        return [self._project_from_row(row, counts=counts.get(str(row.get("PROJECT_ID")), {})) for row in projects]

    def get_project(self, project_id: str) -> ProjectRecord | None:
        self.ensure_storage_exists()
        rows = self._session.sql(
            f"SELECT * FROM {self._projects_table} "
            f"WHERE PROJECT_ID = {self._quote_literal(project_id)} "
            "AND COALESCE(STATUS, 'ACTIVE') NOT IN ('ARCHIVED', 'DELETED')"
        ).collect()
        if not rows:
            return None
        return self._project_from_row(rows[0].as_dict(), counts=self._project_counts().get(project_id, {}))

    def list_project_attributes(self, project_id: str) -> list[ProjectAttributeRecord]:
        self.ensure_storage_exists()
        rows = self._session.sql(
            f"""
            SELECT
                a.*,
                p.PROJECT_NAME,
                source_project.PROJECT_NAME AS SOURCE_PROJECT_NAME
            FROM {self._project_attributes_table} a
            LEFT JOIN {self._projects_table} p
              ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(a.PROJECT_ID)
            LEFT JOIN {self._projects_table} source_project
              ON TO_VARCHAR(source_project.PROJECT_ID) = TO_VARCHAR(a.SOURCE_PROJECT_ID)
            WHERE TO_VARCHAR(a.PROJECT_ID) = {self._quote_literal(project_id)}
              AND COALESCE(a.STATUS, 'ACTIVE') = 'ACTIVE'
            ORDER BY UPPER(a.ATTRIBUTE_NAME), a.CREATED_AT
            """
        ).collect()
        return [self._project_attribute_from_row(row.as_dict()) for row in rows]

    def create_project_attribute(
        self,
        project_id: str,
        payload: ProjectAttributeCreateRequest,
        *,
        user_id: str | None,
        source_project_id: str | None = None,
        source_attribute_id: str | None = None,
    ) -> ProjectAttributeRecord:
        self.ensure_storage_exists()
        if self.get_project(project_id) is None:
            raise AppValidationError(
                message=f"Project {project_id} was not found.",
                details=[{"field": "project_id", "message": "Project does not exist."}],
            )
        name = payload.attribute_name.strip()
        duplicate = self._session.sql(
            f"""
            SELECT ATTRIBUTE_ID
            FROM {self._project_attributes_table}
            WHERE TO_VARCHAR(PROJECT_ID) = {self._quote_literal(project_id)}
              AND UPPER(ATTRIBUTE_NAME) = UPPER({self._quote_literal(name)})
              AND COALESCE(STATUS, 'ACTIVE') = 'ACTIVE'
            LIMIT 1
            """
        ).collect()
        if duplicate:
            raise AppValidationError(
                message=f"Project value {name} already exists.",
                details=[{"field": "attribute_name", "message": "Name must be unique within the project."}],
            )
        attribute_id = str(uuid.uuid4())
        self._session.sql(
            f"""
            INSERT INTO {self._project_attributes_table} (
                ATTRIBUTE_ID,
                PROJECT_ID,
                ATTRIBUTE_NAME,
                ATTRIBUTE_TYPE,
                ATTRIBUTE_VALUE,
                SOURCE_PROJECT_ID,
                SOURCE_ATTRIBUTE_ID,
                STATUS,
                CREATED_BY,
                UPDATED_BY
            )
            SELECT
                {self._quote_literal(attribute_id)},
                {self._quote_literal(project_id)},
                {self._quote_literal(name)},
                {self._quote_literal(payload.attribute_type.strip().upper())},
                {self._quote_literal(payload.attribute_value)},
                {self._quote_literal(source_project_id or '')},
                {self._quote_literal(source_attribute_id or '')},
                'ACTIVE',
                {self._quote_literal(user_id or '')},
                {self._quote_literal(user_id or '')}
            """
        ).collect()
        return next(
            item for item in self.list_project_attributes(project_id)
            if item.attribute_id == attribute_id
        )

    def upsert_project_attributes(
        self,
        project_id: str,
        payload: ProjectAttributeBatchUpsertRequest,
        *,
        user_id: str | None,
    ) -> ProjectAttributeBatchUpsertResponse:
        with _attribute_upsert_locks_guard:
            lock = _attribute_upsert_locks.setdefault(str(project_id), RLock())
        with lock:
            return self._upsert_project_attributes_locked(
                project_id,
                payload,
                user_id=user_id,
            )

    def _upsert_project_attributes_locked(
        self,
        project_id: str,
        payload: ProjectAttributeBatchUpsertRequest,
        *,
        user_id: str | None,
    ) -> ProjectAttributeBatchUpsertResponse:
        self.ensure_storage_exists()
        if self.get_project(project_id) is None:
            raise AppValidationError(
                message=f"Project {project_id} was not found.",
                details=[{"field": "project_id", "message": "Project does not exist."}],
            )
        if not payload.attributes:
            return ProjectAttributeBatchUpsertResponse()
        self._session.sql("BEGIN").collect()
        try:
            return self._upsert_project_attributes_transaction(
                project_id,
                payload,
                user_id=user_id,
            )
        except Exception:
            self._session.sql("ROLLBACK").collect()
            raise

    def _upsert_project_attributes_transaction(
        self,
        project_id: str,
        payload: ProjectAttributeBatchUpsertRequest,
        *,
        user_id: str | None,
    ) -> ProjectAttributeBatchUpsertResponse:
        normalized: dict[str, dict[str, str]] = {}
        for item in payload.attributes:
            key = item.attribute_name.strip().upper()
            candidate = {
                "attribute_id": str(uuid.uuid4()),
                "attribute_name": item.attribute_name.strip(),
                "attribute_type": item.attribute_type.strip().upper(),
                "attribute_value": item.attribute_value,
            }
            previous = normalized.get(key)
            if previous and (
                previous["attribute_value"] != candidate["attribute_value"]
                or previous["attribute_type"] != candidate["attribute_type"]
            ):
                raise AppValidationError(
                    message=f"Project value {candidate['attribute_name']} has conflicting uploaded values.",
                    details=[{"field": "attributes", "message": "Duplicate names must have the same value."}],
                )
            normalized[key] = candidate
        rows = self._session.sql(
            f"""
            SELECT ATTRIBUTE_NAME, ATTRIBUTE_TYPE, ATTRIBUTE_VALUE, COUNT(*) OVER (
                PARTITION BY UPPER(ATTRIBUTE_NAME)
            ) AS NAME_COUNT
            FROM {self._project_attributes_table}
            WHERE TO_VARCHAR(PROJECT_ID) = {self._quote_literal(project_id)}
              AND UPPER(ATTRIBUTE_NAME) IN (
                  SELECT UPPER(value::STRING)
                  FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))
              )
              AND COALESCE(STATUS, 'ACTIVE') = 'ACTIVE'
            """,
            [json.dumps(list(normalized))],
        ).collect()
        existing: dict[str, tuple[str, str]] = {}
        for row in rows:
            values = row.as_dict()
            key = str(values.get("ATTRIBUTE_NAME") or "").upper()
            if int(values.get("NAME_COUNT") or 1) > 1 or key in existing:
                raise AppValidationError(
                    message=f"Project value {values.get('ATTRIBUTE_NAME') or key} has duplicate active records.",
                    details=[{"field": "attributes", "message": "Duplicate project values must be resolved before import."}],
                )
            existing[key] = (
                str(values.get("ATTRIBUTE_TYPE") or "").upper(),
                str(values.get("ATTRIBUTE_VALUE") or ""),
            )
        conflicts = [
            value["attribute_name"]
            for key, value in normalized.items()
            if key in existing
            and existing[key] != (value["attribute_type"], value["attribute_value"])
        ]
        if conflicts:
            raise AppValidationError(
                message=f"Project value {conflicts[0]} already exists with a different value.",
                details=[{"field": "attributes", "message": "Existing project values are not overwritten."}],
            )
        pending = [value for key, value in normalized.items() if key not in existing]
        if pending:
            self._session.sql(
                f"""
                MERGE INTO {self._project_attributes_table} target
                USING (
                    SELECT
                        value:attribute_id::STRING AS ATTRIBUTE_ID,
                        {self._quote_literal(project_id)} AS PROJECT_ID,
                        value:attribute_name::STRING AS ATTRIBUTE_NAME,
                        value:attribute_type::STRING AS ATTRIBUTE_TYPE,
                        value:attribute_value::STRING AS ATTRIBUTE_VALUE
                    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))
                ) source
                ON TO_VARCHAR(target.PROJECT_ID) = source.PROJECT_ID
                   AND UPPER(target.ATTRIBUTE_NAME) = UPPER(source.ATTRIBUTE_NAME)
                   AND COALESCE(target.STATUS, 'ACTIVE') = 'ACTIVE'
                WHEN NOT MATCHED THEN INSERT (
                    ATTRIBUTE_ID, PROJECT_ID, ATTRIBUTE_NAME, ATTRIBUTE_TYPE,
                    ATTRIBUTE_VALUE, STATUS, CREATED_BY, UPDATED_BY
                ) VALUES (
                    source.ATTRIBUTE_ID, source.PROJECT_ID, source.ATTRIBUTE_NAME,
                    source.ATTRIBUTE_TYPE, source.ATTRIBUTE_VALUE, 'ACTIVE',
                    {self._quote_literal(user_id or '')},
                    {self._quote_literal(user_id or '')}
                )
                """,
                [json.dumps(pending)],
            ).collect()
        names = set(normalized)
        try:
            attributes = [
                item for item in self.list_project_attributes(project_id)
                if item.attribute_name.upper() in names
            ]
            returned_by_name: dict[str, ProjectAttributeRecord] = {}
            for attribute in attributes:
                key = attribute.attribute_name.upper()
                if key in returned_by_name:
                    raise AppValidationError(
                        message=f"Project value {attribute.attribute_name} has duplicate active records.",
                        details=[{"field": "attributes", "message": "Duplicate project values must be resolved before import."}],
                    )
                returned_by_name[key] = attribute
            for key, expected in normalized.items():
                actual = returned_by_name.get(key)
                if actual is None or (
                    actual.attribute_type.upper(),
                    actual.attribute_value,
                ) != (expected["attribute_type"], expected["attribute_value"]):
                    raise AppValidationError(
                        message=f"Project value {expected['attribute_name']} changed during import.",
                        details=[{"field": "attributes", "message": "Retry after reviewing the current project value."}],
                    )
        except AppValidationError:
            if pending:
                self._session.sql(
                    f"""
                    DELETE FROM {self._project_attributes_table}
                    WHERE TO_VARCHAR(PROJECT_ID) = {self._quote_literal(project_id)}
                      AND ATTRIBUTE_ID IN (
                          SELECT value:attribute_id::STRING
                          FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))
                      )
                    """,
                    [json.dumps(pending)],
                ).collect()
            raise
        response = ProjectAttributeBatchUpsertResponse(
            attributes=list(returned_by_name.values()),
            created_count=len(pending),
            unchanged_count=len(normalized) - len(pending),
        )
        self._session.sql("COMMIT").collect()
        return response

    def update_project_attribute(
        self,
        project_id: str,
        attribute_id: str,
        payload: ProjectAttributeUpdateRequest,
        *,
        user_id: str | None,
    ) -> ProjectAttributeRecord:
        self.ensure_storage_exists()
        current = next(
            (item for item in self.list_project_attributes(project_id) if item.attribute_id == attribute_id),
            None,
        )
        if current is None:
            raise AppValidationError(
                message=f"Project value {attribute_id} was not found.",
                details=[{"field": "attribute_id", "message": "Project value does not exist."}],
            )
        name = payload.attribute_name.strip() if payload.attribute_name is not None else current.attribute_name
        duplicate = self._session.sql(
            f"""
            SELECT ATTRIBUTE_ID
            FROM {self._project_attributes_table}
            WHERE TO_VARCHAR(PROJECT_ID) = {self._quote_literal(project_id)}
              AND UPPER(ATTRIBUTE_NAME) = UPPER({self._quote_literal(name)})
              AND ATTRIBUTE_ID <> {self._quote_literal(attribute_id)}
              AND COALESCE(STATUS, 'ACTIVE') = 'ACTIVE'
            LIMIT 1
            """
        ).collect()
        if duplicate:
            raise AppValidationError(
                message=f"Project value {name} already exists.",
                details=[{"field": "attribute_name", "message": "Name must be unique within the project."}],
            )
        self._session.sql(
            f"""
            UPDATE {self._project_attributes_table}
            SET ATTRIBUTE_NAME = {self._quote_literal(name)},
                ATTRIBUTE_TYPE = {self._quote_literal((payload.attribute_type or current.attribute_type).strip().upper())},
                ATTRIBUTE_VALUE = {self._quote_literal(
                    current.attribute_value if payload.attribute_value is None else payload.attribute_value
                )},
                STATUS = {self._quote_literal(payload.status or current.status)},
                UPDATED_BY = {self._quote_literal(user_id or '')},
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE TO_VARCHAR(PROJECT_ID) = {self._quote_literal(project_id)}
              AND ATTRIBUTE_ID = {self._quote_literal(attribute_id)}
            """
        ).collect()
        updated = [
            item for item in self.list_project_attributes(project_id)
            if item.attribute_id == attribute_id
        ]
        if not updated:
            return current.model_copy(update={"status": payload.status or current.status})
        return updated[0]

    def delete_project_attribute(self, project_id: str, attribute_id: str, *, user_id: str | None) -> None:
        self.ensure_storage_exists()
        self._session.sql(
            f"""
            UPDATE {self._project_attributes_table}
            SET STATUS = 'INACTIVE',
                UPDATED_BY = {self._quote_literal(user_id or '')},
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE TO_VARCHAR(PROJECT_ID) = {self._quote_literal(project_id)}
              AND ATTRIBUTE_ID = {self._quote_literal(attribute_id)}
            """
        ).collect()

    def import_project_attributes(
        self,
        project_id: str,
        payload: ProjectAttributeImportRequest,
        *,
        user_id: str | None,
    ) -> list[ProjectAttributeRecord]:
        requested_ids = set(payload.attribute_ids)
        source_rows = [
            item for item in self.list_project_attributes(payload.source_project_id)
            if not requested_ids or item.attribute_id in requested_ids
        ]
        existing_by_name = {
            item.attribute_name.upper(): item
            for item in self.list_project_attributes(project_id)
        }
        for source in source_rows:
            existing = existing_by_name.get(source.attribute_name.upper())
            value = ProjectAttributeCreateRequest(
                attribute_name=source.attribute_name,
                attribute_type=source.attribute_type,
                attribute_value=source.attribute_value,
            )
            if existing:
                if payload.overwrite_existing:
                    self.update_project_attribute(
                        project_id,
                        existing.attribute_id,
                        ProjectAttributeUpdateRequest(
                            attribute_type=value.attribute_type,
                            attribute_value=value.attribute_value,
                        ),
                        user_id=user_id,
                    )
                continue
            created = self.create_project_attribute(
                project_id,
                value,
                user_id=user_id,
                source_project_id=payload.source_project_id,
                source_attribute_id=source.attribute_id,
            )
            existing_by_name[created.attribute_name.upper()] = created
        return self.list_project_attributes(project_id)

    def create_sttm(
        self,
        project_id: str,
        payload: STTMCreateRequest,
        *,
        user_id: str | None,
        session_id: str | None,
        thread_id: str | None,
        emit_fir: bool = True,
        display_name: str | None = None,
    ) -> STTMRecord:
        if payload.precedent_links:
            # Validate before inserting so a missing migration cannot leave an
            # orphan STTM behind after a partial request.
            self._require_link_storage(
                self._mapping_links_table,
                field="precedent_links",
            )
        self.ensure_storage_exists()
        snapshot = self._snapshot_to_dict(payload.workspace_snapshot)
        self._validate_project_value_bindings(project_id, snapshot)
        semantic_bundle_id = payload.semantic_bundle_id or self._semantic_bundle_id(snapshot)
        semantic_bundle_hash = payload.semantic_bundle_hash or self._semantic_bundle_hash(snapshot)
        target_fqn = self._table_ref_to_fqn(payload.target_table) or self._table_ref_to_fqn(snapshot.get("target_table"))
        mapping_intent_name = None
        if isinstance(snapshot.get("mapping_intent"), dict):
            mapping_intent_name = snapshot.get("mapping_intent", {}).get("name")
        sttm_name = (
            payload.sttm_name
            or mapping_intent_name
            or f"STTM {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        sttm_metadata = {
            **payload.metadata,
            "actor_user_id": user_id or "",
            "mapping_name": sttm_name,
            "mapping_description": payload.description or "",
        }
        if display_name and payload.metadata.get("bootstrap_origin") == "project_template":
            sttm_metadata["created_by_name"] = display_name.strip()
        migration_run_id = str(payload.metadata.get("migration_run_id") or "").strip()
        agent_external_key = str(payload.metadata.get("agent_external_key") or "").strip()
        if migration_run_id and not agent_external_key:
            agent_external_key = f"agent-run:{migration_run_id}:target:{str(target_fqn or sttm_name).upper()}"
            sttm_metadata["agent_external_key"] = agent_external_key
        is_historical_import = str(payload.metadata.get("source") or "").lower() == "historical_import"
        snapshot_json = json.dumps(
            self._normalize_json_value(snapshot), default=str, allow_nan=False
        )
        sttm_metadata_json = json.dumps(
            self._normalize_json_value(sttm_metadata), default=str, allow_nan=False
        )
        self._insert_existing_columns_bound(
            self._sttm_table,
            {
                "PROJECT_ID": self._quote_literal(project_id),
                "STATUS": "'IMPORTING'" if is_historical_import else "'DRAFT'",
                "IMPORT_STATE": "'IMPORTING'" if is_historical_import else "NULL",
                "IMPORT_KEY": self._quote_literal(str(payload.metadata.get("import_key") or "")),
                "RUNTIME_SUPPRESSED": "TRUE" if is_historical_import else "FALSE",
                **self._actor_column_values(self._sttm_table, user_id),
                "STTM_NAME": self._quote_literal(sttm_name),
                "DESCRIPTION": self._quote_literal(payload.description or ""),
                "TARGET_TABLE": self._quote_literal(target_fqn),
                "DRAFT_PAYLOAD": ("PARSE_JSON(?)", [snapshot_json]),
                "SEMANTIC_BUNDLE_ID": self._quote_literal(semantic_bundle_id or ""),
                "SEMANTIC_BUNDLE_HASH": self._quote_literal(semantic_bundle_hash or ""),
                "STTM_METADATA": ("PARSE_JSON(?)", [sttm_metadata_json]),
                "AGENT_EXTERNAL_KEY": self._quote_literal(agent_external_key),
            },
        )
        identity_predicate = (
            f"AGENT_EXTERNAL_KEY = {self._quote_literal(agent_external_key)}"
            if agent_external_key and self._has_column(self._sttm_table, "AGENT_EXTERNAL_KEY")
            else f"PROJECT_ID = {self._quote_literal(project_id)}"
        )
        sttm_row = self._session.sql(
            f"""
            SELECT *
            FROM {self._sttm_table}
            WHERE {identity_predicate}
            ORDER BY {self._order_by_expr(self._sttm_table, ["CREATED_DATETIME", "STTM_ID"], "STTM_ID")} DESC
            LIMIT 1
            """
        ).collect()[0].as_dict()
        sttm = self._sttm_from_row(sttm_row, mapping_counts={})
        if payload.precedent_links:
            links = self.replace_mapping_links(
                sttm.sttm_id,
                MappingPrecedentLinksUpdate(links=payload.precedent_links),
                user_id=user_id,
            )
            sttm = sttm.model_copy(
                update={"linked_mapping_ids": [item.precedent_sttm_id for item in links]}
            )
        if emit_fir:
            self._record_fir(
                event_type="mapping.created",
                user_id=user_id,
                session_id=session_id,
                request_id=None,
                page=str(snapshot.get("page") or "mappings"),
                surface=str(snapshot.get("surface") or "new_mapping"),
                entity_type="sttm",
                entity_ids=[project_id, sttm.sttm_id],
                payload={
                    "project_id": project_id,
                    "sttm_id": sttm.sttm_id,
                    "mapping_name": sttm_name,
                    "mapping_description": payload.description or "",
                    "target_table": target_fqn or None,
                    "metadata": payload.metadata,
                },
                context_key=str(snapshot.get("context_key") or ""),
                snapshot_id=str(snapshot.get("snapshot_id") or ""),
                milestone="mapping_created",
            )
        if snapshot:
            self.autosave_sttm(
                sttm.sttm_id,
                STTMAutosaveRequest(
                    workspace_snapshot=snapshot,
                    action="sttm.created",
                    session_id=session_id,
                    thread_id=thread_id,
                    semantic_bundle_id=semantic_bundle_id,
                    semantic_bundle_hash=semantic_bundle_hash,
                    metadata=payload.metadata,
                ),
                user_id=user_id,
            )
            sttm = self.get_sttm_record(sttm.sttm_id) or sttm
        return sttm

    def list_project_links(self, project_id: str) -> list[ProjectPrecedentLinkRecord]:
        try:
            rows = self._session.sql(
                f"""
                SELECT l.*, p.PROJECT_NAME AS PRECEDENT_PROJECT_NAME
                FROM {self._project_links_table} l
                LEFT JOIN {self._projects_table} p
                  ON TO_VARCHAR(p.PROJECT_ID) = l.PRECEDENT_PROJECT_ID
                WHERE l.PROJECT_ID = {self._quote_literal(project_id)}
                  AND LOWER(COALESCE(l.STATUS, 'active')) = 'active'
                ORDER BY l.PRIORITY DESC, l.CREATED_AT
                """
            ).collect()
        except Exception as exc:
            if self._is_missing_link_storage_error(exc):
                logger.warning("Project precedent storage is unavailable: %s", exc)
                return []
            raise
        return [self._project_link_from_row(row.as_dict()) for row in rows]

    def replace_project_links(
        self,
        project_id: str,
        payload: ProjectPrecedentLinksUpdate,
        *,
        user_id: str | None,
    ) -> list[ProjectPrecedentLinkRecord]:
        links = [item for item in payload.links if item.precedent_project_id != project_id]
        try:
            self._require_link_storage(
                self._project_links_table,
                field="precedent_links",
            )
        except AppValidationError:
            if not links:
                return []
            raise
        selected = [item.precedent_project_id for item in links]
        retained_predicate = ""
        if selected:
            selected_sql = ", ".join(self._quote_literal(value) for value in selected)
            retained_predicate = f"AND PRECEDENT_PROJECT_ID NOT IN ({selected_sql})"
        self._session.sql(
            f"""
            UPDATE {self._project_links_table}
            SET STATUS = 'inactive', UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE PROJECT_ID = {self._quote_literal(project_id)}
              {retained_predicate}
              AND LOWER(COALESCE(STATUS, 'active')) = 'active'
            """
        ).collect()
        for item in links:
            link_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"fir-project-link:{project_id}:{item.precedent_project_id}"))
            categories = f"TO_ARRAY(PARSE_JSON({self._json_literal(item.knowledge_categories)}))"
            self._session.sql(
                f"""
                MERGE INTO {self._project_links_table} target
                USING (SELECT
                    {self._quote_literal(link_id)} AS PROJECT_LINK_ID,
                    {self._quote_literal(project_id)} AS PROJECT_ID,
                    {self._quote_literal(item.precedent_project_id)} AS PRECEDENT_PROJECT_ID
                ) source
                ON target.PROJECT_ID = source.PROJECT_ID
                   AND target.PRECEDENT_PROJECT_ID = source.PRECEDENT_PROJECT_ID
                WHEN MATCHED THEN UPDATE SET
                    STATUS = 'active', PRIORITY = {item.priority},
                    KNOWLEDGE_CATEGORIES = {categories},
                    ALLOW_PROJECT_SPECIFIC_VALUES = {str(item.allow_project_specific_values).upper()},
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT (
                    PROJECT_LINK_ID, PROJECT_ID, PRECEDENT_PROJECT_ID, STATUS, PRIORITY,
                    KNOWLEDGE_CATEGORIES, ALLOW_PROJECT_SPECIFIC_VALUES, CREATED_BY
                ) VALUES (
                    source.PROJECT_LINK_ID, source.PROJECT_ID, source.PRECEDENT_PROJECT_ID,
                    'active', {item.priority}, {categories},
                    {str(item.allow_project_specific_values).upper()}, {self._quote_literal(user_id or '')}
                )
                """
            ).collect()
        return self.list_project_links(project_id)

    def list_mapping_links(self, sttm_id: str) -> list[MappingPrecedentLinkRecord]:
        try:
            rows = self._session.sql(
                f"""
                SELECT l.*, s.PROJECT_ID AS PRECEDENT_PROJECT_ID,
                       s.STTM_NAME AS PRECEDENT_STTM_NAME,
                       s.TARGET_TABLE AS PRECEDENT_TARGET_TABLE,
                       s.STATUS AS PRECEDENT_STATUS
                FROM {self._mapping_links_table} l
                LEFT JOIN {self._sttm_table} s
                  ON TO_VARCHAR(s.STTM_ID) = l.PRECEDENT_STTM_ID
                WHERE l.STTM_ID = {self._quote_literal(sttm_id)}
                  AND LOWER(COALESCE(l.STATUS, 'active')) = 'active'
                ORDER BY l.PRIORITY DESC, l.CREATED_AT
                """
            ).collect()
        except Exception as exc:
            if self._is_missing_link_storage_error(exc):
                logger.warning("Mapping precedent storage is unavailable: %s", exc)
                return []
            raise
        return [self._mapping_link_from_row(row.as_dict()) for row in rows]

    def replace_mapping_links(
        self,
        sttm_id: str,
        payload: MappingPrecedentLinksUpdate,
        *,
        user_id: str | None,
    ) -> list[MappingPrecedentLinkRecord]:
        links = [item for item in payload.links if item.precedent_sttm_id != sttm_id]
        try:
            self._require_link_storage(
                self._mapping_links_table,
                field="precedent_links",
            )
        except AppValidationError:
            if not links:
                return []
            raise
        selected = [item.precedent_sttm_id for item in links]
        retained_predicate = ""
        if selected:
            selected_sql = ", ".join(self._quote_literal(value) for value in selected)
            retained_predicate = f"AND PRECEDENT_STTM_ID NOT IN ({selected_sql})"
        self._session.sql(
            f"""
            UPDATE {self._mapping_links_table}
            SET STATUS = 'inactive', UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE STTM_ID = {self._quote_literal(sttm_id)}
              {retained_predicate}
              AND LOWER(COALESCE(STATUS, 'active')) = 'active'
            """
        ).collect()
        for item in links:
            link_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"fir-mapping-link:{sttm_id}:{item.precedent_sttm_id}"))
            categories = f"TO_ARRAY(PARSE_JSON({self._json_literal(item.knowledge_categories)}))"
            self._session.sql(
                f"""
                MERGE INTO {self._mapping_links_table} target
                USING (SELECT
                    {self._quote_literal(link_id)} AS MAPPING_LINK_ID,
                    {self._quote_literal(sttm_id)} AS STTM_ID,
                    {self._quote_literal(item.precedent_sttm_id)} AS PRECEDENT_STTM_ID
                ) source
                ON target.STTM_ID = source.STTM_ID
                   AND target.PRECEDENT_STTM_ID = source.PRECEDENT_STTM_ID
                WHEN MATCHED THEN UPDATE SET
                    STATUS = 'active', PRIORITY = {item.priority},
                    KNOWLEDGE_CATEGORIES = {categories},
                    TARGET_COMPATIBILITY = {self._quote_literal(item.target_compatibility or '')},
                    MAPPING_LIFECYCLE = {self._quote_literal(item.mapping_lifecycle or '')},
                    PURPOSE = {self._quote_literal(item.purpose or '')},
                    CONFIDENCE = {item.confidence},
                    ALLOW_PROJECT_SPECIFIC_VALUES = {str(item.allow_project_specific_values).upper()},
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT (
                    MAPPING_LINK_ID, STTM_ID, PRECEDENT_STTM_ID, STATUS, PRIORITY,
                    KNOWLEDGE_CATEGORIES, TARGET_COMPATIBILITY, MAPPING_LIFECYCLE,
                    PURPOSE, CONFIDENCE, ALLOW_PROJECT_SPECIFIC_VALUES, CREATED_BY
                ) VALUES (
                    source.MAPPING_LINK_ID, source.STTM_ID, source.PRECEDENT_STTM_ID,
                    'active', {item.priority}, {categories},
                    {self._quote_literal(item.target_compatibility or '')},
                    {self._quote_literal(item.mapping_lifecycle or '')},
                    {self._quote_literal(item.purpose or '')}, {item.confidence},
                    {str(item.allow_project_specific_values).upper()},
                    {self._quote_literal(user_id or '')}
                )
                """
            ).collect()
        return self.list_mapping_links(sttm_id)

    def _with_template_creator_names(self, mappings: list[STTMRecord]) -> list[STTMRecord]:
        pending = {
            str(item.metadata.get("actor_user_id") or "").strip()
            for item in mappings
            if item.metadata.get("bootstrap_origin") == "project_template"
            and not str(item.metadata.get("created_by_name") or "").strip()
            and str(item.metadata.get("actor_user_id") or "").strip().lstrip("+-").isdigit()
        }
        if not pending:
            return mappings
        table = getattr(self._settings, "qualified_users_table", None)
        if not table:
            return mappings
        try:
            columns = self._table_columns(table)
            display_columns = [column for column in ("DISPLAY_NAME", "SNOWFLAKE_USER", "USERNAME", "USER_NAME") if column in columns]
            if "USER_ID" not in columns or not display_columns:
                return mappings
            names = [f"NULLIF(TRIM(TO_VARCHAR({column})), '')" for column in display_columns]
            display_sql = names[0] if len(names) == 1 else f"COALESCE({', '.join(names)})"
            rows = self._session.sql(
                f"SELECT TO_VARCHAR(USER_ID) AS CREATOR_ID, {display_sql} AS CREATOR_NAME "
                f"FROM {table} WHERE TO_VARCHAR(USER_ID) IN ({', '.join('?' for _ in pending)})",
                params=sorted(pending),
            ).collect()
            resolved = {str(row.as_dict().get("CREATOR_ID") or ""): str(row.as_dict().get("CREATOR_NAME") or "").strip() for row in rows}
        except Exception as exc:
            logger.debug("Template creator display names unavailable: %s", exc)
            return mappings
        result = []
        for item in mappings:
            name = resolved.get(str(item.metadata.get("actor_user_id") or "").strip())
            if (name and item.metadata.get("bootstrap_origin") == "project_template"
                    and not str(item.metadata.get("created_by_name") or "").strip()):
                item = item.model_copy(update={"metadata": {**item.metadata, "created_by_name": name}})
            result.append(item)
        return result

    def list_sttms(self, project_id: str) -> list[STTMRecord]:
        self.ensure_storage_exists()
        order_by = self._order_by_expr(
            self._sttm_table,
            ["LAST_MODIFIED_DATETIME", "CREATED_DATETIME", "STTM_ID"],
            "STTM_ID",
        )
        rows = self._session.sql(
            f"""
            SELECT *
            FROM {self._sttm_table}
            WHERE PROJECT_ID = {self._quote_literal(project_id)}
              AND COALESCE(RUNTIME_SUPPRESSED, FALSE) = FALSE
              AND COALESCE(STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED', 'DELETED')
            ORDER BY {order_by} DESC
            """
        ).collect()
        counts = self._mapping_counts_by_sttm()
        return self._with_template_creator_names([self._sttm_from_row(row.as_dict(), mapping_counts=counts.get(str(row.as_dict().get("STTM_ID")), {})) for row in rows])

    def list_all_projects_summary(self) -> tuple[list[ProjectRecord], list[STTMRecord]]:
        """Return all projects and STTMs without per-mapping queries.

        Query 1: all projects with per-project STTM lifecycle counts.
        Query 2: all STTMs with per-STTM mapping row counts.
        Older template creator names use one optional batched profile lookup.

        The frontend is responsible for grouping STTMs under their project.
        """
        self.ensure_storage_exists()
        projects = self.list_projects()
        order_by = self._order_by_expr(
            self._sttm_table,
            ["LAST_MODIFIED_DATETIME", "CREATED_DATETIME", "STTM_ID"],
            "STTM_ID",
        )
        rows = self._session.sql(
            f"""
            SELECT *
            FROM {self._sttm_table}
            WHERE COALESCE(STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED', 'DELETED')
              AND TO_VARCHAR(PROJECT_ID) IN (
                  SELECT TO_VARCHAR(PROJECT_ID)
                  FROM {self._projects_table}
                  WHERE COALESCE(STATUS, 'ACTIVE') NOT IN ('ARCHIVED', 'DELETED')
              )
            ORDER BY {order_by} DESC
            """
        ).collect()
        counts = self._mapping_counts_by_sttm()
        sttms = [
            self._sttm_from_row(row.as_dict(), mapping_counts=counts.get(str(row.as_dict().get("STTM_ID")), {}))
            for row in rows
        ]
        return projects, self._with_template_creator_names(sttms)

    def get_sttm_record(self, sttm_id: str, *, include_counts: bool = True) -> STTMRecord | None:
        self.ensure_storage_exists()
        rows = self._session.sql(
            f"SELECT s.* FROM {self._sttm_table} s "
            f"JOIN {self._projects_table} p ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(s.PROJECT_ID) "
            f"WHERE s.STTM_ID = {self._quote_literal(sttm_id)} "
            "AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE "
            "AND COALESCE(s.STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED', 'DELETED') "
            "AND COALESCE(p.STATUS, 'ACTIVE') NOT IN ('ARCHIVED', 'DELETED')"
        ).collect()
        if not rows:
            return None
        counts = self._mapping_counts_by_sttm().get(sttm_id, {}) if include_counts else {}
        return self._with_template_creator_names([self._sttm_from_row(rows[0].as_dict(), mapping_counts=counts)])[0]

    def get_sttm_detail(
        self,
        sttm_id: str,
        *,
        include_history: bool = False,
    ) -> STTMDetailResponse | None:
        """Load the interactive workspace, deferring heavyweight audit history by default."""
        sttm = self.get_sttm_record(sttm_id)
        if sttm is None:
            return None
        sttm = sttm.model_copy(
            update={
                "linked_mapping_ids": [
                    item.precedent_sttm_id for item in self.list_mapping_links(sttm_id)
                ]
            }
        )
        project = self.get_project(sttm.project_id)
        if project is not None:
            project = project.model_copy(
                update={
                    "linked_project_ids": [
                        item.precedent_project_id
                        for item in self.list_project_links(sttm.project_id)
                    ]
                }
            )
        return STTMDetailResponse(
            project=project,
            sttm=sttm,
            latest_snapshot=self._latest_snapshot(
                sttm_id,
                snapshot_id=sttm.last_snapshot_id,
            ),
            sources=self._list_sources(sttm_id),
            mapping_rows=self._list_mapping_rows(sttm_id),
            versions=self._list_versions(sttm_id) if include_history else [],
            agent_artifacts=self._list_artifacts(sttm_id) if include_history else [],
        )

    @_serialize_autosave
    def autosave_sttm(
        self,
        sttm_id: str,
        payload: STTMAutosaveRequest,
        *,
        user_id: str | None,
        defer_postsave: bool = False,
    ) -> STTMAutosaveResponse:
        self.ensure_storage_exists()
        self._memory.ensure_storage_exists()
        capture_started = time.perf_counter()
        for table in (self._sttm_table, self._sources_table, self._attributes_table):
            self._table_columns(table)
        self._session.sql("BEGIN TRANSACTION").collect()
        try:
            # Serialize mapping writers across replicas before reading the prior
            # snapshot. The caller must supply a dedicated, non-shared session.
            locked = self._session.sql(
                f"UPDATE {self._sttm_table} SET LAST_SNAPSHOT_ID = LAST_SNAPSHOT_ID "
                "WHERE TO_VARCHAR(STTM_ID) = ?",
                params=[sttm_id],
            ).collect()
            if not AsyncJobService._changed(locked):
                raise SnowflakeQueryError(f"STTM {sttm_id} was not found.")
            result = self._capture_autosave(sttm_id, payload, user_id=user_id)
            commit_started = time.perf_counter()
            self._session.sql("COMMIT").collect()
            logging.getLogger("uvicorn.error").info("Autosave committed sttm_id=%s snapshot_id=%s capture_ms=%.1f commit_ms=%.1f",
                        sttm_id, result.snapshot_id, (commit_started - capture_started) * 1000,
                        (time.perf_counter() - commit_started) * 1000)
        except Exception:
            self._session.sql("ROLLBACK").collect()
            raise
        if result.post_save_job_id and not defer_postsave and not self._settings.autosave_postsave_async_v1:
            self.process_postsave_jobs(
                worker_id=f"autosave:{sttm_id}", sttm_id=sttm_id,
                snapshot_id=result.snapshot_id, max_jobs=1,
            )
            status = self._async_jobs.for_snapshot(
                snapshot_id=result.snapshot_id, job_type="sttm_post_save_projection"
            )
            result = result.model_copy(update={"post_save_job_status": (status or {}).get("STATUS", "queued")})
        return result

    def _capture_autosave(
        self, sttm_id: str, payload: STTMAutosaveRequest, *, user_id: str | None
    ) -> STTMAutosaveResponse:
        # Capture only needs identity/lifecycle/metadata, not dashboard counts.
        sttm = self.get_sttm_record(sttm_id, include_counts=False)
        if sttm is None:
            raise SnowflakeQueryError(f"STTM {sttm_id} was not found.")
        snapshot = self._snapshot_to_dict(payload.workspace_snapshot)
        locked_target = str(sttm.metadata.get("physical_target_fqn") or "").strip()
        snapshot_target = self._table_ref_to_fqn(snapshot.get("target_table"))
        if locked_target and snapshot_target and (
            locked_target.replace('"', "").upper()
            != snapshot_target.replace('"', "").upper()
        ):
            raise AppValidationError(
                message=(
                    f"This mapping is locked to {locked_target}; "
                    f"the submitted workspace targets {snapshot_target}."
                ),
                details=[{
                    "field": "workspace_snapshot.target_table",
                    "message": "Template mapping targets cannot be changed.",
                }],
            )
        if str(payload.action or "").strip().lower() == "sttm.publish_autosave":
            self._validate_project_value_bindings(sttm.project_id, snapshot)
        else:
            self._annotate_draft_value_issues(sttm.project_id, snapshot)
        validation_keys = [
            self._snapshot_hash(item)
            for item in snapshot.get("validation_history") or []
            if isinstance(item, dict)
        ]
        snapshot["validation_cursor"] = self._snapshot_hash(
            {
                "sttm_id": sttm_id,
                "validation_keys": validation_keys,
            }
        )
        context_hash = self._normalized_workspace_hash(snapshot)
        snapshot["context_hash"] = context_hash
        previous_snapshot = self._latest_snapshot(sttm_id)
        semantic_bundle_id = payload.semantic_bundle_id or self._semantic_bundle_id(snapshot)
        semantic_bundle_hash = payload.semantic_bundle_hash or self._semantic_bundle_hash(snapshot)
        normalized_action = str(payload.action or "workspace.autosaved").strip().lower()
        previous_context_hash = str(
            (previous_snapshot or {}).get("context_hash") or ""
        )
        if (
            normalized_action == "workspace.autosaved"
            and not payload.agent_artifacts
            and not payload.fir_events
            and previous_snapshot is not None
            and previous_context_hash
            and previous_context_hash == context_hash
        ):
            captured_job = self._async_jobs.for_snapshot(
                snapshot_id=str(previous_snapshot.get("snapshot_id") or ""),
                job_type="sttm_post_save_projection",
            )
            return STTMAutosaveResponse(
                project_id=sttm.project_id,
                sttm_id=sttm_id,
                snapshot_id=str(previous_snapshot.get("snapshot_id") or ""),
                semantic_bundle_id=semantic_bundle_id,
                semantic_bundle_hash=semantic_bundle_hash,
                has_unpublished_draft=bool(sttm.has_unpublished_draft),
                post_save_job_id=(captured_job or {}).get("JOB_ID"),
                post_save_job_status=(captured_job or {}).get("STATUS"),
            )
        # A save whose mapping content equals the latest snapshot (for example
        # reopening a published mapping, or toggling UI-only state) keeps the
        # snapshot current but is not an edit: it must not create draft rows or
        # move a COMPLETE mapping back to IN_PROGRESS.
        content_unchanged = (
            normalized_action == "workspace.autosaved"
            and not payload.agent_artifacts
            and not payload.fir_events
            and previous_snapshot is not None
            and self._semantic_workspace_hash(snapshot)
            == self._semantic_workspace_hash(previous_snapshot)
        )
        snapshot_id = self._memory.save_workspace_snapshot(
            session_id=payload.session_id or str(snapshot.get("session_id") or ""),
            thread_id=payload.thread_id or str(snapshot.get("thread_id") or ""),
            context_hash=context_hash,
            snapshot_payload=snapshot,
            context_version=str(snapshot.get("context_version") or "1.0"),
            context_key=str(snapshot.get("context_key") or ""),
            action=payload.action or str(snapshot.get("action") or "workspace.autosaved"),
            milestone=str(snapshot.get("milestone") or payload.action or ""),
            page=str(snapshot.get("page") or ""),
            surface=str(snapshot.get("surface") or ""),
            project_id=sttm.project_id,
            sttm_id=sttm_id,
            semantic_bundle_id=semantic_bundle_id,
            semantic_bundle_hash=semantic_bundle_hash,
            mapping_version=payload.mapping_version or str(snapshot.get("mapping_version") or ""),
            user_id=user_id,
        )
        snapshot["snapshot_id"] = snapshot_id
        if content_unchanged:
            if sttm.has_unpublished_draft and snapshot.get("mapping_rows") != previous_snapshot.get("mapping_rows"):
                self._replace_mapping_rows(
                    project_id=sttm.project_id, sttm_id=sttm_id, snapshot=snapshot,
                    session_id=payload.session_id, semantic_bundle_id=semantic_bundle_id,
                    semantic_bundle_hash=semantic_bundle_hash, user_id=user_id,
                )
            self._update_sttm_draft_payload(
                sttm_id=sttm_id,
                snapshot=snapshot,
                snapshot_id=snapshot_id,
                semantic_bundle_id=semantic_bundle_id,
                semantic_bundle_hash=semantic_bundle_hash,
                user_id=user_id,
                preserve_status=True,
            )
            increment("autosave.content_unchanged")
            return STTMAutosaveResponse(
                project_id=sttm.project_id,
                sttm_id=sttm_id,
                snapshot_id=snapshot_id,
                semantic_bundle_id=semantic_bundle_id,
                semantic_bundle_hash=semantic_bundle_hash,
                has_unpublished_draft=bool(sttm.has_unpublished_draft),
            )
        saved_source_count = self._replace_sources(sttm_id, snapshot, user_id=user_id)
        saved_mapping_row_count = self._replace_mapping_rows(
            project_id=sttm.project_id,
            sttm_id=sttm_id,
            snapshot=snapshot,
            session_id=payload.session_id or str(snapshot.get("session_id") or ""),
            semantic_bundle_id=semantic_bundle_id,
            semantic_bundle_hash=semantic_bundle_hash,
            user_id=user_id,
        )
        self._update_sttm_draft_payload(
            sttm_id=sttm_id,
            snapshot=snapshot,
            snapshot_id=snapshot_id,
            semantic_bundle_id=semantic_bundle_id,
            semantic_bundle_hash=semantic_bundle_hash,
            user_id=user_id,
        )
        if payload.metadata:
            merged_metadata = {
                **sttm.metadata,
                **self._normalize_json_value(payload.metadata),
            }
            self._update_existing_columns_bound(
                self._sttm_table,
                {
                    "STTM_METADATA": (
                        "PARSE_JSON(?)",
                        [json.dumps(merged_metadata, default=str, allow_nan=False)],
                    )
                },
                "TO_VARCHAR(STTM_ID) = ?",
                where_params=[sttm_id],
            )
        projection_payload = {
            "request": payload.model_dump(mode="json"),
            "snapshot": snapshot,
            "previous_snapshot": previous_snapshot,
            "user_id": user_id,
            "semantic_bundle_id": semantic_bundle_id,
            "semantic_bundle_hash": semantic_bundle_hash,
            "saved_mapping_row_count": saved_mapping_row_count,
            "normalized_action": normalized_action,
        }
        artifact_count = 0
        fir_count = 0
        post_save_job_id = None
        post_save_job_status = None
        from app.core.learning_evidence import requires_learning_projection
        needs_learning = requires_learning_projection(
            snapshot, previous_snapshot, project_id=sttm.project_id,
            sttm_id=sttm_id, actor_id=user_id,
        )
        needs_artifacts = bool(payload.agent_artifacts or snapshot.get("mapping_artifacts"))
        if normalized_action == "sttm.publish_autosave" or not (needs_learning or needs_artifacts):
            # Publication captures its own immutable outbox job; do not learn
            # from an intermediate draft before that capture commits.
            pass
        else:
            try:
                post_save_job_id, post_save_job_status = self._async_jobs.enqueue(
                    snapshot_id=snapshot_id,
                    sttm_id=sttm_id,
                    project_id=sttm.project_id,
                    job_type="sttm_post_save_projection",
                    payload=projection_payload,
                )
            except Exception:
                increment("autosave.async_job.enqueue_failed")
                raise
        return STTMAutosaveResponse(
            project_id=sttm.project_id,
            sttm_id=sttm_id,
            snapshot_id=snapshot_id,
            saved_source_count=saved_source_count,
            saved_mapping_row_count=saved_mapping_row_count,
            recorded_artifact_count=artifact_count,
            recorded_fir_event_count=fir_count,
            semantic_bundle_id=semantic_bundle_id,
            semantic_bundle_hash=semantic_bundle_hash,
            post_save_job_id=post_save_job_id,
            post_save_job_status=post_save_job_status,
        )

    def _run_postsave_projections(
        self,
        *,
        project_id: str,
        sttm_id: str,
        projection_payload: dict[str, Any],
        renew_lease: Callable[[], None] | None = None,
    ) -> tuple[int, int]:
        payload = STTMAutosaveRequest.model_validate(
            projection_payload.get("request") or {}
        )
        snapshot = self._coerce_json(projection_payload.get("snapshot"), {})
        previous_snapshot = self._coerce_json(
            projection_payload.get("previous_snapshot"), {}
        ) or None
        user_id = projection_payload.get("user_id")
        semantic_bundle_id = str(
            projection_payload.get("semantic_bundle_id") or ""
        )
        semantic_bundle_hash = str(
            projection_payload.get("semantic_bundle_hash") or ""
        )
        normalized_action = str(
            projection_payload.get("normalized_action") or "workspace.autosaved"
        )
        saved_mapping_row_count = int(
            projection_payload.get("saved_mapping_row_count") or 0
        )
        from app.core.learning_evidence import requires_learning_projection
        needs_learning = requires_learning_projection(snapshot, previous_snapshot, project_id=project_id,
                                                     sttm_id=sttm_id, actor_id=user_id)
        if not needs_learning and not (payload.agent_artifacts or snapshot.get("mapping_artifacts")):
            return 0, 0
        artifact_count = self._record_agent_artifacts(
            project_id=project_id,
            sttm_id=sttm_id,
            payload=payload,
            snapshot=snapshot,
            user_id=user_id,
            semantic_bundle_id=semantic_bundle_id,
            semantic_bundle_hash=semantic_bundle_hash,
        )
        if not needs_learning:
            # Draft provenance is durable without turning generated output into
            # approved feedback or learning.
            return artifact_count, 0
        if renew_lease:
            renew_lease()
        fir_count = self._record_autosave_fir_events(
            project_id=project_id,
            sttm_id=sttm_id,
            payload=payload,
            snapshot=snapshot,
            previous_snapshot=previous_snapshot,
            user_id=user_id,
            strict=True,
        )
        from app.core.learning_evidence import changed_mapping_rows, manual_mapping_decisions

        changed_rows = changed_mapping_rows(snapshot, previous_snapshot)
        if changed_rows:
            if renew_lease:
                renew_lease()
            # Only explicitly persisted decisions generate learning. Generated
            # draft proposals remain in their immutable request/artifact audits.
            for decision in manual_mapping_decisions(
                snapshot, previous_snapshot, project_id=project_id, sttm_id=sttm_id, actor_id=user_id,
            ):
                receipt = decision["receipt"]
                accepted_snapshot = {**snapshot, "mapping_rows": [decision["row"]]}
                self._knowledge_projector.project(
                    project_id=project_id, sttm_id=sttm_id, snapshot=accepted_snapshot,
                    outcome=receipt["stage"], user_id=user_id, strict=True,
                    evidence=receipt, rows_only=True,
                )
                if receipt["stage"] == "corrected":
                    self._agent_learning.record_learning(
                        agent_type="SOURCE_MAPPING", learning_type="mapping_correction",
                        summary=f"Saved correction for {receipt['target_column']}; reject the prior decision only in its source/population scope.",
                        attributes={"target_column": receipt["target_column"],
                                    "target_table": MappingKnowledgeProjector._table_fqn(snapshot.get("target_table")),
                                    "incorrect_source": decision["before"]["source_columns"],
                                    "correct_source": decision["after"]["source_columns"],
                                    "incorrect_decision": decision["before"], "correct_decision": decision["after"],
                                    "scope_hash": decision["scope_hash"], "learning_evidence": receipt,
                                    "error_category": "explicit_saved_correction",
                                    "prevention_hint": "Do not repeat the exact rejected decision in the same source/population scope."},
                        entity_type="mapping_row", entity_ids={"project_id": project_id, "sttm_id": sttm_id},
                        user_id=user_id, strict=True,
                    )
                self._record_target_mapping_patterns(
                    project_id=project_id, sttm_id=sttm_id, snapshot=accepted_snapshot,
                    evidence_class="accepted_mapping_row", validation_status="accepted",
                    base_confidence=0.9, strict=True,
                )
        from app.core.saved_mapping_validation import has_new_validation_request

        if has_new_validation_request(snapshot, previous_snapshot):
            if renew_lease:
                renew_lease()
            self._project_validated_mapping(
                project_id=project_id, sttm_id=sttm_id, snapshot=snapshot, user_id=user_id,
            )
        self._memory.upsert_feature_snapshot(
            feature_key=f"sttm:{sttm_id}:latest",
            user_id=user_id,
            session_id=payload.session_id or str(snapshot.get("session_id") or ""),
            page=str(snapshot.get("page") or ""),
            surface=str(snapshot.get("surface") or ""),
            entity_type="sttm",
            entity_ids=[sttm_id],
            features=self._build_fir_features(snapshot),
            model_targets={
                "mapped_count": saved_mapping_row_count,
                "semantic_bundle_hash": semantic_bundle_hash,
            },
        )
        return artifact_count, fir_count

    def _project_validated_mapping(self, *, project_id: str, sttm_id: str,
                                   snapshot: dict[str, Any], user_id: str | None) -> None:
        from app.core.mapping_sql import MappingSqlService
        from app.core.saved_mapping_validation import validate_saved_mapping

        compiler = MappingSqlService(session=self._session, analyst_client=None, settings=self._settings)
        # Failure propagates to the durable outbox retry/error path, never promotion.
        validation = validate_saved_mapping(snapshot, project_id=project_id, compiler=compiler,
                                             project_attributes=self.list_project_attributes(project_id))
        identity = "saved-validation:" + self._snapshot_hash({
            "project_id": project_id, "sttm_id": sttm_id, "snapshot_id": snapshot["snapshot_id"],
            "contract_hash": validation["contract_hash"], "sql_hash": validation["sql_hash"],
        })
        event_id = self._record_fir(
            event_type="mapping.compiler_validated", user_id=user_id,
            session_id=str(snapshot.get("session_id") or ""), request_id=identity,
            page="mapping", surface=str(snapshot.get("surface") or ""), entity_type="mapping_rows",
            entity_ids=[project_id, sttm_id], payload={key: value for key, value in validation.items() if key != "rows"},
            snapshot_id=str(snapshot["snapshot_id"]), context_key=str(snapshot.get("context_key") or ""), strict=True,
        )
        if not event_id:
            raise ValueError("Compiler validation event did not return a durable identity")
        evidence = {"contract_version": "mapping_evidence_v1", "stage": "validated", "project_id": project_id,
                    "sttm_id": sttm_id, "snapshot_id": snapshot["snapshot_id"], "event_id": event_id,
                    "validation_receipt_id": event_id, "validation_kind": "snowflake_explain",
                    "contract_hash": validation["contract_hash"], "sql_hash": validation["sql_hash"],
                    "target_columns": validation["target_columns"], "business_correctness_verified": False}
        validated_snapshot = {**snapshot, "mapping_rows": validation["rows"]}
        self._knowledge_projector.project(project_id=project_id, sttm_id=sttm_id, snapshot=validated_snapshot,
                                          outcome="validated", user_id=user_id, strict=True,
                                          evidence=evidence, rows_only=True)
        self._record_target_mapping_patterns(project_id=project_id, sttm_id=sttm_id, snapshot=validated_snapshot,
            evidence_class="validated_mapping", validation_status="validated", base_confidence=0.9, strict=True)

    def process_postsave_jobs(
        self,
        *,
        worker_id: str,
        max_jobs: int = 4,
        snapshot_id: str | None = None,
        sttm_id: str | None = None,
        project_id: str | None = None,
        job_types: tuple[str, ...] | None = None,
    ) -> int:
        """Claim and project durable autosave jobs with retry-safe leases."""
        processed = 0
        for _ in range(max(1, min(max_jobs, 20))):
            job = self._async_jobs.claim_next(
                worker_id=worker_id,
                snapshot_id=snapshot_id,
                sttm_id=sttm_id,
                lease_seconds=900,
                **({"project_id": project_id} if project_id else {}),
                **({"job_types": job_types} if job_types is not None else {}),
            )
            if not job:
                break
            job_id = str(job.get("JOB_ID") or "")
            lease_owner = str(job.get("LEASE_OWNER") or worker_id)
            try:
                payload = self._coerce_json(job.get("PAYLOAD"), {})
                self._async_jobs.renew(job_id, worker_id=lease_owner)
                job_type = str(job.get("JOB_TYPE") or "")
                if job_type not in {"sttm_post_save_projection", "sttm_publish_projection"}:
                    raise ValueError(f"Unsupported post-save job type: {job.get('JOB_TYPE')}")
                project = self._run_publish_projections if job_type == "sttm_publish_projection" else self._run_postsave_projections
                project(
                    project_id=str(job.get("PROJECT_ID") or ""),
                    sttm_id=str(job.get("STTM_ID") or ""),
                    projection_payload=payload,
                    renew_lease=lambda: self._async_jobs.renew(job_id, worker_id=lease_owner),
                )
                self._async_jobs.renew(job_id, worker_id=lease_owner)
                self._async_jobs.mark_complete(job_id, worker_id=lease_owner)
                processed += 1
            except Exception as exc:
                logger.exception("Post-save job %s failed", job_id)
                self._async_jobs.mark_failed(
                    job_id,
                    {"type": type(exc).__name__, "message": str(exc)},
                    worker_id=lease_owner,
                )
        return processed

    def get_postsave_job_status(
        self,
        *,
        sttm_id: str,
        job_id: str,
    ) -> dict[str, Any] | None:
        # Apply the normal STTM visibility check before returning job metadata.
        if self.get_sttm_record(sttm_id) is None:
            return None
        return self._async_jobs.status(job_id=job_id, sttm_id=sttm_id)

    def _project_value_issues(
        self, project_id: str, snapshot: dict[str, Any],
    ) -> list[tuple[dict[str, Any], list[dict[str, str]]]]:
        from app.core.mapping_sql import MappingSqlService

        references = []
        for row in snapshot.get("mapping_rows") or []:
            if not isinstance(row, dict):
                continue
            names = set()
            if str(row.get("mapping_mode") or "").lower() == "attribute":
                name = str(row.get("attribute_name") or "").strip().lstrip("$").upper()
                if name:
                    names.add(name)
            for field in ("expression", "rule", "constant_value"):
                names.update(value.lstrip("$").upper() for value in
                             MappingSqlService._placeholders_in_sql(str(row.get(field) or "")))
            references.append((row, names))
        if not any(names for _, names in references):
            return [(row, []) for row, _ in references]
        # A failed lookup is not an empty roster. Never create Values on save.
        available = {item.attribute_name.strip().upper() for item in self.list_project_attributes(project_id)}
        return [(row, [{"code": "missing_project_value", "category": "value", "severity": "error",
                        "message": f"Project Value ${name} is missing; create or import it before validation.",
                        "source": "draft_value_check"} for name in sorted(names - available)])
                for row, names in references]

    def _annotate_draft_value_issues(self, project_id: str, snapshot: dict[str, Any]) -> None:
        from app.core.mapping_contracts import has_mapping_definition

        for row, issues in self._project_value_issues(project_id, snapshot):
            row["status"] = "MAPPED" if has_mapping_definition(row) else "UNMAPPED"
            previous = row.get("draft_issues") or []
            retained = [issue for issue in previous if isinstance(issue, dict)
                        and issue.get("source") != "draft_value_check"]
            if issues or previous:
                row["draft_issues"] = retained + issues
            if issues:
                validation = row.get("validation")
                if not isinstance(validation, dict) or validation.get("result") != "failed":
                    row["validation"] = None
                row["accepted"] = False

    def _validate_project_value_bindings(
        self,
        project_id: str,
        snapshot: dict[str, Any],
        *,
        include_unresolved: bool = False,
    ) -> None:
        """Strict interface retained for creation/execution/publication callers."""
        issues = [issue for _, row_issues in self._project_value_issues(project_id, snapshot)
                  for issue in row_issues]
        if issues:
            raise AppValidationError(
                message="One or more Project Value mappings reference missing project metadata.",
                details=[{"field": "mapping_rows.attribute_name", "message": issue["message"]}
                         for issue in issues],
            )

    def _validate_publication(self, project_id: str, snapshot: dict[str, Any]) -> None:
        from app.core.mapping_sql import MappingSqlService

        self._validate_project_value_bindings(project_id, snapshot)
        try:
            validated = MappingSqlService(session=self._session, analyst_client=None, settings=self._settings).validate_publication(
                snapshot, project_id=project_id, project_attributes=self.list_project_attributes(project_id),
            )
            # Preserve authored placeholder text, and capture the exact resolved SQL
            # actually checked against current Values for historical reproducibility.
            snapshot["_publication_validation"] = validated
        except ValueError as exc:
            raise AppValidationError(message=str(exc)) from exc
        except Exception as exc:
            from snowflake.snowpark.exceptions import SnowparkSQLException
            from snowflake.connector.errors import ProgrammingError
            if not isinstance(exc, (SnowparkSQLException, ProgrammingError)):
                raise
            from app.core.sql_failure import sql_failure_details
            details = sql_failure_details(exc)
            query_id = details.get('query_id')
            code = details.get('sql_error_code')
            message = 'Snowflake could not compile the publication SELECT. Check source bindings and current firm values.'
            permission_failure = str(details.get('sql_state') or '') == '42501' or str(code or '').lstrip('0') == '3001'
            if permission_failure:
                message = 'Publication validates read-only SQL. The current role cannot read a required source or metadata object. Target INSERT permission is not required.'
            if code:
                message += f' SQL error: {code}.'
            if query_id:
                message += f' Query ID: {query_id}.'
            logger.warning('Publication SQL validation failed metadata=%s', details)
            if permission_failure:
                from app.core.exceptions import AuthorizationError
                raise AuthorizationError(message, details=[{'field': 'mapping_sql', 'message': message}]) from None
            raise AppValidationError(message=message, details=[{'field': 'mapping_sql', 'message': message}]) from None

    def publish_sttm(
        self,
        sttm_id: str,
        payload: STTMPublishRequest,
        *,
        user_id: str | None,
        actor_type: str = "user",
    ) -> STTMPublishResponse:
        if actor_type != "user":
            raise PermissionError("Publication requires an authenticated human user")
        self.ensure_storage_exists()
        sttm = self.get_sttm_record(sttm_id)
        if sttm is None:
            raise SnowflakeQueryError(f"STTM {sttm_id} was not found.")
        snapshot_payload = self._snapshot_to_dict(payload.workspace_snapshot) or self._latest_snapshot(sttm_id) or {}
        if not snapshot_payload:
            raise SnowflakeQueryError("A mapping snapshot is required for publication.")
        capture_hash = self._snapshot_hash({
            "snapshot": self._normalized_workspace_hash(snapshot_payload),
            "revision_note": payload.revision_note,
            "semantic_bundle_id": payload.semantic_bundle_id,
            "semantic_bundle_hash": payload.semantic_bundle_hash,
            "mapping_version": payload.mapping_version,
            "metadata": payload.metadata,
        })
        capture_id = self._snapshot_hash({
            "sttm_id": sttm_id, "user_id": user_id,
            "request_id": payload.request_id or capture_hash,
        })
        existing = self._published_capture(sttm, capture_id, capture_hash)
        if existing is not None:
            return existing
        self._validate_publication(sttm.project_id, snapshot_payload)
        snapshot_id: str | None = None
        if snapshot_payload:
            autosave = self.autosave_sttm(
                sttm_id,
                STTMAutosaveRequest(
                    workspace_snapshot=snapshot_payload,
                    action="sttm.publish_autosave",
                    session_id=payload.session_id,
                    thread_id=payload.thread_id,
                    semantic_bundle_id=payload.semantic_bundle_id,
                    semantic_bundle_hash=payload.semantic_bundle_hash,
                    mapping_version=payload.mapping_version,
                    metadata=payload.metadata,
                ),
                user_id=user_id,
            )
            snapshot_id = autosave.snapshot_id
        semantic_bundle_id = payload.semantic_bundle_id or self._semantic_bundle_id(snapshot_payload) or sttm.semantic_bundle_id
        semantic_bundle_hash = payload.semantic_bundle_hash or self._semantic_bundle_hash(snapshot_payload) or sttm.semantic_bundle_hash
        next_version = int(sttm.current_version or 0) + 1
        artifact_ids, recommendation_ids = self._publication_provenance(sttm_id, snapshot_payload)
        snapshot_payload["_publication_recommendation_ids"] = recommendation_ids
        snapshot_payload["snapshot_id"] = snapshot_id
        project_context = self._project_business_context(sttm.project_id)
        for key in ("source_system_key", "logical_target_table_key"):
            if project_context.get(key):
                snapshot_payload.setdefault(key, project_context[key])
        if getattr(sttm, "metadata", {}).get("logical_target_table_key"):
            snapshot_payload.setdefault("logical_target_table_key", sttm.metadata["logical_target_table_key"])
        snapshot_payload["published_at"] = datetime.now(timezone.utc).isoformat()
        snapshot_payload["_publication_capture"] = {
            "id": capture_id, "content_hash": capture_hash,
            "version_number": next_version,
        }
        version_payload_json = json.dumps(
            self._normalize_json_value(snapshot_payload), default=str, allow_nan=False
        )
        parsed_mapping_json = json.dumps(
            self._normalize_json_value(snapshot_payload.get("parsed_mapping_model") or {}),
            default=str,
            allow_nan=False,
        )
        artifact_ids_json = json.dumps(artifact_ids, default=str, allow_nan=False)
        raw_mapping_sql = str(
            snapshot_payload.get("raw_mapping_sql")
            or snapshot_payload.get("mapping_sql")
            or snapshot_payload.get("compiled_mapping_sql")
            or ""
        )
        # Resolve schema metadata before BEGIN; no DDL or projection may commit capture early.
        self._table_columns(self._versions_table)
        self._table_columns(self._sttm_table)
        self._session.sql("BEGIN TRANSACTION").collect()
        try:
            claimed = self._session.sql(
                f"UPDATE {self._sttm_table} SET CURRENT_VERSION = ? "
                "WHERE TO_VARCHAR(STTM_ID) = ? AND COALESCE(CURRENT_VERSION, 0) = ? "
                "AND LAST_SNAPSHOT_ID = ? AND COALESCE(RUNTIME_SUPPRESSED, FALSE) = FALSE "
                "AND COALESCE(STATUS, 'DRAFT') NOT IN ('ARCHIVED', 'DELETED')",
                params=[next_version, sttm_id, next_version - 1, snapshot_id],
            ).collect()
            changed = claimed[0].as_dict() if claimed and hasattr(claimed[0], "as_dict") else dict(claimed[0]) if claimed else {}
            if sum(int(value) for value in changed.values() if isinstance(value, (int, float))) != 1:
                raise ConflictError("The draft or published version changed during publication. Reload before publishing.")
            version_id, learning_job_id, learning_status = self._capture_publication(
                sttm=sttm, payload=payload, user_id=user_id, snapshot_payload=snapshot_payload,
                snapshot_id=snapshot_id, next_version=next_version,
                semantic_bundle_id=semantic_bundle_id, semantic_bundle_hash=semantic_bundle_hash,
                artifact_ids_json=artifact_ids_json, version_payload_json=version_payload_json,
                parsed_mapping_json=parsed_mapping_json, raw_mapping_sql=raw_mapping_sql,
            )
            self._session.sql("COMMIT").collect()
        except Exception:
            self._session.sql("ROLLBACK").collect()
            raise
        return STTMPublishResponse(
            project_id=sttm.project_id, sttm_id=sttm_id, version_id=str(version_id),
            version_number=next_version, snapshot_id=snapshot_id, status="COMPLETE",
            semantic_bundle_id=semantic_bundle_id, semantic_bundle_hash=semantic_bundle_hash,
            learning_job_id=learning_job_id, learning_status=learning_status,
        )

    def _published_capture(self, sttm: STTMRecord, capture_id: str, content_hash: str) -> STTMPublishResponse | None:
        rows = self._session.sql(
            f"SELECT * FROM {self._versions_table} WHERE TO_VARCHAR(STTM_ID) = ? "
            "AND VERSION_PAYLOAD:_publication_capture:id::STRING = ? LIMIT 1",
            params=[sttm.sttm_id, capture_id],
        ).collect()
        if not rows:
            return None
        row = rows[0].as_dict()
        snapshot = self._coerce_json(row.get("VERSION_PAYLOAD"), {})
        if snapshot.get("_publication_capture", {}).get("content_hash") != content_hash:
            raise SnowflakeQueryError("The publish request identity was reused with different content.")
        job = self._async_jobs.for_snapshot(snapshot_id=str(row["SNAPSHOT_ID"]), job_type="sttm_publish_projection")
        if not job:
            raise SnowflakeQueryError("Published capture has no durable learning job; recovery is required.")
        return STTMPublishResponse(
            project_id=sttm.project_id, sttm_id=sttm.sttm_id, version_id=str(row["VERSION_ID"]),
            version_number=int(row["VERSION_NUMBER"]), snapshot_id=str(row["SNAPSHOT_ID"]), status="COMPLETE",
            semantic_bundle_id=row.get("SEMANTIC_BUNDLE_ID"), semantic_bundle_hash=row.get("SEMANTIC_BUNDLE_HASH"),
            learning_job_id=str(job["JOB_ID"]), learning_status=str(job["STATUS"]),
        )

    def _capture_publication(
        self, *, sttm: STTMRecord, payload: STTMPublishRequest, user_id: str | None,
        snapshot_payload: dict[str, Any], snapshot_id: str, next_version: int,
        semantic_bundle_id: str | None, semantic_bundle_hash: str | None,
        artifact_ids_json: str, version_payload_json: str, parsed_mapping_json: str, raw_mapping_sql: str,
    ) -> tuple[str, str, str]:
        """DML only: caller owns the version/header/outbox transaction."""
        sttm_id = sttm.sttm_id
        self._insert_existing_columns_bound(
            self._versions_table,
            {
                "STTM_ID": self._quote_literal(sttm_id),
                "VERSION_NUMBER": str(next_version),
                "REVISION_NOTE": self._quote_literal(payload.revision_note or ""),
                "PUBLISHED_BY": self._quote_literal(user_id or ""),
                "SNAPSHOT_ID": self._quote_literal(snapshot_id or sttm.last_snapshot_id or ""),
                "VERSION_PAYLOAD": ("PARSE_JSON(?)", [version_payload_json]),
                "RAW_MAPPING_SQL": ("?", [raw_mapping_sql]),
                "PARSED_MAPPING_MODEL": ("PARSE_JSON(?)", [parsed_mapping_json]),
                "SEMANTIC_BUNDLE_ID": self._quote_literal(semantic_bundle_id or ""),
                "SEMANTIC_BUNDLE_HASH": self._quote_literal(semantic_bundle_hash or ""),
                "MAPPING_VERSION": self._quote_literal(payload.mapping_version or ""),
                "AGENT_ARTIFACT_IDS": ("PARSE_JSON(?)", [artifact_ids_json]),
            },
        )
        version_id = self._session.sql(
            f"""
            SELECT VERSION_ID
            FROM {self._versions_table}
            WHERE STTM_ID = {self._quote_literal(sttm_id)}
              AND VERSION_NUMBER = {next_version}
            LIMIT 1
            """
        ).collect()[0].as_dict().get("VERSION_ID")
        self._update_existing_columns_bound(
            self._sttm_table,
            {
                "CURRENT_VERSION": str(next_version),
                "HAS_UNPUBLISHED_DRAFT": "FALSE",
                "STATUS": "'COMPLETE'",
                "IMPORT_STATE": "IFF(IMPORT_KEY IS NULL, IMPORT_STATE, 'COMPLETE')",
                "RUNTIME_SUPPRESSED": "FALSE",
                "RAW_MAPPING_SQL": ("?", [raw_mapping_sql]),
                "PARSED_MAPPING_MODEL": ("PARSE_JSON(?)", [parsed_mapping_json]),
                **self._actor_column_values(self._sttm_table, user_id),
                "LAST_MODIFIED_DATETIME": "CURRENT_TIMESTAMP()",
                "SEMANTIC_BUNDLE_ID": self._quote_literal(semantic_bundle_id or ""),
                "SEMANTIC_BUNDLE_HASH": self._quote_literal(semantic_bundle_hash or ""),
            },
            "TO_VARCHAR(STTM_ID) = ?",
            where_params=[sttm_id],
        )
        learning_job_id, learning_status = self._async_jobs.enqueue(
            snapshot_id=snapshot_id, sttm_id=sttm_id, project_id=sttm.project_id,
            job_type="sttm_publish_projection",
            payload={
                "snapshot": snapshot_payload, "version_id": str(version_id),
                "version_number": next_version, "user_id": user_id,
                "session_id": payload.session_id,
            },
        )
        return str(version_id), learning_job_id, learning_status

    def _publication_provenance(
        self, sttm_id: str, snapshot: dict[str, Any]
    ) -> tuple[list[str], list[str]]:
        inline = [item for item in snapshot.get("mapping_artifacts") or [] if isinstance(item, dict)]
        mapping_rows = [item for item in snapshot.get("mapping_rows") or [] if isinstance(item, dict)]
        artifact_ids = sorted({str(value) for item in [*inline, *mapping_rows]
                               for value in [item.get("agent_artifact_id"), item.get("artifact_id"), item.get("ARTIFACT_ID")]
                               if value})
        recommendations = {str(value) for item in [*inline, *mapping_rows]
                           for value in item.get("used_recommendation_ids") or [] if value}
        # Only evidence actually referenced by this captured version can earn
        # a publication outcome; the mapping's later/older artifacts cannot.
        for offset in range(0, len(artifact_ids), 100):
            page = artifact_ids[offset:offset + 100]
            rows = self._session.sql(
                f"SELECT ARTIFACT_ID, USED_RECOMMENDATION_IDS, PAYLOAD FROM {self._artifacts_table} "
                f"WHERE ARTIFACT_ID IN ({', '.join('?' for _ in page)}) "
                "AND (ARRAY_CONTAINS(?::VARIANT, ENTITY_IDS) OR PAYLOAD:sttm_id::STRING = ?)",
                params=[*page, sttm_id, sttm_id],
            ).collect()
            found = set()
            for row in rows:
                record = row.as_dict() if hasattr(row, "as_dict") else dict(row)
                found.add(str(record["ARTIFACT_ID"]))
                details = self._coerce_json(record.get("PAYLOAD"), {})
                recommendations.update(str(value) for value in (
                    self._coerce_json(record.get("USED_RECOMMENDATION_IDS"), [])
                    or details.get("used_recommendation_ids") or []
                ) if value)
            if found != set(page):
                raise SnowflakeQueryError("Referenced mapping evidence is not yet available; publication was not captured.")
        return artifact_ids, sorted(recommendations)

    def _run_publish_projections(
        self, *, project_id: str, sttm_id: str, projection_payload: dict[str, Any],
        renew_lease: Callable[[], None] | None = None,
    ) -> tuple[int, int]:
        snapshot_payload = self._coerce_json(projection_payload.get("snapshot"), {})
        next_version = int(projection_payload["version_number"])
        user_id = projection_payload.get("user_id")
        snapshot_id = str(snapshot_payload["snapshot_id"])
        event_identity = f"publish:{sttm_id}:{projection_payload['version_id']}"
        from app.core.learning_evidence import durable_event_id

        self._record_fir(
            event_type="sttm.published",
            user_id=user_id,
            session_id=projection_payload.get("session_id"),
            request_id=event_identity,
            page=str(snapshot_payload.get("page") or "summary"),
            surface=str(snapshot_payload.get("surface") or "publish"),
            entity_type="sttm",
            entity_ids=[sttm_id, f"version:{next_version}"],
            payload={
                "project_id": project_id,
                "sttm_id": sttm_id,
                "version_number": next_version,
                "semantic_bundle_hash": self._semantic_bundle_hash(snapshot_payload),
                "mapping_count": len(snapshot_payload.get("mapping_rows") or []),
            },
            context_key=str(snapshot_payload.get("context_key") or ""),
            snapshot_id=snapshot_id,
            milestone="sttm.published",
            strict=True,
        )
        if renew_lease:
            renew_lease()
        learning_count = self._record_agent_learnings(
            project_id=project_id,
            sttm_id=sttm_id,
            snapshot=snapshot_payload,
            user_id=user_id,
            strict=True,
        )
        if renew_lease:
            renew_lease()
        learning_count += self._knowledge_projector.project(
            project_id=project_id,
            sttm_id=sttm_id,
            snapshot=snapshot_payload,
            outcome="published",
            user_id=user_id,
            strict=True,
            evidence={
                "contract_version": "mapping_evidence_v1", "stage": "published",
                "project_id": project_id, "sttm_id": sttm_id, "snapshot_id": snapshot_id,
                "event_id": durable_event_id("sttm.published", event_identity), "request_id": event_identity,
                "version_id": str(projection_payload["version_id"]),
                "actor_id": user_id,
            },
        )
        if renew_lease:
            renew_lease()
        self._record_target_mapping_patterns(
            project_id=project_id,
            sttm_id=sttm_id,
            snapshot=snapshot_payload,
            evidence_class="published_mapping",
            validation_status="published",
            base_confidence=0.97,
            strict=True,
            publication_version_id=str(projection_payload["version_id"]),
        )
        if renew_lease:
            renew_lease()
        self._record_learned_relationships(sttm_id=sttm_id, snapshot=snapshot_payload, strict=True)
        logger.debug("Recorded %d published agent learnings for STTM %s", learning_count, sttm_id)
        recommendation_ids: set[str] = set(snapshot_payload.get("_publication_recommendation_ids") or [])
        for row in snapshot_payload.get("mapping_rows") or []:
            if not isinstance(row, dict):
                continue
            recommendation_ids.update(
                str(value)
                for value in (row.get("used_recommendation_ids") or [])
                if value
            )
        for recommendation_id in recommendation_ids:
            self._memory.record_fir_recommendation_outcome(
                recommendation_id=recommendation_id,
                outcome_type="published",
                context_key=str(snapshot_payload.get("context_key") or ""),
                snapshot_id=snapshot_id,
                request_id=event_identity,
                user_id=user_id,
                payload={
                    "project_id": project_id,
                    "sttm_id": sttm_id,
                    "version_number": next_version,
                },
            )
        from app.core.learning_retrieval import invalidate_learning_context_cache
        invalidate_learning_context_cache()
        return learning_count, 1

    def _project_counts(self) -> dict[str, dict[str, Any]]:
        project_columns = self._table_columns(self._projects_table)
        sttm_columns = self._table_columns(self._sttm_table)
        attribute_columns = self._table_columns(self._attributes_table)
        if project_columns and "PROJECT_ID" not in project_columns:
            return {}
        if sttm_columns and not {"PROJECT_ID", "STTM_ID"}.issubset(sttm_columns):
            return {}

        status_expr = "s.STATUS" if not sttm_columns or "STATUS" in sttm_columns else "'DRAFT'"

        def lifecycle_counts() -> dict[str, dict[str, Any]]:
            try:
                rows = self._session.sql(
                    f"""
                    SELECT
                        p.PROJECT_ID,
                        COUNT(DISTINCT s.STTM_ID) AS STTM_COUNT,
                        COUNT(DISTINCT IFF({status_expr} = 'COMPLETE', s.STTM_ID, NULL)) AS COMPLETE_COUNT,
                        COUNT(DISTINCT IFF({status_expr} IN ('IN_PROGRESS'), s.STTM_ID, NULL)) AS PARTIAL_COUNT,
                        COUNT(DISTINCT IFF({status_expr} = 'DRAFT', s.STTM_ID, NULL)) AS DRAFT_COUNT,
                        0 AS TOTAL_MAPPINGS,
                        0 AS MAPPED_COUNT
                    FROM {self._projects_table} p
                    LEFT JOIN {self._sttm_table} s
                      ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(s.PROJECT_ID)
                     AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE
                 AND COALESCE(s.STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED', 'DELETED')
                    WHERE COALESCE(p.STATUS, 'ACTIVE') NOT IN ('ARCHIVED', 'DELETED')
                    GROUP BY p.PROJECT_ID
                    """
                ).collect()
                return {str(row.as_dict().get("PROJECT_ID")): row.as_dict() for row in rows}
            except Exception as exc:
                logger.warning("Project counts unavailable; returning projects without counts: %s", exc)
                return {}

        if attribute_columns and "STTM_ID" not in attribute_columns:
            return lifecycle_counts()

        attribute_id_expr = (
            "a.ATTRIBUTE_ID"
            if not attribute_columns or "ATTRIBUTE_ID" in attribute_columns
            else "TO_VARCHAR(a.ATTRIBUTE_NAME)"
            if "ATTRIBUTE_NAME" in attribute_columns
            else "TO_VARCHAR(a.STTM_ID)"
        )
        source_column_expr = (
            "a.SOURCE_COLUMN"
            if not attribute_columns or "SOURCE_COLUMN" in attribute_columns
            else "''"
        )
        transformation_expr = (
            "a.TRANSFORMATION_LOGIC"
            if not attribute_columns or "TRANSFORMATION_LOGIC" in attribute_columns
            else "''"
        )
        if not attribute_columns or {"IS_DRAFT", "EFFECTIVE_THROUGH_VERSION"}.issubset(attribute_columns):
            current_attributes_sql = f"""
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE COALESCE(a.IS_DRAFT, FALSE) = TRUE
                    UNION ALL
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE COALESCE(a.IS_DRAFT, FALSE) = FALSE
                      AND a.EFFECTIVE_THROUGH_VERSION IS NULL
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {self._attributes_table} d
                          WHERE TO_VARCHAR(d.STTM_ID) = TO_VARCHAR(a.STTM_ID)
                            AND COALESCE(d.IS_DRAFT, FALSE) = TRUE
                      )
            """
        else:
            current_attributes_sql = f"""
                    SELECT a.*
                    FROM {self._attributes_table} a
            """

        try:
            rows = self._session.sql(
                f"""
                WITH CURRENT_ATTRIBUTES AS (
{current_attributes_sql}
                )
                SELECT
                    p.PROJECT_ID,
                    COUNT(DISTINCT s.STTM_ID) AS STTM_COUNT,
                    COUNT(DISTINCT IFF({status_expr} = 'COMPLETE', s.STTM_ID, NULL)) AS COMPLETE_COUNT,
                    COUNT(DISTINCT IFF({status_expr} IN ('IN_PROGRESS'), s.STTM_ID, NULL)) AS PARTIAL_COUNT,
                    COUNT(DISTINCT IFF({status_expr} = 'DRAFT', s.STTM_ID, NULL)) AS DRAFT_COUNT,
                    COUNT({attribute_id_expr}) AS TOTAL_MAPPINGS,
                    COUNT(IFF(
                        NULLIF(TRIM(COALESCE({source_column_expr}, '')), '') IS NOT NULL
                        OR (NULLIF(TRIM(COALESCE({transformation_expr}, '')), '') IS NOT NULL
                            AND UPPER(TRIM({transformation_expr})) NOT IN
                            ('SELECT...', 'DIRECT', 'IDENTITY', 'VALUE', 'CUSTOM', 'CAST',
                             'COALESCE', 'CONCATENATE', 'UPPER', 'LOWER', 'TRIM', 'DATE_FORMAT',
                             'SUBSTRING', 'REPLACE', 'NULLIF')),
                        {attribute_id_expr},
                        NULL
                    )) AS MAPPED_COUNT
                FROM {self._projects_table} p
                LEFT JOIN {self._sttm_table} s
                  ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(s.PROJECT_ID)
                 AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE
                 AND COALESCE(s.STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED', 'DELETED')
                LEFT JOIN CURRENT_ATTRIBUTES a ON TO_VARCHAR(s.STTM_ID) = TO_VARCHAR(a.STTM_ID)
                WHERE COALESCE(p.STATUS, 'ACTIVE') NOT IN ('ARCHIVED', 'DELETED')
                GROUP BY p.PROJECT_ID
                """
            ).collect()
            return {str(row.as_dict().get("PROJECT_ID")): row.as_dict() for row in rows}
        except Exception as exc:
            logger.warning("Project attribute counts unavailable; falling back to STTM lifecycle counts: %s", exc)
        return lifecycle_counts()

    def _mapping_counts_by_sttm(self) -> dict[str, dict[str, Any]]:
        attribute_columns = self._table_columns(self._attributes_table)
        if attribute_columns and "STTM_ID" not in attribute_columns:
            return {}
        attribute_id_expr = (
            "ATTRIBUTE_ID"
            if not attribute_columns or "ATTRIBUTE_ID" in attribute_columns
            else "ATTRIBUTE_NAME"
            if "ATTRIBUTE_NAME" in attribute_columns
            else "STTM_ID"
        )
        source_column_expr = "SOURCE_COLUMN" if not attribute_columns or "SOURCE_COLUMN" in attribute_columns else "''"
        transformation_expr = (
            "TRANSFORMATION_LOGIC"
            if not attribute_columns or "TRANSFORMATION_LOGIC" in attribute_columns
            else "''"
        )
        if not attribute_columns or {"IS_DRAFT", "EFFECTIVE_THROUGH_VERSION"}.issubset(attribute_columns):
            current_attributes_sql = f"""
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE COALESCE(a.IS_DRAFT, FALSE) = TRUE
                    UNION ALL
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE COALESCE(a.IS_DRAFT, FALSE) = FALSE
                      AND a.EFFECTIVE_THROUGH_VERSION IS NULL
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {self._attributes_table} d
                          WHERE TO_VARCHAR(d.STTM_ID) = TO_VARCHAR(a.STTM_ID)
                            AND COALESCE(d.IS_DRAFT, FALSE) = TRUE
                      )
            """
        else:
            current_attributes_sql = f"""
                    SELECT a.*
                    FROM {self._attributes_table} a
            """
        try:
            rows = self._session.sql(
                f"""
                WITH CURRENT_ATTRIBUTES AS (
{current_attributes_sql}
                )
                SELECT
                    STTM_ID,
                    COUNT(*) AS MAPPING_COUNT,
                    COUNT(IFF(
                        NULLIF(TRIM(COALESCE({source_column_expr}, '')), '') IS NOT NULL
                        OR (NULLIF(TRIM(COALESCE({transformation_expr}, '')), '') IS NOT NULL
                            AND UPPER(TRIM({transformation_expr})) NOT IN
                            ('SELECT...', 'DIRECT', 'IDENTITY', 'VALUE', 'CUSTOM', 'CAST',
                             'COALESCE', 'CONCATENATE', 'UPPER', 'LOWER', 'TRIM', 'DATE_FORMAT',
                             'SUBSTRING', 'REPLACE', 'NULLIF')),
                        {attribute_id_expr},
                        NULL
                    )) AS MAPPED_COUNT
                FROM CURRENT_ATTRIBUTES
                GROUP BY STTM_ID
                """
            ).collect()
            return {str(row.as_dict().get("STTM_ID")): row.as_dict() for row in rows}
        except Exception as exc:
            logger.warning("STTM attribute counts unavailable; returning zero counts: %s", exc)
            return {}

    def _project_creator_names(self, rows: list[dict[str, Any]]) -> dict[str, str]:
        """Resolve legacy numeric creator IDs without changing ownership records."""
        ids = {
            str(row.get("CREATED_BY"))
            for row in rows
            if row.get("CREATED_BY") is not None and str(row.get("CREATED_BY")).isdigit()
        }
        if not ids:
            return {}
        names: dict[str, str] = {}
        try:
            literals = ", ".join(self._quote_literal(value) for value in sorted(ids))
            user_rows = self._session.sql(
                f"SELECT TO_VARCHAR(USER_ID) AS USER_ID, DISPLAY_NAME "
                f"FROM {self._settings.qualified_users_table} "
                f"WHERE TO_VARCHAR(USER_ID) IN ({literals})"
            ).collect()
            names = {
                str(user.as_dict()["USER_ID"]): str(user.as_dict()["DISPLAY_NAME"])
                for user in user_rows
                if user.as_dict().get("DISPLAY_NAME")
            }
        except Exception:
            logger.warning("Project creator display names could not be read from the user directory", exc_info=True)
        local_user = str(self._settings.snowflake_user or "").strip()
        if local_user:
            legacy_id = str(zlib.crc32(local_user.encode("utf-8")))
            if legacy_id in ids:
                names.setdefault(legacy_id, local_user)
        return names

    def _project_from_row(self, row: dict[str, Any], *, counts: dict[str, Any]) -> ProjectRecord:
        total = int(counts.get("TOTAL_MAPPINGS") or 0)
        mapped = int(counts.get("MAPPED_COUNT") or 0)
        metadata = self._coerce_json(row.get("PROJECT_METADATA"), {})
        return ProjectRecord(
            project_id=str(row.get("PROJECT_ID") or ""),
            project_name=str(row.get("PROJECT_NAME") or ""),
            description=str(row.get("DESCRIPTION") or "") or None,
            status=str(row.get("STATUS") or "ACTIVE"),
            created_by=str(
                row.get("CREATED_BY_NAME")
                or metadata.get("created_by_name")
                or row.get("CREATED_BY")
                or ""
            ) or None,
            created_at=row.get("CREATED_DATETIME"),
            updated_at=row.get("LAST_MODIFIED_DATETIME"),
            sttm_count=int(counts.get("STTM_COUNT") or 0),
            complete_count=int(counts.get("COMPLETE_COUNT") or 0),
            partial_count=int(counts.get("PARTIAL_COUNT") or 0),
            draft_count=int(counts.get("DRAFT_COUNT") or 0),
            total_mappings=total,
            mapped_count=mapped,
            coverage_percent=round((mapped / total) * 100, 2) if total else 0,
            metadata=metadata,
        )

    @staticmethod
    def _project_attribute_from_row(row: dict[str, Any]) -> ProjectAttributeRecord:
        return ProjectAttributeRecord(
            attribute_id=str(row.get("ATTRIBUTE_ID") or ""),
            project_id=str(row.get("PROJECT_ID") or ""),
            project_name=str(row.get("PROJECT_NAME") or "") or None,
            attribute_name=str(row.get("ATTRIBUTE_NAME") or ""),
            attribute_type=str(row.get("ATTRIBUTE_TYPE") or "VARCHAR"),
            attribute_value=str(row.get("ATTRIBUTE_VALUE") or ""),
            source_project_id=str(row.get("SOURCE_PROJECT_ID") or "") or None,
            source_project_name=str(row.get("SOURCE_PROJECT_NAME") or "") or None,
            source_attribute_id=str(row.get("SOURCE_ATTRIBUTE_ID") or "") or None,
            status=str(row.get("STATUS") or "ACTIVE"),
            created_by=str(row.get("CREATED_BY") or "") or None,
            updated_by=str(row.get("UPDATED_BY") or "") or None,
            created_at=row.get("CREATED_AT"),
            updated_at=row.get("UPDATED_AT"),
        )

    def _project_link_from_row(self, row: dict[str, Any]) -> ProjectPrecedentLinkRecord:
        return ProjectPrecedentLinkRecord(
            project_link_id=str(row.get("PROJECT_LINK_ID") or ""),
            project_id=str(row.get("PROJECT_ID") or ""),
            precedent_project_id=str(row.get("PRECEDENT_PROJECT_ID") or ""),
            status=str(row.get("STATUS") or "active"),
            priority=int(row.get("PRIORITY") or 50),
            knowledge_categories=self._coerce_json(row.get("KNOWLEDGE_CATEGORIES"), []),
            allow_project_specific_values=bool(row.get("ALLOW_PROJECT_SPECIFIC_VALUES")),
            precedent_project_name=str(row.get("PRECEDENT_PROJECT_NAME") or "") or None,
            created_by=str(row.get("CREATED_BY") or "") or None,
            created_at=row.get("CREATED_AT"),
            updated_at=row.get("UPDATED_AT"),
        )

    def _mapping_link_from_row(self, row: dict[str, Any]) -> MappingPrecedentLinkRecord:
        return MappingPrecedentLinkRecord(
            mapping_link_id=str(row.get("MAPPING_LINK_ID") or ""),
            sttm_id=str(row.get("STTM_ID") or ""),
            precedent_sttm_id=str(row.get("PRECEDENT_STTM_ID") or ""),
            status=str(row.get("STATUS") or "active"),
            priority=int(row.get("PRIORITY") or 75),
            knowledge_categories=self._coerce_json(row.get("KNOWLEDGE_CATEGORIES"), []),
            target_compatibility=str(row.get("TARGET_COMPATIBILITY") or "") or None,
            mapping_lifecycle=str(row.get("MAPPING_LIFECYCLE") or "") or None,
            purpose=str(row.get("PURPOSE") or "") or None,
            confidence=float(row.get("CONFIDENCE") or 1.0),
            allow_project_specific_values=bool(row.get("ALLOW_PROJECT_SPECIFIC_VALUES")),
            precedent_project_id=str(row.get("PRECEDENT_PROJECT_ID") or "") or None,
            precedent_sttm_name=str(row.get("PRECEDENT_STTM_NAME") or "") or None,
            precedent_target_table=str(row.get("PRECEDENT_TARGET_TABLE") or "") or None,
            precedent_status=str(row.get("PRECEDENT_STATUS") or "") or None,
            created_by=str(row.get("CREATED_BY") or "") or None,
            created_at=row.get("CREATED_AT"),
            updated_at=row.get("UPDATED_AT"),
        )

    def _sttm_from_row(self, row: dict[str, Any], *, mapping_counts: dict[str, Any]) -> STTMRecord:
        total = int(mapping_counts.get("MAPPING_COUNT") or 0)
        mapped = int(mapping_counts.get("MAPPED_COUNT") or 0)
        metadata = self._coerce_json(row.get("STTM_METADATA"), {})
        draft = self._coerce_json(row.get("DRAFT_PAYLOAD"), {})
        target_table = (self._table_ref_to_fqn(draft.get("target_table"))
                        or str(row.get("TARGET_TABLE") or "").strip()
                        or str(metadata.get("physical_target_fqn") or "").strip())
        return STTMRecord(
            sttm_id=str(row.get("STTM_ID") or ""),
            project_id=str(row.get("PROJECT_ID") or ""),
            sttm_name=str(row.get("STTM_NAME") or "") or None,
            description=str(row.get("DESCRIPTION") or "") or None,
            target_table=target_table or None,
            current_version=int(row.get("CURRENT_VERSION") or 0),
            has_unpublished_draft=bool(row.get("HAS_UNPUBLISHED_DRAFT")),
            status=str(row.get("STATUS") or "DRAFT"),
            semantic_bundle_id=str(row.get("SEMANTIC_BUNDLE_ID") or "") or None,
            semantic_bundle_hash=str(row.get("SEMANTIC_BUNDLE_HASH") or "") or None,
            last_snapshot_id=str(row.get("LAST_SNAPSHOT_ID") or "") or None,
            created_at=row.get("CREATED_DATETIME"),
            updated_at=row.get("LAST_MODIFIED_DATETIME"),
            mapping_count=total,
            mapped_count=mapped,
            coverage_percent=round((mapped / total) * 100, 2) if total else 0,
            metadata=metadata,
        )

    def _semantic_bundle_id(self, snapshot: dict[str, Any]) -> str | None:
        bundle = snapshot.get("semantic_bundle") if isinstance(snapshot.get("semantic_bundle"), dict) else {}
        semantic = snapshot.get("semantic") if isinstance(snapshot.get("semantic"), dict) else {}
        return str(bundle.get("bundle_id") or semantic.get("bundle_id") or "") or None

    def _semantic_bundle_hash(self, snapshot: dict[str, Any]) -> str | None:
        bundle = snapshot.get("semantic_bundle") if isinstance(snapshot.get("semantic_bundle"), dict) else {}
        semantic = snapshot.get("semantic") if isinstance(snapshot.get("semantic"), dict) else {}
        return str(bundle.get("bundle_hash") or semantic.get("bundle_hash") or "") or None

    @staticmethod
    def _complete_table_refs(values: list[Any]) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        seen: set[str] = set()
        for value in values:
            if isinstance(value, dict):
                parts = [str(value.get(key) or "").strip() for key in ("database", "schema", "table")]
                alias = value.get("alias")
            else:
                parts = [part.strip().strip('"') for part in str(value or "").split(".")]
                alias = None
            if len(parts) != 3 or not all(parts) or parts[0].startswith("sql-cte:"):
                continue
            key = ".".join(parts).upper()
            if key in seen:
                continue
            seen.add(key)
            refs.append({"database": parts[0], "schema": parts[1], "table": parts[2], "alias": alias})
        return refs

    def _persistable_source_tables(self, snapshot: dict[str, Any]) -> list[dict[str, Any]]:
        """Physical sources to persist; never blank rows, never an empty set by accident.

        Uploaded workspaces can carry their physical inputs only on derived
        sources. When no complete top-level source exists, those inputs are the
        mapping's sources rather than an empty list that erases them.
        """
        raw_tables = snapshot.get("source_tables") if isinstance(snapshot.get("source_tables"), list) else []
        complete = self._complete_table_refs(raw_tables)
        if len(complete) < len(raw_tables):
            increment("autosave.sources.incomplete_ref_skipped", amount=len(raw_tables) - len(complete))
        if complete:
            return complete
        derived_inputs: list[Any] = []
        for derived in snapshot.get("derived_sources") or []:
            if isinstance(derived, dict):
                derived_inputs.extend(derived.get("base_source_tables") or [])
                derived_inputs.extend(derived.get("table_ids") or [])
        return self._complete_table_refs(derived_inputs)

    def _replace_sources(self, sttm_id: str, snapshot: dict[str, Any], *, user_id: str | None) -> int:
        source_tables = self._persistable_source_tables(snapshot)
        derived_sources = snapshot.get("derived_sources") if isinstance(snapshot.get("derived_sources"), list) else []
        if not self._settings.sttm_source_bulk_write_v1:
            return self._replace_sources_legacy(
                sttm_id, source_tables, derived_sources, user_id=user_id
            )
        source_columns = self._table_columns(self._sources_table)
        delete_suffix = " AND IS_DRAFT = TRUE" if source_columns and "IS_DRAFT" in source_columns else ""
        self._session.sql(
            f"DELETE FROM {self._sources_table} WHERE TO_VARCHAR(STTM_ID) = ?{delete_suffix}",
            params=[sttm_id],
        ).collect()
        rows: list[dict[str, Any]] = []
        for index, table in enumerate(source_tables, start=1):
            rows.append(
                {
                    "sttm_id": sttm_id,
                    "source_name": str(
                        table.get("alias") or table.get("table") or f"source_{index}"
                    ),
                    "database_name": str(table.get("database") or ""),
                    "schema_name": str(table.get("schema") or ""),
                    "table_name": str(table.get("table") or ""),
                    "description": self._table_ref_to_fqn(table),
                    "is_draft": True,
                    "actor_user_id": str(user_id or ""),
                }
            )
        for index, derived in enumerate(derived_sources, start=1):
            if isinstance(derived, dict):
                rows.append(
                    {
                        "sttm_id": sttm_id,
                        "source_name": str(
                            derived.get("name") or derived.get("id") or f"derived_{index}"
                        ),
                        "database_name": "",
                        "schema_name": "",
                        "table_name": "",
                        "description": "DERIVED_SOURCE:" + str(derived.get("id") or ""),
                        "is_draft": True,
                        "actor_user_id": str(user_id or ""),
                    }
                )
        if not rows:
            increment("autosave.sources.bulk_statement", amount=1)
            return 0

        expression_by_column = {
            "STTM_ID": "f.value:sttm_id::STRING",
            "SOURCE_NAME": "f.value:source_name::STRING",
            "DATABASE_NAME": "f.value:database_name::STRING",
            "SCHEMA_NAME": "f.value:schema_name::STRING",
            "TABLE_NAME": "f.value:table_name::STRING",
            "DESCRIPTION": "f.value:description::STRING",
            "IS_DRAFT": "COALESCE(f.value:is_draft::BOOLEAN, TRUE)",
            "ACTOR_USER_ID": "f.value:actor_user_id::STRING",
            "CREATED_DATETIME": "CURRENT_TIMESTAMP()",
            "LAST_MODIFIED_DATETIME": "CURRENT_TIMESTAMP()",
        }
        actor_type = self._column_type(self._sources_table, "LAST_MODIFIED_BY")
        if actor_type.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT")):
            expression_by_column["LAST_MODIFIED_BY"] = (
                "TRY_TO_NUMBER(f.value:actor_user_id::STRING)"
            )
        else:
            expression_by_column["LAST_MODIFIED_BY"] = (
                "f.value:actor_user_id::STRING"
            )
        writable_columns = [
            column
            for column in expression_by_column
            if not source_columns or column in source_columns
        ]
        payload_json = json.dumps(
            self._normalize_json_value(rows), default=str, allow_nan=False
        )
        self._session.sql(
            f"INSERT INTO {self._sources_table} ({', '.join(writable_columns)}) "
            f"SELECT {', '.join(expression_by_column[column] for column in writable_columns)} "
            "FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) f",
            params=[payload_json],
        ).collect()
        increment("autosave.sources.bulk_statement", amount=2)
        observe("autosave.sources.bulk_payload.bytes", len(payload_json.encode("utf-8")))
        return len(rows)

    def _replace_sources_legacy(
        self,
        sttm_id: str,
        source_tables: list[dict[str, Any]],
        derived_sources: list[Any],
        *,
        user_id: str | None,
    ) -> int:
        source_columns = self._table_columns(self._sources_table)
        if source_columns and "IS_DRAFT" in source_columns:
            self._session.sql(
                f"DELETE FROM {self._sources_table} WHERE STTM_ID = {self._quote_literal(sttm_id)} AND IS_DRAFT = TRUE"
            ).collect()
        else:
            self._session.sql(
                f"DELETE FROM {self._sources_table} WHERE STTM_ID = {self._quote_literal(sttm_id)}"
            ).collect()
        count = 0
        for index, table in enumerate(source_tables, start=1):
            name = self._table_ref_to_fqn(table)
            self._insert_existing_columns(
                self._sources_table,
                {
                    "STTM_ID": self._quote_literal(sttm_id),
                    "SOURCE_NAME": self._quote_literal(str(table.get("alias") or table.get("table") or f"source_{index}")),
                    "DATABASE_NAME": self._quote_literal(str(table.get("database") or "")),
                    "SCHEMA_NAME": self._quote_literal(str(table.get("schema") or "")),
                    "TABLE_NAME": self._quote_literal(str(table.get("table") or "")),
                    "DESCRIPTION": self._quote_literal(name),
                    "IS_DRAFT": "TRUE",
                    **self._actor_column_values(self._sources_table, user_id),
                },
            )
            count += 1
        for index, derived in enumerate(derived_sources, start=1):
            if not isinstance(derived, dict):
                continue
            self._insert_existing_columns(
                self._sources_table,
                {
                    "STTM_ID": self._quote_literal(sttm_id),
                    "SOURCE_NAME": self._quote_literal(str(derived.get("name") or derived.get("id") or f"derived_{index}")),
                    "DESCRIPTION": self._quote_literal("DERIVED_SOURCE:" + str(derived.get("id") or "")),
                    "IS_DRAFT": "TRUE",
                    **self._actor_column_values(self._sources_table, user_id),
                },
            )
            count += 1
        return count

    @staticmethod
    def _draft_row_metadata(row: dict[str, Any]) -> dict[str, Any]:
        # Explicit recovery fields only: client approval/publication flags are not evidence.
        fields = (
            "expression", "target_sql_name", "target_ordinal", "source_type", "source_dependencies",
            "value_binding_ids", "manually_saved", "manually_edited_after_auto_map", "description_edited",
            "learning_origin", "draft_issues", "reconciliation_warnings", "proposed_sql_source",
            "unmatched_reason", "candidate_source_attributes", "transformation_classification",
            "precedent_decision", "precedent_mapping_id", "override_evidence",
            "used_inference_ids", "used_recommendation_ids", "used_learning_ids",
        )
        return {field: row[field] for field in fields if field in row}

    def _replace_mapping_rows(
        self,
        *,
        project_id: str,
        sttm_id: str,
        snapshot: dict[str, Any],
        session_id: str | None,
        semantic_bundle_id: str | None,
        semantic_bundle_hash: str | None,
        user_id: str | None,
    ) -> int:
        rows = snapshot.get("mapping_rows") if isinstance(snapshot.get("mapping_rows"), list) else []
        attribute_columns = self._table_columns(self._attributes_table)
        if attribute_columns and "IS_DRAFT" in attribute_columns:
            self._session.sql(
                f"""
                DELETE FROM {self._attributes_table}
                WHERE STTM_ID = {self._quote_literal(sttm_id)}
                  AND COALESCE(IS_DRAFT, FALSE) = TRUE
                """
            ).collect()
        else:
            self._session.sql(
                f"DELETE FROM {self._attributes_table} WHERE STTM_ID = {self._quote_literal(sttm_id)}"
            ).collect()
        if self._settings.sttm_mapping_bulk_write_v1:
            return self._insert_mapping_rows_bulk(
                project_id=project_id,
                sttm_id=sttm_id,
                rows=rows,
                snapshot=snapshot,
                session_id=session_id,
                semantic_bundle_id=semantic_bundle_id,
                semantic_bundle_hash=semantic_bundle_hash,
                user_id=user_id,
                attribute_columns=attribute_columns,
            )
        for item in rows:
            if not isinstance(item, dict):
                continue
            source_columns = item.get("source_columns") or []
            if isinstance(source_columns, list):
                source_column_text = ", ".join(str(value) for value in source_columns if value)
            else:
                source_column_text = str(source_columns or "")
            mapping_mode_raw = str(item.get("mapping_mode") or "source").lower()
            mapping_mode = (
                mapping_mode_raw
                if mapping_mode_raw in {"constant", "attribute"}
                else "source"
            )
            constant_value = item.get("constant_value")
            attribute_name = item.get("attribute_name")
            from app.core.mapping_contracts import mapping_transformation_text
            transformation_logic = mapping_transformation_text(item)
            self._insert_existing_columns(
                self._attributes_table,
                {
                    "STTM_ID": self._quote_literal(sttm_id),
                    "ATTRIBUTE_NAME": self._quote_literal(str(item.get("target_column") or "")),
                    "ATTRIBUTE_TYPE": self._quote_literal("TRANSFORMED" if transformation_logic else "RAW"),
                    # Legacy environments may define SOURCE_COLUMN as a short
                    # VARCHAR. The complete list remains authoritative in
                    # CONDITION.source_columns below.
                    "SOURCE_COLUMN": self._quote_text_for_column(
                        self._attributes_table,
                        "SOURCE_COLUMN",
                        source_column_text,
                    ),
                    "DATA_TYPE": self._quote_literal(str(item.get("target_type") or item.get("target_data_type") or "")),
                    "TRANSFORMATION_LOGIC": self._quote_literal(str(transformation_logic)),
                    "DESCRIPTION": self._quote_literal(item.get("description") or ""),
                    "CONDITION": "PARSE_JSON(" + self._quote_literal(json.dumps(self._normalize_json_value({
                        "mapping_row_id": str(item.get("id") or item.get("mapping_row_id") or uuid.uuid4()),
                        "project_id": project_id,
                        "session_id": session_id or "",
                        "target_table": self._table_ref_to_fqn(snapshot.get("target_table")),
                        "source_columns": source_columns,
                        "source_expressions": item.get("source_expressions") or [],
                        "mapping_mode": mapping_mode,
                        "constant_value": constant_value,
                        "attribute_name": attribute_name,
                        "preprocessing_rule": item.get("rule") or item.get("preprocessing_rule") or "",
                        "natural_language_rule": item.get("natural_language_rule") or "",
                        "load_order": item.get("load_order"),
                        "status": item.get("status") or "draft",
                        "confidence": item.get("confidence"),
                        "confidence_reason": item.get("confidence_reason") or "",
                        "alternatives": item.get("alternatives") or [],
                        "ai_candidates": item.get("ai_candidates") or [],
                        "ai_suggestions": item.get("ai_suggestions") or [],
                        "validation": item.get("validation"),
                        "selected_ai_candidate_id": item.get("selected_ai_candidate_id"),
                        "ai_review_status": item.get("ai_review_status"),
                        "ai_undo_snapshot": item.get("ai_undo_snapshot"),
                        "agent_artifact_id": item.get("agent_artifact_id") or "",
                        "semantic_bundle_id": semantic_bundle_id or "",
                        "semantic_bundle_hash": semantic_bundle_hash or "",
                        "fir_context_key": item.get("fir_context_key") or "",
                        **self._draft_row_metadata(item),
                    }), default=str, allow_nan=False).replace("\\", "\\\\")) + ")",
                    "CALCULATION": "PARSE_JSON(" + self._json_literal(item.get("calculation") or {}) + ")",
                    "MEASURE": "PARSE_JSON(" + self._json_literal(item.get("measure") or {}) + ")",
                    "AGGREGATION": "PARSE_JSON(" + self._json_literal(item.get("aggregation") or {}) + ")",
                    "IS_DRAFT": "TRUE",
                    **self._actor_column_values(self._attributes_table, user_id),
                },
            )
        return len([item for item in rows if isinstance(item, dict)])

    def _insert_mapping_rows_bulk(
        self,
        *,
        project_id: str,
        sttm_id: str,
        rows: list[Any],
        snapshot: dict[str, Any],
        session_id: str | None,
        semantic_bundle_id: str | None,
        semantic_bundle_hash: str | None,
        user_id: str | None,
        attribute_columns: set[str],
    ) -> int:
        """Persist a mapping revision with one bound, set-based Snowflake insert."""

        normalized: list[dict[str, Any]] = []
        source_column_type = self._column_type(self._attributes_table, "SOURCE_COLUMN")
        size_match = re.search(r"(?:VAR)?CHAR\s*\(\s*(\d+)\s*\)", source_column_type)
        source_column_limit = int(size_match.group(1)) if size_match else None
        target_table = self._table_ref_to_fqn(snapshot.get("target_table"))
        for item in rows:
            if not isinstance(item, dict):
                continue
            source_columns = item.get("source_columns") or []
            if isinstance(source_columns, list):
                source_column_text = ", ".join(str(value) for value in source_columns if value)
            else:
                source_column_text = str(source_columns or "")
            if source_column_limit is not None:
                source_column_text = source_column_text[:source_column_limit]
            mapping_mode_raw = str(item.get("mapping_mode") or "source").lower()
            mapping_mode = mapping_mode_raw if mapping_mode_raw in {"constant", "attribute"} else "source"
            constant_value = item.get("constant_value")
            from app.core.mapping_contracts import mapping_transformation_text
            transformation_logic = mapping_transformation_text(item)
            normalized.append(
                {
                    "sttm_id": sttm_id,
                    "attribute_name": str(item.get("target_column") or ""),
                    "attribute_type": "TRANSFORMED" if transformation_logic else "RAW",
                    "source_column": source_column_text,
                    "data_type": str(item.get("target_type") or item.get("target_data_type") or ""),
                    "transformation_logic": str(transformation_logic),
                    "description": str(item.get("description") or ""),
                    "condition": {
                        "mapping_row_id": str(item.get("id") or item.get("mapping_row_id") or uuid.uuid4()),
                        "project_id": project_id,
                        "session_id": session_id or "",
                        "target_table": target_table,
                        "source_columns": source_columns,
                        "source_expressions": item.get("source_expressions") or [],
                        "mapping_mode": mapping_mode,
                        "constant_value": constant_value,
                        "attribute_name": item.get("attribute_name"),
                        "preprocessing_rule": item.get("rule") or item.get("preprocessing_rule") or "",
                        "natural_language_rule": item.get("natural_language_rule") or "",
                        "load_order": item.get("load_order"),
                        "status": item.get("status") or "draft",
                        "confidence": item.get("confidence"),
                        "confidence_reason": item.get("confidence_reason") or "",
                        "alternatives": item.get("alternatives") or [],
                        "ai_candidates": item.get("ai_candidates") or [],
                        "ai_suggestions": item.get("ai_suggestions") or [],
                        "validation": item.get("validation"),
                        "selected_ai_candidate_id": item.get("selected_ai_candidate_id"),
                        "ai_review_status": item.get("ai_review_status"),
                        "ai_undo_snapshot": item.get("ai_undo_snapshot"),
                        "agent_artifact_id": item.get("agent_artifact_id") or "",
                        "semantic_bundle_id": semantic_bundle_id or "",
                        "semantic_bundle_hash": semantic_bundle_hash or "",
                        "fir_context_key": item.get("fir_context_key") or "",
                        **self._draft_row_metadata(item),
                    },
                    "calculation": item.get("calculation") or {},
                    "measure": item.get("measure") or {},
                    "aggregation": item.get("aggregation") or {},
                    "is_draft": True,
                    "actor_user_id": str(user_id or ""),
                }
            )
        if not normalized:
            increment("autosave.mappings.bulk_statement", amount=1)
            return 0

        expressions = {
            "STTM_ID": "f.value:sttm_id::STRING",
            "ATTRIBUTE_NAME": "f.value:attribute_name::STRING",
            "ATTRIBUTE_TYPE": "f.value:attribute_type::STRING",
            "SOURCE_COLUMN": "f.value:source_column::STRING",
            "DATA_TYPE": "f.value:data_type::STRING",
            "TRANSFORMATION_LOGIC": "f.value:transformation_logic::STRING",
            "DESCRIPTION": "f.value:description::STRING",
            "CONDITION": "f.value:condition",
            "CALCULATION": "f.value:calculation",
            "MEASURE": "f.value:measure",
            "AGGREGATION": "f.value:aggregation",
            "IS_DRAFT": "COALESCE(f.value:is_draft::BOOLEAN, TRUE)",
            "ACTOR_USER_ID": "f.value:actor_user_id::STRING",
        }
        actor_type = self._column_type(self._attributes_table, "LAST_MODIFIED_BY")
        expressions["LAST_MODIFIED_BY"] = (
            "TRY_TO_NUMBER(f.value:actor_user_id::STRING)"
            if actor_type.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT"))
            else "f.value:actor_user_id::STRING"
        )
        writable_columns = [
            column for column in expressions if not attribute_columns or column in attribute_columns
        ]
        payload_json = json.dumps(
            self._normalize_json_value(normalized), default=str, allow_nan=False
        )
        self._session.sql(
            f"INSERT INTO {self._attributes_table} ({', '.join(writable_columns)}) "
            f"SELECT {', '.join(expressions[column] for column in writable_columns)} "
            "FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) f",
            params=[payload_json],
        ).collect()
        increment("autosave.mappings.bulk_statement", amount=2)
        observe("autosave.mappings.bulk_payload.bytes", len(payload_json.encode("utf-8")))
        return len(normalized)

    def _record_agent_artifacts(
        self,
        *,
        project_id: str,
        sttm_id: str,
        payload: STTMAutosaveRequest,
        snapshot: dict[str, Any],
        user_id: str | None,
        semantic_bundle_id: str | None,
        semantic_bundle_hash: str | None,
    ) -> int:
        artifacts = list(payload.agent_artifacts or [])
        artifacts.extend(snapshot.get("mapping_artifacts") or [])
        count = 0
        for artifact in artifacts:
            if not isinstance(artifact, dict):
                continue
            artifact_id = self._memory.record_agent_artifact(
                request_id=str(artifact.get("request_id") or ""),
                session_id=payload.session_id or str(snapshot.get("session_id") or ""),
                thread_id=payload.thread_id or str(snapshot.get("thread_id") or ""),
                agent_name=str(artifact.get("agent_name") or artifact.get("agent") or "unknown_agent"),
                artifact_type=str(artifact.get("artifact_type") or artifact.get("type") or "agent_artifact"),
                payload={**artifact, "project_id": project_id, "sttm_id": sttm_id},
                artifact_status=str(artifact.get("artifact_status") or artifact.get("status") or "draft"),
                entity_type=str(artifact.get("entity_type") or "sttm"),
                entity_ids=[project_id, sttm_id, *[str(v) for v in artifact.get("entity_ids", []) if v]],
                semantic_bundle_id=semantic_bundle_id,
                semantic_bundle_hash=semantic_bundle_hash,
                summary=str(artifact.get("summary") or ""),
                created_by=user_id,
                context_key=str(snapshot.get("context_key") or artifact.get("context_key") or ""),
                snapshot_id=str(snapshot.get("snapshot_id") or artifact.get("snapshot_id") or ""),
                retrieved_inference_ids=[
                    str(value) for value in (artifact.get("retrieved_inference_ids") or []) if value
                ],
                retrieved_recommendation_ids=[
                    str(value) for value in (artifact.get("retrieved_recommendation_ids") or []) if value
                ],
                used_inference_ids=[
                    str(value) for value in (artifact.get("used_inference_ids") or []) if value
                ],
                used_recommendation_ids=[
                    str(value) for value in (artifact.get("used_recommendation_ids") or []) if value
                ],
            )
            artifact["artifact_id"] = artifact_id
            count += 1
        return count

    def _record_autosave_fir_events(
        self,
        *,
        project_id: str,
        sttm_id: str,
        payload: STTMAutosaveRequest,
        snapshot: dict[str, Any],
        previous_snapshot: dict[str, Any] | None,
        user_id: str | None,
        strict: bool = False,
    ) -> int:
        events = [
            event
            for event in (payload.fir_events or [])
            if isinstance(event, dict)
            and str(event.get("event_type") or "").strip().lower()
            in self._MEANINGFUL_AUTOSAVE_FIR_EVENTS
        ]
        from app.core.learning_evidence import manual_mapping_decisions

        for decision in manual_mapping_decisions(
            snapshot, previous_snapshot, project_id=project_id, sttm_id=sttm_id, actor_id=user_id,
        ):
            receipt = decision["receipt"]
            events.append({
                "event_type": f"mapping.{receipt['stage']}", "entity_type": "mapping_row",
                "entity_ids": [project_id, sttm_id], "request_id": receipt["request_id"],
                "event_payload": {"learning_evidence": receipt, "target_column": receipt["target_column"],
                                  "before": decision["before"], "after": decision["after"],
                                  "scope_hash": decision["scope_hash"]},
            })
        def validation_key(value: dict[str, Any]) -> str:
            return self._snapshot_hash(value)

        prior_validation_keys = {
            validation_key(validation)
            for validation in (previous_snapshot or {}).get("validation_history") or []
            if isinstance(validation, dict)
        }
        new_validations = [
            validation
            for validation in snapshot.get("validation_history") or []
            if isinstance(validation, dict)
            and validation_key(validation) not in prior_validation_keys
        ]
        current_validation_cursor = str(
            snapshot.get("validation_cursor")
            or self._snapshot_hash(
                {
                    "sttm_id": sttm_id,
                    "validation_keys": sorted(
                        prior_validation_keys
                        | {
                            validation_key(validation)
                            for validation in new_validations
                        }
                    ),
                }
            )
        )
        previous_validation_cursor = str(
            (previous_snapshot or {}).get("validation_cursor")
            or self._snapshot_hash(
                {
                    "sttm_id": sttm_id,
                    "validation_keys": sorted(prior_validation_keys),
                }
            )
        )
        action = str(payload.action or "").strip().lower()
        explicit_event_types = {
            str(event.get("event_type") or "").strip().lower()
            for event in events
        }
        if (
            action in self._MEANINGFUL_AUTOSAVE_FIR_EVENTS
            and action not in explicit_event_types
            and (not action.startswith("sql.validation_") or not new_validations)
        ):
            events.append(
                {
                    "event_type": action,
                    "entity_type": "sttm",
                    "entity_ids": [project_id, sttm_id],
                    "event_payload": {
                        "project_id": project_id,
                        "sttm_id": sttm_id,
                        "context_hash": snapshot.get("context_hash"),
                        "mapping_count": len(snapshot.get("mapping_rows") or []),
                        "source_count": len(snapshot.get("source_tables") or []),
                        "derived_source_count": len(snapshot.get("derived_sources") or []),
                    },
                }
            )
        for validation in new_validations:
            # The UI records a mapping_sql_validation receipt only after Compile &
            # Validate succeeds; it is never a failure even without "valid".
            passed = validation.get("valid") is True or (
                str(validation.get("kind") or "").lower() == "mapping_sql_validation"
                and validation.get("valid") is not False
            )
            status = "sql.validation_passed" if passed else "sql.validation_failed"
            events.append(
                {
                    "event_type": status,
                    "entity_type": "validation",
                    "entity_ids": [project_id, sttm_id],
                    "event_payload": {
                        **validation,
                        "validation_cursor": current_validation_cursor,
                        "previous_validation_cursor": previous_validation_cursor,
                    },
                }
            )
        count = 0
        for event in events:
            if not isinstance(event, dict):
                continue
            event_type = str(event.get("event_type") or "").strip().lower()
            event_payload = (
                event.get("event_payload")
                if isinstance(event.get("event_payload"), dict)
                else event
            )
            request_id = str(event.get("request_id") or "")
            if not request_id:
                request_id = "fir-autosave-" + self._snapshot_hash(
                    {
                        "event_type": event_type,
                        "project_id": project_id,
                        "sttm_id": sttm_id,
                        "event_payload": event_payload,
                    }
                )[:32]
            self._record_fir(
                event_type=event_type,
                user_id=user_id,
                session_id=payload.session_id or str(snapshot.get("session_id") or ""),
                request_id=request_id,
                page=str(snapshot.get("page") or event.get("page") or ""),
                surface=str(snapshot.get("surface") or event.get("surface") or ""),
                entity_type=str(event.get("entity_type") or "sttm"),
                entity_ids=[str(v) for v in event.get("entity_ids", [project_id, sttm_id]) if v],
                payload=event_payload,
                context_key=str(snapshot.get("context_key") or ""),
                snapshot_id=str(snapshot.get("snapshot_id") or ""),
                milestone=str(snapshot.get("milestone") or payload.action or ""),
                strict=strict,
            )
            count += 1
        return count

    def _record_fir(
        self,
        *,
        event_type: str,
        user_id: str | None,
        session_id: str | None,
        request_id: str | None,
        page: str | None,
        surface: str | None,
        entity_type: str | None,
        entity_ids: list[str] | None,
        payload: dict[str, Any] | None,
        context_key: str | None = None,
        snapshot_id: str | None = None,
        milestone: str | None = None,
        strict: bool = False,
    ) -> str | None:
        try:
            return self._memory.record_fir_event(
                event_type=event_type,
                user_id=user_id,
                session_id=session_id,
                request_id=request_id,
                page=page,
                surface=surface,
                entity_type=entity_type,
                entity_ids=entity_ids,
                event_payload=payload,
                context_key=context_key,
                snapshot_id=snapshot_id,
                milestone=milestone,
            )
        except Exception as exc:  # pragma: no cover - FIR should not block save/publish
            logger.warning("Failed to record FIR event %s: %s", event_type, exc)
            if strict:
                raise

    def _record_agent_learnings(
        self,
        *,
        project_id: str,
        sttm_id: str,
        snapshot: dict[str, Any],
        user_id: str | None,
        strict: bool = False,
    ) -> int:
        """Record only explicit corrections, accepted rows, and trusted imports.

        ``ai_suggested`` describes origin, not acceptance. Treating it as user
        approval pollutes FIR with every unreviewed proposal and causes later
        mappings to reinforce an agent's own mistakes.
        """
        mapping_rows = snapshot.get("mapping_rows") or []
        if not isinstance(mapping_rows, list):
            return 0

        target_table = self._table_ref_to_fqn(snapshot.get("target_table"))
        source_tables = [
            self._table_ref_to_fqn(table)
            for table in self._snapshot_tables(snapshot, "source_tables")
            if self._table_ref_to_fqn(table)
        ]
        count = 0
        for row in mapping_rows:
            if not isinstance(row, dict):
                continue

            status = str(row.get("status") or "").lower()
            confidence = float(row.get("confidence") or 0.0)
            target_column = str(
                row.get("target_column")
                or row.get("target_attribute")
                or row.get("attribute_name")
                or ""
            )
            provenance = str(row.get("provenance") or "").strip().lower()
            is_historical_precedent = provenance in {
                "historical_import",
                "published_mapping",
                "client_asset_import",
            }
            is_accepted = bool(row.get("accepted")) or is_historical_precedent

            if not target_column or status != "mapped":
                continue

            # Corrections always outrank acceptance and precedent evidence.
            if row.get("was_corrected"):
                incorrect_source = self._extract_source_columns(row.get("original_source") or {})
                correct_source = self._extract_source_columns(row)
                error_category = str(row.get("correction_category") or "manual_edit")
                prevention_hint = str(row.get("correction_reason") or "User corrected the AI suggestion")

                try:
                    self._agent_learning.record_mapping_correction(
                        target_column=target_column,
                        incorrect_source=incorrect_source,
                        correct_source=correct_source,
                        error_category=error_category,
                        prevention_hint=prevention_hint,
                        project_id=project_id,
                        sttm_id=sttm_id,
                        user_id=user_id,
                        strict=strict,
                    )
                    count += 1
                except Exception as exc:
                    logger.debug("Failed to record mapping correction learning: %s", exc)
                    if strict:
                        raise
                continue

            if is_accepted:
                source_columns = self._extract_source_columns(row)
                preprocessing_rule = str(
                    row.get("preprocessing_rule")
                    or row.get("rule")
                    or row.get("expression")
                    or row.get("natural_language_rule")
                    or row.get("source_expression")
                    or ""
                )
                preprocessing_rule_type = str(
                    row.get("preprocessing_rule_type")
                    or ("Historical" if is_historical_precedent else "Direct")
                )

                try:
                    self._agent_learning.record_mapping_acceptance(
                        target_column=target_column,
                        source_columns=source_columns,
                        preprocessing_rule=preprocessing_rule,
                        preprocessing_rule_type=preprocessing_rule_type,
                        confidence_score=confidence,
                        project_id=project_id,
                        sttm_id=sttm_id,
                        user_id=user_id,
                        target_table=target_table or None,
                        source_tables=source_tables,
                        provenance=provenance or None,
                        strict=strict,
                    )
                    count += 1
                except Exception as exc:
                    logger.debug("Failed to record mapping acceptance learning: %s", exc)
                    if strict:
                        raise

        return count

    def _record_target_mapping_patterns(
        self,
        *,
        project_id: str,
        sttm_id: str,
        snapshot: dict[str, Any],
        evidence_class: str,
        validation_status: str,
        base_confidence: float,
        strict: bool = False,
        publication_version_id: str | None = None,
    ) -> int:
        """Persist one reusable, typed FIR pattern for each trusted mapping row.

        This deliberately runs after deterministic mapping persistence. Agent
        enrichment may resume later, but accepted/corrected/published evidence
        is immediately available for target-column retrieval.
        """
        if not self._settings.fir_target_mapping_patterns_v2:
            return 0
        rows = snapshot.get("mapping_rows")
        if not isinstance(rows, list):
            return 0
        target_table = self._table_ref_to_fqn(snapshot.get("target_table"))
        source_tables = [
            self._table_ref_to_fqn(item)
            for item in self._snapshot_tables(snapshot, "source_tables")
            if self._table_ref_to_fqn(item)
        ]
        # Capture contracts from the immutable published/validated snapshot,
        # never from a later mutable draft or inferred from a column's name.
        source_profiles: dict[tuple[str, ...], dict[str, Any]] = {}
        for node in (snapshot.get("relation_graph") or {}).get("nodes") or []:
            if not isinstance(node, dict):
                continue
            relation_names = [node.get("alias"), self._table_ref_to_fqn(node.get("table"))]
            for relation_name in dict.fromkeys(filter(None, relation_names)):
                for profile in semantic_column_profiles(relation_name, node):
                    source_profiles[column_identity(profile["physical_name"])] = profile
        trusted_rows: list[dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            status = str(row.get("status") or "").lower()
            if status not in {"mapped", "accepted", "complete", "published"}:
                continue
            target_column = str(
                row.get("target_column")
                or row.get("target_attribute")
                or row.get("attribute_name")
                or ""
            ).strip()
            if not target_column:
                continue
            expression = published_expression(row)
            attribute_name = str(row.get("attribute_name") or "").lstrip("$")
            if not expression and row.get("mapping_mode") == "attribute" and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", attribute_name):
                expression = f"${attribute_name}"
            trusted_rows.append(
                {
                    **row,
                    "target_alias": target_column,
                    "target_table": target_table,
                    "source_columns": self._extract_source_columns(row),
                    "source_column_profiles": [
                        source_profiles.get(column_identity(column), next((
                            profile for profile in row.get("source_column_profiles") or []
                            if isinstance(profile, dict) and column_identity(profile.get("physical_name")) == column_identity(column)
                        ), {"physical_name": column}))
                        for column in self._extract_source_columns(row)
                    ],
                    "transformation": expression,
                    "constant_value": expression if row.get("mapping_mode") == "attribute" and re.fullmatch(r"\$[A-Za-z_][A-Za-z0-9_]*", expression) else row.get("constant_value"),
                    "field_definition": (
                        row.get("natural_language_rule")
                        or row.get("description")
                        or row.get("business_rationale")
                    ),
                }
            )
        if not trusted_rows:
            return 0
        snapshot_hash = self._snapshot_hash(
            {
                "target_table": target_table,
                "source_tables": source_tables,
                "mapping_rows": trusted_rows,
                "relationships": snapshot.get("relationships") or [],
                "derived_sources": snapshot.get("derived_sources") or [],
            }
        )
        asset_id = f"sttm_{sttm_id}_{snapshot_hash[:20]}"
        if evidence_class == "published_mapping":
            project_context = {
                key: snapshot.get(key)
                for key in ("project_name", "project_description", "project_domain", "project_outcome", "source_system_key", "logical_target_table_key")
                if snapshot.get(key) is not None
            }
        else:
            project_context = self._project_business_context(project_id) if project_id else {}
        filters = snapshot.get("filters") or snapshot.get("query_shaping_rules") or []
        population_rules = ([{"rule_type": "saved_population", "population_contract": filters}]
                            if isinstance(filters, dict) else [item for item in filters if isinstance(item, dict)])
        parsed_document = {
            "target_table": target_table,
            "logical_target_key": optional_identifier(
                ((snapshot.get("mapping_intent") or {}).get("logical_target_key")
                 if isinstance(snapshot.get("mapping_intent"), dict) else "")
                or snapshot.get("logical_target_table_key")
            ),
            "source_tables": source_tables,
            "source_system": (
                str((snapshot.get("mapping_intent") or {}).get("source_system_key") or "")
                if isinstance(snapshot.get("mapping_intent"), dict)
                else ""
            ) or str(project_context.get("source_system_key") or "").upper()
            or self._infer_source_vendor(source_tables),
            "project_context": {
                key: value for key, value in project_context.items() if key != "source_system_key"
            },
            "entity_meaning": snapshot.get("mapping_intent"),
            "column_mappings": trusted_rows,
            "join_patterns": snapshot.get("relationships") or [],
            "ctes": snapshot.get("derived_sources") or [],
            "business_rules": population_rules,
        }
        try:
            service = TargetMappingPatternService(self._session, self._settings)
            extracted = service.extract_document_patterns(
                asset_id=asset_id,
                project_id=project_id,
                parsed_document=parsed_document,
                evidence_class=evidence_class,
                base_confidence=base_confidence,
            )
            if strict and len(extracted) != len(trusted_rows):
                raise ValueError("Learning projection did not capture every mapped row; published snapshot remains available for retry.")
            sql_artifacts = {
                key: hashlib.sha256(str(snapshot[key]).encode("utf-8")).hexdigest()
                for key in ("raw_mapping_sql", "mapping_sql", "compiled_mapping_sql", "compiled_mapping_script_sql")
                if snapshot.get(key)
            }
            patterns = [
                pattern.model_copy(
                    update={
                        "sttm_id": sttm_id,
                        "validation_status": validation_status,
                        "provenance": {
                            **pattern.provenance,
                            "sttm_id": sttm_id,
                            "evidence_class": evidence_class,
                            "snapshot_id": snapshot.get("snapshot_id"),
                            "publication_version_id": publication_version_id,
                            "published_at": snapshot.get("published_at") or snapshot.get("published_datetime"),
                            "publication_capture_id": (snapshot.get("_publication_capture") or {}).get("id"),
                            "sql_artifact_hashes": sql_artifacts,
                        },
                        "evidence_ids": sorted(
                            {*pattern.evidence_ids, sttm_id,
                             *([publication_version_id] if publication_version_id else []),
                             *([str(snapshot["snapshot_id"])] if snapshot.get("snapshot_id") else [])}
                        ),
                    }
                )
                for pattern in extracted
            ]
            count = service.upsert_patterns(patterns)
            if evidence_class == "published_mapping" and publication_version_id:
                service.supersede_published_patterns(sttm_id=sttm_id, publication_version_id=publication_version_id)
            if self._settings.fir_durable_jobs_v2:
                service.create_learning_job(
                    asset_id=asset_id,
                    project_id=project_id,
                    patterns=patterns,
                )
            return count
        except Exception as exc:  # FIR learning must never block user saves.
            logger.warning(
                "Failed to record target-column patterns for STTM %s: %s",
                sttm_id,
                exc,
            )
            if strict:
                raise
            return 0

    def _record_learned_relationships(self, *, sttm_id: str, snapshot: dict[str, Any], strict: bool = False) -> int:
        """Remember the physical joins of a published mapping for Add Join."""
        relationships = [
            item for item in snapshot.get("relationships") or [] if isinstance(item, dict)
        ]
        if not relationships:
            return 0
        try:
            return RelationshipLearningService(self._session, self._settings).record(
                relationships,
                evidence_class="published_mapping",
                support_key=f"sttm:{sttm_id}",
                strict=strict,
            )
        except Exception as exc:  # Learning must never block a publish.
            logger.warning("Failed to record learned joins for STTM %s: %s", sttm_id, exc)
            if strict:
                raise
            return 0

    @staticmethod
    def _infer_source_vendor(source_tables: list[str]) -> str | None:
        joined = " ".join(source_tables).upper()
        for vendor in (
            "HUBSPOT",
            "REDTAIL",
            "EVERNEST",
            "SALESFORCE",
            "WEALTHBOX",
            "ADDEPAR",
            "ORION",
            "TAMARAC",
        ):
            if vendor in joined:
                return vendor
        return None

    def _extract_source_columns(self, row: dict[str, Any] | Any) -> list[str]:
        """Extract source columns from a mapping row or source object."""
        if not isinstance(row, dict):
            return []

        source_cols = row.get("source_columns") or row.get("source_column") or row.get("source_expression")
        if source_cols is None:
            return []

        if isinstance(source_cols, list):
            return [str(c) for c in source_cols if c]
        if isinstance(source_cols, str):
            try:
                parsed = json.loads(source_cols)
                if isinstance(parsed, list):
                    return [str(c) for c in parsed if c]
            except (json.JSONDecodeError, TypeError):
                pass
            if source_cols:
                return [source_cols]
        return []

    def _build_fir_features(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        mapping_rows = snapshot.get("mapping_rows") if isinstance(snapshot.get("mapping_rows"), list) else []
        confidence_values = [
            float(row.get("confidence"))
            for row in mapping_rows
            if isinstance(row, dict) and row.get("confidence") is not None
        ]
        return {
            "source_count": len(snapshot.get("source_tables") or []),
            "derived_source_count": len(snapshot.get("derived_sources") or []),
            "relationship_count": len(snapshot.get("relationships") or []),
            "mapping_count": len(mapping_rows),
            "mapped_count": len(
                [
                    row
                    for row in mapping_rows
                    if isinstance(row, dict)
                    and str(row.get("status") or "").lower() in {"mapped", "accepted", "complete"}
                ]
            ),
            "average_confidence": round(sum(confidence_values) / len(confidence_values), 4)
            if confidence_values
            else None,
            "semantic_bundle_hash": self._semantic_bundle_hash(snapshot),
            "has_sql": bool(snapshot.get("mapping_sql") or snapshot.get("mapping_preview_sql")),
        }

    def _latest_snapshot(
        self,
        sttm_id: str,
        *,
        snapshot_id: str | None = None,
    ) -> dict[str, Any] | None:
        try:
            snapshot_filter = (
                f"AND SNAPSHOT_ID = {self._quote_literal(snapshot_id)}"
                if snapshot_id
                else ""
            )
            rows = self._session.sql(
                f"""
                SELECT SNAPSHOT_ID, SNAPSHOT_PAYLOAD, RAW_MAPPING_SQL, PARSED_MAPPING_MODEL
                FROM {self._snapshots_table}
                WHERE STTM_ID = {self._quote_literal(sttm_id)}
                  {snapshot_filter}
                ORDER BY CREATED_AT DESC
                LIMIT 1
                """
            ).collect()
            if not rows:
                return None
            row = rows[0].as_dict()
            snapshot = self._coerce_json(row.get("SNAPSHOT_PAYLOAD"), {})
            # Keep the immutable columns authoritative. Older payload JSON can
            # predate these fields even when the migrated snapshot row has
            # already been backfilled with the original SQL/model.
            raw_mapping_sql = str(row.get("RAW_MAPPING_SQL") or "")
            if raw_mapping_sql:
                snapshot["raw_mapping_sql"] = raw_mapping_sql
                snapshot.setdefault("mapping_sql", raw_mapping_sql)
            parsed_mapping_model = self._coerce_json(row.get("PARSED_MAPPING_MODEL"), {})
            if parsed_mapping_model:
                snapshot["parsed_mapping_model"] = parsed_mapping_model
            snapshot["snapshot_id"] = str(row.get("SNAPSHOT_ID") or "")
            return snapshot
        except Exception as exc:
            logger.warning("Latest snapshot unavailable for STTM %s: %s", sttm_id, exc)
            return None

    def _list_sources(self, sttm_id: str) -> list[dict[str, Any]]:
        try:
            order_by = self._order_by_expr(
                self._sources_table,
                ["SOURCE_ID", "SOURCE_NAME", "TABLE_NAME"],
                "STTM_ID",
            )
            rows = self._session.sql(
                f"""
                SELECT *
                FROM {self._sources_table}
                WHERE STTM_ID = {self._quote_literal(sttm_id)}
                ORDER BY {order_by}
                """
            ).collect()
            return [row.as_dict() for row in rows]
        except Exception as exc:
            logger.warning("STTM sources unavailable for %s: %s", sttm_id, exc)
            return []

    def _list_mapping_rows(self, sttm_id: str) -> list[dict[str, Any]]:
        try:
            attribute_columns = self._table_columns(self._attributes_table)
            if attribute_columns and "STTM_ID" not in attribute_columns:
                return []
            order_by = self._order_by_expr(
                self._attributes_table,
                ["ATTRIBUTE_NAME", "ATTRIBUTE_ID"],
                "STTM_ID",
            )
            if not attribute_columns or {"IS_DRAFT", "EFFECTIVE_THROUGH_VERSION"}.issubset(attribute_columns):
                current_attributes_sql = f"""
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE TO_VARCHAR(a.STTM_ID) = {self._quote_literal(sttm_id)}
                      AND COALESCE(a.IS_DRAFT, FALSE) = TRUE
                    UNION ALL
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE TO_VARCHAR(a.STTM_ID) = {self._quote_literal(sttm_id)}
                      AND COALESCE(a.IS_DRAFT, FALSE) = FALSE
                      AND a.EFFECTIVE_THROUGH_VERSION IS NULL
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {self._attributes_table} d
                          WHERE TO_VARCHAR(d.STTM_ID) = TO_VARCHAR(a.STTM_ID)
                            AND COALESCE(d.IS_DRAFT, FALSE) = TRUE
                      )
                """
            else:
                current_attributes_sql = f"""
                    SELECT a.*
                    FROM {self._attributes_table} a
                    WHERE TO_VARCHAR(a.STTM_ID) = {self._quote_literal(sttm_id)}
                """
            rows = self._session.sql(
                f"""
                WITH CURRENT_ATTRIBUTES AS (
{current_attributes_sql}
                )
                SELECT *
                FROM CURRENT_ATTRIBUTES
                ORDER BY {order_by}
                """
            ).collect()
            mapping_rows: list[dict[str, Any]] = []
            for row in rows:
                data = row.as_dict()
                condition = self._coerce_json(data.get("CONDITION"), {})
                source_columns = condition.get("source_columns")
                if not isinstance(source_columns, list):
                    source_text = str(data.get("SOURCE_COLUMN") or "")
                    source_columns = [part.strip() for part in source_text.split(",") if part.strip()]
                mapping_rows.append(
                    {
                        "id": str(condition.get("mapping_row_id") or data.get("ATTRIBUTE_ID") or ""),
                        "mapping_row_id": str(condition.get("mapping_row_id") or data.get("ATTRIBUTE_ID") or ""),
                        "target_column": str(data.get("ATTRIBUTE_NAME") or ""),
                        "target_type": str(data.get("DATA_TYPE") or "") or None,
                        "source_columns": source_columns,
                        "mapping_mode": str(condition.get("mapping_mode") or "source"),
                        "constant_value": condition.get("constant_value"),
                        "attribute_name": condition.get("attribute_name"),
                        "rule": str(condition.get("preprocessing_rule") or "") or None,
                        "expression": (
                            None
                            if str(condition.get("mapping_mode") or "source") in {"constant", "attribute"}
                            else str(data.get("TRANSFORMATION_LOGIC") or "") or None
                        ),
                        "natural_language_rule": str(condition.get("natural_language_rule") or "") or None,
                        "description": str(data.get("DESCRIPTION") or "") or None,
                        "load_order": condition.get("load_order"),
                        "status": str(condition.get("status") or ("mapped" if source_columns or data.get("TRANSFORMATION_LOGIC") else "draft")),
                        "confidence": condition.get("confidence"),
                        "confidence_reason": condition.get("confidence_reason"),
                        "alternatives": condition.get("alternatives") if isinstance(condition.get("alternatives"), list) else [],
                        "ai_candidates": condition.get("ai_candidates") or [],
                        "ai_suggestions": condition.get("ai_suggestions") or [],
                        "validation": condition.get("validation"),
                        "selected_ai_candidate_id": condition.get("selected_ai_candidate_id"),
                        "ai_review_status": condition.get("ai_review_status"),
                        "ai_undo_snapshot": condition.get("ai_undo_snapshot"),
                        "agent_artifact_id": condition.get("agent_artifact_id"),
                        "semantic_bundle_id": condition.get("semantic_bundle_id"),
                        "semantic_bundle_hash": condition.get("semantic_bundle_hash"),
                        "attribute_id": str(data.get("ATTRIBUTE_ID") or ""),
                        **self._draft_row_metadata(condition),
                    }
                )
            return mapping_rows
        except Exception as exc:
            logger.warning("STTM attributes unavailable for %s: %s", sttm_id, exc)
            return []

    def _list_versions(self, sttm_id: str) -> list[dict[str, Any]]:
        try:
            order_by = self._order_by_expr(
                self._versions_table,
                ["VERSION_NUMBER", "VERSION_ID", "PUBLISHED_DATETIME"],
                "STTM_ID",
            )
            rows = self._session.sql(
                f"""
                SELECT *
                FROM {self._versions_table}
                WHERE STTM_ID = {self._quote_literal(sttm_id)}
                ORDER BY {order_by} DESC
                """
            ).collect()
            return [row.as_dict() for row in rows]
        except Exception as exc:
            logger.warning("STTM versions unavailable for %s: %s", sttm_id, exc)
            return []

    def _list_artifacts(self, sttm_id: str) -> list[dict[str, Any]]:
        try:
            rows = self._session.sql(
                f"""
                SELECT *
                FROM {self._artifacts_table}
                WHERE ARRAY_CONTAINS({self._quote_literal(sttm_id)}::VARIANT, ENTITY_IDS)
                   OR PAYLOAD:sttm_id::STRING = {self._quote_literal(sttm_id)}
                ORDER BY CREATED_AT DESC
                LIMIT 100
                """
            ).collect()
            return [
                {
                    **row.as_dict(),
                    "PAYLOAD": self._coerce_json(row.as_dict().get("PAYLOAD"), {}),
                    "ENTITY_IDS": self._coerce_json(row.as_dict().get("ENTITY_IDS"), []),
                }
                for row in rows
            ]
        except Exception as exc:
            logger.warning("Agent artifacts unavailable for STTM %s: %s", sttm_id, exc)
            return []

    def _reviewed_mapping_predicate(self, alias: str) -> str:
        """SQL predicate excluding unreviewed Deep Agent drafts from precedent evidence.

        A run-owned draft is the agent's own proposal. Until a person publishes
        it, reusing it as a precedent would let the agent learn from its own
        unverified output.
        """
        if not self._has_column(self._sttm_table, "AGENT_EXTERNAL_KEY"):
            return "TRUE"
        return (f"(COALESCE({alias}.AGENT_EXTERNAL_KEY, '') NOT LIKE 'deep-draft:%' "
                f"OR UPPER(COALESCE({alias}.STATUS, '')) IN ('PUBLISHED', 'COMPLETE'))")


    def find_output_equivalent_mappings(
        self, *, target_columns: list[str], limit: int = 5, min_share: float = 0.5,
    ) -> list[dict[str, Any]]:
        """Earlier mappings whose SQL produces most of these target columns, whatever their target table.

        Target tables were often not recorded on older mappings; the columns a
        mapping's SQL outputs identify what it built. Counts a column when its
        name appears quoted or as an ``AS`` alias in the saved SQL.
        """
        columns = sorted({str(value).strip('"').upper() for value in target_columns if str(value or "").strip()})
        if not columns:
            return []
        rows = self._session.sql(
            f"""WITH cols AS (SELECT VALUE::STRING C FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))),
                     sttm AS (SELECT s.STTM_ID, TO_VARCHAR(s.PROJECT_ID) PROJECT_ID, s.STTM_NAME,
                                     UPPER(COALESCE(s.STATUS, '')) STATUS, UPPER(s.RAW_MAPPING_SQL) SQL_TEXT
                              FROM {self._sttm_table} s
                              WHERE LENGTH(TRIM(COALESCE(s.RAW_MAPPING_SQL, ''))) > 0
                                AND {self._reviewed_mapping_predicate('s')}
                                AND COALESCE(s.STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED'))
                SELECT sttm.STTM_ID, sttm.PROJECT_ID, sttm.STTM_NAME, sttm.STATUS, COUNT(*) COVERED
                FROM sttm JOIN cols ON CONTAINS(sttm.SQL_TEXT, '"' || cols.C || '"')
                                    OR CONTAINS(sttm.SQL_TEXT, ' AS ' || cols.C)
                GROUP BY 1, 2, 3, 4
                HAVING COUNT(*) >= ?
                ORDER BY COVERED DESC, IFF(sttm.STATUS IN ('PUBLISHED', 'COMPLETE'), 0, 1), sttm.STTM_ID DESC
                LIMIT ?""",
            [json.dumps(columns), max(1, int(len(columns) * min_share)), max(1, min(int(limit), 20))],
        ).collect()
        return [{"sttm_id": str(data["STTM_ID"]), "project_id": str(data["PROJECT_ID"]),
                 "sttm_name": data.get("STTM_NAME"), "status": data.get("STATUS"),
                 "covered_target_columns": int(data.get("COVERED") or 0), "target_column_count": len(columns)}
                for data in (row.as_dict() if hasattr(row, "as_dict") else dict(row) for row in rows)]


    def find_precedent_projects(
        self, *, target_tables: list[str], source_tables: list[str], terms: list[str], limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Rank earlier projects by how much of the current migration they already cover.

        Signals, strongest first: an exact target table, a target with the same
        name in another schema, source tables with the same names (a copy of
        the same source system for another client), and project name or
        description words. Only caller-visible metadata rows are read; the
        returned reasons say which signal matched.
        """
        def leaves(values: list[str]) -> list[str]:
            return sorted({str(value).strip('"').rsplit(".", 1)[-1].upper() for value in values if str(value or "").strip()})

        targets = sorted({str(value).strip('"').upper() for value in target_tables if str(value or "").strip()})
        words = sorted({str(value).strip().upper() for value in terms if len(str(value or "").strip()) >= 3})[:24]
        if not targets and not source_tables and not words:
            return []
        rows = self._session.sql(
            f"""WITH sttm AS (
                    SELECT TO_VARCHAR(s.PROJECT_ID) PROJECT_ID, s.STTM_ID, UPPER(COALESCE(s.TARGET_TABLE, '')) TARGET,
                           UPPER(COALESCE(s.STATUS, '')) STATUS,
                           IFF(LENGTH(TRIM(COALESCE(s.RAW_MAPPING_SQL, ''))) > 0, 1, 0) HAS_SQL
                    FROM {self._sttm_table} s
                    WHERE COALESCE(s.STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED')
                      AND {self._reviewed_mapping_predicate('s')}),
                sources AS (
                    SELECT DISTINCT so.STTM_ID, UPPER(so.TABLE_NAME) LEAF FROM {self._sources_table} so
                    WHERE ARRAY_CONTAINS(TO_VARIANT(UPPER(so.TABLE_NAME)), PARSE_JSON(?))),
                scored AS (
                    SELECT sttm.PROJECT_ID,
                           MAX(IFF(ARRAY_CONTAINS(TO_VARIANT(sttm.TARGET), PARSE_JSON(?)), 1, 0)) EXACT_TARGET,
                           MAX(IFF(ARRAY_CONTAINS(TO_VARIANT(SPLIT_PART(sttm.TARGET, '.', -1)), PARSE_JSON(?)), 1, 0)) SAME_TARGET_NAME,
                           COUNT(DISTINCT sources.LEAF) SHARED_SOURCES,
                           MAX(IFF(sttm.STATUS IN ('PUBLISHED', 'COMPLETE'), 1, 0)) PUBLISHED,
                           SUM(sttm.HAS_SQL) MAPPINGS_WITH_SQL,
                           COUNT(DISTINCT sttm.STTM_ID) MAPPINGS
                    FROM sttm LEFT JOIN sources ON sources.STTM_ID = sttm.STTM_ID
                    GROUP BY sttm.PROJECT_ID),
                projects AS (
                    SELECT TO_VARCHAR(p.PROJECT_ID) PROJECT_ID, p.PROJECT_NAME,
                           UPPER(COALESCE(p.PROJECT_NAME, '') || ' ' || COALESCE(p.DESCRIPTION, '')) TEXT
                    FROM {self._projects_table} p WHERE COALESCE(p.STATUS, 'ACTIVE') <> 'ARCHIVED'),
                text_hits AS (
                    SELECT projects.PROJECT_ID, COUNT(*) TEXT_HITS
                    FROM projects, TABLE(FLATTEN(INPUT => PARSE_JSON(?))) w
                    WHERE CONTAINS(projects.TEXT, w.VALUE::STRING) GROUP BY projects.PROJECT_ID)
                SELECT scored.*, projects.PROJECT_NAME, COALESCE(text_hits.TEXT_HITS, 0) TEXT_HITS
                FROM scored JOIN projects ON projects.PROJECT_ID = scored.PROJECT_ID
                LEFT JOIN text_hits ON text_hits.PROJECT_ID = scored.PROJECT_ID
                WHERE scored.EXACT_TARGET + scored.SAME_TARGET_NAME + scored.SHARED_SOURCES
                      + COALESCE(text_hits.TEXT_HITS, 0) > 0
                -- Many historical projects are unfinished experiments: among equal
                -- structural matches, completed work (published or with SQL) ranks first.
                ORDER BY EXACT_TARGET DESC, SAME_TARGET_NAME DESC, SHARED_SOURCES DESC, PUBLISHED DESC,
                         MAPPINGS_WITH_SQL DESC, TEXT_HITS DESC, scored.PROJECT_ID DESC
                LIMIT ?""",
            [json.dumps(leaves(source_tables)), json.dumps(targets), json.dumps(leaves(targets)), json.dumps(words),
             max(1, min(int(limit), 50))],
        ).collect()
        ranked = []
        for row in rows:
            data = row.as_dict() if hasattr(row, "as_dict") else dict(row)
            reasons = [reason for reason, present in (
                ("exact target table", data.get("EXACT_TARGET")),
                ("same target table name in another schema", data.get("SAME_TARGET_NAME")),
                (f"{data.get('SHARED_SOURCES')} source table(s) with the same names", data.get("SHARED_SOURCES")),
                (f"{data.get('TEXT_HITS')} request word(s) in the project name or description", data.get("TEXT_HITS")),
                ("has published mappings", data.get("PUBLISHED")),
                (f"{data.get('MAPPINGS_WITH_SQL')} mapping(s) with executable SQL", data.get("MAPPINGS_WITH_SQL")),
            ) if present]
            ranked.append({"project_id": str(data["PROJECT_ID"]), "project_name": data.get("PROJECT_NAME"),
                           "mapping_count": int(data.get("MAPPINGS") or 0),
                           "mappings_with_sql": int(data.get("MAPPINGS_WITH_SQL") or 0),
                           "published": bool(data.get("PUBLISHED")),
                           "exact_target": bool(data.get("EXACT_TARGET")),
                           "shared_source_tables": int(data.get("SHARED_SOURCES") or 0),
                           "reasons": reasons})
        return ranked


    def find_target_precedent_projects(self, target_table: str, *, limit: int = 20) -> list[str]:
        """Read exact-target precedent identities under the delegated Snowflake role."""
        rows = self._session.sql(
            f"""SELECT TO_VARCHAR(PROJECT_ID) PROJECT_ID FROM {self._sttm_table} s
                WHERE UPPER(TARGET_TABLE)=UPPER(?) AND COALESCE(STATUS,'ACTIVE') <> 'ARCHIVED'
                  AND {self._reviewed_mapping_predicate('s')}
                GROUP BY TO_VARCHAR(PROJECT_ID)
                ORDER BY MIN(CASE WHEN UPPER(COALESCE(STATUS,'')) IN ('PUBLISHED','COMPLETE')
                                  THEN 0 ELSE 1 END), PROJECT_ID DESC
                LIMIT ?""", [target_table, max(1,min(limit,100))]
        ).collect()
        return [str(row["PROJECT_ID"]) for row in rows]


    def firm_value_holders(self, names: list[str], *, limit: int = 500) -> list[dict[str, Any]]:
        """Active firm values with these names in any project (names compared letters and digits only)."""
        keys = sorted({re.sub(r"[^A-Z0-9]", "", str(value).upper()) for value in names if str(value or "").strip()})
        if not keys:
            return []
        self.ensure_storage_exists()
        rows = self._session.sql(
            f"""SELECT TO_VARCHAR(a.PROJECT_ID) PROJECT_ID, p.PROJECT_NAME, a.ATTRIBUTE_ID, a.ATTRIBUTE_NAME,
                       a.ATTRIBUTE_TYPE, a.ATTRIBUTE_VALUE
                FROM {self._project_attributes_table} a
                JOIN {self._projects_table} p ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(a.PROJECT_ID)
                WHERE ARRAY_CONTAINS(TO_VARIANT(REGEXP_REPLACE(UPPER(a.ATTRIBUTE_NAME), '[^A-Z0-9]', '')), PARSE_JSON(?))
                  AND COALESCE(a.STATUS, 'ACTIVE') = 'ACTIVE' AND COALESCE(p.STATUS, 'ACTIVE') <> 'ARCHIVED'
                LIMIT ?""",
            [json.dumps(keys), max(1, min(int(limit), 5000))],
        ).collect()
        return [row.as_dict() if hasattr(row, "as_dict") else dict(row) for row in rows]


    def firm_value_usages(self, target_columns: list[str], *, limit: int = 500) -> dict[str, list[dict[str, Any]]]:
        """Earlier mapping rows that bind these target columns to a firm value.

        A row binds a firm value when it is an ``attribute`` row or its rule
        names ``$Name``. Target columns match by name with separators ignored,
        so ``Transaction_Firm__c`` matches ``TRANSACTION_FIRM__C``. Unreviewed
        agent drafts are excluded. ``values`` holds the active firm values of
        the projects those rows belong to (their names and values, per project).
        """
        names = sorted({re.sub(r"[^A-Z0-9]", "", str(value).upper()) for value in target_columns if str(value or "").strip()})
        if not names:
            return {"usages": [], "values": []}
        usages = self._session.sql(
            f"""SELECT TO_VARCHAR(s.PROJECT_ID) PROJECT_ID, p.PROJECT_NAME, TO_VARCHAR(s.STTM_ID) STTM_ID,
                       UPPER(COALESCE(s.STATUS, '')) STATUS, r.value:target_column::STRING TARGET_COLUMN,
                       r.value:mapping_mode::STRING MAPPING_MODE, r.value:attribute_name::STRING ATTRIBUTE_NAME,
                       r.value:constant_value::STRING CONSTANT_VALUE, r.value:expression::STRING EXPRESSION
                FROM {self._sttm_table} s
                JOIN {self._projects_table} p ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(s.PROJECT_ID),
                     LATERAL FLATTEN(INPUT => s.DRAFT_PAYLOAD:mapping_rows) r
                WHERE COALESCE(s.STATUS, 'DRAFT') NOT IN ('SUPERSEDED', 'IMPORTING', 'IMPORT_FAILED', 'ARCHIVED')
                  AND COALESCE(p.STATUS, 'ACTIVE') <> 'ARCHIVED'
                  AND {self._reviewed_mapping_predicate('s')}
                  AND ARRAY_CONTAINS(TO_VARIANT(REGEXP_REPLACE(UPPER(r.value:target_column::STRING), '[^A-Z0-9]', '')),
                                     PARSE_JSON(?))
                  AND (r.value:mapping_mode::STRING = 'attribute'
                       OR CONTAINS(COALESCE(r.value:expression::STRING, ''), '$')
                       OR STARTSWITH(COALESCE(r.value:constant_value::STRING, ''), '$'))
                ORDER BY s.STTM_ID DESC
                LIMIT ?""",
            [json.dumps(names), max(1, min(int(limit), 2000))],
        ).collect()
        usage_rows = [row.as_dict() if hasattr(row, "as_dict") else dict(row) for row in usages]
        projects = sorted({str(row["PROJECT_ID"]) for row in usage_rows})
        values: list[dict[str, Any]] = []
        if projects:
            self.ensure_storage_exists()
            attributes = self._session.sql(
                f"""SELECT TO_VARCHAR(a.PROJECT_ID) PROJECT_ID, p.PROJECT_NAME, a.ATTRIBUTE_ID, a.ATTRIBUTE_NAME,
                           a.ATTRIBUTE_TYPE, a.ATTRIBUTE_VALUE
                    FROM {self._project_attributes_table} a
                    JOIN {self._projects_table} p ON TO_VARCHAR(p.PROJECT_ID) = TO_VARCHAR(a.PROJECT_ID)
                    WHERE ARRAY_CONTAINS(TO_VARIANT(TO_VARCHAR(a.PROJECT_ID)), PARSE_JSON(?))
                      AND COALESCE(a.STATUS, 'ACTIVE') = 'ACTIVE' AND a.ATTRIBUTE_NAME IS NOT NULL""",
                [json.dumps(projects)],
            ).collect()
            values = [row.as_dict() if hasattr(row, "as_dict") else dict(row) for row in attributes]
        return {"usages": usage_rows, "values": values}
