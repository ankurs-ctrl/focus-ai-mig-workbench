export type PublishProjectItem = {
  id: string;
  name: string;
  mappingCount: number;
  folderColor: string;
  folderBg: string;
};

export type PublishSaveTab = "existing" | "new" | "none";

/** Default empty list. Callers should pass projects from `projectService`. */
export const PUBLISH_PROJECT_OPTIONS: PublishProjectItem[] = [];
