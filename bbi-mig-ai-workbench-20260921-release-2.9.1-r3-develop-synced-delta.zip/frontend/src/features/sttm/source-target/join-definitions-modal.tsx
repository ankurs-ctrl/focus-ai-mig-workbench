"use client";

import { useEffect, useMemo, useState } from "react";
import { AiaBox, AiaTooltip } from "@/components/ui";
import { AiaButton } from "@/components/ui/aia-button";
import { AiaChip } from "@/components/ui/aia-chip";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import type { JoinConfig, TableMeta } from "@/features/sttm/types/sttm.types";
import {
  AddIcon,
  AllInclusiveIcon,
  DeleteOutlinedIcon,
  EditOutlinedIcon,
} from "@/utils/icons";
import { WorkspaceRemoveConfirmDialog } from "./workspace-remove-confirm-dialog";

type JoinType = NonNullable<JoinConfig["joinType"]>;
type JoinDefinitionsTab = "driving" | "joins" | "recommendations";
type RecommendationBand = "HIGH" | "MEDIUM" | "LOW";

type JoinDefinitionsModalProps = {
  isOpen: boolean;
  onClose: () => void;
  joins: JoinConfig[];
  tables: TableMeta[];
  recommendations?: JoinConfig[];
  onCreateJoin: () => void;
  onEditJoin: (join: JoinConfig) => void;
  onDeleteJoin: (joinId: string) => void;
  /** Add a recommended join into the Joins tab immediately. */
  onAcceptRecommendation?: (join: JoinConfig) => void;
  /** Names the table pair when opened from a bundled canvas edge. */
  filterLabel?: string;
  onClearFilter?: () => void;
  /**
   * Join id → CTE name for joins that live inside a CTE. Those joins belong to
   * the shared CTE library, so they are listed read-only here and stay editable
   * in the CTE editor, which also rewrites the CTE SQL and saves it.
   */
  cteOriginById?: Record<string, string>;
  /** Splits the list: joins that touch this table are listed under Driving Joins. */
  drivingTableId?: string | null;
};

const JOIN_TYPE_COLORS: Record<JoinType, { bg: string; fg: string }> = {
  INNER: { bg: "#111827", fg: "#ffffff" },
  LEFT: { bg: "#1e40af", fg: "#ffffff" },
  RIGHT: { bg: "#0d9488", fg: "#ffffff" },
  FULL: { bg: "#9333ea", fg: "#ffffff" },
};

const JOIN_TYPE_OPTIONS: JoinType[] = ["INNER", "LEFT", "RIGHT", "FULL"];

const RECOMMENDATION_GROUPS: Array<{ key: RecommendationBand; title: string }> = [
  { key: "HIGH", title: "High Confidence" },
  { key: "MEDIUM", title: "Medium Confidence" },
  { key: "LOW", title: "Low Confidence" },
];

function tableDisplayName(table: TableMeta | undefined): string {
  if (!table) return "Table";
  const schema = table.schema?.trim();
  const name = table.name?.trim() || "Table";
  return schema ? `${schema}.${name}` : name;
}

function resolveTableLabel(tables: TableMeta[], tableId?: string): string {
  if (!tableId) return "Table";
  const match = tables.find((table) => table.id === tableId);
  if (match) return tableDisplayName(match);
  return tableId;
}

function columnDisplayInfo(
  join: JoinConfig,
  side: "left" | "right",
): { column: string; extraCount: number } {
  const columns = (join.conditions ?? [])
    .map((condition) =>
      (side === "left" ? condition.leftColumn : condition.rightColumn)?.trim() ?? "",
    )
    .filter(Boolean);

  return {
    column: columns[0] || "—",
    extraCount: Math.max(0, columns.length - 1),
  };
}

function ColumnDisplayText({
  join,
  side,
}: {
  join: JoinConfig;
  side: "left" | "right";
}) {
  const { column, extraCount } = columnDisplayInfo(join, side);

  return (
    <AiaText sx={{ ...textStyleCssVars("body"), fontWeight: 600, mt: 0.25, ...wrapTextSx }}>
      {column}
      {extraCount > 0 ? (
        <AiaText
          component="span"
          sx={{
            ...textStyleCssVars("caption"),
            color: "#64748b",
            fontWeight: 500,
            ml: 0.5,
          }}
        >
          +{extraCount} {extraCount === 1 ? "other" : "others"}
        </AiaText>
      ) : null}
    </AiaText>
  );
}

function recommendationBand(join: JoinConfig): RecommendationBand {
  const score = join.confidence ?? 0;
  if (score >= 0.8) return "HIGH";
  if (score >= 0.6) return "MEDIUM";
  return "LOW";
}

function pickColumn(table: TableMeta | undefined, preferredNames: string[]): string {
  const columns = table?.columns ?? [];
  for (const preferred of preferredNames) {
    const match = columns.find(
      (column) => column.name?.toLowerCase() === preferred.toLowerCase(),
    );
    if (match?.name) return match.name;
  }
  return columns[0]?.name ?? "ID";
}

function buildMockRecommendations(tables: TableMeta[]): JoinConfig[] {
  if (tables.length < 2) {
    return [
      {
        id: "mock-rec-high-1",
        joinType: "INNER",
        leftTableId: tables[0]?.id ?? "SOURCE_A",
        rightTableId: tables[0]?.id ?? "SOURCE_B",
        source: "SEMANTIC_VIEW",
        reviewRequired: true,
        confidence: 0.92,
        reviewReason: "Strong semantic key match between related entities.",
        conditions: [
          { leftColumn: pickColumn(tables[0], ["ID", "AGENT_ID"]), operator: "=", rightColumn: "ID" },
        ],
      },
      {
        id: "mock-rec-medium-1",
        joinType: "LEFT",
        leftTableId: tables[0]?.id ?? "SOURCE_A",
        rightTableId: tables[0]?.id ?? "SOURCE_C",
        source: "SEMANTIC_VIEW",
        reviewRequired: true,
        confidence: 0.71,
        reviewReason: "Likely foreign-key style relationship from naming patterns.",
        conditions: [
          {
            leftColumn: pickColumn(tables[0], ["CREATED_BY", "USER_ID"]),
            operator: "=",
            rightColumn: pickColumn(tables[0], ["AGENT_ID", "ID"]),
          },
        ],
      },
      {
        id: "mock-rec-low-1",
        joinType: "FULL",
        leftTableId: tables[0]?.id ?? "SOURCE_A",
        rightTableId: tables[0]?.id ?? "SOURCE_D",
        source: "SEMANTIC_VIEW",
        reviewRequired: true,
        confidence: 0.48,
        reviewReason: "Weak overlap — review column mapping before accepting.",
        conditions: [
          {
            leftColumn: pickColumn(tables[0], ["NAME", "AGENT_NAME"]),
            operator: "=",
            rightColumn: pickColumn(tables[0], ["FULL_NAME", "NAME"]),
          },
        ],
      },
    ];
  }

  const pairs: Array<[TableMeta, TableMeta]> = [];
  for (let i = 0; i < tables.length; i += 1) {
    for (let j = i + 1; j < tables.length; j += 1) {
      pairs.push([tables[i], tables[j]]);
      if (pairs.length >= 6) break;
    }
    if (pairs.length >= 6) break;
  }

  const joinTypes: JoinType[] = ["INNER", "LEFT", "RIGHT", "FULL"];
  const scores = [0.94, 0.86, 0.74, 0.65, 0.52, 0.41];
  const reasons = [
    "Exact semantic key alignment detected.",
    "High-confidence foreign key pattern from column names.",
    "Moderate overlap on shared business keys.",
    "Possible relationship based on schema metadata.",
    "Low confidence — columns share naming tokens only.",
    "Weak candidate — verify join condition before use.",
  ];

  return pairs.map(([left, right], index) => {
    const leftColumn = pickColumn(left, ["ID", "AGENT_ID", "USER_ID", "CREATED_BY"]);
    const rightColumn = pickColumn(right, ["ID", "AGENT_ID", "USER_ID", "CREATED_BY"]);
    return {
      id: `mock-rec-${left.id}-${right.id}-${index}`,
      joinType: joinTypes[index % joinTypes.length],
      leftTableId: left.id,
      rightTableId: right.id,
      source: "SEMANTIC_VIEW" as const,
      reviewRequired: true,
      confidence: scores[index] ?? 0.5,
      reviewReason: reasons[index] ?? "Semantic join candidate.",
      conditions: [
        { leftColumn, operator: "=", rightColumn },
        ...(index % 2 === 0
          ? [
              {
                leftColumn: pickColumn(left, ["NAME", "AGENT_NAME", "CODE"]),
                operator: "=",
                rightColumn: pickColumn(right, ["NAME", "FULL_NAME", "CODE"]),
              },
            ]
          : []),
      ],
    };
  });
}

function isSameJoin(left: JoinConfig, right: JoinConfig): boolean {
  if (left.id && right.id && left.id === right.id) return true;
  return (
    left.leftTableId === right.leftTableId
    && left.rightTableId === right.rightTableId
    && (left.joinType ?? "INNER") === (right.joinType ?? "INNER")
  );
}

const closeButtonSx = {
  minWidth: 28,
  width: 28,
  height: 28,
  p: 0,
  color: "#94a3b8",
  border: "none",
  backgroundColor: "transparent",
  boxShadow: "none",
  "&:hover": {
    color: "#64748b",
    backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
  },
} as const;

const iconButtonSx = {
  minWidth: 32,
  width: 32,
  height: 32,
  p: 0,
  boxShadow: "none",
} as const;

const wrapTextSx = {
  display: "block",
  overflowWrap: "anywhere",
  wordBreak: "break-word",
  whiteSpace: "normal",
} as const;

const tableColumnBlockSx = {
  minWidth: 0,
  width: "100%",
  textAlign: "left" as const,
  bgcolor: "#f8fafc",
  border: "1px solid #eef2f7",
  borderRadius: "8px",
  px: 1.25,
  py: 0.85,
} as const;

function JoinRelationCard({
  join,
  index,
  tables,
  onEdit,
  onDelete,
  onAdd,
  showAddInsteadOfDelete = false,
  isAdded = false,
  cteSourceName,
}: {
  join: JoinConfig;
  index: number;
  tables: TableMeta[];
  onEdit: (join: JoinConfig) => void;
  onDelete?: (joinId: string) => void;
  onAdd?: (join: JoinConfig) => void;
  showAddInsteadOfDelete?: boolean;
  isAdded?: boolean;
  cteSourceName?: string;
}) {
  const joinType = (join.joinType ?? "INNER") as JoinType;
  const palette = JOIN_TYPE_COLORS[joinType];
  const leftLabel = resolveTableLabel(tables, join.leftTableId);
  const rightLabel = resolveTableLabel(tables, join.rightTableId);
  // A CTE owns its joins: editing one here would leave the CTE SQL and the
  // shared library copy behind, so the card is read-only and points at the CTE.
  const isFromCte = Boolean(cteSourceName);
  const actionsDisabled = (showAddInsteadOfDelete && isAdded) || isFromCte;
  const isFromRecommendation = join.source === "SEMANTIC_VIEW";
  // Origin chips use fixed palettes so every chip of a kind matches. The CTE
  // chip also carries the read-only story, which is why these rows need no
  // extra lock marker.
  const originLabel = isFromCte
    ? "Defined inside CTE"
    : isFromRecommendation
      ? "AI Suggested"
      : "User Created";
  const originPalette = isFromCte
    ? { bg: "#dcfce3", fg: "#166534" }
    : isFromRecommendation
      ? { bg: "#ede9fe", fg: "#5b21b6" }
      : { bg: "#e0f2fe", fg: "#0369a1" };
  const readOnlyHint = `This join is defined inside the CTE "${cteSourceName}". Open the CTE to edit or delete it.`;

  return (
    <AiaBox
      sx={{
        display: "grid",
        gridTemplateColumns: "28px minmax(0, 1fr) auto minmax(0, 1fr) auto",
        alignItems: "center",
        columnGap: 2,
        rowGap: 1.5,
        pl: 1.5,
        pr: 2,
        py: 1.25,
        border: `1px solid ${isFromCte ? "#d7f0e1" : "#e5e7eb"}`,
        borderRadius: "12px",
        bgcolor: isFromCte ? "#fbfefc" : actionsDisabled ? "#f8fafc" : "#fff",
        cursor: actionsDisabled ? "default" : "pointer",
        ...(actionsDisabled
          ? {}
          : {
              "&:hover": {
                borderColor: "#cbd5e1",
                bgcolor: "#f8fafc",
              },
            }),
      }}
      onClick={actionsDisabled ? undefined : () => onEdit(join)}
    >
      <AiaBox
        sx={{
          width: 24,
          height: 24,
          borderRadius: "50%",
          border: "1px solid #e2e8f0",
          color: "#475569",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 12,
          fontWeight: 600,
          bgcolor: "#fff",
        }}
      >
        {index + 1}
      </AiaBox>
      <AiaBox sx={tableColumnBlockSx}>
        <AiaText sx={{ ...textStyleCssVars("caption"), color: "#64748b", ...wrapTextSx }}>
          {leftLabel}
        </AiaText>
        <ColumnDisplayText join={join} side="left" />
      </AiaBox>
      <AiaBox
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 1.25,
          flexShrink: 0,
          px: 0.5,
        }}
      >
        <AiaBox
          sx={{
            px: 1.25,
            py: 0.35,
            borderRadius: 999,
            bgcolor: palette.bg,
            color: palette.fg,
            fontSize: 11,
            fontWeight: 700,
            letterSpacing: "0.04em",
            whiteSpace: "nowrap",
          }}
        >
          {joinType} JOIN
        </AiaBox>
        <AiaBox sx={{ width: 42, height: 2, bgcolor: "#2563eb", position: "relative" }}>
          <AiaBox
            sx={{
              position: "absolute",
              right: -1,
              top: "50%",
              width: 0,
              height: 0,
              borderTop: "4px solid transparent",
              borderBottom: "4px solid transparent",
              borderLeft: "6px solid #2563eb",
              transform: "translateY(-50%)",
            }}
          />
        </AiaBox>
        {isAdded ? (
          <AiaBox
            sx={{
              px: 1,
              py: 0.2,
              borderRadius: 999,
              bgcolor: "#dcfce7",
              color: "#166534",
              fontSize: 12,
              fontWeight: 500,
              letterSpacing: "0.05em",
              whiteSpace: "nowrap",
            }}
          >
            Added To Joins
          </AiaBox>
        ) : null}
        {!showAddInsteadOfDelete ? (
          <AiaTooltip
            title={isFromCte ? readOnlyHint : ""}
            placement="top"
            disableHoverListener={!isFromCte}
          >
            <AiaBox
              aria-label={isFromCte ? readOnlyHint : undefined}
              sx={{
                px: 1,
                py: 0.2,
                borderRadius: 999,
                bgcolor: originPalette.bg,
                color: originPalette.fg,
                fontSize: 12,
                fontWeight: 500,
                letterSpacing: "0.05em",
                whiteSpace: "nowrap",
                cursor: isFromCte ? "help" : "inherit",
              }}
            >
              {originLabel}
            </AiaBox>
          </AiaTooltip>
        ) : null}
      </AiaBox>
      <AiaBox sx={tableColumnBlockSx}>
        <AiaText sx={{ ...textStyleCssVars("caption"), color: "#64748b", ...wrapTextSx }}>
          {rightLabel}
        </AiaText>
        <ColumnDisplayText join={join} side="right" />
      </AiaBox>
        <AiaBox
          sx={{ display: "flex", alignItems: "center", gap: 0.75, flexShrink: 0, ml: 1.5 }}
          onClick={(event) => event.stopPropagation()}
        >
          {isFromCte ? null : showAddInsteadOfDelete ? (
            actionsDisabled ? null : (
              <>
                <AiaButton
                  variant="outlined"
                  size="small"
                  onClick={() => onAdd?.(join)}
                  sx={iconButtonSx}
                  customBorderColor="var(--aia-state-success-color, #16a34a)"
                  customColor="var(--aia-state-success-color, #16a34a)"
                  aria-label="Add recommendation as join"
                >
                  <AddIcon sx={{ fontSize: 18 }} />
                </AiaButton>
                <AiaButton
                  variant="outlined"
                  size="small"
                  onClick={() => onEdit(join)}
                  sx={iconButtonSx}
                  customBorderColor="#cbd5e1"
                  customColor="#475569"
                  aria-label="Edit join"
                >
                  <EditOutlinedIcon sx={{ fontSize: 16 }} />
                </AiaButton>
              </>
            )
          ) : (
            <>
              <AiaButton
                variant="outlined"
                size="small"
                onClick={() => onEdit(join)}
                sx={iconButtonSx}
                customBorderColor="#cbd5e1"
                customColor="#475569"
                aria-label="Edit join"
              >
                <EditOutlinedIcon sx={{ fontSize: 16 }} />
              </AiaButton>
              <AiaButton
                variant="outlined"
                size="small"
                onClick={() => join.id && onDelete?.(join.id)}
                sx={iconButtonSx}
                customBorderColor="var(--aia-state-error-color, #dc2626)"
                customColor="var(--aia-state-error-color, #dc2626)"
                aria-label="Delete join"
              >
                <DeleteOutlinedIcon sx={{ fontSize: 16 }} />
              </AiaButton>
            </>
          )}
        </AiaBox>
    </AiaBox>
  );
}

export function JoinDefinitionsModal({
  isOpen,
  onClose,
  joins,
  tables,
  recommendations = [],
  onCreateJoin,
  onEditJoin,
  onDeleteJoin,
  onAcceptRecommendation,
  filterLabel,
  onClearFilter,
  cteOriginById,
  drivingTableId,
}: JoinDefinitionsModalProps) {
  const [activeTab, setActiveTab] = useState<JoinDefinitionsTab>("driving");
  const [selectedJoinType, setSelectedJoinType] = useState<JoinType | "ALL">("ALL");
  const [localRecommendations, setLocalRecommendations] = useState<JoinConfig[]>([]);
  const [pendingDeleteJoinId, setPendingDeleteJoinId] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const resetTimer = window.setTimeout(() => {
      setActiveTab("driving");
      setSelectedJoinType("ALL");
      setPendingDeleteJoinId(null);
      const seed =
        recommendations.length > 0 ? recommendations : buildMockRecommendations(tables);
      setLocalRecommendations(seed);
    }, 0);
    return () => window.clearTimeout(resetTimer);
  }, [isOpen, recommendations, tables]);

  const visibleRecommendations = localRecommendations;

  const groupedRecommendations = useMemo(() => {
    const groups: Record<RecommendationBand, JoinConfig[]> = {
      HIGH: [],
      MEDIUM: [],
      LOW: [],
    };
    visibleRecommendations.forEach((join) => {
      groups[recommendationBand(join)].push(join);
    });
    return groups;
  }, [visibleRecommendations]);

  // Joins that touch the driving table lead the FROM clause, so they get their
  // own tab. Every other join stays in Joins, and nothing is listed twice.
  const { drivingJoins, otherJoins } = useMemo(() => {
    if (!drivingTableId) {
      return { drivingJoins: [] as JoinConfig[], otherJoins: joins };
    }
    const driving: JoinConfig[] = [];
    const others: JoinConfig[] = [];
    for (const join of joins) {
      if (join.leftTableId === drivingTableId || join.rightTableId === drivingTableId) {
        driving.push(join);
      } else {
        others.push(join);
      }
    }
    return { drivingJoins: driving, otherJoins: others };
  }, [drivingTableId, joins]);

  const tabJoins = activeTab === "driving" ? drivingJoins : otherJoins;

  const filteredJoins = useMemo(() => {
    if (selectedJoinType === "ALL") return tabJoins;
    return tabJoins.filter((join) => (join.joinType ?? "INNER") === selectedJoinType);
  }, [selectedJoinType, tabJoins]);

  if (!isOpen) return null;

  const isJoinListTab = activeTab === "driving" || activeTab === "joins";
  const drivingTableLabel = resolveTableLabel(tables, drivingTableId ?? undefined);

  const subtitle =
    joins.length === 1
      ? "1 join configured across source tables and CTEs"
      : `${joins.length} joins configured across source tables and CTEs`;
  const totalLabel = isJoinListTab
    ? tabJoins.length === 1
      ? "1 join total"
      : `${tabJoins.length} joins total`
    : visibleRecommendations.length === 1
      ? "1 AI recommendation"
      : `${visibleRecommendations.length} AI recommendations`;

  const isRecommendationAdded = (recommendation: JoinConfig) =>
    joins.some((join) => isSameJoin(join, recommendation));

  const handleRequestDeleteJoin = (joinId: string) => {
    setPendingDeleteJoinId(joinId);
  };

  const handleConfirmDeleteJoin = () => {
    if (pendingDeleteJoinId) {
      onDeleteJoin(pendingDeleteJoinId);
    }
    setPendingDeleteJoinId(null);
  };

  const handleAddRecommendation = (join: JoinConfig) => {
    if (isRecommendationAdded(join)) return;
    const accepted: JoinConfig = {
      ...join,
      id: join.id ?? `${join.leftTableId}__${join.rightTableId}`,
      source: join.source ?? "SEMANTIC_VIEW",
      reviewRequired: false,
      locked: false,
    };
    onAcceptRecommendation?.(accepted);
  };

  const handleEditRecommendation = (join: JoinConfig) => {
    onEditJoin({
      ...join,
      id: join.id ?? `${join.leftTableId}__${join.rightTableId}`,
      source: join.source ?? "SEMANTIC_VIEW",
      reviewRequired: true,
    });
  };

  const tabButtonSx = (active: boolean) =>
    ({
      flex: 1,
      minWidth: 0,
      width: "100%",
      px: 2,
      py: 1.35,
      borderRadius: 0,
      border: "none",
      borderBottom: active ? "2px solid #2563eb" : "2px solid transparent",
      boxShadow: "none",
      fontWeight: active ? 700 : 600,
      fontSize: 15,
      lineHeight: 1.3,
      color: active ? "#1e40af" : "#64748b",
      backgroundColor: "transparent",
      justifyContent: "center",
      "&:hover": {
        backgroundColor: "color-mix(in srgb, #2563eb 6%, transparent)",
        borderBottom: active ? "2px solid #2563eb" : "2px solid transparent",
      },
    }) as const;

  let recommendationIndex = 0;

  return (
    <>
    <div className="join-definitions-overlay">
      <div className="join-definitions-modal">
        <AiaBox sx={{ px: 3, pt: 2.5, pb: 0, borderBottom: "1px solid #f1f5f9", flexShrink: 0 }}>
          <AiaBox sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 2, mb: 2 }}>
            <AiaBox
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1.25,
                minWidth: 0,
                flex: 1,
                justifyContent: "flex-start",
              }}
            >
              <AiaBox
                sx={{
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  bgcolor: "#2563eb",
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <AllInclusiveIcon sx={{ fontSize: 20 }} />
              </AiaBox>
              <AiaBox sx={{ minWidth: 0, textAlign: "left" }}>
                <AiaText sx={{ ...textStyleCssVars("cardTitle"), letterSpacing: "-0.01em" }}>
                  Join Definitions
                </AiaText>
                <AiaText sx={{ ...textStyleCssVars("secondaryText"), display: "block", mt: 0.25 }}>
                  {subtitle}
                </AiaText>
              </AiaBox>
            </AiaBox>
            <AiaButton variant="text" size="small" onClick={onClose} sx={closeButtonSx} aria-label="Close">
              ✕
            </AiaButton>
          </AiaBox>

          <AiaBox sx={{ display: "flex", alignItems: "stretch", width: "100%" }}>
            <AiaButton
              variant="text"
              size="medium"
              onClick={() => setActiveTab("driving")}
              sx={tabButtonSx(activeTab === "driving")}
            >
              Driving Joins ({drivingJoins.length})
            </AiaButton>
            <AiaButton
              variant="text"
              size="medium"
              onClick={() => setActiveTab("joins")}
              sx={tabButtonSx(activeTab === "joins")}
            >
              Additional Joins ({otherJoins.length})
            </AiaButton>
            <AiaButton
              variant="text"
              size="medium"
              onClick={() => setActiveTab("recommendations")}
              sx={tabButtonSx(activeTab === "recommendations")}
            >
              AI Recommendations ({visibleRecommendations.length})
            </AiaButton>
          </AiaBox>
        </AiaBox>

        <AiaBox
          sx={{
            px: 3,
            py: 1.5,
            minHeight: 56,
            bgcolor: "#f8fafc",
            borderBottom: "1px solid #eef2f7",
            display: "flex",
            alignItems: "center",
            gap: 1.25,
            flexWrap: "wrap",
            flexShrink: 0,
          }}
        >
          {isJoinListTab ? (
            <>
              {filterLabel ? (
                <AiaChip
                  label={`Showing ${filterLabel}`}
                  size="small"
                  color="primary"
                  onDelete={onClearFilter}
                  sx={{ mr: 0.5 }}
                />
              ) : null}
              {activeTab === "driving" && drivingTableId ? (
                <AiaChip
                  label={`Driving: ${drivingTableLabel}`}
                  size="small"
                  customBackgroundColor="#fef3c7"
                  customColor="#854d0e"
                  customBorderColor="#fde68a"
                  sx={{ mr: 0.5 }}
                />
              ) : null}
              <AiaText
                sx={{
                  ...textStyleCssVars("caption"),
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  color: "#64748b",
                  mr: 0.5,
                }}
              >
                Join types:
              </AiaText>
              <AiaButton
                size="small"
                variant={selectedJoinType === "ALL" ? "contained" : "outlined"}
                onClick={() => setSelectedJoinType("ALL")}
                sx={{ minWidth: 0 }}
                {...(selectedJoinType === "ALL"
                  ? {
                      customBackgroundColor: "#334155",
                      customColor: "#ffffff",
                      customBorderColor: "#334155",
                    }
                  : {
                      customBorderColor: "#cbd5e1",
                      customColor: "#475569",
                    })}
              >
                ALL
              </AiaButton>
              {JOIN_TYPE_OPTIONS.map((joinType) => {
                const palette = JOIN_TYPE_COLORS[joinType];
                const active = selectedJoinType === joinType;
                return (
                  <AiaButton
                    key={joinType}
                    size="small"
                    variant={active ? "contained" : "outlined"}
                    onClick={() => setSelectedJoinType(joinType)}
                    sx={{ minWidth: 0 }}
                    {...(active
                      ? {
                          customBackgroundColor: palette.bg,
                          customColor: palette.fg,
                          customBorderColor: palette.bg,
                        }
                      : {
                          customBackgroundColor: `color-mix(in srgb, ${palette.bg} 12%, #ffffff)`,
                          customColor: palette.bg,
                          customBorderColor: `color-mix(in srgb, ${palette.bg} 30%, #ffffff)`,
                        })}
                  >
                    {joinType} JOIN
                  </AiaButton>
                );
              })}
            </>
          ) : (
            <AiaText sx={{ ...textStyleCssVars("caption"), color: "#64748b" }}>
              Semantic join recommendations for the selected tables. Use Add to copy a
              recommendation into Joins. Added items stay listed here without the Add action.
            </AiaText>
          )}
        </AiaBox>

        <AiaBox
          sx={{
            px: 3,
            py: 2.5,
            flex: 1,
            minHeight: 0,
            overflowY: "auto",
          }}
        >
          {isJoinListTab ? (
            filteredJoins.length === 0 ? (
              <AiaBox sx={{ py: 6, textAlign: "center", minHeight: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>
                  {tabJoins.length > 0
                    ? "No joins match the selected join type."
                    : activeTab === "driving"
                      ? drivingTableId
                        ? `No joins use the driving table ${drivingTableLabel} yet. Click Create Join to add one.`
                        : "No driving table selected yet. Pick one on the canvas to see its joins here."
                      : "No joins configured yet. Click Create Join to add one."}
                </AiaText>
              </AiaBox>
            ) : (
              <AiaBox sx={{ display: "flex", flexDirection: "column", gap: 1.25 }}>
                {filteredJoins.map((join, index) => (
                  <JoinRelationCard
                    key={join.id ?? `${join.leftTableId}-${join.rightTableId}-${index}`}
                    join={join}
                    index={index}
                    tables={tables}
                    onEdit={onEditJoin}
                    onDelete={handleRequestDeleteJoin}
                    cteSourceName={join.id ? cteOriginById?.[join.id] : undefined}
                  />
                ))}
              </AiaBox>
            )
          ) : visibleRecommendations.length === 0 ? (
            <AiaBox sx={{ py: 6, textAlign: "center", minHeight: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>
                No semantic join recommendations for the selected tables yet.
              </AiaText>
            </AiaBox>
          ) : (
            <AiaBox sx={{ display: "flex", flexDirection: "column", gap: 2.5 }}>
              {RECOMMENDATION_GROUPS.map((group) => {
                const sectionJoins = groupedRecommendations[group.key];
                return (
                  <AiaBox key={group.key} sx={{ display: "flex", flexDirection: "column", gap: 1.25 }}>
                    <AiaText
                      sx={{
                        ...textStyleCssVars("caption"),
                        letterSpacing: "0.06em",
                        textTransform: "uppercase",
                        color: "#475569",
                        fontWeight: 700,
                        px: 0.25,
                      }}
                    >
                      {group.title} ({sectionJoins.length})
                    </AiaText>
                    {sectionJoins.length === 0 ? (
                      <AiaBox
                        sx={{
                          px: 1.5,
                          py: 1.25,
                          border: "1px dashed #e2e8f0",
                          borderRadius: "12px",
                          bgcolor: "#fafbfc",
                        }}
                      >
                        <AiaText sx={{ ...textStyleCssVars("secondaryText"), fontSize: 12 }}>
                          No recommendations in this group.
                        </AiaText>
                      </AiaBox>
                    ) : (
                      sectionJoins.map((join) => {
                        const index = recommendationIndex;
                        recommendationIndex += 1;
                        const isAdded = isRecommendationAdded(join);
                        return (
                          <JoinRelationCard
                            key={join.id ?? `recommendation-${index}`}
                            join={join}
                            index={index}
                            tables={tables}
                            onEdit={handleEditRecommendation}
                            onAdd={handleAddRecommendation}
                            showAddInsteadOfDelete
                            isAdded={isAdded}
                          />
                        );
                      })
                    )}
                  </AiaBox>
                );
              })}
            </AiaBox>
          )}
        </AiaBox>

        <AiaBox
          sx={{
            px: 3,
            py: 2,
            borderTop: "1px solid #f1f5f9",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 2,
            flexShrink: 0,
          }}
        >
          <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>{totalLabel}</AiaText>
          {isJoinListTab ? (
            <AiaButton
              variant="contained"
              size="large"
              startIcon={<AddIcon sx={{ fontSize: 18 }} />}
              onClick={onCreateJoin}
              customBackgroundColor="var(--aia-primary-bg-color)"
              customColor="var(--aia-primary-bg-text-color)"
              customBorderColor="var(--aia-primary-bg-color)"
              customHoverBackgroundColor="var(--aia-primary-bg-hover-color)"
            >
              Create Join
            </AiaButton>
          ) : (
            <AiaBox />
          )}
        </AiaBox>
      </div>
    </div>

    <WorkspaceRemoveConfirmDialog
      open={pendingDeleteJoinId !== null}
      kind="join"
      mode="selected"
      count={1}
      showCount={false}
      onClose={() => setPendingDeleteJoinId(null)}
      onConfirm={handleConfirmDeleteJoin}
    />
    </>
  );
}
