from copy import deepcopy
import json

import pytest

from app.core.automap_stored_json import store_json, load_stored


def fixture():
    return {'version':'test','receipt_digest':'a'*64,'body':{'sql':"WITH x AS (SELECT 'é' AS name) SELECT name FROM x\r\n"*1000,'score':0.0}}


def test_storage_roundtrip_is_exact_and_small_and_does_not_modify_the_original():
    value=fixture();before=deepcopy(value)
    stored=store_json(value,public_keys=('version','receipt_digest'))
    assert len(json.dumps(stored).encode()) < len(json.dumps(value).encode())/10
    assert load_stored(json.loads(json.dumps(stored)))==before==value


def test_legacy_zlib_artifacts_remain_readable():
    import base64,zlib
    from app.core.automap_json import encoded,digest
    value=fixture();text=encoded(value).encode()
    old={'storage_encoding':'zlib-json-v1','content_sha256':digest(value),
         'uncompressed_bytes':len(text),'content':base64.b64encode(zlib.compress(text)).decode()}
    assert load_stored(old)==value


@pytest.mark.parametrize('field',['uncompressed_bytes','content','content_sha256','receipt_digest'])
def test_modified_storage_cannot_be_used(field):
    stored=store_json(fixture(),public_keys=('version','receipt_digest'))
    if field=='uncompressed_bytes':stored[field]=16_000_001
    elif field=='content':stored[field]+='!'
    else:stored[field]='b'*64
    with pytest.raises(ValueError):load_stored(stored)


def test_compressed_frozen_packet_is_checked_again_on_worker_hydration():
    from tests.unit.core.test_automap_frozen_packet import packet_fixture
    from app.core.automap_frozen_packet import hydrate
    from app.core.automap_packet_policy import source_planning_input
    from app.core.automap_batch import _FastAutoMapContext
    req,_,packet=packet_fixture()
    stored=store_json(packet,public_keys=('version','receipt_digest','message_digest'))
    store=_FastAutoMapContext(source_planning_input(req));store.manifest()
    plan,messages,_,_=hydrate(stored,store,expected_digest=packet['receipt_digest'],max_chars=180000,max_bytes=180000,deadline=None)
    assert messages==packet['messages']
