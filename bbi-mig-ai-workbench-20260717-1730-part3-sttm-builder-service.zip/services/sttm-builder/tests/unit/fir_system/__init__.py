"""FIR System unit tests."""
