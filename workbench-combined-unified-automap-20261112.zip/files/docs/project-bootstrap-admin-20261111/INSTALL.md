# Combined release: project initialization, recommendations and admin controls

This overlay includes all changes from the previous confidence/custom-rules ZIP, the earlier SQL-upload fixes, and this release. Apply the contents of `files/` at your repository root, preserving paths. No environment files, credentials, Git metadata, dependencies or images are included. No files require deletion. This guide supersedes the earlier guides where deployment requirements differ.

## Required deployment

1. Back up source and record existing image tags. Reconcile/drain active Auto-map work before switching versions.
2. Run the existing metadata bootstrap/CI step, which now includes and validates `infra/snowflake/project-bootstrap-lock.sql` in the configured namespace. Do not execute its unrendered namespace placeholder directly. It creates only `TBL_PROJECT_BOOTSTRAP_LOCK` with one mutex row; it does not delete or change existing projects/mappings. Grant SELECT and UPDATE on this table to the same existing caller roles allowed to create projects. Retain their existing database/schema USAGE grants. Do not create the table in a source/target data schema. Do not rerun with CREATE OR REPLACE or reseed the mutex during active requests.
3. Rebuild/deploy the backend image to both the web backend and Auto-map worker, and rebuild/deploy the frontend. Existing metadata/snapshot tables must already be provisioned by the normal installation. No new environment variables or dependency changes are required.
4. Deploy both updated agent specs (`AGT_SOURCE_MAPPING`, `AGT_TRANSFORMATION_RULE`) and the matching manifest using your existing authenticated agent deployment process. Verify with `python scripts/verify_mapping_agent_specs.py`. Start a new Auto-map job to use the rules-v2 protocol; do not edit frozen jobs.

The bootstrap lock is a correctness requirement for concurrent retries. Missing storage/grants fail before creating a project, with an actionable message. Initialization is synchronous but now batches the mapping writes: one header insert, one identity read, one snapshot insert, one attribute insert and one header payload update for all selected targets. Existing project/target validation and the single outer transaction remain. No model calls, source profiling or source-data queries are introduced. Do not parallelize writes on the same Snowpark session or raise proxy timeouts as a substitute.

## UI changes

- Main Source Selection → Join Definitions always exposes AI Recommendations, including its empty state. Reviewing does not automatically accept a join; existing acceptance behavior and CTE-editor behavior are retained.
- Administration → Projects & Mappings lists projects/mappings with search and small archive/delete icons.
- Project cards and mapping-list rows show the same icons only for the Admin persona. The server independently enforces the Admin persona; Publisher and Viewer cannot remove resources.
- Archive and Delete from lists both hide the resource. Delete is a logical deletion, not a purge. Removing a project hides its mappings too. Saved snapshots and published versions remain. Administration now includes Archived and Deleted recovery tabs; see `../metadata-admin-recovery-20261112/INSTALL.md` for restoration rules and the 30-day deletion window. Source/target Snowflake tables are untouched.
- Confirmation dialogs identify the affected resource and explain the retained history. Successful actions patch frontend cached listings without reloading the page. Removed projects/mappings are excluded from normal reads/listings and FIR runtime use through existing suppression fields.

## Local sample preview

No client Snowflake access is needed. From the repository root:

```sh
python scripts/preview_project_admin.py
```

In a second terminal:

```sh
cd frontend
LOCAL_DEV_AUTH_ENABLED=true BACKEND_DEV_ORIGIN=http://127.0.0.1:8016 NEXT_PUBLIC_BACKEND_DEV_ORIGIN=http://127.0.0.1:3016 npm run dev -- --webpack --port 3016 --hostname 127.0.0.1
```

Open http://127.0.0.1:3016/administration/resources, http://127.0.0.1:3016/projects or http://127.0.0.1:3016/mappings. These commands set process-only variables; do not save them into client environment files. The preview API binds only to loopback, uses sample Admin identity/data, and never reads credentials or connects to Snowflake. Preview actions change only the in-memory samples; restart the API to reset them. Do not deploy the preview API or use its local-auth settings in SPCS.

Browser automation was disabled in this Work session. The local page served HTTP 200 during verification, but a genuine rendered screenshot was not captured. A final preview restart was blocked by automatic approval review's usage limit; the server is not claimed to remain running.

## Before client promotion

Run the ten-target create/retry flow after applying the mutex SQL and grants. Verify exactly ten mappings, expected target-row counts and reopenable snapshots. Repeating the same timed-out request must recover the same completed project. Incomplete legacy shells are reported explicitly, not deleted or silently overwritten. Client target/query timings and real cross-replica contention were not measurable locally; record request IDs and the bootstrap elapsed_ms log when testing. A client 504 may have a separate upstream responder; proxy timeouts were not changed.

No client mapping/project was deleted or modified during this work. See VALIDATION.md for local tests and the previous release's native Auto-map evidence.
