"""The workspace snapshot shape the STTM builder UI saves, built on the server.

Deep Agent drafts are opened, edited and recompiled in the same builder as
manual work, so they must be saved exactly as the UI would save them. Each
helper mirrors one frontend function and must stay in step with it:

- ``relation_alias_for``: ``frontend/src/features/sttm/mapping/relation-alias.ts``
- ``relation_graph``: ``mapping-utils.ts`` ``buildCompilerRelationGraph``
- ``base_query_sql``: ``table-relationship-flow.tsx`` ``buildRelationshipQuery``
  with the derived-source ``WITH`` expansion used for the step-1 query
- ``canonical_mapping_row`` / ``canonical_snapshot``: ``workbench-context.ts``
  ``buildWorkbenchContextSnapshot``

The compiler, review and preview services receive the same relation graph and
rows from both paths, so the SELECT a user sees after opening an agent draft is
the SELECT the agent validated.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Iterable

from sqlglot import exp, parse_one

VALIDATION_RECEIPT_TYPE = "mapping_sql_validation"

_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*")
_PLACEHOLDER = re.compile(r"\$[A-Za-z_][A-Za-z0-9_]*")
_STRING_LITERAL = re.compile(r"('(?:''|[^'])*')")


def _alias_stem(seed: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_]", "_", seed.split(".")[-1]).strip("_").lower()
    return stem or "source"


def _identity_digest(identity: str) -> str:
    """FNV-1a over UTF-16 code units, rendered base-36 like the frontend."""
    value = 0x811C9DC5
    data = identity.encode("utf-16-le")
    for index in range(0, len(data), 2):
        value ^= data[index] | (data[index + 1] << 8)
        value = (value * 0x01000193) & 0xFFFFFFFF
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    text = ""
    while True:
        value, remainder = divmod(value, 36)
        text = digits[remainder] + text
        if not value:
            break
    return text.rjust(6, "0")[-6:]


def relation_alias_for(identity: str, display_seed: str | None = None) -> str:
    """Stable relation alias, identical to the frontend ``relationAliasFor``."""
    key = str(identity or "").strip()
    if not key:
        return "source"
    return f"{_alias_stem(display_seed or key)}_{_identity_digest(key)}"


def derived_reference_prefix(name: str) -> str:
    """Qualifier the mapping grid writes for a derived-source column.

    ``buildSourceColumnOptions`` offers ``<lower(name with spaces as _)>.COL``;
    the compiler resolves it through the relation's alias stem.
    """
    return re.sub(r"\s+", "_", str(name or "").strip()).lower()


def table_fqn(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if hasattr(value, "qualified_name"):
        return str(value.qualified_name)
    if isinstance(value, dict):
        direct = value.get("qualified_name") or value.get("fqn")
        if direct:
            return str(direct)
        parts = [str(value.get(key) or "") for key in ("database", "schema", "table")]
        if all(parts):
            return ".".join(parts)
    return ""


def table_ref(value: Any) -> dict[str, str] | None:
    fqn = table_fqn(value)
    parts = [part.strip('"') for part in fqn.split(".") if part]
    if len(parts) < 3:
        return None
    return {"database": parts[0], "schema": parts[1], "table": ".".join(parts[2:])}


def sql_hash(sql: str | None) -> str:
    """Hash of a SELECT, insensitive to a trailing semicolon or edge whitespace."""
    text = str(sql or "").strip()
    text = re.sub(r";\s*$", "", text).strip()
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Derived sources (CTEs)
# ---------------------------------------------------------------------------

def _lineage_value(lineage: Iterable[Any], key: str) -> Any:
    for item in reversed(list(lineage or [])):
        if isinstance(item, dict) and item.get(key) not in (None, "", []):
            return item.get(key)
    return None


def canonical_derived_source(value: Any) -> dict[str, Any]:
    """Full derived-source object in the shape ``workbench-context.ts`` writes.

    Accepts the agent's ``WorkspaceDerivedSourceRef`` (whose SQL, view and
    output columns live in ``lineage``) or an already canonical dict.
    """
    item = value.model_dump(mode="json") if hasattr(value, "model_dump") else dict(value or {})
    lineage = list(item.get("lineage") or [])
    source_id = str(item.get("id") or item.get("derived_source_id") or "")
    name = str(item.get("name") or item.get("source_name") or item.get("derived_source_name") or source_id)
    sql_text = str(item.get("sql_text") or _lineage_value(lineage, "sql") or "").strip() or None
    output_columns = [
        {
            "name": str(column.get("name") or column.get("column_name") or ""),
            "data_type": column.get("data_type") or column.get("dataType") or column.get("type"),
            **({"is_primary_key": column["is_primary_key"]} if "is_primary_key" in column else {}),
        }
        for column in (item.get("output_columns") or _lineage_value(lineage, "output_columns") or [])
        if isinstance(column, dict) and (column.get("name") or column.get("column_name"))
    ]
    base_tables = [
        ref for table in (item.get("base_source_tables") or _lineage_value(lineage, "base_source_tables") or [])
        if (ref := table_ref(table)) is not None
    ]
    return {
        "id": source_id,
        "name": name,
        "sql_text": sql_text,
        "physical_view_name": item.get("physical_view_name") or _lineage_value(lineage, "physical_view_name"),
        "generated_by_request_id": item.get("generated_by_request_id"),
        "semantic_bundle_id": item.get("semantic_bundle_id"),
        "semantic_bundle_label": item.get("semantic_bundle_label"),
        "semantic_view_name": item.get("semantic_view_name"),
        "semantic_level": item.get("semantic_level"),
        "upstream_hash": item.get("upstream_hash"),
        "source_dependency_hash": item.get("source_dependency_hash") or item.get("sql_hash"),
        "purpose": item.get("purpose") or _lineage_value(lineage, "purpose"),
        "business_description": item.get("business_description") or _lineage_value(lineage, "business_description"),
        "grain": item.get("grain") or _lineage_value(lineage, "grain"),
        "keys": [str(key) for key in (item.get("keys") or _lineage_value(lineage, "keys") or [])],
        "output_columns": output_columns,
        "column_semantics": list(item.get("column_semantics") or []),
        "semantic_projection": dict(item.get("semantic_projection") or {}),
        "semantic_quality": item.get("semantic_quality"),
        "lineage_depth": int(item.get("lineage_depth") or 0),
        "base_source_tables": base_tables,
        "table_ids": [table_fqn(ref) for ref in base_tables],
        "alias": relation_alias_for(source_id, name),
        "columns": [
            {"name": column["name"], "type": column.get("data_type") or ""} for column in output_columns
        ],
        "joins": list(item.get("joins") or []),
        "filters": list(item.get("filters") or []),
        "selected_columns_by_table": dict(item.get("selected_columns_by_table") or {}),
        "lineage": lineage,
        "sql_hash": item.get("sql_hash"),
        "origin": item.get("origin") or _lineage_value(lineage, "origin") or "agent",
    }


# ---------------------------------------------------------------------------
# Relation graph and step-1 query
# ---------------------------------------------------------------------------

def relationship_items(relationships: Iterable[Any]) -> list[dict[str, Any]]:
    """Physical-table joins in ``relationshipItems`` form (``left_table`` TableRef)."""
    items: list[dict[str, Any]] = []
    for raw in relationships or []:
        item = raw.model_dump(mode="json") if hasattr(raw, "model_dump") else dict(raw or {})
        left = table_ref(item.get("left_table"))
        right = table_ref(item.get("right_table"))
        conditions = [
            {
                "left_column": str(condition.get("left_column") or ""),
                "operator": str(condition.get("operator") or "="),
                "right_column": str(condition.get("right_column") or ""),
            }
            for condition in item.get("conditions") or []
            if isinstance(condition, dict) and condition.get("left_column") and condition.get("right_column")
        ]
        if not left or not right or not conditions:
            continue
        items.append({
            "left_table": left,
            "right_table": right,
            "join_type": str(item.get("join_type") or "INNER").upper(),
            "constraint_name": item.get("constraint_name"),
            "source": item.get("source") or "USER_DEFINED",
            "locked": bool(item.get("locked", False)),
            "conditions": conditions,
        })
    return items


def relation_graph(
    *,
    source_tables: Iterable[Any],
    source_columns_by_table: dict[str, list[dict[str, Any]]] | None = None,
    derived_sources: Iterable[dict[str, Any]] = (),
    relationships: Iterable[Any] = (),
    derived_edges: Iterable[dict[str, Any]] = (),
    value_bindings: Iterable[Any] = (),
) -> dict[str, Any]:
    """Graph in the shape ``buildCompilerRelationGraph`` sends to the compiler.

    ``relationships`` are physical joins (``left_table``/``right_table``);
    ``derived_edges`` join a derived source by its id and carry
    ``left_relation_id``/``right_relation_id`` directly, as the UI does.
    """
    columns_by_table = {key.upper(): value for key, value in (source_columns_by_table or {}).items()}
    nodes: list[dict[str, Any]] = []
    for table in source_tables:
        ref = table_ref(table)
        if ref is None:
            continue
        relation_id = table_fqn(ref)
        nodes.append({
            "relation_id": relation_id,
            "kind": "PHYSICAL_TABLE",
            "alias": relation_alias_for(relation_id),
            "table": ref,
            "output_columns": [
                {"name": str(column.get("name") or ""), "data_type": column.get("data_type") or column.get("type")}
                for column in columns_by_table.get(relation_id.upper(), [])
                if isinstance(column, dict) and column.get("name")
            ],
        })
    seen_derived_ids: set[str] = set()
    for source in derived_sources:
        # cte_designer and lift_join_filters both hash a table+predicate into
        # an `agent_cte_<hash>` id; the same filtered relation built by both
        # paths for one target must not become two CTEs of the same name.
        source_id = str(source.get("id") or "")
        if source_id and source_id.upper() in seen_derived_ids:
            continue
        if source_id:
            seen_derived_ids.add(source_id.upper())
        nodes.append({
            "relation_id": source["id"],
            "kind": "DERIVED_SOURCE",
            "alias": relation_alias_for(source["id"], source.get("name")),
            "derived_source_id": source["id"],
            "physical_view_name": source.get("physical_view_name"),
            "sql_text": source.get("sql_text"),
            "output_columns": list(source.get("output_columns") or []),
            "column_semantics": list(source.get("column_semantics") or []),
            "grain": source.get("grain"),
            "keys": list(source.get("keys") or []),
            "dependency_hash": source.get("source_dependency_hash") or source.get("upstream_hash"),
            "parent_relation_ids": list(source.get("parent_derived_source_ids") or []),
            "base_relation_ids": [table_fqn(ref) for ref in source.get("base_source_tables") or []],
        })
    node_ids = {node["relation_id"].upper(): node["relation_id"] for node in nodes}
    edges: list[dict[str, Any]] = []

    def add_edge(left_id: str, right_id: str, item: dict[str, Any]) -> None:
        left = node_ids.get(str(left_id).upper())
        right = node_ids.get(str(right_id).upper())
        conditions = [
            {"left_column": str(c["left_column"]), "right_column": str(c["right_column"]),
             "operator": str(c.get("operator") or "=")}
            for c in item.get("conditions") or []
            if isinstance(c, dict) and c.get("left_column") and c.get("right_column")
        ]
        if not left or not right or not conditions:
            return
        edge = {
            "edge_id": str(item.get("edge_id") or item.get("id") or f"relation-edge-{len(edges) + 1}"),
            "left_relation_id": left,
            "right_relation_id": right,
            "join_type": str(item.get("join_type") or "INNER").upper(),
            "provenance": item.get("provenance") or item.get("source") or "USER_DEFINED",
            "validation_status": "validated" if item.get("locked") else "selected",
            "conditions": conditions,
        }
        # Only joins lift_join_filters could not express as a CTE keep these;
        # the grid cannot edit them, so callers report them as parity warnings.
        if item.get("literal_filters"):
            edge["literal_filters"] = list(item["literal_filters"])
        if item.get("normalized_lookup_alternative"):
            edge["normalized_lookup_alternative"] = item["normalized_lookup_alternative"]
        edges.append(edge)

    for raw in relationships:
        item = raw.model_dump(mode="json") if hasattr(raw, "model_dump") else dict(raw or {})
        physical = relationship_items([item])
        if not physical:
            continue
        add_edge(table_fqn(item["left_table"]), table_fqn(item["right_table"]), {**item, **physical[0]})
    for item in derived_edges:
        add_edge(str(item.get("left_relation_id") or ""), str(item.get("right_relation_id") or ""), item)
    bindings = [
        value.model_dump(mode="json") if hasattr(value, "model_dump") else dict(value)
        for value in value_bindings
    ]
    return {"nodes": nodes, "edges": edges, "value_bindings": bindings}


def _slug(value: str, limit: int = 48) -> str:
    return re.sub(r"_+", "_", re.sub(r"[^a-z0-9_]", "_", value.lower())).strip("_")[:limit] or "value"


def _sql_string(value: Any) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def lift_join_filters(
    relationships: Iterable[Any],
    *,
    source_columns_by_table: dict[str, list[dict[str, Any]]],
    driving_fqn: str | None,
) -> dict[str, Any]:
    """Express constant join filters as CTEs, the way a user builds them in the UI.

    The grid's join editor holds column-to-column conditions only. A join
    scoped by a constant (a polymorphic ``..._TYPE = 'Contact'`` column, for
    example) is built in the UI as a filtered CTE joined on the same keys. The
    same is done here when the filtered table is used by that join alone and
    is not the driving table; otherwise the join is left unchanged and
    reported, because rewriting a shared relation would change other joins.

    Returns the remaining physical relationships, the new CTEs, the edges that
    join them, qualifier rewrites for mapping rows, and parity warnings.
    """
    items = [raw.model_dump(mode="json") if hasattr(raw, "model_dump") else dict(raw or {}) for raw in relationships]
    usage: dict[str, int] = {}
    for item in items:
        for side in ("left_table", "right_table"):
            fqn = table_fqn(item.get(side)).upper()
            if fqn:
                usage[fqn] = usage.get(fqn, 0) + 1
    columns_by_table = {key.upper(): value for key, value in source_columns_by_table.items()}
    remaining: list[dict[str, Any]] = []
    derived: list[dict[str, Any]] = []
    derived_edges: list[dict[str, Any]] = []
    rewrites: dict[str, str] = {}
    warnings: list[str] = []
    for item in items:
        filters = [value for value in item.get("literal_filters") or [] if isinstance(value, dict)]
        if item.get("normalized_lookup_alternative"):
            warnings.append(
                f"The join to {table_fqn(item.get('right_table'))} matches a code or its alias; the mapping "
                "grid cannot edit that join, so recompiling in the UI needs the join rebuilt as a CTE."
            )
        if not filters:
            remaining.append(item)
            continue
        sides = {str(value.get("side") or "left") for value in filters}
        side = next(iter(sides)) if len(sides) == 1 else None
        table = table_ref(item.get(f"{side}_table")) if side else None
        fqn = table_fqn(table) if table else ""
        if (not table or usage.get(fqn.upper(), 0) != 1 or fqn.upper() == str(driving_fqn or "").upper()
                or not all(_IDENTIFIER.fullmatch(str(value.get("column") or "")) for value in filters)):
            remaining.append(item)
            warnings.append(
                f"The join between {table_fqn(item.get('left_table'))} and {table_fqn(item.get('right_table'))} "
                "has constant filters that the mapping grid cannot edit."
            )
            continue
        predicate = "\n  AND ".join(f"{value['column']} = {_sql_string(value.get('value'))}" for value in filters)
        name = _slug(f"{table['table']}_" + "_".join(str(value.get("value")) for value in filters))
        source_id = "agent_cte_" + hashlib.sha256(f"{fqn}|{predicate}".upper().encode("utf-8")).hexdigest()[:20]
        columns = columns_by_table.get(fqn.upper(), [])
        derived.append(canonical_derived_source({
            "id": source_id,
            "name": name,
            "sql_text": f"SELECT *\nFROM {fqn}\nWHERE {predicate}",
            "purpose": f"Rows of {table['table']} where " + " and ".join(
                f"{value['column']} = {_sql_string(value.get('value'))}" for value in filters),
            "grain": f"One row per {table['table']} row",
            "output_columns": [
                {"name": column.get("name"), "data_type": column.get("data_type") or column.get("type")}
                for column in columns if isinstance(column, dict) and column.get("name")
            ],
            "base_source_tables": [table],
            "origin": "agent",
        }))
        other = "right" if side == "left" else "left"
        derived_edges.append({
            **{key: value for key, value in item.items() if key not in {"literal_filters", "left_table", "right_table"}},
            f"{side}_relation_id": source_id,
            f"{other}_relation_id": table_fqn(item.get(f"{other}_table")),
            "provenance": item.get("source") or "APPROVED_PLAN",
        })
        prefix = derived_reference_prefix(name)
        for key in (fqn, f"{table['schema']}.{table['table']}", table["table"], relation_alias_for(fqn)):
            rewrites[key.upper()] = prefix
    return {
        "relationships": remaining,
        "derived_sources": derived,
        "derived_edges": derived_edges,
        "rewrites": rewrites,
        "warnings": warnings,
    }


def base_query_sql(graph: dict[str, Any], driving_relation_id: str | None) -> str:
    """The step-1 ``SELECT * FROM ... JOIN ...`` query, with CTEs inlined."""
    nodes = {node["relation_id"]: node for node in graph.get("nodes") or []}
    if not nodes:
        return ""
    derived = [node for node in nodes.values() if node["kind"] != "PHYSICAL_TABLE" and node.get("sql_text")]

    def reference(node: dict[str, Any]) -> tuple[str, str]:
        if node["kind"] != "PHYSICAL_TABLE":
            return node["alias"], node["alias"]
        source = table_fqn(node["table"])
        return source, relation_alias_for(source)

    def render(node: dict[str, Any]) -> str:
        source, alias = reference(node)
        return source if source == alias else f"{source} AS {alias}"

    joins = list(graph.get("edges") or [])
    seed = nodes.get(driving_relation_id or "") or (
        nodes.get(joins[0]["left_relation_id"]) if joins else None
    ) or next(iter(nodes.values()))
    lines = ["SELECT", "  *", f"FROM {render(seed)}"]
    visited = {seed["relation_id"]}
    remaining = list(joins)
    while remaining:
        index = next((
            position for position, join in enumerate(remaining)
            if (join["left_relation_id"] in visited) != (join["right_relation_id"] in visited)
        ), -1)
        if index < 0:
            break
        join = remaining.pop(index)
        left, right = nodes.get(join["left_relation_id"]), nodes.get(join["right_relation_id"])
        if not left or not right:
            continue
        attaching = right if join["left_relation_id"] in visited else left
        lines.append(f"{join.get('join_type') or 'INNER'} JOIN {render(attaching)}")
        lines.append("  ON " + "\n  AND ".join(
            f"{reference(left)[1]}.{condition['left_column']} {condition.get('operator') or '='} "
            f"{reference(right)[1]}.{condition['right_column']}"
            for condition in join.get("conditions") or []
        ))
        visited.add(attaching["relation_id"])
    query = "\n".join(lines)
    if not derived:
        return query
    ctes = [
        f"{node['alias']} AS (\n"
        + "\n".join(f"  {line}" for line in str(node["sql_text"]).strip().rstrip(";").split("\n"))
        + "\n)"
        for node in derived
    ]
    return "WITH\n" + ",\n".join(ctes) + "\n" + query


# ---------------------------------------------------------------------------
# Mapping rows
# ---------------------------------------------------------------------------

def _literal_value(expression: str) -> str | None:
    """The value of a plain string, number or boolean literal, or None.

    Typed literals such as ``TO_DATE('...')`` stay expressions: the Value
    compiler would emit them as untyped strings.
    """
    try:
        node = parse_one(expression, read="snowflake")
    except Exception:
        return None
    while isinstance(node, exp.Paren):
        node = node.this
    if isinstance(node, exp.Literal):
        return str(node.this)
    if isinstance(node, exp.Boolean):
        return "TRUE" if node.this else "FALSE"
    return None


def rewrite_qualifiers(text: str, rewrites: dict[str, str]) -> str:
    """Replace relation qualifiers (``DB.S.T.``, ``S.T.``, ``T.``, an alias) outside string literals.

    ``rewrites`` maps an upper-cased qualifier to its new qualifier. Longer
    qualifiers are replaced first so a table name never rewrites part of a
    fully qualified reference.
    """
    if not text or not rewrites:
        return text
    ordered = sorted(rewrites, key=len, reverse=True)
    pattern = re.compile(
        r'(?<![A-Za-z0-9_$."])(' + "|".join(
            r"\.".join(rf'"?{re.escape(part)}"?' for part in key.split(".")) for key in ordered
        ) + r')\s*\.(?=\s*"?[A-Za-z_])',
        re.IGNORECASE,
    )

    def replace(match: re.Match[str]) -> str:
        key = match.group(1).replace('"', "").upper()
        return f"{rewrites.get(key, match.group(1))}."

    segments = _STRING_LITERAL.split(text)
    return "".join(
        segment if index % 2 else pattern.sub(replace, segment)
        for index, segment in enumerate(segments)
    )


def _is_plain_reference(expression: str, source_columns: list[str]) -> bool:
    """True when the expression only names its single source column."""
    if len(source_columns) != 1:
        return False
    target = source_columns[0].replace('"', "").upper().split(".")
    text = expression.replace('"', "").strip().upper()
    parts = text.split(".")
    return bool(parts) and parts == target[-len(parts):] and all(_IDENTIFIER.fullmatch(p) for p in parts)


def canonical_mapping_row(
    row: dict[str, Any],
    *,
    target_type: str | None = None,
    resolved_placeholders: dict[str, str] | None = None,
    qualifier_rewrites: dict[str, str] | None = None,
) -> dict[str, Any]:
    """One mapping row as the grid saves it; agent review metadata is kept alongside.

    ``status`` follows the grid (``MAPPED`` or ``UNMAPPED``). The agent's own
    review state (``draft``/``unresolved``) moves to ``review_status``.
    """
    rewrites = qualifier_rewrites or {}
    agent_status = str(row.get("status") or "").lower()
    mapped = agent_status in {"draft", "mapped", "accepted", "complete"}
    source_columns = [
        rewrite_qualifiers(str(value), rewrites) for value in row.get("source_columns") or [] if str(value).strip()
    ]
    dependencies = [
        rewrite_qualifiers(str(value), rewrites)
        for value in (row.get("source_dependencies") or source_columns) if str(value).strip()
    ]
    expression = str(row.get("expression") or "").strip()
    for placeholder, sql in (resolved_placeholders or {}).items():
        expression = re.sub(
            rf"(?<![A-Za-z0-9_$]){re.escape(placeholder)}(?![A-Za-z0-9_$])", lambda _m, sql=sql: sql, expression,
        )
    expression = rewrite_qualifiers(expression, rewrites)
    mapping_mode, constant_value, attribute_name = "source", None, None
    if str(row.get("mapping_mode") or "") in {"constant", "attribute"}:
        mapping_mode = str(row["mapping_mode"])
        constant_value = row.get("constant_value")
        attribute_name = row.get("attribute_name")
    elif mapped and expression and not source_columns:
        if _PLACEHOLDER.fullmatch(expression):
            mapping_mode, constant_value, attribute_name = "attribute", expression, expression[1:]
        elif (literal := _literal_value(expression)) is not None:
            mapping_mode, constant_value = "constant", literal
    if mapping_mode != "source":
        rule, expression_out = "Value", None
    elif expression and not _is_plain_reference(expression, source_columns):
        rule, expression_out = "Custom", expression
    else:
        rule, expression_out = "Direct", None
    if not mapped:
        # Unresolved rules are evidence for review, not executable mapping SQL.
        # Their original text is retained separately as held_back_expression.
        expression_out = None
    canonical = {
        "id": str(row.get("id") or ""),
        "target_column": str(row.get("target_column") or ""),
        "target_type": target_type or row.get("target_type"),
        "source_columns": source_columns if mapping_mode == "source" else [],
        "source_type": row.get("source_type"),
        "mapping_mode": mapping_mode,
        "constant_value": None if constant_value is None else str(constant_value),
        "attribute_name": attribute_name,
        "rule": rule,
        "expression": expression_out,
        "natural_language_rule": row.get("natural_language_rule"),
        "description": row.get("description"),
        "load_order": row.get("load_order"),
        "confidence": row.get("confidence"),
        "confidence_reason": row.get("confidence_reason"),
        "used_inference_ids": list(row.get("used_inference_ids") or []),
        "used_recommendation_ids": list(row.get("used_recommendation_ids") or []),
        "used_learning_ids": list(row.get("used_learning_ids") or []),
        "status": "MAPPED" if mapped and (source_columns or expression or mapping_mode != "source") else "UNMAPPED",
        "source_dependencies": dependencies if mapping_mode == "source" else [],
        "transformation_classification": row.get("mapping_classification") or row.get("transformation_classification"),
        "review_status": agent_status or None,
    }
    for key in (
        "mapping_classification", "evidence_ids", "assumptions", "missing_dependencies", "confidence_evidence",
        "specialist_confidence", "candidate_confidence", "rule_status", "rejected_expression", "sql_rejection",
        "repairs", "precedent_decision", "precedent_mapping_id", "value_binding_ids", "dependency",
        "attachment_evidence", "firm_values", "held_back_expression",
    ):
        if key in row:
            canonical[key] = row[key]
    return canonical


def compile_mapping_item(row: dict[str, Any]) -> dict[str, Any]:
    """The ``MappingSqlMappingItem`` payload the mapping page builds from a grid row."""
    mode = row.get("mapping_mode") or "source"
    return {
        "target_column": row["target_column"],
        "target_sql_name": row.get("target_sql_name"),
        "target_type": row.get("target_type"),
        "source_column": (row.get("source_columns") or [None])[0],
        "source_columns": list(row.get("source_columns") or []),
        "mapping_mode": mode,
        "constant_value": row.get("constant_value"),
        "attribute_name": row.get("attribute_name"),
        "expression": row.get("expression"),
        "rule": row.get("rule"),
        "status": row.get("status"),
        "nl_rule": row.get("natural_language_rule"),
        "description": row.get("description"),
        "source_dependencies": list(row.get("source_dependencies") or row.get("source_columns") or []),
        "value_binding_ids": [row["id"]] if mode in {"constant", "attribute"} else [],
        "precedent_decision": row.get("precedent_decision"),
        "precedent_mapping_id": row.get("precedent_mapping_id"),
    }


def grid_value_bindings(rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Value bindings the mapping page derives from constant and attribute rows."""
    bindings = []
    for row in rows:
        if row.get("mapping_mode") not in {"constant", "attribute"} or row.get("constant_value") is None:
            continue
        attribute_name = str(row.get("attribute_name") or "").strip()
        placeholder = str(row["constant_value"]).strip().startswith("$") or bool(attribute_name)
        bindings.append({
            "binding_id": row["id"],
            "value": f"${attribute_name}" if attribute_name else str(row["constant_value"]),
            "data_type": row.get("target_type") or None,
            "is_placeholder": placeholder,
            "allow_project_specific_value": False,
            "resolution_status": "project_attribute" if attribute_name else (
                "placeholder_contract" if placeholder else "resolved"
            ),
            "attribute_name": attribute_name or None,
            "resolved_value": row["constant_value"] if attribute_name else None,
        })
    return bindings


# ---------------------------------------------------------------------------
# Validation receipt
# ---------------------------------------------------------------------------

def validation_receipt(
    *,
    preview_sql: str,
    compile_valid: bool,
    review: dict[str, Any] | None,
    preview: dict[str, Any] | None,
    validated_by: str,
    validated_at: str,
    error: str | None = None,
    failed_phase: str | None = None,
) -> dict[str, Any]:
    """What the mapping page needs to show validation without re-running it.

    ``review`` and ``preview`` are the service responses the page itself
    receives (``MappingSqlReviewResponse`` / ``MappingSqlPreviewResponse``).
    The page restores them only while ``preview_sql_hash`` still matches the
    SELECT on screen.
    """
    return {
        "type": VALIDATION_RECEIPT_TYPE,
        "preview_sql_hash": sql_hash(preview_sql),
        "compile_valid": bool(compile_valid),
        "execution_ready": bool((review or {}).get("execution_ready")),
        "preview_valid": bool(preview) and not error,
        "preview_row_count": len((preview or {}).get("preview_rows") or []),
        "review": review,
        "preview": preview,
        "error": error,
        "failed_phase": failed_phase,
        "validated_by": validated_by,
        "validated_at": validated_at,
    }


def merge_validation_history(history: Iterable[Any], receipt: dict[str, Any] | None, *, limit: int = 5) -> list[dict[str, Any]]:
    """Keep the newest receipt per SELECT; other history entries are preserved."""
    items = [dict(item) for item in history or [] if isinstance(item, dict)]
    if receipt is None:
        return items
    others = [item for item in items if item.get("type") != VALIDATION_RECEIPT_TYPE]
    receipts = [
        item for item in items
        if item.get("type") == VALIDATION_RECEIPT_TYPE and item.get("preview_sql_hash") != receipt["preview_sql_hash"]
    ]
    return [*others, *receipts[-(limit - 1):], receipt] if limit > 1 else [*others, receipt]


def apply_review_choice(snapshot: dict[str, Any], target_column: str, candidate: dict[str, Any], *,
                        answered_by: str) -> dict[str, Any]:
    """The draft snapshot with a reviewer's chosen candidate applied to one grid row.

    The row becomes MAPPED with the candidate's sources, rule or value. The
    compiled SQL is kept but its hash is cleared, so the mapping page compiles
    the changed rows when the draft opens and no earlier validation is shown
    for SQL that no longer matches.
    """
    updated = json.loads(json.dumps(snapshot, default=str))
    rows = list(updated.get("mapping_rows") or [])
    index = next((position for position, row in enumerate(rows)
                  if str(row.get("target_column") or "").upper() == str(target_column).upper()), None)
    if index is None:
        raise ValueError(f"{target_column} is not a row of this draft")
    constant = candidate.get("constant_value")
    sources = [str(value) for value in candidate.get("source_columns") or [] if str(value).strip()]
    expression = str(candidate.get("transformation") or "").strip() or None
    row = {**rows[index], "status": "MAPPED", "review_status": "draft", "rule_status": None,
           "rejected_expression": None, "sql_rejection": None,
           "confidence": candidate.get("confidence"),
           "confidence_reason": f"Chosen in review by {answered_by}: {candidate.get('reason') or 'selected candidate'}",
           "evidence_ids": sorted({*[str(value) for value in rows[index].get("evidence_ids") or []],
                                   *[str(value) for value in candidate.get("evidence_ids") or []]})}
    if candidate.get("attribute_name") and constant not in (None, "") and not sources:
        # A firm value: the grid saves its name with the resolved value.
        row.update({"mapping_mode": "attribute", "constant_value": str(constant),
                    "attribute_name": str(candidate["attribute_name"]), "rule": "Value",
                    "expression": None, "source_columns": [], "source_dependencies": [],
                    "firm_values": [str(candidate["attribute_name"])]})
    elif constant not in (None, "") and not sources:
        placeholder = str(constant).startswith("$")
        row.update({"mapping_mode": "attribute" if placeholder else "constant", "constant_value": str(constant),
                    "attribute_name": str(constant)[1:] if placeholder else None, "rule": "Value",
                    "expression": None, "source_columns": [], "source_dependencies": []})
    else:
        row.update({"mapping_mode": "source", "constant_value": None, "attribute_name": None,
                    "source_columns": sources, "source_dependencies": sources,
                    "rule": "Custom" if expression and not _is_plain_reference(expression, sources) else "Direct",
                    "expression": expression if expression and not _is_plain_reference(expression, sources) else None})
    rows[index] = row
    updated["mapping_rows"] = rows
    updated["checked_mapping_row_ids"] = [item["id"] for item in rows if item.get("status") == "MAPPED"]
    updated["compiled_mapping_context_hash"] = None
    updated["page"], updated["surface"] = "mapping", "MAPPING"
    updated.pop("context_hash", None)
    return updated


def canonical_snapshot(
    base: dict[str, Any],
    *,
    page: str,
    surface: str,
    source_tables: Iterable[Any],
    target_table: Any,
    driving_table: Any,
    graph: dict[str, Any],
    derived_sources: list[dict[str, Any]],
    relationships: Iterable[Any],
    mapping_rows: list[dict[str, Any]],
    filters: dict[str, Any] | None = None,
    compiled_mapping_sql: str | None = None,
    compiled_mapping_preview_sql: str | None = None,
    compiled_mapping_script: str | None = None,
    validation_history: list[dict[str, Any]] | None = None,
    mapping_artifacts: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Assemble the snapshot with every key ``buildWorkbenchContextSnapshot`` writes."""
    driving = table_ref(driving_table)
    filter_state = {
        "filter_sql": None, "base_query_sql": None, "group_by_sql": None, "order_by_sql": None, "groups": [],
        **dict(filters or {}),
    }
    graph_ids = {str(node.get("relation_id") or "") for node in graph.get("nodes") or []}
    requested_driver = str(base.get("driving_relation_id") or "")
    driver_id = requested_driver if requested_driver in graph_ids else (table_fqn(driving) if driving else None)
    filter_state["base_query_sql"] = base_query_sql(graph, driver_id) or None
    selected: dict[str, set[str]] = {}
    for node in graph.get("nodes") or []:
        if node["kind"] == "PHYSICAL_TABLE":
            selected[node["relation_id"]] = set()
    for row in mapping_rows:
        for value in row.get("source_columns") or []:
            owner, _, column = str(value).rpartition(".")
            if owner.upper() in {key.upper() for key in selected} and column:
                selected[next(key for key in selected if key.upper() == owner.upper())].add(column.strip('"'))
    for edge in graph.get("edges") or []:
        for side, column_key in (("left_relation_id", "left_column"), ("right_relation_id", "right_column")):
            if edge[side] in selected:
                for condition in edge.get("conditions") or []:
                    selected[edge[side]].add(str(condition[column_key]).strip('"'))
    previous_selected = dict(base.get("selected_columns_by_table") or {})
    selected_columns = {
        key: sorted(set(values) | set(previous_selected.get(key) or []))
        for key, values in sorted(selected.items())
        if values or previous_selected.get(key)
    }
    source_refs = sorted(
        (ref for table in source_tables if (ref := table_ref(table)) is not None),
        key=table_fqn,
    )
    snapshot = {
        **base,
        "context_version": "2.0",
        "page": page,
        "surface": surface,
        "source_tables": source_refs,
        "target_table": table_ref(target_table),
        "driving_table": driving,
        "selected_columns_by_table": selected_columns,
        "derived_sources": derived_sources,
        "relation_graph": graph,
        "relationships": relationship_items(relationships),
        "filters": filter_state,
        "mapping_rows": mapping_rows,
        "checked_mapping_row_ids": [row["id"] for row in mapping_rows if row.get("status") == "MAPPED"],
        "active_mapping_row_id": base.get("active_mapping_row_id"),
        # Agent drafts are compiled from the grid, never imported SQL; an
        # empty raw SQL keeps the SQL tab on the compiler output.
        "mapping_sql": None,
        "raw_mapping_sql": None,
        "parsed_mapping_model": None,
        "mapping_preview_sql": None,
        "compiled_mapping_sql": compiled_mapping_sql,
        "compiled_mapping_preview_sql": compiled_mapping_preview_sql,
        # The same mapping with firm values as SET + $Name, for export and review.
        "compiled_mapping_script": compiled_mapping_script,
        "compiled_mapping_context_hash": sql_hash(compiled_mapping_preview_sql) if compiled_mapping_preview_sql else None,
        "mapping_artifacts": list(mapping_artifacts if mapping_artifacts is not None else base.get("mapping_artifacts") or []),
        "validation_history": list(validation_history if validation_history is not None else base.get("validation_history") or []),
    }
    # Keys only a stale agent workspace would carry must not leak into the draft.
    snapshot.pop("context_hash", None)
    return json.loads(json.dumps(snapshot, default=str))
