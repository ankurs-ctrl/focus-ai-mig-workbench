"""Convert source objects only through an unambiguous admitted binding."""
from copy import deepcopy
import re

from sqlglot.errors import ParseError, TokenError

from app.core.automap_fast_context import _reference_key


def normalize_source_objects(envelope, plan):
    value = deepcopy(envelope)
    data = value.get("data") if isinstance(value.get("data"), dict) else value
    result = data.get("result") or value.get("result") or {}
    mappings = result.get("mappings") if isinstance(result, dict) else None
    rows = list(mappings.items()) if isinstance(mappings, dict) else [(item.get('target_attribute'), item) for item in mappings if isinstance(item, dict)] if isinstance(mappings, list) else []
    admitted = list(plan.admitted_sources())
    cards = [card.body for card in admitted]
    identities = {}
    for record in admitted:
        body = record.body
        reference = f'{body["binding"]["sql_qualifier"]}.{body["column"]}'
        from app.core.automap_citations import source_record_id
        for identifier in (record.record_id, 'src:' + reference, source_record_id(reference)):
            identities.setdefault(identifier, set()).add(reference)

    def reference(value):
        matches = identities.get(value, ()) if isinstance(value, str) else ()
        if len(matches) == 1:
            return next(iter(matches))
        if not isinstance(value, str):
            return value
        # Convert only one SQL column, never expressions or prose. Preserve
        # exact quoted case and reject ambiguous self-join/unqualified names.
        from sqlglot import parse, exp
        try:
            trees = parse(value, read='snowflake')
            if len(trees) != 1 or not isinstance(trees[0], exp.Column):
                return value
            parts = trees[0].parts
            if not all(isinstance(part, exp.Identifier) for part in parts):
                return value
            key = tuple(part.name if part.args.get('quoted') else part.name.upper() for part in parts)
            direct = {f'{card["binding"]["sql_qualifier"]}.{card["column"]}' for card in cards
                      if _reference_key(f'{card["binding"]["sql_qualifier"]}.{card["column"]}') == key}
            if len(direct) == 1:
                return value
            if len(parts) == 1:
                found = {f'{card["binding"]["sql_qualifier"]}.{card["column"]}' for card in cards
                         if _reference_key(f'{card["binding"]["sql_qualifier"]}.{card["column"]}')[-1:] == key}
                return next(iter(found)) if len(found) == 1 else value
            return resolve({'source_table': '.'.join(part.sql(dialect='snowflake') for part in parts[:-1]),
                            'source_column': parts[-1].sql(dialect='snowflake')})
        except (ValueError, TypeError, ParseError, TokenError):
            return value

    def resolve(item):
        if (type(item) is not dict or set(item) - {"source_column", "source_table", "sql_qualifier"}
                or type(item.get("source_column")) is not str
                or not (item.get("source_table") or item.get("sql_qualifier"))):
            raise ValueError("Unsupported source-reference object")
        # This object format has separate column, table and binding fields.
        # Reject qualified columns, even when their qualifier happens to agree;
        # discarding a supplied qualifier could silently rebind a self-join.
        column_key = _reference_key("dummy." + item["source_column"])
        if len(column_key) != 2:
            raise ValueError("Source object requires one unqualified column identifier")
        column = column_key[-1]
        matches = []
        for card in cards:
            binding = card["binding"]
            source_ref = f'{binding["sql_qualifier"]}.{card["column"]}'
            key = _reference_key(source_ref)
            if column != key[-1] and item["source_column"] != card["name"]:
                continue
            qualifier = item.get("sql_qualifier")
            if qualifier is not None and _reference_key(qualifier + ".dummy")[:-1] != key[:-1]:
                continue
            table = item.get("source_table")
            if table is not None:
                node = plan.store.nodes[binding["relation_id"]]
                owner = node.get("table") or {}
                fqn = ".".join(owner.get(part, "") for part in ("database", "schema", "table"))
                if not fqn.strip("."):
                    continue
                provided = _reference_key(table + ".dummy")[:-1]
                # Catalog names retain exact case. Do not casefold a genuinely
                # quoted physical table into a different uppercase table.
                actual = tuple(_reference_key(part + ".dummy")[0] if part.startswith('"') else part
                               for part in (owner.get("database", ""), owner.get("schema", ""), owner.get("table", "")))
                if not provided or actual[-len(provided):] != provided:
                    continue
            matches.append(source_ref)
        if len(matches) != 1:
            raise ValueError("Source object does not uniquely match an admitted binding")
        return matches[0]

    rows = [(target, item) for target, row in rows if isinstance(row, dict)
            for item in [row, *(row.get('candidates') if isinstance(row.get('candidates'), list) else [])]]
    for target, row in rows:
        if not isinstance(row, dict):
            continue
        if (getattr(getattr(plan, 'store', None), 'original', {}).get('meta') or {}).get('automap_generation_policy') == 'draft-v3':
            for field in ('confidence_policy_version', 'confidence_provenance', 'transformation_confidence_score', 'rule_stage',
                          'rule_stage_reason', 'rule_definition_hash', 'rule_candidate_id'):
                row.pop(field, None)
            store = getattr(plan, 'store', None)
            requirements = getattr(store, 'targets', {}).get(target, {})
            explicit_null = bool(re.search(r'\bSQL\s+NULL\b|\bintentional(?:ly)?\s+(?:SQL\s+)?NULL\b',
                str(requirements.get('target_description') or ''), re.I))
            history = getattr(store, 'evidence', {}).get(target, {})
            published_null = any((record.get('pattern') or record).get('mapping_recipe', {}).get('expression') == 'NULL'
                and (record.get('pattern') or record).get('validation_status') in {'published', 'validated', 'accepted'}
                and record.get('applicable') is True
                for category, records in history.items() if 'target_mapping_patterns' in category for record in records)
            if (row.get('mapping_mode') in {'constant', 'value', 'literal'} and 'constant_value' in row
                    and row['constant_value'] is None and (explicit_null or published_null)):
                row['constant_value'] = 'NULL'
            score = row.get('confidence_score')
            row['original_confidence_score'] = score if type(score) in (int, float) and 0 <= score <= 1 else None
            if row['original_confidence_score'] is None:
                row['confidence_score'] = 0.0
        intent = row.get('rule_intent')
        if isinstance(intent, dict) and isinstance(intent.get('required_columns'), list):
            intent['required_columns'] = [reference(item) for item in intent['required_columns']]
        for field in ("source_attributes", "candidate_source_attributes", "source_dependencies", "sources"):
            items = row.get(field)
            if not isinstance(items, list):
                continue
            try:
                converted = [resolve(item) if isinstance(item, dict) else reference(item) for item in items]
                if any(type(item) is not str for item in converted):
                    continue
                row[field] = list(dict.fromkeys(converted))
            except (ValueError, TypeError, AttributeError, ParseError, TokenError):
                # Keep the invalid field intact for target-level schema rejection
                # and focused repair. Other rows retain their valid mappings.
                pass
    return value
