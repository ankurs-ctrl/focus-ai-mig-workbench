# Cumulative release: metadata loading and admin recovery

Apply the ZIP's files/ directory over the repository root. This package includes the previous Auto-map confidence/transformation, SQL-upload validation/preview/publication, project initialization and admin changes. Environment files and credentials are excluded.

Deployment:

1. Run your existing metadata bootstrap/CI step with its existing database/schema configuration. It now runs project-bootstrap-lock.sql immediately after the base DDL, qualifies the lock table with the configured metadata namespace, and validates its inventory before continuing. Keep the existing role/grant process; no new workflow or configuration variables were added.
2. The lock must contain exactly one row keyed project-bootstrap with a nonnegative integer FENCE. An existing valid fence is preserved. Invalid or empty inventory stops bootstrap; nothing is reset or automatically repaired. The SQL uses __STTM_METADATA_NAMESPACE__; do not execute an unrendered placeholder directly in a worksheet.
3. Build and deploy backend, Auto-map worker and frontend together using the normal process. Previous cumulative agent-spec changes still require deploying AGT_SOURCE_MAPPING and AGT_TRANSFORMATION_RULE and their matching manifest. Verify using scripts/verify_mapping_agent_specs.py. No context limits or capacity settings were increased.
4. Verify project creation/retry, reopen a mapping with many sources, and exercise admin recovery with disposable test resources before client promotion.

Metadata loading:

- Row and column counts are catalog metadata. SHOW TABLES and INFORMATION_SCHEMA.COLUMNS aggregates execute concurrently per schema; no COUNT(*) scans of source tables are issued.
- Counts hydrate independently of column definitions when selecting tables and reopening mappings. Catalog values can lag writes; unavailable counts remain unknown. A real zero is shown as zero.
- Column definitions load in batches of 25 with at most two batches active. Failed batches fall back to individual tables, retain successful siblings, and expose per-table retry controls. Successful retry clears that table's error. Existing cache identity and mapping-scope checks remain.
- Pending-request tracking keeps loading active until all batches finish. Column timings are logged, with Snowflake query IDs on query failures when supplied by the connector. Existing HTTP timing diagnostics remain available. The reported client 499 alone does not establish timeout versus cancellation.

Administration:

- Administration → Projects & Mappings has Active, Archived and Deleted · 30 days tabs, with the existing application loading overlay.
- Admins can restore archived resources and recover deleted resources for 30 days after removal. Restore the parent project first. A project restore revives only children removed with that project, preserving separately removed mappings.
- After 30 days, a deleted resource is excluded from the recovery list and restore is rejected. This is a recovery-window policy, not a physical purge: saved/published history remains retained.
- Existing archives/deletions created before prior status and removal timestamps were recorded cannot be safely auto-restored. They require administrative review; the app does not guess published/draft status.
- Successful archive/delete patches local cached lists and aggregates without a full-page reload. Removal is applied only after server success. Project cards group action icons beside the arrow, and long names truncate with their full name available on hover. Existing fonts, icons and UI components are retained.

No client Snowflake resources were modified while implementing this release. No environment-file synchronization, dependency changes, new grants or workflow changes are required. Browser rendering was unavailable in this session; no new screenshot is claimed.
