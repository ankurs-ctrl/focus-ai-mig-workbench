# Auto-map durable runs v2 — 10 November 2026

Source baseline: develop, 33d48a7aa9d45206cc0c382cc00954aece355386. Local source changes only; no client deployment, commit or push is included in this delivery. This document supersedes the earlier fail-fast patch and its ZIP.

## Implemented behavior

- Twelve foreground execution reservations and four separate recovery reservations. Four imported quarantines occupy recovery rows 13–16, leaving rows 1–12 available for new jobs. This is an application concurrency limit; it does not require twelve SPCS instances or establish Snowflake throughput.
- Unknown remote work always remains counted under the total ceiling of sixteen. If all recovery reservations are occupied and further calls become uncertain, those calls must remain counted. The application cannot safely promise unlimited new dispatch during a provider outage. Genuine active saturation queues within a separately bounded admission budget.
- Background Cortex runs use a dedicated thread and one model POST per attempt. Exact requests, digests, scope, submission intent, thread references, provider run IDs, deadlines, recovery leases and due times survive process restart. Missing submission acknowledgements are resolved from the exact original user message, never by blindly replaying the POST.
- Provider cancellation is followed by inspection of the original thread. A timeout, expired lease, HTTP 200 cancellation acknowledgement, HTTP 409 or operator assertion alone never becomes terminal proof. Confirmed results are stored before releasing capacity and reused by a resumed attempt.
- Backend lifespan starts bounded recovery. Independent leases coordinate replicas; failed recovery backs off durably. An expired foreground reservation with an uncertain result moves into available recovery inventory atomically. Original owner/fence checks stop stale release and renewal.
- Deployed custom OAuth recovery restores active original-caller credentials through the application's existing encrypted OAuth session store. Native account/user/role verification and archive access scope still apply. Revoked, missing or mismatched authentication leaves the operation counted; the service identity never performs provider calls as a substitute. No new token store is introduced.
- New durable jobs retain a private SHA-256 reference to the existing OAuth session and its role (never the cookie session ID or token). The web backend discovers expired job leases and resumes frozen envelopes and saved batch receipts without waiting for a browser poll. The existing atomic job lease remains authoritative. Historical jobs with another execution protocol are readable but are not replayed through the new transport.
- Model execution time and admission waiting are accounted separately. Recovery uses a separate bounded caller-session budget. Transient transport retries retain the same frozen operation identity and completed target proposals. Human mapping preservation, selected-target scoping, compiler validation and publication controls continue through the existing workflow.
- Content-addressed archive operations have bounded retries on fresh sessions in v2. A lost COMMIT acknowledgement is handled by reading the exact existing content before writing again. Tests cover failure before and after commit and verify one stored body and no model call from the archive retry.
- Administrator capacity health is read-only at `GET /api/v1/auto-mapping/capacity/health`. The administrator abandonment endpoint requires the exact operation identity, retirement evidence and explicit acknowledgement of an unknown remote outcome. Abandonment is audited and remains counted; it does not fabricate completion.

No frontend/UI files are changed in this package.

## Deployment

Read `ROLLOUT.md` before enabling the profile. The new inventory is incompatible with legacy readers that expect four rows; it uses a distinct `_V2` table. Ordinary CI validation does not migrate or reset live capacity. The new profile must be explicitly selected after migration and permission checks. Actual `.env` files, keys and PATs are excluded from the package.

## Verification

See `TEST-RESULTS.md` and the sanitized live acceptance report supplied with this package. Local tests cover four old quarantines plus twelve simultaneous new reservations, the hard ceiling, duplicate identity, stale fences, lost acknowledgements, crash/restart recovery, cancellation outcomes, OAuth authentication boundaries, immutable archive receipts and migration repeatability. These offline checks do not establish client account behavior or twelve-call provider throughput.

The live test uses this system's separate Snowflake account, existing semantics in `FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS`, and an isolated disposable schema. It exercises the application source-mapping batch, native v2 migration twice, read-only inventory validation and actual Cortex background execution. It does not publish or alter business mappings. Evidence/citation warnings remain review requirements even when an executable candidate passes validation.

## Findings from the full-table live test

The full fixture covers all 33 physical columns of `BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION`, with nine normal batches of three or four columns. It exposed native Snowpark error wrapping: SQL timeout 630 is in `sql_error_code`, while the wrapper's `errno` is 1304. Admission now recognizes only the existing allowlisted native timeout codes after an acknowledged rollback; lost COMMIT/ROLLBACK acknowledgements remain uncertain. Regression tests instantiate the real Snowpark exception type.

The run also exposed obsolete transient warnings surviving a successful retry. A batch is now marked recovered only when every requested target has a selected, independently valid candidate, the latest attempt has no transport failure and no response error. Genuine validation/business warnings stay visible, and prior attempt failure kinds remain in technical history. A test with an invalid replacement verifies that the failure warning is retained.
