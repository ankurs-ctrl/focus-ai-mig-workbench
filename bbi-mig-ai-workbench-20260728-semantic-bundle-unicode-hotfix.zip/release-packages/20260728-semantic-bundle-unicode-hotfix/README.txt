Semantic bundle Unicode persistence hotfix

Copy this file into the client repository root and allow it to overwrite the
existing source:

  services/sttm-builder/app/core/semantic_context.py

Then rebuild and redeploy the SPCS services. Do not use -SkipBuild because this
is a Python application-code change:

  .\scripts\deploy_spcs_client_snow_safe.ps1 `
    -EnvFile ".\infra\snowflake\env\client.env"

The fix binds semantic bundle and projection JSON as Snowpark query parameters
instead of interpolating JSON into SQL literals. Unicode, backslashes, quotes,
and control-character escapes therefore reach PARSE_JSON without SQL parsing
ambiguity.
