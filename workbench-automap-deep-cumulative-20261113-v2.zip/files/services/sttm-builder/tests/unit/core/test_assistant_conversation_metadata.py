from app.agent_runs.repository import SnowflakeAgentRunRepository
from app.assistant_conversations import ConversationUpdateRequest, SnowflakeAssistantConversationRepository


class _Session:
    def __init__(self) -> None:
        self.statements: list[tuple[str, list[object]]] = []

    def sql(self, statement: str, params: list[object]):
        self.statements.append((statement, params))
        return self

    def collect(self):
        return []


def test_generated_project_links_only_an_unassigned_owned_chat() -> None:
    session = _Session()
    repository = SnowflakeAgentRunRepository(session, database="DB", schema="META")
    repository.link_unassigned_conversation_to_project("chat-1", "project-1", user_id="user-1", tenant_id="tenant-1")
    statement, params = session.statements[0]
    assert "PROJECT_ID IS NULL" in statement
    assert "ACTOR_USER_ID=? AND TENANT_ID=?" in statement
    assert params == ["project-1", "chat-1", "user-1", "tenant-1"]


def test_project_move_clears_mapping_scope_and_keeps_owner_filter() -> None:
    session = _Session()
    repository = SnowflakeAssistantConversationRepository(session, database="DB", schema="META")
    repository.get = lambda *args, **kwargs: type("Chat", (), {"status": "ACTIVE"})()  # type: ignore[method-assign]
    repository.update_metadata(
        "chat-1", ConversationUpdateRequest(project_id="project-2", pinned=True),
        user_id="user-1", tenant_id="tenant-1",
    )
    statement, params = session.statements[0]
    assert "STTM_ID=NULL" in statement
    assert "ACTOR_USER_ID=? AND TENANT_ID=?" in statement
    assert params == ["project-2", True, "chat-1", "user-1", "tenant-1"]
