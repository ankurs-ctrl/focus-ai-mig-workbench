from __future__ import annotations

import asyncio
from threading import Lock
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.agent_runs.attachments import AttachmentService, AttachmentValidationError
from app.agent_runs.events import encode_sse
from app.agent_runs.models import (
    AgentActor,
    AgentAttachment,
    AgentRun,
    AgentRunEvent,
    RunAnswerRequest,
    RunCancelRequest,
    RunCreateRequest,
    RunResumeRequest,
    RunStateResponse,
    TERMINAL_RUN_STATUSES,
)
from app.agent_runs.repository import SnowflakeAgentRunRepository
from app.agent_runs.service import (
    AgentRunService,
    RunAuthorizationError,
    RunConflictError,
    RunNotFoundError,
)
from app.api.deps import get_agent_event_snowflake_client, get_snowflake_client
from app.auth.dependencies import get_current_principal
from app.core.config import Settings, get_settings
from app.core.snowflake import SnowflakeClient, SnowflakeSessionLeasePool
from app.core.warehouse_routing import WarehouseWorkload
from app.schema.contracts import ApiResponseEnvelope, build_response_envelope
from app.agent_tools.capability_registry import CapabilityRegistry

router = APIRouter(prefix="/agent-runs", tags=["Migration Agent"])

# Poll quickly while a run is producing events, back off when idle, and keep
# a short drain window after the run turns terminal.
_STREAM_ACTIVE_POLL_SECONDS = 0.3
_STREAM_IDLE_POLL_SECONDS = 1.0
_STREAM_TERMINAL_DRAIN_SECONDS = 4.0
_LOCAL_STREAM_POOL_SIZE = 8
_LOCAL_STREAM_POOLS: dict[str, SnowflakeSessionLeasePool] = {}
_LOCAL_STREAM_POOLS_LOCK = Lock()


def _local_stream_pool(settings: Settings, role: str) -> SnowflakeSessionLeasePool:
    with _LOCAL_STREAM_POOLS_LOCK:
        pool = _LOCAL_STREAM_POOLS.get(role)
        if pool is None:
            pool = SnowflakeSessionLeasePool(
                settings=settings, user_token="", role=role,
                workload=WarehouseWorkload.CONTROL, maximum=_LOCAL_STREAM_POOL_SIZE,
            )
            _LOCAL_STREAM_POOLS[role] = pool
        return pool


def _actor(request: Request) -> AgentActor:
    principal = get_current_principal(request)
    return AgentActor(
        app_user_id=str(principal.user_id),
        snowflake_username=principal.snowflake_user,
        tenant_id=str(getattr(principal, "tenant_id", None) or "default"),
        effective_role=principal.snowflake_role or principal.app_persona.value,
        actor_type="user",
        delegation_ref=principal.oauth_session_id,
    )


def _require_edit(request: Request) -> None:
    if not get_current_principal(request).permissions.can_edit:
        raise HTTPException(status_code=403, detail="Migration Agent draft operations require edit permission")


def _service(client: SnowflakeClient, settings: Settings) -> AgentRunService:
    from app.agent_runs.review_apply import make_draft_writer

    return AgentRunService(
        SnowflakeAgentRunRepository(
            client.session,
            database=settings.snowflake_database,
            schema=settings.snowflake_schema,
        ), settings=settings, draft_writer=make_draft_writer(client.session, settings),
    )


def _translate_error(exc: Exception) -> HTTPException:
    if isinstance(exc, RunNotFoundError):
        return HTTPException(status_code=404, detail=str(exc))
    if isinstance(exc, RunAuthorizationError):
        return HTTPException(status_code=403, detail=str(exc))
    if isinstance(exc, RunConflictError):
        return HTTPException(status_code=409, detail=str(exc))
    return HTTPException(status_code=400, detail=str(exc))


@router.get("/capabilities")
def capabilities(
    request: Request,
    settings: Annotated[Settings, Depends(get_settings)],
) -> dict[str, Any]:
    principal = get_current_principal(request)
    return {
        "enabled": settings.migration_agent_enabled and principal.permissions.can_edit,
        "can_create_drafts": principal.permissions.can_edit,
        "effort_levels": ["auto", "light", "medium", "high"],
        "model_options": list(dict.fromkeys(filter(None, (
            settings.migration_agent_model_light,
            settings.migration_agent_model_medium,
            settings.migration_agent_model_high,
        )))),
        "effort_model_defaults": {
            "light": settings.migration_agent_model_light,
            "medium": settings.migration_agent_model_medium,
            "high": settings.migration_agent_model_high,
        },
        "supported_attachments": [".sql", ".xlsx", ".csv", ".txt", ".md", ".json", ".yaml", ".yml", ".docx", ".pdf", ".srt", ".vtt"],
        "max_attachment_mb": 10,
        "terminal_success_states": ["READY_FOR_REVIEW", "COMPLETED_WITH_REVIEW_ITEMS"],
        "publish_available": False,
        "publish_requires_exact_artifact_approval": True,
        "plan_mode": {
            "read_only_analysis_before_approval": True,
            "draft_execution_requires_approval": True,
            "publishes_sttm": False,
            "analysis_scales_with_effort": True,
        },
        "sandbox": {
            "model_workspace": "virtual_state_only",
            "host_shell": False,
            "host_filesystem": False,
            "direct_network": False,
            "snowflake_execution": "delegated_role_read_only",
            "allowed_sql": ["SELECT", "WITH"],
            "preview_max_rows": settings.migration_agent_sql_preview_max_rows,
            "statement_timeout_seconds": settings.migration_agent_sql_timeout_seconds,
            "result_max_bytes": settings.migration_agent_sql_result_max_bytes,
            "ddl_dml_call_allowed": False,
        },
        "context_management": {
            "durable_follow_up_evidence": True,
            "read_cache_within_run": True,
            "reuse_catalog_contracts_and_receipts": True,
            "refresh_on_scope_role_hash_or_revision_change": True,
        },
        "tool_contracts": CapabilityRegistry.public_contracts(),
        "feature_flags": {
            "unified_history": settings.assistant_unified_history_v1,
            "intent_routing": settings.assistant_intent_routing_v1,
            "true_resume": settings.migration_agent_true_resume_v1,
            "host_terminalization": settings.migration_agent_host_terminalization_v1,
            "tool_governance": settings.migration_agent_tool_governance_v1,
        },
    }


@router.post("", status_code=202, response_model=ApiResponseEnvelope[AgentRun])
def create_run(
    request: Request,
    body: RunCreateRequest,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[AgentRun]:
    if not settings.migration_agent_enabled:
        raise HTTPException(status_code=503, detail="Migration Agent is not enabled in this environment")
    _require_edit(request)
    # The legacy (non-conversation) path has no intent router. Apply the same
    # deterministic classification so a greeting or an open question is not
    # held to the governed-migration completion rule.
    if not str(body.page_context.get("continuation_kind") or ""):
        from app.assistant_conversations import is_explicit_migration_request, is_greeting_or_capability_question
        if is_greeting_or_capability_question(body.prompt):
            body.page_context["continuation_kind"] = "READ_ONLY_QA"
        elif not is_explicit_migration_request(body.prompt):
            body.page_context["continuation_kind"] = "OPEN_REQUEST"
    try:
        run = _service(client, settings).create_run(body, _actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(
        operation="agent_runs.create",
        request=request,
        data=run,
    )


@router.get("/latest", response_model=ApiResponseEnvelope[RunStateResponse])
def get_latest_run(
    request: Request,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[RunStateResponse]:
    """Restore the caller's latest durable conversation after navigation or refresh."""
    try:
        state = _service(client, settings).get_latest_state(_actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.latest", request=request, data=state)


@router.get("/{run_id}", response_model=ApiResponseEnvelope[RunStateResponse])
def get_run(
    request: Request,
    run_id: str,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[RunStateResponse]:
    try:
        state = _service(client, settings).get_state(run_id, _actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.get", request=request, data=state)


@router.get("/{run_id}/events")
async def get_events(
    request: Request,
    run_id: str,
    client: Annotated[SnowflakeClient | None, Depends(get_agent_event_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
    after: int = Query(default=0, ge=0),
    follow: bool = Query(default=False),
):
    last_event_id = request.headers.get("last-event-id")
    if last_event_id and after == 0:
        try:
            after = max(0, int(last_event_id))
        except ValueError:
            raise HTTPException(status_code=400, detail="Last-Event-ID must be a run event cursor")
    actor = _actor(request)
    if not follow:
        if client is None:
            raise HTTPException(status_code=500, detail="Event store session is unavailable")
        service = _service(client, settings)
        try:
            events = service.list_events(run_id, actor, after=after)
        except Exception as exc:
            raise _translate_error(exc) from exc
        return build_response_envelope(operation="agent_runs.events", request=request, data=events)

    # A long-lived SSE response must not poll through the request-scoped cached
    # Snowpark client. Snowpark sessions are not safe for concurrent statements;
    # sharing the polling session made answer/cancel requests wait behind the
    # stream. Each live stream therefore owns a session exclusively — leased
    # from a small pool in local dev (a fresh externalbrowser login per stream
    # is an SSO round trip) and opened per stream for delegated OAuth tokens.
    principal = get_current_principal(request)
    stream_role = principal.snowflake_role or actor.effective_role

    async def open_stream_client():
        if settings.local_dev_auth_enabled:
            lease = _local_stream_pool(settings, stream_role).lease()
            client = await asyncio.to_thread(lease.__enter__)
            return client, lease
        client = await asyncio.to_thread(
            SnowflakeClient, settings=settings,
            user_token=principal.snowflake_user_token, role=stream_role,
        )
        return client, None

    async def stream():
        cursor = after
        terminal = False
        terminal_seen_at: float | None = None
        idle_delay = _STREAM_ACTIVE_POLL_SECONDS
        idle_polls = 0
        stream_client, lease = await open_stream_client()
        failed: BaseException | None = None
        in_flight = False

        async def on_session(call, *args, **kwargs):
            nonlocal in_flight
            in_flight = True
            result = await asyncio.to_thread(call, *args, **kwargs)
            in_flight = False
            return result

        try:
            repository = _service(stream_client, settings).repository
            # Ownership cannot change for the life of a run; verify it once
            # rather than re-reading the full run payload on every poll.
            run = await on_session(repository.get_run, run_id)
            if run is None:
                return
            AgentRunService._assert_owner(run, actor)
            terminal = run.status in TERMINAL_RUN_STATUSES
            while True:
                if await request.is_disconnected():
                    return
                # Snowflake calls are synchronous. Running them directly inside
                # this async generator blocked unrelated API requests and made a
                # healthy worker look stalled while the event stream was polling.
                events = await on_session(repository.list_events, run_id, after=cursor)
                if events:
                    cursor = events[-1].sequence
                    terminal_seen_at = None
                    idle_polls = 0
                    idle_delay = _STREAM_ACTIVE_POLL_SECONDS
                    yield encode_sse(events)
                else:
                    idle_polls += 1
                    # Terminal state changes rarely; a narrow run read every few
                    # idle polls replaces the four-query state snapshot.
                    if terminal or idle_polls == 1 or idle_polls % 4 == 0:
                        current = await on_session(repository.get_run, run_id)
                        terminal = bool(current and current.status in TERMINAL_RUN_STATUSES)
                    if terminal:
                        # The worker persists terminal state and its final trace
                        # in separate committed operations. Drain briefly so the
                        # stream cannot close just before assistant.final or
                        # evaluation events become visible.
                        now = asyncio.get_running_loop().time()
                        terminal_seen_at = terminal_seen_at or now
                        if now - terminal_seen_at >= _STREAM_TERMINAL_DRAIN_SECONDS:
                            return
                    yield ": keep-alive\n\n"
                    idle_delay = min(_STREAM_IDLE_POLL_SECONDS, idle_delay * 1.5)
                await asyncio.sleep(idle_delay)
        except (GeneratorExit, asyncio.CancelledError) as exc:
            # A browser closing its stream is normal. The session is reusable
            # unless a statement was still running on it in a worker thread.
            if in_flight:
                failed = exc
            raise
        except BaseException as exc:
            failed = exc
            raise
        finally:
            if lease is not None:
                # An errored session is discarded by the pool, a healthy one reused.
                lease.__exit__(type(failed) if failed else None, failed, failed.__traceback__ if failed else None)
            else:
                stream_client.close()

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/{run_id}/answer", response_model=ApiResponseEnvelope[AgentRun])
def answer_run(
    request: Request,
    run_id: str,
    body: RunAnswerRequest,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[AgentRun]:
    _require_edit(request)
    try:
        run = _service(client, settings).answer(run_id, body, _actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.answer", request=request, data=run)


@router.get("/{run_id}/review-table")
def get_review_table(
    request: Request,
    run_id: str,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[dict]:
    """Planning questions, confidence rows and blockers for the run, one row per decision."""
    try:
        table = _service(client, settings).review_table(run_id, _actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.review_table", request=request, data=table)


class ReviewRowsAcceptRequest(BaseModel):
    row_ids: list[str] = Field(min_length=1, max_length=500)
    row_digests: dict[str, str] = Field(default_factory=dict)
    expected_run_revision: int | None = None


@router.post("/{run_id}/review-table/accept")
def accept_review_rows(
    request: Request,
    run_id: str,
    body: ReviewRowsAcceptRequest,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[dict]:
    """Confirm proposed confidence rows as they are (the bulk "Accept" action)."""
    _require_edit(request)
    try:
        result = _service(client, settings).accept_review_rows(
            run_id, body.row_ids, _actor(request), row_digests=body.row_digests,
            expected_run_revision=body.expected_run_revision)
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.review_table.accept", request=request, data=result)


@router.post("/{run_id}/cancel", response_model=ApiResponseEnvelope[AgentRun])
def cancel_run(
    request: Request,
    run_id: str,
    body: RunCancelRequest,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[AgentRun]:
    _require_edit(request)
    try:
        run = _service(client, settings).cancel(run_id, body, _actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.cancel", request=request, data=run)


@router.post("/{run_id}/resume", response_model=ApiResponseEnvelope[AgentRun])
def resume_run(
    request: Request,
    run_id: str,
    body: RunResumeRequest,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[AgentRun]:
    if not settings.migration_agent_true_resume_v1:
        raise HTTPException(status_code=503, detail="Durable run resume is not enabled")
    _require_edit(request)
    try:
        run = _service(client, settings).resume(run_id, body, _actor(request))
    except Exception as exc:
        raise _translate_error(exc) from exc
    return build_response_envelope(operation="agent_runs.resume", request=request, data=run)


@router.post("/attachments", status_code=201, response_model=ApiResponseEnvelope[AgentAttachment])
async def upload_attachment(
    request: Request,
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    settings: Annotated[Settings, Depends(get_settings)],
    file: UploadFile = File(...),
) -> ApiResponseEnvelope[AgentAttachment]:
    if not settings.migration_agent_enabled:
        raise HTTPException(status_code=503, detail="Migration Agent is not enabled in this environment")
    _require_edit(request)
    actor = _actor(request)
    content = await file.read()
    try:
        attachment = AttachmentService(
            client.session,
            stage_prefix=settings.migration_agent_attachment_stage,
        ).ingest(
            filename=file.filename or "",
            content=content,
            owner_user_id=actor.user_id,
            tenant_id=actor.tenant_id,
        )
    except AttachmentValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return build_response_envelope(
        operation="agent_runs.attachments.create",
        request=request,
        data=attachment,
    )
