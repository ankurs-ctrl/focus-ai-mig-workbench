const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const h = require('./test-automap-preservation.cjs');
const sheetFile = path.resolve(__dirname, '../src/features/sttm/mapping/sheet-candidates.ts');
const sheet = new Module(sheetFile, module);
sheet._compile(ts.transpileModule(fs.readFileSync(sheetFile, 'utf8'), {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,sheetFile);
const candidate = (id='one', changes={}) => ({candidate_id:id,source_attributes:['src.Name'],source_dependencies:['src.Name'],
  confidence_score:.3,confidence_reason:'Business evidence for '+id,preprocessing_rule_type:'Direct',mapping_mode:'source',
  transformation_classification:'direct',validation_status:'valid',validation_errors:[],warnings:[],value_binding_ids:[],...changes});
function begin(state) { h.reducer(h.pendingReducer)(state,{meta:{requestId:'sheet-run'}}); }
function deliver(state, options, changes={}) {
 h.helpers.applyAutoMapResponseToState(state,h.response({...options[0],candidates:options,...changes}));
}
function findInitializer(ast,name) {
 let result;
 function visit(node) { if(node.initializer && node.name?.getText(ast)===name) result=node.initializer;ts.forEachChild(node,visit); }
 visit(ast);assert.ok(result,name);return result;
}
const dependencies={...h.helpers,...sheet.exports};
const capture=h.compile(h.functions(h.slice,['captureManualEditSnapshot'])+';return captureManualEditSnapshot;',dependencies);
function reducer(name) {return h.compile(`return (${findInitializer(h.slice,name).getText(h.slice)});`,{...dependencies,captureManualEditSnapshot:capture});}
function stateFor(...rows) {return {...h.stateFor(...rows),mappingLoading:false,derivedSources:[],relationships:[],sources:[],sourceQueryModifiers:{}};}
function selectionHarness(state, compile) {
 const writes=[];const sent=[];let values=[{attribute_id:'firm',attribute_name:'FIRM',attribute_value:'approved'}];
 const callback=findInitializer(h.slice,'selectSheetCandidate').arguments[1].getText(h.slice);
 const select=h.compile(`return (${callback});`,{...dependencies,
  listProjectAttributes:async()=>values,
  resolveSelectedSourceTables:()=>[],
  buildRelationGraph:(_s,_d,_j,_m,currentValues)=>({nodes:[],edges:[],value_bindings:currentValues}),
  dbService:{compileMappingSql:async payload=>{sent.push(payload);return compile ? compile(payload) : {valid:true,ready:true,unresolved_placeholders:[],warnings:[]};}},
  sheetCandidateValidated:payload=>({type:'valid',payload}),
  sheetCandidateInvalidated:payload=>({type:'invalid',payload}),
 });
 return {sent,writes,setValues:next=>{values=next;},select:options=>select(options,{getState:()=>({sttmBuilder:state}),dispatch:action=>{writes.push(action);reducer(action.type==='invalid'?'sheetCandidateInvalidated':'sheetCandidateValidated')(state,action);}})};
}

test('Auto-map fills a blank draft with a low-confidence valid choice and no chat queue',()=>{
 const state=stateFor(h.blank());begin(state);
 deliver(state,[candidate('bad',{confidence_score:.99,validation_status:'invalid',validation_errors:['Missing column']}),candidate()]);
 assert.equal(state.mappings[0].sourceColumn,'src.Name');
 assert.equal(state.mappings[0].confidenceScore,.3);
 assert.equal(state.mappings[0].aiReviewStatus,'unreviewed');
 assert.equal(state.mappings[0].selectedAiCandidateId,'one');
 assert.equal(state.mappings[0].status,'MAPPED');
 assert.equal(state.pendingAiMappingReviews.length,0);
 assert.equal(state.mappings[0].aiCandidates[0].validation_status,'invalid');
});

test('complete alternatives preserve every field and do not manufacture missing alternatives',()=>{
 const result=sheet.exports.rankedRowCandidates([candidate('rule',{preprocessing_rule:'TRIM(src.Name)',preprocessing_rule_type:'Custom'}),candidate('value',{source_attributes:[],mapping_mode:'attribute',attribute_name:'FIRM',constant_value:'$FIRM',value_binding_ids:['firm']})]);
 assert.equal(result.length,2);assert.equal(result[0].preprocessing_rule,'TRIM(src.Name)');
 assert.deepEqual(result[1].value_binding_ids,['firm']);assert.equal(result[1].confidence_reason,'Business evidence for value');
 assert.equal(sheet.exports.rankedRowCandidates([candidate()]).length,1);
});

test('human-authored and confirmed definitions remain unchanged while alternatives appear in the row',()=>{
 for(const row of [h.imported(),{...h.imported(),aiReviewStatus:'confirmed'},{...h.imported(),manuallySaved:true}]) {
  const state=stateFor(structuredClone(row));begin(state);deliver(state,[candidate()]);
  for(const field of ['expression','sourceColumn','sourceColumns','rule','mappingMode']) assert.deepEqual(state.mappings[0][field],row[field]);
  assert.equal(state.mappings[0].aiCandidates.length,1);assert.equal(state.pendingAiMappingReviews.length,0);
 }
});

test('unavailable Values and invalid SQL cannot become executable draft mappings',()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate('bad',{validation_status:'invalid',validation_errors:['Missing Value']})]);
 assert.equal(state.mappings[0].status,'UNMAPPED');assert.equal(state.mappings[0].selectedAiCandidateId,null);
 assert.equal(state.mappings[0].sourceColumn,null);
});

test('only checked target rows receive draft suggestions',()=>{
 const state=stateFor(h.blank(),h.blank('OTHER'));state.selectedMappingIds=['NAME'];begin(state);
 deliver(state,[candidate()]);assert.equal(state.mappings[1].aiCandidates,undefined);assert.equal(state.mappings[1].sourceColumn,null);
});

test('switching validates first then atomically changes source, mode, rule and dependencies',async()=>{
 const state=stateFor(h.blank());begin(state);deliver(state,[candidate(),candidate('rule',{source_attributes:['src.Other'],source_dependencies:['src.Other'],preprocessing_rule:'TRIM(src.Other)',preprocessing_rule_type:'Custom',transformation_classification:'complex'})]);
 state.mappingLoading=false;state.autoMapRun=null;
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'rule'});
 const row=state.mappings[0];assert.equal(row.sourceColumn,'src.Other');assert.equal(row.rule,'Custom');assert.equal(row.expression,'TRIM(src.Other)');
 assert.deepEqual(row.sourceDependencies,['src.Other']);assert.equal(row.aiReviewStatus,'unreviewed');
 assert.equal(harness.sent[0].validate_with_explain,true);assert.equal(harness.sent[0].allow_unresolved_placeholders,false);
 assert.equal(harness.sent[0].project_id,'project');assert.equal(harness.sent[0].relation_graph.value_bindings[0].attribute_value,'approved');
});

test('validation failure or changed input never applies the candidate',async()=>{
 for(const mode of ['invalid','race']) {
  const state=stateFor({...h.blank(),aiCandidates:[candidate()],aiReviewStatus:null});
  const harness=selectionHarness(state,async()=>{
   if(mode==='race')state.mappings[0].expression='user changed';
   return {valid:mode!=='invalid',ready:true,unresolved_placeholders:[],warnings:['Invalid rule']};
  });
  await assert.rejects(harness.select({mappingId:'NAME',candidateId:'one'}),mode==='invalid'?/Invalid rule/:/changed/);
  assert.equal(harness.writes.length,mode==='invalid'?1:0);assert.equal(state.mappings[0].sourceColumn,null);
  if(mode==='invalid')assert.equal(state.mappings[0].aiCandidates[0].validation_status,'invalid');
 }
});

test('confirmation is validated and undo restores the complete earlier definition',async()=>{
 const row={...h.blank(),aiCandidates:[candidate()]};const state=stateFor(row);
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'one',confirm:true});
 assert.equal(row.aiReviewStatus,'confirmed');assert.equal(row.confidenceScore,.3);assert.equal(row.selectedAiCandidateId,'one');
 reducer('undoSheetSuggestion')(state,{payload:'NAME'});
 assert.equal(row.sourceColumn,null);assert.equal(row.expression,null);assert.equal(row.status,'UNMAPPED');assert.equal(row.aiReviewStatus,null);
 assert.equal(row.aiCandidates.length,1);assert.equal(row.aiUndoSnapshot,null);assert.deepEqual(row.sourceColumns,[]);assert.deepEqual(row.sourceDependencies,[]);assert.equal(row.confidenceScore,null);
});

test('manual edits clear candidate selection and protect the edited definition on another Auto-map',()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};const state=stateFor(row);
 reducer('updateMapping')(state,{payload:{id:'NAME',updates:{expression:'UPPER(src.Name)',rule:'Custom'}}});
 assert.equal(row.aiReviewStatus,'edited');assert.equal(row.selectedAiCandidateId,null);
 assert.equal(row.expression,'UPPER(src.Name)');
});

test('candidate details, selection, review and undo survive workspace JSON and reopen recovery',()=>{
 const file=path.resolve(__dirname,'../src/features/sttm/context/workbench-context.ts');
 const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true);
 const mappingRows=findInitializer(ast,'mapping_rows').getText(ast);
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()],aiReviewStatus:'confirmed',aiUndoSnapshot:{sourceColumn:null,status:'UNMAPPED'}};
 const rows=h.compile(`return (${mappingRows});`,{input:{mappings:[row]}});
 const recoveryFile=path.resolve(__dirname,'../src/features/sttm/shared/mapping-row-recovery.ts');
 const recovery=ts.createSourceFile(recoveryFile,fs.readFileSync(recoveryFile,'utf8'),ts.ScriptTarget.Latest,true);
 const recover=h.compile(h.functions(recovery,['savedMappingEvidence'])+';return savedMappingEvidence;');
 const restored=recover(JSON.parse(JSON.stringify(rows[0])));
 assert.deepEqual(restored.aiCandidates,row.aiCandidates);assert.equal(restored.selectedAiCandidateId,'one');
 assert.equal(restored.aiReviewStatus,'confirmed');assert.deepEqual(restored.aiUndoSnapshot,row.aiUndoSnapshot);
});

test('candidate confirmation saves a draft choice without committing another row’s pending manual edits',async()=>{
 const row={...h.blank(),aiCandidates:[candidate()]};const other={...h.blank('OTHER'),expression:'manual draft'};
 const state=stateFor(row,other);state.pendingManualEditSnapshots.OTHER={...other,expression:null};
 const harness=selectionHarness(state);
 await harness.select({mappingId:'NAME',candidateId:'one',confirm:true});
 assert.equal(row.aiReviewStatus,'confirmed');assert.equal(state.pendingManualEditSnapshots.NAME,undefined);
 assert.equal(state.pendingManualEditSnapshots.OTHER.expression,null);assert.equal(other.expression,'manual draft');
 assert.equal(state.autoMapBlockedByManualEdits,true);
});

test('an already selected AI option becomes unresolved if its current Value or SQL validation fails',async()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate()]};
 const state=stateFor(row);
 const harness=selectionHarness(state,async()=>({valid:false,ready:false,unresolved_placeholders:['$FIRM'],warnings:['Value unavailable']}));
 await assert.rejects(harness.select({mappingId:'NAME',candidateId:'one',confirm:true}),/Value unavailable/);
 assert.equal(row.status,'UNMAPPED');assert.equal(row.selectedAiCandidateId,null);assert.equal(row.aiReviewStatus,null);
 assert.equal(row.aiCandidates[0].validation_status,'invalid');assert.equal(row.unmatchedReason,'Value unavailable');
});

test('an invalid replacement does not demote a different valid current choice',async()=>{
 const row={...h.blank(),...sheet.exports.candidateRowUpdates(candidate()),aiCandidates:[candidate(),candidate('other',{source_attributes:['src.Other']})]};
 const state=stateFor(row);
 const harness=selectionHarness(state,async()=>({valid:false,ready:false,unresolved_placeholders:[],warnings:['Column unavailable']}));
 await assert.rejects(harness.select({mappingId:'NAME',candidateId:'other'}),/Column unavailable/);
 assert.equal(row.status,'MAPPED');assert.equal(row.selectedAiCandidateId,'one');assert.equal(row.sourceColumn,'src.Name');
 assert.equal(row.aiCandidates[1].validation_status,'invalid');
});

test('chat receives only draft suggestion, low-confidence and unresolved counts',()=>{
 const state=stateFor(h.blank(),h.blank('OTHER'));begin(state);deliver(state,[candidate()]);
 h.reducer(h.fulfilledReducer)(state,{meta:{requestId:'sheet-run'},payload:{sheetReviewV1:true,totalCount:2,failedTargets:[],autoMapOutcome:null}});
 assert.equal(state.chatMessages.length,1);
 assert.match(state.chatMessages[0].content,/filled 1 draft targets/);
 assert.match(state.chatMessages[0].content,/1 low confidence/);
 assert.match(state.chatMessages[0].content,/1 targets remain unresolved/);
 assert.equal(state.pendingAiMappingReviews.length,0);
 assert.doesNotMatch(state.chatMessages[0].content,/Apply Changes|accept.*queue/i);
});
