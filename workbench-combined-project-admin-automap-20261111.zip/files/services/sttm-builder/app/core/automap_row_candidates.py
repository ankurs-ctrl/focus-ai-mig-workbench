"""Complete, independently validated draft options. Model validity claims are ignored."""
from __future__ import annotations

import hashlib
import json

from app.core.mapping_sql import MappingSqlService
from app.core.automap_suggestions import concrete_option, row_suggestions
from app.core.automap_retrieval import target_name
from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
from app.schema.sttm_builder import AttributeMapping, MappingCandidate, SourceMappingResult, MappingSuggestion, JoinRecommendation, CandidateScoringIssue, STTMStatus


def candidate_identity(option) -> str:
    fields = ("source_attributes", "mapping_mode", "constant_value", "attribute_name",
              "preprocessing_rule", "preprocessing_rule_type", "source_dependencies", "value_binding_ids")
    return hashlib.sha256(json.dumps({key: getattr(option, key) for key in fields},
                                    sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:24]


SCORING_POLICY_VERSION = "draft-caps-v1"
SCORING_META_KEY = "automap_scoring_policy_version"


def requested_target(attributes, name):
    from sqlglot import exp, parse_one
    def key(text):
        try:
            tree = parse_one(text, read="snowflake")
            if not isinstance(tree, exp.Column):
                return None
            return tuple(part.name if part.args.get("quoted") else part.name.upper() for part in tree.parts)
        except Exception:
            return None
    incoming = key(name)
    for attribute in attributes:
        if incoming and incoming in {key(attribute.target_attribute), key(
                attribute.target_table.qualified_name + "." + attribute.target_attribute)}:
            return target_name(attribute.target_attribute)
    return None


def proposal(option):
    """Snapshot a concrete definition, never a shortlist or explanatory prose."""
    import re
    expression = option.preprocessing_rule or ""
    has_binding = any(isinstance(source, str) and source.strip() for source in option.source_attributes)
    has_value = (option.mapping_mode == "constant" and option.constant_value is not None) or (
        option.mapping_mode == "attribute" and bool((option.attribute_name or "").strip()))
    # Labels, error prose and source shortlists are not executable proposals.
    sql_shaped = bool(re.fullmatch(r"\s*(?:NULL|TRUE|FALSE|CURRENT_DATE|CURRENT_TIMESTAMP)\s*", expression, re.I)) or bool(re.match(r'''\s*(?:\$[A-Za-z_]|[('"0-9+-]|(?:CASE|SELECT|WITH)\b|(?:[A-Za-z_][\w$]*|"[^"]+")\s*[.(])''', expression, re.I))
    pending_value_rule = bool(option.value_binding_ids and option.rule_intent)
    if not (concrete_option(option) or pending_value_rule) or not (has_binding or has_value or sql_shaped or pending_value_rule):
        return None
    body = option.model_dump(include=set(MappingCandidate.model_fields))
    if "original_confidence_score" not in option.model_fields_set:
        body["original_confidence_score"] = option.confidence_score
    return MappingCandidate.model_validate(body)


def retain_proposals(mapping, *previous):
    # Keep a bounded transport roster; final validation ranks all retained options.
    unique = {}
    for item in (mapping, *previous):
        for option in [*getattr(item, "candidates", []), item]:
            captured = proposal(option)
            if captured is not None:
                identity = candidate_identity(captured)
                old = unique.get(identity)
                if old is not None:
                    evidence = list(dict.fromkeys(warning for value in (old, captured) for warning in value.warnings
                        if warning.startswith("Malformed proposal field")))
                    old.warnings = list(dict.fromkeys([*old.warnings, *evidence]))
                    captured.warnings = list(dict.fromkeys([*captured.warnings, *evidence]))
                score = lambda value: value.original_confidence_score if value.original_confidence_score is not None else -1
                if old is None or score(captured) > score(old) or (score(captured) == score(old)
                        and ((captured.scoring_policy_version and not old.scoring_policy_version)
                             or (captured.scoring_policy_version == old.scoring_policy_version
                                 and captured.scoring_issues and not old.scoring_issues))):
                    unique[identity] = captured
    # At most four options can cross the response contract. Never evict the
    # current definition just because an earlier round supplied more options.
    values = list(unique.values())
    primary = proposal(mapping)
    if len(values) > 4 and primary is not None:
        primary_id = candidate_identity(primary)
        current = unique[primary_id]
        values = [current, *[item for item in values if candidate_identity(item) != primary_id][-3:]]
    return mapping.model_copy(update={"candidates": values[:4]})


def record_proposal(mapping, previous=None, *, messages=(), category="validation", warning=False):
    """Replace admission evidence for this exact definition, retaining other drafts."""
    current = proposal(mapping)
    roster = retain_proposals(mapping, *([previous] if previous is not None else [])).candidates
    if current is not None:
        matching = next((item for item in roster if candidate_identity(item) == candidate_identity(current)), None)
        if matching is not None:
            current = current.model_copy(update={"original_confidence_score": matching.original_confidence_score})
        current = current.model_copy(update={"scoring_policy_version": SCORING_POLICY_VERSION,
            "scoring_issues": [CandidateScoringIssue(
            code="capture_" + category, message=str(message)[:2000], category=category,
            severity="warning" if warning else "error") for message in messages]})
        roster = [current if candidate_identity(item) == candidate_identity(current) else item for item in roster]
    return mapping.model_copy(update={"candidates": roster})


def source_bindings(raw):
    """Validate presence before choosing an alias; falsy malformed evidence is not absence."""
    normalized = {}
    for field in ("sources", "source_attributes"):
        if field not in raw:
            continue
        values = raw[field]
        if not isinstance(values, list):
            raise ValueError(field + " must be a list")
        references = []
        for value in values:
            if isinstance(value, str):
                references.append(value)
            elif isinstance(value, dict) and field == "sources":
                table = value.get("table")
                column = value.get("column", value.get("attribute"))
                if not isinstance(column, str) or not column.strip() or (
                        table is not None and (not isinstance(table, str) or not table.strip())):
                    raise ValueError(field + " contains an unusable source object")
                references.append(f"{table}.{column}" if table is not None else column)
            else:
                raise ValueError(field + " contains an unusable source binding")
        normalized[field] = references
    return normalized.get("sources", normalized.get("source_attributes", []))


def capture_raw_proposals(row, target=None):
    """Isolate malformed alternatives; unusable fields stay bounded diagnostics."""
    if not isinstance(row, dict):
        return []
    captured = []
    alternatives = row.get("candidates")
    for raw in [row, *(alternatives if isinstance(alternatives, list) else [])]:
        if not isinstance(raw, dict):
            continue
        explicit_target = raw.get("target_attribute", raw.get("target"))
        if raw is not row and explicit_target is not None and explicit_target != target:
            continue
        body = {key: value for key, value in raw.items() if key in MappingCandidate.model_fields}
        if "preprocessing_rule" not in body and "rule" in raw:
            body["preprocessing_rule"] = raw["rule"]
        if "preprocessing_rule_type" not in body and "rule_type" in raw:
            body["preprocessing_rule_type"] = raw["rule_type"]
        body.setdefault("source_attributes", [])
        body.setdefault("original_confidence_score", body.get("confidence_score"))
        body.setdefault("confidence_score", 0.0)
        diagnostics = []
        for field in ("sources", "source_attributes"):
            if field not in raw:
                continue
            try:
                source_bindings({field: raw[field]})
            except ValueError:
                diagnostics.append("Malformed proposal field " + field + ": " + json.dumps(raw[field], default=str)[:1000])
        body["source_attributes"] = [] if diagnostics else source_bindings(raw)
        from pydantic import ValidationError
        for _ in range(len(body) + 1):
            if diagnostics:
                body["warnings"] = []
            try:
                option = MappingCandidate.model_validate(body)
                break
            except ValidationError as error:
                for detail in error.errors():
                    key = detail["loc"][0]
                    diagnostics.append("Malformed proposal field " + str(key) + ": " + json.dumps(body.get(key), default=str)[:1000])
                    if key == "source_attributes":
                        body[key] = []  # Never guess a binding from an object.
                    elif key == "confidence_score":
                        body[key] = 0.0
                        body["original_confidence_score"] = None
                    else:
                        body.pop(key, None)
        else:
            continue
        if proposal(option) is not None:
            captured.append(option.model_copy(update={"warnings": [*option.warnings, *diagnostics][:16]}))
    return captured[:4]


def score_candidate(option, issues, *, req=None, store=None, target=None):
    unique = { (issue.category, issue.code, issue.message): issue for issue in issues }
    issues = list(unique.values())
    cap = min([1.0, *(.49 if issue.category in {"source", "sql", "value"} and issue.severity == "error"
        else .69 if issue.category == "validation" or issue.severity == "error" else .79 for issue in issues)])
    original = option.original_confidence_score
    if req is not None and req.meta.get('automap_rules_policy') == 'rules-v2':
        from app.core.automap_confidence import confidence_estimate
        estimate, provenance = confidence_estimate(option, req, store, target)
        model_scores = [value for value in (original, option.transformation_confidence_score)
                        if value is not None and value > 0]
        model_base = min(model_scores) if model_scores else None
        use_model = model_base is not None and estimate > 0
        adjusted = round(min(model_base if use_model else estimate, cap), 4)
        return option.model_copy(update={'adjusted_confidence_score': adjusted, 'confidence_score': adjusted,
            'confidence_policy_version': 'evidence-v1',
            'confidence_reason': option.confidence_reason or (
                f"Estimated from {provenance.get('resolved_sources', 0)} verified source bindings, "
                f"{provenance.get('resolved_values', 0)} resolved Firm Values, definition readiness and retrieved history."),
            'confidence_provenance': {**provenance, 'cap': cap,
                'score_source': 'model_with_backend_caps' if use_model else 'backend_evidence_fallback',
                'evidence_estimate': estimate, 'model_score': model_base, 'source_model_score': original,
                'transformation_model_score': option.transformation_confidence_score},
            'scoring_issues': issues, 'scoring_policy_version': SCORING_POLICY_VERSION})
    adjusted = min(original, cap) if original is not None else None
    return option.model_copy(update={"adjusted_confidence_score": adjusted,
        "confidence_score": adjusted if adjusted is not None else 0.0,
        "scoring_issues": issues, "scoring_policy_version": SCORING_POLICY_VERSION})


def validate_row_candidates(service, req, response):
    result = response.data.result if response.data else response.result
    if not isinstance(result, SourceMappingResult):
        return response
    graph = req.context.relation_graph
    attributes = {target_name(item.target_attribute): item for item in req.data.attributes or []}
    if response.error is not None or (response.data and response.data.status == STTMStatus.FAILED):
        return response
    bindings = {binding.binding_id: binding for binding in (graph.value_bindings if graph else [])}
    bindings.update({binding.value: binding for binding in (graph.value_bindings if graph else [])})
    for target, mapping in list(result.mappings.items()):
        if requested_target(req.data.attributes or [], target) is None:
            del result.mappings[target]
            continue
        unique = {}
        # The final selected rule may have been generated by the specialist after
        # the model emitted its candidate roster. Keep that final version first.
        primary = proposal(mapping)
        # A scored primary is only a compatibility projection of its roster.
        # Do not turn an unresolved projection into a new candidate on delivery.
        originals = list(mapping.candidates)
        if primary is not None and not (mapping.draft_candidate_id or mapping.selected_candidate_id) and not any(
                candidate_identity(item) == candidate_identity(primary) for item in originals):
            originals.insert(0, primary)
        empty_options = not any(concrete_option(option) for option in originals)
        # Discard model-provided dependency bodies; only the retrieved FIR store
        # can authorize a structured SQL/relationship recommendation.
        mapping.suggestions = [item.model_copy(update={'dependency_proposal': None}) for item in mapping.suggestions]
        guidance = row_suggestions(req, target, mapping, empty_options)
        from app.core.automap_dependency_suggestions import dependency_suggestions
        execution = response._auto_map_execution
        store = execution[1] if execution is not None else None
        guidance.extend(dependency_suggestions(target, store))
        for raw_option in originals:
            option = proposal(raw_option)
            if option is None:
                continue
            if (req.meta.get("auto_map_fast_path") == "v1" and not option.scoring_policy_version
                    and not option.scoring_issues):
                # Unexamined model alternatives are not equivalent to the
                # candidate admitted by the bounded evidence loop.
                option = option.model_copy(update={"scoring_issues": [CandidateScoringIssue(
                    code="capture_validation", category="validation", severity="error",
                    message="Alternative requires exact admission and evidence validation.")]})
            expression = (option.preprocessing_rule or "").strip()
            rule_type = "Value" if option.mapping_mode in {"constant", "attribute"} else (
                option.preprocessing_rule_type or (
                    "Custom" if expression and expression.upper() not in {"DIRECT", "IDENTITY"} else "Direct"))
            # The compiler accepts an approved Value's exact name as an alias.
            # Unlike a row-generated binding ID, this survives graph reconstruction.
            value_ids = []
            for identifier in option.value_binding_ids:
                binding = bindings.get(identifier)
                if binding is not None and binding.value:
                    value_ids.append(binding.value)
                elif binding is None or option.mapping_mode != "constant":
                    value_ids.append(identifier)
            option = option.model_copy(update={"preprocessing_rule_type": rule_type,
                "value_binding_ids": list(dict.fromkeys(value_ids))})
            identity = candidate_identity(option)
            original = option.original_confidence_score
            previous = unique.get(identity)
            if previous is not None:
                evidence = list(dict.fromkeys(warning for value in (previous, option) for warning in value.warnings
                    if warning.startswith("Malformed proposal field")))
                previous.warnings = list(dict.fromkeys([*previous.warnings, *evidence]))
                option.warnings = list(dict.fromkeys([*option.warnings, *evidence]))
            if previous is None or (original if original is not None else -1) > (
                    previous.original_confidence_score if previous.original_confidence_score is not None else -1):
                unique[identity] = option.model_copy(update={"candidate_id": identity})
        options = list(unique.values())
        validated = []
        for option in options:
            errors = []
            incomplete = False
            # Binding/SQL/Value failures are rechecked, not accumulated from retries.
            issues = [issue for issue in option.scoring_issues if issue.code.startswith("capture_")
                      and issue.category in {"source", "evidence", "validation"}]
            errors.extend(item.message for item in issues if item.category == "source" and item.severity == "error")
            warnings = [warning for warning in option.warnings
                        if (warning.startswith("Malformed proposal field") or warning not in option.validation_errors)
                        and warning != "No candidate-specific reasoning was supplied."]
            def issue(code, message, category, severity="error"):
                issues.append(CandidateScoringIssue(code=code, message=message, category=category, severity=severity))
            for warning in warnings:
                if warning.startswith("Malformed proposal field"):
                    field = warning.split(":", 1)[0].removeprefix("Malformed proposal field ")
                    category = ("source" if field in {"sources", "source_attributes", "source_dependencies"} else
                        "sql" if field in {"preprocessing_rule", "preprocessing_rule_type"} else
                        "value" if field in {"constant_value", "attribute_name", "value_binding_ids"} else "validation")
                    issue("malformed_field", warning, category)
                    if category != "validation":
                        errors.append(warning)
                    incomplete = True
            for warning in response.warnings:
                if warning.field and requested_target(req.data.attributes or [], warning.field) == target_name(target):
                    warnings.append(warning.message)
            if not option.confidence_reason:
                warnings.append("No candidate-specific reasoning was supplied.")
                issue("missing_reason", "No candidate-specific reasoning was supplied.", "evidence", "warning")
            if (str(option.preprocessing_rule_type).upper() in {"DIRECT", "IDENTITY"}
                    and option.preprocessing_rule and option.preprocessing_rule.strip().upper() not in {"DIRECT", "IDENTITY"}):
                errors.append("An expression requires a validated transformation rule, not Direct mapping.")
            if option.preprocessing_rule and str(option.preprocessing_rule_type).upper() not in {"DIRECT", "IDENTITY", "VALUE"}:
                from app.core.mapping_contracts import valid_attribute_expression
                if not valid_attribute_expression(option.preprocessing_rule):
                    errors.append("A complete scalar SQL expression is required, not a query, rule label or prose.")
            if option.mapping_mode == "attribute":
                placeholder = "$" + str(option.attribute_name or "").lstrip("$")
                matches = [binding for binding in (graph.value_bindings if graph else [])
                           if binding.value.upper() == placeholder.upper()]
                if (not matches or option.constant_value != placeholder or not option.value_binding_ids
                        or any(not any(value in {binding.binding_id, binding.value} for binding in matches)
                               for value in option.value_binding_ids)):
                    errors.append("The Firm Value name, placeholder and approved binding must agree.")
            if not graph or not graph.nodes:
                incomplete = True
                issue("graph_unavailable", "The current source graph is unavailable for validation.", "validation")
            if option.transformation_classification == "unresolved":
                incomplete = True
                issue("unresolved_validation", option.unmatched_reason or "This option is unresolved.", "validation")
            if option.transformation_classification in {"complex", "simple_multi_source"} and not option.preprocessing_rule:
                errors.append("A complete transformation rule is required.")
            if graph and graph.nodes:
                resolved = MappingSqlService._resolved_placeholder_sql(graph)
                texts = [option.preprocessing_rule or ""]
                if option.mapping_mode in {"constant", "attribute"}:
                    texts.append(option.constant_value or "")
                missing_values = {value for text in texts for value in MappingSqlService._placeholders_in_sql(text)
                                  if value.upper() not in resolved}
                if missing_values:
                    errors.append("Required Firm Value is unresolved: " + ", ".join(sorted(missing_values)))
            if graph and graph.nodes and not errors:
                try:
                    workspace = req.context.workspace_context
                    driving = (workspace.driving_relation_id if workspace else None) or (
                        req.context.driving_table.qualified_name if req.context.driving_table else graph.nodes[0].relation_id)
                    attribute = attributes.get(target_name(target))
                    custom = str(option.preprocessing_rule_type or "Direct").upper() not in {"DIRECT", "IDENTITY", "VALUE"}
                    session = getattr(service, "_query_session", None)
                    if custom and session is None:
                        incomplete = True
                        issue("explain_unavailable", "Required SQL EXPLAIN validation is unavailable.", "validation")
                    scope_check = getattr(service, "_outer_source_binding_error", None)
                    scope_error = scope_check(graph, driving, [*option.source_attributes, *option.source_dependencies,
                        option.preprocessing_rule if custom else None]) if callable(scope_check) else None
                    if scope_error:
                        issue("source_scope", scope_error, "source")
                        raise ValueError(scope_error)
                    compiled = MappingSqlService(session=session, analyst_client=None).compile(
                        MappingSqlCompileRequest(
                            relation_graph=graph, driving_relation_id=driving,
                            allow_unresolved_placeholders=False,
                            validate_with_explain=custom and session is not None,
                            mappings=[MappingSqlMappingItem(
                                target_column=target, target_type=attribute.target_data_type if attribute else None,
                                source_columns=option.source_attributes, source_dependencies=option.source_dependencies,
                                mapping_mode=option.mapping_mode, constant_value=option.constant_value,
                                attribute_name=option.attribute_name, value_binding_ids=option.value_binding_ids,
                                expression=option.preprocessing_rule if custom else None,
                                rule=option.preprocessing_rule_type or "Direct")]))
                    warnings.extend(compiled.warnings)
                    if not compiled.valid or not compiled.ready or compiled.unresolved_placeholders:
                        errors.extend(compiled.warnings or ["This option has no valid executable binding."])
                except (TimeoutError, ConnectionError) as error:
                    incomplete = True
                    issue("validation_unavailable", str(error)[:2000] or "SQL validation is unavailable.", "validation")
                except Exception as error:
                    errors.append(str(error)[:4000] or "The option failed source, Value, or SQL validation.")
            for message in errors:
                lower = message.lower()
                category = "value" if any(word in lower for word in ("value", "placeholder")) else (
                    "source" if any(word in lower for word in ("source", "column", "binding", "graph", "relation")) else "sql")
                issue("candidate_" + category, message, category)
            incomplete = incomplete or any(item.severity == "error" for item in issues)
            validated.append(score_candidate(option.model_copy(update={
                "validation_status": "invalid" if errors else "unvalidated" if incomplete else "valid",
                "validation_errors": list(dict.fromkeys(errors)), "warnings": list(dict.fromkeys(warnings))}), issues,
                    req=req, store=store, target=target))
        # Apply the strongest cap before ranking; unknown scores rank last.
        validated.sort(key=lambda option: -(option.adjusted_confidence_score if option.adjusted_confidence_score is not None else -1))
        # Compiler prerequisites can supply actionable guidance without inventing
        # matching keys, a join type, or a mapping from explanatory prose.
        for option in validated:
            errors = " ".join(option.validation_errors).lower()
            kind = "relationship" if any(token in errors for token in ("join", "connect", "undefined relation", "relationship")) else "value" if any(token in errors for token in ("value", "placeholder")) else None
            if kind and not any(item.kind == kind for item in guidance):
                message = "Review the required source tables and relationship before using this mapping." if kind == "relationship" else "Provide the required approved project Value before using this mapping."
                extra = MappingSuggestion(kind=kind, message=message,
                    source_references=list(dict.fromkeys([*option.source_attributes, *option.source_dependencies])),
                    join_recommendation=JoinRecommendation() if kind == "relationship" else None)
                guidance = row_suggestions(req, target, mapping.model_copy(update={"suggestions": [*guidance, extra], "unmatched_reason": None}), False)
        selected = next((option for option in validated if option.validation_status == "valid"), None)
        # Keep the strongest valid choice even if three higher-scored invalid
        # options precede it. The UI still receives at most three alternatives plus the selected option.
        roster = validated[:4]
        if selected and selected not in roster:
            roster[-1] = selected
        if selected:
            replacement = AttributeMapping.model_validate(selected.model_dump(exclude={
                "candidate_id", "validation_status", "validation_errors", "warnings"}))
            if req.meta.get('automap_rules_policy') == 'rules-v2':
                from app.core.automap_rule_handoff import definition_hash
                if definition_hash(mapping, req.context) == definition_hash(selected, req.context) and mapping.rule_stage:
                    for field in ('rule_stage', 'rule_stage_reason', 'rule_candidate_id', 'rule_definition_hash'):
                        setattr(replacement, field, getattr(mapping, field))
                        setattr(selected, field, getattr(mapping, field))
                else:
                    from app.core.automap_rule_handoff import rule_route
                    replacement.rule_stage, replacement.rule_stage_reason = rule_route(replacement, req.context)
                    selected.rule_stage, selected.rule_stage_reason = replacement.rule_stage, replacement.rule_stage_reason
            replacement.candidates = roster
            replacement.suggestions = guidance
            replacement.selected_candidate_id = selected.candidate_id
        else:
            replacement = mapping.model_copy(update={"candidates": roster, "selected_candidate_id": None, "suggestions": guidance,
                "transformation_classification": "unresolved",
                "unmatched_reason": mapping.unmatched_reason or "No candidate passed source, Value and rule validation."})
        if not roster and req.meta.get('automap_rules_policy') == 'rules-v2':
            replacement = replacement.model_copy(update={'confidence_score': 0.0, 'confidence_policy_version': 'evidence-v1',
                'confidence_provenance': {'reason': 'No supported definition', 'components': {}},
                'confidence_reason': replacement.confidence_reason or 'No supported mapping proposal was produced.'})
        elif roster and not selected and req.meta.get('automap_rules_policy') == 'rules-v2':
            replacement = replacement.model_copy(update={key: getattr(roster[0], key) for key in
                ('confidence_score', 'confidence_policy_version', 'confidence_provenance')})
        replacement.draft_candidate_id = roster[0].candidate_id if roster else None
        result.mappings[target] = replacement
    response.result = result
    if response.data:
        response.data.result = result
    if response.data and any(not mapping.selected_candidate_id for mapping in result.mappings.values()):
        response.data.status = STTMStatus.NEEDS_INPUT
    response.meta = {**response.meta, "automap_sheet_candidates_v1": True,
        "automap_draft_validation": SCORING_POLICY_VERSION, SCORING_META_KEY: SCORING_POLICY_VERSION}
    return response
