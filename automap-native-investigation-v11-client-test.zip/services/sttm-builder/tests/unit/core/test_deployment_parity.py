from pathlib import Path
import re
import pytest
import yaml

ROOT = Path(__file__).resolve().parents[5]
EXPECTED = {
    'AGENT_CALLER_INLINE_FALLBACK_LIMIT_BYTES': '4194304',
    'SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE': 'SEM_TABLE_REGISTRY',
    'SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE': 'SEM_COLUMN_REGISTRY',
    'SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE': 'SEM_NATIVE_VIEWS',
}


@pytest.mark.skipif(not (ROOT/'infra/snowflake/env/client.env').is_file(), reason='Authoritative client.env is external; validate this deployment gate on the client AVD.')
def test_client_profile_and_both_service_templates_share_verified_settings():
    values = dict(line.split('=',1) for line in (ROOT/'infra/snowflake/env/client.env').read_text(encoding='utf-8').splitlines()
                  if line and not line.startswith('#') and '=' in line)
    assert {key:values[key] for key in EXPECTED} == EXPECTED
    input_limits={key:values[key] for key in ('AGENT_OUTBOUND_MESSAGE_MAX_CHARS','AGENT_OUTBOUND_MESSAGE_MAX_BYTES')}
    assert all(2048 <= int(value) <= 180000 for value in input_limits.values())
    assert values['AUTH_MODE'] == 'custom_oauth'
    assert values['AUTO_MAPPING_PROXY_BATCH_SIZE'] == '16'
    for name in ('webapp', 'automap-worker'):
        template = (ROOT/f'infra/snowflake/service-specs/{name}.yaml.tmpl').read_text(encoding='utf-8')
        defaults = {key:values.get(key,'placeholder') for key in re.findall(r'\$\{([A-Z][A-Z0-9_]*)\}',template)}
        defaults['IMAGE_TAG'] = 'parity-test'
        defaults['AUTO_MAPPING_SERVICE_URL'] = 'http://worker:8000'
        defaults['SNOWFLAKE_OAUTH_SECRET_MAPPINGS'] = ''
        rendered = re.sub(r'\$\{([A-Z][A-Z0-9_]*)\}',lambda match:defaults[match[1]],template)
        containers = yaml.safe_load(rendered)['spec']['containers']
        env = next(item['env'] for item in containers if 'AGENT_OUTBOUND_MESSAGE_MAX_CHARS' in item.get('env',{}))
        assert {key:str(env[key]) for key in EXPECTED} == EXPECTED
        assert {key:str(env[key]) for key in input_limits} == input_limits
        assert env['AUTH_MODE'] == 'custom_oauth'


@pytest.mark.skipif(not (ROOT/'infra/snowflake/env/client.env').is_file(), reason='Authoritative client.env is external; validate this deployment gate on the client AVD.')
def test_deployed_caller_profile_never_runs_request_time_schema_ddl(monkeypatch):
    from app.core.config import Settings
    from app.core.conversation_memory import ConversationMemoryService
    values = dict(line.split('=', 1) for line in (ROOT/'infra/snowflake/env/client.env').read_text(encoding='utf-8').splitlines()
                  if line and not line.startswith('#') and '=' in line)
    assert values['AUTH_MODE'] == 'custom_oauth'
    assert values['SPCS_EXECUTE_AS_CALLER_ENABLED'] == 'true'
    settings = Settings(_env_file=None, AUTH_MODE=values['AUTH_MODE'],
                        SPCS_EXECUTE_AS_CALLER_ENABLED=values['SPCS_EXECUTE_AS_CALLER_ENABLED'],
                        SNOWFLAKE_DATABASE='TEST_DB', SNOWFLAKE_SCHEMA='METADATA')
    class NoDDLSession:
        def sql(self, *_args, **_kwargs):
            raise AssertionError('Caller request attempted schema DDL')
    monkeypatch.setattr(ConversationMemoryService, '_ensured_storage_keys', set())
    memory = ConversationMemoryService(NoDDLSession(), settings)
    memory.ensure_storage_exists()
    memory.ensure_storage_exists()


@pytest.mark.skipif(not (ROOT/'infra/snowflake/env/client.env').is_file(), reason='Authoritative client.env is external; validate this deployment gate on the client AVD.')
def test_deployed_rest_host_matches_oauth_and_overrides_injected_account():
    from urllib.parse import urlparse
    from app.core.config import Settings
    from app.core.snowflake_agent import SnowflakeAgentClient
    values = dict(line.split('=', 1) for line in (ROOT/'infra/snowflake/env/client.env').read_text(encoding='utf-8').splitlines()
                  if line and not line.startswith('#') and '=' in line)
    expected_host = urlparse(values['SNOWFLAKE_OAUTH_TOKEN_URL']).hostname
    assert values['SNOWFLAKE_REST_HOST'] == expected_host
    assert expected_host == urlparse(values['SNOWFLAKE_OAUTH_AUTHORIZE_URL']).hostname
    settings = Settings(_env_file=None, SNOWFLAKE_ACCOUNT='injected-account-locator',
                        SNOWFLAKE_HOST='internal.snowflakecomputing.internal',
                        SNOWFLAKE_REST_HOST=values['SNOWFLAKE_REST_HOST'])
    assert settings.rest_snowflake_host == expected_host
    assert SnowflakeAgentClient(token='test-only', host=settings.rest_snowflake_host)._base_url == f'https://{expected_host}'
    for name in ('webapp', 'automap-worker'):
        template = (ROOT/f'infra/snowflake/service-specs/{name}.yaml.tmpl').read_text(encoding='utf-8')
        assert 'SNOWFLAKE_REST_HOST: ${SNOWFLAKE_REST_HOST}' in template


def test_bootstrap_release_parity_is_offline_and_has_no_shared_analyst():
    from scripts.bootstrap_sttm_metadata_infra import check_release_parity
    check_release_parity()


def test_four_batch_release_defaults_reach_both_containers():
    from scripts.render_spcs_spec import render_template
    for name in ('webapp', 'automap-worker'):
        template = (ROOT/f'infra/snowflake/service-specs/{name}.yaml.tmpl').read_text(encoding='utf-8')
        for key in ('AUTOMAP_CONTEXT_RETRIEVAL_V1', 'AUTOMAP_CONTEXT_BATCH_COUNT'):
            assert '${' + key + '}' in template
    template = 'enabled: "${AUTOMAP_CONTEXT_RETRIEVAL_V1}"\ncount: "${AUTOMAP_CONTEXT_BATCH_COUNT}"'
    assert yaml.safe_load(render_template(template, {})) == {'enabled': 'true', 'count': '4'}
    assert yaml.safe_load(render_template(template, {'AUTOMAP_CONTEXT_RETRIEVAL_V1': 'false'}))['enabled'] == 'false'


def test_native_analyst_release_defaults_remain_disabled():
    from scripts.render_spcs_spec import render_template
    rendered = render_template(
        'enabled: "${AGENT_REQUEST_SCOPED_ANALYST_V1}"\nschema: "${AGENT_BUNDLE_VIEW_SCHEMA}"',
        {},
    )
    assert yaml.safe_load(rendered) == {"enabled": "false", "schema": ""}


@pytest.mark.parametrize('relative', [
    'scripts/deploy_spcs_client_snow_safe.ps1',
    'scripts/deploy_spcs_client_snow_single_service.ps1',
])
def test_protected_deployer_is_unchanged(relative):
    import hashlib
    import subprocess
    original=subprocess.check_output(['git','-C',str(ROOT),'show',f'HEAD:{relative}'])
    # Checkout CRLF is allowed; content edits are not.
    assert hashlib.sha256(original.replace(b'\r\n',b'\n')).digest() == hashlib.sha256((ROOT/relative).read_bytes().replace(b'\r\n',b'\n')).digest()


def test_trackable_example_preserves_verified_parity_without_client_secrets():
    values = dict(line.split('=', 1) for line in (ROOT/'infra/snowflake/env/client.env.example').read_text(encoding='utf-8').splitlines()
                  if line and not line.startswith('#') and '=' in line)
    assert {key: values[key] for key in EXPECTED} == EXPECTED
    assert values['AUTO_MAPPING_PROXY_BATCH_SIZE'] == '16'


def test_release_manifest_includes_fir_learning_and_tests_without_private_artifacts():
    from scripts.workbench_release_manifest import release_source
    for path in (
        "infra/snowflake/fir_system/procedures/sp-agent-learning-helpers.sql",
        "infra/snowflake/fir_system/procedures/sp-fir-process-learning-queue.sql",
        "infra/snowflake/fir_system/cortex_search/fir_search_services.sql",
        "infra/snowflake/automap_recipe_search.sql",
        "services/sttm-builder/tests/unit/core/test_saved_mapping_corrections.py",
        "frontend/scripts/test-workspace-persistence.cjs",
        "infra/snowflake/env/client.env.example",
        "services/sttm-builder/pyproject.toml",
        "services/sttm-converter/app/main.py",
        "services/auth-service/Dockerfile",
        "nginx/nginx.conf",
        "start-ai-workbench-dev.ps1",
    ):
        assert release_source(path), path
    for path in ("infra/snowflake/env/client.env", ".dev-cache/replay.json", "deploy_log_run2.txt",
                 "services/sttm-builder/.venv/Lib/site.py", "services/auth-service/server.key",
                 "frontend/.next-old/server.js",
                 "scripts/__pycache__/test.pyc", "services/sttm-builder/.env.local"):
        assert not release_source(path), path