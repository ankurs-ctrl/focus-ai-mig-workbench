"""Run the API and, when enabled, its durable Deep Agent worker together."""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time

from app.core.config import Settings, get_settings


def service_commands(settings: Settings) -> list[list[str]]:
    commands = [[sys.executable, "-m", "uvicorn", os.getenv("APP_MODULE", "app.main:app"),
                 "--host", "0.0.0.0", "--port", str(int(os.getenv("PORT", "8000"))),
                 "--loop", os.getenv("UVICORN_LOOP", "auto")]]
    if settings.migration_agent_enabled:
        from app.agent_runs.policy import validate_worker_configuration

        validate_worker_configuration(settings)
        commands.append([sys.executable, "-m", "app.agent_worker_main"])
    return commands


def main() -> int:
    commands = service_commands(get_settings())
    stopping = False

    def stop(_signum, _frame):
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    children: list[subprocess.Popen] = []
    try:
        for command in commands:
            children.append(subprocess.Popen(command))
        while not stopping:
            for child in children:
                code = child.poll()
                if code is not None:
                    # A worker exiting unexpectedly must not leave an API that
                    # continues accepting work without a durable consumer.
                    return code if code > 0 else 1
            time.sleep(0.25)
        return 0
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
        deadline = time.monotonic() + 15
        for child in children:
            try:
                child.wait(timeout=max(0.1, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()


if __name__ == "__main__":
    raise SystemExit(main())
