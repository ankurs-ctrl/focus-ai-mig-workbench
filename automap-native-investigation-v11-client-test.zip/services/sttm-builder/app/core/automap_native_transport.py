"""Native-tool transport, isolated from the legacy single-shot parser.

The existing managed lifecycle still creates/archives the thread before POST,
leases global admission, never retries uncertain calls and bounds raw entities.
Only registered server-side tools may accompany a completed assistant answer.
"""

from copy import deepcopy
import json
import time
from app.core.automap_native_contract import TOOLS
from app.core.automap_scan_transport import (
    SnowflakeScanTransport,
    _load_json,
    ScanTransportError,
    TerminalResponseError,
    TerminalResponseReason,
    DiagnosticPhase,
)


class NativeAgentTransport(SnowflakeScanTransport):
    def __init__(self, *, allowed_tools=TOOLS, **kwargs):
        self.allowed_tools = frozenset(allowed_tools)
        self.provider_usage = {}
        self.provider_received_at = None
        self.provider_parsed_at = None
        super().__init__(**kwargs)

    def _thread_recovery_cap(self):
        return min(2000000, self._config.max_response_bytes)

    def _extract(self, raw, request, emit):
        self.provider_received_at = time.time()
        try:
            data = _load_json(raw.decode("utf-8"))
        except (ValueError, UnicodeError, RecursionError):
            raise ScanTransportError(
                "Malformed native agent entity; completion unknown"
            ) from None
        # Only numeric provider counters are retained, never raw tool data.
        metadata = data.get("metadata", {}) if isinstance(data, dict) else {}
        usage = (
            metadata.get("usage", data.get("usage", {}))
            if isinstance(metadata, dict)
            else {}
        )
        self.provider_usage = {}
        if isinstance(usage, dict):
            consumed = usage.get("tokens_consumed", [])
            if isinstance(consumed, list):
                for record in consumed[:32]:
                    if not isinstance(record, dict):
                        continue
                    for source, key in [
                        ("input_tokens", "input_tokens"),
                        ("output_tokens", "output_tokens"),
                    ]:
                        amount = record.get(source, {})
                        value = (
                            amount.get("total") if isinstance(amount, dict) else amount
                        )
                        if type(value) is int and value >= 0:
                            self.provider_usage[key] = (
                                self.provider_usage.get(key, 0) + value
                            )
                    window = record.get("context_window")
                    if type(window) is int and window > 0:
                        self.provider_usage["context_window"] = min(
                            window, self.provider_usage.get("context_window", window)
                        )
            for key in ("input_tokens", "output_tokens", "total_tokens"):
                if type(usage.get(key)) is int and usage[key] >= 0:
                    self.provider_usage[key] = usage[key]
        message = data.get("message", data) if isinstance(data, dict) else None
        levels = [data] if message is data else [data, message]
        # Let the original parser classify nonterminal, failure and malformed
        # envelopes before attempting native ancillary-content normalization.
        if (
            not isinstance(message, dict)
            or any(not isinstance(level, dict) for level in levels)
            or any(level.get("status", "completed") != "completed" for level in levels)
            or not isinstance(message.get("content"), list)
        ):
            return super()._extract(raw, request, emit)
        uses = {}
        results = {}
        kept = []

        def invalid():
            raise TerminalResponseError(
                "Completed native response contains invalid or unregistered tools",
                response_reason=TerminalResponseReason.INVALID_CONTENT_KIND,
                content=message["content"],
            )

        for block in message["content"]:
            if not isinstance(block, dict):
                invalid()
            kind = block.get("type")
            if kind not in {"tool_use", "tool_result"}:
                kept.append(block)
                continue
            value = block.get(kind, block)
            if not isinstance(value, dict):
                invalid()
            if kind in block and set(block) != {"type", kind}:
                invalid()
            allowed = (
                {"type", "tool_use_id", "name", "input", "client_side_execute"}
                if kind == "tool_use"
                else {"type", "tool_use_id", "name", "content", "status"}
            )
            if set(value) - allowed:
                invalid()
            if kind in block and value.get("type", "generic") != "generic":
                invalid()
            identity = value.get("tool_use_id")
            name = value.get("name")
            if (
                type(identity) is not str
                or not identity
                or len(identity) > 256
                or name not in self.allowed_tools
            ):
                invalid()
            if kind == "tool_use":
                if (
                    identity in uses
                    or value.get("client_side_execute", False) is not False
                    or type(value.get("input")) is not dict
                ):
                    invalid()
                if (
                    set(value["input"]) != {"request_json"}
                    or type(value["input"]["request_json"]) is not str
                ):
                    invalid()
                if len(value["input"]["request_json"].encode()) > 32768:
                    invalid()
                uses[identity] = name
            else:
                if (
                    identity in results
                    or value.get("status") not in {"success", "error"}
                    or type(value.get("content")) is not list
                ):
                    invalid()
                for content in value["content"]:
                    if type(content) is not dict:
                        invalid()
                    if content.get("type") == "text":
                        if (
                            set(content) != {"type", "text"}
                            or type(content["text"]) is not str
                        ):
                            invalid()
                    elif content.get("type") == "json":
                        if set(content) != {"type", "json"}:
                            invalid()
                    else:
                        invalid()
                results[identity] = name
        if uses != results:
            invalid()
        normalized = deepcopy(data)
        normalized_message = normalized.get("message", normalized)
        normalized_message["content"] = kept
        # Original parser retains explicit status/error, role, text, output
        # budget, unknown-content and final-completion checks. Tool results are
        # never concatenated into or parsed as the mapping answer.
        result = super()._extract(
            json.dumps(normalized, ensure_ascii=False).encode(), request, emit
        )
        self.provider_parsed_at = time.time()
        return result
