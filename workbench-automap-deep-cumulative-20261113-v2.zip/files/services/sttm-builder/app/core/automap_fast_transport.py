"""Durable final-mapping calls; no scan protocol, model repair, or HTTP replay.

The existing transport validates provider completion, not the model's mapping
schema. A bounded terminal answer (even invalid mapping JSON) releases its permit
before archive I/O and consumer validation. Uncertain exchanges remain occupied.
"""
from __future__ import annotations

import time

from copy import deepcopy
from dataclasses import asdict, replace
from enum import Enum
import hashlib
import json
import logging
from threading import Event, Lock

from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.automap_admission import request_digest
from app.core.automap_parallel import _snapshot
from app.core.automap_scan import ScanRequest, RuntimeCallTrace, RuntimePhase
from app.core.automap_evidence_blocks import MAX_EVIDENCE_REVIEW_CALLS
from app.core.automap_scan_transport import _diagnostic_reason, _request_body
from app.core.snowflake_agent import SnowflakeAgentClient


logger = logging.getLogger(__name__)
STAGE_CALL_LIMITS = {"source_mapping": 3, "transformation_rule": 2, "evidence_review": MAX_EVIDENCE_REVIEW_CALLS}
MAX_RUNTIME_CALLS = sum(STAGE_CALL_LIMITS.values())


class RuntimeFailureKind(str, Enum):
    ARCHIVE_DEADLINE = "archive_deadline"
    ARCHIVE_STORAGE = "archive_storage"
    CALLER_SESSION = "caller_session"
    ADMISSION_UNCERTAIN = "admission_claim_uncertain"
    ADMISSION_UNAVAILABLE = "admission_unavailable"
    CAPACITY_BLOCKED = "admission_capacity_blocked"
    ADMISSION_CONTENDED = "admission_contended"
    ADMISSION_INVARIANT = "admission_invariant"
    STOPPED = "stopped"
    TRANSPORT = "transport"
    UNKNOWN = "unknown"


def _runtime_failure_kind(error):
    error = getattr(error, "admission_cause", None) or error
    from app.core.automap_runtime import ArchiveDeadlineExpired, ArchiveStorageFailure, RuntimeConfigurationError
    from app.core.automap_admission import AdmissionCapacityBlocked, AdmissionClaimUncertain, AdmissionContended, AdmissionError, AdmissionUnavailable
    from app.core.automap_scan import ScanStopped
    for error_type, kind in (
        (ArchiveDeadlineExpired, RuntimeFailureKind.ARCHIVE_DEADLINE),
        (ArchiveStorageFailure, RuntimeFailureKind.ARCHIVE_STORAGE),
        (RuntimeConfigurationError, RuntimeFailureKind.CALLER_SESSION),
        (AdmissionClaimUncertain, RuntimeFailureKind.ADMISSION_UNCERTAIN),
        (AdmissionContended, RuntimeFailureKind.ADMISSION_CONTENDED),
        (AdmissionCapacityBlocked, RuntimeFailureKind.CAPACITY_BLOCKED),
        (AdmissionUnavailable, RuntimeFailureKind.ADMISSION_UNAVAILABLE),
        (AdmissionError, RuntimeFailureKind.ADMISSION_INVARIANT),
        (ScanStopped, RuntimeFailureKind.STOPPED),
    ):
        if isinstance(error, error_type):
            return kind
    from app.core.automap_scan_transport import DiagnosticReason
    return RuntimeFailureKind.UNKNOWN if _diagnostic_reason(error) == DiagnosticReason.UNKNOWN_FAILURE else RuntimeFailureKind.TRANSPORT


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class FastModelRuntime:
    """One governed batch with a bounded sequence of distinct operations.

    Construct through build_fast_model_runtime. deadline is the existing absolute
    monotonic MODEL cutoff (the batch must subtract its validation reserve once).
    run uses 1-based call_index; a parse repair is a new operation, never a retry.

    Operator recovery uses reconcile_parallel_runtime(recovery_bundle_for(call_index), original_request=
    request_for(call_index), snapshot_archive_ref=..., permit=original_permit,
    retired_dispatcher=True, deadline=fresh_deadline). That generic thread proof
    requires the exact archived normalized prompt and structured v2 terminal state;
    neither mapping JSON nor scan markers constitute evidence. No automatic GET,
    release, or reconstruction of an owner capability is performed here.
    """

    def __init__(self, *, bundle, service, req, decision, store, deadline, specialist_backend=None, failure_archive=None):
        self.bundle = bundle
        self._service, self._decision = service, decision
        self._store = store
        self._req = req
        self._request_stages = {}
        self._deadline = deadline
        self._failure_archive = failure_archive
        self._operation = req.operation.value
        self._target_ids = tuple(sorted(store.targets))
        self._budget = bundle.limits.selection_budget
        from app.core.automap_input_budget import OUTPUT_HARD_LIMIT
        from app.core.automap_shards import MessageBudget
        self._output_budget = MessageBudget(min(OUTPUT_HARD_LIMIT, self._budget.max_chars),
                                           min(OUTPUT_HARD_LIMIT, self._budget.max_bytes))
        self._max_calls = min(MAX_RUNTIME_CALLS, bundle.limits.max_calls)
        self._cancel = bundle.cancellation if bundle.cancellation is not None else Event()
        self._stop = Event()
        self._lock = Lock()
        self._requests = {}
        self._stage_calls = dict.fromkeys(STAGE_CALL_LIMITS, 0)
        self._backends = {}
        self._failure_diagnostics = None
        self._snapshot_text = self._archive_text({
            "protocol": "automap_exact_snapshot_v1", "state": _snapshot(vars(store)),
        }, bundle.scope.snapshot_id)
        self.snapshot_archive_ref = _hash(self._snapshot_text)
        self._snapshot_committed = False
        self._guarded = bundle.admission.wrap_backend(bundle.backend)
        self._specialist_backend = specialist_backend

    @property
    def admission_wait_seconds(self):
        return sum(r.runtime_trace.capacity_wait_seconds for r in self._requests.values() if isinstance(r,ScanRequest) and r.runtime_trace is not None)

    @property
    def next_call_index(self):
        return max(self._requests, default=0) + 1

    def check_active(self):
        import time
        from app.core.automap_scan import ScanStopped, ScanStatus
        if self._stop.is_set():
            raise ValueError("Fast runtime stopped; transport failures must not be retried")
        if self._cancel.is_set() or time.monotonic() >= self._deadline + self.admission_wait_seconds:
            raise ScanStopped(ScanStatus.CANCELED if self._cancel.is_set() else ScanStatus.TIMED_OUT)

    def _archive_text(self, value, generation):
        return _json({"scope": asdict(self.bundle.scope), "generation": generation, "value": value})

    def _save_text(self, text, *, trace=None, read_phase=None, archive=None):
        reference = _hash(text)
        archive = self.bundle.archive if archive is None else archive
        if self.admission_wait_seconds and hasattr(archive,'with_deadline'):
            archive = archive.with_deadline(archive._deadline+self.admission_wait_seconds)
        from app.core.automap_runtime import SnowflakeReductionArchive
        if isinstance(archive, SnowflakeReductionArchive):
            archive.put_verified(reference, text, on_read=(lambda: trace.enter(read_phase)) if trace is not None and read_phase is not None else None)
            return reference
        archive.put(reference, text)
        if trace is not None and read_phase is not None:
            trace.enter(read_phase)
        if archive.get(reference) != text:
            raise ValueError("Fast model archive was not durably acknowledged")
        return reference

    def request_for(self, call_index):
        """Original immutable request for explicit same-owner operator recovery."""
        return self._requests[call_index]

    def recovery_bundle_for(self, call_index):
        """Use the exact factory-owned backend recorded for this original call."""
        return replace(self.bundle, backend=self._backends[call_index])

    def reconcile_call(self, call_index, *, permit, retired_dispatcher, deadline):
        """Explicit operator recovery, retaining the original agent and all fences.

        Use this entry point for source and specialist calls, instead of passing
        the source-only .bundle to generic recovery. The caller must retain the
        original owner Permit and attest dispatcher retirement; no capability is
        reconstructed and no uncertain remote call is replayed here.
        """
        from app.core.automap_runtime import reconcile_parallel_runtime
        return reconcile_parallel_runtime(self.recovery_bundle_for(call_index),
            permit=permit, original_request=self.request_for(call_index),
            snapshot_archive_ref=self.snapshot_archive_ref,
            retired_dispatcher=retired_dispatcher, deadline=deadline)

    @property
    def failure_diagnostics(self):
        """Safe last failed-call metadata, including whether its archive was ACKed."""
        return deepcopy(self._failure_diagnostics)

    def _metadata(self, request, call_index, request_ref, diagnostics):
        return {**{key: self._req.meta[meta_key] for key,meta_key in (("generation_policy","automap_generation_policy"),("rules_policy","automap_rules_policy")) if meta_key in self._req.meta},
            "call_index": call_index, "job_id": self.bundle.admission.job_id,
            "generation": request.generation, "shard_id": request.shard_id,
            "request_digest": request_digest(request), "snapshot_archive_ref": self.snapshot_archive_ref,
            "request_archive_ref": request_ref, "transport": [asdict(item) for item in diagnostics],
            **(request.runtime_trace.snapshot() if request.runtime_trace is not None else {})}

    def _record_failure(self, error, request, call_index, request_ref, diagnostics):
        metadata = {**self._metadata(request, call_index, request_ref, diagnostics),
                    "failure_code": _diagnostic_reason(error).value,
                    "failure_kind": _runtime_failure_kind(error).value,
                    **({"control_outcome": error.control_outcome} if getattr(error,"control_outcome",None) else {}),
                    **({"pre_submission_failure": True} if getattr(error,"admission_cause",None) is not None else {})}
        from app.core.automap_scan import ScanStopped, ScanStopReason
        if isinstance(error, ScanStopped) and type(error.reason) is ScanStopReason:
            metadata["stop_reason"] = error.reason.value
        from app.core.automap_admission import AdmissionCleanupFailureCode
        cleanup = getattr(error, "admission_cleanup_failure_code", None)
        if type(cleanup) is AdmissionCleanupFailureCode:
            metadata["cleanup_failure_code"] = cleanup.value
        try:
            # Factory reserves finalization inside the original batch deadline.
            # This separate scoped archive never extends inference or releases permits.
            archive = self.bundle.archive if self._failure_archive is None else self._failure_archive
            archive.check_active()
            reference = self._save_text(self._archive_text({
                "protocol": "automap_fast_model_failure_v1", "request_archive_ref": request_ref,
                "fast_diagnostics": metadata,
            }, request.generation), archive=self._failure_archive)
        except Exception:
            metadata["failure_archive_status"] = "unavailable"
            try:
                logger.warning("Auto-map fast failure diagnostics archive unavailable")
            except Exception:
                pass
        else:
            metadata.update(failure_archive_status="acknowledged", failure_archive_ref=reference)
        self._failure_diagnostics = metadata
        try:
            error.fast_diagnostics = deepcopy(metadata)
        except Exception:
            pass  # Adapter property remains available for exceptions without attributes.

    def run(self, messages, call_index, *, stage="source_mapping"):
        """Return (raw_model_text, None, {fast_diagnostics: ...}) after archive ACK.

        ThreadReference is in the occupied durable permit, not a public gate
        result. Never manufacture a thread ID from the legacy extractor's UUID
        fallback or parse one from model-authored text.
        """
        if (getattr(self._req, 'meta', None) or {}).get('automap_rules_policy') == 'rules-v2' and stage != 'transformation_rule':
            cutoff = getattr(self, '_source_schedule_deadline', None)
            if cutoff is None:
                now = time.monotonic()
                self._source_schedule_deadline = now + max(0, self._deadline - now) * .6
            reserve = 2 if self._max_calls >= 4 else 1 if self._max_calls >= 2 else 0
            if time.monotonic() >= self._source_schedule_deadline + self.admission_wait_seconds or call_index > self._max_calls - reserve:
                raise TimeoutError('Source scheduling budget reserved for transformation and finalization')
        if not self._lock.acquire(blocking=False):
            raise ValueError("Fast runtime permits only one operation at a time per batch")
        request, request_ref, diagnostics = None, None, ()
        try:
            self.check_active()
            if stage not in STAGE_CALL_LIMITS:
                raise ValueError("Unsupported governed Auto-map model stage")
            backend = self._specialist_backend if stage == "transformation_rule" else self.bundle.backend
            if backend is None:
                raise ValueError("Governed transformation specialist is unavailable")
            if self._stage_calls[stage] >= STAGE_CALL_LIMITS[stage]:
                raise ValueError("Auto-map stage call budget exhausted")
            operation = "sttm.transform" if stage == "transformation_rule" else self._operation
            if self._stop.is_set():
                raise ValueError("Fast runtime stopped; transport failures must not be retried")
            if (type(call_index) is not int or not 1 <= call_index <= self._max_calls
                    or call_index in self._requests):
                raise ValueError("Fast call_index must identify an unused operation within the call budget")
            self._service._model_guard.assert_model_target_allowed(
                operation=operation, target="agent", decision=self._decision)
            if type(messages) is not list or any(type(message) is not dict for message in messages):
                raise ValueError("Fast model requires normalized user messages")
            from app.core.automap_evidence_tool import enabled, EvidenceToolContext, tool_hint, requested_targets
            normalized = SnowflakeAgentClient._normalize_messages(deepcopy(messages))
            operation_targets = requested_targets(normalized, self._target_ids)
            tool = None
            if enabled(self._service._settings, stage) and stage in {'source_mapping','transformation_rule'}:
                tool = EvidenceToolContext(runtime=self, store=self._store, request=None, stage=stage,
                    message_chars=0, message_bytes=0)
                tool.body['targets'] = list(operation_targets)
                tool.body['records'] = [record for record in tool.body['records'] if set(record['targets']).intersection(operation_targets)]
                with_hint = deepcopy(normalized)
                with_hint[0]['content'].append(tool_hint(tool.handle, operation_targets))
                candidate_message = _json(with_hint)
                if len(candidate_message) <= self._budget.max_chars and len(candidate_message.encode()) <= self._budget.max_bytes:
                    normalized = with_hint
                else:
                    tool = None
            message = _json(normalized)
            if tool is not None:
                tool.max_chars = max(0, min(32000, self._budget.max_chars-len(message)))
                tool.max_bytes = max(0, min(32000, self._budget.max_bytes-len(message.encode())))
            if len(message) > self._budget.max_chars or len(message.encode("utf-8")) > self._budget.max_bytes:
                raise AgentPayloadBudgetError("Complete normalized fast model messages exceed the budget")
            # The namespace includes the trusted factory job, not a request's job
            # or agent override. A second parse attempt gets a different identity.
            shard_id = _hash(_json([self.bundle.admission.job_id, operation, call_index]))
            request = ScanRequest(scope=self.bundle.scope, generation=self.bundle.scope.snapshot_id,
                shard_id=shard_id, target_ids=operation_targets, record_ids=(),
                message=message, output_budget=self._output_budget, deadline=self._deadline + self.admission_wait_seconds,
                _cancel=self._cancel, _stop=self._stop, runtime_trace=RuntimeCallTrace(),
                capacity_wait_limit_seconds=max(0,getattr(self._service._settings,'automap_queue_seconds',900)-self.admission_wait_seconds))
            request.check_active()
            _request_body(request, new_thread=True)  # Reject history/tools before admission or archive I/O.
            self._requests[call_index] = request
            self._stage_calls[stage] += 1
            self._request_stages[call_index] = stage
            self._backends[call_index] = backend
            request_text = self._archive_text({
                "protocol": "automap_fast_model_request_v1",
                "parent_request_id": str(self._req.request_id),
                "snapshot_archive_ref": self.snapshot_archive_ref,
                "job_id": self.bundle.admission.job_id, "call_index": call_index,
                "operation": operation, "agent_fqn": backend._config.agent,
                "request_digest": request_digest(request),
                "request": {"scope": asdict(request.scope), "generation": request.generation,
                    "shard_id": request.shard_id, "target_ids": list(request.target_ids),
                    "record_ids": [], "message": request.message,
                    "output_budget": asdict(request.output_budget), "deadline": request.deadline},
            }, request.generation)
            request_ref = _hash(request_text)
            request = replace(request, request_archive_ref=request_ref)
            self._requests[call_index] = request
            trace = request.runtime_trace
            from app.core.automap_runtime import SnowflakeReductionArchive
            archive = self.bundle.archive
            if self.admission_wait_seconds and hasattr(archive, 'with_deadline'):
                archive = archive.with_deadline(archive._deadline + self.admission_wait_seconds)
            initial = {self.snapshot_archive_ref: self._snapshot_text, request_ref: request_text}
            if (not self._snapshot_committed and isinstance(archive, SnowflakeReductionArchive)
                    and archive.can_put_many(initial)):
                archive.put_many_verified(initial,
                    on_read=lambda: trace.enter(RuntimePhase.REQUEST_READBACK))
                self._snapshot_committed = True
            else:
                if not self._snapshot_committed:
                    self._save_text(self._snapshot_text, trace=trace, read_phase=RuntimePhase.SNAPSHOT_READBACK)
                    self._snapshot_committed = True
                request.check_active()
                trace.enter(RuntimePhase.REQUEST_WRITE)
                self._save_text(request_text, trace=trace, read_phase=RuntimePhase.REQUEST_READBACK)
            request.check_active()
            if tool is not None:
                tool.request = request
                try:
                    tool.register(archive)
                except Exception as exc:
                    # Optional evidence availability never invalidates the complete
                    # supplied packet. Never include native SQL/error text here.
                    logger.warning('Auto-map optional evidence registration unavailable error_type=%s', type(exc).__name__)
            cached = backend.find_result(request) if hasattr(backend,'find_result') else None
            if cached is not None:
                return cached, None, {'fast_diagnostics':{**self._metadata(request,call_index,request_ref,()),
                    'reused_terminal_result':True,'model_post_attempts':0}}
            trace.enter(RuntimePhase.ADMISSION_WAIT)
            with self.bundle.admission(request) as admitted:
                if admitted is not True:
                    raise ValueError("Fast model dispatch requires global admission")
                try:
                    already_completed = backend.find_result(request) if hasattr(backend,'find_result') else None
                    if already_completed is not None:
                        raw = self.bundle.admission.wrap_backend(lambda unused: already_completed)(request)
                    else:
                        raw = (self._guarded if stage != "transformation_rule" else
                               self.bundle.admission.wrap_backend(backend))(request)
                    trace.enter(RuntimePhase.ADMISSION_CLEANUP)
                finally:
                    # Diagnostic collection must not replace a transport failure.
                    try:
                        diagnostics = self.bundle.admission.diagnostics_for(request)
                    except Exception:
                        diagnostics = ()
            # Do not put archive writes inside the gate or its diagnostic sink:
            # provider completion and model-schema correctness are separate.
            trace.enter(RuntimePhase.RESPONSE_WRITE)
            metadata = {**self._metadata(request, call_index, request_ref, diagnostics),
                "stage": stage, "global_admission": True, "pool_capacity": self.bundle.admission.store.capacity}
            response_ref = self._save_text(self._archive_text({
                "protocol": "automap_fast_model_response_v1", "request_archive_ref": request_ref,
                "raw": raw, "fast_diagnostics": metadata,
            }, request.generation), trace=trace, read_phase=RuntimePhase.RESPONSE_READBACK)
            trace.archived_responses = 1
            trace.enter(RuntimePhase.FINAL_CHECK)
            request.check_active()
            trace.finish()
            return raw, None, {"fast_diagnostics": {**metadata, **trace.snapshot(), "response_archive_ref": response_ref}}
        except BaseException as error:
            # A new operation is allowed only after a returned, durably archived
            # terminal answer. HTTP failures, lost ACKs and archive errors stop.
            self._stop.set()
            if request is not None and request.runtime_trace is not None:
                request.runtime_trace.finish()
            if request is not None and request_ref is not None:
                self._record_failure(error, request, call_index, request_ref, diagnostics)
            raise
        finally:
            self._lock.release()


# This limit is per worker process. It does not claim account-wide admission.
_SESSION_GATES = {}
_SESSION_GATES_LOCK = Lock()


class FastSessionModelRuntime(FastModelRuntime):
    """Bounded same-caller agent calls independent of the experimental scan pool.

    A transport failure stops this runtime. No automatic replay of uncertain calls.
    Source decisions have three calls; the rule stage has generation plus one repair.
    """
    def __init__(self, *, service, req, decision, store, deadline):
        from threading import BoundedSemaphore
        import time
        self._service, self._decision = service, decision
        self._req = req
        self._request_stages = {}
        self._operation = req.operation.value
        self._deadline = deadline
        self._stop, self._cancel = Event(), Event()
        self._lock = Lock()
        self._requests, self._backends = {}, {}
        self._failure_diagnostics = None
        self._max_calls = MAX_RUNTIME_CALLS
        self._stage_calls = dict.fromkeys(STAGE_CALL_LIMITS, 0)
        self._job_id = __import__('uuid').uuid4().hex
        self._agent = service._agent
        if getattr(service._settings, 'automap_local_sso_enabled', False):
            from app.core.automap_local_session import bind_local_agent
            self._agent = bind_local_agent(service)
        self._agents = {'source_mapping': service._source_mapping_agent_name,
                        'evidence_review': service._source_mapping_agent_name,
                        'transformation_rule': service._transformation_agent_name}
        from app.core.automap_input_budget import input_limits
        from app.core.automap_shards import MessageBudget
        self._budget = MessageBudget(*input_limits(service._settings))
        capacity = service._settings.automap_fast_max_in_flight
        key = (self._agent._base_url, capacity)
        with _SESSION_GATES_LOCK:
            self._gate = _SESSION_GATES.setdefault(key, BoundedSemaphore(capacity))
        self.capacity = capacity
        self.snapshot_archive_ref = store.snapshot_hash

    def run(self, messages, call_index, *, stage='source_mapping'):
        import time
        if (getattr(self._req, 'meta', None) or {}).get('automap_rules_policy') == 'rules-v2' and stage != 'transformation_rule':
            cutoff = getattr(self, '_source_schedule_deadline', None)
            if cutoff is None:
                now = time.monotonic()
                self._source_schedule_deadline = now + max(0, self._deadline - now) * .6
            reserve = 2 if self._max_calls >= 4 else 1 if self._max_calls >= 2 else 0
            if time.monotonic() >= self._source_schedule_deadline + self.admission_wait_seconds or call_index > self._max_calls - reserve:
                raise TimeoutError('Source scheduling budget reserved for transformation and finalization')
        if not self._lock.acquire(blocking=False):
            raise ValueError('Concurrent calls within one Auto-map batch are forbidden')
        acquired = False
        try:
            self.check_active()
            if stage not in self._agents or not self._agents[stage]:
                raise ValueError('Unsupported Auto-map agent stage')
            if call_index != self.next_call_index or call_index > self._max_calls:
                raise ValueError('Auto-map call index must be sequential and within the call budget')
            if self._stage_calls[stage] >= STAGE_CALL_LIMITS[stage]:
                raise ValueError('Auto-map stage call budget exhausted')
            normalized = SnowflakeAgentClient._normalize_messages(deepcopy(messages))
            wire = _json(normalized)
            if len(wire) > self._budget.max_chars or len(wire.encode('utf-8')) > self._budget.max_bytes:
                raise AgentPayloadBudgetError('Complete Auto-map packet exceeds the input budget')
            operation = 'sttm.transform' if stage == 'transformation_rule' else self._operation
            self._service._model_guard.assert_model_target_allowed(operation=operation, target='agent', decision=self._decision)
            acquired = self._gate.acquire(timeout=max(0, self._deadline - time.monotonic()))
            if not acquired:
                raise TimeoutError('Auto-map in-flight capacity deadline exceeded')
            self.check_active()
            self._requests[call_index] = _hash(wire)
            self._stage_calls[stage] += 1
            self._request_stages[call_index] = stage
            run_options = {"agent": self._agents[stage]}
            if getattr(self._service._settings, "automap_local_request_specs", False):
                from app.core.automap_local_session import local_run_spec
                run_options = {"run_config": local_run_spec(self._service._settings, "source_mapping" if stage == "evidence_review" else stage)}
            raw, thread, payload = self._agent.run_detailed(normalized,
                thread_id=None, parent_message_id=None, allow_retries=False,
                request_timeout=max(1, self._deadline - time.monotonic()), **run_options)
            self.check_active()
            return raw, thread, {**(payload or {}), 'fast_diagnostics': {
                'call_index': call_index, 'job_id': self._job_id, 'stage': stage,
                'global_admission': False, 'admission': 'process_semaphore',
                'pool_capacity': self.capacity, 'request_digest': _hash(wire)}}
        except BaseException:
            self._stop.set()
            raise
        finally:
            if acquired:
                self._gate.release()
            self._lock.release()
