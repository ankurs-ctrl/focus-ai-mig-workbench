"use client";

import { useMemo } from "react";
import { useAppSelector } from "@/store/hooks";
import { computeMappingValidationSignature } from "@/features/sttm/shared/mapping-validation";

/**
 * Whether the current workspace has passed Compile & Validate since its last change.
 * `signature` is the current workspace fingerprint to store after a successful validation.
 */
export function useMappingValidationStatus() {
  const builder = useAppSelector((state) => state.sttmBuilder);
  const {
    sourceDatabases,
    sources,
    targetDatabases,
    targets,
    drivingTableId,
    derivedSources,
    relationships,
    mappings,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    sqlValidatedSignature,
  } = builder;

  const signature = useMemo(
    () =>
      computeMappingValidationSignature({
        sourceDatabases,
        sources,
        targetDatabases,
        targets,
        drivingTableId,
        derivedSources,
        relationships,
        mappings,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [
      derivedSources,
      drivingTableId,
      mappings,
      relationships,
      sourceDatabases,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
      sources,
      targetDatabases,
      targets,
    ],
  );

  return {
    signature,
    isValidated: sqlValidatedSignature !== null && sqlValidatedSignature === signature,
  };
}
