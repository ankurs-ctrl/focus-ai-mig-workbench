from __future__ import annotations

import hashlib
import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable

from pydantic import ValidationError
from sqlglot import exp, parse_one
from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.mapping_contracts import column_identity, optional_identifier, published_expression, relationship_signature
from app.core.performance import increment, observe
from app.schema.fir_patterns import (
    FIRLearningJobResponse,
    TargetMappingPatternCandidate,
    TargetMappingPatternV2,
)

_PLACEHOLDER = re.compile(r"^\$[A-Za-z_][A-Za-z0-9_]*$")
_LITERAL = re.compile(
    r"^\s*(?:'[^']*'|\"[^\"]*\"|-?\d+(?:\.\d+)?|TRUE|FALSE|NULL)\s*$",
    re.IGNORECASE,
)
logger = logging.getLogger(__name__)


def _clip(value: Any, limit: int) -> Any:
    text = value if isinstance(value, str) else None
    if text is None or len(text) <= limit:
        return value
    return text[: limit - 1].rstrip() + "…"


def _names(values: Any, limit: int) -> list[str]:
    """Reduce a column/table list (strings or dicts carrying expressions) to names."""
    names: list[str] = []
    for value in values if isinstance(values, list) else []:
        if isinstance(value, dict):
            value = value.get("name") or value.get("alias") or value.get("column") or value.get("table")
        if value not in (None, ""):
            names.append(_clip(str(value), 80))
        if len(names) >= limit:
            break
    return names


def compact_candidate_for_agent(candidate: dict[str, Any]) -> dict[str, Any]:
    """Agent-facing view of a ranked pattern.

    Stored patterns embed every CTE body, join and query-shaping rule of the source
    mapping (avg ~25K chars, up to ~150K). The compatibility decision has already
    been computed from them; the agent needs which CTEs/joins/rules the recipe relies
    on, not their full SQL. Without this a single 6-column Auto-map batch exceeds the
    payload budget and compaction drops all learning context.
    """
    pattern = dict(candidate.get("pattern") or {})
    # Model context projection now resolves dependencies. Do not truncate the
    # canonical rationale or CTE outputs before that selection has taken place.
    recipe = pattern.get("mapping_recipe") or {}
    dependencies = [*(recipe.get("source_dependencies") or []), *(recipe.get("logical_source_dependencies") or [])]
    required_outputs = {str(value).rsplit(".", 1)[-1].strip('"').upper() for value in dependencies}
    pattern["derived_dependencies"] = [
        {
            "name": item.get("name"),
            "purpose": item.get("purpose"),
            "output_columns": item.get("output_columns") or [],
            "tables_referenced": item.get("tables_referenced") or [],
            "sql_text": item.get("sql_text") if required_outputs & {
                name.upper() for name in _names(item.get("output_columns"), 10000)
            } or any(str(value).upper().startswith(str(item.get("name") or "").upper() + ".")
                     for value in dependencies) else None,
            "lineage_status": "candidate_requires_validation",
        }
        for item in pattern.get("derived_dependencies") or []
        if isinstance(item, dict)
    ]
    pattern["relationship_dependencies"] = [
        {
            key: item.get(key)
            for key in ("left_table", "right_table", "join_type", "condition", "conditions", "keys")
            if item.get(key) not in (None, "", [])
        }
        for item in pattern.get("relationship_dependencies") or []
        if isinstance(item, dict)
    ]
    pattern["query_shaping_dependencies"] = [
        {
            key: item.get(key)
            for key in ("rule_type", "description", "sql_fragment")
            if item.get(key) not in (None, "", [])
        }
        for item in pattern.get("query_shaping_dependencies") or []
        if isinstance(item, dict)
    ]
    pattern["business_rationale"] = pattern.get("business_rationale")
    for key in ("relationship_dependencies", "query_shaping_dependencies"):
        pattern[key] = list({json.dumps(item, sort_keys=True, default=str): item
                             for item in pattern[key]}.values())
    for key in ("content_hash", "source_compatibility_signature"):
        pattern.pop(key, None)
    return {**candidate, "pattern": pattern}


class _FIRWorkDeferred(RuntimeError):
    """Work remains queued because a feature or daily budget gate is closed."""


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
    ).hexdigest()


def _semantic_role(name: str) -> str:
    raw = str(name or "").split(".")[-1].upper()
    if raw.endswith("__C"):
        raw = raw[:-3]
    normalized = re.sub(r"[^A-Z0-9]+", "_", raw).strip("_")
    for suffix in ("_ID", "_CODE", "_DATE", "_NAME", "_STATUS"):
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)]
    return normalized


_QUALIFIER = re.compile(r'(?:"?[A-Za-z_][A-Za-z0-9_$]*"?\s*\.\s*)+(?="?[A-Za-z_])')
# Independent agreement raises a pattern's confidence by this step, up to the cap.
_INDEPENDENT_SUPPORT_STEP = 0.01
_REUSE_CONFIDENCE_CAP = 0.995


def _normalize_expression(expression: Any) -> str:
    """Normalize column qualifiers without changing case-sensitive literal values."""
    text = str(expression or "").strip()
    if not text:
        return ""
    try:
        tree = parse_one(text, read="snowflake")
        for column in tree.find_all(exp.Column):
            column.set("catalog", None)
            column.set("db", None)
            column.set("table", None)
            if not column.this.args.get("quoted"):
                column.this.set("this", column.name.upper())
            elif column.name == column.name.upper():
                column.this.set("quoted", False)
        return tree.sql(dialect="snowflake")
    except Exception:
        return text


def _source_shape(column: Any) -> str:
    """Table leaf plus column, so the same source read in another environment matches."""
    parts = [part.strip().strip('"').upper() for part in str(column or "").split(".") if part.strip()]
    return ".".join(parts[-2:])


def reuse_key_for(
    *,
    target_key: Any,
    target_column: Any,
    source_system: Any,
    mode: Any,
    source_columns: Iterable[Any],
    expression: Any,
    placeholder: Any,
    project_scope: Any,
    contract_version: Any = None,
    source_contract: Any = None,
) -> str:
    """Identity of "this target column is fed this way from this source shape".

    Stored as PATTERN_PAYLOAD:reuse_key. The CLAIM_KEY column is not used: on
    shared environments it holds a claim-type label written by the deep-agent
    control plane, not an identity.
    """
    return "reuse_" + _stable_hash(
        {
            "v": 2,
            "target": str(optional_identifier(target_key) or "").replace('"', "").strip().upper(),
            "contract_version": optional_identifier(contract_version),
            "source_contract": source_contract,
            "target_column": str(target_column or "").strip().upper(),
            "source_system": str(source_system or "").strip().upper(),
            "mode": str(mode or "").lower(),
            "sources": sorted({_source_shape(item) for item in source_columns if item}),
            "expression": _normalize_expression(expression),
            "placeholder": placeholder,
            "project_scope": project_scope,
        }
    )[:40]


def reuse_key_for_payload(payload: dict[str, Any]) -> str:
    """Reuse key of a stored pattern payload (used for corrections and backfill)."""
    target = payload.get("target_contract") if isinstance(payload.get("target_contract"), dict) else {}
    recipe = payload.get("mapping_recipe") if isinstance(payload.get("mapping_recipe"), dict) else {}
    profile = (
        payload.get("source_system_profile")
        if isinstance(payload.get("source_system_profile"), dict)
        else {}
    )
    return reuse_key_for(
        target_key=optional_identifier(target.get("logical_target_key")) or target.get("target_fqn"),
        target_column=target.get("target_column"),
        source_system=profile.get("vendor_family"),
        mode=recipe.get("mode"),
        source_columns=recipe.get("source_dependencies") or [],
        expression=recipe.get("expression"),
        placeholder=recipe.get("placeholder"),
        project_scope=payload.get("project_id") if payload.get("scope") == "project" else None,
        contract_version=target.get("contract_version"),
        source_contract=payload.get("source_recipe_contract") or _source_recipe_contract(payload),
    )


def _source_recipe_contract(payload: dict[str, Any]) -> str | None:
    dependencies = {
        key: payload.get(key) or []
        for key in ("relationship_dependencies", "derived_dependencies", "query_shaping_dependencies")
    }
    return _stable_hash(dependencies) if any(dependencies.values()) else None


def _split_sources(value: Any) -> list[str]:
    if isinstance(value, list):
        raw = value
    elif value in (None, ""):
        raw = []
    else:
        raw = re.split(r"\s*,\s*|\s*;\s*", str(value))
    return sorted({str(item).strip() for item in raw if str(item).strip()})


def _vendor_family_from_sources(source_tables: Iterable[str]) -> str | None:
    joined = " ".join(str(item).upper() for item in source_tables)
    known_families = {
        "REDTAIL": ("REDTAIL",),
        "EVERNEST": ("EVERNEST",),
        "SALESFORCE": ("SALESFORCE", "SFDC"),
        "WEALTHBOX": ("WEALTHBOX",),
        "ADDEPAR": ("ADDEPAR",),
        "ORION": ("ORION",),
        "TAMARAC": ("TAMARAC",),
    }
    for family, markers in known_families.items():
        if any(marker in joined for marker in markers):
            return family
    return None


def _type_family(value: Any) -> str:
    normalized = str(value or "").upper()
    if any(marker in normalized for marker in ("CHAR", "TEXT", "STRING")):
        return "string"
    if any(marker in normalized for marker in ("NUMBER", "DECIMAL", "INT", "FLOAT", "DOUBLE")):
        return "number"
    if "TIMESTAMP" in normalized:
        return "timestamp"
    if "DATE" in normalized:
        return "date"
    if "BOOL" in normalized:
        return "boolean"
    return normalized


class TargetMappingPatternService:
    """Content-addressed target-column learning with guarded transfer ranking."""

    def __init__(self, session: Session, settings: Settings) -> None:
        self._session = session
        self._settings = settings
        self._patterns_table = settings.qualify_table_name(
            settings.snowflake_target_mapping_patterns_table
        )
        self._jobs_table = settings.qualify_table_name(
            settings.snowflake_fir_learning_jobs_table
        )
        self._items_table = settings.qualify_table_name(
            settings.snowflake_fir_learning_work_items_table
        )
        qualify_metadata = getattr(
            settings,
            "qualify_metadata_object_name",
            settings.qualify_table_name,
        )
        self._observability_table = qualify_metadata(
            "TBL_FIR_RUN_OBSERVABILITY"
        )

    @staticmethod
    def _quote(value: Any) -> str:
        return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"

    def extract_document_patterns(
        self,
        *,
        asset_id: str,
        project_id: str,
        parsed_document: dict[str, Any],
        evidence_class: str,
        base_confidence: float,
    ) -> list[TargetMappingPatternV2]:
        source_tables = _split_sources(
            parsed_document.get("source_tables")
            or parsed_document.get("source_datasets")
        )
        default_target = str(
            parsed_document.get("target_table")
            or next(iter(parsed_document.get("target_tables") or []), "")
        )
        joins = [
            item
            for item in parsed_document.get("join_patterns") or []
            if isinstance(item, dict)
        ]
        ctes = [
            item
            for item in parsed_document.get("ctes") or []
            if isinstance(item, dict)
        ]
        query_shape = [
            item
            for item in parsed_document.get("business_rules") or []
            if isinstance(item, dict)
        ]
        patterns: list[TargetMappingPatternV2] = []
        for index, row in enumerate(parsed_document.get("column_mappings") or []):
            if not isinstance(row, dict):
                continue
            target_column = str(
                row.get("target_alias")
                or row.get("target_field")
                or row.get("target_column")
                or ""
            ).strip()
            target_table = str(row.get("target_table") or default_target).strip()
            if not target_column:
                continue
            if row.get("unresolved_references"):
                continue
            logical_source_columns = _split_sources(
                row.get("source_columns")
                or row.get("source_field")
                or row.get("source_column")
            )
            physical_source_columns = _split_sources(
                row.get("physical_source_columns")
            )
            source_columns = physical_source_columns or logical_source_columns
            mapping_source_tables = sorted(
                {
                    column.rsplit(".", 1)[0]
                    for column in physical_source_columns
                    if "." in column
                }
            )
            source_dataset = str(
                row.get("source_dataset") or row.get("source_table") or ""
            ).strip()
            if source_dataset and source_dataset not in source_tables:
                source_tables = sorted({*source_tables, source_dataset})
            expression = published_expression(row)
            constant = row.get("constant_value")
            if not source_columns and not expression and constant is None:
                continue
            mapping_mode = str(row.get("mapping_mode") or "").lower()
            if constant is not None or (
                expression and _PLACEHOLDER.match(expression)
            ):
                mapping_mode = "value"
            elif expression and any(
                marker in expression.upper()
                for marker in ("CASE ", "COALESCE(", "CONCAT", "||", "CAST(")
            ):
                mapping_mode = "complex"
            elif not mapping_mode:
                mapping_mode = "direct"

            # Client/project-specific literals may be evidence, but they are
            # never promoted as client-wide reusable values.
            placeholder = (
                str(constant)
                if constant is not None and _PLACEHOLDER.match(str(constant))
                else expression
                if _PLACEHOLDER.match(expression)
                else None
            )
            has_project_literal = bool(
                placeholder is None and (
                    constant is not None and _LITERAL.match(str(constant))
                    or expression and _LITERAL.match(expression)
                )
            )
            # SQL NULL is a reusable expression, not a redacted project identifier.
            if expression.strip().upper() == 'NULL' or str(constant).strip().upper() == 'NULL':
                expression = 'NULL'
                has_project_literal = False
            scope = (
                "project"
                if has_project_literal or evidence_class == "explicit_user_correction"
                else "client"
            )
            recipe = {
                "mode": mapping_mode,
                "source_dependencies": source_columns,
                "logical_source_dependencies": logical_source_columns,
                "expression": expression if not has_project_literal else None,
                "expression_fingerprint": _stable_hash(expression) if expression else None,
                "placeholder": placeholder,
                "has_project_specific_literal": has_project_literal,
                "natural_language_rule": row.get("field_definition"),
                "target_type": row.get("target_data_type") or row.get("target_type"),
                "processing_order": row.get("processing_order"),
                "depends_on": row.get("depends_on"),
            }
            target_contract = {
                "target_fqn": target_table,
                "logical_target_key": optional_identifier(parsed_document.get("logical_target_key")),
                "contract_version": optional_identifier(parsed_document.get("target_contract_version")),
                "target_column": target_column,
                "business_meaning": row.get("field_definition"),
                "semantic_role": _semantic_role(target_column),
                "type": row.get("target_data_type") or row.get("target_type"),
                "grain": row.get("grain"),
                "nullability": row.get("nullability"),
                "synonyms": row.get("synonyms") or [],
                "domain": row.get("domain")
                or (parsed_document.get("project_context") or {}).get("domain"),
            }
            captured_profiles = {
                column_identity(item.get("physical_name")): item
                for item in row.get("source_column_profiles") or []
                if isinstance(item, dict) and item.get("physical_name")
            }
            source_profile = {
                "vendor_family": parsed_document.get("source_system")
                or parsed_document.get("crm_family"),
                "source_tables": mapping_source_tables or source_tables,
                "entity_meaning": parsed_document.get("entity_meaning"),
                # Business purpose of the project this pattern was learned in.
                "project_context": parsed_document.get("project_context") or None,
                "source_columns": [
                    {
                        "physical_name": column,
                        "semantic_role": captured_profiles.get(column_identity(column), {}).get("semantic_role") or _semantic_role(column),
                        # Row-level contracts only describe a single-source mapping.
                        "type": captured_profiles.get(column_identity(column), {}).get("type") or (row.get("source_type") if len(source_columns) == 1 else None),
                        "grain": captured_profiles.get(column_identity(column), {}).get("grain") or (row.get("source_grain") if len(source_columns) == 1 else None),
                    }
                    for column in source_columns
                ],
            }
            signature = _stable_hash(
                {
                    "target_role": target_contract["semantic_role"],
                    "source_roles": sorted(
                        item["semantic_role"]
                        for item in source_profile["source_columns"]
                    ),
                    "mode": mapping_mode,
                }
            )
            identity = {
                "target_table": str(
                    optional_identifier(parsed_document.get("logical_target_key")) or target_table
                ).upper(),
                "target_column": target_column.upper(),
                "recipe": recipe,
                "project_scope": project_id if scope == "project" else None,
            }
            lineage_text = json.dumps(
                row.get("lineage_path") or [],
                default=str,
            ).upper()
            mapping_ctes = [
                cte
                for cte in ctes
                if str(cte.get("name") or "").upper() in lineage_text
                or any(str(column).upper().startswith(str(cte.get("name") or "").upper() + ".")
                       for column in logical_source_columns)
            ]
            dependency_tokens = {
                token.upper()
                for token in [
                    *source_columns,
                    *(mapping_source_tables or []),
                ]
                if token
            }
            mapping_joins = [
                join
                for join in joins
                if any(
                    token in json.dumps(join, default=str).upper()
                    for token in dependency_tokens
                )
            ]
            source_recipe_contract = _source_recipe_contract({
                "relationship_dependencies": mapping_joins,
                "derived_dependencies": mapping_ctes,
                "query_shaping_dependencies": query_shape,
            })
            reuse_key = reuse_key_for(
                target_key=target_contract["logical_target_key"] or target_table,
                target_column=target_column, source_system=source_profile["vendor_family"],
                mode=mapping_mode, source_columns=source_columns,
                expression=recipe["expression"], placeholder=placeholder,
                project_scope=project_id if scope == "project" else None,
                contract_version=target_contract.get("contract_version"),
                source_contract=source_recipe_contract,
            )
            content_hash = _stable_hash({**identity, "source_recipe_contract": source_recipe_contract})
            patterns.append(
                TargetMappingPatternV2(
                    pattern_id=f"tmp_{content_hash[:24]}",
                    scope=scope,
                    project_id=project_id,
                    target_contract=target_contract,
                    source_system_profile=source_profile,
                    source_compatibility_signature=signature,
                    mapping_recipe=recipe,
                    relationship_dependencies=mapping_joins,
                    derived_dependencies=mapping_ctes,
                    query_shaping_dependencies=query_shape,
                    business_rationale=row.get("field_definition"),
                    applicability_conditions=[],
                    exclusions=(
                        ["Do not reuse the project-specific literal."]
                        if has_project_literal
                        else []
                    ),
                    confidence=base_confidence,
                    validation_status="extracted",
                    provenance={
                        "asset_id": asset_id,
                        "evidence_class": evidence_class,
                        "source": "deterministic_document_extraction",
                        "row_index": index,
                    },
                    evidence_ids=[asset_id],
                    content_hash=content_hash,
                    reuse_key=reuse_key,
                    source_recipe_contract=source_recipe_contract,
                )
            )
        return patterns

    @staticmethod
    def _support_key(pattern: TargetMappingPatternV2) -> str:
        """The piece of evidence a pattern came from: one mapping or one uploaded asset."""
        if pattern.sttm_id:
            return f"sttm:{pattern.sttm_id}"
        asset_id = str(pattern.provenance.get("asset_id") or "").strip()
        return f"asset:{asset_id}" if asset_id else ""

    def _merge_patterns_sql(self, rows_json: str) -> str:
        history_enabled = getattr(self._settings, "fir_canonical_history_v1", False)
        # The evidence already counted lives in PATTERN_PAYLOAD:support_keys.
        # Rows written before it existed count their own mapping once.
        existing_keys = (
            "COALESCE(target.PATTERN_PAYLOAD:support_keys::ARRAY, IFF(target.STTM_ID IS NULL, "
            "ARRAY_CONSTRUCT(), ARRAY_CONSTRUCT('sttm:' || target.STTM_ID)))"
        )
        independent = (
            "(source.SUPPORT_KEY <> '' AND NOT ARRAY_CONTAINS("
            f"source.SUPPORT_KEY::VARIANT, {existing_keys}))"
        )
        if history_enabled:
            independent = f"({independent} AND source.VALIDATION_STATUS IN ('accepted', 'validated', 'published'))"
        support_keys = (
            f"IFF({independent}, ARRAY_APPEND({existing_keys}, source.SUPPORT_KEY), {existing_keys})"
        )
        hash_match = "target.CONTENT_HASH = source.CONTENT_HASH"
        target_match = "target.TARGET_TABLE = source.TARGET_TABLE"
        column_match = "target.TARGET_COLUMN = source.TARGET_COLUMN"
        scope_match = """AND target.SCOPE = source.SCOPE
                AND (source.SCOPE NOT IN ('project', 'mapping') OR COALESCE(target.PROJECT_ID, '') = source.PROJECT_ID)
                AND (source.SCOPE <> 'mapping' OR COALESCE(target.STTM_ID, '') = source.STTM_ID)"""
        source_confidence = "source.CONFIDENCE"
        confidence_replacement = """(source.CONFIDENCE >= target.CONFIDENCE
                AND (source.VALIDATION_STATUS IN ('accepted', 'validated', 'published')
                     OR target.VALIDATION_STATUS NOT IN ('accepted', 'validated', 'published')))"""
        if history_enabled:
            source_confidence = "IFF(source.VALIDATION_STATUS IN ('accepted', 'validated', 'published'), source.CONFIDENCE, target.CONFIDENCE)"
            hash_match = f"({hash_match} AND target.PATTERN_PAYLOAD:reuse_key::STRING = source.REUSE_KEY)"
            target_match = "target.TARGET_TABLE = source.TARGET_TABLE"
            column_match = "target.TARGET_COLUMN = source.TARGET_COLUMN"
            confidence_replacement = """(source.CONFIDENCE >= target.CONFIDENCE
                AND (source.VALIDATION_STATUS IN ('accepted', 'validated', 'published')
                     OR target.VALIDATION_STATUS NOT IN ('accepted', 'validated', 'published')))"""
        lifecycle = """CASE
                    WHEN source.VALIDATION_STATUS = 'published' THEN 'published'
                    WHEN source.VALIDATION_STATUS = 'validated'
                         AND target.VALIDATION_STATUS <> 'published' THEN 'validated'
                    WHEN source.VALIDATION_STATUS = 'accepted'
                         AND target.VALIDATION_STATUS IN ('extracted', 'enriched') THEN 'accepted'
                    ELSE target.VALIDATION_STATUS
                END"""
        # Both representations use the same authority; enrichment is not validation.
        sql = f"""
            MERGE INTO {self._patterns_table} target
            USING (
                SELECT
                    f.value:pattern_id::STRING AS PATTERN_ID,
                    f.value:content_hash::STRING AS CONTENT_HASH,
                    NULLIF(f.value:reuse_key::STRING, '') AS REUSE_KEY,
                    f.value:scope::STRING AS SCOPE,
                    COALESCE(f.value:project_id::STRING, '') AS PROJECT_ID,
                    COALESCE(f.value:sttm_id::STRING, '') AS STTM_ID,
                    f.value:target_table::STRING AS TARGET_TABLE,
                    f.value:target_column::STRING AS TARGET_COLUMN,
                    f.value:payload AS PATTERN_PAYLOAD,
                    f.value:confidence::FLOAT AS CONFIDENCE,
                    f.value:validation_status::STRING AS VALIDATION_STATUS,
                    COALESCE(f.value:support_key::STRING, '') AS SUPPORT_KEY
                FROM TABLE(FLATTEN(INPUT => PARSE_JSON({self._quote(rows_json)}))) f
            ) source
            ON (
                (source.REUSE_KEY IS NOT NULL
                AND target.PATTERN_PAYLOAD:reuse_key::STRING = source.REUSE_KEY)
                OR {hash_match}
            )
            AND {target_match}
            AND {column_match}
            {scope_match}
            AND COALESCE(target.PATTERN_PAYLOAD:target_contract:contract_version::STRING, '')
                = COALESCE(source.PATTERN_PAYLOAD:target_contract:contract_version::STRING, '')
            WHEN MATCHED AND target.STATUS = 'active' AND target.SUPERSEDED_BY IS NULL THEN UPDATE SET
                CONFIDENCE = IFF(
                    {independent},
                    LEAST(
                        {_REUSE_CONFIDENCE_CAP},
                        GREATEST(target.CONFIDENCE, {source_confidence}) + {_INDEPENDENT_SUPPORT_STEP}
                    ),
                    GREATEST(target.CONFIDENCE, {source_confidence})
                ),
                SUPPORT_COUNT = IFF({independent}, target.SUPPORT_COUNT + 1, target.SUPPORT_COUNT),
                VALIDATION_STATUS = {lifecycle},
                PATTERN_PAYLOAD = OBJECT_INSERT(
                    OBJECT_INSERT(
                    OBJECT_INSERT(
                        CASE
                            WHEN source.PATTERN_PAYLOAD:provenance:evidence_class::STRING
                                 = 'explicit_user_correction'
                              OR {confidence_replacement}
                                THEN OBJECT_INSERT(source.PATTERN_PAYLOAD, 'pattern_id', target.PATTERN_ID, TRUE)
                            ELSE target.PATTERN_PAYLOAD
                        END,
                        'support_keys', {support_keys}, TRUE
                    ),
                    'reuse_key',
                    COALESCE(source.REUSE_KEY, target.PATTERN_PAYLOAD:reuse_key::STRING, ''),
                    TRUE
                    ), 'validation_status', {lifecycle}, TRUE
                ),
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN INSERT (
                PATTERN_ID, CONTENT_HASH, SCOPE, PROJECT_ID, STTM_ID,
                TARGET_TABLE, TARGET_COLUMN, PATTERN_PAYLOAD, CONFIDENCE,
                SUPPORT_COUNT, CONTRADICTION_COUNT, VALIDATION_STATUS,
                STATUS, CREATED_AT, UPDATED_AT
            ) VALUES (
                source.PATTERN_ID, source.CONTENT_HASH, source.SCOPE,
                NULLIF(source.PROJECT_ID, ''), NULLIF(source.STTM_ID, ''),
                source.TARGET_TABLE, source.TARGET_COLUMN,
                OBJECT_INSERT(
                    source.PATTERN_PAYLOAD,
                    'support_keys',
                    IFF(source.SUPPORT_KEY = '', ARRAY_CONSTRUCT(), ARRAY_CONSTRUCT(source.SUPPORT_KEY)),
                    TRUE
                ),
                source.CONFIDENCE,
                1, 0, source.VALIDATION_STATUS,
                'active', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
            )
            """
        return sql

    def read_pattern_history(self, *, history_ids: list[str]) -> list[dict[str, Any]]:
        if not history_ids or len(history_ids) > 50:
            raise ValueError("History reads require 1-50 exact IDs")
        history = self._settings.qualify_table_name("TBL_FIR_PATTERN_HISTORY")
        rows = self._session.sql(f"SELECT HISTORY_ID, PATTERN_ID, CANONICAL_KEY, RECORD_KIND, SUPPORT_KEY, PAYLOAD "
            f"FROM {history} WHERE HISTORY_ID IN ({','.join('?' for _ in history_ids)})", params=history_ids).collect()
        return [row.as_dict() for row in rows if str(row.as_dict().get("HISTORY_ID")) in history_ids]

    def _archive_pattern_rows(self, rows: list[dict[str, Any]]) -> None:
        """Archive observations and authoritative versions before any canonical mutation."""
        history = self._settings.qualify_table_name("TBL_FIR_PATTERN_HISTORY")
        observations = [{"history_id": "observation_" + _stable_hash(row), **row} for row in rows if row.get("payload")]
        if observations:
            self._session.sql(f"""
            MERGE INTO {history} target USING (
                SELECT f.value:history_id::STRING HISTORY_ID, f.value:pattern_id::STRING PATTERN_ID,
                       f.value:reuse_key::STRING CANONICAL_KEY, f.value:support_key::STRING SUPPORT_KEY,
                       f.value:payload PAYLOAD
                FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?))) f
            ) source ON target.HISTORY_ID = source.HISTORY_ID
            WHEN NOT MATCHED THEN INSERT (HISTORY_ID, PATTERN_ID, CANONICAL_KEY, RECORD_KIND, SUPPORT_KEY, PAYLOAD)
                VALUES (source.HISTORY_ID, source.PATTERN_ID, source.CANONICAL_KEY, 'observation', source.SUPPORT_KEY, source.PAYLOAD)
            """, params=[json.dumps(observations, default=str)]).collect()
        self._session.sql(f"""
            MERGE INTO {history} archived USING (
                SELECT DISTINCT 'version_' || SHA2(TO_JSON(OBJECT_CONSTRUCT_KEEP_NULL(
                       'pattern_id', current.PATTERN_ID, 'payload', current.PATTERN_PAYLOAD,
                       'validation', current.VALIDATION_STATUS, 'status', current.STATUS,
                       'superseded_by', current.SUPERSEDED_BY, 'support', current.SUPPORT_COUNT,
                       'contradictions', current.CONTRADICTION_COUNT)), 256) HISTORY_ID,
                       current.PATTERN_ID, current.PATTERN_PAYLOAD:reuse_key::STRING CANONICAL_KEY,
                       OBJECT_CONSTRUCT_KEEP_NULL('payload', current.PATTERN_PAYLOAD,
                           'validation_status', current.VALIDATION_STATUS, 'status', current.STATUS,
                           'superseded_by', current.SUPERSEDED_BY, 'support_count', current.SUPPORT_COUNT,
                           'contradiction_count', current.CONTRADICTION_COUNT) PAYLOAD
                FROM {self._patterns_table} current, TABLE(FLATTEN(INPUT => PARSE_JSON(?))) incoming
                WHERE current.PATTERN_PAYLOAD:reuse_key::STRING = incoming.value:reuse_key::STRING
                   OR current.CONTENT_HASH = incoming.value:content_hash::STRING
                   OR current.PATTERN_ID = incoming.value:pattern_id::STRING
            ) source ON archived.HISTORY_ID = source.HISTORY_ID
            WHEN NOT MATCHED THEN INSERT (HISTORY_ID, PATTERN_ID, CANONICAL_KEY, RECORD_KIND, PAYLOAD)
                VALUES (source.HISTORY_ID, source.PATTERN_ID, source.CANONICAL_KEY, 'version', source.PAYLOAD)
        """, params=[json.dumps(rows, default=str)]).collect()

    def upsert_patterns(
        self, patterns: Iterable[TargetMappingPatternV2], *, _in_transaction: bool = False
    ) -> int:
        # One source row per reuse key keeps the MERGE deterministic.
        by_identity: dict[str, TargetMappingPatternV2] = {}
        history_enabled = getattr(self._settings, "fir_canonical_history_v1", False)
        observations = list(patterns)
        for pattern in observations:
            if history_enabled:
                from app.core.fir_canonical import canonical_key
                pattern = pattern.model_copy(update={"reuse_key": canonical_key(pattern.model_dump(mode="json"))})
            identity = pattern.reuse_key or pattern.content_hash
            current = by_identity.get(identity)
            if current is None or pattern.confidence > current.confidence:
                by_identity[identity] = pattern
        items = list(by_identity.values())
        if history_enabled:
            # One observation at a time retains each independent support key;
            # a replay is still deduplicated by the existing support-key MERGE.
            items = [pattern.model_copy(update={"reuse_key": canonical_key(pattern.model_dump(mode="json"))})
                     for pattern in observations]
        if not items:
            return 0
        # Bounded chunks keep each statement well under the SQL text limit.
        chunk_size = 1 if history_enabled else 25
        for start in range(0, len(items), chunk_size):
            rows = [
                {
                    "pattern_id": pattern.pattern_id,
                    "content_hash": pattern.content_hash,
                    "reuse_key": pattern.reuse_key or "",
                    "scope": pattern.scope,
                    "project_id": pattern.project_id or "",
                    "sttm_id": pattern.sttm_id or "",
                    "target_table": str(pattern.target_contract.get("target_fqn") or pattern.target_contract.get("target_table") or ""),
                    "target_column": str(pattern.target_contract.get("target_column") or ""),
                    "payload": pattern.model_dump(mode="json"),
                    "confidence": float(pattern.confidence),
                    "validation_status": pattern.validation_status,
                    "support_key": self._support_key(pattern),
                }
                for pattern in items[start : start + chunk_size]
            ]
            if history_enabled and not _in_transaction:
                self._session.sql("BEGIN TRANSACTION").collect()
            try:
                if history_enabled:
                    revoked = self._session.sql(f"SELECT PATTERN_ID FROM {self._patterns_table} "
                        "WHERE CONTENT_HASH = ? AND (STATUS <> 'active' OR SUPERSEDED_BY IS NOT NULL) LIMIT 1",
                        params=[rows[0]["content_hash"]]).collect()
                    if revoked:
                        raise ValueError("Revoked historical observation cannot reactivate a pattern")
                    self._archive_pattern_rows(rows)
                self._session.sql(self._merge_patterns_sql(json.dumps(rows, default=str))).collect()
                if history_enabled and not _in_transaction:
                    self._session.sql("COMMIT").collect()
            except Exception:
                if history_enabled and not _in_transaction:
                    self._session.sql("ROLLBACK").collect()
                raise
        count = len(items)
        if count:
            # Same-replica readers must not retain an older target-column
            # pattern set. Cross-replica prepared contexts are versioned by the
            # durable FIR epoch resolved from this table.
            from app.core.learning_retrieval import invalidate_learning_context_cache
            from app.core.prepared_context import (
                invalidate_prepared_workspace_context_cache,
            )

            invalidate_learning_context_cache()
            invalidate_prepared_workspace_context_cache()
        return count

    def record_correction(self, *, original_pattern_id: str, corrected_pattern: dict[str, Any], actor: str,
                          reason: str | None, evidence_ids: list[str]) -> TargetMappingPatternV2:
        history_enabled = getattr(self._settings, "fir_canonical_history_v1", False)
        if history_enabled:
            self._session.sql("BEGIN TRANSACTION").collect()
        try:
            if history_enabled:
                self._archive_pattern_rows([{"pattern_id": original_pattern_id, "payload": {},
                                            "reuse_key": "", "content_hash": "", "support_key": ""}])
            corrected = self._record_correction(original_pattern_id=original_pattern_id, corrected_pattern=corrected_pattern,
                actor=actor, reason=reason, evidence_ids=evidence_ids)
            if history_enabled:
                self._session.sql("COMMIT").collect()
            return corrected
        except Exception:
            if history_enabled:
                self._session.sql("ROLLBACK").collect()
            raise

    def _record_correction(
        self,
        *,
        original_pattern_id: str,
        corrected_pattern: dict[str, Any],
        actor: str,
        reason: str | None,
        evidence_ids: list[str],
    ) -> TargetMappingPatternV2:
        rows = self._session.sql(
            f"""
            SELECT PATTERN_PAYLOAD
            FROM {self._patterns_table}
            WHERE PATTERN_ID = {self._quote(original_pattern_id)}
            LIMIT 1
            """
        ).collect()
        if not rows:
            raise ValueError("Target mapping pattern not found")
        original = rows[0].as_dict().get("PATTERN_PAYLOAD")
        if isinstance(original, str):
            original = json.loads(original)
        if not isinstance(original, dict):
            raise ValueError("Target mapping pattern has invalid payload")
        merged = {**original, **corrected_pattern}
        merged["pattern_id"] = f"tmp_{uuid.uuid4().hex[:24]}"
        merged["validation_status"] = "accepted"
        merged["confidence"] = max(float(merged.get("confidence") or 0.0), 0.99)
        merged["provenance"] = {
            **(
                merged.get("provenance")
                if isinstance(merged.get("provenance"), dict)
                else {}
            ),
            "evidence_class": "explicit_user_correction",
            "corrected_from": original_pattern_id,
            "actor": actor,
            "reason": reason,
        }
        merged["evidence_ids"] = sorted(
            {
                *(
                    str(item)
                    for item in merged.get("evidence_ids") or []
                    if item
                ),
                *(str(item) for item in evidence_ids if item),
                original_pattern_id,
            }
        )
        merged["superseded_by"] = None
        merged["contradiction_count"] = 0
        merged["content_hash"] = _stable_hash(
            {
                "corrected_from": original_pattern_id,
                "target_contract": merged.get("target_contract"),
                "source_system_profile": merged.get("source_system_profile"),
                "mapping_recipe": merged.get("mapping_recipe"),
                "relationship_dependencies": merged.get(
                    "relationship_dependencies"
                ),
                "derived_dependencies": merged.get("derived_dependencies"),
                "query_shaping_dependencies": merged.get(
                    "query_shaping_dependencies"
                ),
            }
        )
        if getattr(self._settings, "fir_canonical_history_v1", False):
            from app.core.fir_canonical import canonical_key
            merged["reuse_key"] = canonical_key(merged)
        else:
            merged["reuse_key"] = reuse_key_for_payload(merged)
        corrected = TargetMappingPatternV2.model_validate(merged)
        self.upsert_patterns([corrected], _in_transaction=getattr(self._settings, "fir_canonical_history_v1", False))
        # A correction that keeps the same reuse key (for example only the rule
        # description changed) merges into the original row; superseding it
        # would deactivate the correction itself.
        self._session.sql(
            f"""
            UPDATE {self._patterns_table}
            SET STATUS = 'inactive',
                VALIDATION_STATUS = 'rejected',
                CONTRADICTION_COUNT = COALESCE(CONTRADICTION_COUNT, 0) + 1,
                SUPERSEDED_BY = COALESCE(
                    (
                        SELECT MAX(PATTERN_ID)
                        FROM {self._patterns_table}
                        WHERE PATTERN_PAYLOAD:reuse_key::STRING = {self._quote(corrected.reuse_key)}
                          AND STATUS = 'active'
                    ),
                    {self._quote(corrected.pattern_id)}
                ),
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE PATTERN_ID = {self._quote(original_pattern_id)}
              AND COALESCE(PATTERN_PAYLOAD:reuse_key::STRING, '') <> {self._quote(corrected.reuse_key)}
            """
        ).collect()
        return corrected

    def supersede_published_patterns(self, *, sttm_id, publication_version_id):
        """Idempotently supersede different recipes for this STTM/target publication."""
        self._session.sql(f"""
            UPDATE {self._patterns_table} old
            SET SUPERSEDED_BY = current.PATTERN_ID, STATUS = 'inactive', UPDATED_AT = CURRENT_TIMESTAMP()
            FROM (
                SELECT PATTERN_ID, STTM_ID, TARGET_COLUMN, PATTERN_PAYLOAD
                FROM {self._patterns_table}
                WHERE TO_VARCHAR(STTM_ID) = ? AND VALIDATION_STATUS = 'published'
                  AND PATTERN_PAYLOAD:provenance:publication_version_id::STRING = ?
                  AND STATUS = 'active' AND SUPERSEDED_BY IS NULL
                QUALIFY ROW_NUMBER() OVER (PARTITION BY STTM_ID, TARGET_COLUMN ORDER BY UPDATED_AT DESC, PATTERN_ID) = 1
            ) current
            WHERE old.STTM_ID = current.STTM_ID AND UPPER(old.TARGET_COLUMN) = UPPER(current.TARGET_COLUMN)
              AND old.PATTERN_ID <> current.PATTERN_ID AND old.SUPERSEDED_BY IS NULL
              AND old.VALIDATION_STATUS = 'published'
              AND TRY_TO_NUMBER(old.PATTERN_PAYLOAD:provenance:publication_version_id::STRING) < TRY_TO_NUMBER(?)
              AND COALESCE(old.PATTERN_PAYLOAD:mapping_recipe::STRING, '') <> COALESCE(current.PATTERN_PAYLOAD:mapping_recipe::STRING, '')
        """, params=[str(sttm_id), str(publication_version_id), str(publication_version_id)]).collect()

    def _persisted_job_patterns(self, patterns: list[TargetMappingPatternV2]) -> list[TargetMappingPatternV2]:
        """Resolve the actual MERGE winners before constructing foreign work IDs."""
        resolved: dict[str, TargetMappingPatternV2] = {}
        normalized = []
        for pattern in patterns:
            if getattr(self._settings, "fir_canonical_history_v1", False):
                from app.core.fir_canonical import canonical_key
                pattern = pattern.model_copy(update={"reuse_key":canonical_key(pattern.model_dump(mode="json"))})
            normalized.append(pattern)
        # At most 50 canonical lookups per statement, instead of one round trip per row.
        for start in range(0,len(normalized),50):
            chunk = normalized[start:start+50]
            queries, params = [], []
            for ordinal, pattern in enumerate(chunk):
                queries.append(f"SELECT {ordinal} ORDINAL, PATTERN_ID FROM {self._patterns_table} WHERE STATUS = 'active' AND SUPERSEDED_BY IS NULL "
                    "AND TARGET_TABLE = ? AND TARGET_COLUMN = ? "
                    "AND (CONTENT_HASH = ? OR (? <> '' AND PATTERN_PAYLOAD:reuse_key::STRING = ?)) "
                    "AND COALESCE(PATTERN_PAYLOAD:target_contract:contract_version::STRING, '') = ? "
                    "AND SCOPE = ? AND (SCOPE NOT IN ('project','mapping') OR COALESCE(PROJECT_ID,'') = ?) "
                    "AND (SCOPE <> 'mapping' OR COALESCE(STTM_ID,'') = ?) QUALIFY ROW_NUMBER() OVER (ORDER BY PATTERN_ID) <= 2")
                params.extend([str(pattern.target_contract.get('target_fqn') or pattern.target_contract.get('target_table') or ''),
                    str(pattern.target_contract.get('target_column') or ''),pattern.content_hash,pattern.reuse_key or '',pattern.reuse_key or '',
                    str(pattern.target_contract.get('contract_version') or ''),pattern.scope,pattern.project_id or '',pattern.sttm_id or ''])
            if not queries:
                continue
            rows = self._session.sql(' UNION ALL '.join(queries),params=params).collect()
            winners = {index:set() for index in range(len(chunk))}
            for row in rows:
                data = row.as_dict() if hasattr(row,'as_dict') else dict(row)
                winners[int(data['ORDINAL'])].add(str(data['PATTERN_ID']))
            for ordinal, pattern in enumerate(chunk):
                identifiers = winners[ordinal]
                if len(identifiers) != 1:
                    raise ValueError("Learning work requires one unambiguous persisted canonical pattern")
                identifier = next(iter(identifiers))
                resolved.setdefault(identifier,pattern.model_copy(update={'pattern_id':identifier}))
        return list(resolved.values())

    def create_learning_job(
        self,
        *,
        asset_id: str,
        project_id: str,
        patterns: list[TargetMappingPatternV2],
        processing_generation: str | None = None,
    ) -> FIRLearningJobResponse:
        patterns = self._persisted_job_patterns(patterns)
        # A re-upload of identical evidence must resume the same durable job,
        # not create another enrichment pass. Pattern content hashes include
        # target identity, source evidence, and extraction semantics.
        extraction_version = "3_canonical_work_ids"
        job_hash = _stable_hash(
            {
                "asset_id": asset_id,
                "project_id": project_id,
                "extraction_version": extraction_version,
                **({'processing_generation': processing_generation} if processing_generation else {}),
                "pattern_content_hashes": sorted(
                    pattern.content_hash for pattern in patterns
                ),
                "canonical_pattern_ids": sorted(pattern.pattern_id for pattern in patterns),
            }
        )
        job_id = f"firjob_{job_hash[:32]}"
        self._session.sql(
            f"""
            MERGE INTO {self._jobs_table} target
            USING (
                SELECT
                    {self._quote(job_id)} AS LEARNING_JOB_ID,
                    {self._quote(asset_id)} AS ASSET_ID,
                    {self._quote(project_id)} AS PROJECT_ID
            ) source
            ON target.LEARNING_JOB_ID = source.LEARNING_JOB_ID
            WHEN NOT MATCHED THEN INSERT (
                LEARNING_JOB_ID, ASSET_ID, PROJECT_ID, STATUS, STAGE,
                DISCOVERED_PATTERN_COUNT, COMPLETED_PATTERN_COUNT,
                FAILED_PATTERN_COUNT, CHECKPOINT, CREATED_AT, UPDATED_AT
            ) VALUES (
                source.LEARNING_JOB_ID, source.ASSET_ID, source.PROJECT_ID,
                'initializing', 'target_row_extraction', {len(patterns)}, 0, 0,
                OBJECT_CONSTRUCT(
                    'extraction_version', {self._quote(extraction_version)},
                    'asset_id', source.ASSET_ID
                ),
                CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
            )
            """
        ).collect()
        items: list[tuple[str, str, dict[str, Any]]] = [
            ("document_parse", asset_id, {"asset_id": asset_id}),
            *[
                (
                    "semantic_enrichment",
                    pattern.pattern_id,
                    {
                        "pattern_id": pattern.pattern_id,
                        "content_hash": pattern.content_hash,
                    },
                )
                for pattern in patterns
            ],
            (
                "agent_semantic_enrichment",
                asset_id,
                {"asset_id": asset_id, "pattern_count": len(patterns)},
            ),
            (
                "pattern_conflict_analysis",
                asset_id,
                {"asset_id": asset_id, "pattern_count": len(patterns)},
            ),
            (
                "recommendation_generation",
                asset_id,
                {"asset_id": asset_id, "pattern_count": len(patterns)},
            ),
            (
                "search_index_promotion",
                asset_id,
                {"asset_id": asset_id, "pattern_count": len(patterns)},
            ),
        ]
        # One bound batch avoids a lock/round trip for every pattern. Keep
        # item IDs stable so an interrupted initialization can be resumed.
        documents = []
        for item_type, identity, payload in items:
            item_hash = _stable_hash({'job': job_id, 'type': item_type,
                'identity': identity, 'version': extraction_version})
            documents.append({'WORK_ITEM_ID': f'firitem_{item_hash[:24]}',
                'LEARNING_JOB_ID': job_id, 'WORK_ITEM_TYPE': item_type,
                'IDEMPOTENCY_KEY': item_hash, 'PAYLOAD': payload,
                'STATUS': 'completed' if item_type == 'document_parse' else 'pending'})
        # Bounded metadata batches; no caller/model text is interpolated into SQL.
        work_started = time.perf_counter()
        for offset in range(0, len(documents), 100):
            self._session.sql(f"""
                MERGE INTO {self._items_table} target USING (
                  SELECT VALUE:WORK_ITEM_ID::VARCHAR AS WORK_ITEM_ID,
                    VALUE:LEARNING_JOB_ID::VARCHAR AS LEARNING_JOB_ID,
                    VALUE:WORK_ITEM_TYPE::VARCHAR AS WORK_ITEM_TYPE,
                    VALUE:IDEMPOTENCY_KEY::VARCHAR AS IDEMPOTENCY_KEY,
                    VALUE:PAYLOAD AS PAYLOAD, VALUE:STATUS::VARCHAR AS STATUS
                  FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))
                ) source ON target.IDEMPOTENCY_KEY = source.IDEMPOTENCY_KEY
                WHEN NOT MATCHED THEN INSERT (WORK_ITEM_ID, LEARNING_JOB_ID,
                  WORK_ITEM_TYPE, IDEMPOTENCY_KEY, PAYLOAD, STATUS, ATTEMPT_COUNT,
                  CREATED_AT, UPDATED_AT) VALUES (source.WORK_ITEM_ID,
                  source.LEARNING_JOB_ID, source.WORK_ITEM_TYPE,
                  source.IDEMPOTENCY_KEY, source.PAYLOAD, source.STATUS, 0,
                  CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())
            """, params=[json.dumps(documents[offset:offset+100])]).collect()
        observe('sql_upload.learning_work_items.duration_ms',(time.perf_counter()-work_started)*1000)
        self._session.sql(
            f"UPDATE {self._jobs_table} SET STATUS = 'running', STAGE = 'semantic_enrichment', "
            "UPDATED_AT = CURRENT_TIMESTAMP() WHERE LEARNING_JOB_ID = ? AND STATUS = 'initializing'",
            params=[job_id],
        ).collect()
        existing = self.get_job(job_id)
        if existing is not None:
            return existing
        return FIRLearningJobResponse(
            learning_job_id=job_id,
            status="running",
            asset_id=asset_id,
            project_id=project_id,
            discovered_pattern_count=len(patterns),
            completed_pattern_count=0,
            stage="semantic_enrichment",
            progress=0.0 if patterns else 1.0,
        )

    def process_learning_job(
        self,
        job_id: str,
        *,
        worker_id: str | None = None,
        max_items: int | None = None,
    ) -> FIRLearningJobResponse:
        """Process a bounded, resumable FIR batch.

        Every work item is leased and idempotent. A replica or task may stop
        after any item; the next invocation resumes pending or expired leases.
        Deterministic target extraction has already been persisted before this
        method runs, so a Cortex timeout cannot lose per-column evidence.
        """
        worker = f"{worker_id or 'fir-worker'}:{uuid.uuid4().hex}"
        limit = max(
            1,
            min(
                int(max_items or self._settings.fir_agent_max_patterns_per_batch),
                int(self._settings.fir_agent_max_patterns_per_batch),
            ),
        )
        started_at = time.monotonic()
        job = self.get_job(job_id)
        if job is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        if not self._settings.fir_pipeline_enabled:
            raise RuntimeError("The FIR pipeline is disabled.")
        if job.status in {"paused", "initializing"}:
            return job
        if job.status in {"completed", "failed"}:
            return job

        rows = self._session.sql(
            f"""
            SELECT WORK_ITEM_ID, WORK_ITEM_TYPE, PAYLOAD, ATTEMPT_COUNT
            FROM {self._items_table}
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
              AND (
                    STATUS = 'pending'
                    OR (
                        STATUS = 'running'
                        AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()
                    )
                  )
            ORDER BY
                CASE WORK_ITEM_TYPE
                    WHEN 'semantic_enrichment' THEN 1
                    WHEN 'pattern_conflict_analysis' THEN 2
                    WHEN 'agent_semantic_enrichment' THEN 3
                    WHEN 'recommendation_generation' THEN 4
                    WHEN 'search_index_promotion' THEN 5
                    ELSE 6
                END,
                CREATED_AT
            LIMIT {limit}
            """
        ).collect()
        for row in rows:
            if time.monotonic() - started_at >= self._settings.fir_job_max_runtime_seconds:
                break
            data = row.as_dict()
            item_id = str(data.get("WORK_ITEM_ID") or "")
            item_type = str(data.get("WORK_ITEM_TYPE") or "")
            payload = data.get("PAYLOAD")
            if isinstance(payload, str):
                payload = json.loads(payload)
            if not isinstance(payload, dict):
                payload = {}
            attempts = int(data.get("ATTEMPT_COUNT") or 0)
            if not self._work_dependencies_complete(
                job_id, item_type, expected_pattern_count=job.discovered_pattern_count
            ):
                continue
            if attempts >= int(self._settings.fir_agent_retry_limit):
                self._session.sql(
                    f"UPDATE {self._items_table} SET STATUS = 'dead_letter', "
                    "LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL, UPDATED_AT = CURRENT_TIMESTAMP(), "
                    "ERROR = OBJECT_CONSTRUCT('category', 'attempts_exhausted') "
                    "WHERE WORK_ITEM_ID = ? AND (STATUS = 'pending' OR "
                    "(STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))",
                    params=[item_id],
                ).collect()
                continue
            claimed = self._session.sql(
                f"""
                UPDATE {self._items_table}
                SET STATUS = 'running',
                    LEASE_OWNER = {self._quote(worker)},
                    LEASE_EXPIRES_AT = DATEADD(
                        second,
                        {int(self._settings.fir_agent_request_timeout_seconds) + 30},
                        CURRENT_TIMESTAMP()
                    ),
                    ATTEMPT_COUNT = ATTEMPT_COUNT + 1,
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHERE WORK_ITEM_ID = {self._quote(item_id)}
                  AND ATTEMPT_COUNT < {int(self._settings.fir_agent_retry_limit)}
                  AND (
                        STATUS = 'pending'
                        OR (
                            STATUS = 'running'
                            AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()
                        )
                      )
                """
            ).collect()
            if not self._work_item_changed(claimed):
                continue
            lease_rows = self._session.sql(
                f"""
                SELECT LEASE_OWNER, STATUS
                FROM {self._items_table}
                WHERE WORK_ITEM_ID = {self._quote(item_id)}
                LIMIT 1
                """
            ).collect()
            if (
                not lease_rows
                or str(lease_rows[0].as_dict().get("LEASE_OWNER") or "") != worker
                or str(lease_rows[0].as_dict().get("STATUS") or "") != "running"
            ):
                continue
            try:
                result = self._process_work_item(item_type, payload)
                completed = self._session.sql(
                    f"""
                    UPDATE {self._items_table}
                    SET STATUS = 'completed',
                        RESULT = PARSE_JSON({self._quote(json.dumps(result, default=str))}),
                        ERROR = NULL,
                        LEASE_OWNER = NULL,
                        LEASE_EXPIRES_AT = NULL,
                        COMPLETED_AT = CURRENT_TIMESTAMP(),
                        UPDATED_AT = CURRENT_TIMESTAMP()
                    WHERE WORK_ITEM_ID = {self._quote(item_id)}
                      AND LEASE_OWNER = {self._quote(worker)}
                      AND STATUS = 'running'
                      AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
                    """
                ).collect()
                if not self._work_item_changed(completed):
                    raise RuntimeError("FIR work-item lease expired or was replaced before completion.")
            except _FIRWorkDeferred as exc:
                self._session.sql(
                    f"""
                    UPDATE {self._items_table}
                    SET STATUS = 'pending',
                        ATTEMPT_COUNT = GREATEST(ATTEMPT_COUNT - 1, 0),
                        ERROR = PARSE_JSON({self._quote(json.dumps({
                            'message': str(exc),
                            'category': 'deferred',
                            'action': 'The work remains queued for the next catch-up.'
                        }))}),
                        LEASE_OWNER = NULL,
                        LEASE_EXPIRES_AT = NULL,
                        UPDATED_AT = CURRENT_TIMESTAMP()
                    WHERE WORK_ITEM_ID = {self._quote(item_id)}
                      AND LEASE_OWNER = {self._quote(worker)}
                      AND STATUS = 'running' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
                    """
                ).collect()
                break
            except Exception as exc:
                retry = self._is_transient_failure(exc) and (
                    (attempts + 1) < int(self._settings.fir_agent_retry_limit)
                )
                error_payload = {
                    "message": str(exc),
                    "category": "transient" if retry else "permanent",
                    "work_item_type": item_type,
                    "attempt_count": attempts + 1,
                    "action": (
                        "The item remains queued for a bounded retry."
                        if retry
                        else "Correct the payload or dependency, then use the admin retry action."
                    ),
                }
                logger.exception(
                    "FIR work item failed: job=%s item=%s type=%s retry=%s",
                    job_id,
                    item_id,
                    item_type,
                    retry,
                )
                self._session.sql(
                    f"""
                    UPDATE {self._items_table}
                    SET STATUS = {self._quote('pending' if retry else 'dead_letter')},
                        ERROR = PARSE_JSON({self._quote(json.dumps(error_payload))}),
                        LEASE_OWNER = NULL,
                        LEASE_EXPIRES_AT = NULL,
                        UPDATED_AT = CURRENT_TIMESTAMP()
                    WHERE WORK_ITEM_ID = {self._quote(item_id)}
                      AND LEASE_OWNER = {self._quote(worker)}
                      AND STATUS = 'running' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
                    """
                ).collect()
        return self._refresh_job(job_id)

    @staticmethod
    def _work_item_changed(rows: list[Any]) -> bool:
        if not rows:
            return False
        result = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
        return any(isinstance(value, (int, float)) and value > 0 for value in result.values())

    def _work_dependencies_complete(
        self, job_id: str, item_type: str, *, expected_pattern_count: int
    ) -> bool:
        stages = (
            "document_parse", "semantic_enrichment", "pattern_conflict_analysis",
            "agent_semantic_enrichment", "recommendation_generation", "search_index_promotion",
        )
        if item_type not in stages:
            raise ValueError(f"Unsupported FIR work stage: {item_type}")
        required = stages[:stages.index(item_type)]
        if not required:
            return True
        rows = self._session.sql(
            f"SELECT WORK_ITEM_TYPE, COUNT(*) AS ITEM_COUNT, "
            "COUNT_IF(COALESCE(STATUS, '') <> 'completed') AS INCOMPLETE_DEPENDENCIES "
            f"FROM {self._items_table} WHERE LEARNING_JOB_ID = ? "
            f"AND WORK_ITEM_TYPE IN ({', '.join('?' for _ in required)}) "
            "GROUP BY WORK_ITEM_TYPE",
            params=[job_id, *required],
        ).collect()
        if not rows:
            raise RuntimeError("FIR dependency status could not be verified.")
        inventory = {row.as_dict()["WORK_ITEM_TYPE"]: row.as_dict() for row in rows}
        for stage in required:
            expected = expected_pattern_count if stage == "semantic_enrichment" else 1
            actual = inventory.get(stage, {})
            if int(actual.get("ITEM_COUNT") or 0) != expected:
                return False
            if int(actual.get("INCOMPLETE_DEPENDENCIES") or 0):
                return False
        return True

    @staticmethod
    def _is_transient_failure(exc: Exception) -> bool:
        if isinstance(exc, (TimeoutError, ConnectionError)):
            return True
        message = str(exc).lower()
        return any(
            marker in message
            for marker in (
                "timeout",
                "temporarily unavailable",
                "connection reset",
                "connection aborted",
                "rate limit",
                "too many requests",
                "warehouse is suspended",
                "lock timeout",
            )
        )

    def _process_work_item(
        self, item_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        if item_type == "semantic_enrichment" and getattr(self._settings, "fir_canonical_history_v1", False):
            self._session.sql("BEGIN TRANSACTION").collect()
            try:
                self._archive_pattern_rows([{"pattern_id": str(payload.get("pattern_id") or ""), "payload": {},
                                            "reuse_key": "", "content_hash": "", "support_key": ""}])
                result = self._process_work_item("canonical_semantic_enrichment", payload)
                self._session.sql("COMMIT").collect()
                return result
            except Exception:
                self._session.sql("ROLLBACK").collect()
                raise
        if item_type in {"semantic_enrichment", "canonical_semantic_enrichment"}:
            pattern_id = str(payload.get("pattern_id") or "")
            rows = self._session.sql(
                f"""
                SELECT PATTERN_PAYLOAD, VALIDATION_STATUS
                FROM {self._patterns_table}
                WHERE PATTERN_ID = {self._quote(pattern_id)}
                LIMIT 1
                """
            ).collect()
            if not rows:
                raise ValueError(f"Target mapping pattern {pattern_id} was not found")
            pattern_payload = rows[0].as_dict().get("PATTERN_PAYLOAD")
            if isinstance(pattern_payload, str):
                pattern_payload = json.loads(pattern_payload)
            if not isinstance(pattern_payload, dict):
                raise ValueError(f"Target mapping pattern {pattern_id} has invalid payload")
            target = pattern_payload.get("target_contract") or {}
            recipe = pattern_payload.get("mapping_recipe") or {}
            source_profile = pattern_payload.get("source_system_profile") or {}
            target_label = str(
                target.get("business_meaning")
                or target.get("semantic_role")
                or target.get("target_column")
                or "the target attribute"
            )
            source_roles = [
                str(item.get("semantic_role") or item.get("physical_name") or "")
                for item in source_profile.get("source_columns") or []
                if isinstance(item, dict)
            ]
            if not pattern_payload.get("business_rationale"):
                pattern_payload["business_rationale"] = (
                    f"Populate {target_label} using "
                    + (
                        ", ".join(role for role in source_roles if role)
                        if source_roles
                        else "the compatible current source role"
                    )
                    + f" with a {recipe.get('mode') or 'direct'} mapping."
                )
            pattern_payload["applicability_conditions"] = sorted(
                {
                    *(
                        pattern_payload.get("applicability_conditions")
                        if isinstance(pattern_payload.get("applicability_conditions"), list)
                        else []
                    ),
                    "All required source roles must exist in the current relation graph.",
                    "Source type and target type must be compatible.",
                    "The mapping must pass compilation and validation before application.",
                }
            )
            current_validation = rows[0].as_dict().get("VALIDATION_STATUS") or pattern_payload.get("validation_status")
            pattern_payload["validation_status"] = (
                "enriched" if current_validation == "extracted" else current_validation
            )
            self._session.sql(
                f"""
                UPDATE {self._patterns_table}
                SET PATTERN_PAYLOAD = PARSE_JSON(
                        {self._quote(json.dumps(pattern_payload, default=str))}
                    ),
                    VALIDATION_STATUS = IFF(
                        VALIDATION_STATUS = 'extracted',
                        'enriched',
                        VALIDATION_STATUS
                    ),
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHERE PATTERN_ID = {self._quote(pattern_id)}
                """
            ).collect()
            return {"pattern_id": pattern_id, "status": "enriched"}

        if item_type == "agent_semantic_enrichment":
            if not self._settings.fir_agent_processing_enabled:
                raise _FIRWorkDeferred("FIR agent processing is disabled.")
            asset_id = str(payload.get("asset_id") or "")
            escalation_rows = self._session.sql(
                f"""
                SELECT COUNT_IF(
                    COALESCE(CONTRADICTION_COUNT, 0) > 0
                    OR LOWER(COALESCE(
                        PATTERN_PAYLOAD:mapping_recipe:mode::STRING, ''
                    )) = 'complex'
                    OR COALESCE(ARRAY_SIZE(
                        PATTERN_PAYLOAD:relationship_dependencies
                    ), 0) > 0
                    OR COALESCE(ARRAY_SIZE(
                        PATTERN_PAYLOAD:derived_dependencies
                    ), 0) > 0
                ) AS ESCALATION_COUNT
                FROM {self._patterns_table}
                WHERE STATUS = 'active'
                  AND PATTERN_PAYLOAD:provenance:asset_id::STRING = {self._quote(asset_id)}
                """
            ).collect()
            if not escalation_rows:
                raise RuntimeError("FIR escalation requirements could not be verified.")
            escalation_count = int(
                escalation_rows[0].as_dict().get("ESCALATION_COUNT") or 0
            )
            if escalation_count == 0:
                return {
                    "asset_id": asset_id,
                    "status": "routine_enrichment_complete",
                    "agent_invoked": False,
                    "reason": "No ambiguous, complex, derived, relational, or contradictory pattern requires escalation.",
                }
            procedure = self._settings.qualify_metadata_object_name(
                "SP_FIR_INVOKE_AGENT"
            )
            response = self._session.call(
                procedure,
                {
                    "task_type": "document_learning",
                    "batch_size": self._settings.fir_agent_max_patterns_per_batch,
                    "daily_request_limit": self._settings.fir_agent_daily_request_limit,
                    "daily_token_limit": self._settings.fir_agent_daily_token_limit,
                    "max_concurrency": self._settings.fir_agent_max_concurrency,
                    "processing_options": {
                        "priority_asset_id": payload.get("asset_id"),
                        "target_row_count": payload.get("pattern_count"),
                        "escalation_pattern_count": escalation_count,
                        "collect_feedback": False,
                        "generate_inferences": True,
                        "create_semantic_versions": True,
                        "generate_recommendations": True,
                        "apply_decay": False,
                        "parse_documents": True,
                    },
                },
            )
            if isinstance(response, str):
                try:
                    response = json.loads(response)
                except json.JSONDecodeError:
                    response = {"status": "unknown", "response": response}
            status = str((response or {}).get("status") or "").lower()
            if status in {
                "budget_exhausted",
                "budget_ledger_unavailable",
                "concurrency_limit",
            }:
                raise _FIRWorkDeferred(
                    f"FIR agent work deferred: {status.replace('_', ' ')}."
                )
            if status != "success" or not response.get("agent_invoked") or response.get("errors"):
                raise RuntimeError(
                    f"FIR agent enrichment failed with status {status or 'unknown'}."
                )
            return {
                "asset_id": payload.get("asset_id"),
                "status": "agent_response_received",
                "persisted_agent_outcomes_verified": False,
                "agent_result": response,
            }

        if item_type == "pattern_conflict_analysis":
            asset_id = str(payload.get("asset_id") or "")
            # Different source recipes for one target are not contradictions.
            # Explicit corrections/supersession own negative evidence. This
            # stage inventories alternatives without invalidating other firms.
            rows = self._session.sql(
                f"""
                SELECT TARGET_TABLE, TARGET_COLUMN, COUNT(*) AS ACTIVE_RECIPE_COUNT
                FROM {self._patterns_table}
                WHERE STATUS = 'active' AND SUPERSEDED_BY IS NULL
                  AND PATTERN_PAYLOAD:provenance:asset_id::STRING = ?
                GROUP BY TARGET_TABLE, TARGET_COLUMN
                """,
                params=[asset_id],
            ).collect()
            return {"asset_id": asset_id, "status": "conflicts_analyzed",
                    "target_groups": len(rows), "policy": "explicit_negative_evidence_only"}

        if item_type == "recommendation_generation":
            return {
                "asset_id": payload.get("asset_id"),
                "status": "postprocessing_complete",
                "recommendation_generation_verified": False,
            }
        if item_type == "search_index_promotion":
            asset_id = str(payload.get("asset_id") or "")
            return {
                "asset_id": asset_id,
                "status": "ready_for_search_refresh",
                "search_visibility_verified": False,
            }
        if item_type == "document_parse":
            return {"asset_id": payload.get("asset_id"), "status": "parsed"}
        raise ValueError(f"Unsupported FIR work item type: {item_type}")

    def _refresh_job(self, job_id: str) -> FIRLearningJobResponse:
        existing = self.get_job(job_id)
        if existing is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        counts = self._session.sql(
            f"""
            SELECT
                COUNT_IF(WORK_ITEM_TYPE = 'semantic_enrichment') AS DISCOVERED,
                COUNT_IF(
                    WORK_ITEM_TYPE = 'semantic_enrichment'
                    AND STATUS = 'completed'
                ) AS COMPLETED,
                COUNT_IF(
                    WORK_ITEM_TYPE = 'semantic_enrichment'
                    AND STATUS = 'dead_letter'
                ) AS FAILED,
                COUNT_IF(COALESCE(STATUS, '') NOT IN ('completed', 'dead_letter')) AS REMAINING,
                COUNT_IF(STATUS = 'dead_letter') AS DEAD_LETTER,
                COUNT(*) AS TOTAL_ITEMS
            FROM {self._items_table}
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
            """
        ).collect()[0].as_dict()
        discovered = existing.discovered_pattern_count
        incomplete_inventory = (
            int(counts.get("DISCOVERED") or 0) != discovered
            or int(counts.get("TOTAL_ITEMS") or 0) != discovered + 5
        )
        completed = int(counts.get("COMPLETED") or 0)
        failed = int(counts.get("FAILED") or 0)
        remaining = int(counts.get("REMAINING") or 0)
        dead_letter = int(counts.get("DEAD_LETTER") or 0)
        status = "failed" if dead_letter or incomplete_inventory else "running" if remaining else "completed"
        stage = "semantic_enrichment" if completed + failed < discovered else (
            "failed" if status == "failed" else "downstream_processing" if remaining else "completed"
        )
        if incomplete_inventory:
            stage = "incomplete_work_inventory"
        checkpoint = {
            "completed_patterns": completed,
            "failed_patterns": failed,
            "remaining_work_items": remaining,
            "incomplete_work_inventory": incomplete_inventory,
        }
        self._session.sql(
            f"""
            UPDATE {self._jobs_table}
            SET STATUS = {self._quote(status)},
                STAGE = {self._quote(stage)},
                COMPLETED_PATTERN_COUNT = {completed},
                FAILED_PATTERN_COUNT = {failed},
                CHECKPOINT = PARSE_JSON({self._quote(json.dumps(checkpoint))}),
                COMPLETED_AT = IFF(
                    {self._quote(status)} IN ('completed', 'failed'),
                    CURRENT_TIMESTAMP(),
                    NULL
                ),
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
            """
        ).collect()
        refreshed = self.get_job(job_id)
        if refreshed is None:
            raise ValueError(f"FIR learning job {job_id} disappeared during refresh")
        return refreshed

    def get_job(self, job_id: str) -> FIRLearningJobResponse | None:
        rows = self._session.sql(
            f"""
            SELECT LEARNING_JOB_ID, ASSET_ID, PROJECT_ID, STATUS, STAGE,
                   DISCOVERED_PATTERN_COUNT, COMPLETED_PATTERN_COUNT,
                   FAILED_PATTERN_COUNT
            FROM {self._jobs_table}
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
            LIMIT 1
            """
        ).collect()
        if not rows:
            return None
        data = rows[0].as_dict()
        discovered = int(data.get("DISCOVERED_PATTERN_COUNT") or 0)
        completed = int(data.get("COMPLETED_PATTERN_COUNT") or 0)
        failed = int(data.get("FAILED_PATTERN_COUNT") or 0)
        progress_rows = self._session.sql(
            f"""
            SELECT WORK_ITEM_TYPE, STATUS, PAYLOAD, ATTEMPT_COUNT
            FROM {self._items_table}
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
            ORDER BY CREATED_AT
            """
        ).collect()
        by_status: dict[str, int] = {}
        by_type: dict[str, dict[str, int]] = {}
        target_progress: list[dict[str, Any]] = []
        for progress_row in progress_rows:
            item = progress_row.as_dict()
            item_type = str(item.get("WORK_ITEM_TYPE") or "unknown")
            item_status = str(item.get("STATUS") or "unknown")
            by_status[item_status] = by_status.get(item_status, 0) + 1
            type_counts = by_type.setdefault(item_type, {})
            type_counts[item_status] = type_counts.get(item_status, 0) + 1
            if item_type != "semantic_enrichment":
                continue
            payload = item.get("PAYLOAD")
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except json.JSONDecodeError:
                    payload = {}
            pattern_id = str((payload or {}).get("pattern_id") or "")
            target_progress.append(
                {
                    "pattern_id": pattern_id,
                    "status": item_status,
                    "attempt_count": int(item.get("ATTEMPT_COUNT") or 0),
                }
            )
        if target_progress:
            pattern_ids = ", ".join(
                self._quote(item["pattern_id"])
                for item in target_progress
                if item["pattern_id"]
            )
            if pattern_ids:
                pattern_rows = self._session.sql(
                    f"""
                    SELECT PATTERN_ID, TARGET_TABLE, TARGET_COLUMN
                    FROM {self._patterns_table}
                    WHERE PATTERN_ID IN ({pattern_ids})
                    """
                ).collect()
                identities = {
                    str(item.as_dict().get("PATTERN_ID") or ""): item.as_dict()
                    for item in pattern_rows
                }
                for item in target_progress:
                    identity = identities.get(item["pattern_id"], {})
                    item["target_table"] = identity.get("TARGET_TABLE")
                    item["target_column"] = identity.get("TARGET_COLUMN")
        return FIRLearningJobResponse(
            learning_job_id=str(data.get("LEARNING_JOB_ID")),
            status=str(data.get("STATUS") or "unknown"),
            asset_id=data.get("ASSET_ID"),
            project_id=data.get("PROJECT_ID"),
            discovered_pattern_count=discovered,
            completed_pattern_count=completed,
            failed_pattern_count=failed,
            stage=data.get("STAGE"),
            progress=(completed + failed) / max(discovered, 1),
            work_items_by_status=by_status,
            work_items_by_type=by_type,
            target_column_progress=target_progress,
        )

    def list_jobs(
        self,
        *,
        asset_id: str | None = None,
        project_id: str | None = None,
        statuses: list[str] | None = None,
        limit: int = 100,
    ) -> list[FIRLearningJobResponse]:
        predicates = ["1=1"]
        if asset_id:
            predicates.append(f"ASSET_ID = {self._quote(asset_id)}")
        if project_id:
            predicates.append(f"PROJECT_ID = {self._quote(project_id)}")
        if statuses:
            values = ", ".join(self._quote(value) for value in statuses)
            predicates.append(f"STATUS IN ({values})")
        rows = self._session.sql(
            f"""
            SELECT LEARNING_JOB_ID
            FROM {self._jobs_table}
            WHERE {' AND '.join(predicates)}
            ORDER BY CREATED_AT DESC
            LIMIT {max(1, min(int(limit), 500))}
            """
        ).collect()
        return [
            job
            for row in rows
            if (
                job := self.get_job(
                    str(row.as_dict().get("LEARNING_JOB_ID") or "")
                )
            )
            is not None
        ]

    def pause_job(self, job_id: str) -> FIRLearningJobResponse:
        if self.get_job(job_id) is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        self._session.sql(
            f"""
            UPDATE {self._jobs_table}
            SET STATUS = 'paused', STAGE = 'paused', UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
              AND STATUS NOT IN ('completed', 'failed')
            """
        ).collect()
        job = self.get_job(job_id)
        if job is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        return job

    def resume_job(self, job_id: str) -> FIRLearningJobResponse:
        job = self.get_job(job_id)
        if job is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        if job.status == "paused":
            self._session.sql(
                f"""
                UPDATE {self._jobs_table}
                SET STATUS = 'running', STAGE = 'semantic_enrichment',
                    COMPLETED_AT = NULL, UPDATED_AT = CURRENT_TIMESTAMP()
                WHERE LEARNING_JOB_ID = {self._quote(job_id)}
                  AND STATUS = 'paused'
                """
            ).collect()
        refreshed = self.get_job(job_id)
        if refreshed is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        return refreshed

    def retry_dead_letters(
        self,
        job_id: str,
        *,
        work_item_id: str | None = None,
    ) -> FIRLearningJobResponse:
        if self.get_job(job_id) is None:
            raise ValueError(f"FIR learning job {job_id} was not found")
        item_predicate = (
            f"AND WORK_ITEM_ID = {self._quote(work_item_id)}"
            if work_item_id
            else ""
        )
        self._session.sql(
            f"""
            UPDATE {self._items_table}
            SET STATUS = 'pending', ATTEMPT_COUNT = 0, ERROR = NULL,
                LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL,
                COMPLETED_AT = NULL, UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
              AND STATUS = 'dead_letter'
              {item_predicate}
            """
        ).collect()
        self._session.sql(
            f"""
            UPDATE {self._jobs_table}
            SET STATUS = 'running', STAGE = 'semantic_enrichment',
                ERROR = NULL, COMPLETED_AT = NULL, UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE LEARNING_JOB_ID = {self._quote(job_id)}
            """
        ).collect()
        return self._refresh_job(job_id)

    def process_queue(
        self,
        *,
        worker_id: str,
        asset_id: str | None = None,
        max_jobs: int = 1,
        max_items_per_job: int | None = None,
    ) -> list[FIRLearningJobResponse]:
        jobs = self.list_jobs(
            asset_id=asset_id,
            statuses=["running"],
            limit=max(1, min(max_jobs, self._settings.fir_agent_max_assets_per_run)),
        )
        return [
            self.process_learning_job(
                job.learning_job_id,
                worker_id=worker_id,
                max_items=max_items_per_job,
            )
            for job in jobs
        ]

    def get_latest_job_for_asset(
        self, asset_id: str
    ) -> FIRLearningJobResponse | None:
        rows = self._session.sql(
            f"""
            SELECT LEARNING_JOB_ID
            FROM {self._jobs_table}
            WHERE ASSET_ID = {self._quote(asset_id)}
            ORDER BY CREATED_AT DESC
            LIMIT 1
            """
        ).collect()
        if not rows:
            return None
        return self.get_job(
            str(rows[0].as_dict().get("LEARNING_JOB_ID") or "")
        )

    def retrieve_candidates(
        self,
        *,
        target_table: str,
        target_columns: list[str],
        source_tables: list[str],
        source_columns: list[str] | None = None,
        source_column_profiles: list[dict[str, Any]] | None = None,
        crm_family: str | None = None,
        relationship_paths: list[str] | None = None,
        derived_outputs: list[str] | None = None,
        workspace_context_id: str | None = None,
        project_id: str | None = None,
        linked_project_ids: list[str] | None = None,
        logical_target_key: str | None = None,
        limit: int = 100,
        per_column_limit: int = 4,
        additional_pattern_ids: list[str] | None = None,
        discovered_only: bool = False,
        eligible_pattern_ids: list[str] | None = None,
        hard_positive_limit: bool = False,
        allow_incomplete_metadata: bool = False,
        diagnostics: dict[str, Any] | None = None,
    ) -> list[TargetMappingPatternCandidate]:
        def excluded(pattern_id, target_column, stage, reason, **details):
            if diagnostics is not None:
                diagnostics.setdefault("exclusions", []).append({
                    "pattern_id": pattern_id, "target_column": target_column,
                    "stage": stage, "reason": reason, **details,
                })

        # Bound query width, not total target coverage. Each page gets its own
        # per-target quota; required corrections bypass that quota below.
        normalized_columns = list(dict.fromkeys(str(column) for column in target_columns))
        if len(normalized_columns) > 50:
            candidates: dict[str, TargetMappingPatternCandidate] = {}
            for start in range(0, len(normalized_columns), 50):
                page = normalized_columns[start:start + 50]
                for candidate in self.retrieve_candidates(
                    target_table=target_table, target_columns=page, source_tables=source_tables,
                    source_columns=source_columns, source_column_profiles=source_column_profiles,
                    crm_family=crm_family, relationship_paths=relationship_paths, derived_outputs=derived_outputs,
                    workspace_context_id=workspace_context_id, project_id=project_id,
                    linked_project_ids=linked_project_ids, logical_target_key=logical_target_key,
                    limit=max(len(page) * per_column_limit, 20), per_column_limit=per_column_limit,
                    additional_pattern_ids=additional_pattern_ids,
                    discovered_only=discovered_only,
                    eligible_pattern_ids=eligible_pattern_ids,
                    hard_positive_limit=hard_positive_limit,
                    allow_incomplete_metadata=allow_incomplete_metadata,
                    diagnostics=diagnostics,
                ):
                    candidates.setdefault(candidate.pattern.pattern_id, candidate)
            return list(candidates.values())
        logical_target_key = optional_identifier(logical_target_key)
        target_leaf = str(target_table).split(".")[-1]
        target_predicates = [
            f"UPPER(TARGET_TABLE) = UPPER({self._quote(target_table)})",
            f"UPPER(SPLIT_PART(TARGET_TABLE, '.', -1)) = UPPER({self._quote(target_leaf)})",
        ]
        if logical_target_key:
            target_predicates.append(
                "UPPER(PATTERN_PAYLOAD:target_contract:logical_target_key::STRING) = "
                f"UPPER({self._quote(logical_target_key)})"
            )
        predicates = [f"({' OR '.join(target_predicates)})", "STATUS = 'active'",
                      "COALESCE(VALIDATION_STATUS, '') <> 'rejected'", "SUPERSEDED_BY IS NULL"]
        query_params = None
        if discovered_only:
            identifiers = sorted(set(additional_pattern_ids or []))
            if not identifiers:
                return []
            predicates.append(f"PATTERN_ID IN ({','.join('?' for _ in identifiers)})")
            query_params = identifiers
        if eligible_pattern_ids is not None:
            if not eligible_pattern_ids:
                return []
            identifiers = sorted(set(eligible_pattern_ids))
            predicates.append(f"PATTERN_ID IN ({','.join('?' for _ in identifiers)})")
            query_params = [*(query_params or []), *identifiers]
        if self._settings.automap_hybrid_context_v1 is True:
            predicates.extend([
                "VALIDATION_STATUS IN ('accepted', 'validated', 'published')",
                "COALESCE(CONTRADICTION_COUNT, 0) = 0",
                "COALESCE(PATTERN_PAYLOAD:provenance:evidence_class::STRING, '') NOT IN ('unvalidated_authored_sql', 'unvalidated_authored_mapping_workbook')",
            ])
        if target_columns:
            values = ", ".join(
                self._quote(str(item).upper()) for item in target_columns
            )
            predicates.append(f"UPPER(TARGET_COLUMN) IN ({values})")
        linked = [str(value) for value in linked_project_ids or [] if value and str(value) != str(project_id)]
        if project_id:
            # Reusable client recipes cross projects; project overrides do not.
            predicates.append(f"(SCOPE <> 'project' OR PROJECT_ID = {self._quote(project_id)})")
        else:
            predicates.append("SCOPE <> 'project'")
        predicates.append(
            f"(SCOPE <> 'mapping' OR STTM_ID = {self._quote(workspace_context_id)})"
            if workspace_context_id else "SCOPE <> 'mapping'"
        )
        # Other mappings' published patterns are the evidence a new mapping
        # needs most, so the current mapping is ranked first, never filtered to.
        scope_rank = "3"
        if workspace_context_id or project_id:
            scope_cases = []
            if workspace_context_id:
                scope_cases.append(f"WHEN STTM_ID = {self._quote(workspace_context_id)} THEN 0")
            if project_id:
                scope_cases.append(f"WHEN PROJECT_ID = {self._quote(project_id)} THEN 1")
            if linked:
                scope_cases.append(
                    f"WHEN PROJECT_ID IN ({', '.join(self._quote(value) for value in linked)}) THEN 2"
                )
            scope_rank = f"CASE {' '.join(scope_cases)} ELSE 3 END"
        evidence_tier = """
                CASE
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING
                         = 'explicit_user_correction' THEN 1
                    WHEN VALIDATION_STATUS = 'published'
                      OR PATTERN_PAYLOAD:provenance:evidence_class::STRING
                         = 'published_mapping' THEN 2
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING IN (
                            'validated_mapping',
                            'validated_imported_sql',
                            'validated_imported_workbook',
                            'historical_import'
                         ) THEN 3
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING
                         = 'accepted_mapping_row'
                      OR VALIDATION_STATUS = 'accepted' THEN 4
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING IN (
                            'unvalidated_authored_sql',
                            'unvalidated_authored_mapping_workbook'
                         ) THEN 5
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING
                         = 'fir_inference' THEN 6
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING
                         = 'semantic_role_match' THEN 7
                    WHEN PATTERN_PAYLOAD:provenance:evidence_class::STRING
                         = 'name_similarity' THEN 8
                    ELSE 9
                END"""
        rank_order = "EVIDENCE_TIER, SCOPE_RANK, CONFIDENCE DESC, SUPPORT_COUNT DESC, PATTERN_PAYLOAD:pattern_id::STRING"
        rows = self._session.sql(
            f"""
            SELECT PATTERN_PAYLOAD, SUPPORT_COUNT, CONTRADICTION_COUNT,
                   VALIDATION_STATUS, CONFIDENCE, PATTERN_ID, TARGET_COLUMN
            FROM (
                SELECT PATTERN_PAYLOAD, SUPPORT_COUNT, CONTRADICTION_COUNT,
                       VALIDATION_STATUS, CONFIDENCE, TARGET_COLUMN, PATTERN_ID,
                       {evidence_tier} AS EVIDENCE_TIER,
                       {scope_rank} AS SCOPE_RANK
                FROM {self._patterns_table}
                WHERE {' AND '.join(predicates)}
            )
            ORDER BY {rank_order}
            """, **({"params": query_params} if query_params is not None else {})
        ).collect()
        current_sources = {item.upper() for item in source_tables}
        current_vendor = (
            str(crm_family or "").strip().upper()
            or _vendor_family_from_sources(source_tables)
        )
        current_columns = [str(item) for item in source_columns or [] if item]
        current_column_shapes = {_source_shape(item) for item in current_columns}
        current_column_names = {str(item).upper() for item in current_columns}
        columns_by_role: dict[str, list[str]] = {}
        profiles_by_name = {
            str(profile.get("physical_name") or "").upper(): profile
            for profile in source_column_profiles or [] if isinstance(profile, dict)
        }
        for column in current_columns:
            profile = profiles_by_name.get(column.upper(), {})
            role = str(profile.get("semantic_role") or _semantic_role(column)).upper()
            columns_by_role.setdefault(role, []).append(column)
        current_relationships = {
            relationship_signature(item) for item in relationship_paths or [] if item
        }
        current_derived = {
            str(item).strip().upper() for item in derived_outputs or [] if item
        }
        result: list[TargetMappingPatternCandidate] = []
        seen_reuse_keys: set[str] = set()
        fetched_ids = set()
        for row in rows:
            data = row.as_dict()
            identifier = str(data.get("PATTERN_ID") or "")
            if identifier:
                fetched_ids.add(identifier)
            payload = data.get("PATTERN_PAYLOAD")
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except ValueError:
                    excluded(identifier, data.get("TARGET_COLUMN"), "schema", "invalid_json")
                    continue
            if not isinstance(payload, dict):
                excluded(identifier, data.get("TARGET_COLUMN"), "schema", "non_object_payload")
                continue
            identifier = identifier or str(payload.get("pattern_id") or "")
            target_contract = payload.get("target_contract")
            target_column = target_contract.get("target_column") if isinstance(target_contract, dict) else data.get("TARGET_COLUMN")
            # Rows arrive best-first, so a repeated reuse key is a weaker duplicate.
            if hard_positive_limit:
                from app.core.fir_canonical import canonical_key
                reuse_key = canonical_key(payload)
            else:
                reuse_key = reuse_key_for_payload(payload)
            if reuse_key:
                if reuse_key in seen_reuse_keys:
                    excluded(identifier, target_column, "deduplication", "duplicate_recipe")
                    continue
            payload["support_count"] = int(data.get("SUPPORT_COUNT") or 1)
            payload["contradiction_count"] = int(
                data.get("CONTRADICTION_COUNT") or 0
            )
            payload["validation_status"] = str(
                data.get("VALIDATION_STATUS") or payload.get("validation_status")
            )
            payload["confidence"] = float(
                data.get("CONFIDENCE") or payload.get("confidence") or 0.5
            )
            try:
                pattern = TargetMappingPatternV2.model_validate(payload)
            except ValidationError as exc:
                # One malformed row must not hide every pattern for the target.
                increment("fir_patterns.retrieve.invalid_row")
                logger.warning("Skipping invalid target mapping pattern %s", payload.get("pattern_id"))
                excluded(identifier, target_column, "schema", "invalid_pattern_contract",
                         fields=[{"path": ".".join(map(str, error["loc"])), "type": error["type"]}
                                 for error in exc.errors(include_input=False, include_url=False)])
                continue
            seen_reuse_keys.add(reuse_key)
            historical_sources = {
                str(item).upper()
                for item in pattern.source_system_profile.get("source_tables") or []
            }
            exact = bool(historical_sources and historical_sources <= current_sources)
            historical_vendor = str(
                pattern.source_system_profile.get("vendor_family") or ""
            ).strip().upper() or _vendor_family_from_sources(historical_sources)
            same_vendor = bool(
                current_vendor
                and historical_vendor
                and current_vendor == historical_vendor
            )
            dependency_columns = [
                str(value)
                for value in pattern.mapping_recipe.get("source_dependencies") or []
                if value
            ]
            # The columns a mapping actually reads decide exactness; requiring
            # the whole historical source set rejected mappings whose workspace
            # simply had a different set of other tables selected.
            if dependency_columns and not exact:
                exact = all(
                    str(dependency).upper() in current_column_names
                    or _source_shape(dependency) in current_column_shapes
                    for dependency in dependency_columns
                )
            adapted_columns: list[str] = []
            missing_roles: list[str] = []
            type_checks: list[bool | None] = []
            grain_checks: list[bool | None] = []
            historical_profiles = {
                _semantic_role(str(item.get("physical_name") or "")): item
                for item in pattern.source_system_profile.get("source_columns") or []
                if isinstance(item, dict)
            }
            for dependency in dependency_columns:
                historical_profile = historical_profiles.get(_semantic_role(dependency), {})
                role = str(historical_profile.get("semantic_role") or _semantic_role(dependency)).upper()
                matches = [column for column in current_columns if column.upper() == dependency.upper()]
                if not matches and same_vendor:
                    matches = [column for column in current_columns if _source_shape(column) == _source_shape(dependency)]
                matches = matches or columns_by_role.get(role, [])
                if len(matches) == 1:
                    adapted_columns.append(matches[0])
                    current_profile = profiles_by_name.get(matches[0].upper(), {})
                    current_type = current_profile.get("type")
                    expected_type = (
                        historical_profile.get("type")
                        or pattern.target_contract.get("type")
                    )
                    # Unknown is retained as unknown rather than all([]) == True.
                    type_checks.append(
                        _type_family(current_type) == _type_family(expected_type)
                        if current_type and expected_type else None
                    )
                    current_grain = current_profile.get("grain")
                    expected_grain = (
                        historical_profile.get("grain")
                        or pattern.target_contract.get("grain")
                    )
                    grain_checks.append(
                        str(current_grain).strip().upper() == str(expected_grain).strip().upper()
                        if current_grain and expected_grain else None
                    )
                else:
                    missing_roles.append(role)
            required_relationships = {
                relationship_signature(item)
                for item in pattern.relationship_dependencies
                if isinstance(item, dict)
            } - {""}
            required_derived = {
                str(
                    item.get("name")
                    or item.get("output")
                    or item.get("alias")
                    or ""
                ).strip().upper()
                for item in pattern.derived_dependencies
                if isinstance(item, dict)
            } - {""}
            relationship_ok = (
                required_relationships <= current_relationships
                if required_relationships
                else True
            )
            derived_ok = (
                required_derived <= current_derived if required_derived else True
            )
            roles_ok = not missing_roles if dependency_columns else False
            # One known mismatch is false; every comparison must be known for true.
            types_ok = False if False in type_checks else (True if type_checks and None not in type_checks else None)
            grain_ok = False if False in grain_checks else (True if grain_checks and None not in grain_checks else None)
            metadata_ok = (types_ok is not False and grain_ok is not False) if allow_incomplete_metadata else bool(types_ok and grain_ok)
            neutral_value = not dependency_columns and pattern.mapping_recipe.get('expression') == 'NULL'
            if neutral_value and allow_incomplete_metadata:
                tier, score, decision = 1, 0.8, 'adapt_pattern'
                reasons = ['Published intentional SQL NULL; review its applicability to the current target.']
            elif exact:
                tier, score = 1, 1.0
                decision = (
                    "accept_exact_precedent"
                    if metadata_ok and relationship_ok and derived_ok
                    else "unresolved"
                )
                reasons = ["The historical physical source set is available."]
            elif same_vendor:
                tier, score = 2, 0.86
                decision = (
                    "adapt_pattern"
                    if roles_ok and metadata_ok and relationship_ok and derived_ok
                    else "unresolved"
                )
                reasons = ["The source-system family matches; physical names require validation."]
            elif roles_ok and metadata_ok and relationship_ok and derived_ok:
                tier, score, decision = 3, 0.72, "adapt_pattern"
                reasons = [
                    "Historical physical names were replaced with compatible current semantic roles.",
                    "Required relationships and derived outputs are available.",
                ]
            else:
                tier, score, decision = 4, 0.4, "unresolved"
                reasons = ["The business rule is known but no compatible current source is resolved."]
            missing = []
            missing.extend(
                f"semantic_role:{role}" for role in missing_roles
            )
            missing.extend(
                f"relationship:{value}"
                for value in sorted(required_relationships - current_relationships)
            )
            missing.extend(
                f"derived_output:{value}"
                for value in sorted(required_derived - current_derived)
            )
            if not types_ok:
                missing.append("compatible_source_types")
            if not grain_ok:
                missing.append("compatible_source_grain")
            if allow_incomplete_metadata and (types_ok is None or grain_ok is None):
                reasons.append('Historical type/grain metadata is incomplete; retain this draft for review.')
            prepare_action = None
            if decision == "unresolved":
                excluded(identifier, target_column, "applicability", "unresolved_dependencies",
                         missing_dependencies=sorted(set(missing)))
                prepare_action = {
                    "action_kind": "open_source_preparation",
                    "missing_semantic_roles": missing_roles,
                    "candidate_source_tables": sorted(current_sources),
                    "required_relationships": sorted(required_relationships),
                    "required_derived_outputs": sorted(required_derived),
                    "historical_rationale": pattern.business_rationale,
                }
            result.append(
                TargetMappingPatternCandidate(
                    pattern=pattern,
                    compatibility_tier=tier,
                    compatibility_score=score,
                    decision=decision,
                    compatibility_reasons=reasons,
                    missing_dependencies=sorted(set(missing)),
                    adapted_source_columns=adapted_columns if tier in {2, 3} else [],
                    compatibility_checks={
                        "columns_exist": roles_ok if dependency_columns else None,
                        "types_compatible": types_ok,
                        "grain_compatible": grain_ok,
                        "relationship_path_compatible": relationship_ok,
                        "derived_outputs_available": derived_ok,
                    },
                    prepare_source_action=prepare_action,
                )
            )
        if discovered_only:
            for identifier in sorted(set(additional_pattern_ids or []) - fetched_ids):
                excluded(identifier, None, "canonical_read", "not_returned_by_canonical_filters")
        def scope_priority(item):
            pattern = item.pattern
            return (0 if pattern.project_id == project_id else
                    1 if str(pattern.project_id) in {str(value) for value in linked} else
                    2 if current_vendor and str(pattern.source_system_profile.get("vendor_family") or "").upper() == current_vendor else 3)
        def publication_recency(item):
            from datetime import datetime, timezone
            value = item.pattern.provenance.get("published_at") or item.pattern.provenance.get("validated_at")
            try:
                return -datetime.fromisoformat(str(value).replace("Z", "+00:00")).replace(tzinfo=timezone.utc).timestamp()
            except (ValueError, TypeError):
                return 0
        result.sort(key=lambda item: (
            item.decision == "unresolved",
            item.pattern.provenance.get("evidence_class") != "explicit_user_correction",
            item.pattern.validation_status != "published",
            scope_priority(item), item.compatibility_tier, publication_recency(item),
            -item.pattern.support_count, -item.pattern.confidence, item.pattern.pattern_id,
        ))
        counts: dict[str, int] = {}
        selected = []
        for candidate in result:
            column = str(candidate.pattern.target_contract.get("target_column") or "").upper()
            mandatory = (candidate.pattern.project_id == project_id and
                         candidate.pattern.provenance.get("evidence_class") == "explicit_user_correction")
            discovered = not hard_positive_limit and candidate.pattern.pattern_id in (additional_pattern_ids or [])
            if counts.get(column, 0) >= per_column_limit and not mandatory and not discovered:
                excluded(candidate.pattern.pattern_id, column, "quota", "per_target_limit")
                continue
            counts[column] = counts.get(column, 0) + 1
            selected.append(candidate)
        return selected[:limit] + [item for item in selected[limit:] if (not hard_positive_limit and item.pattern.pattern_id in (additional_pattern_ids or [])) or (
            item.pattern.project_id == project_id and item.pattern.provenance.get("evidence_class") == "explicit_user_correction"
        )]

    def retrieve_knowledge_graph(
        self,
        *,
        target_table: str,
        target_columns: list[str],
        project_id: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        candidates = self.retrieve_candidates(
            target_table=target_table,
            target_columns=target_columns,
            source_tables=[],
            project_id=project_id,
            limit=limit,
        )
        nodes: dict[str, dict[str, Any]] = {}
        edges: dict[str, dict[str, Any]] = {}

        def add_node(node_id: str, kind: str, attributes: dict[str, Any]) -> None:
            if node_id:
                nodes.setdefault(
                    node_id,
                    {"id": node_id, "kind": kind, "attributes": attributes},
                )

        def add_edge(
            source: str,
            relation: str,
            target: str,
            attributes: dict[str, Any] | None = None,
        ) -> None:
            if not source or not target:
                return
            identity = _stable_hash([source, relation, target, attributes or {}])
            edges.setdefault(
                identity,
                {
                    "id": identity,
                    "source": source,
                    "relation": relation,
                    "target": target,
                    "attributes": attributes or {},
                },
            )

        for candidate in candidates:
            pattern = candidate.pattern
            target = pattern.target_contract
            target_table_id = f"target_table:{target.get('target_fqn') or target_table}"
            target_column_id = (
                f"target_column:{target.get('target_fqn') or target_table}."
                f"{target.get('target_column') or ''}"
            )
            add_node(target_table_id, "target_table", {"fqn": target.get("target_fqn")})
            add_node(target_column_id, "target_column", target)
            add_edge(target_table_id, "contains", target_column_id)
            pattern_id = f"mapping_pattern:{pattern.pattern_id}"
            add_node(
                pattern_id,
                "mapping_pattern",
                {
                    "recipe": pattern.mapping_recipe,
                    "confidence": pattern.confidence,
                    "validation_status": pattern.validation_status,
                    "provenance": pattern.provenance,
                },
            )
            add_edge(
                pattern_id,
                "maps_to",
                target_column_id,
                {"compatibility_tier": candidate.compatibility_tier},
            )
            for source_table in pattern.source_system_profile.get("source_tables") or []:
                source_table_id = f"source_table:{source_table}"
                add_node(source_table_id, "source_table", {"fqn": source_table})
                for source_column in pattern.source_system_profile.get("source_columns") or []:
                    if not isinstance(source_column, dict):
                        continue
                    physical = str(source_column.get("physical_name") or "")
                    source_column_id = f"source_column:{physical}"
                    add_node(source_column_id, "source_column", source_column)
                    add_edge(source_table_id, "contains", source_column_id)
                    add_edge(source_column_id, "maps_to", target_column_id)
            for relationship in pattern.relationship_dependencies:
                relationship_id = f"relationship:{_stable_hash(relationship)}"
                add_node(relationship_id, "relationship", relationship)
                add_edge(pattern_id, "validated_by", relationship_id)
                left = str(
                    relationship.get("left_table")
                    or relationship.get("source_table")
                    or ""
                )
                right = str(
                    relationship.get("right_table")
                    or relationship.get("target_table")
                    or ""
                )
                if left and right:
                    left_id = f"source_table:{left}"
                    right_id = f"source_table:{right}"
                    add_node(left_id, "source_table", {"fqn": left})
                    add_node(right_id, "source_table", {"fqn": right})
                    add_edge(left_id, "joins_to", right_id, relationship)
            for derived in pattern.derived_dependencies:
                derived_id = f"derived_source:{_stable_hash(derived)}"
                add_node(derived_id, "derived_source", derived)
                add_edge(pattern_id, "derives_from", derived_id)
            if pattern.mapping_recipe.get("expression"):
                transformation_id = (
                    "transformation:"
                    f"{pattern.mapping_recipe.get('expression_fingerprint') or _stable_hash(pattern.mapping_recipe.get('expression'))}"
                )
                add_node(
                    transformation_id,
                    "transformation",
                    {
                        "expression": pattern.mapping_recipe.get("expression"),
                        "fingerprint": pattern.mapping_recipe.get(
                            "expression_fingerprint"
                        ),
                    },
                )
                add_edge(pattern_id, "transformed_by", transformation_id)
            if pattern.mapping_recipe.get("placeholder"):
                binding_id = (
                    f"value_binding:{pattern.mapping_recipe.get('placeholder')}"
                )
                add_node(
                    binding_id,
                    "value_binding",
                    {
                        "placeholder": pattern.mapping_recipe.get("placeholder"),
                        "scope": pattern.scope,
                    },
                )
                add_edge(binding_id, "maps_to", target_column_id)
            corrected_from = str(
                pattern.provenance.get("corrected_from") or ""
            )
            if corrected_from:
                original_id = f"mapping_pattern:{corrected_from}"
                add_node(original_id, "mapping_pattern", {})
                add_edge(original_id, "corrected_by", pattern_id)
            validation_id = (
                f"validation:{pattern.pattern_id}:{pattern.validation_status}"
            )
            add_node(
                validation_id,
                "validation",
                {
                    "status": pattern.validation_status,
                    "confidence": pattern.confidence,
                    "support_count": pattern.support_count,
                    "contradiction_count": pattern.contradiction_count,
                },
            )
            add_edge(pattern_id, "validated_by", validation_id)
            for evidence_id in pattern.evidence_ids:
                evidence_node = f"evidence:{evidence_id}"
                add_node(
                    evidence_node,
                    "evidence",
                    {"id": evidence_id, "provenance": pattern.provenance},
                )
                add_edge(evidence_node, "maps_to", pattern_id)
            for query_rule in pattern.query_shaping_dependencies:
                kind = str(query_rule.get("kind") or query_rule.get("type") or "query_shape")
                relation = {
                    "filter": "filtered_by",
                    "grouping": "grouped_by",
                    "group_by": "grouped_by",
                }.get(kind.lower(), "transformed_by")
                rule_id = f"query_rule:{_stable_hash(query_rule)}"
                add_node(rule_id, kind, query_rule)
                add_edge(pattern_id, relation, rule_id)
        return {
            "nodes": list(nodes.values()),
            "edges": list(edges.values()),
            "candidate_count": len(candidates),
        }
