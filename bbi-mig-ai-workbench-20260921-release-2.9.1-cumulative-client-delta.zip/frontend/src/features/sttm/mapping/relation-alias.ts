function aliasStem(value: string): string {
  const normalized = String(value ?? '')
    .trim()
    .replace(/[^A-Za-z0-9_]/g, '_')
    .replace(/^_+|_+$/g, '')
    .toLowerCase();
  const safe = normalized && /^[A-Za-z_]/.test(normalized)
    ? normalized
    : `source_${normalized || 'relation'}`;
  return safe.slice(0, 48);
}

function identityDigest(value: string): string {
  // FNV-1a is deterministic in every browser/runtime and needs no async crypto
  // API. Base-36 keeps the Snowflake alias compact while retaining identity.
  let hash = 0x811c9dc5;
  for (const character of String(value ?? '').trim().toUpperCase()) {
    hash ^= character.codePointAt(0) ?? 0;
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(36).padStart(6, '0').slice(-6);
}

/** A stable SQL alias derived from relation identity, never array position. */
export function relationAliasFor(identity: string, displaySeed?: string | null): string {
  const seed = String(displaySeed ?? '').trim()
    || String(identity ?? '').trim().split('.').pop()
    || 'relation';
  return `${aliasStem(seed)}_${identityDigest(identity)}`;
}

/**
 * Map superseded aliases onto the aliases the generator produces today.
 *
 * Mappings saved while aliases were positional persisted qualifiers such as
 * `servicing_advisors_15`. Physical-table aliases are regenerated from identity
 * on every load, so those stored qualifiers now resolve to nothing. Derived
 * sources restore their persisted alias verbatim and therefore never drift.
 *
 * The persisted relation graph is the authoritative record of which alias a
 * stored reference was written against, so pair each persisted node alias with
 * the alias its identity yields now. Entries are only emitted where the two
 * actually differ.
 */
export function buildLegacyAliasRewrites(
  nodes: Array<{ alias?: unknown; identity?: unknown; displaySeed?: unknown }>,
): Map<string, string> {
  const rewrites = new Map<string, string>();
  const ambiguous = new Set<string>();
  for (const node of nodes) {
    const storedAlias = String(node.alias ?? '').trim();
    const identity = String(node.identity ?? '').trim();
    if (!storedAlias || !identity) continue;
    const displaySeed = String(node.displaySeed ?? '').trim() || null;
    const currentAlias = relationAliasFor(identity, displaySeed);
    if (currentAlias === storedAlias) continue;
    const key = storedAlias.toUpperCase();
    const existing = rewrites.get(key);
    if (existing && existing !== currentAlias) {
      ambiguous.add(key);
      continue;
    }
    rewrites.set(key, currentAlias);
  }
  for (const key of ambiguous) rewrites.delete(key);
  return rewrites;
}

/** Rewrite a single legacy `<alias>.COLUMN` qualifier when unambiguous. */
export function rewriteLegacyAliasReference(
  value: string,
  rewrites: Map<string, string>,
): string {
  if (!rewrites.size) return value;
  const text = String(value ?? '');
  if (!text.trim()) return text;
  return text.replace(
    /(?<![A-Za-z0-9_$.])([A-Za-z_][A-Za-z0-9_$]*)(?=\s*\.\s*[A-Za-z_])/g,
    (match, qualifier: string) => rewrites.get(qualifier.toUpperCase()) ?? match,
  );
}
