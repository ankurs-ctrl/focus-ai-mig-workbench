"""Supervisor token accounting, the context meter event and compaction detection."""
from __future__ import annotations

from types import SimpleNamespace

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from app.agent_runtime.execution import BudgetExceededError, ExecutionBudget, SharedBudgetMiddleware
from app.agent_runtime.model_adapter import context_window_for


def _middleware(window: int = 200_000, **budget):
    events: list[tuple[str, dict]] = []
    budget = ExecutionBudget(model_limit=10, tool_limit=10, **budget)
    middleware = SharedBudgetMiddleware(budget, trace=lambda kind, _s, _m, data: events.append((kind, data)),
                                        context_window=window)
    return middleware, budget, events


def _request(state=None):
    return SimpleNamespace(
        system_message=SystemMessage(content="You are the supervisor. " * 50),
        tools=[],
        messages=[HumanMessage(content="Map HOUSEHOLD"), ToolMessage(content="x" * 4000, tool_call_id="t1")],
        state=state or {},
    )


def _response(input_tokens=12_000, output_tokens=300, cache_read=4_000):
    return SimpleNamespace(result=[AIMessage(content="ok", usage_metadata={
        "input_tokens": input_tokens, "output_tokens": output_tokens, "total_tokens": input_tokens + output_tokens,
        "input_token_details": {"cache_read": cache_read}})])


def test_usage_is_recorded_and_split_into_categories_that_sum_to_the_provider_total() -> None:
    middleware, budget, events = _middleware()
    response = middleware.wrap_model_call(_request(), lambda _request: _response())
    assert response.result[0].content == "ok"
    usage = next(data for kind, data in events if kind == "context.usage")
    assert usage["used_tokens"] == 12_000 and usage["window_tokens"] == 200_000
    assert usage["free_tokens"] == 188_000 and usage["compaction_at_tokens"] == 170_000
    assert abs(sum(usage["categories"].values()) - 12_000) <= 4
    assert usage["categories"]["tool_results"] > usage["categories"]["messages"]
    completed = next(data for kind, data in events if kind == "model.completed")
    assert completed["metrics"]["input_tokens"] == 12_000 and completed["metrics"]["cached_tokens"] == 4_000
    snapshot = budget.structured_snapshot()
    assert snapshot["category_input_tokens"] == 12_000 and snapshot["category_output_tokens"] == 300


def test_compaction_is_reported_once_per_summary_boundary() -> None:
    middleware, _budget, events = _middleware()
    state = {"_summarization_event": {"cutoff_index": 14, "file_path": "/conversation_history/t.md"}}
    middleware.wrap_model_call(_request(state), lambda _request: _response())
    middleware.wrap_model_call(_request(state), lambda _request: _response())
    compactions = [data for kind, data in events if kind == "context.compacted"]
    assert len(compactions) == 1 and compactions[0]["cutoff_index"] == 14
    assert [data for kind, data in events if kind == "context.usage"][-1]["summarized"] is True


def test_token_budget_stops_the_next_working_model_call_and_survives_resume() -> None:
    budget = ExecutionBudget(model_limit=10, tool_limit=10, token_limit=10_000)
    budget.record_tokens(input_tokens=9_000, output_tokens=1_000)
    with pytest.raises(BudgetExceededError):
        budget.consume_model("supervisor.model")
    budget.begin_finalization()
    budget.consume_model("supervisor.final")  # final synthesis is never cut off by tokens
    resumed = ExecutionBudget(model_limit=10, tool_limit=10, token_limit=10_000,
                              category_usage={"input_tokens": 9_500, "output_tokens": 600})
    with pytest.raises(BudgetExceededError):
        resumed.consume_model("supervisor.model")


def test_missing_usage_falls_back_to_an_estimate() -> None:
    middleware, _budget, events = _middleware()
    middleware.wrap_model_call(_request(), lambda _request: SimpleNamespace(result=[AIMessage(content="ok")]))
    usage = next(data for kind, data in events if kind == "context.usage")
    assert usage["estimated"] is True and usage["used_tokens"] > 0


def test_context_windows_follow_the_cortex_model_table() -> None:
    assert context_window_for("claude-sonnet-4-5") == 200_000
    assert context_window_for("claude-sonnet-4-6") == 1_000_000
    assert context_window_for("unknown-model") == 200_000
    assert context_window_for("claude-sonnet-4-5", 150_000) == 150_000


def _runtime_for_input(window: int):
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime

    runtime = object.__new__(DeepAgentsRuntime)
    runtime._model = SimpleNamespace(profile={"max_input_tokens": window})
    runtime._registry = SimpleNamespace(prepared_plan_review=None)
    runtime._model_visible_context = lambda: {}
    return runtime


def _invocation(history, summary=""):
    from app.agent_runtime.interface import RuntimeInvocation

    return RuntimeInvocation(run_id="r", thread_id="t", prompt="Change the CALLS filter", effort="medium",
                             workflow_input={"conversation_history": history, "conversation_summary": summary})


def test_history_replay_keeps_the_newest_turns_within_a_quarter_of_the_window() -> None:
    history = [{"role": "user" if i % 2 == 0 else "assistant", "content": f"turn {i} " + "x" * 4_000}
               for i in range(20)]
    history.insert(5, {"role": "assistant", "content": "HOUSEHOLD is compiling.", "kind": "progress"})
    runtime = _runtime_for_input(window=20_000)  # 20K characters of history allowed
    messages = runtime._agent_input(_invocation(history))["messages"]
    replayed = messages[:-1]
    assert sum(len(item["content"]) for item in replayed) <= 20_000
    assert replayed[-1]["content"].startswith("turn 19")  # newest kept, order preserved
    assert all("compiling" not in item["content"] for item in replayed)
    assert messages[-1]["content"].startswith("User request:")


def test_conversation_summary_precedes_the_replayed_turns() -> None:
    runtime = _runtime_for_input(window=200_000)
    messages = runtime._agent_input(_invocation(
        [{"role": "user", "content": "Map TMD"}, {"role": "assistant", "content": "Done"}],
        summary="## SESSION INTENT\nMap the ten TMD targets."))["messages"]
    assert messages[0]["content"].startswith("Summary of the earlier conversation:")
    assert [item["content"] for item in messages[1:3]] == ["Map TMD", "Done"]
