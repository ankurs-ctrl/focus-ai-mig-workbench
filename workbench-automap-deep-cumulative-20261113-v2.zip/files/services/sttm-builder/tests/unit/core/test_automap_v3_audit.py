"""Requirements uncovered by the v3 completion audit."""
from copy import deepcopy
import json
import pytest
from app.core.automap_context_packer import pack_context, ContextBudgetError
from app.core.automap_learning_pack import select_learning_pack
from app.core.automap_candidates import rank_candidates
from app.core.automap_policy import select_positive_evidence
from scripts.benchmark_automap_v3 import score


def pattern(identity, **extra):
    return {'pattern_id': identity, 'project_id': '1', 'support_count': 1,
            'target_contract': {'target_column': 'NAME'},
            'mapping_recipe': {'expression': f'a.{identity}', 'source_dependencies': ['a.ID']}, **extra}


def test_join_signal_changes_equal_semantic_candidates():
    catalog = [{'record_id': name, 'column': 'NAME', 'table_fqn': name, 'description': 'Household label', 'data_type': 'TEXT'}
               for name in ('a', 'b')]
    result = rank_candidates({'target_attribute': 'NAME', 'target_data_type': 'TEXT'}, catalog, connected_relations={'b'})
    assert result[0]['table_fqn'] == 'b'


def test_current_correction_never_competes_with_four_positive_shapes():
    correction = pattern('correction', provenance={'evidence_class': 'explicit_user_correction'})
    records = [pattern(str(index)) for index in range(6)] + [correction]
    pack = select_learning_pack(records, project_id='1', source_columns=['a.ID'])
    assert len(pack) == 5 and pack[0]['pattern_id'] == 'correction'
    wrappers = [{'pattern': item, 'mandatory': item['mandatory']} for item in pack]
    admitted = select_positive_evidence({'canonical_target_mapping_patterns': wrappers}, limit=4)
    assert len(admitted['canonical_target_mapping_patterns']) == 5


def test_quoted_mixed_case_is_not_an_applicable_unquoted_precedent():
    recipe = pattern('quoted')
    recipe['mapping_recipe']['source_dependencies'] = ['a."id"']
    assert not select_learning_pack([recipe], project_id='1', source_columns=['a.ID'])[0]['applicable']
    assert select_learning_pack([recipe], project_id='1', source_columns=['a."id"'])[0]['applicable']


def test_failed_soft_budget_keeps_completed_index_and_sample_trims():
    packet = {'context': {'archived_source_inventory': ['x' * 2000],
                          'description': 'Required meaning ' * 100, 'sample_values': ['x' * 2000]}}
    with pytest.raises(ContextBudgetError) as error:
        pack_context(packet, max_bytes=500)
    result = error.value.packet
    assert result['context_manifest']['trimmed_sections'] == ['archived_source_inventory', 'sample_values']
    assert result['context']['description'] == packet['context']['description']
    assert 'archived_source_inventory' not in result['context']


def test_historical_sql_bodies_are_last_and_current_cte_sql_is_atomic():
    recipe = pattern('prior', derived_dependencies=[{'name': 'old_cte', 'sql_text': 'SELECT ' + 'x' * 10_000}])
    packet = {'context': {'canonical_target_mapping_patterns': [{'pattern': recipe}],
                          'relation_graph': {'nodes': [{'sql_text': 'SELECT ID FROM CURRENT_TABLE'}]}}}
    saved = deepcopy(packet)
    with pytest.raises(ContextBudgetError):
        pack_context(packet, max_bytes=1500)
    packed = pack_context(packet, max_bytes=1500, trim_precedent_sql=True)
    assert packet == saved
    assert packed['context_manifest']['trimmed_sections'][-1] == 'precedent_sql_bodies'
    assert packed['context']['relation_graph'] == packet['context']['relation_graph']
    projected = packed['context']['canonical_target_mapping_patterns'][0]['pattern']
    assert projected['mapping_recipe']['expression'] == recipe['mapping_recipe']['expression']
    assert projected['derived_dependencies'][0]['sql_body_deferred_to_transformation']


def test_inline_shortlist_ladder_finishes_before_any_block_projection(monkeypatch):
    from app.core.automap_admission_context import AdmissionContext
    from tests.unit.core.test_automap_fast_context import plan_for
    original = AdmissionContext._replace_optional
    trials = []
    def measured(plan, ids, **kwargs):
        trials.append((plan.candidate_cap, kwargs.get('allow_blocks', True), plan.blocks.enabled))
        fits = original(plan, ids, **kwargs)
        return fits and plan.candidate_cap == 6
    monkeypatch.setattr(AdmissionContext, '_replace_optional', measured)
    _, plan = plan_for()
    assert trials == [(15, False, False), (10, False, False), (6, False, False)]
    assert not plan.blocks.enabled and not plan.required_pending_blocks()
    assert plan.candidate_cap == 6 and not plan.mandatory_oversized


def test_all_inline_trials_precede_blocked_trials_even_when_required_globals_overflow(monkeypatch):
    from app.core.automap_admission_context import AdmissionContext
    from tests.unit.core.test_automap_fast_context import plan_for, fast_payload
    original = AdmissionContext._replace_optional
    trials = []
    def measured(plan, ids, **kwargs):
        trials.append((plan.candidate_cap, kwargs.get('allow_blocks', True), plan.blocks.enabled))
        return original(plan, ids, **kwargs)
    monkeypatch.setattr(AdmissionContext, '_replace_optional', measured)
    value = fast_payload()
    value['data']['message'] = 'Mandatory exact rule. ' * 7500
    _, plan = plan_for(value)
    assert trials[:3] == [(15, False, False), (10, False, False), (6, False, False)]
    assert any(allow_blocks for _, allow_blocks, _ in trials[3:])
    assert plan.required_pending_blocks()


def test_packer_preserves_correction_and_current_graph_provenance_and_local_trim_markers():
    history = pattern('prior', derived_dependencies=[{'sql_text': 'x' * 10000}])
    correction = pattern('correction', derived_dependencies=[{'sql_text': 'required correction body'}],
                         provenance={'evidence_class': 'explicit_user_correction'})
    untouched = pattern('no_body')
    packet = {'context': {'patterns': [history, correction, untouched],
        'business_rules': {'sample_values': ['required literal']},
        'relation_graph': {'mapping_recipe': {}, 'required_ctes': [{'sql_text': 'current authored SQL'}]}}}
    packed = pack_context(packet, max_bytes=2500, trim_precedent_sql=True)
    assert packed['context']['patterns'][1] == correction
    assert packed['context']['patterns'][2] == untouched
    assert packed['context']['business_rules'] == packet['context']['business_rules']
    assert packed['context']['relation_graph'] == packet['context']['relation_graph']
    assert packed['context']['patterns'][0]['derived_dependencies'][0]['sql_body_deferred_to_transformation']


@pytest.mark.parametrize('classification', ['negative_conditions', 'incorrect_rule', 'mandatory_evidence', 'mandatory'])
@pytest.mark.parametrize('mapping_shape', ['list', 'target_map'])
def test_p1_mapping_precedent_wrappers_keep_negative_and_mandatory_bodies(classification, mapping_shape):
    mapping = pattern('negative', required_ctes=[{'name': 'required_population', 'sql_text': 'SELECT ' + 'x' * 10000}],
                      sample_values=['required example ' * 1000])
    if classification == 'negative_conditions':
        mapping['negative_conditions'] = {'sample_values': ['must not match ' * 1000]}
    elif classification == 'incorrect_rule':
        mapping['incorrect_rule'] = 'Previous rule excluded required population'
    mappings = [mapping] if mapping_shape == 'list' else {'NAME': mapping}
    record = {'record_id': 'fir:negative', 'kind': 'learning_evidence', 'body': {
        'target_id': 'NAME', 'category': 'mapping_precedents', 'evidence': {'mappings': mappings}}}
    if classification == 'mandatory_evidence':
        record['kind'] = 'mandatory_evidence'
    elif classification == 'mandatory':
        record['body']['evidence']['mandatory'] = True
    packet = {'context': {'global_records': [record]}}
    before = deepcopy(packet)
    with pytest.raises(ContextBudgetError) as caught:
        pack_context(packet, max_bytes=2000, trim_precedent_sql=True)
    assert caught.value.packet['context'] == before['context']
    assert packet == before
    assert 'precedent_sql_bodies' not in caught.value.packet['context_manifest']['trimmed_sections']


@pytest.mark.parametrize('protection', [
    'mandatory_kind', 'mandatory_category', 'mandatory_flag', 'correction_provenance',
    'correction_history', 'business_rules', 'mandatory_negative_evidence', 'source_graph',
])
@pytest.mark.parametrize('dependency_field', ['required_ctes', 'derived_dependencies'])
def test_p1_recursive_dependency_deferral_honors_classifications_and_protected_fields(protection, dependency_field):
    protected_body = {'sql_text': 'required body ' * 1000, 'sample_values': ['required literal']}
    if protection == 'mandatory_kind':
        protected_body['kind'] = 'mandatory_evidence'
    elif protection == 'mandatory_category':
        protected_body['category'] = 'mandatory_evidence'
    elif protection == 'mandatory_flag':
        protected_body['mandatory'] = True
    elif protection == 'correction_provenance':
        protected_body['provenance'] = {'evidence_class': 'explicit_user_correction'}
    else:
        protected_body = {protection: protected_body}
    recipe = pattern('prior', **{dependency_field: [{'nested': [protected_body]}, {'sql_text': 'optional body ' * 1000}]})
    packet = {'context': {'mapping_precedents': [{'mappings': [recipe]}]}}
    before = deepcopy(packet)
    with pytest.raises(ContextBudgetError) as caught:
        pack_context(packet, max_bytes=2000, trim_precedent_sql=True)
    projected = caught.value.packet['context']['mapping_precedents'][0]['mappings'][0]
    assert projected[dependency_field][0] == recipe[dependency_field][0]
    assert projected[dependency_field][1] == {'sql_body_deferred_to_transformation': True}
    assert projected['mapping_recipe'] == recipe['mapping_recipe']
    assert packet == before


def test_p1_negative_wrapper_does_not_prevent_safe_sibling_trimming():
    negative = pattern('negative', negative_conditions={'sample_values': ['required excluded literal']},
                       required_ctes=[{'sql_text': 'required population SQL'}])
    optional = pattern('optional', required_ctes=[{'sql_text': 'optional body ' * 1000}],
                       sample_values=['optional samples ' * 1000])
    records = [{'body': {'category': 'mapping_precedents', 'evidence': {'mappings': [item]}}}
               for item in (negative, optional)]
    packet = {'context': {'table_records': records}}
    packed = pack_context(packet, max_bytes=2000, trim_precedent_sql=True)
    assert packed['context']['table_records'][0] == records[0]
    projected = packed['context']['table_records'][1]['body']['evidence']['mappings'][0]
    assert 'sample_values' not in projected
    assert projected['required_ctes'] == [{'sql_body_deferred_to_transformation': True}]


@pytest.mark.parametrize('container', ['shared_list', 'target_map', 'learning', 'receipt'])
def test_negative_mapping_protection_does_not_propagate_to_optional_siblings(container):
    negative = pattern('negative', negative_conditions={'sample_values': ['excluded literal']},
                       required_ctes=[{'sql_text': 'required population SQL'}])
    optional = pattern('optional', sample_values=['optional example ' * 2000],
                       required_ctes=[{'sql_text': 'optional body ' * 2000}])
    mappings = {'NAME': negative, 'OTHER': optional} if container == 'target_map' else [negative, optional]
    body = {'mapping_precedents': [{'mappings': mappings}]}
    if container == 'learning':
        body = {'learning_context': body}
    if container == 'receipt':
        body = {'receipts': [{'result': {'data': body}}]}
    packet = {'context': body}
    before = deepcopy(packet)
    packed = pack_context(packet, max_bytes=2500, trim_precedent_sql=True)
    projected = packed['context']
    if container == 'learning':
        projected = projected['learning_context']
    if container == 'receipt':
        projected = projected['receipts'][0]['result']['data']
    actual = projected['mapping_precedents'][0]['mappings']
    required, trimmed = (actual['NAME'], actual['OTHER']) if container == 'target_map' else actual
    assert required == negative
    assert 'sample_values' not in trimmed
    assert trimmed['required_ctes'] == [{'sql_body_deferred_to_transformation': True}]
    assert packet == before


def test_no_sample_trim_is_claimed_when_only_mandatory_samples_exist():
    packet = {'context': {'business_rules': {'sample_values': ['must retain ' * 2000]}}}
    with pytest.raises(ContextBudgetError) as caught:
        pack_context(packet, max_bytes=1000)
    assert 'sample_values' not in caught.value.packet['context_manifest']['trimmed_sections']
    assert caught.value.packet['context'] == packet['context']


def test_benchmark_uses_actual_nested_recipe_packets_and_batch_metrics():
    packet = {'data': {'attributes': [{'target_attribute': 'NAME'}]}, 'context': {
        'citation_ids': ['src:a.ID', 'fir:prior'],
        'table_records': [{'body': {'canonical_target_mapping_patterns': [{'tier': 'T1', 'pattern': pattern('prior')}]}}]}}
    key = {'mappings': {'NAME': {'source_attributes': ['a.ID']}}}
    run = {'mappings': {'NAME': {'source_attributes': ['a.ID'], 'used_learning_ids': ['prior'],
           'decision_basis': {'citations': ['src:a.ID', 'fir:prior']}}}, 'meta': {
        'auto_map_batch_metrics': [{'source_model_call_count': 1}, {'source_model_call_count': 2}],
        'transformation_stages': [{'target_count': 3, 'validated_rules': 2}]}}
    result = score(key, run, [packet])
    assert result['missing_precedent_decisions'] == 1
    assert result['precedent_use_by_tier'] == {'T1': 1}
    assert result['calls_per_batch'] == [1, 2]
    assert result['rule_compile_rate'] == 2 / 3
    assert result['invalid_citations'] == 0


def test_model_packet_has_rank_reasons_and_preserves_canonical_store():
    from tests.unit.core.test_automap_fast_context import fast_payload, plan_for, unpack
    value = fast_payload()
    store, plan = plan_for(value)
    before = deepcopy(vars(store))
    packet = unpack(plan.messages([]))
    candidates = packet['context']['target_candidates']['NAME0']
    assert candidates and all(item['rank_reason'] for item in candidates)
    assert vars(store) == before


def test_registry_sample_cache_only_fills_missing_samples():
    from types import SimpleNamespace
    from app.core.semantic_model import SemanticModelService
    from app.schema.common import TableRef
    service = SemanticModelService.__new__(SemanticModelService)
    service._native_views_table = 'FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS'
    calls = []
    rows = [{'DB_NAME': 'D', 'SCHEMA_NAME': 'S', 'TABLE_NAME': 'T', 'COLUMN_NAME': name,
             'SAMPLE_VALUES': '["cached"]'} for name in ('ID', 'NAME')]
    def sql(query, params):
        calls.append((query, params))
        return SimpleNamespace(collect=lambda: rows)
    records = [{'database': 'D', 'schema_name': 'S', 'table_name': 'T', 'semantic_model': {'attributes': [
        {'name': 'ID', 'sample_values': ['yaml']}, {'name': 'NAME', 'description': 'Human meaning'}]}}]
    service._merge_column_profile_samples(SimpleNamespace(sql=sql), [TableRef(database='D', schema='S', table='T')], records)
    assert records[0]['semantic_model']['attributes'][0]['sample_values'] == ['yaml']
    assert records[0]['semantic_model']['attributes'][1]['sample_values'] == ['cached']
    assert records[0]['semantic_model']['attributes'][1]['description'] == 'Human meaning'
    assert 'FOCUS_DB_2.STTM_MCP.COLUMN_PROFILE_CACHE' in calls[0][0]
    assert calls[0][1] == ['D', 'S', 'T']


def test_legacy_validated_learning_remains_guidance_even_for_same_project():
    item = pattern('legacy', legacy_guidance=True)
    pack = select_learning_pack([item], project_id='1', source_columns=['a.ID'])
    assert len(pack) == 1 and pack[0]['tier'] == 'T4'
    assert pack[0]['guidance_only'] and not pack[0]['applicable']


def test_fast_job_has_five_batches_for_37_targets_and_no_batch_over_eight():
    from tests.test_automap_fast_job import authored, proxy
    client = proxy()
    req = authored(pending=37)
    req.meta['auto_map_fast_path'] = 'v1'
    pending = req.model_copy(update={'data': req.data.model_copy(update={'attributes': req.data.attributes[-37:]})})
    batches = client._balanced_retrieval_batches(pending)
    assert len(batches) == 5
    assert sum(map(len, batches)) == 37 and max(map(len, batches)) == 8


def test_local_request_spec_uses_manifest_and_does_not_load_tools():
    from types import SimpleNamespace
    from app.core.automap_local_session import local_run_spec
    settings = SimpleNamespace(app_env='local', local_dev_auth_enabled=True,
        resolved_metadata_database='WORKBENCH_DEV', normalized_snowflake_authenticator='programmatic_access_token')
    spec = local_run_spec(settings, 'source_mapping')
    assert spec['models']['orchestration'] == 'claude-haiku-4-5'
    assert spec['tools'] == [] and spec['tool_resources'] == {}
    assert 'selectable_sources' in spec['instructions']['orchestration']
    with pytest.raises(ValueError):
        local_run_spec(settings, 'foreign_stage')


def test_parallel_search_uses_separate_leased_sessions(monkeypatch):
    from contextlib import contextmanager
    from types import SimpleNamespace
    from app.core.automap_search_fallback import discover_fallback
    from app.core.mapping_search import MappingSearchService
    leased, released = [], []
    @contextmanager
    def factory():
        session = object()
        leased.append(session)
        try:
            yield session
        finally:
            released.append(session)
    def discover(self, *, target_columns, **kwargs):
        assert self.session in leased
        target = target_columns[0]
        return {'evidence': [{'knowledge_id': 'shared', 'target_columns': [target]}],
                'source_candidates': {}, 'diagnostics': {'query_count': 1, 'status': 'available'}}
    monkeypatch.setattr(MappingSearchService, 'discover', discover)
    service = SimpleNamespace(_settings=SimpleNamespace(automap_fast_max_in_flight=8),
                              _session=object(), _parallel_session_factory=factory)
    result = discover_fallback(service, target_columns=['A', 'B', 'C'])
    assert len(leased) == len(released) == 3 and len({id(s) for s in leased}) == 3
    assert result['diagnostics']['query_count'] == 3
    assert result['evidence'][0]['target_columns'] == ['A', 'B', 'C']


def test_spcs_fallback_pool_matches_fan_out_and_never_exhausts(monkeypatch):
    """37 slow targets on the real caller lease pool: no 'lease capacity exhausted'."""
    import time
    from types import SimpleNamespace
    from unittest.mock import Mock
    from app.core import snowflake
    from app.core.automap_search_fallback import discover_fallback
    from app.core.config import Settings
    from app.core.mapping_search import MappingSearchService

    def create(**_kwargs):
        session = Mock()
        session.sql.return_value.collect.return_value = [('ROLE', 'WH', 'DB', 'SCHEMA')]
        return SimpleNamespace(session=session, close=Mock())
    monkeypatch.setattr(snowflake, 'SnowflakeClient', create)
    monkeypatch.setattr(MappingSearchService, 'discover', lambda self, *, target_columns, **_: (
        time.sleep(0.05), {'evidence': [], 'source_candidates': {}, 'diagnostics': {'query_count': 1}})[1])
    snowflake.close_write_pools()
    settings = Settings(_env_file=None, snowflake_write_lease_pool_v1=True, local_dev_auth_enabled=False,
                        auth_mode='custom_oauth', automap_fast_max_in_flight=8)
    service = SimpleNamespace(_settings=settings, _session=SimpleNamespace(
        _workbench_search_context={'token': 'caller-token', 'role': 'ROLE'}))
    # Make any wait on the pool fail immediately, as an exhausted pool would.
    original = snowflake.SnowflakeSessionLeasePool.lease
    def strict_lease(self, **kwargs):
        assert self._limit._available > 0, 'fallback workers exceeded the caller lease pool'
        return original(self, **kwargs)
    monkeypatch.setattr(snowflake.SnowflakeSessionLeasePool, 'lease', strict_lease)
    try:
        result = discover_fallback(service, target_columns=[f'T{i}' for i in range(37)])
    finally:
        snowflake.close_write_pools()
    assert result['diagnostics']['parallel_fallback'] is True
    assert result['diagnostics']['errors'] == []
    assert result['diagnostics']['query_count'] == 37


def test_one_failing_fallback_target_degrades_instead_of_failing_the_job(monkeypatch):
    from contextlib import contextmanager
    from types import SimpleNamespace
    from app.core.automap_search_fallback import discover_fallback
    from app.core.mapping_search import MappingSearchService
    @contextmanager
    def factory():
        yield object()
    def discover(self, *, target_columns, **kwargs):
        if target_columns == ['B']:
            raise RuntimeError('Snowflake session lease capacity is exhausted')
        return {'evidence': [], 'source_candidates': {target_columns[0]: ['src.X']}, 'diagnostics': {'query_count': 1}}
    monkeypatch.setattr(MappingSearchService, 'discover', discover)
    service = SimpleNamespace(_settings=SimpleNamespace(automap_fast_max_in_flight=8),
                              _session=object(), _parallel_session_factory=factory)
    result = discover_fallback(service, target_columns=['A', 'B', 'C'])
    assert result['diagnostics']['status'] == 'degraded'
    assert len(result['diagnostics']['errors']) == 1 and result['diagnostics']['errors'][0].startswith('B: RuntimeError')
    assert set(result['source_candidates']) == {'A', 'C'}


def test_caller_lease_pool_capacity_is_validated():
    import pytest
    from app.core import snowflake
    from app.core.config import Settings
    settings = Settings(_env_file=None, snowflake_write_lease_pool_v1=True)
    for bad in (0, 9, True, 2.0):
        with pytest.raises(snowflake.SnowflakeConnectionError):
            with snowflake.caller_write_lease(settings, 'token', 'ROLE', reusable=True, maximum=bad):
                pass
