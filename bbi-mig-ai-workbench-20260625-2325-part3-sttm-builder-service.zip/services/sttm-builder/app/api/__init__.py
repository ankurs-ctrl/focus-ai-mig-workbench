from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request

from app.api.deps import get_auto_mapping_proxy_client, get_sttm_builder_service
from app.auth.dependencies import get_current_principal
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.sttm_builder import STTMBuilderService
from app.schema.contracts import ApiResponseEnvelope, build_response_envelope
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMBuilderRequest

from app.routers import (
    agents,
    agent_gateway,
    conversation,
    coco,
    dbt_conversion,
    derived_source,
    export_workbook,
    mapping_sql,
    semantic_context,
    semantic_model,
    sttm_builder,
    table_selection,
    test_case_generation,
    user,
)

router = APIRouter(prefix="/api/v1")
router.include_router(table_selection.router)
router.include_router(derived_source.router)
router.include_router(sttm_builder.router)
router.include_router(agent_gateway.router)
router.include_router(conversation.router)
router.include_router(coco.router)
router.include_router(mapping_sql.router)
router.include_router(dbt_conversion.router)
router.include_router(test_case_generation.router)
router.include_router(export_workbook.router)
router.include_router(agents.router)
router.include_router(user.router)
router.include_router(semantic_model.router)
router.include_router(semantic_context.router)


@router.post("/workbench/auto-map-jobs", status_code=202)
def start_auto_map_job(
    request: Request,
    body: STTMBuilderEnvelopeRequest | STTMBuilderRequest,
    service: Annotated[STTMBuilderService, Depends(get_sttm_builder_service)],
    proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
) -> ApiResponseEnvelope[dict]:
    normalized, _decision = sttm_builder._apply_sttm_preflight(request, body)
    if not proxy.should_delegate(normalized):
        raise HTTPException(status_code=400, detail="The request is not an Auto-map operation")
    prepared = service.prepare_auto_map_request(normalized)
    job = proxy.start_job(request, prepared)
    return build_response_envelope(
        operation="sttm.auto_map.job.start",
        request=request,
        request_id=prepared.request_id,
        data=job,
    )


@router.get("/workbench/auto-map-jobs/{job_id}")
def get_auto_map_job(
    request: Request,
    job_id: str,
    proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
) -> ApiResponseEnvelope[dict]:
    get_current_principal(request)
    job = proxy.get_job(request, job_id)
    return build_response_envelope(
        operation="sttm.auto_map.job.get",
        request=request,
        request_id=str(job.get("request_id") or ""),
        data=job,
    )
