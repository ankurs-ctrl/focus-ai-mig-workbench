# Revised goal: new Auto-map runs proceed independently of stale quarantines

This supersedes treating prompt failure on an all-quarantined pool as the solution. No ZIP until the complete implementation and local acceptance pass. The user authorized a 12-slot implementation and local live acceptance; client deployment remains a separate rollout.

## Required behavior

New jobs obtain execution capacity immediately when foreground execution slots are available. They do not wait on earlier quarantines, cleanup, expired database leases or terminated jobs. Confirmed terminated operations do not retain occupied execution reservations. Current legitimate foreground saturation may queue work; no claim of unlimited model concurrency. Model/provider failures and truly unmappable columns remain distinguishable from capacity problems.

## Architecture decision

Use the backend worker as the recovery coordinator, Snowflake as durable state, and provider-native run identities for control. Use Snowflake Cortex's documented asynchronous run API: background=true with threads provides run_id; reconnect/poll for results and cancel through POST /api/v2/cortex/agent/runs/{run_id}/cancel. Cancellation 409 means completed/already canceled; inspect authoritative thread state instead of blindly releasing. Run identifiers and cancellation support must be verified in the client's deployed account before enabling that transport there. Official reference: https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-run

Current synchronous transport has an ambiguous outcome after HTTP read timeout. Merely increasing that timeout, expiring a lease, or marking a local thread canceled does not establish remote termination. The new design must close that gap, including loss of the initial submission acknowledgement.

## Capacity separation

Maintain durable logical execution reservations independently from recovery work. Delivered rollout budget: 12 foreground calls plus allowance for up to 4 uncertain older operations, under a hard total outstanding ceiling of 16. This is a bounded application budget, not measured provider throughput or an applied client setting. Old unknown remote calls still count toward the ceiling; stale local records alone do not consume foreground inventory. Do not allow repeated quarantine to grow unbounded remote work. A further unknown beyond the allowance requires confirmed cancellation/termination or recovery before submitting more work; no architecture can honestly guarantee unlimited immediate requests when remote state is unavailable. Observe this exceptional condition and alert, rather than report model/evidence rejection or fabricate completion.

## Delivery order

1. Replace the fixed-lifetime synchronous model operation with an explicit persisted operation lifecycle: PREPARED, SUBMITTING, RUNNING, CANCEL_REQUESTED, TERMINAL, RECOVERY_PENDING. Bind job/batch/attempt, exact archived request digest, caller/access scope, thread/user-message/run identity, dispatcher generation and fence. Existing application job/partial mapping state is reused where appropriate; existing post-save AsyncJobService is not assumed to be the Auto-map queue.
2. Persist submission intent before POST, acknowledged run identity immediately afterwards. Never replay an uncertain submission. Recover lost acknowledgements by inspecting the dedicated original thread and matching the exact user message; if no unique run can be established, keep it in bounded uncertainty accounting. Retire dispatchers durably and check their generation at the dispatch boundary. A paused old worker must not be allowed to submit after retirement.
3. Separate queued/admission time from actual model execution budgets. The current parent wall-clock _automap_deadline must not expire a newly accepted job merely because earlier recovery is running. Accept jobs durably, return their job identity, preserve progress/checkpoints and resume unfinished batches after process restart. Bound queue admission/storage separately. New jobs do not acquire recovery locks or wait on background GET/cancel work.
4. Start a bounded recovery loop through the Auto-map worker lifespan; use durable conditional recovery leases so replicas do not duplicate actions. Persist attempts, next-attempt time, sanitized reason and immutable events. Resolve original caller credentials safely; never substitute service identity silently. Use a separate bounded session budget for health/recovery so cleanup cannot exhaust execution/renewal sessions.
5. On stuck operation, first recover a completed result. If it exceeded its execution budget or was canceled, invoke native cancellation, verify terminal state, retire the attempt, release its execution reservation, then retry only unfinished targets under a bounded retry budget. Completed proposals and human mappings are preserved. Idempotency prevents double application. Unknown provider outcomes move to bounded recovery allowance instead of occupying the foreground pool indefinitely.
6. Add authorized pool health and recovery observability; status reads stay read-only. Record foreground usage, uncertainty allowance, provider outstanding calls, actual POSTs, recovery/cancel outcome, session waits, admission waits and oldest unresolved operation separately. Routine execution remains in the existing mapping UI; no redesign.
7. Implement administrator-only exact-operation legacy reconciliation/abandonment with immutable audit, retirement evidence and unknown-outcome acknowledgement. Abandonment is not completion. The historical four slots require a separate client-side recovery/bootstrap operation; offline tests cannot supply their missing ownership/remote evidence.
8. Provide additive reviewed migrations and an idempotent quiesced rollout. New readers, inventory and configuration must agree; existing strict four-row readers cannot coexist with an eight-row inventory. Preserve old ownership/history and unknown-work accounting. Rollback retains compatible inventory and accounting rather than resetting epochs or shrinking below outstanding work.
9. Run unit, lifecycle, fault-injection and integration contracts before packaging. Document remaining live client checks precisely; only after the full local implementation passes create the requested updated-files ZIP.

## Mandatory local acceptance

- Start with all four legacy records quarantined: a new foreground job obtains an available foreground reservation and performs a model POST without waiting on legacy recovery.
- Existing terminated records do not reduce foreground capacity.
- One stalled call is automatically inspected/canceled and verified; a subsequent job succeeds without manual permit resets.
- Lost submit/cancel/release acknowledgement, authentication outage and worker death do not cause duplicate submissions or mappings, silent permit leaks, or unbounded total calls.
- Multiple replicas, nine-plus batches and bounded sessions make progress without sharing transaction sessions or blocking renewal behind cleanup.
- Restart resumes unfinished work and recovery without requiring mutable current prompts or losing earlier valid results.
- Only confirmed terminal states release provider accounting; unknown exposure never silently disappears.
- Selected-target scope, existing human mappings, transformation validation, confidence/reasoning and publishing controls remain intact.

## Current status

The complete implementation supersedes the earlier fail-fast patch. See IMPLEMENTATION-STATUS.md, ROLLOUT.md and TEST-RESULTS.md for the delivered behavior, verified evidence and client rollout requirements. Earlier ZIPs remain obsolete.
