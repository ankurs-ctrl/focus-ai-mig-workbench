import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse

from app.auth.dependencies import get_current_principal
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.config import Settings, get_settings
from app.api.deps import (
    get_auto_mapping_proxy_client,
    get_prepared_workspace_context_service,
    get_sttm_builder_service,
)
from app.core.prepared_context import (
    PreparedWorkspaceContextService,
    merge_workspace_overlay,
)
from app.core.sttm_builder import STTMBuilderService
from app.guardrails.config.loader import load_config
from app.guardrails.integrations.fastapi import attach_governance_decision
from app.guardrails.contracts.decisions import GovernanceDecision
from app.guardrails.runtime.preflight import PreflightGuard
from app.schema.contracts import ApiResponseEnvelope, build_response_envelope, resolve_request_id
from app.schema.workbench import WorkbenchInfoResponse
from app.schema.workspace_context import WorkbenchContextSnapshotV1
from app.schema.sttm_builder import (
    STTMBuilderEnvelopeRequest,
    SemanticContextItem,
    STTMBuilderRequest,
    STTMBuilderResponse,
    normalize_sttm_builder_invoke_body,
)

router = APIRouter(prefix="/workbench", tags=["STTM Builder"])
logger = logging.getLogger(__name__)


def _hydrate_prepared_workspace(
    body: STTMBuilderEnvelopeRequest,
    prepared_service: PreparedWorkspaceContextService,
) -> STTMBuilderEnvelopeRequest:
    context_id = (body.context.workspace_context_id or "").strip()
    if not context_id:
        return body
    hydrated = prepared_service.hydrate(context_id)
    if not hydrated:
        if body.context.workspace_context and body.context.workspace_context.source_tables:
            return body.model_copy(update={"context": body.context.model_copy(update={
                "workspace_context_id": None, "workspace_context_hash": None,
                "prepared_context_hash": None, "learning_context": None,
                "learning_context_id": None, "learning_context_hash": None,
            })})
        raise HTTPException(status_code=409, detail="Prepared context is unavailable. Refresh workspace context and retry.")
    prepared = hydrated["prepared"]
    if (
        body.context.workspace_context_hash
        and body.context.workspace_context_hash != prepared.workspace_context_hash
    ):
        raise HTTPException(status_code=409, detail="Prepared context version mismatch. Refresh workspace context and retry.")
    baseline = WorkbenchContextSnapshotV1.model_validate(hydrated["workspace"])
    if (baseline.project_id, baseline.sttm_id) != (body.context.project_id, body.context.sttm_id):
        raise HTTPException(status_code=409, detail="Prepared context belongs to a different workspace.")
    merged_workspace = merge_workspace_overlay(
        hydrated["workspace"],
        body.context.workspace_context,
    )
    typed_workspace = WorkbenchContextSnapshotV1.model_validate(merged_workspace)
    updates = {
        "workspace_context": typed_workspace,
        "semantic_bundle_id": prepared.semantic_bundle_id,
        "semantic_bundle_hash": prepared.semantic_bundle_hash,
        "learning_context_id": prepared.learning_context_id,
        "learning_context_hash": prepared.learning_context_hash,
        "artifact_refs": prepared.artifact_refs,
        "learning_context": hydrated.get("learning_context"),
        "prepared_context_hash": prepared.workspace_context_hash,
    }
    # Full snapshots may repeat unchanged inputs; compare normalized values,
    # not field presence. Explicit clears still invalidate prepared semantics.
    semantic_fields = {
        "source_tables", "target_table", "derived_sources", "relationships",
        "selected_columns_by_table", "filters", "relation_graph",
        "driving_table", "driving_relation_id",
    }
    changed_workspace = any(
        getattr(typed_workspace, field) != getattr(baseline, field)
        for field in semantic_fields
    )
    saved_semantics = hydrated["workspace"].get("_prepared_semantic_context") or []
    if not changed_workspace and not body.context.semantic_context and saved_semantics:
        updates["semantic_context"] = [SemanticContextItem.model_validate(item) for item in saved_semantics]
    if changed_workspace:
        # Keep the old workspace only as a structural baseline, not as current
        # semantic/evidence provenance. Live fields and a fresh resolve win.
        for key in ("semantic_bundle_id", "semantic_bundle_hash", "learning_context_id", "learning_context_hash"):
            updates[key] = getattr(body.context, key)
        updates["prepared_context_hash"] = None
        updates["learning_context"] = None
    result = body.model_copy(update={"context": body.context.model_copy(update=updates)})
    if not changed_workspace:
        from app.core.automap_prepared_evidence import TrustedPreparedAutoMap
        artifact = hydrated["workspace"].get("_prepared_automap_context")
        if isinstance(artifact, dict) and artifact:
            result.context._prepared_automap = TrustedPreparedAutoMap(artifact)
    return result


def _apply_sttm_preflight(
    request: Request,
    body: STTMBuilderEnvelopeRequest | STTMBuilderRequest,
) -> tuple[STTMBuilderEnvelopeRequest, GovernanceDecision]:
    normalized = normalize_sttm_builder_invoke_body(body)
    if not normalized.request_id:
        normalized = normalized.model_copy(update={"request_id": resolve_request_id(request)})

    principal = get_current_principal(request)
    trace_id = getattr(request.state, "trace_id", None) or normalized.context.trace_id or normalized.request_id
    guard = PreflightGuard(load_config(settings=get_settings()))
    payload, decision = guard.apply_to_sttm_request(
        normalized.model_dump(mode="json"),
        trace_id=str(trace_id),
        persona=principal.app_persona.value,
    )
    payload["warnings"] = [
        *payload.get("warnings", []),
        *(warning.model_dump() for warning in decision.warnings),
    ]
    guarded = STTMBuilderEnvelopeRequest.model_validate(payload)
    guarded.context._prepared_automap = normalized.context._prepared_automap
    attach_governance_decision(request, decision)
    return guarded, decision


@router.get(
    "/info",
    response_model=ApiResponseEnvelope[WorkbenchInfoResponse],
    summary="Get basic workbench metadata",
)
def info(
    request: Request,
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[WorkbenchInfoResponse]:
    return build_response_envelope(
        operation="workbench.info",
        request=request,
        data=WorkbenchInfoResponse(
        name=settings.app_name,
        environment=settings.app_env,
        version=settings.app_version,
        api_base_path="/api/v1",
        health_path="/healthz",
        ),
    )


@router.post(
    "/invoke",
    response_model=STTMBuilderResponse,
    summary="Invoke the STTM Builder orchestration agent",
    description=(
        "Sends a request to STTM_BUILDER_AGENT, which routes it to the appropriate "
        "sub-agent based on the `interface` field.\n\n"
        "**Interfaces**\n"
        "- `AUTO_MAP` — button-triggered mapping. Provide `attributes` (list of target "
        "attributes, each with optional current source mapping) and `source_tables` (pool of "
        "available source tables). Add `message` to include refinement context.\n"
        "- `TRANSFORM` — transformation rule generation. Same structured fields as AUTO_MAP.\n"
        "- `CHAT` — free-text `message`. The orchestration agent decides which sub-agent to "
        "call; the response always includes a `message` summarising the action or asking a "
        "follow-up.\n\n"
        "Pass `thread_id` from a previous response to continue the same agent session."
    ),
)
def invoke(
    request: Request,
    body: STTMBuilderEnvelopeRequest | STTMBuilderRequest,
    service: Annotated[STTMBuilderService, Depends(get_sttm_builder_service)],
    auto_mapping_proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
    prepared_service: Annotated[
        PreparedWorkspaceContextService,
        Depends(get_prepared_workspace_context_service),
    ],
) -> STTMBuilderResponse:
    body = _hydrate_prepared_workspace(normalize_sttm_builder_invoke_body(body), prepared_service)
    normalized, decision = _apply_sttm_preflight(request, body)
    if auto_mapping_proxy.should_delegate(normalized):
        prepared = service.prepare_auto_map_request(normalized)
        return auto_mapping_proxy.invoke(request, prepared)
    return service.invoke(normalized, governance_decision=decision)


@router.post(
    "/invoke/stream",
    summary="Invoke the STTM Builder orchestration agent as an SSE stream",
)
def invoke_stream(
    request: Request,
    body: STTMBuilderEnvelopeRequest | STTMBuilderRequest,
    service: Annotated[STTMBuilderService, Depends(get_sttm_builder_service)],
    auto_mapping_proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
    prepared_service: Annotated[
        PreparedWorkspaceContextService,
        Depends(get_prepared_workspace_context_service),
    ],
) -> StreamingResponse:
    body = _hydrate_prepared_workspace(normalize_sttm_builder_invoke_body(body), prepared_service)
    principal = get_current_principal(request)
    body = service.restore_auto_map_outcome(
        normalize_sttm_builder_invoke_body(body), owner=str(getattr(principal, "snowflake_user", None) or getattr(principal, "user_id", None) or ""),
    )
    normalized, decision = _apply_sttm_preflight(request, body)
    if auto_mapping_proxy.should_delegate(normalized):
        return StreamingResponse(
            auto_mapping_proxy.invoke_stream(
                request,
                normalized,
                prepare_request=service.prepare_auto_map_request,
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )
    return StreamingResponse(
        service.invoke_stream(normalized, governance_decision=decision),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
