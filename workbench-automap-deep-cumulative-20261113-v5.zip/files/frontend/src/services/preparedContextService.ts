import { getAuthenticatedReadScope } from "@/services/authService";
import { API_ROUTES } from "@/api/routes";
import {
  buildApiEnvelope,
  getApiData,
  postEnvelopeData,
} from "@/api/axiosInstance";

export type PreparedContextStatus = "ready" | "updating" | "partial" | "failed";

export type PreparedWorkspaceContext = {
  workspace_context_id: string;
  workspace_context_hash: string;
  workspace_version: string;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  semantic_registry_version?: string | null;
  semantic_projection_ids?: string[];
  learning_context_id?: string | null;
  learning_context_hash?: string | null;
  fir_epoch?: string | null;
  precedent_version?: string | null;
  correction_version?: string | null;
  artifact_refs?: Array<Record<string, unknown>>;
  status: PreparedContextStatus;
  cache_status: string;
  cache_source?: "memory" | "durable" | "fresh" | "coalesced" | string;
  readiness?: Record<string, boolean>;
  automap_readiness?: { version: string; status: string; revision?: string | null; target_count: number; coverage: Record<string, string>; stage_timings_ms: Record<string, number> };
  stage_timings_ms?: Record<string, number>;
  warnings?: string[];
  created_at?: string | null;
  updated_at?: string | null;
};

export type PrepareWorkspaceContextRequest = {
  workspace: Record<string, unknown>;
  workspace_context_id?: string | null;
  workspace_context_hash?: string | null;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  learning_context_id?: string | null;
  learning_context_hash?: string | null;
  semantic_registry_version?: string | null;
  fir_epoch?: string | null;
  precedent_version?: string | null;
  correction_version?: string | null;
  force?: boolean;
};

const inflight = new Map<string, Promise<PreparedWorkspaceContext>>();

function stableRequestKey(payload: PrepareWorkspaceContextRequest): string {
  const workspace = payload.workspace as {
    source_set_hash?: string;
    derived_set_hash?: string;
    project_id?: string;
    sttm_id?: string;
  };
  const input = payload.workspace;
  const stableWorkspace: Record<string, unknown> = {};
  // Match evidence dependencies, excluding hydration, handles and UI bookkeeping.
  for (const field of ["project_id", "sttm_id", "source_set_hash", "derived_set_hash", "source_tables",
    "target_table", "driving_table", "driving_relation_id", "selected_columns_by_table", "derived_sources",
    "relationships", "relation_graph", "mapping_intent", "filters", "raw_mapping_sql"])
    stableWorkspace[field] = input[field] ?? null;
  stableWorkspace.mapping_rows = ((input.mapping_rows ?? []) as Array<Record<string, unknown>>)
    .map(row => ({target_column: row.target_column, target_type: row.target_type ?? null}));
  stableWorkspace.authored_sql = input.mapping_sql !== input.compiled_mapping_sql ? input.mapping_sql ?? null : null;
  const stable = (value: unknown): unknown => Array.isArray(value) ? value.map(stable)
    : value && typeof value === "object" ? Object.fromEntries(Object.entries(value)
      .sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => [key, stable(item)])) : value;
  return [
    getAuthenticatedReadScope() ?? "anonymous",
    workspace.source_set_hash ?? "",
    workspace.derived_set_hash ?? "",
    JSON.stringify(stable(stableWorkspace)),
    workspace.project_id ?? "",
    workspace.sttm_id ?? "",
    payload.semantic_registry_version ?? "",
    payload.fir_epoch ?? "",
    payload.precedent_version ?? "",
    payload.correction_version ?? "",
    payload.force ? "force" : "cached",
  ].join("|");
}

export const preparedContextService = {
  prepare(payload: PrepareWorkspaceContextRequest): Promise<PreparedWorkspaceContext> {
    const key = stableRequestKey(payload);
    const share = getAuthenticatedReadScope() !== null;
    const existing = share ? inflight.get(key) : undefined;
    if (existing) return existing;

    const request = postEnvelopeData<PreparedWorkspaceContext>(
      API_ROUTES.workbench.contextPrepare,
      buildApiEnvelope("workbench.context.prepare", payload, {}),
      { timeout: 300000 },
    ).finally(() => {
      if (inflight.get(key) === request) inflight.delete(key);
    });
    if (share) inflight.set(key, request);
    return request;
  },

  get(contextId: string): Promise<PreparedWorkspaceContext> {
    return getApiData<PreparedWorkspaceContext>(
      API_ROUTES.workbench.contextStatus(contextId),
      {
        timeout: 30000,
        // A compact browser handle can legitimately be stale after a backend
        // restart or access-scope change. The provider silently discards it
        // and prepares the current snapshot again.
        skipGlobalError: true,
      },
    );
  },
};
