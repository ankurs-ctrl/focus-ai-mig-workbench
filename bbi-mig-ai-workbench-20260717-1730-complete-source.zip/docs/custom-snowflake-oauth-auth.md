# Custom Snowflake OAuth Auth Mode

This app now supports `AUTH_MODE=custom_oauth` as the primary deployed
authentication mode for SPCS.

## What changes in this mode

- Users authenticate through a Snowflake Custom OAuth Authorization Code flow.
- The backend exchanges the auth code for Snowflake OAuth tokens.
- The backend stores encrypted token material server-side in
  `TBL_WORKBENCH_OAUTH_SESSIONS`.
- The browser only receives an opaque HttpOnly session cookie.
- The same Snowflake OAuth access token is used for:
  - Snowpark / SQL session creation
  - Cortex Analyst REST calls
  - Cortex Agent REST calls

`Sf-Context-*` ingress headers are no longer the source of truth in this mode.
They remain available only for `AUTH_MODE=ingress_headers` rollback.

## Required Snowflake setup

Create a confidential custom OAuth integration for the app callback URL.

Example:

```sql
create or replace security integration STTM_BUILDER_CUSTOM_OAUTH
  type = oauth
  enabled = true
  oauth_client = custom
  oauth_client_type = 'CONFIDENTIAL'
  oauth_redirect_uri = 'https://<spcs-public-host>/api/v1/auth/callback'
  oauth_issue_refresh_tokens = true
  oauth_refresh_token_validity = 7776000
  oauth_enforce_pkce = false;
```

Then collect:

- client id via `describe integration ...`
- client secret via `select system$show_oauth_client_secrets(...)`

## Required app env

These must be present in deployed environments:

```env
AUTH_MODE=custom_oauth

SNOWFLAKE_OAUTH_CLIENT_ID=...
SNOWFLAKE_OAUTH_CLIENT_SECRET=...
SNOWFLAKE_OAUTH_AUTHORIZE_URL=https://<account-host>/oauth/authorize
SNOWFLAKE_OAUTH_TOKEN_URL=https://<account-host>/oauth/token-request
SNOWFLAKE_OAUTH_REDIRECT_URI=https://<spcs-public-host>/api/v1/auth/callback
SNOWFLAKE_OAUTH_SCOPE=session:role:<YOUR_RUNTIME_ROLE>

AUTH_SESSION_SECRET=...
AUTH_SESSION_ENCRYPTION_KEY=...
AUTH_SESSION_COOKIE_NAME=sttm_session
AUTH_STATE_COOKIE_NAME=sttm_oauth_state
AUTH_SESSION_COOKIE_SECURE=true
AUTH_SESSION_COOKIE_SAMESITE=lax

SNOWFLAKE_OAUTH_SESSIONS_TABLE=TBL_WORKBENCH_OAUTH_SESSIONS
```

Notes:

- `AUTH_SESSION_ENCRYPTION_KEY` may be a Fernet key or any non-empty secret.
- If it is not already a Fernet key, the app derives one from the secret.
- `AUTH_SESSION_SECRET` signs the OAuth state cookie.

## Metadata table

The backend stores sessions in:

- `TBL_WORKBENCH_OAUTH_SESSIONS`

This DDL is included in:

- `/Users/ankurshome/Desktop/storage/Mr-Bucky/bbi-mig-ai-workbench/infra/snowflake/create-table-ddl.sql`

## Backend endpoints

- `GET /api/v1/auth/login`
- `GET /api/v1/auth/callback`
- `GET /api/v1/auth/logout`
- `GET /api/v1/auth/session`

Frontend login buttons redirect to `/api/v1/auth/login?next=...`.

## Token behavior

In `custom_oauth` mode:

- SQL/Snowpark connections use direct OAuth bearer tokens.
- Cortex Analyst uses:
  - `Authorization: Bearer <token>`
  - `X-Snowflake-Authorization-Token-Type: OAUTH`
- Cortex Agent uses the same bearer OAuth pattern and the generic
  `/api/v2/cortex/agent:run` endpoint.

The old combined `<service_token>.<user_token>` path is not used.

## Rollback

To revert to the previous deployed behavior:

```env
AUTH_MODE=ingress_headers
```

That re-enables the existing `Sf-Context-*`-based identity path without
removing the new OAuth implementation.

## Local dev

Local development stays unchanged.

- Existing local Snowflake auth continues to work.
- `LOCAL_DEV_AUTH_ENABLED` behavior is unchanged.
- OAuth-primary behavior is intended for deployed environments.
