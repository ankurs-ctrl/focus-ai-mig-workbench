-- ============================================================
-- One-time FIR pipeline repair (2.9.6)
--
-- Why: owner's-rights procedures could not create the temporary tables they
-- used to advance streams, and SP_FIR_COLLECT_FEEDBACK only SELECTed its
-- streams. Offsets never moved, 12 streams went stale, and TSK_FIR_CAPTURE,
-- TSK_FIR_ENRICH_CONTEXT and TSK_FIR_LEARNING_QUEUE suspended on errors.
--
-- Run ONCE, after the 2.9.6 procedures are deployed (they drain streams into
-- TBL_FIR_STREAM_DRAIN). Do not add this file to the routine bootstrap:
-- recreating streams on every deploy would discard pending change data.
--
-- Unconsumed changes in a stale stream are already unreadable. Small,
-- high-value sources are replayed with SHOW_INITIAL_ROWS; the collectors
-- MERGE on deterministic record keys, so replayed rows already captured are
-- skipped. UI events are replayed by SP_FIR_BACKFILL_EVENTS instead.
-- ============================================================

CREATE TRANSIENT TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.TBL_FIR_STREAM_DRAIN (
    STREAM_NAME            STRING,
    DRAINED_AT             TIMESTAMP_NTZ
) DATA_RETENTION_TIME_IN_DAYS = 0;

-- Learned Add Join edges (also in fir_v2_schema.sql for new environments).
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.TBL_FIR_RELATIONSHIP_LEARNINGS (
    EDGE_KEY               STRING          NOT NULL,
    LEFT_TABLE             STRING          NOT NULL,
    RIGHT_TABLE            STRING          NOT NULL,
    JOIN_TYPE              STRING,
    CONDITIONS             VARIANT,
    EVIDENCE_CLASS         STRING,
    SUPPORT_KEYS           ARRAY,
    SUPPORT_COUNT          NUMBER          DEFAULT 0,
    REJECT_COUNT           NUMBER          DEFAULT 0,
    CONFIDENCE             FLOAT,
    CREATED_AT             TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_AT             TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
);

-- Replayed: publish events, uploaded documents, recommendation outcomes, derived sources.
CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_STTM_VERSIONS
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_STTM_VERSIONS
APPEND_ONLY = TRUE
SHOW_INITIAL_ROWS = TRUE
COMMENT = 'Captures STTM publish events for high-confidence FIR learning.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_CLIENT_SQL_ASSETS
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_CLIENT_SQL_ASSETS
APPEND_ONLY = FALSE
SHOW_INITIAL_ROWS = TRUE
COMMENT = 'Captures uploaded SQL scripts and Excel mapping imports for FIR document learning.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_RECOMMENDATION_OUTCOMES
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_FIR_RECOMMENDATION_OUTCOMES
APPEND_ONLY = TRUE
SHOW_INITIAL_ROWS = TRUE
COMMENT = 'Captures shown, opened, explained, applied, used, accepted, corrected, rejected, validated, and published recommendation outcomes.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_DERIVED_SOURCES
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_DERIVED_SOURCES
APPEND_ONLY = FALSE
SHOW_INITIAL_ROWS = TRUE
COMMENT = 'Captures derived source creation/modification for FIR processing.';

-- Fresh offsets: UI events are backfilled below; mapping attributes are
-- already learned directly on save/publish; the others are trigger signals
-- whose consumers scan their tables.
CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_WORKBENCH_EVENTS
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_FIR_EVENTS
APPEND_ONLY = TRUE
COMMENT = 'Captures canonical UI milestones and outcomes for offline FIR processing.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_STTM_ATTRIBUTES
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_STTM_ATTRIBUTES
APPEND_ONLY = FALSE
SHOW_INITIAL_ROWS = FALSE
COMMENT = 'Captures mapping attribute changes (AI vs user-modified vs manual) for FIR processing.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_CONVERSATION_TURNS
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_CONVERSATION_TURNS
APPEND_ONLY = TRUE
SHOW_INITIAL_ROWS = FALSE
COMMENT = 'Captures conversation history with agents for FIR conversation learning.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_360_CHANGES
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_AGENT_FIR_360
APPEND_ONLY = FALSE
SHOW_INITIAL_ROWS = FALSE
COMMENT = 'Captures FIR 360 record changes for downstream processing.';

CREATE OR REPLACE STREAM __STTM_METADATA_NAMESPACE__.STM_FIR_LEARNING_WORK_ITEMS
ON TABLE __STTM_METADATA_NAMESPACE__.TBL_FIR_LEARNING_WORK_ITEMS
APPEND_ONLY = FALSE
COMMENT = 'Ready-work signal for bounded twice-daily durable FIR learning catch-up.';

-- Legacy streams on the old SCH_STTM_MCP registry have no consumer.
DROP STREAM IF EXISTS __STTM_METADATA_NAMESPACE__.STM_FIR_SEM_TABLE_REGISTRY;
DROP STREAM IF EXISTS __STTM_METADATA_NAMESPACE__.STM_FIR_SEM_COLUMN_REGISTRY;
DROP STREAM IF EXISTS __STTM_METADATA_NAMESPACE__.STM_FIR_PRECOMPUTE_SEM_TABLE_REGISTRY;
DROP STREAM IF EXISTS __STTM_METADATA_NAMESPACE__.STM_FIR_PRECOMPUTE_SEM_COLUMN_REGISTRY;

-- Capture UI milestones missed while the stream was stale (idempotent by event id).
CALL __STTM_METADATA_NAMESPACE__.SP_FIR_BACKFILL_EVENTS(FALSE, 10000);

ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_CAPTURE RESUME;
ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_ENRICH_CONTEXT RESUME;
ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_LEARNING_QUEUE RESUME;

-- Run the chain now instead of waiting for the next twice-daily window.
EXECUTE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_CAPTURE;
