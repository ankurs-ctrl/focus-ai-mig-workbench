import type {
  DerivedSource,
  JoinConfig,
  MappingState,
  TableNode,
} from "@/features/sttm/types/sttm.types";

/**
 * Semantic key of the workspace an authored (uploaded or edited) SQL artifact
 * was written against.
 *
 * Authored SQL stays authoritative only while the durable relation graph and
 * mappings still match it. The key deliberately excludes metadata that loads
 * after hydration (column catalogs, semantic bundles, catalog descriptions) so
 * that opening a mapping never makes its authored SQL look stale, while any
 * user edit to sources, joins, derived SQL, mappings, or filters does.
 */
export type AuthoredSqlKeyInput = {
  sources: TableNode[];
  /** Selected target identity, excluding its reloadable column catalog. */
  targets?: TableNode[];
  derivedSources: DerivedSource[];
  relationships: JoinConfig[];
  mappings: MappingState[];
  drivingTableId?: string | null;
  sourceFilterSql?: string | null;
  sourceGroupBySql?: string | null;
  sourceOrderBySql?: string | null;
  sourceQueryModifiers?: Record<string, string>;
};

const text = (value: unknown) => String(value ?? "").trim();
const upper = (value: unknown) => text(value).toUpperCase();
const sqlText = (value: unknown) => text(value).replace(/\s+/g, " ");

function digest(value: string, version = "ask2"): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return `${version}:${hash.toString(16).padStart(8, "0")}:${value.length.toString(36)}`;
}

/** Only the empty shape emitted by target-catalog hydration has no SQL intent. */
export function isEmptyTargetPlaceholder(mapping: MappingState): boolean {
  if (mapping.status !== "UNMAPPED" || mapping.rule !== "Select...") return false;
  // Do not discard false/zero/empty-string constants or unrecognized future intent.
  const catalogFields = new Set(["id", "targetColumn", "targetType", "targetOrdinal", "status", "rule"]);
  return Object.entries(mapping).every(([key, value]) => {
    if (catalogFields.has(key)) return true;
    if (key === "mappingMode") return value == null || value === "source";
    if (key === "manuallySaved" || key === "manuallyEditedAfterAutoMap" || key === "descriptionEdited") return !value;
    return value == null || (Array.isArray(value) && value.length === 0);
  });
}

export function computeAuthoredSqlSemanticKey(input: AuthoredSqlKeyInput): string {
  return authoredSqlKey(input);
}

function authoredSqlKey(input: AuthoredSqlKeyInput, legacy = false, keepPlaceholders = false): string {
  const sources = input.sources
    .filter((table) => table.isSelected)
    .map((table) => upper(table.qualifiedName))
    .sort();
  const derived = input.derivedSources
    .filter((source) => source.isSelected)
    .map((source) => [text(source.id), sqlText(source.sqlText)])
    .sort(([left], [right]) => left.localeCompare(right));
  const relationships = input.relationships
    .filter((join) => !join.reviewRequired)
    .map((join) => [
      text(join.leftTableId),
      text(join.rightTableId),
      upper(join.joinType || "INNER"),
      (join.conditions ?? [])
        .map((condition) => [
          upper(condition.leftColumn),
          text(condition.operator || "="),
          upper(condition.rightColumn),
        ].join(" "))
        .sort(),
      ...(join.sqlPredicate ? [join.sqlPredicate] : []),
    ])
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
  const mappings = input.mappings
    .filter((mapping) => keepPlaceholders || !isEmptyTargetPlaceholder(mapping))
    .map((mapping) => [
      upper(mapping.targetColumn),
      text(mapping.status),
      text(mapping.mappingMode || "source"),
      (mapping.sourceColumns ?? (mapping.sourceColumn ? [mapping.sourceColumn] : [])).map(text),
      sqlText(mapping.expression),
      text(mapping.constantValue),
      ...(!legacy ? [text(mapping.targetType), text(mapping.rule), text(mapping.attributeName)] : []),
    ])
    .sort((left, right) => String(left[0]).localeCompare(String(right[0])));
  return digest(JSON.stringify({
    sources,
    ...(!legacy ? {targets: (input.targets ?? []).filter(table => table.isSelected).map(table => upper(table.qualifiedName)).sort()} : {}),
    derived,
    relationships,
    mappings,
    driving: text(input.drivingTableId),
    filter: sqlText(input.sourceFilterSql),
    groupBy: sqlText(input.sourceGroupBySql),
    orderBy: sqlText(input.sourceOrderBySql),
    ...(Object.keys(input.sourceQueryModifiers ?? {}).length ? { queryModifiers: input.sourceQueryModifiers } : {}),
  }), legacy ? "ask1" : "ask2");
}

/**
 * True when authored SQL exists and the workspace still matches the key it was
 * written against. A missing key means legacy authored SQL, which remains
 * authoritative as before.
 */
export function authoredSqlIsCurrent(
  authoredSql: string | null | undefined,
  storedKey: string | null | undefined,
  input: AuthoredSqlKeyInput,
): boolean {
  if (!text(authoredSql)) return false;
  if (!storedKey) return true;
  if (storedKey.startsWith("ask1:")) {
    // Read old saved keys without forcing a compile solely for a key upgrade.
    return storedKey === authoredSqlKey(input, true)
      || storedKey === authoredSqlKey(input, true, true);
  }
  return storedKey === computeAuthoredSqlSemanticKey(input);
}
