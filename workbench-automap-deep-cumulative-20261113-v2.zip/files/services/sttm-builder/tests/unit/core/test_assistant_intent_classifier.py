from __future__ import annotations

import json
from types import SimpleNamespace

from app.agent_runs.models import AssistantIntent
from app.assistant_conversations import intent_from_classification, resolves_deterministically
from app.assistant_intent_classifier import LABELS, classify_message
from app.core.snowflake import SnowflakeClient


class _Rows:
    def __init__(self, value):
        self._value = value

    def collect(self, statement_params=None):
        self.statement_params = statement_params
        if isinstance(self._value, Exception):
            raise self._value
        return [(self._value,)]


class _Session:
    def __init__(self, value):
        self.value = value
        self.calls = []

    def sql(self, query, params=None):
        self.calls.append((query, params))
        return _Rows(self.value)


def _settings(**overrides):
    return SimpleNamespace(assistant_model_intent_routing=True, assistant_intent_model="",
                           migration_agent_model_light="light-model", assistant_intent_timeout_seconds=4,
                           assistant_intent_min_confidence=0.7, **overrides)


def test_classifier_uses_the_light_model_with_a_closed_schema_and_binds_the_message() -> None:
    session = _Session(json.dumps({"intent": "READ_ONLY_QUESTION", "confidence": 0.93}))
    result = classify_message(session, _settings(), "which of my projects has unfinished mappings'); DROP",
                              has_run=True, awaiting=False)
    assert result is not None and result.label == "READ_ONLY_QUESTION" and result.confidence == 0.93
    query, params = session.calls[0]
    assert "DROP" not in query and params[0] == "light-model"
    assert json.loads(params[2])["schema"]["properties"]["intent"]["enum"] == sorted(LABELS)
    assert "DROP" in params[1]  # the message is data inside the prompt, never SQL


def test_low_confidence_unknown_labels_errors_and_disabled_routing_fall_back() -> None:
    assert classify_message(_Session(json.dumps({"intent": "MIGRATION_TASK", "confidence": 0.4})), _settings(),
                            "hmm", has_run=False, awaiting=False) is None
    assert classify_message(_Session(json.dumps({"intent": "DELETE_EVERYTHING", "confidence": 1})), _settings(),
                            "x", has_run=False, awaiting=False) is None
    assert classify_message(_Session(RuntimeError("no cortex")), _settings(), "x", has_run=False, awaiting=False) is None
    session = _Session(json.dumps({"intent": "MIGRATION_TASK", "confidence": 1}))
    disabled = SimpleNamespace(**{**vars(_settings()), "assistant_model_intent_routing": False})
    assert classify_message(session, disabled, "x", has_run=False, awaiting=False) is None
    assert session.calls == []


def test_labels_map_to_routes_and_run_controls_need_a_run() -> None:
    fallback = AssistantIntent.NEW_MIGRATION_TASK
    assert intent_from_classification("GREETING_OR_CAPABILITY", latest_run=None, fallback=fallback) == (
        AssistantIntent.CONVERSATIONAL_QA, True, False)
    assert intent_from_classification("MIGRATION_TASK", latest_run=None, fallback=fallback) == (
        AssistantIntent.NEW_MIGRATION_TASK, False, True)
    assert intent_from_classification("READ_ONLY_QUESTION", latest_run=None, fallback=fallback)[0] is \
        AssistantIntent.CONVERSATIONAL_QA
    assert intent_from_classification("DIAGNOSE", latest_run=None, fallback=fallback)[0] is fallback
    assert intent_from_classification("DIAGNOSE", latest_run=object(), fallback=fallback)[0] is \
        AssistantIntent.RUN_DIAGNOSTIC


def test_exact_controls_and_literal_requests_never_call_the_model() -> None:
    assert resolves_deterministically("continue", AssistantIntent.CONTINUE_RUN, latest_run=None)
    assert resolves_deterministically("Hello what all can you do", AssistantIntent.CONVERSATIONAL_QA, latest_run=None)
    assert resolves_deterministically("Create a mapping for HOUSEHOLD", AssistantIntent.NEW_MIGRATION_TASK, latest_run=None)
    assert not resolves_deterministically("which of my projects look unfinished?", AssistantIntent.NEW_MIGRATION_TASK,
                                          latest_run=None)


def test_classifier_receives_snowflake_client_session_property() -> None:
    client = object.__new__(SnowflakeClient)
    session = object()
    client._session = session

    assert client.session is session
    assert not callable(client.session)
