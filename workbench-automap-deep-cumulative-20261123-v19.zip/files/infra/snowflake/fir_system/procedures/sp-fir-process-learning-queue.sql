-- Advances the durable per-asset FIR learning queue during bounded catch-up.
-- Durable job rows are authoritative. The optional readiness stream is drained
-- after the durable work (best effort) so it never ages past retention.
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_PROCESS_LEARNING_QUEUE(
    "MAX_JOBS" INTEGER DEFAULT 1,
    "MAX_ITEMS_PER_JOB" INTEGER DEFAULT 10
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'process_queue'
EXECUTE AS OWNER
AS
$$
import json
import uuid

NAMESPACE = "__STTM_METADATA_NAMESPACE__"


def _literal(value):
    return "'" + str(value or "").replace("\\", "\\\\").replace("'", "''") + "'"


def _dependencies_complete(session, job_id, stage, expected_patterns):
    stages = (
        "document_parse", "semantic_enrichment", "pattern_conflict_analysis",
        "agent_semantic_enrichment", "recommendation_generation", "search_index_promotion",
    )
    required = stages[:stages.index(stage)]
    if not required:
        return True
    rows = session.sql(
        f"SELECT WORK_ITEM_TYPE, COUNT(*) AS ITEM_COUNT, "
        "COUNT_IF(COALESCE(STATUS, '') <> 'completed') AS INCOMPLETE_DEPENDENCIES "
        f"FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS WHERE LEARNING_JOB_ID = ? "
        f"AND WORK_ITEM_TYPE IN ({', '.join('?' for _ in required)}) GROUP BY WORK_ITEM_TYPE",
        params=[job_id, *required],
    ).collect()
    inventory = {row["WORK_ITEM_TYPE"]: row for row in rows}
    for predecessor in required:
        expected = expected_patterns if predecessor == "semantic_enrichment" else 1
        actual = inventory.get(predecessor)
        if actual is None:
            if expected == 0:
                continue
            return False
        if int(actual["ITEM_COUNT"] or 0) != expected or int(actual["INCOMPLETE_DEPENDENCIES"] or 0):
            return False
    return True


def _changed(rows):
    if not rows:
        return False
    values = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
    return any(isinstance(value, (int, float)) and value > 0 for value in values.values())


def _consume_ready_stream(session):
    # DML consumption advances the stream offset even if the following bounded
    # worker finds no eligible job. Owner's-rights procedures cannot create
    # temporary tables, so the shared always-empty sink is used instead.
    session.sql(
        f"INSERT INTO {NAMESPACE}.TBL_FIR_STREAM_DRAIN "
        "SELECT 'STM_FIR_LEARNING_WORK_ITEMS', CURRENT_TIMESTAMP() "
        f"FROM {NAMESPACE}.STM_FIR_LEARNING_WORK_ITEMS WHERE 0 = 1"
    ).collect()


def _refresh_job(session, job_id, expected_patterns):
    row = session.sql(f"""
        SELECT
            COUNT_IF(WORK_ITEM_TYPE = 'semantic_enrichment') AS DISCOVERED,
            COUNT_IF(
                WORK_ITEM_TYPE = 'semantic_enrichment' AND STATUS = 'completed'
            ) AS COMPLETED,
            COUNT_IF(
                WORK_ITEM_TYPE = 'semantic_enrichment' AND STATUS = 'dead_letter'
            ) AS FAILED,
            COUNT_IF(COALESCE(STATUS, '') NOT IN ('completed', 'dead_letter')) AS REMAINING,
            COUNT_IF(STATUS = 'dead_letter') AS DEAD_LETTER,
            COUNT(*) AS TOTAL_ITEMS
        FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        WHERE LEARNING_JOB_ID = {_literal(job_id)}
    """).collect()[0]
    discovered = expected_patterns
    incomplete_inventory = (
        int(row["DISCOVERED"] or 0) != discovered or int(row["TOTAL_ITEMS"] or 0) != discovered + 5
    )
    completed = int(row["COMPLETED"] or 0)
    failed = int(row["FAILED"] or 0)
    remaining = int(row["REMAINING"] or 0)
    dead_letter = int(row["DEAD_LETTER"] or 0)
    status = "failed" if dead_letter or incomplete_inventory else "running" if remaining else "completed"
    stage = (
        "semantic_enrichment"
        if completed + failed < discovered
        else ("failed" if status == "failed" else "downstream_processing" if remaining else "completed")
    )
    if incomplete_inventory:
        stage = "incomplete_work_inventory"
    checkpoint = json.dumps({
        "completed_patterns": completed,
        "failed_patterns": failed,
        "remaining_work_items": remaining,
        "incomplete_work_inventory": incomplete_inventory,
        "worker": "snowflake_catchup",
    })
    session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_LEARNING_JOBS
        SET STATUS = {_literal(status)},
            STAGE = {_literal(stage)},
            COMPLETED_PATTERN_COUNT = {completed},
            FAILED_PATTERN_COUNT = {failed},
            CHECKPOINT = PARSE_JSON({_literal(checkpoint)}),
            COMPLETED_AT = IFF(
                {_literal(status)} IN ('completed', 'failed'),
                CURRENT_TIMESTAMP(),
                NULL
            ),
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE LEARNING_JOB_ID = {_literal(job_id)}
    """).collect()
    return {
        "learning_job_id": job_id,
        "status": status,
        "discovered": discovered,
        "completed": completed,
        "failed": failed,
        "remaining": remaining,
    }


def _complete_deterministic_enrichment(session, job_id, max_items):
    owner = f"snowflake_catchup:{uuid.uuid4().hex}"
    session.sql("BEGIN TRANSACTION").collect()
    try:
        session.sql(f"""
            UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
            SET STATUS = 'running', LEASE_OWNER = ?,
                LEASE_EXPIRES_AT = DATEADD('second', 870, CURRENT_TIMESTAMP()),
                ATTEMPT_COUNT = ATTEMPT_COUNT + 1, UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE LEARNING_JOB_ID = ? AND WORK_ITEM_TYPE = 'semantic_enrichment'
              AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
              AND WORK_ITEM_ID IN (
                  SELECT WORK_ITEM_ID FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
                  WHERE LEARNING_JOB_ID = ? AND WORK_ITEM_TYPE = 'semantic_enrichment'
                    AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
                  ORDER BY CREATED_AT, WORK_ITEM_ID LIMIT {max_items}
              )
        """, params=[owner, job_id, job_id]).collect()
        _enrich_claimed(session, job_id, owner)
        session.sql(f"""
            UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
            SET STATUS = 'dead_letter', LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL,
                ERROR = OBJECT_CONSTRUCT('category', 'missing_pattern',
                    'message', 'Referenced pattern was not available for enrichment.'),
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE LEARNING_JOB_ID = ? AND LEASE_OWNER = ? AND STATUS = 'running'
        """, params=[job_id, owner]).collect()
        session.sql("COMMIT").collect()
    except Exception:
        session.sql("ROLLBACK").collect()
        raise


def _enrich_claimed(session, job_id, owner):
    session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_TARGET_MAPPING_PATTERNS p
        SET PATTERN_PAYLOAD = OBJECT_INSERT(
                OBJECT_INSERT(
                    p.PATTERN_PAYLOAD,
                    'validation_status',
                    IFF(p.VALIDATION_STATUS = 'extracted', 'enriched', p.VALIDATION_STATUS),
                    TRUE
                ),
                'applicability_conditions',
                ARRAY_DISTINCT(
                    ARRAY_CAT(
                        COALESCE(
                            p.PATTERN_PAYLOAD:applicability_conditions::ARRAY,
                            ARRAY_CONSTRUCT()
                        ),
                        ARRAY_CONSTRUCT(
                            'All required source roles must exist in the current relation graph.',
                            'Source type and target type must be compatible.',
                            'The mapping must pass compilation and validation before application.'
                        )
                    )
                ),
                TRUE
            ),
            VALIDATION_STATUS = IFF(
                p.VALIDATION_STATUS = 'extracted',
                'enriched',
                p.VALIDATION_STATUS
            ),
            UPDATED_AT = CURRENT_TIMESTAMP()
        FROM (
            SELECT PAYLOAD:pattern_id::STRING AS PATTERN_ID
            FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
            WHERE LEARNING_JOB_ID = {_literal(job_id)}
              AND WORK_ITEM_TYPE = 'semantic_enrichment'
              AND STATUS = 'running' AND LEASE_OWNER = {_literal(owner)}
        ) ready
        WHERE p.PATTERN_ID = ready.PATTERN_ID
    """).collect()
    session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        SET STATUS = 'completed',
            RESULT = OBJECT_CONSTRUCT('status', 'enriched'),
            ERROR = NULL,
            LEASE_OWNER = NULL,
            LEASE_EXPIRES_AT = NULL,
            COMPLETED_AT = CURRENT_TIMESTAMP(),
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE LEARNING_JOB_ID = {_literal(job_id)}
          AND WORK_ITEM_TYPE = 'semantic_enrichment'
          AND STATUS = 'running' AND LEASE_OWNER = {_literal(owner)}
          AND PAYLOAD:pattern_id::STRING IN (
              SELECT PATTERN_ID
              FROM {NAMESPACE}.TBL_FIR_TARGET_MAPPING_PATTERNS
              WHERE VALIDATION_STATUS IN (
                  'enriched', 'accepted', 'validated', 'published'
              )
          )
    """).collect()


def _run_agent(session, job_id, asset_id):
    items = session.sql(f"""
        SELECT WORK_ITEM_ID, ATTEMPT_COUNT
        FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        WHERE LEARNING_JOB_ID = {_literal(job_id)}
          AND WORK_ITEM_TYPE = 'agent_semantic_enrichment'
          AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
        LIMIT 1
    """).collect()
    if not items:
        completed = session.sql(
            f"SELECT COUNT(*) AS CNT FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS "
            "WHERE LEARNING_JOB_ID = ? AND WORK_ITEM_TYPE = 'agent_semantic_enrichment' AND STATUS = 'completed'",
            params=[job_id],
        ).collect()
        return "already_complete" if completed and int(completed[0]["CNT"] or 0) == 1 else "waiting_for_agent"
    item_id = str(items[0]["WORK_ITEM_ID"])
    attempts = int(items[0]["ATTEMPT_COUNT"] or 0)
    owner = f"snowflake_catchup:{uuid.uuid4().hex}"
    if attempts >= 2:
        session.sql(f"""
            UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
            SET STATUS = 'dead_letter', LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL,
                ERROR = OBJECT_CONSTRUCT('category', 'attempts_exhausted'), UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE WORK_ITEM_ID = ? AND
                (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
        """, params=[item_id]).collect()
        return "dead_letter"
    claimed = session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        SET STATUS = 'running',
            LEASE_OWNER = {_literal(owner)},
            LEASE_EXPIRES_AT = DATEADD('second', 870, CURRENT_TIMESTAMP()),
            ATTEMPT_COUNT = ATTEMPT_COUNT + 1,
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE WORK_ITEM_ID = {_literal(item_id)}
          AND ATTEMPT_COUNT < 2
          AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
    """).collect()
    if not _changed(claimed):
        return "waiting_for_agent"
    try:
        escalation = session.sql(f"""
            SELECT COUNT(DISTINCT p.PATTERN_ID) AS PATTERN_COUNT, COUNT_IF(
                COALESCE(p.CONTRADICTION_COUNT, 0) > 0
                OR LOWER(COALESCE(p.PATTERN_PAYLOAD:mapping_recipe:mode::STRING, '')) = 'complex'
                OR COALESCE(ARRAY_SIZE(p.PATTERN_PAYLOAD:relationship_dependencies), 0) > 0
                OR COALESCE(ARRAY_SIZE(p.PATTERN_PAYLOAD:derived_dependencies), 0) > 0
            ) AS ESCALATION_COUNT
            FROM {NAMESPACE}.TBL_FIR_TARGET_MAPPING_PATTERNS p
            JOIN {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS i
              ON i.PAYLOAD:pattern_id::STRING = p.PATTERN_ID
            WHERE i.LEARNING_JOB_ID = ? AND i.WORK_ITEM_TYPE = 'semantic_enrichment'
              AND i.STATUS = 'completed' AND p.STATUS = 'active'
        """, params=[job_id]).collect()
        if not escalation:
            raise RuntimeError('FIR escalation requirements could not be verified.')
        expected_rows = session.sql(
            f"SELECT DISCOVERED_PATTERN_COUNT FROM {NAMESPACE}.TBL_FIR_LEARNING_JOBS WHERE LEARNING_JOB_ID = ?",
            params=[job_id],
        ).collect()
        if not expected_rows or int(escalation[0]['PATTERN_COUNT'] or 0) != int(expected_rows[0]['DISCOVERED_PATTERN_COUNT'] or 0):
            raise RuntimeError('Canonical pattern inventory is incomplete; enrichment cannot be skipped.')
        if int(escalation[0]['PATTERN_COUNT'] or 0) > 0 and not int(escalation[0]['ESCALATION_COUNT'] or 0):
            completed = session.sql(f"""
                UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
                SET STATUS = 'completed', RESULT = OBJECT_CONSTRUCT(
                    'status', 'routine_enrichment_complete', 'agent_invoked', FALSE),
                    ERROR = NULL, LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL,
                    COMPLETED_AT = CURRENT_TIMESTAMP(), UPDATED_AT = CURRENT_TIMESTAMP()
                WHERE WORK_ITEM_ID = ? AND LEASE_OWNER = ? AND STATUS = 'running'
                  AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
            """, params=[item_id, owner]).collect()
            return 'routine_enrichment_complete' if _changed(completed) else 'lease_lost'
        response = session.call(
            f"{NAMESPACE}.SP_FIR_INVOKE_AGENT",
            {
                "task_type": "document_learning",
                "batch_size": 10,
                "daily_request_limit": 50,
                "daily_token_limit": 20000000,
                "max_concurrency": 2,
                "processing_options": {
                    "priority_asset_id": asset_id,
                    "target_row_count": int(
                        session.sql(f"""
                            SELECT COUNT(*) AS CNT
                            FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
                            WHERE LEARNING_JOB_ID = {_literal(job_id)}
                              AND WORK_ITEM_TYPE = 'semantic_enrichment'
                        """).collect()[0]["CNT"] or 0
                    ),
                    "collect_feedback": False,
                    "generate_inferences": True,
                    "create_semantic_versions": True,
                    "generate_recommendations": True,
                    "apply_decay": False,
                    "parse_documents": True,
                },
            },
        )
        if isinstance(response, str):
            response = json.loads(response)
        response = response if isinstance(response, dict) else {}
        status = str(response.get("status") or "unknown").lower()
        if status in (
            "budget_exhausted",
            "budget_ledger_unavailable",
            "concurrency_limit",
        ):
            session.sql(f"""
                UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
                SET STATUS = 'pending',
                    ATTEMPT_COUNT = GREATEST(ATTEMPT_COUNT - 1, 0),
                    ERROR = OBJECT_CONSTRUCT(
                        'category', 'deferred',
                        'message', {_literal(status)},
                        'action', 'Retained for the next catch-up.'
                    ),
                    LEASE_OWNER = NULL,
                    LEASE_EXPIRES_AT = NULL,
                    UPDATED_AT = CURRENT_TIMESTAMP()
                WHERE WORK_ITEM_ID = {_literal(item_id)}
                  AND LEASE_OWNER = {_literal(owner)} AND STATUS = 'running'
                  AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
            """).collect()
            return status
        if status != "success" or not response.get("agent_invoked") or response.get("errors"):
            raise RuntimeError(f"Agent returned {status}.")
        completed = session.sql(f"""
            UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
            SET STATUS = 'completed',
                RESULT = PARSE_JSON({_literal(json.dumps(response, default=str))}),
                ERROR = NULL,
                LEASE_OWNER = NULL,
                LEASE_EXPIRES_AT = NULL,
                COMPLETED_AT = CURRENT_TIMESTAMP(),
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE WORK_ITEM_ID = {_literal(item_id)}
              AND LEASE_OWNER = {_literal(owner)} AND STATUS = 'running'
              AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
        """).collect()
        if not _changed(completed):
            return "lease_lost"
        return status
    except Exception as exc:
        retry = attempts + 1 < 2
        error = json.dumps({
            "category": "transient" if retry else "permanent",
            "message": str(exc),
            "work_item_type": "agent_semantic_enrichment",
            "attempt_count": attempts + 1,
            "action": (
                "Retained for the next catch-up."
                if retry
                else "Inspect the asset and use the admin retry action."
            ),
        })
        session.sql(f"""
            UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
            SET STATUS = {_literal('pending' if retry else 'dead_letter')},
                ERROR = PARSE_JSON({_literal(error)}),
                LEASE_OWNER = NULL,
                LEASE_EXPIRES_AT = NULL,
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE WORK_ITEM_ID = {_literal(item_id)}
              AND LEASE_OWNER = {_literal(owner)} AND STATUS = 'running'
              AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()
        """).collect()
        return "retry" if retry else "dead_letter"


def _complete_conflict_stage(session, job_id):
    # Different CRM implementations of a target are alternatives, not negative
    # evidence. Only explicit correction/supersession may penalize a recipe.
    session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        SET STATUS = 'completed', ERROR = NULL, LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL,
            RESULT = OBJECT_CONSTRUCT('status', 'conflicts_analyzed', 'policy', 'explicit_negative_evidence_only'),
            COMPLETED_AT = CURRENT_TIMESTAMP(), UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE LEARNING_JOB_ID = ? AND WORK_ITEM_TYPE = 'pattern_conflict_analysis'
          AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
    """, params=[job_id]).collect()


def _complete_post_agent_stages(session, job_id):
    session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        SET STATUS = 'completed', ERROR = NULL, LEASE_OWNER = NULL, LEASE_EXPIRES_AT = NULL,
            RESULT = OBJECT_CONSTRUCT('status', 'postprocessing_complete',
                'recommendation_generation_verified', FALSE),
            COMPLETED_AT = CURRENT_TIMESTAMP(), UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE LEARNING_JOB_ID = ? AND WORK_ITEM_TYPE = 'recommendation_generation'
          AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
    """, params=[job_id]).collect()
    ready = session.sql(f"""
        SELECT COUNT(*) AS CNT FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        WHERE LEARNING_JOB_ID = ? AND WORK_ITEM_TYPE = 'recommendation_generation' AND STATUS = 'completed'
    """, params=[job_id]).collect()
    if not ready or int(ready[0]["CNT"] or 0) != 1:
        return
    try:
        session.sql(f"""
            UPDATE {NAMESPACE}.TBL_FIR_RUN_OBSERVABILITY
            SET PATTERNS_ENRICHED = (
                    SELECT COUNT(DISTINCT p.PATTERN_ID)
                    FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS i
                    JOIN {NAMESPACE}.TBL_FIR_TARGET_MAPPING_PATTERNS p
                      ON p.PATTERN_ID = i.PAYLOAD:pattern_id::STRING
                    WHERE i.LEARNING_JOB_ID = {_literal(job_id)}
                      AND i.WORK_ITEM_TYPE = 'semantic_enrichment' AND i.STATUS = 'completed'
                      AND p.STATUS = 'active' AND p.SUPERSEDED_BY IS NULL
                      AND p.VALIDATION_STATUS IN ('enriched', 'accepted', 'validated', 'published')
                      AND p.PATTERN_PAYLOAD:validation_status::STRING = p.VALIDATION_STATUS
                ),
                PATTERNS_PROMOTED = NULL,
                RESULT_VALIDATION_STATUS = 'search_visibility_unverified',
                METADATA = OBJECT_INSERT(COALESCE(METADATA, OBJECT_CONSTRUCT()),
                    'pattern_counts_status', 'persisted_enrichment_only', TRUE)
            WHERE RUN_ID = (
                SELECT RESULT:observability_run_id::STRING
                FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
                WHERE LEARNING_JOB_ID = {_literal(job_id)}
                  AND WORK_ITEM_TYPE = 'agent_semantic_enrichment' AND STATUS = 'completed'
            )
        """).collect()
    except Exception:
        pass
    session.sql(f"""
        UPDATE {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS
        SET STATUS = 'completed',
            RESULT = OBJECT_CONSTRUCT(
                'status',
                CASE WORK_ITEM_TYPE
                    WHEN 'search_index_promotion' THEN 'ready_for_search_refresh'
                END,
                'search_visibility_verified', FALSE
            ),
            ERROR = NULL,
            LEASE_OWNER = NULL,
            LEASE_EXPIRES_AT = NULL,
            COMPLETED_AT = CURRENT_TIMESTAMP(),
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE LEARNING_JOB_ID = {_literal(job_id)}
          AND WORK_ITEM_TYPE = 'search_index_promotion'
          AND (STATUS = 'pending' OR (STATUS = 'running' AND LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()))
    """).collect()


def process_queue(session, max_jobs=1, max_items_per_job=10):
    max_jobs = max(1, min(int(max_jobs or 1), 1))
    max_items = max(1, min(int(max_items_per_job or 10), 10))
    jobs = session.sql(f"""
        SELECT j.LEARNING_JOB_ID, j.ASSET_ID, j.DISCOVERED_PATTERN_COUNT
        FROM {NAMESPACE}.TBL_FIR_LEARNING_JOBS j
        WHERE j.STATUS = 'running'
          AND EXISTS (
              SELECT 1
              FROM {NAMESPACE}.TBL_FIR_LEARNING_WORK_ITEMS i
              WHERE i.LEARNING_JOB_ID = j.LEARNING_JOB_ID
                AND (
                    i.STATUS = 'pending'
                    OR (
                        i.STATUS = 'running'
                        AND i.LEASE_EXPIRES_AT < CURRENT_TIMESTAMP()
                    )
                )
          )
        ORDER BY j.UPDATED_AT, j.CREATED_AT
        LIMIT {max_jobs}
    """).collect()
    results = []
    for job in jobs:
        job_id = str(job["LEARNING_JOB_ID"])
        asset_id = str(job["ASSET_ID"] or "")
        expected = int(job["DISCOVERED_PATTERN_COUNT"] or 0)
        if _dependencies_complete(session, job_id, "semantic_enrichment", expected):
            _complete_deterministic_enrichment(session, job_id, max_items)
        if _dependencies_complete(session, job_id, "pattern_conflict_analysis", expected):
            _complete_conflict_stage(session, job_id)
        agent_status = "waiting_for_deterministic_enrichment"
        if _dependencies_complete(session, job_id, "agent_semantic_enrichment", expected):
            agent_status = _run_agent(session, job_id, asset_id)
        if _dependencies_complete(session, job_id, "recommendation_generation", expected):
            _complete_post_agent_stages(session, job_id)
        refreshed = _refresh_job(session, job_id, expected)
        refreshed["agent_status"] = agent_status
        results.append(refreshed)
    status = (
        "no_work" if not results else
        "failed" if any(item["status"] == "failed" for item in results) else
        "in_progress" if any(item["status"] != "completed" for item in results) else "completed"
    )
    # Advance the optional ready-signal stream after durable work so it never
    # ages past retention. A stale or missing stream must not block the queue.
    try:
        _consume_ready_stream(session)
        consumed = True
    except Exception:
        consumed = False
    return {
        "status": status,
        "trigger_stream_consumed": consumed,
        "work_source": "durable_queue",
        "search_visibility_verified": False,
        "processed_jobs": results,
    }
$$;
