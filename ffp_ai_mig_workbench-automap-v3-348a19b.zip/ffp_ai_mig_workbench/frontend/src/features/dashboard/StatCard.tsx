"use client";
import { AiaBox, AiaPaper } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

import Link from "next/link";
import type { ReactNode } from "react";
import { SECONDARY_TEXT_SX } from '@/config/typography-tokens';

type StatCardProps = {
  icon: ReactNode;
  label: string;
  value: string | number;
  href?: string;
};

export default function StatCard({ icon, label, value, href }: StatCardProps) {
  const card = (
    <AiaPaper
      elevation={0}
      className="rounded-[20px] border border-[#EEF2F7] bg-[#FAFBFC] px-5 py-4"
      sx={{
        transition:
          "transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease, border-color 0.2s ease",
        "&:hover": {
          transform: "translateY(-4px)",
          bgcolor: "#F3F4F6",
          borderColor: "#DCE3EC",
          boxShadow: "0 12px 28px rgba(17, 24, 39, 0.12)",
        },
      }}
    >
      <AiaBox className="flex items-center justify-between gap-3">
        <AiaText
          sx={{
            fontSize: "48px",
            fontWeight: 600,
            lineHeight: 1,
            color: "var(--aia-text-color)",
          }}
        >
          {value}
        </AiaText>

        <AiaBox
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            p: 1.25,
            borderRadius: "12px",
            border: "1px solid #DCE3EC",
            bgcolor: "#FFFFFF",
            color: "var(--aia-text-color)",
          }}
        >
          {icon}
        </AiaBox>
      </AiaBox>

      <AiaText sx={{ ...SECONDARY_TEXT_SX, mt: 3, fontWeight: 500 }}>
        {label}
      </AiaText>
    </AiaPaper>
  );

  if (!href) return card;

  return (
    <Link
      href={href}
      aria-label={`${label}: ${value}`}
      className="block rounded-[20px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2"
      style={{ textDecoration: "none", color: "inherit" }}
    >
      {card}
    </Link>
  );
}
