'use client';
import {useEffect,useState} from 'react';
import {Box,Typography,Paper,Table,TableHead,TableBody,TableRow,TableCell,TextField,Alert,Chip,Tabs,Tab,Button} from '@mui/material';
import {AiaLoadingOverlay} from '@/components/ui';
import {authService} from '@/services/authService';
import {getApiData,postEnvelopeData,buildApiEnvelope} from '@/api/axiosInstance';
import {getAllProjectsSummary,invalidateProjectSummaries} from '@/services/projectService';
import AdminResourceActions from './AdminResourceActions';
type Resource = {id:string;name:string;kind:'project'|'mapping';status:string;projectId?:string;recoverable_until?:string};
export default function ResourcesPage(){
 const [items,setItems]=useState<Resource[]>([]),[admin,setAdmin]=useState(false),[search,setSearch]=useState(''),[error,setError]=useState('');
 const [view,setView]=useState<'active'|'archived'|'deleted'>('active'),[loading,setLoading]=useState(true),[restoring,setRestoring]=useState<string|null>(null);
 useEffect(()=>{
  let live=true;
  setLoading(true);setError('');
  void (async()=>{
   const session=await authService.getSession();
   if(session.app_persona!=='ADMIN')throw new Error('Only the Admin persona can manage projects and mappings.');
   if(live)setAdmin(true);
   let rows:Resource[];
   if(view!=='active') rows=(await getApiData<Resource[]>('/v1/admin/resources/removed')).filter(item=>item.status.toLowerCase()===view);
   else {
    const data=await getAllProjectsSummary(true);
    rows=[...data.projects.map(project=>({id:project.project_id,name:project.project_name,kind:'project' as const,status:project.status})),...data.sttms.map(mapping=>({id:mapping.sttm_id,name:mapping.sttm_name||mapping.sttm_id,kind:'mapping' as const,projectId:mapping.project_id,status:mapping.status}))];
   }
   if(live)setItems(rows);
  })().catch(cause=>{if(live)setError(cause.message);}).finally(()=>{if(live)setLoading(false);});
  return()=>{live=false;};
 },[view]);
 const restore=async(item:Resource)=>{
  setRestoring(`${item.kind}:${item.id}`);setError('');
  try{
   await postEnvelopeData(`/v1/admin/resources/${item.kind}/${encodeURIComponent(item.id)}/restore`,buildApiEnvelope('admin.resource.restore',{}));
   invalidateProjectSummaries();
   // Reconcile archived children after a project restore without blanking the page.
   const [rows]=await Promise.all([getApiData<Resource[]>('/v1/admin/resources/removed'),getAllProjectsSummary(true)]);setItems(rows.filter(item=>item.status.toLowerCase()===view));
  }catch(cause){setError(cause instanceof Error?cause.message:'Unable to restore this item.');}finally{setRestoring(null);}
 };
 return <Box sx={{p:4,overflow:'auto',width:'100%',position:'relative',bgcolor:'#f7f8fa'}}>
 <AiaLoadingOverlay open={loading} label="Loading projects and mappings…"/>
 <Typography variant="h5" sx={{fontWeight:700}}>Projects & Mappings</Typography><Typography sx={{mt:1,color:'#64748b'}}>Admin controls for keeping your workspace organized.</Typography>
 {error?<Alert severity="error" sx={{my:2}}>{error}</Alert>:null}
 {admin?<><Tabs value={view} onChange={(_,value)=>setView(value)} sx={{mt:2}}><Tab value="active" label="Active"/><Tab value="archived" label="Archived"/><Tab value="deleted" label="Deleted · 30 days"/></Tabs>
 <Alert severity="info" sx={{my:3}}>{view==='deleted'?'Deleted items can be restored for 30 days. Restore the parent project first. Saved history is retained after the recovery window.':view==='archived'?'Archived projects and mappings appear here. Restore a project before restoring its mappings.':'Archive or delete items from listings. Saved versions and published history are retained. Removing a project also hides its mappings.'}</Alert>
 <TextField size="small" label="Search projects and mappings" value={search} onChange={event=>setSearch(event.target.value)} sx={{mb:2,width:360,maxWidth:'100%'}}/>
 <Paper variant="outlined" sx={{overflowX:'auto'}}><Table><TableHead><TableRow><TableCell>Name</TableCell><TableCell>Type</TableCell><TableCell>Status</TableCell><TableCell align="right">Admin actions</TableCell></TableRow></TableHead><TableBody>
 {items.filter(item=>item.name.toLowerCase().includes(search.toLowerCase())).map(item=><TableRow key={`${item.kind}:${item.id}`}><TableCell sx={{maxWidth:420,overflowWrap:'anywhere'}}><strong>{item.name}</strong></TableCell><TableCell sx={{textTransform:'capitalize'}}>{item.kind}</TableCell><TableCell><Chip size="small" label={item.status}/>{item.recoverable_until?<Typography variant="caption" sx={{display:"block"}}>Restore until {new Date(item.recoverable_until).toLocaleDateString()}</Typography>:null}</TableCell><TableCell align="right">{view!=='active'?<Button disabled={restoring!==null} onClick={()=>void restore(item)}>{restoring===`${item.kind}:${item.id}`?'Restoring…':'Restore'}</Button>:<AdminResourceActions {...item} onRemoved={()=>setItems(rows=>rows.filter(row=>!(row.kind===item.kind&&row.id===item.id)&&!(item.kind==='project'&&row.projectId===item.id)))}/>}</TableCell></TableRow>)}
 {!loading&&!items.length?<TableRow><TableCell colSpan={4}>No {view} projects or mappings.</TableCell></TableRow>:null}
 </TableBody></Table></Paper></>:null}</Box>;
}
