"""Versioned JSON receipts for server-built, exactly sized Auto-map packets.

Only the existing authenticated proxy handoff may supply these receipts. A
message digest detects mutation; it is not a replacement for caller access checks.
No pickle, dynamic class loading or caller-selected code is used for hydration.
"""
from copy import deepcopy
from types import SimpleNamespace

from app.core.automap_retrieval import digest
from app.core.automap_input_budget import wire_messages, wire_text

VERSION = 'automap-packet-v1'
STATE_FIELDS = frozenset(('_preview_mode admission_events allowed base_operations candidate_cap candidate_reasons '
    'column_rankings context_manifest derived_failures eligible_by_ref forced_candidates global_evidence_roots '
    'group_relation groups inventory_ids mandatory_oversized max_bytes max_chars next_pages node_relations omitted '
    'omitted_source_groups omitted_target_groups oversized_optional_groups pinned ranking_scores rankings '
    'read_operations record_group records rendered_record_ids requested_pins required_groups required_pins '
    'retry_outcomes selected shown snapshot source_inventory_index state_hash table_root_group target_groups '
    'unproved_derived validated_derived warnings native_tool_hint data_question_evidence packet_timings').split())
BLOCK_FIELDS = frozenset(('snapshot targets max_chars max_bytes threshold enabled blocks reviews roots text_roots '
    'record_roots active preview root_contexts required_roots').split())



def freeze(plan, messages, results, events):
    from app.core.automap_shards import ContextRecord
    records = dict(plan.records)
    records.update({record.record_id: record for record in plan.prepared.global_records})

    def encode(value):
        if isinstance(value, ContextRecord):
            return {'$packet_record': value.record_id}
        if isinstance(value, dict):
            if all(isinstance(key, str) for key in value):
                # Tagged maps keep original dictionaries distinct from tags.
                return {'$packet_map': [[key, encode(child)] for key, child in value.items()]}
            return {'$packet_map': [[encode(key), encode(child)] for key, child in value.items()]}
        if isinstance(value, (set, frozenset, tuple)):
            return {'$packet_' + type(value).__name__: [encode(child) for child in (sorted(value, key=repr) if isinstance(value, (set, frozenset)) else value)]}
        if isinstance(value, list):
            return [encode(child) for child in value]
        if value is None or type(value) in (str, bool, int, float):
            return value
        raise TypeError('Unsupported frozen packet state: ' + type(value).__name__)

    excluded = {'store', 'prepared', 'blocks', 'deadline', '_preview_store', '_preview_cache'}
    if set(vars(plan)) - excluded - STATE_FIELDS:
        raise ValueError('Unversioned Auto-map admission state')
    state = {key: encode(value) for key, value in vars(plan).items() if key not in excluded}
    ledger_fields = ('reads', 'cursors', 'pages_read', 'discovered', 'evidence', 'available_evidence',
                     'historical_dependencies', 'historical_dependency_owners', 'rejected_evidence_ids')
    text = wire_text(messages)
    body = {'version': VERSION, 'input_digest': digest(plan.store.original),
        'message_digest': digest(wire_messages(messages)), 'messages': wire_messages(messages),
        'final_chars': len(text), 'final_bytes': len(text.encode('utf-8')),
        'limits': {'chars': plan.max_chars, 'bytes': plan.max_bytes},
        'records': {identity: {'owner': record.scope.owner_id, 'snapshot': record.scope.snapshot_id,
            **record._payload()} for identity, record in records.items()},
        'state': state, 'blocks': encode(vars(plan.blocks)),
        'global_records': [record.record_id for record in plan.prepared.global_records],
        'prepared_records': [record.record_id for record in plan.prepared.records],
        'ledger': {key: encode(getattr(plan.store, key)) for key in ledger_fields},
        'results': deepcopy(results), 'events': deepcopy(events)}
    body['receipt_digest'] = digest(body)
    return body


def hydrate(packet, store, *, expected_digest, max_chars, max_bytes, deadline):
    from app.core.automap_stored_json import load_stored
    packet = load_stored(packet)
    from app.core.automap_fast_context import FastContextPlan
    from app.core.automap_evidence_blocks import EvidenceBlocks
    from app.core.automap_shards import ContextRecord, SnapshotScope
    if packet.get('version') != VERSION:
        raise ValueError('Unsupported frozen Auto-map packet version')
    body = {key: value for key, value in packet.items() if key != 'receipt_digest'}
    if packet.get('receipt_digest') != expected_digest or digest(body) != expected_digest:
        raise ValueError('Frozen Auto-map packet receipt mismatch')
    messages = wire_messages(packet['messages'])
    text = wire_text(messages)
    if (packet['input_digest'] != digest(store.original) or packet['message_digest'] != digest(messages)
            or len(text) != packet['final_chars'] or len(text.encode('utf-8')) != packet['final_bytes']
            or packet['final_chars'] > min(180000, max_chars) or packet['final_bytes'] > min(180000, max_bytes)):
        raise ValueError('Frozen Auto-map packet identity or final budget mismatch')
    records = {identity: ContextRecord(scope=SnapshotScope(owner_id=value['owner'], snapshot_id=value['snapshot']),
        record_id=identity, kind=value['kind'], body=value['body']) for identity, value in packet['records'].items()}

    def decode(value):
        if isinstance(value, list):
            return [decode(child) for child in value]
        if not isinstance(value, dict):
            return value
        if len(value) != 1:
            raise ValueError('Invalid frozen packet state tag')
        tag, contents = next(iter(value.items()))
        if tag == '$packet_record':
            return records[contents]
        if tag == '$packet_map':
            return {decode(key): decode(child) for key, child in contents}
        constructors = {'$packet_tuple': tuple, '$packet_set': set, '$packet_frozenset': frozenset}
        if tag in constructors:
            return constructors[tag](decode(child) for child in contents)
        raise ValueError('Invalid frozen packet state tag')

    plan = FastContextPlan.__new__(FastContextPlan)
    for key, value in packet['state'].items():
        if key not in STATE_FIELDS:
            raise ValueError('Invalid frozen packet field')
        setattr(plan, key, decode(value))
    plan.store, plan.deadline, plan._preview_cache = store, deadline, {}
    plan.prepared = SimpleNamespace(records=tuple(records[identity] for identity in packet['prepared_records']),
        global_records=tuple(records[identity] for identity in packet['global_records']))
    plan.blocks = EvidenceBlocks(store.snapshot_hash, plan.max_chars, plan.max_bytes, store.targets)
    block_state = decode(packet['blocks'])
    if set(block_state) != BLOCK_FIELDS:
        raise ValueError('Invalid frozen packet block fields')
    plan.blocks.__dict__.update(block_state)
    for key, value in packet['ledger'].items():
        if key not in {'reads', 'cursors', 'pages_read', 'discovered', 'evidence', 'available_evidence',
                       'historical_dependencies', 'historical_dependency_owners', 'rejected_evidence_ids'}:
            raise ValueError('Invalid frozen packet ledger field')
        setattr(store, key, decode(value))
    if plan.state_hash != plan._state_hash():
        raise ValueError('Frozen Auto-map admission context mismatch')
    return plan, messages, deepcopy(packet['results']), deepcopy(packet['events'])


def worker_reference(req):
    """A small same-caller reference to an acknowledged durable job receipt."""
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    packet = req.meta['_automap_frozen_packet']
    return STTMBuilderEnvelopeRequest.model_validate({'contract_version':req.contract_version,
        'request_id':req.request_id,'operation':req.operation.value,
        'context':{'project_id':req.context.project_id,'sttm_id':req.context.sttm_id},
        'data':{'intent':'AUTO_MAP','attributes':[item.model_dump(mode='json') for item in req.data.attributes]},
        'meta':{'_automap_deadline':req.meta.get('_automap_deadline'), '_automap_packet_ref':{'version':VERSION,'receipt_digest':packet['receipt_digest'],
            'batch_index':req.meta['auto_mapping_batch_index']}}})


def hydrate_worker_reference(service, req):
    """Load only the current native caller's live job; never trust browser proofs."""
    from app.core.auto_mapping_proxy import AutoMappingProxyClient, _RESOLUTION_PLAN_KEY
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    ref = req.meta.get('_automap_packet_ref')
    if ref is None:
        return req
    if (not isinstance(ref, dict) or set(ref) != {'version','receipt_digest','batch_index'}
            or ref['version'] != VERSION or type(ref['batch_index']) is not int or ref['batch_index'] < 0):
        raise ValueError('Invalid Auto-map packet reference')
    table = service._settings.qualify_metadata_object_name('TBL_AUTO_MAP_JOBS')
    from app.core.automap_storage_sql import collect_storage_sql
    rows = collect_storage_sql(service._session, f'''SELECT JOB_STATE FROM {table}
        WHERE REQUEST_ID = ? AND OWNER_ID = CURRENT_USER() AND EXPIRES_AT > CURRENT_TIMESTAMP()
          AND COALESCE(JOB_STATE:recovery_role::VARCHAR, CURRENT_ROLE()) = CURRENT_ROLE()
        LIMIT 2''', params=[str(req.request_id)])
    if len(rows) != 1:
        raise ValueError('Authorized durable Auto-map packet is unavailable')
    value = rows[0].as_dict() if hasattr(rows[0], 'as_dict') else dict(rows[0])
    state = AutoMappingProxyClient._load_job_state(value['JOB_STATE'])
    proxy = AutoMappingProxyClient(service._settings)
    root = proxy._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(state['request_envelope']))
    plan = proxy._trusted_resolution_plan(root)
    preflight = plan.get('preflight') or {}
    entries = preflight.get('batches') or []
    index = ref['batch_index']
    if index >= len(entries) or entries[index].get('status') != 'ready':
        raise ValueError('Durable Auto-map batch is not dispatchable')
    packet = entries[index].get('frozen_packet') or {}
    if packet.get('receipt_digest') != ref['receipt_digest']:
        raise ValueError('Durable Auto-map packet reference mismatch')
    pending = proxy._pending_resolution_request(root)
    by_name = {item.target_attribute:item for item in pending.data.attributes}
    attributes = [by_name[name] for name in entries[index]['target_attributes']]
    if ([item.model_dump(mode='json') for item in attributes] != [item.model_dump(mode='json') for item in req.data.attributes]
            or req.context.project_id != pending.context.project_id or req.context.sttm_id != pending.context.sttm_id):
        raise ValueError('Durable Auto-map requested target scope mismatch')
    meta = {**pending.meta, 'auto_mapping_batch_index':index, '_automap_frozen_packet':packet,
        '_automap_fast_handoff':{**pending.meta['_automap_fast_handoff'],'packet_digest':packet['receipt_digest']}}
    meta.pop(_RESOLUTION_PLAN_KEY,None)
    return pending.model_copy(update={'data':pending.data.model_copy(update={'attributes':attributes}), 'meta':meta})
