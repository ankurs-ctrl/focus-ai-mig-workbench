"""Learning Retrieval Service for AGT_SOURCE_MAPPING integration.

This service retrieves and ranks FIR learnings, similar mappings, and
correction history to provide comprehensive learning context to agents.
"""
from __future__ import annotations

import logging
from typing import Any

from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.agent_learning_service import AgentLearningService, AgentLearning
from app.schema.sttm_builder import (
    LearningContext,
    FIRLearningItem,
    SimilarMappingItem,
    SemanticLearningItem,
    MappingIntentItem,
    ProjectContextItem,
    CrossProjectPatternItem,
    CorrectionHistoryItem,
)

logger = logging.getLogger(__name__)


class LearningRetrievalService:
    """Retrieves and ranks FIR learnings for agent context.

    Provides methods to fetch:
    - FIR learnings from inferences
    - Similar mappings from this and other projects
    - Semantic learnings for column disambiguation
    - Mapping intent (captured or inferred)
    - Project context
    - Cross-project patterns
    - Correction history to avoid repeating mistakes
    """

    def __init__(self, session: Session, settings: Settings) -> None:
        self._session = session
        self._settings = settings
        self._agent_learning_service = AgentLearningService(session, settings)

    def get_comprehensive_learning_context(
        self,
        project_id: str,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        mapping_intent: dict[str, Any] | None = None,
        sttm_id: str | None = None,
        max_fir_learnings: int = 15,
        max_similar_mappings: int = 10,
        max_corrections: int = 5,
        context_key: str | None = None,
        source_set_hash: str | None = None,
        derived_set_hash: str | None = None,
        milestone: str | None = None,
        target_agent: str = "AGT_SOURCE_MAPPING",
    ) -> LearningContext:
        """Retrieve all relevant learning context for a mapping operation.

        Returns prioritized and deduplicated learning items.

        Args:
            project_id: Current project ID
            source_tables: List of source table qualified names
            target_table: Target table qualified name
            target_columns: List of target column names
            mapping_intent: Optional provided mapping intent
            sttm_id: Optional STTM ID for context retrieval
            max_fir_learnings: Maximum FIR learnings to return
            max_similar_mappings: Maximum similar mappings to return
            max_corrections: Maximum correction history items

        Returns:
            LearningContext with all retrieved learning data
        """
        try:
            fir_learnings = self._get_fir_learnings(
                source_tables,
                target_table,
                target_columns,
                max_fir_learnings,
                context_key=context_key,
                project_id=project_id,
                sttm_id=sttm_id,
            )
            similar_mappings = self._get_similar_mappings(
                project_id, source_tables, target_table, target_columns, max_similar_mappings
            )
            semantic_learnings = self._get_semantic_learnings(target_columns)
            intent = self._get_or_infer_mapping_intent(
                project_id, target_table, source_tables, mapping_intent
            )
            project_context = self._get_project_context(project_id, source_tables, sttm_id)
            cross_project_patterns = self._get_cross_project_patterns(
                source_tables, target_table, target_columns
            )
            correction_history = self._get_correction_history(
                project_id, target_columns, max_corrections
            )
            all_tables = list(source_tables) + ([target_table] if target_table else [])
            semantic_version_learnings = self.get_semantic_version_learnings(all_tables)

            fir_recommendations = self._get_fir_recommendations_for_context(
                project_id=project_id,
                source_tables=source_tables,
                target_table=target_table,
                target_columns=target_columns,
                context_key=context_key,
                source_set_hash=source_set_hash,
                derived_set_hash=derived_set_hash,
                milestone=milestone,
                target_agent=target_agent,
            )

            return LearningContext(
                fir_learnings=fir_learnings,
                similar_mappings=similar_mappings,
                semantic_learnings=semantic_learnings,
                mapping_intent=intent,
                project_context=project_context,
                cross_project_patterns=cross_project_patterns,
                correction_history=correction_history,
                semantic_version_learnings=semantic_version_learnings,
                fir_recommendations=fir_recommendations,
                context_key=context_key,
                retrieval_mode=(
                    str(fir_recommendations[0].get("retrieval_mode"))
                    if fir_recommendations
                    else None
                ),
            )
        except Exception as exc:
            logger.warning("Failed to retrieve learning context: %s", exc)
            return LearningContext()

    def _get_fir_learnings(
        self,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        limit: int = 15,
        *,
        context_key: str | None = None,
        project_id: str | None = None,
        sttm_id: str | None = None,
    ) -> list[FIRLearningItem]:
        """Retrieve exact FIR inferences, then reusable knowledge for the same subjects."""
        try:
            inference_table = self._settings.qualify_table_name(
                self._settings.snowflake_assistant_inferences_table
            )
            subjects = {
                str(value).strip().upper()
                for value in [*source_tables, target_table, *target_columns]
                if value and str(value).strip()
            }
            subjects.update(
                f"{target_table.strip().upper()}.{column.strip().upper()}"
                for column in target_columns
                if target_table and column and column.strip()
            )

            def quote(value: str) -> str:
                return "'" + value.replace("'", "''") + "'"

            select_sql = f"""
            SELECT
                INFERENCE_ID AS LEARNING_ID,
                COALESCE(INFERENCE_GOAL_ID, INFERENCE_TYPE) AS LEARNING_TYPE,
                COALESCE(SUBJECT_KEY, ATTRIBUTES:pattern_key::STRING, '') AS PATTERN_KEY,
                SUMMARY,
                COALESCE(CONFIDENCE, 0.5) AS CONFIDENCE,
                COALESCE(PROVENANCE:agent::STRING, SOURCE) AS SOURCE,
                COALESCE(
                    STRUCTURED_ANSWER:business_purpose::STRING,
                    STRUCTURED_ANSWER:business_definition::STRING,
                    STRUCTURED_ANSWER:business_meaning::STRING,
                    ATTRIBUTES:business_rationale::STRING
                ) AS BUSINESS_RATIONALE,
                COALESCE(STRUCTURED_ANSWER:domain::STRING, ATTRIBUTES:domain_pattern::STRING) AS DOMAIN_PATTERN,
                COALESCE(
                    ATTRIBUTES:reusability::STRING,
                    IFF(INFERENCE_GOAL_ID = 'Q2', 'column_specific',
                        IFF(INFERENCE_GOAL_ID IN ('Q6', 'Q7'), 'table_specific', 'highly_reusable'))
                ) AS REUSABILITY,
                TO_CHAR(CREATED_AT, 'YYYY-MM-DD HH24:MI:SS') AS CREATED_AT
            FROM {inference_table}
            WHERE STATUS = 'active'
              AND COALESCE(VALIDATION_STATUS, 'unvalidated') NOT IN ('rejected', 'superseded')
              AND COALESCE(CONFIDENCE, 0.5) >= 0.3
              {{predicate}}
            ORDER BY COALESCE(CONFIDENCE, 0.5) DESC, CREATED_AT DESC
            LIMIT {limit}
            """

            rows = []
            if context_key:
                rows = self._session.sql(
                    select_sql.format(predicate=f"AND CONTEXT_KEY = {quote(context_key)}")
                ).collect()
            if not rows and subjects:
                subject_literals = ", ".join(quote(subject) for subject in sorted(subjects))
                scope = [f"UPPER(COALESCE(SUBJECT_KEY, '')) IN ({subject_literals})"]
                if project_id:
                    scope.append(f"PROJECT_ID = {quote(str(project_id))}")
                if sttm_id:
                    scope.append(f"STTM_ID = {quote(str(sttm_id))}")
                rows = self._session.sql(
                    select_sql.format(predicate="AND (" + " OR ".join(scope) + ")")
                ).collect()
            return [
                FIRLearningItem(
                    learning_id=str(row["LEARNING_ID"] or ""),
                    learning_type=str(row["LEARNING_TYPE"] or ""),
                    pattern_key=str(row["PATTERN_KEY"] or ""),
                    summary=str(row["SUMMARY"] or ""),
                    confidence=float(row["CONFIDENCE"]) if row["CONFIDENCE"] else 0.5,
                    source=str(row["SOURCE"] or ""),
                    business_rationale=row["BUSINESS_RATIONALE"],
                    domain_pattern=row["DOMAIN_PATTERN"],
                    reusability=row["REUSABILITY"],
                    created_at=row["CREATED_AT"],
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get FIR learnings: %s", exc)
            return []

    def _get_similar_mappings(
        self,
        project_id: str,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        limit: int = 10,
    ) -> list[SimilarMappingItem]:
        """Find similar mappings from this or other projects.

        Prioritizes:
        1. Same project mappings (highest)
        2. Published STTMs in other projects
        3. Exact target column name match
        """
        try:
            target_cols_list = ", ".join(f"'{col}'" for col in target_columns) if target_columns else "''"

            query = f"""
            SELECT
                a.ATTRIBUTE_ID as mapping_id,
                s.PROJECT_ID as project_id,
                COALESCE(p.PROJECT_NAME, s.PROJECT_ID) as project_name,
                s.STTM_ID as sttm_id,
                COALESCE(s.STTM_NAME, s.STTM_ID) as sttm_name,
                a.ATTRIBUTE_NAME as target_column,
                COALESCE(TRY_PARSE_JSON(a.SOURCE_COLUMN), ARRAY_CONSTRUCT(a.SOURCE_COLUMN)) as source_columns,
                a.TRANSFORMATION_LOGIC as preprocessing_rule,
                COALESCE(a.CONDITION:preprocessing_rule_type::STRING, 'Direct') as preprocessing_rule_type,
                COALESCE(a.CONDITION:confidence::NUMBER, 0.7) as confidence_score,
                s.STATUS = 'published' as was_published,
                CASE
                    WHEN s.PROJECT_ID = '{project_id}' THEN 1.0
                    WHEN s.STATUS = 'published' THEN 0.8
                    ELSE 0.5
                END as similarity_score
            FROM {self._settings.qualify_table_name('TBL_STTM_ATTRIBUTES')} a
            JOIN {self._settings.qualify_table_name('TBL_STTM')} s ON a.STTM_ID = s.STTM_ID
            LEFT JOIN {self._settings.qualify_table_name('TBL_PROJECTS')} p ON s.PROJECT_ID = p.PROJECT_ID
            WHERE a.ATTRIBUTE_NAME IN ({target_cols_list})
              AND a.SOURCE_COLUMN IS NOT NULL
              AND a.SOURCE_COLUMN != ''
            ORDER BY similarity_score DESC, confidence_score DESC
            LIMIT {limit}
            """

            rows = self._session.sql(query).collect()
            return [
                SimilarMappingItem(
                    mapping_id=str(row["MAPPING_ID"] or ""),
                    project_id=str(row["PROJECT_ID"] or ""),
                    project_name=str(row["PROJECT_NAME"] or ""),
                    sttm_id=str(row["STTM_ID"] or ""),
                    sttm_name=str(row["STTM_NAME"] or ""),
                    target_column=str(row["TARGET_COLUMN"] or ""),
                    source_columns=self._parse_source_columns(row["SOURCE_COLUMNS"]),
                    preprocessing_rule=row["PREPROCESSING_RULE"],
                    preprocessing_rule_type=str(row["PREPROCESSING_RULE_TYPE"] or "Direct"),
                    confidence_score=float(row["CONFIDENCE_SCORE"]) if row["CONFIDENCE_SCORE"] else 0.7,
                    was_published=bool(row["WAS_PUBLISHED"]),
                    similarity_score=float(row["SIMILARITY_SCORE"]) if row["SIMILARITY_SCORE"] else 0.5,
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get similar mappings: %s", exc)
            return []

    def _get_semantic_learnings(
        self,
        target_columns: list[str],
        limit: int = 10,
    ) -> list[SemanticLearningItem]:
        """Retrieve semantic learnings for column disambiguation."""
        try:
            target_cols_pattern = "%|%".join(target_columns) if target_columns else ""

            query = f"""
            SELECT
                LEARNING_ID as learning_id,
                LEARNING_TYPE as learning_type,
                SUMMARY as summary,
                COALESCE(CONFIDENCE, 0.7) as confidence,
                COALESCE(ATTRIBUTES:applies_to, ARRAY_CONSTRUCT()) as applies_to,
                ATTRIBUTES:correct_interpretation::STRING as correct_interpretation,
                ATTRIBUTES:incorrect_interpretation::STRING as incorrect_interpretation
            FROM {self._settings.qualify_table_name(self._settings.snowflake_semantic_learnings_table)}
            WHERE STATUS = 'active'
              AND LEARNING_TYPE IN ('column_disambiguation', 'transformation_pattern', 'domain_vocabulary')
            ORDER BY CONFIDENCE DESC, UPDATED_AT DESC
            LIMIT {limit}
            """

            rows = self._session.sql(query).collect()
            return [
                SemanticLearningItem(
                    learning_id=str(row["LEARNING_ID"] or ""),
                    learning_type=str(row["LEARNING_TYPE"] or ""),
                    summary=str(row["SUMMARY"] or ""),
                    confidence=float(row["CONFIDENCE"]) if row["CONFIDENCE"] else 0.7,
                    applies_to=self._parse_string_list(row["APPLIES_TO"]),
                    correct_interpretation=row["CORRECT_INTERPRETATION"],
                    incorrect_interpretation=row["INCORRECT_INTERPRETATION"],
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get semantic learnings: %s", exc)
            return []

    def _get_or_infer_mapping_intent(
        self,
        project_id: str,
        target_table: str,
        source_tables: list[str],
        provided_intent: dict[str, Any] | None,
    ) -> MappingIntentItem | None:
        """Get existing mapping intent or infer from context."""
        if provided_intent:
            return MappingIntentItem(
                intent_id=provided_intent.get("intent_id", ""),
                business_goal=provided_intent.get("business_goal", ""),
                target_outcome=provided_intent.get("target_outcome", ""),
                lifecycle=provided_intent.get("lifecycle", "initial"),
                domain_hints=provided_intent.get("domain_hints", []),
                captured_from=provided_intent.get("captured_from", "user_response"),
                confidence=float(provided_intent.get("confidence", 0.8)),
            )

        try:
            query = f"""
            SELECT
                INTENT_ID as intent_id,
                BUSINESS_GOAL as business_goal,
                TARGET_OUTCOME as target_outcome,
                COALESCE(ATTRIBUTES:lifecycle::STRING, 'initial') as lifecycle,
                COALESCE(ATTRIBUTES:domain_hints, ARRAY_CONSTRUCT()) as domain_hints,
                COALESCE(SOURCE, 'inferred') as captured_from,
                COALESCE(CONFIDENCE, 0.7) as confidence
            FROM {self._settings.qualify_table_name(self._settings.snowflake_mapping_intents_table)}
            WHERE PROJECT_ID = '{project_id}'
              AND TARGET_TABLE = '{target_table}'
            ORDER BY UPDATED_AT DESC
            LIMIT 1
            """

            rows = self._session.sql(query).collect()
            if rows:
                row = rows[0]
                return MappingIntentItem(
                    intent_id=str(row["INTENT_ID"] or ""),
                    business_goal=str(row["BUSINESS_GOAL"] or ""),
                    target_outcome=str(row["TARGET_OUTCOME"] or ""),
                    lifecycle=str(row["LIFECYCLE"] or "initial"),
                    domain_hints=self._parse_string_list(row["DOMAIN_HINTS"]),
                    captured_from=str(row["CAPTURED_FROM"] or "inferred"),
                    confidence=float(row["CONFIDENCE"]) if row["CONFIDENCE"] else 0.7,
                )
        except Exception as exc:
            logger.debug("Failed to get mapping intent: %s", exc)

        return None

    def _get_project_context(
        self,
        project_id: str,
        source_tables: list[str],
        sttm_id: str | None = None,
    ) -> ProjectContextItem | None:
        """Build project context including stats, common patterns, and STTM details."""
        try:
            query = f"""
            SELECT
                p.PROJECT_ID as project_id,
                p.PROJECT_NAME as project_name,
                p.DESCRIPTION as project_description,
                COUNT(DISTINCT s.STTM_ID) as sttm_count,
                COUNT(DISTINCT CASE WHEN s.STATUS = 'published' THEN s.STTM_ID END) as published_count
            FROM {self._settings.qualify_table_name('TBL_PROJECTS')} p
            LEFT JOIN {self._settings.qualify_table_name('TBL_STTM')} s ON p.PROJECT_ID = s.PROJECT_ID
            WHERE p.PROJECT_ID = '{project_id}'
            GROUP BY p.PROJECT_ID, p.PROJECT_NAME, p.DESCRIPTION
            """

            rows = self._session.sql(query).collect()
            if not rows:
                return None

            row = rows[0]
            context = ProjectContextItem(
                project_id=str(row["PROJECT_ID"] or ""),
                project_name=str(row["PROJECT_NAME"] or ""),
                project_description=str(row["PROJECT_DESCRIPTION"] or "") if row["PROJECT_DESCRIPTION"] else None,
                domain=str(row["PROJECT_DESCRIPTION"] or "") if row["PROJECT_DESCRIPTION"] else None,
                sttm_count=int(row["STTM_COUNT"]) if row["STTM_COUNT"] else 0,
                published_count=int(row["PUBLISHED_COUNT"]) if row["PUBLISHED_COUNT"] else 0,
                common_patterns=[],
                common_source_tables=source_tables[:5],
                related_sttms=[],
            )

            # Fetch STTM details if sttm_id is provided
            if sttm_id:
                sttm_query = f"""
                SELECT
                    STTM_ID,
                    STTM_NAME,
                    DESCRIPTION,
                    STATUS
                FROM {self._settings.qualify_table_name('TBL_STTM')}
                WHERE STTM_ID = '{sttm_id}'
                LIMIT 1
                """
                sttm_rows = self._session.sql(sttm_query).collect()
                if sttm_rows:
                    sttm_row = sttm_rows[0]
                    context.sttm_id = str(sttm_row["STTM_ID"] or "")
                    context.sttm_name = str(sttm_row["STTM_NAME"] or "") if sttm_row["STTM_NAME"] else None
                    context.sttm_description = str(sttm_row["DESCRIPTION"] or "") if sttm_row["DESCRIPTION"] else None
                    context.sttm_status = str(sttm_row["STATUS"] or "") if sttm_row["STATUS"] else None

            return context
        except Exception as exc:
            logger.debug("Failed to get project context: %s", exc)

        return None

    def _get_cross_project_patterns(
        self,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        limit: int = 5,
    ) -> list[CrossProjectPatternItem]:
        """Find reusable patterns from other projects."""
        try:
            target_cols_list = ", ".join(f"'{col}'" for col in target_columns) if target_columns else "''"

            query = f"""
            SELECT
                INFERENCE_ID as pattern_id,
                INFERENCE_TYPE as pattern_type,
                SUMMARY as description,
                ATTRIBUTES as example_mapping,
                ARRAY_CONSTRUCT(ATTRIBUTES:project_id::STRING) as source_projects,
                1 as usage_count,
                COALESCE(CONFIDENCE, 0.8) as avg_confidence,
                ATTRIBUTES:reusability::STRING = 'highly_reusable' as is_recommended
            FROM {self._settings.qualify_table_name(self._settings.snowflake_assistant_inferences_table)}
            WHERE STATUS = 'active'
              AND INFERENCE_TYPE IN ('mapping_acceptance_learning', 'sttm_publish_learning')
              AND ATTRIBUTES:reusability::STRING IN ('highly_reusable', 'table_specific')
              AND ATTRIBUTES:target_column::STRING IN ({target_cols_list})
            ORDER BY avg_confidence DESC
            LIMIT {limit}
            """

            rows = self._session.sql(query).collect()
            return [
                CrossProjectPatternItem(
                    pattern_id=str(row["PATTERN_ID"] or ""),
                    pattern_type=str(row["PATTERN_TYPE"] or "mapping_pattern"),
                    description=str(row["DESCRIPTION"] or ""),
                    example_mapping=self._parse_json(row["EXAMPLE_MAPPING"]) or {},
                    source_projects=self._parse_string_list(row["SOURCE_PROJECTS"]),
                    usage_count=int(row["USAGE_COUNT"]) if row["USAGE_COUNT"] else 1,
                    avg_confidence=float(row["AVG_CONFIDENCE"]) if row["AVG_CONFIDENCE"] else 0.8,
                    is_recommended=bool(row["IS_RECOMMENDED"]),
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get cross-project patterns: %s", exc)
            return []

    def _get_correction_history(
        self,
        project_id: str,
        target_columns: list[str],
        limit: int = 10,
    ) -> list[CorrectionHistoryItem]:
        """Get history of corrections to avoid repeating mistakes."""
        try:
            target_cols_list = ", ".join(f"'{col}'" for col in target_columns) if target_columns else "''"

            query = f"""
            SELECT
                INFERENCE_ID as correction_id,
                ATTRIBUTES:target_column::STRING as target_column,
                COALESCE(ATTRIBUTES:before_source_columns, ARRAY_CONSTRUCT()) as incorrect_source,
                COALESCE(ATTRIBUTES:after_source_columns, ARRAY_CONSTRUCT()) as correct_source,
                COALESCE(ATTRIBUTES:error_category::STRING, 'unknown') as error_category,
                COALESCE(ATTRIBUTES:prevention_hint::STRING, '') as prevention_hint,
                1 as correction_count
            FROM {self._settings.qualify_table_name(self._settings.snowflake_assistant_inferences_table)}
            WHERE INFERENCE_TYPE = 'mapping_edit_learning'
              AND ATTRIBUTES:was_correction::BOOLEAN = TRUE
              AND (
                  ATTRIBUTES:project_id::STRING = '{project_id}'
                  OR ATTRIBUTES:target_column::STRING IN ({target_cols_list})
              )
            ORDER BY CREATED_AT DESC
            LIMIT {limit}
            """

            rows = self._session.sql(query).collect()
            return [
                CorrectionHistoryItem(
                    correction_id=str(row["CORRECTION_ID"] or ""),
                    target_column=str(row["TARGET_COLUMN"] or ""),
                    incorrect_source=self._parse_string_list(row["INCORRECT_SOURCE"]),
                    correct_source=self._parse_string_list(row["CORRECT_SOURCE"]),
                    error_category=str(row["ERROR_CATEGORY"] or "unknown"),
                    prevention_hint=str(row["PREVENTION_HINT"] or ""),
                    correction_count=int(row["CORRECTION_COUNT"]) if row["CORRECTION_COUNT"] else 1,
                )
                for row in rows
            ]
        except Exception as exc:
            logger.debug("Failed to get correction history: %s", exc)
            return []

    def _parse_source_columns(self, value: Any) -> list[str]:
        """Parse source columns from various formats."""
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value if v]
        if isinstance(value, str):
            try:
                import json
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return [str(v) for v in parsed if v]
            except Exception:
                pass
            return [value] if value else []
        return []

    def _parse_string_list(self, value: Any) -> list[str]:
        """Parse a string list from various formats."""
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value if v]
        if isinstance(value, str):
            try:
                import json
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return [str(v) for v in parsed if v]
            except Exception:
                pass
            return [value] if value else []
        return []

    def _parse_json(self, value: Any) -> dict[str, Any] | None:
        """Parse JSON from various formats."""
        if value is None:
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            try:
                import json
                return json.loads(value)
            except Exception:
                pass
        return None

    # ─── Agent-Specific Learning Integration ───────────────────────────

    def get_agent_learnings(
        self,
        agent_type: str,
        query_context: dict[str, Any],
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Retrieve relevant learnings for a specific agent using Cortex Search.

        This is a convenience wrapper around AgentLearningService.

        Args:
            agent_type: The agent type (SOURCE_MAPPING, TRANSFORMATION_RULE, etc.)
            query_context: Context containing target_columns, source_tables, etc.
            max_results: Maximum number of learnings to return

        Returns:
            List of AgentLearning objects sorted by relevance
        """
        return self._agent_learning_service.get_agent_learnings(
            agent_type, query_context, max_results
        )

    def get_source_mapping_learnings(
        self,
        target_columns: list[str],
        source_tables: list[str],
        project_id: str | None = None,
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Get learnings specific to source mapping operations.

        Combines:
        - Similar mappings from past acceptances
        - Corrections to avoid
        - Transformation patterns
        """
        query_context = {
            "target_columns": target_columns,
            "source_tables": source_tables,
        }
        if project_id:
            query_context["project_id"] = project_id

        learnings = self._agent_learning_service.get_agent_learnings(
            "SOURCE_MAPPING", query_context, max_results
        )

        correction_learnings = self._agent_learning_service.get_correction_history(
            "SOURCE_MAPPING", target_columns, max_results=5
        )

        all_learnings = learnings + correction_learnings
        seen_ids = set()
        deduped = []
        for learning in all_learnings:
            if learning.learning_id not in seen_ids:
                seen_ids.add(learning.learning_id)
                deduped.append(learning)

        return sorted(deduped, key=lambda x: -x.confidence)[:max_results]

    def get_transformation_learnings(
        self,
        target_columns: list[str],
        rule_types: list[str] | None = None,
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Get learnings specific to transformation rules.

        Useful for AGT_TRANSFORMATION_RULE to suggest preprocessing patterns.
        """
        query_context = {
            "target_columns": target_columns,
        }
        if rule_types:
            query_context["rule_types"] = rule_types

        return self._agent_learning_service.get_agent_learnings(
            "TRANSFORMATION_RULE", query_context, max_results
        )

    def record_mapping_acceptance(
        self,
        target_column: str,
        source_columns: list[str],
        preprocessing_rule: str,
        preprocessing_rule_type: str,
        confidence_score: float,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
    ) -> str:
        """Record a mapping acceptance for future learning."""
        return self._agent_learning_service.record_mapping_acceptance(
            target_column=target_column,
            source_columns=source_columns,
            preprocessing_rule=preprocessing_rule,
            preprocessing_rule_type=preprocessing_rule_type,
            confidence_score=confidence_score,
            project_id=project_id,
            sttm_id=sttm_id,
            user_id=user_id,
        )

    def record_mapping_correction(
        self,
        target_column: str,
        incorrect_source: list[str],
        correct_source: list[str],
        error_category: str,
        prevention_hint: str,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
    ) -> str:
        """Record a mapping correction to avoid repeating mistakes."""
        return self._agent_learning_service.record_mapping_correction(
            target_column=target_column,
            incorrect_source=incorrect_source,
            correct_source=correct_source,
            error_category=error_category,
            prevention_hint=prevention_hint,
            project_id=project_id,
            sttm_id=sttm_id,
            user_id=user_id,
        )

    def record_transformation_pattern(
        self,
        rule_type: str,
        rule_expression: str,
        description: str,
        source_columns: list[str],
        target_column: str,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
    ) -> str:
        """Record a transformation pattern for future suggestions."""
        return self._agent_learning_service.record_transformation_pattern(
            rule_type=rule_type,
            rule_expression=rule_expression,
            description=description,
            source_columns=source_columns,
            target_column=target_column,
            project_id=project_id,
            sttm_id=sttm_id,
            user_id=user_id,
        )

    def track_learning_usage(
        self,
        learning_id: str,
        was_successful: bool = True,
    ) -> None:
        """Track that a learning was used and whether it was successful."""
        self._agent_learning_service.track_learning_usage(learning_id, was_successful)

    def _get_fir_recommendations_for_context(
        self,
        project_id: str,
        source_tables: list[str],
        target_table: str,
        target_columns: list[str],
        context_key: str | None = None,
        source_set_hash: str | None = None,
        derived_set_hash: str | None = None,
        milestone: str | None = None,
        target_agent: str = "AGT_SOURCE_MAPPING",
    ) -> list[dict[str, Any]]:
        """Fetch pre-computed FIR recommendations relevant to the current mapping context.

        Queries for multiple agent types/triggers to give agents a full picture
        of available pre-computed recommendations for the selected tables.
        """
        all_tables = list(source_tables)
        if target_table:
            all_tables.append(target_table)
        if not all_tables:
            return []

        trigger_type = (
            milestone
            or ("before_auto_map" if target_table else "selection_changed")
        )
        context = {
            "project_id": project_id,
            "table_names": all_tables,
            "column_names": target_columns,
            "context_key": context_key,
            "source_set_hash": source_set_hash,
            "target_fqn": target_table,
            "derived_set_hash": derived_set_hash,
            "milestone": milestone,
        }

        results = self.get_fir_recommendations(
            agent_type=target_agent,
            trigger_type=trigger_type,
            context=context,
            max_results=15,
        )
        if not results:
            from app.core.conversation_memory import ConversationMemoryService

            memory = ConversationMemoryService(self._session, self._settings)
            fallback = memory.find_fir_recommendations_for_context(
                selected_tables=source_tables,
                target_table=target_table or None,
                project_id=project_id or None,
                context_key=context_key,
                source_set_hash=source_set_hash,
                derived_set_hash=derived_set_hash,
                milestone=trigger_type,
                target_agent=target_agent,
                allow_search_fallback=True,
                limit=15,
            )
            results = [
                {
                    "source": "fir_system",
                    "recommendation_id": item.get("recommendation_id"),
                    "type": item.get("recommendation_type"),
                    "category": item.get("recommendation_category"),
                    "priority": item.get("recommendation_priority"),
                    "score": item.get("recommendation_priority"),
                    "confidence": item.get("confidence"),
                    "context_key": item.get("context_key"),
                    "question_id": item.get("question_id"),
                    "evidence_ids": item.get("evidence_ids") or [],
                    "evidence_summary": item.get("evidence_summary"),
                    "payload": item.get("agent_payload") or {},
                    "retrieval_mode": item.get("retrieval_mode"),
                    "usage_stats": {"used": 0, "successful": 0},
                }
                for item in fallback
            ]

        results.sort(key=lambda r: r.get("score", r.get("priority", 0)), reverse=True)
        return results[:15]

    # ─── FIR System Integration ────────────────────────────────────────

    def get_fir_recommendations(
        self,
        agent_type: str,
        trigger_type: str,
        context: dict[str, Any],
        max_results: int = 10,
    ) -> list[dict[str, Any]]:
        """Retrieve FIR System recommendations for an agent.

        Calls SP_FIR_GET_AGENT_RECOMMENDATIONS to fetch pre-formatted
        recommendations from the FIR batch processing system.

        Args:
            agent_type: Target agent (SOURCE_MAPPING, TRANSFORMATION_RULE, STTM_BUILDER)
            trigger_type: Trigger event (on_mapping_start, on_source_selection, etc.)
            context: Context with project_id, table_names, column_names, sttm_id, etc.
            max_results: Maximum recommendations to return

        Returns:
            List of recommendation payloads formatted for learning_context injection.
            Each recommendation has:
            - source: 'fir_system'
            - recommendation_id: Unique ID for tracking
            - type: Recommendation type (pattern_reuse, correction_warning, etc.)
            - priority: 1-100 priority score
            - confidence: Confidence score
            - payload: Agent-specific formatted data
            - usage_stats: {used: int, successful: int}
        """
        try:
            agent_name = f"AGT_{agent_type}" if not agent_type.startswith("AGT_") else agent_type
            context_with_max = {**context, "max_results": max_results}

            proc_name = self._settings.qualify_metadata_object_name(
                "SP_FIR_GET_AGENT_RECOMMENDATIONS"
            )
            result = self._session.call(
                proc_name,
                agent_name,
                trigger_type,
                context_with_max,
            )

            if isinstance(result, str):
                import json
                result = json.loads(result)

            if result.get("status") == "success":
                recommendations = result.get("recommendations", [])
                retrieval_mode = result.get("retrieval_mode")
                for recommendation in recommendations:
                    recommendation["retrieval_mode"] = retrieval_mode
                return recommendations[:max_results]
            else:
                logger.warning(
                    "FIR recommendations retrieval failed: %s",
                    result.get("errors", []),
                )
                return []

        except Exception as exc:
            logger.warning("Failed to get FIR recommendations: %s", exc)
            return []

    def get_semantic_version_learnings(
        self,
        table_fqns: list[str],
        limit: int = 3,
    ) -> list[dict[str, Any]]:
        """Retrieve curated semantic version learnings for the given tables.

        Queries TBL_SEMANTIC_VIEW_VERSIONS for the latest curated version of each
        relevant table's semantic view. Returns BUSINESS_GLOSSARY, RELATIONSHIP_RULES,
        TRANSFORMATION_PATTERNS, COLUMN_SEMANTICS, and QA_PAIRS.
        """
        if not table_fqns:
            return []
        try:
            fqn_list = ", ".join(f"'{fqn}'" for fqn in table_fqns)
            rows = self._session.sql(f"""
                SELECT
                    SEMANTIC_VIEW_FQN,
                    VERSION_LABEL,
                    VERSION_NUMBER,
                    BUSINESS_GLOSSARY,
                    RELATIONSHIP_RULES,
                    TRANSFORMATION_PATTERNS,
                    COLUMN_SEMANTICS,
                    QA_PAIRS,
                    CONFIDENCE
                FROM TBL_SEMANTIC_VIEW_VERSIONS
                WHERE SEMANTIC_VIEW_FQN IN ({fqn_list})
                  AND VALIDATION_STATUS != 'rejected'
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY SEMANTIC_VIEW_FQN
                    ORDER BY VERSION_NUMBER DESC
                ) = 1
                LIMIT {limit}
            """).collect()

            results = []
            for row in rows:
                row_dict = row.as_dict() if hasattr(row, "as_dict") else row
                results.append({
                    "fqn": row_dict.get("SEMANTIC_VIEW_FQN"),
                    "version_label": row_dict.get("VERSION_LABEL"),
                    "version_number": row_dict.get("VERSION_NUMBER"),
                    "business_glossary": row_dict.get("BUSINESS_GLOSSARY"),
                    "relationship_rules": row_dict.get("RELATIONSHIP_RULES"),
                    "transformation_patterns": row_dict.get("TRANSFORMATION_PATTERNS"),
                    "column_semantics": row_dict.get("COLUMN_SEMANTICS"),
                    "qa_pairs": row_dict.get("QA_PAIRS"),
                    "confidence": row_dict.get("CONFIDENCE"),
                })
            return results
        except Exception as exc:
            logger.debug("Failed to get semantic version learnings: %s", exc)
            return []

    def record_fir_recommendation_success(
        self,
        recommendation_id: str,
    ) -> bool:
        """Record that a FIR recommendation was successfully used.

        Called when a user accepts a suggestion that was based on a FIR recommendation.
        This updates the success_count for the recommendation, which influences
        confidence scoring and future recommendation priority.

        Args:
            recommendation_id: The AGENT_RECOMMENDATION_ID from the FIR system

        Returns:
            True if recording succeeded, False otherwise
        """
        try:
            proc_name = self._settings.qualify_metadata_object_name(
                "SP_FIR_RECORD_RECOMMENDATION_SUCCESS"
            )
            self._session.call(proc_name, recommendation_id)
            return True
        except Exception as exc:
            logger.warning("Failed to record FIR recommendation success: %s", exc)
            return False
