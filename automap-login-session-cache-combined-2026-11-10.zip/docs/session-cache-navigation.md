# Session-wide cache retention and navigation — 10 November 2026

Cached data remains available for the verified app session. Five minutes is a background refresh interval, not a deadline that removes data or blocks navigation. Logout, confirmed session expiry, user/role changes and explicit invalidation still clear the appropriate caches. The initial page load verifies the browser identity before using scoped storage; the backend continues authorizing every API request.

## Implemented

- Verified identity is returned immediately after the background refresh interval, with one deduplicated refresh. Transient failures keep cached data and use a short retry delay. Confirmed 401 clears identity and cached reads, hides protected screens and uses the existing sign-in flow. Auth-session 403 remains a permission denial. A late 401 from an old session cannot end a newer session.
- User ID, app persona and Snowflake role remain part of the cache scope. Another tab's identity change invalidates this tab and reloads its verified state without deleting the new identity written by the other tab.
- Dashboard, Projects, all mappings and project detail initialize from available cached summaries. Restored project-list storage also starts background refresh when stale. Temporary refresh failures do not discard already loaded values.
- Autosaves containing only mapping-definition changes retain the summary objects and do not cancel a valid pending aggregate refresh. Changes to draft state, mapping counts, coverage or semantic bundle fields patch the affected mapping/project entries and fence older aggregate responses. Other mapping-detail reads remain intact.
- Project/mapping creation and publication mark list summaries stale without discarding unrelated opened mapping snapshots. Publication invalidates its own detail. A background summary that reports a newer mapping snapshot invalidates only that detail, and cannot discard a local save completed while the aggregate request was in flight.
- Selection, Mapping and Summary of an active saved or unsaved workspace retain edits, columns and metadata without toggling hydration off or waiting for a session request. Explicit new/upload intents are still consumed normally. Existing source/target metadata caches remain session-scoped; changed dependency keys and explicit refresh keep their established invalidation behavior.
- Mapping-detail storage already used `Date.now() + TTL`; that absolute deadline is retained and regression-tested for reads and autosaves. Cached details remain usable during the session; they are not discarded solely because that freshness timestamp is old.

An explicit reopen of another saved workspace still resolves the authoritative durable snapshot so completed assistant turns, published versions and logical conversation identity are not replaced by stale browser state. Normal step navigation within the active workspace does not perform that reopen. Explicit Refresh continues to reload data. The change does not cache writes, validation results under another definition, or model calls.

No UI styling, fonts, backend authorization rules, environment files or client account settings changed.

## Verification

All 33 frontend regression scripts and TypeScript pass. Added/extended checks cover long-lived identity and data caches, restored stale project lists, background refresh/outages, request deduplication, autosave summary deltas, absolute detail timestamps, stale aggregate/save races, saved and unsaved step navigation, explicit new/upload handling, initial cached list rendering, same-user role changes, cross-tab identity changes and old-session 401 fencing. Existing mapping, assistant continuity, upload and persistence assertions remain intact, including the 34 persistence regressions.

These are deterministic frontend/service tests; client browser/SPCS network timing is not inferred from them. No backend code changed in this follow-up.
