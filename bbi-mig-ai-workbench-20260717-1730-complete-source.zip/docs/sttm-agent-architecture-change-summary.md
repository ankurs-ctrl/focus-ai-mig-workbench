# STTM agent architecture change summary

## Problems reported

The workbench had several related production issues after moving deeper agent
workflows into SPCS:

1. Snowflake OAuth worked locally but failed in SPCS with `invalid_client`.
2. Cortex Agent REST calls from inside SPCS returned Snowflake `401/395090`
   because they were using the SPCS caller/connector context instead of the
   signed-in user OAuth bearer token expected by Cortex Agent REST.
3. The assistant had two product-facing orchestrators:
   `AGT_WORKBENCH_CONVERSATION` and `AGT_STTM_BUILDER`, which made routing,
   context, and memory inconsistent.
4. Semantic context was being refreshed/generated/promoted during chat and
   Auto-map paths, making requests slow and fragile.
5. Multi-table Analyst requests failed because Analyst needs one composed model;
   multiple independent semantic views make it choose one rather than reason over
   the whole source/target set.
6. Mapping-page chat did not reliably receive checked rows, mapping confidence,
   confidence reasons, current rules, or Auto-map artifacts.
7. Auto-map eventually worked but still needed deterministic batching,
   per-batch/progress records, and stored reasoning for follow-up questions.
8. SQL validation lost semantic context and sometimes blocked preview.
9. CoCo initially failed because its SDK subprocess transport hit a Python
   `uvloop` incompatibility: `unexpected kwargs: user`.
10. Client deployment scripts still assumed the older single-service /
    two-orchestrator setup.

## Main fixes made

### OAuth and SPCS

- Kept layered user OAuth because Cortex Agent REST expects normal OAuth bearer
  auth, not the SPCS caller token.
- Enabled SPCS custom credentials when `AUTH_MODE=custom_oauth`.
- Moved OAuth client id/secret and session keys to Snowflake password secrets.
- Removed fallback form-body OAuth credential retry; Snowflake OAuth should use
  HTTP Basic client authentication.
- Sanitized OAuth errors into the standard envelope.
- Preserved Snowflake runtime account/host behavior inside SPCS.

### Unified assistant orchestration

- Made `AGT_STTM_BUILDER` the single product-facing assistant orchestrator.
- Kept conversation endpoints as compatibility facades.
- Added deterministic backend routing hints so the Builder receives a narrower
  task instead of exploring every tool for simple messages.
- Moved normal chat away from `AGT_WORKBENCH_CONVERSATION`.
- Updated client deployment defaults so `SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT`
  is optional and defaults to `AGT_STTM_BUILDER`.
- Removed invalid external Snowflake skill references from
  `agent_spec_sttm_builder.yaml`; those caused Cortex Agent HTTP 400 /
  `399504` when the client/account did not have the named skills.

### Semantic registry and bundles

- Treated the workbench registry as the source of truth:
  `SEM_TABLE_VIEWS`, `SEM_COLUMN_VIEWS`, `TBL_SEMANTIC_MODELS`, and bundle
  tables.
- Kept `AGT_SEMANTIC_MODEL_V2` outside the app request path.
- Added/used semantic bundle references in workspace context.
- Fixed the backend to accept multi-table inline composed semantic YAML bundles
  even when there is no physical single semantic view name.
- Stopped request-time semantic generation/freshness/promotion logic.

### Context and memory

- Introduced a canonical workspace snapshot shape for selected sources, target,
  driving table, derived sources, relationships, selected/checked mapping rows,
  mapping artifacts, semantic bundle refs, and current SQL.
- Added assistant context indicators and payload fields so the user can verify
  what is attached to the next prompt.
- Persisted Auto-map output details so later questions such as “why is
  confidence low?” can be answered from actual mapping evidence.

### Auto-map

- Moved Auto-map to a dedicated private worker service.
- Forwarded signed-in user OAuth through private worker auth.
- Split target attributes into deterministic batches with at most two in flight
  to use the two worker instances.
- Stored confidence, confidence reasons, alternatives, rule suggestions, bundle
  hash, and request/query identifiers for each mapping result.
- Added status/progress events and job/result polling.

### CoCo deep agent

- Added CoCo as explicit admin deep-agent mode, not the default assistant.
- Proxied CoCo through same-origin WebSocket.
- Added diagnostics and runtime isolation.
- Preserved permission behavior instead of bypassing permissions.
- Fixed the runtime path so CoCo can start and respond.

### Performance

- Emitted stream status earlier.
- Added timing/cache instrumentation.
- Added catalog/relationship/semantic cache paths.
- Avoided heavy semantic validation and Snowflake `DESCRIBE SEMANTIC VIEW` work
  on every chat request.
- Split lightweight endpoints from heavy agent/semantic dependencies where
  possible.

## Latest normal-chat fix

The most recent normal-chat failure came from the deployed `AGT_STTM_BUILDER`
spec referencing non-existent Snowflake skills:

- `sttm_bundle_orchestration`
- `derived_source_analyst`

Snowflake returned Cortex Agent HTTP 400 / code `399504`. The agent spec now
keeps the behavior in prompt/tool routing and no longer requires those external
skills, making it portable to client environments.

## Latest semantic-bundle fix

The latest derived-source failure showed `SEMANTIC_BUNDLE_NOT_READY` even when
the UI displayed a ready Analyst bundle. The backend was requiring a physical
`semantic_view_name`, but multi-table bundles are represented as inline composed
YAML. The resolver now:

- accepts a bundle id with inline `semantic_model_yaml`;
- returns the bundle id even when no physical semantic view exists;
- reuses prefetched semantic context for inline bundles.

## What remains environment-dependent

- Client IT must register the final SPCS callback URL in the OAuth integration.
- Client IT must grant required source/target data access.
- Client IT must grant `CALLER MODIFY` where restricted caller-rights procedures
  write metadata, especially derived sources.
- Agent quality/performance depends on the deployed Cortex model, warehouse,
  compute pool size, and Snowflake service cold-start behavior.
- `AGT_SEMANTIC_MODEL_V2`/scheduled semantic generation must populate the
  registry before chat, Analyst, Auto-map, and validation can use table assets.
