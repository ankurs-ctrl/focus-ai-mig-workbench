'use client';

import { useEffect, useMemo, useRef, useState, type MouseEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AiaBadge, AiaBox } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { AiaResizeHandle } from '@/components/ui/aia-resize-handle';
import {
    AI_CHAT_RAIL_COLLAPSED_WIDTH,
    AI_CHAT_RAIL_COLOR,
    AI_CHAT_RAIL_DRAG_WIDTH,
    AI_CHAT_RAIL_EXPANDED_WIDTH,
    AI_CHAT_RAIL_HEIGHT,
    AI_CHAT_SHELL_Z_INDEX,
} from '@/features/ai-agent/ai-chat-layout-constants';
import { useAiChatLayout } from '@/features/ai-agent/ai-chat-layout-context';
import AIAgentPanel from '@/features/ai-agent/ai-agent-panel';
import { AiChatHistoryPanel } from '@/features/ai-agent/ai-chat-history-panel';
import { AiChatProjectHistory } from '@/features/ai-agent/ai-chat-project-history';
import type { StoredChatSession } from '@/features/ai-agent/ai-chat-session-utils';
import { AiChatNotificationsPanel } from '@/features/ai-agent/ai-chat-notifications-panel';
import { AiChatSidebarHeader } from '@/features/ai-agent/ai-chat-sidebar-header';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { AddRoundedIcon, AutoAwesomeRoundedIcon } from '@/utils/icons';
import { listProjects, type ProjectRecord } from '@/services/projectService';

function RailDragDots() {
    return (
        <AiaBox
            sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 4px)',
                gap: '3px',
                px: 0.5,
            }}
        >
            {Array.from({ length: 6 }).map((_, index) => (
                <AiaBox
                    key={index}
                    sx={{
                        width: 4,
                        height: 4,
                        borderRadius: '50%',
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    }}
                />
            ))}
        </AiaBox>
    );
}

export function AiChatRailTab() {
    const {
        railTop,
        openChat,
        beginRailDrag,
        beginRailTouchDrag,
        resolvedRecommendationIds,
    } = useAiChatLayout();
    const { firRecommendations, firPrimaryQuestion } = useSttmBuilderContext();
    const [railHovered, setRailHovered] = useState(false);
    const isRailExpanded = railHovered;
    const notificationCount = useMemo(() => {
        const ids = new Set(
            firRecommendations
                .filter((item) => !resolvedRecommendationIds.has(item.recommendation_id))
                .map((item) => item.recommendation_id),
        );
        if (
            firPrimaryQuestion
            && !resolvedRecommendationIds.has(firPrimaryQuestion.recommendation_id)
        ) {
            ids.add(firPrimaryQuestion.recommendation_id);
        }
        return ids.size;
    }, [firPrimaryQuestion, firRecommendations, resolvedRecommendationIds]);

    const handleOpen = (event: MouseEvent) => {
        event.preventDefault();
        event.stopPropagation();
        openChat();
    };

    return (
        <AiaBox
            onMouseEnter={() => setRailHovered(true)}
            onMouseLeave={() => setRailHovered(false)}
            sx={{
                position: 'absolute',
                top: railTop,
                right: 0,
                zIndex: AI_CHAT_SHELL_Z_INDEX,
                display: 'flex',
                alignItems: 'stretch',
                width: isRailExpanded ? AI_CHAT_RAIL_EXPANDED_WIDTH : AI_CHAT_RAIL_COLLAPSED_WIDTH,
                height: AI_CHAT_RAIL_HEIGHT,
                borderTopLeftRadius: '10px',
                borderBottomLeftRadius: '10px',
                overflow: 'hidden',
                boxShadow: '-4px 0 16px rgba(0, 0, 0, 0.16)',
                backgroundColor: AI_CHAT_RAIL_COLOR,
                color: '#ffffff',
                pointerEvents: 'auto',
                transition: 'width 180ms ease, box-shadow 180ms ease',
                ...(isRailExpanded
                    ? {
                          boxShadow: '-6px 0 20px rgba(0, 0, 0, 0.2)',
                      }
                    : {}),
            }}
        >
            <AiaBox
                onMouseDown={beginRailDrag}
                onTouchStart={beginRailTouchDrag}
                title="Drag to move"
                aria-hidden={!isRailExpanded}
                sx={{
                    width: isRailExpanded ? AI_CHAT_RAIL_DRAG_WIDTH : 0,
                    opacity: isRailExpanded ? 1 : 0,
                    overflow: 'hidden',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: isRailExpanded ? 'grab' : 'default',
                    flexShrink: 0,
                    touchAction: 'none',
                    pointerEvents: isRailExpanded ? 'auto' : 'none',
                    transition: 'width 180ms ease, opacity 150ms ease',
                    '&:active': { cursor: 'grabbing' },
                }}
            >
                <RailDragDots />
            </AiaBox>
            <AiaBox
                data-tour={TOUR_TARGETS.sttmAiAssistant}
                component="button"
                type="button"
                aria-label="Open AI Assistant"
                title="Open AI Assistant"
                onClick={handleOpen}
                sx={{
                    flex: 1,
                    minWidth: 0,
                    border: 'none',
                    cursor: 'pointer',
                    p: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: 'transparent',
                    color: 'inherit',
                    pointerEvents: 'auto',
                    '&:hover': {
                        filter: 'brightness(1.05)',
                    },
                }}
            >
                <AiaBadge
                    color="error"
                    badgeContent={notificationCount || null}
                    anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
                    sx={{ pointerEvents: 'none', '& .MuiBadge-badge': { left: 2, top: 2 } }}
                >
                    <AutoAwesomeRoundedIcon sx={{ fontSize: 22, pointerEvents: 'none' }} />
                </AiaBadge>
            </AiaBox>
        </AiaBox>
    );
}

export function AiChatSidebarPanel({ pageMode = false }: { pageMode?: boolean }) {
    const router = useRouter();
    const {
        panelView,
        historySearch,
        sessions,
        activeSessionId,
        resolvedRecommendationIds,
        effectiveSidebarWidth,
        isFullscreen,
        isResizing,
        isMobile,
        isTablet,
        setHistorySearch,
        setPanelView,
        closeChat,
        handleNewChat,
        handleShowHistory,
        handleShowNotifications,
        handleSelectRecommendation,
        handleSelectSession,
        handleDeleteSession,
        handleUpdateSession,
        beginSidebarResize,
        agentPageProjectId,
        setAgentPageProjectId,
    } = useAiChatLayout();
    const { firRecommendations, firPrimaryQuestion, activeProjectId, activeProjectName, activeSttmId, activeSttmName, setActiveProjectIdentity } = useSttmBuilderContext();
    const [projects, setProjects] = useState<ProjectRecord[]>([]);
    const priorIdentity = useRef<{ projectId: string | null; projectName: string | null; sttmId: string | null; sttmName: string | null } | null>(null);
    const selectedProjectId = agentPageProjectId ?? activeProjectId ?? 'general';

    useEffect(() => {
        if (!pageMode) return;
        priorIdentity.current = { projectId: activeProjectId, projectName: activeProjectName, sttmId: activeSttmId, sttmName: activeSttmName };
        setAgentPageProjectId(activeProjectId ?? 'general');
        handleShowHistory();
        setPanelView('chat');
        let cancelled = false;
        void listProjects().then((rows) => { if (!cancelled) setProjects(rows); }).catch(() => { if (!cancelled) setProjects([]); });
        return () => {
            cancelled = true;
            setAgentPageProjectId(null);
            const prior = priorIdentity.current;
            if (prior) setActiveProjectIdentity(prior);
        };
        // Route transition only: preserve the project's original context when leaving.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pageMode]);

    const selectProject = (projectId: string, createNewChat = true, sttmId: string | null = null) => {
        if (createNewChat) handleNewChat();
        setAgentPageProjectId(projectId);
        const project = projects.find((item) => item.project_id === projectId);
        setActiveProjectIdentity({ projectId: projectId === 'general' ? null : projectId, projectName: project?.project_name ?? null, sttmId });
    };

    const selectProjectSession = (session: StoredChatSession) => {
        const projectId = session.projectId ?? 'general';
        if (projectId !== selectedProjectId || session.sttmId !== activeSttmId) selectProject(projectId, false, session.sttmId ?? null);
        window.setTimeout(() => handleSelectSession(session), 0);
    };
    const updateProjectSession = async (session: StoredChatSession, changes: { title?: string; projectId?: string | null; pinned?: boolean }) => {
        await handleUpdateSession(session, changes);
        if (changes.projectId !== undefined && session.id === activeSessionId) {
            selectProject(changes.projectId ?? 'general', false);
            window.setTimeout(() => handleSelectSession({
                ...session,
                ...changes,
                projectId: changes.projectId,
                sttmId: null,
            }), 0);
        }
    };
    const openRecommendations = useMemo(() => {
        const byId = new Map(
            firRecommendations
                .filter((item) => !resolvedRecommendationIds.has(item.recommendation_id))
                .map((item) => [item.recommendation_id, item]),
        );
        if (
            firPrimaryQuestion
            && !resolvedRecommendationIds.has(firPrimaryQuestion.recommendation_id)
        ) {
            byId.set(firPrimaryQuestion.recommendation_id, firPrimaryQuestion);
        }
        return Array.from(byId.values()).sort(
            (left, right) =>
                Number(right.question_id != null) - Number(left.question_id != null)
                || Number(right.recommendation_priority ?? 0)
                    - Number(left.recommendation_priority ?? 0),
        );
    }, [firPrimaryQuestion, firRecommendations, resolvedRecommendationIds]);

    return (
        <AiaBox
            component="aside"
            aria-label="STTM AI Assistant"
            sx={{
                width: pageMode ? '100%' : effectiveSidebarWidth,
                minWidth: pageMode ? 0 : effectiveSidebarWidth,
                maxWidth: '100%',
                flex: pageMode || isFullscreen ? 1 : undefined,
                flexShrink: pageMode || isFullscreen ? 1 : 0,
                height: '100%',
                minHeight: 0,
                display: 'flex',
                flexDirection: 'row',
                position: 'relative',
                zIndex: AI_CHAT_SHELL_Z_INDEX,
                transition: isResizing ? 'none' : 'width 220ms ease',
                backgroundColor: '#ffffff',
                borderLeft: pageMode || isFullscreen ? 'none' : '1px solid #e2e8f0',
                overflow: 'hidden',
            }}
        >
            {!pageMode && !isFullscreen && !isMobile && !isTablet ? (
                <AiaResizeHandle
                    direction="horizontal"
                    onMouseDown={beginSidebarResize}
                    sx={{ alignSelf: 'stretch', height: '100%', width: 6, minWidth: 6 }}
                />
            ) : null}
            {pageMode ? <AiChatProjectHistory sessions={sessions} projects={projects} selectedProjectId={selectedProjectId} activeSessionId={activeSessionId} onSelectProject={(id) => selectProject(id)} onNewProjectChat={(id) => selectProject(id)} onSelectSession={selectProjectSession} onNewChat={handleNewChat} onUpdateSession={updateProjectSession} onArchiveSession={handleDeleteSession} /> : null}
            <AiaBox
                sx={{
                    flex: 1,
                    minWidth: 0,
                    display: 'flex',
                    flexDirection: 'column',
                    backgroundColor: '#ffffff',
                }}
            >
                {pageMode ? <AiaBox sx={{ minHeight: 62, px: 2.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, borderBottom: '1px solid #e2e8f0' }}>
                    <AiaBox sx={{ minWidth: 0 }}>
                        <AiaText sx={{ fontWeight: 800, color: '#0f172a', fontSize: 17 }}>AI Agent</AiaText>
                        <AiaText sx={{ fontSize: 11, color: '#64748b', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{selectedProjectId === 'general' ? 'General · no project' : projects.find((item) => item.project_id === selectedProjectId)?.project_name || 'Project ' + selectedProjectId}</AiaText>
                    </AiaBox>
                    <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <AiaBox component="button" type="button" onClick={handleNewChat} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, border: '1px solid #dbe2ea', borderRadius: 2, px: 1.2, py: 0.7, backgroundColor: '#fff', color: '#1e293b', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}><AddRoundedIcon sx={{ fontSize: 16 }} /> New chat</AiaBox>
                        <Link href="/dashboard" style={{ color: '#475569', textDecoration: 'none', fontSize: 13, fontWeight: 600 }}>Dashboard</Link>
                    </AiaBox>
                </AiaBox> : <AiChatSidebarHeader
                    mode={panelView}
                    onOpenAgentPage={() => { closeChat(); router.push('/ai-agent'); }}
                    onNewChat={handleNewChat}
                    onShowHistory={handleShowHistory}
                    onShowNotifications={handleShowNotifications}
                    onBackToChat={() => setPanelView('chat')}
                    onClose={closeChat}
                    notificationCount={openRecommendations.length}
                    historySearch={historySearch}
                    onHistorySearchChange={setHistorySearch}
                />}
                {!pageMode && panelView === 'history' ? (
                    <AiChatHistoryPanel
                        sessions={sessions}
                        searchQuery={historySearch}
                        activeSessionId={activeSessionId}
                        onSelectSession={handleSelectSession}
                        onDeleteSession={handleDeleteSession}
                    />
                ) : !pageMode && panelView === 'notifications' ? (
                    <AiChatNotificationsPanel
                        recommendations={openRecommendations}
                        onSelectRecommendation={handleSelectRecommendation}
                    />
                ) : null}
                <AiaBox
                    sx={{
                        display: pageMode || panelView === 'chat' ? 'flex' : 'none',
                        flex: 1,
                        minHeight: 0,
                        minWidth: 0,
                    }}
                >
                    <AIAgentPanel variant="sidebar" expanded={pageMode || isFullscreen} pageMode={pageMode} />
                </AiaBox>

            </AiaBox>
        </AiaBox>
    );
}
