"""Identical private planning input for source preflight and worker dispatch.

Only server-accepted request policies are propagated; this is not an authority
constructor. Public entrypoints still select policies and validate caller scope.
"""
from app.schema.sttm_builder import STTMAgentRequestEnvelope


def source_planning_input(req):
    raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode='json', exclude_none=True)
    modern = req.meta.get('automap_packet_policy') == 'frozen-packets-v1'
    if modern:
        raw['meta'] = {key:req.meta[key] for key in ('automap_generation_policy','automap_rules_policy','automap_packet_policy') if key in req.meta}
    elif req.meta.get('automap_rules_policy') == 'rules-v2':
        # Keep old frozen-job operation identities stable. Changed projections
        # must never create a new operation key for an uncertain historical POST.
        raw['meta'] = {'automap_generation_policy':'draft-v3','automap_rules_policy':'rules-v2'}
    from app.core.automap_policy import focused_learning
    raw['context']['learning_context'] = focused_learning(raw['context'].get('learning_context') or {})
    if not modern:
        return raw
    from app.core.automap_retrieval import target_name
    names = {target_name(item['target_attribute']) for item in raw.get('data', {}).get('attributes') or []}
    def requested(name):
        return isinstance(name, str) and target_name(name) in names
    workspace = raw['context'].get('workspace_context') or {}
    if isinstance(workspace.get('mapping_rows'), list):
        workspace['mapping_rows'] = [row for row in workspace['mapping_rows'] if requested(row.get('target_column'))]
    for row in workspace.get('mapping_rows') or []:
        for field in ('ai_candidates','ai_suggestions','ai_undo_snapshot','ai_generation','validation_history'):
            row.pop(field, None)
    from app.core.mapping_context import _targets
    requested_meanings = set().union(*(_targets({'target_column':name}) for name in names)) if names else set()
    execution = raw['context'].get('execution_context') or {}
    for field in ('curated_inferences','exact_fir_recommendations','target_mapping_patterns',
                  'linked_mapping_precedents','linked_project_patterns'):
        if isinstance(execution.get(field), list):
            scoped = []
            for item in execution[field]:
                if isinstance(item, dict) and isinstance(item.get('mappings'), list):
                    selected = [row for row in item['mappings'] if requested(row.get('target_column') or row.get('target_attribute'))]
                    if selected:
                        scoped.append({**item, 'mappings': selected})
                elif not _targets(item) or _targets(item) & requested_meanings:
                    scoped.append(item)
            execution[field] = scoped
    learning = raw['context']['learning_context']
    precedents = []
    for precedent in learning.get('mapping_precedents') or []:
        if not isinstance(precedent, dict):
            continue
        mappings = precedent.get('mappings')
        if isinstance(mappings, list):
            selected = [row for row in mappings if isinstance(row, dict) and requested(row.get('target_column') or row.get('target_attribute'))]
            if selected:
                precedents.append({**precedent, 'mappings': selected})
        else:
            precedents.append(precedent)
    if 'mapping_precedents' in learning:
        learning['mapping_precedents'] = precedents
    return raw


CATALOG_VERSION = 'automap-catalog-v1'
CATALOG_FIELDS = ('tables', 'columns', 'inventory', 'contracts', 'nodes', 'node_owners',
                  'dependencies', 'aliases')


def catalog_fingerprint(context):
    from app.core.automap_retrieval import digest
    return digest({key: context.get(key) for key in ('semantic_context', 'relation_graph', 'target_table')})


def catalog_index(raw):
    """Normalize the immutable catalog once; row proposals are never indexed."""
    from copy import deepcopy
    from app.core.automap_retrieval import AutoMapContext
    payload = deepcopy(raw)
    payload['data']['attributes'] = []
    store = AutoMapContext(payload)
    return {'version': CATALOG_VERSION, 'fingerprint': catalog_fingerprint(raw['context']),
        'fields': {key: ({name: sorted(values) for name, values in store.aliases.items()}
                        if key == 'aliases' else deepcopy(getattr(store, key))) for key in CATALOG_FIELDS}}


def source_context(req, *, fast, raw=None):
    from app.core.automap_retrieval import AutoMapContext
    from app.core.automap_batch import _FastAutoMapContext
    from app.core.automap_prepared_evidence import trusted
    raw = source_planning_input(req) if raw is None else raw
    prepared = trusted(req)
    index = prepared.get('catalog_index') if prepared else None
    return (_FastAutoMapContext if fast else AutoMapContext)(raw, catalog_index=index)
