"""Caller-scoped native tool snapshots, short CAS leases and durable checkpoints.

The caller supplies an exclusive Snowpark session per operation/tool invocation.
No connection, credential, role switch, background thread or DDL is created here.
"""

from contextlib import contextmanager
from copy import deepcopy
import json
import re
import secrets
import time
from app.core.automap_native_contract import VERSION, digest, encoded, initial_state


class NativeStoreError(ValueError):
    pass


class NativeBusy(NativeStoreError):
    pass


def namespace(value):
    if type(value) is not str or not re.fullmatch(
        r"[A-Za-z_][\w$]*\.[A-Za-z_][\w$]*", value
    ):
        raise NativeStoreError("Trusted metadata namespace required")
    return value.upper()


def plain(row):
    return row.as_dict() if hasattr(row, "as_dict") else dict(row)


def affected(rows):
    if len(rows) != 1:
        return False
    values = {
        key.lower().replace("_", " "): value for key, value in plain(rows[0]).items()
    }
    # Snowflake UPDATE returns a second diagnostic count for multi-joined
    # rows. It is not an additional affected-row result. Ambiguous updates
    # still fail closed.
    return (
        values.get("number of rows updated") == 1
        and values.get("number of multi-joined rows updated", 0) == 0
    )


class NativeJobStore:
    def __init__(self, session, metadata, *, timeout=10):
        self.session = session
        self.metadata = namespace(metadata)
        self.table = self.metadata + ".TBL_AUTOMAP_NATIVE_JOBS"
        self.timeout = max(1, min(15, int(timeout)))

    def sql(self, query, params=None):
        return self.session.sql(query, params=params or []).collect(
            statement_params={
                "STATEMENT_TIMEOUT_IN_SECONDS": str(self.timeout),
                "LOCK_TIMEOUT": "1",
            }
        )

    @contextmanager
    def transaction(self):
        # Never commit a caller's transaction. Tools and parent reads use their
        # own exclusive sessions; Snowflake scoped transactions are explicit.
        rows = self.sql("SELECT CURRENT_TRANSACTION() AS TX")
        if rows and plain(rows[0]).get("TX") is not None:
            raise NativeStoreError(
                "Native operations require a transaction-free session"
            )
        self.sql("BEGIN")
        try:
            yield
            self.sql("COMMIT")
        except BaseException:
            try:
                self.sql("ROLLBACK")
            except Exception:
                pass
            raise

    def create(self, snapshot, config, *, batch_identity, deadline_at):
        handle = secrets.token_hex(32)
        # Per-batch identity is server derived; only the parent can match it to
        # its immutable request/revision. A resumed dispatcher must READ first.
        if deadline_at <= time.time():
            raise NativeStoreError("Native job deadline expired")
        config = deepcopy(config)
        identity = plain(self.sql("SELECT CURRENT_USER() AS OWNER_ID")[0])["OWNER_ID"]
        config["owner_user"] = identity
        with self.transaction():
            # Standard-table PK constraints are not enforced. Serialize only
            # registry allocation using a pre-provisioned control row; commit
            # acknowledgement precedes every possible model dispatch.
            if not affected(
                self.sql(
                    f"UPDATE {self.metadata}.TBL_AUTOMAP_NATIVE_CONTROL SET VERSION=VERSION+1 WHERE CONTROL_KEY='registry'"
                )
            ):
                raise NativeStoreError("Native registry control unavailable")
            existing = self.find(batch_identity, snapshot["snapshot_hash"])
            if existing:
                return existing
            self.sql(
                f"""INSERT INTO {self.table}
              (HANDLE,OWNER_ID,ROLE_NAME,SNAPSHOT_HASH,BATCH_IDENTITY,SNAPSHOT,CONFIG,STATE,DEADLINE_AT,CREATED_AT)
              SELECT ?,CURRENT_USER(),CURRENT_ROLE(),?,?,PARSE_JSON(?),PARSE_JSON(?),PARSE_JSON(?),TO_TIMESTAMP_LTZ(?::NUMBER(38,0),6),CURRENT_TIMESTAMP()""",
                [
                    handle,
                    snapshot["snapshot_hash"],
                    batch_identity,
                    encoded(snapshot),
                    encoded(config),
                    encoded(initial_state()),
                    int(deadline_at * 1_000_000),
                ],
            )
            documents = [
                {
                    "binding_id": source["binding_id"],
                    "document": encoded(
                        {
                            "source_ref": source["source_ref"],
                            "semantics": snapshot["records"][source["evidence_id"]][
                                "body"
                            ].get("semantics", []),
                        }
                    )[:8192],
                }
                for source in snapshot["sources"].values()
            ]
            if documents:
                self.sql(
                    f"""INSERT INTO {self.metadata}.TBL_AUTOMAP_NATIVE_SOURCE_DOCUMENTS
                  (HANDLE,OWNER_ID,PROJECT_ID,SNAPSHOT_HASH,BINDING_ID,DOCUMENT,CREATED_AT)
                  SELECT ?,CURRENT_USER(),?,?,V.VALUE:binding_id::VARCHAR,V.VALUE:document::VARCHAR,CURRENT_TIMESTAMP()
                  FROM TABLE(FLATTEN(INPUT=>PARSE_JSON(?))) V""",
                    [
                        handle,
                        str(snapshot["request"]["context"]["project_id"]),
                        snapshot["snapshot_hash"],
                        encoded(documents),
                    ],
                )
        self.load(handle)
        return handle

    def load(self, handle, *, allow_expired=False):
        if type(handle) is not str or not re.fullmatch("[0-9a-f]{64}", handle):
            raise NativeStoreError("Invalid native job handle")
        rows = self.sql(
            f"""SELECT SNAPSHOT_HASH,BATCH_IDENTITY,SNAPSHOT,CONFIG,STATE,
          DATE_PART(EPOCH_SECOND,DEADLINE_AT) AS DEADLINE_EPOCH FROM {self.table}
          WHERE HANDLE=? AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE()""",
            [handle],
        )
        if len(rows) != 1:
            raise NativeStoreError("Native job unavailable to this caller")
        row = plain(rows[0])
        for key in ("SNAPSHOT", "CONFIG", "STATE"):
            if isinstance(row[key], str):
                row[key] = json.loads(row[key])
        snapshot = row["SNAPSHOT"]
        expected = snapshot.get("snapshot_hash")
        if (
            expected != row["SNAPSHOT_HASH"]
            or digest({k: v for k, v in snapshot.items() if k != "snapshot_hash"})
            != expected
        ):
            raise NativeStoreError("Frozen native snapshot changed")
        if row["STATE"].get("version") != VERSION:
            raise NativeStoreError("Unsupported native state")
        if not allow_expired and row["DEADLINE_EPOCH"] <= time.time():
            raise NativeStoreError("Native job deadline expired")
        return row

    @contextmanager
    def edit(self, handle, *, allow_expired=False):
        lease = secrets.token_hex(16)
        # Short transaction holds the row write lock only while manipulating
        # local state. No provider call, polling or evidence read happens here.
        # Rollback removes the temporary lease on every failed exit.
        with self.transaction():
            rows = self.sql(
                f"""UPDATE {self.table} SET LEASE_TOKEN=?,LEASE_UNTIL=DATEADD(second,20,CURRENT_TIMESTAMP())
              WHERE HANDLE=? AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE()
              AND (LEASE_UNTIL IS NULL OR LEASE_UNTIL<CURRENT_TIMESTAMP())""",
                [lease, handle],
            )
            if not affected(rows):
                raise NativeBusy("Native job state is busy; no operation was replayed")
            row = self.load(handle, allow_expired=allow_expired)
            state = deepcopy(row["STATE"])
            revision = state["revision"]
            yield state
            state["revision"] = revision + 1
            rows = self.sql(
                f"""UPDATE {self.table} SET STATE=PARSE_JSON(?),LEASE_TOKEN=NULL,LEASE_UNTIL=NULL
              WHERE HANDLE=? AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE()
              AND LEASE_TOKEN=? AND LEASE_UNTIL>CURRENT_TIMESTAMP()""",
                [encoded(state), handle, lease],
            )
            if not affected(rows):
                raise NativeStoreError(
                    "Native state fence expired; write not acknowledged"
                )

    def lookup(self, batch_identity):
        rows = self.sql(
            f"""SELECT HANDLE FROM {self.table} WHERE BATCH_IDENTITY=?
          AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE() ORDER BY CREATED_AT DESC""",
            [batch_identity],
        )
        if len(rows) > 1:
            raise NativeStoreError("Multiple native snapshots require reconciliation")
        return plain(rows[0])["HANDLE"] if rows else None

    def trace(self, handle, stage, *, counts=None):
        if not re.fullmatch("[a-z_]{1,64}", stage):
            raise NativeStoreError("Invalid trace stage")
        with self.edit(handle, allow_expired=True) as state:
            state["trace"].append(
                {"stage": stage, "at": time.time(), "counts": counts or {}}
            )
            state["trace"] = state["trace"][-128:]

    def find(self, batch_identity, snapshot_hash):
        rows = self.sql(
            f"""SELECT HANDLE FROM {self.table} WHERE BATCH_IDENTITY=? AND SNAPSHOT_HASH=?
          AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE() ORDER BY CREATED_AT DESC""",
            [batch_identity, snapshot_hash],
        )
        if len(rows) > 1:
            raise NativeStoreError(
                "Multiple native attempts require explicit reconciliation"
            )
        return plain(rows[0])["HANDLE"] if rows else None
