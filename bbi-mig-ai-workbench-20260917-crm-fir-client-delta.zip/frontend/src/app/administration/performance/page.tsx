import PerformanceDiagnosticsPage from '@/features/administration/performance/PerformanceDiagnosticsPage';

export default function Page() {
  return <PerformanceDiagnosticsPage />;
}
