import type { TourDefinition } from "../types/tour.types";
import { TOUR_TARGETS, tourSelector } from "../constants/tour-targets";

export const newProjectTour: TourDefinition = {
  id: "new-project",
  label: "New Project",
  description: "Set up a new project folder to organise your mappings.",
  routes: ["/projects"],
  steps: [
    {
      id: "new-project-domain-source-crm",
      title: "Domain and Source CRM Selection",
      body: "Select the project domain and Source CRM to align the STTM with the appropriate migration or mapping use case.",
      target: tourSelector(TOUR_TARGETS.newProjectDomainSourceCrm),
      placement: "bottom",
      isModal: true,
      requiresState: "modal-open",
    },
    {
      id: "new-project-auto-target-mapping",
      title: "Automated Target Mapping Creation",
      body: "Enable Automatic Target Mapping Creation to automatically generate mappings with preselected target systems, allowing users to focus on source selection and mapping configuration. (This is optional)",
      target: tourSelector(TOUR_TARGETS.newProjectSetup),
      placement: "bottom",
      isModal: true,
      requiresState: "modal-open",
    },
    {
      id: "new-project-business-domain",
      title: "Business Domain",
      body: "Enter the business area this project belongs to, such as Retail banking or Insurance. It gives the AI context for suggesting relevant mappings and terminology.",
      target: tourSelector(TOUR_TARGETS.newProjectBusinessDomain),
      placement: "bottom",
      isModal: true,
      requiresState: "modal-open",
    },
    {
      id: "new-project-intended-outcome",
      title: "Intended Outcome",
      body: "Describe what the project should deliver once complete, such as a publish-ready customer mapping for analytics. It helps keep the mappings focused on the end goal.",
      target: tourSelector(TOUR_TARGETS.newProjectIntendedOutcome),
      placement: "bottom",
      isModal: true,
      requiresState: "modal-open",
    },
    {
      id: "new-project-business-process",
      title: "Important Business Process",
      body: "Name the key business process the data supports, such as customer onboarding or account servicing. It helps prioritise the tables and rules that matter most.",
      target: tourSelector(TOUR_TARGETS.newProjectBusinessProcess),
      placement: "top",
      isModal: true,
      requiresState: "modal-open",
    },
  ],
};
