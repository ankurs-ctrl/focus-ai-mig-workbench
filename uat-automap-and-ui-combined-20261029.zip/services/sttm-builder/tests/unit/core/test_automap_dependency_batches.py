from types import SimpleNamespace

from app.core.automap_batching import dependency_batches
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
from tests.unit.core.test_automap_retrieval import payload


def test_dependency_overlap_groups_targets_without_duplicates_or_hardcoded_names():
    value = payload(8, description_size=0)
    value["context"].pop("learning_context")
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    rows = [{"target_column": f"NAME{index}", "source_columns": [f"source{index // 2}.VALUE"]}
            for index in range(8)]
    req.context.learning_context = SimpleNamespace(mapping_precedents=[SimpleNamespace(mappings=rows)])
    batches = dependency_batches(req, 4)
    assert len(batches) == 4
    assert [len(batch) for batch in batches] == [2] * 4
    assert len({item.target_attribute for batch in batches for item in batch}) == 8
    for batch in batches:
        assert int(batch[0].target_attribute[4:]) // 2 == int(batch[1].target_attribute[4:]) // 2
    assert batches == dependency_batches(req, 4)

def test_target_keys_follow_snowflake_identifier_case_rules():
    from app.core.automap_batching import target_identifier_key
    import pytest
    assert target_identifier_key("Household_ID") == target_identifier_key("HOUSEHOLD_ID")
    assert target_identifier_key('"HOUSEHOLD_ID"') == target_identifier_key("household_id")
    assert target_identifier_key('"Household_ID"') != target_identifier_key("HOUSEHOLD_ID")
    with pytest.raises(ValueError, match="target column identifier"):
        target_identifier_key('"unterminated')


def test_case_varied_workspace_rows_supply_dependency_overlap():
    value = payload(4, description_size=0)
    value["context"].pop("learning_context")
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    from app.schema.workspace_context import WorkbenchContextSnapshotV1
    req.context.workspace_context = WorkbenchContextSnapshotV1(mapping_rows=[
        {"id": str(index), "target_column": f"name{index}",
         "source_columns": [f"source{index // 2}.VALUE"]}
        for index in range(4)
    ])
    batches = dependency_batches(req, 2)
    assert [[item.target_attribute for item in batch] for batch in batches] == [
        ["NAME0", "NAME1"], ["NAME2", "NAME3"]]
