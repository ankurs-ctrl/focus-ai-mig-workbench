"""GET/cancel-only recovery for this task's isolated local acceptance fixtures.

No client accounts, model submissions, permit resets or fabricated completion.
"""
import argparse
from contextlib import contextmanager
import json
from pathlib import Path
import re
import sys
import time

ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'services/sttm-builder'),str(ROOT)]


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--credential-env',type=Path,required=True)
    parser.add_argument('--schema',required=True);parser.add_argument('--execute',action='store_true');parser.add_argument('--cleanup',action='store_true')
    args=parser.parse_args()
    if not re.fullmatch('SCH_AUTOMAP_ACCEPTANCE_[A-F0-9]{12}',args.schema):raise ValueError('Dedicated local fixture schema required')
    from dotenv import dotenv_values
    from snowflake.snowpark import Session
    from app.core.automap_durable_admission import DurableRunAdmission
    from app.core.automap_admission import ScanCallAdmission
    from app.core.automap_runtime import RuntimeCaller,SnowflakeReductionArchive
    from app.core.automap_background_transport import BackgroundRunTransport
    from app.core.automap_scan_transport import ScanTransportConfig
    from app.core.automap_shards import SnapshotScope,MessageBudget
    from app.core.automap_parallel import ParallelLimits
    from app.core.automap_batch import ParallelRuntimeBundle
    from app.core.automap_run_recovery import RunRecoveryCoordinator
    from app.core.snowflake_agent import SnowflakeAgentClient,_shared_http_client
    from types import SimpleNamespace
    c=dotenv_values(args.credential_env)
    if c.get('SNOWFLAKE_ACCOUNT','').upper()!='A0581299278961-BBINSIGHT_PARTNER':raise ValueError('Local test account only')
    config=dict(account=c['SNOWFLAKE_ACCOUNT'],user=c['SNOWFLAKE_USER'],role=c['SNOWFLAKE_ROLE'],
        authenticator='PROGRAMMATIC_ACCESS_TOKEN',token=c['SNOWFLAKE_PASSWORD'],warehouse=c['SNOWFLAKE_WAREHOUSE'],login_timeout=20,network_timeout=30)
    ns='FFP_HDP_CRM_MIG_DB_DEV.'+args.schema;table=ns+'.PERMITS_V2'
    s=Session.builder.configs(config).create()
    @contextmanager
    def sessions():
        independent=Session.builder.configs(config).create()
        try:yield independent
        finally:independent.close()
    try:
        native=s.sql("SELECT CURRENT_USER() U,CURRENT_ROLE() R,CURRENT_ORGANIZATION_NAME()||'.'||CURRENT_ACCOUNT_NAME() A").collect()[0]
        assert native['A']=='A0581299278961.BBINSIGHT_PARTNER'
        epochs=s.sql(f'SELECT DISTINCT POOL_EPOCH FROM {table}').collect();assert len(epochs)==1
        caller=RuntimeCaller(native['U'],native['U'],native['R'],native['A'])
        pool=DurableRunAdmission(session_factory=sessions,table=table,account_namespace=native['A'],pool_epoch=epochs[0]['POOL_EPOCH'],capacity=12,recovery_capacity=4)
        rows=s.sql(f"SELECT * FROM {table} WHERE STATE<>'FREE' AND CALLER_ID=CURRENT_USER()").collect()
        print(json.dumps({'schema':args.schema,'real_outstanding_before':len(rows),'execute':args.execute}))
        if not args.execute:return
        if rows:
            row=rows[0];scope=SnapshotScope(caller.native_user,row['GENERATION'])
            archive=SnowflakeReductionArchive(session_factory=sessions,table=ns+'.ARCHIVE',caller=caller,scope=scope,deadline=time.monotonic()+60)
            gate=ScanCallAdmission(pool,job_id=row['JOB_ID'],caller_id=caller.native_user)
            host='a0581299278961-bbinsight-partner.snowflakecomputing.com'
            agent=SnowflakeAgentClient(token=s.connection._rest._token,host=host,auth_mode='snowflake_token',role=caller.role)
            backend=BackgroundRunTransport(agent_client=agent,http_client=_shared_http_client('https://'+host),
                config=ScanTransportConfig(agent=ns+'.AGT_SOURCE_MAPPING',max_response_bytes=120000),admission=gate)
            backend.result_archive=archive;backend.run_seconds=180
            budget=MessageBudget(120000,120000)
            limits=ParallelLimits(budget,budget,budget,budget,12,32,16,8,16,64,256)
            bundle=ParallelRuntimeBundle(scope,backend,gate,archive,limits)
            RunRecoveryCoordinator().tick(bundle,backend,None,SimpleNamespace(automap_run_seconds=180))
        remaining=s.sql(f"SELECT COUNT(*) C FROM {table} WHERE STATE<>'FREE' AND CALLER_ID=CURRENT_USER()").collect()[0]['C']
        print(json.dumps({'real_outstanding_after':remaining,'model_posts':0}))
        if args.cleanup and remaining==0:
            unexpected=s.sql(f"SELECT COUNT(*) C FROM {table} WHERE STATE<>'FREE' AND NOT "
                "(CALLER_ID='LEGACY_TEST_CALLER' AND JOB_ID='old-test' AND OWNER_TOKEN='legacy-fixture' AND RECONCILIATION_REF IS NULL AND MODEL_RUN_ID IS NULL)").collect()[0]['C']
            if unexpected:raise ValueError('Unknown nonfixture exposure remains')
            s.sql('DROP SCHEMA '+ns+' CASCADE').collect();print('Dedicated fixture cleanup completed after terminal proof')
    finally:s.close()

if __name__=='__main__':main()
