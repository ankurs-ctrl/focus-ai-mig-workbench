import json
import uuid
from datetime import UTC, datetime
from unittest.mock import MagicMock

from app.core.table_selection import TableSelectionService, _cached
from app.schema.common import TableRef


def _service() -> tuple[TableSelectionService, MagicMock]:
    session = MagicMock()
    client = MagicMock(session=session)
    settings = MagicMock()
    settings.resolved_semantic_views_table = "REGISTRY.DB.LATEST_TABLES"
    settings.resolved_relationships_procedure = ""
    settings.table_selection_cache_seconds = 3600
    settings.table_selection_stale_if_error_seconds = 86400
    return TableSelectionService(client, settings), session


def test_attributes_are_loaded_with_two_set_based_queries_per_database() -> None:
    service, session = _service()
    column_query = MagicMock()
    column_query.collect.return_value = [
        {
            "TABLE_SCHEMA": "SRC",
            "TABLE_NAME": "CUSTOMER",
            "COLUMN_NAME": "ID",
            "DATA_TYPE": "NUMBER",
            "IS_NULLABLE": "NO",
            "ORDINAL_POSITION": 1,
            "COMMENT": None,
        },
        {
            "TABLE_SCHEMA": "SRC",
            "TABLE_NAME": "NOTE",
            "COLUMN_NAME": "CUSTOMER_ID",
            "DATA_TYPE": "NUMBER",
            "IS_NULLABLE": "YES",
            "ORDINAL_POSITION": 1,
            "COMMENT": None,
        },
    ]
    key_query = MagicMock()
    key_query.collect.return_value = [
        {
            "TABLE_SCHEMA": "SRC",
            "TABLE_NAME": "CUSTOMER",
            "COLUMN_NAME": "ID",
            "CONSTRAINT_TYPE": "PRIMARY KEY",
        }
    ]
    session.sql.side_effect = [column_query, key_query]

    result = service._list_attributes_for_tables_uncached(
        ["DB.SRC.CUSTOMER", "DB.SRC.NOTE"]
    )

    assert session.sql.call_count == 2
    assert [item.table.table for item in result] == ["CUSTOMER", "NOTE"]
    assert result[0].columns[0].is_primary_key is True
    assert result[1].columns[0].column_name == "CUSTOMER_ID"


def test_table_browsing_does_not_scan_all_schema_columns() -> None:
    service, session = _service()
    table_query = MagicMock()
    table_query.collect.return_value = [
        {
            "name": "CUSTOMER",
            "rows": 42,
            "comment": "Customer master",
        }
    ]
    session.sql.return_value = table_query

    result = service._list_tables_uncached("DB", "SRC")

    assert session.sql.call_count == 1
    assert "SHOW TABLES" in session.sql.call_args.args[0]
    assert result[0].table_name == "CUSTOMER"
    assert result[0].column_count == 0


def test_relationships_use_one_semantic_query_for_large_selection() -> None:
    service, session = _service()
    semantic_query = MagicMock()
    semantic_query.collect.return_value = [
        {
            "FQN": "DB.SRC.NOTE",
            "RELATIONSHIPS": json.dumps(
                {
                    "outgoing": [
                        {
                            "schema": "SRC",
                            "table": "CUSTOMER",
                            "constraint_name": "FK_NOTE_CUSTOMER",
                            "confidence": "HIGH",
                            "column_mappings": [
                                {"fk_column": "CUSTOMER_ID", "pk_column": "ID"}
                            ],
                        }
                    ],
                    "incoming": [],
                }
            ),
            "ATTRIBUTES": None,
        }
    ]
    session.sql.return_value = semantic_query
    tables = [
        TableRef(database="DB", schema="SRC", table=name)
        for name in ("NOTE", "CUSTOMER", "ADDRESS", "STATUS")
    ]

    result = service._list_relationships_for_tables_uncached(tables)

    assert session.sql.call_count == 1
    assert len(result) == 1
    assert result[0].left_table.table == "NOTE"
    assert result[0].right_table.table == "CUSTOMER"
    assert result[0].conditions[0].left_column == "CUSTOMER_ID"


def test_relationship_discovery_reuses_active_lookup_for_full_recommendations() -> None:
    service, _ = _service()
    relationships = [
        MagicMock(review_required=False),
        MagicMock(review_required=True),
    ]
    service.list_relationships_for_tables = MagicMock(return_value=relationships)
    tables = [TableRef(database="DB", schema="SRC", table="NOTE")]

    active, recommendations = service.list_relationship_discovery_for_tables(tables)

    assert active == [relationships[0]]
    assert recommendations == relationships
    service.list_relationships_for_tables.assert_called_once_with(tables)


def test_relationship_lookup_returns_active_and_review_semantic_confidences() -> None:
    service, _ = _service()
    note = TableRef(database="DB", schema="SRC", table="NOTE")
    customer = TableRef(database="DB", schema="SRC", table="CUSTOMER")
    address = TableRef(database="DB", schema="SRC", table="ADDRESS")
    service._settings.low_confidence_join_review_v1 = True
    service._semantic_knowledge.relationship_payloads = MagicMock(
        return_value={
            note.qualified_name.upper(): {
                "outgoing": [
                    {
                        "schema": "SRC",
                        "table": "CUSTOMER",
                        "confidence": "HIGH",
                        "column_mappings": [{"fk_column": "CUSTOMER_ID", "pk_column": "ID"}],
                        "source": "SEMANTIC_VIEW",
                    }
                ],
                "incoming": [],
                "review_outgoing": [
                    {
                        "schema": "SRC",
                        "table": "ADDRESS",
                        "confidence": "MEDIUM",
                        "column_mappings": [{"fk_column": "ADDRESS_ID", "pk_column": "ID"}],
                        "source": "SEMANTIC_VIEW",
                        "review_reason": "Needs human review.",
                    }
                ],
                "review_incoming": [],
            },
            customer.qualified_name.upper(): {"outgoing": [], "incoming": []},
            address.qualified_name.upper(): {"outgoing": [], "incoming": []},
        }
    )

    result = service._list_relationships_for_tables_uncached([note, customer, address])

    assert len(result) == 2
    assert {item.review_required for item in result} == {False, True}
    assert next(item for item in result if item.review_required).review_reason == "Needs human review."


def test_single_table_column_lookup_used_by_derived_validation() -> None:
    service, session = _service()
    service._primary_key_columns = MagicMock(return_value={"ID"})
    service._foreign_key_columns = MagicMock(return_value=set())
    dataframe = session.table.return_value
    dataframe.select.return_value = dataframe
    dataframe.filter.return_value = dataframe
    dataframe.sort.return_value = dataframe
    dataframe.collect.return_value = [
        {
            "COLUMN_NAME": "ID",
            "DATA_TYPE": "NUMBER",
            "IS_NULLABLE": "NO",
            "ORDINAL_POSITION": 1,
            "COMMENT": "Contact identifier",
        }
    ]

    result = service._list_columns("DB", "SRC", "CONTACTS")

    assert len(result) == 1
    assert result[0].column_name == "ID"
    assert result[0].is_primary_key is True
    dataframe.filter.assert_called_once()


def test_catalog_metadata_is_reused_within_configured_ttl() -> None:
    service, session = _service()
    service._cache_prefix = f"test-{uuid.uuid4()}"
    query = MagicMock()
    query.collect.return_value = [{"name": "DB", "created_on": datetime.now(UTC)}]
    session.sql.return_value = query

    first = service.list_databases()
    second = service.list_databases()

    assert first == second
    assert session.sql.call_count == 1


def test_expired_catalog_can_fall_back_when_snowflake_is_unavailable(monkeypatch) -> None:
    clock = [10.0]
    monkeypatch.setattr("app.core.table_selection.time.monotonic", lambda: clock[0])
    key = f"stale-{uuid.uuid4()}"

    assert _cached(
        key,
        lambda: ["DB"],
        ttl_seconds=1,
        stale_if_error_seconds=60,
    ) == ["DB"]
    clock[0] = 12.0

    def unavailable() -> list[str]:
        raise RuntimeError("Snowflake unavailable")

    assert _cached(
        key,
        unavailable,
        ttl_seconds=1,
        stale_if_error_seconds=60,
    ) == ["DB"]
