"""Print a non-secret dirty-source manifest before building a release."""
from __future__ import annotations

import hashlib
import json
import argparse
from datetime import datetime, timezone
from pathlib import Path
import subprocess


def release_source(relative: str) -> bool:
    path = Path(relative)
    if any(part in {'.dev-cache', '__pycache__', 'node_modules', '.next', '.venv', 'venv', '.pytest_cache',
                    'dist', 'out', 'coverage', '.ruff_cache'} or part.startswith('.next-') for part in path.parts):
        return False
    if '.env' in path.name and not path.name.endswith('.example'):
        return False
    if path.suffix in {'.log', '.pyc', '.pem', '.key', '.p12', '.pfx'} or path.name.startswith('deploy_log'):
        return False
    return relative.startswith((
        'frontend/src/', 'frontend/public/', 'frontend/scripts/', 'services/',
        'scripts/', 'infra/snowflake/', 'nginx/',
    )) or relative in {
        '.gitignore', '.dockerignore', '.env.example', 'docker-compose.yml', 'docker-compose.yaml',
        'start-ai-workbench-dev.ps1', 'start-ai-workbench-dev.sh', 'stop-ai-workbench-dev.ps1',
        'start-ai-workbench.ps1', 'start-ai-workbench.sh', 'deploy_bbi_workbench_v2.sh',
        'frontend/package.json', 'frontend/package-lock.json', 'frontend/next.config.ts',
        'frontend/tsconfig.json', 'frontend/middleware.ts', 'frontend/Dockerfile',
        'frontend/.dockerignore', 'frontend/eslint.config.mjs', 'frontend/postcss.config.mjs',
        'services/sttm-builder/Dockerfile', 'services/sttm-builder/requirements.txt',
        'docs/workbench-handoff-20261015.md', 'docs/automap-reconciliation-20261016.md',
        'docs/automap-context-rollout.md', 'docs/assistant-context-continuity.md',
        'docs/workbench-context-deployment-parity.md', 'docs/automap-scoped-retrieval.md',
    }


def manifest(root: Path) -> dict:
    def git(*args):
        return subprocess.check_output(['git', '-C', str(root), *args]).decode('utf-8').strip()
    paths = git('ls-files', '--cached', '--others', '--exclude-standard').splitlines()
    sources = {}
    for relative in paths:
        if not release_source(relative):
            continue
        path = root / relative
        if path.is_file():
            sources[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    source_hash = hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest()
    revision = git('rev-parse', 'HEAD')
    values = dict(line.split('=', 1) for line in (root/'infra/snowflake/env/client.env').read_text(encoding='utf-8').splitlines()
                  if line and not line.startswith('#') and '=' in line)
    now = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    return {'root': str(root), 'branch': git('branch', '--show-current'), 'revision': revision,
        'suggested_image_tag': f'{revision[:7]}-{now}-{source_hash[:8]}', 'source_hash': source_hash,
        'dirty_status': git('status', '--short'), 'source_sha256': sources,
        'release_status': 'not_approved_for_deployment',
        'snowflake_source_paths': sorted(path for path in sources if path.startswith('infra/snowflake/')),
        'non_secret_runtime': {key:values[key] for key in ('AGENT_CALLER_INLINE_FALLBACK_LIMIT_BYTES','AGENT_OUTBOUND_MESSAGE_MAX_CHARS',
            'AGENT_OUTBOUND_MESSAGE_MAX_BYTES','SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE','SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE',
            'SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE','AUTO_MAPPING_PROXY_BATCH_SIZE','AUTO_MAPPING_PROXY_MAX_IN_FLIGHT')}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Write a generated local JSON inventory; never deploy')
    args = parser.parse_args()
    result = manifest(Path(__file__).resolve().parents[1])
    if args.output:
        if not args.output.is_absolute() or not args.output.parent.is_dir() or args.output.exists():
            parser.error('--output must be a new absolute path in an existing directory')
        args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
        print(json.dumps({key: result[key] for key in ('revision', 'source_hash', 'suggested_image_tag', 'release_status')}
                         | {'file_count': len(result['source_sha256']), 'output': str(args.output)}, indent=2))
    else:
        print(json.dumps(result, indent=2))