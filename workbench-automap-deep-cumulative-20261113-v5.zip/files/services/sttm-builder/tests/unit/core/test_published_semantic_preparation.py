"""Published-asset revision checks occur on entry, before L1/L2 reuse."""
from types import SimpleNamespace
from unittest.mock import Mock
from app.core.prepared_context import PreparedWorkspaceContextService, invalidate_prepared_workspace_context_cache
from app.core.semantic_model import SemanticModelService
from app.schema.common import TableRef
from app.schema.prepared_context import PreparedWorkspaceContextRequest, PreparedWorkspaceContextResponse


def service():
    svc=PreparedWorkspaceContextService.__new__(PreparedWorkspaceContextService)
    svc._access_fingerprint='published-version-test'
    svc._session=Mock()
    svc._table='PREPARED'
    svc._settings=SimpleNamespace(fir_target_mapping_patterns_v2=False,
        prepared_context_l1_idle_seconds=3600,prepared_context_cache_v2=True,context_singleflight_v1=True)
    version=Mock(return_value='v1')
    svc._semantic_service=SimpleNamespace(_semantic_model_service=SimpleNamespace(published_registry_version=version))
    svc.get=Mock(return_value=None)
    svc._persist=Mock(return_value=True)
    def build(req,**kwargs):
        return PreparedWorkspaceContextResponse(workspace_context_id=kwargs['workspace_context_id'],
            workspace_context_hash=kwargs['workspace_context_hash'],workspace_version='2.0',semantic_registry_version=req.semantic_registry_version)
    svc._build=Mock(side_effect=build)
    return svc,version


def test_same_published_version_reuses_but_changed_version_invalidates_without_generation():
    invalidate_prepared_workspace_context_cache()
    svc,version=service();request=PreparedWorkspaceContextRequest(workspace={})
    first=svc.prepare(request);second=svc.prepare(request)
    assert first.workspace_context_id==second.workspace_context_id
    assert svc._build.call_count==1 and version.call_count==2
    version.return_value='v2'
    third=svc.prepare(request)
    assert third.workspace_context_id!=first.workspace_context_id
    assert svc._build.call_count==2
    assert third.semantic_registry_version=='v2'


def test_cross_replica_durable_hit_must_match_current_published_version():
    invalidate_prepared_workspace_context_cache()
    first,version=service();request=PreparedWorkspaceContextRequest(workspace={})
    saved=first.prepare(request)
    invalidate_prepared_workspace_context_cache()
    replica,current=service();replica.get.return_value=saved
    restored=replica.prepare(request)
    assert restored.cache_status=='l2'
    replica._build.assert_not_called()
    invalidate_prepared_workspace_context_cache();current.return_value='v2'
    changed=replica.prepare(request)
    assert changed.workspace_context_hash!=saved.workspace_context_hash
    replica._build.assert_called_once()


def test_version_check_includes_cte_physical_dependencies_and_target():
    invalidate_prepared_workspace_context_cache()
    svc,version=service()
    request=PreparedWorkspaceContextRequest(workspace={'source_tables':[{'database':'D','schema':'S','table':'A'}],
        'target_table':{'database':'D','schema':'T','table':'TARGET'},
        'derived_sources':[{'id':'cte','base_source_tables':[{'database':'D','schema':'S','table':'B'}]}]})
    svc.prepare(request)
    assert {t.qualified_name for t in version.call_args.args[1]}=={'D.S.A','D.S.B','D.T.TARGET'}


def test_unavailable_version_does_not_authorize_stale_cache_and_remains_usable():
    invalidate_prepared_workspace_context_cache()
    svc,version=service();version.return_value=None
    first=svc.prepare(PreparedWorkspaceContextRequest(workspace={}))
    second=svc.prepare(PreparedWorkspaceContextRequest(workspace={}))
    assert first.workspace_context_id!=second.workspace_context_id
    assert svc._build.call_count==2


def test_fingerprint_is_one_scoped_read_including_legacy_and_curated_registries():
    svc=SemanticModelService.__new__(SemanticModelService)
    svc._table_views_table='TABLE_VIEWS';svc._native_views_table='NATIVE_VIEWS'
    svc._column_views_table='COLUMN_VIEWS';svc._table='LEGACY'
    svc._settings=SimpleNamespace(qualify_metadata_object_name=lambda n:n)
    row=SimpleNamespace(as_dict=lambda:{'REGISTRY':1,'ASSET_STAMP':42,'ASSET_COUNT':3})
    session=Mock();session.sql.return_value.collect.return_value=[row]
    stamp=svc.published_registry_version(session,[TableRef(database='D',schema='S',table='A')])
    assert len(stamp)==64
    sql=session.sql.call_args.args[0]
    assert 'FROM LEGACY t JOIN requested r ON UPPER(t.DB_NAME)' in sql
    assert 'TBL_SEMANTIC_VIEW_VERSIONS' in sql
    assert "('D','S','A')" in sql
    assert all(verb not in sql.upper() for verb in ('CREATE ', 'CALL ', 'UPDATE ', 'DELETE '))
    session.sql.assert_called_once()
