"""Resolve display column names against authoritative Snowflake SQL identifiers."""
from copy import deepcopy

from sqlglot import exp


def bind_output_columns(columns, identifiers):
    from app.core.automap_deterministic import _identifier, _key
    result = []
    for item in columns:
        display = str(item.get("name") or item.get("column_name") or "")
        def matches(identifier):
            if item.get("sql_name") and _key(_identifier(item["sql_name"])) != _key(identifier):
                return False
            return (display in {identifier.name, _key(identifier), identifier.sql(dialect="snowflake")}
                    or (not identifier.args.get("quoted") and display.upper() == _key(identifier)))
        matches_list = [identifier for identifier in identifiers if matches(identifier)]
        if len(matches_list) != 1:
            raise ValueError("Selected CTE outputs differ from current authored SQL")
        identifier = matches_list[0]
        canonical = exp.to_identifier(_key(identifier), quoted=bool(identifier.args.get("quoted")))
        result.append({**deepcopy(item), "sql_name": canonical.sql(dialect="snowflake")})
    return result


def output_sql_columns(node, *, strict=True):
    """Return canonical SQL spellings without changing archived display metadata."""
    from app.core.automap_deterministic import _identifier, _key, _one, _query_output_identifiers
    columns = node.get("output_columns") or []
    if node.get("kind") not in {"DERIVED_SOURCE", "CTE"}:
        return {item["name"]: exp.to_identifier(item["name"], quoted=True).sql(dialect="snowflake")
                for item in columns if item.get("name")}
    try:
        identifiers = _query_output_identifiers(_one(node.get("sql_text") or ""))
    except ValueError:
        identifiers = None  # A wildcard/view requires its server-validated schema.
    try:
        resolved = bind_output_columns(columns, identifiers) if identifiers is not None else columns
    except ValueError:
        if strict:
            raise
        # Scan preparation archives incomplete catalogs too. Eligibility for
        # fast mapping still requires the separate strict output proof.
        resolved = columns
    result = {}
    for item in resolved:
        if not item.get("name"):
            continue
        if item.get("sql_name"):
            identifier = _identifier(item["sql_name"])
            value = exp.to_identifier(_key(identifier), quoted=bool(identifier.args.get("quoted")))
        else:
            value = exp.to_identifier(item["name"], quoted=True)
        result[item["name"]] = value.sql(dialect="snowflake")
    return result
