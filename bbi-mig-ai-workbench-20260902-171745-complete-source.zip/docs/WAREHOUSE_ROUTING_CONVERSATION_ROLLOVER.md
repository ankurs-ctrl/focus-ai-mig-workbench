# Warehouse Routing, Cost Control, and Conversation Continuity

## Resource boundaries

The Workbench uses three independent Snowflake resources:

- SPCS compute pools run the web and auto-map containers.
- Virtual warehouses execute SQL.
- Cortex Agent and Cortex Analyst consume AI credits. SQL produced by Cortex
  still executes through a selected virtual warehouse.

Changing a compute pool does not change the warehouse used by SQL, and changing
a warehouse does not move or resize an SPCS service.

## Warehouse routing

Runtime warehouse selection is controlled by `client.env`:

```env
SNOWFLAKE_WAREHOUSE=AI_WORKBENCH_XS_1
SNOWFLAKE_CONTROL_WAREHOUSE=AI_WORKBENCH_XS_1
SNOWFLAKE_AGENT_WAREHOUSE=AI_WORKBENCH_XS_2
SNOWFLAKE_EXECUTION_WAREHOUSE=AI_WORKBENCH_MEDIUM
AUTO_MAPPING_WAREHOUSE=AI_WORKBENCH_XS_2
```

Fallbacks are:

1. Control: `SNOWFLAKE_CONTROL_WAREHOUSE`, then `SNOWFLAKE_WAREHOUSE`.
2. Agent: `SNOWFLAKE_AGENT_WAREHOUSE`, then Control.
3. Execution: `SNOWFLAKE_EXECUTION_WAREHOUSE`, then Control.
4. Auto-map: `AUTO_MAPPING_WAREHOUSE`, then Agent.

Set all five variables to one X-Small warehouse to run every workload there
without changing code or service specifications.

Control covers metadata, sessions, projects, mappings, caches, FIR, artifacts,
and polling. Agent covers Cortex headers and assistant tool SQL. Auto-map covers
job orchestration and mapping workers. Execution is acquired only for explicit
preview, validation, EXPLAIN, data-quality, test-case, publish, or DBT execution.

Snowflake/Snowpark pools are isolated by user, role, authentication fingerprint,
workload, and resolved warehouse. Runtime code does not issue `USE WAREHOUSE` on
a shared session. Each connection receives a workload-specific statement timeout
and JSON query tag.

## SPCS routing and sizing

The web and auto-map services can be deployed independently:

```env
SNOWFLAKE_COMPUTE_POOL=AI_WORKBENCH_WEB_POOL
AUTO_MAPPING_COMPUTE_POOL=AI_WORKBENCH_AUTOMAP_POOL
```

Pool node bounds, service instance bounds, auto-suspend, and worker concurrency
are environment-driven in the deployment templates. Development may keep both
services on the current pool; production can change only
`AUTO_MAPPING_COMPUTE_POOL` when a dedicated pool is available.

## Automatic conversation rollover

One visible UI conversation is a logical conversation. It may span multiple
physical Cortex thread segments. Before each agent request, the backend estimates
the current segment plus packed request and rolls over at the configured soft
ratio, hard ratio, or turn limit:

```env
AGENT_CONTEXT_LIMIT_TOKENS=90000
AGENT_THREAD_ROLLOVER_RATIO=0.65
AGENT_THREAD_HARD_RATIO=0.80
AGENT_RECENT_TURNS_TO_KEEP=8
AGENT_MAX_TURNS_PER_SEGMENT=60
```

Expired-thread and context-limit errors checkpoint and retry once on a fresh
physical thread. The checkpoint preserves deterministic workspace state,
semantic/FIR handles, linked precedents, pending work, artifact references, and
recent turns. The UI keeps the same logical conversation ID and receives
`thread_checkpointed` and `thread_rolled_over` SSE events.

Conversation segments and compact visible turns are stored in Snowflake, so
continuation survives navigation, replicas, and restarts.

## Content-addressed artifacts

Large SQL, YAML, derived-source definitions, mapping precedents, lineage,
validation output, test/DBT output, and FIR evidence are not repeated in every
message.

```env
SNOWFLAKE_AGENT_ARTIFACT_STAGE=AI_WORKBENCH_ARTIFACTS
AGENT_INLINE_ARTIFACT_LIMIT_BYTES=32768
AGENT_ARTIFACT_DRAFT_RETENTION_DAYS=90
```

Payloads larger than the inline limit are gzip-compressed and written once under
a SHA-256 stage path. Conversation messages carry an artifact ID, summary, and
small excerpt. Artifact hydration always checks the caller access fingerprint
before downloading stage content and supports bounded section/range reads.

Run the metadata bootstrap and caller grants before enabling artifacts in SPCS.
The bootstrap creates the internal stage and conversation-segment metadata.

## Cost controls and verification

Apply
`infra/snowflake/observability/workbench_resource_monitors.sql.tmpl` after
choosing client-specific quotas and monitor names. Warehouses use auto-resume
and a 60-second auto-suspend. Resource monitors cover warehouse credits only;
Cortex and SPCS must be monitored separately.

Use `infra/snowflake/observability/workbench_cost_dashboard.sql` to review:

- query count and active seconds by workload, user, project, and mapping;
- warehouse credits;
- Cortex Agent and Analyst credits;
- SPCS credits by compute pool;
- any non-execution query that activated the Medium execution warehouse.

The `SNOWFLAKE.ACCOUNT_USAGE` views are not real-time, so allow for their normal
ingestion latency when validating a deployment.

Acceptance for routine activity is strict: navigation, metadata refresh,
conversation memory, cache hits, notification polling, and auto-map polling must
not activate the execution warehouse.
