const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const filename = path.resolve(__dirname, '../src/features/sttm/mapping/review-semantic-context.ts');
const loaded = new Module(filename, module);
loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, filename);
const {resolveReviewSemanticContext} = loaded.exports;
(async () => {
  let calls = 0;
  const failed = async () => { calls++; throw new Error('ambiguous ACCOUNT'); };
  const original = {preview_sql:'SELECT 1',semantic_bundle_id:'bundle'};
  assert.equal((await resolveReviewSemanticContext(original,false,failed)).payload,original);
  assert.equal(calls,0);
  const yaml = {...original,semantic_model_yaml:'tables: []'};
  assert.equal((await resolveReviewSemanticContext(yaml,true,failed)).payload,yaml);
  assert.equal(calls,0);
  const fallback = await resolveReviewSemanticContext(original,true,failed);
  assert.equal(fallback.payload,original);
  assert.match(fallback.warning,/Snowflake validation/);
  assert.equal(calls,1);
  const success = await resolveReviewSemanticContext(original,true,async()=>({semantic_model_yaml:'ready'}));
  assert.equal(success.payload.semantic_model_yaml,'ready');
  assert.equal(original.semantic_model_yaml,undefined);
  console.log('SQL review is independent of missing or failed optional semantics.');
})().catch(error=>{console.error(error);process.exitCode=1;});