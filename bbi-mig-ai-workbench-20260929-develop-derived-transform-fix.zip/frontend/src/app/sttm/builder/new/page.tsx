"use client";

import { useEffect } from "react";
import { useSidebarSlot } from "@/features/sttm/layout/sidebar-slot-context";
import SourceTargetPanel from "@/features/sttm/source-target/source-target-panel";
import SourceTargetDbSelection from "@/features/sttm/source-target/source-target-db-selection";
import SttmTableRelationshipFlow from "@/features/sttm/source-target/table-relationship-flow";

export default function SttmBuilderPage() {
  const { setContent } = useSidebarSlot();

  useEffect(() => {
    let cancelled = false;
    // Defer so SidebarSlotProvider finishes mounting before receiving content.
    const frame = window.requestAnimationFrame(() => {
      if (!cancelled) {
        setContent(<SourceTargetDbSelection />);
      }
    });
    return () => {
      cancelled = true;
      window.cancelAnimationFrame(frame);
      setContent(null);
    };
  }, [setContent]);

  return (
    <div className="sttm-scroll-pane h-full min-h-0 min-w-0 flex-1 overflow-y-auto overflow-x-hidden bg-white p-3">
      <div className="flex min-w-0 flex-col gap-3 pb-3">
        <div className="grid min-h-[450px] min-w-0 grid-cols-1 overflow-hidden rounded-lg border border-[#e5e7eb] bg-white lg:grid-cols-[minmax(0,1.35fr)_minmax(0,0.65fr)]">
          <div className="flex min-h-0 min-w-0 border-b border-[#e5e7eb] lg:border-b-0 lg:border-r">
            <SourceTargetPanel type="source" />
          </div>
          <div className="grid min-h-0 min-w-0 grid-rows-[minmax(160px,auto)_minmax(240px,1fr)]">
            <div className="flex min-h-0 min-w-0 border-b border-[#e5e7eb]">
              <SourceTargetPanel type="derived" />
            </div>
            <div className="flex min-h-0 min-w-0">
              <SourceTargetPanel type="target" />
            </div>
          </div>
        </div>

        <SttmTableRelationshipFlow />
      </div>
    </div>
  );
}
