"""Parent response/checkpoint delivery independent of slow connection setup."""

from concurrent.futures import Future, TimeoutError
from threading import Event
from types import SimpleNamespace
import time
import pytest
from app.core import automap_native_delivery as delivery
from tests.unit.core.test_automap_fast_batch import prepared_request
from tests.unit.core.test_automap_fast_context import fast_payload


def test_ready_worker_is_not_blocked_by_slow_checkpoint_connection(monkeypatch):
    release = Event()
    entered = Event()
    calls = []

    def slow(*args):
        calls.append(1)
        entered.set()
        assert release.wait(3)
        return []

    monkeypatch.setattr(delivery, "_read_checkpoints", slow)
    req = prepared_request(fast_payload())
    future = Future()
    future.set_result("ready")
    start = time.monotonic()
    try:
        results = list(
            delivery.completed_with_checkpoints(
                None,
                {future: 0},
                req,
                [req.data.attributes],
                {},
                poll_seconds=0.01,
                deadline=time.time() + 1,
            )
        )
        assert results == [future] and future.result() == "ready"
        assert time.monotonic() - start < 0.5 and entered.wait(0.5) and calls == [1]
    finally:
        release.set()


def test_parent_deadline_survives_stalled_connection_without_spawning_extra_readers(
    monkeypatch,
):
    release = Event()
    calls = []

    def slow(*args):
        calls.append(1)
        assert release.wait(3)
        return []

    monkeypatch.setattr(delivery, "_read_checkpoints", slow)
    req = prepared_request(fast_payload())
    future = Future()
    start = time.monotonic()
    try:
        with pytest.raises(TimeoutError, match="deadline"):
            list(
                delivery.completed_with_checkpoints(
                    None,
                    {future: 0},
                    req,
                    [req.data.attributes],
                    {},
                    poll_seconds=0.01,
                    deadline=time.time() + 0.08,
                )
            )
        assert time.monotonic() - start < 0.5 and calls == [1]
    finally:
        release.set()


def test_checkpoint_is_returned_even_when_worker_response_failed(monkeypatch):
    req = prepared_request(fast_payload())
    future = Future()
    future.set_exception(RuntimeError("lost response"))
    result = SimpleNamespace(
        meta={
            "auto_map_native_checkpoint_token": "verified",
            "auto_map_native_checkpoint_targets": ["NAME0"],
        }
    )
    import copy

    result.model_copy = lambda **kw: copy.copy(result)

    def read(*args):
        time.sleep(0.02)
        return [(0, req, result)]

    monkeypatch.setattr(delivery, "_read_checkpoints", read)
    proxy = SimpleNamespace(_batch_identity=lambda *a: "batch")
    events = list(
        delivery.completed_with_checkpoints(
            proxy,
            {future: 0},
            req,
            [req.data.attributes],
            {},
            poll_seconds=0.01,
            progress_callback=lambda *a: None,
            deadline=time.time() + 1,
        )
    )
    assert events[0] == ("checkpoint", 0, result)
    assert events[1].result().meta["auto_map_native_provisional"] is False


def checkpoint_pair():
    from tests.unit.core.test_automap_native_tools import (
        system,
        proposal,
        read_required,
        call,
    )
    from app.core.automap_native import make_response

    req, snap, store, tools = system(2)
    targets = list(snap["targets"])
    for target in targets:
        item = proposal(snap, target)
        read_required(tools, snap, target, item["mapping"]["source_attributes"])
        call(
            tools,
            snap,
            "SubmitProposals",
            {"proposals": {target: item}},
            targets=[target],
        )
        if target == targets[0]:
            partial = make_response(req, store.row)
    return req, partial, make_response(req, store.row)


def test_older_one_target_checkpoint_does_not_replace_complete_worker():
    req, partial, complete = checkpoint_pair()
    result = delivery.reconcile_checkpoint(partial, complete)
    assert len(result.meta["auto_map_native_checkpoint_targets"]) == 2
    assert result.result.mappings["NAME1"].source_attributes == ['a."X47"']


def test_conflicting_same_revision_proposals_are_not_silently_overwritten():
    req, partial, complete = checkpoint_pair()
    complete.result.mappings["NAME0"].confidence_reason = "conflicting content"
    result = delivery.reconcile_checkpoint(partial, complete)
    assert result.result.mappings['NAME0'] == partial.result.mappings['NAME0']
    assert result.result.mappings['NAME1'] == complete.result.mappings['NAME1']
    assert result.meta['auto_map_native_delivery_conflict_targets'] == ['NAME0']
    assert any(warning.code == 'AUTO_MAPPING_NATIVE_DELIVERY_CONFLICT' for warning in result.warnings)


def test_other_generation_worker_is_rejected():
    req, partial, complete = checkpoint_pair()
    complete.meta["auto_map_native_identity"]["input_revision"] = "new"
    with pytest.raises(ValueError, match="revision"):
        delivery.reconcile_checkpoint(partial, complete)


def test_accepted_checkpoint_survives_cutoff_and_late_worker_cannot_replace_it(
    monkeypatch,
):
    req, partial, complete = checkpoint_pair()
    future = Future()
    clock = [10.0]
    monkeypatch.setattr(delivery, "time", SimpleNamespace(time=lambda: clock[0]))
    monkeypatch.setattr(delivery, "_read_checkpoints", lambda *a: [(0, req, partial)])
    proxy = SimpleNamespace(_batch_identity=lambda *a: "batch")
    outputs = delivery.completed_with_checkpoints(
        proxy,
        {future: 0},
        req,
        [req.data.attributes],
        {},
        progress_callback=lambda *a: None,
        deadline=20,
        poll_seconds=0.001,
    )
    first = next(outputs)
    assert first[0] == "checkpoint"
    clock[0] = 21.0
    future.set_result(complete)
    terminal = next(outputs)
    assert terminal.result().meta["auto_map_native_checkpoint_targets"] == ["NAME0"]
    assert terminal.native_accepted_before_deadline is terminal.result()
