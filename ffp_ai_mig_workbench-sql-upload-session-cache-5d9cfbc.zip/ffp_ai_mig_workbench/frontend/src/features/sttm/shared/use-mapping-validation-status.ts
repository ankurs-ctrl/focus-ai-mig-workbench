"use client";

import { useMemo } from "react";
import { useAppSelector } from "@/store/hooks";
import { computeMappingValidationSignature } from "@/features/sttm/shared/mapping-validation";
import { useProjectAttributes } from "@/features/sttm/mapping/use-project-attributes";

/**
 * Whether the current workspace has passed Compile & Validate since its last change.
 * `signature` is the current workspace fingerprint to store after a successful validation.
 */
export function useMappingValidationStatus() {
  const builder = useAppSelector((state) => state.sttmBuilder);
  const {
    sourceDatabases,
    sources,
    targetDatabases,
    targets,
    drivingTableId,
    derivedSources,
    relationships,
    mappings,
    sourceFilterSql,
    sourceGroupBySql,
    sourceOrderBySql,
    sqlValidatedSignature,
  } = builder;
  const { projectAttributes, isLoadingProjectAttributes } = useProjectAttributes(builder.activeProjectId);

  const signature = useMemo(
    () =>
      computeMappingValidationSignature({
        projectId: builder.activeProjectId,
        firmValues: projectAttributes,
        semanticContext: builder.semanticContextItems,
        sourceDatabases,
        sources,
        targetDatabases,
        targets,
        drivingTableId,
        derivedSources,
        relationships,
        mappings,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [
      builder.activeProjectId,
      builder.semanticContextItems,
      projectAttributes,
      derivedSources,
      drivingTableId,
      mappings,
      relationships,
      sourceDatabases,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
      sources,
      targetDatabases,
      targets,
    ],
  );

  return {
    signature,
    isValidated: !isLoadingProjectAttributes && sqlValidatedSignature !== null && sqlValidatedSignature === signature,
  };
}
