'use client';

import { AiaBox, AiaCard } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { BODY_SX, SECONDARY_TEXT_SX, TYPOGRAPHY_TOKENS } from '@/config/typography-tokens';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { WorkspaceEmptyMessage } from './workspace-empty-message';
import {
  WORKSPACE_CARD_SELECTED_TEXT,
  workspaceCardSx,
} from '@/features/sttm/source-target/workspace-card-styles';
import { getDerivedSourceCounts } from '@/features/sttm/source-target/derived-source-counts';

type DerivedWorkspaceListProps = {
  orderedIds: string[];
  isSelected: (id: string) => boolean;
  onSelect: (id: string, event: React.MouseEvent, orderedIds: string[]) => void;
};

export default function DerivedWorkspaceList({
  orderedIds,
  isSelected,
  onSelect,
}: DerivedWorkspaceListProps) {
  const { derivedSources } = useSttmBuilderContext();

  const workspaceItems = derivedSources.filter((source) => source.isSelected);

  if (workspaceItems.length === 0) {
    return (
      <WorkspaceEmptyMessage>
        Drag CTEs from CTE Library into this area.
      </WorkspaceEmptyMessage>
    );
  }

  return (
    <AiaBox sx={{ width: "100%", minWidth: 0, alignSelf: "stretch" }}>
      {workspaceItems.map((source) => {
        const { sourceTableCount, selectedColumnCount, outputColumnCount } =
          getDerivedSourceCounts(source);
        const selected = isSelected(source.id);

        return (
          <AiaCard
            key={source.id}
            variant="outlined"
            sx={{
              ...workspaceCardSx(selected),
              alignSelf: "stretch",
            }}
            onClick={(event) => onSelect(source.id, event, orderedIds)}
          >
            <AiaBox
              sx={{
                flex: "1 1 auto",
                minWidth: 0,
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                gap: "var(--sttm-card-title-caption-gap)",
              }}
            >
              <AiaText
                sx={{
                  ...BODY_SX,
                  color: selected ? WORKSPACE_CARD_SELECTED_TEXT : TYPOGRAPHY_TOKENS.body.color,
                  whiteSpace: 'normal',
                  overflowWrap: 'anywhere',
                  wordBreak: 'break-word',
                }}
              >
                {source.sourceName}
              </AiaText>
              <AiaText
                sx={{
                  ...SECONDARY_TEXT_SX,
                  fontSize: 12,
                  color: selected
                    ? 'color-mix(in srgb, #ffffff 78%, transparent)'
                    : TYPOGRAPHY_TOKENS.secondaryText.color,
                }}
              >
                {sourceTableCount} source table{sourceTableCount === 1 ? '' : 's'} ·{' '}
                {outputColumnCount > 0
                  ? `${outputColumnCount} output column${outputColumnCount === 1 ? '' : 's'}`
                  : `${selectedColumnCount} selected columns`}
              </AiaText>
            </AiaBox>
          </AiaCard>
        );
      })}
    </AiaBox>
  );
}
