from copy import deepcopy

from app.core.automap_policy import POLICY_VERSION
from app.core.automap_transform import transformation_packet
from app.core.automap_retrieval import encoded
from tests.unit.core.test_automap_retrieval import payload


def test_legacy_transform_does_not_require_experimental_dependency_contract(monkeypatch):
    from app.core.sttm_builder import STTMBuilderService
    from app.core.config import Settings
    from tests.unit.core.test_auto_mapping_proxy import _request
    from app.schema.sttm_builder import Interface, STTMOperation

    request = _request(1)
    request.operation = STTMOperation.TRANSFORM
    request.data.intent = Interface.TRANSFORM
    request.meta["auto_map_stage"] = "complex_transformation"
    selected = {"source_attributes": ["DB.SRC.SOURCE.COL_0"], "source_dependencies": [],
                "constant_value": None, "used_learning_ids": [], "preprocessing_rule": "TRIM(src.COL_0)"}
    request.data.attributes[0].selected_mapping = selected
    def packet(raw):
        raise AssertionError("Legacy graph must not use retrieval-only contracts")
    monkeypatch.setattr("app.core.automap_transform.transformation_packet", packet)
    result = STTMBuilderService.project_agent_payload(request, Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=False))
    from scripts.automap_message_sizes import expand_packet
    assert expand_packet(result.payload)["data"]["attributes"][0]["selected_mapping"] == selected


def test_transform_handoff_has_only_selected_semantics_and_keeps_original():
    value = payload(description_size=10000)
    value["context"]["learning_context"]["automap_policy_version"] = POLICY_VERSION
    value["context"]["semantic_context"][0]["semantic_model"]["attributes"].append(
        {"name": "UNRELATED", "business_meaning": "Do not send this"})
    value["data"]["attributes"][0]["selected_mapping"] = {
        "source_attributes": ["a.X47"], "source_dependencies": ["a.X47"], "value_binding_ids": ["firm"]}
    saved = deepcopy(value)
    result = transformation_packet(value)
    assert "Legal appellation" in encoded(result)
    assert "Do not send this" not in encoded(result)
    assert "resolved_value" not in encoded(result)
    assert "semantic_context" not in result["context"]
    assert "$FirmID" in encoded(result)
    assert value == saved


def test_specialist_receives_admitted_fir_rule_and_current_project_contract():
    from scripts.automap_message_sizes import expand_packet
    value = payload(description_size=0)
    value["context"].update(project_id="current", sttm_id="mapping",
        workspace_context={"mapping_rows":[{"target_column":"Name0", "expression":"TRIM(a.X47)"}]})
    value["context"]["learning_context"] = {
        "automap_policy_version": POLICY_VERSION,
        "project_context":{"project_id":"current", "project_description":"Household migration"},
        "search_evidence":[
            {"knowledge_id":"fir-good", "target_columns":["NAME0"], "validation_status":"validated",
             "payload":{"target_column":"NAME0", "expression":"TRIM(a.X47)"}},
            {"knowledge_id":"foreign", "target_columns":["OTHER"], "payload":{"expression":"bad"}},
        ],
    }
    value["data"]["attributes"][0]["selected_mapping"] = {
        "source_attributes":["a.X47"], "source_dependencies":["a.X47"], "value_binding_ids":[],
        "used_learning_ids":["fir-good"]}
    result = expand_packet(transformation_packet(value))
    assert result["context"]["project_id"] == "current"
    assert result["context"]["current_mapping_rows"][0]["expression"] == "TRIM(a.X47)"
    evidence = result["context"]["mapping_evidence"]["NAME0"]["search_hydrated_evidence"]
    assert [item["knowledge_id"] for item in evidence] == ["fir-good"]
    assert evidence[0]["payload"]["expression"] == "TRIM(a.X47)"
    assert result['context']['evidence_citation_contract']['NAME0']['allowed_evidence_ids']==['fir-good']


def test_expression_cannot_hide_extra_sources_or_project_values():
    from types import SimpleNamespace
    from app.core.automap_transform import expression_within_selection
    value = payload(description_size=0)
    value["context"]["relation_graph"]["nodes"][0]["output_columns"].append({"name": "OTHER"})
    selected = SimpleNamespace(source_attributes=["a.X47"], source_dependencies=["a.X47"], value_binding_ids=[])
    rule = SimpleNamespace(rule="COALESCE(a.X47, a.OTHER)", source_dependencies=["a.X47"], value_binding_ids=[])
    assert not expression_within_selection(value, selected, rule)
    rule.rule = "COALESCE(a.X47, $FirmID)"
    assert not expression_within_selection(value, selected, rule)
    selected.value_binding_ids = ["firm"]
    assert expression_within_selection(value, selected, rule)
    rule.rule = "TRIM(A.X47)"
    assert expression_within_selection(value, selected, rule)


def test_admitted_evidence_is_private_not_serialized_metadata():
    from app.schema.sttm_builder import STTMBuilderResponse
    response = STTMBuilderResponse(thread_id="local")
    response._auto_map_admitted_evidence = {"NAME": {"rules": [{"sql": "private-body"}]}}
    assert "private-body" not in response.model_dump_json()
    assert response.model_copy()._auto_map_admitted_evidence == response._auto_map_admitted_evidence
