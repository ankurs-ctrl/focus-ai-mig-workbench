/** Shared helpers for local fixture modules under `src/data/mock`. */

export function mockDelay<T>(data: T, delay = 500): Promise<T> {
  return new Promise((resolve) => {
    globalThis.setTimeout(() => resolve(data), delay);
  });
}

export function mockSleep(delay = 200): Promise<void> {
  return new Promise((resolve) => {
    globalThis.setTimeout(resolve, delay);
  });
}
