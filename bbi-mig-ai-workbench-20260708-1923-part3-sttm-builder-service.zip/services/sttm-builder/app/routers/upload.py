"""Upload router — handles SQL and Excel file uploads for FIR learning.

Two modes:
  - auto_populate: Parse file, return structured data for builder hydration, trigger FIR in background
  - learn_from_it: Store asset, trigger FIR immediately for learning, user builds manually
"""
from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, File, Form, UploadFile, HTTPException, Depends

from ..core.sql_parser import parse_sql_document, ParsedSqlDocument
from ..core.excel_parser import parse_excel_mapping, ParsedExcelMapping

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/upload", tags=["Upload"])

MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB


def _get_snowflake_session():
    from ..core.snowflake import get_snowflake_client
    client = get_snowflake_client()
    return client.session


@router.post("/sql")
async def upload_sql(
    file: UploadFile = File(...),
    project_id: str = Form(...),
    mode: str = Form("auto_populate"),
):
    """Upload a SQL file for parsing and FIR learning.

    Args:
        file: The SQL file (.sql)
        project_id: Project context
        mode: 'auto_populate' (fill builder) or 'learn_from_it' (background learning)

    Returns:
        Parsed summary with tables, columns, joins, transformations
    """
    if not file.filename or not file.filename.lower().endswith(".sql"):
        raise HTTPException(400, "Only .sql files are accepted")

    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(413, f"File exceeds {MAX_FILE_SIZE // (1024*1024)}MB limit")

    sql_text = content.decode("utf-8", errors="replace")
    asset_id = hashlib.sha256(content).hexdigest()[:32]

    parsed = parse_sql_document(sql_text)

    session = _get_snowflake_session()
    try:
        _store_sql_asset(session, asset_id, file.filename, sql_text, project_id, parsed)
    except Exception as exc:
        logger.error("Failed to store SQL asset: %s", exc)

    if mode == "learn_from_it":
        try:
            _trigger_fir_agent(session, project_id)
        except Exception as exc:
            logger.warning("FIR trigger failed (will process on next batch): %s", exc)

    return {
        "status": "success",
        "asset_id": asset_id,
        "filename": file.filename,
        "mode": mode,
        "parsed_summary": parsed.to_dict(),
    }


@router.post("/excel")
async def upload_excel(
    file: UploadFile = File(...),
    project_id: str = Form(...),
    mode: str = Form("auto_populate"),
):
    """Upload an Excel/CSV mapping file for parsing and FIR learning.

    Args:
        file: The Excel file (.xlsx, .xls, .csv)
        project_id: Project context
        mode: 'auto_populate' or 'learn_from_it'

    Returns:
        Parsed mapping summary with source/target columns and rules
    """
    valid_exts = (".xlsx", ".xls", ".csv")
    if not file.filename or not any(file.filename.lower().endswith(ext) for ext in valid_exts):
        raise HTTPException(400, f"Accepted formats: {', '.join(valid_exts)}")

    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(413, f"File exceeds {MAX_FILE_SIZE // (1024*1024)}MB limit")

    parsed = parse_excel_mapping(content, file.filename)
    asset_id = hashlib.sha256(content).hexdigest()[:32]

    session = _get_snowflake_session()
    try:
        _store_excel_asset(session, asset_id, file.filename, parsed, project_id)
    except Exception as exc:
        logger.error("Failed to store Excel asset: %s", exc)

    if mode == "learn_from_it":
        try:
            _trigger_fir_agent(session, project_id)
        except Exception as exc:
            logger.warning("FIR trigger failed: %s", exc)

    return {
        "status": "success",
        "asset_id": asset_id,
        "filename": file.filename,
        "mode": mode,
        "parsed_summary": parsed.to_dict(),
    }


@router.post("/trigger-learning")
async def trigger_learning(
    asset_id: str = Form(...),
    project_id: str = Form(...),
):
    """Trigger immediate FIR agent processing for a previously uploaded document.

    This endpoint is called when user chooses "Use as Highest-Priority Learning"
    after uploading a file. It invokes the FIR agent synchronously to process
    the document and generate recommendations before returning.
    """
    session = _get_snowflake_session()

    rows = session.sql(
        "SELECT SQL_ASSET_ID FROM TBL_WORKBENCH_CLIENT_SQL_ASSETS WHERE SQL_ASSET_ID = ?",
        [asset_id],
    ).collect()
    if not rows:
        raise HTTPException(404, "Asset not found. Please re-upload the file.")

    try:
        payload = json.dumps({
            "task_type": "document_learning",
            "processing_options": {
                "collect_feedback": True,
                "generate_inferences": True,
                "create_semantic_versions": True,
                "generate_recommendations": True,
                "apply_decay": False,
                "parse_documents": True,
                "precompute_recommendations": True,
                "priority_asset_id": asset_id,
            },
        })
        result = session.sql("CALL SP_FIR_INVOKE_AGENT(PARSE_JSON(?))", [payload]).collect()
        status = "completed"
        details = {}
        if result:
            row = result[0].as_dict() if hasattr(result[0], "as_dict") else {}
            details = row if isinstance(row, dict) else {}
    except Exception as exc:
        logger.error("trigger-learning FIR invocation failed: %s", exc)
        raise HTTPException(502, f"FIR processing failed: {exc}")

    rec_count = 0
    try:
        rec_rows = session.sql("""
            SELECT COUNT(*) AS CNT FROM TBL_FIR_AGENT_RECOMMENDATIONS
            WHERE STATUS = 'active'
              AND APPLICABLE_TABLES IS NOT NULL
              AND CREATED_AT > DATEADD('minute', -5, CURRENT_TIMESTAMP())
        """).collect()
        if rec_rows:
            row = rec_rows[0].as_dict() if hasattr(rec_rows[0], "as_dict") else {}
            rec_count = row.get("CNT", 0)
    except Exception:
        pass

    return {
        "status": status,
        "asset_id": asset_id,
        "recommendations_generated": rec_count,
        "details": details,
    }


def _store_sql_asset(
    session, asset_id: str, filename: str, sql_text: str, project_id: str, parsed: ParsedSqlDocument
) -> None:
    """Store uploaded SQL in TBL_WORKBENCH_CLIENT_SQL_ASSETS."""
    attributes = json.dumps(parsed.to_dict())
    session.sql("""
        MERGE INTO TBL_WORKBENCH_CLIENT_SQL_ASSETS target
        USING (SELECT ? AS SQL_ASSET_ID) source
        ON target.SQL_ASSET_ID = source.SQL_ASSET_ID
        WHEN NOT MATCHED THEN INSERT (
            SQL_ASSET_ID, TITLE, SQL_TEXT, SQL_KIND, DIALECT,
            DESCRIPTION, TAGS, ATTRIBUTES, PROJECT_ID,
            STATUS, CREATED_AT, UPDATED_AT
        ) SELECT ?, ?, ?, 'SELECT', 'snowflake',
                 ?, PARSE_JSON('[]'), PARSE_JSON(?), ?,
                 'active', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
    """, [
        asset_id,
        asset_id, filename, sql_text,
        f"Uploaded SQL: {filename}", attributes, project_id,
    ]).collect()


def _store_excel_asset(
    session, asset_id: str, filename: str, parsed: ParsedExcelMapping, project_id: str
) -> None:
    """Store uploaded Excel mapping in TBL_WORKBENCH_CLIENT_SQL_ASSETS as a mapping document."""
    attributes = json.dumps(parsed.to_dict())
    session.sql("""
        MERGE INTO TBL_WORKBENCH_CLIENT_SQL_ASSETS target
        USING (SELECT ? AS SQL_ASSET_ID) source
        ON target.SQL_ASSET_ID = source.SQL_ASSET_ID
        WHEN NOT MATCHED THEN INSERT (
            SQL_ASSET_ID, TITLE, SQL_TEXT, SQL_KIND, DIALECT,
            DESCRIPTION, TAGS, ATTRIBUTES, PROJECT_ID,
            STATUS, CREATED_AT, UPDATED_AT
        ) SELECT ?, ?, ?, 'MAPPING', 'excel',
                 ?, PARSE_JSON('["excel_mapping"]'), PARSE_JSON(?), ?,
                 'active', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
    """, [
        asset_id,
        asset_id, filename, json.dumps(parsed.to_dict()),
        f"Uploaded mapping: {filename}", attributes, project_id,
    ]).collect()


def _trigger_fir_agent(session, project_id: str) -> None:
    """Trigger immediate FIR agent processing for this upload."""
    payload = json.dumps({
        "task_type": "manual",
        "processing_options": {
            "collect_feedback": True,
            "generate_inferences": True,
            "create_semantic_versions": False,
            "generate_recommendations": True,
            "apply_decay": False,
            "parse_documents": True,
        },
    })
    session.sql("CALL SP_FIR_INVOKE_AGENT(PARSE_JSON(?))", [payload]).collect()
