from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field

from app.agent_runs.models import EffortLevel


class RuntimeInvocation(BaseModel):
    run_id: str
    thread_id: str
    prompt: str
    effort: EffortLevel
    context_refs: list[str] = Field(default_factory=list)
    resume_value: Any | None = None
    is_resume: bool = False
    workflow_input: dict[str, Any] = Field(default_factory=dict)


class RuntimeResult(BaseModel):
    status: str
    safe_summary: str
    assistant_message: str = ""
    output_refs: list[str] = Field(default_factory=list)
    interrupt: dict[str, Any] | None = None
    workflow_state: dict[str, Any] = Field(default_factory=dict)
    model_calls_used: int = 0
    tool_calls_used: int = 0
    budget_usage: dict[str, int] = Field(default_factory=dict)


class AgentRuntime(ABC):
    """Framework-neutral supervisor boundary; no Deep Agents types leak out."""

    @abstractmethod
    def invoke(self, invocation: RuntimeInvocation) -> RuntimeResult: ...

    @abstractmethod
    async def ainvoke(self, invocation: RuntimeInvocation) -> RuntimeResult: ...

    @abstractmethod
    def cancel(self, run_id: str) -> None: ...
