import { format } from 'sql-formatter';

/** Presentation only. Never use formatted text as an execution/identity contract. */
export function formatSqlForDisplay(sql: string): string {
  if (!sql.trim()) return sql;
  try {
    return format(sql, {
      language: 'snowflake',
      tabWidth: 2,
      keywordCase: 'preserve',
      dataTypeCase: 'preserve',
      functionCase: 'preserve',
      identifierCase: 'preserve',
      linesBetweenQueries: 1,
      expressionWidth: 60,
    });
  } catch {
    // Incomplete user edits and unsupported scripting must remain intact.
    return sql;
  }
}