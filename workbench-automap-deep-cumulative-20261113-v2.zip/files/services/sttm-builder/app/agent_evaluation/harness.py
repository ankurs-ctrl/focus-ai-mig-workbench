from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from app.agent_runs.models import AgentRun, AgentRunEvent


class EvaluationFinding(BaseModel):
    evaluator: str
    passed: bool
    score: float = Field(ge=0.0, le=1.0)
    summary: str
    evidence: dict[str, Any] = Field(default_factory=dict)


class EvaluationReport(BaseModel):
    run_id: str
    agent_version: str
    prompt_version: str
    passed: bool
    score: float = Field(ge=0.0, le=1.0)
    findings: list[EvaluationFinding]


class AgentEvaluationHarness:
    """Self-hosted deterministic trajectory gates used by offline and online evals."""

    def evaluate(
        self,
        run: AgentRun,
        events: list[AgentRunEvent],
        *,
        agent_version: str = "deep-agent-1",
        prompt_version: str = "supervisor-1",
    ) -> EvaluationReport:
        ordered = sorted(events, key=lambda event: event.sequence)
        sequences = [event.sequence for event in ordered]
        event_types = [event.event_type for event in ordered]
        findings = [
            self._finding(
                "event_continuity",
                sequences == list(range(1, len(sequences) + 1)),
                "Run events have a contiguous committed cursor." if sequences == list(range(1, len(sequences) + 1)) else "Run events contain a cursor gap or duplicate.",
                {"sequences": sequences},
            ),
            self._finding(
                "budget_compliance",
                run.model_calls_used <= run.policy.model_call_budget and run.tool_calls_used <= run.policy.tool_call_budget,
                "Model and tool calls remained within the hard run budget.",
                {"model_calls": run.model_calls_used, "tool_calls": run.tool_calls_used},
            ),
            self._finding(
                "truthful_activity",
                any(value.startswith(("tool.", "subagent.", "trace.")) for value in event_types),
                "The trajectory contains typed execution activity.",
                {"event_types": event_types},
            ),
            self._finding(
                "publish_policy",
                not any(value in {"tool.publish.completed", "run.published"} for value in event_types),
                "No autonomous publish event occurred.",
            ),
            self._question_quality(ordered),
            self._plan_completion(ordered),
            self._terminal_quality(ordered),
        ]
        score = sum(item.score for item in findings) / len(findings)
        return EvaluationReport(
            run_id=run.run_id,
            agent_version=agent_version,
            prompt_version=prompt_version,
            passed=all(item.passed for item in findings),
            score=score,
            findings=findings,
        )

    @staticmethod
    def _finding(evaluator: str, passed: bool, summary: str, evidence: dict[str, Any] | None = None) -> EvaluationFinding:
        return EvaluationFinding(evaluator=evaluator, passed=passed, score=1.0 if passed else 0.0, summary=summary, evidence=evidence or {})

    def _question_quality(self, events: list[AgentRunEvent]) -> EvaluationFinding:
        questions = [event for event in events if event.event_type == "run.question.required"]
        valid = all(
            isinstance(event.data.get("choices"), list)
            and len(event.data["choices"]) >= 2
            and bool(event.data.get("recommended_choice_id"))
            for event in questions
        )
        return self._finding(
            "clarification_quality",
            valid,
            "Every clarification includes ranked options and a recommendation." if valid else "A clarification is missing usable options or a recommendation.",
            {"question_count": len(questions)},
        )

    def _terminal_quality(self, events: list[AgentRunEvent]) -> EvaluationFinding:
        terminal = [event for event in events if event.event_type in {"assistant.final", "run.failed", "run.cancelled"}]
        valid = len(terminal) == 1 and bool(terminal[0].safe_summary.strip())
        return self._finding(
            "terminal_integrity",
            valid,
            "The run has one factual terminal result." if valid else "The run is missing a unique factual terminal result.",
            {"terminal_events": [event.event_type for event in terminal]},
        )

    def _plan_completion(self, events: list[AgentRunEvent]) -> EvaluationFinding:
        plans = [event for event in events if event.event_type == "plan.updated"]
        if not plans:
            return self._finding(
                "plan_completion",
                True,
                "The trajectory did not require a persisted multi-step plan.",
            )
        todos = plans[-1].data.get("details", {}).get("todos", [])
        valid = bool(todos) and all(
            str(todo.get("status") or "").lower() == "completed"
            for todo in todos
            if isinstance(todo, dict)
        )
        return self._finding(
            "plan_completion",
            valid,
            "The latest generated plan is complete."
            if valid
            else "The run terminated with unfinished generated plan items.",
            {"todos": todos},
        )
