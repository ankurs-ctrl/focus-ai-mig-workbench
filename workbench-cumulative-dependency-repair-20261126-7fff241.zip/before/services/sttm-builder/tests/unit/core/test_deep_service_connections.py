from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import Mock
import threading

import pytest
from snowflake.snowpark.exceptions import SnowparkSQLException

from app.agent_runs.service_connections import ServiceConnection, ServiceConnectionError, session_expired, sql_diagnostics
from app.agent_runs.recovery import failure_code, can_resume
from app.agent_runs.repository import InMemoryAgentRunRepository, SnowflakeAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.agent_runs.models import AgentActor, RunCreateRequest, RunStatus
from app.agent_runs.worker import AgentWorker


def expired():
    return SnowparkSQLException('Authentication token has expired.', error_code='1304', sql_error_code=390114)


def client(*outcomes):
    value = Mock()
    value.session.sql.return_value.collect.side_effect = list(outcomes)
    return value


def test_wrapped_native_expiry_wins_over_wrapper_and_is_not_a_user_login_error():
    error = RuntimeError('checkpoint read failed')
    error.__cause__ = expired()
    assert session_expired(error)
    assert sql_diagnostics(error) == {'native_code': '390114', 'wrapper_code': '1304'}
    assert failure_code(error) == 'transient_failure'
    assert not session_expired(SnowparkSQLException('Bad SQL', error_code='1304', sql_error_code=904))


def test_read_reconnects_with_current_factory_and_revalidates_lease():
    old, new = client(expired()), client([{'VALUE': 7}], [{'VALUE': 8}])
    factory = Mock(side_effect=[old, new])
    connection = ServiceConnection(factory, 'checkpoint', sleep=Mock())
    guard = Mock()
    connection.set_lease_check(guard, 'run-1')
    retained_session = connection.session
    assert retained_session.sql('SELECT VALUE FROM CHECKPOINTS').collect() == [{'VALUE': 7}]
    guard.assert_called_once()
    old.close.assert_called_once()
    assert retained_session is connection.session
    assert retained_session.sql('SELECT VALUE FROM CHECKPOINTS').collect() == [{'VALUE': 8}]
    assert factory.call_count == 2


def test_lost_lease_prevents_retry_on_replacement_session():
    from app.agent_runtime.execution import ExecutionLeaseLostError
    old, new = client(expired()), client([])
    connection = ServiceConnection(Mock(side_effect=[old, new]), 'checkpoint')
    connection.set_lease_check(Mock(side_effect=ExecutionLeaseLostError('Lost lease')))
    with pytest.raises(ExecutionLeaseLostError):
        connection.sql('SELECT * FROM CHECKPOINTS').collect()
    new.session.sql.assert_not_called()


@pytest.mark.parametrize('sql', ['CALL SP_WRITE_CHECKPOINT()', 'UPDATE RUNS SET STATUS=1', 'COMMIT'])
def test_expired_writes_are_never_replayed(sql):
    old, new = client(expired()), client([])
    factory = Mock(side_effect=[old, new])
    connection = ServiceConnection(factory, 'checkpoint')
    with pytest.raises(ServiceConnectionError) as caught:
        connection.sql(sql).collect()
    assert caught.value.uncertain
    assert caught.value.error_code == 'service_connection_uncertain'
    assert factory.call_count == 1
    with pytest.raises(ServiceConnectionError):
        connection.sql('SELECT 1').collect()
    connection.recover()
    assert connection.sql('SELECT 1').collect() == []
    assert old.session.sql.call_count == 1


def test_read_in_failed_transaction_is_not_retried_outside_that_transaction():
    old = client([], expired())
    factory = Mock(return_value=old)
    connection = ServiceConnection(factory, 'run_repository')
    connection.sql('BEGIN').collect()
    with pytest.raises(ServiceConnectionError) as caught:
        connection.sql('SELECT * FROM RUNS').collect()
    assert caught.value.uncertain and factory.call_count == 1


def test_reconnect_exhaustion_is_bounded_and_sticky_until_coordinated_recovery():
    factory = Mock(side_effect=expired())
    sleep = Mock()
    connection = ServiceConnection(factory, 'checkpoint', sleep=sleep)
    with pytest.raises(ServiceConnectionError):
        connection.sql('SELECT 1').collect()
    assert factory.call_count == 3
    assert [call.args[0] for call in sleep.call_args_list] == [1, 2]


def test_permission_failure_is_not_reconnected_or_masked():
    failure = SnowparkSQLException('Not authorized', error_code='1304', sql_error_code=3001)
    factory = Mock(return_value=client(failure))
    with pytest.raises(SnowparkSQLException):
        ServiceConnection(factory, 'checkpoint').sql('SELECT 1').collect()
    assert factory.call_count == 1


def test_stage_read_can_reconnect_but_stage_write_cannot_replay():
    old, new = client(), client()
    old.session.file.get_stream.side_effect = expired()
    new.session.file.get_stream.return_value = 'stream'
    owner = ServiceConnection(Mock(side_effect=[old, new]), 'checkpoint')
    assert owner.file.get_stream('@stage/object') == 'stream'
    new.session.file.put_stream.side_effect = expired()
    with pytest.raises(ServiceConnectionError) as caught:
        owner.file.put_stream('payload', '@stage/object')
    assert caught.value.uncertain
    new.session.file.put_stream.assert_called_once()


def test_close_waits_for_in_use_connection():
    entered, finish, closed = threading.Event(), threading.Event(), threading.Event()
    current = client()
    def collect():
        entered.set()
        assert finish.wait(2)
        return []
    current.session.sql.return_value.collect.side_effect = collect
    owner = ServiceConnection(lambda: current, 'heartbeat')
    running = threading.Thread(target=lambda: owner.sql('SELECT 1').collect())
    running.start()
    assert entered.wait(2)
    closer = threading.Thread(target=lambda: (owner.close(), closed.set()))
    closer.start()
    assert not closed.wait(.05)
    finish.set()
    running.join(2); closer.join(2)
    assert closed.is_set()
    current.close.assert_called_once()


def test_real_checkpoint_saver_uses_replacement_session_without_stale_reference():
    from app.agent_runs.checkpoint import SnowflakeStageCheckpointSaver
    old, new = client(expired()), client([], [])
    owner = ServiceConnection(Mock(side_effect=[old, new]), 'checkpoint')
    saver = SnowflakeStageCheckpointSaver(owner.session)
    assert saver.get_tuple({'configurable': {'thread_id': 'thread-1'}}) is None
    assert saver.get_tuple({'configurable': {'thread_id': 'thread-2'}}) is None
    assert new.session.sql.call_count == 2
    old.close.assert_called_once()


def run_fixture():
    repo = InMemoryAgentRunRepository()
    run = AgentRunService(repo).create_run(RunCreateRequest(prompt='Create an isolated draft'),
        AgentActor(app_user_id='audit', snowflake_username='AUDIT', effective_role='ROLE'))
    return repo, run


def test_service_failure_recovers_connections_and_never_asks_user_to_sign_in():
    repo, run = run_fixture()
    recovered = Mock()
    factory = Mock(side_effect=ServiceConnectionError('checkpoint', 'read'))
    worker = AgentWorker(repo, None, worker_id='worker', runtime_factory=factory,
                         service_connection_recovery=recovered)
    assert worker.run_once()
    recovered.assert_called_once()
    stored = repo.get_run(run.run_id)
    assert stored.status is RunStatus.FAILED
    assert stored.error_code == 'service_connection_unavailable'
    assert 'sign in' not in stored.safe_error.lower()
    assert not repo.list_review_items(run.run_id)
    assert factory.call_count == 1


def test_checkpoint_write_failure_does_not_reinvoke_model_or_allow_blind_resume():
    repo, run = run_fixture()
    runtime = Mock()
    runtime.invoke.side_effect = ServiceConnectionError('checkpoint', 'write', uncertain=True)
    runtime.usage_snapshot.return_value = (1, 0)
    runtime.budget_snapshot.return_value = {}
    worker = AgentWorker(repo, None, worker_id='worker', runtime_factory=lambda run: (runtime, lambda: None),
                         service_connection_recovery=Mock())
    assert worker.run_once()
    stored = repo.get_run(run.run_id)
    assert stored.error_code == 'service_connection_uncertain'
    assert not can_resume(stored)
    assert runtime.invoke.call_count == 1
    assert not worker.run_once()


def test_recovery_lease_loss_does_not_save_failure_using_old_ownership():
    from app.agent_runtime.execution import ExecutionLeaseLostError
    repo, run = run_fixture()
    worker = AgentWorker(repo, None, worker_id='worker',
        runtime_factory=Mock(side_effect=ServiceConnectionError('checkpoint', 'read')),
        service_connection_recovery=Mock(side_effect=ExecutionLeaseLostError('Lease moved')))
    with pytest.raises(ExecutionLeaseLostError):
        worker.run_once()
    assert repo.get_run(run.run_id).status is not RunStatus.FAILED


def test_heartbeat_expiry_is_recovered_and_fenced_before_continuing():
    from app.agent_runtime.interface import RuntimeResult
    repo, run = run_fixture()
    heartbeat = Mock(wraps=repo)
    restored = threading.Event()
    recovered = Mock(side_effect=restored.set)
    heartbeat.renew_lease.side_effect = [ServiceConnectionError('heartbeat', 'write', uncertain=True), True]
    class Runtime:
        def set_cancellation_check(self, check): self.check = check
        def invoke(self, invocation):
            assert restored.wait(2)
            assert self.check() is None
            return RuntimeResult(status='COMPLETED', safe_summary='Done', assistant_message='Done',
                                 workflow_state={'status': 'COMPLETED'})
    worker = AgentWorker(repo, None, worker_id='worker', runtime_factory=lambda run: (Runtime(), lambda: None),
        heartbeat_repository=heartbeat, heartbeat_connection_recovery=recovered)
    worker.heartbeat_seconds = .01
    assert worker.run_once()
    assert repo.get_run(run.run_id).status is RunStatus.COMPLETED
    recovered.assert_called_once()
    assert heartbeat.renew_lease.call_count == 2


def test_heartbeat_reconnect_with_moved_lease_prevents_another_renewal():
    from app.agent_runtime.interface import RuntimeResult
    repo, run = run_fixture()
    heartbeat = Mock(wraps=repo)
    heartbeat.renew_lease.side_effect = ServiceConnectionError('heartbeat', 'write', uncertain=True)
    def moved():
        current = repo.get_run(run.run_id)
        current.lease_owner = 'other-worker'
        repo.save_run(current)
    class Runtime:
        def invoke(self, invocation):
            import time
            time.sleep(.05)
            return RuntimeResult(status='COMPLETED', safe_summary='Done', workflow_state={'status': 'COMPLETED'})
    worker = AgentWorker(repo, None, worker_id='worker', runtime_factory=lambda run: (Runtime(), lambda: None),
        heartbeat_repository=heartbeat, heartbeat_connection_recovery=moved)
    worker.heartbeat_seconds = .01
    worker.run_once()
    assert heartbeat.renew_lease.call_count == 1
    assert repo.get_run(run.run_id).status is not RunStatus.COMPLETED
