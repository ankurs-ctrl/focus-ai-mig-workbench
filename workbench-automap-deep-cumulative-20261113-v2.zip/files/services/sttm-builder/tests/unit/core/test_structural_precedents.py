"""Phase 3: relationship learnings reused across structurally identical schemas."""
from __future__ import annotations

from typing import Any

from app.agent_tools.structural_precedents import (
    learning_attributes,
    parse_relationship_learning,
    retarget_cte_sql,
    tables_needing_contracts,
    translate_learnings,
)


def test_a_precedent_cte_is_reused_over_the_current_copies_of_its_tables() -> None:
    sql = ("SELECT a.CONTACT_ID, MAX(a.CITY) AS CITY FROM OLD_DB.EVERNEST.ADDRESSES a "
           "JOIN prior_cte p ON p.ID = a.CONTACT_ID WHERE a.TYPE = 'HOME' GROUP BY a.CONTACT_ID")
    current = ["DB.SCH_TMD_SOURCE.ADDRESSES", "DB.SCH_TMD_SOURCE.CONTACTS"]
    adapted = retarget_cte_sql(sql, current, cte_names=["PRIOR_CTE"])
    assert adapted is not None
    rewritten, mapping = adapted
    assert "DB.SCH_TMD_SOURCE.ADDRESSES" in rewritten and "OLD_DB" not in rewritten
    assert "prior_cte" in rewritten.lower() and "'HOME'" in rewritten and "GROUP BY" in rewritten
    assert mapping == {"OLD_DB.EVERNEST.ADDRESSES": "DB.SCH_TMD_SOURCE.ADDRESSES"}
    # No current copy, or two candidate copies: the CTE is not adapted.
    assert retarget_cte_sql(sql, ["DB.SCH_TMD_SOURCE.CONTACTS"], cte_names=["PRIOR_CTE"]) is None
    assert retarget_cte_sql(sql, [*current, "DB.OTHER.ADDRESSES"], cte_names=["PRIOR_CTE"]) is None


def _contract(*columns: str) -> dict[str, Any]:
    return {"columns": list(columns), "key_columns": ["ID"],
            "column_contracts": [{"name": name, "type": "NUMBER(38,0)" if name.endswith("ID") else "VARCHAR(255)",
                                  "nullable": True} for name in columns]}


_SHAPES = {
    "CONTACTS": _contract("ID", "CATEGORY_ID", "STATUS_ID", "DELETED"),
    "CONTACT_CATEGORIES": _contract("ID", "NAME"),
    "CONTACT_STATUSES": _contract("ID", "NAME", "DELETED"),
    "CONTACT_FAMILIES": _contract("ID", "NAME"),
    "CONTACT_FAMILY_MEMBERS": _contract("ID", "FAMILY_ID", "CONTACT_ID"),
    "COUNTRY_CODES": _contract("CODE", "NAME"),
}
_OLD = {f"DB.SCH_EVERNEST_HH_SOURCE.{name}": contract for name, contract in _SHAPES.items()}
_NEW = {f"DB.SCH_TMD_SOURCE.{name}": contract for name, contract in _SHAPES.items()}


def _legacy(learning_id: str, left: str, right: str, condition: str) -> dict[str, Any]:
    """The exact shape currently stored by the mapping knowledge projector."""
    table = "{'database': 'DB', 'schema': 'SCH_EVERNEST_HH_SOURCE', 'table': '%s'}"
    return {"learning_id": learning_id, "confidence": 1.0, "trust_stage": None,
            "attributes": {"left_table": table % left, "right_table": table % right, "condition": condition}}


def _translate(rows):
    learnings = [item for item in (parse_relationship_learning(row) for row in rows) if item]
    originals = {table: _OLD[table] for table in tables_needing_contracts(learnings) if table in _OLD}
    return translate_learnings(learnings, _NEW, originals)


def test_legacy_learnings_transfer_to_the_identically_shaped_schema() -> None:
    claims = _translate([_legacy("a", "CONTACT_FAMILY_MEMBERS", "CONTACT_FAMILIES",
                                 '[{"left_column":"family_id","operator":"=","right_column":"id"}]')])
    assert claims == [("structural_precedent", {
        "left_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILY_MEMBERS", "right_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILIES",
        "conditions": [{"left_column": "FAMILY_ID", "right_column": "ID", "operator": "="}],
        # A legacy, unstaged learning only suggests the candidate (trust factor 0.6).
        "literal_filters": [], "user_confirmed": False, "confidence": 0.6, "source": "STRUCTURAL_PRECEDENT",
        "evidence_ids": ["learning:a"],
        "translated_from": ["DB.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILY_MEMBERS", "DB.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILIES"],
    })]


def test_reversed_column_order_is_repaired_and_impossible_claims_are_dropped() -> None:
    claims = _translate([
        # Stored as CONTACTS.id = CONTACT_CATEGORIES.category_id (columns swapped).
        _legacy("swapped", "CONTACTS", "CONTACT_CATEGORIES",
                '[{"left_column":"id","operator":"=","right_column":"category_id"}]'),
        # CONTACT_STATUSES has no FAMILY_ID: the stored "confidence 1" join is wrong.
        _legacy("bogus", "CONTACTS", "CONTACT_STATUSES",
                '[{"left_column":"deleted","operator":"=","right_column":"family_id"}]'),
        _legacy("alias", "COUNTRY_CODES", "CONTACT_CATEGORIES",
                '[{"left_column":"billing_country","operator":"=","right_column":"COUNTRY_ALIAS"}]'),
    ])
    assert [relationship["conditions"] for _, relationship in claims] == [
        [{"left_column": "CATEGORY_ID", "right_column": "ID", "operator": "="}]]
    assert claims[0][1]["evidence_ids"] == ["learning:swapped"]


def test_a_structurally_different_table_is_not_a_precedent() -> None:
    changed = dict(_NEW)
    changed["DB.SCH_TMD_SOURCE.CONTACT_FAMILIES"] = _contract("ID", "NAME", "EXTRA_COLUMN")
    learnings = [parse_relationship_learning(_legacy(
        "a", "CONTACT_FAMILY_MEMBERS", "CONTACT_FAMILIES", '[{"left_column":"family_id","right_column":"id"}]'))]
    originals = {table: _OLD[table] for table in tables_needing_contracts(learnings)}
    assert translate_learnings(learnings, changed, originals) == []


def test_same_schema_learning_is_direct_learning_evidence() -> None:
    row = {"learning_id": "b", "confidence": 0.9, "trust_stage": "outcome", "attributes": {
        "left_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILY_MEMBERS", "right_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILIES",
        "conditions": [{"left_column": "FAMILY_ID", "right_column": "ID"}]}}
    learnings = [parse_relationship_learning(row)]
    originals = {table: _NEW[table] for table in tables_needing_contracts(learnings)}
    claims = translate_learnings(learnings, _NEW, originals)
    assert [kind for kind, _ in claims] == ["learning"]


def test_written_attributes_are_structured_and_fingerprinted() -> None:
    attributes = learning_attributes({
        "left_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILY_MEMBERS", "right_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILIES",
        "conditions": [{"left_column": "FAMILY_ID", "right_column": "ID", "operator": "="}],
    }, _NEW)
    assert attributes["left_table"] == "DB.SCH_TMD_SOURCE.CONTACT_FAMILY_MEMBERS"
    assert attributes["conditions"] == [{"left_column": "FAMILY_ID", "right_column": "ID"}]
    assert len(attributes["left_fingerprint"]) == 32 and attributes["right_fingerprint"]
    # A learning written this way transfers without reading the original tables.
    learning = parse_relationship_learning({"learning_id": "c", "confidence": 1.0, "attributes": attributes})
    assert tables_needing_contracts([learning]) == []


def _handlers(learning):
    import threading
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handlers = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handlers._learning = learning
    handlers._domain_lock = threading.RLock()
    handlers._tool = lambda _name: None
    events = []
    handlers._emit = lambda event_type, status, summary, **data: events.append((event_type, summary, data))
    described = []

    def describe(tables):
        described.append(sorted(tables))
        return {table: {**_OLD, **_NEW}[table] for table in tables if table in {**_OLD, **_NEW}}

    handlers._describe_tables = describe
    return handlers, events, described


def test_graph_receives_translated_learnings_and_reads_only_unfingerprinted_originals() -> None:
    class _Learning:
        def __init__(self):
            self.names = None

        def get_relationship_learnings(self, *, table_names, budget):
            self.names = table_names
            return [_legacy("a", "CONTACT_FAMILY_MEMBERS", "CONTACT_FAMILIES",
                            '[{"left_column":"family_id","right_column":"id"}]'),
                    _legacy("bogus", "CONTACTS", "CONTACT_STATUSES",
                            '[{"left_column":"deleted","right_column":"family_id"}]')]

    learning = _Learning()
    handlers, events, described = _handlers(learning)
    claims = handlers._relationship_learning_claims(dict(_NEW))
    assert "CONTACT_FAMILIES" in learning.names and all("." not in name for name in learning.names)
    assert described == [sorted({"DB.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILY_MEMBERS",
                                 "DB.SCH_EVERNEST_HH_SOURCE.CONTACT_FAMILIES",
                                 "DB.SCH_EVERNEST_HH_SOURCE.CONTACTS",
                                 "DB.SCH_EVERNEST_HH_SOURCE.CONTACT_STATUSES"})]
    assert [(kind, item["left_table"]) for kind, item in claims] == [
        ("structural_precedent", "DB.SCH_TMD_SOURCE.CONTACT_FAMILY_MEMBERS")]
    assert "Reused 1 join(s) from 2" in events[-1][1]


def test_learning_reader_failure_never_blocks_the_graph() -> None:
    class _Broken:
        def get_relationship_learnings(self, **_kwargs):
            raise RuntimeError("warehouse unavailable")

    handlers, _, _ = _handlers(_Broken())
    assert handlers._relationship_learning_claims(dict(_NEW)) == []


def test_confirmed_joins_are_written_back_as_validated_fingerprinted_learnings() -> None:
    class _Writer:
        def __init__(self):
            self.items = []

        def record_relationship_learning(self, **kwargs):
            self.items.append(kwargs)
            return "lrn_1"

    writer = _Writer()
    handlers, events, _ = _handlers(writer)
    join = {"left_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILY_MEMBERS", "right_table": "DB.SCH_TMD_SOURCE.CONTACT_FAMILIES",
            "conditions": [{"left_column": "FAMILY_ID", "right_column": "ID", "operator": "="}],
            "source": "USER_CONFIRMED_JOIN_RULE"}
    state = {"run_id": "run_1", "actor_user_id": "u1", "tenant_id": "t", "effective_role": "R"}
    assert handlers.record_confirmed_relationships(state, [join]) == 1
    item = writer.items[0]
    assert item["trust_stage"] == "validated" and item["user_id"] == "u1"
    assert item["attributes"]["left_fingerprint"] and item["attributes"]["provenance"] == "user_confirmed_join"
    # The stored learning is immediately reusable on another identically shaped schema.
    stored = parse_relationship_learning({"learning_id": "lrn_1", "confidence": 1.0, "trust_stage": "validated",
                                          "attributes": item["attributes"]})
    assert tables_needing_contracts([stored]) == []
    moved = {name.replace("SCH_TMD_SOURCE", "SCH_NEW_CLIENT"): contract for name, contract in _NEW.items()}
    assert [claim["confidence"] for _, claim in translate_learnings([stored], moved, {})] == [1.0]


def test_precedent_finder_binds_every_input_and_explains_each_match() -> None:
    import json
    from app.core.project_service import ProjectService

    calls = []

    class _Rows:
        def __init__(self, rows): self._rows = rows
        def collect(self): return self._rows

    class _Session:
        def sql(self, query, params=None):
            calls.append((query, params))
            return _Rows([{"PROJECT_ID": "4", "PROJECT_NAME": "EverNest Redtail CRM Migration", "EXACT_TARGET": 0,
                           "SAME_TARGET_NAME": 0, "SHARED_SOURCES": 4, "PUBLISHED": 1, "MAPPINGS": 21,
                           "MAPPINGS_WITH_SQL": 12, "TEXT_HITS": 0}])

    class _Service(ProjectService):
        _sttm_table = "DB.META.TBL_STTM"
        _sources_table = "DB.META.TBL_STTM_SOURCES"
        _projects_table = "DB.META.TBL_PROJECTS"

    service = _Service.__new__(_Service)
    service._session = _Session()
    service._table_column_cache = {"DB.META.TBL_STTM": {"STATUS", "AGENT_EXTERNAL_KEY"}}
    ranked = service.find_precedent_projects(
        target_tables=["db.aia_wb_target.household"],
        source_tables=["DB.SCH_TMD_SOURCE.CONTACTS", "DB.SCH_TMD_SOURCE.CONTACT_FAMILIES"],
        terms=["tmd", "x", "O'Brien"], limit=5)
    query, params = calls[0]
    # No user value is interpolated into SQL text.
    assert "CONTACTS" not in query and "O'BRIEN" not in query and "HOUSEHOLD" not in query
    # The agent's own unreviewed drafts are never precedents.
    assert "NOT LIKE 'deep-draft:%'" in query
    assert json.loads(params[0]) == ["CONTACTS", "CONTACT_FAMILIES"]
    assert json.loads(params[1]) == ["DB.AIA_WB_TARGET.HOUSEHOLD"] and json.loads(params[2]) == ["HOUSEHOLD"]
    assert json.loads(params[3]) == ["O'BRIEN", "TMD"] and params[4] == 5
    assert ranked[0]["shared_source_tables"] == 4 and ranked[0]["mappings_with_sql"] == 12
    assert ranked[0]["reasons"] == ["4 source table(s) with the same names", "has published mappings",
                                    "12 mapping(s) with executable SQL"]


def test_search_precedents_tool_returns_ranked_projects_with_reasons() -> None:
    from types import SimpleNamespace

    handlers, _, _ = _handlers(None)
    seen = {}

    def finder(**kwargs):
        seen.update(kwargs)
        return [{"project_id": "4", "project_name": "EverNest", "reasons": ["4 source table(s) with the same names"]}]

    handlers._projects = SimpleNamespace(find_precedent_projects=finder)
    result = handlers.search_precedents(query="use learnings from the Evernest migration",
                                        source_tables=["DB.S.CONTACTS"], target_tables=["DB.T.HOUSEHOLD"])
    assert result.status == "succeeded" and result.data["projects"][0]["project_id"] == "4"
    # Generic request words would match almost every project name.
    assert seen["terms"] == ["Evernest"]
    assert "best: EverNest" in result.summary


def test_same_named_signatures_finds_copies_in_any_schema_with_one_query() -> None:
    from app.agent_tools.contract_reader import same_named_signatures

    calls = []

    class _Rows:
        def __init__(self, rows): self._rows = rows
        def collect(self): return self._rows

    def sql(query, params=None):
        calls.append((query, params))
        return _Rows([
            {"TABLE_SCHEMA": "OLD_CLIENT", "TABLE_NAME": "CONTACTS", "SIGNATURE": "a"},
            {"TABLE_SCHEMA": "NEW_CLIENT", "TABLE_NAME": "CONTACTS", "SIGNATURE": "a"},
            {"TABLE_SCHEMA": "NEW_CLIENT", "TABLE_NAME": "USERS", "SIGNATURE": "z"},
        ])

    found = same_named_signatures(sql, ["DB.OLD_CLIENT.CONTACTS", "DB.OLD_CLIENT.USERS"])
    assert len(calls) == 1
    query, params = calls[0]
    assert params == ["CONTACTS", "USERS"] and "OLD_CLIENT" not in query
    assert found["DB.OLD_CLIENT.CONTACTS"] == {"DB.OLD_CLIENT.CONTACTS": "a", "DB.NEW_CLIENT.CONTACTS": "a"}
    assert found["DB.OLD_CLIENT.USERS"] == {"DB.NEW_CLIENT.USERS": "z"}


def test_schema_counterparts_rank_identical_copies_and_report_differences() -> None:
    from app.agent_tools.structural_precedents import schema_counterparts

    same_named = {
        "DB.OLD.CONTACTS": {"DB.OLD.CONTACTS": "c", "DB.NEW.CONTACTS": "c", "DB.OTHER.CONTACTS": "x", "DB.TGT.CONTACTS": "c"},
        "DB.OLD.USERS": {"DB.OLD.USERS": "u", "DB.NEW.USERS": "changed"},
        "DB.OLD.SOURCES": {"DB.OLD.SOURCES": "s", "DB.NEW.SOURCES": "s", "DB.OTHER.SOURCES": "s"},
        "DB.OLD.CODES": {"DB.OLD.CODES": "k"},
    }
    ranked = schema_counterparts(list(same_named), same_named, exclude_schemas=["DB.TGT"])
    assert [item["schema"] for item in ranked] == ["DB.NEW", "DB.OTHER"]
    new = ranked[0]
    assert new["identical_count"] == 2 and new["historical_table_count"] == 4
    assert {item["current_table"] for item in new["identical"]} == {"DB.NEW.CONTACTS", "DB.NEW.SOURCES"}
    assert new["different_columns"] == [{"historical_table": "DB.OLD.USERS", "current_table": "DB.NEW.USERS"}]
    assert new["missing"] == ["DB.OLD.CODES"]


def test_precedent_search_fills_omitted_arguments_from_the_run() -> None:
    from app.agent_tools.capability_registry import CapabilityRegistry

    registry = CapabilityRegistry.__new__(CapabilityRegistry)
    import threading
    registry._catalog_lock = threading.Lock()
    registry._catalog_candidates = {"DB.TGT.HOUSEHOLD", "DB.SRC.CONTACTS", "DB.OTHER.HOUSEHOLD"}
    registry._context_provider = lambda: {"prompt": "Map HOUSEHOLD from SRC like the Evernest work",
                                          "prompt_named_targets": ["TGT.HOUSEHOLD"]}
    query, sources, targets = registry._precedent_search_defaults("", [], [])
    assert query.startswith("Map HOUSEHOLD")
    assert targets == ["DB.TGT.HOUSEHOLD"]
    assert sources == ["DB.SRC.CONTACTS"]
    # Explicit arguments are never replaced.
    assert registry._precedent_search_defaults("x", ["A.B.C"], ["A.B.T"]) == ("x", ["A.B.C"], ["A.B.T"])


def test_counterparts_named_in_the_request_rank_first() -> None:
    from app.agent_tools.structural_precedents import schema_counterparts

    tables = [f"DB.OLD.T{i}" for i in range(9)]
    same_named = {table: {table: "s", table.replace("DB.OLD.", "DB.OTHER_CLIENT."): "s",
                          **({table.replace("DB.OLD.", "DB.SCH_NEW_SOURCE."): "s"} if i < 7 else {})}
                  for i, table in enumerate(tables)}
    ranked = schema_counterparts(tables, same_named, requested_text="Create HOUSEHOLD from sch_new_source please")
    assert [item["schema"] for item in ranked] == ["DB.SCH_NEW_SOURCE", "DB.OTHER_CLIENT"]
    assert ranked[0]["named_in_request"] is True and ranked[1]["named_in_request"] is False
    # A UI selection counts the same as naming the schema.
    selected = schema_counterparts(tables, same_named, selected_scope=["DB.SCH_NEW_SOURCE.T1"])
    assert selected[0]["schema"] == "DB.SCH_NEW_SOURCE"
    # A schema named only as part of a longer word does not count.
    assert schema_counterparts(tables, same_named, requested_text="XSCH_NEW_SOURCE")[0]["schema"] == "DB.OTHER_CLIENT"


def test_unreviewed_agent_drafts_are_not_precedents_but_published_ones_are() -> None:
    from app.core.project_service import ProjectService

    class _Service(ProjectService):
        _sttm_table = "DB.META.TBL_STTM"

    service = _Service.__new__(_Service)
    service._table_column_cache = {"DB.META.TBL_STTM": {"STATUS", "AGENT_EXTERNAL_KEY"}}
    predicate = service._reviewed_mapping_predicate("s")
    assert "s.AGENT_EXTERNAL_KEY" in predicate and "'PUBLISHED'" in predicate
    # Older metadata tables without the column keep every mapping.
    service._table_column_cache = {"DB.META.TBL_STTM": {"STATUS"}}
    assert service._reviewed_mapping_predicate("s") == "TRUE"


def _confirmed(learning_id: str, left: str, right: str, left_column: str, right_column: str,
               *, alternative: str = "", confirmed: bool = True) -> dict[str, Any]:
    from app.agent_tools.contract_reader import contract_fingerprint

    return {"learning_id": learning_id, "confidence": 1.0, "trust_stage": "validated", "attributes": {
        "left_table": f"DB.SCH_EVERNEST_HH_SOURCE.{left}", "right_table": f"DB.SCH_EVERNEST_HH_SOURCE.{right}",
        "conditions": [{"left_column": left_column, "right_column": right_column}],
        "left_fingerprint": contract_fingerprint(_SHAPES[left]), "right_fingerprint": contract_fingerprint(_SHAPES[right]),
        **({"normalized_lookup_alternative": alternative} if alternative else {}),
        "provenance": "user_confirmed_join" if confirmed else "precedent"}}


def _remembering_handlers(rows):
    from types import SimpleNamespace

    handlers, _, _ = _handlers(None)
    handlers._learning = SimpleNamespace(get_relationship_learnings=lambda **_kwargs: rows)
    handlers._describe_tables = lambda tables: {table: _NEW[table] for table in tables if table in _NEW}
    return handlers


def test_a_join_confirmed_on_another_clients_identical_tables_is_reused_with_its_lookup_alternative() -> None:
    handlers = _remembering_handlers([
        _confirmed("c1", "CONTACTS", "COUNTRY_CODES", "CATEGORY_ID", "CODE", alternative="NAME"),
    ])
    remembered = handlers.remembered_join_paths(
        {"run_id": "r"}, ["DB.SCH_TMD_SOURCE.COUNTRY_CODES"], ["DB.SCH_TMD_SOURCE.CONTACTS"])
    join = remembered["DB.SCH_TMD_SOURCE.COUNTRY_CODES"]["joins"][0]
    assert join["left_table"] == "DB.SCH_TMD_SOURCE.CONTACTS" and join["right_table"] == "DB.SCH_TMD_SOURCE.COUNTRY_CODES"
    assert join["normalized_lookup_alternative"] == "NAME" and join["source"] == "REMEMBERED_USER_CONFIRMATION"


def test_conflicting_or_unconfirmed_earlier_answers_are_asked_again() -> None:
    conflicting = _remembering_handlers([
        _confirmed("c1", "CONTACTS", "CONTACT_STATUSES", "STATUS_ID", "ID"),
        _confirmed("c2", "CONTACTS", "CONTACT_STATUSES", "DELETED", "DELETED"),
    ])
    assert conflicting.remembered_join_paths(
        {"run_id": "r"}, ["DB.SCH_TMD_SOURCE.CONTACT_STATUSES"], ["DB.SCH_TMD_SOURCE.CONTACTS"]) == {}
    unconfirmed = _remembering_handlers([
        _confirmed("p1", "CONTACTS", "CONTACT_STATUSES", "STATUS_ID", "ID", confirmed=False)])
    assert unconfirmed.remembered_join_paths(
        {"run_id": "r"}, ["DB.SCH_TMD_SOURCE.CONTACT_STATUSES"], ["DB.SCH_TMD_SOURCE.CONTACTS"]) == {}
    # A remembered answer must connect to a table already in the plan.
    assert _remembering_handlers([_confirmed("c1", "CONTACTS", "CONTACT_STATUSES", "STATUS_ID", "ID")]) \
        .remembered_join_paths({"run_id": "r"}, ["DB.SCH_TMD_SOURCE.CONTACT_STATUSES"],
                               ["DB.SCH_TMD_SOURCE.CONTACT_FAMILIES"]) == {}


def test_confirmed_lookup_alternative_is_written_with_the_learning() -> None:
    attributes = learning_attributes({"left_table": "DB.S.ADDRESSES", "right_table": "DB.S.COUNTRY_CODES",
                                      "conditions": [{"left_column": "COUNTRY", "right_column": "COUNTRY_CODE"}],
                                      "normalized_lookup_alternative": "country_alias"}, {})
    assert attributes["normalized_lookup_alternative"] == "COUNTRY_ALIAS"
