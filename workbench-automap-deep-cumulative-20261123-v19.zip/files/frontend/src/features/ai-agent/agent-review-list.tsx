'use client';

import { useState, type ReactNode } from 'react';
import { AiaBox, AiaButton, AiaInput, AiaStack } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

export type AgentReviewChoice = { id: string; label: string; description: string; confidence?: number | null };

export type AgentReviewItem = {
  id: string;
  category: string;
  summary: string;
  question: string;
  status: string;
  sttmId: string | null;
  blocking: boolean;
  subject: string | null;
  recommendedChoiceId: string | null;
  allowFreeText: boolean;
  choices: AgentReviewChoice[];
};

type AgentReviewListProps = {
  items: AgentReviewItem[];
  busy: boolean;
  error: string | null;
  onAnswer: (itemId: string, choiceId: string | null, text: string | null) => void;
  footer?: ReactNode;
};

function ReviewCard({ item, busy, onAnswer }: {
  item: AgentReviewItem;
  busy: boolean;
  onAnswer: AgentReviewListProps['onAnswer'];
}) {
  const [text, setText] = useState('');
  const [selectedChoice, setSelectedChoice] = useState<string | null>(item.recommendedChoiceId);
  const businessQuestion = ['confidence_gate', 'confidence_gate_batch', 'source_research_choice', 'source_join_path', 'target_scope'].includes(item.category);
  const answerable = businessQuestion ? item.choices.length >= 2 : item.choices.length > 0;
  const hasOther = businessQuestion && answerable;
  const choices = hasOther ? [...item.choices, {id: '__other__', label: 'Other', description: 'Describe a different option. The agent will check it and update the plan.', confidence: null}] : item.choices;
  const choosingOther = selectedChoice === '__other__';
  const summary = /allow_partial_coverage|at least one in-scope mapping candidate/.test(item.summary)
    ? 'The agent has not finished preparing supported column mappings. The researched tables are saved.' : item.summary;
  const heading = answerable && item.question && item.question !== item.summary ? item.question : summary;
  return (
    <AiaBox component="li" id={`review-card-${item.id}`} sx={{ listStyle: 'none', p: 1.25, border: '1px solid #e2e8f0', borderLeft: `3px solid ${item.blocking ? '#f59e0b' : '#cbd5e1'}`, borderRadius: 1.5, backgroundColor: '#fff', minWidth: 0 }}>
      {item.subject ? <AiaText sx={{ fontSize: 10.5, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.04em', overflowWrap: 'anywhere' }}>{item.subject}</AiaText> : null}
      <AiaText sx={{ mt: 0.25, fontSize: 12.5, fontWeight: 700, color: '#0f172a', overflowWrap: 'anywhere' }}>{heading}</AiaText>
      {heading !== summary ? <AiaText sx={{ mt: 0.25, fontSize: 11.5, color: '#475569', overflowWrap: 'anywhere' }}>{summary}</AiaText> : null}
      {answerable && choices.length ? <AiaStack role="radiogroup" aria-label={heading} spacing={0.5} sx={{ mt: 0.9 }}>
        {choices.map((choice) => {
          const recommended = choice.id === item.recommendedChoiceId;
          const selected = selectedChoice === choice.id;
          const confidence = choice.confidence == null ? null : Math.round(choice.confidence * 100);
          const confidenceColor = confidence == null ? '#64748b' : confidence >= 80 ? '#166534' : confidence >= 60 ? '#92400e' : '#991b1b';
          const confidenceBackground = confidence == null ? '#f1f5f9' : confidence >= 80 ? '#dcfce7' : confidence >= 60 ? '#fef3c7' : '#fee2e2';
          return <AiaBox key={choice.id} component="button" type="button" role="radio" aria-checked={selected}
            disabled={busy} title={choice.description || choice.label} onClick={() => setSelectedChoice(choice.id)}
            sx={{ width: '100%', minHeight: 44, display: 'grid', gridTemplateColumns: '18px minmax(0, 1fr)', gap: 0.75,
              alignItems: 'start', p: 0.9, border: `1px solid ${selected ? '#60a5fa' : '#e2e8f0'}`, borderRadius: 1,
              backgroundColor: selected ? '#eff6ff' : '#fff', textAlign: 'left', cursor: 'pointer', color: '#0f172a' }}>
            <AiaBox component="span" aria-hidden sx={{ mt: 0.2, width: 14, height: 14, borderRadius: '50%',
              border: `1px solid ${selected ? '#2563eb' : '#94a3b8'}`,
              boxShadow: selected ? 'inset 0 0 0 3px #eff6ff' : 'none',
              backgroundColor: selected ? '#2563eb' : '#fff' }} />
            <AiaBox component="span" sx={{ display: 'block', minWidth: 0 }}>
              <AiaStack component="span" direction="row" spacing={0.5} useFlexGap sx={{ alignItems: 'center', flexWrap: 'wrap' }}>
                <AiaText component="span" sx={{ fontSize: 13, fontWeight: 600 }}>{choice.label}</AiaText>
                {recommended ? <AiaBox component="span" sx={{ px: 0.6, py: 0.1, borderRadius: 999, fontSize: 10,
                  fontWeight: 600, color: '#1d4ed8', backgroundColor: '#dbeafe' }}>Recommended</AiaBox> : null}
              </AiaStack>
              {choice.description ? <AiaText component="span" sx={{ display: 'block', mt: 0.2, fontSize: 12, fontWeight: 400, color: '#64748b' }}>{choice.description}</AiaText> : null}
              {confidence != null ? <AiaBox component="span" sx={{ display: 'inline-block', mt: 0.45, px: 0.65, py: 0.15,
                borderRadius: 999, backgroundColor: confidenceBackground, color: confidenceColor, fontSize: 10.5,
                fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>{confidence}% confidence</AiaBox> : null}
            </AiaBox>
          </AiaBox>;
        })}
        <AiaButton size="small" variant="contained" disabled={busy || !selectedChoice || (choosingOther && !text.trim())}
          onClick={() => selectedChoice && onAnswer(item.id, selectedChoice, choosingOther ? text.trim() : null)} sx={{ alignSelf: 'flex-start', mt: 0.35, textTransform: 'none' }}>
          {choosingOther ? 'Update plan' : 'Apply answer'}
        </AiaButton>
      </AiaStack> : null}
      {hasOther && choosingOther ? <AiaInput size="small" multiline minRows={2} value={text} onChange={setText}
        placeholder="Describe the option you want the agent to check"
        sx={{ mt: 1, width: '100%', '& .MuiInputBase-input': { fontSize: 12 } }} /> : null}
      {!answerable ? <AiaText sx={{ mt: 0.7, fontSize: 11.5, color: '#64748b' }}>Research finding. No answer is required here.</AiaText> : null}
    </AiaBox>
  );
}

/** Open review items as answerable cards: needed ones first, then optional. */
export function AgentReviewList({ items, busy, error, onAnswer, footer }: AgentReviewListProps) {
  const answerable = (item: AgentReviewItem) => item.choices.length >= 2 || (item.choices.length > 0 && ['plan_approval', 'authentication_required'].includes(item.category));
  const needed = items.filter((item) => answerable(item));
  const optional = items.filter((item) => !answerable(item));
  const section = (title: string, list: AgentReviewItem[]) => list.length ? <AiaBox sx={{ mb: 1.5 }}>
    <AiaText sx={{ mb: 0.75, fontSize: 11, fontWeight: 800, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title} · {list.length}</AiaText>
    <AiaStack component="ul" spacing={0.75} sx={{ m: 0, p: 0 }}>
      {list.map((item) => <ReviewCard key={item.id} item={item} busy={busy} onAnswer={onAnswer} />)}
    </AiaStack>
  </AiaBox> : null;
  return (
    <AiaBox>
      {error ? <AiaText role="alert" sx={{ mb: 1, fontSize: 12, color: '#b91c1c' }}>{error}</AiaText> : null}
      {items.length ? <>
        {section('Questions', needed)}
        {section('Findings', optional)}
      </> : <AiaText sx={{ fontSize: 12, color: '#64748b' }}>No open review items.</AiaText>}
      {footer}
      <AiaText sx={{ mt: 1, fontSize: 10.5, color: '#64748b' }}>Answers are recorded on the run; mapping choices update the saved draft. Nothing is published.</AiaText>
    </AiaBox>
  );
}
