import { cacheScope, cacheRevision, onCacheIdentityChange, scopedStorageKey } from '@/services/session-cache-scope';
import { API_ROUTES } from "@/api/routes";
import { getAuthenticatedReadScope } from "@/services/authService";
import {
  buildApiEnvelope,
  deleteApiData,
  getApiData,
  postEnvelopeData,
  putEnvelopeData,
} from "@/api/axiosInstance";
import { normalizeProjectAttributeRecords } from "@/features/sttm/mapping/project-attribute-utils";
import { getProjectColorById, PROJECT_COLOR_OPTIONS } from "@/features/projects/project-color-options";
import type { ProjectItem, ProjectPerson } from "@/features/projects/projects-data";

type JsonRecord = Record<string, unknown>;

export type ProjectRecord = {
  project_id: string;
  project_name: string;
  description?: string | null;
  status: string;
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  sttm_count: number;
  complete_count: number;
  partial_count: number;
  draft_count: number;
  total_mappings: number;
  mapped_count: number;
  coverage_percent: number;
  metadata?: JsonRecord | null;
  linked_project_ids?: string[];
};

export type STTMRecord = {
  sttm_id: string;
  project_id: string;
  sttm_name?: string | null;
  description?: string | null;
  target_table?: string | null;
  current_version: number;
  has_unpublished_draft: boolean;
  status: string;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  last_snapshot_id?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  mapping_count: number;
  mapped_count: number;
  coverage_percent: number;
  metadata?: JsonRecord | null;
  linked_mapping_ids?: string[];
};

export type STTMDetail = {
  project?: ProjectRecord | null;
  sttm: STTMRecord;
  latest_snapshot?: JsonRecord | null;
  sources: JsonRecord[];
  mapping_rows: JsonRecord[];
  versions: JsonRecord[];
  agent_artifacts: JsonRecord[];
};

export type STTMAutosavePayload = {
  workspace_snapshot: JsonRecord;
  action?: string;
  session_id?: string | null;
  thread_id?: string | null;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  mapping_version?: string | null;
  agent_artifacts?: JsonRecord[];
  fir_events?: JsonRecord[];
  metadata?: JsonRecord;
};

export type STTMAutosaveResult = {
  project_id: string;
  sttm_id: string;
  snapshot_id: string;
  has_unpublished_draft: boolean;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  post_save_job_id?: string | null;
  post_save_job_status?: string | null;
  [key: string]: unknown;
};

export type STTMPostSaveJobStatus = {
  job_id: string;
  snapshot_id: string;
  sttm_id: string;
  project_id: string;
  job_type: string;
  status: string;
  attempt_count: number;
  error_details?: JsonRecord | null;
};

export type STTMPublishPayload = {
  request_id?: string;
  revision_note?: string | null;
  workspace_snapshot?: JsonRecord | null;
  session_id?: string | null;
  thread_id?: string | null;
  semantic_bundle_id?: string | null;
  semantic_bundle_hash?: string | null;
  mapping_version?: string | null;
  metadata?: JsonRecord;
};

export type ProjectsSummary = {
  projects: ProjectRecord[];
  sttms: STTMRecord[];
};

export type ProjectTemplateTarget = {
  logical_target_key: string;
  table_name: string;
  physical_fqn: string;
  available: boolean;
  column_count: number;
  columns: Array<Record<string, unknown>>;
  missing_columns: string[];
};

export type ProjectTemplateRecord = {
  template_id: string;
  template_version: string;
  label: string;
  source_systems: string[];
  target_contract_id: string;
  target_contract_version: string;
  target_database: string;
  target_schema: string;
  available_targets: ProjectTemplateTarget[];
  missing_targets: ProjectTemplateTarget[];
  unexpected_tables: string[];
};

export type ProjectBootstrapResponse = {
  project: ProjectRecord;
  mappings: STTMRecord[];
  template: ProjectTemplateRecord;
  bootstrap_status: string;
  unavailable_target_tables: string[];
};

export type ProjectAttributeRecord = {
  attribute_id: string;
  project_id: string;
  project_name?: string | null;
  attribute_name: string;
  attribute_type: string;
  attribute_value: string;
  source_project_id?: string | null;
  source_project_name?: string | null;
  source_attribute_id?: string | null;
  status: string;
  created_by?: string | null;
  updated_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
};

// Keep project lists, summaries, and immutable STTM snapshot pointers warm across
// normal navigation, while periodically revalidating changes made by other tabs
// or service instances. Local mutations patch or invalidate affected entries.
// A freshness deadline schedules background work; cached values stay usable
// for the verified session until a relevant mutation or identity invalidation.
const PROJECT_METADATA_CACHE_TTL_MS = 5 * 60 * 1000;
const PROJECTS_SESSION_CACHE_KEY = "aia-workbench:projects:list:v2";
const PROJECT_SUMMARY_SESSION_CACHE_KEY = "aia-workbench:projects:summary:v2";
const STTM_DETAIL_SESSION_PREFIX = "aia-workbench:sttm:detail:v2:";

const metadataListeners = new Set<() => void>();
export function subscribeProjectMetadata(listener: () => void) {
  metadataListeners.add(listener);
  return () => { metadataListeners.delete(listener); };
}
function notifyProjectMetadata() { metadataListeners.forEach(listener => { try { listener(); } catch { /* Subscribers cannot fail a successful save. */ } }); }
let projectMetadataRevision = 0;
let summaryMutationRevision = 0;
const sttmDetailRevisions = new Map<string, number>();
let projectsCache: { data: ProjectRecord[]; expiresAt: number } | null = null;
let projectsInFlight: Promise<ProjectRecord[]> | null = null;
let summaryCache: { data: ProjectsSummary; expiresAt: number } | null = null;
let summaryInFlight: Promise<ProjectsSummary> | null = null;
const sttmDetailBySnapshotId = new Map<string, STTMDetail>();
const sttmLatestPointers = new Map<string, { snapshotId: string; expiresAt: number }>();
const sttmDetailRequests = new Map<string, Promise<STTMDetail>>();

function hasSessionEntry<T>(entry: { data: T; expiresAt: number } | null): entry is { data: T; expiresAt: number } {
  return Boolean(entry && cacheScope());
}

function readSessionCache<T>(key: string): { data: T; expiresAt: number } | null {
  if (typeof window === "undefined") {
    return null;
  }
  try {
    const raw = window.sessionStorage.getItem(scopedStorageKey(key));
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw) as { data?: T; expiresAt?: number };
    if (!parsed || !("data" in parsed) || !Number.isFinite(parsed.expiresAt) || !cacheScope()) {
      window.sessionStorage.removeItem(scopedStorageKey(key));
      return null;
    }
    return { data: parsed.data as T, expiresAt: parsed.expiresAt! };
  } catch {
    return null;
  }
}

function writeSessionCache<T>(key: string, entry: { data: T; expiresAt: number }) {
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.sessionStorage.setItem(scopedStorageKey(key), JSON.stringify(entry));
  } catch {
    // Session storage is an optimization only. Ignore quota/security failures.
  }
}

function clearSessionProjectCaches() {
  if (typeof window === "undefined") {
    return;
  }
  window.sessionStorage.removeItem(PROJECTS_SESSION_CACHE_KEY);
  window.sessionStorage.removeItem(PROJECT_SUMMARY_SESSION_CACHE_KEY);
  for (let index = window.sessionStorage.length - 1; index >= 0; index -= 1) {
    const key = window.sessionStorage.key(index);
    if (key?.startsWith(STTM_DETAIL_SESSION_PREFIX) || key?.startsWith(PROJECTS_SESSION_CACHE_KEY) || key?.startsWith(PROJECT_SUMMARY_SESSION_CACHE_KEY)) {
      window.sessionStorage.removeItem(key);
    }
  }
}

export function invalidateProjectMetadataCache() {
  projectMetadataRevision++;
  invalidateProjectAttributeRequests();
  projectsCache = null;
  projectsInFlight = null;
  summaryCache = null;
  summaryInFlight = null;
  sttmDetailBySnapshotId.clear();
  sttmLatestPointers.clear();
  sttmDetailRequests.clear();
  clearSessionProjectCaches();
}

/** Structural changes refresh lists without discarding unrelated opened mappings. */
export function invalidateProjectSummaries() {
  summaryMutationRevision++;
  projectsInFlight = null;
  summaryInFlight = null;
  getCachedProjectsSummary();
  if (summaryCache) {
    summaryCache = {...summaryCache, expiresAt: 0};
    writeSessionCache(PROJECT_SUMMARY_SESSION_CACHE_KEY,summaryCache);
  }
  if (projectsCache) {
    projectsCache = {...projectsCache, expiresAt: 0};
    writeSessionCache(PROJECTS_SESSION_CACHE_KEY,projectsCache);
  }
}

function invalidateMappingDetail(sttmId: string) {
  sttmDetailRevisions.set(sttmId,(sttmDetailRevisions.get(sttmId) ?? 0)+1);
  const pointer=sttmLatestPointers.get(sttmId);
  if (pointer) sttmDetailBySnapshotId.delete(pointer.snapshotId);
  sttmLatestPointers.delete(sttmId);
  sttmDetailRequests.delete(sttmId);
  try { window.sessionStorage.removeItem(scopedStorageKey(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`)); } catch { /* Optional storage. */ }
}

/** Return the already-loaded project/STTM summary without starting a request. */
export function getCachedProjectsSummary(): ProjectsSummary | null {
  if (hasSessionEntry(summaryCache)) {
    return summaryCache.data;
  }
  const cachedSummary = readSessionCache<ProjectsSummary>(PROJECT_SUMMARY_SESSION_CACHE_KEY);
  if (!hasSessionEntry(cachedSummary)) {
    return null;
  }
  summaryCache = cachedSummary;
  projectsCache = {
    data: cachedSummary.data.projects,
    expiresAt: cachedSummary.expiresAt,
  };
  return cachedSummary.data;
}

function initialsFor(name?: string | null) {
  const value = (name || "AI Workbench").trim();
  const parts = value.split(/\s+/).filter(Boolean);
  return (parts.length > 1 ? `${parts[0][0]}${parts[1][0]}` : value.slice(0, 2)).toUpperCase();
}

function formatTimestamp(value?: string | null) {
  if (!value) {
    return "—";
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "—";
  }
  const day = date.getDate().toString().padStart(2, "0");
  const month = date.toLocaleString("en-GB", { month: "short" });
  const year = date.getFullYear();
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  return `${day} ${month} ${year} · ${hours}:${minutes}`;
}

function personFor(name?: string | null, timestamp?: string | null): ProjectPerson {
  return {
    initials: initialsFor(name),
    name: name || "AI Workbench",
    timestamp: formatTimestamp(timestamp),
  };
}

function colorForRecord(record: ProjectRecord) {
  const metadata = record.metadata ?? {};
  const configuredId = typeof metadata.theme_color_id === "string" ? metadata.theme_color_id : "";
  if (configuredId) {
    return getProjectColorById(configuredId);
  }
  const index = Math.abs(
    Array.from(record.project_id || record.project_name).reduce(
      (hash, char) => (hash * 31 + char.charCodeAt(0)) | 0,
      0,
    ),
  ) % PROJECT_COLOR_OPTIONS.length;
  return PROJECT_COLOR_OPTIONS[index];
}

export function projectRecordToItem(record: ProjectRecord): ProjectItem {
  const color = colorForRecord(record);
  const createdBy = personFor(record.created_by, record.created_at);
  const modifiedBy = personFor(record.created_by, record.updated_at ?? record.created_at);

  return {
    id: record.project_id,
    name: record.project_name,
    description: record.description || "No description yet.",
    themeColor: color.color,
    themeBg: color.bg,
    themeBorder: color.color,
    coveragePercent: Math.round(record.coverage_percent || 0),
    coverageBarColor: color.color,
    totalMappings: record.total_mappings || record.sttm_count || 0,
    completeCount: record.complete_count || 0,
    partialCount: record.partial_count || 0,
    draftCount: record.draft_count || 0,
    createdBy,
    lastModifiedBy: modifiedBy,
    domain: typeof record.metadata?.domain === "string" ? record.metadata.domain : undefined,
    intendedOutcome: typeof record.metadata?.intended_outcome === "string" ? record.metadata.intended_outcome : undefined,
    businessProcess: typeof record.metadata?.business_process === "string" ? record.metadata.business_process : undefined,
    owner: typeof record.metadata?.owner === "string" ? record.metadata.owner : undefined,
    linkedProjectIds: record.linked_project_ids ?? [],
  };
}

export async function listProjects(refresh = false): Promise<ProjectRecord[]> {
  if (!refresh && !hasSessionEntry(projectsCache)) {
    const summary=getCachedProjectsSummary();
    if (!summary) projectsCache=readSessionCache<ProjectRecord[]>(PROJECTS_SESSION_CACHE_KEY);
  }
  if (!refresh && hasSessionEntry(projectsCache)) {
    if (projectsCache.expiresAt <= Date.now()) void listProjects(true).catch(() => {});
    return projectsCache.data;
  }
  if (projectsInFlight) {
    return projectsInFlight;
  }
  const revision = cacheRevision();
  const metadataRevision = projectMetadataRevision;
  const mutationRevision = summaryMutationRevision;
  projectsInFlight = getApiData<ProjectRecord[]>(API_ROUTES.projects.list, {
    skipGlobalError: true,
    timeout: 25000,
  })
    .then((projects) => {
      if (revision !== cacheRevision() || metadataRevision !== projectMetadataRevision || mutationRevision !== summaryMutationRevision) throw new Error("Session changed during project retrieval.");
      projectsCache = {
        data: projects,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      };
      writeSessionCache(PROJECTS_SESSION_CACHE_KEY, projectsCache);
      return projects;
    })
    .finally(() => {
      if (metadataRevision === projectMetadataRevision && mutationRevision === summaryMutationRevision) projectsInFlight = null;
    });
  return projectsInFlight;
}

export async function createProject(params: {
  project_name: string;
  description?: string | null;
  theme_color_id?: string;
  domain?: string | null;
  intended_outcome?: string | null;
  business_process?: string | null;
  owner?: string | null;
  linked_project_ids?: string[];
}): Promise<ProjectRecord> {
  const project = await postEnvelopeData<ProjectRecord>(
    API_ROUTES.projects.create,
    buildApiEnvelope(
      "projects.create",
      {
        project_name: params.project_name,
        description: params.description ?? "",
        metadata: {
          theme_color_id: params.theme_color_id,
          domain: params.domain,
          intended_outcome: params.intended_outcome,
          business_process: params.business_process,
          owner: params.owner,
        },
        precedent_links: (params.linked_project_ids ?? []).map((projectId, index) => ({
          precedent_project_id: projectId,
          priority: Math.max(1, 100 - index),
          knowledge_categories: [
            "column_mapping",
            "relationship",
            "transformation",
            "query_shaping",
            "derived_lineage",
          ],
          allow_project_specific_values: false,
        })),
      },
      {},
    ),
    { timeout: 90000 },
  );
  invalidateProjectSummaries();
  return project;
}

export async function listProjectTemplates(): Promise<ProjectTemplateRecord[]> {
  return getApiData<ProjectTemplateRecord[]>(API_ROUTES.projects.templates, {
    skipGlobalError: true,
    timeout: 30000,
  });
}

export async function createProjectFromTemplate(params: {
  project_name: string;
  description?: string | null;
  theme_color_id?: string;
  domain?: string | null;
  intended_outcome?: string | null;
  business_process?: string | null;
  owner?: string | null;
  linked_project_ids?: string[];
  template_id: string;
  source_system_key: string;
  bootstrap_mode: "AUTO" | "EMPTY";
  idempotency_key: string;
  selected_target_tables?: string[];
}): Promise<ProjectBootstrapResponse> {
  const result = await postEnvelopeData<ProjectBootstrapResponse>(
    API_ROUTES.projects.createFromTemplate,
    buildApiEnvelope("projects.create_from_template", {
      project_name: params.project_name,
      description: params.description ?? "",
      template_id: params.template_id,
      source_system_key: params.source_system_key,
      bootstrap_mode: params.bootstrap_mode,
      idempotency_key: params.idempotency_key,
      selected_target_tables: params.selected_target_tables,
      metadata: {
        theme_color_id: params.theme_color_id,
        domain: params.domain,
        intended_outcome: params.intended_outcome,
        business_process: params.business_process,
        owner: params.owner,
      },
      precedent_links: (params.linked_project_ids ?? []).map((projectId, index) => ({
        precedent_project_id: projectId,
        priority: Math.max(1, 100 - index),
        knowledge_categories: [
          "column_mapping", "relationship", "transformation", "query_shaping", "derived_lineage",
        ],
        allow_project_specific_values: false,
      })),
    }),
    // Bootstrap commits all selected target shells in one transaction; a ten-table
    // project can exceed the generic 90-second write budget on a cold warehouse.
    { timeout: 300000 },
  );
  invalidateProjectSummaries();
  return result;
}

export async function listProjectSttms(projectId: string): Promise<STTMRecord[]> {
  return getApiData<STTMRecord[]>(API_ROUTES.projects.sttms(projectId), {
    skipGlobalError: true,
    timeout: 15000,
  });
}

const projectAttributeRequests = new Map<string, Promise<ProjectAttributeRecord[]>>();
let projectAttributeRevision = 0;

export function invalidateProjectAttributeRequests() {
  projectAttributeRevision += 1;
  projectAttributeRequests.clear();
}

export async function listProjectAttributes(projectId: string, signal?: AbortSignal): Promise<ProjectAttributeRecord[]> {
  const scope = getAuthenticatedReadScope();
  const revision = projectAttributeRevision;
  const key = JSON.stringify([scope, projectId]);
  if (signal?.aborted) throw new DOMException('Aborted','AbortError');
  // Re-read completed requests: Values may change in another tab or session.
  // Cancelable callers own their request. SSR and unknown identities never share.
  const share = typeof window !== "undefined" && scope !== null && !signal;
  const existing = share ? projectAttributeRequests.get(key) : undefined;
  if (existing) return existing.then(records => records.map(record => ({ ...record })));
  const pending = getApiData<unknown>(API_ROUTES.projects.attributes(projectId), {
    skipGlobalError: true,
    timeout: 30000,
    signal,
  }).then(payload => {
    if (revision !== projectAttributeRevision) throw new Error("Project values changed during retrieval; reload them.");
    if (share && scope !== getAuthenticatedReadScope()) throw new Error("Authenticated session changed; reload project values.");
    const records = normalizeProjectAttributeRecords(payload, projectId);
    return records;
  });
  if (share) projectAttributeRequests.set(key, pending);
  try {
    return (await pending).map(record => ({ ...record }));
  } finally {
    if (projectAttributeRequests.get(key) === pending) projectAttributeRequests.delete(key);
  }
}

export async function createProjectAttribute(
  projectId: string,
  payload: { attribute_name: string; attribute_type: string; attribute_value: string },
  signal?: AbortSignal,
): Promise<ProjectAttributeRecord> {
  const result = await postEnvelopeData<ProjectAttributeRecord>(
    API_ROUTES.projects.attributes(projectId),
    buildApiEnvelope("projects.attributes.create", payload, { project_id: projectId }),
    { signal },
  );
  invalidateProjectAttributeRequests();
  return result;
}

export async function upsertProjectAttributes(
  projectId: string,
  attributes: Array<{
    attribute_name: string;
    attribute_type: string;
    attribute_value: string;
  }>,
  signal?: AbortSignal,
): Promise<{
  attributes: ProjectAttributeRecord[];
  created_count: number;
  unchanged_count: number;
}> {
  const result = await postEnvelopeData<{ attributes: ProjectAttributeRecord[]; created_count: number; unchanged_count: number }>(
    API_ROUTES.projects.batchUpsertAttributes(projectId),
    buildApiEnvelope(
      "projects.attributes.batch_upsert",
      { attributes },
      { project_id: projectId },
    ),
    { signal },
  );
  invalidateProjectAttributeRequests();
  return result;
}

export async function updateProjectAttribute(
  projectId: string,
  attributeId: string,
  payload: {
    attribute_name?: string;
    attribute_type?: string;
    attribute_value?: string;
    status?: "ACTIVE" | "INACTIVE";
  },
): Promise<ProjectAttributeRecord> {
  const result = await putEnvelopeData<ProjectAttributeRecord>(
    API_ROUTES.projects.attribute(projectId, attributeId),
    buildApiEnvelope("projects.attributes.update", payload, {
      project_id: projectId,
      attribute_id: attributeId,
    }),
  );
  invalidateProjectAttributeRequests();
  return result;
}

export async function deleteProjectAttribute(
  projectId: string,
  attributeId: string,
): Promise<void> {
  await deleteApiData(API_ROUTES.projects.attribute(projectId, attributeId));
  invalidateProjectAttributeRequests();
}

export async function importProjectAttributes(
  projectId: string,
  payload: {
    source_project_id: string;
    attribute_ids: string[];
    overwrite_existing?: boolean;
  },
): Promise<ProjectAttributeRecord[]> {
  const result = await postEnvelopeData<ProjectAttributeRecord[]>(
    API_ROUTES.projects.importAttributes(projectId),
    buildApiEnvelope("projects.attributes.import", payload, { project_id: projectId }),
  );
  invalidateProjectAttributeRequests();
  return result;
}

/**
 * Fetch all projects and all STTMs in a single request.
 * Avoids the N+1 pattern of listing projects then fetching per-project STTMs.
 * The caller groups STTMs by project_id client-side.
 */
export async function getAllProjectsSummary(refresh = false): Promise<ProjectsSummary> {
  const cachedSummary = getCachedProjectsSummary();
  if (!refresh && cachedSummary) {
    if (summaryCache && summaryCache.expiresAt <= Date.now()) void getAllProjectsSummary(true).catch(() => {});
    return cachedSummary;
  }
  if (summaryInFlight) {
    return summaryInFlight;
  }
  const revision = cacheRevision();
  const metadataRevision = projectMetadataRevision;
  const mutationRevision = summaryMutationRevision;
  const detailVersions = new Map(sttmDetailRevisions);
  summaryInFlight = getApiData<ProjectsSummary>(API_ROUTES.projects.summary, {
    skipGlobalError: true,
    timeout: 45000,
  })
    .then((summary) => {
      if (revision !== cacheRevision() || metadataRevision !== projectMetadataRevision || mutationRevision !== summaryMutationRevision) throw new Error("Session changed during summary retrieval.");
      // A newer server snapshot invalidates only its detail cache. Never use a
      // late aggregate read to discard a local save made while it was in flight.
      for (const row of summary.sttms) {
        const pointer=sttmLatestPointers.get(row.sttm_id);
        if (pointer && row.last_snapshot_id && pointer.snapshotId !== row.last_snapshot_id
            && (detailVersions.get(row.sttm_id) ?? 0)===(sttmDetailRevisions.get(row.sttm_id) ?? 0)) {
          invalidateMappingDetail(row.sttm_id);
        }
      }
      summaryCache = {
        data: summary,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      };
      projectsCache = {
        data: summary.projects,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      };
      writeSessionCache(PROJECT_SUMMARY_SESSION_CACHE_KEY, summaryCache);
      writeSessionCache(PROJECTS_SESSION_CACHE_KEY, projectsCache);
      notifyProjectMetadata();
      return summary;
    })
    .finally(() => {
      if (metadataRevision === projectMetadataRevision && mutationRevision === summaryMutationRevision) summaryInFlight = null;
    });
  return summaryInFlight;
}

export async function createProjectSttm(
  projectId: string,
  payload: JsonRecord,
  signal?: AbortSignal,
): Promise<STTMRecord> {
  const sttm = await postEnvelopeData<STTMRecord>(
    API_ROUTES.projects.sttms(projectId),
    buildApiEnvelope("projects.sttms.create", payload, { project_id: projectId }),
    { timeout: 90000, signal },
  );
  invalidateProjectSummaries();
  return sttm;
}

export async function getSttm(
  sttmId: string,
  options?: { includeHistory?: boolean; forceRefresh?: boolean },
): Promise<STTMDetail> {
  if (options?.includeHistory) {
    return getApiData<STTMDetail>(`${API_ROUTES.sttms.get(sttmId)}?include_history=true`);
  }
  if (options?.forceRefresh) {
    sttmDetailRevisions.set(sttmId,(sttmDetailRevisions.get(sttmId) ?? 0)+1);
    sttmLatestPointers.delete(sttmId);
    sttmDetailRequests.delete(sttmId);
    if (typeof window !== "undefined") {
      window.sessionStorage.removeItem(scopedStorageKey(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`));
    }
  }
  const pointer = sttmLatestPointers.get(sttmId);
  if (!options?.forceRefresh && pointer && cacheScope()) {
    const immutableSnapshot = sttmDetailBySnapshotId.get(pointer.snapshotId);
    if (immutableSnapshot) return immutableSnapshot;
  }
  const sessionDetail = options?.forceRefresh
    ? null
    : readSessionCache<STTMDetail>(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`);
  if (hasSessionEntry(sessionDetail)) {
    const snapshot = sessionDetail.data.latest_snapshot ?? {};
    const snapshotId = String(
      sessionDetail.data.sttm.last_snapshot_id ?? snapshot.snapshot_id ?? `draft:${sttmId}`,
    );
    sttmDetailBySnapshotId.set(snapshotId, sessionDetail.data);
    sttmLatestPointers.set(sttmId, { snapshotId, expiresAt: sessionDetail.expiresAt });
    return sessionDetail.data;
  }
  const pending = sttmDetailRequests.get(sttmId);
  if (pending) return pending;
  const revision = cacheRevision();
  const metadataRevision = projectMetadataRevision;
  const detailRevision = sttmDetailRevisions.get(sttmId) ?? 0;
  const request = getApiData<STTMDetail>(`${API_ROUTES.sttms.get(sttmId)}${options?.forceRefresh ? '?force_refresh=true' : ''}`)
    .then((detail) => {
      if (revision !== cacheRevision() || metadataRevision !== projectMetadataRevision || detailRevision !== (sttmDetailRevisions.get(sttmId) ?? 0)) throw new Error("Session changed during mapping retrieval.");
      const snapshot = detail.latest_snapshot ?? {};
      const snapshotId = String(
        detail.sttm.last_snapshot_id ?? snapshot.snapshot_id ?? `draft:${sttmId}`,
      );
      sttmDetailBySnapshotId.set(snapshotId, detail);
      sttmLatestPointers.set(sttmId, {
        snapshotId,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      });
      writeSessionCache(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`, {
        data: detail,
        expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
      });
      return detail;
    })
    .finally(() => { if (sttmDetailRequests.get(sttmId) === request) sttmDetailRequests.delete(sttmId); });
  sttmDetailRequests.set(sttmId, request);
  return request;
}

export async function autosaveSttm(
  sttmId: string,
  payload: STTMAutosavePayload,
): Promise<STTMAutosaveResult> {
  const identityRevision = cacheRevision();
  const result = await postEnvelopeData<STTMAutosaveResult>(
    API_ROUTES.sttms.autosave(sttmId),
    buildApiEnvelope("sttms.autosave", payload, { sttm_id: sttmId }),
    // Snowflake-backed autosaves update the durable snapshot plus normalized
    // source/mapping/FIR projections. Allow that write to finish instead of
    // reporting a false failure at the global 30-second request limit.
    { skipGlobalError: true, timeout: 120_000 },
  );
  if (identityRevision !== cacheRevision()) throw new Error("Session changed during autosave.");
  sttmDetailRevisions.set(sttmId,(sttmDetailRevisions.get(sttmId) ?? 0)+1);
  sttmDetailRequests.delete(sttmId);
  const pointer = sttmLatestPointers.get(sttmId);
  const priorDetail = pointer ? sttmDetailBySnapshotId.get(pointer.snapshotId) : null;
  if (priorDetail) {
    const nextDetail: STTMDetail = {
      ...priorDetail,
      sttm: {
        ...priorDetail.sttm,
        last_snapshot_id: result.snapshot_id,
        has_unpublished_draft: result.has_unpublished_draft,
        ...('semantic_bundle_id' in result ? {semantic_bundle_id:result.semantic_bundle_id} : {}),
        ...('semantic_bundle_hash' in result ? {semantic_bundle_hash:result.semantic_bundle_hash} : {}),
      },
      latest_snapshot: {
        ...(payload.workspace_snapshot ?? {}),
        snapshot_id: result.snapshot_id,
      },
      sources: Array.isArray(payload.workspace_snapshot.source_tables)
        ? payload.workspace_snapshot.source_tables
        : priorDetail.sources,
      mapping_rows: Array.isArray(payload.workspace_snapshot.mapping_rows)
        ? payload.workspace_snapshot.mapping_rows
        : priorDetail.mapping_rows,
    };
    if (pointer && pointer.snapshotId !== result.snapshot_id)
      sttmDetailBySnapshotId.delete(pointer.snapshotId); // Retain every opened mapping's current detail, not obsolete autosaves.
    sttmDetailBySnapshotId.set(result.snapshot_id, nextDetail);
    sttmLatestPointers.set(sttmId, {
      snapshotId: result.snapshot_id,
      expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
    });
    writeSessionCache(`${STTM_DETAIL_SESSION_PREFIX}${sttmId}`, {
      data: nextDetail,
      expiresAt: Date.now() + PROJECT_METADATA_CACHE_TTL_MS,
    });
  }
  if (!summaryCache) {
    getCachedProjectsSummary();
  }
  if (summaryCache) {
    const mappingRows = Array.isArray(payload.workspace_snapshot.mapping_rows)
      ? payload.workspace_snapshot.mapping_rows as JsonRecord[]
      : null;
    const mappedCount = mappingRows?.filter(
      (row) => String(row.status ?? "").toUpperCase() === "MAPPED",
    ).length;
    const nextSummaryCache = {
      ...summaryCache,
      data: {
        ...summaryCache.data,
        sttms: summaryCache.data.sttms.map((sttm) => {
          if (sttm.sttm_id !== sttmId) return sttm;
          const next = {
            ...sttm,
            has_unpublished_draft:result.has_unpublished_draft,
            ...('semantic_bundle_id' in result ? {semantic_bundle_id:result.semantic_bundle_id} : {}),
            ...('semantic_bundle_hash' in result ? {semantic_bundle_hash:result.semantic_bundle_hash} : {}),
            mapping_count:mappingRows?.length ?? sttm.mapping_count,
            mapped_count:mappedCount ?? sttm.mapped_count,
            coverage_percent:mappingRows?.length ? Math.round(((mappedCount ?? 0)/mappingRows.length)*100)
              : mappingRows ? 0 : sttm.coverage_percent,
          };
          return JSON.stringify(next) === JSON.stringify(sttm) ? sttm : {...next,last_snapshot_id:result.snapshot_id};
        }),
      },
    };
    const changed = nextSummaryCache.data.sttms.some((row,index) => row !== summaryCache!.data.sttms[index]);
    if (changed) {
      summaryMutationRevision++; // Only changed summary fields fence older aggregate reads.
      summaryInFlight = null; projectsInFlight = null;
      const affected = nextSummaryCache.data.sttms.find(row=>row.sttm_id===sttmId);
      const prior = summaryCache.data.sttms.find(row=>row.sttm_id===sttmId);
      nextSummaryCache.data.projects = summaryCache.data.projects.map(project => {
        if (!affected || !prior || project.project_id !== affected.project_id) return project;
        const total = project.total_mappings + (affected.mapping_count ?? 0) - (prior.mapping_count ?? 0);
        const mapped = project.mapped_count + (affected.mapped_count ?? 0) - (prior.mapped_count ?? 0);
        if (total === project.total_mappings && mapped === project.mapped_count) return project;
        return {...project,total_mappings:total,mapped_count:mapped,coverage_percent:total ? Math.round(mapped/total*10000)/100 : 0};
      });
      summaryCache = nextSummaryCache;
      projectsCache = {data:nextSummaryCache.data.projects, expiresAt:nextSummaryCache.expiresAt};
      writeSessionCache(PROJECT_SUMMARY_SESSION_CACHE_KEY, nextSummaryCache);
      writeSessionCache(PROJECTS_SESSION_CACHE_KEY, projectsCache);
      notifyProjectMetadata();
    }
  }
  else {
    // No baseline exists to prove that a pending aggregate is unaffected.
    summaryMutationRevision++; summaryInFlight=null; projectsInFlight=null;
  }
  return result;
}

export async function getPostSaveJobStatus(
  sttmId: string,
  jobId: string,
): Promise<STTMPostSaveJobStatus> {
  return getApiData<STTMPostSaveJobStatus>(API_ROUTES.sttms.postSaveJob(sttmId, jobId));
}

export async function publishSttm(
  sttmId: string,
  payload: STTMPublishPayload,
): Promise<JsonRecord> {
  const result = await postEnvelopeData<JsonRecord>(
    API_ROUTES.sttms.publish(sttmId),
    buildApiEnvelope("sttms.publish", payload, { sttm_id: sttmId }),
  );
  invalidateProjectSummaries();
  invalidateMappingDetail(sttmId);
  return result;
}

onCacheIdentityChange(invalidateProjectMetadataCache);
