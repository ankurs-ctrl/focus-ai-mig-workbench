"""Bootstrap inventory safety and the administrator recovery window."""
from decimal import Decimal
import importlib.util
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock
import pytest

ROOT = Path(__file__).resolve().parents[5]
spec = importlib.util.spec_from_file_location('metadata_bootstrap_script', ROOT / 'scripts/bootstrap_sttm_metadata_infra.py')
bootstrap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bootstrap)

@pytest.mark.parametrize('rows', [[], [('wrong',0)], [('project-bootstrap',-1)], [('project-bootstrap',Decimal('0.5'))], [('project-bootstrap','0')], [('project-bootstrap',True)], [('project-bootstrap',0),('project-bootstrap',1)]])
def test_bootstrap_rejects_invalid_inventory_without_mutation(rows):
 connection=MagicMock();cursor=connection.cursor.return_value.__enter__.return_value
 cursor.fetchall.return_value=rows
 with pytest.raises(RuntimeError,match='No automatic repair'):
  bootstrap.validate_project_bootstrap_lock(connection,'D.S')
 assert cursor.execute.call_count==1
 assert cursor.execute.call_args.args[0]=='SELECT LOCK_KEY, FENCE FROM D.S.TBL_PROJECT_BOOTSTRAP_LOCK'

@pytest.mark.parametrize('fence',[0,17,Decimal('99999999999999')])
def test_bootstrap_preserves_valid_fence(fence):
 connection=MagicMock();cursor=connection.cursor.return_value.__enter__.return_value
 cursor.fetchall.return_value=[('project-bootstrap',fence)]
 bootstrap.validate_project_bootstrap_lock(connection,'D.S')
 assert cursor.execute.call_count==1

def test_lock_is_applied_after_base_ddl_and_qualified():
 names=[path.name for path in bootstrap.BASE_SQL_FILES]
 assert names[names.index('create-table-ddl.sql')+1]=='project-bootstrap-lock.sql'
 raw=(ROOT/'infra/snowflake/project-bootstrap-lock.sql').read_text()
 rendered=bootstrap.render_sql(raw,'UAT.METADATA')
 assert 'CREATE TABLE IF NOT EXISTS UAT.METADATA.TBL_PROJECT_BOOTSTRAP_LOCK' in rendered
 assert not any(line.lstrip().upper().startswith(('DELETE ', 'INSERT INTO')) for line in rendered.splitlines())

@pytest.mark.parametrize('kind',['project','mapping'])
def test_restore_is_guarded_and_keeps_separately_removed_children(monkeypatch,kind):
 import app.api
 from app.routers import projects
 from app.auth.models import AppPersona
 monkeypatch.setattr(projects,'get_current_principal',lambda request:SimpleNamespace(app_persona=AppPersona.ADMIN,snowflake_user='ADMIN',user_id=1,snowflake_role='ADMIN'))
 monkeypatch.setattr(projects,'build_response_envelope',lambda **kwargs:kwargs['data'])
 session=MagicMock();session.sql.return_value.collect.return_value=[{'changed':1}]
 service=SimpleNamespace(_session=session,_projects_table='PROJECTS',_sttm_table='MAPPINGS')
 projects.manage_resource(kind,'7','restore',SimpleNamespace(),service)
 updates=[call.args[0] for call in session.sql.call_args_list if call.args[0].startswith('UPDATE')]
 assert len(updates)==(2 if kind=='project' else 1)
 for sql in updates:
  assert 'previous_status' in sql and 'DATEADD(day, -30' in sql
 if kind=='project':assert 'parent_project_id' in updates[1]
 else:assert 'EXISTS' in updates[0] and "NOT IN ('ARCHIVED','DELETED')" in updates[0]
 assert session.sql.call_args_list[-1].args[0]=='COMMIT'

def test_removed_inventory_excludes_expired_deletions_and_is_admin_only(monkeypatch):
 import app.api
 from app.routers import projects
 from app.auth.models import AppPersona
 monkeypatch.setattr(projects,'get_current_principal',lambda request:SimpleNamespace(app_persona=AppPersona.ADMIN,snowflake_user='ADMIN',user_id=1,snowflake_role='ADMIN'))
 monkeypatch.setattr(projects,'build_response_envelope',lambda **kwargs:kwargs['data'])
 session=MagicMock();session.sql.return_value.collect.return_value=[]
 service=SimpleNamespace(_session=session,_projects_table='PROJECTS',_sttm_table='MAPPINGS')
 assert projects.archived_resources(SimpleNamespace(),service)==[]
 for call in session.sql.call_args_list:
  assert 'DATEADD(day, -30' in call.args[0] and 'RECOVERABLE_UNTIL' in call.args[0]
 monkeypatch.setattr(projects,'get_current_principal',lambda request:SimpleNamespace(app_persona='DEVELOPER'))
 session.reset_mock()
 with pytest.raises(Exception) as caught:projects.archived_resources(SimpleNamespace(),service)
 assert caught.value.status_code==403
 session.sql.assert_not_called()

def test_catalog_counts_run_concurrently_and_do_not_wait_for_columns():
 from threading import Barrier
 from app.core.table_selection import TableSelectionService
 service=TableSelectionService.__new__(TableSelectionService)
 barrier=Barrier(2)
 def tables():barrier.wait(timeout=3);return [{'name':'CUSTOMER','rows':0}]
 def counts():barrier.wait(timeout=3);return [{'TABLE_NAME':'CUSTOMER','COLUMN_COUNT':37}]
 session=MagicMock();session.sql.side_effect=[SimpleNamespace(collect=tables),SimpleNamespace(collect=counts)]
 service._session=session
 result=service._list_tables_uncached('DB','SRC')
 assert result[0].row_count==0 and result[0].column_count==37
 assert session.sql.call_count==2
