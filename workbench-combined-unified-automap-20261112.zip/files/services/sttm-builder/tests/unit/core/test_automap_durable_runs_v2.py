"""Offline concurrency/HTTP acceptance; SQL effects simulated, never client writes."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, UTC, timedelta
from dataclasses import replace
from threading import RLock, Event
from types import SimpleNamespace
import json
import re
import time

import httpx
import pytest

from app.core.automap_durable_admission import DurableRunAdmission
from app.core.automap_admission import CallIdentity, ScanCallAdmission, StalePermit, Completion, RemoteCallCompleted
from app.core.automap_background_transport import BackgroundRunTransport
from app.core.automap_scan import ScanRequest, RuntimeCallTrace
from app.core.automap_shards import SnapshotScope, MessageBudget
from app.core.automap_scan_transport import ScanTransportConfig
from app.core.snowflake_agent import SnowflakeAgentClient
from tests.test_automap_runtime import harness, recovery_case

ACCOUNT='TEST_ORG.TEST_ACCOUNT';EPOCH='d74c3ae7-8233-4a97-87a7-fc69ab3e977d';TABLE='DB.META.PERMITS_V2'


class MemorySQL:
    def __init__(self):
        self.lock=RLock();self.events=[];self.fail_handoff=False
        self.rows=[dict(ACCOUNT_NAMESPACE=ACCOUNT,POOL_EPOCH=EPOCH,SLOT_ID=i,STATE='FREE',OWNER_TOKEN=None,
            FENCE=0,JOB_ID=None,CALLER_ID=None,GENERATION=None,SHARD_ID=None,RECONCILIATION_REF=None,
            MODEL_RUN_ID=None,REQUEST_ARCHIVE_REF=None,LEASE_EXPIRES_AT=None,RUN_DEADLINE=None,
            RECOVERY_OWNER=None,RECOVERY_LEASE_AT=None,NEXT_RECOVERY_AT=None,RECOVERY_ATTEMPTS=0,DISPATCH_PROTOCOL=None,
            COMPLETION=None,UPDATED_AT=datetime.now(UTC)) for i in range(1,17)]

    @contextmanager
    def factory(self):
        db=self
        class Session:
            def __init__(self):self.active=False
            def sql(self,q,params=None):
                session=self
                class Result:
                    def collect(self,**kwargs):return session.execute(q,params or [])
                return Result()
            def execute(self,q,p):
                if q.startswith('SELECT CURRENT_ORGANIZATION_NAME'):
                    return [dict(ACCOUNT_NAMESPACE=ACCOUNT,TRANSACTION_ID=1 if self.active else None)]
                if q=='BEGIN TRANSACTION':
                    db.lock.acquire();self.active=True;self.before=deepcopy(db.rows);self.events=deepcopy(db.events);return []
                if q in {'COMMIT','ROLLBACK'}:
                    if self.active:
                        if q=='ROLLBACK':db.rows[:]=self.before;db.events[:]=self.events
                        self.active=False;db.lock.release()
                    return []
                if 'OWNER_TOKEN IS NULL AS OWNER_MISSING' in q:
                    with db.lock:
                        return [{**deepcopy(r),'OWNER_MISSING':r['OWNER_TOKEN'] is None,
                            'EXPIRED':r['LEASE_EXPIRES_AT'] is not None and r['LEASE_EXPIRES_AT']<=datetime.now(UTC),
                            'AGE_SECONDS':max(0,int((datetime.now(UTC)-r['UPDATED_AT']).total_seconds()))} for r in db.rows]
                if q.startswith(('SELECT STATE, RECONCILIATION_REF','SELECT RECONCILIATION_REF')):
                    account,epoch,slot,owner,fence,job,caller,gen,shard=p
                    with db.lock:
                        return [deepcopy(r) for r in db.rows if r['SLOT_ID']==slot and r['OWNER_TOKEN']==owner
                            and r['FENCE']==fence and r['JOB_ID']==job and r['CALLER_ID']==caller
                            and r['GENERATION']==gen and r['SHARD_ID']==shard and r['STATE'] in {'HELD','QUARANTINED'}]
                assert self.active
                if q.startswith('SELECT *'):
                    limit=int(re.search(r'LIMIT (\d+)',q).group(1));now=datetime.now(UTC)
                    return [deepcopy(r) for r in db.rows if r['CALLER_ID']==p[2]
                        and (r['STATE']=='QUARANTINED' or r['STATE']=='HELD' and r['LEASE_EXPIRES_AT']<=now)
                        and (r['NEXT_RECOVERY_AT'] is None or r['NEXT_RECOVERY_AT']<=now)
                        and (r['RECOVERY_OWNER'] is None or r['RECOVERY_LEASE_AT']<=now)][:limit]
                if q.startswith('UPDATE') and '_CONTROL SET' in q:return [{'number of rows updated':1}]
                if q.startswith('SELECT SLOT_ID, POOL_EPOCH'):return deepcopy(db.rows)
                if q.startswith('SELECT SLOT_ID, FENCE'):
                    return [deepcopy(r) for r in db.rows if r['SLOT_ID']>12 and r['STATE']=='FREE'][:1]
                if q.startswith('INSERT INTO'):
                    db.events.append(json.loads(p[3]));return [{'number of rows inserted':1}]
                if q.startswith('UPDATE') and "SET STATE='HELD'" in q:
                    owner,job,caller,gen,shard,seconds,account,epoch,slot,fence=p
                    r=db.rows[slot-1]
                    if r['STATE']!='FREE' or r['FENCE']!=fence:return [{'number of rows updated':0}]
                    r.update(STATE='HELD',OWNER_TOKEN=owner,FENCE=fence+1,JOB_ID=job,CALLER_ID=caller,DISPATCH_PROTOCOL='background_v2',
                        GENERATION=gen,SHARD_ID=shard,RECONCILIATION_REF=None,MODEL_RUN_ID=None,
                        REQUEST_ARCHIVE_REF=None,LEASE_EXPIRES_AT=datetime.now(UTC)+timedelta(seconds=seconds))
                    return [{'number of rows updated':1}]
                if ' t SET ' in q:
                    account,epoch,slot,owner,fence,job,caller,gen,shard,target,target_fence=p
                    source=db.rows[slot-1];dest=db.rows[target-1]
                    if source['OWNER_TOKEN']!=owner or source['FENCE']!=fence or dest['STATE']!='FREE' or dest['FENCE']!=target_fence:
                        return [{'number of rows updated':0}]
                    dest.update({k:deepcopy(source[k]) for k in ['OWNER_TOKEN','JOB_ID','CALLER_ID','GENERATION','SHARD_ID',
                        'RECONCILIATION_REF','MODEL_RUN_ID','REQUEST_ARCHIVE_REF','RUN_DEADLINE','DISPATCH_PROTOCOL','COMPLETION']})
                    dest.update(STATE='QUARANTINED',FENCE=target_fence+1,LEASE_EXPIRES_AT=None)
                    if db.fail_handoff:raise RuntimeError('simulated audit/write failure')
                    return [{'number of rows updated':1}]
                if not q.startswith('UPDATE'):raise AssertionError(q)
                if 'AND STATE = ? AND RECONCILIATION_REF = ?' in q:
                    values=p[:2];identity_params=p[2:11]
                else: values=p[:-9];identity_params=p[-9:]
                account,epoch,slot,owner,fence,job,caller,gen,shard=identity_params;r=db.rows[slot-1]
                if "DISPATCH_PROTOCOL='background_v2'" in q:
                    if r.get('DISPATCH_PROTOCOL')!='background_v2' or r.get('RECONCILIATION_REF') or r.get('MODEL_RUN_ID'):
                        return [{'number of rows updated':0}]
                    if r['STATE']=='HELD' and r['LEASE_EXPIRES_AT']>datetime.now(UTC):
                        return [{'number of rows updated':0}]

                if (r['OWNER_TOKEN']!=owner or r['FENCE']!=fence or r['JOB_ID']!=job or r['GENERATION']!=gen
                    or r['STATE'] not in {'HELD','QUARANTINED'}):return [{'number of rows updated':0}]
                if "SET STATE='FREE'" in q or "SET STATE = 'FREE'" in q:
                    r.update(STATE='FREE',OWNER_TOKEN=None,FENCE=fence+1,LEASE_EXPIRES_AT=None)
                    if values:r.update(COMPLETION=values[0],RECONCILIATION_REF=values[1])
                elif "SET STATE='QUARANTINED'" in q:
                    r['STATE']='QUARANTINED'
                    if "COMPLETION='OPERATOR_ABANDONED'" in q:r['COMPLETION']='OPERATOR_ABANDONED'
                elif 'SET RECOVERY_OWNER=?' in q:
                    r.update(RECOVERY_OWNER=values[0],RECOVERY_LEASE_AT=datetime.now(UTC)+timedelta(seconds=60),RECOVERY_ATTEMPTS=r['RECOVERY_ATTEMPTS']+1)
                elif 'SET RECOVERY_OWNER=NULL' in q:
                    r.update(RECOVERY_OWNER=None,RECOVERY_LEASE_AT=None,NEXT_RECOVERY_AT=datetime.now(UTC)+timedelta(seconds=60),LAST_RECOVERY_REASON=values[0])
                elif 'SET REQUEST_ARCHIVE_REF' in q:r.update(REQUEST_ARCHIVE_REF=values[0],RUN_DEADLINE=datetime.now(UTC)+timedelta(seconds=values[1]))
                elif 'SET MODEL_RUN_ID' in q:r['MODEL_RUN_ID']=values[0]
                elif 'SET RECONCILIATION_REF' in q:
                    r['RECONCILIATION_REF']=values[0]
                    if 'REQUEST_ARCHIVE_REF = ?' in q:r.update(REQUEST_ARCHIVE_REF=values[1],RUN_DEADLINE=datetime.now(UTC)+timedelta(seconds=values[2]),LEASE_EXPIRES_AT=datetime.now(UTC)+timedelta(seconds=values[3]))
                elif 'SET LEASE_EXPIRES_AT' in q:
                    if r['STATE']!='HELD' or r['LEASE_EXPIRES_AT']<=datetime.now(UTC):return [{'number of rows updated':0}]
                    r['LEASE_EXPIRES_AT']=datetime.now(UTC)+timedelta(seconds=values[0])
                else:raise AssertionError(q)
                return [{'number of rows updated':1}]
        s=Session()
        try:yield s
        finally:
            if s.active:s.execute('ROLLBACK',[])


def response(data,status=200):
    return httpx.Response(status,stream=httpx.ByteStream(json.dumps(data).encode()))

def pool(db):return DurableRunAdmission(session_factory=db.factory,table=TABLE,account_namespace=ACCOUNT,
    pool_epoch=EPOCH,capacity=12,recovery_capacity=4)

def identity(n):return CallIdentity('job-'+str(n),'ALICE','snapshot','shard-'+str(n))


def test_four_old_quarantines_do_not_occupy_any_of_twelve_new_execution_slots():
    db=MemorySQL()
    for r in db.rows[12:]:r.update(STATE='QUARANTINED',OWNER_TOKEN='legacy',JOB_ID='old',CALLER_ID='OLD')
    old=deepcopy(db.rows[12:]);store=pool(db)
    with ThreadPoolExecutor(max_workers=12) as executor:permits=list(executor.map(lambda n:store.try_claim(identity(n)),range(12)))
    assert len({p.slot_id for p in permits})==12
    assert db.rows[12:]==old
    assert store.try_claim(identity(13)) is None
    for permit in permits:store.complete(permit,Completion.SUCCEEDED)
    assert all(r['STATE']=='FREE' for r in db.rows[:12])
    assert db.rows[12:]==old


def test_duplicate_concurrent_dispatch_identity_can_obtain_only_one_reservation():
    db=MemorySQL();store=pool(db)
    with ThreadPoolExecutor(max_workers=12) as executor:permits=list(executor.map(lambda n:store.try_claim(identity(1)),range(12)))
    assert sum(p is not None for p in permits)==1


def test_uncertain_call_moves_atomically_to_recovery_and_stale_worker_cannot_release_reused_slot():
    db=MemorySQL();store=pool(db);original=store.try_claim(identity(1))
    store.quarantine(original)
    assert db.rows[original.slot_id-1]['STATE']=='FREE' and db.rows[12]['STATE']=='QUARANTINED'
    assert db.events[0]['action']=='RECOVERY_HANDOFF'
    replacements=[store.try_claim(identity(100+i)) for i in range(12)]
    replacement=next(p for p in replacements if p.slot_id==original.slot_id)
    with pytest.raises(StalePermit):store.complete(original,Completion.SUCCEEDED)
    assert db.rows[replacement.slot_id-1]['OWNER_TOKEN']==replacement.owner
    assert store.try_claim(identity(1)) is None


def test_handoff_failure_rolls_back_both_inventory_and_audit():
    db=MemorySQL();store=pool(db);permit=store.try_claim(identity(1));before=deepcopy(db.rows);db.fail_handoff=True
    with pytest.raises(Exception):store.quarantine(permit)
    assert db.rows==before and db.events==[]


def test_recovery_full_keeps_unknown_counted_under_hard_total_ceiling():
    db=MemorySQL();store=pool(db)
    permits=[store.try_claim(identity(i)) for i in range(12)]
    for p in permits:store.quarantine(p)
    assert sum(r['STATE']=='QUARANTINED' for r in db.rows)==12
    assert len([r for r in db.rows[:12] if r['STATE']=='FREE'])==4
    assert [store.try_claim(identity(20+i)) for i in range(4)]
    assert store.try_claim(identity(30)) is None
    assert sum(r['STATE']!='FREE' for r in db.rows)==16


class MemoryArchive:
    def __init__(self):self.values={};self._deadline=time.monotonic()+60
    def with_deadline(self,deadline):return self
    def put(self,k,v):self.values[k]=v
    def get(self,k):return self.values[k]


@pytest.mark.parametrize('mode',['success','nested_run_id','lost_submit_ack','cancel_409'])
def test_real_background_transport_reaches_model_and_confirms_terminal_before_release(mode):
    db=MemorySQL();store=pool(db);gate=ScanCallAdmission(store,job_id='job',caller_id='ALICE')
    message={'role':'user','status':'completed','content':[{'type':'text','text':'exact original'}]}
    request=ScanRequest(SnapshotScope('ALICE','snapshot'),'snapshot','shard',('T',),(),json.dumps([message]),
        MessageBudget(10000,10000),time.monotonic()+20,Event(),Event(),runtime_trace=RuntimeCallTrace(),
        request_archive_ref='a'*64,capacity_wait_limit_seconds=30)
    sent=[];canceled=False
    def respond(r):
        nonlocal canceled
        sent.append(r)
        if r.method=='POST' and r.url.path.endswith('/threads'):return response({'thread_id':123})
        if r.url.path.endswith('/cancel'):
            canceled=True;return response({},409 if mode=='cancel_409' else 200)
        if r.method=='POST':
            body=json.loads(r.content);assert body['background'] is True and body['stream'] is False
            if mode not in {'success','nested_run_id'}:raise httpx.ReadTimeout('lost acknowledgement')
            if mode=='nested_run_id':return response({'status':'in_progress','metadata':{'run_id':'123-11','thread_id':123,'user_message_id':11}})
            return response({'status':'in_progress','run_id':'123-11'})
        payload={**message,'schema_version':'v2'}
        messages=[dict(message_id=11,parent_id=0,role='user',message_type='conversation',message_payload=json.dumps(payload))]
        if mode=='nested_run_id':payload.pop('schema_version');payload.pop('status',None);messages[0]['message_payload']=json.dumps(payload)
        if mode in {'success','nested_run_id'} or canceled:
            answer={'schema_version':'v2','role':'assistant','status':'completed' if mode in {'success','nested_run_id'} else 'cancelled',
                'content':[{'type':'text','text':'{"mapping":"valid"}'}] if mode in {'success','nested_run_id'} else []}
            messages.append(dict(message_id=12,parent_id=11,role='assistant',message_type='conversation',message_payload=json.dumps(answer)))
        return response({'metadata':{'thread_id':123},'messages':messages})
    with httpx.Client(transport=httpx.MockTransport(respond)) as http:
        agent=SnowflakeAgentClient(token='synthetic',host='test-org-test-account.snowflakecomputing.com')
        backend=BackgroundRunTransport(agent_client=agent,http_client=http,config=ScanTransportConfig(agent='DB.META.AGENT',max_response_bytes=120000),admission=gate)
        backend.run_seconds=20;backend.result_archive=MemoryArchive()
        if mode in {'success','nested_run_id'}:
            with gate(request):assert gate.wrap_backend(backend)(request)=='{"mapping":"valid"}'
            assert backend.result_archive.values
        else:
            with pytest.raises(RemoteCallCompleted):
                with gate(request):gate.wrap_backend(backend)(request)
    assert sum(r.method=='POST' and r.url.path.endswith(':run') for r in sent)==1
    assert db.rows[0]['STATE']=='FREE'
    if mode not in {'success','nested_run_id'}:assert canceled


def test_expiry_releases_only_proven_new_protocol_pre_submission_not_legacy_unknown():
    db=MemorySQL();store=pool(db);permit=store.try_claim(identity(1))
    db.rows[permit.slot_id-1]['LEASE_EXPIRES_AT']=datetime.now(UTC)-timedelta(seconds=1)
    store.recover_not_dispatched(permit)
    assert db.rows[permit.slot_id-1]['STATE']=='FREE'
    assert db.events[-1]['action']=='NOT_DISPATCHED_RELEASE'
    legacy=store.try_claim(identity(2));db.rows[legacy.slot_id-1].update(DISPATCH_PROTOCOL=None,LEASE_EXPIRES_AT=datetime.now(UTC)-timedelta(seconds=1))
    with pytest.raises(StalePermit):store.recover_not_dispatched(legacy)
    assert db.rows[legacy.slot_id-1]['STATE']=='HELD'


def test_expired_held_with_committed_thread_cannot_be_released_as_not_dispatched():
    from app.core.automap_admission import ThreadReference
    db=MemorySQL();store=pool(db);permit=store.try_claim(identity(1))
    store.record_reconciliation(permit,ThreadReference(123,'DB.META.AGENT','a'*64))
    db.rows[permit.slot_id-1]['LEASE_EXPIRES_AT']=datetime.now(UTC)-timedelta(seconds=1)
    with pytest.raises(StalePermit):store.recover_not_dispatched(permit)
    assert db.rows[permit.slot_id-1]['STATE']=='HELD'


@pytest.mark.parametrize('status',['completed','error','timed_out','cancelled'])
def test_restarted_coordinator_recovers_from_durable_rows_without_original_runtime_memory(monkeypatch,harness,recovery_case,status):
    import sys
    from types import SimpleNamespace
    from app.core.automap_admission import ThreadReference,request_digest
    from app.core.automap_run_recovery import RunRecoveryCoordinator
    from tests.test_automap_runtime import CALLER
    case=recovery_case
    monkeypatch.setattr(sys.modules[__name__],'ACCOUNT',CALLER.account_namespace)
    db=MemorySQL();store=pool(db)
    # Both production stores use the same Snowflake schema. Route our two existing
    # SQL simulators through one session surface to preserve that integration.
    from tests.test_automap_runtime import Session as ArchiveSession
    @contextmanager
    def combined_factory():
        with db.factory() as memory:
            native=ArchiveSession(harness.database)
            class Combined:
                def sql(self,q,params=None,**kwargs):
                    if q in {'BEGIN TRANSACTION','COMMIT','ROLLBACK'}:
                        class Both:
                            def collect(self,**opts):
                                memory.sql(q,params).collect(**opts)
                                return native.sql(q,params).collect(**opts)
                        return Both()
                    if case.bundle.archive._table in q:
                        return native.sql(q,params,**kwargs)
                    return memory.sql(q,params)
            try:yield Combined()
            finally:
                if native.transaction:native.sql('ROLLBACK').collect()
                native.close()
    store._factory=combined_factory
    request=replace(case.request,generation=case.bundle.scope.snapshot_id)
    permit=store.try_claim(CallIdentity(case.bundle.admission.job_id,CALLER.native_user,request.generation,request.shard_id))
    reference=ThreadReference(123,case.reference.agent_fqn,request_digest(request))
    store.record_reconciliation(permit,reference)
    scope={'owner_id':request.scope.owner_id,'snapshot_id':request.scope.snapshot_id}
    from dataclasses import asdict
    import hashlib
    body=json.dumps({'scope':scope,'generation':request.generation,'value':{
        'protocol':'automap_fast_model_request_v1','job_id':permit.identity.job_id,'agent_fqn':reference.agent_fqn,
        'request_digest':request_digest(request),'snapshot_archive_ref':case.snapshot_ref,
        'request':{'scope':scope,'generation':request.generation,'shard_id':request.shard_id,
            'message':request.message,'target_ids':list(request.target_ids),'record_ids':list(request.record_ids),
            'output_budget':asdict(request.output_budget)}}})
    ref=hashlib.sha256(body.encode()).hexdigest()
    archive=case.bundle.archive.with_deadline(time.monotonic()+30);archive.put(ref,body)
    store.record_request(permit,ref,20);store.record_run(permit,'123-11');store.quarantine(permit)
    payload=json.loads(case.data['messages'][1]['message_payload'])
    payload['status']=status;payload['content']=[{'type':'text','text':'{"valid":"reply"}'}] if status=='completed' else []
    case.data['messages'][1]['message_payload']=json.dumps(payload)
    gate=ScanCallAdmission(store,job_id=permit.identity.job_id,caller_id=CALLER.native_user)
    backend=BackgroundRunTransport(agent_client=case.bundle.backend._agent_client,http_client=case.bundle.backend._http_client,
        config=case.bundle.backend._config,admission=gate)
    backend.result_archive=archive;backend.run_seconds=20
    bundle=replace(case.bundle,admission=gate,backend=backend,archive=archive)
    # A brand-new scheduler instance has no original Permit/request in memory.
    coordinator=RunRecoveryCoordinator()
    coordinator.tick(bundle,backend,None,SimpleNamespace(automap_run_seconds=20))
    assert all(r['STATE']=='FREE' for r in db.rows)
    assert case.sent and all(r.method=='GET' for r in case.sent)
    sent=len(case.sent)
    RunRecoveryCoordinator().tick(bundle,backend,None,SimpleNamespace(automap_run_seconds=20))
    assert len(case.sent)==sent
    audits=[json.loads(text) for values in harness.database.blobs.values() for text in values]
    assert any(a.get('value',{}).get('protocol')=='automap_terminal_reconciliation_v1' for a in audits)


def test_operator_abandonment_is_audited_and_never_fabricates_remote_completion():
    db=MemorySQL();store=pool(db);permit=store.try_claim(identity(1))
    with pytest.raises(ValueError):store.operator_abandon(permit,actor='ADMIN',reason='old test',retirement_evidence='approval-123',acknowledge_unknown=False)
    assert db.events==[]
    store.operator_abandon(permit,actor='ADMIN',reason='retired test dispatcher',retirement_evidence='approval-123',acknowledge_unknown=True)
    assert db.rows[permit.slot_id-1]['STATE']=='FREE'
    occupied=[r for r in db.rows if r['STATE']!='FREE']
    assert len(occupied)==1 and occupied[0]['COMPLETION']=='OPERATOR_ABANDONED'
    assert occupied[0]['STATE']=='QUARANTINED'
    audit=next(e for e in db.events if e['action']=='OPERATOR_ABANDONED')
    assert audit['detail']['still_counted'] is True
    assert audit['detail']['remote_outcome']=='unknown'
    assert 'owner_token_digest' in audit and permit.owner not in json.dumps(audit)


def test_recovery_registration_does_not_block_new_jobs_when_old_auth_cache_is_full():
    from app.core.automap_run_recovery import RunRecoveryCoordinator
    from types import SimpleNamespace
    coordinator=RunRecoveryCoordinator()
    for n in range(65):
        bundle=SimpleNamespace(admission=SimpleNamespace(store=SimpleNamespace(_table='DB.META.POOL')),
            archive=SimpleNamespace(_caller=SimpleNamespace(access_scope=str(n))))
        coordinator.register(bundle,None,None,SimpleNamespace(automap_recovery_poll_seconds=5))
    assert len(coordinator._contexts)==64
    assert ('DB.META.POOL','64') in coordinator._contexts


def test_capacity_wait_does_not_spend_execution_budget_but_cancellation_still_stops(monkeypatch):
    from types import SimpleNamespace
    import app.core.automap_admission as module
    from app.core.automap_admission import Permit
    clock=[100.0];monkeypatch.setattr(module.time,'monotonic',lambda:clock[0])
    monkeypatch.setattr(module.time,'sleep',lambda seconds:clock.__setitem__(0,clock[0]+seconds))
    seen=[]
    class WaitingStore:
        separate_wait_budget=True;lease_seconds=120
        def try_claim(self,identity):
            seen.append(identity)
            if len(seen)==1:clock[0]+=20;return None
            return Permit(ACCOUNT,EPOCH,1,'owner',1,identity)
        def renew(self,permit):pass
        def complete(self,*args):pass
        def quarantine(self,permit):raise AssertionError('No uncertain model call')
    store=WaitingStore();gate=ScanCallAdmission(store,job_id='job',caller_id='ALICE')
    request=ScanRequest(SnapshotScope('ALICE','snapshot'),'snapshot','shard',(),(),'[]',MessageBudget(1000,1000),
        105,Event(),Event(),runtime_trace=RuntimeCallTrace(),capacity_wait_limit_seconds=30)
    with gate(request):
        assert request.remaining_seconds()==pytest.approx(5)
        assert gate.wrap_backend(lambda req:'completed')(request)=='completed'
    assert request.runtime_trace.capacity_wait_seconds>=20
    request._cancel.set()
    from app.core.automap_scan import ScanStopped,ScanStatus
    with pytest.raises(ScanStopped) as error:
        with gate(request):pass
    assert error.value.status==ScanStatus.CANCELED
    assert len(seen)==2


def test_crashed_dispatcher_uncertain_call_moves_off_execution_inventory_before_next_job(monkeypatch):
    from types import SimpleNamespace
    from app.core.automap_run_recovery import RunRecoveryCoordinator
    from app.core.automap_batch import ParallelRuntimeBundle
    db=MemorySQL();store=pool(db)
    permit=store.try_claim(identity(1))
    db.rows[permit.slot_id-1]['LEASE_EXPIRES_AT']=datetime.now(UTC)-timedelta(seconds=1)
    gate=ScanCallAdmission(store,job_id=permit.identity.job_id,caller_id=permit.identity.caller_id)
    bundle=ParallelRuntimeBundle(None,None,gate,SimpleNamespace(_caller=SimpleNamespace(native_user=permit.identity.caller_id)),None)
    coordinator=RunRecoveryCoordinator()
    def uncertain(*args):raise LookupError('No unique terminal proof yet')
    monkeypatch.setattr(coordinator,'_recover',uncertain)
    coordinator.tick(bundle,None,None,SimpleNamespace())
    assert all(r['STATE']=='FREE' for r in db.rows[:12])
    assert sum(r['STATE']=='QUARANTINED' for r in db.rows[12:])==1
    assert store.try_claim(identity(2)) is not None
    assert store.try_claim(identity(1)) is None  # uncertain original is never replayed


@pytest.mark.parametrize('commit_failure',['before','after'])
def test_durable_archive_retry_uses_fresh_session_and_does_not_duplicate_committed_content(harness,monkeypatch,commit_failure):
    from tests.test_automap_runtime import build,blob,Session
    bundle=build(harness);archive=bundle.archive
    archive._storage_retry_attempts=2
    assert archive.with_deadline(time.monotonic()+30)._storage_retry_attempts==2
    original=Session.sql;attempts=[]
    def sql(self,query,*args,**kwargs):
        result=original(self,query,*args,**kwargs)
        if query!='COMMIT':return result
        class Commit:
            def collect(inner,**opts):
                attempts.append(self)
                self.database.commit_failure=commit_failure if len(attempts)==1 else None
                return result.collect(**opts)
        return Commit()
    monkeypatch.setattr(Session,'sql',sql)
    reference,text=blob(bundle)
    archive.put(reference,text)
    assert archive.get(reference)==text
    assert len(attempts)==2 and attempts[0] is not attempts[1]
    assert sum(len(items) for items in harness.database.blobs.values())==1
    assert not harness.database.requests_threads  # archive retry never reaches model


def test_v2_cannot_dispatch_legacy_scan_protocol_into_background_inventory():
    from types import SimpleNamespace
    from app.core.automap_runtime import build_parallel_runtime,RuntimeConfigurationError
    service=SimpleNamespace(_settings=SimpleNamespace(automap_durable_runs_v2=True))
    with pytest.raises(RuntimeConfigurationError,match='accepted fast-path'):
        build_parallel_runtime(service,req=None,decision=None,store=None,deadline=time.monotonic()+30)


@pytest.mark.parametrize('parallel,fast,capacity,recovery',[(False,True,12,4),(True,False,12,4),(True,True,30,4)])
def test_v2_settings_reject_mixed_transport_or_unbounded_exposure(parallel,fast,capacity,recovery):
    from types import SimpleNamespace
    from app.core.config import Settings
    settings=SimpleNamespace(automap_durable_runs_v2=True,automap_parallel_context_v1=parallel,
        automap_fast_path_v1=fast,automap_parallel_pool_capacity=capacity,automap_recovery_capacity=recovery)
    with pytest.raises(ValueError):Settings.validate_parallel_automap(settings)


@pytest.mark.parametrize('code',[627,630])
def test_real_snowpark_timeout_wrapper_is_contention_only_after_acknowledged_rollback(monkeypatch,code):
    from snowflake.snowpark.exceptions import SnowparkSQLException
    from app.core import automap_admission as admission
    db=MemorySQL();store=pool(db)
    original=store._sql;failed=[]
    def sql(session,query,params=None):
        if '_CONTROL SET FENCE' in query and not failed:
            failed.append(True)
            raise SnowparkSQLException('PRIVATE native timeout',error_code='1304',sql_error_code=code)
        return original(session,query,params)
    monkeypatch.setattr(store,'_sql',sql)
    with pytest.raises(admission.AdmissionContended):store.try_claim(identity(1))
    assert all(r['STATE']=='FREE' and r['FENCE']==0 for r in db.rows)
    assert store.try_claim(identity(1)) is not None


@pytest.mark.parametrize('code',[627,630])
def test_checked_caller_boundary_preserves_native_snowpark_contention_without_error_text(harness,code):
    from app.core.automap_runtime import _checked_sessions,RuntimeConfigurationError
    from tests.test_automap_runtime import CALLER,Session
    from snowflake.snowpark.exceptions import SnowparkSQLException
    @contextmanager
    def provider():
        session=Session(harness.database)
        try:yield session
        finally:session.close()
    factory=_checked_sessions(provider,CALLER,())
    with pytest.raises(RuntimeConfigurationError) as caught:
        with factory():raise SnowparkSQLException('PRIVATE query and token',error_code='1304',sql_error_code=code)
    assert caught.value.errno==code
    assert 'PRIVATE' not in str(caught.value) and caught.value.__cause__ is None


def _worker_http(monkeypatch, responses):
    """Keep real HTTP serialization, proxy parsing and response validation."""
    import socket
    client_type = httpx.Client
    wire = [item.model_dump_json().encode() for item in responses]
    calls = []

    def respond(request):
        calls.append(request)
        assert request.url.host == 'worker.invalid'
        assert request.url.path == '/api/v1/auto-mapping/invoke'
        assert json.loads(request.content)['meta']['auto_map_fast_path'] == 'v1'
        assert len(calls) <= len(wire), 'Unexpected worker retry'
        return httpx.Response(200, content=wire[len(calls) - 1],
                              headers={'content-type': 'application/json'})

    monkeypatch.setattr(socket.socket, 'connect', lambda *args: pytest.fail('Network access'))
    monkeypatch.setattr(socket, 'getaddrinfo', lambda *args, **kwargs: pytest.fail('DNS access'))
    monkeypatch.setattr('app.core.auto_mapping_proxy.httpx.Client',
        lambda **kwargs: client_type(transport=httpx.MockTransport(respond), **kwargs))
    monkeypatch.setattr('app.core.auto_mapping_proxy.time.sleep', lambda *args: None)
    return calls


def _durable_proxy(**settings):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    return AutoMappingProxyClient(Settings(_env_file=None).model_copy(update={
        'auto_mapping_service_url': 'http://worker.invalid',
        'automap_context_retrieval_v1': True, 'automap_durable_runs_v2': True,
        'automap_run_retry_attempts': 2, 'automap_fast_path_v1': True,
        'automap_fast_project_ids': ['allowed'], **settings}))


def _fast_worker_response(*, malformed_model=False, count=1):
    from app.schema.sttm_builder import STTMBuilderResponse, STTMStatus, STTMArtifactType, SubAgent
    from tests.unit.core.test_automap_fast_batch import FinalAgent, answer_for, fast_payload, invoke
    answer = json.loads(answer_for(['NAME0']))
    answer['warnings'] = ['Keep this model review warning']
    agent = FinalAgent(['x' * 2371, 'x' * 2371] if malformed_model else [json.dumps(answer)])
    builder, req, (raw, thread, payload) = invoke(fast_payload(count), agent=agent)
    parsed = builder._parse_envelope(raw)
    result = parsed[1]
    warnings = builder._auto_map_response_warnings(parsed[3], payload.get('warnings', []))
    unresolved = sum(item.transformation_classification == 'unresolved' for item in result.mappings.values())
    # Same envelope construction as STTMBuilderService.invoke's retrieval branch:
    # from_invocation echoes the selector, while worker diagnostics stay nested.
    response = STTMBuilderResponse.from_invocation(req, thread_id=thread, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=result, message='Offline worker result',
        status=STTMStatus.NEEDS_INPUT if unresolved else STTMStatus.COMPLETED,
        artifact_type=STTMArtifactType.SOURCE_MAPPING, warnings=warnings,
        meta={'auto_map_retrieval': payload['auto_map_retrieval']})
    assert response.meta['auto_map_fast_path'] == 'v1'
    assert len(agent.calls) == (2 if malformed_model else 1)
    return req, response


@pytest.mark.parametrize('malformed_model', [False, True])
@pytest.mark.parametrize('durable', [False, True])
def test_real_fast_worker_http_response_preserves_success_or_malformed_model_review(monkeypatch, malformed_model, durable):
    from app.schema.sttm_builder import STTMStatus
    req, worker = _fast_worker_response(malformed_model=malformed_model)
    calls = _worker_http(monkeypatch, [worker])
    response = _durable_proxy(automap_durable_runs_v2=durable)._invoke_complete_batch(
        req, headers={}, batch_index=0, planned_model_payload={})
    assert len(calls) == 1
    assert response.meta['auto_map_fast_path'] == 'v1'
    assert response.meta['auto_map_retrieval'] == worker.meta['auto_map_retrieval']
    assert response.data.status == (STTMStatus.NEEDS_INPUT if malformed_model else STTMStatus.COMPLETED)
    assert response.warnings == worker.warnings
    if not malformed_model:
        assert any(w.message == 'Keep this model review warning' for w in response.warnings)
    assert (response.result.mappings['NAME0'].transformation_classification == 'unresolved') == malformed_model
    assert 'durable_transport_retries' not in response.meta


@pytest.mark.parametrize('attempt', ['initial', 'replacement'])
@pytest.mark.parametrize('path, invalid', [
    (path, invalid)
    for path in (
        ('auto_map_retrieval',),
        ('auto_map_retrieval', 'auto_map_fast_path'),
        ('auto_map_retrieval', 'auto_map_fast_path', 'fast_diagnostics'),
        ('auto_map_retrieval', 'auto_map_fast_path', 'fast_diagnostics', 'failure_kind'),
        ('auto_map_retrieval', 'auto_map_fast_path', 'fast_diagnostics', 'stop_reason'),
    )
    for invalid in ('', 'PRIVATE malformed metadata', [], ['transport'], False, 0, 1, {})
    if (not isinstance(invalid, str) if path[-1] in {'failure_kind', 'stop_reason'}
        else not isinstance(invalid, dict))
])
def test_invalid_fast_diagnostics_reject_explicitly_without_hiding_failures(monkeypatch, attempt, path, invalid):
    from app.core.exceptions import SnowflakeAgentError
    from tests.unit.core.test_auto_mapping_proxy import _request, _response
    req = _request(1)
    req.meta['auto_map_fast_path'] = 'v1'
    prior = _response(req)
    prior.meta['auto_map_retrieval'] = {'auto_map_fast_path': {'fast_diagnostics': {'failure_kind': 'transport'}}}
    invalid_response = _response(req)
    branch = invalid_response.meta
    for key in path[:-1]:
        branch = branch.setdefault(key, {})
    branch[path[-1]] = invalid
    before = invalid_response.model_dump_json()
    calls = _worker_http(monkeypatch, [prior, invalid_response] if attempt == 'replacement' else [invalid_response])
    client = _durable_proxy()
    monkeypatch.setattr(client, '_merge_batch_responses', lambda *args: pytest.fail('Merged invalid diagnostics'))
    with pytest.raises(SnowflakeAgentError, match='AUTO_MAPPING_INVALID_FAST_DIAGNOSTICS') as caught:
        client._invoke_complete_batch(req, headers={}, batch_index=0, planned_model_payload={})
    assert 'meta.' + '.'.join(path) in str(caught.value)
    assert 'PRIVATE' not in str(caught.value)
    assert len(calls) == (2 if attempt == 'replacement' else 1)
    assert invalid_response.model_dump_json() == before


@pytest.mark.parametrize('path', [
    ('auto_map_retrieval',),
    ('auto_map_retrieval', 'auto_map_fast_path'),
    ('auto_map_retrieval', 'auto_map_fast_path', 'fast_diagnostics'),
    ('auto_map_retrieval', 'auto_map_fast_path', 'fast_diagnostics', 'failure_kind'),
    ('auto_map_retrieval', 'auto_map_fast_path', 'fast_diagnostics', 'stop_reason'),
])
@pytest.mark.parametrize('missing', [False, True])
@pytest.mark.parametrize('attempt', ['initial', 'replacement'])
def test_optional_fast_diagnostics_missing_or_null_keep_warnings(monkeypatch, path, missing, attempt):
    from app.core.sttm_builder import STTMBuilderService
    from tests.unit.core.test_auto_mapping_proxy import _request, _response
    req = _request(1)
    req.meta['auto_map_fast_path'] = 'v1'
    worker = _response(req)
    branch = worker.meta
    for key in path[:-1]:
        branch = branch.setdefault(key, {})
    if not missing:
        branch[path[-1]] = None
    worker.warnings = STTMBuilderService._auto_map_response_warnings(['Keep this worker review warning'])
    prior = _response(req)
    prior.meta['auto_map_retrieval'] = {'auto_map_fast_path': {'fast_diagnostics': {'failure_kind': 'transport'}}}
    calls = _worker_http(monkeypatch, [prior, worker] if attempt == 'replacement' else [worker])
    response = _durable_proxy()._invoke_complete_batch(req, headers={}, batch_index=0, planned_model_payload={})
    assert len(calls) == (2 if attempt == 'replacement' else 1)
    assert response.meta['auto_map_fast_path'] == 'v1'
    assert any(w.message == 'Keep this worker review warning' for w in response.warnings)
    diagnostics = _durable_proxy()._fast_response_diagnostics(worker)
    assert isinstance(diagnostics, dict)
    assert diagnostics.get('failure_kind') is None and diagnostics.get('stop_reason') is None
    if 'auto_map_retrieval' in worker.meta:
        assert response.meta['auto_map_retrieval'] == worker.meta['auto_map_retrieval']


@pytest.mark.parametrize('diagnostics, expected_calls', [
    ({'failure_kind': 'transport'}, 3),
    ({'failure_kind': 'transport', 'stop_reason': 'canceled'}, 1),
    ({'failure_kind': 'future_failure'}, 1),
])
def test_retry_uses_latest_nested_diagnostics_and_keeps_terminal_failure(monkeypatch, diagnostics, expected_calls):
    from app.core.sttm_builder import STTMBuilderService
    from tests.unit.core.test_auto_mapping_proxy import _request, _response
    req = _request(1)
    req.meta['auto_map_fast_path'] = 'v1'
    workers = [_response(req) for _ in range(expected_calls)]
    for worker in workers:
        worker.meta['auto_map_retrieval'] = {'auto_map_fast_path': {'fast_diagnostics': diagnostics}}
        worker.warnings = STTMBuilderService._auto_map_response_warnings(['Failure remains visible'])
    calls = _worker_http(monkeypatch, workers)
    response = _durable_proxy()._invoke_complete_batch(req, headers={}, batch_index=0, planned_model_payload={})
    assert len(calls) == expected_calls
    assert response.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] == diagnostics
    assert any(w.message == 'Failure remains visible' for w in response.warnings)
    assert len(response.meta.get('durable_transport_history', [])) == expected_calls - 1


@pytest.mark.parametrize('failure_kind', [
    'transport', 'stopped', 'admission_unavailable', 'admission_claim_uncertain', 'admission_contended',
])
def test_real_fast_worker_success_after_retry_keeps_selector_and_history(monkeypatch, failure_kind):
    req, worker = _fast_worker_response()
    prior = worker.model_copy(deep=True)
    prior.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = {'failure_kind': failure_kind}
    calls = _worker_http(monkeypatch, [prior, worker])
    response = _durable_proxy()._invoke_complete_batch(req, headers={}, batch_index=0, planned_model_payload={})
    assert len(calls) == 2
    assert response.meta['auto_map_fast_path'] == 'v1'
    assert response.meta['auto_map_retrieval'] == worker.meta['auto_map_retrieval']
    assert response.meta['durable_transport_history'] == [{'attempt': 0, 'failure_kind': failure_kind}]
    assert response.data.status == worker.data.status
    assert response.result.mappings['NAME0'].source_attributes == worker.result.mappings['NAME0'].source_attributes
    assert any(w.message == 'Keep this model review warning' for w in response.warnings)


@pytest.mark.parametrize('replacement_diagnostics', [
    {'failure_kind': 'transport', 'stop_reason': 'canceled'},
    {'failure_kind': 'future_failure'},
    {'failure_kind': 'invalid_model_json'},
])
def test_replacement_failure_stops_retry_and_preserves_prior_failure_warning(monkeypatch, replacement_diagnostics):
    from app.schema.contracts import ApiWarning
    req, worker = _fast_worker_response()
    prior = worker.model_copy(deep=True)
    prior.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = {'failure_kind': 'transport'}
    prior.warnings.append(ApiWarning(code='auto_map_fast_stage_failed', message='Prior transport failure'))
    worker.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = replacement_diagnostics
    calls = _worker_http(monkeypatch, [prior, worker])
    response = _durable_proxy(automap_run_retry_attempts=3)._invoke_complete_batch(
        req, headers={}, batch_index=0, planned_model_payload={})
    assert len(calls) == 2
    assert response.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] == replacement_diagnostics
    assert any(w.code == 'auto_map_fast_stage_failed' for w in response.warnings)
    assert response.meta['durable_transport_history'] == [{'attempt': 0, 'failure_kind': 'transport'}]


def test_invalid_diagnostics_rejected_even_when_durable_retry_budget_is_zero(monkeypatch):
    from app.core.exceptions import SnowflakeAgentError
    req, worker = _fast_worker_response()
    worker.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = []
    calls = _worker_http(monkeypatch, [worker])
    with pytest.raises(SnowflakeAgentError, match='AUTO_MAPPING_INVALID_FAST_DIAGNOSTICS'):
        _durable_proxy(automap_run_retry_attempts=0)._invoke_complete_batch(
            req, headers={}, batch_index=0, planned_model_payload={})
    assert len(calls) == 1


@pytest.mark.parametrize('retry_count', [1, 2])
@pytest.mark.parametrize('text', [False, True])
@pytest.mark.parametrize('first_calls, replacement', [(1, 'zero'), (0, 'zero'), (1, 'invalid')])
def test_retry_provenance_survives_parent_and_durable_partial_reload(monkeypatch, text, first_calls, replacement, retry_count):
    from app.core.automap_row_candidates import validate_row_candidates
    from app.schema.sttm_builder import AttributeMapping, STTMBuilderResponse, STTMStatus
    from app.schema.contracts import ApiWarning
    from tests.test_automap_durable_json import DurableSession, MARKER
    from types import SimpleNamespace

    req, first = _fast_worker_response(count=2)
    first = validate_row_candidates(SimpleNamespace(_query_session=None), req, first)
    target = 'NAME0'
    proven = first.result.mappings[target].model_copy(deep=True)
    assert proven.selected_candidate_id or proven.draft_candidate_id
    assert any(c.validation_status == 'valid' for c in proven.candidates)
    first.result.mappings['NAME1'] = AttributeMapping(source_attributes=[], confidence_score=0,
        transformation_classification='unresolved', unmatched_reason='No completed candidate')
    first.data.result = first.result
    first.data.status = STTMStatus.NEEDS_INPUT
    first.meta['auto_map_retrieval']['model_call_count'] = first_calls
    first.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = {'failure_kind': 'transport'}
    first.meta['auto_map_target_bindings'] = {target: {'attempt': 'original'}}
    first.meta['agent_payload'] = {'attempt': 'original'}
    first.meta['durable_model_provenance'] = {'attempt_model_call_counts': [99],
        'model_call_count': 99, 'validated_results': {target: _durable_proxy()._resolution_digest(proven.model_dump(mode='json'))}}
    latest = first.model_copy(deep=True)
    latest.meta['auto_map_target_bindings'] = {'NAME1': {'attempt': 'latest'}}
    latest.meta['agent_payload'] = {'attempt': 'latest'}
    latest.meta['agent_payload_attempts'] = [{'attempt': 'latest'}]
    latest.meta['auto_map_retrieval']['model_call_count'] = 0 if replacement == 'zero' else 1
    latest.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = {
        'failure_kind': 'stopped', 'stop_reason': 'canceled', 'preparation_stage': 'not_dispatched'}
    latest.warnings = [ApiWarning(code='auto_map_fast_stage_failed', message='Latest preparation stopped')]
    if replacement == 'zero':
        latest.result.mappings[target] = AttributeMapping(source_attributes=[], confidence_score=0,
            transformation_classification='unresolved', unmatched_reason='Preparation stopped')
        # A valid-looking row on a zero-call response is not model provenance.
        latest.result.mappings['NAME1'] = proven.model_copy(deep=True)
    else:
        invalid = proven.model_copy(deep=True)
        for candidate in invalid.candidates:
            candidate.validation_status = 'invalid'
        invalid.source_attributes = ['a.MISSING']
        latest.result.mappings[target] = invalid
    latest.data.result = latest.result
    intermediate = latest.model_copy(deep=True)
    intermediate.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics']['stop_reason'] = None
    calls = _worker_http(monkeypatch, [first, *([intermediate] if retry_count == 2 else []), latest])
    client = _durable_proxy(automap_run_retry_attempts=3)
    merged = client._invoke_complete_batch(req, headers={}, batch_index=0, planned_model_payload={})
    accepted = client._resolution_batch_response(req, merged, 0)
    selected = accepted.result.mappings[target]
    if first_calls:
        assert selected.model_dump() == proven.model_dump()
    else:
        assert selected.transformation_classification == 'unresolved'
        assert not selected.candidates
    assert accepted.result.mappings['NAME1'].transformation_classification == 'unresolved'
    assert len(calls) == retry_count + 1
    assert accepted.meta['auto_map_retrieval'] == latest.meta['auto_map_retrieval']
    assert accepted.meta['durable_model_provenance']['attempt_model_call_counts'] == [first_calls] + [0 if replacement == 'zero' else 1] * retry_count
    assert accepted.meta['durable_model_provenance']['model_call_count'] == first_calls + retry_count * (replacement == 'invalid')
    assert set(accepted.meta['durable_model_provenance']['validated_results']) == ({target} if first_calls else set())
    assert client._fast_response_diagnostics(accepted) == client._fast_response_diagnostics(latest)
    assert any(w.message == 'Latest preparation stopped' for w in accepted.warnings)
    assert accepted.meta['agent_payload_attempts'] == [{'attempt': 'original'}] + [{'attempt': 'latest'}] * retry_count
    assert accepted.meta['auto_map_target_bindings'][target] == {'attempt': 'original'}
    record = {'job_id': 'retry-provenance', 'owner': 'ALICE', 'state_version': 1,
        'request_envelope': req.model_dump(mode='json'),
        'partial_responses': [{'batch_index': 0, 'response': client._compact_partial_response(accepted).model_dump(mode='json'),
            'batch_identity': client._batch_identity(req, req.data.attributes)}]}
    session = DurableSession(text=text)
    client._persist_job(record, headers={}, session=session, required=True)
    restarted = _durable_proxy()
    loaded = restarted._load_persisted_job(record['job_id'], owner='ALICE', headers={}, session=session)
    assert MARKER not in loaded
    assert loaded['partial_responses'] == record['partial_responses']
    restored = STTMBuilderResponse.model_validate(loaded['partial_responses'][0]['response'])
    reaccepted = restarted._resolution_batch_response(req, restored, 0)
    assert reaccepted.result == accepted.result
    assert reaccepted.meta == accepted.meta
    assert len(calls) == retry_count + 1  # Reload never calls a worker.
    if first_calls and replacement == 'zero':
        changed = restored.model_copy(deep=True)
        changed.data.result.mappings[target].source_attributes = ['a.MISSING']
        assert restarted._resolution_batch_response(req, changed, 0).result.mappings[target].transformation_classification == 'unresolved'


@pytest.mark.parametrize('text', [False, True])
def test_actual_preparation_stop_after_valid_worker_survives_durable_receipt(monkeypatch, text):
    from types import SimpleNamespace
    from app.core.automap_batch import invoke_batch
    from app.core.automap_row_candidates import validate_row_candidates
    from app.core.automap_scan import ScanStopped, ScanStatus
    from app.schema.sttm_builder import STTMBuilderResponse, STTMStatus, SubAgent
    from tests.unit.core.test_automap_fast_batch import service, FinalAgent
    from tests.test_automap_durable_json import DurableSession

    req, first = _fast_worker_response()
    first = validate_row_candidates(SimpleNamespace(_query_session=None), req, first)
    first.meta['auto_map_retrieval']['auto_map_fast_path']['fast_diagnostics'] = {'failure_kind': 'transport'}
    builder = service(FinalAgent())
    def stop_preparation(*args, **kwargs):
        raise ScanStopped(ScanStatus.CANCELED, 'Preparation stopped before model dispatch')
    builder._fast_model_runtime_factory = stop_preparation
    raw, thread, payload = invoke_batch(builder, req, SimpleNamespace())
    parsed = builder._parse_envelope(raw)
    latest = STTMBuilderResponse.from_invocation(req, thread_id=thread, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=parsed[1], message='Preparation stopped',
        status=STTMStatus.NEEDS_INPUT,
        warnings=builder._auto_map_response_warnings(parsed[3], payload.get('warnings', [])),
        meta={'auto_map_retrieval': payload['auto_map_retrieval']})
    assert not builder._agent.calls
    assert latest.meta['auto_map_retrieval']['model_call_count'] == 0
    assert latest.result.mappings['NAME0'].transformation_classification == 'unresolved'
    calls = _worker_http(monkeypatch, [first, latest])
    client = _durable_proxy()
    accepted = client._resolution_batch_response(req, client._invoke_complete_batch(
        req, headers={}, batch_index=0, planned_model_payload={}), 0)
    assert accepted.result == first.result
    assert accepted.meta['auto_map_retrieval'] == latest.meta['auto_map_retrieval']
    assert accepted.meta['durable_model_provenance']['attempt_model_call_counts'] == [1, 0]
    assert accepted.meta['durable_model_provenance']['model_call_count'] == 1
    assert set(w.code for w in latest.warnings) <= set(w.code for w in accepted.warnings)
    record = {'job_id': 'actual-preparation-stop', 'owner': 'ALICE', 'state_version': 1,
        'request_envelope': req.model_dump(mode='json'), 'partial_responses': [{'batch_index': 0,
            'response': client._compact_partial_response(accepted).model_dump(mode='json'),
            'batch_identity': client._batch_identity(req, req.data.attributes)}]}
    session = DurableSession(text=text)
    client._persist_job(record, headers={}, session=session, required=True)
    restarted = _durable_proxy()
    loaded = restarted._load_persisted_job(record['job_id'], owner='ALICE', headers={}, session=session)
    restored = STTMBuilderResponse.model_validate(loaded['partial_responses'][0]['response'])
    assert restarted._resolution_batch_response(req, restored, 0).result == first.result
    assert len(calls) == 2


@pytest.mark.parametrize('replacement_valid',[True,False])
def test_retry_does_not_label_validated_recovered_batch_as_still_failed(monkeypatch,replacement_valid):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    from app.schema.sttm_builder import MappingCandidate,STTMStatus
    from app.schema.contracts import ApiWarning
    from tests.unit.core.test_auto_mapping_proxy import _request,_response
    req=_request(1)
    req.meta['auto_map_fast_path']='v1'
    client=AutoMappingProxyClient(Settings(_env_file=None).model_copy(update={
        'auto_mapping_service_url':'http://worker.invalid',
        'automap_context_retrieval_v1':True,'automap_durable_runs_v2':True,'automap_run_retry_attempts':1}))
    old=_response(req);new=_response(req)
    target=req.data.attributes[0].target_attribute
    old.warnings=[ApiWarning(code='auto_map_fast_stage_failed',message='Prior transport failure',field='source_mapping_agent'),
                  ApiWarning(code='BUSINESS_REVIEW',message='Keep this real review requirement',field=target)]
    old.meta['auto_map_retrieval']={'auto_map_fast_path':{'fast_diagnostics':{'failure_kind':'admission_unavailable'}}}
    old.data.status=STTMStatus.NEEDS_INPUT
    new.meta['auto_map_retrieval']={'auto_map_fast_path':{'fast_diagnostics':{}}}
    mapping=new.data.result.mappings[target]
    candidate=MappingCandidate(**mapping.model_dump(exclude={'candidates','selected_candidate_id','draft_candidate_id','suggestions'}),
        candidate_id='verified',validation_status='valid' if replacement_valid else 'invalid')
    mapping.candidates=[candidate];mapping.selected_candidate_id='verified' if replacement_valid else None
    calls=_worker_http(monkeypatch, [old, new])
    response=client._invoke_complete_batch(req,headers={},batch_index=0,planned_model_payload={})
    codes={w.code for w in response.warnings}
    assert len(calls)==2 and 'BUSINESS_REVIEW' in codes
    assert ('auto_map_fast_stage_failed' not in codes)==replacement_valid
    if replacement_valid:assert response.data.status==STTMStatus.COMPLETED
    assert response.meta['durable_transport_history']==[{'attempt':0,'failure_kind':'admission_unavailable'}]


def test_preparation_contention_reuses_exact_thread_and_posts_once(monkeypatch):
    from app.core.automap_admission import AdmissionContended
    original=DurableRunAdmission.record_preparation;seen=[]
    def save(self,permit,reference,archive_ref,seconds):
        seen.append((permit,reference,archive_ref))
        if len(seen)<3:raise AdmissionContended('rolled back lock timeout')
        return original(self,permit,reference,archive_ref,seconds)
    monkeypatch.setattr(DurableRunAdmission,'record_preparation',save)
    test_real_background_transport_reaches_model_and_confirms_terminal_before_release('success')
    assert len(seen)==3 and seen[0]==seen[1]==seen[2]


@pytest.mark.parametrize('failure,expected', [('contended','admission_contended'),('commit','admission_claim_uncertain'),('rollback','admission_claim_uncertain'),('stale','admission_invariant')])
def test_preparation_failure_never_posts_or_recreates_thread(monkeypatch,failure,expected):
    from app.core.automap_admission import AdmissionContended, AdmissionClaimUncertain, RemoteCallNotDispatched
    from app.core.automap_fast_transport import _runtime_failure_kind
    attempts=[];posts=[]
    original=BackgroundRunTransport._json_exchange
    def exchange(self,*args,**kwargs):
        if kwargs.get('model_post'):posts.append(1)
        return original(self,*args,**kwargs)
    def save(self,permit,reference,archive_ref,seconds):
        attempts.append((permit,reference,archive_ref))
        error={'contended':AdmissionContended,'commit':AdmissionClaimUncertain,'rollback':AdmissionClaimUncertain,'stale':StalePermit}[failure]('synthetic')
        error.sql_failure={'sql_error_code':'630','query_id':'query-123','sql_state':'57014'}
        raise error
    monkeypatch.setattr(DurableRunAdmission,'record_preparation',save)
    monkeypatch.setattr(BackgroundRunTransport,'_json_exchange',exchange)
    with pytest.raises(RemoteCallNotDispatched) as caught:
        test_real_background_transport_reaches_model_and_confirms_terminal_before_release('success')
    assert len(attempts)==(3 if failure=='contended' else 1) and not posts
    assert all(item==attempts[0] for item in attempts)
    assert _runtime_failure_kind(caught.value).value==expected
    assert caught.value.sql_failure['query_id']=='query-123'


def test_transient_heartbeat_contention_uses_same_owned_permit(monkeypatch):
    from app.core.automap_admission import retry_control_operation, AdmissionContended
    db=MemorySQL();store=pool(db);permit=store.try_claim(identity(1));seen=[];original=store.renew
    request=SimpleNamespace(runtime_trace=RuntimeCallTrace())
    def renew():
        seen.append(permit)
        if len(seen)==1:raise AdmissionContended('rolled back')
        return original(permit)
    retry_control_operation(request,'permit_renewal',renew,renewal=True)
    assert seen==[permit,permit]
    assert db.rows[permit.slot_id-1]['STATE']=='HELD'


def test_preparation_retry_does_not_block_another_ready_batch(monkeypatch):
    original=DurableRunAdmission.record_preparation
    blocked=Event();release=Event();ready=Event();counter=iter(range(2));lock=RLock();first=[None]
    def save(self,*args):
        with lock:
            if first[0] is None:first[0]=id(self)
            is_first=id(self)==first[0]
        if is_first:
            blocked.set();assert release.wait(5)
        else:ready.set()
        return original(self,*args)
    monkeypatch.setattr(DurableRunAdmission,'record_preparation',save)
    with ThreadPoolExecutor(max_workers=2) as executor:
        a=executor.submit(test_real_background_transport_reaches_model_and_confirms_terminal_before_release,'success')
        assert blocked.wait(5)
        b=executor.submit(test_real_background_transport_reaches_model_and_confirms_terminal_before_release,'success')
        try:
            assert ready.wait(5)
            b.result(timeout=5)  # sibling posts and finishes before blocked batch
        finally:release.set()
        a.result(timeout=5)


def test_control_transaction_keeps_native_diagnostics_after_confirmed_rollback():
    from app.core.automap_admission import AdmissionContended
    calls=[]
    class NativeTimeout(Exception):
        sql_error_code=630;sqlstate='57014';sfqid='query-native-123'
    @contextmanager
    def factory():
        def execute(q):
            calls.append(q)
            if q.startswith('SELECT CURRENT'):return [{'ACCOUNT_NAMESPACE':ACCOUNT,'TRANSACTION_ID':None}]
            if q.startswith('UPDATE'):raise NativeTimeout('sensitive SQL and binds must not escape')
            return []
        yield SimpleNamespace(sql=lambda q,params=None:SimpleNamespace(collect=lambda **kwargs:execute(q)))
    store=DurableRunAdmission(session_factory=factory,table=TABLE,account_namespace=ACCOUNT,pool_epoch=EPOCH,capacity=12)
    with pytest.raises(AdmissionContended) as caught:
        with store._transaction() as session:store._sql(session,'UPDATE synthetic')
    assert calls[-1]=='ROLLBACK'
    assert caught.value.control_outcome=='rolled_back'
    assert caught.value.sql_failure=={'error_type':'NativeTimeout','sql_error_code':'630','sql_state':'57014','query_id':'query-native-123'}
    assert 'sensitive' not in str(caught.value)


def test_runtime_progress_is_scoped_read_only_and_never_changes_execution():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.automap_runtime import RuntimeCaller
    settings=SimpleNamespace(automap_durable_runs_v2=True,automap_parallel_permit_table_fqn='D.S.P',automap_parallel_archive_table_fqn='D.S.A')
    proxy=AutoMappingProxyClient.__new__(AutoMappingProxyClient);proxy._settings=settings
    queries=[]
    def execute(q,params):
        queries.append((q,params))
        if 'CURRENT_USER() AS NATIVE_USER' in q:return [{'NATIVE_USER':'ALICE','ROLE_NAME':'TEST_ROLE','ACCOUNT_NAMESPACE':ACCOUNT,'TRANSACTION_ID':None}]
        return [{'PHASE':'model_run','N':1},{'PHASE':'thread_persist','N':1}]
    session=SimpleNamespace(sql=lambda q,params=None:SimpleNamespace(collect=lambda **kwargs:execute(q,params)))
    record={'owner':'ALICE','recovery_role':'TEST_ROLE','created_at':'2026-11-12T00:00:00Z','request_id':'original-parent'}
    result=proxy._with_runtime_progress({'status':'running','stage':'preparing'},record,session)
    assert result['phase_counts']=={'model_run':1,'thread_persist':1} and result['stage']=='model_run'
    assert all(q.lstrip().startswith('SELECT') for q,_ in queries)
    assert queries[-1][1]==['ALICE',RuntimeCaller('ALICE','ALICE','TEST_ROLE',ACCOUNT).access_scope,record['created_at'],'original-parent']
    assert 'A.ACCESS_SCOPE = ?' in queries[-1][0]
    queries.clear();record['owner']='BOB'
    assert proxy._with_runtime_progress({'status':'running','stage':'preparing'},record,session)['stage']=='preparing'
    assert len(queries)==1 # no archive read for another owner


def test_background_preparation_does_not_add_a_redundant_renewal_transaction(monkeypatch):
    def redundant(*args):pytest.fail('Background preparation must renew its lease in the atomic save')
    monkeypatch.setattr(DurableRunAdmission,'renew',redundant)
    test_real_background_transport_reaches_model_and_confirms_terminal_before_release('success')
