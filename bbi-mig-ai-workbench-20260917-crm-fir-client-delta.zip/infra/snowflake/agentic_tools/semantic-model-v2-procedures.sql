-- Canonical semantic-model V2 procedures exported from the validated V2 environment.
-- Namespaces are rendered by bootstrap_sttm_metadata_infra.py.

-- LIST_TABLES
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.LIST_TABLES("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    result        VARIANT;
    query         VARCHAR;
    rs            RESULTSET;
    db_count      INTEGER;
    schema_count  INTEGER;
    table_count   INTEGER;
BEGIN
    query := ''
        SELECT ARRAY_AGG(
            '''''' || DB_NAME || '''''' || ''''.'''' || TABLE_SCHEMA || ''''.'''' || TABLE_NAME
        ) AS FULL_TABLE_NAMES
        FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_TYPE   = ''''BASE TABLE''''
        ORDER BY TABLE_NAME
    '';
    rs := (EXECUTE IMMEDIATE :query);
    LET c1 CURSOR FOR rs;
    FOR r IN c1 DO
        result := r.FULL_TABLE_NAMES;
    END FOR;

    IF (result IS NOT NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''OK'',
            ''code'',    ''SUCCESS'',
            ''message'', ''Tables retrieved from '' || DB_NAME || ''.'' || SCHEMA_NAME,
            ''tables'',  result
        );
    END IF;

    -- Slow path: diagnose why result is NULL
    query := ''
        SELECT COUNT(*) FROM SNOWFLAKE.ACCOUNT_USAGE.DATABASES
        WHERE DATABASE_NAME = UPPER('''''' || DB_NAME || '''''') AND DELETED IS NULL
    '';
    rs := (EXECUTE IMMEDIATE :query);
    LET c2 CURSOR FOR rs;
    FOR r IN c2 DO db_count := r."COUNT(*)"; END FOR;

    IF (db_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''DB_NOT_FOUND'',
            ''message'', ''Database "'' || DB_NAME || ''" does not exist or is not visible to this role.'');
    END IF;

    query := ''
        SELECT COUNT(*) FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.SCHEMATA
        WHERE SCHEMA_NAME = UPPER('''''' || SCHEMA_NAME || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    LET c3 CURSOR FOR rs;
    FOR r IN c3 DO schema_count := r."COUNT(*)"; END FOR;

    IF (schema_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''SCHEMA_NOT_FOUND'',
            ''message'', ''Schema "'' || SCHEMA_NAME || ''" does not exist in "'' || DB_NAME || ''".'');
    END IF;

    query := ''
        SELECT COUNT(*) FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''') AND TABLE_TYPE = ''''BASE TABLE''''
    '';
    rs := (EXECUTE IMMEDIATE :query);
    LET c4 CURSOR FOR rs;
    FOR r IN c4 DO table_count := r."COUNT(*)"; END FOR;

    IF (table_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''OK'', ''code'', ''EMPTY_SCHEMA'',
            ''message'', ''Schema "'' || DB_NAME || ''.'' || SCHEMA_NAME || ''" exists but has no tables.'',
            ''tables'', ARRAY_CONSTRUCT());
    END IF;

    RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNKNOWN'',
        ''message'', ''Could not retrieve tables for unknown reason.'');

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', SQLERRM);
END;
';

-- LIST_COLUMNS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.LIST_COLUMNS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    result        VARIANT;
    query         VARCHAR;
    rs            RESULTSET;
    db_count      INTEGER;
    schema_count  INTEGER;
    table_count   INTEGER;
    col_count     INTEGER;
    table_filter  VARCHAR;
BEGIN
    IF (TABLE_NAME IS NOT NULL) THEN
        table_filter := '' AND TABLE_NAME = UPPER('''''' || TABLE_NAME || '''''')'';
    ELSE
        table_filter := '''';
    END IF;

    query := ''
        SELECT COUNT(*) AS COL_COUNT
        FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
        '' || table_filter;
    rs := (EXECUTE IMMEDIATE :query);
    LET c1 CURSOR FOR rs;
    FOR r IN c1 DO col_count := r.COL_COUNT; END FOR;

    IF (col_count > 0) THEN
        query := ''
            SELECT ARRAY_AGG(
                OBJECT_CONSTRUCT(
                    ''''full_column_name'''', '''''' || DB_NAME || '''''' || ''''.'''' || TABLE_SCHEMA || ''''.'''' || TABLE_NAME || ''''.'''' || COLUMN_NAME,
                    ''''table'''',            TABLE_NAME,
                    ''''column'''',           COLUMN_NAME,
                    ''''position'''',         ORDINAL_POSITION,
                    ''''data_type'''',        DATA_TYPE,
                    ''''max_length'''',       CHARACTER_MAXIMUM_LENGTH,
                    ''''precision'''',        NUMERIC_PRECISION,
                    ''''scale'''',            NUMERIC_SCALE,
                    ''''nullable'''',         IS_NULLABLE,
                    ''''default'''',          COLUMN_DEFAULT,
                    ''''comment'''',          COMMENT
                )
            ) WITHIN GROUP (ORDER BY TABLE_NAME, ORDINAL_POSITION) AS COLUMNS
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
            '' || table_filter;
        rs := (EXECUTE IMMEDIATE :query);
        LET c2 CURSOR FOR rs;
        FOR r IN c2 DO result := r.COLUMNS; END FOR;
        RETURN OBJECT_CONSTRUCT(''status'', ''OK'', ''code'', ''SUCCESS'',
            ''message'', ''Columns retrieved for '' || DB_NAME || ''.'' || SCHEMA_NAME || COALESCE(''.'' || TABLE_NAME, '' (all tables)''),
            ''columns'', result);
    END IF;

    -- Slow path diagnostics
    query := ''SELECT COUNT(*) FROM SNOWFLAKE.ACCOUNT_USAGE.DATABASES WHERE DATABASE_NAME = UPPER('''''' || DB_NAME || '''''') AND DELETED IS NULL'';
    rs := (EXECUTE IMMEDIATE :query);
    LET c3 CURSOR FOR rs;
    FOR r IN c3 DO db_count := r."COUNT(*)"; END FOR;
    IF (db_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''DB_NOT_FOUND'',
            ''message'', ''Database "'' || DB_NAME || ''" does not exist.'');
    END IF;

    query := ''SELECT COUNT(*) FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = UPPER('''''' || SCHEMA_NAME || '''''')'';
    rs := (EXECUTE IMMEDIATE :query);
    LET c4 CURSOR FOR rs;
    FOR r IN c4 DO schema_count := r."COUNT(*)"; END FOR;
    IF (schema_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''SCHEMA_NOT_FOUND'',
            ''message'', ''Schema "'' || SCHEMA_NAME || ''" does not exist in "'' || DB_NAME || ''".'');
    END IF;

    IF (TABLE_NAME IS NOT NULL) THEN
        query := ''SELECT COUNT(*) FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''') AND TABLE_NAME = UPPER('''''' || TABLE_NAME || '''''')'';
        rs := (EXECUTE IMMEDIATE :query);
        LET c5 CURSOR FOR rs;
        FOR r IN c5 DO table_count := r."COUNT(*)"; END FOR;
        IF (table_count = 0) THEN
            RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''TABLE_NOT_FOUND'',
                ''message'', ''Table "'' || TABLE_NAME || ''" does not exist in "'' || DB_NAME || ''.'' || SCHEMA_NAME || ''".'');
        END IF;
        RETURN OBJECT_CONSTRUCT(''status'', ''OK'', ''code'', ''NO_COLUMNS_FOUND'',
            ''message'', ''Table exists but has no accessible columns.'', ''columns'', ARRAY_CONSTRUCT());
    END IF;

    RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNKNOWN'', ''message'', ''Could not retrieve columns.'');

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', SQLERRM);
END;
';

-- GET_TABLE_DDL
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GET_TABLE_DDL("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    query        VARCHAR;
    rs           RESULTSET;
    db_count     INTEGER;
    schema_count INTEGER;
    table_count  INTEGER;
    ddl_text     VARCHAR;
BEGIN
    query := ''SELECT COUNT(*) FROM SNOWFLAKE.ACCOUNT_USAGE.DATABASES WHERE DATABASE_NAME = UPPER('''''' || DB_NAME || '''''') AND DELETED IS NULL'';
    rs := (EXECUTE IMMEDIATE :query);
    LET c1 CURSOR FOR rs;
    FOR r IN c1 DO db_count := r."COUNT(*)"; END FOR;
    IF (db_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''DB_NOT_FOUND'',
            ''message'', ''Database "'' || DB_NAME || ''" does not exist.'');
    END IF;

    query := ''SELECT COUNT(*) FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = UPPER('''''' || SCHEMA_NAME || '''''')'';
    rs := (EXECUTE IMMEDIATE :query);
    LET c2 CURSOR FOR rs;
    FOR r IN c2 DO schema_count := r."COUNT(*)"; END FOR;
    IF (schema_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''SCHEMA_NOT_FOUND'',
            ''message'', ''Schema "'' || SCHEMA_NAME || ''" does not exist in "'' || DB_NAME || ''".'');
    END IF;

    query := ''SELECT COUNT(*) FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''') AND TABLE_NAME = UPPER('''''' || TABLE_NAME || '''''')'';
    rs := (EXECUTE IMMEDIATE :query);
    LET c3 CURSOR FOR rs;
    FOR r IN c3 DO table_count := r."COUNT(*)"; END FOR;
    IF (table_count = 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''TABLE_NOT_FOUND'',
            ''message'', ''Table "'' || TABLE_NAME || ''" does not exist in "'' || DB_NAME || ''.'' || SCHEMA_NAME || ''".'');
    END IF;

    query := ''SELECT GET_DDL(''''TABLE'''', '''''' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME || '''''') AS DDL'';
    rs := (EXECUTE IMMEDIATE :query);
    LET c4 CURSOR FOR rs;
    FOR r IN c4 DO ddl_text := r.DDL; END FOR;

    IF (ddl_text IS NOT NULL AND LENGTH(TRIM(ddl_text)) > 0) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''OK'', ''code'', ''SUCCESS'',
            ''message'', ''DDL retrieved for '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME,
            ''ddl'', ddl_text);
    END IF;

    RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''DDL_ACCESS_DENIED'',
        ''message'', ''Table exists but DDL could not be retrieved. Check OWNERSHIP privilege.'');

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', SQLERRM);
END;
';

-- GET_TABLE_STATS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GET_TABLE_STATS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    query        VARCHAR;
    rs           RESULTSET;
    col_name     VARCHAR;
    col_type     VARCHAR;
    select_frags VARCHAR DEFAULT '''';
    row_count    INTEGER DEFAULT 0;
    stats_failed BOOLEAN DEFAULT FALSE;
    col_array    VARIANT;
BEGIN
    BEGIN
        query := ''
            SELECT COLUMN_NAME, DATA_TYPE
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
            ORDER BY ORDINAL_POSITION
        '';
        rs := (EXECUTE IMMEDIATE :query);
        LET c1 CURSOR FOR rs;

        FOR r IN c1 DO
            col_name := r.COLUMN_NAME;
            col_type := r.DATA_TYPE;

            LET frag VARCHAR DEFAULT
                ''OBJECT_CONSTRUCT(
                    ''''column_name'''',    '''''' || col_name || '''''',
                    ''''data_type'''',      '''''' || col_type || '''''',
                    ''''null_count'''',     SUM(CASE WHEN "'' || col_name || ''" IS NULL THEN 1 ELSE 0 END),
                    ''''distinct_count'''', COUNT(DISTINCT "'' || col_name || ''")''
            ;

            IF (col_type IN (''NUMBER'', ''FLOAT'', ''FLOAT4'', ''FLOAT8'', ''DOUBLE'', ''DOUBLE PRECISION'',
                             ''REAL'', ''INT'', ''INTEGER'', ''BIGINT'', ''SMALLINT'', ''TINYINT'',
                             ''BYTEINT'', ''NUMERIC'', ''DECIMAL'')) THEN
                frag := frag || '',
                    ''''min'''',    TO_VARCHAR(MIN("'' || col_name || ''")),
                    ''''max'''',    TO_VARCHAR(MAX("'' || col_name || ''")),
                    ''''avg'''',    AVG("'' || col_name || ''"),
                    ''''stddev'''', STDDEV("'' || col_name || ''"),
                    ''''p25'''',    APPROX_PERCENTILE("'' || col_name || ''", 0.25),
                    ''''p50'''',    APPROX_PERCENTILE("'' || col_name || ''", 0.50),
                    ''''p75'''',    APPROX_PERCENTILE("'' || col_name || ''", 0.75)'';
            ELSEIF (col_type IN (''DATE'', ''DATETIME'', ''TIMESTAMP'', ''TIMESTAMP_NTZ'', ''TIMESTAMP_LTZ'', ''TIMESTAMP_TZ'')) THEN
                frag := frag || '',
                    ''''min'''',    TO_VARCHAR(MIN("'' || col_name || ''")),
                    ''''max'''',    TO_VARCHAR(MAX("'' || col_name || ''")),
                    ''''span_days'''', DATEDIFF(day, MIN("'' || col_name || ''"), MAX("'' || col_name || ''"))'';
            END IF;

            frag := frag || '')'';

            IF (select_frags = '''') THEN
                select_frags := frag;
            ELSE
                select_frags := select_frags || '', '' || frag;
            END IF;
        END FOR;

    EXCEPTION
        WHEN OTHER THEN stats_failed := TRUE;
    END;

    IF (stats_failed = TRUE OR select_frags = '''') THEN
        LET db_cnt INTEGER DEFAULT 0;
        LET sc_cnt INTEGER DEFAULT 0;
        LET tb_cnt INTEGER DEFAULT 0;

        query := ''SELECT COUNT(*) AS CNT FROM SNOWFLAKE.ACCOUNT_USAGE.DATABASES WHERE DATABASE_NAME = UPPER('''''' || DB_NAME || '''''') AND DELETED IS NULL'';
        rs := (EXECUTE IMMEDIATE :query); LET cv1 CURSOR FOR rs; FOR r IN cv1 DO db_cnt := r.CNT; END FOR;
        IF (db_cnt = 0) THEN RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''DB_NOT_FOUND'', ''message'', ''Database "'' || DB_NAME || ''" does not exist.''); END IF;

        query := ''SELECT COUNT(*) AS CNT FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = UPPER('''''' || SCHEMA_NAME || '''''')'';
        rs := (EXECUTE IMMEDIATE :query); LET cv2 CURSOR FOR rs; FOR r IN cv2 DO sc_cnt := r.CNT; END FOR;
        IF (sc_cnt = 0) THEN RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''SCHEMA_NOT_FOUND'', ''message'', ''Schema not found.''); END IF;

        query := ''SELECT COUNT(*) AS CNT FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''') AND TABLE_NAME = UPPER('''''' || TABLE_NAME || '''''')'';
        rs := (EXECUTE IMMEDIATE :query); LET cv3 CURSOR FOR rs; FOR r IN cv3 DO tb_cnt := r.CNT; END FOR;
        IF (tb_cnt = 0) THEN RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''TABLE_NOT_FOUND'', ''message'', ''Table not found.''); END IF;

        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''STATS_UNAVAILABLE'', ''message'', ''Could not build stats query.'');
    END IF;

    query := ''SELECT COUNT(*) AS CNT FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;
    rs := (EXECUTE IMMEDIATE :query);
    LET c2 CURSOR FOR rs;
    FOR r IN c2 DO row_count := r.CNT; END FOR;

    query := ''SELECT ARRAY_CONSTRUCT('' || select_frags || '') AS COL_ARRAY FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;
    rs := (EXECUTE IMMEDIATE :query);
    LET c3 CURSOR FOR rs;
    FOR r IN c3 DO col_array := r.COL_ARRAY; END FOR;

    RETURN OBJECT_CONSTRUCT(
        ''status'',    ''OK'',
        ''code'',      ''SUCCESS'',
        ''table'',     DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME,
        ''row_count'', row_count,
        ''columns'',   col_array
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', SQLERRM);
END;
';

-- GET_TABLE_RELATIONSHIPS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GET_TABLE_RELATIONSHIPS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR, "IN_SCHEMA_SWEEP" BOOLEAN DEFAULT FALSE)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    fqn              VARCHAR;
    query            VARCHAR;
    rs               RESULTSET;
    rs2              RESULTSET;
    rs3              RESULTSET;

    -- PK detection state
    confirmed_pk     ARRAY   DEFAULT ARRAY_CONSTRUCT();
    eliminated       ARRAY   DEFAULT ARRAY_CONSTRUCT();
    composite_cands  ARRAY   DEFAULT ARRAY_CONSTRUCT();
    pk_done          BOOLEAN DEFAULT FALSE;
    col_name         VARCHAR;
    t_total          INTEGER;
    t_nonnull        INTEGER;
    t_distinct       INTEGER;

    -- Column scan variables (V8.1: threshold removed; always Tier1-first)
    col_count              INTEGER DEFAULT 0;
    is_nullable_meta       VARCHAR;
    tier1_passing          ARRAY   DEFAULT ARRAY_CONSTRUCT();
    tier2_passing          ARRAY   DEFAULT ARRAY_CONSTRUCT();
    additional_unique_cols ARRAY   DEFAULT ARRAY_CONSTRUCT();

    -- Relationships
    outgoing         ARRAY   DEFAULT ARRAY_CONSTRUCT();
    incoming         ARRAY   DEFAULT ARRAY_CONSTRUCT();

    -- FK detection
    formal_fk_cols   ARRAY   DEFAULT ARRAY_CONSTRUCT();
    ref_table        VARCHAR;
    ref_schema       VARCHAR;
    ref_total        INTEGER;
    ref_nonnull      INTEGER;
    ref_distinct     INTEGER;
    pk_col           VARCHAR DEFAULT '''';

    -- Gate 1 / Gate 2 variables (data type + overlap check)
    pk_data_type     VARCHAR;
    cand_data_type   VARCHAR;
    fk_data_type     VARCHAR;
    overlap_matches  INTEGER;
    overlap_total    INTEGER;
    overlap_pct      NUMBER;
    overlap_conf     VARCHAR;
    type_compatible  BOOLEAN;
    is_alternate_key              BOOLEAN DEFAULT FALSE;
    alternate_keys_review_required BOOLEAN DEFAULT FALSE;

    -- ── Phase 2 (V8) variables ────────────────────────────────────────
    -- Enabled / error tracking
    p2_enabled          BOOLEAN DEFAULT FALSE;
    p2_phase2_err       VARCHAR DEFAULT '''';

    -- Step 6: Staleness check
    p2_stale_count      INTEGER DEFAULT 0;

    -- Step 6: Cortex Search candidate state
    p2_search_ctx       VARCHAR;
    p2_search_resp      VARIANT;
    p2_cand_table       VARCHAR;
    p2_cand_col         VARCHAR;
    p2_cand_schema      VARCHAR;
    p2_cand_data_type   VARCHAR;
    p2_sim_score        FLOAT;
    p2_skip_cand        BOOLEAN DEFAULT FALSE;
    p2_col_matched      BOOLEAN DEFAULT FALSE;
    p2_already_exact    BOOLEAN DEFAULT FALSE;

    -- Step 6: Gate 2 profile state
    p2_distinct_ratio   NUMBER  DEFAULT 0;
    p2_null_diff        NUMBER  DEFAULT 0;
    p2_fk_distinct      INTEGER DEFAULT 0;
    p2_ref_distinct     INTEGER DEFAULT 0;
    p2_fk_null_pct      NUMBER  DEFAULT 0;
    p2_ref_null_pct     NUMBER  DEFAULT 0;
    p2_fk_min_len       INTEGER DEFAULT 0;
    p2_fk_max_len       INTEGER DEFAULT 0;
    p2_ref_min_len      INTEGER DEFAULT 0;
    p2_ref_max_len      INTEGER DEFAULT 0;
    p2_length_ok        BOOLEAN DEFAULT FALSE;

    -- Step 6: Profile score (max 100 in V9: PATTERN_CLASS adds +25)
    p2_score            INTEGER DEFAULT 0;
    p2_score_max        INTEGER DEFAULT 100;

    -- Step 6: Fuzzy relationship creation
    p2_fuzzy_conf       VARCHAR;
    p2_outgoing_idx     INTEGER DEFAULT 0;
    p2_fuzzy_count      INTEGER DEFAULT 0;

    -- Step 7: Review batch
    p2_review_id            INTEGER DEFAULT 0;
    p2_review_batch         ARRAY   DEFAULT ARRAY_CONSTRUCT();
    p2_review_batch_trimmed ARRAY   DEFAULT ARRAY_CONSTRUCT();
    p2_review_count         INTEGER DEFAULT 0;

    -- Step 7: Cortex Complete
    p2_prompt           VARCHAR;
    p2_llm_raw          VARIANT;
    p2_verdicts         VARIANT;

    -- Step 7: Verdict application (outgoing rebuild)
    p2_verdict_obj      VARIANT;
    p2_has_verdict      BOOLEAN DEFAULT FALSE;
    p2_final_conf       VARCHAR;
    p2_verdict_str      VARCHAR;
    p2_outgoing_final   ARRAY   DEFAULT ARRAY_CONSTRUCT();
    p2_addl_final       ARRAY   DEFAULT ARRAY_CONSTRUCT();
    p2_match_id         INTEGER DEFAULT 0;
    p2_ak_match_id      INTEGER DEFAULT 0;

    -- ── V10: Phase 2 Conditional Gate ────────────────────────────────
    phase2_needed            BOOLEAN DEFAULT FALSE;
    phase2_skip_reason       VARCHAR DEFAULT NULL;
    p2_infra_count           INTEGER DEFAULT 0;
    p2_infra_exists          BOOLEAN DEFAULT FALSE;
    inferred_outgoing_count  INTEGER DEFAULT 0;
    formal_outgoing_count    INTEGER DEFAULT 0;  -- count of FORMAL entries from SHOW IMPORTED KEYS
    orphan_key_col_count     INTEGER DEFAULT 0;  -- key-like cols (_ID/_KEY/_CODE/_NO) not in formal FK set
    p2_schema_fresh_count    INTEGER DEFAULT 0;
    p2_schema_total_count    INTEGER DEFAULT 0;

    -- ── V9: Phase 2A (PK Fuzzy Identification) ────────────────────────
    p2a_found              BOOLEAN DEFAULT FALSE;
    p2a_search_ctx         VARCHAR;
    p2a_search_resp        VARIANT;
    p2a_cand_col           VARCHAR;
    p2a_sim_score          FLOAT;
    p2a_is_key             BOOLEAN DEFAULT FALSE;
    p2a_i                  INTEGER DEFAULT 0;

    -- ── V9: Phase 2C (Fuzzy Incoming FK) ─────────────────────────────
    p2c_search_ctx           VARCHAR;
    p2c_search_resp          VARIANT;
    p2c_cand_table           VARCHAR;
    p2c_cand_col             VARCHAR;
    p2c_cand_schema          VARCHAR;
    p2c_cand_data_type       VARCHAR;
    p2c_sim_score            FLOAT;
    p2c_fk_distinct          INTEGER DEFAULT 0;
    p2c_ref_distinct         INTEGER DEFAULT 0;
    p2c_fk_null_pct          NUMBER  DEFAULT 0;
    p2c_ref_null_pct         NUMBER  DEFAULT 0;
    p2c_fk_min_len           INTEGER DEFAULT 0;
    p2c_fk_max_len           INTEGER DEFAULT 0;
    p2c_ref_min_len          INTEGER DEFAULT 0;
    p2c_ref_max_len          INTEGER DEFAULT 0;
    p2c_distinct_ratio       NUMBER  DEFAULT 0;
    p2c_length_ok            BOOLEAN DEFAULT FALSE;
    p2c_score                INTEGER DEFAULT 0;
    p2c_skip_cand            BOOLEAN DEFAULT FALSE;
    p2c_fuzzy_conf           VARCHAR;
    p2c_fuzzy_count          INTEGER DEFAULT 0;
    p2c_already_has_incoming BOOLEAN DEFAULT FALSE;
    p2c_pattern_match        BOOLEAN DEFAULT FALSE;
    p2c_fk_pattern           VARCHAR;
    p2c_ref_pattern          VARCHAR;

    -- ── V9: Phase 2B Gate 2.4 pattern variables (reused in 2C) ────────
    -- p2c_fk_pattern / p2c_ref_pattern declared above; used in both 2B and 2C

    -- ── V10: Step 8 (Incoming Relationship Review) variables ────────────
    p8_review_batch         ARRAY   DEFAULT ARRAY_CONSTRUCT();
    p8_review_batch_trimmed ARRAY   DEFAULT ARRAY_CONSTRUCT();
    p8_review_count         INTEGER DEFAULT 0;
    p8_review_id            INTEGER DEFAULT 0;
    p8_prompt               VARCHAR;
    p8_llm_raw              VARIANT;
    p8_verdicts             VARIANT;
    p8_verdict_obj          VARIANT;
    p8_has_verdict          BOOLEAN DEFAULT FALSE;
    p8_verdict_str          VARCHAR;
    p8_final_conf           VARCHAR;
    p8_incoming_final       ARRAY   DEFAULT ARRAY_CONSTRUCT();
    -- Fix 2: reverse-direction false-positive flag (set per Phase 2C candidate)
    p2c_is_rfp              BOOLEAN DEFAULT FALSE;

BEGIN
    fqn := DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;

    -- ── 0. Validate ──────────────────────────────────────────────────
    BEGIN
        query := ''
            SELECT COUNT(*) AS CNT
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            IF (r.CNT = 0) THEN
                RETURN OBJECT_CONSTRUCT(
                    ''status'',  ''ERROR'',
                    ''code'',    ''TABLE_NOT_FOUND'',
                    ''message'', ''Table "'' || TABLE_NAME || ''" does not exist in "''
                               || DB_NAME || ''.'' || SCHEMA_NAME || ''".'');
            END IF;
        END FOR;
    EXCEPTION WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''INVALID_LOCATION'',
            ''message'', ''Database/schema not found or access denied: ''
                       || DB_NAME || ''.'' || SCHEMA_NAME);
    END;

    -- ── 1. FORMAL OUTGOING (Imported Keys) ───────────────────────────
    BEGIN
        EXECUTE IMMEDIATE ''SHOW IMPORTED KEYS IN TABLE '' || fqn;
        query := ''
            SELECT "pk_schema_name" AS pk_schema,
                   "pk_table_name"  AS pk_table,
                   "fk_column_name" AS fk_col,
                   "pk_column_name" AS pk_col
            FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            outgoing       := ARRAY_APPEND(outgoing, OBJECT_CONSTRUCT(
                ''schema'',          r.pk_schema,
                ''table'',           r.pk_table,
                ''type'',            ''FORMAL'',
                ''confidence'',      ''HIGH'',
                ''inferred_method'', ''FORMAL_CONSTRAINT'',
                ''column_mappings'', ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                    ''fk_column'', r.fk_col, ''pk_column'', r.pk_col))));
            formal_fk_cols        := ARRAY_APPEND(formal_fk_cols, r.fk_col);
            formal_outgoing_count := formal_outgoing_count + 1;  -- V10: track formal FK count
        END FOR;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    -- ── 2. FORMAL INCOMING (Exported Keys) ───────────────────────────
    BEGIN
        EXECUTE IMMEDIATE ''SHOW EXPORTED KEYS IN TABLE '' || fqn;
        query := ''
            SELECT "fk_schema_name" AS fk_schema,
                   "fk_table_name"  AS fk_table,
                   "fk_column_name" AS fk_col,
                   "pk_column_name" AS pk_col
            FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            incoming := ARRAY_APPEND(incoming, OBJECT_CONSTRUCT(
                ''schema'',          r.fk_schema,
                ''table'',           r.fk_table,
                ''type'',            ''FORMAL'',
                ''confidence'',      ''HIGH'',
                ''inferred_method'', ''FORMAL_CONSTRAINT'',
                ''column_mappings'', ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                    ''fk_column'', r.fk_col, ''pk_column'', r.pk_col))));
        END FOR;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    -- ── 3. PK DETECTION ──────────────────────────────────────────────

    -- ── Step A: Formal PRIMARY KEY — HIGH confidence, always early-exit ──
    BEGIN
        EXECUTE IMMEDIATE ''SHOW PRIMARY KEYS IN TABLE '' || fqn;
        query := ''SELECT "column_name" AS col
                  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            confirmed_pk := ARRAY_APPEND(confirmed_pk, OBJECT_CONSTRUCT(
                ''column'',              r.col,
                ''confidence'',          ''HIGH'',
                ''uniqueness_verified'', TRUE,
                ''reason'',              ''Formally defined PRIMARY KEY constraint''));
            pk_done  := TRUE;
            pk_col   := r.col;
        END FOR;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    -- ── Step B: IS_IDENTITY = YES ─────────────────────────────────────
    IF (NOT pk_done) THEN
        query := ''
            SELECT COLUMN_NAME
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
              AND IS_IDENTITY  = ''''YES''''
            ORDER BY ORDINAL_POSITION'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            col_name := r.COLUMN_NAME;
            query := ''SELECT COUNT(*) AS t, COUNT('' || col_name || '') AS n,
                             COUNT(DISTINCT '' || col_name || '') AS d FROM '' || fqn;
            rs2 := (EXECUTE IMMEDIATE :query);
            FOR r2 IN rs2 DO
                t_total := r2.t; t_nonnull := r2.n; t_distinct := r2.d;
            END FOR;
            IF (t_total > 0 AND t_total = t_distinct AND t_nonnull = t_total) THEN
                IF (NOT pk_done) THEN
                    confirmed_pk := ARRAY_APPEND(confirmed_pk, OBJECT_CONSTRUCT(
                        ''column'',              col_name,
                        ''confidence'',          ''MEDIUM'',
                        ''uniqueness_verified'', TRUE,
                        ''reason'',              ''IS_IDENTITY = YES — uniqueness confirmed by data''));
                    pk_done := TRUE; pk_col := col_name;
                END IF;
            ELSE
                eliminated := ARRAY_APPEND(eliminated, OBJECT_CONSTRUCT(
                    ''column'',             col_name,
                    ''uniqueness_verified'', FALSE,
                    ''elimination_reason'', ''IS_IDENTITY but duplicate/null rows detected''));
            END IF;
        END FOR;
    END IF;

    -- ── Step C: Data-driven PK — Always-Tiered scan (V8.1) ───────────
    --
    --  All tables use the same two-phase tiered strategy regardless of
    --  column count. The < 9 / >= 9 threshold has been removed.
    --
    --  Tier 1 definition (REGEXP_LIKE, literal underscore suffix):
    --    _ID  _KEY  _CODE  _NUM  _NO  _REF  _UUID  _GUID
    --
    --  Strategy:
    --    C-1: Scan Tier 1 columns only (key-like names, all table sizes)
    --    C-2: Scan Tier 2 columns (non-key-like) ONLY if C-1 yields 0 passers
    --
    --  Null logic: metadata IS_NULLABLE as hint only.
    --    IS_NULLABLE = ''NO''  → skip null check, proceed to uniqueness
    --    IS_NULLABLE = ''YES'' → run actual COUNT check; skip only if real nulls found
    --
    --  C-3 decision tree (unchanged):
    --    Tier1=1, Tier2=0 → confirmed_pk MEDIUM (Case A)
    --    Tier1=1, Tier2≥1 → confirmed_pk MEDIUM + alternate_keys_review_required (Case B)
    --    Tier1≥2          → composite_pk_candidates + human_review_required (Case C)
    --    Tier1=0, Tier2=1 → confirmed_pk LOW (Case D)
    --    Tier1=0, Tier2≥2 → composite_pk_candidates + human_review_required (Case E)
    --    nothing passes   → metadata fallback composite_cands (Case F)
    -- ─────────────────────────────────────────────────────────────────

    IF (NOT pk_done) THEN

        -- ── C-0: Fetch total column count (diagnostic; no longer gates scan strategy) ──
        query := ''
            SELECT COUNT(*) AS col_cnt
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            col_count := r.col_cnt;
        END FOR;

        -- ── C-1: TIER 1 SCAN — key-like columns only (all table sizes) ──
        -- REGEXP_LIKE: ''_'' is a LITERAL underscore in regex — no ESCAPE needed.
        -- Matches: CLIENT_ID ✅   SALESFORCEID ❌ (no literal _ before ID)
        query := ''
            SELECT COLUMN_NAME, IS_NULLABLE
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
              AND IS_IDENTITY  != ''''YES''''
              AND REGEXP_LIKE(COLUMN_NAME, ''''.*(_ID|_KEY|_CODE|_NUM|_NO|_REF|_UUID|_GUID)$'''')
            ORDER BY ORDINAL_POSITION'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            col_name         := r.COLUMN_NAME;
            is_nullable_meta := r.IS_NULLABLE;

            query := ''SELECT COUNT(*) AS t, COUNT('' || col_name || '') AS n,
                             COUNT(DISTINCT '' || col_name || '') AS d FROM '' || fqn;
            rs2 := (EXECUTE IMMEDIATE :query);
            FOR r2 IN rs2 DO
                t_total := r2.t; t_nonnull := r2.n; t_distinct := r2.d;
            END FOR;

            IF (is_nullable_meta = ''YES'' AND t_nonnull != t_total) THEN
                eliminated := ARRAY_APPEND(eliminated, OBJECT_CONSTRUCT(
                    ''column'',             col_name,
                    ''uniqueness_verified'', FALSE,
                    ''elimination_reason'', ''Real NULLs found in data ('' ||
                        (t_total - t_nonnull) || '' null rows)''));
            ELSEIF (t_total > 0 AND t_total = t_distinct AND t_nonnull = t_total) THEN
                tier1_passing := ARRAY_APPEND(tier1_passing, col_name);
            ELSE
                eliminated := ARRAY_APPEND(eliminated, OBJECT_CONSTRUCT(
                    ''column'',             col_name,
                    ''uniqueness_verified'', FALSE,
                    ''elimination_reason'', ''distinct_count ('' || t_distinct
                        || '') != row_count ('' || t_total || '')''));
            END IF;
        END FOR;

        -- ── C-2: TIER 2 SCAN — non-key-like columns, only if Tier 1 found no candidates ──
        IF (ARRAY_SIZE(tier1_passing) = 0) THEN
            query := ''
                SELECT COLUMN_NAME, IS_NULLABLE
                FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
                  AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
                  AND IS_IDENTITY  != ''''YES''''
                  AND NOT REGEXP_LIKE(COLUMN_NAME, ''''.*(_ID|_KEY|_CODE|_NUM|_NO|_REF|_UUID|_GUID)$'''')
                ORDER BY ORDINAL_POSITION'';
            rs := (EXECUTE IMMEDIATE :query);
            FOR r IN rs DO
                col_name         := r.COLUMN_NAME;
                is_nullable_meta := r.IS_NULLABLE;

                query := ''SELECT COUNT(*) AS t, COUNT('' || col_name || '') AS n,
                                 COUNT(DISTINCT '' || col_name || '') AS d FROM '' || fqn;
                rs2 := (EXECUTE IMMEDIATE :query);
                FOR r2 IN rs2 DO
                    t_total := r2.t; t_nonnull := r2.n; t_distinct := r2.d;
                END FOR;

                IF (is_nullable_meta = ''YES'' AND t_nonnull != t_total) THEN
                    eliminated := ARRAY_APPEND(eliminated, OBJECT_CONSTRUCT(
                        ''column'',             col_name,
                        ''uniqueness_verified'', FALSE,
                        ''elimination_reason'', ''Real NULLs found in data ('' ||
                            (t_total - t_nonnull) || '' null rows)''));
                ELSEIF (t_total > 0 AND t_total = t_distinct AND t_nonnull = t_total) THEN
                    tier2_passing := ARRAY_APPEND(tier2_passing, col_name);
                ELSE
                    eliminated := ARRAY_APPEND(eliminated, OBJECT_CONSTRUCT(
                        ''column'',             col_name,
                        ''uniqueness_verified'', FALSE,
                        ''elimination_reason'', ''distinct_count ('' || t_distinct
                            || '') != row_count ('' || t_total || '')''));
                END IF;
            END FOR;
        END IF;
        -- (Tier 1 found candidates → Tier 2 scan intentionally skipped)

        -- ── C-3: Accidental-uniqueness mitigation + alternate key capture ──
        IF (ARRAY_SIZE(tier1_passing) = 1) THEN
            -- ── Case A or B ──────────────────────────────────────────
            pk_col   := tier1_passing[0]::VARCHAR;
            confirmed_pk := ARRAY_APPEND(confirmed_pk, OBJECT_CONSTRUCT(
                ''column'',              pk_col,
                ''confidence'',          ''MEDIUM'',
                ''uniqueness_verified'', TRUE,
                ''reason'',              ''Key-like column name, non-null + unique confirmed by data''));
            pk_done  := TRUE;

            -- Case B: Tier 2 passers exist → surface as alternate unique keys
            IF (ARRAY_SIZE(tier2_passing) > 0) THEN
                alternate_keys_review_required := TRUE;
                FOR i IN 0 TO ARRAY_SIZE(tier2_passing) - 1 DO
                    additional_unique_cols := ARRAY_APPEND(additional_unique_cols, OBJECT_CONSTRUCT(
                        ''column'',              tier2_passing[i]::VARCHAR,
                        ''tier'',                ''TIER2_NON_KEY_LIKE'',
                        ''uniqueness_verified'', TRUE,
                        ''reason'',              ''Non-key-like column also passed non-null + uniqueness checks'',
                        ''review_note'',         ''Verify if this is an alternate business key (e.g. legacy system ID) or coincidentally unique data. Excluded from outgoing FK candidate search.''));
                END FOR;
            END IF;

        ELSEIF (ARRAY_SIZE(tier1_passing) > 1) THEN
            -- ── Case C ───────────────────────────────────────────────
            pk_col := tier1_passing[0]::VARCHAR;
            FOR i IN 0 TO ARRAY_SIZE(tier1_passing) - 1 DO
                composite_cands := ARRAY_APPEND(composite_cands, OBJECT_CONSTRUCT(
                    ''column'',     tier1_passing[i]::VARCHAR,
                    ''tier'',       ''TIER1_KEY_LIKE'',
                    ''confidence'', ''MEDIUM'',
                    ''reason'',     ''Multiple Tier 1 key-like columns are unique and non-null — composite PK or alternate key''));
            END FOR;
            pk_done := FALSE;
            FOR i IN 0 TO ARRAY_SIZE(tier2_passing) - 1 DO
                additional_unique_cols := ARRAY_APPEND(additional_unique_cols, OBJECT_CONSTRUCT(
                    ''column'',              tier2_passing[i]::VARCHAR,
                    ''tier'',               ''TIER2_NON_KEY_LIKE'',
                    ''uniqueness_verified'', TRUE,
                    ''reason'',             ''Non-key-like column also passed non-null + uniqueness checks'',
                    ''review_note'',        ''PK ambiguous among Tier 1 columns; this Tier 2 column is also unique and non-null. Human review required.''));
            END FOR;

        ELSEIF (ARRAY_SIZE(tier2_passing) = 1) THEN
            -- ── Case D ───────────────────────────────────────────────
            pk_col   := tier2_passing[0]::VARCHAR;
            confirmed_pk := ARRAY_APPEND(confirmed_pk, OBJECT_CONSTRUCT(
                ''column'',              pk_col,
                ''confidence'',          ''LOW'',
                ''uniqueness_verified'', TRUE,
                ''reason'',              ''Non-key-like column, non-null + unique confirmed by data — no key-like column found''));
            pk_done  := TRUE;

        ELSEIF (ARRAY_SIZE(tier2_passing) > 1) THEN
            -- ── Case E ───────────────────────────────────────────────
            pk_col := tier2_passing[0]::VARCHAR;
            FOR i IN 0 TO ARRAY_SIZE(tier2_passing) - 1 DO
                composite_cands := ARRAY_APPEND(composite_cands, OBJECT_CONSTRUCT(
                    ''column'',     tier2_passing[i]::VARCHAR,
                    ''tier'',       ''TIER2_NON_KEY_LIKE'',
                    ''confidence'', ''LOW'',
                    ''reason'',     ''Multiple non-key-like columns are unique and non-null — composite PK or accidental uniqueness''));
            END FOR;
            pk_done := FALSE;

        ELSE
            -- ── Case F: Nothing passed — metadata fallback ────────────
            query := ''
                SELECT COLUMN_NAME
                FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
                  AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
                  AND IS_NULLABLE  = ''''NO''''
                ORDER BY ORDINAL_POSITION'';
            rs := (EXECUTE IMMEDIATE :query);
            FOR r IN rs DO
                composite_cands := ARRAY_APPEND(composite_cands, r.COLUMN_NAME);
            END FOR;
            pk_done := FALSE;
        END IF;

    END IF;  -- end outer IF (NOT pk_done)

    -- ── 4. INFERRED INCOMING — Gate 1 (data type) + Gate 2 (value overlap) ──
    IF (pk_done AND pk_col != '''') THEN
        query := ''
            SELECT DATA_TYPE
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
              AND COLUMN_NAME  = UPPER('''''' || pk_col      || '''''')
            LIMIT 1'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            pk_data_type := r.DATA_TYPE;
        END FOR;

        query := ''
            SELECT c.TABLE_SCHEMA, c.TABLE_NAME, c.DATA_TYPE
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS c
            WHERE c.TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND c.TABLE_NAME  != UPPER('''''' || TABLE_NAME  || '''''')
              AND c.COLUMN_NAME  = UPPER('''''' || pk_col      || '''''')'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO

            cand_data_type  := r.DATA_TYPE;
            type_compatible := (
                (pk_data_type = cand_data_type)
                OR (pk_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL'') AND cand_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL''))
                OR (pk_data_type IN (''VARCHAR'',''TEXT'',''CHAR'')              AND cand_data_type IN (''VARCHAR'',''TEXT'',''CHAR''))
                OR (pk_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ'') AND cand_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ''))
            );

            IF (type_compatible) THEN
                overlap_matches := 0;
                overlap_total   := 0;
                query := ''
                    SELECT
                        COUNT(fk_sample.'' || pk_col || '')  AS total_sampled,
                        COUNT(parent_col.'' || pk_col || '') AS matches
                    FROM (
                        SELECT DISTINCT '' || pk_col || ''
                        FROM '' || DB_NAME || ''.'' || r.TABLE_SCHEMA || ''.'' || r.TABLE_NAME || ''
                        WHERE '' || pk_col || '' IS NOT NULL
                        LIMIT 20
                    ) fk_sample
                    LEFT JOIN (
                        SELECT DISTINCT '' || pk_col || ''
                        FROM '' || fqn || ''
                        WHERE '' || pk_col || '' IS NOT NULL
                    ) parent_col ON parent_col.'' || pk_col || '' = fk_sample.'' || pk_col;
                rs2 := (EXECUTE IMMEDIATE :query);
                FOR r2 IN rs2 DO
                    overlap_total   := r2.total_sampled;
                    overlap_matches := r2.matches;
                END FOR;

                overlap_pct := IFF(overlap_total = 0, 0,
                                   overlap_matches * 100.0 / overlap_total);

                IF      (overlap_pct >= 80) THEN overlap_conf := ''MEDIUM'';
                ELSEIF  (overlap_pct >= 40) THEN overlap_conf := ''LOW'';
                ELSE                            overlap_conf := ''SKIP'';
                END IF;

                IF (overlap_conf != ''SKIP'') THEN
                    incoming := ARRAY_APPEND(incoming, OBJECT_CONSTRUCT(
                        ''schema'',            r.TABLE_SCHEMA,
                        ''table'',             r.TABLE_NAME,
                        ''type'',              ''INFERRED'',
                        ''confidence'',        overlap_conf,
                        ''inferred_method'',   ''PK_COLUMN_MATCH'',
                        ''value_overlap_pct'', overlap_pct,
                        ''data_type_match'',   TRUE,
                        ''column_mappings'',   ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                            ''fk_column'', pk_col, ''pk_column'', pk_col))));
                END IF;

            END IF;
        END FOR;
    END IF;


    -- ── 5. FK DETECTION — INFERRED OUTGOING ───────────────────────────
    query := ''
        SELECT COLUMN_NAME, DATA_TYPE
        FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
          AND UPPER(COLUMN_NAME) != UPPER('''''' || pk_col || '''''')
        ORDER BY ORDINAL_POSITION'';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO
        col_name     := r.COLUMN_NAME;
        fk_data_type := r.DATA_TYPE;

        is_alternate_key := FALSE;
        FOR ak IN 0 TO ARRAY_SIZE(additional_unique_cols) - 1 DO
            IF (additional_unique_cols[ak]:column::VARCHAR = col_name) THEN
                is_alternate_key := TRUE;
            END IF;
        END FOR;

        IF (NOT ARRAY_CONTAINS(col_name::VARIANT, formal_fk_cols) AND NOT is_alternate_key) THEN

            query := ''
                SELECT TABLE_SCHEMA, TABLE_NAME, DATA_TYPE
                FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
                  AND TABLE_NAME  != UPPER('''''' || TABLE_NAME  || '''''')
                  AND COLUMN_NAME  = UPPER('''''' || col_name    || '''''')'';
            rs2 := (EXECUTE IMMEDIATE :query);
            FOR r2 IN rs2 DO
                ref_schema     := r2.TABLE_SCHEMA;
                ref_table      := r2.TABLE_NAME;
                cand_data_type := r2.DATA_TYPE;

                type_compatible := (
                    (fk_data_type = cand_data_type)
                    OR (fk_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL'') AND cand_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL''))
                    OR (fk_data_type IN (''VARCHAR'',''TEXT'',''CHAR'')              AND cand_data_type IN (''VARCHAR'',''TEXT'',''CHAR''))
                    OR (fk_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ'') AND cand_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ''))
                );

                IF (type_compatible) THEN
                    query := ''SELECT COUNT(*) AS t,
                                     COUNT('' || col_name || '') AS n,
                                     COUNT(DISTINCT '' || col_name || '') AS d
                              FROM '' || DB_NAME || ''.'' || ref_schema || ''.'' || ref_table;
                    rs3 := (EXECUTE IMMEDIATE :query);
                    FOR r3 IN rs3 DO
                        ref_total := r3.t; ref_nonnull := r3.n; ref_distinct := r3.d;
                    END FOR;

                    IF (ref_total > 0 AND ref_total = ref_distinct AND ref_nonnull = ref_total) THEN

                        overlap_matches := 0;
                        overlap_total   := 0;
                        query := ''
                            SELECT
                                COUNT(fk_sample.'' || col_name || '')  AS total_sampled,
                                COUNT(ref_col.''   || col_name || '')  AS matches
                            FROM (
                                SELECT DISTINCT '' || col_name || ''
                                FROM '' || fqn || ''
                                WHERE '' || col_name || '' IS NOT NULL
                                LIMIT 20
                            ) fk_sample
                            LEFT JOIN (
                                SELECT DISTINCT '' || col_name || ''
                                FROM '' || DB_NAME || ''.'' || ref_schema || ''.'' || ref_table || ''
                                WHERE '' || col_name || '' IS NOT NULL
                            ) ref_col ON ref_col.'' || col_name || '' = fk_sample.'' || col_name;
                        rs3 := (EXECUTE IMMEDIATE :query);
                        FOR r3 IN rs3 DO
                            overlap_total   := r3.total_sampled;
                            overlap_matches := r3.matches;
                        END FOR;

                        overlap_pct := IFF(overlap_total = 0, 0,
                                           overlap_matches * 100.0 / overlap_total);

                        IF      (overlap_pct >= 80) THEN overlap_conf := ''MEDIUM'';
                        ELSEIF  (overlap_pct >= 40) THEN overlap_conf := ''LOW'';
                        ELSE                            overlap_conf := ''SKIP'';
                        END IF;

                        IF (overlap_conf != ''SKIP'') THEN
                            outgoing := ARRAY_APPEND(outgoing, OBJECT_CONSTRUCT(
                                ''schema'',            ref_schema,
                                ''table'',             ref_table,
                                ''type'',              ''INFERRED'',
                                ''confidence'',        overlap_conf,
                                ''inferred_method'',   ''EXACT_NAME_MATCH_UNIQUENESS_VERIFIED'',
                                ''value_overlap_pct'', overlap_pct,
                                ''data_type_match'',   TRUE,
                                ''column_mappings'',   ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                                    ''fk_column'', col_name, ''pk_column'', col_name))));
                        END IF;

                    END IF;
                END IF;
            END FOR;

        END IF;
    END FOR;


    -- ══════════════════════════════════════════════════════════════════
    -- PHASE 2 DECISION GATE (V10)
    -- Phase 2 is CONDITIONAL — only runs when Phase 1 leaves genuine gaps.
    --
    -- Gate A: IN_SCHEMA_SWEEP=TRUE → ''schema_sweep_phase2_deferred''
    -- Gate B (V10 — 4 conditions ALL must be true to skip):
    --   pk_done = TRUE               → Formal PK declared in DDL
    --   formal_outgoing_count > 0    → At least one formal FK constraint exists
    --   inferred_outgoing_count = 0  → Step 5 found no extra name-matched FK gaps
    --   orphan_key_col_count = 0     → No key-like cols (_ID/_KEY/_CODE/_NO) remain
    --                                   outside the formal FK set
    --   → ''formal_constraints_sufficient''
    -- Gate C: COLUMN_PROFILE_CACHE missing → ''infrastructure_not_deployed''
    -- Gate D: All clear → phase2_needed=TRUE, run Phase 2
    --
    -- phase2_skip_reason is saved as a TOP-LEVEL field in the output.
    -- CHECK_TABLE_STALENESS Gate 4 reads it to distinguish deliberate
    -- skips from transient failures (no PHASE2_UPGRADE on deliberate skips).
    -- ══════════════════════════════════════════════════════════════════

    -- Count Phase 1 INFERRED outgoing items (presence = FK gaps exist)
    inferred_outgoing_count := 0;
    FOR p2_gate_i IN 0 TO ARRAY_SIZE(outgoing) - 1 DO
        IF (outgoing[p2_gate_i]:type::VARCHAR = ''INFERRED'') THEN
            inferred_outgoing_count := inferred_outgoing_count + 1;
        END IF;
    END FOR;

    -- ── V10: Orphan key column scan ───────────────────────────────────────
    -- Count columns that look like FKs by naming convention (_ID/_KEY/_CODE/_NO)
    -- but are NOT the confirmed PK and NOT already captured in formal_fk_cols.
    -- A positive count forces Phase 2 regardless of formal_outgoing_count.
    BEGIN
        LET orp_query VARCHAR := ''
            SELECT COUNT(*) AS orphan_cnt
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
              AND UPPER(COLUMN_NAME) != UPPER('''''' || pk_col || '''''')
              AND (
                   UPPER(COLUMN_NAME) LIKE ''''%_ID''''
                OR UPPER(COLUMN_NAME) LIKE ''''%_KEY''''
                OR UPPER(COLUMN_NAME) LIKE ''''%_CODE''''
                OR UPPER(COLUMN_NAME) LIKE ''''%_NO''''
              )
        '';
        rs := (EXECUTE IMMEDIATE :orp_query);
        FOR r IN rs DO
            orphan_key_col_count := r.orphan_cnt;
        END FOR;

        -- Subtract key-like columns already captured as formal FKs
        FOR fk_i IN 0 TO ARRAY_SIZE(formal_fk_cols) - 1 DO
            LET fk_col_chk VARCHAR := UPPER(formal_fk_cols[fk_i]::VARCHAR);
            IF (fk_col_chk LIKE ''%_ID''
             OR fk_col_chk LIKE ''%_KEY''
             OR fk_col_chk LIKE ''%_CODE''
             OR fk_col_chk LIKE ''%_NO'') THEN
                orphan_key_col_count := orphan_key_col_count - 1;
            END IF;
        END FOR;

        IF (orphan_key_col_count < 0) THEN orphan_key_col_count := 0; END IF;
    EXCEPTION WHEN OTHER THEN
        orphan_key_col_count := 0;  -- safe default: treat as no orphans on error
    END;

    IF (IN_SCHEMA_SWEEP) THEN
        -- Gate A: Schema sweep → always defer Phase 2 (cost control)
        phase2_skip_reason := ''schema_sweep_phase2_deferred'';
        p2_enabled         := FALSE;

    ELSEIF (pk_done AND formal_outgoing_count > 0 AND inferred_outgoing_count = 0 AND orphan_key_col_count = 0) THEN
        -- Gate B (V10): Formal constraints are genuinely complete. All 4 conditions met:
        --   pk_done = TRUE               → Formal PK declared in DDL
        --   formal_outgoing_count > 0    → At least one formal FK constraint exists
        --   inferred_outgoing_count = 0  → Step 5 found no additional name-matched FK gaps
        --   orphan_key_col_count = 0     → No key-like columns (_ID/_KEY/_CODE/_NO) remain
        --                                   outside the formal FK set for Cortex to resolve
        phase2_skip_reason := ''formal_constraints_sufficient'';
        p2_enabled         := FALSE;

    ELSE
        -- Gate C: Check Phase 2 infrastructure is SEEDED for this schema
        BEGIN
            SELECT COUNT(*) INTO :p2_infra_count
            FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
            WHERE DB_NAME     = UPPER(:DB_NAME)
              AND SCHEMA_NAME = UPPER(:SCHEMA_NAME);
            p2_infra_exists := (p2_infra_count > 0);
        EXCEPTION WHEN OTHER THEN
            p2_infra_exists := FALSE;
        END;

        IF (NOT p2_infra_exists) THEN
            RETURN OBJECT_CONSTRUCT(
                ''status'',  ''ERROR'',
                ''code'',    ''PHASE2_INFRA_NOT_SEEDED'',
                ''message'', ''Phase 2 infrastructure is not seeded for schema '' || SCHEMA_NAME || ''. Please run CALL REFRESH_COLUMN_SEARCH_INDEX('''''' || DB_NAME || '''''', '''''' || SCHEMA_NAME || '''''', NULL) before generating semantic views.''
            );
        ELSE
            -- Gate D: All checks clear — Phase 2 will run
            phase2_needed      := TRUE;
            p2_enabled         := TRUE;
            phase2_skip_reason := NULL;
        END IF;
    END IF;


    IF (phase2_needed) THEN
        BEGIN  -- ── Phase 2 outer exception guard ──────────────────────




        -- ══════════════════════════════════════════════════════════════
        -- PHASE 2A — PK FUZZY IDENTIFICATION (V9 NEW)
        -- ══════════════════════════════════════════════════════════════
        -- Runs only when Phase 1 could NOT confirm a PK (pk_done = FALSE).
        -- Uses Cortex Search semantic matching to identify the PK column,
        -- cross-validated with IS_LIKELY_KEY from COLUMN_PROFILE_CACHE
        -- (IS_LIKELY_KEY = TRUE means distinct_count = row_count AND null_count = 0).
        --
        -- Confidence:
        --   semantic_similarity >= 0.55 AND IS_LIKELY_KEY = TRUE → MEDIUM
        --   semantic_similarity >= 0.40 AND IS_LIKELY_KEY = TRUE → LOW
        --
        -- If Phase 2A resolves pk_col, Phase 2B FK search proceeds with it.
        -- ══════════════════════════════════════════════════════════════
        IF (NOT pk_done) THEN
            BEGIN
                p2a_found       := FALSE;
                p2a_i           := 0;
                p2a_search_ctx  := TABLE_NAME || '' primary key unique identifier row ID'';
                p2a_search_resp := NULL;

                -- Cortex Search: find semantically key-like columns in THIS table
                BEGIN
                    LET search_payload VARCHAR := OBJECT_CONSTRUCT(
                        ''query'',   :p2a_search_ctx,
                        ''columns'', ARRAY_CONSTRUCT(''TABLE_NAME'', ''COLUMN_NAME'', ''DATA_TYPE''),
                        ''filter'',  OBJECT_CONSTRUCT(''@and'', ARRAY_CONSTRUCT(
                            OBJECT_CONSTRUCT(''@eq'', OBJECT_CONSTRUCT(''SCHEMA_NAME'', :SCHEMA_NAME)),
                            OBJECT_CONSTRUCT(''@eq'', OBJECT_CONSTRUCT(''TABLE_NAME'',  :TABLE_NAME))
                        )),
                        ''limit'',   5
                    )::VARCHAR;

                    rs2 := (SELECT PARSE_JSON(SNOWFLAKE.CORTEX.SEARCH_PREVIEW(
                        ''__STTM_METADATA_NAMESPACE__.COLUMN_SEARCH_SVC'',
                        :search_payload
                    )) AS result);
                    FOR r2 IN rs2 DO
                        p2a_search_resp := r2.result;
                    END FOR;
                EXCEPTION WHEN OTHER THEN NULL;
                END;

                IF (p2a_search_resp IS NOT NULL
                    AND ARRAY_SIZE(p2a_search_resp:results) > 0) THEN
                    -- Iterate results (highest similarity first); stop at first valid match
                    WHILE (p2a_i < ARRAY_SIZE(p2a_search_resp:results) AND NOT p2a_found) DO
                        p2a_cand_col  := p2a_search_resp:results[p2a_i]:COLUMN_NAME::VARCHAR;
                        -- V10 FIX: Use @scores:cosine_similarity (old @search_score field removed)
                        p2a_sim_score := COALESCE(
                            p2a_search_resp:results[p2a_i]:"@scores":cosine_similarity::FLOAT,
                            0.0
                        );

                        -- V10 FIX: Threshold lowered 0.75 → 0.40 (Cortex Search cosine range)
                        IF (p2a_sim_score >= 0.40) THEN
                            -- Cross-validate with COLUMN_PROFILE_CACHE: IS_LIKELY_KEY must be TRUE
                            p2a_is_key := FALSE;
                            BEGIN
                                SELECT COALESCE(IS_LIKELY_KEY, FALSE) INTO :p2a_is_key
                                FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                                WHERE DB_NAME     = :DB_NAME
                                  AND SCHEMA_NAME = :SCHEMA_NAME
                                  AND TABLE_NAME  = :TABLE_NAME
                                  AND COLUMN_NAME = :p2a_cand_col
                                LIMIT 1;
                            EXCEPTION WHEN OTHER THEN
                                p2a_is_key := FALSE;
                            END;

                            IF (p2a_is_key) THEN
                                -- Fuzzy PK identified and validated by data
                                pk_col  := p2a_cand_col;
                                pk_done := TRUE;
                                confirmed_pk := ARRAY_APPEND(confirmed_pk, OBJECT_CONSTRUCT(
                                    ''column'',              p2a_cand_col,
                                    ''confidence'',          IFF(p2a_sim_score >= 0.55, ''MEDIUM'', ''LOW''),
                                    ''uniqueness_verified'', TRUE,
                                    ''reason'',              ''Phase 2A: Cortex Search semantic PK identification. IS_LIKELY_KEY=TRUE confirmed in COLUMN_PROFILE_CACHE (distinct_count = row_count AND null_count = 0).'',
                                    ''semantic_similarity'', p2a_sim_score,
                                    ''inferred_method'',     ''CORTEX_SEARCH_PK_FUZZY''
                                ));
                                p2a_found := TRUE;
                            END IF;
                        END IF;
                        p2a_i := p2a_i + 1;
                    END WHILE;
                END IF;
            EXCEPTION WHEN OTHER THEN
                p2_phase2_err := p2_phase2_err || '' Phase2A:'' || SQLERRM;
            END;
        END IF;  -- NOT pk_done (Phase 2A)


        -- ══════════════════════════════════════════════════════════════
        -- PHASE 2B — FUZZY FK DISCOVERY (OUTGOING)
        -- ══════════════════════════════════════════════════════════════

        -- ── 6.1: Iterate eligible FK candidate columns ────────────────
        -- Eligible = NOT PK, NOT formal FK, NOT alternate key, NOT already exact FK
        query := ''
            SELECT COLUMN_NAME, DATA_TYPE
            FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
              AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
              AND UPPER(COLUMN_NAME) != UPPER('''''' || pk_col || '''''')
            ORDER BY ORDINAL_POSITION'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR r IN rs DO
            col_name     := r.COLUMN_NAME;
            fk_data_type := r.DATA_TYPE;

            -- Skip formal FKs
            IF (ARRAY_CONTAINS(col_name::VARIANT, formal_fk_cols)) THEN
                CONTINUE;
            END IF;

            -- Skip alternate unique keys
            is_alternate_key := FALSE;
            FOR ak IN 0 TO ARRAY_SIZE(additional_unique_cols) - 1 DO
                IF (additional_unique_cols[ak]:column::VARCHAR = col_name) THEN
                    is_alternate_key := TRUE;
                END IF;
            END FOR;
            IF (is_alternate_key) THEN CONTINUE; END IF;

            -- Skip columns that already have an exact-name match in outgoing[]
            p2_already_exact := FALSE;
            FOR p2_chk IN 0 TO ARRAY_SIZE(outgoing) - 1 DO
                IF (outgoing[p2_chk]:type::VARCHAR = ''INFERRED''
                    AND outgoing[p2_chk]:column_mappings[0]:fk_column::VARCHAR = col_name) THEN
                    p2_already_exact := TRUE;
                END IF;
            END FOR;
            IF (p2_already_exact) THEN CONTINUE; END IF;

            -- ── 6.2: Build search context ─────────────────────────────
            -- Use full SEARCH_TEXT from semantic index if available;
            -- fall back to "{col_name} column in {TABLE_NAME}"
            p2_search_ctx := col_name || '' column in '' || TABLE_NAME;
            BEGIN
                SELECT SEARCH_TEXT INTO :p2_search_ctx
                FROM __STTM_METADATA_NAMESPACE__.COLUMN_SEMANTIC_INDEX
                WHERE DB_NAME     = :DB_NAME
                  AND SCHEMA_NAME = :SCHEMA_NAME
                  AND TABLE_NAME  = :TABLE_NAME
                  AND COLUMN_NAME = :col_name
                LIMIT 1;
            EXCEPTION WHEN OTHER THEN NULL;  -- stay with fallback
            END;

            -- ── 6.3: Cortex Search call ───────────────────────────────
            -- Top 3 candidates, same schema, exclude this table.
            -- API returns results in DESCENDING similarity order.
            p2_search_resp := NULL;
            BEGIN
                LET search_payload VARCHAR := OBJECT_CONSTRUCT(
                    ''query'',   :p2_search_ctx,
                    ''columns'', ARRAY_CONSTRUCT(
                        ''TABLE_NAME'', ''COLUMN_NAME'', ''DATA_TYPE'', ''SCHEMA_NAME''),
                    ''filter'',  OBJECT_CONSTRUCT(''@and'', ARRAY_CONSTRUCT(
                        OBJECT_CONSTRUCT(''@eq'',  OBJECT_CONSTRUCT(''SCHEMA_NAME'', :SCHEMA_NAME)),
                        OBJECT_CONSTRUCT(''@not'', OBJECT_CONSTRUCT(''@eq'',
                            OBJECT_CONSTRUCT(''TABLE_NAME'', :TABLE_NAME)))
                    )),
                    ''limit'',   10
                )::VARCHAR;

                rs2 := (SELECT PARSE_JSON(SNOWFLAKE.CORTEX.SEARCH_PREVIEW(
                    ''__STTM_METADATA_NAMESPACE__.COLUMN_SEARCH_SVC'',
                    :search_payload
                )) AS result);
                FOR r2 IN rs2 DO
                    p2_search_resp := r2.result;
                END FOR;
            EXCEPTION WHEN OTHER THEN 
                p2_phase2_err := p2_phase2_err || '' CortexSearchErr:'' || SQLERRM;
            END;

            IF (p2_search_resp IS NULL OR ARRAY_SIZE(p2_search_resp:results) = 0) THEN
                CONTINUE;
            END IF;

            -- ── 6.4: Process candidates (index 0 = highest similarity first) ──
            p2_col_matched := FALSE;
            FOR cand_i IN 0 TO ARRAY_SIZE(p2_search_resp:results) - 1 DO

                -- First-match-wins: once a candidate passes all gates, skip the rest
                IF (p2_col_matched) THEN CONTINUE; END IF;

                p2_cand_table     := p2_search_resp:results[cand_i]:TABLE_NAME::VARCHAR;
                p2_cand_col       := p2_search_resp:results[cand_i]:COLUMN_NAME::VARCHAR;
                p2_cand_schema    := p2_search_resp:results[cand_i]:SCHEMA_NAME::VARCHAR;
                p2_cand_data_type := p2_search_resp:results[cand_i]:DATA_TYPE::VARCHAR;
                -- V10 FIX: Cortex Search now returns ''@scores'':cosine_similarity
                -- instead of a top-level ''@search_score'' field.
                -- COALESCE guards against NULL if API changes again.
                p2_sim_score      := COALESCE(
                    p2_search_resp:results[cand_i]:"@scores":cosine_similarity::FLOAT,
                    0.0
                );

                -- V10 FIX: Threshold lowered 0.80 → 0.40.
                -- Cortex Search cosine_similarity for strong FK pairs scores
                -- 0.50–0.58; raw embedding cosine (EMBED_TEXT) scores 0.85–0.95.
                -- These are different models with different score distributions.
                IF (p2_sim_score < 0.40) THEN CONTINUE; END IF;

                -- Reset per-candidate state
                p2_skip_cand      := FALSE;
                p2_score          := 0;
                p2_score_max      := 100;     -- V9: PATTERN_CLASS activated → max 100
                p2_distinct_ratio := 0;
                p2_null_diff      := 0;
                p2_length_ok      := FALSE;
                p2c_fk_pattern    := NULL;
                p2c_ref_pattern   := NULL;

                -- ── GATE 1: Datatype compatibility (reuse Phase 1 logic) ──
                type_compatible := (
                    (fk_data_type = p2_cand_data_type)
                    OR (fk_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL'')
                        AND p2_cand_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL''))
                    OR (fk_data_type IN (''VARCHAR'',''TEXT'',''CHAR'')
                        AND p2_cand_data_type IN (''VARCHAR'',''TEXT'',''CHAR''))
                    OR (fk_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ'')
                        AND p2_cand_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ''))
                );
                IF (NOT type_compatible) THEN
                    p2_skip_cand := TRUE;
                END IF;

                -- ── GATE 2: Profile Compatibility ────────────────────────
                IF (NOT p2_skip_cand) THEN

                    -- On-demand candidate table refresh: check freshness, refresh if stale
                    -- V9: After schema-wide refresh in Step 6.0, this is a safety net only.
                    BEGIN
                        p2_stale_count := 0;
                        SELECT COUNT(*) INTO :p2_stale_count
                        FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                        WHERE DB_NAME     = :DB_NAME
                          AND SCHEMA_NAME = :p2_cand_schema
                          AND TABLE_NAME  = :p2_cand_table
                          AND LAST_REFRESHED >= DATEADD(day, -7, CURRENT_TIMESTAMP());
                        IF (p2_stale_count = 0) THEN
                            EXECUTE IMMEDIATE ''CALL __STTM_METADATA_NAMESPACE__.REFRESH_COLUMN_SEARCH_INDEX(''''''
                                || DB_NAME || '''''', '''''' || p2_cand_schema || '''''', '''''' || p2_cand_table || '''''')'';
                        END IF;
                    EXCEPTION WHEN OTHER THEN NULL;
                    END;

                    -- Fetch FK column profile (THIS table)
                    p2_fk_distinct := 0; p2_fk_null_pct := 0;
                    p2_fk_min_len  := 0; p2_fk_max_len  := 0;
                    rs2 := (SELECT
                        COALESCE(DISTINCT_COUNT, 0) AS dc,
                        COALESCE(NULL_PCT, 0)       AS np,
                        COALESCE(MIN_LENGTH, 0)     AS mnl,
                        COALESCE(MAX_LENGTH, 0)     AS mxl
                    FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                    WHERE DB_NAME     = :DB_NAME
                      AND SCHEMA_NAME = :SCHEMA_NAME
                      AND TABLE_NAME  = :TABLE_NAME
                      AND COLUMN_NAME = :col_name
                    LIMIT 1);
                    FOR r2 IN rs2 DO
                        p2_fk_distinct := r2.dc;
                        p2_fk_null_pct := r2.np;
                        p2_fk_min_len  := r2.mnl;
                        p2_fk_max_len  := r2.mxl;
                    END FOR;

                    -- Fetch ref column profile (candidate table)
                    p2_ref_distinct := 0; p2_ref_null_pct := 0;
                    p2_ref_min_len  := 0; p2_ref_max_len  := 0;
                    rs2 := (SELECT
                        COALESCE(DISTINCT_COUNT, 0) AS dc,
                        COALESCE(NULL_PCT, 0)       AS np,
                        COALESCE(MIN_LENGTH, 0)     AS mnl,
                        COALESCE(MAX_LENGTH, 0)     AS mxl
                    FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                    WHERE DB_NAME     = :DB_NAME
                      AND SCHEMA_NAME = :p2_cand_schema
                      AND TABLE_NAME  = :p2_cand_table
                      AND COLUMN_NAME = :p2_cand_col
                    LIMIT 1);
                    FOR r2 IN rs2 DO
                        p2_ref_distinct := r2.dc;
                        p2_ref_null_pct := r2.np;
                        p2_ref_min_len  := r2.mnl;
                        p2_ref_max_len  := r2.mxl;
                    END FOR;

                    -- Skip if no profile data exists for either column
                    IF (p2_fk_distinct = 0 AND p2_ref_distinct = 0) THEN
                        p2_skip_cand := TRUE;
                    END IF;

                    -- ── Gate 2.1: Distinct count ratio (HARD gate + scored) ──
                    IF (NOT p2_skip_cand) THEN
                        p2_distinct_ratio := IFF(
                            GREATEST(p2_fk_distinct, p2_ref_distinct) = 0, 0,
                            LEAST(p2_fk_distinct, p2_ref_distinct) * 1.0
                                / GREATEST(p2_fk_distinct, p2_ref_distinct)
                        );
                        IF (p2_distinct_ratio < 0.10) THEN
                            p2_score := p2_score + 0;      -- SOFT FAIL: 1:N relationships can have very different distinct counts
                        ELSEIF (p2_distinct_ratio >= 0.80) THEN p2_score := p2_score + 30;
                        ELSEIF (p2_distinct_ratio >= 0.50) THEN p2_score := p2_score + 20;
                        ELSE                                    p2_score := p2_score + 10;
                        END IF;
                    END IF;

                    -- ── Gate 2.3: Length distribution (HARD gate + scored) ──
                    IF (NOT p2_skip_cand) THEN
                        p2_length_ok := (p2_fk_min_len >= p2_ref_min_len * 0.5)
                                     AND (p2_fk_max_len <= p2_ref_max_len * 2.0);
                        IF (NOT p2_length_ok) THEN
                            p2_skip_cand := TRUE;          -- HARD FAIL
                        ELSE
                            -- Score by precision of length match
                            IF ((p2_ref_max_len - p2_ref_min_len) <= 2
                                AND (p2_fk_max_len - p2_fk_min_len) <= 2) THEN
                                -- Both narrow/fixed-length (e.g. 18-char Salesforce IDs)
                                p2_score := p2_score + 25;
                            ELSEIF ((p2_fk_max_len - p2_fk_min_len)
                                    <= (p2_ref_max_len - p2_ref_min_len) * 1.5 + 1) THEN
                                p2_score := p2_score + 15;
                            ELSE
                                p2_score := p2_score + 5;  -- compatible but loose
                            END IF;
                        END IF;
                    END IF;

                    -- ── Gate 2.4: Pattern classification — ACTIVATED in V9 ──────
                    -- Compare PATTERN_CLASS of FK column vs candidate ref column.
                    -- Matching class adds +25 pts (SOFT signal — no HARD gate rejection).
                    -- Values: NUMERIC | ALPHA | ALPHANUMERIC | FORMATTED | EMPTY
                    IF (NOT p2_skip_cand) THEN
                        p2c_fk_pattern  := NULL;
                        p2c_ref_pattern := NULL;
                        BEGIN
                            SELECT PATTERN_CLASS INTO :p2c_fk_pattern
                            FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                            WHERE DB_NAME = :DB_NAME AND SCHEMA_NAME = :SCHEMA_NAME
                              AND TABLE_NAME = :TABLE_NAME AND COLUMN_NAME = :col_name
                            LIMIT 1;
                        EXCEPTION WHEN OTHER THEN NULL;
                        END;
                        BEGIN
                            SELECT PATTERN_CLASS INTO :p2c_ref_pattern
                            FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                            WHERE DB_NAME = :DB_NAME AND SCHEMA_NAME = :p2_cand_schema
                              AND TABLE_NAME = :p2_cand_table AND COLUMN_NAME = :p2_cand_col
                            LIMIT 1;
                        EXCEPTION WHEN OTHER THEN NULL;
                        END;
                        IF (p2c_fk_pattern IS NOT NULL AND p2c_ref_pattern IS NOT NULL
                            AND p2c_fk_pattern = p2c_ref_pattern) THEN
                            p2_score := p2_score + 25;
                        END IF;
                    END IF;

                    -- ── Gate 2.2: Null % difference (SOFT signal, score only) ──
                    IF (NOT p2_skip_cand) THEN
                        p2_null_diff := ABS(p2_fk_null_pct - p2_ref_null_pct);
                        IF      (p2_null_diff <= 10) THEN p2_score := p2_score + 20;
                        ELSEIF  (p2_null_diff <= 30) THEN p2_score := p2_score + 10;
                        -- > 30: no rejection, no points (optional FK relationship is valid)
                        END IF;
                    END IF;

                END IF;  -- Gate 2

                -- ── GATE 3: Option X — ref column unique + non-null in data ──
                IF (NOT p2_skip_cand) THEN
                    ref_total := 0; ref_nonnull := 0; ref_distinct := 0;
                    query := ''SELECT COUNT(*) AS t,
                                     COUNT('' || p2_cand_col || '') AS n,
                                     COUNT(DISTINCT '' || p2_cand_col || '') AS d
                              FROM '' || DB_NAME || ''.'' || p2_cand_schema || ''.'' || p2_cand_table;
                    rs3 := (EXECUTE IMMEDIATE :query);
                    FOR r3 IN rs3 DO
                        ref_total := r3.t; ref_nonnull := r3.n; ref_distinct := r3.d;
                    END FOR;
                    IF (ref_total = 0 OR ref_total != ref_distinct OR ref_nonnull != ref_total) THEN
                        p2_skip_cand := TRUE;   -- referenced column is not a PK candidate
                    END IF;
                END IF;

                -- ── GATE 4: Value overlap >= 40% ─────────────────────────
                IF (NOT p2_skip_cand) THEN
                    overlap_matches := 0; overlap_total := 0;
                    query := ''
                        SELECT
                            COUNT(fk_s.'' || col_name     || '') AS total_sampled,
                            COUNT(ref_c.'' || p2_cand_col || '') AS matches
                        FROM (
                            SELECT DISTINCT '' || col_name || ''
                            FROM '' || fqn || ''
                            WHERE '' || col_name || '' IS NOT NULL
                            LIMIT 20
                        ) fk_s
                        LEFT JOIN (
                            SELECT DISTINCT '' || p2_cand_col || ''
                            FROM '' || DB_NAME || ''.'' || p2_cand_schema || ''.'' || p2_cand_table || ''
                            WHERE '' || p2_cand_col || '' IS NOT NULL
                        ) ref_c ON ref_c.'' || p2_cand_col || '' = fk_s.'' || col_name;
                    rs3 := (EXECUTE IMMEDIATE :query);
                    FOR r3 IN rs3 DO
                        overlap_total   := r3.total_sampled;
                        overlap_matches := r3.matches;
                    END FOR;
                    overlap_pct := IFF(overlap_total = 0, 0,
                                       overlap_matches * 100.0 / overlap_total);
                    IF (overlap_pct < 40) THEN
                        p2_skip_cand := TRUE;
                    END IF;
                END IF;

                -- ── ALL GATES PASSED — Create fuzzy outgoing relationship ──
                -- V10: Confidence thresholds updated for Cortex Search cosine range.
                -- Score check: >= 0.40. Tier: >= 0.55 MEDIUM.
                IF (NOT p2_skip_cand) THEN

                    -- D2: Confidence tier
                    p2_fuzzy_conf := IFF(
                        NVL(p2_sim_score, 0) >= 0.55 AND overlap_pct >= 80, ''MEDIUM'', ''LOW'');

                    -- Capture outgoing index BEFORE append (for Step 7 linking)
                    p2_outgoing_idx := ARRAY_SIZE(outgoing);
                    p2_review_id    := p2_review_id + 1;

                    outgoing := ARRAY_APPEND(outgoing, OBJECT_CONSTRUCT(
                        ''schema'',          p2_cand_schema,
                        ''table'',           p2_cand_table,
                        ''type'',            ''FUZZY'',
                        ''confidence'',      p2_fuzzy_conf,
                        ''inferred_method'', ''CORTEX_SEARCH_SEMANTIC'',
                        ''column_mappings'', ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                            ''fk_column'', col_name, ''pk_column'', p2_cand_col)),
                        ''relationship_evidence'', OBJECT_CONSTRUCT(
                            ''semantic_similarity'', p2_sim_score,
                            ''datatype_match'',      TRUE,
                            ''profile_score'',       p2_score,
                            ''profile_score_max'',   100,
                            ''profile_details'',     OBJECT_CONSTRUCT(
                                ''distinct_count_ratio'', p2_distinct_ratio,
                                ''length_compatible'',    p2_length_ok,
                                ''null_pct_diff'',        p2_null_diff,
                                ''pattern_class_fk'',     p2c_fk_pattern,
                                ''pattern_class_ref'',    p2c_ref_pattern,
                                ''pattern_class_match'',  IFF(p2c_fk_pattern IS NOT NULL
                                                            AND p2c_ref_pattern IS NOT NULL
                                                            AND p2c_fk_pattern = p2c_ref_pattern,
                                                            TRUE, FALSE)
                            ),
                            ''uniqueness_verified'', TRUE,
                            ''value_overlap_pct'',   overlap_pct
                        )
                    ));

                    -- Add to Step 7 review batch (NO raw sample values — D5)
                    p2_review_batch := ARRAY_APPEND(p2_review_batch, OBJECT_CONSTRUCT(
                        ''id'',               p2_review_id,
                        ''outgoing_idx'',     p2_outgoing_idx,
                        ''type'',             ''FUZZY_FK'',
                        ''fk_table'',         TABLE_NAME,
                        ''fk_column'',        col_name,
                        ''ref_table'',        p2_cand_table,
                        ''ref_column'',       p2_cand_col,
                        ''fk_datatype'',      fk_data_type,
                        ''ref_datatype'',     p2_cand_data_type,
                        ''fk_distinct_count'', p2_fk_distinct,
                        ''ref_distinct_count'', p2_ref_distinct,
                        ''fk_null_pct'',      p2_fk_null_pct,
                        ''ref_null_pct'',     p2_ref_null_pct,
                        ''fk_length_range'',  p2_fk_min_len::VARCHAR || ''-'' || p2_fk_max_len::VARCHAR,
                        ''ref_length_range'', p2_ref_min_len::VARCHAR || ''-'' || p2_ref_max_len::VARCHAR,
                        ''pattern_class_fk'', p2c_fk_pattern,
                        ''pattern_class_ref'', p2c_ref_pattern,
                        ''pattern_class_match'', IFF(p2c_fk_pattern IS NOT NULL AND p2c_ref_pattern IS NOT NULL
                                                    AND p2c_fk_pattern = p2c_ref_pattern, TRUE, FALSE),
                        ''profile_score'',    p2_score,
                        ''profile_score_max'', 100,
                        ''semantic_similarity'', p2_sim_score,
                        ''value_overlap_pct'', overlap_pct
                    ));

                    p2_fuzzy_count := p2_fuzzy_count + 1;
                    p2_col_matched := TRUE;  -- first-match-wins: skip remaining candidates for this column
                END IF;

            END FOR;  -- cand_i (Cortex Search candidates)
        END FOR;  -- eligible FK candidate columns (Phase 2B)


        -- ══════════════════════════════════════════════════════════════
        -- PHASE 2C — FUZZY INCOMING FK DISCOVERY (V9 NEW)
        -- ══════════════════════════════════════════════════════════════
        -- After Phase 2B (outgoing), search for columns in OTHER schema
        -- tables that semantically reference THIS table''s PK (reverse FK).
        -- Complements Step 2 (FORMAL INCOMING) and Step 4 (INFERRED INCOMING
        -- by exact PK name match). Phase 2C catches cross-named references
        -- (e.g., TABLE_A.SALESFORCEID referenced as TABLE_B.OWNER_SF_ID).
        -- Only runs when pk_done = TRUE (PK column is known).
        -- ══════════════════════════════════════════════════════════════
        IF (pk_done AND pk_col != '''') THEN
            BEGIN
                -- Build search context from PK column''s SEARCH_TEXT (rich context)
                p2c_search_ctx := pk_col || '' primary key identifier in '' || TABLE_NAME;
                BEGIN
                    SELECT SEARCH_TEXT INTO :p2c_search_ctx
                    FROM __STTM_METADATA_NAMESPACE__.COLUMN_SEMANTIC_INDEX
                    WHERE DB_NAME     = :DB_NAME
                      AND SCHEMA_NAME = :SCHEMA_NAME
                      AND TABLE_NAME  = :TABLE_NAME
                      AND COLUMN_NAME = :pk_col
                    LIMIT 1;
                EXCEPTION WHEN OTHER THEN NULL;
                END;

                -- Cortex Search: find columns in OTHER tables referencing this PK
                p2c_search_resp := NULL;
                BEGIN
                    LET search_payload VARCHAR := OBJECT_CONSTRUCT(
                        ''query'',   :p2c_search_ctx,
                        ''columns'', ARRAY_CONSTRUCT(
                            ''TABLE_NAME'', ''COLUMN_NAME'', ''DATA_TYPE'', ''SCHEMA_NAME''),
                        ''filter'',  OBJECT_CONSTRUCT(''@and'', ARRAY_CONSTRUCT(
                            OBJECT_CONSTRUCT(''@eq'',  OBJECT_CONSTRUCT(''SCHEMA_NAME'', :SCHEMA_NAME)),
                            OBJECT_CONSTRUCT(''@not'', OBJECT_CONSTRUCT(''@eq'',
                                OBJECT_CONSTRUCT(''TABLE_NAME'', :TABLE_NAME)))
                        )),
                        ''limit'',   10
                    )::VARCHAR;

                    rs2 := (SELECT PARSE_JSON(SNOWFLAKE.CORTEX.SEARCH_PREVIEW(
                        ''__STTM_METADATA_NAMESPACE__.COLUMN_SEARCH_SVC'',
                        :search_payload
                    )) AS result);
                    FOR r2 IN rs2 DO
                        p2c_search_resp := r2.result;
                    END FOR;
                EXCEPTION WHEN OTHER THEN NULL;
                END;

                IF (p2c_search_resp IS NOT NULL
                    AND ARRAY_SIZE(p2c_search_resp:results) > 0) THEN

                    FOR p2c_i IN 0 TO ARRAY_SIZE(p2c_search_resp:results) - 1 DO
                        p2c_cand_table     := p2c_search_resp:results[p2c_i]:TABLE_NAME::VARCHAR;
                        p2c_cand_col       := p2c_search_resp:results[p2c_i]:COLUMN_NAME::VARCHAR;
                        p2c_cand_schema    := p2c_search_resp:results[p2c_i]:SCHEMA_NAME::VARCHAR;
                        p2c_cand_data_type := p2c_search_resp:results[p2c_i]:DATA_TYPE::VARCHAR;
                        -- V10 FIX: Use @scores:cosine_similarity (old @search_score field removed)
                        p2c_sim_score      := COALESCE(
                            p2c_search_resp:results[p2c_i]:"@scores":cosine_similarity::FLOAT,
                            0.0
                        );
                        p2c_skip_cand      := FALSE;
                        p2c_score          := 0;
                        p2c_fk_pattern     := NULL;
                        p2c_ref_pattern    := NULL;

                        -- V10 FIX: Threshold lowered 0.80 → 0.40
                        IF (p2c_sim_score < 0.40) THEN CONTINUE; END IF;

                        -- Skip if table already has ANY incoming relationship (formal/inferred/fuzzy)
                        p2c_already_has_incoming := FALSE;
                        FOR inc_chk IN 0 TO ARRAY_SIZE(incoming) - 1 DO
                            IF (UPPER(incoming[inc_chk]:table::VARCHAR) = UPPER(p2c_cand_table)
                                AND UPPER(incoming[inc_chk]:schema::VARCHAR) = UPPER(p2c_cand_schema)) THEN
                                p2c_already_has_incoming := TRUE;
                            END IF;
                        END FOR;
                        IF (p2c_already_has_incoming) THEN CONTINUE; END IF;

                        -- ── GATE 1: Data type compatible with THIS table''s PK ─────
                        type_compatible := (
                            (pk_data_type = p2c_cand_data_type)
                            OR (pk_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL'') AND p2c_cand_data_type IN (''NUMBER'',''FLOAT'',''INTEGER'',''DECIMAL''))
                            OR (pk_data_type IN (''VARCHAR'',''TEXT'',''CHAR'')              AND p2c_cand_data_type IN (''VARCHAR'',''TEXT'',''CHAR''))
                            OR (pk_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ'') AND p2c_cand_data_type IN (''DATE'',''TIMESTAMP_NTZ'',''TIMESTAMP_LTZ'',''TIMESTAMP_TZ''))
                        );
                        IF (NOT type_compatible) THEN p2c_skip_cand := TRUE; END IF;

                        -- ── GATE 2: Profile compatibility ─────────────────────────
                        IF (NOT p2c_skip_cand) THEN
                            -- On-demand candidate refresh (safety net after schema-wide 6.0)
                            BEGIN
                                p2_stale_count := 0;
                                SELECT COUNT(*) INTO :p2_stale_count
                                FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                                WHERE DB_NAME = :DB_NAME AND SCHEMA_NAME = :p2c_cand_schema
                                  AND TABLE_NAME = :p2c_cand_table
                                  AND LAST_REFRESHED >= DATEADD(day, -7, CURRENT_TIMESTAMP());
                                IF (p2_stale_count = 0) THEN
                                    EXECUTE IMMEDIATE ''CALL __STTM_METADATA_NAMESPACE__.REFRESH_COLUMN_SEARCH_INDEX(''''''
                                        || DB_NAME || '''''', '''''' || p2c_cand_schema || '''''', '''''' || p2c_cand_table || '''''')'';
                                END IF;
                            EXCEPTION WHEN OTHER THEN NULL;
                            END;

                            -- Ref = THIS table''s PK (the referenced side)
                            p2c_ref_distinct := 0; p2c_ref_null_pct := 0;
                            p2c_ref_min_len  := 0; p2c_ref_max_len  := 0;
                            rs2 := (SELECT
                                COALESCE(DISTINCT_COUNT, 0) AS dc, COALESCE(NULL_PCT, 0) AS np,
                                COALESCE(MIN_LENGTH, 0) AS mnl, COALESCE(MAX_LENGTH, 0) AS mxl,
                                PATTERN_CLASS AS pc
                            FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                            WHERE DB_NAME = :DB_NAME AND SCHEMA_NAME = :SCHEMA_NAME
                              AND TABLE_NAME = :TABLE_NAME AND COLUMN_NAME = :pk_col LIMIT 1);
                            FOR r2 IN rs2 DO
                                p2c_ref_distinct := r2.dc; p2c_ref_null_pct := r2.np;
                                p2c_ref_min_len  := r2.mnl; p2c_ref_max_len  := r2.mxl;
                                p2c_ref_pattern  := r2.pc;
                            END FOR;

                            -- FK = candidate column (the referencing side)
                            p2c_fk_distinct := 0; p2c_fk_null_pct := 0;
                            p2c_fk_min_len  := 0; p2c_fk_max_len  := 0;
                            rs2 := (SELECT
                                COALESCE(DISTINCT_COUNT, 0) AS dc, COALESCE(NULL_PCT, 0) AS np,
                                COALESCE(MIN_LENGTH, 0) AS mnl, COALESCE(MAX_LENGTH, 0) AS mxl,
                                PATTERN_CLASS AS pc
                            FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                            WHERE DB_NAME = :DB_NAME AND SCHEMA_NAME = :p2c_cand_schema
                              AND TABLE_NAME = :p2c_cand_table AND COLUMN_NAME = :p2c_cand_col LIMIT 1);
                            FOR r2 IN rs2 DO
                                p2c_fk_distinct := r2.dc; p2c_fk_null_pct := r2.np;
                                p2c_fk_min_len  := r2.mnl; p2c_fk_max_len  := r2.mxl;
                                p2c_fk_pattern  := r2.pc;
                            END FOR;

                            IF (p2c_fk_distinct = 0 AND p2c_ref_distinct = 0) THEN
                                p2c_skip_cand := TRUE;
                            END IF;

                            -- Gate 2.1: Distinct count ratio (HARD gate)
                            IF (NOT p2c_skip_cand) THEN
                                p2c_distinct_ratio := IFF(
                                    GREATEST(p2c_fk_distinct, p2c_ref_distinct) = 0, 0,
                                    LEAST(p2c_fk_distinct, p2c_ref_distinct) * 1.0
                                        / GREATEST(p2c_fk_distinct, p2c_ref_distinct));
                                IF (p2c_distinct_ratio < 0.10) THEN
                                    p2c_score := p2c_score + 0;
                                ELSEIF (p2c_distinct_ratio >= 0.80) THEN p2c_score := p2c_score + 30;
                                ELSEIF (p2c_distinct_ratio >= 0.50) THEN p2c_score := p2c_score + 20;
                                ELSE                                      p2c_score := p2c_score + 10;
                                END IF;
                            END IF;

                            -- Gate 2.3: Length distribution (HARD gate)
                            IF (NOT p2c_skip_cand) THEN
                                p2c_length_ok := (p2c_fk_min_len >= p2c_ref_min_len * 0.5)
                                              AND (p2c_fk_max_len <= p2c_ref_max_len * 2.0);
                                IF (NOT p2c_length_ok) THEN
                                    p2c_skip_cand := TRUE;
                                ELSE
                                    IF ((p2c_ref_max_len - p2c_ref_min_len) <= 2
                                        AND (p2c_fk_max_len - p2c_fk_min_len) <= 2) THEN
                                        p2c_score := p2c_score + 25;
                                    ELSEIF ((p2c_fk_max_len - p2c_fk_min_len)
                                            <= (p2c_ref_max_len - p2c_ref_min_len) * 1.5 + 1) THEN
                                        p2c_score := p2c_score + 15;
                                    ELSE
                                        p2c_score := p2c_score + 5;
                                    END IF;
                                END IF;
                            END IF;

                            -- Gate 2.4: PATTERN_CLASS match (SOFT signal, +25 pts)
                            IF (NOT p2c_skip_cand AND p2c_fk_pattern IS NOT NULL
                                AND p2c_ref_pattern IS NOT NULL
                                AND p2c_fk_pattern = p2c_ref_pattern) THEN
                                p2c_score := p2c_score + 25;
                            END IF;

                            -- Gate 2.2: Null % difference (SOFT signal)
                            IF (NOT p2c_skip_cand) THEN
                                IF      (ABS(p2c_fk_null_pct - p2c_ref_null_pct) <= 10) THEN p2c_score := p2c_score + 20;
                                ELSEIF  (ABS(p2c_fk_null_pct - p2c_ref_null_pct) <= 30) THEN p2c_score := p2c_score + 10;
                                END IF;
                            END IF;
                        END IF;  -- Gate 2

                        -- ── GATE 3: THIS table''s PK is unique + non-null ──────────
                        IF (NOT p2c_skip_cand) THEN
                            ref_total := 0; ref_nonnull := 0; ref_distinct := 0;
                            query := ''SELECT COUNT(*) AS t, COUNT('' || pk_col || '') AS n, COUNT(DISTINCT '' || pk_col || '') AS d FROM '' || fqn;
                            rs3 := (EXECUTE IMMEDIATE :query);
                            FOR r3 IN rs3 DO
                                ref_total := r3.t; ref_nonnull := r3.n; ref_distinct := r3.d;
                            END FOR;
                            IF (ref_total = 0 OR ref_total != ref_distinct OR ref_nonnull != ref_total) THEN
                                p2c_skip_cand := TRUE;
                            END IF;
                        END IF;

                        -- ── GATE 4: Value overlap >= 40% ─────────────────────────
                        IF (NOT p2c_skip_cand) THEN
                            overlap_matches := 0; overlap_total := 0;
                            query := ''
                                SELECT
                                    COUNT(fk_s.'' || p2c_cand_col || '') AS total_sampled,
                                    COUNT(ref_c.'' || pk_col        || '') AS matches
                                FROM (
                                    SELECT DISTINCT '' || p2c_cand_col || ''
                                    FROM '' || DB_NAME || ''.'' || p2c_cand_schema || ''.'' || p2c_cand_table || ''
                                    WHERE '' || p2c_cand_col || '' IS NOT NULL
                                    LIMIT 20
                                ) fk_s
                                LEFT JOIN (
                                    SELECT DISTINCT '' || pk_col || ''
                                    FROM '' || fqn || ''
                                    WHERE '' || pk_col || '' IS NOT NULL
                                ) ref_c ON ref_c.'' || pk_col || '' = fk_s.'' || p2c_cand_col;
                            rs3 := (EXECUTE IMMEDIATE :query);
                            FOR r3 IN rs3 DO
                                overlap_total   := r3.total_sampled;
                                overlap_matches := r3.matches;
                            END FOR;
                            overlap_pct := IFF(overlap_total = 0, 0,
                                               overlap_matches * 100.0 / overlap_total);
                            IF (overlap_pct < 40) THEN p2c_skip_cand := TRUE; END IF;
                        END IF;

                        -- ── ALL GATES PASSED — Create fuzzy incoming relationship ──
                        IF (NOT p2c_skip_cand) THEN
                            p2c_fuzzy_conf := IFF(
                                p2c_sim_score >= 0.55 AND overlap_pct >= 80, ''MEDIUM'', ''LOW'');

                            -- ── Fix 2: Reverse-direction cross-check ────────────────────────────
                            -- If (fk_table=p2c_cand_table, fk_col=p2c_cand_col) already
                            -- appears as (table=p2c_cand_table, pk_column=p2c_cand_col)
                            -- in outgoing[], then p2c_cand_col IS the referenced PK in
                            -- p2c_cand_table, not an FK pointing here. Pre-flag INVALID.
                            p2c_is_rfp := FALSE;
                            FOR rfp_i IN 0 TO ARRAY_SIZE(outgoing) - 1 DO
                                IF (outgoing[rfp_i]:table::VARCHAR = p2c_cand_table
                                    AND outgoing[rfp_i]:column_mappings[0]:pk_column::VARCHAR = p2c_cand_col) THEN
                                    p2c_is_rfp := TRUE;
                                END IF;
                            END FOR;

                            incoming := ARRAY_APPEND(incoming, OBJECT_CONSTRUCT(
                                ''schema'',            p2c_cand_schema,
                                ''table'',             p2c_cand_table,
                                ''type'',              ''FUZZY'',
                                -- Fix 2: pre-flag when reverse-direction match found
                                ''confidence'',        IFF(p2c_is_rfp, ''FLAGGED'', p2c_fuzzy_conf),
                                ''inferred_method'',   ''CORTEX_SEARCH_SEMANTIC'',
                                ''column_mappings'',   ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                                    ''fk_column'', p2c_cand_col, ''pk_column'', pk_col)),
                                ''relationship_evidence'', OBJECT_CONSTRUCT(
                                    ''semantic_similarity'', p2c_sim_score,
                                    ''datatype_match'',      TRUE,
                                    ''profile_score'',       p2c_score,
                                    ''profile_score_max'',   100,
                                    ''value_overlap_pct'',   overlap_pct,
                                    -- V10: enriched profile fields for Step 8 review
                                    ''fk_distinct_count'',   p2c_fk_distinct,
                                    ''ref_distinct_count'',  p2c_ref_distinct,
                                    ''fk_null_pct'',         p2c_fk_null_pct,
                                    ''ref_null_pct'',        p2c_ref_null_pct,
                                    -- Fix 3: add length range fields
                                    ''fk_length_range'',     p2c_fk_min_len::VARCHAR || ''-'' || p2c_fk_max_len::VARCHAR,
                                    ''ref_length_range'',    p2c_ref_min_len::VARCHAR || ''-'' || p2c_ref_max_len::VARCHAR,
                                    ''pattern_class_fk'',    p2c_fk_pattern,
                                    ''pattern_class_ref'',   p2c_ref_pattern,
                                    ''pattern_class_match'', IFF(p2c_fk_pattern IS NOT NULL
                                        AND p2c_ref_pattern IS NOT NULL
                                        AND p2c_fk_pattern = p2c_ref_pattern, TRUE, FALSE)
                                ),
                                -- Fix 2: attach pre-built semantic_review for RFP cases
                                -- NULL for non-RFP entries → omitted by OBJECT_CONSTRUCT
                                ''semantic_review'', IFF(p2c_is_rfp,
                                    OBJECT_CONSTRUCT(
                                        ''verdict'',         ''INVALID'',
                                        ''confidence_note'', ''Pre-flagged by SQL cross-check: ''
                                            || p2c_cand_col
                                            || '' is already referenced as a pk_column in the outgoing[] ''
                                            || ''array, confirming it is the PK of ''
                                            || p2c_cand_table
                                            || '', not an FK pointing to ''
                                            || TABLE_NAME || ''.'' || pk_col || ''.'',
                                        ''source_references'', ARRAY_CONSTRUCT(
                                            ''outgoing[].table='' || p2c_cand_table
                                                || '' + pk_column='' || p2c_cand_col
                                                || '' — reverse direction confirmed''
                                        ),
                                        ''reviewed_by'',  ''SQL_CROSS_CHECK'',
                                        ''reviewed_at'',  CURRENT_TIMESTAMP()::VARCHAR
                                    ),
                                    NULL)
                            ));

                            -- Fix 2: only send to LLM batch when NOT a reverse false positive
                            IF (NOT p2c_is_rfp) THEN
                                p8_review_id := p8_review_id + 1;
                                p8_review_batch := ARRAY_APPEND(p8_review_batch, OBJECT_CONSTRUCT(
                                    ''id'',                  p8_review_id,
                                    ''fk_table'',            p2c_cand_table,
                                    ''fk_column'',           p2c_cand_col,
                                    ''ref_table'',           TABLE_NAME,
                                    ''ref_column'',          pk_col,
                                    ''type'',                ''FUZZY_INCOMING'',
                                    ''fk_datatype'',         p2c_cand_data_type,
                                    ''fk_distinct_count'',   p2c_fk_distinct,
                                    ''ref_distinct_count'',  p2c_ref_distinct,
                                    ''fk_null_pct'',         p2c_fk_null_pct,
                                    ''ref_null_pct'',        p2c_ref_null_pct,
                                    ''fk_length_range'',     p2c_fk_min_len::VARCHAR || ''-'' || p2c_fk_max_len::VARCHAR,
                                    ''ref_length_range'',    p2c_ref_min_len::VARCHAR || ''-'' || p2c_ref_max_len::VARCHAR,
                                    ''pattern_class_fk'',    p2c_fk_pattern,
                                    ''pattern_class_ref'',   p2c_ref_pattern,
                                    ''pattern_class_match'', IFF(p2c_fk_pattern IS NOT NULL
                                        AND p2c_ref_pattern IS NOT NULL
                                        AND p2c_fk_pattern = p2c_ref_pattern, TRUE, FALSE),
                                    ''profile_score'',       p2c_score,
                                    ''profile_score_max'',   100,
                                    ''semantic_similarity'', p2c_sim_score,
                                    ''value_overlap_pct'',   overlap_pct
                                ));
                            END IF;

                            p2c_fuzzy_count := p2c_fuzzy_count + 1;
                        END IF;

                    END FOR;  -- p2c_i (Phase 2C candidates)
                END IF;  -- p2c_search_resp has results
            EXCEPTION WHEN OTHER THEN
                p2_phase2_err := p2_phase2_err || '' Phase2C:'' || SQLERRM;
            END;
        END IF;  -- pk_done for Phase 2C


        -- ══════════════════════════════════════════════════════════════
        -- STEP 7 — BATCH SEMANTIC REVIEW
        -- ══════════════════════════════════════════════════════════════
        BEGIN

            -- Add LOW-confidence exact-name inferred relationships to review batch.
            -- Only when overlap_pct < 60 (skip when >= 60 — reliable enough).
            FOR p7_i IN 0 TO ARRAY_SIZE(outgoing) - 1 DO
                IF (outgoing[p7_i]:type::VARCHAR = ''INFERRED''
                    AND outgoing[p7_i]:confidence::VARCHAR = ''LOW''
                    AND outgoing[p7_i]:value_overlap_pct::FLOAT < 60) THEN
                    p2_review_id := p2_review_id + 1;
                    p2_review_batch := ARRAY_APPEND(p2_review_batch, OBJECT_CONSTRUCT(
                        ''id'',              p2_review_id,
                        ''outgoing_idx'',    p7_i,
                        ''type'',            ''LOW_CONF_EXACT_FK'',
                        ''fk_table'',        TABLE_NAME,
                        ''fk_column'',       outgoing[p7_i]:column_mappings[0]:fk_column::VARCHAR,
                        ''ref_table'',       outgoing[p7_i]:table::VARCHAR,
                        ''ref_column'',      outgoing[p7_i]:column_mappings[0]:pk_column::VARCHAR,
                        ''value_overlap_pct'', outgoing[p7_i]:value_overlap_pct::FLOAT,
                        ''confidence'',      ''LOW''
                    ));
                END IF;
            END FOR;

            -- Add alternate key reviews (when Step 3 flagged additional unique columns)
            IF (alternate_keys_review_required) THEN
                FOR p7_ak IN 0 TO ARRAY_SIZE(additional_unique_cols) - 1 DO
                    p2_review_id := p2_review_id + 1;
                    p2_review_batch := ARRAY_APPEND(p2_review_batch, OBJECT_CONSTRUCT(
                        ''id'',        p2_review_id,
                        ''ak_idx'',    p7_ak,
                        ''type'',      ''ALTERNATE_KEY'',
                        ''table'',     TABLE_NAME,
                        ''column'',    additional_unique_cols[p7_ak]:column::VARCHAR,
                        ''pk_column'', pk_col
                    ));
                END FOR;
            END IF;

            p2_review_count := ARRAY_SIZE(p2_review_batch);

            IF (p2_review_count > 0) THEN

                -- Cap batch at 15 items to stay within LLM context window
                p2_review_batch_trimmed := IFF(
                    p2_review_count > 15,
                    ARRAY_SLICE(p2_review_batch, 0, 15),
                    p2_review_batch
                );

                -- Build evidence-aware prompt (structural metadata only; NO raw sample values per D5)
                p2_prompt :=
                    ''You are a senior data engineer validating inferred foreign-key and alternate-key''
                    || '' relationships in a Snowflake data warehouse.''
                    || CHR(10)
                    || ''Reason ONLY from the structural evidence fields supplied per item.''
                    || CHR(10)
                    || ''Do NOT invent facts not present in the metadata. Do NOT reference table or''
                    || '' column names as if you know their business meaning unless the name itself''
                    || '' is evidence (e.g. CUSTOMER_ID → likely customer identifier).''
                    || CHR(10)
                    || ''Respond with a valid JSON ARRAY ONLY. No prose, no markdown, no extra text.''
                    || CHR(10) || CHR(10)
                    || ''## Evidence field guide''
                    || CHR(10)
                    || ''Each review item is one of three types:''
                    || CHR(10)
                    || ''  FUZZY_FK          — column matched via Cortex Search semantic similarity,''
                    || '' all 4 SQL gates passed.''
                    || CHR(10)
                    || ''  LOW_CONF_EXACT_FK — same column name in both tables, uniqueness verified,''
                    || '' but value overlap was 40-59% (borderline).''
                    || CHR(10)
                    || ''  ALTERNATE_KEY     — column is non-null + unique but not selected as PK.''
                    || '' Verify if it is a real business key or coincidentally unique.''
                    || CHR(10) || CHR(10)
                    || ''Evidence fields and how to interpret them:''
                    || CHR(10)
                    || ''  semantic_similarity  : 0.0-1.0 (FUZZY_FK only).''
                    || '' >=0.55=strong semantic match; 0.40-0.54=moderate.''
                    || '' NOTE: scores in the 0.50-0.65 range are completely normal even for''
                    || '' exact synonym matches (e.g. CUSTOMER_KEY vs CUSTOMER_ID).''
                    || CHR(10)
                    || ''  profile_score        : 0-100 (V9: PATTERN_CLASS activated, matching class adds 25 pts).''
                    || '' >=70=strong structural match; 50-69=moderate; <50=weak.''
                    || CHR(10)
                    || ''  distinct_count_ratio : min/max of distinct counts of the two columns.''
                    || '' >=0.80=closely proportional (strong); 0.30-0.79=partial (passed hard gate,''
                    || '' weaker).''
                    || CHR(10)
                    || ''  fk_length_range      : "min-max" value lengths in FK column (e.g. "18-18").''
                    || CHR(10)
                    || ''  ref_length_range     : "min-max" value lengths in referenced column.''
                    || '' Fixed-width match (both "18-18") = strong signal for ID columns.''
                    || CHR(10)
                    || ''  pattern_class_fk     : Character class of FK column (NUMERIC/ALPHA/ALPHANUMERIC/FORMATTED/EMPTY).''
                    || CHR(10)
                    || ''  pattern_class_ref    : Character class of referenced column.''
                    || '' pattern_class_match=true = +25 pts to profile score.''
                    || CHR(10)
                    || ''  fk_null_pct          : % NULL in FK column. 0=fully populated.''
                    || CHR(10)
                    || ''  ref_null_pct         : % NULL in referenced column.''
                    || '' Large difference (>30) weakens the FK hypothesis.''
                    || CHR(10)
                    || ''  value_overlap_pct    : % of FK sample values found in referenced column.''
                    || '' >=80=strong referential integrity; 40-79=partial overlap.''
                    || CHR(10) || CHR(10)
                    || ''## Verdict rules''
                    || CHR(10)
                    || ''  VALID    : Multiple strong signals agree.''
                    || '' Typically: semantic_similarity>=0.55 AND overlap>=80 AND profile_score>=70.''
                    || CHR(10)
                    || ''  UNCERTAIN: Mixed signals. Some strong, some weak. Human review recommended.''
                    || CHR(10)
                    || ''  INVALID  : Evidence is predominantly weak or contradictory.''
                    || CHR(10)
                    || ''Bias toward UNCERTAIN when signals disagree.''
                    || '' Never return VALID when value_overlap_pct < 50.''
                    || CHR(10) || CHR(10)
                    || ''## Items to review''
                    || CHR(10) || p2_review_batch_trimmed::VARCHAR
                    || CHR(10) || CHR(10)
                    || ''## Required output (one JSON object per item, wrapped in array)''
                    || CHR(10)
                    || ''[{"id":<id>,"verdict":"VALID"|"UNCERTAIN"|"INVALID",''
                    || ''"confidence_note":"<one sentence citing specific evidence fields and values>",''
                    || ''"source_references":["<field_name>:<value> — <brief interpretation>"]}]'';

                -- Call Cortex Complete (mixtral-8x7b) with :variable binding — no escaping needed
                p2_llm_raw := NULL;
                BEGIN
                    rs := (SELECT SNOWFLAKE.CORTEX.COMPLETE(
                        ''mixtral-8x7b'',
                        :p2_prompt
                    ) AS llm_resp);
                    FOR r IN rs DO
                        p2_llm_raw := r.llm_resp;
                    END FOR;
                EXCEPTION WHEN OTHER THEN
                    p2_phase2_err := p2_phase2_err || '' Step7.LLM:'' || SQLERRM;
                END;

                -- Parse verdicts (TRY_PARSE_JSON: graceful if LLM returns non-JSON)
                p2_verdicts := NULL;
                IF (p2_llm_raw IS NOT NULL) THEN
                    p2_verdicts := TRY_PARSE_JSON(p2_llm_raw::VARCHAR);
                END IF;

            END IF;  -- p2_review_count > 0

        EXCEPTION WHEN OTHER THEN
            p2_phase2_err := p2_phase2_err || '' Step7:'' || SQLERRM;
        END;  -- Step 7


        -- ── Step 7 post-processing: Rebuild outgoing[] with semantic reviews ──
        -- Rebuild only when verdicts were successfully parsed.
        -- Strips internal tracking fields; attaches semantic_review where matched.
        BEGIN
            IF (p2_verdicts IS NOT NULL AND ARRAY_SIZE(p2_verdicts) > 0) THEN
                p2_outgoing_final := ARRAY_CONSTRUCT();

                FOR p7_i IN 0 TO ARRAY_SIZE(outgoing) - 1 DO
                    p2_verdict_obj := NULL;
                    p2_has_verdict := FALSE;
                    p2_final_conf  := outgoing[p7_i]:confidence::VARCHAR;

                    -- Find review batch entry for this outgoing index
                    FOR rb_i IN 0 TO ARRAY_SIZE(p2_review_batch_trimmed) - 1 DO
                        IF (p2_review_batch_trimmed[rb_i]:outgoing_idx::INTEGER = p7_i) THEN
                            p2_match_id := p2_review_batch_trimmed[rb_i]:id::INTEGER;
                            -- Find matching verdict by id
                            FOR v_i IN 0 TO ARRAY_SIZE(p2_verdicts) - 1 DO
                                IF (p2_verdicts[v_i]:id::INTEGER = p2_match_id) THEN
                                    p2_verdict_str := p2_verdicts[v_i]:verdict::VARCHAR;
                                    -- INVALID → demote to FLAGGED (relationship kept in output)
                                    IF (p2_verdict_str = ''INVALID'') THEN
                                        p2_final_conf := ''FLAGGED'';
                                    END IF;
                                    p2_verdict_obj := OBJECT_CONSTRUCT(
                                        ''verdict'',           p2_verdict_str,
                                        ''confidence_note'',   p2_verdicts[v_i]:confidence_note::VARCHAR,
                                        ''source_references'', p2_verdicts[v_i]:source_references,
                                        ''reviewed_by'',       ''mixtral-8x7b'',
                                        ''reviewed_at'',       CURRENT_TIMESTAMP()::VARCHAR
                                    );
                                    p2_has_verdict := TRUE;
                                END IF;
                            END FOR;
                        END IF;
                    END FOR;

                    -- Rebuild element (OBJECT_CONSTRUCT omits NULL values automatically)
                    p2_outgoing_final := ARRAY_APPEND(p2_outgoing_final, OBJECT_CONSTRUCT(
                        ''schema'',               outgoing[p7_i]:schema,
                        ''table'',                outgoing[p7_i]:table,
                        ''type'',                 outgoing[p7_i]:type,
                        ''confidence'',           p2_final_conf,
                        ''inferred_method'',      outgoing[p7_i]:inferred_method,
                        ''column_mappings'',      outgoing[p7_i]:column_mappings,
                        -- Phase 1 INFERRED fields (NULL for FUZZY → omitted by OBJECT_CONSTRUCT)
                        ''value_overlap_pct'',    outgoing[p7_i]:value_overlap_pct,
                        ''data_type_match'',      outgoing[p7_i]:data_type_match,
                        -- Phase 2 FUZZY field (NULL for INFERRED → omitted)
                        ''relationship_evidence'', outgoing[p7_i]:relationship_evidence,
                        -- Semantic review (NULL when not reviewed → omitted)
                        ''semantic_review'',      p2_verdict_obj
                    ));
                END FOR;

                outgoing := p2_outgoing_final;

            END IF;  -- verdicts available

            -- Attach semantic review to additional_unique_cols entries (alternate key review)
            IF (alternate_keys_review_required AND p2_verdicts IS NOT NULL) THEN
                p2_addl_final := ARRAY_CONSTRUCT();
                FOR p7_ak IN 0 TO ARRAY_SIZE(additional_unique_cols) - 1 DO
                    p2_verdict_obj := NULL;

                    -- Find verdict for this alternate key entry
                    FOR rb_i IN 0 TO ARRAY_SIZE(p2_review_batch_trimmed) - 1 DO
                        IF (p2_review_batch_trimmed[rb_i]:type::VARCHAR = ''ALTERNATE_KEY''
                            AND p2_review_batch_trimmed[rb_i]:ak_idx::INTEGER = p7_ak) THEN
                            p2_ak_match_id := p2_review_batch_trimmed[rb_i]:id::INTEGER;
                            FOR v_i IN 0 TO ARRAY_SIZE(p2_verdicts) - 1 DO
                                IF (p2_verdicts[v_i]:id::INTEGER = p2_ak_match_id) THEN
                                    p2_verdict_obj := OBJECT_CONSTRUCT(
                                        ''verdict'',           p2_verdicts[v_i]:verdict::VARCHAR,
                                        ''confidence_note'',   p2_verdicts[v_i]:confidence_note::VARCHAR,
                                        ''source_references'', p2_verdicts[v_i]:source_references,
                                        ''reviewed_by'',       ''mixtral-8x7b'',
                                        ''reviewed_at'',       CURRENT_TIMESTAMP()::VARCHAR
                                    );
                                END IF;
                            END FOR;
                        END IF;
                    END FOR;

                    p2_addl_final := ARRAY_APPEND(p2_addl_final, OBJECT_CONSTRUCT(
                        ''column'',              additional_unique_cols[p7_ak]:column,
                        ''tier'',                additional_unique_cols[p7_ak]:tier,
                        ''uniqueness_verified'', additional_unique_cols[p7_ak]:uniqueness_verified,
                        ''reason'',              additional_unique_cols[p7_ak]:reason,
                        ''review_note'',         additional_unique_cols[p7_ak]:review_note,
                        ''semantic_review'',     p2_verdict_obj  -- NULL → omitted if not reviewed
                    ));
                END FOR;
                additional_unique_cols := p2_addl_final;
            END IF;

        EXCEPTION WHEN OTHER THEN
            p2_phase2_err := p2_phase2_err || '' Step7.rebuild:'' || SQLERRM;
        END;  -- Step 7 post-processing


        -- ══════════════════════════════════════════════════════════════════
        -- STEP 8 — INCOMING RELATIONSHIP BATCH SEMANTIC REVIEW (V10 NEW)
        -- ══════════════════════════════════════════════════════════════════
        -- Mirrors Step 7 but scoped exclusively to Phase 2C fuzzy incoming entries.
        -- Uses a direction-aware prompt: the LLM reasons about which table is the
        -- child (FK holder) vs parent (PK holder), preventing false positives where
        -- a PK column in another table is mistaken for a back-reference to this PK.
        -- Batch cap: 10 items (independent of Step 7''s 15-item cap).
        -- Matched by (fk_table, fk_column) pair — immune to Phase 1 offset in incoming[].
        -- INVALID verdict → confidence demoted to FLAGGED (kept for auditability).
        -- ══════════════════════════════════════════════════════════════════
        BEGIN
            p8_review_count := ARRAY_SIZE(p8_review_batch);

            IF (p8_review_count > 0) THEN

                -- Cap at 10 items (independent of Step 7''s cap)
                p8_review_batch_trimmed := IFF(
                    p8_review_count > 10,
                    ARRAY_SLICE(p8_review_batch, 0, 10),
                    p8_review_batch
                );

                -- Direction-aware prompt for incoming FK review
                p8_prompt :=
                    ''You are a senior data engineer validating inferred INCOMING foreign-key''
                    || '' relationships in a Snowflake star schema.''
                    || CHR(10)
                    || ''DIRECTION: fk_table.fk_column is in the CHILD table and supposedly''
                    || '' holds a foreign key pointing to ref_table.ref_column (the PK).''
                    || '' Direction: fk_table → ref_table.''
                    || CHR(10)
                    || ''COMMON FALSE POSITIVE TYPE 1: a column that is itself a PK in''
                    || '' fk_table will have high distinct count and low null% — this does''
                    || '' NOT make it an FK to ref_table.''
                    || CHR(10)
                    || ''COMMON FALSE POSITIVE TYPE 2 — NAMING MISMATCH (most reliable signal):''
                    || '' if fk_column and ref_column share NO common word root or stem''
                    || '' (e.g. ORDER_KEY vs SALES_KEY, PRODUCT_ID vs SALES_KEY), this is''
                    || '' strong evidence the match is semantically wrong regardless of''
                    || '' value overlap. A true FK column name normally references the parent''
                    || '' table (e.g. CUSTOMER_ID in an orders table). If the names are''
                    || '' unrelated, return INVALID unless there is overwhelming other evidence.''
                    || CHR(10)
                    || ''Reason ONLY from the structural evidence fields. Do NOT invent facts.''
                    || CHR(10)
                    || ''Respond with a valid JSON ARRAY ONLY. No prose, no markdown, no extra text.''
                    || CHR(10) || CHR(10)
                    || ''## Evidence field guide''
                    || CHR(10)
                    || ''  semantic_similarity  : 0.0-1.0. Cortex Search cosine similarity.''
                    || '' >=0.55=strong; 0.40-0.54=moderate; <0.40=weak.''
                    || '' NOTE: scores in the 0.50-0.65 range are completely normal even for''
                    || '' exact synonym matches (e.g. CUSTOMER_KEY vs CUSTOMER_ID).''
                    || '' Do NOT reject a match solely because the score is ~0.55.''
                    || CHR(10)
                    || ''  profile_score        : 0-100. >=70=strong structural match; <50=weak.''
                    || CHR(10)
                    || ''  fk_distinct_count    : distinct values in the candidate FK column.''
                    || CHR(10)
                    || ''  ref_distinct_count   : distinct values in the referenced PK column.''
                    || '' For a true FK: fk_distinct_count <= ref_distinct_count.''
                    || '' However, fk_distinct_count < ref_distinct_count alone is NOT''
                    || '' sufficient to conclude VALID — it is only a necessary condition,''
                    || '' not sufficient. Naming and semantic evidence must also support it.''
                    || CHR(10)
                    || ''  fk_null_pct          : % NULL in fk_column.''
                    || CHR(10)
                    || ''  value_overlap_pct    : % of FK sample values found in ref PK column.''
                    || '' >=80=strong; 40-79=partial. High overlap with unrelated names''
                    || '' is a numeric coincidence, not FK evidence.''
                    || CHR(10)
                    || ''  fk_length_range      : min-max character lengths in fk_column.''
                    || CHR(10)
                    || ''  ref_length_range     : min-max character lengths in ref column.''
                    || '' Identical ranges are a moderate structural signal.''
                    || CHR(10)
                    || ''  pattern_class_match  : true = both columns share the same character class.''
                    || CHR(10) || CHR(10)
                    || ''## Verdict rules (evaluate in this order)''
                    || CHR(10)
                    || ''  Step 1 — Naming check (highest priority):''
                    || ''   Do fk_column and ref_column share a common root? (e.g. CUSTOMER_ID''
                    || '' → CUSTOMER_KEY = related; ORDER_KEY → SALES_KEY = unrelated.)''
                    || ''   If UNRELATED names: return INVALID. Stop.''
                    || CHR(10)
                    || ''  Step 2 — Structural check:''
                    || ''   Is fk_distinct_count > ref_distinct_count? Return INVALID. Stop.''
                    || CHR(10)
                    || ''  Step 3 — Confidence check:''
                    || ''   semantic_similarity >= 0.55 AND value_overlap >= 80: VALID.''
                    || ''   semantic_similarity >= 0.40 OR value_overlap >= 60: UNCERTAIN.''
                    || ''   Otherwise: INVALID.''
                    || CHR(10) || CHR(10)
                    || ''## Items to review''
                    || CHR(10) || p8_review_batch_trimmed::VARCHAR
                    || CHR(10) || CHR(10)
                    || ''## Required output (one JSON object per item, wrapped in array)''
                    || CHR(10)
                    || ''[{"id":<id>,"verdict":"VALID"|"UNCERTAIN"|"INVALID",''
                    || ''"confidence_note":"<one sentence citing specific evidence fields and values>",''
                    || ''"source_references":["<field_name>:<value> — <brief interpretation>"]}]'';

                -- Call Cortex Complete
                p8_llm_raw := NULL;
                BEGIN
                    rs := (SELECT SNOWFLAKE.CORTEX.COMPLETE(
                        ''mixtral-8x7b'',
                        :p8_prompt
                    ) AS llm_resp);
                    FOR r IN rs DO
                        p8_llm_raw := r.llm_resp;
                    END FOR;
                EXCEPTION WHEN OTHER THEN
                    p2_phase2_err := p2_phase2_err || '' Step8.LLM:'' || SQLERRM;
                END;

                -- Parse verdicts (TRY_PARSE_JSON: graceful if LLM returns non-JSON)
                p8_verdicts := NULL;
                IF (p8_llm_raw IS NOT NULL) THEN
                    p8_verdicts := TRY_PARSE_JSON(p8_llm_raw::VARCHAR);
                END IF;

            END IF;  -- p8_review_count > 0

        EXCEPTION WHEN OTHER THEN
            p2_phase2_err := p2_phase2_err || '' Step8:'' || SQLERRM;
        END;  -- Step 8


        -- ── Step 8 post-processing: Rebuild incoming[] with semantic reviews ──────────────────
        -- Matched by (fk_table, fk_column) pair to avoid Phase 1 index offset.
        BEGIN
            IF (p8_verdicts IS NOT NULL AND ARRAY_SIZE(p8_verdicts) > 0) THEN
                p8_incoming_final := ARRAY_CONSTRUCT();

                FOR p8_i IN 0 TO ARRAY_SIZE(incoming) - 1 DO
                    p8_verdict_obj := NULL;
                    p8_has_verdict := FALSE;
                    p8_final_conf  := incoming[p8_i]:confidence::VARCHAR;

                    -- Only FUZZY incoming entries were submitted to Step 8
                    IF (incoming[p8_i]:type::VARCHAR = ''FUZZY'') THEN
                        LET p8_cand_fk_tbl VARCHAR := incoming[p8_i]:table::VARCHAR;
                        LET p8_cand_fk_col VARCHAR := incoming[p8_i]:column_mappings[0]:fk_column::VARCHAR;

                        -- Match by (fk_table, fk_column) in the batch
                        FOR rb_i IN 0 TO ARRAY_SIZE(p8_review_batch_trimmed) - 1 DO
                            IF (p8_review_batch_trimmed[rb_i]:fk_table::VARCHAR = p8_cand_fk_tbl
                                AND p8_review_batch_trimmed[rb_i]:fk_column::VARCHAR = p8_cand_fk_col) THEN
                                LET p8_match_id INTEGER := p8_review_batch_trimmed[rb_i]:id::INTEGER;
                                FOR v_i IN 0 TO ARRAY_SIZE(p8_verdicts) - 1 DO
                                    IF (p8_verdicts[v_i]:id::INTEGER = p8_match_id) THEN
                                        p8_verdict_str := p8_verdicts[v_i]:verdict::VARCHAR;
                                        IF (p8_verdict_str = ''INVALID'') THEN
                                            p8_final_conf := ''FLAGGED'';
                                        END IF;
                                        p8_verdict_obj := OBJECT_CONSTRUCT(
                                            ''verdict'',           p8_verdict_str,
                                            ''confidence_note'',   p8_verdicts[v_i]:confidence_note::VARCHAR,
                                            ''source_references'', p8_verdicts[v_i]:source_references,
                                            ''reviewed_by'',       ''mixtral-8x7b'',
                                            ''reviewed_at'',       CURRENT_TIMESTAMP()::VARCHAR
                                        );
                                        p8_has_verdict := TRUE;
                                    END IF;
                                END FOR;
                            END IF;
                        END FOR;
                    END IF;

                    -- Rebuild (OBJECT_CONSTRUCT omits NULL values automatically)
                    p8_incoming_final := ARRAY_APPEND(p8_incoming_final, OBJECT_CONSTRUCT(
                        ''schema'',               incoming[p8_i]:schema,
                        ''table'',                incoming[p8_i]:table,
                        ''type'',                 incoming[p8_i]:type,
                        ''confidence'',           p8_final_conf,
                        ''inferred_method'',      incoming[p8_i]:inferred_method,
                        ''column_mappings'',      incoming[p8_i]:column_mappings,
                        ''value_overlap_pct'',    incoming[p8_i]:value_overlap_pct,
                        ''data_type_match'',      incoming[p8_i]:data_type_match,
                        ''relationship_evidence'', incoming[p8_i]:relationship_evidence,
                        -- NULL for non-FUZZY entries → omitted by OBJECT_CONSTRUCT
                        ''semantic_review'',      p8_verdict_obj
                    ));
                END FOR;

                incoming := p8_incoming_final;
            END IF;

        EXCEPTION WHEN OTHER THEN
            p2_phase2_err := p2_phase2_err || '' Step8.rebuild:'' || SQLERRM;
        END;  -- Step 8 post-processing

        EXCEPTION WHEN OTHER THEN
            p2_phase2_err := p2_phase2_err || '' Phase2.outer:'' || SQLERRM;
            p2_enabled    := FALSE;
        END;  -- Phase 2 outer exception guard

    END IF;  -- phase2_needed


    -- ── Return ────────────────────────────────────────────────────────
    RETURN OBJECT_CONSTRUCT(
        ''status'',             ''OK'',
        ''table'',              fqn,
        ''phase2_enabled'',     p2_enabled,
        -- V9: phase2_skip_reason as top-level field.
        -- CHECK_TABLE_STALENESS Gate 4 reads this to distinguish deliberate skips
        -- (no PHASE2_UPGRADE) from unexpected failures (triggers PHASE2_UPGRADE).
        -- Values: formal_constraints_sufficient | infrastructure_not_deployed |
        --         schema_sweep_phase2_deferred  | null (Phase 2 ran normally)
        ''phase2_skip_reason'', phase2_skip_reason,
        ''pk_detection'', OBJECT_CONSTRUCT(
            ''pk_confirmed'',                   pk_done,
            ''human_review_required'',          NOT pk_done,
            ''alternate_keys_review_required'', alternate_keys_review_required,
            ''confirmed_pk'',                   confirmed_pk,
            ''additional_unique_columns'',      additional_unique_cols,
            ''eliminated_candidates'',          eliminated,
            ''composite_pk_candidates'',        composite_cands,
            ''scan_strategy'', ''TIERED (col_count='' || col_count || '', Tier1_first, Tier2_fallback, regexp_like_patterns)'',
            -- V9: Phase 2A result block — only present when Phase 2A identified the PK
            ''fuzzy_pk'', IFF(p2_enabled AND p2a_found,
                OBJECT_CONSTRUCT(
                    ''column'',              pk_col,
                    ''confidence'',          IFF(p2a_sim_score >= 0.90, ''MEDIUM'', ''LOW''),
                    ''semantic_similarity'', p2a_sim_score,
                    ''inferred_method'',     ''CORTEX_SEARCH_PK_FUZZY'',
                    ''is_likely_key_verified'', TRUE
                ), NULL),
            ''pk_note'', IFF(NOT pk_done,
                ''No single-column PK detected. Composite PK suspected or human validation required.'',
                IFF(alternate_keys_review_required,
                    ''PK inferred from data. Additional unique columns detected — see additional_unique_columns. Verify if they are alternate business keys or coincidentally unique data.'',
                    IFF(ARRAY_SIZE(confirmed_pk) > 0 AND confirmed_pk[0]:confidence::VARCHAR != ''HIGH'',
                        ''PK inferred from data — not formally constrained. Phase 2 Cortex Search can improve FK confidence.'',
                        NULL)))
        ),
        ''summary'', OBJECT_CONSTRUCT(
            ''pk_confirmed'',                    pk_done,
            ''human_review_required'',           NOT pk_done,
            ''alternate_keys_review_required'',  alternate_keys_review_required,
            ''outgoing_count'',                  ARRAY_SIZE(outgoing),
            ''incoming_count'',                  ARRAY_SIZE(incoming),
            ''additional_unique_columns_count'', ARRAY_SIZE(additional_unique_cols),
            ''formal_outgoing_count'',           formal_outgoing_count,    -- V10: formal FK count
            ''orphan_key_col_count'',            orphan_key_col_count,     -- V10: unresolved key-like cols
            ''phase2_fuzzy_outgoing_count'',     p2_fuzzy_count,
            ''phase2_fuzzy_incoming_count'',     p2c_fuzzy_count,
            ''phase2_review_items_sent'',        p2_review_count,
            ''phase2_incoming_review_items_sent'', p8_review_count,        -- V10: Step 8 batch size
            ''phase2_skip_reason'',              phase2_skip_reason,
            -- Only included when Phase 2 encountered an error (NULL otherwise → omitted)
            ''phase2_error'', IFF(LENGTH(p2_phase2_err) > 0, p2_phase2_err, NULL)
        ),
        ''outgoing'', outgoing,
        ''incoming'', incoming
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''UNEXPECTED_ERROR'',
            ''message'', SQLERRM);
END;
';

-- GET_SAMPLE_ROWS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GET_SAMPLE_ROWS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR, "SAMPLE_SIZE" NUMBER(38,0))
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    query        VARCHAR;
    rs           RESULTSET;
    result       VARIANT;
    n            INTEGER;
    fetch_failed BOOLEAN DEFAULT FALSE;
    db_cnt       INTEGER DEFAULT 0;
    sc_cnt       INTEGER DEFAULT 0;
    tb_cnt       INTEGER DEFAULT 0;
BEGIN
    n := COALESCE(SAMPLE_SIZE, 10);

    BEGIN
        query := ''
            SELECT ARRAY_AGG(row_data) AS SAMPLE_ROWS
            FROM (
                SELECT OBJECT_CONSTRUCT(*) AS row_data
                FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME || ''
                LIMIT '' || n || ''
            )
        '';
        rs := (EXECUTE IMMEDIATE :query);
        FOR rec IN rs DO result := rec.SAMPLE_ROWS; END FOR;
    EXCEPTION
        WHEN OTHER THEN fetch_failed := TRUE;
    END;

    IF (fetch_failed = TRUE) THEN
        query := ''SELECT COUNT(*) AS CNT FROM SNOWFLAKE.ACCOUNT_USAGE.DATABASES WHERE DATABASE_NAME = UPPER('''''' || DB_NAME || '''''') AND DELETED IS NULL'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR rec IN rs DO db_cnt := rec.CNT; END FOR;
        IF (db_cnt = 0) THEN
            RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''DB_NOT_FOUND'', ''message'', ''Database "'' || DB_NAME || ''" does not exist.'');
        END IF;

        query := ''SELECT COUNT(*) AS CNT FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = UPPER('''''' || SCHEMA_NAME || '''''')'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR rec IN rs DO sc_cnt := rec.CNT; END FOR;
        IF (sc_cnt = 0) THEN
            RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''SCHEMA_NOT_FOUND'', ''message'', ''Schema "'' || SCHEMA_NAME || ''" not found.'');
        END IF;

        query := ''SELECT COUNT(*) AS CNT FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''') AND TABLE_NAME = UPPER('''''' || TABLE_NAME || '''''')'';
        rs := (EXECUTE IMMEDIATE :query);
        FOR rec IN rs DO tb_cnt := rec.CNT; END FOR;
        IF (tb_cnt = 0) THEN
            RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''TABLE_NOT_FOUND'', ''message'', ''Table "'' || TABLE_NAME || ''" not found.'');
        END IF;

        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', ''Could not fetch sample rows.'');
    END IF;

    IF (result IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''OK'', ''code'', ''EMPTY_TABLE'',
            ''message'', ''Table "'' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME || ''" has no rows.'',
            ''rows'', ARRAY_CONSTRUCT());
    END IF;

    RETURN OBJECT_CONSTRUCT(
        ''status'',      ''OK'',
        ''code'',        ''SUCCESS'',
        ''table'',       DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME,
        ''sample_size'', ARRAY_SIZE(result::ARRAY),
        ''rows'',        result
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', SQLERRM);
END;
';

-- GET_COLUMN_PROFILE
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GET_COLUMN_PROFILE("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR, "COLUMN_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    query        VARCHAR;
    rs           RESULTSET;
    col_type     VARCHAR;
    row_count    INTEGER DEFAULT 0;
    dist_count   INTEGER DEFAULT 0;
    null_count   INTEGER DEFAULT 0;
    base_stats   VARIANT;
    val_list     VARIANT;
    val_type     VARCHAR;
BEGIN
    -- Step 1: Get column data type
    query := ''
        SELECT DATA_TYPE FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
          AND COLUMN_NAME  = UPPER('''''' || COLUMN_NAME || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO col_type := r.DATA_TYPE; END FOR;

    -- Step 2: Vital stats
    query := ''
        SELECT
            COUNT(*) AS RC,
            COUNT(DISTINCT "'' || COLUMN_NAME || ''") AS DC,
            COUNT(*) - COUNT("'' || COLUMN_NAME || ''") AS NC
        FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO
        row_count  := r.RC;
        dist_count := r.DC;
        null_count := r.NC;
    END FOR;

    -- Step 3: Values (all unique if <=15, else sample 10)
    IF (dist_count <= 15) THEN
        val_type := ''UNIQUE'';
        query := ''SELECT ARRAY_AGG(DISTINCT "'' || COLUMN_NAME || ''") WITHIN GROUP (ORDER BY "'' || COLUMN_NAME || ''") AS VALS
                  FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME || ''
                  WHERE "'' || COLUMN_NAME || ''" IS NOT NULL'';
    ELSE
        val_type := ''SAMPLE'';
        query := ''SELECT ARRAY_AGG(VAL) AS VALS FROM (
                    SELECT DISTINCT "'' || COLUMN_NAME || ''" AS VAL
                    FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME || ''
                    WHERE "'' || COLUMN_NAME || ''" IS NOT NULL LIMIT 10
                  )'';
    END IF;
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO val_list := r.VALS; END FOR;

    -- Step 4: Range or length stats
    IF (col_type IN (''NUMBER'', ''FLOAT'', ''INTEGER'', ''DATE'', ''TIMESTAMP_NTZ'', ''TIMESTAMP_LTZ'', ''TIMESTAMP_TZ'')) THEN
        query := ''SELECT OBJECT_CONSTRUCT(''''min'''', MIN("'' || COLUMN_NAME || ''"), ''''max'''', MAX("'' || COLUMN_NAME || ''")) AS GS
                  FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;
    ELSE
        query := ''SELECT OBJECT_CONSTRUCT(''''min_len'''', MIN(LENGTH("'' || COLUMN_NAME || ''")), ''''max_len'''', MAX(LENGTH("'' || COLUMN_NAME || ''"))) AS GS
                  FROM '' || DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;
    END IF;
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO base_stats := r.GS; END FOR;

    -- Step 5: Return structured payload
    RETURN OBJECT_CONSTRUCT(
        ''status'',         ''OK'',
        ''column'',         COLUMN_NAME,
        ''data_type'',      col_type,
        ''row_count'',      row_count,
        ''null_count'',     null_count,
        ''null_pct'',       ROUND(null_count * 100.0 / NULLIF(row_count, 0), 2),
        ''distinct_count'', dist_count,
        ''value_type'',     val_type,
        ''values'',         val_list,
        ''range_stats'',    base_stats
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(''status'', ''ERROR'', ''code'', ''UNEXPECTED_ERROR'', ''message'', SQLERRM);
END;
';

-- CHECK_TABLE_STALENESS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.CHECK_TABLE_STALENESS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    fqn                 VARCHAR;
    stored_view_id      VARCHAR;
    stored_gen_at       TIMESTAMP_NTZ;
    stored_col_hash     VARCHAR;
    stored_altered      TIMESTAMP_NTZ;
    stored_p2           BOOLEAN;
    stored_skip_reason  VARCHAR;   -- V4: reads phase2_skip_reason top-level field
    src_altered         TIMESTAMP_NTZ;
    live_col_hash       VARCHAR;
    p2_infra_exists     BOOLEAN DEFAULT FALSE;  -- Gate 4: is COLUMN_PROFILE_CACHE deployed?
    p2_infra_count      INTEGER DEFAULT 0;
    query               VARCHAR;
    rs                  RESULTSET;
BEGIN
    fqn := DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME;

    -- ── Gate 1: Does an ACTIVE semantic view exist? ───────────────────
    -- Reads phase2_enabled AND phase2_skip_reason from stored SEMANTIC_VIEW VARIANT.
    -- Both are TOP-LEVEL fields in the agent-assembled JSON saved by SAVE_SEMANTIC_VIEW.
    -- Path: SEMANTIC_VIEW:phase2_enabled        (BOOLEAN)
    --       SEMANTIC_VIEW:phase2_skip_reason    (VARCHAR | null)
    query := ''
        SELECT
            VIEW_ID,
            GENERATED_AT,
            COLUMN_SET_HASH,
            LAST_ALTERED_TS,
            COALESCE(SEMANTIC_VIEW:phase2_enabled::BOOLEAN, FALSE)     AS P2_ENABLED,
            SEMANTIC_VIEW:phase2_skip_reason::VARCHAR                  AS P2_SKIP_REASON
        FROM __STTM_METADATA_NAMESPACE__.SEM_TABLE_VIEWS
        WHERE DATABASE_NAME = UPPER('''''' || DB_NAME    || '''''')
          AND SCHEMA_NAME   = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME    = UPPER('''''' || TABLE_NAME  || '''''')
          AND STATUS        = ''''ACTIVE''''
        ORDER BY GENERATED_AT DESC LIMIT 1
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO
        stored_view_id    := r.VIEW_ID;
        stored_gen_at     := r.GENERATED_AT;
        stored_col_hash   := r.COLUMN_SET_HASH;
        stored_altered    := r.LAST_ALTERED_TS;
        stored_p2         := r.P2_ENABLED;
        stored_skip_reason := r.P2_SKIP_REASON;  -- V4: null = unexpected failure
    END FOR;

    IF (stored_view_id IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''MISSING'',
            ''code'',    ''NO_SEMANTIC_VIEW'',
            ''message'', ''No active semantic view found for '' || fqn || ''. Run the full discovery pipeline.'',
            ''fqn'',     fqn
        );
    END IF;

    -- ── Gate 0: 7-day TTL check (V4 NEW) ──────────────────────────────────
    IF (stored_gen_at < DATEADD(day, -7, CURRENT_TIMESTAMP())) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',        ''STALE'',
            ''code'',          ''TTL_EXPIRED'',
            ''message'',       ''Semantic view for '' || fqn || '' is older than 7 days. Regenerate.'',
            ''view_id'',       stored_view_id,
            ''generated_at'',  stored_gen_at
        );
    END IF;

    -- ── Gate 2: COLUMN_SET_HASH check (primary structural gate) ──────
    -- Hash = MD5(COLUMN_NAME:DATA_TYPE:IS_NULLABLE sorted alphabetically).
    -- Detects: column added, removed, type changed, nullability changed.
    query := ''
        SELECT MD5(
            LISTAGG(COLUMN_NAME || '''':'''' || DATA_TYPE || '''':'''' || IS_NULLABLE, ''''|'''')
            WITHIN GROUP (ORDER BY COLUMN_NAME)
        ) AS COL_HASH
        FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO live_col_hash := r.COL_HASH; END FOR;

    IF (live_col_hash != stored_col_hash OR stored_col_hash IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',        ''STALE'',
            ''code'',          ''COLUMNS_CHANGED'',
            ''message'',       ''Column structure of '' || fqn || '' has changed since last semantic view. Regenerate.'',
            ''view_id'',       stored_view_id,
            ''generated_at'',  stored_gen_at
        );
    END IF;

    -- ── Gate 3: LAST_ALTERED_TS check (DDL safety net) ────────────────
    -- Catches DDL events not reflected in column-set hash
    -- (e.g. column renames, comment changes, constraint updates).
    query := ''
        SELECT LAST_ALTERED
        FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME   = UPPER('''''' || TABLE_NAME  || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO src_altered := r.LAST_ALTERED; END FOR;

    IF (src_altered > stored_altered OR stored_altered IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',             ''STALE'',
            ''code'',               ''DDL_ALTERED'',
            ''message'',            ''Table '' || fqn || '' was altered after the last semantic view was generated. Regenerate.'',
            ''view_id'',            stored_view_id,
            ''table_last_altered'', src_altered,
            ''view_generated_at'',  stored_gen_at
        );
    END IF;

    -- ── Gate 4: Phase 2 gap + skip reason check (V4) ─────────────────
    -- Phase 2 did not run last time (phase2_enabled=false in stored view).
    --
    -- V4 LOGIC (priority order):
    --   1. If phase2_skip_reason is a known deliberate skip value:
    --      → Return FRESH immediately. Do NOT trigger PHASE2_UPGRADE.
    --        Deliberate skips:
    --          ''formal_constraints_sufficient''  — Phase 1 resolved all PK+FK
    --          ''infrastructure_not_deployed''    — infra was missing at procedure run time
    --          ''schema_sweep_phase2_deferred''   — IN_SCHEMA_SWEEP=TRUE was used
    --
    --   2. If phase2_skip_reason IS NULL (unexpected failure / pre-V9 view):
    --      → Fall back to V3 infrastructure check:
    --          COLUMN_PROFILE_CACHE exists → PHASE2_UPGRADE
    --          COLUMN_PROFILE_CACHE absent → FRESH
    IF (stored_p2 = FALSE OR stored_p2 IS NULL) THEN

        -- ── Sub-check A: Deliberate skip? ────────────────────────────
        IF (stored_skip_reason IN (
                ''formal_constraints_sufficient'',
                ''infrastructure_not_deployed'',
                ''schema_sweep_phase2_deferred''
        )) THEN
            RETURN OBJECT_CONSTRUCT(
                ''status'',             ''FRESH'',
                ''code'',               ''USE_CACHED'',
                ''phase2_enabled'',     FALSE,
                ''phase2_skip_reason'', stored_skip_reason,
                ''message'',            ''Semantic view for '' || fqn || '' is current. ''
                                   || ''Phase 2 was deliberately skipped: '' || stored_skip_reason,
                ''view_id'',            stored_view_id,
                ''generated_at'',       stored_gen_at
            );
        END IF;

        -- ── Sub-check B: Unexpected failure / pre-V9 view ────────────
        -- skip_reason IS NULL means Phase 2 was attempted but failed without
        -- setting a reason, OR this is a pre-V9 view with no skip_reason field.
        -- Apply the V3 infrastructure readiness check.
        BEGIN
            query := ''
                SELECT COUNT(*) AS CNT
                FROM __STTM_METADATA_DATABASE__.INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = ''''__STTM_METADATA_SCHEMA__''''
                  AND TABLE_NAME   = ''''COLUMN_PROFILE_CACHE''''
            '';
            rs := (EXECUTE IMMEDIATE :query);
            FOR r IN rs DO
                p2_infra_count  := r.CNT;
                p2_infra_exists := (r.CNT > 0);
            END FOR;
        EXCEPTION WHEN OTHER THEN
            -- Cannot determine infrastructure state → treat as not ready → stay FRESH
            p2_infra_exists := FALSE;
        END;

        IF (p2_infra_exists = TRUE) THEN
            -- Infrastructure is deployed. Phase 2 failed last time unexpectedly.
            -- Signal agent to re-run full pipeline so Phase 2 can succeed now.
            -- V9: procedure self-determines Phase 2 need — no SKIP_PHASE2 parameter.
            RETURN OBJECT_CONSTRUCT(
                ''status'',               ''PHASE2_UPGRADE'',
                ''code'',                 ''PHASE2_PREVIOUSLY_FAILED'',
                ''infrastructure_ready'', TRUE,
                ''message'',              ''Semantic view for '' || fqn || '' exists (Phase 1 only). ''
                                     || ''Phase 2 infrastructure is deployed. ''
                                     || ''Re-run the full pipeline — the procedure will ''
                                     || ''self-determine whether Phase 2 is needed.'',
                ''view_id'',              stored_view_id,
                ''generated_at'',         stored_gen_at,
                ''phase2_enabled'',       FALSE
            );
        ELSE
            -- Infrastructure not yet deployed (files 17-20 not run).
            -- Accept Phase 1-only view as FRESH. Do NOT trigger a re-run loop.
            RETURN OBJECT_CONSTRUCT(
                ''status'',               ''FRESH'',
                ''code'',                 ''USE_CACHED'',
                ''infrastructure_ready'', FALSE,
                ''message'',              ''Semantic view for '' || fqn || '' is current (Phase 1 only). ''
                                     || ''Phase 2 infrastructure not yet deployed. ''
                                     || ''Run files 17-20 and REFRESH_COLUMN_SEARCH_INDEX ''
                                     || ''to enable fuzzy FK discovery on the next agent run.'',
                ''view_id'',              stored_view_id,
                ''generated_at'',         stored_gen_at,
                ''phase2_enabled'',       FALSE
            );
        END IF;

    END IF;

    -- ── All gates passed: semantic view is structurally FRESH ─────────
    -- Phase 2 ran successfully on the last generation (phase2_enabled=true).
    RETURN OBJECT_CONSTRUCT(
        ''status'',             ''FRESH'',
        ''code'',               ''USE_CACHED'',
        ''message'',            ''Semantic view for '' || fqn || '' is current. Call get_cached_semantic_view.'',
        ''view_id'',            stored_view_id,
        ''generated_at'',       stored_gen_at,
        ''phase2_enabled'',     TRUE,
        ''phase2_skip_reason'', NULL
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''UNEXPECTED_ERROR'',
            ''message'', SQLERRM
        );
END;
';

-- CHECK_COLUMN_STALENESS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.CHECK_COLUMN_STALENESS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR, "COLUMN_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    query            VARCHAR;
    rs               RESULTSET;
    stored_view_id   VARCHAR;
    stored_gen_at    TIMESTAMP_NTZ;
    stored_col_hash  VARCHAR;
    live_col_hash    VARCHAR;
    fqn              VARCHAR;
BEGIN
    fqn := DB_NAME || ''.'' || SCHEMA_NAME || ''.'' || TABLE_NAME || ''.'' || COLUMN_NAME;

    -- ── Gate 1: Does an ACTIVE column view exist? ─────────────────────
    query := ''
        SELECT VIEW_ID, GENERATED_AT, COLUMN_HASH
        FROM __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS
        WHERE DATABASE_NAME = UPPER('''''' || DB_NAME    || '''''')
          AND SCHEMA_NAME   = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME    = UPPER('''''' || TABLE_NAME  || '''''')
          AND COLUMN_NAME   = UPPER('''''' || COLUMN_NAME || '''''')
          AND STATUS        = ''''ACTIVE''''
        ORDER BY GENERATED_AT DESC LIMIT 1
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO
        stored_view_id  := r.VIEW_ID;
        stored_gen_at   := r.GENERATED_AT;
        stored_col_hash := r.COLUMN_HASH;
    END FOR;

    IF (stored_view_id IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''MISSING'',
            ''code'',    ''NO_COLUMN_VIEW'',
            ''message'', ''No active attribute view found for '' || fqn || ''. Profile it.'',
            ''fqn'',     fqn
        );
    END IF;

    -- ── Gate 2: Has the column structure (type + nullable) changed? ───
    query := ''
        SELECT MD5(DATA_TYPE || '''':'''' || IS_NULLABLE) AS COL_HASH
        FROM '' || DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA  = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME    = UPPER('''''' || TABLE_NAME  || '''''')
          AND COLUMN_NAME   = UPPER('''''' || COLUMN_NAME || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO live_col_hash := r.COL_HASH; END FOR;

    IF (live_col_hash != stored_col_hash OR stored_col_hash IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''STALE'',
            ''code'',    ''COLUMN_STRUCTURE_CHANGED'',
            ''message'', ''Column '' || fqn || '' structure has changed (type or nullability). Re-profile.'',
            ''view_id'', stored_view_id
        );
    END IF;

    -- ── All gates passed: column view is FRESH ────────────────────────
    RETURN OBJECT_CONSTRUCT(
        ''status'',       ''FRESH'',
        ''code'',         ''USE_CACHED'',
        ''message'',      ''Attribute view for '' || fqn || '' is current. No re-profiling needed.'',
        ''view_id'',      stored_view_id,
        ''generated_at'', stored_gen_at
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''UNEXPECTED_ERROR'',
            ''message'', SQLERRM
        );
END;
';

-- GET_CACHED_SEMANTIC_VIEW
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GET_CACHED_SEMANTIC_VIEW("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    query            VARCHAR;
    rs               RESULTSET;
    semantic_json    VARIANT;
    view_id_val      VARCHAR;
    gen_at_val       TIMESTAMP_NTZ;
    gen_by_val       VARCHAR;
    version_val      INTEGER;
    col_count_val    INTEGER;
BEGIN
    -- ── Fetch the ACTIVE semantic view from LATEST_TABLE_VIEWS ─────────
    -- LATEST_TABLE_VIEWS is a view over SEM_TABLE_VIEWS that returns only
    -- the most recent ACTIVE row per table (one row guaranteed by QUALIFY).
    query := ''
        SELECT
            VIEW_ID,
            VERSION,
            COLUMN_COUNT,
            GENERATED_AT,
            GENERATED_BY,
            SEMANTIC_VIEW
        FROM __STTM_METADATA_NAMESPACE__.LATEST_TABLE_VIEWS
        WHERE DATABASE_NAME = UPPER('''''' || DB_NAME     || '''''')
          AND SCHEMA_NAME   = UPPER('''''' || SCHEMA_NAME || '''''')
          AND TABLE_NAME    = UPPER('''''' || TABLE_NAME  || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO
        view_id_val   := r.VIEW_ID;
        version_val   := TRY_CAST(r.VERSION AS INTEGER);
        col_count_val := r.COLUMN_COUNT;
        gen_at_val    := r.GENERATED_AT;
        gen_by_val    := r.GENERATED_BY;
        semantic_json := r.SEMANTIC_VIEW;
    END FOR;

    -- ── NOT FOUND: no active cached view exists ─────────────────────────
    IF (view_id_val IS NULL OR semantic_json IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''NOT_FOUND'',
            ''message'', ''No active semantic view found in cache for '' ||
                       UPPER(DB_NAME) || ''.'' || UPPER(SCHEMA_NAME) || ''.'' || UPPER(TABLE_NAME) ||
                       ''. Run the full discovery pipeline and call save_semantic_view first.''
        );
    END IF;

    -- ── FOUND: return full cached payload ──────────────────────────────
    RETURN OBJECT_CONSTRUCT(
        ''status'',        ''OK'',
        ''source'',        ''CACHE'',
        ''view_id'',       view_id_val,
        ''version'',       version_val,
        ''column_count'',  col_count_val,
        ''generated_at'',  gen_at_val,
        ''generated_by'',  gen_by_val,
        ''semantic_view'', semantic_json
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''UNEXPECTED_ERROR'',
            ''message'', SQLERRM
        );
END;
';

-- SAVE_SEMANTIC_VIEW
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SAVE_SEMANTIC_VIEW("SEMANTIC_VIEW_JSON_STR" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    SEMANTIC_VIEW_JSON VARIANT;
    scope           VARCHAR;
    db_name         VARCHAR;
    schema_name     VARCHAR;
    table_name      VARCHAR;
    fqn             VARCHAR;
    col_count       INTEGER;
    row_count       INTEGER;
    new_view_id     VARCHAR;
    col_set_hash    VARCHAR;
    last_altered    TIMESTAMP_NTZ;
    next_version    INTEGER;
    query           VARCHAR;
    rs              RESULTSET;
BEGIN
    -- ── 0. Parse the String Payload into JSON ──────────────────────────
    BEGIN
        SEMANTIC_VIEW_JSON := PARSE_JSON(SEMANTIC_VIEW_JSON_STR);
    EXCEPTION WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''INVALID_JSON'',
            ''message'', ''Failed to parse JSON payload. Ensure it is a valid JSON string.''
        );
    END;

    -- ── 1. Parse and validate the payload envelope ─────────────────────
    scope       := UPPER(COALESCE(SEMANTIC_VIEW_JSON:scope::VARCHAR, ''''));
    db_name     := UPPER(COALESCE(SEMANTIC_VIEW_JSON:database::VARCHAR, ''''));
    schema_name := UPPER(COALESCE(SEMANTIC_VIEW_JSON:schema::VARCHAR, ''''));
    table_name  := UPPER(COALESCE(SEMANTIC_VIEW_JSON:table::VARCHAR, ''''));
    fqn         := db_name || ''.'' || schema_name || ''.'' || table_name;

    IF (scope != ''TABLE'') THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''UNSUPPORTED_SCOPE'',
            ''message'', ''SAVE_SEMANTIC_VIEW supports TABLE scope only. Got: '' || scope
        );
    END IF;

    IF (db_name = '''' OR schema_name = '''' OR table_name = '''') THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''INVALID_PAYLOAD'',
            ''message'', ''Payload must include non-empty database, schema, and table fields.''
        );
    END IF;

    -- ── 2. Count columns from attribute_semantic_model ─────────────────
    col_count := ARRAY_SIZE(SEMANTIC_VIEW_JSON:attribute_semantic_model);

    -- Best-effort ROW_COUNT from the first column''s data_quality block
    IF (col_count > 0) THEN
        row_count := SEMANTIC_VIEW_JSON:attribute_semantic_model[0]:data_quality:row_count::INTEGER;
    ELSE
        row_count := NULL;
    END IF;

    -- ── 3. Generate new VIEW_ID for this semantic generation event ──────
    new_view_id := UUID_STRING();

    -- ── 4. Fetch live COLUMN_SET_HASH from INFORMATION_SCHEMA ──────────
    query := ''
        SELECT MD5(LISTAGG(COLUMN_NAME || '''':'''' || DATA_TYPE || '''':'''' || IS_NULLABLE, ''''|'''')
               WITHIN GROUP (ORDER BY COLUMN_NAME)) AS COL_HASH
        FROM '' || db_name || ''.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = UPPER('''''' || schema_name || '''''')
          AND TABLE_NAME   = UPPER('''''' || table_name  || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO col_set_hash := r.COL_HASH; END FOR;

    -- ── 5. Fetch live LAST_ALTERED_TS from INFORMATION_SCHEMA ──────────
    query := ''
        SELECT LAST_ALTERED
        FROM '' || db_name || ''.INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = UPPER('''''' || schema_name || '''''')
          AND TABLE_NAME   = UPPER('''''' || table_name  || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO last_altered := r.LAST_ALTERED; END FOR;

    -- ── 6. Compute next VERSION number ──────────────────────────────────
    query := ''
        SELECT COALESCE(MAX(TRY_CAST(VERSION AS INTEGER)), 0) + 1 AS NEXT_VER
        FROM __STTM_METADATA_NAMESPACE__.SEM_TABLE_VIEWS
        WHERE DATABASE_NAME = UPPER('''''' || db_name    || '''''')
          AND SCHEMA_NAME   = UPPER('''''' || schema_name || '''''')
          AND TABLE_NAME    = UPPER('''''' || table_name  || '''''')
    '';
    rs := (EXECUTE IMMEDIATE :query);
    FOR r IN rs DO next_version := r.NEXT_VER::INTEGER; END FOR;
    IF (next_version IS NULL) THEN next_version := 1; END IF;

    -- ── 7. Supersede existing ACTIVE table view ─────────────────────────
    query := ''
        UPDATE __STTM_METADATA_NAMESPACE__.SEM_TABLE_VIEWS
        SET STATUS = ''''SUPERSEDED''''
        WHERE DATABASE_NAME = UPPER('''''' || db_name    || '''''')
          AND SCHEMA_NAME   = UPPER('''''' || schema_name || '''''')
          AND TABLE_NAME    = UPPER('''''' || table_name  || '''''')
          AND STATUS = ''''ACTIVE''''
    '';
    EXECUTE IMMEDIATE :query;

    -- ── 8. Insert new ACTIVE table view ─────────────────────────────────
    INSERT INTO __STTM_METADATA_NAMESPACE__.SEM_TABLE_VIEWS (
        VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, FQN,
        GENERATED_BY, STATUS, VERSION,
        ROW_COUNT, COLUMN_COUNT, COLUMN_SET_HASH, LAST_ALTERED_TS, SEMANTIC_VIEW
    )
    SELECT
        :new_view_id, :db_name, :schema_name, :table_name, :fqn,
        CURRENT_USER(), ''ACTIVE'', :next_version,
        :row_count, :col_count, :col_set_hash, :last_altered, :SEMANTIC_VIEW_JSON;

    -- ── 9. Supersede existing ACTIVE column views for this table ────────
    query := ''
        UPDATE __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS
        SET STATUS = ''''SUPERSEDED''''
        WHERE DATABASE_NAME = UPPER('''''' || db_name    || '''''')
          AND SCHEMA_NAME   = UPPER('''''' || schema_name || '''''')
          AND TABLE_NAME    = UPPER('''''' || table_name  || '''''')
          AND STATUS = ''''ACTIVE''''
    '';
    EXECUTE IMMEDIATE :query;

    -- ── 10. Bulk-insert new ACTIVE column views via FLATTEN ─────────────
    -- V3: COLUMN_DESCRIPTION extracted from attribute_semantic_model[i].description
    --     and written as a dedicated column. This enables REFRESH_COLUMN_SEARCH_INDEX
    --     to read descriptions directly (Priority 1 in description chain) without
    --     needing to parse ATTRIBUTE_VIEW JSON.
    INSERT INTO __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS (
        VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, FQN,
        TABLE_VIEW_ID, GENERATED_BY, STATUS, DATA_TYPE, COLUMN_HASH,
        COLUMN_DESCRIPTION,
        ATTRIBUTE_VIEW
    )
    SELECT
        UUID_STRING(),
        :db_name,
        :schema_name,
        :table_name,
        UPPER(f.value:name::VARCHAR),
        :fqn || ''.'' || UPPER(f.value:name::VARCHAR),
        :new_view_id,
        CURRENT_USER(),
        ''ACTIVE'',
        f.value:data_type::VARCHAR,
        MD5(f.value:data_type::VARCHAR || '':'' ||
            IFF(f.value:nullable::BOOLEAN, ''YES'', ''NO'')),
        NULLIF(TRIM(f.value:description::VARCHAR), ''''),  -- V3: dedicated description column
        f.value
    FROM TABLE(FLATTEN(input => :SEMANTIC_VIEW_JSON, path => ''attribute_semantic_model'')) f;

    -- ── 11. Return success metadata ──────────────────────────────────────
    RETURN OBJECT_CONSTRUCT(
        ''status'',          ''OK'',
        ''fqn'',             fqn,
        ''table_view_id'',   new_view_id,
        ''version'',         next_version,
        ''columns_saved'',   col_count,
        ''column_set_hash'', col_set_hash
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''SAVE_FAILED'',
            ''message'', SQLERRM
        );
END;
';

-- CREATE_SV_WITHOUT_AGENT
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.CREATE_SV_WITHOUT_AGENT("P_DB_NAME" VARCHAR, "P_SCHEMA_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run'
EXECUTE AS CALLER
AS '
import json
from datetime import datetime

def run(session, p_db_name, p_schema_name):
    start_time = datetime.now()

    # Step 1: Get all tables in the schema
    tables_result = session.sql(
        f"CALL __STTM_METADATA_NAMESPACE__.LIST_TABLES(''{p_db_name}'', ''{p_schema_name}'')"
    ).collect()
    raw = json.loads(tables_result[0][0]) if tables_result else {}
    fqn_list = raw.get(''tables'', [])

    # Extract just the table name from FQN
    table_names = []
    for fqn in fqn_list:
        parts = fqn.split(''.'')
        table_names.append(parts[-1] if parts else fqn)

    # Step 2: Check staleness for ALL tables (fast - no LLM)
    fresh_tables = []
    stale_tables = []

    for table_name in table_names:
        staleness_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.CHECK_TABLE_STALENESS(''{p_db_name}'', ''{p_schema_name}'', ''{table_name}'')"
        ).collect()
        staleness = json.loads(staleness_result[0][0]) if staleness_result else {}
        status = staleness.get(''status'', ''MISSING'')

        if status == ''FRESH'':
            fresh_tables.append(table_name)
        else:
            stale_tables.append(table_name)

    # Step 3: FIRE GENERATE_SV_DIRECT IN PARALLEL for all stale tables
    async_handles = []
    for table_name in stale_tables:
        sql = f"CALL __STTM_METADATA_NAMESPACE__.GENERATE_SV_DIRECT_V2_TEST(''{p_db_name}'', ''{p_schema_name}'', ''{table_name}'')"
        async_job = session.sql(sql).collect_nowait()
        async_handles.append({''job'': async_job, ''table_name'': table_name})

    # Step 4: Wait for all parallel executions to finish
    success_tables = []
    error_tables = []
    timings = {}

    for handle in async_handles:
        try:
            result_rows = handle[''job''].result()
            result = json.loads(result_rows[0][0]) if result_rows else {}
            success_tables.append(handle[''table_name''])
            timings[handle[''table_name'']] = result.get(''total_seconds'', 0)
        except Exception as e:
            error_tables.append({''table'': handle[''table_name''], ''error'': str(e)})

    end_time = datetime.now()
    total_seconds = (end_time - start_time).total_seconds()

    return {
        ''database'': p_db_name,
        ''schema'': p_schema_name,
        ''total_tables'': len(table_names),
        ''fresh_skipped'': fresh_tables,
        ''generated_parallel'': success_tables,
        ''errors'': error_tables,
        ''per_table_seconds'': timings,
        ''total_seconds'': total_seconds,
        ''mode'': ''PARALLEL_DIRECT''
    }
';

-- CREATE_SCHEMA_SEMANTIC_VIEWS
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.CREATE_SCHEMA_SEMANTIC_VIEWS("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "FORCE_RECREATE" BOOLEAN DEFAULT TRUE)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    -- Result tracking
    total_tables   INTEGER DEFAULT 0;
    succeeded_cnt  INTEGER DEFAULT 0;
    skipped_cnt    INTEGER DEFAULT 0;
    failed_cnt     INTEGER DEFAULT 0;
    results_arr    ARRAY   DEFAULT ARRAY_CONSTRUCT();

    -- Per-table variables
    tbl_name_val   VARCHAR;
    tbl_result     VARIANT;
    tbl_status_val VARCHAR;

    -- Query helpers
    query_str      VARCHAR;
    rs_var         RESULTSET;

BEGIN
    -- ══════════════════════════════════════════════════════════════════
    -- STEP 1: Fetch all tables in the given schema that have semantic
    --         JSON stored in LATEST_TABLE_VIEWS
    -- ══════════════════════════════════════════════════════════════════
    query_str := ''
        SELECT TABLE_NAME
        FROM   __STTM_METADATA_NAMESPACE__.LATEST_TABLE_VIEWS
        WHERE  DATABASE_NAME = UPPER('''''' || :DB_NAME    || '''''')
          AND  SCHEMA_NAME   = UPPER('''''' || :SCHEMA_NAME || '''''')
        ORDER  BY TABLE_NAME'';

    rs_var := (EXECUTE IMMEDIATE :query_str);

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 2: Iterate and call CREATE_TABLE_SEMANTIC_VIEW per table
    -- ══════════════════════════════════════════════════════════════════
    FOR r IN rs_var DO
        tbl_name_val := r.TABLE_NAME::VARCHAR;
        total_tables := total_tables + 1;

        -- Call the single-table procedure
        tbl_result := (
            CALL __STTM_METADATA_NAMESPACE__.CREATE_TABLE_SEMANTIC_VIEW(
                :DB_NAME, :SCHEMA_NAME, :tbl_name_val, :FORCE_RECREATE
            )
        );

        tbl_status_val := COALESCE(tbl_result:status::VARCHAR, ''ERROR'');

        -- Accumulate counts
        IF (tbl_status_val = ''OK'') THEN
            succeeded_cnt := succeeded_cnt + 1;
        ELSEIF (tbl_status_val = ''SKIPPED'') THEN
            skipped_cnt := skipped_cnt + 1;
        ELSE
            failed_cnt := failed_cnt + 1;
        END IF;

        -- Collect per-table result summary
        results_arr := ARRAY_APPEND(results_arr, OBJECT_CONSTRUCT(
            ''table'',  tbl_name_val,
            ''status'', tbl_status_val,
            ''detail'', tbl_result
        ));

    END FOR;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 3: Return summary
    -- ══════════════════════════════════════════════════════════════════
    RETURN OBJECT_CONSTRUCT(
        ''status'',        ''COMPLETED'',
        ''schema'',        UPPER(:DB_NAME) || ''.'' || UPPER(:SCHEMA_NAME),
        ''total_tables'',  total_tables,
        ''succeeded'',     succeeded_cnt,
        ''skipped'',       skipped_cnt,
        ''failed'',        failed_cnt,
        ''results'',       results_arr
    );

EXCEPTION WHEN OTHER THEN
    RETURN OBJECT_CONSTRUCT(
        ''status'',  ''ERROR'',
        ''code'',    ''SCHEMA_ITERATOR_FAILED'',
        ''schema'',  UPPER(:DB_NAME) || ''.'' || UPPER(:SCHEMA_NAME),
        ''message'', SQLERRM
    );
END;
';

-- REFRESH_COLUMN_SEARCH_INDEX
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.REFRESH_COLUMN_SEARCH_INDEX("P_DB_NAME" VARCHAR, "P_SCHEMA_NAME" VARCHAR, "P_TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    fqn                     VARCHAR;
    query                   VARCHAR;
    rs                      RESULTSET;
    rs2                     RESULTSET;

    -- Table loop
    current_table           VARCHAR;
    tables_refreshed        INTEGER DEFAULT 0;
    tables_skipped_fresh    INTEGER DEFAULT 0;

    -- Gate 0 (7-day TTL per table)
    gate0_skip              BOOLEAN DEFAULT FALSE;

    -- Per-column state
    col_name                VARCHAR;
    data_type               VARCHAR;
    is_nullable_flag        VARCHAR;
    col_description         VARCHAR;
    desc_source             VARCHAR;
    search_text             VARCHAR;

    -- GET_TABLE_STATS results (per table)
    stats_resp              VARIANT;
    stats_col               VARIANT;
    col_stats_map           VARIANT;
    tbl_row_count           INTEGER DEFAULT 0;
    col_len_map             VARIANT;
    col_samp_map            VARIANT;

    -- Per-column stats (from GET_TABLE_STATS map lookup)
    s_distinct              INTEGER DEFAULT 0;
    s_null_count            INTEGER DEFAULT 0;
    s_min_val               VARCHAR DEFAULT NULL;
    s_max_val               VARCHAR DEFAULT NULL;
    s_distinct_ratio        NUMBER  DEFAULT 0;
    s_null_ratio            NUMBER  DEFAULT 0;
    s_null_pct              NUMBER  DEFAULT 0;
    s_min_len               INTEGER DEFAULT 0;
    s_max_len               INTEGER DEFAULT 0;
    s_is_key                BOOLEAN DEFAULT FALSE;

    -- LLM batch (per table)
    llm_needed_cols         ARRAY   DEFAULT ARRAY_CONSTRUCT();
    llm_prompt              VARCHAR;
    llm_raw                 VARIANT;
    llm_desc_map            VARIANT;
    llm_signal              VARCHAR;
    llm_cardinality         VARCHAR;
    llm_text                VARCHAR;
    llm_start               INTEGER DEFAULT 0;
    llm_end_pos             INTEGER DEFAULT 0;

    -- PATTERN_CLASS computation
    sample_arr              VARIANT;
    p_class                 VARCHAR DEFAULT ''ALPHANUMERIC'';
    sample_count            INTEGER DEFAULT 0;
    numeric_count           INTEGER DEFAULT 0;
    alpha_count             INTEGER DEFAULT 0;
    formatted_count         INTEGER DEFAULT 0;

    -- Per-table counters
    cols_refreshed          INTEGER DEFAULT 0;
    llm_generated_count     INTEGER DEFAULT 0;
    fallback_count          INTEGER DEFAULT 0;
    sem_views_hit_count     INTEGER DEFAULT 0;
    table_error             VARCHAR;

    -- Schema-level totals
    total_cols_refreshed    INTEGER DEFAULT 0;
    total_llm_generated     INTEGER DEFAULT 0;
    total_fallback          INTEGER DEFAULT 0;
    total_sem_views_hits    INTEGER DEFAULT 0;

    -- Error tracking (loud failure per table)
    error_list              ARRAY   DEFAULT ARRAY_CONSTRUCT();

BEGIN

    -- ── Build table list ──────────────────────────────────────────────
    IF (P_TABLE_NAME IS NULL) THEN
        query := ''
            SELECT TABLE_NAME
            FROM '' || P_DB_NAME || ''.INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = UPPER('''''' || P_SCHEMA_NAME || '''''')
              AND TABLE_TYPE   = ''''BASE TABLE''''
            ORDER BY TABLE_NAME'';
    ELSE
        query := ''SELECT '''''' || P_TABLE_NAME || '''''' AS TABLE_NAME'';
    END IF;

    rs := (EXECUTE IMMEDIATE :query);

    -- ══════════════════════════════════════════════════════════════════
    -- OUTER LOOP: process each table
    -- ══════════════════════════════════════════════════════════════════
    FOR tbl IN rs DO
        current_table := tbl.TABLE_NAME;
        fqn           := P_DB_NAME || ''.'' || P_SCHEMA_NAME || ''.'' || current_table;

        -- ══ GATE 0: 7-day TTL check (per table) ══════════════════════
        -- If ALL columns for this table have been refreshed within 7 days,
        -- skip it. If any column is missing or stale, re-seed the whole table.
        gate0_skip := FALSE;
        BEGIN
            DECLARE
                g0_query VARCHAR;
                g0_rs    RESULTSET;
                g0_cnt   INTEGER DEFAULT 0;
                g0_fresh INTEGER DEFAULT 0;
            BEGIN
                g0_query := ''
                    SELECT
                        COUNT(*)                                           AS total_cols,
                        SUM(IFF(LAST_REFRESHED >= DATEADD(''''day'''', -7,
                            CURRENT_TIMESTAMP()), 1, 0))                  AS fresh_cols
                    FROM __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE
                    WHERE DB_NAME     = UPPER('''''' || P_DB_NAME    || '''''')
                      AND SCHEMA_NAME = UPPER('''''' || P_SCHEMA_NAME || '''''')
                      AND TABLE_NAME  = UPPER('''''' || current_table || '''''')'';
                g0_rs := (EXECUTE IMMEDIATE :g0_query);
                FOR g IN g0_rs DO
                    g0_cnt   := COALESCE(g.total_cols, 0);
                    g0_fresh := COALESCE(g.fresh_cols, 0);
                END FOR;
                -- Skip only if cache has rows AND all are within 7 days
                IF (g0_cnt > 0 AND g0_cnt = g0_fresh) THEN
                    gate0_skip := TRUE;
                END IF;
            EXCEPTION WHEN OTHER THEN
                gate0_skip := FALSE;  -- on error, proceed with seeding
            END;
        END;

        IF (gate0_skip) THEN
            tables_skipped_fresh := tables_skipped_fresh + 1;
        ELSE
            -- Reset per-table state
            cols_refreshed      := 0;
            llm_generated_count := 0;
            fallback_count      := 0;
            sem_views_hit_count := 0;
            table_error         := NULL;

            -- ══ STEP 1: GET_TABLE_STATS ══════════════════════════════
            -- One call returns stats for ALL columns. Replaces N per-column scans.
            stats_resp    := NULL;
            tbl_row_count := 0;
            col_stats_map := OBJECT_CONSTRUCT();

            BEGIN
                DECLARE sr_rs RESULTSET;
                BEGIN
                    sr_rs := (EXECUTE IMMEDIATE
                        ''CALL __STTM_METADATA_NAMESPACE__.GET_TABLE_STATS(''''''
                        || P_DB_NAME || '''''', '''''' || P_SCHEMA_NAME || '''''', '''''' || current_table || '''''')'');
                    FOR sr IN sr_rs DO
                        stats_resp := sr.GET_TABLE_STATS;
                    END FOR;

                    IF (stats_resp IS NOT NULL AND stats_resp:code::VARCHAR = ''SUCCESS'') THEN
                        tbl_row_count := COALESCE(stats_resp:row_count::INTEGER, 0);

                        -- Build col_name → stats lookup map.
                        -- KEY FIX v3: UPPER() on both key build and lookup to prevent
                        -- case-mismatch producing all-zero stats (root cause of the bug).
                        DECLARE
                            i_s  INTEGER DEFAULT 0;
                            n_s  INTEGER DEFAULT 0;
                            ckey VARCHAR;
                        BEGIN
                            n_s := ARRAY_SIZE(stats_resp:columns);
                            WHILE (i_s < n_s) DO
                                ckey := UPPER(stats_resp:columns[i_s]:column_name::VARCHAR);
                                col_stats_map := OBJECT_INSERT(col_stats_map, ckey,
                                    stats_resp:columns[i_s], TRUE);
                                i_s := i_s + 1;
                            END WHILE;
                        END;
                    END IF;
                EXCEPTION WHEN OTHER THEN
                    stats_resp    := NULL;
                    tbl_row_count := 0;
                    col_stats_map := OBJECT_CONSTRUCT();
                    -- Loud: record error but continue (partial results still useful)
                    table_error := ''GET_TABLE_STATS failed: '' || SQLERRM;
                END;
            END;

            -- ══ STEP 2: Get all columns for this table ════════════════
            query := ''
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                FROM '' || P_DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = UPPER('''''' || P_SCHEMA_NAME || '''''')
                  AND TABLE_NAME   = UPPER('''''' || current_table  || '''''')
                ORDER BY ORDINAL_POSITION'';
            rs2 := (EXECUTE IMMEDIATE :query);

            -- ══ STEP 3: First pass — identify which columns need LLM ═
            -- Collect columns that have no SEM_COLUMN_VIEWS description.
            -- Only structural signals will be sent to LLM (D5 compliant).
            llm_needed_cols := ARRAY_CONSTRUCT();

            FOR c IN rs2 DO
                col_name         := c.COLUMN_NAME;
                data_type        := c.DATA_TYPE;
                is_nullable_flag := c.IS_NULLABLE;

                -- Check SEM_COLUMN_VIEWS.COLUMN_DESCRIPTION
                -- FIX v3: direct column query (column now exists after file 03c)
                col_description := NULL;
                BEGIN
                    DECLARE
                        dq VARCHAR;
                        dr RESULTSET;
                    BEGIN
                        dq := ''
                            SELECT COLUMN_DESCRIPTION
                            FROM __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS
                            WHERE DATABASE_NAME = UPPER('''''' || P_DB_NAME    || '''''')
                              AND SCHEMA_NAME   = UPPER('''''' || P_SCHEMA_NAME || '''''')
                              AND TABLE_NAME    = UPPER('''''' || current_table || '''''')
                              AND COLUMN_NAME   = UPPER('''''' || col_name      || '''''')
                              AND STATUS = ''''ACTIVE''''
                              AND COLUMN_DESCRIPTION IS NOT NULL
                            LIMIT 1'';
                        dr := (EXECUTE IMMEDIATE :dq);
                        FOR d IN dr DO
                            IF (d.COLUMN_DESCRIPTION IS NOT NULL AND
                                LENGTH(TRIM(d.COLUMN_DESCRIPTION)) > 0) THEN
                                col_description := TRIM(d.COLUMN_DESCRIPTION);
                            END IF;
                        END FOR;
                    EXCEPTION WHEN OTHER THEN
                        col_description := NULL;
                    END;
                END;

                -- Only queue for LLM if no SEM_COLUMN_VIEWS description
                IF (col_description IS NULL) THEN
                    -- Derive cardinality signal from stats (D5: no raw values)
                    stats_col := col_stats_map[UPPER(col_name)];
                    IF (stats_col IS NOT NULL AND tbl_row_count > 0) THEN
                        s_distinct       := COALESCE(stats_col:distinct_count::INTEGER, 0);
                        s_null_count     := COALESCE(stats_col:null_count::INTEGER, 0);
                        s_distinct_ratio := IFF(tbl_row_count > 0,
                                               s_distinct::NUMBER / tbl_row_count::NUMBER, 0);
                        s_null_ratio     := IFF(tbl_row_count > 0,
                                               s_null_count::NUMBER / tbl_row_count::NUMBER, 0);
                        s_is_key         := (s_distinct = tbl_row_count AND s_null_count = 0);

                        llm_cardinality := CASE
                            WHEN s_distinct_ratio >= 0.95 THEN ''HIGH''
                            WHEN s_distinct_ratio >= 0.10 THEN ''MEDIUM''
                            ELSE ''LOW''
                        END;

                        llm_signal := CASE
                            WHEN s_is_key
                                 THEN ''unique non-null identifier (distinct_count equals row_count)''
                            WHEN s_distinct_ratio >= 0.95 AND s_null_ratio = 0
                                 THEN ''non-nullable, high cardinality — likely a key or identifier''
                            WHEN s_distinct_ratio >= 0.95
                                 THEN ''high cardinality — likely a key or identifier''
                            WHEN s_distinct_ratio >= 0.10 AND s_null_ratio = 0
                                 THEN ''non-nullable, '' || s_distinct::VARCHAR
                                      || '' distinct values — categorical or descriptive''
                            WHEN s_distinct_ratio >= 0.10
                                 THEN s_distinct::VARCHAR
                                      || '' distinct values — categorical or descriptive''
                            WHEN s_null_ratio > 0.50
                                 THEN ''optional or sparsely populated, ''
                                      || s_distinct::VARCHAR || '' distinct values''
                            ELSE
                                 ''non-nullable, '' || s_distinct::VARCHAR
                                 || '' distinct values — likely a flag, code, or measure''
                        END;
                    ELSE
                        llm_cardinality := ''UNKNOWN'';
                        llm_signal      := ''statistical profile not available'';
                    END IF;

                    llm_needed_cols := ARRAY_APPEND(llm_needed_cols,
                        OBJECT_CONSTRUCT(
                            ''column'',      col_name,
                            ''data_type'',   data_type,
                            ''nullable'',    IFF(is_nullable_flag = ''YES'', TRUE, FALSE),
                            ''cardinality'', llm_cardinality,
                            ''signal'',      llm_signal
                        )
                    );
                END IF;

            END FOR;  -- first pass

            -- ══ STEP 4: LLM batch description generation ══════════════
            -- One Cortex Complete call covers ALL uncovered columns for this table.
            -- D5: Only structural signals sent — no raw values, no sample data.
            llm_desc_map := OBJECT_CONSTRUCT();

            IF (ARRAY_SIZE(llm_needed_cols) > 0) THEN
                BEGIN
                    llm_prompt :=
                        ''You are a data engineer documenting a Snowflake schema.'' || CHR(10) ||
                        ''Generate a 1-sentence business description for each column below.'' || CHR(10) ||
                        ''Use ONLY the structural signals provided. Do NOT invent values, dates, or examples.'' || CHR(10) ||
                        ''Respond with a valid JSON array ONLY — no text before or after the array.'' || CHR(10) ||
                        CHR(10) ||
                        ''Table: '' || current_table || '' (schema: '' || P_SCHEMA_NAME || '')'' || CHR(10) ||
                        ''Columns:'' || CHR(10) ||
                        TO_VARCHAR(llm_needed_cols) || CHR(10) ||
                        CHR(10) ||
                        ''Required format (copy exactly):'' || CHR(10) ||
                        ''[{"column": "COLUMN_NAME", "description": "One sentence ending with a period."}, ...]'';

                    -- SNOWFLAKE.CORTEX.COMPLETE returns a STRING (VARCHAR)
                    llm_raw := SNOWFLAKE.CORTEX.COMPLETE(''mixtral-8x7b'', llm_prompt)::VARCHAR;

                    -- FIX v3: Robust JSON extraction using TRY_PARSE_JSON
                    -- TRY_PARSE_JSON returns NULL on bad JSON rather than throwing.
                    -- UPPER() on column keys for consistent lookup.
                    DECLARE
                        llm_arr       VARIANT;
                        i_llm         INTEGER DEFAULT 0;
                        n_llm         INTEGER DEFAULT 0;
                        llm_col_key   VARCHAR;
                        llm_col_desc  VARCHAR;
                    BEGIN
                        llm_text    := TRIM(llm_raw);
                        llm_start   := CHARINDEX(''['', llm_text);
                        -- Find last '']'': position from end in reversed string
                        llm_end_pos := LENGTH(llm_text) - CHARINDEX('']'', REVERSE(llm_text)) + 1;

                        IF (llm_start > 0 AND llm_end_pos >= llm_start) THEN
                            llm_text := SUBSTR(llm_text, llm_start,
                                               llm_end_pos - llm_start + 1);
                            -- TRY_PARSE_JSON: NULL on bad JSON, no exception
                            llm_arr := TRY_PARSE_JSON(llm_text);
                        ELSE
                            llm_arr := NULL;
                        END IF;

                        IF (llm_arr IS NOT NULL) THEN
                            n_llm := ARRAY_SIZE(llm_arr);
                            WHILE (i_llm < n_llm) DO
                                -- UPPER() so lookup matches col_stats_map key convention
                                llm_col_key  := UPPER(llm_arr[i_llm]:column::VARCHAR);
                                llm_col_desc := llm_arr[i_llm]:description::VARCHAR;
                                IF (llm_col_key IS NOT NULL AND llm_col_desc IS NOT NULL) THEN
                                    llm_desc_map := OBJECT_INSERT(llm_desc_map,
                                        llm_col_key, llm_col_desc, TRUE);
                                END IF;
                                i_llm := i_llm + 1;
                            END WHILE;
                        END IF;
                    EXCEPTION WHEN OTHER THEN
                        -- JSON processing failed — llm_desc_map stays empty
                        -- All columns queued for LLM will fall to column-name fallback
                        llm_desc_map := OBJECT_CONSTRUCT();
                    END;

                EXCEPTION WHEN OTHER THEN
                    -- Cortex Complete unavailable — record error loudly
                    llm_desc_map := OBJECT_CONSTRUCT();
                    table_error  := COALESCE(table_error || '' | '', '''') ||
                                    ''Cortex LLM failed for table '' || current_table
                                    || '': '' || SQLERRM;
                END;
            END IF;

            -- ══ STEP 4.5: Batch Data Extraction ══════════════════════
            -- Dynamically construct two single queries for Lengths and Samples
            BEGIN
                DECLARE
                    rs_batch RESULTSET;
                    len_q VARCHAR;
                    samp_q VARCHAR;
                    first BOOLEAN DEFAULT TRUE;
                BEGIN
                    rs_batch := (EXECUTE IMMEDIATE ''
                        SELECT COLUMN_NAME
                        FROM '' || P_DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA = UPPER('''''' || P_SCHEMA_NAME || '''''')
                          AND TABLE_NAME   = UPPER('''''' || current_table  || '''''')
                        ORDER BY ORDINAL_POSITION'');

                    len_q := ''SELECT OBJECT_CONSTRUCT(*) AS len_map FROM (SELECT '';
                    samp_q := ''SELECT OBJECT_CONSTRUCT(*) AS samp_map FROM (SELECT '';

                    FOR c IN rs_batch DO
                        IF (NOT first) THEN 
                            len_q := len_q || '', ''; 
                            samp_q := samp_q || '', ''; 
                        END IF;
                        -- Lengths extraction
                        len_q := len_q || ''COALESCE(MIN(LENGTH("'' || c.COLUMN_NAME || ''"::VARCHAR)), 0) AS "min_'' || UPPER(c.COLUMN_NAME) || ''", '';
                        len_q := len_q || ''COALESCE(MAX(LENGTH("'' || c.COLUMN_NAME || ''"::VARCHAR)), 0) AS "max_'' || UPPER(c.COLUMN_NAME) || ''"'';
                        
                        -- Samples extraction
                        samp_q := samp_q || ''ARRAY_SLICE(ARRAY_AGG(DISTINCT "'' || c.COLUMN_NAME || ''"::VARCHAR), 0, 10) AS "'' || UPPER(c.COLUMN_NAME) || ''"'';
                        first := FALSE;
                    END FOR;
                    len_q := len_q || '' FROM '' || fqn || '')'';
                    samp_q := samp_q || '' FROM (SELECT * FROM '' || fqn || '' SAMPLE (1000 ROWS)))'';
                    
                    -- Execute len_q
                    BEGIN
                        DECLARE len_r RESULTSET := (EXECUTE IMMEDIATE :len_q);
                        BEGIN FOR lr IN len_r DO col_len_map := lr.len_map; END FOR; END;
                    EXCEPTION WHEN OTHER THEN col_len_map := OBJECT_CONSTRUCT(); END;

                    -- Execute samp_q
                    BEGIN
                        DECLARE samp_r RESULTSET := (EXECUTE IMMEDIATE :samp_q);
                        BEGIN FOR sr2 IN samp_r DO col_samp_map := sr2.samp_map; END FOR; END;
                    EXCEPTION WHEN OTHER THEN col_samp_map := OBJECT_CONSTRUCT(); END;
                END;
            END;

            -- ══ STEP 5: Second pass — build SEARCH_TEXT, MERGE into tables ══
            query := ''
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                FROM '' || P_DB_NAME || ''.INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = UPPER('''''' || P_SCHEMA_NAME || '''''')
                  AND TABLE_NAME   = UPPER('''''' || current_table  || '''''')
                ORDER BY ORDINAL_POSITION'';
            rs2 := (EXECUTE IMMEDIATE :query);

            FOR c IN rs2 DO
                col_name         := c.COLUMN_NAME;
                data_type        := c.DATA_TYPE;
                is_nullable_flag := c.IS_NULLABLE;

                -- ── 5a. Resolve description (3-tier priority chain) ───
                col_description := NULL;
                desc_source     := ''COLUMN_NAME_FALLBACK'';

                -- Priority 1: SEM_COLUMN_VIEWS.COLUMN_DESCRIPTION
                -- FIX v3: reads the dedicated column (not ATTRIBUTE_VIEW JSON)
                BEGIN
                    DECLARE
                        dq2 VARCHAR;
                        dr2 RESULTSET;
                    BEGIN
                        dq2 := ''
                            SELECT COLUMN_DESCRIPTION
                            FROM __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS
                            WHERE DATABASE_NAME = UPPER('''''' || P_DB_NAME    || '''''')
                              AND SCHEMA_NAME   = UPPER('''''' || P_SCHEMA_NAME || '''''')
                              AND TABLE_NAME    = UPPER('''''' || current_table || '''''')
                              AND COLUMN_NAME   = UPPER('''''' || col_name      || '''''')
                              AND STATUS = ''''ACTIVE''''
                              AND COLUMN_DESCRIPTION IS NOT NULL
                            LIMIT 1'';
                        dr2 := (EXECUTE IMMEDIATE :dq2);
                        FOR d IN dr2 DO
                            IF (d.COLUMN_DESCRIPTION IS NOT NULL AND
                                LENGTH(TRIM(d.COLUMN_DESCRIPTION)) > 0) THEN
                                col_description     := TRIM(d.COLUMN_DESCRIPTION);
                                desc_source         := ''SEM_COLUMN_VIEWS'';
                                sem_views_hit_count := sem_views_hit_count + 1;
                            END IF;
                        END FOR;
                    EXCEPTION WHEN OTHER THEN
                        col_description := NULL;
                    END;
                END;

                -- Priority 2: LLM-generated description
                IF (col_description IS NULL) THEN
                    DECLARE llm_lkp VARCHAR;
                    BEGIN
                        llm_lkp := llm_desc_map[UPPER(col_name)]::VARCHAR;
                        IF (llm_lkp IS NOT NULL AND LENGTH(TRIM(llm_lkp)) > 0) THEN
                            col_description     := TRIM(llm_lkp);
                            desc_source         := ''LLM_GENERATED'';
                            llm_generated_count := llm_generated_count + 1;
                        END IF;
                    END;
                END IF;

                -- Priority 3: Column name fallback (absolute last resort)
                IF (col_description IS NULL) THEN
                    col_description := col_name;
                    desc_source     := ''COLUMN_NAME_FALLBACK'';
                    fallback_count  := fallback_count + 1;
                END IF;

                -- ── 5b. Build SEARCH_TEXT ─────────────────────────────
                search_text := current_table || ''.'' || col_name
                               || '' ('' || data_type || '')''
                               || CHR(10) || CHR(10)
                               || col_description;

                -- ── 5c. MERGE into COLUMN_SEMANTIC_INDEX ─────────────
                MERGE INTO __STTM_METADATA_NAMESPACE__.COLUMN_SEMANTIC_INDEX AS tgt
                USING (SELECT
                    :P_DB_NAME        AS db_n,
                    :P_SCHEMA_NAME    AS sch_n,
                    :current_table    AS tbl_n,
                    :col_name         AS col_n,
                    :data_type        AS dt,
                    :search_text      AS st,
                    :desc_source      AS ds
                ) AS src
                ON  tgt.DB_NAME     = src.db_n
                AND tgt.SCHEMA_NAME = src.sch_n
                AND tgt.TABLE_NAME  = src.tbl_n
                AND tgt.COLUMN_NAME = src.col_n
                WHEN MATCHED THEN UPDATE SET
                    DATA_TYPE          = src.dt,
                    SEARCH_TEXT        = src.st,
                    DESCRIPTION_SOURCE = src.ds,
                    LAST_UPDATED       = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT (
                    DB_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME,
                    DATA_TYPE, SEARCH_TEXT, DESCRIPTION_SOURCE, LAST_UPDATED)
                VALUES (
                    src.db_n, src.sch_n, src.tbl_n, src.col_n,
                    src.dt,   src.st,   src.ds,    CURRENT_TIMESTAMP());

                -- ── 5d. Derive profile fields from GET_TABLE_STATS ───
                -- FIX v3: UPPER(col_name) lookup matches UPPER() key in col_stats_map
                s_distinct    := 0; s_null_count := 0; s_min_val := NULL;
                s_max_val     := NULL; s_distinct_ratio := 0; s_null_ratio := 0;
                s_null_pct    := 0; s_min_len := 0; s_max_len := 0;
                s_is_key      := FALSE;

                stats_col := col_stats_map[UPPER(col_name)];
                IF (stats_col IS NOT NULL) THEN
                    s_distinct   := COALESCE(stats_col:distinct_count::INTEGER, 0);
                    s_null_count := COALESCE(stats_col:null_count::INTEGER, 0);
                    s_min_val    := stats_col:min::VARCHAR;
                    s_max_val    := stats_col:max::VARCHAR;

                    IF (tbl_row_count > 0) THEN
                        s_distinct_ratio := ROUND(
                            s_distinct::NUMBER / tbl_row_count::NUMBER, 6);
                        s_null_ratio     := ROUND(
                            s_null_count::NUMBER / tbl_row_count::NUMBER, 6);
                        s_null_pct       := ROUND(
                            s_null_count::NUMBER * 100.0 / tbl_row_count::NUMBER, 2);
                    END IF;

                    s_is_key := (s_distinct = tbl_row_count
                                 AND s_null_count = 0
                                 AND tbl_row_count > 0);
                END IF;

                -- ── 5e/5f. MIN/MAX LENGTH & SAMPLE_VALUES ─────────────
                -- Retrieved from batched queries run in Step 4.5
                s_min_len  := COALESCE(col_len_map[''min_'' || UPPER(col_name)]::INTEGER, 0);
                s_max_len  := COALESCE(col_len_map[''max_'' || UPPER(col_name)]::INTEGER, 0);
                sample_arr := col_samp_map[UPPER(col_name)];

                -- ── 5g. PATTERN_CLASS via SQL regex (no LLM) ─────────
                -- NUMERIC    → all match ^[0-9.+\\-Ee]+$
                -- ALPHA      → all match ^[A-Za-z\\s]+$
                -- FORMATTED  → all match ^[A-Z0-9]{15,20}$ (UUID-like)
                -- ALPHANUMERIC → mixed
                -- EMPTY      → no non-null samples
                p_class        := ''ALPHANUMERIC'';
                sample_count   := 0;
                numeric_count  := 0;
                alpha_count    := 0;
                formatted_count := 0;

                IF (sample_arr IS NOT NULL AND ARRAY_SIZE(sample_arr) > 0) THEN
                    BEGIN
                        DECLARE
                            pc_q VARCHAR;
                            pc_r RESULTSET;
                        BEGIN
                            pc_q := ''
                                SELECT
                                    COUNT(*)                                                                       AS cnt,
                                    SUM(IFF(REGEXP_LIKE(f.value::VARCHAR, ''''^[0-9.+\\\\-Ee]+$''''),    1, 0))        AS num_cnt,
                                    SUM(IFF(REGEXP_LIKE(f.value::VARCHAR, ''''^[A-Za-z\\\\s]+$''''),     1, 0))        AS alpha_cnt,
                                    SUM(IFF(REGEXP_LIKE(f.value::VARCHAR, ''''^[A-Z0-9]{15,20}$''''), 1, 0))        AS fmt_cnt
                                FROM TABLE(FLATTEN(input => PARSE_JSON('''''' || TO_VARCHAR(sample_arr) || ''''''))) f'';
                            pc_r := (EXECUTE IMMEDIATE :pc_q);
                            FOR pr IN pc_r DO
                                sample_count    := pr.cnt;
                                numeric_count   := pr.num_cnt;
                                alpha_count     := pr.alpha_cnt;
                                formatted_count := pr.fmt_cnt;
                            END FOR;
                        EXCEPTION WHEN OTHER THEN
                            sample_count := 0;
                        END;
                    END;

                    p_class := CASE
                        WHEN sample_count    = 0            THEN ''EMPTY''
                        WHEN numeric_count   = sample_count THEN ''NUMERIC''
                        WHEN alpha_count     = sample_count THEN ''ALPHA''
                        WHEN formatted_count = sample_count THEN ''FORMATTED''
                        ELSE                                     ''ALPHANUMERIC''
                    END;
                ELSE
                    p_class := ''EMPTY'';
                END IF;

                -- ── 5h. MERGE into COLUMN_PROFILE_CACHE ──────────────
                MERGE INTO __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE AS tgt
                USING (SELECT
                    :P_DB_NAME        AS db_n,
                    :P_SCHEMA_NAME    AS sch_n,
                    :current_table    AS tbl_n,
                    :col_name         AS col_n,
                    :data_type        AS dt,
                    :s_distinct       AS dc,
                    :s_null_pct       AS np,
                    :s_min_len        AS mnl,
                    :s_max_len        AS mxl,
                    :sample_arr       AS sv,
                    :p_class          AS pc,
                    :tbl_row_count    AS rc,
                    :s_null_count     AS nc,
                    :s_distinct_ratio AS dr,
                    :s_null_ratio     AS nr,
                    :s_is_key         AS ik
                ) AS src
                ON  tgt.DB_NAME     = src.db_n
                AND tgt.SCHEMA_NAME = src.sch_n
                AND tgt.TABLE_NAME  = src.tbl_n
                AND tgt.COLUMN_NAME = src.col_n
                WHEN MATCHED THEN UPDATE SET
                    DATA_TYPE       = src.dt,
                    DISTINCT_COUNT  = src.dc,
                    NULL_PCT        = src.np,
                    MIN_LENGTH      = src.mnl,
                    MAX_LENGTH      = src.mxl,
                    SAMPLE_VALUES   = src.sv,
                    PATTERN_CLASS   = src.pc,
                    ROW_COUNT       = src.rc,
                    NULL_COUNT      = src.nc,
                    DISTINCT_RATIO  = src.dr,
                    NULL_RATIO      = src.nr,
                    IS_LIKELY_KEY   = src.ik,
                    LAST_REFRESHED  = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT (
                    DB_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, DATA_TYPE,
                    DISTINCT_COUNT, NULL_PCT, MIN_LENGTH, MAX_LENGTH,
                    SAMPLE_VALUES, PATTERN_CLASS,
                    ROW_COUNT, NULL_COUNT, DISTINCT_RATIO, NULL_RATIO, IS_LIKELY_KEY,
                    LAST_REFRESHED)
                VALUES (
                    src.db_n, src.sch_n, src.tbl_n, src.col_n, src.dt,
                    src.dc,   src.np,   src.mnl,   src.mxl,
                    src.sv,   src.pc,
                    src.rc,   src.nc,   src.dr,    src.nr,   src.ik,
                    CURRENT_TIMESTAMP());

                cols_refreshed := cols_refreshed + 1;
            END FOR;  -- second pass (column loop)

            -- Accumulate schema-level counters
            tables_refreshed     := tables_refreshed     + 1;
            total_cols_refreshed := total_cols_refreshed + cols_refreshed;
            total_llm_generated  := total_llm_generated  + llm_generated_count;
            total_fallback       := total_fallback        + fallback_count;
            total_sem_views_hits := total_sem_views_hits  + sem_views_hit_count;

            -- Record table-level error if any (loud failure)
            IF (table_error IS NOT NULL) THEN
                error_list := ARRAY_APPEND(error_list,
                    OBJECT_CONSTRUCT(''table'', current_table, ''error'', table_error));
            END IF;

        END IF;  -- END IF (NOT gate0_skip)

    END FOR;  -- table loop

    -- ── Return result ─────────────────────────────────────────────────
    IF (P_TABLE_NAME IS NOT NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',                     IFF(ARRAY_SIZE(error_list) = 0, ''OK'', ''PARTIAL''),
            ''table'',                      P_DB_NAME || ''.'' || P_SCHEMA_NAME || ''.'' || P_TABLE_NAME,
            ''skipped_fresh'',              tables_skipped_fresh > 0,
            ''columns_refreshed'',          total_cols_refreshed,
            ''sem_column_views_hits'',      total_sem_views_hits,
            ''llm_descriptions_generated'', total_llm_generated,
            ''column_name_fallbacks'',      total_fallback,
            ''errors'',                     error_list,
            ''refreshed_at'',               CURRENT_TIMESTAMP()::VARCHAR
        );
    ELSE
        RETURN OBJECT_CONSTRUCT(
            ''status'',                     IFF(ARRAY_SIZE(error_list) = 0, ''OK'', ''PARTIAL''),
            ''schema'',                     P_DB_NAME || ''.'' || P_SCHEMA_NAME,
            ''tables_refreshed'',           tables_refreshed,
            ''tables_skipped_fresh'',       tables_skipped_fresh,
            ''columns_refreshed'',          total_cols_refreshed,
            ''sem_column_views_hits'',      total_sem_views_hits,
            ''llm_descriptions_generated'', total_llm_generated,
            ''column_name_fallbacks'',      total_fallback,
            ''errors'',                     error_list,
            ''refreshed_at'',               CURRENT_TIMESTAMP()::VARCHAR
        );
    END IF;

    -- NOTE: No top-level EXCEPTION WHEN OTHER catch-all.
    -- Errors at table level are caught and recorded in errors[].
    -- Catastrophic errors (e.g. INFORMATION_SCHEMA unreachable) will
    -- propagate to the caller as a native SQL exception — this is
    -- intentional (loud failure, not silent swallowing).

END;
';

-- GENERATE_SV_DIRECT_V2_TEST
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.GENERATE_SV_DIRECT_V2_TEST("P_DB_NAME" VARCHAR, "P_SCHEMA_NAME" VARCHAR, "P_TABLE_NAME" VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run'
EXECUTE AS CALLER
AS '
import json
import traceback
from datetime import datetime

def build_precise_type(col):
    base = col.get(''data_type'', ''VARCHAR'')
    precision = col.get(''precision'')
    scale = col.get(''scale'')
    if base == ''NUMBER'' and precision is not None:
        if scale and scale > 0:
            return f"NUMBER({precision},{scale})"
        else:
            return f"NUMBER({precision},0)"
    if base in (''TEXT'', ''VARCHAR''):
        return ''VARCHAR(16777216)''
    return base

def try_numeric(val):
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return val
    if isinstance(val, str):
        try:
            if ''.'' in val:
                return float(val)
            else:
                return int(val)
        except (ValueError, TypeError):
            return val
    return val

def build_value_profile(profile_response, range_stats_from_table):
    value_profile = {}
    if not isinstance(profile_response, dict):
        if range_stats_from_table:
            value_profile[''range_stats''] = range_stats_from_table
        return value_profile
    values = profile_response.get(''values'', [])
    value_type = profile_response.get(''value_type'', '''')
    if values:
        if value_type == ''UNIQUE'':
            value_profile[''unique_values''] = values
        else:
            value_profile[''sample_values''] = values[:10] if len(values) > 10 else values
    if range_stats_from_table:
        value_profile[''range_stats''] = range_stats_from_table
    else:
        profile_range = profile_response.get(''range_stats'', {})
        if profile_range:
            value_profile[''range_stats''] = {k: try_numeric(v) for k, v in profile_range.items() if v is not None}
    return value_profile

def deduplicate_notes(llm_notes, flagged_notes):
    if not flagged_notes:
        return llm_notes
    merged = list(llm_notes) if llm_notes else []
    for fn in flagged_notes:
        is_covered = False
        for existing in merged:
            fn_lower = fn.lower()
            existing_lower = existing.lower()
            table_refs = []
            if '' from '' in fn_lower:
                parts = fn_lower.split('' from '')
                if len(parts) > 1:
                    table_part = parts[1].split(''.'')[0].split('' '')[0]
                    table_refs.append(table_part)
            if '' -> '' in fn_lower:
                parts = fn_lower.split('' -> '')
                if len(parts) > 1:
                    table_part = parts[1].split(''.'')[0].split('' '')[0]
                    table_refs.append(table_part)
            for ref in table_refs:
                if ref and len(ref) > 3 and ref in existing_lower:
                    if any(word in existing_lower for word in [''invalid'', ''excluded'', ''rejected'', ''flagged'']):
                        is_covered = True
                        break
            if is_covered:
                break
        if not is_covered:
            merged.append(fn)
    return merged

def run(session, p_db_name, p_schema_name, p_table_name):
    start_time = datetime.now()
    current_step = ''init''

    try:
        # Step 1: CHECK_TABLE_STALENESS
        current_step = ''check_table_staleness''
        staleness_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.CHECK_TABLE_STALENESS(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'')"
        ).collect()
        staleness = json.loads(staleness_result[0][0])
        status = staleness.get(''status'', ''MISSING'')

        if status == ''FRESH'':
            return {
                ''method'': ''DIRECT_PROCEDURE_V2_FINAL'',
                ''table'': p_table_name,
                ''action'': ''CACHED'',
                ''total_seconds'': (datetime.now() - start_time).total_seconds()
            }

        # Step 2: LIST_COLUMNS
        current_step = ''list_columns''
        cols_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.LIST_COLUMNS(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'')"
        ).collect()
        columns_raw = json.loads(cols_result[0][0])
        columns = columns_raw.get(''columns'', [])
        col_names = [c.get(''column'', c.get(''name'', '''')) for c in columns]

        precise_types = {}
        for col in columns:
            cname = col.get(''column'', col.get(''name'', ''''))
            precise_types[cname] = build_precise_type(col)

        # Step 3: GET_TABLE_DDL
        current_step = ''get_table_ddl''
        ddl_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.GET_TABLE_DDL(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'')"
        ).collect()
        ddl_data = json.loads(ddl_result[0][0])

        # Step 4: GET_TABLE_RELATIONSHIPS
        current_step = ''get_table_relationships''
        rels_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.GET_TABLE_RELATIONSHIPS(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'', FALSE)"
        ).collect()
        rels_data = json.loads(rels_result[0][0])

        # Step 5: GET_TABLE_STATS
        current_step = ''get_table_stats''
        stats_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.GET_TABLE_STATS(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'')"
        ).collect()
        stats_data = json.loads(stats_result[0][0])

        # Step 6: GET_SAMPLE_ROWS
        current_step = ''get_sample_rows''
        sample_result = session.sql(
            f"CALL __STTM_METADATA_NAMESPACE__.GET_SAMPLE_ROWS(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'', 5)"
        ).collect()
        sample_data = json.loads(sample_result[0][0])

        # Step 7: GET_COLUMN_PROFILE for ALL columns
        current_step = ''column_profiles''
        column_profiles = {}
        for col_name in col_names:
            try:
                profile_result = session.sql(
                    f"CALL __STTM_METADATA_NAMESPACE__.GET_COLUMN_PROFILE(''{p_db_name}'', ''{p_schema_name}'', ''{p_table_name}'', ''{col_name}'')"
                ).collect()
                column_profiles[col_name] = json.loads(profile_result[0][0])
            except Exception:
                column_profiles[col_name] = {}

        # Build range_stats_map from GET_TABLE_STATS
        stats_columns = stats_data.get(''columns'', stats_data.get(''stats'', []))
        range_stats_map = {}
        stats_by_col = {}

        if isinstance(stats_columns, list):
            for cs in stats_columns:
                cname = cs.get(''column_name'', cs.get(''column'', cs.get(''name'', '''')))
                stats_by_col[cname] = cs
                dtype = cs.get(''data_type'', '''').upper()
                if any(t in dtype for t in [''NUMBER'', ''FLOAT'', ''INT'', ''DECIMAL'', ''NUMERIC'']):
                    rs = {
                        ''min'': try_numeric(cs.get(''min'')),
                        ''max'': try_numeric(cs.get(''max'')),
                        ''mean'': try_numeric(cs.get(''avg'', cs.get(''mean''))),
                        ''stddev'': try_numeric(cs.get(''stddev'')),
                        ''p25'': try_numeric(cs.get(''p25'', cs.get(''percentile_25''))),
                        ''p50'': try_numeric(cs.get(''p50'', cs.get(''median'', cs.get(''percentile_50'')))),
                        ''p75'': try_numeric(cs.get(''p75'', cs.get(''percentile_75'')))
                    }
                    range_stats_map[cname] = {k: v for k, v in rs.items() if v is not None}
                elif any(t in dtype for t in [''DATE'', ''TIMESTAMP'']):
                    rs = {''min'': cs.get(''min''), ''max'': cs.get(''max''), ''span_days'': cs.get(''span_days'')}
                    range_stats_map[cname] = {k: v for k, v in rs.items() if v is not None}
                elif any(t in dtype for t in [''VARCHAR'', ''TEXT'', ''CHAR'', ''STRING'']):
                    rs = {
                        ''min_len'': try_numeric(cs.get(''min_len'', cs.get(''min_length''))),
                        ''max_len'': try_numeric(cs.get(''max_len'', cs.get(''max_length'')))
                    }
                    range_stats_map[cname] = {k: v for k, v in rs.items() if v is not None}
        elif isinstance(stats_columns, dict):
            stats_by_col = stats_columns

        # Relationship validation
        outgoing = rels_data.get(''outgoing'', [])
        incoming = rels_data.get(''incoming'', [])
        validated_outgoing = []
        validated_incoming = []
        flagged_notes = []

        for rel in outgoing:
            confidence = rel.get(''confidence'', '''')
            semantic_review = rel.get(''semantic_review'', {})
            verdict = semantic_review.get(''verdict'', ''VALID'')
            if confidence == ''FLAGGED'' or verdict == ''INVALID'':
                fk_col = rel.get(''column_mappings'', [{}])[0].get(''fk_column'', ''?'')
                ref_table = rel.get(''table'', ''?'')
                ref_col = rel.get(''column_mappings'', [{}])[0].get(''pk_column'', ''?'')
                reviewed_by = semantic_review.get(''reviewed_by'', ''LLM review'')
                flagged_notes.append(f"Outgoing FK {fk_col} -> {ref_table}.{ref_col} flagged as INVALID by {reviewed_by}. Excluded.")
            else:
                validated_outgoing.append(rel)

        for rel in incoming:
            confidence = rel.get(''confidence'', '''')
            semantic_review = rel.get(''semantic_review'', {})
            verdict = semantic_review.get(''verdict'', ''VALID'')
            reviewed_by = semantic_review.get(''reviewed_by'', '''')
            if confidence == ''FLAGGED'' or verdict == ''INVALID'':
                fk_col = rel.get(''column_mappings'', [{}])[0].get(''fk_column'', ''?'')
                fk_table = rel.get(''table'', ''?'')
                if reviewed_by == ''SQL_CROSS_CHECK'':
                    flagged_notes.append(f"Incoming FK from {fk_table}.{fk_col} excluded: direction captured in outgoing[] (SQL cross-check).")
                else:
                    flagged_notes.append(f"Incoming FK from {fk_table}.{fk_col} flagged by LLM review as INVALID. Excluded from incoming[].")
            else:
                validated_incoming.append(rel)

        # Promote value_overlap_pct to top level of each relationship so
        # CREATE_TABLE_SEMANTIC_VIEW can read it at rel_entry:value_overlap_pct
        for rel in validated_outgoing:
            evidence = rel.get(''relationship_evidence'', {})
            if ''value_overlap_pct'' in evidence and ''value_overlap_pct'' not in rel:
                rel[''value_overlap_pct''] = evidence[''value_overlap_pct'']
        for rel in validated_incoming:
            evidence = rel.get(''relationship_evidence'', {})
            if ''value_overlap_pct'' in evidence and ''value_overlap_pct'' not in rel:
                rel[''value_overlap_pct''] = evidence[''value_overlap_pct'']

        # Step 8: LLM call with OPTIMIZED V4 PROMPT
        current_step = ''llm_cortex_complete''

        ddl_str = ddl_data.get(''ddl'', '''')
        rels_out_str = json.dumps(validated_outgoing, indent=2)
        rels_in_str = json.dumps(validated_incoming, indent=2)
        pk_str = json.dumps(rels_data.get(''pk_detection'', {}), indent=2)
        stats_str = json.dumps(stats_data, indent=2)
        sample_str = json.dumps(sample_data, indent=2)
        profiles_str = json.dumps(column_profiles, indent=2)

        if len(stats_str) > 12000:
            stats_str = stats_str[:12000] + ''\\n... (truncated)''
        if len(profiles_str) > 12000:
            profiles_str = profiles_str[:12000] + ''\\n... (truncated)''
        if len(sample_str) > 5000:
            sample_str = sample_str[:5000] + ''\\n... (truncated)''

        col_meta_lines = []
        for col in columns:
            cname = col.get(''column'', '''')
            ptype = precise_types.get(cname, ''UNKNOWN'')
            nullable = col.get(''nullable'', ''YES'')
            col_meta_lines.append(f"  - {cname}: {ptype} (nullable={nullable})")
        col_meta_str = ''\\n''.join(col_meta_lines)

        llm_prompt = f"""You are generating a semantic view for table {p_db_name}.{p_schema_name}.{p_table_name}.
Your output must be production-quality metadata that enables downstream consumers (analysts, Cortex Agents, semantic layers) to understand and use this table confidently.

TABLE DDL:
{ddl_str}

COLUMN METADATA (precise types from catalog):
{col_meta_str}

VALIDATED OUTGOING RELATIONSHIPS (this table references these):
{rels_out_str}

VALIDATED INCOMING RELATIONSHIPS (these tables reference this one):
{rels_in_str}

PK DETECTION (from data scan):
{pk_str}

TABLE STATS (per-column statistics):
{stats_str}

SAMPLE ROWS (for PII/format detection - DO NOT include raw PII values in output):
{sample_str}

COLUMN PROFILES (value distributions, sample/unique values):
{profiles_str}

FLAGGED/REJECTED RELATIONSHIPS (document in table_semantic_notes):
{json.dumps(flagged_notes)}

---

Generate a JSON object with EXACTLY these keys:
1. "table_description": 2-3 sentences about what this table stores and its business role.
2. "domain_summary": 1-2 sentences a business analyst can quote.
3. "table_semantic_notes": Array of strings with table-level observations (PK method, grain, rejected relationships, referential integrity findings).
4. "columns": object keyed by column name, each value has:
   "description": "One sentence: what this column stores.",
   "business_meaning": "Business purpose, joins, role in hierarchies. No statistics.",
   "semantic_role": "primary_key|foreign_key|metric|dimension|identifier|attribute",
   "semantic_notes": ["2-4 evidence-based observations from metadata."]

RULES:
- No statistics in description or business_meaning (those go in data_quality programmatically).
- No recommendations, indexing advice, or architecture suggestions.
- Reference actual relationship table names in business_meaning.
- semantic_notes: only observations supported by the metadata provided.

Return ONLY valid JSON. No markdown, no explanation."""

        # Use messages format with max_tokens to prevent output truncation
        messages = [{''role'': ''user'', ''content'': llm_prompt}]
        messages_json = json.dumps(messages)
        llm_sql = "SELECT SNOWFLAKE.CORTEX.COMPLETE(''claude-sonnet-4-5'', PARSE_JSON(?), {''max_tokens'': 64000}):choices[0]:messages::VARCHAR AS RESPONSE"
        llm_result = session.sql(llm_sql, params=[messages_json]).collect()
        llm_response = llm_result[0][''RESPONSE'']

        try:
            clean = llm_response.strip()
            if clean.startswith(''```''):
                clean = clean.split(''\\n'', 1)[1]
                clean = clean.rsplit(''```'', 1)[0]
            descriptions = json.loads(clean)
        except Exception:
            descriptions = {
                ''table_description'': '''',
                ''domain_summary'': '''',
                ''table_semantic_notes'': [],
                ''columns'': {}
            }

        # Step 9: Assemble final JSON
        current_step = ''assembly''

        pk_detection = rels_data.get(''pk_detection'', {})
        pk_confirmed = pk_detection.get(''pk_confirmed'', False)
        confirmed_pk = pk_detection.get(''confirmed_pk'', [])
        primary_keys = [p.get(''column'', '''') for p in confirmed_pk] if pk_confirmed else []

        attribute_semantic_model = []

        for col in columns:
            col_name = col.get(''column'', col.get(''name'', ''''))
            col_desc = descriptions.get(''columns'', {}).get(col_name, {})

            col_stats = {}
            if isinstance(stats_columns, list):
                col_stats = next((s for s in stats_columns if s.get(''column_name'', s.get(''column'', s.get(''name'', ''''))) == col_name), {})
            elif isinstance(stats_columns, dict):
                col_stats = stats_columns.get(col_name, {})

            constraints = []
            if col_name in primary_keys:
                constraints.append(''PRIMARY_KEY'')
            if col.get(''nullable'', ''YES'') == ''NO'':
                constraints.append(''NOT_NULL'')
            for rel in validated_outgoing:
                for mapping in rel.get(''column_mappings'', []):
                    if mapping.get(''fk_column'', '''') == col_name:
                        constraints.append({
                            ''type'': ''FOREIGN_KEY'',
                            ''confidence'': rel.get(''confidence'', ''MEDIUM''),
                            ''references'': {''table'': rel.get(''table'', ''''), ''column'': mapping.get(''pk_column'', '''')}
                        })

            cp = column_profiles.get(col_name, {})
            range_stats_from_table = range_stats_map.get(col_name, {})
            value_profile = build_value_profile(cp, range_stats_from_table)

            row_count = stats_data.get(''row_count'', 0)
            null_count = col_stats.get(''null_count'', 0)
            distinct_count = col_stats.get(''distinct_count'', 0)
            null_pct = round((null_count / row_count * 100), 2) if row_count > 0 else 0.0

            data_type = precise_types.get(col_name, col.get(''data_type'', ''VARCHAR''))

            entry = {
                ''name'': col_name,
                ''data_type'': data_type,
                ''nullable'': col.get(''nullable'', ''YES'') == ''YES'',
                ''constraints'': constraints,
                ''description'': col_desc.get(''description'', f''Column {col_name}''),
                ''business_meaning'': col_desc.get(''business_meaning'', ''''),
                ''semantic_role'': col_desc.get(''semantic_role'', ''attribute''),
                ''data_quality'': {
                    ''row_count'': row_count,
                    ''null_count'': null_count,
                    ''null_pct'': null_pct,
                    ''distinct_count'': distinct_count
                },
                ''value_profile'': value_profile,
                ''semantic_notes'': col_desc.get(''semantic_notes'', [])
            }
            attribute_semantic_model.append(entry)

        attributes_summary = []
        for attr in attribute_semantic_model:
            attributes_summary.append({
                ''name'': attr[''name''],
                ''data_type'': attr[''data_type''],
                ''constraints'': attr[''constraints''],
                ''summary'': attr[''description'']
            })

        llm_table_notes = descriptions.get(''table_semantic_notes'', [])
        table_semantic_notes = deduplicate_notes(llm_table_notes, flagged_notes)

        pk_note = None
        if not pk_confirmed:
            pk_note = "Primary key could not be confirmed. Composite PK suspected. Human validation required."
        elif confirmed_pk and confirmed_pk[0].get(''confidence'', '''') == ''MEDIUM'':
            pk_note = "PK inferred from data - not formally constrained."

        final_json = {
            ''scope'': ''TABLE'',
            ''database'': p_db_name,
            ''schema'': p_schema_name,
            ''table'': p_table_name,
            ''phase2_enabled'': rels_data.get(''phase2_enabled'', True),
            ''phase2_skip_reason'': rels_data.get(''phase2_skip_reason'', None),
            ''pk_detection'': pk_detection,
            ''semantic_model'': {
                ''description'': descriptions.get(''table_description'', ''''),
                ''domain_summary'': descriptions.get(''domain_summary'', ''''),
                ''relationships'': {
                    ''outgoing'': validated_outgoing,
                    ''incoming'': validated_incoming,
                    ''pk_note'': pk_note
                },
                ''attributes'': attributes_summary,
                ''semantic_notes'': table_semantic_notes
            },
            ''attribute_semantic_model'': attribute_semantic_model
        }

        # Step 10: SAVE_SEMANTIC_VIEW
        current_step = ''save_semantic_view''
        save_payload = json.dumps(final_json, ensure_ascii=True)
        save_result = session.sql(
            "CALL __STTM_METADATA_NAMESPACE__.SAVE_SEMANTIC_VIEW(?)", params=[save_payload]
        ).collect()
        save_response = json.loads(save_result[0][0])

        total_seconds = (datetime.now() - start_time).total_seconds()

        return {
            ''method'': ''DIRECT_PROCEDURE_V2_FINAL'',
            ''table'': p_table_name,
            ''status'': save_response.get(''status'', ''UNKNOWN''),
            ''version'': save_response.get(''version'', None),
            ''columns_saved'': save_response.get(''columns_saved'', None),
            ''total_seconds'': total_seconds,
            ''staleness_status'': status
        }

    except Exception as e:
        return {
            ''table'': p_table_name,
            ''status'': ''FAILED'',
            ''failed_at_step'': current_step,
            ''error'': str(e)[:500],
            ''total_seconds'': (datetime.now() - start_time).total_seconds()
        }
';

-- CREATE_TABLE_SEMANTIC_VIEW
CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.CREATE_TABLE_SEMANTIC_VIEW("DB_NAME" VARCHAR, "SCHEMA_NAME" VARCHAR, "TABLE_NAME" VARCHAR, "FORCE_RECREATE" BOOLEAN DEFAULT TRUE)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    -- ── Raw JSON from LATEST_TABLE_VIEWS ──────────────────────────────
    sv_json            VARIANT;
    table_view_id_val  VARCHAR;

    -- ── JSON sub-blocks ───────────────────────────────────────────────
    attr_model_arr     VARIANT;
    sem_model_block    VARIANT;
    pk_det_block       VARIANT;
    outgoing_arr       VARIANT;
    phase2_en          BOOLEAN DEFAULT FALSE;

    -- ── View identity ─────────────────────────────────────────────────
    view_name_val      VARCHAR;
    primary_alias_val  VARCHAR;
    target_fqn_val     VARCHAR;
    source_fqn_val     VARCHAR;
    ca_table_name      VARCHAR;

    -- ── PK Detection ──────────────────────────────────────────────────
    pk_conf            BOOLEAN DEFAULT FALSE;
    pk_clause_str      VARCHAR DEFAULT '''';
    confirmed_pk_arr   VARIANT;
    fuzzy_pk_block     VARIANT;
    comp_cands_arr     VARIANT;
    pk_col_list_str    VARCHAR DEFAULT '''';
    comp_pk_str        VARCHAR DEFAULT '''';
    pk_note_str        VARCHAR DEFAULT '''';

    -- ── Counters and flags ────────────────────────────────────────────
    facts_cnt          INTEGER DEFAULT 0;
    dims_cnt           INTEGER DEFAULT 0;
    joins_cnt          INTEGER DEFAULT 0;
    metrics_cnt        INTEGER DEFAULT 0;
    has_low_conf_flag  BOOLEAN DEFAULT FALSE;
    has_flagged_flag   BOOLEAN DEFAULT FALSE;
    row_cnt_val        INTEGER DEFAULT 0;

    -- ── DDL building blocks ───────────────────────────────────────────
    primary_tbl_comment  VARCHAR DEFAULT '''';
    flagged_warn_str     VARCHAR DEFAULT '''';
    related_tbls_str     VARCHAR DEFAULT '''';
    relationships_str    VARCHAR DEFAULT '''';
    facts_ddl_str        VARCHAR DEFAULT '''';
    dims_ddl_str         VARCHAR DEFAULT '''';
    metrics_ddl_str      VARCHAR DEFAULT '''';
    table_level_comment  VARCHAR DEFAULT '''';
    ca_dims_str          VARCHAR DEFAULT '''';
    ca_facts_str         VARCHAR DEFAULT '''';
    ca_timedims_str      VARCHAR DEFAULT '''';
    ca_json_str          VARCHAR DEFAULT '''';
    full_ddl             VARCHAR DEFAULT '''';
    ca_yaml_str          VARCHAR DEFAULT '''';

    -- ── First-item flags for comma handling ───────────────────────────
    facts_first_flag       BOOLEAN DEFAULT TRUE;
    dims_first_flag        BOOLEAN DEFAULT TRUE;
    ca_dims_first_flag     BOOLEAN DEFAULT TRUE;
    ca_facts_first_flag    BOOLEAN DEFAULT TRUE;
    ca_time_first_flag     BOOLEAN DEFAULT TRUE;
    join_cond_first_flag   BOOLEAN DEFAULT TRUE;

    -- ── Loop counters ─────────────────────────────────────────────────

    -- ── Attribute-level variables ─────────────────────────────────────
    attr_entry_v       VARIANT;
    col_name_val       VARCHAR;
    col_role_val       VARCHAR;
    col_type_val       VARCHAR;
    col_desc_val       VARCHAR;
    col_biz_val        VARCHAR;
    col_comment_str    VARCHAR DEFAULT '''';
    col_is_time_flag   BOOLEAN DEFAULT FALSE;
    null_pct_val       NUMBER  DEFAULT 0;
    unique_vals_arr    VARIANT;
    notes_arr_v        VARIANT;
    note_val           VARCHAR;

    -- ── Constraint-level variables ────────────────────────────────────
    constraint_arr_v   VARIANT;
    constraint_item_v  VARIANT;
    constraint_type_v  VARCHAR;
    fk_ref_table_v     VARCHAR;
    fk_ref_col_v       VARCHAR;
    fk_ref_conf_v      VARCHAR;

    -- ── Relationship-level variables ──────────────────────────────────
    rel_entry_v        VARIANT;
    rel_schema_val     VARCHAR;
    rel_table_val      VARCHAR;
    rel_conf_val       VARCHAR;
    rel_type_str       VARCHAR;
    rel_method_val     VARCHAR;
    rel_overlap_val    NUMBER  DEFAULT 0;
    rel_review_block   VARIANT;
    rel_alias_str      VARCHAR;
    rel_fqn_str        VARCHAR;
    col_maps_arr_v     VARIANT;
    col_map_item_v     VARIANT;
    fk_col_val         VARCHAR;
    pk_col_val         VARCHAR;
    join_cond_str      VARCHAR DEFAULT '''';
    rel_comment_str    VARCHAR DEFAULT '''';
    has_mismatch_flag  BOOLEAN DEFAULT FALSE;
    tbl_entry_str      VARCHAR DEFAULT '''';
    fk_list_str        VARCHAR DEFAULT '''';
    pk_list_str        VARCHAR DEFAULT '''';
    rel_name_val       VARCHAR;
    rel_first_flag     BOOLEAN DEFAULT TRUE;

    -- ── SEM_NATIVE_VIEWS bookkeeping ──────────────────────────────────
    new_native_id_val  VARCHAR;
    query_str          VARCHAR;
    rs_var             RESULTSET;
    existing_cnt       INTEGER DEFAULT 0;

BEGIN

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 0: Guard — check FORCE_RECREATE vs existing ACTIVE view
    -- NOTE: We intentionally filter only for STATUS = ''ACTIVE''.
    -- If a previous attempt FAILED or is PENDING, we want to ignore it 
    -- and attempt to recreate the view automatically.
    -- ══════════════════════════════════════════════════════════════════
    IF (NOT FORCE_RECREATE) THEN
        query_str := ''
            SELECT COUNT(*) AS CNT
            FROM   __STTM_METADATA_NAMESPACE__.SEM_NATIVE_VIEWS
            WHERE  DATABASE_NAME = UPPER(?)
              AND  SCHEMA_NAME   = UPPER(?)
              AND  TABLE_NAME    = UPPER(?)
              AND  STATUS        = ''''ACTIVE'''''';
        rs_var := (EXECUTE IMMEDIATE :query_str USING (DB_NAME, SCHEMA_NAME, TABLE_NAME));
        FOR r IN rs_var DO
            existing_cnt := r.CNT::INTEGER;
        END FOR;

        IF (existing_cnt > 0) THEN
            view_name_val  := ''SV_'' || UPPER(SCHEMA_NAME) || ''_'' || UPPER(TABLE_NAME);
            target_fqn_val := ''__STTM_METADATA_NAMESPACE__.'' || view_name_val;
            RETURN OBJECT_CONSTRUCT(
                ''status'',     ''SKIPPED'',
                ''view_name'',  view_name_val,
                ''target_fqn'', target_fqn_val,
                ''reason'',     ''Active native view already exists. Pass FORCE_RECREATE=TRUE to overwrite.''
            );
        END IF;
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 1: Read semantic JSON from LATEST_TABLE_VIEWS
    -- ══════════════════════════════════════════════════════════════════
    query_str := ''
        SELECT SEMANTIC_VIEW, VIEW_ID
        FROM   __STTM_METADATA_NAMESPACE__.LATEST_TABLE_VIEWS
        WHERE  DATABASE_NAME = UPPER(?)
          AND  SCHEMA_NAME   = UPPER(?)
          AND  TABLE_NAME    = UPPER(?)
        LIMIT  1'';
    rs_var := (EXECUTE IMMEDIATE :query_str USING (DB_NAME, SCHEMA_NAME, TABLE_NAME));
    FOR r IN rs_var DO
        sv_json           := r.SEMANTIC_VIEW;
        table_view_id_val := r.VIEW_ID::VARCHAR;
    END FOR;

    IF (sv_json IS NULL) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',  ''ERROR'',
            ''code'',    ''NO_SEMANTIC_VIEW'',
            ''message'', ''No active semantic view JSON found in LATEST_TABLE_VIEWS for [''
                       || UPPER(DB_NAME) || ''.'' || UPPER(SCHEMA_NAME) || ''.'' || UPPER(TABLE_NAME)
                       || '']. Run the semantic model agent pipeline for this table first.''
        );
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 2: Parse key JSON blocks
    -- ══════════════════════════════════════════════════════════════════
    attr_model_arr  := sv_json:attribute_semantic_model;
    sem_model_block := sv_json:semantic_model;
    pk_det_block    := sv_json:pk_detection;
    outgoing_arr    := sv_json:semantic_model:relationships:outgoing;
    phase2_en       := COALESCE(sv_json:phase2_enabled::BOOLEAN, FALSE);

    -- Best-effort row count from first attribute data_quality
    IF (attr_model_arr IS NOT NULL AND ARRAY_SIZE(attr_model_arr) > 0) THEN
        row_cnt_val := COALESCE(attr_model_arr[0]:data_quality:row_count::INTEGER, 0);
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 3: Derive view name and aliases
    -- ══════════════════════════════════════════════════════════════════
    view_name_val     := ''SV_'' || UPPER(SCHEMA_NAME) || ''_'' || UPPER(TABLE_NAME);
    primary_alias_val := UPPER(SCHEMA_NAME) || ''_'' || UPPER(TABLE_NAME);
    target_fqn_val    := ''__STTM_METADATA_NAMESPACE__.'' || view_name_val;
    source_fqn_val    := UPPER(DB_NAME) || ''.'' || UPPER(SCHEMA_NAME) || ''.'' || UPPER(TABLE_NAME);
    ca_table_name     := LOWER(primary_alias_val);

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 4: Determine PK clause
    --   Handles: single PK, composite PK candidates, fuzzy PK,
    --            pk_confirmed=false (no clause emitted)
    -- ══════════════════════════════════════════════════════════════════
    pk_conf          := COALESCE(pk_det_block:pk_confirmed::BOOLEAN, FALSE);
    confirmed_pk_arr := pk_det_block:confirmed_pk;
    fuzzy_pk_block   := pk_det_block:fuzzy_pk;
    comp_cands_arr   := pk_det_block:composite_pk_candidates;
    pk_note_str      := COALESCE(sem_model_block:relationships:pk_note::VARCHAR, '''');

    IF (pk_conf AND confirmed_pk_arr IS NOT NULL AND ARRAY_SIZE(confirmed_pk_arr) > 0) THEN
        pk_col_list_str := '''';
        FOR i_idx IN 0 TO ARRAY_SIZE(confirmed_pk_arr) - 1 DO
            IF (i_idx > 0) THEN
                pk_col_list_str := pk_col_list_str || '', '';
            END IF;
            pk_col_list_str := pk_col_list_str
                            || COALESCE(confirmed_pk_arr[i_idx]:column::VARCHAR, '''');
        END FOR;
        IF (pk_col_list_str != '''') THEN
            pk_clause_str := ''primary key ('' || pk_col_list_str || '')'';
        END IF;
    ELSE
        -- pk_confirmed = false: build composite candidate list for comment warning
        IF (comp_cands_arr IS NOT NULL AND ARRAY_SIZE(comp_cands_arr) > 0) THEN
            FOR i_idx IN 0 TO ARRAY_SIZE(comp_cands_arr) - 1 DO
                IF (i_idx > 0) THEN comp_pk_str := comp_pk_str || '', ''; END IF;
                comp_pk_str := comp_pk_str
                            || COALESCE(comp_cands_arr[i_idx]:column::VARCHAR, '''');
            END FOR;
        END IF;
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 5: First pass on outgoing[] — collect FLAGGED warnings
    -- ══════════════════════════════════════════════════════════════════
    flagged_warn_str := '''';
    IF (outgoing_arr IS NOT NULL AND ARRAY_SIZE(outgoing_arr) > 0) THEN
        FOR i_idx IN 0 TO ARRAY_SIZE(outgoing_arr) - 1 DO
            rel_entry_v  := outgoing_arr[i_idx];
            rel_conf_val := COALESCE(rel_entry_v:confidence::VARCHAR, '''');

            IF (rel_conf_val = ''FLAGGED'') THEN
                has_flagged_flag := TRUE;
                rel_table_val    := COALESCE(rel_entry_v:table::VARCHAR, ''UNKNOWN'');
                rel_review_block := rel_entry_v:semantic_review;

                flagged_warn_str := flagged_warn_str
                    || '' | EXCLUDED (FLAGGED): Relationship to '' || rel_table_val
                    || '' was rejected'';
                IF (rel_review_block IS NOT NULL) THEN
                    flagged_warn_str := flagged_warn_str
                        || '' by LLM (reviewed_by: ''
                        || COALESCE(rel_review_block:reviewed_by::VARCHAR, ''unknown'')
                        || '', verdict: INVALID)'';
                END IF;
                flagged_warn_str := flagged_warn_str || ''. Manual verification required.'';
            END IF;
        END FOR;
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 6: Build primary table comment
    --   Contains: description, domain_summary, row_count, phase2 status,
    --             pk_note, fuzzy_pk details, pk_confirmed=false warning,
    --             table-level semantic_notes, FLAGGED warnings.
    -- ══════════════════════════════════════════════════════════════════
    -- Guard: if description contains a JSON parse error, suppress it and use a placeholder
    primary_tbl_comment :=
        IFF(
            COALESCE(sem_model_block:description::VARCHAR, '''') ILIKE ''Parse error:%'',
            ''[WARNING: Semantic model description could not be parsed — rerun agent pipeline for this table.] '',
            COALESCE(sem_model_block:description::VARCHAR, '''') || '' ''
        )
        || COALESCE(sem_model_block:domain_summary::VARCHAR, '''');

    IF (row_cnt_val > 0) THEN
        primary_tbl_comment := primary_tbl_comment
            || '' Rows: '' || TO_VARCHAR(row_cnt_val) || ''.'';
    END IF;

    primary_tbl_comment := primary_tbl_comment
        || '' Phase2 FK enrichment: ''
        || IFF(phase2_en, ''enabled'', ''not enabled'') || ''.'';

    IF (pk_note_str != '''') THEN
        primary_tbl_comment := primary_tbl_comment || '' PK NOTE: '' || pk_note_str;
    END IF;

    -- Fuzzy PK detail (Phase 2A Cortex Search identified)
    IF (fuzzy_pk_block IS NOT NULL) THEN
        primary_tbl_comment := primary_tbl_comment
            || '' PK ['' || COALESCE(fuzzy_pk_block:column::VARCHAR, '''') || '']''
            || '' identified via Phase 2A Cortex Search''
            || '' (similarity: ''
            || TO_VARCHAR(ROUND(COALESCE(fuzzy_pk_block:semantic_similarity::FLOAT, 0), 4))
            || '', IS_LIKELY_KEY=''
            || COALESCE(fuzzy_pk_block:is_likely_key_verified::VARCHAR, ''unknown'')
            || ''). Not formally constrained in DDL — verify before authoritative use.'';
    END IF;

    -- pk_confirmed = false warning
    IF (NOT pk_conf) THEN
        primary_tbl_comment := primary_tbl_comment
            || '' WARNING: No confirmed single-column PK.''
            || IFF(comp_pk_str != '''',
                   '' Composite PK candidates: ['' || comp_pk_str || ''].'',
                   '' No composite candidates found either.'')
            || '' Human validation required. All inferred relationships are provisional.'';
    END IF;

    -- Table-level semantic_notes
    notes_arr_v := sem_model_block:semantic_notes;
    IF (notes_arr_v IS NOT NULL AND ARRAY_SIZE(notes_arr_v) > 0) THEN
        FOR i_idx IN 0 TO ARRAY_SIZE(notes_arr_v) - 1 DO
            note_val := COALESCE(notes_arr_v[i_idx]::VARCHAR, '''');
            IF (note_val != '''') THEN
                primary_tbl_comment := primary_tbl_comment || '' NOTE: '' || note_val;
            END IF;
        END FOR;
    END IF;

    -- Append FLAGGED warnings
    IF (flagged_warn_str != '''') THEN
        primary_tbl_comment := primary_tbl_comment || flagged_warn_str;
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 7: Build outgoing join entries (tables clause entries 2..N)
    --   Processes: column_mappings, column name mismatches, confidence
    --   tiers, LLM review verdict, join condition assembly.
    --   FLAGGED entries are skipped silently (already warned in step 5).
    -- ══════════════════════════════════════════════════════════════════
    related_tbls_str := '''';

    IF (outgoing_arr IS NOT NULL AND ARRAY_SIZE(outgoing_arr) > 0) THEN
        FOR i_idx IN 0 TO ARRAY_SIZE(outgoing_arr) - 1 DO
            rel_entry_v    := outgoing_arr[i_idx];
            rel_conf_val   := COALESCE(rel_entry_v:confidence::VARCHAR, '''');

            -- Skip FLAGGED relationships
            IF (rel_conf_val = ''FLAGGED'') THEN
                CONTINUE;
            END IF;

            rel_schema_val  := COALESCE(rel_entry_v:schema::VARCHAR, SCHEMA_NAME);
            rel_table_val   := COALESCE(rel_entry_v:table::VARCHAR, '''');
            rel_type_str    := COALESCE(rel_entry_v:type::VARCHAR, '''');
            rel_method_val  := COALESCE(rel_entry_v:inferred_method::VARCHAR, '''');
            rel_overlap_val := COALESCE(rel_entry_v:value_overlap_pct::NUMBER, 0);
            rel_review_block := rel_entry_v:semantic_review;
            col_maps_arr_v  := rel_entry_v:column_mappings;

            IF (rel_table_val = '''') THEN CONTINUE; END IF;

            rel_alias_str := UPPER(rel_schema_val) || ''_'' || UPPER(rel_table_val);
            rel_fqn_str   := UPPER(DB_NAME) || ''.'' || UPPER(rel_schema_val) || ''.'' || UPPER(rel_table_val);

            -- ── Build join condition from column_mappings ──────────────
            -- Uses exact fk_column and pk_column values — handles name mismatches
            join_cond_str      := '''';
            fk_list_str        := '''';
            pk_list_str        := '''';
            join_cond_first_flag := TRUE;
            has_mismatch_flag  := FALSE;

            IF (col_maps_arr_v IS NOT NULL AND ARRAY_SIZE(col_maps_arr_v) > 0) THEN
                FOR j_idx IN 0 TO ARRAY_SIZE(col_maps_arr_v) - 1 DO
                    col_map_item_v := col_maps_arr_v[j_idx];
                    fk_col_val     := COALESCE(col_map_item_v:fk_column::VARCHAR, '''');
                    pk_col_val     := COALESCE(col_map_item_v:pk_column::VARCHAR, '''');

                    IF (fk_col_val = '''' OR pk_col_val = '''') THEN CONTINUE; END IF;

                    IF (NOT join_cond_first_flag) THEN
                        join_cond_str := join_cond_str || '' AND '';
                        fk_list_str   := fk_list_str || '', '';
                        pk_list_str   := pk_list_str || '', '';
                    END IF;
                    join_cond_str := join_cond_str
                        || primary_alias_val || ''.'' || fk_col_val
                        || '' = ''
                        || rel_alias_str    || ''.'' || pk_col_val;
                    fk_list_str := fk_list_str || fk_col_val;
                    pk_list_str := pk_list_str || pk_col_val;
                    join_cond_first_flag := FALSE;

                    IF (fk_col_val != pk_col_val) THEN
                        has_mismatch_flag := TRUE;
                    END IF;
                END FOR;
            END IF;

            IF (join_cond_str = '''') THEN CONTINUE; END IF;

            -- ── Build related table comment ────────────────────────────
            rel_comment_str := ''Join confidence: '' || rel_conf_val
                || '' | Type: '' || rel_type_str
                || '' | Method: '' || rel_method_val
                || '' | Value overlap: '' || TO_VARCHAR(ROUND(rel_overlap_val, 1)) || ''%'';

            -- Column name mismatch detail
            IF (has_mismatch_flag AND col_maps_arr_v IS NOT NULL) THEN
                FOR j_idx IN 0 TO ARRAY_SIZE(col_maps_arr_v) - 1 DO
                    col_map_item_v := col_maps_arr_v[j_idx];
                    fk_col_val := COALESCE(col_map_item_v:fk_column::VARCHAR, '''');
                    pk_col_val := COALESCE(col_map_item_v:pk_column::VARCHAR, '''');
                    IF (fk_col_val != '''' AND pk_col_val != '''' AND fk_col_val != pk_col_val) THEN
                        rel_comment_str := rel_comment_str
                            || '' | COLUMN MISMATCH: ''
                            || fk_col_val || '' (FK in this table)''
                            || '' -> '' || pk_col_val || '' (PK in '' || rel_table_val || '').''
                            || '' Verify column alignment before production use.'';
                    END IF;
                END FOR;
            END IF;

            -- LLM review verdict
            IF (rel_review_block IS NOT NULL) THEN
                rel_comment_str := rel_comment_str
                    || '' | LLM Review (''
                    || COALESCE(rel_review_block:reviewed_by::VARCHAR, ''unknown'') || ''): ''
                    || COALESCE(rel_review_block:verdict::VARCHAR, ''unknown'')
                    || '' - ''
                    || COALESCE(rel_review_block:confidence_note::VARCHAR, '''');
            END IF;

            -- LOW confidence advisory
            IF (rel_conf_val = ''LOW'') THEN
                has_low_conf_flag := TRUE;
                rel_comment_str := rel_comment_str
                    || '' | LOW CONFIDENCE: Cortex Analyst should verify this join.''
                    || '' Prioritise HIGH/MEDIUM confidence joins when available for the same target dimension.'';
            END IF;

            -- ── Assemble the full table entry string ───────────────────
            tbl_entry_str :=
                '','' || CHR(10)
                || ''    '' || rel_alias_str || '' as '' || rel_fqn_str || CHR(10)
                || ''      primary key ('' || pk_list_str || '')'' || CHR(10)
                || ''      comment='''''' || REPLACE(rel_comment_str, '''''''', '''''''''''') || '''''''';

            related_tbls_str := related_tbls_str || tbl_entry_str;
            
            -- ── Assemble relationship entry ────────────────────────────
            rel_name_val := ''REL_'' || primary_alias_val || ''_TO_'' || rel_alias_str;
            IF (NOT rel_first_flag) THEN
                relationships_str := relationships_str || '','' || CHR(10);
            END IF;
            relationships_str := relationships_str
                || ''    '' || rel_name_val || '' as '' || primary_alias_val 
                || '' ('' || fk_list_str || '') REFERENCES '' || rel_alias_str;
            rel_first_flag := FALSE;

            joins_cnt := joins_cnt + 1;

        END FOR;
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 8: Build FACTS + DIMENSIONS DDL clauses and CA extension
    --   Routes each column by semantic_role:
    --     ''metric''     → facts block  + CA facts
    --     timestamp    → dimensions block + CA time_dimensions
    --     everything else → dimensions block + CA dimensions
    --   Handles: PII warnings, negative value caution, high null rate,
    --            low-cardinality enum values, FK reference notes.
    -- ══════════════════════════════════════════════════════════════════
    facts_ddl_str       := '''';
    dims_ddl_str        := '''';
    ca_dims_str         := '''';
    ca_facts_str        := '''';
    ca_timedims_str     := '''';
    facts_first_flag    := TRUE;
    dims_first_flag     := TRUE;
    ca_dims_first_flag  := TRUE;
    ca_facts_first_flag := TRUE;
    ca_time_first_flag  := TRUE;

    IF (attr_model_arr IS NOT NULL AND ARRAY_SIZE(attr_model_arr) > 0) THEN
        FOR i_idx IN 0 TO ARRAY_SIZE(attr_model_arr) - 1 DO
            attr_entry_v   := attr_model_arr[i_idx];
            col_name_val   := COALESCE(attr_entry_v:name::VARCHAR, '''');
            col_role_val   := COALESCE(attr_entry_v:semantic_role::VARCHAR, ''attribute'');
            col_type_val   := UPPER(COALESCE(attr_entry_v:data_type::VARCHAR, ''''));
            col_desc_val   := COALESCE(attr_entry_v:description::VARCHAR, '''');
            col_biz_val    := COALESCE(attr_entry_v:business_meaning::VARCHAR, '''');
            null_pct_val   := COALESCE(attr_entry_v:data_quality:null_pct::NUMBER, 0);
            unique_vals_arr := attr_entry_v:value_profile:unique_values;

            IF (col_name_val = '''') THEN CONTINUE; END IF;

            -- ── Numeric metric heuristic fallback ─────────────────────
            -- If the upstream agent left semantic_role as ''attribute'', but
            -- the column is a decimal NUMBER type (e.g., NUMBER(38,2)) with
            -- no PK/FK constraints and the name does not look like a key —
            -- treat it as a metric so SALES, PROFIT, etc. are not lost
            -- in the dimensions block.
            IF (col_role_val = ''attribute''
                AND col_type_val LIKE ''NUMBER%,%''
                AND NOT (col_type_val LIKE ''NUMBER%,0)%'')
                AND ARRAY_SIZE(COALESCE(attr_entry_v:constraints, ARRAY_CONSTRUCT())) = 0
                AND NOT (col_name_val ILIKE ''%_KEY%''
                      OR col_name_val ILIKE ''%_ID%''
                      OR col_name_val ILIKE ''%_SK%'')) THEN
                col_role_val := ''metric'';
            END IF;

            -- Classify as time dimension?
            col_is_time_flag := (
                col_type_val ILIKE ''%DATE%'' OR col_type_val ILIKE ''%TIMESTAMP%''
                OR col_name_val ILIKE ''%DATE%'' 
                OR col_name_val ILIKE ''%_AT''
                OR col_name_val ILIKE ''%_TS''
            );

            -- ── Build column comment ──────────────────────────────────
            col_comment_str := col_desc_val;
            IF (col_biz_val != '''') THEN
                col_comment_str := col_comment_str || '' '' || col_biz_val;
            END IF;

            -- FK reference notes from constraints array
            constraint_arr_v := attr_entry_v:constraints;
            IF (constraint_arr_v IS NOT NULL AND ARRAY_SIZE(constraint_arr_v) > 0) THEN
                FOR j_idx IN 0 TO ARRAY_SIZE(constraint_arr_v) - 1 DO
                    constraint_item_v := constraint_arr_v[j_idx];
                    -- Constraints can be strings ("PRIMARY_KEY") or objects ({"type":"FOREIGN_KEY",...})
                    constraint_type_v := COALESCE(
                        constraint_item_v:type::VARCHAR,
                        constraint_item_v::VARCHAR,
                        ''''
                    );
                    IF (constraint_type_v = ''FOREIGN_KEY'') THEN
                        fk_ref_table_v := COALESCE(constraint_item_v:references:table::VARCHAR, '''');
                        fk_ref_col_v   := COALESCE(constraint_item_v:references:column::VARCHAR, '''');
                        fk_ref_conf_v  := COALESCE(constraint_item_v:confidence::VARCHAR, '''');
                        IF (fk_ref_table_v != '''') THEN
                            col_comment_str := col_comment_str
                                || '' FK to '' || fk_ref_table_v || ''.'' || fk_ref_col_v
                                || '' ('' || fk_ref_conf_v || '' confidence).'';
                        END IF;
                    END IF;
                END FOR;
            END IF;

            -- Semantic notes: detect special patterns and annotate
            notes_arr_v := attr_entry_v:semantic_notes;
            IF (notes_arr_v IS NOT NULL AND ARRAY_SIZE(notes_arr_v) > 0) THEN
                FOR j_idx IN 0 TO ARRAY_SIZE(notes_arr_v) - 1 DO
                    note_val := COALESCE(notes_arr_v[j_idx]::VARCHAR, '''');
                    IF (note_val = '''') THEN CONTINUE; END IF;

                    IF (note_val ILIKE ''%negative values%'') THEN
                        col_comment_str := col_comment_str
                            || '' CAUTION: Negative values are VALID business outcomes.''
                            || '' Do NOT apply ABS() without explicit business justification.'';
                    ELSEIF (note_val ILIKE ''%pii%'' OR note_val ILIKE ''%personally identifiable%'') THEN
                        col_comment_str := col_comment_str || '' [PII WARNING] '' || note_val;
                    ELSE
                        col_comment_str := col_comment_str || '' '' || note_val;
                    END IF;
                END FOR;
            END IF;

            -- High null rate advisory
            IF (null_pct_val > 20) THEN
                col_comment_str := col_comment_str
                    || '' HIGH NULL RATE (''
                    || ROUND(null_pct_val, 1) || ''%)''
                    || '' — use LEFT JOIN when joining on this column.'';
            END IF;

            -- Low-cardinality enum hint (list valid values if <= 15)
            IF (unique_vals_arr IS NOT NULL
                AND ARRAY_SIZE(unique_vals_arr) > 0
                AND ARRAY_SIZE(unique_vals_arr) <= 15) THEN
                col_comment_str := col_comment_str || '' Valid values: '';
                FOR j_idx IN 0 TO ARRAY_SIZE(unique_vals_arr) - 1 DO
                    IF (j_idx > 0) THEN col_comment_str := col_comment_str || '', ''; END IF;
                    col_comment_str := col_comment_str || unique_vals_arr[j_idx]::VARCHAR;
                END FOR;
                col_comment_str := col_comment_str || ''.'';
            END IF;

            -- ── Route to FACTS or DIMENSIONS ─────────────────────────
            IF (col_role_val = ''metric'' OR col_role_val = ''measure'' OR col_role_val = ''fact'') THEN

                -- ── FACTS block ───────────────────────────────────────
                IF (NOT facts_first_flag) THEN
                    facts_ddl_str := facts_ddl_str || '','' || CHR(10);
                END IF;
                facts_ddl_str := facts_ddl_str
                    || ''    '' || primary_alias_val || ''.'' || col_name_val
                    || '' as '' || col_name_val || CHR(10)
                    || ''      comment='''''' || REPLACE(col_comment_str, '''''''', '''''''''''') || '''''''';
                facts_first_flag := FALSE;
                facts_cnt := facts_cnt + 1;
                
                -- ── METRICS block ─────────────────────────────────────
                IF (metrics_cnt > 0) THEN
                    metrics_ddl_str := metrics_ddl_str || '','' || CHR(10);
                END IF;
                metrics_ddl_str := metrics_ddl_str
                    || ''    sum_'' || col_name_val || '' as SUM('' || primary_alias_val || ''.'' || col_name_val || '')'' || CHR(10)
                    || ''      comment=''''Sum of '' || REPLACE(col_desc_val, '''''''', '''''''''''') || '''''','' || CHR(10)
                    || ''    avg_'' || col_name_val || '' as AVG('' || primary_alias_val || ''.'' || col_name_val || '')'' || CHR(10)
                    || ''      comment=''''Average of '' || REPLACE(col_desc_val, '''''''', '''''''''''') || '''''''';
                metrics_cnt := metrics_cnt + 2;


                -- CA facts
                IF (NOT ca_facts_first_flag) THEN ca_facts_str := ca_facts_str || '',''; END IF;
                ca_facts_str := ca_facts_str || ''{"name":"'' || col_name_val || ''"}'';
                ca_facts_first_flag := FALSE;

            ELSE

                -- ── DIMENSIONS block ──────────────────────────────────
                IF (NOT dims_first_flag) THEN
                    dims_ddl_str := dims_ddl_str || '','' || CHR(10);
                END IF;
                dims_ddl_str := dims_ddl_str
                    || ''    '' || primary_alias_val || ''.'' || col_name_val
                    || '' as '' || col_name_val || CHR(10)
                    || ''      comment='''''' || REPLACE(col_comment_str, '''''''', '''''''''''') || '''''''';
                dims_first_flag := FALSE;
                dims_cnt := dims_cnt + 1;

                -- CA routing: timestamps → time_dimensions, others → dimensions
                IF (col_is_time_flag) THEN
                    IF (NOT ca_time_first_flag) THEN ca_timedims_str := ca_timedims_str || '',''; END IF;
                    ca_timedims_str := ca_timedims_str || ''{"name":"'' || col_name_val || ''"}'';
                    ca_time_first_flag := FALSE;
                ELSE
                    IF (NOT ca_dims_first_flag) THEN ca_dims_str := ca_dims_str || '',''; END IF;
                    IF (col_role_val = ''primary_key'') THEN
                        ca_dims_str := ca_dims_str || ''{"name":"'' || col_name_val || ''","unique":true}'';
                    ELSE
                        ca_dims_str := ca_dims_str || ''{"name":"'' || col_name_val || ''"}'';
                    END IF;
                    ca_dims_first_flag := FALSE;
                END IF;

            END IF;

        END FOR;
    END IF;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 9: Build CA extension JSON string
    --   Covers primary table only (Phase 1).
    --   Double-quotes are safe in CA JSON (no single-quote escaping needed).
    -- ══════════════════════════════════════════════════════════════════
    ca_json_str :=
        ''{"tables":[{"name":"'' || ca_table_name || ''",''
        || ''"dimensions":[''  || ca_dims_str     || ''],''
        || ''"facts":[''       || ca_facts_str    || ''],''
        || ''"time_dimensions":['' || ca_timedims_str || '']}]}'';

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 10: Build top-level semantic view comment
    -- ══════════════════════════════════════════════════════════════════
    table_level_comment :=
        ''Semantic view for '' || source_fqn_val || ''.''
        || '' Facts: ''      || IFF(facts_cnt = 0, ''none'', TO_VARCHAR(facts_cnt)) || ''.''
        || '' Dimensions: '' || TO_VARCHAR(dims_cnt) || ''.''
        || '' Outgoing joins: '' || TO_VARCHAR(joins_cnt) || ''.''
        || IFF(has_low_conf_flag,
               '' LOW-confidence joins included (LLM-validated).''
               || '' Verify column alignment before production use.'',
               '''')
        || IFF(has_flagged_flag,
               '' FLAGGED relationships excluded (see primary table comment for details).'',
               '''')
        || IFF(NOT pk_conf,
               '' PK unconfirmed — composite PK suspected. Human review required.'',
               '''');

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 11: Assemble the full DDL string
    -- ══════════════════════════════════════════════════════════════════

    -- Header + opening tables clause
    full_ddl := ''CREATE OR REPLACE SEMANTIC VIEW '' || target_fqn_val || CHR(10)
             || ''  tables ('' || CHR(10)
             || ''    '' || primary_alias_val || '' as '' || source_fqn_val;

    -- PK clause (omitted if pk_confirmed=false)
    IF (pk_clause_str != '''') THEN
        full_ddl := full_ddl || CHR(10) || ''      '' || pk_clause_str;
    END IF;

    -- Primary table comment
    full_ddl := full_ddl || CHR(10)
             || ''      comment='''''' || REPLACE(primary_tbl_comment, '''''''', '''''''''''') || '''''''';

    -- Related tables (outgoing joins, excluding FLAGGED)
    full_ddl := full_ddl || related_tbls_str || CHR(10)
             || ''  )'' || CHR(10);
             
    -- Relationships block
    IF (joins_cnt > 0) THEN
        full_ddl := full_ddl
                 || ''  relationships ('' || CHR(10)
                 || relationships_str || CHR(10)
                 || ''  )'' || CHR(10);
    END IF;

    -- Facts block (omitted if no metric columns exist)
    IF (facts_cnt > 0) THEN
        full_ddl := full_ddl
                 || ''  facts ('' || CHR(10)
                 || facts_ddl_str || CHR(10)
                 || ''  )'' || CHR(10);
    END IF;

    -- Dimensions block
    IF (dims_cnt > 0) THEN
        full_ddl := full_ddl
                 || ''  dimensions ('' || CHR(10)
                 || dims_ddl_str || CHR(10)
                 || ''  )'' || CHR(10);
    END IF;
    
    -- Metrics block
    IF (metrics_cnt > 0) THEN
        full_ddl := full_ddl
                 || ''  metrics ('' || CHR(10)
                 || metrics_ddl_str || CHR(10)
                 || ''  )'' || CHR(10);
    END IF;

    -- Top-level comment
    full_ddl := full_ddl
             || ''  comment='''''' || REPLACE(table_level_comment, '''''''', '''''''''''') || '''''''' || CHR(10);

    -- CA extension
    full_ddl := full_ddl
             || ''  with extension (CA='''''' || ca_json_str || '''''');'';

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 12: Execute the DDL
    -- ══════════════════════════════════════════════════════════════════
    IF (LENGTH(full_ddl) > 15000000) THEN
        RETURN OBJECT_CONSTRUCT(
            ''status'',       ''ERROR'',
            ''code'',         ''DDL_TOO_LARGE'',
            ''view_name'',    view_name_val,
            ''target_fqn'',   target_fqn_val,
            ''message'',      ''Generated DDL string exceeds safe execution limits ('' || TO_VARCHAR(LENGTH(full_ddl)) || '' bytes).''
        );
    END IF;

    BEGIN
        EXECUTE IMMEDIATE full_ddl;

        -- Fetch the native YAML representation generated by Snowflake
        query_str := ''SELECT SYSTEM$READ_YAML_FROM_SEMANTIC_VIEW('''''' || target_fqn_val || '''''') AS YAML_OUT'';
        rs_var := (EXECUTE IMMEDIATE :query_str);
        FOR r IN rs_var DO
            ca_yaml_str := r.YAML_OUT::VARCHAR;
        END FOR;

    EXCEPTION WHEN OTHER THEN
        new_native_id_val := UUID_STRING();
        INSERT INTO __STTM_METADATA_NAMESPACE__.SEM_NATIVE_VIEWS (
            NATIVE_VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, SOURCE_FQN,
            TABLE_VIEW_ID, VIEW_NAME, TARGET_DB, TARGET_SCHEMA, TARGET_FQN,
            DDL_TEXT, CA_YAML_MODEL, FACTS_COUNT, DIMENSIONS_COUNT, JOINS_COUNT,
            HAS_LOW_CONFIDENCE_JOINS, HAS_FLAGGED_EXCLUDED, PK_CONFIRMED, PHASE2_ENABLED,
            STATUS, ERROR_MESSAGE, CREATED_AT
        )
        VALUES (
            :new_native_id_val, UPPER(:DB_NAME), UPPER(:SCHEMA_NAME), UPPER(:TABLE_NAME), :source_fqn_val,
            :table_view_id_val, :view_name_val, ''__STTM_METADATA_DATABASE__'', ''__STTM_METADATA_SCHEMA__'', :target_fqn_val,
            :full_ddl, NULL, :facts_cnt, :dims_cnt, :joins_cnt,
            :has_low_conf_flag, :has_flagged_flag, :pk_conf, :phase2_en,
            ''FAILED'', :SQLERRM, CURRENT_TIMESTAMP()
        );

        RETURN OBJECT_CONSTRUCT(
            ''status'',       ''ERROR'',
            ''code'',         ''DDL_EXECUTION_FAILED'',
            ''view_name'',    view_name_val,
            ''target_fqn'',   target_fqn_val,
            ''message'',      SQLERRM,
            ''ddl_preview'',  LEFT(full_ddl, 1000)
        );
    END;

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 13: Update SEM_NATIVE_VIEWS
    --   a) Mark any existing ACTIVE row for this table as SUPERSEDED
    --   b) Insert a new ACTIVE row
    -- ══════════════════════════════════════════════════════════════════
    UPDATE __STTM_METADATA_NAMESPACE__.SEM_NATIVE_VIEWS
    SET    STATUS = ''SUPERSEDED''
    WHERE  DATABASE_NAME = UPPER(:DB_NAME)
      AND  SCHEMA_NAME   = UPPER(:SCHEMA_NAME)
      AND  TABLE_NAME    = UPPER(:TABLE_NAME)
      AND  STATUS        = ''ACTIVE'';

    new_native_id_val := UUID_STRING();

    INSERT INTO __STTM_METADATA_NAMESPACE__.SEM_NATIVE_VIEWS (
        NATIVE_VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, SOURCE_FQN,
        TABLE_VIEW_ID, VIEW_NAME, TARGET_DB, TARGET_SCHEMA, TARGET_FQN,
        DDL_TEXT, CA_YAML_MODEL, FACTS_COUNT, DIMENSIONS_COUNT, JOINS_COUNT,
        HAS_LOW_CONFIDENCE_JOINS, HAS_FLAGGED_EXCLUDED, PK_CONFIRMED, PHASE2_ENABLED,
        STATUS, CREATED_AT
    )
    VALUES (
        :new_native_id_val, UPPER(:DB_NAME), UPPER(:SCHEMA_NAME), UPPER(:TABLE_NAME), :source_fqn_val,
        :table_view_id_val, :view_name_val, ''__STTM_METADATA_DATABASE__'', ''__STTM_METADATA_SCHEMA__'', :target_fqn_val,
        :full_ddl, :ca_yaml_str, :facts_cnt, :dims_cnt, :joins_cnt,
        :has_low_conf_flag, :has_flagged_flag, :pk_conf, :phase2_en,
        ''ACTIVE'', CURRENT_TIMESTAMP()
    );

    -- ══════════════════════════════════════════════════════════════════
    -- STEP 14: Return success
    -- ══════════════════════════════════════════════════════════════════
    RETURN OBJECT_CONSTRUCT(
        ''status'',                   ''OK'',
        ''view_name'',                view_name_val,
        ''target_fqn'',               target_fqn_val,
        ''source_fqn'',               source_fqn_val,
        ''facts_count'',              facts_cnt,
        ''dims_count'',               dims_cnt,
        ''joins_count'',              joins_cnt,
        ''has_low_confidence_joins'', has_low_conf_flag,
        ''has_flagged_excluded'',     has_flagged_flag,
        ''pk_confirmed'',             pk_conf,
        ''phase2_enabled'',           phase2_en,
        ''native_view_id'',           new_native_id_val
    );

EXCEPTION WHEN OTHER THEN
    RETURN OBJECT_CONSTRUCT(
        ''status'',  ''ERROR'',
        ''code'',    ''UNEXPECTED_ERROR'',
        ''message'', SQLERRM
    );
END;
';
