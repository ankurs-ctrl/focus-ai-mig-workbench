from __future__ import annotations

import json
import re
from hashlib import sha256
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field

from app.agent_runs.models import AgentRun, AssistantIntent, ExecutionPath, RunMode, RunStatus


class AssistantMode(str, Enum):
    QUICK = "quick"
    DEEP = "deep"


class AssistantConversation(BaseModel):
    conversation_id: str
    actor_user_id: str
    tenant_id: str = "default"
    mode: AssistantMode
    title: str = "New chat"
    project_id: str | None = None
    sttm_id: str | None = None
    pinned: bool = False
    status: Literal["ACTIVE", "ARCHIVED"] = "ACTIVE"
    last_turn_id: str | None = None
    last_run_id: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class AssistantTurn(BaseModel):
    turn_id: str
    conversation_id: str
    sequence: int
    role: Literal["user", "assistant", "progress", "error", "cancellation"]
    mode: AssistantMode
    message_kind: str
    message: str
    intent: AssistantIntent
    run_id: str | None = None
    idempotency_key: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ConversationCreateRequest(BaseModel):
    mode: AssistantMode
    title: str | None = Field(default=None, max_length=255)
    project_id: str | None = Field(default=None, max_length=255)
    sttm_id: str | None = Field(default=None, max_length=255)
    idempotency_key: str | None = Field(default=None, max_length=255)


class ConversationUpdateRequest(BaseModel):
    title: str | None = Field(default=None, max_length=255)
    project_id: str | None = Field(default=None, max_length=255)
    pinned: bool | None = None


class ConversationTurnRequest(BaseModel):
    message: str = Field(min_length=1, max_length=50_000)
    idempotency_key: str = Field(min_length=1, max_length=255)
    model_name: str | None = Field(default=None, max_length=128)
    page_context: dict[str, Any] = Field(default_factory=dict)
    authorized_schemas: list[str] = Field(default_factory=list)
    source_scope: list[str] = Field(default_factory=list)
    target_scope: list[str] = Field(default_factory=list)
    project_id: str | None = None
    attachment_ids: list[str] = Field(default_factory=list)
    requested_mappings: list[str] = Field(default_factory=list)
    effort: str = "auto"
    run_mode: RunMode = RunMode.AUTO
    plan_offer_decision: Literal["continue_auto"] | None = None


class ConversationTurnResponse(BaseModel):
    conversation_id: str
    turn_id: str
    intent: AssistantIntent
    execution_path: ExecutionPath
    message: str | None = None
    question: dict[str, Any] | None = None
    run: AgentRun | None = None
    resumable: bool = False
    plan_offer: dict[str, str] | None = None


class LegacyConversationImport(BaseModel):
    legacy_id: str
    title: str = "Imported chat"
    project_id: str | None = None
    sttm_id: str | None = None
    messages: list[dict[str, Any]] = Field(default_factory=list, max_length=500)


class LegacyConversationImportRequest(BaseModel):
    browser_migration_id: str = Field(min_length=1, max_length=255)
    sessions: list[LegacyConversationImport] = Field(default_factory=list, max_length=30)


def concise_chat_title(message: str) -> str:
    """Make a short, readable subject without another model call on submit."""
    normalized = " ".join(message.split())
    lower = normalized.casefold()
    if re.search(r"\b(?:continue|complete|finish)\b", lower) and re.search(r"\b(?:migration|mapping|draft)\b", lower):
        if re.search(r"\bsql\b", lower) and re.search(r"\b(?:preview|sample results?)\b", lower):
            return "Complete mapping SQL and preview"
        return "Complete migration mapping"
    if re.search(r"\b(?:summari[sz]e|review)\b", lower) and re.search(r"\b(?:transcript|call notes?)\b", lower):
        return "Review client call transcript"
    if re.search(r"\b(?:recommend|find|identify)\b", lower) and re.search(r"\b(?:source|derived sources?)\b", lower):
        return "Review source candidates"
    first = re.split(r"[\n.!?;]", normalized, maxsplit=1)[0].strip()
    first = re.sub(r"^(?:please\s+|can you\s+|could you\s+|i (?:want|need|would like) (?:you )?to\s+)+", "", first, flags=re.I)
    first = re.sub(r"\b(?:a new|an existing|the existing)\b\s*", "", first, flags=re.I)
    words = first.split()
    title = " ".join(words[:9]).strip(" ,:-")
    if len(title) > 72:
        title = title[:72].rsplit(" ", 1)[0].strip(" ,:-")
    if not title:
        return "New chat"
    return title[0].upper() + title[1:]


class ConversationDetail(BaseModel):
    conversation: AssistantConversation
    turns: list[AssistantTurn] = Field(default_factory=list)
    linked_runs: list["ConversationRunSummary"] = Field(default_factory=list)
    resumable: bool = False
    current_plan: dict[str, Any] | None = None
    attachments: list[dict[str, str]] = Field(default_factory=list)


class ConversationRunSummary(BaseModel):
    """Small restore-safe projection; full run payloads stay on the run API."""

    run_id: str
    status: RunStatus
    turn_id: str | None = None
    intent: AssistantIntent
    resume_attempt: int = 0
    run_revision: int = 0
    error_code: str | None = None
    safe_error: str | None = None
    prompt: str = Field(default="", exclude=True)
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_run(cls, run: AgentRun) -> "ConversationRunSummary":
        return cls(
            run_id=run.run_id,
            status=run.status,
            turn_id=run.request.turn_id,
            intent=run.request.intent,
            resume_attempt=run.resume_attempt,
            run_revision=run.run_revision,
            error_code=run.error_code,
            safe_error=run.safe_error,
            prompt=run.request.prompt,
            created_at=run.created_at,
            updated_at=run.updated_at,
        )


_GREETING_PREFIX = re.compile(
    r"^(?:(?:hi|hello|hey|hiya|greetings|good\s+(?:morning|afternoon|evening)|thanks|thank\s+you)"
    r"(?:\s+(?:there|team|agent|coco))?[\s,.!:;-]*)+"
)
_PURE_GREETING = re.compile(
    r"(?:hi|hello|hey|hiya|greetings|good\s+(?:morning|afternoon|evening)|thanks|thank\s+you|ok(?:ay)?|cool)"
    r"(?:\s+(?:there|team|agent|coco))?[\s.!?]*"
)
_CAPABILITY_QUESTION = re.compile(
    r"^(?:please\s+)?(?:"
    r"help|help me|what can you help(?: me)? with|how can you help(?: me)?|"
    r"(?:so\s+)?what (?:all |else )?(?:can|could|do) you (?:do|help with|support|offer)|"
    r"what are (?:all )?(?:your|the) (?:capabilities|features|skills|options)|"
    r"(?:tell me |show me )?(?:about )?(?:your|the agent'?s?) capabilities|list (?:your )?capabilities|"
    r"who are you|what are you|what is this(?: agent| tool)?|how do (?:i|we) (?:use|start with) (?:you|this)|"
    r"what do you support|what kinds? of (?:tasks|things|requests) can you (?:do|handle)"
    r")[\s?.!]*$"
)
_MIGRATION_ACTION = re.compile(
    r"\b(?:build|create|design|plan|generate|prepare|execute|run|validate|optimize)\b"
    r".{0,100}\b(?:migration|mapping|sttm)\b"
)
_TASK_MARKERS = (
    "create mapping", "create a mapping", "build mapping", "update mapping", "draft mapping",
    "migrate ", "map ", "source-to-target", "source to target", "run migration",
    "generate mapping", "reconcile mapping", "validate mapping", "create sttm",
    "create a sttm", "draft sttm", "build sttm",
)


def _normalized(message: str) -> str:
    return " ".join(message.casefold().split())


def _without_greeting(text: str) -> str:
    return _GREETING_PREFIX.sub("", text, count=1).strip()


def is_greeting_or_capability_question(message: str) -> bool:
    """A greeting or "what can you do" needs no tools, workflow, or durable run."""
    text = _normalized(message)
    if not text or is_explicit_migration_request(message):
        return False
    if _PURE_GREETING.fullmatch(text):
        return True
    return bool(_CAPABILITY_QUESTION.match(_without_greeting(text)))


def is_explicit_migration_request(message: str) -> bool:
    """True only when the user literally asked for migration or mapping work."""
    text = _normalized(message)
    return bool(_MIGRATION_ACTION.search(text)) or any(marker in text for marker in _TASK_MARKERS)


def resolve_assistant_intent(
    message: str,
    *,
    latest_run: AgentRun | None,
    mode: AssistantMode | str | None = None,
) -> AssistantIntent:
    """Route from the current message only; history never reactivates an old plan."""
    text = _normalized(message)
    if re.fullmatch(r"(?:please\s+)?(?:continue|resume|keep going|carry on)[.!?\s]*", text) or re.search(
        r"(?:[,;]\s*|\b(?:and|then)\s+)(?:please\s+)?(?:continue|resume|keep going|carry on)[.!?\s]*$",
        text,
    ):
        return AssistantIntent.CONTINUE_RUN
    if re.search(r"\b(?:cancel|stop|abort)\b", text) and re.search(r"\b(?:run|agent|task|it|this)\b", text):
        return AssistantIntent.CANCEL_RUN
    if (
        latest_run is not None
        and latest_run.status in {RunStatus.AWAITING_INPUT, RunStatus.AWAITING_CONFIRMATION}
        and re.fullmatch(r"(?:yes|no|approve|reject|confirm|option\s+\d+|choice\s+\d+)[.!?\s]*", text)
    ):
        return AssistantIntent.ANSWER_INTERRUPT
    diagnostic_phrases = (
        "what failed", "why did", "why couldn't", "why could not", "what was the error",
        "explain the error", "why you were not able", "what happened", "diagnose",
    )
    if latest_run is not None and any(phrase in text for phrase in diagnostic_phrases):
        return AssistantIntent.RUN_DIAGNOSTIC
    # A request to execute or preview SQL from the preceding answer needs a
    # durable run (it is not conversational QA), but it is not a request to
    # restart the migration or create draft artifacts.
    if is_read_only_sql_followup(message, latest_run=latest_run):
        return AssistantIntent.NEW_MIGRATION_TASK
    if is_greeting_or_capability_question(message):
        return AssistantIntent.CONVERSATIONAL_QA
    # "Hello, what is a CTE?" is the same glossary question as "What is a CTE?".
    text = _without_greeting(text) or text
    explanatory_leads = (
        "what is ", "what are ", "what does ", "how does ", "how do ", "why is ", "why are ",
        "explain ", "can you explain ", "tell me about ", "describe what ",
    )
    action_verbs = (
        "create ", "build ", "update ", "change ", "generate ", "draft ",
        "run ", "execute ", "reconcile ", "validate ", "save ",
    )
    glossary_terms = (
        "target table", "source table", "source-to-target mapping", "source to target mapping",
        "derived source", "cte", "fir evidence", "semantic context", "confidence score",
    )
    explicit_glossary = (
        text.startswith(explanatory_leads)
        and any(term in text for term in glossary_terms)
        and not any(verb in text for verb in action_verbs)
    )
    general_explanation = (
        text.startswith(explanatory_leads)
        and not any(verb in text for verb in action_verbs)
    )
    if explicit_glossary or general_explanation:
        return AssistantIntent.CONVERSATIONAL_QA
    if is_explicit_migration_request(message):
        return AssistantIntent.NEW_MIGRATION_TASK
    # Deep mode is supervisor-owned. Unknown natural-language phrasing must be
    # interpreted from the full request by the model, not rejected by a finite
    # keyword vocabulary. The deterministic router is reserved for controls,
    # interrupts, diagnostics, and high-confidence glossary fast paths above.
    if str(getattr(mode, "value", mode) or "").casefold() == AssistantMode.DEEP.value:
        return AssistantIntent.NEW_MIGRATION_TASK
    return AssistantIntent.CONVERSATIONAL_QA


def is_read_only_document_question(message: str, *, has_attachments: bool) -> bool:
    """Narrow document analysis must not create a migration draft or checkpoint."""
    if not has_attachments:
        return False
    text = " ".join(message.casefold().split())
    if re.search(r"\b(?:create|build|draft|save|persist|publish|execute|run|generate|implement|migrate|map|update|modify|compile|preview)\b", text):
        return False
    return bool(re.search(
        r"\b(?:summari[sz]e|summary|identify|list|extract|explain|what|which|who|when|why|how|compare|review|ask|questions?|tell me)\b",
        text,
    ))


def is_read_only_sql_followup(message: str, *, latest_run: AgentRun | None) -> bool:
    if latest_run is None:
        return False
    text = " ".join(message.casefold().split())
    asks_for_sql_result = (
        re.search(r"\b(?:execute|run|preview)\b", text) is not None
        and re.search(r"\b(?:sql|query|proposed|output|rows?|results?)\b", text) is not None
    )
    asks_for_mutation = re.search(
        r"\b(?:create|save|publish|persist|modify|update|delete|insert|merge|draft\s+sttm)\b",
        text,
    ) is not None
    return asks_for_sql_result and not asks_for_mutation


def intent_from_classification(
    label: str, *, latest_run: AgentRun | None, fallback: AssistantIntent,
) -> tuple[AssistantIntent, bool, bool]:
    """Map a model intent label to ``(intent, capability question, explicit migration task)``.

    Controls that need a run (continue, cancel, diagnose) apply only when the
    conversation has one; otherwise the deterministic fallback stands.
    """
    if label == "GREETING_OR_CAPABILITY":
        return AssistantIntent.CONVERSATIONAL_QA, True, False
    if label in {"CONCEPT_QUESTION", "READ_ONLY_QUESTION"}:
        return AssistantIntent.CONVERSATIONAL_QA, False, False
    if label == "MIGRATION_TASK":
        return AssistantIntent.NEW_MIGRATION_TASK, False, True
    if latest_run is not None:
        control = {"CONTINUE": AssistantIntent.CONTINUE_RUN, "CANCEL": AssistantIntent.CANCEL_RUN,
                   "DIAGNOSE": AssistantIntent.RUN_DIAGNOSTIC}.get(label)
        if control is not None:
            return control, False, False
    return fallback, False, False


def resolves_deterministically(message: str, intent: AssistantIntent, *, latest_run: AgentRun | None) -> bool:
    """Exact controls, recognised capability questions and literal task requests need no model call."""
    return (
        intent in {AssistantIntent.CONTINUE_RUN, AssistantIntent.CANCEL_RUN,
                   AssistantIntent.ANSWER_INTERRUPT, AssistantIntent.RUN_DIAGNOSTIC}
        or is_greeting_or_capability_question(message)
        or is_explicit_migration_request(message)
        or is_read_only_sql_followup(message, latest_run=latest_run)
    )


def capability_answer() -> str:
    """Generated from the registered agent capabilities, so it cannot drift from what the agent can do."""
    from app.agent_tools.capability_registry import CapabilityRegistry

    return CapabilityRegistry.capability_answer()


def build_conversational_fast_answer(message: str) -> str | None:
    """Answer common Workbench glossary questions without agent startup."""
    if is_greeting_or_capability_question(message):
        return capability_answer()
    text = _without_greeting(_normalized(message)) or _normalized(message)
    if "source-to-target mapping" in text or "source to target mapping" in text:
        return (
            "A source-to-target mapping defines how each target column is populated from source data. "
            "It records source columns, joins, filters, transformations, defaults, data types, and unresolved "
            "items so the migration SQL is traceable, testable, and reviewable."
        )
    if "target table" in text:
        return (
            "A target table is the destination structure the migration must populate. Its contract—columns, "
            "types, keys, nullability, and grain—drives which source data, joins, and transformation rules are required."
        )
    if "source table" in text:
        return (
            "A source table is an input dataset used to populate the target. The Workbench inspects its columns, "
            "keys, quality, and relationships before proposing mappings."
        )
    if "derived source" in text:
        return (
            "A derived source is a governed intermediate dataset—often a query or CTE—that joins, filters, "
            "deduplicates, or reshapes raw sources before target-column mappings are applied."
        )
    if re.search(r"\bcte\b", text):
        return (
            "A CTE (common table expression) is a named intermediate SQL result declared with WITH. In migration "
            "SQL it helps isolate joins, cleansing, deduplication, and reusable transformation steps."
        )
    if "confidence score" in text:
        return (
            "A mapping confidence score summarizes how strongly evidence supports a proposed source, join, or rule. "
            "High confidence requires verified contracts and consistent precedent; unresolved or inferred logic lowers it."
        )
    return None


class SnowflakeAssistantConversationRepository:
    def __init__(self, session: Any, *, database: str = "", schema: str = "") -> None:
        self._session = session
        prefix = ".".join(part for part in (database, schema) if part)
        self._prefix = f"{prefix}." if prefix else ""

    def _table(self, name: str) -> str:
        return f"{self._prefix}{name}"

    @staticmethod
    def _row(value: Any) -> dict[str, Any]:
        return value.as_dict() if hasattr(value, "as_dict") else dict(value)

    @staticmethod
    def _variant(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value

    def create(self, body: ConversationCreateRequest, *, user_id: str, tenant_id: str) -> AssistantConversation:
        if body.idempotency_key:
            identity = f"{tenant_id}\x1f{user_id}\x1f{body.idempotency_key}".encode()
            conversation_id = f"conv_{sha256(identity).hexdigest()[:32]}"
        else:
            conversation_id = f"conv_{uuid4().hex}"
        conversation = AssistantConversation(
            conversation_id=conversation_id, actor_user_id=user_id, tenant_id=tenant_id,
            mode=body.mode, title=(body.title or "New chat").strip() or "New chat",
            project_id=body.project_id, sttm_id=body.sttm_id,
        )
        self._session.sql(
            f"""MERGE INTO {self._table('TBL_ASSISTANT_CONVERSATIONS')} target
            USING (SELECT ? CONVERSATION_ID) source
            ON target.CONVERSATION_ID=source.CONVERSATION_ID
            WHEN NOT MATCHED THEN INSERT
              (CONVERSATION_ID, ACTOR_USER_ID, TENANT_ID, MODE, TITLE, PROJECT_ID, STTM_ID,
               STATUS, CREATED_AT, UPDATED_AT)
            VALUES (source.CONVERSATION_ID,?,?,?,?,NULLIF(?,''),NULLIF(?,''),
                    'ACTIVE',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP())""",
            [conversation.conversation_id, user_id, tenant_id, conversation.mode.value,
             conversation.title, conversation.project_id or "", conversation.sttm_id or ""],
        ).collect()
        return self.get(conversation.conversation_id, user_id=user_id, tenant_id=tenant_id) or conversation

    def get(self, conversation_id: str, *, user_id: str, tenant_id: str) -> AssistantConversation | None:
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_ASSISTANT_CONVERSATIONS')} WHERE CONVERSATION_ID=? AND ACTOR_USER_ID=? AND TENANT_ID=? LIMIT 1",
            [conversation_id, user_id, tenant_id],
        ).collect()
        return self._conversation(self._row(rows[0])) if rows else None

    def list(self, *, user_id: str, tenant_id: str, limit: int, offset: int, project_id: str | None = None, sttm_id: str | None = None) -> list[AssistantConversation]:
        predicates = [
            "ACTOR_USER_ID=?", "TENANT_ID=?", "STATUS='ACTIVE'",
            "(LAST_TURN_ID IS NOT NULL OR LAST_RUN_ID IS NOT NULL)",
        ]
        params: list[Any] = [user_id, tenant_id]
        if project_id:
            predicates.append("PROJECT_ID=?")
            params.append(project_id)
        if sttm_id:
            predicates.append("STTM_ID=?")
            params.append(sttm_id)
        params.extend([limit, offset])
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_ASSISTANT_CONVERSATIONS')} WHERE {' AND '.join(predicates)} ORDER BY UPDATED_AT DESC LIMIT ? OFFSET ?",
            params,
        ).collect()
        return [self._conversation(self._row(row)) for row in rows]

    def archive(self, conversation_id: str, *, user_id: str, tenant_id: str) -> bool:
        rows = self._session.sql(
            f"""UPDATE {self._table('TBL_ASSISTANT_CONVERSATIONS')}
            SET STATUS='ARCHIVED', UPDATED_AT=CURRENT_TIMESTAMP()
            WHERE CONVERSATION_ID=? AND ACTOR_USER_ID=? AND TENANT_ID=? AND STATUS='ACTIVE'""",
            [conversation_id, user_id, tenant_id],
        ).collect()
        # Snowpark UPDATE returns one result row with rows_updated when
        # available. A preceding ownership check keeps behavior portable.
        return bool(rows) or self.get(conversation_id, user_id=user_id, tenant_id=tenant_id) is not None

    def update_metadata(
        self, conversation_id: str, body: ConversationUpdateRequest, *, user_id: str, tenant_id: str
    ) -> AssistantConversation | None:
        current = self.get(conversation_id, user_id=user_id, tenant_id=tenant_id)
        if current is None or current.status != "ACTIVE":
            return None
        fields = body.model_fields_set
        assignments: list[str] = []
        params: list[Any] = []
        if "title" in fields:
            title = (body.title or "").strip()
            if not title:
                raise ValueError("Chat title cannot be empty")
            assignments.append("TITLE=?")
            params.append(title)
        if "project_id" in fields:
            assignments.extend(["PROJECT_ID=NULLIF(?, '')", "STTM_ID=NULL"])
            params.append(body.project_id or "")
        if "pinned" in fields:
            if body.pinned is None:
                raise ValueError("Pinned must be true or false")
            assignments.append("PINNED=?")
            params.append(body.pinned)
        if not assignments:
            return current
        self._session.sql(
            f"UPDATE {self._table('TBL_ASSISTANT_CONVERSATIONS')} SET {', '.join(assignments)} "
            "WHERE CONVERSATION_ID=? AND ACTOR_USER_ID=? AND TENANT_ID=? AND STATUS='ACTIVE'",
            [*params, conversation_id, user_id, tenant_id],
        ).collect()
        return self.get(conversation_id, user_id=user_id, tenant_id=tenant_id)

    def append_turn(self, turn: AssistantTurn) -> AssistantTurn:
        self._session.sql(
            f"""MERGE INTO {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')} target
            USING (SELECT ? TURN_ID, ? CONVERSATION_ID) source
            ON target.TURN_ID=source.TURN_ID
            WHEN MATCHED THEN UPDATE SET RUN_ID=NULLIF(?,''), TURN_META=PARSE_JSON(?),
              MESSAGE_KIND=?, INTENT_CLASS=?
            WHEN NOT MATCHED THEN INSERT
              (TURN_ID, CONVERSATION_ID, ROLE, ROUTE, INTENT_CLASS, MESSAGE, USER_ID,
               TURN_SEQUENCE, MODE, MESSAGE_KIND, RUN_ID, IDEMPOTENCY_KEY, TURN_META)
            VALUES (?, ?, ?, 'assistant', ?, ?, NULL, ?, ?, ?, NULLIF(?,''), NULLIF(?,''), PARSE_JSON(?))""",
            [turn.turn_id, turn.conversation_id, turn.run_id or "", json.dumps(turn.metadata, default=str),
             turn.message_kind, turn.intent.value, turn.turn_id, turn.conversation_id,
             turn.role, turn.intent.value, turn.message, turn.sequence, turn.mode.value,
             turn.message_kind, turn.run_id or "", turn.idempotency_key or "",
             json.dumps(turn.metadata, default=str)],
        ).collect()
        self._session.sql(
            f"""UPDATE {self._table('TBL_ASSISTANT_CONVERSATIONS')}
            SET LAST_TURN_ID=?, LAST_RUN_ID=COALESCE(NULLIF(?,''),LAST_RUN_ID),
                TITLE=IFF(TITLE='New chat' AND ?='user',?,TITLE), UPDATED_AT=CURRENT_TIMESTAMP()
            WHERE CONVERSATION_ID=?""",
            [turn.turn_id, turn.run_id or "", turn.role, concise_chat_title(turn.message), turn.conversation_id],
        ).collect()
        return turn

    def next_sequence(self, conversation_id: str) -> int:
        rows = self._session.sql(
            f"SELECT COALESCE(MAX(TURN_SEQUENCE),0)+1 NEXT_SEQ FROM {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')} WHERE CONVERSATION_ID=?",
            [conversation_id],
        ).collect()
        return int(self._row(rows[0]).get("NEXT_SEQ") or 1)

    def find_turn_by_idempotency(self, conversation_id: str, key: str) -> AssistantTurn | None:
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')} WHERE CONVERSATION_ID=? AND IDEMPOTENCY_KEY=? ORDER BY CREATED_AT DESC LIMIT 1",
            [conversation_id, key],
        ).collect()
        return self._turn(self._row(rows[0])) if rows else None

    def has_idempotency_key(self, key: str) -> bool:
        rows = self._session.sql(
            f"SELECT 1 FROM {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')} WHERE IDEMPOTENCY_KEY=? LIMIT 1",
            [key],
        ).collect()
        return bool(rows)

    def list_turns(self, conversation_id: str, *, limit: int = 200) -> list[AssistantTurn]:
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')} WHERE CONVERSATION_ID=? AND TURN_SEQUENCE IS NOT NULL ORDER BY TURN_SEQUENCE, CREATED_AT LIMIT ?",
            [conversation_id, limit],
        ).collect()
        return [self._turn(self._row(row)) for row in rows]

    def list_recent_turns(self, conversation_id: str, *, limit: int = 30) -> list[AssistantTurn]:
        """The newest `limit` turns in chronological order (model history window)."""
        rows = self._session.sql(
            f"""SELECT * FROM (
                SELECT * FROM {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')}
                WHERE CONVERSATION_ID=? AND TURN_SEQUENCE IS NOT NULL
                ORDER BY TURN_SEQUENCE DESC, CREATED_AT DESC LIMIT ?
            ) ORDER BY TURN_SEQUENCE, CREATED_AT""",
            [conversation_id, limit],
        ).collect()
        return [self._turn(self._row(row)) for row in rows]

    @staticmethod
    def _conversation(row: dict[str, Any]) -> AssistantConversation:
        return AssistantConversation(
            conversation_id=str(row["CONVERSATION_ID"]), actor_user_id=str(row["ACTOR_USER_ID"]),
            tenant_id=str(row.get("TENANT_ID") or "default"), mode=str(row["MODE"]).lower(),
            title=str(row.get("TITLE") or "New chat"), project_id=row.get("PROJECT_ID"),
            sttm_id=row.get("STTM_ID"), pinned=bool(row.get("PINNED") or False), status=str(row.get("STATUS") or "ACTIVE"),
            last_turn_id=row.get("LAST_TURN_ID"), last_run_id=row.get("LAST_RUN_ID"),
            created_at=row.get("CREATED_AT") or datetime.now(UTC), updated_at=row.get("UPDATED_AT") or datetime.now(UTC),
        )

    def _turn(self, row: dict[str, Any]) -> AssistantTurn:
        meta = self._variant(row.get("TURN_META"))
        return AssistantTurn(
            turn_id=str(row["TURN_ID"]), conversation_id=str(row["CONVERSATION_ID"]),
            sequence=int(row.get("TURN_SEQUENCE") or 0), role=str(row.get("ROLE") or "assistant").lower(),
            mode=str(row.get("MODE") or "quick").lower(), message_kind=str(row.get("MESSAGE_KIND") or "message"),
            message=str(row.get("MESSAGE") or ""), intent=str(row.get("INTENT_CLASS") or AssistantIntent.CONVERSATIONAL_QA.value),
            run_id=row.get("RUN_ID"), idempotency_key=row.get("IDEMPOTENCY_KEY"),
            metadata=dict(meta) if isinstance(meta, dict) else {}, created_at=row.get("CREATED_AT") or datetime.now(UTC),
        )
