import QuizPage from "@/features/quiz/QuizPage";

export default function Page() {
  return <QuizPage />;
}
