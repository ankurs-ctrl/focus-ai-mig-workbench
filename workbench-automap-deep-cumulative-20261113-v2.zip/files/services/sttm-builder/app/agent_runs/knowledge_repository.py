"""Durable storage for conversation-scoped run knowledge."""
from __future__ import annotations

import json
import re
from typing import Any

_TABLE_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
# Bind values are bounded; large evidence packages are written in chunks.
_MAX_BATCH_BYTES = 4_000_000


class RunKnowledgeRepository:
    def __init__(self, session: Any, *, database: str = "", schema: str = "",
                 table: str = "TBL_AGENT_RUN_KNOWLEDGE") -> None:
        parts = [part for part in (database, schema) if part]
        if not _TABLE_NAME.fullmatch(table) or not all(_TABLE_NAME.fullmatch(part) for part in parts):
            raise ValueError("Unsafe knowledge table name")
        self._session = session
        self._table = ".".join([*parts, table])

    @staticmethod
    def _variant(value: Any) -> Any:
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return value
        return value

    def load(self, scope: str, access_scope: str) -> list[dict[str, Any]]:
        rows = self._session.sql(
            f"SELECT KIND, ITEM_KEY, FINGERPRINT, PAYLOAD FROM {self._table} "
            "WHERE KNOWLEDGE_SCOPE = ? AND ACCESS_SCOPE = ?",
            params=[scope, access_scope],
        ).collect()
        result = []
        for row in rows:
            data = row.as_dict() if hasattr(row, "as_dict") else dict(row)
            result.append({"kind": data.get("KIND"), "key": data.get("ITEM_KEY"),
                           "fingerprint": data.get("FINGERPRINT") or "",
                           "payload": self._variant(data.get("PAYLOAD"))})
        return result

    @staticmethod
    def _chunks(rows: list[dict[str, Any]]) -> list[str]:
        chunks: list[str] = []
        current: list[str] = []
        size = 0
        for row in rows:
            encoded = json.dumps(row, sort_keys=True, separators=(",", ":"), default=str)
            if current and size + len(encoded) > _MAX_BATCH_BYTES:
                chunks.append("[" + ",".join(current) + "]")
                current, size = [], 0
            current.append(encoded)
            size += len(encoded)
        if current:
            chunks.append("[" + ",".join(current) + "]")
        return chunks

    def write(self, scope: str, access_scope: str, run_id: str, rows: list[dict[str, Any]]) -> int:
        upserts = [row for row in rows if row.get("payload") is not None]
        deletions = [{"kind": row["kind"], "key": row["key"]} for row in rows if row.get("payload") is None]
        for chunk in self._chunks(upserts):
            self._session.sql(
                f"""
                MERGE INTO {self._table} t
                USING (
                    SELECT VALUE:kind::VARCHAR KIND, VALUE:key::VARCHAR ITEM_KEY,
                           VALUE:fingerprint::VARCHAR FINGERPRINT, VALUE:payload PAYLOAD
                    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))
                ) s
                ON t.KNOWLEDGE_SCOPE = ? AND t.ACCESS_SCOPE = ? AND t.KIND = s.KIND AND t.ITEM_KEY = s.ITEM_KEY
                WHEN MATCHED THEN UPDATE SET FINGERPRINT = s.FINGERPRINT, PAYLOAD = s.PAYLOAD,
                    RUN_ID = ?, UPDATED_AT = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT
                    (KNOWLEDGE_SCOPE, ACCESS_SCOPE, KIND, ITEM_KEY, FINGERPRINT, PAYLOAD, RUN_ID, CREATED_AT, UPDATED_AT)
                    VALUES (?, ?, s.KIND, s.ITEM_KEY, s.FINGERPRINT, s.PAYLOAD, ?, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())
                """,
                params=[chunk, scope, access_scope, run_id, scope, access_scope, run_id],
            ).collect()
        for chunk in self._chunks(deletions):
            self._session.sql(
                f"""
                DELETE FROM {self._table} t
                USING (
                    SELECT VALUE:kind::VARCHAR KIND, VALUE:key::VARCHAR ITEM_KEY
                    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))
                ) s
                WHERE t.KNOWLEDGE_SCOPE = ? AND t.ACCESS_SCOPE = ? AND t.KIND = s.KIND AND t.ITEM_KEY = s.ITEM_KEY
                """,
                params=[chunk, scope, access_scope],
            ).collect()
        return len(rows)
