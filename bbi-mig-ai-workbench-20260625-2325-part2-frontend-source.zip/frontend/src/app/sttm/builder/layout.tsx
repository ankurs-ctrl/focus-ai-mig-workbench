'use client';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { SidebarHost } from '@/features/sttm/layout/sidebar-host';
import { SidebarSlotProvider, useSidebarSlot } from '@/features/sttm/layout/sidebar-slot-context';
import { usePathname, useRouter } from 'next/navigation';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import {
  getSelectedSourceTables,
  getSelectedTargetTable,
} from '@/features/sttm/shared/sttm-selection-utils';
import { dbService } from '@/services/dbService';
import { AiaResizeHandle } from '@/components/ui/aia-resize-handle';
import { SttmSidebarCollapseFooter } from '@/features/sttm/layout/sttm-sidebar-collapse-footer';
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  IconButton,
  LinearProgress,
  Stack,
  Typography,
} from '@mui/material';

type SemanticPrepState = {
  open: boolean;
  loading: boolean;
  progress: number;
  title: string;
  detail: string;
  error?: string | null;
};

const initialSemanticPrepState: SemanticPrepState = {
  open: false,
  loading: false,
  progress: 0,
  title: 'Preparing semantic view',
  detail: 'Checking the current source-to-target selection.',
  error: null,
};

const MIN_SIDEBAR_WIDTH = 248;
const MAX_SIDEBAR_WIDTH = 420;
const COLLAPSED_SIDEBAR_WIDTH = 54;

function BuilderLayoutShell({ children }: { children: ReactNode }) {
  const [semanticPrepState, setSemanticPrepState] = useState<SemanticPrepState>(initialSemanticPrepState);
  const router = useRouter();
  const pathname = usePathname();
  const { content, collapsed, setCollapsed, width, setWidth } = useSidebarSlot();
  const resizeStateRef = useRef<{ startX: number; startWidth: number } | null>(null);
  const proceedToMappingRef = useRef<() => void>(() => {});
  const {
    fullData,
    derivedSources,
    relationships,
    applySemanticRefresh,
    semanticBundleId,
    semanticViewName,
  } = useSttmBuilderContext();

  const selectedSourceTables = useMemo(
    () => getSelectedSourceTables(fullData?.sources ?? []),
    [fullData?.sources],
  );

  const selectedTargetTable = useMemo(
    () => getSelectedTargetTable(fullData?.targets ?? []),
    [fullData?.targets],
  );

  useEffect(() => {
    const handlePointerMove = (event: MouseEvent) => {
      const state = resizeStateRef.current;
      if (!state) {
        return;
      }
      const nextWidth = Math.min(
        MAX_SIDEBAR_WIDTH,
        Math.max(MIN_SIDEBAR_WIDTH, state.startWidth + event.clientX - state.startX),
      );
      setWidth(nextWidth);
    };

    const handlePointerUp = () => {
      resizeStateRef.current = null;
    };

    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
    };
  }, [setWidth]);

  const beginResize = (event: React.MouseEvent<HTMLDivElement>) => {
    resizeStateRef.current = {
      startX: event.clientX,
      startWidth: width,
    };
  };

  const makeTableRef = (qualifiedName: string) => {
    const [database, schema, table] = qualifiedName.split('.', 3);
    return { database, schema, table };
  };

  const isWorkspacePage = pathname.includes('/mapping') || pathname.includes('/summary');
  const showSidebarHost = !isWorkspacePage && content !== null;

  const canProceedToMapping = useMemo(
    () =>
      (selectedSourceTables.length > 0 || derivedSources.some((source) => source.isSelected)) &&
      Boolean(selectedTargetTable),
    [derivedSources, selectedSourceTables, selectedTargetTable],
  );

  const selectedDerivedSourceIds = useMemo(
    () => derivedSources.filter((source) => source.isSelected).map((source) => source.id),
    [derivedSources],
  );

  const proceedToMapping = async () => {
    if (!canProceedToMapping) {
      return;
    }

    const selectedTarget = selectedTargetTable;
    if (!selectedTarget) {
      return;
    }

    setSemanticPrepState({
      open: true,
      loading: true,
      progress: 12,
      title: 'Opening mapping workspace',
      detail: 'Using the current source, join, and target context while semantic preparation continues in the background.',
      error: null,
    });

    setSemanticPrepState((current) => ({
      ...current,
      progress: 52,
      detail: semanticBundleId || semanticViewName
        ? 'Reusing the current semantic context and opening mapping now.'
        : 'Opening mapping now and continuing semantic preparation in the background.',
    }));

    void dbService.refreshSemanticContext({
      selected_source_tables: selectedSourceTables.map((table) => makeTableRef(table.qualifiedName)),
      selected_derived_sources: selectedDerivedSourceIds,
      target_table: makeTableRef(selectedTarget.qualifiedName),
      relationships: relationships
        .filter((join) => join.leftTableId && join.rightTableId && join.conditions?.length)
        .map((join) => ({
          left_table: makeTableRef(join.leftTableId as string),
          right_table: makeTableRef(join.rightTableId as string),
          constraint_name: join.constraintName ?? null,
          join_type: join.joinType ?? 'INNER',
          source: join.source ?? 'USER_DEFINED',
          locked: join.locked ?? false,
          conditions: (join.conditions ?? []).map((condition) => ({
            left_column: condition.leftColumn,
            right_column: condition.rightColumn,
            operator: condition.operator ?? '=',
          })),
        })),
      requested_level: 'L3_MAPPING_ENRICHED',
      force: false,
    })
      .then((refresh) => {
        applySemanticRefresh(refresh);
      })
      .catch((error) => {
        console.warn("Background semantic refresh did not complete before mapping opened.", error);
      });

    window.setTimeout(() => {
      setSemanticPrepState({
        open: true,
        loading: false,
        progress: 100,
        title: semanticBundleId || semanticViewName ? 'Opening mapping with current context' : 'Opening mapping',
        detail: semanticBundleId || semanticViewName
          ? 'Mapping is opening with the current semantic context while freshness checks continue in the background.'
          : 'Mapping is opening now. Semantic preparation will continue in the background and update the current context when it completes.',
        error: null,
      });
      window.setTimeout(() => {
        setSemanticPrepState(initialSemanticPrepState);
        router.push('/sttm/builder/new/mapping');
      }, 250);
    }, 150);
  };

  useEffect(() => {
    proceedToMappingRef.current = () => {
      void proceedToMapping();
    };
  });

  useEffect(() => {
    const handleProceedToMapping = () => {
      if (pathname.includes('/mapping') || pathname.includes('/summary')) {
        return;
      }
      proceedToMappingRef.current();
    };

    window.addEventListener('sttm:proceed-to-mapping', handleProceedToMapping);
    return () => {
      window.removeEventListener('sttm:proceed-to-mapping', handleProceedToMapping);
    };
  }, [pathname]);

  return (
    <>
      <div className="flex h-full min-h-0 flex-1 flex-col overflow-hidden bg-gray-50">
        <div className="flex min-h-0 flex-1 overflow-hidden">
          {showSidebarHost ? (
            <aside
              className="hidden shrink-0 border-r border-gray-200 bg-white md:flex"
              style={{ width: collapsed ? COLLAPSED_SIDEBAR_WIDTH : width }}
            >
              {collapsed ? (
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    minHeight: 0,
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  <Box sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
                    <SidebarHost />
                  </Box>
                  <SttmSidebarCollapseFooter
                    collapsed
                    centered
                    expandLabel="Expand source sidebar"
                    onToggle={() => setCollapsed(false)}
                  />
                </Box>
              ) : (
                <Box sx={{ display: 'flex', width: '100%', minWidth: 0, height: '100%', minHeight: 0 }}>
                  <Box sx={{ minWidth: 0, flex: 1, height: '100%', minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
                    <Box sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
                      <SidebarHost />
                    </Box>
                  </Box>
                  <AiaResizeHandle
                    direction="horizontal"
                    onMouseDown={beginResize}
                    sx={{ alignSelf: 'stretch', height: '100%' }}
                  />
                </Box>
              )}
            </aside>
          ) : null}

          <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
            <main
              className={
                isWorkspacePage
                  ? 'flex min-h-0 flex-1 overflow-hidden bg-white'
                  : 'flex min-h-0 flex-1 flex-col overflow-hidden bg-white'
              }
            >
              {children}
            </main>
          </div>
        </div>
      </div>
      <Dialog
        open={semanticPrepState.open}
        onClose={() => {
          if (!semanticPrepState.loading) {
            setSemanticPrepState(initialSemanticPrepState);
          }
        }}
        maxWidth="xs"
        fullWidth
      >
        <Box sx={{ p: 3 }}>
          <Stack spacing={2}>
            <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center' }}>
              {semanticPrepState.loading ? <CircularProgress size={22} /> : null}
              <Box>
                <Typography sx={{ fontSize: 16, fontWeight: 800, color: '#0f172a' }}>
                  {semanticPrepState.title}
                </Typography>
                <Typography sx={{ fontSize: 13, color: '#475569', mt: 0.5 }}>
                  {semanticPrepState.detail}
                </Typography>
              </Box>
            </Stack>
            <LinearProgress
              variant="determinate"
              value={semanticPrepState.progress}
              sx={{
                height: 8,
                borderRadius: 999,
                backgroundColor: '#e2e8f0',
                '& .MuiLinearProgress-bar': {
                  borderRadius: 999,
                  backgroundColor: '#2563eb',
                },
              }}
            />
            {semanticPrepState.error ? (
              <Box
                sx={{
                  borderRadius: 2,
                  border: '1px solid #fecaca',
                  backgroundColor: '#fef2f2',
                  px: 1.5,
                  py: 1.25,
                }}
              >
                <Typography sx={{ fontSize: 13, color: '#b91c1c' }}>
                  {semanticPrepState.error}
                </Typography>
              </Box>
            ) : null}
            {!semanticPrepState.loading ? (
              <Stack direction="row" spacing={1} sx={{ justifyContent: 'flex-end' }}>
                <Button
                  onClick={() => setSemanticPrepState(initialSemanticPrepState)}
                  sx={{ textTransform: 'none' }}
                >
                  Close
                </Button>
              </Stack>
            ) : null}
          </Stack>
        </Box>
      </Dialog>
    </>
  );
}

export default function BuilderLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <SidebarSlotProvider>
      <BuilderLayoutShell>{children}</BuilderLayoutShell>
    </SidebarSlotProvider>
  );
}
