export type JoinConnector = "AND" | "OR";

/** The first condition has no connector. Anything other than OR is AND. */
export function readJoinConnector(value: unknown, index: number): JoinConnector {
  if (index <= 0) return "AND";
  return String(value ?? "").trim().toUpperCase() === "OR" ? "OR" : "AND";
}

/** Keep the field only when a join actually stored one, so untouched joins stay unchanged. */
export function joinConnectorPayload(
  value: unknown,
): { connector: JoinConnector } | Record<string, never> {
  const token = String(value ?? "").trim().toUpperCase();
  if (token === "AND" || token === "OR") return { connector: token };
  return {};
}

/**
 * Join predicate fragments. `prefix` is the text before each later connector,
 * so an all-AND list matches the previous `join(prefix + "AND ")` output.
 */
export function joinOnPredicate(
  parts: Array<{ sql: string; connector?: unknown }>,
  prefix: string,
): string {
  return parts.reduce((combined, part, index) => {
    if (index === 0) return part.sql;
    return `${combined}${prefix}${readJoinConnector(part.connector, index)} ${part.sql}`;
  }, "");
}

/** One comparison, or a parenthesized group of comparisons. */
export type JoinTerm = {
  id: string;
  connector: JoinConnector;
  leftColumn: string;
  operator: string;
  rightColumn: string;
  children?: JoinTerm[];
};

export type JoinPredicateContext = {
  leftSql: string;
  rightSql: string;
  leftAliases: string[];
  rightAliases: string[];
  leftColumns: string[];
  rightColumns: string[];
};

type PredicateTable = { id?: string; name?: string; columns?: Array<{ name?: string }> };
type PredicateRelation = { identity: string; alias: string; displaySeed?: string | null };

let termSequence = 0;

export function newJoinTermId(): string {
  termSequence += 1;
  return `join-term-${termSequence}`;
}

export function blankJoinTerm(connector: JoinConnector = "AND"): JoinTerm {
  return { id: newJoinTermId(), connector, leftColumn: "", operator: "=", rightColumn: "", };
}

export function blankJoinGroup(connector: JoinConnector = "AND"): JoinTerm {
  return { ...blankJoinTerm(connector), children: [blankJoinTerm()] };
}

export function clearJoinTermColumn(rows: JoinTerm[], side: "leftColumn" | "rightColumn"): JoinTerm[] {
  return rows.map((row) => ({
    ...row,
    [side]: "",
    children: row.children ? clearJoinTermColumn(row.children, side) : row.children,
  }));
}

export function joinTermsHaveGroup(rows: JoinTerm[]): boolean {
  return rows.some((row) => Array.isArray(row.children) && termHasContent(row));
}

export function joinTermsHaveComparison(rows: JoinTerm[]): boolean {
  return rows.some((row) => row.children
    ? joinTermsHaveComparison(row.children)
    : Boolean(row.leftColumn && row.operator && row.rightColumn));
}

export function buildJoinPredicateContext(input: {
  leftTableId: string;
  rightTableId: string;
  tables: PredicateTable[];
  previewRelations: PredicateRelation[];
  displayAliases?: Map<string, string>;
}): JoinPredicateContext {
  const aliasFor = (tableId: string) => {
    const index = input.tables.findIndex((table) => table.id === tableId);
    return input.previewRelations[index]?.alias ?? input.tables[index]?.name ?? "";
  };
  const qualifiers = (tableId: string) => {
    const table = input.tables.find((item) => item.id === tableId);
    const relation = input.previewRelations[input.tables.findIndex((item) => item.id === tableId)];
    const values = [aliasFor(tableId), table?.name ?? "", relation?.alias ?? "", relation?.identity ?? ""];
    const display = input.displayAliases?.get(String(relation?.alias ?? "").toUpperCase())
      ?? input.displayAliases?.get(String(relation?.identity ?? "").toUpperCase());
    if (display) values.push(display);
    return values.map((value) => value.trim()).filter(Boolean);
  };
  const columns = (tableId: string) => (input.tables.find((item) => item.id === tableId)?.columns ?? [])
    .map((column) => String(column.name ?? ""))
    .filter(Boolean);
  return {
    leftSql: aliasFor(input.leftTableId),
    rightSql: aliasFor(input.rightTableId),
    leftAliases: qualifiers(input.leftTableId),
    rightAliases: qualifiers(input.rightTableId),
    leftColumns: columns(input.leftTableId),
    rightColumns: columns(input.rightTableId),
  };
}

export function formatJoinTerms(rows: JoinTerm[], context: JoinPredicateContext): string {
  const formatted = formatTermList(rows.filter(termHasContent), context, true);
  return formatted;
}

/** Turn a column-shaped ON clause back into rows. Anything else returns null. */
export function parseJoinPredicate(sql: string, context: JoinPredicateContext): JoinTerm[] | null {
  const source = sql.trim().replace(/^\s*ON\s+/i, "").replace(/;\s*$/, "").trim();
  if (!source) return null;
  const tokens = tokenizePredicate(source);
  if (!tokens) return null;
  const parsed = parseOr(tokens, { index: 0 });
  if (!parsed || parsed.index !== tokens.length) return null;
  const node = parsed.node.k === "list" && parsed.node.explicit ? { ...parsed.node, explicit: false } : parsed.node;
  const terms = lowerNode(node, context);
  return terms && joinTermsHaveComparison(terms) ? terms : null;
}

function termHasContent(row: JoinTerm): boolean {
  return row.children ? row.children.some(termHasContent) : Boolean(row.leftColumn && row.operator && row.rightColumn);
}

function formatTermList(rows: JoinTerm[], context: JoinPredicateContext, top: boolean): string {
  const visible = rows.filter(termHasContent);
  return visible.map((row, index) => {
    const body = row.children
      ? `(${formatTermList(row.children, context, false)})`
      : `${quoteSqlName(context.leftSql)}.${quoteSqlName(row.leftColumn)} ${row.operator || "="} ${quoteSqlName(context.rightSql)}.${quoteSqlName(row.rightColumn)}`;
    if (index === 0) return body;
    return `${top ? "\n  " : " "}${row.connector === "OR" ? "OR" : "AND"} ${body}`;
  }).join("");
}

function quoteSqlName(value: string): string {
  return /^[A-Za-z_][A-Za-z0-9_$]*$/.test(value) ? value : `"${value.replace(/"/g, "\"\"")}"`;
}

type Token =
  | { t: "lp" | "rp" | "dot" | "and" | "or" }
  | { t: "op"; v: string }
  | { t: "id"; v: string };

function tokenizePredicate(source: string): Token[] | null {
  const tokens: Token[] = [];
  let index = 0;
  while (index < source.length) {
    const char = source[index];
    if (/\s/.test(char)) { index += 1; continue; }
    if (char === "(") { tokens.push({ t: "lp" }); index += 1; continue; }
    if (char === ")") { tokens.push({ t: "rp" }); index += 1; continue; }
    if (char === ".") { tokens.push({ t: "dot" }); index += 1; continue; }
    const operator = source.slice(index).match(/^(<>|!=|>=|<=|=|>|<)/);
    if (operator) { tokens.push({ t: "op", v: operator[1] === "<>" ? "!=" : operator[1] }); index += operator[1].length; continue; }
    const quoted = source.slice(index).match(/^"((?:""|[^"])*)"/);
    if (quoted) { tokens.push({ t: "id", v: quoted[1].replace(/""/g, "\"") }); index += quoted[0].length; continue; }
    const word = source.slice(index).match(/^[A-Za-z_][A-Za-z0-9_$]*/);
    if (!word) return null;
    const text = word[0];
    const kind = text.toUpperCase();
    tokens.push(kind === "AND" ? { t: "and" } : kind === "OR" ? { t: "or" } : { t: "id", v: text });
    index += text.length;
  }
  return tokens;
}

type CmpNode = { k: "cmp"; leftQualifier: string; leftColumn: string; operator: string; rightQualifier: string; rightColumn: string };
type ListNode = { k: "list"; logic: "AND" | "OR"; items: AstNode[]; explicit: boolean };
type AstNode = CmpNode | ListNode;

function parseOr(tokens: Token[], cursor: { index: number }): { node: AstNode; index: number } | null {
  const left = parseAnd(tokens, cursor);
  if (!left) return null;
  const items = [left.node];
  let index = left.index;
  while (tokens[index]?.t === "or") {
    const next = parseAnd(tokens, { index: index + 1 });
    if (!next) return null;
    items.push(next.node);
    index = next.index;
  }
  return { node: items.length === 1 ? items[0] : { k: "list", logic: "OR", items, explicit: false }, index };
}

function parseAnd(tokens: Token[], cursor: { index: number }): { node: AstNode; index: number } | null {
  const left = parsePrimary(tokens, cursor);
  if (!left) return null;
  const items = [left.node];
  let index = left.index;
  while (tokens[index]?.t === "and") {
    const next = parsePrimary(tokens, { index: index + 1 });
    if (!next) return null;
    items.push(next.node);
    index = next.index;
  }
  return { node: items.length === 1 ? items[0] : { k: "list", logic: "AND", items, explicit: false }, index };
}

function parsePrimary(tokens: Token[], cursor: { index: number }): { node: AstNode; index: number } | null {
  if (tokens[cursor.index]?.t === "lp") {
    const inner = parseOr(tokens, { index: cursor.index + 1 });
    if (!inner || tokens[inner.index]?.t !== "rp") return null;
    const node = inner.node.k === "cmp" ? inner.node : { ...inner.node, explicit: true };
    return { node, index: inner.index + 1 };
  }
  return parseComparison(tokens, cursor);
}

function parseComparison(tokens: Token[], cursor: { index: number }): { node: CmpNode; index: number } | null {
  const left = parseQualified(tokens, cursor.index);
  if (!left || tokens[left.index]?.t !== "op") return null;
  const operator = (tokens[left.index] as { v: string }).v;
  const right = parseQualified(tokens, left.index + 1);
  if (!right) return null;
  return {
    node: {
      k: "cmp",
      leftQualifier: left.qualifier,
      leftColumn: left.column,
      operator,
      rightQualifier: right.qualifier,
      rightColumn: right.column,
    },
    index: right.index,
  };
}

function parseQualified(tokens: Token[], index: number): { qualifier: string; column: string; index: number } | null {
  const qualifier = tokens[index];
  const dot = tokens[index + 1];
  const column = tokens[index + 2];
  if (qualifier?.t !== "id" || dot?.t !== "dot" || column?.t !== "id") return null;
  if (tokens[index + 3]?.t === "dot") return null;
  return { qualifier: qualifier.v, column: column.v, index: index + 3 };
}

function lowerNode(node: AstNode, context: JoinPredicateContext): JoinTerm[] | null {
  if (node.k === "cmp") {
    const term = comparisonTerm(node, "AND", context);
    return term ? [term] : null;
  }
  if (node.explicit) {
    const children = lowerList(node, context);
    if (!children?.length) return null;
    return [{ ...blankJoinTerm(), children }];
  }
  if (node.logic === "OR" && node.items.every((item) => isPlainAndChain(item))) {
    const rows: JoinTerm[] = [];
    for (let index = 0; index < node.items.length; index += 1) {
      const item = node.items[index];
      const chain = item.k === "cmp" ? [item] : item.items;
      for (let childIndex = 0; childIndex < chain.length; childIndex += 1) {
        const cmp = chain[childIndex];
        if (cmp.k !== "cmp") return null;
        const term = comparisonTerm(cmp, index === 0 && childIndex === 0 ? "AND" : childIndex === 0 ? "OR" : "AND", context);
        if (!term) return null;
        rows.push(term);
      }
    }
    return rows;
  }
  if (node.logic === "AND" && node.items.every((item) => item.k === "cmp")) {
    return lowerComparisons(node.items, "AND", context);
  }
  return lowerList(node, context);
}

function lowerList(node: ListNode, context: JoinPredicateContext): JoinTerm[] | null {
  const rows: JoinTerm[] = [];
  for (let index = 0; index < node.items.length; index += 1) {
    const lowered = lowerNode(node.items[index], context);
    if (!lowered?.length) return null;
    const connector: JoinConnector = index === 0 ? "AND" : node.logic;
    const andChain = lowered.every((row, childIndex) => childIndex === 0 || (row.connector !== "OR" && !row.children));
    if (lowered.length === 1) rows.push({ ...lowered[0], connector });
    else if (node.logic === "OR" && andChain) {
      rows.push({ ...lowered[0], connector }, ...lowered.slice(1));
    } else {
      rows.push({
        ...blankJoinTerm(connector),
        children: lowered.map((row, childIndex) => childIndex === 0 ? { ...row, connector: "AND" } : row),
      });
    }
  }
  return rows;
}

function lowerComparisons(items: AstNode[], logic: "AND" | "OR", context: JoinPredicateContext): JoinTerm[] | null {
  const rows: JoinTerm[] = [];
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    if (item.k !== "cmp") return null;
    const term = comparisonTerm(item, index === 0 ? "AND" : logic, context);
    if (!term) return null;
    rows.push(term);
  }
  return rows;
}

function isPlainAndChain(node: AstNode): boolean {
  if (node.k === "cmp") return true;
  return !node.explicit && node.logic === "AND" && node.items.every((item) => item.k === "cmp");
}

const FLIP_OPERATOR: Record<string, string> = { ">": "<", "<": ">", ">=": "<=", "<=": ">=", "=": "=", "!=": "!=" };

function comparisonTerm(node: CmpNode, connector: JoinConnector, context: JoinPredicateContext): JoinTerm | null {
  const leftSide = qualifierSide(node.leftQualifier, context);
  const rightSide = qualifierSide(node.rightQualifier, context);
  if (!leftSide || !rightSide || leftSide === rightSide) return null;
  const swapped = leftSide === "right";
  const leftColumn = canonicalColumn(swapped ? node.rightColumn : node.leftColumn, context.leftColumns);
  const rightColumn = canonicalColumn(swapped ? node.leftColumn : node.rightColumn, context.rightColumns);
  const operator = swapped ? FLIP_OPERATOR[node.operator] ?? node.operator : node.operator;
  if (!["=", "!=", ">", "<", ">=", "<="].includes(operator)) return null;
  return { ...blankJoinTerm(connector), leftColumn, operator, rightColumn };
}

function qualifierSide(qualifier: string, context: JoinPredicateContext): "left" | "right" | null {
  const key = qualifier.trim().toUpperCase();
  const left = context.leftAliases.some((alias) => alias.toUpperCase() === key);
  const right = context.rightAliases.some((alias) => alias.toUpperCase() === key);
  if (left === right) return null;
  return left ? "left" : "right";
}

function canonicalColumn(column: string, columns: string[]): string {
  return columns.find((item) => item.toUpperCase() === column.toUpperCase()) ?? column;
}
