"use client";
import { AiaBox, AiaPaper } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { CAPTION_SX, SECONDARY_TEXT_SX } from '@/config/typography-tokens';
import type { STTMRecord } from '@/services/projectService';

export default function QuickStatsPanel({ sttms }: { sttms: STTMRecord[] }) {
    const total = sttms.length;
    const published = sttms.filter((row) => ['COMPLETE', 'COMPLETED', 'PUBLISHED'].includes(row.status?.toUpperCase())).length;
    const percent = (count: number) => total ? Math.round((count / total) * 100) : 0;
    const averageCoverage = total ? Math.round(sttms.reduce((sum, row) => sum + (Number(row.coverage_percent) || 0), 0) / total) : 0;
    const quickStats = [
        { label: 'Average mapping coverage', value: averageCoverage, color: '#6B7280' },
        { label: 'Published', value: percent(published), color: '#6B7280' },
        { label: 'In Progress', value: percent(total - published), color: '#F97316' },
    ];
    return (
        <AiaPaper
            elevation={0}
            className="rounded-[20px] border border-[#EEF2F7] bg-white p-5"
        >
            <AiaText sx={{ ...CAPTION_SX, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                Quick Stats
            </AiaText>

            <AiaBox className="mt-5 flex flex-col gap-5">
                {quickStats.map((item) => (
                    <AiaBox key={item.label}>
                        <AiaBox className="mb-2 flex items-center justify-between">
                            <AiaText sx={{ ...SECONDARY_TEXT_SX, fontWeight: 500, color: "#4B5563" }}>
                                {item.label}
                            </AiaText>
                            <AiaText sx={{ ...CAPTION_SX, fontWeight: 600, color: "#111827" }}>
                                {item.value}%
                            </AiaText>
                        </AiaBox>

                        <AiaBox className="h-[6px] rounded-full bg-[#ECEFF3]">
                            <AiaBox
                                className="h-[6px] rounded-full"
                                sx={{
                                    width: `${item.value}%`,
                                    backgroundColor: item.color,
                                }}
                            />
                        </AiaBox>
                    </AiaBox>
                ))}
            </AiaBox>
        </AiaPaper>
    );
}
