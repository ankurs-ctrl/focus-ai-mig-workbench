import type { TableNode } from '@/features/sttm/types/sttm.types';
import { relationAliasFor } from '@/features/sttm/mapping/relation-alias';

/** Restore query occurrences from the saved graph, never from a deduplicated catalog list. */
export function restoreImportedPhysicalInstances(tables: TableNode[], nodes: Array<Record<string, unknown>>): TableNode[] {
  const imported = nodes.filter(node => node.kind === 'PHYSICAL_TABLE' && String(node.relation_id ?? '').startsWith('sql-instance:'));
  if (!imported.length) return tables;
  const ids = new Set<string>();
  const restored = imported.map(node => {
    const id = String(node.relation_id);
    const table = node.table as Record<string, unknown> | undefined;
    if (ids.has(id) || !table?.database || !table.schema || !table.table || relationAliasFor(id) !== node.alias)
      throw new Error('The saved SQL relation-instance contract is inconsistent. No replacement bindings were inferred.');
    ids.add(id);
    const qualifiedName = `${table.database}.${table.schema}.${table.table}`;
    const template = tables.find(candidate => candidate.qualifiedName === qualifiedName);
    return {...template, tableId:id, qualifiedName, tableName:String(table.table), isSelected:true,
      tag:template?.tag ?? '', rows:template?.rows ?? '', columns:template?.columns ?? 0};
  });
  const represented = new Set(restored.map(table => table.qualifiedName));
  return [...tables.filter(table => !ids.has(table.tableId)).map(table => ({...table,
    isSelected:table.isSelected && !represented.has(table.qualifiedName)})), ...restored];
}
