type OrderedMessage = { role: 'user' | 'assistant'; id: string; content: string; kind?: 'progress' | 'final' };

/** Restored history may contain the final answer before durable progress is replayed. */
export function insertProgressBeforeFinal<T extends OrderedMessage>(messages: T[], progress: T): T[] {
  const lastUser = messages.findLastIndex((message) => message.role === 'user');
  const firstFinal = messages.findIndex((message, index) => index > lastUser && message.role === 'assistant' && message.kind === 'final');
  if (firstFinal < 0) return [...messages, progress];
  return [...messages.slice(0, firstFinal), progress, ...messages.slice(firstFinal)];
}

/** Replace the restored copy of an answer with its durable event instead of showing it twice. */
export function appendOrReplaceFinal<T extends OrderedMessage>(messages: T[], final: T): T[] {
  const lastUser = messages.findLastIndex((message) => message.role === 'user');
  const duplicate = messages.findIndex((message, index) => index > lastUser && message.role === 'assistant'
    && message.kind === 'final' && message.content.trim() === final.content.trim());
  if (duplicate < 0) return [...messages, final];
  return messages.map((message, index) => index === duplicate ? final : message);
}
