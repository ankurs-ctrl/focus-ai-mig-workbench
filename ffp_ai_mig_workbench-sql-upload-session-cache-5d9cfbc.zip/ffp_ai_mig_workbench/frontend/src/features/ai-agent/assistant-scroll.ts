export type AssistantScrollMetrics = {
  scrollTop: number;
  scrollHeight: number;
  clientHeight: number;
};

export type AssistantScrollState = AssistantScrollMetrics & { following: boolean };
export type AssistantScrollEvent = "layout" | "scroll" | "jump";

const NEAR_BOTTOM_PX = 64;
const POSITION_EPSILON = 1;

/** Layout changes never change intent: only scrolling or Jump to latest can. */
export function updateAssistantScroll(
  previous: AssistantScrollState | undefined,
  metrics: AssistantScrollMetrics,
  event: AssistantScrollEvent,
) {
  const bottom = Math.max(0, metrics.scrollHeight - metrics.clientHeight);
  const currentTop = Math.max(0, Math.min(metrics.scrollTop, bottom));
  const previousTop = Math.max(0, Math.min(previous?.scrollTop ?? currentTop, bottom));
  let following = previous?.following ?? true;
  let scrollTop = previousTop;

  if (event === "jump") {
    following = true;
  } else if (event === "scroll" && Math.abs(currentTop - previousTop) > POSITION_EPSILON) {
    // Ignore our own writes and browser clamping when content shrinks. In
    // particular, a temporarily non-overflowing transcript cannot resume follow.
    following = currentTop > previousTop && bottom - currentTop <= NEAR_BOTTOM_PX;
    scrollTop = currentTop;
  }

  if (following && event !== "scroll") scrollTop = bottom;
  return {
    state: { ...metrics, scrollTop, following } satisfies AssistantScrollState,
    scrollTop,
    showJump: !following && bottom - scrollTop > POSITION_EPSILON,
  };
}