"use client";

export default function AppBootstrapFallback() {
  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#F7F8FA]">
      <div className="h-14 shrink-0 border-b border-[#e5e7eb] bg-white" />
      <div className="flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-sm text-[#64748b]">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-[#cbd5e1] border-t-[#2563eb]" />
          <span>Loading workspace…</span>
        </div>
      </div>
    </div>
  );
}
