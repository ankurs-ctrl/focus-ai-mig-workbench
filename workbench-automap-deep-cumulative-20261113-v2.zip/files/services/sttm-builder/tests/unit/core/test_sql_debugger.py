"""The SQL debugger finds the root cause of a failing mapping query, fixes it and verifies the fix.

Fixtures reproduce the failures from run 18: placeholders left in rules
(``<BizAcctMaster>``, ``'<FIRM_CODE>-'``), an ambiguous column, a column read
from the wrong table, an invented function, and values that do not convert.
"""
from __future__ import annotations

import re
from types import SimpleNamespace

from app.agent_runs.contracts import MappingContextPackageV1
from app.agent_tools.sql_debugger import (
    AMBIGUOUS_COLUMN,
    DATE_CONVERSION,
    DIVISION_BY_ZERO,
    INVALID_IDENTIFIER,
    NUMERIC_CONVERSION,
    SYNTAX,
    UNKNOWN_FUNCTION,
    DebugContext,
    SqlDebugger,
    classify,
    guard_divisors,
    locate_by_line,
    replace_placeholders,
    try_conversions,
)
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.schema.common import TableRef
from app.schema.mapping_sql import (
    MappingSqlCompileResponse,
    MappingSqlMappingItem,
    MappingSqlPreviewResponse,
    MappingSqlReviewResponse,
)
from app.schema.workspace_context import WorkbenchContextSnapshotV1

ACTIVITIES = "DB.SRC.ACTIVITIES"
LINKS = "DB.SRC.ACTIVITIES_CONTACTS"


def _item(target: str, expression: str | None, dependencies: list[str] | None = None) -> MappingSqlMappingItem:
    return MappingSqlMappingItem(target_column=target, expression=expression, status="MAPPED",
                                 source_columns=dependencies or [], source_dependencies=dependencies or [])


def _context() -> DebugContext:
    return DebugContext(
        relation_columns={ACTIVITIES: {"ID", "SUBJECT", "PRIORITY", "AMOUNT", "START_DATE"},
                          LINKS: {"ID", "ACTIVITY_ID", "CONTACT_ID"}},
        placeholder_values={"FIRMCODE": ("'EN'", "EN"), "BIZACCTMASTER": None},
        target_types={"SUBJECT": "VARCHAR(10)"},
    )


def test_errors_are_classified_without_carrying_data_values() -> None:
    assert classify("SQL compilation error:\nambiguous column name 'ID'").category == AMBIGUOUS_COLUMN
    assert classify("SQL compilation error: error line 3 at position 4\ninvalid identifier 'A.CONTACT_ID'").subject == "A.CONTACT_ID"
    assert classify("SQL compilation error:\nUnknown function LOOKUP_OWNER").category == UNKNOWN_FUNCTION
    assert classify("syntax error line 7 at position 12 unexpected '<'.").category == SYNTAX
    numeric = classify("100038 (22018): Numeric value 'Jane Doe' is not recognized")
    assert numeric.category == NUMERIC_CONVERSION and numeric.subject == "" and "Jane" not in numeric.message
    assert classify("Date '31/31/2020' is not recognized").category == DATE_CONVERSION
    assert classify("100051 (22012): Division by zero").category == DIVISION_BY_ZERO
    assert classify("Undefined relation or alias in dependency: X.Y (target: OWNERID)").targets == ["OWNERID"]


def test_standard_fixes_are_valid_snowflake() -> None:
    assert try_conversions("CAST(S1.START_DATE AS DATE)") == "TRY_CAST(TO_VARCHAR(S1.START_DATE) AS DATE)"
    assert try_conversions("TO_NUMBER(S1.CODE, 10)") == "TRY_TO_NUMBER(TO_VARCHAR(S1.CODE), 10)"
    assert try_conversions("TRY_TO_NUMBER(S1.CODE)") is None
    assert guard_divisors("S1.A / S1.B * 100") == "S1.A / NULLIF(S1.B, 0) * 100"
    # A cast to a short text type fails before an outer LEFT runs (run 20).
    from app.agent_tools.sql_debugger import fit_length
    assert fit_length("CAST(t.X AS VARCHAR(40))", "VARCHAR(40)") == "LEFT(TO_VARCHAR(t.X), 40)"
    assert fit_length("UPPER(t.X)", "VARCHAR(18)") == "LEFT(UPPER(t.X), 18)"
    assert replace_placeholders("CONCAT('<FIRM_CODE>-', S1.ID)", {"FIRMCODE": ("'EN'", "EN")}) == ("CONCAT('EN-', S1.ID)", [])
    assert replace_placeholders("<Firm Code> || S1.ID", {"FIRMCODE": ("'EN'", "EN")}) == ("'EN' || S1.ID", [])
    assert replace_placeholders("<BizAcctMaster>.ID", {}) == (None, ["BizAcctMaster"])


def test_lint_substitutes_known_values_and_holds_back_missing_ones() -> None:
    debugger = SqlDebugger(context=_context(), compile_subset=lambda subset: (None, None))
    outcome = debugger.lint([
        _item("LEGACY_ID__C", "CONCAT('<FIRM_CODE>-', CAST(ID AS VARCHAR))", [f"{ACTIVITIES}.ID"]),
        _item("ACCOUNTID", "<BizAcctMaster>.TARGET_CRM_ID"),
        _item("SUBJECT", None, [f"{ACTIVITIES}.SUBJECT"]),
    ])
    fixed = {item.target_column: item.expression for item in outcome.items}
    # The placeholder is replaced and the bare ID (produced by two relations)
    # is qualified by the row's own dependency.
    assert fixed["LEGACY_ID__C"] == f"CONCAT('EN-', CAST({ACTIVITIES}.ID AS VARCHAR))"
    assert "ACCOUNTID" in outcome.held and "<BizAcctMaster>" in outcome.held["ACCOUNTID"]
    assert [repair.category for repair in outcome.repairs] == ["placeholder", "ambiguous_column"]


def test_compile_repair_verifies_each_fix_before_keeping_it() -> None:
    calls = []

    def compile_subset(subset):
        calls.append([item.target_column for item in subset])
        for item in subset:
            expression = item.expression or ""
            if re.search(r"(?<![.\w])CONTACT_ID", expression) or "ACTIVITIES.CONTACT_ID" in expression:
                return None, RuntimeError("SQL compilation error:\ninvalid identifier 'ACTIVITIES.CONTACT_ID'")
        return SimpleNamespace(valid=True, ready=True, preview_sql="SELECT 1"), None

    debugger = SqlDebugger(context=_context(), compile_subset=compile_subset)
    items = [_item("WHOID", "ACTIVITIES.CONTACT_ID"), _item("SUBJECT", None, [f"{ACTIVITIES}.SUBJECT"])]
    first = compile_subset(items)[1]
    outcome = debugger.repair_compile(items, first)
    assert outcome.error is None and outcome.compiled is not None
    assert outcome.items[0].expression == f"{LINKS}.CONTACT_ID"
    assert outcome.repairs[0].category == INVALID_IDENTIFIER and outcome.repairs[0].method == "standard"
    assert ["WHOID"] in calls  # the fix was verified on the column alone first


def test_model_fix_is_used_only_when_no_standard_fix_exists_and_must_verify() -> None:
    def compile_subset(subset):
        if any("LOOKUP_OWNER(" in (item.expression or "") or "BAD(" in (item.expression or "") for item in subset):
            return None, RuntimeError("SQL compilation error:\nUnknown function LOOKUP_OWNER")
        return SimpleNamespace(valid=True, ready=True, preview_sql="SELECT 1"), None

    proposals = iter([("BAD(x)", "first try"), ("NULL", "no owner mapper is joined")])
    debugger = SqlDebugger(context=_context(), compile_subset=compile_subset,
                           model_fix=lambda item, diagnosis: next(proposals), max_model_repairs_per_column=1)
    items = [_item("OWNERID", "LOOKUP_OWNER(ACTIVITIES.USER_ID)")]
    outcome = debugger.repair_compile(items, compile_subset(items)[1])
    # One model proposal per column; it failed verification, so nothing is kept.
    assert outcome.error is not None and not outcome.repairs

    proposals = iter([("NULL", "no owner mapper is joined")])
    debugger = SqlDebugger(context=_context(), compile_subset=compile_subset,
                           model_fix=lambda item, diagnosis: next(proposals))
    outcome = debugger.repair_compile(items, compile_subset(items)[1])
    assert outcome.error is None and outcome.repairs[0].method == "model"


def test_syntax_error_line_points_at_the_select_item() -> None:
    rendered = "SELECT\n  ACTIVITIES.ID AS ID,\n  CASE\n    WHEN x THEN <bad>\n  END AS STATUS,\n  y AS SUBJECT\nFROM t"
    diagnosis = classify("syntax error line 4 at position 16 unexpected '<'.")
    assert locate_by_line(diagnosis, rendered, ["ID", "STATUS", "SUBJECT"]) == ["STATUS"]


def test_preview_repair_finds_the_failing_column_by_probing() -> None:
    probes = []

    def probe(subset):
        probes.append([item.target_column for item in subset])
        if any(re.search(r"(?<!TRY_)CAST\(", item.expression or "") for item in subset):
            return RuntimeError("100038 (22018): Numeric value 'n/a' is not recognized")
        return None

    debugger = SqlDebugger(context=_context(), compile_subset=lambda subset: (None, None), probe_subset=probe)
    items = [_item("PRIORITY", None, [f"{ACTIVITIES}.PRIORITY"]),
             _item("AMOUNT__C", "CAST(ACTIVITIES.AMOUNT AS NUMBER(18,2))"),
             _item("SUBJECT", "UPPER(ACTIVITIES.SUBJECT)")]
    outcome = debugger.repair_preview(items, probe(items))
    assert outcome.error is None
    assert outcome.items[1].expression == "TRY_CAST(TO_VARCHAR(ACTIVITIES.AMOUNT) AS DECIMAL(18, 2))"
    assert outcome.repairs[0].category == NUMERIC_CONVERSION
    assert ["PRIORITY"] not in probes  # plain source columns cannot fail a conversion


def test_budget_bounds_every_snowflake_call() -> None:
    calls = []

    def compile_subset(subset):
        calls.append(1)
        return None, RuntimeError("SQL compilation error:\nambiguous column name 'ID'")

    debugger = SqlDebugger(context=_context(), compile_subset=compile_subset, max_attempts=3)
    items = [_item(f"C{index}", "ID + 1", [f"{ACTIVITIES}.ID"]) for index in range(10)]
    debugger.repair_compile(items, compile_subset(items)[1])
    assert len(calls) <= 1 + 3


def test_agent_validation_repairs_compile_and_preview_errors_and_records_receipts() -> None:
    """End to end through _validate_generated_sql with a fake compiler and Snowflake."""
    compiled_requests = []

    class _MappingSql:
        def compile(self, request):
            compiled_requests.append(request)
            for item in request.mappings:
                if re.search(r"(?<![.\w])ID(?![\w])", item.expression or "") and "." not in (item.expression or "").split("ID")[0][-1:]:
                    raise RuntimeError("SQL compilation error:\nambiguous column name 'ID'")
            select = ", ".join(f"{item.expression or item.source_dependencies[0]} AS {item.target_column}"
                               for item in request.mappings)
            return MappingSqlCompileResponse(valid=True, ready=True, preview_sql=f"SELECT {select}",
                                             generated_sql=f"INSERT INTO T SELECT {select};")

        def review(self, request):
            return MappingSqlReviewResponse(valid=True, review_agent="SNOWFLAKE", syntax_valid=True,
                                            execution_ready=True, review_summary="ok",
                                            original_preview_sql=request.preview_sql,
                                            original_generated_sql=request.generated_sql)

        def probe_preview(self, preview_sql, *, limit):
            if re.search(r"(?<!TRY_)CAST\(", preview_sql):
                raise RuntimeError("Numeric value 'x' is not recognized")

        def preview(self, request):
            self.probe_preview(request.preview_sql, limit=request.preview_limit)
            return MappingSqlPreviewResponse(valid=True, variant_used="original",
                                             executed_preview_sql=request.preview_sql,
                                             executed_generated_sql=request.generated_sql)

    activities = TableRef(database="DB", schema="SRC", table="ACTIVITIES")
    links = TableRef(database="DB", schema="SRC", table="ACTIVITIES_CONTACTS")
    context = MappingContextPackageV1(
        run_id="run", thread_id="run", app_user_id="1", effective_role="R",
        workspace=WorkbenchContextSnapshotV1(
            source_tables=[activities, links], driving_table=activities,
            relationships=[{"left_table": activities.model_dump(), "right_table": links.model_dump(),
                            "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "ACTIVITY_ID"}]}],
        ),
    )
    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object(),  # type: ignore[arg-type]
                                         mapping_sql=_MappingSql())  # type: ignore[arg-type]
    rows = [
        {"id": "a", "target_column": "LEGACY_ID", "status": "draft", "source_columns": [f"{ACTIVITIES}.ID"],
         "expression": "'EN-' || ID"},
        {"id": "b", "target_column": "AMOUNT", "status": "draft", "source_columns": [f"{ACTIVITIES}.AMOUNT"],
         "expression": "CAST(ACTIVITIES.AMOUNT AS NUMBER)"},
    ]
    result = handlers._validate_generated_sql(
        state={"run_id": "run", "mapping_context_package": context.model_dump(mode="json")},
        target_table="DB.TGT.T", source_tables=[ACTIVITIES, LINKS],
        source_columns={ACTIVITIES: ["ID", "AMOUNT"], LINKS: ["ID", "ACTIVITY_ID"]},
        rows=rows, policy=SimpleNamespace(validation_depth="preview", preview_row_limit=20),
    )
    assert result["compile_valid"] is True and result["preview_valid"] is True
    categories = [repair["root_cause"] for repair in result["sql_repairs"]]
    assert categories == ["ambiguous_column", "numeric_conversion"]
    assert rows[0]["expression"] == f"'EN-' || {ACTIVITIES}.ID" and rows[0]["repairs"]
    assert rows[1]["expression"].startswith("TRY_CAST(") and rows[1]["status"] == "draft"
    assert result["validation_receipt"]["preview_valid"] is True
