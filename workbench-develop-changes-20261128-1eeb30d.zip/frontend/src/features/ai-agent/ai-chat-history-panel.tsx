"use client";

import { useMemo, useState } from "react";
import { DeleteChatDialog } from "./delete-chat-dialog";
import { InputBase } from "@mui/material";
import {
  AiaBox,
  AiaButton,
  AiaDialog,
  AiaDialogActions,
  AiaDialogContent,
  AiaDialogTitle,
  AiaIconButton,
  AiaMenu,
  AiaMenuItem,
  AiaStack,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { MODAL_ABOVE_AI_CHAT_Z_INDEX } from "@/features/ai-agent/ai-chat-layout-constants";
import type { StoredChatSession } from "@/features/ai-agent/ai-chat-session-utils";
import {
  formatSessionRelativeTime,
  groupSessionsByRecency,
} from "@/features/ai-agent/ai-chat-session-utils";
import {
  ChatBubbleOutlineRoundedIcon,
  ArchiveOutlinedIcon,
  PushPinOutlinedIcon,
  EditOutlinedIcon,
  MoreHorizIcon,
} from "@/utils/icons";

type AiChatHistoryPanelProps = {
  sessions: StoredChatSession[];
  searchQuery: string;
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  activeSessionId: string | null;
  onSelectSession: (session: StoredChatSession) => void;
  onRenameSession: (sessionId: string, title: string) => void;
  onDeleteSession: (sessionId: string) => Promise<void>;
  onArchiveSession: (session: StoredChatSession) => Promise<void>;
  onPinSession: (session: StoredChatSession) => Promise<void>;
};

export function AiChatHistoryPanel({
  sessions,
  searchQuery,
  loading,
  error,
  onRetry,
  activeSessionId,
  onSelectSession,
  onRenameSession,
  onDeleteSession,
  onArchiveSession,
  onPinSession,
}: AiChatHistoryPanelProps) {
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null);
  const [menuSession, setMenuSession] = useState<StoredChatSession | null>(null);
  const [renameSession, setRenameSession] = useState<StoredChatSession | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<StoredChatSession | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const normalizedQuery = searchQuery.trim().toLowerCase();
  const groups = useMemo(
    () =>
      groupSessionsByRecency(
        normalizedQuery
          ? sessions.filter((session) => session.title.toLowerCase().includes(normalizedQuery))
          : sessions,
      ),
    [normalizedQuery, sessions],
  );

  const closeMenu = () => {
    setMenuAnchor(null);
    setMenuSession(null);
  };

  const closeRename = () => {
    setRenameSession(null);
    setRenameValue("");
  };

  const submitRename = () => {
    const next = renameValue.trim();
    if (!renameSession || !next) return;
    onRenameSession(renameSession.id, next);
    closeRename();
  };

  return (
    <AiaBox
      sx={{
        flex: 1,
        minHeight: 0,
        overflowY: "auto",
        backgroundColor: "#ffffff",
        px: 1.5,
        py: 1.5,
      }}
    >
      {actionError && <AiaText role="alert" sx={{ color: "error.main", fontSize: 13 }}>{actionError}</AiaText>}
      {error && (
        <AiaBox role="status" sx={{ px: 1, pb: 1 }}>
          <AiaText sx={{ fontSize: 13, color: "#64748b" }}>{error}</AiaText>
          {onRetry && <AiaButton size="small" onClick={onRetry}>Retry</AiaButton>}
        </AiaBox>
      )}
      {loading && !sessions.length ? (
        <AiaText role="status" sx={{ p: 2, fontSize: 14, color: "#64748b" }}>Loading chat history…</AiaText>
      ) : groups.length === 0 && !error ? (
        <AiaBox sx={{ py: 6, textAlign: "center" }}>
          <AiaText sx={{ fontSize: 14, color: "#64748b" }}>
            {normalizedQuery ? "No chats match your search." : "No chat history yet."}
          </AiaText>
        </AiaBox>
      ) : (
        groups.map((group) => (
          <AiaBox key={group.label} sx={{ mb: 2 }}>
            <AiaText
              sx={{
                px: 1.25,
                mb: 0.75,
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: 0.6,
                color: "#94a3b8",
              }}
            >
              {group.label}
            </AiaText>
            <AiaStack spacing={0.5}>
              {group.sessions.map((session) => {
                const isActive = session.id === activeSessionId;
                const menuOpenHere = menuSession?.id === session.id && Boolean(menuAnchor);
                return (
                  <AiaBox
                    key={session.id}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      borderRadius: "12px",
                      backgroundColor: isActive || menuOpenHere ? "#eff6ff" : "transparent",
                      "&:hover": { backgroundColor: isActive ? "#eff6ff" : "#f8fafc" },
                      "&:hover .chat-row-actions, & .chat-row-actions:focus-visible": {
                        opacity: 1,
                      },
                    }}
                  >
                    <AiaBox
                      component="button"
                      type="button"
                      onClick={() => onSelectSession(session)}
                      sx={{
                        flex: 1,
                        minWidth: 0,
                        textAlign: "left",
                        border: "none",
                        background: "transparent",
                        cursor: "pointer",
                        px: 1.25,
                        py: 1.25,
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 1.25,
                      }}
                    >
                      <ChatBubbleOutlineRoundedIcon
                        sx={{ fontSize: 18, color: "#64748b", mt: 0.25, flexShrink: 0 }}
                      />
                      <AiaBox sx={{ minWidth: 0, flex: 1 }}>
                        <AiaText
                          sx={{
                            fontSize: 14,
                            fontWeight: 700,
                            color: "#0f172a",
                            lineHeight: 1.35,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {session.title}
                        </AiaText>
                        <AiaText sx={{ mt: 0.35, fontSize: 12, color: "#94a3b8" }}>
                          {formatSessionRelativeTime(session.updatedAt)}
                        </AiaText>
                      </AiaBox>
                    </AiaBox>
                    <AiaIconButton
                      className="chat-row-actions"
                      size="small"
                      aria-label={`${session.title} options`}
                      title="Chat options"
                      onClick={(event) => {
                        setMenuSession(session);
                        setMenuAnchor(event.currentTarget);
                      }}
                      sx={{
                        mr: 0.75,
                        flexShrink: 0,
                        opacity: menuOpenHere ? 1 : 0,
                        transition: "opacity 120ms ease",
                        color: "#64748b",
                        p: 0.5,
                        borderRadius: "6px",
                        "&:hover": { backgroundColor: "#e2e8f0" },
                      }}
                    >
                      <MoreHorizIcon sx={{ fontSize: 18 }} />
                    </AiaIconButton>
                  </AiaBox>
                );
              })}
            </AiaStack>
          </AiaBox>
        ))
      )}

      <AiaMenu
        anchorEl={menuAnchor}
        open={Boolean(menuAnchor)}
        onClose={closeMenu}
        sx={{ zIndex: MODAL_ABOVE_AI_CHAT_Z_INDEX }}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        slotProps={{
          paper: {
            sx: {
              mt: 0.5,
              minWidth: 180,
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              backgroundColor: "#FFFFFF",
              boxShadow: "0 10px 30px rgba(15, 23, 42, 0.12)",
              py: 0.5,
            },
          },
        }}
      >
        <AiaMenuItem
          onClick={() => {
            if (menuSession) {
              setRenameSession(menuSession);
              setRenameValue(menuSession.title);
            }
            closeMenu();
          }}
          sx={{ py: 0.95 }}
        >
          <EditOutlinedIcon sx={{ fontSize: 16, color: "#64748B", mr: 1.25 }} />
          <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#0F172A" }}>
            Rename chat
          </AiaText>
        </AiaMenuItem>
        {[
          { label: menuSession?.pinned ? "Unpin chat" : "Pin chat", icon: PushPinOutlinedIcon, action: onPinSession },
          { label: "Archive chat", icon: ArchiveOutlinedIcon, action: onArchiveSession },
        ].map(({ label, icon: Icon, action }) => (
          <AiaMenuItem key={label} onClick={() => {
            const selected = menuSession;
            closeMenu();
            setActionError(null);
            if (selected) void action(selected).catch(failure =>
              setActionError(failure instanceof Error ? failure.message : "The chat could not be updated."));
          }}>
            <Icon sx={{ fontSize: 16, color: "#64748b", mr: 1.25 }} />{label}
          </AiaMenuItem>
        ))}
        <AiaMenuItem
          onClick={() => {
            if (menuSession) setDeleteTarget(menuSession);
            closeMenu();
          }}
          sx={{ py: 0.95 }}
        >
          <AiaText sx={{ fontSize: 13, fontWeight: 600, color: "#DC2626" }}>
            Delete chat
          </AiaText>
        </AiaMenuItem>
      </AiaMenu>

      {deleteTarget && <DeleteChatDialog title={deleteTarget.title} onClose={() => setDeleteTarget(null)}
        onDelete={() => onDeleteSession(deleteTarget.id)} />}
      <AiaDialog
        open={Boolean(renameSession)}
        onClose={closeRename}
        fullWidth
        maxWidth="xs"
        sx={{ zIndex: MODAL_ABOVE_AI_CHAT_Z_INDEX }}
      >
        <AiaDialogTitle sx={{ fontSize: 16, fontWeight: 700, color: "#0F172A" }}>
          Rename chat
        </AiaDialogTitle>
        <AiaDialogContent>
          <InputBase
            autoFocus
            fullWidth
            value={renameValue}
            onChange={(event) => setRenameValue(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                submitRename();
              }
            }}
            placeholder="Chat title"
            sx={{
              mt: 0.5,
              px: 1.25,
              py: 1,
              borderRadius: "10px",
              border: "1px solid #E2E8F0",
              fontSize: 14,
              color: "#0F172A",
            }}
          />
        </AiaDialogContent>
        <AiaDialogActions sx={{ px: 3, pb: 2 }}>
          <AiaButton onClick={closeRename} sx={{ textTransform: "none", color: "#64748B" }}>
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            onClick={submitRename}
            disabled={!renameValue.trim()}
            sx={{ textTransform: "none", fontWeight: 700 }}
          >
            Save
          </AiaButton>
        </AiaDialogActions>
      </AiaDialog>
    </AiaBox>
  );
}
