'use client';
import { AiaText } from '@/components/ui/aia-text';
import { useState } from 'react';
import { AiaCard } from '@/components/ui';
import { AiaBox } from '@/components/ui';

import { AiaIconButton } from '@/components/ui';
import { AiaMenu } from '@/components/ui';
import { AiaMenuItem } from '@/components/ui';
import { CheckIcon, MoreVertIcon, TableChartOutlinedIcon } from '@/utils/icons';



import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { AiaChip } from '@/components/ui/aia-chip';
import { BODY_SX, SECONDARY_TEXT_SX, TYPOGRAPHY_TOKENS } from '@/config/typography-tokens';
import {
  WORKSPACE_CARD_SELECTED_TEXT,
  workspaceCardSx,
} from './workspace-card-styles';

/** Database and schema stay in their source casing, just smaller than the name. */
const META_FONT_SIZE = 12;

export default function SourceTargetItem({
  type = 'source',
  item,
  selectHandler,
  isSelected = false,
}: any) {
  const { sourceInfo, targetInfo, drivingTableId, setDrivingTable }: any = useSttmBuilderContext();

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleMenuClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = (event: React.MouseEvent) => {
    event.stopPropagation();
    setAnchorEl(null);
  };

  const handleMakeDrivingTable = (event: React.MouseEvent) => {
    event.stopPropagation();
    setDrivingTable(item.tableId);
    setAnchorEl(null);
  };

  const isDrivingTable = type === 'source' && drivingTableId === item.tableId;

  const metaLeft = type === 'source' ? sourceInfo : targetInfo;
  const itemQualifiedName = String(item.qualifiedName ?? item.tableId ?? "").trim();
  const qualifiedNameParts = itemQualifiedName.split(".").filter(Boolean);
  const itemDatabaseName = qualifiedNameParts.length >= 3 ? qualifiedNameParts[0] : "";
  const itemSchemaName = qualifiedNameParts.length >= 3 ? qualifiedNameParts[1] : "";
  // Saved mappings restore selected tables before the schema browser is opened.
  // In that state sourceInfo/targetInfo is intentionally empty, while the table's
  // own qualifiedName remains authoritative. Per-item metadata also matters for
  // mappings whose selected relations span more than one database or schema.
  const databaseName = itemDatabaseName || metaLeft?.dbName || "—";
  const schemaName = itemSchemaName || metaLeft?.schemaName || "—";
  const metaColor = isSelected
    ? 'color-mix(in srgb, #ffffff 78%, transparent)'
    : TYPOGRAPHY_TOKENS.secondaryText.color;
  return (
    <>
      <AiaCard
        variant="outlined"
        onClick={(event) => selectHandler(item.tableId, event)}
        sx={workspaceCardSx(isSelected)}
      >
        <TableChartOutlinedIcon
          sx={{
            color: isSelected ? WORKSPACE_CARD_SELECTED_TEXT : '#9ca3af',
            fontSize: 20,
            flexShrink: 0,
          }}
        />

        <AiaBox sx={{ flexGrow: 1, minWidth: 0 }}>
          <AiaBox sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, minWidth: 0 }}>
            <AiaText
              sx={{
                ...BODY_SX,
                color: isSelected ? WORKSPACE_CARD_SELECTED_TEXT : '#111827',
                fontWeight: 700,
                whiteSpace: 'normal',
                overflowWrap: 'anywhere',
                lineHeight: 1.35,
              }}
            >
              {item.tableName}
            </AiaText>

            {isDrivingTable && (
              <AiaChip
                label="Driving"
                size="small"
                color="warning"
                customBackgroundColor="#fef08a"
                customColor="#854d0e"
                customBorderColor="#fde047"
                sx={{
                  height: 22,
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-label": { px: 0.75, py: 0 },
                }}
              />
            )}
          </AiaBox>
          <AiaText
            sx={{
              ...SECONDARY_TEXT_SX,
              fontSize: META_FONT_SIZE,
              color: metaColor,
              whiteSpace: 'normal',
              overflowWrap: 'anywhere',
            }}
          >
            {schemaName} · {databaseName}
          </AiaText>
        </AiaBox>

        <AiaBox sx={{ textAlign: 'right', minWidth: 72 }}>
          <AiaText
            sx={{
              ...SECONDARY_TEXT_SX,
              display: 'block',
              fontSize: META_FONT_SIZE,
              color: metaColor,
            }}
          >
            {item.rows ?? '—'}
          </AiaText>
          <AiaText
            sx={{
              ...SECONDARY_TEXT_SX,
              display: 'block',
              fontSize: META_FONT_SIZE,
              color: metaColor,
            }}
          >
            {item.columns ?? '—'} cols
          </AiaText>
        </AiaBox>

        {type === 'source' && (
          <AiaBox sx={{ ml: 0.5 }} onClick={(e) => e.stopPropagation()}>
            <AiaIconButton
              size="small"
              onClick={handleMenuClick}
              sx={{ color: isSelected ? WORKSPACE_CARD_SELECTED_TEXT : 'text.secondary' }}
            >
              <MoreVertIcon fontSize="small" />
            </AiaIconButton>
            <AiaMenu
              anchorEl={anchorEl}
              open={open}
              onClose={handleMenuClose}
              onClick={(e) => e.stopPropagation()}
              slotProps={{
                paper: {
                  sx: {
                    minWidth: 160,
                    boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                    borderRadius: '8px',
                  }
                }
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
              <AiaMenuItem
                onClick={handleMakeDrivingTable}
                disabled={!isSelected}
                sx={{
                  fontSize: '13px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  opacity: !isSelected ? 0.5 : 1,
                  filter: !isSelected ? 'blur(0.5px)' : 'none',
                  textTransform: !isSelected ? 'uppercase' : 'none',
                }}
              >
                Mark as driving table
                {isDrivingTable && <CheckIcon fontSize="small" sx={{ ml: 2, color: 'primary.main' }} />}
              </AiaMenuItem>
            </AiaMenu>
          </AiaBox>
        )}
      </AiaCard>

    </>

  );
}
