-- ============================================================
-- FIR System Snowflake Tasks
-- Automated batch processing triggered by data changes.
-- ============================================================

-- ============================================================
-- TSK_FIR_PROCESS_BATCH - Main FIR Processing Task
-- Runs every 5 minutes when any FIR stream has changes.
-- ============================================================
CREATE OR REPLACE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_PROCESS_BATCH
    WAREHOUSE = __WAREHOUSE_NAME__
    SCHEDULE = '5 MINUTES'
    ALLOW_OVERLAPPING_EXECUTION = FALSE
    SUSPEND_TASK_AFTER_NUM_FAILURES = 3
    TASK_AUTO_RETRY_ATTEMPTS = 2
    USER_TASK_TIMEOUT_MS = 3600000
    COMMENT = 'Main FIR batch processing task triggered by stream changes. Collects feedback, generates inferences, and creates recommendations.'
WHEN
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_WORKBENCH_FEEDBACK') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_STTM_ATTRIBUTES') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_DERIVED_SOURCES') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_SEM_TABLE_VIEWS') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_CONVERSATION_TURNS') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_STTM_VERSIONS') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_CLIENT_SQL_ASSETS')
AS
CALL __STTM_METADATA_NAMESPACE__.SP_FIR_INVOKE_AGENT(
    OBJECT_CONSTRUCT(
        'task_type', 'stream_triggered',
        'batch_size', 100,
        'processing_options', OBJECT_CONSTRUCT(
            'collect_feedback', TRUE,
            'generate_inferences', TRUE,
            'create_semantic_versions', TRUE,
            'generate_recommendations', TRUE,
            'apply_decay', FALSE,
            'parse_documents', TRUE
        )
    )
);


-- ============================================================
-- TSK_FIR_CONFIDENCE_DECAY - Daily Confidence Decay Task
-- Runs daily at 2 AM to apply temporal decay to confidence scores.
-- ============================================================
CREATE OR REPLACE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_CONFIDENCE_DECAY
    WAREHOUSE = __WAREHOUSE_NAME__
    SCHEDULE = 'USING CRON 0 2 * * * America/New_York'
    ALLOW_OVERLAPPING_EXECUTION = FALSE
    SUSPEND_TASK_AFTER_NUM_FAILURES = 3
    USER_TASK_TIMEOUT_MS = 1800000
    COMMENT = 'Daily task to apply temporal decay to FIR confidence scores. Runs at 2 AM EST.'
AS
CALL __STTM_METADATA_NAMESPACE__.SP_FIR_APPLY_CONFIDENCE_DECAY();


-- ============================================================
-- TSK_FIR_SEMANTIC_CONSOLIDATION - Weekly Consolidation Task
-- Runs weekly on Sundays at 4 AM to consolidate semantic versions.
-- ============================================================
CREATE OR REPLACE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_SEMANTIC_CONSOLIDATION
    WAREHOUSE = __WAREHOUSE_NAME__
    SCHEDULE = 'USING CRON 0 4 * * 0 America/New_York'
    ALLOW_OVERLAPPING_EXECUTION = FALSE
    SUSPEND_TASK_AFTER_NUM_FAILURES = 3
    USER_TASK_TIMEOUT_MS = 3600000
    COMMENT = 'Weekly task to consolidate semantic versions, archive old versions, and validate high-confidence versions. Runs Sunday 4 AM EST.'
AS
CALL __STTM_METADATA_NAMESPACE__.SP_FIR_CONSOLIDATE_SEMANTIC_VERSIONS();


-- ============================================================
-- TSK_FIR_SEMANTIC_PRECOMPUTE - Semantic Pre-computation Task
-- Triggered when semantic views or curated versions change.
-- Discovers meaningful table combinations and generates
-- proactive recommendations for all downstream agents.
-- ============================================================
CREATE OR REPLACE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_SEMANTIC_PRECOMPUTE
    WAREHOUSE = __WAREHOUSE_NAME__
    SCHEDULE = '10 MINUTES'
    ALLOW_OVERLAPPING_EXECUTION = FALSE
    SUSPEND_TASK_AFTER_NUM_FAILURES = 3
    TASK_AUTO_RETRY_ATTEMPTS = 1
    USER_TASK_TIMEOUT_MS = 7200000
    COMMENT = 'Semantic pre-computation task. Triggered when semantic views change. Generates proactive FIR recommendations for all meaningful table permutations.'
WHEN
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_SEM_TABLE_VIEWS') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_SEM_COLUMN_VIEWS') OR
    SYSTEM$STREAM_HAS_DATA('__STTM_METADATA_NAMESPACE__.STM_FIR_SEMANTIC_VERSIONS')
AS
CALL __STTM_METADATA_NAMESPACE__.SP_FIR_PRECOMPUTE_PERMUTATIONS(
    OBJECT_CONSTRUCT(
        'max_pairs_per_batch', 10,
        'skip_if_recent_days', 7
    )
);


-- ============================================================
-- TSK_FIR_RECOMMENDATION_SCORING - Periodic Scoring Task
-- Runs daily after confidence decay to re-score all active
-- recommendations based on usage, recency, and ML scores.
-- ============================================================
CREATE OR REPLACE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_RECOMMENDATION_SCORING
    WAREHOUSE = __WAREHOUSE_NAME__
    SCHEDULE = 'USING CRON 30 2 * * * America/New_York'
    ALLOW_OVERLAPPING_EXECUTION = FALSE
    SUSPEND_TASK_AFTER_NUM_FAILURES = 3
    USER_TASK_TIMEOUT_MS = 900000
    COMMENT = 'Daily recommendation scoring task. Runs at 2:30 AM EST after confidence decay. Updates RECOMMENDATION_PRIORITY based on usage, recency, feedback, and ML scores.'
AS
CALL __STTM_METADATA_NAMESPACE__.SP_FIR_SCORE_RECOMMENDATIONS();


-- ============================================================
-- Task Management Commands (run manually after deployment)
-- ============================================================

-- Resume tasks after creation
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_PROCESS_BATCH RESUME;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_CONFIDENCE_DECAY RESUME;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_SEMANTIC_CONSOLIDATION RESUME;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_SEMANTIC_PRECOMPUTE RESUME;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_RECOMMENDATION_SCORING RESUME;

-- Suspend tasks for maintenance
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_PROCESS_BATCH SUSPEND;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_CONFIDENCE_DECAY SUSPEND;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_SEMANTIC_CONSOLIDATION SUSPEND;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_SEMANTIC_PRECOMPUTE SUSPEND;
-- ALTER TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_RECOMMENDATION_SCORING SUSPEND;

-- Check task status
-- SHOW TASKS LIKE 'TSK_FIR_%' IN SCHEMA __STTM_METADATA_NAMESPACE__;

-- View task history
-- SELECT *
-- FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY(
--     TASK_NAME => 'TSK_FIR_PROCESS_BATCH',
--     SCHEDULED_TIME_RANGE_START => DATEADD('hour', -24, CURRENT_TIMESTAMP())
-- ))
-- ORDER BY SCHEDULED_TIME DESC;

-- Manually trigger task for testing
-- EXECUTE TASK __STTM_METADATA_NAMESPACE__.TSK_FIR_PROCESS_BATCH;
