# Client FIR Asset Ingestion

Use `scripts/load_client_fir_knowledge.py` when historical SQL scripts or mapping
workbooks must be learned without calling application HTTP endpoints.

The command uses the same parsers and resolver as the upload API. It:

1. Parses SQL, XLSX, XLS, or CSV content.
2. Detects source, target, CTE, join, column-mapping, filter, and transformation roles.
3. Resolves physical tables against Snowflake and the configured semantic registry.
4. Stores the original document and parsed structure.
5. Writes `TBL_FIR_ASSET_TABLE_REFERENCES`.
6. Enqueues a `document.sql_upload` or `document.excel_upload` FIR event.
7. Can create a real project and STTM using the same canonical snapshot and
   persistence services as the UI.
8. Can publish the STTM so its mappings, rules, relationships, and artifacts
   become strong FIR and agent-learning evidence.
9. Leaves inference and recommendation generation to the offline FIR task graph.

Use `--process-fir-now` when FIR tasks are suspended or the deployment role
cannot operate tasks. It synchronously runs feedback capture, context enrichment,
`AGT_FIR_SYSTEM`, and recommendation scoring after the assets are stored.

## Create and Publish One Mapping

```powershell
.\scripts\load_client_fir_knowledge.ps1 `
  --env-file .\infra\snowflake\env\client.env `
  --project-name "CRM Migration" `
  --project-description "Historical CRM mappings imported for FIR" `
  --project-domain "CRM" `
  --project-outcome "Reuse validated migration precedents" `
  --mapping-name "Household Migration" `
  --mapping-description "Imported from the client SQL and mapping workbook" `
  --business-goal "Build the curated household target" `
  --file .\docs\household_migration.sql `
  --file .\docs\household_mapping.xlsx `
  --source-table-hint CLIENT_DB.CRM.ACCOUNTS `
  --source-table-hint CLIENT_DB.CRM.CONTACTS `
  --target-table-hint CLIENT_DB.CURATED.HOUSEHOLD `
  --create-mapping `
  --publish `
  --process-fir-now `
  --rebuild-search
```

Use `--project-id` instead of `--project-name` to add the mapping to an existing
project.

Source and target hints are authoritative for actual mapping creation. Parsed
legacy identifiers remain stored as evidence, but the command will not guess when
a table is ambiguous.

The resulting STTM contains:

- Normalized selected sources and target.
- Workbook or SQL-derived target-column mappings.
- Preprocessing rules, descriptions, and processing order.
- Original SQL, detected joins, filters, windows, and business rules as artifacts.
- A canonical `WorkbenchContextSnapshotV2`.
- A published version, FIR publication event, readable artifacts, and
  `TBL_AGENT_LEARNINGS` rows.

## Materialize Named CTEs

```powershell
.\scripts\load_client_fir_knowledge.ps1 `
  --env-file .\infra\snowflake\env\client.env `
  --project-id 401 `
  --mapping-name "Accounts Migration" `
  --file .\scripts\accounts.sql `
  --file .\mappings\accounts.xlsx `
  --source-table-hint CLIENT_DB.CRM.ACCOUNTS `
  --target-table-hint CLIENT_DB.CURATED.ACCOUNTS `
  --create-mapping `
  --materialize-ctes `
  --publish
```

`--materialize-ctes` is opt-in. Each named CTE is converted into an executable
read-only query and passed through `DerivedSourceService`. That service validates
the query, stores the derived-source lineage and semantic projection, calls
`SP_FIR_MATERIALIZE_DERIVED_SOURCE`, and records the secure physical view name.

Subqueries without a named CTE remain document and mapping evidence; the importer
does not invent derived sources from them.

## Many Mappings

Run the command once per mapping so each source set, target, mapping name, and
publication has its own exact `context_key`. Multiple `--file` values in one
command are treated as supporting assets for the same mapping.

## Validate Before Loading

```powershell
.\scripts\load_client_fir_knowledge.ps1 `
  --env-file .\infra\snowflake\env\client.env `
  --project-name "CRM Migration" `
  --mapping-name "Household Migration" `
  --file .\docs\household_migration.sql `
  --file .\docs\household_mapping.xlsx `
  --source-table-hint CLIENT_DB.CRM.ACCOUNTS `
  --source-table-hint CLIENT_DB.CRM.CONTACTS `
  --target-table-hint CLIENT_DB.CURATED.HOUSEHOLD `
  --create-mapping `
  --publish `
  --dry-run
```

The report shows detected tables, mapping-row count, CTE count, source/target
identity, publication intent, and the future exact context key without connecting
to Snowflake.

## After Loading

Verify unresolved or ambiguous references:

```sql
SELECT
  SQL_ASSET_ID,
  RAW_IDENTIFIER,
  REFERENCE_ROLE,
  RESOLUTION_STATUS,
  RESOLVED_FQN,
  CANDIDATE_FQNS,
  SEMANTIC_STATUS
FROM TBL_FIR_ASSET_TABLE_REFERENCES
WHERE PROJECT_ID = '401'
ORDER BY CREATED_AT DESC;
```

After references resolve, resume or manually run the FIR task graph. The next
matching source/target selection can retrieve the generated exact or structured
recommendations without waiting for a live FIR agent. Published mappings are also
available to Auto-map as high-confidence exact precedents.
