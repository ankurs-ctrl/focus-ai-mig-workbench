# Deep Agent integration deployment notes

The integration selectively imports the deep-agent feature from ZIP commit
`022191db6f9c79e680be20c353341098e61344ef` onto develop base
`e0c0af26305cc163c7b4fde59f520db2c88c42d8`. It is not a merge of the ZIP's old shared application.

The existing `/ai-agent` page, composer, fonts, navigation and standard mapping assistant remain the host UI. Plan/Agent mode, effort (`Low effort` → `light`), supported model choices, attachments, durable history, review checkpoints, progress, artifacts and usage now connect to `/agent-runs` and conversation APIs. Models come from backend capabilities.

## Runtime and migrations

Install the merged Python dependency lock. Do not replace local account or deployment settings with files from the ZIP. No credentials or `.env` files are part of this integration.

A baseline application metadata schema (including existing FIR v2 workspace snapshots, events and artifacts) is required. For a fresh isolated schema apply the existing base table DDL and FIR v2 additive reconciliation first; CREATE TABLE IF NOT EXISTS alone does not add newer columns to an old table.

Apply these additive migrations in order against the application's metadata database/schema, using the existing deployment substitution mechanism and an authorized deployment role:

- `20260830_migration_agent_control_plane.sql`
- `20260901_assistant_conversation_reliability.sql`
- `20260921_deep_capacity.sql`
- `20260921_deep_migration_knowledge.sql`
- `20260922_deep_command_outbox.sql`
- `20260922_deep_learning_subjects.sql`
- `20260922_deep_lease_fencing.sql`
- `20260923_deep_capacity_provisioning.sql`
- `20260923_deep_fenced_events.sql`
- `20260924_deep_checkpoint_batch.sql`
- `20260927_assistant_conversation_pins.sql`
- `20260929_deep_run_knowledge.sql`

Enable `MIGRATION_AGENT_ENABLED`, `MIGRATION_AGENT_TRUE_RESUME_V1`,
`MIGRATION_AGENT_TOOL_GOVERNANCE_V1`, `ASSISTANT_UNIFIED_HISTORY_V1`, and
`ASSISTANT_INTENT_ROUTING_V1` for the deep-agent workflow. Check the merged settings and worker configuration validator for the complete deployment contract. Preserve existing values for session, caching, Auto-map capacity/recovery and Snowflake identity.

Configure `MIGRATION_AGENT_MODEL_LIGHT`, `MIGRATION_AGENT_MODEL_MEDIUM`, and
`MIGRATION_AGENT_MODEL_HIGH` to Cortex models available to the deployment role.
`MIGRATION_AGENT_MAX_COMPLETION_TOKENS` defaults to 16384; choose an allowance supported by the selected models. An omitted output allowance previously inherited the Cortex Chat Completions 4096-token default and repeatedly truncated full plans. A response marked truncated now stops safely, retains evidence and requires correction before resume.
[Snowflake Cortex REST API](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-rest-api) documents the output parameter and model limits.

If deep-agent specialists live outside the metadata schema, set
`MIGRATION_AGENT_SOURCE_MAPPING_AGENT` and
`MIGRATION_AGENT_TRANSFORMATION_RULE_AGENT` to their approved FQNs. Empty overrides retain existing resolution. Existing semantic registries can be selected through the current semantic database/schema settings; do not regenerate semantics merely to test this feature.

The container now starts `python -m app.service_main`. This runs the API and, when the feature is enabled, a durable worker. The process terminates its owned children if either exits, avoiding an API that accepts deep jobs without a consumer. Other deployments may run `python -m app.agent_worker_main` as a separately supervised worker; do not start a duplicate worker unintentionally. Existing delegated user authorization remains required in SPCS.

## Boundaries

Plan mode may persist operational checkpoints/research, but business project/STTM/join/CTE/Firm Value drafts require the approved action and current plan revision. Opening a review does not approve it. Cancellation, rejection and stale approval do not authorize draft writes. Publishing is a human action and is not performed by this integration's agent.

Full model calls are durably counted before dispatch. Restarts restore monotonic usage, verified research and checkpoints. Repeated malformed plan corrections stop after three same-code failures rather than exhausting the account in a loop. Optional knowledge search failure is explicit evidence of unavailability, never an invented result.

Local verification uses a separate scratch schema in this system's Snowflake account. It does not verify client SPCS OAuth, grants, available models or deployment configuration. This delivery targets CodeCommit develop only; it does not deploy or update UAT.


## Root-overlay ZIP

Extract the supplied ZIP into the existing repository root (the directory containing `frontend/`, `services/` and `infra/`). There is no enclosing package directory. It contains only the integration's changed/new files, tests, dependency lock and additive migrations; it contains no `.env`, credentials, client account/deployment files, runtime lock or installed dependencies. Existing unlisted files are untouched. Application `app/core/config.py` logic is included, with all pre-existing setting defaults preserved.

Extraction does not install Python dependencies, apply Snowflake migrations, enable feature flags or rebuild deployed containers. Perform the runtime/migration steps above with the client's existing deployment mechanism, then rebuild the frontend and backend. Preserve the client's own values. The verification report distinguishes native system-account checks from client-only checks.
