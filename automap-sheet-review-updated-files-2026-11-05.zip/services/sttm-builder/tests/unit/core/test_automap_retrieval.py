from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from app.core.automap_retrieval import AutoMapContext, encoded
from app.core.config import Settings
from app.core.sttm_builder import STTMBuilderService
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest


def payload(target_count=1, description_size=500_000):
    source = {"database": "D", "schema": "S", "table": "A"}
    target = {**source, "table": "T"}
    return {"request_id": "isolated", "operation": "sttm.auto_map", "context": {
        "project_id": "allowed", "sttm_id": "mapping", "source_tables": [source], "target_table": target,
        "semantic_context": [
            {"table": source, "semantic_model": {"grain": "One customer", "pk_detection": {"notes": "P" * description_size},
                "attributes": [{"name": "X47", "business_meaning": "Legal appellation", "null_behavior": "Unknown, not empty"}]}},
            {"table": target, "semantic_model": {"attributes": [{"name": f"NAME{index}", "business_meaning": "Customer legal name"}
                                                                    for index in range(target_count)]}},
        ],
        "relation_graph": {"nodes": [{"relation_id": "a", "kind": "PHYSICAL_TABLE", "alias": "a", "table": source,
                                      "output_columns": [{"name": "X47", "data_type": "TEXT"}]}], "edges": [],
                           "value_bindings": [{"binding_id": "firm", "value": "$FirmID", "resolved_value": "current"}]},
        "learning_context": {"correction_history": [{"target_column": "NAME0", "correction_id": "negative1",
                                                       "prevention_hint": "Never use CONTACT_NAME."}]},
    }, "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": target, "target_attribute": f"NAME{index}"}
                                                        for index in range(target_count)]}}


def request(store, operation, **kwargs):
    return {"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash, "operation": operation, **kwargs}


@pytest.mark.parametrize('column', ['BIZACCOUNTID', '"Business.ID"'])
def test_structural_cte_handles_remain_typed_retrieval_arguments(column):
    value = payload(description_size=0)
    relation_id = 'sql-cte:source-1901:statement:0/scope:2:cte_biz_src'
    graph = value['context']['relation_graph']
    graph['nodes'].append({'relation_id': relation_id, 'kind': 'DERIVED_SOURCE',
        'alias': 'cte_biz_src', 'sql_text': 'SELECT X47 AS BIZACCOUNTID FROM D.S.A',
        'output_columns': [{'name': column.strip('"'), 'data_type': 'TEXT'}]})
    graph['edges'].append({'edge_id': 'joined-cte', 'left_relation_id': 'a',
        'right_relation_id': relation_id, 'join_type': 'INNER',
        'conditions': [{'left_column': 'X47', 'right_column': column, 'operator': '='}]})
    saved = deepcopy(value)
    store = AutoMapContext(value)
    # Reproduce the old crash: an opaque handle cannot be parsed as SQL.
    from app.core.automap_retrieval import reference_parts
    with pytest.raises(ValueError, match='Expected one exact column reference'):
        reference_parts(f'{relation_id}.{column}')
    AutoMapContext(value).mandatory_results(max_bytes=32768, max_operations=64)
    operations = store.required_operations('NAME0', {'source_attributes': []})
    exact = {'operation': 'column', 'relation': relation_id, 'column': column}
    assert exact in operations
    result = store.read(request(store, 'column', relation=relation_id, column=column), max_bytes=12000)
    assert result['complete']
    assert exact not in store.required_operations('NAME0', {'source_attributes': []})
    assert value == saved
    store.mandatory_results(max_bytes=32768, max_operations=64)


def test_manifest_retains_complete_namespace_and_exact_store_not_large_bodies():
    original = payload(37)
    saved = deepcopy(original)
    store = AutoMapContext(original)
    manifest = store.manifest()
    assert len(encoded(manifest)) < 20000
    assert manifest["context"]["auto_map_retrieval"]["column_catalog"]["D.S.A"] == {"X47": None}
    assert "correction_history" in manifest["context"]["auto_map_retrieval"]["mandatory_categories"]["NAME0"]
    assert original == saved
    result = store.read(request(store, "column", relation="a", column="X47"), max_bytes=12000)
    assert "Unknown, not empty" in encoded(result)
    assert store.tables["D.S.A"][0]["pk_detection"]["notes"] == "P" * 500000


def test_real_account_nested_registry_shapes_keep_rich_column_meaning():
    value = payload(description_size=0)
    value["context"]["semantic_context"][0]["semantic_model"] = {
        "attribute_semantic_model": [{"name": "X47", "business_meaning": "Legal appellation", "null_behavior": "Never substitute empty"}],
        "semantic_model": {"attributes": [{"name": "X47", "summary": "Customer legal name"}],
                           "domain_summary": "Customer entity", "semantic_notes": "One entity per ID"},
    }
    store = AutoMapContext(value)
    result = store.read(request(store, "column", relation="D.S.A", column="X47"), max_bytes=12000)
    assert "Never substitute empty" in encoded(result)
    assert "Customer legal name" in encoded(result)
    assert "Customer entity" in encoded(store.manifest())


def test_large_multitable_contracts_are_exact_deferred_reads_not_inline_duplicates():
    value = payload(description_size=0)
    note = "Preserve preferred-address population and nullable flags. " * 200
    value["context"]["semantic_context"][0]["semantic_model"]["semantic_notes"] = note
    store = AutoMapContext(value)
    manifest = store.manifest()
    assert note not in encoded(manifest)
    assert manifest["context"]["auto_map_retrieval"]["table_contracts"]["D.S.A"]["exact_table_read_required"]
    assert "table contract:D.S.A" in store.missing_reads("NAME0", {"source_attributes": ["a.X47"]})
    result = store.read(request(store, "table", relation="a"), max_bytes=20000)
    assert note in encoded(result)
    assert "table contract:D.S.A" not in store.missing_reads("NAME0", {"source_attributes": ["a.X47"]})
    assert value["context"]["semantic_context"][0]["semantic_model"]["semantic_notes"] == note


def test_search_degradation_cannot_masquerade_as_no_evidence():
    store = AutoMapContext(payload(description_size=0))
    store.read(request(store, "discover", target="NAME0"), max_bytes=12000,
               discover=lambda target: {"evidence": {}, "diagnostics": {"status": "degraded", "errors": ["denied"]}})
    assert "historical retrieval unavailable" in store.missing_reads("NAME0", {"source_attributes": []})


@pytest.mark.parametrize("focused", [False, True])
@pytest.mark.parametrize("guard", ["current", "no_match", "cited", "linked", "denied", "unknown"])
def test_optional_search_failure_does_not_waive_mandatory_evidence(guard, focused):
    value = payload(description_size=0)
    learning = value["context"]["learning_context"]
    learning["retrieval_diagnostics"] = {
        "correction_history": {"status": "available"}, "project_context": {"status": "available"},
    }
    mapping = {"source_attributes": ["a.X47"]}
    if guard == "cited":
        mapping["used_learning_ids"] = ["recipe"]
    elif guard == "linked":
        learning["linked_mapping_ids"] = ["selected-precedent"]
    elif guard in {"denied", "unknown"}:
        learning["retrieval_diagnostics"]["correction_history"]["status"] = "error" if guard == "denied" else "unknown"
    elif guard == "no_match":
        learning["retrieval_diagnostics"]["correction_history"]["status"] = "no_match"
    if focused:
        from app.core.automap_policy import focused_learning
        value["context"]["learning_context"] = focused_learning(learning)
    store = AutoMapContext(value)
    store.discover_batch(lambda targets: {target: {"evidence": {}, "diagnostics": {
        "status": "degraded", "route": "search", "errors": ["denied"],
    }} for target in targets})
    store.read(request(store, "discover", target="NAME0"), max_bytes=12000)
    missing = store.missing_reads("NAME0", mapping)
    assert ("historical retrieval unavailable" in missing) == (guard not in {"current", "no_match"})
    assert "mandatory evidence:correction_history" in missing
    assert "source semantics:a.X47" in missing
    assert store.discovered["NAME0"]["diagnostics"]["status"] == "degraded"


def test_target_scoping_deduplicates_identical_execution_evidence_losslessly():
    value = payload(2, description_size=0)
    patterns = [{"pattern_id": "one", "target_column": "NAME0", "sql": "SELECT X47 FROM D.S.A"},
                {"pattern_id": "two", "target_column": "NAME1", "sql": "SELECT X47 FROM D.S.A"}]
    value["context"]["learning_context"]["target_mapping_patterns"] = deepcopy(patterns)
    value["context"]["execution_context"] = {"target_mapping_patterns": deepcopy(patterns)}
    store = AutoMapContext(value)
    assert store.evidence["NAME0"]["target_mapping_patterns"] == [patterns[0]]
    assert "execution:target_mapping_patterns" not in store.evidence["NAME0"]
    assert store.original["context"]["execution_context"]["target_mapping_patterns"] == patterns


def test_repeated_exact_records_round_trip_without_summarizing_rules():
    from app.core.automap_retrieval import factor_exact_records
    record = {"sql": "SELECT X47 FROM D.S.A WHERE FLAG IS NULL", "rules": ["Never drop NULL rows"] * 80}
    original = {"evidence": [deepcopy(record), deepcopy(record)], "other": {"record": deepcopy(record)}}
    factored = factor_exact_records(original)
    assert len(encoded(factored)) < len(encoded(original))

    def expand(value):
        if isinstance(value, dict):
            if set(value) == {"$exact_record"}:
                return expand(factored["exact_record_dictionary"][value["$exact_record"]])
            return {key: expand(child) for key, child in value.items()
                    if key not in {"exact_record_dictionary", "exact_record_encoding"}}
        return [expand(child) for child in value] if isinstance(value, list) else value

    assert expand(factored) == original


def test_population_dependency_omits_unrelated_history_but_keeps_exact_sql_and_filters():
    value = payload(description_size=0)
    value["context"]["workspace_context"] = {
        "filters": {"filter_sql": "a.FLAG IS NULL"}, "raw_mapping_sql": "SELECT X47 FROM D.S.A WHERE FLAG IS NULL",
        "mapping_rows": [{"target_column": "OTHER", "expression": "UNRELATED"}],
        "conversation_history": ["unrelated"], "auto_map_outcome": {"mappings": {"OTHER": "unrelated"}},
    }
    store = AutoMapContext(value)
    store.manifest()
    result = store.read(request(store, "dependency", relation_id="workspace"), max_bytes=12000)
    assert "FLAG IS NULL" in encoded(result)
    assert "UNRELATED" not in encoded(result)
    assert "mapping_rows" in store.original["context"]["workspace_context"]


def test_structural_predicate_semantics_are_required_in_addition_to_selected_source():
    value = payload(description_size=0)
    value["context"]["relation_graph"]["nodes"][0]["output_columns"].append({"name": "PREFERRED"})
    value["context"]["semantic_context"][0]["semantic_model"]["attributes"].append(
        {"name": "PREFERRED", "business_meaning": "Primary address selection"})
    value["context"]["workspace_context"] = {"filters": {"filter_sql": "a.PREFERRED = TRUE"}}
    store = AutoMapContext(value)
    store.manifest()
    assert "source semantics:a.PREFERRED" in store.missing_reads("NAME0", {"source_attributes": ["a.X47"]})


@pytest.mark.parametrize("change", [
    {"snapshot_hash": "stale"}, {"relation": "OTHER.S.A"}, {"project_id": "outside"},
    {"column": "INVENTED"}, {"cursor": "guessed"},
])
def test_cross_scope_stale_and_guessed_identities_return_no_content(change):
    store = AutoMapContext(payload())
    with pytest.raises(ValueError):
        store.read({**request(store, "column", relation="a", column="X47"), **change}, max_bytes=12000)
    assert not store.reads


def test_unicode_pages_are_lossless_and_cursor_bound_to_operation():
    original = payload(description_size=0)
    text = "\u96ea\\\"\n" * 4000
    original["context"]["semantic_context"][0]["semantic_model"]["attributes"][0]["description"] = text
    store = AutoMapContext(original)
    query = request(store, "column", relation="D.S.A", column="X47")
    pages = []
    while True:
        result = store.read(query, max_bytes=6000)
        assert len(encoded(result).encode()) <= 6000
        pages.append(result)
        if not result["next_cursor"]:
            break
        with pytest.raises(ValueError):
            store.read(request(store, "table", relation="D.S.A", cursor=result["next_cursor"]), max_bytes=6000)
        query["cursor"] = result["next_cursor"]
    pieces = [fragment for page in pages for fragment in page["fragments"] if "text_start" in fragment]
    assert "".join(fragment["value"] for fragment in pieces) == text
    assert ("column", "D.S.A", "X47") in store.reads


def test_multi_read_cursor_keeps_page_plan_when_next_chunk_has_more_budget():
    original = payload(description_size=0)
    text = "exact-body-with-escapes\\\"\n" * 2500
    original["context"]["semantic_context"][0]["semantic_model"]["attributes"][0]["description"] = text
    store = AutoMapContext(original)
    operation = {"operation": "column", "relation": "D.S.A", "column": "X47"}
    first = store.read_many(request(store, "multi_read", reads=[operation,
        {"operation": "contract", "relation": "D.S.A"}]),
        max_bytes=32768, max_total_bytes=12000)["results"][0]["result"]
    assert first["next_cursor"]
    fragments = list(first["fragments"])
    result = first
    while result["next_cursor"]:
        result = store.read_many(request(store, "multi_read", reads=[{
            **operation, "cursor": result["next_cursor"]}]),
            max_bytes=32768, max_total_bytes=131072)["results"][0]["result"]
        assert not result.get("error"), result
        assert result["page_count"] == first["page_count"]
        fragments.extend(result["fragments"])
    assert "".join(fragment["value"] for fragment in fragments if "text_start" in fragment) == text
    assert store.exact_completed_result(operation)["complete"]


def test_cursor_pages_reserve_original_allowance_when_aggregate_chunk_grows():
    original = payload(description_size=0)
    original["context"]["semantic_context"][0]["semantic_model"]["attributes"][0]["description"] = "exact body " * 7000
    store = AutoMapContext(original)
    operation = {"operation": "column", "relation": "D.S.A", "column": "X47"}
    first = store.read(request(store, **operation), max_bytes=16000)
    response = store.read_many(request(store, "multi_read", reads=[{
        **operation, "cursor": first["next_cursor"]}, {"operation": "contract", "relation": "D.S.A"},
        {"operation": "table", "relation": "D.S.A"}]), max_bytes=32768, max_total_bytes=24000)
    assert not response["results"][0]["result"].get("error")
    assert response["results"][0]["result"]["page_count"] == first["page_count"]
    assert len(encoded(response).encode()) <= 24000


def test_dependency_closure_keeps_parent_sql_and_exact_filters():
    value = payload(description_size=0)
    nodes = value["context"]["relation_graph"]["nodes"]
    nodes.extend([
        {"relation_id": "base", "alias": "base", "kind": "CTE", "sql_text": "SELECT X47 FROM D.S.A WHERE ACTIVE=1", "parent_relation_ids": ["a"]},
        {"relation_id": "final", "alias": "final", "kind": "CTE", "sql_text": "SELECT X47 FROM base QUALIFY ROW_NUMBER() OVER(ORDER BY X47)=1", "parent_relation_ids": ["base"]},
    ])
    store = AutoMapContext(value)
    store.manifest()
    result = store.read(request(store, "dependency", relation_id="final"), max_bytes=12000)
    assert "WHERE ACTIVE=1" in encoded(result)
    assert "QUALIFY ROW_NUMBER()" in encoded(result)
    assert all(identity in encoded(result) for identity in ("base", "final", "a"))


def test_uploaded_embedded_cte_parent_is_exact_dependency_not_new_mapping_source():
    value = payload(description_size=0)
    parent = "sql-cte:doc:statement:0/scope:0:PrivateParent"
    value["context"]["relation_graph"]["nodes"].append({
        "relation_id": "final", "alias": "final", "kind": "DERIVED_SOURCE",
        "sql_text": "WITH PrivateParent AS (SELECT X47 FROM D.S.A WHERE ACTIVE=1) SELECT X47 FROM PrivateParent",
        "parent_relation_ids": [parent],
    })
    store = AutoMapContext(value)
    store.manifest()
    result = store.read(request(store, "dependency", relation_id="final"), max_bytes=12000)
    assert parent in encoded(result)
    assert "WHERE ACTIVE = 1" in encoded(result)
    assert parent not in store.aliases
    assert "PrivateParent" not in store.aliases
    store.nodes["final"]["parent_relation_ids"].append("absent")
    with pytest.raises(ValueError, match="parent is unavailable"):
        store.read(request(store, "dependency", relation_id="final"), max_bytes=12000)


def test_mandatory_negative_evidence_is_not_replaced_by_search_no_match():
    store = AutoMapContext(payload(description_size=0))
    discovery = store.read(request(store, "discover", target="NAME0"), max_bytes=12000,
                           discover=lambda target: {"evidence": {}, "diagnostics": {"status": "no_match"}})
    assert "correction_history" in discovery["data"]["mandatory_categories"]
    mapping = {"source_attributes": ["a.X47"], "source_dependencies": []}
    assert "mandatory evidence:correction_history" in store.missing_reads("NAME0", mapping)
    store.read(request(store, "evidence", target="NAME0", category="correction_history"), max_bytes=12000)
    store.read(request(store, "column", relation="D.S.T", column="NAME0"), max_bytes=12000)
    store.read(request(store, "column", relation="a", column="X47"), max_bytes=12000)
    assert not store.missing_reads("NAME0", mapping)
    assert store.evidence_ids("NAME0") == {"negative1"}


def test_linked_precedent_and_oversized_negative_rule_remain_mandatory_exact_pages():
    value = payload(description_size=0)
    rule = "Never use historical firm values. " * 1000
    value["context"]["learning_context"]["mapping_precedents"] = [
        {"precedent_sttm_id": "linked", "mappings": [{"target_column": "NAME0", "mapping_id": "row1", "expression": "a.X47",
                                                     "prevention_hint": rule}]}]
    store = AutoMapContext(value)
    manifest = store.manifest()
    assert "mapping_precedents" in manifest["context"]["auto_map_retrieval"]["mandatory_categories"]["NAME0"]
    query = request(store, "evidence", target="NAME0", category="mapping_precedents")
    pages = []
    while True:
        result = store.read(query, max_bytes=6000)
        pages.extend(result["fragments"])
        if not result["next_cursor"]:
            break
        assert "mandatory evidence:mapping_precedents" in store.missing_reads("NAME0", {"source_attributes": []})
        query["cursor"] = result["next_cursor"]
    assert "".join(fragment["value"] for fragment in pages if "text_start" in fragment) == rule
    assert {"linked", "row1"} <= store.evidence_ids("NAME0")


def test_reading_one_target_cannot_authorize_other_target_evidence():
    value = payload(2, description_size=0)
    store = AutoMapContext(value)
    store.read(request(store, "evidence", target="NAME0", category="correction_history"), max_bytes=12000)
    assert "correction_history" not in store.evidence["NAME1"]
    with pytest.raises(ValueError):
        store.read(request(store, "evidence", target="NAME1", category="correction_history"), max_bytes=12000)
    assert store.evidence_ids("NAME0") == {"negative1"}
    assert store.evidence_ids("NAME1") == set()


def test_multi_read_rejects_whole_foreign_list_before_any_content_or_read_marks():
    store = AutoMapContext(payload(2, description_size=0))
    query = request(store, "multi_read", reads=[
        {"operation": "column", "relation": "a", "column": "X47"},
        {"operation": "column", "relation": "FOREIGN", "column": "X47"},
    ])
    with pytest.raises(ValueError):
        store.read_many(query, max_bytes=12000)
    assert not store.reads


def test_multi_read_is_bounded_and_shared_column_satisfies_all_targets():
    store = AutoMapContext(payload(2, description_size=0))
    query = request(store, "multi_read", reads=[{"operation": "column", "relation": "a", "column": "X47"}])
    assert len(store.read_many(query, max_bytes=12000)["results"]) == 1
    assert all("source semantics:a.X47" not in store.missing_reads(target, {"source_attributes": ["a.X47"]})
               for target in store.targets)
    query["reads"] *= 65
    with pytest.raises(ValueError, match="bounded"):
        store.read_many(query, max_bytes=12000)


def test_case_resolution_does_not_merge_distinct_quoted_columns():
    value = payload(description_size=0)
    value["context"]["semantic_context"][0]["semantic_model"]["attributes"].extend([
        {"name": "Mixed", "business_meaning": "One"}, {"name": "MIXED", "business_meaning": "Two"}])
    store = AutoMapContext(value)
    lower = store.read(request(store, "column", relation="a", column="x47"), max_bytes=12000)
    assert "Legal appellation" in encoded(lower)
    exact = store.read(request(store, "column", relation="a", column='"Mixed"'), max_bytes=12000)
    assert "One" in encoded(exact) and "Two" not in encoded(exact)
    with pytest.raises(ValueError):
        store.read(request(store, "column", relation="a", column="mixed"), max_bytes=12000)


def test_boolean_distinct_modifier_does_not_force_whole_workspace_dependency():
    value = payload(description_size=0)
    value["context"]["relation_graph"]["query_modifiers"] = {"distinct": "true"}
    value["context"]["workspace_context"] = {"context_key": "key"}
    store = AutoMapContext(value)
    store.manifest()
    assert not any(item.startswith("unparsed population") for item in store.missing_reads("NAME0", {}))


def test_nested_repeated_records_roundtrip_interns_shared_sql_inside_arrays():
    from app.core.automap_retrieval import factor_exact_records
    shared = {"sql": "SELECT X47 FROM D.S.A WHERE FLAG IS NULL " * 100}
    values = [{"target": "NAME0", "dependencies": [deepcopy(shared)]},
              {"target": "NAME1", "dependencies": [deepcopy(shared)]}]
    original = {"one": deepcopy(values), "two": deepcopy(values)}
    factored = factor_exact_records(original)
    def expand(value):
        if isinstance(value, dict):
            if set(value) == {"$exact_record"}:
                return expand(factored["exact_record_dictionary"][value["$exact_record"]])
            return {key: expand(child) for key, child in value.items()
                    if key not in {"exact_record_dictionary", "exact_record_encoding"}}
        return [expand(child) for child in value] if isinstance(value, list) else value
    assert expand(factored) == original
    assert len(encoded(factored)) < len(encoded(original)) / 2


def test_deferred_recipe_dependencies_are_exact_and_required_before_recipe_citation():
    value = payload(description_size=0)
    dependency = {"sql_text": "SELECT X47 FROM D.S.A WHERE FLAG IS NULL " * 80,
                  "output_columns": [{"name": "X47", "null_behavior": "Never empty"}]}
    value["context"]["learning_context"]["target_mapping_patterns"] = [{"pattern": {
        "target_contract": {"target_column": "NAME0"}, "pattern_id": "recipe",
        "derived_dependencies": [dependency], "exclusions": ["Never change population"],
    }}]
    store = AutoMapContext(value)
    result = store.read(request(store, "evidence", target="NAME0", category="target_mapping_patterns"), max_bytes=12000)
    assert "Never change population" in encoded(result)
    identity = next(iter(store.historical_dependencies))
    assert store.historical_dependencies[identity] == [dependency]
    assert f"derived dependency:{identity}" in store.missing_reads("NAME0", {"used_learning_ids": ["recipe"]})
    query = request(store, "dependency", relation_id=identity)
    while True:
        page = store.read(query, max_bytes=6000)
        if not page["next_cursor"]:
            break
        query["cursor"] = page["next_cursor"]
    assert store.exact_completed_result(query)["data"] == [dependency]
    assert f"derived dependency:{identity}" not in store.missing_reads("NAME0", {"used_learning_ids": ["recipe"]})
    assert value["context"]["learning_context"]["target_mapping_patterns"][0]["pattern"]["derived_dependencies"] == [dependency]


def test_lossless_shapes_and_text_segments_roundtrip_unicode_sql_and_reserved_fallback():
    from app.core.automap_retrieval import factor_exact_object_shapes, factor_exact_text_lines
    sql = ("SELECT 'a,b;\n\\quoted', X47 FROM D.S.A WHERE FLAG IS NULL, " * 25) + "\n"
    original = {"rows": [{"name": str(index), "description": sql + str(index), "nullable": None}
                         for index in range(10)]}
    text = factor_exact_text_lines(original)
    factored = factor_exact_object_shapes(text)
    def expand(value):
        if isinstance(value, dict):
            if set(value) == {"$exact_object"}:
                index, children = value["$exact_object"]
                return dict(zip(factored["exact_object_shapes"][index], map(expand, children)))
            if set(value) == {"$exact_text"}:
                return "".join(map(expand, value["$exact_text"]))
            if set(value) == {"$exact_line"}:
                return factored["exact_text_lines"][value["$exact_line"]]
            return {key: expand(child) for key, child in value.items() if key not in {
                "exact_object_shapes", "exact_object_encoding", "exact_text_lines", "exact_text_encoding"}}
        return list(map(expand, value)) if isinstance(value, list) else value
    assert expand(factored) == original
    assert factor_exact_object_shapes({"$exact_object": "original"}) == {"$exact_object": "original"}
    assert factor_exact_text_lines({"$exact_line": "original"}) == {"$exact_line": "original"}


def test_planning_and_worker_manifest_fit_37_targets_with_half_megabyte_semantics():
    value = payload(37)
    # Use a valid correction model for the transport envelope.
    value["context"]["learning_context"] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
                        AGENT_OUTBOUND_MESSAGE_MAX_CHARS=60000, AGENT_OUTBOUND_MESSAGE_MAX_BYTES=65536)
    before = req.model_dump_json()
    projected = STTMBuilderService.project_agent_payload(req, settings)
    assert len(projected.text) < settings.agent_outbound_message_max_chars
    assert len(projected.payload["retrieved_auto_map_context"]) == 37
    restored = STTMBuilderEnvelopeRequest.model_validate(req.to_worker_payload())
    assert STTMBuilderService.project_agent_payload(restored, settings).text == projected.text
    assert req.model_dump_json() == before
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    batches = AutoMappingProxyClient(settings)._build_batches(req)
    assert len(batches) == 4
    assert sorted(len(batch) for batch in batches) == [9, 9, 9, 10]


class ScriptedAgent:
    def __init__(self, bad=False):
        self.calls = []
        self.bad = bad

    def run_detailed(self, messages, **kwargs):
        self.calls.append((deepcopy(messages), kwargs))
        value = json.loads(messages[-1]["content"][0]["text"])
        def expand(child):
            if isinstance(child, dict):
                if set(child) == {"$ctx"}:
                    return value["context_value_dictionary"][child["$ctx"]]
                if set(child) == {"$exact_record"}:
                    return expand(value["exact_record_dictionary"][child["$exact_record"]])
                if set(child) == {"$exact_object"}:
                    index, values = child["$exact_object"]
                    return dict(zip(value["exact_object_shapes"][index], [expand(item) for item in values]))
                if set(child) == {"$exact_text"}:
                    return "".join(expand(item) for item in child["$exact_text"])
                if set(child) == {"$exact_line"}:
                    return value["exact_text_lines"][child["$exact_line"]]
                return {key: expand(item) for key, item in child.items()}
            return [expand(item) for item in child] if isinstance(child, list) else child
        value = expand(value)
        targets = [item["target_attribute"] for item in value["data"]["attributes"]]
        manifest = value["context"]["auto_map_retrieval"]
        results = value["retrieved_auto_map_context"]
        source_read = any(item.get("request", {}).get("relation") == "a" for item in results)
        if not source_read and not self.bad:
            answer = {"meta": {"delegation": {"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": manifest["snapshot_hash"],
                       "operation": "multi_read", "reads": [{"operation": "column", "relation": "a", "column": "X47"}]}}}
        else:
            answer = {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {target: {
                "source_attributes": ["a.X47"], "confidence_score": 0.9,
                "transformation_classification": "direct", "used_learning_ids": ["invented"] if self.bad else [],
            } for target in targets}}}}
        return json.dumps(answer), f"thread-{len(self.calls)}", {"message_id": len(self.calls)}


def service(agent):
    instance = STTMBuilderService.__new__(STTMBuilderService)
    instance._agent = agent
    instance._source_mapping_agent_name = "AGT_SOURCE_MAPPING"
    def explain_only(query):
        # Final sheet candidates now pass the SQL compilation gate as well.
        assert query.startswith("EXPLAIN USING TEXT ")
        return SimpleNamespace(collect=lambda: [])
    instance._query_session = SimpleNamespace(sql=explain_only)
    instance._settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTOMAP_CONTEXT_MAX_READS=6,
                                  AGENT_OUTBOUND_MESSAGE_MAX_CHARS=60000, AGENT_OUTBOUND_MESSAGE_MAX_BYTES=65536)
    instance._model_guard = SimpleNamespace(assert_model_target_allowed=lambda **kwargs: None)
    instance._discover_auto_map_batch_evidence = lambda req, targets: {
        target: {"evidence": {}, "diagnostics": {"status": "no_match"}} for target in targets}
    return instance


def test_mapping_loop_reasons_over_entire_batch_and_returns_final_thread():
    value = payload(3)
    value["context"]["learning_context"] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    agent = ScriptedAgent()
    raw, thread, metadata = service(agent)._invoke_retrieval_auto_map(req, SimpleNamespace())
    mappings = json.loads(raw)["data"]["result"]["mappings"]
    assert len(mappings) == 3
    assert all(item["source_attributes"] == ["a.X47"] for item in mappings.values()), [item["unmatched_reason"] for item in mappings.values()]
    assert len(agent.calls) == 2
    assert thread == "thread-2"
    assert metadata["auto_map_retrieval"]["target_count"] == 3
    assert all(kwargs["thread_id"] is None for _, kwargs in agent.calls)
    assert all(len(encoded(messages).encode()) <= 65536 for messages, _ in agent.calls)
    for messages, _ in agent.calls:
        assert len(json.loads(messages[0]["content"][0]["text"])["data"]["attributes"]) == 3
        assert "Perform sttm.auto_map now" in messages[0]["content"][1]["text"]
        assert "source_dependencies contains columns" in messages[0]["content"][1]["text"]


def test_focused_registry_distinguishes_sql_alias_from_internal_handle():
    from app.core.automap_policy import POLICY_VERSION
    value = payload(description_size=0)
    value["context"]["learning_context"] = {"automap_policy_version": POLICY_VERSION}
    node = value["context"]["relation_graph"]["nodes"][0]
    node["relation_id"] = "sql-cte:doc:statement:0/scope:12:SOURCE"
    node["alias"] = "cte_source"
    registry = AutoMapContext(value).manifest()["context"]["auto_map_retrieval"]["relation_registry"]
    assert registry["D.S.A"]["sql_qualifier"] == "cte_source"
    assert node["relation_id"] in registry["D.S.A"]["aliases"]


def test_unretrieved_or_invented_evidence_cannot_be_returned_as_grounded():
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    raw, _, _ = service(ScriptedAgent(bad=True))._invoke_retrieval_auto_map(
        STTMBuilderEnvelopeRequest.model_validate(value), SimpleNamespace())
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["transformation_classification"] == "unresolved"
    assert mapping["source_attributes"] == []


def test_invalid_schema_is_retried_not_mistaken_for_explicit_abstention():
    class InvalidThenValidAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            raw, thread, metadata = super().run_detailed(messages, **kwargs)
            answer = json.loads(raw)
            if len(self.calls) == 2:
                for mapping in answer["data"]["result"]["mappings"].values():
                    mapping["confidence_score"] = 95
            return json.dumps(answer), thread, metadata
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    agent = InvalidThenValidAgent()
    raw, _, _ = service(agent)._invoke_retrieval_auto_map(
        STTMBuilderEnvelopeRequest.model_validate(value), SimpleNamespace())
    assert len(agent.calls) == 3
    assert "batch_evidence_deficits" in json.loads(agent.calls[2][0][0]["content"][0]["text"])
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]


def test_unsourced_exact_precedent_claim_is_not_accepted_even_with_column_reads():
    class FalsePrecedentAgent(ScriptedAgent):
        def run_detailed(self, messages, **kwargs):
            raw, thread, metadata = super().run_detailed(messages, **kwargs)
            answer = json.loads(raw)
            for mapping in ((answer.get("data") or {}).get("result") or {}).get("mappings", {}).values():
                mapping["pattern_decision"] = "accept_exact_precedent"
                mapping["precedent_decision"] = "accept_precedent"
            return json.dumps(answer), thread, metadata
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    raw, _, _ = service(FalsePrecedentAgent())._invoke_retrieval_auto_map(
        STTMBuilderEnvelopeRequest.model_validate(value), SimpleNamespace())
    mapping = json.loads(raw)["data"]["result"]["mappings"]["NAME0"]
    assert mapping["transformation_classification"] == "unresolved"
    assert "unsupported" in mapping["unmatched_reason"]


def test_bootstrap_analyst_restore_is_explicit_and_specs_match_backend():
    from pathlib import Path
    import yaml
    root = Path(__file__).resolve().parents[5]
    bootstrap = (root / "scripts/bootstrap_sttm_metadata_infra.py").read_text(encoding="utf-8")
    assert '"--restore-bundle-analyst-tools", action="store_true"' in bootstrap
    assert "if args.restore_bundle_analyst_tools:" in bootstrap
    for filename in ("agent_spec_source_mapping.yaml", "agent_spec_sttm_builder.yaml"):
        spec = yaml.safe_load((root / "infra/snowflake/agents" / filename).read_text(encoding="utf-8"))
        instructions = spec["instructions"]["orchestration"]
        if filename == "agent_spec_source_mapping.yaml":
            assert "meta.evidence_requests" in instructions and "CASE" in instructions
        else:
            assert "CORTEX_ANALYST" in instructions
            assert "backend delegation" in instructions
        assert not any(tool["tool_spec"]["type"] == "cortex_analyst_text_to_sql" for tool in spec.get("tools", []))


@pytest.mark.parametrize("sql", ["DELETE FROM D.S.A", "SELECT X47 FROM D.S.A; DELETE FROM D.S.A",
                                 "SELECT X47 FROM OTHER.S.A", "SELECT EVIL_FUNCTION(X47) FROM D.S.A"])
def test_analyst_delegation_does_not_execute_mutation_or_unselected_scope(sql):
    instance = service(ScriptedAgent())
    instance._model_guard.guard_sql = lambda sql, decision: None
    req_value = payload(description_size=0)
    req_value["context"]["learning_context"] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(req_value)
    semantic = SimpleNamespace(semantic_view_name="D.S.SV_A", semantic_model_yaml=None, bundle_id="prepared")
    instance._prefetched_semantic_refresh = lambda req: semantic
    instance._analyst = SimpleNamespace(ask=lambda **kwargs: SimpleNamespace(sql=sql, request_id="analyst", warnings=[]))
    executions = []
    instance._preview_sql_rows = lambda sql: executions.append(sql)
    with pytest.raises(ValueError):
        instance._auto_map_analyst_evidence(req, {"tool": "CORTEX_ANALYST", "snapshot_hash": "exact",
                                               "question": "Is the source key unique?", "requires_actual_rows": True},
                                          SimpleNamespace(warnings=[]), "exact")
    assert not executions


def test_analyst_uses_prepared_view_and_distinguishes_sql_from_actual_rows():
    instance = service(ScriptedAgent())
    instance._model_guard.guard_sql = lambda sql, decision: None
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    instance._prefetched_semantic_refresh = lambda req: SimpleNamespace(semantic_view_name="D.S.SV_A", bundle_id="prepared")
    calls = []
    def ask(**kwargs):
        calls.append(kwargs)
        return SimpleNamespace(sql="SELECT COUNT(*) AS N FROM D.S.A", request_id="analyst", warnings=[])
    instance._analyst = SimpleNamespace(ask=ask)
    instance._preview_sql_rows = lambda sql: []
    result = instance._auto_map_analyst_evidence(req, {"tool": "CORTEX_ANALYST", "snapshot_hash": "exact",
                                                    "question": "How many rows?", "requires_actual_rows": True},
                                               SimpleNamespace(warnings=[]), "exact")
    assert calls[0]["semantic_view"] == "D.S.SV_A"
    assert calls[0]["semantic_model_yaml"] is None
    assert result["data_result_obtained"] is False


def test_actual_private_worker_router_handles_all_37_targets_without_saving_mappings(monkeypatch):
    from app.api.deps import get_sttm_builder_service
    from app.auto_mapping_worker.main import app
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    value = payload(37)
    value["context"]["learning_context"] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    agent = ScriptedAgent()
    instance = service(agent)
    instance._with_semantic_context = lambda req: (req, None)
    instance._sanitize_request_semantic_context = lambda req: req
    instance._with_learning_context = lambda req: req
    instance._govern_request_for_model = lambda req, decision: req
    instance._should_use_analyst = lambda *args: False
    instance._build_governance_decision = lambda req: SimpleNamespace()
    instance._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    instance._persist_response_artifact = lambda *args: None
    # Supply an already prepared execution context to avoid fixture-only memory reads.
    req.context.prepared_context_hash = "fixture-prepared"
    from app.schema.sttm_builder import AgentExecutionContextV2
    req.context.execution_context = AgentExecutionContextV2(context_key="isolated")
    instance._settings = instance._settings.model_copy(update={"app_env": "local", "auto_map_pipeline_v2": True,
                                                              "auto_mapping_service_url": "inprocess"})
    app.dependency_overrides[get_sttm_builder_service] = lambda: instance
    try:
        proxy = AutoMappingProxyClient(instance._settings)
        response = proxy._invoke_complete_batch(req, headers={}, batch_index=0)
    finally:
        app.dependency_overrides.pop(get_sttm_builder_service, None)
    assert len(response.result.mappings) == 37
    assert all(item.source_attributes == ["a.X47"] for item in response.result.mappings.values())
    assert len(agent.calls) == 2