from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from app.core.learning_subjects import target_column_subject

# source_system and target_standard are written by the FIR pipeline on the shared table.
PatternScope = Literal["client", "project", "mapping", "source_system", "target_standard"]
PatternValidationStatus = Literal[
    "extracted", "enriched", "accepted", "validated", "published", "rejected"
]


class TargetMappingPatternV2(BaseModel):
    pattern_id: str
    subject_type: Literal["target_column", "mapping_row"] = "target_column"
    subject_key: str = ""
    claim_key: str = "preferred_source_recipe"
    scope: PatternScope = "client"
    project_id: str | None = None
    sttm_id: str | None = None
    target_contract: dict[str, Any]
    source_system_profile: dict[str, Any] = Field(default_factory=dict)
    source_compatibility_signature: str
    mapping_recipe: dict[str, Any]
    relationship_dependencies: list[dict[str, Any]] = Field(default_factory=list)
    derived_dependencies: list[dict[str, Any]] = Field(default_factory=list)
    query_shaping_dependencies: list[dict[str, Any]] = Field(default_factory=list)
    business_rationale: str | None = None
    applicability_conditions: list[str] = Field(default_factory=list)
    exclusions: list[str] = Field(default_factory=list)
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    support_count: int = 1
    contradiction_count: int = 0
    validation_status: PatternValidationStatus = "extracted"
    provenance: dict[str, Any] = Field(default_factory=dict)
    evidence_ids: list[str] = Field(default_factory=list)
    superseded_by: str | None = None
    content_hash: str
    # Reuse identity: the same target column fed the same way from the same
    # source shape. Independent mappings that agree share one reuse key and
    # raise its support; exact-content variants keep their own CONTENT_HASH.
    reuse_key: str | None = None
    source_recipe_contract: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    @model_validator(mode="after")
    def canonicalize_subject(self) -> "TargetMappingPatternV2":
        target_table = str(
            self.target_contract.get("target_table")
            or self.target_contract.get("table_fqn")
            or self.target_contract.get("target_fqn")
            or ""
        )
        target_column = str(
            self.target_contract.get("target_column")
            or self.target_contract.get("column_name")
            or ""
        )
        if not self.subject_key and target_table and target_column:
            self.subject_key = target_column_subject(target_table, target_column)
        if not self.subject_key:
            # Legacy uploads may have no resolved target contract yet. Retain
            # their row evidence without fabricating a cross-project target.
            asset = str(self.provenance.get("asset_id") or self.pattern_id)
            self.subject_type = "mapping_row"
            self.subject_key = f"mapping_row:{asset}:{target_column}"

        return self


class TargetMappingPatternQuery(BaseModel):
    target_table: str | None = None
    target_columns: list[str] = Field(default_factory=list)
    source_tables: list[str] = Field(default_factory=list)
    source_columns: list[str] = Field(default_factory=list)
    source_column_profiles: list[dict[str, Any]] = Field(default_factory=list)
    crm_family: str | None = None
    relationship_paths: list[str] = Field(default_factory=list)
    derived_outputs: list[str] = Field(default_factory=list)
    workspace_context_id: str | None = None
    project_id: str | None = None
    limit: int = Field(default=100, ge=1, le=500)


class TargetMappingPatternCandidate(BaseModel):
    pattern: TargetMappingPatternV2
    compatibility_tier: int
    compatibility_score: float
    decision: Literal[
        "accept_exact_precedent", "adapt_pattern", "override_pattern", "unresolved"
    ]
    compatibility_reasons: list[str] = Field(default_factory=list)
    missing_dependencies: list[str] = Field(default_factory=list)
    adapted_source_columns: list[str] = Field(default_factory=list)
    compatibility_checks: dict[str, bool | None] = Field(default_factory=dict)
    prepare_source_action: dict[str, Any] | None = None


class FIRLearningJobResponse(BaseModel):
    learning_job_id: str
    status: str
    asset_id: str | None = None
    project_id: str | None = None
    discovered_pattern_count: int = 0
    completed_pattern_count: int = 0
    failed_pattern_count: int = 0
    stage: str | None = None
    progress: float = 0.0
    warnings: list[str] = Field(default_factory=list)
    work_items_by_status: dict[str, int] = Field(default_factory=dict)
    work_items_by_type: dict[str, dict[str, int]] = Field(default_factory=dict)
    target_column_progress: list[dict[str, Any]] = Field(default_factory=list)
