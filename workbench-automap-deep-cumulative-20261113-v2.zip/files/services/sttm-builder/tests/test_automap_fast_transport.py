"""Real factory/admission/transport with fake Snowflake CAS and mock HTTP only."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import replace
import json
from threading import Event, Lock
import time
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from app.core import automap_runtime as runtime
from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.automap_admission import RemoteCallCompleted, request_digest
from app.core.automap_scan import ScanStopped, ScanTransportReason
from app.core.automap_scan_transport import ScanTransportError, TerminalResponseError
from app.core.snowflake_agent import SnowflakeAgentClient
from tests.test_automap_runtime import CALLER, HOST, Database, Session, settings, store_for


SOURCE = "DB.META.AGT_SOURCE_MAPPING"
MESSAGES = [{"role": "user", "content": [{"type": "text", "text": '  original \\" prompt \u00e9\n'}]}]


def reply(data, status=200):
    return httpx.Response(status, stream=httpx.ByteStream(json.dumps(data).encode()))


@pytest.fixture
def harness(monkeypatch):
    database = Database(capacity=4)
    wire = []
    clients = []
    lock = Lock()
    state = SimpleNamespace(answer='{"data":{"mappings":[]}}', mode="success", hook=None,
                            recovery=None, permits=[], models=[], provider_response=None)

    @contextmanager
    def sessions():
        session = Session(database)
        clients.append(session)
        try:
            yield session
        finally:
            session.close()

    def respond(outgoing):
        assert outgoing.headers["Authorization"] == "Bearer caller-only-token"
        assert outgoing.url.host == HOST
        assert "cookie" not in outgoing.headers
        with lock:
            wire.append(outgoing)
        if outgoing.method == "GET":
            assert outgoing.url.path.startswith("/api/v2/cortex/threads/")
            return reply(state.recovery)
        if outgoing.url.path == "/api/v2/cortex/threads":
            assert outgoing.content == b"{}"
            with lock:
                database.requests_threads.append(outgoing)
                thread_id = len(database.requests_threads)
            if state.mode == "thread_lost_ack":
                database.commit_failure = "after"
            return reply({"thread_id": thread_id})
        assert outgoing.url.path in {"/api/v2/databases/DB/schemas/META/agents/AGT_SOURCE_MAPPING:run",
                                     "/api/v2/databases/DB/schemas/META/agents/AGT_TRANSFORMATION_RULE:run"}
        expected_agent = "DB.META." + outgoing.url.path.rsplit("/", 1)[-1].split(":")[0]
        payload = json.loads(outgoing.content)
        assert set(payload) == {"messages", "stream", "thread_id", "parent_message_id"}
        assert payload["stream"] is False and payload["parent_message_id"] == 0
        with database.lock:
            slot = next(deepcopy(slot) for slot in database.slots if slot["STATE"] == "HELD"
                and json.loads(slot.get("RECONCILIATION_REF") or "{}").get("thread_id") == payload["thread_id"])
            archived = [json.loads(text) for texts in database.blobs.values() for text in texts]
        reference = json.loads(slot["RECONCILIATION_REF"])
        assert reference["agent_fqn"] == expected_agent
        record = next(item["value"] for item in archived
            if item["value"].get("protocol") == "automap_fast_model_request_v1"
            and item["value"]["request_digest"] == reference["request_digest"])
        assert any(item["value"].get("protocol") == "automap_exact_snapshot_v1" for item in archived)
        assert all(item["scope"]["owner_id"] == CALLER.native_user for item in archived)
        assert outgoing.content == ('{"messages":' + record["request"]["message"]
            + ',"stream":false,"thread_id":' + str(payload["thread_id"]) + ',"parent_message_id":0}').encode()
        assert any(query == "COMMIT" and any("SET RECONCILIATION_REF" in previous_query
            and previous_params[0] == slot["RECONCILIATION_REF"]
            for previous_session, previous_query, previous_params, _ in database.log[:index]
            if previous_session is session)
            for index, (session, query, _, _) in enumerate(database.log))
        with lock:
            state.models.append(outgoing)
        if state.hook:
            state.hook(outgoing)
        if state.mode == "lost_ack":
            raise httpx.ReadError("PRIVATE response acknowledgement lost")
        if state.mode == "timeout":
            raise httpx.ReadTimeout("PRIVATE ambiguous POST timeout")
        if state.mode == "http500":
            return reply({"status": "completed", "error": "PRIVATE"}, 500)
        if state.mode == "http429":
            return reply({"error": "rate limit"}, 429)
        if state.mode == "invalid_wire":
            return httpx.Response(200, stream=httpx.ByteStream(b"not provider JSON"))
        if state.mode == "output_archive_failure":
            database.fail_sql = "INSERT INTO"
        if state.mode == "release_lost_ack":
            database.fail_release_commit = True
        if state.provider_response is not None:
            return reply(state.provider_response)
        content = [{"type": "thinking", "thinking": "ignored"}, {"type": "text", "text": state.answer}]
        if state.mode == "tool_block":
            content.insert(0, {"type": "tool_use", "name": "existing_tool"})
        return reply({"role": "assistant", "status": "completed", "content": content})

    http = httpx.Client(transport=httpx.MockTransport(respond), headers={"Cookie": "not-forwarded"})
    monkeypatch.setattr(runtime, "_shared_http_client", lambda origin: http)
    service = SimpleNamespace(_settings=settings(automap_parallel_pool_capacity=4),
        _session=Session(database), _query_session=Session(database),
        _agent=SnowflakeAgentClient("caller-only-token", host=HOST, role=CALLER.role),
        _source_mapping_agent_name=SOURCE, _transformation_agent_name="DB.META.AGT_TRANSFORMATION_RULE",
        _parallel_caller=CALLER, _parallel_session_factory=sessions,
        _model_guard=SimpleNamespace(assert_model_target_allowed=Mock()))
    req = SimpleNamespace(operation=SimpleNamespace(value="sttm.auto_map"), request_id="FORGED_JOB",
        actor=SimpleNamespace(user_id="FORGED_OWNER"), meta={"source_mapping_agent": "BAD.BAD.AGENT"})
    result = SimpleNamespace(service=service, req=req, decision=object(), store=store_for(),
        database=database, state=state, wire=wire, clients=clients, deadline=time.monotonic() + 30)
    yield result
    http.close()


def build(harness, *, deadline=None):
    model = runtime.build_fast_model_runtime(harness.service, harness.req, harness.decision,
        harness.store, harness.deadline if deadline is None else deadline)
    original = model.bundle.admission.store.try_claim

    def claim(identity):
        permit = original(identity)
        if permit is not None:
            harness.state.permits.append(permit)
        return permit

    model.bundle.admission.store.try_claim = claim
    return model


def values(harness):
    return [json.loads(text)["value"] for texts in harness.database.blobs.values() for text in texts]


def test_exact_single_post_source_agent_and_archive_before_consumer(harness):
    original = deepcopy(MESSAGES)
    model = build(harness)
    archive_put = model.bundle.archive.put

    def verify_put(reference, text):
        if json.loads(text)["value"]["protocol"] == "automap_fast_model_response_v1":
            assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
        archive_put(reference, text)

    model.bundle.archive.put = verify_put
    raw, thread, payload = model.run(MESSAGES, 1)
    assert raw == harness.state.answer and thread is None
    assert MESSAGES == original
    diagnostic = payload["fast_diagnostics"]
    assert diagnostic["global_admission"] is True and diagnostic["pool_capacity"] == 4
    assert diagnostic["job_id"] != harness.req.request_id
    assert diagnostic["request_digest"] == request_digest(model.request_for(1))
    assert diagnostic["transport"][-1]["status"] == "completed"
    assert diagnostic["thread_post_attempts"] == diagnostic["model_post_attempts"] == 1
    assert diagnostic["terminal_responses"] == diagnostic["archived_responses"] == 1
    assert diagnostic["runtime_phase"] == "final_check"
    assert diagnostic["phase_seconds"]["admission_cleanup"] >= 0
    assert len(harness.state.models) == len(harness.database.requests_threads) == 1
    assert json.loads(model.bundle.archive.get(diagnostic["response_archive_ref"]))["value"]["raw"] == raw
    assert harness.service._model_guard.assert_model_target_allowed.call_args.kwargs["decision"] is harness.decision
    assert all(session.closed for session in harness.clients)


@pytest.mark.parametrize("session_mode", [False, True])
def test_evidence_reviews_do_not_consume_source_or_rule_budget(harness, session_mode):
    from app.core.automap_fast_transport import FastSessionModelRuntime
    if session_mode:
        harness.service._settings.automap_fast_max_in_flight = 4
        harness.service._agent.run_detailed = Mock(return_value=("{}", None, {}))
        model = FastSessionModelRuntime(service=harness.service, req=harness.req,
            decision=harness.decision, store=harness.store, deadline=harness.deadline)
    else:
        model = build(harness)
    stages = ["evidence_review"] * 3 + ["source_mapping"] * 3 + ["transformation_rule"] * 2
    for index, stage in enumerate(stages, 1):
        model.run(MESSAGES, index, stage=stage)
    assert model._stage_calls == {"evidence_review": 3, "source_mapping": 3, "transformation_rule": 2}
    assert model.next_call_index == 9
    with pytest.raises(ValueError, match="budget"):
        model.run(MESSAGES, 9, stage="evidence_review")
    if not session_mode:
        assert len(harness.state.models) == 8
        assert {model.request_for(index).deadline for index in range(1, 9)} == {harness.deadline}
        assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)


@pytest.mark.parametrize("mode", ["timeout", "http500"])
def test_session_runtime_never_replays_uncertain_post(harness, monkeypatch, mode):
    from app.core import snowflake_agent
    from app.core.automap_fast_transport import FastSessionModelRuntime
    calls = []

    def respond(request):
        calls.append(request)
        if mode == "timeout":
            raise httpx.ReadTimeout("PRIVATE timeout")
        return reply({"error": "PRIVATE"}, 500)

    harness.service._settings.automap_fast_max_in_flight = 4
    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        monkeypatch.setattr(snowflake_agent, "_shared_http_client", lambda _: client)
        model = FastSessionModelRuntime(service=harness.service, req=harness.req,
            decision=harness.decision, store=harness.store, deadline=harness.deadline)
        with pytest.raises(snowflake_agent.SnowflakeAgentError):
            model.run(MESSAGES, 1, stage="evidence_review")
        with pytest.raises(ValueError, match="must not be retried"):
            model.run(MESSAGES, 2)
    assert len(calls) == 1


def test_source_and_specialist_have_separate_v3_call_caps(harness):
    harness.service._settings.automap_parallel_max_calls = 8
    model = build(harness)
    model.run(MESSAGES, 1)
    for index in range(2, 4):
        model.run(MESSAGES, index, stage="transformation_rule")
    with pytest.raises(ValueError, match="call budget"):
        model.run(MESSAGES, 4, stage="transformation_rule")
    assert len(harness.state.models) == 3
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    archived = [value for value in values(harness) if value.get("protocol") == "automap_fast_model_request_v1"]
    assert len({value["job_id"] for value in archived}) == 1
    assert sum(value["agent_fqn"] == "DB.META.AGT_TRANSFORMATION_RULE" for value in archived) == 2


def test_malformed_mapping_json_is_terminal_new_operation_not_http_retry(harness):
    model = build(harness)
    harness.state.answer = "malformed MODEL JSON; not scan output"
    assert model.run(MESSAGES, 1)[0] == harness.state.answer
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    harness.state.answer = '{"status":"NEEDS_INPUT","data":{"mappings":[]}}'
    assert model.run(MESSAGES, 2)[0] == harness.state.answer
    assert model.request_for(1).shard_id != model.request_for(2).shard_id
    assert model.request_for(1).deadline == model.request_for(2).deadline == harness.deadline
    assert len([value for value in values(harness) if value["protocol"] == "automap_exact_snapshot_v1"]) == 1
    assert len(harness.state.models) == 2
    assert model.run(MESSAGES, 3)[0] == harness.state.answer
    assert len(harness.state.models) == 3


def test_actual_fast_context_packet_and_source_envelope_not_scan_protocol(harness, monkeypatch):
    from tests.unit.core.test_automap_fast_context import plan_for
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import SourceMappingResult

    harness.store, plan = plan_for()
    messages = plan.messages([])
    before = deepcopy(vars(harness.store))
    harness.state.answer = json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
        "NAME0": {"source_attributes": ["a.X47"], "confidence_score": 0.9,
                  "transformation_classification": "direct"}}}}})
    monkeypatch.setattr("app.core.automap_parallel.prepare_parallel", Mock(side_effect=AssertionError("scan/reducer")))
    model = build(harness)
    raw, _, _ = model.run(messages, 1)
    parser = STTMBuilderService.__new__(STTMBuilderService)
    assert isinstance(parser._parse_envelope(raw)[1], SourceMappingResult)
    assert vars(harness.store) == before
    sent = json.loads(harness.state.models[0].content)["messages"]
    assert sent == SnowflakeAgentClient._normalize_messages(messages)
    assert "auto_map_fast_path_v1" in model.request_for(1).message
    assert len(harness.state.models) == 1


def test_missing_parallel_factory_remains_denied_with_complete_request_fixture(harness):
    from app.core.automap_batch import invoke_batch

    harness.service._build_auto_map_parallel_runtime = None
    with pytest.raises(ValueError, match="_build_auto_map_parallel_runtime"):
        invoke_batch(harness.service, harness.req, harness.decision)
    assert not harness.wire and not harness.database.blobs


def test_same_call_index_cannot_dispatch_twice(harness):
    model = build(harness)
    model.run(MESSAGES, 1)
    with pytest.raises(ValueError, match="unused operation"):
        model.run(MESSAGES, 1)
    assert len(harness.state.models) == 1


@pytest.mark.parametrize("agent", [None, "DB.META.AGT_AUTOMAP_SCAN_DEV_TEST", "OTHER.META.AGT_SOURCE_MAPPING",
    "DB.OTHER.AGT_SOURCE_MAPPING", "DB.META.USER_AGENT", 'DB.META."AGT_SOURCE_MAPPING"', "DB.META.AGT_SOURCE_MAPPING;DROP"])
def test_wrong_or_untrusted_agent_denied_before_io(harness, agent):
    harness.service._source_mapping_agent_name = agent
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.wire and not harness.database.log


@pytest.mark.parametrize("capacity", [0, True])
def test_rejects_invalid_provisioned_capacity(harness, capacity):
    harness.service._settings.automap_parallel_pool_capacity = capacity
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    assert not harness.wire and not harness.database.claims


@pytest.mark.parametrize("capacity", [2, 5, 8])
def test_configurable_durable_capacity_does_not_dispatch_scan_agent(harness, capacity):
    harness.service._settings.automap_parallel_pool_capacity = capacity
    harness.service._settings.automap_parallel_test_agent = None
    model = build(harness)
    assert model.bundle.admission.store.capacity == capacity
    assert model.bundle.backend._config.agent == SOURCE
    assert not harness.wire


def test_rejects_wrong_caller_and_policy_denial(harness):
    harness.service._parallel_caller = replace(CALLER, native_user="BOB")
    with pytest.raises(runtime.RuntimeConfigurationError):
        build(harness)
    harness.service._parallel_caller = CALLER
    harness.service._model_guard.assert_model_target_allowed.side_effect = PermissionError("blocked")
    with pytest.raises(PermissionError):
        build(harness)
    assert not harness.wire and not harness.database.blobs


@pytest.mark.parametrize("messages", [[], MESSAGES * 2, [{"role": "assistant", "content": "no"}],
    [{"role": "user", "status": "pending", "content": "no"}],
    [{"role": "user", "content": [{"type": "tool_result", "text": "no"}]}]])
def test_invalid_normalized_request_denied_before_archive_or_thread(harness, messages):
    model = build(harness)
    with pytest.raises((ValueError, ScanTransportError)):
        model.run(messages, 1)
    assert not harness.wire and not harness.database.blobs


@pytest.mark.parametrize("text,chars,size", [('"' * 150, 250, 1000), ('\u00e9' * 100, 1000, 250)])
def test_exact_escaped_and_utf8_normalized_message_budget(harness, text, chars, size):
    harness.service._settings.agent_outbound_message_max_chars = chars
    harness.service._settings.agent_outbound_message_max_bytes = size
    model = build(harness)
    with pytest.raises(AgentPayloadBudgetError):
        model.run([{"role": "user", "content": text}], 1)
    assert not harness.wire and not harness.database.blobs


def test_deadline_not_reset_during_archive_preparation(harness):
    model = build(harness)
    model._deadline = time.monotonic() - 1
    with pytest.raises(ScanStopped):
        model.run(MESSAGES, 1)
    assert not harness.wire and not harness.database.blobs


def test_queue_wait_cannot_dispatch_past_original_deadline(harness):
    from app.core.automap_admission import CallIdentity

    model = build(harness, deadline=time.monotonic() + 0.25)
    pool = model.bundle.admission.store
    for index in range(4):
        assert pool.try_claim(CallIdentity("other-job", CALLER.native_user, "generation", f"shard-{index}"))
    with pytest.raises(ScanStopped):
        model.run(MESSAGES, 1)
    assert not harness.wire
    assert all(slot["STATE"] == "HELD" for slot in harness.database.slots)


def test_parsed_output_budget_is_terminal_without_quarantine(harness):
    from app.core.automap_scan_transport import TerminalOutputBudgetError

    harness.service._settings.agent_outbound_message_max_chars = 200
    harness.service._settings.agent_outbound_message_max_bytes = 1000
    harness.state.answer = "x" * 201
    model = build(harness)
    with pytest.raises(TerminalOutputBudgetError):
        model.run(MESSAGES, 1)
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    assert len(harness.state.models) == 1


def test_raw_response_limit_remains_uncertain_not_a_mapping_repair(harness):
    from app.core.automap_scan_transport import RawResponseBudgetError

    harness.state.answer = "x" * 120_001
    model = build(harness)
    with pytest.raises(RawResponseBudgetError):
        model.run(MESSAGES, 1)
    assert any(slot["STATE"] == "QUARANTINED" for slot in harness.database.slots)
    with pytest.raises(ValueError):
        model.run(MESSAGES, 2)
    assert len(harness.state.models) == 1


@pytest.mark.parametrize("mode", ["lost_ack", "http500", "invalid_wire", "thread_lost_ack", "release_lost_ack"])
def test_uncertain_exchange_keeps_occupied_and_no_new_operation(harness, mode):
    harness.state.mode = mode
    model = build(harness)
    with pytest.raises(Exception):
        model.run(MESSAGES, 1)
    harness.database.commit_failure = None
    assert any(slot["STATE"] in ("HELD", "QUARANTINED") for slot in harness.database.slots)
    assert len(harness.state.models) == (0 if mode == "thread_lost_ack" else 1)
    before = len(harness.wire)
    with pytest.raises(ValueError, match="must not be retried"):
        model.run(MESSAGES, 2)
    assert len(harness.wire) == before
    assert not any(value["protocol"] == "automap_fast_model_response_v1" for value in values(harness))


@pytest.mark.parametrize("mode", ["http429", "tool_block", "output_archive_failure"])
def test_known_terminal_failure_or_archive_failure_never_http_retries(harness, mode):
    harness.state.mode = mode
    model = build(harness)
    with pytest.raises(Exception):
        model.run(MESSAGES, 1)
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    assert len(harness.state.models) == 1
    with pytest.raises(ValueError):
        model.run(MESSAGES, 2)
    assert len(harness.state.models) == 1


def test_terminal_shape_failure_archived_after_release_before_consumer(harness, caplog):
    secret = "PRIVATE-content-credential-and-tool-name"
    harness.state.provider_response = {"role": "assistant", "status": "completed", "content": [
        {"type": "thinking", "thinking": secret}, {"type": "text", "text": secret},
        {"type": secret + "\nspoofed-log", "name": secret}]}
    model = build(harness)
    archive_put = model.bundle.archive.put

    def verify_put(reference, text):
        if json.loads(text)["value"]["protocol"] == "automap_fast_model_failure_v1":
            assert model._stop.is_set()
            assert model.failure_diagnostics is None
            assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
            assert secret not in text
        archive_put(reference, text)

    model.bundle.archive.put = verify_put
    with pytest.raises(TerminalResponseError) as caught:
        model.run(MESSAGES, 1)
    assert isinstance(caught.value, RemoteCallCompleted)
    metadata = model.failure_diagnostics
    assert metadata == caught.value.fast_diagnostics
    assert metadata["failure_code"] == "terminal_response"
    assert metadata["failure_archive_status"] == "acknowledged"
    failure = json.loads(model.bundle.archive.get(metadata["failure_archive_ref"]))["value"]
    assert set(failure) == {"protocol", "request_archive_ref", "fast_diagnostics"}
    assert failure["request_archive_ref"] == metadata["request_archive_ref"]
    event = failure["fast_diagnostics"]["transport"][-1]
    assert event["response_reason"] == "invalid_content_kind"
    assert event["block_types"] == ["text", "thinking", "unknown"] and event["block_count"] == 3
    assert len(metadata["transport"]) <= 6
    assert secret not in json.dumps(metadata) + caplog.text
    assert len(harness.state.models) == 1
    caught.value.fast_diagnostics.clear()
    metadata.clear()
    assert model.failure_diagnostics["failure_code"] == "terminal_response"
    with pytest.raises(ValueError, match="must not be retried"):
        model.run(MESSAGES, 2)
    assert len(harness.state.models) == 1


@pytest.mark.parametrize("mode,code", [("lost_ack", ScanTransportReason.HTTP_READ_ERROR.value),
    ("http500", ScanTransportReason.UNEXPECTED_HTTP_STATUS.value),
    ("invalid_wire", ScanTransportReason.MALFORMED_JSON.value), ("thread_lost_ack", "unknown_failure")])
def test_unknown_failure_archive_never_releases_quarantined_permit(harness, mode, code):
    harness.state.mode = mode
    model = build(harness)
    with pytest.raises(Exception):
        model.run(MESSAGES, 1)
    metadata = model.failure_diagnostics
    assert metadata["failure_code"] == code
    assert metadata["failure_archive_status"] == ("unavailable" if mode == "thread_lost_ack" else "acknowledged")
    assert any(slot["STATE"] == "QUARANTINED" for slot in harness.database.slots)
    assert all(event["response_reason"] is None for event in metadata["transport"])
    assert "PRIVATE" not in json.dumps(metadata)
    before = len(harness.wire)
    with pytest.raises(ValueError, match="must not be retried"):
        model.run(MESSAGES, 2)
    assert len(harness.wire) == before


@pytest.mark.parametrize("failure", ["put", "ack", "deadline"])
def test_failure_archive_unavailable_preserves_original_error_and_deadline(harness, caplog, failure):
    harness.state.mode = "tool_block"
    model = build(harness)
    archive = model.bundle.archive
    original_put, original_get = archive._put, archive._read_many
    refs = []

    def put(session, reference, text):
        if json.loads(text)["value"]["protocol"] == "automap_fast_model_failure_v1":
            refs.append(reference)
            assert archive is model.bundle.archive
            if failure == "put":
                raise RuntimeError("PRIVATE archive credentials")
            if failure == "deadline":
                archive._deadline = time.monotonic() - 1
        original_put(session, reference, text)

    def get(session, references):
        result = original_get(session, references)
        return {key: None if failure == 'ack' and key in refs else value for key,value in result.items()}

    archive._put, archive._read_many = put, get
    archive.with_deadline = Mock(side_effect=AssertionError("Must not extend archive deadline"))
    with pytest.raises(TerminalResponseError) as caught:
        model.run(MESSAGES, 1)
    metadata = caught.value.fast_diagnostics
    assert metadata["failure_archive_status"] == "unavailable"
    assert "failure_archive_ref" not in metadata
    assert model.request_for(1).deadline == harness.deadline
    assert metadata["transport"][-1]["response_reason"] == "invalid_content_kind"
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
    assert len(refs) == 1 and len(harness.state.models) == 1
    assert "Auto-map fast failure diagnostics archive unavailable" in caplog.text
    assert "PRIVATE" not in caplog.text + json.dumps(metadata)
    archive.with_deadline.assert_not_called()


def test_release_failure_retains_safe_transport_reason_without_claiming_release(harness):
    harness.state.mode = "release_lost_ack"
    harness.state.provider_response = {"status": "completed", "role": "assistant",
                                      "content": [{"type": "tool_result", "name": "PRIVATE"}]}
    model = build(harness)
    with pytest.raises(Exception) as caught:
        model.run(MESSAGES, 1)
    assert isinstance(caught.value, RemoteCallCompleted)
    metadata = model.failure_diagnostics
    assert metadata["failure_code"] == "terminal_response"
    assert metadata["cleanup_failure_code"] == "admission_claim_uncertain"
    assert metadata["transport"][-1]["response_reason"] == "invalid_content_kind"
    assert any(slot["STATE"] in ("HELD", "QUARANTINED") for slot in harness.database.slots)
    assert len(harness.state.models) == 1


def test_baseexception_still_stops_and_quarantines_without_retry(harness):
    original = KeyboardInterrupt("PRIVATE interruption")
    harness.state.hook = Mock(side_effect=original)
    model = build(harness)
    with pytest.raises(KeyboardInterrupt) as caught:
        model.run(MESSAGES, 1)
    assert caught.value is original
    assert model.failure_diagnostics["failure_code"] == "unknown_failure"
    assert "PRIVATE" not in json.dumps(model.failure_diagnostics)
    assert any(slot["STATE"] == "QUARANTINED" for slot in harness.database.slots)
    with pytest.raises(ValueError, match="must not be retried"):
        model.run(MESSAGES, 2)
    assert len(harness.state.models) == 1


@pytest.mark.parametrize("phase,protocol,readback,posts", [
    ("snapshot_write", "automap_exact_snapshot_v1", False, 0),
    ("snapshot_readback", "automap_exact_snapshot_v1", True, 0),
    ("request_write", "automap_fast_model_request_v1", False, 0),
    ("request_readback", "automap_fast_model_request_v1", True, 0),
    ("response_write", "automap_fast_model_response_v1", False, 1),
    ("response_readback", "automap_fast_model_response_v1", True, 1),
])
def test_all_archive_boundaries_report_safe_failure_phase(harness, phase, protocol, readback, posts):
    model = build(harness)
    archive = model.bundle.archive
    original_put, original_get = archive._put_many, archive._read_many
    original_single = archive._put
    failing = set()

    def put(session, items):
        for reference, text in items.items():
            if json.loads(text)["value"]["protocol"] == protocol:
                failing.add(reference)
                if not readback:
                    raise RuntimeError("PRIVATE archive failure")
        return original_put(session, items)

    def get(session, references):
        result = original_get(session, references)
        return {key: None if readback and key in failing else value for key,value in result.items()}

    def single(session, reference, text):
        if json.loads(text)["value"]["protocol"] == protocol:
            failing.add(reference)
            if not readback:
                raise RuntimeError("PRIVATE archive failure")
        return original_single(session, reference, text)

    archive._put_many, archive._read_many, archive._put = put, get, single
    with pytest.raises((RuntimeError, ValueError)):
        model.run(MESSAGES, 1)
    metadata = model.failure_diagnostics
    assert metadata["runtime_phase"] == (phase if phase.startswith("response") else "request_readback" if readback else "snapshot_write")
    assert metadata["thread_post_attempts"] == metadata["model_post_attempts"] == posts
    assert metadata["terminal_responses"] == posts
    assert metadata["archived_responses"] == 0
    assert metadata["failure_archive_status"] == "acknowledged"
    assert "PRIVATE" not in json.dumps(metadata)
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)


@pytest.mark.parametrize("phase,posts", [("admission_wait", 0), ("permit_renewal", 0), ("lifecycle_bind", 0), ("thread_persist", 1)])
def test_predispatch_failure_phase_does_not_invent_model_posts(harness, phase, posts):
    from app.core.automap_admission import AdmissionUnavailable
    model = build(harness)
    gate = model.bundle.admission
    failure = Mock(side_effect=AdmissionUnavailable("PRIVATE failure"))
    if phase == "admission_wait":
        gate.store.try_claim = failure
    elif phase == "permit_renewal":
        gate.store.renew = failure
    elif phase == "lifecycle_bind":
        gate.bind_lifecycle = failure
    else:
        gate.store.record_reconciliation = failure
    with pytest.raises(AdmissionUnavailable):
        model.run(MESSAGES, 1)
    metadata = model.failure_diagnostics
    assert metadata["runtime_phase"] == phase
    assert metadata["thread_post_attempts"] == posts
    assert metadata["model_post_attempts"] == metadata["terminal_responses"] == 0
    assert metadata["failure_kind"] == "admission_unavailable"
    assert metadata["failure_archive_status"] == "acknowledged"
    assert "PRIVATE" not in json.dumps(metadata)
    assert not harness.state.models
    if phase in {"lifecycle_bind", "thread_persist"}:
        assert any(slot["STATE"] == "QUARANTINED" for slot in harness.database.slots)


def test_admission_wait_reports_zero_posts_and_uses_only_reserved_finalization(harness):
    from app.core.automap_admission import CallIdentity
    deadline = time.monotonic() + .25
    finalization = deadline + 2
    model = runtime.build_fast_model_runtime(harness.service, harness.req, harness.decision,
        harness.store, deadline, finalization_deadline=finalization)
    for index in range(4):
        model.bundle.admission.store.try_claim(CallIdentity("other", CALLER.native_user, "generation", f"shard-{index}"))
    with pytest.raises(ScanStopped):
        model.run(MESSAGES, 1)
    metadata = model.failure_diagnostics
    assert metadata["runtime_phase"] == "admission_wait"
    assert metadata["stop_reason"] == "deadline_expired"
    assert metadata["model_post_attempts"] == metadata["thread_post_attempts"] == 0
    assert metadata["failure_archive_status"] == "acknowledged"
    assert model.request_for(1).deadline == model.bundle.archive._deadline == deadline
    assert model._failure_archive._deadline == finalization
    assert not harness.wire
    assert all(slot["STATE"] == "HELD" for slot in harness.database.slots)


@pytest.mark.parametrize("extra", [-1, 21, float("inf"), float("nan")])
def test_factory_rejects_finalization_outside_reserved_parent_budget(harness, extra):
    with pytest.raises(runtime.RuntimeConfigurationError):
        runtime.build_fast_model_runtime(harness.service, harness.req, harness.decision,
            harness.store, harness.deadline, finalization_deadline=harness.deadline + extra)
    assert not harness.wire and not harness.database.blobs


@pytest.mark.parametrize("kind,reason", [("cancel", "canceled"), ("deadline", "deadline_expired"), ("internal", "internal_stop")])
def test_stop_diagnostics_distinguish_cancellation_deadline_and_internal_stop(harness, kind, reason, monkeypatch):
    model = build(harness)
    if kind == "deadline":
        clock = time.monotonic
        harness.state.hook = lambda _: monkeypatch.setattr(time, "monotonic", lambda: clock() + 60)
    else:
        event = model._cancel if kind == "cancel" else model._stop
        harness.state.hook = lambda _: event.set()
    with pytest.raises(ScanStopped):
        model.run(MESSAGES, 1)
    assert model.failure_diagnostics["stop_reason"] == reason
    assert model.failure_diagnostics["model_post_attempts"] == 1
    assert any(slot["STATE"] in {"HELD", "QUARANTINED"} for slot in harness.database.slots)


def test_expired_failure_finalization_skips_archive_acquisition(harness):
    model = build(harness)
    archive = model.bundle.archive
    original = archive.put_many_verified
    writes = []

    def put(items, **kwargs):
        writes.extend(json.loads(text)["value"]["protocol"] for text in items.values())
        archive._deadline = time.monotonic() - 1
        original(items, **kwargs)

    archive.put_many_verified = put
    archive._factory = Mock(side_effect=AssertionError("expired archive must not acquire a session"))
    with pytest.raises(runtime.ArchiveDeadlineExpired):
        model.run(MESSAGES, 1)
    assert writes == ["automap_exact_snapshot_v1", "automap_fast_model_request_v1"]
    assert model.failure_diagnostics["failure_kind"] == "archive_deadline"
    assert model.failure_diagnostics["failure_archive_status"] == "unavailable"
    archive._factory.assert_not_called()
    assert not harness.wire


def test_snapshot_commit_failure_prevents_any_thread_or_model(harness):
    model = build(harness)
    harness.database.commit_failure = "after"
    with pytest.raises(runtime.ArchiveStorageFailure):
        model.run(MESSAGES, 1)
    assert not harness.wire and not harness.database.claims


def test_four_independent_runtime_jobs_overlap_fifth_waits_under_shared_cas(harness):
    models = [build(harness) for _ in range(5)]
    all_four = Event()
    release = Event()
    blocked = Event()
    lock = Lock()
    active = 0
    peak = 0

    def hook(outgoing):
        nonlocal active, peak
        with lock:
            active += 1
            peak = max(peak, active)
            if active == 4:
                all_four.set()
        assert release.wait(10)
        with lock:
            active -= 1

    original = models[-1].bundle.admission.store.try_claim

    def claim(identity):
        result = original(identity)
        if result is None:
            blocked.set()
        return result

    models[-1].bundle.admission.store.try_claim = claim
    harness.state.hook = hook
    with ThreadPoolExecutor(5) as workers:
        futures = [workers.submit(model.run, MESSAGES, 1) for model in models[:4]]
        try:
            assert all_four.wait(8)
            futures.append(workers.submit(models[-1].run, MESSAGES, 1))
            assert blocked.wait(5)
            assert len(harness.database.requests_threads) == len(harness.state.models) == 4
            assert sum(slot["STATE"] == "HELD" for slot in harness.database.slots) == 4
        finally:
            release.set()
        assert all(future.result(10)[2]["fast_diagnostics"]["global_admission"] for future in futures)
    assert peak == 4
    assert len(harness.state.models) == 5 and len({permit.identity.job_id for permit in harness.state.permits}) == 5
    assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)


@pytest.mark.parametrize("stage", ["source_mapping", "transformation_rule"])
@pytest.mark.parametrize("mutation", [None, "wrong_prompt", "plain_model_status", "extra_branch", "wrong_digest", "wrong_backend"])
def test_generic_terminal_reconciliation_requires_original_prompt_not_scan_schema(harness, mutation, stage):
    model = build(harness)
    harness.state.mode = "lost_ack"
    with pytest.raises(ScanTransportError):
        model.run(MESSAGES, 1, stage=stage)
    request = model.request_for(1)
    permit = harness.state.permits[0]
    user = dict(json.loads(request.message)[0], schema_version="v2")
    assistant = {"schema_version": "v2", "role": "assistant", "status": "completed",
        "content": [{"type": "text", "text": "not valid mapping JSON"}]}
    if mutation == "wrong_prompt":
        user["content"][0]["text"] += " "
    if mutation == "plain_model_status":
        assistant.pop("status")
        assistant["content"] = [{"type": "text", "text": '{"status":"completed"}'}]
    harness.state.recovery = {"metadata": {"thread_id": 1}, "messages": [
        {"message_id": 2, "parent_id": 0, "role": "user", "message_type": "conversation",
         "message_payload": json.dumps(user)},
        {"message_id": 3, "parent_id": 2, "role": "assistant", "message_type": "conversation",
         "message_payload": json.dumps(assistant)}]}
    if mutation == "extra_branch":
        harness.state.recovery["messages"].append(dict(harness.state.recovery["messages"][1], message_id=4))
    if mutation == "wrong_digest":
        request = replace(request, message=request.message + " ")
    before_posts = len([outgoing for outgoing in harness.wire if outgoing.method == "POST"])
    bundle = model.recovery_bundle_for(1)
    if mutation == "wrong_backend":
        bundle = replace(bundle, backend=model.bundle.backend if stage == "transformation_rule" else model._specialist_backend)
    if mutation is None:
        result = model.reconcile_call(1, permit=permit, retired_dispatcher=True, deadline=time.monotonic() + 20)
    else:
        result = runtime.reconcile_parallel_runtime(bundle, permit=permit, original_request=request,
            snapshot_archive_ref=model.snapshot_archive_ref, retired_dispatcher=True, deadline=time.monotonic() + 20)
    assert (result.status is runtime.ReconciliationStatus.RELEASED) is (mutation is None)
    assert len([outgoing for outgoing in harness.wire if outgoing.method == "POST"]) == before_posts
    if mutation is None:
        assert all(slot["STATE"] == "FREE" for slot in harness.database.slots)
        assert any(value["protocol"] == "automap_terminal_reconciliation_v1" for value in values(harness))
    else:
        assert any(slot["STATE"] == "QUARANTINED" for slot in harness.database.slots)
        if mutation == "wrong_backend":
            assert not any(outgoing.method == "GET" for outgoing in harness.wire)


def test_verified_archive_readback_uses_one_exclusive_lease_and_acknowledged_commit(harness):
    model=build(harness);archive=model.bundle.archive;original=archive._factory;leases=[]
    @contextmanager
    def factory():
        with original() as session:
            leases.append(session)
            yield session
    archive._factory=factory
    archive.put_verified(model.snapshot_archive_ref,model._snapshot_text)
    assert len(leases)==1
    assert archive.get(model.snapshot_archive_ref)==model._snapshot_text
    assert len(leases)==2


def test_completed_trace_does_not_charge_later_work_to_final_check(monkeypatch):
    from app.core.automap_scan import RuntimeCallTrace, RuntimePhase
    trace=RuntimeCallTrace();trace.enter(RuntimePhase.FINAL_CHECK);trace.finish()
    before=trace.snapshot()
    clock=time.monotonic
    monkeypatch.setattr(time,'monotonic',lambda:clock()+100)
    assert trace.snapshot()==before
