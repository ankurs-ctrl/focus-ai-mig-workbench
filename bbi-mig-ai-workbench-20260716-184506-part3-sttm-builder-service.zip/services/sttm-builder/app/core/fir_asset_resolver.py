from __future__ import annotations

import json
import uuid
from typing import Any

from app.core.config import Settings


class FIRAssetTableResolver:
    """Resolve document identifiers without guessing and persist their roles."""

    def __init__(self, session: Any, settings: Settings) -> None:
        self._session = session
        self._settings = settings
        self._references_table = settings.qualify_metadata_object_name(
            "TBL_FIR_ASSET_TABLE_REFERENCES"
        )
        self._projects_table = settings.qualify_metadata_object_name("TBL_PROJECTS")

    def resolve_and_store(
        self,
        *,
        asset_id: str,
        project_id: str,
        references: list[tuple[str, str]],
    ) -> list[dict[str, Any]]:
        defaults = self._project_defaults(project_id)
        catalog = self._catalog()
        self._session.sql(
            f"DELETE FROM {self._references_table} WHERE SQL_ASSET_ID = ? AND PROJECT_ID = ?",
            [asset_id, project_id],
        ).collect()
        resolved = [
            self._resolve(raw_identifier=identifier, role=role, catalog=catalog, defaults=defaults)
            for identifier, role in references
            if str(identifier).strip()
        ]
        for item in resolved:
            self._persist(asset_id=asset_id, project_id=project_id, item=item)
        return resolved

    def _project_defaults(self, project_id: str) -> tuple[str, str]:
        try:
            rows = self._session.sql(
                f"SELECT PROJECT_METADATA FROM {self._projects_table} WHERE PROJECT_ID = ?",
                [project_id],
            ).collect()
            metadata = rows[0]["PROJECT_METADATA"] if rows else {}
            if isinstance(metadata, str):
                metadata = json.loads(metadata)
            return (
                str((metadata or {}).get("database") or (metadata or {}).get("database_name") or "").upper(),
                str((metadata or {}).get("schema") or (metadata or {}).get("schema_name") or "").upper(),
            )
        except Exception:
            return "", ""

    def _catalog(self) -> list[dict[str, Any]]:
        semantic_rows = self._session.sql(f"""
            SELECT DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, FQN, VIEW_ID, STATUS
            FROM {self._settings.resolved_semantic_views_table}
            WHERE COALESCE(UPPER(STATUS), 'ACTIVE') = 'ACTIVE'
        """).collect()
        semantic = [row.as_dict() if hasattr(row, "as_dict") else dict(row) for row in semantic_rows]
        semantic_by_fqn = {
            str(row.get("FQN") or f"{row.get('DATABASE_NAME')}.{row.get('SCHEMA_NAME')}.{row.get('TABLE_NAME')}").upper(): row
            for row in semantic
        }
        try:
            physical_rows = self._session.sql("""
                SELECT TABLE_CATALOG AS DATABASE_NAME, TABLE_SCHEMA AS SCHEMA_NAME,
                       TABLE_NAME, CONCAT_WS('.', TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME) AS FQN
                FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES
                WHERE DELETED IS NULL
                  AND TABLE_SCHEMA <> 'INFORMATION_SCHEMA'
            """).collect()
        except Exception:
            # Environments without ACCOUNT_USAGE imported privileges can still
            # resolve every table represented in the semantic registry.
            return semantic
        catalog: list[dict[str, Any]] = []
        for physical_row in physical_rows:
            physical = physical_row.as_dict() if hasattr(physical_row, "as_dict") else dict(physical_row)
            physical_fqn = str(physical.get("FQN") or "").upper()
            semantic_row = semantic_by_fqn.get(physical_fqn)
            catalog.append({
                **physical,
                "VIEW_ID": semantic_row.get("VIEW_ID") if semantic_row else None,
                "STATUS": semantic_row.get("STATUS") if semantic_row else None,
                "SEMANTIC_AVAILABLE": bool(semantic_row),
            })
        return catalog

    @staticmethod
    def _resolve(
        *,
        raw_identifier: str,
        role: str,
        catalog: list[dict[str, Any]],
        defaults: tuple[str, str],
    ) -> dict[str, Any]:
        raw = raw_identifier.strip().strip('"').upper()
        parts = [part.strip('"') for part in raw.split(".") if part]
        default_database, default_schema = defaults

        def fqn(row: dict[str, Any]) -> str:
            return str(row.get("FQN") or f"{row.get('DATABASE_NAME')}.{row.get('SCHEMA_NAME')}.{row.get('TABLE_NAME')}").upper()

        method = "unresolved"
        candidates: list[dict[str, Any]] = []
        if len(parts) == 3:
            candidates = [row for row in catalog if fqn(row) == ".".join(parts)]
            method = "exact_fqn"
        elif len(parts) == 2:
            candidates = [
                row for row in catalog
                if str(row.get("SCHEMA_NAME") or "").upper() == parts[0]
                and str(row.get("TABLE_NAME") or "").upper() == parts[1]
            ]
            method = "unique_schema_table"
        elif len(parts) == 1 and default_database and default_schema:
            candidates = [
                row for row in catalog
                if str(row.get("DATABASE_NAME") or "").upper() == default_database
                and str(row.get("SCHEMA_NAME") or "").upper() == default_schema
                and str(row.get("TABLE_NAME") or "").upper() == parts[0]
            ]
            method = "project_database_schema"
        if not candidates and len(parts) == 1:
            candidates = [
                row for row in catalog
                if str(row.get("TABLE_NAME") or "").upper() == parts[0]
            ]
            method = "unique_table_name"

        status = "resolved" if len(candidates) == 1 else "ambiguous" if len(candidates) > 1 else "unresolved"
        selected = candidates[0] if len(candidates) == 1 else None
        semantic_available = bool(selected and (selected.get("SEMANTIC_AVAILABLE", selected.get("VIEW_ID") is not None)))
        return {
            "reference_id": f"asset_ref_{uuid.uuid4().hex[:20]}",
            "raw_identifier": raw_identifier,
            "reference_role": role,
            "resolution_status": status,
            "resolved_fqn": fqn(selected) if selected else None,
            "candidate_fqns": [fqn(row) for row in candidates],
            "semantic_table_view_id": selected.get("VIEW_ID") if selected else None,
            "semantic_status": "active" if semantic_available else "missing",
            "resolution_method": method,
            "resolution_confidence": 1.0 if selected and method == "exact_fqn" else 0.9 if selected else 0.0,
        }

    def _persist(self, *, asset_id: str, project_id: str, item: dict[str, Any]) -> None:
        self._session.sql(f"""
            MERGE INTO {self._references_table} target
            USING (SELECT ? AS REFERENCE_ID) source
            ON target.REFERENCE_ID = source.REFERENCE_ID
            WHEN NOT MATCHED THEN INSERT (
                REFERENCE_ID, SQL_ASSET_ID, PROJECT_ID, RAW_IDENTIFIER,
                REFERENCE_ROLE, RESOLUTION_STATUS, RESOLVED_FQN, CANDIDATE_FQNS,
                SEMANTIC_TABLE_VIEW_ID, SEMANTIC_STATUS, RESOLUTION_METHOD,
                RESOLUTION_CONFIDENCE, ATTRIBUTES
            ) VALUES (?, ?, ?, ?, ?, ?, ?, PARSE_JSON(?), ?, ?, ?, ?, PARSE_JSON('{{}}'))
        """, [
            item["reference_id"], item["reference_id"], asset_id, project_id,
            item["raw_identifier"], item["reference_role"], item["resolution_status"],
            item["resolved_fqn"], json.dumps(item["candidate_fqns"]),
            item["semantic_table_view_id"], item["semantic_status"],
            item["resolution_method"], item["resolution_confidence"],
        ]).collect()
