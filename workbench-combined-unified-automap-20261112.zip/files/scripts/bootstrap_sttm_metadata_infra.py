#!/usr/bin/env python3
"""Create STTM metadata tables, procedures, tools, and agents in a target namespace."""

from __future__ import annotations

import argparse
import io
import json
import os
import re
from pathlib import Path

import snowflake.connector
import yaml
from snowflake.connector.util_text import split_statements


ROOT_DIR = Path(__file__).resolve().parent.parent
NAMESPACE_PLACEHOLDER = "__STTM_METADATA_NAMESPACE__"
SEMANTIC_TABLE_OBJECT_PLACEHOLDER = "__SEMANTIC_TABLE_VIEWS_OBJECT__"
SEMANTIC_COLUMN_OBJECT_PLACEHOLDER = "__SEMANTIC_COLUMN_VIEWS_OBJECT__"
SEMANTIC_NATIVE_OBJECT_PLACEHOLDER = "__SEMANTIC_NATIVE_VIEWS_OBJECT__"
METADATA_DATABASE_PLACEHOLDER = "__STTM_METADATA_DATABASE__"
METADATA_SCHEMA_PLACEHOLDER = "__STTM_METADATA_SCHEMA__"
SKILLS_STAGE_NAME = "STTM_AGENT_SKILLS"

BASE_SQL_FILES = [
    ROOT_DIR / "infra/snowflake/fir_system/tables/tbl_fir_agent_recommendations.sql",
    ROOT_DIR / "infra/snowflake/create-table-ddl.sql",
    ROOT_DIR / "infra/snowflake/project-bootstrap-lock.sql",
    ROOT_DIR / "infra/snowflake/sql_upload_recovery_v1.sql",
    ROOT_DIR
    / "infra/snowflake/migrations/20260723_warehouse_routing_conversation_artifacts.sql",
    ROOT_DIR / "infra/snowflake/migrations/20260731_project_attributes.sql",
    ROOT_DIR / "infra/snowflake/migrations/20260801_agent_artifact_jobs.sql",
    ROOT_DIR / "infra/snowflake/migrations/20260911_full_registry_semantic_mode.sql",
    ROOT_DIR / "infra/snowflake/create-derived-sources-table.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-table-ddl.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-list-tables.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-list-columns.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-sample-data.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-table-stats.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-attribute-profile.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-table-relationship.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-check-table-staleness.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-check-column-staleness.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-cached-semantic-view.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-table-context-bundle.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-save-semantic-view.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-semantic-registry.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-rollup-schema-summary.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-semantic-model.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-subagent-semantic-model.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-subagent-source-mapping.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-subagent-transformation-rule.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-dbt-repo-tools.sql",
]

SEMANTIC_V2_SQL_FILES = [
    ROOT_DIR / "infra/snowflake/semantic_registry_v2/semantic-model-v2-infrastructure.sql",
    ROOT_DIR / "infra/snowflake/semantic_registry_v2/latest_views.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/semantic-model-v2-procedures.sql",
]

FIR_SQL_FILES = [
    ROOT_DIR / "infra/snowflake/fir_system/tables/tbl_agent_fir_360.sql",
    ROOT_DIR / "infra/snowflake/fir_system/tables/tbl_semantic_view_versions.sql",
    ROOT_DIR / "infra/snowflake/fir_system/tables/fir_v2_schema.sql",
    ROOT_DIR / "infra/snowflake/fir_system/tables/fir_canonical_history.sql",
    ROOT_DIR / "infra/snowflake/scripts/20260719_evernest_import_reliability.sql",
    ROOT_DIR / "infra/snowflake/fir_system/tables/fir_v2_linking_schema.sql",
    ROOT_DIR / "infra/snowflake/fir_system/streams/fir_streams.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-collect-feedback.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-enrich-context.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-refresh-features.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-backfill-events.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-generate-inferences.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-create-semantic-version.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-generate-recommendations.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-apply-confidence-decay.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-get-agent-recommendations.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-orchestrate-batch.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-consolidate-semantic-versions.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-read-documents.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-read-pending-records.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-read-semantic-evidence.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-store-inference.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-store-recommendation.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-reconcile-recommendation-identities.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-store-qa-pair.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-agent-learning-helpers.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-materialize-derived-source.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-precompute-from-semantic-view.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-precompute-permutations.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-score-recommendations.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-invoke-agent.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-process-learning-queue.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-stream-keepalive.sql",
    ROOT_DIR / "infra/snowflake/fir_system/cortex_search/workbench_rag_search_service.sql",
    ROOT_DIR / "infra/snowflake/fir_system/cortex_search/fir_search_services.sql",
    ROOT_DIR / "infra/snowflake/automap_recipe_search.sql",
]

LINKING_MIGRATION_SQL_FILES = [
    ROOT_DIR / "infra/snowflake/fir_system/tables/fir_v2_linking_schema.sql",
]

PERFORMANCE_R13_SQL_FILES = [
    ROOT_DIR / "infra/snowflake/migrations/20260805_safe_performance.sql",
    ROOT_DIR / "infra/snowflake/agentic_tools/sp-get-table-relationship.sql",
    ROOT_DIR / "infra/snowflake/fir_system/procedures/sp-fir-get-agent-recommendations.sql",
]

POST_AGENT_SQL_FILES = [
    ROOT_DIR / "infra/snowflake/fir_system/tasks/fir_tasks.sql",
]

# preserve: restore prior states; enable-core: core consumers; enable-all: every FIR task.
FIR_TASK_POLICIES = ("preserve", "enable-core", "enable-all")

# Ready-signal streams whose source table is the durable work inventory
# (scripts/fir_stream_recovery.CONTRACTS "durable_signal"): name -> (source, APPEND_ONLY).
FIR_SIGNAL_STREAMS = {
    "STM_FIR_LEARNING_WORK_ITEMS": ("TBL_FIR_LEARNING_WORK_ITEMS", False),
    "STM_FIR_360_CHANGES": ("TBL_AGENT_FIR_360", False),
    "STM_FIR_CONTEXT_EVIDENCE": ("TBL_FIR_CONTEXT_EVIDENCE", True),
    "STM_FIR_RECOMMENDATIONS": ("TBL_FIR_AGENT_RECOMMENDATIONS", True),
    "STM_FIR_PRECOMPUTE_SEM_TABLE_VIEWS": ("SEM_TABLE_VIEWS", False),
    "STM_FIR_PRECOMPUTE_SEM_COLUMN_VIEWS": ("SEM_COLUMN_VIEWS", False),
    "STM_FIR_PRECOMPUTE_SEMANTIC_VERSIONS": ("TBL_SEMANTIC_VIEW_VERSIONS", True),
}

AGENT_SPECS = [
    ("AGT_SOURCE_MAPPING", ROOT_DIR / "infra/snowflake/agents/agent_spec_source_mapping.yaml"),
    ("AGT_TRANSFORMATION_RULE", ROOT_DIR / "infra/snowflake/agents/agent_spec_transformation_rule.yaml"),
    ("AGT_STTM_BUILDER", ROOT_DIR / "infra/snowflake/agents/agent_spec_sttm_builder.yaml"),
    ("AGT_DBT_CONVERSION", ROOT_DIR / "infra/snowflake/agents/agent_spec_dbt_conversion.yaml"),
    ("AGT_DBT_TEST_GENERATION", ROOT_DIR / "infra/snowflake/agents/agent_spec_test_case_generation.yaml"),
    ("AGT_WORKBENCH_CONVERSATION", ROOT_DIR / "infra/snowflake/agents/agent_spec_workbench_conversation.yaml"),
    ("AGT_FIR_SYSTEM", ROOT_DIR / "infra/snowflake/agents/agent_spec_fir_system.yaml"),
]

SEMANTIC_V2_AGENT_SPEC = (
    "AGT_SEMANTIC_MODEL_V2",
    ROOT_DIR / "infra/snowflake/agents/agent_spec_semantic_model_v2.yaml",
)

SEMANTIC_V2_TABLES = {
    "SEM_DATABASE_REGISTRY",
    "SV_PIPELINE_LOG",
    "SEM_SCHEMA_VIEWS",
    "SEM_TABLE_VIEWS",
    "SEM_COLUMN_VIEWS",
    "SEM_NATIVE_VIEWS",
    "COLUMN_SEMANTIC_INDEX",
    "COLUMN_PROFILE_CACHE",
}

SEMANTIC_V2_PROCEDURES = {
    "LIST_TABLES",
    "LIST_COLUMNS",
    "GET_TABLE_DDL",
    "GET_TABLE_STATS",
    "GET_TABLE_RELATIONSHIPS",
    "GET_SAMPLE_ROWS",
    "GET_COLUMN_PROFILE",
    "CHECK_TABLE_STALENESS",
    "CHECK_COLUMN_STALENESS",
    "GET_CACHED_SEMANTIC_VIEW",
    "SAVE_SEMANTIC_VIEW",
    "CREATE_SV_WITHOUT_AGENT",
    "CREATE_SCHEMA_SEMANTIC_VIEWS",
    "REFRESH_COLUMN_SEARCH_INDEX",
    "GENERATE_SV_DIRECT_V2_TEST",
    "CREATE_TABLE_SEMANTIC_VIEW",
}

SEMANTIC_V2_AGENT_TOOLS = {
    "list_tables",
    "list_columns",
    "get_table_ddl",
    "get_table_stats",
    "GET_TABLE_RELATIONSHIPS",
    "get_sample_rows",
    "get_column_profile",
    "CHECK_TABLE_STALENESS",
    "CHECK_COLUMN_STALENESS",
    "GET_CACHED_SEMANTIC_VIEW",
    "SAVE_SEMANTIC_VIEW",
}

SKILL_DIRECTORIES = [
    ROOT_DIR / "infra/snowflake/skills/sttm_bundle_orchestration",
    ROOT_DIR / "infra/snowflake/skills/derived_source_analyst",
    ROOT_DIR / "infra/snowflake/skills/live_feedback_and_recommendations",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database", default=os.environ.get("SNOWFLAKE_DATABASE", ""))
    parser.add_argument("--schema", default=os.environ.get("SNOWFLAKE_SCHEMA", ""))
    parser.add_argument(
        "--semantic-database",
        default=os.environ.get("SNOWFLAKE_SEMANTIC_VIEWS_DATABASE", ""),
    )
    parser.add_argument(
        "--semantic-schema",
        default=os.environ.get("SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA", ""),
    )
    parser.add_argument(
        "--semantic-table-object",
        default=os.environ.get(
            "SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE",
            "LATEST_TABLE_VIEWS",
        ),
    )
    parser.add_argument(
        "--semantic-column-object",
        default=os.environ.get(
            "SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE",
            "LATEST_COLUMN_VIEWS",
        ),
    )
    parser.add_argument(
        "--semantic-native-object",
        default=os.environ.get(
            "SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE",
            "LATEST_NATIVE_VIEWS",
        ),
    )
    parser.add_argument(
        "--preserve-semantic-registry", action="store_true",
        help="Validate existing registry tables without replacing its semantic objects or agent.",
    )
    parser.add_argument("--fir-task-policy", choices=FIR_TASK_POLICIES, default="preserve",
                        help="Restore task states; optionally enable the five core FIR processing tasks.")
    parser.add_argument("--fir-queue-interval-minutes", type=int, default=None,
                        help="Override bounded learning queue polling interval (1-1440 minutes).")
    parser.add_argument("--warehouse", default=os.environ.get("SNOWFLAKE_WAREHOUSE", ""))
    parser.add_argument(
        "--artifact-stage",
        default=os.environ.get(
            "SNOWFLAKE_AGENT_ARTIFACT_STAGE",
            "AI_WORKBENCH_ARTIFACTS",
        ),
    )
    parser.add_argument("--role", default=os.environ.get("SNOWFLAKE_ROLE", ""))
    parser.add_argument("--account", default=os.environ.get("SNOWFLAKE_ACCOUNT", ""))
    parser.add_argument("--user", default=os.environ.get("SNOWFLAKE_USER", ""))
    parser.add_argument("--password", default=os.environ.get("SNOWFLAKE_PASSWORD", ""))
    parser.add_argument(
        "--authenticator",
        default=os.environ.get("SNOWFLAKE_AUTHENTICATOR", ""),
    )
    parser.add_argument("--host", default=os.environ.get("SNOWFLAKE_HOST", ""))
    parser.add_argument(
        "--private-key-file",
        default=os.environ.get("SNOWFLAKE_PRIVATE_KEY_FILE", ""),
        help="PEM private-key file for SNOWFLAKE_JWT authentication.",
    )
    parser.add_argument(
        "--private-key-passphrase",
        default=(
            os.environ.get("PRIVATE_KEY_PASSPHRASE")
            or os.environ.get("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE")
            or os.environ.get("KEY_PASSPHRASE")
            or ""
        ),
        help="Passphrase for the encrypted private key.",
    )
    parser.add_argument(
        "--check-release-parity", action="store_true",
        help="Validate tracked bootstrap files and agent tool resources offline; no Snowflake changes.",
    )
    parser.add_argument(
        "--restore-bundle-analyst-tools", action="store_true",
        help="Legacy opt-in: attach every promoted bundle as a native Analyst tool. The workbench uses request-scoped backend delegation by default.",
    )
    parser.add_argument(
        "--linking-migration-only",
        action="store_true",
        help="Apply only the FIR project/mapping linking migration; do not deploy agents or skills.",
    )
    parser.add_argument(
        "--performance-r13-only",
        action="store_true",
        help=(
            "Apply only the R13 performance table and optimized procedures; "
            "do not deploy agents, tasks, streams, stages, skills, or grants."
        ),
    )
    parser.add_argument("--sql-upload-recovery-only", action="store_true",
        help="Install and verify SQL upload recovery only; preserve agents, tasks, streams and grants.")
    args = parser.parse_args()
    if args.fir_queue_interval_minutes is not None and not 1 <= args.fir_queue_interval_minutes <= 1440:
        parser.error("--fir-queue-interval-minutes must be between 1 and 1440")
    return args


def connect(args: argparse.Namespace, *, paramstyle: str = "pyformat"):
    if not args.account or not args.user:
        raise SystemExit("SNOWFLAKE_ACCOUNT and SNOWFLAKE_USER are required.")
    if not args.database or not args.schema:
        raise SystemExit("SNOWFLAKE_DATABASE and SNOWFLAKE_SCHEMA are required.")

    kwargs: dict[str, object] = {
        "account": args.account,
        "user": args.user,
        "paramstyle": paramstyle,
    }
    if args.host:
        kwargs["host"] = args.host
    if args.role:
        kwargs["role"] = args.role
    if args.warehouse:
        kwargs["warehouse"] = args.warehouse
    if args.database:
        kwargs["database"] = args.database

    authenticator = (args.authenticator or "").strip().lower()
    if authenticator == "externalbrowser":
        kwargs["authenticator"] = "externalbrowser"
    elif authenticator in {"snowflake_jwt", "jwt", "key_pair", "keypair"}:
        if not args.private_key_file:
            raise SystemExit(
                "--private-key-file or SNOWFLAKE_PRIVATE_KEY_FILE is required "
                "when SNOWFLAKE_AUTHENTICATOR=SNOWFLAKE_JWT."
            )

        private_key_path = Path(args.private_key_file)
        if not private_key_path.is_file():
            raise SystemExit(
                f"Snowflake private-key file does not exist: {private_key_path}"
            )

        kwargs["authenticator"] = "SNOWFLAKE_JWT"
        kwargs["private_key_file"] = str(private_key_path)

        if args.private_key_passphrase:
            kwargs["private_key_file_pwd"] = args.private_key_passphrase

    else:
        if not args.password:
            raise SystemExit(
                "SNOWFLAKE_PASSWORD is required unless "
                "SNOWFLAKE_AUTHENTICATOR is externalbrowser or SNOWFLAKE_JWT."
            )
        kwargs["password"] = args.password

    return snowflake.connector.connect(**kwargs)


def target_namespace(database: str, schema: str) -> str:
    return f"{database.strip()}.{schema.strip()}"


def render_sql(
    raw_sql: str,
    namespace: str,
    *,
    warehouse: str = "",
    role: str = "",
    database: str = "",
    semantic_namespace: str = "",
    semantic_table_object: str = "LATEST_TABLE_VIEWS",
    semantic_column_object: str = "LATEST_COLUMN_VIEWS",
    semantic_native_object: str = "LATEST_NATIVE_VIEWS",
) -> str:
    rendered = raw_sql.replace(NAMESPACE_PLACEHOLDER, namespace)
    rendered = rendered.replace("FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA", namespace)
    metadata_database, metadata_schema = namespace.split(".", 1)
    rendered = rendered.replace(METADATA_DATABASE_PLACEHOLDER, metadata_database)
    rendered = rendered.replace(METADATA_SCHEMA_PLACEHOLDER, metadata_schema)
    rendered = rendered.replace("__WAREHOUSE_NAME__", warehouse)
    rendered = rendered.replace("__SERVICE_OWNER_ROLE__", role)
    rendered = rendered.replace("__DATABASE__", database)
    rendered = rendered.replace(
        "__SEMANTIC_REGISTRY_NAMESPACE__",
        semantic_namespace or namespace,
    )
    rendered = rendered.replace(
        SEMANTIC_TABLE_OBJECT_PLACEHOLDER,
        semantic_table_object or "LATEST_TABLE_VIEWS",
    )
    rendered = rendered.replace(
        SEMANTIC_COLUMN_OBJECT_PLACEHOLDER,
        semantic_column_object or "LATEST_COLUMN_VIEWS",
    )
    rendered = rendered.replace(
        SEMANTIC_NATIVE_OBJECT_PLACEHOLDER,
        semantic_native_object or "LATEST_NATIVE_VIEWS",
    )
    return re.sub(
        r"CREATE TABLE(?! IF NOT EXISTS)\s+",
        "CREATE TABLE IF NOT EXISTS ",
        rendered,
        flags=re.IGNORECASE,
    )


def _existing_column_names(connection, table_identifier: str) -> set[str]:
    """Return normalized column names without relying on INFORMATION_SCHEMA casing."""
    with connection.cursor() as cursor:
        cursor.execute(f"DESC TABLE {table_identifier}")
        return {
            str(row[0]).strip().upper()
            for row in cursor.fetchall()
            if row and row[0] is not None
        }


def _skip_redundant_mime_type_add(connection, statement: str, label: str) -> bool:
    """Work around Snowflake ambiguity on ADD COLUMN IF NOT EXISTS MIME_TYPE.

    Some upgraded client tables already contain MIME_TYPE but Snowflake raises
    002028 instead of treating this particular ALTER as a no-op. Inspect the
    table first and skip only this one additive statement when the column is
    demonstrably present.
    """
    if not label.endswith("20260723_warehouse_routing_conversation_artifacts.sql"):
        return False
    match = re.search(
        r"""
        ALTER\s+TABLE\s+
        (?P<table>[A-Za-z0-9_$".]+)
        \s+ADD\s+COLUMN\s+IF\s+NOT\s+EXISTS\s+
        "?MIME_TYPE"?
        \s+STRING
        """,
        statement,
        flags=re.IGNORECASE | re.VERBOSE,
    )
    if not match:
        return False
    table_identifier = match.group("table")
    if "MIME_TYPE" not in _existing_column_names(connection, table_identifier):
        return False
    print(
        "[bootstrap-sttm-metadata] MIME_TYPE already exists on "
        f"{table_identifier}; skipping redundant additive ALTER."
    )
    return True


def _grant_statement_role(statement: str) -> str | None:
    """Return the grantee role name if statement is a `GRANT ... TO ROLE X`."""
    match = re.match(
        r'\s*GRANT\s+.+?\s+TO\s+ROLE\s+"?(?P<role>[A-Za-z0-9_$]+)"?\s*;?\s*$',
        statement,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return match.group("role").upper() if match else None


def _current_session_role(connection) -> str:
    with connection.cursor() as cursor:
        cursor.execute("SELECT CURRENT_ROLE()")
        return str(cursor.fetchone()[0]).upper()


def task_update_statements(statement: str, *, exists: bool) -> list[str]:
    """Convert only the repository's simple independent-task template to ALTER.

    Refuse unsupported syntax instead of silently replacing a task and losing
    history, grants, or graph relationships.
    """
    clean = re.sub(r"(?m)^\s*--[^\r\n]*", "", statement).strip().rstrip(";")
    match = re.fullmatch(
        r"CREATE OR REPLACE TASK ([A-Za-z0-9_$.]+)\s+(.*?)\nAS\s+(.+)",
        clean, re.S | re.I,
    )
    if not match:
        raise ValueError("Unsupported task template; explicit migration required")
    name, header, body = match.groups()
    if not exists:
        return [clean.replace("CREATE OR REPLACE TASK", "CREATE TASK", 1)]
    pieces = re.split(r"\nWHEN\s*\n", header, maxsplit=1, flags=re.I)
    settings = pieces[0].strip()
    for line in settings.splitlines():
        if not re.fullmatch(r"\s*(WAREHOUSE|SCHEDULE|ALLOW_OVERLAPPING_EXECUTION|SUSPEND_TASK_AFTER_NUM_FAILURES|TASK_AUTO_RETRY_ATTEMPTS|USER_TASK_TIMEOUT_MS|COMMENT)\s*=\s*(?:'(?:[^']|'')*'|[A-Za-z0-9_$.]+)\s*", line, re.I):
            raise ValueError("Unsupported task property; explicit migration required")
    return [f"ALTER TASK {name} SET {settings}",
            f"ALTER TASK {name} MODIFY WHEN {pieces[1].strip()}" if len(pieces) == 2 else f"ALTER TASK {name} REMOVE WHEN",
            f"ALTER TASK {name} MODIFY AS {body}"]


def execute_multi_statement(connection, sql_text: str, label: str) -> None:
    print(f"[bootstrap-sttm-metadata] Applying {label}")
    # Snowflake's execute_stream treats a trailing block of line comments after
    # the final semicolon as another (empty) statement when comments are
    # preserved. Keep comments inside SQL/procedure bodies intact, but remove a
    # comment-only tail before handing the stream to the connector.
    executable_sql = re.sub(r"(?:\s*--[^\r\n]*(?:\r?\n|$))+\s*$", "", sql_text)
    if not executable_sql.strip():
        return
    try:
        statements = split_statements(
            io.StringIO(executable_sql),
            remove_comments=False,
        )
        for statement, _is_put_or_get in statements:
            if not statement.strip():
                continue
            if _skip_redundant_mime_type_add(connection, statement, label):
                continue
            try:
                with connection.cursor() as cursor:
                    task_text = re.sub(r"(?m)^\s*--[^\r\n]*", "", statement).lstrip()
                    task_match = re.match(r"CREATE OR REPLACE TASK ([A-Za-z0-9_$.]+)", task_text)
                    if task_match:
                        task_fqn = task_match.group(1)
                        task_namespace, task_name = task_fqn.rsplit(".", 1)
                        cursor.execute(f"SHOW TASKS IN SCHEMA {task_namespace}")
                        columns = [str(item[0]).lower() for item in cursor.description or []]
                        tasks = [dict(zip(columns, row)) for row in cursor.fetchall()]
                        existing = next((row for row in tasks if row.get("name") == task_name), None)
                        if existing and (str(existing.get("state")).lower() != "suspended" or
                                         str(existing.get("predecessors") or "[]") not in {"[]", ""}):
                            raise RuntimeError("Task must be suspended and independent; graph migration requires explicit review")
                        for update in task_update_statements(statement, exists=existing is not None):
                            cursor.execute(update)
                    else:
                        cursor.execute(statement)
                    _ = cursor.rowcount
            except Exception as exc:
                # A managed-access schema blocks GRANT statements from any
                # role except the schema owner or a MANAGE GRANTS holder -
                # even when the grantee is the exact role that just created
                # (and already owns) the object, where the grant is a pure
                # no-op: ownership already implies every privilege being
                # granted. Treat only this narrow, provably-benign case as a
                # soft skip; anything else still aborts the run.
                grantee_role = _grant_statement_role(statement)
                if grantee_role and "managed access schema" in str(exc).lower():
                    if grantee_role == _current_session_role(connection):
                        print(
                            f"[bootstrap-sttm-metadata] Skipping self-grant to "
                            f"{grantee_role} in {label} - already implied by "
                            "object ownership; managed access schema blocks "
                            "the explicit GRANT but not the creator's own access."
                        )
                        continue
                raise
    except Exception as exc:
        raise RuntimeError(f"Failed while applying {label}: {exc}") from exc


def create_schema(connection, database: str, schema: str) -> None:
    statement = f'CREATE SCHEMA IF NOT EXISTS "{database}"."{schema}"'
    with connection.cursor() as cursor:
        cursor.execute(statement)


def create_stage(
    connection,
    database: str,
    schema: str,
    stage_name: str,
) -> None:
    raw_parts = [
        part.strip().strip('"')
        for part in stage_name.lstrip("@").split(".")
        if part.strip()
    ]
    if len(raw_parts) == 1:
        parts = [database, schema, raw_parts[0]]
    elif len(raw_parts) == 3:
        parts = raw_parts
    else:
        raise SystemExit(
            "Stage names must be OBJECT or DATABASE.SCHEMA.OBJECT; received "
            f"'{stage_name}'."
        )
    if any(not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_$]*", part) for part in parts):
        raise SystemExit(f"Unsafe Snowflake stage identifier: '{stage_name}'.")
    qualified = ".".join(f'"{part}"' for part in parts)
    statement = f"CREATE STAGE IF NOT EXISTS {qualified}"
    with connection.cursor() as cursor:
        cursor.execute(statement)


def read_repository_text(path: Path) -> str:
    """Read version-controlled SQL, YAML, and Markdown consistently on Windows."""
    return path.read_text(encoding="utf-8-sig")


def validate_project_bootstrap_lock(connection, namespace: str) -> None:
    with connection.cursor() as cursor:
        cursor.execute(f"SELECT LOCK_KEY, FENCE FROM {namespace}.TBL_PROJECT_BOOTSTRAP_LOCK")
        rows = cursor.fetchall()
    from decimal import Decimal
    if (len(rows) != 1 or rows[0][0] != "project-bootstrap"
            or isinstance(rows[0][1], bool)
            or not isinstance(rows[0][1], (int, Decimal))
            or rows[0][1] < 0 or rows[0][1] != int(rows[0][1])):
        raise RuntimeError("Invalid project bootstrap lock inventory; expected one project-bootstrap row with a nonnegative integer fence. No automatic repair was performed.")


def apply_sql_files(
    connection,
    paths: list[Path],
    *,
    namespace: str,
    warehouse: str,
    role: str,
    database: str,
    semantic_namespace: str,
    semantic_table_object: str,
    semantic_column_object: str,
    semantic_native_object: str,
) -> None:
    for path in paths:
        sql_text = render_sql(
            read_repository_text(path),
            namespace,
            warehouse=warehouse,
            role=role,
            database=database,
            semantic_namespace=semantic_namespace,
            semantic_table_object=semantic_table_object,
            semantic_column_object=semantic_column_object,
            semantic_native_object=semantic_native_object,
        )
        execute_multi_statement(connection, sql_text, str(path.relative_to(ROOT_DIR)))
        if path.name == "project-bootstrap-lock.sql":
            validate_project_bootstrap_lock(connection, namespace)


def activate_session(connection, args: argparse.Namespace) -> None:
    with connection.cursor() as cursor:
        if args.role:
            cursor.execute(f'USE ROLE "{args.role}"')
        if args.warehouse:
            cursor.execute(f'USE WAREHOUSE "{args.warehouse}"')
        if args.database:
            cursor.execute(f'USE DATABASE "{args.database}"')


def render_agent_statement(agent_name: str, spec_text: str, namespace: str) -> str:
    qualified_name = f"{namespace}.{agent_name}"
    profile = f'{{"display_name":"{agent_name}"}}'
    return (
        f"CREATE OR REPLACE AGENT {qualified_name}\n"
        f"    PROFILE = '{profile}'\n"
        "    FROM SPECIFICATION\n"
        "    $$\n"
        f"{spec_text.rstrip()}\n"
        "    $$"
    )


def apply_agents(connection, namespace: str, warehouse: str) -> None:
    for agent_name, path in AGENT_SPECS:
        spec_text = render_sql(read_repository_text(path), namespace, warehouse=warehouse)
        statement = render_agent_statement(agent_name, spec_text, namespace)
        print(
            "[bootstrap-sttm-metadata] Creating agent "
            f"{namespace}.{agent_name} from {path.relative_to(ROOT_DIR)}"
        )
        with connection.cursor() as cursor:
            cursor.execute(statement)


def apply_semantic_v2_agent(connection, namespace: str, warehouse: str) -> None:
    agent_name, path = SEMANTIC_V2_AGENT_SPEC
    spec_text = render_sql(read_repository_text(path), namespace, warehouse=warehouse)
    statement = render_agent_statement(agent_name, spec_text, namespace)
    print(
        "[bootstrap-sttm-metadata] Creating agent "
        f"{namespace}.{agent_name} from {path.relative_to(ROOT_DIR)}"
    )
    with connection.cursor() as cursor:
        cursor.execute(statement)


def verify_semantic_v2_install(connection, database: str, schema: str) -> None:
    with connection.cursor() as cursor:
        cursor.execute(
            f"""
            SELECT TABLE_NAME
            FROM {database}.INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = %s
              AND TABLE_NAME IN ({','.join(['%s'] * len(SEMANTIC_V2_TABLES))})
            """,
            (schema.upper(), *sorted(SEMANTIC_V2_TABLES)),
        )
        installed_tables = {str(row[0]).upper() for row in cursor.fetchall()}
    missing_tables = SEMANTIC_V2_TABLES - installed_tables
    if missing_tables:
        raise RuntimeError(
            "AGT_SEMANTIC_MODEL_V2 bootstrap is missing tables: "
            + ", ".join(sorted(missing_tables))
        )

    with connection.cursor() as cursor:
        cursor.execute(
            f"""
            SELECT PROCEDURE_NAME
            FROM {database}.INFORMATION_SCHEMA.PROCEDURES
            WHERE PROCEDURE_SCHEMA = %s
              AND PROCEDURE_NAME IN ({','.join(['%s'] * len(SEMANTIC_V2_PROCEDURES))})
            """,
            (schema.upper(), *sorted(SEMANTIC_V2_PROCEDURES)),
        )
        installed = {str(row[0]).upper() for row in cursor.fetchall()}
    missing = SEMANTIC_V2_PROCEDURES - installed
    if missing:
        raise RuntimeError(
            "AGT_SEMANTIC_MODEL_V2 bootstrap is missing procedures: "
            + ", ".join(sorted(missing))
        )

    agent_name = f"{database}.{schema}.AGT_SEMANTIC_MODEL_V2"
    with connection.cursor() as cursor:
        cursor.execute(f"DESCRIBE AGENT {agent_name}")
        row = cursor.fetchone()
        columns = [str(item[0]).lower() for item in cursor.description or []]
    described = dict(zip(columns, row or []))
    raw_spec = described.get("agent_spec") or described.get("specification")
    spec = json.loads(raw_spec) if isinstance(raw_spec, str) else raw_spec
    if not isinstance(spec, dict):
        raise RuntimeError(f"{agent_name} did not expose a valid specification")
    tool_names = {
        str((item.get("tool_spec") or {}).get("name") or "")
        for item in spec.get("tools") or []
        if isinstance(item, dict)
    }
    missing_tools = SEMANTIC_V2_AGENT_TOOLS - tool_names
    if missing_tools:
        raise RuntimeError(
            f"{agent_name} is missing tools: " + ", ".join(sorted(missing_tools))
        )
    print(
        "[bootstrap-sttm-metadata] Verified AGT_SEMANTIC_MODEL_V2 with "
        f"{len(installed_tables)} tables, {len(installed)} procedures, "
        f"and {len(tool_names)} agent tools."
    )


def upload_skills(connection, database: str, schema: str) -> None:
    stage_path = f'@"{database}"."{schema}"."{SKILLS_STAGE_NAME}"'
    for skill_dir in SKILL_DIRECTORIES:
        for file_path in skill_dir.iterdir():
            if not file_path.is_file():
                continue
            destination = f"{stage_path}/skills/{skill_dir.name}/"
            statement = (
                f"PUT file://{file_path.resolve().as_posix()} "
                f"{destination} AUTO_COMPRESS=FALSE OVERWRITE=TRUE"
            )
            print(
                "[bootstrap-sttm-metadata] Uploading skill file "
                f"{file_path.relative_to(ROOT_DIR)} to {destination}"
            )
            with connection.cursor() as cursor:
                cursor.execute(statement)


def _fetch_single_row_dict(connection, sql: str) -> dict[str, object] | None:
    with connection.cursor() as cursor:
        cursor.execute(sql)
        row = cursor.fetchone()
        if row is None:
            return None
        columns = [str(column[0]) for column in cursor.description or []]
    return dict(zip(columns, row))


def _replace_agent(connection, *, agent_name: str, profile: str, spec: dict[str, object]) -> None:
    spec_yaml = yaml.safe_dump(spec, sort_keys=False, allow_unicode=False)
    escaped_profile = profile.replace("'", "''")
    statement = (
        f"CREATE OR REPLACE AGENT {agent_name}\n"
        f"    PROFILE = '{escaped_profile}'\n"
        "    FROM SPECIFICATION\n"
        "    $$\n"
        f"{spec_yaml.rstrip()}\n"
        "    $$"
    )
    with connection.cursor() as cursor:
        cursor.execute(statement)


def restore_bundle_analyst_tools(connection, *, namespace: str, warehouse: str) -> None:
    bundle_table = f"{namespace}.TBL_SEMANTIC_BUNDLES"
    agent_name = f"{namespace}.AGT_STTM_BUILDER"

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                f"""
                SELECT SEMANTIC_BUNDLE_ID, BUNDLE_LABEL, SEMANTIC_VIEW_NAME, ANALYST_TOOL_NAME
                FROM {bundle_table}
                WHERE SEMANTIC_VIEW_NAME IS NOT NULL
                """
            )
            rows = cursor.fetchall()
            columns = [str(column[0]) for column in cursor.description or []]
    except Exception as exc:
        print(
            "[bootstrap-sttm-metadata] Skipping Analyst tool restore because bundle metadata "
            f"was not readable: {exc}"
        )
        return

    if not rows:
        print("[bootstrap-sttm-metadata] No promoted semantic bundles found to restore.")
        return

    described = _fetch_single_row_dict(connection, f"DESCRIBE AGENT {agent_name}")
    if not described:
        print(f"[bootstrap-sttm-metadata] DESCRIBE AGENT returned no rows for {agent_name}")
        return

    described_lower = {str(key).lower(): value for key, value in described.items()}
    raw_spec = (
        described_lower.get("agent_spec")
        or described_lower.get("specification")
        or described_lower.get("spec")
    )
    if not raw_spec:
        print(f"[bootstrap-sttm-metadata] No agent spec found in DESCRIBE AGENT for {agent_name}")
        return

    profile = str(described_lower.get("profile") or '{"display_name":"AGT_STTM_BUILDER"}')
    spec = yaml.safe_load(raw_spec) if isinstance(raw_spec, str) else raw_spec
    if not isinstance(spec, dict):
        print(f"[bootstrap-sttm-metadata] Agent spec for {agent_name} was not a mapping.")
        return

    tools = spec.setdefault("tools", [])
    tool_resources = spec.setdefault("tool_resources", {})
    if not isinstance(tools, list) or not isinstance(tool_resources, dict):
        print(f"[bootstrap-sttm-metadata] Agent spec for {agent_name} has invalid tool sections.")
        return

    changed = False
    for row in rows:
        row_dict = dict(zip(columns, row))
        bundle_id = str(row_dict.get("SEMANTIC_BUNDLE_ID") or "").strip()
        semantic_view_name = str(row_dict.get("SEMANTIC_VIEW_NAME") or "").strip()
        if not bundle_id or not semantic_view_name:
            continue

        bundle_label = str(row_dict.get("BUNDLE_LABEL") or bundle_id).strip()
        tool_name = str(row_dict.get("ANALYST_TOOL_NAME") or f"ANALYST_{bundle_id.upper()}").strip()

        existing_resource = tool_resources.get(tool_name)
        if not isinstance(existing_resource, dict) or str(existing_resource.get("semantic_view") or "") != semantic_view_name:
            resource: dict[str, object] = {"semantic_view": semantic_view_name}
            if warehouse:
                resource["execution_environment"] = {
                    "type": "warehouse",
                    "warehouse": warehouse,
                }
            tool_resources[tool_name] = resource
            changed = True

        tool_present = any(
            isinstance(tool, dict)
            and isinstance(tool.get("tool_spec"), dict)
            and str(tool["tool_spec"].get("name") or "") == tool_name
            for tool in tools
        )
        if not tool_present:
            tools.append(
                {
                    "tool_spec": {
                        "type": "cortex_analyst_text_to_sql",
                        "name": tool_name,
                        "description": (
                            f"Uses Cortex Analyst over semantic view {semantic_view_name} "
                            f"for analytical questions on {bundle_label}."
                        ),
                    }
                }
            )
            changed = True

    if changed:
        print(
            "[bootstrap-sttm-metadata] Restoring Cortex Analyst tools on "
            f"{agent_name} for promoted semantic bundles."
        )
        _replace_agent(connection, agent_name=agent_name, profile=profile, spec=spec)
    else:
        print("[bootstrap-sttm-metadata] Cortex Analyst tools already up to date.")


def check_release_parity() -> None:
    """Keep new installs reproducible without running full bootstrap on upgrades."""
    for path in [*BASE_SQL_FILES, *FIR_SQL_FILES, *SEMANTIC_V2_SQL_FILES, *POST_AGENT_SQL_FILES]:
        if not path.is_file():
            raise ValueError(f"Missing bootstrap source: {path.relative_to(ROOT_DIR)}")
    for agent_name, path in [*AGENT_SPECS, SEMANTIC_V2_AGENT_SPEC]:
        spec = yaml.safe_load(read_repository_text(path))
        names = [item["tool_spec"]["name"] for item in spec.get("tools", [])]
        if len(names) != len(set(names)):
            raise ValueError(f"Duplicate tools in {agent_name}")
        resources = spec.get("tool_resources") or {}
        if set(resources) - set(names):
            raise ValueError(f"Orphan tool resources in {agent_name}")
        for item in spec.get("tools", []):
            tool = item["tool_spec"]
            if tool["name"] not in resources:
                raise ValueError(f"Missing tool resource in {agent_name}: {tool['name']}")
            if agent_name == "AGT_STTM_BUILDER" and tool["type"] == "cortex_analyst_text_to_sql":
                raise ValueError("Bundle Analyst must be request-local, not installed on the shared agent")
        print(f"[bootstrap-sttm-metadata] Verified {agent_name}: {', '.join(names) or 'no native tools'}")
    print("[bootstrap-sttm-metadata] Offline release parity passed; no Snowflake objects modified.")


def verify_existing_semantic_registry(connection, namespace: str, args) -> None:
    """Validate the consumer contract without touching the externally managed pipeline."""
    objects = (
        (args.semantic_table_object, 'VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, FQN, VERSION, STATUS, ROW_COUNT, COLUMN_COUNT, COLUMN_SET_HASH, LAST_ALTERED_TS, SEMANTIC_VIEW, GENERATED_AT'),
        (args.semantic_column_object, 'VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, ATTRIBUTE_VIEW, GENERATED_AT, STATUS'),
        (args.semantic_native_object, 'NATIVE_VIEW_ID, DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, SOURCE_FQN, TABLE_VIEW_ID, TARGET_FQN, CA_YAML_MODEL, STATUS, CREATED_AT'),
    )
    with connection.cursor() as cursor:
        for name, columns in objects:
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_$]*', name):
                raise ValueError('Preserved semantic registry object must be a simple identifier')
            cursor.execute(f'SELECT {columns} FROM {namespace}.{name} WHERE 1=0')
    print(f'[bootstrap-sttm-metadata] Preserved existing semantic registry and agent: {namespace}')


def capture_fir_task_states(connection, namespace: str) -> dict[str, str]:
    with connection.cursor() as cursor:
        cursor.execute(f"SHOW TASKS IN SCHEMA {namespace}")
        columns = [str(item[0]).lower() for item in cursor.description or []]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
    return {str(row["name"]): str(row["state"]).lower() for row in rows
            if re.fullmatch(r"TSK_FIR_[A-Z0-9_]+", str(row.get("name", "")))}


def _show_fir_streams(connection, namespace: str) -> list[dict]:
    with connection.cursor() as cursor:
        cursor.execute(f"SHOW STREAMS LIKE 'STM_FIR%' IN SCHEMA {namespace}")
        columns = [str(item[0]).lower() for item in cursor.description or []]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]


def _stale(row: dict) -> bool:
    return str(row.get("stale")).lower() == "true"


def preflight_fir_activation(connection, namespace: str, role: str, prior: dict[str, str], policy: str) -> None:
    """Fail before suspension if the requested activation cannot safely proceed."""
    if policy == "preserve" and not any(state == "started" for state in prior.values()):
        return
    if not role:
        raise RuntimeError("FIR activation requires an explicitly configured owner role")
    # Existing task owners survive ALTER-based deployment. Do not infer them
    # from the connection role, and fail before suspending any consumer.
    if prior:
        with connection.cursor() as cursor:
            cursor.execute(f"SHOW TASKS IN SCHEMA {namespace}")
            columns = [str(item[0]).lower() for item in cursor.description or []]
            tasks = [dict(zip(columns, row)) for row in cursor.fetchall()]
        owners = {str(row.get('owner') or '') for row in tasks if row.get('name') in prior}
        if owners != {role}:
            raise RuntimeError("FIR task owners differ from the configured role or are not visible; review each owner before activation")
    pending, inspected, can_execute = [role], set(), False
    while pending:
        current = pending.pop()
        if current in inspected:
            continue
        if len(inspected) >= 100:
            raise RuntimeError("FIR privilege preflight exceeded role hierarchy bound")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_$]*", current):
            raise ValueError("FIR preflight requires a simple role identifier")
        inspected.add(current)
        with connection.cursor() as cursor:
            cursor.execute(f"SHOW GRANTS TO ROLE {current}")
            columns = [str(item[0]).lower() for item in cursor.description or []]
            grants = [dict(zip(columns, row)) for row in cursor.fetchall()]
        for grant in grants:
            if str(grant.get("privilege")).upper() == "EXECUTE TASK" and str(grant.get("granted_on")).upper() == "ACCOUNT":
                can_execute = True
            if str(grant.get("granted_on")).upper() == "ROLE" and grant.get("name"):
                pending.append(str(grant["name"]))
    if not can_execute:
        raise RuntimeError(f"FIR activation blocked: EXECUTE TASK not verified for owner role {role}; obtain administrator review before deployment")
    # Stale ready-signal streams are refreshed after task suspension. A stale
    # data-carrying stream lost unconsumed changes and needs a reviewed replay.
    unsafe = sorted(str(row.get("name")) for row in _show_fir_streams(connection, namespace)
                    if _stale(row) and str(row.get("name")) not in FIR_SIGNAL_STREAMS)
    if unsafe:
        raise RuntimeError("FIR activation blocked: stale streams require a reviewed backfill/cutover; "
                           f"no task was suspended: {unsafe}")


def refresh_stale_signal_streams(connection, namespace: str) -> list[str]:
    """Recreate stale ready-signal streams while every FIR task is suspended.

    A stale offset is unreadable, and these sources are the durable work
    inventory, so nothing is replayed. SHOW_INITIAL_ROWS re-signals existing
    work once so each consumer catches up through its own bounded procedure.
    """
    stale = [row for row in _show_fir_streams(connection, namespace) if _stale(row)]
    if not stale:
        return []
    unsafe = sorted(str(row.get("name")) for row in stale if str(row.get("name")) not in FIR_SIGNAL_STREAMS)
    if unsafe:
        raise RuntimeError(f"Stale data-carrying FIR streams require a reviewed replay: {unsafe}")
    started = sorted(name for name, state in capture_fir_task_states(connection, namespace).items() if state == "started")
    if started:
        raise RuntimeError(f"FIR stream refresh requires every FIR task suspended: {started}")
    refreshed = []
    for row in stale:
        name = str(row["name"])
        source, append_only = FIR_SIGNAL_STREAMS[name]
        if str(row.get("table_name") or "").upper() != f"{namespace}.{source}".upper():
            raise RuntimeError(f"FIR stream {name} source does not match its contract")
        comment = str(row.get("comment") or "").replace("'", "''")
        with connection.cursor() as cursor:
            cursor.execute(
                f"CREATE OR REPLACE STREAM {namespace}.{name} ON TABLE {namespace}.{source} "
                f"APPEND_ONLY = {'TRUE' if append_only else 'FALSE'} SHOW_INITIAL_ROWS = TRUE COMMENT = '{comment}'"
            )
        refreshed.append(name)
    remaining = sorted(str(row.get("name")) for row in _show_fir_streams(connection, namespace) if _stale(row))
    if remaining:
        raise RuntimeError(f"FIR streams still stale after refresh: {remaining}")
    print(f"[bootstrap-sttm-metadata] Refreshed stale FIR signal streams: {', '.join(refreshed)}")
    return refreshed


def run_fir_stream_keepalive(connection, namespace: str) -> None:
    """Run the keepalive once so near-stale data streams are captured immediately."""
    with connection.cursor() as cursor:
        cursor.execute(f"CALL {namespace}.SP_FIR_STREAM_KEEPALIVE(4)")
        row = cursor.fetchone()
    report = row[0] if row else None
    print(f"[bootstrap-sttm-metadata] FIR stream keepalive: {report}")


def restore_fir_task_states(connection, namespace: str, prior: dict[str, str],
                            policy: str, queue_interval: int | None = None) -> None:
    if policy not in FIR_TASK_POLICIES:
        raise ValueError("Invalid FIR task policy")
    if queue_interval is not None and not 1 <= queue_interval <= 1440:
        raise ValueError("FIR queue interval must be between 1 and 1440 minutes")
    installed = capture_fir_task_states(connection, namespace)
    required = (set(installed) if policy == "enable-all" else
                {"TSK_FIR_CAPTURE", "TSK_FIR_ENRICH_CONTEXT", "TSK_FIR_PROCESS_BATCH",
                 "TSK_FIR_PROMOTE_INDEX", "TSK_FIR_LEARNING_QUEUE"} if policy == "enable-core" else set())
    desired = required | {name for name, state in prior.items() if state == "started"}
    missing = desired - installed.keys()
    if missing:
        raise RuntimeError(f"Required FIR tasks missing after bootstrap: {sorted(missing)}")
    if queue_interval is not None:
        if not 1 <= queue_interval <= 1440:
            raise ValueError("FIR queue interval must be between 1 and 1440 minutes")
        with connection.cursor() as cursor:
            cursor.execute(f"ALTER TASK {namespace}.TSK_FIR_LEARNING_QUEUE SUSPEND")
            cursor.execute(f"ALTER TASK {namespace}.TSK_FIR_LEARNING_QUEUE SET SCHEDULE = '{queue_interval} MINUTE'")
    for name in sorted(desired):
        if not re.fullmatch(r"TSK_FIR_[A-Z0-9_]+", name):
            raise ValueError("Invalid FIR task identifier")
        with connection.cursor() as cursor:
            cursor.execute(f"ALTER TASK {namespace}.{name} RESUME")
    actual = capture_fir_task_states(connection, namespace)
    if any(actual.get(name) != "started" for name in desired):
        raise RuntimeError("FIR task activation did not match the configured runtime policy")
    print(f"[bootstrap-sttm-metadata] FIR task policy {policy}: {len(desired)} tasks enabled.")


def verify_sql_upload_recovery(connection, namespace):
    import sys
    sys.path.insert(0, str(ROOT_DIR / "services/sttm-builder"))
    from app.core.sql_upload_jobs import verify_upload_schema
    from snowflake.snowpark import Session
    verify_upload_schema(Session.builder.config("connection", connection).create(), f"{namespace}.TBL_SQL_UPLOAD_REQUESTS")


def main() -> int:
    args = parse_args()
    if args.check_release_parity:
        check_release_parity()
        return 0
    namespace = target_namespace(args.database, args.schema)
    semantic_namespace = target_namespace(
        args.semantic_database or args.database,
        args.semantic_schema or args.schema,
    )

    with connect(args) as connection:
        activate_session(connection, args)
        if getattr(args, "sql_upload_recovery_only", False):
            apply_sql_files(connection, [ROOT_DIR / "infra/snowflake/sql_upload_recovery_v1.sql"],
                namespace=namespace, warehouse=args.warehouse, role=args.role, database=args.database,
                semantic_namespace=semantic_namespace, semantic_table_object=args.semantic_table_object,
                semantic_column_object=args.semantic_column_object, semantic_native_object=args.semantic_native_object)
            verify_sql_upload_recovery(connection, namespace)
            print("[bootstrap-sttm-metadata] SQL upload recovery installed and verified; no grants modified.")
            return 0
        if args.performance_r13_only:
            apply_sql_files(
                connection,
                PERFORMANCE_R13_SQL_FILES,
                namespace=namespace,
                warehouse=args.warehouse,
                role=args.role,
                database=args.database,
                semantic_namespace=semantic_namespace,
                semantic_table_object=args.semantic_table_object,
                semantic_column_object=args.semantic_column_object,
                semantic_native_object=args.semantic_native_object,
            )
            print("")
            print("[bootstrap-sttm-metadata] R13 safe-performance migration completed.")
            print("[bootstrap-sttm-metadata] No tasks, streams, agents, stages, or grants were modified.")
            return 0
        if args.linking_migration_only:
            apply_sql_files(
                connection,
                LINKING_MIGRATION_SQL_FILES,
                namespace=namespace,
                warehouse=args.warehouse,
                role=args.role,
                database=args.database,
                semantic_namespace=semantic_namespace,
                semantic_table_object=args.semantic_table_object,
                semantic_column_object=args.semantic_column_object,
                semantic_native_object=args.semantic_native_object,
            )
            print("")
            print("[bootstrap-sttm-metadata] FIR linking migration completed successfully.")
            print(f"[bootstrap-sttm-metadata] Target namespace: {namespace}")
            return 0
        create_schema(connection, args.database, args.schema)
        prior_fir_tasks = capture_fir_task_states(connection, namespace)
        preflight_fir_activation(connection, namespace, args.role, prior_fir_tasks,
                                 getattr(args, "fir_task_policy", "preserve"))
        semantic_database, semantic_schema = semantic_namespace.split(".", 1)
        if semantic_namespace.upper() != namespace.upper():
            create_schema(connection, semantic_database, semantic_schema)
        create_stage(connection, args.database, args.schema, SKILLS_STAGE_NAME)
        create_stage(connection, args.database, args.schema, args.artifact_stage)
        upload_skills(connection, args.database, args.schema)
        for task_name, task_state in prior_fir_tasks.items():
            if task_state == "started":
                with connection.cursor() as cursor:
                    cursor.execute(f"ALTER TASK {namespace}.{task_name} SUSPEND")
        apply_sql_files(
            connection,
            [*BASE_SQL_FILES, *FIR_SQL_FILES],
            namespace=namespace,
            warehouse=args.warehouse,
            role=args.role,
            database=args.database,
            semantic_namespace=semantic_namespace,
            semantic_table_object=args.semantic_table_object,
            semantic_column_object=args.semantic_column_object,
            semantic_native_object=args.semantic_native_object,
        )
        verify_sql_upload_recovery(connection, namespace)
        if args.preserve_semantic_registry:
            verify_existing_semantic_registry(connection, semantic_namespace, args)
        else:
            # Install V2 last when bootstrap owns the semantic pipeline.
            apply_sql_files(
                connection,
                SEMANTIC_V2_SQL_FILES,
                namespace=semantic_namespace,
                warehouse=args.warehouse,
                role=args.role,
                database=semantic_database,
                semantic_namespace=semantic_namespace,
                semantic_table_object=args.semantic_table_object,
                semantic_column_object=args.semantic_column_object,
                semantic_native_object=args.semantic_native_object,
            )
            apply_semantic_v2_agent(connection, semantic_namespace, args.warehouse)
            verify_semantic_v2_install(connection, semantic_database, semantic_schema)
        apply_agents(connection, namespace, args.warehouse)
        apply_sql_files(
            connection,
            POST_AGENT_SQL_FILES,
            namespace=namespace,
            warehouse=args.warehouse,
            role=args.role,
            database=args.database,
            semantic_namespace=semantic_namespace,
            semantic_table_object=args.semantic_table_object,
            semantic_column_object=args.semantic_column_object,
            semantic_native_object=args.semantic_native_object,
        )
        if os.environ.get("FIR_RECOVER_REVIEWED_UAT") == "20261022F1A1":
            if namespace != "FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT.SCH_STTM_METADATA":
                raise RuntimeError("Reviewed stream recovery is UAT-only")
            from snowflake.snowpark import Session
            import sys
            sys.path.insert(0, str(ROOT_DIR))
            from scripts.fir_stream_recovery import recover_reviewed_uat
            # Snowpark uses qmark binds; bootstrap's connector uses pyformat.
            with connect(args, paramstyle="qmark") as recovery_connection:
                recovery_session = Session.builder.config("connection", recovery_connection).create()
                recover_reviewed_uat(recovery_session)
        refresh_stale_signal_streams(connection, namespace)
        restore_fir_task_states(connection, namespace, prior_fir_tasks,
                                getattr(args, "fir_task_policy", "preserve"),
                                getattr(args, "fir_queue_interval_minutes", None))
        run_fir_stream_keepalive(connection, namespace)
        if args.restore_bundle_analyst_tools:
            restore_bundle_analyst_tools(
                connection, namespace=namespace, warehouse=args.warehouse,
            )
        else:
            print("[bootstrap-sttm-metadata] No shared bundle tools restored. CurrentBundleAnalyst is runtime-only and disabled by default.")
    print("")
    print("[bootstrap-sttm-metadata] Completed successfully.")
    print(f"[bootstrap-sttm-metadata] Target namespace: {namespace}")
    print(f"[bootstrap-sttm-metadata] Semantic registry: {semantic_namespace}")
    print(
        "[bootstrap-sttm-metadata] Semantic objects: "
        f"{args.semantic_table_object}, {args.semantic_column_object}, "
        f"{args.semantic_native_object}"
    )
    print("[bootstrap-sttm-metadata] Role grants were not modified.")
    print("[bootstrap-sttm-metadata] FIR task state verified against runtime policy.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())