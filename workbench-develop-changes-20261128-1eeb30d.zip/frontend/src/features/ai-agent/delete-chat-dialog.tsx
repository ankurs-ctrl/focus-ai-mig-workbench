"use client";

import { useState } from "react";
import { AiaButton, AiaDialog, AiaDialogActions, AiaDialogContent, AiaDialogTitle } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { MODAL_ABOVE_AI_CHAT_Z_INDEX } from "./ai-chat-layout-constants";

export function DeleteChatDialog({ title, onClose, onDelete }: {
  title: string;
  onClose: () => void;
  onDelete: () => Promise<void>;
}) {
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function confirm() {
    setDeleting(true);
    setError(null);
    try {
      await onDelete();
      onClose();
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : "The chat could not be deleted.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <AiaDialog open onClose={deleting ? undefined : onClose} fullWidth maxWidth="xs"
      sx={{ zIndex: MODAL_ABOVE_AI_CHAT_Z_INDEX }}>
      <AiaDialogTitle>Delete chat?</AiaDialogTitle>
      <AiaDialogContent>
        <AiaText>“{title}” and its messages will be permanently deleted from chat history.</AiaText>
        {error && <AiaText role="alert" sx={{ mt: 1, color: "error.main" }}>{error}</AiaText>}
      </AiaDialogContent>
      <AiaDialogActions>
        <AiaButton onClick={onClose} disabled={deleting}>Cancel</AiaButton>
        <AiaButton variant="contained" color="error" onClick={() => void confirm()} disabled={deleting}>
          {deleting ? "Deleting…" : "Delete chat"}
        </AiaButton>
      </AiaDialogActions>
    </AiaDialog>
  );
}
