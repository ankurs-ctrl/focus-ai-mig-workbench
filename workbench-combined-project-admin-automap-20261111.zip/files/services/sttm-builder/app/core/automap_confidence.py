"""Deterministic mapping support estimate; never a probability or approval."""
from app.core.automap_retrieval import AutoMapContext, reference_parts
from app.core.mapping_contracts import valid_attribute_expression
from app.core.mapping_sql import MappingSqlService


WEIGHTS = {'meaning': .30, 'bindings': .25, 'definition': .20, 'history': .15, 'compatibility': .10}


def confidence_estimate(option, req, store, target):
    if store is None:
        from app.schema.sttm_builder import STTMAgentRequestEnvelope
        store = AutoMapContext(STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode='json', exclude_none=True))
    refs = set(option.source_attributes + option.source_dependencies)
    resolved = set()
    for ref in refs:
        try:
            owner, column = reference_parts(ref)
            owner = store.primary_owner(owner)
            if store._column_name(owner, column) is not None:
                resolved.add(ref)
        except (ValueError, TypeError, KeyError):
            pass
    graph = req.context.relation_graph
    values = {value for text in (option.preprocessing_rule, option.constant_value)
              for value in MappingSqlService._placeholders_in_sql(text or '')}
    if option.mapping_mode == 'attribute' and option.attribute_name:
        values.add('$' + option.attribute_name.lstrip('$'))
    bindings = graph.value_bindings if graph else []
    known_value_ids = {identifier for binding in bindings for identifier in (binding.binding_id, binding.value)}
    missing_value_ids = set(option.value_binding_ids) - known_value_ids
    values.update(binding.value for binding in bindings if {binding.binding_id, binding.value} & set(option.value_binding_ids))
    resolved_values = {value for value in values if any(
        binding.value.upper() == value.upper() and binding.resolved_value is not None for binding in bindings)}
    required_count = len(refs) + len(values) + len(missing_value_ids)
    ratio = (len(resolved) + len(resolved_values)) / required_count if required_count else None
    constant = option.mapping_mode == 'constant' and option.constant_value is not None and not values
    complete = option.validation_status == 'valid'
    intent = bool(option.rule_intent or (option.preprocessing_nl_rule or '').strip())
    definition = 1.0 if complete else .5 if intent else 0.0
    categories = {**getattr(store, 'available_evidence', {}).get(target, {}), **store.evidence.get(target, {})}
    records = [item for category, items in categories.items() if 'target_mapping_patterns' in category for item in items]
    trusted = [item for item in records if (item.get('pattern') or item).get('validation_status') in {'published', 'accepted', 'validated'}]
    cited_ids = set(option.used_learning_ids)
    applicable = [item for item in trusted if (item.get('pattern') or item).get('pattern_id') in cited_ids
                  and item.get('applicable') is True and item.get('decision') != 'unresolved']
    history = 1.0 if applicable else .5 if trusted else None if not records else 0.0
    # Explanatory prose alone is not verified semantic support.
    citations = set((option.decision_basis or {}).get('citations') or [])
    source_cited = bool(citations & {identifier for ref in resolved for identifier in (ref, 'src:' + ref)})
    value_cited = bool(citations & {'val:' + value for value in resolved_values})
    meaning = 1.0 if applicable else .5 if source_cited or value_cited else 0.0
    compatibility = .5
    checks = [item.get('compatibility_checks') or {} for item in applicable]
    if checks:
        flags = [value for check in checks for key, value in check.items() if key in {'types_compatible', 'grain_compatible'}]
        compatibility = 0.0 if False in flags else 1.0 if flags and all(value is True for value in flags) else .5
    if not resolved and not resolved_values and not constant:
        # A retained expression or precise intent is a reviewable draft, but
        # inventing a number for an empty unresolved row provides no information.
        supported = bool(trusted and (intent or valid_attribute_expression(option.preprocessing_rule)))
        if not supported:
            return 0.0, {'components': {}, 'reason': 'No verified source, Value, constant or historical rule support'}
    parts = {'meaning': meaning, 'bindings': ratio, 'definition': definition,
             'history': history, 'compatibility': compatibility}
    if constant:
        parts['bindings'] = None
        parts['definition'] = 1.0 if complete else .5
    denominator = sum(WEIGHTS[key] for key, value in parts.items() if value is not None)
    score = sum(WEIGHTS[key] * value for key, value in parts.items() if value is not None) / denominator
    return round(score, 4), {'method': 'weighted_observed_evidence', 'components': {
        key: {'weight': WEIGHTS[key], 'support': value, 'applicable': value is not None} for key, value in parts.items()},
        'resolved_sources': len(resolved), 'required_sources': len(refs),
        'resolved_values': len(resolved_values), 'required_values': len(values),
        'trusted_recipe_count': len(trusted), 'applicable_cited_recipe_count': len(applicable)}
