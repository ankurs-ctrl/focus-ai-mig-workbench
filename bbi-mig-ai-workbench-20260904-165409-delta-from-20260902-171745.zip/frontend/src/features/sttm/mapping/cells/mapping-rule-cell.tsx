import { AiaBox, AiaSelect, AiaTableCellPrimitive } from '@/components/ui';

import type { SxProps, Theme } from '@mui/material/styles';

import { aiaTableCellSx } from '@/components/ui/aia-table';
import {
  MAPPING_PREPROCESS_RULE_SELECT_SX,
  MAPPING_TABLE_SECONDARY_INPUT_SX,
  MAPPING_TYPE_SELECT_SX,
  MAPPING_TYPE_SELECT_WRAPPER_SX,
} from '../mapping-table-styles';

type MappingRuleCellProps = {
  value: string;
  options: Array<{ label: string; value: string }>;
  onRuleChange: (value: string) => void;
  placeholder?: string;
  highlighted?: boolean;
  width?: number | string;
  minWidth?: number | string;
  sx?: SxProps<Theme>;
};

const BASE_SELECT_SX: SxProps<Theme> = {
  ...MAPPING_TABLE_SECONDARY_INPUT_SX,
  ...MAPPING_TYPE_SELECT_SX,
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: '#e5e7eb',
  },
};

const HIGHLIGHTED_SELECT_SX: SxProps<Theme> = {
  bgcolor: '#fef3c7',
  color: '#92400e',
  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
  fontWeight: 600,
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: '#f59e0b',
  },
  '& .MuiInputBase-input, & .MuiAutocomplete-input': {
    color: '#92400e',
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
    fontWeight: 600,
  },
};

const RULE_SELECT_SX: SxProps<Theme> = MAPPING_PREPROCESS_RULE_SELECT_SX;

export const MappingRuleCell = ({
  value,
  options,
  onRuleChange,
  placeholder = 'Select transform rule...',
  highlighted = false,
  width,
  minWidth = 0,
  sx,
}: MappingRuleCellProps) => {
  const selectSx: SxProps<Theme> = highlighted
    ? ([BASE_SELECT_SX, HIGHLIGHTED_SELECT_SX, RULE_SELECT_SX] as SxProps<Theme>)
    : ([BASE_SELECT_SX, RULE_SELECT_SX] as SxProps<Theme>);

  return (
    <AiaTableCellPrimitive
      sx={aiaTableCellSx({ width, minWidth, sx }, { overflow: 'visible', maxWidth: width })}
    >
      <AiaBox sx={MAPPING_TYPE_SELECT_WRAPPER_SX}>
        <AiaSelect
          label=""
          value={value}
          options={options}
          onChange={(next) => onRuleChange(Array.isArray(next) ? next[0] ?? '' : next)}
          placeholder={placeholder}
          size="small"
          fullWidth
          sx={selectSx}
        />
      </AiaBox>
    </AiaTableCellPrimitive>
  );
};
