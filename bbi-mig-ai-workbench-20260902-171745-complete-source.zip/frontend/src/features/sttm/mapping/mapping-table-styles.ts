import {
  aiaDataTableSx,
  AIA_DATA_TABLE_BODY_CELL_SX,
  AIA_DATA_TABLE_HEADER_CELL_SX,
  AIA_DATA_TABLE_ROW_SX,
  AIA_DATA_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
} from '@/components/ui/aia-table/aia-data-table-styles';

export {
  AIA_DATA_TABLE_BODY_CELL_SX as MAPPING_TABLE_BODY_CELL_SX,
  AIA_DATA_TABLE_BODY_TEXT_SX as MAPPING_TABLE_BODY_TEXT_SX,
  AIA_DATA_TABLE_CONTAINER_SX as MAPPING_TABLE_CONTAINER_SX,
  AIA_DATA_TABLE_FILTER_CONTROL_HEIGHT as MAPPING_TABLE_FILTER_CONTROL_HEIGHT,
  AIA_DATA_TABLE_FILTER_CONTROL_ROOT_SX as MAPPING_TABLE_FILTER_CONTROL_ROOT_SX,
  AIA_DATA_TABLE_FILTER_INPUT_SX as MAPPING_TABLE_FILTER_INPUT_SX,
  AIA_DATA_TABLE_FILTER_SELECT_SX as MAPPING_TABLE_FILTER_SELECT_SX,
  AIA_DATA_TABLE_PAGINATION_SX as MAPPING_TABLE_PAGINATION_SX,
  AIA_DATA_TABLE_SCROLLBAR_SX as MAPPING_TABLE_SCROLLBAR_SX,
  AIA_DATA_TABLE_SEARCH_ROW_CELL_SX as MAPPING_TABLE_SEARCH_ROW_CELL_SX,
  AIA_DATA_TABLE_SEARCH_ROW_HEIGHT as MAPPING_TABLE_SEARCH_ROW_HEIGHT,
  AIA_DATA_TABLE_SECONDARY_INPUT_SX as MAPPING_TABLE_SECONDARY_INPUT_SX,
  AIA_DATA_TABLE_SECONDARY_INPUT_TYPOGRAPHY as MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
} from '@/components/ui/aia-table/aia-data-table-styles';

/** Compact column-label header row for the mapping table. */
export const MAPPING_TABLE_HEADER_ROW_HEIGHT = 52;

/** Source column control height (single select / input row). */
export const MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT = 38;
export const MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX = MAPPING_SOURCE_COLUMN_INPUT_MIN_HEIGHT;

/** Body cell vertical padding (theme py: 1.2 → 9.6px each side). */
export const MAPPING_TABLE_BODY_CELL_PADDING_Y_PX = 20;

/** Source-column height is the default min height for every mapping body cell. */
export const MAPPING_TABLE_BODY_ROW_MIN_HEIGHT_PX =
  MAPPING_SOURCE_COLUMN_DEFAULT_HEIGHT_PX + MAPPING_TABLE_BODY_CELL_PADDING_Y_PX;

export const MAPPING_TABLE_HEADER_CELL_SX = {
  ...AIA_DATA_TABLE_HEADER_CELL_SX,
  minHeight: MAPPING_TABLE_HEADER_ROW_HEIGHT,
  height: MAPPING_TABLE_HEADER_ROW_HEIGHT,
  py: 0.75,
  px: 1.25,
  lineHeight: 1.3,
  textAlign: 'left' as const,
  whiteSpace: 'nowrap' as const,
  overflow: 'visible' as const,
  textOverflow: 'clip' as const,
} as const;
/** Body rows size to cell content; data is left-aligned and vertically centered. */
export const MAPPING_TABLE_ROW_SX = {
  ...AIA_DATA_TABLE_ROW_SX,
  height: 'auto',
  minHeight: MAPPING_TABLE_BODY_ROW_MIN_HEIGHT_PX,
  '& > .MuiTableCell-root': {
    height: 'auto',
    minHeight: MAPPING_TABLE_BODY_ROW_MIN_HEIGHT_PX,
    verticalAlign: 'middle',
    textAlign: 'left',
  },
} as const;

export function mappingTableSx(minWidth: number) {
  return {
    ...aiaDataTableSx(minWidth),
    '& .MuiTableBody-root .MuiTableRow-root': {
      height: 'auto',
      minHeight: MAPPING_TABLE_BODY_ROW_MIN_HEIGHT_PX,
    },
    '& .MuiTableBody-root .MuiTableCell-root': {
      ...AIA_DATA_TABLE_BODY_CELL_SX,
      height: 'auto',
      minHeight: MAPPING_TABLE_BODY_ROW_MIN_HEIGHT_PX,
      verticalAlign: 'middle' as const,
      textAlign: 'left' as const,
    },
  };
}

export function scrollableMappingTableSx(minWidth: number) {
  return {
    ...mappingTableSx(minWidth),
    width: `max(100%, ${minWidth}px)`,
  };
}

export const MAPPING_TABLE_CHECKBOX_SX = {
  color: '#cbd5e1',
  '&.Mui-checked': {
    color: 'var(--color-primary)',
  },
  '&.MuiCheckbox-indeterminate': {
    color: 'var(--color-primary)',
  },
} as const;

export const MAPPING_SELECTION_BAR_SX = {
  px: 2,
  py: 1,
  bgcolor: 'rgba(15, 23, 42, 0.06)',
  color: '#0f172a',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 2,
  borderBottom: '1px solid #e2e8f0',
} as const;

/** Rule select and Pre-process icon on one row. */
export const MAPPING_PREPROCESS_RULE_ICON_BUTTON_WIDTH = 36;

export const MAPPING_PREPROCESS_RULE_ICON_BUTTON_SX = {
  width: MAPPING_PREPROCESS_RULE_ICON_BUTTON_WIDTH,
  height: MAPPING_PREPROCESS_RULE_ICON_BUTTON_WIDTH,
  minWidth: MAPPING_PREPROCESS_RULE_ICON_BUTTON_WIDTH,
  flexShrink: 0,
  border: '1px solid #e5e7eb',
  borderRadius: '6px',
  color: 'var(--aia-primary-bg-color)',
  bgcolor: '#fff',
  '&:hover': {
    bgcolor: 'color-mix(in srgb, var(--aia-primary-bg-color) 8%, #fff)',
  },
  '&.Mui-disabled': {
    color: '#cbd5e1',
    borderColor: '#e5e7eb',
  },
} as const;

export const MAPPING_PREPROCESS_RULE_ICON_BUTTON_SPACER_SX = {
  width: MAPPING_PREPROCESS_RULE_ICON_BUTTON_WIDTH,
  minWidth: MAPPING_PREPROCESS_RULE_ICON_BUTTON_WIDTH,
  flexShrink: 0,
} as const;

/** Full-width Mapping Type select (no icon sibling). */
export const MAPPING_TYPE_SELECT_WRAPPER_SX = {
  width: '100%',
  minWidth: 0,
  maxWidth: '100%',
  display: 'flex',
  alignItems: 'center',
} as const;

export const MAPPING_TYPE_SELECT_SX = {
  width: '100%',
  // Fit longest option ("Attribute") + padding + chevron.
  minWidth: 'calc(9ch + 52px)',
  ...AIA_DATA_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
  height: 36,
  minHeight: 36,
  borderRadius: '6px',
  bgcolor: '#fff',
  '& .MuiSelect-select': {
    ...AIA_DATA_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    py: '8px !important',
    pl: '12px !important',
    pr: '36px !important',
    overflow: 'visible',
    textOverflow: 'clip',
    whiteSpace: 'nowrap',
  },
} as const;

/** @deprecated Prefer MAPPING_TYPE_SELECT_WRAPPER_SX */
export const MAPPING_PREPROCESS_RULE_SELECT_WRAPPER_SX = MAPPING_TYPE_SELECT_WRAPPER_SX;

export const MAPPING_PREPROCESS_RULE_ROW_SX = {
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  gap: 0.75,
  width: '100%',
  maxWidth: '100%',
  minWidth: 0,
} as const;

export const MAPPING_PREPROCESS_RULE_SELECT_SX = MAPPING_TYPE_SELECT_SX;

export const MAPPING_PREPROCESS_RULE_FILTER_SX = {
  ...MAPPING_TYPE_SELECT_SX,
  width: '100%',
  minWidth: 0,
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: '#e5e7eb',
  },
} as const;
