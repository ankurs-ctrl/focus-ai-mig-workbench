from __future__ import annotations

import hashlib
import json
import re
from typing import Any
from datetime import UTC, datetime
from uuid import uuid4

from app.agent_runs.models import (
    EFFORT_POLICIES,
    AgentActor,
    AgentReviewItem,
    AgentRun,
    AgentRunEvent,
    ReviewItemStatus,
    RunAnswerRequest,
    RunCancelRequest,
    RunCreateRequest,
    RunResumeRequest,
    RunStateResponse,
    RunStatus,
    TERMINAL_RUN_STATUSES,
    request_hash,
    resolve_effort,
    ReviewChoice,
)
from app.agent_runs.repository import AgentRunRepository


class RunNotFoundError(LookupError):
    pass


class RunAuthorizationError(PermissionError):
    pass


class RunConflictError(RuntimeError):
    pass


def _bounded_id(value: str, limit: int) -> str:
    """``value`` if it fits ``limit``; otherwise a stable prefix plus a digest of the whole id."""
    text = str(value)
    if len(text) <= limit:
        return text
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
    return f"{text[:limit - len(digest) - 1]}~{digest}"


class AgentRunService:
    def __init__(self, repository: AgentRunRepository, *, settings=None, draft_writer=None) -> None:
        self.repository = repository
        self.settings = settings
        # Applies a chosen mapping candidate to the run-owned draft (see
        # app.agent_runs.review_apply); without it a choice is only recorded.
        self.draft_writer = draft_writer

    def _policy(self, request):
        from app.agent_runs.policy import resolve_policy
        return resolve_policy(resolve_effort(request), self.settings)

    @staticmethod
    def _assert_owner(run: AgentRun, actor: AgentActor) -> None:
        if run.actor.tenant_id != actor.tenant_id or run.actor.user_id != actor.user_id or run.actor.effective_role != actor.effective_role:
            raise RunAuthorizationError("The migration run is outside the current user scope")

    def create_run(self, request: RunCreateRequest, actor: AgentActor) -> AgentRun:
        if actor.actor_type != "user":
            raise RunAuthorizationError("Only an authenticated user may start a migration run")
        if request.model_name:
            configured_models = {
                getattr(self.settings, f"migration_agent_model_{level}", "")
                for level in ("light", "medium", "high")
            }
            if request.model_name not in configured_models:
                raise ValueError("Selected model is not configured for this deployment")
        digest = request_hash(request, actor)
        if request.idempotency_key:
            existing = self.repository.find_run_by_idempotency(actor.user_id, request.idempotency_key)
            if existing:
                self._assert_owner(existing, actor)
                if existing.request_hash != digest:
                    raise RunConflictError("Idempotency key was reused with a different request")
                return existing
        run_id = f"run_{uuid4().hex}"
        run = AgentRun(
            run_id=run_id,
            actor=actor,
            request=request,
            request_hash=digest,
            policy=self._policy(request),
            project_id=request.project_id,
            checkpoint_thread_id=run_id,
        )
        run = self.repository.create_run(run)
        self.emit(
            run,
            "run.queued",
            "queued",
            "Migration Agent accepted the run for durable execution.",
            data={"requested_effort": request.effort.value, "resolved_effort": run.policy.effort.value},
        )
        self._wake_workers()
        return run

    def get_state(self, run_id: str, actor: AgentActor) -> RunStateResponse:
        run = self._require_run(run_id)
        self._assert_owner(run, actor)
        return self._state_for_run(run)

    def get_latest_state(self, actor: AgentActor) -> RunStateResponse:
        run = self.repository.get_latest_run(actor.user_id, actor.tenant_id)
        if run is None:
            raise RunNotFoundError("No migration run exists for the current user")
        self._assert_owner(run, actor)
        return self._state_for_run(run)

    def _state_for_run(self, run: AgentRun) -> RunStateResponse:
        from app.agent_runs.usage import restore_usage
        run = run.model_copy(deep=True)
        restore_usage(run, self.repository.latest_budget_usage(run.run_id))
        run_id = run.run_id
        dag = self.repository.list_dag_nodes(run_id)
        return RunStateResponse(
            run=run,
            steps=self.repository.list_steps(run_id),
            review_items=self._review_items_for_run(run_id, dag),
            mapping_dag=dag,
        )

    def _review_items_for_run(self, run_id: str, dag=None) -> list[AgentReviewItem]:
        """Expose the latest saved mapping candidates once per target column."""
        items = self.repository.list_review_items(run_id)
        dag = dag if dag is not None else self.repository.list_dag_nodes(run_id)
        compile_results = [
            ((node.partition_payload or {}).get("result") or {})
            for node in dag
            if node.mapping_key.endswith(":compile")
        ]
        latest: dict[tuple[str, str], tuple[str, list[dict], str, dict]] = {}
        for node in dag:
            if not node.mapping_key.endswith(":compile"):
                continue
            result = (node.partition_payload or {}).get("result") or {}
            for finding in result.get("review_items") or []:
                if finding.get("category") != "mapping_candidate_review":
                    continue
                details = finding.get("details") or {}
                target = str(details.get("target_column") or "").upper()
                if target:
                    sttm_id = str(result.get("sttm_id") or node.sttm_id or "")
                    latest[(sttm_id, target)] = (str(finding.get("safe_summary") or ""),
                                                list(details.get("candidates") or []), sttm_id, details)
        seen: set[tuple[str, str, str]] = set()
        output: list[AgentReviewItem] = []
        for item in reversed(items):
            if item.category == "mapping_candidate_review":
                target = str(item.subject_keys[0] if item.subject_keys else
                             (re.match(r"^[A-Za-z0-9_]+", item.safe_summary) or [""])[0]).upper()
                latest_key = (str(item.sttm_id or ""), target)
                if latest_key not in latest:
                    compatible = [
                        key for key, value in latest.items()
                        if key[1] == target and value[0] == item.safe_summary
                    ]
                    if not compatible and not item.sttm_id:
                        compatible = [key for key in latest if key[1] == target]
                    if len(compatible) == 1:
                        # Repair legacy rows written with no STTM, or with the
                        # first mapping's STTM, only when the current DAG and
                        # exact finding summary identify one owning mapping.
                        latest_key = compatible[0]
                key = (item.category, str(item.sttm_id or ""), target)
                if latest and latest_key not in latest:
                    continue
                if latest_key in latest:
                    summary, candidates, sttm_id, details = latest[latest_key]
                    mapping = next(
                        (result for result in compile_results if str(result.get("sttm_id") or "") == sttm_id),
                        {},
                    )
                    mapping_row = next(
                        (
                            row for row in mapping.get("mapping_rows") or []
                            if str(row.get("target_column") or "").upper() == target
                        ),
                        {},
                    )
                    confidence = mapping_row.get("confidence")
                    validated = (
                        dict(mapping.get("sql_validation") or {}).get("compile_valid") is True
                        and dict(mapping.get("sql_validation") or {}).get("preview_valid") is True
                    )
                    if (
                        str(mapping_row.get("status") or "").lower() == "draft"
                        and isinstance(confidence, (int, float))
                        and confidence >= float(getattr(self.settings, "migration_agent_column_review_confidence", 0.8) or 0.8)
                        and validated
                    ):
                        # This mapping was deterministically validated and is
                        # auto-approved in the review table, not a user action.
                        continue
                    choices = self._mapping_review_choices(candidates, details)
                    firm_value = details.get("firm_value_name")
                    if len(choices) == 1 and not firm_value:
                        summary = f"{target}: no current, executable candidate is verified; inspect the saved draft and supply a rule."
                    item = item.model_copy(update={
                        "safe_summary": summary,
                        "question": (f"Which value should firm value {firm_value} have for {target}?" if firm_value
                                     else f"Which mapping should be used for {target}?"),
                        "subject_keys": [target], "sttm_id": sttm_id or item.sttm_id,
                        "choices": choices,
                    })
            else:
                key = (item.category, str(item.sttm_id or ""), item.safe_summary)
            if key in seen:
                continue
            seen.add(key)
            output.append(item)
        return list(reversed(output))

    def _run_lineage(self, run: AgentRun) -> list[str]:
        """This run and its same-owner ancestors: the runs whose drafts it may change."""
        lineage = [run.run_id]
        parent_id = run.request.parent_run_id
        while parent_id and parent_id not in lineage and len(lineage) < 20:
            parent = self.repository.get_run(parent_id)
            if parent is None or (parent.actor.user_id, parent.actor.tenant_id) != (
                    run.actor.user_id, run.actor.tenant_id):
                break
            lineage.append(parent.run_id)
            parent_id = parent.request.parent_run_id
        return lineage

    def review_table(self, run_id: str, actor: AgentActor) -> dict[str, Any]:
        """The run's tiered, deduplicated review table (planning questions, confidence rows, blockers)."""
        from app.agent_runs.review_tiers import build_review_table

        run = self._require_run(run_id)
        self._assert_owner(run, actor)
        dag = self.repository.list_dag_nodes(run_id)
        persisted = {(item.category, str(item.subject_keys[0] if item.subject_keys else "").upper(), item.sttm_id): item
                     for item in self._review_items_for_run(run_id, dag)}
        results: list[dict[str, Any]] = []
        findings: list[dict[str, Any]] = []
        for node in dag:
            if not node.mapping_key.endswith(":compile"):
                continue
            result = dict((node.partition_payload or {}).get("result") or {})
            if not result:
                continue
            results.append(result)
            mapping_rows = {
                str(row.get("target_column") or "").upper(): row
                for row in result.get("mapping_rows") or []
            }
            for finding in result.get("review_items") or []:
                details = dict(finding.get("details") or {})
                target_column = str(details.get("target_column") or "").upper()
                mapping_row = mapping_rows.get(target_column, {})
                current_choice = (
                    str(mapping_row.get("expression") or "").strip()
                    or (f"${mapping_row['attribute_name']}" if mapping_row.get("attribute_name") else "")
                    or ", ".join(str(value) for value in mapping_row.get("source_columns") or [])
                    or None
                )
                details.update({
                    "confidence": details.get("confidence", mapping_row.get("confidence")),
                    "current_choice": details.get("current_choice") or current_choice,
                })
                key = (finding.get("category"), target_column, result.get("sttm_id"))
                item = persisted.pop(key, None)
                findings.append({
                    **finding, "details": details,
                    "mapping_key": result.get("mapping_key") or node.mapping_key.removesuffix(":compile"),
                    "mapping_name": result.get("mapping_name") or node.mapping_name,
                    "target_table": result.get("target_table") or node.target_table,
                    "sttm_id": result.get("sttm_id") or node.sttm_id,
                    "review_item_id": item.review_item_id if item else None,
                    "status": item.status.value if item else "OPEN",
                })
        # Run-level items (plan gates, source research) have no compile finding.
        findings.extend({"category": item.category, "safe_summary": item.safe_summary, "blocking": item.blocking,
                         "review_item_id": item.review_item_id, "status": item.status.value,
                         "details": {"target_column": item.subject_keys[0] if item.subject_keys else None}}
                        for item in persisted.values())
        threshold = float(getattr(self.settings, "migration_agent_column_review_confidence", 0.8) or 0.8)
        table = build_review_table(results, findings, has_plan=any(node.plan_hash for node in dag),
                                   accept_threshold=threshold, target_count=len(run.mapping_manifest or []))
        validated_auto = {row["row_id"] for row in table["rows"] if row.get("auto_approve_eligible")}
        accepted = {row_id for event in self.repository.list_events_by_type(run_id, {"review.rows_accepted"})
                    for row_id in (event.data or {}).get("row_ids") or []}
        for row in table["rows"]:
            if row["row_id"] in accepted and row["status"] in {"PROPOSED", "OPEN"}:
                row.update(status="ACCEPTED", accept_eligible=False)
            elif row["row_id"] in validated_auto and row["status"] == "PROPOSED":
                row.update(status="AUTO_APPROVED", accept_eligible=False)
        open_rows = [row for row in table["rows"] if row["status"] not in {
            "ANSWERED", "RESOLVED", "DISMISSED", "ACCEPTED", "AUTO_APPROVED"}]
        table["summary"].update(
            planning_questions=sum(1 for row in open_rows if row["tier"] == "planning_question"),
            blockers=sum(1 for row in open_rows if row["tier"] == "blocker"),
            decisions_to_confirm=sum(1 for row in open_rows if row["tier"] == "confidence" and row["kind"] != "check"),
            checks_failed=sum(1 for row in open_rows if row["kind"] == "check"),
            accept_eligible=sum(1 for row in open_rows if row["accept_eligible"]),
            actionable=sum(1 for row in open_rows if row["actionability"] in {"required", "confirmation"}),
            informational=sum(1 for row in open_rows if row["actionability"] == "informational"),
        )
        table["summary"]["auto_approved"] = len(validated_auto)
        table["summary"]["approval_threshold"] = threshold
        return {"run_id": run_id, "status": run.status.value, **table}

    def accept_review_rows(self, run_id: str, row_ids: list[str], actor: AgentActor, *,
                           row_digests: dict[str, str] | None = None,
                           expected_run_revision: int | None = None) -> dict[str, Any]:
        """Confirm proposed rows as they are. The draft already holds them; this records the review."""
        run = self._require_run(run_id)
        self._assert_owner(run, actor)
        if expected_run_revision is not None and int(run.run_revision or 0) != expected_run_revision:
            return {"accepted": [], "skipped": row_ids, "skip_reasons": {
                row_id: "run_revision_changed" for row_id in row_ids}}
        current = {row["row_id"]: row for row in self.review_table(run_id, actor)["rows"]}
        digests = row_digests or {}
        unique = list(dict.fromkeys(row_ids))
        eligible = [row_id for row_id in unique if (row := current.get(row_id))
                    and row.get("accept_eligible") is True
                    and (row_id not in digests or digests[row_id] == row.get("row_digest"))]
        skip_reasons = {
            row_id: (
                "not_found" if row_id not in current
                else "stale_row" if row_id in digests and digests[row_id] != current[row_id].get("row_digest")
                else "not_eligible"
            )
            for row_id in unique if row_id not in eligible
        }
        if eligible:
            self.emit(run, "review.rows_accepted", "succeeded",
                      f"Confirmed {len(eligible)} proposed mapping row(s) as they are.",
                      data={"row_ids": eligible, "accepted_by": actor.user_id,
                            "columns": [{"targets": current[row_id]["targets"], "column": current[row_id]["column"],
                                         "confidence": current[row_id]["confidence"]} for row_id in eligible]})
        return {"accepted": eligible, "skipped": [row_id for row_id in unique if row_id not in eligible],
                "skip_reasons": skip_reasons}

    @staticmethod
    def _mapping_review_choices(candidates: list[dict], details: dict | None = None) -> list[ReviewChoice]:
        choices = []
        for index, candidate in enumerate(candidates[:3]):
            if candidate.get("attribute_name") and candidate.get("constant_value") not in (None, ""):
                known = candidate.get("firm_value") or {}
                where = f" (used in {', '.join(known.get('projects') or [])[:120]})" if known.get("projects") else ""
                choices.append(ReviewChoice(
                    choice_id=f"candidate_{index + 1}",
                    label=f"Firm value {candidate['attribute_name']} = {candidate['constant_value']}{where}",
                    description=str(candidate.get("reason") or "Firm value candidate."),
                    evidence_ids=list(candidate.get("evidence_ids") or []),
                    recommended=index == 0 and not known,
                    selection_payload={"decision": "candidate", "candidate": candidate},
                ))
                continue
            if (not candidate.get("source_columns") and
                (str(candidate.get("constant_value") or "").startswith("$") or
                 str(candidate.get("transformation") or "").strip().lower() in {"", "value"})):
                continue
            label = ", ".join(candidate.get("source_columns") or []) or str(
                candidate.get("constant_value") or candidate.get("transformation") or "Candidate rule"
            )
            choices.append(ReviewChoice(
                choice_id=f"candidate_{index + 1}",
                label=label,
                description=str(candidate.get("reason") or "Evidence candidate; verify before applying."),
                evidence_ids=list(candidate.get("evidence_ids") or []),
                recommended=index == 0,
                confidence=(float(candidate["confidence"]) if candidate.get("confidence") is not None else None),
                selection_payload={"decision": "candidate", "candidate": candidate},
            ))
        firm_value = (details or {}).get("firm_value_name")
        choices.append(ReviewChoice(choice_id="keep_unresolved", label="Keep unresolved",
                                    description=("Leave the column unmapped for now, or type this firm's value "
                                                 "to create the firm value and map the column."
                                                 if firm_value else "Record that none of these candidates is suitable."),
                                    selection_payload={"decision": "unresolved", **({"firm_value": {
                                        "name": firm_value, "type": (details or {}).get("firm_value_type") or "VARCHAR",
                                    }} if firm_value else {})}))
        return choices

    def list_events(
        self, run_id: str, actor: AgentActor, *, after: int = 0, limit: int = 500
    ) -> list[AgentRunEvent]:
        run = self._require_run(run_id)
        self._assert_owner(run, actor)
        return self.repository.list_events(run_id, after=after, limit=limit)

    def answer(self, run_id: str, request: RunAnswerRequest, actor: AgentActor) -> AgentRun:
        run = self._require_run(run_id)
        previous = run.model_copy(deep=True)
        self._assert_owner(run, actor)
        item = self.repository.get_review_item(run_id, request.review_item_id)
        if item is None:
            raise RunNotFoundError(f"Review item {request.review_item_id} was not found")
        if run.status is RunStatus.NEEDS_REVIEW and item.category == "mapping_candidate_review":
            current = next((value for value in self._review_items_for_run(run_id)
                            if value.review_item_id == item.review_item_id), None)
            if current is None:
                raise RunConflictError("A newer mapping review question replaced this finding; refresh the run")
            if current.status is ReviewItemStatus.ANSWERED:
                if (request.choice_id and current.selected_choice_id == request.choice_id) or (
                    not request.choice_id and current.answer == request.answer
                ):
                    return run
                raise RunConflictError("This mapping decision was already recorded")
            selected = next((choice for choice in current.choices if choice.choice_id == request.choice_id), None)
            if request.choice_id and selected is None:
                raise RunConflictError("The selected option is not part of the current mapping review")
            if current.status is not ReviewItemStatus.OPEN:
                raise RunConflictError("The review item is no longer open")
            answer = (json.dumps({"choice_id": selected.choice_id, "answer": selected.label,
                                  **selected.selection_payload}, sort_keys=True) if selected
                      else str(request.answer or "").strip())
            current.status = ReviewItemStatus.ANSWERED
            current.answer = answer
            current.selected_choice_id = selected.choice_id if selected else None
            current.answered_by = actor.user_id
            current.answered_at = datetime.now(UTC)
            with self.repository.command_transaction():
                if not self.repository.answer_review_item(current):
                    raise RunConflictError("This mapping decision was already recorded; refresh the run")
            payload = dict(selected.selection_payload or {}) if selected else {}
            target = str(current.subject_keys[0] if current.subject_keys else "")
            typed = str(request.answer or "").strip()
            asked = next((dict(choice.selection_payload.get("firm_value") or {}) for choice in current.choices
                          if (choice.selection_payload or {}).get("firm_value")), None)
            if not selected and typed and asked and asked.get("name"):
                # A typed answer to a firm-value question is this firm's value.
                payload = {"decision": "candidate", "candidate": {
                    "attribute_name": asked["name"], "constant_value": typed,
                    "firm_value": {"name": asked["name"], "type": asked.get("type") or "VARCHAR", "value": typed},
                    "confidence": 1.0, "reason": "Value entered in review",
                }}
            if (self.draft_writer is not None and payload.get("decision") == "candidate"
                    and current.sttm_id and target):
                try:
                    applied = self.draft_writer(run=run, sttm_id=str(current.sttm_id), target_column=target,
                                                candidate=dict(payload.get("candidate") or {}), actor=actor,
                                                lineage=self._run_lineage(run))
                except Exception as exc:  # noqa: BLE001 - the decision stays recorded; the user can apply it by hand
                    self.emit(run, "run.review_decision.recorded", "answered",
                              f"Mapping review choice recorded, but it could not be applied to the draft "
                              f"({type(exc).__name__}). Apply it in the mapping page.",
                              sttm_id=current.sttm_id, subject_keys=current.subject_keys,
                              data={"review_item_id": current.review_item_id, "choice_id": current.selected_choice_id,
                                    "applied": False})
                    return run
                self.emit(run, "run.review_decision.recorded", "answered",
                          f"Applied the chosen rule for {target} to the draft. The mapping page recompiles it when "
                          "you open the draft; validate the SQL there.",
                          sttm_id=current.sttm_id, subject_keys=current.subject_keys,
                          data={"review_item_id": current.review_item_id, "choice_id": current.selected_choice_id,
                                "applied": True, **dict(applied or {})})
                return run
            self.emit(run, "run.review_decision.recorded", "answered",
                      "Mapping review choice recorded. Apply the selected rule in the saved draft before validation.",
                      sttm_id=current.sttm_id, subject_keys=current.subject_keys,
                      data={"review_item_id": current.review_item_id,
                            "choice_id": current.selected_choice_id})
            return run
        if item.interrupt_id and request.interrupt_id != item.interrupt_id:
            raise RunConflictError("The answer belongs to a stale workflow interrupt")
        if item.action_digest and request.action_digest != item.action_digest:
            raise RunConflictError(
                "The approval must reference the exact current action digest; review the current action before continuing"
            )
        if item.action_digest and item.artifact_revision and request.artifact_revision != item.artifact_revision:
            raise RunConflictError("The approval must reference the exact current artifact revision")
        if item.status is ReviewItemStatus.ANSWERED:
            if request.choice_id and item.selected_choice_id == request.choice_id:
                return run
            if not request.choice_id and item.answer == request.answer:
                return run
        if item.status is not ReviewItemStatus.OPEN:
            raise RunConflictError("The review item is no longer awaiting an answer")
        if run.cancel_requested_at or run.status not in {RunStatus.AWAITING_INPUT, RunStatus.AWAITING_CONFIRMATION}:
            raise RunConflictError("The run is no longer awaiting this decision")
        selected = None
        if request.choice_id:
            selected = next(
                (choice for choice in item.choices if choice.choice_id == request.choice_id),
                None,
            )
            if selected is None:
                raise RunConflictError("The selected option is not part of the current workflow interrupt")
        if not item.allow_free_text and not selected:
            raise RunConflictError("This workflow interrupt requires one of its stored options")
        resolved_answer = (
            json.dumps(
                {
                    "choice_id": selected.choice_id,
                    "answer": selected.label,
                    **selected.selection_payload,
                },
                sort_keys=True,
            )
            if selected
            else str(request.answer or "").strip()
        )
        if item.category == "authentication_required":
            if (not actor.delegation_ref or not actor.snowflake_username
                    or actor.snowflake_username.casefold() != str(run.actor.snowflake_username or "").casefold()):
                raise RunAuthorizationError("Sign in again as the initiating user before resuming this run")
            # Only an authenticated API actor may rebind the same user's session.
            run.actor = run.actor.model_copy(update={"delegation_ref": actor.delegation_ref})
            run.error_code = None
            run.safe_error = None
        item.status = ReviewItemStatus.ANSWERED
        item.answer = resolved_answer
        item.selected_choice_id = selected.choice_id if selected else None
        item.answered_by = actor.user_id
        item.answered_at = datetime.now(UTC)
        if item.category in {"plan_approval", "source_research_choice", "source_join_path"}:
            # Every answered research checkpoint begins another bounded phase.
            # Keep cumulative usage for audit while granting each answered
            # checkpoint its own bounded execution phase. Reconstructing the
            # plan on resume consumes model, tool and database calls too.
            run.budget_grants.append({
                "reason": "approved_execution_phase" if item.category == "plan_approval" else "answered_research_checkpoint",
                "idempotency_key": request.idempotency_key,
                "authorized_by": actor.user_id,
                "created_at": item.answered_at.isoformat(),
                "elapsed_offset": run.elapsed_seconds_used,
                "model_offset": run.model_calls_used,
                "tool_offset": run.tool_calls_used,
                "category_offsets": dict(run.category_usage),
            })
        with self.repository.command_transaction():
            if not self.repository.answer_review_item(item):
                raise RunConflictError("This decision was already answered or cancelled; refresh the run")
            run.status = RunStatus.QUEUED
            run.current_step_id = item.step_id
            run = self.repository.save_run_if_current(run, previous)
        self.emit(
            run,
            "run.question.answered",
            "answered",
            "User input recorded; the durable run is ready to resume.",
            step_id=item.step_id,
            sttm_id=item.sttm_id,
            subject_keys=item.subject_keys,
            data={
                "review_item_id": item.review_item_id,
                "choice_id": item.selected_choice_id,
            },
        )
        self._wake_workers()
        return run

    def _wake_workers(self) -> None:
        """A queued run is claimable now; spare idle slots their poll delay."""
        if self.settings is None:
            return
        from app.agent_runs.wake import notify_workers

        notify_workers(self.settings)

    def cancel(self, run_id: str, request: RunCancelRequest, actor: AgentActor) -> AgentRun:
        run = self._require_run(run_id)
        previous = run.model_copy(deep=True)
        self._assert_owner(run, actor)
        if run.status in TERMINAL_RUN_STATUSES:
            return run
        # Cancellation is idempotent. Repeated UI clicks/retries must not add
        # duplicate activity events or mutate the original cancellation reason.
        if run.cancel_requested_at is not None:
            return run
        run.cancel_requested_at = datetime.now(UTC)
        run.cancel_reason = request.reason
        # No worker owns a never-started queued run, so there is no safe
        # boundary to wait for. Cancel it synchronously and make Stop terminal.
        if run.status in {RunStatus.AWAITING_INPUT, RunStatus.AWAITING_CONFIRMATION} or (
            run.status is RunStatus.QUEUED and run.started_at is None and not run.lease_owner
        ):
            run.status = RunStatus.CANCELLED
            run.completed_at = run.cancel_requested_at
            run = self.repository.save_run_if_current(run, previous)
            self.emit(run, "run.cancelled", "cancelled", "Migration run cancelled at its current checkpoint.")
            return run
        run = self.repository.save_run_if_current(run, previous)
        self.emit(
            run,
            "run.cancel.requested",
            "pending",
            "Cancellation requested. The worker will stop at the next safe boundary.",
        )
        return run

    def resume(self, run_id: str, request: RunResumeRequest, actor: AgentActor) -> AgentRun:
        """Resume the same checkpoint under a recorded, bounded user authorization."""
        run = self._require_run(run_id)
        previous = run.model_copy(deep=True)
        self._assert_owner(run, actor)
        if run.last_resume_idempotency_key == request.idempotency_key:
            return run
        if run.run_revision != request.expected_revision:
            raise RunConflictError("The run changed; refresh before resuming it")
        if run.status is RunStatus.QUEUED:
            return run
        if run.status not in {RunStatus.FAILED, RunStatus.NEEDS_REVIEW, RunStatus.AWAITING_INPUT, RunStatus.AWAITING_CONFIRMATION}:
            raise RunConflictError(f"Run status {run.status.value} is not resumable")
        if run.status is RunStatus.NEEDS_REVIEW and run.project_id:
            from app.agent_runs.policy import resolve_policy
            run.policy.max_resume_attempts = max(
                run.policy.max_resume_attempts,
                resolve_policy(run.policy.effort, self.settings).max_resume_attempts,
            )
        from app.agent_runs.recovery import PERMANENT_FAILURES, can_resume
        if str(run.error_code or "").casefold() in PERMANENT_FAILURES or (
            run.status is RunStatus.FAILED and run.resume_attempt < run.policy.max_resume_attempts and not can_resume(run)
        ):
            raise RunConflictError("This failure requires corrected configuration, authorization or scope before recovery")
        if run.resume_attempt >= run.policy.max_resume_attempts:
            raise RunConflictError("The configured resume allowance was exhausted; review the run policy")
        if run.status in {RunStatus.AWAITING_INPUT, RunStatus.AWAITING_CONFIRMATION}:
            raise RunConflictError("Answer the existing checkpoint; resume cannot bypass a pending decision")
        if run.error_code == "budget_exhausted" or (run.status is RunStatus.NEEDS_REVIEW and run.project_id):
            from app.agent_runs.policy import resolve_policy
            current_window = resolve_policy(run.policy.effort, self.settings).elapsed_seconds
            extension = max(0, current_window - run.policy.elapsed_seconds)
            run.budget_grants.append({
                "idempotency_key":request.idempotency_key,"authorized_by":actor.user_id,
                "created_at":datetime.now(UTC).isoformat(),"policy":run.policy.model_dump(mode="json"),
                "reason": "retry_incomplete_draft" if run.status is RunStatus.NEEDS_REVIEW else "budget_exhausted_resume",
                "model_offset":run.model_calls_used,"tool_offset":run.tool_calls_used,
                "category_offsets":dict(run.category_usage),"elapsed_offset":run.elapsed_seconds_used + extension,
            })
        if actor.delegation_ref:
            if str(actor.snowflake_username or "").casefold() != str(run.actor.snowflake_username or "").casefold():
                raise RunAuthorizationError("The authenticated Snowflake user does not own this run")
            run.actor = run.actor.model_copy(update={"delegation_ref": actor.delegation_ref})
        run.resume_attempt += 1
        run.run_revision += 1
        run.last_resume_idempotency_key = request.idempotency_key
        run.status = RunStatus.QUEUED
        run.completed_at = None
        run.error_code = None
        run.safe_error = None
        run.lease_owner = None
        run.lease_expires_at = None
        run = self.repository.save_run_if_current(run, previous)
        self.emit(
            run,
            "run.resumed",
            "queued",
            "Resuming the same durable run from its latest checkpoint.",
            data={
                "resume_attempt": run.resume_attempt,
                "run_revision": run.run_revision,
                "same_run_id": run.run_id,
                "checkpoint_thread_id": run.checkpoint_thread_id or run.run_id,
                "checkpoint_id": run.checkpoint_id,
            },
        )
        self._wake_workers()
        return run

    def emit(
        self,
        run: AgentRun,
        event_type: str,
        status: str,
        safe_summary: str,
        *,
        step_id: str | None = None,
        sttm_id: str | None = None,
        subject_keys: list[str] | None = None,
        artifact_refs: list[str] | None = None,
        data: dict | None = None,
        parent_event_id: str | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
    ) -> AgentRunEvent:
        return self.repository.append_event(
            self.build_event(
                run,
                event_type,
                status,
                safe_summary,
                step_id=step_id,
                sttm_id=sttm_id,
                subject_keys=subject_keys,
                artifact_refs=artifact_refs,
                data=data,
                parent_event_id=parent_event_id,
                trace_id=trace_id,
                span_id=span_id,
            )
        )

    @staticmethod
    def build_event(
        run: AgentRun,
        event_type: str,
        status: str,
        safe_summary: str,
        *,
        step_id: str | None = None,
        sttm_id: str | None = None,
        subject_keys: list[str] | None = None,
        artifact_refs: list[str] | None = None,
        data: dict | None = None,
        parent_event_id: str | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
    ) -> AgentRunEvent:
        # Trace ids are built from run ids, table FQNs and column names and can
        # exceed the event table's column sizes. Shorten them deterministically,
        # identically for the column and for the ids in the event data, so the
        # trace tree still links and one long name cannot fail the whole run.
        data = dict(data or {})
        for key, limit in (("trace_id", 128), ("parent_trace_id", 128), ("span_id", 128)):
            if isinstance(data.get(key), str):
                data[key] = _bounded_id(data[key], limit)
        return AgentRunEvent(
            event_id=f"evt_{uuid4().hex}",
            run_id=run.run_id,
            conversation_id=run.request.conversation_id,
            turn_id=run.request.turn_id,
            intent=run.request.intent,
            execution_path=(
                "resume" if run.resume_attempt else "new_run"
            ),
            plan_id=(
                str(data.get("plan_id") or data.get("trace_id") or f"plan:{run.run_id}")
                if event_type.startswith("plan.") else None
            ),
            resume_attempt=run.resume_attempt,
            event_type=event_type,
            status=status,
            safe_summary=safe_summary,
            project_id=run.project_id,
            sttm_id=sttm_id or run.current_sttm_id,
            step_id=step_id or run.current_step_id,
            parent_event_id=_bounded_id(parent_event_id, 64) if parent_event_id else parent_event_id,
            trace_id=_bounded_id(trace_id, 128) if trace_id else trace_id,
            span_id=_bounded_id(span_id, 128) if span_id else span_id,
            subject_keys=subject_keys or [],
            artifact_refs=artifact_refs or [],
            data={
                **data,
                "conversation_id": run.request.conversation_id,
                "turn_id": run.request.turn_id,
                "intent": run.request.intent.value,
                "execution_path": "resume" if run.resume_attempt else "new_run",
                "resume_attempt": run.resume_attempt,
            },
        )

    def create_question(
        self,
        run: AgentRun,
        *,
        category: str,
        question: str,
        safe_summary: str,
        step_id: str | None = None,
        sttm_id: str | None = None,
        subject_keys: list[str] | None = None,
        choices: list[str | dict] | None = None,
        evidence_ids: list[str] | None = None,
        proposed_action_hash: str | None = None,
        interrupt_id: str | None = None,
        action_digest: str | None = None,
        artifact_revision: str | None = None,
        recommended_choice_id: str | None = None,
        allow_free_text: bool = True,
        confirmation: bool = False,
        event_data: dict | None = None,
        worker_owned: bool = False,
    ) -> AgentReviewItem:
        item = AgentReviewItem(
            review_item_id=f"review_{uuid4().hex}",
            run_id=run.run_id,
            step_id=step_id,
            project_id=run.project_id,
            sttm_id=sttm_id,
            subject_keys=subject_keys or [],
            blocking=True,
            category=category,
            question=question,
            choices=[ReviewChoice.model_validate(choice) if isinstance(choice, dict) else ReviewChoice(choice_id=f"choice_{index + 1}", label=str(choice)) for index, choice in enumerate(choices or [])],
            recommended_choice_id=recommended_choice_id,
            allow_free_text=allow_free_text,
            interrupt_id=interrupt_id,
            action_digest=action_digest or proposed_action_hash,
            artifact_revision=artifact_revision,
            safe_summary=safe_summary,
            evidence_ids=evidence_ids or [],
            proposed_action_hash=proposed_action_hash,
        )
        run.status = RunStatus.AWAITING_CONFIRMATION if confirmation else RunStatus.AWAITING_INPUT
        run.current_step_id = step_id
        with self.repository.command_transaction():
            if worker_owned:
                self.repository.save_run_owned(run)
            else:
                self.repository.save_run(run)
            self.repository.save_review_item(item)
        self.emit(
            run,
            "plan.approval_required" if confirmation else "run.question.required",
            "awaiting_confirmation" if confirmation else "awaiting_input",
            safe_summary,
            step_id=step_id,
            sttm_id=sttm_id,
            subject_keys=subject_keys,
            data={
                "review_item_id": item.review_item_id,
                "question": question,
                "category": item.category,
                "choices": [choice.model_dump(mode="json") for choice in item.choices],
                "recommended_choice_id": item.recommended_choice_id,
                "allow_free_text": item.allow_free_text,
                "interrupt_id": item.interrupt_id,
                "action_digest": item.action_digest,
                "artifact_revision": item.artifact_revision,
                **(event_data or {}),
            },
        )
        return item

    def _require_run(self, run_id: str) -> AgentRun:
        run = self.repository.get_run(run_id)
        if run is None:
            raise RunNotFoundError(f"Migration run {run_id} was not found")
        return run
