const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname,'../src');
const text = file => fs.readFileSync(path.join(root,file),'utf8');
const targets = {
  'components/sql/sql-preview/mapping-sql-preview.tsx':['sttmEditSql','sttmCompileValidate','sttmOptimizeSql','sttmRunPreview'],
  'features/sttm/mapping/source-target-attribute-mapping.tsx':['sttmSourceColumn','sttmTransformRuleColumn'],
  'features/sttm/mapping/mapping-confidence-group-header.tsx':['sttmConfidenceGroups'],
  'features/sttm/source-target/filter-conditions.tsx':['sttmQueryPreview'],
};
for(const [file,names] of Object.entries(targets)) for(const name of names) {
  const source = text(file);
  const literal = `data-tour={TOUR_TARGETS.${name}}`;
  const configurable = name === "sttmQueryPreview" && source.includes(`data-tour={previewTourTarget ?? TOUR_TARGETS.${name}}`);
  assert.ok(source.includes(literal) || configurable,`${file}: ${name}`);
  assert.ok(text('features/tour/constants/tour-targets.ts').includes(`${name}:`));
}
const sidebar=text('features/sttm/source-target/source-target-db-selection.tsx');
assert.equal((sidebar.match(/\.\.\.STICKY_SEARCH_SX/g)||[]).length,2);
assert.ok(sidebar.includes('titleSx={sttmSelectTablesTitleSx}'));
assert.ok(text('features/sttm/source-target/table-relationship-flow.tsx').includes('sourceApplySequence'));
assert.ok(text('features/sttm/source-target/add-derived-modal.tsx').includes('bindScopeRelations'));
const joinModal = text('features/sttm/source-target/join-modal.tsx');
assert.equal((joinModal.match(/disabled=\{predicateMode\}/g)||[]).length,2);
assert.ok(joinModal.includes("{predicateMode ? 'Use column conditions' : 'Edit complete ON predicate'}"));
console.log('New tour targets, sticky searches and retained scoped SQL safeguards passed.');