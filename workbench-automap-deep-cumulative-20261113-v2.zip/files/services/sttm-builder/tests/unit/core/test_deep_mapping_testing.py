import sqlite3

import pytest
import sqlglot

from app.migration_workflow.testing import audit_test_artifacts, contract_test_queries, evaluate_test_rows


def test_generated_assertions_detect_null_and_duplicate_keys():
    # Execute the generated assertion semantics on a generic dataset, not a mocked count.
    sql = 'SELECT 1 AS ID UNION ALL SELECT 1 AS ID UNION ALL SELECT NULL AS ID'
    tests = contract_test_queries(sql, [{'name': 'ID', 'nullable': False}], ['ID'])
    connection = sqlite3.connect(':memory:')
    connection.row_factory = sqlite3.Row
    try:
        results = []
        for test in tests:
            sqlite_sql = sqlglot.transpile(test['sql'], read='snowflake', write='sqlite')[0]
            rows = [dict(row) for row in connection.execute(sqlite_sql)]
            results.append(evaluate_test_rows(rows))
        assert [result['violations'] for result in results] == [1, 1]
        assert all(result['status'] == 'failed' for result in results)
        assert all(result['checked_rows'] == 3 for result in results)
    finally:
        connection.close()


def test_empty_data_is_inconclusive_and_nullability_is_not_invented():
    assert evaluate_test_rows([{'CHECKED_ROWS': 0, 'VIOLATIONS': 0}])['status'] == 'inconclusive'
    assert contract_test_queries('SELECT 1 AS ID', [{'name': 'ID'}], []) == []
    with pytest.raises(ValueError, match='outside'):
        contract_test_queries('SELECT 1 AS ID', [{'name': 'ID'}], ['UNKNOWN'])


def test_contract_assertions_keep_trailing_sql_comment_outside_wrapper():
    tests = contract_test_queries(
        'SELECT 1 AS ID -- source note', [{'name': 'ID', 'nullable': False}], [],
    )
    assert '\n) AS MAPPING_TEST' in tests[0]['sql']
    assert sqlglot.parse_one(tests[0]['sql'], read='snowflake') is not None


def test_high_effort_validation_records_unavailable_contract_test_coverage():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_runs.models import EFFORT_POLICIES, EffortLevel, ToolResult

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._emit = lambda *args, **kwargs: None
    handler._record_validation_report = lambda *args, **kwargs: None
    handler._learning = None
    handler._budget = None
    handler.run_mapping_contract_tests = lambda *args, **kwargs: ToolResult(
        status='needs_input', summary='No authoritative key or not-null contract is available.',
        data={'test_receipts': [], 'all_passed': False},
    )
    result = handler.cross_validate({
        'run_id': 'run-generic', 'project_id': 'project-generic',
        'effort_policy': EFFORT_POLICIES[EffortLevel.HIGH].model_dump(mode='json'),
        'manifest': [{'mapping_key': 'household', 'mapping_name': 'Household',
                      'target_table': 'DB.TGT.HOUSEHOLD', 'sttm_id': 'draft-generic'}],
        'mapping_results': [{'mapping_key': 'household', 'sttm_id': 'draft-generic',
                             'sql_validation': {'preview_valid': True}}],
    })
    assert result['validation_report']['gates']['mapping_tests']['passed'] is False
    assert any(item['category'] == 'mapping_tests' and item['blocking']
               for item in result['review_items'])


def test_cross_validation_keeps_same_named_columns_scoped_to_their_mapping():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.agent_runs.models import EFFORT_POLICIES, EffortLevel

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._emit = lambda *args, **kwargs: None
    handler._record_validation_report = lambda *args, **kwargs: None
    handler._learning = None
    handler._budget = None
    mapping_results = [
        {
            'mapping_key': key,
            'mapping_name': name,
            'target_table': f'DB.TGT.{name}',
            'sttm_id': sttm_id,
            'review_items': [{
                'category': 'mapping_candidate_review',
                'blocking': True,
                'safe_summary': f'{name}.OWNERID needs review.',
                'details': {'target_column': 'OWNERID', 'candidates': []},
            }],
        }
        for key, name, sttm_id in (
            ('calls', 'CALLS', 'sttm-calls'),
            ('tasks', 'TASKS', 'sttm-tasks'),
        )
    ]

    result = handler.cross_validate({
        'run_id': 'run-scoped-review',
        'project_id': 'project-scoped-review',
        'effort_policy': EFFORT_POLICIES[EffortLevel.LIGHT].model_dump(mode='json'),
        'manifest': [],
        'mapping_results': mapping_results,
    })

    reviews = [
        item for item in result['review_items']
        if item['category'] == 'mapping_candidate_review'
    ]
    assert {
        (item['mapping_key'], item['target_table'], item['sttm_id'])
        for item in reviews
    } == {
        ('calls', 'DB.TGT.CALLS', 'sttm-calls'),
        ('tasks', 'DB.TGT.TASKS', 'sttm-tasks'),
    }


def test_generated_case_coverage_does_not_claim_execution_or_business_correctness():
    data = {'status': 'completed', 'test_case_document': [{'test_case_id': 'one', 'target_attribute': 'ID'}]}
    audit = audit_test_artifacts(data, ['ID'])
    assert audit['passed']
    assert audit['execution_status'] == 'not_run'
    assert audit['business_correctness_verified'] is False
    assert audit_test_artifacts(data, ['ID', 'NAME'])['uncovered_targets'] == ['NAME']


@pytest.mark.parametrize('path', ['../secret', '/tmp/test.sql', 'C:\\tmp\\test.sql', 'a/../../test.sql'])
def test_specialist_artifact_paths_cannot_escape_artifact_namespace(path):
    data = {'status': 'completed', 'test_case_document': [{'test_case_id': 'one', 'target_attribute': 'ID'}],
            'seed_files': [{'file_path': path}]}
    assert 'unsafe_artifact_path' in audit_test_artifacts(data, ['ID'])['issues']


def test_duplicate_case_ids_and_unknown_targets_require_review():
    data = {'status': 'completed', 'test_case_document': [
        {'test_case_id': 'one', 'target_attribute': 'ID'}, {'test_case_id': 'one', 'target_attribute': 'UNKNOWN'}]}
    assert set(audit_test_artifacts(data, ['ID'])['issues']) == {
        'missing_or_duplicate_test_identity', 'unassigned_target_attribute'}


@pytest.mark.parametrize('fault', ['changed_sql', 'changed_revision', 'wrong_run'])
def test_contract_test_runner_rejects_stale_or_foreign_drafts_before_sql(fault):
    from threading import RLock
    from types import SimpleNamespace
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    from app.core.sql_execution_guard import sql_hash
    handler = object.__new__(WorkbenchWorkflowHandlers)
    sql = 'SELECT ID FROM DB.SRC.ENTITY'
    mapping = {'mapping_key': 'entity', 'sttm_id': 'draft',
               'sql_validation': {'compiled_mapping_preview_sql': sql, 'preview_valid': True,
                                  'validated_preview_sql_hash': sql_hash(sql)},
               'mutation_receipt': {'new_revision': 1}}
    record = SimpleNamespace(current_version=1, metadata={'migration_run_id': 'run'})
    if fault == 'changed_sql':
        mapping['sql_validation']['compiled_mapping_preview_sql'] += ' WHERE ID > 0'
    elif fault == 'changed_revision':
        record.current_version = 2
    else:
        record.metadata['migration_run_id'] = 'another-run'
    handler._completed_mapping_state = lambda *args: ({}, mapping, None)
    handler._projects = SimpleNamespace(get_sttm_record=lambda *args: record)
    handler._domain_lock = RLock()
    handler._tool = lambda *args: None
    handler.execute_read_only_sql = lambda *args, **kwargs: pytest.fail('Executed stale SQL')
    result = handler.run_mapping_contract_tests({'run_id': 'run'}, 'entity')
    assert result.status == 'conflict'
