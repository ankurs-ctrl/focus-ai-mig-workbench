"""Publish structural draft contracts only from completed domain output.

These are mapping definitions, not loaded target identifiers or approval of a
business rule. Load-time dependencies cannot be satisfied by a draft receipt.
"""
from __future__ import annotations
from app.migration_workflow.scheduler import ArtifactContract, Dependency
from app.core.sql_execution_guard import sql_hash


def emit_artifact_contracts(*, mapping_key, project_id, revision, stage, result, dependencies):
    rows={str(row['target_column']):row for row in result.get('mapping_rows', [])}
    emitted={}
    for value in dependencies:
        edge=Dependency.model_validate(value)
        if edge.producer_mapping != mapping_key or edge.availability != 'draft':
            continue
        if edge.producer_revision != revision or edge.required_producer_stage != stage:
            continue
        if edge.producer_project and edge.producer_project != project_id:
            continue
        columns=edge.producer_columns
        # An explicit producer contract is required; never infer a crosswalk from a name.
        if not columns or any(column not in rows for column in columns):
            continue
        selected=[rows[column] for column in columns]
        if any(row.get('status') != 'draft' or row.get('missing_dependencies') or row.get('assumptions')
               for row in selected):
            continue
        evidence=sorted({str(e) for row in selected for e in row.get('evidence_ids', []) if e})
        if not evidence:
            continue
        validation=result.get('sql_validation') or {}
        if stage in {'compiled','validated'}:
            if not validation.get('compile_valid') or not validation.get('compiled_mapping_sql'):
                continue
            if stage == 'validated' and not validation.get('preview_valid'):
                continue
        payload={'kind':'draft_mapping_definition','columns':columns,'mapping_rows':selected,
                 'business_approval_verified':False,'target_values_available':False}
        if stage in {'compiled','validated'}:
            payload['sql_hash']=sql_hash(validation['compiled_mapping_sql'])
        contract=ArtifactContract(artifact_id=edge.producer_output,producer_mapping=mapping_key,
            producer_project=project_id,revision=revision,stage=stage,evidence_ids=evidence,
            verified=True,payload=payload)
        if contract.artifact_id in emitted and emitted[contract.artifact_id] != contract:
            raise ValueError('Conflicting output declarations')
        emitted[contract.artifact_id]=contract
    return [value.model_dump(mode='json') for value in emitted.values()]
