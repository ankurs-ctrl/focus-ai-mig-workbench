from app.agent_runs.value_bindings import normalize_typed_project_value, prompt_project_value, valid_typed_project_value


def test_historical_expression_is_not_offered_as_typed_date_value() -> None:
    assert not valid_typed_project_value("TO_CHAR(CURRENT_DATE, 'yyyy-mm-DD')", "DATE")
    assert valid_typed_project_value("2026-09-26", "DATE")
    assert not valid_typed_project_value("$ParentOfficeID", "VARCHAR")
    assert valid_typed_project_value("1101", "NUMBER(38,0)")
    assert not valid_typed_project_value("one thousand", "NUMBER(38,0)")


def test_prompt_values_bind_only_when_field_and_type_are_explicit() -> None:
    assert prompt_project_value("MASTER_PAYOUT_DATE__C: 2026-07-21", "constant_MASTER_PAYOUT_DATE__C", ["MASTER_PAYOUT_DATE__C"], "DATE") == "2026-07-21"
    assert prompt_project_value("Use 2026-07-21 for MASTER_PAYOUT_DATE__C", "constant_MASTER_PAYOUT_DATE__C", ["MASTER_PAYOUT_DATE__C"], "DATE") == "2026-07-21"
    assert prompt_project_value("2026-07-21", "constant_MASTER_PAYOUT_DATE__C", ["MASTER_PAYOUT_DATE__C"], "DATE") is None
    assert prompt_project_value("MASTER_PAYOUT_DATE__C: tomorrow", "constant_MASTER_PAYOUT_DATE__C", ["MASTER_PAYOUT_DATE__C"], "DATE") is None
    assert prompt_project_value("MASTER_PAYOUT_DATE__C: 2026-07-21\nMASTER_PAYOUT_DATE__C: 2026-08-21", "constant_MASTER_PAYOUT_DATE__C", ["MASTER_PAYOUT_DATE__C"], "DATE") is None
    assert prompt_project_value("ACTIVE: No", "constant_ACTIVE", ["ACTIVE"], "BOOLEAN") == "FALSE"
    assert normalize_typed_project_value("Yes", "BOOL") == "TRUE"


def test_a_firm_value_stated_in_a_sentence_is_read_for_its_own_name_only() -> None:
    prompt = ("Map HOUSEHOLD from SCH_TMD_SOURCE. The firm value ClientStartDate for this firm is 2024-01-01. "
              "The TYPE is important.")
    assert prompt_project_value(prompt, "ClientStartDate", ["BFFS_CLIENTSTARTDATE__C"], "VARCHAR") == "2024-01-01"
    assert prompt_project_value("TransactionFirmID is 'a0B5g00000XyZ'.", "TransactionFirmID", ["X"], "VARCHAR") == "a0B5g00000XyZ"
    # A target column named in a sentence is not a value statement.
    assert prompt_project_value(prompt, "RecordKind", ["TYPE"], "VARCHAR") is None
    assert prompt_project_value("MyClientStartDate is 5", "ClientStartDate", [], "VARCHAR") is None
