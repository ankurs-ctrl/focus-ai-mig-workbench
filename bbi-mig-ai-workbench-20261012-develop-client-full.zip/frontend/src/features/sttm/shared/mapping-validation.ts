import type { DatabaseNode, DerivedSource, JoinConfig, MappingState, TableNode } from "@/features/sttm/types/sttm.types";
import {
  resolveSelectedSourceTables,
  resolveSelectedTargetTable,
} from "@/features/sttm/shared/sttm-selection-utils";

/** Entry kind written to the snapshot's `validation_history`. */
export const MAPPING_SQL_VALIDATION_KIND = "mapping_sql_validation";

/** One-shot sessionStorage hint: which tab the mapping page should open on. */
export const OPEN_MAPPING_TAB_STORAGE_KEY = "sttm:open-mapping-tab";

type ValidationSignatureInput = {
  sourceDatabases: DatabaseNode[];
  sources: TableNode[];
  targetDatabases: DatabaseNode[];
  targets: TableNode[];
  drivingTableId: string | null;
  derivedSources: DerivedSource[];
  relationships: JoinConfig[];
  mappings: MappingState[];
  sourceFilterSql: string;
  sourceGroupBySql: string;
  sourceOrderBySql: string;
};

/** FNV-1a: short, stable digest so the persisted marker stays small. */
function digest(value: string): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return `${hash.toString(36)}-${value.length.toString(36)}`;
}

/**
 * Fingerprint of everything that changes the generated SQL: Select Tables (sources,
 * CTEs, target, driving table, joins, filters) and Map · Transform · Validate (mapped
 * rows). A successful Compile & Validate stores it; any edit afterwards changes it,
 * which means the SQL must be validated again before publishing.
 *
 * It deliberately excludes the snapshot id so a validation survives page reloads.
 */
export function computeMappingValidationSignature(state: ValidationSignatureInput): string {
  const sources = resolveSelectedSourceTables(state)
    .map((table) => table.qualifiedName.toUpperCase())
    .sort();
  const target = resolveSelectedTargetTable(state)?.qualifiedName.toUpperCase() ?? null;
  const derived = state.derivedSources
    .filter((source) => source.isSelected)
    .map((source) => ({ id: source.id, sql: source.sqlText ?? "" }))
    .sort((left, right) => left.id.localeCompare(right.id));
  const mappings = state.mappings
    .filter((mapping) => mapping.status === "MAPPED")
    .map((mapping) => ({
      targetColumn: mapping.targetColumn,
      targetType: mapping.targetType,
      sourceColumn: mapping.sourceColumn,
      sourceColumns: mapping.sourceColumns,
      mappingMode: mapping.mappingMode,
      constantValue: mapping.constantValue,
      expression: mapping.expression,
      rule: mapping.rule,
      sourceDependencies: mapping.sourceDependencies,
      valueBindingIds: mapping.valueBindingIds,
    }));
  return digest(
    JSON.stringify({
      sources,
      target,
      drivingTableId: state.drivingTableId,
      derived,
      relationships: state.relationships,
      mappings,
      filter: state.sourceFilterSql ?? "",
      groupBy: state.sourceGroupBySql ?? "",
      orderBy: state.sourceOrderBySql ?? "",
    }),
  );
}

export function readValidatedSignature(
  validationHistory: unknown,
): string | null {
  if (!Array.isArray(validationHistory)) return null;
  for (let index = validationHistory.length - 1; index >= 0; index -= 1) {
    const entry = validationHistory[index] as Record<string, unknown> | null;
    if (entry && entry.kind === MAPPING_SQL_VALIDATION_KIND && typeof entry.signature === "string") {
      return entry.signature;
    }
  }
  return null;
}
