# Missing semantic YAML: native results

Actual Cortex builder, source-mapping and transformation-rule submissions and Snowflake SQL execution in isolated test-account fixtures. No installed YAML was removed: controlled registry records were passed through the production resolver so absence was deterministic. Actual current workspace bindings, a persisted validated FIR recipe and approved Firm Values were supplied. Test setup/provisioning is excluded from the engine/chat timings below.

| Coverage / scenario | Auto-map seconds | Chat seconds | Source-model POSTs | Rule-model POSTs | Preliminary reviews | Result |
|---|---:|---:|---:|---:|---:|---|
| One target YAML absent; new mixed mapping | 114.56 | 9.634 | 2 | 1 | 0 | passed |
| All selected YAMLs absent; uploaded CTE / retained ID | 103.07 | 10.779 | 1 | 1 | 0 | passed |

Both runs produced the expected output values, positive confidence for supported definitions, cited the persisted FIR recipe, released execution slots and cleaned up their scratch schemas. The CTE case retained its existing ID definition and ACTIVE population filter. Each builder chat returned a final explanation of the name/Firm Value transformation and a missing-evidence notice; no Analyst tool was bound to the incomplete selection. The runner uses the normal bounded context-retrieval continuation if the builder requests exact evidence before answering.

NATIVE-semantic-partial.json includes raw fixture model envelopes, per-target returned definitions and exact template/deployed-fixture hashes. Its recorded runtime hashes and all three template hashes match the final packaged source. The all-missing report preceded the final explicit SQL-NULL serialization clarification in the source-agent instructions/packet; the shared missing-semantics, builder and transformation behavior is the same. The final partial run verifies that clarification and returns OWNERNAME with mapping_mode constant and constant_value the string NULL.

An earlier repeat exposed a model definition mismatch for intended NULL; its report is retained as INVESTIGATION-partial-null-contract.json. It did not fail on missing YAML: four supported definitions survived, but the acceptance compiler refused the incomplete OWNERNAME definition. The new canonical output guidance addresses this distinction; unsupported future model outputs still require explicit review/repair, not fabricated defaults.

## Phase accounting

Detailed per-call UTC timestamps, control-session waits, retries, SQL query IDs and actual POST counts are in each JSON. Parallel phases overlap, so their sums are not job wall time. Source/rule stages below exclude fixture provisioning and chat.

| Coverage | Call | Stage | Archive | Admission | Thread | Atomic save | Model | Cleanup |
|---|---:|---|---:|---:|---:|---:|---:|---:|
| Partial | 1 | source_mapping | 13.96 | 9.17 | 0.31 | 5.15 | 15.16 | 4.15 |
| Partial | 2 | source_mapping | 19.22 | 6.43 | 0.32 | 4.49 | 24.62 | 3.88 |
| Partial | 3 | transformation_rule | 9.39 | 6.94 | 0.3 | 2.99 | 22.72 | 4.14 |
| None / CTE | 1 | source_mapping | 12.7 | 5.97 | 0.31 | 3.67 | 24.27 | 3.66 |
| None / CTE | 2 | transformation_rule | 8.99 | 5.86 | 0.31 | 2.95 | 23.27 | 3.92 |

This is an engine/transport acceptance with local fixture governance/postflight persistence disabled, not a production SPCS browser test. SQL-upload publication remains a local regression check; these native tests do not publish mappings or change client data. The older four normal-coverage scenarios are documented separately in NATIVE-RESULTS.md with their own source hashes.
