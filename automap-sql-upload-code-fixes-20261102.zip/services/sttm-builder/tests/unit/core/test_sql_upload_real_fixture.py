"""Offline real SQL -> production parser -> frontend Apply regression."""
import hashlib
import json
from pathlib import Path
import shutil
import socket
import subprocess

import pytest
from sqlglot import exp, parse_one

from app.core.sql_parser import parse_sql_document
from app.core.mapping_sql import MappingSqlService
from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem

ROOT = Path(__file__).resolve().parents[5]
FIXTURE = ROOT / 'services/sttm-builder/tests/fixtures/Ft. Pitt 01-HHs.sql'
SCRIPT = ROOT / 'frontend/scripts/test-upload-workflow.cjs'
NAMESPACE = 'FFP_HDP_CRM_MIG_DB_DEV.SCH_DYNAMICS_FTPITT_BBI'
PREDICATES = [
    'JIMSHH.ACCOUNTOWNERID = mu.DYNAMICS_USER_GUID',
    'JIMSHH.CountryKey = cc.MatchKey',
    'JIMSHH.StateKey = sc.MatchKey',
    'JIMSHH.LegacyPASID = mhm.LEGACYPORTFOLIOACCOUNTID',
    'JIMSHH.SOURCEOFBUSINESS = rl.REFERRAL_SOURCE__C AND JIMSHH.SoBKey = rl.SoBKey',
]


@pytest.fixture(autouse=True)
def offline_only(monkeypatch):
    def no_network(*args, **kwargs):
        raise AssertionError('Real-fixture regression must stay offline')
    monkeypatch.setattr(socket.socket, 'connect', no_network)


@pytest.fixture
def upload():
    text = FIXTURE.read_text(encoding='utf-8-sig')
    assert hashlib.sha256(text.encode()).hexdigest() == 'fe19b90c82c95dd281556fdf74d6c35b929798f7ad998887637b28aea9f1d031'
    parsed = parse_sql_document(text).to_dict()
    # Explicit offline catalog evidence, not a claim about the live account.
    references = [dict(raw_identifier=name, resolved_fqn=f'{NAMESPACE}.ACCOUNTS' if name == 'ACCOUNTS' else name,
                       reference_role='source', resolution_status='resolved', catalog_status='available',
                       semantic_status='lookup_failed') for name in parsed['source_tables']]
    return dict(asset_id='real-ft-pitt', parsed_summary=parsed,
                import_preview=dict(sql=text, table_references=references))


def run_frontend(uploaded, expected_error=None):
    node = shutil.which('node')
    assert node and (ROOT / 'frontend/node_modules/typescript').exists(), 'Install frontend test dependencies'
    result = subprocess.run([node, str(SCRIPT), '--upload-json'],
                            input=json.dumps(dict(uploaded=uploaded, expectedError=expected_error)),
                            capture_output=True, text=True, timeout=60)
    assert result.returncode == 0, result.stdout + result.stderr
    return json.loads(next(line.split(':', 1)[1] for line in result.stdout.splitlines()
                           if line.startswith('UPLOAD_RESULT:')))


@pytest.mark.parametrize('semantic_status', ['active', 'missing', 'stale', 'lookup_failed'])
def test_real_fixture_all_joins_targets_and_sql_survive_apply(upload, semantic_status):
    for reference in upload['import_preview']['table_references']:
        reference['semantic_status'] = semantic_status
    parsed = upload['parsed_summary']
    outer = next(scope for scope in parsed['query_scopes'] if not scope['parent_scope_id'])
    assert [join['predicate'] for join in outer['joins']] == PREDICATES
    assert [join['join_type'] for join in outer['joins']] == ['LEFT'] * 5
    result = run_frontend(upload)
    workspace, state = result['workspace'], result['state']
    assert workspace['sql'] == state['mappingSql'] == upload['import_preview']['sql']
    assert len(workspace['mappings']) == len(parse_one(workspace['sql'], read='snowflake').expressions) == 35
    assert [row['targetColumn'] for row in workspace['mappings']] == [row['target_alias'] for row in parsed['column_mappings']]
    assert len(workspace['sourceTableFqns']) == 6
    assert workspace['unresolvedSourceTables'] == []
    assert len(workspace['derivedSources']) == 4
    assert all(source['isSelected'] for source in workspace['derivedSources'])
    driver = next(source for source in workspace['derivedSources'] if source['name'] == 'JimsHH')
    assert outer['relations'][0]['source_scope_id'] == driver['queryScope']['scope_id']
    assert workspace['drivingTableId'] == driver['id']
    assert workspace['queryModifiers']['distinct'] == 'DISTINCT'
    joins = workspace['relationships']
    assert len(joins) == len(state['relationships']) == len(result['graph']['edges']) == 5
    assert [join['joinType'] for join in joins] == ['LEFT'] * 5
    assert [join['rightTableId'] for join in joins] == [
        f'{NAMESPACE}.MAPPER_USER',
        next(source['id'] for source in workspace['derivedSources'] if source['name'] == 'CountryLookup'),
        next(source['id'] for source in workspace['derivedSources'] if source['name'] == 'StateLookup'),
        f'{NAMESPACE}.MAPPER_HH_MASTER',
        next(source['id'] for source in workspace['derivedSources'] if source['name'] == 'ReferralLookup'),
    ]
    assert all(join['leftTableId'] == driver['id'] for join in joins)
    for actual, expected, edge in zip(joins, outer['joins'], result['graph']['edges']):
        assert edge['join_type'] == 'LEFT'
        assert edge['conditions'] == expected['structured']['conditions']
        assert [dict(left_column=pair['leftColumn'], operator=pair['operator'], right_column=pair['rightColumn'])
                for pair in actual['conditions']] == expected['structured']['conditions']
    assert [len(join['conditions']) for join in joins] == [1, 1, 1, 1, 2]
    node_ids = {node['relation_id'] for node in result['graph']['nodes']}
    assert all(join['leftTableId'] in node_ids and join['rightTableId'] in node_ids for join in joins)
    for source, cte in zip(workspace['derivedSources'], parsed['ctes']):
        assert source['definitionSql'] == cte['definition_sql']
        assert source['sqlText'] == cte['sql_text']
        assert source['queryScope'] == cte['scope_contract']
    query = parse_one(workspace['sql'], read='snowflake')
    assert len(list(query.find_all(exp.Union))) == 3
    assert all(union.args['distinct'] for union in query.find_all(exp.Union))
    assert len(list(query.find_all(exp.Join))) == 6
    assert len(list(query.find_all(exp.Distinct))) == 2
    assert '$LegacyHHcPrefix' in next(row['expression'] for row in workspace['mappings'] if row['targetColumn'] == 'Legacy_ID__c')
    assert next(row for row in parsed['column_mappings'] if row['target_alias'] == 'FINSERV__STATUS__C')['constant_value'] == "'Current Client'"
    assert next(row for row in workspace['mappings'] if row['targetColumn'] == 'FINSERV__STATUS__C')['constantValue'] == 'Current Client'
    assert result['expressions']['FINSERV__STATUS__C'] == "'Current Client'"
    assert result['regeneratedSql'].count("'Current Client' AS FINSERV__STATUS__C") == 1
    assert "'''Current Client'''" not in result['regeneratedSql']
    assert next(row for row in workspace['mappings'] if row['targetColumn'] == 'Transaction_Firm__c')['constantValue'] == '$TransactionFirmID'


def test_real_fixture_apply_target_hydration_currency_and_save_lifecycle(upload):
    result = subprocess.run([shutil.which('node'), str(SCRIPT), '--upload-json', '--hydration-lifecycle'],
                            input=json.dumps(dict(uploaded=upload)), capture_output=True, text=True, timeout=60)
    assert result.returncode == 0, result.stdout + result.stderr
    lifecycle = json.loads(next(line.split(':', 1)[1] for line in result.stdout.splitlines()
                                if line.startswith('HYDRATION_RESULT:')))
    assert lifecycle == dict(mapped=35, hydrated=45, ctes=4, applySaves=1,
                             editSaves=1, hydrationCompiles=0, editCompiles=1)


def compile_frontend_rows(result):
    # Exercise the production typed request and compiler without a session or EXPLAIN.
    state = result['state']
    request = MappingSqlCompileRequest(
        relation_graph=result['graph'], driving_relation_id=state['drivingTableId'],
        validate_with_explain=False,
        mappings=[MappingSqlMappingItem(
            target_column=row['targetColumn'], target_type=row['targetType'],
            mapping_mode=row['mappingMode'], constant_value=row['constantValue'],
            source_columns=row['sourceColumns'], expression=row['expression'],
            rule=row['rule'], status=row['status'],
        ) for row in state['mappings']],
    )
    return MappingSqlService(session=None, analyst_client=None).compile(request)


def test_real_fixture_row_regeneration_matches_backend_constant_contract(upload):
    result = run_frontend(upload)
    compiled = compile_frontend_rows(result)
    query = parse_one(compiled.generated_sql, read='snowflake')
    status = next(item.this for item in query.expressions if item.alias == 'FINSERV__STATUS__C')
    assert isinstance(status, exp.Literal) and status.is_string
    assert status.this == 'Current Client'
    assert "'''Current Client'''" not in compiled.generated_sql
    assert len(query.expressions) == 35
    assert len(query.args['joins']) == 5
    assert all(join.side == 'LEFT' for join in query.args['joins'])
    # No firm values were supplied by the fixture; compilation must not invent them.
    assert not compiled.ready
    assert {name.upper().lstrip('$') for name in compiled.unresolved_placeholders} == {
        'TRANSACTIONFIRMID', 'PARENTOFFICEID', 'CLIENTSTARTDATE',
        'HHRECORDTYPE', 'MASTER_PAYOUT_DATE',
    }
    # The separate source-expression placeholder is retained verbatim too.
    assert '$LegacyHHcPrefix' in compiled.canonical_preview_sql
    assert '$LegacyHHcPrefix' in result['expressions']['Legacy_ID__c']
    assert compiled.script_sql is None
    for row in result['workspace']['mappings']:
        if row['mappingMode'] == 'constant' and row['constantValue'].startswith('$'):
            assert row['attributeName'] is None
            assert result['expressions'][row['targetColumn']] == row['constantValue']


@pytest.mark.parametrize('use_preview_rows', [False, True])
def test_parsed_constant_tokens_decode_once_and_regenerate_offline(use_preview_rows):
    text = """SELECT 'O''Brien' AS APOSTROPHE, '''Current Client''' AS QUOTED_VALUE,
        'He said ''Hello''' AS EMBEDDED_QUOTES, 'a''''b' AS DOUBLE_APOSTROPHE,
        42 AS NUMERIC_VALUE, TRUE AS TRUE_VALUE, FALSE AS FALSE_VALUE,
        NULL AS NULL_VALUE, $MissingValue AS UNRESOLVED FROM D.S.A"""
    parsed = parse_sql_document(text)
    expected = {
        'APOSTROPHE': ("'O''Brien'", "O'Brien", 'TEXT'),
        'QUOTED_VALUE': ("'''Current Client'''", "'Current Client'", 'TEXT'),
        'EMBEDDED_QUOTES': ("'He said ''Hello'''", "He said 'Hello'", 'TEXT'),
        'DOUBLE_APOSTROPHE': ("'a''''b'", "a''b", 'TEXT'),
        'NUMERIC_VALUE': ('42', '42', 'NUMBER'),
        'TRUE_VALUE': ('TRUE', 'TRUE', 'BOOLEAN'),
        'FALSE_VALUE': ('FALSE', 'FALSE', 'BOOLEAN'),
        'NULL_VALUE': ('NULL', 'NULL', 'TEXT'),
        'UNRESOLVED': ('$MissingValue', '$MissingValue', 'TEXT'),
    }
    for row in parsed.column_mappings:
        assert row.mapping_mode == 'constant'
        token = expected[row.target_alias][0]
        assert parse_one(row.constant_value, read='snowflake') == parse_one(token, read='snowflake')
    # Real Snowflake rendering uses backslash-escaped apostrophes, not the input spelling.
    assert parsed.column_mappings[0].constant_value == "'O\\'Brien'"
    summary = parsed.to_dict()
    # The parser has no target metadata. Supply explicit target types as the UI does.
    for row in summary['column_mappings']:
        row['target_type'] = expected[row['target_alias']][2]
    uploaded = dict(asset_id='constants', parsed_summary=summary)
    if use_preview_rows:
        uploaded['import_preview'] = dict(mapping_rows=summary['column_mappings'], sql=text)
    result = run_frontend(uploaded)
    for row in result['state']['mappings']:
        token, value, _ = expected[row['targetColumn']]
        assert row['constantValue'] == value
        assert row['mappingMode'] == 'constant'
        assert row['attributeName'] is None
        assert result['expressions'][row['targetColumn']] == token
    compiled = compile_frontend_rows(result)
    projections = {item.alias: item.this for item in parse_one(compiled.generated_sql, read='snowflake').expressions}
    for target, (token, _, _) in expected.items():
        assert projections[target] == parse_one(token, read='snowflake')
    assert not compiled.ready
    assert [name.upper().lstrip('$') for name in compiled.unresolved_placeholders] == ['MISSINGVALUE']
    assert compiled.script_sql is None


def test_resolved_project_value_keeps_its_literal_quotes():
    parsed = parse_sql_document("SET Firm = '''Current Client'''; SELECT $Firm AS FIRM FROM D.S.A").to_dict()
    result = run_frontend(dict(asset_id='project-value', parsed_summary=parsed))
    row = result['state']['mappings'][0]
    assert row['mappingMode'] == 'attribute'
    assert row['constantValue'] == "'Current Client'"
    assert row['attributeName'].upper() == 'FIRM'
    assert result['expressions']['FIRM'] == "'''Current Client'''"


@pytest.mark.parametrize('catalog_status,resolution_status', [
    ('lookup_failed', 'lookup_failed'), ('lookup_failed', 'resolved'), (None, 'resolved'),
])
def test_unknown_catalog_preserves_explicit_exact_join_source(upload, catalog_status, resolution_status):
    reference = next(ref for ref in upload['import_preview']['table_references'] if ref['raw_identifier'].endswith('.MAPPER_USER'))
    reference.update(catalog_status=catalog_status, resolution_status=resolution_status)
    result = run_frontend(upload)
    identity = reference['raw_identifier']
    assert identity in result['workspace']['sourceTableFqns']
    assert identity in result['state']['unresolvedSourceTables']
    assert result['graph']['edges'][0]['right_relation_id'] == identity


def test_missing_reference_preserves_explicit_fqn_identity(upload):
    upload['import_preview']['table_references'] = [ref for ref in upload['import_preview']['table_references']
                                                  if not ref['raw_identifier'].endswith('.MAPPER_USER')]
    result = run_frontend(upload)
    assert result['graph']['edges'][0]['right_relation_id'] == f'{NAMESPACE}.MAPPER_USER'


def test_broken_scope_id_is_not_resolved_by_cte_name_guess(upload):
    outer = next(scope for scope in upload['parsed_summary']['query_scopes'] if not scope['parent_scope_id'])
    outer['relations'][2]['source_scope_id'] = 'nonexistent'
    assert 'error' in run_frontend(upload, 'scope.*nonexistent')


def test_unqualified_cte_input_blocks_without_dropping_its_dependency(upload):
    reference = next(ref for ref in upload['import_preview']['table_references'] if ref['raw_identifier'] == 'ACCOUNTS')
    reference.update(resolved_fqn=None, resolution_status='ambiguous', catalog_status=None)
    assert 'error' in run_frontend(upload, 'source identities.*ACCOUNTS')


def test_real_fixture_preserves_complex_join_as_complete_predicate(upload):
    text = upload['import_preview']['sql'].replace(
        'JIMSHH.CountryKey = cc.MatchKey', '(JIMSHH.CountryKey = cc.MatchKey OR cc.MatchKey IS NULL)')
    upload['parsed_summary'] = parse_sql_document(text).to_dict()
    upload['import_preview']['sql'] = text
    result = run_frontend(upload)
    join = result['workspace']['relationships'][1]
    assert join['joinType'] == 'LEFT'
    assert join['conditions'] == []
    assert join['sqlPredicate'] == '(cte_jimshh.CountryKey = cte_countrylookup.MatchKey OR cte_countrylookup.MatchKey IS NULL)'
    assert len(result['graph']['edges']) == 5
    assert result['graph']['edges'][1]['additional_predicate'] == join['sqlPredicate']
    assert result['state']['mappingSql'] == text


def assert_parent_ids_survive_apply(result, source_name, expected_names):
    sources = {source['name']: source for source in result['workspace']['derivedSources']}
    source = sources[source_name]
    expected = {sources[name]['id'] for name in expected_names}
    assert set(source['parentDerivedSourceIds']) == expected
    assert expected <= set(source['inputTables'])
    applied = next(item for item in result['state']['derivedSources'] if item['id'] == source['id'])
    assert set(applied['parentDerivedSourceIds']) == set(applied['derivedSourceIds']) == expected
    node = next(item for item in result['graph']['nodes'] if item['relation_id'] == source['id'])
    assert set(node['parent_relation_ids']) == expected


def test_real_fixture_union_descendant_dependency_survives_apply(upload):
    parsed = upload['parsed_summary']
    referral = next(cte for cte in parsed['ctes'] if cte['name'] == 'ReferralLookup')
    assert referral['scope_contract']['query_kind'] == 'union'
    assert referral['scope_contract']['relations'] == []
    result = run_frontend(upload)
    assert_parent_ids_survive_apply(result, 'ReferralLookup', ['JimsHH'])
    assert_parent_ids_survive_apply(result, 'CountryLookup', [])
    assert_parent_ids_survive_apply(result, 'StateLookup', [])
    compiled = compile_frontend_rows(result)
    assert len(parse_one(compiled.generated_sql, read='snowflake').expressions) == 35


def test_union_nested_shadows_and_transitive_dependencies_are_scope_bound():
    text = '''WITH seed AS (SELECT ID FROM D.S.SEED),
      base AS (SELECT ID FROM seed),
      unrelated AS (SELECT ID FROM D.S.UNRELATED),
      output AS (
        SELECT b.ID FROM D.S.A a JOIN (SELECT ID FROM base) b ON a.ID = b.ID
        UNION SELECT b.ID FROM D.S.B a JOIN (SELECT ID FROM base) b ON a.ID = b.ID
        UNION SELECT ID FROM (
          WITH base AS (SELECT ID FROM D.S.SHADOW) SELECT ID FROM base
        ) shadowed
      ) SELECT o.ID, b.ID AS BASE_ID, s.ID AS SEED_ID FROM output o
      LEFT JOIN base b ON o.ID = b.ID LEFT JOIN seed s ON b.ID = s.ID'''
    parsed = parse_sql_document(text).to_dict()
    result = run_frontend(dict(asset_id='shadowed', parsed_summary=parsed))
    base_ctes = [cte for cte in parsed['ctes'] if cte['name'] == 'base']
    assert len(base_ctes) == 2
    outer = next(scope for scope in parsed['query_scopes'] if not scope['parent_scope_id'])
    outer_base = next(cte for cte in base_ctes if cte['scope_contract']['parent_scope_id'] == outer['scope_id'])
    sources = result['workspace']['derivedSources']
    base = next(source for source in sources if source['queryScope']['scope_id'] == outer_base['scope_id'])
    output = next(source for source in sources if source['name'] == 'output')
    seed = next(source for source in sources if source['name'] == 'seed')
    assert output['parentDerivedSourceIds'] == [base['id']]
    assert base['parentDerivedSourceIds'] == [seed['id']]
    applied = {source['id']: source for source in result['state']['derivedSources']}
    nodes = {node['relation_id']: node for node in result['graph']['nodes']}
    for source in (output, base, seed):
        assert applied[source['id']]['parentDerivedSourceIds'] == source['parentDerivedSourceIds']
        assert nodes[source['id']]['parent_relation_ids'] == source['parentDerivedSourceIds']
    assert not next(source for source in sources if source['name'] == 'unrelated')['isSelected']
    assert any(source['name'] == 'base' and source['id'] != base['id']
               and source['id'] not in output['parentDerivedSourceIds'] for source in sources)
    # Selection does not invent dependency canvas nodes; the actual parent
    # closure must still survive when only the UNION source is selected.
    parsed_only = parse_sql_document(text.split(') SELECT o.ID,')[0] + ') SELECT ID FROM output').to_dict()
    only = run_frontend(dict(asset_id='shadowed-only', parsed_summary=parsed_only))
    only_sources = {source['id']: source for source in only['state']['derivedSources']}
    selected = [source for source in only_sources.values() if source['isSelected']]
    assert len(selected) == 1 and selected[0]['sourceName'] == 'output'
    parent = only_sources[selected[0]['parentDerivedSourceIds'][0]]
    assert parent['sourceName'] == 'base'
    assert only_sources[parent['parentDerivedSourceIds'][0]]['sourceName'] == 'seed'
    output_node = next(node for node in only['graph']['nodes'] if node['relation_id'] == selected[0]['id'])
    assert output_node['parent_relation_ids'] == selected[0]['parentDerivedSourceIds']


def test_quoted_and_unquoted_aliases_rewrite_separately_through_real_parser():
    text = '''SELECT "a".ID + A.ID AS TOTAL,
      COALESCE("a".NAME, '"a".NAME and A.NAME') AS LABEL
      FROM D.S.LOWER_SOURCE AS "a" LEFT JOIN D.S.UPPER_SOURCE AS A
      ON ("a".ID = A.ID OR "a".NAME = 'A.ID')'''
    parsed = parse_sql_document(text).to_dict()
    result = run_frontend(dict(asset_id='quoted-alias', parsed_summary=parsed, import_preview=dict(sql=text)))
    aliases = {node['relation_id']: node['alias'] for node in result['graph']['nodes']}
    lower, upper = aliases['D.S.LOWER_SOURCE'], aliases['D.S.UPPER_SOURCE']
    assert lower != upper
    rows = {row['targetColumn']: row for row in result['state']['mappings']}
    assert rows['TOTAL']['expression'] == f'{lower}.ID + {upper}.ID'
    assert set(rows['TOTAL']['sourceColumns']) == {f'{lower}.ID', f'{upper}.ID'}
    assert rows['LABEL']['expression'] == f'''COALESCE({lower}.NAME, '"a".NAME and A.NAME')'''
    predicate = f'''({lower}.ID = {upper}.ID OR {lower}.NAME = 'A.ID')'''
    assert result['state']['relationships'][0]['sqlPredicate'] == predicate
    assert result['graph']['edges'][0]['additional_predicate'] == predicate
    assert result['state']['mappingSql'] == text
    compiled = compile_frontend_rows(result)
    # The compiler deliberately chooses readable aliases. Verify bindings to
    # the correct physical tables in both returned artifacts, not alias spelling.
    for sql in (compiled.canonical_preview_sql, compiled.generated_sql):
        query = parse_one(sql, read='snowflake')
        tables = {table.name: table.alias for table in query.find_all(exp.Table)}
        compiled_lower, compiled_upper = tables['LOWER_SOURCE'], tables['UPPER_SOURCE']
        assert compiled_lower != compiled_upper
        assert query.expressions[0].this.sql(dialect='snowflake') == f'{compiled_lower}.ID + {compiled_upper}.ID'
        assert query.args['joins'][0].args['on'].unnest() == parse_one(
            f"{compiled_lower}.ID = {compiled_upper}.ID OR {compiled_lower}.NAME = 'A.ID'", read='snowflake')
        assert {literal.this for literal in query.find_all(exp.Literal) if literal.is_string} == {
            '"a".NAME and A.NAME', 'A.ID'}


@pytest.mark.parametrize('status', ['unresolved', 'ambiguous', 'invalid'])
def test_explicit_unresolved_fqn_is_not_overridden(upload, status):
    reference = next(ref for ref in upload['import_preview']['table_references'] if ref['raw_identifier'].endswith('.MAPPER_USER'))
    reference.update(resolution_status=status, catalog_status='lookup_failed')
    assert 'error' in run_frontend(upload, 'source identities.*MAPPER_USER')


def test_unknown_unqualified_identity_cannot_be_borrowed_from_another_fqn():
    parsed = parse_sql_document('SELECT a.ID FROM ACCOUNTS a').to_dict()
    references = [dict(raw_identifier='ACCOUNTS', resolved_fqn='D.S.ACCOUNTS',
                       reference_role='source', resolution_status='lookup_failed', catalog_status='lookup_failed'),
                  dict(raw_identifier='D.S.ACCOUNTS', resolved_fqn='D.S.ACCOUNTS',
                       reference_role='source', resolution_status='resolved', catalog_status='available')]
    assert 'error' in run_frontend(dict(asset_id='unknown-short', parsed_summary=parsed,
                                       import_preview=dict(table_references=references)), 'source identities.*ACCOUNTS')


@pytest.mark.parametrize('use_ft_pitt', [False, True])
def test_nine_fqns_use_real_bounded_qualification_and_continue_offline(monkeypatch, upload, use_ft_pitt):
    from app.core.config import Settings
    from app.routers.upload import _qualified_upload_references
    import app.core.upload_reference_status as reference_status

    # Only the Snowflake transport is substituted. Real qualification, shared
    # eight-call budget, parser, workspace, Apply reducer and compiler all run.
    class OfflineCatalog:
        def __init__(self):
            self.calls = []

        def sql(self, query, params):
            assert query == 'DESCRIBE TABLE IDENTIFIER(?)'
            self.calls.append((query, params))
            return self

        def collect(self, *, statement_params):
            assert statement_params['STATEMENT_TIMEOUT_IN_SECONDS'] > 0
            return [dict(name='ID')]

    monkeypatch.setattr(reference_status.time, 'monotonic', lambda: 0.0)
    session = OfflineCatalog()
    text = 'SELECT t0.ID FROM D.S.T0 t0 ' + ' '.join(
        f'LEFT JOIN D.S.T{index} t{index} ON t0.ID = t{index}.ID' for index in range(1, 9))
    if use_ft_pitt:
        # Keep the provided query, qualifying its one short identity explicitly
        # and adding three joins to exercise nine FQNs with its real UNION CTEs.
        text = upload['import_preview']['sql'].replace('ACCOUNTS as a', f'{NAMESPACE}.ACCOUNTS as a').rstrip().rstrip(';')
        text += ' ' + ' '.join(f'LEFT JOIN D.S.EXTRA{index} extra{index} ON JIMSHH.LEGACYCRMID = extra{index}.ID'
                              for index in range(3))
    parsed = parse_sql_document(text).to_dict()
    references = _qualified_upload_references(
        session, Settings(), project_id='offline',
        references=[(name, 'source') for name in parsed['source_tables']], use_context={}, known_tables=[])
    assert len(session.calls) == 6  # Two calls are reserved for semantic inspection.
    unknown = [ref for ref in references if ref['catalog_status'] == 'lookup_failed']
    assert len(unknown) == 3
    assert any(warning['reason'] == 'call_limit' for warning in unknown[0]['metadata_warnings'])
    result = run_frontend(dict(asset_id='nine-fqns', parsed_summary=parsed,
                               import_preview=dict(sql=text, table_references=references)))
    expected = set(parsed['source_tables'])
    assert len(expected) == 9
    assert set(result['workspace']['sourceTableFqns']) == expected
    assert {source['tableId'] for source in result['state']['sources'] if source['isSelected']} == expected
    assert {node['relation_id'] for node in result['graph']['nodes'] if node['kind'] == 'PHYSICAL_TABLE'} == expected
    assert result['state']['unresolvedSourceTables'] == [item['raw_identifier'] for item in unknown]
    assert result['workspace']['targetTableFqn'] is None
    assert result['state']['compiledMappingReady'] is False
    assert result['state']['mappingSql'] == text
    assert len(result['graph']['edges']) == 8
    compiled = compile_frontend_rows(result)
    assert len(parse_one(compiled.generated_sql, read='snowflake').args['joins']) == 8
    if use_ft_pitt:
        assert len(result['workspace']['mappings']) == 35
        assert_parent_ids_survive_apply(result, 'ReferralLookup', ['JimsHH'])
    assert len(session.calls) == 6


@pytest.mark.parametrize('literal,value',[("'NULL'",'NULL'),("'null'",'null'),("' NULL '",' NULL ')],ids=['literal-null','lower-null','padded-null'])
def test_reserved_text_literals_remain_exact_expressions_through_upload(literal,value):
    text=f'SELECT {literal} AS VALUE FROM D.S.T'
    result=run_frontend(dict(asset_id='literal-reserved',parsed_summary=parse_sql_document(text).to_dict(),
                             import_preview=dict(sql=text)))
    row=result['state']['mappings'][0]
    assert row['mappingMode']=='source' and row['constantValue'] is None
    assert row['expression']==literal
    compiled=compile_frontend_rows(result)
    tree=parse_one(compiled.generated_sql,read='snowflake')
    item=tree.expressions[0].this
    assert isinstance(item,exp.Literal) and item.is_string and item.this==value
    assert compiled.ready and not compiled.unresolved_placeholders
