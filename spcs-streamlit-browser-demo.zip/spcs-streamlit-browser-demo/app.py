from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
import snowflake.connector
import streamlit as st

SERVICE_TOKEN_PATH = Path("/snowflake/session/token")
DEFAULT_TITLE = "Snowflake Access Browser Demo"


class DemoConnectionError(RuntimeError):
    """Raised when the demo cannot create a Snowflake connection."""


@dataclass(frozen=True)
class SessionMode:
    name: str
    description: str


def _normalize_host(host: str, account: str) -> str:
    normalized_host = (host or "").strip().replace("_", "-").lower()
    if normalized_host.endswith(".snowflakecomputing.com"):
        return normalized_host

    normalized_account = (account or "").strip().replace("_", "-").lower()
    if normalized_account.endswith(".snowflakecomputing.com"):
        return normalized_account
    if normalized_account:
        return f"{normalized_account}.snowflakecomputing.com"
    return normalized_host


def _read_service_token() -> str:
    try:
        token = SERVICE_TOKEN_PATH.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise DemoConnectionError(
            f"Could not read the service token from {SERVICE_TOKEN_PATH}: {exc}"
        ) from exc

    if not token:
        raise DemoConnectionError(f"The service token file {SERVICE_TOKEN_PATH} is empty.")
    return token


def _get_header(name: str) -> str:
    return str(st.context.headers.get(name, "") or "").strip()


def _detect_session_mode() -> SessionMode:
    if _get_header("Sf-Context-Current-User-Token"):
        return SessionMode(
            name="spcs_caller_rights",
            description="Running behind Snowflake ingress with caller-rights auth.",
        )
    return SessionMode(
        name="local_direct_auth",
        description="Running locally with direct Snowflake authentication.",
    )


def _local_connection_kwargs() -> dict[str, Any]:
    account = os.getenv("SNOWFLAKE_ACCOUNT", "").strip()
    user = os.getenv("SNOWFLAKE_USER", "").strip()
    warehouse = os.getenv("SNOWFLAKE_WAREHOUSE", "").strip()
    database = os.getenv("SNOWFLAKE_DATABASE", "").strip()
    schema = os.getenv("SNOWFLAKE_SCHEMA", "").strip()
    role = os.getenv("SNOWFLAKE_ROLE", "").strip()
    host = _normalize_host(os.getenv("SNOWFLAKE_HOST", ""), account)
    password = os.getenv("SNOWFLAKE_PASSWORD", "").strip()
    raw_authenticator = os.getenv("SNOWFLAKE_AUTHENTICATOR", "").strip()
    authenticator = raw_authenticator or ("snowflake" if password else "externalbrowser")

    if not account:
        raise DemoConnectionError("SNOWFLAKE_ACCOUNT is required for local mode.")
    if not user:
        raise DemoConnectionError("SNOWFLAKE_USER is required for local mode.")

    kwargs: dict[str, Any] = {
        "account": account,
        "user": user,
        "authenticator": authenticator,
    }
    if host:
        kwargs["host"] = host
    if warehouse:
        kwargs["warehouse"] = warehouse
    if database:
        kwargs["database"] = database
    if schema:
        kwargs["schema"] = schema
    if role:
        kwargs["role"] = role

    if authenticator.lower() not in {"externalbrowser", "oauth"}:
        if not password:
            raise DemoConnectionError(
                "SNOWFLAKE_PASSWORD is required when SNOWFLAKE_AUTHENTICATOR is not externalbrowser."
            )
        kwargs["password"] = password

    return kwargs


def _spcs_connection_kwargs() -> dict[str, Any]:
    account = os.getenv("SNOWFLAKE_ACCOUNT", "").strip()
    host = _normalize_host(os.getenv("SNOWFLAKE_HOST", ""), account)
    warehouse = os.getenv("SNOWFLAKE_WAREHOUSE", "").strip()
    database = os.getenv("SNOWFLAKE_DATABASE", "").strip()
    schema = os.getenv("SNOWFLAKE_SCHEMA", "").strip()
    role = os.getenv("SNOWFLAKE_ROLE", "").strip()
    user_token = _get_header("Sf-Context-Current-User-Token")

    if not account:
        raise DemoConnectionError("SNOWFLAKE_ACCOUNT must be set inside the service.")
    if not host:
        raise DemoConnectionError("SNOWFLAKE_HOST must be set inside the service.")
    if not user_token:
        raise DemoConnectionError(
            "Sf-Context-Current-User-Token was not present. Access the app through Snowflake public ingress."
        )

    kwargs: dict[str, Any] = {
        "account": account,
        "host": host,
        "authenticator": "oauth",
        "token": f"{_read_service_token()}.{user_token}",
    }
    if warehouse:
        kwargs["warehouse"] = warehouse
    if database:
        kwargs["database"] = database
    if schema:
        kwargs["schema"] = schema
    if role:
        kwargs["role"] = role
    return kwargs


@st.cache_resource(show_spinner=False)
def get_connection(mode_name: str, cache_hint: str) -> snowflake.connector.SnowflakeConnection:
    del cache_hint
    if mode_name == "spcs_caller_rights":
        kwargs = _spcs_connection_kwargs()
    else:
        kwargs = _local_connection_kwargs()
    return snowflake.connector.connect(**kwargs)


def _quote_identifier(name: str) -> str:
    escaped = name.replace('"', '""')
    return f'"{escaped}"'


def run_query(connection: snowflake.connector.SnowflakeConnection, sql: str) -> pd.DataFrame:
    with connection.cursor(snowflake.connector.DictCursor) as cursor:
        cursor.execute(sql)
        rows = cursor.fetchall()
    frame = pd.DataFrame(rows)
    frame.columns = [str(column).lower() for column in frame.columns]
    return frame


def select_existing_columns(frame: pd.DataFrame, candidates: list[str]) -> pd.DataFrame:
    columns = [column for column in candidates if column in frame.columns]
    if not columns:
        return frame
    return frame[columns]


def fetch_session_summary(connection: snowflake.connector.SnowflakeConnection) -> dict[str, Any]:
    sql = """
    SELECT
      CURRENT_USER() AS current_user,
      CURRENT_ROLE() AS current_role,
      CURRENT_WAREHOUSE() AS current_warehouse,
      CURRENT_DATABASE() AS current_database,
      CURRENT_SCHEMA() AS current_schema
    """
    frame = run_query(connection, sql)
    if frame.empty:
        return {}
    return frame.iloc[0].to_dict()


def fetch_databases(connection: snowflake.connector.SnowflakeConnection) -> pd.DataFrame:
    return run_query(connection, "SHOW DATABASES")


def fetch_schemas(connection: snowflake.connector.SnowflakeConnection, database: str) -> pd.DataFrame:
    return run_query(connection, f"SHOW SCHEMAS IN DATABASE {_quote_identifier(database)}")


def fetch_tables(
    connection: snowflake.connector.SnowflakeConnection,
    database: str,
    schema: str,
) -> pd.DataFrame:
    sql = (
        "SHOW TABLES IN SCHEMA "
        f"{_quote_identifier(database)}.{_quote_identifier(schema)}"
    )
    return run_query(connection, sql)


def build_cache_hint(mode: SessionMode) -> str:
    if mode.name == "spcs_caller_rights":
        return _get_header("Sf-Context-Current-User") or "spcs-user"
    return "|".join(
        [
            os.getenv("SNOWFLAKE_ACCOUNT", ""),
            os.getenv("SNOWFLAKE_USER", ""),
            os.getenv("SNOWFLAKE_ROLE", ""),
            os.getenv("SNOWFLAKE_WAREHOUSE", ""),
        ]
    )


def show_sidebar(mode: SessionMode) -> None:
    st.sidebar.header("Runtime")
    st.sidebar.write(f"Mode: `{mode.name}`")
    st.sidebar.write(mode.description)
    st.sidebar.divider()

    st.sidebar.header("Ingress Context")
    st.sidebar.write(
        {
            "Sf-Context-Current-User": _get_header("Sf-Context-Current-User") or "<absent>",
            "Sf-Context-Current-User-Token": "present"
            if _get_header("Sf-Context-Current-User-Token")
            else "absent",
        }
    )

    st.sidebar.divider()
    st.sidebar.header("Snowflake Env")
    st.sidebar.write(
        {
            "SNOWFLAKE_ACCOUNT": os.getenv("SNOWFLAKE_ACCOUNT", "<unset>"),
            "SNOWFLAKE_HOST": _normalize_host(
                os.getenv("SNOWFLAKE_HOST", ""),
                os.getenv("SNOWFLAKE_ACCOUNT", ""),
            )
            or "<unset>",
            "SNOWFLAKE_WAREHOUSE": os.getenv("SNOWFLAKE_WAREHOUSE", "<unset>"),
            "SNOWFLAKE_DATABASE": os.getenv("SNOWFLAKE_DATABASE", "<unset>"),
            "SNOWFLAKE_SCHEMA": os.getenv("SNOWFLAKE_SCHEMA", "<unset>"),
        }
    )


def main() -> None:
    st.set_page_config(
        page_title=os.getenv("DEMO_TITLE", DEFAULT_TITLE),
        layout="wide",
    )
    st.title(os.getenv("DEMO_TITLE", DEFAULT_TITLE))
    st.caption(
        "A minimal Snowpark Container Services demo that shows caller-visible "
        "databases, schemas, and tables."
    )

    mode = _detect_session_mode()
    show_sidebar(mode)

    try:
        connection = get_connection(mode.name, build_cache_hint(mode))
    except Exception as exc:
        st.error(f"Failed to connect to Snowflake: {exc}")
        st.stop()

    summary = fetch_session_summary(connection)
    st.subheader("Session")
    st.json(
        {
            "mode": mode.name,
            "snowflake_user_header": _get_header("Sf-Context-Current-User") or None,
            **summary,
        }
    )

    databases = fetch_databases(connection)
    if databases.empty:
        st.warning("No visible databases were returned for this user.")
        st.stop()

    st.subheader("Visible Databases")
    database_names = databases["name"].tolist()
    selected_database = st.selectbox("Database", database_names, index=0)
    st.dataframe(
        select_existing_columns(databases, ["name", "kind", "owner", "comment"]).fillna(""),
        use_container_width=True,
        hide_index=True,
    )

    schemas = fetch_schemas(connection, selected_database)
    st.subheader("Visible Schemas")
    if schemas.empty:
        st.info(f"No visible schemas were returned for database `{selected_database}`.")
        st.stop()

    schema_names = schemas["name"].tolist()
    selected_schema = st.selectbox("Schema", schema_names, index=0)
    st.dataframe(
        select_existing_columns(schemas, ["name", "owner", "comment"]).fillna(""),
        use_container_width=True,
        hide_index=True,
    )

    tables = fetch_tables(connection, selected_database, selected_schema)
    st.subheader("Visible Tables")
    if tables.empty:
        st.info(
            f"No visible tables were returned for schema `{selected_database}.{selected_schema}`."
        )
    else:
        st.dataframe(
            select_existing_columns(
                tables,
                ["database_name", "schema_name", "name", "kind", "rows", "owner", "comment"],
            ).fillna(""),
            use_container_width=True,
            hide_index=True,
        )

    with st.expander("What this demo proves"):
        st.markdown(
            """
            - The public URL is fronted by Snowflake ingress.
            - In SPCS mode, the app uses `Sf-Context-Current-User-Token` plus the service token.
            - The object list reflects the caller's Snowflake visibility, not a shared service account.
            """
        )


if __name__ == "__main__":
    main()
