import base64
from urllib.parse import parse_qs, urlparse
from pathlib import Path

import httpx
import pytest
from fastapi import Request

from app.auth.custom_oauth import (
    _decode_state_cookie,
    _exchange_code_for_tokens,
    _pkce_code_challenge,
    _refresh_tokens,
    build_login_redirect,
)
from app.config import Settings
from app.core.exceptions import OAuthTokenExchangeError
from scripts.render_spcs_spec import _validate_spcs_oauth_config


def _settings() -> Settings:
    return Settings(
        _env_file=None,
        auth_mode="custom_oauth",
        auth_session_secret="state-signing-secret",
        auth_session_encryption_key="session-encryption-secret",
        auth_session_cookie_secure=False,
        snowflake_oauth_client_id="oauth-client-id",
        snowflake_oauth_client_secret="oauth-client-secret",
        snowflake_oauth_authorize_url="https://account.example/oauth/authorize",
        snowflake_oauth_token_url="https://account.example/oauth/token-request",
        snowflake_oauth_redirect_uri="https://app.example/api/v1/auth/callback",
        snowflake_oauth_scope="session:role:FOCUS_ADMIN",
    )


def _request(query: str = "") -> Request:
    return Request(
        {
            "type": "http",
            "http_version": "1.1",
            "method": "GET",
            "scheme": "https",
            "path": "/api/v1/auth/login",
            "raw_path": b"/api/v1/auth/login",
            "query_string": query.encode(),
            "headers": [],
            "client": ("127.0.0.1", 1234),
            "server": ("app.example", 443),
        }
    )


def _state_cookie(response: object, cookie_name: str) -> str:
    header = response.headers["set-cookie"]  # type: ignore[attr-defined]
    prefix = f"{cookie_name}="
    return header.split(prefix, 1)[1].split(";", 1)[0].strip('"')


def test_session_lookup_and_touch_share_connection_without_caching(monkeypatch):
    from contextlib import contextmanager
    from datetime import datetime, timedelta, timezone
    from unittest.mock import Mock
    from app.auth import custom_oauth as oauth

    settings = _settings()
    cursor = Mock()
    cursor.fetchone.return_value = {
        'SESSION_ID': 'session', 'SNOWFLAKE_USER': 'user', 'EMAIL': 'user@example.test',
        'APP_USER_ID': 'user', 'ACCESS_TOKEN_ENCRYPTED': 'encrypted',
        'ACCESS_TOKEN_EXPIRES_AT': datetime.now(timezone.utc) + timedelta(hours=1),
        'IS_ACTIVE': True,
    }
    connection = Mock()
    connection.cursor.return_value = cursor
    opened = []
    @contextmanager
    def connect(_settings):
        opened.append(True)
        yield connection
    monkeypatch.setattr(oauth, 'get_service_connection', connect)
    record = oauth._session_select_row('session', settings, touch=True)
    assert record.session_id == 'session'
    assert len(opened) == 1
    assert cursor.execute.call_count == 2
    assert 'IS_ACTIVE = TRUE' in cursor.execute.call_args_list[0].args[0]
    assert cursor.execute.call_args_list[1].args[1] == ('session',)
    connection.commit.assert_called_once()
    cursor.close.assert_called_once()
    monkeypatch.setattr(oauth, '_touch_session', Mock(side_effect=AssertionError('second connection')))
    assert oauth._refresh_session_if_needed(record, settings, touch=False) is record
    cursor.fetchone.return_value = None
    cursor.execute.reset_mock()
    assert oauth._session_select_row('session', settings, touch=True) is None
    assert len(opened) == 2  # Every request rechecks revocation; no cached record.
    assert cursor.execute.call_count == 1


def test_login_redirect_uses_pkce_and_binds_verifier_to_signed_state() -> None:
    settings = _settings()
    response = build_login_redirect(_request("next=%2Fdashboard"), settings)

    query = parse_qs(urlparse(response.headers["location"]).query)
    assert query["code_challenge_method"] == ["S256"]
    assert "code_challenge" in query
    assert "code_verifier" not in query

    state_payload = _decode_state_cookie(
        _state_cookie(response, settings.auth_state_cookie_name),
        settings,
    )
    assert state_payload["state"] == query["state"][0]
    assert state_payload["next"] == "/dashboard"
    assert query["code_challenge"] == [
        _pkce_code_challenge(state_payload["code_verifier"])
    ]


def test_token_exchange_uses_basic_auth_only_and_sends_pkce(monkeypatch) -> None:
    settings = _settings()
    captured: dict[str, object] = {}

    def _post(url: str, **kwargs: object) -> httpx.Response:
        captured["url"] = url
        captured.update(kwargs)
        return httpx.Response(
            200,
            json={
                "access_token": "access-token",
                "refresh_token": "refresh-token",
                "expires_in": 600,
            },
            request=httpx.Request("POST", url),
        )

    monkeypatch.setattr("app.auth.custom_oauth.httpx.post", _post)

    tokens = _exchange_code_for_tokens("authorization-code", "pkce-verifier", settings)

    assert tokens.access_token == "access-token"
    expected_basic = base64.b64encode(
        b"oauth-client-id:oauth-client-secret"
    ).decode("ascii")
    assert captured["headers"] == {
        "Accept": "application/json",
        "Authorization": f"Basic {expected_basic}",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    assert "auth" not in captured
    assert captured["data"] == {
        "grant_type": "authorization_code",
        "code": "authorization-code",
        "code_verifier": "pkce-verifier",
        "redirect_uri": settings.snowflake_oauth_redirect_uri,
    }
    assert "client_id" not in captured["data"]  # type: ignore[operator]
    assert "client_secret" not in captured["data"]  # type: ignore[operator]


@pytest.mark.parametrize(
    ("operation", "invoke"),
    [
        (
            "token exchange",
            lambda settings: _exchange_code_for_tokens("bad-code", "verifier", settings),
        ),
        ("token refresh", lambda settings: _refresh_tokens("bad-refresh", settings)),
    ],
)
def test_oauth_failures_are_sanitized(
    monkeypatch,
    operation: str,
    invoke,
) -> None:
    settings = _settings()
    raw_secret_marker = "must-not-leak-upstream-response"

    def _post(url: str, **_: object) -> httpx.Response:
        return httpx.Response(
            401,
            json={
                "error": "invalid_client",
                "message": raw_secret_marker,
            },
            request=httpx.Request("POST", url),
        )

    monkeypatch.setattr("app.auth.custom_oauth.httpx.post", _post)

    with pytest.raises(OAuthTokenExchangeError) as exc_info:
        invoke(settings)

    assert str(exc_info.value) == f"Snowflake OAuth {operation} failed"
    assert raw_secret_marker not in str(exc_info.value)
    assert exc_info.value.details == [{"field": "oauth", "message": "invalid_client"}]


def test_spcs_renderer_rejects_localhost_oauth_callback(monkeypatch) -> None:
    monkeypatch.setenv("AUTH_MODE", "custom_oauth")
    monkeypatch.setenv(
        "SNOWFLAKE_OAUTH_REDIRECT_URI",
        "http://localhost:3000/api/v1/auth/callback",
    )

    with pytest.raises(SystemExit, match="must be an HTTPS public callback URL"):
        _validate_spcs_oauth_config(Path("webapp.yaml.tmpl"))


def test_spcs_renderer_accepts_https_public_oauth_callback(monkeypatch) -> None:
    monkeypatch.setenv("AUTH_MODE", "custom_oauth")
    monkeypatch.setenv(
        "SNOWFLAKE_OAUTH_REDIRECT_URI",
        "https://app.example/api/v1/auth/callback",
    )
    monkeypatch.setenv("AUTH_SESSION_COOKIE_SECURE", "true")

    _validate_spcs_oauth_config(Path("webapp.yaml.tmpl"))


def test_spcs_renderer_rejects_insecure_oauth_cookie(monkeypatch) -> None:
    monkeypatch.setenv("AUTH_MODE", "custom_oauth")
    monkeypatch.setenv(
        "SNOWFLAKE_OAUTH_REDIRECT_URI",
        "https://app.example/api/v1/auth/callback",
    )
    monkeypatch.setenv("AUTH_SESSION_COOKIE_SECURE", "false")

    with pytest.raises(SystemExit, match="AUTH_SESSION_COOKIE_SECURE must be true"):
        _validate_spcs_oauth_config(Path("webapp.yaml.tmpl"))


def _login_request_with_cookie(settings, query='next=%2Fdashboard'):
    scope=dict(_request(query).scope)
    scope['headers']=[(b'cookie',f'{settings.auth_session_cookie_name}=existing-session'.encode())]
    return Request(scope)


@pytest.mark.parametrize('next_path,expected',[('next=%2Fdashboard','/dashboard'),('next=%2F%2Fevil.example','/home'),('next=%2F%5Cevil.example','/home')])
def test_login_reuses_verified_session_without_new_oauth_state(monkeypatch,next_path,expected):
    from app.auth import custom_oauth as oauth
    from types import SimpleNamespace
    from unittest.mock import Mock
    settings=_settings();record=SimpleNamespace(is_active=True)
    lookup=Mock(return_value=record);refresh=Mock(return_value=record)
    monkeypatch.setattr(oauth,'_session_select_row',lookup)
    monkeypatch.setattr(oauth,'_refresh_session_if_needed',refresh)
    monkeypatch.setattr(oauth,'decrypt_access_token',Mock(return_value='existing-token'))
    response=oauth.build_login_redirect(_login_request_with_cookie(settings,next_path),settings)
    assert response.headers['location']==expected
    assert response.headers['cache-control']=='no-store'
    assert 'set-cookie' not in response.headers
    lookup.assert_called_once_with('existing-session',settings)
    refresh.assert_called_once_with(record,settings,touch=False)


@pytest.mark.parametrize('kind',['unknown','revoked','expired','rejected_grant'])
def test_unusable_existing_session_starts_normal_pkce_login(monkeypatch,kind):
    from app.auth import custom_oauth as oauth
    from fastapi import HTTPException
    from types import SimpleNamespace
    settings=_settings();record=None if kind=='unknown' else SimpleNamespace(is_active=kind!='revoked')
    monkeypatch.setattr(oauth,'_session_select_row',lambda *a:record)
    def refresh(*a,**k):
        if kind=='expired':raise HTTPException(401,'Expired session')
        if kind=='rejected_grant':raise OAuthTokenExchangeError('Rejected',details=[{'field':'oauth','message':'invalid_grant'}])
        pytest.fail('Unknown/revoked session must not refresh')
    monkeypatch.setattr(oauth,'_refresh_session_if_needed',refresh)
    response=oauth.build_login_redirect(_login_request_with_cookie(settings),settings)
    query=parse_qs(urlparse(response.headers['location']).query)
    assert query['code_challenge_method']==['S256']
    assert settings.auth_state_cookie_name in response.headers['set-cookie']


@pytest.mark.parametrize('kind',['database','permission','provider'])
def test_auth_infrastructure_failures_do_not_silently_restart_oauth(monkeypatch,kind):
    from app.auth import custom_oauth as oauth
    from fastapi import HTTPException
    from types import SimpleNamespace
    settings=_settings()
    def lookup(*a):
        if kind=='database':raise RuntimeError('Database unavailable')
        return SimpleNamespace(is_active=True)
    def refresh(*a,**k):
        if kind=='permission':raise HTTPException(403,'Access denied')
        raise OAuthTokenExchangeError('Provider unavailable',details=[{'field':'oauth','message':'temporarily_unavailable'}])
    monkeypatch.setattr(oauth,'_session_select_row',lookup)
    monkeypatch.setattr(oauth,'_refresh_session_if_needed',refresh)
    with pytest.raises((RuntimeError,HTTPException,OAuthTokenExchangeError)):
        oauth.build_login_redirect(_login_request_with_cookie(settings),settings)


@pytest.mark.parametrize('age_seconds,expected_writes',[(30,0),(61,1)])
def test_activity_bookkeeping_is_throttled_but_revocation_is_always_read(monkeypatch,age_seconds,expected_writes):
    from app.auth import custom_oauth as oauth
    from contextlib import contextmanager
    from datetime import datetime,timedelta,UTC
    from unittest.mock import Mock
    cursor=Mock();now=datetime.now(UTC)
    cursor.fetchone.return_value={'SESSION_ID':'session','SNOWFLAKE_USER':'user','EMAIL':'user@example.test',
        'APP_USER_ID':'user','ACCESS_TOKEN_ENCRYPTED':'encrypted','ACCESS_TOKEN_EXPIRES_AT':now+timedelta(hours=1),
        'IS_ACTIVE':True,'LAST_ACCESSED_AT':now-timedelta(seconds=age_seconds),
        'ACTIVITY_TOUCH_DUE':age_seconds>=60}
    connection=Mock();connection.cursor.return_value=cursor
    @contextmanager
    def connect(settings):yield connection
    monkeypatch.setattr(oauth,'get_service_connection',connect)
    settings=_settings()
    oauth._session_select_row('session',settings,touch=True)
    assert cursor.execute.call_count==1+expected_writes
    assert "CONVERT_TIMEZONE('UTC', CURRENT_TIMESTAMP())::TIMESTAMP_NTZ" in cursor.execute.call_args_list[0].args[0]
    assert connection.commit.call_count==expected_writes
    cursor.execute.reset_mock();cursor.fetchone.return_value=None
    assert oauth._session_select_row('session',settings,touch=True) is None
    assert cursor.execute.call_count==1  # Revoked on next call, never served from cache.
