const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const filename = path.resolve(__dirname, '../src/components/sql/format-sql.ts');
const loaded = new Module(filename, module);
loaded.paths = Module._nodeModulePaths(path.dirname(filename));
loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, filename);
const { formatSqlForDisplay } = loaded.exports;
const cases = [
  'SELECT a.ID, b.NAME FROM D.S.A a LEFT JOIN D.S.B b ON a.ID=b.ID OR b.ID IS NULL WHERE a.ACTIVE=TRUE QUALIFY ROW_NUMBER() OVER(PARTITION BY a.ID ORDER BY a.TS)=1 ORDER BY a.ID NULLS FIRST LIMIT 7',
  'WITH base AS (SELECT ID, NAME FROM D.S.A), final AS (SELECT ID, UPPER(NAME) AS NAME FROM base) SELECT * FROM final',
  `SET FIRM = 'O''Brien  LLC'; SELECT $FIRM, '-- literal FROM WHERE' AS "Mixed.Name" FROM IDENTIFIER($SOURCE)`,
  `SELECT $$SELECT a,b FROM x; -- literal$$ AS BODY, 'a  b' AS TXT FROM D.S.A -- keep line comment\nWHERE ID>0`,
];
for (const sql of cases) {
  const formatted = formatSqlForDisplay(sql);
  assert.ok(formatted.split('\n').length >= 3, formatted);
  assert.equal(formatSqlForDisplay(formatted), formatted, 'formatting is idempotent');
}
assert.ok(formatSqlForDisplay(cases[2]).includes("'O''Brien  LLC'"));
assert.ok(formatSqlForDisplay(cases[2]).includes('"Mixed.Name"'));
assert.ok(formatSqlForDisplay(cases[3]).includes('$$SELECT a,b FROM x; -- literal$$'));
assert.ok(formatSqlForDisplay(cases[3]).includes("'a  b'"));
assert.equal(formatSqlForDisplay("SELECT 'unfinished"), "SELECT 'unfinished");
assert.equal(formatSqlForDisplay(''), '');
console.log('Snowflake SQL display formatting regressions passed.');