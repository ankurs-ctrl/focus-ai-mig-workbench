# AIA Migration Workbench — Agent Architecture

## Inside the App vs Outside the App

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  INSIDE THE APP  (synchronous, per user request)                                │
│                                                                                 │
│   Browser UI                                                                    │
│       │                                                                         │
│       │  chat / auto-map / transform / dbt / test-cases                        │
│       ▼                                                                         │
│   Python Backend (sttm-builder container)                                       │
│       │                                                                         │
│       ├─ 1. Fetch semantic bundle ──────────────────────────────────────────┐  │
│       │     (SemanticContextService reads SEM_TABLE_VIEWS / TBL_SEMANTIC_   │  │
│       │      MODELS built by AGT_SEMANTIC_MODEL)                            │  │
│       │                                                                     │  │
│       ├─ 2. Fetch FIR learning context ─────────────────────────────────┐  │  │
│       │     (LearningRetrievalService reads TBL_FIR_AGENT_RECOMMENDATIONS │  │  │
│       │      written by AGT_FIR_SYSTEM)                                  │  │  │
│       │                                                                  │  │  │
│       ▼                                                                  │  │  │
│   AGT_STTM_BUILDER  ◄── orchestrator for all user-facing STTM work      │  │  │
│       │                                                                  │  │  │
│       ├──[auto-map]──► SP_SUBAGT_SOURCE_MAPPING                         │  │  │
│       │                    └──► AGT_SOURCE_MAPPING                      │  │  │
│       │                             returns structured JSON mappings     │  │  │
│       │                                                                  │  │  │
│       ├──[complex SQL]──► SP_SUBAGT_TRANSFORMATION_RULE                 │  │  │
│       │                    └──► AGT_TRANSFORMATION_RULE                 │  │  │
│       │                             returns SQL expressions             │  │  │
│       │                                                                  │  │  │
│       ├──[dbt]──────────────────► AGT_DBT_CONVERSION                   │  │  │
│       │                                                                  │  │  │
│       ├──[test cases]──────────► AGT_DBT_TEST_GENERATION               │  │  │
│       │                                                                  │  │  │
│       ├──[chat/rag]─────────────► Cortex Search                        │  │  │
│       │                            CSS_WORKBENCH_RAG                    │  │  │
│       │                            CSS_FIR_KNOWLEDGE                    │  │  │
│       │                                                                  │  │  │
│       └──[sql questions]─────────► Cortex Analyst (dynamic, per bundle) │  │  │
│                                                                          │  │  │
└──────────────────────────────────────────────────────────────────────────┘  │  │
                                                                               │  │
┌──────────────────────────────────────────────────────────────────────────────▼──▼─┐
│  OUTSIDE THE APP  (background, Snowflake Tasks — no active user request)           │
│                                                                                    │
│   ┌─────────────────────────────────────────────────────────────────────────────┐ │
│   │  AGT_SEMANTIC_MODEL                                                         │ │
│   │  Triggered: on-demand when table semantic view is stale/missing,            │ │
│   │             or by background semantic pipeline jobs                         │ │
│   │                                                                             │ │
│   │  Tools: SP_GET_TABLE_CONTEXT_BUNDLE, SP_LIST_TABLES,                       │ │
│   │         SP_CHECK_TABLE_STALENESS, SP_SAVE_SEMANTIC_VIEW,                   │ │
│   │         SP_GET_CACHED_SEMANTIC_VIEW                                        │ │
│   │                                                                             │ │
│   │  Writes to: SEM_TABLE_VIEWS, TBL_SEMANTIC_MODELS                           │ │
│   │  ──────────────────────────────────────────────────────────────────────►   │ │
│   │  Read by SemanticContextService before every in-app agent call             │ │
│   └─────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                    │
│   ┌─────────────────────────────────────────────────────────────────────────────┐ │
│   │  AGT_FIR_SYSTEM  (Feedback → Inference → Recommendation flywheel)          │ │
│   │  Triggered: Snowflake stream-based tasks, 02:00 + 14:00 UTC daily           │ │
│   │             fires only when streams have new data                           │ │
│   │                                                                             │ │
│   │  Streams it watches:                                                        │ │
│   │    TBL_WORKBENCH_FEEDBACK, TBL_WORKBENCH_FIR_EVENTS,                       │ │
│   │    TBL_STTM_ATTRIBUTES, TBL_STTM_VERSIONS, TBL_DERIVED_SOURCES,            │ │
│   │    TBL_WORKBENCH_CONVERSATION_TURNS, SEM_TABLE_VIEWS,                      │ │
│   │    TBL_WORKBENCH_CLIENT_SQL_ASSETS, recommendation outcomes                │ │
│   │                                                                             │ │
│   │  Tools: SP_FIR_COLLECT_FEEDBACK, SP_FIR_READ_DOCUMENTS,                    │ │
│   │         SP_FIR_READ_PENDING_RECORDS, SP_FIR_READ_SEMANTIC_EVIDENCE,        │ │
│   │         SP_FIR_STORE_INFERENCE, SP_FIR_STORE_RECOMMENDATION,               │ │
│   │         SP_FIR_CREATE_SEMANTIC_VERSION, SP_FIR_APPLY_CONFIDENCE_DECAY      │ │
│   │                                                                             │ │
│   │  Writes to: TBL_FIR_AGENT_RECOMMENDATIONS, TBL_WORKBENCH_INFERENCES,       │ │
│   │             TBL_FIR_TARGET_MAPPING_PATTERNS (CSS_FIR_KNOWLEDGE index)      │ │
│   │  ──────────────────────────────────────────────────────────────────────►   │ │
│   │  Read by LearningRetrievalService before every in-app agent call           │ │
│   └─────────────────────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Full Agent Flow — per user action

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                          USER ACTIONS & AGENT ROUTING                            │
└──────────────────────────────────────────────────────────────────────────────────┘

 USER ACTION                 BACKEND ROUTE              AGENTS CALLED
 ───────────────────────────────────────────────────────────────────────────────────

 Types in chat               ConversationService
   │                          → STTMBuilderService
   │                            ├─ prepare semantic context (from AGT_SEMANTIC_MODEL output)
   │                            └─ inject FIR learnings  (from AGT_FIR_SYSTEM output)
   │                                         │
   │                                         ▼
   ├─ simple greeting ───────────────► fast-path answer (no agent call)
   │
   ├─ mapping question ─────────────► AGT_STTM_BUILDER
   │                                    └─ SearchWorkbenchRag + SearchFIRKnowledge
   │                                    └─ routes to AGT_SOURCE_MAPPING if needed
   │
   ├─ "explain this field" ─────────► AGT_STTM_BUILDER
   │                                    └─ SearchFIRKnowledge
   │
   └─ "run a SQL query" ────────────► AGT_STTM_BUILDER
                                        └─ Cortex Analyst tool (dynamic)


 Clicks AUTO-MAP button       STTMBuilderService
   │                            (invoke_auto_map_parallel)
   │                            ├─ semantic context
   │                            └─ FIR learning context
   │                                         │
   │                                         ▼
   │                           AGT_STTM_BUILDER
   │                               └─► SP_SUBAGT_SOURCE_MAPPING
   │                                       └─► AGT_SOURCE_MAPPING
   │                                               returns JSON: {
   │                                                 target_col: {
   │                                                   source_attributes,
   │                                                   confidence_score,
   │                                                   mapping_type: DIRECT/COMPLEX,
   │                                                   fir_evidence_ids
   │                                                 }
   │                                               }
   │
   └─ (if COMPLEX mappings found)
       STTMBuilderService second pass
           └─► AGT_STTM_BUILDER
                   └─► SP_SUBAGT_TRANSFORMATION_RULE
                           └─► AGT_TRANSFORMATION_RULE
                                   returns SQL expressions per attribute


 Clicks TRANSFORM button      STTMBuilderService
                                           │
                                           ▼
                              AGT_STTM_BUILDER
                                  └─► SP_SUBAGT_TRANSFORMATION_RULE
                                          └─► AGT_TRANSFORMATION_RULE


 Requests DBT conversion      STTMBuilderService
                                  routing_hint = dbt_conversion
                                           │
                                           ▼
                              AGT_DBT_CONVERSION
                                  └─ SP_DBT_GET_PROJECT_CONFIG
                                  └─ SP_DBT_LIST_DOMAIN_MODELS
                                  └─ SP_DBT_GET_FILE
                                  └─ SP_DBT_LIST_MACROS
                                  └─ SP_DBT_GET_SOURCES_YAML
                                  └─ SearchFIRKnowledge
                                  returns: raw/, curated/, mart/ .sql files
                                           schema.yml, sources.yml


 Requests test cases          STTMBuilderService
                                  routing_hint = test_cases
                                           │
                                           ▼
                              AGT_DBT_TEST_GENERATION
                                  └─ SearchFIRKnowledge
                                  returns: seed CSVs + test case document


 User accepts / edits /       Events written to:
 rejects a mapping              TBL_WORKBENCH_FEEDBACK
 User publishes STTM            TBL_STTM_ATTRIBUTES / TBL_STTM_VERSIONS
 User uploads SQL script        TBL_WORKBENCH_CLIENT_SQL_ASSETS
   │
   │  (streams capture all of the above)
   │
   └─► Snowflake Task fires (when streams have data, 02:00 + 14:00 UTC)
           └─► SP_FIR_INVOKE_AGENT
                   └─► AGT_FIR_SYSTEM
                           ├─ reads all feedback streams
                           ├─ generates inferences + recommendations
                           ├─ evolves curated semantic views
                           └─ writes to TBL_FIR_AGENT_RECOMMENDATIONS
                                        TBL_FIR_TARGET_MAPPING_PATTERNS
                                        CSS_FIR_KNOWLEDGE (Cortex Search index)
                                (picked up next time user triggers a mapping)
```

---

## Agent Summary Table

| Agent | Where it runs | Triggered by | Calls sub-agents | Reads from | Writes to |
|---|---|---|---|---|---|
| **AGT_STTM_BUILDER** | In-app, per request | Every user chat / auto-map / transform | AGT_SOURCE_MAPPING, AGT_TRANSFORMATION_RULE | Semantic bundle, FIR learnings | Conversation turns |
| **AGT_SOURCE_MAPPING** | In-app, per auto-map | AGT_STTM_BUILDER via SP | — | Agent payload (pre-packed by backend) | Returns JSON to caller |
| **AGT_TRANSFORMATION_RULE** | In-app, per transform | AGT_STTM_BUILDER via SP, or backend second pass | — | Agent payload | Returns SQL expressions to caller |
| **AGT_DBT_CONVERSION** | In-app, on demand | User requests dbt conversion | — | dbt repo SPs, FIR knowledge | dbt model files (via artifacts) |
| **AGT_DBT_TEST_GENERATION** | In-app, on demand | User requests test cases | — | FIR knowledge | Test case artifacts |
| **AGT_SEMANTIC_MODEL** | Outside app, on-demand / scheduled | Stale/missing semantic view, background pipeline | — | SP_GET_TABLE_CONTEXT_BUNDLE | SEM_TABLE_VIEWS, TBL_SEMANTIC_MODELS |
| **AGT_FIR_SYSTEM** | Outside app, Snowflake Tasks | Stream-triggered, 2× daily | — | 9 change streams (feedback, events, attributes, versions, SQL assets, …) | TBL_FIR_AGENT_RECOMMENDATIONS, TBL_FIR_TARGET_MAPPING_PATTERNS, CSS_FIR_KNOWLEDGE |
| **AGT_WORKBENCH_CONVERSATION** | In-app | Chat (simple routing only) | Routes to STTM_BUILDER | Cortex Search | — |

---

## The FIR Flywheel (how the app gets smarter over time)

```
  User accepts a mapping
  User rejects a suggestion
  User uploads a SQL script
  User publishes an STTM
          │
          │  written to Snowflake tables
          ▼
  ┌───────────────────┐
  │  Change Streams   │  (9 streams watching feedback, events,
  │  (Snowflake)      │   attributes, versions, SQL assets, etc.)
  └────────┬──────────┘
           │ fires when data arrives
           ▼
  ┌───────────────────────────────────┐
  │  Snowflake Task Graph             │
  │  TSK_FIR_CAPTURE                  │
  │  TSK_FIR_ENRICH_CONTEXT           │
  │  TSK_FIR_PROCESS_BATCH            │
  │  TSK_FIR_PROMOTE_INDEX            │
  │  TSK_FIR_LEARNING_QUEUE           │
  └────────┬──────────────────────────┘
           │ calls
           ▼
  ┌─────────────────────────┐
  │   AGT_FIR_SYSTEM        │  (claude-sonnet-4, 600s budget)
  │   analyzes patterns     │
  │   generates inferences  │
  │   writes recommendations│
  └────────┬────────────────┘
           │ writes
           ▼
  TBL_FIR_AGENT_RECOMMENDATIONS
  TBL_FIR_TARGET_MAPPING_PATTERNS
  CSS_FIR_KNOWLEDGE  (Cortex Search)
           │
           │  read at next user request
           ▼
  Backend injects into every agent payload
  as  context.learning_context
           │
           ▼
  AGT_SOURCE_MAPPING sees correction_history
  and similar_mappings → better suggestions
```
