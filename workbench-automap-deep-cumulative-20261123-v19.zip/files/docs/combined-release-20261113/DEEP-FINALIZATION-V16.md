# Deep finalization and saved mapping access — V16

Cumulative over V15 and both supplied ZIP baselines. This note supersedes V15's saved-SQL tool restriction and short-project timing limits where explicitly verified below. Preserve earlier limitations for other flows.

## Changes

- Completed responses no longer wait for SP_FLUSH_AGENT_COMMAND_OUTBOX before the final answer is durable. Mutation receipts still commit inside the existing command transaction. Outbox projection occurs afterward, and failures leave the successful answer intact while the existing terminal recovery retries projection. Approval/partial-migration flows retain their existing ordering.
- Short, explicit project setup uses supervisor exit checkpointing instead of a fenced checkpoint write at every superstep. Project service command receipts/template idempotency remain durable; a restart may repeat the tool call but not create another project. Plan-only and multi-step mapping work retain their checkpoint behavior.
- New read_mapping_definition(project_id, sttm_id) reads saved SQL without a migration plan. It checks the mapping belongs to the requested caller-visible project's mapping list, uses the existing caller-bound project service and returns explicit status/provenance. Wrong-project references are denied. Oversized SQL is deferred atomically, never cut mid-expression. Reads are cached only within the operation, with no durable assumption that drafts remain unchanged.
- Supervisor instructions use this reader for formula/CTE follow-ups and distinguish an actual field expression from a reporting aggregation. The existing execute_read_only_sql tool executes bounded Snowflake SELECT/CTE queries on verified caller-accessible tables. It is not a simulated SQL response. It does not acquire arbitrary metadata DML access.
- App metadata writes continue through typed existing services, using their parameterized SQL, initiating caller, validation and durable receipts. No arbitrary INSERT/UPDATE tool is added: such SQL would bypass app ownership, revision handling, indexes and command recovery. The app metadata guide describes the actual stores and correct service routes.

## Native acceptance

One before/after project sample each: 135 seconds before, 117 after moving the outbox, 78 with exit checkpointing too. Final run: project 4001, two model calls, one project tool, no catalog/FIR research or migration plan. The final model-to-answer event gap fell from approximately 61 seconds to approximately 23 seconds. These are real local conversation API -> worker -> Snowflake tests, not browser click timing or an SPCS guarantee. Event phase intervals include persistence overhead and cannot isolate every SQL/network duration.

Actual same-chat follow-up: the agent remembered project 3101/STTM 5701, used the new reader, returned the actual saved expression (v.total_amount_cents / 100) and explained the conversion plus supporting joins. One supervisor tool submission, two model calls; domain metrics include the project/mapping service reads. The read tool itself took approximately 4.3 seconds between recorded start/completion, and no new migration preparation ran. Total wall time 134 seconds includes the deliberate worker-restart queue gap; recorded active usage was 44 seconds. Do not present that queue gap as query execution time. The old synthetic precedent is historical evidence, not certification of current workbook parity.

Regression evidence: 144 final affected tests pass; an earlier overlapping saved-reader/outbox suite passed 100 tests. Coverage includes wrong-project denial, complete/multibyte SQL deferral, caller identity, idempotent project setup, Plan-mode protection, short-only checkpoint policy, and an outbox failure after a durable successful answer. No source/target data DML or publishing occurred.

## Install and remaining limits

Extract files/ over the repository root; preserve all environment files/secrets. Build and deploy matching frontend, API and Deep-worker images. No new table, variable, grant, Snowflake agent-spec or capacity increase. Normal bootstrap and V13's existing Deep timeout guidance still apply. No CodeCommit push or SPCS deployment is claimed.

The finalization interval is reduced, not eliminated. The approximately 23-second remaining interval needs finer checkpoint/session/trace telemetry before attributing all of it to one statement. Only one final short-project sample was measured. Standalone CTE/join/selected-row write capabilities documented as unfinished in V14 remain unfinished. These fixes do not claim the full migration timing gate passed.

Local conversations:
http://localhost:3000/ai-agent?conversation=conv_318f6ff7cc1551d359746748cb006ad5
http://localhost:3000/ai-agent?conversation=conv_7cde351e8910b6a78c29b77aaab06784
