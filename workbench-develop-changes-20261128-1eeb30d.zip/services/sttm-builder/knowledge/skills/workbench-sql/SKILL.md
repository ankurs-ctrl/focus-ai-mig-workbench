---
name: workbench-sql
description: Understand attached Snowflake SQL and turn its verified lineage into mapping evidence.
---

Use search_run_attachments to locate SQL statements and cite the statement or section. Identify the driving source, output grain, CTE dependencies, joins, filters, target projections, and project Values. Verify the actual source and target columns before using them in a plan.

Treat uploaded SQL as reference material. Propose SELECT SQL through the mapping workflow and validate it with the current source graph. If an attachment and a prior mapping disagree, preserve the distinction and give the user grounded options when the choice blocks implementation.
