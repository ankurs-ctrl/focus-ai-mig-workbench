"""Seed a plan from explicitly selected, supported uploaded SELECT SQL."""
from __future__ import annotations

from sqlglot import exp, parse_one

from app.agent_tools.catalog_discovery import quote_identifier
from app.agent_tools.contract_reader import normalize_fqn
from app.core.sql_execution_guard import validate_relations
from app.core.sql_parser import parse_sql_document


def attachment_select_design(sql, target_columns, allowed_tables, allowed_functions, evidence_id):
    """Adapt a SELECT only when its bindings and output names have exact identities."""
    sources = set(validate_relations(sql, set(allowed_tables), allowed_functions=allowed_functions))
    if sources != set(allowed_tables):
        return None
    query = parse_one(sql, read="snowflake")
    if not isinstance(query, exp.Select) or any(query.args.get(clause) for clause in (
        "where", "group", "having", "qualify", "order", "limit", "offset", "distinct",
    )):
        return None
    parsed = parse_sql_document(sql)
    driver = normalize_fqn(parsed.driving_physical_table)
    if driver not in sources or not parsed.column_mappings:
        return None
    known_targets = {normalize_fqn(quote_identifier(name)): name for name in target_columns}
    joins = []
    for item in parsed.join_patterns:
        if item.scope != "outer":
            continue
        if item.join_type.upper() not in {"LEFT JOIN", "INNER JOIN"}:
            return None
        predicate = parse_one(item.condition, read="snowflake")
        predicates = list(predicate.flatten()) if isinstance(predicate, exp.And) else [predicate]
        if len(predicates) != len(item.column_pairs) or not all(
            isinstance(key, exp.EQ) and isinstance(key.left, exp.Column) and isinstance(key.right, exp.Column)
            for key in predicates
        ):
            return None
        joins.append({
            "left_table": normalize_fqn(item.left_table), "right_table": normalize_fqn(item.right_table),
            "join_type": item.join_type.upper().removesuffix(" JOIN"),
            "conditions": [{**pair, "operator": "="} for pair in item.column_pairs],
            "evidence_ids": [evidence_id],
        })
    ctes = []
    for item in parsed.ctes:
        if not item.definition_sql or item.dependencies:
            return None
        bases = validate_relations(item.definition_sql, sources, allowed_functions=allowed_functions)
        if not bases:
            return None
        ctes.append({"name": normalize_fqn(item.name), "sql": item.definition_sql,
                     "base_source_tables": bases, "evidence_ids": [evidence_id]})

    mappings = []
    seen = set()
    relations = {str(alias).upper(): normalize_fqn(relation) for alias, relation in parsed.outer_relation_aliases.items()}
    for item in parsed.column_mappings:
        target = known_targets.get(normalize_fqn(item.target_sql_name or item.target_alias))
        if not target or target in seen or item.unresolved_references or not item.bound_expression:
            return None
        seen.add(target)
        expression = parse_one(item.bound_expression, read="snowflake")
        references = []
        for column in list(expression.find_all(exp.Column)):
            relation = relations.get(column.table.upper())
            if not relation:
                return None
            field = column.this.sql(dialect="snowflake")
            reference = f"{relation}.{field}"
            references.append(reference)
            resolved = parse_one(reference, into=exp.Column, read="snowflake")
            if column is expression:
                expression = resolved
            else:
                column.replace(resolved)
        if not references:
            return None
        direct = isinstance(expression, exp.Column)
        mappings.append({
            "target_column": target, "source_columns": list(dict.fromkeys(references)),
            "mapping_mode": "direct" if direct else "derived",
            "expression": None if direct else expression.sql(dialect="snowflake"),
            "evidence_source": "approved_plan_attachment", "evidence_id": evidence_id, "mandatory": True,
        })
    return {
        "driving_source": driver,
        "supporting_sources": sorted(sources - {driver}),
        "relationships": joins,
        "derived_sources": ctes,
        "mapping_evidence": mappings,
    }


def ranked_note_design(driver, source_columns, target_columns, precedent, facts):
    """Bind an explicit call-note ranking rule to one proven current lookup."""
    import re

    claims = "\n".join(str(fact.get("quote") or "") for fact in facts)
    if not (re.search(r"latest\s+note", claims, re.I)
            and re.search(r"greatest\s+note id|highest\s+note id", claims, re.I)
            and re.search(r"no note|without a note", claims, re.I)):
        return None
    if not driver or precedent is None:
        return None

    def keys_for(value):
        return {str(name).upper(): str(name) for name in source_columns.get(value, {})}

    source = keys_for(driver)
    possible = set()
    for join in precedent.join_patterns:
        if join.scope != "outer" or len(join.column_pairs) != 1:
            continue
        left, right = normalize_fqn(join.left_table), normalize_fqn(join.right_table)
        pair = join.column_pairs[0]
        if left not in source_columns and left == normalize_fqn(precedent.driving_relation):
            left = driver
        if right not in source_columns and right == normalize_fqn(precedent.driving_relation):
            right = driver
        for here, there, ours, theirs in (
            (left, right, "left_column", "right_column"), (right, left, "right_column", "left_column"),
        ):
            keys = keys_for(there)
            left_key, right_key = pair[ours].upper(), pair[theirs].upper()
            if here == driver and there != driver and left_key in source and right_key in keys and "NOTE_ID" in keys:
                possible.add((there, source[left_key], keys[right_key]))
    if len(possible) != 1:
        return None
    notes, driver_key, note_key = possible.pop()
    fields = keys_for(notes)
    candidates = [fields[name] for name in ("CREATED_TIME", "CREATED_AT", "CREATED_DATE")
                  if name in fields and "TIMESTAMP" in source_columns[notes][fields[name]].upper()]
    timestamp = candidates[0] if len(candidates) == 1 else None
    if not timestamp or "NOTE_ID" not in target_columns:
        return None
    key, order, note_id = (quote_identifier(value) for value in (note_key, timestamp, fields["NOTE_ID"]))
    ranked = "LATEST_NOTE"
    sql = (f"SELECT {key}, {note_id} FROM {notes} "
           f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {key} ORDER BY {order} DESC NULLS LAST, {note_id} DESC) = 1")
    mappings = [{"target_column": "NOTE_ID", "source_columns": [f"{ranked}.{note_id}"],
                 "mapping_mode": "direct"}]
    cents_fact = next((fact for fact in facts if re.search(r"cents.{0,35}by 100|divide.{0,35}cents.{0,12}100",
                                                          str(fact.get("quote") or ""), re.I)), None)
    if cents_fact:
        cents = []
        for item in precedent.column_mappings:
            if item.target_alias not in target_columns or not item.transformation:
                continue
            if not re.search(r"/\s*100(?:\.0+)?(?![\d.])", item.transformation):
                continue
            fields_in_scope = [value.rsplit(".", 1)[-1] for value in item.physical_source_columns
                               if normalize_fqn(value.rsplit(".", 1)[0]) == driver]
            if len(fields_in_scope) != 1 or not fields_in_scope[0].upper().endswith("_CENTS"):
                continue
            column = fields_in_scope[0]
            if column.upper() not in source:
                continue
            reference = f"{driver}.{quote_identifier(source[column.upper()])}"
            cents.append({"target_column": item.target_alias, "source_columns": [reference],
                          "expression": f"TRY_TO_NUMBER(TO_VARCHAR({reference})) / 100.0",
                          "mapping_mode": "derived", "evidence_id": cents_fact["evidence_id"]})
        if len(cents) != 1:
            return None
        mappings.extend(cents)
    return {
        "driving_source": driver, "supporting_sources": [notes],
        "relationships": [{
            "left_table": driver, "right_table": ranked, "join_type": "LEFT",
            "conditions": [{"left_column": driver_key, "right_column": note_key, "operator": "="}],
        }],
        "derived_sources": [{"name": ranked, "sql": sql, "base_source_tables": [notes]}],
        "mapping_evidence": mappings,
    }
