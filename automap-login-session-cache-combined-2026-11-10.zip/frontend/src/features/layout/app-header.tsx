"use client";
import { AiaAvatar, AiaBox, AiaButton, AiaIconButton, AiaMenu, AiaMenuItem, AiaSwitch, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useStore } from 'react-redux';
import type { RootState } from '@/store/store';
import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import {
  KeyboardArrowDownRoundedIcon,
  LogoutRoundedIcon,
  SettingsOutlinedIcon,
} from '@/utils/icons';

// import { useThemeMode } from "@/app/Providers";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { authService, getStoredDisplayName } from "@/services/authService";
import type { UserSession } from "@/types/user";
import { CLIENT_CONFIG as config } from "@/config/client.config";
import { SUBTITLE_SX } from "@/config/typography-tokens";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { resolveBuilderSelectionState } from "@/features/sttm/shared/sttm-selection-utils";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import BuilderContentHeader, {
  builderHeaderActionButtonSx,
  builderHeaderActionStrokeColor,
} from "@/features/sttm/layout/builder-content-header";
import PublishMappingModal from "@/features/sttm/summary/publish-mapping-modal";
import PublishSuccessDialog from "@/features/sttm/summary/publish-success-dialog";
import { buildSummaryMetrics } from "@/features/sttm/summary/summary-utils";
import {
  evaluateFirRecommendations,
  setPublishedMappingIdentity,
  updateAssistantPreferences as updateAssistantPreferencesThunk,
} from "@/features/sttm/store/sttm-builder-slice";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";
import { useTour } from "@/features/tour/engine";
import type { PublishMappingPayload } from "@/features/sttm/summary/publish-mapping-modal";
import type { PublishProjectItem } from "@/features/sttm/summary/publish-mapping-data";
import {
  createProject,
  createProjectSttm,
  getSttm,
  getPostSaveJobStatus,
  listProjects,
  invalidateProjectSummaries,
  publishSttm,
  type ProjectRecord,
} from "@/services/projectService";
import {
  buildWorkbenchContextSnapshot,
  tableRefFromQualifiedName,
} from "@/features/sttm/context/workbench-context";
import { buildCompilerRelationGraph } from '@/features/sttm/mapping/mapping-utils';
import { refreshAllWorkbenchData } from "@/services/workbenchCacheService";
import { OPEN_MAPPING_TAB_STORAGE_KEY } from "@/features/sttm/shared/mapping-validation";
import { useMappingValidationStatus } from "@/features/sttm/shared/use-mapping-validation-status";
import { SttmNoticeDialog } from "@/features/sttm/shared/sttm-notice-dialog";

type AppHeaderProps = {
  userName?: string;
  role?: string;
};

function projectRecordToPublishOption(project: ProjectRecord): PublishProjectItem {
  const metadata = project.metadata ?? {};
  const folderColor =
    typeof metadata.theme_color === "string"
      ? metadata.theme_color
      : typeof metadata.theme_color_id === "string"
        ? metadata.theme_color_id
        : "#2563EB";

  return {
    id: project.project_id,
    name: project.project_name,
    mappingCount: project.sttm_count || project.total_mappings || 0,
    folderColor,
    folderBg: "rgba(37, 99, 235, 0.12)",
  };
}

type BuilderRouteState = {
  basePath: string;
  isBuilder: boolean;
  isMapping: boolean;
  isSummary: boolean;
};

function publicationSignature(snapshot: Record<string, unknown> | null | undefined): string {
  if (!snapshot) return "";
  const rows = Array.isArray(snapshot.mapping_rows) ? snapshot.mapping_rows : [];
  const derived = Array.isArray(snapshot.derived_sources) ? snapshot.derived_sources : [];
  const content = {
    source_tables: snapshot.source_tables,
    target_table: snapshot.target_table,
    derived_sources: derived.map((item) => {
      const source = item as Record<string, unknown>;
      return { id: source.id, name: source.name, sql_text: source.sql_text };
    }),
    relationships: snapshot.relationships,
    filters: snapshot.filters,
    mapping_rows: rows.map((item) => {
      const row = item as Record<string, unknown>;
      return {
        target_column: row.target_column,
        source_columns: row.source_columns,
        mapping_mode: row.mapping_mode,
        constant_value: row.constant_value,
        attribute_name: row.attribute_name,
        expression: row.expression,
        rule: row.rule,
        status: row.status,
      };
    }),
    mapping_sql: snapshot.mapping_sql || "",
    mapping_preview_sql: snapshot.mapping_preview_sql || "",
    mapping_sql_variant: snapshot.mapping_sql_variant || "original",
  };
  return JSON.stringify(content);
}

function publishedSnapshotFromVersion(version: Record<string, unknown> | undefined): Record<string, unknown> | null {
  const raw = version?.VERSION_PAYLOAD ?? version?.version_payload;
  if (raw && typeof raw === "object") return raw as Record<string, unknown>;
  if (typeof raw === "string") {
    try { return JSON.parse(raw) as Record<string, unknown>; } catch { return null; }
  }
  return null;
}

function resolveBuilderRoute(pathname: string, activeSttmId?: string | null): BuilderRouteState {
  const normalizedPath = pathname.replace(/\/+$/, "") || "/";
  const match = normalizedPath.match(
    /^\/sttm\/builder\/([^/]+)(?:\/(mapping|validate|summary))?$/,
  );

  if (!match) {
    return {
      basePath: "/sttm/builder/new",
      isBuilder: false,
      isMapping: false,
      isSummary: false,
    };
  }

  const routeIdentity = match[1];
  const routeStep = match[2];
  const durableRoutesEnabled = process.env.NEXT_PUBLIC_DURABLE_STTM_ROUTE_V1 !== "false";
  const resolvedIdentity =
    routeIdentity !== "new"
      ? routeIdentity
      : durableRoutesEnabled && activeSttmId
        ? encodeURIComponent(activeSttmId)
        : "new";

  return {
    basePath: `/sttm/builder/${resolvedIdentity}`,
    isBuilder: true,
    isMapping: routeStep === "mapping" || routeStep === "validate",
    isSummary: routeStep === "summary",
  };
}

export default function AppHeader({
  role = "Publisher",
}: AppHeaderProps) {
  const { sourcePreviewGate } = useSttmBuilderContext();
  // const { mode, toggleMode } = useThemeMode();
  const [session, setSession] = useState<UserSession | null>(null);
  const [storedDisplayName, setStoredDisplayName] = useState<string | null>(null);
  const [menuAnchorEl, setMenuAnchorEl] = useState<HTMLElement | null>(null);
  const [settingsAnchorEl, setSettingsAnchorEl] = useState<HTMLElement | null>(null);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [publishProjectOptions, setPublishProjectOptions] = useState<PublishProjectItem[]>([]);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publicationLearning, setPublicationLearning] = useState<{
    sttmId: string; jobId: string; status: string;
  } | null>(null);
  useEffect(() => {
    if (!publicationLearning || ["completed", "failed"].includes(publicationLearning.status)) return;
    let cancelled = false;
    const timer = window.setInterval(() => {
      void getPostSaveJobStatus(publicationLearning.sttmId, publicationLearning.jobId).then(job => {
        if (!cancelled) setPublicationLearning(current => current?.jobId === job.job_id
          ? { ...current, status: job.status } : current);
      }).catch(() => {
        if (!cancelled) setPublicationLearning(current => current ? { ...current, status: "unavailable" } : current);
      });
    }, 3000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [publicationLearning]);
  // Mapping (and project) just published; non-null shows the success popup.
  const [publishedSuccess, setPublishedSuccess] = useState<{ mappingName: string; projectName: string | null } | null>(null);
  const [publishedMapping, setPublishedMapping] = useState<{
    name: string; description: string; version: number; snapshot: Record<string, unknown> | null; loading: boolean; error?: string;
  } | null>(null);
  const pathname = usePathname();
  const router = useRouter();
  const dispatch = useAppDispatch();
  const store = useStore<RootState>();
  const tour = useTour();
  const {
    sources,
    targets,
    mappings,
    derivedSources,
    relationships,
    sourceDatabases,
    targetDatabases,
    assistantPreferences,
    semanticBundleId,
    semanticViewName,
    semanticBundleLabel,
    semanticLevel,
    semanticStatus,
    sourceAttributeGroups,
    drivingTableId,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    selectedMappingIds,
    activeMappingId,
    mappingSql,
    authoredSqlSemanticKey,
    unresolvedSourceTables,
    mappingPreviewSql,
    mappingSqlVariant,
    compiledMappingSql,
    compiledMappingScriptSql,
    compiledMappingReady,
    compiledMappingPreviewSql,
    compiledMappingContextHash,
    mappingIntent,
    activeProjectName,
    activeProjectId,
    activeSttmId,
    activeSttmName,
    activeSttmDescription,
    sqlValidatedSignature,
    sourceQueryModifiers,
    semanticContextItems,
    validationValuesSignature,
  } = useAppSelector((state) => state.sttmBuilder);
  const { isValidated: isMappingSqlValidated, isCurrent: isCurrentValidation } = useMappingValidationStatus();
  const [publishBlockedOpen, setPublishBlockedOpen] = useState(false);
  const builderRoute = resolveBuilderRoute(pathname, activeSttmId);
  const { resolvedSourceTables, selectedTargetTable, canProceedToMapping } =
    resolveBuilderSelectionState({
      sourceDatabases,
      targetDatabases,
      sources,
      targets,
      derivedSources,
    });

  useEffect(() => {
    setStoredDisplayName(getStoredDisplayName());

    let cancelled = false;

    authService
      .getSession()
      .then((response) => {
        if (!cancelled) {
          setSession(response);
          setStoredDisplayName(getStoredDisplayName());
        }
      })
      .catch(() => {
        if (!cancelled) {
          setSession(null);
          // Keep any previously stored display name until logout clears it.
          setStoredDisplayName(getStoredDisplayName());
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!isPublishModalOpen) {
      return;
    }

    let cancelled = false;
    listProjects()
      .then((projects) => {
        if (!cancelled) {
          setPublishProjectOptions(projects.map(projectRecordToPublishOption));
        }
      })
      .catch((error) => {
        if (!cancelled) {
          setPublishProjectOptions([]);
        }
        if (process.env.NODE_ENV === "development") {
          console.warn("Project options unavailable; publish target list is empty until backend recovers.", error);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [isPublishModalOpen]);

  useEffect(() => {
    if (!isPublishModalOpen || !activeSttmId) {
      setPublishedMapping(null);
      return;
    }
    let cancelled = false;
    setPublishedMapping({ name: activeSttmName || "Mapping", description: "", version: 0, snapshot: null, loading: true });
    void getSttm(activeSttmId, { includeHistory: true }).then((detail) => {
      if (cancelled) return;
      const version = detail.versions.find((item) =>
        Number(item.VERSION_NUMBER ?? item.version_number) === detail.sttm.current_version);
      const snapshot = publishedSnapshotFromVersion(version);
      setPublishedMapping({
        name: detail.sttm.sttm_name || activeSttmName || "Mapping",
        description: detail.sttm.description || "",
        version: detail.sttm.current_version,
        snapshot,
        loading: false,
        error: detail.sttm.current_version > 0 && !snapshot
          ? "The published version could not be loaded. Please reopen the mapping and try again."
          : undefined,
      });
    }).catch((error) => {
      console.error("Unable to read the published mapping version", error);
      if (!cancelled) setPublishedMapping({ name: activeSttmName || "Mapping", description: "", version: 0, snapshot: null, loading: false, error: "The published version could not be loaded. Please try again." });
    });
    return () => { cancelled = true; };
  }, [isPublishModalOpen, activeSttmId, activeSttmName]);

  const resolvedUserName =
    session?.display_name?.trim() ||
    storedDisplayName ||
    session?.email ||
    "";
  const canShowUserMenu = Boolean(resolvedUserName);
  const resolvedRole = session?.app_persona
    ? `${session.app_persona.charAt(0)}${session.app_persona.slice(1).toLowerCase()}`
    : role;

  const initials = resolvedUserName
    .split(" ")
    .map((item) => item[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const isMappingPage = builderRoute.isMapping;
  const isSummaryPage = builderRoute.isSummary;
  const currentAssistantPage: "builder" | "mapping" | "summary" = isSummaryPage
    ? "summary"
    : isMappingPage
      ? "mapping"
      : "builder";
  const currentAssistantSurface: "SOURCE_SELECTION" | "MAPPING" =
    currentAssistantPage === "mapping" ? "MAPPING" : "SOURCE_SELECTION";
  const isSttmBuilderHeader = builderRoute.isBuilder;
  const currentStep: 1 | 2 | 3 = isSummaryPage ? 3 : isMappingPage ? 2 : 1;
  const sourceTableCount =
    resolvedSourceTables.length +
    derivedSources.filter((source) => source.isSelected).length;
  const joinCount = relationships.filter(
    (join) => join.leftTableId && join.rightTableId && (join.conditions?.length || join.sqlPredicate),
  ).length;
  const tableCount = sourceTableCount + (selectedTargetTable ? 1 : 0);
  const mappedCount = mappings.filter((mapping) => mapping.status === "MAPPED").length;
  const publishMetrics = useMemo(
    () =>
      buildSummaryMetrics({
        mappings,
        sources: resolvedSourceTables,
        joinCount,
      }),
    [joinCount, mappings, resolvedSourceTables],
  );
  const defaultMappingName =
    activeSttmName?.trim()
    || selectedTargetTable?.tableName?.toUpperCase()
    || "Untitled Mapping";
  const defaultMappingDescription = activeSttmDescription?.trim() || "";
  const defaultPublishProjectId = activeProjectId;
  const currentPublicationSnapshot = buildWorkbenchContextSnapshot({
    action: "sttm.published",
    page: "summary",
    surface: "MAPPING",
    sourceTables: resolvedSourceTables,
    targetTable: selectedTargetTable,
    drivingTableId,
    derivedSources,
    relationships,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    mappings,
    mappingSql,
    mappingPreviewSql,
    mappingSqlVariant,
  });
  const publishedContentUnchanged = Boolean(
    publishedMapping?.snapshot
    && publicationSignature(currentPublicationSnapshot as unknown as Record<string, unknown>)
      === publicationSignature(publishedMapping.snapshot),
  );
  const requestProceedToMapping = () => {
    if (!canProceedToMapping || !sourcePreviewGate.validated || !sourcePreviewGate.synced || isMappingPage || isSummaryPage) {
      return;
    }
    window.dispatchEvent(new CustomEvent("sttm:proceed-to-mapping"));
  };

  const requestProceedToSummary = () => {
    if (!canProceedToMapping || isSummaryPage) {
      return;
    }
    window.dispatchEvent(new CustomEvent("sttm:proceed-to-summary"));
  };

  const requestStepNavigation = (step: number) => {
    window.dispatchEvent(new CustomEvent("sttm:navigate-step", { detail: { step } }));
  };

  const handleOpenAssistantSettings = () => {
    const anchor = menuAnchorEl;
    setMenuAnchorEl(null);
    setSettingsAnchorEl(anchor);
  };

  const handleLogout = () => {
    setMenuAnchorEl(null);
    setSettingsAnchorEl(null);
    authService.logout();
  };

  const handlePublishMapping = async (payload: PublishMappingPayload) => {
    if (isPublishing) {
      return;
    }

    if (!isCurrentValidation(store.getState().sttmBuilder)) {
      setPublishBlockedOpen(true);
      return;
    }
    const submissionSignature = store.getState().sttmBuilder.sqlValidatedSignature;
    const assertCurrentSubmission = () => {
      const current = store.getState().sttmBuilder;
      if (!isCurrentValidation(current) || current.sqlValidatedSignature !== submissionSignature) {
        throw new Error("The mapping or SQL changed. Save pending edits and validate again before publishing.");
      }
    };
    setIsPublishing(true);
    try {
      let projectId = payload.publishMode === "version" && activeSttmId
        ? activeProjectId
        : payload.projectId;

      if (activeSttmId && (publishedMapping?.loading || publishedMapping?.error)) {
        throw new Error(publishedMapping?.error || "The published mapping is still loading. Please try again.");
      }
      if (activeSttmId && publishedContentUnchanged) {
        setIsPublishModalOpen(false);
        return;
      }

      if (payload.publishMode !== "version" && (payload.saveTab === "new" || !projectId)) {
        const projectName =
          payload.saveTab === "new"
            ? payload.projectName || `${payload.mappingName} Project`
            : "Unassigned STTMs";
        const existingProject = publishProjectOptions.find(
          (project) => project.name.toLowerCase() === projectName.toLowerCase(),
        );
        if (existingProject) {
          projectId = existingProject.id;
        } else {
          const createdProject = await createProject({
            project_name: projectName,
            description:
              payload.saveTab === "new"
                ? payload.projectDescription || `Project created while publishing ${payload.mappingName}.`
                : "Mappings saved without an explicit project selection.",
            theme_color_id: "blue",
            domain: payload.projectDomain,
            intended_outcome: payload.projectOutcome,
            business_process: payload.projectBusinessProcess,
            owner: payload.projectOwner,
          });
          projectId = createdProject.project_id;
          setPublishProjectOptions((items) => [
            projectRecordToPublishOption(createdProject),
            ...items,
          ]);
        }
      }

      if (!projectId) {
        throw new Error("A project is required before publishing the mapping.");
      }

      const targetTableRef = tableRefFromQualifiedName(selectedTargetTable?.qualifiedName);
      const mappingDescription = payload.mappingDescription.trim()
        || (payload.publishMode === "version" ? publishedMapping?.description || "" : "");
      const snapshotInput = {
        page: currentAssistantPage,
        surface: currentAssistantSurface,
        sessionId: session ? String(session.user_id) : null,
        projectId,
        projectName: payload.projectName || activeProjectName,
        projectDescription: payload.projectDescription,
        projectDomain: payload.projectDomain,
        projectOutcome: payload.projectOutcome,
        sttmName: payload.mappingName,
        sttmDescription: mappingDescription,
        mappingLifecycle: mappingIntent?.lifecycle ?? "new",
        businessGoal:
          mappingDescription
          || mappingIntent?.business_goal
          || mappingIntent?.target_outcome
          || null,
        sourceTables: resolvedSourceTables,
        targetTable: selectedTargetTable,
        drivingTableId,
        sourceAttributeGroups,
        derivedSources,
        relationships,
        sourceFilterSql,
        sourceFilterGroups,
        sourceQuerySql,
        sourceGroupBySql,
        sourceOrderBySql,
        sourceQueryModifiers,
        semanticContextItems,
        validationValuesSignature,
        mappings,
        selectedMappingIds,
        activeMappingId,
        mappingSql,
        authoredSqlSemanticKey,
        unresolvedSourceTables,
        mappingPreviewSql,
        mappingSqlVariant,
        compiledMappingSql,
        compiledMappingScriptSql,
        compiledMappingReady,
        compiledMappingPreviewSql,
        compiledMappingContextHash,
        sqlValidatedSignature,
        mappingIntent,
        semanticBundleId,
        semanticBundleLabel,
        semanticLevel,
        semanticStatus,
        semanticViewName,
      };
      const createSnapshot = buildWorkbenchContextSnapshot({
        ...snapshotInput,
        action: "mapping.created",
      });

      assertCurrentSubmission();
      const sttmId = payload.publishMode === "version" && activeSttmId
        ? activeSttmId
        : (await createProjectSttm(projectId, {
            sttm_name: payload.mappingName,
            description: mappingDescription,
            target_table: targetTableRef,
            workspace_snapshot: createSnapshot,
            semantic_bundle_id: semanticBundleId,
            metadata: {
              source: "ui_publish_modal",
              semantic_view_name: semanticViewName,
            },
          })).sttm_id;

      const publicationGraph = buildCompilerRelationGraph({
        semanticContext: semanticContextItems,
        sourceTables: resolvedSourceTables.map(table => ({...tableRefFromQualifiedName(table.qualifiedName)!,
          relation_id: table.tableId.startsWith('sql-instance:') ? table.tableId : table.qualifiedName})),
        sourceColumnsByTable: Object.fromEntries(sourceAttributeGroups.map(group => [group.qualifiedName, group.columns])),
        derivedSources, relationships, mappings, queryModifiers: sourceQueryModifiers,
      });
      const publishSnapshot = buildWorkbenchContextSnapshot({
        ...snapshotInput,
        action: "sttm.published",
        milestone: "before_publish",
        sttmId,
      });

      publishSnapshot.relation_graph = publicationGraph;
      assertCurrentSubmission();
      const publishResult = await publishSttm(sttmId, {
        revision_note: "Published from AIA Migration Workbench UI.",
        workspace_snapshot: publishSnapshot,
        semantic_bundle_id: semanticBundleId,
        metadata: {
          source: "ui_publish_modal",
          semantic_view_name: semanticViewName,
        },
      });

      if (publishResult.learning_job_id) {
        setPublicationLearning({ sttmId, jobId: String(publishResult.learning_job_id),
          status: String(publishResult.learning_status ?? "queued") });
      }
      dispatch(setPublishedMappingIdentity({
        projectId,
        sttmId,
        sttmName: payload.mappingName,
        projectName: payload.projectName || activeProjectName || null,
        snapshotId: String(publishResult.snapshot_id ?? "") || null,
      }));
      setIsPublishModalOpen(false);
      // Confirm success; its OK button continues to the Mappings list.
      setPublishedSuccess({
        mappingName: payload.mappingName,
        projectName: payload.projectName || activeProjectName || null,
      });

      void dispatch(
        evaluateFirRecommendations({
          checkpoint: "sttm_published",
          page: "summary",
          surface: "MAPPING",
          scopeType: "mapping",
          candidateAction: "review_published_mapping",
        }),
      );

    } catch (error) {
      console.error("Publish mapping failed", error);
      window.alert(error instanceof Error ? error.message : "Failed to publish mapping.");
    } finally {
      setIsPublishing(false);
    }
  };

  const menuOpen = Boolean(menuAnchorEl);
  const settingsOpen = Boolean(settingsAnchorEl);

  return (
    <AiaBox
      className="flex w-full shrink-0 items-center justify-between px-5"
      sx={{
        height: "var(--aia-header-height)",
        minHeight: "var(--aia-header-height)",
        backgroundColor: "var(--aia-header-bgColor)",
        borderBottom: "1px solid var(--aia-border-color)",
        color: "var(--color-header-text)",
      }}
    >
      <AiaBox className="flex shrink-0 items-center gap-3">
        <AiaBox className="flex h-15 w-15 items-center justify-center overflow-hidden rounded-sm ">
          <Link href="/dashboard">
            <Image
              src={config.branding.logo.light}
              alt="STTM Builder Logo"
              width={50}
              height={50}
              className="object-contain"
            />
          </Link>
        </AiaBox>

        <AiaText
          sx={{
            ...SUBTITLE_SX,
            color: "inherit",
            display: "flex",
            alignItems: "center",
          }}
        >
          AIA Migration Workbench
        </AiaText>
      </AiaBox>

      {isSttmBuilderHeader ? (
        <AiaBox sx={{ mx: 4, flex: 1, minWidth: 0 }}>
          <BuilderContentHeader
            embedded
            currentStep={currentStep}
            sourceTableCount={sourceTableCount}
            joinCount={joinCount}
            tableCount={tableCount}
            mappingCount={mappedCount}
            onNext={() => {
              if (currentStep === 1) {
                requestProceedToMapping();
                return;
              }
              if (currentStep === 2) {
                requestProceedToSummary();
              }
            }}
            onPublish={() => {
              // Publishing requires a successful Compile & Validate of the current
              // workspace; any edit since the last success requires a new run.
              if (!isMappingSqlValidated) {
                setPublishBlockedOpen(true);
                return;
              }
              setIsPublishModalOpen(true);
              void dispatch(
                evaluateFirRecommendations({
                  checkpoint: "before_publish",
                  page: "summary",
                  surface: "MAPPING",
                  scopeType: "mapping",
                  candidateAction: "publish_mapping",
                }),
              );
            }}
            onStepChange={(step) => {
              if (step === 1) {
                // Backward move (2 -> 1 or 3 -> 1): same blocking transition as
                // forward moves, so the wizard behaves consistently either way.
                requestStepNavigation(1);
                return;
              }
              if (step === 2) {
                if (isMappingPage) {
                  return;
                }
                if (isSummaryPage) {
                  requestStepNavigation(2);
                  return;
                }
                requestProceedToMapping();
                return;
              }
              if (!canProceedToMapping) {
                return;
              }
              requestProceedToSummary();
            }}
            nextDisabled={currentStep === 1 ? !canProceedToMapping || !sourcePreviewGate.validated || !sourcePreviewGate.synced : false}
          />
        </AiaBox>
      ) : null}

      <AiaBox className="flex shrink-0 items-center gap-3">
        {/* Theme toggle — hidden for now
        <AiaTooltip title={mode === "light" ? "Switch to dark mode" : "Switch to light mode"}>
          <AiaIconButton
            onClick={toggleMode}
            aria-label="Toggle light and dark theme"
            sx={{
              width: 32,
              height: 32,
              borderRadius: "4px",
              color: "inherit",
              border: "1px solid rgba(255,255,255,0.28)",
              "&:hover": {
                backgroundColor: "rgba(255,255,255,0.08)",
              },
            }}
          >
            {mode === "light" ? (
              <DarkModeRoundedIcon sx={{ fontSize: 18 }} />
            ) : (
              <LightModeRoundedIcon sx={{ fontSize: 18 }} />
            )}
          </AiaIconButton>
        </AiaTooltip>
        */}

        <AiaTooltip title="Refresh all Workbench data">
          <AiaIconButton
            aria-label="Refresh all Workbench data"
            onClick={() => {
              refreshAllWorkbenchData();
              window.location.reload();
            }}
            sx={{
              width: 34,
              height: 34,
              borderRadius: "6px",
              color: "inherit",
              border: "1px solid rgba(255,255,255,0.28)",
              "&:hover": { backgroundColor: "rgba(255,255,255,0.08)" },
            }}
          >
            <RefreshRoundedIcon sx={{ fontSize: 19 }} />
          </AiaIconButton>
        </AiaTooltip>

        <AiaButton
          variant="outlined"
          rounded="sm"
          size="large"
          customColor={builderHeaderActionStrokeColor}
          onClick={() => tour.startTourForPath(pathname)}
          aria-label="Start tour guide"
          sx={builderHeaderActionButtonSx}
        >
          Tour Guide
        </AiaButton>

        {canShowUserMenu ? (
          <>
        <AiaBox
          role="button"
          onClick={(event) => setMenuAnchorEl(event.currentTarget)}
          data-tour={TOUR_TARGETS.userProfile}
          sx={{ display: "flex", alignItems: "center", gap: 1.25, cursor: "pointer" }}
        >
          <AiaAvatar
            sx={{
              width: 28,
              height: 28,
              bgcolor: "var(--aia-avatar-bg)",
              color: "var(--aia-avatar-textColor)",
              fontSize: 12,
              fontWeight: 700,
            }}
          >
            {initials}
          </AiaAvatar>

          <AiaBox className="leading-tight">
            <AiaText
              className="text-[12px] font-semibold"
              sx={{ fontFamily: "var(--font-body)" }}
            >
              {resolvedUserName}
            </AiaText>
            <AiaText
              className="text-[11px]/70"
              sx={{ fontFamily: "var(--font-body)" }}
            >
              {resolvedRole}
            </AiaText>
          </AiaBox>

          <KeyboardArrowDownRoundedIcon sx={{ fontSize: 18, color: "currentColor" }} />
        </AiaBox>

        <AiaMenu
          anchorEl={settingsAnchorEl}
          open={settingsOpen}
          onClose={() => setSettingsAnchorEl(null)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
          transformOrigin={{ vertical: "top", horizontal: "right" }}
        >
          <AiaBox sx={{ px: 2, pt: 1.5, pb: 1, minWidth: 320 }}>
            <AiaText sx={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
              AI assistant settings
            </AiaText>
            <AiaText sx={{ fontSize: 12, color: "#64748b", mt: 0.35 }}>
              Control whether live business feedback and recommendations appear while you work.
            </AiaText>
          </AiaBox>
          <AiaMenuItem disableRipple sx={{ minWidth: 320, alignItems: "stretch", py: 1.25 }}>
            <AiaBox sx={{ display: "flex", width: "100%", alignItems: "center", gap: 2 }}>
              <AiaBox sx={{ flex: 1, minWidth: 0 }}>
                <AiaText sx={{ fontSize: 13, fontWeight: 700 }}>Live feedback</AiaText>
                <AiaText sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.45 }}>
                  Ask business questions from table, join, and derived-source activity.
                </AiaText>
              </AiaBox>
              <AiaBox sx={{ display: "flex", alignItems: "center", minHeight: 40 }}>
                <AiaSwitch
                  checked={assistantPreferences.feedback_enabled}
                  onChange={(event) =>
                    dispatch(
                      updateAssistantPreferencesThunk({
                        ...assistantPreferences,
                        feedback_enabled: event.target.checked,
                      }),
                    )
                  }
                />
              </AiaBox>
            </AiaBox>
          </AiaMenuItem>
          <AiaMenuItem disableRipple sx={{ minWidth: 320, alignItems: "stretch", py: 1.25 }}>
            <AiaBox sx={{ display: "flex", width: "100%", alignItems: "center", gap: 2 }}>
              <AiaBox sx={{ flex: 1, minWidth: 0 }}>
                <AiaText sx={{ fontSize: 13, fontWeight: 700 }}>Live recommendations</AiaText>
                <AiaText sx={{ fontSize: 12, color: "#64748b", lineHeight: 1.45 }}>
                  Show proactive join, semantic, and mapping suggestions above the assistant.
                </AiaText>
              </AiaBox>
              <AiaBox sx={{ display: "flex", alignItems: "center", minHeight: 40 }}>
                <AiaSwitch
                  checked={assistantPreferences.recommendations_enabled}
                  onChange={(event) =>
                    dispatch(
                      updateAssistantPreferencesThunk({
                        ...assistantPreferences,
                        recommendations_enabled: event.target.checked,
                      }),
                    )
                  }
                />
              </AiaBox>
            </AiaBox>
          </AiaMenuItem>
        </AiaMenu>

        <AiaMenu
          anchorEl={menuAnchorEl}
          open={menuOpen}
          onClose={() => setMenuAnchorEl(null)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
          transformOrigin={{ vertical: "top", horizontal: "right" }}
        >
          {/* <AiaMenuItem disableRipple sx={{ cursor: "default", "&:hover": { backgroundColor: "transparent" } }}>
            {/* <AiaBox>
              <AiaText sx={{ fontSize: 13, fontWeight: 700 }}>{resolvedUserName}</AiaText>
              <AiaText sx={{ fontSize: 12, color: "#64748b" }}>{resolvedRole}</AiaText>
            </AiaBox> *
          </AiaMenuItem> */}
          {/* <AiaDivider /> */}
          <AiaMenuItem onClick={handleOpenAssistantSettings}>
            <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1.25 }}>
              <SettingsOutlinedIcon sx={{ fontSize: 18, color: "#64748b" }} />
              <AiaText sx={{ fontSize: 13, fontWeight: 600 }}>Assistant Settings</AiaText>
            </AiaBox>
          </AiaMenuItem>
          <AiaMenuItem onClick={handleLogout}>
            <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1.25 }}>
              <LogoutRoundedIcon sx={{ fontSize: 18, color: "#64748b" }} />
              <AiaText sx={{ fontSize: 13, fontWeight: 600 }}>Logout</AiaText>
            </AiaBox>
          </AiaMenuItem>
        </AiaMenu>
          </>
        ) : null}
      </AiaBox>

      {isPublishModalOpen && isSummaryPage && <PublishMappingModal
        open
        onClose={() => setIsPublishModalOpen(false)}
        defaultMappingName={defaultMappingName}
        defaultMappingDescription={defaultMappingDescription}
        defaultProjectId={defaultPublishProjectId}
        metrics={publishMetrics}
        projectOptions={publishProjectOptions}
        isPublishing={isPublishing}
        existingMapping={activeSttmId && publishedMapping ? {
          name: publishedMapping.name,
          description: publishedMapping.description,
          version: publishedMapping.version,
          unchanged: publishedContentUnchanged,
          loading: publishedMapping.loading,
          error: publishedMapping.error,
        } : null}
        onPublish={handlePublishMapping}
      />}
      {publicationLearning ? <AiaBox role="status" sx={{ position: "fixed", bottom: 16, right: 16,
        maxWidth: 360, p: 1.5, bgcolor: "background.paper", border: "1px solid", borderColor: "divider", borderRadius: 2, zIndex: 1300 }}>
        <AiaText sx={{ fontSize: 13 }}>
          {publicationLearning.status === "completed" ? "Mapping published. Learning processing complete."
            : publicationLearning.status === "failed" ? "Mapping published. Learning processing failed; recovery is required."
            : publicationLearning.status === "unavailable" ? "Mapping published. Learning status is temporarily unavailable."
            : "Mapping published. Learning processing is pending."}
        </AiaText>
        <AiaButton size="small" onClick={() => setPublicationLearning(null)}>Dismiss</AiaButton>
      </AiaBox> : null}
      <PublishSuccessDialog
        open={publishedSuccess !== null}
        mappingName={publishedSuccess?.mappingName ?? ""}
        projectName={publishedSuccess?.projectName ?? null}
        onStay={() => setPublishedSuccess(null)}
        onConfirm={() => {
          setPublishedSuccess(null);
          // Drop cached project/mapping lists so Mappings shows the new publication.
          invalidateProjectSummaries();
          router.push("/mappings");
        }}
      />
      <SttmNoticeDialog
        open={publishBlockedOpen}
        title="Compile & Validate required"
        message={
          sqlValidatedSignature
            ? "This mapping has changed since its SQL was last validated. Go to Map · Transform · Validate → SQL tab and run Compile & Validate again. You can publish once validation succeeds."
            : "The SQL for this mapping has not been validated yet. Go to Map · Transform · Validate → SQL tab and run Compile & Validate. You can publish once validation succeeds."
        }
        actionLabel="Go to SQL tab"
        onAction={() => {
          setPublishBlockedOpen(false);
          try {
            window.sessionStorage.setItem(OPEN_MAPPING_TAB_STORAGE_KEY, "sql-preview");
          } catch {
            // Storage can be unavailable; the step navigation still works.
          }
          requestStepNavigation(2);
        }}
        onClose={() => setPublishBlockedOpen(false)}
      />
    </AiaBox>
  );
}
