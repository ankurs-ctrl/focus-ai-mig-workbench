"""Shared Snowflake slot leases for specialist work across SPCS replicas.

Slots are provisioned by deployment, never invented by an agent. A request must
claim one slot in every scope (account/tenant/role/project) before dispatch.
"""
from __future__ import annotations
from contextlib import contextmanager
import threading
import time
from uuid import uuid4

class CapacityUnavailable(RuntimeError):
    error_code='capacity_unavailable'

class CapacityLeasePool:
    def __init__(self, *, client_factory, table: str, scopes: list[str], lease_seconds: int = 120,
                 wait_seconds: int = 30, check_active=lambda:None, scope_limits=None,
                 provision_procedure: str | None = None, scope_values=None):
        self.client_factory=client_factory
        self.table=table
        self.scopes=sorted(set(scopes))
        self.lease_seconds=lease_seconds
        self.wait_seconds=wait_seconds
        self.check_active=check_active
        self.scope_limits = dict(scope_limits or {})
        self.provision_procedure = provision_procedure
        self.scope_values = dict(scope_values or {})
        self._provisioned = set()
        self._provision_lock = threading.Lock()

    def resolved_scopes(self, project_id: str | None = None):
        values = {**self.scope_values, **({'project': project_id} if project_id else {})}
        if not self.scope_values:
            return [(scope, self.scope_limits.get(scope)) for scope in self.scopes]
        # Hash structured values to avoid tenant/project delimiter collisions.
        import hashlib
        import json
        from string import Formatter
        resolved = []
        for template in self.scopes:
            fields = [name for _,name,_,_ in Formatter().parse(template) if name]
            if any(not values.get(name) for name in fields):
                raise ValueError('Capacity scope is missing its authenticated context')
            identity = {'template':template, 'values':{name:values[name] for name in fields}}
            scope = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
            resolved.append((scope,self.scope_limits.get(template)))
        return resolved

    @staticmethod
    def _affected(rows):
        return sum(int(list(row.as_dict().values())[0]) for row in rows)

    @contextmanager
    def acquire(self, project_id: str | None = None):
        token=uuid4().hex
        client=self.client_factory()
        session=client.session
        claimed=[]
        stopped=threading.Event()
        lost=threading.Event()
        def release():
            session.sql('UPDATE IDENTIFIER(?) SET OWNER_TOKEN=NULL, LEASE_UNTIL=NULL WHERE OWNER_TOKEN=?',
                        [self.table,token]).collect()
        try:
            scopes = self.resolved_scopes(project_id)
            with self._provision_lock:
                for scope, limit in scopes:
                    if limit is not None and (scope,limit) not in self._provisioned:
                        if not self.provision_procedure or not 1 <= limit <= 1000:
                            raise ValueError('Invalid capacity provisioning configuration')
                        self.check_active()
                        session.sql('CALL IDENTIFIER(?)(?, ?, ?)',
                            [self.provision_procedure,self.table,scope,limit]).collect()
                        self._provisioned.add((scope,limit))
            deadline=time.monotonic()+self.wait_seconds
            while True:
                self.check_active()
                claimed=[]
                for scope, _ in scopes:
                    candidates=session.sql('''SELECT SLOT_ID FROM IDENTIFIER(?) WHERE SCOPE_KEY=? AND ENABLED
                        AND (OWNER_TOKEN IS NULL OR LEASE_UNTIL<CURRENT_TIMESTAMP()) ORDER BY SLOT_ID''',[self.table,scope]).collect()
                    for row in candidates:
                        slot=str(row['SLOT_ID'])
                        rows=session.sql('''UPDATE IDENTIFIER(?) SET OWNER_TOKEN=?, LEASE_UNTIL=DATEADD(second,?,CURRENT_TIMESTAMP()),
                            GENERATION=GENERATION+1 WHERE SCOPE_KEY=? AND SLOT_ID=? AND ENABLED
                            AND (OWNER_TOKEN IS NULL OR LEASE_UNTIL<CURRENT_TIMESTAMP())''',
                            [self.table,token,self.lease_seconds,scope,slot]).collect()
                        count=self._affected(rows)
                        if count>1:raise RuntimeError('Duplicate capacity slots; deployment configuration is invalid')
                        if count==1:
                            claimed.append((scope,slot));break
                    else:break
                if len(claimed)==len(scopes):break
                release()
                if time.monotonic()>=deadline:
                    raise CapacityUnavailable('Shared specialist capacity unavailable; resume when capacity is free')
                stopped.wait(0.25)
            # Renewal owns this dedicated capacity session while the caller uses
            # separate delegated domain sessions. It never touches model data.
            def renew():
                while not stopped.wait(max(1,self.lease_seconds//3)):
                    try:
                        rows=session.sql('''UPDATE IDENTIFIER(?) SET LEASE_UNTIL=DATEADD(second,?,CURRENT_TIMESTAMP())
                            WHERE OWNER_TOKEN=? AND LEASE_UNTIL>CURRENT_TIMESTAMP()''',
                            [self.table,self.lease_seconds,token]).collect()
                        if self._affected(rows)!=len(claimed):lost.set();return
                    except Exception:
                        lost.set();return
            thread=threading.Thread(target=renew,daemon=True)
            thread.start()
            try:
                yield token
                if lost.is_set():raise CapacityUnavailable('Specialist capacity lease lost; result cannot be accepted')
            finally:
                stopped.set();thread.join(timeout=self.lease_seconds)
        finally:
            try:release()
            finally:client.close()
