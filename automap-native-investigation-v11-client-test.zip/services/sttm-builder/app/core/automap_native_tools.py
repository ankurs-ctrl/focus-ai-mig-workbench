"""Actual Snowflake custom-tool handlers for native Auto-map investigation.

All tools take REQUEST_JSON VARCHAR. User/project/resources are resolved from a
caller-scoped frozen job, not chosen by model parameters. Pure handlers expose
ports for deterministic tests; production entrypoints use the caller Snowpark
session and Snowflake's authenticated API helper.
"""

from copy import deepcopy
import json
import math
import re
import time
from app.core.automap_native_contract import (
    TOOLS,
    VERSION,
    digest,
    encoded,
    identifier_key,
    words,
    evidence_identifiers,
)
from app.core.automap_native_store import (
    NativeJobStore,
    NativeStoreError,
    NativeBusy,
    plain,
)


class NativeToolError(ValueError):
    pass


def load_json(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise NativeToolError("duplicate_json_field")
            result[key] = value
        return result

    def invalid(value):
        raise NativeToolError("nonfinite_json")

    return json.loads(text, object_pairs_hook=unique, parse_constant=invalid)


def _list(value, limit=16):
    if (
        type(value) is not list
        or not value
        or len(value) > limit
        or any(type(item) is not str for item in value)
    ):
        raise NativeToolError("bounded_nonempty_identity_list_required")
    return list(dict.fromkeys(value))


def _profile_projection(value, extras, *, path=()):
    # Only explicitly typed PK diagnostics are optional; words inside evidence
    # never grant an exemption to business rules/negative evidence.
    if isinstance(value, dict):
        output = {}
        for key, child in value.items():
            if (
                path
                and path[-1] in {"pk_detection", "key_contract"}
                and key == "eliminated_candidates"
            ):
                identity = "profile_" + digest([list(path), key, child])
                extras[identity] = deepcopy(child)
                output[key] = {
                    "evidence_id": identity,
                    "purpose": "primary_key_candidate_elimination",
                    "required_for_mapping": False,
                    "instruction": "Not exclusion from source mapping.",
                }
            else:
                output[key] = _profile_projection(child, extras, path=(*path, key))
        return output
    if isinstance(value, list):
        return [
            _profile_projection(child, extras, path=(*path, index))
            for index, child in enumerate(value)
        ]
    return deepcopy(value)


def covered(spans, length):
    end = 0
    for left, right in sorted(tuple(span) for span in spans):
        if left > end:
            return False
        end = max(end, right)
    return end >= length


class NativeTools:
    def __init__(
        self,
        store,
        *,
        search=None,
        precedents=None,
        analyst=None,
        compile_proposal=None,
        phase="source"
    ):
        self.phase = phase
        self.store = store
        self.search = search
        self.precedents = precedents
        self.analyst = analyst
        self.compile_proposal = compile_proposal

    def execute(self, tool, request_json):
        if tool not in TOOLS:
            raise NativeToolError("unregistered_tool")
        if self.phase == "rule" and tool not in {
            "ReadEvidence",
            "InspectRelationships",
            "ValidateProposal",
            "SubmitProposals",
        }:
            raise NativeToolError("tool_not_registered_for_rule")
        if type(request_json) is not str or len(request_json.encode()) > 32768:
            raise NativeToolError("tool_input_budget")
        request = load_json(request_json)
        if type(request) is not dict or set(request) - {
            "job_handle",
            "snapshot_hash",
            "target_ids",
            "params",
            "question",
        }:
            raise NativeToolError("invalid_tool_contract")
        handle = request.get("job_handle")
        row = self.store.load(handle)
        snap = row["SNAPSHOT"]
        config = row["CONFIG"]
        if request.get("snapshot_hash") != snap["snapshot_hash"]:
            raise NativeToolError("stale_snapshot")
        if (
            tool in {"ValidateProposal", "SubmitProposals"}
            and config.get("kind", "source") != self.phase
        ):
            raise NativeToolError("wrong_proposal_phase")
        targets = _list(request.get("target_ids"))
        if not set(targets) <= snap["targets"].keys():
            raise NativeToolError("foreign_target")
        params = request.get("params", {})
        if type(params) is not dict:
            raise NativeToolError("invalid_tool_params")
        question = request.get("question", "")
        if type(question) is not str or len(question) > 4000:
            raise NativeToolError("invalid_question")
        # Reads/search do not depend on unrelated state revisions. Proposal
        # validation does depend on newly returned evidence/canonical history.
        state = deepcopy(row["STATE"])
        original_proposals = deepcopy(state["proposals"])
        question_key = digest(
            [
                tool,
                targets,
                params,
                question,
                (
                    digest(state["reads"])
                    if tool in {"ValidateProposal", "SubmitProposals"}
                    else None
                ),
                state.get("window", 0),
            ]
        )
        with self.store.edit(handle) as state:
            if state["tool_calls"] >= config.get("max_tool_calls", 64) or state.get(
                "window_calls", 0
            ) >= config.get("window_tool_calls", 32):
                state["window_exhausted"] = True
                return {
                    "status": "working_window_exhausted",
                    "new_information": False,
                    "instruction": "Checkpoint summary only; do not repeat tools. Unresolved evidence may continue in a bounded focused window.",
                }
            state["tool_calls"] += 1
            state["window_calls"] = state.get("window_calls", 0) + 1
            prior = state["actions"].get(question_key)
            if prior:
                prior["repeats"] = prior.get("repeats", 0) + 1
                if prior["status"] == "done":
                    return {
                        "status": "cached",
                        "operation_id": question_key,
                        "new_information": False,
                        "instruction": "This exact result was already delivered in this window. Do not repeat the operation.",
                    }
                return {
                    "status": prior["status"],
                    "reason": "Identical operation is already recorded; do not repeat it.",
                    "operation_id": question_key,
                    "new_information": False,
                }
            state["actions"][question_key] = {
                "status": "in_progress",
                "tool": tool,
                "target_ids": targets,
                "at": time.time(),
            }
        state = deepcopy(state)  # Work outside the short committed operation lease.
        try:
            result = getattr(self, "_" + tool)(
                snap, state, targets, params, question, config
            )
            if isinstance(result, dict):
                result["working_window"] = {
                    "calls_remaining": max(
                        0,
                        config.get("window_tool_calls", 32)
                        - state.get("window_calls", 0),
                    ),
                    "evidence_bytes_remaining": max(
                        0,
                        config.get("evidence_budget_bytes", 160000)
                        - state["delivered_bytes"],
                    ),
                }
            text = encoded(result)
            if len(text.encode()) > config.get("tool_output_bytes", 32768):
                raise NativeToolError("tool_output_budget")
            with self.store.edit(handle) as current:
                if current["delivered_bytes"] + len(text.encode()) > config.get(
                    "evidence_budget_bytes", 160000
                ):
                    raise NativeToolError("working_window_exhausted")
                # Merge only this operation's deltas, never replace the durable
                # dependency set or reads made by a concurrent independent tool.
                for identity, spans in state["reads"].items():
                    current["reads"][identity] = sorted(
                        {tuple(span) for span in current["reads"].get(identity, [])}
                        | {tuple(span) for span in spans}
                    )
                for target, bindings in state["candidates"].items():
                    current["candidates"][target] = sorted(
                        set(current["candidates"].get(target, [])) | set(bindings)
                    )
                for target, proposal in state["proposals"].items():
                    if proposal == original_proposals.get(target):
                        continue
                    old = current["proposals"].get(target)
                    if old and old != original_proposals.get(target):
                        raise NativeToolError("concurrent_proposal_changed")
                    current["proposals"][target] = proposal
                current["canonical_records"].update(state["canonical_records"])
                for target in targets:
                    if target in state.get("verified_notes", {}):
                        current.setdefault("verified_notes", {})[target] = state[
                            "verified_notes"
                        ][target]
                    for binding, dependency in (
                        state.get("dependencies", {}).get(target, {}).items()
                    ):
                        current.setdefault("dependencies", {}).setdefault(target, {})[
                            binding
                        ] = dependency
                if tool in {"ValidateProposal", "SubmitProposals"}:
                    for target in targets:
                        if target in state["deficits"]:
                            current["deficits"][target] = state["deficits"][target]
                    for target in targets:
                        if target not in state["deficits"]:
                            current["deficits"].pop(target, None)
                current["delivered_bytes"] += len(text.encode())
                current["total_delivered_bytes"] = current.get(
                    "total_delivered_bytes", 0
                ) + len(text.encode())
                current["actions"][question_key] = {
                    "status": "done",
                    "tool": tool,
                    "target_ids": targets,
                    "at": time.time(),
                    "result": result,
                }
                current["trace"].append(
                    {
                        "stage": "tool_completed",
                        "at": time.time(),
                        "counts": {
                            "tool": tool,
                            "target_ids": targets,
                            "bytes": len(text.encode()),
                            "targets": len(targets),
                        },
                    }
                )
                current["trace"] = current["trace"][-128:]
            return result
        except Exception as exc:
            # Failed/uncertain external operations are NEVER retried on cache
            # miss or lease expiry. Preserve completed sibling checkpoints.
            with self.store.edit(handle, allow_expired=True) as current:
                if (
                    isinstance(exc, NativeToolError)
                    and str(exc) == "working_window_exhausted"
                ):
                    current["window_exhausted"] = True
                current["actions"][question_key] = {
                    "status": "failed",
                    "tool": tool,
                    "target_ids": targets,
                    "at": time.time(),
                    "reason": (
                        str(exc)
                        if isinstance(exc, NativeToolError)
                        else "tool_execution_failed"
                    ),
                }
            raise

    def _SearchSources(self, snap, state, targets, params, question, config):
        if set(params) - {"limit", "cursor"} or not question.strip():
            raise NativeToolError("source_search_requires_question")
        limit = params.get("limit", 8)
        if type(limit) is not int or not 1 <= limit <= 16:
            raise NativeToolError("source_search_limit")
        tokens = words(question)
        all_sources = list(snap["sources"].values())
        ranked = sorted(
            all_sources,
            key=lambda item: (
                -len(
                    tokens
                    & words(
                        item["source_ref"]
                        + " "
                        + encoded(
                            snap["records"][item["evidence_id"]]["body"].get(
                                "semantics", []
                            )
                        )
                    )
                ),
                item["binding_id"],
            ),
        )
        indexed = []
        search_status = "unavailable"
        if self.search:
            # The port derives all filters from snap/config. Returned IDs are
            # intersected with this snapshot, including distinct self-joins.
            try:
                indexed = self.search(snap, question, config)
                search_status = "available"
            except Exception:
                search_status = "unavailable_frozen_inventory_used"
        indexed = [key for key in indexed if key in snap["sources"]]
        ordered = list(
            dict.fromkeys([*indexed, *[source["binding_id"] for source in ranked]])
        )
        cursor = params.get("cursor", 0)
        if type(cursor) is not int or not 0 <= cursor <= len(ordered):
            raise NativeToolError("invalid_source_cursor")
        ids = ordered[cursor : cursor + limit]
        for target in targets:
            state["candidates"][target] = sorted(
                set(state["candidates"].get(target, [])) | set(ids)
            )
        return {
            "status": "available",
            "candidates": [snap["sources"][key] for key in ids],
            "search_status": search_status,
            "next_cursor": cursor + limit if cursor + limit < len(ordered) else None,
            "coverage": "bounded_inventory_search_not_exhaustive",
            "instruction": "Candidates require exact reads and business support.",
        }

    def _ReadEvidence(self, snap, state, targets, params, question, config):
        if set(params) - {"evidence_ids", "offset", "page_bytes", "kind"}:
            raise NativeToolError("invalid_read_contract")
        extras = {}
        projected = {
            key: _profile_projection(value, extras, path=("records", key))
            for key, value in {
                **snap["records"],
                **{
                    key: value["record"]
                    for key, value in state["canonical_records"].items()
                },
            }.items()
        }
        index = [
            {
                "evidence_id": identity,
                "kind": record["kind"],
                "target": record["body"].get("target_id"),
                "relation": record["body"].get("relation")
                or record["body"].get("relation_id"),
                "column": record["body"].get("column"),
                "owner_id": record["body"].get("owner_ref"),
            }
            for identity, record in snap["records"].items()
        ]
        bodies = {
            **projected,
            **extras,
            "evidence_index": index,
            "existing_definitions": snap["existing_rows"],
            "values": snap["values"],
            "learning_index": [
                {
                    "evidence_id": identity,
                    "kind": record["kind"],
                    "target": record["body"].get("target_id"),
                    "category": record["body"].get("category"),
                }
                for identity, record in snap["records"].items()
                if record["kind"] in {"mandatory_evidence", "learning_evidence"}
            ],
        }
        ids = _list(params.get("evidence_ids") or [params.get("kind")])
        if not set(ids) <= bodies.keys():
            raise NativeToolError("unknown_evidence_node")
        # A single column read carries its owner context automatically. If that
        # owner is large, the response includes its next_offset, never a claim
        # that the unread remainder was inspected.
        if len(ids) == 1 and params.get("offset", 0) == 0:
            owner = (snap["records"].get(ids[0], {}).get("body") or {}).get("owner_ref")
            if owner and owner not in ids:
                ids.append(owner)
        offset = params.get("offset", 0)
        size = params.get("page_bytes", 2048)
        if (
            type(offset) is not int
            or offset < 0
            or type(size) is not int
            or not 256 <= size <= 8192
        ):
            raise NativeToolError("invalid_evidence_page")
        results = []
        remaining = []
        for position, identity in enumerate(ids):
            if len(encoded(results).encode()) + size * 2 + 1024 > config.get(
                "tool_output_bytes", 32768
            ):
                remaining = ids[position:]
                break
            body = encoded(bodies[identity])
            if offset > len(body):
                raise NativeToolError("invalid_evidence_offset")
            end = min(len(body), offset + size)
            while len(body[offset:end].encode()) > size:
                end = offset + (end - offset) // 2
            state["reads"].setdefault(identity, []).append([offset, end])
            results.append(
                {
                    "evidence_id": identity,
                    "body_hash": digest(bodies[identity]),
                    "encoding": "json",
                    "text": body[offset:end],
                    "offset": offset,
                    "end": end,
                    "length": len(body),
                    "complete": covered(state["reads"][identity], len(body)),
                    "next_offset": end if end < len(body) else None,
                    "receipt_id": digest(
                        [snap["snapshot_hash"], identity, offset, end, body[offset:end]]
                    ),
                }
            )
        return {
            "status": "available",
            "evidence": results,
            "remaining_evidence_ids": remaining,
            "instruction": "Read all required pages; excerpts do not establish full coverage.",
        }

    def _InspectRelationships(self, snap, state, targets, params, question, config):
        if set(params) - {"binding_ids"}:
            raise NativeToolError("invalid_relationship_request")
        ids = _list(params.get("binding_ids"))
        if not set(ids) <= snap["sources"].keys():
            raise NativeToolError("unknown_binding")
        relations = {snap["sources"][key]["relation_id"] for key in ids}
        graph = snap["relation_graph"]
        # Return bounded index/links. Exact predicates and SQL remain read nodes.
        return {
            "status": "available",
            "relations": [
                {
                    "relation_id": node["relation_id"],
                    "kind": node.get("kind"),
                    "exposed_output_count": len(node.get("output_columns", [])),
                    "output_binding_ids": [
                        key
                        for key, source in snap["sources"].items()
                        if source["relation_id"] == node["relation_id"]
                    ][:16],
                    "output_inventory_tool": "SearchSources",
                    "parent_relation_ids": node.get("parent_relation_ids", []),
                }
                for node in graph.get("nodes", [])
                if node["relation_id"] in relations
            ],
            "relationships": [
                {
                    "edge_id": edge.get("edge_id"),
                    "left_relation_id": edge.get("left_relation_id"),
                    "right_relation_id": edge.get("right_relation_id"),
                    "join_type": edge.get("join_type"),
                }
                for edge in graph.get("edges", [])
                if relations
                & {edge.get("left_relation_id"), edge.get("right_relation_id")}
            ],
            "parent_contract_evidence_ids": [
                snap["graph_records"][parent]
                for node in graph.get("nodes", [])
                if node["relation_id"] in relations
                for parent in node.get("parent_relation_ids", [])
                if parent in snap.get("graph_records", {})
            ],
            "audit_index_tool": 'ReadEvidence(evidence_ids=["evidence_index"])',
            "exact_node_evidence_ids": [
                snap["graph_records"][identity]
                for identity in relations
                if identity in snap.get("graph_records", {})
            ],
            "exact_relationship_evidence_ids": snap.get("edge_records", []),
            "exact_graph_evidence_ids": [
                key
                for key, record in snap["records"].items()
                if record["kind"] == "source_graph"
            ],
            "instruction": "Relationship index is not permission to select hidden parent outputs.",
        }

    def _SearchPrecedents(self, snap, state, targets, params, question, config):
        if params or not question.strip():
            raise NativeToolError("precedent_search_requires_question")
        if not self.precedents:
            return {
                "status": "unavailable",
                "reason": "canonical_precedent_search_unavailable",
            }
        # The port must return only lifecycle/scope/applicability hydrated records.
        records = self.precedents(snap, targets, question, config)
        index = []
        for item in records:
            identity = "fir_" + digest(item["record"])
            state["canonical_records"][identity] = {
                "record": item["record"],
                "target_ids": item["target_ids"],
                "canonical_ids": item["canonical_ids"],
            }
            index.append(
                {
                    "evidence_id": identity,
                    "target_ids": item["target_ids"],
                    "canonical_ids": item["canonical_ids"],
                }
            )
        return {
            "status": "available",
            "records": index,
            "coverage": "bounded_query_not_exhaustive",
        }

    def _AskPreparedAnalyst(self, snap, state, targets, params, question, config):
        if set(params) - {"binding_ids"} or not question.strip():
            raise NativeToolError("analyst_requires_specific_question")
        ids = _list(params.get("binding_ids"))
        if not set(ids) <= snap["sources"].keys():
            raise NativeToolError("unknown_analyst_binding")
        if not self.analyst:
            return {"status": "unavailable", "reason": "prepared_analyst_unavailable"}
        if snap["bundle"].get("coverage_validated") is not True:
            return {
                "status": "unavailable",
                "reason": "prepared_bundle_does_not_cover_current_snapshot",
            }
        if not snap["bundle"].get("id") or not snap["bundle"].get("hash"):
            return {
                "status": "unavailable",
                "reason": "prepared_bundle_identity_missing",
            }
        result = self.analyst(snap, ids, question, config)
        if (
            result.get("status") != "executed"
            or result.get("data_result_obtained") is not True
        ):
            return result
        identity = "analysis_" + digest([snap["snapshot_hash"], result])
        record = {"record_id": identity, "kind": "analyst_observation", "body": result}
        state["canonical_records"][identity] = {
            "record": record,
            "target_ids": targets,
            "canonical_ids": [],
        }
        state["reads"].setdefault(identity, []).append([0, len(encoded(record))])
        return {
            "status": "executed",
            "evidence_id": identity,
            "evidence": record,
            "instruction": "Executed data observation, not business-policy authority.",
        }

    def _required(self, snap, target, refs):
        ids = set()
        for ref in refs:
            source = next(
                (
                    item
                    for item in snap["sources"].values()
                    if item["source_ref"] == ref
                ),
                None,
            )
            if not source:
                raise NativeToolError("unknown_or_hidden_binding")
            ids.update([source["evidence_id"], source["owner_id"]])
            if source["relation_id"] in snap.get("graph_records", {}):
                ids.add(snap["graph_records"][source["relation_id"]])
        ids.update(snap.get("edge_records", []))
        for identity in snap["mandatory_evidence"]:
            record = snap["records"][identity]
            owner = record["body"].get("target_id")
            if owner is None or identifier_key(owner) == identifier_key(
                snap["targets"][target]["name"]
            ):
                ids.add(identity)
        return ids - {None}

    def _validate(self, snap, state, target, proposal, support, config):
        from app.schema.sttm_builder import AttributeMapping

        try:
            mapping = AttributeMapping.model_validate(proposal)
        except Exception:
            raise NativeToolError("invalid_mapping_schema") from None
        mapping = mapping.model_copy(
            update={
                key: list(dict.fromkeys(getattr(mapping, key)))
                for key in (
                    "source_attributes",
                    "source_dependencies",
                    "candidate_source_attributes",
                )
            }
        )
        # Normalization is deliberately strict: strings must be copied from the
        # native roster, so object/qualifier ambiguity cannot change bindings.
        refs = list(
            dict.fromkeys(
                [
                    *mapping.source_attributes,
                    *mapping.source_dependencies,
                    *mapping.candidate_source_attributes,
                ]
            )
        )
        sources = {source["source_ref"]: source for source in snap["sources"].values()}
        used = set(
            mapping.used_learning_ids
            + mapping.used_inference_ids
            + mapping.used_recommendation_ids
            + mapping.override_evidence
            + ([mapping.precedent_mapping_id] if mapping.precedent_mapping_id else [])
        )
        known = set(snap.get("learning_ids", {}).get(target, []))
        canonical_required = []
        for identity, record in snap["records"].items():
            if record["kind"] not in {
                "mandatory_evidence",
                "learning_evidence",
                "historical_dependency",
            }:
                continue
            if identifier_key(
                record["body"].get("target_id") or snap["targets"][target]["name"]
            ) != identifier_key(snap["targets"][target]["name"]):
                continue
            if used & evidence_identifiers(record["body"]):
                canonical_required.append(identity)
        for identity, value in state["canonical_records"].items():
            if target in value["target_ids"]:
                known.update(value["canonical_ids"])
                if used & set(value["canonical_ids"]):
                    canonical_required.append(identity)
        if used - known:
            raise NativeToolError("foreign_or_unretrieved_learning_citation")

        def dependencies(value):
            found = set()
            if isinstance(value, dict):
                if value.get("exact_dependency_id"):
                    found.add(value["exact_dependency_id"])
                for child in value.values():
                    found.update(dependencies(child))
            elif isinstance(value, list):
                for child in value:
                    found.update(dependencies(child))
            return found

        for identity in list(canonical_required):
            record = (
                snap["records"].get(identity)
                or state["canonical_records"][identity]["record"]
            )
            canonical_required.extend(dependencies(record))
        if any(ref not in sources for ref in refs):
            raise NativeToolError("unknown_or_hidden_binding")
        extras = {}
        bodies = {
            key: _profile_projection(record, extras, path=("records", key))
            for key, record in {
                **snap["records"],
                **{
                    key: value["record"]
                    for key, value in state["canonical_records"].items()
                },
            }.items()
        }
        # A continuation can carry selected exact quotes, never a fabricated
        # summary of an unread large record. Partial notes do not authorize a
        # mapping or satisfy full required-record coverage.
        if isinstance(support, dict) and isinstance(support.get("citations"), list):
            quotes = []
            for citation in support["citations"][:32]:
                if type(citation) is not dict or set(citation) != {
                    "evidence_id",
                    "quote",
                }:
                    continue
                identity = citation["evidence_id"]
                quote = citation["quote"]
                if (
                    identity in bodies
                    and type(quote) is str
                    and quote
                    and len(quote.encode()) <= 512
                    and any(
                        quote in encoded(bodies[identity])[left:right]
                        for left, right in state["reads"].get(identity, [])
                    )
                ):
                    quotes.append(
                        {
                            "evidence_id": identity,
                            "body_hash": digest(bodies[identity]),
                            "quote": quote,
                        }
                    )
            if quotes:
                state.setdefault("verified_notes", {})[target] = {
                    "excerpts": quotes,
                    "source_refs": refs,
                    "meaning_status": "literal_excerpts_only_not_a_validated_mapping",
                }
        required = self._required(snap, target, refs) | set(canonical_required)
        for ref in refs:
            binding = sources[ref]["binding_id"]
            state.setdefault("dependencies", {}).setdefault(target, {})[binding] = {
                "evidence_ids": sorted(required),
                "usable": False,
                "returned_evidence_ids": sorted(
                    identity
                    for identity in required
                    if covered(
                        state["reads"].get(identity, []), len(encoded(bodies[identity]))
                    )
                ),
            }
        missing = [
            identity
            for identity in self._required(snap, target, refs) | set(canonical_required)
            if not covered(
                state["reads"].get(identity, []), len(encoded(bodies[identity]))
            )
        ]
        if missing:
            state["deficits"][target] = {
                "code": "missing_exact_evidence",
                "evidence_ids": sorted(missing),
            }
            return {"valid": False, **state["deficits"][target]}
        from app.core.learning_evidence import repeats_rejected_decision
        from app.core.automap_retrieval import AutoMapContext

        original = AutoMapContext(snap["request"])
        name = snap["targets"][target]["name"]
        for correction in original.evidence.get(name, {}).get("correction_history", []):
            if repeats_rejected_decision(
                correction,
                mapping.model_dump(mode="json"),
                (snap["request"].get("context") or {}).get("workspace_context") or {},
            ):
                raise NativeToolError("rejected_corrected_mapping")
        if (
            mapping.pattern_decision in {"accept_exact_precedent", "adapt_pattern"}
            and not used
        ):
            raise NativeToolError("precedent_requires_read_canonical_evidence")
        if type(support) is not dict or set(support) - {
            "status",
            "source_meaning",
            "target_meaning",
            "grain",
            "contradictions",
            "citations",
        }:
            raise NativeToolError("semantic_support_required")
        status = support.get("status")
        if status not in {
            "supported",
            "uncertain",
            "contradicted",
            "missing_business_input",
            "needs_evidence",
        }:
            raise NativeToolError("invalid_semantic_support")
        contradictions = support.get("contradictions", [])
        if type(contradictions) is not list or any(
            type(item) is not str for item in contradictions
        ):
            raise NativeToolError("invalid_contradictions")
        if status == "supported" and (
            not all(
                type(support.get(key)) is str and support[key].strip()
                for key in ("source_meaning", "target_meaning", "grain")
            )
        ):
            raise NativeToolError("semantic_reasoning_required")
        citations = support.get("citations", [])
        if type(citations) is not list or len(citations) > 32:
            raise NativeToolError("invalid_citations")
        for citation in citations:
            if type(citation) is not dict or set(citation) != {"evidence_id", "quote"}:
                raise NativeToolError("invalid_citation")
            identity = citation["evidence_id"]
            quote = citation["quote"]
            if (
                identity not in bodies
                or type(quote) is not str
                or not quote
                or not any(
                    quote in encoded(bodies[identity])[start:end]
                    for start, end in state["reads"].get(identity, [])
                )
            ):
                raise NativeToolError("unread_or_fabricated_citation")
        if refs and status == "supported":
            cited = {item["evidence_id"] for item in citations}
            required_sources = {
                sources[ref]["evidence_id"] for ref in mapping.source_attributes
            }
            target_evidence = {
                identity
                for identity, record in snap["records"].items()
                if record["kind"] == "target"
                and identifier_key(record["body"]["target_id"])
                == identifier_key(snap["targets"][target]["name"])
            }
            if not required_sources <= cited or not target_evidence & cited:
                raise NativeToolError(
                    "supported_mapping_requires_source_and_target_evidence"
                )
        # A declared contradiction cannot be excused by SQL validity/confidence.
        if contradictions or status in {
            "contradicted",
            "missing_business_input",
            "needs_evidence",
        }:
            mapping = AttributeMapping(
                source_attributes=[],
                candidate_source_attributes=list(
                    dict.fromkeys(
                        [
                            *mapping.source_attributes,
                            *mapping.candidate_source_attributes,
                        ]
                    )
                ),
                confidence_score=0,
                confidence_reason=mapping.confidence_reason
                or "; ".join(contradictions),
                transformation_classification="unresolved",
                unmatched_reason=(
                    "Missing business input"
                    if status == "missing_business_input"
                    else (
                        (mapping.unmatched_reason or "Additional evidence required")
                        if status == "needs_evidence"
                        else "Semantic contradiction requires business review"
                    )
                ),
            )
        if config.get("kind") == "rule":
            selected = config["selected_mapping"]
            if (
                any(
                    getattr(mapping, key) != selected.get(key)
                    for key in ("mapping_mode", "constant_value", "attribute_name")
                )
                or mapping.source_attributes != selected["source_attributes"]
                or mapping.source_dependencies != selected["source_dependencies"]
                or set(mapping.value_binding_ids) != set(selected["value_binding_ids"])
            ):
                raise NativeToolError("rule_cannot_change_selected_bindings")
            if not mapping.preprocessing_rule:
                raise NativeToolError("specialist_requires_executable_expression")
        if mapping.preprocessing_rule:
            from sqlglot import exp, parse_one

            def _reference_key(reference):
                column = parse_one(reference, read="snowflake", into=exp.Column)
                if (
                    not isinstance(column, exp.Column)
                    or column.is_star
                    or len(column.parts) != 2
                ):
                    raise NativeToolError("qualified_source_column_required")
                return tuple(
                    part.name if part.args.get("quoted") else part.name.upper()
                    for part in column.parts
                )

            try:
                expression = parse_one(mapping.preprocessing_rule, read="snowflake")
                if isinstance(expression, exp.Query):
                    raise NativeToolError("scalar_expression_required")
                selected_refs = {
                    _reference_key(ref)
                    for ref in [
                        *mapping.source_attributes,
                        *mapping.source_dependencies,
                    ]
                }
                if any(
                    _reference_key(column.sql(dialect="snowflake")) not in selected_refs
                    for column in expression.find_all(exp.Column)
                ):
                    raise NativeToolError("expression_has_unselected_binding")
            except NativeToolError:
                raise
            except Exception:
                raise NativeToolError("malformed_expression") from None
        expression_is_complex = False
        if mapping.preprocessing_rule and str(
            mapping.preprocessing_rule_type or ""
        ).upper() not in {"DIRECT", "IDENTITY", "VALUE"}:
            expression_is_complex = True
        requires_rule = (
            config.get("kind", "source") == "source"
            and mapping.transformation_classification != "unresolved"
            and (
                mapping.transformation_classification
                in {"complex", "simple_multi_source"}
                or expression_is_complex
                or (
                    len(mapping.source_attributes) > 1
                    and mapping.mapping_mode == "source"
                )
            )
        )
        if (
            self.compile_proposal
            and mapping.transformation_classification != "unresolved"
        ):
            compilation = self.compile_proposal(
                snap, target, mapping, requires_rule, config
            )
            if not compilation.get("valid"):
                state["deficits"][target] = {
                    "code": compilation.get("code", "mapping_compile_failed"),
                    "stage": "compilation",
                }
                return compilation
        elif mapping.transformation_classification != "unresolved":
            raise NativeToolError("proposal_compiler_unavailable")
        state["deficits"].pop(target, None)
        for ref in refs:
            state["dependencies"][target][sources[ref]["binding_id"]]["usable"] = True
        state["candidates"][target] = sorted(
            set(state["candidates"].get(target, []))
            | {sources[ref]["binding_id"] for ref in refs}
        )
        return {
            "valid": True,
            "mapping": mapping.model_dump(mode="json"),
            "requires_rule": requires_rule,
            "review_only": status == "uncertain"
            or bool(contradictions)
            or bool(
                re.search(
                    r"rather than|does not (?:represent|match|capture|reflect)|different (?:business|meaning|event|grain|concept)",
                    mapping.confidence_reason or "",
                    re.I,
                )
            ),
            "support": support,
        }

    def _ValidateProposal(self, snap, state, targets, params, question, config):
        if len(targets) != 1 or set(params) != {"mapping", "semantic_support"}:
            raise NativeToolError("one_scoped_proposal_required")
        return self._validate(
            snap,
            state,
            targets[0],
            params["mapping"],
            params["semantic_support"],
            config,
        )

    def _SubmitProposals(self, snap, state, targets, params, question, config):
        if (
            set(params) != {"proposals"}
            or type(params["proposals"]) is not dict
            or set(params["proposals"]) != set(targets)
        ):
            raise NativeToolError("submit_requires_exact_target_proposals")
        results = {}
        for target, item in params["proposals"].items():
            if type(item) is not dict or set(item) != {"mapping", "semantic_support"}:
                results[target] = {"valid": False, "code": "invalid_proposal"}
                state["deficits"][target] = {"code": "invalid_proposal"}
                continue
            if state["proposals"].get(target, {}).get("stage") in {
                "validated",
                "needs_rule",
            }:
                results[target] = {"valid": True, "already_checkpointed": True}
                continue
            try:
                result = self._validate(
                    snap,
                    state,
                    target,
                    item["mapping"],
                    item["semantic_support"],
                    config,
                )
            except Exception as error:
                result = {
                    "valid": False,
                    "code": (
                        str(error)
                        if isinstance(error, NativeToolError)
                        else "invalid_target_proposal"
                    ),
                }
                state["deficits"][target] = {"code": result["code"]}
            results[target] = result
            if result["valid"]:
                proposal = {
                    "mapping": result["mapping"],
                    "support": result["support"],
                    "review_only": result["review_only"],
                    "stage": (
                        "needs_evidence"
                        if result["support"]["status"] == "needs_evidence"
                        else "needs_rule" if result["requires_rule"] else "validated"
                    ),
                    "at": time.time(),
                    "snapshot_hash": snap["snapshot_hash"],
                }
                proposal["proposal_hash"] = digest(proposal)
                state["proposals"][target] = proposal
        results = {
            key: {
                field: value
                for field, value in result.items()
                if field not in {"mapping", "support"}
            }
            for key, result in results.items()
        }
        return {
            "status": "checkpointed",
            "targets": results,
            "instruction": "No authored mapping has been replaced; no workspace was published.",
        }


def dispatch(session, tool, request_json, *, phase="source", metadata=None):
    """Snowflake procedure entrypoint. Namespace comes from procedure context."""
    from app.core.automap_native_rpc import request as rpc
    from app.core.automap_native_store import namespace

    metadata = namespace(
        metadata
    )  # Constant in the registered procedure's deployed handler.
    row = session.sql("SELECT CURRENT_TRANSACTION() AS TX").collect()[0]
    from app.core.automap_native_store import plain

    row = plain(row)
    if row.get("TX") is not None:
        raise NativeToolError("native_tools_require_transaction_free_call")
    # Scope and handle are validated before a bridge request is even enqueued.
    parsed = load_json(request_json)
    if type(parsed) is not dict:
        raise NativeToolError("invalid_tool_contract")
    store = NativeJobStore(session, metadata)
    handle = parsed.get("job_handle")
    runtime = NativeTools(
        store,
        phase=phase,
        search=lambda snap, question, config: rpc(
            store, handle, "sources", {"question": question}
        ),
        precedents=lambda snap, targets, question, config: rpc(
            store, handle, "precedents", {"targets": targets, "question": question}
        ),
        analyst=lambda snap, ids, question, config: rpc(
            store, handle, "analyst", {"ids": ids, "question": question}
        ),
        compile_proposal=lambda snap, target, mapping, requires_rule, config: rpc(
            store,
            handle,
            "compile",
            {
                "target": target,
                "mapping": mapping.model_dump(mode="json"),
                "requires_rule": requires_rule,
            },
        ),
    )
    try:
        return encoded(runtime.execute(tool, request_json))
    except Exception as error:
        code = (
            str(error)
            if isinstance(error, NativeToolError)
            else "native_tool_store_unavailable"
        )
        return encoded(
            {
                "status": "unavailable",
                "code": code,
                "new_information": False,
                "instruction": "Repair only this specific tool contract error. request_json must encode an object with job_handle, snapshot_hash, target_ids (owned IDs), question, and params (object). Put all operation-specific fields INSIDE params, never alongside job_handle. Do not infer no-match or fabricate evidence; retain prior validated siblings.",
                "required_top_level_fields": [
                    "job_handle",
                    "snapshot_hash",
                    "target_ids",
                    "params",
                ],
                "allowed_top_level_fields": [
                    "job_handle",
                    "snapshot_hash",
                    "target_ids",
                    "params",
                    "question",
                ],
            }
        )


def search_sources(session, request_json):
    return dispatch(session, "SearchSources", request_json)


def read_evidence(session, request_json):
    return dispatch(session, "ReadEvidence", request_json)


def inspect_relationships(session, request_json):
    return dispatch(session, "InspectRelationships", request_json)


def search_precedents(session, request_json):
    return dispatch(session, "SearchPrecedents", request_json)


def ask_prepared_analyst(session, request_json):
    return dispatch(session, "AskPreparedAnalyst", request_json)


def validate_proposal(session, request_json):
    return dispatch(session, "ValidateProposal", request_json)


def submit_proposals(session, request_json):
    return dispatch(session, "SubmitProposals", request_json)


def validate_rule(session, request_json):
    return dispatch(session, "ValidateProposal", request_json, phase="rule")


def submit_rule(session, request_json):
    return dispatch(session, "SubmitProposals", request_json, phase="rule")
