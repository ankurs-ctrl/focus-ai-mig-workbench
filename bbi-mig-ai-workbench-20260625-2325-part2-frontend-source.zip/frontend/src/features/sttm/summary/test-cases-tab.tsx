"use client";

import { useMemo, useState } from "react";
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import AutoAwesomeRoundedIcon from "@mui/icons-material/AutoAwesomeRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import type {
  MappingSqlMappingItem,
  TableRef,
  TestCaseGenerationRequest,
  TestCaseGenerationResponse,
} from "@/types/api-contract";
import { dbService } from "@/services/dbService";

type TestCasesTabProps = {
  active: boolean;
  requestPayload: TestCaseGenerationRequest | null;
  workbookLoading?: boolean;
  onDownloadWorkbook?: () => void;
  onCompleted?: (result: CachedTestCaseGeneration) => void;
};

export type CachedTestCaseGeneration = {
  result: TestCaseGenerationResponse;
  statusMessage: string;
};

const completedTestCaseGenerationCache = new Map<string, CachedTestCaseGeneration>();

function toTableRef(qualifiedName: string): TableRef | null {
  const [database, schema, table] = qualifiedName.split(".", 3);
  if (!database || !schema || !table) return null;
  return { database, schema, table };
}

function deriveDomainName(targetSchema: string | null, sourceSchemas: string[]): string | null {
  for (const value of [targetSchema, ...sourceSchemas]) {
    if (!value) continue;
    const normalized = value.trim().toLowerCase();
    for (const prefix of ["curated_", "raw_", "mart_", "api_", "ds_"]) {
      if (normalized.startsWith(prefix)) return normalized.slice(prefix.length);
    }
    if (normalized.includes("_")) return normalized.split("_").slice(1).join("_");
    return normalized;
  }
  return null;
}

function deriveLayer(schemaName: string | null): "raw" | "curated" | "mart" {
  const normalized = (schemaName ?? "").trim().toLowerCase();
  if (normalized.startsWith("mart_")) return "mart";
  if (normalized.startsWith("raw_")) return "raw";
  return "curated";
}

function mapSummaryMappings(
  mappings: Array<{
    targetColumn: string;
    targetType: string;
    sourceColumn: string | null;
    sourceColumns?: string[];
    expression: string | null;
    rule: string;
    status: string;
    nlRule?: string | null;
    description?: string | null;
  }>,
): MappingSqlMappingItem[] {
  return mappings.map((mapping) => ({
    target_column: mapping.targetColumn,
    target_type: mapping.targetType || null,
    source_column: mapping.sourceColumn ?? null,
    source_columns: mapping.sourceColumns ?? [],
    expression: mapping.expression ?? null,
    rule: mapping.rule ?? null,
    status: mapping.status ?? null,
    nl_rule: mapping.nlRule ?? null,
    description: mapping.description ?? null,
  }));
}

export function buildTestCaseRequestPayload(params: {
  targets: Array<{ isSelected: boolean; qualifiedName: string }>;
  sources: Array<{ isSelected: boolean; qualifiedName: string }>;
  relationships: Array<{
    leftTableId?: string;
    rightTableId?: string;
    constraintName?: string | null;
    joinType?: string;
    source?: string | null;
    locked?: boolean;
    conditions?: Array<{ leftColumn?: string; rightColumn?: string; operator?: string }>;
  }>;
  derivedSources: Array<{ isSelected?: boolean; id: string; sourceName?: string; sqlText?: string | null }>;
  mappings: Array<{
    targetColumn: string;
    targetType: string;
    sourceColumn: string | null;
    sourceColumns?: string[];
    expression: string | null;
    rule: string;
    status: string;
    nlRule?: string | null;
    description?: string | null;
  }>;
  semanticContextItems?: TestCaseGenerationRequest["semantic_context"] | null;
  validatedSql: string;
}): TestCaseGenerationRequest | null {
  const selectedTarget = params.targets.find((table) => table.isSelected);
  const targetTable = selectedTarget ? toTableRef(selectedTarget.qualifiedName) : null;
  if (!targetTable || !params.validatedSql.trim()) return null;

  const sourceTables = params.sources
    .filter((table) => table.isSelected)
    .map((table) => toTableRef(table.qualifiedName))
    .filter((table): table is TableRef => Boolean(table));
  const relationshipPayload = params.relationships
    .filter((join) => join.leftTableId && join.rightTableId && join.conditions?.length)
    .map((join) => {
      const leftTable = toTableRef(String(join.leftTableId));
      const rightTable = toTableRef(String(join.rightTableId));
      if (!leftTable || !rightTable) return null;
      return {
        left_table: leftTable,
        right_table: rightTable,
        constraint_name: join.constraintName ?? null,
        join_type: join.joinType ?? "INNER",
        source: join.source ?? "USER_DEFINED",
        locked: join.locked ?? false,
        conditions: (join.conditions ?? [])
          .filter((condition) => condition.leftColumn && condition.rightColumn)
          .map((condition) => ({
            left_column: String(condition.leftColumn),
            right_column: String(condition.rightColumn),
            operator: condition.operator ?? "=",
          })),
      };
    })
    .filter((item): item is NonNullable<typeof item> => Boolean(item));
  const sourceSchemas = sourceTables.map((table) => table.schema);

  return {
    project_name: `${targetTable.table} Test Cases`,
    domain_name: deriveDomainName(targetTable.schema, sourceSchemas),
    target_layer: deriveLayer(targetTable.schema),
    materialization: deriveLayer(targetTable.schema) === "mart" ? "view" : "incremental",
    source_tables: sourceTables,
    target_table: targetTable,
    relationships: relationshipPayload,
    validated_sql: params.validatedSql,
    mappings: mapSummaryMappings(params.mappings.filter((mapping) => mapping.status === "MAPPED")),
    semantic_context: params.semanticContextItems ?? [],
    derived_sources: params.derivedSources
      .filter((source) => source.isSelected)
      .map((source) => ({
        derived_source_name: source.sourceName || source.id,
        sql_text: source.sqlText ?? null,
        semantic_view_name: null,
        base_sources: [],
      })),
  };
}

export function getCachedTestCaseGeneration(
  requestPayload: TestCaseGenerationRequest | null,
): CachedTestCaseGeneration | null {
  if (!requestPayload) return null;
  return completedTestCaseGenerationCache.get(JSON.stringify(requestPayload)) ?? null;
}

export function TestCasesTab({
  active,
  requestPayload,
  workbookLoading = false,
  onDownloadWorkbook,
  onCompleted,
}: TestCasesTabProps) {
  const cached = useMemo(() => getCachedTestCaseGeneration(requestPayload), [requestPayload]);
  const [result, setResult] = useState<TestCaseGenerationResponse | null>(cached?.result ?? null);
  const [statusMessage, setStatusMessage] = useState(cached?.statusMessage ?? "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canGenerate = Boolean(requestPayload && active && !loading);

  const generate = async () => {
    if (!requestPayload) {
      setError("Generate validated SQL before creating test cases.");
      return;
    }
    setLoading(true);
    setError(null);
    setStatusMessage("AGT_TEST_CASE_GENERATION is creating STTM validation tests.");
    try {
      const response = await dbService.generateTestCases(requestPayload);
      const cacheEntry = {
        result: response,
        statusMessage: `Generated ${response.test_case_document.length} test cases.`,
      };
      completedTestCaseGenerationCache.set(JSON.stringify(requestPayload), cacheEntry);
      setResult(response);
      setStatusMessage(cacheEntry.statusMessage);
      onCompleted?.(cacheEntry);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setStatusMessage("");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ flex: 1, minHeight: 0, overflow: "auto", p: 2 }}>
      <Stack direction="row" spacing={1.5} sx={{ mb: 2, flexWrap: "wrap", alignItems: "center" }}>
        <Typography variant="h6" sx={{ fontWeight: 800 }}>
          Test Cases
        </Typography>
        {result ? <Chip size="small" color="success" label={`${result.test_case_document.length} generated`} /> : null}
        <Box sx={{ flex: 1 }} />
        <Button
          variant="outlined"
          startIcon={workbookLoading ? <CircularProgress size={16} /> : <DownloadRoundedIcon />}
          disabled={!result || workbookLoading}
          onClick={onDownloadWorkbook}
        >
          Export workbook
        </Button>
        <Button
          variant="contained"
          startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <AutoAwesomeRoundedIcon />}
          disabled={!canGenerate}
          onClick={generate}
        >
          Generate test cases
        </Button>
      </Stack>

      {!requestPayload ? (
        <Alert severity="info">Validated mapping SQL is required before test-case generation.</Alert>
      ) : null}
      {statusMessage ? <Alert severity="success" sx={{ mb: 2 }}>{statusMessage}</Alert> : null}
      {error ? <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert> : null}

      {result ? (
        <Stack spacing={2}>
          <Box>
            <Typography variant="subtitle2" sx={{ fontWeight: 800, mb: 1 }}>
              Test groups
            </Typography>
            <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap", gap: 1 }}>
              {result.test_groups.map((group) => (
                <Chip
                  key={group.group}
                  label={`${group.group}: ${group.target_columns.length} columns`}
                  variant="outlined"
                />
              ))}
            </Stack>
          </Box>
          <Divider />
          <Box>
            <Typography variant="subtitle2" sx={{ fontWeight: 800, mb: 1 }}>
              Generated cases
            </Typography>
            <Stack spacing={1.25}>
              {result.test_case_document.map((item) => (
                <Box key={item.test_case_id} sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5 }}>
                  <Stack direction="row" spacing={1} sx={{ mb: 0.75, flexWrap: "wrap", alignItems: "center" }}>
                    <Typography sx={{ fontWeight: 800 }}>{item.target_attribute}</Typography>
                    <Chip size="small" label={item.test_type} />
                    <Chip size="small" variant="outlined" label={item.group} />
                  </Stack>
                  <Typography variant="body2" sx={{ mb: 0.75 }}>{item.test_case_description}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    Sources: {item.source_columns || "n/a"} · Expected: {item.expected_target_value || "n/a"}
                  </Typography>
                </Box>
              ))}
            </Stack>
          </Box>
          {result.seed_files.length ? (
            <>
              <Divider />
              <Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 800, mb: 1 }}>
                  Seed files
                </Typography>
                <Stack spacing={1}>
                  {result.seed_files.map((file) => (
                    <Box key={file.file_path} sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5 }}>
                      <Typography sx={{ fontWeight: 800 }}>{file.file_path}</Typography>
                      <Typography component="pre" sx={{ whiteSpace: "pre-wrap", fontSize: 12, mt: 1, maxHeight: 180, overflow: "auto" }}>
                        {file.content}
                      </Typography>
                    </Box>
                  ))}
                </Stack>
              </Box>
            </>
          ) : null}
        </Stack>
      ) : null}
    </Box>
  );
}
