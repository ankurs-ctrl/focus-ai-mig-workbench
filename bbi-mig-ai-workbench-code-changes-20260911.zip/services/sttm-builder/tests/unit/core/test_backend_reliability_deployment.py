import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[5]


def test_semantic_version_uses_insert_select_for_json_binds() -> None:
    sql = (
        ROOT
        / "infra/snowflake/fir_system/procedures/sp-fir-create-semantic-version.sql"
    ).read_text()
    insert = sql[sql.index("INSERT INTO __STTM_METADATA_NAMESPACE__.TBL_SEMANTIC_VIEW_VERSIONS") :]
    assert ") SELECT" in insert
    assert ") VALUES" not in insert
    assert "PARSE_JSON(?)" in insert


def test_safe_powershell_renderer_exports_every_service_placeholder() -> None:
    script = (ROOT / "scripts/deploy_spcs_client_snow_safe.ps1").read_text()
    exported = set(re.findall(r"\$env:([A-Z][A-Z0-9_]*)\s*=", script))
    for relative in (
        "infra/snowflake/service-specs/webapp.yaml.tmpl",
        "infra/snowflake/service-specs/automap-worker.yaml.tmpl",
    ):
        template = (ROOT / relative).read_text()
        placeholders = set(re.findall(r"\$\{([A-Z][A-Z0-9_]*)\}", template))
        assert placeholders <= exported, sorted(placeholders - exported)


def test_all_spcs_renderers_supply_catalog_cache_configuration() -> None:
    required = {
        "TABLE_SELECTION_CACHE_SECONDS",
        "TABLE_SELECTION_STALE_IF_ERROR_SECONDS",
    }
    for relative in (
        "scripts/deploy_spcs_client_snow.sh",
        "scripts/deploy_spcs_client_direct.sh",
        "scripts/deploy_spcs_client_snow.ps1",
        "scripts/deploy_spcs_client_snow_safe.ps1",
        "scripts/deploy_spcs_client_snow_single_service.ps1",
        "deploy_bbi_workbench_v2.sh",
    ):
        script = (ROOT / relative).read_text()
        assert required <= set(re.findall(r"TABLE_SELECTION_[A-Z_]+", script)), relative


def test_spcs_proxy_buffers_json_but_not_agent_streams() -> None:
    config = (ROOT / "nginx/conf.d/default.conf").read_text()
    stream_location = config[
        config.index("location ~ ^/api/v1/") : config.index("location /api/")
    ]
    json_location = config[
        config.index("location /api/") : config.index("location /_next/static/")
    ]
    assert "proxy_buffering off;" in stream_location
    assert "gzip off;" in stream_location
    assert "proxy_buffering on;" in json_location
    assert "proxy_set_header Connection \"\";" in json_location


def test_automap_deploy_defaults_use_bounded_six_target_batches() -> None:
    files = (
        "infra/snowflake/env/client.env.example",
        "scripts/deploy_spcs_client_snow.sh",
        "scripts/deploy_spcs_client_snow.ps1",
        "scripts/deploy_spcs_client_snow_safe.ps1",
        "scripts/deploy_spcs_client_snow_single_service.ps1",
        "deploy_bbi_workbench_v2.sh",
    )
    for relative in files:
        content = (ROOT / relative).read_text()
        defaults = [
            line
            for line in content.splitlines()
            if "AUTO_MAPPING_PROXY_BATCH_SIZE" in line and "=" in line
        ]
        assert any("6" in line and "17" not in line for line in defaults), relative


def test_low_confidence_review_is_enabled_in_backend_defaults() -> None:
    config = (ROOT / "services/sttm-builder/app/core/config.py").read_text()
    match = re.search(
        r"low_confidence_join_review_v1: bool = Field\(\s*default=(True|False)",
        config,
    )
    assert match and match.group(1) == "True"


def test_interactive_sttm_load_defers_and_does_not_cache_heavy_history() -> None:
    service = (ROOT / "services/sttm-builder/app/core/project_service.py").read_text()
    router = (ROOT / "services/sttm-builder/app/routers/projects.py").read_text()

    assert "versions=self._list_versions(sttm_id) if include_history else []" in service
    assert "agent_artifacts=self._list_artifacts(sttm_id) if include_history else []" in service
    assert "settings.backend_read_cache_v1 and not include_history" in router
    assert "projects:sttm-detail:" in router
