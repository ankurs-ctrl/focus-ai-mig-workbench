"""Summarize captured model contracts without printing source profiles or project values."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/sttm-builder"))
from automap_message_sizes import expand_packet


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--summary-only", action="store_true", help="Print identities/counts only, never mapping bodies or literals")
    parser.add_argument("--request-id", help="Restrict output to one exact application request")
    parser.add_argument("--context-summary", action="store_true", help="Summarize actual context and evidence without literal values")
    args = parser.parse_args()
    for path in sorted(args.directory.glob("*.json"), key=lambda item: item.stat().st_mtime_ns):
        artifact = json.loads(path.read_text(encoding="utf-8"))
        payload = artifact["payload"]
        text = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        if hashlib.sha256(text.encode()).hexdigest() != artifact["sha256"]:
            raise ValueError(f"Audit content hash mismatch: {path.name}")
        summary = {key: artifact[key] for key in ("audit_id", "stage", "chars", "bytes")}
        summary["agent"] = payload["agent"]
        summary["modified_at"] = path.stat().st_mtime
        if artifact["stage"] == "request":
            message = payload["request"]["messages"][-1]
            packet = json.loads(message["content"][0]["text"])
            packet = expand_packet(packet)
            if args.request_id and packet.get("request_id") != args.request_id:
                continue
            context = packet.get("context", {})
            reads = packet.get("retrieved_auto_map_context", [])
            summary.update(request_id=packet.get("request_id"), sttm_id=context.get("sttm_id"))
            summary.update(targets=[item.get("target_attribute") for item in packet.get("data", {}).get("attributes", [])],
                           context_sections=list(context), read_operations=dict(Counter(item.get("request", {}).get("operation") for item in reads)),
                           evidence_counts=[{"target": item.get("request", {}).get("target"),
                                             "category": item.get("request", {}).get("category"),
                                             "result_keys": list(item.get("result", {}))}
                                            for item in reads if item.get("request", {}).get("operation") == "evidence"])
            if args.context_summary:
                registry = (context.get("auto_map_retrieval") or {}).get("relation_registry") or {}
                summary["context_audit"] = {
                    "project_id": context.get("project_id"),
                    "project_fields_present": [key for key, value in (context.get("project_context") or {}).items() if value],
                    "project_context_status": context.get("project_context_status"),
                    "mapping_intent_fields": [key for key, value in (context.get("mapping_intent") or {}).items() if value],
                    "current_row_count": len(context.get("current_mapping_rows") or []),
                    "population_fields": list(context.get("population") or {}),
                    "relations": len(registry),
                    "selectable_relations": sum(bool(item.get("selectable")) for item in registry.values()),
                    "value_bindings": [{key: item.get(key) for key in ("binding_id", "attribute_name", "is_placeholder", "resolution_status", "allow_project_specific_value")}
                                       for item in context.get("value_bindings") or []],
                    "discoveries": [{"target": item.get("request", {}).get("target"),
                                     "result_keys": list((item.get("result") or {}).get("data") or {}),
                                     "category_counts": {key: len(value) for key, value in ((item.get("result") or {}).get("data") or {}).items() if isinstance(value, (list, dict))},
                                     "diagnostics": ((item.get("result") or {}).get("data") or {}).get("diagnostics")}
                                    for item in reads if item.get("request", {}).get("operation") == "discover"],
                    "evidence_reads": [{"target": item.get("request", {}).get("target"), "category": item.get("request", {}).get("category"),
                                        "records": len(item.get("result")) if isinstance(item.get("result"), list) else None}
                                       for item in reads if item.get("request", {}).get("operation") == "evidence"],
                    "column_reads": [{"relation": item.get("request", {}).get("relation"), "column": item.get("request", {}).get("column")}
                                     for item in reads if item.get("request", {}).get("operation") == "column"],
                }
        else:
            if args.request_id or args.context_summary:
                continue
            from app.core.snowflake_agent import SnowflakeAgentClient
            from app.core.sttm_builder import _extract_json_object
            response, _ = SnowflakeAgentClient._extract_text_and_thread(payload["response"], None)
            try:
                parsed = json.loads(_extract_json_object(response))
                result = parsed.get("data", {}).get("result", {})
                summary.update(delegation=parsed.get("meta", {}).get("delegation"),
                               mappings=result.get("mappings"), rules=result.get("rules"), error=parsed.get("error"))
            except (ValueError, TypeError):
                summary["invalid_structured_response"] = True
        if args.summary_only:
            mappings = summary.pop("mappings", None) or {}
            rules = summary.pop("rules", None) or {}
            summary.pop("error", None)
            summary.pop("evidence_counts", None)
            summary["mapping_count"] = len(mappings)
            summary["rule_count"] = len(rules)
            records = mappings.values() if isinstance(mappings, dict) else mappings
            summary["classifications"] = dict(Counter(
                item.get("transformation_classification", "unspecified")
                for item in records if isinstance(item, dict)
            ))
        print(json.dumps(summary, ensure_ascii=True), flush=True)


if __name__ == "__main__":
    main()