from __future__ import annotations

import os

import snowflake.connector


def normalize_host(host: str, account: str) -> str:
    normalized_host = (host or "").strip().replace("_", "-").lower()
    if normalized_host.endswith(".snowflakecomputing.com"):
        return normalized_host

    normalized_account = (account or "").strip().replace("_", "-").lower()
    if normalized_account.endswith(".snowflakecomputing.com"):
        return normalized_account
    if normalized_account:
        return f"{normalized_account}.snowflakecomputing.com"
    return normalized_host


def quote_identifier(name: str) -> str:
    return f'"{name.replace("\"", "\"\"")}"'


def main() -> int:
    account = os.environ.get("SNOWFLAKE_ACCOUNT", "").strip()
    user = os.environ.get("SNOWFLAKE_USER", "").strip()
    password = os.environ.get("SNOWFLAKE_PASSWORD", "").strip()
    warehouse = os.environ.get("SNOWFLAKE_WAREHOUSE", "").strip()
    database = os.environ.get("SNOWFLAKE_DATABASE", "").strip()
    schema = os.environ.get("SNOWFLAKE_SCHEMA", "").strip()
    role = os.environ.get("SNOWFLAKE_ROLE", "").strip()
    raw_authenticator = os.environ.get("SNOWFLAKE_AUTHENTICATOR", "").strip()
    authenticator = raw_authenticator or ("snowflake" if password else "externalbrowser")
    host = normalize_host(os.environ.get("SNOWFLAKE_HOST", ""), account)

    if not account or not user:
        raise SystemExit("SNOWFLAKE_ACCOUNT and SNOWFLAKE_USER are required.")

    kwargs = {
        "account": account,
        "host": host,
        "user": user,
        "authenticator": authenticator,
    }
    if warehouse:
        kwargs["warehouse"] = warehouse
    if database:
        kwargs["database"] = database
    if schema:
        kwargs["schema"] = schema
    if role:
        kwargs["role"] = role
    if authenticator.lower() not in {"externalbrowser", "oauth"}:
        if not password:
            raise SystemExit("SNOWFLAKE_PASSWORD is required for non-externalbrowser auth.")
        kwargs["password"] = password

    print(f"Connecting with authenticator={authenticator} host={host}")
    with snowflake.connector.connect(**kwargs) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                  CURRENT_USER(),
                  CURRENT_ROLE(),
                  CURRENT_WAREHOUSE(),
                  CURRENT_DATABASE(),
                  CURRENT_SCHEMA()
                """
            )
            print("Session:", cursor.fetchone())

            cursor.execute("SHOW DATABASES")
            databases = cursor.fetchmany(5)
            print(f"Visible databases preview: {len(databases)} rows")
            if databases:
                first_database = databases[0][1]
                print("First database:", first_database)

                cursor.execute(
                    f"SHOW SCHEMAS IN DATABASE {quote_identifier(first_database)}"
                )
                schemas = cursor.fetchmany(5)
                print(f"Schemas preview in {first_database}: {len(schemas)} rows")
                if schemas:
                    first_schema = schemas[0][1]
                    print("First schema:", first_schema)
                    cursor.execute(
                        "SHOW TABLES IN SCHEMA "
                        f"{quote_identifier(first_database)}.{quote_identifier(first_schema)}"
                    )
                    tables = cursor.fetchmany(5)
                    print(
                        f"Tables preview in {first_database}.{first_schema}: {len(tables)} rows"
                    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
