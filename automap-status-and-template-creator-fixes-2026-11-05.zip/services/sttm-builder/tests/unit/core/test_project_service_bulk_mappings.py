import json
from types import SimpleNamespace

from app.core.project_service import ProjectService


class _Query:
    def collect(self):
        return []


class _Session:
    def __init__(self):
        self.calls = []

    def sql(self, query, params=None):
        self.calls.append((query, params))
        return _Query()


def test_mapping_replacement_uses_one_delete_and_one_bound_bulk_insert() -> None:
    session = _Session()
    service = ProjectService.__new__(ProjectService)
    service._session = session
    service._settings = SimpleNamespace(
        sttm_mapping_bulk_write_v1=True,
        snowflake_sttm_attributes_table="DB.META.TBL_STTM_ATTRIBUTES",
        qualify_metadata_object_name=lambda value: value,
    )
    columns = {
        "STTM_ID",
        "ATTRIBUTE_NAME",
        "ATTRIBUTE_TYPE",
        "SOURCE_COLUMN",
        "DATA_TYPE",
        "TRANSFORMATION_LOGIC",
        "DESCRIPTION",
        "CONDITION",
        "CALCULATION",
        "MEASURE",
        "AGGREGATION",
        "IS_DRAFT",
        "ACTOR_USER_ID",
        "LAST_MODIFIED_BY",
    }
    service._table_columns = lambda _table: columns
    service._column_type = lambda _table, column: (
        "VARCHAR(12)" if column == "SOURCE_COLUMN" else "VARCHAR"
    )

    count = service._replace_mapping_rows(
        project_id="project-1",
        sttm_id="sttm-1",
        snapshot={
            "target_table": {"database": "DB", "schema": "TGT", "table": "CUSTOMER"},
            "mapping_rows": [
                {
                    "id": "mapping-1",
                    "target_column": "CUSTOMER_ID",
                    "target_type": "VARCHAR",
                    "source_columns": ["DB.SRC.CONTACTS.ID"],
                    "status": "mapped",
                    "validation": {"definitionSignature": "exact-row", "contextSignature": "exact-context", "result": "valid"},
                    "ai_candidates": [{"candidate_id": "option-1", "confidence_score": .42,
                        "confidence_reason": "Business evidence", "source_attributes": ["DB.SRC.CONTACTS.ID"],
                        "validation_status": "valid", "preprocessing_rule_type": "Direct"}],
                    "selected_ai_candidate_id": "option-1", "ai_review_status": "unreviewed",
                    "ai_undo_snapshot": {"source_columns": [], "status": "UNMAPPED"},
                }
            ],
        },
        session_id="session-1",
        semantic_bundle_id="bundle-1",
        semantic_bundle_hash="hash-1",
        user_id="USER_A",
    )

    assert count == 1
    assert len(session.calls) == 2
    assert "DELETE FROM" in session.calls[0][0]
    insert_sql, insert_params = session.calls[1]
    assert "FLATTEN(INPUT => PARSE_JSON(?))" in insert_sql
    assert "CUSTOMER_ID" not in insert_sql
    persisted = json.loads(insert_params[0])
    assert persisted[0]["attribute_name"] == "CUSTOMER_ID"
    assert persisted[0]["source_column"] == "DB.SRC.CONTA"
    assert persisted[0]["condition"]["semantic_bundle_hash"] == "hash-1"

    assert persisted[0]["condition"]["ai_candidates"][0]["confidence_reason"] == "Business evidence"
    assert persisted[0]["condition"]["ai_candidates"][0]["confidence_score"] == .42
    assert persisted[0]["condition"]["selected_ai_candidate_id"] == "option-1"
    assert persisted[0]["condition"]["ai_review_status"] == "unreviewed"
    assert persisted[0]["condition"]["ai_undo_snapshot"]["status"] == "UNMAPPED"


    assert persisted[0]["condition"]["validation"] == {"definitionSignature": "exact-row", "contextSignature": "exact-context", "result": "valid"}


def test_selection_validation_and_row_proofs_survive_snapshot_model_without_certifying_other_rows() -> None:
    from app.schema.workspace_context import WorkbenchContextSnapshotV1
    receipt = {"kind": "source_selection_validation", "contextSignature": "context", "previewKey": "preview", "valid": True, "synced": True}
    proof = {"definitionSignature": "row", "contextSignature": "context", "result": "valid"}
    snapshot = WorkbenchContextSnapshotV1.model_validate({
        "project_id": "project", "validation_values_signature": "values", "validation_history": [receipt],
        "mapping_rows": [
            {"id": "known", "target_column": "NAME", "source_columns": ["source.NAME"], "status": "MAPPED", "validation": proof},
            {"id": "unknown", "target_column": "OTHER", "source_columns": ["source.OTHER"], "status": "NEEDS_VALIDATION"},
        ],
    }).model_dump(mode="json")
    assert snapshot["validation_values_signature"] == "values"
    assert snapshot["validation_history"] == [receipt]
    assert snapshot["mapping_rows"][0]["validation"] == proof
    assert "validation" not in snapshot["mapping_rows"][1]
    assert snapshot["mapping_rows"][1]["status"] == "NEEDS_VALIDATION"
