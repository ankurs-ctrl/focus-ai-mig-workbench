import type { ChatMessage } from "@/features/sttm/types/sttm.types";

export type StoredChatSession = {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: number;
  mode?: "quick" | "deep";
  backendConversationId?: string | null;
  projectId?: string | null;
  sttmId?: string | null;
  storageScope?: string;
  pinned?: boolean;
};

export const AI_CHAT_SESSIONS_STORAGE_KEY = "sttm-ai-chat-sessions";

function storageKey(scope: string) {
  return `${AI_CHAT_SESSIONS_STORAGE_KEY}::${scope || "anonymous::new::new"}`;
}

export function createChatSessionId() {
  return `session_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export function deriveSessionTitle(messages: ChatMessage[]) {
  const userMessage = messages.find((message) => message.role === "user");
  if (!userMessage?.content.trim()) return "New chat";
  const content = userMessage.content.toLowerCase();
  if (/\b(continue|complete|finish)\b/.test(content) && /\b(migration|mapping|draft)\b/.test(content)) {
    return /\bsql\b/.test(content) && /\b(preview|sample results?)\b/.test(content)
      ? "Complete mapping SQL and preview" : "Complete migration mapping";
  }
  if (/\b(summarize|summarise|review)\b/.test(content) && /\b(transcript|call notes?)\b/.test(content)) {
    return "Review client call transcript";
  }
  if (/\b(recommend|find|identify)\b/.test(content) && /\b(source|derived sources?)\b/.test(content)) {
    return "Review source candidates";
  }
  const first = userMessage.content.trim().replace(/\s+/g, ' ').split(/[.!?;\n]/, 1)[0]
    .replace(/^(?:(?:please|can you|could you)\s+|i (?:want|need|would like) (?:you )?to\s+)+/i, '')
    .replace(/\b(?:a new|an existing|the existing)\b\s*/gi, '');
  const concise = first.split(' ').slice(0, 9).join(' ').trim().replace(/[, :\-]+$/, '');
  const title = concise.length > 72 ? concise.slice(0, 72).replace(/\s+\S*$/, '') : concise;
  return title ? title[0].toUpperCase() + title.slice(1) : 'New chat';
}

export function formatSessionRelativeTime(timestamp: number) {
  const diffMs = Date.now() - timestamp;
  const minutes = Math.floor(diffMs / 60_000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? "" : "s"} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

export function loadStoredChatSessions(scope: string): StoredChatSession[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(storageKey(scope));
    if (!raw) return [];
    const parsed = JSON.parse(raw) as StoredChatSession[];
    return Array.isArray(parsed) ? parsed.map((session) => ({
      ...session,
      storageScope: scope,
      projectId: Object.prototype.hasOwnProperty.call(session, 'projectId')
        ? session.projectId
        : (() => { const segment = scope.split('::')[1]; return segment && segment !== 'new' && segment !== 'general' ? segment : null; })(),
    })) : [];
  } catch {
    return [];
  }
}

export function loadAllStoredChatSessions(userId: string): StoredChatSession[] {
  if (typeof window === 'undefined') return [];
  const prefix = `${AI_CHAT_SESSIONS_STORAGE_KEY}::${userId}::`;
  const sessions: StoredChatSession[] = [];
  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);
    if (key?.startsWith(prefix)) sessions.push(...loadStoredChatSessions(key.slice(`${AI_CHAT_SESSIONS_STORAGE_KEY}::`.length)));
  }
  return Array.from(new Map(sessions.map((session) => [session.id, session])).values())
    .sort((left, right) => right.updatedAt - left.updatedAt);
}

export function persistChatSessions(scope: string, sessions: StoredChatSession[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(storageKey(scope), JSON.stringify(sessions.slice(0, 30)));
  } catch {
    // Ignore quota errors in mock/dev mode.
  }
}
