"use client";
import { AiaBox } from '@/components/ui';
import { SqlEditor } from '@/components/sql/sql-editor';
import { AiaText } from '@/components/ui/aia-text';
import React, { useEffect, useState } from "react";

import { AllInclusiveIcon, ArrowBackRoundedIcon } from '@/utils/icons';
import { textStyleCssVars } from '@/config/typography-tokens';

import type { JoinConfig, TableMeta } from "@/features/sttm/types/sttm.types";
import { AiaButton } from "@/components/ui/aia-button";
import { AiaChip } from "@/components/ui/aia-chip";
import { AiaSelect } from "@/components/ui/aia-select";
import { AiaAutocomplete } from "@/components/ui/aia-auto-complete";
import { buildRelationDisplayAliases, formatRelationDisplayText, rewriteLegacyAliasReference } from "@/features/sttm/mapping/relation-alias";
import {
  blankJoinGroup,
  blankJoinTerm,
  buildJoinPredicateContext,
  clearJoinTermColumn,
  formatJoinTerms,
  joinTermsHaveComparison,
  joinTermsHaveGroup,
  parseJoinPredicate,
  type JoinTerm,
} from "@/features/sttm/source-target/join-predicate";

function ConnectorToggle({
  value,
  label,
  onChange,
}: {
  value: "AND" | "OR";
  label: string;
  onChange: (connector: "AND" | "OR") => void;
}) {
  return (
    <AiaBox sx={{ gridColumn: "1 / -1", display: "flex", justifyContent: "center", py: 0.75 }} role="group" aria-label={label}>
      {(["AND", "OR"] as const).map((connector) => {
        const active = value === connector;
        return (
          <AiaButton
            key={connector}
            size="small"
            variant={active ? "contained" : "outlined"}
            color="primary"
            onClick={() => onChange(connector)}
            aria-pressed={active}
            sx={{ minWidth: 40, height: 22, px: 0.75, fontSize: 10, fontWeight: 700, lineHeight: 1, ml: connector === "OR" ? 0.5 : 0 }}
            {...(active
              ? {
                  customBackgroundColor: "var(--aia-primary-bg-color)",
                  customColor: "var(--aia-primary-bg-text-color)",
                  customBorderColor: "var(--aia-primary-bg-color)",
                  customHoverBackgroundColor: "var(--aia-primary-bg-hover-color)",
                }
              : { customBorderColor: "var(--aia-primary-bg-color)", customColor: "var(--aia-primary-bg-color)" })}
          >
            {connector}
          </AiaButton>
        );
      })}
    </AiaBox>
  );
}

function JoinConditionEditor({
  rows,
  onChange,
  depth,
  allowEmpty,
  leftColumnOptions,
  rightColumnOptions,
  operatorOptions,
  leftTableId,
  rightTableId,
  gridColumns,
  rowSx,
  operatorSx,
  actionSx,
}: {
  rows: JoinTerm[];
  onChange: (rows: JoinTerm[]) => void;
  depth: number;
  allowEmpty: boolean;
  leftColumnOptions: Array<{ label: string; value: string }>;
  rightColumnOptions: Array<{ label: string; value: string }>;
  operatorOptions: Array<{ label: string; value: string }>;
  leftTableId: string;
  rightTableId: string;
  gridColumns: string;
  rowSx: Record<string, unknown>;
  operatorSx: Record<string, unknown>;
  actionSx: Record<string, unknown>;
}) {
  const replace = (index: number, patch: Partial<JoinTerm>) => {
    onChange(rows.map((row, rowIndex) => rowIndex === index ? { ...row, ...patch } : row));
  };
  const remove = (index: number) => {
    const next = rows.filter((_, rowIndex) => rowIndex !== index);
    onChange(next.length || allowEmpty ? next : [blankJoinTerm()]);
  };
  const append = (term: JoinTerm) => onChange([...rows, term]);
  const addGroup = (index: number) => {
    const current = rows[index];
    if (!current.children && !current.leftColumn && !current.rightColumn) {
      onChange(rows.map((row, rowIndex) => rowIndex === index ? { ...blankJoinGroup(), connector: row.connector } : row));
      return;
    }
    const next = [...rows];
    next.splice(index + 1, 0, blankJoinGroup());
    onChange(next);
  };
  return (
    <>
      {rows.map((row, index) => (
        <React.Fragment key={row.id}>
          {index > 0 && (
            <ConnectorToggle value={row.connector} label={`Combine condition ${index + 1}`} onChange={(connector) => replace(index, { connector })} />
          )}
          {row.children ? (
            <AiaBox sx={{ gridColumn: "1 / -1", border: "1px solid #e5e7eb", borderRadius: 1, p: 1.25, backgroundColor: "#f8fafc" }}>
              <AiaBox sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                <AiaText sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.06em", color: "#64748b" }}>GROUP</AiaText>
                <AiaBox sx={{ display: "flex", gap: 0.75 }}>
                  <AiaButton variant="outlined" size="small" color="primary" onClick={() => remove(index)} sx={actionSx} customBorderColor="var(--aia-button-color)" customColor="var(--aia-button-color)" aria-label="Remove group">✕</AiaButton>
                  <AiaButton variant="outlined" size="small" color="primary" onClick={() => { const next = [...rows]; next.splice(index + 1, 0, blankJoinTerm()); onChange(next); }} sx={{ ...actionSx, fontSize: 20, fontWeight: 600 }} customBorderColor="var(--aia-button-color)" customColor="var(--aia-button-color)" aria-label="Add condition after group">+</AiaButton>
                  {depth < 3 && (
                    <AiaButton variant="outlined" size="small" color="primary" onClick={() => { const next = [...rows]; next.splice(index + 1, 0, blankJoinGroup()); onChange(next); }} sx={{ ...actionSx, fontSize: 11, fontWeight: 700, width: "auto", minWidth: 28, px: 0.5 }} customBorderColor="var(--aia-button-color)" customColor="var(--aia-button-color)" aria-label="Add group after this group">()</AiaButton>
                  )}
                </AiaBox>
              </AiaBox>
              <AiaBox sx={{ display: "grid", gridTemplateColumns: gridColumns, columnGap: 1.5 }}>
                <JoinConditionEditor
                  rows={row.children}
                  depth={depth + 1}
                  allowEmpty
                  onChange={(children) => children.length ? replace(index, { children }) : remove(index)}
                  leftColumnOptions={leftColumnOptions}
                  rightColumnOptions={rightColumnOptions}
                  operatorOptions={operatorOptions}
                  leftTableId={leftTableId}
                  rightTableId={rightTableId}
                  gridColumns={gridColumns}
                  rowSx={rowSx}
                  operatorSx={operatorSx}
                  actionSx={actionSx}
                />
              </AiaBox>
            </AiaBox>
          ) : (
            <AiaBox sx={rowSx}>
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaAutocomplete hideLabel options={leftColumnOptions} value={row.leftColumn} placeholder="Search column…" disabled={!leftTableId} fullWidth onChange={(val) => replace(index, { leftColumn: Array.isArray(val) ? val[0] ?? "" : String(val) })} />
              </AiaBox>
              <AiaBox sx={{ width: 108, minWidth: 108, maxWidth: 108 }}>
                <AiaSelect options={operatorOptions} value={row.operator} placeholder="Condition" fullWidth sx={operatorSx} onChange={(val) => replace(index, { operator: String(val) })} />
              </AiaBox>
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaAutocomplete hideLabel options={rightColumnOptions} value={row.rightColumn} placeholder="Search column…" disabled={!rightTableId} fullWidth onChange={(val) => replace(index, { rightColumn: Array.isArray(val) ? val[0] ?? "" : String(val) })} />
              </AiaBox>
              <AiaBox sx={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 0.75 }}>
                <AiaButton variant="outlined" size="small" color="primary" onClick={() => remove(index)} disabled={!allowEmpty && rows.length <= 1} sx={actionSx} customBorderColor="var(--aia-button-color)" customColor="var(--aia-button-color)" aria-label="Remove condition">✕</AiaButton>
                <AiaButton variant="outlined" size="small" color="primary" onClick={() => append(blankJoinTerm())} sx={{ ...actionSx, fontSize: 20, fontWeight: 600 }} customBorderColor="var(--aia-button-color)" customColor="var(--aia-button-color)" aria-label="Add condition">+</AiaButton>
                {depth < 3 && (
                  <AiaButton variant="outlined" size="small" color="primary" onClick={() => addGroup(index)} sx={{ ...actionSx, fontSize: 11, fontWeight: 700, width: "auto", minWidth: 28, px: 0.5 }} customBorderColor="var(--aia-button-color)" customColor="var(--aia-button-color)" aria-label="Add grouped conditions">()</AiaButton>
                )}
              </AiaBox>
            </AiaBox>
          )}
        </React.Fragment>
      ))}
    </>
  );
}

function DrivingChip() {
  return (
    <AiaChip
      label="Driving"
      size="small"
      color="warning"
      customBackgroundColor="#fef08a"
      customColor="#854d0e"
      customBorderColor="#fde047"
      sx={{
        height: 22,
        fontSize: 10,
        fontWeight: 700,
        "& .MuiChip-label": { px: 0.75, py: 0 },
      }}
    />
  );
}

function DerivedChip() {
  return <AiaChip label="CTE" size="small" color="success" />;
}

interface JoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBack?: () => void;
  tables: TableMeta[];
  initialLeftTableId?: string;
  initialRightTableId?: string;
  drivingTableIdOverride?: string | null;
  editingJoin?: JoinConfig | null;
  confirmAddsJoin?: boolean;
  allowSqlPredicate?: boolean;
  previewRelations?: Array<{ identity: string; alias: string; displaySeed?: string | null }>;
  onConfirm: (join: JoinConfig) => void;
  requireJoinTypeSelection?: boolean;
}

export function JoinModal(props: JoinModalProps) {
  if (!props.isOpen) return null;
  const identity = JSON.stringify([props.editingJoin ?? null, props.initialLeftTableId, props.initialRightTableId]);
  return <JoinModalContent key={identity} {...props} />;
}

function JoinModalContent({
  onClose,
  onBack,
  tables,
  initialLeftTableId,
  initialRightTableId,
  drivingTableIdOverride,
  editingJoin,
  confirmAddsJoin = false,
  allowSqlPredicate = false,
  previewRelations = [],
  onConfirm,
  requireJoinTypeSelection = false,
}: JoinModalProps) {
  // New joins default to LEFT JOIN; editing keeps the join's own type.
  const [joinType, setJoinType] = useState<"INNER" | "LEFT" | "RIGHT" | "FULL" | "">(
    editingJoin?.joinType ?? (requireJoinTypeSelection ? "" : "LEFT")
  );

  // New joins start from the driving table on the left (unless it is already the right table).
  const initialLeftTableIdValue = editingJoin?.leftTableId
    ?? initialLeftTableId
    ?? (drivingTableIdOverride && drivingTableIdOverride !== initialRightTableId ? drivingTableIdOverride : "");
  const initialRightTableIdValue = editingJoin?.rightTableId ?? initialRightTableId ?? "";
  const [leftTableId, setLeftTableId] = useState(initialLeftTableIdValue);
  const [rightTableId, setRightTableId] = useState(initialRightTableIdValue);
  const initialPredicateContext = () => buildJoinPredicateContext({
    leftTableId: initialLeftTableIdValue,
    rightTableId: initialRightTableIdValue,
    tables,
    previewRelations,
    displayAliases: buildRelationDisplayAliases(previewRelations),
  });
  const [rows, setRows] = useState<JoinTerm[]>(() => {
    if (editingJoin?.conditions?.length) {
      return editingJoin.conditions.map((condition, index) => ({
        ...blankJoinTerm(),
        leftColumn: condition.leftColumn ?? "",
        operator: condition.operator ?? "=",
        rightColumn: condition.rightColumn ?? "",
        connector: index > 0 && String(condition.connector ?? "").toUpperCase() === "OR" ? "OR" : "AND",
      }));
    }
    return parseJoinPredicate(editingJoin?.sqlPredicate ?? "", initialPredicateContext()) ?? [blankJoinTerm()];
  });
  const [sqlPredicate, setSqlPredicate] = useState(editingJoin?.sqlPredicate ?? "");
  const [predicateMode, setPredicateMode] = useState(() => {
    if (editingJoin?.conditions?.length) return false;
    if (parseJoinPredicate(editingJoin?.sqlPredicate ?? "", initialPredicateContext())) return false;
    return Boolean(editingJoin?.sqlPredicate?.trim());
  });
  const [columnSyncMessage, setColumnSyncMessage] = useState("");
  const displayAliases = buildRelationDisplayAliases(previewRelations);
  const runtimeAliases = new Map<string, string>();
  for (const relation of previewRelations) {
    const display = displayAliases.get(relation.alias.toUpperCase());
    if (display) runtimeAliases.set(display.toUpperCase(), relation.alias);
  }

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previous; };
  }, []);

  const drivingTableId = drivingTableIdOverride ?? null;

  // Driving table first in both Left and Right Table lists, then the rest A–Z by name.
  const tableOptions = tables
    .filter((t) => !!t.id)
    .sort(
      (a, b) =>
        Number(b.id === drivingTableId) - Number(a.id === drivingTableId)
        || (a.name || a.schema || "").localeCompare(b.name || b.schema || "", undefined, {
          sensitivity: "base",
          numeric: true,
        }),
    )
    .map((t) => {
      const schema = t.schema ?? "";
      const name = t.name ?? "";
      return {
        label: name || schema,
        value: t.id as string,
        badge: t.id === drivingTableId ? <DrivingChip /> : undefined,
      };
    });

  const predicateContext = buildJoinPredicateContext({
    leftTableId,
    rightTableId,
    tables,
    previewRelations,
    displayAliases,
  });
  const loadedRowsFromSql = !editingJoin?.conditions?.length
    && Boolean(parseJoinPredicate(editingJoin?.sqlPredicate ?? "", predicateContext));

  const openPredicateEditor = () => {
    if (predicateMode) {
      if (!sqlPredicate.trim()) {
        setRows([blankJoinTerm()]);
        setColumnSyncMessage("");
        setPredicateMode(false);
        return;
      }
      const parsed = parseJoinPredicate(sqlPredicate, predicateContext);
      if (!parsed) {
        setColumnSyncMessage("This ON clause stays in the editor. Column rows can show table.column comparisons combined with AND, OR, and parentheses.");
        return;
      }
      setRows(parsed);
      setColumnSyncMessage("");
      setPredicateMode(false);
      return;
    }
    setSqlPredicate(formatJoinTerms(rows, predicateContext));
    setColumnSyncMessage("");
    setPredicateMode(true);
  };

  const storedPredicate = sqlPredicate.trim().replace(/;\s*$/, "").trim();
  const parsedPredicate = predicateMode ? parseJoinPredicate(storedPredicate, predicateContext) : null;
  const activeRows = predicateMode ? parsedPredicate : rows;
  const grouped = activeRows ? joinTermsHaveGroup(activeRows) : false;

  const handleConfirm = () => {
    if (!leftTableId || !rightTableId || !joinType) return;
    if (predicateMode ? !storedPredicate : !joinTermsHaveComparison(rows)) return;
    const flatRows = (activeRows ?? []).filter((row) => !row.children && row.leftColumn && row.operator && row.rightColumn);

    const out: JoinConfig = {
      id:
        editingJoin?.id ??
        `${leftTableId}__${rightTableId}`, // one join per table-pair
      joinType,
      leftTableId,
      rightTableId,
      constraintName: editingJoin?.constraintName,
      source: editingJoin?.source ?? "USER_DEFINED",
      locked: false,
      sqlPredicate: activeRows
        ? (grouped ? formatJoinTerms(activeRows, predicateContext) : undefined)
        : storedPredicate,
      conditions: activeRows && !grouped ? flatRows.map((row) => ({
        leftColumn: row.leftColumn,
        operator: row.operator,
        rightColumn: row.rightColumn,
        connector: row.connector === "OR" ? "OR" : "AND" as const,
      })) : [],
    };

    onConfirm(out);
    onClose();
  };

  const isFormValid =
    !!joinType && !!leftTableId &&
    !!rightTableId &&
    (predicateMode ? Boolean(storedPredicate) : joinTermsHaveComparison(rows));

  const leftTable = tables.find((t) => t.id === leftTableId);
  const rightTable = tables.find((t) => t.id === rightTableId);
  const leftIsDerived = leftTable?.tag?.toLowerCase().includes("derived") ?? false;
  const rightIsDerived = rightTable?.tag?.toLowerCase().includes("derived") ?? false;

  const leftColumnOptions = (leftTable?.columns ?? [])
    .filter((c) => !!c.name)
    .map((c) => ({
      label: `${c.name} (${c.type ?? ""})`,
      value: c.name as string,
    }));
  const rightColumnOptions = (rightTable?.columns ?? [])
    .filter((c) => !!c.name)
    .map((c) => ({
      label: `${c.name} (${c.type ?? ""})`,
      value: c.name as string,
    }));

  const operatorOptions = [
    { label: "— op —", value: "" },
    { label: "=", value: "=" },
    { label: "≠", value: "!=" },
    { label: ">", value: ">" },
    { label: "<", value: "<" },
    { label: "≥", value: ">=" },
    { label: "≤", value: "<=" },
  ];

  const sectionLabelSx = {
    ...textStyleCssVars("caption"),
    fontWeight: 400,
    letterSpacing: "0.08em",
    textTransform: "uppercase" as const,
  };

  const joinFieldGap = 1.5;
  const joinFieldsWidth = "100%";
  const joinConditionColumnWidth = 108;
  const joinTableGridSx = {
    display: "grid",
    gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
    gap: joinFieldGap,
    width: "100%",
  } as const;
  const joinColumnGridColumns = `minmax(0, 1fr) ${joinConditionColumnWidth}px minmax(0, 1fr) max-content`;
  const joinConditionSelectSx = {
    width: joinConditionColumnWidth,
    minWidth: joinConditionColumnWidth,
    maxWidth: joinConditionColumnWidth,
    "& .MuiSelect-select": {
      textAlign: "left",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      paddingLeft: 1,
      paddingRight: "24px !important",
    },
  } as const;
  const joinColumnRowSubgridSx = {
    gridColumn: "1 / -1",
    display: "grid",
    gridTemplateColumns: "subgrid",
    alignItems: "center",
  } as const;
  const joinRowActionButtonSx = {
    minWidth: 28,
    width: 28,
    height: 28,
    p: 0,
    fontSize: 14,
    lineHeight: 1,
    boxShadow: "none",
  } as const;
  const joinRowActionButtonSxBase = {
    ...joinRowActionButtonSx,
    color: "var(--aia-button-color)",
    borderColor: "var(--aia-button-color)",
    "--aia-btn-stroke": "var(--aia-button-color)",
    "&:hover": {
      color: "var(--aia-button-color)",
      borderColor: "var(--aia-button-color)",
      backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
    },
  } as const;
  const joinCloseButtonSx = {
    ...joinRowActionButtonSx,
    color: "#94a3b8",
    border: "none",
    backgroundColor: "transparent",
    "&:hover": {
      color: "#94a3b8",
      border: "none",
      backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
    },
  } as const;

  return (
    <div className="join-modal-overlay">
      <div className="join-modal" role="dialog" aria-modal="true" aria-label="Establish Join">
        <AiaBox sx={{ p: 3, borderBottom: "1px solid #f1f5f9" }}>
          <AiaBox sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2 }}>
            <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1.5, minWidth: 0 }}>
              <AllInclusiveIcon
                sx={{
                  fontSize: "calc(var(--aia-card-title-font-size) + 2px)",
                  color: "var(--aia-card-title-color)",
                  flexShrink: 0,
                }}
                aria-hidden
              />
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText
                  sx={{
                    ...textStyleCssVars("cardTitle"),
                    textTransform: "capitalize",
                    letterSpacing: "-0.01em",
                  }}
                >
                  Establish Join
                </AiaText>
                <AiaText
                  sx={{
                    ...textStyleCssVars("secondaryText"),
                    mt: 0.25,
                    display: "block",
                  }}
                >
                  Define a relationship between two tables
                </AiaText>
              </AiaBox>
            </AiaBox>
            <AiaButton
              variant="text"
              size="small"
              onClick={onClose}
              sx={joinCloseButtonSx}
              aria-label="Close"
            >
              ✕
            </AiaButton>
          </AiaBox>
        </AiaBox>

        <AiaBox sx={{ p: 2, minHeight: 0, overflowY: "auto", '& .MuiInputBase-root': { fontSize: 13 }, '& .MuiAutocomplete-input': { padding: '4px !important' } }}>
          <AiaText sx={{ ...sectionLabelSx, mb: 1.25 }}>
            JOIN TYPE
          </AiaText>
          <AiaBox sx={{ display: "flex", gap: 1, flexWrap: "wrap", mb: 3 }}>
            {(["INNER", "LEFT", "RIGHT", "FULL"] as const).map((t) => {
              const active = joinType === t;
              return (
                <AiaButton
                  key={t}
                  size="small"
                  variant={active ? "contained" : "outlined"}
                  color="primary"
                  onClick={() => setJoinType(t)}
                  {...(active
                    ? {
                        customBackgroundColor: "var(--aia-primary-bg-color)",
                        customColor: "var(--aia-primary-bg-text-color)",
                        customBorderColor: "var(--aia-primary-bg-color)",
                        customHoverBackgroundColor: "var(--aia-primary-bg-hover-color)",
                      }
                    : {
                        customBorderColor: "var(--aia-primary-bg-color)",
                        customColor: "var(--aia-primary-bg-color)",
                      })}
                >
                  {t} JOIN
                </AiaButton>
              );
            })}
          </AiaBox>

          <AiaBox sx={{ width: joinFieldsWidth, pb: 2.5 }}>
            <AiaBox sx={joinTableGridSx}>
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText sx={{ ...sectionLabelSx, mb: 1 }}>
                  LEFT TABLE
                </AiaText>
                <AiaAutocomplete
                  hideLabel
                  options={tableOptions}
                  value={leftTableId}
                  disabled={predicateMode}
                  placeholder="Search table…"
                  onChange={(val) => {
                    setLeftTableId(Array.isArray(val) ? val[0] ?? "" : String(val));
                    setRows((prev) => clearJoinTermColumn(prev, "leftColumn"));
                  }}
                />
                <AiaText sx={{ mt: 0.65, fontSize: 11, color: "#64748b", overflowWrap: "anywhere" }}>
                  {leftIsDerived ? `CTE: ${leftTable?.name ?? ""}` : leftTable ? `${leftTable.database ?? ""}.${leftTable.schema ?? ""}.${leftTable.name ?? ""}`.replace(/\.+/g, ".") : "Select a table"}
                </AiaText>
                {leftIsDerived ? (
                  <AiaBox sx={{ mt: 0.9 }}>
                    <DerivedChip />
                  </AiaBox>
                ) : null}
              </AiaBox>

              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText sx={{ ...sectionLabelSx, mb: 1 }}>
                  RIGHT TABLE
                </AiaText>
                <AiaAutocomplete
                  hideLabel
                  options={tableOptions}
                  value={rightTableId}
                  disabled={predicateMode}
                  placeholder="Search table…"
                  onChange={(val) => {
                    setRightTableId(Array.isArray(val) ? val[0] ?? "" : String(val));
                    setRows((prev) => clearJoinTermColumn(prev, "rightColumn"));
                  }}
                />
                <AiaText sx={{ mt: 0.65, fontSize: 11, color: "#64748b", overflowWrap: "anywhere" }}>
                  {rightIsDerived ? `CTE: ${rightTable?.name ?? ""}` : rightTable ? `${rightTable.database ?? ""}.${rightTable.schema ?? ""}.${rightTable.name ?? ""}`.replace(/\.+/g, ".") : "Select a related table"}
                </AiaText>
                {rightIsDerived ? (
                  <AiaBox sx={{ mt: 0.9 }}>
                    <DerivedChip />
                  </AiaBox>
                ) : null}
              </AiaBox>
            </AiaBox>
          </AiaBox>

          <AiaBox
            sx={{
              width: "100%",
              borderBottom: "1px solid #e5e7eb",
              mb: 2.5,
            }}
          />

          {(allowSqlPredicate || editingJoin?.sqlPredicate) && (
            <AiaBox sx={{ mb: 2 }}>
              <AiaButton size="small" variant="outlined" onClick={openPredicateEditor}>
                {predicateMode ? 'Use column conditions' : 'Edit complete ON predicate'}
              </AiaButton>
              {!predicateMode && editingJoin?.sqlPredicate && !loadedRowsFromSql && <AiaText sx={{ fontSize: 12, mt: 1 }}>Saving will replace the original ON expression with the column conditions below.</AiaText>}
              {columnSyncMessage && <AiaText sx={{ fontSize: 12, mt: 1 }}>{columnSyncMessage}</AiaText>}
            </AiaBox>
          )}
          {(allowSqlPredicate || editingJoin?.sqlPredicate) && predicateMode ? (
            <AiaBox>
              <AiaText sx={{ ...sectionLabelSx, mb: 1 }}>Complete ON predicate</AiaText>
              <SqlEditor value={formatRelationDisplayText(sqlPredicate, displayAliases)}
                onChange={(value) => {
                  setColumnSyncMessage("");
                  setSqlPredicate(rewriteLegacyAliasReference(value, runtimeAliases));
                }}
                title="ON predicate" minHeight={160} maxHeight={240} showCopy />
              <AiaText sx={{ fontSize: 12, color: "#64748b", mt: 1 }}>
                Use the relation names shown in Query Preview. Saving updates the join and its SQL preview.
              </AiaText>
            </AiaBox>
          ) : <AiaBox
            sx={{
              maxHeight: 300,
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            <AiaBox
              sx={{
                display: "grid",
                gridTemplateColumns: joinColumnGridColumns,
                columnGap: joinFieldGap,
                width: "100%",
              }}
            >
              <AiaBox sx={{ ...joinColumnRowSubgridSx, mb: 1 }}>
                <AiaText sx={sectionLabelSx}>LEFT COLUMNS</AiaText>
                <AiaText sx={{ ...sectionLabelSx, justifySelf: "start", whiteSpace: "nowrap" }}>
                  CONDITIONS
                </AiaText>
                <AiaText sx={sectionLabelSx}>RIGHT COLUMNS</AiaText>
                <AiaBox />
              </AiaBox>

              <JoinConditionEditor
                rows={rows}
                onChange={setRows}
                depth={0}
                allowEmpty={false}
                leftColumnOptions={leftColumnOptions}
                rightColumnOptions={rightColumnOptions}
                operatorOptions={operatorOptions}
                leftTableId={leftTableId}
                rightTableId={rightTableId}
                gridColumns={joinColumnGridColumns}
                rowSx={joinColumnRowSubgridSx}
                operatorSx={joinConditionSelectSx}
                actionSx={joinRowActionButtonSxBase}
              />
            </AiaBox>
            <AiaText sx={{ fontSize: 12, color: "#64748b", mt: 1.25 }}>
              Click () to add a group. Comparisons inside that group keep their own AND and OR, as in ID = FAMILY_ID AND (DELETED = DELETED OR HOH = HOH).
            </AiaText>
          </AiaBox>}
        </AiaBox>

        <AiaBox sx={{ px: 3, py: 2.25, borderTop: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 1.5 }}>
          {onBack ? (
            <AiaButton
              variant="outlined"
              size="large"
              startIcon={<ArrowBackRoundedIcon sx={{ fontSize: 18 }} />}
              onClick={onBack}
              customBorderColor="var(--aia-primary-bg-color)"
              customColor="var(--aia-primary-bg-color)"
            >
              Back
            </AiaButton>
          ) : (
            <AiaBox />
          )}
          <AiaBox sx={{ display: "flex", justifyContent: "flex-end", gap: 1.5 }}>
          <AiaButton
            variant="outlined"
            size="large"
            onClick={onClose}
            customBorderColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-color)"
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            size="large"
            color="primary"
            onClick={handleConfirm}
            disabled={!isFormValid}
            customBackgroundColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-text-color)"
            customBorderColor="var(--aia-primary-bg-color)"
            customHoverBackgroundColor="var(--aia-primary-bg-hover-color)"
          >
            {editingJoin
              ? confirmAddsJoin
                ? "Update and Add Join"
                : "Update Join"
              : "Add Join"}
          </AiaButton>
          </AiaBox>
        </AiaBox>
      </div>
    </div>
  );
}
