from __future__ import annotations

from collections.abc import Callable
from typing import Any

from app.agent_runs.models import AgentCommand, AgentCommandReceipt
from app.agent_runs.repository import AgentRunRepository
from app.agent_tools.authorization import AgentToolAuthorizer


class CommandConflictError(RuntimeError):
    pass


class AgentCommandExecutor:
    """Execute one authorized mutation exactly once and persist its receipt.

    A repeated idempotency key returns the original result. Reusing a key with a
    different payload is rejected before any domain service is invoked.
    """

    def __init__(
        self,
        repository: AgentRunRepository,
        *,
        authorizer: AgentToolAuthorizer | None = None,
    ) -> None:
        self._repository = repository
        self._authorizer = authorizer or AgentToolAuthorizer()

    def execute(
        self,
        command: AgentCommand,
        mutation: Callable[[], Any],
        *,
        current_revision: Callable[[], int | None] | None = None,
        result_serializer: Callable[[Any], dict[str, Any]] | None = None,
    ) -> AgentCommandReceipt:
        self._authorizer.authorize(command)
        with self._repository.command_transaction():
            existing = self._repository.get_command_receipt(command.idempotency_key)
            if existing:
                if existing.payload_hash != command.payload_hash:
                    raise CommandConflictError("Idempotency key was reused with a different payload")
                return existing

            prior_revision = current_revision() if current_revision else None
            if command.expected_revision is not None and prior_revision != command.expected_revision:
                receipt = AgentCommandReceipt(
                    run_id=command.run_id,
                    command_id=command.command_id, idempotency_key=command.idempotency_key,
                    payload_hash=command.payload_hash, operation=command.operation,
                    status="CONFLICT", project_id=command.project_id, sttm_id=command.sttm_id,
                    prior_revision=prior_revision, safe_error="The draft changed after the migration step began.",
                )
                self._repository.save_command_receipt(receipt)
                raise CommandConflictError(receipt.safe_error)

            if command.dry_run:
                receipt = AgentCommandReceipt(
                    run_id=command.run_id,
                    command_id=command.command_id, idempotency_key=command.idempotency_key,
                    payload_hash=command.payload_hash, operation=command.operation,
                    status="DRY_RUN", project_id=command.project_id, sttm_id=command.sttm_id,
                    prior_revision=prior_revision, new_revision=prior_revision,
                    result={"authorized": True, "would_execute": command.operation},
                )
                return self._repository.save_command_receipt(receipt)

            result = mutation()
            new_revision = current_revision() if current_revision else prior_revision
            if result_serializer:
                serialized = result_serializer(result)
            elif hasattr(result, "model_dump"):
                serialized = result.model_dump(mode="json")
            elif isinstance(result, dict):
                serialized = result
            else:
                serialized = {"value": result}
            receipt = AgentCommandReceipt(
                    run_id=command.run_id,
                command_id=command.command_id, idempotency_key=command.idempotency_key,
                payload_hash=command.payload_hash, operation=command.operation,
                status="SUCCEEDED", project_id=command.project_id or serialized.get("project_id"),
                sttm_id=command.sttm_id or serialized.get("sttm_id"), prior_revision=prior_revision,
                new_revision=new_revision, result=serialized,
            )
            return self._repository.save_command_receipt(receipt)
