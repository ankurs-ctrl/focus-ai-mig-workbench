from pathlib import Path
from types import SimpleNamespace
import ast
import pytest
from app.agent_worker_main import _deep_rest_host
from app.core.config import Settings


def test_delegated_oauth_prefers_application_public_host_without_changing_connection():
    settings=Settings(_env_file=None,AUTH_MODE='custom_oauth',LOCAL_DEV_AUTH_ENABLED=False,
        SNOWFLAKE_ACCOUNT='injected-locator',SNOWFLAKE_HOST='internal.snowflakecomputing.internal',
        SNOWFLAKE_REST_HOST='mhsuejt-ffp-hdp-snow-account-prod.snowflakecomputing.com')
    context=SimpleNamespace(host='internal.snowflakecomputing.internal',token='unchanged-user-token')
    assert _deep_rest_host(settings,context)==settings.rest_snowflake_host
    assert context.host=='internal.snowflakecomputing.internal' and context.token=='unchanged-user-token'


def test_local_session_token_keeps_connector_host():
    settings=SimpleNamespace(local_dev_auth_enabled=True,rest_snowflake_host='public.example')
    assert _deep_rest_host(settings,SimpleNamespace(host='connector.example'))=='connector.example'


def test_no_public_override_uses_same_fallback_as_application():
    settings=SimpleNamespace(local_dev_auth_enabled=False,rest_snowflake_host='')
    assert _deep_rest_host(settings,SimpleNamespace(host='connector.example'))=='connector.example'


def test_all_supervisor_and_specialist_factories_use_resolved_host_and_delegated_token():
    import app.agent_worker_main as worker
    tree=ast.parse(Path(worker.__file__).read_text())
    calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
        and n.func.id in {'SnowflakeAgentClient','SnowflakeAnalystClient','build_snowflake_cortex_model'}]
    assert len(calls)==3
    for call in calls:
        values={k.arg:k.value for k in call.keywords}
        assert isinstance(values['host'],ast.Name) and values['host'].id=='rest_host'
        token=values.get('token',values.get('oauth_token'))
        assert isinstance(token,ast.Name) and token.id=='cortex_token'
        assert 'role' in values
