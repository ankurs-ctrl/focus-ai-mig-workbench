const test = require('node:test');
const assert = require('node:assert/strict');
const {helpers,stateFor,blank,imported,direct,response} = require('./test-automap-preservation.cjs');

test('canonical target IDs agree with Python and preserve quoted case', () => {
  assert.equal(helpers.autoMapTargetBindingId('D.S.T','BillingCity'),'tgt_2862d67ab0073684aca427865fee9675');
  assert.equal(helpers.autoMapTargetBindingId('d.s.t','BILLINGCITY'),'tgt_2862d67ab0073684aca427865fee9675');
  assert.equal(helpers.autoMapTargetBindingId('D.S.T','"BillingCity"'),'tgt_c42224bb2064b6ed1615dca5876323b4');
});

test('checked uploaded display spelling resolves to the authoritative unquoted target', () => {
  const row={...blank('city'),targetColumn:'BillingCity'};
  const state=stateFor(row);state.targetAttributeGroup.columns=[{name:'BILLINGCITY'}];state.selectedMappingIds=['city'];
  assert.deepEqual(helpers.autoMapScope(state).names,['BILLINGCITY']);
  state.targetAttributeGroup.columns=[{name:'"BillingCity"'}];assert.throws(()=>helpers.autoMapScope(state),/scope/);
});

test('ambiguous target inventory is rejected before starting Auto-map', () => {
  const state=stateFor(blank('BillingCity'),blank('BILLINGCITY'));
  assert.throws(()=>helpers.autoMapScope(state),/scope/);
});

test('provisional native checkpoints do not downgrade unfinished siblings', () => {
  const first=blank('NAME');const second={...blank('OTHER'),status:'PROCESSING'};
  const state=stateFor(first,second);
  const body=response(direct);body.result.mappings.OTHER={source_attributes:[],confidence_score:0,transformation_classification:'unresolved',unmatched_reason:'Still investigating'};
  body.meta={auto_map_native_provisional:true,auto_map_native_checkpoint_targets:['NAME'],auto_map_native_checkpoint_token:'one'};
  helpers.applyAutoMapResponseToState(state,body);
  assert.equal(state.mappings[0].status,'MAPPED');assert.equal(state.mappings[1].status,'PROCESSING');
  assert.equal(state.mappingSuggestions.length,1);
});

test('conflicting target binding proof cannot enter rows or proposals', () => {
  const state=stateFor(blank());state.autoMapRun={requestId:'run',sttmId:'one',projectId:'project',baseline:{},expectedInputs:{},targetBindings:{NAME:'expected'}};
  const body=response(direct);body.meta={auto_map_target_bindings:{NAME:'foreign'}};
  helpers.applyAutoMapResponseToState(state,body);
  assert.equal(state.mappings[0].status,'UNMAPPED');assert.equal(state.mappingSuggestions.length,0);
});
