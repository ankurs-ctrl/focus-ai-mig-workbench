"""Small in-process performance counters for rollout diagnostics.

The registry deliberately stores counts and durations only. It never stores SQL,
tokens, user text, or semantic evidence. Snowflake query history remains the
source of truth for warehouse execution and credit measurements.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict
from contextlib import contextmanager
from functools import wraps
from typing import Any, Iterator


_LOCK = threading.Lock()
_COUNTERS: dict[str, int] = defaultdict(int)
_DURATIONS: dict[str, dict[str, float]] = defaultdict(
    lambda: {"count": 0.0, "total_ms": 0.0, "max_ms": 0.0}
)
_DURATION_SAMPLES: dict[str, list[float]] = defaultdict(list)
_MAX_SAMPLES_PER_METRIC = 512


def _metric_key(metric: str, labels: dict[str, Any]) -> str:
    if not labels:
        return metric
    suffix = ",".join(
        f"{key}={str(value)[:96]}" for key, value in sorted(labels.items())
    )
    return f"{metric}{{{suffix}}}"


def increment(metric: str, amount: int = 1, **labels: Any) -> None:
    with _LOCK:
        _COUNTERS[_metric_key(metric, labels)] += amount


def observe(metric: str, duration_ms: float, **labels: Any) -> None:
    with _LOCK:
        key = _metric_key(metric, labels)
        value = _DURATIONS[key]
        value["count"] += 1
        value["total_ms"] += float(duration_ms)
        value["max_ms"] = max(value["max_ms"], float(duration_ms))
        samples = _DURATION_SAMPLES[key]
        samples.append(float(duration_ms))
        if len(samples) > _MAX_SAMPLES_PER_METRIC:
            del samples[: len(samples) - _MAX_SAMPLES_PER_METRIC]


def _percentile(samples: list[float], percentile: float) -> float:
    if not samples:
        return 0.0
    ordered = sorted(samples)
    index = max(0, min(len(ordered) - 1, int((len(ordered) - 1) * percentile)))
    return ordered[index]


@contextmanager
def timed(metric: str) -> Iterator[None]:
    started = time.perf_counter()
    try:
        yield
    finally:
        observe(metric, (time.perf_counter() - started) * 1000)


def measured(metric: str):
    """Record one sync function invocation without changing its return contract."""
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            started = time.perf_counter()
            try:
                return function(*args, **kwargs)
            finally:
                observe(metric, (time.perf_counter() - started) * 1000)
        return wrapped
    return decorate


def snapshot() -> dict[str, Any]:
    with _LOCK:
        durations = {
            name: {
                **values,
                "avg_ms": (
                    values["total_ms"] / values["count"]
                    if values["count"]
                    else 0.0
                ),
                "p50_ms": _percentile(_DURATION_SAMPLES.get(name, []), 0.50),
                "p95_ms": _percentile(_DURATION_SAMPLES.get(name, []), 0.95),
                "p99_ms": _percentile(_DURATION_SAMPLES.get(name, []), 0.99),
                "sample_count": len(_DURATION_SAMPLES.get(name, [])),
            }
            for name, values in _DURATIONS.items()
        }
        counters = dict(_COUNTERS)

        def total(prefixes: tuple[str, ...]) -> int:
            return sum(value for name, value in counters.items() if name.startswith(prefixes))

        prepared_hits = total(("prepared_context.cache.l1_hit", "prepared_context.cache.l2_hit"))
        prepared_misses = total(("prepared_context.cache.l1_miss", "prepared_context.cache.l2_miss"))
        learning_hits = total(("learning_context.cache.l1_hit", "learning_context.cache.l2_hit"))
        learning_misses = total(("learning_context.cache.l1_miss", "learning_context.cache.l2_miss"))
        return {
            "counters": counters,
            "durations": durations,
            "rates": {
                "prepared_context_hit_rate": prepared_hits / max(1, prepared_hits + prepared_misses),
                "learning_context_hit_rate": learning_hits / max(1, learning_hits + learning_misses),
            },
        }
