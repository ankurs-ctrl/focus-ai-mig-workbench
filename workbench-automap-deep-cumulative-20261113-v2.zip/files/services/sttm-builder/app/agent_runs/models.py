from __future__ import annotations

import hashlib
import json
import re
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Literal

from pydantic import AliasChoices, BaseModel, Field, field_validator, model_validator


class EffortLevel(str, Enum):
    AUTO = "auto"
    LIGHT = "light"
    MEDIUM = "medium"
    HIGH = "high"


class RunMode(str, Enum):
    AUTO = "auto"
    PLAN = "plan"


class RunStatus(str, Enum):
    QUEUED = "QUEUED"
    INTAKE = "INTAKE"
    PLANNING = "PLANNING"
    AWAITING_CONFIRMATION = "AWAITING_CONFIRMATION"
    EXECUTING = "EXECUTING"
    AWAITING_INPUT = "AWAITING_INPUT"
    VALIDATING = "VALIDATING"
    COMPLETED = "COMPLETED"
    READY_FOR_REVIEW = "READY_FOR_REVIEW"
    COMPLETED_WITH_REVIEW_ITEMS = "COMPLETED_WITH_REVIEW_ITEMS"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"


class AssistantIntent(str, Enum):
    CONVERSATIONAL_QA = "CONVERSATIONAL_QA"
    RUN_DIAGNOSTIC = "RUN_DIAGNOSTIC"
    CONTINUE_RUN = "CONTINUE_RUN"
    NEW_MIGRATION_TASK = "NEW_MIGRATION_TASK"
    ANSWER_INTERRUPT = "ANSWER_INTERRUPT"
    CANCEL_RUN = "CANCEL_RUN"


class ExecutionPath(str, Enum):
    FAST_PATH = "fast_path"
    PLAN_OFFER = "plan_offer"
    NEW_RUN = "new_run"
    RESUME = "resume"
    CONTROL = "control"


TERMINAL_RUN_STATUSES = {
    RunStatus.COMPLETED,
    RunStatus.READY_FOR_REVIEW,
    RunStatus.COMPLETED_WITH_REVIEW_ITEMS,
    RunStatus.NEEDS_REVIEW,
    RunStatus.FAILED,
    RunStatus.CANCELLED,
    RunStatus.EXPIRED,
}


class StepStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    AWAITING_INPUT = "AWAITING_INPUT"
    SUCCEEDED = "SUCCEEDED"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    BLOCKED = "BLOCKED"
    STALE = "STALE"


class ReviewItemStatus(str, Enum):
    OPEN = "OPEN"
    ANSWERED = "ANSWERED"
    RESOLVED = "RESOLVED"
    DISMISSED = "DISMISSED"


class RetryClass(str, Enum):
    TRANSIENT = "TRANSIENT"
    CONFLICT = "CONFLICT"
    AUTHORIZATION = "AUTHORIZATION"
    USER_INPUT = "USER_INPUT"
    VALIDATION = "VALIDATION"
    PERMANENT = "PERMANENT"


class EffortPolicy(BaseModel):
    effort: EffortLevel
    reasoning_effort: Literal["low", "medium", "high"]
    planning_depth: int
    retrieval_card_limit: int
    retrieval_token_budget: int
    profile_row_limit: int
    specialist_retries: int
    relationship_alternatives: int
    preview_row_limit: int
    validation_depth: Literal["compile", "preview", "reconcile"]
    cross_mapping_checks: list[str]
    model_call_budget: int
    tool_call_budget: int
    # These fields were introduced after durable runs were already in use.
    # Keep zero as the wire-level legacy sentinel and hydrate the partition
    # deterministically so old run snapshots remain readable.
    working_model_call_budget: int = 0
    finalization_model_call_budget: int = 0
    working_tool_call_budget: int = 0
    finalization_tool_call_budget: int = 0
    max_parallel_mappings: int = Field(ge=1, le=32)
    domain_operation_budget: int = Field(default=240, ge=1)
    cortex_call_budget: int = Field(default=80, ge=1)
    specialist_model_call_budget: int = Field(default=80, ge=1)
    snowflake_query_budget: int = Field(default=500, ge=1)
    retry_budget: int = Field(default=10, ge=0)
    max_resume_attempts: int = Field(default=3, ge=0, le=100)
    elapsed_seconds: int = Field(default=1800, ge=1)
    finalization_seconds: int = Field(default=60, ge=1)

    @model_validator(mode="after")
    def hydrate_legacy_budget_partitions(self) -> "EffortPolicy":
        defaults = {
            # Legacy snapshots retain their original totals and partitions;
            # newly created runs use the expanded explicit values below.
            EffortLevel.LIGHT: (16, 4, 32, 8),
            EffortLevel.MEDIUM: (24, 6, 100, 20),
            EffortLevel.HIGH: (68, 12, 260, 40),
        }
        working_model, final_model, working_tool, final_tool = defaults[self.effort]
        if self.finalization_seconds >= self.elapsed_seconds:
            raise ValueError("Finalization reserve must be smaller than the elapsed-time budget")
        if self.model_call_budget <= self.finalization_model_call_budget or self.tool_call_budget <= self.finalization_tool_call_budget:
            raise ValueError("Finalization reserves must be smaller than total budgets")
        if self.working_model_call_budget <= 0:
            self.working_model_call_budget = working_model
        if self.finalization_model_call_budget <= 0:
            self.finalization_model_call_budget = final_model
        if self.working_tool_call_budget <= 0:
            self.working_tool_call_budget = working_tool
        if self.finalization_tool_call_budget <= 0:
            self.finalization_tool_call_budget = final_tool
        return self


EFFORT_POLICIES: dict[EffortLevel, EffortPolicy] = {
    EffortLevel.LIGHT: EffortPolicy(
        effort=EffortLevel.LIGHT,
        reasoning_effort="low",
        planning_depth=1,
        retrieval_card_limit=8,
        retrieval_token_budget=2500,
        profile_row_limit=25,
        specialist_retries=2,
        relationship_alternatives=1,
        preview_row_limit=25,
        validation_depth="compile",
        cross_mapping_checks=["contract"],
        # Ten turns is not enough for the Deep Agents planning contract plus a
        # multi-tool read-only answer and final synthesis. Light still limits
        # depth/parallelism, but retains a bounded completion reserve.
        model_call_budget=32,
        tool_call_budget=80,
        working_model_call_budget=26,
        finalization_model_call_budget=6,
        working_tool_call_budget=64,
        finalization_tool_call_budget=16,
        max_parallel_mappings=1, domain_operation_budget=80, cortex_call_budget=20, specialist_model_call_budget=20, snowflake_query_budget=120, retry_budget=2, elapsed_seconds=3600,
    ),
    EffortLevel.MEDIUM: EffortPolicy(
        effort=EffortLevel.MEDIUM,
        reasoning_effort="medium",
        planning_depth=2,
        retrieval_card_limit=20,
        retrieval_token_budget=6000,
        profile_row_limit=100,
        specialist_retries=3,
        relationship_alternatives=2,
        preview_row_limit=100,
        validation_depth="preview",
        cross_mapping_checks=["contract", "keys", "dependencies", "relationships"],
        model_call_budget=128,
        tool_call_budget=480,
        working_model_call_budget=112,
        finalization_model_call_budget=16,
        working_tool_call_budget=400,
        finalization_tool_call_budget=80,
        max_parallel_mappings=3,
        # Sized for up to five parallel mappings (more resolve to High):
        # source-mapping + transformation + one repair per mapping.
        cortex_call_budget=120,
        specialist_model_call_budget=120,
        domain_operation_budget=360,
        snowflake_query_budget=800,
        max_resume_attempts=8,
        elapsed_seconds=7200,
        finalization_seconds=90,
    ),
    EffortLevel.HIGH: EffortPolicy(
        effort=EffortLevel.HIGH,
        reasoning_effort="high",
        planning_depth=3,
        retrieval_card_limit=40,
        retrieval_token_budget=12000,
        profile_row_limit=500,
        specialist_retries=4,
        relationship_alternatives=3,
        preview_row_limit=500,
        validation_depth="reconcile",
        cross_mapping_checks=["contract", "keys", "dependencies", "relationships", "reconciliation", "blast_radius"],
        model_call_budget=128,
        tool_call_budget=600,
        working_model_call_budget=108,
        finalization_model_call_budget=20,
        working_tool_call_budget=500,
        finalization_tool_call_budget=100,
        max_parallel_mappings=5, domain_operation_budget=600, cortex_call_budget=200, specialist_model_call_budget=200, snowflake_query_budget=1500, retry_budget=20, max_resume_attempts=12, elapsed_seconds=10800, finalization_seconds=120,
    ),
}


def resolve_effort(request: "RunCreateRequest") -> EffortLevel:
    """Resolve Auto deterministically so budgets are fixed before execution starts."""
    if request.effort is not EffortLevel.AUTO:
        return request.effort
    # A read-only explanation is answered from the supervisor's own knowledge
    # plus, at most, a few catalog reads; Auto can still promote it later.
    if (
        str(dict(request.page_context or {}).get("continuation_kind") or "") == "READ_ONLY_QA"
        and not request.attachment_ids
    ):
        return EffortLevel.LIGHT
    scope_size = len(request.source_scope) + len(request.target_scope)
    from app.agent_runs.prompt_scope import extract_prompt_targets

    # Chat users name targets in prose, not in requested_mappings; ten named
    # targets must not run with Light's single-mapping, 32-call ceiling.
    mapping_count = max(len(request.requested_mappings), len(extract_prompt_targets(request.prompt)))
    prompt = request.prompt.lower()
    recent_context = " ".join(
        str(item.get("content") or item.get("text") or "")
        for item in request.conversation_history[-8:]
        if isinstance(item, dict)
    ).lower()
    high_risk_markers = ("reconcile", "blast radius", "all mappings", "whole project")
    explicitly_read_only = "read-only" in prompt or "read only" in prompt
    publish_requested = (
        not explicitly_read_only
        and bool(re.search(r"\b(publish|deploy|release)\b", prompt))
        and not bool(
            re.search(
                r"\b(?:do not|don't|never|without)\s+(?:\w+\s+){0,3}(?:publish|publishing|deploy|deploying|release|releasing)\b",
                prompt,
            )
        )
    )
    if (
        mapping_count > 5
        or scope_size > 10
        or publish_requested
        or any(marker in prompt for marker in high_risk_markers)
    ):
        return EffortLevel.HIGH
    # Scope discovery is a multi-tool workload even when no table is selected.
    # Classifying only by prompt length and preselected objects gave catalog +
    # evidence-ranking requests the 10-turn Light ceiling.
    discovery_markers = (
        "analyze",
        "inspect",
        "search",
        "discover",
        "find the best",
        "recommend",
        "compare",
        "source and target",
        "sources and targets",
        "fir",
        "precedent",
        "evidence",
        "create a mapping",
        "new mapping",
        "new project",
        "tmd project",
        "create a project",
        "target tables",
        "targets",
    )
    discovery_signals = sum(marker in prompt for marker in discovery_markers)
    mapping_mutation = bool(re.search(
        r"\b(?:generate|build|create|draft|produce|complete|update|refine)\b.{0,40}\b(?:mapping|sttm)\b"
        r"|\b(?:mapping|sttm)\b.{0,40}\b(?:generate|build|create|draft|produce|complete|update|refine)\b",
        prompt,
    ))
    prior_evidence_follow_up = mapping_mutation and bool(
        re.search(r"\b(?:source|target|contract|recommend|mapping|join|confidence|evidence)\b", recent_context)
    )
    requires_scope_discovery = scope_size == 0 and discovery_signals >= 1
    if (
        mapping_count > 1
        or scope_size > 2
        or len(request.prompt) > 500
        or request.attachment_ids
        or discovery_signals >= 2
        or requires_scope_discovery
        or mapping_mutation
        or prior_evidence_follow_up
    ):
        return EffortLevel.MEDIUM
    return EffortLevel.LIGHT


class AgentActor(BaseModel):
    app_user_id: str = Field(validation_alias=AliasChoices("app_user_id", "user_id"))
    snowflake_username: str | None = None
    tenant_id: str = "default"
    effective_role: str | None = None
    actor_type: Literal["user", "agent-worker", "service"] = "user"
    delegation_ref: str | None = None

    @property
    def user_id(self) -> str:
        """Backward-compatible accessor; domain writes always use the app user id."""
        return self.app_user_id


class AgentRunContext(BaseModel):
    run_id: str
    thread_id: str
    conversation_id: str | None = None
    app_user_id: str
    snowflake_username: str | None = None
    tenant_id: str = "default"
    effective_role: str
    page_context: dict[str, Any] = Field(default_factory=dict)
    authorized_schemas: list[str] = Field(default_factory=list)
    run_owned_artifact_ids: list[str] = Field(default_factory=list)
    policy_version: str = "1.0"
    model_call_budget: int
    tool_call_budget: int


class RunCreateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=50_000)
    effort: EffortLevel = EffortLevel.AUTO
    model_name: str | None = Field(default=None, max_length=128)
    run_mode: RunMode = RunMode.AUTO
    conversation_id: str | None = Field(default=None, max_length=255)
    turn_id: str | None = Field(default=None, max_length=255)
    intent: AssistantIntent = AssistantIntent.NEW_MIGRATION_TASK
    parent_run_id: str | None = Field(default=None, max_length=64)
    conversation_history: list[dict[str, Any]] = Field(default_factory=list, max_length=100)
    page_context: dict[str, Any] = Field(default_factory=dict)
    authorized_schemas: list[str] = Field(default_factory=list, max_length=100)
    project_id: str | None = None
    source_scope: list[str] = Field(default_factory=list)
    target_scope: list[str] = Field(default_factory=list)
    precedent_project_ids: list[str] = Field(default_factory=list)
    precedent_sttm_ids: list[str] = Field(default_factory=list)
    attachment_ids: list[str] = Field(default_factory=list, max_length=20)
    requested_mappings: list[str] = Field(default_factory=list, max_length=50)
    constraints: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str | None = Field(default=None, max_length=255)


class AgentRun(BaseModel):
    category_usage: dict[str, int] = Field(default_factory=dict)
    elapsed_seconds_used: float = 0
    phase_started_at: datetime | None = None
    phase_elapsed_start: float = 0
    budget_grants: list[dict[str, Any]] = Field(default_factory=list)
    effort_history: list[dict[str, Any]] = Field(default_factory=list)
    run_id: str
    actor: AgentActor
    request: RunCreateRequest
    request_hash: str
    policy: EffortPolicy
    status: RunStatus = RunStatus.QUEUED
    project_id: str | None = None
    manifest_version: int = 0
    mapping_manifest: list[dict[str, Any]] = Field(default_factory=list)
    current_step_id: str | None = None
    current_sttm_id: str | None = None
    current_mapping_name: str | None = None
    checkpoint_thread_id: str | None = None
    checkpoint_id: str | None = None
    resume_attempt: int = 0
    run_revision: int = 0
    last_resume_idempotency_key: str | None = None
    lease_owner: str | None = None
    lease_generation: int = 0
    lease_expires_at: datetime | None = None
    heartbeat_at: datetime | None = None
    cancel_requested_at: datetime | None = None
    cancel_reason: str | None = None
    model_calls_used: int = 0
    tool_calls_used: int = 0
    supervisor_tool_requests_used: int = 0
    domain_operations_used: int = 0
    specialist_calls_used: int = 0
    cache_hits: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error_code: str | None = None
    safe_error: str | None = None


class AgentRunStep(BaseModel):
    step_id: str
    run_id: str
    node_name: str
    mapping_key: str | None = None
    sttm_id: str | None = None
    attempt: int = 1
    status: StepStatus = StepStatus.PENDING
    input_refs: list[str] = Field(default_factory=list)
    output_refs: list[str] = Field(default_factory=list)
    retry_class: RetryClass | None = None
    safe_summary: str | None = None
    error_code: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    model_calls: int = 0
    tool_calls: int = 0


class AgentRunEvent(BaseModel):
    event_id: str
    run_id: str
    conversation_id: str | None = None
    turn_id: str | None = None
    intent: AssistantIntent = AssistantIntent.NEW_MIGRATION_TASK
    execution_path: ExecutionPath = ExecutionPath.NEW_RUN
    plan_id: str | None = None
    resume_attempt: int = 0
    sequence: int = 0
    event_type: str
    status: str
    safe_summary: str
    project_id: str | None = None
    sttm_id: str | None = None
    step_id: str | None = None
    parent_event_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    subject_keys: list[str] = Field(default_factory=list)
    artifact_refs: list[str] = Field(default_factory=list)
    data: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ReviewChoice(BaseModel):
    choice_id: str
    label: str
    description: str | None = None
    impact: str | None = None
    evidence_ids: list[str] = Field(default_factory=list)
    recommended: bool = False
    # Calibrated probability that this choice is correct, when the host scored it.
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    selection_payload: dict[str, Any] = Field(default_factory=dict)


class AgentReviewItem(BaseModel):
    review_item_id: str
    run_id: str
    step_id: str | None = None
    project_id: str | None = None
    sttm_id: str | None = None
    mapping_key: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)
    subject_keys: list[str] = Field(default_factory=list)
    blocking: bool = False
    category: str
    question: str | None = None
    choices: list[ReviewChoice] = Field(default_factory=list)
    recommended_choice_id: str | None = None
    allow_free_text: bool = True
    interrupt_id: str | None = None
    action_digest: str | None = None
    artifact_revision: str | None = None
    safe_summary: str
    evidence_ids: list[str] = Field(default_factory=list)
    proposed_action_hash: str | None = None
    status: ReviewItemStatus = ReviewItemStatus.OPEN
    answer: str | None = None
    selected_choice_id: str | None = None
    answered_by: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    answered_at: datetime | None = None
    expires_at: datetime | None = None

    @field_validator("choices", mode="before")
    @classmethod
    def normalize_choices(cls, value: Any) -> list[Any]:
        normalized: list[Any] = []
        for index, item in enumerate(value or []):
            if isinstance(item, ReviewChoice):
                normalized.append(item)
            elif isinstance(item, str):
                normalized.append({"choice_id": f"choice_{index + 1}", "label": item})
            elif isinstance(item, dict):
                label = str(item.get("label") or item.get("value") or "").strip()
                if label:
                    normalized.append({"choice_id": str(item.get("choice_id") or item.get("id") or f"choice_{index + 1}"), **item, "label": label})
        return normalized


class MappingDagNode(BaseModel):
    partition_payload: dict[str, Any] = Field(default_factory=dict)
    plan_hash: str | None = None
    run_id: str
    mapping_key: str
    mapping_name: str
    target_table: str | None = None
    sttm_id: str | None = None
    dependencies: list[str] = Field(default_factory=list)
    status: StepStatus = StepStatus.PENDING
    stale_reason: str | None = None


class AgentAttachment(BaseModel):
    attachment_id: str
    owner_user_id: str
    tenant_id: str = "default"
    filename: str
    extension: str
    detected_mime: str
    size_bytes: int
    content_hash: str
    immutable_uri: str
    scan_status: Literal["pending", "clean", "rejected"] = "pending"
    parser_status: Literal["pending", "parsed", "failed", "unsupported"] = "pending"
    untrusted_content: bool = True
    prompt_injection_indicators: list[str] = Field(default_factory=list)
    parsed_manifest: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class AgentCommand(BaseModel):
    command_id: str
    run_id: str
    step_id: str
    operation: str
    subject_key: str
    actor: AgentActor
    project_id: str | None = None
    sttm_id: str | None = None
    expected_revision: int | None = None
    expected_snapshot_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    evidence_ids: list[str] = Field(default_factory=list)
    reason_ids: list[str] = Field(default_factory=list)
    dry_run: bool = False
    payload_hash: str = ""
    idempotency_key: str = ""

    @model_validator(mode="after")
    def derive_hashes(self) -> "AgentCommand":
        # Preserve existing short IDs and idempotency keys so old receipts remain reusable.
        # Oversized IDs could never have been stored in the VARCHAR(64) column.
        canonical = json.dumps(self.payload, sort_keys=True, separators=(",", ":"), default=str)
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        if self.payload_hash and self.payload_hash != digest:
            raise ValueError("payload_hash does not match the normalized command payload")
        self.payload_hash = digest
        if len(self.command_id) > 64:
            self.command_id = hashlib.sha256(json.dumps([self.command_id,digest]).encode("utf-8")).hexdigest()
        expected_key = ":".join(
            [self.run_id, self.step_id, self.operation, self.subject_key, digest]
        )
        if self.idempotency_key and self.idempotency_key != expected_key:
            raise ValueError("idempotency_key does not match the command contract")
        self.idempotency_key = expected_key
        return self


class AgentCommandReceipt(BaseModel):
    run_id: str | None = None
    command_id: str
    idempotency_key: str
    payload_hash: str
    operation: str
    status: Literal["SUCCEEDED", "FAILED", "CONFLICT", "DENIED", "DRY_RUN"]
    project_id: str | None = None
    sttm_id: str | None = None
    prior_revision: int | None = None
    new_revision: int | None = None
    result: dict[str, Any] = Field(default_factory=dict)
    safe_error: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class RunAnswerRequest(BaseModel):
    review_item_id: str
    answer: str | None = Field(default=None, max_length=10_000)
    choice_id: str | None = Field(default=None, min_length=1, max_length=255)
    idempotency_key: str | None = Field(default=None, max_length=255)
    interrupt_id: str | None = None
    action_digest: str | None = None
    artifact_revision: str | None = None

    @model_validator(mode="after")
    def require_answer_or_choice(self) -> "RunAnswerRequest":
        if not (str(self.answer or "").strip() or self.choice_id):
            raise ValueError("An answer or a stored choice_id is required")
        return self


class RunCancelRequest(BaseModel):
    reason: str = Field(default="Cancelled by user", max_length=2_000)


class RunResumeRequest(BaseModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    expected_revision: int = Field(ge=0)


class RunStateResponse(BaseModel):
    run: AgentRun
    steps: list[AgentRunStep] = Field(default_factory=list)
    review_items: list[AgentReviewItem] = Field(default_factory=list)
    mapping_dag: list[MappingDagNode] = Field(default_factory=list)


class ToolRisk(str, Enum):
    READ = "read"
    DRAFT_WRITE = "draft_write"
    APPROVAL_REQUIRED = "approval_required"
    PUBLISH = "publish"
    PROHIBITED = "prohibited"


class ToolContract(BaseModel):
    name: str
    description: str
    business_label: str = ""
    purpose: str = ""
    owning_agent: str = "supervisor"
    allowed_intents: list[AssistantIntent] = Field(
        default_factory=lambda: [AssistantIntent.NEW_MIGRATION_TASK, AssistantIntent.CONTINUE_RUN]
    )
    prerequisites: list[str] = Field(default_factory=list)
    when_to_use: str = ""
    when_not_to_use: str = ""
    side_effects: str = "none"
    expected_output: str = "Structured tool result"
    risk: ToolRisk
    required_scopes: list[str] = Field(default_factory=list)
    data_sensitivity: Literal["metadata", "business", "restricted"] = "metadata"
    idempotent: bool = True
    requires_expected_revision: bool = False
    cancellable: bool = True
    timeout_seconds: int = 60
    cost_class: Literal["low", "medium", "high"] = "low"
    executor: str | None = None
    # A successful read may be reused by later claims and turns of the same
    # conversation; reuse is invalidated when a table contract it was derived
    # from changes and is bounded by MIGRATION_AGENT_KNOWLEDGE_TTL_SECONDS.
    durable_reuse: bool = False


class ToolResult(BaseModel):
    status: Literal["succeeded", "needs_input", "denied", "conflict", "failed"]
    summary: str
    data: dict[str, Any] = Field(default_factory=dict)
    evidence_refs: list[str] = Field(default_factory=list)
    artifact_refs: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metrics: dict[str, float | int | str] = Field(default_factory=dict)
    retry_class: RetryClass | None = None
    error_code: str | None = None

    @classmethod
    def from_untrusted(cls, value: Any, *, operation: str) -> "ToolResult":
        if isinstance(value, cls):
            return value
        if not isinstance(value, dict):
            return cls(
                status="failed",
                summary=f"{operation} returned a malformed result.",
                retry_class=RetryClass.PERMANENT,
                error_code="malformed_tool_result",
            )
        try:
            if "status" not in value:
                return cls(status="succeeded", summary=str(value.get("safe_summary") or value.get("summary") or f"{operation} completed."), data=value)
            return cls.model_validate(value)
        except Exception:
            return cls(status="failed", summary=f"{operation} returned a malformed result.", retry_class=RetryClass.PERMANENT, error_code="malformed_tool_result")


def request_hash(request: RunCreateRequest, actor: AgentActor) -> str:
    body = {"request": request.model_dump(mode="json"), "actor": actor.model_dump(mode="json")}
    return hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
