"""Score saved Auto-map responses against an exported accepted answer key.

No database writes or model calls. Supply packet JSON to verify citation membership;
without it citation validity is explicitly unknown. --baseline produces deltas.
"""
import argparse
import json
from pathlib import Path
import sys


def mappings(value):
    if isinstance(value.get('mappings'), dict):
        return value['mappings']
    result = value.get('result') or (value.get('data') or {}).get('result') or {}
    if isinstance(result.get('mappings'), dict):
        return result['mappings']
    rows = value.get('mapping_rows') or []
    return {str(row.get('target_column') or row.get('target_attribute')): row for row in rows}


def signature(row):
    sources = row.get('source_attributes') or row.get('source_columns') or []
    expression = row.get('preprocessing_rule') or row.get('expression') or row.get('transformation') or ''
    # Compare exact expressions, including literal case and placeholder spelling.
    return sorted(sources), row.get('mapping_mode') or 'source', expression.strip()


def packet_precedents(packet):
    """Read the production nested canonical records, not an invented learning_packs field."""
    found = {}
    def visit(value, tier=None):
        if isinstance(value, list):
            for child in value:
                visit(child, tier)
        elif isinstance(value, dict):
            tier = value.get('tier') or tier
            if value.get('pattern_id') and isinstance(value.get('target_contract'), dict):
                target = value['target_contract'].get('target_column')
                if target:
                    found.setdefault(str(target).upper(), {})[str(value['pattern_id'])] = tier or 'unknown'
            if value.get('precedent_sttm_id'):
                for row in value.get('mappings') or []:
                    target = row.get('target_column') or row.get('target_attribute')
                    if target:
                        found.setdefault(str(target).upper(), {})[str(row.get('mapping_id') or value['precedent_sttm_id'])] = tier or 'T2'
            for child in value.values():
                if isinstance(child, (dict, list)):
                    visit(child, tier)
    visit(packet)
    return found


def score(key, run, packets=None):
    expected, actual = mappings(key), mappings(run)
    covered = [target for target in expected if target in actual]
    exact = sum(signature(expected[target]) == signature(actual[target]) for target in covered)
    supplied, precedents = {}, {}
    for packet in packets or []:
        # Exports may use the exact lossless wire encodings.
        try:
            from scripts.automap_message_sizes import expand_packet
        except ModuleNotFoundError:
            from automap_message_sizes import expand_packet
        packet = expand_packet(packet)
        context = packet.get('context') or {}
        ids = set(context.get('citation_ids') or [])
        for target in (packet.get('data') or {}).get('attributes') or []:
            name = str(target['target_attribute']).upper()
            supplied.setdefault(name, set()).update(ids)
        for target, records in packet_precedents(packet).items():
            precedents.setdefault(target, {}).update(records)
    citations = invalid = missing = missing_citation_targets = 0
    tier_use = {}
    for target in covered:
        row = actual[target]
        target_key = str(target).upper()
        cited = (row.get('decision_basis') or {}).get('citations') or []
        citations += len(cited)
        if packets is not None:
            allowed = supplied.get(target_key, set())
            invalid += len(set(cited) - allowed)
            missing_citation_targets += not bool(set(cited) & allowed)
        if target_key in precedents and not row.get('precedent_decision'):
            missing += 1
        used = set(row.get('used_learning_ids') or []) | {identity.removeprefix('fir:') for identity in cited if identity.startswith('fir:')}
        for identity in used:
            tier = precedents.get(target_key, {}).get(identity)
            if tier:
                tier_use[tier] = tier_use.get(tier, 0) + 1
    meta = run.get('meta') or {}
    retrieval = meta.get('auto_map_retrieval') or run.get('auto_map_retrieval') or {}
    batches = meta.get('auto_map_batch_metrics') or [{
        'batch_index': 0, 'source_model_call_count': retrieval.get('source_model_call_count', retrieval.get('model_call_count')),
        'total_model_call_count': retrieval.get('model_call_count'),
        'timings_ms': retrieval.get('timings_ms'), 'elapsed_seconds': retrieval.get('elapsed_seconds')}]
    stages = meta.get('transformation_stages') or ([meta['transformation_stage']] if meta.get('transformation_stage') else [])
    rule_targets = sum(stage.get('target_count') or 0 for stage in stages)
    compiled = sum(stage.get('validated_rules') or 0 for stage in stages)
    return {'targets': len(expected), 'decision_records': len(covered),
            'coverage': len(covered) / max(1, len(expected)), 'exact_matches': exact,
            'accuracy': exact / max(1, len(expected)),
            'citation_count': citations, 'invalid_citations': invalid if packets is not None else None,
            'targets_without_valid_citation': missing_citation_targets if packets is not None else None,
            'citation_validity_verified': packets is not None,
            'missing_precedent_decisions': missing if packets is not None else None,
            'precedent_use_by_tier': tier_use,
            'rule_compile_rate': compiled / rule_targets if rule_targets else None,
            'prep_ms': meta.get('auto_map_preparation_ms'),
            'batch_metrics': batches,
            'timings_ms': retrieval.get('timings_ms'), 'elapsed_seconds': retrieval.get('elapsed_seconds'),
            'calls_per_batch': [batch.get('source_model_call_count') for batch in batches],
            'unresolved_count': sum(row.get('transformation_classification') == 'unresolved' for row in actual.values())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--answer-key', type=Path, required=True)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--packets', type=Path)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    read = lambda path: json.loads(path.read_text())
    result = score(read(args.answer_key), read(args.run), read(args.packets) if args.packets else None)
    if args.baseline:
        baseline = score(read(args.answer_key), read(args.baseline))
        result['baseline'] = baseline
        result['accuracy_delta'] = result['accuracy'] - baseline['accuracy']
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(text)
    else:
        sys.stdout.write(text)


if __name__ == '__main__':
    main()
