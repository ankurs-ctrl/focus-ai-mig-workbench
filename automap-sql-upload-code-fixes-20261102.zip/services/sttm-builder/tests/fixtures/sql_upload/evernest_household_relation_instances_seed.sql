-- OPTIONAL SYNTHETIC DATA ONLY. Not executed by the application.
-- Use a dedicated existing scratch namespace, never a client application schema.
-- Replace REGRESSION_DB.EVERNEST in BOTH fixture files for your scratch namespace.
-- All tables below are session-temporary; run the SELECT fixture in this session.
USE DATABASE REGRESSION_DB;
USE SCHEMA EVERNEST;
CREATE TEMPORARY TABLE CONTACTS (id INT, first_name VARCHAR, last_name VARCHAR, status_id INT, servicing_advisor_id INT, writing_advisor_id INT, category_id INT, deleted INT);
INSERT INTO CONTACTS VALUES (1,'Jane','Stone',1,1,1,1,0),(2,'Not','Client',2,1,1,1,0),(1193,'Outer','Filter',2,1,1,1,0),(3,'Deleted','Client',1,1,1,1,1);
CREATE TEMPORARY TABLE CONTACT_STATUSES (id INT, name VARCHAR);
INSERT INTO CONTACT_STATUSES VALUES (1,'Client'),(2,'Prospect');
CREATE TEMPORARY TABLE ADDRESSES (id INT, addressable_id INT, country VARCHAR, state VARCHAR, city VARCHAR, deleted INT, is_primary INT);
INSERT INTO ADDRESSES VALUES (1,1,'United States','Pennsylvania','Pittsburgh',0,1),(2,1,'Canada','Ontario','WrongDuplicate',0,1),(3,1,'Canada','Ontario','Toronto',0,0);
CREATE TEMPORARY TABLE CONTACT_FAMILY_MEMBERS (contact_id INT, family_id INT, deleted INT);
INSERT INTO CONTACT_FAMILY_MEMBERS VALUES (1,10,0);
CREATE TEMPORARY TABLE CONTACT_FAMILIES (id INT, deleted INT);
INSERT INTO CONTACT_FAMILIES VALUES (10,0);
CREATE TEMPORARY TABLE SERVICING_ADVISORS (id INT);
INSERT INTO SERVICING_ADVISORS VALUES (1);
CREATE TEMPORARY TABLE WRITING_ADVISORS (id INT);
INSERT INTO WRITING_ADVISORS VALUES (1);
CREATE TEMPORARY TABLE CONTACT_CATEGORIES (id INT);
INSERT INTO CONTACT_CATEGORIES VALUES (1);
CREATE TEMPORARY TABLE CONTACT_UDFS (contact_id INT, deleted INT);
INSERT INTO CONTACT_UDFS VALUES (1,0);
CREATE TEMPORARY TABLE COUNTRY_CODES (country_code VARCHAR, country_alias VARCHAR);
INSERT INTO COUNTRY_CODES VALUES ('US','United States'),('CA','Canada');
CREATE TEMPORARY TABLE STATE_CODES (state_code VARCHAR, state_alias VARCHAR);
INSERT INTO STATE_CODES VALUES ('PA','Pennsylvania'),('ON','Ontario');
-- Expected SELECT row:
-- 1 | Pittsburgh | US | CA | PA | ON | Jane Stone | <empty string>
-- Population filters and QUALIFY must exclude other contacts and the duplicate address.
