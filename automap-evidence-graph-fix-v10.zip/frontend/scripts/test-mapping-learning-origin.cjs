const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const filename = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
const ast = ts.createSourceFile(filename, fs.readFileSync(filename, 'utf8'), ts.ScriptTarget.Latest, true);
const functions = [];
const reducers = {};
function visit(node) {
  if (ts.isFunctionDeclaration(node) && ['autoMapReviewIsApplicable', 'autoMapReviewIsCurrent', 'autoMapReviewValueProofIsCurrent', 'autoMapRevisionHash', 'autoMapInputSignature', 'autoMapSourceInputs', 'autoMapSharedInputs', 'stablePreparedContextValue', 'applyMappingSuggestion', 'isStructuredSqlExpression', 'buildPendingAiMappingReviews'].includes(node.name?.text)) functions.push(node.getText(ast));
  if (ts.isPropertyAssignment(node) && ['applyPendingAiMappingReview', 'applyAllPendingAiMappingReviews', 'skipPendingAiMappingReview'].includes(node.name.getText(ast))) reducers[node.name.getText(ast)] = node.initializer.getText(ast);
  ts.forEachChild(node, visit);
}
visit(ast);
const loaded = new Module(filename, module);
loaded.paths = Module._nodeModulePaths(path.dirname(filename));
loaded._compile(ts.transpileModule(`
const {sha256} = require('@noble/hashes/sha256');
const isValuePlaceholder = value => String(value ?? '').startsWith('$');
const resolveAgentResponseParts = response => ({artifactType: response.data.artifact_type});
const buildPendingAiMappingReviewRows = (_mappings, _selected, _active, response) => response.reviews;
${functions.join('\n')}
module.exports = {apply: ${reducers.applyPendingAiMappingReview}, applyAll: ${reducers.applyAllPendingAiMappingReviews},
  skip: ${reducers.skipPendingAiMappingReview}, buildPendingAiMappingReviews, applyMappingSuggestion,
  autoMapRevisionHash, autoMapSharedInputs, stablePreparedContextValue};
`, {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020}}).outputText, filename);
const review = {mappingId:'row', targetColumn:'NAME', sourceAttributes:['a.NAME'], confidenceScore:.9,
  candidateSourceAttributes:[], preprocessingRule:'TRIM(a.NAME)', preprocessingRuleType:'TRIM'};
const reviews = loaded.exports.buildPendingAiMappingReviews([], [], null, {
  request_id:'request', data:{artifact_type:'transformation_rules'}, reviews:[review]});
assert.equal(reviews[0].generatedByRequestId, 'request');
const row = {id:'row', targetColumn:'NAME', sourceColumns:['a.NAME'], expression:'a.NAME', manuallySaved:true};
const state = {mappings:[{...row}], pendingAiMappingReviews:reviews, selectedMappingIds:['row'], errorState:{}};
const helper = loaded.exports;
const proof = {projectId: undefined, sttmId: undefined, valuesRevision: 'current',
  sharedRevision: helper.autoMapRevisionHash(helper.autoMapSharedInputs(state)),
  reviews: Object.fromEntries(reviews.map(item => [item.mappingId, helper.autoMapRevisionHash(helper.stablePreparedContextValue(item))]))};
helper.apply(state, {payload: proof});
assert.equal(state.mappings[0].expression, 'TRIM(a.NAME)');
assert.equal(state.mappings[0].manuallySaved, false);
assert.deepEqual(state.mappings[0].learningOrigin, {kind:'assistant_apply', requestId:'request', artifactType:'transformation_rules'});
const skipped = {mappings:[{...row}], pendingAiMappingReviews:reviews};
loaded.exports.skip(skipped);
assert.deepEqual(skipped.mappings[0], row);
loaded.exports.applyMappingSuggestion(state.mappings[0], review);
assert.equal(state.mappings[0].learningOrigin, null);
console.log('Assistant Apply retains request/artifact origin but not acceptance; Skip does not mutate rows; generation clears old origin.');