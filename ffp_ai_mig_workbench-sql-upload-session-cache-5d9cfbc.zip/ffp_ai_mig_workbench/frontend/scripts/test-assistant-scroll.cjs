const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const {test} = require('node:test');

const filename = path.resolve(__dirname, '../src/features/ai-agent/assistant-scroll.ts');
const loaded = new Module(filename, module);
loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020},
}).outputText, filename);
const {updateAssistantScroll} = loaded.exports;
const metrics = (scrollTop = 600, scrollHeight = 1000, clientHeight = 400) => ({scrollTop, scrollHeight, clientHeight});
const bottom = () => updateAssistantScroll(undefined, metrics(), 'layout').state;
const paused = () => updateAssistantScroll(bottom(), metrics(200), 'scroll').state;

test('initial non-overflow follows when streaming creates overflow', () => {
  const first = updateAssistantScroll(undefined, metrics(0, 100, 400), 'layout');
  assert.equal(first.scrollTop, 0);
  assert.equal(first.showJump, false);
  const streamed = updateAssistantScroll(first.state, metrics(0, 1100, 400), 'layout');
  assert.equal(streamed.scrollTop, 700);
  assert.equal(streamed.state.following, true);
});

test('large streaming updates use pre-update intent, not post-update distance', () => {
  const before = bottom();
  const snapshot = {...before};
  const next = updateAssistantScroll(before, metrics(600, 1800), 'layout');
  assert.equal(next.scrollTop, 1400);
  assert.deepEqual(before, snapshot, 'helper must be pure');
});

test('scrolling up pauses across tokens, trace expansion and completion', () => {
  let state = paused();
  assert.equal(state.following, false);
  for (const height of [1010, 1700, 2100, 1800, 1800]) {
    const next = updateAssistantScroll(state, metrics(200, height), 'layout');
    assert.equal(next.scrollTop, 200);
    assert.equal(next.showJump, true);
    state = next.state;
  }
});

test('loading completion near bottom never re-enables paused follow', () => {
  const next = updateAssistantScroll(paused(), metrics(200, 630), 'layout');
  assert.equal(next.scrollTop, 200);
  assert.equal(next.state.following, false);
  assert.equal(next.showJump, true);
  assert.equal(updateAssistantScroll(next.state, metrics(200, 630), 'scroll').state.following, false);
});

test('resize and no-overflow clamping do not manufacture user intent', () => {
  const noOverflow = updateAssistantScroll(paused(), metrics(0, 300, 600), 'layout');
  assert.equal(noOverflow.state.following, false);
  assert.equal(noOverflow.showJump, false);
  const clampedEvent = updateAssistantScroll(noOverflow.state, metrics(0, 300, 600), 'scroll');
  assert.equal(clampedEvent.state.following, false);
  const narrow = updateAssistantScroll(clampedEvent.state, metrics(0, 1400, 300), 'layout');
  assert.equal(narrow.scrollTop, 0);
  assert.equal(narrow.showJump, true);
});

test('browser scroll event caused by shrink does not resume follow before observer', () => {
  const next = updateAssistantScroll(paused(), metrics(100, 500), 'scroll');
  assert.equal(next.state.following, false);
  assert.equal(updateAssistantScroll(next.state, metrics(100, 1500), 'layout').scrollTop, 100);
});

test('user scrolling near bottom resumes follow; farther away does not', () => {
  assert.equal(updateAssistantScroll(paused(), metrics(535), 'scroll').state.following, false);
  const near = updateAssistantScroll(paused(), metrics(540), 'scroll');
  assert.equal(near.state.following, true);
  assert.equal(near.scrollTop, 540, 'scroll handler must not fight the user');
  assert.equal(updateAssistantScroll(near.state, metrics(540, 1500), 'layout').scrollTop, 1100);
});

test('small upward gestures near bottom can pause even during streaming', () => {
  const upward = updateAssistantScroll(bottom(), metrics(595), 'scroll');
  assert.equal(upward.state.following, false);
  assert.equal(upward.scrollTop, 595);
  assert.equal(updateAssistantScroll(upward.state, metrics(595, 1010), 'layout').scrollTop, 595);
});

test('Jump resumes follow immediately and clears the control', () => {
  const jumped = updateAssistantScroll(paused(), metrics(200), 'jump');
  assert.equal(jumped.scrollTop, 600);
  assert.equal(jumped.showJump, false);
  assert.equal(updateAssistantScroll(jumped.state, metrics(600), 'scroll').state.following, true);
});

test('resize follows only while already following; subpixel events are stable', () => {
  assert.equal(updateAssistantScroll(bottom(), metrics(600, 1000, 300), 'layout').scrollTop, 700);
  assert.equal(updateAssistantScroll(paused(), metrics(200, 1000, 300), 'layout').scrollTop, 200);
  assert.equal(updateAssistantScroll(paused(), metrics(200.5), 'scroll').state.following, false);
});

// Execute the panel's real callbacks/effects with geometry only; no browser or
// React rendering dependencies. This catches integration bypasses of the helper.
const panelFile = path.resolve(__dirname, '../src/features/ai-agent/ai-agent-panel.tsx');
const panel = ts.createSourceFile(panelFile, fs.readFileSync(panelFile, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
let syncSource, scopeSource, resizeSource;
const layoutEffects = [];
const scrollWrites = [];
const attributes = [];
function visit(node) {
  if (ts.isVariableDeclaration(node) && node.name.getText(panel) === 'syncMessageScroll') syncSource = node.initializer.arguments[0].getText(panel);
  if (ts.isVariableDeclaration(node) && node.name.getText(panel) === 'scrollScope') scopeSource = node.initializer.getText(panel);
  if (ts.isCallExpression(node) && node.expression.getText(panel) === 'useLayoutEffect') layoutEffects.push(node.arguments[0].getText(panel));
  if (ts.isCallExpression(node) && node.expression.getText(panel) === 'useEffect'
    && node.arguments[0].getText(panel).includes('new ResizeObserver')) resizeSource = node.arguments[0].getText(panel);
  if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.EqualsToken
    && node.left.getText(panel).endsWith('.scrollTop')) scrollWrites.push(node.right.getText(panel));
  if (ts.isJsxAttribute(node)) attributes.push(node.getText(panel));
  ts.forEachChild(node, visit);
}
visit(panel);
const compileCallback = (code, context) => {
  const compiled = new Module(panelFile, module);
  compiled._compile(ts.transpileModule(`module.exports = context => { const {${Object.keys(context).join(',')}} = context; return (${code}); };`, {
    compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020},
  }).outputText, panelFile);
  return compiled.exports(context);
};

test('panel uses only guarded scroll writes and a readable jump outside transcript', () => {
  assert.deepEqual(scrollWrites, ['next.scrollTop']);
  assert.ok(layoutEffects.includes('() => { syncMessageScroll(); }'));
  assert.ok(attributes.includes('onScroll={() => syncMessageScroll("scroll")}'));
  assert.ok(attributes.includes('onClick={() => syncMessageScroll("jump")}'));
  assert.match(panel.text, /overflowAnchor: "none"/);
  assert.match(panel.text, /<\/AiaBox>\s*<\/AiaBox>\s*\{showJumpToLatest \?/);
  const jump = panel.text.slice(panel.text.indexOf('{showJumpToLatest ?'), panel.text.indexOf('{hideComposer &&'));
  for (const style of ['flexShrink: 0', 'width: "100%"', 'whiteSpace: "normal"', 'color: "#1d4ed8"', 'backgroundColor: "#ffffff"']) assert.ok(jump.includes(style));
  assert.match(jump, /Jump to latest/);
});

test('actual callback restores independent standard, CoCo and recommendation intent', () => {
  const node = metrics();
  const scrollStatesRef = {current: new Map()};
  let shown;
  const scope = (mode, sttm = 'one', panelMode = 'assistant', variant = 'standalone') => compileCallback(scopeSource, {
    activeProjectId: 'project', activeSttmId: sttm, cocoState: {isActive: mode}, panelMode, variant,
  });
  const sync = key => compileCallback(syncSource, {messagesRef: {current: node}, scrollStatesRef,
    scrollScope: key, updateAssistantScroll, setShowJumpToLatest: value => {shown = value;}});
  const standard = sync(scope(false));
  standard();
  node.scrollTop = 200;
  standard('scroll');
  sync(scope(true))();
  assert.equal(node.scrollTop, 600);
  standard();
  assert.equal(node.scrollTop, 200);
  assert.equal(shown, true);
  sync(scope(false, 'one', 'recommendations'))();
  assert.equal(node.scrollTop, 600);
  standard();
  assert.equal(node.scrollTop, 200);
  sync(scope(false, 'two'))();
  assert.equal(node.scrollTop, 600);
  standard();
  assert.equal(node.scrollTop, 200);
  assert.equal(scope(false, 'one', 'recommendations', 'sidebar'), scope(false));
});

test('observer watches viewport and content, preserves latest intent and disconnects', () => {
  const observed = [];
  let notify, disconnected = false;
  let state = bottom();
  let node = metrics();
  const content = {};
  const cleanup = compileCallback(resizeSource, {messagesRef: {current: node}, messageContentRef: {current: content},
    ResizeObserver: class { constructor(callback) {notify = callback;} observe(target) {observed.push(target);} disconnect() {disconnected = true;} },
    syncMessageScroll: () => { const next = updateAssistantScroll(state, node, 'layout'); state = next.state; node.scrollTop = next.scrollTop; },
  })();
  assert.deepEqual(observed, [node, content]);
  state = paused();
  node = metrics(200, 1600);
  notify();
  assert.equal(node.scrollTop, 200, 'queued resize must honor the latest user intent');
  cleanup();
  assert.equal(disconnected, true);
});