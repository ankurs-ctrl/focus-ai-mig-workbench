from types import SimpleNamespace

import pytest

from app.agent_runs.models import AgentActor, RunCreateRequest
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.agent_runs.service import AgentRunService


def test_requested_model_must_be_configured_for_deployment() -> None:
    settings = SimpleNamespace(
        migration_agent_model_light="model-light",
        migration_agent_model_medium="model-medium",
        migration_agent_model_high="model-high",
        migration_agent_effort_overrides={},
    )
    service = AgentRunService(InMemoryAgentRunRepository(), settings=settings)
    actor = AgentActor(user_id="user-1", tenant_id="tenant-1")
    with pytest.raises(ValueError, match="not configured"):
        service.create_run(RunCreateRequest(prompt="Create a mapping", model_name="unknown"), actor)
    run = service.create_run(RunCreateRequest(prompt="Create a mapping", model_name="model-high"), actor)
    assert run.request.model_name == "model-high"
