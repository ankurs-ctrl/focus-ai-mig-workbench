"""Deterministic extraction of the target tables a prompt names.

Effort must be fixed before execution starts, and chat users name several
targets in prose ("targets AIA_WB_TARGET.{HOUSEHOLD, NOTES}" or a bulleted
list) rather than through the target_scope field. This parser only counts and
normalizes names; it never authorizes them. The supervisor still verifies every
target against the live catalog before any evidence or draft work.
"""
from __future__ import annotations

import re

_IDENT = r'"?[A-Za-z_][A-Za-z0-9_$]*"?'
_BRACE_LIST = re.compile(rf"\b({_IDENT}(?:\.{_IDENT}){{0,2}})\.\{{([^{{}}]{{1,2000}})\}}")
_FQN = re.compile(rf"(?<![\w.]){_IDENT}\.{_IDENT}\.{_IDENT}(?![\w.])")
_LIST_ITEM = r"[A-Za-z_][A-Za-z0-9_$]*(?:\.[A-Za-z_][A-Za-z0-9_$]*){0,2}"
_TARGET_LIST = re.compile(
    rf"\btarget(?:s| tables?)\b[^:\n]{{0,80}}:\s*((?:[\-*\u2022]?\s*{_LIST_ITEM}\s*(?:,|\band\b|\n|[.;]|$)\s*){{2,}})",
    re.IGNORECASE,
)
_SOURCE_CONTEXT = re.compile(r"\bsources?\b|\bfrom\b", re.IGNORECASE)
_STOPWORDS = {"AND", "THE", "ALL", "TABLES", "TABLE", "TARGETS", "TARGET"}


def _clean(value: str) -> str:
    return value.strip().strip('"').upper()


def extract_prompt_targets(prompt: str) -> list[str]:
    """Return distinct target names mentioned in the prompt, in order.

    Names are upper-cased and may be fully qualified (DB.SCHEMA.TABLE),
    schema-qualified, or bare when the prompt lists them after "targets:".
    Tables in a clause introduced by "source"/"from" are not targets.
    """
    text = str(prompt or "")
    found: list[str] = []

    def add(name: str) -> None:
        cleaned = ".".join(_clean(part) for part in name.split(".") if part.strip())
        if cleaned and cleaned.split(".")[-1] not in _STOPWORDS and cleaned not in found:
            found.append(cleaned)

    def is_source_clause(start: int, end: int | None = None) -> bool:
        # Role labels can follow the identifier: "use DB.S.T as the source".
        # Do not infer the opposite role from an earlier table in that sentence.
        suffix = text[end:end + 40] if end is not None else ""
        if re.match(r"\s+as\s+(?:the\s+|a\s+)?source\b", suffix, re.IGNORECASE):
            return True
        if re.match(r"\s+as\s+(?:the\s+|a\s+)?target\b", suffix, re.IGNORECASE):
            return False
        window = text[max(0, start - 60):start]
        last_sentence = re.split(r"[.;\n]", window)[-1]
        return bool(_SOURCE_CONTEXT.search(last_sentence)) and "target" not in last_sentence.casefold()

    for match in _BRACE_LIST.finditer(text):
        if is_source_clause(match.start(), match.end()):
            continue
        prefix = match.group(1)
        for item in re.split(r"[,\s]+", match.group(2)):
            if re.fullmatch(_IDENT, item or ""):
                add(f"{prefix}.{item}")
    brace_spans = [match.span() for match in _BRACE_LIST.finditer(text)]
    for match in _FQN.finditer(text):
        if any(start <= match.start() < end for start, end in brace_spans) or is_source_clause(match.start(), match.end()):
            continue
        add(match.group(0))
    for match in _TARGET_LIST.finditer(text):
        for item in re.split(r",|\band\b|\n|[;]|\.(?=\s|$)", match.group(1), flags=re.IGNORECASE):
            item = item.strip().lstrip("-*\u2022").strip()
            if re.fullmatch(_LIST_ITEM, item):
                if not any(existing.split(".")[-1] == _clean(item).split(".")[-1] for existing in found):
                    add(item)
    return found
