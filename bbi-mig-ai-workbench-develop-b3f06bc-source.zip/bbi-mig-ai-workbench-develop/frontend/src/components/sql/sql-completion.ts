import { SQL_FUNCTIONS_BY_CATEGORY } from './function-library.config';

/** Keywords offered as ghost-text completions in every SQL editor. */
export const SQL_COMPLETION_KEYWORDS = [
  'SELECT', 'FROM', 'WHERE', 'WITH', 'AS', 'INNER JOIN', 'LEFT JOIN',
  'RIGHT JOIN', 'FULL JOIN', 'ON', 'AND', 'OR', 'GROUP BY', 'HAVING',
  'ORDER BY', 'ASC', 'DESC', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END',
];

/**
 * Bare function names taken from the function library, so the editor completes
 * `UPPE` to `UPPER` and leaves the parentheses to auto-pairing.
 */
export const SQL_FUNCTION_COMPLETIONS = Array.from(
  new Set(
    Object.values(SQL_FUNCTIONS_BY_CATEGORY)
      .flat()
      .map((entry) => entry.split('(')[0].trim())
      .filter((name) => name && !name.includes(' ')),
  ),
);

/** Dedupes candidate lists while keeping the order they were supplied in. */
export function mergeSqlCompletionCandidates(...groups: string[][]) {
  return Array.from(new Set(groups.flat().filter(Boolean)));
}
