'use client';
import { AiaBox } from '@/components/ui';


import { SqlEditorSurface } from '../sql-editor-surface';

export type SqlPreviewSqlBlockProps = {
  sql: string;
  emptyText?: string;
};

export function SqlPreviewSqlBlock({
  sql,
  emptyText = '-- No columns mapped yet. Map columns to generate SQL.',
}: SqlPreviewSqlBlockProps) {
  return (
    <AiaBox sx={{ minHeight: 0 }}>
      <SqlEditorSurface
        value={sql}
        readOnly
        showLineNumbers={false}
        compact
        emptyText={emptyText}
      />
    </AiaBox>
  );
}
