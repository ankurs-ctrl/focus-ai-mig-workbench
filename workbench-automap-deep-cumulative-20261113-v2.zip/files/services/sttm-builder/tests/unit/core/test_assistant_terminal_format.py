import json
from app.core.sttm_builder import STTMBuilderService


def test_streamed_structured_answer_is_parsed_not_shown_as_json():
    service = object.__new__(STTMBuilderService)
    envelope = {'contract_version':'1.0','operation':'sttm.chat',
        'data':{'intent':'CHAT','status':'completed','message':'Here is the CTE draft.',
                'artifact_type':'derived_source_draft','artifact':{'sql_text':'WITH a AS (SELECT 1 AS ID) SELECT ID FROM a','source_name_suggestion':'income_source'}},
        'warnings':[],'error':None,'meta':{}}
    raw='event: response\ndata: '+json.dumps({'content':[{'type':'text','text':json.dumps(envelope)}]})+'\n\n'
    parsed=service._parse_chat_response(raw)
    assert parsed[2]=='Here is the CTE draft.'
    assert parsed[8]['sql_text'].startswith('WITH a AS')


def test_streamed_plain_markdown_remains_plain_markdown():
    service=object.__new__(STTMBuilderService)
    raw='event: response\ndata: '+json.dumps({'content':[{'type':'text','text':'**Summary:**\n\nUse the current source.'}]})+'\n\n'
    assert service._parse_chat_response(raw)[2]=='**Summary:**\n\nUse the current source.'


def test_incomplete_relationship_graph_preserves_builder_answer_without_analyst_execution():
    from types import SimpleNamespace
    from unittest.mock import Mock
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    service=object.__new__(STTMBuilderService)
    service._invoke_analyst=Mock(side_effect=AssertionError('Incomplete graph must not execute Analyst'))
    req=STTMBuilderEnvelopeRequest.model_validate({'operation':'sttm.chat','context':{},'data':{'intent':'CHAT','message':'Generate a CTE'}})
    response=SimpleNamespace(warnings=[],meta={})
    result=service._execute_requested_analyst_delegation(req,response,
        semantic_refresh=SimpleNamespace(analyst_ready=False,missing_assets=[]),decision=None)
    assert result is response
    assert result.meta['analyst_delegation_status']=='relationship_gap'
    assert result.warnings[0].code=='SEMANTIC_RELATIONSHIP_GAP'
