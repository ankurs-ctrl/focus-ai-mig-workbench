"""SQL-contract simulation for ownership-only dispatch; not native SPCS evidence."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, UTC, timedelta
from types import SimpleNamespace

import pytest

from app.core.automap_operation_tracking import OperationCallTracking, OperationAlreadyRecorded, operations_enabled
from app.core.automap_admission import Completion, AdmissionClaimUncertain, StalePermit
from tests.unit.core.test_automap_durable_runs_v2 import MemorySQL, ACCOUNT, EPOCH, TABLE, identity


class OperationsSQL(MemorySQL):
    def __init__(self):
        super().__init__()
        self.rows=[]
        self.claim_controls=0
        self.fail_commit=False

    @contextmanager
    def factory(self):
        with super().factory() as base:
            db=self
            class Session:
                def sql(self,q,params=None):
                    p=params or []
                    class Result:
                        def collect(self,**kwargs):
                            if q=='COMMIT' and db.fail_commit:
                                base.sql(q,params=p).collect(**kwargs)
                                raise OSError('lost commit acknowledgement')
                            if q.startswith('UPDATE') and '_CONTROL SET' in q:
                                db.claim_controls+=1
                            if q.startswith('SELECT SLOT_ID, STATE') and 'OPERATION_KEY=?' in q:
                                return [deepcopy(r) for r in db.rows if r.get('OPERATION_KEY')==p[0]
                                    and (len(p)==1 or r['OWNER_TOKEN']==p[1])][:2]
                            if q.startswith('SELECT SLOT_ID, STATE'):
                                assert base.active
                                account,epoch,job,caller,generation,shard,*owner=p
                                return [deepcopy(r) for r in db.rows if (r['ACCOUNT_NAMESPACE'],r['POOL_EPOCH'],r['JOB_ID'],r['CALLER_ID'],r['GENERATION'],r['SHARD_ID'])==(account,epoch,job,caller,generation,shard)
                                        and (not owner or r['OWNER_TOKEN']==owner[0])][:2]
                            if q.startswith('INSERT INTO') and '(OPERATION_KEY,ACCOUNT_NAMESPACE,POOL_EPOCH,JOB_ID' in q:
                                assert base.active
                                key,account,epoch,job,caller,generation,shard,owner,seconds=p
                                db.rows.append(dict(OPERATION_KEY=key,SLOT_ID=len(db.rows)+1,ACCOUNT_NAMESPACE=account,POOL_EPOCH=epoch,
                                    JOB_ID=job,CALLER_ID=caller,GENERATION=generation,SHARD_ID=shard,OWNER_TOKEN=owner,
                                    STATE='HELD',FENCE=1,LEASE_EXPIRES_AT=datetime.now(UTC)+timedelta(seconds=seconds),
                                    UPDATED_AT=datetime.now(UTC),RECONCILIATION_REF=None,MODEL_RUN_ID=None,
                                    REQUEST_ARCHIVE_REF=None,COMPLETION=None,DISPATCH_PROTOCOL='background_v2'))
                                return [{'number of rows inserted':1}]
                            return base.sql(q,params=p).collect(**kwargs)
                    return Result()
            yield Session()


def tracking(db):
    return OperationCallTracking(session_factory=db.factory,table=TABLE,
        account_namespace=ACCOUNT,pool_epoch=EPOCH,capacity=2,recovery_capacity=1)


def test_many_independent_operations_are_not_capped_by_legacy_capacity_or_recovery():
    db=OperationsSQL();store=tracking(db)
    with ThreadPoolExecutor(max_workers=16) as workers:
        permits=list(workers.map(lambda n: store.try_claim(identity(n)),range(48)))
    assert len({p.slot_id for p in permits})==48
    assert all(r['STATE']=='HELD' for r in db.rows)
    assert store.shared_capacity_limit is False
    assert db.claim_controls==0  # No global control-table UPDATE
    # An unrelated pending/uncertain call does not queue a new operation.
    db.rows[0]['STATE']='QUARANTINED'
    assert store.try_claim(identity(49)).slot_id==49


def test_concurrent_duplicate_is_recorded_once_and_returns_specific_outcome_without_queue():
    db=OperationsSQL();stores=[tracking(db) for _ in range(5)]
    def claim(n):
        try:return stores[n%5].try_claim(identity(1))
        except OperationAlreadyRecorded:return None
    with ThreadPoolExecutor(max_workers=10) as workers:permits=list(workers.map(claim,range(20)))
    assert sum(p is not None for p in permits)==1
    assert len(db.rows)==1
    assert db.rows[0]['STATE']=='HELD'


def test_lost_claim_commit_never_returns_dispatch_authority_and_restart_does_not_reclaim():
    db=OperationsSQL();store=tracking(db);db.fail_commit=True
    with pytest.raises(AdmissionClaimUncertain):store.try_claim(identity(1))
    db.fail_commit=False
    assert len(db.rows)==1
    with pytest.raises(OperationAlreadyRecorded):tracking(db).try_claim(identity(1))
    assert tracking(db).try_claim(identity(2)) is not None


def test_owner_scope_and_large_operation_ids_remain_fenced():
    db=OperationsSQL();store=tracking(db)
    for n in range(40):permit=store.try_claim(identity(n))
    assert permit.slot_id>32
    assert store._permit_params(permit)[2]==40
    from dataclasses import replace
    with pytest.raises(StalePermit):store._permit_params(replace(permit,pool_epoch='foreign'))
    # Completion retains the operation row, never reuses it for a second POST.
    store.complete(permit,Completion.SUCCEEDED)
    with pytest.raises(OperationAlreadyRecorded):store.try_claim(identity(39))


def test_only_server_frozen_new_requests_use_operation_tracking():
    settings=SimpleNamespace(automap_shared_capacity_limit=False)
    assert operations_enabled(settings)
    assert operations_enabled(settings,SimpleNamespace(meta={'_automap_call_tracking':'operation_v3'}))
    assert not operations_enabled(settings,SimpleNamespace(meta={}))
    assert not operations_enabled(settings,SimpleNamespace(meta={'_automap_call_tracking':'pooled_v2'}))

@pytest.mark.parametrize('mode',['success','nested_run_id','lost_submit_ack','cancel_409'])
def test_background_transport_preserves_one_post_and_recovery_without_slot_pool(monkeypatch, mode):
    import tests.unit.core.test_automap_durable_runs_v2 as existing
    monkeypatch.setattr(existing,'MemorySQL',OperationsSQL)
    monkeypatch.setattr(existing,'pool',tracking)
    existing.test_real_background_transport_reaches_model_and_confirms_terminal_before_release(mode)


def test_native_snowpark_diagnostics_retain_sqlstate_without_query_or_token():
    from app.core.sql_failure import sql_failure_details
    from snowflake.snowpark.exceptions import SnowparkSQLException
    from snowflake.connector.errors import ProgrammingError
    native=ProgrammingError(msg='private SQL and credentials',errno=200001,sqlstate='23001',sfqid='safe-query-id')
    error=SnowparkSQLException('private query',conn_error=native)
    assert sql_failure_details(error)=={'error_type':'SnowparkSQLException','sql_error_code':'200001',
        'sql_state':'23001','query_id':'safe-query-id'}


def test_frozen_operation_requests_survive_capacity_setting_changes():
    settings=SimpleNamespace(automap_shared_capacity_limit=True)
    assert operations_enabled(settings,SimpleNamespace(meta={'_automap_call_tracking':'operation_v3'}))
    assert not operations_enabled(settings,SimpleNamespace(meta={'_automap_call_tracking':'pooled_v2'}))
