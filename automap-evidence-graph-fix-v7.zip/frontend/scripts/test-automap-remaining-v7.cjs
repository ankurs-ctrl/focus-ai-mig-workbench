// Synthetic fixtures execute the actual acceptance thunk, application reducers and retry planner.
const assert=require('node:assert/strict');
const test=require('node:test').test;
const ts=require('typescript');
const h=require('./test-automap-preservation.cjs');
const {helpers,compile,reducer,stateFor,blank,imported,response,direct}=h;
let acceptThunk,applyOne,applyAll;
function visit(node){
  if(ts.isVariableDeclaration(node)&&node.name.getText(h.slice)==='acceptPendingAiMappingReviews')acceptThunk=node.initializer.arguments[1].getText(h.slice);
  if(ts.isPropertyAssignment(node)&&node.name.getText(h.slice)==='applyPendingAiMappingReview')applyOne=node.initializer.getText(h.slice);
  if(ts.isPropertyAssignment(node)&&node.name.getText(h.slice)==='applyAllPendingAiMappingReviews')applyAll=node.initializer.getText(h.slice);
  ts.forEachChild(node,visit);
}
visit(h.slice);
const values=[{name:'FirmID',value:'old'}];
const revision=helpers.autoMapRevisionHash(helpers.autoMapValuesSignature(values));
function queued(){
  const state=stateFor(imported(),blank('NEW'));
  state.selectedMappingIds=['NAME'];
  reducer(h.pendingReducer)(state,{meta:{requestId:'run-one'}});
  state.autoMapRun.valuesRevision=revision;
  helpers.applyAutoMapResponseToState(state,response(direct));
  assert.equal(state.pendingAiMappingReviews.length,1);
  assert.equal(state.pendingAiMappingReviews[0].autoMapValuesRevision,revision);
  state.autoMapRun=null;
  return state;
}
function accept(state,{all=false,newValues=values,change,fail=false}={}){
  const actions=[];
  const fn=compile(`return (${acceptThunk});`,{...helpers,
    listProjectAttributes:async()=>{if(change)change(state);if(fail)throw Error('Read unavailable');return newValues;},
    getErrorMessage:error=>error.message,
    applyPendingAiMappingReview:payload=>({type:'one',payload}),applyAllPendingAiMappingReviews:payload=>({type:'all',payload})});
  return fn({all},{getState:()=>({sttmBuilder:state}),dispatch:action=>{
    actions.push(action);reducer(action.type==='all'?applyAll:applyOne)(state,action);
  },rejectWithValue:error=>({error})}).then(result=>({result,actions}));
}

test('delayed single acceptance rechecks unchanged project Values and applies once',async()=>{
  const state=queued();const {result,actions}=await accept(state);
  assert.equal(result,undefined);assert.equal(actions.length,1);
  assert.equal(state.mappings[0].sourceColumn,'src.NewName');assert.equal(state.pendingAiMappingReviews.length,0);
  await accept(state);assert.equal(state.mappings[0].sourceColumn,'src.NewName');
});
for(const all of [false,true])test(`changed Values hold queued proposal (all=${all})`,async()=>{
  const state=queued(),before=structuredClone(state.mappings);
  await accept(state,{all,newValues:[{name:'FirmID',value:'new'}]});
  assert.deepEqual(state.mappings,before);assert.equal(state.pendingAiMappingReviews.length,1);assert.match(state.errorState.autoMap,/held/);
});
test('Value read failure retains proposals and makes no apply dispatch',async()=>{
  const state=queued();const {result,actions}=await accept(state,{fail:true});
  assert.match(result.error,/unavailable/);assert.equal(actions.length,0);assert.equal(state.pendingAiMappingReviews.length,1);
});
for(const change of [s=>s.mappingSql='SELECT changed',s=>s.activeProjectId='different',s=>s.activeSttmId='different'])
  test('workspace/shared changes during the Value read fence delayed acceptance',async()=>{
    const state=queued();const {result,actions}=await accept(state,{change});
    assert.match(result.error,/changed/);assert.equal(actions.length,0);assert.equal(state.pendingAiMappingReviews.length,1);
  });
test('manual edit during Value lookup and changed proposal contents cannot be consumed',async()=>{
  const state=queued();await accept(state,{change:s=>{s.mappings[0].expression='src.UserEdit';}});
  assert.equal(state.mappings[0].expression,'src.UserEdit');assert.equal(state.pendingAiMappingReviews.length,1);
  const other=queued();await accept(other,{change:s=>{s.pendingAiMappingReviews[0].preprocessingRule='src.Other';}});
  assert.equal(other.mappings[0].expression,imported().expression);assert.equal(other.pendingAiMappingReviews.length,1);
});
test('direct action without verified Values proof is fail closed',()=>{
  const state=queued();reducer(applyOne)(state,{payload:undefined});
  assert.equal(state.pendingAiMappingReviews.length,1);assert.equal(state.mappings[0].expression,imported().expression);
});
test('apply-all accepts current siblings and retains a stale sibling',async()=>{
  const state=queued();const second={...state.pendingAiMappingReviews[0],mappingId:'NEW',targetColumn:'NEW'};
  second.autoMapInputSignature=helpers.autoMapRevisionHash(helpers.autoMapInputSignature(state.mappings[1]));
  second.autoMapValuesRevision='stale';state.pendingAiMappingReviews.push(second);
  await accept(state,{all:true});assert.equal(state.mappings[0].sourceColumn,'src.NewName');assert.equal(state.mappings[1].sourceColumn,null);
  assert.deepEqual(state.pendingAiMappingReviews.map(row=>row.targetColumn),['NEW']);
});
function retryState(){
  const state=stateFor(blank('VALUE'),blank('FORMAT'),blank('EVIDENCE'));
  state.autoMapOutcome={retry_context_by_target:Object.fromEntries(state.mappings.map((row,i)=>[row.targetColumn,{
    outcome_code:['missing_business_input','malformed_reference','source_not_examined'][i],
    shared_revision:helpers.autoMapRevisionHash(helpers.autoMapSharedInputs(state)),values_revision:revision,
    row_revision:helpers.autoMapRevisionHash(helpers.autoMapInputSignature(row))}]))};
  for(const row of state.mappings)row.transformationClassification='unresolved';
  return state;
}
test('retry reasons choose missing input, repair or retrieval without changing overwrite authority',()=>{
  const state=retryState();const plan=helpers.autoMapRetryPlan(state,['VALUE','FORMAT','EVIDENCE'],revision);
  assert.deepEqual(plan.blocked,['VALUE']);assert.deepEqual(plan.names,['FORMAT','EVIDENCE']);
  assert.equal(plan.hints.FORMAT.action,'repair');assert.equal(plan.hints.EVIDENCE.action,'retrieve');
  assert.equal(helpers.autoMapScope(state,{action:'retry_unresolved'}).mode,'preserve_and_complete');
});
for(const change of [s=>s.mappingSql='new SQL',s=>s.mappingIntent={business_goal:'Approved rule'},s=>s.learningContextHash='new learning',s=>s.mappings[0].nlRule='approved input'])
  test('changed relevant inputs allow the missing-input target to be reconsidered',()=>{
    const state=retryState();change(state);const plan=helpers.autoMapRetryPlan(state,['VALUE'],revision);
    assert.deepEqual(plan.names,['VALUE']);assert.equal(plan.hints.VALUE.action,'check_business_input');
  });
test('changed current Values allow reconsideration; old outcomes without revisions are not treated as proof',()=>{
  const state=retryState();assert.deepEqual(helpers.autoMapRetryPlan(state,['VALUE'],'new revision').names,['VALUE']);
  state.autoMapOutcome=null;assert.deepEqual(helpers.autoMapRetryPlan(state,['VALUE'],revision).names,['VALUE']);
});

function runHarness({missingOnly=false,resultMissing=false,resultReview=false,priorMissing=false,newValues=values}={}){
  const state=stateFor(blank('VALUE'),blank('FORMAT'));
  if(missingOnly)state.mappings=state.mappings.slice(0,1);
  Object.assign(state,{sources:[{qualifiedName:'D.S.SOURCE',isSelected:true}],targets:[{qualifiedName:'D.T.TARGET',isSelected:true}],
    derivedSources:[],sourceAttributeGroups:[{columns:[{name:'Name'}]}],relationships:[],
    targetAttributeGroup:{qualifiedName:'D.T.TARGET',columns:state.mappings.map(row=>({name:row.targetColumn}))},
    semanticBundleId:'bundle',semanticContextItems:[{}]});
  state.semanticDependencySignature=helpers.autoMapSourceInputs(state);
  for(const row of state.mappings)row.transformationClassification='unresolved';
  if(priorMissing){
    state.autoMapOutcome={retry_context_by_target:Object.fromEntries(state.mappings.map(row=>[row.targetColumn,{
      outcome_code:row.targetColumn==='VALUE'?'missing_business_input':'malformed_reference',
      shared_revision:helpers.autoMapRevisionHash(helpers.autoMapSharedInputs(state)),values_revision:revision,
      row_revision:helpers.autoMapRevisionHash(helpers.autoMapInputSignature(row))}]))};
  }
  const requests=[];const create=type=>payload=>({type,payload});
  const fn=compile(`return (${h.thunkSource});`,{...helpers,
    resolveSelectedSourceTables:s=>s.sources,resolveSelectedTargetTable:s=>s.targets[0],
    makeTableRef:q=>{const[database,schema,table]=q.split('.');return{database,schema,table};},
    estimateAutoMapComplexity:()=>0,autoMapBatchesInitialized:create('init'),autoMapStreamStatus:create('status'),
    autoMapSemanticPrepared:create('semantic'),autoMapBatchStarted:create('started'),autoMapBatchApplied:create('applied'),
    getSelectedDerivedSourceIds:()=>[],listProjectAttributes:async()=>newValues,
    snapshotFromState:()=>({mapping_rows:[]}),findTargetDescription:()=>null,qualifiedTableRefOrNull:()=>null,
    buildRelationshipPayload:()=>[],buildRelationGraph:()=>({}),buildSelectedColumnsByTable:()=>({}),getErrorMessage:e=>e.message,
    workbenchService:{getAutoMapCapabilities:async()=>({selected_scope:true,reevaluation:true}),startAutoMapJob:async req=>{
      requests.push(req);
      return{status:'completed',partial_responses:[],response:{operation:'sttm.auto_map',result:{mappings:Object.fromEntries(
        req.attributes.map(item=>[item.target_attribute,resultMissing?{source_attributes:[],confidence_score:0,
          transformation_classification:'unresolved',unmatched_reason:'Missing business rule'}:direct]))},
        meta:{automap_evidence_review_only_targets:resultReview?req.attributes.map(item=>item.target_attribute):[],auto_map_retrieval:{targets:req.attributes.map(item=>({target:item.target_attribute,
          outcome_code:resultMissing?'missing_business_input':'grounded'}))}}}};
    }},
  });
  return{state,requests,run:async()=>{
    reducer(h.pendingReducer)(state,{meta:{requestId:'run-one',arg:{action:'retry_unresolved'}}});
    return fn({action:'retry_unresolved'},{requestId:'run-one',getState:()=>({sttmBuilder:state}),dispatch:action=>{
      if(action.type==='started')reducer(h.startReducer)(state,action);
      if(action.type==='applied')reducer(h.appliedReducer)(state,action);
    },rejectWithValue:error=>({error})});
  }};
}
test('actual retry thunk makes no job request for unchanged missing business input',async()=>{
  const t=runHarness({missingOnly:true,priorMissing:true});const result=await t.run();
  assert.match(result.error,/Update that input/);assert.equal(t.requests.length,0);
});
test('actual retry thunk excludes only blocked targets and sends scoped repair guidance',async()=>{
  const t=runHarness({priorMissing:true});const result=await t.run();assert.equal(result.error,undefined);
  assert.deepEqual(t.requests[0].attributes.map(row=>row.target_attribute),['FORMAT']);
  assert.deepEqual(t.requests[0].meta.auto_map_target_scope,['FORMAT']);
  assert.equal(t.requests[0].meta.auto_map_retry_outcomes.FORMAT.action,'repair');
  assert.equal(t.state.mappings[0].sourceColumn,null);assert.equal(t.state.mappings[1].sourceColumn,'src.NewName');
});
test('actual retry thunk uses current Values and records outcome revisions for the next retry',async()=>{
  const t=runHarness({missingOnly:true,priorMissing:true,newValues:[{name:'FirmID',value:'new'}],resultMissing:true});
  const first=await t.run();assert.equal(first.error,undefined);assert.equal(t.requests.length,1);
  const record=first.autoMapOutcome.retry_context_by_target.VALUE;
  assert.equal(record.outcome_code,'missing_business_input');assert.notEqual(record.values_revision,revision);
  t.state.autoMapOutcome=first.autoMapOutcome;t.state.autoMapRun=null;
  const second=await t.run();assert.match(second.error,/Update that input/);assert.equal(t.requests.length,1);
});

test('rule-stage outcomes from every worker override earlier grounded source outcomes',()=>{
  const result=helpers.autoMapTargetOutcomeCodes({meta:{auto_map_retrieval_batches:[
    {targets:[{target:'FIRST',outcome_code:'grounded'}]},{targets:[{target:'SECOND',outcome_code:'grounded'}]}],
    transformation_stage_batches:[{target_outcomes:{FIRST:'invalid_expression'}},{target_outcomes:{SECOND:'evidence_block_incomplete'}}]}});
  assert.deepEqual(result,{FIRST:'invalid_expression',SECOND:'evidence_block_incomplete'});
});

test('actual Auto-map response stamps a durable Value revision before delayed acceptance',async()=>{
  const t=runHarness({missingOnly:true,resultReview:true});const result=await t.run();
  assert.equal(result.error,undefined);assert.equal(t.state.pendingAiMappingReviews.length,1);
  assert.equal(t.state.pendingAiMappingReviews[0].autoMapValuesRevision,revision);
  t.state.autoMapRun=null;
  await accept(t.state);
  assert.equal(t.state.pendingAiMappingReviews.length,0);assert.equal(t.state.mappings[0].sourceColumn,'src.NewName');
});
