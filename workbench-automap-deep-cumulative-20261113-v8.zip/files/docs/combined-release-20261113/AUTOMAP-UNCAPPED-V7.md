# Auto-map ownership-only parallel dispatch — cumulative v7

**Superseded by v8:** a later audit found the child-batch projection dropped the new tracking marker. The standalone ownership test below was valid, but the v7 full model runs still used pooled admission. Read AUDIT-HANDOFF-V8.md and use the corrected release.

## What changes

New durable Auto-map generations no longer acquire preallocated shared execution slots. Each logical model call inserts its own record in TBL_AUTOMAP_CALL_OPERATIONS, using an enforced unique operation key. Concurrent independent calls do not wait for other calls to finish; simultaneous duplicates are refused, completed receipts can be reused during recovery, and uncertain submissions are never replayed blindly. The existing per-job batch scheduler, shared submission budget, worker concurrency, caller authorization, context limits and Snowflake/provider throttling remain. This removes the global application slot ceiling, not every resource safeguard or infrastructure failure.

A native standard-table prototype still contended on its shared claim-control UPDATE. The released design removes that UPDATE entirely and uses a small HYBRID metadata table with enforced primary/unique keys and row-level locking. Snowflake account support for hybrid tables is required; bootstrap fails explicitly if unavailable. There is no silent fallback to the blocking slot pool for new generations.

Old frozen jobs retain their original pooled-v2 tracking. Recovery discovers both stores and never migrates, resets or replays old permits. New call records are not recycled; uncertain calls remain attached to their original identities without blocking unrelated calls. Existing legacy admission settings remain for old-job recovery/rollback compatibility and do not cap operation-v3 calls.

Rows now sort by descending estimated confidence across mapping states. Business Suggestions display only explicitly model-authored suggestions with provenance. Compiler, binding, scoring and dependency fallback messages remain stored as diagnostics rather than business advice. Existing legacy suggestions without reliable model provenance are not relabeled as model advice. Agent instructions require evidence-backed, target-specific business recommendations; backend confidence calculation and validation remain.

## Deploy before running new Auto-map jobs

1. Apply all cumulative files, preserving client.env, other environment files and credentials. Deploy matching frontend, API, Auto-map worker and Deep worker images together. No failed client job is replayed by this release.
2. Run the existing full metadata bootstrap in the configured metadata namespace. It now creates TBL_AUTOMAP_CALL_OPERATIONS as a HYBRID table and TBL_AUTOMAP_CALL_OPERATIONS_EVENTS. It validates table type, enforced operation primary key, unique numeric record ID and existing inventory; it never resets old records. Do not run bootstrap in a transient schema: Snowflake hybrid tables require a supported permanent database/schema. Do not use --sql-upload-recovery-only to install these objects.
3. Apply the updated administrator-run grant template to the two new operational tables. Runtime/caller roles need SELECT, INSERT, UPDATE on OPERATIONS and SELECT, INSERT on OPERATIONS_EVENTS. Restricted caller service owners need matching CALLER allowances. Exact statements are in client_admin_setup_template.sql and setup-caller-grants.sql; substitute existing client roles/namespace. Bootstrap intentionally does not expand privileges automatically. No INSERT or UPDATE permission is needed on business source/target tables for this change.
4. Deploy the updated AGT_SOURCE_MAPPING and AGT_TRANSFORMATION_RULE specifications. agent_spec_manifest.json is updated. Safe/single-service scripts hash the actual files; the standard deployment script now does too when no explicit hash override is supplied. If client.env pins AGENT_SPEC_SOURCE_MAPPING_SHA256 or AGENT_SPEC_TRANSFORMATION_RULE_SHA256, replace those with the manifest values below, or remove those stale overrides so deployment derives the file hashes.
5. AUTOMAP_SHARED_CAPACITY_LIMIT=false is the default in backend, renderer and both web/Auto-map-worker service templates. All three client deployment scripts forward it. No client.env edit is needed unless an existing override explicitly sets true. Optional rollback true restores pooled behavior for fresh generations; keep both metadata stores and their recovery records intact.
6. Confirm rendered webapp and Auto-map-worker specifications both contain AUTOMAP_SHARED_CAPACITY_LIMIT: "false". Keep existing durable fast-path enablement enabled. Start a fresh isolated mapping run and inspect actual model submissions, operation_claim timing and completed responses.

## Validation

- Full backend suite: 5772 passed, 32 skipped. Frontend: 490 passed. TypeScript passed. Deployment/profile/bootstrap checks included.
- Native ownership test: six independent calls owned records simultaneously despite legacy capacity argument one; preparation 1.98–2.61 seconds. Six simultaneous duplicate claims produced exactly one owner. Enforced bootstrap constraints verified natively. No model calls in this metadata-only test.
- Real Loan Income HTTP prepare/job/private-worker acceptance, starting without execution context: two completed runs, 284.32s and 185.30s; 33 target outcomes each. Each had 32 positive-confidence proposals and one explicit missing dependency. Each completed two custom rules; warm run also retained one rule-pending outcome. This is not a claim that every target is executable or business-approved.
- Real mixed native acceptance: 40 targets, 12 sources, five concurrent source batches, two transformation submissions, 161.66s, 40 supported proposals, FIR recipe reuse and expected output checks passed, no failed batches. Complete initial evidence needed zero optional retrieval calls.
- These runs used native Snowflake sessions/models through local production code and private-worker endpoints. They are not a five-replica SPCS deployment benchmark or proof of the exact historical client blocker. No client mappings, account settings, roles or grants were changed by acceptance. Scratch fixtures were isolated; no production semantic pipeline was run.

The removed shared pool cannot explain all elapsed time: Loan acceptance still spent time in page preparation, model repairs and transformations. Provider/database outages and missing business inputs remain explicit. See the accompanying safe JSON reports for timings, submission counts and outcomes.

## Agent hashes

AGT_SOURCE_MAPPING: `8a7d4a8e596522e87b7057a311dd489ed5654ad2cc1c7ec0cd7c67a27da959cc`

AGT_TRANSFORMATION_RULE: `f8ffac6c64cfc4a33acf69f7144b0c95d7f70b7d81370542b959470af8910609`

