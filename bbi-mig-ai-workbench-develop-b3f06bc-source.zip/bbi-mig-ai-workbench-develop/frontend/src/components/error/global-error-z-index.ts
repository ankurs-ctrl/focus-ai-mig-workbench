/**
 * Stacking for the global API/error alert dialog.
 * Must sit above every in-app overlay (modals ~1400, menus ~1600, loading ~9999).
 */
export const GLOBAL_ERROR_DIALOG_Z_INDEX = 20000;
