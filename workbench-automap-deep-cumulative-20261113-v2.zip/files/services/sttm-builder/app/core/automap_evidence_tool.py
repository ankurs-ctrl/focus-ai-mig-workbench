"""Bounded native evidence tool registration; no arbitrary model SQL."""
from copy import deepcopy
import json
from uuid import uuid4


def records_for(store):
    records = []
    for target, categories in store.evidence.items():
        for category, values in categories.items():
            kind = 'correction' if 'correction' in category else 'fir'
            for value in values:
                if not isinstance(value, dict):
                    continue
                from app.core.automap_retrieval import digest
                pattern = value.get('pattern') or value
                identity = pattern.get('record_id') or ('fir:' + str(pattern['pattern_id']) if pattern.get('pattern_id') else 'evidence:' + digest(value))
                records.append({'record_id':identity, 'kind':kind, 'targets':[target], 'body':deepcopy(value)})
    for relation, value in store.tables.items():
        from app.core.automap_retrieval import digest
        records.append({'record_id':'semantic:'+digest([relation,value]), 'kind':'semantic',
                        'targets':sorted(store.targets), 'body':{'relation':relation, 'semantics':deepcopy(value)}})
    for identity, value in store.dependencies.items():
        records.append({'record_id':'dependency:'+identity, 'kind':'dependency',
                        'targets':sorted(store.targets), 'body':deepcopy(value)})
    return records


class EvidenceToolContext:
    def __init__(self, *, runtime, store, request, stage, message_chars, message_bytes):
        self.handle = uuid4().hex
        self.runtime, self.request = runtime, request
        self.stage = stage
        self.body = {'targets':sorted(store.targets), 'records':records_for(store)}
        self.max_chars = max(0, min(32000, 180000-message_chars))
        self.max_bytes = max(0, min(32000, 180000-message_bytes))

    def register(self, archive):
        # The exact request is already durable. Use the same caller-scoped
        # session/deadline provider; no new connections or admission slots.
        caller = self.runtime.bundle.archive._caller
        table = self.runtime._service._settings.qualify_metadata_object_name('TBL_AUTOMAP_TOOL_CONTEXT')
        body = json.dumps(self.body,ensure_ascii=False,separators=(',',':'))
        if len(body.encode('utf-8')) > archive._max_bytes:
            raise ValueError('Retained tool evidence exceeds artifact limit')
        with archive.checkpoint() as checkpoint:
            rows = archive._sql(checkpoint.session, f'''INSERT INTO {table}
                (CONTEXT_HANDLE,OWNER_USER,OWNER_ROLE,ACCOUNT_NAMESPACE,ACCESS_SCOPE,JOB_ID,BATCH_ID,
                 STAGE,CONTEXT_BODY,EXPIRES_AT,MAX_CHARS,MAX_BYTES)
                SELECT ?,?,?,?,?,?,?,?,PARSE_JSON(?),DATEADD('second', ?,CURRENT_TIMESTAMP()),?,?''',
                [self.handle, caller.native_user,caller.role,caller.account_namespace,caller.access_scope,
                    self.runtime.bundle.admission.job_id,self.request.shard_id,self.stage,
                    body, max(1,min(600,int(self.request.remaining_seconds()))),self.max_chars,self.max_bytes])
            result = rows[0].as_dict() if len(rows)==1 and hasattr(rows[0], 'as_dict') else {}
            if result.get('number of rows inserted') != 1:
                raise ValueError('Tool context registration was not acknowledged')


def enabled(settings, stage):
    name = 'agent_spec_transformation_rule_sha256' if stage == 'transformation_rule' else 'agent_spec_source_mapping_sha256'
    value = getattr(settings, name, '')
    return type(value) is str and len(value) == 64


def tool_hint(handle, targets=()):
    return {'type':'text','text':json.dumps({'automap_native_evidence':{
        'version':'native-evidence-v1','context_handle':handle,'tool':'ReadAutoMapEvidence','targets':list(targets),
        'instruction':'Use supplied evidence first. Only if necessary, retrieve retained evidence for requested targets. At most two calls. Never use a tool when this context handle is absent.'}},separators=(',',':'))}


def context_handle(request):
    for message in json.loads(request.message):
        for block in message.get('content', []):
            try:
                value = json.loads(block.get('text','')).get('automap_native_evidence', {})
            except (ValueError, AttributeError):
                continue
            if value.get('version') == 'native-evidence-v1':
                return value.get('context_handle')
    return None


def verify_context(archive, request, job_id):
    handle = context_handle(request)
    if not handle:
        return None
    caller = archive._caller
    table = archive._table.rsplit('.',1)[0]+'.TBL_AUTOMAP_TOOL_CONTEXT'
    with archive._session() as session:
        rows = archive._sql(session, f'''SELECT CONTEXT_HANDLE FROM {table}
            WHERE CONTEXT_HANDLE=? AND OWNER_USER=? AND OWNER_ROLE=? AND ACCOUNT_NAMESPACE=?
            AND ACCESS_SCOPE=? AND JOB_ID=? AND BATCH_ID=? AND CALL_COUNT BETWEEN 0 AND 2''',
            [handle,caller.native_user,caller.role,caller.account_namespace,caller.access_scope,job_id,request.shard_id])
    return handle if len(rows)==1 else None


def final_content(payload, handle):
    """Validate paired native tool blocks; extract only final assistant text."""
    from app.core.automap_scan_transport import ScanTransportError
    calls, returned, content = {}, set(), []
    for block in payload.get('content', []):
        kind = block.get('type') if isinstance(block, dict) else None
        if kind not in {'tool_use','tool_result'}:
            content.append(block)
            continue
        value = block.get(kind)
        if not isinstance(value, dict) or value.get('name') != 'ReadAutoMapEvidence' or value.get('type') != 'generic':
            raise ScanTransportError('Unexpected native tool in terminal response')
        identity = value.get('tool_use_id')
        if not isinstance(identity, str) or not identity or len(identity)>256:
            raise ScanTransportError('Invalid native tool identity')
        if kind == 'tool_use':
            args = value.get('input')
            if (not isinstance(args, dict) or set(args) != {'CONTEXT_HANDLE','REQUEST_JSON'}
                    or args['CONTEXT_HANDLE'] != handle or not isinstance(args['REQUEST_JSON'], str)
                    or identity in calls or len(calls)>=2):
                raise ScanTransportError('Native evidence tool scope mismatch')
            calls[identity] = True
        else:
            if identity not in calls or identity in returned or value.get('status') not in {'success','error'}:
                raise ScanTransportError('Unpaired native evidence result')
            returned.add(identity)
    if set(calls) != returned:
        raise ScanTransportError('Incomplete native evidence tool response')
    return {**payload, 'content':content}


def requested_targets(messages, fallback):
    from app.core.automap_retrieval import target_name
    for message in messages:
        for block in message.get('content', []):
            try:
                packet = json.loads(block.get('text', ''))
            except (ValueError, TypeError):
                continue
            if not isinstance(packet, dict):
                continue
            attributes = (packet.get('data') or {}).get('attributes')
            if not isinstance(attributes, list):
                continue
            names = [target_name(item['target_attribute']) for item in attributes
                     if isinstance(item, dict) and isinstance(item.get('target_attribute'), str)]
            if names and len(names) == len(attributes) and len(set(names)) == len(names) and set(names) <= set(fallback):
                return tuple(sorted(names))
    return tuple(fallback)
