'use client';

import { useEffect, type ReactNode } from 'react';
import { AiaBox, AiaButton, AiaIconButton } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { CloseOutlinedIcon } from '@/utils/icons';
import { textStyleCssVars } from '@/config/typography-tokens';

type SttmNoticeDialogProps = {
  open: boolean;
  title: string;
  message: ReactNode;
  tone?: 'warning' | 'error';
  closeLabel?: string;
  actionLabel?: string;
  onAction?: () => void;
  onClose: () => void;
};

const TONE_COLORS = {
  warning: { accent: '#B45309', surface: '#FFFBEB', border: '#FDE68A' },
  error: { accent: '#B91C1C', surface: '#FEF2F2', border: '#FECACA' },
} as const;

/** Blocking notice popup for STTM builder actions (same look as the mapping confirm dialog). */
export function SttmNoticeDialog({
  open,
  title,
  message,
  tone = 'warning',
  closeLabel = 'Close',
  actionLabel,
  onAction,
  onClose,
}: SttmNoticeDialogProps) {
  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, [open]);
  if (!open) {
    return null;
  }
  const colors = TONE_COLORS[tone];

  return (
    <AiaBox
      role="alertdialog"
      aria-modal="true"
      aria-label={title}
      onClick={onClose}
      sx={{
        position: 'fixed',
        inset: 0,
        zIndex: 1400,
        px: 2,
        py: 4,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(15, 23, 42, 0.42)',
        backdropFilter: 'blur(4px)',
      }}
    >
      <AiaBox
        onClick={(event) => event.stopPropagation()}
        sx={{
          width: '100%',
          maxWidth: 520,
          maxHeight: 'calc(100dvh - 32px)',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: '16px',
          border: '1px solid rgba(15, 23, 42, 0.08)',
          boxShadow: '0 30px 60px rgba(15, 23, 42, 0.18)',
          overflow: 'hidden',
          backgroundColor: '#FFFFFF',
        }}
      >
        <AiaBox
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: 1.5,
            px: 2.5,
            py: 2,
            borderBottom: '1px solid #EEF2F7',
          }}
        >
          <AiaText
            sx={{
              ...textStyleCssVars('cardTitle'),
              letterSpacing: '-0.01em',
              color: colors.accent,
            }}
          >
            {title}
          </AiaText>
          <AiaIconButton
            onClick={onClose}
            aria-label="Close"
            sx={{
              width: 32,
              height: 32,
              border: '1px solid #E2E8F0',
              color: '#64748B',
              bgcolor: '#FFFFFF',
              '&:hover': { bgcolor: '#F8FAFC' },
            }}
          >
            <CloseOutlinedIcon sx={{ fontSize: 18 }} />
          </AiaIconButton>
        </AiaBox>

        <AiaBox sx={{ px: 2.5, py: 2.25, minHeight: 0, overflowY: 'auto', overscrollBehavior: 'contain' }}>
          <AiaBox
            sx={{
              px: 1.75,
              py: 1.5,
              borderRadius: '10px',
              border: `1px solid ${colors.border}`,
              backgroundColor: colors.surface,
              fontSize: 14,
              color: '#334155',
              lineHeight: 1.6,
              maxHeight: 260,
              overflowY: 'auto',
              whiteSpace: 'pre-wrap',
              overflowWrap: 'anywhere',
            }}
          >
            {message}
          </AiaBox>
        </AiaBox>

        <AiaBox
          sx={{
            px: 2.5,
            py: 2,
            borderTop: '1px solid #EEF2F7',
            display: 'flex',
            alignItems: 'center',
            flexShrink: 0,
            justifyContent: 'flex-end',
            gap: 1.25,
          }}
        >
          <AiaButton
            variant="outlined"
            onClick={onClose}
            sx={{
              minWidth: 96,
              height: 38,
              borderRadius: '10px',
              borderColor: '#dbe2ea',
              color: '#334155',
              fontSize: 14,
              fontWeight: 600,
              textTransform: 'none',
            }}
          >
            {closeLabel}
          </AiaButton>
          {actionLabel && onAction ? (
            <AiaButton
              variant="contained"
              color="primary"
              onClick={onAction}
              sx={{
                minWidth: 120,
                height: 38,
                borderRadius: '10px',
                fontSize: 14,
                fontWeight: 700,
                textTransform: 'none',
              }}
            >
              {actionLabel}
            </AiaButton>
          ) : null}
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
