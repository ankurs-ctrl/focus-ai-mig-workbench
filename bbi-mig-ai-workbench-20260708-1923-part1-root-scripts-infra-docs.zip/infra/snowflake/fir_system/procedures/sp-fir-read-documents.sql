-- ============================================================
-- SP_FIR_READ_DOCUMENTS
-- Tool for AGT_FIR_SYSTEM to read raw uploaded document content
-- from TBL_WORKBENCH_CLIENT_SQL_ASSETS for intelligent parsing.
-- Returns full SQL text, metadata, and attributes for LLM analysis.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_READ_DOCUMENTS(
    "LIMIT_COUNT" INTEGER DEFAULT 10,
    "STATUS_FILTER" VARCHAR DEFAULT 'active',
    "ASSET_ID" VARCHAR DEFAULT NULL
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'read_documents'
EXECUTE AS OWNER
AS
$$
import json
from datetime import datetime


def read_documents(session, limit_count: int = 10, status_filter: str = 'active', asset_id: str = None) -> dict:
    """Read uploaded documents for the FIR agent to parse and understand."""
    results = {
        'status': 'success',
        'documents': [],
        'total_found': 0,
        'read_at': datetime.utcnow().isoformat()
    }

    try:
        if asset_id:
            rows = session.sql("""
                SELECT
                    SQL_ASSET_ID,
                    PROJECT_ID,
                    ENTITY_TYPE,
                    ENTITY_IDS,
                    TITLE,
                    SQL_TEXT,
                    SQL_KIND,
                    DIALECT,
                    DESCRIPTION,
                    SOURCE_LABEL,
                    AUTHOR_NAME,
                    TAGS,
                    ATTRIBUTES,
                    STATUS,
                    CREATED_AT,
                    UPDATED_AT
                FROM __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_CLIENT_SQL_ASSETS
                WHERE SQL_ASSET_ID = ?
            """, [asset_id]).collect()
        else:
            rows = session.sql(f"""
                SELECT
                    SQL_ASSET_ID,
                    PROJECT_ID,
                    ENTITY_TYPE,
                    ENTITY_IDS,
                    TITLE,
                    SQL_TEXT,
                    SQL_KIND,
                    DIALECT,
                    DESCRIPTION,
                    SOURCE_LABEL,
                    AUTHOR_NAME,
                    TAGS,
                    ATTRIBUTES,
                    STATUS,
                    CREATED_AT,
                    UPDATED_AT
                FROM __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_CLIENT_SQL_ASSETS
                WHERE STATUS = ?
                ORDER BY CREATED_AT DESC
                LIMIT {limit_count}
            """, [status_filter]).collect()

        results['total_found'] = len(rows)

        for row in rows:
            entity_ids = row['ENTITY_IDS']
            if isinstance(entity_ids, str):
                try:
                    entity_ids = json.loads(entity_ids)
                except Exception:
                    pass

            tags = row['TAGS']
            if isinstance(tags, str):
                try:
                    tags = json.loads(tags)
                except Exception:
                    pass

            attributes = row['ATTRIBUTES']
            if isinstance(attributes, str):
                try:
                    attributes = json.loads(attributes)
                except Exception:
                    pass

            doc = {
                'sql_asset_id': row['SQL_ASSET_ID'],
                'project_id': row['PROJECT_ID'],
                'entity_type': row['ENTITY_TYPE'],
                'entity_ids': entity_ids,
                'title': row['TITLE'],
                'sql_text': row['SQL_TEXT'],
                'sql_kind': row['SQL_KIND'],
                'dialect': row['DIALECT'],
                'description': row['DESCRIPTION'],
                'source_label': row['SOURCE_LABEL'],
                'author_name': row['AUTHOR_NAME'],
                'tags': tags,
                'attributes': attributes,
                'status': row['STATUS'],
                'created_at': str(row['CREATED_AT']) if row['CREATED_AT'] else None,
                'updated_at': str(row['UPDATED_AT']) if row['UPDATED_AT'] else None
            }
            results['documents'].append(doc)

    except Exception as e:
        results['status'] = 'failed'
        results['error'] = str(e)

    return results
$$;
