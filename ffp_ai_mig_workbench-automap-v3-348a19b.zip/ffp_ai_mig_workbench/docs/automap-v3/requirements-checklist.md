# Auto-map v3 requirement audit

Status is specific to the local checkout and separate test account. Passing synthetic
regressions is not a substitute for the accepted client answer-key benchmark.

| Plan requirement | Status / evidence |
| --- | --- |
| Requested latest branch | Working on requested `sync/uat-frontend-native-integration`, local base `09e39f3`; remote latest verification requires GitHub credentials. |
| Archive experiment and create develop feature branch | Not performed. User requested the existing integration branch; no Git writes without the plan's explicit approval. Native sources remain recoverable from local Git history. |
| Client mapping 10301 / 3102 keys and master/develop baselines | Not accessible here; IDs absent in test account. Git objects `fa449c4` and `f3fbdf4` are also absent locally. |
| Benchmark scoring tool | Implemented; audited to read actual nested recipe packets, real per-batch call/timing metrics, precedent decisions, citation membership, and rule compile counts. |
| Native code/wiring removal | Implemented. Semantic registry utility retained. Deployed native objects have not been dropped. |
| Reusable strict JSON, proposal compiler, guidance, local SSO/PAT | Extracted. Local SSO/PAT guard and authentication identity checks tested. |
| Separate approved teardown with backups | Read-only preparation utility added under docs/automap-v3; backup/inventory execution and approved teardown remain pending. No destructive Snowflake operation has been run. |
| YAML descriptions, synonyms, samples, types, metrics/expr handling | Implemented; human descriptions take priority, computed metrics are non-executable knowledge. |
| Fallback sample profiles | Implemented from the existing registry `COLUMN_PROFILE_CACHE`, only when authored/YAML samples are absent. |
| Non-executable YAML, executable Analyst eligibility | YAML retained separately; Analyst still uses the prepared executable-view path. |
| Cached semantic column catalog and bundle artifact | Implemented. |
| >=90% non-echo admitted semantics | Registry-backed 37-field fixture currently reports 100% for every batch; exact ACCOUNTS/HOUSEHOLD client gate remains pending its data. |
| RRF name/synonym/BM25/type/join/CTE/forced precedence | Implemented; audit connected graph signal, avoids rebuilding shared docs per target, and retains forced precedent sources. |
| Candidate reasons | Added to emitted `target_candidates`; originally missing from the first implementation. |
| Business capsule, Values, target semantics, table recommendations | Implemented using current request and canonical execution/learning records. Stored recommendations remain usable when tasks are suspended. |
| 80 KB target and trimming sequence | Implemented sequence: index, samples, 15/10/6 candidates, historical SQL-body deferral. Mandatory excess is explicitly reported. Real 37-field test wire packets are 37,479–79,414 bytes; all under 80 KB. |
| Three source calls and one evidence round | Implemented. Separate transformation generation plus one repair. |
| Delegation soft deficit and explicit CASE data question | Implemented; unsupported legacy delegation does not discard grounded siblings. |
| Latest published FIR SQL, T1–T4, scope, CRM, recency, applicability, shape support | Implemented and SQL-compiled against test account. Current corrections/negatives do not compete for the four-positive quota. |
| Legacy FIR learning without version ID | Retained as explicit T4 guidance, never falsely labelled a latest verified publication. Two stored Redtail recipes verified live. |
| Parallel Search fallback | Added with independent same-caller sessions when available; no concurrent use of one request Snowpark session. |
| Publish CRM/HUBSPOT/logical target and supersession | Implemented and tested. |
| Canonical reuse across projects | Existing client-scope behavior verified by test; project-scoped overrides deliberately remain project-scoped. |
| CRM/recency Search attributes | SQL source updated; deployment of service changes is still pending. |
| Idempotent backfill | SQL preparation implemented; not executed in any account. |
| FIR freshness check | Local test account: eleven tasks suspended, no recent runs, 894 stored recommendations; no task state changed. Client DEV/UAT not accessed. |
| Protocol/spec/examples, packet citation validation | Implemented; review downgrade for invalid/missing receipt. |
| Stronger model comparison | Completed on equal packets: Haiku 37/37, zero invalid citations, 24.585 s; Sonnet 37/37, 13 invalid citations, 82.991 s. Kept Haiku. |
| Spec runtime-change opt-in, diff and hashes | Implemented; final hash refresh follows code/spec checks. |
| Independent runtime, OAuth/local SSO, configurable 8, deadlines | Implemented. Existing provisioned durable pool stays at four until separately resized. |
| Prep once per job | Canonical prep/discovery frozen in job handoff; per-worker admission remains batch-specific. |
| Transformation admitted scope/full context/Values/sqlglot repair | Implemented; expressions remain compiler checked. Rule batches run with their parallel owning workers. |
| Local application start and full mapping request | Local backend startup/health passed with current hash-pinned request-scoped v3 specs. Client accepted mapping request remains a separate release gate. |
| 37 targets <=150s / accuracy >=master | Generated 37-field identity test: 37/37, zero invalid/missing citations, 12.641 s prep + 24.585 s model wall. Client business accuracy/master-baseline comparison is not established. |
| DEV SPCS/UAT pipeline deployment and query-history load check | Not performed; client environment unavailable and local test account differs. |
| UAT smoke and object teardown | Pending successful release and explicit approval for destructive steps. |
| UI scope | Originally no UI changes. User subsequently authorized CTE project browsing and manual Save dialog changes; implemented only those requested UI changes. |


Final code audit validation: 2,431 selected regression tests passed; 92 final targeted
checks passed. The complete plan is **not released end-to-end**: the client accepted
answer-key/master comparison, client deployments, committed backfill and approved
teardown remain outstanding as listed above. Subsequent requested UI changes and validation are recorded in additional-mapping-requirements.md.
