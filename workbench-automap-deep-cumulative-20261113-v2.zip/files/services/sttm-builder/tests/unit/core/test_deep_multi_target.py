from typing import Any

from app.agent_runs.contracts import ProjectDecisionV1
from app.agent_runs.models import EffortLevel, RunCreateRequest, ToolResult, resolve_effort
from app.agent_runs.prompt_scope import extract_prompt_targets
from app.agent_runtime.execution import ExecutionBudget
from app.agent_tools.capability_registry import CapabilityRegistry
from app.migration_workflow.dependency_inference import infer_mapping_dependencies
from app.migration_workflow.graph import _project_decision
from app.migration_workflow.manifest import build_manifest_from_specs

TMD_PROMPT = (
    "Create a TMD project in FFP_HDP_DLAB_DB_DEV with targets AIA_WB_TARGET.{HOUSEHOLD, BIZ_ACCOUNTS, "
    "BIZ_CONTACTS, PERSONACCOUNT, AGREEMENTS, ALERTS, CALLS, MEETINGS, NOTES, TASKS} from sources SCH_TMD_SOURCE"
)


def test_prompt_targets_cover_brace_lists_fqns_and_bullets_but_not_sources() -> None:
    assert len(extract_prompt_targets(TMD_PROMPT)) == 10
    assert extract_prompt_targets("Map DB.TGT.HOUSEHOLD from DB.SRC.CONTACTS") == ["DB.TGT.HOUSEHOLD"]
    assert extract_prompt_targets("Target tables: HOUSEHOLD, NOTES, TASKS and CALLS. Sources are in X.") == [
        "HOUSEHOLD", "NOTES", "TASKS", "CALLS",
    ]
    assert extract_prompt_targets("Target tables:\n- HOUSEHOLD\n- NOTES\n") == ["HOUSEHOLD", "NOTES"]
    assert extract_prompt_targets("Hello what all can you do") == []


def test_ten_named_targets_resolve_auto_effort_to_high() -> None:
    assert resolve_effort(RunCreateRequest(prompt=TMD_PROMPT)) is EffortLevel.HIGH
    three = "Create mappings for targets: DB.T.A, DB.T.B, DB.T.C"
    assert resolve_effort(RunCreateRequest(prompt=three)) is EffortLevel.MEDIUM


def _specs(*targets: str) -> list[dict[str, Any]]:
    return [{"mapping_key": target.split(".")[-1].lower(), "target_table": target} for target in targets]


def test_old_mappings_sharing_a_source_key_produce_a_column_scoped_edge() -> None:
    specs = _specs("DB.TGT.HOUSEHOLD", "DB.TGT.CALLS")
    edges, candidates = infer_mapping_dependencies(
        specs,
        target_columns={
            "DB.TGT.HOUSEHOLD": ["FINSERV__SOURCESYSTEMID__C", "NAME", "HOUSEHOLD_TYPE__C"],
            "DB.TGT.CALLS": ["SUBJECT", "FINSERV__HOUSEHOLD__C"],
        },
        precedent_lineage={
            "DB.TGT.HOUSEHOLD": [{"sttm_id": "h1", "sttm_status": "COMPLETE", "column_lineage": {
                "FINSERV__SOURCESYSTEMID__C": ["DEV.SRC.CONTACTS.FAMILY_ID"], "NAME": ["DEV.SRC.CONTACTS.NAME"]}}],
            "DB.TGT.CALLS": [{"sttm_id": "c1", "sttm_status": "COMPLETE", "column_lineage": {
                "FINSERV__HOUSEHOLD__C": ["PROD.SRC.CONTACTS.FAMILY_ID"], "SUBJECT": ["PROD.SRC.ACTIVITIES.SUBJECT"]}}],
        },
    )

    assert len(edges) == 1
    edge = edges[0]
    assert (edge["consumer_mapping"], edge["producer_mapping"]) == ("calls", "household")
    assert edge["consumer_columns"] == ["FINSERV__HOUSEHOLD__C"]
    assert edge["producer_columns"] == ["FINSERV__SOURCESYSTEMID__C"]
    assert edge["blocking_scope"] == "column" and edge["confidence"] == 0.75
    assert edge["evidence_id"].startswith("sttm_precedent:")
    # HOUSEHOLD_TYPE__C is an attribute, not a reference to another target.
    assert not any(item["consumer_column"] == "HOUSEHOLD_TYPE__C" for item in candidates)


def test_a_column_name_alone_is_a_review_candidate_never_an_edge() -> None:
    edges, candidates = infer_mapping_dependencies(
        _specs("DB.TGT.HOUSEHOLD", "DB.TGT.NOTES"),
        target_columns={"DB.TGT.HOUSEHOLD": ["ID", "NAME"], "DB.TGT.NOTES": ["BODY", "HOUSEHOLD__C"]},
    )

    assert edges == []
    assert candidates == [{
        "consumer_mapping": "notes", "consumer_column": "HOUSEHOLD__C", "producer_mappings": ["household"],
        "confidence": 0.5, "reason": "Only the column name suggests this reference; confirm the key crosswalk.",
    }]


def test_a_shared_key_that_names_no_producer_stays_a_candidate() -> None:
    lineage = lambda sttm, column: [{"sttm_id": sttm, "sttm_status": "COMPLETE",  # noqa: E731
                                     "column_lineage": {column: ["S.CONTACTS.ID"]}}]
    edges, candidates = infer_mapping_dependencies(
        _specs("DB.T.HOUSEHOLD", "DB.T.PERSONACCOUNT", "DB.T.TASKS"),
        target_columns={"DB.T.HOUSEHOLD": ["LEGACY_ID__C"], "DB.T.PERSONACCOUNT": ["LEGACY_ID__C"],
                        "DB.T.TASKS": ["WHOID"]},
        precedent_lineage={"DB.T.HOUSEHOLD": lineage("h", "LEGACY_ID__C"),
                           "DB.T.PERSONACCOUNT": lineage("p", "LEGACY_ID__C"),
                           "DB.T.TASKS": lineage("t", "WHOID")},
    )

    assert edges == []
    assert candidates[0]["consumer_column"] == "WHOID"
    assert sorted(candidates[0]["producer_mappings"]) == ["household", "personaccount"]


def test_a_mutual_reference_keeps_the_stronger_edge_and_demotes_the_cycle() -> None:
    edges, candidates = infer_mapping_dependencies(
        _specs("DB.T.ACCOUNT", "DB.T.CONTACT"),
        target_columns={"DB.T.ACCOUNT": ["ID", "CONTACTID"], "DB.T.CONTACT": ["ID", "ACCOUNTID"]},
        target_foreign_keys={
            "DB.T.CONTACT": [{"fk_column": "ACCOUNTID", "pk_table": "DB.T.ACCOUNT", "pk_column": "ID"}],
        },
        fir_cards={"DB.T.ACCOUNT": [{"learning_type": "mapping_dependency", "learning_id": "L1",
                                     "text": "ACCOUNT CONTACTID resolves CONTACT ID"}]},
    )

    assert [(edge["consumer_mapping"], edge["producer_mapping"]) for edge in edges] == [("contact", "account")]
    demoted = next(item for item in candidates if "cycle" in item["reason"])
    assert (demoted["consumer_mapping"], demoted["consumer_column"]) == ("account", "CONTACTID")


def test_manifest_is_built_from_every_mapping_spec_with_its_dependencies() -> None:
    specs = [
        {"mapping_key": name.lower(), "mapping_name": name, "target_table": f"DB.T.{name}"}
        for name in ("HOUSEHOLD", "BIZ_ACCOUNTS", "BIZ_CONTACTS", "PERSONACCOUNT", "AGREEMENTS",
                     "ALERTS", "CALLS", "MEETINGS", "NOTES", "TASKS")
    ]
    manifest = build_manifest_from_specs(specs, [
        {"consumer_mapping": "calls", "producer_mapping": "household"},
        {"consumer_mapping": "notes", "producer_mapping": "household"},
    ])

    assert [item["target_table"] for item in manifest] == [spec["target_table"] for spec in specs]
    assert {item["mapping_key"]: item["dependencies"] for item in manifest}["calls"] == ["household"]
    assert all(item["dependencies"] == [] for item in manifest if item["mapping_key"] not in {"calls", "notes"})


def test_new_project_request_overrides_the_open_project_but_the_default_does_not() -> None:
    forced = _project_decision({"project_decision": {"force_new": True, "project_name": "TMD"}}, "101")
    assert forced["operation"] == "create" and forced["project_id"] is None
    default = _project_decision({"project_decision": {"operation": "create", "run_owned": True}}, "101")
    assert default["operation"] == "reuse" and default["project_id"] == "101"
    assert _project_decision({}, None)["operation"] == "create"
    try:
        ProjectDecisionV1(force_new=True)
    except ValueError:
        pass
    else:
        raise AssertionError("A forced new project needs a name")


class _MultiTargetWorkbench:
    """Three targets; NOTES has no current source design."""

    columns = {
        "DB.TGT.HOUSEHOLD": ["FINSERV__SOURCESYSTEMID__C", "NAME"],
        "DB.TGT.CALLS": ["SUBJECT", "FINSERV__HOUSEHOLD__C"],
        "DB.TGT.NOTES": ["BODY", "HOUSEHOLD__C"],
    }
    lineage = {
        "DB.TGT.HOUSEHOLD": {"FINSERV__SOURCESYSTEMID__C": ["DB.SRC.CONTACTS.FAMILY_ID"], "NAME": ["DB.SRC.CONTACTS.NAME"]},
        "DB.TGT.CALLS": {"FINSERV__HOUSEHOLD__C": ["DB.SRC.CONTACTS.FAMILY_ID"], "SUBJECT": ["DB.SRC.ACTIVITIES.SUBJECT"]},
    }
    driving = {"DB.TGT.HOUSEHOLD": "DB.SRC.CONTACTS", "DB.TGT.CALLS": "DB.SRC.ACTIVITIES"}

    def inspect_table_contract(self, table_fqn: str) -> ToolResult:
        return ToolResult(status="succeeded", summary="ok", data={"columns": self.columns[table_fqn]})

    def prepare_migration_evidence(self, _context, *, source_tables, target_table, precedent_project_ids) -> ToolResult:
        driving = self.driving.get(target_table)
        columns = self.columns[target_table]
        candidate = {
            "normalized_intent": f"Build {target_table}",
            "project_decision": {"operation": "create", "run_owned": True},
            "source_preparation": {"driving_source": driving, "target_table": target_table,
                                   **({} if driving else {"unresolved_items": ["No current driving source"]})},
            "auto_map": {"target_columns": columns, "mapping_evidence": [
                {"target_column": column, "source_columns": [f"{(driving or 'X').split('.')[-1]}.{column}"],
                 "mapping_mode": "direct"} for column in columns]},
            "evidence_ids_used": [f"evidence:{target_table}"],
        }
        return ToolResult(status="succeeded", summary=f"Prepared {target_table}", data={
            "source_tables": [driving] if driving else [],
            "plan_candidate": candidate,
            "target_contract": {"table": target_table, "columns": columns},
            "exact_target_precedents": [{"sttm_id": f"old:{target_table}", "sttm_status": "COMPLETE",
                                         "column_lineage": self.lineage.get(target_table, {})}],
            "fir": {"cards": []},
        })


class _FirmValueWorkbench(_MultiTargetWorkbench):
    def firm_values_inventory(self, _context, target_tables) -> ToolResult:
        assert target_tables == ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS"]
        return ToolResult(status="succeeded", summary="Project 101 holds the missing values.", data={
            "missing": [{"name": "HHRecordType"}, {"name": "TaskRecordTypeID"}],
            "import_sources": [{
                "project_id": "101",
                "project_name": "Redtail TMD Project",
                "names": ["HHRecordType", "TaskRecordTypeID"],
            }],
        })


def _registry(workbench: Any) -> CapabilityRegistry:
    registry = CapabilityRegistry(
        context_provider=lambda: {"intent": "NEW_MIGRATION_TASK", "run_id": "multi-run",
                                  "prompt_named_targets": ["A", "B"]},
        workflow_executor=lambda *_args: {},
        workbench=workbench,
        budget=ExecutionBudget(model_limit=64, tool_limit=200),
    )
    registry.begin_run({"run_id": "multi-run"})
    registry.tools()  # installs the host plan validator
    return registry


def test_multi_target_evidence_stages_ready_mappings_and_reports_the_rest() -> None:
    registry = _registry(_MultiTargetWorkbench())
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")

    result = tool.invoke({"target_tables": ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS", "DB.TGT.NOTES"]})

    assert result["status"] == "succeeded", result
    data = result["data"]
    assert [item["target_table"] for item in data["ready_mappings"]] == ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS"]
    assert [item["target_table"] for item in data["needs_research"]] == ["DB.TGT.NOTES"]
    assert data["dependencies"][0]["consumer_mapping"] == "calls"
    assert data["dependencies"][0]["producer_columns"] == ["FINSERV__SOURCESYSTEMID__C"]
    assert data["plan_validation"]["status"] == "succeeded", data["plan_validation"]
    staged = registry.validated_supervisor_plan
    assert [spec["target_table"] for spec in staged["mapping_specs"]] == ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS"]
    # Each mapping carries its own evidence, not the first target's.
    calls = next(spec for spec in staged["mapping_specs"] if spec["mapping_key"] == "calls")
    assert calls["auto_map"]["target_columns"] == ["SUBJECT", "FINSERV__HOUSEHOLD__C"]
    assert calls["source_preparation"]["driving_source"] == "DB.SRC.ACTIVITIES"


def test_multi_target_plan_offers_one_firm_value_import_before_project_creation() -> None:
    registry = _registry(_FirmValueWorkbench())
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")

    result = tool.invoke({"target_tables": ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS"]})

    assert result["status"] == "succeeded", result
    decisions = registry.prepared_plan_candidate["decisions"]
    import_decision = next(item for item in decisions if item["subject"] == "value_binding_import")
    assert import_decision["selected_value"] == "import:101"
    assert import_decision["names"] == ["HHRecordType", "TaskRecordTypeID"]
    assert import_decision["question"] == (
        "Import the required firm values available from this precedent project?"
    )


def test_a_mapping_spec_is_held_to_its_own_targets_evidence() -> None:
    registry = _registry(_MultiTargetWorkbench())
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")
    tool.invoke({"target_tables": ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS"]})
    plan = dict(registry.prepared_plan_candidate)
    validator = next(item for item in registry.tools() if item.name == "validate_migration_plan")

    swapped = [dict(spec) for spec in plan["mapping_specs"]]
    swapped[1] = {**swapped[1], "source_preparation": {**swapped[1]["source_preparation"],
                                                       "driving_source": "DB.SRC.CONTACTS"}}
    rejected = validator.invoke({"plan": {**plan, "mapping_specs": swapped}})

    assert rejected["error_code"] == "mapping_spec_invalid"
    assert rejected["data"]["mapping_spec_issues"][0]["error_code"] == "source_graph_evidence_stale"

    forced = validator.invoke({"plan": {**plan, "project_decision": {"force_new": True, "project_name": "TMD Redtail"}}})
    assert forced["status"] == "succeeded"
    assert registry.validated_supervisor_plan["project_decision"]["force_new"] is True


class _PrecedentWorkbench(_MultiTargetWorkbench):
    """HOUSEHOLD and CALLS each have an old design on another client's copy of the sources."""

    designs = {
        "DB.TGT.HOUSEHOLD": ("101", "DB.OLD.CONTACTS", ["DB.OLD.CONTACTS", "DB.OLD.FAMILIES"]),
        "DB.TGT.CALLS": ("202", "DB.OLD.ACTIVITIES", ["DB.OLD.ACTIVITIES", "DB.OLD.CONTACTS"]),
    }

    def __init__(self) -> None:
        self.prepared: list[tuple[str, list[str]]] = []

    def prepare_migration_evidence(self, _context, *, source_tables, target_table, precedent_project_ids) -> ToolResult:
        self.prepared.append((target_table, list(source_tables)))
        result = super().prepare_migration_evidence(_context, source_tables=source_tables, target_table=target_table,
                                                    precedent_project_ids=precedent_project_ids)
        design = self.designs.get(target_table)
        if design:
            result.data["research_summary"] = {"output_equivalent_precedents": [{"sttm_id": design[0]}]}
        return result

    def inspect_precedent_mapping(self, sttm_id, target, *, output_equivalent=False, requested_text="", selected_scope=None):
        design = next(value for value in self.designs.values() if value[0] == sttm_id)
        identical = [{"historical_table": table, "current_table": table.replace("DB.OLD.", "DB.SRC.")}
                     for table in design[2]]
        return ToolResult(status="succeeded", summary="Inspected", data={
            "sql_driving_source_candidate": design[1],
            "current_schema_counterparts": [
                {"schema": "DB.OTHER", "named_in_request": False, "identical": [], "different_columns": [],
                 "identical_count": 9, "historical_table_count": 2},
                {"schema": "DB.SRC", "named_in_request": True, "identical": identical, "different_columns": [],
                 "identical_count": len(identical), "historical_table_count": len(identical)},
            ]})


def test_every_target_gets_its_own_sources_from_its_precedent_or_an_explicit_override() -> None:
    workbench = _PrecedentWorkbench()
    registry = _registry(workbench)
    registry._catalog_candidates.add("DB.SRC.NOTES")  # found by catalog search earlier in the run
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")

    result = tool.invoke({"target_tables": ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS", "DB.TGT.NOTES"],
                          "sources_by_target": {"NOTES": ["DB.SRC.NOTES"]}})

    final = {target: sources for target, sources in workbench.prepared if sources}
    # Driving source first, translated into the requested schema (never DB.OTHER).
    assert final["DB.TGT.HOUSEHOLD"] == ["DB.SRC.CONTACTS", "DB.SRC.FAMILIES"]
    assert final["DB.TGT.CALLS"] == ["DB.SRC.ACTIVITIES", "DB.SRC.CONTACTS"]
    assert final["DB.TGT.NOTES"] == ["DB.SRC.NOTES"]
    selection = {item["target_table"]: item["source_selection"] for item in result["data"]["per_target"]}
    assert selection == {"DB.TGT.HOUSEHOLD": "precedent_counterparts", "DB.TGT.CALLS": "precedent_counterparts",
                         "DB.TGT.NOTES": "explicit"}


def test_host_applies_the_precedent_design_after_a_stalled_source_decision() -> None:
    workbench = _PrecedentWorkbench()
    registry = _registry(workbench)
    registry._catalog_candidates.update({"DB.TGT.HOUSEHOLD", "DB.TGT.NOTES"})  # verified targets
    registry._prepared_plan_review = {"target_table": "DB.TGT.HOUSEHOLD",
                                      "research_summary": {"output_equivalent_precedents": [{"sttm_id": "101"}]}}
    result = registry.prepare_evidence_from_precedent_design()
    assert result is not None and result["status"] == "succeeded"
    assert workbench.prepared[-1] == ("DB.TGT.HOUSEHOLD", ["DB.SRC.CONTACTS", "DB.SRC.FAMILIES"])
    # Without a precedent the host does not guess.
    registry._prepared_plan_review = {"target_table": "DB.TGT.NOTES", "research_summary": {}}
    assert registry.prepare_evidence_from_precedent_design() is None
