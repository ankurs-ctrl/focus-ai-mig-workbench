"use client";
import { AiaBox } from '@/components/ui';
import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

import { AiChatMainOverlay } from "@/features/ai-agent/ai-chat-shell-integration";
import { AiChatRailTab, AiChatSidebarPanel } from "@/features/ai-agent/ai-chat-shell-host";
import { useAiChatLayout } from "@/features/ai-agent/ai-chat-layout-context";
import { APP_NAV_ROUTES } from "./app-sidebar-types";
import AppSidebar from "./app-sidebar";
import type { AppNavItem } from "./app-sidebar-types";

type AppShellProps = {
  activeNav?: AppNavItem;
  initialNewMappingOpen?: boolean;
  children: React.ReactNode;
};

export default function AppShell({
  activeNav,
  initialNewMappingOpen = false,
  children,
}: AppShellProps) {
  const pathname = usePathname();
  const workspaceRef = useRef<HTMLDivElement | null>(null);
  const { isOpen, isFullscreen, setLayoutMetrics } = useAiChatLayout();
  const isAiAgentRoute =
    pathname === APP_NAV_ROUTES["AI Agent"]
    || pathname.startsWith(`${APP_NAV_ROUTES["AI Agent"]}/`);

  useEffect(() => {
    const node = workspaceRef.current;
    if (!node) return;

    const update = () => {
      setLayoutMetrics(node.clientWidth, node.clientHeight);
    };

    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => observer.disconnect();
  }, [setLayoutMetrics]);

  return (
    <AiaBox
      sx={{
        display: "flex",
        flex: 1,
        minHeight: 0,
        overflow: "hidden",
        bgcolor: "#F7F8FA",
      }}
    >
      <AppSidebar activeNav={activeNav} initialNewMappingOpen={initialNewMappingOpen} />
      <AiaBox
        ref={workspaceRef}
        sx={{
          flex: 1,
          minWidth: 0,
          minHeight: 0,
          display: "flex",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {isAiAgentRoute ? (
          <AiaBox
            component="main"
            sx={{
              flex: 1,
              minWidth: 0,
              minHeight: 0,
              display: "flex",
              flexDirection: "column",
              overflow: "hidden",
              position: "relative",
            }}
          >
            {children}
          </AiaBox>
        ) : isOpen && isFullscreen ? (
          <AiChatSidebarPanel />
        ) : (
          <>
            <AiaBox
              component="main"
              sx={{
                flex: 1,
                minWidth: 0,
                minHeight: 0,
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
                position: "relative",
              }}
            >
              <AiChatMainOverlay />
              {children}
            </AiaBox>

            {isOpen ? <AiChatSidebarPanel /> : <AiChatRailTab />}
          </>
        )}
      </AiaBox>
    </AiaBox>
  );
}
