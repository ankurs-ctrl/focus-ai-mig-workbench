# Cached preparation and background-loading release (v3)

The cached evidence path now runs the same server-owned finalizer as cold preparation. It attaches a real execution context after the authoritative workspace/Value/learning overlays, then calculates its proof. An unchanged server-owned preparation does not create a second runtime snapshot. Worker checks remain strict; client handles and hashes do not create preparation authority.

The frontend fences results using authored inputs rather than semantic/learning handles, validation-cache signatures, recommendations, counts or loading state. Initial Values are awaited and compared through their canonical business signature, including placeholder/resolution state. Changes to source/target membership, CTE dependency SQL, joins, filters, mapping intent, business Values and manually edited rows remain protected. Background installation of unchanged Values does not hold a result.

Published semantics have one owner: the prepared-context service. On workspace entry/preparation, one selected-object fingerprint read covers table, column, native, legacy and curated published assets, including CTE physical dependencies. Changed assets invalidate the prepared identity and bypass the older bundle cache. No semantic agent, pipeline or native-view rebuild is invoked. Missing YAML remains a coverage gap and permits supported drafts. There is no polling or mid-run refresh.

Preparation invariants are recorded as AUTO_MAP_PREPARATION_INVALID with a safe stage, invariant and request reference. The UI displays that reference. OAuth grant rejection is separately classified as authentication required; only the rejected owner's existing session is marked inactive, avoiding repeated refresh attempts. No credentials are cleared, other sessions reset, model calls replayed or completed results deleted.

## Actual endpoint acceptance

Two real Loan Income runs used HTTP prepare -> HTTP durable job -> private worker endpoint -> native Snowflake source/rule agents. Requests started with execution_context=null. No execution context, preparation proof or worker handoff was injected by the harness. Concurrent page/click preparation coalesced to one durable handle; the second run cleared memory and loaded its handle from durable storage.

| Measurement | Concurrent page/click preparation | Durable-cache click |
|---|---:|---:|
| Targets / physical sources | 33 / 3, plus a driving CTE | 33 / 3, plus a driving CTE |
| Durable job completion | 200.72 s | 223.70 s |
| Parent preparation | 18.43 s | 9.23 s |
| Cached semantic/FIR retrieval in parent | 0 / 0 ms | 0 / 0 ms |
| Native source submissions | 5 | 5 |
| Native transformation submissions | 4 | 3 |
| Completed model responses | 9 | 8 |
| Initial source POST spread | 8.62 s | 17.54 s |
| Failed batches | 0 | 0 |
| Supported positive-confidence proposals | 32 | 32 |
| Executable custom rules | 5 | 4 |
| Specific missing dependencies | 1 | 1 |

Every target received numeric estimated confidence. INCOME_REVIEW_DOCUMENT remained an explicit missing dependency with confidence 0; it was not fabricated. The first run's 32 supported definitions compiled together and returned three real rows from a preview with LIMIT 5. Its estimated supported scores ranged from 0.55 to 0.95. The second run also produced 32 supported definitions. Different direct/custom choices are agent proposals, not business approval.

Persisted job records from both runs independently confirmed a non-null server execution context, a real snapshot, matching preparation hash and cache_source=prepared_workspace. All ten worker invocations received server snapshots. Complete native messages remained below 180,000 characters and bytes. Scratch operational tables/agents were removed after both runs were terminal. No client job was replayed or client mapping modified.

Read CACHED-PREPARATION-RESULTS.json for phase/submission evidence and retained query IDs, and LOAN-PREPARED-JOB-MAPPINGS.csv for reviewable output. These measurements used local ASGI/private-worker endpoints, real native Snowflake agents and independent native caller control-session test leases. They are not a newly deployed SPCS acceptance, a production load test or a 140-second performance pass. Worker preparation and durable I/O still contribute to latency. The existing SPCS parallel scheduler/admission policy was retained.

The Loan fixture contains current published semantics, but no synthetic FIR was injected. Existing FIR, Value, linked/cross-project, missing-YAML, confidence, SQL-upload/preview/publication, administration and Deep Agent cases remain in the regression suite. Real Loan assumptions still require review: timezone meaning, portal-history selection, note population and ranking ties. The missing document dependency needs additional business sources. Provider outages and missing business inputs can still produce explicit unfinished outcomes.

## Regression checks

Final backend suite: 5,737 passed, 32 skipped; final frontend suite: 482 passed; final TypeScript: passed. Additional focused preparation/authorization/OAuth checks: 35 passed. SQL-upload validation/preview/publication, FIR/confidence, administration and Deep Agent checks remain included. Original client OAuth failures cannot be attributed to a user/job from the supplied anonymous messages; known recovery errors now include their available owner/job context.

## Deployment

Apply the cumulative files/ overlay to the repository root. Preserve all environment files and credentials. Rebuild and deploy matching frontend, API and Auto-map worker images together to every replica; do not leave an old worker behind. This v3 follow-up adds no production table, grant, agent instruction, capacity setting, timeout or context-limit change. The cumulative package still contains the earlier Deep Agent and evidence-tool/bootstrap changes; deployments that have not installed them must follow INSTALL.md and the Deep Agent deployment notes.

Existing failed client jobs are historical evidence, not automatic replay requests. The fixes apply to a new authorized Auto-map generation. No client mapping changes are required. Source references, scoring, SQL-upload behavior and earlier rendering fixes are retained.
