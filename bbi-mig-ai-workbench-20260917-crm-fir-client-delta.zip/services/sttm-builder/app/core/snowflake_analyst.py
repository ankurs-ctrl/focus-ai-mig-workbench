import json
import hashlib
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Iterator

import httpx

from app.core.exceptions import SnowflakeAgentError

_HTTP_CLIENT_LOCK = threading.Lock()
_HTTP_CLIENTS: dict[str, httpx.Client] = {}
_ANALYST_CACHE_LOCK = threading.Lock()
_ANALYST_CACHE: dict[str, tuple[float, "SnowflakeAnalystResponse"]] = {}
_ANALYST_IN_FLIGHT: dict[str, threading.Event] = {}
_ANALYST_FAILURES: dict[str, tuple[float, str]] = {}
_ANALYST_CACHE_TTL_SECONDS = 300.0
_ANALYST_CACHE_MAX_ENTRIES = 256


def _shared_http_client(base_url: str) -> httpx.Client:
    with _HTTP_CLIENT_LOCK:
        client = _HTTP_CLIENTS.get(base_url)
        if client is None or client.is_closed:
            client = httpx.Client(
                limits=httpx.Limits(
                    max_connections=30,
                    max_keepalive_connections=15,
                    keepalive_expiry=60.0,
                )
            )
            _HTTP_CLIENTS[base_url] = client
        return client


@dataclass
class SnowflakeAnalystResponse:
    request_id: str | None
    text: str | None
    sql: str | None
    suggestions: list[str] = field(default_factory=list)
    warnings: list[dict[str, Any]] = field(default_factory=list)
    response_metadata: dict[str, Any] = field(default_factory=dict)
    raw_message: dict[str, Any] = field(default_factory=dict)
    verified_query_used: dict[str, Any] | None = None


class SnowflakeAnalystClient:
    _ENDPOINT = "/api/v2/cortex/analyst/message"

    def __init__(
        self,
        token: str,
        *,
        host: str,
        auth_mode: str = "oauth_bearer",
        role: str | None = None,
        warehouse: str | None = None,
    ) -> None:
        resolved_host = (host or "").strip()
        if not resolved_host:
            raise SnowflakeAgentError("SNOWFLAKE_HOST is not set for Cortex Analyst requests.")
        self._token = token
        self._host = resolved_host
        self._base_url = f"https://{resolved_host}"
        self._auth_mode = auth_mode
        self._role = (role or "").strip()
        self._warehouse = (warehouse or "").strip()

    def ask(
        self,
        *,
        question: str,
        semantic_view: str | None = None,
        semantic_model_yaml: str | None = None,
        semantic_views: list[str] | None = None,
    ) -> SnowflakeAnalystResponse:
        payload = self._build_payload(
            question=question,
            semantic_view=semantic_view,
            semantic_model_yaml=semantic_model_yaml,
            semantic_views=semantic_views,
            stream=False,
        )
        cache_material = json.dumps(
            {
                "payload": payload,
                "host": self._host.lower(),
                "role": self._role.upper(),
                "warehouse": self._warehouse.upper(),
                # Scope cached results to the delegated credential without ever
                # retaining or logging the credential itself.
                "credential": hashlib.sha256(self._token.encode("utf-8")).hexdigest(),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        cache_key = hashlib.sha256(cache_material.encode("utf-8")).hexdigest()
        now = time.monotonic()
        with _ANALYST_CACHE_LOCK:
            failure = _ANALYST_FAILURES.get(cache_key)
            if failure and failure[0] > now:
                raise SnowflakeAgentError(failure[1])
            if failure:
                _ANALYST_FAILURES.pop(cache_key, None)
            cached = _ANALYST_CACHE.get(cache_key)
            if cached and cached[0] > now:
                response = cached[1]
                return SnowflakeAnalystResponse(
                    request_id=response.request_id,
                    text=response.text,
                    sql=response.sql,
                    suggestions=list(response.suggestions),
                    warnings=list(response.warnings),
                    response_metadata={**response.response_metadata, "cache_source": "memory"},
                    raw_message=dict(response.raw_message),
                    verified_query_used=response.verified_query_used,
                )
            if cached:
                _ANALYST_CACHE.pop(cache_key, None)
            in_flight = _ANALYST_IN_FLIGHT.get(cache_key)
            if in_flight is None:
                in_flight = threading.Event()
                _ANALYST_IN_FLIGHT[cache_key] = in_flight
                owns_request = True
            else:
                owns_request = False
        if not owns_request:
            in_flight.wait(timeout=240.0)
            retry_wait: threading.Event | None = None
            with _ANALYST_CACHE_LOCK:
                cached = _ANALYST_CACHE.get(cache_key)
                if cached and cached[0] > time.monotonic():
                    response = cached[1]
                    return SnowflakeAnalystResponse(
                        request_id=response.request_id,
                        text=response.text,
                        sql=response.sql,
                        suggestions=list(response.suggestions),
                        warnings=list(response.warnings),
                        response_metadata={**response.response_metadata, "cache_source": "coalesced"},
                        raw_message=dict(response.raw_message),
                        verified_query_used=response.verified_query_used,
                    )
                failure = _ANALYST_FAILURES.get(cache_key)
                if failure and failure[0] > time.monotonic():
                    raise SnowflakeAgentError(failure[1])
                existing_retry = _ANALYST_IN_FLIGHT.get(cache_key)
                if existing_retry is None:
                    # The owner failed or timed out. Exactly one waiter becomes
                    # the bounded retry owner; other waiters coalesce again.
                    replacement = threading.Event()
                    _ANALYST_IN_FLIGHT[cache_key] = replacement
                    in_flight = replacement
                else:
                    retry_wait = existing_retry
            if retry_wait is not None:
                retry_wait.wait(timeout=240.0)
                return self.ask(
                    question=question,
                    semantic_view=semantic_view,
                    semantic_model_yaml=semantic_model_yaml,
                    semantic_views=semantic_views,
                )

        try:
            response = None
            for attempt in range(2):
                try:
                    response = _shared_http_client(self._base_url).post(
                        f"{self._base_url}{self._ENDPOINT}",
                        headers=self._build_headers(),
                        json=payload,
                        timeout=240.0,
                    )
                except httpx.HTTPError as exc:
                    if attempt == 0:
                        time.sleep(0.5)
                        continue
                    raise SnowflakeAgentError(
                        f"HTTP error communicating with Cortex Analyst: {exc}"
                    ) from exc
                if response.status_code == 429 or response.status_code >= 500:
                    if attempt == 0:
                        time.sleep(0.5)
                        continue
                break

            if response is None:  # pragma: no cover - defensive
                raise SnowflakeAgentError("Cortex Analyst returned no response.")

            if response.status_code != 200:
                message = (
                    f"Cortex Analyst returned HTTP {response.status_code}: {response.text}"
                )
                # A caller/contract error will not improve when a coalesced
                # waiter repeats it. Share it briefly with all waiters. A
                # transient status already received its single bounded retry.
                failure_ttl = 30.0 if response.status_code < 500 and response.status_code != 429 else 1.0
                with _ANALYST_CACHE_LOCK:
                    _ANALYST_FAILURES[cache_key] = (
                        time.monotonic() + failure_ttl,
                        message,
                    )
                raise SnowflakeAgentError(message)

            try:
                data = response.json()
            except json.JSONDecodeError as exc:
                raise SnowflakeAgentError(
                    f"Cortex Analyst response is not valid JSON: {exc}"
                ) from exc

            parsed = self._parse_response(data)
            with _ANALYST_CACHE_LOCK:
                if len(_ANALYST_CACHE) >= _ANALYST_CACHE_MAX_ENTRIES:
                    oldest_key = min(_ANALYST_CACHE, key=lambda key: _ANALYST_CACHE[key][0])
                    _ANALYST_CACHE.pop(oldest_key, None)
                parsed.response_metadata = {**parsed.response_metadata, "cache_source": "fresh"}
                _ANALYST_FAILURES.pop(cache_key, None)
                _ANALYST_CACHE[cache_key] = (
                    time.monotonic() + _ANALYST_CACHE_TTL_SECONDS,
                    parsed,
                )
            return parsed
        finally:
            with _ANALYST_CACHE_LOCK:
                completed = _ANALYST_IN_FLIGHT.pop(cache_key, None)
                if completed is not None:
                    completed.set()

    def stream_events(
        self,
        *,
        question: str,
        semantic_view: str | None = None,
        semantic_model_yaml: str | None = None,
        semantic_views: list[str] | None = None,
    ) -> Iterator[tuple[str, dict[str, Any]]]:
        """Yield the genuine Cortex Analyst SSE events without buffering."""
        payload = self._build_payload(
            question=question,
            semantic_view=semantic_view,
            semantic_model_yaml=semantic_model_yaml,
            semantic_views=semantic_views,
            stream=True,
        )
        headers = {**self._build_headers(), "Accept": "text/event-stream"}
        try:
            with _shared_http_client(self._base_url).stream(
                "POST",
                f"{self._base_url}{self._ENDPOINT}",
                headers=headers,
                json=payload,
                timeout=240.0,
            ) as response:
                if response.status_code != 200:
                    body = response.read().decode("utf-8", errors="replace")
                    raise SnowflakeAgentError(
                        f"Cortex Analyst returned HTTP {response.status_code}: {body}"
                    )
                event_name = "message"
                data_lines: list[str] = []
                for line in response.iter_lines():
                    if line == "":
                        if data_lines:
                            raw = "\n".join(data_lines)
                            try:
                                data = json.loads(raw)
                            except json.JSONDecodeError:
                                data = {"text": raw}
                            yield event_name, data
                        event_name = "message"
                        data_lines = []
                        continue
                    if line.startswith("event:"):
                        event_name = line[6:].strip()
                    elif line.startswith("data:"):
                        data_lines.append(line[5:].lstrip())
                if data_lines:
                    raw = "\n".join(data_lines)
                    try:
                        data = json.loads(raw)
                    except json.JSONDecodeError:
                        data = {"text": raw}
                    yield event_name, data
        except SnowflakeAgentError:
            raise
        except httpx.HTTPError as exc:
            raise SnowflakeAgentError(
                f"HTTP error communicating with Cortex Analyst: {exc}"
            ) from exc

    @staticmethod
    def _build_payload(
        *,
        question: str,
        semantic_view: str | None,
        semantic_model_yaml: str | None,
        semantic_views: list[str] | None,
        stream: bool,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": question}],
                }
            ],
            "stream": stream,
        }
        if semantic_views:
            payload["semantic_models"] = [{"semantic_view": value} for value in semantic_views]
        elif semantic_view:
            payload["semantic_view"] = semantic_view
        elif semantic_model_yaml:
            payload["semantic_model"] = semantic_model_yaml
        else:
            raise SnowflakeAgentError(
                "Cortex Analyst requests require a semantic_view, semantic_views, or semantic_model_yaml."
            )
        return payload

    def _build_headers(self) -> dict[str, str]:
        if self._auth_mode == "snowflake_token":
            return {
                "Authorization": f'Snowflake Token="{self._token}"',
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

        headers = {
            "Authorization": f"Bearer {self._token}",
            "X-Snowflake-Authorization-Token-Type": "OAUTH",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self._role:
            headers["X-Snowflake-Role"] = self._role
        if self._warehouse:
            headers["X-Snowflake-Warehouse"] = self._warehouse
        return headers

    @staticmethod
    def _parse_response(data: dict[str, Any]) -> SnowflakeAnalystResponse:
        message = data.get("message") if isinstance(data.get("message"), dict) else {}
        content = message.get("content") if isinstance(message.get("content"), list) else []

        text_blocks: list[str] = []
        suggestions: list[str] = []
        sql_statement: str | None = None
        verified_query_used: dict[str, Any] | None = None

        for block in content:
            if not isinstance(block, dict):
                continue
            block_type = block.get("type")
            if block_type == "text" and isinstance(block.get("text"), str):
                text_blocks.append(block["text"])
            elif block_type == "suggestions" and isinstance(block.get("suggestions"), list):
                suggestions.extend(str(item) for item in block["suggestions"] if item is not None)
            elif block_type == "sql":
                statement = block.get("statement")
                if isinstance(statement, str):
                    sql_statement = statement
                verified = block.get("verified_query_used")
                if isinstance(verified, dict):
                    verified_query_used = verified

        warnings = data.get("warnings") if isinstance(data.get("warnings"), list) else []
        response_metadata = (
            data.get("response_metadata")
            if isinstance(data.get("response_metadata"), dict)
            else {}
        )

        return SnowflakeAnalystResponse(
            request_id=data.get("request_id") if isinstance(data.get("request_id"), str) else None,
            text="\n".join(part for part in text_blocks if part).strip() or None,
            sql=sql_statement,
            suggestions=suggestions,
            warnings=warnings,
            response_metadata=response_metadata,
            raw_message=message,
            verified_query_used=verified_query_used,
        )
