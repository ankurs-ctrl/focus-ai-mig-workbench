const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const proxyReplay = process.argv.includes('--proxy-replay');
const test = proxyReplay ? () => {} : require('node:test').test;
const root = path.resolve(__dirname, '../src');
const parse = file => ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true);
const sliceFile = path.join(root, 'features/sttm/store/sttm-builder-slice.ts');
const slice = parse(sliceFile);
const compile = (source, context = {}) => {
  const loaded = new Module(sliceFile, module);
  loaded._compile(ts.transpileModule(`module.exports = context => { const {${Object.keys(context).join(',')}} = context; ${source} };`, {
    compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020},
  }).outputText, sliceFile);
  return loaded.exports(context);
};
const functions = (ast, names) => names.map(name => {
  const declaration = ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === name);
  assert.ok(declaration, name);
  return declaration.getText(ast).replace(/^export\s+/, '');
}).join('\n');
const helperNames = ['autoMapTargetBindingId', 'autoMapCompletionCounts', 'autoMapCompletionMessage', 'autoMapReviewIsApplicable', 'autoMapReviewFromRun', 'autoMapRetryPlan', 'autoMapTargetOutcomeCodes', 'autoMapReviewValueProofIsCurrent', 'autoMapRevisionHash', 'autoMapScope', 'autoMapHasDefinition', 'autoMapSourceInputs', 'autoMapSharedInputs', 'autoMapInputsMatch', 'autoMapReviewIsCurrent', 'autoMapValuesSignature', 'stablePreparedContextValue', 'compactPreparedContextHash', 'preparedWorkspaceSnapshot', 'normalizeTargetKey', 'targetKeyVariants', 'isStructuredSqlExpression', 'applyMappingSuggestion',
  'extractSemanticViewNameFromStatus', 'normalizeSemanticContextItems', 'applyAutoMapResponseToState',
  'autoMapRecord', 'autoMapCount', 'extractAutoMapPreservation', 'autoMapInputSignature', 'autoMapRowIsEdited',
  'restoreAutoMapStatus', 'isCurrentAutoMapRun', 'cloneMappingSnapshot',
  'parseEmbeddedAgentEnvelope', 'extractJsonObjectCandidate', 'looksLikeEmbeddedAgentEnvelope', 'extractWarningMessages',
  'resolveAgentResponseParts', 'getStructuredAgentResult', 'buildPendingAiMappingReviews', 'buildPendingAiMappingReviewRows',
  'extractAutoMappingReview', 'formatAutoMappingReview'];
const pureModules = new Map();
function loadPure(file) {
  if(pureModules.has(file))return pureModules.get(file).exports;
  const loaded=new Module(file,module);pureModules.set(file,loaded);
  loaded.require=request=>{
    if(request.startsWith('@/')||request.startsWith('.')){
      let target=request.startsWith('@/')?path.join(root,request.slice(2)):path.resolve(path.dirname(file),request);
      if(!path.extname(target))target+='.ts';
      return loadPure(target);
    }
    return require(request);
  };
  loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);
  return loaded.exports;
}
const sheetModule={exports:loadPure(path.join(root,'features/sttm/mapping/sheet-candidates.ts'))};
const reviewHelpers=loadPure(path.join(root,'features/sttm/mapping/mapping-review-model.ts'));
const reviewSummary=loadPure(path.join(root,'features/sttm/mapping/mapping-review-summary.ts'));
const selectionHelpers=loadPure(path.join(root,'features/sttm/shared/sttm-selection-utils.ts'));
const selectedSources=state=>selectionHelpers.resolveSelectedSourceTables({...state,sources:state.sources??[],sourceDatabases:state.sourceDatabases??[]});
const helpers = compile(`${functions(slice, helperNames)}; return {${helperNames.join(',')}};`, {
  ...sheetModule.exports, ...reviewHelpers, ...reviewSummary, ...loadPure(path.join(root,'features/sttm/shared/row-validation-state.ts')), ...loadPure(path.join(root,'features/sttm/shared/validation-context.ts')), resolveSelectedSourceTables:selectedSources,
  sha256: require('@noble/hashes/sha256').sha256,
  isValuePlaceholder: value => typeof value === 'string' && /^\$\w+$/.test(value),
});
Object.assign(helpers,reviewHelpers,reviewSummary,loadPure(path.join(root,'features/sttm/shared/row-validation-state.ts')),loadPure(path.join(root,'features/sttm/shared/validation-context.ts')),{resolveSelectedSourceTables:selectedSources});
const blank = (id = 'NAME') => ({id, targetColumn: id, targetType: 'VARCHAR', status: 'UNMAPPED',
  sourceColumn: null, expression: null, rule: 'Select...', mappingMode: 'source'});
const imported = () => {const row={...blank(), status: 'MAPPED', sourceColumn: 'src.Name', sourceColumns: ['src.Name'],
  expression: "COALESCE(src.Name, 'MiXeD ''literal''')", rule: 'Custom', sourceDependencies: ['D.S.SOURCE'],
  description: 'Imported rule', targetOrdinal: 3};row.validation=helpers.validatedRow(row,helpers.selectionValidationSignature({activeProjectId:'project',activeSttmId:'one'}));return row;};
const stateFor = (...rows) => {
 const state={mappings: rows, mappingSuggestions: [], pendingManualEditSnapshots: {},
  pendingAiMappingReviews: [], selectedMappingIds: [], targetAttributeGroup: {columns: rows.map(row => ({name: row.targetColumn}))}, autoMapProcessingIds: [], chatMessages: [],
  assistantUnreadCount: 0, errorState: {}, activeSttmId: 'one', activeProjectId: 'project'};
 return state;
};
const unresolved = {source_attributes: [], confidence_score: 0, transformation_classification: 'unresolved', unmatched_reason: 'Current output unavailable'};
const direct = {source_attributes: ['src.NewName'], confidence_score: 0.95, preprocessing_rule_type: 'Direct'};
const response = (proposal, extra = {}) => ({operation: 'sttm.auto_map', result: {mappings: {NAME: proposal}}, ...extra});

test('unresolved proposals preserve imported inputs exactly without certifying validity', () => {
  const original = imported();
  const state = stateFor({...original});
  helpers.applyAutoMapResponseToState(state, response(unresolved));
  const row = state.mappings[0];
  for (const field of ['expression', 'sourceColumn', 'sourceColumns', 'rule', 'sourceDependencies', 'description', 'targetOrdinal']) {
    assert.deepEqual(row[field], original[field], field);
  }
  assert.equal(row.status, 'MAPPED');
  assert.equal(row.unmatchedReason, unresolved.unmatched_reason);
  assert.equal(row.transformationClassification, 'unresolved');
  assert.equal(state.mappingSuggestions[0].unmatchedReason, unresolved.unmatched_reason);
  assert.deepEqual(state.selectedMappingIds, []);
  const first = structuredClone(state);
  helpers.applyAutoMapResponseToState(state, response(unresolved));
  assert.deepEqual(state, first, 'terminal replay must be idempotent');
});

test('bare MAPPED, missing constant values and invalid bindings are not protected as valid', () => {
  for (const row of [{...blank(), status: 'MAPPED'}, {...blank(), status: 'MAPPED', mappingMode: 'constant', constantValue: null},
    {...blank(), status: 'MAPPED', mappingMode: 'attribute', attributeName: 'MissingFirmValue', constantValue: null}]) {
    const state = stateFor(row);
    helpers.applyAutoMapResponseToState(state, response(unresolved));
    assert.equal(row.status, helpers.hasMappingDefinition(row) ? 'MAPPED' : 'UNMAPPED');
    assert.equal(row.expression, null);
  }
});

test('empty and malformed custom proposals cannot erase row inputs', () => {
  for (const proposal of [{}, {...direct, preprocessing_rule_type: 'Custom', preprocessing_rule: null},
    {mapping_mode: 'constant', constant_value: null}, {mapping_mode: 'attribute', attribute_name: null}]) {
    const row = imported();
    const expression = row.expression;
    helpers.applyAutoMapResponseToState(stateFor(row), response(proposal));
    assert.equal(row.expression, expression);
    assert.equal(row.sourceColumn, 'src.Name');
    assert.equal(row.status, helpers.hasMappingDefinition(row) ? 'MAPPED' : 'UNMAPPED');
  }
});

test('a successful response may repair an imported row; there is no blanket baseline lock', () => {
  const row = imported();
  helpers.applyAutoMapResponseToState(stateFor(row), response(direct));
  assert.equal(row.sourceColumn, 'src.NewName');
  assert.equal(row.status, 'MAPPED');
  assert.equal(row.expression, null);
});

test('partial unresolved followed by terminal success completes new rows', () => {
  const row = blank();
  const state = stateFor(row);
  helpers.applyAutoMapResponseToState(state, response(unresolved));
  helpers.applyAutoMapResponseToState(state, response(direct));
  assert.equal(row.status, 'MAPPED');
  assert.equal(row.transformationClassification, null);
  assert.equal(row.unmatchedReason, null);
  assert.equal(state.mappingSuggestions.length, 1);
});

test('manual flags and pending revisions win over partial, terminal and failed proposals', () => {
  for (const guard of ['manuallySaved', 'manuallyEditedAfterAutoMap', 'pending']) {
    for (const proposal of [direct, unresolved]) {
      const row = {...imported(), expression: "src.Name || 'USER MiXeD'"};
      const state = stateFor(row);
      if (guard === 'pending') state.pendingManualEditSnapshots.NAME = imported();
      else row[guard] = true;
      const before = structuredClone(row);
      helpers.applyAutoMapResponseToState(state, response(proposal));
      helpers.applyAutoMapResponseToState(state, response(proposal, {warnings: [{code: 'AUTO_MAPPING_BATCH_FAILED', field: 'NAME'}]}));
      assert.deepEqual(row, before);
      assert.equal(state.mappingSuggestions.length, 1, 'proposal remains reviewable');
    }
  }
});

test('in-flight manual revision is not overwritten by terminal replay', () => {
  const row = blank();
  const state = stateFor(row);
  helpers.applyAutoMapResponseToState(state, response(direct));
  state.pendingManualEditSnapshots.NAME = {...row};
  row.expression = "COALESCE(src.NewName, 'My revision')";
  row.rule = 'Custom';
  const edited = structuredClone(row);
  helpers.applyAutoMapResponseToState(state, response(direct));
  assert.deepEqual(row, edited);
});

test('infrastructure failure and precedent override retain mapped imported inputs', () => {
  for (const result of [response(unresolved, {warnings: [{code: 'AUTO_MAPPING_BATCH_FAILED', field: 'D.S.T.NAME'}]}),
    response({...direct, precedent_decision: 'override_precedent'})]) {
    const row = imported();
    const original = structuredClone(row);
    const state = stateFor(row);
    begin(state);
    helpers.applyAutoMapResponseToState(state, result);
    assert.deepEqual(row, original);
    if (!result.warnings) assert.equal(state.pendingAiMappingReviews[0].mappingId, 'NAME');
  }
});

test('empty string constant is a real value and SQL literals keep case and quoting', () => {
  const row = blank();
  const state = stateFor(row);
  helpers.applyAutoMapResponseToState(state, response({mapping_mode: 'constant', constant_value: ''}));
  assert.equal(row.status, 'MAPPED');
  assert.equal(row.constantValue, '');
  const expression = "COALESCE(src.Name, 'MiXeD ''literal''')";
  helpers.applyAutoMapResponseToState(state, response({...direct, preprocessing_rule_type: 'Custom', preprocessing_rule: expression}));
  assert.equal(row.expression, expression);
});

let startReducer, pendingReducer, appliedReducer, failedReducer, fulfilledReducer, rejectedReducer, updateReducer, thunkSource;
function visit(node) {
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice) === 'autoMapBatchStarted') startReducer = node.arguments[1].getText(slice);
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice) === 'runAutoMap.pending') pendingReducer = node.arguments[1].getText(slice);
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice) === 'autoMapBatchApplied') appliedReducer = node.arguments[1].getText(slice);
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice) === 'autoMapBatchFailed') failedReducer = node.arguments[1].getText(slice);
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice) === 'runAutoMap.fulfilled') fulfilledReducer = node.arguments[1].getText(slice);
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice) === 'runAutoMap.rejected') rejectedReducer = node.arguments[1].getText(slice);
  if (ts.isPropertyAssignment(node) && node.name.getText(slice) === 'updateMapping') updateReducer = node.initializer.getText(slice);
  if (ts.isVariableDeclaration(node) && node.name.getText(slice) === 'runAutoMap') thunkSource = node.initializer.arguments[1].getText(slice);
  ts.forEachChild(node, visit);
}
visit(slice);
const reducer = source => compile(`return (${source});`, {...helpers, createChatMessageId: () => 'result'});
const begin = (state, requestId = 'run-one') => reducer(pendingReducer)(state, {meta: {requestId, arg: {action: 'complete'}}});
const finish = (state, payload = {}, requestId = 'run-one') => reducer(fulfilledReducer)(state, {
  meta: {requestId}, payload: {failedTargets: [], autoMapOutcome: null, ...payload},
});
const preservationResponse = (proposal, {targets = ['NAME'], status = 'definition_preserved', values = [], partial = false} = {}) => response(proposal, {
  data: {status: values.length ? 'needs_input' : 'completed'},
  meta: {
    automap_preserved_targets: targets,
    automap_baseline_preservation: {version: 'v1', instruction: 'preserve_frontend_rows', apply_preserved_mappings: false,
      definition_source: 'context.workspace_context', preserve_mapping_sql: true, preserve_raw_mapping_sql: true},
    ...(!partial ? {automap_resolution: {mode: 'preserve_and_complete', execution_status: values.length ? 'blocked' : 'not_validated',
      targets: targets.map(target => ({target_attribute: target, status, unresolved_values: values,
        execution_status: values.length ? 'blocked' : 'not_validated'}))}} : {}),
  },
});

test('batch progress does not change a pending manual row or its selected IDs', () => {
  const state = stateFor({...blank(), manuallySaved: true}, {...blank('EDIT'), manuallyEditedAfterAutoMap: true}, blank('PENDING'), blank('NEW'));
  state.pendingManualEditSnapshots.PENDING = blank('PENDING');
  reducer(startReducer)(state, {payload: {processingIds: state.mappings.map(row => row.id), processedCount: 0, totalCount: 4}});
  assert.deepEqual(state.mappings.map(row => row.status), ['UNMAPPED', 'UNMAPPED', 'UNMAPPED', 'PROCESSING']);
  assert.deepEqual(state.selectedMappingIds, []);
});

test('completion displays authoritative merged review counts rather than batch prose', () => {
  const review = {headline: '2 mapped; 1 needs input', total_count: 3, mapped_count: 2, unresolved_count: 1,
    missing_derived_output_count: 0, recommendations: []};
  const reviewSummary = helpers.formatAutoMappingReview(helpers.extractAutoMappingReview({meta: {auto_mapping_review: review}}));
  assert.match(reviewSummary, /\*\*Mapped:\*\* 2 of 3/);
  assert.match(reviewSummary, /\*\*Still needs input:\*\* 1/);
  const state = stateFor(imported());
  begin(state);
  finish(state, {autoMappingReview: review, reviewSummary});
  assert.equal(state.autoMapStatusMessage, review.headline);
  assert.equal(state.chatMessages[0].content, reviewSummary);
  assert.equal(state.chatMessages[0].status, 'needs_input');
});

test('preserved reference scalars never rewrite literal SQL, functions, zero or false', () => {
  for (const expression of ["'NULL'", "''", 'CURRENT_TIMESTAMP()', '0', 'false', "  COALESCE(src.Name, 'MiXeD ''literal''')  "]) {
    for (const proposal of [unresolved, direct, {mapping_mode: 'constant', constant_value: expression},
      {...direct, preprocessing_rule_type: 'Custom', preprocessing_rule: "COALESCE(src.Rewritten, 'WRONG')"}]) {
      const original = {...imported(), expression};
      original.validation=helpers.validatedRow(original,helpers.selectionValidationSignature({activeProjectId:'project',activeSttmId:'one'}));
      const state = stateFor(structuredClone(original));
      state.mappingSql = "WITH src AS (SELECT 'MiXeD' AS Name)\r\nSELECT " + expression + ' AS NAME FROM src;';
      state.rawMappingSql = state.mappingSql;
      state.compiledMappingReady = false;
      state.sqlValidatedSignature = null;
      begin(state);
      assert.equal(state.autoMapRun.baseline.NAME.status, 'MAPPED');
      assert.equal(state.mappings[0].status, 'PROCESSING');
      const fullSql = state.mappingSql;
      const result = preservationResponse(proposal);
      helpers.applyAutoMapResponseToState(state, result);
      helpers.applyAutoMapResponseToState(state, result);
      finish(state);
      assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
      assert.equal(state.mappingSql, fullSql);
      assert.equal(state.rawMappingSql, fullSql);
      assert.equal(state.compiledMappingReady, false);
      assert.equal(state.sqlValidatedSignature, null);
      assert.equal(state.mappingSuggestions.length, 0, 'reference-only payload is not an applicable suggestion');
      assert.equal(state.pendingAiMappingReviews.length, 0);
    }
  }
});

test('preserved Values retain exact empty/zero/false bindings and unresolved custom definitions', () => {
  for (const constantValue of ['', '0', 'false', 0, false, null, '$AccountID']) {
    const original = {...imported(), mappingMode: 'attribute', attributeName: 'AccountID', constantValue,
      valueBindingIds: ['project:AccountID'], expression: '$AccountID', rule: 'Value'};
    original.validation=helpers.validatedRow(original,helpers.selectionValidationSignature({activeProjectId:'project',activeSttmId:'one'}));
    const state = stateFor(structuredClone(original));
    begin(state);
    helpers.applyAutoMapResponseToState(state, preservationResponse({
      ...direct, preprocessing_rule_type: 'Custom', preprocessing_rule: "COALESCE(src.Id, 'INVENTED')",
    }, {values: ['$AccountID']}));
    finish(state);
    assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
    assert.equal(state.mappingSuggestions.length, 0);
  }
});

test('unproven pending baseline is retained and replacement proposal requires explicit Apply', () => {
  for (const partial of [false, true]) {
    const original = {...imported(), validation:null, status: 'NEEDS_VALIDATION'};
    const state = stateFor(structuredClone(original));
    begin(state);
    const result = preservationResponse(direct, {status: 'pending', partial});
    result.meta.auto_mapping_review = {headline: 'Review the baseline proposal', recommendations: [{
      category: 'baseline_proposal', target_attribute: 'NAME', severity: 'action_required',
    }]};
    helpers.applyAutoMapResponseToState(state, result);
    helpers.applyAutoMapResponseToState(state, result);
    finish(state);
    assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
    assert.equal(state.pendingAiMappingReviews.length, 1);
    assert.equal(state.pendingAiMappingReviews[0].mappingId, original.id);
    assert.deepEqual(state.pendingAiMappingReviews[0].sourceAttributes, ['src.NewName']);
    assert.equal(state.mappingSuggestions.length, 1);
  }
});

test('unproven missing proposals and preserved partial references do not certify pending rows', () => {
  for (const options of [{status: 'pending'}, {status: 'definition_preserved'}, {partial: true}]) {
    const original = {...imported(), validation:null, status: 'NEEDS_VALIDATION'};
    const state = stateFor(structuredClone(original));
    begin(state);
    helpers.applyAutoMapResponseToState(state, preservationResponse(unresolved, options));
    finish(state);
    assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
    assert.equal(state.pendingAiMappingReviews.length, 0);
  }
});

test('server-pending proposals cannot downgrade an unchanged validated baseline', () => {
  const original = imported();
  const state = stateFor(structuredClone(original));
  begin(state);
  helpers.applyAutoMapResponseToState(state, preservationResponse(direct, {status: 'pending'}));
  finish(state);
  assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
  assert.equal(state.pendingAiMappingReviews.length, 1);
});

test('terminal diagnostics correct legacy diagnostic-free partials only inside the unchanged run fence', () => {
  for (const guard of ['unchanged', 'manual', 'edit', 'applied', 'other-run', 'other-workspace', 'finished']) {
    const original = {...imported(), validation:null, expression: 'src.MISSING', sourceColumn: 'src.MISSING', sourceColumns: ['src.MISSING']};
    const state = stateFor(structuredClone(original));
    begin(state);
    const apply = result => reducer(appliedReducer)(state, {payload: {requestId: 'run-one', response: result,
      completedMappingIds: ['NAME'], processedCount: 1, totalCount: 1}});
    apply(preservationResponse(unresolved, {partial: true}));
    if (guard === 'manual') state.mappings[0].manuallySaved = true;
    if (guard === 'edit') reducer(updateReducer)(state, {payload: {id: 'NAME', updates: {expression: 'src.USER_EDIT'}, options: {skipDirtyTracking: true}}});
    if (guard === 'applied') apply(response(direct));
    if (guard === 'other-run') state.autoMapRun.requestId = 'run-two';
    if (guard === 'other-workspace') state.activeSttmId = 'two';
    if (guard === 'finished') finish(state);
    const beforeTerminal = structuredClone(state.mappings[0]);
    apply(preservationResponse(unresolved, {status: 'pending'}));
    apply(preservationResponse(unresolved, {status: 'pending'}));
    if (guard === 'unchanged') {
      assert.equal(state.mappings[0].status, 'MAPPED');
      finish(state);
      assert.deepEqual(state.mappings[0], {...original, status: 'MAPPED'});
    } else assert.deepEqual(state.mappings[0], beforeTerminal, guard);
  }
});

test('partial and terminal baseline proposals never replace explicit empty, numeric zero or boolean false Values', () => {
  for (const constantValue of ['', 0, false, '0', 'false']) {
    const original = {...blank(), status:'NEEDS_VALIDATION', mappingMode: 'constant', rule: 'VALUE', constantValue};
    const state = stateFor(structuredClone(original));
    begin(state);
    for (const result of [preservationResponse(direct, {status: 'pending'}), preservationResponse(direct, {status: 'pending'})]) {
      reducer(appliedReducer)(state, {payload: {requestId: 'run-one', response: result,
        completedMappingIds: ['NAME'], processedCount: 1, totalCount: 1}});
    }
    finish(state);
    assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
    assert.equal(state.pendingAiMappingReviews.length, 1);
  }
});

test('Redux draft baseline snapshots survive processing transitions without aliasing', () => {
  const {produce} = require('immer');
  const original = imported();
  const started = produce(stateFor(original), draft => begin(draft));
  assert.equal(started.autoMapRun.baseline.NAME.status, 'MAPPED');
  const applied = produce(started, draft => helpers.applyAutoMapResponseToState(draft, preservationResponse(unresolved)));
  const completed = produce(applied, draft => finish(draft));
  assert.deepEqual(completed.mappings[0], original);
  assert.equal(completed.autoMapRun, null);
});

test('only listed targets are preserved regardless of checked selection, and new mappings still apply', () => {
  const original = imported();
  const state = stateFor(structuredClone(original), blank('NEW'));
  state.selectedMappingIds = ['NEW'];
  begin(state);
  const result = preservationResponse(unresolved, {targets: ['D.T.TARGET.NAME']});
  result.result.mappings.NEW = direct;
  helpers.applyAutoMapResponseToState(state, result);
  finish(state);
  assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
  assert.equal(state.mappings[1].status, 'MAPPED');
  assert.deepEqual(state.selectedMappingIds, ['NEW']);
  assert.deepEqual(state.mappingSuggestions.map(item => item.targetAttribute), ['NEW']);
});

test('preservation is not inferred from request metadata, mode, malformed fields or non-Auto-map operations', () => {
  const canonical = preservationResponse(direct);
  for (const result of [response(direct, {context: {meta: canonical.meta}}),
    response(direct, {meta: {auto_map_resolution_mode: 'preserve_and_complete'}}),
    {...canonical, operation: 'sttm.transform'},
    {...canonical, meta: {...canonical.meta, automap_preserved_targets: [false]}},
    {...canonical, meta: {...canonical.meta, automap_baseline_preservation: {instruction: 'preserve_frontend_rows', apply_preserved_mappings: 'false'}}},
    ...[null, false, [], 'invalid'].map(meta => response(direct, {meta}))]) {
    const state = stateFor(imported());
    begin(state);
    helpers.applyAutoMapResponseToState(state, result);
    assert.equal(state.mappings[0].sourceColumn, 'src.NewName');
  }
});

test('client reevaluation hints cannot override preservation but server-excluded targets can be replaced', () => {
  const state = stateFor(imported());
  const original = structuredClone(state.mappings[0]);
  begin(state);
  state.auto_map_resolution_mode = 'reeval_all';
  const result = preservationResponse(direct);
  result.context = {meta: {auto_map_resolution_mode: 'reeval_all'}};
  helpers.applyAutoMapResponseToState(state, result);
  assert.deepEqual(state.mappings[0], {...original,status:'MAPPED'});
  result.meta.automap_preserved_targets = [];
  result.meta.automap_resolution.mode = 'reeval_selected';
  helpers.applyAutoMapResponseToState(state, result);
  assert.equal(state.mappings[0].sourceColumn, 'src.NewName');
});

test('unsaved meaningful edits through the real update reducer fence partial and terminal responses', () => {
  for (const updates of [{expression: "src.Name || 'USER'"}, {constantValue: ''}, {sourceDependencies: ['changed']},
    {sourceColumns: ['changed']}, {valueBindingIds: ['changed']}, {rule: 'UPPER'}, {attributeName: 'Changed'}]) {
    const state = stateFor(imported());
    begin(state);
    reducer(updateReducer)(state, {payload: {id: 'NAME', updates, options: {skipDirtyTracking: true}}});
    const edited = structuredClone(state.mappings[0]);
    helpers.applyAutoMapResponseToState(state, response(direct));
    helpers.applyAutoMapResponseToState(state, preservationResponse(unresolved));
    finish(state);
    assert.deepEqual(state.mappings[0], {...edited,status:'MAPPED'});
  }
});

test('equivalent arrays and status bookkeeping are not mistaken for meaningful input revisions', () => {
  const state = stateFor(imported());
  begin(state);
  reducer(updateReducer)(state, {payload: {id: 'NAME', updates: {sourceColumns: ['src.Name'], status: 'UNMAPPED'}, options: {skipDirtyTracking: true}}});
  helpers.applyAutoMapResponseToState(state, response(unresolved));
  helpers.applyAutoMapResponseToState(state, response(direct));
  assert.equal(state.mappings[0].sourceColumn, 'src.NewName');
  assert.equal(state.mappings[0].status, 'MAPPED');
});

test('partial then terminal cannot overwrite a new unsaved edit after a successful proposal', () => {
  const state = stateFor(blank());
  begin(state);
  helpers.applyAutoMapResponseToState(state, response(direct));
  reducer(updateReducer)(state, {payload: {id: 'NAME', updates: {expression: "'edited after partial'"}, options: {skipDirtyTracking: true}}});
  const edited = structuredClone(state.mappings[0]);
  helpers.applyAutoMapResponseToState(state, response(direct));
  finish(state);
  assert.deepEqual(state.mappings[0], {...edited,status:'MAPPED'});
});

test('completion, batch failure and rejection restore only unchanged processing rows', () => {
  for (const end of ['finish', 'batch failure', 'rejection']) {
    const state = stateFor(imported(), blank('NEW'), {...blank('MANUAL'), manuallySaved: true});
    const originals = structuredClone(state.mappings);
    begin(state);
    assert.deepEqual(state.mappings.map(row => row.status), ['PROCESSING', 'PROCESSING', 'UNMAPPED']);
    if (end === 'finish') finish(state);
    else if (end === 'batch failure') reducer(failedReducer)(state, {payload: {completedMappingIds: ['NAME', 'NEW'], totalCount: 2, processedCount: 2}});
    else reducer(rejectedReducer)(state, {meta: {requestId: 'run-one'}, payload: 'failed'});
    assert.deepEqual(state.mappings, originals);
  }
});

test('stale requests and changed workspaces cannot restore or apply old rows', () => {
  const state = stateFor(imported());
  begin(state);
  const before = structuredClone(state);
  reducer(appliedReducer)(state, {payload: {requestId: 'old', response: response(direct), completedMappingIds: ['NAME']}});
  finish(state, {}, 'old');
  reducer(rejectedReducer)(state, {meta: {requestId: 'old'}, payload: 'failed'});
  assert.deepEqual(state, before);
  state.activeSttmId = 'different';
  const otherWorkspace = structuredClone(state);
  finish(state);
  assert.deepEqual(state, otherWorkspace);
});

test('summary distinguishes preserved, new, proposed and Value-blocked counts and rejects malformed optional counts', () => {
  const result = preservationResponse(unresolved, {values: ['$AccountID']});
  result.meta.auto_mapping_review = {headline: 'Definitions retained, execution blocked', total_count: 5, mapped_count: 1,
    preserved_count: 3, newly_mapped_count: 1, baseline_retained_count: 4, proposed_count: 2,
    execution_blocked_count: 1, unresolved_values_count: 1, unresolved_count: 2, recommendations: []};
  const review = helpers.extractAutoMappingReview(result);
  const summary = helpers.formatAutoMappingReview(review);
  for (const text of ['**Definitions preserved:** 3', '**Newly mapped:** 1 of 5', '**Replacement proposals (not applied):** 1',
    '**Unresolved Values:** 1', '**Targets blocked by unbound Values:** 1', 'Preservation is not execution approval.']) assert.ok(summary.includes(text), text);
  assert.ok(!summary.includes('**Mapped:**'));
  for (const invalid of ['3', -1, null, false, [], {}, Infinity, 0.5]) {
    result.meta.auto_mapping_review.preserved_count = invalid;
    assert.equal(helpers.extractAutoMappingReview(result).preserved_count, undefined);
  }
  result.meta.auto_mapping_review.preserved_count = 0;
  assert.equal(helpers.extractAutoMappingReview(result).preserved_count, 0);
  delete result.meta.auto_mapping_review.unresolved_values_count;
  result.meta.automap_resolution.targets.push({target_attribute: 'OTHER', unresolved_values: ['$AccountID', '$OwnerID']});
  assert.equal(helpers.extractAutoMappingReview(result).unresolved_values_count, 2, 'count distinct Values, not target references');
  result.meta.automap_resolution.targets[0].unresolved_values = 'malformed';
  assert.equal(helpers.extractAutoMappingReview(result).unresolved_values_count, undefined, 'do not invent zero for malformed diagnostics');
});

// Use the real thunk, adapter, snapshot row projection and reducer functions;
// only external service/context preparation is replaced. No noble/browser needed.
const service = parse(path.join(root, 'services/workbenchService.ts'));
const api = parse(path.join(root, 'api/axiosInstance.ts'));
const buildApiEnvelope = compile(`${functions(api, ['buildApiEnvelope'])}; return buildApiEnvelope;`, {
  API_CONTRACT_VERSION: 'test', createRequestId: () => 'request-id',
});
const toEnvelope = compile(`${functions(service, ['nullableNonEmptyArray', 'toEnvelope'])}; return toEnvelope;`, {
  buildApiEnvelope, operationByIntent: {AUTO_MAP: 'sttm.auto_map', CHAT: 'sttm.chat'},
});
const snapshot = parse(path.join(root, 'features/sttm/context/workbench-context.ts'));
let rowProjection, checkedProjection;
function visitProjection(node) {
  if (ts.isPropertyAssignment(node) && node.name.getText(snapshot) === 'mapping_rows') rowProjection = node.initializer.getText(snapshot);
  if (ts.isPropertyAssignment(node) && node.name.getText(snapshot) === 'checked_mapping_row_ids') checkedProjection = node.initializer.getText(snapshot);
  ts.forEachChild(node, visitProjection);
}
visitProjection(snapshot);
const snapshotFromState = compile(`${functions(slice, ['snapshotFromState'])}; return snapshotFromState;`, {
  resolveSelectedSourceTables: state => state.sources,
  resolveSelectedTargetTable: state => state.targets[0],
  buildWorkbenchContextSnapshot: input => compile(`return {mapping_rows: ${rowProjection}, checked_mapping_row_ids: ${checkedProjection}};`, {input,...helpers}),
});

test('durable and compatibility requests carry mode, full inventory and selected workspace rows', async () => {
  for (const compatibility of [false, true]) {
    const state = {...stateFor({...imported(), manuallySaved: true}, blank('NEW')), sources: [{tableId:'D.S.SOURCE',tableName:'SOURCE',qualifiedName: 'D.S.SOURCE'}],
      targets: [{qualifiedName: 'D.T.TARGET'}], derivedSources: [], sourceAttributeGroups: [{columns: [{name: 'Name'}]}],
      targetAttributeGroup: {qualifiedName: 'D.T.TARGET', columns: [{name: 'NAME'}, {name: 'NEW'}, {name: 'EXTRA'}]},
      semanticBundleId: 'bundle', semanticContextItems: [{}], relationships: [], activeSttmId: 'one', activeProjectId: 'project'};
    const requests = [];
    state.semanticDependencySignature = helpers.autoMapSourceInputs(state);
    begin(state);
    const actionCreator = type => payload => ({type, payload});
    const resultResponse = preservationResponse(unresolved);
    resultResponse.result.mappings.NEW = direct;
    const thunk = compile(`return (${thunkSource});`, {
      ...helpers,
      resolveSelectedSourceTables: current => current.sources,
      resolveSelectedTargetTable: current => current.targets[0],
      makeTableRef: qualified => {const [database, schema, table] = qualified.split('.'); return {database, schema, table};},
      estimateAutoMapComplexity: () => 0,
      autoMapBatchesInitialized: actionCreator('initialized'), autoMapStreamStatus: actionCreator('status'),
      autoMapSemanticPrepared: actionCreator('semantic-prepared'), autoMapBatchStarted: actionCreator('started'), autoMapBatchApplied: actionCreator('applied'),
      getSelectedDerivedSourceIds: () => [], listProjectAttributes: async () => [], snapshotFromState,
      preparedWorkspaceSnapshot: () => ({dependencyHash: 'snapshot-hash'}),
      preparedContextService: {prepare: async () => ({workspace_context_id:'prepared', workspace_context_hash:'hash', status:'ready'})},
      applyPreparedWorkspaceContext: actionCreator('prepared-context'),
      findTargetDescription: () => null, qualifiedTableRefOrNull: () => null, buildRelationshipPayload: () => [],
      buildRelationGraph: () => ({}), buildSelectedColumnsByTable: () => ({}),
      getErrorMessage: error => error.message,
      workbenchService: {
        startAutoMapJob: async request => { requests.push(toEnvelope(request)); if (compatibility) throw new Error('404 not found');
          return {status: 'completed', partial_responses: [], response: resultResponse}; },
        invokeStream: async function* (request) {requests.push(toEnvelope(request)); yield {event: 'final', data: resultResponse};},
      },
    });
    const result = await thunk({action: 'complete'}, {requestId: 'run-one', getState: () => ({sttmBuilder: state}), dispatch: action => {
      if (action.type === 'started') reducer(startReducer)(state, action);
      if (action.type === 'applied') reducer(appliedReducer)(state, action);
    }, rejectWithValue: message => {throw new Error(message);}});
    finish(state, result);
    assert.equal(result.totalCount, 3);
    assert.equal(requests.length, compatibility ? 2 : 1);
    for (const envelope of requests) {
      assert.equal(envelope.meta.auto_map_resolution_mode, 'preserve_and_complete');
      assert.deepEqual(envelope.data.attributes.map(item => item.target_attribute), ['NAME', 'NEW', 'EXTRA']);
      assert.deepEqual(envelope.context.workspace_context.checked_mapping_row_ids, []);
      assert.equal(envelope.context.workspace_context.mapping_rows.length, 2);
      assert.equal(envelope.context.workspace_context.mapping_rows[0].expression, imported().expression);
      assert.equal(envelope.context.workspace_context.mapping_rows[0].manually_saved, true);
      assert.equal(envelope.context.workspace_context.mapping_rows[1].status, 'UNMAPPED', 'backend receives original status, not PROCESSING');
    }
    assert.deepEqual(state.selectedMappingIds, []);
    assert.deepEqual(state.mappings[0], {...imported(), manuallySaved: true});
    assert.equal(state.mappings[1].status, 'MAPPED');
    assert.equal(state.autoMapOutcome.resolution.execution_status, 'not_validated');
  }
  assert.deepEqual(toEnvelope({interface: 'CHAT'}).meta, {}, 'do not enable Auto-map policy on chat requests');
});

// Pytest sends actual proxy progress and terminal envelopes, never reconstructed
// metadata. Keep this runner in the existing harness so both use the same reducers.
if (proxyReplay) {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  const state = stateFor(...input.rows);
  begin(state);
  const trace = [];
  for (const result of [...input.partials, input.terminal]) {
    reducer(appliedReducer)(state, {payload: {requestId: 'run-one', response: result,
      completedMappingIds: state.mappings.map(row => row.id), processedCount: state.mappings.length,
      totalCount: state.mappings.length}});
    trace.push(structuredClone(state.mappings));
  }
  finish(state, {autoMappingReview: input.terminal.meta.auto_mapping_review});
  process.stdout.write(JSON.stringify({trace, rows: state.mappings, reviews: state.pendingAiMappingReviews,
    suggestions: state.mappingSuggestions}));
}
module.exports = {helpers, loadPure, compile, slice, functions, reducer, pendingReducer, fulfilledReducer, rejectedReducer,
  appliedReducer, startReducer, blank, imported, stateFor, response, direct, unresolved, thunkSource};
