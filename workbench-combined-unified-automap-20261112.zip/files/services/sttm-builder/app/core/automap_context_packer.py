"""Deterministic evidence packing. Identifiers, descriptions and Values are atomic."""
from copy import deepcopy
from app.core.automap_json import encoded


class ContextBudgetError(ValueError):
    def __init__(self, message, packet=None):
        super().__init__(message)
        self.packet = packet


def pack_context(packet, *, max_bytes=80_000, measure=None, trim_precedent_sql=False):
    result = deepcopy(packet)
    trimmed = []
    measure = measure or (lambda value: len(encoded(value).encode('utf-8')))

    def fits():
        result['context_manifest'] = {'trimmed_sections': trimmed.copy(), 'budget_bytes': max_bytes}
        # Measurement includes the manifest itself and caller's wire framing.
        return measure(result) <= max_bytes

    if not fits():
        for key in ('compact_index', 'archived_source_inventory'):
            if result.get('context', {}).pop(key, None) is not None:
                trimmed.append(key)
                if key == 'archived_source_inventory':
                    result.get('context', {}).pop('inventory_instruction', None)
    from app.core.automap_evidence_blocks import EvidenceReference
    from app.core.automap_policy import negative_evidence
    protected_sections = {'business_rules', 'filters', 'filter_rules', 'relationship_rules',
                          'mandatory_evidence', 'mandatory_negative_evidence', 'correction_history',
                          'relation_graph', 'source_graph'}

    def protected(value):
        provenance = value.get('provenance') or {}
        return (isinstance(value.get('category'), str) and value['category'] in protected_sections
                or value.get('kind') in ('source_graph', 'mandatory_evidence')
                or value.get('mandatory') is True
                # The recursive policy classifies one mapping, not its ancestor
                # receipt/learning containers; optional siblings remain trimmable.
                or negative_evidence({key: value.get(key) for key in (
                    'correction_id', 'incorrect_source', 'incorrect_rule', 'prevention_hint',
                    'negative_conditions', 'contradictions', 'contradiction_count')})
                or isinstance(value.get('mapping_recipe'), dict) and negative_evidence(value['mapping_recipe'])
                or isinstance(provenance, dict) and provenance.get('evidence_class') == 'explicit_user_correction')

    if not fits():
        samples_removed = False
        def remove_samples(value):
            nonlocal samples_removed
            if isinstance(value, EvidenceReference):
                return
            if isinstance(value, dict):
                if protected(value):
                    return
                if "sample_values" in value:
                    value.pop("sample_values")
                    samples_removed = True
                for key, child in value.items():
                    if key not in protected_sections:
                        remove_samples(child)
            elif isinstance(value, list):
                for child in value:
                    remove_samples(child)
        remove_samples(result)
        if samples_removed:
            trimmed.append('sample_values')
    # Candidate admission is reduced by its owner (15 -> 10 -> 6) before this
    # last stage. Current CTE SQL, joins, filters, descriptions and Values are atomic.
    if not fits() and trim_precedent_sql:
        changed = False
        def trim_bodies(value):
            nonlocal changed
            if isinstance(value, EvidenceReference):
                return
            if isinstance(value, dict):
                if protected(value):
                    return
                if isinstance(value.get('mapping_recipe'), dict):
                    deferred_here = False
                    for key in ('derived_dependencies', 'required_ctes'):
                        def defer(dependency):
                            nonlocal deferred_here
                            if isinstance(dependency, EvidenceReference):
                                return
                            if isinstance(dependency, dict):
                                if protected(dependency):
                                    return
                                for name, child in list(dependency.items()):
                                    if name in protected_sections:
                                        continue
                                    if name in {'sql_text', 'cte_sql', 'sql_body'} and isinstance(child, str):
                                        dependency.pop(name)
                                        dependency['sql_body_deferred_to_transformation'] = True
                                        deferred_here = True
                                    else:
                                        defer(child)
                            elif isinstance(dependency, list):
                                for child in dependency:
                                    defer(child)
                        defer(value.get(key))
                    if deferred_here:
                        changed = True
                        value['precedent_sql_scope'] = 'expression_only; full bodies retained for transformation'
                for key, child in value.items():
                    if key not in protected_sections:
                        trim_bodies(child)
            elif isinstance(value, list):
                for child in value:
                    trim_bodies(child)
        trim_bodies(result)
        if changed:
            trimmed.append('precedent_sql_bodies')
    if not fits():
        result['context_manifest']['mandatory_over_soft_budget'] = True
        raise ContextBudgetError('Mandatory semantic evidence exceeds the batch allowance', result)
    result['context_manifest']['section_bytes'] = {
        key: len(encoded(value).encode('utf-8')) for key, value in result.items() if key != 'context_manifest'}
    if measure(result) > max_bytes:
        result['context_manifest'].pop('section_bytes')
    return result


def cte_card(node):
    outputs = node.get('output_columns') or []
    names = {str(item.get('name') or '').upper() for item in outputs}
    card = {key: deepcopy(node[key]) for key in ('relation_id', 'alias', 'purpose', 'description', 'output_columns', 'grain', 'keys') if key in node}
    card['column_semantics'] = [deepcopy(item) for item in node.get('column_semantics') or []
                                if str(item.get('name') or item.get('column_name') or '').upper() in names]
    return card


def shared_capsule(context):
    from app.core.semantic_evidence import missing_semantic_assets
    missing = missing_semantic_assets(context)
    graph = context.get('relation_graph') or {}
    workspace = context.get('workspace_context') or {}
    intent = context.get('mapping_intent') or {}
    learning = context.get('learning_context') or {}
    execution = context.get('execution_context') or {}
    target = context.get('target_table') or {}
    target_fqn = '.'.join(str(target.get(key) or '') for key in ('database', 'schema', 'table')).upper()
    recommendations = execution.get('exact_fir_recommendations') or learning.get('fir_recommendations') or learning.get('recommendations') or []
    recommendations = [item for item in recommendations if not item.get('target_table') or str(item.get('target_table')).upper() == target_fqn]
    from app.core.automap_semantic_catalog import table_business_description
    target_description = ''
    for record in context.get('semantic_context') or []:
        owner = record.get('table') or {}
        owner_fqn = '.'.join(str(owner.get(key) or record.get({'schema': 'schema_name', 'table': 'table_name'}.get(key, key)) or '')
                             for key in ('database', 'schema', 'table')).upper()
        if owner_fqn == target_fqn:
            target_description = table_business_description(record)
            break
    return {'semantic_evidence_coverage': {'missing_assets': missing, 'status': 'partial' if missing else 'available'},
            'business_context': {key: deepcopy(workspace[key]) for key in (
                'project_description', 'sttm_description', 'business_goal', 'description', 'project', 'sttm') if key in workspace},
            'source_system_key': intent.get('source_system_key'),
            'target_table_description': target_description, 'mapping_intent': deepcopy(intent),
            'cte_catalog': [cte_card(node) for node in graph.get('nodes') or [] if node.get('kind') in {'CTE', 'DERIVED_SOURCE'}],
            'join_graph': deepcopy(graph.get('edges') or []),
            'values': [{'record_id': 'val:' + str(item.get('value')), **{key: deepcopy(item[key]) for key in (
                'binding_id', 'value', 'description', 'data_type') if key in item},
                'resolved': item.get('resolved_value') is not None}
                       for item in graph.get('value_bindings') or []],
            'table_recommendations': deepcopy(recommendations[:3])}
