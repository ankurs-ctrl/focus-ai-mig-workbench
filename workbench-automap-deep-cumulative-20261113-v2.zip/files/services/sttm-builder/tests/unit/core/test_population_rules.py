from app.migration_workflow.population_rules import (
    merge_predicates,
    mentions_column,
    precedent_population,
    soft_delete_predicate,
)


def test_soft_delete_predicate_by_flag_type():
    assert soft_delete_predicate("contacts", {"columns": [{"name": "DELETED", "type": "NUMBER(38,0)"}]}) == (
        "COALESCE(contacts.DELETED, 0) = 0")
    assert soft_delete_predicate("c", {"columns": [{"name": "IS_DELETED", "type": "BOOLEAN"}]}) == (
        "COALESCE(c.IS_DELETED, FALSE) = FALSE")
    assert "NOT IN ('1', 'Y'" in soft_delete_predicate("c", {"columns": [{"name": "DELETED", "type": "VARCHAR"}]})
    assert soft_delete_predicate("c", {"columns": [{"name": "ID", "type": "NUMBER"}]}) is None


def test_merge_predicates_keeps_existing_and_skips_repeats():
    assert merge_predicates(None, ["a = 1"]) == "a = 1"
    assert merge_predicates("x = 1 OR y = 2", ["c.DELETED = 0"]) == "(x = 1 OR y = 2) AND c.DELETED = 0"
    assert merge_predicates("c.DELETED = 0", ["c.deleted  =  0"]) == "c.DELETED = 0"
    assert mentions_column("contacts.deleted = 0", "DELETED")
    assert not mentions_column("contacts.undeleted_at IS NULL", "DELETED")


def test_precedent_population_lists_where_and_qualify_by_cte():
    sql = """WITH SOURCE AS (SELECT c.id FROM DB.S.CONTACTS c
               WHERE c.deleted = 0 AND c.type = 'Individual' QUALIFY ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY c.id) = 1)
             SELECT * FROM SOURCE WHERE id IS NOT NULL"""
    rules = precedent_population(sql)
    assert {"scope": "SOURCE", "kind": "where", "sql": "c.deleted = 0 AND c.type = 'Individual'"} in rules
    assert any(rule["kind"] == "qualify" for rule in rules)
    assert {"scope": "final query", "kind": "where", "sql": "NOT id IS NULL"} in rules
    assert precedent_population("not sql at all ((") == []
