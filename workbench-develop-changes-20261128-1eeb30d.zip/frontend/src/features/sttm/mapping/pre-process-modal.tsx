'use client';
import { AiaAccordion, AiaAccordionDetails, AiaAccordionSummary, AiaBox, AiaButton, AiaCheckbox, AiaChip, AiaDialog, AiaDialogActions, AiaDialogContent, AiaDialogTitle, AiaIconButton, AiaInput, AiaSelect, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { DeleteOutlinedIcon, EditOutlinedIcon, ExpandMoreIcon, KeyIcon, LinkIcon, StorageRoundedIcon } from '@/utils/icons';

import {
  SqlEditor,
  SQL_COMPLETION_KEYWORDS,
  SQL_EDITOR_PANEL_MIN_HEIGHT,
  SQL_FUNCTION_COMPLETIONS,
  mergeSqlCompletionCandidates,
  type SqlInsertOptions,
} from '@/components/sql';
import { AiaSearchbox } from '@/components/ui/aia-searchbox';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { useAiChatLayout } from '@/features/ai-agent/ai-chat-layout-context';
import { useTour } from '@/features/tour/engine/tour-context';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import type { ColumnGroup, DerivedSource } from '@/features/sttm/types/sttm.types';
import { withPreservedAutoMapConfidence } from './mapping-confidence-groups';
import { useProjectAttributes } from './use-project-attributes';
import { useProjectCustomRules } from './use-project-custom-rules';
import { parseAppError } from '@/api/errors/app-error';
import { libraryRuleForSave, matchingLibraryRule, missingLibraryColumns, removeDottedColumnTokens } from './custom-rule-library';
import { followFirmValueInSql, followFirmValueNames, firmValueLiteral, firmValueLiteralPattern, firmValueNamesInExpression, firmValuePlaceholder, firmValuePlaceholderPattern, sqlUsesFirmValuePlaceholder } from './firm-value-literal';
import { liveFirmValueEditNotes, readFirmValueEdits } from './project-attribute-utils';
import { authService } from '@/services/authService';
import {
  deleteProjectCustomRule,
  listProjects,
  renameProjectCustomRule,
  saveProjectCustomRule,
  type ProjectAttributeRecord,
  type ProjectCustomRuleRecord,
  type ProjectRecord,
} from '@/services/projectService';
import { AiaResizeHandle } from '@/components/ui/aia-resize-handle';
import { SttmSidebarCollapseFooter } from '@/features/sttm/layout/sttm-sidebar-collapse-footer';
import { SttmSidebarCollapsedRail } from '@/features/sttm/layout/sttm-sidebar-collapsed-rail';
import { ResizableSidebarSections } from '@/features/sttm/layout/resizable-sidebar-sections';
import { SttmSidebarSectionIcon } from '@/features/sttm/layout/sttm-sidebar-icons';
import {
  formatSqlType,
  generateMappingDescription,
  getDerivedDisplayColumns,
  derivedColumnReference,
  parseSourceColumns,
} from './mapping-utils';
import { sqlIdentifierParts } from '@/features/sttm/shared/sql-identifiers';
import { relationAliasFor } from './relation-alias';
import {
  sttmSidebarBodyTextSx,
  sttmSidebarColumnTypeSx,
  sttmSidebarSearchboxSx,
  sttmSidebarSearchInputSx,
  sttmSidebarSecondaryTextSx,
} from '@/features/sttm/layout/sttm-sidebar-text-styles';
import { textStyleCssVars } from '@/config/typography-tokens';

const modalCloseButtonSx = {
  minWidth: 28,
  width: 28,
  height: 28,
  p: 0,
  fontSize: 14,
  lineHeight: 1,
  boxShadow: 'none',
  color: 'var(--aia-button-color)',
  '&:hover': {
    bgcolor: 'transparent',
    color: 'var(--aia-button-hover-color)',
  },
} as const;

const modalPrimaryButtonColors = {
  customBackgroundColor: 'var(--aia-primary-bg-color)',
  customColor: 'var(--aia-primary-bg-text-color)',
  customBorderColor: 'var(--aia-primary-bg-color)',
  customHoverBackgroundColor: 'var(--aia-primary-bg-hover-color)',
} as const;

const singleLineNameSx = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
} as const;

function tableAlias(tableName: string) {
  return tableName.toLowerCase();
}

function schemaCategory(qualifiedName: string) {
  const schema = qualifiedName.split('.')[1] ?? qualifiedName;
  return schema.split('_')[0] || schema;
}

type PreProcessColumnGroup = ColumnGroup & {
  matchNames?: string[];
  derivedSource?: DerivedSource;
};

const CTE_SECTION_LABEL = 'CTE Sources';

// Each sidebar section's search bar stays pinned at the top while its list scrolls.
const STICKY_SEARCH_SX = {
  position: 'sticky',
  top: 0,
  zIndex: 1,
  flexShrink: 0,
  backgroundColor: 'var(--color-surface)',
} as const;

const sectionCategorySx = {
  px: 1,
  py: 0.5,
  ...sttmSidebarSecondaryTextSx,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
} as const;

function filterColumnGroups<T extends ColumnGroup>(groups: T[], search: string): T[] {
  const query = search.trim().toLowerCase();
  if (!query) return groups;
  return groups
    .map((group) => ({
      ...group,
      columns: group.columns.filter(
        (col) =>
          col.name?.toLowerCase().includes(query) ||
          group.table.toLowerCase().includes(query),
      ),
    }))
    .filter((group) => group.columns.length > 0);
}

function derivedColumnsForPicker(source: DerivedSource) {
  const displayColumns = getDerivedDisplayColumns(source);
  if (displayColumns.length) return displayColumns;
  // Fall back to the CTE's selected columns so a CTE is never listed without columns
  // just because its output/preview columns were not loaded.
  const seen = new Set<string>();
  return Object.values(source.selectedColumnsByTable ?? {})
    .flat()
    .map((name) => String(name ?? '').trim())
    .filter((name) => {
      const key = name.toUpperCase();
      if (!name || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .map((name) => ({ name, type: '—' }));
}

// Every CTE selected in Select Tables (CTE Sources) is listed, even when its columns are
// unavailable, so it is never silently missing from the picker.
function buildDerivedColumnGroups(derivedSources: DerivedSource[]): PreProcessColumnGroup[] {
  return derivedSources
    .filter((source) => source.isSelected)
    .map((source) => {
      const normalize = (value: string | null | undefined) =>
        String(value ?? '').trim().replace(/\s+/g, '_');
      const alias = relationAliasFor(source.id, source.sourceName);
      return {
        table: alias,
        derivedSource: source,
        qualifiedName: `CTE.CTE.${alias}`,
        columns: derivedColumnsForPicker(source),
        matchNames: [
          normalize(source.sourceName),
          normalize(source.id),
          normalize(source.physicalViewName?.split('.').pop()),
          relationAliasFor(source.id, source.sourceName),
        ].filter(Boolean),
      };
    });
}

function sourceColumnMatches(item: string, group: PreProcessColumnGroup, columnName: string) {
  const parts = sqlIdentifierParts(item);
  const expected = group.derivedSource ? sqlIdentifierParts(derivedColumnReference(group.derivedSource, columnName)).at(-1)
    : columnName.toUpperCase();
  if (parts.length < 2 || parts[parts.length - 1] !== expected) return false;
  const qualifier = JSON.stringify(parts.slice(0, -1));
  return [group.table, ...(group.matchNames ?? [])].some(
    name => JSON.stringify(sqlIdentifierParts(name)) === qualifier,
  );
}

function columnReference(group: PreProcessColumnGroup, columnName: string) {
  return group.derivedSource
    ? derivedColumnReference(group.derivedSource, columnName)
    : `${tableAlias(group.table)}.${columnName}`;
}

function columnsUsedInExpression(expression: string, groups: PreProcessColumnGroup[]) {
  const tokens = expression.match(/[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+/g) ?? [];
  const found: string[] = [];
  for (const group of groups) {
    for (const column of group.columns) {
      const name = String(column.name ?? '');
      if (!name || !tokens.some((token) => sourceColumnMatches(token, group, name))) continue;
      if (!found.some((item) => sourceColumnMatches(item, group, name))) {
        found.push(columnReference(group, name));
      }
    }
  }
  return found;
}

const DEFAULT_SOURCE_SIDEBAR_WIDTH = 340;
const MIN_SOURCE_SIDEBAR_WIDTH = 248;
const COLLAPSED_SOURCE_SIDEBAR_WIDTH = 70;
const FOOTER_ROW_HEIGHT = 76;
// Dragging can widen the source sidebar up to half of the window.
const MAX_SOURCE_SIDEBAR_VIEWPORT_RATIO = 0.5;

function groupBySchema<T extends ColumnGroup>(groups: T[]) {
  const map = new Map<string, T[]>();
  for (const group of groups) {
    const key = schemaCategory(group.qualifiedName);
    const bucket = map.get(key) ?? [];
    bucket.push(group);
    map.set(key, bucket);
  }
  return Array.from(map.entries());
}

function looksLikeSqlExpression(value?: string | null) {
  const trimmed = value?.trim();
  if (!trimmed) return false;

  const upper = trimmed.toUpperCase();
  if (
    [
      'DIRECT',
      'UPPER',
      'LOWER',
      'TRIM',
      'CAST',
      'COALESCE',
      'DATE_FORMAT',
      'SUBSTRING',
      'REPLACE',
      'NULLIF',
      'CONCATENATE',
    ].includes(upper)
  ) {
    return false;
  }

  return /[().\s,]/.test(trimmed);
}

export default function PreProcessModal() {
  const {
    isPreProcessModalOpen,
    setPreProcessModalOpen,
    activeMappingId,
    mappings,
    updateMapping,
    sourceAttributeGroups: physicalSourceGroups,
    derivedSources,
    relationships,
    refreshAssistantSignals,
    activeProjectId,
    activeProjectName,
    activeSttmId,
  } = useSttmBuilderContext();
  const { projectAttributes: firmValues, isLoadingProjectAttributes } = useProjectAttributes(activeProjectId);
  const {
    rules: libraryRules,
    isLoading: libraryRulesLoading,
    error: libraryRulesError,
    reload: reloadLibraryRules,
  } = useProjectCustomRules(isPreProcessModalOpen ? activeProjectId : null);
  const {
    isOpen: isAssistantOpen,
    effectiveSidebarWidth,
    isMobile,
    isTablet,
  } = useAiChatLayout();
  const { registerModalTour, startTour } = useTour();

  const [expression, setExpression] = useState('');
  const insertAtCursorRef = useRef<((text: string, options?: SqlInsertOptions) => void) | null>(null);
  const [sourceSearch, setSourceSearch] = useState('');
  const [cteSearch, setCteSearch] = useState('');
  const [firmSearch, setFirmSearch] = useState('');
  const [chosenFirmValueNames, setChosenFirmValueNames] = useState<string[] | null>(null);
  const [ruleSearch, setRuleSearch] = useState('');
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [selectedLibraryRuleId, setSelectedLibraryRuleId] = useState<string | null>(null);
  const [saveStartedFromLibrary, setSaveStartedFromLibrary] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [saveDescription, setSaveDescription] = useState('');
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveConflictName, setSaveConflictName] = useState<string | null>(null);
  const [savingRule, setSavingRule] = useState(false);
  const [libraryNotice, setLibraryNotice] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [libraryProjectId, setLibraryProjectId] = useState('');
  const selectedLibraryProjectId = libraryProjectId || activeProjectId || '';
  const viewingCurrentLibrary = !selectedLibraryProjectId || selectedLibraryProjectId === activeProjectId;
  const {
    rules: otherProjectRules,
    isLoading: otherProjectRulesLoading,
    error: otherProjectRulesError,
  } = useProjectCustomRules(
    isPreProcessModalOpen && !viewingCurrentLibrary ? selectedLibraryProjectId : null,
  );
  const [copyProjects, setCopyProjects] = useState<ProjectRecord[]>([]);
  const [renameTarget, setRenameTarget] = useState<ProjectCustomRuleRecord | null>(null);
  const [renameName, setRenameName] = useState('');
  const [renameExpression, setRenameExpression] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);
  const [renamingRule, setRenamingRule] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ProjectCustomRuleRecord | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deletingRule, setDeletingRule] = useState(false);
  const [expandedTables, setExpandedTables] = useState<Record<string, boolean>>({});
  // Collapsing keeps the dragged width, so expanding reopens the sidebar at the same size.
  const [sourceSidebarCollapsed, setSourceSidebarCollapsed] = useState(false);
  const [sourceSidebarWidth, setSourceSidebarWidth] = useState(DEFAULT_SOURCE_SIDEBAR_WIDTH);
  const sourceSidebarResizeRef = useRef<{ startX: number; startWidth: number } | null>(null);

  useEffect(() => {
    const handlePointerMove = (event: MouseEvent) => {
      const state = sourceSidebarResizeRef.current;
      if (!state) {
        return;
      }
      const maxWidth = Math.max(
        MIN_SOURCE_SIDEBAR_WIDTH,
        Math.floor(window.innerWidth * MAX_SOURCE_SIDEBAR_VIEWPORT_RATIO),
      );
      setSourceSidebarWidth(
        Math.min(maxWidth, Math.max(MIN_SOURCE_SIDEBAR_WIDTH, state.startWidth + event.clientX - state.startX)),
      );
    };
    const handlePointerUp = () => {
      sourceSidebarResizeRef.current = null;
    };
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
    };
  }, []);

  const activeMapping = mappings.find((m) => m.id === activeMappingId);
  const joinCount = relationships.length;

  const physicalColumnGroups = useMemo<PreProcessColumnGroup[]>(
    () =>
      // Saved mappings (auto-map, relation graph, compiler) qualify columns with the
      // identity alias, e.g. `customer_20231101_ab12cd.ID`; accept it so they pre-tick.
      physicalSourceGroups.map((group) => ({
        ...group,
        matchNames: [relationAliasFor(group.qualifiedName)],
      })),
    [physicalSourceGroups],
  );

  const derivedColumnGroups = useMemo(
    () => buildDerivedColumnGroups(derivedSources),
    [derivedSources],
  );

  const sourceAttributeGroups = useMemo<PreProcessColumnGroup[]>(
    () => [...physicalColumnGroups, ...derivedColumnGroups],
    [physicalColumnGroups, derivedColumnGroups],
  );
  const selectedColumns = useMemo(
    () => columnsUsedInExpression(expression, sourceAttributeGroups),
    [expression, sourceAttributeGroups],
  );

  useEffect(() => {
    if (!isPreProcessModalOpen) return;
    let live = true;
    void authService.getSession().then((session) => {
      if (live) setIsAdmin(session.app_persona === 'ADMIN');
    }).catch(() => {
      if (live) setIsAdmin(false);
    });
    void listProjects().then((projects) => {
      if (live) setCopyProjects(projects);
    }).catch(() => {
      if (live) setCopyProjects([]);
    });
    return () => {
      live = false;
    };
  }, [isPreProcessModalOpen]);

  // Prefill from the saved mapping once per open (or when switching rows). Keying on the
  // mapping object instead would re-run on every `mappings` update and overwrite edits.
  const prefillKey = isPreProcessModalOpen ? activeMappingId : null;
  const [prefilledKey, setPrefilledKey] = useState<string | null>(null);
  if (prefillKey !== prefilledKey) {
    setPrefilledKey(prefillKey);
    if (prefillKey && activeMapping) {
      const initialColumns =
        activeMapping.sourceColumns && activeMapping.sourceColumns.length
          ? activeMapping.sourceColumns
          : parseSourceColumns(activeMapping.sourceColumn);
      const suggestedExpression =
        !activeMapping.expression && looksLikeSqlExpression(activeMapping.aiSuggestedRule)
          ? activeMapping.aiSuggestedRule?.trim() ?? ''
          : '';
      setExpression(activeMapping.expression || suggestedExpression || initialColumns.join(', '));
      setChosenFirmValueNames(activeMapping.selectedFirmValueNames ?? null);
    } else {
      setExpression('');
      setChosenFirmValueNames(null);
    }
    setLibraryProjectId(activeProjectId ?? '');
    setSourceSearch('');
    setCteSearch('');
    setFirmSearch('');
    setRuleSearch('');
    setSelectedLibraryRuleId(null);
    setSaveDialogOpen(false);
    setLibraryNotice(null);
  }

  useEffect(() => {
    if (!isPreProcessModalOpen) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setExpandedTables(
      Object.fromEntries(
        sourceAttributeGroups.map((group) => [group.qualifiedName, true]),
      ),
    );
  }, [isPreProcessModalOpen, sourceAttributeGroups]);

  useEffect(() => {
    if (!isPreProcessModalOpen || !activeProjectId) return;
    const notes = liveFirmValueEditNotes(readFirmValueEdits(activeProjectId), firmValues);
    if (!notes.length) return;
    setChosenFirmValueNames((prev) => {
      let names = prev;
      for (const note of notes) {
        names = followFirmValueNames(names, note.previousName, note.nextName) ?? names;
      }
      return names;
    });
    setExpression((prev) => {
      let next = prev;
      for (const note of notes) {
        next = followFirmValueInSql(next, note, chosenFirmValueNames) ?? next;
      }
      return next;
    });
  }, [activeProjectId, firmValues, isPreProcessModalOpen]);

  useEffect(() => {
    if (!isPreProcessModalOpen) {
      registerModalTour(null);
      return;
    }
    registerModalTour('sttm-preprocess');
    return () => registerModalTour(null);
  }, [isPreProcessModalOpen, registerModalTour]);

  const handleClose = () => {
    setSaveDialogOpen(false);
    setPreProcessModalOpen(false);
  };

  const openSaveDialog = () => {
    if (!expression.trim() || !activeProjectId) return;
    const source = libraryRuleForSave(libraryRules, expression, selectedLibraryRuleId);
    setSaveStartedFromLibrary(Boolean(source));
    setSaveName(source?.rule_name ?? '');
    setSaveDescription(source?.description?.trim() ?? '');
    setSaveError(null);
    setSaveConflictName(null);
    setSaveDialogOpen(true);
  };

  const submitLibraryRule = async (onConflict: 'ask' | 'overwrite') => {
    if (!activeProjectId) return;
    const name = (onConflict === 'overwrite' ? saveConflictName ?? saveName : saveName).trim();
    if (!name) {
      setSaveError('Enter a rule name.');
      return;
    }
    setSavingRule(true);
    setSaveError(null);
    try {
      const saved = await saveProjectCustomRule(activeProjectId, {
        rule_name: name,
        description: saveDescription.trim() || null,
        expression: expression.trim(),
        origin_sttm_id: activeSttmId,
        on_conflict: onConflict,
      });
      await reloadLibraryRules();
      setSaveDialogOpen(false);
      setLibraryNotice(
        saved.reused ? `Already saved as ${saved.rule_name}.` : `Saved ${saved.rule_name}.`,
      );
    } catch (error) {
      const parsed = parseAppError(error);
      if (parsed.payload.code === 'CUSTOM_RULE_NAME_CONFLICT' || parsed.payload.statusCode === 409) {
        const existing = parsed.payload.details?.find((item) => item.field === 'existing_rule_name')?.message;
        setSaveConflictName(existing || name);
        setSaveError(
          parsed.payload.message
            || `A rule named ${existing || name} already exists. Type a different name, or overwrite it.`,
        );
        return;
      }
      setSaveConflictName(null);
      setSaveError(parsed.payload.message || 'The rule could not be saved.');
    } finally {
      setSavingRule(false);
    }
  };

  const submitRename = async () => {
    if (!activeProjectId || !renameTarget) return;
    const name = renameName.trim();
    const sql = renameExpression.trim();
    if (!name) {
      setRenameError('Enter a rule name.');
      return;
    }
    if (!sql) {
      setRenameError('Enter the SQL for this rule.');
      return;
    }
    setRenamingRule(true);
    setRenameError(null);
    try {
      const renamed = await renameProjectCustomRule(activeProjectId, renameTarget.rule_id, {
        rule_name: name,
        expression: sql,
      });
      await reloadLibraryRules();
      if (selectedLibraryRuleId === renameTarget.rule_id) setExpression(renamed.expression);
      setRenameTarget(null);
      setLibraryNotice(`Saved ${renamed.rule_name}.`);
    } catch (error) {
      setRenameError(parseAppError(error).payload.message || 'The rule could not be renamed.');
    } finally {
      setRenamingRule(false);
    }
  };

  const submitDelete = async () => {
    if (!activeProjectId || !deleteTarget) return;
    setDeletingRule(true);
    setDeleteError(null);
    try {
      await deleteProjectCustomRule(activeProjectId, deleteTarget.rule_id);
      if (selectedLibraryRuleId === deleteTarget.rule_id) setSelectedLibraryRuleId(null);
      await reloadLibraryRules();
      setLibraryNotice(`Deleted ${deleteTarget.rule_name}.`);
      setDeleteTarget(null);
    } catch (error) {
      setDeleteError(parseAppError(error).payload.message || 'The rule could not be deleted.');
    } finally {
      setDeletingRule(false);
    }
  };

  const copyOtherProjectRule = (rule: ProjectCustomRuleRecord) => {
    setSelectedLibraryRuleId(null);
    setChosenFirmValueNames(null);
    setExpression(rule.expression);
    setSaveStartedFromLibrary(false);
    setSaveName(rule.rule_name);
    setSaveDescription(rule.description?.trim() ?? '');
    setSaveError(null);
    setSaveConflictName(null);
    setSaveDialogOpen(true);
  };

  const handleApply = () => {
    if (!activeMappingId) return;
    const trimmedExpression = expression.trim();
    const targetColumn = activeMapping?.targetColumn ?? '';
    const nextRule = trimmedExpression ? 'Custom' : (activeMapping?.rule || 'Direct');
    const description = generateMappingDescription({
      rule: nextRule,
      sourceColumns: selectedColumns,
      targetColumn,
      expression: trimmedExpression,
    });

    const hasContent = trimmedExpression || selectedColumns.length > 0;
    const matchedLibraryRule = matchingLibraryRule(libraryRules, trimmedExpression);
    const libraryNote = matchedLibraryRule
      ? {
          libraryRuleId: matchedLibraryRule.rule_id,
          libraryRuleName: matchedLibraryRule.rule_name,
          libraryRuleVersion: matchedLibraryRule.version,
        }
      : !libraryRulesLoading && !libraryRulesError
        ? { libraryRuleId: null, libraryRuleName: null, libraryRuleVersion: null }
        : {};

    const updates = {
      expression: trimmedExpression || null,
      selectedFirmValueNames: chosenFirmValueNames,
      // The NL Rule column mirrors the SQL Preview at the time the rule is applied.
      nlRule: trimmedExpression || null,
      sourceColumns: selectedColumns,
      sourceColumn: selectedColumns.join(', ') || null,
      mappingMode: 'source' as const,
      constantValue: null,
      attributeName: null,
      rule: nextRule,
      status: (hasContent ? 'MAPPED' : 'UNMAPPED') as 'MAPPED' | 'UNMAPPED',
      ...libraryNote,
      ...(activeMapping?.descriptionEdited ? {} : { description }),
    };

    updateMapping(
      activeMappingId,
      activeMapping
        ? withPreservedAutoMapConfidence(activeMapping, updates)
        : updates,
    );
    window.setTimeout(() => refreshAssistantSignals('on_transformation_review'), 0);
    handleClose();
  };

  const insertText = (text: string, options?: SqlInsertOptions) => {
    const insertAtCursor = insertAtCursorRef.current;
    if (insertAtCursor) {
      insertAtCursor(text, {
        wrapExisting: options?.wrapExisting,
        separateTokens: false,
        replaceColumnReference: options?.replaceColumnReference,
      });
      return;
    }
    if (options?.wrapExisting && text.includes('()')) {
      setExpression((prev) => (prev ? text.replace('()', `(${prev})`) : text));
    } else {
      setExpression((prev) => prev + (prev && !prev.endsWith(' ') ? ' ' : '') + text);
    }
  };

  const insertColumnReference = (group: PreProcessColumnGroup, columnName: string) => {
    insertText(columnReference(group, columnName), { replaceColumnReference: true });
  };

  // The name inserts another copy, including when the column is already in the SQL.
  // The checkbox only tracks presence: checking inserts the first copy, unchecking
  // removes every copy of that table's column.
  const toggleColumnSelection = (
    group: PreProcessColumnGroup,
    columnName: string,
    checked?: boolean,
  ) => {
    const isCurrentlySelected = isColumnSelected(group, columnName);
    const shouldSelect = checked !== undefined ? checked : !isCurrentlySelected;
    if (shouldSelect) {
      if (!isCurrentlySelected) insertColumnReference(group, columnName);
      return;
    }
    setExpression((prev) =>
      removeDottedColumnTokens(prev, (token) => sourceColumnMatches(token, group, columnName)),
    );
  };

  const selectedCteCount = selectedColumns.filter((item) =>
    derivedColumnGroups.some((group) =>
      group.columns.some((col) => sourceColumnMatches(item, group, col.name ?? '')),
    ),
  ).length;
  const selectedSourceCount = selectedColumns.length - selectedCteCount;
  const selectionSummary = `${selectedSourceCount} ${selectedSourceCount === 1 ? 'column' : 'columns'}, ${selectedCteCount} CTE selected`;

  const isColumnSelected = (group: PreProcessColumnGroup, columnName: string) =>
    selectedColumns.some((item) => sourceColumnMatches(item, group, columnName));

  const isFirmValueSelected = (attribute: ProjectAttributeRecord) =>
    sqlUsesFirmValuePlaceholder(expression, attribute.attribute_name);

  const toggleFirmValue = (attribute: ProjectAttributeRecord, checked?: boolean) => {
    const literal = firmValueLiteral(attribute.attribute_value, attribute.attribute_type);
    const name = attribute.attribute_name.trim();
    const placeholder = firmValuePlaceholder(name);
    const shouldSelect = checked !== undefined ? checked : !isFirmValueSelected(attribute);
    const base = chosenFirmValueNames ?? firmValueNamesInExpression(expression, firmValues);
    const next = shouldSelect
      ? base.some((item) => item.trim().toUpperCase() === name.toUpperCase())
        ? base
        : [...base, name]
      : base.filter((item) => item.trim().toUpperCase() !== name.toUpperCase());
    setChosenFirmValueNames(next);
    if (shouldSelect) {
      if (sqlUsesFirmValuePlaceholder(expression, name)) return;
      if (firmValueLiteralPattern(literal).test(expression)) {
        setExpression((prev) =>
          prev.replace(firmValueLiteralPattern(literal, 'g'), `$1${placeholder}`),
        );
        return;
      }
      insertText(placeholder);
      return;
    }
    setExpression((prev) =>
      prev
        .replace(firmValuePlaceholderPattern(name, 'gi'), '$1')
        .replace(/\s{2,}/g, ' ')
        .trim(),
    );
  };

  const filteredFirmValues = useMemo(() => {
    const query = firmSearch.trim().toLowerCase();
    const list = !query
      ? firmValues
      : firmValues.filter(
          (attribute) =>
            attribute.attribute_name.toLowerCase().includes(query)
            || String(attribute.attribute_value ?? '').toLowerCase().includes(query),
        );
    const selected: typeof list = [];
    const rest: typeof list = [];
    for (const attribute of list) {
      if (sqlUsesFirmValuePlaceholder(expression, attribute.attribute_name)) selected.push(attribute);
      else rest.push(attribute);
    }
    return [...selected, ...rest];
  }, [expression, firmSearch, firmValues]);

  const filteredSourceSchemas = useMemo(
    () => groupBySchema(filterColumnGroups(physicalColumnGroups, sourceSearch)),
    [physicalColumnGroups, sourceSearch],
  );

  const filteredCteGroups = useMemo(
    () => filterColumnGroups(derivedColumnGroups, cteSearch),
    [derivedColumnGroups, cteSearch],
  );

  const libraryProjectOptions = useMemo(() => {
    const current = copyProjects.find((project) => project.project_id === activeProjectId);
    const currentName = current?.project_name || activeProjectName || 'This project';
    const others = copyProjects
      .filter((project) => project.project_id !== activeProjectId)
      .map((project) => ({ value: project.project_id, label: project.project_name || project.project_id }))
      .sort((left, right) => left.label.localeCompare(right.label));
    return [
      ...(activeProjectId
        ? [{ value: activeProjectId, label: currentName }]
        : []),
      ...others,
    ];
  }, [activeProjectId, activeProjectName, copyProjects]);
  const projectLibraryRules = viewingCurrentLibrary ? libraryRules : otherProjectRules;
  const filteredLibraryRules = useMemo(() => {
    const query = ruleSearch.trim().toLowerCase();
    if (!query) return projectLibraryRules;
    return projectLibraryRules.filter((rule) =>
      rule.rule_name.toLowerCase().includes(query)
      || rule.expression.toLowerCase().includes(query),
    );
  }, [projectLibraryRules, ruleSearch]);

  const availableColumnRefs = useMemo(
    () => sourceAttributeGroups.flatMap((group) =>
      group.columns.flatMap((column) => {
        const columnName = column.name;
        if (!columnName) return [];
        return [group.derivedSource
          ? derivedColumnReference(group.derivedSource, columnName)
          : `${tableAlias(group.table)}.${columnName}`];
      }),
    ),
    [sourceAttributeGroups],
  );
  const missingRuleColumns = missingLibraryColumns(expression, availableColumnRefs);
  const loadedLibraryRule = matchingLibraryRule(libraryRules, expression);
  const typedRuleName = saveName.trim();
  const overwriteRuleName = typedRuleName
    ? libraryRules.find((rule) => rule.rule_name.trim().toUpperCase() === typedRuleName.toUpperCase())?.rule_name
      ?? (saveConflictName && saveConflictName.trim().toUpperCase() === typedRuleName.toUpperCase()
        ? saveConflictName
        : null)
    : null;

  const renderSectionSearch = (
    value: string,
    onChange: (value: string) => void,
    placeholder: string,
    extraSx?: Record<string, unknown>,
  ) => (
    <AiaBox sx={{ ...STICKY_SEARCH_SX, px: 1, pb: 1, ...extraSx }}>
      <AiaSearchbox
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        sx={sttmSidebarSearchboxSx}
        inputSx={sttmSidebarSearchInputSx}
      />
    </AiaBox>
  );

  const renderSectionEmpty = (message: string) => (
    <AiaText sx={{ px: 1, py: 0.5, ...sttmSidebarSecondaryTextSx, fontStyle: 'italic' }}>
      {message}
    </AiaText>
  );

  const renderColumnGroup = (group: PreProcessColumnGroup, isCte: boolean) => {
    const isExpanded = expandedTables[group.qualifiedName] ?? true;
    return (
      <AiaAccordion
        key={group.qualifiedName}
        expanded={isExpanded}
        onChange={(_, expanded) =>
          setExpandedTables((prev) => ({
            ...prev,
            [group.qualifiedName]: expanded,
          }))
        }
        disableGutters
        elevation={0}
        sx={{
          bgcolor: 'transparent',
          '&:before': { display: 'none' },
          boxShadow: 'none',
        }}
      >
        <AiaAccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ fontSize: 18, color: '#6b7280' }} />}
          sx={{
            minHeight: 34,
            px: 0.5,
            '& .MuiAccordionSummary-content': {
              my: 0.5,
              display: 'flex',
              alignItems: 'center',
              gap: 0.75,
              minWidth: 0,
            },
          }}
        >
          <StorageRoundedIcon sx={{ fontSize: 14, color: '#6b7280', flexShrink: 0 }} />
          <AiaText
            title={group.table}
            sx={{ ...sttmSidebarBodyTextSx, ...singleLineNameSx, fontWeight: 400 }}
          >
            {group.table}
          </AiaText>
        </AiaAccordionSummary>
        <AiaAccordionDetails sx={{ p: 0, pb: 0.5 }}>
          {group.columns.length === 0 && isCte ? (
            <AiaText sx={{ px: 1.25, py: 0.45, ...sttmSidebarSecondaryTextSx, fontStyle: 'italic' }}>
              No output columns available for this CTE.
            </AiaText>
          ) : null}
          {group.columns.map((col) => {
            const colName = col.name ?? '';
            const isSelected = isColumnSelected(group, colName);
            const typeLabel = (col.type ? formatSqlType(col.type) : '—').toLowerCase();

            return (
              <AiaBox
                key={`${group.qualifiedName}-${colName}`}
                onMouseDown={(event) => {
                  event.preventDefault();
                }}
                onClick={() => insertColumnReference(group, colName)}
                sx={{
                  px: 1.25,
                  py: 0.45,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 1,
                  cursor: 'pointer',
                  borderRadius: '6px',
                  '&:hover': { bgcolor: '#f3f4f6' },
                }}
              >
                <AiaBox
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 0.75,
                    minWidth: 0,
                    flex: 1,
                  }}
                >
                  <AiaCheckbox
                    checked={isSelected}
                    checkHandler={(checked) => toggleColumnSelection(group, colName, checked)}
                    uncheckedColor="var(--aia-primary-bg-color)"
                    checkedColor="var(--aia-primary-bg-color)"
                  />
                  <AiaBox
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 0.5,
                      flex: 1,
                      minWidth: 0,
                    }}
                  >
                    <AiaText
                      title={colName}
                      sx={{
                        ...sttmSidebarSecondaryTextSx,
                        ...singleLineNameSx,
                        color: 'var(--color-text)',
                      }}
                    >
                      {colName}
                    </AiaText>
                    {col.isPrimaryKey ? (
                      <KeyIcon sx={{ fontSize: 16, color: '#ca8a04', flexShrink: 0 }} />
                    ) : null}
                    {col.isForeignKey ? (
                      <LinkIcon sx={{ fontSize: 16, color: '#9ca3af', flexShrink: 0 }} />
                    ) : null}
                  </AiaBox>
                </AiaBox>
                <AiaText
                  sx={{
                    ...sttmSidebarColumnTypeSx,
                    display: 'block',
                    mt: 0,
                    flexShrink: 0,
                    textAlign: 'right',
                  }}
                >
                  {typeLabel}
                </AiaText>
              </AiaBox>
            );
          })}
        </AiaAccordionDetails>
      </AiaAccordion>
    );
  };

  const followLibrarySql = (sql: string) => {
    if (!activeProjectId) return sql;
    let next = sql;
    for (const note of liveFirmValueEditNotes(readFirmValueEdits(activeProjectId), firmValues)) {
      next = followFirmValueInSql(next, note) ?? next;
    }
    return next;
  };

  const renderLibraryRule = (rule: (typeof libraryRules)[number], copied = false) => {
    const isLoaded = !copied && (selectedLibraryRuleId ?? loadedLibraryRule?.rule_id) === rule.rule_id;
    const librarySql = followLibrarySql(rule.expression);
    return (
      <AiaBox
        key={rule.rule_id}
        onClick={() => {
          if (copied) {
            setSelectedLibraryRuleId(null);
            setChosenFirmValueNames(null);
            setExpression(librarySql);
            return;
          }
          setSelectedLibraryRuleId(rule.rule_id);
          setChosenFirmValueNames(null);
          setExpression(librarySql);
        }}
        sx={{
          px: 1.25,
          py: 0.6,
          cursor: 'pointer',
          borderRadius: '6px',
          bgcolor: isLoaded ? '#eef2ff' : 'transparent',
          '&:hover': { bgcolor: isLoaded ? '#eef2ff' : '#f3f4f6' },
        }}
      >
        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <AiaText
            title={rule.rule_name}
            sx={{ ...sttmSidebarSecondaryTextSx, ...singleLineNameSx, flex: 1, color: 'var(--color-text)' }}
          >
            {rule.rule_name}
          </AiaText>
          {copied ? (
            <AiaButton
              variant="text"
              size="small"
              onClick={(event) => {
                event.stopPropagation();
                copyOtherProjectRule(rule);
              }}
              sx={{ minWidth: 0, px: 0.75, fontSize: 12, textTransform: 'none' }}
            >
              Copy
            </AiaButton>
          ) : null}
          {!copied && isAdmin ? (
            <>
              <AiaTooltip title="Edit">
                <AiaIconButton
                  size="small"
                  aria-label={`Edit ${rule.rule_name}`}
                  onClick={(event) => {
                    event.stopPropagation();
                    setRenameTarget(rule);
                    setRenameName(rule.rule_name);
                    setRenameExpression(rule.expression);
                    setRenameError(null);
                  }}
                >
                  <EditOutlinedIcon sx={{ fontSize: 16 }} />
                </AiaIconButton>
              </AiaTooltip>
              <AiaTooltip title="Delete">
                <AiaIconButton
                  size="small"
                  aria-label={`Delete ${rule.rule_name}`}
                  onClick={(event) => {
                    event.stopPropagation();
                    setDeleteTarget(rule);
                    setDeleteError(null);
                  }}
                  sx={{ color: '#b91c1c' }}
                >
                  <DeleteOutlinedIcon sx={{ fontSize: 16 }} />
                </AiaIconButton>
              </AiaTooltip>
            </>
          ) : null}
        </AiaBox>
        <AiaText title={librarySql} sx={{ ...sttmSidebarColumnTypeSx, ...singleLineNameSx, display: 'block' }}>
          {librarySql}
        </AiaText>
      </AiaBox>
    );
  };

  const renderFirmValue = (attribute: ProjectAttributeRecord) => {
    const name = attribute.attribute_name;
    const value = String(attribute.attribute_value ?? '');
    const isSelected = isFirmValueSelected(attribute);
    return (
      <AiaBox
        key={attribute.attribute_id}
        onMouseDown={(event) => {
          event.preventDefault();
        }}
        onClick={() => toggleFirmValue(attribute)}
        sx={{
          px: 1.25,
          py: 0.6,
          display: 'flex',
          alignItems: 'flex-start',
          gap: 0.75,
          cursor: 'pointer',
          borderRadius: '6px',
          '&:hover': { bgcolor: '#f3f4f6' },
        }}
      >
        <AiaCheckbox
          checked={isSelected}
          checkHandler={(checked) => toggleFirmValue(attribute, checked)}
          uncheckedColor="var(--aia-primary-bg-color)"
          checkedColor="var(--aia-primary-bg-color)"
        />
        {/* Name on one line; the value wraps on the line below it. */}
        <AiaBox sx={{ minWidth: 0, flex: 1 }}>
          <AiaText
            title={name}
            sx={{
              ...sttmSidebarSecondaryTextSx,
              ...singleLineNameSx,
              color: 'var(--color-text)',
            }}
          >
            {name}
          </AiaText>
          <AiaText
            sx={{
              ...sttmSidebarColumnTypeSx,
              display: 'block',
              mt: 0.25,
              textTransform: 'none',
              whiteSpace: 'normal',
              overflowWrap: 'anywhere',
            }}
          >
            {value || '—'}
          </AiaText>
        </AiaBox>
      </AiaBox>
    );
  };

  const sqlCompletionCandidates = useMemo(() => {
    const identifiers = sourceAttributeGroups.flatMap((group) => {
      const alias = tableAlias(group.table);
      const columns = group.columns.flatMap((column) => {
        const name = String(column.name ?? '').trim();
        if (!name) return [];
        return alias ? [name, `${alias}.${name}`] : [name];
      });
      return [alias, group.table, group.qualifiedName, ...columns].filter(Boolean);
    });

    return mergeSqlCompletionCandidates(
      identifiers,
      SQL_FUNCTION_COMPLETIONS,
      SQL_COMPLETION_KEYWORDS,
    );
  }, [sourceAttributeGroups]);

  const joinSubtitle =
    joinCount > 0 ? `${joinCount} join${joinCount === 1 ? '' : 's'} from Step 1` : undefined;
  const assistantDockWidth =
    isAssistantOpen && !isMobile && !isTablet ? effectiveSidebarWidth : 0;

  return (
    <>
    <AiaDialog
      open={isPreProcessModalOpen}
      onClose={handleClose}
      maxWidth="xl"
      fullWidth
      sx={{
        right: `${assistantDockWidth}px`,
        transition: 'right 220ms ease',
        '& .MuiDialog-paper': {
          height: '90vh',
          maxWidth: assistantDockWidth
            ? `min(1536px, calc(100vw - ${assistantDockWidth + 48}px))`
            : undefined,
          borderRadius: '16px',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        },
      }}
    >
      <AiaBox sx={{ p: 3, borderBottom: '1px solid #f1f5f9' }}>
        <AiaBox sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
          <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1.5, minWidth: 0, flex: 1 }}>
            <AiaBox
              sx={{
                width: 36,
                height: 36,
                borderRadius: '50%',
                bgcolor: 'var(--color-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <StorageRoundedIcon sx={{ fontSize: 18, color: '#fff' }} />
            </AiaBox>
            <AiaBox sx={{ minWidth: 0 }}>
              <AiaText
                sx={{
                  ...textStyleCssVars('cardTitle'),
                  textTransform: 'capitalize',
                  letterSpacing: '-0.01em',
                }}
              >
                Pre-Processing Rule
              </AiaText>
              {activeMapping ? (
                <AiaBox sx={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 1.25, mt: 0.25 }}>
                  <AiaText sx={{ ...textStyleCssVars('secondaryText') }}>
                    Target:{' '}
                    <AiaBox component="span" sx={{ fontWeight: 700, color: "var(--aia-text-color)" }}>
                      {activeMapping.targetColumn}
                    </AiaBox>
                  </AiaText>
                  <AiaText sx={{ ...textStyleCssVars('secondaryText') }}>
                    Type:{' '}
                    <AiaBox component="span" sx={{ fontWeight: 600, color: '#374151' }}>
                      {formatSqlType(activeMapping.targetType)}
                    </AiaBox>
                  </AiaText>
                  {joinCount > 0 ? (
                    <AiaChip
                      size="small"
                      color="success"
                      label={`++ ${joinCount} join${joinCount === 1 ? '' : 's'} in FROM`}
                    />
                  ) : null}
                </AiaBox>
              ) : null}
            </AiaBox>
          </AiaBox>
          <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0 }}>
            <AiaButton
              variant="contained"
              size="small"
              onClick={() => startTour('sttm-preprocess')}
              aria-label="Start Pre-Processing Rule tour guide"
              sx={{
                textTransform: 'none',
                fontWeight: 700,
                fontSize: 13,
                borderRadius: '10px',
                px: 1.5,
                py: 0.6,
                minHeight: 34,
                backgroundColor: 'var(--aia-primary-bg-color)',
                color: 'var(--aia-primary-bg-text-color)',
                boxShadow: 'none',
                '&:hover': {
                  backgroundColor: 'var(--aia-primary-bg-hover-color)',
                },
              }}
            >
              Tour Guide
            </AiaButton>
            <AiaButton
              variant="text"
              size="small"
              onClick={handleClose}
              sx={modalCloseButtonSx}
              aria-label="Close"
            >
              ✕
            </AiaButton>
          </AiaBox>
        </AiaBox>
      </AiaBox>

      <AiaBox sx={{ display: 'flex', flex: 1, minHeight: 0 }}>
        <AiaBox
          data-tour={TOUR_TARGETS.preprocessSourceTables}
          sx={{
            width: sourceSidebarCollapsed ? COLLAPSED_SOURCE_SIDEBAR_WIDTH : sourceSidebarWidth,
            minWidth: sourceSidebarCollapsed ? COLLAPSED_SOURCE_SIDEBAR_WIDTH : MIN_SOURCE_SIDEBAR_WIDTH,
            maxWidth: sourceSidebarCollapsed ? COLLAPSED_SOURCE_SIDEBAR_WIDTH : '50vw',
            flexShrink: 0,
            borderRight: '1px solid #e5e7eb',
            display: 'flex',
            minHeight: 0,
            overflow: 'hidden',
            bgcolor: '#fff',
          }}
        >
          {sourceSidebarCollapsed ? (
            <AiaBox sx={{ width: '100%', minHeight: 0, display: 'flex', flexDirection: 'column' }}>
              <AiaBox sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
                <SttmSidebarCollapsedRail
                  items={[
                    { kind: 'source', label: 'Source Tables' },
                    { kind: 'derived', label: CTE_SECTION_LABEL },
                    ...(activeProjectId ? [{ kind: 'firm' as const, label: 'Firm Values' }] : []),
                  ]}
            />
          </AiaBox>
              <SttmSidebarCollapseFooter
                collapsed
                centered
                height={FOOTER_ROW_HEIGHT}
                expandLabel="Expand source sidebar"
                onToggle={() => setSourceSidebarCollapsed(false)}
                                />
            </AiaBox>
          ) : null}
          {/* Hidden rather than unmounted while collapsed, so search and expanded tables are kept. */}
                                <AiaBox
                                  sx={{
              display: sourceSidebarCollapsed ? 'none' : 'flex',
              flexDirection: 'column',
                                    flex: 1,
                                    minWidth: 0,
              minHeight: 0,
                                  }}
                                >
          <AiaBox sx={{ flex: 1, minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <ResizableSidebarSections
              // Only Source Tables starts open in this popup.
              defaultExpanded={{ source: true, cte: false, firm: false }}
              sections={[
                {
                  id: 'source',
                  title: 'Source Tables',
                  icon: <SttmSidebarSectionIcon kind="source" />,
                  content: (
                    <>
                      {renderSectionSearch(sourceSearch, setSourceSearch, 'Search tables, columns...')}
                      <AiaBox sx={{ px: 0.5 }}>
                        {filteredSourceSchemas.map(([schema, groups]) => (
                          <AiaBox key={schema} sx={{ mb: 1 }}>
                            <AiaText sx={sectionCategorySx}>{schema}</AiaText>
                            {groups.map((group) => renderColumnGroup(group, false))}
              </AiaBox>
            ))}
                        {filteredSourceSchemas.length === 0
                          ? renderSectionEmpty(
                              physicalColumnGroups.length === 0
                                ? 'No source tables available. Select tables first.'
                                : 'No columns match your search.',
                            )
                          : null}
                      </AiaBox>
                    </>
                  ),
                },
                {
                  id: 'cte',
                  title: CTE_SECTION_LABEL,
                  icon: <SttmSidebarSectionIcon kind="derived" />,
                  content: (
                    <>
                      {renderSectionSearch(cteSearch, setCteSearch, 'Search CTEs, columns...')}
                      <AiaBox sx={{ px: 0.5 }}>
                        {filteredCteGroups.map((group) => renderColumnGroup(group, true))}
                        {filteredCteGroups.length === 0
                          ? renderSectionEmpty(
                              derivedColumnGroups.length === 0
                                ? 'No CTE sources selected in Select Tables.'
                                : 'No CTEs or columns match your search.',
                            )
                          : null}
                      </AiaBox>
                    </>
                  ),
                },
                ...(activeProjectId
                  ? [
                      {
                        id: 'firm',
                        title: 'Firm Values',
                        icon: <SttmSidebarSectionIcon kind="firm" />,
                        content: (
                          <>
                            {renderSectionSearch(firmSearch, setFirmSearch, 'Search firm values...')}
                            <AiaBox sx={{ px: 0.5 }}>
                              {filteredFirmValues.map((attribute) => renderFirmValue(attribute))}
                              {filteredFirmValues.length === 0
                                ? renderSectionEmpty(
                                    isLoadingProjectAttributes && firmValues.length === 0
                                      ? 'Loading firm values...'
                                      : firmValues.length === 0
                                        ? 'No firm values in this project.'
                                        : 'No firm values match your search.',
                                  )
                                : null}
                            </AiaBox>
                          </>
                        ),
                      },
                    ]
                  : []),
              ]}
            />
          </AiaBox>
          <SttmSidebarCollapseFooter
            collapsed={false}
            height={FOOTER_ROW_HEIGHT}
            collapseLabel="Collapse source sidebar"
            onToggle={() => setSourceSidebarCollapsed(true)}
          />
          </AiaBox>
          {sourceSidebarCollapsed ? null : (
            <AiaResizeHandle
              direction="horizontal"
              onMouseDown={(event) => {
                event.preventDefault();
                sourceSidebarResizeRef.current = { startX: event.clientX, startWidth: sourceSidebarWidth };
                }}
            />
            )}
          </AiaBox>

        <AiaBox sx={{ flex: 1, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
        <AiaBox
          sx={{
            flex: 1,
            minWidth: 0,
            minHeight: 0,
            display: 'flex',
            gap: 1.5,
            p: 3,
            bgcolor: '#f8fafc',
            overflow: 'hidden',
          }}
        >
          <AiaBox
            data-tour={TOUR_TARGETS.preprocessSqlEditor}
            sx={{ flex: 1, minWidth: 0, minHeight: 0, display: 'flex' }}
          >
          <SqlEditor
            value={expression}
            onChange={setExpression}
            undoHistory
            historyKey={activeMappingId}
            completionCandidates={sqlCompletionCandidates}
            title="SQL Preview"
            subtitle={joinSubtitle}
            placeholder={`-- Type or click a column from the left panel\n-- e.g. UPPER(a.NAME)   or   ROW_NUMBER() OVER(ORDER BY a.DATE_KEY)`}
            showCopy
            insertAtCursorRef={insertAtCursorRef}
            fillHeight
            minHeight={SQL_EDITOR_PANEL_MIN_HEIGHT}
            maxHeight="100%"
            sx={{ width: '100%', flex: 1, minWidth: 0, minHeight: 0 }}
          />
          </AiaBox>
          <AiaBox
            data-tour={TOUR_TARGETS.preprocessCustomRuleLibrary}
            sx={{
              width: 280,
              flexShrink: 0,
              minHeight: 0,
              display: 'flex',
              flexDirection: 'column',
              bgcolor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: 2,
              overflow: 'hidden',
            }}
          >
            <AiaBox
              sx={{
                height: 'var(--aia-sidebar-nav-item-height)',
                minHeight: 'var(--aia-sidebar-nav-item-height)',
                px: 'var(--aia-sidebar-nav-padding-x)',
                borderBottom: '1px solid #eef2f7',
                bgcolor: '#fafafa',
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--aia-sidebar-nav-icon-gap)',
                flexShrink: 0,
              }}
            >
              <SttmSidebarSectionIcon kind="rules" />
              <AiaText
                sx={{
                  fontSize: 'var(--aia-sidebar-nav-font-size)',
                  fontWeight: 'var(--aia-sidebar-nav-font-weight)',
                  lineHeight: 'var(--aia-sidebar-nav-line-height)',
                  color: 'var(--aia-sidebar-nav-text-color)',
                  textTransform: 'capitalize',
                  whiteSpace: 'nowrap',
                }}
              >
                Custom Rule Library
              </AiaText>
            </AiaBox>
            <AiaBox sx={{ px: 1.5, pt: 1.25, pb: 1, flexShrink: 0 }}>
              <AiaSelect
                label="Project"
                value={selectedLibraryProjectId}
                onChange={(value) => {
                  setLibraryProjectId(String(value));
                  setRuleSearch('');
                }}
                fullWidth
                size="small"
                menuMatchAnchor
                options={libraryProjectOptions}
              />
              <AiaBox sx={{ mt: 1 }}>
                {renderSectionSearch(ruleSearch, setRuleSearch, 'Search custom rules...', { px: 0, pt: 0, pb: 0 })}
              </AiaBox>
            </AiaBox>
            {libraryNotice ? (
              <AiaText sx={{ px: 1.5, pb: 0.75, fontSize: 12, color: '#047857' }}>
                {libraryNotice}
              </AiaText>
            ) : null}
            <AiaBox sx={{ flex: 1, minHeight: 0, overflowY: 'auto', px: 0.5, pb: 1 }}>
              {filteredLibraryRules.map((rule) => renderLibraryRule(rule, !viewingCurrentLibrary))}
              {filteredLibraryRules.length === 0
                ? renderSectionEmpty(
                    !selectedLibraryProjectId
                      ? 'Open a project to use saved rules.'
                      : (viewingCurrentLibrary ? libraryRulesLoading : otherProjectRulesLoading)
                        ? 'Loading saved rules...'
                        : (viewingCurrentLibrary ? libraryRulesError : otherProjectRulesError)
                          ? ((viewingCurrentLibrary ? libraryRulesError : otherProjectRulesError) ?? 'Unable to load saved rules.')
                          : projectLibraryRules.length === 0
                            ? 'No saved rules in this project yet.'
                            : 'No saved rules match your search.',
                  )
                : null}
              {viewingCurrentLibrary && loadedLibraryRule && missingRuleColumns.length > 0 ? (
                <AiaText sx={{ px: 1.25, py: 0.5, fontSize: 12, fontWeight: 600, color: '#b91c1c', lineHeight: 1.45 }}>
                  Some columns in this rule are not in the current mapping. Edit the SQL before applying.
                </AiaText>
              ) : null}
            </AiaBox>
          </AiaBox>
        </AiaBox>

      <AiaBox
        sx={{
          px: 3,
          height: FOOTER_ROW_HEIGHT,
          flexShrink: 0,
          borderTop: '1px solid #f1f5f9',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 2,
        }}
      >
        <AiaText title={selectionSummary} sx={{ fontSize: 12, color: '#64748b', ...singleLineNameSx }}>
          {selectionSummary}
        </AiaText>
        <AiaBox sx={{ display: 'flex', gap: 1.5, flexShrink: 0 }}>
          <AiaButton
            variant="outlined"
            size="large"
            onClick={handleClose}
            data-tour={TOUR_TARGETS.preprocessCancel}
            customBorderColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-color)"
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="outlined"
            size="large"
            onClick={openSaveDialog}
            disabled={!expression.trim() || !activeProjectId || savingRule}
            customBorderColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-color)"
          >
            Save to library
          </AiaButton>
          <AiaButton
            variant="contained"
            size="large"
            color="primary"
            onClick={handleApply}
            data-tour={TOUR_TARGETS.preprocessApplyRule}
            disabled={!expression.trim() && selectedColumns.length === 0}
            {...modalPrimaryButtonColors}
          >
            Apply Rule
          </AiaButton>
        </AiaBox>
      </AiaBox>
        </AiaBox>
      </AiaBox>
    </AiaDialog>
    <AiaDialog
      open={isPreProcessModalOpen && saveDialogOpen}
      onClose={() => {
        if (savingRule) return;
        setSaveDialogOpen(false);
      }}
      fullWidth
      maxWidth="sm"
    >
      <AiaDialogTitle sx={{ fontWeight: 700 }}>Save to library</AiaDialogTitle>
      <AiaDialogContent>
        <AiaBox sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
          <AiaBox>
            <AiaText sx={{ fontSize: 12, fontWeight: 600, color: '#64748b', mb: 0.5 }}>RULE NAME</AiaText>
            <AiaInput
              fullWidth
              value={saveName}
              placeholder="Enter a rule name"
              disabled={savingRule}
              onChange={(value) => setSaveName(value)}
            />
            {overwriteRuleName ? (
              <AiaText sx={{ mt: 0.75, fontSize: 12, fontWeight: 600, color: '#b91c1c', lineHeight: 1.45 }}>
                {overwriteRuleName} is already in the library. Overwrite it, or change the name to save a new rule.
              </AiaText>
            ) : null}
          </AiaBox>
          <AiaBox>
            <AiaText sx={{ fontSize: 12, fontWeight: 600, color: '#64748b', mb: 0.5 }}>
              DESCRIPTION
            </AiaText>
            <AiaInput
              fullWidth
              multiline
              minRows={2}
              value={saveDescription}
              placeholder="Optional"
              disabled={savingRule}
              onChange={(value) => setSaveDescription(value)}
            />
          </AiaBox>
          {saveError ? (
            <AiaText sx={{ fontSize: 13, color: '#b45309', lineHeight: 1.45 }}>{saveError}</AiaText>
          ) : null}
        </AiaBox>
      </AiaDialogContent>
      <AiaDialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
        <AiaButton
          variant="outlined"
          size="medium"
          disabled={savingRule}
          onClick={() => setSaveDialogOpen(false)}
        >
          Cancel
        </AiaButton>
        {overwriteRuleName ? (
          <AiaButton
            variant="outlined"
            size="medium"
            disabled={savingRule}
            onClick={() => void submitLibraryRule('overwrite')}
          >
            Overwrite
          </AiaButton>
        ) : null}
        <AiaButton
          variant="contained"
          color="primary"
          size="medium"
          disabled={savingRule || !typedRuleName || Boolean(overwriteRuleName)}
          onClick={() => void submitLibraryRule('ask')}
          {...modalPrimaryButtonColors}
        >
          {savingRule ? 'Saving...' : saveStartedFromLibrary || overwriteRuleName ? 'Save as new' : 'Save'}
        </AiaButton>
      </AiaDialogActions>
    </AiaDialog>
    <AiaDialog
      open={isPreProcessModalOpen && Boolean(renameTarget)}
      onClose={() => {
        if (renamingRule) return;
        setRenameTarget(null);
      }}
      fullWidth
      maxWidth="sm"
    >
      <AiaDialogTitle sx={{ fontWeight: 700 }}>Edit rule</AiaDialogTitle>
      <AiaDialogContent>
        <AiaBox sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
          <AiaBox>
            <AiaText sx={{ fontSize: 12, fontWeight: 600, color: '#64748b', mb: 0.5 }}>RULE NAME</AiaText>
            <AiaInput
              fullWidth
              value={renameName}
              disabled={renamingRule}
              onChange={(value) => setRenameName(value)}
            />
          </AiaBox>
          <SqlEditor
            value={renameExpression}
            onChange={setRenameExpression}
            readOnly={renamingRule}
            title="SQL Preview"
            showCopy
            showLineNumbers
            undoHistory
            completionCandidates={sqlCompletionCandidates}
            minHeight={220}
            maxHeight={320}
            placeholder="-- Edit the rule SQL"
            sx={{ width: '100%' }}
          />
          {renameError ? (
            <AiaText sx={{ fontSize: 13, color: '#b91c1c', lineHeight: 1.45 }}>{renameError}</AiaText>
          ) : null}
        </AiaBox>
      </AiaDialogContent>
      <AiaDialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
        <AiaButton variant="outlined" disabled={renamingRule} onClick={() => setRenameTarget(null)}>
          Cancel
        </AiaButton>
        <AiaButton
          variant="contained"
          disabled={renamingRule || !renameName.trim() || !renameExpression.trim()}
          onClick={() => void submitRename()}
        >
          {renamingRule ? 'Saving...' : 'Save'}
        </AiaButton>
      </AiaDialogActions>
    </AiaDialog>
    <AiaDialog
      open={isPreProcessModalOpen && Boolean(deleteTarget)}
      onClose={() => {
        if (deletingRule) return;
        setDeleteTarget(null);
      }}
      fullWidth
      maxWidth="xs"
    >
      <AiaDialogTitle sx={{ fontWeight: 700 }}>Delete rule</AiaDialogTitle>
      <AiaDialogContent>
        <AiaText sx={{ fontSize: 14, lineHeight: 1.5 }}>
          Delete {deleteTarget?.rule_name}? Mappings that already use its SQL keep that SQL.
        </AiaText>
        {deleteError ? (
          <AiaText sx={{ mt: 1, fontSize: 13, color: '#b91c1c' }}>{deleteError}</AiaText>
        ) : null}
      </AiaDialogContent>
      <AiaDialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
        <AiaButton variant="outlined" disabled={deletingRule} onClick={() => setDeleteTarget(null)}>
          Cancel
        </AiaButton>
        <AiaButton color="error" variant="contained" disabled={deletingRule} onClick={() => void submitDelete()}>
          {deletingRule ? 'Deleting...' : 'Delete'}
        </AiaButton>
      </AiaDialogActions>
    </AiaDialog>
    </>
  );
}
