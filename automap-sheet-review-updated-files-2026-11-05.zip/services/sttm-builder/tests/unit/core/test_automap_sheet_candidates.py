from types import SimpleNamespace

import pytest
from pydantic import ValidationError

from app.core.automap_row_candidates import validate_row_candidates
from app.schema.sttm_builder import (AttributeMapping, MappingCandidate, SourceMappingResult,
    STTMBuilderEnvelopeRequest, STTMBuilderResponse, STTMStatus, SubAgent)


def request():
    return STTMBuilderEnvelopeRequest.model_validate({
        'operation': 'sttm.auto_map', 'data': {'intent': 'AUTO_MAP', 'attributes': [{
            'target_table': {'database': 'D', 'schema': 'OUT', 'table': 'TARGET'}, 'target_attribute': 'NAME', 'target_data_type': 'VARCHAR'}]},
        'context': {'relation_graph': {'nodes': [{'relation_id': 'D.S.T', 'alias': 'src', 'kind': 'PHYSICAL_TABLE',
            'table': {'database': 'D', 'schema': 'S', 'table': 'T'},
            'output_columns': [{'name': 'NAME', 'data_type': 'VARCHAR'}, {'name': 'OTHER', 'data_type': 'VARCHAR'}]}]}}})


def option(source='src.NAME', confidence=.4, **changes):
    return dict(source_attributes=[source], source_dependencies=[source], confidence_score=confidence,
                confidence_reason=f'Evidence for {source}', preprocessing_rule_type='Direct',
                transformation_classification='direct') | changes


class ExplainSession:
    def __init__(self): self.queries = []
    def sql(self, text):
        assert text.startswith('EXPLAIN USING TEXT ')
        self.queries.append(text)
        if 'UNKNOWN_FUNCTION' in text:
            raise ValueError('Invalid function')
        return SimpleNamespace(collect=lambda: [])


def validate(primary=None, alternatives=(), req=None):
    req = req or request()
    mapping = AttributeMapping.model_validate({**(primary or option()), 'candidates': list(alternatives)})
    result = SourceMappingResult(mappings={'NAME': mapping})
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=result, message=None, status=STTMStatus.COMPLETED)
    session = ExplainSession()
    result = validate_row_candidates(SimpleNamespace(_query_session=session), req, response)
    assert result.result == result.data.result
    return result.result.mappings['NAME'], session


def test_low_confidence_is_valid_and_no_alternatives_are_manufactured():
    mapping, _ = validate(option(confidence=.12))
    assert mapping.selected_candidate_id == mapping.candidates[0].candidate_id
    assert mapping.confidence_score == .12
    assert len(mapping.candidates) == 1
    assert mapping.candidates[0].validation_status == 'valid'


def test_each_candidate_keeps_its_own_score_reason_sources_and_rule():
    mapping, session = validate(option(confidence=.8), [option('src.OTHER', .6,
        preprocessing_rule="UPPER(src.OTHER)", preprocessing_rule_type='Custom', transformation_classification='complex')])
    assert [candidate.confidence_score for candidate in mapping.candidates] == [.8, .6]
    assert mapping.candidates[1].confidence_reason == 'Evidence for src.OTHER'
    assert mapping.candidates[1].preprocessing_rule == 'UPPER(src.OTHER)'
    assert len(session.queries) == 1
    assert all(candidate.validation_status == 'valid' for candidate in mapping.candidates)


def test_highest_invalid_option_does_not_displace_a_valid_low_confidence_option():
    mapping, _ = validate(option('src.MISSING', .99), [option('src.OTHER', .22)])
    assert mapping.source_attributes == ['src.OTHER']
    assert mapping.confidence_score == .22
    assert mapping.candidates[0].validation_status == 'invalid'
    assert mapping.selected_candidate_id == mapping.candidates[1].candidate_id


@pytest.mark.parametrize('changes', [
    {'source_attributes': ['src.MISSING']},
    {'source_attributes': ['outside.NAME']},
    {'preprocessing_rule': 'UNKNOWN_FUNCTION(src.NAME)', 'preprocessing_rule_type': 'Custom'},
    {'transformation_classification': 'complex', 'preprocessing_rule': None},
    {'mapping_mode': 'attribute', 'attribute_name': 'FIRM', 'constant_value': '$FIRM', 'value_binding_ids': ['missing']},
])
def test_invalid_claimed_valid_candidates_remain_unresolved(changes):
    mapping, _ = validate(option(**changes), [option(**changes, validation_status='valid')])
    assert mapping.selected_candidate_id is None
    assert mapping.transformation_classification == 'unresolved'
    assert all(candidate.validation_status == 'invalid' for candidate in mapping.candidates)
    assert all(candidate.validation_errors for candidate in mapping.candidates)


def test_deduplication_uses_the_complete_option():
    mapping, _ = validate(option(), [option(), option(preprocessing_rule='UPPER(src.NAME)', preprocessing_rule_type='Custom')])
    assert len(mapping.candidates) == 2
    assert len({candidate.candidate_id for candidate in mapping.candidates}) == 2


def test_three_invalid_options_do_not_hide_valid_primary():
    mapping, _ = validate(option(confidence=.1), [option('src.A', .99), option('src.B', .98), option('src.C', .97)])
    assert len(mapping.candidates) == 3
    assert mapping.source_attributes == ['src.NAME']
    assert mapping.selected_candidate_id in {candidate.candidate_id for candidate in mapping.candidates}


def test_roster_cannot_exceed_three_provider_options():
    with pytest.raises(ValidationError):
        AttributeMapping.model_validate({**option(), 'candidates': [option()] * 4})


def test_duplicate_complete_options_keep_the_highest_real_confidence_and_reason():
    mapping, _ = validate(option(confidence=.2), [option(confidence=.9, confidence_reason='Stronger evidence')])
    assert len(mapping.candidates) == 1
    assert mapping.confidence_score == .9
    assert mapping.confidence_reason == 'Stronger evidence'


def test_sheet_review_dispatch_does_not_reuse_an_unvalidated_scalar_shortcut(monkeypatch):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    req = request()
    req.meta['auto_map_sheet_review_v1'] = True
    proxy = AutoMappingProxyClient(Settings(_env_file=None))
    monkeypatch.setattr(proxy, '_exact_precedent_response', lambda *_: pytest.fail('unvalidated shortcut was used'))
    calls = []
    def invoke(batch, **kwargs):
        calls.append(batch)
        return STTMBuilderResponse.from_invocation(batch, thread_id=None, parent_message_id=None,
            agent=SubAgent.SOURCE_MAPPING_AGENT, result=SourceMappingResult(mappings={'NAME': AttributeMapping(**option())}),
            message=None, status=STTMStatus.COMPLETED)
    monkeypatch.setattr(proxy, '_invoke_batch', invoke)
    response = proxy._invoke_with_headers(req, headers={})
    assert calls
    assert response.result.mappings['NAME'].source_attributes == ['src.NAME']


def test_agent_payload_keeps_current_definition_without_sending_persisted_review_history():
    import json
    from app.core.sttm_builder import STTMBuilderService
    req = request()
    value = req.model_dump(mode='json')
    value['context']['workspace_context'] = {'mapping_rows': [{
        'id': 'row', 'target_column': 'NAME', 'source_columns': ['src.NAME'],
        'ai_candidates': [{'history': 'previous alternative'}],
        'ai_undo_snapshot': {'expression': 'old rule'}, 'ai_review_status': 'confirmed'}]}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    outgoing = json.loads(STTMBuilderService._build_agent_payload_unbounded(req))
    row = outgoing['context']['workspace_context']['mapping_rows'][0]
    assert row['source_columns'] == ['src.NAME']
    assert 'ai_candidates' not in row and 'ai_undo_snapshot' not in row
    assert req.context.workspace_context.mapping_rows[0].model_dump()['ai_review_status'] == 'confirmed'
    assert req.context.workspace_context.mapping_rows[0].model_dump()['ai_candidates']


@pytest.mark.parametrize('rule,valid', [('TRIM(src.NAME)', True), ('UNKNOWN_FUNCTION(src.NAME)', False)])
def test_a_missing_rule_type_never_bypasses_expression_validation(rule, valid):
    mapping, session = validate(option(preprocessing_rule=rule, preprocessing_rule_type=None))
    assert len(session.queries) == 1
    assert (mapping.selected_candidate_id is not None) is valid
    assert mapping.candidates[0].preprocessing_rule_type == 'Custom'


def test_direct_type_cannot_hide_an_unvalidated_expression():
    mapping, _ = validate(option(preprocessing_rule='UNKNOWN_FUNCTION(src.NAME)', preprocessing_rule_type='Direct'))
    assert mapping.selected_candidate_id is None
    assert mapping.candidates[0].validation_status == 'invalid'


def test_firm_value_remains_selectable_when_reopened_graph_has_a_new_row_binding_id():
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
    from app.schema.sttm_builder import ValueBinding
    req = request()
    binding = ValueBinding(binding_id='project-attribute:firm-1', value='$FIRM',
        resolved_value='Approved firm', data_type='VARCHAR', is_placeholder=True,
        allow_project_specific_value=True, attribute_name='FIRM', resolution_status='project_attribute')
    req.context.relation_graph.value_bindings = [binding]
    mapping, _ = validate(option(source_attributes=[], source_dependencies=[], mapping_mode='attribute',
        attribute_name='FIRM', constant_value='$FIRM', value_binding_ids=[binding.binding_id],
        transformation_classification='value', preprocessing_rule_type='Value'), req=req)
    assert mapping.selected_candidate_id
    assert mapping.value_binding_ids == ['$FIRM']
    rebuilt = req.context.relation_graph.model_copy(deep=True)
    rebuilt.value_bindings = [binding.model_copy(update={'binding_id': 'value:new-sheet-row'})]
    result = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=rebuilt, validate_with_explain=False, allow_unresolved_placeholders=False,
        mappings=[MappingSqlMappingItem(target_column='NAME', mapping_mode=mapping.mapping_mode,
            constant_value=mapping.constant_value, attribute_name=mapping.attribute_name,
            value_binding_ids=mapping.value_binding_ids, rule='Value')]))
    assert result.valid and result.ready
    assert not result.unresolved_placeholders
