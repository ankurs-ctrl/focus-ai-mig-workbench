from types import SimpleNamespace

import pytest

from app.core.mapping_sql import MappingSqlService
from app.core.snowflake_analyst import SnowflakeAnalystResponse
from app.schema.common import TableRef
from app.schema.mapping_sql import (
    MappingSqlCompileRequest,
    MappingSqlMappingItem,
    MappingSqlParseRequest,
    MappingSqlPreviewRequest,
    MappingSqlReviewRequest,
)
from app.schema.sttm_builder import (
    RelationEdge,
    RelationGraphContext,
    RelationNode,
    RelationNodeKind,
    RelationshipConditionItem,
    ValueBinding,
)


class _Query:
    def collect(self):
        return []


class _Session:
    def sql(self, _query):
        return _Query()


class _PreviewQuery:
    schema = SimpleNamespace(fields=[])

    def collect(self):
        return []


class _PreviewSession:
    def sql(self, _query, params=None):
        return _PreviewQuery()


def test_preview_without_source_alias_comparison_returns_rows_contract() -> None:
    service = MappingSqlService(session=_PreviewSession(), analyst_client=_Analyst())

    response = service.preview(
        MappingSqlPreviewRequest(
            source_query_sql="SELECT 1",
            preview_sql="SELECT 1 AS VALUE",
            generated_sql="SELECT 1 AS VALUE",
        )
    )

    assert response.valid is True
    assert response.preview_rows == []
    assert response.source_sample_rows == []


@pytest.mark.parametrize(
    "sql_text",
    [
        "SELECT 1; SELECT 2",
        "DELETE FROM DB.SCHEMA.TARGET",
        "CALL DB.SCHEMA.DO_WORK()",
    ],
)
def test_preview_rejects_multiple_statements_and_non_query_sql(sql_text: str) -> None:
    service = MappingSqlService(session=_PreviewSession(), analyst_client=_Analyst())

    with pytest.raises(ValueError, match="SELECT|WITH|DDL|DML|CALL|command"):
        service.preview(
            MappingSqlPreviewRequest(
                source_query_sql="SELECT 1",
                preview_sql=sql_text,
                generated_sql=sql_text,
            )
        )


class _FailingQuery:
    def collect(self):
        raise RuntimeError(
            "SQL compilation error: Session variable '$TransactionFirmID' does not exist"
        )


class _FailingSession:
    def sql(self, _query):
        return _FailingQuery()


class _AiRepairSession:
    def sql(self, query, params=None):
        if "AI_COMPLETE" in query or "CORTEX.COMPLETE" in query:
            class Completion:
                def collect(self):
                    return [{"RESPONSE": '{"sql":"SELECT SRC.AMOUNT / 100 AS AMOUNT FROM DB.SCHEMA.SRC AS SRC","summary":"Replaced the invalid operator phrase."}'}]
            return Completion()
        if "AMOUNT / 100" in query:
            return _Query()
        return _FailingQuery()


class _Analyst:
    def __init__(self):
        self.calls = []

    def ask(self, **kwargs):
        self.calls.append(kwargs)
        return SnowflakeAnalystResponse(
            request_id="analyst-request",
            text="The SQL is valid.",
            sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC",
        )


def test_compile_uses_current_graph_even_when_all_rows_accept_precedent() -> None:
    class Session:
        def sql(self, *_args, **_kwargs):
            raise AssertionError("Compilation must not retrieve prior RAW_MAPPING_SQL")

    service = MappingSqlService(
        session=Session(),
        analyst_client=_Analyst(),
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(
                nodes=[
                    RelationNode(
                        relation_id="DB.CRM.CONTACTS",
                        kind=RelationNodeKind.PHYSICAL_TABLE,
                        alias="contacts_1",
                        table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
                    )
                ],
            ),
            mappings=[
                MappingSqlMappingItem(
                    target_column="LEGACY_ID__C",
                    source_column="contacts_1.ID",
                    source_columns=["contacts_1.ID"],
                    source_dependencies=["contacts_1.ID"],
                    expression="'HH-' || CAST(contacts_1.ID AS TEXT)",
                    status="MAPPED",
                    precedent_decision="accept_precedent",
                    precedent_mapping_id="1101",
                )
            ],
            target_table=TableRef(database="DB", schema="TGT", table="EVERNEST_HH"),
            accepted_precedent_sttm_id="1101",
            validate_with_explain=False,
        )
    )

    assert response.valid is True
    assert response.ready is True
    assert "'HH-' || CAST(contacts_1.ID AS TEXT) AS LEGACY_ID__C" in response.preview_sql
    assert "FROM DB.CRM.CONTACTS AS contacts_1" in response.preview_sql
    assert "UserMaster" not in response.preview_sql


def test_compile_resolves_a_dependency_saved_under_the_positional_alias_scheme() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.SERVICING_ADVISORS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="servicing_advisors_kc2ar1",
                table=TableRef(
                    database="DB", schema="CRM", table="SERVICING_ADVISORS"
                ),
            )
        ]
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="ADVISOR_ID",
                    source_dependencies=["servicing_advisors_15.ID"],
                    expression="TRIM(servicing_advisors_15.ID)",
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "TRIM(servicing_advisors_kc2ar1.ID) AS ADVISOR_ID" in response.preview_sql


def test_compile_rejects_a_legacy_alias_that_matches_more_than_one_relation() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.SERVICING_ADVISORS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="servicing_advisors_kc2ar1",
                table=TableRef(database="DB", schema="CRM", table="SERVICING_ADVISORS"),
            ),
            RelationNode(
                relation_id="DB.ARCHIVE.SERVICING_ADVISORS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="servicing_advisors_x8z991",
                table=TableRef(database="DB", schema="ARCHIVE", table="SERVICING_ADVISORS"),
            ),
        ]
    )

    with pytest.raises(ValueError, match="Undefined relation or alias"):
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="ADVISOR_ID",
                        source_dependencies=["servicing_advisors_15.ID"],
                        status="MAPPED",
                    )
                ],
            )
        )


def test_legacy_alias_resolution_prefers_an_exact_suffix_shaped_table_name() -> None:
    relation_id = "DB.CRM.CONTACT_UDF_FIELDS"
    nodes = {
        relation_id: RelationNode(
            relation_id=relation_id,
            kind=RelationNodeKind.PHYSICAL_TABLE,
            alias="contact_udf_fields_a1b2c3",
            table=TableRef(database="DB", schema="CRM", table="CONTACT_UDF_FIELDS"),
        )
    }

    resolved = MappingSqlService._resolve_legacy_alias_relation(
        "CONTACT_UDF_FIELDS",
        nodes,
        {"CONTACT_UDF_FIELDS_A1B2C3": relation_id},
    )

    assert resolved == relation_id


def test_compile_resolves_project_value_binding_without_exposing_placeholder() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=RelationGraphContext(
                nodes=[
                    RelationNode(
                        relation_id="DB.CRM.CONTACTS",
                        kind=RelationNodeKind.PHYSICAL_TABLE,
                        alias="contacts_1",
                        table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
                    )
                ],
                value_bindings=[
                    ValueBinding(
                        binding_id="project-attribute:firm",
                        value="$TransactionFirmID",
                        resolved_value="42",
                        data_type="NUMBER",
                        attribute_name="TransactionFirmID",
                        is_placeholder=True,
                        allow_project_specific_value=True,
                        resolution_status="project_attribute",
                    )
                ],
            ),
            mappings=[
                MappingSqlMappingItem(
                    target_column="TRANSACTION_FIRM_ID",
                    target_type="NUMBER",
                    mapping_mode="attribute",
                    constant_value="$TransactionFirmID",
                    attribute_name="TransactionFirmID",
                    value_binding_ids=["project-attribute:firm"],
                    status="MAPPED",
                )
            ],
            target_table=TableRef(database="DB", schema="TGT", table="EVERNEST_HH"),
            validate_with_explain=False,
        )
    )

    assert response.ready is True
    assert "42 AS TRANSACTION_FIRM_ID" in response.preview_sql
    assert "$TransactionFirmID" not in response.preview_sql


def test_review_uses_inline_semantic_yaml_when_view_is_not_promoted() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC",
        generated_sql="INSERT INTO DB.SCHEMA.TGT (ID) SELECT SRC.ID FROM DB.SCHEMA.SRC",
        semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
        request_optimization=True,
    )

    response = service.review(request)

    assert response.review_agent == "CORTEX_ANALYST"
    assert analyst.calls[0]["semantic_view"] is None
    assert analyst.calls[0]["semantic_model_yaml"] == request.semantic_model_yaml


def test_review_skips_analyst_for_valid_sql_without_optimization_request() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)

    response = service.review(
        MappingSqlReviewRequest(
            source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
            preview_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC AS SRC",
            generated_sql="SELECT SRC.ID AS ID FROM DB.SCHEMA.SRC AS SRC",
            semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
        )
    )

    assert response.execution_ready is True
    assert response.review_agent == "SNOWFLAKE_EXECUTOR"
    assert analyst.calls == []


def test_review_prompt_includes_derived_output_contract_and_saved_sql() -> None:
    analyst = _Analyst()
    service = MappingSqlService(session=_Session(), analyst_client=analyst)
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT household_1.HOUSEHOLD_ID AS ID FROM household_1",
        generated_sql="SELECT household_1.HOUSEHOLD_ID AS ID FROM household_1",
        semantic_model_yaml="name: INLINE_TEST\ntables: []\n",
        request_optimization=True,
        relation_graph=RelationGraphContext(
            nodes=[
                RelationNode(
                    relation_id="household",
                    kind=RelationNodeKind.DERIVED_SOURCE,
                    alias="household_1",
                    sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES",
                    output_columns=[
                        {"name": "CONTACT_ID", "data_type": "NUMBER"},
                        {"name": "HOUSEHOLD_ID", "data_type": "NUMBER"},
                    ],
                )
            ]
        ),
    )

    service.review(request)

    question = analyst.calls[0]["question"]
    assert "outputs=['CONTACT_ID', 'HOUSEHOLD_ID']" in question
    assert "Saved SQL for derived relation household" in question
    assert "Never reference a derived column" in question


def test_review_returns_actionable_value_binding_fix_when_validation_fails() -> None:
    service = MappingSqlService(session=_FailingSession(), analyst_client=_Analyst())
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT '$TransactionFirmID' AS TRANSACTION_FIRM__C FROM DB.SCHEMA.SRC",
        generated_sql=(
            "INSERT INTO DB.SCHEMA.TGT (TRANSACTION_FIRM__C) "
            "SELECT '$TransactionFirmID' FROM DB.SCHEMA.SRC"
        ),
    )

    response = service.review(request)

    assert response.execution_ready is False
    assert response.requires_approval is False
    assert [item.code for item in response.repair_options] == [
        "resolve_value_binding",
        "edit_sql",
    ]
    assert response.repair_options[0].identifier == "$TransactionFirmID"
    assert response.repair_options[0].action == "open_mapping"


def test_review_ai_repair_is_snowflake_validated_before_approval() -> None:
    service = MappingSqlService(session=_AiRepairSession(), analyst_client=_Analyst())
    request = MappingSqlReviewRequest(
        source_query_sql="SELECT * FROM DB.SCHEMA.SRC",
        preview_sql="SELECT CAST / DIVIDE AS AMOUNT FROM DB.SCHEMA.SRC AS SRC",
        generated_sql="SELECT CAST / DIVIDE AS AMOUNT FROM DB.SCHEMA.SRC AS SRC",
        mappings=[MappingSqlMappingItem(target_column="AMOUNT", status="MAPPED")],
        attempt_ai_repair=True,
    )

    response = service.review(request)

    assert response.execution_ready is True
    assert response.requires_approval is True
    assert response.review_kind == "repair"
    assert response.optimized_preview_sql == "SELECT SRC.AMOUNT / 100 AS AMOUNT FROM DB.SCHEMA.SRC AS SRC"


def test_parse_blocks_ambiguous_unqualified_table_references() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.parse(
        MappingSqlParseRequest(
            sql="INSERT INTO TARGET_TABLE (ID) SELECT ID FROM CONTACT",
            known_tables=[
                TableRef(database="DB_A", schema="CRM", table="CONTACT"),
                TableRef(database="DB_B", schema="CRM", table="CONTACT"),
                TableRef(database="DB_A", schema="CRM", table="TARGET_TABLE"),
            ],
        )
    )

    assert response.valid is False
    assert response.ambiguous_references["CONTACT"] == [
        "DB_A.CRM.CONTACT",
        "DB_B.CRM.CONTACT",
    ]


def test_parse_select_preview_preserves_current_target() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.parse(
        MappingSqlParseRequest(
            sql="SELECT SRC.ID AS ID FROM DB_A.CRM.CONTACT AS SRC",
            known_tables=[
                TableRef(database="DB_A", schema="CRM", table="CONTACT"),
                TableRef(database="DB_A", schema="CRM", table="TARGET_TABLE"),
            ],
            current_workspace={"target_table": "DB_A.CRM.TARGET_TABLE"},
        )
    )

    assert response.valid is True
    assert response.parsed_workspace["target_table"] == "DB_A.CRM.TARGET_TABLE"
    assert "target_table_changed" not in response.diff


def test_parse_resolves_static_set_variable_as_project_attribute() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.parse(
        MappingSqlParseRequest(
            sql=(
                "SET ParentOfficeID = '001-office';\n"
                "SELECT $ParentOfficeID AS PARENT_ID FROM DB_A.CRM.CONTACT"
            ),
            known_tables=[
                TableRef(database="DB_A", schema="CRM", table="CONTACT"),
            ],
        )
    )

    row = response.parsed_workspace["mapping_rows"][0]
    assert row["mapping_mode"] == "attribute"
    assert row["attribute_name"] == "ParentOfficeID"
    assert row["constant_value"] == "001-office"


def test_compile_unifies_physical_and_derived_relations() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="household_rollup",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="household_rollup_2",
                sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES",
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-household",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="household_rollup",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID", right_column="CONTACT_ID", operator="="
                    )
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            target_table=TableRef(database="DB", schema="CRM", table="TARGET"),
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="LEGACY_ID",
                    source_columns=["DB.CRM.CONTACTS.ID", "household_rollup_2.HOUSEHOLD_ID"],
                    source_dependencies=["DB.CRM.CONTACTS.ID", "household_rollup_2.HOUSEHOLD_ID"],
                    expression="COALESCE(household_rollup_2.HOUSEHOLD_ID, DB.CRM.CONTACTS.ID)",
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "WITH\nhousehold_rollup_2 AS (" in response.preview_sql
    assert "FROM DB.CRM.CONTACTS AS contacts_1" in response.preview_sql
    assert "LEFT JOIN household_rollup_2" in response.preview_sql
    assert "COALESCE(household_rollup_2.HOUSEHOLD_ID, contacts_1.ID)" in response.preview_sql
    assert response.preview_sql.count("FROM DB.CRM.CONTACTS") == 1


def test_compile_rejects_query_level_mapping_expression() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ]
    )

    try:
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="ID",
                        source_dependencies=["contacts_1.ID"],
                        expression="contacts_1.ID FROM DB.CRM.CONTACTS",
                        status="MAPPED",
                    )
                ],
            )
        )
    except ValueError as exc:
        assert "Query-level SQL" in str(exc)
    else:
        raise AssertionError("Expected query-level SQL to be rejected")


def test_compile_preserves_but_blocks_unresolved_value_placeholder() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="parent-office",
                value="$ParentOfficeID",
                is_placeholder=True,
                resolution_status="placeholder_contract",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    mapping_mode="constant",
                    constant_value="$ParentOfficeID",
                    value_binding_ids=["parent-office"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is False
    assert response.unresolved_placeholders == ["$ParentOfficeID"]
    assert "$ParentOfficeID AS PARENT_ID" in response.preview_sql


def test_compile_substitutes_only_explicitly_resolved_value_placeholder() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="parent-office",
                value="$ParentOfficeID",
                resolved_value="001-office",
                data_type="VARCHAR",
                is_placeholder=True,
                resolution_status="resolved",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    mapping_mode="constant",
                    constant_value="$ParentOfficeID",
                    value_binding_ids=["parent-office"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert response.unresolved_placeholders == []
    assert "'001-office' AS PARENT_ID" in response.preview_sql


def test_compile_uses_named_project_attribute_as_governed_value_binding() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="project-parent-office",
                attribute_name="PARENT_OFFICE_ID",
                value="001-office",
                resolved_value="001-office",
                data_type="VARCHAR",
                allow_project_specific_value=True,
                resolution_status="resolved",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    mapping_mode="attribute",
                    attribute_name="PARENT_OFFICE_ID",
                    constant_value="001-office",
                    value_binding_ids=["project-parent-office"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert response.unresolved_placeholders == []
    assert "'001-office' AS PARENT_ID" in response.preview_sql


def test_compile_accepts_unique_placeholder_value_as_binding_reference() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="canonical-TransactionFirmID",
                value="$TransactionFirmID",
                is_placeholder=True,
                resolution_status="placeholder_contract",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="TRANSACTION_FIRM__C",
                    mapping_mode="constant",
                    constant_value="$TransactionFirmID",
                    value_binding_ids=["$TransactionFirmID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is False
    assert response.unresolved_placeholders == ["$TransactionFirmID"]


def test_compile_rejects_circular_derived_dependencies() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="derived_a",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="derived_a",
                sql_text="SELECT ID FROM derived_b",
                parent_relation_ids=["derived_b"],
            ),
            RelationNode(
                relation_id="derived_b",
                kind=RelationNodeKind.CTE,
                alias="derived_b",
                sql_text="SELECT ID FROM derived_a",
                parent_relation_ids=["derived_a"],
            ),
        ]
    )

    try:
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                driving_relation_id="derived_a",
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="ID",
                        source_dependencies=["derived_a.ID"],
                        status="MAPPED",
                    )
                ],
            )
        )
    except ValueError as exc:
        assert "Circular derived-source dependency" in str(exc)
    else:
        raise AssertionError("Expected circular derived dependencies to be rejected")


def test_compile_rejects_column_missing_from_derived_output_contract() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="household_rollup",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="household_rollup_1",
                sql_text="SELECT CONTACT_ID, HOUSEHOLD_ID FROM DB.CRM.FAMILIES",
                output_columns=[
                    {"name": "CONTACT_ID", "data_type": "NUMBER"},
                    {"name": "HOUSEHOLD_ID", "data_type": "NUMBER"},
                ],
            )
        ]
    )

    try:
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="LEGACY_FIRM_INFO__C",
                        source_columns=["household_rollup.MISSING_LEGACY_INFO"],
                        source_dependencies=["household_rollup.MISSING_LEGACY_INFO"],
                        status="MAPPED",
                    )
                ],
            )
        )
    except ValueError as exc:
        assert "is not produced by relation household_rollup" in str(exc)
    else:
        raise AssertionError("Expected missing derived output to be rejected")


def test_compile_resolves_a_project_attribute_placeholder_inside_an_expression() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_9",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ],
        value_bindings=[
            ValueBinding(
                binding_id="backup-owner",
                value="$BackupOwnerID",
                is_placeholder=True,
                resolution_status="project_attribute",
                resolved_value="005Qi00000ZBGiAIAX",
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            target_table=TableRef(database="DB", schema="CRM", table="TARGET"),
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="OWNERID",
                    source_columns=["DB.CRM.CONTACTS.ID"],
                    source_dependencies=["DB.CRM.CONTACTS.ID"],
                    expression="COALESCE(contacts_9.ID, $BackupOwnerID)",
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert response.unresolved_placeholders == []
    assert "$BackupOwnerID" not in response.preview_sql
    assert "COALESCE(contacts_9.ID, '005Qi00000ZBGiAIAX')" in response.preview_sql


def _bare_qualifier_graph(second_schema: str = "CRM") -> RelationGraphContext:
    return RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_9",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id=f"DB.{second_schema}.ADDRESSES",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="addresses_18",
                table=TableRef(database="DB", schema=second_schema, table="ADDRESSES"),
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id=f"DB.{second_schema}.ADDRESSES",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID", right_column="ADDRESSABLE_ID", operator="="
                    )
                ],
            )
        ],
    )


def _bare_qualifier_request(
    graph: RelationGraphContext, expression: str
) -> MappingSqlCompileRequest:
    return MappingSqlCompileRequest(
        relation_graph=graph,
        target_table=TableRef(database="DB", schema="CRM", table="TARGET"),
        driving_relation_id="DB.CRM.CONTACTS",
        validate_with_explain=False,
        mappings=[
            MappingSqlMappingItem(
                target_column="BILLINGCOUNTRY",
                source_columns=["DB.CRM.CONTACTS.ID"],
                source_dependencies=["DB.CRM.CONTACTS.ID"],
                expression=expression,
                status="MAPPED",
            )
        ],
    )


def test_compile_resolves_a_bare_table_name_qualifier_to_its_alias() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.compile(
        _bare_qualifier_request(
            _bare_qualifier_graph(),
            "NULLIF(UPPER(TRIM(ADDRESSES.COUNTRY)), '')",
        )
    )

    assert response.ready is True
    assert "addresses_18.COUNTRY" in response.preview_sql
    assert "ADDRESSES.COUNTRY" not in response.preview_sql
    assert "LEFT JOIN DB.CRM.ADDRESSES AS addresses_18" in response.preview_sql


def test_compile_resolves_a_schema_qualified_table_name_to_its_alias() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    response = service.compile(
        _bare_qualifier_request(
            _bare_qualifier_graph(),
            "TRIM(CRM.ADDRESSES.COUNTRY)",
        )
    )

    assert response.ready is True
    assert "addresses_18.COUNTRY" in response.preview_sql


def test_compile_still_rejects_an_unknown_bare_table_name() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())

    with pytest.raises(ValueError, match="Undefined SQL alias in mapping expression: PHONES"):
        service.compile(
            _bare_qualifier_request(_bare_qualifier_graph(), "TRIM(PHONES.NUMBER)")
        )


def test_compile_refuses_an_ambiguous_bare_table_name() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = _bare_qualifier_graph(second_schema="BILLING")
    graph.nodes.append(
        RelationNode(
            relation_id="DB.SHIPPING.ADDRESSES",
            kind=RelationNodeKind.PHYSICAL_TABLE,
            alias="addresses_21",
            table=TableRef(database="DB", schema="SHIPPING", table="ADDRESSES"),
        )
    )

    with pytest.raises(ValueError, match="Undefined SQL alias in mapping expression: ADDRESSES"):
        service.compile(_bare_qualifier_request(graph, "TRIM(ADDRESSES.COUNTRY)"))

    response = service.compile(
        _bare_qualifier_request(graph, "TRIM(BILLING.ADDRESSES.COUNTRY)")
    )
    assert response.ready is True
    assert "addresses_18.COUNTRY" in response.preview_sql


def test_compile_inherits_parent_join_for_a_disconnected_derived_source() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="DB.CRM.ADDRESSES",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="addresses_2",
                table=TableRef(database="DB", schema="CRM", table="ADDRESSES"),
            ),
            RelationNode(
                relation_id="billing_address",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="billing_address_3",
                sql_text=(
                    "SELECT a.ADDRESSABLE_ID AS CONTACT_ID, a.COUNTRY "
                    "FROM DB.CRM.ADDRESSES AS a WHERE a.IS_PRIMARY = 1"
                ),
                output_columns=[{"name": "CONTACT_ID"}, {"name": "COUNTRY"}],
                column_semantics=[
                    {
                        "name": "CONTACT_ID",
                        "source_columns": ["a.ADDRESSABLE_ID"],
                    },
                    {"name": "COUNTRY", "source_columns": ["a.COUNTRY"]},
                ],
                base_relation_ids=["DB.CRM.ADDRESSES"],
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="DB.CRM.ADDRESSES",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID",
                        right_column="ADDRESSABLE_ID",
                        operator="=",
                    )
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CONTACTS",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="BILLINGCOUNTRY",
                    source_dependencies=["billing_address.COUNTRY"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "LEFT JOIN billing_address_3" in response.preview_sql
    assert "contacts_1.ID = billing_address_3.CONTACT_ID" in response.preview_sql


def test_compile_does_not_inherit_a_join_when_the_parent_key_was_dropped() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            ),
            RelationNode(
                relation_id="DB.CRM.ADDRESSES",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="addresses_2",
                table=TableRef(database="DB", schema="CRM", table="ADDRESSES"),
            ),
            RelationNode(
                relation_id="billing_address",
                kind=RelationNodeKind.DERIVED_SOURCE,
                alias="billing_address_3",
                sql_text="SELECT a.COUNTRY FROM DB.CRM.ADDRESSES AS a",
                output_columns=[{"name": "COUNTRY"}],
                column_semantics=[
                    {"name": "COUNTRY", "source_columns": ["a.COUNTRY"]}
                ],
                base_relation_ids=["DB.CRM.ADDRESSES"],
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="contacts-addresses",
                left_relation_id="DB.CRM.CONTACTS",
                right_relation_id="DB.CRM.ADDRESSES",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID",
                        right_column="ADDRESSABLE_ID",
                        operator="=",
                    )
                ],
            )
        ],
    )

    with pytest.raises(ValueError, match="Required relations are disconnected"):
        service.compile(
            MappingSqlCompileRequest(
                relation_graph=graph,
                driving_relation_id="DB.CRM.CONTACTS",
                validate_with_explain=False,
                mappings=[
                    MappingSqlMappingItem(
                        target_column="BILLINGCOUNTRY",
                        source_dependencies=["billing_address.COUNTRY"],
                        status="MAPPED",
                    )
                ],
            )
        )


def test_compile_resolves_dependency_relation_id_case_insensitively() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.CONTACTS",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="contacts_1",
                table=TableRef(database="DB", schema="CRM", table="CONTACTS"),
            )
        ]
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="OWNER_ID",
                    source_dependencies=["db.crm.contacts.ID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "contacts_1.ID AS OWNER_ID" in response.preview_sql


def test_compile_reverses_left_join_when_driving_from_right_endpoint() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.PARENT",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="parent_1",
                table=TableRef(database="DB", schema="CRM", table="PARENT"),
            ),
            RelationNode(
                relation_id="DB.CRM.CHILD",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="child_2",
                table=TableRef(database="DB", schema="CRM", table="CHILD"),
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="parent-child",
                left_relation_id="DB.CRM.PARENT",
                right_relation_id="DB.CRM.CHILD",
                join_type="LEFT",
                conditions=[
                    RelationshipConditionItem(
                        left_column="ID",
                        right_column="PARENT_ID",
                        operator="=",
                    )
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="DB.CRM.CHILD",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    source_dependencies=["DB.CRM.PARENT.ID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert "FROM DB.CRM.CHILD AS child_2" in response.preview_sql
    assert "RIGHT JOIN DB.CRM.PARENT AS parent_1" in response.preview_sql


def test_compile_normalizes_driving_and_edge_relation_ids_case_insensitively() -> None:
    service = MappingSqlService(session=_Session(), analyst_client=_Analyst())
    graph = RelationGraphContext(
        nodes=[
            RelationNode(
                relation_id="DB.CRM.PARENT",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="parent_1",
                table=TableRef(database="DB", schema="CRM", table="PARENT"),
            ),
            RelationNode(
                relation_id="DB.CRM.CHILD",
                kind=RelationNodeKind.PHYSICAL_TABLE,
                alias="child_2",
                table=TableRef(database="DB", schema="CRM", table="CHILD"),
            ),
        ],
        edges=[
            RelationEdge(
                edge_id="parent-child",
                left_relation_id="db.crm.parent",
                right_relation_id="db.crm.child",
                join_type="INNER",
                conditions=[
                    RelationshipConditionItem(left_column="ID", right_column="PARENT_ID")
                ],
            )
        ],
    )

    response = service.compile(
        MappingSqlCompileRequest(
            relation_graph=graph,
            driving_relation_id="db.crm.child",
            validate_with_explain=False,
            mappings=[
                MappingSqlMappingItem(
                    target_column="PARENT_ID",
                    source_dependencies=["db.crm.parent.ID"],
                    status="MAPPED",
                )
            ],
        )
    )

    assert response.ready is True
    assert "JOIN DB.CRM.PARENT AS parent_1" in response.preview_sql
