import api from "@/api/axiosInstance";
import type {
  FIRRecommendation,
  FIRRecommendationEvaluationResponse,
  WorkbenchContextSnapshotV2,
} from "@/types/api-contract";

export const recommendationService = {
  evaluate: async (
    workspaceContext: WorkbenchContextSnapshotV2,
    options?: { checkpoint?: string | null; projectId?: string | null; signal?: AbortSignal },
  ): Promise<FIRRecommendationEvaluationResponse> => {
    const response = await api.post(
      "/v1/recommendations/evaluate",
      {
        workspace_context: workspaceContext,
        checkpoint: options?.checkpoint ?? workspaceContext.checkpoint ?? workspaceContext.milestone,
        project_id: options?.projectId ?? workspaceContext.project_id,
        limit: 20,
        include_search_fallback: true,
        include_evidence: false,
      },
      { timeout: 30000, signal: options?.signal },
    );
    return response.data as FIRRecommendationEvaluationResponse;
  },

  get: async (recommendationId: string): Promise<FIRRecommendation> => {
    const response = await api.get(
      `/v1/recommendations/${encodeURIComponent(recommendationId)}`,
      { timeout: 30000 },
    );
    return response.data as FIRRecommendation;
  },

  recordOutcome: async (
    recommendationId: string,
    payload: {
      outcome_type: string;
      context_key?: string | null;
      snapshot_id?: string | null;
      user_id?: string | null;
      payload?: Record<string, unknown>;
    },
  ) => {
    await api.post(`/v1/recommendations/${encodeURIComponent(recommendationId)}/outcomes`, payload, {
      timeout: 30000,
    });
  },
};
