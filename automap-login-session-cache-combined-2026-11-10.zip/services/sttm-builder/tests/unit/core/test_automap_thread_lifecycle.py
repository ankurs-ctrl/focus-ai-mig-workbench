"""Offline durable lifecycle contracts; no live provider/SQL correctness claim."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from dataclasses import replace
import json
from threading import Barrier, Lock
import traceback

import httpx
import pytest

from app.core import automap_admission as admission
from app.core.automap_scan import ScanStopped
from app.core.automap_scan_transport import (
    AUTOMAP_USER_AGENT, SnowflakeScanTransport, ScanTransportConfig, ScanTransportError, RawResponseBudgetError,
    ThreadTerminalEvidence, ThreadTerminalStatus, ThreadEvidenceSource,
)
from app.core.snowflake_agent import SnowflakeAgentClient
from test_automap_admission import Database, adapter, request, store, IDENTITY


AGENT = "DB.SC.SCAN_AGENT"
TOKEN = "private-credential-never-log"
MESSAGE = '[ {"role":"user", "status":"completed", "content":[{"type":"text","text":"exact \\u00e9"}]} ]'


def reply(data, status=200):
    return httpx.Response(status, stream=httpx.ByteStream(json.dumps(data).encode()))


def transport(gate, client):
    return SnowflakeScanTransport(agent_client=SnowflakeAgentClient(TOKEN,
        host="test_org-test_account.snowflakecomputing.com", role="CALLER"),
        http_client=client, config=ScanTransportConfig(AGENT, 120_000), admission=gate)


def run(gate, backend, req):
    with gate(req):
        return gate.wrap_backend(backend)(req)


def test_interleaved_workers_commit_distinct_threads_before_exact_single_post():
    database = Database()
    gate = adapter(database)
    barrier = Barrier(2)
    sent = []
    refs = []
    sent_lock = Lock()

    def handler(outgoing):
        assert outgoing.headers["Authorization"] == "Bearer " + TOKEN
        if outgoing.url.path == "/api/v2/cortex/threads":
            assert outgoing.content == b"{}"
            with sent_lock:
                thread_id = 100 + len(sent)
                sent.append(outgoing)
            barrier.wait(3)
            return reply({"thread_id": thread_id})
        data = json.loads(outgoing.content)
        with database.lock:
            rows = deepcopy(database.rows)
        match = next(row for row in rows if row["RECONCILIATION_REF"] is not None
                     and json.loads(row["RECONCILIATION_REF"])["thread_id"] == data["thread_id"])
        assert match["STATE"] == "HELD"
        assert any(session.commands and session.commands[-1][0] == "COMMIT" and any("SET RECONCILIATION_REF" in sql
            and params[0] == match["RECONCILIATION_REF"] for sql, params in session.commands)
            for session in database.sessions)
        assert outgoing.content == ('{"messages":' + MESSAGE + ',"stream":false,"thread_id":'
            + str(data["thread_id"]) + ',"parent_message_id":0}').encode()
        refs.append((match["SHARD_ID"], data["thread_id"]))
        # Keep both HELD until both model requests have checked persisted refs.
        barrier.wait(3)
        return reply({"role": "assistant", "status": "completed", "content": [{"type": "text", "text": "{}"}]})

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        backend = transport(gate, client)
        with ThreadPoolExecutor(2) as workers:
            futures = [workers.submit(run, gate, backend, request(message=MESSAGE, shard_id=f"shard-{index}"))
                       for index in range(2)]
            assert [future.result(5) for future in futures] == ["{}", "{}"]
    assert len(refs) == 2 and len({thread for _, thread in refs}) == 2
    assert {shard for shard, _ in refs} == {"shard-0", "shard-1"}
    assert all(row["STATE"] == "FREE" for row in database.rows)


@pytest.mark.parametrize("failure", ["before", "after", "zero", "multiple", "bool", "missing", "expired", "quarantined"])
def test_persistence_failure_prevents_model_post(failure):
    database = Database()
    gate = adapter(database)
    attempts = []

    def handler(outgoing):
        attempts.append(outgoing)
        assert outgoing.url.path == "/api/v2/cortex/threads"
        if failure in ("before", "after"):
            database.commit_failure = failure
        elif failure == "expired":
            database.clock += 31
        elif failure == "quarantined":
            database.rows[0]["STATE"] = "QUARANTINED"
        else:
            database.result_override = {"zero": [{"number of rows updated": 0}],
                "multiple": [{"number of rows updated": 2}], "bool": [{"number of rows updated": True}],
                "missing": []}[failure]
        return reply({"thread_id": 123})

    req = request(message=MESSAGE)
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with gate(req):
            with pytest.raises(admission.AdmissionError):
                gate.wrap_backend(transport(gate, client))(req)
            database.commit_failure = None
            database.result_override = None
    assert len(attempts) == 1
    assert database.rows[0]["STATE"] == "QUARANTINED"
    assert (database.rows[0]["RECONCILIATION_REF"] is not None) == (failure == "after")


@pytest.mark.parametrize("case", ["timeout", "over_limit", "bad_id", "bool_id", "wrapper", "redirect", "malformed"])
def test_thread_creation_failure_no_inference(case, caplog):
    database = Database()
    gate = adapter(database)
    attempts = []

    def handler(outgoing):
        attempts.append(outgoing)
        if case == "timeout":
            raise httpx.ReadTimeout(TOKEN)
        if case == "over_limit":
            return reply({"thread_id": 123, "private": "x" * 4096})
        if case == "malformed":
            return httpx.Response(200, stream=httpx.ByteStream(b'{"thread_id":'))
        return reply({"wrapper": {"metadata": {"thread_id": 123}},
            "bool_id": {"thread_id": True}, "bad_id": {"thread_id": "123"},
            "redirect": {"thread_id": 123}}[case], status=302 if case == "redirect" else 200)

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises((ScanTransportError, RawResponseBudgetError)) as caught:
            run(gate, transport(gate, client), request(message=MESSAGE))
    assert TOKEN not in "".join(traceback.format_exception(caught.value)) + caplog.text
    assert len(attempts) == 1
    assert database.rows[0]["STATE"] == "QUARANTINED"
    assert database.rows[0]["RECONCILIATION_REF"] is None


@pytest.mark.parametrize("messages", [[], [{"role": "assistant", "status": "completed", "content": [{"type": "text", "text": "x"}]}],
    json.loads(MESSAGE) * 2])
def test_new_thread_requires_exactly_one_user_without_network(messages):
    database = Database()
    gate = adapter(database)
    with httpx.Client(transport=httpx.MockTransport(lambda _: pytest.fail("No HTTP allowed"))) as client:
        with pytest.raises(ScanTransportError):
            run(gate, transport(gate, client), request(message=json.dumps(messages)))


@pytest.mark.parametrize("verified_payload", [False, True])
def test_model_timeout_preserves_reference_get_only_recovery_without_release(verified_payload):
    database = Database()
    gate = adapter(database)
    attempts = []
    captured = []
    original = gate.store.record_reconciliation

    def record(permit, reference):
        captured.append(permit)
        original(permit, reference)

    gate.store.record_reconciliation = record

    def handler(outgoing):
        attempts.append((outgoing.method, str(outgoing.url)))
        if outgoing.method == "GET":
            if verified_payload:
                data = thread_fixture()
                data["metadata"]["thread_id"] = 123
                return reply(data)
            return reply({"metadata": {"thread_id": 123}, "messages": [{"message_id": 2, "parent_id": 1,
                "role": "assistant", "message_type": "conversation", "message_payload": '{"status":"completed"}'}]})
        if outgoing.url.path == "/api/v2/cortex/threads":
            return reply({"thread_id": 123})
        raise httpx.ReadTimeout(TOKEN)

    req = request(message=MESSAGE)
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        backend = transport(gate, client)
        with pytest.raises(ScanTransportError):
            run(gate, backend, req)
        before = deepcopy(database.rows)
        start_sessions = len(database.sessions)
        observation = backend.recover_thread(captured[0], req)
        assert observation.reference.thread_id == 123
        if verified_payload:
            assert observation.assistant_message_ids == (ASSISTANT_ID,)
            assert observation.terminal == ThreadTerminalEvidence(123, USER_ID, ASSISTANT_ID, ThreadTerminalStatus.COMPLETED)
        else:
            assert observation.assistant_message_ids == (2,)
            assert observation.terminal is None  # Missing matched root and structured v2 role.
        assert all(sql.startswith("SELECT") for session in database.sessions[start_sessions:]
                   for sql, _ in session.commands)
        assert database.rows == before
    assert [method for method, _ in attempts] == ["POST", "POST", "GET"]
    assert attempts[-1][1] == "https://test_org-test_account.snowflakecomputing.com/api/v2/cortex/threads/123?page_size=100"


@pytest.mark.parametrize("auth_mode", ["oauth_bearer", "snowflake_token"])
def test_create_run_recover_require_static_user_agent_without_client_credentials(auth_mode):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    captured, sent = [], []
    original = gate.store.record_reconciliation

    def record(permit, reference):
        captured.append(permit)
        original(permit, reference)

    gate.store.record_reconciliation = record
    agent = SnowflakeAgentClient(TOKEN, host="test_org-test_account.snowflakecomputing.com",
                                role="CALLER", auth_mode=auth_mode)
    expected = {key.lower(): value for key, value in agent._build_headers().items()}
    expected.update({"user-agent": AUTOMAP_USER_AGENT, "accept-encoding": "identity"})

    def handler(outgoing):
        sent.append(outgoing)
        if not outgoing.headers.get("User-Agent"):
            return reply({"code": "391903"}, status=400)
        actual = dict(outgoing.headers)
        assert actual.pop("host") == "test_org-test_account.snowflakecomputing.com"
        if outgoing.method == "POST":
            assert actual.pop("content-length") == str(len(outgoing.content))
        assert actual == expected
        assert len(outgoing.headers.multi_items()) == len(outgoing.headers)
        if outgoing.method == "GET":
            return reply({"metadata": {"thread_id": 123}, "messages": []})
        if outgoing.url.path == "/api/v2/cortex/threads":
            assert outgoing.content == b"{}"
            return reply({"thread_id": 123})
        raise httpx.ReadTimeout("Model completion unknown")

    with httpx.Client(transport=httpx.MockTransport(handler),
            headers={"User-Agent": "untrusted-client-agent", "Authorization": "wrong",
                     "X-Other-Caller": "wrong", "Proxy-Authorization": "wrong"},
            cookies={"session": "wrong"}, auth=("wrong", "credential"),
            params={"agent": "wrong"}, follow_redirects=True) as client:
        backend = SnowflakeScanTransport(agent_client=agent, http_client=client,
            config=ScanTransportConfig(AGENT, 120_000), admission=gate)
        with pytest.raises(ScanTransportError):
            run(gate, backend, req)
        before = deepcopy(database.rows)
        assert backend.recover_thread(captured[0], req).terminal is None
        assert database.rows == before
    assert [outgoing.method for outgoing in sent] == ["POST", "POST", "GET"]
    assert all("agent=" not in str(outgoing.url) for outgoing in sent)
    assert database.rows[0]["STATE"] == "QUARANTINED"


@pytest.mark.parametrize("changed", ["job", "caller", "epoch", "fence", "owner", "snapshot", "message", "agent", "hash", "untracked"])
def test_wrong_recovery_scope_rejected_before_get(changed):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    permit = gate.store.try_claim(IDENTITY)
    reference = admission.ThreadReference(123, AGENT, admission.request_digest(req))
    gate.store.record_reconciliation(permit, reference)
    gate.store.quarantine(permit)
    if changed in ("job", "caller"):
        permit = replace(permit, identity=replace(permit.identity, **{changed + "_id": "wrong"}))
    elif changed == "epoch":
        permit = replace(permit, pool_epoch="wrong")
    elif changed == "fence":
        permit = replace(permit, fence=999)
    elif changed == "owner":
        permit = replace(permit, owner="wrong")
    elif changed == "snapshot":
        req = replace(req, scope=replace(req.scope, snapshot_id="wrong"))
    elif changed == "message":
        req = replace(req, message=MESSAGE + " ")
    elif changed == "untracked":
        database.rows[0]["RECONCILIATION_REF"] = None
    else:
        reference = replace(reference, **({"agent_fqn": "DB.SC.OTHER"} if changed == "agent" else {"request_digest": "0" * 64}))
        database.rows[0]["RECONCILIATION_REF"] = reference.serialize()
    before = deepcopy(database.rows)
    with httpx.Client(transport=httpx.MockTransport(lambda _: pytest.fail("Wrong scope made HTTP"))) as client:
        with pytest.raises(admission.AdmissionError):
            transport(gate, client).recover_thread(permit, req)
    assert database.rows == before


@pytest.mark.parametrize("payload", [[], [{"message_id": 1, "parent_id": 0, "role": "user", "message_type": "conversation", "message_payload": "x"}],
    [{"message_id": 2, "parent_id": 1, "role": "assistant", "message_type": "conversation", "message_payload": "cancelled"}]])
def test_empty_user_only_or_assistant_cancel_text_not_terminal(payload):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    permit = gate.store.try_claim(IDENTITY)
    gate.store.record_reconciliation(permit, admission.ThreadReference(123, AGENT, admission.request_digest(req)))
    gate.store.quarantine(permit)
    with httpx.Client(transport=httpx.MockTransport(lambda _: reply({"metadata": {"thread_id": 123}, "messages": payload}))) as client:
        assert transport(gate, client).recover_thread(permit, req).terminal is None
    assert database.rows[0]["STATE"] == "QUARANTINED"


@pytest.mark.parametrize("at", ["created", "committed", "model"])
def test_cancellation_keeps_unknown_call_held_no_extra_model_post(at):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    attempts = []
    original = gate.store.record_reconciliation

    def record(permit, reference):
        original(permit, reference)
        if at == "committed":
            req._cancel.set()
    gate.store.record_reconciliation = record

    def handler(outgoing):
        attempts.append(outgoing)
        if outgoing.url.path == "/api/v2/cortex/threads":
            if at == "created":
                req._cancel.set()
            return reply({"thread_id": 123})
        req._cancel.set()
        return reply({})

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(ScanStopped):
            run(gate, transport(gate, client), req)
    assert len(attempts) == (2 if at == "model" else 1)
    assert database.rows[0]["STATE"] == "QUARANTINED"


def test_reference_write_once_and_retired_dispatcher_required():
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    reference = admission.ThreadReference(123, AGENT, "0" * 64)
    pool.record_reconciliation(permit, reference)
    with pytest.raises(admission.StalePermit):
        pool.record_reconciliation(permit, replace(reference, thread_id=456))
    assert pool.read_reconciliation(permit) == reference
    with pytest.raises(admission.AdmissionError):
        pool.reconcile_terminal(permit, admission.Completion.FAILED, evidence_ref="audited", retired_dispatcher=False)
    assert database.rows[0]["STATE"] == "HELD"


def test_long_reference_rejected_without_truncation():
    with pytest.raises(ValueError):
        admission.ThreadReference(123, "DB.SC." + "A" * 200, "0" * 64)


@pytest.mark.parametrize("case", ["wrong_thread", "payload_object", "duplicate", "eof", "encoding", "oversize", "status"])
def test_recovery_malformed_or_nonterminal_get_never_releases(case):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    permit = gate.store.try_claim(IDENTITY)
    gate.store.record_reconciliation(permit, admission.ThreadReference(123, AGENT, admission.request_digest(req)))
    gate.store.quarantine(permit)
    message = {"message_id": 2, "parent_id": 1, "role": "assistant", "message_type": "conversation",
               "message_payload": "result"}
    data = {"metadata": {"thread_id": 123}, "messages": [message]}
    if case == "wrong_thread":
        data["metadata"]["thread_id"] = 456
    if case == "payload_object":
        message["message_payload"] = {"status": "completed"}
    if case == "duplicate":
        data["messages"].append(message)

    def handler(outgoing):
        assert outgoing.method == "GET"
        if case == "eof":
            return httpx.Response(200, stream=httpx.ByteStream(b'{"metadata":'))
        if case == "encoding":
            return httpx.Response(200, headers={"Content-Encoding": "gzip"}, stream=httpx.ByteStream(b"private"))
        if case == "oversize":
            return reply({"private": "x" * 120_001})
        return reply(data, status=503 if case == "status" else 200)

    before = deepcopy(database.rows)
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(ScanTransportError):
            transport(gate, client).recover_thread(permit, req)
    assert database.rows == before


def test_suppressed_reference_commit_failure_cannot_dispatch():
    from contextlib import contextmanager
    database = Database()

    @contextmanager
    def suppressing():
        try:
            with database.factory() as session:
                yield session
        except OSError:
            pass

    gate = admission.ScanCallAdmission(store(database, session_factory=suppressing), job_id="job", caller_id="caller")
    req = request(message=MESSAGE)
    calls = []

    def handler(outgoing):
        calls.append(outgoing)
        database.commit_failure = "after"
        return reply({"thread_id": 123})

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with gate(req):
            with pytest.raises(admission.AdmissionUnavailable):
                gate.wrap_backend(transport(gate, client))(req)
            database.commit_failure = None
    assert len(calls) == 1 and database.rows[0]["RECONCILIATION_REF"] is not None
    assert database.rows[0]["STATE"] == "QUARANTINED"


def test_two_legacy_untracked_quarantines_never_recycled():
    database = Database()
    gate = adapter(database)
    for _ in range(2):
        gate.store.quarantine(gate.store.try_claim(IDENTITY))
    database.clock += 1_000_000
    before = deepcopy(database.rows)
    with httpx.Client(transport=httpx.MockTransport(lambda _: pytest.fail("No thread or model creation"))) as client:
        with pytest.raises(ScanStopped):
            run(gate, transport(gate, client), request(seconds=0.02, message=MESSAGE))
    assert database.rows == before


def test_diagnostic_collection_cannot_write_or_mask_terminal_response(monkeypatch):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)

    def handler(outgoing):
        if outgoing.url.path == "/api/v2/cortex/threads":
            return reply({"thread_id": 123})
        return reply({"role": "assistant", "status": "completed", "content": [{"type": "text", "text": "{}"}]})

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        backend = transport(gate, client)
        extract = backend._extract

        def checked_extract(*args):
            # Any store work after receipt must be outside transport, on gate exit.
            database.fail_update = True
            result = extract(*args)
            req._cancel.clear()
            return result

        monkeypatch.setattr(backend, "_extract", checked_extract)
        with gate(req):
            assert gate.wrap_backend(backend)(req) == "{}"
            events = gate.diagnostics_for(req)
            assert [event.operation.value for event in events] == ["thread_create", "model_run", "model_run"]
            assert all(len(session.commands) > 0 for session in database.sessions)
            database.fail_update = False
    assert database.rows[0]["STATE"] == "FREE"


def test_reference_persistence_consumes_original_deadline():
    import time
    database = Database()
    gate = adapter(database)
    req = request(seconds=0.08, message=MESSAGE)
    original = gate.store.record_reconciliation
    attempts = []

    def record(permit, reference):
        original(permit, reference)
        time.sleep(0.1)

    gate.store.record_reconciliation = record

    def handler(outgoing):
        attempts.append(outgoing)
        return reply({"thread_id": 123})

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(ScanStopped):
            run(gate, transport(gate, client), req)
    assert len(attempts) == 1 and database.rows[0]["RECONCILIATION_REF"] is not None
    assert database.rows[0]["STATE"] == "QUARANTINED"


@pytest.mark.parametrize("field,value", [("owner", "wrong"), ("fence", 999), ("pool_epoch", "wrong"),
    ("account_namespace", "OTHER.ACCOUNT"), ("identity", replace(IDENTITY, job_id="wrong")),
    ("identity", replace(IDENTITY, generation="wrong")), ("identity", replace(IDENTITY, caller_id="wrong")),
    ("identity", replace(IDENTITY, shard_id="wrong"))])
def test_reference_write_rejects_wrong_ownership_scope(field, value):
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    before = deepcopy(database.rows)
    with pytest.raises(admission.StalePermit):
        pool.record_reconciliation(replace(permit, **{field: value}), admission.ThreadReference(123, AGENT, "0" * 64))
    assert database.rows == before


def test_copied_context_cannot_reuse_backend_after_admission_exit():
    from contextvars import copy_context
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    with gate(req):
        copied = copy_context()
        assert gate.wrap_backend(lambda _: "done")(req) == "done"
    with pytest.raises(admission.AdmissionError):
        copied.run(gate.wrap_backend(lambda _: pytest.fail("Reused dispatch")), req)


def test_old_lifecycle_cannot_write_during_new_admission():
    database = Database()
    gate = adapter(database)
    captured = []
    first = request(message=MESSAGE)

    def backend(req):
        captured.append(gate.bind_lifecycle(req))
        with pytest.raises(admission.AdmissionError):
            gate.bind_lifecycle(req)
        return "done"

    run(gate, backend, first)
    second = request(message=MESSAGE)
    with gate(second):
        with pytest.raises(admission.AdmissionError):
            captured[0].record_reconciliation(admission.ThreadReference(123, AGENT, admission.request_digest(first)))
        assert gate.wrap_backend(lambda _: "done")(second) == "done"


def test_new_sql_contract_parses_offline():
    import sqlglot
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    pool.record_reconciliation(permit, admission.ThreadReference(123, AGENT, "0" * 64))
    pool.read_reconciliation(permit)
    for session in database.sessions:
        for sql, params in session.commands:
            sqlglot.parse_one(sql, dialect="snowflake")
            assert sql.count("?") == len(params)


@pytest.mark.parametrize("fail_at", ["thread", "model"])
def test_timeout_diagnostics_keep_operation_and_do_not_reuse_thread_http_id(fail_at):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    provider_id = "12fcb8bb-d91e-491a-ae30-6cf934017462"

    def handler(outgoing):
        if fail_at == "thread" or outgoing.url.path.endswith(":run"):
            raise httpx.ReadTimeout(TOKEN)
        return httpx.Response(200, headers={"X-Request-Id": provider_id},
                              stream=httpx.ByteStream(b'{"thread_id":123}'))

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with gate(req):
            with pytest.raises(ScanTransportError):
                gate.wrap_backend(transport(gate, client))(req)
            events = gate.diagnostics_for(req)
            assert events[-1].operation.value == ("thread_create" if fail_at == "thread" else "model_run")
            assert events[-1].request_id is None
            assert events[-1].http_status is None
            if fail_at == "model":
                assert events[0].request_id == provider_id


# Live-shaped envelope supplied from the independently verified synthetic thread;
# only its schema/IDs are reproduced here, never a live account call.
THREAD_ID = 6185696905
USER_ID = 405384784538118
ASSISTANT_ID = 405384784534178


def thread_fixture(*, status="completed", user_status=True):
    user_payload = dict(json.loads(MESSAGE)[0], schema_version="v2", tags={})
    if not user_status:
        del user_payload["status"]
    assistant_payload = {"role": "assistant", "schema_version": "v2", "status": status,
                         "tags": {}, "content": [{"type": "text", "text": "synthetic result"}]}
    return {"metadata": {"thread_id": THREAD_ID, "status": "IDLE"}, "messages": [
        {"message_id": ASSISTANT_ID, "parent_id": USER_ID, "role": "assistant",
         "request_id": "12fcb8bb-d91e-491a-ae30-6cf934017462", "agent": {},
         "is_compressed": True, "compression_alg": "opaque", "message_type": "conversation",
         "message_payload": json.dumps(assistant_payload)},
        {"message_id": USER_ID, "parent_id": 0, "role": "user", "request_id": "opaque",
         "agent": {}, "is_compressed": True, "compression_alg": "opaque",
         "message_type": "conversation", "message_payload": json.dumps(user_payload)}]}


def recover_fixture(data, *, req=None):
    database = Database()
    gate = adapter(database)
    req = req or request(message=MESSAGE)
    permit = gate.store.try_claim(IDENTITY)
    reference = admission.ThreadReference(THREAD_ID, AGENT, admission.request_digest(req))
    gate.store.record_reconciliation(permit, reference)
    gate.store.quarantine(permit)
    before = deepcopy(database.rows)
    sessions = len(database.sessions)
    attempts = []

    def handler(outgoing):
        attempts.append(outgoing)
        assert outgoing.method == "GET"
        assert outgoing.url.path == f"/api/v2/cortex/threads/{THREAD_ID}"
        assert dict(outgoing.url.params) == {"page_size": "100"}
        assert outgoing.headers["Authorization"] == "Bearer " + TOKEN
        return reply(data)

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        observation = transport(gate, client).recover_thread(permit, req)
    assert len(attempts) == 1
    assert database.rows == before
    assert all(sql.startswith("SELECT") for session in database.sessions[sessions:] for sql, _ in session.commands)
    return observation


@pytest.mark.parametrize("status", list(ThreadTerminalStatus))
@pytest.mark.parametrize("user_status", [True, False])
def test_structured_live_shape_returns_typed_terminal_without_release(status, user_status):
    observation = recover_fixture(thread_fixture(status=status.value, user_status=user_status))
    assert observation.terminal == ThreadTerminalEvidence(THREAD_ID, USER_ID, ASSISTANT_ID, status)
    assert observation.terminal.source is ThreadEvidenceSource.STRUCTURED_V2_PAYLOAD
    assert observation.terminal.run_id == f"{THREAD_ID}-{USER_ID}"
    assert observation.assistant_message_ids == (ASSISTANT_ID,)


@pytest.mark.parametrize("payload", [
    "completed", '"completed"', '"{\\"role\\":\\"assistant\\",\\"status\\":\\"completed\\"}"',
    '{"role":"assistant","status":"completed"}', '{"schema_version":"v2","status":"completed"}',
    '{"schema_version":"v1","role":"assistant","status":"completed","content":[]}',
    '{"schema_version":"v2","role":"user","status":"completed","content":[]}',
    '{"schema_version":"v2","role":"assistant","content":[]}',
    '{"schema_version":"v2","role":"assistant","status":"completed","status":"error","content":[]}',
    '{"schema_version":"v2","role":"assistant","status":"completed","content":[{"x":1,"x":2}]}',
    '{"schema_version":"v2","role":"assistant","status":"completed","content":[],"tags":NaN}',
    '{"schema_version":"v2","role":"assistant","status":"completed","content":null}',
    '{"schema_version":"v2","role":"assistant","status":"completed","content":[]',
    "H4sIAAAAAAAA/w==", "\u0000\u001f\u008bcompressed", "[" * 1100 + "]" * 1100,
])
def test_prose_malformed_or_compressed_payload_never_terminal(payload):
    data = thread_fixture()
    data["messages"][0]["message_payload"] = payload
    assert recover_fixture(data).terminal is None


@pytest.mark.parametrize("status", [None, True, 1, {}, [], "COMPLETED", "complete", "failed", "running", "IDLE", ""])
def test_status_allowlist_only_not_idle_or_error_content(status):
    data = thread_fixture(status=status)
    payload = json.loads(data["messages"][0]["message_payload"])
    payload["content"] = [{"type": "text", "text": '{"status":"completed"}'}]
    payload["error"] = {"status": "error"}
    data["messages"][0]["message_payload"] = json.dumps(payload)
    assert recover_fixture(data).terminal is None


@pytest.mark.parametrize("case", ["text", "trim", "extra_block", "block_extra", "block_type", "missing_content",
    "extra_key", "status_null", "status_running", "role", "schema", "duplicate", "prose", "block_order"])
def test_root_match_allows_no_semantic_message_changes(case):
    data = thread_fixture()
    user = data["messages"][1]
    payload = json.loads(user["message_payload"])
    if case == "text":
        payload["content"][0]["text"] = "different"
    elif case == "trim":
        payload["content"][0]["text"] += " "
    elif case == "extra_block":
        payload["content"].append({"type": "text", "text": ""})
    elif case == "block_extra":
        payload["content"][0]["extra"] = "x"
    elif case == "block_type":
        payload["content"][0]["type"] = "thinking"
    elif case == "missing_content":
        del payload["content"]
    elif case == "extra_key":
        payload["extra"] = "x"
    elif case.startswith("status_"):
        payload["status"] = None if case == "status_null" else "running"
    elif case == "role":
        payload["role"] = "assistant"
    elif case == "schema":
        payload["schema_version"] = "v1"
    elif case == "block_order":
        payload["content"] = [{"type": "text", "text": "second"}] + payload["content"]
    user["message_payload"] = json.dumps(payload)
    if case == "duplicate":
        user["message_payload"] = user["message_payload"][:-1] + ',"role":"user"}'
    elif case == "prose":
        user["message_payload"] = "plain user text"
    assert recover_fixture(data).terminal is None


def test_root_semantic_comparison_preserves_exact_original_digest():
    data = thread_fixture(user_status=False)
    user = json.loads(data["messages"][1]["message_payload"])
    user["content"].append({"type": "text", "text": "second"})
    original = dict(json.loads(MESSAGE)[0], content=user["content"])
    message = json.dumps([original], ensure_ascii=True, indent=3)
    req = request(message=message)
    digest = admission.request_digest(req)
    # Different JSON key order/escaping/whitespace is not a semantic mutation.
    data["messages"][1]["message_payload"] = json.dumps(user, ensure_ascii=False, sort_keys=True)
    observation = recover_fixture(data, req=req)
    assert observation.terminal is not None
    assert observation.reference.request_digest == digest
    assert admission.request_digest(replace(req, message=message + " ")) != digest
    user["content"].reverse()
    data["messages"][1]["message_payload"] = json.dumps(user)
    assert recover_fixture(data, req=req).terminal is None


@pytest.mark.parametrize("case", ["no_root", "no_assistant", "parent_other_user", "parent_assistant",
    "root_parent", "root_null", "extra_root", "extra_branch", "extra_assistant", "compaction", "full_page"])
def test_missing_or_ambiguous_branch_never_terminal(case):
    data = thread_fixture()
    assistant, user = data["messages"]
    if case == "no_root":
        data["messages"] = [assistant]
    elif case == "no_assistant":
        data["messages"] = [user]
    elif case == "parent_other_user":
        assistant["parent_id"] = USER_ID + 1
    elif case == "parent_assistant":
        assistant["parent_id"] = ASSISTANT_ID
    elif case == "root_parent":
        user["parent_id"] = 42
    elif case == "root_null":
        user["parent_id"] = None
    elif case in ("extra_root", "extra_branch"):
        data["messages"].append(dict(user, message_id=42, parent_id=0 if case == "extra_root" else ASSISTANT_ID))
    elif case == "extra_assistant":
        data["messages"].append(dict(assistant, message_id=43))
    elif case == "compaction":
        assistant["message_type"] = "compaction"
    elif case == "full_page":
        data["messages"].extend(dict(assistant, message_id=index + 1) for index in range(98))
    assert recover_fixture(data).terminal is None


@pytest.mark.parametrize("change", ["fence", "job", "reference", "free"])
def test_valid_terminal_cannot_escape_post_get_scope_recheck(change):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    permit = gate.store.try_claim(IDENTITY)
    gate.store.record_reconciliation(permit, admission.ThreadReference(THREAD_ID, AGENT, admission.request_digest(req)))
    gate.store.quarantine(permit)

    def handler(outgoing):
        if change == "fence":
            database.rows[0]["FENCE"] += 1
        elif change == "job":
            database.rows[0]["JOB_ID"] = "other"
        elif change == "reference":
            database.rows[0]["RECONCILIATION_REF"] = admission.ThreadReference(777, AGENT, admission.request_digest(req)).serialize()
        else:
            database.rows[0]["STATE"] = "FREE"
        return reply(thread_fixture())

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(admission.AdmissionError):
            transport(gate, client).recover_thread(permit, req)


@pytest.mark.parametrize("status", list(ThreadTerminalStatus))
def test_terminal_evidence_requires_explicit_operator_retirement_to_reconcile(status):
    database = Database()
    gate = adapter(database)
    req = request(message=MESSAGE)
    permit = gate.store.try_claim(IDENTITY)
    gate.store.record_reconciliation(permit, admission.ThreadReference(THREAD_ID, AGENT, admission.request_digest(req)))
    gate.store.quarantine(permit)
    database.clock += 1_000_000  # Expiry alone cannot release or take over.
    with httpx.Client(transport=httpx.MockTransport(lambda _: reply(thread_fixture(status=status.value)))) as client:
        observation = transport(gate, client).recover_thread(permit, req)
    assert observation.terminal.status is status
    assert database.rows[0]["STATE"] == "QUARANTINED"
    completion = admission.Completion.SUCCEEDED if status is ThreadTerminalStatus.COMPLETED else admission.Completion.FAILED
    evidence_ref = f"{observation.terminal.source.value}:{observation.terminal.run_id}:{ASSISTANT_ID}:{status.value}"
    with pytest.raises(admission.AdmissionError):
        gate.store.reconcile_terminal(permit, completion, evidence_ref=evidence_ref, retired_dispatcher=False)
    assert database.rows[0]["STATE"] == "QUARANTINED"
    # Test-only trusted operator: production must establish dispatcher retirement
    # and persist an audit record before making this explicit call.
    gate.store.reconcile_terminal(permit, completion, evidence_ref=evidence_ref, retired_dispatcher=True)
    assert database.rows[0]["STATE"] == "FREE"
    assert database.rows[0]["COMPLETION"] == completion.value
    assert database.rows[0]["FENCE"] > permit.fence
    with pytest.raises(admission.StalePermit):
        gate.store.reconcile_terminal(permit, completion, evidence_ref=evidence_ref, retired_dispatcher=True)


def test_unpaired_managed_transport_never_creates_thread():
    database = Database()
    gate = adapter(database)
    with httpx.Client(transport=httpx.MockTransport(lambda _: pytest.fail("No HTTP"))) as client:
        with pytest.raises(admission.AdmissionError):
            transport(gate, client)(request(message=MESSAGE))


def test_native_user_row_without_optional_envelope_metadata_still_requires_exact_content():
    data = thread_fixture()
    user = next(m for m in data['messages'] if m['role'] == 'user')
    value = json.loads(user['message_payload'])
    value.pop('schema_version', None)
    value.pop('status', None)
    user['message_payload'] = json.dumps(value)
    observation = recover_fixture(data)
    assert observation.terminal is not None
    value['content'][0]['text'] += ' altered'
    user['message_payload'] = json.dumps(value)
    assert recover_fixture(data).terminal is None
