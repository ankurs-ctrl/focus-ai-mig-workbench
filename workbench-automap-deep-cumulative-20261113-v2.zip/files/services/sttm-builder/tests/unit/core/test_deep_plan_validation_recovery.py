import pytest
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage

from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
from app.agent_runtime.execution import ExecutionBudget
from app.agent_runtime.interface import RuntimeInvocation
from app.agent_runs.models import EffortLevel
from app.agent_tools.capability_registry import CapabilityRegistry, PlanValidationArguments
from app.migration_workflow.graph import build_migration_graph


class Model(FakeMessagesListChatModel):
    def bind_tools(self, tools, **kwargs):
        return self


def test_plan_tool_exposes_sql_step_contract_to_the_model():
    step = PlanValidationArguments.model_json_schema()["properties"]["plan"]["properties"]["execution_steps"]["items"]
    assert "mapping" in step["properties"]["query_kind"]["enum"]
    assert "preview" in step["properties"]["query_kind"]["enum"]
    assert step["properties"]["dynamic_sql"]["type"] == "boolean"
    assert "phase" in step["required"]


def test_three_rejected_plan_corrections_stop_before_another_model_turn():
    traces = []
    runtime = DeepAgentsRuntime(
        model=Model(responses=[AIMessage(content="unused")]),
        migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=128, tool_limit=600),
        trace=lambda event, *_args: traces.append(event),
    )

    def validate_migration_plan(**kwargs):
        return {"status": "needs_input", "summary": "Set query_kind and SQL.",
                "error_code": "planned_sql_required", "data": {"validation_errors": [
                    {"path": "execution_steps", "message": "Set query_kind and SQL."}]}}

    denied = runtime._registry._trace_early_refusals(validate_migration_plan)

    class RepeatingAgent:
        calls = 0

        def stream(self, _input, **kwargs):
            for _ in range(30):
                self.calls += 1
                denied(plan={})
                yield "values", {"messages": [AIMessage(content="Revising the plan.")],
                                 "todos": [{"content": "Validate plan", "status": "in_progress"}]}

    repeating = RepeatingAgent()
    runtime._agent = repeating
    result = runtime.invoke(RuntimeInvocation(
        run_id="plan-loop-regression", thread_id="plan-loop-regression",
        prompt="Plan first, then create the full draft mapping after approval.",
        effort=EffortLevel.MEDIUM, workflow_input={"run_mode": "plan", "intent": "NEW_MIGRATION_TASK"},
    ))
    assert repeating.calls == 3
    assert result.status == "NEEDS_REVIEW"
    assert "plan.validation_stalled" in traces
    assert runtime._workflow_result is None
    assert runtime._registry.validated_supervisor_plan is None
    assert result.workflow_state["review_items"][0]["details"]["attempts"] == 3


def test_successful_validation_clears_the_failure_boundary():
    registry = CapabilityRegistry(context_provider=lambda: {}, workflow_executor=lambda *_: {},
                                  workbench=None, budget=ExecutionBudget(model_limit=8, tool_limit=8))
    result = {"status": "needs_input", "error_code": "invalid_plan_contract"}

    def validate_migration_plan():
        return dict(result)

    wrapped = registry._trace_early_refusals(validate_migration_plan)
    wrapped()
    wrapped()
    assert registry.plan_validation_failure["attempts"] == 2
    result["status"] = "succeeded"
    wrapped()
    assert registry.plan_validation_failure is None


def test_verified_source_does_not_trigger_research_nudge_during_plan_assembly():
    traces = []
    runtime = DeepAgentsRuntime(
        model=Model(responses=[AIMessage(content="unused")]),
        migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=128, tool_limit=600),
        trace=lambda event, *_args: traces.append(event),
    )
    class AssemblingAgent:
        calls = 0
        stream_lengths = []
        def stream(self, _input, **kwargs):
            runtime._registry._prepared_plan_review = {
                "target_table": "DB.TGT.TARGET",
                "plan_candidate": {"source_preparation": {"driving_source": "DB.SRC.SOURCE"}},
                "unresolved": [],
            }
            self.stream_lengths.append(0)
            for _ in range(7):
                self.stream_lengths[-1] += 1
                self.calls += 1
                yield "values", {"messages": [AIMessage(content="Assembling the approval plan.")],
                                 "todos": [{"content": "Validate plan", "status": "in_progress"}]}
    agent = AssemblingAgent()
    runtime._agent = agent
    runtime.invoke(RuntimeInvocation(
        run_id="verified-source-plan", thread_id="verified-source-plan",
        prompt="Plan the full mapping from DB.SRC.SOURCE to DB.TGT.TARGET.",
        effort=EffortLevel.MEDIUM, workflow_input={"run_mode": "plan", "intent": "NEW_MIGRATION_TASK"},
    ))
    assert agent.stream_lengths
    assert all(length == 7 for length in agent.stream_lengths)
    assert "plan.source_research_nudged" not in traces


def test_plan_tool_exposes_decisions_and_nested_source_value_contracts():
    import json
    properties = PlanValidationArguments.model_json_schema()["properties"]["plan"]["properties"]
    decisions = properties["decisions"]["items"]["properties"]
    assert "mapping" not in decisions["subject"]["enum"]
    assert "source" in decisions["subject"]["enum"]
    bindings = properties["source_preparation"]["properties"]["value_bindings"]["items"]
    assert "user_prompt" in bindings["properties"]["source"]["enum"]
    assert "$ref" not in json.dumps(properties)
    assert properties["auto_map"]["properties"]["expected_coverage"]["anyOf"][0]["maximum"] == 1


def test_plan_tool_exposes_complete_mapping_candidate_shape():
    properties = PlanValidationArguments.model_json_schema()["properties"]["plan"]["properties"]
    candidate = properties["auto_map"]["properties"]["mapping_evidence"]["items"]
    assert candidate["required"] == ["target_column", "source_columns", "mapping_mode"]
    assert candidate["properties"]["source_columns"]["items"]["type"] == "string"


def test_explicit_singular_source_reference_is_canonicalized_without_replacing_plural():
    from app.agent_tools.capability_registry import _normalize_mapping_evidence
    singular = {"target_column": "ID", "source_table": "DB.S.SOURCE", "source_column": "ID"}
    explicit = {**singular, "source_columns": ["DB.S.OTHER.ID"]}
    result = _normalize_mapping_evidence([singular, explicit, {"source_column": {"expression": "made_up"}}])
    assert result[0]["source_columns"] == ["DB.S.SOURCE.ID"]
    assert "source_columns" not in singular
    assert result[1]["source_columns"] == ["DB.S.OTHER.ID"]
    assert "source_columns" not in result[2]


def test_trailing_source_and_target_labels_do_not_invert_scope():
    from app.agent_runs.prompt_scope import extract_prompt_targets
    prompt = 'Use exactly DB.SRC.SOURCE_TABLE as the source and DB.TGT.TARGET_TABLE as the target.'
    assert extract_prompt_targets(prompt) == ['DB.TGT.TARGET_TABLE']


def test_explicit_single_target_and_its_alias_reach_governed_handoff():
    runtime = DeepAgentsRuntime(
        model=Model(responses=[AIMessage(content="unused")]), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=16, tool_limit=30),
    )
    source = 'DB.SRC.SOURCE'
    target = 'DB.TGT.TARGET'
    runtime._registry.validate_prepared_plan = lambda: {"status": "succeeded"}
    calls = []
    def governed(_):
        calls.append('governed')
        runtime._workflow_result = {"status": "NEEDS_REVIEW", "assistant_message": "Paused before any draft write."}
    runtime._invoke_compiled_workflow = governed
    class Agent:
        def stream(self, _input, **kwargs):
            runtime._registry._prepared_plan_candidate = {"source_preparation": {"driving_source": source, "target_table": target}}
            runtime._registry._validated_supervisor_plan = dict(runtime._registry._prepared_plan_candidate)
            yield 'values', {"messages": [AIMessage(content='Plan validated.')],
                             "todos": [{"content": "Approval", "status": "in_progress"}]}
    runtime._agent = Agent()
    result = runtime.invoke(RuntimeInvocation(
        run_id='single-target-handoff', thread_id='single-target-handoff',
        prompt=f'Use exactly {source} as the source and {target} as the target.',
        effort=EffortLevel.MEDIUM,
        workflow_input={"intent": "NEW_MIGRATION_TASK", "run_mode": "plan",
                        "authorized_target_scope": [target], "requested_mappings": ['TARGET']},
    ))
    assert calls == ['governed']
    assert result.status == 'NEEDS_REVIEW'


def test_handoff_revalidates_the_repaired_plan_instead_of_old_evidence_candidate():
    registry = CapabilityRegistry(context_provider=lambda: {}, workflow_executor=lambda *_: {},
                                  workbench=None, budget=ExecutionBudget(model_limit=8, tool_limit=8))
    registry._prepared_plan_candidate = {"auto_map": {"mapping_evidence": []}}
    repaired = {"auto_map": {"mapping_evidence": [{"target_column": "ID", "source_columns": ["DB.S.T.ID"]}]}}
    registry._validated_supervisor_plan = repaired
    seen = []
    registry._plan_validator = lambda plan: seen.append(plan) or {"status": "succeeded"}
    assert registry.validate_prepared_plan()["status"] == "succeeded"
    assert seen == [repaired]


@pytest.mark.parametrize("before_question", [False, True, "lost_boundary"])
def test_lost_approval_checkpoint_ack_reemits_same_question_without_model_call(before_question):
    from langgraph.checkpoint.memory import InMemorySaver
    from app.migration_workflow.graph import DefaultWorkflowHandlers
    class InterruptedBoundarySaver(InMemorySaver):
        failed_once = False
        recovered = False
        def put(self, config, checkpoint, metadata, new_versions):
            values = checkpoint.get("channel_values", {})
            if before_question == "lost_boundary" and not self.recovered and (values.get("manifest") or self.failed_once):
                self.failed_once = True
                raise RuntimeError("simulated checkpoint acknowledgement loss")
            return super().put(config, checkpoint, metadata, new_versions)
    saver = InterruptedBoundarySaver()
    handlers = DefaultWorkflowHandlers()
    graph = build_migration_graph(handlers, checkpointer=saver)
    initial = {"run_id": "lost-ack", "thread_id": "lost-ack", "prompt": "Build the plan first",
               "actor_user_id": "user-1", "effective_role": "TEST_ROLE",
               "run_mode": "plan", "requested_mappings": ["Target"],
               "authorized_source_scope": ["DB.SRC.SOURCE"], "authorized_target_scope": ["DB.TGT.TABLE"],
               "supervisor_plan": {"normalized_intent": "Build Target", "_deep_supervisor_validated": True,
                                   "source_preparation": {"driving_source": "DB.SRC.SOURCE", "target_table": "DB.TGT.TABLE"},
                                   "auto_map": {"requested_mappings": ["Target"]}}}
    if before_question == "lost_boundary":
        with pytest.raises(RuntimeError, match="acknowledgement loss"):
            graph.invoke(initial, config={"configurable": {"thread_id": "lost-ack:workflow"}})
        snapshot = graph.get_state({"configurable": {"thread_id": "lost-ack:workflow"}})
        assert not snapshot.next
        assert any(task.result is not None for task in snapshot.tasks)
        saver.recovered = True
        first = {}
    else:
        first = graph.invoke(initial, config={"configurable": {"thread_id": "lost-ack:workflow"}},
                             interrupt_after=["authorize_scope"] if before_question else None)
        if not before_question:
            assert first.get('__interrupt__')
    runtime = DeepAgentsRuntime(model=Model(responses=[AIMessage(content='unused')]),
                               migration_graph=graph, checkpointer=saver,
                               budget=ExecutionBudget(model_limit=8, tool_limit=20))
    class ForbiddenModel:
        def stream(self, *_args, **_kwargs):
            raise AssertionError('Unanswered workflow review must not restart model research')
    runtime._agent = ForbiddenModel()
    restored = runtime.invoke(RuntimeInvocation(run_id='lost-ack', thread_id='lost-ack',
        prompt='Build the plan first', effort=EffortLevel.MEDIUM, workflow_input=initial, is_resume=True))
    assert restored.status == 'AWAITING_CONFIRMATION'
    assert restored.interrupt['category'] == 'plan_approval'
    if not before_question:
        assert restored.interrupt['action_digest'] == first['__interrupt__'][0].value['action_digest']
    assert restored.workflow_state.get('project_id') is None
    assert restored.model_calls_used == 0


def test_real_supervisor_middleware_stops_truncation_after_one_attempt():
    runtime = DeepAgentsRuntime(
        model=Model(responses=[AIMessage(content='partial decision', response_metadata={"finish_reason": "length"})]),
        migration_graph=build_migration_graph(), budget=ExecutionBudget(model_limit=16, tool_limit=30),
    )
    result = runtime.invoke(RuntimeInvocation(run_id='truncated', thread_id='truncated',
        prompt='Explain what you can do', effort=EffortLevel.LIGHT,
        workflow_input={"intent": "READ_ONLY_QA"}))
    assert result.status == 'NEEDS_REVIEW'
    assert result.model_calls_used == 1
    assert result.workflow_state['review_items'][0]['category'] == 'model_output_truncated'


def test_approved_pending_write_boundary_resumes_before_project_id_receipt():
    from types import SimpleNamespace
    called = []
    graph = SimpleNamespace(
        get_state=lambda _: SimpleNamespace(values={"run_id": "approved-boundary", "status": "EXECUTING", "approved_plan_hash": "saved-approved-hash"},
                                           next=(), interrupts=(), tasks=(SimpleNamespace(result={"approved_plan_hash": "saved-approved-hash"}),)),
        update_state=lambda *_args, **_kwargs: None,
        invoke=lambda value, **kwargs: called.append(value) or {"status": "NEEDS_REVIEW", "run_id": "approved-boundary"},
    )
    runtime = DeepAgentsRuntime(model=Model(responses=[AIMessage(content='unused')]), migration_graph=graph,
                               budget=ExecutionBudget(model_limit=8, tool_limit=20))
    runtime._active_invocation = RuntimeInvocation(run_id='approved-boundary', thread_id='approved-boundary',
                                                  prompt='Create the approved draft', effort=EffortLevel.MEDIUM,
                                                  workflow_input={}, is_resume=True)
    result = runtime._retry_approved_source_preparation(runtime._active_invocation)
    assert called == [None]
    assert result['status'] == 'NEEDS_REVIEW'


def test_join_resolution_returns_to_supervisor_before_business_drafts():
    from langgraph.checkpoint.memory import InMemorySaver
    from app.migration_workflow.graph import DefaultWorkflowHandlers
    class Handlers(DefaultWorkflowHandlers):
        def resolve_source_clarification(self, state, selected):
            return {"status": "succeeded", "supervisor_plan": state['supervisor_plan']}
        def create_project(self, state):
            raise AssertionError('A join decision cannot skip CTE/filter/value plan completion')
    graph = build_migration_graph(Handlers(), checkpointer=InMemorySaver())
    plan = {"_deep_supervisor_validated": True, "normalized_intent": "Create all requested transformations",
            "source_preparation": {"driving_source": "DB.SRC.SOURCE", "target_table": "DB.TGT.TABLE"},
            "auto_map": {"requested_mappings": ["Target"]}}
    result = graph.invoke({"run_id": "join-plan", "actor_user_id": "user-1", "effective_role": "TEST_ROLE",
                           "prompt": "Create the requested CTE, join, filter and firm value", "run_mode": "auto",
                           "authorized_source_scope": ["DB.SRC.SOURCE"], "authorized_target_scope": ["DB.TGT.TABLE"],
                           "requested_mappings": ["Target"], "supervisor_plan": plan,
                           "research_clarification": {"selected_source": "DB.SRC.SOURCE", "require_supervisor_completion": True}},
                          config={"configurable": {"thread_id": "join-plan"}})
    assert result['status'] == 'PLAN_REVISION_REQUIRED'
    assert result['plan_revision_request']['category'] == 'complete_requested_design'
    assert result.get('project_id') is None
    assert not result.get('approved_plan_hash')


def test_proposed_transformation_alias_survives_candidate_normalization():
    from app.agent_tools.capability_registry import _normalize_mapping_evidence
    candidate = {"target_column": "EMAIL_LOWER", "source_table": "DB.S.CUSTOMERS", "source_column": "EMAIL",
                 "transformation_rule": "LOWER(CUSTOMERS.EMAIL)"}
    result = _normalize_mapping_evidence([candidate])[0]
    assert result['transformation'] == 'LOWER(CUSTOMERS.EMAIL)'
    assert result['source_columns'] == ['DB.S.CUSTOMERS.EMAIL']
    assert 'transformation' not in candidate
    assert _normalize_mapping_evidence([{**candidate, 'transformation': 'LOWER(EMAIL)'}])[0]['transformation'] == 'LOWER(EMAIL)'


def test_source_design_aliases_preserve_cte_identity_and_do_not_invent_value_approval():
    from app.agent_tools.capability_registry import _normalize_source_preparation
    source = {"derived_sources": [{"cte_name": "active_customers", "base_table": "DB.S.CUSTOMERS",
                                   "sql": "SELECT * FROM DB.S.CUSTOMERS WHERE ACTIVE = TRUE", "is_driving": True}],
              "value_bindings": [{"name": "Firm", "source": "user_specified", "value": "TEST", "target_columns": ["FIRM_CODE"]}]}
    plain = _normalize_source_preparation(source)
    assert plain['derived_sources'][0]['name'] == 'active_customers'
    assert plain['derived_sources'][0]['base_source_tables'] == [{'database': 'DB', 'schema': 'S', 'table': 'CUSTOMERS'}]
    assert plain['derived_sources'][0]['is_driving_source'] is True
    assert plain['value_bindings'][0]['placeholder'] == '$Firm'
    assert plain['value_bindings'][0]['candidate_value'] == 'TEST'
    assert 'resolved_value' not in plain['value_bindings'][0]
    current = _normalize_source_preparation(source, prompt="Generate this mapping: SELECT 'TEST' AS FIRM_CODE FROM DB.S.CUSTOMERS")
    assert current['value_bindings'][0]['resolved_value'] == 'TEST'
    assert current['value_bindings'][0]['resolution_status'] == 'resolved'
    assert current['value_bindings'][0]['approval_state'] == 'approved'
    assert 'resolved_value' not in _normalize_source_preparation(source, prompt="SELECT 'OTHER' AS FIRM_CODE")['value_bindings'][0]
    assert 'resolved_value' not in _normalize_source_preparation(source, prompt="SELECT 'TEST' AS OTHER_FIELD")['value_bindings'][0]


def test_source_graph_description_normalizes_only_to_the_same_verified_driver():
    from app.agent_tools.capability_registry import _canonical_source_decision
    source = {'driving_source': 'DB.S.CUSTOMERS', 'supporting_sources': ['DB.S.STATUSES']}
    assert _canonical_source_decision('DB.S.CUSTOMERS (driving), DB.S.STATUSES (supporting)', source) == 'DB.S.CUSTOMERS'
    assert _canonical_source_decision('DB.S.OTHER', source) == 'DB.S.OTHER'
    assert _canonical_source_decision('DB.S.STATUSES', source) == 'DB.S.STATUSES'
    assert _canonical_source_decision('DB.S.CUSTOMERS and DB.S.UNVERIFIED', source) == 'DB.S.CUSTOMERS and DB.S.UNVERIFIED'


def test_resume_revalidates_last_saved_structured_plan_without_research_or_claimed_success():
    from types import SimpleNamespace
    traces = []
    runtime = DeepAgentsRuntime(model=Model(responses=[AIMessage(content='unused')]),
        migration_graph=build_migration_graph(), budget=ExecutionBudget(model_limit=8, tool_limit=20),
        trace=lambda event, *_: traces.append(event))
    submission = {'normalized_intent': 'Complete the requested draft', 'source_preparation': {'driving_source': 'DB.S.SOURCE'}}
    runtime._agent = SimpleNamespace(get_state=lambda _: SimpleNamespace(values={'messages': [AIMessage(content='', tool_calls=[
        {'name': 'validate_migration_plan', 'args': {'plan': submission}, 'id': 'saved', 'type': 'tool_call'}])]}))
    seen = []
    def validate(payload):
        seen.append(payload['plan'])
        return {'status': 'needs_input', 'error_code': 'still_missing_source'}
    runtime._registry.tools = lambda: [SimpleNamespace(name='validate_migration_plan', invoke=validate)]
    invocation = RuntimeInvocation(run_id='saved-plan', thread_id='saved-plan', prompt='Continue the requested draft',
                                   effort=EffortLevel.MEDIUM, workflow_input={}, is_resume=True)
    assert runtime._revalidate_saved_plan_submission(invocation, {}) is False
    assert seen == [submission]
    assert runtime._workflow_result is None
    assert runtime._budget.snapshot()[0] == 0
    runtime._registry.tools = lambda: [SimpleNamespace(name='validate_migration_plan', invoke=lambda payload: {'status': 'succeeded'})]
    assert runtime._revalidate_saved_plan_submission(invocation, {}) is True
    assert traces == ['plan.submission.revalidated', 'plan.submission.revalidated']
    assert runtime._workflow_result is None  # Success still needs the governed executor's receipts.


def test_native_driving_cte_alias_does_not_override_canonical_flag():
    from app.agent_tools.capability_registry import _normalize_source_preparation
    result = _normalize_source_preparation({'derived_sources': [
        {'name': 'active_customers', 'used_as_driving_source': True},
        {'name': 'active_alias', 'use_as_driving_source': True},
        {'name': 'other', 'is_driving_source': False, 'used_as_driving_source': True}]})
    assert result['derived_sources'][0]['is_driving_source'] is True
    assert result['derived_sources'][1]['is_driving_source'] is True
    assert result['derived_sources'][2]['is_driving_source'] is False
