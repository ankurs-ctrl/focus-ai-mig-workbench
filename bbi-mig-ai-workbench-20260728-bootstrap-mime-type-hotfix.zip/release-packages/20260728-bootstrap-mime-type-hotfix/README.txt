Bootstrap progression hotfix (revision 3)

Copy the three files in this ZIP into the client repository root, allowing them
to overwrite the existing files:

  infra/snowflake/migrations/20260723_warehouse_routing_conversation_artifacts.sql
  infra/snowflake/fir_system/streams/fir_streams.sql
  scripts/bootstrap_sttm_metadata_infra.py

Then rerun the same command:

  .\scripts\bootstrap_sttm_metadata_infra.ps1 -EnvFile ".\infra\snowflake\env\client.env"

The bootstrap is additive and idempotent. Statements completed before the
failure do not need to be rolled back.

Revision 2 checks the existing TBL_AGENT_ARTIFACTS columns with DESC TABLE
before executing the MIME_TYPE ALTER. This replaces the earlier quote-only
workaround, which was not sufficient in upgraded client schemas.

Revision 3 also creates semantic change streams on the canonical raw registry
tables in the STTM metadata namespace. The configured semantic-read namespace
can contain LATEST_* views and must not be used as the backing table for
Snowflake streams.
