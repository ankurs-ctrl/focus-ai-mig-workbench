"""Read-only SQL relation validation shared by mapping and Deep previews."""
from __future__ import annotations
import hashlib
from sqlglot import exp, parse
from sqlglot.optimizer.scope import traverse_scope


def sql_hash(sql: str) -> str:
    return hashlib.sha256(sql.strip().rstrip(';').encode()).hexdigest()


def is_single_read_only_query(sql: str) -> bool:
    """Check whether historical SQL can be shown as one executable plan query."""
    try:
        statements = parse(sql, read='snowflake')
    except Exception:
        return False
    if len(statements) != 1 or not isinstance(statements[0], exp.Query):
        return False
    forbidden = (exp.Insert, exp.Update, exp.Delete, exp.Merge, exp.Create,
                 exp.Alter, exp.Drop, exp.Command, exp.Into, exp.Lock)
    return not any(isinstance(node, forbidden) for node in statements[0].walk())


def validate_relations(sql: str, allowed_tables: set[str], *, allowed_functions: set[str] | None = None) -> list[str]:
    statements = parse(sql, read='snowflake')
    if len(statements) != 1 or not isinstance(statements[0], exp.Query):
        raise ValueError('Exactly one SELECT or WITH query is required')
    query=statements[0]
    forbidden=(exp.Insert,exp.Update,exp.Delete,exp.Merge,exp.Create,exp.Alter,exp.Drop,exp.Command,exp.Into,exp.Lock)
    if any(isinstance(node,forbidden) for node in query.walk()):
        raise ValueError('DDL, DML, CALL and command SQL are prohibited')
    approved_functions = {name.upper() for name in allowed_functions or set()}
    for node in query.walk():
        if isinstance(node, exp.Anonymous) and node.name.upper() not in approved_functions:
            raise PermissionError(f"Unrecognized or user-defined function requires deployment authorization: {node.name}")
        if isinstance(node, exp.Dot) and isinstance(node.expression, exp.Func):
            raise PermissionError("Qualified function calls are outside the read-only preview contract")
    # No external/table functions or stage reads can be smuggled through a SELECT.
    allowed={value.replace('"','').upper() for value in allowed_tables}
    physical=set()
    for scope in traverse_scope(query):
        for _,source in scope.selected_sources.values():
            if not isinstance(source,exp.Table):
                continue  # resolved CTE/subquery scope
            if not isinstance(source.this,exp.Identifier) or not source.catalog or not source.db:
                raise PermissionError('Physical relations must be fully qualified authorized tables')
            fqn='.'.join([source.catalog,source.db,source.name]).upper()
            if fqn not in allowed:
                raise PermissionError(f'Relation must be authorized or discovered in the selected source scope: {fqn}')
            physical.add(fqn)
    if any(isinstance(n, (exp.TableFromRows, exp.UDTF)) for n in query.walk()):
        raise PermissionError("Table functions and external stage reads are prohibited")
    if any(isinstance(n,exp.Table) and not isinstance(n.this,exp.Identifier) for n in query.walk()):
        raise PermissionError('Table functions and external stage reads are prohibited')
    return sorted(physical)
