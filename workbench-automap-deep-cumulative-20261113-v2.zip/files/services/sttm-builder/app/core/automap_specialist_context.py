"""Bounded exact evidence reads for large transformation packets.

The existing selected source/rule identities remain explicit. Oversized bodies
are archived/read verbatim in child blocks, on the same guarded runtime. Quotes
are an index: resulting expressions require review, never automatic acceptance.
"""
from copy import deepcopy
from app.core.automap_evidence_blocks import EvidenceBlocks, EvidenceBlockError, MAX_EVIDENCE_REVIEW_CALLS
from app.core.automap_input_budget import input_limits, wire_messages, wire_text
from app.core.automap_retrieval import digest, encoded
from app.core.automap_transform import transformation_packet
from app.schema.sttm_builder import STTMAgentRequestEnvelope


class TransformationPreparationError(ValueError):
    """A known pre-submission failure; never wraps transport/model execution."""
    def __init__(self, cause):
        import traceback
        allowed = {'Expected one exact column reference', 'Unknown transformation source column', 'Ambiguous transformation source binding'}
        message = str(cause) if str(cause) in allowed else 'Current bindings or packet shape could not be prepared.'
        self.diagnostic = {'message': message, 'code': 'transformation_preparation_failed', 'error_type': type(cause).__name__,
            'locations': [{'file': frame.filename.rsplit('/', 1)[-1], 'function': frame.name, 'line': frame.lineno}
                          for frame in traceback.extract_tb(cause.__traceback__)[-8:]]}
        super().__init__('Current transformation bindings or packet could not be prepared; no model request was submitted.')


def specialist_messages(service, req, runtime):
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    try:
        return _specialist_messages(service, req, runtime)
    except AgentPayloadBudgetError:
        raise
    except (ValueError, KeyError, TypeError) as error:
        raise TransformationPreparationError(error) from error


def _specialist_messages(service, req, runtime):
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    try:
        projected = service.project_agent_payload(req, service._settings)
        return [{'role': 'user', 'content': [{'type': 'text', 'text': projected.text}]}], None
    except AgentPayloadBudgetError:
        if req.meta.get('automap_generation_policy') == 'draft-v3':
            from app.core.automap_input_budget import fit_optional_history
            from app.core.automap_retrieval import factor_exact_records, factor_exact_text_lines
            raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode='json', exclude_none=True)
            packet = transformation_packet(raw, factor=False)
            chars, size = input_limits(service._settings)
            def render(value):
                value = factor_exact_text_lines(factor_exact_records(value))
                return wire_messages([{'role': 'user', 'content': [{'type': 'text', 'text': encoded(value)}]}])
            messages, coverage = fit_optional_history(packet, render, max_chars=chars, max_bytes=size)
            return messages, {'context_budget': coverage}
        pass
    runtime.check_active()
    raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode='json', exclude_none=True)
    exact = transformation_packet(raw, factor=False)
    chars, size = input_limits(service._settings)
    blocks = EvidenceBlocks(digest(exact), chars, size, targets=[item.target_attribute for item in req.data.attributes])
    blocks.enabled = True

    preview = False

    def render():
        blocks.begin(preview=preview)
        packet = {key: deepcopy(exact[key]) for key in ('request_id', 'operation') if key in exact}
        packet['context'] = blocks.project(exact['context'], path=('context',))
        packet['data'] = {key: blocks.project(value, path=('data', key)) for key, value in exact['data'].items() if key != 'attributes'}
        packet['data']['attributes'] = []
        for attribute in exact['data'].get('attributes', []):
            item = {key: deepcopy(value) if key in {'target_attribute','target_table','target_data_type'} else blocks.project(value, path=('data', 'attributes', attribute.get('target_attribute'), key))
                    for key, value in attribute.items() if key != 'selected_mapping'}
            selected = attribute.get('selected_mapping') or {}
            item['selected_mapping'] = {key: deepcopy(value) if key in {'source_attributes', 'source_dependencies', 'value_binding_ids'}
                                        else blocks.project(value, path=('data', 'attributes', attribute.get('target_attribute'), 'selected_mapping', key)) for key, value in selected.items()}
            packet['data']['attributes'].append(item)
        packet['evidence_snapshot_hash'] = blocks.snapshot
        packet['instructions'] = ('Generate rules only for the requested targets and exact selected bindings. '
            'Evidence blocks were read separately; only exact verified quotes are indexed here, not the complete contracts. '
            'Never infer a missing clause from an excerpt. Preserve authored population, joins, CTE output boundaries '
            'and approved Value placeholders. If evidence is insufficient, omit that rule; never invent one. '
            'All resulting expressions require human review against the archived exact contracts. '
            'Return the normal completed AGT_TRANSFORMATION_RULE rules envelope, without tools or delegation.')
        return wire_messages([{'role':'user','content':[{'type':'text','text':encoded(packet)}]}])

    def fit():
        while True:
            runtime.check_active()
            messages = render()
            text = wire_text(messages)
            if len(text) <= chars and len(text.encode('utf-8')) <= size:
                return messages
            if blocks.threshold <= 512:
                raise EvidenceBlockError('Specialist identity/framing cannot fit the configured allowance')
            blocks.threshold //= 2

    # Preflight conservatively reserves fully populated quote indexes.
    preview = True
    fit()
    preview = False
    messages = fit()
    count = 0

    def review_budget_available():
        stage_calls = getattr(runtime, '_stage_calls', {})
        used = stage_calls.get('evidence_review', count)
        return (used < MAX_EVIDENCE_REVIEW_CALLS
                and runtime.next_call_index < getattr(runtime, '_max_calls', 8))

    # Size every required read before spending any review calls. request() can
    # refine a block, so repeat until the pending identities stabilize.
    while True:
        before = tuple(blocks.pending)
        for identity in before:
            runtime.check_active()
            blocks.request(identity)
        if tuple(blocks.pending) == before:
            break
    used_reviews = getattr(runtime, '_stage_calls', {}).get('evidence_review', 0)
    if len(blocks.pending) > MAX_EVIDENCE_REVIEW_CALLS - used_reviews:
        raise EvidenceBlockError('Specialist evidence exceeds the remaining shared review budget; replan before rule generation')
    while blocks.pending:
        runtime.check_active()
        # Reserve the actual rule call. No budget is raised or reset here.
        if not review_budget_available():
            raise EvidenceBlockError('Specialist evidence-read call budget exhausted before rule generation')
        identity = blocks.pending[0]
        outgoing = blocks.request(identity)
        if outgoing is None:
            continue
        for attempt in range(2):
            runtime.check_active()
            if not review_budget_available():
                raise EvidenceBlockError('Specialist evidence-review repair budget exhausted')
            if attempt:
                outgoing = deepcopy(outgoing)
                outgoing[0]['content'].append({'type':'text','text':'Repair only evidence_review JSON; return literal quotes, matching block_id, completed status, and no mapping decisions.'})
            # Transport failure escapes immediately: never re-POST an uncertain call.
            result, _, _ = runtime.run(outgoing, runtime.next_call_index, stage='evidence_review')
            count += 1
            try:
                blocks.accept(identity, result)
                break
            except EvidenceBlockError:
                if attempt:
                    raise
        messages = fit()
    return messages, {'snapshot_hash': blocks.snapshot, 'review_required': True,
        'block_count': len(blocks.active), 'block_review_calls': count,
        'reviewed_blocks': len(blocks.active & blocks.reviews.keys())}
