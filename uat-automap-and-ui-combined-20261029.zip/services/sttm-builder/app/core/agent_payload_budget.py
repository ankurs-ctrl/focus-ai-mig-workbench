from __future__ import annotations

import copy
import hashlib
import json
import logging
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any

from app.core.exceptions import AgentPayloadRequiredContextTooLargeError

logger = logging.getLogger(__name__)

class AgentPayloadBudgetError(AgentPayloadRequiredContextTooLargeError):
    """Raised when required request content cannot fit in the agent contract."""

    error_label = "AGENT_PAYLOAD_REQUIRED_CONTEXT_TOO_LARGE"


@dataclass(frozen=True)
class AgentPayloadBudgetResult:
    payload: dict[str, Any]
    text: str
    diagnostics: dict[str, Any]


def _json_text(payload: dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _fits(text: str, *, max_chars: int, max_bytes: int) -> bool:
    return len(text) <= max_chars and len(text.encode("utf-8")) <= max_bytes


def _trim(value: Any, limit: int) -> Any:
    if not isinstance(value, str) or len(value) <= limit:
        return value
    return value[: max(0, limit - 1)].rstrip() + "…"


def _target_names(payload: dict[str, Any]) -> set[str]:
    names: set[str] = set()
    for item in ((payload.get("data") or {}).get("attributes") or []):
        if not isinstance(item, dict):
            continue
        value = item.get("target_attribute") or item.get("target_column")
        if value:
            names.add(str(value).rsplit(".", 1)[-1].upper())
    return names


def _mentions_target(item: Any, targets: set[str]) -> bool:
    if not targets:
        return True
    if isinstance(item, dict):
        for key in ("target_column", "target_attribute", "column", "target_entity"):
            value = item.get(key)
            if isinstance(value, str) and value.rsplit(".", 1)[-1].upper() in targets:
                return True
            if isinstance(value, dict) and _mentions_target(value, targets):
                return True
        return any(_mentions_target(value, targets) for value in item.values())
    if isinstance(item, list):
        return any(_mentions_target(value, targets) for value in item)
    return False


def _artifact_descriptor(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        artifact_id = value.get("artifact_id") or value.get("id")
        artifact_type = value.get("artifact_type") or value.get("type")
        raw = _json_text(value)
    else:
        artifact_id = None
        artifact_type = type(value).__name__
        raw = str(value)
    return {
        "artifact_id": artifact_id,
        "artifact_type": artifact_type,
        "content_hash": hashlib.sha256(raw.encode("utf-8")).hexdigest(),
        "content_omitted": True,
    }


def _remove_echoed_artifacts(payload: dict[str, Any]) -> int:
    """Remove prior response bodies while retaining attributable descriptors."""

    removed = 0
    data = payload.get("data")
    if isinstance(data, dict):
        for key in ("artifact", "response_artifact", "previous_response", "generated_artifact"):
            if key not in data:
                continue
            descriptor = _artifact_descriptor(data.pop(key))
            if descriptor:
                data.setdefault("artifact_refs", []).append(descriptor)
            removed += 1

    context = payload.get("context")
    if not isinstance(context, dict):
        return removed
    workspace = context.get("workspace_context")
    if isinstance(workspace, dict):
        artifacts = workspace.pop("mapping_artifacts", None)
        if artifacts:
            refs = context.setdefault("artifact_refs", [])
            for artifact in artifacts if isinstance(artifacts, list) else [artifacts]:
                descriptor = _artifact_descriptor(artifact)
                if descriptor:
                    refs.append(descriptor)
                    removed += 1
    execution = context.get("execution_context")
    if isinstance(execution, dict):
        for key in ("artifact", "artifacts", "generated_artifact", "response"):
            if key in execution:
                execution.pop(key, None)
                removed += 1
    return removed


def _qualified(table: Any) -> str:
    if isinstance(table, dict):
        parts = [table.get(key) for key in ("database", "schema", "table")]
        return ".".join(str(part) for part in parts if part).upper()
    return str(table or "").upper()


def _is_name_echo(text: Any, name: Any) -> bool:
    """``{"name": "STREET_ADDRESS", "description": "Street Address"}`` says nothing."""
    normalise = lambda value: re.sub(r"[^A-Z0-9]", "", str(value or "").upper())  # noqa: E731
    return bool(text) and normalise(text) == normalise(name)


def _compact_constraints(values: Any) -> list[str]:
    """``{"type": "FOREIGN_KEY", "references": {...}, "confidence": ...}`` -> ``FOREIGN_KEY->T.C``."""
    compact: list[str] = []
    for value in values if isinstance(values, list) else []:
        if isinstance(value, dict):
            references = value.get("references") if isinstance(value.get("references"), dict) else {}
            ref = ".".join(str(references[key]) for key in ("table", "column") if references.get(key))
            kind = str(value.get("type") or "CONSTRAINT")
            compact.append(f"{kind}->{ref}" if ref else kind)
        elif value:
            compact.append(str(value))
    return list(dict.fromkeys(compact))


@dataclass(frozen=True)
class _SemanticLimits:
    description: int
    domain_summary: int  # 0 drops the field
    summary: int
    attributes: int
    outputs: int
    sql: int
    table_relationships: bool
    # relation_graph output_columns are authoritative for CTE names and types; under
    # pressure the semantic entry only adds what the graph lacks (meaning, lineage).
    graph_owns_outputs: bool


_SEMANTIC_LIMITS = {
    "normal": _SemanticLimits(500, 300, 140, 40, 60, 3000, True, False),
    "emergency": _SemanticLimits(240, 160, 120, 24, 40, 1200, True, True),
    "tight": _SemanticLimits(160, 0, 80, 16, 30, 600, False, True),
}

# Bookkeeping hashes and the UI join list, which every table model repeats in full
# (context.relationships and relation_graph.edges carry it once).
_SEMANTIC_NOISE_KEYS = ("selected_ui_relationships", "upstream_hash", "source_dependency_hash")


def _compact_attribute(attribute: dict[str, Any], limits: _SemanticLimits) -> dict[str, Any]:
    compact: dict[str, Any] = {"name": attribute.get("name")}
    for key in ("business_meaning", "semantic_role", "synonyms", "value_profile",
                "default_aggregation", "max_length", "nullable", "null_behavior"):
        if attribute.get(key) not in (None, "", [], {}):
            compact[key] = attribute[key]
    if attribute.get("data_type"):
        compact["data_type"] = attribute.get("data_type")
    summary = attribute.get("summary") or attribute.get("description")
    if summary and summary != attribute.get("business_meaning") and not _is_name_echo(summary, attribute.get("name")):
        compact["summary"] = _trim(summary, limits.summary)
    constraints = [
        value for value in _compact_constraints(attribute.get("constraints"))
        # The flags below already say this.
        if not (value == "PRIMARY_KEY" and attribute.get("is_primary_key"))
        and not (value == "FOREIGN_KEY" and attribute.get("is_foreign_key"))
    ]
    if constraints:
        compact["constraints"] = constraints
    for flag in ("is_primary_key", "is_foreign_key"):
        if attribute.get(flag):
            compact[flag] = True
    return compact


def _compact_output(output: dict[str, Any], limits: _SemanticLimits) -> dict[str, Any] | None:
    name = output.get("name") or output.get("column_name")
    description = output.get("description")
    meaningful = bool(description) and not _is_name_echo(description, name)
    if limits.graph_owns_outputs and not meaningful and not output.get("source_columns"):
        return None
    compact: dict[str, Any] = {"name": name}
    if output.get("data_type") and not limits.graph_owns_outputs:
        compact["data_type"] = output.get("data_type")
    if meaningful:
        compact["description"] = _trim(description, limits.summary)
    if output.get("source_columns"):
        compact["source_columns"] = output.get("source_columns")
    if output.get("is_primary_key"):
        compact["is_primary_key"] = True
    return compact


def _graph_sql_ids(context: dict[str, Any]) -> set[str]:
    graph = context.get("relation_graph") if isinstance(context.get("relation_graph"), dict) else {}
    return {
        str(node.get("derived_source_id"))
        for node in graph.get("nodes") or []
        if isinstance(node, dict) and node.get("derived_source_id") and node.get("sql_text")
    }


def _compact_semantics(
    items: Any,
    targets: set[str],
    *,
    emergency: bool,
    tight: bool = False,
    target_table: Any = None,
    graph_sql_ids: set[str] | None = None,
) -> list[dict[str, Any]] | None:
    """Keep every source, Source Prep CTE and target; reduce each one instead.

    Tables are never dropped: the agent needs each relation's meaning to choose
    between candidates. Source attributes arrive already narrowed to the batch
    (join keys, learned-pattern dependencies, lexical relevance); only the target
    model is cut to the batch's columns. What goes is duplication (UI join lists,
    hashes, CTE SQL the graph already holds, column descriptions that repeat the
    column name, text shared by every CTE) and, under pressure, prose length.
    """
    if not isinstance(items, list):
        return None
    limits = _SEMANTIC_LIMITS["tight" if tight else "emergency" if emergency else "normal"]
    target_name = _qualified(target_table)
    seen_derived_text: set[tuple[str, str]] = set()
    result: list[dict[str, Any]] = []
    for raw_item in items:
        if not isinstance(raw_item, dict):
            continue
        item = copy.deepcopy(raw_item)
        model = item.get("semantic_model")
        if isinstance(model, dict):
            for key in _SEMANTIC_NOISE_KEYS:
                model.pop(key, None)
            if model.get("table_role_hint") == "source_or_target_resolved_by_bundle":
                model.pop("table_role_hint")
            derived = str(item.get("scope") or "").upper() in {"DERIVED_SOURCE", "CTE"}
            is_target = bool(target_name) and _qualified(item.get("table")) == target_name
            attributes = model.get("attributes")
            if isinstance(attributes, list):
                chosen = [attribute for attribute in attributes if isinstance(attribute, dict)]
                if is_target and targets:
                    chosen = [a for a in chosen if str(a.get("name") or "").upper() in targets] or chosen
                model["attributes"] = [_compact_attribute(a, limits) for a in chosen]
            outputs = model.get("output_columns")
            if isinstance(outputs, list):
                compact_outputs = [
                    _compact_output(output, limits) for output in outputs if isinstance(output, dict)
                ]
                model["output_columns"] = [o for o in compact_outputs if o][: limits.outputs]
            if derived and model.get("derived_source_id") in (graph_sql_ids or set()):
                # relation_graph holds the same CTE body (authoritative for the agent).
                model.pop("sql_text", None)
            # A truncated SQL prefix is not executable lineage. Keep the full
            # body when the authoritative graph does not already own it.
            if derived:
                # Source Prep stamps every CTE with the same plan-level text (often
                # the user's whole project prompt); keep it once.
                for key in ("description", "purpose", "grain"):
                    text = model.get(key)
                    if isinstance(text, str) and (key, text) in seen_derived_text:
                        model.pop(key, None)
                    elif isinstance(text, str):
                        seen_derived_text.add((key, text))
            for key in ("description", "business_context", "purpose", "grain"):
                if key in model:
                    model[key] = _trim(model.get(key), limits.description)
            if limits.domain_summary:
                if "domain_summary" in model:
                    model["domain_summary"] = _trim(model.get("domain_summary"), limits.domain_summary)
            else:
                model.pop("domain_summary", None)
                model.pop("business_context", None)
            relationships = model.get("relationships")
            if not limits.table_relationships:
                model.pop("relationships", None)
            elif isinstance(relationships, dict):
                kept = {
                    key: [rel for rel in values if rel]
                    for key, values in relationships.items()
                    if isinstance(values, list) and any(values)
                }
                if kept:
                    model["relationships"] = kept
                else:
                    model.pop("relationships", None)
            if isinstance(model.get("semantic_coverage_issues"), list):
                model["semantic_coverage_issues"] = [
                    _trim(issue, 120) for issue in model["semantic_coverage_issues"][:4]
                ]
            for key in [key for key, value in model.items() if value in (None, "", [], {})]:
                model.pop(key)
        result.append(item)
    return result or None


_PATTERN_CHAR_BUDGET = 18_000
_EMERGENCY_PATTERN_CHAR_BUDGET = 8_000
_DEPENDENCY_KEYS = ("derived_dependencies", "relationship_dependencies", "query_shaping_dependencies")


def _pattern_target(candidate: Any) -> str:
    if not isinstance(candidate, dict):
        return ""
    pattern = candidate.get("pattern") if isinstance(candidate.get("pattern"), dict) else candidate
    contract = pattern.get("target_contract") if isinstance(pattern.get("target_contract"), dict) else {}
    value = contract.get("target_column") or pattern.get("target_column") or ""
    return str(value).rsplit(".", 1)[-1].upper()


def _column_names(values: Any, limit: int | None = None) -> list[str]:
    names: list[str] = []
    for value in values if isinstance(values, list) else []:
        name = (value.get("name") or value.get("alias") or value.get("column_name")) if isinstance(value, dict) else value
        if name:
            names.append(str(name).rsplit(".", 1)[-1].strip('"'))
        if limit is not None and len(names) >= limit:
            break
    return names


_GENERATED_SUFFIX = re.compile(r"_[a-z0-9]{6}$")


@dataclass(frozen=True)
class _PreparedRelation:
    relation_id: str
    alias: str
    columns: frozenset[str]
    sql_text: str


def _prepared_relations(context: dict[str, Any]) -> dict[str, Any]:
    """CTE/derived relations selected in Source Prep, indexed by name and by columns."""
    graph = context.get("relation_graph") if isinstance(context.get("relation_graph"), dict) else {}
    by_name: dict[str, _PreparedRelation] = {}
    relations: list[_PreparedRelation] = []
    for node in graph.get("nodes") or []:
        if not isinstance(node, dict) or str(node.get("kind") or "").upper() not in {"DERIVED_SOURCE", "CTE"}:
            continue
        relation = _PreparedRelation(
            relation_id=str(node.get("relation_id") or node.get("alias") or ""),
            alias=str(node.get("alias") or node.get("relation_id") or ""),
            columns=frozenset(name.upper() for name in _column_names(node.get("output_columns"))),
            sql_text=str(node.get("sql_text") or "").strip(),
        )
        relations.append(relation)
        for name in (node.get("relation_id"), node.get("alias"), node.get("physical_view_name")):
            if not name:
                continue
            key = str(name).rsplit(".", 1)[-1].strip('"')
            by_name[key.upper()] = relation
            # Source Prep appends a generated suffix (addresses_one_per_contacts_d7du3q).
            by_name[_GENERATED_SUFFIX.sub("", key).upper()] = relation
    return {"by_name": by_name, "relations": relations}


def _match_prepared(item: dict[str, Any], prepared: dict[str, Any]) -> tuple[_PreparedRelation | None, str]:
    """Resolve a historical CTE to a Source Prep relation, deterministically.

    Historical CTE names come from the legacy SQL (``BillingAddress``) while Source
    Prep generates its own (``addresses_one_per_contacts_d7du3q``), so after exact
    and suffix-stripped name matches, fall back to output-column overlap.
    """
    by_name = prepared.get("by_name") or {}
    name = str(item.get("name") or "")
    sql_text = str(item.get("sql_text") or "").strip()
    if name.upper() in by_name and sql_text and sql_text == by_name[name.upper()].sql_text:
        return by_name[name.upper()], "sql_and_name"
    columns = {column.upper() for column in _column_names(item.get("output_columns"))}
    if not columns:
        return None, ""
    for relation in prepared.get("relations") or []:
        if sql_text and sql_text == relation.sql_text and columns <= relation.columns:
            return relation, "sql_and_outputs"
    return None, ""


def _resolve_pattern(candidate: Any, prepared: dict[str, Any], *, emergency: bool) -> Any:
    """Point a pattern's CTEs at the Source Prep graph instead of carrying their SQL.

    A CTE matched to a Source Prep relation is referenced by relation id only: its
    columns are in ``relation_graph``. An unmatched CTE keeps its output columns,
    source tables and a short excerpt so the agent can still judge the precedent,
    without the full SQL body.
    """
    if not isinstance(candidate, dict) or not isinstance(candidate.get("pattern"), dict):
        return candidate
    pattern = dict(candidate["pattern"])
    derived = []
    for item in pattern.get("derived_dependencies") or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "")
        if item.get("prepared_relation_id"):
            # Already resolved by the normal pass; emergency compaction re-runs this.
            derived.append(item)
            continue
        relation, matched_by = _match_prepared(item, prepared)
        if relation is not None:
            derived.append({
                "name": name,
                "prepared_relation_id": relation.relation_id,
                "prepared_alias": relation.alias,
                "matched_by": matched_by,
            })
        else:
            # Prepared contexts saved before retrieval-time compaction still carry
            # full CTE SQL and column dicts; reduce both shapes the same way.
            derived.append({
                "name": name,
                "in_source_prep": False,
                "output_columns": _column_names(item.get("output_columns"), 12),
                "tables_referenced": _column_names(item.get("tables_referenced"), 6),
                "sql_text": item.get("sql_text"),
                "sql_excerpt": item.get("sql_excerpt") if not item.get("sql_text") else None,
                "lineage_complete": bool(item.get("sql_text")),
            })
    pattern["derived_dependencies"] = derived
    # Joins and query shaping are owned by the Source Prep graph; keep the gist only.
    pattern["relationship_dependencies"] = pattern.get("relationship_dependencies") or []
    pattern["query_shaping_dependencies"] = pattern.get("query_shaping_dependencies") or []
    pattern["business_rationale"] = _trim(pattern.get("business_rationale"), 240 if emergency else 600)
    return {**candidate, "pattern": pattern}


def _select_patterns(
    values: list[Any],
    targets: set[str],
    prepared: dict[str, Any],
    *,
    per_target: int,
    emergency: bool,
) -> list[Any]:
    """Batch-specific, rank-preserving pattern selection.

    Only patterns whose target contract is one of this batch's columns are sent.
    Every column keeps its best-ranked pattern; lower-ranked alternatives fill the
    remaining budget. When even the best patterns do not fit, the Auto-map planner
    splits the batch (they run in parallel) rather than dropping precedent.
    """
    budget = _EMERGENCY_PATTERN_CHAR_BUDGET if emergency else _PATTERN_CHAR_BUDGET
    relevant = [
        _resolve_pattern(value, prepared, emergency=emergency)
        for value in values
        if not targets or _pattern_target(value) in targets
    ]
    chosen: set[int] = set()
    counts: dict[str, int] = {}
    used = 0
    for index, value in enumerate(relevant):
        key = _pattern_target(value)
        if key in counts:
            continue
        chosen.add(index)
        counts[key] = 1
        used += len(_json_text({"v": value}))
    for index, value in enumerate(relevant):
        key = _pattern_target(value)
        if index in chosen or counts.get(key, 0) >= per_target:
            continue
        size = len(_json_text({"v": value}))
        if used + size > budget:
            continue
        chosen.add(index)
        counts[key] = counts.get(key, 0) + 1
        used += size
    return [relevant[index] for index in sorted(chosen)]


def _compact_learning(
    learning: Any,
    targets: set[str],
    *,
    emergency: bool,
    prepared: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    if not isinstance(learning, dict):
        return None
    compact = copy.deepcopy(learning)
    target_lists = {
        "source_agent_learnings": 4,
        "transformation_patterns": 4,
        "similar_mappings": 1 if emergency else 3,
        "correction_history": 2 if emergency else 5,
        "fir_recommendations": 1 if emergency else 3,
    }
    for key, per_target in target_lists.items():
        values = compact.get(key)
        if not isinstance(values, list):
            continue
        relevant = [value for value in values if _mentions_target(value, targets)]
        limit = max(per_target, per_target * max(1, len(targets)))
        compact[key] = (relevant or values[:per_target])[:limit]
    if isinstance(compact.get("target_mapping_patterns"), list):
        compact["target_mapping_patterns"] = _select_patterns(
            compact["target_mapping_patterns"],
            targets,
            prepared or {},
            per_target=2 if emergency else 4,
            emergency=emergency,
        )

    precedents: list[dict[str, Any]] = []
    for precedent in compact.get("mapping_precedents") or []:
        if not isinstance(precedent, dict):
            continue
        mappings = [
            mapping
            for mapping in (precedent.get("mappings") or [])
            if isinstance(mapping, dict) and _mentions_target(mapping, targets)
        ]
        if targets and not mappings:
            continue
        item = {
            key: value
            for key, value in precedent.items()
            if key not in {"mappings", "ctes", "derived_sources", "business_rules"}
        }
        item["mappings"] = mappings[: max(1, len(targets) * (1 if emergency else 2))]
        item["ctes"] = (precedent.get("ctes") or [])[: (2 if emergency else 6)]
        item["derived_sources"] = (precedent.get("derived_sources") or [])[: (2 if emergency else 6)]
        item["business_rules"] = [
            rule for rule in (precedent.get("business_rules") or [])
            if not targets or _mentions_target(rule, targets)
        ][: (2 if emergency else 8)]
        precedents.append(item)
    compact["mapping_precedents"] = precedents[: (2 if emergency else 6)]

    for key, limit in {
        "fir_learnings": 4 if emergency else 10,
        "semantic_learnings": 4 if emergency else 10,
        "cross_project_patterns": 2 if emergency else 6,
        "semantic_version_learnings": 2 if emergency else 5,
        "linked_project_patterns": 2 if emergency else 5,
        "linked_mapping_precedents": 2 if emergency else 5,
        "retrieval_explanations": 4 if emergency else 10,
        "project_derived_sources": 8 if emergency else 25,
    }.items():
        if isinstance(compact.get(key), list):
            compact[key] = compact[key][:limit]

    if emergency:
        project = compact.get("project_context")
        if isinstance(project, dict):
            compact["project_context"] = {
                key: project.get(key)
                for key in (
                    "project_id", "project_name", "sttm_id", "sttm_name", "domain",
                    "intended_outcome", "business_process", "source_system_key",
                )
                if project.get(key) is not None
            }
    return compact


def _deduplicate_semantic_catalogs(context: dict[str, Any], targets: set[str] | None = None) -> None:
    """Keep catalog facts once, without discarding uncatalogued or conflicting facts."""
    graph = context.get("relation_graph") or {}
    nodes = {
        _qualified(node.get("table")): node
        for node in graph.get("nodes") or []
        if isinstance(node, dict) and node.get("table")
    }
    derived_nodes = {str(node.get("derived_source_id")): node for node in graph.get("nodes") or []
                     if isinstance(node, dict) and node.get("derived_source_id")}
    for item in context.get("semantic_context") or []:
        if not isinstance(item, dict) or not isinstance(item.get("semantic_model"), dict):
            continue
        model = item["semantic_model"]
        registry = model.get("semantic_registry")
        if isinstance(registry, dict):
            model["semantic_registry"] = {
                key: value for key, value in registry.items()
                if value not in (None, "", [], {})
                and key not in {"column_set_hash", "last_altered_ts", "yaml_hash", "request_id", "native_semantic_source",
                                "native_view_id", "row_count", "column_count", "status", "physical_view_name"}
                and not (key == "fqn" and _qualified(value) == _qualified(item.get("table")))
                and not (key == "native_table_view_id" and value == registry.get("view_id"))
            }
        catalog = model.get("column_catalog")
        if not isinstance(catalog, list):
            continue
        attributes = {attribute.get("name"): attribute for attribute in model.get("attributes") or []
                      if isinstance(attribute, dict)}
        node = nodes.get(_qualified(item.get("table"))) or derived_nodes.get(str(model.get("derived_source_id")))
        outputs = {column.get("name"): column for column in (node or {}).get("output_columns") or []
                   if isinstance(column, dict)}
        remaining = []
        for column in catalog:
            if not isinstance(column, dict):
                remaining.append(column)
                continue
            if targets and _qualified(item.get("table")) == _qualified(context.get("target_table")) and str(column.get("name") or "").upper() not in targets:
                continue
            facts = {key: value for key, value in column.items() if value not in (None, "", [], {})}
            attribute = attributes.get(column.get("name"), {})
            if all(attribute.get(key) == value for key, value in facts.items()):
                continue
            output = outputs.get(column.get("name"))
            if output is not None and all(output.get(key) in (None, value) for key, value in facts.items() if key != "data_type"):
                for key, value in facts.items():
                    if key == "data_type" and output.get(key) not in (None, value):
                        output["semantic_data_type"] = value
                    else:
                        output[key] = value
            else:
                remaining.append(facts)
        if remaining:
            model["column_catalog"] = remaining
        else:
            model.pop("column_catalog", None)


def _compact_context(payload: dict[str, Any], *, emergency: bool, tight: bool = False) -> None:
    context = payload.get("context")
    if not isinstance(context, dict):
        return
    targets = _target_names(payload)
    _deduplicate_semantic_catalogs(context, targets)
    context["semantic_context"] = _compact_semantics(
        context.get("semantic_context"),
        targets,
        emergency=emergency,
        tight=tight,
        target_table=context.get("target_table"),
        graph_sql_ids=_graph_sql_ids(context),
    )
    context["learning_context"] = _compact_learning(
        context.get("learning_context"),
        targets,
        emergency=emergency,
        prepared=_prepared_relations(context),
    )
    workspace = context.get("workspace_context")
    if isinstance(workspace, dict):
        workspace.pop("conversation_history", None)
        for key in (
            "raw_mapping_sql", "mapping_sql", "mapping_preview_sql",
            "compiled_mapping_sql", "compiled_mapping_preview_sql",
            "compiled_mapping_semantic_context",
            "parsed_mapping_model", "validation_history",
        ):
            workspace.pop(key, None)
        rows = workspace.get("mapping_rows")
        if isinstance(rows, list):
            relevant = [row for row in rows if _mentions_target(row, targets)]
            workspace["mapping_rows"] = (relevant or rows[:4])[: (8 if emergency else 30)]
    execution = context.get("execution_context")
    if isinstance(execution, dict):
        # These are duplicates of learning_context or of top-level context sections.
        # Keep exact IDs and summary only.
        for key in (
            "curated_inferences", "exact_fir_recommendations",
            "linked_project_patterns", "linked_mapping_precedents",
            "target_mapping_patterns", "retrieval_explanations",
            "relationships", "derived_lineage", "retrieved_learning_ids",
        ):
            execution.pop(key, None)
    if emergency:
        context.pop("datahub_context", None)
        lineage = context.get("derived_source_lineage")
        if isinstance(lineage, list):
            context["derived_source_lineage"] = lineage[:6]
        _compact_relation_graph(
            context.get("relation_graph"), _semantic_typed_columns(context), physical_names_only=tight
        )
        # Bookkeeping the model does not reason over: retrieval ID lists (sent items
        # carry their own IDs), UI selection state and semantic asset versions.
        if isinstance(context.get("learning_context"), dict):
            context["learning_context"].pop("retrieved_learning_ids", None)
        if isinstance(workspace, dict):
            workspace.pop("checked_mapping_row_ids", None)
            if isinstance(workspace.get("semantic"), dict):
                workspace["semantic"].pop("asset_versions", None)
        if isinstance(execution, dict):
            execution.pop("semantic_bundle_summary", None)


def _semantic_typed_columns(context: dict[str, Any]) -> dict[str, set[str]]:
    """Physical-table columns whose name and type the semantic bundle already carries."""
    covered: dict[str, set[str]] = {}
    for item in context.get("semantic_context") or []:
        if not isinstance(item, dict) or str(item.get("scope") or "TABLE").upper() in {"DERIVED_SOURCE", "CTE"}:
            continue
        model = item.get("semantic_model") if isinstance(item.get("semantic_model"), dict) else {}
        names = {
            str(attribute.get("name")).upper()
            for attribute in model.get("attributes") or []
            if isinstance(attribute, dict) and attribute.get("name") and attribute.get("data_type")
        }
        if names:
            covered[_qualified(item.get("table"))] = names
    return covered


def _compact_relation_graph(
    graph: Any,
    semantic_columns: dict[str, set[str]] | None = None,
    *,
    physical_names_only: bool = False,
) -> None:
    """Keep the graph exact (ids, edges, every output name) but drop duplicated metadata.

    Every column name stays: the graph is the agent's legal namespace. A column's
    type is dropped where the semantic bundle already describes that column, and
    repeated physical types are factored into a node-level default at the last
    stage (CTE nodes always keep explicit types).
    """
    if not isinstance(graph, dict):
        return
    semantic_columns = semantic_columns or {}
    for node in graph.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        physical = str(node.get("kind") or "").upper() == "PHYSICAL_TABLE"
        covered = semantic_columns.get(_qualified(node.get("table")) or str(node.get("relation_id") or "").upper(), set())
        if not physical:
            covered = set()
        outputs = node.get("output_columns")
        if isinstance(outputs, list):
            node["output_columns"] = [
                {
                    key: column.get(key)
                    for key in ("name", "data_type", "semantic_data_type", "semantic_role")
                    if column.get(key) is not None
                    and not (key == "data_type" and str(column.get("name") or "").upper() in covered)
                }
                if isinstance(column, dict) else column
                for column in outputs
            ]
            if physical and physical_names_only:
                types = [column.get("data_type") for column in node["output_columns"]
                         if isinstance(column, dict) and column.get("data_type")]
                if types:
                    default_type = max(dict.fromkeys(types), key=types.count)
                    node["output_column_default_type"] = default_type
                    for column in node["output_columns"]:
                        if isinstance(column, dict) and column.get("data_type") == default_type:
                            column.pop("data_type")
        # Derivation inputs are already expressed by graph edges and lineage.
        node.pop("base_relation_ids", None)
        node.pop("column_semantics", None)
        node.pop("dependency_hash", None)
        for key in [key for key, value in node.items() if value in (None, "", [], {})]:
            node.pop(key)
    for edge in graph.get("edges") or []:
        if isinstance(edge, dict):
            for key in [key for key, value in edge.items() if value in (None, "", [], {})]:
                edge.pop(key)
    bindings = graph.get("value_bindings") or []
    if bindings and all(isinstance(binding, dict) for binding in bindings):
        defaults = {key: bindings[0][key] for key in (
            "data_type", "is_placeholder", "allow_project_specific_value", "resolution_status"
        ) if key in bindings[0] and all(binding.get(key) == bindings[0][key] for binding in bindings)}
        if defaults:
            graph.setdefault("value_binding_defaults", {}).update(defaults)
            for binding in bindings:
                for key in defaults:
                    binding.pop(key, None)


def _minimal_patterns(learning: Any, targets: set[str]) -> list[dict[str, Any]]:
    """Best pattern per batch target, reduced to recipe and decision."""
    if not isinstance(learning, dict):
        return []
    kept: list[dict[str, Any]] = []
    seen: set[str] = set()
    for candidate in learning.get("target_mapping_patterns") or []:
        key = _pattern_target(candidate)
        if not isinstance(candidate, dict) or key in seen or (targets and key not in targets):
            continue
        seen.add(key)
        pattern = candidate.get("pattern") if isinstance(candidate.get("pattern"), dict) else {}
        kept.append({
            "decision": candidate.get("decision"),
            "compatibility_tier": candidate.get("compatibility_tier"),
            "pattern": {
                "pattern_id": pattern.get("pattern_id"),
                "target_contract": {"target_column": key},
                "mapping_recipe": pattern.get("mapping_recipe") or {},
                "derived_dependencies": pattern.get("derived_dependencies") or [],
                "relationship_dependencies": pattern.get("relationship_dependencies") or [],
                "query_shaping_dependencies": pattern.get("query_shaping_dependencies") or [],
                "support_count": pattern.get("support_count"),
            },
        })
    return kept


def _pack_column_records(context: dict[str, Any]) -> None:
    """Factor repeated JSON keys; every column value remains in the model message."""
    def pack(container: dict[str, Any], key: str) -> None:
        records = container.get(key)
        if not isinstance(records, list) or not records or not all(isinstance(row, dict) for row in records):
            return
        fields = list(dict.fromkeys(field for row in records for field in row))
        packed = {"fields": fields, "rows": [[row.get(field) for field in fields] for row in records]}
        groups: list[tuple[tuple[str, ...], list[dict[str, Any]]]] = []
        for row in records:
            shape = tuple(row)
            if not groups or groups[-1][0] != shape:
                groups.append((shape, []))
            groups[-1][1].append(row)
        grouped = {"record_groups": [
            {"fields": list(shape), "rows": [[row[field] for field in shape] for row in rows]}
            for shape, rows in groups
        ]}
        if len(_json_text(grouped)) < len(_json_text(packed)):
            packed = grouped
        if len(_json_text(packed)) < len(_json_text({key: records})):
            container[key] = packed

    for node in (context.get("relation_graph") or {}).get("nodes") or []:
        if isinstance(node, dict):
            pack(node, "output_columns")
    graph = context.get("relation_graph")
    if isinstance(graph, dict):
        pack(graph, "value_bindings")
        pack(graph, "edges")
        pack(graph, "nodes")
    for item in context.get("semantic_context") or []:
        model = item.get("semantic_model") if isinstance(item, dict) else None
        if isinstance(model, dict):
            pack(model, "attributes")
    learning = context.get("learning_context") or {}
    for precedent in learning.get("mapping_precedents") or []:
        if isinstance(precedent, dict):
            pack(precedent, "relationships")
            pack(precedent, "mappings")
            for derived in precedent.get("derived_sources") or []:
                if isinstance(derived, dict):
                    pack(derived, "output_columns")
                    pack(derived, "columns")
    context["column_record_encoding"] = "Objects with fields/rows are tabular records: zip fields with each row. record_groups contains multiple such tables; concatenate their records. Null means no supplied value."


def _factor_selected_graph_context(context: dict[str, Any]) -> None:
    graph = context.get("relation_graph") or {}
    nodes = {node.get("relation_id"): node for node in graph.get("nodes") or [] if isinstance(node, dict)}
    context["source_tables"] = [
        {"graph_relation_id": node["relation_id"]} if (node := next(
            (node for node in nodes.values() if node.get("table") == table), None
        )) else table
        for table in context.get("source_tables") or []
    ]
    represented = []
    for relation in context.get("relationships") or []:
        if not isinstance(relation, dict):
            represented.append(relation)
            continue
        match = next((edge for edge in graph.get("edges") or []
                      if _qualified(nodes.get(edge.get("left_relation_id"), {}).get("table")) == _qualified(relation.get("left_table"))
                      and _qualified(nodes.get(edge.get("right_relation_id"), {}).get("table")) == _qualified(relation.get("right_table"))
                      and edge.get("join_type") == relation.get("join_type")
                      and edge.get("conditions") == relation.get("conditions")
                      and not any(relation.get(key) for key in ("additional_predicate", "sql_predicate", "predicate"))
                      and not any(edge.get(key) for key in ("additional_predicate", "sql_predicate", "predicate"))), None)
        represented.append({"graph_edge_id": match["edge_id"]} if match and match.get("edge_id") else relation)
    if represented:
        context["relationships"] = represented
    selected = context.get("selected_columns_by_table")
    if isinstance(selected, dict):
        for table, columns in selected.items():
            node = next((node for node in nodes.values() if _qualified(node.get("table")) == _qualified(table)), None)
            outputs = (node or {}).get("output_columns") or []
            if isinstance(columns, list) and isinstance(outputs, list) and set(columns) == {column.get("name") for column in outputs if isinstance(column, dict)}:
                selected[table] = {"graph_relation_id": node["relation_id"], "selection": "all_output_columns"}


def _factor_repeated_context_values(payload: dict[str, Any]) -> None:
    """Intern exact repeated strings on the model boundary, never truncate their contents."""
    counts: Counter[str] = Counter()
    has_reserved_key = False

    def count(value: Any) -> None:
        nonlocal has_reserved_key
        if isinstance(value, str) and len(value) >= 16:
            counts[value] += 1
        elif isinstance(value, dict):
            if any(key in value for key in ("$ctx", "context_value_dictionary", "context_value_encoding")):
                has_reserved_key = True
            for child in value.values():
                count(child)
        elif isinstance(value, list):
            for child in value:
                count(child)

    count(payload)
    if has_reserved_key:
        return
    values = [value for value, count in counts.items() if count > 1 and (len(value) - 12) * count > len(value) + 8]
    if not values:
        return
    indices = {value: index for index, value in enumerate(values)}

    def replace(value: Any) -> Any:
        if isinstance(value, str) and value in indices:
            return {"$ctx": indices[value]}
        if isinstance(value, dict):
            return {key: replace(child) for key, child in value.items()}
        if isinstance(value, list):
            return [replace(child) for child in value]
        return value

    factored = replace(payload)
    factored["context_value_dictionary"] = values
    factored["context_value_encoding"] = "A {$ctx: N} value means the EXACT string at context_value_dictionary[N]. Resolve all references before reasoning; return ordinary strings, not references."
    if len(_json_text(factored)) < len(_json_text(payload)):
        payload.clear()
        payload.update(factored)


def budget_agent_payload(
    payload: dict[str, Any],
    *,
    max_chars: int,
    max_bytes: int,
    enabled: bool = True,
    emergency: bool = False,
    compact_encoding: bool = False,
) -> AgentPayloadBudgetResult:
    candidate = copy.deepcopy(payload)
    original_text = _json_text(candidate)
    removed_artifacts = _remove_echoed_artifacts(candidate)
    sanitized_text = _json_text(candidate)

    if not enabled and not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes):
        sections = candidate.get("context") or {}
        if len(_target_names(candidate)) == 1:
            for item in sections.get("semantic_context") or []:
                model = item.get("semantic_model") or {}
                logger.debug("Packet semantic asset=%s fields=%s columns=%s", item.get("table"),
                               {key: len(_json_text(value)) for key, value in model.items()},
                               [column.get("name") for column in model.get("attributes") or []])
        logger.debug("Required mapping packet overflow targets=%s sections=%s semantic_fields=%s learning_fields=%s",
                     sorted(_target_names(candidate)),
                     {key: len(_json_text(value)) for key, value in sections.items()},
                     {key: sum(len(_json_text((item.get('semantic_model') or {}).get(key))) for item in sections.get('semantic_context') or [] if isinstance(item.get('semantic_model'), dict))
                      for key in {key for item in sections.get('semantic_context') or [] if isinstance(item.get('semantic_model'), dict) for key in item['semantic_model']}},
                     {key: len(_json_text(value)) for key, value in (sections.get('learning_context') or {}).items()})
        raise AgentPayloadBudgetError(
            f"Required context for {', '.join(sorted(_target_names(candidate)))} is {len(sanitized_text)} characters; split the target batch without truncating rules."
        )
    compacted = False
    emergency_applied = emergency
    if enabled and (emergency or not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes)):
        _compact_context(candidate, emergency=False)
        compacted = True
        sanitized_text = _json_text(candidate)
    if enabled and not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes):
        _compact_context(candidate, emergency=True)
        emergency_applied = True
        sanitized_text = _json_text(candidate)
    if enabled and not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes):
        # Shorter prose per table rather than fewer tables.
        _compact_context(candidate, emergency=True, tight=True)
        sanitized_text = _json_text(candidate)

    if enabled and not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes):
        _factor_selected_graph_context(candidate.get("context") or {})
        if compact_encoding:
            _pack_column_records(candidate.get("context") or {})
        sanitized_text = _json_text(candidate)

    if enabled and compact_encoding and not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes):
        factored = copy.deepcopy(candidate)
        _factor_repeated_context_values(factored)
        factored_text = _json_text(factored)
        logger.debug("Agent dictionary factoring before_chars=%s after_chars=%s", len(sanitized_text), len(factored_text))
        if _fits(factored_text, max_chars=max_chars, max_bytes=max_bytes):
            candidate, sanitized_text = factored, factored_text

    if enabled and not _fits(sanitized_text, max_chars=max_chars, max_bytes=max_bytes):
        required = {
            "contract_version": candidate.get("contract_version"),
            "request_id": candidate.get("request_id"),
            "operation": candidate.get("operation"),
            **{key: candidate[key] for key in ("context_value_dictionary", "context_value_encoding") if key in candidate},
            "data": candidate.get("data"),
            "context": {
                key: (candidate.get("context") or {}).get(key)
                for key in (
                    "source_tables", "driving_table", "target_table", "relationships",
                    "selected_columns_by_table", "relation_graph", "mapping_intent",
                    "semantic_bundle_id", "prepared_context_hash",
                    "column_record_encoding",
                )
                if (candidate.get("context") or {}).get(key) is not None
            },
        }
        required_text = _json_text(required)
        if not _fits(required_text, max_chars=max_chars, max_bytes=max_bytes):
            raise AgentPayloadBudgetError(
                f"{AgentPayloadBudgetError.error_label}: mandatory request content is "
                f"{len(required_text)} characters/{len(required_text.encode('utf-8'))} bytes"
            )
        # Even the minimal payload keeps the batch's best learned pattern per column
        # when it fits; precedent is the most decision-relevant learning context.
        patterns = _minimal_patterns(
            (candidate.get("context") or {}).get("learning_context"), _target_names(candidate)
        )
        # Mapping needs the semantic bundle (sources, Source Prep CTEs, target) and the
        # learnings together. Try that pair first, then patterns alone, then nothing.
        tiers: list[dict[str, Any]] = []
        semantic = (candidate.get("context") or {}).get("semantic_context")
        learning = (candidate.get("context") or {}).get("learning_context")
        resolved = learning.get("target_mapping_patterns") if isinstance(learning, dict) else None
        if semantic and resolved:
            tiers.append({"semantic_context": semantic, "learning_context": learning})
        if semantic:
            tiers.append({"semantic_context": semantic, "learning_context": {
                **(learning or {}), "target_mapping_patterns": patterns,
            }})
            # Retrieval telemetry is persisted on the prepared envelope and audit;
            # the model needs the actual evidence, not cache bookkeeping.
            tiers.append({"semantic_context": semantic, "learning_context": {
                key: (patterns if key == "target_mapping_patterns" else value)
                for key, value in (learning or {}).items()
                if key not in {"retrieval_diagnostics", "cache_status", "learning_context_hash", "context_key", "retrieval_explanations"}
            }})
        if patterns:
            tiers.append({"learning_context": {"target_mapping_patterns": patterns}})
        for extra in tiers:
            with_context = copy.deepcopy(required)
            with_context["context"].update(copy.deepcopy(extra))
            if compact_encoding:
                _factor_repeated_context_values(with_context)
            with_context_text = _json_text(with_context)
            logger.debug("Agent minimal context targets=%s chars=%s data_chars=%s", sorted(_target_names(payload)), len(with_context_text), len(_json_text(candidate.get("data") or {})))
            if _fits(with_context_text, max_chars=max_chars, max_bytes=max_bytes):
                required, required_text = with_context, with_context_text
                break
        if semantic and not required["context"].get("semantic_context"):
            context = candidate.get("context") or {}
            for section, values in (("graph", context.get("relation_graph") or {}), ("learning", learning or {})):
                for key, value in values.items():
                    logger.warning("Agent overflow section=%s field=%s chars=%s", section, key, len(_json_text({key: value})))
            semantic_sizes: dict[str, int] = {}
            for item in semantic:
                model = item.get("semantic_model") if isinstance(item, dict) else None
                if isinstance(model, dict):
                    for key, value in model.items():
                        semantic_sizes[key] = semantic_sizes.get(key, 0) + len(_json_text({key: value}))
            logger.warning("Agent context overflow targets=%s max_chars=%s sections=%s semantic_fields=%s learning_sections=%s",
                len(_target_names(candidate)), max_chars,
                {key: len(_json_text({key: value})) for key, value in context.items()},
                semantic_sizes,
                {key: len(_json_text({key: value})) for key, value in (learning or {}).items()})
            raise AgentPayloadBudgetError(
                "Required semantic context cannot fit; split the target batch instead of dropping its semantics."
            )
        if patterns and not (required["context"].get("learning_context") or {}).get("target_mapping_patterns"):
            raise AgentPayloadBudgetError(
                "Required target evidence cannot fit; split the target batch instead of dropping all patterns."
            )
        candidate = required
        sanitized_text = required_text
        emergency_applied = True

    context = candidate.get("context") if isinstance(candidate.get("context"), dict) else {}
    section_sizes = {
        key: len(_json_text({key: value}))
        for key, value in sorted(context.items())
    }
    diagnostics = {
        "original_chars": len(original_text),
        "original_bytes": len(original_text.encode("utf-8")),
        "final_chars": len(sanitized_text),
        "final_bytes": len(sanitized_text.encode("utf-8")),
        "max_chars": max_chars,
        "max_bytes": max_bytes,
        "compacted": compacted,
        "emergency_compaction": emergency_applied,
        "artifact_bodies_removed": removed_artifacts,
        "largest_context_sections": sorted(
            section_sizes.items(), key=lambda item: (-item[1], item[0])
        )[:6],
    }
    return AgentPayloadBudgetResult(
        payload=candidate,
        text=sanitized_text,
        diagnostics=diagnostics,
    )
