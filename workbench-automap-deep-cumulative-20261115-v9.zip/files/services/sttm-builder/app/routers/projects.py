from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request

from app.api.deps import get_project_service, get_transactional_project_service, get_postsave_projection_runner
from app.auth.dependencies import get_current_principal
from app.core.config import Settings, get_settings
from app.core.exceptions import SnowflakeQueryError
from app.core.project_service import ProjectService
from app.core.read_cache import invalidate_read_cache, read_through
from app.schema.contracts import ApiActor, ApiRequestEnvelope, ApiResponseEnvelope, build_response_envelope
from app.schema.project import (
    MappingPrecedentLinkRecord,
    MappingPrecedentLinksUpdate,
    ProjectAttributeBatchUpsertRequest,
    ProjectAttributeBatchUpsertResponse,
    ProjectAttributeCreateRequest,
    ProjectAttributeImportRequest,
    ProjectAttributeRecord,
    ProjectAttributeUpdateRequest,
    ProjectCreateRequest,
    ProjectCreateFromTemplateRequest,
    ProjectBootstrapResponse,
    ProjectTemplateRecord,
    ProjectRecord,
    ProjectPrecedentLinkRecord,
    ProjectPrecedentLinksUpdate,
    ProjectsSummaryResponse,
    STTMAutosaveRequest,
    STTMAutosaveResponse,
    STTMPostSaveJobStatusResponse,
    STTMCreateRequest,
    STTMDetailResponse,
    STTMPublishRequest,
    STTMPublishResponse,
    STTMRecord,
)

router = APIRouter(tags=["Projects"])


def _actor_from_request(request: Request) -> ApiActor:
    principal = get_current_principal(request)
    return ApiActor(
        user_id=principal.snowflake_user or str(principal.user_id),
        role=principal.snowflake_role,
    )


def _user_id(request: Request) -> str:
    """Get the user identifier for database operations."""
    principal = get_current_principal(request)
    return principal.snowflake_user or str(principal.user_id)


def _project_creator_id(request: Request) -> str:
    """Return the stable numeric id required by legacy TBL_PROJECTS schemas."""
    return str(get_current_principal(request).user_id)


def _user_display_name(request: Request) -> str:
    """Get a human-readable display name for the user.

    Priority: display_name > snowflake_user > email prefix > 'User {id}'
    """
    principal = get_current_principal(request)
    if principal.display_name:
        return principal.display_name
    if principal.snowflake_user:
        return principal.snowflake_user
    if principal.email and "@" in principal.email:
        return principal.email.split("@")[0]
    return f"User {principal.user_id}"


def _require_edit(request: Request) -> None:
    principal = get_current_principal(request)
    if not principal.permissions.can_edit:
        raise HTTPException(status_code=403, detail="Project edit permission is required.")
    invalidate_read_cache("projects:", "recommendations:")


def _require_publish(request: Request) -> None:
    principal = get_current_principal(request)
    if not principal.permissions.can_publish:
        raise HTTPException(status_code=403, detail="Project publish permission is required.")
    invalidate_read_cache("projects:", "recommendations:")


def _unwrap(body, expected_type):
    if isinstance(body, expected_type):
        return body
    if isinstance(body, ApiRequestEnvelope):
        return body.data
    return expected_type.model_validate(body)


@router.get(
    "/project-templates",
    response_model=ApiResponseEnvelope[list[ProjectTemplateRecord]],
)
def list_project_templates(
    request: Request,
    service: Annotated[ProjectService, Depends(get_project_service)],
    target_database: str | None = None,
    target_schema: str | None = None,
) -> ApiResponseEnvelope[list[ProjectTemplateRecord]]:
    get_current_principal(request)
    return build_response_envelope(
        operation="project_templates.list",
        request=request,
        actor=_actor_from_request(request),
        data=service.get_project_templates(
            target_database=target_database,
            target_schema=target_schema,
        ),
    )


@router.get("/projects/summary", response_model=ApiResponseEnvelope[ProjectsSummaryResponse])
def get_projects_summary(
    request: Request,
    service: Annotated[ProjectService, Depends(get_project_service)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> ApiResponseEnvelope[ProjectsSummaryResponse]:
    """Return all projects and all STTMs in a single response — avoids N+1 per-project fetches."""
    principal = get_current_principal(request)
    cache_key = (
        "projects:summary:"
        f"{principal.snowflake_user or principal.user_id}:"
        f"{principal.snowflake_role or ''}"
    )
    if settings.backend_read_cache_v1 and request.headers.get('cache-control') != 'no-cache':
        projects, sttms = read_through(
            cache_key,
            ttl_seconds=settings.backend_project_summary_cache_seconds,
            loader=service.list_all_projects_summary,
            sliding=True,
        )
    else:
        projects, sttms = service.list_all_projects_summary()
    return build_response_envelope(
        operation="projects.summary",
        request=request,
        actor=_actor_from_request(request),
        data=ProjectsSummaryResponse(projects=projects, sttms=sttms),
    )


@router.get("/projects", response_model=ApiResponseEnvelope[list[ProjectRecord]])
def list_projects(
    request: Request,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[ProjectRecord]]:
    get_current_principal(request)
    return build_response_envelope(
        operation="projects.list",
        request=request,
        actor=_actor_from_request(request),
        data=service.list_projects(),
    )


@router.post("/projects", response_model=ApiResponseEnvelope[ProjectRecord])
def create_project(
    request: Request,
    body: ApiRequestEnvelope[ProjectCreateRequest] | ProjectCreateRequest,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[ProjectRecord]:
    _require_edit(request)
    payload = _unwrap(body, ProjectCreateRequest)
    try:
        data = service.create_project(
            payload,
            user_id=_project_creator_id(request),
            display_name=_user_display_name(request),
        )
    except SnowflakeQueryError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return build_response_envelope(
        operation="projects.create",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        data=data,
    )


@router.post(
    "/projects/from-template",
    response_model=ApiResponseEnvelope[ProjectBootstrapResponse],
)
def create_project_from_template(
    request: Request,
    body: ApiRequestEnvelope[ProjectCreateFromTemplateRequest] | ProjectCreateFromTemplateRequest,
    service: Annotated[ProjectService, Depends(get_transactional_project_service)],
) -> ApiResponseEnvelope[ProjectBootstrapResponse]:
    _require_edit(request)
    payload = _unwrap(body, ProjectCreateFromTemplateRequest)
    data = service.create_project_from_template(
        payload,
        user_id=_project_creator_id(request),
        display_name=_user_display_name(request),
    )
    return build_response_envelope(
        operation="projects.create_from_template",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        data=data,
    )


@router.get(
    "/projects/{project_id}/attributes",
    response_model=ApiResponseEnvelope[list[ProjectAttributeRecord]],
)
def list_project_attributes(
    request: Request,
    project_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[ProjectAttributeRecord]]:
    get_current_principal(request)
    return build_response_envelope(
        operation="projects.attributes.list",
        request=request,
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.list_project_attributes(project_id),
    )


@router.post(
    "/projects/{project_id}/attributes",
    response_model=ApiResponseEnvelope[ProjectAttributeRecord],
)
def create_project_attribute(
    request: Request,
    project_id: str,
    body: ApiRequestEnvelope[ProjectAttributeCreateRequest] | ProjectAttributeCreateRequest,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[ProjectAttributeRecord]:
    _require_edit(request)
    payload = _unwrap(body, ProjectAttributeCreateRequest)
    return build_response_envelope(
        operation="projects.attributes.create",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.create_project_attribute(project_id, payload, user_id=_user_id(request)),
    )


@router.post(
    "/projects/{project_id}/attributes/batch-upsert",
    response_model=ApiResponseEnvelope[ProjectAttributeBatchUpsertResponse],
)
def upsert_project_attributes(
    request: Request,
    project_id: str,
    body: ApiRequestEnvelope[ProjectAttributeBatchUpsertRequest] | ProjectAttributeBatchUpsertRequest,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[ProjectAttributeBatchUpsertResponse]:
    _require_edit(request)
    payload = _unwrap(body, ProjectAttributeBatchUpsertRequest)
    return build_response_envelope(
        operation="projects.attributes.batch_upsert",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.upsert_project_attributes(project_id, payload, user_id=_user_id(request)),
    )


@router.put(
    "/projects/{project_id}/attributes/{attribute_id}",
    response_model=ApiResponseEnvelope[ProjectAttributeRecord],
)
def update_project_attribute(
    request: Request,
    project_id: str,
    attribute_id: str,
    body: ApiRequestEnvelope[ProjectAttributeUpdateRequest] | ProjectAttributeUpdateRequest,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[ProjectAttributeRecord]:
    _require_edit(request)
    payload = _unwrap(body, ProjectAttributeUpdateRequest)
    return build_response_envelope(
        operation="projects.attributes.update",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"project_id": project_id, "attribute_id": attribute_id},
        data=service.update_project_attribute(
            project_id,
            attribute_id,
            payload,
            user_id=_user_id(request),
        ),
    )


@router.delete(
    "/projects/{project_id}/attributes/{attribute_id}",
    response_model=ApiResponseEnvelope[dict],
)
def delete_project_attribute(
    request: Request,
    project_id: str,
    attribute_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[dict]:
    _require_edit(request)
    service.delete_project_attribute(project_id, attribute_id, user_id=_user_id(request))
    return build_response_envelope(
        operation="projects.attributes.delete",
        request=request,
        actor=_actor_from_request(request),
        context={"project_id": project_id, "attribute_id": attribute_id},
        data={"deleted": True, "attribute_id": attribute_id},
    )


@router.post(
    "/projects/{project_id}/attributes/import",
    response_model=ApiResponseEnvelope[list[ProjectAttributeRecord]],
)
def import_project_attributes(
    request: Request,
    project_id: str,
    body: ApiRequestEnvelope[ProjectAttributeImportRequest] | ProjectAttributeImportRequest,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[ProjectAttributeRecord]]:
    _require_edit(request)
    payload = _unwrap(body, ProjectAttributeImportRequest)
    return build_response_envelope(
        operation="projects.attributes.import",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.import_project_attributes(project_id, payload, user_id=_user_id(request)),
    )


@router.get("/projects/{project_id}/sttms", response_model=ApiResponseEnvelope[list[STTMRecord]])
def list_project_sttms(
    request: Request,
    project_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[STTMRecord]]:
    get_current_principal(request)
    return build_response_envelope(
        operation="projects.sttms.list",
        request=request,
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.list_sttms(project_id),
    )


@router.post("/projects/{project_id}/sttms", response_model=ApiResponseEnvelope[STTMRecord])
def create_project_sttm(
    request: Request,
    project_id: str,
    body: ApiRequestEnvelope[STTMCreateRequest] | STTMCreateRequest,
    service: Annotated[ProjectService, Depends(get_transactional_project_service)],
) -> ApiResponseEnvelope[STTMRecord]:
    _require_edit(request)
    payload = _unwrap(body, STTMCreateRequest)
    try:
        data = service.create_sttm(
            project_id,
            payload,
            user_id=_user_id(request),
            session_id=getattr(body, "context", {}).get("session_id") if hasattr(body, "context") else None,
            thread_id=getattr(body, "context", {}).get("thread_id") if hasattr(body, "context") else None,
        )
    except SnowflakeQueryError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return build_response_envelope(
        operation="projects.sttms.create",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=data,
    )


@router.get(
    "/projects/{project_id}/precedent-links",
    response_model=ApiResponseEnvelope[list[ProjectPrecedentLinkRecord]],
)
def list_project_precedent_links(
    request: Request,
    project_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[ProjectPrecedentLinkRecord]]:
    get_current_principal(request)
    return build_response_envelope(
        operation="projects.precedent_links.list",
        request=request,
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.list_project_links(project_id),
    )


@router.put(
    "/projects/{project_id}/precedent-links",
    response_model=ApiResponseEnvelope[list[ProjectPrecedentLinkRecord]],
)
def replace_project_precedent_links(
    request: Request,
    project_id: str,
    body: ApiRequestEnvelope[ProjectPrecedentLinksUpdate] | ProjectPrecedentLinksUpdate,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[ProjectPrecedentLinkRecord]]:
    _require_edit(request)
    payload = _unwrap(body, ProjectPrecedentLinksUpdate)
    return build_response_envelope(
        operation="projects.precedent_links.replace",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"project_id": project_id},
        data=service.replace_project_links(project_id, payload, user_id=_user_id(request)),
    )


@router.get(
    "/sttms/{sttm_id}/precedent-links",
    response_model=ApiResponseEnvelope[list[MappingPrecedentLinkRecord]],
)
def list_mapping_precedent_links(
    request: Request,
    sttm_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[MappingPrecedentLinkRecord]]:
    get_current_principal(request)
    return build_response_envelope(
        operation="sttms.precedent_links.list",
        request=request,
        actor=_actor_from_request(request),
        context={"sttm_id": sttm_id},
        data=service.list_mapping_links(sttm_id),
    )


@router.put(
    "/sttms/{sttm_id}/precedent-links",
    response_model=ApiResponseEnvelope[list[MappingPrecedentLinkRecord]],
)
def replace_mapping_precedent_links(
    request: Request,
    sttm_id: str,
    body: ApiRequestEnvelope[MappingPrecedentLinksUpdate] | MappingPrecedentLinksUpdate,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[list[MappingPrecedentLinkRecord]]:
    _require_edit(request)
    payload = _unwrap(body, MappingPrecedentLinksUpdate)
    return build_response_envelope(
        operation="sttms.precedent_links.replace",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"sttm_id": sttm_id},
        data=service.replace_mapping_links(sttm_id, payload, user_id=_user_id(request)),
    )


@router.get("/sttms/{sttm_id}", response_model=ApiResponseEnvelope[STTMDetailResponse])
def get_sttm(
    request: Request,
    sttm_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
    settings: Annotated[Settings, Depends(get_settings)],
    force_refresh: bool = False,
    include_history: Annotated[
        bool,
        Query(
            description=(
                "Include published versions and full agent artifacts. Disabled by default "
                "so the mapping workspace becomes interactive without downloading audit history."
            )
        ),
    ] = False,
) -> ApiResponseEnvelope[STTMDetailResponse]:
    principal = get_current_principal(request)
    if settings.backend_read_cache_v1 and not include_history and not force_refresh:
        cache_key = (
            "projects:sttm-detail:"
            f"{principal.snowflake_user or principal.user_id}:"
            f"{principal.snowflake_role or ''}:{sttm_id}"
        )
        detail = read_through(
            cache_key,
            ttl_seconds=settings.backend_project_summary_cache_seconds,
            loader=lambda: service.get_sttm_detail(sttm_id, include_history=False),
            sliding=False,
        )
    else:
        # Full audit history can be tens of megabytes, so it is always fetched on
        # demand and never retained in the process cache.
        detail = service.get_sttm_detail(sttm_id, include_history=include_history)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"STTM {sttm_id} was not found.")
    return build_response_envelope(
        operation="sttms.get",
        request=request,
        actor=_actor_from_request(request),
        context={"sttm_id": sttm_id},
        data=detail,
    )


@router.post("/sttms/{sttm_id}/autosave", response_model=ApiResponseEnvelope[STTMAutosaveResponse])
def autosave_sttm(
    request: Request,
    background_tasks: BackgroundTasks,
    sttm_id: str,
    body: ApiRequestEnvelope[STTMAutosaveRequest] | STTMAutosaveRequest,
    service: Annotated[ProjectService, Depends(get_transactional_project_service, scope="function")],
    projection_runner=Depends(get_postsave_projection_runner),
) -> ApiResponseEnvelope[STTMAutosaveResponse]:
    _require_edit(request)
    payload = _unwrap(body, STTMAutosaveRequest)
    try:
        # Snapshot, rows, header and outbox commit before acknowledgment.
        # Background projection owns a separate caller-scoped session.
        data = service.autosave_sttm(sttm_id, payload, user_id=_user_id(request), defer_postsave=True)
    except SnowflakeQueryError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    if data.post_save_job_id:
        background_tasks.add_task(
            projection_runner,
            worker_id=f"autosave:{sttm_id}",
            sttm_id=sttm_id,
            max_jobs=4,
        )
    invalidate_read_cache("projects:", "recommendations:")
    return build_response_envelope(
        operation="sttms.autosave",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"sttm_id": sttm_id},
        data=data,
    )


@router.get(
    "/sttms/{sttm_id}/post-save-jobs/{job_id}",
    response_model=ApiResponseEnvelope[STTMPostSaveJobStatusResponse],
)
def get_sttm_post_save_job(
    request: Request,
    sttm_id: str,
    job_id: str,
    service: Annotated[ProjectService, Depends(get_project_service)],
) -> ApiResponseEnvelope[STTMPostSaveJobStatusResponse]:
    row = service.get_postsave_job_status(sttm_id=sttm_id, job_id=job_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Post-save job was not found.")
    data = STTMPostSaveJobStatusResponse(
        job_id=str(row.get("JOB_ID") or ""),
        snapshot_id=str(row.get("SNAPSHOT_ID") or ""),
        sttm_id=str(row.get("STTM_ID") or ""),
        project_id=str(row.get("PROJECT_ID") or ""),
        job_type=str(row.get("JOB_TYPE") or ""),
        status=str(row.get("STATUS") or "queued"),
        attempt_count=int(row.get("ATTEMPT_COUNT") or 0),
        error_details=service._coerce_json(row.get("ERROR_DETAILS"), {}) or None,
        created_at=row.get("CREATED_AT"),
        updated_at=row.get("UPDATED_AT"),
        completed_at=row.get("COMPLETED_AT"),
    )
    return build_response_envelope(
        operation="sttms.post_save_job.get",
        request=request,
        actor=_actor_from_request(request),
        context={"sttm_id": sttm_id, "job_id": job_id},
        data=data,
    )


@router.post("/sttms/{sttm_id}/publish", response_model=ApiResponseEnvelope[STTMPublishResponse])
def publish_sttm(
    request: Request,
    background_tasks: BackgroundTasks,
    sttm_id: str,
    body: ApiRequestEnvelope[STTMPublishRequest] | STTMPublishRequest,
    service: Annotated[ProjectService, Depends(get_transactional_project_service, scope="function")],
    projection_runner=Depends(get_postsave_projection_runner),
) -> ApiResponseEnvelope[STTMPublishResponse]:
    _require_publish(request)
    payload = _unwrap(body, STTMPublishRequest)
    try:
        data = service.publish_sttm(sttm_id, payload, user_id=_user_id(request))
    except SnowflakeQueryError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    if data.learning_job_id and data.learning_status in {"queued", "running"}:
        background_tasks.add_task(
            projection_runner,
            worker_id=f"publish:{sttm_id}",
            sttm_id=sttm_id,
            snapshot_id=data.snapshot_id,
            max_jobs=4,
        )
    invalidate_read_cache("projects:", "recommendations:")
    return build_response_envelope(
        operation="sttms.publish",
        request=request,
        request_id=getattr(body, "request_id", None),
        actor=_actor_from_request(request),
        context={"sttm_id": sttm_id},
        data=data,
    )


@router.get('/admin/resources/archived')
@router.get('/admin/resources/removed')
def archived_resources(request: Request,
    service: Annotated[ProjectService, Depends(get_project_service)]):
    from app.auth.models import AppPersona
    if get_current_principal(request).app_persona is not AppPersona.ADMIN:
        raise HTTPException(status_code=403, detail='Only the Admin persona can view archived resources.')
    items = []
    for kind, table, key, name in (
        ('project', service._projects_table, 'PROJECT_ID', 'PROJECT_NAME'),
        ('mapping', service._sttm_table, 'STTM_ID', 'STTM_NAME'),
    ):
        meta = 'PROJECT_METADATA' if kind == 'project' else 'STTM_METADATA'
        rows = service._session.sql(f"""SELECT TO_VARCHAR({key}) AS ID, {name} AS NAME, STATUS,
            {meta}:removal:at::VARCHAR AS REMOVED_AT,
            IFF(UPPER(STATUS) = 'DELETED', DATEADD(day, 30, TRY_TO_TIMESTAMP_TZ({meta}:removal:at::VARCHAR)), NULL) AS RECOVERABLE_UNTIL
            FROM {table} WHERE UPPER(STATUS) = 'ARCHIVED'
            OR (UPPER(STATUS) = 'DELETED' AND TRY_TO_TIMESTAMP_TZ({meta}:removal:at::VARCHAR) >= DATEADD(day, -30, CURRENT_TIMESTAMP()))
            ORDER BY {name}""").collect()
        for row in rows:
            data = row.as_dict() if hasattr(row, 'as_dict') else dict(row)
            items.append({'id': data['ID'], 'name': data['NAME'] or data['ID'], 'kind': kind, 'status': data['STATUS'], 'removed_at': str(data.get('REMOVED_AT') or ''), 'recoverable_until': str(data.get('RECOVERABLE_UNTIL') or '')})
    return build_response_envelope(operation='admin.resources.archived', request=request,
        actor=_actor_from_request(request), data=items)


@router.post('/admin/resources/{kind}/{resource_id}/{action}')
def manage_resource(kind: str, resource_id: str, action: str, request: Request,
                    service: Annotated[ProjectService, Depends(get_transactional_project_service)]):
    from app.auth.models import AppPersona
    if get_current_principal(request).app_persona is not AppPersona.ADMIN:
        raise HTTPException(status_code=403, detail='Only the Admin persona can manage projects and mappings.')
    if kind not in {'project', 'mapping'} or action not in {'archive', 'delete', 'restore'}:
        raise HTTPException(status_code=422, detail='Unsupported resource action')
    table = service._projects_table if kind == 'project' else service._sttm_table
    key = 'PROJECT_ID' if kind == 'project' else 'STTM_ID'
    meta = 'PROJECT_METADATA' if kind == 'project' else 'STTM_METADATA'
    status = {'archive': 'ARCHIVED', 'delete': 'DELETED', 'restore': 'RESTORED'}[action]
    service._session.sql('BEGIN').collect()
    try:
        if action == 'restore':
            # Restore only rows with recorded pre-archive state. Never guess a
            # published/draft status, or revive a separately removed child.
            parent_guard = '' if kind == 'project' else f" AND EXISTS (SELECT 1 FROM {service._projects_table} P WHERE P.PROJECT_ID = RESOURCE.PROJECT_ID AND UPPER(P.STATUS) NOT IN ('ARCHIVED','DELETED'))"
            sql = f"""UPDATE {table} AS RESOURCE SET STATUS = {meta}:removal:previous_status::VARCHAR,
                RUNTIME_SUPPRESSED = COALESCE({meta}:removal:previous_suppressed::BOOLEAN, FALSE),
                {meta} = OBJECT_DELETE({meta}, 'removal')
                WHERE TO_VARCHAR({key}) = ? AND (UPPER(STATUS) = 'ARCHIVED' OR (UPPER(STATUS) = 'DELETED' AND TRY_TO_TIMESTAMP_TZ({meta}:removal:at::VARCHAR) >= DATEADD(day, -30, CURRENT_TIMESTAMP())))
                AND {meta}:removal:previous_status IS NOT NULL {parent_guard}"""
            params = [resource_id]
        else:
            sql = f"""UPDATE {table} SET STATUS = ?, RUNTIME_SUPPRESSED = TRUE,
                {meta} = OBJECT_INSERT(COALESCE({meta}, OBJECT_CONSTRUCT()), 'removal',
                    OBJECT_CONSTRUCT('action', ?, 'actor', ?, 'at', TO_VARCHAR(CURRENT_TIMESTAMP()),
                        'previous_status', STATUS, 'previous_suppressed', COALESCE(RUNTIME_SUPPRESSED, FALSE)), TRUE)
                WHERE TO_VARCHAR({key}) = ? AND UPPER(STATUS) NOT IN ('ARCHIVED','DELETED')"""
            params = [status, action, _user_id(request), resource_id]
        result = service._session.sql(sql, params=params).collect()
        from app.core.async_jobs import AsyncJobService
        if not AsyncJobService._changed(result):
            raise HTTPException(status_code=409 if action == 'restore' else 404, detail='Resource is unavailable for this action. Restore its parent first; older archives without saved status require administrative recovery.')
        if kind == 'project':
            if action == 'restore':
                child_sql = f"""UPDATE {service._sttm_table} SET STATUS = STTM_METADATA:removal:previous_status::VARCHAR,
                    RUNTIME_SUPPRESSED = COALESCE(STTM_METADATA:removal:previous_suppressed::BOOLEAN, FALSE),
                    STTM_METADATA = OBJECT_DELETE(STTM_METADATA, 'removal')
                    WHERE TO_VARCHAR(PROJECT_ID) = ? AND (UPPER(STATUS) = 'ARCHIVED' OR (UPPER(STATUS) = 'DELETED' AND TRY_TO_TIMESTAMP_TZ(STTM_METADATA:removal:at::VARCHAR) >= DATEADD(day, -30, CURRENT_TIMESTAMP())))
                    AND STTM_METADATA:removal:parent_project_id::VARCHAR = ?
                    AND STTM_METADATA:removal:previous_status IS NOT NULL"""
                child_params = [resource_id, resource_id]
            else:
                child_sql = f"""UPDATE {service._sttm_table} SET STATUS = ?, RUNTIME_SUPPRESSED = TRUE,
                    STTM_METADATA = OBJECT_INSERT(COALESCE(STTM_METADATA, OBJECT_CONSTRUCT()), 'removal',
                        OBJECT_CONSTRUCT('action', ?, 'parent_project_id', ?, 'actor', ?, 'at', TO_VARCHAR(CURRENT_TIMESTAMP()),
                            'previous_status', STATUS, 'previous_suppressed', COALESCE(RUNTIME_SUPPRESSED, FALSE)), TRUE)
                    WHERE TO_VARCHAR(PROJECT_ID) = ? AND UPPER(STATUS) NOT IN ('ARCHIVED','DELETED')"""
                child_params = [status, action, resource_id, _user_id(request), resource_id]
            service._session.sql(child_sql, params=child_params).collect()
        service._session.sql('COMMIT').collect()
    except Exception:
        service._session.sql('ROLLBACK').collect()
        raise
    invalidate_read_cache('projects:', 'recommendations:')
    from app.core.learning_retrieval import invalidate_learning_context_cache
    invalidate_learning_context_cache()
    return build_response_envelope(operation='admin.resource.' + action, request=request,
        actor=_actor_from_request(request), data={'id': resource_id, 'status': status, 'history_retained': True})
