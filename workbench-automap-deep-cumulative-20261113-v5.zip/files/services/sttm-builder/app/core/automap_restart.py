"""Restore durable work using existing, live caller OAuth sessions.

The service connection discovers operational metadata only. All archive reads,
provider control and job resumption use independently verified caller sessions.
No token is written into a job, permit, log or new credential store.
"""
from contextlib import contextmanager
import json
import logging
import hmac
import re
import time

from app.core.automap_runtime import (
    RuntimeCaller, SnowflakeReductionArchive, _checked_sessions, _fqn, _host,
)
from app.core.snowflake import get_service_connection, caller_write_lease
from app.core.warehouse_routing import WarehouseWorkload

logger = logging.getLogger(__name__)


def _rows(settings, sql, params=()):
    from snowflake.connector import DictCursor
    with get_service_connection(settings) as connection:
        cursor = connection.cursor(DictCursor)
        try:
            cursor.execute(sql, params, timeout=5)
            return cursor.fetchall()
        finally:
            cursor.close()


def authenticated_headers(settings, session_id, owner, role):
    """Recheck revocation and refresh through the application's existing store."""
    from app.auth.custom_oauth import (
        _session_select_row, _refresh_session_if_needed, decrypt_access_token,
    )
    from app.core.auto_mapping_proxy import _DelegatedHeaders
    record = _session_select_row(session_id, settings)
    if (record is None or not record.is_active
            or record.snowflake_user != owner or record.snowflake_role != role):
        raise PermissionError('Original caller session unavailable')
    record = _refresh_session_if_needed(record, settings, touch=False)
    if (not record.is_active or record.snowflake_user != owner or record.snowflake_role != role):
        raise PermissionError('Refreshed caller identity changed')
    return _DelegatedHeaders({
        'Content-Type': 'application/json',
        'X-Workbench-OAuth-Access-Token': decrypt_access_token(record, settings),
        'X-Workbench-OAuth-User': owner,
        'X-Workbench-OAuth-Role': role,
        'X-Workbench-OAuth-Email': record.email,
    }, session_id=session_id)


def register_caller(coordinator, settings, session_id, owner, role):
    """Rebuild only a control runtime; this function cannot submit a model run."""
    from app.core.automap_admission import ScanCallAdmission
    from app.core.automap_durable_admission import DurableRunAdmission
    from app.core.automap_background_transport import BackgroundRunTransport
    from app.core.automap_batch import ParallelRuntimeBundle
    from app.core.automap_parallel import ParallelLimits
    from app.core.automap_scan_transport import ScanTransportConfig
    from app.core.automap_shards import SnapshotScope, MessageBudget
    from app.core.snowflake_agent import SnowflakeAgentClient, _shared_http_client

    headers = authenticated_headers(settings, session_id, owner, role)
    token = headers['X-Workbench-OAuth-Access-Token']
    namespace = settings.automap_parallel_account_namespace
    caller = RuntimeCaller(owner, owner, role, namespace)
    host = _host(settings.rest_snowflake_host)
    if host not in {namespace.lower().replace('.', '-') + '.snowflakecomputing.com',
                    namespace.lower().replace('.', '-').replace('_', '-') + '.snowflakecomputing.com'}:
        raise PermissionError('Recovery account host mismatch')

    @contextmanager
    def provider(deadline=None):
        # Each control lease independently verifies the native user/role/account.
        current = authenticated_headers(settings, session_id, owner, role)
        if not hmac.compare_digest(current['X-Workbench-OAuth-Access-Token'], token):
            raise PermissionError('Caller credential rotated; rebuild recovery context')
        with caller_write_lease(settings, token, role, WarehouseWorkload.CONTROL,
                reusable=True, deadline=deadline, maximum=2, purpose='automap-recovery') as client:
            yield client.session

    factory = _checked_sessions(provider, caller, (), deadline_provider=provider)
    with factory(deadline=time.monotonic()+15):
        pass
    pool = DurableRunAdmission(session_factory=factory,
        table=_fqn(settings.automap_parallel_permit_table_fqn, 'permit table'),
        account_namespace=namespace, pool_epoch=settings.automap_parallel_pool_epoch,
        capacity=settings.automap_parallel_pool_capacity,
        recovery_capacity=settings.automap_recovery_capacity)
    gate = ScanCallAdmission(pool, job_id='0'*32, caller_id=owner)
    scope = SnapshotScope(owner, '0'*64)
    archive = SnowflakeReductionArchive(session_factory=factory,
        table=_fqn(settings.automap_parallel_archive_table_fqn, 'archive table'),
        caller=caller, scope=scope, deadline=time.monotonic()+55)
    agent = SnowflakeAgentClient(token, host=host, role=role, auth_mode='oauth_bearer')
    metadata = f'{settings.resolved_metadata_database}.{settings.resolved_metadata_schema}'
    backends = [BackgroundRunTransport(agent_client=agent,
        http_client=_shared_http_client(agent._base_url), admission=gate,
        config=ScanTransportConfig(agent=_fqn(metadata+'.'+name, 'agent'), max_response_bytes=120_000))
        for name in ('AGT_SOURCE_MAPPING', 'AGT_TRANSFORMATION_RULE')]
    budget = MessageBudget(120_000, 120_000)
    limits = ParallelLimits(budget, budget, budget, budget, 1, 0, 0, 8, 16, 64, 256)
    bundle = ParallelRuntimeBundle(scope, backends[0], gate, archive, limits)
    coordinator.register(bundle, *backends, settings)


def restore_work(coordinator, settings, *, resume_jobs=False):
    """Bounded periodic discovery, separate from foreground admission and health."""
    if not (settings.automap_durable_runs_v2 and settings.uses_custom_oauth):
        return
    pool = _fqn(settings.automap_parallel_permit_table_fqn, 'permit table')
    sessions = _fqn(settings.qualified_oauth_sessions_table, 'OAuth sessions table')
    callers = _rows(settings, f"""
        SELECT DISTINCT s.SESSION_ID, s.SNOWFLAKE_USER, s.SNOWFLAKE_ROLE
        FROM {sessions} s JOIN {pool} p ON p.CALLER_ID=s.SNOWFLAKE_USER
        WHERE p.ACCOUNT_NAMESPACE=%s AND p.POOL_EPOCH=%s
          AND p.STATE IN ('HELD','QUARANTINED') AND s.IS_ACTIVE=TRUE
          AND s.SNOWFLAKE_ROLE IS NOT NULL
        ORDER BY s.SNOWFLAKE_USER, s.SESSION_ID LIMIT 16
        """, (settings.automap_parallel_account_namespace, settings.automap_parallel_pool_epoch))
    for row in callers:
        try:
            register_caller(coordinator, settings, row['SESSION_ID'],
                            row['SNOWFLAKE_USER'], row['SNOWFLAKE_ROLE'])
        except Exception as exc:
            logger.warning('Auto-map caller recovery authentication unavailable caller=%s role=%s error_type=%s', row['SNOWFLAKE_USER'], row['SNOWFLAKE_ROLE'], type(exc).__name__)
    if not (resume_jobs and settings.auto_map_pipeline_v2):
        return
    table = _fqn(settings.qualify_metadata_object_name('TBL_AUTO_MAP_JOBS'), 'job table')
    jobs = _rows(settings, f"""
        SELECT JOB_ID, OWNER_ID, JOB_STATE FROM {table}
        WHERE STATUS IN ('queued','running') AND EXPIRES_AT>CURRENT_TIMESTAMP()
          AND (LEASE_EXPIRES_AT IS NULL OR LEASE_EXPIRES_AT<CURRENT_TIMESTAMP())
          AND JOB_STATE:execution_protocol::VARCHAR='background_v2'
        ORDER BY UPDATED_AT LIMIT 4
        """)
    for row in jobs:
        try:
            resume_job(settings, row)
        except Exception as exc:
            logger.warning('Auto-map durable resume unavailable job_id=%s owner=%s error_type=%s', row['JOB_ID'], row['OWNER_ID'], type(exc).__name__)


def resume_job(settings, row):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient, _AUTO_MAP_JOBS, _AUTO_MAP_JOBS_LOCK, _AUTO_MAP_ACTIVE_RUNNERS
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    record = row['JOB_STATE']
    if isinstance(record, str):
        record = json.loads(record)
    if isinstance(record, dict) and '_automap_exact_json' in record:
        record = AutoMappingProxyClient._load_job_state(record)
    owner = row['OWNER_ID']
    if (not isinstance(record, dict) or record.get('owner') != owner
            or record.get('job_id') != row['JOB_ID'] or record.get('execution_protocol') != 'background_v2'
            or record.get('status') not in {'queued', 'running'}):
        raise PermissionError('Durable job identity mismatch')
    session_hash = record.get('recovery_session_hash')
    role = record.get('recovery_role')
    if not isinstance(session_hash,str) or not re.fullmatch('[0-9a-f]{64}',session_hash) or not role:
        return  # historical jobs require fresh caller authentication, never owner fallback
    sessions=_fqn(settings.qualified_oauth_sessions_table,'OAuth sessions table')
    matches=_rows(settings,f'SELECT SESSION_ID FROM {sessions} WHERE SHA2(SESSION_ID,256)=%s '
        'AND SNOWFLAKE_USER=%s AND SNOWFLAKE_ROLE=%s AND IS_ACTIVE=TRUE LIMIT 2',
        (session_hash,owner,role))
    if len(matches)!=1:
        raise PermissionError('Original caller session reference unavailable')
    session_id=matches[0]['SESSION_ID']
    headers = authenticated_headers(settings, session_id, owner, role)
    req = STTMBuilderEnvelopeRequest.model_validate(record['request_envelope'])
    proxy = AutoMappingProxyClient(settings)
    with _AUTO_MAP_JOBS_LOCK:
        if row['JOB_ID'] in _AUTO_MAP_ACTIVE_RUNNERS:
            return
        _AUTO_MAP_JOBS[row['JOB_ID']] = record
    # Existing atomic distributed lease, receipt validation and protocol checks
    # remain authoritative. Only unfinished batches can be dispatched.
    proxy._launch_job_runner(row['JOB_ID'], req=req, headers=headers, owner=owner, record=record)
