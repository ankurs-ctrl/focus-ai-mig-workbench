'use client';

import { useState } from 'react';
import { AiaBox, AiaCard, AiaIconButton, AiaMenu, AiaMenuItem } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { AiaChip } from '@/components/ui/aia-chip';
import { CheckIcon, MoreVertIcon } from '@/utils/icons';
import { BODY_SX, SECONDARY_TEXT_SX, TYPOGRAPHY_TOKENS } from '@/config/typography-tokens';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { WorkspaceEmptyMessage } from './workspace-empty-message';
import {
  WORKSPACE_CARD_SELECTED_TEXT,
  workspaceCardSx,
} from '@/features/sttm/source-target/workspace-card-styles';
import { getDerivedSourceCounts } from '@/features/sttm/source-target/derived-source-counts';

type DerivedWorkspaceListProps = {
  orderedIds: string[];
  isSelected: (id: string) => boolean;
  onSelect: (id: string, event: React.MouseEvent, orderedIds: string[]) => void;
};

function DerivedWorkspaceCardMenu({ sourceId }: { sourceId: string }) {
  const { drivingTableId, setDrivingTable } = useSttmBuilderContext();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const isDrivingTable = drivingTableId === sourceId;

  const handleMenuClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = (event: React.MouseEvent) => {
    event.stopPropagation();
    setAnchorEl(null);
  };
  const handleMakeDrivingTable = (event: React.MouseEvent) => {
    event.stopPropagation();
    setDrivingTable(sourceId);
    setAnchorEl(null);
  };

  return (
    <AiaBox sx={{ ml: 0.5 }} onClick={(e) => e.stopPropagation()}>
      <AiaIconButton size="small" onClick={handleMenuClick} sx={{ color: 'text.secondary' }}>
        <MoreVertIcon fontSize="small" />
      </AiaIconButton>
      <AiaMenu
        anchorEl={anchorEl}
        open={open}
        onClose={handleMenuClose}
        onClick={(e) => e.stopPropagation()}
        slotProps={{
          paper: {
            sx: { minWidth: 160, boxShadow: '0 4px 20px rgba(0,0,0,0.1)', borderRadius: '8px' },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <AiaMenuItem
          onClick={handleMakeDrivingTable}
          sx={{ fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
        >
          Mark as driving table
          {isDrivingTable && <CheckIcon fontSize="small" sx={{ ml: 2, color: 'primary.main' }} />}
        </AiaMenuItem>
      </AiaMenu>
    </AiaBox>
  );
}

export default function DerivedWorkspaceList({
  orderedIds,
  isSelected,
  onSelect,
}: DerivedWorkspaceListProps) {
  const { derivedSources, drivingTableId } = useSttmBuilderContext();

  const workspaceItems = derivedSources.filter((source) => source.isSelected);

  if (workspaceItems.length === 0) {
    return (
      <WorkspaceEmptyMessage>
        Drag CTEs from CTE Library into this area.
      </WorkspaceEmptyMessage>
    );
  }

  return (
    <AiaBox sx={{ width: "100%", minWidth: 0, alignSelf: "stretch" }}>
      {workspaceItems.map((source) => {
        const { sourceTableCount, selectedColumnCount, outputColumnCount } =
          getDerivedSourceCounts(source);
        const selected = isSelected(source.id);
        const isDrivingTable = drivingTableId === source.id;

        return (
          <AiaCard
            key={source.id}
            variant="outlined"
            sx={{
              ...workspaceCardSx(selected),
              alignSelf: "stretch",
            }}
            onClick={(event) => onSelect(source.id, event, orderedIds)}
          >
            <AiaBox
              sx={{
                flex: "1 1 auto",
                minWidth: 0,
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                gap: "var(--sttm-card-title-caption-gap)",
              }}
            >
              <AiaBox sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, minWidth: 0 }}>
                <AiaText
                  sx={{
                    ...BODY_SX,
                    color: selected ? WORKSPACE_CARD_SELECTED_TEXT : TYPOGRAPHY_TOKENS.body.color,
                    whiteSpace: 'normal',
                    overflowWrap: 'anywhere',
                    wordBreak: 'break-word',
                  }}
                >
                  {source.sourceName}
                </AiaText>
                {isDrivingTable && (
                  <AiaChip
                    label="Driving"
                    size="small"
                    color="warning"
                    customBackgroundColor="#fef08a"
                    customColor="#854d0e"
                    customBorderColor="#fde047"
                    sx={{
                      height: 22,
                      fontSize: 10,
                      fontWeight: 700,
                      "& .MuiChip-label": { px: 0.75, py: 0 },
                    }}
                  />
                )}
              </AiaBox>
              <AiaText
                sx={{
                  ...SECONDARY_TEXT_SX,
                  fontSize: 12,
                  color: selected
                    ? 'color-mix(in srgb, #ffffff 78%, transparent)'
                    : TYPOGRAPHY_TOKENS.secondaryText.color,
                }}
              >
                {sourceTableCount} source table{sourceTableCount === 1 ? '' : 's'} ·{' '}
                {outputColumnCount > 0
                  ? `${outputColumnCount} output column${outputColumnCount === 1 ? '' : 's'}`
                  : `${selectedColumnCount} selected columns`}
              </AiaText>
            </AiaBox>
            <DerivedWorkspaceCardMenu sourceId={source.id} />
          </AiaCard>
        );
      })}
    </AiaBox>
  );
}
