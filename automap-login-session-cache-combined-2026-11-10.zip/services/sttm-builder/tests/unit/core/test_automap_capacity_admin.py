from types import SimpleNamespace
import pytest
from fastapi import HTTPException
from app.auth.models import AppPersona
from app.routers import automap_capacity as api


@pytest.mark.parametrize('persona',[AppPersona.VIEWER,AppPersona.PUBLISHER])
def test_non_admin_capacity_access_rejected_before_any_database_use(monkeypatch,persona):
    monkeypatch.setattr(api,'get_current_principal',lambda req:SimpleNamespace(app_persona=persona))
    with pytest.raises(HTTPException) as error:api.admin_pool(object(),SimpleNamespace(automap_durable_runs_v2=True))
    assert error.value.status_code==403


def test_readonly_health_does_not_resume_or_reconcile_anything():
    class ReadOnly:
        capacity=12;recovery_capacity=4;inventory_capacity=16
        def health(self):return {'free':4,'execution_free':0,'quarantined':0}
        def __getattr__(self,name):raise AssertionError('Unexpected operation '+name)
    result=api.health((None,ReadOnly()))
    assert result['all_unavailable'] is True  # recovery spares are not execution slots
    assert result['outstanding_ceiling']==16


def test_abandonment_requires_every_exact_identity_and_explicit_acknowledgement():
    from pydantic import ValidationError
    with pytest.raises(ValidationError):api.AbandonOperation(slot_id=1,fence=1)
    args=dict(slot_id=1,fence=1,pool_epoch='epoch',job_id='job',caller_id='caller',generation='generation',
        shard_id='shard',reason='old test',dispatcher_retirement_verified=True,retirement_evidence='approval-record',
        acknowledge_unknown_remote_outcome=True)
    assert api.AbandonOperation(**args).acknowledge_unknown_remote_outcome is True
    args['acknowledge_unknown_remote_outcome']=False
    with pytest.raises(ValidationError):api.AbandonOperation(**args)
