"""Bounded compiler feedback for the owning request, never raw SQL log text."""
import re
from sqlglot.errors import ParseError


def compiler_feedback(error=None, *, code='invalid_expression', stage='expression_parse', issues=()):
    details = []
    if isinstance(error, ParseError):
        for item in error.errors[:4]:
            details.append({'description': re.sub(r'\s+', ' ', str(item.get('description', 'Invalid SQL expression')))[:160],
                'line': item.get('line') if type(item.get('line')) is int else None,
                'column': item.get('col') if type(item.get('col')) is int else None})
    elif error is not None:
        # Bound to the compiler's first-line diagnostic; never include a SQL
        # context dump or stack trace. This stays in the owning request, not logs.
        details.append({'description': re.sub(r'\s+', ' ', str(error).splitlines()[0] if str(error).splitlines() else 'Compiler rejected the expression')[:160],
                        'action': 'Check syntax, selected source qualifiers, join connectivity and approved Value bindings.',
                        'error_type': type(error).__name__[:64]})
    for item in list(issues)[:4]:
        # Compiler diagnostics are returned only to this frozen request/model.
        details.append({'description': re.sub(r'\s+', ' ', str(item))[:160]})
    return {'code': code, 'stage': stage, 'issues': details[:4] or [{'description': 'No executable source binding was produced.'}]}


class CompilerFeedbackError(ValueError):
    def __init__(self, feedback):
        self.feedback = feedback
        super().__init__('Expression failed bounded compiler validation')
