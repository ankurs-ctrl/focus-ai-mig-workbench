"""A re-queued run continues from what it already did instead of starting again."""
from __future__ import annotations

from types import SimpleNamespace

from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
from app.agent_runtime.execution import ExecutionBudget
from app.agent_runtime.interface import RuntimeInvocation
from app.agent_runtime.run_knowledge import RunKnowledge
from app.agent_runs.models import EffortLevel
from app.agent_tools.capability_registry import CapabilityRegistry


def _registry(knowledge: RunKnowledge) -> CapabilityRegistry:
    return CapabilityRegistry(
        context_provider=lambda: {"run_id": "run-1"}, workflow_executor=lambda *_args: {}, workbench=object(),
        budget=ExecutionBudget(model_limit=64, tool_limit=200), knowledge=knowledge,
    )


def test_the_validated_plan_survives_a_new_process_for_the_same_run_only() -> None:
    knowledge = RunKnowledge(scope="conversation:c", access_scope="t:u:R", run_id="run-1", ttl_seconds=3600)
    first = _registry(knowledge)
    first.begin_run({"run_id": "run-1"})
    first._validated_supervisor_plan = {"_deep_supervisor_validated": True, "plan_hash": "p1"}
    first._prepared_plan_candidate = {"project_decision": {"project_name": "X"}}
    first._persist_plan_state()

    restarted = _registry(knowledge)  # a fresh worker process reading the same durable knowledge
    restarted.begin_run({"run_id": "run-1"})
    assert restarted.validated_supervisor_plan["plan_hash"] == "p1"
    assert restarted.prepared_plan_candidate == {"project_decision": {"project_name": "X"}}

    other = _registry(knowledge)
    other.begin_run({"run_id": "run-2"})
    assert other.validated_supervisor_plan is None


class _Graph:
    def __init__(self, values: dict, pending: tuple = ()) -> None:
        self.snapshot = SimpleNamespace(values=values, next=pending)

    def get_state(self, _config):
        return self.snapshot

    def update_state(self, *_args, **_kwargs):
        raise AssertionError("a finished workflow must not be rescheduled")

    def invoke(self, *_args, **_kwargs):
        raise AssertionError("a finished workflow must not run again")


def _runtime(graph: _Graph) -> SimpleNamespace:
    runtime = SimpleNamespace(_migration_graph=graph, _workflow_result=None, traces=[])
    runtime._trace = lambda *args: runtime.traces.append(args[0])
    runtime._run_workflow = lambda _value: (_ for _ in ()).throw(AssertionError("must not rerun"))
    return runtime


def _invocation() -> RuntimeInvocation:
    return RuntimeInvocation(run_id="run-1", thread_id="run-1", prompt="map ten targets", effort=EffortLevel.HIGH,
                             is_resume=True)


def test_a_finished_workflow_is_restored_from_its_checkpoint() -> None:
    values = {"status": "COMPLETED_WITH_REVIEW_ITEMS", "run_id": "run-1", "project_id": "1305",
              "approved_plan_hash": "p1", "mapping_results": [{"mapping_key": "calls", "partitions": []}]}
    runtime = _runtime(_Graph(values))
    restored = DeepAgentsRuntime._retry_approved_source_preparation(runtime, _invocation())
    assert restored == values and runtime._workflow_result == values
    assert runtime.traces == ["workflow.checkpoint.restored"]


def test_another_runs_checkpoint_or_an_unfinished_one_is_not_restored() -> None:
    other = {"status": "READY_FOR_REVIEW", "run_id": "run-9", "mapping_results": [{}]}
    assert DeepAgentsRuntime._retry_approved_source_preparation(_runtime(_Graph(other)), _invocation()) is None
    empty = {"status": "READY_FOR_REVIEW", "run_id": "run-1", "mapping_results": []}
    assert DeepAgentsRuntime._retry_approved_source_preparation(_runtime(_Graph(empty)), _invocation()) is None


def test_checkpoint_started_distinguishes_a_plan_that_never_executed() -> None:
    assert DeepAgentsRuntime._workflow_checkpoint_started(_runtime(_Graph({})), _invocation()) is False
    assert DeepAgentsRuntime._workflow_checkpoint_started(_runtime(_Graph({"status": "EXECUTING"})), _invocation()) is True
