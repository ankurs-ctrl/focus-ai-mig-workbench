const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),ts=require('typescript');
const root=path.resolve(__dirname,'../src/features/ai-agent');
const source=fs.readFileSync(path.join(root,'deep-agent-panel.tsx'),'utf8');
const ast=ts.createSourceFile('panel.tsx',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const compile=(text,context)=>vm.runInNewContext(ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,context);
function callback(name){let found;function visit(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ast)===name)found=n.initializer.arguments[0].getText(ast);ts.forEachChild(n,visit);}visit(ast);assert.ok(found,name);return found;}
function sender(active){
 let quick=[],deep=[],switched=0;
 const state={isActive:active,isRunning:false,isConnecting:false,isCancelling:false};
 const ctx={currentSendRef:{current:message=>{quick.push(message);return true;}},migrationAgentState:state,
  migrationAgentAvailable:true,migrationAttachmentUploading:false,pendingPlanOffer:null,
  connectAndSendMigrationAgentMessage:(...args)=>deep.push(args),chatLoading:false,chatMessages:[],migrationAgentMessages:[],
  activeProjectId:'project',migrationModelOptions:[],migrationAttachments:[],migrationContextUsage:null,
  handleMigrationAttachment:()=>{},toggleMigrationAgentMode:()=>switched++,setMigrationAgentState:()=>{},migrationAgentClientRef:{current:null}};
 return{ctx,quick,deep,api:()=>compile('('+callback('deepSendApi')+')',ctx)(),switched:()=>switched};
}
test('Quick page sender uses Quick handler; Deep page sender retains execution options',()=>{
 const q=sender(false);assert.equal(q.api().assistantMode,'quick');assert.equal(q.api().send('Explain source'),true);
 assert.deepEqual(q.quick,['Explain source']);assert.equal(q.deep.length,0);
 const d=sender(true),options={runMode:'plan',effort:'high',modelName:'configured'};
 assert.equal(d.api().send('Generate draft',options),true);assert.deepEqual(d.deep,[['Generate draft',options]]);
 assert.equal(d.quick.length,0);
});
test('current Quick handler is read at send time, so manual review state does not go stale',()=>{
 const q=sender(false),api=q.api();let seen=0;q.ctx.currentSendRef.current=()=>{seen++;return false;};
 assert.equal(api.send('Apply'),false);assert.equal(seen,1);assert.equal(q.deep.length,0);
});
test('page mode switch uses the shared panel switch and rejects unavailable Deep',()=>{
 const q=sender(false);q.api().onAssistantModeChange('deep');assert.equal(q.switched(),1);
 q.ctx.migrationAgentAvailable=false;q.api().onAssistantModeChange('deep');assert.equal(q.switched(),1);
});
test('live durable progress is visible on dedicated page and replay deduplicates messages',()=>{
 let messages=[],state={};
 const ctx={pageMode:true,animateMigrationAgentMessagesRef:{current:true},
  setMigrationAgentMessages:fn=>messages=fn(messages),setMigrationAgentState:fn=>state=fn(state),
  isSimilarProgress:(a,b)=>a===b,insertProgressBeforeFinal:(current,item)=>[...current,item]};
 const onMessage=compile('('+callback('handleMigrationAgentMessage')+')',ctx);
 const event={type:'assistant.progress',event_id:'progress-1',data:{text:'Read the approved source contracts.',durable_event_id:'progress-1'}};
 onMessage(event);assert.equal(messages.length,1);assert.equal(messages[0].animate,true);
 onMessage(event);assert.equal(messages.length,1);
 assert.equal(messages[0].content,event.data.text);
});
test('sidebar and dedicated page use the same panel with plan, SQL and results pane',()=>{
 assert.match(fs.readFileSync(path.join(root,'ai-chat-shell-host.tsx'),'utf8'),/import AIAgentPanel from .*deep-agent-panel/);
 assert.match(source,/<AgentArtifactPane/);assert.match(source,/onClose=\{\(\) => setPlanSidebarOpen\(false\)\}/);
 assert.match(source,/View plan revision/);assert.match(source,/View extraction SQL/);
 assert.match(source,/return <AssistantMarkdown content=\{normalized\}/);
});

test('page uses ZIP-style shared dropdown with both modes and above-menu placement',()=>{
 const composer=fs.readFileSync(path.join(root,'ai-agent-page-composer.tsx'),'utf8');
 assert.match(composer,/<AiaSelect[\s\S]*?value=\{assistantMode\}/);
 assert.match(composer,/menuPlacement="above"/);
 assert.match(composer,/label: "Quick Assistant", value: "quick"/);
 assert.match(composer,/label: "Deep Agent", value: "deep"/);
 assert.doesNotMatch(composer,/aria-pressed=\{assistantMode/);
});
