"""Bounded recovery operations. No dispatch, cancellation, credential fallback or expiry takeover.

The host supplies original caller-authenticated bundles and independently verified
retirement. A failed worker lease is NOT retirement. This module is deliberately
not invoked from status/health reads or model admission.
"""
from dataclasses import dataclass
import math
from threading import Event
import time

from app.core.automap_admission import Permit, request_digest
from app.core.automap_runtime import (
    ReconciliationResult, ReconciliationStatus, reconcile_parallel_runtime,
)
from app.core.automap_scan import ScanRequest
from app.core.automap_shards import MessageBudget, SnapshotScope
import json


def recover_archived_operation(bundle, *, permit: Permit, request_archive_ref: str,
                               retired_dispatcher: bool, deadline: float) -> ReconciliationResult:
    """Recover after process loss using the exact content-addressed original request.

    Never rebuild a prompt from current metadata. The caller must build the same
    original access/snapshot scope and agent bundle with fresh original-caller auth.
    Both archive reads and terminal GETs use this fresh bounded recovery deadline.
    Unknown archive formats/scopes are rejected without issuing a remote POST.
    """
    if retired_dispatcher is not True:
        raise ValueError("Verified dispatcher retirement required")
    if type(deadline) not in (int, float):
        raise ValueError("Recovery requires a numeric deadline")
    remaining = deadline - time.monotonic()
    if not math.isfinite(remaining) or not 0 < remaining <= 60:
        raise ValueError("Recovery deadline must be within 60 seconds")
    try:
        archive = bundle.archive.with_deadline(deadline)
        body = json.loads(archive.get(request_archive_ref))
        value = body['value']
        original = value['request']
        if (value['protocol'] != 'automap_fast_model_request_v1'
                or value['job_id'] != permit.identity.job_id
                or value['agent_fqn'] != bundle.backend._config.agent
                or body['scope'] != original['scope']
                or body['generation'] != original['generation']
                or original['generation'] != permit.identity.generation
                or original['shard_id'] != permit.identity.shard_id
                or original['scope'] != {'owner_id': bundle.scope.owner_id, 'snapshot_id': bundle.scope.snapshot_id}
                or bundle.admission.caller_id != permit.identity.caller_id):
            return ReconciliationResult(ReconciliationStatus.REJECTED)
        req = ScanRequest(scope=SnapshotScope(**original['scope']), generation=original['generation'],
            shard_id=original['shard_id'], target_ids=tuple(original['target_ids']),
            record_ids=tuple(original['record_ids']), message=original['message'],
            output_budget=MessageBudget(**original['output_budget']), deadline=deadline,
            _cancel=Event(), _stop=Event())
        if request_digest(req) != value['request_digest']:
            return ReconciliationResult(ReconciliationStatus.REJECTED)
        return reconcile_parallel_runtime(bundle, permit=permit, original_request=req,
            snapshot_archive_ref=value['snapshot_archive_ref'], retired_dispatcher=True, deadline=deadline)
    except Exception:
        # Original archive/auth failures cannot be turned into terminal completion.
        return ReconciliationResult(ReconciliationStatus.REJECTED)


@dataclass(frozen=True)
class RecoveryRetry:
    """Durable scheduler state. Persist next_attempt_at in UTC epoch seconds, not monotonic time."""
    attempts: int = 0
    next_attempt_at: float = 0

    def after_failure(self, now: float, *, jitter: float) -> 'RecoveryRetry':
        if (type(self.attempts) is not int or self.attempts < 0 or not math.isfinite(now)
                or not math.isfinite(jitter) or not 0 <= jitter <= 1):
            raise ValueError('Invalid recovery backoff')
        delay = min(3600, 15 * 2 ** min(self.attempts, 8)) * (.75 + .25 * jitter)
        return RecoveryRetry(self.attempts + 1, now + delay)
