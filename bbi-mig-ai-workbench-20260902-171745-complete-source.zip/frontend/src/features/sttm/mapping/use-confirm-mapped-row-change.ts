'use client';

import { useCallback, useState } from 'react';

import type { MappingState } from '@/features/sttm/types/sttm.types';

export type PendingMappedRowChange = {
  targetColumn: string;
  actionDescription: string;
  onConfirm: () => void;
};

export const MAPPED_ROW_CHANGE_MESSAGES = {
  transformRule:
    'Changing the transform rule will clear the current source mapping and confidence score.',
  sourceColumn:
    'Changing the source will replace the current mapping and clear the confidence score.',
  projectAttribute:
    'Changing the project value will replace the current mapping and clear the confidence score.',
  directPick:
    'Selecting a new source column will replace the current mapping and clear the confidence score.',
  preProcess:
    'Editing pre-process will modify the current mapping and clear the confidence score.',
  recommendation:
    'Applying this recommendation will replace the current mapping.',
} as const;

export function useConfirmMappedRowChange() {
  const [pendingChange, setPendingChange] = useState<PendingMappedRowChange | null>(null);

  const confirmIfMappedRowChange = useCallback((
    row: Pick<MappingState, 'status' | 'targetColumn'>,
    actionDescription: string,
    onConfirm: () => void,
  ) => {
    if (row.status !== 'MAPPED') {
      onConfirm();
      return;
    }

    setPendingChange({
      targetColumn: row.targetColumn,
      actionDescription,
      onConfirm,
    });
  }, []);

  const closeConfirm = useCallback(() => {
    setPendingChange(null);
  }, []);

  const confirmChange = useCallback(() => {
    pendingChange?.onConfirm();
    setPendingChange(null);
  }, [pendingChange]);

  return {
    pendingChange,
    confirmIfMappedRowChange,
    closeConfirm,
    confirmChange,
  };
}
