import threading
import time

from fastapi import Request

from app.auth.models import AppPersona, CurrentPrincipal, PermissionSet
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.config import Settings
from app.schema.common import TableRef
from app.schema.sttm_builder import (
    AttributeMapping,
    Interface,
    SourceMappingResult,
    STTMBuilderContext,
    STTMBuilderEnvelopeRequest,
    STTMBuilderRequestData,
    STTMBuilderResponse,
    STTMOperation,
    STTMStatus,
    SubAgent,
    TargetAttributeItem,
)


def _request(attribute_count: int = 6) -> STTMBuilderEnvelopeRequest:
    source = TableRef(database="DB", schema="SRC", table="SOURCE")
    target = TableRef(database="DB", schema="TGT", table="TARGET")
    return STTMBuilderEnvelopeRequest(
        request_id="request-123",
        operation=STTMOperation.AUTO_MAP,
        context=STTMBuilderContext(source_tables=[source], target_table=target),
        data=STTMBuilderRequestData(
            intent=Interface.AUTO_MAP,
            attributes=[
                TargetAttributeItem(
                    target_table=target,
                    target_attribute=f"COL_{index}",
                )
                for index in range(attribute_count)
            ],
        ),
    )


def _response(req: STTMBuilderEnvelopeRequest) -> STTMBuilderResponse:
    mappings = {
        item.target_attribute: AttributeMapping(
            source_attributes=[f"DB.SRC.SOURCE.{item.target_attribute}"],
            confidence_score=0.9,
        )
        for item in req.data.attributes or []
    }
    return STTMBuilderResponse.from_invocation(
        req,
        thread_id="worker-thread",
        parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT,
        result=SourceMappingResult(mappings=mappings),
        message="ok",
        status=STTMStatus.COMPLETED,
    )


def test_proxy_fans_out_two_batches_and_preserves_mapping_order(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTH_MODE="custom_oauth",
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=2,
        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request()
    http_request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    http_request.state.current_principal = CurrentPrincipal(
        user_id=1,
        snowflake_user="ALICE",
        email="alice@example.com",
        display_name="Alice",
        app_persona=AppPersona.ADMIN,
        permissions=PermissionSet(can_read=True, can_edit=True),
        snowflake_user_token="oauth-secret-token",
        snowflake_role="FOCUS_ADMIN",
    )

    lock = threading.Lock()
    active = 0
    max_active = 0
    captured_headers: list[dict[str, str]] = []
    captured_payloads: list[str] = []

    def fake_invoke_batch(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        nonlocal active, max_active
        with lock:
            active += 1
            max_active = max(max_active, active)
            captured_headers.append(headers)
            captured_payloads.append(req.model_dump_json())
        time.sleep(0.03 if batch_index == 0 else 0.01)
        with lock:
            active -= 1
        return _response(req)

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke_batch)

    result = proxy.invoke(http_request, envelope)

    assert max_active == 2
    assert list(result.result.mappings) == [f"COL_{index}" for index in range(6)]
    assert result.contract_version == "1.0"
    assert result.meta["auto_mapping_dispatch"] == {
        "attribute_count": 6,
        "batch_count": 3,
        "batch_size": 2,
        "max_in_flight": 2,
        "failed_batches": [],
    }
    assert all(item["X-Workbench-OAuth-Access-Token"] == "oauth-secret-token" for item in captured_headers)
    assert all("oauth-secret-token" not in item for item in captured_payloads)


def test_async_job_completes_without_holding_the_ingress_request(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTH_MODE="custom_oauth",
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=17,
        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=2)
    http_request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    http_request.state.current_principal = CurrentPrincipal(
        user_id=1,
        snowflake_user="ALICE",
        email="alice@example.com",
        display_name="Alice",
        app_persona=AppPersona.ADMIN,
        permissions=PermissionSet(can_read=True, can_edit=True),
        snowflake_user_token="oauth-secret-token",
        snowflake_role="FOCUS_ADMIN",
    )
    monkeypatch.setattr(
        proxy,
        "_invoke_with_headers",
        lambda req, *, headers: _response(req),
    )

    started = proxy.start_job(http_request, envelope)
    assert started["status"] in {"queued", "running", "completed"}
    for _ in range(100):
        job = proxy.get_job(http_request, started["job_id"])
        if job["status"] == "completed":
            break
        time.sleep(0.01)

    assert job["status"] == "completed"
    assert job["response"]["contract_version"] == "1.0"
    assert "owner" not in job
