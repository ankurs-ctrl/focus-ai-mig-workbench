"""Agent-specific learning retrieval service.

This service provides per-agent learning storage and retrieval using Cortex Search
for semantically relevant learnings.
"""
from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from uuid import uuid4

from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.learning_subjects import target_column_subject

logger = logging.getLogger(__name__)


@dataclass
class AgentLearning:
    """A learning record for a specific agent."""

    learning_id: str
    agent_type: str
    learning_type: str
    summary: str
    confidence: float
    attributes: dict[str, Any]
    subject_type: str | None = None
    subject_key: str | None = None
    claim_key: str | None = None
    trust_stage: str = "evidence"
    evidence_ids: list[str] = field(default_factory=list)
    entity_type: str | None = None
    entity_ids: dict[str, Any] | None = None
    tags: list[str] | None = None
    usage_count: int = 0
    success_count: int = 0
    relevance_score: float = 0.0
    created_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "learning_id": self.learning_id,
            "agent_type": self.agent_type,
            "learning_type": self.learning_type,
            "summary": self.summary,
            "confidence": self.confidence,
            "attributes": self.attributes,
            "subject_type": self.subject_type,
            "subject_key": self.subject_key,
            "claim_key": self.claim_key,
            "trust_stage": self.trust_stage,
            "evidence_ids": self.evidence_ids,
            "entity_type": self.entity_type,
            "entity_ids": self.entity_ids,
            "tags": self.tags,
            "usage_count": self.usage_count,
            "success_count": self.success_count,
            "relevance_score": self.relevance_score,
        }


class AgentLearningService:
    """Service for per-agent learning storage and retrieval."""

    AGENT_TYPES = {
        "SOURCE_MAPPING": "CSS_SOURCE_MAPPING_LEARNINGS",
        "TRANSFORMATION_RULE": "CSS_TRANSFORMATION_LEARNINGS",
        "STTM_BUILDER": "CSS_STTM_BUILDER_LEARNINGS",
    }

    def __init__(self, session: Session, settings: Settings):
        self._session = session
        self._settings = settings
        self._schema = f"{settings.snowflake_database}.{settings.snowflake_schema}"
        self._record_procedure_available: bool | None = None
        self._usage_procedure_available: bool | None = None

    def get_agent_learnings(
        self,
        agent_type: str,
        query_context: dict[str, Any],
        max_results: int = 10,
    ) -> list[AgentLearning]:
        """Retrieve relevant learnings for a specific agent using Cortex Search.

        Args:
            agent_type: The agent type (SOURCE_MAPPING, TRANSFORMATION_RULE, etc.)
            query_context: Context to search against (target columns, source tables, etc.)
            max_results: Maximum number of learnings to return

        Returns:
            List of relevant AgentLearning objects sorted by relevance
        """
        search_service = self.AGENT_TYPES.get(agent_type)
        if not search_service:
            logger.warning("Unknown agent type: %s, falling back to SQL query", agent_type)
            return self._get_learnings_sql(agent_type, query_context, max_results)

        search_query = self._build_search_query(query_context)
        if not search_query:
            logger.debug("Empty search query for agent %s", agent_type)
            return []

        try:
            full_service_name = f"{self._schema}.{search_service}"
            results = self._session.sql(f"""
                SELECT *
                FROM TABLE(
                    {full_service_name}!SEARCH(
                        query => '{self._escape_sql(search_query)}',
                        columns => ['SEARCH_TEXT'],
                        limit => {max_results}
                    )
                )
                ORDER BY RELEVANCE_SCORE DESC
            """).collect()

            return [self._parse_learning(row.as_dict()) for row in results]
        except Exception as exc:
            logger.warning(
                "Cortex Search failed for agent %s, falling back to SQL: %s",
                agent_type,
                exc,
            )
            return self._get_learnings_sql(agent_type, query_context, max_results)

    def get_correction_history(
        self,
        agent_type: str,
        target_columns: list[str],
        max_results: int = 10,
        *,
        target_table: str | None = None,
        project_id: str | None = None,
        linked_project_ids: list[str] | None = None,
    ) -> list[AgentLearning]:
        """Get correction history for specific target columns.

        This is critical for avoiding repeated mistakes.
        """
        if not target_columns:
            return []

        target_cols_sql = ", ".join(f"'{self._escape_sql(c)}'" for c in target_columns)
        allowed_projects = [project_id] if project_id else []
        allowed_projects.extend(linked_project_ids or [])
        project_predicate = (
            "AND ENTITY_IDS:project_id::STRING IN ("
            + ", ".join(f"'{self._escape_sql(value)}'" for value in sorted(set(allowed_projects)) if value)
            + ")"
            if any(allowed_projects)
            else "AND 1 = 0"
        )
        target_predicate = (
            f"AND UPPER(ATTRIBUTES:target_table::STRING) = UPPER('{self._escape_sql(target_table)}')"
            if target_table
            else "AND ATTRIBUTES:target_table IS NOT NULL"
        )

        try:
            rows = self._session.sql(f"""
                SELECT *
                FROM {self._schema}.TBL_AGENT_LEARNINGS
                WHERE AGENT_TYPE = '{agent_type}'
                  AND LEARNING_TYPE IN ('mapping_correction', 'mapping_edit')
                  AND STATUS = 'active'
                  {project_predicate}
                  {target_predicate}
                  AND (
                      ATTRIBUTES:target_column::STRING IN ({target_cols_sql})
                      OR ARRAY_CONTAINS('{self._escape_sql(target_columns[0])}'::VARIANT, ATTRIBUTES:target_columns::ARRAY)
                  )
                ORDER BY CONFIDENCE DESC, CREATED_AT DESC
                LIMIT {max_results}
            """).collect()

            return [self._parse_learning(row.as_dict()) for row in rows]
        except Exception as exc:
            logger.warning("Failed to get correction history: %s", exc)
            return []

    def get_similar_mappings(
        self,
        target_column: str,
        source_tables: list[str],
        project_id: str | None = None,
        max_results: int = 5,
    ) -> list[AgentLearning]:
        """Get similar accepted mappings for a target column."""
        search_terms = [target_column] + source_tables[:3]
        search_query = " ".join(search_terms)

        try:
            full_service_name = f"{self._schema}.CSS_SOURCE_MAPPING_LEARNINGS"
            rows = self._session.sql(f"""
                SELECT *
                FROM TABLE(
                    {full_service_name}!SEARCH(
                        query => '{self._escape_sql(search_query)}',
                        columns => ['SEARCH_TEXT'],
                        filter => {{'LEARNING_TYPE': 'mapping_acceptance'}},
                        limit => {max_results}
                    )
                )
                ORDER BY RELEVANCE_SCORE DESC
            """).collect()

            return [self._parse_learning(row.as_dict()) for row in rows]
        except Exception as exc:
            logger.warning("Failed to get similar mappings via Cortex Search: %s", exc)
            return self._get_similar_mappings_sql(target_column, source_tables, project_id, max_results)

    def record_learning(
        self,
        agent_type: str,
        learning_type: str,
        summary: str,
        attributes: dict[str, Any],
        entity_type: str | None = None,
        entity_ids: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        confidence: float = 0.7,
        user_id: str | None = None,
        strict: bool = False,
        subject_type: str | None = None,
        subject_key: str | None = None,
        claim_key: str | None = None,
        trust_stage: str = "evidence",
        evidence_ids: list[str] | None = None,
    ) -> str:
        """Record a new learning for an agent.

        Returns:
            The learning_id of the created or updated learning
        """
        from app.core.learning_evidence import capture_attributes, captured_learning_key

        attributes = capture_attributes(attributes, entity_ids)
        if attributes["trust_stage"] != "observation":
            from app.core.learning_receipts import verify_receipts
            if "capture" not in verify_receipts(self._session, self._settings, [("capture", attributes, entity_ids or {})]):
                raise ValueError("Learning receipt does not match durable capture authority")
        learning_id = f"lrn_{uuid4().hex[:16]}"
        learning_key = captured_learning_key(agent_type, learning_type, attributes) or self._generate_learning_key(
            agent_type, learning_type, {"attributes": attributes, "entity_ids": entity_ids},
        )

        if strict:
            # Retryable projections use deterministic DML, not a procedure that
            # may increase support on every replay or hide a failed write.
            resolved_id = self._record_learning_direct(
                f"lrn_{learning_key[:24]}", agent_type, learning_type, learning_key,
                summary, attributes, entity_type, entity_ids, tags, confidence, user_id,
            )
            self._invalidate_prepared_learning_contexts()
            return resolved_id

        if self._record_procedure_available is not False and not subject_key:
            try:
                result = self._session.sql(f"""
                    CALL {self._schema}.SP_RECORD_AGENT_LEARNING(
                        ?, ?, ?, PARSE_JSON(?), ?, PARSE_JSON(?),
                        PARSE_JSON(?)::ARRAY, ?, ?
                    )
                """, params=[
                    agent_type, learning_type, summary, json.dumps(attributes),
                    entity_type, json.dumps(entity_ids) if entity_ids is not None else None,
                    json.dumps(tags) if tags is not None else None, confidence, user_id,
                ]).collect()
                self._record_procedure_available = True
                if result and result[0][0]:
                    resolved_id = str(result[0][0])
                else:
                    raise ValueError("Learning procedure did not return a persisted active record")
                self._invalidate_prepared_learning_contexts()
                return resolved_id
            except Exception as exc:
                if self._is_missing_procedure(exc, "SP_RECORD_AGENT_LEARNING"):
                    if self._record_procedure_available is not False:
                        logger.warning(
                            "SP_RECORD_AGENT_LEARNING is unavailable; using direct "
                            "TBL_AGENT_LEARNINGS MERGE for this process."
                        )
                    self._record_procedure_available = False
                else:
                    logger.warning(
                        "SP_RECORD_AGENT_LEARNING failed; using direct MERGE: %s",
                        exc,
                    )

        resolved_id = self._record_learning_direct(
            learning_id,
            agent_type,
            learning_type,
            learning_key,
            summary,
            attributes,
            entity_type,
            entity_ids,
            tags,
            confidence,
            user_id,
            subject_type,
            subject_key,
            claim_key,
            trust_stage,
            evidence_ids or [],
        )
        self._invalidate_prepared_learning_contexts()
        return resolved_id

    def _invalidate_prepared_learning_contexts(self) -> None:
        from app.core.learning_retrieval import invalidate_learning_context_cache

        invalidate_learning_context_cache()
        try:
            table_name = self._settings.qualify_metadata_object_name(
                "TBL_PREPARED_LEARNING_CONTEXTS"
            )
            self._session.sql(f"DELETE FROM {table_name}").collect()
        except Exception as exc:
            logger.debug("Durable prepared FIR context invalidation unavailable: %s", exc)

    def track_learning_usage(
        self,
        learning_id: str,
        was_successful: bool = True,
    ) -> None:
        """Track that a learning was used and whether it was successful."""
        if self._usage_procedure_available is not False:
            try:
                self._session.sql(f"""
                    CALL {self._schema}.SP_TRACK_LEARNING_USAGE(
                        '{learning_id}',
                        {str(bool(was_successful)).upper()}
                    )
                """).collect()
                self._usage_procedure_available = True
                return
            except Exception as exc:
                if self._is_missing_procedure(exc, "SP_TRACK_LEARNING_USAGE"):
                    self._usage_procedure_available = False
                else:
                    logger.warning(
                        "SP_TRACK_LEARNING_USAGE failed; using direct UPDATE: %s",
                        exc,
                    )
        try:
            self._session.sql(f"""
                UPDATE {self._schema}.TBL_AGENT_LEARNINGS
                SET USAGE_COUNT = COALESCE(USAGE_COUNT, 0) + 1,
                    SUCCESS_COUNT = COALESCE(SUCCESS_COUNT, 0)
                        + {1 if was_successful else 0},
                    LAST_USED_AT = CURRENT_TIMESTAMP()
                WHERE LEARNING_ID = '{self._escape_sql(learning_id)}'
            """).collect()
        except Exception as exc:
            logger.warning("Failed to track learning usage directly: %s", exc)

    def record_validation_outcome(
        self,
        learning_ids: list[str],
        *,
        passed: bool,
        evidence_id: str,
    ) -> None:
        """Attach validation evidence without turning an unaccepted inference into truth."""
        for learning_id in sorted(set(value for value in learning_ids if value)):
            try:
                self._session.sql(
                    f"""
                    UPDATE {self._schema}.TBL_AGENT_LEARNINGS
                    SET USAGE_COUNT = COALESCE(USAGE_COUNT, 0) + 1,
                        SUCCESS_COUNT = COALESCE(SUCCESS_COUNT, 0) + ?,
                        TRUST_STAGE = IFF(? AND TRUST_STAGE = 'outcome', 'validated', TRUST_STAGE),
                        EVIDENCE_IDS = ARRAY_DISTINCT(ARRAY_CAT(
                            COALESCE(EVIDENCE_IDS, ARRAY_CONSTRUCT()), ARRAY_CONSTRUCT(?)
                        )),
                        LAST_USED_AT = CURRENT_TIMESTAMP()
                    WHERE LEARNING_ID = ?
                      AND TRUST_STAGE <> 'superseded'
                    """,
                    [1 if passed else 0, passed, evidence_id, learning_id],
                ).collect()
            except Exception as exc:
                logger.warning("Failed to record validation outcome for %s: %s", learning_id, exc)

    def record_mapping_acceptance(
        self,
        target_column: str,
        source_columns: list[str],
        preprocessing_rule: str,
        preprocessing_rule_type: str,
        confidence_score: float,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
        target_table: str | None = None,
        source_tables: list[str] | None = None,
        provenance: str | None = None,
        strict: bool = False,
    ) -> str:
        """Record a mapping acceptance as a SOURCE_MAPPING learning."""
        target_label = (
            f"{target_table}.{target_column}"
            if target_table
            else target_column
        )
        summary = (
            f"Accepted mapping: {', '.join(source_columns)} -> {target_label} "
            f"using {preprocessing_rule_type}"
        )

        attributes = {
            "target_column": target_column,
            "target_table": target_table,
            "source_columns": source_columns,
            "source_tables": source_tables or [],
            "preprocessing_rule": preprocessing_rule,
            "preprocessing_rule_type": preprocessing_rule_type,
            "confidence_score": confidence_score,
            "provenance": provenance,
        }

        tags = [f"rule:{preprocessing_rule_type}", f"target:{target_column}"]
        if target_table:
            tags.append(f"target_table:{target_table}")
        tags.extend(f"source_table:{table}" for table in (source_tables or []))
        subject_key = (
            target_column_subject(target_table, target_column)
            if target_table
            else f"mapping_row:{sttm_id}:{target_column.upper()}"
        )
        return self.record_learning(
            agent_type="SOURCE_MAPPING",
            learning_type="mapping_acceptance",
            summary=summary,
            attributes=attributes,
            subject_type="target_column" if target_table else "mapping_row",
            subject_key=subject_key,
            claim_key="preferred_source_recipe",
            trust_stage="outcome",
            entity_type="mapping_row",
            entity_ids={"project_id": project_id, "sttm_id": sttm_id},
            tags=tags,
            confidence=min(1.0, confidence_score + 0.1),
            user_id=user_id,
            strict=strict,
        )

    def record_mapping_correction(
        self,
        target_column: str,
        incorrect_source: list[str],
        correct_source: list[str],
        error_category: str,
        prevention_hint: str,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
        strict: bool = False,
        target_table: str | None = None,
    ) -> str:
        """Record a mapping correction to avoid repeating mistakes."""
        summary = f"Correction for {target_column}: avoid {incorrect_source}, use {correct_source}. {prevention_hint}"

        attributes = {
            "target_column": target_column,
            "target_table": target_table,
            "incorrect_source": incorrect_source,
            "correct_source": correct_source,
            "error_category": error_category,
            "prevention_hint": prevention_hint,
        }

        subject_key = (
            target_column_subject(target_table, target_column)
            if target_table
            else f"mapping_row:{sttm_id}:{target_column.upper()}"
        )
        # A correction is authoritative negative feedback for the same claim.
        # Keep history, but remove prior outcomes from future retrieval before
        # writing the replacement outcome.
        try:
            self._session.sql(
                f"""
                UPDATE {self._schema}.TBL_AGENT_LEARNINGS
                SET TRUST_STAGE = 'superseded'
                WHERE STATUS = 'active'
                  AND SUBJECT_KEY = '{self._escape_sql(subject_key)}'
                  AND CLAIM_KEY = 'preferred_source_recipe'
                  AND TRUST_STAGE IN ('outcome', 'validated')
                """
            ).collect()
        except Exception as exc:
            logger.warning("Failed to supersede prior mapping outcomes: %s", exc)

        return self.record_learning(
            agent_type="SOURCE_MAPPING",
            learning_type="mapping_correction",
            summary=summary,
            attributes=attributes,
            subject_type="target_column" if target_table else "mapping_row",
            subject_key=subject_key,
            claim_key="preferred_source_recipe",
            trust_stage="outcome",
            entity_type="mapping_row",
            entity_ids={"project_id": project_id, "sttm_id": sttm_id},
            tags=[f"error:{error_category}", f"target:{target_column}"],
            confidence=0.9,
            user_id=user_id,
            strict=strict,
        )

    def record_transformation_pattern(
        self,
        rule_type: str,
        rule_expression: str,
        description: str,
        source_columns: list[str],
        target_column: str,
        project_id: str,
        sttm_id: str,
        user_id: str | None = None,
    ) -> str:
        """Record a transformation rule pattern."""
        summary = f"Transformation pattern: {rule_type} for {target_column}. {description}"

        attributes = {
            "rule_type": rule_type,
            "rule_expression": rule_expression,
            "description": description,
            "source_columns": source_columns,
            "target_column": target_column,
        }

        return self.record_learning(
            agent_type="TRANSFORMATION_RULE",
            learning_type="transformation_pattern",
            summary=summary,
            attributes=attributes,
            entity_type="transformation",
            entity_ids={"project_id": project_id, "sttm_id": sttm_id},
            tags=[f"rule_type:{rule_type}", f"target:{target_column}"],
            confidence=0.8,
            user_id=user_id,
        )

    # ─── Private helpers ───────────────────────────────────────────────

    def _build_search_query(self, query_context: dict[str, Any]) -> str:
        """Build a search query from the context."""
        parts = []

        if "target_columns" in query_context:
            parts.extend(query_context["target_columns"][:5])

        if "source_tables" in query_context:
            for table in query_context["source_tables"][:3]:
                if isinstance(table, dict):
                    parts.append(table.get("table", ""))
                else:
                    parts.append(str(table).split(".")[-1])

        if "target_table" in query_context:
            target = query_context["target_table"]
            if isinstance(target, dict):
                parts.append(target.get("table", ""))
            else:
                parts.append(str(target).split(".")[-1])

        if "intent" in query_context:
            parts.append(str(query_context["intent"]))

        return " ".join(filter(None, parts))

    def get_scoped_mapping_learnings(
        self, *, agent_type: str, project_id: str, target_table: str,
        target_columns: list[str], max_results: int = 30,
    ) -> list[AgentLearning]:
        """Strict local evidence; reusable cross-project recipes use the pattern service.

        Unlike the legacy search fallback this fails visibly and never retrieves
        another project's values based solely on a shared target column name.
        """
        if not project_id or not target_columns:
            return []
        columns = ", ".join("'" + self._escape_sql(column.upper()) + "'" for column in target_columns)
        rows = self._session.sql(f"""
            SELECT * FROM {self._schema}.TBL_AGENT_LEARNINGS
            WHERE AGENT_TYPE = '{self._escape_sql(agent_type)}'
              AND STATUS = 'active' AND SUPERSEDED_BY IS NULL
              AND LOWER(COALESCE(NULLIF(TRUST_STAGE, ''), ATTRIBUTES:validation_status::STRING, ''))
                  IN ('accepted', 'corrected', 'validated', 'published', 'approved')
              AND ENTITY_IDS:project_id::STRING = '{self._escape_sql(project_id)}'
              AND UPPER(ATTRIBUTES:target_column::STRING) IN ({columns})
              AND (UPPER(ATTRIBUTES:target_table::STRING) = '{self._escape_sql(target_table.upper())}'
                   OR ATTRIBUTES:target_table IS NULL)
            ORDER BY CONFIDENCE DESC, CREATED_AT DESC
            LIMIT {max(1, min(max_results, 100))}
        """).collect()
        from app.core.learning_receipts import verify_receipts
        records = [row.as_dict() for row in rows]
        def as_object(value):
            return json.loads(value) if isinstance(value, str) else value or {}
        versioned = [(str(row["LEARNING_ID"]), as_object(row.get("ATTRIBUTES")), as_object(row.get("ENTITY_IDS")))
                     for row in records if as_object(row.get("ATTRIBUTES")).get("learning_contract_version")]
        verified = verify_receipts(self._session, self._settings, versioned)
        versioned_ids = {identity for identity, _, _ in versioned}
        return [self._parse_learning(row) for row in records
                if str(row["LEARNING_ID"]) not in versioned_ids or str(row["LEARNING_ID"]) in verified]

    def _get_learnings_sql(
        self,
        agent_type: str,
        query_context: dict[str, Any],
        max_results: int,
    ) -> list[AgentLearning]:
        """Fallback SQL-based learning retrieval."""
        try:
            rows = self._session.sql(f"""
                SELECT *
                FROM {self._schema}.TBL_AGENT_LEARNINGS
                WHERE AGENT_TYPE = '{agent_type}'
                  AND STATUS = 'active'
                ORDER BY CONFIDENCE DESC, USAGE_COUNT DESC, CREATED_AT DESC
                LIMIT {max_results}
            """).collect()

            return [self._parse_learning(row.as_dict()) for row in rows]
        except Exception as exc:
            logger.error("SQL learning retrieval failed: %s", exc)
            return []

    def _get_similar_mappings_sql(
        self,
        target_column: str,
        source_tables: list[str],
        project_id: str | None,
        max_results: int,
    ) -> list[AgentLearning]:
        """Fallback SQL-based similar mappings retrieval."""
        try:
            project_filter = ""
            if project_id:
                project_filter = f"AND ENTITY_IDS:project_id::STRING != '{project_id}'"

            rows = self._session.sql(f"""
                SELECT *
                FROM {self._schema}.TBL_AGENT_LEARNINGS
                WHERE AGENT_TYPE = 'SOURCE_MAPPING'
                  AND LEARNING_TYPE = 'mapping_acceptance'
                  AND STATUS = 'active'
                  AND (
                      ATTRIBUTES:target_column::STRING ILIKE '%{self._escape_sql(target_column)}%'
                      OR SUMMARY ILIKE '%{self._escape_sql(target_column)}%'
                  )
                  {project_filter}
                ORDER BY CONFIDENCE DESC, USAGE_COUNT DESC
                LIMIT {max_results}
            """).collect()

            return [self._parse_learning(row.as_dict()) for row in rows]
        except Exception as exc:
            logger.error("SQL similar mappings retrieval failed: %s", exc)
            return []

    def _parse_learning(self, row: dict[str, Any]) -> AgentLearning:
        """Parse a database row into an AgentLearning object."""
        attributes = row.get("ATTRIBUTES") or {}
        if isinstance(attributes, str):
            try:
                attributes = json.loads(attributes)
            except json.JSONDecodeError:
                attributes = {}

        entity_ids = row.get("ENTITY_IDS") or {}
        if isinstance(entity_ids, str):
            try:
                entity_ids = json.loads(entity_ids)
            except json.JSONDecodeError:
                entity_ids = {}

        tags = row.get("TAGS") or []
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except json.JSONDecodeError:
                tags = []

        return AgentLearning(
            learning_id=str(row.get("LEARNING_ID", "")),
            agent_type=str(row.get("AGENT_TYPE", "")),
            learning_type=str(row.get("LEARNING_TYPE", "")),
            summary=str(row.get("SEARCH_TEXT") or row.get("SUMMARY", "")),
            confidence=float(row.get("CONFIDENCE", 0.5)),
            attributes=attributes,
            subject_type=row.get("SUBJECT_TYPE"),
            subject_key=row.get("SUBJECT_KEY"),
            claim_key=row.get("CLAIM_KEY"),
            trust_stage=str(row.get("TRUST_STAGE") or "evidence"),
            evidence_ids=list(row.get("EVIDENCE_IDS") or []),
            entity_type=row.get("ENTITY_TYPE"),
            entity_ids=entity_ids,
            tags=tags,
            usage_count=int(row.get("USAGE_COUNT", 0)),
            success_count=int(row.get("SUCCESS_COUNT", 0)),
            relevance_score=float(row.get("RELEVANCE_SCORE", 0.0)),
            created_at=row.get("CREATED_AT"),
        )

    def _generate_learning_key(
        self,
        agent_type: str,
        learning_type: str,
        attributes: dict[str, Any],
    ) -> str:
        """Generate a unique key for deduplication."""
        key_data = f"{agent_type}|{learning_type}|{json.dumps(attributes, sort_keys=True)}"
        return hashlib.md5(key_data.encode()).hexdigest()

    def _record_learning_direct(
        self,
        learning_id: str,
        agent_type: str,
        learning_type: str,
        learning_key: str,
        summary: str,
        attributes: dict[str, Any],
        entity_type: str | None,
        entity_ids: dict[str, Any] | None,
        tags: list[str] | None,
        confidence: float,
        user_id: str | None,
        subject_type: str | None = None,
        subject_key: str | None = None,
        claim_key: str | None = None,
        trust_stage: str = "evidence",
        evidence_ids: list[str] | None = None,
    ) -> str:
        """Direct deduplicating MERGE when the helper procedure is unavailable."""
        from app.core.learning_evidence import capture_attributes, capture_evidence_ids

        attributes = capture_attributes(attributes, entity_ids)
        try:
            self._session.sql(f"""
                MERGE INTO {self._schema}.TBL_AGENT_LEARNINGS target
                USING (
                    SELECT
                        ? AS LEARNING_ID,
                        ? AS AGENT_TYPE,
                        ? AS LEARNING_TYPE,
                        ? AS LEARNING_KEY,
                        ? AS SUMMARY,
                        ?::FLOAT AS CONFIDENCE,
                        ? AS ENTITY_TYPE,
                        PARSE_JSON(?) AS ENTITY_IDS,
                        PARSE_JSON(?) AS ATTRIBUTES,
                        ? AS TRUST_STAGE,
                        PARSE_JSON(?) AS EVIDENCE_IDS,
                        PARSE_JSON(?)::ARRAY AS TAGS,
                        ? AS CREATED_BY
                ) source
                ON target.LEARNING_KEY = source.LEARNING_KEY
                WHEN MATCHED AND target.STATUS = 'active' AND target.SUPERSEDED_BY IS NULL THEN UPDATE SET
                    SUMMARY = source.SUMMARY,
                    CONFIDENCE = GREATEST(
                        COALESCE(target.CONFIDENCE, 0),
                        source.CONFIDENCE
                    ),
                    ENTITY_TYPE = COALESCE(source.ENTITY_TYPE, target.ENTITY_TYPE),
                    ENTITY_IDS = COALESCE(source.ENTITY_IDS, target.ENTITY_IDS),
                    ATTRIBUTES = source.ATTRIBUTES,
                    TRUST_STAGE = source.TRUST_STAGE,
                    EVIDENCE_IDS = source.EVIDENCE_IDS,
                    TAGS = COALESCE(source.TAGS, target.TAGS),
                    LAST_USED_AT = CURRENT_TIMESTAMP()
                WHEN NOT MATCHED THEN INSERT (
                    LEARNING_ID, AGENT_TYPE, LEARNING_TYPE, LEARNING_KEY, SUMMARY,
                    CONFIDENCE, ENTITY_TYPE, ENTITY_IDS, ATTRIBUTES, TAGS,
                    CREATED_BY, STATUS, TRUST_STAGE, EVIDENCE_IDS
                ) VALUES (
                    source.LEARNING_ID, source.AGENT_TYPE, source.LEARNING_TYPE,
                    source.LEARNING_KEY, source.SUMMARY, source.CONFIDENCE,
                    source.ENTITY_TYPE, source.ENTITY_IDS, source.ATTRIBUTES,
                    source.TAGS, source.CREATED_BY, 'active', source.TRUST_STAGE, source.EVIDENCE_IDS
                )
            """, params=[
                learning_id, agent_type, learning_type, learning_key, summary, confidence,
                entity_type, json.dumps(entity_ids) if entity_ids is not None else None,
                json.dumps(attributes), attributes['trust_stage'],
                json.dumps(capture_evidence_ids(attributes)),
                json.dumps(tags) if tags is not None else None, user_id,
            ]).collect()
            rows = self._session.sql(f"""
                SELECT LEARNING_ID
                FROM {self._schema}.TBL_AGENT_LEARNINGS
                WHERE LEARNING_KEY = ?
                  AND STATUS = 'active'
                  AND SUPERSEDED_BY IS NULL
                ORDER BY CREATED_AT DESC
                LIMIT 1
            """, params=[learning_key]).collect()
            if not rows or not rows[0][0]:
                raise ValueError("Learning was not persisted as an active record; it may have been revoked")
            return str(rows[0][0])
        except Exception as exc:
            logger.error("Direct learning insert failed: %s", exc)
            raise

    @staticmethod
    def _is_missing_procedure(exc: Exception, procedure_name: str) -> bool:
        message = str(exc).upper()
        return procedure_name.upper() in message and any(
            marker in message
            for marker in (
                "UNKNOWN USER-DEFINED FUNCTION",
                "UNKNOWN FUNCTION",
                "DOES NOT EXIST",
                "NOT EXIST",
            )
        )

    def _escape_sql(self, value: str) -> str:
        """Escape single quotes in SQL strings."""
        return value.replace("'", "''")

    def _quote_or_null(self, value: str | None) -> str:
        """Return quoted value or NULL."""
        if value is None:
            return "NULL"
        return f"'{self._escape_sql(value)}'"

    def _json_or_null(self, value: Any | None) -> str:
        """Return PARSE_JSON or NULL."""
        if value is None:
            return "NULL"
        return f"PARSE_JSON('{self._escape_sql(json.dumps(value))}')"

    def _array_or_null(self, value: list | None) -> str:
        """Return ARRAY_CONSTRUCT or NULL."""
        if value is None:
            return "NULL"
        items = ", ".join(f"'{self._escape_sql(str(v))}'" for v in value)
        return f"ARRAY_CONSTRUCT({items})"
