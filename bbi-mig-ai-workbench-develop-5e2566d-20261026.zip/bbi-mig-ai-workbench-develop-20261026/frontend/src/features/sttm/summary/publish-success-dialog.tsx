"use client";

import { AiaBox, AiaButton } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import { CheckCircleRoundedIcon } from "@/utils/icons";

type PublishSuccessDialogProps = {
  open: boolean;
  mappingName: string;
  /** Project the mapping was published to; the row is hidden when unknown. */
  projectName?: string | null;
  /** "Go to Mappings". */
  onConfirm: () => void;
  /** "Stay here": close the popup and remain on the current screen. */
  onStay: () => void;
};

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <>
      <AiaBox component="dt" sx={{ m: 0, color: "#64748B", fontWeight: 600 }}>
        {label}
      </AiaBox>
      <AiaBox
        component="dd"
        sx={{ m: 0, color: "var(--aia-text-color)", fontWeight: 700, overflowWrap: "anywhere" }}
      >
        {value}
      </AiaBox>
    </>
  );
}

/**
 * Shown after Publish Mapping succeeds. Only its buttons close it (backdrop clicks do
 * nothing): "Stay here" closes it, "Go to Mappings" continues to the Mappings list.
 */
export default function PublishSuccessDialog({
  open,
  mappingName,
  projectName,
  onConfirm,
  onStay,
}: PublishSuccessDialogProps) {
  if (!open) return null;

  return (
    <AiaBox
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="publish-success-title"
      aria-describedby="publish-success-message"
      sx={{
        position: "fixed",
        inset: 0,
        zIndex: 1500,
        px: 2,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "rgba(15, 23, 42, 0.42)",
        backdropFilter: "blur(4px)",
      }}
    >
      <AiaBox
        sx={{
          width: "100%",
          maxWidth: 540,
          borderRadius: "16px",
          border: "1px solid rgba(15, 23, 42, 0.08)",
          boxShadow: "0 30px 60px rgba(15, 23, 42, 0.18)",
          backgroundColor: "#FFFFFF",
          overflow: "hidden",
        }}
      >
        <AiaBox sx={{ px: 3, pt: 3, pb: 1.25, display: "flex", alignItems: "center", gap: 1 }}>
          <CheckCircleRoundedIcon sx={{ fontSize: 28, color: "#16A34A", flexShrink: 0 }} />
          <AiaText
            id="publish-success-title"
            sx={{ ...textStyleCssVars("cardTitle"), letterSpacing: "-0.01em" }}
          >
            Mapping published
          </AiaText>
        </AiaBox>
        <AiaBox sx={{ px: 3, pb: 3, display: "flex", flexDirection: "column", gap: 1.5 }}>
          <AiaText
            id="publish-success-message"
            sx={{ fontSize: 15, color: "var(--aia-text-color)", lineHeight: 1.6 }}
          >
            Your mapping was published successfully. Go to Mappings to see it in the list, or
            stay here to keep reviewing it.
          </AiaText>
          <AiaBox
            component="dl"
            sx={{
              m: 0,
              px: 1.75,
              py: 1.25,
              borderRadius: "10px",
              border: "1px solid #E2E8F0",
              backgroundColor: "#F8FAFC",
              display: "grid",
              gridTemplateColumns: "auto minmax(0, 1fr)",
              columnGap: 1.5,
              rowGap: 0.75,
              fontSize: 14,
              lineHeight: 1.5,
            }}
          >
            <DetailRow label="Mapping" value={mappingName} />
            {projectName ? <DetailRow label="Project" value={projectName} /> : null}
          </AiaBox>
        </AiaBox>
        <AiaBox
          sx={{
            px: 3,
            py: 2,
            borderTop: "1px solid #EEF2F7",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 1.25,
          }}
        >
          {/* Ghost button: closes the popup and keeps the user on this screen. */}
          <AiaButton
            variant="text"
            onClick={onStay}
            sx={{
              height: 38,
              px: 1.5,
              borderRadius: "10px",
              fontSize: 14,
              fontWeight: 600,
              textTransform: "none",
              color: "#94A3B8",
              "&:hover": { backgroundColor: "#F8FAFC", color: "#64748B" },
            }}
          >
            Stay here
          </AiaButton>
          <AiaButton
            variant="contained"
            color="primary"
            autoFocus
            onClick={onConfirm}
            sx={{
              minWidth: 140,
              height: 38,
              borderRadius: "10px",
              fontSize: 14,
              fontWeight: 700,
              textTransform: "none",
            }}
          >
            Go to Mappings
          </AiaButton>
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
