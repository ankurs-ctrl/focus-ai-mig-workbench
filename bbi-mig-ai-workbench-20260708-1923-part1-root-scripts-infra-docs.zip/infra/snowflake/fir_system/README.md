# FIR System DDL

This directory contains the Snowflake DDL for the AGT_FIR_SYSTEM batch processing agent.

## Overview

The FIR (Feedback → Inference → Recommendation) System is a batch processing pipeline that:
1. Collects feedback from multiple sources (explicit, implicit, mapping, conversation)
2. Generates typed inferences with full lineage tracking
3. Creates versioned curated semantic views (RAW → CURATED_V1 → CURATED_V2)
4. Produces agent-specific recommendations with trigger conditions
5. Applies temporal confidence decay

## Directory Structure

```
fir_system/
├── README.md                     # This file
├── tables/
│   ├── tbl_agent_fir_360.sql    # Core lineage table
│   ├── tbl_semantic_view_versions.sql  # Versioned semantic views
│   └── tbl_fir_agent_recommendations.sql  # Agent recommendations
├── streams/
│   └── fir_streams.sql          # Change detection streams
├── procedures/
│   ├── sp-fir-collect-feedback.sql
│   ├── sp-fir-generate-inferences.sql
│   ├── sp-fir-create-semantic-version.sql
│   ├── sp-fir-generate-recommendations.sql
│   ├── sp-fir-apply-confidence-decay.sql
│   ├── sp-fir-get-agent-recommendations.sql
│   ├── sp-fir-orchestrate-batch.sql
│   └── sp-fir-consolidate-semantic-versions.sql
├── cortex_search/
│   └── fir_search_services.sql  # Cortex Search services
├── tasks/
│   └── fir_tasks.sql            # Snowflake Tasks
└── grants/
    └── fir_grants.sql           # SPCS grants
```

## Deployment Order

Deploy in this order:

1. **Tables** (idempotent)
   ```sql
   -- Replace __STTM_METADATA_NAMESPACE__ with actual namespace
   @fir_system/tables/tbl_agent_fir_360.sql
   @fir_system/tables/tbl_semantic_view_versions.sql
   @fir_system/tables/tbl_fir_agent_recommendations.sql
   ```

2. **Streams**
   ```sql
   @fir_system/streams/fir_streams.sql
   ```

3. **Procedures**
   ```sql
   @fir_system/procedures/sp-fir-collect-feedback.sql
   @fir_system/procedures/sp-fir-generate-inferences.sql
   @fir_system/procedures/sp-fir-create-semantic-version.sql
   @fir_system/procedures/sp-fir-generate-recommendations.sql
   @fir_system/procedures/sp-fir-apply-confidence-decay.sql
   @fir_system/procedures/sp-fir-get-agent-recommendations.sql
   @fir_system/procedures/sp-fir-orchestrate-batch.sql
   @fir_system/procedures/sp-fir-consolidate-semantic-versions.sql
   ```

4. **Cortex Search Services**
   ```sql
   -- Replace __WAREHOUSE_NAME__ with actual warehouse
   @fir_system/cortex_search/fir_search_services.sql
   ```

5. **Tasks**
   ```sql
   @fir_system/tasks/fir_tasks.sql
   -- Then resume tasks manually:
   ALTER TASK TSK_FIR_PROCESS_BATCH RESUME;
   ALTER TASK TSK_FIR_CONFIDENCE_DECAY RESUME;
   ALTER TASK TSK_FIR_SEMANTIC_CONSOLIDATION RESUME;
   ```

6. **Grants**
   ```sql
   -- Replace __SERVICE_OWNER_ROLE__ with actual role
   @fir_system/grants/fir_grants.sql
   ```

## Placeholder Replacements

Before deployment, replace these placeholders:

| Placeholder | Description | Example |
|------------|-------------|---------|
| `__STTM_METADATA_NAMESPACE__` | Full DB.SCHEMA path | `FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA` |
| `__WAREHOUSE_NAME__` | Compute warehouse | `COMPUTE_WH` |
| `__SERVICE_OWNER_ROLE__` | SPCS service role | `STTM_SERVICE_ROLE` |
| `__DATABASE__` | Database name | `FFP_HDP_CRM_MIG_DB_DEV` |

## Task Schedule

| Task | Schedule | Purpose |
|------|----------|---------|
| TSK_FIR_PROCESS_BATCH | Every 5 min (stream-triggered) | Main batch processing |
| TSK_FIR_CONFIDENCE_DECAY | Daily 2 AM EST | Apply confidence decay |
| TSK_FIR_SEMANTIC_CONSOLIDATION | Sunday 4 AM EST | Archive old versions |

## Confidence Scoring

**Initial confidence by source type:**
- Explicit feedback (thumbs up/down): 0.9
- Mapping acceptance: 0.85
- Mapping edit/correction: 0.8
- STTM publish: 0.95
- Implicit (derived source): 0.6
- Conversation: 0.5

**Decay formula:**
```
CURRENT = INITIAL * POWER(0.95, days_since_creation / 30)
```

**Usage boost:**
```
CONFIDENCE = min(1.0, CONFIDENCE + 0.05 * SUCCESS_COUNT / USAGE_COUNT)
```

## Verification

After deployment:

```sql
-- Check tables
SHOW TABLES LIKE 'TBL_%FIR%' IN SCHEMA <namespace>;

-- Check streams
SHOW STREAMS LIKE 'STM_FIR_%' IN SCHEMA <namespace>;

-- Check procedures
SHOW PROCEDURES LIKE 'SP_FIR_%' IN SCHEMA <namespace>;

-- Check tasks
SHOW TASKS LIKE 'TSK_FIR_%' IN SCHEMA <namespace>;

-- Test manual invocation
CALL SP_FIR_ORCHESTRATE_BATCH(OBJECT_CONSTRUCT(
    'task_type', 'manual',
    'batch_size', 10,
    'processing_options', OBJECT_CONSTRUCT(
        'collect_feedback', TRUE,
        'generate_inferences', TRUE,
        'create_semantic_versions', FALSE,
        'generate_recommendations', TRUE,
        'apply_decay', FALSE
    )
));
```

## Integration

Other agents fetch recommendations via:

```sql
CALL SP_FIR_GET_AGENT_RECOMMENDATIONS(
    'AGT_SOURCE_MAPPING',
    'on_mapping_start',
    OBJECT_CONSTRUCT(
        'project_id', '<project_id>',
        'table_names', ARRAY_CONSTRUCT('CUSTOMER', 'ACCOUNT'),
        'max_results', 10
    )
);
```

Record successful usage:

```sql
CALL SP_FIR_RECORD_RECOMMENDATION_SUCCESS('<recommendation_id>');
```
