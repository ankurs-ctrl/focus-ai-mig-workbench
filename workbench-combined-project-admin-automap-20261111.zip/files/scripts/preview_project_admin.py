"""Local UI sample-data API. Never connects to Snowflake or reads credentials.

Run with Python, then start the frontend with the command in the release notes.
Only loopback connections are accepted. Archive/delete affect in-memory samples.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import re

PROJECTS = [{'project_id': '101', 'project_name': 'CRM Migration — Preview',
    'description': 'Local sample data; no Snowflake connection', 'status': 'ACTIVE',
    'sttm_count': 2, 'complete_count': 0, 'partial_count': 0, 'draft_count': 2,
    'total_mappings': 24, 'mapped_count': 0, 'coverage_percent': 0}]
MAPPINGS = [{'sttm_id': str(201+i), 'project_id': '101', 'sttm_name': name,
    'status': 'DRAFT', 'current_version': 0, 'has_unpublished_draft': True,
    'mapping_count': 12, 'mapped_count': 0, 'coverage_percent': 0}
    for i, name in enumerate(['Contacts', 'Households'])]


class Handler(BaseHTTPRequestHandler):
    def reply(self, data, status=200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.endswith('/auth/session') or self.path.endswith('/auth/permissions'):
            self.reply({'user_id': 1, 'display_name': 'Local Admin Preview', 'snowflake_user': 'LOCAL_PREVIEW',
                'app_persona': 'ADMIN', 'snowflake_role': 'ADMIN', 'email': 'preview@example.test',
                'permissions': {'can_read': True, 'can_edit': True, 'can_publish': True,
                                'can_manage_users': True, 'can_view_audit': True}, 'auth_mode': 'local'})
        elif self.path.endswith('/projects/summary'):
            self.reply({'projects': PROJECTS, 'sttms': MAPPINGS})
        else:
            self.reply([])

    def do_POST(self):
        match = re.fullmatch(r'/api/v1/admin/resources/(project|mapping)/(\d+)/(archive|delete)', self.path)
        if not match:
            self.reply({'message': 'Preview supports sample archive/delete actions only.'}, 404)
            return
        kind, identifier, action = match.groups()
        if kind == 'project':
            PROJECTS[:] = [project for project in PROJECTS if project['project_id'] != identifier]
            MAPPINGS[:] = [mapping for mapping in MAPPINGS if mapping['project_id'] != identifier]
        else:
            MAPPINGS[:] = [mapping for mapping in MAPPINGS if mapping['sttm_id'] != identifier]
        self.reply({'status': 'ARCHIVED' if action == 'archive' else 'DELETED', 'history_retained': True})


if __name__ == '__main__':
    print('Sample-data preview API: http://127.0.0.1:8016', flush=True)
    HTTPServer(('127.0.0.1', 8016), Handler).serve_forever()
