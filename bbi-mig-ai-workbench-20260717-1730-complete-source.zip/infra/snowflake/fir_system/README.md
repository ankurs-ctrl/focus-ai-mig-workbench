# FIR 2.0 Snowflake Runtime

FIR is an offline `Feedback -> Evidence -> Inference -> Recommendation` pipeline. Interactive UI requests persist a complete `WorkbenchContextSnapshotV2` and retrieve already-computed guidance; they never invoke `AGT_FIR_SYSTEM`.

## Runtime Flow

1. The UI saves `TBL_WORKSPACE_SNAPSHOTS` and a normalized event before Auto-map, chat, transformation, derived save, validation, or publish.
2. `TSK_FIR_CAPTURE` consumes source streams and creates canonical `TBL_AGENT_FIR_360` records.
3. `TSK_FIR_ENRICH_CONTEXT` resolves semantic, column, derived, document, freshness, profile, prior-inference, and outcome evidence into `TBL_FIR_CONTEXT_EVIDENCE`.
4. `TSK_FIR_PROCESS_BATCH` invokes `AGT_FIR_SYSTEM` offline for fixed Q1/Q2/Q3/Q5/Q6/Q7 goals.
5. `TSK_FIR_PROMOTE_INDEX` scores outputs. Cortex Search indexes active rows asynchronously.
6. Runtime agents retrieve exact `context_key` matches first and use Cortex Search only as a fallback.

## Authoritative Objects

| Concern | Objects |
|---|---|
| UI state and actions | `TBL_WORKSPACE_SNAPSHOTS`, `TBL_WORKBENCH_FIR_EVENTS` |
| Explicit feedback | `TBL_WORKBENCH_FEEDBACK` |
| Enriched evidence | `TBL_FIR_CONTEXT_EVIDENCE`, `TBL_FIR_ASSET_TABLE_REFERENCES` |
| Fixed inferences | `TBL_WORKBENCH_INFERENCES`, `TBL_FIR_INFERENCE_EVIDENCE`, `TBL_FIR_INFERENCE_GOALS` |
| Recommendations | `TBL_FIR_AGENT_RECOMMENDATIONS`, `TBL_FIR_RECOMMENDATION_OUTCOMES` |
| Curated knowledge | `TBL_SEMANTIC_VIEW_VERSIONS` |
| Base semantics | `SEM_TABLE_VIEWS`, `SEM_COLUMN_VIEWS` |
| Derived semantics | `TBL_DERIVED_SOURCES`; `PHYSICAL_VIEW_NAME` identifies the owner-managed secure view |
| Audit lineage | `TBL_AGENT_FIR_360`, `TBL_AGENT_ARTIFACTS` |

## Deployment

Use the versioned deploy script; do not use `fir_combined_deploy.sql` as an authoritative migration.

```bash
./infra/snowflake/scripts/deploy-fir-system.sh --dry-run --skip-tasks
./infra/snowflake/scripts/deploy-fir-system.sh --skip-tasks
```

The script applies additive schema reconciliation before streams, procedures, search services, tasks, and grants. Tasks are intentionally left suspended.

Before enabling capture, inspect the historical event report:

```sql
CALL <namespace>.SP_FIR_BACKFILL_EVENTS(TRUE, 10000);
```

After review, run the bounded backfill with `FALSE`. Enable graph children first and the root last:

```sql
ALTER TASK <namespace>.TSK_FIR_PROMOTE_INDEX RESUME;
ALTER TASK <namespace>.TSK_FIR_PROCESS_BATCH RESUME;
ALTER TASK <namespace>.TSK_FIR_ENRICH_CONTEXT RESUME;
ALTER TASK <namespace>.TSK_FIR_CAPTURE RESUME;
```

Then independently enable freshness, profiling, semantic precompute, decay, consolidation, and recommendation scoring. The freshness procedure runs Tier 1 hourly and skips recently refreshed lower-tier tables for 24 hours. Profiling is weekly and samples only explicit relationship candidates.

## Retrieval Contract

Every agent request carries `snapshot_id`, backend-computed `context_key`, action, and milestone. Exact retrieval compares project, sorted source set, target, derived set, selected columns, lifecycle, and milestone before semantic fallback.

```sql
CALL <namespace>.SP_FIR_GET_AGENT_RECOMMENDATIONS(
  'AGT_SOURCE_MAPPING',
  'before_auto_map',
  OBJECT_CONSTRUCT(
    'context_key', '<backend context key>',
    'source_set_hash', '<hash>',
    'target_fqn', '<db.schema.table>',
    'derived_set_hash', '<hash>',
    'milestone', 'before_auto_map',
    'max_results', 10
  )
);
```

Retrieval does not count as success. `shown`, `used`, `accepted`, `corrected`, `rejected`, and `published` are separate rows in `TBL_FIR_RECOMMENDATION_OUTCOMES`.

## Verification

```sql
SHOW STREAMS LIKE 'STM_FIR_%' IN SCHEMA <namespace>;
SHOW TASKS LIKE 'TSK_FIR_%' IN SCHEMA <namespace>;
SELECT PROCESSING_STAGE, COUNT(*) FROM <namespace>.TBL_AGENT_FIR_360 GROUP BY 1;
SELECT EVIDENCE_STATUS, COUNT(*) FROM <namespace>.TBL_FIR_CONTEXT_EVIDENCE GROUP BY 1;
SELECT INFERENCE_GOAL_ID, VALIDATION_STATUS, COUNT(*)
FROM <namespace>.TBL_WORKBENCH_INFERENCES GROUP BY 1, 2;
```
