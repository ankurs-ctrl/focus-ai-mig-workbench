"""Server-side SQL parser using sqlglot.

Handles full DDL/DML/CTEs — not just SELECT like the client-side parser.
Extracts tables, column mappings, joins, transformations, and business rules.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

try:
    import sqlglot
    from sqlglot import exp
    HAS_SQLGLOT = True
except ImportError:
    HAS_SQLGLOT = False
    logger.warning("sqlglot not installed — SQL parsing will use fallback regex")


@dataclass
class ColumnMapping:
    source_table: str | None
    source_column: str
    target_alias: str | None
    transformation: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_table": self.source_table,
            "source_column": self.source_column,
            "target_alias": self.target_alias,
            "transformation": self.transformation,
        }


@dataclass
class JoinPattern:
    join_type: str
    left_table: str
    right_table: str
    condition: str
    keys: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "join_type": self.join_type,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "condition": self.condition,
            "keys": self.keys,
        }


@dataclass
class CTEDefinition:
    name: str
    purpose: str
    tables_referenced: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "purpose": self.purpose,
            "tables_referenced": self.tables_referenced,
        }


@dataclass
class BusinessRule:
    rule_type: str  # 'case_expression', 'where_filter', 'window_function'
    description: str
    sql_fragment: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_type": self.rule_type,
            "description": self.description,
            "sql_fragment": self.sql_fragment,
        }


@dataclass
class ParsedSqlDocument:
    source_tables: list[str] = field(default_factory=list)
    target_table: str | None = None
    column_mappings: list[ColumnMapping] = field(default_factory=list)
    join_patterns: list[JoinPattern] = field(default_factory=list)
    ctes: list[CTEDefinition] = field(default_factory=list)
    business_rules: list[BusinessRule] = field(default_factory=list)
    transformations: list[str] = field(default_factory=list)
    sql_dialect: str = "snowflake"
    parse_warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_tables": self.source_tables,
            "target_table": self.target_table,
            "column_mappings": [m.to_dict() for m in self.column_mappings],
            "join_patterns": [j.to_dict() for j in self.join_patterns],
            "ctes": [c.to_dict() for c in self.ctes],
            "business_rules": [r.to_dict() for r in self.business_rules],
            "transformations": self.transformations,
            "sql_dialect": self.sql_dialect,
            "parse_warnings": self.parse_warnings,
            "stats": {
                "tables": len(self.source_tables),
                "columns": len(self.column_mappings),
                "joins": len(self.join_patterns),
                "ctes": len(self.ctes),
                "rules": len(self.business_rules),
            },
        }


def parse_sql_document(sql_text: str) -> ParsedSqlDocument:
    """Parse a SQL document and extract all structural information."""
    if HAS_SQLGLOT:
        return _parse_with_sqlglot(sql_text)
    return _parse_with_regex(sql_text)


def _parse_with_sqlglot(sql_text: str) -> ParsedSqlDocument:
    """Full parse using sqlglot AST."""
    result = ParsedSqlDocument()

    try:
        statements = sqlglot.parse(sql_text, read="snowflake", error_level=sqlglot.ErrorLevel.WARN)
    except Exception as exc:
        result.parse_warnings.append(f"sqlglot parse error: {exc}")
        return _parse_with_regex(sql_text)

    for stmt in statements:
        if stmt is None:
            continue

        # Extract source tables
        for table in stmt.find_all(exp.Table):
            table_name = table.name
            if table.db:
                table_name = f"{table.db}.{table_name}"
            if table.catalog:
                table_name = f"{table.catalog}.{table_name}"
            if table_name and table_name not in result.source_tables:
                result.source_tables.append(table_name)

        # Extract CTEs
        for cte in stmt.find_all(exp.CTE):
            cte_name = cte.alias
            cte_tables = []
            for t in cte.find_all(exp.Table):
                cte_tables.append(t.name)
            result.ctes.append(CTEDefinition(
                name=cte_name,
                purpose=f"CTE referencing {', '.join(cte_tables[:3])}",
                tables_referenced=cte_tables,
            ))

        # Extract joins
        for join in stmt.find_all(exp.Join):
            join_type = "LEFT JOIN"
            if join.side:
                join_type = f"{join.side} JOIN"
            elif join.kind:
                join_type = f"{join.kind} JOIN"

            right_table = ""
            table_expr = join.find(exp.Table)
            if table_expr:
                right_table = table_expr.name

            condition = ""
            on_clause = join.args.get("on")
            if on_clause:
                condition = on_clause.sql()

            keys = []
            if on_clause:
                for col in on_clause.find_all(exp.Column):
                    keys.append(col.sql())

            result.join_patterns.append(JoinPattern(
                join_type=join_type,
                left_table="",
                right_table=right_table,
                condition=condition[:200],
                keys=keys[:4],
            ))

        # Extract column mappings from SELECT
        select = stmt.find(exp.Select)
        if select:
            for col_expr in select.expressions:
                mapping = _extract_column_mapping(col_expr)
                if mapping:
                    result.column_mappings.append(mapping)

        # Extract CASE expressions as business rules
        for case_expr in stmt.find_all(exp.Case):
            sql_frag = case_expr.sql()[:300]
            result.business_rules.append(BusinessRule(
                rule_type="case_expression",
                description=f"CASE expression with {len(list(case_expr.find_all(exp.If)))} conditions",
                sql_fragment=sql_frag,
            ))

        # Extract WHERE conditions
        where = stmt.find(exp.Where)
        if where:
            result.business_rules.append(BusinessRule(
                rule_type="where_filter",
                description="WHERE clause filter",
                sql_fragment=where.sql()[:300],
            ))

        # Extract window functions
        for window in stmt.find_all(exp.Window):
            result.business_rules.append(BusinessRule(
                rule_type="window_function",
                description=f"Window: {window.this.sql()[:50]}",
                sql_fragment=window.sql()[:300],
            ))

        # Detect transformations
        _detect_transformations(stmt, result)

    return result


def _extract_column_mapping(col_expr) -> ColumnMapping | None:
    """Extract a column mapping from a SELECT expression."""
    try:
        alias = None
        if hasattr(col_expr, "alias") and col_expr.alias:
            alias = col_expr.alias

        if isinstance(col_expr, exp.Column):
            return ColumnMapping(
                source_table=col_expr.table if col_expr.table else None,
                source_column=col_expr.name,
                target_alias=alias,
            )

        if isinstance(col_expr, exp.Alias):
            inner = col_expr.this
            alias = col_expr.alias
            if isinstance(inner, exp.Column):
                return ColumnMapping(
                    source_table=inner.table if inner.table else None,
                    source_column=inner.name,
                    target_alias=alias,
                )
            else:
                return ColumnMapping(
                    source_table=None,
                    source_column=inner.sql()[:100],
                    target_alias=alias,
                    transformation=inner.sql()[:200],
                )

        return ColumnMapping(
            source_table=None,
            source_column=col_expr.sql()[:100],
            target_alias=alias,
            transformation=col_expr.sql()[:200] if not isinstance(col_expr, exp.Column) else None,
        )
    except Exception:
        return None


def _detect_transformations(stmt, result: ParsedSqlDocument) -> None:
    """Detect common transformation patterns."""
    sql_str = stmt.sql().upper()
    patterns = [
        ("CAST", "Type casting"),
        ("COALESCE", "Null handling"),
        ("TRIM", "Whitespace trimming"),
        ("UPPER", "Uppercase normalization"),
        ("LOWER", "Lowercase normalization"),
        ("CONCAT", "String concatenation"),
        ("LPAD", "Left padding"),
        ("RPAD", "Right padding"),
        ("DATEADD", "Date arithmetic"),
        ("DATEDIFF", "Date difference"),
        ("SPLIT_PART", "String splitting"),
        ("ROW_NUMBER", "Row numbering"),
        ("LAG", "Previous row access"),
        ("LEAD", "Next row access"),
        ("NVL", "Null value replacement"),
    ]
    for pattern, desc in patterns:
        if pattern in sql_str:
            result.transformations.append(f"{pattern}: {desc}")


def _parse_with_regex(sql_text: str) -> ParsedSqlDocument:
    """Fallback regex-based parser when sqlglot is unavailable."""
    result = ParsedSqlDocument()
    result.parse_warnings.append("Parsed with regex fallback (sqlglot unavailable)")

    upper = sql_text.upper()

    # Extract tables from FROM/JOIN clauses
    table_pattern = re.compile(
        r'\b(?:FROM|JOIN)\s+(\w+(?:\.\w+)*)\s*', re.IGNORECASE
    )
    for match in table_pattern.finditer(sql_text):
        table = match.group(1)
        if table.upper() not in ("SELECT", "WHERE", "ON", "AND", "OR"):
            if table not in result.source_tables:
                result.source_tables.append(table)

    # Extract aliases from SELECT
    alias_pattern = re.compile(
        r'\bas\s+(\w+)', re.IGNORECASE
    )
    for match in alias_pattern.finditer(sql_text):
        alias = match.group(1)
        if alias.upper() not in ("VARCHAR", "INTEGER", "DATE", "TIMESTAMP"):
            result.column_mappings.append(ColumnMapping(
                source_table=None,
                source_column="(regex match)",
                target_alias=alias,
            ))

    # Detect joins
    join_pattern = re.compile(
        r'(LEFT|RIGHT|INNER|FULL|CROSS)?\s*JOIN\s+(\w+)', re.IGNORECASE
    )
    for match in join_pattern.finditer(sql_text):
        result.join_patterns.append(JoinPattern(
            join_type=f"{match.group(1) or 'INNER'} JOIN",
            left_table="",
            right_table=match.group(2),
            condition="(regex parse)",
        ))

    _detect_transformations_regex(upper, result)
    return result


def _detect_transformations_regex(upper_sql: str, result: ParsedSqlDocument) -> None:
    patterns = [
        ("CAST(", "Type casting"),
        ("COALESCE(", "Null handling"),
        ("CASE WHEN", "Conditional logic"),
        ("TRIM(", "Whitespace trimming"),
        ("OVER(", "Window function"),
    ]
    for pattern, desc in patterns:
        if pattern in upper_sql:
            result.transformations.append(f"{pattern.rstrip('(')}: {desc}")
