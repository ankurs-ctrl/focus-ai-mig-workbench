import { sqlIdentifierKey } from '@/features/sttm/shared/sql-identifiers';
import { cacheScope, cacheRevision, onCacheIdentityChange, scopedStorageKey } from '@/services/session-cache-scope';
import api, {
  buildApiEnvelope,
  getApiData,
  getApiErrorMessage,
  postEnvelopeData,
  resolveApiBaseUrl,
} from "@/api/axiosInstance";
import { API_ROUTES } from "@/api/routes";
import type {
  DbtConversionRequest,
  DbtConversionResponse,
  MappingSqlPreviewRequest,
  MappingSqlPreviewResponse,
  MappingSqlCompileRequest,
  MappingSqlCompileResponse,
  MappingSqlParseRequest,
  MappingSqlParseResponse,
  MappingSqlReviewRequest,
  MappingSqlReviewResponse,
  TestCaseGenerationRequest,
  TestCaseGenerationResponse,
  WorkbookExportRequest,
} from "@/types/api-contract";

type TableRef = { database: string; schema: string; table: string };

type AgentArtifactJob = {
  job_id: string;
  job_type: string;
  status: "queued" | "running" | "completed" | "failed";
  stage: string;
  result?: {
    data?: Record<string, unknown>;
    error?: { detail?: string | null; title?: string | null } | null;
  } | null;
  error?: string | null;
};

function waitForAgentPoll(delayMs: number, signal?: AbortSignal): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException("Agent job polling was cancelled.", "AbortError"));
      return;
    }
    const handleAbort = () => {
      window.clearTimeout(timer);
      reject(new DOMException("Agent job polling was cancelled.", "AbortError"));
    };
    const timer = window.setTimeout(() => {
      signal?.removeEventListener("abort", handleAbort);
      resolve();
    }, delayMs);
    signal?.addEventListener("abort", handleAbort, { once: true });
  });
}

async function pollAgentArtifactJob(
  url: (jobId: string) => string,
  jobId: string,
  signal?: AbortSignal,
): Promise<AgentArtifactJob> {
  const deadline = Date.now() + 30 * 60 * 1000;
  while (Date.now() < deadline) {
    if (signal?.aborted) throw new DOMException("Agent job polling was cancelled.", "AbortError");
    const job = await getApiData<AgentArtifactJob>(url(jobId), {
      timeout: 30000,
      signal,
      skipGlobalError: true,
    });
    if (job.status === "completed" || job.status === "failed") return job;
    await waitForAgentPoll(2000, signal);
  }
  throw new Error("The agent job did not finish within 30 minutes. Its durable job record remains available.");
}

type DatabaseItem = {
  database_name: string;
  created?: string;
  schemas?: SchemaItem[];
};

type SchemaItem = {
  schema_name: string;
  created?: string;
};

type TableItem = {
  table_name: string;
  row_count?: number | null;
  column_count?: number;
};

type ColumnItem = {
  column_name: string;
  data_type: string;
  is_nullable?: string;
  ordinal_position?: number;
  comment?: string | null;
  is_primary_key?: boolean;
  is_foreign_key?: boolean;
};

type TableAttributes = {
  table: TableRef;
  columns: ColumnItem[];
};

type RelationshipItem = {
  id: string;
  left_table: TableRef;
  right_table: TableRef;
  left_relation_id?: string | null;
  right_relation_id?: string | null;
  constraint_name?: string | null;
  join_type?: "INNER" | "LEFT" | "RIGHT" | "FULL";
  source?: "FOREIGN_KEY" | "USER_DEFINED" | "SEMANTIC_VIEW" | "LEARNED" | null;
  locked?: boolean;
  review_required?: boolean;
  confidence?: number | null;
  review_reason?: string | null;
  evidence?: Record<string, unknown> | null;
  conditions?: Array<{
    left_column?: string;
    right_column?: string;
    fk_column?: string;
    pk_column?: string;
    operator?: string;
  }>;
};

type RelationshipDiscovery = {
  active: RelationshipItem[];
  recommendations: RelationshipItem[];
};

type DerivedSourcePayload = {
  derived_source_id?: string | null;
  derived_source_name: string;
  sql_text: string;
  definition_sql?: string | null;
  query_scope?: Record<string, unknown>;
  source_tables: TableRef[];
  parent_derived_source_ids?: string[];
  driving_table?: TableRef | null;
  relationships?: Array<{
    id?: string;
    left_table: TableRef;
    right_table: TableRef;
    join_type?: "INNER" | "LEFT" | "RIGHT" | "FULL";
    constraint_name?: string | null;
    source?: "FOREIGN_KEY" | "USER_DEFINED" | "SEMANTIC_VIEW" | "LEARNED" | null;
    locked?: boolean;
    conditions?: Array<{
      left_column: string;
      right_column: string;
      operator?: string;
      connector?: "AND" | "OR";
    }>;
  }>;
  filters?: unknown[];
  selected_columns_by_table?: Record<string, string[]>;
  purpose?: string | null;
  business_description?: string | null;
  output_columns?: Array<Record<string, unknown>>;
  column_semantics?: Array<Record<string, unknown>>;
  grain?: string | null;
  keys?: string[];
  generated_by_request_id?: string | null;
  project_id?: string | null;
  sttm_id?: string | null;
  /** ask -> 409 on a duplicate name; overwrite keeps the id; new_version saves NAME_vN. */
  on_conflict?: "ask" | "overwrite" | "new_version";
};

type DerivedSourcePreviewColumn = {
  name: string;
  data_type: string;
  is_primary_key?: boolean;
};

type DerivedSourceValidateResult = {
  valid: boolean;
  message: string;
  sql_text?: string | null;
  preview_columns: DerivedSourcePreviewColumn[];
  preview_rows: Array<{ values: Record<string, unknown> }>;
};

type DerivedSourceRecord = DerivedSourcePayload & {
  derived_source_id: string;
  preview_columns?: DerivedSourcePreviewColumn[];
  base_source_tables?: TableRef[];
  lineage_depth?: number;
  semantic_bundle_id?: string | null;
  semantic_view_name?: string | null;
  semantic_level?: string | null;
  upstream_hash?: string | null;
  source_dependency_hash?: string | null;
  physical_view_name?: string | null;
  semantic_projection?: Record<string, unknown>;
  semantic_quality?: "complete" | "incomplete" | string;
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  is_active?: boolean;
  version?: number;
  is_latest?: boolean;
  family_key?: string | null;
  sql_hash?: string | null;
  origin_sttm_id?: string | null;
  /** True when identical SQL already existed and that record was returned. */
  reused?: boolean;
};

type DbtStreamTelemetryEvent =
  | {
      type: "fetch_begin";
      url: string;
    }
  | {
      type: "fetch_resolved";
      url: string;
      status: number;
      ok: boolean;
      headers: Record<string, string>;
    }
  | {
      type: "first_chunk";
      byteLength: number;
    }
  | {
      type: "sse_event";
      eventName: string;
    };

type DbtStreamTelemetry = {
  onEvent?: (event: DbtStreamTelemetryEvent) => void;
};

type SemanticLevel =
  | "FULL_REGISTRY"  // Recommended default
  | "L0_RELATIONSHIP"
  | "L1_CONTEXT"
  | "L2_ANALYST_READY"
  | "L3_MAPPING_ENRICHED";

type SemanticContextRefreshPayload = {
  project_id?: string | null;
  workspace_derived_sources?: Array<Record<string, unknown>>;
  selected_source_tables: TableRef[];
  selected_derived_sources?: string[];
  target_table?: TableRef | null;
  relationships?: Array<Record<string, unknown>>;
  requested_level?: SemanticLevel;
  force?: boolean;
};

type SemanticContextBundleResponse = {
  bundle_id: string;
  bundle_hash: string;
  bundle_label?: string | null;
  requested_level: SemanticLevel;
  achieved_level: SemanticLevel;
  semantic_view_name?: string | null;
  semantic_model_yaml?: string | null;
  status: "ready" | "refreshed" | "promoted" | "partial" | "failed";
  promoted?: boolean;
  cache_hit?: boolean;
  cache_status?: string;
  cache_source?: string;
  cache_age_ms?: number | null;
  registry_version?: string | null;
  raw_assets?: Array<Record<string, unknown>>;
  composed_yaml?: string | null;
  derived_semantics?: Array<Record<string, unknown>>;
  excluded_relationships?: Array<Record<string, unknown>>;
  composition_diagnostics?: Array<Record<string, unknown>>;
  analyst_ready?: boolean;
  missing_assets?: string[];
  missing_relationships?: Array<Record<string, unknown>>;
  stage_timings_ms?: Record<string, number>;
  summary: Record<string, unknown>;
  lineage?: Array<Record<string, unknown>>;
  semantic_context?: Array<Record<string, unknown>>;
  datahub_context?: Record<string, unknown> | null;
};

const TABLE_METADATA_CACHE_TTL_MS = Number.MAX_SAFE_INTEGER;
// v2 stores { data, expiresAt }; v1 entries stored raw data with no expiry.
const TABLE_METADATA_SESSION_PREFIX = "aia-workbench:catalog:v2:";
// Derived sources are created by other users and agents, so they go stale quickly.
const DERIVED_SOURCES_CACHE_TTL_MS = 60_000;

type TimedCacheEntry<T> = {
  data: T;
  expiresAt: number;
  schemaHash: string;
};

let databaseCacheEpoch = 0;
const attributeCache = new Map<string, TimedCacheEntry<TableAttributes[]>>();
const attributeRequests = new Map<string, Promise<TableAttributes[]>>();
const relationshipCache = new Map<string, TimedCacheEntry<RelationshipItem[]>>();
const relationshipRequests = new Map<string, Promise<RelationshipItem[]>>();
const metadataCache = new Map<string, TimedCacheEntry<unknown>>();
const metadataRequests = new Map<string, Promise<unknown>>();
const metadataGenerations = new Map<string, number>();
const semanticBundleCache = new Map<string, TimedCacheEntry<SemanticContextBundleResponse>>();
const semanticBundleRequests = new Map<string, Promise<SemanticContextBundleResponse>>();

function readSessionMetadata<T>(key: string): { data: T; expiresAt: number } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(scopedStorageKey(`${TABLE_METADATA_SESSION_PREFIX}${key}`));
    if (!raw) return null;
    const entry = JSON.parse(raw) as { data?: T; expiresAt?: number };
    if (typeof entry?.expiresAt !== "number" || !cacheScope() || !("data" in entry)) {
      return null;
    }
    return { data: entry.data as T, expiresAt: entry.expiresAt };
  } catch {
    return null;
  }
}

function writeSessionMetadata<T>(key: string, data: T, expiresAt: number) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(
      scopedStorageKey(`${TABLE_METADATA_SESSION_PREFIX}${key}`),
      JSON.stringify({ data, expiresAt }),
    );
  } catch {
    // Session storage is a best-effort optimization; large catalogs may exceed quota.
  }
}

function invalidateMetadataKey(key: string) {
  metadataGenerations.set(key, (metadataGenerations.get(key) ?? 0) + 1);
  metadataCache.delete(key);
  metadataRequests.delete(key);
  if (typeof window !== "undefined") {
    window.sessionStorage.removeItem(scopedStorageKey(`${TABLE_METADATA_SESSION_PREFIX}${key}`));
  }
}

/** Invalidate every key in a family, e.g. the per-project derived-source lists. */
function invalidateMetadataPrefix(prefix: string) {
  const keys = new Set([...metadataCache.keys(), ...metadataRequests.keys()]);
  if (typeof window !== "undefined") {
    for (let index = window.sessionStorage.length - 1; index >= 0; index -= 1) {
      const stored = window.sessionStorage.key(index);
      if (stored?.startsWith(TABLE_METADATA_SESSION_PREFIX)) {
        keys.add(stored.slice(TABLE_METADATA_SESSION_PREFIX.length).split(":identity:")[0]);
      }
    }
  }
  keys.forEach((key) => {
    if (key === prefix || key.startsWith(`${prefix}:`)) invalidateMetadataKey(key);
  });
}

/** Learned joins change when a join is accepted, rejected or published. */
export function invalidateRelationshipCache() {
  relationshipCache.clear();
}

export function invalidateDatabaseMetadataCache() {
  databaseCacheEpoch++;
  attributeCache.clear();
  attributeRequests.clear();
  relationshipRequests.clear();
  metadataRequests.clear();
  semanticBundleRequests.clear();
  relationshipCache.clear();
  metadataCache.clear();
  semanticBundleCache.clear();
  if (typeof window === "undefined") return;
  for (let index = window.sessionStorage.length - 1; index >= 0; index -= 1) {
    const key = window.sessionStorage.key(index);
    if (key?.startsWith(TABLE_METADATA_SESSION_PREFIX)) {
      window.sessionStorage.removeItem(key);
    }
  }
}

function stableKey(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableKey).sort().join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, item]) => `${key}:${stableKey(item)}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

async function cachedMetadata<T>(
  key: string,
  loader: () => Promise<T>,
  ttlMs: number = TABLE_METADATA_CACHE_TTL_MS,
  refresh = false,
): Promise<T> {
  const cached = metadataCache.get(key);
  if (!refresh && cached && cacheScope()) {
    if (cached.expiresAt <= Date.now()) void cachedMetadata(key,loader,ttlMs,true).catch(() => {});
    return cached.data as T;
  }
  const sessionCached = readSessionMetadata<T>(key);
  if (!refresh && sessionCached !== null) {
    metadataCache.set(key, {
      data: sessionCached.data,
      expiresAt: sessionCached.expiresAt,
      schemaHash: key,
    });
    if (sessionCached.expiresAt <= Date.now()) void cachedMetadata(key,loader,ttlMs,true).catch(() => {});
    return sessionCached.data;
  }
  const pending = metadataRequests.get(key);
  if (pending) return pending as Promise<T>;
  const revision = cacheRevision();
  const epoch = databaseCacheEpoch;
  const generation = metadataGenerations.get(key) ?? 0;
  const request = loader()
    .then((data) => {
      if (revision !== cacheRevision() || epoch !== databaseCacheEpoch) throw new Error("Session changed during catalog retrieval.");
      if ((metadataGenerations.get(key) ?? 0) === generation) {
        const expiresAt = Math.min(Date.now() + ttlMs, Number.MAX_SAFE_INTEGER);
        metadataCache.set(key, {
          data,
          expiresAt,
          schemaHash: key,
        });
        writeSessionMetadata(key, data, expiresAt);
      }
      return data;
    })
    .finally(() => {
      if (metadataRequests.get(key) === request) {
        metadataRequests.delete(key);
      }
    });
  metadataRequests.set(key, request);
  return request;
}

function tableSetKey(tables: string[]): string {
  return [...new Set(tables.map((table) => sqlIdentifierKey(table)).filter(Boolean))]
    .sort()
    .join("|");
}

function relationshipTableSetKey(tables: TableRef[]): string {
  return tableSetKey(tables.map((table) => `${table.database}.${table.schema}.${table.table}`));
}

function metadataSchemaHash(attributes: TableAttributes[]): string {
  return attributes
    .map((item) =>
      `${item.table.database}.${item.table.schema}.${item.table.table}:` +
      item.columns
        .map((column) => `${column.ordinal_position ?? ""}:${column.column_name}:${column.data_type}`)
        .join(","),
    )
    .sort()
    .join("|");
}

export const dbService = {
  getExplorerData: async (): Promise<DatabaseItem[]> => {
    return cachedMetadata("databases", () =>
      postEnvelopeData<DatabaseItem[]>(
        API_ROUTES.tableSelection.databases,
        buildApiEnvelope("table_selection.list_databases", {}),
      ),
    );
  },

  getDatabaseSchemas: async (database: string): Promise<SchemaItem[]> => {
    return cachedMetadata(`schemas:${sqlIdentifierKey(database)}`, () => postEnvelopeData<SchemaItem[]>(
      API_ROUTES.tableSelection.schemas,
      buildApiEnvelope("table_selection.list_schemas", { database }, { database }),
    ));
  },

  getSchemaTables: async (database: string, schema: string): Promise<TableItem[]> => {
    return cachedMetadata(
      `tables:${sqlIdentifierKey(`${database}.${schema}`)}`,
      () => postEnvelopeData<TableItem[]>(
        API_ROUTES.tableSelection.tables,
        buildApiEnvelope("table_selection.list_tables", { database, schema }, { database, schema }),
        { timeout: 120000, skipGlobalError: true },
      ),
    );
  },

  getTableAttributes: async (tables: string[]): Promise<TableAttributes[]> => {
    const key = tableSetKey(tables);
    const cached = attributeCache.get(key);
    if (cached && cached.expiresAt > Date.now()) return cached.data;
    const pending = attributeRequests.get(key);
    if (pending) return pending;
    const identityRevision = cacheRevision();
    const epoch = databaseCacheEpoch;
    const request = postEnvelopeData<TableAttributes[]>(
      API_ROUTES.tableSelection.attributes,
      buildApiEnvelope("table_selection.list_attributes", { tables }, { tables }),
      { timeout: 120000, skipGlobalError: true },
    )
      .then((data) => {
        if (identityRevision !== cacheRevision() || epoch !== databaseCacheEpoch) throw new Error("Session changed during attribute retrieval.");
        attributeCache.set(key, {
          data,
          expiresAt: Date.now() + TABLE_METADATA_CACHE_TTL_MS,
          schemaHash: metadataSchemaHash(data),
        });
        return data;
      })
      .finally(() => { if (attributeRequests.get(key) === request) attributeRequests.delete(key); });
    attributeRequests.set(key, request);
    return request;
  },

  getTableRelationships: async (
    tables: Array<{ database: string; schema: string; table: string }>,
    forceRefresh = false,
    derived_sources: Array<{ id: string; sql: string }> = [],
  ): Promise<RelationshipItem[]> => {
    const key = relationshipTableSetKey(tables) + JSON.stringify(derived_sources);
    if (forceRefresh) relationshipCache.delete(key);
    const cached = relationshipCache.get(key);
    if (cached && cached.expiresAt > Date.now()) return cached.data;
    const pending = relationshipRequests.get(key);
    if (pending) return pending;
    const identityRevision = cacheRevision();
    const epoch = databaseCacheEpoch;
    const request = postEnvelopeData<RelationshipItem[]>(
      API_ROUTES.tableSelection.relationships,
      buildApiEnvelope("table_selection.list_relationships", { tables, derived_sources }, { tables }),
      { timeout: 120000, skipGlobalError: true },
    )
      .then((data) => {
        if (identityRevision !== cacheRevision() || epoch !== databaseCacheEpoch) throw new Error("Session changed during relationship retrieval.");
        relationshipCache.set(key, {
          data,
          expiresAt: Date.now() + TABLE_METADATA_CACHE_TTL_MS,
          schemaHash: key,
        });
        return data;
      })
      .finally(() => { if (relationshipRequests.get(key) === request) relationshipRequests.delete(key); });
    relationshipRequests.set(key, request);
    return request;
  },

  getRelationshipRecommendations: async (
    tables: TableRef[],
  ): Promise<RelationshipDiscovery> => {
    return postEnvelopeData<RelationshipDiscovery>(
      API_ROUTES.tableSelection.relationshipRecommendations,
      buildApiEnvelope(
        "table_selection.relationship_recommendations",
        { tables },
        { tables },
      ),
      { timeout: 120000, skipGlobalError: true },
    );
  },

  recordRelationshipReview: async (
    relationship: RelationshipItem,
    outcome: "accepted" | "rejected" | "used",
    context: {
      project_id?: string | null;
      sttm_id?: string | null;
      context_hash?: string | null;
    },
  ): Promise<void> => {
    await postEnvelopeData<{ recorded: boolean }>(
      API_ROUTES.tableSelection.relationshipReview,
      buildApiEnvelope(
        "table_selection.relationship_review",
        {
          relationship,
          outcome,
          project_id: context.project_id ?? null,
          sttm_id: context.sttm_id ?? null,
          context_hash: context.context_hash ?? null,
        },
        context,
      ),
      { timeout: 30000, skipGlobalError: true },
    );
    invalidateRelationshipCache();
  },

  listDerivedSources: async (projectId?: string | null): Promise<DerivedSourceRecord[]> => {
    const key = projectId ? `derived-sources:${projectId}` : "derived-sources";
    return cachedMetadata(
      key,
      () =>
        getApiData<DerivedSourceRecord[]>(
          projectId
            ? `${API_ROUTES.derivedSources.list}?project_id=${encodeURIComponent(projectId)}`
            : API_ROUTES.derivedSources.list,
        ),
      DERIVED_SOURCES_CACHE_TTL_MS,
    );
  },

  validatePreProcessExpression: async (
    payload: DerivedSourcePayload,
  ): Promise<DerivedSourceValidateResult> => {
    return dbService.validateDerivedSource(payload);
  },

  validateDerivedSource: async (payload: DerivedSourcePayload): Promise<DerivedSourceValidateResult> => {
    return postEnvelopeData<DerivedSourceValidateResult>(
      API_ROUTES.derivedSources.validate,
      buildApiEnvelope("derived_source.validate", payload, {
        source_tables: payload.source_tables,
        driving_table: payload.driving_table ?? null,
        relationships: payload.relationships ?? [],
        selected_columns_by_table: payload.selected_columns_by_table ?? {},
      }),
      { timeout: 120000, skipGlobalError: true },
    );
  },

  saveDerivedSource: async (payload: DerivedSourcePayload): Promise<DerivedSourceRecord> => {
    const result = await postEnvelopeData<DerivedSourceRecord>(
      API_ROUTES.derivedSources.save,
      buildApiEnvelope("derived_source.save", payload, {
        source_tables: payload.source_tables,
        driving_table: payload.driving_table ?? null,
        relationships: payload.relationships ?? [],
        selected_columns_by_table: payload.selected_columns_by_table ?? {},
      }),
      { timeout: 180000, skipGlobalError: true },
    );
    invalidateMetadataPrefix("derived-sources");
    semanticBundleCache.clear();
    semanticBundleRequests.clear();
    return result;
  },

  refreshSemanticContext: async (
    payload: SemanticContextRefreshPayload
  ): Promise<SemanticContextBundleResponse> => {
    const normalizedPayload = { ...payload, requested_level: "FULL_REGISTRY" as const };
    const key = stableKey(normalizedPayload);
    if (!payload.force) {
      const cached = semanticBundleCache.get(key);
      if (cached && cached.expiresAt > Date.now()) return cached.data;
      const pending = semanticBundleRequests.get(key);
      if (pending) return pending;
    }
    const identityRevision = cacheRevision();
    const epoch = databaseCacheEpoch;
    const request = postEnvelopeData<SemanticContextBundleResponse>(
      API_ROUTES.semanticContext.refresh,
      buildApiEnvelope("semantic_context.refresh", normalizedPayload),
      { timeout: 120000, skipGlobalError: true },
    )
      .then((data) => {
        if (identityRevision !== cacheRevision() || epoch !== databaseCacheEpoch) throw new Error("Session changed during semantic retrieval.");
        semanticBundleCache.set(key, {
          data,
          expiresAt: Date.now() + TABLE_METADATA_CACHE_TTL_MS,
          schemaHash: data.registry_version ?? data.bundle_hash,
        });
        if (typeof window !== "undefined") {
          window.sessionStorage.setItem(
            "sttm.activeSemanticContext",
            JSON.stringify({
              bundle_id: data.bundle_id,
              bundle_hash: data.bundle_hash,
              registry_version: data.registry_version ?? null,
              cache_status: data.cache_status ?? "miss",
            }),
          );
        }
        return data;
      })
      .finally(() => { if (semanticBundleRequests.get(key) === request) semanticBundleRequests.delete(key); });
    semanticBundleRequests.set(key, request);
    return request;
  },

  compileMappingSql: async (
    payload: MappingSqlCompileRequest,
  ): Promise<MappingSqlCompileResponse> => {
    return postEnvelopeData<MappingSqlCompileResponse>(
      "/v1/workbench/mapping-sql/compile",
      buildApiEnvelope("mapping_sql.compile", payload, {
        target_table: payload.target_table ?? null,
        relation_graph: payload.relation_graph,
      }),
      { timeout: 120000, skipGlobalError: true },
    );
  },

  reviewMappingSql: async (
    payload: MappingSqlReviewRequest,
  ): Promise<MappingSqlReviewResponse> => {
    return postEnvelopeData<MappingSqlReviewResponse>(
      "/v1/workbench/mapping-sql/review",
      buildApiEnvelope("mapping_sql.review", payload, {
        source_tables: payload.source_tables,
        target_table: payload.target_table ?? null,
        driving_table: payload.driving_table ?? null,
        relationships: payload.relationships ?? [],
        semantic_bundle_id: payload.semantic_bundle_id ?? null,
        semantic_view_name: payload.semantic_view_name ?? null,
      }),
      { timeout: 120000, skipGlobalError: true },
    );
  },

  parseMappingSql: async (
    payload: MappingSqlParseRequest,
  ): Promise<MappingSqlParseResponse> => {
    return postEnvelopeData<MappingSqlParseResponse>(
      "/v1/workbench/mapping-sql/parse",
      buildApiEnvelope("mapping_sql.parse", payload),
      { timeout: 120000 },
    );
  },

  previewMappingSql: async (
    payload: MappingSqlPreviewRequest,
  ): Promise<MappingSqlPreviewResponse> => {
    return postEnvelopeData<MappingSqlPreviewResponse>(
      "/v1/workbench/mapping-sql/preview",
      buildApiEnvelope("mapping_sql.preview", payload, {
        source_tables: payload.source_tables,
        target_table: payload.target_table ?? null,
        driving_table: payload.driving_table ?? null,
        relationships: payload.relationships ?? [],
        semantic_bundle_id: payload.semantic_bundle_id ?? null,
        semantic_view_name: payload.semantic_view_name ?? null,
      }),
      { timeout: 120000, skipGlobalError: true },
    );
  },

  generateDbtConversion: async (
    payload: DbtConversionRequest,
  ): Promise<DbtConversionResponse> => {
    return postEnvelopeData<DbtConversionResponse>(
      "/v1/workbench/dbt-conversion",
      buildApiEnvelope("dbt_conversion.generate", payload, {
        project_id: payload.project_id ?? null,
        sttm_id: payload.sttm_id ?? null,
        target_table: payload.target_table,
        source_tables: payload.source_tables,
        driving_table: payload.driving_table ?? null,
        relationships: payload.relationships ?? [],
        semantic_bundle_id: payload.semantic_bundle_id ?? null,
        semantic_view_name: payload.semantic_view_name ?? null,
      }),
      { timeout: 300000 },
    );
  },

  generateTestCases: async (
    payload: TestCaseGenerationRequest,
  ): Promise<TestCaseGenerationResponse> => {
    const started = await postEnvelopeData<AgentArtifactJob>(
      API_ROUTES.testCases.jobs,
      buildApiEnvelope("test_cases.generate", payload, {
        project_id: payload.project_id ?? null,
        sttm_id: payload.sttm_id ?? null,
        target_table: payload.target_table,
        source_tables: payload.source_tables,
        relationships: payload.relationships ?? [],
      }),
      { timeout: 30000 },
    );
    const job = await pollAgentArtifactJob(API_ROUTES.testCases.job, started.job_id);
    if (job.status === "failed") throw new Error(job.error || "Test-case generation failed.");
    if (job.result?.error) {
      throw new Error(job.result.error.detail || job.result.error.title || "Test-case generation failed.");
    }
    if (!job.result?.data) throw new Error("Test-case generation completed without a result.");
    return job.result.data as unknown as TestCaseGenerationResponse;
  },

  streamDbtConversion: async function* (
    payload: DbtConversionRequest,
    signal?: AbortSignal,
    telemetry?: DbtStreamTelemetry,
  ): AsyncGenerator<
    | { event: "status"; data: Record<string, unknown> }
    | { event: "artifact"; data: Record<string, unknown> }
    | { event: "final"; data: Record<string, unknown> }
    | { event: "error"; data: { message?: string; code?: string } }
  > {
    const url = `${resolveApiBaseUrl()}${API_ROUTES.dbtConversion.jobs}`;
    telemetry?.onEvent?.({
      type: "fetch_begin",
      url,
    });

    const started = await postEnvelopeData<AgentArtifactJob>(
      API_ROUTES.dbtConversion.jobs,
      buildApiEnvelope("dbt_conversion.generate", payload, {
          project_id: payload.project_id ?? null,
          sttm_id: payload.sttm_id ?? null,
          target_table: payload.target_table,
          source_tables: payload.source_tables,
          driving_table: payload.driving_table ?? null,
          relationships: payload.relationships ?? [],
          semantic_bundle_id: payload.semantic_bundle_id ?? null,
          semantic_view_name: payload.semantic_view_name ?? null,
      }),
      { timeout: 30000, signal },
    );

    telemetry?.onEvent?.({
      type: "fetch_resolved",
      url,
      status: 202,
      ok: true,
      headers: {},
    });

    yield { event: "status", data: { phase: "queued", message: "DBT conversion job queued safely in the background." } };
    let lastStage = "";
    const deadline = Date.now() + 30 * 60 * 1000;
    while (Date.now() < deadline) {
      const job = await getApiData<AgentArtifactJob>(API_ROUTES.dbtConversion.job(started.job_id), {
        timeout: 30000,
        signal,
        skipGlobalError: true,
      });
      if (job.stage !== lastStage) {
        lastStage = job.stage;
        yield { event: "status", data: { phase: job.stage, message: `DBT conversion: ${job.stage.replaceAll("_", " ")}.` } };
      }
      if (job.status === "failed") {
        yield { event: "error", data: { message: job.error || "DBT conversion failed.", code: "DBT_CONVERSION_JOB_FAILED" } };
        return;
      }
      if (job.status === "completed") {
        if (!job.result?.data) {
          yield { event: "error", data: { message: "DBT conversion completed without a result.", code: "DBT_CONVERSION_EMPTY_RESULT" } };
          return;
        }
        yield { event: "final", data: job.result };
        return;
      }
      await waitForAgentPoll(2000, signal);
    }
    yield { event: "error", data: { message: "DBT conversion did not finish within 30 minutes.", code: "DBT_CONVERSION_JOB_TIMEOUT" } };
    return;

  },

  exportSttmWorkbook: async (
    payload: WorkbookExportRequest,
  ): Promise<Blob> => {
    try {
      const response = await api.post(
        "/v1/workbench/exports/sttm-excel",
        buildApiEnvelope("workbook.export.sttm_excel", payload, {
          source_tables: payload.source_tables ?? [],
          target_table: payload.target_table ?? null,
        }),
        {
          responseType: "blob",
          timeout: 120000,
          headers: { "Content-Type": "application/json" },
        },
      );
      return response.data as Blob;
    } catch (error) {
      const blobData = (error as { response?: { data?: unknown } })?.response?.data;
      if (blobData instanceof Blob) {
        try {
          const text = await blobData.text();
          const parsed = JSON.parse(text) as { message?: string; error?: { detail?: string; title?: string } };
          throw new Error(
            parsed.error?.detail ||
            parsed.error?.title ||
            parsed.message ||
            "Unable to generate the Excel workbook."
          );
        } catch {
          // Fall back to the standard API error parser below.
        }
      }
      throw new Error(getApiErrorMessage(error, "Unable to generate the Excel workbook."));
    }
  },
};

onCacheIdentityChange(invalidateDatabaseMetadataCache);
