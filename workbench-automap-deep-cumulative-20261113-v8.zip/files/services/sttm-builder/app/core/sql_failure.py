"""Allowlisted SQL failure metadata; never exception text, statements or binds."""
import re


def sql_failure_details(error):
    details = {'error_type': type(error).__name__}
    inherited = getattr(error, 'sql_failure', {})
    fields = {'sql_error_code': ('sql_error_code', 'errno'), 'sql_state': ('sqlstate', 'sql_state'),
              'query_id': ('sfqid', 'query_id')}
    for key, attributes in fields.items():
        # Snowpark retains native SQLSTATE on its connector exception rather
        # than projecting it onto SnowparkSQLException. Read allowlisted fields
        # only; never inspect native query, message, bindings or credentials.
        native = getattr(error, 'conn_error', None)
        values = [getattr(source, name, None) for source in (error, native) for name in attributes]
        if isinstance(inherited, dict):
            values.append(inherited.get(key))
        value = next((str(value) for value in values if type(value) in (int, str)
                      and re.fullmatch(r'[A-Za-z0-9_-]{1,128}', str(value))), None)
        if value is not None:
            details[key] = value
    if isinstance(inherited, dict) and re.fullmatch(r'[A-Za-z0-9_]{1,128}', str(inherited.get('error_type', ''))):
        details['error_type'] = inherited['error_type']
    return details
