# Native Auto-map acceptance and timing

These are actual Cortex agent submissions and Snowflake SQL executions in isolated scratch schemas of our separate test account. The real concurrent proxy scheduler, model transport, production reusable caller lease pool (capacity 2), parser/importer for uploaded SQL, rule specialist, compiler and output-value checks were exercised. No mappings were published. All scratch schemas were cleaned up; old quarantine fixtures remained unchanged until cleanup.

The five contracts include a direct ID, FIR-derived name transformation, direct Firm Value, pure Firm-Value CASE and intentional SQL NULL. Existing ID definitions were retained in the partial/upload/CTE cases. The CTE retained its ACTIVE filter, producing only the expected active rows.

## End-to-end engine results

| Scenario | Engine seconds | Mapping-model POSTs | Rule-model POSTs | Preliminary review POSTs | Baseline preserved | Retained SQL query IDs |
|---|---:|---:|---:|---:|---|---:|
| new | 97.75 | 2 | 1 | 0 | Not applicable | 129 |
| partial | 137.32 | 2 | 1 | 0 | True | 159 |
| sql-upload | 92.2 | 1 | 1 | 0 | True | 106 |
| cte | 96.98 | 1 | 1 | 0 | True | 110 |

Engine times exclude fixture provisioning, test-agent creation and authentication setup; each JSON separately records test_setup_seconds. These small mixed fixtures are not a performance replica of the client's 37-target/287-source workspace. Source POST counts can include a focused format/evidence repair; the runtime_calls records identify each submission. Zero preliminary reviews does not mean zero validation.

## Per-call phase timings

All values below are seconds. Parallel call durations overlap: do not add them to explain job wall time. Archive includes verified writes/readbacks. Admission includes control-store work and capacity waiting; it is not proof of capacity exhaustion. Model includes provider submission/status inspection and terminal-result handling, not an isolated server-side inference measurement. Completed traces are frozen, so later sibling work is not charged to final_check.

| Scenario | Call | Stage | Archive | Admission | Thread create | Atomic preparation | Model | Cleanup | Call total |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| new | 1 | source_mapping | 13.87 | 8.65 | 0.77 | 3.89 | 19.27 | 3.88 | 50.33 |
| new | 2 | transformation_rule | 8.32 | 6.28 | 0.36 | 2.84 | 17.54 | 4.42 | 39.75 |
| new | 3 | source_mapping | 20.23 | 5.67 | 0.32 | 4.06 | 16.29 | 6.81 | 53.4 |
| partial | 1 | source_mapping | 14.5 | 5.31 | 0.79 | 3.4 | 19.92 | 3.74 | 47.66 |
| partial | 2 | source_mapping | 8.77 | 6.57 | 0.32 | 2.77 | 18.95 | 3.99 | 41.37 |
| partial | 3 | transformation_rule | 8.63 | 5.45 | 0.29 | 2.92 | 17.4 | 6.13 | 40.81 |
| sql-upload | 1 | source_mapping | 13.36 | 5.3 | 0.78 | 3.42 | 20.59 | 3.64 | 47.09 |
| sql-upload | 2 | transformation_rule | 8.34 | 5.58 | 0.33 | 2.82 | 17.2 | 3.6 | 37.87 |
| cte | 1 | source_mapping | 13.34 | 5.41 | 0.77 | 3.8 | 18.5 | 3.75 | 45.56 |
| cte | 2 | transformation_rule | 8.72 | 6.38 | 0.32 | 3.19 | 21.57 | 3.85 | 44.03 |

## Semantics and FIR verification

Every final report records model_inputs with semantic description markers, exact FIR IDs present in submitted bodies, approved Firm Value presence, per-target mapping evidence, actual output checks and confidence. Relevant FIR was retrieved from a persisted validated fixture and supplied to both mapping and transformation agents. It was not merely asserted in the test name.

fir_attribution separates supported recipe IDs from backend_inferred_recipe_ids. Inference occurs only for exact SQL matches to already-read, authorized, trusted and applicable recipes, with unambiguous named CTE alias adaptation. It does not claim that the model cited an ID it omitted, choose a different mapping, or certify population compatibility. Unknown attribution remains a confidence-capped review note. Foreign citations, missing required corrections, invalid bindings and SQL errors remain checked.

## Bottlenecks and changes

The client export confirms substantial admission/thread-state/cleanup time, 16 observed model POSTs, and many evidence-review calls. It does not identify the original blocking transaction. The code investigation found that pending-batch construction stripped the accepted draft/rules policies; this explained a route back into the older review-heavy protocol. The new tests lock policy propagation across the parent/worker boundary.

The release removes preliminary quote-review calls from new draft runs, combines thread/request/lease persistence, removes a redundant standalone renewal, and verifies archive content on the writing lease before requiring COMMIT acknowledgement. It retains exact evidence and recovery safeguards. Remaining measurable cost is largely Snowflake control/archive work plus necessary mapping/rule calls. No capacity, context or timeout increases were used.

Each NATIVE-*.json contains source hashes, UTC phase timestamps, per-call timings, native SQL query IDs, actual submissions, output rows, evidence attribution and cleanup evidence. The client incident's lost native SQL diagnostics cannot be reconstructed from these test reports.
