"""Recover monotonic run accounting from already committed lifecycle events."""
from typing import Any

from app.agent_runs.models import AgentRun


def restore_usage(run: AgentRun, usage: Any) -> None:
    if not isinstance(usage, dict):
        return
    for field, key in (("model_calls_used", "model_calls"), ("tool_calls_used", "domain_operations"),
                       ("supervisor_tool_requests_used", "supervisor_tool_requests"),
                       ("specialist_calls_used", "specialist_calls"), ("cache_hits", "cache_hits"),
                       ("domain_operations_used", "domain_operations")):
        value = usage.get(key)
        if type(value) is int and value >= 0:
            setattr(run, field, max(getattr(run, field), value))
    for key, value in usage.items():
        if key.startswith("category_") and type(value) is int and value >= 0:
            category = key.removeprefix("category_")
            run.category_usage[category] = max(run.category_usage.get(category, 0), value)
    elapsed = usage.get("elapsed_seconds")
    if type(elapsed) is int and elapsed >= 0:
        run.elapsed_seconds_used = max(run.elapsed_seconds_used, elapsed)
