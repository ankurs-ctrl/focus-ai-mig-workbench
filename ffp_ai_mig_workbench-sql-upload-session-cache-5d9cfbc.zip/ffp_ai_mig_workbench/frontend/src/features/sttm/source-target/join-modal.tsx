"use client";
import { AiaBox } from '@/components/ui';
import { SqlEditor } from '@/components/sql/sql-editor';
import { AiaText } from '@/components/ui/aia-text';
import React, { useEffect, useState } from "react";

import { AllInclusiveIcon, ArrowBackRoundedIcon } from '@/utils/icons';
import { textStyleCssVars } from '@/config/typography-tokens';

import type { JoinConfig, TableMeta } from "@/features/sttm/types/sttm.types";
import { AiaButton } from "@/components/ui/aia-button";
import { AiaChip } from "@/components/ui/aia-chip";
import { AiaSelect } from "@/components/ui/aia-select";
import { AiaAutocomplete } from "@/components/ui/aia-auto-complete";
import { buildRelationDisplayAliases, formatRelationDisplayText, rewriteLegacyAliasReference } from "@/features/sttm/mapping/relation-alias";

function DrivingChip() {
  return (
    <AiaChip
      label="Driving"
      size="small"
      color="warning"
      customBackgroundColor="#fef08a"
      customColor="#854d0e"
      customBorderColor="#fde047"
      sx={{
        height: 22,
        fontSize: 10,
        fontWeight: 700,
        "& .MuiChip-label": { px: 0.75, py: 0 },
      }}
    />
  );
}

function DerivedChip() {
  return <AiaChip label="CTE" size="small" color="success" />;
}

interface JoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBack?: () => void;
  tables: TableMeta[];
  initialLeftTableId?: string;
  initialRightTableId?: string;
  drivingTableIdOverride?: string | null;
  editingJoin?: JoinConfig | null;
  confirmAddsJoin?: boolean;
  allowSqlPredicate?: boolean;
  previewRelations?: Array<{ identity: string; alias: string; displaySeed?: string | null }>;
  onConfirm: (join: JoinConfig) => void;
}

export function JoinModal(props: JoinModalProps) {
  if (!props.isOpen) return null;
  const identity = JSON.stringify([props.editingJoin ?? null, props.initialLeftTableId, props.initialRightTableId]);
  return <JoinModalContent key={identity} {...props} />;
}

function JoinModalContent({
  isOpen,
  onClose,
  onBack,
  tables,
  initialLeftTableId,
  initialRightTableId,
  drivingTableIdOverride,
  editingJoin,
  confirmAddsJoin = false,
  allowSqlPredicate = false,
  previewRelations = [],
  onConfirm,
}: JoinModalProps) {
  // New joins default to LEFT JOIN; editing keeps the join's own type.
  const [joinType, setJoinType] = useState<"INNER" | "LEFT" | "RIGHT" | "FULL">(
    editingJoin?.joinType ?? "LEFT"
  );

  type PairRow = {
    id: string;
    leftColumn: string;
    operator: string;
    rightColumn: string;
  };
  // New joins start from the driving table on the left (unless it is already the right table).
  const [leftTableId, setLeftTableId] = useState(
    editingJoin?.leftTableId
      ?? initialLeftTableId
      ?? (drivingTableIdOverride && drivingTableIdOverride !== initialRightTableId ? drivingTableIdOverride : ""),
  );
  const [rightTableId, setRightTableId] = useState(editingJoin?.rightTableId ?? initialRightTableId ?? "");
  const [rows, setRows] = useState<PairRow[]>(() => editingJoin?.conditions?.length
    ? editingJoin.conditions.map((condition, index) => ({ id: `row-${index + 1}`,
      leftColumn: condition.leftColumn ?? "", operator: condition.operator ?? "=", rightColumn: condition.rightColumn ?? "" }))
    : [{ id: "row-1", leftColumn: "", operator: "=", rightColumn: "" }]);
  const [sqlPredicate, setSqlPredicate] = useState(editingJoin?.sqlPredicate ?? "");
  const [predicateMode, setPredicateMode] = useState(Boolean(editingJoin?.sqlPredicate));
  const displayAliases = buildRelationDisplayAliases(previewRelations);
  const runtimeAliases = new Map<string, string>();
  for (const relation of previewRelations) {
    const display = displayAliases.get(relation.alias.toUpperCase());
    if (display) runtimeAliases.set(display.toUpperCase(), relation.alias);
  }

  if (!isOpen) return null;

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previous; };
  }, []);

  const drivingTableId = drivingTableIdOverride ?? null;

  // Driving table first in both Left and Right Table lists, then the rest A–Z by name.
  const tableOptions = tables
    .filter((t) => !!t.id)
    .sort(
      (a, b) =>
        Number(b.id === drivingTableId) - Number(a.id === drivingTableId)
        || (a.name || a.schema || "").localeCompare(b.name || b.schema || "", undefined, {
          sensitivity: "base",
          numeric: true,
        }),
    )
    .map((t) => {
      const schema = t.schema ?? "";
      const name = t.name ?? "";
      return {
        label: name || schema,
        value: t.id as string,
        badge: t.id === drivingTableId ? <DrivingChip /> : undefined,
      };
    });

  const openPredicateEditor = () => {
    if (!predicateMode && !sqlPredicate.trim()) {
      const aliasFor = (tableId: string) => {
        const index = tables.findIndex((table) => table.id === tableId);
        return previewRelations[index]?.alias ?? tables[index]?.name ?? "";
      };
      setSqlPredicate(rows.filter((row) => row.leftColumn && row.rightColumn)
        .map((row) => `${aliasFor(leftTableId)}.${row.leftColumn} ${row.operator || "="} ${aliasFor(rightTableId)}.${row.rightColumn}`)
        .join(" AND "));
    }
    setPredicateMode(!predicateMode);
  };

  const handleConfirm = () => {
    const validRows = rows.filter((r) => r.leftColumn && r.operator && r.rightColumn);
    if (predicateMode ? !sqlPredicate.trim() : validRows.length === 0) return;
    if (!leftTableId || !rightTableId) return;

    const out: JoinConfig = {
      id:
        editingJoin?.id ??
        `${leftTableId}__${rightTableId}`, // one join per table-pair
      joinType,
      leftTableId,
      rightTableId,
      constraintName: editingJoin?.constraintName,
      source: editingJoin?.source ?? "USER_DEFINED",
      locked: false,
      sqlPredicate: predicateMode ? sqlPredicate.trim() : undefined,
      conditions: predicateMode ? [] : validRows.map((r) => ({
        leftColumn: r.leftColumn,
        operator: r.operator,
        rightColumn: r.rightColumn,
      })),
    };

    onConfirm(out);
    onClose();
  };

  const isFormValid =
    !!leftTableId &&
    !!rightTableId &&
    (predicateMode ? Boolean(sqlPredicate.trim()) : rows.some((r) => r.leftColumn && r.operator && r.rightColumn));

  const updateRow = (idx: number, patch: Partial<PairRow>) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  };

  const addRow = () => {
    setRows((prev) => [
      ...prev,
      { id: `row-${prev.length + 1}`, leftColumn: "", operator: "=", rightColumn: "" },
    ]);
  };

  const removeRow = (idx: number) => {
    setRows((prev) => (prev.length <= 1 ? prev : prev.filter((_, i) => i !== idx)));
  };

  const leftTable = tables.find((t) => t.id === leftTableId);
  const rightTable = tables.find((t) => t.id === rightTableId);
  const leftIsDerived = leftTable?.tag?.toLowerCase().includes("derived") ?? false;
  const rightIsDerived = rightTable?.tag?.toLowerCase().includes("derived") ?? false;

  const leftColumnOptions = (leftTable?.columns ?? [])
    .filter((c) => !!c.name)
    .map((c) => ({
      label: `${c.name} (${c.type ?? ""})`,
      value: c.name as string,
    }));
  const rightColumnOptions = (rightTable?.columns ?? [])
    .filter((c) => !!c.name)
    .map((c) => ({
      label: `${c.name} (${c.type ?? ""})`,
      value: c.name as string,
    }));

  const operatorOptions = [
    { label: "— op —", value: "" },
    { label: "=", value: "=" },
    { label: "≠", value: "!=" },
    { label: ">", value: ">" },
    { label: "<", value: "<" },
    { label: "≥", value: ">=" },
    { label: "≤", value: "<=" },
  ];

  const sectionLabelSx = {
    ...textStyleCssVars("caption"),
    fontWeight: 400,
    letterSpacing: "0.08em",
    textTransform: "uppercase" as const,
  };

  const joinFieldGap = 1.5;
  const joinFieldsWidth = "100%";
  const joinConditionColumnWidth = 108;
  const joinTableGridSx = {
    display: "grid",
    gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
    gap: joinFieldGap,
    width: "100%",
  } as const;
  const joinColumnGridColumns = `minmax(0, 1fr) ${joinConditionColumnWidth}px minmax(0, 1fr) max-content`;
  const joinConditionSelectSx = {
    width: joinConditionColumnWidth,
    minWidth: joinConditionColumnWidth,
    maxWidth: joinConditionColumnWidth,
    "& .MuiSelect-select": {
      textAlign: "left",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      paddingLeft: 1,
      paddingRight: "24px !important",
    },
  } as const;
  const joinColumnRowSubgridSx = {
    gridColumn: "1 / -1",
    display: "grid",
    gridTemplateColumns: "subgrid",
    alignItems: "center",
  } as const;
  const joinRowActionButtonSx = {
    minWidth: 28,
    width: 28,
    height: 28,
    p: 0,
    fontSize: 14,
    lineHeight: 1,
    boxShadow: "none",
  } as const;
  const joinRowActionButtonSxBase = {
    ...joinRowActionButtonSx,
    color: "var(--aia-button-color)",
    borderColor: "var(--aia-button-color)",
    "--aia-btn-stroke": "var(--aia-button-color)",
    "&:hover": {
      color: "var(--aia-button-color)",
      borderColor: "var(--aia-button-color)",
      backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
    },
  } as const;
  const joinCloseButtonSx = {
    ...joinRowActionButtonSx,
    color: "#94a3b8",
    border: "none",
    backgroundColor: "transparent",
    "&:hover": {
      color: "#94a3b8",
      border: "none",
      backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
    },
  } as const;

  return (
    <div className="join-modal-overlay">
      <div className="join-modal" role="dialog" aria-modal="true" aria-label="Establish Join">
        <AiaBox sx={{ p: 3, borderBottom: "1px solid #f1f5f9" }}>
          <AiaBox sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2 }}>
            <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1.5, minWidth: 0 }}>
              <AllInclusiveIcon
                sx={{
                  fontSize: "calc(var(--aia-card-title-font-size) + 2px)",
                  color: "var(--aia-card-title-color)",
                  flexShrink: 0,
                }}
                aria-hidden
              />
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText
                  sx={{
                    ...textStyleCssVars("cardTitle"),
                    textTransform: "capitalize",
                    letterSpacing: "-0.01em",
                  }}
                >
                  Establish Join
                </AiaText>
                <AiaText
                  sx={{
                    ...textStyleCssVars("secondaryText"),
                    mt: 0.25,
                    display: "block",
                  }}
                >
                  Define a relationship between two tables
                </AiaText>
              </AiaBox>
            </AiaBox>
            <AiaButton
              variant="text"
              size="small"
              onClick={onClose}
              sx={joinCloseButtonSx}
              aria-label="Close"
            >
              ✕
            </AiaButton>
          </AiaBox>
        </AiaBox>

        <AiaBox sx={{ p: 2, minHeight: 0, overflowY: "auto", '& .MuiInputBase-root': { fontSize: 13 }, '& .MuiAutocomplete-input': { padding: '4px !important' } }}>
          <AiaText sx={{ ...sectionLabelSx, mb: 1.25 }}>
            JOIN TYPE
          </AiaText>
          <AiaBox sx={{ display: "flex", gap: 1, flexWrap: "wrap", mb: 3 }}>
            {(["INNER", "LEFT", "RIGHT", "FULL"] as const).map((t) => {
              const active = joinType === t;
              return (
                <AiaButton
                  key={t}
                  size="small"
                  variant={active ? "contained" : "outlined"}
                  color="primary"
                  onClick={() => setJoinType(t)}
                  {...(active
                    ? {
                        customBackgroundColor: "var(--aia-primary-bg-color)",
                        customColor: "var(--aia-primary-bg-text-color)",
                        customBorderColor: "var(--aia-primary-bg-color)",
                        customHoverBackgroundColor: "var(--aia-primary-bg-hover-color)",
                      }
                    : {
                        customBorderColor: "var(--aia-primary-bg-color)",
                        customColor: "var(--aia-primary-bg-color)",
                      })}
                >
                  {t} JOIN
                </AiaButton>
              );
            })}
          </AiaBox>

          <AiaBox sx={{ width: joinFieldsWidth, pb: 2.5 }}>
            <AiaBox sx={joinTableGridSx}>
              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText sx={{ ...sectionLabelSx, mb: 1 }}>
                  LEFT TABLE
                </AiaText>
                <AiaAutocomplete
                  hideLabel
                  options={tableOptions}
                  value={leftTableId}
                  disabled={predicateMode}
                  placeholder="Search table…"
                  onChange={(val) => {
                    setLeftTableId(Array.isArray(val) ? val[0] ?? "" : String(val));
                    setRows((prev) => prev.map((r) => ({ ...r, leftColumn: "" })));
                  }}
                />
                <AiaText sx={{ mt: 0.65, fontSize: 11, color: "#64748b", overflowWrap: "anywhere" }}>
                  {leftIsDerived ? `CTE: ${leftTable?.name ?? ""}` : leftTable ? `${leftTable.database ?? ""}.${leftTable.schema ?? ""}.${leftTable.name ?? ""}`.replace(/\.+/g, ".") : "Select a table"}
                </AiaText>
                {leftIsDerived ? (
                  <AiaBox sx={{ mt: 0.9 }}>
                    <DerivedChip />
                  </AiaBox>
                ) : null}
              </AiaBox>

              <AiaBox sx={{ minWidth: 0 }}>
                <AiaText sx={{ ...sectionLabelSx, mb: 1 }}>
                  RIGHT TABLE
                </AiaText>
                <AiaAutocomplete
                  hideLabel
                  options={tableOptions}
                  value={rightTableId}
                  disabled={predicateMode}
                  placeholder="Search table…"
                  onChange={(val) => {
                    setRightTableId(Array.isArray(val) ? val[0] ?? "" : String(val));
                    setRows((prev) => prev.map((r) => ({ ...r, rightColumn: "" })));
                  }}
                />
                <AiaText sx={{ mt: 0.65, fontSize: 11, color: "#64748b", overflowWrap: "anywhere" }}>
                  {rightIsDerived ? `CTE: ${rightTable?.name ?? ""}` : rightTable ? `${rightTable.database ?? ""}.${rightTable.schema ?? ""}.${rightTable.name ?? ""}`.replace(/\.+/g, ".") : "Select a related table"}
                </AiaText>
                {rightIsDerived ? (
                  <AiaBox sx={{ mt: 0.9 }}>
                    <DerivedChip />
                  </AiaBox>
                ) : null}
              </AiaBox>
            </AiaBox>
          </AiaBox>

          <AiaBox
            sx={{
              width: "100%",
              borderBottom: "1px solid #e5e7eb",
              mb: 2.5,
            }}
          />

          {(allowSqlPredicate || editingJoin?.sqlPredicate) && (
            <AiaBox sx={{ mb: 2 }}>
              <AiaButton size="small" variant="outlined" onClick={openPredicateEditor}>
                {predicateMode ? 'Use column conditions' : 'Edit complete ON predicate'}
              </AiaButton>
              {!predicateMode && editingJoin?.sqlPredicate && <AiaText sx={{ fontSize: 12, mt: 1 }}>Saving will replace the original ON expression with the column conditions below.</AiaText>}
            </AiaBox>
          )}
          {(allowSqlPredicate || editingJoin?.sqlPredicate) && predicateMode ? (
            <AiaBox>
              <AiaText sx={{ ...sectionLabelSx, mb: 1 }}>Complete ON predicate</AiaText>
              <SqlEditor value={formatRelationDisplayText(sqlPredicate, displayAliases)}
                onChange={(value) => setSqlPredicate(rewriteLegacyAliasReference(value, runtimeAliases))}
                title="ON predicate" minHeight={160} maxHeight={240} showCopy />
              <AiaText sx={{ fontSize: 12, color: "#64748b", mt: 1 }}>
                Use the relation names shown in Query Preview. Saving updates the join and its SQL preview.
              </AiaText>
            </AiaBox>
          ) : <AiaBox
            sx={{
              maxHeight: 300,
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            <AiaBox
              sx={{
                display: "grid",
                gridTemplateColumns: joinColumnGridColumns,
                columnGap: joinFieldGap,
                width: "100%",
              }}
            >
              <AiaBox sx={{ ...joinColumnRowSubgridSx, mb: 1 }}>
                <AiaText sx={sectionLabelSx}>LEFT COLUMNS</AiaText>
                <AiaText sx={{ ...sectionLabelSx, justifySelf: "start", whiteSpace: "nowrap" }}>
                  CONDITIONS
                </AiaText>
                <AiaText sx={sectionLabelSx}>RIGHT COLUMNS</AiaText>
                <AiaBox />
              </AiaBox>

              {rows.map((row, idx) => (
                <AiaBox
                  key={row.id}
                  sx={{
                    ...joinColumnRowSubgridSx,
                    ...(idx > 0 ? { mt: joinFieldGap } : {}),
                  }}
                >
                  <AiaBox sx={{ minWidth: 0 }}>
                    <AiaAutocomplete
                      hideLabel
                      options={leftColumnOptions}
                      value={row.leftColumn}
                      placeholder="Search column…"
                      onChange={(val) =>
                        updateRow(idx, { leftColumn: Array.isArray(val) ? val[0] ?? "" : String(val) })
                      }
                      disabled={!leftTableId}
                      fullWidth
                    />
                  </AiaBox>

                  <AiaBox sx={{ width: joinConditionColumnWidth, minWidth: joinConditionColumnWidth, maxWidth: joinConditionColumnWidth }}>
                    <AiaSelect
                      options={operatorOptions}
                      value={row.operator}
                      placeholder="Condition"
                      onChange={(val) => updateRow(idx, { operator: String(val) })}
                      fullWidth
                      sx={joinConditionSelectSx}
                    />
                  </AiaBox>

                  <AiaBox sx={{ minWidth: 0 }}>
                    <AiaAutocomplete
                      hideLabel
                      options={rightColumnOptions}
                      value={row.rightColumn}
                      placeholder="Search column…"
                      onChange={(val) =>
                        updateRow(idx, { rightColumn: Array.isArray(val) ? val[0] ?? "" : String(val) })
                      }
                      disabled={!rightTableId}
                      fullWidth
                    />
                  </AiaBox>

                  <AiaBox
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      gap: 0.75,
                    }}
                  >
                    <AiaButton
                      variant="outlined"
                      size="small"
                      color="primary"
                      onClick={() => removeRow(idx)}
                      disabled={rows.length <= 1}
                      sx={joinRowActionButtonSxBase}
                      customBorderColor="var(--aia-button-color)"
                      customColor="var(--aia-button-color)"
                      aria-label="Remove condition"
                    >
                      ✕
                    </AiaButton>
                    <AiaButton
                      variant="outlined"
                      size="small"
                      color="primary"
                      onClick={addRow}
                      sx={{
                        ...joinRowActionButtonSxBase,
                        fontSize: 20,
                        fontWeight: 600,
                      }}
                      customBorderColor="var(--aia-button-color)"
                      customColor="var(--aia-button-color)"
                      aria-label="Add condition"
                    >
                      +
                    </AiaButton>
                  </AiaBox>
                </AiaBox>
              ))}
            </AiaBox>
          </AiaBox>}
        </AiaBox>

        <AiaBox sx={{ px: 3, py: 2.25, borderTop: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 1.5 }}>
          {onBack ? (
            <AiaButton
              variant="outlined"
              size="large"
              startIcon={<ArrowBackRoundedIcon sx={{ fontSize: 18 }} />}
              onClick={onBack}
              customBorderColor="var(--aia-primary-bg-color)"
              customColor="var(--aia-primary-bg-color)"
            >
              Back
            </AiaButton>
          ) : (
            <AiaBox />
          )}
          <AiaBox sx={{ display: "flex", justifyContent: "flex-end", gap: 1.5 }}>
          <AiaButton
            variant="outlined"
            size="large"
            onClick={onClose}
            customBorderColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-color)"
          >
            Cancel
          </AiaButton>
          <AiaButton
            variant="contained"
            size="large"
            color="primary"
            onClick={handleConfirm}
            disabled={!isFormValid}
            customBackgroundColor="var(--aia-primary-bg-color)"
            customColor="var(--aia-primary-bg-text-color)"
            customBorderColor="var(--aia-primary-bg-color)"
            customHoverBackgroundColor="var(--aia-primary-bg-hover-color)"
          >
            {editingJoin
              ? confirmAddsJoin
                ? "Update and Add Join"
                : "Update Join"
              : "Add Join"}
          </AiaButton>
          </AiaBox>
        </AiaBox>
      </div>
    </div>
  );
}
