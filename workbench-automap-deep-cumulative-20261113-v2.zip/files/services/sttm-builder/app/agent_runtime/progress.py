"""Chat progress for long runs, written by the supervisor.

Long supervisor tool calls (evidence preparation, and above all the governed
migration workflow) block the supervisor, so it cannot narrate while they run.
Host code here never writes chat text. It records structured facts at workflow
boundaries (per target and phase), publishes them to the activity tree and
progress strip as ``automap.progress``, and keeps the last few completed
activity summaries. A narrator thread hands those to the supervisor's model,
which writes the ``assistant.update``. When the chat has been quiet for a
heartbeat interval, the narrator is asked for an update from the current status.
Every event passes through ``__call__``, so any supervisor update resets the
heartbeat.
"""
from __future__ import annotations

import threading
import time
from collections import deque
from typing import Any, Callable

TraceEmitter = Callable[[str, str, str, dict[str, Any]], None]
# Given {"new_events", "status", "previous_update"}, return the supervisor's chat text or None.
Narrator = Callable[[dict[str, Any]], "str | None"]

# Display order for the per-target progress strip.
PHASES = ("queued", "preparing", "mapping", "compiling", "done", "needs_review")
_TERMINAL = {"done", "needs_review"}


def _short(table: str) -> str:
    return str(table or "").rsplit(".", 1)[-1].strip('"')


class ProgressReporter:
    """Wraps the run's trace sink; thread-safe (narration runs on its own thread)."""

    def __init__(
        self,
        trace: TraceEmitter,
        run_id: str,
        *,
        heartbeat_seconds: float = 120.0,
        min_gap_seconds: float = 45.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._trace = trace
        self._run_id = run_id
        self._heartbeat_seconds = max(15.0, float(heartbeat_seconds))
        self._min_gap_seconds = max(5.0, float(min_gap_seconds))
        self._clock = clock
        self._lock = threading.Lock()
        self._started_at = clock()
        self._last_update_at = self._started_at
        self._last_update_text = ""
        self._earlier_updates: deque[str] = deque(maxlen=3)
        self._phases: dict[str, str] = {}
        self._posted: set[tuple[str, str]] = set()
        self._pending: list[dict[str, Any]] = []
        self._narrator: Narrator | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        # Completed activity already shown in the activity tree; context for a heartbeat.
        self._recent: deque[str] = deque(maxlen=8)

    # The runtime calls the reporter exactly like the trace sink.
    def __call__(self, event_type: str, status: str, summary: str, data: dict[str, Any]) -> None:
        if event_type == "assistant.update":
            with self._lock:
                self._last_update_at = self._clock()
                self._last_update_text = str(data.get("text") or summary or "")
                self._earlier_updates.append(self._last_update_text[:400])
        elif event_type in {"trace.action.completed", "tool.completed", "trace.group.completed"} and summary:
            with self._lock:
                self._recent.append(str(summary)[:200])
        self._trace(event_type, status, summary, data)

    def __getattr__(self, name: str) -> Any:
        # flush/close/stopped belong to the wrapped durable writer.
        if name.startswith("__") or name == "_trace":
            raise AttributeError(name)
        return getattr(self._trace, name)

    @property
    def overdue(self) -> bool:
        """True once the chat has been quiet for a heartbeat interval."""
        with self._lock:
            return self._clock() - self._last_update_at >= self._heartbeat_seconds

    def plan_targets(self, targets: list[str]) -> None:
        with self._lock:
            for target in targets:
                self._phases.setdefault(_short(target), "queued")

    def set_phase(self, target: str, phase: str) -> None:
        """Update the progress strip without recording a fact."""
        with self._lock:
            self._phases[_short(target)] = phase

    def milestone(self, target: str, phase: str, **facts: Any) -> bool:
        """Record one fact for (target, phase); repeats only update the phase."""
        name = _short(target)
        with self._lock:
            self._phases[name] = phase
            if (name, phase) in self._posted:
                return False
            self._posted.add((name, phase))
            fact = {"target": name, "phase": phase, **facts}
            self._pending.append(fact)
        self._publish(fact)
        return True

    def announce(self, key: str, **facts: Any) -> bool:
        """Record one run-level fact (not tied to a target); repeats of ``key`` are dropped."""
        with self._lock:
            if ("", key) in self._posted:
                return False
            self._posted.add(("", key))
            fact = {"phase": key, **facts}
            self._pending.append(fact)
        self._publish(fact)
        return True

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            phases = dict(self._phases)
            elapsed = self._clock() - self._started_at
        done = sum(1 for value in phases.values() if value in _TERMINAL)
        return {"targets": phases, "done": done, "total": len(phases), "elapsed_seconds": int(elapsed)}

    # Narration: only while a narrator is attached (the supervisor's invocation is running).
    def start_narration(self, narrator: Narrator) -> None:
        with self._lock:
            self._narrator = narrator
        self._stop.clear()
        if self._thread is None:
            interval = min(10.0, self._min_gap_seconds / 3)

            def loop() -> None:
                while not self._stop.wait(interval):
                    try:
                        self.narrate()
                    except Exception:  # narration never fails the run
                        continue

            self._thread = threading.Thread(target=loop, name=f"migration-progress-{self._run_id}", daemon=True)
            self._thread.start()

    def stop_narration(self, *, flush: bool = True) -> None:
        """Detach the narrator; ``flush`` asks it once more for facts not yet narrated."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        if flush:
            try:
                self.narrate(force=True)
            except Exception:
                pass
        with self._lock:
            self._narrator = None

    def narrate(self, *, force: bool = False) -> bool:
        """Ask the supervisor for an update when facts are waiting or the chat is quiet."""
        with self._lock:
            narrator = self._narrator
            quiet = self._clock() - self._last_update_at
            facts = list(self._pending)
            due = bool(facts) and (force or quiet >= self._min_gap_seconds)
            heartbeat = not facts and quiet >= self._heartbeat_seconds
            previous = self._last_update_text
            earlier = list(self._earlier_updates)
            recent = list(self._recent)
        if narrator is None or not (due or heartbeat):
            return False
        status = self.snapshot()
        if heartbeat and status["total"] and status["done"] == status["total"]:
            return False
        if heartbeat and not status["total"] and not recent:
            return False  # nothing verified to report yet
        text = narrator({"new_events": facts, "status": status, "previous_update": previous,
                         "earlier_updates": earlier, "recent_activity": recent,
                         # Before the executor plans its targets, nothing is mapped yet.
                         "stage": "executing" if status["total"] else "research",
                         "reason": "heartbeat" if heartbeat else "milestones"})
        text = str(text or "").strip()
        with self._lock:
            # Narrated facts are consumed even when the supervisor had nothing to add.
            self._pending = self._pending[len(facts):]
            if not text:
                # Wait a full gap before asking again about the same quiet period.
                self._last_update_at = self._clock() if heartbeat else self._last_update_at
                return False
        self(
            "assistant.update", "running", text,
            {"trace_id": f"progress:{self._run_id}", "kind": "assistant", "text": text,
             "source": "supervisor", "progress": {"kind": "heartbeat" if heartbeat else "milestone", **status}},
        )
        return True

    def _publish(self, fact: dict[str, Any]) -> None:
        """Structured fact for the activity tree and the progress strip; never chat text."""
        self._trace(
            "automap.progress", "running", f"{fact.get('target') or 'run'}: {fact.get('phase')}",
            {"trace_id": f"progress:{self._run_id}:{fact.get('target') or 'run'}", "parent_trace_id": "mapping-execution",
             "kind": "progress", "label": f"{fact.get('target') or 'Run'} · {fact.get('phase')}",
             "fact": fact, "progress": self.snapshot()},
        )
