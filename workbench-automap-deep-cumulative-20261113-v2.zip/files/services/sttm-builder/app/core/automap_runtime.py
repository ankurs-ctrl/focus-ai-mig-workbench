"""Production dependencies for the opt-in parallel Auto-map path.

No DDL, credential discovery, owner fallback, or artifact bodies in request context.
Deployment must provision the configured archive table with these columns:
OWNER_ID VARCHAR, ACCESS_SCOPE VARCHAR, SNAPSHOT_ID VARCHAR, CONTENT_HASH VARCHAR,
BODY VARCHAR(16777216), CREATED_AT TIMESTAMP_LTZ. Runtime needs SELECT/INSERT only;
retention and native row-access controls are deployment responsibilities. Duplicate
concurrent inserts are harmless: every read verifies the content hash and scope.
The permit table is separately provisioned using automap_call_admission.sql.

Only custom OAuth can be reconstructed from the existing caller session context.
Other authentication modes require an explicitly injected, authenticated caller
and exclusive SessionFactory. A connector session token is NOT a login credential.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from enum import Enum
import hashlib
import hmac
import json
import math
import re
from threading import Event, Lock, get_ident
import time
from uuid import UUID, uuid4

import httpx

from app.core.automap_admission import (
    AdmissionError, AdmissionUnavailable, Completion, Permit, SessionFactory,
    SnowflakeCallAdmission, ScanCallAdmission, StalePermit, ThreadReference, request_digest,
)
from app.core.automap_batch import ParallelRuntimeBundle
from app.core.automap_parallel import ParallelLimits
from app.core.automap_scan import ScanRequest
from app.core.automap_scan_transport import (
    ScanTransportConfig, SnowflakeScanTransport, ThreadRecoveryObservation,
    ThreadTerminalEvidence, ThreadTerminalStatus,
)
from app.core.automap_shards import MessageBudget, SnapshotScope
from app.core.snowflake import SnowflakeLeaseDeadlineExpired, caller_write_lease
from app.core.snowflake_agent import SnowflakeAgentClient, _shared_http_client
from app.core.warehouse_routing import WarehouseWorkload


class RuntimeConfigurationError(ValueError):
    """Parallel execution is unavailable; legacy/owner fallback is forbidden."""


def _text(value, name):
    if (type(value) is not str or not value.strip() or len(value) > 256
            or any(ord(char) < 32 or ord(char) == 127 for char in value)):
        raise RuntimeConfigurationError(f"{name} requires a nonempty trusted value")
    return value


def _integer(value, name, minimum=1, maximum=120_000):
    if type(value) is not int or not minimum <= value <= maximum:
        raise RuntimeConfigurationError(f"{name} must be an integer in [{minimum}, {maximum}]")
    return value


def _fqn(value, name):
    if type(value) is not str or not re.fullmatch(
            r"[A-Za-z_][A-Za-z0-9_$]{0,254}(\.[A-Za-z_][A-Za-z0-9_$]{0,254}){2}", value):
        raise RuntimeConfigurationError(f"{name} requires an unquoted DATABASE.SCHEMA.OBJECT")
    return value.upper()


def _host(value):
    if type(value) is not str or not value or value != value.strip():
        raise RuntimeConfigurationError("A configured Snowflake HTTPS host is required")
    origin = httpx.URL("https://" + value)
    if (not origin.host or origin.userinfo or origin.path not in ("", "/")
            or origin.query or origin.fragment or origin.port not in (None, 443)
            or not origin.host.endswith(".snowflakecomputing.com")):
        raise RuntimeConfigurationError("Invalid Snowflake account host")
    return origin.host.lower()


@dataclass(frozen=True)
class RuntimeCaller:
    """Server-authenticated identity, NEVER constructed from req.actor/model data.

    actor_id may be an application principal ID; native_user is its verified
    Snowflake CURRENT_USER. The role/account must match every leased session.
    """

    actor_id: str
    native_user: str
    role: str
    account_namespace: str

    def __post_init__(self):
        for name in ("actor_id", "native_user", "role", "account_namespace"):
            _text(getattr(self, name), name)
        if not re.fullmatch(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", self.account_namespace):
            raise RuntimeConfigurationError("Caller requires canonical ORG.ACCOUNT")

    @property
    def access_scope(self):
        return hashlib.sha256(json.dumps(
            [self.account_namespace, self.native_user, self.role, self.actor_id],
            separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()


def _deadline_params(deadline):
    remaining = 5 if deadline is None else deadline - time.monotonic()
    if remaining <= 0:
        raise ArchiveDeadlineExpired("Parallel archive deadline expired")
    # Snowflake SQL timeouts have whole-second granularity; synchronous collect
    # and connection creation cannot guarantee wall-clock cancellation. Recheck
    # after returning, and never apply the work deadline to required cleanup.
    return {"STATEMENT_TIMEOUT_IN_SECONDS": str(max(1, min(5, math.ceil(remaining)))), "LOCK_TIMEOUT": "1"}


def _session_identity(session, *, deadline=None):
    statement_params = _deadline_params(deadline)
    try:
        rows = session.sql(
            "SELECT CURRENT_USER() AS NATIVE_USER, CURRENT_ROLE() AS ROLE_NAME, "
            "CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() AS ACCOUNT_NAMESPACE, "
            "CURRENT_TRANSACTION() AS TRANSACTION_ID"
        ).collect(statement_params=statement_params)
    except Exception:
        _deadline_params(deadline)
        raise
    _deadline_params(deadline)
    if len(rows) != 1:
        raise RuntimeConfigurationError("Missing authenticated Snowflake session identity")
    row = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
    if row.get("TRANSACTION_ID") is not None:
        raise RuntimeConfigurationError("Parallel runtime requires a transaction-free caller session")
    return RuntimeCaller(row.get("NATIVE_USER"), row.get("NATIVE_USER"),
                         row.get("ROLE_NAME"), row.get("ACCOUNT_NAMESPACE"))


def _same_native(actual, expected):
    if (actual.native_user, actual.role, actual.account_namespace) != (
            expected.native_user, expected.role, expected.account_namespace):
        raise RuntimeConfigurationError("Leased session caller, role, or account mismatch")


# Reject accidental same-session providers even across independent factory calls.
_ACTIVE_SESSIONS = set()
_ACTIVE_LOCK = Lock()


def _checked_sessions(provider, caller, forbidden, *, deadline_provider=None):
    @contextmanager
    def lease(*, deadline=None):
        _deadline_params(deadline)
        failed = False
        entered = False
        operation_failure = None
        try:
            context = deadline_provider(deadline) if deadline is not None and deadline_provider is not None else provider()
            with context as session:
                _deadline_params(deadline)
                key = id(session)
                with _ACTIVE_LOCK:
                    if any(session is existing for existing in forbidden) or key in _ACTIVE_SESSIONS:
                        raise RuntimeConfigurationError("An exclusive independent caller session is required")
                    _ACTIVE_SESSIONS.add(key)
                try:
                    _same_native(_session_identity(session, deadline=deadline), caller)
                    entered = True
                    yield session
                except BaseException as exc:
                    failed = True
                    if entered:
                        operation_failure = exc
                    raise
                finally:
                    with _ACTIVE_LOCK:
                        _ACTIVE_SESSIONS.remove(key)
            _deadline_params(deadline)
            if failed or not entered:
                raise RuntimeConfigurationError("Caller session provider suppressed a failure")
        except SnowflakeLeaseDeadlineExpired:
            raise ArchiveDeadlineExpired("Parallel archive deadline expired") from None
        except (RuntimeConfigurationError, AdmissionError):
            raise
        except Exception as exc:
            _deadline_params(deadline)
            failure = RuntimeConfigurationError("Exclusive caller session unavailable")
            from app.core.sql_failure import sql_failure_details
            failure.sql_failure = sql_failure_details(exc)
            failure.lease_stage = 'operation' if exc is operation_failure else 'provider_exit' if entered else 'acquire_or_identity'
            failure.lease_error_type = type(exc).__name__
            known = {'Session pool has been retired': 'pool_retired',
                     'Snowflake session lease capacity is exhausted': 'pool_saturated',
                     'Write connection capacity is exhausted; retry later': 'write_capacity_saturated'}
            failure.lease_error_code = known.get(str(exc), 'lease_unavailable')
            # Only allowlisted operation metadata may cross this secrecy boundary.
            # Acquisition, identity checks and provider exit are never contention.
            if exc is operation_failure:
                from app.core.sql_failure import sql_failure_details
                failure.sql_failure = sql_failure_details(exc)
                for code in (getattr(exc,'sql_error_code',None),getattr(exc,'errno',None)):
                    if type(code) in (int,str) and str(code).lstrip('0') in {'627','630'}:
                        failure.errno=int(str(code).lstrip('0'))
                        break
            raise failure from None
    # SessionFactory remains a no-argument callable for admission and injected
    # providers. Archives opt into this explicit deadline-aware extension.
    lease.with_deadline = lambda deadline: lease(deadline=deadline)
    return lease


def _resolve_caller(service, account_namespace, expected_host, *, deadline=None):
    _deadline_params(deadline)
    if getattr(service._settings,'automap_local_sso_enabled',False) and getattr(service._settings,'automap_durable_runs_v2',False):
        from app.core.automap_local_session import local_session, validate_local_settings
        validate_local_settings(service._settings)
        caller = _session_identity(service._session,deadline=deadline)
        if caller.account_namespace != account_namespace or caller.native_user != service._settings.snowflake_user.upper():
            raise RuntimeConfigurationError('Local caller account/user mismatch')
        _same_native(_session_identity(service._query_session,deadline=deadline),caller)
        @contextmanager
        def local_provider():
            with local_session(service._settings,caller.role) as session:
                yield session
        factory=_checked_sessions(local_provider,caller,(service._session,service._query_session))
        with factory(): pass
        return caller,factory
    deadline_provider = None
    supplied = getattr(service, "_parallel_caller", None)
    provider = getattr(service, "_parallel_session_factory", None)
    if (supplied is None) != (provider is None):
        raise RuntimeConfigurationError("Inject both parallel_caller and parallel_session_factory")
    if supplied is not None:
        if not isinstance(supplied, RuntimeCaller) or not callable(provider):
            raise RuntimeConfigurationError("A trusted RuntimeCaller and exclusive SessionFactory are required")
        caller = supplied
    else:
        settings = service._settings
        context = getattr(service._session, "_workbench_search_context", None)
        agent = service._agent
        if (getattr(settings, "uses_custom_oauth", False) is not True
                or agent._auth_mode != "oauth_bearer" or type(context) is not dict):
            raise RuntimeConfigurationError(
                "Caller login credentials unavailable: inject parallel_caller and "
                "parallel_session_factory; existing Session/session tokens cannot be shared or cloned")
        token, role = context.get("token"), context.get("role")
        if (type(token) is not str or not token.strip() or type(agent._token) is not str
                or not hmac.compare_digest(token.encode(), agent._token.encode())
                or _host(context.get("host")) != expected_host
                or type(role) is not str or not role or agent._role != role):
            raise RuntimeConfigurationError("Existing agent and caller OAuth context do not match")
        if getattr(settings, "snowflake_write_lease_pool_v1", False) is not True:
            raise RuntimeConfigurationError("SNOWFLAKE_WRITE_LEASE_POOL_V1 is required for reusable caller sessions")
        # This read is before launching workers. The request session is never lent.
        try:
            caller = _session_identity(service._session, deadline=deadline)
        except RuntimeConfigurationError:
            raise
        except Exception:
            raise RuntimeConfigurationError("Could not verify authenticated caller identity") from None
        if caller.role != role:
            raise RuntimeConfigurationError("Caller OAuth role differs from active session")

        @contextmanager
        def provider(deadline=None, purpose="request"):
            with caller_write_lease(settings, token, role, WarehouseWorkload.CONTROL,
                                    reusable=True, deadline=deadline, purpose=purpose,
                                    maximum=2 if purpose=="automap-recovery" else _integer(getattr(settings, "automap_admission_session_capacity", 2),
                                                     "AUTOMAP_ADMISSION_SESSION_CAPACITY", maximum=8)) as client:
                yield client.session

        deadline_provider = provider

    if caller.account_namespace != account_namespace:
        raise RuntimeConfigurationError("Caller account differs from configured admission account")
    if supplied is not None:
        # Injection is trusted, but still reject a provider for another caller.
        try:
            _same_native(_session_identity(service._session, deadline=deadline), caller)
            _same_native(_session_identity(getattr(service, "_query_session", service._session), deadline=deadline), caller)
        except RuntimeConfigurationError:
            raise
        except Exception:
            raise RuntimeConfigurationError("Could not verify injected caller identity") from None
    factory = _checked_sessions(provider, caller,
        (service._session, getattr(service, "_query_session", service._session)),
        deadline_provider=deadline_provider or getattr(provider, "with_deadline", None))
    if supplied is None:
        @contextmanager
        def recovery_provider(deadline=None):
            with provider(deadline=deadline,purpose="automap-recovery") as session:
                yield session
        factory.recovery_factory = _checked_sessions(recovery_provider,caller,
            (service._session,getattr(service,'_query_session',service._session)),deadline_provider=recovery_provider)
    else:
        factory.recovery_factory = getattr(provider,'recovery_factory',factory)
    # Fail before archive/model work when the injected provider is not same-caller.
    with factory(deadline=deadline):
        pass
    return caller, factory


class ArchiveDeadlineExpired(RuntimeConfigurationError):
    """The shared work budget elapsed during archive acquisition or operation."""


class ArchiveStorageFailure(RuntimeConfigurationError):
    """Archive operation failed; expose only the underlying exception type."""

    def __init__(self, message: str, *, cause_type: str) -> None:
        self.cause_type = cause_type
        super().__init__(message)


class SnowflakeReductionArchive:
    """Exact scoped immutable blobs in an explicitly provisioned metadata table.

    The hash is integrity, not authorization. Every SQL read/write also scopes by
    authenticated native user, access scope and snapshot. There is no memory cache,
    truncation, DDL, or local-disk fallback. Writes commit before returning a handle.
    """

    max_batch_records = 32
    max_batch_request_bytes = 1_000_000

    def __init__(self, *, session_factory: SessionFactory, table: str,
                 caller: RuntimeCaller, scope: SnapshotScope, deadline: float,
                 max_blob_bytes: int = 16_000_000, storage_retry_attempts: int = 0):
        if (not callable(session_factory) or not isinstance(caller, RuntimeCaller)
                or not isinstance(scope, SnapshotScope)
                or type(deadline) not in (int, float) or not math.isfinite(deadline)):
            raise RuntimeConfigurationError("Archive requires trusted sessions, scope and finite deadline")
        self._factory = session_factory
        self._table = _fqn(table, "archive table")
        self._caller, self._scope, self._deadline = caller, scope, deadline
        if type(storage_retry_attempts) is not int or not 0<=storage_retry_attempts<=2:
            raise ValueError('Archive retries must be bounded to two')
        self._storage_retry_attempts=storage_retry_attempts
        self._max_bytes = _integer(max_blob_bytes, "archive max_blob_bytes", maximum=16_000_000)
        if scope.owner_id != caller.native_user:
            raise RuntimeConfigurationError("Archive owner must be the authenticated native user")

    def check_active(self):
        """Reject new archive/finalization work after this absolute deadline."""
        _deadline_params(self._deadline)

    @contextmanager
    def _session(self):
        self.check_active()
        bounded = getattr(self._factory, "with_deadline", None)
        try:
            # Legacy injected factories cannot bound acquisition internally;
            # checked factories guard identity, and this wrapper guards archive SQL.
            with (bounded(self._deadline) if bounded is not None else self._factory()) as session:
                self.check_active()
                yield session
            self.check_active()
        except Exception:
            self.check_active()
            raise

    def _sql(self, session, sql, params=None):
        return self._collect_sql(session, sql, params, statement_params=_deadline_params(self._deadline))

    def _collect_sql(self, session, sql, params=None, *, statement_params):
        # Snowpark AST otherwise embeds another encoded copy of every bound
        # snapshot in query metadata. Keep large single binds and batch budgets
        # about the actual SQL request, without changing caller/session settings.
        try:
            rows = session.sql(sql, params=params, _emit_ast=False).collect(
                _emit_ast=False, statement_params=statement_params)
        except Exception:
            self.check_active()
            raise
        self.check_active()
        return rows

    def _params(self, reference):
        if type(reference) is not str or not re.fullmatch(r"[0-9a-f]{64}", reference):
            raise RuntimeConfigurationError("Invalid archive reference")
        return [self._caller.native_user, self._caller.access_scope, self._scope.snapshot_id, reference]

    def _validate(self, reference, text):
        if (type(text) is not str or len(text.encode("utf-8")) > self._max_bytes
                or hashlib.sha256(text.encode("utf-8")).hexdigest() != reference):
            raise RuntimeConfigurationError("Archive content integrity/budget failure")
        value = json.loads(text)
        if (type(value) is not dict or value.get("scope") != {
                "owner_id": self._scope.owner_id, "snapshot_id": self._scope.snapshot_id}):
            raise RuntimeConfigurationError("Archive content scope mismatch")
        return text

    def _read(self, session, reference):
        return self._read_many(session, (reference,)).get(reference)

    def _references(self, references):
        if type(references) not in (tuple, list) or not 1 <= len(references) <= self.max_batch_records:
            raise RuntimeConfigurationError("Archive batch requires 1 to 32 references")
        for reference in references:
            self._params(reference)
        if len(set(references)) != len(references):
            raise RuntimeConfigurationError("Duplicate archive batch reference")
        return tuple(references)

    def _request_bytes(self, sql, params):
        # Account for the SQL and qmark binding metadata, including JSON escaping
        # of the JSON-array bind itself. Reserve space for connector request IDs.
        envelope = {"sqlText": sql, "bindings": {
            str(index): {"type": "TEXT", "value": value} for index, value in enumerate(params, 1)},
            "parameters": {"STATEMENT_TIMEOUT_IN_SECONDS": "5", "LOCK_TIMEOUT": "1"}}
        return len(json.dumps(envelope, ensure_ascii=True).encode("utf-8")) + 4096

    def _read_many(self, session, references):
        references = self._references(references)
        # Never collect 32 full-sized snapshots at once. Oversize bodies return
        # only metadata; at most max_blob_bytes is hydrated, using single reads.
        inline_bytes = self._max_bytes if len(references) == 1 else self.max_batch_request_bytes // len(references)
        sql = (f"SELECT CONTENT_HASH, COUNT(*) AS ROW_COUNT, COUNT(BODY) AS BODY_COUNT, "
            "COUNT(DISTINCT BODY) AS BODY_VERSIONS, OCTET_LENGTH(MIN(BODY)) AS BODY_BYTES, "
            f"IFF(OCTET_LENGTH(MIN(BODY)) <= {inline_bytes}, MIN(BODY), NULL) AS BODY "
            f"FROM {self._table} WHERE OWNER_ID = ? AND ACCESS_SCOPE = ? AND SNAPSHOT_ID = ? "
            f"AND CONTENT_HASH IN ({', '.join('?' for _ in references)}) GROUP BY CONTENT_HASH")
        params = self._params(references[0])[:3] + list(references)
        if self._request_bytes(sql, params) > self.max_batch_request_bytes:
            raise RuntimeConfigurationError("Archive read request exceeds batch budget")
        rows = self._sql(session, sql, params)
        if len(rows) > len(references):
            raise RuntimeConfigurationError("Unexpected archive batch rows")
        found = {}
        sizes = {}
        total_bytes = 0
        for raw in rows:
            row = raw.as_dict() if hasattr(raw, "as_dict") else dict(raw)
            reference = row.get("CONTENT_HASH")
            count, body_count = row.get("ROW_COUNT"), row.get("BODY_COUNT")
            size, versions = row.get("BODY_BYTES"), row.get("BODY_VERSIONS")
            if (reference not in references or reference in found
                    or type(count) is not int or count < 1 or type(body_count) is not int or body_count != count
                    or type(versions) is not int or versions != 1
                    or type(size) is not int or not 0 < size <= self._max_bytes):
                raise RuntimeConfigurationError("Conflicting or invalid immutable archive rows")
            total_bytes += size
            if total_bytes > self._max_bytes:
                raise RuntimeConfigurationError("Archive read batch exceeds body budget; use single reads")
            text = row.get("BODY")
            if size <= inline_bytes:
                self._validate(reference, text)
                if len(text.encode("utf-8")) != size:
                    raise RuntimeConfigurationError("Archive body size mismatch")
            elif text is not None:
                raise RuntimeConfigurationError("Unbounded archive batch body")
            found[reference] = text
            sizes[reference] = size
        for reference, text in found.items():
            if text is None:
                text = self._read(session, reference)
                if text is None:
                    raise RuntimeConfigurationError("Scoped archive reference disappeared")
                if len(text.encode("utf-8")) != sizes[reference]:
                    raise RuntimeConfigurationError("Archive body changed during bounded read")
                found[reference] = text
        return found

    def _insert_many_statement(self, items):
        sql = (f"INSERT INTO {self._table} "
            "(OWNER_ID, ACCESS_SCOPE, SNAPSHOT_ID, CONTENT_HASH, BODY, CREATED_AT) "
            "SELECT ?, ?, ?, VALUE:reference::VARCHAR, VALUE:body::VARCHAR, CURRENT_TIMESTAMP() "
            "FROM TABLE(FLATTEN(INPUT => PARSE_JSON(?)))")
        body = json.dumps([{"reference": reference, "body": text} for reference, text in items.items()],
                          ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return sql, self._params(next(iter(items)))[:3] + [body]

    def can_put_many(self, items):
        """Whether a bounded dictionary fits the full encoded bulk SQL request."""
        if type(items) is not dict or not 1 <= len(items) <= self.max_batch_records:
            return False
        if (any(type(text) is not str for text in items.values())
                or sum(len(text) for text in items.values()) > self.max_batch_request_bytes):
            return False
        sql, params = self._insert_many_statement(items)
        return self._request_bytes(sql, params) <= self.max_batch_request_bytes

    def _ack_insert(self, rows, expected):
        result = rows[0].as_dict() if len(rows) == 1 and hasattr(rows[0], "as_dict") else (
            dict(rows[0]) if len(rows) == 1 else {})
        count = result.get("number of rows inserted")
        if type(count) is not int or count != expected:
            raise RuntimeConfigurationError("Archive insert was not acknowledged")

    def _put_many(self, session, items):
        if not self.can_put_many(items):
            raise RuntimeConfigurationError("Archive write batch exceeds request budget; use single put")
        for reference, text in items.items():
            self._params(reference)
            self._validate(reference, text)
        previous = self._read_many(session, tuple(items))
        if any(previous[reference] != items[reference] for reference in previous):
            raise RuntimeConfigurationError("Archive reference is immutable")
        missing = {reference: text for reference, text in items.items() if reference not in previous}
        if missing:
            sql, params = self._insert_many_statement(missing)
            self._ack_insert(self._sql(session, sql, params), len(missing))

    def _put(self, session, reference, text):
        params = self._params(reference)
        self._validate(reference, text)
        previous = self._read(session, reference)
        if previous is None:
            rows = self._sql(session, f"INSERT INTO {self._table} "
                "(OWNER_ID, ACCESS_SCOPE, SNAPSHOT_ID, CONTENT_HASH, BODY, CREATED_AT) "
                "SELECT ?, ?, ?, ?, ?, CURRENT_TIMESTAMP()", params + [text])
            self._ack_insert(rows, 1)
        elif previous != text:
            raise RuntimeConfigurationError("Archive reference is immutable")

    def with_deadline(self, deadline):
        """New operator budget, retaining the exact authenticated archive namespace."""
        return SnowflakeReductionArchive(session_factory=self._factory, table=self._table,
            caller=self._caller, scope=self._scope, deadline=deadline, max_blob_bytes=self._max_bytes,
            storage_retry_attempts=self._storage_retry_attempts)

    def get(self, reference):
        return self.get_many((reference,))[reference]

    def get_many(self, references):
        for attempt in range(self._storage_retry_attempts+1):
            try:
                return self._get_many_once(references)
            except ArchiveStorageFailure:
                if attempt==self._storage_retry_attempts:raise
                self.check_active()

    def _get_many_once(self, references):
        self.check_active()
        references = self._references(references)
        result = None
        try:
            with self._session() as session:
                result = self._read_many(session, references)
                if set(result) != set(references):
                    raise RuntimeConfigurationError("Scoped archive references unavailable")
            if result is None or set(result) != set(references):
                raise RuntimeConfigurationError("Archive provider suppressed a read failure")
            return result
        except ArchiveDeadlineExpired:
            raise
        except Exception as exc:
            raise ArchiveStorageFailure("Scoped archive read failed", cause_type=type(exc).__name__) from None

    def put_verified(self, reference, text, *, on_read=None):
        """Exact readback on the writing lease; durable only after COMMIT ACK.

        Unknown acknowledgements use the existing content-addressed retry policy:
        the next transaction reads existing content before any insert.
        """
        self.check_active()
        self._params(reference)
        self._validate(reference, text)
        for attempt in range(self._storage_retry_attempts + 1):
            try:
                with self.checkpoint() as checkpoint:
                    checkpoint.put(reference, text)
                    if on_read is not None:on_read()
                    if checkpoint.get(reference) != text:
                        raise RuntimeConfigurationError('Archive readback differs from exact content')
                return
            except ArchiveStorageFailure:
                if attempt == self._storage_retry_attempts:raise
                self.check_active()

    def put_many_verified(self, items, *, on_read=None):
        """One bounded transaction and one exact readback for related artifacts."""
        self.check_active()
        if not self.can_put_many(items):
            raise RuntimeConfigurationError("Archive write batch exceeds request budget")
        items = dict(items)
        for reference, text in items.items():
            self._params(reference)
            self._validate(reference, text)
        for attempt in range(self._storage_retry_attempts + 1):
            try:
                with self.checkpoint() as checkpoint:
                    checkpoint.put_many(items)
                    if on_read is not None:
                        on_read()
                    if checkpoint.get_many(tuple(items)) != items:
                        raise RuntimeConfigurationError("Archive readback differs from exact content")
                return
            except ArchiveStorageFailure:
                if attempt == self._storage_retry_attempts:
                    raise
                self.check_active()

    def put(self, reference, text):
        self.check_active()
        self._params(reference)
        self._validate(reference, text)
        for attempt in range(self._storage_retry_attempts+1):
            try:
                with self.checkpoint() as checkpoint:
                    checkpoint.put(reference, text)
                return
            except ArchiveStorageFailure:
                if attempt==self._storage_retry_attempts:raise
                # A failed COMMIT acknowledgement may have committed. A fresh
                # exclusive session reads the exact content address before any
                # insert; conflicting content remains a hard error. No model
                # invocation or request deadline is changed by this retry.
                self.check_active()

    def put_many(self, items):
        """Atomically persist one bounded batch; plain put remains durable too."""
        self.check_active()
        if not self.can_put_many(items):
            raise RuntimeConfigurationError("Archive write batch exceeds request budget; use single put")
        items = dict(items)
        for reference, text in items.items():
            self._params(reference)
            self._validate(reference, text)
        for attempt in range(self._storage_retry_attempts+1):
            try:
                with self.checkpoint() as checkpoint:
                    checkpoint.put_many(items)
                return
            except ArchiveStorageFailure:
                if attempt==self._storage_retry_attempts:raise
                self.check_active()

    @contextmanager
    def checkpoint(self):
        """Explicit atomic phase, on one exclusive caller lease and deadline.

        Only the yielded transaction view may read uncommitted writes. No handle
        is durable until this context exits successfully, including COMMIT ACK.
        """
        committed = False
        body_error = None
        try:
            with self._session() as session:
                # Preflight outside rollback handling: no BEGIN was attempted if
                # this fails. Once submitted, even an uncertain BEGIN needs cleanup.
                statement_params = _deadline_params(self._deadline)
                view = _ArchiveCheckpoint(self, session)
                try:
                    self._collect_sql(session, "BEGIN TRANSACTION", statement_params=statement_params)
                    try:
                        yield view
                    except BaseException as exc:
                        body_error = exc
                        raise
                    if view.failed:
                        raise RuntimeConfigurationError("Archive checkpoint contains a failed operation")
                    self._sql(session, "COMMIT")
                    committed = True
                except BaseException:
                    try:
                        session.sql("ROLLBACK", _emit_ast=False).collect(_emit_ast=False, statement_params={
                            "STATEMENT_TIMEOUT_IN_SECONDS": "5", "LOCK_TIMEOUT": "1"})
                    except Exception:
                        pass
                    raise
                finally:
                    view.active = False
            if not committed:
                raise RuntimeConfigurationError("Archive provider suppressed a write failure")
        except ArchiveDeadlineExpired:
            raise
        except Exception as exc:
            if exc is body_error:
                raise
            raise ArchiveStorageFailure("Durable archive write failed", cause_type=type(exc).__name__) from None


class _ArchiveCheckpoint:
    """Short-lived transaction view, never shared with another thread or phase."""

    def __init__(self, archive, session):
        self.archive, self.session = archive, session
        self.thread = get_ident()
        self.active, self.failed = True, False

    def _call(self, operation, *args):
        try:
            if not self.active or self.thread != get_ident() or self.failed:
                raise RuntimeConfigurationError("Archive checkpoint is inactive or foreign")
            return operation(self.session, *args)
        except ArchiveDeadlineExpired:
            self.failed = True
            raise
        except Exception as exc:
            self.failed = True
            raise ArchiveStorageFailure("Archive checkpoint operation failed", cause_type=type(exc).__name__) from None
        except BaseException:
            self.failed = True
            raise

    def put(self, reference, text):
        self._call(self.archive._put, reference, text)

    def put_many(self, items):
        self._call(self.archive._put_many, items)

    def get_many(self, references):
        result = self._call(self.archive._read_many, references)
        if set(result) != set(references):
            self.failed = True
            raise RuntimeConfigurationError("Scoped archive references unavailable")
        return result

    def get(self, reference):
        return self.get_many((reference,))[reference]


class ReconciliationStatus(str, Enum):
    RELEASED = "RELEASED"
    UNTRACKED_REQUIRES_OPERATOR = "UNTRACKED_REQUIRES_OPERATOR"
    NO_TERMINAL_EVIDENCE = "NO_TERMINAL_EVIDENCE"
    STALE_PERMIT = "STALE_PERMIT"
    REJECTED = "REJECTED"
    RELEASE_UNCERTAIN = "RELEASE_UNCERTAIN"


@dataclass(frozen=True)
class ReconciliationResult:
    status: ReconciliationStatus
    evidence_ref: str | None = None
    terminal: ThreadTerminalEvidence | None = None


@dataclass(frozen=True)
class OccupiedRuntimePermit:
    permit: Permit
    state: str
    reference: ThreadReference | None


class RuntimeCallAdmission(SnowflakeCallAdmission):
    """Runtime pool adds a public exact-owner inspection, without claiming a slot.

    Keep owner lookup inside the pool API. Never reconstruct OWNER_TOKEN from a
    caller, slot number, diagnostic or a new job. The original Permit is required.
    """

    def inspect_occupied(self, permit: Permit) -> OccupiedRuntimePermit:
        params = self._permit_params(permit)
        try:
            with self._factory() as session:
                rows = self._sql(session,
                    f"SELECT STATE, RECONCILIATION_REF FROM {self._table} "
                    "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                    "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                    "AND GENERATION = ? AND SHARD_ID = ? AND STATE IN ('HELD', 'QUARANTINED') "
                    "AND ACCOUNT_NAMESPACE = CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() LIMIT 2",
                    params)
                if len(rows) != 1:
                    raise StalePermit("Expected exactly one owned occupied permit")
                row = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
                if row.get("STATE") not in ("HELD", "QUARANTINED") or "RECONCILIATION_REF" not in row:
                    raise AdmissionError("Malformed occupied permit")
                raw = row["RECONCILIATION_REF"]
                reference = None if raw is None or raw == "" else ThreadReference.parse(raw)
                return OccupiedRuntimePermit(permit, row["STATE"], reference)
        except AdmissionError:
            raise
        except Exception:
            raise AdmissionUnavailable("Scoped permit inspection unavailable") from None

    def reconcile_terminal(self, permit, completion, *, evidence_ref, retired_dispatcher,
                           expected_occupied=None):
        if expected_occupied is None:
            return super().reconcile_terminal(permit, completion, evidence_ref=evidence_ref,
                                             retired_dispatcher=retired_dispatcher)
        if (retired_dispatcher is not True or type(expected_occupied) is not OccupiedRuntimePermit
                or expected_occupied.permit != permit or expected_occupied.reference is None
                or type(completion) is not Completion):
            raise AdmissionError("Exact occupied state and dispatcher retirement required")
        _text(evidence_ref, "evidence_ref")
        if len(evidence_ref) > 255:
            raise AdmissionError("Reconciliation reference exceeds 255 characters")
        params = self._permit_params(permit)
        with self._transaction() as session:
            rows = self._sql(session,
                f"UPDATE {self._table} SET STATE = 'FREE', OWNER_TOKEN = NULL, FENCE = FENCE + 1, "
                "LEASE_EXPIRES_AT = NULL, COMPLETION = ?, RECONCILIATION_REF = ?, UPDATED_AT = CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                "AND GENERATION = ? AND SHARD_ID = ? AND STATE = ? AND RECONCILIATION_REF = ?",
                [completion.value, evidence_ref] + params + [expected_occupied.state,
                    expected_occupied.reference.serialize()])
            row = rows[0].as_dict() if len(rows) == 1 and hasattr(rows[0], "as_dict") else (
                dict(rows[0]) if len(rows) == 1 else {})
            count = {key.lower(): value for key, value in row.items()}.get("number of rows updated")
            if type(count) is int and count == 0:
                raise StalePermit("Occupied permit changed before reconciliation")
            if type(count) is not int or count != 1:
                raise AdmissionError("Reconciliation update was not uniquely acknowledged")


def reconcile_parallel_runtime(bundle: ParallelRuntimeBundle, *, permit: Permit,
                               original_request: ScanRequest, snapshot_archive_ref: str,
                               retired_dispatcher: bool, deadline: float) -> ReconciliationResult:
    """Explicit operator-only GET recovery; never dispatch, cancel, retry or claim.

    Use the original trusted factory bundle (admission.store is the public pool),
    original Permit including OWNER_TOKEN, original typed ScanRequest and the
    prepare_parallel snapshot_archive_ref. The persisted ThreadReference binds
    the EXACT original message digest; a caller-supplied replacement cannot pass.
    We do not reconstruct scan/reduction messages from mutable current settings.

    deadline is a fresh absolute monotonic deadline, at most 60 seconds away.
    Old stop/cancel events apply to dispatch, not this operator's GET; replace them
    only on an immutable recovery copy. retired_dispatcher=True is the operator's
    attestation, NOT independent verification that a paused worker was retired.
    The host must prevent subsequent dispatch by that worker before calling.

    The audit is committed in the same exact owner/access/snapshot archive BEFORE
    pool reconciliation. An audit is evidence of observation/intent, not a receipt
    that release committed. RELEASE_UNCERTAIN must not be treated as success.
    """
    if retired_dispatcher is not True:
        raise RuntimeConfigurationError("Reconciliation requires explicitly retired_dispatcher=True")
    remaining = deadline - time.monotonic() if type(deadline) in (int, float) else float("nan")
    if not math.isfinite(remaining) or not 0 < remaining <= 60:
        raise RuntimeConfigurationError("Recovery requires a fresh deadline within 60 seconds")
    if (not isinstance(bundle, ParallelRuntimeBundle) or type(permit) is not Permit
            or type(original_request) is not ScanRequest
            or not isinstance(bundle.admission, ScanCallAdmission)
            or not isinstance(bundle.admission.store, RuntimeCallAdmission)
            or not isinstance(bundle.backend, SnowflakeScanTransport)
            or not isinstance(bundle.archive, SnowflakeReductionArchive)):
        raise RuntimeConfigurationError("An original production runtime bundle, Permit and ScanRequest are required")
    gate, pool = bundle.admission, bundle.admission.store
    if (bundle.backend._admission is not gate or bundle.scope != original_request.scope
            or bundle.archive._scope != bundle.scope or bundle.scope.owner_id != gate.caller_id
            or permit.identity.caller_id != gate.caller_id or permit.identity.job_id != gate.job_id
            or permit.identity.generation != original_request.generation
            or permit.identity.shard_id != original_request.shard_id):
        return ReconciliationResult(ReconciliationStatus.REJECTED)
    recovery = replace(original_request, deadline=deadline, _cancel=Event(), _stop=Event())
    archive = bundle.archive.with_deadline(deadline)
    evidence_ref = None
    terminal = None
    releasing = False
    try:
        recovery.check_active()
        occupied = pool.inspect_occupied(permit)
        if occupied.reference is None:
            return ReconciliationResult(ReconciliationStatus.UNTRACKED_REQUIRES_OPERATOR)
        reference = occupied.reference
        if (reference.request_digest != request_digest(original_request)
                or reference.agent_fqn != bundle.backend._config.agent):
            return ReconciliationResult(ReconciliationStatus.REJECTED)
        # Existing exact snapshot archive is durable and scoped by native caller,
        # access scope AND snapshot. The separately committed request digest binds
        # the supplied normalized message, including whitespace/escaping, to it.
        snapshot = json.loads(archive.get(snapshot_archive_ref))
        if (snapshot.get("generation") != bundle.scope.snapshot_id
                or type(snapshot.get("value")) is not dict
                or snapshot["value"].get("protocol") != "automap_exact_snapshot_v1"
                or type(snapshot["value"].get("state")) is not dict):
            return ReconciliationResult(ReconciliationStatus.REJECTED)
        recovery.check_active()
        observation = bundle.backend.recover_thread(permit, recovery)
        if (type(observation) is not ThreadRecoveryObservation or observation.permit != permit
                or observation.reference != reference):
            return ReconciliationResult(ReconciliationStatus.REJECTED)
        terminal = observation.terminal
        if terminal is None:
            return ReconciliationResult(ReconciliationStatus.NO_TERMINAL_EVIDENCE)
        if (type(terminal) is not ThreadTerminalEvidence or terminal.thread_id != reference.thread_id
                or observation.assistant_message_ids != (terminal.assistant_message_id,)):
            return ReconciliationResult(ReconciliationStatus.REJECTED)
        recovery.check_active()
        if pool.inspect_occupied(permit) != occupied:
            return ReconciliationResult(ReconciliationStatus.STALE_PERMIT)
        audit = {"scope": asdict(bundle.scope), "generation": original_request.generation,
            "value": {"protocol": "automap_terminal_reconciliation_v1",
                "snapshot_archive_ref": snapshot_archive_ref,
                "account_namespace": permit.account_namespace, "pool_epoch": permit.pool_epoch,
                "slot_id": permit.slot_id, "fence": permit.fence, "state": occupied.state,
                # The capability token stays in the caller's Permit and pool row.
                "owner_token_digest": hashlib.sha256(permit.owner.encode("utf-8")).hexdigest(),
                "identity": asdict(permit.identity), "thread_reference": json.loads(reference.serialize()),
                "terminal": asdict(terminal), "retired_dispatcher_attested": True}}
        text = json.dumps(audit, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        audit_ref = hashlib.sha256(text.encode("utf-8")).hexdigest()
        # Fixed vocabulary + int64 IDs + hash: comfortably below VARCHAR(255).
        evidence_ref = f"thread-v2:{terminal.run_id}:{terminal.assistant_message_id}:{terminal.status.value}:{audit_ref}"
        if len(evidence_ref) > 255:
            raise RuntimeConfigurationError("Terminal reference exceeds reconciliation capacity")
        archive.put(audit_ref, text)
        recovery.check_active()
        # Failed/suppressed archive callbacks cannot authorize release. Read back
        # the durable body, then fence again after all archive I/O.
        if archive.get(audit_ref) != text:
            raise RuntimeConfigurationError("Terminal audit was not durably acknowledged")
        recovery.check_active()
        if pool.inspect_occupied(permit) != occupied:
            return ReconciliationResult(ReconciliationStatus.STALE_PERMIT, evidence_ref, terminal)
        completion = Completion.SUCCEEDED if terminal.status is ThreadTerminalStatus.COMPLETED else Completion.FAILED
        recovery.check_active()
        releasing = True
        pool.reconcile_terminal(permit, completion, evidence_ref=evidence_ref,
                                retired_dispatcher=True, expected_occupied=occupied)
        return ReconciliationResult(ReconciliationStatus.RELEASED, evidence_ref, terminal)
    except StalePermit:
        return ReconciliationResult(ReconciliationStatus.STALE_PERMIT, evidence_ref, terminal)
    except Exception:
        # Do not expose credentials/payloads from injected sessions or callbacks.
        return ReconciliationResult(ReconciliationStatus.RELEASE_UNCERTAIN if releasing
            else ReconciliationStatus.REJECTED, evidence_ref, terminal)


def build_parallel_runtime(service, *, req, decision, store, deadline, fast=False):
    """Factory used by invoke_batch; request/model fields never select resources."""
    if getattr(service._settings,'automap_durable_runs_v2',False) and not fast:
        raise RuntimeConfigurationError('Durable v2 requires the accepted fast-path request protocol')
    settings = service._settings
    if getattr(settings, "automap_parallel_context_v1", False) is not True:
        raise RuntimeConfigurationError("Parallel Auto-map is disabled")
    if not fast:
        settings.validate_parallel_automap()
    if type(deadline) not in (int, float) or not math.isfinite(deadline) or deadline <= time.monotonic():
        raise RuntimeConfigurationError("A live finite parallel deadline is required")
    if not isinstance(service._agent, SnowflakeAgentClient):
        raise RuntimeConfigurationError("Existing same-caller SnowflakeAgentClient required")
    service._model_guard.assert_model_target_allowed(operation=req.operation.value, target="agent", decision=decision)
    agent = (_fqn(service._source_mapping_agent_name, "source mapping agent") if fast else
             _fqn(getattr(settings, "automap_parallel_test_agent", None), "AUTOMAP_PARALLEL_TEST_AGENT"))
    permit_table = _fqn(getattr(settings, "automap_parallel_permit_table_fqn", None), "AUTOMAP_PARALLEL_PERMIT_TABLE_FQN")
    archive_table = _fqn(getattr(settings, "automap_parallel_archive_table_fqn", None), "AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN")
    metadata = _fqn(f"{settings.resolved_metadata_database}.{settings.resolved_metadata_schema}.OBJECT", "metadata namespace").rsplit(".", 1)[0]
    if ((not fast and agent != metadata + ".AGT_AUTOMAP_SCAN_DEV_TEST")
            or any(name.rsplit(".", 1)[0] != metadata for name in (permit_table, archive_table))
            or len({agent, permit_table, archive_table}) != 3):
        raise RuntimeConfigurationError("Only isolated AGT_AUTOMAP_SCAN_DEV_TEST and distinct metadata tables are approved")
    namespace = _text(getattr(settings, "automap_parallel_account_namespace", None), "AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE").upper()
    if not re.fullmatch(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", namespace):
        raise RuntimeConfigurationError("AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE requires canonical ORG.ACCOUNT")
    epoch = _text(getattr(settings, "automap_parallel_pool_epoch", None), "AUTOMAP_PARALLEL_POOL_EPOCH")
    try:
        if str(UUID(epoch)) != epoch:
            raise ValueError
    except ValueError:
        raise RuntimeConfigurationError("AUTOMAP_PARALLEL_POOL_EPOCH requires a canonical UUID") from None
    # Bound only this provisioned scan/reduce pool; final mapping is not admitted here.
    capacity = _integer(getattr(settings, "automap_parallel_pool_capacity", None), "AUTOMAP_PARALLEL_POOL_CAPACITY", maximum=32)
    workers = _integer(getattr(settings, "automap_parallel_max_workers", 2), "AUTOMAP_PARALLEL_MAX_WORKERS", maximum=32)
    chars = min(120_000, _integer(settings.agent_outbound_message_max_chars, "AGENT_OUTBOUND_MESSAGE_MAX_CHARS", maximum=100_000_000))
    size = min(120_000, _integer(settings.agent_outbound_message_max_bytes, "AGENT_OUTBOUND_MESSAGE_MAX_BYTES", maximum=100_000_000))
    budget = MessageBudget(chars, size)
    limits = ParallelLimits(scan_budget=budget, reduction_budget=budget,
        output_budget=MessageBudget(min(chars, 32_768), min(size, 32_768)), selection_budget=budget,
        max_workers=min(workers, capacity),
        max_calls=_integer(getattr(settings, "automap_parallel_max_calls", 32), "AUTOMAP_PARALLEL_MAX_CALLS", maximum=64),
        max_reduction_rounds=_integer(getattr(settings, "automap_parallel_max_reduction_rounds", 16), "AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS", minimum=0, maximum=32),
        candidate_cap=min(15, max(8, len(store.targets))), fan_in=16,
        max_selected_sources=64, max_selected_records=256)
    expected_host = _host(settings.rest_snowflake_host)
    account_host = namespace.lower().replace(".", "-")
    canonical_hosts = {account_host + ".snowflakecomputing.com",
                       account_host.replace("_", "-") + ".snowflakecomputing.com"}
    if expected_host not in canonical_hosts:
        raise RuntimeConfigurationError("REST host must match configured canonical ORG.ACCOUNT; locator aliases are not verified")
    if service._agent._base_url != "https://" + expected_host:
        raise RuntimeConfigurationError("Agent host differs from configured Snowflake account host")
    if (service._agent._auth_mode not in ("oauth_bearer", "snowflake_token")
            or type(service._agent._token) is not str or not service._agent._token.strip()):
        raise RuntimeConfigurationError("Existing agent requires authenticated caller credentials")
    caller, sessions = _resolve_caller(service, namespace, expected_host, deadline=deadline)
    scope = SnapshotScope(caller.native_user, store.snapshot_hash)
    admission_type = RuntimeCallAdmission
    admission_options = {}
    if getattr(settings, 'automap_durable_runs_v2', False):
        from app.core.automap_durable_admission import DurableRunAdmission
        admission_type = DurableRunAdmission
        admission_options['recovery_capacity'] = settings.automap_recovery_capacity
    admission = admission_type(session_factory=sessions, table=permit_table,
        account_namespace=namespace, pool_epoch=epoch, capacity=capacity, **admission_options)
    archive = SnowflakeReductionArchive(session_factory=sessions, table=archive_table,
        caller=caller, scope=scope, deadline=deadline,
        storage_retry_attempts=2 if getattr(settings,'automap_durable_runs_v2',False) else 0)
    # Batch/model request IDs are not a source of authenticated job attribution.
    job_id = uuid4().hex
    if getattr(settings, 'automap_durable_runs_v2', False):
        job_id = hashlib.sha256(json.dumps([caller.access_scope, req.request_id, store.snapshot_hash,
            sorted(store.targets), req.meta.get('auto_mapping_batch_index')],separators=(',',':')).encode()).hexdigest()[:32]
    gate = ScanCallAdmission(admission, job_id=job_id, caller_id=caller.native_user)
    # Only pre-dispatch correlation writes; transport diagnostics stay in memory.
    backend = SnowflakeScanTransport(agent_client=service._agent,
        http_client=_shared_http_client(service._agent._base_url),
        config=ScanTransportConfig(agent=agent, max_response_bytes=120_000), admission=gate)
    return ParallelRuntimeBundle(scope, backend, gate, archive, limits)


def build_fast_model_runtime(service, req, decision, store, deadline, *, finalization_deadline=None):
    """Use trusted same-caller agents without constructing a scan runtime."""
    from app.core.automap_fast_transport import FastSessionModelRuntime
    from app.core.automap_fast_context import FINAL_RESERVE_SECONDS
    if finalization_deadline is not None and (type(finalization_deadline) not in (int, float)
            or not math.isfinite(finalization_deadline)
            or not deadline <= finalization_deadline <= deadline + FINAL_RESERVE_SECONDS):
        raise RuntimeConfigurationError("Finalization must remain inside the reserved batch deadline")
    settings = service._settings
    if not math.isfinite(deadline) or deadline <= time.monotonic():
        raise RuntimeConfigurationError("A live finite Auto-map deadline is required")
    if not isinstance(service._agent, SnowflakeAgentClient):
        raise RuntimeConfigurationError("Existing authenticated SnowflakeAgentClient required")
    metadata = f"{settings.resolved_metadata_database}.{settings.resolved_metadata_schema}"
    if _fqn(service._source_mapping_agent_name, "source agent") != metadata + ".AGT_SOURCE_MAPPING":
        raise RuntimeConfigurationError("Auto-map requires metadata AGT_SOURCE_MAPPING")
    configured = getattr(service, "_transformation_agent_name", None)
    if configured and _fqn(configured, "rule agent") != metadata + ".AGT_TRANSFORMATION_RULE":
        raise RuntimeConfigurationError("Auto-map requires metadata AGT_TRANSFORMATION_RULE")
    if service._agent._auth_mode not in {"oauth_bearer", "snowflake_token"} or not service._agent._token:
        raise RuntimeConfigurationError("Auto-map requires authenticated caller credentials")
    service._model_guard.assert_model_target_allowed(operation=req.operation.value, target="agent", decision=decision)
    if getattr(settings, "automap_parallel_context_v1", False) and (not getattr(settings, "automap_local_sso_enabled", False) or getattr(settings,"automap_durable_runs_v2",False)):
        # Opt-in durable admission reuses the existing provisioned tables; no scan is dispatched.
        from app.core.automap_fast_transport import FastModelRuntime
        from app.core.automap_input_budget import input_limits
        bundle = build_parallel_runtime(service, req=req, decision=decision, store=store, deadline=deadline, fast=True)
        bundle = replace(bundle, limits=replace(bundle.limits, selection_budget=MessageBudget(*input_limits(settings))))
        transport_type = SnowflakeScanTransport
        if getattr(settings, 'automap_durable_runs_v2', False):
            from app.core.automap_background_transport import BackgroundRunTransport
            transport_type = BackgroundRunTransport
        backend = transport_type(agent_client=service._agent,
            http_client=bundle.backend._http_client,
            config=ScanTransportConfig(agent=service._source_mapping_agent_name, max_response_bytes=120_000), admission=bundle.admission)
        specialist = transport_type(agent_client=service._agent,
            http_client=bundle.backend._http_client,
            config=ScanTransportConfig(agent=configured, max_response_bytes=120_000), admission=bundle.admission) if configured else None
        if getattr(settings, 'automap_durable_runs_v2', False):
            backend.run_seconds = settings.automap_run_seconds
            backend.result_archive = bundle.archive
            if specialist is not None:
                specialist.run_seconds = settings.automap_run_seconds
                specialist.result_archive = bundle.archive
            from app.core.automap_run_recovery import recovery_coordinator
            recovery_coordinator.register(bundle, backend, specialist, settings)
        failure_archive = bundle.archive.with_deadline(finalization_deadline) if finalization_deadline is not None else None
        return FastModelRuntime(bundle=replace(bundle, backend=backend), service=service,
            req=req, decision=decision, store=store, deadline=deadline, specialist_backend=specialist,
            failure_archive=failure_archive)
    return FastSessionModelRuntime(service=service, req=req, decision=decision, store=store,
        deadline=min(deadline, time.monotonic() + getattr(settings, "automap_fast_batch_seconds", 60)))
