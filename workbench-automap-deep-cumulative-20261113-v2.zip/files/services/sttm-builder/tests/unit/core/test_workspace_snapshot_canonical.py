"""Deep Agent drafts are saved in exactly the shape the STTM builder UI saves.

Reference values marked "frontend" were produced by running the frontend
module itself (``node --experimental-strip-types``) on the same inputs.
"""
from __future__ import annotations

from types import SimpleNamespace

from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.core.workspace_snapshot import (
    VALIDATION_RECEIPT_TYPE,
    base_query_sql,
    canonical_derived_source,
    canonical_mapping_row,
    canonical_snapshot,
    compile_mapping_item,
    grid_value_bindings,
    lift_join_filters,
    merge_validation_history,
    relation_alias_for,
    relation_graph,
    rewrite_qualifiers,
    sql_hash,
    validation_receipt,
)
from app.agent_runs.contracts import MappingContextPackageV1
from app.schema.common import TableRef
from app.schema.mapping_sql import MappingSqlCompileResponse, MappingSqlPreviewResponse, MappingSqlReviewResponse
from app.schema.workspace_context import WorkbenchContextSnapshotV1

CONTACTS = "DB.SRC.CONTACTS"
ADDRESSES = "DB.SRC.ADDRESSES"


def test_relation_alias_matches_the_frontend_generator() -> None:
    # frontend: relationAliasFor(...) from src/features/sttm/mapping/relation-alias.ts
    assert relation_alias_for("FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.CONTACTS") == "contacts_9g51lg"
    assert relation_alias_for("agent_cte_1", "Emails Per Contact") == "emails_per_contact_n7glhb"
    assert relation_alias_for("DB.S.T") == "t_st0eae"
    assert relation_alias_for("FFP_HDP_DLAB_DB_DEV.SCH_TMD_SOURCE.MAPPER_HH_MASTER") == "mapper_hh_master_hkmd4w"
    assert relation_alias_for("derived_ab12", "contacts udf") == "contacts_udf_54byuv"
    assert relation_alias_for("DB.S.Émile") == "mile_652ywg"
    assert relation_alias_for("") == "source"


def test_agent_rows_are_saved_as_grid_rows() -> None:
    mapped = canonical_mapping_row({
        "id": "migration:1:FULL_NAME", "target_column": "FULL_NAME", "status": "draft",
        "source_columns": [f"{CONTACTS}.FIRST", f"{CONTACTS}.LAST"],
        "expression": "CONTACTS.FIRST || ' ' || CONTACTS.LAST",
        "mapping_classification": "many_to_one", "confidence": 0.9, "evidence_ids": ["e1"],
    }, target_type="VARCHAR(100)")
    assert mapped["status"] == "MAPPED" and mapped["review_status"] == "draft"
    assert mapped["rule"] == "Custom" and mapped["mapping_mode"] == "source"
    assert mapped["target_type"] == "VARCHAR(100)"
    assert mapped["transformation_classification"] == "many_to_one"
    assert mapped["source_dependencies"] == mapped["source_columns"]
    assert mapped["evidence_ids"] == ["e1"]

    direct = canonical_mapping_row({
        "id": "r2", "target_column": "ID", "status": "draft",
        "source_columns": [f"{CONTACTS}.ID"], "expression": "CONTACTS.ID",
    })
    assert direct["rule"] == "Direct" and direct["expression"] is None

    constant = canonical_mapping_row({
        "id": "r3", "target_column": "TYPE", "status": "draft", "source_columns": [], "expression": "'Call'",
        "mapping_classification": "constant",
    })
    assert (constant["mapping_mode"], constant["constant_value"], constant["rule"]) == ("constant", "Call", "Value")
    assert constant["expression"] is None and constant["source_columns"] == []

    typed = canonical_mapping_row({
        "id": "r4", "target_column": "START", "status": "draft", "source_columns": [],
        "expression": "TO_DATE('2020-01-01')",
    })
    assert typed["mapping_mode"] == "source" and typed["rule"] == "Custom"

    attribute = canonical_mapping_row({
        "id": "r5", "target_column": "FIRM", "status": "draft", "source_columns": [], "expression": "$FirmCode",
    })
    assert (attribute["mapping_mode"], attribute["attribute_name"]) == ("attribute", "FirmCode")

    unresolved = canonical_mapping_row({"id": "r6", "target_column": "X", "status": "unresolved", "source_columns": []})
    assert unresolved["status"] == "UNMAPPED" and unresolved["review_status"] == "unresolved"

    held_back = canonical_mapping_row({
        "id": "r7", "target_column": "RECORDTYPEID", "status": "unresolved",
        "mapping_mode": "source", "source_columns": [], "expression": "$HHRecordType",
        "held_back_expression": "$HHRecordType",
    })
    assert held_back["status"] == "UNMAPPED" and held_back["mapping_mode"] == "source"
    assert held_back["attribute_name"] is None and held_back["expression"] is None
    assert held_back["held_back_expression"] == "$HHRecordType"


def test_resolved_project_values_and_qualifier_rewrites_land_in_the_row() -> None:
    row = canonical_mapping_row(
        {"id": "r", "target_column": "LEGACY_ID__C", "status": "draft",
         "source_columns": [f"{ADDRESSES}.ID"], "expression": "$Prefix || ADDRESSES.ID || ' ADDRESSES.ID'"},
        resolved_placeholders={"$Prefix": "'EN-'"},
        qualifier_rewrites={ADDRESSES: "addresses_contact", "SRC.ADDRESSES": "addresses_contact",
                            "ADDRESSES": "addresses_contact"},
    )
    assert row["expression"] == "'EN-' || addresses_contact.ID || ' ADDRESSES.ID'"
    assert row["source_columns"] == ["addresses_contact.ID"]
    assert rewrite_qualifiers(f"{ADDRESSES}.ID + ADDRESSES.ZIP", {ADDRESSES: "a", "ADDRESSES": "a"}) == "a.ID + a.ZIP"


def test_a_derived_source_built_twice_from_different_paths_becomes_one_cte() -> None:
    """cte_designer and lift_join_filters can hash the same table+predicate to the same id.

    Snowflake rejects two WITH entries of the same name ("Relation IDs must
    be unique."); the second build of an identical source must be dropped,
    not turned into a duplicate node.
    """
    cte = canonical_derived_source({
        "id": "agent_cte_dup", "name": "addresses_one_per_contacts",
        "lineage": [{"sql": "SELECT * FROM DB.SRC.ADDRESSES WHERE ADDRESSABLE_TYPE = 'Crm::Contact'"},
                    {"output_columns": [{"name": "CONTACT_ID", "data_type": "NUMBER"}],
                     "base_source_tables": [{"database": "DB", "schema": "SRC", "table": "ADDRESSES"}]}],
    })
    graph = relation_graph(
        source_tables=[TableRef(database="DB", schema="SRC", table="CONTACTS")],
        source_columns_by_table={}, derived_sources=[cte, dict(cte)],
    )
    assert len([node for node in graph["nodes"] if node["relation_id"] == "agent_cte_dup"]) == 1


def test_relation_graph_and_step_one_query_match_the_mapping_page() -> None:
    cte = canonical_derived_source({
        "id": "agent_cte_emails", "name": "emails_per_contact",
        "lineage": [{"sql": "SELECT CONTACT_ID, LISTAGG(ADDRESS, ';') AS ADDRESSES FROM DB.SRC.EMAILS GROUP BY CONTACT_ID"},
                    {"output_columns": [{"name": "CONTACT_ID", "data_type": "NUMBER"},
                                        {"name": "ADDRESSES", "data_type": "TEXT"}],
                     "base_source_tables": [{"database": "DB", "schema": "SRC", "table": "EMAILS"}]}],
    })
    assert cte["sql_text"].startswith("SELECT CONTACT_ID") and cte["alias"] == relation_alias_for("agent_cte_emails", "emails_per_contact")
    assert [column["name"] for column in cte["columns"]] == ["CONTACT_ID", "ADDRESSES"]
    graph = relation_graph(
        source_tables=[TableRef(database="DB", schema="SRC", table="CONTACTS"), ADDRESSES],
        source_columns_by_table={CONTACTS: [{"name": "ID", "data_type": "NUMBER"}]},
        derived_sources=[cte],
        relationships=[{
            "left_table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
            "right_table": {"database": "DB", "schema": "SRC", "table": "ADDRESSES"},
            "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}],
        }],
        derived_edges=[{"left_relation_id": CONTACTS, "right_relation_id": "agent_cte_emails", "join_type": "LEFT",
                        "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}],
    )
    physical = graph["nodes"][0]
    assert physical == {
        "relation_id": CONTACTS, "kind": "PHYSICAL_TABLE", "alias": relation_alias_for(CONTACTS),
        "table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
        "output_columns": [{"name": "ID", "data_type": "NUMBER"}],
    }
    assert graph["nodes"][2]["kind"] == "DERIVED_SOURCE" and graph["nodes"][2]["relation_id"] == "agent_cte_emails"
    assert [(edge["left_relation_id"], edge["right_relation_id"]) for edge in graph["edges"]] == [
        (CONTACTS, ADDRESSES), (CONTACTS, "agent_cte_emails"),
    ]
    contacts, addresses = relation_alias_for(CONTACTS), relation_alias_for(ADDRESSES)
    emails = cte["alias"]
    assert base_query_sql(graph, CONTACTS) == (
        f"WITH\n{emails} AS (\n"
        "  SELECT CONTACT_ID, LISTAGG(ADDRESS, ';') AS ADDRESSES FROM DB.SRC.EMAILS GROUP BY CONTACT_ID\n)\n"
        f"SELECT\n  *\nFROM {CONTACTS} AS {contacts}\n"
        f"LEFT JOIN {ADDRESSES} AS {addresses}\n  ON {contacts}.ID = {addresses}.CONTACT_ID\n"
        f"LEFT JOIN {emails}\n  ON {contacts}.ID = {emails}.CONTACT_ID"
    )


def test_constant_join_filters_become_a_filtered_cte() -> None:
    lifted = lift_join_filters([{
        "left_table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
        "right_table": {"database": "DB", "schema": "SRC", "table": "ADDRESSES"},
        "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "ADDRESSABLE_ID"}],
        "literal_filters": [{"side": "right", "column": "ADDRESSABLE_TYPE", "value": "Crm::Contact"}],
    }], source_columns_by_table={ADDRESSES: [{"name": "ADDRESSABLE_ID"}, {"name": "CITY"}]}, driving_fqn=CONTACTS)
    assert lifted["relationships"] == [] and not lifted["warnings"]
    cte = lifted["derived_sources"][0]
    assert cte["sql_text"] == f"SELECT *\nFROM {ADDRESSES}\nWHERE ADDRESSABLE_TYPE = 'Crm::Contact'"
    assert cte["name"] == "addresses_crm_contact"
    edge = lifted["derived_edges"][0]
    assert (edge["left_relation_id"], edge["right_relation_id"]) == (CONTACTS, cte["id"])
    assert lifted["rewrites"][ADDRESSES] == "addresses_crm_contact"

    shared = lift_join_filters([
        {"left_table": CONTACTS, "right_table": ADDRESSES, "conditions": [{"left_column": "ID", "right_column": "A"}],
         "literal_filters": [{"side": "right", "column": "T", "value": "x"}]},
        {"left_table": ADDRESSES, "right_table": "DB.SRC.ZIPS", "conditions": [{"left_column": "Z", "right_column": "Z"}]},
    ], source_columns_by_table={}, driving_fqn=CONTACTS)
    assert not shared["derived_sources"] and len(shared["relationships"]) == 2 and shared["warnings"]


def test_snapshot_has_every_key_the_builder_writes_and_no_imported_sql() -> None:
    rows = [canonical_mapping_row({"id": "r", "target_column": "ID", "status": "draft",
                                   "source_columns": [f"{CONTACTS}.ID"]})]
    graph = relation_graph(source_tables=[CONTACTS], source_columns_by_table={}, value_bindings=grid_value_bindings(rows))
    receipt = validation_receipt(preview_sql="SELECT 1;", compile_valid=True, review={"execution_ready": True},
                                 preview={"preview_rows": [{"values": {"ID": 1}}]}, validated_by="deep_agent",
                                 validated_at="2026-09-30T00:00:00Z")
    snapshot = canonical_snapshot(
        {"mapping_sql": "SELECT stale", "context_hash": "old", "selected_columns_by_table": {CONTACTS: ["NAME"]}},
        page="mapping", surface="MAPPING", source_tables=[CONTACTS], target_table="DB.TGT.T", driving_table=CONTACTS,
        graph=graph, derived_sources=[], relationships=[], mapping_rows=rows,
        compiled_mapping_sql="INSERT INTO DB.TGT.T (ID)\nSELECT 1;", compiled_mapping_preview_sql="SELECT 1",
        compiled_mapping_script="SET FirmID = '001';\nSELECT $FirmID AS ID;",
        validation_history=merge_validation_history([], receipt),
    )
    for key in ("source_tables", "target_table", "driving_table", "selected_columns_by_table", "derived_sources",
                "relation_graph", "relationships", "filters", "mapping_rows", "checked_mapping_row_ids",
                "compiled_mapping_sql", "compiled_mapping_preview_sql", "compiled_mapping_script",
                "compiled_mapping_context_hash",
                "mapping_artifacts", "validation_history"):
        assert key in snapshot
    assert snapshot["mapping_sql"] is None and snapshot["raw_mapping_sql"] is None
    assert "context_hash" not in snapshot
    assert snapshot["selected_columns_by_table"] == {CONTACTS: ["ID", "NAME"]}
    assert snapshot["filters"]["base_query_sql"] == f"SELECT\n  *\nFROM {CONTACTS} AS {relation_alias_for(CONTACTS)}"
    assert snapshot["compiled_mapping_context_hash"] == sql_hash("SELECT 1;")
    from app.schema.project import STTMAutosaveRequest
    round_trip = STTMAutosaveRequest.model_validate({
        "workspace_snapshot": snapshot,
        "expected_snapshot_id": None,
    }).model_dump(mode="json")
    assert round_trip["workspace_snapshot"]["compiled_mapping_script"] == snapshot["compiled_mapping_script"]
    assert snapshot["checked_mapping_row_ids"] == ["r"]
    assert snapshot["validation_history"][0]["type"] == VALIDATION_RECEIPT_TYPE


def test_grid_attribute_binding_preserves_named_placeholder_and_resolved_value() -> None:
    from app.core.workspace_snapshot import grid_value_bindings

    bindings = grid_value_bindings([{
        "id": "firm-transaction",
        "mapping_mode": "attribute",
        "attribute_name": "TransactionFirmID",
        "constant_value": "001Qi00001Rb8gCIAR",
        "target_type": "VARCHAR",
    }])

    assert bindings == [{
        "binding_id": "firm-transaction",
        "value": "$TransactionFirmID",
        "data_type": "VARCHAR",
        "is_placeholder": True,
        "allow_project_specific_value": False,
        "resolution_status": "project_attribute",
        "attribute_name": "TransactionFirmID",
        "resolved_value": "001Qi00001Rb8gCIAR",
    }]


def test_validation_history_keeps_one_receipt_per_select() -> None:
    first = validation_receipt(preview_sql="SELECT 1", compile_valid=True, review=None, preview=None,
                               validated_by="deep_agent", validated_at="t1")
    again = validation_receipt(preview_sql="SELECT 1;", compile_valid=True, review=None, preview=None,
                               validated_by="user", validated_at="t2")
    other = {"type": "note"}
    history = merge_validation_history(merge_validation_history([other], first), again)
    assert history == [other, again]


def test_agent_compile_request_is_the_request_the_mapping_page_sends() -> None:
    """Relation ids, aliases, Value rows and row payloads match buildCompilerRelationGraph."""
    compiled = []

    class _MappingSql:
        def compile(self, request):
            compiled.append(request)
            return MappingSqlCompileResponse(valid=True, ready=True, preview_sql="SELECT 1 AS ID",
                                             generated_sql="INSERT INTO DB.TGT.T (ID)\nSELECT 1 AS ID;")

        def review(self, request):
            return MappingSqlReviewResponse(valid=True, review_agent="SNOWFLAKE", syntax_valid=True,
                                            execution_ready=True, review_summary="ok",
                                            original_preview_sql=request.preview_sql,
                                            original_generated_sql=request.generated_sql)

        def preview(self, request):
            return MappingSqlPreviewResponse(valid=True, variant_used="original",
                                             executed_preview_sql=request.preview_sql,
                                             executed_generated_sql=request.generated_sql)

    contacts = TableRef(database="DB", schema="SRC", table="CONTACTS")
    context = MappingContextPackageV1(
        run_id="run", thread_id="run", app_user_id="1", effective_role="R",
        workspace=WorkbenchContextSnapshotV1(source_tables=[contacts], driving_table=contacts,
                                             target_table=TableRef(database="DB", schema="TGT", table="T")),
    )
    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object(),  # type: ignore[arg-type]
                                         mapping_sql=_MappingSql())  # type: ignore[arg-type]
    result = handlers._validate_generated_sql(
        state={"run_id": "run", "mapping_context_package": context.model_dump(mode="json")},
        target_table="DB.TGT.T", source_tables=[CONTACTS], source_columns={CONTACTS: ["ID", "NAME"]},
        rows=[
            {"id": "a", "target_column": "ID", "status": "draft", "source_columns": ["ID"], "expression": None},
            {"id": "b", "target_column": "TYPE", "status": "draft", "source_columns": [], "expression": "'Call'"},
        ],
        policy=SimpleNamespace(validation_depth="preview", preview_row_limit=20),
    )
    request = compiled[0]
    assert request.driving_relation_id == CONTACTS
    assert [(node.relation_id, node.alias) for node in request.relation_graph.nodes] == [
        (CONTACTS, relation_alias_for(CONTACTS)),
    ]
    by_target = {item.target_column: item for item in request.mappings}
    assert by_target["ID"].source_columns == [f"{CONTACTS}.ID"] and by_target["ID"].rule == "Direct"
    assert (by_target["TYPE"].mapping_mode, by_target["TYPE"].constant_value) == ("constant", "Call")
    assert by_target["TYPE"].value_binding_ids == ["b"]
    assert [binding.binding_id for binding in request.relation_graph.value_bindings] == ["b"]
    assert request.mappings[0].model_dump() == compile_mapping_item(
        canonical_mapping_row({"id": "a", "target_column": "ID", "status": "draft",
                               "source_columns": [f"{CONTACTS}.ID"]})
    ) | {"target_type": None}
    assert result["compiled_mapping_preview_sql"] == "SELECT 1 AS ID"
    assert result["validation_receipt"]["preview_sql_hash"] == sql_hash("SELECT 1 AS ID")
    assert result["workspace_design"]["driving_id"] == CONTACTS


def test_requested_driving_cte_controls_population_and_join_rewrites():
    from app.schema.workspace_context import WorkspaceDerivedSourceRef
    contacts = TableRef(database='DB', schema='SRC', table='CONTACTS')
    statuses = TableRef(database='DB', schema='SRC', table='STATUSES')
    workspace = WorkbenchContextSnapshotV1(source_tables=[contacts, statuses], driving_table=contacts,
        driving_relation_id='active-customers', derived_sources=[WorkspaceDerivedSourceRef(
            id='active-customers', name='active_customers', sql_text='SELECT * FROM DB.SRC.CONTACTS WHERE ACTIVE = TRUE',
            base_source_tables=[contacts.model_dump()], output_columns=[{'name': 'ID'}, {'name': 'STATUS_ID'}, {'name': 'ACTIVE'}])],
        relationships=[{'left_table': contacts.model_dump(), 'right_table': statuses.model_dump(), 'join_type': 'LEFT',
                        'conditions': [{'left_column': 'STATUS_ID', 'right_column': 'ID', 'operator': '='}]}])
    handlers = WorkbenchWorkflowHandlers(repository=object(), project_service=object(), session=object())
    design = handlers._canonical_design(state={}, source_tables=[CONTACTS, 'DB.SRC.STATUSES'],
                                        source_columns={CONTACTS: ['ID', 'STATUS_ID', 'ACTIVE'], 'DB.SRC.STATUSES': ['ID', 'LABEL']},
                                        workspace=workspace)
    assert design['driving_id'] == 'active-customers'
    assert len(design['graph'].edges) == 1
    assert design['graph'].edges[0].left_relation_id == 'active-customers'
    assert design['graph'].edges[0].right_relation_id == 'DB.SRC.STATUSES'
    assert 'active_customers' in design['rewrites'][CONTACTS]
    sql = base_query_sql(design['graph'].model_dump(mode='json'), design['driving_id'])
    assert 'WHERE ACTIVE = TRUE' in sql
    assert 'LEFT JOIN' in sql and 'STATUS_ID' in sql

    snapshot = canonical_snapshot(workspace.model_dump(mode='json'), page='builder', surface='mapping',
        source_tables=workspace.source_tables, target_table=None, driving_table=contacts,
        graph=design['graph'].model_dump(mode='json'), derived_sources=design['derived_sources'],
        relationships=design['relationships'], mapping_rows=[])
    assert snapshot['driving_relation_id'] == 'active-customers'
    assert 'WHERE ACTIVE = TRUE' in snapshot['filters']['base_query_sql']
    from_sql = snapshot['filters']['base_query_sql'].split('FROM')[-1]
    assert 'active_customers' in from_sql
