"""Which source rows a mapping loads: rules applied before any column is mapped.

Reference migration scripts always narrow their driving rows: soft-deleted
records are excluded, and records are segmented by status and type (active
clients become households, businesses become business accounts). A mapping
that loads every source row reproduces none of that, so these rules are part
of the design, not a column decision:

* soft delete: a driving table with a delete flag loads only live rows;
* precedent population: an exact-target precedent's WHERE clauses are the
  default population, reported as evidence for the plan.
"""
from __future__ import annotations

import re
from typing import Any, Iterable

import sqlglot
from sqlglot import exp

SOFT_DELETE_COLUMNS = ("DELETED", "IS_DELETED", "ISDELETED", "DELETED_FLAG", "IS_ARCHIVED_DELETED")


def _columns(contract: dict[str, Any] | None) -> list[dict[str, Any]]:
    columns = (contract or {}).get("columns") or []
    return [item if isinstance(item, dict) else {"name": str(item)} for item in columns]


def soft_delete_predicate(alias: str, contract: dict[str, Any] | None) -> str | None:
    """``alias.DELETED = 0``-style predicate for a table with a delete flag, else None."""
    by_name = {str(item.get("name") or item.get("column_name") or "").upper(): item for item in _columns(contract)}
    column = next((name for name in SOFT_DELETE_COLUMNS if name in by_name), None)
    if column is None:
        return None
    data_type = str(by_name[column].get("type") or by_name[column].get("data_type") or "").upper()
    reference = f"{alias}.{column}"
    if "BOOL" in data_type:
        return f"COALESCE({reference}, FALSE) = FALSE"
    if any(marker in data_type for marker in ("CHAR", "TEXT", "STRING")):
        return f"COALESCE(UPPER({reference}), 'N') NOT IN ('1', 'Y', 'YES', 'T', 'TRUE')"
    return f"COALESCE({reference}, 0) = 0"


def _normalized(sql: str) -> str:
    return re.sub(r"\s+", "", str(sql or "")).upper()


def mentions_column(filter_sql: str | None, column: str) -> bool:
    return bool(filter_sql) and re.search(rf"(?<![A-Z0-9_]){re.escape(column.upper())}(?![A-Z0-9_])",
                                          str(filter_sql).upper()) is not None


def merge_predicates(existing: str | None, predicates: Iterable[str]) -> str | None:
    """``existing AND p1 AND p2`` without repeating a predicate already there."""
    parts = [str(existing).strip()] if existing and str(existing).strip() else []
    seen = {_normalized(item) for item in parts}
    for predicate in predicates:
        if predicate and _normalized(predicate) not in seen and _normalized(predicate) not in _normalized(existing or ""):
            parts.append(predicate)
            seen.add(_normalized(predicate))
    if not parts:
        return None
    if len(parts) == 1:
        return parts[0]
    return " AND ".join(f"({part})" if " OR " in part.upper() else part for part in parts)


def precedent_population(sql: str) -> list[dict[str, str]]:
    """WHERE and QUALIFY clauses of a precedent query, outermost first, with the CTE each belongs to."""
    try:
        tree = sqlglot.parse_one(sql, read="snowflake")
    except Exception:  # noqa: BLE001 - unparseable history is simply no evidence
        return []
    rules: list[dict[str, str]] = []
    for select in tree.find_all(exp.Select):
        cte = select.find_ancestor(exp.CTE)
        owner = cte.alias_or_name if cte is not None else "final query"
        for key, kind in (("where", "where"), ("qualify", "qualify")):
            clause = select.args.get(key)
            if clause is not None:
                rules.append({"scope": owner, "kind": kind, "sql": clause.this.sql(dialect="snowflake")})
    return rules
