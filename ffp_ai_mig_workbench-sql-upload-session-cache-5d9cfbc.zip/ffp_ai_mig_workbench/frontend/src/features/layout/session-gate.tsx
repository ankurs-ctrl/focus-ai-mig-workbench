"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AiaBox, AiaCircularProgress } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import { AppError } from "@/api/errors/app-error";
import { authService, clearBrowserWorkbenchSession } from "@/services/authService";

type SessionStatus = "checking" | "ready" | "signed-out" | "denied" | "unavailable";

// Session answers that mean "not signed in to the workbench yet".
const NOT_SIGNED_IN_STATUSES = new Set([401]);

function isNotSignedIn(error: unknown) {
  return error instanceof AppError && NOT_SIGNED_IN_STATUSES.has(error.payload.statusCode ?? 0);
}

/**
 * Blocks signed-in screens until `/api/v1/auth/session` answers.
 * - While it loads: a spinner (screens would otherwise render with empty data).
 * - 401 clears the rejected cookie before returning to the public sign-in page.
 * - Permission denial and temporary failures remain distinct, without redirecting.
 */
export default function SessionGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>("checking");

  useEffect(() => {
    let cancelled = false;
    authService
      .getSession()
      .then(() => {
        if (!cancelled) setStatus("ready");
      })
      .catch(async (error) => {
        if (cancelled) return;
        if (isNotSignedIn(error)) {
          setStatus("signed-out");
          clearBrowserWorkbenchSession();
          try {
            await fetch(`/api/v1/auth/clear-session`, {method: "POST", signal: AbortSignal.timeout(8000)});
          } catch {
            // Sign in remains reachable even if cookie clearing is unavailable.
          }
          if (!cancelled) window.location.replace("/home");
          return;
        }
        setStatus(error instanceof AppError && error.payload.statusCode === 403 ? "denied" : "unavailable");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (status === "ready") {
    return <>{children}</>;
  }

  // Checking, or on the way to /home: keep the screen behind a spinner.
  return (
    <AiaBox
      role="status"
      aria-live="polite"
      sx={{
        flex: 1,
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 1.5,
        backgroundColor: "var(--color-app-bg)",
      }}
    >
      <AiaCircularProgress size={32} />
      <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>
        {status === "denied" ? "Your account does not have permission to access this workspace. Contact your administrator."
          : status === "unavailable" ? "Session verification is unavailable. Please reload to retry."
          : status === "signed-out" ? "Redirecting to sign in…" : "Checking your session…"}
      </AiaText>
    </AiaBox>
  );
}
