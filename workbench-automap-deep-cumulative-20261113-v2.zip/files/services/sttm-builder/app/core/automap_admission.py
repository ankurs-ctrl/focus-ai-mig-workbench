"""Distributed Auto-map admission over deployment-preallocated Snowflake slots.

Safety contract
---------------
All replicas MUST use the same table, canonical ORG.ACCOUNT namespace, pool epoch
and capacity. Runtime code never inserts, deletes, or creates slots. Provisioning
must be exclusive, and the runtime role must not be able to insert/delete/reset
this table. Standard-table primary keys are NOT used as enforced constraints.

Claims read the small fixed inventory, then UPDATE a FREE slot conditional on its
observed fence and epoch. Exactly one updated row and an acknowledged COMMIT are
required before dispatch. A stale read can lose a claim, never authorize a call.
Each update is in an explicit transaction so unexpected affected counts roll back.
No count-then-insert, process semaphore, or SELECT FOR UPDATE is involved.

HELD and QUARANTINED slots both consume capacity, including after lease expiry.
Expiry only stops renewal; it NEVER frees a slot or authorizes takeover. A crash,
lost COMMIT acknowledgement, timeout, or uncertain remote failure can leak capacity
until explicit terminal reconciliation. Fences protect the store, NOT the remote
provider: reconciliation must prove the old call terminal AND prevent a paused
old dispatcher from subsequently sending it. Absence in query history is not proof.

The session factory must yield an EXCLUSIVE, transaction-free Snowpark session per
operation (including heartbeat operations), discard it after errors, never suppress
exceptions, and bound connection/network waits. It owns credentials; this module
stores none. SQL execution/lock timeouts are bounded too, but Python cannot interrupt
blocked session creation or networking exactly at the scan deadline.

Use BOTH ScanCallAdmission and its wrap_backend() with scan_registry. The scan
catches backend exceptions inside admission, so a normal context exit is NOT proof
of terminal completion. A wrapped backend must perform at most ONE synchronous
remote call, no hidden retries, and return only after remote completion. Only a
transport that has confirmed a terminal remote error may raise RemoteCallCompleted.
Other exceptions, including cancellation, are uncertain and quarantined.

Only the global concurrent-call cap is implemented. Job/caller IDs are attribution,
not quotas or fairness. No FIFO scheduling, per-job/caller cap, or live wiring.
See https://docs.snowflake.com/en/sql-reference/transactions (resource locking,
READ COMMITTED, explicit transactions, multi-threading). Live concurrency and SQL
compilation still require verification in an approved isolated DEV environment.
"""
from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager, contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
import hashlib
import json
from enum import Enum
import math
import random
import re
from threading import Event, Lock, Thread
import time
from typing import Any, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from app.core.automap_scan_transport import ScanTransportDiagnostic
from uuid import UUID, uuid4


_CONTROL_TRACE = ContextVar("automap_control_trace", default=None)
_CONTROL_DEADLINE = ContextVar("automap_control_deadline", default=None)
_CONTROL_QUEUE_WINDOW = ContextVar("automap_control_queue_window", default=None)


def _control_failure(error, source, outcome):
    from app.core.sql_failure import sql_failure_details
    error.sql_failure = sql_failure_details(source)
    error.control_outcome = outcome
    return error


def retry_control_operation(request, operation, callback, *, renewal=False):
    """Retry only a positively rolled-back operation, never a remote call."""
    deadline = time.monotonic() + 10
    if not renewal:
        deadline = min(deadline, request.effective_deadline)
    window = {"deadline": deadline, "queue_deadline": getattr(request, "effective_deadline", deadline), "started": False}
    window_token = _CONTROL_QUEUE_WINDOW.set(window)
    trace_token = _CONTROL_TRACE.set(getattr(request, "runtime_trace", None))
    token = _CONTROL_DEADLINE.set(deadline)
    last_contention = None
    try:
        for attempt in range(3):
            if not renewal:
                request.check_active()
            deadline = window["deadline"]
            if time.monotonic() >= deadline:
                if last_contention is not None:raise last_contention
                raise AdmissionUnavailable('Control operation retry window exhausted')
            try:
                return callback()
            except AdmissionContended as error:
                last_contention = error
                error.control_operation = operation
                trace = getattr(request, 'runtime_trace', None)
                if trace is not None:
                    trace.control_retries[operation] = min(attempt + 1, 2)
                if attempt == 2:
                    raise
                delay = (.15, .45)[attempt] * random.uniform(.8, 1.2)
                deadline = window["deadline"]
                remaining = deadline - time.monotonic()
                if remaining <= delay:
                    raise
                time.sleep(delay)
    finally:
        _CONTROL_DEADLINE.reset(token)
        _CONTROL_QUEUE_WINDOW.reset(window_token)
        _CONTROL_TRACE.reset(trace_token)


class AdmissionError(RuntimeError):
    """No remote call is authorized by a failed admission operation."""


class AdmissionUnavailable(AdmissionError):
    """Store outcome may be uncertain; never fall back to local admission."""


class AdmissionCapacityBlocked(AdmissionUnavailable):
    """Every permit is quarantined; waiting cannot create execution capacity."""


class AdmissionClaimUncertain(AdmissionUnavailable):
    """A write or commit may have succeeded; claiming again could leak capacity."""


class AdmissionContended(AdmissionUnavailable):
    """A rolled-back Snowflake lock/statement timeout; bounded retry is safe."""


def _is_contention(exc: Exception) -> bool:
    # Snowpark's errno is its wrapper code (e.g. 1304); the native Snowflake
    # lock/statement timeout is sql_error_code. Connector errors use errno.
    return any(type(code) in (int,str) and str(code).lstrip('0') in {'627','630'}
               for code in (getattr(exc,'sql_error_code',None),getattr(exc,'errno',None)))


class AdmissionInvariantError(AdmissionError):
    """Invalid inventory or unrecognized affected-row result."""


class StalePermit(AdmissionError):
    """The owner/fence no longer matches, or renewal is too late."""


class UnreportedCompletion(AdmissionError):
    """No paired backend reported a terminal outcome."""


class RemoteCallCompleted(RuntimeError):
    """Transport attests a terminal remote failure (NOT a timeout/disconnect)."""


class RemoteCallNotDispatched(RemoteCallCompleted):
    """No model POST was attempted; safe to release without remote cancellation."""


class Completion(str, Enum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    NOT_DISPATCHED = "NOT_DISPATCHED"


class AdmissionCleanupFailureCode(str, Enum):
    """Safe secondary diagnostics on error.admission_cleanup_failure_code."""

    UNAVAILABLE = "admission_unavailable"
    CLAIM_UNCERTAIN = "admission_claim_uncertain"
    CONTENDED = "admission_contended"
    INVARIANT = "admission_invariant"
    CLEANUP_FAILED = "admission_cleanup_failed"


def _cleanup_failure_code(error: BaseException) -> AdmissionCleanupFailureCode:
    if isinstance(error, AdmissionClaimUncertain):
        return AdmissionCleanupFailureCode.CLAIM_UNCERTAIN
    if isinstance(error, AdmissionContended):
        return AdmissionCleanupFailureCode.CONTENDED
    if isinstance(error, AdmissionUnavailable):
        return AdmissionCleanupFailureCode.UNAVAILABLE
    if isinstance(error, AdmissionInvariantError):
        return AdmissionCleanupFailureCode.INVARIANT
    return AdmissionCleanupFailureCode.CLEANUP_FAILED


@dataclass(frozen=True)
class AdmissionCapabilities:
    global_call_cap: bool = True
    per_job_limit: bool = False
    per_caller_limit: bool = False
    fairness: bool = False
    automatic_expiry_reclaim: bool = False


CAPABILITIES = AdmissionCapabilities()


def _identity(value: str, name: str) -> str:
    if type(value) is not str or not value.strip() or len(value) > 256:
        raise ValueError(f"Invalid {name}")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError(f"Invalid {name}")
    value.encode("utf-8")
    return value


def _positive_int(value: int, name: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"Invalid {name}")
    return value


@dataclass(frozen=True)
class CallIdentity:
    job_id: str
    caller_id: str
    generation: str
    shard_id: str

    def __post_init__(self) -> None:
        for name in ("job_id", "caller_id", "generation", "shard_id"):
            _identity(getattr(self, name), name)


@dataclass(frozen=True)
class Permit:
    account_namespace: str
    pool_epoch: str
    slot_id: int
    owner: str
    fence: int
    identity: CallIdentity


@dataclass(frozen=True)
class ThreadReference:
    """Nonsecret, versioned correlation fitting the existing VARCHAR(256)."""

    thread_id: int
    agent_fqn: str
    request_digest: str
    version: int = 1

    def __post_init__(self) -> None:
        if (type(self.version) is not int or self.version != 1
                or type(self.thread_id) is not int or not 0 < self.thread_id < 2**63
                or type(self.agent_fqn) is not str or not re.fullmatch(
                    r"[A-Z_][A-Z0-9_$]*(\.[A-Z_][A-Z0-9_$]*){2}", self.agent_fqn)
                or type(self.request_digest) is not str
                or not re.fullmatch(r"[0-9a-f]{64}", self.request_digest)):
            raise ValueError("Invalid thread reconciliation reference")
        if len(self.serialize().encode("ascii")) > 256:
            raise ValueError("Thread reconciliation reference exceeds existing column capacity")

    def serialize(self) -> str:
        return json.dumps(dict(version=self.version, thread_id=self.thread_id,
            agent_fqn=self.agent_fqn, request_digest=self.request_digest), separators=(",", ":"))

    @classmethod
    def parse(cls, value: str) -> ThreadReference:
        try:
            if type(value) is not str or len(value.encode("utf-8")) > 256:
                raise ValueError
            data = json.loads(value)
            if type(data) is not dict or set(data) != {"version", "thread_id", "agent_fqn", "request_digest"}:
                raise ValueError
            reference = cls(**data)
            if reference.serialize() != value:
                raise ValueError
            return reference
        except (ValueError, TypeError, UnicodeError, RecursionError):
            raise AdmissionInvariantError("Invalid persisted thread reference") from None


def request_digest(request: AdmissionRequest) -> str:
    """Bind exact checked message bytes AND snapshot/generation/shard scope."""
    return hashlib.sha256(json.dumps([
        request.scope.owner_id, request.scope.snapshot_id, request.generation,
        request.shard_id, request.message,
    ], ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()


class SqlSession(Protocol):
    def sql(self, query: str, params: list[Any] | None = None) -> Any: ...


SessionFactory = Callable[[], AbstractContextManager[SqlSession]]


def _row(value: Any) -> dict[str, Any]:
    return value.as_dict() if hasattr(value, "as_dict") else dict(value)


def _affected(rows: list[Any]) -> int:
    if len(rows) != 1:
        raise AdmissionInvariantError("Missing UPDATE result")
    result = {key.lower(): value for key, value in _row(rows[0]).items()}
    count = result.get("number of rows updated")
    if type(count) is not int or count < 0:
        raise AdmissionInvariantError("Invalid UPDATE affected-row count")
    return count


class SnowflakeCallAdmission:
    """Fixed global pool. Construction performs no I/O; no implicit configuration."""

    capabilities = CAPABILITIES

    def __init__(self, *, session_factory: SessionFactory, table: str,
                 account_namespace: str, pool_epoch: str, capacity: int,
                 lease_seconds: int = 120, statement_timeout_seconds: int = 5,
                 fail_on_quarantined_pool: bool = False) -> None:
        if not callable(session_factory):
            raise TypeError("An exclusive session factory is required")
        # Deliberately reject quoted/partial identifiers, URLs and account aliases.
        if type(table) is not str or not re.fullmatch(
                r"[A-Za-z_][A-Za-z0-9_$]*(\.[A-Za-z_][A-Za-z0-9_$]*){2}", table):
            raise ValueError("table requires an unquoted DATABASE.SCHEMA.TABLE")
        if type(account_namespace) is not str or not re.fullmatch(
                r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", account_namespace):
            raise ValueError("account_namespace requires canonical ORG.ACCOUNT")
        if type(pool_epoch) is not str or str(UUID(pool_epoch)) != pool_epoch:
            raise ValueError("pool_epoch requires a canonical deployment UUID")
        self._factory = session_factory
        self._table = table.upper()
        self.account_namespace = account_namespace.upper()
        self.pool_epoch = pool_epoch
        self.capacity = _positive_int(capacity, "capacity")
        self.inventory_capacity = self.capacity
        self._claim_extra = ""
        if type(fail_on_quarantined_pool) is not bool:
            raise ValueError("fail_on_quarantined_pool must be boolean")
        self._fail_on_quarantined_pool = fail_on_quarantined_pool
        self.lease_seconds = _positive_int(lease_seconds, "lease_seconds")
        self._timeout = _positive_int(statement_timeout_seconds, "statement_timeout_seconds")

    def _sql(self, session: SqlSession, query: str, params: list[Any] | None = None) -> list[Any]:
        deadline = _CONTROL_DEADLINE.get()
        remaining = self._timeout if deadline is None else min(self._timeout, deadline - time.monotonic())
        if remaining <= 0:
            raise AdmissionUnavailable('Control operation deadline exhausted')
        return session.sql(query, params=params).collect(statement_params={
            "STATEMENT_TIMEOUT_IN_SECONDS": str(max(1, math.ceil(remaining))), "LOCK_TIMEOUT": "1"})

    @contextmanager
    def _transaction(self) -> Iterator[SqlSession]:
        committed = False
        try:
            deadline = _CONTROL_DEADLINE.get()
            session_started = time.monotonic()
            bounded = getattr(self._factory, 'with_deadline', None)
            window = _CONTROL_QUEUE_WINDOW.get()
            acquire_deadline = window["queue_deadline"] if window is not None and not window["started"] else deadline
            with (bounded(acquire_deadline) if acquire_deadline is not None and bounded is not None else self._factory()) as session:
                # Initial session queueing uses the existing request deadline.
                # The shared ten-second database retry window starts only after
                # acquiring a checked exclusive session. Later attempts retain
                # that same deadline and always acquire a fresh lease.
                if window is not None and not window["started"]:
                    window["started"] = True
                    window["deadline"] = min(time.monotonic() + 10, window["queue_deadline"])
                    _CONTROL_DEADLINE.set(window["deadline"])
                trace = _CONTROL_TRACE.get()
                if trace is not None:trace.control_session_wait_seconds += time.monotonic()-session_started
                context = self._sql(session,
                    "SELECT CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() AS ACCOUNT_NAMESPACE, "
                    "CURRENT_TRANSACTION() AS TRANSACTION_ID")
                if len(context) != 1:
                    raise AdmissionInvariantError("Missing session context")
                context_row = _row(context[0])
                if context_row.get("ACCOUNT_NAMESPACE") != self.account_namespace:
                    raise AdmissionInvariantError("Session account namespace mismatch")
                if context_row.get("TRANSACTION_ID") is not None:
                    raise AdmissionInvariantError("Session already has an active transaction")
                try:
                    self._sql(session, "BEGIN TRANSACTION")
                    yield session
                    try:
                        self._sql(session, "COMMIT")
                    except Exception as error:
                        # The COMMIT result is uncertain. Never claim another slot.
                        raise _control_failure(AdmissionClaimUncertain("Claim COMMIT outcome uncertain"), error, "commit_uncertain") from None
                    committed = True
                except BaseException as exc:
                    # A failed rollback after a write leaves claim ownership uncertain.
                    try:
                        self._sql(session, "ROLLBACK")
                    except Exception as rollback_error:
                        failure = _control_failure(AdmissionClaimUncertain("Claim rollback outcome uncertain"), exc, "rollback_uncertain")
                        raise failure from None
                    if isinstance(exc, Exception) and not isinstance(exc, AdmissionError) and _is_contention(exc):
                        # Classify before crossing the session wrapper, and only
                        # after an acknowledged rollback of this transaction.
                        raise _control_failure(AdmissionContended("Admission claim contended"), exc, "rolled_back") from None
                    raise
            if not committed:
                raise AdmissionUnavailable("Session factory suppressed a transaction failure")
        except AdmissionError:
            raise
        except Exception as error:
            raise _control_failure(AdmissionUnavailable("Admission store unavailable; reconciliation may be required"), error, "unavailable") from None

    def health(self) -> dict[str, int | float | None]:
        """Read-only administrator health; no owners, prompts or recovery side effects.

        Hosting APIs must authorize global-pool inspection separately from caller jobs.
        Validate full inventory before aggregation; Snowflake PKs are informational.
        """
        try:
            with self._factory() as session:
                context = self._sql(session,
                    "SELECT CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() AS ACCOUNT_NAMESPACE, "
                    "CURRENT_TRANSACTION() AS TRANSACTION_ID")
                if (len(context) != 1 or _row(context[0]).get("ACCOUNT_NAMESPACE") != self.account_namespace
                        or _row(context[0]).get("TRANSACTION_ID") is not None):
                    raise AdmissionInvariantError("Health session identity mismatch")
                rows = self._sql(session,
                    f"SELECT SLOT_ID, POOL_EPOCH, STATE, FENCE, OWNER_TOKEN IS NULL AS OWNER_MISSING, "
                    "COALESCE(LEASE_EXPIRES_AT <= CURRENT_TIMESTAMP(), FALSE) AS EXPIRED, "
                    "GREATEST(0, DATEDIFF('second', UPDATED_AT, CURRENT_TIMESTAMP())) AS AGE_SECONDS "
                    f"FROM {self._table} WHERE ACCOUNT_NAMESPACE = ? ORDER BY SLOT_ID LIMIT {self.inventory_capacity + 1}",
                    [self.account_namespace])
                items = [_row(row) for row in rows]
                if (len(items) != self.inventory_capacity or [v.get("SLOT_ID") for v in items] != list(range(1, self.inventory_capacity + 1))
                        or any(v.get("POOL_EPOCH") != self.pool_epoch
                               or v.get("STATE") not in {"FREE", "HELD", "QUARANTINED"}
                               or type(v.get("FENCE")) is not int or v["FENCE"] < 0
                               or type(v.get("OWNER_MISSING")) is not bool
                               or (v["STATE"] == "FREE") != v["OWNER_MISSING"]
                               or type(v.get("EXPIRED")) is not bool
                               or type(v.get("AGE_SECONDS")) not in (int, float)
                               or not math.isfinite(v["AGE_SECONDS"]) or v["AGE_SECONDS"] < 0 for v in items)):
                    raise AdmissionInvariantError("Invalid health inventory")
                ages = [v["AGE_SECONDS"] for v in items if v["STATE"] == "QUARANTINED"]
                summary = {"capacity": self.capacity, **{state.lower(): sum(v["STATE"] == state for v in items)
                         for state in ("FREE", "HELD", "QUARANTINED")},
                        "expired_held": sum(v["STATE"] == "HELD" and v["EXPIRED"] for v in items),
                        "oldest_quarantine_seconds": max(ages) if ages else None}
                return self._health_details(summary,items)
        except AdmissionError:
            raise
        except Exception:
            raise AdmissionUnavailable("Admission health unavailable") from None

    def _health_details(self,summary,items):
        return summary

    def _claimable_slot(self, slot_id: int) -> bool:
        return True

    def try_claim(self, identity: CallIdentity) -> Permit | None:
        if not isinstance(identity, CallIdentity):
            raise TypeError("A trusted CallIdentity is required")
        permit = None
        with self._transaction() as session:
            rows = self._sql(session,
                f"SELECT SLOT_ID, POOL_EPOCH, STATE, OWNER_TOKEN, FENCE FROM {self._table} "
                f"WHERE ACCOUNT_NAMESPACE = ? ORDER BY SLOT_ID LIMIT {self.inventory_capacity + 1}",
                [self.account_namespace])
            inventory = [_row(row) for row in rows]
            # Validate the entire namespace, not just FREE rows: PKs are unenforced.
            if (len(inventory) != self.inventory_capacity
                    or [row.get("SLOT_ID") for row in inventory] != list(range(1, self.inventory_capacity + 1))):
                raise AdmissionInvariantError("Pool inventory does not match deployment capacity")
            for row in inventory:
                if (row.get("POOL_EPOCH") != self.pool_epoch
                        or row.get("STATE") not in {"FREE", "HELD", "QUARANTINED"}
                        or type(row.get("FENCE")) is not int or row["FENCE"] < 0
                        or (row["STATE"] == "FREE") != (row.get("OWNER_TOKEN") is None)):
                    raise AdmissionInvariantError("Pool inventory is corrupt or epoch changed")
            if self._fail_on_quarantined_pool and all(row["STATE"] == "QUARANTINED" for row in inventory):
                raise AdmissionCapacityBlocked(
                    "Auto-map execution capacity requires administrator recovery; all permits are quarantined")
            free = next((row for row in inventory if row["STATE"] == "FREE" and self._claimable_slot(row["SLOT_ID"])), None)
            if free is not None:
                owner = uuid4().hex
                count = _affected(self._sql(session,
                    f"UPDATE {self._table} SET STATE = 'HELD', OWNER_TOKEN = ?, FENCE = FENCE + 1, "
                    "JOB_ID = ?, CALLER_ID = ?, GENERATION = ?, SHARD_ID = ?, "
                    "LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP()), "
                    f"UPDATED_AT = CURRENT_TIMESTAMP(), COMPLETION = NULL, RECONCILIATION_REF = NULL {self._claim_extra} "
                    "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                    "AND STATE = 'FREE' AND OWNER_TOKEN IS NULL AND FENCE = ?",
                    [owner, identity.job_id, identity.caller_id, identity.generation, identity.shard_id,
                     self.lease_seconds, self.account_namespace, self.pool_epoch, free["SLOT_ID"], free["FENCE"]]))
                if count > 1:
                    raise AdmissionInvariantError("Claim updated multiple slots")
                if count == 1:
                    permit = Permit(self.account_namespace, self.pool_epoch, free["SLOT_ID"],
                                    owner, free["FENCE"] + 1, identity)
        return permit

    def _permit_params(self, permit: Permit) -> list[Any]:
        if (not isinstance(permit, Permit) or permit.account_namespace != self.account_namespace
                or permit.pool_epoch != self.pool_epoch or not 1 <= permit.slot_id <= self.inventory_capacity):
            raise StalePermit("Permit belongs to a different pool")
        return [permit.account_namespace, permit.pool_epoch, permit.slot_id, permit.owner, permit.fence,
                permit.identity.job_id, permit.identity.caller_id, permit.identity.generation,
                permit.identity.shard_id]

    def _change(self, permit: Permit, assignment: str, values: list[Any], condition: str) -> None:
        params = self._permit_params(permit)
        with self._transaction() as session:
            count = _affected(self._sql(session,
                f"UPDATE {self._table} SET {assignment}, UPDATED_AT = CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                f"AND GENERATION = ? AND SHARD_ID = ? AND {condition}", values + params))
            if count == 0:
                raise StalePermit("Permit no longer matches or lease expired")
            if count != 1:
                raise AdmissionInvariantError("Permit update affected multiple slots")

    def renew(self, permit: Permit) -> None:
        """Same logical owner, NEW exclusive session. Never revive expired/quarantined work."""
        self._change(permit, "LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP())",
                     [self.lease_seconds], "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()")

    def record_reconciliation(self, permit: Permit, reference: ThreadReference) -> None:
        """Write once while HELD; returning requires one row and acknowledged COMMIT."""
        if type(reference) is not ThreadReference:
            raise TypeError("A trusted ThreadReference is required")
        self._change(permit, "RECONCILIATION_REF = ?", [reference.serialize()],
            "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP() AND RECONCILIATION_REF IS NULL")

    def read_reconciliation(self, permit: Permit) -> ThreadReference:
        """Read-only scoped lookup. Never upgrades untracked old permits."""
        params = self._permit_params(permit)
        try:
            with self._factory() as session:
                rows = self._sql(session,
                    f"SELECT RECONCILIATION_REF FROM {self._table} "
                    "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                    "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                    "AND GENERATION = ? AND SHARD_ID = ? AND STATE IN ('HELD', 'QUARANTINED') "
                    "AND ACCOUNT_NAMESPACE = CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() LIMIT 2",
                    params)
                if len(rows) != 1:
                    raise StalePermit("Recovery permit scope does not match exactly one occupied slot")
                return ThreadReference.parse(_row(rows[0]).get("RECONCILIATION_REF"))
        except AdmissionError:
            raise
        except Exception:
            raise AdmissionUnavailable("Scoped thread reference unavailable") from None

    def quarantine(self, permit: Permit) -> None:
        """Retain owner and fence indefinitely, even if the liveness lease expired."""
        self._change(permit, "STATE = 'QUARANTINED'", [], "STATE IN ('HELD', 'QUARANTINED')")

    def complete(self, permit: Permit, completion: Completion, *, reconciliation_ref: str | None = None) -> None:
        """Release ONLY on explicit terminal evidence; allowed after expiry.

        For orphan/uncertain calls, use reconcile_terminal instead. An expired
        lease alone, elapsed wall time, or caller cancellation is never evidence.
        """
        if not isinstance(completion, Completion):
            raise ValueError("Explicit terminal Completion is required")
        if reconciliation_ref is not None:
            _identity(reconciliation_ref, "reconciliation_ref")
        self._change(permit,
            "STATE = 'FREE', OWNER_TOKEN = NULL, FENCE = FENCE + 1, LEASE_EXPIRES_AT = NULL, "
            "COMPLETION = ?, RECONCILIATION_REF = ?",
            [completion.value, reconciliation_ref], "STATE IN ('HELD', 'QUARANTINED')")

    def reconcile_terminal(self, permit: Permit, completion: Completion, *, evidence_ref: str,
                           retired_dispatcher: bool) -> None:
        """Trusted reconciler attests terminal remote work + retired old dispatcher.

        evidence_ref is a non-secret audit reference, NOT credentials or payload.
        This method does not contact the provider or verify evidence automatically.
        """
        if retired_dispatcher is not True:
            raise AdmissionError("Terminal reconciliation requires an explicitly retired dispatcher")
        _identity(evidence_ref, "evidence_ref")
        self.complete(permit, completion, reconciliation_ref=evidence_ref)


class RequestScope(Protocol):
    @property
    def owner_id(self) -> str: ...
    @property
    def snapshot_id(self) -> str: ...


class AdmissionRequest(Protocol):
    """Structural ScanRequest subset, avoiding a circular scan import."""
    @property
    def scope(self) -> RequestScope: ...
    @property
    def generation(self) -> str: ...
    @property
    def shard_id(self) -> str: ...
    @property
    def message(self) -> str: ...
    def check_active(self) -> None: ...
    def remaining_seconds(self) -> float: ...


@dataclass
class _CallState:
    request: AdmissionRequest
    permit: Permit
    renewal_failed: Event
    invoked: bool = False
    completion: Completion | None = None
    terminal_commit_acknowledged: bool = False
    lifecycle_bound: bool = False
    reference: ThreadReference | None = None
    diagnostics: list[ScanTransportDiagnostic] = field(default_factory=list)
    active: bool = True
    lock: Any = field(default_factory=Lock, repr=False)


@dataclass(frozen=True)
class ScanCallLifecycle:
    """Exact-request capability; no thread-local lookup in the transport.

    The paired gate validates the capability on every operation. A copied context,
    reused request, or different admission cannot dispatch a second model call.
    """

    _gate: ScanCallAdmission = field(repr=False)
    _state: _CallState = field(repr=False)

    def commit_terminal_result(self, archive, reference, body):
        """Persist exact result and fenced release together; never set before ACK."""
        state, gate = self._state, self._gate
        if (gate._current.get() is not state or not state.active or not state.invoked
                or state.completion is not None or state.reference is None
                or archive._scope != state.request.scope
                or archive._caller.native_user != state.permit.identity.caller_id):
            raise AdmissionError('Terminal commit requires its original paired lifecycle')
        with archive.checkpoint() as checkpoint:
            checkpoint.put(reference, body)
            if checkpoint.get(reference) != body:
                raise AdmissionError('Terminal result readback differs from exact content')
            gate.store.complete_on_session(checkpoint.session, state.permit, Completion.SUCCEEDED)
        state.terminal_commit_acknowledged = True

    def record_reconciliation(self, reference: ThreadReference) -> None:
        if type(reference) is not ThreadReference:
            raise TypeError("A trusted ThreadReference is required")
        self._gate._validate_lifecycle(self._state)
        if self._state.reference is not None:
            raise AdmissionError("Thread reference was already recorded")
        if reference.request_digest != request_digest(self._state.request):
            raise AdmissionError("Thread reference request digest mismatch")
        self._state.request.check_active()
        self._gate.store.record_reconciliation(self._state.permit, reference)
        self._state.reference = reference
        self._state.request.check_active()
        self._gate._validate_lifecycle(self._state)

    def record_preparation(self, reference, archive_ref, seconds):
        self._gate._validate_lifecycle(self._state)
        if self._state.reference is not None:
            raise AdmissionError('Thread reference was already recorded')
        if type(reference) is not ThreadReference or reference.request_digest != request_digest(self._state.request):
            raise AdmissionError('Thread reference request digest mismatch')
        retry_control_operation(self._state.request, 'dispatch_preparation', lambda:
            self._gate.store.record_preparation(self._state.permit, reference, archive_ref, seconds))
        self._state.reference = reference
        self._state.request.check_active()
        self._gate._validate_lifecycle(self._state)

    def check_dispatch(self) -> None:
        self._gate._validate_lifecycle(self._state)
        if self._state.reference is None:
            raise AdmissionError("Model dispatch requires acknowledged thread persistence")
        self._state.request.check_active()

    def record_diagnostic(self, diagnostic: ScanTransportDiagnostic) -> None:
        # Only bounded in-memory append: never call a sink or store here.
        from app.core.automap_scan_transport import ScanTransportDiagnostic
        if (type(diagnostic) is ScanTransportDiagnostic and len(self._state.diagnostics) < 6
                and diagnostic.scope == self._state.request.scope
                and diagnostic.generation == self._state.request.generation
                and diagnostic.shard_id == self._state.request.shard_id):
            self._state.diagnostics.append(diagnostic)


class ScanCallAdmission:
    """Pass admission=adapter, backend=adapter.wrap_backend(transport) to the scan.

    job_id/caller_id must come from the trusted job/auth context, never a model.
    The scope owner must match caller_id; applications using composite owner IDs
    must supply that same trusted identifier. One adapter may serve many threads.
    """

    def __init__(self, store: SnowflakeCallAdmission, *, job_id: str, caller_id: str,
                 poll_seconds: float = 0.05, heartbeat_seconds: float | None = None) -> None:
        self.store = store
        self.job_id = _identity(job_id, "job_id")
        self.caller_id = _identity(caller_id, "caller_id")
        self._poll = poll_seconds
        self._heartbeat = store.lease_seconds / 3 if heartbeat_seconds is None else heartbeat_seconds
        for value in (self._poll, self._heartbeat):
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError("Wait intervals must be positive and finite")
        if self._heartbeat >= store.lease_seconds:
            raise ValueError("Heartbeat must be shorter than the lease")
        self._current: ContextVar[_CallState | None] = ContextVar("automap_admission", default=None)

    @contextmanager
    def __call__(self, request: AdmissionRequest) -> Iterator[bool]:
        if self._current.get() is not None:
            raise AdmissionError("Nested admission is not supported")
        if request.scope.owner_id != self.caller_id:
            raise AdmissionError("Request caller scope mismatch")
        identity = CallIdentity(self.job_id, self.caller_id, request.generation, request.shard_id)
        attempt = 0
        wait_started = time.monotonic()
        credited_until = wait_started
        def credit_wait():
            nonlocal credited_until
            if getattr(self.store,'separate_wait_budget',False):
                now=time.monotonic()
                if now-wait_started > request.capacity_wait_limit_seconds:
                    raise AdmissionUnavailable('Execution capacity queue budget exhausted')
                if request.runtime_trace is not None:
                    request.runtime_trace.capacity_wait_seconds += now-credited_until
                credited_until=now
        while True:
            credit_wait()
            request.check_active()
            queue_deadline = request.effective_deadline
            if getattr(self.store, "separate_wait_budget", False):
                queue_deadline = min(queue_deadline, wait_started + request.capacity_wait_limit_seconds)
            control_token = _CONTROL_DEADLINE.set(queue_deadline)
            trace_token = _CONTROL_TRACE.set(getattr(request, 'runtime_trace', None))
            try:
                try:
                    permit = self.store.try_claim(identity)
                except AdmissionContended:
                    # Acknowledged rollback contention remains retryable; SQL
                    # statement timeouts are unchanged. Pool waiting is bounded
                    # by the existing execution-capacity/request deadline.
                    permit = None
            finally:
                _CONTROL_DEADLINE.reset(control_token)
                _CONTROL_TRACE.reset(trace_token)
            credit_wait()
            if permit is not None:
                break
            request.check_active()
            delay = min(2.0, max(0.25, self._poll) * 2 ** min(attempt, 3))
            delay *= 0.75 + random.random() * 0.5
            attempt += 1
            time.sleep(min(delay, request.remaining_seconds()))
        state = _CallState(request, permit, Event())
        stop = Event()

        def heartbeat() -> None:
            while not stop.wait(self._heartbeat):
                try:
                    retry_control_operation(request, "permit_renewal", lambda: self.store.renew(permit), renewal=True)
                except Exception:
                    state.renewal_failed.set()
                    try:
                        self.store.quarantine(permit)
                    except Exception:
                        pass  # HELD is just as non-reclaimable as QUARANTINED.
                    return

        thread = Thread(target=heartbeat, name="automap-permit-renew", daemon=True)
        token = self._current.set(state)
        entered = False
        primary_error = None
        try:
            request.check_active()
            thread.start()
            entered = True
            yield True
        except BaseException as exc:
            primary_error = exc
            trace = getattr(request, "runtime_trace", None)
            if trace is not None:
                trace.failure_phase = trace.phase
            raise
        finally:
            trace = getattr(request, "runtime_trace", None)
            if trace is not None:
                from app.core.automap_scan import RuntimePhase
                trace.enter(RuntimePhase.ADMISSION_CLEANUP)
            stop.set()
            cleanup_error = None
            try:
                if thread.ident is not None:
                    # An in-flight renewal uses an independent session; fencing makes
                    # a late heartbeat harmless after completion/reuse of this slot.
                    # Never wait a lease-derived interval (normally tens of seconds).
                    thread.join(timeout=min(self._heartbeat, 0.1))
            except BaseException as exc:
                cleanup_error = exc
            state.active = False
            self._current.reset(token)
            completion = Completion.NOT_DISPATCHED if not entered else state.completion
            cleanup_deadline = _CONTROL_DEADLINE.set(request.effective_deadline if request.remaining_seconds() > 0 else None)
            cleanup_trace = _CONTROL_TRACE.set(getattr(request, "runtime_trace", None))
            try:
                if state.terminal_commit_acknowledged:
                    pass  # Exact result and fenced release already committed together.
                elif completion is not None:
                    self.store.complete(permit, completion)
                else:
                    self.store.quarantine(permit)
            except BaseException as exc:
                cleanup_error = exc
            finally:
                _CONTROL_DEADLINE.reset(cleanup_deadline)
                _CONTROL_TRACE.reset(cleanup_trace)
            if cleanup_error is not None:
                error = primary_error if primary_error is not None else cleanup_error
                try:
                    error.admission_cleanup_failure_code = _cleanup_failure_code(cleanup_error)
                except Exception:
                    pass  # A custom immutable exception must still remain primary.
                if primary_error is None:
                    raise cleanup_error from None
            if entered and completion is None and not state.invoked and primary_error is None:
                raise UnreportedCompletion("Paired backend did not report completion")

    def _validate_lifecycle(self, state: _CallState) -> None:
        if (self._current.get() is not state or not state.active or not state.invoked
                or state.completion is not None or state.renewal_failed.is_set()):
            raise AdmissionError("Lifecycle requires its active paired backend permit")

    def bind_lifecycle(self, request: AdmissionRequest) -> ScanCallLifecycle:
        state = self._current.get()
        if state is None:
            raise AdmissionError("Lifecycle requires its unique admitted request")
        with state.lock:
            if state.request is not request or state.lifecycle_bound:
                raise AdmissionError("Lifecycle requires its unique admitted request")
            self._validate_lifecycle(state)
            state.lifecycle_bound = True
        return ScanCallLifecycle(self, state)

    def diagnostics_for(self, request: AdmissionRequest) -> tuple[ScanTransportDiagnostic, ...]:
        state = self._current.get()
        if state is None or state.request is not request:
            raise AdmissionError("Diagnostics require their admitted request")
        return tuple(state.diagnostics)

    def wrap_backend(self, backend: Callable[[AdmissionRequest], str]) -> Callable[[AdmissionRequest], str]:
        if not callable(backend):
            raise TypeError("A synchronous one-call backend is required")

        def guarded(request: AdmissionRequest) -> str:
            state = self._current.get()
            if state is None:
                raise AdmissionError("Backend requires its unused admission context")
            with state.lock:
                if not state.active or state.request is not request or state.invoked:
                    raise AdmissionError("Backend requires its unused admission context")
                state.invoked = True
            state.completion = Completion.NOT_DISPATCHED
            request.check_active()
            if state.renewal_failed.is_set():
                raise AdmissionUnavailable("Permit renewal failed before dispatch")
            trace = getattr(request, "runtime_trace", None)
            if trace is not None:
                from app.core.automap_scan import RuntimePhase
                trace.enter(RuntimePhase.PERMIT_RENEWAL)
            # Background transport proves ownership and renews the same lease
            # in its atomic preparation UPDATE immediately before submission.
            # Legacy transports still need this standalone renewal.
            if getattr(backend, 'atomic_dispatch_preparation', False) is not True:
                retry_control_operation(request, 'permit_renewal', lambda: self.store.renew(state.permit))
            request.check_active()
            state.completion = None
            try:
                result = backend(request)
            except RemoteCallNotDispatched:
                state.completion = Completion.NOT_DISPATCHED
                raise
            except RemoteCallCompleted:
                state.completion = Completion.FAILED
                raise
            else:
                state.completion = Completion.SUCCEEDED
                return result

        return guarded
