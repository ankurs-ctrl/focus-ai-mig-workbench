# Loan workbook and assistant follow-up — 13 November 2026

This follow-up supersedes only the relevant assistant/test findings in the earlier validation notes. It preserves the cumulative Auto-map and Deep Agent release.

## Actual Snowflake checks

- Target: `BBI_STTM_TEST_DB.DW_OPS.LOAN_INCOME_AMOUNT_CALCULATION`, 33 physical columns.
- Initial real sources: `DL_AMOUNT.LOAN_INCOME_AMOUNT_CALCULATION`, `DL_AMOUNT.NOTE`, `DW_OPS.PORTAL_USER_HISTORY`.
- Remaining real DW sources inspected and supplied to a focused missing-input check: `WORKFLOW_SESSION`, `WORKFLOW_SESSION_TYPE`, `WORKFLOW_STEP`. The existing synthetic output table `DIP_LOAN_INCOME_FULL_20261005` was not used as source evidence.
- The unchanged supplied workbook has 35 target definitions. `PORTAL_USER_UUID` and `SIMULATED_TERMS` are not physical target columns; workbook `DOCUMENTATION_ERROR_FLAG` corresponds by meaning to physical `DOC_ERROR_FLAG`. No target schema was changed.
- The actual local assistant endpoint invoked the installed builder agent and returned a structured CTE draft. Its first SQL failed numeric TRY_CAST compilation. One compiler-feedback turn corrected numeric conversion and CTE alias boundaries. Corrected SQL compiled and returned actual preview rows.
- Independent bounded checks covered three source identities: zero missing/duplicate identities, zero monthly-income conversion mismatches and zero original-loan-amount conversion mismatches.
- Isolated configured fast-path acceptance: five parallel source batches (6/7 targets each), five source POSTs plus two transformation POSTs; **32 valid proposals, four completed custom rules, one explicit missing dependency**, 202.31 seconds. No failed batches and all isolated execution slots released. All 33 targets have numeric confidence: supported proposals 0.60–0.95; unresolved target 0.
- All 32 proposals compiled together through the production SQL compiler. A wrapper explicitly limited execution to five rows; three preview rows returned.

`INCOME_REVIEW_DOCUMENT` remains unresolved. The workbook's `Original Query for Reference!C140:C144` derives IR_DOCUMENT from verification-task and task-log history, partitioned by product/actor. Current workflow metadata lacks the required actor/task-to-income associations. A focused one-target call with all six real sources returned an explicit gap and confidence 0. Its generic runner labels zero positive proposals as failed; this is retained in the evidence, alongside the independently checked expected unresolved outcome. It did not erase the 32 existing proposals.

## Business review remains required

The builder returned `needs_input`. Timezone meaning, current-active versus historical portal-user population, note windows/review associations and ranking tie-breakers need confirmation. The CREATED_TIME proposal uses America/Chicago at confidence 0.60; that is an unapproved assumption, not a confirmed interpretation of CST. Do not publish without reviewing these choices. Successful SQL compilation does not establish business correctness.

The real test retrieved three existing semantic records; the six-source focused check retrieved four. No synthetic FIR recipe was injected into this case. Earlier mixed acceptance independently verifies FIR reuse; this case is not presented as proof of complete FIR discovery.

A standard local invocation, where fast-path switches were absent, timed out at the client after 360 seconds. Its remote outcome remains uncertain and it was not replayed. The successful 202-second result is a distinct, isolated fast-path job. Newly deployed SPCS replicas and the standard-path timeout are not claimed as fixed by this follow-up.

## Changes and checks

- Streamed terminal envelopes pass through the existing typed response/artifact parser instead of being displayed as JSON.
- Recognizable internal STTM JSON envelopes are not rendered as user-facing code; ordinary JSON examples remain code.
- Unmistakable prose-only Markdown fences render as prose/tables. SQL remains code with existing styling and controls.
- Derived-source summaries exclude SQL bodies; the heading says Draft. SQL remains in the artifact.
- Derived-generation intent goes through AGT_STTM_BUILDER. Incomplete relationship graphs retain its response with a warning; they do not trigger an unready Analyst fallback. SQL/identifier checks remain enforced.
- Updated builder instructions require separate prose/SQL, exact CTE output aliases, correct numeric casts and explicit population assumptions.
- Backend targeted regressions: **88 passed**. Markdown, continuity and transformation-apply frontend regressions passed; TypeScript and agent manifest checks passed.

Deploy the updated backend/frontend together and apply the updated AGT_STTM_BUILDER instructions while preserving client tools, models, resources and budgets. No new table, capacity setting or environment file is introduced by this follow-up. The earlier cumulative release's evidence-tool/bootstrap/Deep Agent steps still apply. Native builder calls used the previously installed builder specification; the new instruction text is delivered for deployment, not claimed as already installed in the client.

No source or target data was modified and no mapping was published. Native previews are excluded from the package; only aggregate evidence and definitions are included.
