"use client";

import {
  AiaBox,
  AiaButton,
  AiaIconButton,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { CloseOutlinedIcon } from "@/utils/icons";

import type { HardcodedAttribute } from "./attributes-data";

const titleSx = { fontSize: 16, fontWeight: 600, color: "var(--aia-text-color)" } as const;
const bodySx = { fontSize: 14, fontWeight: 400, color: "#475569", lineHeight: 1.5 } as const;
const buttonSx = {
  minWidth: 96,
  height: 38,
  borderRadius: "10px",
  textTransform: "none",
  fontSize: 13,
  fontWeight: 600,
  boxShadow: "none",
} as const;

export type FirmValueDeleteResult = {
  deletedNames: string[];
  blockedMessages: string[];
};

type DeleteAttributeModalProps = {
  open: boolean;
  attributes: HardcodedAttribute[];
  result?: FirmValueDeleteResult | null;
  onClose: () => void;
  onConfirm: () => void;
};

function joinNames(names: string[]) {
  if (names.length <= 1) {
    return names[0] ?? "";
  }
  if (names.length === 2) {
    return `${names[0]} and ${names[1]}`;
  }
  return `${names.slice(0, -1).join(", ")}, and ${names[names.length - 1]}`;
}

export default function DeleteAttributeModal({
  open,
  attributes,
  result = null,
  onClose,
  onConfirm,
}: DeleteAttributeModalProps) {
  const hasResult = Boolean(result && (result.deletedNames.length || result.blockedMessages.length));
  if (!open || (attributes.length === 0 && !hasResult)) {
    return null;
  }

  const deletedNames = result?.deletedNames ?? [];
  const blockedMessages = result?.blockedMessages ?? [];
  const single = attributes.length === 1 ? attributes[0] : null;
  const title = hasResult
    ? deletedNames.length
      ? "Deleted"
      : "Cannot delete"
    : "Delete Attribute?";

  return (
    <AiaBox
      role="dialog"
      aria-modal="true"
      aria-label={title}
      sx={{
        position: "fixed",
        inset: 0,
        zIndex: 1400,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        p: 2,
      }}
    >
      <AiaBox
        onClick={onClose}
        sx={{
          position: "absolute",
          inset: 0,
          bgcolor: "rgba(15, 23, 42, 0.45)",
        }}
      />

      <AiaBox
        sx={{
          position: "relative",
          width: "100%",
          maxWidth: 480,
          borderRadius: "16px",
          bgcolor: "#FFFFFF",
          border: "1px solid #E5E7EB",
          boxShadow: "0 24px 60px rgba(15, 23, 42, 0.18)",
          overflow: "hidden",
        }}
      >
        <AiaBox
          sx={{
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "space-between",
            gap: 1.5,
            px: 2.5,
            py: 2,
            borderBottom: "1px solid #F1F5F9",
          }}
        >
          <AiaText sx={titleSx}>{title}</AiaText>
          <AiaIconButton
            aria-label="Close dialog"
            onClick={onClose}
            sx={{
              width: 32,
              height: 32,
              color: "#64748B",
              border: "1px solid #E5E7EB",
              borderRadius: "8px",
            }}
          >
            <CloseOutlinedIcon sx={{ fontSize: 18 }} />
          </AiaIconButton>
        </AiaBox>

        <AiaBox sx={{ px: 2.5, py: 2.25, display: "flex", flexDirection: "column", gap: 1.25 }}>
          {hasResult ? (
            <>
              {deletedNames.length ? (
                <AiaText sx={bodySx}>
                  {joinNames(deletedNames)} {deletedNames.length === 1 ? "was" : "were"} deleted.
                </AiaText>
              ) : null}
              {blockedMessages.map((message) => (
                <AiaText key={message} sx={bodySx}>
                  {message}
                </AiaText>
              ))}
            </>
          ) : single ? (
            <AiaText sx={bodySx}>
              Are you sure you want to delete {single.attributeName}? This action cannot be undone.
            </AiaText>
          ) : (
            <>
              <AiaText sx={bodySx}>
                Are you sure you want to delete these {attributes.length} firm values? This action cannot be undone.
              </AiaText>
              <AiaBox component="ul" sx={{ mt: 0, mb: 0, pl: 2.5 }}>
                {attributes.map((item) => (
                  <AiaText key={item.id} component="li" sx={{ ...bodySx, fontSize: 13, lineHeight: 1.6 }}>
                    {item.attributeName}
                  </AiaText>
                ))}
              </AiaBox>
            </>
          )}
        </AiaBox>

        <AiaBox
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 1.25,
            px: 2.5,
            py: 2,
            borderTop: "1px solid #F1F5F9",
            bgcolor: "#FAFBFC",
          }}
        >
          {hasResult ? (
            <AiaButton variant="contained" onClick={onClose} sx={buttonSx}>
              OK
            </AiaButton>
          ) : (
            <>
              <AiaButton
                variant="outlined"
                onClick={onClose}
                sx={{
                  ...buttonSx,
                  borderColor: "#E5E7EB",
                  color: "#374151",
                  "&:hover": {
                    borderColor: "#D1D5DB",
                    bgcolor: "#F9FAFB",
                  },
                }}
              >
                Cancel
              </AiaButton>
              <AiaButton
                variant="contained"
                onClick={onConfirm}
                sx={{
                  ...buttonSx,
                  bgcolor: "#DC2626",
                  color: "#FFFFFF",
                  border: "1px solid #DC2626",
                  "&:hover": {
                    bgcolor: "#B91C1C",
                    boxShadow: "none",
                  },
                }}
              >
                Delete
              </AiaButton>
            </>
          )}
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
