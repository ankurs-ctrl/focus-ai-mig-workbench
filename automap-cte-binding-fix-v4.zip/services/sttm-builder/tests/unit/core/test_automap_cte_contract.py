from copy import deepcopy

import pytest
from sqlglot import exp, parse_one

from app.core.automap_cte_contract import hydrate_authored_cte_graph
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest


def request(child="SELECT p.X47 FROM p", *, parent="SELECT X47 FROM D.S.T"):
    sql = f"WITH p AS ({parent}), c AS ({child}) SELECT c.X47 FROM c"
    return STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "data": {"intent": "AUTO_MAP"},
        "context": {"workspace_context": {"mapping_sql": sql}, "relation_graph": {"nodes": [
            {"relation_id": "t", "alias": "t", "kind": "PHYSICAL_TABLE",
             "table": {"database": "D", "schema": "S", "table": "T"}, "output_columns": [{"name": "X47"}]},
            {"relation_id": "p", "alias": "dp", "kind": "DERIVED_SOURCE", "original_cte_name": "p",
             "parent_relation_ids": ["t"], "sql_text": "SELECT * FROM p", "output_columns": [{"name": "X47"}]},
            {"relation_id": "c", "alias": "dc", "kind": "DERIVED_SOURCE", "original_cte_name": "c",
             "parent_relation_ids": ["p"], "sql_text": sql.rsplit(" SELECT c.X47 FROM c", 1)[0] + " SELECT * FROM c",
             "output_columns": [{"name": "X47"}]}]}}})


@pytest.mark.parametrize("child", ["SELECT p.X47 FROM p", "SELECT a.X47 FROM p AS a",
    "SELECT p.X47 FROM p WHERE EXISTS (WITH p AS (SELECT 1 AS X47) SELECT p.X47 FROM p)"])
def test_scoped_rebinding_preserves_qualifiers_aliases_and_shadowing(child):
    req = request(child)
    original = deepcopy(req.model_dump())
    hydrated = hydrate_authored_cte_graph(req)
    body = parse_one(hydrated.context.relation_graph.nodes[-1].sql_text, read="snowflake")
    tables = list(body.find_all(exp.Table))
    parent = next(table for table in tables if table.name == "dp")
    assert parent.alias.upper() == ("A" if " AS a" in child else "P")
    assert all(column.table.upper() in {"A", "P"} for column in body.find_all(exp.Column))
    if "EXISTS" in child:
        assert any(table.name == "P" for table in tables)  # local CTE stays local
    assert hydrate_authored_cte_graph(hydrated).model_dump() == hydrated.model_dump()
    assert req.model_dump() == original


@pytest.mark.parametrize("changed", ["SELECT X47 FROM D.S.T WHERE 1=0", "SELECT X47+1 AS X47 FROM D.S.T",
                                    "SELECT X47 FROM D.S.OTHER", "SELECT X47 AS HIDDEN FROM D.S.T"])
def test_actual_definition_mutation_is_rejected_even_with_matching_old_hash(changed):
    req = hydrate_authored_cte_graph(request())
    req.context.relation_graph.nodes[1].sql_text = changed
    with pytest.raises(ValueError, match="body differs"):
        hydrate_authored_cte_graph(req)
    from app.core.automap_fast_context import validate_derived_output_contracts
    with pytest.raises(ValueError, match="body differs"):
        validate_derived_output_contracts(req, None)


def test_self_contained_wrapper_dependency_mutation_is_rejected():
    req = request()
    req.context.relation_graph.nodes[-1].sql_text = req.context.relation_graph.nodes[-1].sql_text.replace(
        "SELECT X47 FROM D.S.T", "SELECT X47 FROM D.S.T WHERE 1=0")
    with pytest.raises(ValueError, match="dependency differs"):
        hydrate_authored_cte_graph(req)


def test_quoted_parent_case_and_column_qualifier_survive_rebinding():
    req = request()
    for node in req.context.relation_graph.nodes[1:]:
        node.sql_text = node.sql_text.replace("p", '"Parent"')
    req.context.relation_graph.nodes[1].original_cte_name = '"Parent"'
    req.context.workspace_context.mapping_sql = req.context.workspace_context.mapping_sql.replace("p", '"Parent"')
    req.context.workspace_context.raw_mapping_sql = req.context.workspace_context.mapping_sql
    hydrated = hydrate_authored_cte_graph(req)
    sql = hydrated.context.relation_graph.nodes[-1].sql_text
    assert '"Parent".X47' in sql and 'dp AS "Parent"' in sql


def test_filtered_outer_wrapper_is_not_discarded():
    req = request()
    req.context.relation_graph.nodes[-1].sql_text += " WHERE 1=0"
    with pytest.raises(ValueError, match="body differs"):
        hydrate_authored_cte_graph(req)


def test_distinct_quoted_output_case_is_not_collapsed_by_contract_validation():
    from app.core.automap_fast_context import validate_derived_output_contracts
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "data": {"intent": "AUTO_MAP"},
        "context": {"workspace_context": {"mapping_sql": 'WITH c AS (SELECT 1 AS "a", 2 AS "A") SELECT * FROM c',
                                          "driving_relation_id": "c"},
                    "relation_graph": {"nodes": [{"relation_id": "c", "alias": "dc", "kind": "DERIVED_SOURCE",
                        "original_cte_name": "c", "sql_text": "SELECT * FROM c", "output_columns": [
                            {"name": "a", "sql_name": '"a"'}, {"name": "A", "sql_name": '"A"'}]}]}}})
    hydrated = hydrate_authored_cte_graph(req)
    assert set(validate_derived_output_contracts(hydrated, None)) == {"c"}


@pytest.mark.parametrize("suffix", [" SAMPLE (0)", " AS renamed (RENAMED_OUTPUT)"])
@pytest.mark.parametrize("wrapped", [False, True])
def test_population_or_output_modifiers_are_never_stripped_from_wrapper(suffix, wrapped):
    req = request()
    node = req.context.relation_graph.nodes[-1] if wrapped else req.context.relation_graph.nodes[1]
    node.sql_text += suffix
    before = req.model_dump()
    with pytest.raises(ValueError, match="body differs"):
        hydrate_authored_cte_graph(req)
    assert req.model_dump() == before


def test_plain_relation_alias_is_a_transparent_wrapper():
    req = request()
    req.context.relation_graph.nodes[1].sql_text += " AS named"
    assert hydrate_authored_cte_graph(req).context.relation_graph.nodes[1].sql_text == "SELECT X47 FROM D.S.T"


@pytest.mark.parametrize("nested", [False, True])
def test_unreachable_positional_cte_does_not_block_selected_definition(nested):
    req = request("WITH unused(Y) AS (SELECT 0) SELECT p.X47 FROM p" if nested else "SELECT p.X47 FROM p")
    if not nested:
        sql = req.context.workspace_context.mapping_sql.replace("WITH p", "WITH unused(Y) AS (SELECT 0), p", 1)
        req.context.workspace_context.mapping_sql = sql
        req.context.workspace_context.raw_mapping_sql = sql
    before = req.model_dump()
    hydrated = hydrate_authored_cte_graph(req)
    assert "dp AS P" in hydrated.context.relation_graph.nodes[-1].sql_text
    assert req.model_dump() == before
    assert hydrate_authored_cte_graph(hydrated).model_dump() == hydrated.model_dump()


def test_reachable_positional_cte_remains_an_explicit_blocker():
    req = request()
    sql = req.context.workspace_context.mapping_sql.replace("WITH p AS", "WITH p(X47) AS", 1)
    req.context.workspace_context.mapping_sql = req.context.workspace_context.raw_mapping_sql = sql
    with pytest.raises(ValueError, match="unsupported positional"):
        hydrate_authored_cte_graph(req)


def test_sampling_inside_the_authored_definition_is_preserved():
    req = request(parent="SELECT X47 FROM D.S.T SAMPLE (0)")
    assert "TABLESAMPLE" in hydrate_authored_cte_graph(req).context.relation_graph.nodes[1].sql_text


@pytest.mark.parametrize("child", [
    "WITH dp AS (SELECT 999 AS X47) SELECT p.X47 FROM p",
    "SELECT p.X47 FROM p WHERE EXISTS (WITH dp AS (SELECT 999 AS X47) SELECT p.X47 FROM p)",
    'WITH "DP" AS (SELECT 999 AS X47) SELECT p.X47 FROM p',
])
def test_runtime_name_capture_is_rejected_before_value_can_change_from_one_to_999(child):
    import sqlite3
    from app.core.automap_fast_context import validate_derived_output_contracts
    req = request(child, parent="SELECT 1 AS X47")
    req.context.relation_graph.nodes[1].parent_relation_ids = []
    with sqlite3.connect(":memory:") as db:
        assert db.execute(req.context.workspace_context.mapping_sql).fetchall() == [(1,)]
    before = req.model_dump()
    with pytest.raises(ValueError, match="collides with a nested CTE"):
        hydrate_authored_cte_graph(req)
    with pytest.raises(ValueError, match="collides with a nested CTE"):
        validate_derived_output_contracts(req, None)
    assert req.model_dump() == before


def test_distinct_quoted_local_name_does_not_capture_unquoted_runtime_name():
    req = request('WITH "dp" AS (SELECT 999 AS X47) SELECT p.X47 FROM p', parent="SELECT 1 AS X47")
    req.context.relation_graph.nodes[1].parent_relation_ids = []
    hydrated = hydrate_authored_cte_graph(req)
    assert 'WITH "dp" AS' in hydrated.context.relation_graph.nodes[-1].sql_text
    assert "FROM dp AS P" in hydrated.context.relation_graph.nodes[-1].sql_text
    assert hydrate_authored_cte_graph(hydrated).model_dump() == hydrated.model_dump()


def test_local_table_alias_is_not_a_cte_name_collision():
    req = request("SELECT p.X47 FROM p JOIN D.S.T AS dp ON dp.X47 = p.X47")
    assert "JOIN D.S.T AS DP" in hydrate_authored_cte_graph(req).context.relation_graph.nodes[-1].sql_text


def test_runtime_alias_cannot_capture_an_unqualified_physical_source():
    req = request("SELECT p.X47 FROM p JOIN dp AS physical ON physical.X47 = p.X47")
    with pytest.raises(ValueError, match="collides with a physical source"):
        hydrate_authored_cte_graph(req)


def test_simultaneous_top_level_renames_preserve_original_relation_identity():
    import sqlite3
    req = request(parent="SELECT 1 AS X47")
    req.context.relation_graph.nodes[1].alias = "c"
    req.context.relation_graph.nodes[1].parent_relation_ids = []
    req.context.relation_graph.nodes[-1].alias = "p"
    hydrated = hydrate_authored_cte_graph(req)
    parent, child = hydrated.context.relation_graph.nodes[1:]
    sql = f"WITH c AS ({parent.sql_text}), p AS ({child.sql_text}) SELECT * FROM p"
    with sqlite3.connect(":memory:") as db:
        assert db.execute(sql).fetchall() == [(1,)]


def test_unreachable_nested_runtime_collision_does_not_block_selected_source():
    req = request(parent="SELECT 1 AS X47")
    sql = req.context.workspace_context.mapping_sql.replace(
        "WITH p", "WITH unused AS (WITH dp AS (SELECT 999 AS X47) SELECT p.X47 FROM p), p", 1)
    req.context.workspace_context.mapping_sql = req.context.workspace_context.raw_mapping_sql = sql
    assert hydrate_authored_cte_graph(req).context.relation_graph.nodes[-1].dependency_hash


def test_fresh_binding_analysis_catches_capture_even_if_initial_visibility_probe_misses_it(monkeypatch):
    import app.core.automap_cte_contract as contract
    original_scoped = contract._scoped
    def stale_visibility(sql):
        tree, root, definitions = original_scoped(sql)
        for scope in root.traverse():
            scope.cte_sources = {name: source for name, source in scope.cte_sources.items() if name != "DP"}
        return tree, root, definitions
    monkeypatch.setattr(contract, "_scoped", stale_visibility)
    req = request("WITH dp AS (SELECT 999 AS X47) SELECT p.X47 FROM p", parent="SELECT 1 AS X47")
    with pytest.raises(ValueError, match="changes relation bindings"):
        contract.hydrate_authored_cte_graph(req)


def test_unused_top_level_runtime_name_is_not_introduced_into_emitted_namespace():
    import sqlite3
    req = request(parent="SELECT 1 AS X47")
    req.context.relation_graph.nodes[1].parent_relation_ids = []
    sql = req.context.workspace_context.mapping_sql.replace("WITH p", "WITH dp AS (SELECT 999 AS X47), p", 1)
    req.context.workspace_context.mapping_sql = req.context.workspace_context.raw_mapping_sql = sql
    hydrated = hydrate_authored_cte_graph(req)
    parent, child = hydrated.context.relation_graph.nodes[1:]
    sql = f"WITH dp AS ({parent.sql_text}), dc AS ({child.sql_text}) SELECT * FROM dc"
    with sqlite3.connect(":memory:") as db:
        assert db.execute(sql).fetchall() == [(1,)]


def test_reachable_top_level_parent_requires_an_explicit_graph_binding():
    req = request()
    req.context.relation_graph.nodes = [req.context.relation_graph.nodes[0], req.context.relation_graph.nodes[-1]]
    with pytest.raises(ValueError, match="no graph runtime binding"):
        hydrate_authored_cte_graph(req)
