"""One review table per run: planning questions, confidence rows and true blockers.

Run 25 raised 151 review items, 69 of them blocking, most of them per-column
findings nobody needs to answer before the draft is usable. This module sorts
every finding into one of three tiers and folds repeats across targets into one
row, so the user sees a short list of decisions and a table of confidence rows
instead of a wall of blockers.

- planning question: a business decision only the user can make (a missing
  firm value, a population rule or grain with no precedent, a firm override).
  Only asked when a plan exists; without a plan everything goes to the table.
- blocker: the draft cannot be produced (no driving table, SQL that could not be
  repaired, the workflow never ran).
- confidence: everything else, including per-column choices and pass/fail checks.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

TIER_BLOCKER = "blocker"
TIER_PLANNING = "planning_question"
TIER_CONFIDENCE = "confidence"

_BLOCKER_CATEGORIES = {
    "source_preparation", "source_design_incomplete", "sql_repair_review", "workflow_not_invoked",
    "evidence_preparation_failed", "supervisor_plan_required",
}
_PLANNING_CATEGORIES = {
    "value_binding_input", "population_rule_review", "historical_business_review", "attachment_conflict",
    "precedent_override", "source_research_choice", "source_join_path", "source_join_path_batch",
    "confidence_gate", "confidence_gate_batch", "plan_approval", "plan_edit", "join_grain",
}
_CHECK_CATEGORIES = {
    "mapping_tests", "relationship_reconciliation", "join_coverage", "join_fanout", "join_key_contract",
    "join_key_type", "relationship_contract", "precedent_contract", "derived_source_validation",
}
_IMPACT = {TIER_BLOCKER: 3, TIER_PLANNING: 2, TIER_CONFIDENCE: 0}


def _details(item: dict[str, Any]) -> dict[str, Any]:
    return dict(item.get("details") or {})


def tier_of(item: dict[str, Any], *, has_plan: bool) -> str:
    category = str(item.get("category") or "")
    details = _details(item)
    if category in _BLOCKER_CATEGORIES and item.get("blocking", True):
        return TIER_BLOCKER
    if not has_plan:
        return TIER_CONFIDENCE
    if category in _PLANNING_CATEGORIES:
        return TIER_PLANNING
    if category == "mapping_candidate_review" and details.get("firm_value_name"):
        return TIER_PLANNING  # the firm's own value, which no evidence can supply
    return TIER_CONFIDENCE


def _normalized(text: str, names: list[str]) -> str:
    value = re.sub(r"^\s*[A-Z][A-Z0-9_]*(?:\.[A-Z0-9_\"]+)?\s*:\s*", "", str(text or ""))
    for name in names:
        if name:
            value = re.sub(rf"\b{re.escape(name)}\b", "<target>", value, flags=re.IGNORECASE)
    return re.sub(r"\d+", "<n>", re.sub(r"\s+", " ", value)).strip().lower()


def _prefix_target(text: str) -> str:
    """``HOUSEHOLD: ...`` names its target when the finding carries no table."""
    match = re.match(r"^\s*([A-Z][A-Z0-9_]*)\s*:", str(text or ""))
    return match.group(1) if match else ""


def decision_key(item: dict[str, Any], target: str) -> str:
    """Findings that ask the same decision of several targets share one key."""
    details = _details(item)
    category = str(item.get("category") or "")
    firm_value = details.get("firm_value_name") or details.get("attribute_name") or details.get("placeholder")
    if firm_value and category in {"mapping_candidate_review", "value_binding_input"}:
        return f"firm_value:{str(firm_value).strip('$').upper()}"
    column = str(details.get("target_column") or "")
    if column and category == "mapping_candidate_review":
        return f"{category}:{target}:{column}".upper()
    return f"{category}:{_normalized(str(item.get('safe_summary') or ''), [target, target.rsplit('.', 1)[-1]])}"


def _short(table: Any) -> str:
    return str(table or "").rsplit(".", 1)[-1].strip('"')


def _member_columns(details: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for item in [*(details.get("target_columns") or []), *(details.get("columns") or [])]:
        value = item.get("target_column") if isinstance(item, dict) else item
        if value and str(value).strip():
            values.append(str(value))
    return list(dict.fromkeys(values))


def _choice(row: dict[str, Any]) -> str:
    expression = str(row.get("expression") or "").strip()
    if expression:
        return expression
    if row.get("attribute_name"):
        return f"${row['attribute_name']}"
    if row.get("constant_value") not in (None, ""):
        return repr(row.get("constant_value"))
    return ", ".join(str(item) for item in row.get("source_columns") or []) or "unmapped"


def target_is_ready(result: dict[str, Any]) -> bool:
    """A usable target has complete rows and validated extraction SQL."""
    rows = [row for row in result.get("mapping_rows") or [] if isinstance(row, dict)]
    if not rows:
        return False
    required = {str(value).upper() for value in result.get("target_columns") or [] if str(value).strip()}
    present = {str(row.get("target_column") or "").upper() for row in rows if row.get("target_column")}
    if required and not required.issubset(present):
        return False
    if any(str(row.get("status") or "").lower() in {"unresolved", "unmapped"} for row in rows):
        return False
    validation = dict(result.get("sql_validation") or {})
    return validation.get("compile_valid") is True and validation.get("preview_valid") is True


def build_review_table(
    mapping_results: list[dict[str, Any]],
    review_items: list[dict[str, Any]],
    *,
    has_plan: bool,
    accept_threshold: float = 0.8,
    target_count: int = 0,
) -> dict[str, Any]:
    """Rows sorted by impact then lowest confidence, plus the run's summary counts."""
    rows: list[dict[str, Any]] = []
    by_key: dict[str, dict[str, Any]] = {}
    reviewed_columns: set[tuple[str, str]] = set()
    mapping_rows_by_target = {
        str(result.get("target_table") or result.get("mapping_name") or "").upper(): {
            str(row.get("target_column") or "").upper(): row
            for row in result.get("mapping_rows") or []
        }
        for result in mapping_results
    }
    for item in review_items:
        details = _details(item)
        member_columns = _member_columns(details)
        target_key = str(item.get("target_table") or item.get("mapping_name") or _details(item).get("target_table") or "")
        target = _short(target_key)
        target_column = str(details.get("target_column") or "").upper()
        if item.get("category") == "mapping_candidate_review" and target_column:
            mapping_row = mapping_rows_by_target.get(target_key.upper(), {}).get(target_column)
            if mapping_row is not None and str(mapping_row.get("status") or "").lower() == "draft":
                confidence = mapping_row.get("confidence")
                if isinstance(confidence, (int, float)) and confidence >= accept_threshold:
                    # The synthesized mapping row below is the audit record
                    # for a validated high-confidence choice. The persisted
                    # finding must not survive as a second open decision.
                    continue
        if not target and not _details(item).get("target_column"):
            target = _prefix_target(str(item.get("safe_summary") or ""))
            target_key = target
        tier = tier_of(item, has_plan=has_plan)
        key = f"{tier}:{decision_key(item, target_key or target)}"
        existing = by_key.get(key)
        if existing is not None:
            if target and target not in existing["targets"]:
                existing["targets"].append(target)
            existing["review_item_ids"].extend(v for v in [item.get("review_item_id")] if v)
            existing["source_blocking"] = existing["source_blocking"] or bool(item.get("blocking"))
            existing["prevents_target_ready"] = existing["prevents_target_ready"] or bool(item.get("blocking"))
            if str(item.get("status") or "OPEN") not in {"ANSWERED", "RESOLVED", "DISMISSED", "ACCEPTED"}:
                existing["status"] = str(item.get("status") or "OPEN")
            continue
        for column in [details.get("target_column"), *member_columns]:
            if column:
                reviewed_columns.add(((target_key or target).upper(), str(column).upper()))
        member_confidences = [
            value.get("confidence")
            for value in details.get("columns") or []
            if isinstance(value, dict) and isinstance(value.get("confidence"), (int, float))
        ]
        grouped_mapping_review = (
            item.get("category") == "mapping_candidate_review"
            and not details.get("target_column")
            and bool(member_columns)
        )
        row = {
            "row_id": key,
            "mapping_key": item.get("mapping_key") or details.get("mapping_key"),
            "mapping_name": item.get("mapping_name") or details.get("mapping_name") or target,
            "sttm_id": item.get("sttm_id") or details.get("sttm_id"),
            "tier": tier,
            "category": str(item.get("category") or ""),
            "kind": "mapping_group" if grouped_mapping_review else "check" if item.get("category") in _CHECK_CATEGORIES else "decision",
            "targets": [target] if target else [],
            "target_keys": [target_key] if target_key else [],
            "column": details.get("target_column") or (
                f"{len(member_columns)} uncorroborated mappings" if grouped_mapping_review else None
            ),
            "current_choice": details.get("current_choice") or details.get("selected_value") or (
                ", ".join(member_columns) if grouped_mapping_review else None
            ),
            "confidence": details.get("confidence") if details.get("confidence") is not None else (
                min(member_confidences) if member_confidences else None
            ),
            "why": str(item.get("safe_summary") or ""),
            "status": str(item.get("status") or "OPEN"),
            "blocking": tier == TIER_BLOCKER,
            "source_blocking": bool(item.get("blocking")),
            "prevents_target_ready": bool(item.get("blocking")),
            "review_item_ids": [v for v in [item.get("review_item_id")] if v],
        }
        by_key[key] = row
        rows.append(row)
    validated_targets: set[str] = set()
    for result in mapping_results:
        target_key = str(result.get("target_table") or result.get("mapping_name") or "")
        target = _short(target_key)
        validation = dict(result.get("sql_validation") or {})
        if target and validation.get("compile_valid") is True and validation.get("preview_valid") is True:
            validated_targets.add(target_key.upper())
        for mapping_row in result.get("mapping_rows") or []:
            column = str(mapping_row.get("target_column") or "")
            key = f"{TIER_CONFIDENCE}:mapping_candidate_review:{target_key}:{column}".upper()
            confidence = mapping_row.get("confidence")
            unresolved = str(mapping_row.get("status") or "").lower() == "unresolved"
            if (target_key.upper(), column.upper()) in reviewed_columns:
                continue
            existing = next((row for row in rows if row["row_id"].upper() in {key, key.replace(
                TIER_CONFIDENCE.upper(), TIER_PLANNING.upper(), 1)}), None)
            if existing is not None:
                existing.update(column=existing["column"] or column,
                                current_choice=existing["current_choice"] or _choice(mapping_row),
                                confidence=existing["confidence"] if existing["confidence"] is not None else confidence)
                continue
            rows.append({
                "row_id": key, "mapping_key": result.get("mapping_key"),
                "mapping_name": result.get("mapping_name") or target,
                "sttm_id": result.get("sttm_id"),
                "tier": TIER_CONFIDENCE, "category": "column_mapping",
                "kind": str(mapping_row.get("mapping_classification") or "direct"),
                "targets": [target], "target_keys": [target_key], "column": column,
                "current_choice": _choice(mapping_row),
                "confidence": confidence,
                "why": str(mapping_row.get("confidence_reason") or mapping_row.get("decision_reason") or ""),
                "status": "UNRESOLVED" if unresolved else "PROPOSED",
                "blocking": False, "source_blocking": False, "prevents_target_ready": unresolved,
                "review_item_ids": [],
            })
    for row in rows:
        confidence = row["confidence"]
        row["impact"] = _IMPACT[row["tier"]] + (1 if row["status"] == "UNRESOLVED" else 0) + len(row["targets"]) / 100
        row["accept_eligible"] = (row["tier"] == TIER_CONFIDENCE and row["status"] == "PROPOSED"
                                  and isinstance(confidence, (int, float)) and confidence >= accept_threshold)
        row["auto_approve_eligible"] = bool(
            row["accept_eligible"] and row["category"] in {"column_mapping", "mapping_candidate_review"}
            and row.get("target_keys") and all(str(value).upper() in validated_targets for value in row["target_keys"])
        )
        row["actionability"] = (
            "required" if row["tier"] in {TIER_BLOCKER, TIER_PLANNING} or row["status"] == "UNRESOLVED"
            else "informational" if row["auto_approve_eligible"] or row["kind"] == "check"
            else "confirmation"
        )
        row["row_digest"] = hashlib.sha256(json.dumps({
            key: row.get(key) for key in (
                "row_id", "target_keys", "column", "current_choice", "confidence", "status", "review_item_ids"
            )
        }, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()
    rows.sort(key=lambda row: (-row["impact"], row["confidence"] if isinstance(row["confidence"], (int, float)) else -1))
    open_rows = [row for row in rows if row["status"] not in {"ANSWERED", "RESOLVED", "DISMISSED", "ACCEPTED"}]
    summary = {
        "targets_ready": len({
            str(result.get("target_table") or result.get("mapping_name") or "").upper()
            for result in mapping_results
            if target_is_ready(result)
        }),
        "targets": max(len({str(result.get("target_table") or result.get("mapping_name") or "").upper()
                            for result in mapping_results if result.get("target_table") or result.get("mapping_name")}),
                       int(target_count or 0)),
        "planning_questions": sum(1 for row in open_rows if row["tier"] == TIER_PLANNING),
        "blockers": sum(1 for row in open_rows if row["tier"] == TIER_BLOCKER),
        "decisions_to_confirm": sum(1 for row in open_rows if row["tier"] == TIER_CONFIDENCE and row["kind"] != "check"),
        "checks_failed": sum(1 for row in open_rows if row["kind"] == "check"),
        "accept_eligible": sum(1 for row in open_rows if row["accept_eligible"]),
        "actionable": sum(1 for row in open_rows if row["actionability"] in {"required", "confirmation"}),
        "informational": sum(1 for row in open_rows if row["actionability"] == "informational"),
    }
    mappings = [
        {
            "mapping_key": result.get("mapping_key"),
            "mapping_name": result.get("mapping_name") or _short(result.get("target_table")),
            "target_table": result.get("target_table"),
            "sttm_id": result.get("sttm_id"),
            "mapped_count": sum(
                1 for mapping_row in result.get("mapping_rows") or []
                if str(mapping_row.get("status") or "").lower() == "draft"
            ),
            "unresolved_count": sum(
                1 for mapping_row in result.get("mapping_rows") or []
                if str(mapping_row.get("status") or "").lower() in {"unresolved", "unmapped"}
            ),
            "total_count": len(result.get("target_columns") or result.get("mapping_rows") or []),
            "compile_valid": dict(result.get("sql_validation") or {}).get("compile_valid") is True,
            "preview_valid": dict(result.get("sql_validation") or {}).get("preview_valid") is True,
        }
        for result in mapping_results
    ]
    return {"rows": rows, "mappings": mappings, "summary": summary}
