"""Real native worker/tool orchestration; simulated model and storage boundaries.

Checks concurrent early specialist work and checkpoint recovery when delivery
fails. Does not claim live Snowflake invocation or production mapping accuracy.
"""

import asyncio
from contextlib import contextmanager
from copy import deepcopy
from threading import Event, RLock
from types import SimpleNamespace
import time
import pytest
from app.core import automap_native as native
from app.core.automap_native_contract import digest, encoded, initial_state
from app.core.automap_native_tools import NativeTools
from app.core.automap_native_ports import compile_proposal
from tests.unit.core.test_automap_native_tools import proposal, read_required, call
from tests.unit.core.test_automap_fast_batch import (
    prepared_request,
    service,
    FinalAgent,
)
from tests.unit.core.test_automap_fast_context import fast_payload


class Registry:
    def __init__(self):
        self.rows = {}
        self.ids = {}
        self.lock = RLock()
        self.fail_finish = False

    def create(self, snapshot, config, *, batch_identity, deadline_at):
        with self.lock:
            if batch_identity in self.ids:
                return self.ids[batch_identity]
            handle = digest(batch_identity)
            self.ids[batch_identity] = handle
            self.rows[handle] = {
                "SNAPSHOT": deepcopy(snapshot),
                "SNAPSHOT_HASH": snapshot["snapshot_hash"],
                "CONFIG": deepcopy(config),
                "STATE": initial_state(),
                "DEADLINE_EPOCH": deadline_at,
            }
            return handle

    def lookup(self, identity):
        return self.ids.get(identity)

    def load(self, handle, **kw):
        with self.lock:
            return deepcopy(self.rows[handle])

    @contextmanager
    def edit(self, handle, **kw):
        with self.lock:
            state = deepcopy(self.rows[handle]["STATE"])
            yield state
            state["revision"] += 1
            self.rows[handle]["STATE"] = deepcopy(state)
            if self.fail_finish and state["dispatcher"] in {"terminal", "uncertain"}:
                raise RuntimeError("simulated lost finalization acknowledgement")

    def trace(self, handle, stage, counts=None):
        with self.edit(handle) as state:
            state["trace"].append(
                {"stage": stage, "at": time.time(), "counts": counts or {}}
            )


class HandleStore:
    def __init__(self, registry, handle):
        self.registry = registry
        self.handle = handle

    def load(self, handle, **kw):
        return self.registry.load(self.handle, **kw)

    def edit(self, handle, **kw):
        return self.registry.edit(self.handle, **kw)


def setup(monkeypatch, *, source_failure=False, finalization_failure=False):
    req = prepared_request(fast_payload(2))
    builder = service(FinalAgent())
    builder._settings = builder._settings.model_copy(
        update={
            "automap_native_tools_v1": True,
            "automap_native_project_ids": "allowed",
            "automap_native_max_windows": 2,
            "snowflake_database": "DB",
            "snowflake_schema": "META",
        }
    )
    builder._query_session = None
    builder._govern_request_for_model = lambda req, decision: req
    builder._postflight_guard = SimpleNamespace(
        finalize_sttm_response=lambda response, decision: response
    )
    registry = Registry()
    registry.fail_finish = finalization_failure
    monkeypatch.setattr(native, "NativeJobStore", lambda *a: registry)

    @contextmanager
    def sessions():
        yield SimpleNamespace()

    bundle = SimpleNamespace(archive=SimpleNamespace(_factory=sessions))
    monkeypatch.setattr(native, "_bundle", lambda *a: bundle)
    started = Event()
    calls = []

    class Runtime:
        def __init__(self, kind):
            self.kind = kind
            self.next_call_index = 1
            self.bundle = SimpleNamespace(
                backend=SimpleNamespace(
                    provider_received_at=None,
                    provider_parsed_at=None,
                    provider_usage={},
                )
            )

        def run(self, messages, call_index, **kwargs):
            self.next_call_index = call_index + 1
            calls.append(self.kind)
            import json

            packet = json.loads(messages[0]["content"][0]["text"])
            handle = packet["job_handle"]
            snap = registry.load(handle)["SNAPSHOT"]
            targets = list(snap["targets"])
            tools = NativeTools(
                HandleStore(registry, handle),
                phase=self.kind,
                compile_proposal=lambda snap, target, mapping, needs, config: compile_proposal(
                    None, snap, target, mapping, needs, config
                ),
            )
            # Use the actual native tool contracts, exact reads and compiler.
            for index, target in enumerate(targets):
                changes = {}
                if self.kind == "source" and index == 1:
                    changes = {
                        "transformation_classification": "complex",
                        "preprocessing_nl_rule": "Trim whitespace",
                    }
                if self.kind == "rule":
                    started.set()
                    changes = {
                        "transformation_classification": "complex",
                        "preprocessing_rule": 'TRIM(a."X47")',
                        "preprocessing_rule_type": "Custom",
                    }
                item = proposal(snap, target, **changes)
                read_required(tools, snap, target, item["mapping"]["source_attributes"])
                call(
                    tools,
                    snap,
                    "SubmitProposals",
                    {"proposals": {target: item}},
                    targets=[target],
                )
            if self.kind == "source":
                assert started.wait(
                    3
                ), "specialist should start while source run is still active"
                if source_failure:
                    raise RuntimeError(
                        "simulated source delivery failure after checkpoint"
                    )
            agent = (
                "AGT_SOURCE_MAPPING"
                if self.kind == "source"
                else "AGT_TRANSFORMATION_RULE"
            )
            return (
                encoded(
                    {"agent": agent, "status": "completed", "result": {"mappings": {}}}
                ),
                None,
                {},
            )

    monkeypatch.setattr(
        native,
        "_runtime",
        lambda *args, kind="source", **kwargs: (Runtime(kind), "test-spec"),
    )
    return builder, req, registry, calls


@pytest.mark.parametrize(
    "failure", [False, True], ids=["normal", "source-response-lost"]
)
def test_direct_checkpoint_and_early_rule_survive_unrelated_source_delivery_failure(
    monkeypatch, failure
):
    builder, req, registry, calls = setup(monkeypatch, source_failure=failure)
    response = asyncio.run(
        native.invoke_native(builder, req, governance_decision=SimpleNamespace())
    )
    assert calls == ["source", "rule"]
    assert response.result.mappings["NAME0"].source_attributes == ['a."X47"']
    assert response.result.mappings["NAME1"].preprocessing_rule == 'TRIM(a."X47")'
    assert not builder._agent.calls
    # A second dispatcher reads checkpoints instead of posting another run.
    recovered = asyncio.run(
        native.invoke_native(builder, req, governance_decision=SimpleNamespace())
    )
    assert recovered.result == response.result and calls == ["source", "rule"]


def test_checkpoints_survive_worker_finalization_acknowledgement_loss(monkeypatch):
    builder, req, registry, calls = setup(monkeypatch, finalization_failure=True)
    with pytest.raises(RuntimeError):
        asyncio.run(
            native.invoke_native(builder, req, governance_decision=SimpleNamespace())
        )
    recovered = native.recover_checkpoints(registry, req)
    assert recovered.result.mappings["NAME0"].source_attributes == ['a."X47"']
    assert recovered.result.mappings["NAME1"].preprocessing_rule == 'TRIM(a."X47")'
    assert calls == ["source", "rule"]
