from __future__ import annotations

import asyncio
import base64
import hashlib
import io
import json
import signal
import threading
import time
from collections.abc import AsyncIterator, Iterator, Sequence
from contextlib import contextmanager
from typing import Any

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.base import (
    BaseCheckpointSaver,
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
    get_checkpoint_id,
    get_checkpoint_metadata,
    WRITES_IDX_MAP,
)


class SnowflakeStageCheckpointSaver(BaseCheckpointSaver):
    """Store LangGraph payloads in an encrypted stage and compact refs in a table."""

    def __init__(
        self,
        session: Any,
        *,
        database: str = "",
        schema: str = "",
        stage: str = "WORKBENCH_AGENT_CHECKPOINTS",
        io_timeout_seconds: float = 30.0,
        assume_new_thread: bool = False,
        lease_fence: tuple[str, str, int] | None = None,
    ) -> None:
        super().__init__()
        self._session = session
        self._lease_fence = lease_fence
        prefix = ".".join(part for part in (database, schema) if part)
        self._table = f"{prefix + '.' if prefix else ''}TBL_AGENT_CHECKPOINT_REFS"
        self._writes_table = f"{prefix + '.' if prefix else ''}TBL_AGENT_CHECKPOINT_WRITES"
        self._fenced_write_procedure = f"{prefix + '.' if prefix else ''}SP_WRITE_AGENT_CHECKPOINT_FENCED"
        stage_name = stage.lstrip("@")
        self._stage = f"@{stage_name if '.' in stage_name else (prefix + '.' if prefix else '') + stage_name}"
        self._write_lock = threading.RLock()
        self._io_timeout_seconds = max(1.0, float(io_timeout_seconds))
        # A worker owns a durable thread lease exclusively. Keep the latest
        # committed package hot in that worker while still writing every
        # checkpoint to Snowflake for restart recovery.
        self._checkpoint_cache: dict[tuple[str, str, str], dict[str, Any]] = {}
        self._latest_cache: dict[tuple[str, str], str] = {}
        self._pending_cache: dict[
            tuple[str, str, str], list[tuple[str, str, Any]]
        ] = {}
        self._assume_new_thread = assume_new_thread
        self._initial_empty_checks: set[tuple[str, str]] = set()

    @contextmanager
    def _persist(self):
        with self._write_lock:
            try:
                yield
            except Exception:
                self._checkpoint_cache.clear()
                self._latest_cache.clear()
                self._pending_cache.clear()
                raise

    def _write_fenced(self, *, thread_id: str, kind: str, rows: list[dict[str, Any]]) -> None:
        """Persist one graph boundary and its lease check in one Snowflake call.

        The procedure wraps the MERGE and run-row fence in one short transaction.
        A stale worker receives an explicit rejection before any cache state is
        advanced. No client-side transaction is held across network calls.
        """
        from app.agent_runtime.execution import ExecutionLeaseLostError

        assert self._lease_fence is not None
        run_id, owner, generation = self._lease_fence
        # The supervisor and its compiled migration workflow use separate
        # LangGraph thread IDs under the same run lease. Reject unrelated
        # threads, but allow these host-owned child checkpoints to commit.
        if thread_id not in {run_id, f"{run_id}:supervisor", f"{run_id}:workflow"}:
            raise ExecutionLeaseLostError('Checkpoint thread does not match the worker lease')
        result = self._session.sql(
            f"CALL {self._fenced_write_procedure}(?, ?, ?, ?, PARSE_JSON(?))",
            [run_id, owner, generation, kind, json.dumps(rows, separators=(",", ":"), default=str)],
        ).collect()
        if not result:
            raise RuntimeError('Checkpoint procedure returned no write receipt')
        receipt = self._variant(next(iter(self._row(result[0]).values())))
        if not isinstance(receipt, dict):
            raise RuntimeError('Checkpoint procedure returned an invalid write receipt')
        if receipt.get('error') == 'worker_lease_lost':
            raise ExecutionLeaseLostError('Checkpoint write rejected by the durable lease fence')
        if receipt.get('error') or int(receipt.get('written') or 0) != len(rows):
            raise RuntimeError('Checkpoint procedure did not persist the complete write batch')

    @contextmanager
    def _io_deadline(self) -> Iterator[None]:
        """Bound blocking Snowflake stage reads in the synchronous worker.

        Snowpark's ``get_stream`` has no operation-level timeout. In SPCS the
        durable worker runs this saver on its process main thread, where a
        real-time signal safely interrupts a dead socket instead of leaving the
        lease alive forever. Async callers already execute on helper threads and
        retain the connector's own network timeout behavior.
        """
        if (
            threading.current_thread() is not threading.main_thread()
            or not hasattr(signal, "SIGALRM")
            or not hasattr(signal, "setitimer")
        ):
            yield
            return

        def timeout_handler(_signum: int, _frame: Any) -> None:
            raise TimeoutError(
                f"Snowflake checkpoint I/O exceeded {self._io_timeout_seconds:g} seconds"
            )

        previous_handler = signal.getsignal(signal.SIGALRM)
        previous_timer = signal.setitimer(signal.ITIMER_REAL, 0)
        started_at = time.monotonic()
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.setitimer(signal.ITIMER_REAL, self._io_timeout_seconds)
        try:
            yield
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous_handler)
            if previous_timer[0] > 0:
                remaining = max(0.001, previous_timer[0] - (time.monotonic() - started_at))
                signal.setitimer(signal.ITIMER_REAL, remaining, previous_timer[1])

    @staticmethod
    def _row(value: Any) -> dict[str, Any]:
        return value.as_dict() if hasattr(value, "as_dict") else dict(value)

    def _encode(self, value: Any) -> dict[str, str]:
        type_name, payload = self.serde.dumps_typed(value)
        return {"type": type_name, "data": base64.b64encode(payload).decode("ascii")}

    def _decode(self, value: dict[str, str]) -> Any:
        return self.serde.loads_typed((value["type"], base64.b64decode(value["data"])))

    @staticmethod
    def _variant(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        try:
            return json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return value

    @staticmethod
    def _package(value: dict[str, Any]) -> tuple[str, str, str]:
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(payload.encode()).hexdigest()
        return payload, digest, f"inline://{digest}"

    def _write(self, thread_id: str, checkpoint_id: str, package: dict[str, Any]) -> tuple[str, str]:
        payload = json.dumps(package, sort_keys=True, separators=(",", ":")).encode()
        digest = hashlib.sha256(payload).hexdigest()
        uri = f"{self._stage}/{thread_id}/{checkpoint_id}/{digest}.json"
        self._session.file.put_stream(io.BytesIO(payload), uri, auto_compress=False, overwrite=False)
        return uri, digest

    def _read(self, uri: str) -> dict[str, Any]:
        last_timeout: TimeoutError | None = None
        for attempt in range(2):
            stream: Any | None = None
            try:
                with self._io_deadline():
                    stream = self._session.file.get_stream(uri, decompress=False)
                    return json.loads(stream.read().decode())
            except TimeoutError as exc:
                last_timeout = exc
                if attempt == 1:
                    raise TimeoutError(
                        "Durable checkpoint restoration timed out after one retry"
                    ) from exc
            finally:
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        pass
        assert last_timeout is not None
        raise last_timeout

    def _rows(self, thread_id: str, namespace: str, checkpoint_id: str | None = None, *, limit: int | None = None) -> list[dict[str, Any]]:
        where = "THREAD_ID = ? AND CHECKPOINT_NS = ?"
        params: list[Any] = [thread_id, namespace]
        if checkpoint_id:
            where += " AND CHECKPOINT_ID = ?"
            params.append(checkpoint_id)
        sql = f"SELECT * FROM {self._table} WHERE {where} ORDER BY CHECKPOINT_ID DESC"
        if limit:
            sql += f" LIMIT {int(limit)}"
        return [self._row(row) for row in self._session.sql(sql, params).collect()]

    def _as_tuple(self, row: dict[str, Any]) -> CheckpointTuple:
        inline_payload = self._variant(row.get("PAYLOAD"))
        package = (
            inline_payload
            if isinstance(inline_payload, dict)
            else self._read(str(row["CHECKPOINT_URI"]))
        )
        thread_id, namespace, checkpoint_id = str(row["THREAD_ID"]), str(row.get("CHECKPOINT_NS") or ""), str(row["CHECKPOINT_ID"])
        config: RunnableConfig = {"configurable": {"thread_id": thread_id, "checkpoint_ns": namespace, "checkpoint_id": checkpoint_id}}
        parent_id = row.get("PARENT_CHECKPOINT_ID")
        parent = {"configurable": {"thread_id": thread_id, "checkpoint_ns": namespace, "checkpoint_id": str(parent_id)}} if parent_id else None
        pending_writes = [
            (str(item["task_id"]), str(item["channel"]), self._decode(item["value"]))
            for item in package.get("pending_writes", [])
        ]
        pending_writes.extend(
            self._pending_writes(thread_id, namespace, checkpoint_id)
        )
        return CheckpointTuple(
            config=config,
            checkpoint=self._decode(package["checkpoint"]),
            metadata=self._decode(package["metadata"]),
            parent_config=parent,
            pending_writes=pending_writes,
        )

    def _pending_writes(
        self,
        thread_id: str,
        namespace: str,
        checkpoint_id: str,
    ) -> list[tuple[str, str, Any]]:
        cache_key = (thread_id, namespace, checkpoint_id)
        with self._write_lock:
            cached = self._pending_cache.get(cache_key)
            if cached is not None:
                return list(cached)
        rows = self._session.sql(
            f"""SELECT TASK_ID, CHANNEL, VALUE_URI, VALUE_PAYLOAD
            FROM {self._writes_table}
            WHERE THREAD_ID=? AND CHECKPOINT_NS=? AND CHECKPOINT_ID=?
            ORDER BY TASK_ID, WRITE_INDEX""",
            [thread_id, namespace, checkpoint_id],
        ).collect()
        result: list[tuple[str, str, Any]] = []
        for value in rows:
            row = self._row(value)
            inline_payload = self._variant(row.get("VALUE_PAYLOAD"))
            package = (
                inline_payload
                if isinstance(inline_payload, dict)
                else self._read(str(row["VALUE_URI"]))
            )
            result.append(
                (
                    str(row["TASK_ID"]),
                    str(row["CHANNEL"]),
                    self._decode(package["value"]),
                )
            )
        with self._write_lock:
            self._pending_cache[cache_key] = list(result)
        return result

    def get_tuple(self, config: RunnableConfig) -> CheckpointTuple | None:
        values = config["configurable"]
        thread_id = str(values["thread_id"])
        namespace = str(values.get("checkpoint_ns") or "")
        checkpoint_id = get_checkpoint_id(config)
        empty_key = (thread_id, namespace)
        if self._assume_new_thread and not checkpoint_id and empty_key not in self._initial_empty_checks:
            # A freshly created run has a unique checkpoint namespace. Avoid a
            # guaranteed-empty Snowflake lookup on its first graph entry; all
            # later reads use the saver cache or durable store normally.
            self._initial_empty_checks.add(empty_key)
            return None
        with self._write_lock:
            if not checkpoint_id:
                checkpoint_id = self._latest_cache.get((thread_id, namespace))
            cached = (
                self._checkpoint_cache.get((thread_id, namespace, checkpoint_id))
                if checkpoint_id
                else None
            )
        if cached is not None:
            return self._as_tuple(dict(cached))
        rows = self._rows(thread_id, namespace, checkpoint_id, limit=1)
        if rows:
            row = rows[0]
            with self._write_lock:
                self._checkpoint_cache[(thread_id, namespace, str(row["CHECKPOINT_ID"]))] = dict(row)
                self._latest_cache[(thread_id, namespace)] = str(row["CHECKPOINT_ID"])
        return self._as_tuple(rows[0]) if rows else None

    def list(self, config: RunnableConfig | None, *, filter: dict[str, Any] | None = None, before: RunnableConfig | None = None, limit: int | None = None) -> Iterator[CheckpointTuple]:
        if config is None:
            raise ValueError("checkpoint listing requires a thread_id")
        values = config["configurable"]
        before_id = get_checkpoint_id(before) if before else None
        count = 0
        for row in self._rows(str(values["thread_id"]), str(values.get("checkpoint_ns") or "")):
            if before_id and str(row["CHECKPOINT_ID"]) >= before_id:
                continue
            item = self._as_tuple(row)
            if filter and any(item.metadata.get(key) != value for key, value in filter.items()):
                continue
            yield item
            count += 1
            if limit is not None and count >= limit:
                break

    def put(self, config: RunnableConfig, checkpoint: Checkpoint, metadata: CheckpointMetadata, new_versions: Any) -> RunnableConfig:
        del new_versions
        values = config["configurable"]
        thread_id, namespace = str(values["thread_id"]), str(values.get("checkpoint_ns") or "")
        checkpoint_id, parent_id = str(checkpoint["id"]), str(values.get("checkpoint_id") or "")
        effective_metadata = get_checkpoint_metadata(config, metadata)
        package = {"checkpoint": self._encode(checkpoint), "metadata": self._encode(effective_metadata), "pending_writes": []}
        payload_json, digest, uri = self._package(package)
        metadata_json = json.dumps(effective_metadata, default=str)
        with self._persist():
            if self._lease_fence:
                self._write_fenced(thread_id=thread_id, kind='REF', rows=[{
                    'thread_id': thread_id, 'namespace': namespace,
                    'checkpoint_id': checkpoint_id, 'parent_id': parent_id,
                    'uri': uri, 'content_hash': digest,
                    'metadata': effective_metadata, 'payload': package,
                }])
            else:
                self._session.sql(
                    f"""MERGE INTO {self._table} t USING (SELECT ? THREAD_ID, ? CHECKPOINT_NS, ? CHECKPOINT_ID) s
                    ON t.THREAD_ID=s.THREAD_ID AND t.CHECKPOINT_NS=s.CHECKPOINT_NS AND t.CHECKPOINT_ID=s.CHECKPOINT_ID
                    WHEN MATCHED THEN UPDATE SET PARENT_CHECKPOINT_ID=NULLIF(?, ''), CHECKPOINT_URI=?, CONTENT_HASH=?, METADATA=PARSE_JSON(?), PAYLOAD=PARSE_JSON(?)
                    WHEN NOT MATCHED THEN INSERT (RUN_ID, THREAD_ID, CHECKPOINT_NS, CHECKPOINT_ID, PARENT_CHECKPOINT_ID, CHECKPOINT_URI, CONTENT_HASH, METADATA, PAYLOAD)
                    VALUES (?, ?, ?, ?, NULLIF(?, ''), ?, ?, PARSE_JSON(?), PARSE_JSON(?))""",
                    [thread_id, namespace, checkpoint_id, parent_id, uri, digest, metadata_json, payload_json, thread_id, thread_id, namespace, checkpoint_id, parent_id, uri, digest, metadata_json, payload_json],
                ).collect()
            row = {
                "RUN_ID": thread_id,
                "THREAD_ID": thread_id,
                "CHECKPOINT_NS": namespace,
                "CHECKPOINT_ID": checkpoint_id,
                "PARENT_CHECKPOINT_ID": parent_id or None,
                "CHECKPOINT_URI": uri,
                "CONTENT_HASH": digest,
                "METADATA": effective_metadata,
                "PAYLOAD": package,
            }
            self._checkpoint_cache[(thread_id, namespace, checkpoint_id)] = row
            self._latest_cache[(thread_id, namespace)] = checkpoint_id
            # This saver just wrote the checkpoint, so every pending write for
            # it will also pass through put_writes here. Seeding the cache
            # avoids a guaranteed-empty SELECT on the next get_tuple.
            self._pending_cache.setdefault((thread_id, namespace, checkpoint_id), [])
        return {"configurable": {"thread_id": thread_id, "checkpoint_ns": namespace, "checkpoint_id": checkpoint_id}}

    def put_writes(self, config: RunnableConfig, writes: Sequence[tuple[str, Any]], task_id: str, task_path: str = "") -> None:
        values = config["configurable"]
        thread_id = str(values["thread_id"])
        namespace = str(values.get("checkpoint_ns") or "")
        checkpoint_id = str(values["checkpoint_id"])
        if not writes:
            return
        # LangGraph reserves one negative index per control channel. A single
        # resume may emit that channel more than once in the same batch; a
        # Snowflake MERGE with duplicate source keys fails instead of applying
        # the final value. Preserve the last write for each durable key.
        last_by_index: dict[int, tuple[int, str, Any]] = {}
        for ordinal, (channel, value) in enumerate(writes):
            last_by_index[WRITES_IDX_MAP.get(channel, ordinal)] = (ordinal, channel, value)
        unique_writes = sorted(
            ((write_index, *entry) for write_index, entry in last_by_index.items()),
            key=lambda entry: entry[1],
        )
        rows: list[tuple[str, int, str, Any, str, str, str]] = []
        params: list[Any] = []
        placeholders: list[str] = []
        for write_index, _ordinal, channel, value in unique_writes:
            package = {"value": self._encode(value)}
            payload_json, digest, uri = self._package(package)
            rows.append((task_id, write_index, channel, value, uri, digest, payload_json))
            placeholders.append("(?,?,?,?,?,?,?,?,?,?)")
            params.extend([
                thread_id, namespace, checkpoint_id, task_id, write_index,
                task_path, channel, uri, digest, payload_json,
            ])
        with self._persist():
            if self._lease_fence:
                self._write_fenced(thread_id=thread_id, kind='WRITES', rows=[{
                    'thread_id': thread_id, 'namespace': namespace,
                    'checkpoint_id': checkpoint_id, 'task_id': task,
                    'write_index': write_index,
                    'task_path': task_path, 'channel': channel,
                    'uri': uri, 'content_hash': digest,
                    'payload': json.loads(payload_json),
                } for task, write_index, channel, _value, uri, digest, payload_json in rows])
            else:
                self._session.sql(
                    f"""MERGE INTO {self._writes_table} t USING (
                        SELECT column1 THREAD_ID, column2 CHECKPOINT_NS, column3 CHECKPOINT_ID,
                               column4 TASK_ID, column5 WRITE_INDEX, column6 TASK_PATH,
                               column7 CHANNEL, column8 VALUE_URI, column9 CONTENT_HASH,
                               PARSE_JSON(column10) VALUE_PAYLOAD
                        FROM VALUES {', '.join(placeholders)}
                    ) s
                    ON t.THREAD_ID=s.THREAD_ID AND t.CHECKPOINT_NS=s.CHECKPOINT_NS
                       AND t.CHECKPOINT_ID=s.CHECKPOINT_ID AND t.TASK_ID=s.TASK_ID
                       AND t.WRITE_INDEX=s.WRITE_INDEX
                    WHEN MATCHED THEN UPDATE SET TASK_PATH=s.TASK_PATH, CHANNEL=s.CHANNEL,
                        VALUE_URI=s.VALUE_URI, CONTENT_HASH=s.CONTENT_HASH,
                        VALUE_PAYLOAD=s.VALUE_PAYLOAD, UPDATED_AT=CURRENT_TIMESTAMP()
                    WHEN NOT MATCHED THEN INSERT
                        (RUN_ID, THREAD_ID, CHECKPOINT_NS, CHECKPOINT_ID, TASK_ID, TASK_PATH,
                         WRITE_INDEX, CHANNEL, VALUE_URI, CONTENT_HASH, VALUE_PAYLOAD)
                    VALUES (s.THREAD_ID, s.THREAD_ID, s.CHECKPOINT_NS, s.CHECKPOINT_ID,
                        s.TASK_ID, s.TASK_PATH, s.WRITE_INDEX, s.CHANNEL, s.VALUE_URI,
                        s.CONTENT_HASH, s.VALUE_PAYLOAD)""",
                    params,
                ).collect()
            cache_key = (thread_id, namespace, checkpoint_id)
            cached = list(self._pending_cache.get(cache_key, []))
            replacements = {(task, channel) for task, _index, channel, *_ in rows}
            cached = [item for item in cached if (item[0], item[1]) not in replacements]
            cached.extend((task, channel, value) for task, _index, channel, value, *_ in rows)
            self._pending_cache[cache_key] = cached

    def delete_thread(self, thread_id: str) -> None:
        self._session.sql(f"DELETE FROM {self._writes_table} WHERE THREAD_ID=?", [thread_id]).collect()
        self._session.sql(f"DELETE FROM {self._table} WHERE THREAD_ID=?", [thread_id]).collect()
        with self._write_lock:
            self._checkpoint_cache = {
                key: value for key, value in self._checkpoint_cache.items()
                if key[0] != thread_id
            }
            self._latest_cache = {
                key: value for key, value in self._latest_cache.items()
                if key[0] != thread_id
            }
            self._pending_cache = {
                key: value for key, value in self._pending_cache.items()
                if key[0] != thread_id
            }

    async def aget_tuple(self, config: RunnableConfig) -> CheckpointTuple | None:
        return await asyncio.to_thread(self.get_tuple, config)

    async def alist(self, config: RunnableConfig | None, **kwargs: Any) -> AsyncIterator[CheckpointTuple]:
        for item in await asyncio.to_thread(lambda: list(self.list(config, **kwargs))):
            yield item

    async def aput(self, config: RunnableConfig, checkpoint: Checkpoint, metadata: CheckpointMetadata, new_versions: Any) -> RunnableConfig:
        return await asyncio.to_thread(self.put, config, checkpoint, metadata, new_versions)

    async def aput_writes(self, config: RunnableConfig, writes: Sequence[tuple[str, Any]], task_id: str, task_path: str = "") -> None:
        await asyncio.to_thread(self.put_writes, config, writes, task_id, task_path)

    async def adelete_thread(self, thread_id: str) -> None:
        await asyncio.to_thread(self.delete_thread, thread_id)
