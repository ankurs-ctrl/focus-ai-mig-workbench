from app.agent_runs.models import AgentActor, AssistantIntent, RunCreateRequest, RunStatus
from app.agent_runs.repository import InMemoryAgentRunRepository
from app.agent_runs.service import AgentRunService
from app.assistant_conversations import build_conversational_fast_answer, concise_chat_title, resolve_assistant_intent, is_read_only_document_question, is_read_only_sql_followup, is_explicit_migration_request, is_greeting_or_capability_question


def _failed_run():
    repository = InMemoryAgentRunRepository()
    run = AgentRunService(repository).create_run(
        RunCreateRequest(prompt="Create a mapping", conversation_id="conv-1"),
        AgentActor(user_id="user-1", tenant_id="tenant-1"),
    )
    run.status = RunStatus.FAILED
    return run


def test_new_chat_title_is_a_short_subject() -> None:
    assert concise_chat_title("Please create a new Evernest Household migration project. Use CONTACTS as the driving table.") == "Create Evernest Household migration project"
    assert concise_chat_title("Continue the existing migration draft using its saved sources. Generate the final SQL and show a bounded preview with sample results.") == "Complete mapping SQL and preview"
    assert concise_chat_title("   ") == "New chat"


def test_current_diagnostic_question_does_not_reactivate_old_mapping_plan() -> None:
    assert resolve_assistant_intent(
        "What was the error, and why were you not able to resolve it?",
        latest_run=_failed_run(),
    ) is AssistantIntent.RUN_DIAGNOSTIC


def test_only_explicit_continue_resumes_and_simple_question_stays_fast() -> None:
    run = _failed_run()
    assert resolve_assistant_intent("Please continue", latest_run=run) is AssistantIntent.CONTINUE_RUN
    assert resolve_assistant_intent("Why did you stop, keep going", latest_run=run) is AssistantIntent.CONTINUE_RUN
    assert resolve_assistant_intent("What does a household key mean?", latest_run=run) is AssistantIntent.CONVERSATIONAL_QA
    assert resolve_assistant_intent("What is a source-to-target mapping?", latest_run=run) is AssistantIntent.CONVERSATIONAL_QA
    assert resolve_assistant_intent("Explain source-to-target mapping", latest_run=run) is AssistantIntent.CONVERSATIONAL_QA
    assert resolve_assistant_intent("Create a mapping for household", latest_run=run) is AssistantIntent.NEW_MIGRATION_TASK


def test_proposed_sql_preview_is_a_read_only_durable_followup() -> None:
    run = _failed_run()
    message = "Before approving, execute the proposed SQL and give me the output"
    assert is_read_only_sql_followup(message, latest_run=run) is True
    assert resolve_assistant_intent(message, latest_run=run) is AssistantIntent.NEW_MIGRATION_TASK
    assert is_read_only_sql_followup("Create and save the draft STTM", latest_run=run) is False


def test_business_migration_plan_prompt_is_not_misrouted_as_target_glossary() -> None:
    message = (
        "Build the Evernest household migration using the best verified sources. "
        "First present an evidence-backed plan with proposed SQL. "
        "Do not create a draft before approval. Target table as Evernest_HH."
    )
    assert resolve_assistant_intent(message, latest_run=None) is AssistantIntent.NEW_MIGRATION_TASK


def test_deep_mode_routes_unfamiliar_natural_language_to_supervisor() -> None:
    assert resolve_assistant_intent(
        "I need the household information moved over and made usable for our CRM team.",
        latest_run=None,
        mode="deep",
    ) is AssistantIntent.NEW_MIGRATION_TASK
    assert resolve_assistant_intent(
        "What is a target table?", latest_run=None, mode="deep"
    ) is AssistantIntent.CONVERSATIONAL_QA
    assert resolve_assistant_intent(
        "What does a household key mean?", latest_run=None, mode="deep"
    ) is AssistantIntent.CONVERSATIONAL_QA


def test_workbench_glossary_questions_have_local_fast_answers() -> None:
    assert "destination structure" in (build_conversational_fast_answer("Explain what a target table is.") or "")
    assert "each target column" in (build_conversational_fast_answer("What is a source-to-target mapping?") or "")
    assert build_conversational_fast_answer("Summarize the current project") is None


def test_greetings_and_capability_questions_are_simple_questions_in_every_mode() -> None:
    for message in (
        "Hello what all can you do",
        "hi",
        "Hey there!",
        "What can you do?",
        "help",
        "Good morning, how can you help me?",
        "what are your capabilities",
        "Hello, what is a target table?",
    ):
        for mode in (None, "deep"):
            assert resolve_assistant_intent(message, latest_run=None, mode=mode) is AssistantIntent.CONVERSATIONAL_QA, (message, mode)
    assert is_greeting_or_capability_question("Hello what all can you do")
    assert not is_greeting_or_capability_question("Hello, what is a target table?")
    answer = build_conversational_fast_answer("Hello what all can you do") or ""
    # Generated from the capability registry: labels and risk groups, no fixed text or table names.
    from app.agent_tools.capability_registry import CapabilityRegistry
    assert CapabilityRegistry.BUSINESS_METADATA["search_precedents"]["business_label"] in answer
    assert "Research and answer (read-only)" in answer and "Create and validate run-owned drafts" in answer
    assert "AIA_WB_TARGET" not in answer
    assert "destination structure" in (build_conversational_fast_answer("Hello, what is a target table?") or "")


def test_greeting_does_not_hide_an_explicit_migration_request() -> None:
    for message in (
        "Hello, create a mapping for household",
        "Hi, build the Evernest household migration",
        "Hey can you map this table",
    ):
        assert resolve_assistant_intent(message, latest_run=None, mode="deep") is AssistantIntent.NEW_MIGRATION_TASK
        assert is_explicit_migration_request(message)
        assert not is_greeting_or_capability_question(message)
    assert not is_explicit_migration_request("I need the household information moved over.")


def test_uploaded_transcript_question_is_read_only_but_draft_request_is_not() -> None:
    prompt = "Use this call transcript as project evidence. Summarize the agreed mapping rules, identify what remains unresolved, and ask one focused question with options."
    assert is_read_only_document_question(prompt, has_attachments=True)
    assert not is_read_only_document_question(prompt, has_attachments=False)
    assert not is_read_only_document_question("Summarize it and create a mapping draft", has_attachments=True)
