"""Replay saved source decisions without agents, writes or population repairs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/sttm-builder"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", required=True)
    parser.add_argument("--job-id", required=True)
    args = parser.parse_args()
    from app.core.config import Settings
    from app.core.mapping_sql import MappingSqlService
    from app.core.snowflake import SnowflakeClient
    from app.core.sttm_builder import _normalize_source_mappings
    from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest

    client = SnowflakeClient(Settings(_env_file=args.env_file))
    try:
        rows = client.session.sql(
            "SELECT JOB_STATE:request_envelope AS REQUEST, "
            "JOB_STATE:partial_responses AS RESPONSES FROM "
            "FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA.TBL_AUTO_MAP_JOBS "
            "WHERE JOB_ID = ? LIMIT 1", params=[args.job_id],
        ).collect()
    finally:
        client.close()
    if not rows:
        raise ValueError("Saved job was not found")

    def decoded(value):
        return json.loads(value) if isinstance(value, str) else value

    from app.core.automap_stored_json import context_storage
    request = STTMBuilderEnvelopeRequest.model_validate(context_storage(decoded(rows[0]["REQUEST"]), restore=True))
    graph = request.context.relation_graph
    if graph is None:
        raise ValueError("Saved request has no compiler relation graph")
    workspace = request.context.workspace_context
    driver = workspace.driving_relation_id if workspace else None
    driver = driver or (request.context.driving_table.qualified_name if request.context.driving_table else None)
    target_types = {attribute.target_attribute.rsplit(".", 1)[-1]: attribute.target_data_type
                    for attribute in request.data.attributes or []}
    mappings = {}
    for partial in decoded(rows[0]["RESPONSES"]):
        response = partial["response"]
        result = response.get("result") or (response.get("data") or {}).get("result") or {}
        for target, mapping in _normalize_source_mappings(result).items():
            if target in mappings:
                raise ValueError("Duplicate target in saved partial responses")
            mappings[target] = mapping

    compiler = MappingSqlService(session=None, analyst_client=None)
    summaries, valid_items = [], []
    for target, mapping in sorted(mappings.items()):
        leaf = target.rsplit(".", 1)[-1]
        row = {"target": leaf, "source_count": len(mapping.source_attributes)}
        if mapping.mapping_mode == "source" and not mapping.source_attributes:
            row.update(status="no_source_binding", reason=mapping.unmatched_reason)
        else:
            rule_type = str(mapping.preprocessing_rule_type or "Direct")
            item = MappingSqlMappingItem(
                target_column=leaf, target_type=target_types.get(leaf),
                source_columns=mapping.source_attributes, source_dependencies=mapping.source_dependencies,
                mapping_mode=mapping.mapping_mode, constant_value=mapping.constant_value,
                attribute_name=mapping.attribute_name, value_binding_ids=mapping.value_binding_ids,
                rule=rule_type,
                expression=mapping.preprocessing_rule if rule_type.upper() not in
                    {"DIRECT", "IDENTITY", "CONSTANT", "LITERAL", "VALUE"} else None,
            )
            try:
                compiled = compiler.compile(MappingSqlCompileRequest(
                    relation_graph=graph, driving_relation_id=driver,
                    target_table=request.context.target_table, mappings=[item],
                    validate_with_explain=False, allow_unresolved_placeholders=True,
                ))
                row.update(status="compiler_ready" if compiled.ready else "compiler_not_ready",
                           warnings=compiled.warnings)
                if compiled.ready:
                    valid_items.append(item)
            except ValueError as exc:
                row.update(status="compiler_rejected", reason=str(exc))
        summaries.append(row)

    combined = compiler.compile(MappingSqlCompileRequest(
        relation_graph=graph, driving_relation_id=driver,
        target_table=request.context.target_table, mappings=valid_items,
        validate_with_explain=False, allow_unresolved_placeholders=True,
    )) if valid_items else None
    private = ROOT / ".dev-cache" / "automap-saved-validation" / args.job_id
    private.mkdir(parents=True, exist_ok=True)
    artifact = {"job_id": args.job_id, "driver": driver,
                "relation_graph": graph.model_dump(mode="json"),
                "saved_mappings": {key: value.model_dump(mode="json") for key, value in mappings.items()},
                "results": summaries, "compiled": combined.model_dump(mode="json") if combined else None}
    (private / "replay.json").write_text(json.dumps(artifact, indent=2), encoding="utf-8")
    print(json.dumps({"job_id": args.job_id, "targets": len(summaries),
                      "compiler_ready": len(valid_items), "graph_nodes": len(graph.nodes),
                      "graph_edges": len(graph.edges), "results": summaries,
                      "private_artifact": str(private / "replay.json"),
                      "limitations": "Saved source decisions only; no model, Snowflake SQL validation, mapping write or load."}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())