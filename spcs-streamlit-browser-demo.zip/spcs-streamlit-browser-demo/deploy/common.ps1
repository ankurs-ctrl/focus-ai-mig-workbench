Set-StrictMode -Version Latest

# Shared helper functions for all PowerShell deployment scripts in this bundle.
# The goal is to keep the user-facing scripts short and readable while reusing
# env parsing, path resolution, and Snow CLI invocation logic in one place.

function Get-BundleRoot {
    return Split-Path -Parent $PSScriptRoot
}

function Import-DemoEnv {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path $Path)) {
        throw "Env file not found: $Path"
    }

    $values = @{}
    foreach ($line in Get-Content $Path) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("#")) {
            continue
        }

        $parts = $trimmed -split "=", 2
        if ($parts.Count -ne 2) {
            continue
        }

        $key = $parts[0].Trim()
        $value = $parts[1].Trim()
        if (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'"))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        $values[$key] = $value
    }

    return $values
}

function Require-ConfigValues {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Config,
        [Parameter(Mandatory = $true)][string[]]$RequiredKeys,
        [Parameter(Mandatory = $true)][string]$EnvFile
    )

    foreach ($key in $RequiredKeys) {
        if (-not $Config.ContainsKey($key) -or [string]::IsNullOrWhiteSpace([string]$Config[$key])) {
            throw "$key must be set in $EnvFile"
        }
    }
}

function Resolve-Python {
    param([string]$Preferred = "")

    if ($Preferred) {
        if (Test-Path $Preferred) {
            return $Preferred
        }

        $preferredCommand = Get-Command $Preferred -ErrorAction SilentlyContinue
        if ($preferredCommand) {
            return $preferredCommand.Source
        }
    }

    foreach ($candidate in @("python", "python3", "py")) {
        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($command) {
            return $command.Source
        }
    }

    throw "Python 3.10+ is required but was not found in PATH."
}

function Get-ToolsVenvPath {
    return Join-Path (Get-BundleRoot) ".client-tools-venv"
}

function Get-SnowExePath {
    return Join-Path (Get-ToolsVenvPath) "Scripts\snow.exe"
}

function Ensure-SnowInstalled {
    $snowExe = Get-SnowExePath
    if (-not (Test-Path $snowExe)) {
        throw "Snow CLI was not found at $snowExe. Run .\deploy\bootstrap_client_spcs_tools.ps1 first."
    }
    return $snowExe
}

function Get-DefaultEnvFile {
    return Join-Path $PSScriptRoot "client.streamlit-demo.env"
}

function Set-EnvFromConfig {
    param([Parameter(Mandatory = $true)][hashtable]$Config)

    foreach ($entry in $Config.GetEnumerator()) {
        [System.Environment]::SetEnvironmentVariable($entry.Key, [string]$entry.Value, "Process")
    }
}

function Get-LowerValue {
    param([string]$Value)
    return $Value.ToLowerInvariant()
}

function Get-ImageTag {
    param([hashtable]$Config, [string]$Preferred = "")

    if ($Preferred) {
        return $Preferred
    }

    if ($Config.ContainsKey("IMAGE_TAG") -and -not [string]::IsNullOrWhiteSpace([string]$Config["IMAGE_TAG"])) {
        return [string]$Config["IMAGE_TAG"]
    }

    return Get-Date -Format "yyyyMMddHHmmss"
}

function Get-RemoteImage {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Config,
        [Parameter(Mandatory = $true)][string]$ImageTag
    )

    $dbLower = Get-LowerValue -Value $Config["SNOWFLAKE_DATABASE"]
    $schemaLower = Get-LowerValue -Value $Config["SNOWFLAKE_SCHEMA"]
    $repoLower = Get-LowerValue -Value $Config["SNOWFLAKE_IMAGE_REPOSITORY"]
    $imageName = if ($Config.ContainsKey("DOCKER_IMAGE_NAME") -and $Config["DOCKER_IMAGE_NAME"]) {
        [string]$Config["DOCKER_IMAGE_NAME"]
    } else {
        "spcs-streamlit-browser"
    }

    return "{0}/{1}/{2}/{3}/{4}:{5}" -f `
        $Config["SNOWFLAKE_REGISTRY_HOST"], `
        $dbLower, `
        $schemaLower, `
        $repoLower, `
        $imageName, `
        $ImageTag
}

function Get-RenderedSpecPath {
    param([string]$ImageTag)

    $artifactsDir = Join-Path (Get-BundleRoot) "artifacts"
    New-Item -ItemType Directory -Force -Path $artifactsDir | Out-Null
    return Join-Path $artifactsDir ("spcs-streamlit-browser.{0}.yaml" -f $ImageTag)
}

function Invoke-SnowSql {
    param(
        [Parameter(Mandatory = $true)][string]$SnowExe,
        [Parameter(Mandatory = $true)][string]$ConnectionName,
        [Parameter(Mandatory = $true)][string]$Sql
    )

    & $SnowExe sql -c $ConnectionName -q $Sql
}
