"""Real service, durable admission and HTTP transport; only Snowflake/HTTP are fake."""
import asyncio
from datetime import datetime, timedelta, timezone
import json
import time

import pytest

from tests.test_automap_fast_transport import harness as transport_harness
from tests.unit.core.test_automap_fast_batch import native_failure_builder, prepared_request
from tests.unit.core.test_automap_fast_context import fast_payload
from types import SimpleNamespace


def setup(harness, target_count=2, *, seconds=180):
    builder, models = native_failure_builder(harness)
    builder._with_semantic_context = lambda req: (req, None)
    builder._with_learning_context = lambda req: req
    builder._should_use_analyst = lambda *args: False
    builder._persist_response_artifact = lambda *args: None
    builder._postflight_guard = SimpleNamespace(finalize_sttm_response=lambda response, decision: response)
    value = fast_payload(target_count)
    value["meta"]["auto_map_deadline_at"] = (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()
    req = prepared_request(value)
    selected = {f"NAME{index}": {"source_attributes": ["a.X47"], "source_dependencies": ["a.X47"],
        "confidence_score": .9, "preprocessing_rule_type": "Custom", "transformation_classification": "complex"}
        for index in range(target_count)}
    source = json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": selected}}})
    return builder, models, req, source


def rules(*targets, evidence=None, citation_field="learning_evidence"):
    return json.dumps({"agent": "AGT_TRANSFORMATION_RULE", "data": {"result": {"rules": [
        {"target_attribute": target, "rule": "TRIM(a.X47)", "source_dependencies": ["a.X47"],
         citation_field: evidence or []} for target in targets]}}})


@pytest.mark.parametrize("failure", ["timeout", "lost_ack"])
def test_native_specialist_shares_runtime_accounting_archive_and_partial_repair(transport_harness, failure):
    h = transport_harness
    builder, models, req, source = setup(h)
    specialist_posts = []
    def hook(outgoing):
        if "AGT_SOURCE_MAPPING" in outgoing.url.path:
            h.state.answer = source
        else:
            specialist_posts.append(outgoing)
            h.state.answer = rules("NAME0")
            if len(specialist_posts) == 2:
                # Lost response acknowledgement: no retry, permit stays held.
                h.state.mode = failure
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert len(models) == 1 and len(h.state.models) == 3
    assert final.result.mappings["NAME0"].preprocessing_rule == "TRIM(a.X47)"
    assert final.result.mappings["NAME0"].transformation_classification == "complex"
    assert final.result.mappings["NAME1"].transformation_classification == "unresolved"
    assert final.result.mappings["NAME1"].source_attributes == ["a.X47"]
    assert sum(slot["STATE"] in {"HELD", "QUARANTINED"} for slot in h.database.slots) == 1
    assert final.meta["transformation_stage"]["total_model_calls"] == 3
    requests = [models[0].request_for(index) for index in (1, 2, 3)]
    assert len({request.deadline for request in requests}) == 1
    assert len({request.shard_id for request in requests}) == 3
    assert "_auto_map_execution" not in final.model_dump_json()


@pytest.mark.parametrize("provider", ["in_progress", "tool_result", "suggested_queries"])
def test_specialist_enforces_terminal_content_contract(transport_harness, provider):
    h = transport_harness
    builder, models, req, source = setup(h, 1)
    def hook(outgoing):
        if "AGT_SOURCE_MAPPING" in outgoing.url.path:
            h.state.answer = source
            return
        content = [{"type": "text", "text": rules("NAME0")}]
        if provider == "tool_result":
            content.append({"type": "tool_result", "content": "do not accept"})
        elif provider == "suggested_queries":
            content.append({"type": "suggested_queries", "suggested_queries": [{"query": ""}]})
        h.state.provider_response = {"role": "assistant", "status": "in_progress" if provider == "in_progress" else "completed",
                                     "content": content}
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings["NAME0"].transformation_classification == (
        "complex" if provider == "suggested_queries" else "unresolved")
    assert len(h.state.models) == 2
    assert sum(slot["STATE"] in {"HELD", "QUARANTINED"} for slot in h.database.slots) == (provider == "in_progress")


@pytest.mark.parametrize("expire_on", [1, 2])
def test_deadline_expiring_inside_initial_or_repair_keeps_only_previously_validated_rules(
        transport_harness, monkeypatch, expire_on):
    h = transport_harness
    builder, models, req, source = setup(h, seconds=30)
    posts = []
    monotonic = time.monotonic
    def hook(outgoing):
        if "AGT_SOURCE_MAPPING" in outgoing.url.path:
            h.state.answer = source
            return
        posts.append(outgoing)
        assert 0 < outgoing.extensions["timeout"]["read"] <= 10
        h.state.answer = rules("NAME0", "NAME1") if len(posts) == expire_on else rules("NAME0")
        if len(posts) == expire_on:
            monkeypatch.setattr(time, "monotonic", lambda: monotonic() + 90)
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert len(posts) == expire_on
    assert final.result.mappings["NAME1"].transformation_classification == "unresolved"
    assert final.result.mappings["NAME0"].transformation_classification == ("complex" if expire_on == 2 else "unresolved")


@pytest.mark.parametrize("evidence", ["invented", "negative1"])
@pytest.mark.parametrize("citation_field", ["learning_evidence", "used_inference_ids", "used_recommendation_ids", "override_evidence"])
def test_specialist_fabricated_or_other_target_citations_never_become_grounded(transport_harness, evidence, citation_field):
    h = transport_harness
    builder, models, req, source = setup(h)
    def hook(outgoing):
        h.state.answer = source if "AGT_SOURCE_MAPPING" in outgoing.url.path else rules(
            "NAME1", evidence=[evidence], citation_field=citation_field)
    h.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert final.result.mappings["NAME1"].transformation_classification == "unresolved"
    assert evidence not in final.result.mappings["NAME1"].used_learning_ids
    assert len(h.state.models) == 3  # source, initial, one focused repair
