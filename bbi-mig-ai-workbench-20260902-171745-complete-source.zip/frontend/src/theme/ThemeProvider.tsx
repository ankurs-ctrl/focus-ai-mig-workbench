'use client';

import type { ReactNode } from 'react';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { CacheProvider } from '@emotion/react';
import { createEmotionCache } from '@/theme/emotionCache';
import { getAppTheme, type AppThemeMode } from './theme';

const clientSideEmotionCache = createEmotionCache();

type AppThemeProviderProps = {
  children: ReactNode;
  mode?: AppThemeMode;
};

export default function AppThemeProvider({
  children,
  mode = 'light',
}: AppThemeProviderProps) {
  return (
    <CacheProvider value={clientSideEmotionCache}>
      <MuiThemeProvider theme={getAppTheme(mode)}>
        <CssBaseline />
        {children}
      </MuiThemeProvider>
    </CacheProvider>
  );
}
