'use client';

import { AiaBox, AiaTableCellPrimitive, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { InfoOutlinedIcon } from '@/utils/icons';
import type { SxProps, Theme } from '@mui/material/styles';
import type { ReactNode } from 'react';

import { businessReviewText } from '../mapping-review-model';
import {
  getConfidenceGroup,
  isSavedManualMapping,
  MANUAL_CONFIDENCE_PERCENT,
  normalizeConfidencePercent,
} from '../mapping-confidence-groups';

type MappingConfidenceCellProps = {
  confidenceScore?: number | null;
  status?: import('../../types/sttm.types').MappingStatus;
  reason?: string | null;
  businessMeaning?: string | null;
  manuallyEditedAfterAutoMap?: boolean;
  /** Saved manual mapping — shown as 100% with the Manual label. */
  manuallySaved?: boolean;
  /** Edited by the user but not saved yet — shown as 100% with the Edited label. */
  pendingManualEdit?: boolean;
  width?: number | string;
  minWidth?: number | string;
  sx?: SxProps<Theme>;
};

const BAND_COLORS = {
  high: { text: '#166534', bar: '#22c55e', track: '#dcfce7' },
  medium: { text: '#92400e', bar: '#f59e0b', track: '#fef3c7' },
  low: { text: '#b91c1c', bar: '#ef4444', track: '#fee2e2' },
  unmapped: { text: '#475569', bar: '#94a3b8', track: '#e2e8f0' },
} as const;

function buildTooltipContent({
  confidenceScore,
  reason,
  businessMeaning,
  manuallyEditedAfterAutoMap,
  manualSaved,
  manualEditing,
}: {
  confidenceScore: number | null | undefined;
  reason?: string | null;
  businessMeaning?: string | null;
  manuallyEditedAfterAutoMap?: boolean;
  manualSaved: boolean;
  manualEditing: boolean;
}): ReactNode {
  if (
    confidenceScore == null
    && !reason
    && !businessMeaning
    && !manuallyEditedAfterAutoMap
    && !manualSaved
    && !manualEditing
  ) {
    return null;
  }

  const band =
    manualSaved
      ? 'Manual mapping (high confidence)'
      : manualEditing
        ? 'Manual edit (100%)'
        : confidenceScore == null
          ? null
          : (() => {
              const percent = normalizeConfidencePercent(confidenceScore);
              if (percent == null) return null;
              if (percent >= 80) return 'High confidence';
              if (percent >= 60) return 'Medium confidence';
              return 'Low confidence';
            })();

  return (
    <AiaBox sx={{ display: 'grid', gap: 0.7, whiteSpace: 'normal', overflowWrap: 'anywhere' }}>
      {band ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit', fontWeight: 800 }}>
          {band}
        </AiaText>
      ) : null}
      {manualSaved ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Manual:</strong> Saved by the user, so confidence is 100%.
        </AiaText>
      ) : null}
      {manualEditing ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Manual:</strong> Edited by the user. The row stays in its current group until you Save, then moves to High confidence.
        </AiaText>
      ) : null}
      {manuallyEditedAfterAutoMap && !manualSaved && !manualEditing ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Manual:</strong> Edited locally. Original confidence is kept until Save.
        </AiaText>
      ) : null}
      {businessMeaning ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Business fit:</strong> {businessMeaning}
        </AiaText>
      ) : null}
      {/* The AI's reasoning doesn't describe a mapping the user made by hand. */}
      {reason && !manualSaved && !manualEditing ? (
        <AiaText sx={{ fontSize: 'inherit', lineHeight: 'inherit' }}>
          <strong>Why:</strong> {reason}
        </AiaText>
      ) : null}
    </AiaBox>
  );
}

export function MappingConfidenceCell({
  confidenceScore,
  status,
  reason,
  businessMeaning,
  manuallyEditedAfterAutoMap = false,
  manuallySaved = false,
  pendingManualEdit = false,
  width,
  minWidth,
  sx,
}: MappingConfidenceCellProps) {
  const hasMapping = status != null && status !== 'UNMAPPED';
  const manualEditing = pendingManualEdit && hasMapping;
  const manualSaved = !pendingManualEdit && isSavedManualMapping({ manuallySaved, status });
  const percent = manualSaved || manualEditing
    ? MANUAL_CONFIDENCE_PERCENT
    : normalizeConfidencePercent(confidenceScore);
  const group = getConfidenceGroup(percent);
  const colors = BAND_COLORS[group];
  const tooltipContent = buildTooltipContent({
    confidenceScore,
    reason: businessReviewText(reason),
    businessMeaning: businessReviewText(businessMeaning),
    manuallyEditedAfterAutoMap,
    manualSaved,
    manualEditing,
  });
  const showEditedTag = manualEditing || (manuallyEditedAfterAutoMap && !manualSaved);

  return (
    <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx })}>
      {percent == null ? null : (
        <AiaBox
          data-tour={TOUR_TARGETS.sttmConfidenceScore}
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            gap: 0.6,
            minWidth: 0,
            width: '100%',
          }}
        >
          <AiaBox sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: 0.5, flexWrap: 'wrap' }}>
            <AiaText
              sx={{
                fontSize: '0.75rem',
                fontWeight: 800,
                color: colors.text,
                lineHeight: 1.2,
                textAlign: 'left',
              }}
            >
              {`${Math.round(percent)}%`}
            </AiaText>
            {manualSaved ? (
              <AiaText
                component="span"
                sx={{
                  fontSize: '0.72rem',
                  fontWeight: 800,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                  color: colors.text,
                  bgcolor: colors.track,
                  borderRadius: '4px',
                  px: 0.7,
                  py: 0.25,
                  lineHeight: 1.3,
                }}
              >
                Manual
              </AiaText>
            ) : null}
            {showEditedTag ? (
              <AiaText
                component="span"
                sx={{
                  fontSize: '0.62rem',
                  fontWeight: 700,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                  color: '#475569',
                  bgcolor: '#e2e8f0',
                  borderRadius: '4px',
                  px: 0.55,
                  py: 0.15,
                  lineHeight: 1.3,
                }}
              >
                Edited
              </AiaText>
            ) : null}
            {tooltipContent ? (
              <AiaTooltip
                title={tooltipContent}
                placement="top"
                arrow
                enterDelay={200}
                slotProps={{
                  tooltip: {
                    sx: {
                      fontSize: '0.72rem',
                      maxWidth: 360,
                      lineHeight: 1.5,
                    },
                  },
                }}
              >
                <InfoOutlinedIcon sx={{ fontSize: 15, color: '#64748b', cursor: 'help' }} />
              </AiaTooltip>
            ) : null}
          </AiaBox>
          <AiaBox
            sx={{
              width: '100%',
              height: 6,
              borderRadius: 999,
              bgcolor: colors.track,
              overflow: 'hidden',
            }}
          >
            <AiaBox
              sx={{
                width: `${percent}%`,
                height: '100%',
                borderRadius: 999,
                bgcolor: colors.bar,
                transition: 'width 160ms ease',
              }}
            />
          </AiaBox>
        </AiaBox>
      )}
    </AiaTableCellPrimitive>
  );
}
