const assert=require('node:assert/strict');
const test=require('node:test');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
function harness(){
  let scope='caller:one';const calls=[];
  const module={exports:{}};
  const code=ts.transpileModule(fs.readFileSync(path.resolve(__dirname,'../src/services/preparedContextService.ts'),'utf8'),
    {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
  const requireMock=name=>({
    '@/services/authService':{getAuthenticatedReadScope:()=>scope},
    '@/api/routes':{API_ROUTES:{workbench:{contextPrepare:'/prepare'}}},
    '@/api/axiosInstance':{buildApiEnvelope:(operation,data)=>({operation,data}),postEnvelopeData:(url,payload)=>{
      let resolve;const promise=new Promise(done=>resolve=done);calls.push({payload,resolve});return promise;
    }},
  })[name];
  Function('require','module','exports',code)(requireMock,module,module.exports);
  return {service:module.exports.preparedContextService,calls,setScope:value=>scope=value};
}
const workspace={project_id:'p',sttm_id:'m',source_tables:[{database:'D',schema:'S',table:'A'}],
  target_table:{database:'D',schema:'T',table:'B'},mapping_rows:[{target_column:'ID',target_type:'NUMBER'}]};
test('page and click preparation share one request despite metadata and UI hydration',async()=>{
  const h=harness();const a=h.service.prepare({workspace});
  const b=h.service.prepare({workspace:{...workspace,semantic:{bundle_id:'arrived'},context_hash:'arrived',
    checked_mapping_row_ids:['ID'],validation_history:[{result:'new'}],compiled_mapping_sql:'SELECT generated',
    mapping_rows:[{...workspace.mapping_rows[0],source_columns:['a.ID'],confidence:.9}]}});
  assert.equal(a,b);assert.equal(h.calls.length,1);
  h.calls[0].resolve({workspace_context_id:'prepared'});await a;
  const c=h.service.prepare({workspace});assert.equal(h.calls.length,2);h.calls[1].resolve({});await c;
});
test('authored change and changed caller never share preparation',async()=>{
  const h=harness();const a=h.service.prepare({workspace});
  const b=h.service.prepare({workspace:{...workspace,raw_mapping_sql:'SELECT changed'}});
  h.setScope('caller:two');const c=h.service.prepare({workspace});
  assert.equal(h.calls.length,3);assert.notEqual(a,b);assert.notEqual(a,c);
  h.calls.forEach(call=>call.resolve({}));await Promise.all([a,b,c]);
});
test('unknown caller scope cannot coalesce requests',async()=>{
  const h=harness();h.setScope(null);const a=h.service.prepare({workspace}),b=h.service.prepare({workspace});
  assert.equal(h.calls.length,2);h.calls.forEach(call=>call.resolve({}));await Promise.all([a,b]);
});
