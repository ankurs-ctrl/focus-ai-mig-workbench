const AUTO_PAIRS: Record<string, string> = {
  '(': ')',
  '[': ']',
  "'": "'",
  '"': '"',
};

const CLOSERS = new Set(Object.values(AUTO_PAIRS));
const QUOTES = new Set(["'", '"']);

/** Auto-closing only kicks in before whitespace, a closer, or the end of the line. */
const SAFE_NEXT_CHAR = /[\s)\]},;]/;
const IDENTIFIER_CHAR = /[A-Za-z0-9_$]/;

export type SqlAutoPairEdit = {
  /** Range of the current value replaced by `insertText`. */
  replaceStart: number;
  replaceEnd: number;
  insertText: string;
  /** Caret / selection once the edit is applied. */
  selectionStart: number;
  selectionEnd: number;
};

function countChar(text: string, char: string) {
  let total = 0;
  for (const current of text) {
    if (current === char) total += 1;
  }
  return total;
}

function hasUnmatchedOpener(before: string, opener: string, closer: string) {
  let depth = 0;
  for (const char of before) {
    if (char === opener) depth += 1;
    else if (char === closer && depth > 0) depth -= 1;
  }
  return depth > 0;
}

function moveCaret(position: number): SqlAutoPairEdit {
  return {
    replaceStart: position,
    replaceEnd: position,
    insertText: '',
    selectionStart: position,
    selectionEnd: position,
  };
}

export function isAutoPairNoop(edit: SqlAutoPairEdit) {
  return edit.replaceStart === edit.replaceEnd && !edit.insertText;
}

/**
 * Resolves the Snowflake-style auto-pairing edit for a keystroke, or `null`
 * when the key should fall through to the browser's default handling.
 */
export function resolveSqlAutoPair(
  value: string,
  selectionStart: number,
  selectionEnd: number,
  key: string,
): SqlAutoPairEdit | null {
  const before = value.slice(0, selectionStart);
  const after = value.slice(selectionEnd);
  const selected = value.slice(selectionStart, selectionEnd);
  const hasSelection = selectionStart !== selectionEnd;

  // Backspace inside an empty pair removes both halves.
  if (key === 'Backspace') {
    if (hasSelection || selectionStart === 0) return null;
    const opener = value[selectionStart - 1];
    const closer = AUTO_PAIRS[opener];
    if (!closer || value[selectionStart] !== closer) return null;
    return {
      replaceStart: selectionStart - 1,
      replaceEnd: selectionStart + 1,
      insertText: '',
      selectionStart: selectionStart - 1,
      selectionEnd: selectionStart - 1,
    };
  }

  // Typing the closing half right before an auto-inserted one steps over it.
  if (!hasSelection && CLOSERS.has(key) && after.startsWith(key)) {
    if (QUOTES.has(key)) {
      if (countChar(before, key) % 2 === 1) return moveCaret(selectionStart + 1);
    } else {
      const opener = Object.keys(AUTO_PAIRS).find((item) => AUTO_PAIRS[item] === key);
      if (opener && hasUnmatchedOpener(before, opener, key)) {
        return moveCaret(selectionStart + 1);
      }
    }
  }

  const closer = AUTO_PAIRS[key];
  if (!closer) return null;

  // Typing an opener with text selected wraps that selection instead.
  if (hasSelection) {
    return {
      replaceStart: selectionStart,
      replaceEnd: selectionEnd,
      insertText: `${key}${selected}${closer}`,
      selectionStart: selectionStart + 1,
      selectionEnd: selectionStart + 1 + selected.length,
    };
  }

  const nextChar = after.charAt(0);
  if (nextChar && !SAFE_NEXT_CHAR.test(nextChar)) return null;

  if (QUOTES.has(key)) {
    // Never auto-close a quote glued to an identifier or closing an open string.
    const previousChar = before.slice(-1);
    if (previousChar && IDENTIFIER_CHAR.test(previousChar)) return null;
    if (countChar(before, key) % 2 === 1) return null;
  }

  return {
    replaceStart: selectionStart,
    replaceEnd: selectionStart,
    insertText: `${key}${closer}`,
    selectionStart: selectionStart + 1,
    selectionEnd: selectionStart + 1,
  };
}
