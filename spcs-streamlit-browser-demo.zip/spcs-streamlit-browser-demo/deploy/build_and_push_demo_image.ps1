param(
    [string]$EnvFile = "",
    [string]$ImageTag = "",
    [switch]$SkipLogin
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

if (-not $EnvFile) {
    $EnvFile = Get-DefaultEnvFile
}

$snowExe = Ensure-SnowInstalled
$cfg = Import-DemoEnv -Path $EnvFile

Require-ConfigValues -Config $cfg -RequiredKeys @(
    "SNOWFLAKE_CONNECTION",
    "SNOWFLAKE_DATABASE",
    "SNOWFLAKE_SCHEMA",
    "SNOWFLAKE_REGISTRY_HOST",
    "SNOWFLAKE_IMAGE_REPOSITORY"
) -EnvFile $EnvFile

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker is required but was not found in PATH."
}

$bundleRoot = Get-BundleRoot
$resolvedImageTag = Get-ImageTag -Config $cfg -Preferred $ImageTag
$remoteImage = Get-RemoteImage -Config $cfg -ImageTag $resolvedImageTag
$localImage = if ($cfg.ContainsKey("LOCAL_DOCKER_IMAGE_NAME") -and $cfg["LOCAL_DOCKER_IMAGE_NAME"]) {
    [string]$cfg["LOCAL_DOCKER_IMAGE_NAME"]
} else {
    "spcs-streamlit-browser:local"
}

Write-Host "Testing Snow CLI connection '$($cfg["SNOWFLAKE_CONNECTION"])'"
& $snowExe connection test -c $cfg["SNOWFLAKE_CONNECTION"]

if (-not $SkipLogin) {
    Write-Host ""
    Write-Host "Logging Docker into Snowflake image registry"
    & $snowExe spcs image-registry login -c $cfg["SNOWFLAKE_CONNECTION"]
}

Write-Host ""
Write-Host "Building Docker image $localImage"
docker build --platform linux/amd64 -t $localImage $bundleRoot

Write-Host ""
Write-Host "Tagging $localImage -> $remoteImage"
docker tag $localImage $remoteImage

Write-Host ""
Write-Host "Pushing $remoteImage"
docker push $remoteImage

Write-Host ""
Write-Host "Image push complete."
Write-Host "Remote image: $remoteImage"
