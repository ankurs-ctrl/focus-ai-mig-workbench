const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const file = path.resolve(__dirname, '../src/features/ai-agent/deep-agent-panel.tsx');
test('page and sidebar findings share formatted review components instead of a JSON pane', () => {
  const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let review;
  function walk(node) {
    if (ts.isJsxAttribute(node) && node.name.getText(source) === 'reviewContent') review = node;
    ts.forEachChild(node, walk);
  }
  walk(source);
  assert.ok(review);
  const content = review.getText(source);
  assert.match(content, /AgentReviewTable/);
  assert.match(content, /AgentReviewList/);
  assert.doesNotMatch(content, /JSON\.stringify|component="pre"/);
});
test('working steps remain in chat activity and the artifact pane requires a generated plan', () => {
  const source = fs.readFileSync(file, 'utf8');
  assert.match(source, /<MigrationPlanRows event=\{event\}/);
  assert.match(source, /planContent=\{planDocument \? <>/);
  assert.doesNotMatch(source, /workingPlanOpenedRef|displayedPlan/);
  assert.match(source, /row\.mapping_key \|\| row\.sttm_id/);
});

test('dismissing the plan hides the entire chat card while preserving the approval controls', () => {
  const source = fs.readFileSync(file, 'utf8');
  assert.match(source, /\{planDocument && showPlanPreview \? \(\s*<AiaPaper[^>]+data-testid="chat-plan-artifact"/);
  assert.match(source, /aria-label="Dismiss plan preview"[^\n]+setDismissedPlanKey\(planKey\)/);
  assert.match(source, /\{planDocument && migrationAgentState\.pendingPermission\?\.tool === 'approve_migration_plan'/);
});

test('implementation dismisses the chat preview and closes the Plan sidebar only after acknowledgement', async () => {
  const vm = require('node:vm');
  const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let submit;
  function visit(node) {
    if (ts.isVariableDeclaration(node) && node.name.getText(source) === 'submitQuestionAnswer') {
      submit = node.initializer.arguments[0].getText(source);
    }
    ts.forEachChild(node, visit);
  }
  visit(source);
  assert.ok(submit);

  for (const scenario of ['accepted', 'rejected', 'results-open']) {
    let acknowledge;
    const actions = [];
    const client = { answerReviewDecision: () => new Promise((resolve, reject) => {
      acknowledge = () => scenario === 'rejected' ? reject(new Error('Answer rejected')) : resolve();
    }) };
    const context = {
      migrationAgentState: { pendingPermission: { tool: 'approve_migration_plan', permission_id: 'approval' } },
      migrationAgentClientRef: { current: client },
      reviewAnswerInFlight: { current: false },
      planKey: 'plan-1',
      artifactTab: scenario === 'results-open' ? 'results' : 'plan',
      setReviewDecisionBusy() {}, setMigrationAgentMessages() {}, setOtherAnswer() {}, setOtherAnswerOpen() {},
      setReviewDecisionError: error => { if (error) actions.push('error'); },
      setDismissedPlanKey: key => actions.push(key),
      setPlanSidebarOpen: open => actions.push(open),
    };
    const handler = vm.runInNewContext(ts.transpileModule(`(${submit})`, {
      compilerOptions: { target: ts.ScriptTarget.ES2022 },
    }).outputText, context);
    const saving = handler('approve', null, 'Implement plan');
    assert.deepEqual(actions, []);
    acknowledge();
    await saving;
    assert.deepEqual(actions, scenario === 'rejected' ? ['error'] : scenario === 'results-open' ? ['plan-1'] : ['plan-1', false]);
  }
});
