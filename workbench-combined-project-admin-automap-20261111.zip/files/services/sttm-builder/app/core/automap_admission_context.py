"""One binding/evidence admission contract for rendering, validation and recovery.

Preview receipts are local size projections only. They never mark the exact-read
ledger or appear on the wire; workers must hydrate the selected operations first.
"""
from copy import deepcopy
from dataclasses import dataclass

from sqlglot.errors import ParseError, TokenError

from app.core.automap_retrieval import digest, encoded


@dataclass(frozen=True)
class BindingAdmission:
    record_id: str
    source_ref: str
    relation_id: str


class CandidateAdmissionError(ValueError):
    def __init__(self, code, references=()):
        self.code = code
        self.references = tuple(references)
        super().__init__({
            "unadmitted_binding": "Existing source binding needs exact evidence admission and reevaluation",
            "unknown_binding": "Source binding does not exist in the current selectable graph",
            "ambiguous_binding": "Source binding is ambiguous across current table instances",
            "out_of_scope_binding": "Source exists upstream but is not an exposed selectable output in the current graph",
            "missing_selected_sources": "A transformation needs selected source bindings",
            "invalid_expression": "Transformation requires one valid scalar expression",
            "malformed_reference": "Source reference is not one qualified SQL column",
        }[code])


class AdmissionContext:
    def admitted_records(self):
        ids = set(self.pinned)
        for group in self.selected:
            ids.update(self.groups[group])
        return [self.records[identity] for identity in sorted(ids)]

    def admitted_sources(self):
        return [record for record in self.admitted_records()
                if record.kind == "source_column" and record.body.get("eligible") is True
                and (record.body.get('binding') or {}).get('relation_id') not in getattr(self, 'unproved_derived', set())
                and (self._preview_mode or self.source_evidence_ready(record.record_id))]

    def binding_admissions(self):
        return tuple(BindingAdmission(card.record_id,
            f'{card.body["binding"]["sql_qualifier"]}.{card.body["column"]}',
            card.body["binding"]["relation_id"]) for card in self.admitted_sources())

    def _pin_operations(self, operations):
        # A typed column read may pin only verified graph cards, never every
        # source mentioned by a table/contract/dependency metadata read.
        for operation in operations:
            if operation.get("operation") not in {"column", "profile"}:
                continue
            relation, column = operation["relation"], operation["column"]
            try:
                owners = set(self.store._relations(relation))
            except ValueError:
                continue
            for card in self.prepared.records:
                body = card.body
                if card.kind not in {"source_column", "lineage_column", "target_column"}:
                    continue
                if body.get("relation") not in owners:
                    continue
                binding = body.get("binding")
                # Metadata can naturally have no outer source binding. A typed
                # node read must never pin its unbound parent/target card.
                if relation in self.store.nodes and (not isinstance(binding, dict)
                        or binding.get("relation_id") != relation):
                    continue
                owner = body["relation"]
                if (self.store._column_name(owner, body["column"]) is not None
                        and self.store._column_name(owner, body["column"]) == self.store._column_name(owner, column)):
                    self.pinned.add(card.record_id)

    def _close_pins(self):
        for identity in tuple(self.pinned):
            owner = self.records[identity].body.get("owner_ref")
            if owner in self.record_group:
                self.selected.add(self.record_group[owner])
        self._close_groups()

    def selection_operations(self):
        operations = list(self.base_operations)
        for card in self.admitted_records():
            body = card.body
            if card.kind in {"source_column", "lineage_column", "target_column"}:
                if (self.blocks.enabled and card.record_id not in self.required_pins | self.requested_pins
                        and not self.source_evidence_ready(card.record_id)):
                    continue
                relation = body["relation"]
                names = {body["name"]}
                canonical = self.store._column_name(relation, body["column"])
                if canonical is not None:
                    names.add(canonical)
                operations.extend({"operation": "column", "relation": relation, "column": name}
                                  for name in sorted(names) if name in self.store.columns.get(relation, {}))
            elif body.get("relation") in self.store.contracts:
                operations.append({"operation": "contract", "relation": body["relation"]})
        # Dependencies appended by closure are still compulsory and exact.
        operations.extend(item for item in self.read_operations if item["operation"] == "dependency")
        return list({encoded(item): item for item in operations}.values())

    def projected_results(self, operations):
        if not hasattr(self, "_preview_store"):
            self._preview_store = deepcopy(self.store)
        results = []
        for operation in operations:
            key = encoded(operation)
            if key not in self._preview_cache:
                if operation["operation"] == "discover":
                    target = operation["target"]
                    discovered = self.store.discovered.get(target) or {}
                    result = {"operation": "discover", "target": target, "complete": True,
                        "data": {"diagnostics": discovered.get("diagnostics"),
                                 "source_candidates": discovered.get("source_candidates", {})}}
                else:
                    identity, value = self._preview_store._value(operation)
                    result = {"operation": identity[0], "identity": list(identity[1:]),
                              "content_hash": digest(value), "complete": True, "data": deepcopy(value)}
                self._preview_cache[key] = {"read_key": key, "request": deepcopy(operation), "result": result}
            results.append(self._preview_cache[key])
        return results

    def packet_results(self, results, targets=None):
        # Completed reads remain in the backend ledger/archive, but optional
        # receipts rotate with their cards. Never equate archived with shown.
        operations = {encoded(item) for item in self.selection_operations()}
        return [item for item in results if encoded(item.get("request", {})) in operations
                and (targets is None or item.get("request", {}).get("operation") not in {"discover", "evidence"}
                     or item["request"].get("target") in targets)]

    def _preview_fits(self, *, targets=None, missing=None, issues=(), allow_blocks=True):
        self._close_pins()
        self.read_operations = self.selection_operations()
        self._refresh_allowed()
        self._refresh_coverage()
        receipts = self.projected_results(self.read_operations)
        self._preview_mode = True
        try:
            messages = self._render(receipts, targets=targets, missing=missing, issues=issues)
            if allow_blocks and not self._fits(messages):
                self.blocks.enabled = True
                messages = self._render(receipts, targets=targets, missing=missing, issues=issues)
                while not self._fits(messages) and self.blocks.threshold > 512:
                    self.blocks.threshold //= 2
                    messages = self._render(receipts, targets=targets, missing=missing, issues=issues)
        finally:
            self._preview_mode = False
        from app.core.automap_input_budget import wire_text
        text = wire_text(messages)
        fits = self._fits(messages)
        self.admission_events.append({"stage": "packing", "target_count": len(targets or self.store.targets),
            "source_count": len(self.binding_admissions()), "chars": len(text),
            "bytes": len(text.encode("utf-8")), "accepted": fits})
        return fits

    def admission_state(self):
        return (set(self.selected), set(self.pinned), list(self.read_operations), set(self.required_pins), list(self.base_operations), set(self.requested_pins), self.blocks.enabled, self.blocks.threshold)

    def restore_admission(self, state):
        (self.selected, self.pinned, self.read_operations, self.required_pins, self.base_operations,
         self.requested_pins, self.blocks.enabled, self.blocks.threshold) = state
        self._refresh_allowed()
        self._refresh_coverage()

    def mark_dispatched(self, targets=None):
        ids = {card.record_id for card in self.admitted_sources()}
        for target in targets or self.store.targets:
            self.shown[target].update(ids)
        self._refresh_coverage()

    def _replace_optional(self, ids, *, targets=None, missing=None, issues=(), allow_blocks=True):
        self.selected = set(self.required_groups)
        self.pinned = set(self.required_pins) | set(ids)
        self.read_operations = list(self.base_operations)
        return self._preview_fits(targets=targets, missing=missing, issues=issues, allow_blocks=allow_blocks)

    def recover_references(self, references, *, targets, missing=None, issues=()):
        from app.core.automap_fast_context import _reference_key
        ids = set(self.required_pins) | set(self.requested_pins)
        for reference in references:
            try:
                cards = self.eligible_by_ref.get(_reference_key(reference), ())
            except (ValueError, ParseError, TokenError):
                raise CandidateAdmissionError("malformed_reference") from None
            if len(cards) != 1:
                raise CandidateAdmissionError("unknown_binding")
            ids.add(cards[0].record_id)
        before = self.admission_state()
        if not self._replace_optional(ids, targets=targets, missing=missing, issues=issues):
            self.restore_admission(before)
            return False, []
        # Candidate dependencies become pinned constraints for subsequent calls.
        self.requested_pins.update(ids)
        self.read_operations = self.selection_operations()
        return True, list(self.read_operations)

    def _advance_pages(self, targets, results, *, missing=None, issues=()):
        # Select unseen individual cards from ranked pages; a page larger than
        # the remaining room can be consumed in bounded portions. The cursor
        # remains until every eligible member has actually been dispatched.
        choices = {}
        for target in targets:
            choices[target] = [identity for identity in self.column_rankings[target]
                               if identity not in self.shown[target]]
        before = self.admission_state()
        for count in ((1,) if self.blocks.enabled else (8, 4, 2, 1)):
            self.restore_admission(before)
            ids = {identity for values in choices.values() for identity in values[:count]}
            if not ids:
                break
            if self._replace_optional(ids, targets=targets, missing=missing, issues=issues):
                self.requested_pins = set(ids)
                self.read_operations = self.selection_operations()
                pages = sorted({self.record_group[identity] for identity in ids})
                return pages, list(self.read_operations)
        accepted = self.fit_fallback(choices, targets=targets, missing=missing, issues=issues)
        if accepted:
            self.requested_pins = set(accepted)
            self.read_operations = self.selection_operations()
            return sorted({self.record_group[identity] for identity in accepted}), list(self.read_operations)
        self.restore_admission(before)
        return [], []

    def fit_fallback(self, choices, *, targets=None, missing=None, issues=()):
        """Skip a genuinely oversized optional winner, keeping usable evidence."""
        self._replace_optional(set(), targets=targets, missing=missing, issues=issues)
        accepted = set()
        for target, ranked in choices.items():
            for identity in ranked:
                self._check_deadline()
                before = self.admission_state()
                if self._replace_optional(accepted | {identity}, targets=targets, missing=missing, issues=issues):
                    accepted.add(identity)
                    break
                self.oversized_optional_groups.add(self.record_group[identity])
                self.restore_admission(before)
        return accepted

    def admission_manifest(self):
        admitted = {record.record_id for record in self.admitted_records()}
        eligible = set(self.inventory_ids)
        return {target: [{"group": group, "rank": rank,
            "score": self.ranking_scores[target].get(group, 0),
            "eligible_members": len(set(self.groups[group]) & eligible),
            "admitted_members": len(set(self.groups[group]) & admitted & eligible),
            "shown_members": len(set(self.groups[group]) & self.shown[target]),
            "status": "admitted_or_partial" if set(self.groups[group]) & admitted & eligible
                else "optional_members_exceeded_budget" if group in self.oversized_optional_groups
                else "outside_bounded_shortlist_not_absence"}
            for rank, group in enumerate(groups)] for target, groups in self.rankings.items()}

    def source_evidence_roots(self, identity):
        card = self.records[identity]
        roots = set(self.blocks.record_roots.get(identity, ()))
        owner = card.body.get("owner_ref")
        group = self.record_group.get(owner)
        for member in self.groups.get(group, ()):
            roots.update(self.blocks.record_roots.get(member, ()))
        return roots

    def source_evidence_ready(self, identity):
        if (self.records[identity].body.get('binding') or {}).get('relation_id') in getattr(self, 'unproved_derived', set()):
            return False
        if not self.blocks.enabled:
            return True
        # Resolve the exact projection locally without claiming a model read.
        if identity not in self.blocks.record_roots:
            self.blocks.record(self.records[identity])
        owner = self.records[identity].body.get("owner_ref")
        for member in self.groups.get(self.record_group.get(owner), ()):
            if member not in self.blocks.record_roots:
                self.blocks.record(self.records[member])
        return not self.blocks.pending_for_roots(self.source_evidence_roots(identity))

    def required_pending_blocks(self):
        roots = set(self.global_evidence_roots)
        required_records = set(self.required_pins) | set(self.requested_pins)
        required_records.update(identity for group in self.required_groups for identity in self.groups[group])
        for identity in required_records & self.rendered_record_ids:
            roots.update(self.source_evidence_roots(identity))
        return self.blocks.pending_for_roots(roots)

    def request_optional_evidence_roots(self, references, roots):
        """Promote only graph-owned optional roots explicitly requested by model.

        A root ID is not authority to read unrelated archived data. Resolve all
        bindings first, then check the entire request before mutating admission.
        """
        from app.core.automap_fast_context import _reference_key
        allowed = set(self.global_evidence_roots)
        for reference in references:
            try:
                cards = self.eligible_by_ref.get(_reference_key(reference), ())
            except (ValueError, ParseError, TokenError):
                return False
            if len(cards) != 1:
                return False
            allowed.update(self.source_evidence_roots(cards[0].record_id))
        if (type(roots) is not list or len(roots) > 32 or any(type(root) is not str for root in roots)
                or not set(roots) <= allowed):
            return False
        self.blocks.required_roots.update(roots)
        return True

    def refresh_packed_evidence(self, packet):
        """Bind read obligations to surviving typed references, not trial archives."""
        context = packet.get('context') or {}
        cards = context.get('table_records') or []
        for card in cards:
            self.blocks.record_roots[card['record_id']] = self.blocks.referenced_roots(card)
        # Graph root IDs are an index, not authority to keep a removed body alive.
        self.global_evidence_roots = self.blocks.referenced_roots({
            'context': {key: value for key, value in context.items()
                        if key not in {'table_records', 'evidence_graph'}},
            'data': packet.get('data'),
            'retrieved_auto_map_context': packet.get('retrieved_auto_map_context')})
        roots = self.global_evidence_roots | self.blocks.referenced_roots(cards)
        self.blocks.active = {identity for root in roots for identity in self.blocks.roots[root]}
        if 'selectable_sources' in context:
            selectable = [{"record_id": item.record_id, "source_ref": item.source_ref,
                           "data_type": self.records[item.record_id].body.get("data_type")}
                          for item in self.binding_admissions() if item.record_id in self.rendered_record_ids]
            by_record = {item['record_id']: item for item in selectable}
            context['selectable_sources'] = selectable
            for card in cards:
                if card['kind'] != 'source_column':
                    continue
                if card['record_id'] in by_record:
                    card['body']['eligible'] = True
                    card['body'].pop('admission_status', None)
                elif self.records[card['record_id']].body.get('eligible') is True:
                    card['body'].pop('eligible', None)
                    card['body']['admission_status'] = 'requires_evidence_read'
            for target in context.get('target_candidates', {}):
                context['target_candidates'][target] = [
                    {**by_record[identity], 'rank_reason': self.candidate_reasons[target][identity]}
                    for identity in self.column_rankings[target] if identity in by_record]
            from app.core.automap_citations import source_record_id
            context['citation_ids'] = sorted(set(context.get('citation_ids', ()))
                | {'src:' + item['source_ref'] for item in selectable}
                | {source_record_id(item['source_ref']) for item in selectable})
            self._refresh_allowed()
        context['evidence_graph'] = self.evidence_graph()
        pending = set(self.blocks.pending)
        context['auto_map_retrieval']['evidence_block_coverage'] = {
            'active_blocks': len(self.blocks.active),
            'reviewed_blocks': len(self.blocks.active & self.blocks.reviews.keys()),
            'pending_blocks': len(pending),
            'optional_unread_blocks': len(self.blocks.active - self.blocks.reviews.keys() - pending),
            'review_only': bool(roots & self.blocks.required_roots)}

    def evidence_read_manifest(self):
        """Size required block calls without issuing a model call or marking reads."""
        from app.core.automap_input_budget import wire_text
        measured = {}
        while True:
            pending = [identity for identity in self.required_pending_blocks() if identity not in measured]
            if not pending:
                break
            for identity in pending:
                self._check_deadline()
                message = self.blocks.request(identity)
                if message is not None:
                    text = wire_text(message)
                    measured[identity] = (len(text), len(text.encode('utf-8')))
        from app.core.automap_evidence_blocks import MAX_EVIDENCE_REVIEW_CALLS
        required_calls = len(measured)
        return {"required_block_calls": required_calls,
            "max_evidence_review_calls": MAX_EVIDENCE_REVIEW_CALLS,
            "format_repair_calls_available": min(1, max(0, MAX_EVIDENCE_REVIEW_CALLS - required_calls)) if required_calls else 0,
            "evidence_review_feasible": required_calls <= MAX_EVIDENCE_REVIEW_CALLS,
            "max_block_message_chars": max((size[0] for size in measured.values()), default=0),
            "max_block_message_bytes": max((size[1] for size in measured.values()), default=0),
            "model_calls": 0, "evidence_review_completed": False}

    def evidence_graph(self):
        nodes = []
        for record in self.admitted_records():
            if record.kind != "source_column" or record.body.get("eligible") is not True:
                continue
            body = record.body
            roots = sorted(self.source_evidence_roots(record.record_id))
            nodes.append({"node_id": record.record_id,
                "source_ref": f'{body["binding"]["sql_qualifier"]}.{body["column"]}',
                "owner_node": body.get("owner_ref"), "evidence_roots": roots,
                "evidence_state": "admitted_for_this_call" if self.source_evidence_ready(record.record_id) else "requires_read"})
        # Topology is an index, never a second copy of SQL or a grant of
        # source eligibility. Exact join predicates remain in source_graph.
        graph = (self.store.original.get("context") or {}).get("relation_graph") or {}
        visible_relations = {(record.body.get("binding") or {}).get("relation_id")
            for record in self.admitted_records() if record.kind == "source_column"}
        graph_records = [record.record_id for record in self.prepared.global_records
            if record.kind == "source_graph"]
        relationships = [{"edge_id": edge.get("edge_id"),
            "left_relation_id": edge.get("left_relation_id"),
            "right_relation_id": edge.get("right_relation_id"),
            "join_type": edge.get("join_type"), "evidence_record_ids": graph_records}
            for edge in graph.get("edges") or []
            if edge.get("left_relation_id") in visible_relations
                or edge.get("right_relation_id") in visible_relations]
        return {"snapshot_hash": self.snapshot,
            "relationship_edges": relationships,
            "targets": {target: {"candidate_nodes": [identity for identity in self.column_rankings[target]
                if identity in self.pinned]} for target in self.store.targets},
            "source_nodes": nodes,
            "mandatory_evidence_roots": sorted(self.global_evidence_roots & self.blocks.required_roots),
            "optional_evidence_roots": sorted(self.global_evidence_roots - self.blocks.required_roots),
            "read_contract": "Request exact source_refs through meta.evidence_requests. Each source connects to its owner, "
                "join dependencies, and exact evidence blocks. Unread nodes do not authorize a mapping.",
            "evidence_nodes": [{"root_id": root, "block_count": len(self.blocks.roots[root]),
                "reviewed_count": sum(identity in self.blocks.reviews for identity in self.blocks.roots[root]),
                "required_for_mapping": root in self.blocks.required_roots,
                "purposes": sorted({context['purpose'] for context in self.blocks.root_contexts.get(root, [])})}
                for root in sorted({root for node in nodes for root in node["evidence_roots"]} | self.global_evidence_roots)]}
