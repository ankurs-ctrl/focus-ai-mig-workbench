from types import SimpleNamespace

import pytest
from pydantic import ValidationError

from app.core.automap_row_candidates import validate_row_candidates
from app.schema.sttm_builder import (AttributeMapping, MappingCandidate, SourceMappingResult,
    STTMBuilderEnvelopeRequest, STTMBuilderResponse, STTMStatus, SubAgent)


def request():
    return STTMBuilderEnvelopeRequest.model_validate({
        'operation': 'sttm.auto_map', 'data': {'intent': 'AUTO_MAP', 'attributes': [{
            'target_table': {'database': 'D', 'schema': 'OUT', 'table': 'TARGET'}, 'target_attribute': 'NAME', 'target_data_type': 'VARCHAR'}]},
        'context': {'relation_graph': {'nodes': [{'relation_id': 'D.S.T', 'alias': 'src', 'kind': 'PHYSICAL_TABLE',
            'table': {'database': 'D', 'schema': 'S', 'table': 'T'},
            'output_columns': [{'name': 'NAME', 'data_type': 'VARCHAR'}, {'name': 'OTHER', 'data_type': 'VARCHAR'}]}]}}})


def option(source='src.NAME', confidence=.4, **changes):
    return dict(source_attributes=[source], source_dependencies=[source], confidence_score=confidence,
                confidence_reason=f'Evidence for {source}', preprocessing_rule_type='Direct',
                transformation_classification='direct') | changes


class ExplainSession:
    def __init__(self): self.queries = []
    def sql(self, text):
        assert text.startswith('EXPLAIN USING TEXT ')
        self.queries.append(text)
        if 'UNKNOWN_FUNCTION' in text:
            raise ValueError('Invalid function')
        return SimpleNamespace(collect=lambda: [])


def validate(primary=None, alternatives=(), req=None, warnings=()):
    req = req or request()
    mapping = AttributeMapping.model_validate({**(primary or option()), 'candidates': list(alternatives)})
    result = SourceMappingResult(mappings={'NAME': mapping})
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=result, message=None, status=STTMStatus.COMPLETED, warnings=list(warnings))
    session = ExplainSession()
    result = validate_row_candidates(SimpleNamespace(_query_session=session), req, response)
    assert result.result == result.data.result
    return result.result.mappings['NAME'], session


@pytest.mark.parametrize('score', [None, 0.0, .91])
def test_draft_contract_round_trip_is_distinct_and_does_not_invent_confidence(score):
    candidate = MappingCandidate.model_validate({**option(), 'candidate_id': 'draft',
        'original_confidence_score': score, 'adjusted_confidence_score': None if score is None else min(score, .49),
        'scoring_policy_version': 'draft-v1', 'validation_status': 'invalid',
        'scoring_issues': [{'code': 'missing_value', 'category': 'value', 'severity': 'error',
                            'message': 'Current-project $FIRM is unresolved.'}]})
    mapping = AttributeMapping.model_validate({**option(), 'candidates': [candidate],
        'selected_candidate_id': None, 'draft_candidate_id': 'draft'})
    restored = AttributeMapping.model_validate_json(mapping.model_dump_json())
    assert restored == mapping
    assert restored.selected_candidate_id is None and restored.draft_candidate_id == 'draft'
    assert restored.candidates[0].original_confidence_score == score
    assert restored.candidates[0].scoring_issues[0].category == 'value'
    legacy = MappingCandidate.model_validate(option())
    assert legacy.original_confidence_score is None and legacy.adjusted_confidence_score is None
    assert legacy.scoring_policy_version is None and legacy.scoring_issues == []
    assert legacy.confidence_score == .4  # The legacy score is not reinterpreted.
    assert AttributeMapping.model_validate(option()).draft_candidate_id is None


@pytest.mark.parametrize('field', ['original_confidence_score', 'adjusted_confidence_score'])
@pytest.mark.parametrize('score', [-.01, 1.01, float('nan'), float('inf')])
def test_draft_confidence_contract_rejects_invalid_scores(field, score):
    with pytest.raises(ValidationError):
        MappingCandidate.model_validate({**option(), field: score})


@pytest.mark.parametrize('issue', [
    {'code': 'bad', 'message': 'Invalid category', 'category': 'unknown', 'severity': 'error'},
    {'code': 'bad', 'message': 'Invalid severity', 'category': 'value', 'severity': 'unknown'},
    {'code': 'bad', 'category': 'value', 'severity': 'error'},
])
def test_draft_scoring_issues_are_structured(issue):
    with pytest.raises(ValidationError):
        MappingCandidate.model_validate({**option(), 'scoring_issues': [issue]})


@pytest.mark.parametrize('name,value,data_type,expression,literal', [
    ('Disabled', False, 'BOOLEAN', 'IFF($Disabled, src.NAME, src.OTHER)', 'FALSE'),
    ('Zero', 0, 'NUMBER', 'LENGTH(src.NAME) + $Zero', '0'),
    ('Empty', '', 'VARCHAR', 'COALESCE(src.NAME, $Empty)', "''"),
])
@pytest.mark.parametrize('whole_target', [True, False])
def test_falsy_project_values_validate_and_compile_without_literal_agent_bindings(
        name, value, data_type, expression, literal, whole_target):
    from app.core.mapping_sql import MappingSqlService
    from app.core.automap_transform import expression_within_selection, transformation_packet
    from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
    from app.schema.sttm_builder import TransformationRule
    req = request()
    req.context.project_id = 'current-project'
    req.data.attributes[0].target_data_type = data_type if whole_target else None
    req.context.relation_graph = MappingSqlService.with_project_values(req.context.relation_graph, [
        SimpleNamespace(attribute_name=name, attribute_type=data_type, attribute_value=value)])
    binding = req.context.relation_graph.value_bindings[0]
    sources = [] if whole_target else ['src.NAME', 'src.OTHER']
    proposal = option(source_attributes=sources, source_dependencies=sources,
        mapping_mode='attribute' if whole_target else 'source', attribute_name=name if whole_target else None,
        constant_value='$' + name if whole_target else None, value_binding_ids=[binding.binding_id],
        preprocessing_rule=None if whole_target else expression,
        preprocessing_rule_type='Value' if whole_target else 'Custom',
        transformation_classification='value' if whole_target else 'complex')
    mapping, session = validate(proposal, req=req)
    assert mapping.selected_candidate_id and mapping.candidates[0].validation_status == 'valid'
    assert mapping.mapping_mode == ('attribute' if whole_target else 'source')
    assert mapping.value_binding_ids == ['$' + name]
    assert len(session.queries) == (0 if whole_target else 1)
    compiled = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=req.context.relation_graph, driving_relation_id='D.S.T', validate_with_explain=False,
        allow_unresolved_placeholders=False, mappings=[MappingSqlMappingItem(target_column='NAME',
            target_type=req.data.attributes[0].target_data_type, source_columns=sources, source_dependencies=sources,
            mapping_mode=mapping.mapping_mode, constant_value=mapping.constant_value, attribute_name=mapping.attribute_name,
            value_binding_ids=mapping.value_binding_ids, expression=None if whole_target else expression,
            rule='Value' if whole_target else 'Custom')]))
    assert compiled.valid and compiled.ready and not compiled.unresolved_placeholders
    assert '$' + name not in compiled.preview_sql and literal in compiled.preview_sql
    raw = req.model_dump(mode='json', exclude_none=True)
    raw['data']['attributes'][0]['selected_mapping'] = proposal
    specialist = transformation_packet(raw, factor=False)
    assert specialist['context']['relation_graph']['value_bindings'][0]['value'] == '$' + name
    assert 'resolved_value' not in specialist['context']['relation_graph']['value_bindings'][0]
    if not whole_target:
        assert expression_within_selection(raw, mapping, TransformationRule(target_attribute='NAME',
            rule=expression, source_dependencies=sources, value_binding_ids=[binding.binding_id]))
        assert not expression_within_selection(raw, mapping, TransformationRule(target_attribute='NAME',
            rule=expression.replace('$' + name, '$Foreign'), source_dependencies=sources, value_binding_ids=['foreign']))


@pytest.mark.parametrize('changes', [
    {'constant_value': '$OTHER'}, {'attribute_name': 'OTHER'}, {'value_binding_ids': ['foreign-id']},
])
def test_whole_target_value_rejects_mismatched_current_project_binding(changes):
    from app.core.mapping_sql import MappingSqlService
    req = request()
    req.context.relation_graph = MappingSqlService.with_project_values(req.context.relation_graph, [
        SimpleNamespace(attribute_name='FIRM', attribute_type='VARCHAR', attribute_value='private-current')])
    proposal = option(source_attributes=[], source_dependencies=[], mapping_mode='attribute',
        attribute_name='FIRM', constant_value='$FIRM', value_binding_ids=['project-FIRM'],
        preprocessing_rule_type='Value', transformation_classification='value') | changes
    mapping, _ = validate(proposal, req=req)
    assert mapping.selected_candidate_id is None
    assert 'must agree' in ' '.join(mapping.candidates[0].validation_errors)


def revalidate(mapping, req=None, session=None):
    req = req or request()
    result = SourceMappingResult(mappings={'NAME': mapping})
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=result, message=None, status=STTMStatus.COMPLETED)
    return validate_row_candidates(SimpleNamespace(_query_session=session), req, response)


def test_adjusted_ranking_preserves_original_across_roundtrip_and_dedup():
    mapping, _ = validate(option('src.MISSING', .99), [option('src.OTHER', .6)])
    assert [item.adjusted_confidence_score for item in mapping.candidates] == [.6, .49]
    assert [item.original_confidence_score for item in mapping.candidates] == [.6, .99]
    assert mapping.draft_candidate_id == mapping.selected_candidate_id == mapping.candidates[0].candidate_id
    restored = AttributeMapping.model_validate_json(mapping.model_dump_json())
    second = revalidate(restored).result.mappings['NAME']
    assert second == mapping
    assert second.candidates[1].scoring_issues[0].category == 'source'


def test_unknown_original_remains_unknown_even_with_legacy_zero_on_reopen():
    from app.core.sttm_builder import _normalize_source_mappings
    mapping = _normalize_source_mappings({'mappings': {'NAME': option(confidence_score=None)}})['NAME']
    first = revalidate(mapping).result.mappings['NAME']
    assert first.candidates[0].original_confidence_score is None
    assert first.candidates[0].adjusted_confidence_score is None
    restored = AttributeMapping.model_validate_json(first.model_dump_json())
    assert revalidate(restored).result.mappings['NAME'] == first


@pytest.mark.parametrize('score', [.2, .99])
def test_caps_use_strongest_issue_and_never_raise_original(score):
    from app.core.automap_row_candidates import score_candidate
    from app.schema.sttm_builder import CandidateScoringIssue
    candidate = MappingCandidate(**option(confidence=score), original_confidence_score=score)
    issues = [CandidateScoringIssue(code=category, category=category, message=category, severity=severity)
              for category, severity in [('evidence', 'warning'), ('validation', 'error'), ('sql', 'error')]]
    first = score_candidate(candidate, issues * 2)
    assert first.adjusted_confidence_score == min(score, .49)
    assert len(first.scoring_issues) == 3
    assert score_candidate(first, issues) == first
    assert score_candidate(first, []).adjusted_confidence_score == score


def test_incomplete_sql_validation_is_not_claimed_valid_and_reason_cap_is_separate():
    mapping = AttributeMapping(**option(confidence=.96, preprocessing_rule='TRIM(src.NAME)',
        preprocessing_rule_type='Custom'))
    first = revalidate(mapping).result.mappings['NAME']
    assert first.candidates[0].adjusted_confidence_score == .69
    assert first.candidates[0].validation_status == 'unvalidated'
    assert first.selected_candidate_id is None and first.draft_candidate_id
    corrected = revalidate(first, session=ExplainSession()).result.mappings['NAME']
    assert corrected.candidates[0].validation_status == 'valid'
    assert corrected.candidates[0].adjusted_confidence_score == .96
    assert not corrected.candidates[0].scoring_issues
    weak, _ = validate(option(confidence=.96, confidence_reason=None))
    assert weak.candidates[0].adjusted_confidence_score == .79
    assert weak.candidates[0].validation_status == 'valid'


def test_resolved_value_removes_old_blocker_without_compounding_penalties():
    from app.core.mapping_sql import MappingSqlService
    req = request()
    mapping, _ = validate(option(confidence=.95, preprocessing_rule='COALESCE(src.NAME, $FIRM)',
        preprocessing_rule_type='Custom'), req=req)
    assert mapping.candidates[0].adjusted_confidence_score == .49
    assert any(item.category == 'value' for item in mapping.candidates[0].scoring_issues)
    req.context.relation_graph = MappingSqlService.with_project_values(req.context.relation_graph, [
        SimpleNamespace(attribute_name='FIRM', attribute_type='VARCHAR', attribute_value='')])
    fixed = revalidate(mapping, req, ExplainSession()).result.mappings['NAME']
    assert fixed.candidates[0].adjusted_confidence_score == .95
    assert not fixed.candidates[0].scoring_issues and not fixed.candidates[0].validation_errors
    assert fixed.selected_candidate_id == fixed.draft_candidate_id


@pytest.mark.parametrize('sources', ['[{', [{'bad': 'object'}], {}, False, 0, None, ''])
@pytest.mark.parametrize('field', ['source_attributes', 'sources'])
@pytest.mark.parametrize('other_field', [False, True])
@pytest.mark.parametrize('rule_alias', [False, True])
@pytest.mark.parametrize('list_envelope', [False, True])
def test_malformed_source_diagnostic_and_cap_survive_repeated_json_validation(sources, field, other_field, rule_alias, list_envelope):
    from app.core.sttm_builder import _normalize_source_mappings
    raw = dict(confidence_score=.99, confidence_reason='Corresponding name', preprocessing_rule='TRIM(src.NAME)', preprocessing_rule_type='Custom')
    if other_field:
        raw['sources' if field == 'source_attributes' else 'source_attributes'] = ['src.NAME']
    raw[field] = sources
    if rule_alias:
        raw['rule'] = raw.pop('preprocessing_rule')
        raw['rule_type'] = raw.pop('preprocessing_rule_type')
    body = [{'target': 'NAME', **raw}] if list_envelope else {'NAME': raw}
    mapping = _normalize_source_mappings({'mappings': body})['NAME']
    first = None
    for _ in range(3):
        mapping = revalidate(mapping, session=ExplainSession()).result.mappings['NAME']
        candidate = mapping.candidates[0]
        assert candidate.source_attributes == []
        assert candidate.original_confidence_score == .99
        assert candidate.adjusted_confidence_score == .49
        assert candidate.validation_status == 'invalid'
        assert mapping.selected_candidate_id is None
        assert any('Malformed proposal field ' + field in message for message in candidate.validation_errors)
        assert len(candidate.scoring_issues) == len({(issue.code, issue.category, issue.message) for issue in candidate.scoring_issues})
        if first is not None:
            assert candidate == first
        first = candidate
        mapping = AttributeMapping.model_validate_json(mapping.model_dump_json())


@pytest.mark.parametrize('fields', [{}, {'sources': []}, {'source_attributes': []},
    {'sources': [], 'source_attributes': []}, {'sources': [{'table': 'src', 'column': 'NAME'}]}])
@pytest.mark.parametrize('list_envelope', [False, True])
def test_absent_empty_and_structured_sources_remain_legitimate(fields, list_envelope):
    from app.core.sttm_builder import _normalize_source_mappings
    raw = dict(confidence_score=.99, confidence_reason='Corresponding name',
        preprocessing_rule='TRIM(src.NAME)', preprocessing_rule_type='Custom', **fields)
    body = [{'target': 'NAME', **raw}] if list_envelope else {'NAME': raw}
    mapping = _normalize_source_mappings({'mappings': body})['NAME']
    for _ in range(3):
        mapping = revalidate(mapping, session=ExplainSession()).result.mappings['NAME']
        assert mapping.selected_candidate_id
        assert mapping.candidates[0].adjusted_confidence_score == .99
        assert mapping.candidates[0].validation_status == 'valid'
        mapping = AttributeMapping.model_validate_json(mapping.model_dump_json())


def test_malformed_source_evidence_survives_clean_duplicate_with_higher_score():
    from app.core.sttm_builder import _normalize_source_mappings
    raw = dict(source_attributes={}, confidence_score=.9, confidence_reason='Corresponding name',
        preprocessing_rule='TRIM(src.NAME)', preprocessing_rule_type='Custom')
    raw['candidates'] = [dict(raw, source_attributes=[], confidence_score=.99)]
    mapping = _normalize_source_mappings({'mappings': [{'target': 'NAME', **raw}]})['NAME']
    for _ in range(3):
        mapping = revalidate(mapping, session=ExplainSession()).result.mappings['NAME']
        assert len(mapping.candidates) == 1
        assert mapping.candidates[0].adjusted_confidence_score == .49
        assert mapping.candidates[0].validation_status == 'invalid'
        assert mapping.selected_candidate_id is None
        mapping = AttributeMapping.model_validate_json(mapping.model_dump_json())


@pytest.mark.parametrize('expression', ['NULL', 'TRUE', 'FALSE', 'CURRENT_DATE', 'CURRENT_TIMESTAMP', ' null ', 'true'])
def test_bare_scalar_expression_survives_normalization_and_validation(expression):
    from app.core.sttm_builder import _normalize_source_mappings
    mapping = _normalize_source_mappings({'mappings': {'NAME': option(source_attributes=[], source_dependencies=[],
        preprocessing_rule=expression, preprocessing_rule_type='Custom')}})['NAME']
    result = revalidate(mapping, session=ExplainSession()).result.mappings['NAME']
    assert result.candidates[0].preprocessing_rule == expression
    assert result.candidates[0].validation_status == 'valid'
    assert result.selected_candidate_id
    assert revalidate(AttributeMapping.model_validate_json(result.model_dump_json()), session=ExplainSession()).result.mappings['NAME'] == result


@pytest.mark.parametrize('expression', ['NULL is unknown', 'TRUE customer match', 'CURRENT_DATE is recommended', 'CURRENT_TIMESTAMP_extra'])
def test_bare_scalar_allowlist_does_not_admit_prose(expression):
    mapping, _ = validate(option(source_attributes=[], source_dependencies=[], preprocessing_rule=expression))
    assert not mapping.candidates


def test_normalization_isolates_malformed_alternatives_and_keeps_raw_invalid_sql():
    from app.core.sttm_builder import _normalize_source_mappings
    raw_rule = '  CASE WHEN src.NAME = 1 THEN  '
    raw = option(preprocessing_rule=raw_rule, preprocessing_rule_type='Custom',
        candidates=[option('src.OTHER', .8), option(source_attributes=[{'bad': 'object'}],
                    preprocessing_rule='COALESCE(src.OTHER,', preprocessing_rule_type='Custom'), 'src.NAME'])
    mapping = _normalize_source_mappings({'mappings': {'NAME': raw}})['NAME']
    assert mapping.source_attributes == ['src.NAME'] and mapping.preprocessing_rule == raw_rule
    assert any(item.source_attributes == ['src.OTHER'] for item in mapping.candidates)
    broken = next(item for item in mapping.candidates if item.preprocessing_rule == 'COALESCE(src.OTHER,')
    assert broken.source_attributes == []
    assert any('Malformed proposal field' in item for item in broken.warnings)
    scored = revalidate(mapping, session=ExplainSession()).result.mappings['NAME']
    assert any(item.preprocessing_rule == raw_rule and item.validation_status == 'invalid' for item in scored.candidates)


@pytest.mark.parametrize('body', [{}, {'candidate_source_attributes': ['src.NAME']},
    {'unmatched_reason': 'Use src.NAME if possible'}, {'confidence_reason': 'src.NAME is probably suitable'}])
def test_names_and_prose_never_create_a_draft(body):
    from app.core.sttm_builder import _normalize_source_mappings
    mapping = _normalize_source_mappings({'mappings': {'NAME': body}})['NAME']
    assert not revalidate(mapping).result.mappings['NAME'].draft_candidate_id


def test_all_invalid_45_targets_keep_concrete_drafts_but_not_foreign_targets():
    req = request()
    template = req.data.attributes[0]
    req.data.attributes = [template.model_copy(update={'target_attribute': 'NAME' + str(index)}) for index in range(45)]
    result = SourceMappingResult(mappings={item.target_attribute: AttributeMapping(**option('src.MISSING', .97))
                                          for item in req.data.attributes})
    result.mappings['FOREIGN'] = AttributeMapping(**option())
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=result, message=None, status=STTMStatus.COMPLETED)
    scored = validate_row_candidates(SimpleNamespace(_query_session=None), req, response)
    assert len(scored.result.mappings) == 45
    assert all(item.draft_candidate_id and item.selected_candidate_id is None for item in scored.result.mappings.values())
    assert all(item.candidates[0].adjusted_confidence_score == .49 for item in scored.result.mappings.values())
    assert scored.data.status == STTMStatus.NEEDS_INPUT


@pytest.mark.parametrize('target', ['FOREIGN', 'OTHER.S.T.NAME', 'NAME, OTHER'])
def test_foreign_and_malformed_targets_cannot_create_candidates(target):
    req = request()
    result = SourceMappingResult(mappings={target: AttributeMapping(**option())})
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT, result=result, message=None, status=STTMStatus.COMPLETED)
    assert not validate_row_candidates(SimpleNamespace(), req, response).result.mappings


@pytest.mark.parametrize('rule', ['Use src.NAME when available.', 'The compiler failed (syntax error).', 'TRIM'])
def test_rule_prose_without_binding_does_not_create_a_candidate(rule):
    mapping, _ = validate(option(source_attributes=[], source_dependencies=[], preprocessing_rule=rule,
        preprocessing_rule_type='Custom'))
    assert mapping.candidates == [] and mapping.draft_candidate_id is None


def test_structurally_unusable_fields_remain_diagnostics_not_guessed_bindings():
    from app.core.sttm_builder import _normalize_source_mappings
    mapping = _normalize_source_mappings({'mappings': {'NAME': option(source_attributes=[{'table': 'src', 'column': 'NAME'}])}})['NAME']
    assert not mapping.source_attributes and not mapping.candidates
    assert 'Unusable proposal fields' in mapping.suggestions[0].message
    assert 'src' in mapping.suggestions[0].message


def test_proxy_never_erases_scored_roster_or_synthesizes_direct():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.automap_row_candidates import SCORING_META_KEY, SCORING_POLICY_VERSION
    req = request()
    req.meta[SCORING_META_KEY] = SCORING_POLICY_VERSION
    mapping = AttributeMapping(**option(confidence=.97, preprocessing_rule='COALESCE(src.NAME, $MISSING)',
        preprocessing_rule_type='Custom'))
    response = revalidate(mapping, req, ExplainSession())
    before = response.model_dump()
    AutoMappingProxyClient._validate_worker_response(response, req=req, batch_index=0)
    AutoMappingProxyClient._demote_undefined_firm_values(response, req=req)
    assert response.model_dump() == before
    response.meta.pop('automap_draft_validation')
    from app.core.exceptions import SnowflakeAgentError
    with pytest.raises(SnowflakeAgentError, match='policy mismatch'):
        AutoMappingProxyClient._validate_worker_response(response, req=req, batch_index=0)


def test_legacy_confidence_label_is_not_an_original_numeric_model_score():
    from app.core.sttm_builder import _normalize_source_mappings
    mapping = _normalize_source_mappings({'mappings': [{'target': 'NAME',
        'sources': [{'table': 'src', 'column': 'NAME', 'confidence': 'HIGH'}]}]})['NAME']
    assert mapping.confidence_score == .9  # Legacy compatibility remains unchanged.
    assert mapping.original_confidence_score is None
    scored = revalidate(mapping).result.mappings['NAME']
    assert scored.candidates[0].original_confidence_score is None
    assert scored.candidates[0].adjusted_confidence_score is None


def test_recorded_admission_retry_preserves_original_and_clears_resolved_issue():
    from app.core.automap_row_candidates import record_proposal
    original = AttributeMapping(**option(confidence=.97))
    blocked = record_proposal(original, messages=['Required read is incomplete'])
    retry = AttributeMapping(**option(confidence=.69))
    fixed = record_proposal(retry, blocked)
    assert fixed.candidates[0].original_confidence_score == .97
    assert not fixed.candidates[0].scoring_issues
    scored = revalidate(fixed).result.mappings['NAME']
    assert scored.candidates[0].adjusted_confidence_score == .97
    assert revalidate(scored).result.mappings['NAME'] == scored


def test_explicit_foreign_target_in_alternative_is_not_rebound_to_enclosing_row():
    from app.core.sttm_builder import _normalize_source_mappings
    mapping = _normalize_source_mappings({'mappings': {'NAME': option(candidates=[
        option('src.OTHER', .99, target_attribute='OTHER.S.T.NAME')])}})['NAME']
    assert all(item.source_attributes != ['src.OTHER'] for item in mapping.candidates)


def test_low_confidence_is_valid_and_no_alternatives_are_manufactured():
    mapping, _ = validate(option(confidence=.12))
    assert mapping.selected_candidate_id == mapping.candidates[0].candidate_id
    assert mapping.confidence_score == .12
    assert len(mapping.candidates) == 1
    assert mapping.candidates[0].validation_status == 'valid'


def test_each_candidate_keeps_its_own_score_reason_sources_and_rule():
    mapping, session = validate(option(confidence=.8), [option('src.OTHER', .6,
        preprocessing_rule="UPPER(src.OTHER)", preprocessing_rule_type='Custom', transformation_classification='complex')])
    assert [candidate.confidence_score for candidate in mapping.candidates] == [.8, .6]
    assert mapping.candidates[1].confidence_reason == 'Evidence for src.OTHER'
    assert mapping.candidates[1].preprocessing_rule == 'UPPER(src.OTHER)'
    assert len(session.queries) == 1
    assert all(candidate.validation_status == 'valid' for candidate in mapping.candidates)


def test_highest_invalid_option_does_not_displace_a_valid_low_confidence_option():
    mapping, _ = validate(option('src.MISSING', .99), [option('src.OTHER', .22)])
    assert mapping.source_attributes == ['src.OTHER']
    assert mapping.confidence_score == .22
    assert mapping.candidates[0].validation_status == 'invalid'
    assert mapping.selected_candidate_id == mapping.candidates[1].candidate_id


@pytest.mark.parametrize('changes', [
    {'source_attributes': ['src.MISSING']},
    {'source_attributes': ['outside.NAME']},
    {'preprocessing_rule': 'UNKNOWN_FUNCTION(src.NAME)', 'preprocessing_rule_type': 'Custom'},
    {'transformation_classification': 'complex', 'preprocessing_rule': None},
    {'mapping_mode': 'attribute', 'attribute_name': 'FIRM', 'constant_value': '$FIRM', 'value_binding_ids': ['missing']},
])
def test_invalid_claimed_valid_candidates_remain_unresolved(changes):
    mapping, _ = validate(option(**changes), [option(**changes, validation_status='valid')])
    assert mapping.selected_candidate_id is None
    assert mapping.transformation_classification == 'unresolved'
    assert all(candidate.validation_status == 'invalid' for candidate in mapping.candidates)
    assert all(candidate.validation_errors for candidate in mapping.candidates)


def test_deduplication_uses_the_complete_option():
    mapping, _ = validate(option(), [option(), option(preprocessing_rule='UPPER(src.NAME)', preprocessing_rule_type='Custom')])
    assert len(mapping.candidates) == 2
    assert len({candidate.candidate_id for candidate in mapping.candidates}) == 2


def test_three_invalid_options_do_not_hide_valid_primary():
    mapping, _ = validate(option(confidence=.1), [option('src.A', .99), option('src.B', .98), option('src.C', .97)])
    assert len(mapping.candidates) == 4
    assert mapping.source_attributes == ['src.NAME']
    assert mapping.selected_candidate_id in {candidate.candidate_id for candidate in mapping.candidates}


def test_roster_cannot_exceed_current_plus_three_alternatives():
    with pytest.raises(ValidationError):
        AttributeMapping.model_validate({**option(), 'candidates': [option()] * 5})


def test_duplicate_complete_options_keep_the_highest_real_confidence_and_reason():
    mapping, _ = validate(option(confidence=.2), [option(confidence=.9, confidence_reason='Stronger evidence')])
    assert len(mapping.candidates) == 1
    assert mapping.confidence_score == .9
    assert mapping.confidence_reason == 'Stronger evidence'


def test_sheet_review_dispatch_does_not_reuse_an_unvalidated_scalar_shortcut(monkeypatch):
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    from app.core.config import Settings
    req = request()
    req.meta['auto_map_sheet_review_v1'] = True
    proxy = AutoMappingProxyClient(Settings(_env_file=None))
    monkeypatch.setattr(proxy, '_exact_precedent_response', lambda *_: pytest.fail('unvalidated shortcut was used'))
    calls = []
    def invoke(batch, **kwargs):
        calls.append(batch)
        response = STTMBuilderResponse.from_invocation(batch, thread_id=None, parent_message_id=None,
            agent=SubAgent.SOURCE_MAPPING_AGENT, result=SourceMappingResult(mappings={'NAME': AttributeMapping(**option())}),
            message=None, status=STTMStatus.COMPLETED)
        return validate_row_candidates(SimpleNamespace(_query_session=ExplainSession()), batch, response)
    monkeypatch.setattr(proxy, '_invoke_batch', invoke)
    response = proxy._invoke_with_headers(req, headers={})
    assert calls
    assert response.result.mappings['NAME'].source_attributes == ['src.NAME']


def test_agent_payload_keeps_current_definition_without_sending_persisted_review_history():
    import json
    from app.core.sttm_builder import STTMBuilderService
    req = request()
    value = req.model_dump(mode='json')
    value['context']['workspace_context'] = {'mapping_rows': [{
        'id': 'row', 'target_column': 'NAME', 'source_columns': ['src.NAME'],
        'ai_candidates': [{'history': 'previous alternative'}],
        'ai_undo_snapshot': {'expression': 'old rule'}, 'ai_review_status': 'confirmed'}]}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    outgoing = json.loads(STTMBuilderService._build_agent_payload_unbounded(req))
    row = outgoing['context']['workspace_context']['mapping_rows'][0]
    assert row['source_columns'] == ['src.NAME']
    assert 'ai_candidates' not in row and 'ai_undo_snapshot' not in row
    assert req.context.workspace_context.mapping_rows[0].model_dump()['ai_review_status'] == 'confirmed'
    assert req.context.workspace_context.mapping_rows[0].model_dump()['ai_candidates']


@pytest.mark.parametrize('rule,valid', [('TRIM(src.NAME)', True), ('UNKNOWN_FUNCTION(src.NAME)', False)])
def test_a_missing_rule_type_never_bypasses_expression_validation(rule, valid):
    mapping, session = validate(option(preprocessing_rule=rule, preprocessing_rule_type=None))
    assert len(session.queries) == 1
    assert (mapping.selected_candidate_id is not None) is valid
    assert mapping.candidates[0].preprocessing_rule_type == 'Custom'


def test_direct_type_cannot_hide_an_unvalidated_expression():
    mapping, _ = validate(option(preprocessing_rule='UNKNOWN_FUNCTION(src.NAME)', preprocessing_rule_type='Direct'))
    assert mapping.selected_candidate_id is None
    assert mapping.candidates[0].validation_status == 'invalid'


def test_firm_value_remains_selectable_when_reopened_graph_has_a_new_row_binding_id():
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
    from app.schema.sttm_builder import ValueBinding
    req = request()
    binding = ValueBinding(binding_id='project-attribute:firm-1', value='$FIRM',
        resolved_value='Approved firm', data_type='VARCHAR', is_placeholder=True,
        allow_project_specific_value=True, attribute_name='FIRM', resolution_status='project_attribute')
    req.context.relation_graph.value_bindings = [binding]
    mapping, _ = validate(option(source_attributes=[], source_dependencies=[], mapping_mode='attribute',
        attribute_name='FIRM', constant_value='$FIRM', value_binding_ids=[binding.binding_id],
        transformation_classification='value', preprocessing_rule_type='Value'), req=req)
    assert mapping.selected_candidate_id
    assert mapping.value_binding_ids == ['$FIRM']
    rebuilt = req.context.relation_graph.model_copy(deep=True)
    rebuilt.value_bindings = [binding.model_copy(update={'binding_id': 'value:new-sheet-row'})]
    result = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=rebuilt, validate_with_explain=False, allow_unresolved_placeholders=False,
        mappings=[MappingSqlMappingItem(target_column='NAME', mapping_mode=mapping.mapping_mode,
            constant_value=mapping.constant_value, attribute_name=mapping.attribute_name,
            value_binding_ids=mapping.value_binding_ids, rule='Value')]))
    assert result.valid and result.ready
    assert not result.unresolved_placeholders


def test_empty_and_prose_only_results_become_suggestions_without_fake_zero_percent_candidates():
    mapping, _ = validate(option(source_attributes=[], source_dependencies=[], confidence_score=0,
        transformation_classification='unresolved', unmatched_reason='No suitable source. SI_FIRM is entirely null; consider a firm lookup.',
        candidate_source_attributes=['src.OTHER']))
    assert mapping.candidates == []
    assert mapping.selected_candidate_id is None
    assert not mapping.suggestions
    assert mapping.unmatched_reason
    assert mapping.candidate_source_attributes == ['src.OTHER']


def test_unscoped_and_other_row_warnings_do_not_get_copied_to_a_mapping():
    from app.schema.contracts import ApiWarning
    warnings = [ApiWarning(code='own',field='NAME',message='NAME requires business review.'),
                ApiWarning(code='other',field='REFERRAL_ID',message='Referral data is sparse.'),
                ApiWarning(code='batch',message='Other target may require review.')]
    mapping, _ = validate(warnings=warnings)
    assert 'NAME requires business review.' in mapping.candidates[0].warnings
    assert 'Referral data is sparse.' not in mapping.candidates[0].warnings
    assert 'Other target may require review.' not in mapping.candidates[0].warnings


def join_request(with_edge=False):
    from app.schema.sttm_builder import RelationNode, RelationEdge
    req=request()
    req.context.relation_graph.nodes.append(RelationNode.model_validate({'relation_id':'D.S.LOOKUP','alias':'lookup',
        'kind':'PHYSICAL_TABLE','table':{'database':'D','schema':'S','table':'LOOKUP'},'output_columns':[{'name':'ID','data_type':'VARCHAR'}]}))
    if with_edge:
        req.context.relation_graph.edges.append(RelationEdge.model_validate({'edge_id':'known','left_relation_id':'D.S.T',
            'right_relation_id':'D.S.LOOKUP','join_type':'LEFT','conditions':[{'left_column':'OTHER','right_column':'ID','operator':'='}],
            'provenance':'FOREIGN_KEY','validation_status':'validated'}))
    return req


def test_join_suggestion_keeps_known_tables_but_does_not_invent_keys_or_type():
    req=join_request()
    mapping, _=validate(option(suggestions=[{'kind':'relationship','message':'Review a firm lookup.',
        'source_references':['src.NAME','lookup.ID'],'join_recommendation':{'left_relation_id':'D.S.T','right_relation_id':'D.S.LOOKUP',
        'join_type':'INNER','conditions':[{'left_column':'INVENTED','right_column':'SECRET','operator':'='}]}}]),req=req)
    recommendation=mapping.suggestions[0].join_recommendation
    assert recommendation.left_relation_id=='D.S.T' and recommendation.right_relation_id=='D.S.LOOKUP'
    assert recommendation.join_type is None and recommendation.conditions==[]
    assert req.context.relation_graph.edges==[]


def test_join_prefill_uses_authorized_relationship_evidence_instead_of_model_keys():
    req=join_request(True)
    mapping, _=validate(option(suggestions=[{'kind':'relationship','message':'Review this required relationship.',
        'join_recommendation':{'left_relation_id':'D.S.T','right_relation_id':'D.S.LOOKUP','join_type':'RIGHT',
        'conditions':[{'left_column':'MADE_UP','right_column':'OTHER','operator':'='}]}}]),req=req)
    rec=mapping.suggestions[0].join_recommendation
    assert rec.join_type=='LEFT'
    assert rec.conditions[0]['left_column']=='OTHER'
    assert rec.conditions[0]['right_column']=='ID'


def test_unknown_relation_in_a_recommendation_is_not_admitted_as_a_real_source():
    req=join_request()
    mapping, _=validate(option(suggestions=[{'kind':'relationship','message':'Choose the missing lookup.',
        'join_recommendation':{'left_relation_id':'D.S.T','right_relation_id':'D.S.INVENTED'}}]),req=req)
    assert mapping.suggestions[0].join_recommendation.right_relation_id is None
    assert [node.relation_id for node in req.context.relation_graph.nodes]==['D.S.T','D.S.LOOKUP']


def test_relationship_guidance_can_resolve_known_execution_references_without_guessing_a_join():
    req=join_request()
    mapping, _=validate(option(suggestions=[{'kind':'relationship','message':'Review a lookup.',
        'source_references':['src.NAME','lookup.ID']}]),req=req)
    rec=mapping.suggestions[0].join_recommendation
    assert (rec.left_relation_id,rec.right_relation_id)==('D.S.T','D.S.LOOKUP')
    assert rec.join_type is None and not rec.conditions


def test_source_and_transformation_packets_separate_display_names_from_execution_identity():
    from app.core.execution_display_names import execution_display_names
    from app.core.automap_transform import transformation_packet
    req=request();raw=req.model_dump(mode='json')
    names=execution_display_names(raw['context'])
    assert names['relations'][0]['execution_alias']=='src'
    assert names['relations'][0]['display_name']=='T'
    assert names['relations'][0]['relation_id']=='D.S.T'
    packet=transformation_packet(raw,factor=False)
    assert packet['context']['execution_display_names']==names
    assert packet['context']['relation_graph']['nodes'][0]['alias']=='src'
