const assert=require('node:assert/strict');
const test=require('node:test');
const fs=require('node:fs');const path=require('node:path');const ts=require('typescript');const Module=require('node:module');
const root=path.resolve(__dirname,'../src');const cache=new Map();
const mocks={};
let attributesResult=async()=>[];
let tablesResult=async()=>[];
let compileResult=async()=>({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});
function load(file){
 if(cache.has(file))return cache.get(file).exports;
 const loaded=new Module(file,module);cache.set(file,loaded);
 loaded.require=request=>{
  if(request==='@/api/axiosInstance')return {getApiErrorMessage:(error,fallback)=>error.message||fallback};
  if(request==='@/services/dbService')return {dbService:{compileMappingSql:payload=>compileResult(payload),getTableAttributes:names=>attributesResult(names),getSchemaTables:(db,schema)=>tablesResult(db,schema)}};
  if(request==='@/services/projectService')return {listProjectAttributes:async()=>[]};
  if(request.startsWith('@/services/')){
   if(!mocks[request])mocks[request]=new Proxy({},{get:(_target,key)=> key==='then'?undefined:(...args)=>{const fn=mocks[`${request}:${String(key)}`];return fn?fn(...args):{};}});
   return mocks[request];
  }
  if(request.startsWith('@/')||request.startsWith('.')){
   let target=request.startsWith('@/')?path.join(root,request.slice(2)):path.resolve(path.dirname(file),request);
   if(!path.extname(target))target+='.ts';return load(target);
  }
  return require(request);
 };
 loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);
 return loaded.exports;
}
const slice=load(path.join(root,'features/sttm/store/sttm-builder-slice.ts'));
const validation=load(path.join(root,'features/sttm/shared/row-validation-state.ts'));
const context=load(path.join(root,'features/sttm/shared/validation-context.ts'));
const review=load(path.join(root,'features/sttm/mapping/mapping-review-model.ts'));
const {configureStore}=require('@reduxjs/toolkit');
const table=(id,name=id)=>({tableId:id,tableName:name,qualifiedName:`D.S.${name}`,isSelected:true,tag:'Source',rows:'1',columns:1,columnItems:[{name:'NAME',type:'VARCHAR'}]});
const row=()=>({id:'name',targetColumn:'NAME',targetType:'VARCHAR',sourceColumn:'src.NAME',sourceColumns:['src.NAME'],mappingMode:'source',rule:'Direct',expression:null,status:'MAPPED'});
const option=(id='selected',ref='src.NAME')=>({candidate_id:id,source_attributes:[ref],source_dependencies:[],mapping_mode:'source',preprocessing_rule_type:'Direct',scoring_policy_version:'draft-caps-v1',confidence_score:.8,confidence_reason:'Corresponding name',validation_status:'valid',validation_errors:[],warnings:[],value_binding_ids:[]});
function state(rows=[row()]){
 const state=structuredClone(slice.default(undefined,{type:'@@init'}));
 Object.assign(state,{activeProjectId:'project',activeSttmId:'mapping',sources:[table('source')],targets:[table('target','TARGET')],drivingTableId:'source',mappings:rows});
 for(const row of rows)if(row.status==='MAPPED')row.validation=validation.validatedRow(row,context.selectionValidationSignature(state));
 return state;
}
function store(initial=state()) {return configureStore({reducer:{sttmBuilder:slice.default},preloadedState:{sttmBuilder:initial},middleware:get=>get({serializableCheck:false,immutableCheck:false})});}
function normalize(initial){return slice.default(initial,slice.setValidationValuesSignature({projectId:'other',signature:'ignored'}));}

test('generation without EXPLAIN never grants row or artifact proof, but reviewed SQL can validate zero-mapped drafts',()=>{
 const initial=state([{...row(),status:'NEEDS_VALIDATION'}]);
 const payload={generatedSql:'SELECT NAME',previewSql:'SELECT NAME',contextHash:'draft',ready:true,
  validationContext:context.selectionValidationSignature(initial),validatedRows:[{id:'name',definitionSignature:validation.rowDefinitionSignature(initial.mappings[0])}]};
 const generated=slice.default(initial,slice.setCompiledMappingResult(payload));
 assert.equal(generated.mappings[0].status,'MAPPED');assert.equal(generated.mappings[0].validation,undefined);
 assert.equal(generated.sqlValidatedSignature,null);
 const checked=slice.default(generated,slice.setCompiledMappingResult({...payload,explainValidated:true}));
 assert.equal(checked.mappings[0].status,'MAPPED');
});

test('artifact proof covers failed drafts, SQL, query context and Values, not citation or review flags',()=>{
 const signatures=load(path.join(root,'features/sttm/shared/mapping-validation.ts'));
 const initial={...state([{...row(),status:'VALIDATION_FAILED'}]),projectId:'project',semanticContext:[]};
 const signature=signatures.computeMappingValidationSignature(initial);initial.sqlValidatedSignature=signature;
 assert.equal(signatures.currentMappingIsValidated(initial),true);
 for(const change of [s=>s.mappings[0].rule='Custom',s=>s.mappings[0].attributeName='Firm',s=>s.mappings[0].targetSqlName='"Name"',
  s=>s.mappings.push({...row(),id:'bad',targetColumn:'BAD',status:'NEEDS_VALIDATION',rule:'Custom'}),
  s=>s.mappingSql='SELECT edited',s=>s.mappingPreviewSql='SELECT changed',s=>s.compiledMappingSql='SELECT changed',
  s=>s.sourceQuerySql='SELECT other',s=>s.sourceQueryModifiers={limit:'LIMIT 2'},s=>s.validationValuesSignature='changed-values',
  s=>s.pendingManualEditSnapshots={name:s.mappings[0]}]) {
  const changed=structuredClone(initial);change(changed);assert.equal(signatures.currentMappingIsValidated(changed),false);
 }
 const viewed=structuredClone(initial);Object.assign(viewed.mappings[0],{confidenceReason:'missing citation',aiReviewStatus:'unreviewed',status:'MAPPED'});
 assert.equal(signatures.currentMappingIsValidated(viewed),true);
 const restored=slice.default(undefined,slice.hydrateBuilderSession(initial));
 assert.equal(restored.mappings.filter(item=>item.status==='MAPPED').length,1);assert.ok(restored.mappings.every(item=>!validation.rowValidationIsCurrent(item,context.selectionValidationSignature(restored))));
 assert.equal(signatures.readValidatedSignature([{kind:'mapping_sql_validation',signature,valid:false}]),null);
});

test('the actual slice keeps validated applied rows mapped despite AI review flags, confidence and guidance',()=>{
 const initial=state();const current=initial.mappings[0];Object.assign(current,{selectedAiCandidateId:'selected',aiReviewStatus:'unreviewed',confidenceScore:.1,aiCandidates:[option()],aiSuggestions:[{suggestion_id:'coverage',kind:'source_data',message:'Check coverage',source_references:[]}]});
 const result=normalize(initial);assert.equal(result.mappings[0].status,'MAPPED');
 assert.equal(result.mappings[0].aiReviewStatus,'unreviewed');
 const sum=load(path.join(root,'features/sttm/mapping/mapping-review-summary.ts')).mappingReviewSummary(result.mappings,{},result.sources,[],result.activeSttmId);
 assert.match(sum,/Mapped:\*\* 1/);assert.match(sum,/Unmapped:\*\* 0/);
});
test('source visibility, a saved manual flag, and stale MAPPED labels cannot certify incomplete or unvalidated definitions',()=>{
 const initial=state([{...row(),status:'UNMAPPED',manuallySaved:true},{...row(),id:'custom',rule:'Custom',expression:null,status:'UNMAPPED'},{...row(),id:'value',sourceColumn:null,sourceColumns:[],mappingMode:'attribute',attributeName:'FIRM',status:'UNMAPPED'},{...row(),id:'blank',sourceColumn:null,sourceColumns:[],rule:'Direct',status:'UNMAPPED'}]);
 assert.deepEqual(normalize(initial).mappings.map(row=>row.status),['MAPPED','MAPPED','MAPPED','UNMAPPED']);
});
test('a failed alternative never invalidates the currently validated definition or destroys its undo',()=>{
 const initial=state();const current=initial.mappings[0];Object.assign(current,{selectedAiCandidateId:'selected',aiReviewStatus:'unreviewed',aiCandidates:[option(),option('alternative','src.OTHER')],aiUndoSnapshot:{...row(),sourceColumn:'src.OLD',sourceColumns:['src.OLD']}});
 const expected=structuredClone(current.validation);const history=structuredClone(current.aiUndoSnapshot);
 const result=slice.default(initial,slice.sheetCandidateInvalidated({mappingId:'name',candidateId:'alternative',signature:slice.autoMapInputSignature? slice.autoMapInputSignature(current):JSON.stringify([current.id,current.targetColumn,current.targetType,current.targetOrdinal,current.sourceColumn,current.sourceType,current.sourceColumns,current.mappingMode,current.constantValue,current.attributeName,current.expression,current.rule,current.nlRule,current.loadOrder,current.description,current.descriptionEdited,current.sourceDependencies,current.valueBindingIds]),shared:slice.autoMapSharedInputs(initial),reason:'Missing join'}));
 assert.equal(result.mappings[0].status,'MAPPED');assert.deepEqual(result.mappings[0].validation,expected);assert.deepEqual(result.mappings[0].aiUndoSnapshot,history);
 assert.equal(result.mappings[0].aiCandidates[1].validation_status,'invalid');
});
test('confirmed current blocking errors have their own status; editing makes that failed proof stale',()=>{
 const initial=state();initial.mappings[0].validation=validation.validatedRow(initial.mappings[0],context.selectionValidationSignature(initial),'failed','Column not found');
 assert.equal(normalize(initial).mappings[0].status,'MAPPED');
 const changed=slice.default(initial,slice.updateMapping({id:'name',updates:{sourceColumn:'src.FIXED',sourceColumns:['src.FIXED']}}));
 assert.equal(changed.mappings[0].status,'MAPPED');
});
test('validation is unaffected by viewing recommendations and survives browser draft hydration',()=>{
 const initial=state();const signature=context.selectionValidationSignature(initial);
 initial.sourceValidation={contextSignature:signature,previewKey:'preview',valid:true,synced:true};
 initial.mappings[0].aiUndoSnapshot={...row(),sourceColumn:'src.OLD',sourceColumns:['src.OLD']};
 const hydrated=slice.default(undefined,slice.hydrateBuilderSession(initial));
 assert.deepEqual(hydrated.sourceValidation,initial.sourceValidation);assert.equal(context.selectionValidationSignature(hydrated),signature);
 assert.equal(hydrated.mappings[0].status,'MAPPED');assert.deepEqual(hydrated.mappings[0].aiUndoSnapshot,initial.mappings[0].aiUndoSnapshot);
});
test('every executable selection dependency changes the signature, while cancellation restores eligibility',()=>{
 const initial=state();const before=context.selectionValidationSignature(initial);const changes=[
 s=>s.sourceQuerySql='SELECT changed',s=>s.sources.push(table('other')),s=>s.targets[0].qualifiedName='D.S.OTHER',s=>s.drivingTableId='other',
 s=>s.relationships.push({id:'join',leftTableId:'source',rightTableId:'other',joinType:'LEFT',conditions:[{leftColumn:'ID',operator:'=',rightColumn:'ID'}]}),
 s=>s.sourceFilterSql='ID > 1',s=>s.sourceGroupBySql='ID',s=>s.sourceOrderBySql='ID',s=>s.sourceQueryModifiers={distinct:'DISTINCT'},
 s=>s.derivedSources.push({id:'cte',sourceName:'cte',isSelected:true,sqlText:'SELECT 1',joins:[],filters:[],columns:[]}),s=>s.validationValuesSignature='new-values',
 ];
 for(const change of changes){const changed=structuredClone(initial);change(changed);assert.notEqual(context.selectionValidationSignature(changed),before);assert.equal(normalize(changed).mappings[0].status,'MAPPED');assert.equal(validation.rowValidationIsCurrent(changed.mappings[0],context.selectionValidationSignature(changed)),false);assert.equal(context.selectionValidationSignature(initial),before);}
 const viewed=structuredClone(initial);viewed.mappings[0].aiReviewStatus='confirmed';viewed.selectedMappingIds=['name'];viewed.sources[0].rows='99';assert.equal(context.selectionValidationSignature(viewed),before);
 const edited=slice.default(initial,slice.updateMapping({id:'name',updates:{sourceColumns:['src.EDIT'],sourceColumn:'src.EDIT'}}));
 const canceled=slice.default(edited,slice.cancelPendingManualMappingEdits());assert.equal(canceled.mappings[0].status,'MAPPED');
});
test('selection validation responses for an old revision cannot enable Next',()=>{
 const initial=state();const old=context.selectionValidationSignature(initial);initial.sourceFilterSql='ID > 1';
 const result=slice.default(initial,slice.setSourceValidation({contextSignature:old,previewKey:'old',valid:true,synced:true}));assert.equal(result.sourceValidation,null);
 const current=context.selectionValidationSignature(initial);const valid=slice.default(result,slice.setSourceValidation({contextSignature:current,previewKey:'new',valid:true,synced:true}));assert.equal(valid.sourceValidation.contextSignature,current);
 const failed=slice.default(valid,slice.setSourceValidation({contextSignature:current,previewKey:'new',valid:false,synced:false}));assert.equal(failed.sourceValidation.valid,false);
});
test('saving the reviewed join is the first source mutation and updates one shared recommendation status',()=>{
 const initial=state();const lookup={...table('lookup'),isSelected:false};initial.sources.push(lookup);
 initial.sourceQuerySql='SELECT authored';initial.sourceFilterSql='ID > 0';initial.pendingManualEditSnapshots={name:{...initial.mappings[0]}};
 initial.mappings[0].aiSuggestions=[{suggestion_id:'join-1',kind:'relationship',message:'Requires lookup',source_references:[]}];
 const before=structuredClone(initial);const result=slice.default(initial,slice.saveReviewedJoin({id:'reviewed',leftTableId:'source',rightTableId:'lookup',joinType:'LEFT',conditions:[{leftColumn:'ID',operator:'=',rightColumn:'ID'}],recommendationId:'join-1'}));
 assert.equal(before.sources[1].isSelected,false);assert.equal(before.relationships.length,0);
 assert.equal(result.sources[1].isSelected,true);assert.equal(result.relationships.length,1);assert.equal(result.mappings[0].aiSuggestions[0].recommendation_status,'saved');
 assert.equal(result.mappings[0].status,'MAPPED');assert.equal(result.drivingTableId,before.drivingTableId);assert.equal(result.sourceQuerySql,before.sourceQuerySql);assert.equal(result.sourceFilterSql,before.sourceFilterSql);assert.deepEqual(result.pendingManualEditSnapshots,before.pendingManualEditSnapshots);
});
test('undo is offered only for a distinct recoverable previous definition',()=>{
 const current=row();assert.equal(validation.recoverableAiUndo({...current,aiUndoSnapshot:{sourceColumns:[],sourceColumn:null}}),false);
 assert.equal(validation.recoverableAiUndo({...current,aiUndoSnapshot:{...current,confidenceScore:.99}}),false);
 assert.equal(validation.recoverableAiUndo({...current,aiUndoSnapshot:{...current,sourceColumns:['src.OLD']}}),true);
});
function draftResponse(candidates, target='NAME') {
 return {operation:'sttm.auto_map',meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'},result:{mappings:{[target]:{
  candidates,draft_candidate_id:candidates[0]?.candidate_id??null,selected_candidate_id:candidates.find(item=>item.validation_status==='valid')?.candidate_id??null}}}};
}
function applyDraft(initial,response,requestId='draft-run') {
 return slice.default(initial,{type:'sttmBuilder/autoMapBatchApplied',payload:{requestId,completedMappingIds:initial.mappings.map(item=>item.id),processedCount:initial.mappings.length,totalCount:initial.mappings.length,response}});
}
function blankRow(id='name',target='NAME') {return {...row(),id,targetColumn:target,sourceColumn:null,sourceColumns:[],expression:null,status:'UNMAPPED',rule:'Select...'};}

test('actual reducer handles 45 targets as drafts, not successful validation or human approval',()=>{
 const rows=Array.from({length:45},(_,index)=>blankRow('row'+index,'TARGET_'+index));
 const initial=state(rows);initial.targetAttributeGroup={qualifiedName:'D.S.TARGET',columns:rows.map(item=>({name:item.targetColumn}))};
 const mappings=Object.fromEntries(rows.map((item,index)=>{
  const candidate={...option('draft'+index,'src.COLUMN_'+index),confidence_score:index===44?0:.49,original_confidence_score:index===44?null:.9,adjusted_confidence_score:index===44?null:.49,
   validation_status:index<30?'invalid':index<40?'unvalidated':'valid',validation_errors:index<30?['Missing source']:[],scoring_policy_version:'draft-caps-v1'};
  return [item.targetColumn,{candidates:[candidate],draft_candidate_id:candidate.candidate_id,selected_candidate_id:candidate.validation_status==='valid'?candidate.candidate_id:null}];
 }));
 let next=slice.default(initial,slice.runAutoMap.pending('draft-run',undefined));
 next=applyDraft(next,{operation:'sttm.auto_map',meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'},result:{mappings}});
 next=applyDraft(next,{operation:'sttm.auto_map',meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'},result:{mappings}});
 next=slice.default(next,slice.runAutoMap.fulfilled({sheetReviewV1:true,totalCount:45,failedTargets:[],autoMapOutcome:null},'draft-run',undefined));
 assert.equal(next.mappings.filter(item=>item.sourceColumn).length,45);
 assert.equal(next.mappings.filter(item=>item.status==='MAPPED').length,45);
 assert.equal(next.mappings.filter(item=>item.validation?.result==='failed').length,30);
 assert.ok(next.mappings.every(item=>item.validation?.result!=='valid'&&item.aiReviewStatus==='unreviewed'&&!item.manuallySaved));
 assert.ok(next.mappings.every(item=>item.aiUndoSnapshot.sourceColumn===null));
 assert.equal(next.mappings[44].confidenceScore,null);
 const summary=next.chatMessages.at(-1).content;
 assert.match(summary,/New draft mappings applied:\*\* 45/);assert.match(summary,/Mapped:\*\* 45/);
 assert.match(summary,/Unmapped:\*\* 0/);assert.match(summary,/Mapped:\*\* 45/);
 assert.equal(next.compiledMappingReady,false);
 assert.ok(next.mappings.slice(0,30).every(item=>item.validation.origin==='generation'));
 assert.ok(next.mappings.every(item=>review.mappingDisplayStatus(item)==='MAPPED'));
 assert.doesNotMatch(summary,/unresolved|review needed|validation failed|requiring validation|review the highlighted/i);
 assert.equal(next.autoMapStatusMessage,'45 mapped, 0 unmapped.');
});

test('all 45 invalid generated drafts have neutral presentation without changing execution guards',()=>{
 const rows=Array.from({length:45},(_,index)=>blankRow('row'+index,'TARGET_'+index));
 let next=state(rows);next.targetAttributeGroup={qualifiedName:'D.S.TARGET',columns:rows.map(item=>({name:item.targetColumn}))};
 next=slice.default(next,slice.runAutoMap.pending('draft-run',undefined));
 const mappings=Object.fromEntries(rows.map((item,index)=>[item.targetColumn,{candidates:[{...option('draft'+index,'src.COLUMN_'+index),validation_status:'invalid',confidence_score:.49,validation_errors:['SQL validation failed'],confidence_reason:'Customer attribute corresponds to the target. precedent_decision missing.'}]}]));
 next=applyDraft(next,{operation:'sttm.auto_map',meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'},result:{mappings}});
 next=slice.default(next,slice.runAutoMap.fulfilled({sheetReviewV1:true,totalCount:45,failedTargets:[],autoMapOutcome:null},'draft-run',undefined));
 assert.ok(next.mappings.every(item=>item.status==='MAPPED'&&item.validation.result==='failed'&&item.confidenceScore===.49));
 assert.ok(next.mappings.every(item=>review.mappingDisplayStatus(item)==='MAPPED'));
 assert.equal(next.compiledMappingReady,false);assert.equal(next.sqlValidatedSignature,null);
 assert.match(next.chatMessages.at(-1).content,/Mapped:\*\* 45/);
 assert.doesNotMatch(next.chatMessages.at(-1).content,/unresolved|review needed|validation failed|precedent_decision/i);
});

test('actual candidate delivery fences stale request, workspace, shared revision, foreign target and failed results',()=>{
 for(const mode of ['request','workspace','shared','foreign','failed','error','batch-failed','binding']) {
  let initial=state([blankRow()]);initial.targetAttributeGroup={qualifiedName:'D.S.TARGET',columns:[{name:'NAME'}]};
  initial=slice.default(initial,slice.runAutoMap.pending('draft-run',undefined));
  initial=structuredClone(initial);
  const response=draftResponse([option()],mode==='foreign'?'FOREIGN.S.TARGET.NAME':'NAME');
  if(mode==='workspace')initial.activeSttmId='other';
  if(mode==='shared')initial.sourceQuerySql='SELECT changed';
  if(mode==='failed')response.data={status:'failed'};
  if(mode==='error')response.error={message:'Agent failed'};
  if(mode==='batch-failed')response.warnings=[{code:'AUTO_MAPPING_BATCH_FAILED',field:'NAME'}];
  if(mode==='binding'){initial.autoMapRun.targetBindings={NAME:'current'};response.meta.auto_map_target_bindings={NAME:'foreign'};}
  const next=applyDraft(initial,response,mode==='request'?'stale':'draft-run');
  assert.equal(next.mappings[0].sourceColumn,null,mode);assert.notEqual(next.mappings[0].validation?.result,'valid',mode);
 }
});

test('actual sheet drafts preserve imported, saved, confirmed and midrun edited definitions',()=>{
 for(const mode of ['imported','saved','confirmed','edited','midrun','after-partial']) {
  const baseline=mode==='midrun'||mode==='after-partial'?blankRow():{...row(),expression:'TRIM(src.NAME)',rule:'Custom'};
  if(mode==='saved')baseline.manuallySaved=true;
  if(mode==='confirmed')baseline.aiReviewStatus='confirmed';
  if(mode==='edited')baseline.aiReviewStatus='edited';
  let next=state([baseline]);next.targetAttributeGroup={qualifiedName:'D.S.TARGET',columns:[{name:'NAME'}]};
  next=slice.default(next,slice.runAutoMap.pending('draft-run',undefined));
  if(mode==='after-partial')next=applyDraft(next,draftResponse([option('first','src.FIRST')]));
  if(mode==='midrun'||mode==='after-partial')next=slice.default(next,slice.updateMapping({id:'name',updates:{sourceColumn:'src.MANUAL',sourceColumns:['src.MANUAL'],expression:'UPPER(src.MANUAL)',rule:'Custom'}}));
  const before=next.mappings[0];
  next=applyDraft(next,draftResponse([{...option('bad','src.BAD'),validation_status:'invalid',validation_errors:['Unknown source']}]));
  for(const key of ['sourceColumn','sourceColumns','expression','rule','aiReviewStatus','validation'])assert.deepEqual(next.mappings[0][key],before[key],mode+':'+key);
  if(!['midrun','after-partial'].includes(mode))assert.equal(next.mappings[0].aiCandidates.length,1);
 }
});

test('Use candidate applies an invalid draft without compilation, clears no unrelated edit, and supports undo',async()=>{
 const initial=state([row(),{...row(),id:'other',targetColumn:'OTHER'}]);
 initial.mappings[0].aiCandidates=[{...option('invalid','src.MISSING'),validation_status:'invalid',validation_errors:['Missing column']}];
 initial.pendingManualEditSnapshots.other={...initial.mappings[1],sourceColumn:'src.ORIGINAL'};
 const currentStore=store(initial);let calls=0;
 compileResult=async()=>{calls++;throw new Error('Draft selection must not compile');};
 await currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'invalid'})).unwrap();
 const selected=currentStore.getState().sttmBuilder;
 assert.equal(calls,0);assert.equal(selected.mappings[0].sourceColumn,'src.MISSING');assert.equal(selected.mappings[0].status,'MAPPED');
 assert.equal(selected.mappings[0].aiReviewStatus,'unreviewed');assert.deepEqual(selected.pendingManualEditSnapshots.other,initial.pendingManualEditSnapshots.other);
 currentStore.dispatch(slice.undoSheetSuggestion('name'));
 const restored=currentStore.getState().sttmBuilder.mappings[0];assert.equal(restored.sourceColumn,'src.NAME');assert.deepEqual(restored.validation,initial.mappings[0].validation);
});

test('explicit failed validation remains actionable and caps structured confidence',async()=>{
 const candidate={...option(),original_confidence_score:.8,adjusted_confidence_score:.8};
 const current={...blankRow(),...load(path.join(root,'features/sttm/mapping/sheet-candidates.ts')).candidateRowUpdates(candidate)};
 current.aiCandidates=[candidate];
 const currentStore=store(state([current]));
 compileResult=async()=>({valid:false,ready:false,unresolved_placeholders:['$FIRM'],warnings:['Provide the project Value FIRM.']});
 await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'selected',validateOnly:true})).unwrap(),error=>/Provide the project Value/.test(error.message));
 const failed=currentStore.getState().sttmBuilder.mappings[0];
 assert.equal(failed.validation.origin,'explicit');assert.equal(review.mappingDisplayStatus(failed),'MAPPED');
 assert.equal(failed.confidenceScore,.49);assert.equal(failed.status,'MAPPED');
 const snapshot=slice.snapshotFromState(currentStore.getState().sttmBuilder,'workspace.autosaved');
 assert.equal(snapshot.mapping_rows[0].validation.origin,'explicit');
});

test('actual saved evidence and hydration keep historical AI display-only at every thunk and reducer boundary',async()=>{
 const recovery=load(path.join(root,'features/sttm/shared/mapping-row-recovery.ts'));
 for(const validity of ['invalid','valid']) for(const version of [undefined,'old-policy']) {
  const legacy={...option('legacy'),scoring_policy_version:version,confidence_score:.99,validation_status:validity,validation_errors:validity==='invalid'?['Missing source']:[]};
  const evidence=recovery.savedMappingEvidence(JSON.parse(JSON.stringify({ai_candidates:[legacy],selected_ai_candidate_id:'legacy'})));
  const initial=state([{...row(),...evidence,confidenceScore:.99}]);
  const hydrated=slice.default(undefined,slice.hydrateBuilderSession(JSON.parse(JSON.stringify(initial))));
  const currentStore=store(hydrated);const before=JSON.stringify(currentStore.getState().sttmBuilder);let calls=0;
  compileResult=async()=>{calls++;return {valid:true,ready:true,unresolved_placeholders:[],warnings:[]};};
  for(const options of [{},{confirm:true},{validateOnly:true},{candidateId:'__current_definition__',validateOnly:true}]) {
   await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'legacy',...options})).unwrap(),error=>/historical.*display-only/i.test(error.message));
   assert.equal(JSON.stringify(currentStore.getState().sttmBuilder),before);
  }
  const signature=JSON.stringify([hydrated.mappings[0].id,hydrated.mappings[0].targetColumn,hydrated.mappings[0].targetType,hydrated.mappings[0].targetOrdinal,hydrated.mappings[0].sourceColumn,hydrated.mappings[0].sourceType,hydrated.mappings[0].sourceColumns,hydrated.mappings[0].mappingMode,hydrated.mappings[0].constantValue,hydrated.mappings[0].attributeName,hydrated.mappings[0].expression,hydrated.mappings[0].rule,hydrated.mappings[0].nlRule,hydrated.mappings[0].loadOrder,hydrated.mappings[0].description,hydrated.mappings[0].descriptionEdited,hydrated.mappings[0].sourceDependencies,hydrated.mappings[0].valueBindingIds]);
  const payload={mappingId:'name',candidateId:'legacy',signature,shared:slice.autoMapSharedInputs(hydrated)};
  for(const action of [slice.sheetCandidateValidated({...payload,draftOnly:true}),slice.sheetCandidateValidated({...payload,confirm:true}),slice.sheetCandidateRevalidated(payload)]) {
   currentStore.dispatch(action);assert.equal(JSON.stringify(currentStore.getState().sttmBuilder),before);
  }
  assert.equal(calls,0);assert.deepEqual(currentStore.getState().sttmBuilder.mappings[0].aiCandidates,evidence.aiCandidates);
 }
});

test('manual held definitions remain explicitly checkable without promoting their historical AI evidence',async()=>{
 const legacy={...option('legacy'),scoring_policy_version:undefined,validation_status:'invalid',confidence_score:.99};
 const initial=state([{...row(),manuallySaved:true,aiCandidates:[legacy],selectedAiCandidateId:'legacy'}]);
 const currentStore=store(initial);compileResult=async()=>({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});
 await currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true})).unwrap();
 assert.equal(currentStore.getState().sttmBuilder.mappings[0].status,'MAPPED');
 assert.deepEqual(currentStore.getState().sttmBuilder.mappings[0].aiCandidates,[legacy]);
});

test('actual validation refresh is symmetric, idempotent and survives retry and backend reopen',async()=>{
 const sheet=load(path.join(root,'features/sttm/mapping/sheet-candidates.ts'));
 for(const original of [.99,.2,null]) for(const failure of ['value','source','sql','validation']) for(const extra of ['none','evidence','admission']) {
  const retained=extra==='none'?[]:[{code:extra==='admission'?'capture_validation':'missing_reason',category:extra==='admission'?'validation':'evidence',severity:extra==='admission'?'error':'warning',message:extra==='admission'?'Admission remains required.':'Evidence is limited.'}];
  const candidate={...option(),original_confidence_score:original,adjusted_confidence_score:original,confidence_score:original??0,confidence_reason:'Corresponding name',scoring_issues:retained};
  const current={...blankRow(),...sheet.candidateRowUpdates(candidate),aiCandidates:[candidate]};
  let currentStore=store(state([current]));
  const run=()=>currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'selected',validateOnly:true})).unwrap();
  const failedReply=()=>{if(failure==='validation')throw new Error('Service unavailable');return {valid:false,ready:false,unresolved_placeholders:failure==='value'?['$FIRM']:[],warnings:[failure==='value'?'Required Firm Value is unresolved: $FIRM':failure==='source'?'Source column unavailable':'Rule expression is invalid']};};
  compileResult=async()=>failedReply();await assert.rejects(run());
  let actual=currentStore.getState().sttmBuilder.mappings[0];
  const expected=original===null?null:Math.min(original,failure==='validation'?.69:.49);
  assert.equal(actual.confidenceScore,expected);assert.equal(actual.aiCandidates[0].adjusted_confidence_score,expected);
  assert.equal(actual.aiCandidates[0].original_confidence_score,original);assert.equal(actual.aiCandidates[0].scoring_policy_version,'draft-caps-v1');
  assert.equal(actual.aiCandidates[0].scoring_issues.at(-1).category,failure);assert.deepEqual(actual.draftIssues,actual.aiCandidates[0].scoring_issues);
  assert.match(review.businessReviewText(actual.confidenceReason),/Confidence is limited/);assert.equal(actual.status,'MAPPED');assert.notEqual(actual.validation?.result,'valid');
  const first=JSON.stringify(actual.aiCandidates[0]);await assert.rejects(run());assert.equal(JSON.stringify(currentStore.getState().sttmBuilder.mappings[0].aiCandidates[0]),first);
  currentStore=store(reopenDraft(JSON.parse(JSON.stringify(slice.snapshotFromState(currentStore.getState().sttmBuilder,'workspace.autosaved')))));
  assert.equal(JSON.stringify(currentStore.getState().sttmBuilder.mappings[0].aiCandidates[0]),first);
  compileResult=async()=>({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});await run();
  actual=currentStore.getState().sttmBuilder.mappings[0];
  assert.equal(actual.confidenceScore,original===null?null:Math.min(original,extra==='admission'?.69:extra==='evidence'?.79:1));
  assert.deepEqual(actual.aiCandidates[0].scoring_issues,retained);assert.equal(actual.confidenceReason,'Corresponding name');
  assert.equal(actual.status,'MAPPED');assert.equal(actual.validation?.result==='valid',extra!=='admission');
  assert.equal(actual.aiCandidates[0].confidence_reason,'Corresponding name');
  compileResult=async()=>failedReply();await assert.rejects(run());assert.equal(currentStore.getState().sttmBuilder.mappings[0].confidenceScore,expected);
 }
});

test('unavailable retry never raises a known failure score and confirmation uses the same refresh',async()=>{
 const sheet=load(path.join(root,'features/sttm/mapping/sheet-candidates.ts'));
 const candidate={...option(),original_confidence_score:.99,adjusted_confidence_score:.99,confidence_score:.99};
 const currentStore=store(state([{...blankRow(),...sheet.candidateRowUpdates(candidate),aiCandidates:[candidate]}]));
 const run=confirm=>currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'selected',confirm,validateOnly:!confirm})).unwrap();
 compileResult=async()=>({valid:false,ready:false,unresolved_placeholders:['$FIRM'],warnings:['Required Firm Value is unresolved: $FIRM']});await assert.rejects(run(false));
 compileResult=async()=>{throw new Error('Timeout');};await assert.rejects(run(false));
 let actual=currentStore.getState().sttmBuilder.mappings[0];assert.equal(actual.confidenceScore,.49);assert.equal(actual.status,'MAPPED');
 assert.deepEqual(actual.aiCandidates[0].scoring_issues.map(issue=>issue.category),['value','validation']);
 compileResult=async()=>({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});await run(true);
 actual=currentStore.getState().sttmBuilder.mappings[0];assert.equal(actual.confidenceScore,.99);assert.equal(actual.status,'MAPPED');assert.equal(actual.aiReviewStatus,'confirmed');
 assert.deepEqual(actual.aiCandidates[0].scoring_issues,[]);assert.deepEqual(actual.draftIssues,[]);assert.equal(actual.confidenceReason,'Corresponding name');
});

test('current-definition revalidation updates the actual AI roster rather than a disposable copy',async()=>{
 const sheet=load(path.join(root,'features/sttm/mapping/sheet-candidates.ts'));
 const candidate={...option(),original_confidence_score:.99,adjusted_confidence_score:.99,confidence_score:.99};
 const currentStore=store(state([{...blankRow(),...sheet.candidateRowUpdates(candidate),aiCandidates:[candidate]}]));
 const run=()=>currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true})).unwrap();
 compileResult=async()=>({valid:false,ready:false,unresolved_placeholders:['$FIRM'],warnings:['Required Firm Value is unresolved: $FIRM']});await assert.rejects(run());
 let actual=currentStore.getState().sttmBuilder.mappings[0];assert.equal(actual.confidenceScore,.49);assert.equal(actual.aiCandidates[0].adjusted_confidence_score,.49);
 compileResult=async()=>({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});await run();
 actual=currentStore.getState().sttmBuilder.mappings[0];assert.equal(actual.confidenceScore,.99);assert.equal(actual.aiCandidates[0].adjusted_confidence_score,.99);assert.deepEqual(actual.draftIssues,[]);assert.equal(actual.status,'MAPPED');
});

test('valid but not ready validation is unavailable rather than a proven rule failure',async()=>{
 const sheet=load(path.join(root,'features/sttm/mapping/sheet-candidates.ts'));
 const candidate={...option(),original_confidence_score:.99,adjusted_confidence_score:.99,confidence_score:.99};
 const currentStore=store(state([{...blankRow(),...sheet.candidateRowUpdates(candidate),aiCandidates:[candidate]}]));
 compileResult=async()=>({valid:true,ready:false,unresolved_placeholders:[],warnings:[]});
 await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'selected',validateOnly:true})).unwrap());
 const actual=currentStore.getState().sttmBuilder.mappings[0];assert.equal(actual.confidenceScore,.69);assert.equal(actual.aiCandidates[0].validation_status,'unvalidated');assert.equal(actual.status,'MAPPED');
});

module.exports={load,slice,state,store,validation,context,reopenDraft};

test('presence contract covers legitimate Values, unresolved names and authored rules without categorical or AI guidance maps',()=>{
 for(const definition of [{sourceColumns:['missing.COLUMN']},{mappingMode:'constant',constantValue:false},{mappingMode:'constant',constantValue:0},
  {mappingMode:'constant',constantValue:''},{mappingMode:'attribute',attributeName:'UNRESOLVED'},{expression:'BROKEN('},{nlRule:'Use the household business name'},{rule:'CURRENT_TIMESTAMP()'}]) {
  const current={...blankRow(),...definition};assert.equal(validation.rowMappingStatus(current),'MAPPED');assert.equal(validation.rowValidationIsCurrent(current,'context'),false);
 }
 for(const definition of [{},{mappingMode:'constant',constantValue:null},{mappingMode:'attribute',attributeName:' '},{sourceColumns:[' ']},
  {rule:'Direct'},{rule:'Custom'},{rule:'TRIM'},{candidateSourceColumns:['src.NAME']},{aiSuggestions:[{message:'Use names'}]}]) assert.equal(validation.rowMappingStatus({...blankRow(),...definition}),'UNMAPPED');
});

test('clear removes authored rule text and validation; cancel restores the exact definition',()=>{
 const initial=state([{...row(),nlRule:'Use the business name'}]);
 const cleared=slice.default(initial,slice.bulkClearMappings({ids:['name']}));
 assert.equal(cleared.mappings[0].status,'UNMAPPED');assert.equal(cleared.mappings[0].nlRule,null);assert.equal(cleared.mappings[0].validation,null);
 const restored=slice.default(cleared,slice.cancelPendingManualMappingEdits());assert.equal(validation.rowDefinitionSignature(restored.mappings[0]),validation.rowDefinitionSignature(initial.mappings[0]));assert.deepEqual(restored.mappings[0].validation,initial.mappings[0].validation);
});

test('unvalidated and partially invalid definitions remain visible working text without fabricated executable mappings',()=>{
 const utils=load(path.join(root,'features/sttm/mapping/mapping-utils.ts'));
 const sql=utils.buildWorkingMappingSql({sourceQuerySql:'SELECT * FROM D.S.SOURCE src',mappings:[
  {...blankRow('source','SOURCE'),sourceColumns:['src.NAME']},
  {...blankRow('invalid','INVALID'),expression:'BROKEN('},
  {...blankRow('value','VALUE'),mappingMode:'attribute',attributeName:'MissingFirm'},
  {...blankRow('custom','CUSTOM'),nlRule:'Use the business name',rule:'Custom'},blankRow('blank','BLANK')]});
 assert.match(sql,/src.NAME AS SOURCE/);assert.match(sql,/BROKEN\( AS INVALID/);assert.match(sql,/\$MissingFirm AS VALUE/);
 assert.match(sql,/-- Pending CUSTOM: Use the business name/);assert.doesNotMatch(sql,/<missing expression>|NULL AS|AS BLANK/);
});

test('an untouched AI definition receives the new invalid draft without inheriting its old validation',()=>{
 const initial=state();initial.targetAttributeGroup={qualifiedName:'D.S.TARGET',columns:[{name:'NAME'}]};
 Object.assign(initial.mappings[0],{selectedAiCandidateId:'selected',aiReviewStatus:'unreviewed',aiCandidates:[option()]});
 const proof=structuredClone(initial.mappings[0].validation);
 let next=slice.default(initial,slice.runAutoMap.pending('run',undefined));
 next=slice.default(next,({type:'sttmBuilder/autoMapBatchApplied',payload:{requestId:'run',completedMappingIds:['name'],processedCount:1,totalCount:1,response:{operation:'sttm.auto_map',meta:{automap_sheet_candidates_v1:true,automap_scoring_policy_version:'draft-caps-v1',automap_draft_validation:'draft-caps-v1'},result:{mappings:{NAME:{candidates:[{...option('bad','src.MISSING'),validation_status:'invalid',validation_errors:['Column unavailable']}],suggestions:[{suggestion_id:'business',kind:'business_rule',message:'Review policy',source_references:[]}]}}}}}}));
 assert.equal(next.mappings[0].status,'MAPPED');assert.equal(next.mappings[0].sourceColumn,'src.MISSING');assert.notDeepEqual(next.mappings[0].validation,proof);
 assert.equal(next.mappings[0].validation.result,'failed');assert.deepEqual(next.mappings[0].aiUndoSnapshot.validation,proof);
});
test('the real row validation thunk validates a manual current definition without creating an AI candidate or changing its provenance',async()=>{
 const currentStore=store();const history={...row(),sourceColumn:'src.OLD',sourceColumns:['src.OLD']};
 currentStore.dispatch(slice.updateMapping({id:'name',updates:{sourceColumn:'src.EDIT',sourceColumns:['src.EDIT'],aiUndoSnapshot:history}}));
 const before=currentStore.getState().sttmBuilder.mappings[0];assert.equal(before.status,'MAPPED');
 compileResult=async payload=>{assert.equal(payload.validate_with_explain,true);assert.deepEqual(payload.mappings[0].source_columns,['src.EDIT']);return {valid:true,ready:true,unresolved_placeholders:[],warnings:[]};};
 await currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true})).unwrap();
 const after=currentStore.getState().sttmBuilder.mappings[0];assert.equal(after.status,'MAPPED');assert.equal(after.selectedAiCandidateId,undefined);assert.equal(after.aiCandidates,undefined);assert.deepEqual(after.aiUndoSnapshot,history);
});
test('a late row validation response cannot certify the newer edited definition',async()=>{
 const currentStore=store();currentStore.dispatch(slice.updateMapping({id:'name',updates:{sourceColumn:'src.ONE',sourceColumns:['src.ONE']}}));
 let finish;compileResult=()=>new Promise(resolve=>{finish=resolve;});
 const request=currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true}));
 await new Promise(resolve=>setImmediate(resolve));
 currentStore.dispatch(slice.updateMapping({id:'name',updates:{sourceColumn:'src.TWO',sourceColumns:['src.TWO']}}));
 finish({valid:true,ready:true,unresolved_placeholders:[],warnings:[]});await assert.rejects(request.unwrap(),error=>/inputs changed/.test(error.message));
 const after=currentStore.getState().sttmBuilder.mappings[0];assert.equal(after.sourceColumn,'src.TWO');assert.equal(after.status,'MAPPED');assert.equal(validation.rowValidationIsCurrent(after,context.selectionValidationSignature(currentStore.getState().sttmBuilder)),false);
});
test('source validation and row proofs survive canonical backend snapshot serialization',()=>{
 const initial=state();initial.validationValuesSignature='authoritative-values';
 const signature=context.selectionValidationSignature(initial);initial.sourceValidation={contextSignature:signature,previewKey:'preview',valid:true,synced:true};
 initial.mappings[0].validation=validation.validatedRow(initial.mappings[0],signature);
 const snapshot=slice.snapshotFromState(initial,'manual.save');
 assert.equal(snapshot.validation_values_signature,'authoritative-values');assert.deepEqual(context.readSourceValidation(snapshot.validation_history),initial.sourceValidation);assert.deepEqual(snapshot.mapping_rows[0].validation,initial.mappings[0].validation);
});

function expression(source,name){let found;function visit(node){if(ts.isVariableDeclaration(node)&&node.name.getText(source)===name)found=node.initializer;ts.forEachChild(node,visit);}visit(source);assert.ok(found,name);return found.getText(source);}
function evaluate(source,bindings){const module={exports:{}};const js=ts.transpileModule('module.exports = '+source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;new Function('module',...Object.keys(bindings),js)(module,...Object.values(bindings));return module.exports;}
const flowFile=path.join(root,'features/sttm/source-target/table-relationship-flow.tsx');
const flow=ts.createSourceFile(flowFile,fs.readFileSync(flowFile,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const navigation=load(path.join(root,'features/sttm/mapping/review-navigation.ts'));
function joinCallbacks(initial){
 let modal;function visit(node){if((ts.isJsxSelfClosingElement(node)||ts.isJsxOpeningElement(node))&&node.tagName.getText(flow)==='JoinModal')modal=node;ts.forEachChild(node,visit);}visit(flow);assert.ok(modal);
 const calls=[];const saved={current:null};const session=new Map();const intent={id:'intent',suggestionId:'join-1',mappingId:'name',base:'/sttm/builder/mapping'};
 const bindings={rowJoinIntent:intent,savedRowJoinIntent:saved,setIsJoinModalOpen:()=>{},setEditingJoin:()=>{},setJoinState:()=>{throw new Error('Legacy SQL-mutating save must not run');},saveReviewedJoin:join=>calls.push(['save',join]),refreshAssistantSignals:()=>{},reviewRouter:{push:url=>calls.push(['navigate',url])},rowReviewUrl:navigation.rowReviewUrl,JOIN_REVIEW_KEY:navigation.JOIN_REVIEW_KEY,window:{setTimeout:()=>{},sessionStorage:{setItem:(key,value)=>session.set(key,value),removeItem:key=>session.delete(key)}}};
 const callback=name=>evaluate(modal.attributes.properties.find(item=>item.name?.text===name).initializer.expression.getText(flow),bindings);
 return{close:callback('onClose'),confirm:callback('onConfirm'),calls,session,saved};
}
test('canceling the actual join editor writes no sources, relationships or mapping and returns to the row',()=>{
 const callbacks=joinCallbacks(state());callbacks.close();assert.deepEqual(callbacks.calls,[['navigate','/sttm/builder/mapping/mapping?reviewRow=name&reviewSection=suggestions']]);assert.equal(callbacks.saved.current,null);
});
test('the join editor Save followed by its normal Close retains saved navigation and offers reevaluation',()=>{
 const callbacks=joinCallbacks(state());const join={id:'j',leftTableId:'source',rightTableId:'lookup',joinType:'LEFT',conditions:[{leftColumn:'ID',operator:'=',rightColumn:'ID'}]};
 callbacks.confirm(join);callbacks.close();assert.equal(callbacks.calls.filter(item=>item[0]==='save').length,1);assert.equal(callbacks.calls.filter(item=>item[0]==='navigate').length,1);
 assert.match(callbacks.calls.at(-1)[1],/joinReviewed=1$/);assert.equal(JSON.parse(callbacks.session.get(navigation.JOIN_REVIEW_KEY)).status,'saved');
});
test('opening the real recommendation hook only stores a scoped navigation intent, without dispatching source selection',()=>{
 const initial=state();initial.sources.push({...table('lookup'),isSelected:false});const before=JSON.stringify(initial);const writes=[];
 const file=path.join(root,'features/sttm/mapping/use-row-join-review.ts');const loaded=new Module(file,module);
 loaded.require=name=>name==='next/navigation'?{useRouter:()=>({push:url=>writes.push(url)})}:name.endsWith('sttm-builder-context')?{useSttmBuilderContext:()=>({...initial,fullData:{sources:[]},selectJoinReviewSources:()=>{throw new Error('Provisional selection was persisted');}})}:navigation;
 loaded._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);
 const previous=global.window;global.window={location:{pathname:'/sttm/builder/mapping/mapping'},sessionStorage:{setItem:(key,value)=>writes.push(JSON.parse(value))}};
 try{loaded.exports.useRowJoinReview()(initial.mappings[0],{suggestion_id:'join-1',kind:'relationship',message:'Use known lookup',join_recommendation:{left_relation_id:'source',right_relation_id:'lookup'}});}finally{global.window=previous;}
 assert.equal(JSON.stringify(initial),before);assert.equal(writes[0].recommendation.right_relation_id,'lookup');assert.equal(writes[1],'/sttm/builder/mapping?joinReview=1');
});
const filterFile=path.join(root,'features/sttm/source-target/filter-conditions.tsx');
const filters=ts.createSourceFile(filterFile,fs.readFileSync(filterFile,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
function selectionValidator(){
 let resolve;const gates=[];const latest={current:'revision'};
 const bindings={validationRevision:'revision',validationSequence:{current:0},latestValidationRevision:latest,setValidatedGateKey:()=>{},requireSyncForNext:true,setSourcePreviewGate:gate=>gates.push(gate),isLoadingProjectAttributes:false,projectAttributesError:null,editablePreviewSql:'SELECT 1',setPreviewValidation:()=>{},setValidatedPreview:()=>{},effectiveSqlCatalog:[],drivingTableId:null,relationships:[],rootGroups:[],setIsValidatingPreview:()=>{},dbService:{validateDerivedSource:()=>new Promise(done=>{resolve=done;})},sourceValidationSignature:'context',previewGateKey:'preview',hasPreviewChanges:false,getApiErrorMessage:error=>error.message};
 const validate=evaluate(expression(filters,'handleValidatePreviewSql'),bindings);return{validate,gates,latest,complete:result=>resolve(result)};
}
test('the real selection validator ignores a late successful response from an older SQL/dependency revision',async()=>{
 const validator=selectionValidator();const request=validator.validate();validator.latest.current='newer-revision';validator.complete({valid:true,preview_rows:[]});assert.equal(await request,false);assert.equal(validator.gates.some(gate=>gate.persist&&gate.validated),false);
});
test('selection validation persists its exact successful revision and stores failures as disabled gates',async()=>{
 for(const valid of [true,false]){const validator=selectionValidator();const request=validator.validate();validator.complete({valid,preview_rows:[]});assert.equal(await request,valid);const receipt=validator.gates.findLast(gate=>gate.persist);assert.deepEqual(receipt,{validated:valid,synced:valid,contextSignature:'context',previewKey:'preview',persist:true});}
});

function effectContaining(source,text){let result;function visit(node){if(ts.isCallExpression(node)&&/^(React\.)?useEffect$/.test(node.expression.getText(source))&&node.arguments[0]?.getText(source).includes(text))result=node.arguments[0].getText(source);ts.forEachChild(node,visit);}visit(source);assert.ok(result,text);return result;}
test('the selection gate restores a saved valid context on navigation and cancel, and rejects changed dependencies or failures',()=>{
 const effect=effectContaining(filters,'const restored');
 const run=changes=>{const gates=[];const keys=[];evaluate(effect,{requireSyncForNext:true,syncApplied:false,sourceValidationSignature:'current',previewGateKey:'preview',isSyncingPreview:false,hasPreviewChanges:false,isLoadingProjectAttributes:false,projectAttributesError:null,sourceValidation:{contextSignature:'current',valid:true,synced:true},validatedGateKey:null,setValidatedGateKey:key=>keys.push(key),setSourcePreviewGate:gate=>gates.push(gate),setSyncApplied:()=>{},...changes})();return{gates,keys};};
 assert.equal(run({}).gates.at(-1).validated,true);
 assert.equal(run({hasPreviewChanges:true}).gates.at(-1).validated,false);
 assert.equal(run({sourceValidationSignature:'edited'}).gates.at(-1).validated,false);
 assert.equal(run({sourceValidation:{contextSignature:'current',valid:false,synced:false}}).gates.at(-1).validated,false);
 assert.equal(run({sourceValidation:null}).gates.at(-1).validated,false);
 assert.equal(run({isLoadingProjectAttributes:true}).gates.at(-1).validated,false);
 assert.equal(run({previewGateKey:'reopened-preview'}).gates.at(-1).validated,true);
 assert.equal(run({}).gates.at(-1).validated,true,'cancel to the original context restores eligibility');
});
test('filter/query hydration effects do not emit persisted edits on mount; user revisions still emit once',()=>{
 const filterEffect=effectContaining(filters,'onChangeRef.current?.');const queryEffect=effectContaining(filters,'onQueryChangeRef.current?.');
 const emittedFilterRevision={current:0},filterEditRevision={current:0},emittedQueryRevision={current:0},queryEditRevision={current:0};const writes=[];
 const bindings={emittedFilterRevision,filterEditRevision,emittedQueryRevision,queryEditRevision,rootGroups:[],generateSQL:()=>'',onChangeRef:{current:()=>writes.push('filters')},onQueryChangeRef:{current:()=>writes.push('query')},groupByItems:[],orderByItems:[],groupBySql:'',orderBySql:''};
 const filter=evaluate(filterEffect,bindings),query=evaluate(queryEffect,bindings);filter();query();assert.deepEqual(writes,[]);
 filterEditRevision.current=1;queryEditRevision.current=1;filter();query();filter();query();assert.deepEqual(writes,['filters','query']);
});

test('backend reopen preserves the exact selection receipt and row status for physical joins and CTE contexts',()=>{
 for(const derived of [false,true,'cte-only']){
  const initial=state();initial.sources=[table('D.S.ACCOUNTS','ACCOUNTS'),table('D.S.LOOKUP','LOOKUP')];initial.targets=[table('D.S.TARGET','TARGET')];initial.drivingTableId='D.S.ACCOUNTS';
  initial.relationships=[{id:'existing',leftTableId:'D.S.ACCOUNTS',rightTableId:'D.S.LOOKUP',joinType:'LEFT',conditions:[{leftColumn:'ID',rightColumn:'ID',operator:'='}]}];
  initial.sourceQuerySql='SELECT * FROM D.S.ACCOUNTS LEFT JOIN D.S.LOOKUP ON ACCOUNTS.ID = LOOKUP.ID';
  if(derived){initial.derivedSources=[{id:'sql-cte:cte',sourceName:'authored_cte',isSelected:true,sqlText:'SELECT NAME FROM D.S.ACCOUNTS',joins:[],filters:[],columns:[{name:'NAME',type:'VARCHAR'}]}];initial.drivingTableId='sql-cte:cte';}
  if(derived==='cte-only'){initial.sources=[];initial.relationships=[];initial.derivedSources[0].sqlText="SELECT 'Name' AS NAME";initial.sourceQuerySql="WITH authored_cte AS (SELECT 'Name' AS NAME) SELECT * FROM authored_cte";}
  const signature=context.selectionValidationSignature(initial);initial.sourceValidation={contextSignature:signature,previewKey:'validated',valid:true,synced:true};initial.mappings[0].validation=validation.validatedRow(initial.mappings[0],signature);
  const snapshot=slice.snapshotFromState(initial,'manual.save');const args={projectId:'project',sttmId:'mapping'};
  let reopened=slice.default(undefined,slice.openSttmFromBackend.pending('open',args));
  reopened=slice.default(reopened,slice.openSttmFromBackend.fulfilled({projectId:'project',sttmId:'mapping',detail:{latest_snapshot:snapshot,sources:[],mapping_rows:snapshot.mapping_rows,sttm:{sttm_name:'Saved mapping',project_id:'project'},project:{project_name:'Project'}}},'open',args));
  assert.equal(context.selectionValidationSignature(reopened),signature,derived?'CTE dependencies':'physical dependencies');assert.deepEqual(reopened.sourceValidation,initial.sourceValidation);assert.equal(reopened.mappings[0].status,'MAPPED');
 }
});

function reopenDraft(snapshot, normalizedOnly=false) {
 const args={projectId:'project',sttmId:'mapping'};
 let reopened=slice.default(undefined,slice.openSttmFromBackend.pending('open',args));
 const latest={...snapshot};if(normalizedOnly)delete latest.mapping_rows;
 return slice.default(reopened,slice.openSttmFromBackend.fulfilled({projectId:'project',sttmId:'mapping',detail:{latest_snapshot:latest,
  sources:[],mapping_rows:snapshot.mapping_rows,sttm:{sttm_name:'Draft',project_id:'project'},project:{project_name:'Project'}}},'open',args));
}
test('invalid explicit manual save remains owned through snapshot and normalized reopen, navigation and later AI delivery',()=>{
 for(const normalizedOnly of [false,true]) {
  let initial=state([{...row(),status:'NEEDS_VALIDATION',confidenceScore:.49,confidenceReason:'Original reasoning',
   aiCandidates:[{...option(),original_confidence_score:.95,adjusted_confidence_score:.49,scoring_policy_version:'draft-caps-v1',
    scoring_issues:[{code:'sql',message:'Incomplete SQL',category:'sql',severity:'error'}]}],aiReviewStatus:'unreviewed',selectedAiCandidateId:'selected'}]);
  initial.sources=[table('D.S.ACCOUNTS','ACCOUNTS')];initial.drivingTableId='D.S.ACCOUNTS';
  initial=slice.default(initial,slice.updateMapping({id:'name',updates:{sourceColumn:'missing.NAME',sourceColumns:['missing.NAME'],sourceDependencies:['missing.NAME'],
   expression:'CASE WHEN missing.NAME = $MISSING',rule:'Custom',proposedSqlSource:'SELECT missing.NAME',
   draftIssues:[{code:'missing_project_value',message:'Missing Value',category:'value',severity:'error'}]}}));
  assert.ok(initial.pendingManualEditSnapshots.name);
  initial=slice.default(initial,slice.commitPendingManualMappingEdits());
  const saved=initial.mappings[0];assert.equal(saved.manuallySaved,true);assert.equal(saved.manuallyEditedAfterAutoMap,true);
  assert.notEqual(saved.aiReviewStatus,'confirmed');assert.equal(saved.status,'MAPPED');assert.notEqual(saved.validation?.result,'valid');assert.equal(saved.confidenceReason,'Original reasoning');
  assert.deepEqual(initial.pendingManualEditSnapshots,{});
  for(let count=0;count<3;count++) {
   const snapshot=JSON.parse(JSON.stringify(slice.snapshotFromState(initial,'workspace.autosaved')));
   initial=reopenDraft(snapshot,normalizedOnly);
   const actual=initial.mappings[0];
   for(const key of ['expression','sourceColumns','sourceDependencies','proposedSqlSource','confidenceScore','confidenceReason','aiCandidates','draftIssues','manuallySaved','manuallyEditedAfterAutoMap'])assert.deepEqual(actual[key],saved[key],key);
   assert.equal(actual.status,'MAPPED');assert.notEqual(actual.validation?.result,'valid');assert.notEqual(actual.validation?.result,'valid');assert.notEqual(actual.aiReviewStatus,'confirmed');
   assert.equal(actual.reconciliationWarnings.length,1);assert.match(actual.reconciliationWarnings[0],/missing.NAME/);
   assert.ok(!review.guidanceForRow(actual).some(item=>item.message==='Missing Value'));
 assert.ok(actual.validation?.error || actual.draftIssues?.length || actual.reconciliationWarnings?.length, 'manual validation remains recorded independently of AI suggestions');
   initial=slice.default(initial,slice.hydrateBuilderSession(JSON.parse(JSON.stringify(initial))));
  }
  const delivered=applyDraft(initial,draftResponse([option('new','D.S.ACCOUNTS.NAME')]));
  assert.equal(delivered.mappings[0].expression,saved.expression);assert.equal(delivered.mappings[0].manuallySaved,true);
 }
});
test('reopen does not turn whole-field manual or confirmed flags into row approval',()=>{
 const initial=state([{...row(),status:'NEEDS_VALIDATION',manuallySaved:true,aiReviewStatus:'confirmed'}]);
 const snapshot=slice.snapshotFromState(initial,'workspace.autosaved');
 snapshot.mapping_rows[0].status='MAPPED';snapshot.mapping_rows[0].accepted=true;snapshot.mapping_rows[0].published=true;
 const restored=reopenDraft(snapshot);assert.equal(restored.mappings[0].status,'MAPPED');assert.equal(restored.mappings[0].validation,null);
});

test('a stale selected candidate ID cannot invalidate a different current definition',async()=>{
 const initial=state();Object.assign(initial.mappings[0],{selectedAiCandidateId:'stale',aiCandidates:[option('stale','src.OLD')]});
 const currentStore=store(initial);compileResult=async()=>({valid:false,ready:false,unresolved_placeholders:[],warnings:['Invalid old option']});
 await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'stale',validateOnly:true})).unwrap(),error=>/Invalid old option/.test(error.message));
 const result=currentStore.getState().sttmBuilder.mappings[0];assert.equal(result.status,'MAPPED');assert.deepEqual(result.validation,initial.mappings[0].validation);assert.equal(result.aiCandidates[0].validation_status,'invalid');
});

test('validation checks the exact legacy rule definition without silently rewriting executable fields',async()=>{
 const initial=state([{...row(),status:'UNMAPPED',sourceColumn:null,sourceColumns:[],rule:'CURRENT_TIMESTAMP()',expression:null}]);const currentStore=store(initial);
 compileResult=async payload=>{assert.equal(payload.mappings[0].expression,null);assert.equal(payload.mappings[0].rule,'CURRENT_TIMESTAMP()');return {valid:false,ready:false,unresolved_placeholders:[],warnings:['Rule requires an expression']};};
 await assert.rejects(currentStore.dispatch(slice.selectSheetCandidate({mappingId:'name',candidateId:'__current_definition__',validateOnly:true})).unwrap(),error=>/requires an expression/.test(error.message));
 assert.equal(currentStore.getState().sttmBuilder.mappings[0].status,'MAPPED');assert.equal(currentStore.getState().sttmBuilder.mappings[0].rule,'CURRENT_TIMESTAMP()');
});

test('working SQL keeps unresolved evidence IDs out of projections while preserving authored literal values',()=>{
 const utils=load(path.join(root,'features/sttm/mapping/mapping-utils.ts'));
 const sql=utils.buildWorkingMappingSql({sourceQuerySql:'SELECT * FROM D.S.SOURCE a',mappings:[
  {...blankRow('id','ID'),sourceColumns:['src:unknown.NAME']},
  {...blankRow('literal','LITERAL'),expression:"'src:customer'"},
  {...blankRow('ready','READY'),sourceColumns:['a.NAME']} ]});
 assert.match(sql,/-- Pending ID:/);assert.doesNotMatch(sql,/src:unknown\.NAME AS/);
 assert.match(sql,/'src:customer' AS LITERAL/);assert.match(sql,/a.NAME AS READY/);
});

test('calculated confidence survives local revalidation without repeated caps or a model score',()=>{
 const sheet=load(path.join(root,'features/sttm/mapping/sheet-candidates.ts'));
 const candidate={...option(),original_confidence_score:null,confidence_score:.82,adjusted_confidence_score:.82,
  confidence_policy_version:'evidence-v1',confidence_provenance:{score_source:'backend_evidence_fallback',evidence_estimate:.82},
  scoring_policy_version:sheet.DRAFT_SCORING_POLICY,scoring_issues:[]};
 assert.equal(sheet.candidateConfidence(candidate),.82);
 const failed=sheet.refreshCandidateValidation(candidate,{reason:'missing source',category:'source'});
 assert.equal(sheet.candidateConfidence(failed),.49);
 const restored=sheet.refreshCandidateValidation(failed);
 assert.equal(sheet.candidateConfidence(restored),.82);
 assert.equal(sheet.refreshCandidateValidation(restored).confidence_score,.82);
 assert.equal(restored.original_confidence_score,null);
});


test('source hydration bounds batches, retains partial successes and clears per-table errors after retry',async()=>{
 const initial=state();initial.sources=Array.from({length:57},(_,i)=>table(`source${i}`,`T${i}`));
 const current=store(initial);let active=0,maxActive=0;const sizes=[];let failing=true;
 attributesResult=async names=>{sizes.push(names.length);active++;maxActive=Math.max(maxActive,active);try{
  await new Promise(resolve=>setTimeout(resolve,1));
  if(failing&&names.includes('D.S.T27'))throw new Error('inaccessible table');
  return names.map(name=>({table:{database:'D',schema:'S',table:name.split('.')[2]},columns:[{column_name:'ID',data_type:'NUMBER'}]}));
 }finally{active--;}};
 await current.dispatch(slice.fetchAttributes({qualifiedNames:initial.sources.map(table=>table.qualifiedName),side:'source'}));
 let result=current.getState().sttmBuilder;
 assert.equal(result.sourceAttributeGroups.length,56);assert.equal(result.attributeErrors['D.S.T27'],'inaccessible table');
 assert.ok(sizes.every(size=>size<=25));assert.ok(maxActive<=2);
 failing=false;await current.dispatch(slice.fetchAttributes({qualifiedNames:['D.S.T27'],side:'source'}));
 result=current.getState().sttmBuilder;assert.equal(result.sourceAttributeGroups.length,57);assert.equal(result.attributeErrors['D.S.T27'],undefined);
});

test('catalog count hydration preserves zero counts and ignores results after mapping changes',async()=>{
 const current=store(state());let release;
 tablesResult=async()=>[{table_name:'source',row_count:0,column_count:37}];
 await current.dispatch(slice.fetchSelectedTableCounts(['D.S.source']));
 assert.equal(current.getState().sttmBuilder.sources[0].rows,'0');assert.equal(current.getState().sttmBuilder.sources[0].columns,37);
 const delayed=store(state());tablesResult=()=>new Promise(resolve=>{release=resolve;});
 const task=delayed.dispatch(slice.fetchSelectedTableCounts(['D.S.source']));
 delayed.dispatch(slice.openSttmFromBackend.pending('next',{sttmId:'different'}));
 release([{table_name:'source',row_count:999,column_count:99}]);await task;
 assert.equal(delayed.getState().sttmBuilder.sources.length,0);
});

test('metadata loading stays active until every concurrent request finishes',async()=>{
 const current=store(state());const releases={};
 attributesResult=names=>new Promise(resolve=>{releases[names[0]]=()=>resolve(names.map(name=>({table:{database:'D',schema:'S',table:name.split('.')[2]},columns:[{column_name:'ID',data_type:'NUMBER'}]})));});
 const first=current.dispatch(slice.fetchAttributes({qualifiedNames:['D.S.first'],side:'source'}));
 const second=current.dispatch(slice.fetchAttributes({qualifiedNames:['D.S.second'],side:'source'}));
 releases['D.S.first']();await first;
 assert.equal(current.getState().sttmBuilder.loadState.attributes,'loading');
 releases['D.S.second']();await second;
 assert.equal(current.getState().sttmBuilder.loadState.attributes,'success');
});
