from __future__ import annotations

from datetime import datetime
from io import BytesIO
from typing import Any

from snowflake.snowpark import Session

from app.core.exceptions import SnowflakeQueryError
from app.schema.export_workbook import WorkbookExportRequest
from app.schema.mapping_sql import MappingSqlPreviewRow


class WorkbookExportService:
    def __init__(self, *, session: Session) -> None:
        self._session = session

    def build_workbook(self, body: WorkbookExportRequest) -> bytes:
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
            from openpyxl.utils import get_column_letter
        except ImportError as exc:  # pragma: no cover - environment guard
            raise RuntimeError(
                "Excel export dependencies are not installed. Install 'openpyxl' in services/sttm-builder/.venv to enable workbook downloads."
            ) from exc

        header_fill = PatternFill("solid", fgColor="D9EAF7")
        section_fill = PatternFill("solid", fgColor="EEF6FF")
        thin_border = Border(
            left=Side(style="thin", color="D1D5DB"),
            right=Side(style="thin", color="D1D5DB"),
            top=Side(style="thin", color="D1D5DB"),
            bottom=Side(style="thin", color="D1D5DB"),
        )
        base_font = Font(name="Arial", size=10)
        header_font = Font(name="Arial", size=10, bold=True, color="1F2937")
        title_font = Font(name="Arial", size=13, bold=True, color="111827")

        workbook = Workbook()
        summary_sheet = workbook.active
        summary_sheet.title = "Summary"
        derived_sheet = workbook.create_sheet("Derived Sources")
        sttm_sheet = workbook.create_sheet("STTM")
        sql_sheet = workbook.create_sheet("Generated SQL")

        preview_rows = self._preview_rows(body.preview_sql)
        preview_values = [row.values for row in preview_rows]

        self._build_summary_sheet(summary_sheet, body, title_font, header_font, base_font)
        self._build_derived_sheet(
            derived_sheet,
            body,
            get_column_letter,
            title_font,
            header_font,
            base_font,
            section_fill,
            header_fill,
            thin_border,
        )
        self._build_sttm_sheet(
            sttm_sheet,
            body,
            preview_values,
            get_column_letter,
            title_font,
            header_font,
            base_font,
            section_fill,
            header_fill,
            thin_border,
        )
        self._build_sql_sheet(
            sql_sheet,
            body,
            title_font,
            base_font,
            section_fill,
            thin_border,
        )

        buffer = BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()

    def _preview_rows(self, preview_sql: str) -> list[MappingSqlPreviewRow]:
        sql_text = (preview_sql or "").strip().rstrip(";")
        if not sql_text or sql_text.startswith("--"):
            return []
        try:
            dataframe = self._session.sql(f"SELECT * FROM ({sql_text}) AS EXPORT_PREVIEW LIMIT 2")
            return [
                MappingSqlPreviewRow(values=row.as_dict(recursive=True))
                for row in dataframe.collect()
            ]
        except Exception as exc:
            raise SnowflakeQueryError(
                f"Failed to load preview sample rows for the workbook export: {exc}"
            ) from exc

    def _build_summary_sheet(self, sheet, body: WorkbookExportRequest, title_font, header_font, base_font) -> None:
        rows = [
            ("STTM Export Summary", None),
            ("Project", body.project_name or "STTM Export"),
            ("Created by", body.created_by or "Unknown"),
            ("Generated at", body.created_at or datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")),
            ("Version details", body.version_label or "Current builder session"),
            ("Target table", body.target_table.qualified_name if body.target_table else "Not selected"),
            ("Source tables", ", ".join(table.qualified_name for table in body.source_tables) or "None"),
            ("Overview", body.summary_narrative or "Summary narrative not available."),
        ]
        for idx, (label, value) in enumerate(rows, start=1):
            cell_a = sheet.cell(row=idx, column=1, value=label)
            cell_b = sheet.cell(row=idx, column=2, value=value)
            cell_a.font = title_font if idx == 1 else header_font
            cell_b.font = base_font
        sheet.column_dimensions["A"].width = 22
        sheet.column_dimensions["B"].width = 96

    def _build_derived_sheet(self, sheet, body: WorkbookExportRequest, get_column_letter, title_font, header_font, base_font, section_fill, header_fill, thin_border) -> None:
        row = 1
        row = self._write_section_title(sheet, row, "Derived sources", title_font, section_fill)
        derived_headers = [
            "Derived Source Name",
            "Source Tables",
            "Base Source Tables",
            "Semantic View",
            "Semantic Bundle",
            "SQL",
        ]
        row = self._write_table_header(sheet, row, derived_headers, header_font, header_fill, thin_border)
        derived_items = body.derived_sources or []
        if derived_items:
            for item in derived_items:
                values = [
                    item.derived_source_name,
                    ", ".join(table.qualified_name for table in item.source_tables),
                    ", ".join(table.qualified_name for table in item.base_source_tables),
                    item.semantic_view_name or "",
                    item.semantic_bundle_label or "",
                    item.sql_text or "",
                ]
                self._write_row(sheet, row, values, base_font, thin_border)
                row += 1
        else:
            self._write_row(sheet, row, ["No derived sources selected.", "", "", "", "", ""], base_font, thin_border)
            row += 1

        row += 1
        row = self._write_section_title(sheet, row, "Source relationships", title_font, section_fill)
        relationship_headers = [
            "Left Table",
            "Join Type",
            "Right Table",
            "Join Conditions",
            "Constraint Name",
            "Source",
        ]
        row = self._write_table_header(sheet, row, relationship_headers, header_font, header_fill, thin_border)
        if body.relationships:
            for relationship in body.relationships:
                conditions = ", ".join(
                    f"{condition.left_column} {condition.operator} {condition.right_column}"
                    for condition in relationship.conditions
                )
                self._write_row(
                    sheet,
                    row,
                    [
                        relationship.left_table.qualified_name,
                        relationship.join_type,
                        relationship.right_table.qualified_name,
                        conditions,
                        relationship.constraint_name or "",
                        relationship.source or "",
                    ],
                    base_font,
                    thin_border,
                )
                row += 1
        else:
            self._write_row(sheet, row, ["No join relationships available.", "", "", "", "", ""], base_font, thin_border)
            row += 1

        for idx, width in enumerate([34, 12, 34, 48, 20, 16], start=1):
            sheet.column_dimensions[get_column_letter(idx)].width = width

    def _build_sttm_sheet(self, sheet, body: WorkbookExportRequest, preview_values: list[dict[str, Any]], get_column_letter, title_font, header_font, base_font, section_fill, header_fill, thin_border) -> None:
        row = 1
        row = self._write_section_title(sheet, row, "List of different sources join conditions", title_font, section_fill)
        row = self._write_table_header(
            sheet,
            row,
            ["Source Table", "Target Table", "Join Type", "Join Condition"],
            header_font,
            header_fill,
            thin_border,
        )
        if body.relationships:
            for relationship in body.relationships:
                self._write_row(
                    sheet,
                    row,
                    [
                        relationship.left_table.qualified_name,
                        relationship.right_table.qualified_name,
                        relationship.join_type,
                        ", ".join(
                            f"{condition.left_column} {condition.operator} {condition.right_column}"
                            for condition in relationship.conditions
                        ),
                    ],
                    base_font,
                    thin_border,
                )
                row += 1
        else:
            self._write_row(sheet, row, ["No joins configured.", "", "", ""], base_font, thin_border)
            row += 1

        row += 1
        row = self._write_section_title(sheet, row, "Filters that should be applied", title_font, section_fill)
        row = self._write_table_header(sheet, row, ["Filters"], header_font, header_fill, thin_border)
        self._write_row(sheet, row, [body.filters_sql or "No filters configured."], base_font, thin_border)
        row += 2

        row = self._write_section_title(sheet, row, "Target mappings", title_font, section_fill)
        headers = [
            "id",
            "Partner",
            "Schema",
            "Target Table Name",
            "Target Field Name",
            "Target Field Data Type",
            "pk?",
            "contains_pii",
            "Field Type",
            "Field Depends On",
            "Processing Order",
            "Pre Processing Rules",
            "Source Field Names",
            "Source Dataset Name",
            "Field Definition",
            "Example 1",
            "Example 2",
        ]
        row = self._write_table_header(sheet, row, headers, header_font, header_fill, thin_border)
        target_schema = body.target_table.schema if body.target_table else ""
        target_table_name = body.target_table.table if body.target_table else ""
        mappings = [mapping for mapping in body.mappings if (mapping.status or "").upper() == "MAPPED"]
        for index, mapping in enumerate(mappings, start=1):
            source_columns = mapping.source_columns or []
            if not source_columns and mapping.source_column:
                source_columns = [part.strip() for part in mapping.source_column.split(",") if part.strip()]
            if not source_columns:
                source_columns = [""]
            start_row = row
            example_1 = preview_values[0].get(mapping.target_column) if len(preview_values) > 0 else ""
            example_2 = preview_values[1].get(mapping.target_column) if len(preview_values) > 1 else ""
            for source_idx, source_column in enumerate(source_columns):
                dataset_name = ".".join(source_column.split(".")[:-1]) if "." in source_column else ""
                values = [
                    index if source_idx == 0 else "",
                    body.project_name or "",
                    target_schema if source_idx == 0 else "",
                    target_table_name if source_idx == 0 else "",
                    mapping.target_column if source_idx == 0 else "",
                    mapping.target_type if source_idx == 0 else "",
                    "No" if source_idx == 0 else "",
                    "" if source_idx == 0 else "",
                    ("TRANSFORMED" if mapping.expression or (mapping.rule and mapping.rule not in {"Direct", "Select..."}) else "RAW") if source_idx == 0 else "",
                    ", ".join(source_columns) if source_idx == 0 else "",
                    mapping.nl_rule or "" if source_idx == 0 else "",
                    (mapping.expression or mapping.rule or "") if source_idx == 0 else "",
                    source_column,
                    dataset_name,
                    mapping.description or "" if source_idx == 0 else "",
                    example_1 if source_idx == 0 else "",
                    example_2 if source_idx == 0 else "",
                ]
                self._write_row(sheet, row, values, base_font, thin_border)
                row += 1
            if row - start_row > 1:
                for column in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 16, 17):
                    sheet.merge_cells(start_row=start_row, start_column=column, end_row=row - 1, end_column=column)

        widths = [8, 20, 18, 24, 24, 18, 8, 12, 14, 22, 18, 24, 26, 26, 32, 16, 16]
        for idx, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(idx)].width = width

    def _build_sql_sheet(self, sheet, body: WorkbookExportRequest, title_font, base_font, section_fill, thin_border) -> None:
        row = 1
        row = self._write_section_title(sheet, row, "Source query foundation", title_font, section_fill)
        for line in (body.source_query_sql or "No source query SQL available.").splitlines() or [""]:
            self._write_row(sheet, row, [line], base_font, thin_border)
            row += 1
        row += 1
        row = self._write_section_title(sheet, row, "Generated SQL", title_font, section_fill)
        for line in (body.generated_sql or "No generated SQL available.").splitlines() or [""]:
            self._write_row(sheet, row, [line], base_font, thin_border)
            row += 1
        sheet.column_dimensions["A"].width = 120

    def _write_section_title(self, sheet, row: int, title: str, title_font, section_fill) -> int:
        cell = sheet.cell(row=row, column=1, value=title)
        cell.font = title_font
        cell.fill = section_fill
        sheet.merge_cells(start_row=row, start_column=1, end_row=row, end_column=6)
        return row + 1

    def _write_table_header(self, sheet, row: int, headers: list[str], header_font, header_fill, thin_border) -> int:
        for index, header in enumerate(headers, start=1):
            cell = sheet.cell(row=row, column=index, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = thin_border
        return row + 1

    def _write_row(self, sheet, row: int, values: list[Any], base_font, thin_border) -> None:
        for index, value in enumerate(values, start=1):
            cell = sheet.cell(row=row, column=index, value=value)
            cell.font = base_font
            cell.border = thin_border
