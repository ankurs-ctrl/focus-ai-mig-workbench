"""V3 semantic fidelity, retrieval, packet and runtime boundaries (offline)."""
from copy import deepcopy
import json
from types import SimpleNamespace
import pytest

from app.core.automap_semantic_catalog import hydrate_registry_yaml, build_catalog, catalog_entry
from app.core.automap_candidates import rank_candidates
from app.core.automap_context_packer import pack_context, ContextBudgetError, shared_capsule
from app.core.automap_learning_pack import select_learning_pack, AutoMapLearningPack
from app.core.automap_citations import citation_deficits
from app.core.automap_json import load_json, variant_parameter
from app.schema.sttm_builder import AttributeMapping

YAML = '''tables:
- name: ACCOUNTS
  base_table: {database: D, schema: CRM, table: ACCOUNTS}
  description: Household relationship records at one row per household.
  dimensions:
  - name: household_label
    expr: HH_LABEL
    description: Display name of the household relationship, excluding account numbers.
    synonyms: [household name, family name]
    sample_values: [Smith Family, Jones Household]
    data_type: VARCHAR
  time_dimensions:
  - {name: closed, expr: CLOSED_AT, description: Date the household relationship ended., data_type: DATE}
  facts:
  - {name: assets, expr: ASSETS, description: Total assets belonging to the household., data_type: NUMBER}
  metrics:
  - {name: total_assets, expr: SUM(ASSETS), description: Aggregated assets.}
'''


def local_binding_service():
    def session(token, **identity_changes):
        identity = dict(NATIVE_USER='ANKURSINHA', ROLE_NAME='DEV_ROLE',
                        ACCOUNT_NAMESPACE='MHSUEJT.GD01711', TRANSACTION_ID=None)
        identity.update(identity_changes)
        return SimpleNamespace(
            sql=lambda _: SimpleNamespace(collect=lambda **_: [identity]),
            _conn=SimpleNamespace(_conn=SimpleNamespace(
                _rest=SimpleNamespace(_token=token), host='mhsuejt-gd01711.snowflakecomputing.com',
                account='MHSUEJT-GD01711')))
    return SimpleNamespace(
        _settings=SimpleNamespace(app_env='local', local_dev_auth_enabled=True,
            resolved_metadata_database='FFP_HDP_DLAB_DB_DEV',
            normalized_snowflake_authenticator='externalbrowser', snowflake_user='ANKURSINHA'),
        _session=session('control-session'), _query_session=session('agent-session'),
        _agent=SimpleNamespace(_auth_mode='snowflake_token', _token='agent-session', _role=None,
                              _base_url='https://mhsuejt-gd01711.snowflakecomputing.com'))


def test_local_binding_reuses_agent_session_without_another_login(monkeypatch):
    from app.core import snowflake
    from app.core.automap_local_session import bind_local_agent
    monkeypatch.setattr(snowflake, 'get_local_rest_session_context',
                        lambda *args: pytest.fail('An extra connector login must not occur'))
    service = local_binding_service()
    bound = bind_local_agent(service)
    assert bound is not service._agent
    assert bound._token == service._agent._token == 'agent-session'
    assert service._session._conn._conn._rest._token == 'control-session'


@pytest.mark.parametrize('field,value', [
    ('NATIVE_USER', 'OTHER'), ('ROLE_NAME', 'OTHER_ROLE'),
    ('ACCOUNT_NAMESPACE', 'OTHER.ACCOUNT'), ('TRANSACTION_ID', 123),
])
def test_local_binding_rejects_mismatched_agent_session_identity(field, value):
    from app.core.automap_local_session import bind_local_agent
    from app.core.automap_runtime import RuntimeConfigurationError
    service = local_binding_service()
    identity = dict(NATIVE_USER='ANKURSINHA', ROLE_NAME='DEV_ROLE',
                    ACCOUNT_NAMESPACE='MHSUEJT.GD01711', TRANSACTION_ID=None)
    identity[field] = value
    service._query_session.sql = lambda _: SimpleNamespace(collect=lambda **_: [identity])
    with pytest.raises(RuntimeConfigurationError):
        bind_local_agent(service)


@pytest.mark.parametrize('field,value', [
    ('_token', 'foreign-token'), ('_auth_mode', 'oauth_bearer'),
    ('_base_url', 'https://other.snowflakecomputing.com'), ('_role', 'OTHER_ROLE'),
])
def test_local_binding_rejects_foreign_agent_credentials(field, value):
    from app.core.automap_local_session import bind_local_agent
    service = local_binding_service()
    setattr(service._agent, field, value)
    with pytest.raises(ValueError):
        bind_local_agent(service)


def test_local_diagnostic_deadlines_allow_a_300_second_agent():
    from app.core.config import Settings
    settings = Settings(_env_file=None, AUTOMAP_LOCAL_SSO_ENABLED=False,
                        AUTOMAP_FAST_PATH_V1=False, AUTOMAP_FAST_BATCH_SECONDS=360,
                        AUTOMAP_FAST_JOB_SECONDS=600)
    assert settings.automap_fast_batch_seconds > 300
    assert settings.automap_fast_job_seconds > settings.automap_fast_batch_seconds
    with pytest.raises(ValueError):
        Settings(_env_file=None, AUTOMAP_LOCAL_SSO_ENABLED=False,
                 AUTOMAP_FAST_PATH_V1=False, AUTOMAP_FAST_BATCH_SECONDS=601)


def test_registry_yaml_fills_echo_and_preserves_human_edits():
    original = {'attributes': [{'name': 'HH_LABEL', 'description': 'HH Label'},
                              {'name': 'CLOSED_AT', 'description': 'Human edit: date after reconciliation.'}]}
    saved = deepcopy(original)
    result = hydrate_registry_yaml(original, YAML, 'ACCOUNTS')
    rows = {row['name']: row for row in result['attributes']}
    assert original == saved
    assert rows['HH_LABEL']['description'].startswith('Display name')
    assert rows['HH_LABEL']['synonyms'] == ['household name', 'family name']
    assert rows['HH_LABEL']['sample_values'] == ['Smith Family', 'Jones Household']
    assert rows['CLOSED_AT']['description'] == 'Human edit: date after reconciliation.'
    assert rows['CLOSED_AT']['provenance'] == 'human_override'
    assert 'total_assets' not in rows
    assert result['description'].startswith('Household relationship')


def test_yaml_retained_as_nonexecutable_knowledge():
    from app.core.sttm_builder import STTMBuilderService
    value = [{'semantic_model': {'semantic_view': {'name': 'OLD.VIEW', 'yaml': YAML}}}]
    result = STTMBuilderService._normalize_nested_semantic_context(semantic_context=value, semantic_view_name=None, semantic_bundle_id='b')
    assert 'semantic_view' not in result[0]['semantic_model']
    assert result[0]['semantic_model']['semantic_knowledge']['yaml'] == YAML
    assert 'name' not in result[0]['semantic_model']['semantic_knowledge']


def test_catalog_caps_samples_and_keeps_meaning():
    entry = catalog_entry('D.S.A', 'HH_LABEL', {'description': 'Household display name',
                          'sample_values': ['ü' * 300] * 9, 'synonyms': ['family name']})
    assert len(entry['sample_values']) == 5 and len(entry['sample_values'][0]) == 120
    assert entry['description'] == 'Household display name'
    records = [{'database': 'D', 'schema_name': 'CRM', 'table_name': 'ACCOUNTS',
                'semantic_model': {'semantic_knowledge': {'yaml': YAML}}}]
    catalog = build_catalog(records, bundle_hash='stable')
    catalog[0]['description'] = 'mutated'
    assert build_catalog(records, bundle_hash='stable')[0]['description'] != 'mutated'


def test_synonym_and_description_admit_differently_named_columns():
    catalog = [catalog_entry('a', 'HH_LABEL', {'description': 'Household display name', 'synonyms': ['family name']}),
               catalog_entry('a', 'ACCOUNT_NUM', {'description': 'Custodian investment account number'})]
    target = {'target_attribute': 'FAMILY_NAME', 'target_description': 'Household display name'}
    assert rank_candidates(target, catalog)[0]['column'] == 'HH_LABEL'
    assert rank_candidates(target, catalog, forced_refs=['a.ACCOUNT_NUM'], limit=1)[0]['column'] == 'ACCOUNT_NUM'
    assert rank_candidates(target, list(reversed(catalog))) == rank_candidates(target, catalog)


def test_packer_trims_index_before_samples_and_preserves_descriptions_values():
    packet = {'context': {'archived_source_inventory': {'a': ['x' * 1000]},
                         'selectable_values': [{'record_id': 'val:$FIRM_NAME', 'description': 'Current firm'}],
                         'candidates': [{'column': 'ID', 'description': 'Immutable identifier', 'sample_values': ['x' * 300]}]}}
    packed = pack_context(packet, max_bytes=800)
    assert packed['context_manifest']['trimmed_sections'] == ['archived_source_inventory']
    packed = pack_context(packet, max_bytes=460)
    assert packed['context_manifest']['trimmed_sections'] == ['archived_source_inventory', 'sample_values']
    assert packed['context']['candidates'][0]['description'] == 'Immutable identifier'
    assert packed['context']['selectable_values'] == packet['context']['selectable_values']
    assert len(json.dumps(packed, separators=(',', ':'), sort_keys=True).encode()) <= 460
    with pytest.raises(ContextBudgetError):
        pack_context(packet, max_bytes=20)


def precedent(identity, project='1', crm='HUBSPOT', expression='a.ID', published='2026-11-01', support=1):
    return {'pattern_id': identity, 'project_id': project, 'published_at': published, 'support_count': support,
            'source_system_profile': {'vendor_family': crm},
            'mapping_recipe': {'expression': expression, 'source_dependencies': ['a.ID']}}


def test_learning_pack_tiers_recency_applicability_and_deduplication():
    rows = [precedent('old', published='2026-10-01'), precedent('new'),
            precedent('linked', project='2', expression='TRIM(a.ID)'),
            precedent('crm', project='3', expression='UPPER(a.ID)'),
            precedent('other', project='4', crm='SALESFORCE', expression='LOWER(a.ID)', support=99)]
    pack = select_learning_pack(rows, project_id='1', linked_projects=['2'], crm='HUBSPOT', source_columns=['a.ID'])
    assert [item['pattern_id'] for item in pack[:2]] == ['new', 'linked']
    # Cross-project scope ranks knowledge; verified current dependencies allow a draft.
    assert not next(item for item in pack if item['pattern_id'] == 'other')['guidance_only']
    assert next(item for item in pack if item['pattern_id'] == 'other')['matching_columns'] == ['a.ID']
    assert all(item['applicable'] for item in pack if item['tier'] != 'T4')
    assert not select_learning_pack([precedent('x')], project_id='1', source_columns=[])[0]['applicable']


def test_latest_learning_query_is_batched_and_bound():
    calls = []
    session = SimpleNamespace(sql=lambda query, params: (calls.append((query, params)) or SimpleNamespace(collect=lambda: [])))
    settings = SimpleNamespace(qualify_table_name=lambda name: 'D.S.' + name, qualify_metadata_object_name=lambda name: 'D.S.' + name)
    result = AutoMapLearningPack(session, settings).retrieve(targets=['A', 'B'], target_table="D.S.T'X", project_id='1')
    assert result == {'A': [], 'B': []} and len(calls) == 1
    assert "T'X" not in calls[0][0] and "D.S.T'X" in calls[0][1]
    assert 's.CURRENT_VERSION' in calls[0][0] and 'QUALIFY ROW_NUMBER()' in calls[0][0]


def test_packet_citations_and_precedent_receipt():
    candidate = AttributeMapping(source_attributes=['a.ID'], confidence_score=.9,
        decision_basis={'citations': ['src:a.ID'], 'semantic_reason': 'Same household identifier meaning.'})
    args = dict(source_ids={'src:a.ID'}, evidence_ids={'p1'}, value_ids={'val:$FIRM_NAME'}, has_precedents=True)
    assert citation_deficits(candidate, **args) == ['Precedents were supplied without a precedent_decision']
    candidate.precedent_decision = 'followed'
    assert not citation_deficits(candidate, **args)
    candidate.decision_basis['citations'] = ['src:foreign.SECRET']
    assert any('outside' in value for value in citation_deficits(candidate, **args))


@pytest.mark.parametrize('text', ['{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}'])
def test_strict_json_rejects_duplicate_and_nonfinite_values(text):
    with pytest.raises(ValueError):
        load_json(text)


def test_exact_variant_preserves_false_zero_and_unicode():
    value = {'false': False, 'zero': 0, 'name': 'é', 'sql': "a = 'O\'Brien'"}
    assert load_json(variant_parameter(value)) == value


def test_values_are_first_class_without_resolved_literals():
    capsule = shared_capsule({'relation_graph': {'value_bindings': [
        {'binding_id': 'firm', 'value': '$FIRM_NAME', 'description': 'Current firm', 'resolved_value': 'PRIVATE'}]}})
    assert capsule['values'][0]['record_id'] == 'val:$FIRM_NAME'
    assert capsule['values'][0]['resolved'] is True and 'PRIVATE' not in json.dumps(capsule)


def test_local_auth_guard_is_dev_only():
    from app.core.automap_local_session import validate_local_settings
    settings = SimpleNamespace(app_env='local', local_dev_auth_enabled=True,
        resolved_metadata_database='WORKBENCH_DEV', normalized_snowflake_authenticator='externalbrowser')
    validate_local_settings(settings)
    for key, value in [('app_env', 'production'), ('resolved_metadata_database', 'WORKBENCH_UAT'),
                       ('local_dev_auth_enabled', False), ('normalized_snowflake_authenticator', 'password')]:
        modified = SimpleNamespace(**{**vars(settings), key: value})
        with pytest.raises(ValueError):
            validate_local_settings(modified)


def test_client_recipe_key_accumulates_across_projects_but_scoped_overrides_do_not():
    from app.core.fir_canonical import canonical_key
    payload = {**precedent('p'), 'scope': 'client', 'target_contract': {'target_column': 'ID'}}
    assert canonical_key(payload) == canonical_key({**payload, 'project_id': 'other'})
    scoped = {**payload, 'scope': 'project'}
    assert canonical_key(scoped) != canonical_key({**scoped, 'project_id': 'other'})


def test_transform_can_use_admitted_case_column_and_declared_value_only():
    from app.core.automap_transform import expression_within_selection
    from tests.unit.core.test_automap_transform_projection import payload
    value = payload(description_size=0)
    value['context']['relation_graph']['nodes'][0]['output_columns'].append({'name': 'OTHER'})
    selected = SimpleNamespace(source_attributes=['a.X47'], source_dependencies=[], value_binding_ids=[], admitted_source_attributes=['a.X47','a.OTHER'])
    rule = SimpleNamespace(rule="CASE WHEN a.OTHER IS NULL THEN a.X47 ELSE a.OTHER END", source_dependencies=['a.OTHER','a.X47'], value_binding_ids=[])
    assert expression_within_selection(value, selected, rule)
    selected.admitted_source_attributes = []
    assert not expression_within_selection(value, selected, rule)


def session_runtime(answer='{}'):
    import time
    from app.core.automap_fast_transport import FastSessionModelRuntime
    calls = []
    def run(messages, **kwargs):
        calls.append(kwargs)
        if isinstance(answer, Exception):
            raise answer
        return answer, None, {}
    agent = SimpleNamespace(_base_url='https://example.snowflakecomputing.com', run_detailed=run)
    settings = SimpleNamespace(automap_fast_max_in_flight=8, agent_outbound_message_max_chars=150000,
                               agent_outbound_message_max_bytes=150000, automap_local_sso_enabled=False)
    service = SimpleNamespace(_settings=settings, _agent=agent, _source_mapping_agent_name='D.S.AGT_SOURCE_MAPPING',
        _transformation_agent_name='D.S.AGT_TRANSFORMATION_RULE',
        _model_guard=SimpleNamespace(assert_model_target_allowed=lambda **kwargs: None))
    req = SimpleNamespace(operation=SimpleNamespace(value='sttm.auto_map'))
    return FastSessionModelRuntime(service=service, req=req, decision=None,
                                  store=SimpleNamespace(snapshot_hash='a' * 64), deadline=time.monotonic()+60), calls


def test_pool_independent_runtime_caps_source_and_rule_calls_separately():
    runtime, calls = session_runtime()
    messages = [{'role': 'user', 'content': [{'type': 'text', 'text': '{}'}]}]
    for index in range(1, 4):
        runtime.run(messages, index)
    for index in range(4, 6):
        runtime.run(messages, index, stage='transformation_rule')
    assert len(calls) == 5
    assert [item['agent'] for item in calls[:3]] == ['D.S.AGT_SOURCE_MAPPING'] * 3
    assert calls[-1]['agent'] == 'D.S.AGT_TRANSFORMATION_RULE'
    assert all(0 < item['request_timeout'] <= 60 for item in calls)
    with pytest.raises(ValueError):
        runtime.run(messages, 6)
    assert len(calls) == 5


def test_pool_independent_transport_failure_is_not_replayed():
    runtime, calls = session_runtime(TimeoutError('private provider details'))
    messages = [{'role': 'user', 'content': [{'type': 'text', 'text': '{}'}]}]
    with pytest.raises(TimeoutError):
        runtime.run(messages, 1)
    with pytest.raises(ValueError):
        runtime.run(messages, 2)
    assert len(calls) == 1


def test_benchmark_does_not_claim_unknown_citations_are_verified():
    from scripts.benchmark_automap_v3 import score
    key = {'mappings': {'ID': {'source_attributes': ['a.ID'], 'mapping_mode': 'source'}}}
    run = {'mappings': {'ID': {**key['mappings']['ID'], 'decision_basis': {'citations': ['src:absent.ID']}}}}
    report = score(key, run)
    assert report['accuracy'] == 1 and report['coverage'] == 1
    assert report['invalid_citations'] is None and not report['citation_validity_verified']
    packet = {'data': {'attributes': [{'target_attribute': 'ID'}]}, 'context': {'citation_ids': ['src:a.ID']}}
    report = score(key, run, [packet])
    assert report['invalid_citations'] == 1


def test_supersession_targets_only_older_different_published_recipes():
    from app.core.target_mapping_patterns import TargetMappingPatternService
    calls = []
    service = TargetMappingPatternService.__new__(TargetMappingPatternService)
    service._patterns_table = 'D.S.PATTERNS'
    service._session = SimpleNamespace(sql=lambda query, params: (calls.append((query, params)) or SimpleNamespace(collect=lambda: [])))
    service.supersede_published_patterns(sttm_id='100', publication_version_id='9')
    query, params = calls[0]
    assert 'old.PATTERN_ID <> current.PATTERN_ID' in query
    assert "old.VALIDATION_STATUS = 'published'" in query
    assert 'TRY_TO_NUMBER(?)' in query and 'mapping_recipe' in query
    assert params == ['100', '9', '9']


def test_hubspot_publish_fallback():
    from app.core.project_service import ProjectService
    assert ProjectService._infer_source_vendor(['D.HUBSPOT.CONTACT']) == 'HUBSPOT'
