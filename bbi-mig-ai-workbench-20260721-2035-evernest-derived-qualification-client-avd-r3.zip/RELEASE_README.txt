EverNest reliability client AVD release R3
==========================================

This archive contains the complete verified R2 application/DDL payload plus
the derived-source qualification repair added on 2026-07-21.

R3 repair
---------
- Cortex Analyst derived SQL may use a semantic short table name such as
  CONTACT_FAMILIES.
- Before Snowflake validation and persistence, the backend now resolves such
  names against the selected source graph and writes the unique fully
  qualified DATABASE.SCHEMA.TABLE reference.
- Existing fully qualified references and CTE references are preserved.
- Ambiguous short names are rejected with the list of valid qualified choices.
- The normalized SQL is returned to the UI and shown in the derived builder.
- Business prompts beginning with "Prepare one reusable household-level
  source..." are now classified as derived-source generation on both the UI
  and backend. They use the bounded Cortex Analyst path instead of the longer
  orchestration-agent/RAG path that could expire without a final response.
- If only some selected tables have published semantic assets, the registry
  composer now builds an Analyst model from the valid subset and reports the
  missing assets as warnings. One missing asset no longer discards the entire
  model and silently forces a long agent fallback.

Verification
------------
- Focused backend semantic, contract, and derived-source suites: 36 passed.
- Frontend TypeScript check: passed.
- Archive checksum and per-file MANIFEST.sha256 are generated after packaging.

Deployment
----------
Extract this archive over the R2/client worktree. Rebuild/redeploy the frontend
and STTM Builder service. No environment or Docker files are included or
changed by this R3 repair.
