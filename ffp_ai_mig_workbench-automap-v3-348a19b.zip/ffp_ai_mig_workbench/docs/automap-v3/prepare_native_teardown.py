"""Read-only native-v1 teardown preparation. Never executes generated DROP SQL.

Run only after v3 acceptance. Back up both agent specs to local files, inventory
exact native-v1 resources in the selected namespace, and produce reviewable SQL.
The resulting DROP statements require the separate explicit approval in the plan.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re


def identifier(value):
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_$]*', value):
        raise ValueError('Expected a plain Snowflake identifier')
    return '"' + value + '"'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env', required=True, type=Path)
    parser.add_argument('--namespace', required=True)
    parser.add_argument('--expected-account', required=True)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    parts = args.namespace.split('.')
    if len(parts) != 2:
        parser.error('Expected DATABASE.SCHEMA')
    namespace = '.'.join(map(identifier, parts))
    if args.output_dir.exists():
        parser.error('Use a new output directory to preserve existing backups')
    from dotenv import dotenv_values
    import snowflake.connector
    env = dotenv_values(args.credential_env)
    if env['SNOWFLAKE_ACCOUNT'].upper() != args.expected_account.upper():
        parser.error('Credential account differs from --expected-account')
    connection = snowflake.connector.connect(account=env['SNOWFLAKE_ACCOUNT'], user=env['SNOWFLAKE_USER'],
        authenticator='PROGRAMMATIC_ACCESS_TOKEN', token=env['SNOWFLAKE_PASSWORD'],
        role=env.get('SNOWFLAKE_ROLE'), warehouse=env.get('SNOWFLAKE_WAREHOUSE'), login_timeout=20)
    args.output_dir.mkdir(parents=True)
    inventory, drops = [], []
    try:
        cursor = connection.cursor()
        agents = ('AGT_AUTOMAP_INVESTIGATOR_V1', 'AGT_AUTOMAP_TRANSFORMATION_V1')
        # Stop preparation if either required specification cannot be backed up.
        for name in agents:
            fqn = namespace + '.' + identifier(name)
            cursor.execute('SELECT GET_DDL(\'AGENT\', %s)', (fqn,))
            ddl = cursor.fetchone()[0]
            if not isinstance(ddl, str) or not ddl:
                raise ValueError('Agent backup is empty')
            path = args.output_dir / (name + '.sql')
            path.write_text(ddl)
            inventory.append({'kind': 'AGENT', 'name': name, 'backup_sha256': hashlib.sha256(ddl.encode()).hexdigest()})
            drops.append('DROP AGENT IF EXISTS ' + fqn + ';')
        patterns = [('PROCEDURES', 'SP_AUTOMAP_%', 'PROCEDURE'),
                    ('TABLES', 'TBL_AUTOMAP_NATIVE_%', 'TABLE'),
                    ('VIEWS', 'AUTOMAP_POP_%', 'VIEW'),
                    ('CORTEX SEARCH SERVICES', 'CSS_AUTOMAP_SOURCE_COLUMNS_V2', 'CORTEX SEARCH SERVICE')]
        for show, pattern, kind in patterns:
            cursor.execute(f"SHOW {show} LIKE '{pattern}' IN SCHEMA {namespace}")
            keys = [column[0].lower() for column in cursor.description]
            for row in cursor.fetchall():
                item = dict(zip(keys, row))
                name = item['name']
                allowed = (kind == 'PROCEDURE' and name.startswith('SP_AUTOMAP_') or
                           kind == 'TABLE' and name.startswith('TBL_AUTOMAP_NATIVE_') or
                           kind == 'VIEW' and name.startswith('AUTOMAP_POP_') or
                           kind == 'CORTEX SEARCH SERVICE' and name == 'CSS_AUTOMAP_SOURCE_COLUMNS_V2')
                if not allowed:
                    raise ValueError('Unexpected object in teardown inventory')
                suffix = ''
                if kind == 'PROCEDURE':
                    signature = str(item.get('arguments') or '').split(' RETURN ', 1)[0]
                    if not signature.startswith(name + '(') or not signature.endswith(')'):
                        raise ValueError('Procedure signature requires manual review')
                    suffix = signature[len(name):]
                    if not re.fullmatch(r'\([A-Za-z0-9_ (),]*\)', suffix):
                        raise ValueError('Procedure argument types require manual review')
                inventory.append({'kind': kind, 'name': name, 'signature': suffix})
                drops.append(f'DROP {kind} IF EXISTS {namespace}.{identifier(name)}{suffix};')
        (args.output_dir / 'inventory.json').write_text(json.dumps(inventory, indent=2))
        text = '-- REVIEW AND OBTAIN EXPLICIT APPROVAL BEFORE EXECUTING.\n'
        text += '-- Account: ' + args.expected_account + '; namespace: ' + args.namespace + '\n'
        text += '-- Execute only after v3 acceptance; UAT requires its pipeline release first.\n'
        text += '\n'.join(drops) + '\n'
        (args.output_dir / 'teardown.sql').write_text(text)
        print(json.dumps({'prepared_only': True, 'object_count': len(inventory),
                          'teardown_sha256': hashlib.sha256(text.encode()).hexdigest()}))
    finally:
        connection.close()


if __name__ == '__main__':
    main()
