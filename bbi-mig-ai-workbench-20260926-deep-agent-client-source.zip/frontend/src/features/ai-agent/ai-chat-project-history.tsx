'use client';

import { useEffect, useMemo, useRef, useState, type KeyboardEvent, type MouseEvent } from 'react';
import { AiaBox, AiaMenu, AiaMenuItem } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import type { StoredChatSession } from './ai-chat-session-utils';
import type { ProjectRecord } from '@/services/projectService';
import {
  AddRoundedIcon, ArchiveOutlinedIcon, ChatBubbleOutlineRoundedIcon,
  EditNoteRoundedIcon, FolderRoundedIcon, KeyboardArrowDownIcon,
  KeyboardDoubleArrowLeftRoundedIcon, KeyboardDoubleArrowRightRoundedIcon,
  MoreVertIcon, PushPinOutlinedIcon, SearchRoundedIcon,
} from '@/utils/icons';

type SessionUpdate = { title?: string; projectId?: string | null; pinned?: boolean };
type Props = {
  sessions: StoredChatSession[];
  projects: ProjectRecord[];
  selectedProjectId: string;
  activeSessionId: string | null;
  onSelectProject: (projectId: string) => void;
  onNewProjectChat: (projectId: string) => void;
  onSelectSession: (session: StoredChatSession) => void;
  onNewChat: () => void;
  onUpdateSession: (session: StoredChatSession, changes: SessionUpdate) => Promise<void>;
  onArchiveSession: (session: StoredChatSession) => Promise<void>;
};

const WIDTH_KEY = 'aia:chat-history-width';
const COLLAPSED_KEY = 'aia:chat-history-collapsed';
const FIRST_PAGE = 5;
const NEXT_PAGE = 10;
const MIN_WIDTH = 220;
const MAX_WIDTH = 440;
const clamp = (value: number) => Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, value));
const iconButtonSx = {
  width: 30, height: 30, border: 'none', borderRadius: 1.5,
  backgroundColor: 'transparent', color: '#64748b', cursor: 'pointer',
  display: 'grid', placeItems: 'center',
  '&:hover': { backgroundColor: '#e9eef5' },
} as const;

function ScrollingTitle({ title }: { title: string }) {
  const viewportRef = useRef<HTMLSpanElement>(null);
  const textRef = useRef<HTMLSpanElement>(null);
  const [overflow, setOverflow] = useState(0);
  const [hovered, setHovered] = useState(false);
  useEffect(() => {
    const viewport = viewportRef.current;
    const content = textRef.current;
    if (!viewport || !content) return;
    const measure = () => setOverflow(Math.max(0, content.scrollWidth - viewport.clientWidth));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(viewport);
    observer.observe(content);
    return () => observer.disconnect();
  }, [title]);
  return <span ref={viewportRef} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
    style={{ display: 'block', width: '100%', overflow: 'hidden', whiteSpace: 'nowrap', fontSize: 12.5, color: '#26354a' }}>
    <span ref={textRef} style={{ display: 'inline-block', transform: hovered && overflow ? `translateX(-${overflow}px)` : 'translateX(0)', transition: `transform ${Math.min(9000, Math.max(1800, overflow * 24))}ms linear` }}>
      {title}
    </span>
  </span>;
}

export function AiChatProjectHistory(props: Props) {
  const {
    sessions, projects, selectedProjectId, activeSessionId,
    onSelectProject, onNewProjectChat, onSelectSession, onNewChat,
    onUpdateSession, onArchiveSession,
  } = props;
  const [width, setWidth] = useState(280);
  const [collapsed, setCollapsed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [projectsOpen, setProjectsOpen] = useState(true);
  const [recentOpen, setRecentOpen] = useState(true);
  const [openProjects, setOpenProjects] = useState<Record<string, boolean>>({});
  const [visibleCounts, setVisibleCounts] = useState<Record<string, number>>({});
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const [menuSession, setMenuSession] = useState<StoredChatSession | null>(null);
  const [dialog, setDialog] = useState<'rename' | 'move' | null>(null);
  const [dialogValue, setDialogValue] = useState('');
  const [actionError, setActionError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const savedWidth = Number(window.localStorage.getItem(WIDTH_KEY));
    if (Number.isFinite(savedWidth) && savedWidth > 0) setWidth(clamp(savedWidth));
    if (window.localStorage.getItem(COLLAPSED_KEY) === 'true') setCollapsed(true);
  }, []);
  useEffect(() => {
    if (selectedProjectId !== 'general') {
      setOpenProjects((current) => ({ ...current, [selectedProjectId]: true }));
    }
  }, [selectedProjectId]);

  const projectNames = useMemo(
    () => new Map(projects.map((project) => [project.project_id, project.project_name || project.project_id])),
    [projects],
  );
  const search = query.trim().toLowerCase();
  const matching = sessions.filter((session) => !search
    || session.title.toLowerCase().includes(search)
    || (projectNames.get(session.projectId || '') || '').toLowerCase().includes(search));
  const pinned = matching.filter((session) => session.pinned).sort((a, b) => b.updatedAt - a.updatedAt);
  const recent = matching.filter((session) => !session.projectId && !session.pinned).sort((a, b) => b.updatedAt - a.updatedAt);
  const projectIds = Array.from(new Set([
    ...projects.map((project) => project.project_id),
    ...matching.map((session) => session.projectId).filter((id): id is string => Boolean(id)),
  ])).sort((a, b) => (projectNames.get(a) || a).localeCompare(projectNames.get(b) || b));

  const toggleCollapsed = () => setCollapsed((current) => {
    window.localStorage.setItem(COLLAPSED_KEY, String(!current));
    return !current;
  });
  const resizeStart = (event: MouseEvent) => {
    event.preventDefault();
    const initialX = event.clientX;
    const initialWidth = width;
    const onMove = (move: globalThis.MouseEvent) => setWidth(clamp(initialWidth + move.clientX - initialX));
    const onUp = (up: globalThis.MouseEvent) => {
      window.localStorage.setItem(WIDTH_KEY, String(clamp(initialWidth + up.clientX - initialX)));
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  };
  const resizeKey = (event: KeyboardEvent) => {
    const next = event.key === 'ArrowRight' ? width + 16
      : event.key === 'ArrowLeft' ? width - 16
      : event.key === 'Home' ? MIN_WIDTH
      : event.key === 'End' ? MAX_WIDTH : null;
    if (next == null) return;
    event.preventDefault();
    const value = clamp(next);
    setWidth(value);
    window.localStorage.setItem(WIDTH_KEY, String(value));
  };
  const showMenu = (event: MouseEvent<HTMLElement>, session: StoredChatSession) => {
    event.stopPropagation();
    setMenuAnchor(event.currentTarget);
    setMenuSession(session);
    setActionError('');
  };
  const startDialog = (kind: 'rename' | 'move') => {
    setDialog(kind);
    setDialogValue(kind === 'rename' ? menuSession?.title || '' : menuSession?.projectId || 'general');
    setMenuAnchor(null);
  };
  const resetVisibleCount = (key: string) => setVisibleCounts((current) => ({ ...current, [key]: FIRST_PAGE }));
  const saveDialog = async () => {
    if (!menuSession || !dialog) return;
    setSaving(true);
    setActionError('');
    try {
      if (dialog === 'rename') {
        if (!dialogValue.trim()) throw new Error('Enter a chat title.');
        await onUpdateSession(menuSession, { title: dialogValue.trim() });
      } else {
        await onUpdateSession(menuSession, { projectId: dialogValue === 'general' ? null : dialogValue });
      }
      setDialog(null);
      setMenuSession(null);
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Could not save chat.');
    } finally {
      setSaving(false);
    }
  };

  const row = (session: StoredChatSession, showProject = false) => (
    <AiaBox key={session.id} sx={{
      display: 'flex', alignItems: 'center', minWidth: 0, borderRadius: 2,
      backgroundColor: activeSessionId === session.id ? '#eaf1fb' : 'transparent',
      '&:hover': { backgroundColor: '#f0f3f7' },
      '&:hover .chat-more': { opacity: 1 },
    }}>
      <AiaBox component="button" type="button" title={session.title} onClick={() => onSelectSession(session)} sx={{
        display: 'flex', alignItems: 'center', gap: 1, flex: 1, minWidth: 0,
        px: 1, py: 0.75, border: 'none', backgroundColor: 'transparent', cursor: 'pointer', textAlign: 'left',
      }}>
        <ChatBubbleOutlineRoundedIcon sx={{ fontSize: 15, color: '#94a3b8' }} />
        <AiaBox sx={{ minWidth: 0, flex: 1 }}>
          <ScrollingTitle title={session.title} />
          {showProject && session.projectId ? <AiaText sx={{ fontSize: 10.5, color: '#8b99aa', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{projectNames.get(session.projectId) || 'Project ' + session.projectId}</AiaText> : null}
        </AiaBox>
      </AiaBox>
      <AiaBox className="chat-more" component="button" type="button" aria-label={'Options for ' + session.title} onClick={(event: MouseEvent<HTMLElement>) => showMenu(event, session)} sx={{ ...iconButtonSx, width: 26, height: 26, opacity: 0.3, flexShrink: 0 }}><MoreVertIcon sx={{ fontSize: 17 }} /></AiaBox>
    </AiaBox>
  );
  const rows = (key: string, items: StoredChatSession[], showProject = false) => {
    const count = visibleCounts[key] || FIRST_PAGE;
    return <>
      {items.slice(0, count).map((session) => row(session, showProject))}
      {items.length > count ? <AiaBox component="button" type="button" onClick={() => setVisibleCounts((current) => ({ ...current, [key]: count + NEXT_PAGE }))} sx={{
        display: 'block', width: '100%', px: 1.1, py: 0.7, border: 'none', backgroundColor: 'transparent',
        color: '#64748b', cursor: 'pointer', fontSize: 12, textAlign: 'left',
        '&:hover': { color: '#1d4ed8' },
      }}>Show more</AiaBox> : null}
      {count > FIRST_PAGE ? <AiaBox component="button" type="button" onClick={() => resetVisibleCount(key)} sx={{
        display: 'block', width: '100%', px: 1.1, py: 0.7, border: 'none', backgroundColor: 'transparent',
        color: '#64748b', cursor: 'pointer', fontSize: 12, textAlign: 'left',
        '&:hover': { color: '#1d4ed8' },
      }}>Show less</AiaBox> : null}
    </>;
  };

  return <>
    <AiaBox component="nav" aria-label="Chats by project" sx={{
      width: collapsed ? 48 : width, minWidth: collapsed ? 48 : width,
      maxWidth: 'min(440px, 80vw)', position: 'relative', display: 'flex',
      flexDirection: 'column', minHeight: 0, backgroundColor: '#fbfcfe',
      borderRight: '1px solid #dbe2ea',
    }}>
      {collapsed ? <AiaBox sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, py: 1.5 }}>
        <AiaBox component="button" type="button" title="Expand chats" aria-label="Expand chats" onClick={toggleCollapsed} sx={iconButtonSx}><KeyboardDoubleArrowRightRoundedIcon sx={{ fontSize: 18 }} /></AiaBox>
        <AiaBox component="button" type="button" title="New chat" aria-label="New chat" onClick={onNewChat} sx={iconButtonSx}><AddRoundedIcon sx={{ fontSize: 18 }} /></AiaBox>
      </AiaBox> : <>
        <AiaBox sx={{ px: 1.5, pt: 1.2, pb: 1.1, borderBottom: '1px solid #e8edf4' }}>
          <AiaBox sx={{ display: 'flex', alignItems: 'center' }}>
            <AiaText sx={{ flex: 1, fontSize: 14, fontWeight: 800, color: '#152238' }}>Chats</AiaText>
            <AiaBox component="button" type="button" title="Search chats" aria-label="Search chats" onClick={() => { if (searchOpen) setQuery(''); setSearchOpen(!searchOpen); }} sx={iconButtonSx}><SearchRoundedIcon sx={{ fontSize: 18 }} /></AiaBox>
            <AiaBox component="button" type="button" title="Collapse chats" aria-label="Collapse chats" onClick={toggleCollapsed} sx={iconButtonSx}><KeyboardDoubleArrowLeftRoundedIcon sx={{ fontSize: 18 }} /></AiaBox>
          </AiaBox>
          <AiaBox component="button" type="button" onClick={onNewChat} sx={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 1, mt: 1,
            px: 1, py: 0.8, border: '1px solid #dbe2ea', borderRadius: 2,
            backgroundColor: '#fff', color: '#152238', fontSize: 13, fontWeight: 700,
            cursor: 'pointer', '&:hover': { backgroundColor: '#f3f7fc' },
          }}><EditNoteRoundedIcon sx={{ fontSize: 18 }} /> New chat</AiaBox>
          {searchOpen ? <input autoFocus aria-label="Search chats" placeholder="Search chats and projects" value={query} onChange={(event) => setQuery(event.target.value)} style={{ width: '100%', marginTop: 10, padding: '8px 10px', border: '1px solid #cbd5e1', borderRadius: 8, background: '#fff', fontSize: 12.5 }} /> : null}
        </AiaBox>
        <AiaBox sx={{ flex: 1, minHeight: 0, overflowY: 'auto', px: 1, py: 1.2 }}>
          {pinned.length ? <AiaBox sx={{ mb: 1.5 }}><AiaText sx={{ px: 1.1, pb: 0.6, fontSize: 11, fontWeight: 800, color: '#8492a6' }}>Pinned</AiaText>{pinned.map((session) => row(session, true))}</AiaBox> : null}
          <AiaBox sx={{ mb: 1.5 }}>
            <AiaBox component="button" type="button" aria-expanded={recentOpen} aria-controls="ai-chat-recent" onClick={() => {
              if (recentOpen) resetVisibleCount('recent');
              setRecentOpen(!recentOpen);
            }} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', px: 1.1, pb: 0.6, border: 'none', backgroundColor: 'transparent', color: '#8492a6', fontSize: 11, fontWeight: 800, cursor: 'pointer', textAlign: 'left' }}>
              Recent <KeyboardArrowDownIcon sx={{ fontSize: 16, transform: recentOpen ? 'none' : 'rotate(-90deg)' }} />
            </AiaBox>
            {recentOpen ? <AiaBox id="ai-chat-recent">
              {rows('recent', recent)}
              {recent.length === 0 && !search ? <AiaText sx={{ px: 1.1, fontSize: 12, color: '#94a3b8' }}>Chats without a project appear here.</AiaText> : null}
            </AiaBox> : null}
          </AiaBox>
          <AiaBox component="button" type="button" aria-expanded={projectsOpen} aria-controls="ai-chat-projects" onClick={() => {
            if (projectsOpen) setVisibleCounts({});
            setProjectsOpen(!projectsOpen);
          }} sx={{
            display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', px: 1.1, py: 0.7,
            border: 'none', backgroundColor: 'transparent', color: '#8492a6',
            fontSize: 11, fontWeight: 800, cursor: 'pointer', textAlign: 'left',
          }}>Projects <KeyboardArrowDownIcon sx={{ fontSize: 16, transform: projectsOpen ? 'none' : 'rotate(-90deg)' }} /></AiaBox>
          {projectsOpen ? <AiaBox id="ai-chat-projects">{projectIds.map((id) => {
            const projectSessions = matching.filter((session) => session.projectId === id);
            const items = projectSessions.filter((session) => !session.pinned).sort((a, b) => b.updatedAt - a.updatedAt);
            const open = Boolean(openProjects[id]);
            const name = projectNames.get(id) || 'Project ' + id;
            return <AiaBox key={id} sx={{ mb: 0.3 }}>
              <AiaBox sx={{
                display: 'flex', alignItems: 'center', borderRadius: 2,
                backgroundColor: selectedProjectId === id ? '#edf3fc' : 'transparent',
                '&:hover': { backgroundColor: '#f0f3f7' },
                '&:hover .project-new-chat, &:focus-within .project-new-chat': { opacity: 1, pointerEvents: 'auto' },
              }}>
                <AiaBox component="button" type="button" aria-expanded={open} aria-controls={'ai-chat-project-' + id} onClick={() => {
                  if (open) resetVisibleCount(id);
                  setOpenProjects((current) => ({ ...current, [id]: !open }));
                  if (selectedProjectId !== id) onSelectProject(id);
                }} sx={{
                  flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: 0.7,
                  px: 1, py: 0.7, border: 'none', backgroundColor: 'transparent',
                  textAlign: 'left', cursor: 'pointer',
                }}>
                  <FolderRoundedIcon sx={{ fontSize: 17, color: selectedProjectId === id ? '#2563eb' : '#64748b' }} />
                  <AiaText sx={{ flex: 1, minWidth: 0, fontSize: 12.5, fontWeight: selectedProjectId === id ? 800 : 650, color: '#1e293b', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</AiaText>
                  <KeyboardArrowDownIcon sx={{ fontSize: 15, color: '#94a3b8', transform: open ? 'none' : 'rotate(-90deg)' }} />
                </AiaBox>
                <AiaBox className="project-new-chat" component="button" type="button" title={'New chat in ' + name} aria-label={'New chat in ' + name} onClick={() => {
                  setOpenProjects((current) => ({ ...current, [id]: true }));
                  onNewProjectChat(id);
                }} sx={{ ...iconButtonSx, width: 26, height: 26, mr: 0.3, opacity: 0, pointerEvents: 'none', transition: 'opacity 120ms ease', '@media (hover: none)': { opacity: 1, pointerEvents: 'auto' } }}><AddRoundedIcon sx={{ fontSize: 17 }} /></AiaBox>
              </AiaBox>
              {open ? <AiaBox id={'ai-chat-project-' + id} sx={{ pl: 1.5 }}>
                {rows(id, items)}
                {items.length === 0 ? <AiaText sx={{ px: 1.1, py: 0.5, fontSize: 11.5, color: '#a0acbb' }}>No chats yet</AiaText> : null}
              </AiaBox> : null}
            </AiaBox>;
          })}</AiaBox> : null}
        </AiaBox>
        <AiaBox role="separator" aria-label="Resize chat sidebar" aria-orientation="vertical"
          aria-valuemin={MIN_WIDTH} aria-valuemax={MAX_WIDTH} aria-valuenow={width}
          tabIndex={0} onMouseDown={resizeStart} onKeyDown={resizeKey}
          sx={{ position: 'absolute', right: -3, top: 0, bottom: 0, width: 6, zIndex: 2, cursor: 'col-resize', '&:hover, &:focus-visible': { backgroundColor: '#93c5fd' } }} />
      </>}
    </AiaBox>

    <AiaMenu anchorEl={menuAnchor} open={Boolean(menuAnchor)} onClose={() => setMenuAnchor(null)}>
      <AiaMenuItem onClick={() => {
        const session = menuSession;
        setMenuAnchor(null);
        if (session) void onUpdateSession(session, { pinned: !session.pinned }).catch((error) => setActionError(error instanceof Error ? error.message : 'Could not pin chat.'));
      }}><PushPinOutlinedIcon sx={{ fontSize: 17, mr: 1 }} />{menuSession?.pinned ? 'Unpin chat' : 'Pin chat'}</AiaMenuItem>
      <AiaMenuItem onClick={() => startDialog('rename')}><EditNoteRoundedIcon sx={{ fontSize: 17, mr: 1 }} />Rename</AiaMenuItem>
      <AiaMenuItem onClick={() => startDialog('move')}><FolderRoundedIcon sx={{ fontSize: 17, mr: 1 }} />Move to project</AiaMenuItem>
      <AiaMenuItem onClick={() => {
        const session = menuSession;
        setMenuAnchor(null);
        if (session) void onArchiveSession(session).catch((error) => setActionError(error instanceof Error ? error.message : 'Could not archive chat.'));
      }}><ArchiveOutlinedIcon sx={{ fontSize: 17, mr: 1 }} />Archive</AiaMenuItem>
    </AiaMenu>
    {dialog && menuSession ? <AiaBox role="dialog" aria-modal="true" aria-label={dialog === 'rename' ? 'Rename chat' : 'Move chat to project'} sx={{
      position: 'fixed', inset: 0, zIndex: 1600, p: 2, display: 'grid', placeItems: 'center', backgroundColor: 'rgba(15,23,42,.42)',
    }}>
      <AiaBox sx={{ width: 'min(400px, 100%)', p: 2.5, borderRadius: 3, backgroundColor: '#fff', boxShadow: '0 24px 60px rgba(15,23,42,.2)' }}>
        <AiaText sx={{ mb: 1.5, fontSize: 17, fontWeight: 800, color: '#0f172a' }}>{dialog === 'rename' ? 'Rename chat' : 'Move chat to project'}</AiaText>
        {dialog === 'rename'
          ? <input autoFocus aria-label="Chat title" value={dialogValue} maxLength={255} onChange={(event) => setDialogValue(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') void saveDialog(); }} style={{ width: '100%', padding: 10, border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 14 }} />
          : <select aria-label="Destination project" value={dialogValue} onChange={(event) => setDialogValue(event.target.value)} style={{ width: '100%', padding: 10, border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 14 }}><option value="general">Recent · no project</option>{projects.map((project) => <option key={project.project_id} value={project.project_id}>{project.project_name || project.project_id}</option>)}</select>}
        {actionError ? <AiaText role="alert" sx={{ mt: 1, fontSize: 12, color: '#b91c1c' }}>{actionError}</AiaText> : null}
        <AiaBox sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 2 }}>
          <AiaBox component="button" type="button" disabled={saving} onClick={() => { setDialog(null); setActionError(''); }} sx={{ px: 1.5, py: 0.75, border: 'none', background: 'transparent', cursor: 'pointer' }}>Cancel</AiaBox>
          <AiaBox component="button" type="button" disabled={saving} onClick={() => void saveDialog()} sx={{ px: 1.5, py: 0.75, border: 'none', borderRadius: 1.5, background: '#2563eb', color: '#fff', fontWeight: 700, cursor: 'pointer' }}>{saving ? 'Saving…' : 'Save'}</AiaBox>
        </AiaBox>
      </AiaBox>
    </AiaBox> : null}
    {actionError && !dialog ? <AiaBox role="alert" sx={{ position: 'fixed', zIndex: 1600, bottom: 24, left: 24, p: 1.5, borderRadius: 2, backgroundColor: '#fee2e2', color: '#991b1b', fontSize: 13 }}>{actionError}</AiaBox> : null}
  </>;
}
