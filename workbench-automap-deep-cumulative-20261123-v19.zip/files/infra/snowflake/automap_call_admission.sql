-- REVIEW ONLY: not executed/compiled against a live account.
-- Deployment owner must choose the database/schema and fixed capacity (8 below).
-- Deploy ONCE, with all dispatchers stopped. CTAS atomically creates + preallocates
-- the inventory. Deliberately no OR REPLACE, IF NOT EXISTS, MERGE, or request DDL.
-- Never reset/delete/insert slots or replace this table while old calls or paused
-- dispatchers can survive. Reprovision only after terminal reconciliation/drain;
-- use a NEW epoch, and configure every replica with the same table/epoch/capacity.
-- No PK is declared: uniqueness on standard tables is NOT an enforced invariant.
-- Runtime requires SELECT/UPDATE only; the deployment role controls provisioning.
-- Do not grant INSERT, DELETE, TRUNCATE, OWNERSHIP, or table-replacement powers to
-- the runtime role. Review inherited grants separately before enabling dispatch.
-- The namespace is canonical CURRENT_ORGANIZATION_NAME().CURRENT_ACCOUNT_NAME(),
-- NOT a host URL, Desktop connection name, or account locator alias.
-- Tokens identify owners, not credentials. Keep prompts, auth tokens and error
-- payloads OUT of this table; audit references must also be non-secret.
--
-- Algorithm: SELECT inventory -> CAS UPDATE FREE+owner-null+epoch+fence -> verify
-- exactly one updated row -> COMMIT acknowledged -> dispatch. Contention may
-- return zero rows or a transaction error: both deny, never authorize a call.
-- UPDATE/DELETE/MERGE locks are held until COMMIT/ROLLBACK on standard tables;
-- no claim about row-level locks, FIFO fairness, or parallel update performance.
-- Docs: https://docs.snowflake.com/en/sql-reference/transactions
--
-- DEV verification still required after approval:
-- 1. Confirm Snowpark UPDATE result column and statement_params timeout handling.
-- 2. Barrier-start separate sessions on one free slot: exactly one committed
--    owner, losers update zero or fail; repeat with stale FREE/fence observations.
-- 3. Duplicate/missing slot, epoch/capacity mismatch, account mismatch: fail closed.
-- 4. Verify rollback on malformed/multiple affected rows and lock/statement errors.
-- 5. Drop connection at COMMIT (before and after server commit): NEVER dispatch
--    without acknowledgement; inspect retained owners and reconcile explicitly.
-- 6. Expire lease / kill worker / time out transport with remote work still active:
--    slot stays HELD or QUARANTINED; no TTL takeover and no replacement call.
-- 7. Renew via independent sessions, then reuse slot and replay old completion,
--    renewal and quarantine: owner/fence/generation guards must reject them.
-- 8. Multi-replica real remote in-flight counter must remain <= fixed capacity.
--    Test coordinator cancellation while worker is still running.
-- 9. Unknown-call reconciliation requires provider terminal evidence AND retired
--    old dispatcher; absence in delayed query history is NOT terminal evidence.
-- 10. Review query cost, standard-table lock contention, warehouse wakeup latency,
--     connection/network timeouts and heartbeat load before selecting capacity.
--
-- Limits: only this pool's participating calls are bounded; existing automap paths
-- are not wired. Job/caller labels are attribution, not limits or fairness.

SET AUTOMAP_POOL_EPOCH = UUID_STRING();

CREATE TABLE WORKBENCH_DEV.CONTROL.TBL_AUTOMAP_CALL_ADMISSION (
    ACCOUNT_NAMESPACE VARCHAR(256) NOT NULL,
    POOL_EPOCH VARCHAR(36) NOT NULL,
    SLOT_ID NUMBER(38, 0) NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    OWNER_TOKEN VARCHAR(32),
    FENCE NUMBER(38, 0) NOT NULL,
    JOB_ID VARCHAR(256),
    CALLER_ID VARCHAR(256),
    GENERATION VARCHAR(256),
    SHARD_ID VARCHAR(256),
    LEASE_EXPIRES_AT TIMESTAMP_LTZ,
    UPDATED_AT TIMESTAMP_LTZ NOT NULL,
    COMPLETION VARCHAR(32),
    RECONCILIATION_REF VARCHAR(256)
) AS
SELECT
    CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME(),
    $AUTOMAP_POOL_EPOCH,
    ROW_NUMBER() OVER (ORDER BY SEQ4()),
    'FREE',
    NULL,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    CURRENT_TIMESTAMP(),
    NULL,
    NULL
FROM TABLE(GENERATOR(ROWCOUNT => 8));

-- Record these deployment values in trusted configuration for EVERY replica.
SELECT ACCOUNT_NAMESPACE, POOL_EPOCH, COUNT(*) AS CAPACITY,
       COUNT(DISTINCT SLOT_ID) AS DISTINCT_SLOTS, MIN(SLOT_ID), MAX(SLOT_ID)
FROM WORKBENCH_DEV.CONTROL.TBL_AUTOMAP_CALL_ADMISSION
GROUP BY ACCOUNT_NAMESPACE, POOL_EPOCH;
