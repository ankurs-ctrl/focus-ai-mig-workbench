"""Validation shared by researched value choices and checkpoint answers."""
from __future__ import annotations

import re
from datetime import date


def normalize_typed_project_value(value: str, data_type: str | None) -> str:
    text = str(value or "").strip()
    if str(data_type or "").upper().startswith(("BOOLEAN", "BOOL")):
        return {"YES": "TRUE", "NO": "FALSE"}.get(text.upper(), text.upper())
    return text


def prompt_project_value(prompt: str, name: str, target_columns: list[str], data_type: str | None) -> str | None:
    """Bind only an explicit field/value pair from the current user request.

    Free-floating dates and IDs are deliberately ignored: their destination is
    ambiguous, especially when a historical SQL script has several constants.
    """
    named = {name, name.removeprefix("constant_")}
    aliases = set(named)
    aliases.update(str(column) for column in target_columns)
    matches: set[str] = set()
    for alias in aliases:
        if not alias:
            continue
        label = re.escape(alias).replace("_", "[_ ]")
        patterns = [
            rf"(?im)^\s*(?:use\s+)?(?:constant_)?{label}\s*(?:=|:|should\s+(?:be|use))\s*([^\n;,]+)",
            rf"(?im)^\s*use\s+([^\n;,]+?)\s+for\s+(?:constant_)?{label}\s*$",
        ]
        if alias in named:
            # In a sentence, for the value's own name only (a column name such
            # as TYPE is too common a word): "ClientStartDate for this firm is
            # 2024-01-01." One quoted or unbroken value, not the rest of the sentence.
            patterns.append(
                rf"(?i)(?<![A-Za-z0-9_$]){label}(?![A-Za-z0-9_])(?:\s+for\s+this\s+(?:firm|client|project))?"
                r"\s+(?:is|=|:)\s+(\"[^\"\n]+\"|'[^'\n]+'|[^\s,;]+?)(?=[.,;]?(?:\s|$))"
            )
        for pattern in patterns:
            for match in re.finditer(pattern, prompt):
                value = normalize_typed_project_value(match.group(1).strip().strip("'\""), data_type)
                if valid_typed_project_value(value, data_type):
                    matches.add(value)
    return next(iter(matches)) if len(matches) == 1 else None


def valid_typed_project_value(value: str, data_type: str | None) -> bool:
    text = str(value or "").strip()
    kind = str(data_type or "").upper()
    if not text or re.fullmatch(r"\$[A-Za-z_][A-Za-z0-9_]*", text):
        return False
    if kind.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT", "INTEGER", "BIGINT", "FLOAT", "DOUBLE")):
        return bool(re.fullmatch(r"[-+]?(?:\d+\.?\d*|\.\d+)", text))
    if kind.startswith(("BOOLEAN", "BOOL")):
        return text.upper() in {"TRUE", "FALSE"}
    if kind.startswith("DATE"):
        try:
            date.fromisoformat(text)
        except ValueError:
            return False
    return True
