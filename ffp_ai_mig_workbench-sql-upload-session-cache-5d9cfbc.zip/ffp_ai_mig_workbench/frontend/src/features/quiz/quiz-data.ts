/**
 * Hardcoded quiz content. Shaped like a future API response so the backend can
 * replace `QUIZ_QUESTION_POOL` later without touching the screen.
 */

export const QUIZ_CATEGORIES = [
  'Getting Started',
  'Projects & Mappings',
  'Select Tables',
  'Map · Transform · Validate',
  'Final Mapping & Summary',
] as const;

export type QuizArea = (typeof QUIZ_CATEGORIES)[number];

export type QuizQuestion = {
  id: string;
  area: QuizArea;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
};

export const QUIZ_TITLE = 'Workbench Knowledge Quiz';

/** Every attempt draws this many random questions from each category (5 × 3 = 15). */
export const QUESTIONS_PER_CATEGORY = 3;

export const QUIZ_QUESTION_POOL: QuizQuestion[] = [
  // ---------------------------------------------------------------- Getting Started
  {
    id: 'gs-1',
    area: 'Getting Started',
    question:
      'You have signed in to the Snowflake portal. How do you then sign in to the Migration Workbench itself?',
    options: [
      'No second step is needed; the portal sign-in covers everything',
      'Click "Sign in with Snowflake" on the workbench home screen',
      'Ask an administrator to create a workbench password',
      'Open the AI Agent and type your username',
    ],
    correctOptionIndex: 1,
    explanation:
      'The portal sign-in only opens the platform. The in-app "Sign in with Snowflake" on the home screen signs you in to the workbench so you can use data, mappings and the AI Agent.',
  },
  {
    id: 'gs-2',
    area: 'Getting Started',
    question: 'What happens if you open a workbench screen before signing in to the workbench?',
    options: [
      'The screen loads with empty data',
      'You see an error page with no way forward',
      'After a short session check you are taken to the home screen to sign in',
      'You are signed in automatically',
    ],
    correctOptionIndex: 2,
    explanation:
      'Screens wait for the session check. If you are not signed in to the workbench yet, you are sent to the home screen to click "Sign in with Snowflake".',
  },
  {
    id: 'gs-3',
    area: 'Getting Started',
    question: 'What does STTM stand for?',
    options: [
      'Source-to-Target Mapping',
      'Snowflake Table Transfer Model',
      'Structured Table Transformation Method',
      'Standard Target Template Manager',
    ],
    correctOptionIndex: 0,
    explanation:
      'An STTM (Source-to-Target Mapping) describes how each target column is filled from source columns.',
  },
  {
    id: 'gs-4',
    area: 'Getting Started',
    question: 'Which of these is NOT one of the Dashboard summary counts?',
    options: [
      'Total Projects',
      'In-progress Mappings',
      'Published Mappings',
      'Failed Snowflake Logins',
    ],
    correctOptionIndex: 3,
    explanation:
      'The Dashboard shows Total Projects, Total Mappings, In-progress Mappings and Published Mappings.',
  },
  {
    id: 'gs-5',
    area: 'Getting Started',
    question: 'What can the STTM AI Agent help you with?',
    options: [
      'Resetting your Snowflake password',
      'Generating CTEs, joins and transform rules from natural language',
      'Changing other users\' roles',
      'Approving target tables in the metadata schema',
    ],
    correctOptionIndex: 1,
    explanation:
      'Describe what you need in plain English and the AI Agent suggests CTEs, joins and transform rules for your mapping.',
  },
  {
    id: 'gs-6',
    area: 'Getting Started',
    question: 'What does the "Tour Guide" button do?',
    options: [
      'Opens the user manual as a PDF',
      'Starts a step-by-step walkthrough of the current screen',
      'Contacts the support team',
      'Resets the screen layout',
    ],
    correctOptionIndex: 1,
    explanation:
      'Tour Guide highlights each part of the current screen in turn and explains what it does.',
  },

  // ---------------------------------------------------------------- Projects & Mappings
  {
    id: 'pm-1',
    area: 'Projects & Mappings',
    question: 'What is a Project used for in the workbench?',
    options: [
      'Storing Snowflake credentials for each user',
      'Running scheduled data loads',
      'Grouping related mappings into a folder',
      'Defining screen permissions for a role',
    ],
    correctOptionIndex: 2,
    explanation:
      'Projects are folders that group mappings, e.g. all mappings for one CRM migration.',
  },
  {
    id: 'pm-2',
    area: 'Projects & Mappings',
    question:
      'In New Project, what does the Project Setup option "Create target mappings automatically" do?',
    options: [
      'Pre-creates mappings for the template\'s approved target tables',
      'Publishes every mapping in the project straight away',
      'Copies all mappings from another project',
      'Creates a project with no mappings',
    ],
    correctOptionIndex: 0,
    explanation:
      'Automatic setup pre-creates mappings for the approved target tables of the chosen template. "Create empty project" starts with none.',
  },
  {
    id: 'pm-3',
    area: 'Projects & Mappings',
    question:
      'With "Create target mappings automatically" selected, why might Create Project stay disabled even though every field is filled?',
    options: [
      'The project name is too long',
      'The template has no approved target tables',
      'Another project uses the same colour',
      'The Owner field is empty',
    ],
    correctOptionIndex: 1,
    explanation:
      'Automatic setup needs at least one approved target table. Choose "Create empty project" or get the target tables approved.',
  },
  {
    id: 'pm-4',
    area: 'Projects & Mappings',
    question: 'Which of these is NOT one of the "+ New Mapping" options?',
    options: [
      'SQL Upload',
      'Upload Excel',
      'Build Mapping Manually',
      'Import from a CRM API',
    ],
    correctOptionIndex: 3,
    explanation:
      'New Mapping offers SQL Upload, Upload Excel and Build Mapping Manually (the 3-step wizard).',
  },
  {
    id: 'pm-5',
    area: 'Projects & Mappings',
    question: 'What does the "SQL Upload" option do?',
    options: [
      'Runs your SQL directly against production',
      'Uses AI to turn existing SQL into a source-to-target mapping',
      'Uploads SQL as an attachment without processing it',
      'Converts SQL into an Excel file',
    ],
    correctOptionIndex: 1,
    explanation:
      'SQL Upload parses your existing SQL and builds the mapping (STTM) from it, so you don\'t start from scratch.',
  },
  {
    id: 'pm-6',
    area: 'Projects & Mappings',
    question: 'What is the correct order of the mapping wizard steps?',
    options: [
      'Map · Transform · Validate → Select Tables → Final Mapping & Summary',
      'Select Tables → Map · Transform · Validate → Final Mapping & Summary',
      'Select Tables → Final Mapping & Summary → Map · Transform · Validate',
      'Final Mapping & Summary → Select Tables → Map · Transform · Validate',
    ],
    correctOptionIndex: 1,
    explanation:
      'You first choose the tables, then map and transform the columns, and finally review and publish.',
  },

  // ---------------------------------------------------------------- Select Tables
  {
    id: 'st-1',
    area: 'Select Tables',
    question: 'What must you select before Next is enabled on Select Tables?',
    options: [
      'Exactly one source and at least one target',
      'At least one CTE and one target',
      'At least one source and exactly one target',
      'Any single table',
    ],
    correctOptionIndex: 2,
    explanation:
      'A mapping loads into exactly one target table, from one or more source tables.',
  },
  {
    id: 'st-2',
    area: 'Select Tables',
    question: 'What is the Driving table?',
    options: [
      'The first source selected; it sets the row grain and join direction',
      'The target table being loaded',
      'The largest table in the schema',
      'A CTE created with the Function Library',
    ],
    correctOptionIndex: 0,
    explanation:
      'The first source becomes the Driving table (orange DRIVING badge). It can be reassigned from the table\'s context menu.',
  },
  {
    id: 'st-3',
    area: 'Select Tables',
    question: 'What does "Create CTE" let you do?',
    options: [
      'Create a new physical table in Snowflake',
      'Define a derived table with SQL and reuse it as a source',
      'Export the mapping as a CSV file',
      'Copy the target table structure',
    ],
    correctOptionIndex: 1,
    explanation:
      'Create CTE opens the Add Derived Table popup. The CTE is then listed under CTE Sources and can be mapped like a source table.',
  },
  {
    id: 'st-4',
    area: 'Select Tables',
    question: 'What are Filter Conditions used for?',
    options: [
      'Hiding columns from the mapping grid',
      'Restricting which source rows are included, using conditions and groups',
      'Sorting the table list alphabetically',
      'Choosing which users can see the mapping',
    ],
    correctOptionIndex: 1,
    explanation:
      'Filter Conditions add WHERE-style rules (in groups) so only the rows you need are loaded.',
  },
  {
    id: 'st-5',
    area: 'Select Tables',
    question: 'Which category tab in the Function Library holds window functions such as ROW_NUMBER and LAG?',
    options: ['String', 'Logic', 'Window +', 'Conversion'],
    correctOptionIndex: 2,
    explanation:
      'The Function Library tabs are String, Numeric, Date, Conversion, Logic and Window +.',
  },
  {
    id: 'st-6',
    area: 'Select Tables',
    question: 'In Join Definition, how are AI join recommendations labelled?',
    options: [
      'By High, Medium and Low confidence',
      'By table size',
      'By the date they were created',
      'They are not labelled',
    ],
    correctOptionIndex: 0,
    explanation:
      'AI Recommendations are grouped by High, Medium and Low confidence so you can review the strongest joins first.',
  },

  // ---------------------------------------------------------------- Map · Transform · Validate
  {
    id: 'mtv-1',
    area: 'Map · Transform · Validate',
    question: 'What does Auto Map do?',
    options: [
      'Publishes all mappings without review',
      'Deletes unmapped target columns',
      'Uses AI to fill source columns, with a confidence score and reason',
      'Sorts rows alphabetically',
    ],
    correctOptionIndex: 2,
    explanation:
      'Auto Map suggests a source for each target column and shows how confident it is and why. You can still edit any row.',
  },
  {
    id: 'mtv-2',
    area: 'Map · Transform · Validate',
    question: 'Which confidence range puts a row in the High Confidence group?',
    options: ['50–70%', '60–80%', '70–90%', '80–100%'],
    correctOptionIndex: 3,
    explanation:
      'High is 80–100% and Medium is 60–80%; the rest are Low or Unmapped.',
  },
  {
    id: 'mtv-3',
    area: 'Map · Transform · Validate',
    question: 'What does the Confidence column show after you edit a row yourself?',
    options: ['100%', 'Manual', 'Unknown', 'It stays at the AI score'],
    correctOptionIndex: 1,
    explanation:
      'Rows you set yourself show "Manual" instead of an AI confidence score.',
  },
  {
    id: 'mtv-4',
    area: 'Map · Transform · Validate',
    question: 'Which Transform Rule opens the Pre-Processing Rule popup from the Source Column?',
    options: ['Direct', 'Custom', 'Upper', 'Trim'],
    correctOptionIndex: 1,
    explanation:
      'With Custom selected, the magic icon in Source Column opens the Pre-Processing Rule popup, where you write the SQL expression.',
  },
  {
    id: 'mtv-5',
    area: 'Map · Transform · Validate',
    question: 'In the Pre-Processing Rule popup, what happens when you click a Firm Value?',
    options: [
      'Its value is inserted into the SQL Preview as a literal',
      'Its name is inserted as a column',
      'The project settings open',
      'The rule is applied immediately',
    ],
    correctOptionIndex: 0,
    explanation:
      'Firm values are project attributes. Clicking one inserts its value (e.g. \'ABC Wealth\') into the SQL Preview.',
  },
  {
    id: 'mtv-6',
    area: 'Map · Transform · Validate',
    question: 'After you click Apply Rule in the Pre-Processing popup, what does the NL Rule column show?',
    options: [
      'Nothing; it is always typed by hand',
      'The target column name',
      'The SQL from the SQL Preview',
      'The AI confidence reason',
    ],
    correctOptionIndex: 2,
    explanation:
      'Apply Rule saves the expression and copies the SQL Preview into the row\'s NL Rule.',
  },
  {
    id: 'mtv-7',
    area: 'Map · Transform · Validate',
    question: 'When does a row get the Mapped badge?',
    options: [
      'As soon as the AI suggests a source',
      'When it has a description',
      'When it has a source column, a transform rule and an order',
      'Only after the mapping is published',
    ],
    correctOptionIndex: 2,
    explanation:
      'A row counts as Mapped once its source column, rule and order are all set.',
  },

  // ---------------------------------------------------------------- Final Mapping & Summary
  {
    id: 'fms-1',
    area: 'Final Mapping & Summary',
    question: 'Before a mapping can be published, which check must pass?',
    options: [
      'Compile & Validate of the generated SQL',
      'An Excel download',
      'A Data Lineage export',
      'A Tour Guide run',
    ],
    correctOptionIndex: 0,
    explanation:
      'Publish is gated on Compile & Validate (SQL tab of Map · Transform · Validate), so only SQL that compiles can be published.',
  },
  {
    id: 'fms-2',
    area: 'Final Mapping & Summary',
    question: 'You changed a mapping after validating its SQL. What do you need to do before publishing?',
    options: [
      'Nothing; the earlier validation still counts',
      'Run Compile & Validate again',
      'Create a new project',
      'Download the Excel file',
    ],
    correctOptionIndex: 1,
    explanation:
      'Any change after validation means the SQL must be compiled and validated again before you can publish.',
  },
  {
    id: 'fms-3',
    area: 'Final Mapping & Summary',
    question: 'Which of these is NOT a tab in Final Mapping & Summary?',
    options: ['STTM Sheet', 'Data Lineage', 'DBT Conversion', 'Join Designer'],
    correctOptionIndex: 3,
    explanation:
      'The summary tabs include STTM Sheet, SQL Preview, Data Lineage, DBT Conversion and Test Cases. Joins are designed on Select Tables.',
  },
  {
    id: 'fms-4',
    area: 'Final Mapping & Summary',
    question: 'Which downloads are available from Final Mapping & Summary?',
    options: [
      'Excel and SQL',
      'PDF and Word',
      'CSV only',
      'No downloads are available',
    ],
    correctOptionIndex: 0,
    explanation:
      'Use Download Excel for the mapping sheet and Download SQL for the generated SQL.',
  },
  {
    id: 'fms-5',
    area: 'Final Mapping & Summary',
    question: 'What does the Data Lineage view show?',
    options: [
      'Who edited the mapping and when',
      'How target columns are derived from source tables and columns',
      'The Snowflake warehouse usage',
      'A list of all projects',
    ],
    correctOptionIndex: 1,
    explanation:
      'Data Lineage traces each target column back through transformations to the source columns it comes from.',
  },
  {
    id: 'fms-6',
    area: 'Final Mapping & Summary',
    question: 'After a mapping is published successfully, what are your options in the confirmation popup?',
    options: [
      'Undo publish or delete the mapping',
      '"Stay here" or "Go to Mappings"',
      'Download Excel or Download SQL',
      'There is no confirmation',
    ],
    correctOptionIndex: 1,
    explanation:
      'The success popup lets you stay on the summary or continue to the Mappings list.',
  },
];

/** Result messages by score percentage, highest threshold first. */
export const QUIZ_RESULT_LEVELS = [
  { minPercent: 90, title: 'Workbench expert', message: 'Excellent! You know the workbench inside out.' },
  { minPercent: 70, title: 'Confident user', message: 'Great job. Review the missed questions to close the gaps.' },
  { minPercent: 40, title: 'Getting there', message: 'Good start. The explanations below will help you level up.' },
  { minPercent: 0, title: 'Just starting', message: 'No worries. Go through the explanations and try again.' },
] as const;

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/** Same question with its options in random order (the correct answer index follows). */
function withShuffledOptions(question: QuizQuestion): QuizQuestion {
  const order = shuffle(question.options.map((_, index) => index));
  return {
    ...question,
    options: order.map((index) => question.options[index]),
    correctOptionIndex: order.indexOf(question.correctOptionIndex),
  };
}

/**
 * One attempt: `QUESTIONS_PER_CATEGORY` random questions from every category, so each
 * category gets the same share. Questions from the previous attempt are used only when a
 * category has no unused ones left. Question and option order are shuffled too.
 */
export function buildQuizAttempt(previousQuestionIds: string[] = []): QuizQuestion[] {
  const previous = new Set(previousQuestionIds);
  const picked = QUIZ_CATEGORIES.flatMap((category) => {
    const inCategory = QUIZ_QUESTION_POOL.filter((question) => question.area === category);
    const fresh = shuffle(inCategory.filter((question) => !previous.has(question.id)));
    const repeats = shuffle(inCategory.filter((question) => previous.has(question.id)));
    return [...fresh, ...repeats].slice(0, QUESTIONS_PER_CATEGORY);
  });
  return shuffle(picked).map(withShuffledOptions);
}
