'use client';

import { useEffect, useMemo, useState } from 'react';
import { AiaBox, AiaButton, AiaDialog, AiaIconButton } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { AiaAutocomplete } from '@/components/ui/aia-auto-complete';
import type { Column, ColumnGroup, DatabaseNode, DerivedSource } from '@/features/sttm/types/sttm.types';
import {
  buildSelectedSourceHierarchy,
  type SourceHierarchyDatabase,
} from '@/features/sttm/shared/source-hierarchy-utils';
import { CloseRoundedIcon } from '@/utils/icons';
import { formatSqlType, getDerivedDisplayColumns, tableAlias } from './mapping-utils';

type DirectSourcePickerModalProps = {
  open: boolean;
  onClose: () => void;
  onApply: (payload: {
    sourceColumn: string;
    sourceType: string | null;
  }) => void;
  targetColumn: string;
  targetType?: string | null;
  initialSourceColumn?: string | null;
  sourceDatabases: DatabaseNode[];
  sourceAttributeGroups: ColumnGroup[];
  derivedSources?: DerivedSource[];
};

const modalPrimaryButtonColors = {
  customBackgroundColor: 'var(--aia-primary-bg-color)',
  customColor: 'var(--aia-primary-bg-text-color)',
  customBorderColor: 'var(--aia-primary-bg-color)',
  customHoverBackgroundColor: 'var(--aia-primary-bg-hover-color)',
} as const;

const fieldLabelSx = {
  mb: 1,
  fontSize: 11,
  fontWeight: 700,
  letterSpacing: '0.04em',
  textTransform: 'uppercase' as const,
  color: '#64748b',
};

const DERIVED_DB_ID = '__derived__';

function parseSourceColumnParts(value: string | null | undefined): {
  database: string;
  schema: string;
  table: string;
  column: string;
} {
  const parts = String(value ?? '')
    .split('.')
    .map((part) => part.trim())
    .filter(Boolean);
  if (parts.length >= 4) {
    return {
      database: parts[0],
      schema: parts[1],
      table: parts[2],
      column: parts.slice(3).join('.'),
    };
  }
  if (parts.length === 3) {
    return {
      database: '',
      schema: parts[0],
      table: parts[1],
      column: parts[2],
    };
  }
  if (parts.length === 2) {
    return {
      database: DERIVED_DB_ID,
      schema: '',
      table: parts[0],
      column: parts[1],
    };
  }
  return { database: '', schema: '', table: '', column: parts[0] ?? '' };
}

function buildDerivedHierarchy(derivedSources: DerivedSource[]): SourceHierarchyDatabase | null {
  const selected = derivedSources.filter((source) => source.isSelected !== false);
  if (!selected.length) return null;

  return {
    dbId: DERIVED_DB_ID,
    dbName: 'Derived',
    schemas: [
      {
        schemaId: 'derived',
        schemaName: 'derived',
        tables: selected.map((source) => {
          const aliasSeed = source.alias || source.sourceName || source.id;
          const alias = tableAlias(String(aliasSeed).replace(/\s+/g, '_'));
          return {
            tableId: source.id,
            tableName: source.sourceName || alias,
            qualifiedName: alias,
            columns: getDerivedDisplayColumns(source).map((column) => ({
              name: column.name,
              type: column.type,
            })),
          };
        }),
      },
    ],
  };
}

function findColumnType(columns: Column[], columnName: string): string | null {
  const match = columns.find(
    (column) => column.name?.toLowerCase() === columnName.toLowerCase(),
  );
  return match?.type ?? null;
}

export default function DirectSourcePickerModal({
  open,
  onClose,
  onApply,
  targetColumn,
  targetType,
  initialSourceColumn,
  sourceDatabases,
  sourceAttributeGroups,
  derivedSources = [],
}: DirectSourcePickerModalProps) {
  const hierarchy = useMemo(() => {
    const physical = buildSelectedSourceHierarchy(sourceDatabases, sourceAttributeGroups);
    const derived = buildDerivedHierarchy(derivedSources);
    return derived ? [...physical, derived] : physical;
  }, [derivedSources, sourceAttributeGroups, sourceDatabases]);

  const [databaseId, setDatabaseId] = useState('');
  const [schemaId, setSchemaId] = useState('');
  const [tableId, setTableId] = useState('');
  const [columnName, setColumnName] = useState('');

  useEffect(() => {
    if (!open) return;

    const parsed = parseSourceColumnParts(initialSourceColumn);
    let nextDb: SourceHierarchyDatabase | null = hierarchy.find(
      (db) =>
        db.dbId === parsed.database
        || db.dbName.toLowerCase() === parsed.database.toLowerCase(),
    ) ?? hierarchy[0] ?? null;

    if (!nextDb && parsed.database === DERIVED_DB_ID) {
      nextDb = hierarchy.find((db) => db.dbId === DERIVED_DB_ID) ?? null;
    }

    const nextSchema =
      nextDb?.schemas.find(
        (schema) =>
          schema.schemaId === parsed.schema
          || schema.schemaName.toLowerCase() === parsed.schema.toLowerCase(),
      )
      ?? nextDb?.schemas[0]
      ?? null;

    const nextTable =
      nextSchema?.tables.find((table) => {
        const alias = table.qualifiedName.split('.').filter(Boolean).at(-1) ?? table.tableName;
        return (
          table.tableId === parsed.table
          || table.tableName.toLowerCase() === parsed.table.toLowerCase()
          || alias.toLowerCase() === parsed.table.toLowerCase()
          || table.qualifiedName.toLowerCase() === `${parsed.schema}.${parsed.table}`.toLowerCase()
          || table.qualifiedName.toLowerCase().endsWith(`.${parsed.table}`.toLowerCase())
        );
      })
      ?? nextSchema?.tables[0]
      ?? null;

    const nextColumn =
      nextTable?.columns.find(
        (column) => column.name?.toLowerCase() === parsed.column.toLowerCase(),
      )?.name
      ?? '';

    // eslint-disable-next-line react-hooks/set-state-in-effect
    setDatabaseId(nextDb?.dbId ?? '');
    setSchemaId(nextSchema?.schemaId ?? '');
    setTableId(nextTable?.tableId ?? '');
    setColumnName(nextColumn);
  }, [hierarchy, initialSourceColumn, open]);

  const selectedDatabase = hierarchy.find((db) => db.dbId === databaseId) ?? null;
  const selectedSchema =
    selectedDatabase?.schemas.find((schema) => schema.schemaId === schemaId) ?? null;
  const selectedTable =
    selectedSchema?.tables.find((table) => table.tableId === tableId) ?? null;

  const databaseOptions = hierarchy.map((db) => ({
    label: db.dbName,
    value: db.dbId,
  }));
  const schemaOptions = (selectedDatabase?.schemas ?? []).map((schema) => ({
    label: schema.schemaName,
    value: schema.schemaId,
  }));
  const tableOptions = (selectedSchema?.tables ?? []).map((table) => ({
    label: table.tableName,
    value: table.tableId,
  }));
  const columnOptions = (selectedTable?.columns ?? [])
    .filter((column) => column.name)
    .map((column) => ({
      label: column.type
        ? `${column.name} (${formatSqlType(column.type).toLowerCase()})`
        : column.name!,
      value: column.name!,
    }));

  const canApply = Boolean(selectedTable && columnName.trim());

  const handleApply = () => {
    if (!selectedTable || !columnName.trim()) return;
    const sourceColumn = `${selectedTable.qualifiedName}.${columnName.trim()}`;
    onApply({
      sourceColumn,
      sourceType: findColumnType(selectedTable.columns, columnName.trim()),
    });
    onClose();
  };

  return (
    <AiaDialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      slotProps={{
        paper: {
          sx: {
            borderRadius: 2,
            overflow: 'hidden',
          },
        },
      }}
    >
      <AiaBox
        sx={{
          px: 2.5,
          py: 1.75,
          borderBottom: '1px solid #e5e7eb',
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'space-between',
          gap: 2,
        }}
      >
        <AiaBox sx={{ minWidth: 0 }}>
          <AiaText sx={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>
            Direct source mapping
          </AiaText>
          <AiaText sx={{ mt: 0.5, fontSize: '0.82rem', color: '#64748b' }}>
            Choose database, schema, table, and column for this target field.
          </AiaText>
        </AiaBox>
        <AiaIconButton
          aria-label="Close"
          onClick={onClose}
          size="small"
          sx={{
            color: '#64748b',
            '&:hover': {
              bgcolor: '#f1f5f9',
              color: '#0f172a',
            },
          }}
        >
          <CloseRoundedIcon sx={{ fontSize: 20 }} />
        </AiaIconButton>
      </AiaBox>

      <AiaBox sx={{ px: 2.5, py: 2, display: 'grid', gap: 2 }}>
        <AiaBox
          sx={{
            p: 1.5,
            borderRadius: 1.5,
            border: '1px solid #e2e8f0',
            bgcolor: '#f8fafc',
            display: 'grid',
            gap: 0.35,
          }}
        >
          <AiaText sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            Target column
          </AiaText>
          <AiaText sx={{ fontSize: '0.95rem', fontWeight: 700, color: '#0f172a', overflowWrap: 'anywhere' }}>
            {targetColumn || 'Untitled target'}
          </AiaText>
          {targetType ? (
            <AiaText sx={{ fontSize: '0.78rem', color: '#64748b' }}>
              Type: {formatSqlType(targetType).toLowerCase()}
            </AiaText>
          ) : null}
        </AiaBox>

        <AiaBox>
          <AiaText sx={fieldLabelSx}>Database</AiaText>
          <AiaAutocomplete
            hideLabel
            size="small"
            fullWidth
            value={databaseId}
            options={databaseOptions}
            placeholder="Select database..."
            onChange={(next) => {
              const nextId = Array.isArray(next) ? next[0] ?? '' : next;
              setDatabaseId(nextId);
              const db = hierarchy.find((item) => item.dbId === nextId);
              const firstSchema = db?.schemas[0];
              setSchemaId(firstSchema?.schemaId ?? '');
              setTableId(firstSchema?.tables[0]?.tableId ?? '');
              setColumnName('');
            }}
          />
        </AiaBox>

        <AiaBox>
          <AiaText sx={fieldLabelSx}>Schema</AiaText>
          <AiaAutocomplete
            hideLabel
            size="small"
            fullWidth
            value={schemaId}
            options={schemaOptions}
            placeholder="Select schema..."
            disabled={!databaseId}
            onChange={(next) => {
              const nextId = Array.isArray(next) ? next[0] ?? '' : next;
              setSchemaId(nextId);
              const schema = selectedDatabase?.schemas.find((item) => item.schemaId === nextId);
              setTableId(schema?.tables[0]?.tableId ?? '');
              setColumnName('');
            }}
          />
        </AiaBox>

        <AiaBox>
          <AiaText sx={fieldLabelSx}>Table</AiaText>
          <AiaAutocomplete
            hideLabel
            size="small"
            fullWidth
            value={tableId}
            options={tableOptions}
            placeholder="Select table..."
            disabled={!schemaId}
            onChange={(next) => {
              const nextId = Array.isArray(next) ? next[0] ?? '' : next;
              setTableId(nextId);
              setColumnName('');
            }}
          />
        </AiaBox>

        <AiaBox>
          <AiaText sx={fieldLabelSx}>Column</AiaText>
          <AiaAutocomplete
            hideLabel
            size="small"
            fullWidth
            value={columnName}
            options={columnOptions}
            placeholder="Select column..."
            disabled={!tableId}
            onChange={(next) => {
              setColumnName(Array.isArray(next) ? next[0] ?? '' : next);
            }}
          />
        </AiaBox>
      </AiaBox>

      <AiaBox
        sx={{
          px: 2.5,
          py: 1.75,
          borderTop: '1px solid #e5e7eb',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: 1,
        }}
      >
        <AiaButton variant="outlined" onClick={onClose}>
          Cancel
        </AiaButton>
        <AiaButton
          variant="contained"
          disabled={!canApply}
          onClick={handleApply}
          {...modalPrimaryButtonColors}
        >
          Apply
        </AiaButton>
      </AiaBox>
    </AiaDialog>
  );
}
