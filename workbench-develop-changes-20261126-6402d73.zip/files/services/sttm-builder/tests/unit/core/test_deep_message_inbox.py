from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from app.agent_runs.models import RunStatus
from app import api  # Initialize the shared API router before loading its children.
from app.routers import assistant_conversations as router


@pytest.fixture
def inbox(monkeypatch):
    conversations, runs = MagicMock(), MagicMock()
    envelope = lambda **kwargs: SimpleNamespace(data=kwargs['data'])
    monkeypatch.setattr(router, '_identity', lambda _: ('u', 't', SimpleNamespace(user_id='u', tenant_id='t', effective_role='R')))
    monkeypatch.setattr(router, '_repositories', lambda *_: (conversations, runs))
    monkeypatch.setattr(router, 'build_response_envelope', envelope)
    conversations.get.return_value = SimpleNamespace(mode=SimpleNamespace(value='deep'), project_id='project')
    runs.get_latest_run_for_conversation.return_value = SimpleNamespace(
        run_id='run', status=RunStatus.COMPLETED,
        actor=SimpleNamespace(user_id='u', tenant_id='t', effective_role='R'),
    )
    runs.list_review_items.return_value = []
    pending = SimpleNamespace(turn_id='inbox_1', metadata={
        'delivery': 'pending', 'mode': 'queue',
        'turn': {'message': 'Explain the saved mapping', 'idempotency_key': 'client-message'},
    })
    conversations.pending_messages.return_value = [pending]
    return conversations, runs, pending


def test_delivery_waits_for_success_and_claims_the_saved_turn_once(inbox, monkeypatch):
    conversations, runs, pending = inbox
    dispatched = MagicMock(return_value=SimpleNamespace(data={'turn_id': 'turn_1'}))
    monkeypatch.setattr(router, '_submit_turn', dispatched)
    latest = runs.get_latest_run_for_conversation.return_value
    latest.status = RunStatus.AWAITING_INPUT
    assert router.deliver_pending_message(None, 'conv', None, None, None).data is None
    latest.status = RunStatus.FAILED
    assert router.deliver_pending_message(None, 'conv', None, None, None).data is None
    dispatched.assert_not_called()

    latest.status = RunStatus.COMPLETED
    conversations.transition_pending_message.return_value = False
    assert router.deliver_pending_message(None, 'conv', None, None, None).data is None
    dispatched.assert_not_called()

    conversations.transition_pending_message.return_value = True
    assert router.deliver_pending_message(None, 'conv', None, None, None).data == {'turn_id': 'turn_1'}
    assert dispatched.call_args.args[2].idempotency_key == 'delivery:inbox_1'
    pending.metadata['delivery'] = 'submitting'
    conversations.find_turn_by_idempotency.return_value = SimpleNamespace(metadata={'execution_path': 'new_run'})
    assert router.deliver_pending_message(None, 'conv', None, None, None).data is None
    dispatched.assert_called_once()
