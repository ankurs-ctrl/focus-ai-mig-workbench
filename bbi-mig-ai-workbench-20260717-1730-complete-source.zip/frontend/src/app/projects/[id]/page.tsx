import ProjectDetailPage from '@/features/projects/ProjectDetailPage';

type PageProps = {
  params: { id: string };
};

export default function Page({ params }: PageProps) {
  return <ProjectDetailPage projectId={params.id} />;
}
