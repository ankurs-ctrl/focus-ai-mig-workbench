"""Real Analyst port/SQL validation and nested permit fencing, simulated API/SQL."""

from copy import deepcopy
from decimal import Decimal
from datetime import date
import pytest
from app.core import automap_native_ports as ports
from app.core.automap_native_tools import NativeToolError
from tests.unit.core.test_automap_native_tools import system


class Session:
    def __init__(self):
        self.transaction = False
        self.view = None
        self.definition = None
        self.events = []
        self.slots = [
            {"SLOT_ID": index, "FENCE": 0, "STATE": "FREE", "OWNER_TOKEN": None}
            for index in range(4)
        ]

    def sql(self, query, params=None):
        def collect(**kwargs):
            self.events.append(query)
            params_ = params or []
            if query == "SELECT CURRENT_TRANSACTION() AS TX":
                return [{"TX": 1 if self.transaction else None}]
            if query == "BEGIN":
                self.transaction = True
                return []
            if query in {"COMMIT", "ROLLBACK"}:
                self.transaction = False
                return []
            if query.startswith("SELECT SLOT_ID"):
                return deepcopy(self.slots)
            if "SET STATE='HELD'" in query:
                token, slot, fence = params_
                item = self.slots[slot]
                assert item["STATE"] == "FREE" and item["FENCE"] == fence
                item.update(STATE="HELD", OWNER_TOKEN=token, FENCE=fence + 1)
                return [{"number of rows updated": 1}]
            if "TBL_AUTOMAP_NATIVE_ANALYST_SLOTS SET STATE=" in query:
                slot, fence, token = params_
                item = self.slots[slot]
                assert item["FENCE"] == fence and item["OWNER_TOKEN"] == token
                item["STATE"] = "QUARANTINED" if "'QUARANTINED'" in query else "FREE"
                return [{"number of rows updated": 1}]
            if query.startswith("CREATE VIEW"):
                self.view = query.split(" AS ", 1)[0].split()[-1]
                self.definition = query.split(" AS ", 1)[1]
                return []
            if query.startswith("SELECT GET_DDL"):
                return [{"DDL": "CREATE VIEW " + self.view + " AS " + self.definition}]
            if query.startswith("EXPLAIN"):
                return []
            if query == "SELECT LAST_QUERY_ID() AS QUERY_ID":
                return [{"QUERY_ID": "observed-query-id"}]
            if query.startswith("SELECT") or query.startswith("WITH"):
                return [{"RESULT": Decimal("2.500"), "OBSERVED_ON": date(2026, 1, 1)}]
            raise AssertionError(query)

        return type("Frame", (), {"collect": staticmethod(collect)})()


def prepared():
    _, snap, _, _ = system()
    snap["bundle"] = {
        "id": "prepared",
        "hash": "bundle-hash",
        "coverage_validated": True,
    }
    return snap, list(snap["sources"]), {"metadata": "D.META", "analyst_slots": 4}


def test_actual_analyst_call_is_followed_by_validation_then_bounded_execution(
    monkeypatch,
):
    snap, ids, config = prepared()
    session = Session()
    calls = []

    def api(method, path, payload, **kw):
        calls.append((method, path, payload))
        session.events.append("API")
        assert "bundle" not in payload and "semantic_model" in payload
        return {
            "request_id": "provider-request",
            "message": {
                "role": "analyst",
                "content": [
                    {
                        "type": "sql",
                        "statement": "SELECT COUNT(*) AS N FROM " + session.view,
                    }
                ],
            },
        }

    monkeypatch.setattr(ports, "api", api)
    result = ports.ask_analyst(
        session, snap, ids, "How many records are in this prepared population?", config
    )
    assert len(calls) == 1 and calls[0][1] == "/api/v2/cortex/analyst/message"
    assert result["status"] == "executed" and result["data_result_obtained"] is True
    assert (
        result["query_id"] == "observed-query-id"
        and result["bundle"]["hash"] == "bundle-hash"
    )
    assert result["rows"][0]["RESULT"] == {"type": "decimal", "value": "2.500"}
    events = session.events
    api_index = events.index("API")
    assert events[api_index + 1].startswith(
        "SELECT CURRENT_TRANSACTION"
    )  # nested permit release
    explain = next(i for i, text in enumerate(events) if text.startswith("EXPLAIN"))
    read = next(i for i, text in enumerate(events) if text.startswith("SELECT COUNT"))
    assert api_index < explain < read and "LIMIT 100" in events[read]
    assert all(slot["STATE"] == "FREE" for slot in session.slots)


@pytest.mark.parametrize(
    "poison",
    ["foreign", "failed", "unknown", "suggestions", "quoted-foreign"],
    ids=[
        "foreign-sql",
        "failed-status",
        "unknown-block",
        "ambiguous",
        "quoted-case-escape",
    ],
)
def test_failed_or_ambiguous_analyst_content_never_executes_generated_sql(
    monkeypatch, poison
):
    snap, ids, config = prepared()
    session = Session()

    def api(*a, **kw):
        statement = "SELECT COUNT(*) FROM " + session.view
        if poison == "foreign":
            statement = "SELECT * FROM SECRET.DATA.OTHER"
        if poison == "quoted-foreign":
            statement = (
                'SELECT * FROM "d"."meta"."' + session.view.split(".")[-1].lower() + '"'
            )
        body = {
            "message": {
                "role": "analyst",
                "content": [{"type": "sql", "statement": statement}],
            }
        }
        if poison == "failed":
            body["status"] = "failed"
        if poison == "unknown":
            body["message"]["content"].append({"type": "execute"})
        if poison == "suggestions":
            body["message"]["content"].append(
                {"type": "suggestions", "suggestions": ["Clarify population"]}
            )
        return body

    monkeypatch.setattr(ports, "api", api)
    if poison == "suggestions":
        assert (
            ports.ask_analyst(session, snap, ids, "Question", config)["status"]
            == "ambiguous"
        )
    else:
        with pytest.raises(NativeToolError):
            ports.ask_analyst(session, snap, ids, "Question", config)
    assert not any(
        text.startswith("EXPLAIN") or text.startswith("SELECT COUNT")
        for text in session.events
    )
    assert all(slot["STATE"] == "FREE" for slot in session.slots)


def test_uncertain_analyst_post_is_quarantined_without_replay(monkeypatch):
    snap, ids, config = prepared()
    session = Session()
    posts = []

    def api(*a, **kw):
        posts.append(True)
        raise TimeoutError("lost acknowledgement")

    monkeypatch.setattr(ports, "api", api)
    with pytest.raises(TimeoutError):
        ports.ask_analyst(session, snap, ids, "Question", config)
    assert (
        len(posts) == 1
        and sum(slot["STATE"] == "QUARANTINED" for slot in session.slots) == 1
    )


def test_duplicate_nested_pool_inventory_is_rejected_before_api(monkeypatch):
    snap, ids, config = prepared()
    session = Session()
    session.slots[1]["SLOT_ID"] = 0
    monkeypatch.setattr(
        ports, "api", lambda *a, **kw: pytest.fail("provider must not be invoked")
    )
    with pytest.raises(NativeToolError, match="inventory"):
        ports.ask_analyst(session, snap, ids, "Question", config)


def test_quoted_physical_case_is_distinct_while_unquoted_columns_fold():
    assert "LIMIT 100" in ports.validate_analyst_sql(
        "SELECT c_1 FROM D.S.V", "D.S.V", {"C_1"}
    )
    with pytest.raises(NativeToolError):
        ports.validate_analyst_sql('SELECT C_1 FROM "d".S.V', "D.S.V", {"C_1"})
    with pytest.raises(NativeToolError):
        ports.validate_analyst_sql('SELECT "c_1" FROM D.S.V', "D.S.V", {"C_1"})
