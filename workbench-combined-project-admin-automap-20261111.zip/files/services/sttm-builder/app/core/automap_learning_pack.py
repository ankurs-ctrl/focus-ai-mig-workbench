"""Batched, publication-aware FIR retrieval with deterministic scope and CRM tiers."""
from copy import deepcopy
import hashlib
import json
from app.core.automap_json import load_json
from app.core.automap_policy import negative_evidence
from app.core.mapping_contracts import column_identity


def select_learning_pack(records, *, project_id, linked_projects=(), crm=None, source_columns=(), limit=4):
    current = {column_identity(str(column)) for column in source_columns}
    linked = {str(value) for value in linked_projects}
    ranked = []
    for record in records:
        pattern = deepcopy(record.get('pattern') or record)
        if pattern.get('superseded_by'):
            continue
        profile = pattern.get('source_system_profile') or {}
        source_crm = str(pattern.get('source_system_key') or profile.get('vendor_family') or '').upper()
        owner = str(pattern.get('project_id') or '')
        tier = (4 if pattern.get('legacy_guidance') else
                1 if owner == str(project_id) else 2 if owner in linked else 3 if crm and source_crm == str(crm).upper() else 4)
        recipe = pattern.get('mapping_recipe') or {}
        sources = recipe.get('source_dependencies') or recipe.get('source_columns') or []
        matches = [column for column in sources if column_identity(str(column)) in current]
        # Project tier ranks relevant knowledge; current bindings decide draft reuse.
        project_literal = recipe.get('has_project_specific_literal') and owner != str(project_id)
        applicable = not pattern.get('legacy_guidance') and not project_literal and len(matches) == len(sources)
        if project_literal:
            # Retain the recipe's intent/kind without offering another firm's
            # identifier as executable SQL or a constant for this project.
            recipe = {**recipe, 'expression': None, 'constant_value': None,
                      'requires_current_project_value': True}
            pattern['mapping_recipe'] = recipe
        provenance = pattern.get('provenance') or {}
        mandatory = negative_evidence(pattern) or (owner == str(project_id) and provenance.get('evidence_class') == 'explicit_user_correction')
        pattern.update(tier=f'T{tier}', applicable=applicable, matching_columns=matches,
                       guidance_only=not applicable, source_system_key=source_crm, mandatory=mandatory,
                       required_joins=deepcopy(pattern.get('relationship_dependencies') or []),
                       required_ctes=deepcopy(pattern.get('derived_dependencies') or []))
        from app.core.mapping_sql import MappingSqlService
        pattern['placeholders'] = sorted(MappingSqlService._placeholders_in_sql(recipe.get('expression') or ''))
        identity = {'recipe': recipe, 'joins': pattern.get('relationship_dependencies'),
                    'ctes': pattern.get('derived_dependencies'), 'population': pattern.get('query_shaping_dependencies'),
                    'project': owner if recipe.get('has_project_specific_literal') else None}
        pattern['expression_hash'] = hashlib.sha256(json.dumps(identity, sort_keys=True, default=str).encode()).hexdigest()
        pattern['record_id'] = 'fir:' + str(pattern.get('pattern_id'))
        ranked.append(pattern)
    def rank(item):
        # ISO publication timestamps sort lexically; query already filters the latest version.
        return (item['tier'], not item['applicable'],)
    ranked.sort(key=lambda item: str(item.get('published_at') or (item.get('provenance') or {}).get('published_at') or ''), reverse=True)
    ranked.sort(key=rank)
    mandatory = [item for item in ranked if item['mandatory']]
    unique = []
    seen = set()
    for item in ranked:
        if not item['mandatory'] and item['expression_hash'] not in seen:
            unique.append(item)
            seen.add(item['expression_hash'])
    selected = unique[:2]
    selected_ids = {item['pattern_id'] for item in selected}
    supported = sorted(unique[2:], key=lambda item: (-int(item.get('support_count') or 0), item['tier'], item['pattern_id']))
    selected.extend(item for item in supported if item['pattern_id'] not in selected_ids)
    return [*mandatory, *selected[:limit]]


class AutoMapLearningPack:
    def __init__(self, session, settings):
        self.session, self.settings = session, settings
        self.counts = {}

    def retrieve(self, *, targets, target_table, logical_target_key=None, project_id=None,
                 linked_projects=(), crm=None, source_columns=(), excluded_pattern_ids=()):
        if not targets:
            return {}
        q = self.settings.qualify_table_name
        patterns = self.settings.qualify_metadata_object_name('TBL_FIR_TARGET_MAPPING_PATTERNS')
        excluded = sorted({str(value).removeprefix('fir:') for value in excluded_pattern_ids if value})
        exclusion_sql = ("AND (p.PATTERN_ID NOT IN (" + ','.join('?' for _ in excluded) + ") OR "
            "p.PATTERN_PAYLOAD:provenance:evidence_class::STRING = 'explicit_user_correction' AND TO_VARCHAR(p.PROJECT_ID) = ?)"
            if excluded else '')
        # Bound values only. Latest published ledger rows, never mutable drafts.
        rows = self.session.sql(f'''
            SELECT p.PATTERN_PAYLOAD, p.SUPPORT_COUNT, v.PUBLISHED_DATETIME AS PUBLISHED_AT,
                   p.TARGET_COLUMN, project.PROJECT_NAME, v.VERSION_NUMBER,
                   (v.VERSION_ID IS NULL AND COALESCE(p.PATTERN_PAYLOAD:provenance:evidence_class::STRING, '') <> 'explicit_user_correction') AS LEGACY_GUIDANCE,
                   COALESCE(NULLIF(p.PATTERN_PAYLOAD:source_system_profile:vendor_family::STRING, ''),
                            project.PROJECT_METADATA:source_system_key::STRING) AS SOURCE_SYSTEM_KEY
            FROM {patterns} p
            LEFT JOIN {q('TBL_STTM')} s ON TO_VARCHAR(s.STTM_ID) = TO_VARCHAR(p.STTM_ID)
            LEFT JOIN {q('TBL_PROJECTS')} project ON TO_VARCHAR(project.PROJECT_ID) = TO_VARCHAR(p.PROJECT_ID)
            LEFT JOIN {q('TBL_STTM_VERSIONS')} v
              ON v.STTM_ID = s.STTM_ID AND v.VERSION_NUMBER = s.CURRENT_VERSION
             AND TO_VARCHAR(v.VERSION_ID) = p.PATTERN_PAYLOAD:provenance:publication_version_id::STRING
            WHERE p.STATUS = 'active' AND p.SUPERSEDED_BY IS NULL
              AND (p.VALIDATION_STATUS = 'published' AND v.VERSION_ID IS NOT NULL
                   OR p.VALIDATION_STATUS IN ('published', 'validated', 'accepted')
                      AND NULLIF(p.PATTERN_PAYLOAD:provenance:publication_version_id::STRING, '') IS NULL
                      AND COALESCE(p.CONTRADICTION_COUNT, 0) = 0
                      AND COALESCE(p.PATTERN_PAYLOAD:provenance:evidence_class::STRING, '') NOT IN ('unvalidated_authored_sql', 'unvalidated_authored_mapping_workbook')
                   OR p.PATTERN_PAYLOAD:provenance:evidence_class::STRING = 'explicit_user_correction'
                      AND TO_VARCHAR(p.PROJECT_ID) = ?)
              AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE
              AND COALESCE(project.RUNTIME_SUPPRESSED, FALSE) = FALSE
              AND UPPER(COALESCE(project.STATUS, 'ACTIVE')) <> 'ARCHIVED'
              AND (UPPER(p.TARGET_TABLE) = UPPER(?)
                   OR UPPER(p.PATTERN_PAYLOAD:target_contract:logical_target_key::STRING) = UPPER(NULLIF(?, '')))
              AND UPPER(p.TARGET_COLUMN) IN ({','.join('?' for _ in targets)})
              {exclusion_sql}
            QUALIFY ROW_NUMBER() OVER (
                PARTITION BY p.STTM_ID, p.TARGET_TABLE, p.TARGET_COLUMN,
                    COALESCE(p.PATTERN_PAYLOAD:provenance:evidence_class::STRING, '') = 'explicit_user_correction'
                ORDER BY v.PUBLISHED_DATETIME DESC NULLS LAST, p.UPDATED_AT DESC, p.PATTERN_ID) = 1
            ORDER BY PUBLISHED_AT DESC NULLS LAST, p.PATTERN_ID
        ''', params=[str(project_id or ''), target_table, logical_target_key or '', *[str(t).upper() for t in targets],
                     *excluded, *([str(project_id or '')] if excluded else [])]).collect()
        grouped = {str(target).upper(): [] for target in targets}
        for row in rows:
            row = row.as_dict() if hasattr(row, 'as_dict') else dict(row)
            pattern = row['PATTERN_PAYLOAD']
            pattern = load_json(pattern) if isinstance(pattern, str) else deepcopy(pattern)
            pattern.update(legacy_guidance=bool(row.get('LEGACY_GUIDANCE')), support_count=row.get('SUPPORT_COUNT') or 0, published_at=str(row.get('PUBLISHED_AT') or ''),
                           project_name=row.get('PROJECT_NAME'), publication_version=row.get('VERSION_NUMBER'),
                           source_system_key=row.get('SOURCE_SYSTEM_KEY') or (pattern.get('source_system_profile') or {}).get('vendor_family'))
            grouped.setdefault(str(row['TARGET_COLUMN']).upper(), []).append(pattern)
        self.counts = {target: len(records) for target, records in grouped.items()}
        return {target: select_learning_pack(records, project_id=project_id, linked_projects=linked_projects,
                                            crm=crm, source_columns=source_columns) for target, records in grouped.items()}
