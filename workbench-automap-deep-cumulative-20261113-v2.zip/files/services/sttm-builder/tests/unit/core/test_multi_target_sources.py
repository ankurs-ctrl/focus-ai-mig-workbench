"""Multi-target source selection without precedents and per-target join settlement."""
import json
from types import SimpleNamespace
from typing import Any

from app.agent_runs.models import ToolResult
from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
from app.agent_tools import join_research, source_scout
from app.agent_tools.capability_registry import CapabilityRegistry

from tests.unit.core.test_deep_multi_target import _MultiTargetWorkbench, _registry

DRIVER = "DB.SRC.CONTACTS"


def _join(left: str, right: str, column: str) -> dict[str, Any]:
    return {"left_table": left, "right_table": right, "conditions": [{"left_column": column, "right_column": "ID"}]}


class _FakeSession:
    def __init__(self, response: dict[str, Any] | Exception) -> None:
        self.response = response
        self.calls: list[list[Any]] = []

    def sql(self, _text: str, params: list[Any] | None = None):
        self.calls.append(list(params or []))
        response = self.response

        class _Query:
            def collect(self, statement_params=None):
                if isinstance(response, Exception):
                    raise response
                return [[json.dumps(response)]]
        return _Query()


SETTINGS = SimpleNamespace(migration_agent_model_medium="model-m", migration_agent_source_scout_min_confidence=0.6,
                           migration_agent_source_scout_max_sources=4, migration_agent_source_scout_timeout_seconds=10)
INVENTORY = {"DB.SRC.NOTES": [("ID", "NUMBER"), ("BODY", "TEXT")],
             "DB.SRC.NOTE_ASSOCIATIONS": [("NOTE_ID", "NUMBER"), ("NOTEABLE_ID", "NUMBER")],
             DRIVER: [("ID", "NUMBER")]}


def test_scout_keeps_only_tables_that_exist_and_puts_the_driver_first() -> None:
    session = _FakeSession({"driving_source": "notes", "confidence": 0.82, "rationale": "one note per row",
                            "supporting_sources": ["NOTE_ASSOCIATIONS", "INVENTED_TABLE", "DB.SRC.CONTACTS", "NOTES"]})
    result = source_scout.scout_sources(session, SETTINGS, target="DB.TGT.NOTES",
                                        target_columns=[("DESCRIPTION__C", "TEXT")], inventory=INVENTORY)

    assert result.usable
    assert result.sources == ["DB.SRC.NOTES", "DB.SRC.NOTE_ASSOCIATIONS", DRIVER]
    assert result.rejected_names == ["INVENTED_TABLE"]
    # The inventory and target columns are in the prompt, as data.
    assert "NOTE_ASSOCIATIONS: NOTE_ID, NOTEABLE_ID" in session.calls[0][1]


def test_scout_reports_instead_of_guessing() -> None:
    low = source_scout.scout_sources(_FakeSession({"driving_source": "NOTES", "supporting_sources": [], "confidence": 0.3}),
                                     SETTINGS, target="DB.TGT.NOTES", target_columns=[], inventory=INVENTORY)
    assert low.reason == "low_confidence" and not low.usable
    missing = source_scout.scout_sources(_FakeSession({"driving_source": "NOPE", "supporting_sources": [], "confidence": 0.9}),
                                         SETTINGS, target="DB.TGT.NOTES", target_columns=[], inventory=INVENTORY)
    assert missing.reason == "no_driving_source" and missing.rejected_names == ["NOPE"]
    failed = source_scout.scout_sources(_FakeSession(TimeoutError()), SETTINGS, target="DB.TGT.NOTES",
                                        target_columns=[], inventory=INVENTORY)
    assert failed.reason.startswith("model_unavailable") and failed.sources == []
    unconfigured = source_scout.scout_sources(_FakeSession({}), SimpleNamespace(), target="DB.TGT.NOTES",
                                              target_columns=[], inventory=INVENTORY)
    assert unconfigured.reason == "no_model_configured"


class _ScoutWorkbench(_MultiTargetWorkbench):
    """NOTES has no precedent; its sources can only come from the scout."""

    def __init__(self) -> None:
        self.prepared: list[tuple[str, list[str]]] = []
        self.scouted: list[dict[str, Any]] = []

    def prepare_migration_evidence(self, _context, *, source_tables, target_table, precedent_project_ids) -> ToolResult:
        self.prepared.append((target_table, list(source_tables)))
        if target_table == "DB.TGT.NOTES" and source_tables:
            self.driving = {**self.driving, "DB.TGT.NOTES": source_tables[0]}
        return super().prepare_migration_evidence(_context, source_tables=source_tables, target_table=target_table,
                                                  precedent_project_ids=precedent_project_ids)

    def scout_target_sources(self, target, contract, *, schemas, requested_text="", known_designs=None):
        self.scouted.append({"target": target, "schemas": schemas, "designs": known_designs, "contract": contract})
        if target == "DB.TGT.NOTES":
            return {"sources": ["DB.SRC.NOTES", "DB.SRC.NOTE_ASSOCIATIONS"], "reason": "", "confidence": 0.8,
                    "driving_source": "DB.SRC.NOTES"}
        return {"sources": [], "reason": "no_driving_source"}


def test_a_target_without_a_precedent_is_prepared_from_scouted_sources() -> None:
    workbench = _ScoutWorkbench()
    registry = _registry(workbench)
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")

    result = tool.invoke({"target_tables": ["DB.TGT.HOUSEHOLD", "DB.TGT.NOTES"],
                          "sources_by_target": {"HOUSEHOLD": [DRIVER]}})

    notes = next(item for item in result["data"]["per_target"] if item["target_table"] == "DB.TGT.NOTES")
    assert notes["source_selection"] == "scouted" and notes["status"] == "ready", notes
    assert ("DB.TGT.NOTES", ["DB.SRC.NOTES", "DB.SRC.NOTE_ASSOCIATIONS"]) in workbench.prepared
    # Only the target without sources is scouted, over the schema the other target resolved to.
    assert [item["target"] for item in workbench.scouted] == ["DB.TGT.NOTES"]
    assert workbench.scouted[0]["schemas"] == ["DB.SRC"]
    assert workbench.scouted[0]["designs"] == [{"target": "DB.TGT.HOUSEHOLD", "driving_source": DRIVER}]
    assert {"DB.SRC.NOTES", "DB.SRC.NOTE_ASSOCIATIONS"} <= set(registry._catalog_candidates)


def test_no_ready_target_reports_every_target_not_the_last_one() -> None:
    class _Nothing(_ScoutWorkbench):
        driving: dict[str, str] = {}

        def scout_target_sources(self, target, contract, **_kwargs):
            return {"sources": [], "reason": "no_driving_source"}

    registry = _registry(_Nothing())
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")
    tool.invoke({"target_tables": ["DB.TGT.CALLS", "DB.TGT.NOTES"]})

    review = registry.prepared_plan_review
    assert review["target_table"] == "" and len(review["multi_target_outcome"]["targets"]) == 2
    state = DeepAgentsRuntime._evidence_boundary_state(review, None)
    assert state["status"] == "NEEDS_REVIEW"
    assert "**CALLS**" in state["assistant_message"] and "**NOTES**" in state["assistant_message"]
    assert "source proposal: no_driving_source" in state["assistant_message"]
    assert len(state["review_items"]) == 2


class _JoinWorkbench:
    def __init__(self, remembered: dict[str, dict[str, Any]], policy: str = "exclude") -> None:
        self._settings = SimpleNamespace(migration_agent_multi_target_unjoined_policy=policy)
        self.remembered = remembered
        self.asked: list[list[str]] = []
        self.events: list[str] = []

    def inspect_table_contract(self, table):
        return ToolResult(status="succeeded", summary="ok", data={"columns": ["ID"]})

    def auto_apply_verified_joins(self) -> bool:
        return True

    def record_auto_resolved_join(self, _state, question, _option) -> None:
        self.events.append(f"auto:{question['target']}")

    def remembered_join_paths(self, _state, targets, plan_tables):
        self.asked.append(sorted(plan_tables))
        return {target: path for target, path in self.remembered.items()
                if target in targets and any(table in plan_tables for table in path["connects_to"])}

    def record_remembered_join(self, _state, target, _path) -> None:
        self.events.append(f"remembered:{target}")


def _settling_registry(workbench: Any, monkeypatch, questions: list[dict[str, Any]]):
    registry = CapabilityRegistry.__new__(CapabilityRegistry)
    registry._workbench = workbench
    registry._context_provider = lambda: {"run_id": "r1"}
    registry._prepared_plan_candidate = {"source_preparation": {
        "driving_source": DRIVER, "supporting_sources": [q["target"] for q in questions]}}
    traced: list[str] = []
    registry._trace = lambda _event, _status, summary, _data: traced.append(summary)
    applied: list[tuple[list[dict[str, Any]], list[str]]] = []
    registry.apply_reviewed_join_path = lambda joins, excluded=None: (
        applied.append((list(joins), list(excluded or []))) or {"status": "succeeded"})
    monkeypatch.setattr(join_research, "research_questions", lambda _prepared, _contracts: questions)
    return registry, applied, traced


def test_joins_are_settled_per_target_verified_then_remembered_then_left_out(monkeypatch) -> None:
    members, families, activities = "DB.SRC.MEMBERS", "DB.SRC.FAMILIES", "DB.SRC.ACTIVITIES"
    questions = [
        {"target": members, "driver": DRIVER, "options": [
            {"id": "p1", "recommended": True, "confidence": 0.97, "joins": [_join(members, DRIVER, "CONTACT_ID")]}]},
        {"target": families, "driver": DRIVER, "options": []},
        {"target": activities, "driver": DRIVER, "options": [
            {"id": "a", "recommended": False, "confidence": 0.5, "joins": [_join(activities, DRIVER, "OWNER_ID")]}]},
    ]
    # FAMILIES was confirmed earlier as joining MEMBERS: usable once MEMBERS is resolved.
    family_join = _join(members, families, "FAMILY_ID")
    workbench = _JoinWorkbench({families: {"joins": [family_join], "connects_to": [members]}})
    registry, applied, traced = _settling_registry(workbench, monkeypatch, questions)

    result = registry._settle_target_joins("DB.TGT.HOUSEHOLD", {"data": {}})

    assert result["status"] == "succeeded"
    joins, excluded = applied[0]
    assert joins == [_join(members, DRIVER, "CONTACT_ID"), family_join]
    assert excluded == [activities]
    assert workbench.events == [f"auto:{members}", f"remembered:{families}"]
    assert result["join_resolution"]["left_out"] == ["ACTIVITIES"]
    assert [item["decision"] for item in result["join_resolution"]["applied"]] == ["verified", "remembered"]
    assert traced and "Left ACTIVITIES out of HOUSEHOLD" in traced[0]


def test_ask_policy_keeps_an_unjoined_target_for_the_user(monkeypatch) -> None:
    activities = "DB.SRC.ACTIVITIES"
    questions = [{"target": activities, "driver": DRIVER, "options": []}]
    registry, applied, _traced = _settling_registry(_JoinWorkbench({}, policy="ask"), monkeypatch, questions)

    result = registry._settle_target_joins("DB.TGT.CALLS", {"data": {}})

    assert result["status"] == "needs_input" and applied == []
    assert result["join_resolution"]["left_out"] == ["ACTIVITIES"]


def test_workbench_scout_scans_the_named_schema_once_and_traces_the_proposal() -> None:
    import threading

    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    queries: list[str] = []
    answer = {"driving_source": "NOTES", "supporting_sources": ["NOTE_ASSOCIATIONS"], "confidence": 0.8}

    class _Session:
        def sql(self, text: str, params: list[Any] | None = None):
            queries.append(text)
            if "SCHEMATA" in text:
                rows = [{"SCHEMA_NAME": "SRC"}]
            elif "AI_COMPLETE" in text:
                rows = [[json.dumps(answer)]]
            else:
                rows = [{"TABLE_SCHEMA": "SRC", "TABLE_NAME": name, "COLUMN_NAME": "ID", "DATA_TYPE": "NUMBER"}
                        for name in ("NOTES", "NOTE_ASSOCIATIONS")]
            return SimpleNamespace(collect=lambda statement_params=None: rows)

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._session = _Session()
    handler._settings = SETTINGS
    handler._domain_lock = threading.RLock()
    events: list[tuple[str, str]] = []
    handler._emit = lambda event, status, summary, **_data: events.append((status, summary))
    handler._tool = lambda _operation: None
    handler._setting = lambda name, default: getattr(SETTINGS, name, default)

    first = handler.scout_target_sources("DB.TGT.NOTES", {"columns": ["BODY"]}, schemas=[],
                                         requested_text="sources from SRC")
    second = handler.scout_target_sources("DB.TGT.CALLS", {"columns": ["SUBJECT"]}, schemas=["DB.SRC"])

    assert first["sources"] == ["DB.SRC.NOTES", "DB.SRC.NOTE_ASSOCIATIONS"] and first["reason"] == ""
    assert first["schemas"] == ["DB.SRC"] and second["inventory_tables"] == 2
    assert sum("INFORMATION_SCHEMA.COLUMNS" in text for text in queries) == 1  # cached inventory
    assert events[0][0] == "succeeded" and "driving source NOTES" in events[0][1]


def test_a_reused_design_that_mostly_does_not_join_is_compared_with_a_fresh_proposal(monkeypatch) -> None:
    from app.agent_tools import capability_registry as module
    from tests.unit.core.test_deep_multi_target import _PrecedentWorkbench

    class _Workbench(_PrecedentWorkbench):
        def prepare_migration_evidence(self, _context, *, source_tables, target_table, precedent_project_ids):
            if source_tables:
                self.driving = {**self.driving, target_table: source_tables[0]}
            result = super().prepare_migration_evidence(_context, source_tables=source_tables, target_table=target_table,
                                                        precedent_project_ids=precedent_project_ids)
            if source_tables and source_tables[0] == "DB.SRC.CONTACTS":
                result.data["plan_candidate"]["source_preparation"].update({
                    "supporting_sources": list(source_tables[1:]),
                    "unresolved_items": [f"Current relationship evidence has no join path to DB.SRC.CONTACTS: {name}"
                                         for name in source_tables[1:]]})
            return result

        def scout_target_sources(self, target, contract, *, schemas, requested_text="", known_designs=None):
            self.scout_designs = known_designs
            return {"sources": ["DB.SRC.HOUSEHOLDS", "DB.SRC.MEMBERS"], "reason": "", "confidence": 0.8}

    workbench = _Workbench()
    registry = _registry(workbench)
    monkeypatch.setattr(module, "only_join_paths_open", lambda _review: True)

    def settle(target, prepared):
        source = dict(prepared["data"]["plan_candidate"]["source_preparation"])
        tables = [value for value in source.get("supporting_sources") or []]
        if workbench.prepared[-1][1][0] == "DB.SRC.CONTACTS":  # the reused design: nothing joins
            left_out, kept = ["FAMILIES", "A", "B"], []
        else:
            left_out, kept = [], ["DB.SRC.MEMBERS"]
        registry._prepared_plan_candidate = {**prepared["data"]["plan_candidate"],
                                             "source_preparation": {**source, "supporting_sources": kept or tables[:0]}}
        return {"status": "succeeded", "join_resolution": {"applied": [], "left_out": left_out, "policy": "exclude"}}

    registry._settle_target_joins = settle
    tool = next(item for item in registry.tools() if item.name == "prepare_multi_target_evidence")
    result = tool.invoke({"target_tables": ["DB.TGT.HOUSEHOLD", "DB.TGT.CALLS"],
                          "sources_by_target": {"CALLS": ["DB.SRC.ACTIVITIES"]}})

    household = next(item for item in result["data"]["per_target"] if item["target_table"] == "DB.TGT.HOUSEHOLD")
    assert household["source_selection"] == "scouted_after_unjoinable_design", household
    assert household["selected_sources"] == ["DB.SRC.HOUSEHOLDS", "DB.SRC.MEMBERS"]
    # The rejected design is not offered to the scout as a known good one.
    assert all(item["target"] != "DB.TGT.HOUSEHOLD" for item in workbench.scout_designs)
    # The spec is validated against the evidence of the design that was kept.
    staged = registry.validated_supervisor_plan
    household_spec = next(spec for spec in staged["mapping_specs"] if spec["target_table"] == "DB.TGT.HOUSEHOLD")
    assert household_spec["source_preparation"]["driving_source"] == "DB.SRC.HOUSEHOLDS"
    assert registry._prepared_plan_candidates["DB.TGT.HOUSEHOLD"]["source_preparation"]["driving_source"] == \
        "DB.SRC.HOUSEHOLDS"


def test_prepare_sources_lets_clean_mappings_through_a_batch_with_one_blocked_finding() -> None:
    from threading import RLock
    from app.agent_runs.contracts import MigrationPlanArtifactV1
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = RLock()

    def prepare_one(state, spec):
        key = state["manifest"][0]["mapping_key"]
        diagnostics = {"unresolved": ["High-fanout join on MAPPER_ACR_MASTER"]} if key == "biz_accounts" else {}
        return {"mapping_context_package": {"context_hash": key}, "source_preparation_result": diagnostics}

    handler._prepare_mapping_sources = prepare_one
    manifest = [{"mapping_key": "household", "target_table": "DB.T.HOUSEHOLD"},
                {"mapping_key": "biz_accounts", "target_table": "DB.T.BIZ_ACCOUNTS"}]
    plan = MigrationPlanArtifactV1(plan_id="p1", run_id="r1", thread_id="t1", original_request="x",
        normalized_intent="x", context_hash="h", source_preparation={"target_table": "DB.T.HOUSEHOLD"},
        auto_map={}, mapping_specs=[{"mapping_key": key, "target_table": item["target_table"],
                                     "source_preparation": {"target_table": item["target_table"]}}
                                    for key, item in zip(("household", "biz_accounts"), manifest)])
    result = handler.prepare_sources({"migration_plan": plan.model_dump(mode="json"),
                                      "approved_plan_hash": plan.plan_hash, "manifest": manifest})

    preparation = result["source_preparation_result"]
    assert preparation["status"] == "succeeded"  # not all mappings are blocked
    assert preparation["blocked_mapping_keys"] == ["biz_accounts"]
    assert set(result["mapping_context_packages"]) == {"household", "biz_accounts"}


def test_prepare_sources_blocks_the_run_only_when_every_mapping_is_unresolved() -> None:
    from threading import RLock
    from app.agent_runs.contracts import MigrationPlanArtifactV1
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = WorkbenchWorkflowHandlers.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = RLock()
    handler._prepare_mapping_sources = lambda state, spec: {
        "mapping_context_package": {}, "source_preparation_result": {"unresolved": ["No verified driving source"]}}
    manifest = [{"mapping_key": "agreements", "target_table": "DB.T.AGREEMENTS"}]
    plan = MigrationPlanArtifactV1(plan_id="p1", run_id="r1", thread_id="t1", original_request="x",
        normalized_intent="x", context_hash="h", source_preparation={"target_table": "DB.T.AGREEMENTS"}, auto_map={})

    result = handler.prepare_sources({"migration_plan": plan.model_dump(mode="json"),
                                      "approved_plan_hash": plan.plan_hash, "manifest": manifest})

    assert result["source_preparation_result"]["status"] == "needs_input"
    assert result["source_preparation_result"]["blocked_mapping_keys"] == []


def test_mapping_step_status_translates_ready_for_review_and_survives_unknown_values() -> None:
    from app.agent_runs.models import StepStatus
    from app.agent_runs.worker import _mapping_step_status

    assert _mapping_step_status("READY_FOR_REVIEW") == StepStatus.SUCCEEDED
    assert _mapping_step_status("NEEDS_REVIEW") == StepStatus.NEEDS_REVIEW
    assert _mapping_step_status("PENDING") == StepStatus.PENDING
    # An unrecognized status must not crash finalization after drafts were saved.
    assert _mapping_step_status("SOMETHING_NEW") == StepStatus.NEEDS_REVIEW


def test_schema_inventory_and_named_schemas_use_bound_parameters() -> None:
    issued: list[tuple[str, list[Any]]] = []

    def sql(text: str, params: list[Any] | None = None):
        issued.append((text, list(params or [])))
        rows = ([{"SCHEMA_NAME": "SCH_TMD_SOURCE"}, {"SCHEMA_NAME": "SCH_OTHER"}] if "SCHEMATA" in text else
                [{"TABLE_SCHEMA": "SCH_TMD_SOURCE", "TABLE_NAME": "NOTES", "COLUMN_NAME": "ID", "DATA_TYPE": "NUMBER"},
                 {"TABLE_SCHEMA": "SCH_TMD_SOURCE", "TABLE_NAME": "NOTES", "COLUMN_NAME": "BODY", "DATA_TYPE": "TEXT"}])
        return SimpleNamespace(collect=lambda: rows)

    assert source_scout.schemas_named_in_text(sql, ["DB"], "use sources from SCH_TMD_SOURCE please") == ["DB.SCH_TMD_SOURCE"]
    inventory = source_scout.schema_inventory(sql, ["DB.SCH_TMD_SOURCE", "bad name.x"], max_tables=10)
    assert inventory == {"DB.SCH_TMD_SOURCE.NOTES": [("ID", "NUMBER"), ("BODY", "TEXT")]}
    assert issued[-1][1] == ["SCH_TMD_SOURCE"]
