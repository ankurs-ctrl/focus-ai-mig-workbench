"""Versioned native Auto-map identities, frozen evidence and compact seed packets.

No model calls, SQL execution, mutable global resources or authorization from model
parameters. All originals remain in the immutable job snapshot.
"""

from copy import deepcopy
import hashlib
import json
import re

VERSION = "automap_native_v1"
TOOLS = (
    "SearchSources",
    "ReadEvidence",
    "InspectRelationships",
    "SearchPrecedents",
    "AskPreparedAnalyst",
    "ValidateProposal",
    "SubmitProposals",
)


def encoded(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def digest(value):
    return hashlib.sha256(encoded(value).encode()).hexdigest()


def identifier_key(name):
    from sqlglot import exp, parse_one

    node = parse_one(name, read="snowflake", into=exp.Column)
    if not isinstance(node, exp.Column) or len(node.parts) != 1 or node.is_star:
        raise ValueError("Expected one exact target identifier")
    part = node.parts[0]
    return part.name if part.args.get("quoted") else part.name.upper()


def target_id(table, name):
    from sqlglot import exp, parse_one

    relation = parse_one(table, read="snowflake", into=exp.Table)
    parts = [
        part.name if part.args.get("quoted") else part.name.upper()
        for part in relation.parts
    ]
    return "tgt_" + digest([parts, identifier_key(name)])[:32]


def enabled(settings, project_id):
    return getattr(settings, "automap_native_tools_v1", False) is True and str(
        project_id
    ) in set(str(getattr(settings, "automap_native_project_ids", "")).split(","))


def initial_state():
    return {
        "version": VERSION,
        "actions": {},
        "reads": {},
        "candidates": {},
        "proposals": {},
        "deficits": {},
        "trace": [],
        "tool_calls": 0,
        "delivered_bytes": 0,
        "revision": 0,
        "canonical_records": {},
        "dependencies": {},
        "verified_notes": {},
        "total_delivered_bytes": 0,
        "window": 0,
        "window_calls": 0,
        "dispatcher": "new",
    }


def frozen_request(req):
    raw = req.model_dump(mode="json", exclude_none=True)
    raw["meta"] = {
        key: value
        for key, value in raw.get("meta", {}).items()
        if not key.startswith("_") and key not in {"guardrails"}
    }
    return raw


def build_snapshot(
    req, *, validated_derived, max_record_bytes=16000000, strict_contracts=True
):
    from app.core.automap_retrieval import AutoMapContext
    from app.core.automap_scan_context import prepare_scan_context
    from app.core.automap_shards import MessageBudget
    from app.core.automap_policy import semantic_projection

    raw = frozen_request(req)
    if strict_contracts:
        derived = {
            node.relation_id
            for node in (
                req.context.relation_graph.nodes if req.context.relation_graph else []
            )
            if node.kind.value in {"DERIVED_SOURCE", "CTE"}
        }
        if not derived <= set(validated_derived):
            raise ValueError("Derived outputs require current server validation proofs")
    store = AutoMapContext(raw)
    manifest = store.manifest()
    prepared = prepare_scan_context(
        store,
        owner_id="native-frozen-evidence",
        budget=MessageBudget(max_record_bytes, max_record_bytes),
    )
    records = {
        record.record_id: record._payload()
        for record in (*prepared.global_records, *prepared.records)
    }
    for identity, body in store.historical_dependencies.items():
        owner, category, ids = store.historical_dependency_owners[identity]
        records[identity] = {
            "record_id": identity,
            "kind": "historical_dependency",
            "body": {
                "target_id": owner,
                "category": category,
                "canonical_ids": sorted(ids),
                "evidence": deepcopy(body),
            },
        }
    sources = {}
    for record in prepared.records:
        body = record.body
        if record.kind != "source_column" or body.get("eligible") is not True:
            continue
        binding = body.get("binding")
        if not isinstance(binding, dict):
            raise ValueError("Selectable source has no binding")
        identity = "src_" + digest([binding["relation_id"], body["column"]])[:32]
        sources[identity] = {
            "binding_id": identity,
            "source_ref": binding["sql_qualifier"] + "." + body["column"],
            "relation_id": binding["relation_id"],
            "relation": body["relation"],
            "column": body["column"],
            "data_type": body.get("data_type"),
            "evidence_id": record.record_id,
            "owner_id": body.get("owner_ref"),
        }
    # A graph index does not repeat 600 parent output columns. Exact originals
    # remain archived. Each selected node/edge/constraint has an exact read ID.
    graph_records = {}
    graph = raw.get("context", {}).get("relation_graph") or {}
    for node in graph.get("nodes", []):
        identity = "node_" + digest(node)
        records[identity] = {
            "record_id": identity,
            "kind": "relation_contract",
            "body": {
                key: deepcopy(value)
                for key, value in node.items()
                if key not in {"output_columns"}
            },
        }
        graph_records[node["relation_id"]] = identity
    edge_records = []
    for edge in graph.get("edges", []):
        identity = "edge_" + digest(edge)
        records[identity] = {
            "record_id": identity,
            "kind": "relationship",
            "body": deepcopy(edge),
        }
        edge_records.append(identity)
    for identity, record in list(records.items()):
        if record["kind"] == "source_graph":
            record["body"] = {
                "relation_contracts": graph_records,
                "relationship_ids": edge_records,
                "value_bindings": deepcopy(graph.get("value_bindings", [])),
                "instruction": "Exact node/edge records retain SQL and provenance; no hidden parent output is selectable.",
            }
    targets = {}
    for attribute in req.data.attributes:
        identity = target_id(
            attribute.target_table.qualified_name, attribute.target_attribute
        )
        if identity in targets:
            raise ValueError("Ambiguous canonical target binding")
        supplied = req.meta.get("auto_map_target_bindings")
        if supplied is not None and (
            type(supplied) is not dict
            or supplied.get(attribute.target_attribute) != identity
        ):
            raise ValueError("Target binding ID differs from frozen selection")
        targets[identity] = {
            "binding_id": identity,
            "name": attribute.target_attribute,
            "attribute": attribute.model_dump(mode="json", exclude_none=True),
        }
    context = raw.get("context") or {}
    workspace = context.get("workspace_context") or {}
    target_keys = {identifier_key(target["name"]) for target in targets.values()}
    rows = []
    for row in workspace.get("mapping_rows") or []:
        name = row.get("target_column") or row.get("target_attribute")
        if name and identifier_key(name) in target_keys:
            rows.append(deepcopy(row))
    baseline_ids = []
    for row in rows:
        identity = "baseline_" + digest(row)
        records[identity] = {
            "record_id": identity,
            "kind": "existing_definition",
            "body": {
                "target_id": row.get("target_column") or row.get("target_attribute"),
                "definition": deepcopy(row),
            },
        }
        baseline_ids.append(identity)
    globals_ = [
        record.record_id
        for record in prepared.global_records
        if record.kind
        in {
            "mandatory_evidence",
            "source_graph",
            "target_table_semantics",
            "target",
            "request_data",
        }
    ]
    filters = workspace.get("filters") or {}
    constraints = {
        "driving_relation_id": workspace.get("driving_relation_id"),
        "source_filter_sql": filters.get("filter_sql")
        or workspace.get("source_filter_sql"),
        "source_group_by_sql": filters.get("group_by_sql")
        or workspace.get("source_group_by_sql"),
        "source_order_by_sql": filters.get("order_by_sql")
        or workspace.get("source_order_by_sql"),
        "source_query_modifiers": filters.get("query_modifiers")
        or workspace.get("source_query_modifiers")
        or graph.get("query_modifiers")
        or {},
    }
    constraints_id = "constraints_" + digest(
        {
            key: constraints.get(key)
            for key in (
                "source_filter_sql",
                "source_group_by_sql",
                "source_order_by_sql",
                "source_query_modifiers",
            )
        }
    )
    records[constraints_id] = {
        "record_id": constraints_id,
        "kind": "population_constraints",
        "body": {
            key: deepcopy(constraints.get(key))
            for key in (
                "source_filter_sql",
                "source_group_by_sql",
                "source_order_by_sql",
                "source_query_modifiers",
            )
        },
    }
    current = manifest.get("context") or {}
    guidance = {
        key: deepcopy(current[key])
        for key in (
            "mapping_intent",
            "project_context",
            "project_context_status",
            "current_mapping_policy",
        )
        if current.get(key) not in (None, {}, [], "")
    }
    if guidance:
        guidance_id = "guidance_" + digest(guidance)
        records[guidance_id] = {
            "record_id": guidance_id,
            "kind": "current_business_guidance",
            "body": guidance,
        }
        globals_.append(guidance_id)
    globals_.append(constraints_id)
    globals_.extend(baseline_ids)
    snapshot = {
        "version": VERSION,
        "request": raw,
        "sources": sources,
        "targets": targets,
        "records": records,
        "mandatory_evidence": globals_,
        "graph_records": graph_records,
        "edge_records": edge_records,
        "learning_ids": {
            key: sorted(
                set().union(
                    *(
                        evidence_identifiers(record["body"])
                        for record in records.values()
                        if record["kind"]
                        in {
                            "mandatory_evidence",
                            "learning_evidence",
                            "historical_dependency",
                        }
                        and identifier_key(
                            record["body"].get("target_id") or target["name"]
                        )
                        == identifier_key(target["name"])
                    )
                )
            )
            for key, target in targets.items()
        },
        "existing_rows": rows,
        "derived_contracts": validated_derived,
        "relation_graph": deepcopy(context.get("relation_graph") or {}),
        "learning": deepcopy(context.get("learning_context") or {}),
        "values": deepcopy(
            (context.get("relation_graph") or {}).get("value_bindings") or []
        ),
        "bundle": {
            "id": context.get("semantic_bundle_id"),
            "hash": context.get("semantic_bundle_hash"),
        },
        "constraints": constraints,
    }
    snapshot["snapshot_hash"] = digest(snapshot)
    if len(encoded(snapshot).encode()) > max_record_bytes:
        raise ValueError("Frozen native snapshot exceeds durable storage budget")
    return snapshot


def evidence_identifiers(value):
    ids = set()
    if isinstance(value, dict):
        for key, child in value.items():
            if (
                key
                in {
                    "pattern_id",
                    "learning_id",
                    "correction_id",
                    "inference_id",
                    "recommendation_id",
                    "mapping_id",
                    "knowledge_id",
                    "precedent_sttm_id",
                }
                and child
            ):
                ids.add(str(child))
            else:
                ids.update(evidence_identifiers(child))
    elif isinstance(value, list):
        for child in value:
            ids.update(evidence_identifiers(child))
    return ids


def words(value):
    return set(re.findall(r"[a-z0-9]+", str(value).lower()))


def seed_packet(snapshot, handle, *, max_chars, max_bytes, limit=8):
    """Compact index plus inline exact evidence only when small; never claim a read."""
    targets = []
    for identity, target in snapshot["targets"].items():
        tokens = words(encoded(target["attribute"]))
        ranked = sorted(
            snapshot["sources"].values(),
            key=lambda source: (
                -len(
                    tokens
                    & words(
                        source["source_ref"]
                        + " "
                        + encoded(
                            snapshot["records"][source["evidence_id"]]["body"].get(
                                "semantics", []
                            )
                        )
                    )
                ),
                source["binding_id"],
            ),
        )
        brief = {
            key: deepcopy(value) for key, value in target.items() if key != "attribute"
        }
        brief["target_data_type"] = target["attribute"].get("target_data_type")
        brief["meaning_preview"] = str(
            target["attribute"].get("target_description") or target["name"]
        )[:512]
        targets.append(
            {
                **brief,
                "candidate_binding_ids": [
                    item["binding_id"] for item in ranked[:limit]
                ],
            }
        )
    wanted = {
        identity for target in targets for identity in target["candidate_binding_ids"]
    }
    packet = {
        "protocol": VERSION,
        "job_handle": handle,
        "snapshot_hash": snapshot["snapshot_hash"],
        "targets": targets,
        "sources": [snapshot["sources"][key] for key in sorted(wanted)],
        "existing_definitions": deepcopy(snapshot["existing_rows"]),
        "mandatory_evidence_ids": snapshot["mandatory_evidence"],
        "learning_evidence_index": [
            {
                "evidence_id": identity,
                "kind": record["kind"],
                "target": record["body"].get("target_id"),
                "category": record["body"].get("category"),
            }
            for identity, record in snapshot["records"].items()
            if record["kind"] in {"mandatory_evidence", "learning_evidence"}
        ],
        "source_inventory_count": len(snapshot["sources"]),
        "instruction": "Investigate with registered tools. Search ranks candidates; it proves no binding. "
        "Read candidate and owner evidence and required target/population rules before proposing. "
        "Inventory entries are not read receipts. Only exposed source outputs may be selected. "
        "Submit completed targets immediately; retain alternatives and name missing business input. "
        "Do not walk every source page. Ask a specific unanswered question or stop. "
        "A SQL-valid source with contradictory business meaning cannot be a supported mapping. "
        "Existing definitions remain unchanged until human replacement acceptance. "
        "Finish with a completed AGT_SOURCE_MAPPING envelope; durable SubmitProposals checkpoints are authoritative.",
    }
    # Do not cut authored definitions or mandatory clauses to hit a soft limit.
    # Move exact bodies behind their existing records and immutable archive.
    while True:
        text = encoded(packet)
        messages = [
            {
                "role": "user",
                "status": "completed",
                "content": [{"type": "text", "text": text}],
            }
        ]
        wire = encoded(messages)
        if len(wire) <= max_chars and len(wire.encode()) <= max_bytes:
            return messages
        if limit > 1:
            return seed_packet(
                snapshot,
                handle,
                max_chars=max_chars,
                max_bytes=max_bytes,
                limit=max(1, limit // 2),
            )
        if "learning_evidence_index" in packet:
            del packet["learning_evidence_index"]
            packet["learning_index_archive"] = (
                'ReadEvidence(evidence_ids=["learning_index"])'
            )
            continue
        if "existing_definitions" in packet:
            packet["existing_definition_archive"] = (
                'ReadEvidence(kind="existing_definitions")'
            )
            del packet["existing_definitions"]
            continue
        raise ValueError("Native target identity/seed cannot fit; split target batch")
