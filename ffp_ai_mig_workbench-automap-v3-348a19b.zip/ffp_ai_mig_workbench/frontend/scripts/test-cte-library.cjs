const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const parse = name => {const source = fs.readFileSync(path.join(root, name), 'utf8');return ts.createSourceFile(name,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);};
function initializer(ast, name) {
  let result;
  function visit(node) {if (ts.isVariableDeclaration(node) && node.name.getText(ast) === name) result=node.initializer;ts.forEachChild(node,visit);}
  visit(ast);assert.ok(result, name);return result;
}
function evaluate(text, context) {
 const output=ts.transpileModule(`(${text})`, {compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}}).outputText;
 return vm.runInNewContext(output,context);
}
(async () => {
 const calls=[];
 const slice=parse('src/features/sttm/store/sttm-builder-slice.ts');
 const fetchNode=initializer(slice,'fetchDerivedSources');
 const fetch=fetchNode.arguments[1].getText(slice);
 const conditionText=fetchNode.arguments[2].properties.find(prop=>prop.name.getText(slice)==='condition').initializer.getText(slice);
 const condition=evaluate(conditionText,{isCacheFresh:()=>true});
 const cache={derivedSourcesFetchedAt:'fresh'};
 const cachedState={derivedSources:[{id:'project-only'}],cacheMetadata:cache};
 assert.equal(condition(undefined,{getState:()=>({sttmBuilder:cachedState})}),true,'old project-only cache must not hide the global library');
 cache.derivedSourcesScope='all';
 assert.equal(condition(undefined,{getState:()=>({sttmBuilder:cachedState})}),false,'a fresh global library may be reused');
 const load=evaluate(fetch,{dbService:{listDerivedSources:async (...args)=>{calls.push(args);return [
  {derived_source_id:'a',derived_source_name:'Revenue',project_id:'p1'},
  {derived_source_id:'b',derived_source_name:'Revenue',project_id:'p2'},
  {derived_source_id:'s',derived_source_name:'Shared',project_id:null},
 ];}},getErrorMessage:()=>'',Date});
 const result=await load(undefined,{rejectWithValue:error=>{throw error;}});
 assert.equal(calls[0].length,0,'load the global authorized endpoint, not the active project');
 assert.deepEqual(Array.from(result.derivedSources,x=>x.projectId),['p1','p2',null]);
 const panel=parse('src/features/sttm/source-target/source-target-db-selection.tsx');
 const filter=initializer(panel,'visibleDerivedSources').getText(panel);
 const sources=result.derivedSources.map(source=>({...source,isSelected:source.id==='a'}));
 const view=(project,search='')=>evaluate(filter,{derivedSources:sources,cteProject:project,derivedSearchText:search,matchesSearch:(text,query)=>text.toLowerCase().includes(query.toLowerCase())});
 assert.equal(view('all').length,3);
 assert.deepEqual(Array.from(view('p2'),x=>x.id),['b']);
 assert.deepEqual(Array.from(view('shared'),x=>x.id),['s']);
 assert.equal(view('p1','missing').length,0);
 assert.equal(view('all','Revenue').length,2,'identical CTE names from different projects remain distinct');
 assert.equal(sources[0].isSelected,true,'browsing never changes workspace selection');
 const closureText=fs.readFileSync(path.join(root,'src/features/sttm/shared/derived-source-closure.ts'),'utf8');
 const module={exports:{}};
 vm.runInNewContext(ts.transpileModule(closureText,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,{module,exports:module.exports});
 const workspace=module.exports.workspaceDerivedSources([
 {id:'parent',projectId:'p2',sourceName:'Parent',sqlText:'SELECT ID FROM DB.S.T',isSelected:false},
 {id:'child',projectId:'p2',sourceName:'Child',sqlText:'SELECT ID FROM Parent',parentDerivedSourceIds:['parent'],isSelected:true},
 ]);
 assert.deepEqual(Array.from(workspace,x=>x.id),['parent','child']);
 assert.equal(workspace[0].is_selected,false);
 assert.equal(workspace[1].parent_derived_source_ids[0],'parent');
 console.log('PASS global CTE load, project/shared/search filters, distinct identities, workspace selection, nested dependency closure');
})().catch(error=>{console.error(error);process.exitCode=1;});
