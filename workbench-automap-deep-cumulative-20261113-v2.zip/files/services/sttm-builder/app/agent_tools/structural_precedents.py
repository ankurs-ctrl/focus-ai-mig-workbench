"""Relationship learnings reused across structurally identical schemas.

A join confirmed for one schema (for example a previous client's copy of the
same CRM export) is evidence for the identically shaped tables of another
schema. Learnings are matched to current tables by column-set fingerprint
(``contract_reader.contract_fingerprint``), re-oriented when their stored
column order is reversed, and discarded when their columns do not exist on
the current tables. Every translated claim is still verified against the data
by the relationship graph before it can be applied.
"""
from __future__ import annotations

import ast
import json
import re
from typing import Any, Iterable

from app.agent_tools.contract_reader import contract_fingerprint, normalize_fqn

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
# Prior discount by how the learning was established. Legacy projector rows
# have no stage and include unreviewed joins, so they only suggest candidates.
TRUST_FACTORS: dict[str, float] = {"outcome": 1.0, "validated": 1.0, "published": 0.9, "evidence": 0.6}


def _table(value: Any) -> str:
    """FQN from a TableRef dict, its legacy ``str(dict)`` form, or an FQN string."""
    if isinstance(value, str) and value.strip().startswith("{"):
        try:
            value = ast.literal_eval(value.strip())
        except (ValueError, SyntaxError):
            return ""
    if isinstance(value, dict):
        value = value.get("qualified_name") or ".".join(
            str(value.get(key) or "") for key in ("database", "schema", "table"))
    fqn = normalize_fqn(value)
    return fqn if fqn.count(".") == 2 and all(fqn.split(".")) else ""


_TEXT_EQUALITY = re.compile(
    r'^\s*"?(?:([A-Za-z0-9_$]+)"?\.)?"?([A-Za-z_][A-Za-z0-9_$]*)"?\s*=\s*"?(?:([A-Za-z0-9_$]+)"?\.)?"?([A-Za-z_][A-Za-z0-9_$]*)"?\s*$')


def _text_conditions(text: str, left_table: str, right_table: str) -> list[dict[str, str]]:
    """``A.X = B.Y AND ...`` oriented by table qualifier (unqualified sides keep their order)."""
    left_leaf, right_leaf = left_table.rsplit(".", 1)[-1], right_table.rsplit(".", 1)[-1]
    conditions = []
    for clause in re.split(r"\s+AND\s+", text.strip(), flags=re.I):
        match = _TEXT_EQUALITY.fullmatch(clause)
        if not match:
            return []
        first_table, first, second_table, second = (value.upper() if value else "" for value in match.groups())
        if first_table == right_leaf and second_table in {left_leaf, ""} and first_table != left_leaf:
            first, second = second, first
        conditions.append({"left_column": first, "right_column": second})
    return conditions


def _conditions(value: Any, left_table: str = "", right_table: str = "") -> list[dict[str, str]]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            return _text_conditions(value, left_table, right_table)
    conditions = []
    for item in value if isinstance(value, list) else []:
        if not isinstance(item, dict) or str(item.get("operator") or "=") != "=":
            return []
        left = str(item.get("left_column") or item.get("fk_column") or "").upper()
        right = str(item.get("right_column") or item.get("pk_column") or "").upper()
        if not _IDENTIFIER.fullmatch(left) or not _IDENTIFIER.fullmatch(right):
            return []
        conditions.append({"left_column": left, "right_column": right})
    return conditions


def relationship_table(value: Any) -> str:
    """Public form of the table normalizer used when writing learnings."""
    return _table(value)


def relationship_conditions(value: Any, left_table: str = "", right_table: str = "") -> list[dict[str, str]]:
    """Upper-case equality conditions; empty when any condition is not a column equality."""
    return _conditions(value, _table(left_table) or str(left_table or ""), _table(right_table) or str(right_table or ""))


def parse_relationship_learning(row: dict[str, Any]) -> dict[str, Any] | None:
    """Normalize a ``table_relationship`` learning (any stored generation)."""
    attributes = row.get("attributes") if isinstance(row.get("attributes"), dict) else {}
    left, right = _table(attributes.get("left_table")), _table(attributes.get("right_table"))
    conditions = _conditions(attributes.get("conditions") or attributes.get("condition"), left, right)
    if not left or not right or left == right or not conditions:
        return None
    filters = [item for item in attributes.get("literal_filters") or []
               if isinstance(item, dict) and item.get("side") in {"left", "right"} and item.get("column")]
    alternative = str(attributes.get("normalized_lookup_alternative") or "").upper()
    return {
        "learning_id": str(row.get("learning_id") or ""),
        "confidence": float(row.get("confidence") or 0.0),
        "trust_stage": str(row.get("trust_stage") or "evidence"),
        "left_table": left, "right_table": right, "conditions": conditions,
        "literal_filters": filters,
        "normalized_lookup_alternative": alternative if _IDENTIFIER.fullmatch(alternative) else "",
        "user_confirmed": str(attributes.get("provenance") or "") == "user_confirmed_join",
        "left_fingerprint": str(attributes.get("left_fingerprint") or ""),
        "right_fingerprint": str(attributes.get("right_fingerprint") or ""),
    }


def tables_needing_contracts(learnings: Iterable[dict[str, Any]]) -> list[str]:
    """Original learning tables whose fingerprint must be read to translate them."""
    needed = set()
    for item in learnings:
        if not item["left_fingerprint"]:
            needed.add(item["left_table"])
        if not item["right_fingerprint"]:
            needed.add(item["right_table"])
    return sorted(needed)


def _counterparts(table: str, fingerprint: str, current: dict[str, str]) -> list[str]:
    """Current tables structurally identical to ``table`` (same table first)."""
    if table in current and (not fingerprint or current[table] == fingerprint):
        return [table]
    leaf = table.rsplit(".", 1)[-1]
    # Shape alone is not identity: small lookup tables (ID, NAME) share a
    # fingerprint, so only a same-named, identically shaped table qualifies.
    return [fqn for fqn, value in current.items()
            if fingerprint and value == fingerprint and fqn.rsplit(".", 1)[-1] == leaf]


def translate_learnings(
    learnings: Iterable[dict[str, Any]],
    current_contracts: dict[str, dict[str, Any]],
    original_contracts: dict[str, dict[str, Any]],
) -> list[tuple[str, dict[str, Any]]]:
    """``(evidence kind, relationship)`` claims on current tables.

    ``learning`` when the learning is about the current tables themselves,
    ``structural_precedent`` when it was recorded for identically shaped
    tables elsewhere. Claims whose columns do not exist on the current tables
    in either orientation are dropped.
    """
    current = {normalize_fqn(table): contract_fingerprint(contract) for table, contract in current_contracts.items()}
    columns = {normalize_fqn(table): {str(value).upper() for value in contract.get("columns") or []}
               for table, contract in current_contracts.items()}
    originals = {normalize_fqn(table): contract_fingerprint(contract) for table, contract in original_contracts.items()}
    claims: list[tuple[str, dict[str, Any]]] = []
    seen: set[str] = set()
    for item in learnings:
        left_fp = item["left_fingerprint"] or originals.get(item["left_table"], "")
        right_fp = item["right_fingerprint"] or originals.get(item["right_table"], "")
        for left in _counterparts(item["left_table"], left_fp, current):
            for right in _counterparts(item["right_table"], right_fp, current):
                if left == right:
                    continue
                conditions = item["conditions"]
                reversed_order = False
                if all(c["left_column"] in columns[left] and c["right_column"] in columns[right] for c in conditions):
                    oriented = conditions
                elif all(c["right_column"] in columns[left] and c["left_column"] in columns[right] for c in conditions):
                    # Stored with its columns reversed relative to its tables.
                    oriented = [{"left_column": c["right_column"], "right_column": c["left_column"]} for c in conditions]
                    reversed_order = True
                else:
                    continue
                if any(f["column"].upper() not in columns[left if f["side"] == "left" else right]
                       for f in item["literal_filters"]):
                    continue
                kind = "learning" if (left, right) == (item["left_table"], item["right_table"]) else "structural_precedent"
                # A code/alias lookup alternative lives on the lookup (right) table.
                alternative = item.get("normalized_lookup_alternative") or ""
                keep_alternative = bool(alternative) and not reversed_order and alternative in columns[right]
                relationship = {
                    "left_table": left, "right_table": right,
                    "conditions": [{**c, "operator": "="} for c in oriented],
                    "literal_filters": item["literal_filters"],
                    **({"normalized_lookup_alternative": alternative} if keep_alternative else {}),
                    "user_confirmed": bool(item.get("user_confirmed")),
                    "confidence": round(item["confidence"] * TRUST_FACTORS.get(item["trust_stage"], 0.6), 4),
                    "source": "RELATIONSHIP_LEARNING" if kind == "learning" else "STRUCTURAL_PRECEDENT",
                    "evidence_ids": [f"learning:{item['learning_id']}"] if item["learning_id"] else [],
                    "translated_from": [item["left_table"], item["right_table"]] if kind != "learning" else [],
                }
                identity = json.dumps([kind, left, right, relationship["conditions"], item["learning_id"]], sort_keys=True)
                if identity not in seen:
                    seen.add(identity)
                    claims.append((kind, relationship))
    return claims


def schema_counterparts(
    historical_tables: Iterable[str],
    same_named: dict[str, dict[str, str]],
    *,
    exclude_schemas: Iterable[str] = (),
    requested_text: str = "",
    selected_scope: Iterable[str] = (),
    limit: int = 5,
) -> list[dict[str, Any]]:
    """Other schemas holding a copy of the tables a historical mapping used.

    ``same_named`` is ``contract_reader.same_named_signatures`` output. A
    table counts as identical only when it has the same name and the same
    column signature as the historical table. A schema the request names (or
    the UI selected) is the current client's and ranks first; the rest are
    ranked by how many of the historical tables they reproduce exactly.
    """
    excluded = {normalize_fqn(value) for value in exclude_schemas}
    historical = [normalize_fqn(value) for value in dict.fromkeys(historical_tables) if str(value).count(".") == 2]
    schemas: dict[str, dict[str, Any]] = {}
    for table in historical:
        visible = same_named.get(table, {})
        original = visible.get(table)
        home = table.rsplit(".", 1)[0]
        for fqn, signature in visible.items():
            schema = fqn.rsplit(".", 1)[0]
            if schema == home or schema in excluded:
                continue
            entry = schemas.setdefault(schema, {"schema": schema, "identical": [], "different_columns": [], "missing": []})
            if original and signature == original:
                entry["identical"].append({"historical_table": table, "current_table": fqn})
            else:
                entry["different_columns"].append({"historical_table": table, "current_table": fqn})
    text = str(requested_text or "").upper()
    selected = {normalize_fqn(value).rsplit(".", 1)[0] if str(value).count(".") == 2 else normalize_fqn(value)
                for value in selected_scope}
    for entry in schemas.values():
        present = {item["historical_table"] for item in entry["identical"] + entry["different_columns"]}
        entry["missing"] = [table for table in historical if table not in present]
        entry["identical_count"] = len(entry["identical"])
        entry["historical_table_count"] = len(historical)
        leaf = entry["schema"].rsplit(".", 1)[-1]
        entry["named_in_request"] = (
            bool(re.search(rf"(?<![A-Z0-9_$]){re.escape(leaf)}(?![A-Z0-9_$])", text))
            or entry["schema"] in selected or leaf in selected
        )
    ranked = sorted(schemas.values(), key=lambda item: (
        not item["named_in_request"], -item["identical_count"], len(item["missing"]), item["schema"]))
    return [item for item in ranked if item["identical_count"]][:limit]


def learning_attributes(relationship: dict[str, Any], contracts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Structured, fingerprinted attributes for writing a relationship learning."""
    left, right = _table(relationship.get("left_table")), _table(relationship.get("right_table"))
    return {
        "left_table": left,
        "right_table": right,
        "conditions": _conditions(relationship.get("conditions")),
        "literal_filters": list(relationship.get("literal_filters") or []),
        **({"normalized_lookup_alternative": str(relationship["normalized_lookup_alternative"]).upper()}
           if relationship.get("normalized_lookup_alternative") else {}),
        "join_type": str(relationship.get("join_type") or "LEFT").upper(),
        "left_fingerprint": contract_fingerprint(contracts[left]) if left in contracts else "",
        "right_fingerprint": contract_fingerprint(contracts[right]) if right in contracts else "",
        "reusability": "structural",
    }


def retarget_cte_sql(sql: str, current_sources: Iterable[str], *,
                     cte_names: Iterable[str] = ()) -> tuple[str, dict[str, str]] | None:
    """A precedent CTE's SQL re-pointed at the current copies of its tables.

    A CTE written for another client's schema is reused with the same logic
    when every table it reads has exactly one same-named current source; the
    rewritten SQL and a historical-to-current table map are returned. Other
    CTEs of the same statement are left as they are. ``None`` means some
    table has no unambiguous current copy, so the CTE cannot be adapted.
    """
    import sqlglot
    from sqlglot import exp

    by_leaf: dict[str, list[str]] = {}
    for source in current_sources:
        fqn = normalize_fqn(source)
        if fqn.count(".") == 2:
            by_leaf.setdefault(fqn.rsplit(".", 1)[-1], []).append(fqn)
    local = {str(name).strip('"').upper() for name in cte_names}
    try:
        tree = sqlglot.parse_one(sql, read="snowflake")
    except Exception:
        return None
    local |= {str(cte.alias_or_name).upper() for cte in tree.find_all(exp.CTE)}
    mapping: dict[str, str] = {}
    for table in tree.find_all(exp.Table):
        name = str(table.name or "").upper()
        if not name or (not table.db and name in local):
            continue
        historical = ".".join(part for part in (table.catalog, table.db, table.name) if part).upper()
        matches = by_leaf.get(name, [])
        if len(matches) != 1:
            return None
        database, schema, leaf = matches[0].split(".")
        table.set("catalog", exp.to_identifier(database))
        table.set("db", exp.to_identifier(schema))
        table.set("this", exp.to_identifier(leaf))
        if historical != matches[0]:
            mapping[historical] = matches[0]
    return tree.sql(dialect="snowflake"), mapping
