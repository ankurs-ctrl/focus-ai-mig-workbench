"""Deterministic target ownership using known dependency overlap, not table names."""
from __future__ import annotations

import math

from sqlglot import exp, parse_one
from sqlglot.errors import SqlglotError

from app.core.automap_retrieval import reference_parts


def target_identifier_key(value: str) -> str:
    """Snowflake resolution key: unquoted folds, quoted spelling remains exact."""
    try:
        tree = parse_one(value, read="snowflake")
    except SqlglotError as exc:
        raise ValueError("Expected a target column identifier") from exc
    if not isinstance(tree, exp.Column) or not tree.parts:
        raise ValueError("Expected a target column identifier")
    leaf = tree.parts[-1]
    name = str(leaf.this)
    return name if leaf.args.get("quoted") else name.upper()


def dependency_batches(req, count):
    attributes = list(req.data.attributes or [])
    if not attributes:
        return [[]]
    count = min(count, len(attributes))
    known = {target_identifier_key(item.target_attribute): set() for item in attributes}
    learning = req.context.learning_context
    rows = [row for precedent in learning.mapping_precedents for row in precedent.mappings] if learning else []
    workspace = req.context.workspace_context
    if workspace:
        rows.extend(row.model_dump(mode="json") for row in workspace.mapping_rows)
    for row in rows:
        try:
            target = target_identifier_key(str(row.get("target_column") or row.get("target_attribute") or ""))
        except ValueError:
            continue
        if target not in known:
            continue
        for reference in [*(row.get("source_columns") or []), *(row.get("source_dependencies") or [])]:
            try:
                relation, _column = reference_parts(str(reference))
                if relation:
                    known[target].add(relation)
            except ValueError:
                continue  # Unknown dependencies are not invented for grouping.
    groups = [[] for _ in range(count)]
    dependencies = [set() for _ in range(count)]
    weights = [0] * count
    capacity = math.ceil(len(attributes) / count)
    ranked = sorted(enumerate(attributes), key=lambda pair: (
        -len(known[target_identifier_key(pair[1].target_attribute)]), -len(pair[1].model_dump_json()), pair[0]))
    for position, attribute in ranked:
        refs = known[target_identifier_key(attribute.target_attribute)]
        available = [index for index in range(count) if len(groups[index]) < capacity]
        index = min(available, key=lambda index: (
            -len(refs & dependencies[index]), len(groups[index]), weights[index], index))
        groups[index].append((position, attribute))
        dependencies[index].update(refs)
        weights[index] += len(attribute.model_dump_json())
    return [[attribute for _, attribute in sorted(group)] for group in groups if group]
