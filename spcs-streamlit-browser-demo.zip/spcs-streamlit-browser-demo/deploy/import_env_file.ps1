param(
    [Parameter(Mandatory = $true)][string]$EnvFile
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

# Loads KEY=VALUE pairs from a .env-style file into the current PowerShell process.
# This is the PowerShell equivalent of "source .env" for this demo bundle.
$cfg = Import-DemoEnv -Path $EnvFile
Set-EnvFromConfig -Config $cfg

Write-Host "Imported environment variables from $EnvFile into the current PowerShell session."
