from threading import Event
import pytest
from app.migration_workflow.scheduler import (Partition, PartitionScheduler, PartitionState, Dependency,
    ArtifactContract, dependency_ready, validate_graph, merge_column_partitions)
from app.migration_workflow.manifest import build_manifest


def test_generic_nine_mapping_scope_has_no_client_dependencies():
    targets = [f'ACCOUNT.TARGET.ENTITY_{i}' for i in range(9)]
    manifest = build_manifest('Migrate the requested domain', target_scope=targets)
    assert len(manifest) == 9
    assert all(not item['dependencies'] for item in manifest)
    assert [v['target_table'] for v in manifest] == targets


def test_newly_ready_work_starts_before_unrelated_slow_work_finishes():
    released = Event()
    def execute(p):
        if p.partition_id == 'slow':
            assert released.wait(2), 'Scheduler waited for an entire wave'
        elif p.partition_id == 'consumer':
            released.set()
        return {}
    partitions = [Partition(partition_id=k, mapping_key=k, waits_for=['fast'] if k=='consumer' else []) for k in ['slow','fast','consumer']]
    saved=[]
    result=PartitionScheduler(max_workers=2,persist=lambda p:saved.append((p.partition_id,p.state)),check_active=lambda:None).run(partitions,execute)
    assert all(p.state==PartitionState.COMPLETED for p in result)
    assert ('consumer',PartitionState.RUNNING) in saved


def edge(**kwargs):
    return Dependency(consumer_mapping='consumer',producer_mapping='producer',producer_output='lookup',evidence_id='e1',confidence=1,**kwargs)


def test_twenty_columns_run_while_four_wait_for_verified_crosswalk():
    independent_started=Event()
    dep=edge(consumer_columns=['D1','D2','D3','D4'],blocking_scope='column')
    work=[Partition(partition_id='p',mapping_key='producer'),
          Partition(partition_id='ind',mapping_key='consumer',columns=[f'C{i}' for i in range(20)]),
          Partition(partition_id='dep',mapping_key='consumer',columns=dep.consumer_columns,dependencies=[dep]),
          Partition(partition_id='compile',mapping_key='consumer',stage='compile',waits_for=['ind','dep'])]
    def execute(p):
        if p.partition_id=='p':
            assert independent_started.wait(2)
            return {'artifact_contracts':[ArtifactContract(artifact_id='lookup',producer_mapping='producer',revision=1,stage='mapped',evidence_ids=['e1'],verified=True).model_dump()]}
        if p.partition_id=='ind':independent_started.set()
        return {'mapping_rows':[{'target_column':c} for c in p.columns]}
    result=PartitionScheduler(max_workers=2,persist=lambda p:None,check_active=lambda:None).run(work,execute)
    assert all(p.state==PartitionState.COMPLETED for p in result)
    assert len(merge_column_partitions([p for p in result if p.mapping_key=='consumer']))==24


def test_cycles_rejected_before_execution():
    with pytest.raises(ValueError,match='cycle'):
        validate_graph([Partition(partition_id='a',mapping_key='a',waits_for=['b']),Partition(partition_id='b',mapping_key='b',waits_for=['a'])])


def test_load_time_and_stale_artifacts_do_not_satisfy_dependencies():
    output=ArtifactContract(artifact_id='lookup',producer_mapping='producer',revision=2,stage='mapped',evidence_ids=['e'],verified=True)
    assert not dependency_ready(edge(),{'lookup':output})
    assert not dependency_ready(edge(availability='load_time'),{'lookup':output.model_copy(update={'revision':1})})


def test_optional_unavailable_dependency_does_not_block():
    work=[Partition(partition_id='a',mapping_key='consumer',dependencies=[edge(required=False,availability='load_time')])]
    result=PartitionScheduler(max_workers=1,persist=lambda p:None,check_active=lambda:None).run(work,lambda p:{})
    assert result[0].state==PartitionState.COMPLETED


def test_completed_partition_is_not_replayed_after_reconnect():
    p=Partition(partition_id='a',mapping_key='a',state=PartitionState.COMPLETED,result={'mapping_rows':[]})
    PartitionScheduler(max_workers=1,persist=lambda p:None,check_active=lambda:None).run([p],lambda p:pytest.fail('Replayed completed partition'))


def test_merge_rejects_conflicting_column_decisions():
    a=Partition(partition_id='a',mapping_key='m',columns=['X'],state=PartitionState.COMPLETED,result={'mapping_rows':[{'target_column':'X','expression':'1'}]})
    b=a.model_copy(update={'partition_id':'b','result':{'mapping_rows':[{'target_column':'X','expression':'2'}]}})
    with pytest.raises(ValueError,match='Conflicting'):merge_column_partitions([a,b])


def test_domain_contract_emission_unblocks_only_explicit_draft_columns():
    from app.migration_workflow.artifacts import emit_artifact_contracts
    dependency=edge(producer_columns=['KEY'],consumer_columns=['PARENT_KEY'],blocking_scope='column')
    producer_result={'mapping_rows':[{'target_column':'KEY','source_columns':['DB.SRC.A.KEY'],
                                     'status':'draft','evidence_ids':['contract:source']} ]}
    emitted=emit_artifact_contracts(mapping_key='producer',project_id='project',revision=1,
        stage='mapped',result=producer_result,dependencies=[dependency])
    assert len(emitted)==1 and emitted[0]['payload']['target_values_available'] is False
    work=[Partition(partition_id='p',mapping_key='producer',columns=['KEY']),
          Partition(partition_id='c',mapping_key='consumer',columns=['PARENT_KEY'],dependencies=[dependency])]
    def execute(partition):
        if partition.mapping_key=='producer':return {**producer_result,'artifact_contracts':emitted}
        assert partition.dependency_contracts[0].payload['columns']==['KEY']
        return {}
    result=PartitionScheduler(max_workers=2,persist=lambda p:None,check_active=lambda:None).run(work,execute)
    assert all(p.state==PartitionState.COMPLETED for p in result)
    assert not emit_artifact_contracts(mapping_key='producer',project_id='project',revision=1,
        stage='mapped',result=producer_result,dependencies=[dependency.model_copy(update={'availability':'load_time'})])


def test_failed_result_cannot_leak_an_artifact_to_other_partitions():
    dependency=edge()
    work=[Partition(partition_id='p',mapping_key='producer'),
          Partition(partition_id='c',mapping_key='consumer',dependencies=[dependency])]
    def execute(partition):
        return {'partition_state':'NEEDS_REVIEW','artifact_contracts':[
            ArtifactContract(artifact_id='lookup',producer_mapping='producer',revision=1,
                             stage='mapped',evidence_ids=['e'],verified=True).model_dump()]}
    result=PartitionScheduler(max_workers=2,persist=lambda p:None,check_active=lambda:None).run(work,execute)
    assert result[1].state==PartitionState.WAITING


def test_failed_partition_preserves_structured_partial_review_evidence():
    class PartialFailure(RuntimeError):
        partial_result = {"target_table": "DB.T.CALLS", "sttm_id": "s1", "mapping_rows": [{
            "target_column": "OWNERID", "status": "unresolved",
        }], "review_items": [{"category": "mapping_candidate_review", "safe_summary": "Owner needs a value"}]}

    work = [Partition(partition_id="calls:compile", mapping_key="calls", stage="compile")]
    result = PartitionScheduler(max_workers=1, persist=lambda _p: None, check_active=lambda: None).run(
        work, lambda _p: (_ for _ in ()).throw(PartialFailure("save failed")))
    assert result[0].state == PartitionState.NEEDS_REVIEW
    assert result[0].result["target_table"] == "DB.T.CALLS"
    assert result[0].result["review_items"][0]["safe_summary"] == "Owner needs a value"
    assert result[0].result["error_type"] == "PartialFailure"


def test_partial_producer_dependency_does_not_create_false_mapping_cycle():
    dependency=edge(producer_columns=['KEY'],consumer_columns=['PARENT_KEY'],blocking_scope='column')
    validate_graph([
        Partition(partition_id='producer-key',mapping_key='producer',columns=['KEY']),
        Partition(partition_id='producer-rest',mapping_key='producer',columns=['REST'],waits_for=['consumer']),
        Partition(partition_id='consumer',mapping_key='consumer',columns=['PARENT_KEY'],dependencies=[dependency]),
    ])


def test_contract_combines_completed_column_partitions_and_survives_restart():
    dependency = edge(producer_columns=['KEY', 'TYPE'], producer_project='project')
    work = [Partition(partition_id='key', mapping_key='producer', project_id='project', columns=['KEY']),
            Partition(partition_id='type', mapping_key='producer', project_id='project', columns=['TYPE']),
            Partition(partition_id='consumer', mapping_key='consumer', dependencies=[dependency])]
    saved = {}
    def execute(p):
        if p.mapping_key == 'consumer':
            [contract] = p.dependency_contracts
            assert contract.payload['columns'] == ['KEY', 'TYPE']
            assert len(contract.payload['mapping_rows']) == 2
            return {}
        return {'mapping_rows': [{'target_column': c, 'status': 'draft', 'evidence_ids': ['e:' + c]}
                                 for c in p.columns]}
    scheduler = PartitionScheduler(max_workers=2, persist=lambda p: saved.update({p.partition_id:p.model_copy(deep=True)}),
                                   check_active=lambda: None)
    result = scheduler.run(work, execute)
    assert all(p.state == PartitionState.COMPLETED for p in result)
    producers = [saved['key'], saved['type']]
    assert sum(len(p.result.get('artifact_contracts', [])) for p in producers) == 1
    # Reconnect after both producers committed but before the consumer ran.
    resumed = scheduler.run([*producers, work[2].model_copy(update={'state': PartitionState.WAITING, 'result': {}})], execute)
    assert resumed[-1].state == PartitionState.COMPLETED


def test_unknown_producer_column_rejected_before_dispatch():
    with pytest.raises(ValueError, match='unknown producer columns'):
        validate_graph([Partition(partition_id='p', mapping_key='producer', columns=['KEY']),
                        Partition(partition_id='c', mapping_key='consumer',
                                  dependencies=[edge(producer_columns=['MISSING'])])])
