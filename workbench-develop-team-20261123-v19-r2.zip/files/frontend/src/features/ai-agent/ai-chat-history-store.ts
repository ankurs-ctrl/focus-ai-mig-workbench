// Shared browser-history adapter. Retains user/project scope normalization and
// server-conversation metadata; native conversation operations stay in the provider.
export {
  AI_CHAT_SESSIONS_STORAGE_KEY,
  loadStoredChatSessions,
  loadAllStoredChatSessions,
  persistChatSessions,
} from '@/features/ai-agent/ai-chat-session-utils';

export const MAX_STORED_CHAT_SESSIONS = 30;
