import type { WorkbenchContextSnapshotV1 } from "@/types/api-contract";
import { resolveApiBaseUrl } from "@/api/axiosInstance";

// Events per page of GET /agent-runs/{id}/events (the service default limit).
const EVENT_PAGE_SIZE = 500;

export type MigrationEffort = "auto" | "light" | "medium" | "high";
export type MigrationRunMode = "auto" | "plan";
export type MigrationConversationMessage = {
  role: "user" | "assistant";
  content: string;
};

export type ReviewTableRow = {
  row_id: string;
  mapping_key: string | null;
  mapping_name: string | null;
  sttm_id: string | null;
  tier: "planning_question" | "confidence" | "blocker";
  category: string;
  kind: string;
  targets: string[];
  target_keys: string[];
  column: string | null;
  current_choice: string | null;
  confidence: number | null;
  why: string;
  status: string;
  blocking: boolean;
  review_item_ids: string[];
  impact: number;
  accept_eligible: boolean;
  auto_approve_eligible: boolean;
  actionability: "required" | "confirmation" | "informational";
  source_blocking?: boolean;
  prevents_target_ready?: boolean;
  row_digest: string;
};

export type ReviewTable = {
  run_id: string;
  status: string;
  rows: ReviewTableRow[];
  mappings: Array<{
    mapping_key: string | null;
    mapping_name: string | null;
    target_table: string | null;
    sttm_id: string | null;
    mapped_count: number;
    unresolved_count: number;
    total_count: number;
    compile_valid: boolean;
    preview_valid: boolean;
  }>;
  summary: {
    targets_ready: number;
    targets: number;
    planning_questions: number;
    blockers: number;
    decisions_to_confirm: number;
    checks_failed: number;
    accept_eligible: number;
    actionable: number;
    informational: number;
    auto_approved: number;
    approval_threshold: number;
  };
};

export type MigrationAgentServerMessage = {
  contract_version: "1.0";
  type: string;
  session_id: string;
  request_id: string;
  event_id: string;
  timestamp: string;
  context_hash: string;
  data?: Record<string, unknown> | null;
  error?: { detail?: string; code?: string } | null;
};

export type MigrationAgentPermissionRequest = {
  permission_id: string;
  category?: string;
  tool: string;
  resource: string;
  reason: string;
  expected_effect: string;
  risk: string;
  reversible: boolean;
  input?: Record<string, unknown>;
  questions?: Array<{
    question: string;
    header?: string;
    options?: Array<{ id?: string; label: string; description?: string; recommended?: boolean; impact?: string; confidence?: number | null }>;
    multiSelect?: boolean;
  }>;
  plan?: Record<string, unknown>;
  interrupt_id?: string | null;
  action_digest?: string | null;
  artifact_revision?: string | null;
  recommended_choice_id?: string | null;
  allow_free_text?: boolean;
  answer_hint?: string | null;
};

type ApiEnvelope<T> = { data?: T } | T;

function migrationApiUrl(path: string): string {
  const base = resolveApiBaseUrl().replace(/\/$/, "");
  return `${base}${path.replace(/^\/api/, "")}`;
}

class ApiRequestError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
    this.name = "ApiRequestError";
  }
}

type RunEvent = {
  event_id: string;
  run_id: string;
  sequence: number;
  event_type: string;
  status: string;
  safe_summary: string;
  data?: Record<string, unknown>;
  trace_id?: string | null;
  span_id?: string | null;
  parent_event_id?: string | null;
  created_at: string;
  conversation_id?: string | null;
  turn_id?: string | null;
  intent?: string;
  plan_id?: string | null;
};

type RunState = {
  run: {
    run_id: string;
    status: string;
    request?: {
      prompt?: string;
      conversation_id?: string | null;
      conversation_history?: MigrationConversationMessage[];
      turn_id?: string | null;
    };
    project_id?: string | null;
    current_sttm_id?: string | null;
    current_mapping_name?: string | null;
    run_revision?: number;
  };
  review_items: Array<{
    review_item_id: string;
    category?: string;
    question?: string | null;
    choices?: Array<{
      choice_id: string;
      label: string;
      description?: string | null;
      impact?: string | null;
      evidence_ids?: string[];
      recommended?: boolean;
      confidence?: number | null;
      selection_payload?: Record<string, unknown>;
    }>;
    recommended_choice_id?: string | null;
    allow_free_text?: boolean;
    interrupt_id?: string | null;
    action_digest?: string | null;
    artifact_revision?: string | null;
    sttm_id?: string | null;
    subject_keys?: string[];
    blocking?: boolean;
    safe_summary: string;
    status: string;
  }>;
  mapping_dag: Array<{
    mapping_key: string;
    mapping_name: string;
    sttm_id?: string | null;
    status: string;
    partition_payload?: { result?: { sql_validation?: {
      compile_valid?: boolean; preview_valid?: boolean; compiled_mapping_sql?: string;
      compiled_mapping_preview_sql?: string;
      preview_columns?: string[]; preview_rows?: unknown[]; preview_row_count?: number;
    }; mapped_target_columns?: string[]; unresolved_target_columns?: string[] } };
  }>;
};

function unwrap<T>(value: ApiEnvelope<T>): T {
  return (typeof value === "object" && value !== null && "data" in value
    ? value.data
    : value) as T;
}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(migrationApiUrl(url), {
    credentials: "include",
    ...init,
    headers: {
      ...(init?.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(init?.headers ?? {}),
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = payload?.detail ?? payload?.error?.detail ?? response.statusText;
    throw new ApiRequestError(String(detail || `Migration Agent request failed (${response.status})`), response.status);
  }
  return unwrap<T>(payload as ApiEnvelope<T>);
}

export type MigrationAgentDiagnostics = {
  status: "ok" | "error";
  enabled: boolean;
  publish_available: false;
  supported_attachments: string[];
  model_options?: string[];
  effort_model_defaults?: Record<string, string>;
  error?: string;
  feature_flags?: Record<string, boolean>;
  plan_mode?: Record<string, boolean>;
  sandbox?: Record<string, unknown>;
  context_management?: Record<string, boolean>;
};

export async function fetchMigrationAgentDiagnostics(): Promise<MigrationAgentDiagnostics> {
  try {
    const capabilities = await api<{
      enabled: boolean;
      publish_available: false;
      supported_attachments: string[];
      model_options?: string[];
      effort_model_defaults?: Record<string, string>;
      feature_flags?: Record<string, boolean>;
      plan_mode?: Record<string, boolean>;
      sandbox?: Record<string, unknown>;
      context_management?: Record<string, boolean>;
    }>("/api/v1/agent-runs/capabilities");
    return {
      status: capabilities.enabled ? "ok" : "error",
      enabled: capabilities.enabled,
      publish_available: false,
      supported_attachments: capabilities.supported_attachments,
      model_options: capabilities.model_options ?? [],
      effort_model_defaults: capabilities.effort_model_defaults ?? {},
      feature_flags: capabilities.feature_flags,
      plan_mode: capabilities.plan_mode,
      sandbox: capabilities.sandbox,
      context_management: capabilities.context_management,
      error: capabilities.enabled ? undefined : "Migration Agent is disabled in this environment",
    };
  } catch (error) {
    return {
      status: "error",
      enabled: false,
      publish_available: false,
      supported_attachments: [],
      error: error instanceof Error ? error.message : "Migration Agent is unavailable",
    };
  }
}

export function getDiagnosticsErrorMessage(diagnostics: MigrationAgentDiagnostics): string | null {
  return diagnostics.status === "ok" && diagnostics.enabled
    ? null
    : diagnostics.error ?? "Migration Agent is unavailable";
}

export async function importLegacyQuickHistory(
  browserMigrationId: string,
  sessions: Array<{ id: string; title: string; projectId?: string | null; sttmId?: string | null; messages: MigrationConversationMessage[] }>,
): Promise<boolean> {
  if (!sessions.length) return true;
  const result = await api<{ confirmed: boolean }>("/api/v1/assistant-conversations/import", {
    method: "POST",
    body: JSON.stringify({
      browser_migration_id: browserMigrationId,
      sessions: sessions.map((session) => ({
        legacy_id: session.id,
        title: session.title,
        project_id: session.projectId ?? null,
        sttm_id: session.sttmId ?? null,
        messages: session.messages.map(({ role, content }) => ({ role, content })),
      })),
    }),
  });
  return result.confirmed === true;
}

export type ServerAssistantConversation = {
  conversation_id: string;
  mode: "quick" | "deep";
  title: string;
  updated_at: string;
  project_id?: string | null;
  sttm_id?: string | null;
  pinned?: boolean;
};

export async function fetchAssistantConversationHistory(scope?: { projectId?: string | null; sttmId?: string | null }): Promise<ServerAssistantConversation[]> {
  const history: ServerAssistantConversation[] = [];
  for (let offset = 0; offset < 1000; offset += 100) {
    const params = new URLSearchParams({ limit: '100', offset: String(offset) });
    if (scope?.projectId) params.set('project_id', scope.projectId);
    if (scope?.sttmId) params.set('sttm_id', scope.sttmId);
    const page = await api<ServerAssistantConversation[]>(`/api/v1/assistant-conversations?${params}`);
    history.push(...page);
    if (page.length < 100) break;
  }
  return history;
}

export async function updateAssistantConversation(
  conversationId: string,
  changes: { title?: string; project_id?: string | null; pinned?: boolean },
): Promise<ServerAssistantConversation> {
  return api<ServerAssistantConversation>(`/api/v1/assistant-conversations/${encodeURIComponent(conversationId)}`, {
    method: 'PATCH',
    body: JSON.stringify(changes),
  });
}

export async function deleteAssistantConversation(conversationId: string): Promise<void> {
  await api(`/api/v1/assistant-conversations/${encodeURIComponent(conversationId)}`, {
    method: "DELETE",
  });
}

export async function fetchAssistantConversation(conversationId: string): Promise<{
  conversation: ServerAssistantConversation;
  turns: Array<{ turn_id: string; role: string; message: string }>;
}> {
  return api(`/api/v1/assistant-conversations/${encodeURIComponent(conversationId)}`);
}

export class MigrationAgentSessionClient {
  private runId: string | null = null;
  private reviewItemId: string | null = null;
  private cursor = 0;
  private closed = false;
  private effort: MigrationEffort = "auto";
  private modelName: string | null = null;
  private runMode: MigrationRunMode = "auto";
  private pendingPlanOffer: { message: string; snapshot: WorkbenchContextSnapshotV1; history: MigrationConversationMessage[] } | null = null;
  private attachmentIds: string[] = [];
  private onMessage: ((message: MigrationAgentServerMessage) => void) | null = null;
  private onDisconnect: (() => void) | null = null;
  private streamAbort: AbortController | null = null;
  private pendingInterruptId: string | null = null;
  private pendingActionDigest: string | null = null;
  private pendingArtifactRevision: string | null = null;
  private terminalEventReceived = false;
  private cancellationRequested = false;
  private streamGeneration = 0;
  private conversationId: string | null = null;
  private activeTurnId: string | null = null;
  private useConversationApi = false;
  private connectionReady: Promise<void> | null = null;
  private conversationCreationPromise: Promise<string> | null = null;
  private conversationCreationKey = crypto.randomUUID();

  getConversationId(): string | null {
    return this.conversationId;
  }

  setOptions(options: { effort: MigrationEffort; modelName?: string | null; runMode: MigrationRunMode; attachmentIds: string[] }): void {
    this.effort = options.effort;
    this.modelName = options.modelName ?? null;
    this.runMode = options.runMode;
    this.attachmentIds = [...options.attachmentIds];
  }

  async uploadAttachment(file: File): Promise<string> {
    const form = new FormData();
    form.append("file", file);
    const attachment = await api<{ attachment_id: string }>("/api/v1/agent-runs/attachments", {
      method: "POST",
      body: form,
    });
    return attachment.attachment_id;
  }

  async connect(
    snapshot: WorkbenchContextSnapshotV1,
    onMessage: (message: MigrationAgentServerMessage) => void,
    onDisconnect: () => void,
  ): Promise<void> {
    this.closed = false;
    this.onMessage = onMessage;
    this.onDisconnect = onDisconnect;
    // Mode switching is a UI-local operation. Negotiate capabilities only;
    // creating or restoring durable state here causes blank history entries
    // and makes an old run suddenly replace the welcome screen.
    this.connectionReady = (async () => {
      const diagnostics = await fetchMigrationAgentDiagnostics();
      const error = getDiagnosticsErrorMessage(diagnostics);
      if (error) throw new Error(error);
      this.useConversationApi = Boolean(
        diagnostics.feature_flags?.unified_history && diagnostics.feature_flags?.intent_routing,
      );
      if (this.useConversationApi) {
        // A placeholder may have been allocated before capability negotiation;
        // unified conversations are server-owned and must be created on submit.
        this.conversationId = null;
      } else if (!this.conversationId) {
        this.conversationId = crypto.randomUUID();
      }
    })();
    void this.connectionReady.catch(() => undefined);
    this.emit("session.ready", snapshot.context_hash, { durable: true, publish_available: false });
  }

  sendMessage(
    message: string,
    snapshot: WorkbenchContextSnapshotV1,
    conversationHistory: MigrationConversationMessage[] = [],
  ): void {
    void this.startRun(message, snapshot, conversationHistory);
  }

  resumePlanOffer(mode: "plan" | "auto"): void {
    const pending = this.pendingPlanOffer;
    if (!pending) return;
    this.pendingPlanOffer = null;
    this.runMode = mode;
    void this.startRun(pending.message, pending.snapshot, pending.history, mode === "auto" ? "continue_auto" : undefined);
  }

  dismissPlanOffer(): void {
    this.pendingPlanOffer = null;
  }

  get isConnected(): boolean {
    return !this.closed && this.onMessage !== null;
  }

  startNewConversation(): void {
    this.streamGeneration += 1;
    this.streamAbort?.abort();
    this.runId = null;
    this.pendingPlanOffer = null;
    this.reviewItemId = null;
    this.pendingInterruptId = null;
    this.pendingActionDigest = null;
    this.pendingArtifactRevision = null;
    this.cursor = 0;
    this.terminalEventReceived = false;
    this.cancellationRequested = false;
    this.attachmentIds = [];
    this.conversationId = this.useConversationApi ? null : crypto.randomUUID();
    this.activeTurnId = null;
    this.conversationCreationPromise = null;
    this.conversationCreationKey = crypto.randomUUID();
  }

  async restoreConversation(
    conversationId: string,
    snapshot: WorkbenchContextSnapshotV1,
    onMessage: (message: MigrationAgentServerMessage) => void,
    onDisconnect: () => void,
  ): Promise<void> {
    this.closed = false;
    this.onMessage = onMessage;
    this.onDisconnect = onDisconnect;
    const restoreGeneration = ++this.streamGeneration;
    this.streamAbort?.abort();
    const detail = await api<{
      conversation: ServerAssistantConversation;
      turns: Array<{ turn_id: string; role: string; message: string; metadata?: { question?: { prompt: string; options: Array<{ label: string; description: string }> } } }>;
      linked_runs: Array<{
        run_id: string;
        status: RunState["run"]["status"];
        turn_id: string | null;
        safe_error?: string | null;
      }>;
      attachments?: Array<{ id: string; name: string }>;
      current_plan?: Record<string, unknown> | null;
    }>(`/api/v1/assistant-conversations/${encodeURIComponent(conversationId)}`);
    if (this.closed || restoreGeneration !== this.streamGeneration) return;
    this.conversationId = conversationId;
    this.attachmentIds = (detail.attachments ?? []).map((attachment) => attachment.id);
    const latest = detail.linked_runs.at(-1) ?? null;
    this.runId = latest?.run_id ?? null;
    this.activeTurnId = latest?.turn_id ?? null;
    this.cursor = 0;
    this.terminalEventReceived = false;
    const status = latest?.status ?? "COMPLETED";
    this.emit("session.restored", snapshot.context_hash, {
      run_id: latest?.run_id ?? conversationId,
      prompt: "",
      status,
      conversation_history: detail.turns
        .filter((turn) => turn.role === "user" || turn.role === "assistant")
        .map((turn) => ({ role: turn.role, content: turn.message, turn_id: turn.turn_id, question: turn.metadata?.question })),
      attachments: detail.attachments ?? [],
      current_plan: detail.current_plan ?? null,
    });
    if (latest && ['AWAITING_INPUT', 'AWAITING_CONFIRMATION'].includes(status)) {
      const state = await api<RunState>(`/api/v1/agent-runs/${encodeURIComponent(latest.run_id)}`);
      if (this.closed || restoreGeneration !== this.streamGeneration || this.runId !== latest.run_id) return;
      const pending = state.review_items.find(item => item.status === 'OPEN' && item.interrupt_id);
      if (pending) {
        this.reviewItemId = pending.review_item_id;
        this.pendingInterruptId = pending.interrupt_id ?? null;
        this.pendingActionDigest = pending.action_digest ?? null;
        this.pendingArtifactRevision = pending.artifact_revision ?? null;
        const plan = detail.current_plan?.plan;
        this.emit('permission.requested', snapshot.context_hash, {
          permission_id: pending.review_item_id, category: pending.category,
          tool: pending.category === 'plan_approval' ? 'approve_migration_plan' : 'answer_migration_question',
          resource: 'run-owned draft plan', reason: pending.question ?? pending.safe_summary,
          expected_effect: 'Resume this exact saved plan.', risk: 'draft_write', reversible: true,
          interrupt_id: pending.interrupt_id, action_digest: pending.action_digest,
          artifact_revision: pending.artifact_revision, recommended_choice_id: pending.recommended_choice_id,
          allow_free_text: pending.allow_free_text === true,
          plan: plan && typeof plan === 'object' ? plan : undefined,
          questions: [{question: pending.question ?? pending.safe_summary,
            options: (pending.choices ?? []).map(choice => ({id: choice.choice_id, label: choice.label,
              description: choice.description ?? undefined, impact: choice.impact ?? undefined,
              recommended: choice.recommended || choice.choice_id === pending.recommended_choice_id,
              confidence: choice.confidence ?? null}))}],
        });
      }
    }
    const terminal = ["COMPLETED", "NEEDS_REVIEW", "COMPLETED_WITH_REVIEW_ITEMS", "READY_FOR_REVIEW", "FAILED", "CANCELLED", "EXPIRED"].includes(status);
    if (latest && terminal) {
      const generation = ++this.streamGeneration;
      await this.fetchAvailableEvents(snapshot.context_hash, latest.run_id, generation);
      // The run row is the source of truth: a run that ended without a
      // terminal event (a failed trace write, for example) still ends here.
      if (!this.terminalEventReceived && status === "FAILED") {
        this.emit("assistant.error", snapshot.context_hash, {}, {
          detail: latest.safe_error || "The run stopped with an error.", code: status,
        });
      } else if (!this.terminalEventReceived && status === "CANCELLED") {
        this.emit("assistant.cancelled", snapshot.context_hash, { message: "The run was stopped." });
      }
      this.terminalEventReceived = true;
      this.emit("session.caught_up", snapshot.context_hash, { run_id: latest.run_id, cursor: this.cursor, terminal: true, status });
    } else if (latest) {
      const generation = ++this.streamGeneration;
      void this.stream(snapshot.context_hash, latest.run_id, generation);
    }
  }

  private async ensureConversation(snapshot: WorkbenchContextSnapshotV1): Promise<string> {
    if (this.conversationId) return this.conversationId;
    if (this.conversationCreationPromise) return this.conversationCreationPromise;
    const context = snapshot as unknown as Record<string, unknown>;
    this.conversationCreationPromise = api<{ conversation_id: string }>("/api/v1/assistant-conversations", {
        method: "POST",
        body: JSON.stringify({
          mode: "deep",
          project_id: context.project_id ?? null,
          sttm_id: context.sttm_id ?? null,
          idempotency_key: this.conversationCreationKey,
        }),
      })
      .then((conversation) => {
        this.conversationId = conversation.conversation_id;
        return conversation.conversation_id;
      })
      .finally(() => {
        this.conversationCreationPromise = null;
      });
    return this.conversationCreationPromise;
  }

  private async startRun(
    message: string,
    snapshot: WorkbenchContextSnapshotV1,
    conversationHistory: MigrationConversationMessage[],
    planOfferDecision?: "continue_auto",
  ): Promise<void> {
    const generation = ++this.streamGeneration;
    this.streamAbort?.abort();
    this.terminalEventReceived = false;
    try {
      if (this.connectionReady) await this.connectionReady;
      const context = snapshot as unknown as Record<string, unknown>;
      const target = snapshot.target_table;
      const targetScope = target
        ? [`${target.database}.${target.schema}.${target.table}`]
        : [];
      const sourceScope = snapshot.source_tables.map(
        (table) => `${table.database}.${table.schema}.${table.table}`,
      );
      const authorizedSchemas = Array.from(new Set([
        ...snapshot.source_tables.map((table) => `${table.database}.${table.schema}`),
        ...(snapshot.source_tables.length > 0 && target ? [`${target.database}.${target.schema}`] : []),
      ]));
      if (!this.useConversationApi) {
        const legacyRun = await api<{ run_id: string }>("/api/v1/agent-runs", {
          method: "POST",
          body: JSON.stringify({
            prompt: message,
            effort: this.effort,
            model_name: this.modelName,
            run_mode: this.runMode,
            conversation_id: this.conversationId ?? crypto.randomUUID(),
            conversation_history: conversationHistory.slice(-40),
            project_id: context.project_id ?? null,
            source_scope: sourceScope,
            target_scope: targetScope,
            authorized_schemas: authorizedSchemas,
            page_context: context,
            attachment_ids: this.attachmentIds,
            idempotency_key: crypto.randomUUID(),
          }),
        });
        if (this.closed || generation !== this.streamGeneration) return;
        this.runId = legacyRun.run_id;
        this.cursor = 0;
        this.terminalEventReceived = false;
        this.cancellationRequested = false;
        await this.stream(snapshot.context_hash, legacyRun.run_id, generation);
        return;
      }
      const conversationId = await this.ensureConversation(snapshot);
      const turn = await api<{
        turn_id: string;
        intent: string;
        execution_path: "fast_path" | "plan_offer" | "new_run" | "resume" | "control";
        message?: string | null;
        question?: { prompt: string; options: Array<{ label: string; description: string }> } | null;
        plan_offer?: { reason: string; recommended_mode: string } | null;
        run?: { run_id: string; status: string } | null;
      }>(`/api/v1/assistant-conversations/${encodeURIComponent(conversationId)}/turns`, {
        method: "POST",
        body: JSON.stringify({
          message,
          effort: this.effort,
          model_name: this.modelName,
          run_mode: this.runMode,
          plan_offer_decision: planOfferDecision,
          project_id: context.project_id ?? null,
          source_scope: sourceScope,
          target_scope: targetScope,
          authorized_schemas: authorizedSchemas,
          page_context: context,
          attachment_ids: this.attachmentIds,
          idempotency_key: crypto.randomUUID(),
        }),
      });
      if (this.closed || generation !== this.streamGeneration) return;
      if (turn.execution_path === "plan_offer" && turn.plan_offer) {
        this.pendingPlanOffer = { message, snapshot, history: conversationHistory };
        this.emit("plan.mode.recommended", snapshot.context_hash, turn.plan_offer);
        return;
      }
      this.activeTurnId = turn.turn_id;
      if (turn.execution_path === "fast_path" || !turn.run) {
        this.runId = null;
        this.terminalEventReceived = true;
        if (turn.message) {
          this.emit("assistant.final", snapshot.context_hash, {
            text: turn.message,
            question: turn.question ?? null,
            turn_id: turn.turn_id,
            intent: turn.intent,
            execution_path: turn.execution_path,
          });
        }
        return;
      }
      this.runId = turn.run.run_id;
      this.cursor = 0;
      this.terminalEventReceived = false;
      this.cancellationRequested = false;
      this.emit("assistant.status", snapshot.context_hash, {
        status: "Starting agent…",
        message: "Execution continues safely if this browser disconnects.",
      });
      await this.stream(snapshot.context_hash, turn.run.run_id, generation, turn.execution_path !== "new_run");
    } catch (error) {
      this.emitError(error);
    }
  }

  private async stream(contextHash: string, runId: string, generation: number, catchUp = true): Promise<void> {
    if (this.runId !== runId || generation !== this.streamGeneration) return;
    // Fetch already-committed events first. Some reverse proxies buffer a new
    // SSE response until its first upstream Snowflake query completes; this
    // bounded read makes the real plan/tool activity visible immediately.
    // A run created by this very request has at most its queued event, which
    // the stream's first poll returns, so the extra round trip is skipped.
    if (catchUp) {
      try {
        await this.fetchAvailableEvents(contextHash, runId, generation);
        this.emit("session.caught_up", contextHash, { run_id: runId, cursor: this.cursor });
      } catch {
        this.emit("assistant.status", contextHash, {
          status: "Reconnecting to agent activity…",
        });
      }
    } else {
      // Nothing durable precedes a brand-new run: everything is live output.
      this.emit("session.caught_up", contextHash, { run_id: runId, cursor: this.cursor });
    }
    let reconnectAttempts = 0;
    let reconnectStartedAt: number | null = null;
    while (!this.closed && !this.terminalEventReceived && this.runId === runId && generation === this.streamGeneration) {
      this.streamAbort?.abort();
      this.streamAbort = new AbortController();
      const controller = this.streamAbort;
      let inactivityTimer: ReturnType<typeof setTimeout> | null = null;
      const armInactivityReconnect = () => {
        if (inactivityTimer) clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => controller.abort(), 60_000);
      };
      armInactivityReconnect();
      try {
        const response = await fetch(
          migrationApiUrl(`/api/v1/agent-runs/${encodeURIComponent(runId)}/events?after=${this.cursor}&follow=true`),
          { credentials: "include", headers: { Accept: "text/event-stream" }, signal: controller.signal },
        );
        if (!response.ok || !response.body) {
          throw new ApiRequestError(`Migration event stream failed (${response.status})`, response.status);
        }
        if (reconnectStartedAt !== null) {
          this.emit("trace.event", contextHash, {
            trace_id: `transport:${runId}:${Date.now()}`,
            kind: "transport",
            label: "Activity stream reconnected",
            status: "succeeded",
            safe_summary: "Durable activity streaming resumed from the last committed cursor.",
            metrics: { reconnect_latency_ms: Date.now() - reconnectStartedAt },
          });
          reconnectStartedAt = null;
        }
        reconnectAttempts = 0;
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        while (!this.closed && !this.terminalEventReceived && this.runId === runId && generation === this.streamGeneration) {
          const { value, done } = await reader.read();
          if (done) break;
          armInactivityReconnect();
          buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");
          let boundary = buffer.indexOf("\n\n");
          while (boundary >= 0) {
            const block = buffer.slice(0, boundary);
            buffer = buffer.slice(boundary + 2);
            const data = block.split("\n").filter((line) => line.startsWith("data:"))
              .map((line) => line.slice(5).trim()).join("\n");
            if (data) this.acceptEvent(JSON.parse(data) as RunEvent, contextHash, runId, generation);
            boundary = buffer.indexOf("\n\n");
          }
        }
      } catch (error) {
        if (this.closed || this.terminalEventReceived || this.runId !== runId || generation !== this.streamGeneration) return;
        if (error instanceof ApiRequestError && error.status >= 400 && error.status < 500 && ![408, 429].includes(error.status)) {
          throw error;
        }
        reconnectAttempts += 1;
        reconnectStartedAt ??= Date.now();
        // A proxy or development server can buffer an otherwise healthy SSE
        // connection. Reconcile from the committed cursor before reconnecting
        // so durable activity is never stranded behind that transport layer.
        try {
          await this.fetchAvailableEvents(contextHash, runId, generation);
        } catch {
          // The reconnect loop below owns retry/backoff and user diagnostics.
        }
        if (reconnectAttempts === 1 || reconnectAttempts % 8 === 0) {
          this.emit("assistant.status", contextHash, {
            status: "Agent is still running. Reconnecting to activity…",
            transport_retry: reconnectAttempts,
          });
        }
      } finally {
        if (inactivityTimer) clearTimeout(inactivityTimer);
        // The reader stops at a terminal event; cancel the response too so
        // the server ends its polling loop instead of draining for seconds.
        if (this.terminalEventReceived) controller.abort();
      }
      if (this.closed || this.terminalEventReceived || this.runId !== runId || generation !== this.streamGeneration) return;
      const retryDelay = Math.min(10_000, 1_000 * Math.max(1, Math.ceil(reconnectAttempts / 2)));
      await new Promise((resolve) => setTimeout(resolve, retryDelay));
    }
  }

  private acceptEvent(event: RunEvent, contextHash: string, runId: string, generation: number): void {
    if (event.run_id !== runId || this.runId !== runId || generation !== this.streamGeneration) return;
    if (this.conversationId && event.conversation_id && event.conversation_id !== this.conversationId) return;
    if (this.activeTurnId && event.turn_id && event.turn_id !== this.activeTurnId) return;
    if (event.sequence <= this.cursor) return;
    event.data = {
      ...(event.data ?? {}),
      buffered_event_delay_ms: Math.max(0, Date.now() - new Date(event.created_at).getTime()),
    };
    this.cursor = event.sequence;
    this.handleRunEvent(event, contextHash);
    if (["assistant.final", "run.failed", "run.cancelled"].includes(event.event_type)) {
      this.terminalEventReceived = true;
    }
  }

  private async fetchAvailableEvents(contextHash: string, runId: string, generation: number): Promise<void> {
    // The events endpoint returns one page (500) per call; a long run has more.
    // Keep reading from the cursor until a short page, so a restored run
    // replays through its final answer instead of stopping mid-way.
    for (let page = 0; page < 200; page += 1) {
      if (this.runId !== runId || generation !== this.streamGeneration) return;
      const before = this.cursor;
      const events = await api<RunEvent[]>(
        `/api/v1/agent-runs/${encodeURIComponent(runId)}/events?after=${this.cursor}&follow=false`,
      );
      for (const event of events) this.acceptEvent(event, contextHash, runId, generation);
      if (events.length < EVENT_PAGE_SIZE || this.cursor <= before) return;
    }
  }

  private handleRunEvent(event: RunEvent, contextHash: string): void {
    if (event.event_type === "run.question.answered") {
      this.emit("permission.resolved", contextHash, {
        permission_id: event.data?.review_item_id,
        run_id: event.run_id,
      });
      return;
    }
    if (["run.question.required", "plan.approval_required"].includes(event.event_type)) {
      const choices = Array.isArray(event.data?.choices) ? event.data.choices as RunState["review_items"][number]["choices"] : [];
      this.reviewItemId = String(event.data?.review_item_id ?? "");
      this.pendingInterruptId = typeof event.data?.interrupt_id === "string" ? event.data.interrupt_id : null;
      this.pendingActionDigest = typeof event.data?.action_digest === "string" ? event.data.action_digest : null;
      this.pendingArtifactRevision = event.data?.artifact_revision != null ? String(event.data.artifact_revision) : null;
      this.emit("permission.requested", contextHash, {
        permission_id: this.reviewItemId,
        category: String(event.data?.category ?? ""),
        tool: event.event_type === "plan.approval_required" ? "approve_migration_plan" : "answer_migration_question",
        resource: event.event_type === "plan.approval_required" ? "run-owned draft plan" : "migration run",
        reason: String(event.data?.question ?? event.safe_summary),
        expected_effect: "Resume the same durable plan with your selected answer.",
        risk: event.event_type === "plan.approval_required" ? "draft_write" : "low",
        reversible: true,
        interrupt_id: event.data?.interrupt_id ?? null,
        action_digest: event.data?.action_digest ?? null,
        recommended_choice_id: event.data?.recommended_choice_id ?? null,
        allow_free_text: event.data?.allow_free_text !== false,
        answer_hint: typeof event.data?.answer_hint === "string" ? event.data.answer_hint : null,
        plan: event.data?.plan && typeof event.data.plan === "object"
          ? event.data.plan as Record<string, unknown>
          : undefined,
        questions: [{
          question: String(event.data?.question ?? event.safe_summary),
          options: (choices ?? []).map((choice) => ({
            id: choice.choice_id,
            label: choice.label,
            description: choice.description ?? undefined,
            impact: choice.impact ?? undefined,
            recommended: choice.recommended || choice.choice_id === event.data?.recommended_choice_id,
            confidence: typeof choice.confidence === "number" ? choice.confidence : null,
          })),
        }],
      });
      return;
    }
    if (event.event_type === "run.failed") {
      this.emit("trace.event", contextHash, {
        ...event.data,
        trace_id: event.trace_id ?? event.event_id,
        event_type: event.event_type,
        kind: "run",
        label: "Run failed",
        status: "failed",
        safe_summary: event.safe_summary,
        created_at: event.created_at,
      });
      this.emit("assistant.error", contextHash, {}, { detail: event.safe_summary, code: event.status });
      return;
    }
    if (event.event_type === "run.cancelled") {
      this.emit("trace.event", contextHash, {
        ...event.data,
        trace_id: event.trace_id ?? event.event_id,
        event_type: event.event_type,
        kind: "run",
        label: "Run stopped",
        status: "cancelled",
        safe_summary: event.safe_summary,
        created_at: event.created_at,
      });
      this.emit("assistant.cancelled", contextHash, { message: event.safe_summary });
      return;
    }
    if (["run.completed_with_review_items", "run.ready_for_review"].includes(event.event_type)) {
      this.emit("trace.event", contextHash, {
        ...event.data,
        trace_id: event.trace_id ?? event.event_id,
        event_type: event.event_type,
        kind: "run",
        label: "Review required",
        status: "needs_review",
        safe_summary: event.safe_summary,
        created_at: event.created_at,
      });
      const completedRunId = event.run_id;
      void this.refreshReviewItems(contextHash, completedRunId).catch(() => undefined);
      return;
    }
    if (event.event_type === "assistant.final") {
      this.emit("assistant.final", contextHash, {
        text: String(event.data?.text ?? event.safe_summary),
        status: event.data?.status,
        run_id: this.runId,
        durable_event_id: event.event_id,
      });
      return;
    }
    if (event.event_type === "assistant.update") {
      const text = String(event.data?.text ?? event.safe_summary);
      // Model-authored milestone narration is rendered once in the conversation.
      // Tool/plan lifecycle remains independently inspectable in activity.
      this.emit("assistant.progress", contextHash, {
        text, durable_event_id: event.event_id, progress: event.data?.progress ?? null,
      });
      return;
    }
    if (event.event_type === "context.usage") {
      // Context meter only; never a status line or an activity row.
      this.emit("context.usage", contextHash, { ...(event.data ?? {}), run_id: event.run_id });
      return;
    }
    if (event.event_type === "workspace.synced") {
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("aia:workspace-synced", { detail: event.data ?? {} }));
      }
      this.emit("trace.event", contextHash, {
        ...event.data,
        trace_id: event.trace_id ?? event.event_id,
        event_type: event.event_type,
        kind: "artifact",
        label: "Workbench draft synchronized",
        status: event.status,
        safe_summary: event.safe_summary,
        created_at: event.created_at,
      });
      return;
    }
    if (
      event.event_type.startsWith("trace.")
      || event.event_type.startsWith("tool.")
      || event.event_type.startsWith("model.")
      || event.event_type.startsWith("supervisor.")
      || event.event_type.startsWith("subagent.")
      || event.event_type.startsWith("agent.")
      || event.event_type.startsWith("plan.")
      || event.event_type.startsWith("source_preparation.")
      || event.event_type.startsWith("automap.")
      || event.event_type.startsWith("artifact.")
      || event.event_type.startsWith("validation.")
      || event.event_type.startsWith("evaluation.")
      || event.event_type.startsWith("learning.")
      || event.event_type === "context.compacted"
      || event.event_type === "assistant.preamble"
      || event.event_type === "run.queued"
      || event.event_type === "run.started"
      || event.event_type === "run.resumed.execution"
      || event.event_type === "run.cancel.requested"
      || event.event_type === "run.cancelled"
      || event.event_type === "run.ready_for_review"
    ) {
      const requestedEffort = typeof event.data?.requested_effort === "string" ? event.data.requested_effort : null;
      const resolvedEffort = typeof event.data?.resolved_effort === "string" ? event.data.resolved_effort : null;
      const runLabel = event.event_type === "run.queued"
        ? `Waiting for worker${resolvedEffort ? ` · ${requestedEffort === "auto" ? `Auto → ${resolvedEffort}` : resolvedEffort} effort` : ""}`
        : event.event_type === "run.started"
          ? "Agent started"
          : event.event_type === "run.resumed.execution"
            ? "Agent resumed"
          : null;
      const runSummary = event.event_type === "run.queued"
        ? "Request saved. The Deep Agent worker has not started this run yet; steps will appear when it claims the run."
        : event.safe_summary;
      this.emit("trace.event", contextHash, {
        ...event.data,
        trace_id: event.trace_id ?? event.data?.trace_id ?? event.event_id,
        parent_trace_id: event.data?.parent_trace_id ?? event.parent_event_id ?? null,
        event_type: event.event_type,
        kind: event.data?.kind ?? (event.event_type.startsWith("run.") ? "run" : undefined),
        label: runLabel ?? event.data?.label ?? event.safe_summary,
        status: event.status,
        safe_summary: runSummary,
        created_at: event.created_at,
      });
      return;
    }
    this.emit("assistant.status", contextHash, {
      status: event.safe_summary,
      event_type: event.event_type,
      run_id: event.run_id,
    });
  }

  private async refreshReviewItems(contextHash: string, runId: string): Promise<void> {
    const state = await api<RunState>(`/api/v1/agent-runs/${encodeURIComponent(runId)}`);
    if (this.runId !== runId) return;
    const compile = state.mapping_dag.find((item) => item.mapping_key.endsWith(":compile"))?.partition_payload?.result;
    this.emit("review.items", contextHash, {
      run_id: runId,
      artifact: compile ? {
        sql: compile.sql_validation?.compiled_mapping_preview_sql ?? "",
        compileValid: compile.sql_validation?.compile_valid === true,
        previewValid: compile.sql_validation?.preview_valid === true,
        previewColumns: compile.sql_validation?.preview_columns ?? [],
        previewRows: (compile.sql_validation?.preview_rows ?? []).slice(0, 10).map((row) =>
          typeof row === "string" ? row : JSON.stringify(row)),
        previewRowCount: compile.sql_validation?.preview_row_count ?? 0,
        mappedCount: compile.mapped_target_columns?.length ?? 0,
        unresolvedCount: compile.unresolved_target_columns?.length ?? 0,
      } : null,
      items: state.review_items.map((item) => ({
        review_item_id: item.review_item_id,
        category: item.category,
        question: item.question,
        summary: item.safe_summary,
        choices: item.choices ?? [],
        recommended_choice_id: item.recommended_choice_id ?? null,
        allow_free_text: item.allow_free_text !== false,
        blocking: item.blocking === true,
        subject_keys: item.subject_keys ?? [],
        status: item.status,
        sttm_id: item.sttm_id ?? null,
      })),
    });
  }

  async answerReviewDecision(contextHash: string, reviewItemId: string, choiceId: string | null,
    answer: string | null = null): Promise<void> {
    if (!this.runId) throw new Error("No saved migration run is available for review.");
    const runId = this.runId;
    const state = await api<RunState>(`/api/v1/agent-runs/${encodeURIComponent(runId)}`);
    const item = state.review_items.find(value => value.review_item_id === reviewItemId && value.status === 'OPEN');
    if (!item) throw new Error('This question has changed. Refresh the conversation.');
    await api(`/api/v1/agent-runs/${encodeURIComponent(runId)}/answer`, {
      method: "POST",
      body: JSON.stringify({ review_item_id: reviewItemId, choice_id: choiceId, answer,
        interrupt_id: item.interrupt_id, action_digest: item.action_digest,
        artifact_revision: item.artifact_revision, idempotency_key: crypto.randomUUID() }),
    });
    await this.refreshReviewItems(contextHash, runId);
    if (['AWAITING_INPUT', 'AWAITING_CONFIRMATION'].includes(state.run.status)) {
      this.terminalEventReceived = false;
      this.reviewItemId = null;
      const generation = ++this.streamGeneration;
      void this.stream(contextHash, runId, generation).catch(error => this.emitError(error));
    }
  }

  /** The run's tiered review table: planning questions, confidence rows, blockers. */
  async fetchReviewTable(): Promise<ReviewTable | null> {
    if (!this.runId) return null;
    return api<ReviewTable>(`/api/v1/agent-runs/${encodeURIComponent(this.runId)}/review-table`);
  }

  /** Confirm proposed rows as they are; returns the rows the server accepted. */
  async acceptReviewRows(rows: ReviewTableRow[], expectedRunRevision?: number): Promise<{ accepted: string[]; skipped: string[] }> {
    if (!this.runId) throw new Error("No saved migration run is available for review.");
    return api(`/api/v1/agent-runs/${encodeURIComponent(this.runId)}/review-table/accept`, {
      method: "POST",
      body: JSON.stringify({ row_ids: rows.map((row) => row.row_id),
        row_digests: Object.fromEntries(rows.map((row) => [row.row_id, row.row_digest])),
        expected_run_revision: expectedRunRevision }),
    });
  }

  decidePermission(
    contextHash: string,
    permissionId: string,
    decision: "allow_once" | "allow_session" | "deny" | "deny_with_feedback" | "cancel",
    feedback = "",
    choiceId: string | null = null,
  ): void {
    if (decision === "cancel" || decision === "deny") {
      this.cancel(contextHash);
      return;
    }
    if (!this.runId) return;
    const answer = feedback.trim() || (decision === "allow_session" ? "Approved for this run" : "Approved");
    void api(`/api/v1/agent-runs/${encodeURIComponent(this.runId)}/answer`, {
      method: "POST",
      body: JSON.stringify({
        review_item_id: permissionId,
        answer: choiceId ? null : answer,
        choice_id: choiceId,
        idempotency_key: crypto.randomUUID(),
        interrupt_id: this.pendingInterruptId,
        action_digest: this.pendingActionDigest,
        artifact_revision: this.pendingArtifactRevision,
      }),
    }).then(() => {
      this.reviewItemId = null;
      this.pendingInterruptId = null;
      this.pendingActionDigest = null;
      this.pendingArtifactRevision = null;
      this.emit("assistant.status", contextHash, { status: "Answer recorded; run resuming." });
    }).catch(async (error) => {
      // The answer may have committed even if its HTTP response was lost.
      // Reconcile the durable run before offering another mutation attempt.
      const activeRunId = this.runId;
      if (!activeRunId) return this.emitError(error);
      try {
        const state = await api<RunState>(`/api/v1/agent-runs/${encodeURIComponent(activeRunId)}`);
        await this.fetchAvailableEvents(contextHash, activeRunId, this.streamGeneration);
        if (["COMPLETED", "FAILED", "CANCELLED", "NEEDS_REVIEW"].includes(state.run.status)) {
          return;
        }
        if (["QUEUED", "EXECUTING"].includes(state.run.status)) {
          this.emit("assistant.status", contextHash, { status: "Answer recorded; reconnecting to the durable run…" });
          return;
        }
        const pending = state.review_items.find((item) => item.review_item_id === permissionId && item.status === "OPEN");
        if (pending) {
          this.emit("permission.requested", contextHash, {
            permission_id: pending.review_item_id,
            category: pending.category,
            tool: pending.category === "plan_approval" ? "approve_migration_plan" : "answer_migration_question",
            resource: "migration run",
            reason: pending.question ?? pending.safe_summary,
            expected_effect: "Resume the same durable checkpoint.",
            risk: "low", reversible: true,
            interrupt_id: pending.interrupt_id,
            action_digest: pending.action_digest,
            artifact_revision: pending.artifact_revision,
            recommended_choice_id: pending.recommended_choice_id,
            allow_free_text: pending.allow_free_text,
            questions: [{ question: pending.question ?? pending.safe_summary,
              options: (pending.choices ?? []).map((item) => ({ id: item.choice_id, label: item.label,
                description: item.description ?? undefined, impact: item.impact ?? undefined,
                recommended: item.recommended || item.choice_id === pending.recommended_choice_id,
                confidence: typeof item.confidence === "number" ? item.confidence : null })) }],
          });
          this.emit("assistant.status", contextHash, { status: "The answer was not recorded. Review the current checkpoint and try again." });
          return;
        }
      } catch {
        // Preserve the run ID and checkpoint; reconnect can recover it later.
      }
      this.emitError(error);
    });
  }

  answerQuestion(contextHash: string, permissionId: string, answers: Record<string, string>): void {
    this.decidePermission(contextHash, permissionId, "allow_once", Object.values(answers).join("\n"));
  }

  chooseOption(contextHash: string, permissionId: string, choiceId: string): void {
    this.decidePermission(contextHash, permissionId, "allow_once", "", choiceId);
  }

  reviewPlan(
    contextHash: string,
    permissionId: string,
    decision: "approve" | "request_changes" | "cancel",
    feedback = "",
  ): void {
    this.decidePermission(
      contextHash,
      permissionId,
      decision === "cancel" ? "cancel" : "allow_once",
      feedback || decision,
    );
  }

  cancel(contextHash: string): void {
    if (!this.runId || this.cancellationRequested) return;
    const runId = this.runId;
    const generation = this.streamGeneration;
    this.cancellationRequested = true;
    void api(`/api/v1/agent-runs/${encodeURIComponent(runId)}/cancel`, {
      method: "POST",
      body: JSON.stringify({ reason: "Cancelled from the AI Assistant" }),
    }).then(() => {
      if (this.runId === runId && this.streamGeneration === generation) {
        this.emit("assistant.status", contextHash, { status: "Stopping at the next safe boundary…" });
      }
    })
      .catch((error) => {
        if (this.runId !== runId || this.streamGeneration !== generation) return;
        this.cancellationRequested = false;
        this.emitError(error);
      });
  }

  close(): void {
    this.closed = true;
    this.streamGeneration += 1;
    this.streamAbort?.abort();
    this.onMessage = null;
    this.onDisconnect = null;
  }

  private emit(
    type: string,
    contextHash: string,
    data: Record<string, unknown> = {},
    error: MigrationAgentServerMessage["error"] = null,
  ): void {
    this.onMessage?.({
      contract_version: "1.0",
      type,
      session_id: this.runId ?? "migration-agent",
      request_id: crypto.randomUUID(),
      event_id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      context_hash: contextHash,
      data,
      error,
    });
  }

  private emitError(error: unknown): void {
    this.emit("assistant.error", "", {}, {
      detail: error instanceof TypeError
        ? "The backend connection was interrupted. This run is durable; reconnect or reopen this chat to see its current result."
        : error instanceof Error ? error.message : "Migration Agent request failed",
      code: error instanceof TypeError ? "migration_agent_transport_error" : "migration_agent_error",
    });
  }
}
