/** Browser read caches are scoped to verified identity, never cookie presence. */
let identity: string | null = null;
let revision = 0;
const listeners = new Set<() => void>();
const sessionFailureListeners = new Set<(error: unknown) => void>();
export function onSessionFailure(listener: (error: unknown) => void) {
  sessionFailureListeners.add(listener);
  return () => { sessionFailureListeners.delete(listener); };
}
export function reportSessionFailure(error: unknown) {
  sessionFailureListeners.forEach(listener => { try { listener(error); } catch { /* Isolated consumers. */ } });
}
export const cacheScope = () => identity;
export const cacheRevision = () => revision;
export function onCacheIdentityChange(listener: () => void) { listeners.add(listener); }
export function setCacheIdentity(next: string | null) {
  if (identity === next && next !== null) return;
  identity = next; revision++;
  listeners.forEach(listener => { try { listener(); } catch { /* Storage is optional; identity fencing remains active. */ } });
}
export function scopedStorageKey(key: string) {
  return `${key}:identity:${encodeURIComponent(identity ?? 'unverified')}`;
}
