'use client';

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';

import { listProjectAttributes } from '@/services/projectService';
import type { ProjectAttributeRecord } from '@/services/projectService';

import {
  filterAttributesForProject,
  normalizeProjectAttributeRecords,
  STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT,
} from './project-attribute-utils';

export function useProjectAttributes(projectId: string | null | undefined) {
  const [attributes, setAttributes] = useState<ProjectAttributeRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const lastSuccessfulRead = useRef(0);
  const [loadedProject, setLoadedProject] = useState<string | null>(null);
  const currentProject = useRef(projectId);
  useLayoutEffect(() => { currentProject.current = projectId; }, [projectId]);
  const requestSequence = useRef(0);

  const reloadProjectAttributes = useCallback(async () => {
    const sequence = ++requestSequence.current;
    const normalizedProjectId = projectId?.trim();
    if (!normalizedProjectId) {
      setAttributes([]);
      setIsLoading(false);
      setLoadedProject(null);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const records = await listProjectAttributes(normalizedProjectId);
      if (currentProject.current?.trim() !== normalizedProjectId || sequence !== requestSequence.current) return;
      lastSuccessfulRead.current = Date.now();
      setAttributes(
        filterAttributesForProject(
          normalizeProjectAttributeRecords(records, normalizedProjectId),
          normalizedProjectId,
        ),
      );
    } catch {
      if (currentProject.current?.trim() === normalizedProjectId && sequence === requestSequence.current) {
        setError('Project values could not be refreshed. Displayed values may be stale; SQL compilation reloads authoritative values.');
      }
    } finally {
      if (sequence === requestSequence.current && currentProject.current?.trim() === normalizedProjectId) {
        setIsLoading(false);
        setLoadedProject(normalizedProjectId);
      }
    }
  }, [projectId]);

  useEffect(() => {
    setAttributes([]);
    setError(null);
    lastSuccessfulRead.current = 0;
    void reloadProjectAttributes();
  }, [reloadProjectAttributes]);

  useEffect(() => {
    const normalizedProjectId = projectId?.trim();
    if (!normalizedProjectId) {
      return;
    }

    const handleAttributesChanged = (event: Event) => {
      const detail = (event as CustomEvent<{ projectId?: string }>).detail;
      if (!detail?.projectId || detail.projectId === normalizedProjectId) {
        void reloadProjectAttributes();
      }
    };

    const handleWindowFocus = () => {
      if (Date.now() - lastSuccessfulRead.current >= 30_000) void reloadProjectAttributes();
    };

    window.addEventListener(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, handleAttributesChanged);
    window.addEventListener('focus', handleWindowFocus);

    return () => {
      window.removeEventListener(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, handleAttributesChanged);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [projectId, reloadProjectAttributes]);

  const projectAttributes = useMemo(() => filterAttributesForProject(attributes, projectId), [attributes, projectId]);
  return {
    projectAttributes,
    isLoadingProjectAttributes: isLoading || Boolean(projectId?.trim() && loadedProject !== projectId.trim()),
    projectAttributesError: error,
    reloadProjectAttributes,
  };
}
