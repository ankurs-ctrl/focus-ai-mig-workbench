'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import type { SxProps, Theme } from '@mui/material/styles';

import { AiaBox, AiaIconButton, AiaSelect } from '@/components/ui';
import { AiaInput } from '@/components/ui/aia-input';
import { AiaText } from '@/components/ui/aia-text';
import { CloseRoundedIcon, SearchRoundedIcon } from '@/utils/icons';
import {
  MAPPING_TABLE_FILTER_INPUT_SX,
  MAPPING_TABLE_FILTER_SELECT_SX,
  MAPPING_TABLE_HEADER_ROW_HEIGHT,
} from './mapping-table-styles';

type MappingHeaderSearchLabelProps = {
  title: ReactNode;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  mode?: 'text' | 'select';
  options?: Array<{ label: string; value: string }>;
  sx?: SxProps<Theme>;
};

const ICON_BUTTON_SX = {
  width: 36,
  height: 36,
  p: 0,
  color: '#475569',
  flexShrink: 0,
  border: '1px solid #cbd5e1',
  borderRadius: '8px',
  bgcolor: 'transparent',
  '&:hover': {
    color: '#0f172a',
    borderColor: '#94a3b8',
    bgcolor: 'rgba(15, 23, 42, 0.04)',
  },
} as const;

const ACTIVE_ICON_BUTTON_SX = {
  ...ICON_BUTTON_SX,
  color: 'var(--aia-primary-bg-color)',
  borderColor: 'color-mix(in srgb, var(--aia-primary-bg-color) 45%, #cbd5e1)',
  bgcolor: 'color-mix(in srgb, var(--aia-primary-bg-color) 8%, #fff)',
  '&:hover': {
    color: 'var(--aia-primary-bg-color)',
    borderColor: 'var(--aia-primary-bg-color)',
    bgcolor: 'color-mix(in srgb, var(--aia-primary-bg-color) 12%, #fff)',
  },
} as const;

const CLOSE_ICON_BUTTON_SX = {
  width: 30,
  height: 30,
  p: 0,
  mr: 0.5,
  color: '#64748b',
  flexShrink: 0,
  border: 'none',
  borderRadius: '6px',
  bgcolor: 'transparent',
  '&:hover': {
    color: '#0f172a',
    bgcolor: 'rgba(15, 23, 42, 0.06)',
  },
} as const;

const HEADER_FILTER_CONTROL_HEIGHT = 40;

const FILTER_FIELD_SHELL_SX = {
  display: 'flex',
  alignItems: 'center',
  width: '100%',
  minWidth: 0,
  height: HEADER_FILTER_CONTROL_HEIGHT,
  minHeight: HEADER_FILTER_CONTROL_HEIGHT,
  border: '1px solid #e5e7eb',
  borderRadius: '6px',
  bgcolor: '#fff',
  overflow: 'hidden',
  '&:focus-within': {
    borderColor: 'var(--aia-primary-bg-color)',
  },
} as const;

export function MappingHeaderSearchLabel({
  title,
  value,
  onChange,
  placeholder = 'Search...',
  mode = 'text',
  options = [],
  sx,
}: MappingHeaderSearchLabelProps) {
  const [expanded, setExpanded] = useState(false);
  const expandedAreaRef = useRef<HTMLDivElement | null>(null);
  const hasFilter = Boolean(value.trim());

  useEffect(() => {
    if (!expanded) return undefined;

    let cancelled = false;
    const focusInput = () => {
      if (cancelled) return;
      const input = expandedAreaRef.current?.querySelector<HTMLElement>(
        'input, [role="combobox"], .MuiSelect-select',
      );
      input?.focus?.();
    };

    // Wait until the expanded controls are committed to the DOM.
    const timer = window.setTimeout(focusInput, 0);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [expanded]);

  return (
    <AiaBox
      sx={[
        {
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 1,
          width: '100%',
          minWidth: 0,
          minHeight: MAPPING_TABLE_HEADER_ROW_HEIGHT - 8,
          position: 'relative',
          overflow: 'hidden',
        },
        ...(sx ? (Array.isArray(sx) ? sx : [sx]) : []),
      ]}
    >
      {!expanded ? (
        <>
          <AiaBox
            sx={{
              flex: 1,
              minWidth: 0,
              display: 'flex',
              alignItems: 'center',
              overflow: 'visible',
              mr: 1,
            }}
          >
            {typeof title === 'string' ? (
              <AiaText
                component="span"
                sx={{
                  fontSize: 'inherit',
                  fontWeight: 'inherit',
                  color: 'inherit',
                  lineHeight: 'inherit',
                  whiteSpace: 'nowrap',
                  overflow: 'visible',
                }}
              >
                {title}
              </AiaText>
            ) : (
              title
            )}
          </AiaBox>
          <AiaIconButton
            size="small"
            aria-label="Open column search"
            onClick={() => setExpanded(true)}
            sx={hasFilter ? ACTIVE_ICON_BUTTON_SX : ICON_BUTTON_SX}
          >
            <SearchRoundedIcon sx={{ fontSize: 18 }} />
          </AiaIconButton>
        </>
      ) : (
        <AiaBox
          ref={expandedAreaRef}
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 0.5,
            width: '100%',
            minWidth: 0,
            animation: 'mappingHeaderSearchExpand 180ms ease',
            transformOrigin: 'right center',
            '@keyframes mappingHeaderSearchExpand': {
              from: {
                opacity: 0.4,
                transform: 'translateX(12px)',
              },
              to: {
                opacity: 1,
                transform: 'translateX(0)',
              },
            },
          }}
        >
          <AiaBox sx={FILTER_FIELD_SHELL_SX}>
            {mode === 'select' ? (
              <AiaSelect
                label=""
                value={value}
                options={options}
                onChange={(next) => onChange(Array.isArray(next) ? next[0] ?? '' : next)}
                placeholder={placeholder}
                size="small"
                fullWidth
                sx={{
                  ...MAPPING_TABLE_FILTER_SELECT_SX,
                  flex: 1,
                  minWidth: 0,
                  height: '100%',
                  '& .MuiOutlinedInput-root, &.MuiInputBase-root': {
                    minHeight: '100%',
                    height: '100%',
                    bgcolor: 'transparent',
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    border: 'none',
                  },
                  '& .MuiSelect-select': {
                    py: '10px !important',
                    pl: '10px !important',
                    pr: '28px !important',
                    fontSize: '0.82rem',
                  },
                }}
              />
            ) : (
              <AiaInput
                value={value}
                onChange={onChange}
                placeholder={placeholder}
                size="small"
                fullWidth
                inputProps={{ 'aria-label': placeholder }}
                sx={{
                  ...MAPPING_TABLE_FILTER_INPUT_SX,
                  flex: 1,
                  minWidth: 0,
                  height: '100%',
                  '& .MuiOutlinedInput-root': {
                    minHeight: '100%',
                    height: '100%',
                    bgcolor: 'transparent',
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    border: 'none',
                  },
                  '& .MuiInputBase-input': {
                    py: '10px !important',
                    pl: '10px !important',
                    pr: '4px !important',
                    fontSize: '0.82rem',
                  },
                }}
              />
            )}
            <AiaIconButton
              size="small"
              aria-label="Close column search"
              onClick={() => setExpanded(false)}
              sx={CLOSE_ICON_BUTTON_SX}
            >
              <CloseRoundedIcon sx={{ fontSize: 18 }} />
            </AiaIconButton>
          </AiaBox>
        </AiaBox>
      )}
    </AiaBox>
  );
}
