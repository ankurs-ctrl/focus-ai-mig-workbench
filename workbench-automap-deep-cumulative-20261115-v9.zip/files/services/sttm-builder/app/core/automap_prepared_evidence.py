"""Server-owned Auto-map evidence reused by screen preparation and dispatch.

A matching client hash never grants reuse: only access-checked hydration or an
owner-scoped durable job can construct the trusted in-memory marker.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import time

VERSION = 'prepared-automap-v2'


def evidence_inputs(workspace):
    value = workspace.model_dump(mode='json') if hasattr(workspace, 'model_dump') else workspace
    value = value or {}
    keys = ('project_id', 'sttm_id', 'source_tables', 'target_table', 'selected_columns_by_table',
            'derived_sources', 'relationships', 'relation_graph', 'driving_table',
            'driving_relation_id', 'mapping_intent', 'filters', 'raw_mapping_sql')
    result = {key: deepcopy(value.get(key)) for key in keys}
    # Legacy authored SQL can live in mapping_sql. Generated SQL is not an evidence input.
    result['legacy_authored_sql'] = value.get('mapping_sql') if value.get('mapping_sql') != value.get('compiled_mapping_sql') else None
    result['target_contracts'] = [{key: row.get(key) for key in ('target_column', 'target_type')}
                                  for row in value.get('mapping_rows') or []]
    return result


def revision(workspace):
    return hashlib.sha256(json.dumps(evidence_inputs(workspace), sort_keys=True,
        separators=(',', ':'), ensure_ascii=False, default=str).encode()).hexdigest()


@dataclass(frozen=True)
class TrustedPreparedAutoMap:
    body: dict

    def __post_init__(self):
        from app.core.automap_stored_json import load_stored
        object.__setattr__(self, 'body', load_stored(self.body))


def trusted(req):
    marker = getattr(req.context, '_prepared_automap', None)
    if not isinstance(marker, TrustedPreparedAutoMap):
        return None
    body = marker.body
    if body.get('version') != VERSION or body.get('input_revision') != revision(req.context.workspace_context):
        return None
    discovery = (body.get('evidence_index') or {}).get('targets') or body.get('discovery') or {}
    from app.core.automap_retrieval import target_name
    if not all(target_name(item.target_attribute) in discovery for item in req.data.attributes or []):
        return None
    return body


def reuse(req):
    body = trusted(req)
    if body is None:
        return None
    from app.schema.sttm_builder import LearningContext
    from app.core.automap_policy import preparation_hash
    saved = {item['target_attribute']:item for item in body.get('target_requirements', [])}
    attributes = [item.model_copy(update={'target_description':saved.get(item.target_attribute, {}).get('target_description')})
        if not item.target_description and saved.get(item.target_attribute, {}).get('target_description') else item
        for item in req.data.attributes or []]
    context = req.context.model_copy(update={'learning_context': LearningContext.model_validate(body['learning'])})
    context.prepared_context_hash = preparation_hash(context)
    return req.model_copy(update={'context': context, 'data':req.data.model_copy(update={'attributes':attributes}), 'meta': {**req.meta,
        'learning_context_prepared': True, 'automap_prepared_revision': body['input_revision'],
        'context_diagnostics': {'cache_source': 'prepared_workspace',
            'timings_ms': {'semantic_refresh': 0, 'precedent_and_fir_retrieval': 0}}}})


def build(*, workspace, semantic_context, target_columns, session, settings, learning_service):
    """Use the existing discovery policy once for all screen targets; no models."""
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from app.core.sttm_builder import STTMBuilderService
    from app.core.automap_retrieval import target_name
    started = time.perf_counter()
    semantic_context = semantic_context or []
    descriptions = {}
    for item in semantic_context:
        table = item.get('table') or {}
        if workspace.target_table and '.'.join(str(table.get(k) or '') for k in ('database','schema','table')).upper() == workspace.target_table.qualified_name.upper():
            for column in (item.get('semantic_model') or {}).get('attributes') or []:
                descriptions[str(column.get('name') or '').upper()] = column
    attributes = []
    for name in target_columns:
        column = descriptions.get(name.upper(), {})
        attributes.append({'target_attribute': name, 'target_table': workspace.target_table.model_dump(mode='json'),
            'target_data_type': column.get('data_type'), 'target_description': column.get('description')})
    request = STTMBuilderEnvelopeRequest.model_validate({'contract_version':'1.0','request_id':'workspace-preparation',
        'operation':'sttm.auto_map','data':{'intent':'AUTO_MAP','attributes':attributes},
        'context':{'project_id':workspace.project_id,'sttm_id':workspace.sttm_id,
            'source_tables':[t.model_dump(mode='json') for t in workspace.source_tables],
            'target_table':workspace.target_table.model_dump(mode='json'),
            'selected_columns_by_table':workspace.selected_columns_by_table,
            'workspace_context':workspace.model_dump(mode='json'), 'relation_graph':workspace.relation_graph,
            'mapping_intent':workspace.mapping_intent,'semantic_context':semantic_context},
        'meta':{'automap_generation_policy':'draft-v3','auto_map_fast_path':'v1'}})
    learning = learning_service.get_auto_map_context(project_id=str(workspace.project_id or ''),
        sttm_id=workspace.sttm_id, target_columns=target_columns, target_table=workspace.target_table.qualified_name)
    request.context.learning_context = learning
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._session = service._query_session = session
    service._settings = settings
    discovery = service._discover_auto_map_batch_evidence(request, [target_name(name) for name in target_columns])
    from app.core.automap_packet_policy import catalog_index, source_planning_input
    index = catalog_index(source_planning_input(request))
    return {'version':VERSION,'input_revision':revision(workspace), 'catalog_index':index,
        'learning':learning.model_dump(mode='json'),'evidence_index':indexed_discovery(discovery),
        'target_requirements':attributes,
        'preparation_ms':round((time.perf_counter()-started)*1000,2)}


def indexed_discovery(discovery):
    """Retain each complete evidence body once, with target/category references."""
    from app.core.automap_retrieval import digest, encoded
    records, targets = {}, {}
    for target, item in discovery.items():
        value = deepcopy(item)
        categories = value.pop('evidence', {})
        references = {}
        for category, entries in categories.items():
            ids = []
            for entry in entries:
                identity = 'prepared-evidence:' + digest(entry)
                if identity not in records:
                    text = encoded(entry)
                    records[identity] = {'body': deepcopy(entry), 'chars':len(text), 'bytes':len(text.encode('utf-8'))}
                ids.append(identity)
            references[category] = ids
        targets[target] = {**value, 'evidence_refs':references}
    return {'version':'automap-evidence-index-v1', 'records':records, 'targets':targets}


def discovery_for(body, targets):
    index = body.get('evidence_index')
    if not isinstance(index, dict) or index.get('version') != 'automap-evidence-index-v1':
        return {target:deepcopy(body['discovery'][target]) for target in targets}
    result = {}
    for target in targets:
        value = deepcopy(index['targets'][target])
        references = value.pop('evidence_refs')
        value['evidence'] = {category:[deepcopy(index['records'][identity]['body']) for identity in ids]
                             for category, ids in references.items()}
        result[target] = value
    return result
