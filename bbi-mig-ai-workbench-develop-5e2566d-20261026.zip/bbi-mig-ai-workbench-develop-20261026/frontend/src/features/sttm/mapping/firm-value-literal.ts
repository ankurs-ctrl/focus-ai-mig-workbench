import type { ProjectAttributeRecord } from '@/services/projectService';

const NUMERIC_FIRM_VALUE_TYPES = new Set(['INT', 'BIGINT', 'NUMBER', 'DECIMAL', 'FLOAT', 'DOUBLE']);

/**
 * SQL literal for a firm value, inserted when it is clicked: numbers as-is, booleans as
 * TRUE/FALSE, everything else single-quoted (with embedded quotes escaped).
 */
export function firmValueLiteral(value: string | null | undefined, type: string | null | undefined) {
  const raw = String(value ?? '').trim();
  const baseType = String(type ?? '').trim().toUpperCase().split('(')[0];
  if (NUMERIC_FIRM_VALUE_TYPES.has(baseType) && raw !== '' && Number.isFinite(Number(raw))) {
    return raw;
  }
  if (baseType === 'BOOLEAN' && /^(true|false)$/i.test(raw)) {
    return raw.toUpperCase();
  }
  return `'${String(value ?? '').replace(/'/g, "''")}'`;
}

/** Matches the literal as a whole token, capturing the preceding character. */
export function firmValueLiteralPattern(literal: string, flags = '') {
  const escaped = literal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^A-Za-z0-9_.'])${escaped}(?![A-Za-z0-9_.'])`, flags);
}

/** Names of the firm values whose literal appears in a pre-processing expression. */
export function firmValueNamesInExpression(
  expression: string | null | undefined,
  firmValues: ProjectAttributeRecord[],
): string[] {
  if (!expression?.trim() || !firmValues.length) return [];
  return firmValues
    .filter((attribute) =>
      firmValueLiteralPattern(firmValueLiteral(attribute.attribute_value, attribute.attribute_type)).test(expression),
    )
    .map((attribute) => attribute.attribute_name);
}
