#!/usr/bin/env python3
"""Drive a Deep Agent migration run end to end through the backend API only.

The harness creates (or attaches to) a durable run, answers blocking review
items from a scripted answers policy, and records deterministic metrics from
the run's persisted events so every phase can be compared with the baseline.

Example:
    python scripts/deep_agent_e2e.py \
        --prompt-file scripts/e2e/tmd_ten_targets.prompt.txt \
        --answers scripts/e2e/tmd_ten_targets.answers.json --effort medium
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = REPO_ROOT / "services" / "sttm-builder"
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from app.agent_runs.run_metrics import summarize_run  # noqa: E402

TERMINAL = {"COMPLETED", "READY_FOR_REVIEW", "COMPLETED_WITH_REVIEW_ITEMS", "NEEDS_REVIEW",
            "FAILED", "CANCELLED", "EXPIRED"}
AWAITING = {"AWAITING_INPUT", "AWAITING_CONFIRMATION"}


class ApiError(RuntimeError):
    def __init__(self, status: int, body: str) -> None:
        super().__init__(f"HTTP {status}: {body[:800]}")
        self.status = status
        self.body = body


class RunsApi:
    def __init__(self, base_url: str, timeout: float) -> None:
        self._root = base_url.rstrip("/") + "/api/v1"
        self._base = self._root + "/agent-runs"
        self._timeout = timeout

    def _call(self, method: str, path: str, body: dict[str, Any] | None = None, *, root: bool = False) -> Any:
        data = json.dumps(body).encode("utf-8") if body is not None else None
        request = urllib.request.Request(
            (self._root if root else self._base) + path, data=data, method=method,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=self._timeout) as response:
                payload = json.loads(response.read().decode("utf-8") or "{}")
        except urllib.error.HTTPError as exc:
            raise ApiError(exc.code, exc.read().decode("utf-8", "replace")) from exc
        return payload.get("data", payload) if isinstance(payload, dict) else payload

    def create(self, body: dict[str, Any]) -> dict[str, Any]:
        return self._call("POST", "", body)

    def create_conversation(self, body: dict[str, Any]) -> dict[str, Any]:
        return self._call("POST", "/assistant-conversations", body, root=True)

    def submit_turn(self, conversation_id: str, body: dict[str, Any]) -> dict[str, Any]:
        return self._call("POST", f"/assistant-conversations/{conversation_id}/turns", body, root=True)

    def state(self, run_id: str) -> dict[str, Any]:
        return self._call("GET", f"/{run_id}")

    def events(self, run_id: str, after: int) -> list[dict[str, Any]]:
        return list(self._call("GET", f"/{run_id}/events?after={after}") or [])

    def answer(self, run_id: str, body: dict[str, Any]) -> dict[str, Any]:
        return self._call("POST", f"/{run_id}/answer", body)

    def resume(self, run_id: str, revision: int, key: str) -> dict[str, Any]:
        return self._call("POST", f"/{run_id}/resume", {"idempotency_key": key, "expected_revision": revision})

    def cancel(self, run_id: str, reason: str) -> dict[str, Any]:
        return self._call("POST", f"/{run_id}/cancel", {"reason": reason})


class AnswerPolicy:
    """Scripted user replies. Rules are tried in order; the first match wins.

    File format::

        {"default": "recommended" | "stop",
         "rules": [{"category": "source_join_path",
                    "question": "CONTACT_FAMILIES connect to",   # regex, case-insensitive
                    "answer": "A.ID = B.A_ID"}                    # free-text answer
                   {"question": "...", "choice": "CONTACTS.ID = X"}  # regex on choice label
                   {"question": "...", "choice": "recommended"}]}
    """

    def __init__(self, spec: dict[str, Any]) -> None:
        self.default = str(spec.get("default") or "stop").lower()
        if self.default not in {"recommended", "stop"}:
            raise ValueError("answers.default must be 'recommended' or 'stop'")
        # Accept the agent's own recommendation before any scripted rule; the
        # rules then only answer questions the agent could not decide.
        self.prefer_recommended = bool(spec.get("prefer_recommended"))
        self.rules = list(spec.get("rules") or [])

    @staticmethod
    def _recommended(item: dict[str, Any]) -> dict[str, Any] | None:
        choices = list(item.get("choices") or [])
        wanted = item.get("recommended_choice_id")
        for choice in choices:
            if wanted and choice.get("choice_id") == wanted:
                return choice
        return next((choice for choice in choices if choice.get("recommended")), None)

    def decide(self, item: dict[str, Any]) -> tuple[dict[str, Any] | None, str]:
        text = " ".join(str(item.get(key) or "") for key in ("question", "safe_summary"))
        if self.prefer_recommended:
            choice = self._recommended(item)
            if choice is not None:
                return {"choice_id": choice["choice_id"]}, f"agent recommendation ('{choice.get('label')}')"
        for index, rule in enumerate(self.rules):
            if rule.get("category") and rule["category"] != item.get("category"):
                continue
            if rule.get("question") and not re.search(rule["question"], text, re.I):
                continue
            if "answer" in rule:
                return {"answer": str(rule["answer"])}, f"rule {index} (free text)"
            wanted = str(rule.get("choice") or "")
            if wanted.lower() == "recommended":
                choice = self._recommended(item)
            else:
                choice = next((value for value in item.get("choices") or []
                               if re.search(wanted, str(value.get("label") or ""), re.I)), None)
            if choice is None:
                return None, f"rule {index} matched but no choice matched '{wanted}'"
            return {"choice_id": choice["choice_id"]}, f"rule {index} (choice '{choice.get('label')}')"
        if self.default == "recommended":
            choice = self._recommended(item)
            if choice is not None:
                return {"choice_id": choice["choice_id"]}, f"default recommended ('{choice.get('label')}')"
        return None, "no rule matched"


def _now() -> str:
    return datetime.now(UTC).strftime("%H:%M:%S")


def _log(message: str) -> None:
    print(f"[{_now()}] {message}", flush=True)


def _pending_questions(state: dict[str, Any]) -> list[dict[str, Any]]:
    return [item for item in state.get("review_items") or []
            if str(item.get("status") or "").upper() == "OPEN" and item.get("interrupt_id")]


def _question_key(item: dict[str, Any]) -> str:
    return f"{item.get('category')}|{item.get('question') or item.get('safe_summary')}"


def run(args: argparse.Namespace) -> int:
    api = RunsApi(args.base_url, args.http_timeout)
    policy = AnswerPolicy(json.loads(Path(args.answers).read_text(encoding="utf-8"))) if args.answers \
        else AnswerPolicy({"default": "stop"})

    conversation_id: str | None = None
    if args.run_id:
        run_id = args.run_id
        _log(f"Attaching to run {run_id}")
    else:
        prompt = Path(args.prompt_file).read_text(encoding="utf-8").strip() if args.prompt_file else args.prompt
        if not prompt:
            raise SystemExit("--prompt, --prompt-file or --run-id is required")
        page_context = {"page": "builder", "surface": "SOURCE_SELECTION"}
        key = f"e2e-{int(time.time())}"
        if args.direct_run:
            body: dict[str, Any] = {"prompt": prompt, "effort": args.effort,
                                    "page_context": page_context, "idempotency_key": key}
            if args.precedent_project:
                body["precedent_project_ids"] = list(args.precedent_project)
            run_id = api.create(body)["run_id"]
            _log(f"Created run {run_id} (not linked to a conversation)")
        else:
            # Same path as the browser: a Deep conversation plus a user turn, so
            # the run, its questions, answers, steps and SQL appear in History.
            # --conversation-id posts a follow-up turn into an existing one.
            if args.conversation_id:
                conversation_id = args.conversation_id
            else:
                conversation = api.create_conversation({"mode": "deep", "title": args.title or None,
                                                        "idempotency_key": f"{key}-conversation"})
                conversation_id = conversation["conversation_id"]
            if args.precedent_project:
                _log("--precedent-project is only sent with --direct-run; the conversation path ignores it")
            turn = api.submit_turn(conversation_id, {
                "message": prompt, "effort": args.effort, "page_context": page_context,
                "idempotency_key": key, **({"run_mode": args.run_mode} if args.run_mode else {}),
            })
            if not turn.get("run"):
                raise SystemExit(f"Turn did not start a run (execution_path={turn.get('execution_path')}): "
                                 f"{turn.get('message')}")
            run_id = turn["run"]["run_id"]
            _log(f"Conversation {conversation_id} (visible in UI History) started run {run_id}")

    events: list[dict[str, Any]] = []
    cursor = 0
    answered: dict[str, str] = {}
    asked_counts: dict[str, int] = {}
    answer_log: list[dict[str, Any]] = []
    resumes_requested = 0
    stop_reason = ""
    started = time.monotonic()
    state: dict[str, Any] = {}

    while True:
        try:
            batch = api.events(run_id, cursor)
        except (ApiError, OSError) as exc:
            _log(f"Event read failed, retrying: {exc}")
            batch = []
        for event in batch:
            events.append(event)
            cursor = max(cursor, int(event.get("sequence") or 0))
            if args.verbose:
                _log(f"#{event.get('sequence')} {event.get('event_type')} [{event.get('status')}] "
                     f"{str(event.get('safe_summary') or '')[:160]}")
        try:
            state = api.state(run_id)
        except (ApiError, OSError) as exc:
            _log(f"State read failed, retrying: {exc}")
            time.sleep(args.poll)
            continue
        status = str(state["run"]["status"]).upper()

        if status in AWAITING:
            for item in _pending_questions(state):
                item_id = item["review_item_id"]
                if item_id in answered:
                    continue
                key = _question_key(item)
                asked_counts[key] = asked_counts.get(key, 0) + 1
                if asked_counts[key] > args.max_repeat:
                    stop_reason = f"question repeated {asked_counts[key]} times: {key}"
                    break
                reply, why = policy.decide(item)
                _log(f"Question [{item.get('category')}]: {item.get('question') or item.get('safe_summary')}")
                if item.get("category") == "plan_approval":
                    # The full plan travels on the approval event; the review item holds only the digest.
                    approval = next((dict(e.get("data") or e.get("event_data") or {}) for e in reversed(events)
                                     if e.get("event_type") == "plan.approval_required"
                                     and (e.get("data") or e.get("event_data") or {}).get("review_item_id") == item_id), {})
                    plan = dict(approval.get("plan") or {})
                    writes = plan.get("planned_writes") or []
                    specs = plan.get("mapping_specs") or []
                    _log(f"  plan: revision {plan.get('revision') or item.get('artifact_revision')} "
                         f"hash {str(plan.get('plan_hash') or item.get('action_digest') or '')[:12]} "
                         f"targets {len(specs)} writes {len(writes)} evidence {len(plan.get('evidence_refs') or [])} "
                         f"steps {len(plan.get('execution_steps') or [])}")
                    for spec in specs[:12]:
                        prep = dict(spec.get("source_preparation") or {})
                        _log(f"    target {spec.get('target_table')}: driving {prep.get('driving_source')} "
                             f"+{len(prep.get('supporting_sources') or [])} sources, "
                             f"depends on {[d.get('target_table') or d.get('mapping_key') for d in spec.get('dependencies') or []]}")
                if reply is None:
                    stop_reason = f"unanswerable question ({why}): {key}"
                    break
                body = {"review_item_id": item_id, "interrupt_id": item.get("interrupt_id"),
                        "action_digest": item.get("action_digest"),
                        "artifact_revision": item.get("artifact_revision"),
                        "idempotency_key": f"e2e-{item_id}", **reply}
                try:
                    api.answer(run_id, body)
                except ApiError as exc:
                    _log(f"Answer rejected: {exc}")
                    stop_reason = f"answer rejected for {item_id}: HTTP {exc.status}"
                    break
                answered[item_id] = why
                answer_log.append({"review_item_id": item_id, "category": item.get("category"),
                                   "question": item.get("question"), "reply": reply, "policy": why,
                                   "at": datetime.now(UTC).isoformat()})
                _log(f"  -> answered via {why}")
            if stop_reason:
                break
        elif status in TERMINAL:
            if status == "FAILED" and resumes_requested < args.max_resumes:
                resumes_requested += 1
                _log(f"Run FAILED ({state['run'].get('error_code')}); requesting resume {resumes_requested}")
                try:
                    api.resume(run_id, int(state["run"].get("run_revision") or 0), f"e2e-resume-{resumes_requested}")
                except ApiError as exc:
                    stop_reason = f"resume rejected: {exc}"
                    break
            else:
                # Drain trailing events persisted just after the terminal state.
                time.sleep(args.poll)
                for event in api.events(run_id, cursor):
                    events.append(event)
                    cursor = max(cursor, int(event.get("sequence") or 0))
                state = api.state(run_id)
                stop_reason = f"terminal status {status}"
                break

        if time.monotonic() - started > args.timeout:
            stop_reason = f"harness timeout after {args.timeout}s in status {status}"
            if args.cancel_on_timeout:
                api.cancel(run_id, "E2E harness timeout")
            break
        time.sleep(args.poll)

    summary = summarize_run(state.get("run") or {"run_id": run_id}, events, state.get("review_items") or [])
    report = {
        "run_id": run_id,
        "conversation_id": conversation_id,
        "stop_reason": stop_reason,
        "harness_seconds": round(time.monotonic() - started, 1),
        "answers": answer_log,
        "open_review_items": [
            {"category": item.get("category"), "question": item.get("question") or item.get("safe_summary"),
             "blocking": item.get("blocking"), "subject_keys": item.get("subject_keys")}
            for item in state.get("review_items") or [] if str(item.get("status") or "").upper() == "OPEN"
        ],
        "mapping_dag": [
            {"mapping_key": node.get("mapping_key"), "target_table": node.get("target_table"),
             "status": node.get("status"), "sttm_id": node.get("sttm_id"),
             "dependencies": node.get("dependencies")}
            for node in state.get("mapping_dag") or []
        ],
        "metrics": summary,
    }
    out = Path(args.out) if args.out else REPO_ROOT / ".dev-cache" / "e2e" / f"{run_id}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")

    timing = summary["timing"]
    print("\n=== Deep Agent E2E summary ===")
    print(f"run: {run_id}  status: {summary['status']}  stop: {stop_reason}")
    print(f"project: {summary['project_id']}  sttm: {', '.join(summary['sttm_ids']) or '-'}")
    print(f"wall {timing['wall_seconds']:.0f}s | active {timing['active_seconds']:.0f}s | "
          f"waiting {timing['waiting_on_user_seconds']:.0f}s | recorded {timing['recorded_elapsed_seconds']:.0f}s")
    print(f"model calls {summary['usage']['model_calls_used']} | tool calls {summary['usage']['tool_calls_used']} | "
          f"tool failures {summary['events']['tool_failed']} | resumes {summary['resumes']}")
    reads = summary["contract_reads"]
    print(f"contract reads {reads['total']} in {reads['queries']} queries ({reads['distinct_tables']} tables, "
          f"{reads['redundant_reads']} redundant, {len(reads['tables_reread_across_segments'])} re-read after resume) "
          f"| revalidated {reads['revalidated_tables']} | conversation reuses {summary['knowledge_reuses']}")
    questions = summary["questions"]
    print(f"questions asked {questions['asked']} | open review items {questions['review_items_open']} "
          f"| by category {questions['by_category']}")
    print(f"mappings {summary['mappings']}")
    print(f"report: {out}")
    return 0 if summary["status"] in TERMINAL - {"FAILED", "CANCELLED", "EXPIRED"} else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--prompt")
    parser.add_argument("--prompt-file")
    parser.add_argument("--run-id", help="Attach to an existing run instead of creating one.")
    parser.add_argument("--effort", default="medium", choices=["auto", "light", "medium", "high"])
    parser.add_argument("--precedent-project", action="append", default=[])
    parser.add_argument("--title", help="Conversation title shown in UI History.")
    parser.add_argument("--conversation-id", help="Post the prompt as a follow-up turn in this conversation.")
    parser.add_argument("--run-mode", choices=["auto", "plan"],
                        help="plan: the run stops at the plan-approval checkpoint (answered by the answers policy).")
    parser.add_argument("--direct-run", action="store_true",
                        help="Create a bare run via /agent-runs (not visible in UI History).")
    parser.add_argument("--answers", help="JSON answers policy file.")
    parser.add_argument("--timeout", type=float, default=5400.0, help="Harness wall-clock limit in seconds.")
    parser.add_argument("--poll", type=float, default=5.0)
    parser.add_argument("--http-timeout", type=float, default=120.0)
    parser.add_argument("--max-repeat", type=int, default=2, help="Stop when the same question is asked more often.")
    parser.add_argument("--max-resumes", type=int, default=0, help="Resume a FAILED run at most this many times.")
    parser.add_argument("--cancel-on-timeout", action="store_true")
    parser.add_argument("--out")
    parser.add_argument("--verbose", action="store_true")
    return run(parser.parse_args())


if __name__ == "__main__":
    # Event text contains non-ASCII (for example "→" in join paths); a
    # redirected Windows console would otherwise crash the harness mid-run.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
