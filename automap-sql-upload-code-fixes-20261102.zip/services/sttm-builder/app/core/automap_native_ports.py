"""Snowflake-executed ports: scoped Search, existing compiler and prepared Analyst.

Imported by the staged application runtime ZIP. No browser token, fresh login,
owner-role fallback or arbitrary model-supplied resource is accepted.
"""

from types import SimpleNamespace
import json
import re
import secrets
import time
from urllib.parse import quote
from app.core.automap_native_contract import digest, encoded
from app.core.automap_native_store import namespace, plain, affected
from app.core.automap_native_tools import NativeToolError


def api(method, path, payload, *, timeout=30000):
    from app.core.automap_native_rpc import HTTP

    port = HTTP.get()
    if port is None:
        raise NativeToolError("native_same_caller_transport_unavailable")
    return port(method, path, payload, timeout=timeout)


def native_search(service, query, columns, filters, limit=12):
    parts = service.split(".")
    if len(parts) != 3 or any(
        not re.fullmatch(r"[A-Za-z_][\w$]*", part) for part in parts
    ):
        raise NativeToolError("invalid_configured_search_resource")
    path = (
        "/api/v2/databases/"
        + quote(parts[0], safe="")
        + "/schemas/"
        + quote(parts[1], safe="")
        + "/cortex-search-services/"
        + quote(parts[2], safe="")
        + ":query"
    )
    response = api(
        "POST",
        path,
        {"query": query, "columns": columns, "filter": filters, "limit": limit},
    )
    rows = response.get("results")
    if type(rows) is not list or len(rows) > limit:
        raise NativeToolError("invalid_search_response")
    return rows


def search_sources(snap, question, config):
    service = config["column_search_service"]
    # Native index contains only derived documents. The tool always applies
    # immutable request filters; Search owner rights cannot widen the roster.
    rows = native_search(
        service,
        question,
        ["BINDING_ID"],
        {
            "@and": [
                {"@eq": {"SNAPSHOT_HASH": snap["snapshot_hash"]}},
                {"@eq": {"OWNER_ID": config["owner_user"]}},
                {"@eq": {"PROJECT_ID": str(snap["request"]["context"]["project_id"])}},
            ]
        },
        16,
    )
    return [
        str(row["BINDING_ID"])
        for row in rows
        if row.get("BINDING_ID") in snap["sources"]
    ]


def search_precedents(session, snap, targets, question, config):
    from app.core.mapping_search import MappingSearchService
    from app.core.target_mapping_patterns import TargetMappingPatternService
    from app.core.config import Settings
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest

    settings = Settings(
        _env_file=None,
        SNOWFLAKE_DATABASE=config["metadata"].split(".")[0],
        SNOWFLAKE_SCHEMA=config["metadata"].split(".")[1],
    ).model_copy(update={"automap_hybrid_context_v1": True})

    class Search(MappingSearchService):
        def _search(self, service, query, columns, filters, diagnostics, limit=6):
            diagnostics["query_count"] += 1
            rows = native_search(service, query, columns, filters, limit)
            diagnostics["returned_hit_count"] += len(rows)
            return rows

    req = STTMBuilderEnvelopeRequest.model_validate(snap["request"])
    names = [snap["targets"][target]["name"] for target in targets]
    context = req.context
    source_tables = [table.qualified_name for table in context.source_tables]
    result = Search(session, settings).discover(
        project_id=str(context.project_id),
        sttm_id=context.sttm_id,
        target_table=context.target_table.qualified_name,
        target_columns=names,
        source_tables=source_tables,
        linked_project_ids=(
            list(context.learning_context.linked_project_ids)
            if context.learning_context
            else []
        ),
        query_refinement=question,
    )
    # Reuse canonical recipe admission, rather than accepting an index document
    # that happens to contain a matching target name.
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._session = session
    service._settings = settings
    columns, profiles, relationships, derived = service._learning_retrieval_inputs(
        req, context.target_table.qualified_name
    )
    patterns = TargetMappingPatternService(session, settings).retrieve_candidates(
        target_table=context.target_table.qualified_name,
        target_columns=names,
        source_tables=source_tables,
        source_columns=columns,
        source_column_profiles=profiles,
        relationship_paths=[
            encoded(
                item.model_dump(mode="json") if hasattr(item, "model_dump") else item
            )
            for item in relationships
        ],
        derived_outputs=[
            str(item.name) for item in derived if getattr(item, "name", None)
        ],
        workspace_context_id=context.sttm_id,
        project_id=context.project_id,
        linked_project_ids=(
            list(context.learning_context.linked_project_ids)
            if context.learning_context
            else []
        ),
        additional_pattern_ids=[
            item["pattern_id"] for item in result["evidence"] if item.get("pattern_id")
        ],
        discovered_only=True,
        hard_positive_limit=True,
        limit=2 * len(targets),
        per_column_limit=2,
        diagnostics={},
    )
    records = []
    from app.core.automap_native_contract import identifier_key

    def target_keys(value):
        keys = set()
        if isinstance(value, dict):
            for key, child in value.items():
                if key in {"target_column", "target_attribute"} and isinstance(
                    child, str
                ):
                    try:
                        keys.add(identifier_key(child))
                    except ValueError:
                        pass
                else:
                    keys.update(target_keys(child))
        elif isinstance(value, list):
            for child in value:
                keys.update(target_keys(child))
        return keys

    for pattern in patterns:
        raw = pattern.model_dump(mode="json")
        if pattern.decision == "unresolved":
            continue
        owners = [
            target
            for target in targets
            if identifier_key(snap["targets"][target]["name"]) in target_keys(raw)
        ]
        if owners:
            records.append(
                {
                    "record": raw,
                    "target_ids": owners,
                    "canonical_ids": [raw["pattern"]["pattern_id"]],
                }
            )
    for record in result["evidence"]:
        if record.get("knowledge_type") == "recipe":
            continue
        owners = [
            target
            for target in targets
            if identifier_key(snap["targets"][target]["name"])
            in {identifier_key(name) for name in record.get("target_columns", [])}
        ]
        if owners and record.get("knowledge_id"):
            records.append(
                {
                    "record": record,
                    "target_ids": owners,
                    "canonical_ids": [record["knowledge_id"]],
                }
            )
    return records


def compile_request(snap, mappings, *, explain=False):
    from app.schema.mapping_sql import MappingSqlCompileRequest
    from app.schema.sttm_builder import RelationGraphContext

    graph = RelationGraphContext.model_validate(snap["relation_graph"])
    constraints = snap["constraints"]
    modifiers = constraints.get("source_query_modifiers") or {}
    graph_modifiers = {
        key: value
        for key, value in modifiers.items()
        if key in {"having", "qualify", "distinct", "limit", "offset"}
    }
    if (
        graph.query_modifiers
        and graph_modifiers
        and graph.query_modifiers != graph_modifiers
    ):
        raise NativeToolError("source_population_modifier_conflict")
    graph = graph.model_copy(
        update={"query_modifiers": graph_modifiers or graph.query_modifiers}
    )
    from sqlglot import parse_one, exp

    # The shared compiler represents these clauses explicitly. Unsupported
    # shape-changing modifiers must fail before any proposal/data query.
    supported = {
        "where_predicates",
        "group_by_expressions",
        "qualify_predicates",
        "order_by_expressions",
        "having",
        "qualify",
        "distinct",
        "limit",
        "offset",
    }
    if any(
        value not in (None, False, [], {})
        for key, value in modifiers.items()
        if key not in supported
    ):
        raise NativeToolError("source_population_modifier_not_supported")

    def clause(name, kind):
        sql = constraints.get(name)
        if not sql:
            return []
        tree = parse_one(
            "SELECT 1 " + ("GROUP BY " if kind == "group" else "ORDER BY ") + sql,
            read="snowflake",
        )
        return [item.sql(dialect="snowflake") for item in tree.args[kind].expressions]

    groups = (
        clause("source_group_by_sql", "group")
        or modifiers.get("group_by_expressions")
        or []
    )
    orders = (
        clause("source_order_by_sql", "order")
        or modifiers.get("order_by_expressions")
        or []
    )
    where = []
    if constraints.get("source_filter_sql"):
        where.append(constraints["source_filter_sql"])
    where.extend(modifiers.get("where_predicates") or [])
    return MappingSqlCompileRequest(
        relation_graph=graph,
        mappings=mappings,
        driving_relation_id=constraints.get("driving_relation_id")
        or graph.nodes[0].relation_id,
        where_predicates=where,
        group_by_expressions=groups,
        qualify_predicates=modifiers.get("qualify_predicates") or [],
        order_by_expressions=orders,
        allow_unresolved_placeholders=False,
        validate_with_explain=explain,
    )


def compile_proposal(session, snap, target, mapping, requires_rule, config):
    from app.core.mapping_sql import MappingSqlService
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.mapping_sql import MappingSqlMappingItem
    from app.schema.sttm_builder import RelationGraphContext
    from app.core.automap_retrieval import AutoMapContext

    graph = RelationGraphContext.model_validate(snap["relation_graph"])
    driving = (
        snap["constraints"].get("driving_relation_id") or graph.nodes[0].relation_id
    )
    expression = mapping.preprocessing_rule
    refs = [
        *mapping.source_attributes,
        *mapping.source_dependencies,
        (
            expression
            if expression
            and str(mapping.preprocessing_rule_type).upper()
            not in {"DIRECT", "IDENTITY", "VALUE"}
            else None
        ),
    ]
    if STTMBuilderService._outer_source_binding_error(graph, driving, refs):
        return {"valid": False, "code": "source_scope_or_connectivity_invalid"}
    resolved = MappingSqlService._resolved_placeholder_sql(graph)
    placeholders = MappingSqlService._placeholders_in_sql(expression or "")
    if mapping.mapping_mode == "attribute":
        placeholders.add("$" + str(mapping.attribute_name).lstrip("$"))
    if any(value.upper() not in resolved for value in placeholders):
        return {"valid": False, "code": "missing_business_input"}
    if mapping.mapping_mode == "attribute":
        bindings = [
            binding
            for binding in graph.value_bindings
            if binding.value.upper()
            == ("$" + str(mapping.attribute_name).lstrip("$")).upper()
        ]
        if (
            not bindings
            or mapping.constant_value != bindings[0].value
            or not mapping.value_binding_ids
            or any(
                not any(
                    value in {binding.binding_id, binding.value} for binding in bindings
                )
                for value in mapping.value_binding_ids
            )
        ):
            return {"valid": False, "code": "invalid_value_binding"}
    if (
        expression
        and str(mapping.preprocessing_rule_type or "DIRECT").upper()
        in {"DIRECT", "IDENTITY"}
        and expression.upper() not in {"DIRECT", "IDENTITY"}
    ):
        return {"valid": False, "code": "unvalidated_direct_expression"}
    if requires_rule and not mapping.source_attributes:
        return {"valid": False, "code": "missing_selected_sources"}
    item = MappingSqlMappingItem(
        target_column=snap["targets"][target]["name"],
        target_type=snap["targets"][target]["attribute"].get("target_data_type"),
        source_columns=mapping.source_attributes,
        source_dependencies=mapping.source_dependencies,
        mapping_mode=mapping.mapping_mode,
        constant_value=mapping.constant_value,
        attribute_name=mapping.attribute_name,
        value_binding_ids=mapping.value_binding_ids,
        expression=mapping.source_attributes[0] if requires_rule else expression,
        rule=(
            "Direct"
            if requires_rule
            else str(mapping.preprocessing_rule_type or "Direct")
        ),
    )
    try:
        result = MappingSqlService(session=None, analyst_client=None).compile(
            compile_request(snap, [item])
        )
        if not result.ready or not result.valid:
            return {"valid": False, "code": "mapping_not_ready"}
        if session is not None:
            session.sql("EXPLAIN USING TEXT " + result.preview_sql).collect(
                statement_params={
                    "STATEMENT_TIMEOUT_IN_SECONDS": str(
                        config.get("validation_seconds", 10)
                    ),
                    "LOCK_TIMEOUT": "1",
                }
            )
        return {
            "valid": True,
            "compiled_hash": digest(result.canonical_preview_sql or result.preview_sql),
        }
    except Exception:
        return {
            "valid": False,
            "code": "mapping_compile_failed",
            "stage": "sql_compilation",
        }


def validate_analyst_sql(sql, view, columns):
    from sqlglot import exp, parse
    from sqlglot.optimizer.scope import traverse_scope
    from app.core.automap_native_contract import identifier_key

    statements = parse(sql, read="snowflake")
    if len(statements) != 1 or not isinstance(statements[0], exp.Query):
        raise NativeToolError("analyst_requires_one_readonly_query")
    tree = statements[0]
    if any(
        isinstance(node, (exp.Command, exp.DDL, exp.DML, exp.Anonymous, exp.Into))
        for node in tree.walk()
    ):
        raise NativeToolError("analyst_unsupported_or_side_effectful_sql")
    allowed_funcs = {
        "COUNT",
        "SUM",
        "AVG",
        "MIN",
        "MAX",
        "COALESCE",
        "NULLIF",
        "CAST",
        "TRY_CAST",
        "UPPER",
        "LOWER",
        "TRIM",
        "LENGTH",
        "ROUND",
        "ABS",
        "DATE_TRUNC",
        "DATEDIFF",
        "YEAR",
        "MONTH",
        "DAY",
        "EXTRACT",
        "IF",
        "CASE",
        "IS_NULL_VALUE",
        "ROW_NUMBER",
        "RANK",
        "DENSE_RANK",
        "REGEXP_LIKE",
        "REGEXP_REPLACE",
        "TRY_TO_DATE",
        "TO_DATE",
        "SUBSTRING",
        "CONCAT",
    }
    if any(
        isinstance(node, exp.Func) and node.sql_name() not in allowed_funcs
        for node in tree.walk()
    ):
        raise NativeToolError("analyst_function_requires_review")
    for table in tree.find_all(exp.Table):
        if any(
            value not in (None, False, [], {})
            for key, value in table.args.items()
            if key not in {"this", "db", "catalog", "alias"}
        ):
            raise NativeToolError("analyst_population_modifier_forbidden")
        alias = table.args.get("alias")
        if alias and alias.args.get("columns"):
            raise NativeToolError("analyst_output_alias_forbidden")
    normalized = tuple(part.upper() for part in view.split("."))
    for scope in traverse_scope(tree):
        for _, source in scope.sources.items():
            if (
                isinstance(source, exp.Table)
                and tuple(
                    part.name if part.args.get("quoted") else part.name.upper()
                    for part in source.parts
                )
                != normalized
            ):
                raise NativeToolError("analyst_foreign_relation")
        for column in scope.columns:
            if (
                column.name if column.this.args.get("quoted") else column.name.upper()
            ) not in columns:
                raise NativeToolError("analyst_hidden_column")
    return tree.limit(100).sql(dialect="snowflake")


class AnalystPool:
    """Separate fixed nested-call pool: avoids parent/native-permit deadlock.

    No TTL recycling. Unknown API completion quarantines the occupied slot.
    """

    def __init__(self, session, metadata, *, capacity=4):
        from app.core.automap_native_store import NativeJobStore

        self.session = session
        self.table = namespace(metadata) + ".TBL_AUTOMAP_NATIVE_ANALYST_SLOTS"
        self.transactions = NativeJobStore(session, metadata)
        self.capacity = capacity

    def sql(self, text, params=None):
        return self.session.sql(text, params=params or []).collect(
            statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "5", "LOCK_TIMEOUT": "1"}
        )

    def claim(self, handle):
        inventory = [
            plain(row)
            for row in self.sql(
                f"SELECT SLOT_ID,FENCE,STATE FROM {self.table} ORDER BY SLOT_ID"
            )
        ]
        if (
            len(inventory) != self.capacity
            or {row["SLOT_ID"] for row in inventory} != set(range(self.capacity))
            or any(
                row["STATE"] not in {"FREE", "HELD", "QUARANTINED"} for row in inventory
            )
        ):
            raise NativeToolError("analyst_pool_inventory_invalid")
        rows = [row for row in inventory if row["STATE"] == "FREE"]
        for row in rows:
            row = plain(row)
            token = secrets.token_hex(16)
            with self.transactions.transaction():
                claimed = affected(
                    self.sql(
                        f"""UPDATE {self.table} SET STATE='HELD',OWNER_TOKEN=?,OWNER_ID=CURRENT_USER(),ROLE_NAME=CURRENT_ROLE(),FENCE=FENCE+1
                    WHERE SLOT_ID=? AND FENCE=? AND STATE='FREE' AND OWNER_TOKEN IS NULL""",
                        [token, row["SLOT_ID"], row["FENCE"]],
                    )
                )
            if claimed:
                return row["SLOT_ID"], row["FENCE"] + 1, token
        raise NativeToolError("analyst_capacity_unavailable")

    def finish(self, permit, terminal):
        slot, fence, token = permit
        with self.transactions.transaction():
            if terminal:
                ok = affected(
                    self.sql(
                        f"""UPDATE {self.table} SET STATE='FREE',OWNER_TOKEN=NULL,OWNER_ID=NULL,ROLE_NAME=NULL
                  WHERE SLOT_ID=? AND FENCE=? AND OWNER_TOKEN=? AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE() AND STATE='HELD' """,
                        [slot, fence, token],
                    )
                )
            else:
                ok = affected(
                    self.sql(
                        f"""UPDATE {self.table} SET STATE='QUARANTINED' WHERE SLOT_ID=? AND FENCE=? AND OWNER_TOKEN=?
                  AND OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE() AND STATE='HELD' """,
                        [slot, fence, token],
                    )
                )
            if not ok:
                raise NativeToolError("analyst_permit_fence_failed")


def ask_analyst(session, snap, ids, question, config):
    """Compile a selected-output population view; generate, inspect, then execute.

    The original prepared bundle remains the identity/meaning authority. This
    on-demand subset projection is not a semantic refresh or source rediscovery.
    """
    import yaml
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlMappingItem

    bindings = [snap["sources"][key] for key in ids]
    mappings = [
        MappingSqlMappingItem(
            target_column="C_" + source["binding_id"][4:20].upper(),
            source_columns=[source["source_ref"]],
            rule="Direct",
        )
        for source in bindings
    ]
    compiled = MappingSqlService(session=None, analyst_client=None).compile(
        compile_request(snap, mappings)
    )
    if not compiled.ready or not compiled.valid:
        raise NativeToolError("prepared_analyst_population_unavailable")
    view = (
        namespace(config["metadata"])
        + ".AUTOMAP_POP_"
        + digest([snap["snapshot_hash"], ids])[:24].upper()
    )
    # Content-addressed, caller-owned metadata view. Never replace an existing
    # view with a different definition; views are not target-data writes.
    session.sql(
        "CREATE VIEW IF NOT EXISTS " + view + " AS " + compiled.preview_sql
    ).collect(
        statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "10", "LOCK_TIMEOUT": "1"}
    )
    rows = session.sql("SELECT GET_DDL('VIEW', ?) AS DDL", params=[view]).collect(
        statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "10", "LOCK_TIMEOUT": "1"}
    )
    # Verify the actual SELECT body (format-independent), not just object name.
    from sqlglot import parse_one, exp

    ddl = parse_one(str(plain(rows[0])["DDL"]), read="snowflake")
    actual = ddl.expression
    if actual.sql(dialect="snowflake") != parse_one(
        compiled.preview_sql, read="snowflake"
    ).sql(dialect="snowflake"):
        raise NativeToolError("prepared_population_view_changed")
    parts = view.split(".")
    model = {
        "name": "current_automap_population",
        "tables": [
            {
                "name": "POPULATION",
                "base_table": dict(zip(("database", "schema", "table"), parts)),
                "description": "Current validated source graph population; preserve original joins and filters.",
                "dimensions": [
                    {
                        "name": item.target_column,
                        "expr": item.target_column,
                        "data_type": source.get("data_type") or "VARCHAR",
                        "description": encoded(
                            {
                                "binding": source["source_ref"],
                                "semantics": snap["records"][source["evidence_id"]][
                                    "body"
                                ].get("semantics", []),
                            }
                        ),
                    }
                    for item, source in zip(mappings, bindings)
                ],
            }
        ],
    }
    model_text = yaml.safe_dump(model, sort_keys=False)
    if len(model_text.encode()) > 64000:
        raise NativeToolError("analyst_semantic_model_budget")
    pool = AnalystPool(
        session, config["metadata"], capacity=config.get("analyst_slots", 4)
    )
    permit = pool.claim(snap["snapshot_hash"])
    terminal = False
    try:
        body = api(
            "POST",
            "/api/v2/cortex/analyst/message",
            {
                "messages": [
                    {"role": "user", "content": [{"type": "text", "text": question}]}
                ],
                "semantic_model": model_text,
                "stream": False,
            },
            timeout=config.get("analyst_seconds", 30) * 1000,
        )
        message = body.get("message") if isinstance(body, dict) else None
        levels = [body, message] if isinstance(message, dict) else [body]
        statuses = [
            level["status"]
            for level in levels
            if isinstance(level, dict) and "status" in level
        ]
        supported = {"completed", "failed", "error", "timed_out", "cancelled"}
        # Analyst's synchronous contract normally has no status; a typed Analyst
        # message with a content list establishes a returned response. An explicit
        # unknown/nonterminal status always overrides that shape.
        terminal = (
            all(type(status) is str and status in supported for status in statuses)
            if statuses
            else isinstance(message, dict)
            and message.get("role") == "analyst"
            and isinstance(message.get("content"), list)
            and bool(message['content'])
        )
    finally:
        pool.finish(permit, terminal)
    if not terminal or not isinstance(body, dict):
        raise NativeToolError('analyst_completion_unknown')
    message = body.get("message")
    if type(message) is not dict or message.get('role') != 'analyst' or any(
        level.get("status", "completed") != "completed"
        or any(level.get(key) is not None for key in ("error", "error_code", "code"))
        for level in (body, message)
    ):
        raise NativeToolError("analyst_failed_or_nonterminal_envelope")
    content = message.get("content")
    if type(content) is not list or any(
        type(item) is not dict or item.get("type") not in {"text", "sql", "suggestions"}
        for item in content
    ):
        raise NativeToolError("analyst_unknown_content")
    if any(item.get("type") == "suggestions" for item in content):
        return {
            "status": "ambiguous",
            "bundle": snap["bundle"],
            "data_result_obtained": False,
        }
    sqls = [item.get("statement") for item in content if item.get("type") == "sql"]
    if len(sqls) != 1 or type(sqls[0]) is not str:
        return {
            "status": "ambiguous",
            "bundle": snap["bundle"],
            "data_result_obtained": False,
        }
    sql = validate_analyst_sql(sqls[0], view, {item.target_column for item in mappings})
    session.sql("EXPLAIN USING TEXT " + sql).collect(
        statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "10", "LOCK_TIMEOUT": "1"}
    )
    frame = session.sql(sql)
    rows = frame.collect(
        statement_params={
            "STATEMENT_TIMEOUT_IN_SECONDS": str(
                config.get("analyst_query_seconds", 15)
            ),
            "LOCK_TIMEOUT": "1",
            "QUERY_TAG": "automap_native_analyst:" + snap["snapshot_hash"][:16],
        }
    )
    query_rows = session.sql("SELECT LAST_QUERY_ID() AS QUERY_ID").collect()
    query_id = plain(query_rows[0]).get("QUERY_ID") if query_rows else None
    # Decimal/date/time/binary Snowpark values are explicit typed strings,
    # never silently lossy floats. Retain result column types for interpretation.
    from datetime import date, datetime, time as datetime_time
    from decimal import Decimal

    def value(item):
        if isinstance(item, (datetime, date, datetime_time)):
            return {"type": type(item).__name__, "value": item.isoformat()}
        if isinstance(item, Decimal):
            return {"type": "decimal", "value": str(item)}
        if isinstance(item, bytes):
            return {"type": "binary_hex", "value": item.hex()}
        if type(item) is float and not __import__("math").isfinite(item):
            return {"type": "nonfinite", "value": str(item)}
        if isinstance(item, dict):
            return {str(k): value(v) for k, v in item.items()}
        if isinstance(item, (list, tuple)):
            return [value(v) for v in item]
        return item

    values = [value(plain(row)) for row in rows[:100]]
    # Never return a SQL-generation response as if it were executed data.
    if len(encoded(values).encode()) > 8192:
        values = []
        status = "result_exceeds_budget"
    else:
        status = "executed"
    return {
        "status": status,
        "data_result_obtained": status == "executed",
        "empty_result": not rows,
        "rows": values,
        "query_id": query_id,
        "query_hash": digest(sql),
        "request_id": body.get("request_id"),
        "bundle": snap["bundle"],
        "snapshot_hash": snap["snapshot_hash"],
        "population_hash": digest(compiled.preview_sql),
        "prepared_population_view": view,
        "binding_ids": ids,
        "instruction": "Observed data behavior is not proof of an unstated business policy.",
    }
