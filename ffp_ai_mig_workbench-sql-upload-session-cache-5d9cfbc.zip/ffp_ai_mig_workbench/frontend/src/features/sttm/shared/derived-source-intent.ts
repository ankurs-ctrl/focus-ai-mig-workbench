/**
 * Derived-source (CTE) generation intent, mirrored from
 * services/sttm-builder/app/core/sttm_builder.py (_is_derived_source_generation_text).
 * Both are checked against derived-source-intent.fixture.json; word boundaries
 * keep "cte" from matching inside words such as "selected".
 */
const SUBJECT = /\b(?:derived (?:source|table)s?|ctes?|common table expressions?|reusable (?:source|relation)s?)\b/;
const GENERATION = /\b(?:create|build|generate|write|save|make|implement|prepare|draft|compose)\b/;
const DIRECT =
  /\b(?:write|generate|build|create|draft|compose)\s+(?:(?:a|an|the|me|us|some|that|this|my|new)\s+)*(?:sql|query|queries|select)\b/;
const EXPLICIT = /\b(?:generate|build|create|write)\s+(?:it|this|those|them|all|now)\b/;
// "which" asks for advice only when it opens a question, not in "a CTE which joins".
const RECOMMEND = /\b(?:advice|advise|recommend\w*|best|what should)\b|(?:^|[.?!]\s*)which\b/;
const MIGRATION = /\b(?:reusable household[- ]level source|reusable source for|migration source)\b/;
const MIGRATION_VERB = /\b(?:prepare|create|build|generate|make)\b/;
const THOSE = /\b(?:generate|build|create)\s+those\b/;

export function isDerivedSourceGenerationText(raw: string): boolean {
  const text = raw.toLowerCase().split(/\s+/).filter(Boolean).join(" ");
  const direct = DIRECT.test(text);
  if (RECOMMEND.test(text) && !(direct || EXPLICIT.test(text))) return false;
  if (direct) return true;
  if (MIGRATION.test(text) && MIGRATION_VERB.test(text)) return true;
  if (SUBJECT.test(text) && GENERATION.test(text)) return true;
  return THOSE.test(text);
}
