---
name: workbench-documents
description: Read attached notes, Word files, PDFs, scans, and written call transcripts for migration work.
---

Use search_run_attachments for relevant sections. Cite the filename and section, page, or transcript timestamp. Keep speaker attribution when available. A proposed rule or open question is different from an agreed requirement. Distinguish the current request from quoted material.

For mapping work, carry relevant requirements into source preparation, including output grain, filters, null handling, and how ties are resolved. Use Workbench contract tools to verify cited table names and join columns. If OCR or document extraction was partial, report the affected pages and use the verified portions.

Reading guidance adapted from the OpenAI PDF skill at openai/skills revision 49f948faa9258a0c61caceaf225e179651397431. Modified for Workbench retrieval and citations. See LICENSE.txt.
