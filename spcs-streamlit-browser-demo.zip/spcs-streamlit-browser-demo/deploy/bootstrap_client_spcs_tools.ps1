param(
    [string]$PythonExe = "",
    [string]$SnowflakeCliVersion = ""
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

# Purpose:
# - create a small local tools virtualenv just for deployment utilities
# - install Snowflake CLI into that virtualenv
# - verify Docker is available before the user starts the deploy flow

$bundleRoot = Get-BundleRoot
$toolsVenv = Get-ToolsVenvPath
$pythonCmd = Resolve-Python -Preferred $PythonExe

$versionCheck = @'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10+ is required for the client deployment tools.")
'@

$versionCheck | & $pythonCmd -

if (-not (Test-Path $toolsVenv)) {
    Write-Host "Creating tools virtualenv at $toolsVenv"
    & $pythonCmd -m venv $toolsVenv
} else {
    Write-Host "Reusing tools virtualenv at $toolsVenv"
}

$venvPython = Join-Path $toolsVenv "Scripts\python.exe"
$snowExe = Join-Path $toolsVenv "Scripts\snow.exe"

Write-Host "Upgrading pip tooling"
& $venvPython -m pip install --upgrade pip setuptools wheel

if ($SnowflakeCliVersion) {
    Write-Host "Installing snowflake-cli==$SnowflakeCliVersion"
    & $venvPython -m pip install --upgrade "snowflake-cli==$SnowflakeCliVersion"
} else {
    Write-Host "Installing latest snowflake-cli"
    & $venvPython -m pip install --upgrade snowflake-cli
}

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker is required but was not found in PATH."
}

Write-Host ""
Write-Host "Snow CLI installed successfully."
Write-Host "Snow binary: $snowExe"
& $snowExe --version
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Copy deploy\client.streamlit-demo.env.example to deploy\client.streamlit-demo.env"
Write-Host "  2. Fill the client-specific values in that env file"
Write-Host "  3. Run .\deploy\configure_client_snow_connection.ps1"
Write-Host "  4. Run .\deploy\prepare_spcs_prereqs.ps1"
Write-Host "  5. Run .\deploy\build_and_push_demo_image.ps1"
Write-Host "  6. Run .\deploy\deploy_streamlit_demo_service.ps1"
