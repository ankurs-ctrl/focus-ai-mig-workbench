'use client';
import { AiaBox } from '@/components/ui';


import { SqlEditorSurface } from '../sql-editor-surface';

export type SqlPreviewSqlBlockProps = {
  sql: string;
  emptyText?: string;
  readOnly?: boolean;
  formatOnDisplay?: boolean;
  onChange?: (sql: string) => void;
  suggestions?: string[];
};

export function SqlPreviewSqlBlock({
  sql,
  emptyText = '-- No columns mapped yet. Map columns to generate SQL.',
  readOnly = true,
  formatOnDisplay,
  onChange,
  suggestions,
}: SqlPreviewSqlBlockProps) {
  return (
    <AiaBox sx={{ minHeight: 0 }}>
      <SqlEditorSurface
        value={sql}
        readOnly={readOnly}
        formatOnDisplay={formatOnDisplay}
        onChange={onChange}
        completionCandidates={suggestions}
        compact
        emptyText={emptyText}
      />
    </AiaBox>
  );
}
