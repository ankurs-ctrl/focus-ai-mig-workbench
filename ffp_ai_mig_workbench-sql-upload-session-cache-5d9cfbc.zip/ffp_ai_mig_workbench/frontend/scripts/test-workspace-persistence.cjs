const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');

const filename = path.resolve(__dirname, '../src/features/sttm/context/sttm-builder-context.tsx');
const source = fs.readFileSync(filename, 'utf8');
const ast = ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true);
const callbacks = {};
function visit(node) {
  if (ts.isVariableDeclaration(node) && ['enqueueBackendAutosave', 'trackPostSaveJob', 'flushWorkspace'].includes(node.name.getText(ast))) {
    callbacks[node.name.getText(ast)] = node.initializer.arguments[0].getText(ast);
  }
  if (ts.isVariableDeclaration(node) && node.name.getText(ast) === 'persistState') callbacks.persistState = node.initializer.arguments[0].getText(ast);
  if (ts.isCallExpression(node) && node.expression.getText(ast) === 'useEffect'
      && node.arguments[0]?.getText(ast).includes('const workspaceIdentity =')) callbacks.criticalEffect = node.arguments[0].getText(ast);
  if (ts.isCallExpression(node) && node.expression.getText(ast) === 'useEffect'
      && node.arguments[0]?.getText(ast).includes('// One baseline per open request:')) callbacks.baselineEffect = node.arguments[0].getText(ast);
  ts.forEachChild(node, visit);
}
visit(ast);
function callback(name, context) {
  const loaded = new Module(filename, module);
  loaded._compile(ts.transpileModule(`module.exports = context => { const {${Object.keys(context).join(',')}} = context; return (${callbacks[name]}); };`, {
    compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020},
  }).outputText, filename);
  return loaded.exports(context);
}
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
};
const settle = async () => { for (let attempt = 0; attempt < 20; attempt++) await Promise.resolve(); };
function context(overrides = {}) {
  const statuses = [];
  return {
    statuses,
    ...helpers,
    store: {getState: () => ({sttmBuilder:{...emptyState(),chatMessages:[]}})},
    latestStateRef: {current:null},
    latestPersistedSessionRef: {current:null},
    latestCriticalSignatureRef: {current:''},
    lastBackendAutosaveAcknowledgementRef: {current:null},
    backendAutosaveInFlightRef: {current: false},
    backendAutosaveActiveRef: {current: null},
    pendingBackendAutosaveRef: {current: null},
    backendAutosavePromiseRef: {current: null},
    backendAutosaveErrorRef: {current: null},
    persistenceRevisionRef: {current: 0},
    activePostSaveJobRef: {current: null},
    lastBackendAutosaveSignatureRef: {current: null},
    setWorkspacePersistenceStatus: status => statuses.push(status),
    setWorkspacePersistenceError: () => {},
    trackPostSaveJob: () => {},
    persistState: () => {},
    console: {warn: () => {}},
    window: {setTimeout: resolve => { resolve(); return 1; }},
    ...overrides,
  };
}
const tests = [];
function test(name, run) { tests.push({name, run}); }

test('newer coalesced save survives an older in-flight failure', async () => {
  const first = deferred();
  const calls = [];
  const state = context({autosaveSttm: async (_id, payload) => {
    calls.push(payload.revision);
    if (calls.length === 1) return first.promise;
    return {};
  }});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('7401', {revision: 1}, 'old');
  enqueue('7401', {revision: 2}, 'new');
  first.reject(new Error('save failed'));
  await settle();
  assert.deepEqual(calls, [1, 2]);
  assert.equal(state.pendingBackendAutosaveRef.current, null);
  assert.equal(state.lastBackendAutosaveSignatureRef.current, 'new');
});

test('failed flush terminates with an error instead of waiting forever', async () => {
  const state = context({autosaveSttm: async () => { throw new Error('save failed'); }});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('7401', {revision: 1}, 'failed');
  await settle();
  let waits = 0;
  state.window.setTimeout = resolve => { if (++waits > 5) throw new Error('flush did not terminate'); resolve(); };
  await assert.rejects(callback('flushWorkspace', state)(), /save failed/);
});

test('a failed latest snapshot can be retried explicitly', async () => {
  let calls = 0;
  const state = context({autosaveSttm: async () => {
    if (++calls === 1) throw new Error('temporary failure');
    return {};
  }});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('7401', {revision: 1}, 'latest');
  await settle();
  assert.equal(state.pendingBackendAutosaveRef.current.signature, 'latest');
  state.persistState = () => ({sttmId:'7401',signature:'latest',revision:enqueue('7401', {revision: 1}, 'latest')});
  await callback('flushWorkspace', state)();
  assert.equal(calls, 2);
  assert.equal(state.statuses.at(-1), 'saved');
  assert.equal(state.backendAutosaveErrorRef.current, null);
});

test('writes stay single-flight and coalesce to the newest snapshot', async () => {
  const first = deferred();
  const calls = [];
  const state = context({autosaveSttm: async (_id, payload) => {
    calls.push(payload.revision);
    if (calls.length === 1) return first.promise;
    return {};
  }});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('7401', {revision: 1}, 'one');
  enqueue('7401', {revision: 2}, 'two');
  enqueue('7401', {revision: 3}, 'three');
  assert.deepEqual(calls, [1]);
  first.resolve({});
  await settle();
  assert.deepEqual(calls, [1, 3]);
  assert.equal(state.statuses.at(-1), 'saved');
});

test('a new save cancels status ownership of the previous background job', async () => {
  const state = context({autosaveSttm: async () => ({}), activePostSaveJobRef: {current: 'old-job'}});
  callback('enqueueBackendAutosave', state)('7401', {}, 'new');
  assert.equal(state.activePostSaveJobRef.current, null);
  await settle();
});

test('background job completion after eight polls is observed', async () => {
  let polls = 0;
  const state = context({getPostSaveJobStatus: async () => ({status: ++polls > 8 ? 'completed' : 'running'})});
  await callback('trackPostSaveJob', state)('7401', 'job', 0);
  assert.equal(polls, 9);
  assert.equal(state.statuses.at(-1), 'saved');
});

test('bounded background observation reports pending, not indefinite saving', async () => {
  const state = context({getPostSaveJobStatus: async () => ({status: 'running'})});
  await callback('trackPostSaveJob', state)('7401', 'job', 0);
  assert.equal(state.statuses.at(-1), 'details_pending');
});

test('stale background response cannot replace newer save status', async () => {
  const response = deferred();
  const state = context({getPostSaveJobStatus: () => response.promise});
  const tracking = callback('trackPostSaveJob', state)('7401', 'job', 0);
  await settle();
  state.persistenceRevisionRef.current++;
  state.activePostSaveJobRef.current = null;
  state.setWorkspacePersistenceStatus('saving');
  response.resolve({status: 'completed'});
  await tracking;
  assert.equal(state.statuses.at(-1), 'saving');
});

test('same id background responses are fenced by save revision', async () => {
  const response = deferred();
  const state = context({getPostSaveJobStatus: () => response.promise});
  const tracking = callback('trackPostSaveJob', state)('7401', 'same-job', 0);
  await settle();
  state.persistenceRevisionRef.current++;
  state.setWorkspacePersistenceStatus('saving');
  response.resolve({status: 'failed'});
  await tracking;
  assert.equal(state.statuses.at(-1), 'saving');
});

test('post-save failure reports committed draft separately', async () => {
  let message;
  const state = context({getPostSaveJobStatus: async () => ({status:'failed'}),
    setWorkspacePersistenceError: error => {message = error;}});
  await callback('trackPostSaveJob', state)('7401', 'job', 0);
  assert.equal(state.statuses.at(-1), 'error');
  assert.match(message, /Draft saved/);
});

test('flush waits for the newest coalesced write, not background projections', async () => {
  const first = deferred();
  const second = deferred();
  let calls = 0;
  const state = context({autosaveSttm: () => ++calls === 1 ? first.promise : second.promise});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('7401', {revision: 1}, 'one');
  enqueue('7401', {revision: 2}, 'two');
  let done = false;
  const flush = callback('flushWorkspace', state)().then(() => {done = true;});
  first.resolve({post_save_job_id:'old',post_save_job_status:'queued'});
  await settle();
  assert.equal(calls, 2);
  assert.equal(done, false);
  second.resolve({post_save_job_id:'new',post_save_job_status:'queued'});
  await flush;
  assert.equal(done, true);
});

test('manual-save dialog remains retryable after persistence failure', async () => {
  const mappingPath = path.resolve(__dirname, '../src/features/sttm/mapping/source-target-attribute-mapping.tsx');
  const mappingAst = ts.createSourceFile(mappingPath, fs.readFileSync(mappingPath, 'utf8'), ts.ScriptTarget.Latest, true);
  function find(node) {
    if (ts.isVariableDeclaration(node) && node.name.getText(mappingAst) === 'handleConfirmSaveManualEdits') {
      callbacks.handleConfirmSaveManualEdits = node.initializer.arguments[0].getText(mappingAst);
    }
    ts.forEachChild(node, find);
  }
  find(mappingAst);
  let closed = false;
  const busy = [];
  const state = {
    hasUnsavedManualEdits:false, saveConfirmOpen:true, isSavingManualEdits:false,
    setIsSavingManualEdits:value=>busy.push(value), commitPendingManualMappingEdits:()=>{},
    flushWorkspace:async()=>{throw new Error('failed');}, clearUndoStack:()=>{},
    setSaveConfirmOpen:value=>{closed=!value;}, setCancelConfirmOpen:()=>{}, console:{warn:()=>{}},
  };
  await callback('handleConfirmSaveManualEdits', state)();
  assert.equal(closed, false);
  assert.deepEqual(busy, [true, false]);
  state.flushWorkspace = async()=>{};
  await callback('handleConfirmSaveManualEdits', state)();
  assert.equal(closed, true);
});

test('repeated flushes while the same save is active do not enqueue new revisions', async () => {
  const pending = deferred();
  let calls = 0;
  const state = context({autosaveSttm: () => { calls++; return pending.promise; }});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('9601', {}, 'same');
  enqueue('9601', {}, 'same');
  enqueue('9601', {}, 'same');
  assert.equal(state.persistenceRevisionRef.current, 1);
  pending.resolve({});
  await settle();
  assert.equal(calls, 1);
  assert.equal(state.statuses.at(-1), 'saved');
});

test('returning to an active signature after a different queued edit still saves the latest', async () => {
  const pending = deferred();
  const calls = [];
  const state = context({autosaveSttm: (_id, payload) => {
    calls.push(payload.name);
    return calls.length === 1 ? pending.promise : Promise.resolve({});
  }});
  const enqueue = callback('enqueueBackendAutosave', state);
  enqueue('9601', {name:'first'}, 'first');
  enqueue('9601', {name:'other'}, 'other');
  enqueue('9601', {name:'reverted'}, 'first');
  pending.resolve({});
  await settle();
  assert.deepEqual(calls, ['first', 'reverted']);
});

test('transient processing does not dirty durable semantics but edits and outcomes do', () => {
  const fingerprint = helpers.semanticWorkspaceFingerprint;
  const state = {...emptyState(),mappings:[{id:'one',targetColumn:'NAME',status:'UNMAPPED'}]};
  const before = fingerprint(state);
  state.mappings[0].status = 'PROCESSING';
  assert.equal(fingerprint(state), before);
  state.mappings[0].expression = 'SOURCE.NAME';
  assert.notEqual(fingerprint(state), before);
  delete state.mappings[0].expression;
  state.mappings[0].status = 'MAPPED';
  assert.notEqual(fingerprint(state), before);
});

test('chat questions and streaming deltas coalesce until the completed answer', () => {
  const declaration = ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'completedConversationFingerprint');
  const loaded = new Module(filename, module);
  loaded._compile(ts.transpileModule(`${declaration.getText(ast)}; module.exports = completedConversationFingerprint;`, {
    compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020},
  }).outputText, filename);
  const fingerprint = loaded.exports;
  const previous = [{role:'user', content:'Explain NAME'}, {role:'assistant', content:'Source is NAME_R'}];
  const baseline = fingerprint(previous);
  const question = {role:'user', content:'Highlight column names'};
  assert.deepEqual(fingerprint([...previous, question]), baseline);
  assert.deepEqual(fingerprint([...previous, question, {role:'assistant', content:'partial', isStreaming:true}]), baseline);
  assert.deepEqual(fingerprint([...previous, question, {role:'assistant', content:'failed', status:'failed'}]), baseline);
  assert.equal(fingerprint([...previous, question, {role:'assistant', content:'`NAME_R`'}]).length, 4);
});

function load(relative) {
  const file = path.resolve(__dirname, relative);
  const loaded = new Module(file, module);
  loaded.require = name => name.startsWith('@/') ? load(`../src/${name.slice(2)}.ts`)
    : name.startsWith('.') ? load(path.resolve(path.dirname(file), `${name}.ts`)) : require(name);
  loaded._compile(ts.transpileModule(fs.readFileSync(file, 'utf8'), {
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText, file);
  return loaded.exports;
}
const selection = load('../src/features/sttm/shared/sttm-selection-utils.ts');
const authored = load('../src/features/sttm/mapping/authored-sql-key.ts');
const derived = load('../src/features/sttm/shared/derived-source-columns.ts');
const helpers = compileHelpers();
function compileHelpers() {
  const declarations = [];
  function collect(node) {
    if (ts.isFunctionDeclaration(node) && ['semanticWorkspaceFingerprint', 'durableWorkspaceState',
      'completedConversationFingerprint', 'criticalWorkspaceFingerprint', 'persistedWorkspaceSession'].includes(node.name?.text)) {
      declarations.push(node.getText(ast).replace(/^export\s+/,''));
    }
    ts.forEachChild(node,collect);
  }
  collect(ast);
  const loaded = new Module(filename, module);
  loaded._compile(ts.transpileModule(`module.exports = dependencies => { const {${Object.keys({...selection,...authored,...derived}).join(',')}} = dependencies;
    ${declarations.join('\n')}; return {semanticWorkspaceFingerprint, criticalWorkspaceFingerprint, persistedWorkspaceSession, durableWorkspaceState}; };`, {
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText, filename);
  return loaded.exports({...selection,...authored,...derived});
}
const fingerprint = helpers.semanticWorkspaceFingerprint;
const emptyState = () => ({sources:[],targets:[],sourceDatabases:[],targetDatabases:[],mappings:[],
  pendingManualEditSnapshots:{},sourceAttributeGroups:[],derivedSources:[],relationships:[],selectedMappingIds:[]});
function scheduler(state, signature = 'dirty') {
  let clock = 0, timerId = 0;
  const timers = new Map(), writes = [];
  const input = {state,criticalStateSignature:signature,sessionHydrated:true,isInSttmBuilder:true,
    dirtyWorkspaceRef:{current:null},dirtySinceRef:{current:null},criticalPersistTimerRef:{current:null},
    lastBackendAutosaveSignatureRef:{current:'baseline'},lastCriticalStateSignatureRef:{current:null},
    CRITICAL_STATE_MAX_WAIT_MS:30000,CRITICAL_STATE_DEBOUNCE_MS:5000,
    Date:{now:()=>clock},window:{setTimeout:(run,delay)=>{timers.set(++timerId,{run,at:clock+delay});return timerId;},clearTimeout:id=>timers.delete(id)},
    persistState:()=>writes.push(input.criticalStateSignature)};
  return {input,timers,writes,render:()=>callback('criticalEffect',input)(),advance(ms) {
    clock += ms;
    for (const [id,timer] of [...timers]) if(timer.at<=clock) {timers.delete(id);timer.run();}
  }};
}
test('cancelled critical debounce reschedules identical dirty work after loading and StrictMode cleanup', () => {
  const lifecycle = scheduler({activeProjectId:'p',activeSttmId:'10301',openSttmStatus:'success'});
  lifecycle.render()();
  lifecycle.input.state.openSttmStatus='loading'; lifecycle.render();
  lifecycle.input.state.openSttmStatus='success'; lifecycle.render();
  assert.equal(lifecycle.timers.size,1);
  lifecycle.advance(5000);
  assert.deepEqual(lifecycle.writes,['dirty']);
});
test('critical debounce retains maximum wait through cancellations and latest revision', () => {
  const lifecycle = scheduler({activeProjectId:'p',activeSttmId:'10301',openSttmStatus:'success'});
  let cleanup = lifecycle.render();
  for(let revision=1;revision<=7;revision++) {
    lifecycle.advance(4000); cleanup(); lifecycle.input.criticalStateSignature=`revision-${revision}`; cleanup=lifecycle.render();
  }
  lifecycle.advance(2000);
  assert.deepEqual(lifecycle.writes,['revision-7']);
});
test('clean reversion cancels dirty work and workspace identity resets maximum wait', () => {
  const lifecycle=scheduler({activeProjectId:'p',activeSttmId:'10301',openSttmStatus:'success'});
  let cleanup=lifecycle.render(); lifecycle.advance(4000); cleanup();
  lifecycle.input.criticalStateSignature='baseline'; lifecycle.render(); lifecycle.advance(30000);
  assert.deepEqual(lifecycle.writes,[]);
  lifecycle.input.criticalStateSignature='dirty'; cleanup=lifecycle.render(); lifecycle.advance(4000); cleanup();
  lifecycle.input.state.activeSttmId='other'; lifecycle.render();
  lifecycle.advance(1000); assert.equal(lifecycle.writes.length,0);
  lifecycle.advance(4000); assert.deepEqual(lifecycle.writes,['dirty']);
});
test('redundant source display and materialized default ordinal do not dirty rows; real changes do', () => {
  const state=emptyState(); state.mappings=[{id:'a',targetColumn:'A',sourceColumns:['a.ID','b.ID'],sourceColumn:'a.ID',status:'MAPPED'}];
  const before=fingerprint(state);
  state.mappings[0].sourceColumn='a.ID, b.ID'; state.mappings[0].targetOrdinal=0;
  assert.equal(fingerprint(state),before);
  state.mappings[0].targetOrdinal=4; assert.notEqual(fingerprint(state),before);
  state.mappings[0].targetOrdinal=0; state.mappings[0].sourceColumns=['b.ID']; assert.notEqual(fingerprint(state),before);
});
test('owned wildcard catalog enrichment is not durable but edited output types and definitions are', () => {
  const state=emptyState();
  state.derivedSources=[{id:'cte',sourceName:'C',isSelected:true,sqlText:'SELECT * FROM D.S.A',columns:[],outputColumns:[],
    queryScope:{outputs:[{star:true,plain_star:true}],relations:[{relation_name:'D.S.A'}]}}];
  const before=fingerprint(state);
  state.sourceAttributeGroups=[{qualifiedName:'D.S.A',columns:[{name:'ID',type:'NUMBER'}]}];
  state.derivedSources=derived.hydrateDerivedColumns(state.derivedSources,state.sourceAttributeGroups);
  assert.equal(fingerprint(state),before);
  const enriched=structuredClone(state);
  state.derivedSources[0].columns[0].type='VARCHAR'; assert.notEqual(fingerprint(state),before);
  Object.assign(state,structuredClone(enriched));
  state.derivedSources[0].outputColumns[0].data_type='VARCHAR'; assert.notEqual(fingerprint(state),before);
  Object.assign(state,structuredClone(enriched)); state.derivedSources[0].definitionSql='SELECT ID FROM D.S.A';
  assert.notEqual(fingerprint(state),before);
});
test('explicit CTE output catalog defaults normalize but output edits and types remain durable', () => {
  const state=emptyState();
  state.derivedSources=[{id:'cte',sourceName:'C',isSelected:true,sqlText:'SELECT ID FROM D.S.A',columns:[{name:'ID',type:'—'}],
    outputColumns:[{name:'ID'}],queryScope:{outputs:[{name:'ID',star:false}]}}];
  const before=fingerprint(state);
  state.derivedSources=derived.hydrateDerivedColumns(state.derivedSources,[]);
  assert.equal(fingerprint(state),before);
  state.derivedSources[0].columns[0].type='NUMBER'; assert.notEqual(fingerprint(state),before);
  state.derivedSources[0].columns[0].type='TEXT'; state.derivedSources[0].outputColumns[0].name='OTHER';
  assert.notEqual(fingerprint(state),before);
});
test('durable derived annotations and compiler validation results still schedule saves', () => {
  const state=emptyState();
  state.derivedSources=[{id:'manual',sourceName:'C',isSelected:true,columns:[{name:'ID',type:'NUMBER'}],outputColumns:[{name:'ID',data_type:'NUMBER'}]}];
  const before=fingerprint(state);
  for(const key of ['columns','outputColumns']) {
    const edited=structuredClone(state); edited.derivedSources[0][key][0].name='USER_EDIT'; assert.notEqual(fingerprint(edited),before);
  }
  for(const [key,value] of Object.entries({compiledMappingSql:'compiled',compiledMappingReady:true,sqlValidatedSignature:'validated'})) {
    assert.notEqual(fingerprint({...state,[key]:value}),before);
  }
});
test('backend autosave uses the fingerprint committed projection without discarding pending edits', () => {
  const committed={id:'a',targetColumn:'A',sourceColumns:['a.ID'],status:'MAPPED'};
  const state={...emptyState(),activeProjectId:'p',activeSttmId:'10301',mappings:[{...committed,sourceColumns:['a.EDIT']}],pendingManualEditSnapshots:{a:committed}};
  const before=structuredClone(state), sent=[];
  const sliceFile=path.resolve(__dirname,'../src/features/sttm/store/sttm-builder-slice.ts');
  const sliceAst=ts.createSourceFile(sliceFile,fs.readFileSync(sliceFile,'utf8'),ts.ScriptTarget.Latest,true);
  const snapshotDeclaration=sliceAst.statements.find(node=>ts.isFunctionDeclaration(node)&&node.name?.text==='snapshotFromState');
  const snapshotModule=new Module(sliceFile,module);
  snapshotModule._compile(ts.transpileModule(`module.exports=dependencies=>{const {resolveSelectedSourceTables,resolveSelectedTargetTable,buildWorkbenchContextSnapshot}=dependencies;
    ${snapshotDeclaration.getText(sliceAst).replace(/^export\s+/,'')};return snapshotFromState;};`,{
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText,sliceFile);
  const realSnapshot=snapshotModule.exports({...selection,...load('../src/features/sttm/context/workbench-context.ts')});
  const payloads=[];
  Object.assign(state,{pendingAiMappingReviews:[],mappingSuggestions:[],chatMessages:[]});
  Object.assign(before,{pendingAiMappingReviews:[],mappingSuggestions:[],chatMessages:[]});
  const input={latestStateRef:{current:state},latestPersistedSessionRef:{current:state},
    latestCriticalSignatureRef:{current:'dirty'},lastBackendAutosaveSignatureRef:{current:'old'},
    pendingBackendAutosaveRef:{current:null},backendAutosaveInFlightRef:{current:false},
    latestAssistantPageRef:{current:'mapping'},latestAssistantSurfaceRef:{current:'MAPPING'},
    getScopedStorageKey:()=>'',getActiveWorkspacePointerKey:()=>'',persistBrowserWorkspace:()=>{},
    window:{localStorage:{setItem:()=>{}}},console,
    durableWorkspaceState:helpers.durableWorkspaceState,
    snapshotFromState:projected=>{sent.push(projected);return realSnapshot(projected,'workspace.autosaved');},
    enqueueBackendAutosave:(_id,payload)=>payloads.push(payload)};
  callback('persistState',input)(true);
  assert.deepEqual(sent[0].mappings,[committed]); assert.deepEqual(state,before);
  assert.deepEqual(payloads[0].workspace_snapshot.mapping_rows[0].source_columns,['a.ID']);
  const pendingFingerprint=fingerprint(state);
  state.pendingManualEditSnapshots={};
  assert.notEqual(fingerprint(state),pendingFingerprint);
  callback('persistState',input)(true);
  assert.deepEqual(sent[1].mappings[0].sourceColumns,['a.EDIT']);
  assert.deepEqual(payloads[1].workspace_snapshot.mapping_rows[0].source_columns,['a.EDIT']);
  // Cancel uses the real reducer and must leave no pending change to save.
  let cancelReducer;
  function findCancel(node) {if(ts.isPropertyAssignment(node)&&node.name.getText(sliceAst)==='cancelPendingManualMappingEdits') cancelReducer=node.initializer.getText(sliceAst);ts.forEachChild(node,findCancel);}
  findCancel(sliceAst); callbacks.cancelReducer=cancelReducer;
  state.pendingManualEditSnapshots={a:committed};
  callback('cancelReducer',{cloneMappingSnapshot:structuredClone})(state);
  assert.deepEqual(state.mappings,[committed]);
  callback('persistState',input)(true);
  assert.deepEqual(payloads[2].workspace_snapshot.mapping_rows[0].source_columns,['a.ID']);
});

function immediateFlushHarness() {
  const {configureStore, createSlice} = require('@reduxjs/toolkit');
  const sliceFile = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
  const sliceAst = ts.createSourceFile(sliceFile, fs.readFileSync(sliceFile, 'utf8'), ts.ScriptTarget.Latest, true);
  const reducerNames = ['updateMapping', 'commitPendingManualMappingEdits', 'cancelPendingManualMappingEdits'];
  const reducers = {};
  function scan(node) {
    if (ts.isPropertyAssignment(node) && reducerNames.includes(node.name.getText(sliceAst))) {
      reducers[node.name.getText(sliceAst)] = node.initializer.getText(sliceAst);
    }
    ts.forEachChild(node, scan);
  }
  scan(sliceAst);
  const declarations = sliceAst.statements.filter(node => ts.isFunctionDeclaration(node)
    && ['cloneMappingSnapshot', 'captureManualEditSnapshot', 'snapshotFromState'].includes(node.name?.text));
  const loaded = new Module(sliceFile, module);
  loaded._compile(ts.transpileModule(`module.exports = dependencies => {
    const {resolveSelectedSourceTables, resolveSelectedTargetTable, buildWorkbenchContextSnapshot} = dependencies;
    ${declarations.map(node => node.getText(sliceAst).replace(/^export\s+/, '')).join('\n')}
    return {snapshotFromState, reducers: {${Object.entries(reducers).map(([name, text]) => `${name}: ${text}`).join(',')}}};
  };`, {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText, sliceFile);
  const real = loaded.exports({...selection, ...load('../src/features/sttm/context/workbench-context.ts')});
  const initialState = {...emptyState(), activeProjectId:'p', activeSttmId:'10301', activeSnapshotId:'snapshot',
    pendingAiMappingReviews:[], mappingSuggestions:[], chatMessages:[], assistantSignals:[], assistantInferences:[],
    mappings:[{id:'a',targetColumn:'A',sourceColumns:['a.ID'],status:'MAPPED'}]};
  const slice = createSlice({name:'sttmBuilder', initialState, reducers:real.reducers});
  const store = configureStore({reducer:{sttmBuilder:slice.reducer}});
  store.dispatch(slice.actions.updateMapping({id:'a',updates:{sourceColumns:['a.EDIT'],expression:'a.EDIT',constantValue:'new'}}));
  const beforeCommit = store.getState().sttmBuilder;
  const requests = [], browser = [];
  const state = context({...helpers, store, snapshotFromState:real.snapshotFromState,
    latestStateRef:{current:beforeCommit},latestPersistedSessionRef:{current:beforeCommit},
    latestCriticalSignatureRef:{current:'baseline'},lastBackendAutosaveSignatureRef:{current:'baseline'},
    lastBackendAutosaveAcknowledgementRef:{current:null},
    latestAssistantPageRef:{current:'mapping'},latestAssistantSurfaceRef:{current:'MAPPING'},
    getScopedStorageKey:()=>'',getActiveWorkspacePointerKey:()=>'',
    persistBrowserWorkspace:(_key,session)=>browser.push(session),
    window:{localStorage:{setItem:()=>{}}},
    autosaveSttm:(id,payload)=>{const response=deferred();requests.push({id,payload,response});return response.promise;},
  });
  state.enqueueBackendAutosave = callback('enqueueBackendAutosave',state);
  state.persistState = callback('persistState',state);
  state.flushWorkspace = callback('flushWorkspace',state);
  let closed = false, undoCleared = false;
  const dialog = callback('handleConfirmSaveManualEdits', {
    hasUnsavedManualEdits:true,saveConfirmOpen:true,isSavingManualEdits:false,
    commitPendingManualMappingEdits:()=>store.dispatch(slice.actions.commitPendingManualMappingEdits()),
    flushWorkspace:state.flushWorkspace,setIsSavingManualEdits:()=>{},
    setSaveConfirmOpen:value=>{closed=!value;},setCancelConfirmOpen:()=>{},
    clearUndoStack:()=>{undoCleared=true;},console:{warn:()=>{}},
  });
  return {state,store,actions:slice.actions,beforeCommit,requests,browser,dialog,
    closed:()=>closed,undoCleared:()=>undoCleared};
}

test('real commit then immediate flush captures Redux without rerender and waits for its 200 before closing', async () => {
  const harness = immediateFlushHarness();
  const saving = harness.dialog();
  await settle();
  assert.equal(harness.requests.length,1,'committed Redux state must enqueue before any React rerender');
  const committed = harness.store.getState().sttmBuilder;
  assert.notEqual(committed,harness.beforeCommit);
  assert.equal(harness.state.latestStateRef.current,committed);
  assert.deepEqual(harness.state.latestPersistedSessionRef.current.mappings,committed.mappings);
  assert.deepEqual(harness.browser[0].mappings,committed.mappings);
  assert.equal(harness.state.latestCriticalSignatureRef.current,helpers.criticalWorkspaceFingerprint(committed));
  const row = harness.requests[0].payload.workspace_snapshot.mapping_rows[0];
  assert.deepEqual(row.source_columns,['a.EDIT']);
  assert.equal(row.expression,'a.EDIT');
  assert.equal(row.manually_saved,true);
  assert.equal(harness.closed(),false); assert.equal(harness.undoCleared(),false);
  assert.notEqual(harness.state.statuses.at(-1),'saved');
  harness.requests[0].response.resolve({status:200});
  await saving;
  assert.equal(harness.closed(),true); assert.equal(harness.undoCleared(),true);
  assert.equal(harness.state.lastBackendAutosaveSignatureRef.current,helpers.criticalWorkspaceFingerprint(committed));
  assert.equal(harness.state.lastBackendAutosaveAcknowledgementRef.current.revision,1);
  await harness.state.flushWorkspace();
  assert.equal(harness.requests.length,1,'acknowledged revision must not be saved twice');
});

test('immediate committed flush waits behind the old active write and preserves later uncommitted edits', async () => {
  const harness = immediateFlushHarness();
  harness.state.enqueueBackendAutosave('10301',{old:true},'old');
  const saving = harness.dialog();
  const committed = harness.store.getState().sttmBuilder;
  assert.equal(harness.requests.length,1);
  harness.store.dispatch(harness.actions.updateMapping({id:'a',updates:{sourceColumns:['a.LATER']}}));
  harness.requests[0].response.resolve({status:200});
  await settle();
  assert.equal(harness.closed(),false);
  assert.equal(harness.requests.length,2);
  assert.deepEqual(harness.requests[1].payload.workspace_snapshot.mapping_rows[0].source_columns,['a.EDIT']);
  assert.notEqual(harness.state.lastBackendAutosaveSignatureRef.current,helpers.criticalWorkspaceFingerprint(committed));
  harness.requests[1].response.resolve({status:200}); await saving;
  assert.equal(harness.closed(),true);
  const live = harness.store.getState().sttmBuilder;
  assert.deepEqual(live.mappings[0].sourceColumns,['a.LATER']);
  assert.deepEqual(live.pendingManualEditSnapshots.a.sourceColumns,['a.EDIT']);
  assert.equal(helpers.criticalWorkspaceFingerprint(live),helpers.criticalWorkspaceFingerprint(committed));
  harness.state.latestStateRef.current=live;
  harness.state.latestCriticalSignatureRef.current=helpers.criticalWorkspaceFingerprint(live);
  harness.state.persistState(true);
  await harness.state.flushWorkspace();
  assert.equal(harness.requests.length,2,'auto and explicit flush must exclude later uncommitted edits');
  harness.store.dispatch(harness.actions.cancelPendingManualMappingEdits());
  await harness.state.flushWorkspace();
  assert.equal(harness.requests.length,2,'cancel must retain the acknowledged baseline');
});

test('uncommitted edits remain excluded by auto and explicit flush without modifying Redux', async () => {
  const harness = immediateFlushHarness();
  harness.state.lastBackendAutosaveSignatureRef.current='different';
  harness.state.persistState(true);
  assert.deepEqual(harness.requests[0].payload.workspace_snapshot.mapping_rows[0].source_columns,['a.ID']);
  harness.requests[0].response.resolve({status:200}); await settle();
  const flushing=harness.state.flushWorkspace(); await settle();
  for (const request of harness.requests) {
    assert.deepEqual(request.payload.workspace_snapshot.mapping_rows[0].source_columns,['a.ID']);
    request.response.resolve({status:200});
  }
  await flushing;
  assert.equal(harness.store.getState().sttmBuilder,harness.beforeCommit);
  assert.deepEqual(harness.beforeCommit.mappings[0].sourceColumns,['a.EDIT']);
  assert.deepEqual(harness.beforeCommit.pendingManualEditSnapshots.a.sourceColumns,['a.ID']);
});

test('superseded coalesced commit cannot report its unmatched revision as saved', async () => {
  const harness = immediateFlushHarness();
  harness.state.enqueueBackendAutosave('10301',{old:true},'old');
  harness.store.dispatch(harness.actions.commitPendingManualMappingEdits());
  const flushed = assert.rejects(harness.state.flushWorkspace(),/revision was superseded/);
  harness.store.dispatch(harness.actions.updateMapping({id:'a',updates:{sourceColumns:['a.NEWER']}}));
  harness.store.dispatch(harness.actions.commitPendingManualMappingEdits());
  const newer = harness.state.flushWorkspace();
  harness.requests[0].response.resolve({status:200}); await settle();
  assert.equal(harness.requests.length,2);
  assert.deepEqual(harness.requests[1].payload.workspace_snapshot.mapping_rows[0].source_columns,['a.NEWER']);
  harness.requests[1].response.resolve({status:200});
  await flushed; await newer;
  assert.equal(harness.state.lastBackendAutosaveAcknowledgementRef.current.revision,3);
});

test('failed immediate commit flush stays open and retries the same Redux snapshot', async () => {
  const harness = immediateFlushHarness();
  const saving = harness.dialog();
  harness.requests[0].response.reject(new Error('save failed')); await saving;
  assert.equal(harness.closed(),false); assert.equal(harness.undoCleared(),false);
  assert.equal(harness.state.lastBackendAutosaveAcknowledgementRef.current,null);
  const retry = harness.dialog();
  assert.equal(harness.requests.length,2);
  assert.deepEqual(harness.requests[1].payload.workspace_snapshot.mapping_rows,
    harness.requests[0].payload.workspace_snapshot.mapping_rows);
  assert.equal(harness.closed(),false);
  harness.requests[1].response.resolve({status:200}); await retry;
  assert.equal(harness.closed(),true);
});

test('snapshot construction failure rejects explicit flush instead of closing as saved', async () => {
  const harness = immediateFlushHarness();
  harness.state.snapshotFromState=()=>{throw new Error('snapshot failed');};
  harness.state.persistState=callback('persistState',harness.state);
  harness.store.dispatch(harness.actions.commitPendingManualMappingEdits());
  await assert.rejects(callback('flushWorkspace',harness.state)(),/snapshot failed/);
  assert.equal(harness.requests.length,0);
});

test('reverting to acknowledged baseline while a different write is active queues the baseline again', async () => {
  const harness = immediateFlushHarness();
  const baseline = helpers.criticalWorkspaceFingerprint(harness.beforeCommit);
  harness.state.lastBackendAutosaveSignatureRef.current=baseline;
  harness.state.enqueueBackendAutosave('10301',{different:true},'different');
  const flushing = harness.state.flushWorkspace();
  assert.equal(harness.state.pendingBackendAutosaveRef.current.signature,baseline);
  harness.requests[0].response.resolve({status:200}); await settle();
  assert.equal(harness.requests.length,2);
  assert.deepEqual(harness.requests[1].payload.workspace_snapshot.mapping_rows[0].source_columns,['a.ID']);
  harness.requests[1].response.resolve({status:200}); await flushing;
  assert.equal(harness.state.lastBackendAutosaveSignatureRef.current,baseline);
});

test('hydration baseline is captured once and cannot consume a later committed signature', () => {
  const state={...emptyState(),activeProjectId:'p',activeSttmId:'10301',openSttmStatus:'loading',loadState:{attributes:'loading'}};
  const input={state,sessionHydrated:true,criticalStateSignature:'loading',
    backendBaselineIdentityRef:{current:'p:10301'},lastBackendAutosaveSignatureRef:{current:'previous'}};
  callback('baselineEffect',input)(); assert.equal(input.backendBaselineIdentityRef.current,null);
  state.openSttmStatus='success'; input.criticalStateSignature='hydrating';
  callback('baselineEffect',input)(); assert.equal(input.lastBackendAutosaveSignatureRef.current,'previous');
  state.loadState.attributes='success'; input.criticalStateSignature='baseline';
  callback('baselineEffect',input)(); assert.equal(input.lastBackendAutosaveSignatureRef.current,'baseline');
  input.criticalStateSignature='committed-edit'; callback('baselineEffect',input)();
  assert.equal(input.lastBackendAutosaveSignatureRef.current,'baseline');
  state.openSttmStatus='loading'; callback('baselineEffect',input)();
  state.openSttmStatus='success'; input.criticalStateSignature='reopened'; callback('baselineEffect',input)();
  assert.equal(input.lastBackendAutosaveSignatureRef.current,'reopened');
});

test('repeated synchronous flush observes the same exact active revision', async () => {
  const harness = immediateFlushHarness();
  harness.store.dispatch(harness.actions.commitPendingManualMappingEdits());
  const first=harness.state.flushWorkspace(), second=harness.state.flushWorkspace();
  assert.equal(harness.requests.length,1);
  assert.equal(harness.state.persistenceRevisionRef.current,1);
  harness.requests[0].response.resolve({status:200}); await Promise.all([first,second]);
  assert.equal(harness.state.lastBackendAutosaveAcknowledgementRef.current.revision,1);
});

async function runHydrationLifecycle(state) {
  Object.assign(state,{pendingManualEditSnapshots:{},sourceAttributeGroups:[],activeProjectId:'p',activeSttmId:'10301',openSttmStatus:'success'});
  const pageFile=path.resolve(__dirname,'../src/app/sttm/builder/new/mapping/page.tsx');
  const pageAst=ts.createSourceFile(pageFile,fs.readFileSync(pageFile,'utf8'),ts.ScriptTarget.Latest,true);
  let targetEffect,autoEffect;
  const sliceFile=path.resolve(__dirname,'../src/features/sttm/store/sttm-builder-slice.ts');
  const sliceAst=ts.createSourceFile(sliceFile,fs.readFileSync(sliceFile,'utf8'),ts.ScriptTarget.Latest,true);
  let ensureReducer;
  function scan(node) {
    if(ts.isCallExpression(node)&&node.expression.getText(pageAst)==='useEffect') {
      const text=node.arguments[0]?.getText(pageAst);
      if(text?.includes('const initialMappings =')) targetEffect=text;
      if(text?.includes('lastAutomaticCompileHash.current = compilerContextHash')) autoEffect=text;
    }
    ts.forEachChild(node,scan);
  }
  scan(pageAst);
  function find(node) {if(ts.isPropertyAssignment(node)&&node.name.getText(sliceAst)==='ensureTargetMappings') ensureReducer=node.initializer.getText(sliceAst);ts.forEachChild(node,find);}
  find(sliceAst);
  callbacks.targetEffect=targetEffect; callbacks.autoEffect=autoEffect; callbacks.ensureReducer=ensureReducer;
  const {missingTargetMappings}=load('../src/features/sttm/shared/mapping-row-recovery.ts');
  const ensure=callback('ensureReducer',{missingTargetMappings});
  const original=structuredClone(state), before=fingerprint(state);
  assert.equal(state.mappings.length,35); assert.equal(state.derivedSources.length,4);
  const targetAttributeGroup={qualifiedName:'D.T.HOUSEHOLD',columns:[...state.mappings.map(row=>({name:row.targetColumn,type:row.targetType})),
    ...Array.from({length:10},(_,index)=>({name:`UNUSED_${index}`,type:'VARCHAR'}))]};
  callback('targetEffect',{savedWorkspaceHydrating:false,targetAttributeGroup,targetTableKey:targetAttributeGroup.qualifiedName,targetColumnsSignature:'45',ensureTargetMappings:rows=>ensure(state,{payload:rows})})();
  assert.equal(state.mappings.length,45); assert.deepEqual(state.mappings.slice(0,35),original.mappings);
  assert.equal(authored.authoredSqlIsCurrent(state.mappingSql,state.authoredSqlSemanticKey,state),true,'target placeholders must retain authored currency');
  assert.equal(fingerprint(state),before,'target placeholders must not schedule another save');
  // Repeated catalog enrichment of the four owned CTEs is metadata-only too.
  state.derivedSources=derived.hydrateDerivedColumns(state.derivedSources,state.sourceAttributeGroups);
  assert.equal(fingerprint(state),before);
  const {selectMappingSqlArtifact}=load('../src/features/sttm/mapping/mapping-sql-artifact.ts');
  const artifact=()=>selectMappingSqlArtifact({authoredSql:state.mappingSql,authoredPreviewSql:state.mappingPreviewSql,
    authoredIsCurrent:authored.authoredSqlIsCurrent(state.mappingSql,state.authoredSqlSemanticKey,state),fallbackSql:'draft',fallbackPreviewSql:'draft'});
  const pending=[]; let compiles=0;
  const autoInput={autoCompile:true,mappingLoading:false,savedWorkspaceHydrating:false,isLoadingProjectAttributes:false,
    pendingManualEditSnapshots:{},currentSqlArtifact:artifact(),isCompilingSql:false,reviewLoading:false,mappedCount:35,
    lastAutomaticCompileHash:{current:null},compilerContextHash:'hydrated',compileCurrentMappingSql:()=>compiles++,
    window:{setTimeout:run=>{pending.push(run);return 1;},clearTimeout:()=>{}}};
  callback('autoEffect',autoInput)(); assert.equal(pending.length,0); assert.equal(artifact().source,'authored');
  const lifecycle=scheduler(state,before); lifecycle.render()(); lifecycle.render(); lifecycle.advance(5000);
  assert.equal(lifecycle.writes.length,1,'Apply save survives effect cancellation');
  lifecycle.input.lastBackendAutosaveSignatureRef.current=before; lifecycle.render(); lifecycle.advance(5000);
  assert.equal(lifecycle.writes.length,1);
  state.mappings[35].mappingMode='constant'; state.mappings[35].constantValue='intent';
  assert.equal(authored.authoredSqlIsCurrent(state.mappingSql,state.authoredSqlSemanticKey,state),false);
  autoInput.currentSqlArtifact=artifact(); callback('autoEffect',autoInput)(); pending.forEach(run=>run()); assert.equal(compiles,1);
  lifecycle.input.criticalStateSignature=fingerprint(state); lifecycle.render(); lifecycle.advance(5000);
  assert.equal(lifecycle.writes.length,2);
  return {mapped:35,hydrated:45,ctes:4,applySaves:1,editSaves:1,hydrationCompiles:0,editCompiles:compiles};
}
module.exports={runHydrationLifecycle};

if (require.main === module) (async () => {
  let failures = 0;
  for (const item of tests) {
    try { await item.run(); console.log(`PASS ${item.name}`); }
    catch (error) { failures++; console.error(`FAIL ${item.name}: ${error.message}`); }
  }
  console.log(`${tests.length - failures}/${tests.length} persistence regressions passed.`);
  process.exitCode = failures ? 1 : 0;
})();