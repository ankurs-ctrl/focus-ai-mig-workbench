"use client";

import { useCallback } from "react";
import { useSignals } from "@/hooks/useSignals";
import { SignalNotificationStack } from "@/components/signals";
import { signalService } from "@/services/signalService";

export default function SttmLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const { signals, dismissSignal } = useSignals({ autoConnect: true });

    const handleOptionSelect = useCallback(
        (signalId: string, optionId: string) => {
            const signal = signals.find((s) => s.signal_id === signalId);
            const recommendationId = signal?.metadata?.recommendation_id as string | undefined;
            signalService.sendSignalResponse(signalId, optionId, recommendationId);
            dismissSignal(signalId);
        },
        [signals, dismissSignal]
    );

    return (
        <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
            {children}
            <SignalNotificationStack
                signals={signals}
                onDismiss={dismissSignal}
                onOptionSelect={handleOptionSelect}
            />
        </div>
    );
}
