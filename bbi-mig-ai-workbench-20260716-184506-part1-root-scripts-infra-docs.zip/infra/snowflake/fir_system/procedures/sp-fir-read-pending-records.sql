-- ============================================================
-- SP_FIR_READ_PENDING_RECORDS
-- Thin CRUD tool for AGT_FIR_SYSTEM: reads raw pending records.
-- The agent does ALL reasoning; this procedure just fetches data.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_READ_PENDING_RECORDS(
    "BATCH_SIZE" INTEGER DEFAULT 50,
    "PROCESSING_STAGE" VARCHAR DEFAULT 'pending'
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'read_pending_records'
EXECUTE AS OWNER
AS
$$
import json

def read_pending_records(session, batch_size: int = 50, processing_stage: str = 'pending') -> dict:
    """Read raw pending records from TBL_AGENT_FIR_360 for agent processing."""
    results = session.sql("""
        SELECT
            f.FIR_RECORD_ID,
            f.FIR_RECORD_KEY,
            f.FEEDBACK_ID,
            f.SOURCE_TYPE,
            f.SOURCE_EVENT_TYPE,
            f.USER_ID,
            f.SESSION_ID,
            f.PROJECT_ID,
            f.STTM_ID,
            f.SEMANTIC_BUNDLE_ID,
            f.ENTITY_TYPE,
            f.ENTITY_IDS,
            f.FEEDBACK_PAYLOAD,
            f.INITIAL_CONFIDENCE,
            f.CURRENT_CONFIDENCE,
            f.TARGET_AGENTS,
            f.CONTEXT_KEY,
            f.SNAPSHOT_ID,
            f.MILESTONE,
            f.EVIDENCE_CONTEXT_ID,
            e.EVIDENCE_PAYLOAD AS CONTEXT_EVIDENCE,
            f.CREATED_AT
        FROM __STTM_METADATA_NAMESPACE__.TBL_AGENT_FIR_360 f
        JOIN __STTM_METADATA_NAMESPACE__.TBL_FIR_CONTEXT_EVIDENCE e
          ON e.EVIDENCE_CONTEXT_ID = f.EVIDENCE_CONTEXT_ID
        WHERE f.PROCESSING_STAGE = ?
          AND f.EVIDENCE_CONTEXT_ID IS NOT NULL
          AND e.EVIDENCE_STATUS = 'ready'
        ORDER BY COALESCE(f.FEEDBACK_PAYLOAD:priority::BOOLEAN, FALSE) DESC,
                 f.CREATED_AT ASC
        LIMIT ?
    """, [processing_stage, batch_size]).collect()

    records = []
    for row in results:
        record = {
            'fir_record_id': row['FIR_RECORD_ID'],
            'fir_record_key': row['FIR_RECORD_KEY'],
            'feedback_id': row['FEEDBACK_ID'],
            'source_type': row['SOURCE_TYPE'],
            'source_event_type': row['SOURCE_EVENT_TYPE'],
            'user_id': row['USER_ID'],
            'session_id': row['SESSION_ID'],
            'project_id': row['PROJECT_ID'],
            'sttm_id': row['STTM_ID'],
            'semantic_bundle_id': row['SEMANTIC_BUNDLE_ID'],
            'entity_type': row['ENTITY_TYPE'],
            'entity_ids': row['ENTITY_IDS'],
            'feedback_payload': json.loads(row['FEEDBACK_PAYLOAD']) if isinstance(row['FEEDBACK_PAYLOAD'], str) else row['FEEDBACK_PAYLOAD'],
            'initial_confidence': row['INITIAL_CONFIDENCE'],
            'current_confidence': row['CURRENT_CONFIDENCE'],
            'target_agents': row['TARGET_AGENTS'],
            'context_key': row['CONTEXT_KEY'],
            'snapshot_id': row['SNAPSHOT_ID'],
            'milestone': row['MILESTONE'],
            'evidence_context_id': row['EVIDENCE_CONTEXT_ID'],
            'context_evidence': json.loads(row['CONTEXT_EVIDENCE']) if isinstance(row['CONTEXT_EVIDENCE'], str) else row['CONTEXT_EVIDENCE'],
            'created_at': str(row['CREATED_AT']) if row['CREATED_AT'] else None
        }
        records.append(record)

    return {
        'status': 'success',
        'record_count': len(records),
        'processing_stage': processing_stage,
        'records': records
    }
$$;
