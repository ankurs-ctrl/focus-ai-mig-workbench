# Auto-map v3 implementation and validation

Working branch: `sync/uat-frontend-native-integration`, local base `09e39f3`.
Date: 2026-11-05 (Asia/Kolkata).

## Changes

- Removed native Auto-map routing, runtime/RPC/store modules, experimental agents' source artifacts, deployment renderer settings, native scripts and tests. Kept `semantic_registry_native.py`. The UAT workflow and UAT profile already lacked the native-install step/profile on this branch.
- Extracted strict JSON/VARIANT helpers, proposal compilation, non-executable guidance, and explicit DEV-only local SSO/PAT support into generic modules.
- Hydrated registry YAML descriptions, synonyms, types and samples into physical attributes while preserving authored meanings. Computed YAML metrics remain semantic knowledge rather than fabricated physical columns. Non-executable YAML survives under `semantic_knowledge`.
- Added an immutable cached column catalog, also recorded in persisted bundle artifacts. Added deterministic BM25-style/name/synonym/type/graph reciprocal-rank-fusion ranking and precedent admission. Initial candidate budgets are 15, 10 and 6.
- Added shared business context, exposed CTE meanings, join graph, Values roster and table recommendations to packets. Packing trims the compact index and samples first, retains descriptions/Values, and reports its manifest. The normal target is 80 KB; required evidence may use configured headroom. Oversized mandatory evidence remains unresolved when the bounded read/call budget cannot establish it.
- Added batched latest-publication FIR retrieval, T1–T4 ranking, applicability and expression-shape deduplication. Search is a fallback; fallback and other-CRM recipes are guidance. Scoped corrections remain governed by the existing negative-evidence path.
- Preserved scope/recency in canonical retrieval, propagated publication CRM/logical target metadata, added HUBSPOT fallback, and added idempotent republish supersession plus a separate backfill SQL preparation tool.
- Aligned the source-agent protocol with admitted sources, Values, citations, precedent decisions, rule intent and a single evidence round. Source calls are capped at three, including repair. Invalid or absent packet receipts require human review. A single explicit CASE distribution question can reach the existing prepared read-only Analyst boundary.
- Removed the mandatory scan-agent dependency. Fast calls can use authenticated same-caller REST with a process semaphore, or explicitly configured durable admission. Both paths have bounded calls and deadlines. The process semaphore is not an account-wide limit.
- Expanded transformation scope to the target's server-admitted candidates and approved Values, included referenced CTE SQL/semantics/samples and uncited recipes, and re-derived dependencies with sqlglot before compilation. Rules have generation plus one repair and a 12k-token agent budget.
- Added an explicit `--allow-runtime-changes` preparation flag and model/budget diff to spec synchronization. No model upgrade was selected without an accuracy benchmark.

Product UI source, layout, styling and review controls were not changed. The retired native frontend test was removed; existing review/preservation tests were executed unchanged.

## Local verification

The combined regression run passed **2,419 tests** (1,277 unrelated tests deselected). The unchanged frontend review and preservation suites passed **48 + 29 tests**. Follow-up packet and deadline checks passed **80 + 2 tests**; publication/recipe checks passed **28 tests**. Tests that encoded the old 64-call/multi-round behavior were updated to check bounded unresolved outcomes, current packet samples, 150k rollout headroom, and configurable concurrency. Protocol-parser and uncertain-transport checks remain covered.

Commands (from the repository root, with the available Python environment):

```sh
PYTHONPATH=.:services/sttm-builder python -m pytest -q services/sttm-builder/tests/unit/core services/sttm-builder/tests/test_automap_runtime.py services/sttm-builder/tests/test_automap_fast_transport.py services/sttm-builder/tests/test_automap_fast_job.py -k 'automap or target_mapping or publish or semantic'
node frontend/scripts/test-automap-review-v8.cjs
node frontend/scripts/test-automap-preservation.cjs
```

The checked-in UAT service render and PowerShell workflow parser tests run without deploying. Source and transformation spec hashes are pinned in `agent_spec_manifest.json`.

## Read-only checks against this machine's test account

Authenticated using the existing local PAT without displaying or copying it into the repository. Account `OI30704`, database `FFP_HDP_CRM_MIG_DB_DEV`, schema `SCH_STTM_METADATA`, role `FOCUS_ADMIN`. This is separate from the client's DEV/UAT accounts.

- Source and transformation agents exist. Retired native agents also still exist; no objects were dropped.
- The metadata schema has `SEM_TABLE_VIEWS` and `SEM_COLUMN_VIEWS`. After the user supplied the external registry location, confirmed and configured `FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS`; the earlier metadata-only absence check was insufficient.
- The database contains four published version-ledger rows and one active published pattern. The most common legacy recipe rows have empty physical target-table keys.
- The new learning-pack SQL compiled and executed. Two stored Redtail recipes for `HOUSEHOLD_TYPE__C` and `PARENTID` were retrieved from the test account. They lack publication-version IDs, so they remain explicit legacy guidance rather than verified latest-publication precedents.
- All eleven FIR tasks in the metadata schema are suspended. No FIR task history was returned for the past seven days. There are 894 stored FIR recommendations; task suspension does not prevent reading existing learning. Task state was not changed.
- Client answer-key mappings `10301` and `3102` are absent. Client project IDs must not be assumed to identify equivalent data here.

## Benchmark and rollout work that remains

The client accepted answer key is absent from this test account. The external native registry is now configured and tested. No client business accuracy or master-baseline comparison is claimed. A generated identity contract was exercised against real registry semantics with the same packets for Haiku and Sonnet; results are below. Deployed agent specs remain unchanged, and local runtime can use hash-pinned request-scoped specs. Phase-B Search/embedding ranking remains off pending grants and measured recall improvement.

Offline scoring:

```sh
python scripts/benchmark_automap_v3.py --answer-key accepted.json --run run.json --packets packets.json --baseline baseline.json --output report.json
```

Inputs use canonical response mappings (or exported `mapping_rows`). Packet exports must be expanded JSON objects; without packets citation validity is reported as unknown. Master `fa449c4` and the original plan's develop baseline have not been measured in this checkout.

Prepare an idempotent backfill artifact, then review it before execution:

```sh
python scripts/prepare_automap_learning_backfill.py --namespace DATABASE.SCHEMA --output /tmp/automap-learning-backfill.sql
```

No Git commits, branch/archive writes, client-account deployment, data backfill, task enablement or object teardown was performed. These remain separate release operations. The plan explicitly requires approval for Git writes and object drops.

The UAT profile advertises eight worker requests but deliberately retains the existing four-permit durable pool inventory. Account-wide model concurrency remains four until an approved pool resize; changing a number in configuration cannot provision extra permits. The independent runtime defaults to eight calls in flight per process when durable admission is disabled.

## Completed local live validation after the registry correction

Non-secret local overrides: `infra/snowflake/env/local.automap-v3.env`. They select
`FOCUS_DB_2.STTM_MCP` for registry reads and preserve the workbench metadata/FIR
namespace. `scripts/run_automap_v3_local.py` reads existing credentials into the
process environment without copying secrets to a new file. DEV-only request-scoped
specs are hash-checked and leave deployed agents unchanged.

The registry-backed fixture selected 33 loan-calculation fields and four portal-history
fields, across ten batches. All admitted candidates had non-name-echo descriptions.
Actual wire packets ranged from 37,479 to 79,414 bytes, below the 80 KB target.
Prep took 12.641 seconds in this run.

| Model | Decisions / exact identity matches | Invalid citations | Missing valid citation | Model wall time |
| --- | --- | --- | --- | --- |
| claude-haiku-4-5 | 37 / 37 | 0 | 0 | 24.585 s |
| claude-sonnet-4-5 | 37 / 37 | 13 | 0 | 82.991 s |

**Decision:** keep Haiku. Sonnet failed the zero-invalid-citation gate on this test.
The identity fixture validates semantic transport and protocol adherence; it does
not establish Ft. Pitt mapping accuracy. These calls used stateless request-scoped
specs, not modified deployed agents. See `local-model-benchmark.json`.

Two additional live Haiku transformation fixtures passed scalar-expression, admitted
scope, local compiler validity and readiness checks: CASE with an admitted extra
column (9.025 s), and COALESCE with an approved Value placeholder (19.759 s).
No generated SQL was executed. See `local-rule-validation.json`.

The local backend started with the test profile and returned `status: ok` with the
current source and transformation template hashes. See `local-backend-health.json`.
The three backfill UPDATE statements passed Snowflake EXPLAIN without executing updates.

The completion audit additionally corrected four-target batching (37 -> 10 batches),
connected join/CTE ranking signals, emitted candidate reasons, protected the mandatory
correction quota, retained completed packet trims, added parallel same-caller Search,
added profile-cache sample fallback, and fixed benchmark extraction of production packets.

A read-only teardown preparation utility is provided at
`docs/automap-v3/prepare_native_teardown.py`. It backs up both agent specs and prepares
an exact object inventory and DROP SQL; it never executes DROP statements. It has not
been run because release acceptance and explicit teardown approval are still pending.

## Final regression after the completion audit

- Broad Auto-map, semantics, FIR/publish, runtime and job selection: **2,431 passed**,
  1,277 unrelated tests deselected (142.75 s).
- Final targeted semantic/ranking/packet/audit checks: **92 passed**.
- Unchanged frontend review suite: **48 passed**; previous unchanged preservation
  suite: **29 passed**.
- Python compilation, exact spec hashes, product-UI unchanged check and native-code
  removal checks passed. Repository CRLF line endings are retained; whitespace check
  uses `git -c core.whitespace=cr-at-eol diff --check`.

The local launcher was health-checked on loopback. Both temporary backend processes were stopped after verification; no mappings were submitted to them.


Local reproduction (use an existing credential file; do not paste a PAT into a command):

```sh
python scripts/run_automap_v3_local.py --credential-env /absolute/path/to/existing/.env.local
python scripts/validate_automap_v3_live.py --credential-env /absolute/path/to/existing/.env.local --output-dir /tmp/automap-v3-new-run --live
```

The first command keeps the backend on loopback port 8103 until stopped. The second
uses the default non-secret local profile and produces private local packets plus a
report. It leaves deployed agents, mappings, and registry tables unchanged.
