from types import SimpleNamespace

from app.core.project_service import ProjectService
from app.schema.project import (
    ProjectCreateFromTemplateRequest,
    ProjectRecord,
    ProjectTemplateRecord,
    ProjectTemplateTarget,
    STTMRecord,
)


class _TransactionQuery:
    def collect(self):
        return []


class _TransactionSession:
    def __init__(self) -> None:
        self.statements: list[str] = []

    def sql(self, statement: str):
        self.statements.append(statement)
        return _TransactionQuery()


def _service() -> ProjectService:
    service = ProjectService.__new__(ProjectService)
    service._settings = SimpleNamespace()
    service._session = _TransactionSession()
    service.ensure_storage_exists = lambda: None
    return service


def _template() -> ProjectTemplateRecord:
    return ProjectTemplateRecord(
        template_id="CRM_MIGRATION",
        template_version="1.0",
        label="CRM Migration",
        source_systems=["REDTAIL", "OTHER"],
        target_contract_id="CRM_COMMON_TARGET",
        target_contract_version="1.0",
        target_database="CLIENT_DB",
        target_schema="SALESFORCE",
        available_targets=[
            ProjectTemplateTarget(
                logical_target_key="CRM.HOUSEHOLD",
                table_name="HOUSEHOLD",
                physical_fqn="CLIENT_DB.SALESFORCE.HOUSEHOLD",
                columns=[{"name": "HOUSEHOLD_ID", "type": "NUMBER", "primary_key": True}],
                column_count=1,
            ),
            ProjectTemplateTarget(
                logical_target_key="CRM.CALLS",
                table_name="CALLS",
                physical_fqn="CLIENT_DB.SALESFORCE.CALLS",
                columns=[{"name": "CALL_ID", "type": "NUMBER", "primary_key": True}],
                column_count=1,
            ),
        ],
        missing_targets=[],
    )


def test_template_bootstrap_creates_target_locked_shells_without_fir() -> None:
    service = _service()
    service.get_project_templates = lambda **_kwargs: [_template()]
    service.list_projects = lambda: []
    created_payloads = []
    project = ProjectRecord(project_id="project-1", project_name="Migration")

    def create_project(payload, **kwargs):
        assert kwargs["emit_fir"] is False
        assert payload.metadata["source_system_key"] == "REDTAIL"
        return project.model_copy(update={"metadata": payload.metadata})

    def create_sttm(project_id, payload, **kwargs):
        assert project_id == "project-1"
        assert kwargs["emit_fir"] is False
        created_payloads.append(payload)
        return STTMRecord(
            sttm_id=f"sttm-{len(created_payloads)}",
            project_id=project_id,
            sttm_name=payload.sttm_name,
            target_table=payload.target_table.qualified_name,
            metadata=payload.metadata,
        )

    service.create_project = create_project
    service.create_sttm = create_sttm

    result = service.create_project_from_template(
        ProjectCreateFromTemplateRequest(
            project_name="Migration",
            source_system_key="REDTAIL",
            idempotency_key="bootstrap-123",
        ),
        user_id="user-1",
    )

    assert [item.target_table for item in result.mappings] == [
        "CLIENT_DB.SALESFORCE.HOUSEHOLD",
        "CLIENT_DB.SALESFORCE.CALLS",
    ]
    assert created_payloads[0].metadata["logical_target_table_key"] == "CRM.HOUSEHOLD"
    snapshot = created_payloads[0].workspace_snapshot.model_dump(mode="json")
    assert snapshot["mapping_rows"][0]["target_column"] == "HOUSEHOLD_ID"
    assert service._session.statements == ["BEGIN", "COMMIT"]


def test_empty_project_is_allowed_when_target_schema_has_no_tables() -> None:
    service = _service()
    empty_template = _template().model_copy(update={"available_targets": []})
    service.get_project_templates = lambda **_kwargs: [empty_template]
    service.list_projects = lambda: []
    service.create_project = lambda payload, **_kwargs: ProjectRecord(
        project_id="project-1",
        project_name=payload.project_name,
        metadata=payload.metadata,
    )

    result = service.create_project_from_template(
        ProjectCreateFromTemplateRequest(
            project_name="Exception",
            source_system_key="OTHER",
            bootstrap_mode="EMPTY",
            idempotency_key="bootstrap-empty",
        ),
        user_id="user-1",
    )

    assert result.mappings == []
    assert result.bootstrap_status == "COMPLETE"


def test_json_contract_restricts_approved_tables_and_columns() -> None:
    service = ProjectService.__new__(ProjectService)
    service._settings = SimpleNamespace(
        crm_target_tables="IGNORED_TABLE",
        crm_target_contract_json=(
            '{"tables":{"HOUSEHOLD":{"columns":['
            '{"name":"HOUSEHOLD_ID","semantic_role":"primary_key"},'
            '"NAME"]}}}'
        ),
    )

    tables, columns = service._crm_target_contract()

    assert tables == ["HOUSEHOLD"]
    assert [item["name"] for item in columns["HOUSEHOLD"]] == [
        "HOUSEHOLD_ID",
        "NAME",
    ]
    assert columns["HOUSEHOLD"][0]["semantic_role"] == "primary_key"
