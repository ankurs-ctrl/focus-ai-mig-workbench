# BBI Migration Workbench: Backend and App Architecture

## 1. Purpose of this document

This document explains how the current STTM workbench application is structured, how the frontend and backend connect, how Snowflake sessions and agents are used, and how the app is run locally and deployed to Snowpark Container Services (SPCS).

It is written as a KT guide, so the focus is:

- where code lives
- what each major folder does
- how one request flows through the system
- how to add a new API endpoint
- how backend logic is connected to frontend pages
- how Snowflake sessions, Cortex Analyst, and Cortex Agents are called
- how local and SPCS runtime behavior differ
- which scripts are used for local start, bootstrap, and deployment

The examples below refer to the current implementation in this repository.

## 2. High-level architecture

The app is split into a few main layers:

1. `frontend/`
   - Next.js application
   - renders UI
   - calls backend APIs
   - maintains page-level and workflow state

2. `services/sttm-builder/`
   - the main backend for the workbench
   - FastAPI application
   - contains API routers, business logic, auth/session handling, Snowflake integrations, agent/analyst clients, guardrails, and export logic

3. `nginx/`
   - reverse proxy container used in SPCS
   - public entrypoint in deployed mode
   - routes browser traffic to frontend and backend containers

4. `infra/snowflake/`
   - Snowflake-specific infrastructure assets
   - SQL bootstrap scripts
   - agent specs
   - SPCS service-spec templates
   - environment templates

5. `scripts/`
   - local startup scripts
   - connection/configuration scripts
   - deployment scripts
   - helper automation for Snowflake/SPCS setup

6. `backend/`
   - older backend code also present in repo
   - not the primary runtime used by the current STTM workbench app
   - for the current app, the active backend is `services/sttm-builder/`

## 3. Repo structure and what each folder contains

### 3.1 Top-level folders

- `frontend/`
  - current UI application
- `services/sttm-builder/`
  - current FastAPI backend
- `nginx/`
  - NGINX container config for deployed routing
- `infra/`
  - Snowflake infra, service specs, SQL, env templates
- `scripts/`
  - startup and deployment scripts
- `docs/`
  - documentation and KT material
- `release-packages/`
  - packaged deliverables / deployment bundles
- `artifacts/`
  - generated deployment/service-spec outputs
- `buildspecs/`
  - build-related specs

### 3.2 Backend structure: `services/sttm-builder/app/`

This is the most important folder for the backend.

- `main.py`
  - FastAPI application entrypoint
  - creates the app
  - configures middleware, CORS, health endpoints, and routers

- `api/`
  - dependency wiring for services and Snowflake clients
  - `deps.py` is the main composition layer

- `routers/`
  - each file defines a route group / API surface
  - examples:
    - `table_selection.py`
    - `conversation.py`
    - `sttm_builder.py`
    - `mapping_sql.py`
    - `derived_source.py`
    - `dbt_conversion.py`
    - `export_workbook.py`

- `core/`
  - main business logic
  - Snowflake access
  - agent invocation
  - conversation flow
  - auto-mapping proxy
  - SQL generation / validation / preview

- `auth/`
  - auth routes
  - principal resolution
  - persona resolution
  - ingress-header extraction
  - custom Snowflake OAuth flow
  - session persistence

- `schema/`
  - Pydantic models and request/response contracts
  - typed envelopes and domain models

- `guardrails/`
  - governance, routing, preflight/postflight controls, model boundary checks

- `debug/`
  - debug endpoints/utilities when enabled

### 3.3 Frontend structure: `frontend/src/`

- `app/`
  - Next.js App Router pages and layouts
  - examples:
    - `app/layout.tsx`
    - `app/landing/page.tsx`
    - `app/dashboard/page.tsx`
    - `app/sttm/builder/new/page.tsx`
    - `app/sttm/builder/new/mapping/page.tsx`
    - `app/sttm/builder/new/summary/page.tsx`

- `features/`
  - domain-specific UI and state
  - STTM screens/components/store/context live here

- `services/`
  - frontend-side API wrappers
  - examples:
    - `dbService.ts`
    - `workbenchService.ts`
    - `authService.ts`

- `api/`
  - axios/fetch setup
  - route constants
  - error normalization

- `contexts/`
  - React contexts

- `hooks/`
  - reusable React hooks

- `store/`
  - Redux hooks/store slices

- `types/`
  - frontend contract types

## 4. Main application entry points

### 4.1 Backend entry point

File:

- `services/sttm-builder/app/main.py`

Responsibilities:

- create `FastAPI()` app
- load settings from `app.core.config`
- install guardrails middleware
- configure CORS
- include all API routers
- expose health endpoints

In other words, if someone asks, "Where does the backend start?", this is the answer.

### 4.2 Frontend entry point

Files:

- `frontend/src/app/layout.tsx`
- `frontend/src/app/Providers.tsx`

Responsibilities:

- global HTML/body layout
- app header and shell
- global providers (theme/store/etc.)
- wraps all pages

For the STTM builder workflow specifically, a common entry page is:

- `frontend/src/app/sttm/builder/new/page.tsx`

That page mounts the source/target selection UI and begins the builder workflow.

## 5. Standard backend API pattern

The backend generally follows this pattern:

1. Router receives request
2. Request payload is validated using Pydantic schema
3. Router gets service instance via dependency injection from `app/api/deps.py`
4. Core service executes business logic
5. Core service uses Snowflake client / agent client / other helpers
6. Router wraps response using the standard response envelope

This is intentionally layered:

- routers stay thin
- core services hold behavior
- schema layer holds contracts
- deps layer wires everything together

## 6. Standard request/response envelope

File:

- `services/sttm-builder/app/schema/contracts.py`

This file defines the standard payload envelope used across backend APIs.

Main models:

- `ApiRequestEnvelope[TData]`
- `ApiResponseEnvelope[TData]`
- `ApiActor`
- `ApiWarning`
- `ApiError`

Important helpers:

- `resolve_request_id(...)`
- `build_response_envelope(...)`

That means POST endpoints usually accept and return a structured payload like:

```json
{
  "contract_version": "1.0",
  "request_id": "...",
  "operation": "table_selection.list_databases",
  "actor": null,
  "context": {},
  "data": {},
  "warnings": [],
  "error": null,
  "meta": {}
}
```

This contract is important because frontend services are written around it.

## 7. Example endpoint walkthrough: list databases

This is the cleanest example to explain how a new endpoint is wired.

### 7.1 Frontend caller

File:

- `frontend/src/services/dbService.ts`

The frontend uses:

- `API_ROUTES.tableSelection.databases`
- `buildApiEnvelope(...)`
- `postEnvelopeData(...)`

So the frontend does not hardcode raw URLs everywhere. It builds a standard envelope and posts it to the backend.

### 7.2 API route constant

File:

- `frontend/src/api/routes.ts`

Relevant constant:

```ts
tableSelection: {
  databases: '/v1/table-selection/databases',
}
```

### 7.3 Frontend HTTP client

File:

- `frontend/src/api/axiosInstance.ts`

This file decides the API base URL:

- local browser -> direct backend origin, usually `http://127.0.0.1:8000/api`
- deployed mode -> relative `/api`, letting NGINX/SPCS route internally

It also:

- applies global timeout
- unwraps standard envelopes
- normalizes API errors

### 7.4 Backend router

File:

- `services/sttm-builder/app/routers/table_selection.py`

Relevant route:

- `POST /api/v1/table-selection/databases`

This route:

- accepts a typed request envelope
- injects `TableSelectionService`
- calls `service.list_databases()`
- wraps output using `build_response_envelope(...)`

The router itself is intentionally thin.

### 7.5 Dependency injection

File:

- `services/sttm-builder/app/api/deps.py`

Relevant dependency:

- `get_table_selection_service(...)`

That dependency builds the `TableSelectionService`, usually by first creating a `SnowflakeClient`.

This is where wiring happens. Routers should not manually construct deep dependency graphs.

### 7.6 Core business logic

File:

- `services/sttm-builder/app/core/table_selection.py`

Method:

- `list_databases()`

This method executes Snowflake SQL:

- `SHOW TERSE DATABASES`

and transforms the result into the response shape the UI expects.

This same service also supports:

- schemas
- tables
- attributes
- relationships

### 7.7 Snowflake execution

File:

- `services/sttm-builder/app/core/snowflake.py`

The `SnowflakeClient` is responsible for opening a usable Snowflake connection/session based on the current auth mode and runtime environment.

So the full chain is:

`Frontend page -> dbService -> axiosInstance -> FastAPI router -> deps -> TableSelectionService -> SnowflakeClient -> Snowflake SQL`

## 8. Richer example: conversation / AI path

The builder workbench also has a richer route family for AI-assisted workflows.

Files:

- `services/sttm-builder/app/routers/conversation.py`
- `services/sttm-builder/app/core/conversation.py`

The conversation router handles endpoints such as:

- `/api/v1/workbench/conversation/invoke`
- `/api/v1/workbench/conversation/invoke/stream`
- `/api/v1/workbench/conversation/signals`
- `/api/v1/workbench/conversation/signals/evaluate`

This route family is more advanced than table selection because it includes:

- governance preflight
- actor injection
- route planning
- memory / RAG integration
- handoff to STTM builder service
- streaming SSE responses

Important design pattern:

- router performs normalization and preflight
- `ConversationService` decides what to do
- it may:
  - answer directly
  - record feedback
  - evaluate assistant signals
  - hand off to another service/agent path

This is a good example for teammates to understand how “AI” behavior is orchestrated instead of being embedded directly in a route function.

## 9. How frontend integrates with backend

There are a few consistent frontend integration patterns.

### 9.1 Route constants

File:

- `frontend/src/api/routes.ts`

All backend paths should be registered here first.

### 9.2 Shared HTTP client

File:

- `frontend/src/api/axiosInstance.ts`

All standard HTTP traffic goes through this layer.

It gives:

- consistent base URL handling
- consistent envelope support
- global error handling

### 9.3 Feature service wrapper

Example files:

- `frontend/src/services/dbService.ts`
- `frontend/src/services/workbenchService.ts`
- `frontend/src/services/authService.ts`

This layer is the frontend equivalent of “API client abstractions”.

Pages and components generally should not call `fetch()` or `axios.post()` directly when a reusable service already exists.

### 9.4 Workflow state management

For STTM pages, a lot of orchestration happens in:

- `frontend/src/features/sttm/context/sttm-builder-context.tsx`
- Redux slice(s) under `frontend/src/features/sttm/store/`

This context:

- loads databases on mount
- loads derived sources
- reacts to selected sources/targets
- triggers assistant signal evaluation
- dispatches async thunks like auto-map, chat, relationship fetch, etc.

So the backend is typically reached from:

`Page -> Context / Store thunk -> frontend service -> backend endpoint`

## 10. How to add a new backend endpoint

This is the safest pattern to follow.

### Step 1: Define or extend schema models

Add request/response types under:

- `services/sttm-builder/app/schema/`

If it is a POST operation, prefer typed envelopes around a typed `data` payload.

### Step 2: Add core service logic

Implement the actual behavior in a core module under:

- `services/sttm-builder/app/core/`

Example:

- if you are adding a “list X” backend operation, create a method in the relevant service class
- keep Snowflake access and transformation logic here

### Step 3: Add dependency wiring if needed

If the router needs a new service or a differently configured service, update:

- `services/sttm-builder/app/api/deps.py`

This keeps construction logic centralized.

### Step 4: Add router endpoint

Add the route under the relevant file in:

- `services/sttm-builder/app/routers/`

Guidelines:

- keep the route thin
- validate input with schema types
- inject service with `Depends(...)`
- return `build_response_envelope(...)`

### Step 5: Register router if it is a new router file

If it is a brand new route group, include it in:

- `services/sttm-builder/app/api/__init__.py`

### Step 6: Add frontend route constant

Update:

- `frontend/src/api/routes.ts`

### Step 7: Add frontend service function

Update or create a service in:

- `frontend/src/services/`

Use:

- `getApiData(...)`
- `postApiData(...)`
- `postEnvelopeData(...)`
- `buildApiEnvelope(...)`

### Step 8: Integrate into UI/store

Wire the frontend service into:

- a page
- a React context
- a Redux thunk/slice
- or a component event handler

### Step 9: Test locally

Verify:

- backend route works directly
- frontend service unwraps the response correctly
- errors are formatted properly
- any auth mode differences are accounted for

## 11. Auth and session handling

This is one of the most important parts of the system.

### 11.1 Main auth files

- `services/sttm-builder/app/auth/router.py`
- `services/sttm-builder/app/auth/dependencies.py`
- `services/sttm-builder/app/auth/custom_oauth.py`
- `services/sttm-builder/app/auth/extractors/headers.py`
- `services/sttm-builder/app/auth/persona/resolver.py`
- `services/sttm-builder/app/auth/models.py`

### 11.2 Auth modes in current design

The backend is designed to support multiple modes through config.

Main settings are defined in:

- `services/sttm-builder/app/core/config.py`

Important flags:

- `AUTH_MODE`
- `LOCAL_DEV_AUTH_ENABLED`
- `SPCS_EXECUTE_AS_CALLER_ENABLED`

### 11.3 Local development mode

In local mode, the backend can use developer credentials from local env.

Typical pattern:

- local env file: `services/sttm-builder/.env.local`
- backend can connect as the developer using:
  - username/password, or
  - `externalbrowser`

This is why local development can work without Snowflake ingress headers.

### 11.4 SPCS ingress-header mode

In deployed SPCS mode, the older/main deployment pattern uses Snowflake ingress headers such as:

- `Sf-Context-Current-User`
- `Sf-Context-Current-User-Email`
- `Sf-Context-Current-User-Token`

File:

- `services/sttm-builder/app/auth/extractors/headers.py`

These are used to resolve the caller identity and caller token.

### 11.5 Custom Snowflake OAuth mode

The repo also contains a custom OAuth flow.

File:

- `services/sttm-builder/app/auth/custom_oauth.py`

This flow supports:

- login redirect
- callback/code exchange
- refresh-token handling
- encrypted server-side session persistence
- session lookup from backend cookie

Session metadata is stored in a Snowflake table configured by:

- `SNOWFLAKE_OAUTH_SESSIONS_TABLE`

### 11.6 Principal and persona resolution

Once the backend has enough identity context, it resolves app persona using:

- `services/sttm-builder/app/auth/persona/resolver.py`

This resolver reads/writes the users metadata table and maps the user into app personas such as:

- `ADMIN`
- `PUBLISHER`
- `VIEWER`

It is also designed to tolerate some metadata column drift by inspecting the table definition dynamically.

## 12. How Snowflake sessions are created

Main file:

- `services/sttm-builder/app/core/snowflake.py`

This file is the center of Snowflake session strategy.

### 12.1 What this file does

It decides:

- whether the app is in local dev or deployed mode
- whether it should use local dev credentials
- whether it should use a service token
- whether it should use a caller token
- whether to combine service + user token for caller-rights SPCS mode

### 12.2 Common session paths

#### Local dev path

- reads local env
- uses local Snowflake credentials
- may use cached local connection behavior

#### SPCS caller-rights path

- reads SPCS runtime token from `/snowflake/session/token`
- reads caller token from ingress-derived context
- may construct an effective caller token depending on mode

#### Custom OAuth path

- uses the OAuth access token from the app session
- uses standard OAuth auth for Snowflake connector / REST clients

## 13. How agents and analyst are called

There are two main categories:

1. Snowflake connector / SQL / Snowpark operations
2. Snowflake REST-based AI services

### 13.1 Dependency creation

File:

- `services/sttm-builder/app/api/deps.py`

This file creates:

- Snowflake SQL client
- Snowflake agent client
- Snowflake analyst client
- higher-level services that use those clients

### 13.2 Agent/Analyst config

Main names come from settings in:

- `services/sttm-builder/app/core/config.py`

Examples:

- `SNOWFLAKE_STTM_BUILDER_AGENT`
- `SNOWFLAKE_SOURCE_MAPPING_AGENT`
- `SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT`
- `SNOWFLAKE_SEMANTIC_MODEL_AGENT`
- `SNOWFLAKE_DBT_CONVERSION_AGENT`
- `SNOWFLAKE_TEST_CASE_GENERATION_AGENT`

### 13.3 Conversation path to agents

The conversation flow eventually reaches:

- `ConversationService`
- `STTMBuilderService`
- Snowflake agent/analyst client(s)

This is where the system decides:

- direct answer
- semantic-context preparation
- handoff to STTM builder
- Cortex Analyst review
- Cortex Agent invocation

### 13.4 Why the design is split this way

This keeps:

- HTTP/API semantics in routers
- orchestration in core services
- low-level Snowflake transport logic in dedicated clients

That separation is important when debugging auth, token, role, REST, or agent issues.

## 14. Auto-mapping service split

There is support for running automap in a separate internal SPCS service.

Main file:

- `services/sttm-builder/app/core/auto_mapping_proxy.py`

What it does:

- checks whether `AUTO_MAPPING_SERVICE_URL` is configured
- only delegates when the intent is `AUTO_MAP`
- splits attributes into batches
- sends batches to the dedicated automap worker
- merges returned mappings
- handles batch failure and retries

Important detail:

- the proxy forwards Snowflake caller headers and OAuth headers to the internal service

Relevant service spec:

- `infra/snowflake/service-specs/automap-worker.yaml.tmpl`

This worker service is private/internal only and is intended to scale separately from the main webapp service.

## 15. Local startup flow

### 15.1 Main local launcher

File:

- `start-ai-workbench-dev.sh`

What it does:

- kills stale listeners on ports `3000` and `8000`
- starts backend via `scripts/start_sttm_backend_local.sh`
- starts frontend dev server

### 15.2 Backend local launcher

File:

- `scripts/start_sttm_backend_local.sh`

What it does:

- ensures `.env.local` exists
- syncs missing keys from `.env.example`
- validates local auth config
- creates virtual environment if needed
- installs backend dependencies if needed
- starts Uvicorn

This script is the best place for teammates to understand “what local backend assumptions exist”.

## 16. SPCS deployment flow

### 16.1 Main deploy script

File:

- `scripts/deploy_spcs_client_snow.sh`

What it does at a high level:

1. load env from `infra/snowflake/env/client.env`
2. validate/test Snow CLI connection
3. ensure compute pools exist
4. log Docker into Snowflake image registry
5. build backend/frontend/nginx images
6. push images to Snowflake registry
7. render service spec templates
8. create or upgrade SPCS services

### 16.2 Main webapp service spec

File:

- `infra/snowflake/service-specs/webapp.yaml.tmpl`

This template defines the public service with three containers:

- `sttm-builder` (backend)
- `frontend`
- `nginx`

It injects the full env surface used by the backend and frontend.

### 16.3 Automap worker service spec

File:

- `infra/snowflake/service-specs/automap-worker.yaml.tmpl`

This template defines the separate private worker service:

- one container: `automap-worker`
- private endpoint
- execute-as-caller enabled

### 16.4 Deployment-time env model

Key env values live under:

- `infra/snowflake/env/`

Examples include:

- account/database/schema/image registry settings
- auth mode
- OAuth URLs
- agent names
- metadata table names
- automap worker URL
- retry values

## 17. Local vs SPCS behavior

This is the most important operational difference to understand.

### Local

- frontend usually runs on `localhost:3000`
- backend runs on `127.0.0.1:8000`
- backend may use local Snowflake credentials
- frontend may bypass proxy and call backend directly

### SPCS

- browser enters through public ingress
- NGINX serves as front door
- frontend and backend run as sibling containers
- backend may use ingress caller context or custom OAuth session
- internal services can talk over Snowflake internal service DNS

### Why this matters

Some bugs only reproduce in SPCS because of:

- caller-rights behavior
- Snowflake role evaluation
- internal DNS/service URLs
- ingress token/header availability
- cookie domain/redirect URI issues
- OAuth callback configuration

## 18. Common code and utilities

The most reused cross-cutting files are:

- `services/sttm-builder/app/core/config.py`
  - runtime settings

- `services/sttm-builder/app/api/deps.py`
  - dependency graph / service construction

- `services/sttm-builder/app/schema/contracts.py`
  - standard request/response envelope

- `services/sttm-builder/app/core/snowflake.py`
  - Snowflake session strategy

- `frontend/src/api/axiosInstance.ts`
  - frontend HTTP client standardization

- `frontend/src/api/routes.ts`
  - central backend route registry

These are the best files to read first when onboarding.

## 19. Recommended reading order for a new teammate

If someone is new to the project, this is a good reading path:

1. `services/sttm-builder/app/main.py`
2. `services/sttm-builder/app/api/__init__.py`
3. `services/sttm-builder/app/api/deps.py`
4. `services/sttm-builder/app/core/config.py`
5. `services/sttm-builder/app/schema/contracts.py`
6. `services/sttm-builder/app/routers/table_selection.py`
7. `services/sttm-builder/app/core/table_selection.py`
8. `frontend/src/api/routes.ts`
9. `frontend/src/api/axiosInstance.ts`
10. `frontend/src/services/dbService.ts`
11. `frontend/src/app/sttm/builder/new/page.tsx`
12. `frontend/src/features/sttm/context/sttm-builder-context.tsx`

After that, move to:

13. `services/sttm-builder/app/routers/conversation.py`
14. `services/sttm-builder/app/core/conversation.py`
15. `services/sttm-builder/app/auth/custom_oauth.py`
16. `services/sttm-builder/app/core/auto_mapping_proxy.py`
17. `scripts/deploy_spcs_client_snow.sh`
18. `infra/snowflake/service-specs/webapp.yaml.tmpl`

## 20. Practical example: adding a new endpoint end-to-end

Suppose we want to add:

- `POST /api/v1/table-selection/table-stats`

### Backend

1. Add schema types in `app/schema/...`
2. Add `list_table_stats(...)` in `app/core/table_selection.py`
3. Add a route in `app/routers/table_selection.py`
4. Return `build_response_envelope(...)`
5. If needed, update `app/api/deps.py`

### Frontend

1. Add route constant in `frontend/src/api/routes.ts`
2. Add service function in `frontend/src/services/dbService.ts`
3. Call it from UI/store/context
4. Handle loading/error/success states in the relevant component

This is the exact repo-native pattern and should be preferred over inventing a parallel structure.

## 21. Key takeaways

- The current workbench backend lives in `services/sttm-builder/`, not `backend/`
- Routers are thin; core services do the real work
- `app/api/deps.py` is the central dependency-wiring file
- `app/core/snowflake.py` is the central Snowflake session strategy file
- Standard request/response envelopes are defined in `app/schema/contracts.py`
- Frontend integrates through `api/routes.ts`, `axiosInstance.ts`, and feature service files
- Local and SPCS differ primarily in auth/session source, routing, and Snowflake runtime behavior
- The repo already supports both:
  - all-in-one public webapp service
  - separate internal automap worker service

## 22. Suggested future KT additions

Good follow-up documents to create after this one:

1. agent-by-agent technical reference
   - STTM Builder
   - Source Mapping
   - Workbench Conversation
   - Semantic Model
   - DBT Conversion
   - Test Case Generation

2. Snowflake object inventory
   - tables
   - procedures
   - agents
   - Cortex Search services
   - OAuth/session tables

3. deployment troubleshooting runbook
   - OAuth issues
   - caller-rights issues
   - container startup failures
   - agent authorization issues
   - automap worker connectivity issues
