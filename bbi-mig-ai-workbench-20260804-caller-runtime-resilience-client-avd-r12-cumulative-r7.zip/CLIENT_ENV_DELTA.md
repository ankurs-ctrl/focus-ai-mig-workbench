# R12 environment delta

No new mandatory environment variables or Snowflake grants are required for the
R12 runtime fallbacks.

The bounded caller-mode inline artifact limit is optional and defaults to 1 MiB:

```dotenv
AGENT_CALLER_INLINE_FALLBACK_LIMIT_BYTES=1048576
```

The normal deployment scripts do not issue new caller, stage, or Cortex grants.
The administrator templates remain reference-only and are not executed by the
deployment flow.

R12 introduces no new tables, migrations, streams, or tasks.
