---
name: workbench-spreadsheets
description: Read attached Excel and CSV files containing source-to-target specifications, samples, and Firm Values.
---

Use search_run_attachments to identify relevant sheets and headers. Cite the sheet and row or cell range. Preserve identifiers and leading zeroes. Use a formula's cached result only when it is present. A formula can describe a rule but does not authorize executing it.

Distinguish source-to-target rows, Firm Values, and sample data by their headers and context. Verify source and target bindings through the current catalog. Apply Firm Values through the governed import action when the user requests a write.
