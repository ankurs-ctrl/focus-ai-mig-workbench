"use client";

import { useCallback, useState, type ReactNode } from "react";
import {
  AiAgentSendApiContext,
  AiAgentSendRegisterContext,
  idleSendApi,
  type AiAgentSendApi,
} from "@/features/ai-agent/use-ai-agent-send";

export function AiAgentSendBridgeProvider({ children }: { children: ReactNode }) {
  const [api, setApi] = useState<AiAgentSendApi>(idleSendApi);
  const register = useCallback((next: AiAgentSendApi) => {
    setApi(next);
  }, []);

  return (
    <AiAgentSendRegisterContext.Provider value={register}>
      <AiAgentSendApiContext.Provider value={api}>{children}</AiAgentSendApiContext.Provider>
    </AiAgentSendRegisterContext.Provider>
  );
}
