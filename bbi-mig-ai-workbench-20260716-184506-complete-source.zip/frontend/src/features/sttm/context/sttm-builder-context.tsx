"use client";

import { createContext, useContext, useEffect, useMemo, useRef, useState, useCallback } from "react";
import { usePathname } from "next/navigation";
import { dbService } from "@/services/dbService";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  abortPendingEvaluateSignals,
  clearAssistantSignalsForContext,
  evaluateFirRecommendations,
  fetchDatabases,
  fetchSchemas,
  fetchTables,
  fetchAttributes,
  fetchDerivedSources,
  fetchRelationships,
  runAutoMap as runAutoMapThunk,
  sendChatMessage as sendChatMessageThunk,
  submitChatFeedback as submitChatFeedbackThunk,
  respondToAssistantSignal as respondToAssistantSignalThunk,
  toggleSource as toggleSourceAction,
  selectTarget as selectTargetAction,
  selectAllSources as selectAllSourcesAction,
  clearSources as clearSourcesAction,
  clearTargets as clearTargetsAction,
  setDrivingTable as setDrivingTableAction,
  setRelationships as setRelationshipsAction,
  setSourceFilterConditions as setSourceFilterConditionsAction,
  addDerivedSource as addDerivedSourceAction,
  updateDerivedSource as updateDerivedSourceAction,
  removeDerivedSource as removeDerivedSourceAction,
  toggleDerivedSource as toggleDerivedSourceAction,
  openPendingDerivedSourceDraft as openPendingDerivedSourceDraftAction,
  acknowledgePendingDerivedSourceDraft as acknowledgePendingDerivedSourceDraftAction,
  dismissPendingDerivedSourceDraft as dismissPendingDerivedSourceDraftAction,
  resetChatSession as resetChatSessionAction,
  restoreChatSession as restoreChatSessionAction,
  applySemanticRefresh as applySemanticRefreshAction,
  initializeMappings as initializeMappingsAction,
  updateMapping as updateMappingAction,
  applyPendingAiMappingReview as applyPendingAiMappingReviewAction,
  skipPendingAiMappingReview as skipPendingAiMappingReviewAction,
  toggleMappingSelection as toggleMappingSelectionAction,
  selectAllMappings as selectAllMappingsAction,
  bulkMarkMapped as bulkMarkMappedAction,
  bulkSetDirect as bulkSetDirectAction,
  setPreProcessModalOpen as setPreProcessModalOpenAction,
  setMappingSql as setMappingSqlAction,
  setMappingPreviewSql as setMappingPreviewSqlAction,
  setMappingSqlVariant as setMappingSqlVariantAction,
  updateAssistantPreferences as updateAssistantPreferencesThunk,
  hydrateBuilderSession,
  type PersistedSttmBuilderSession,
} from "@/features/sttm/store/sttm-builder-slice";
import { getSelectedSourceTables } from "@/features/sttm/shared/sttm-selection-utils";
import type {
  DerivedSource,
  RuleGroup,
  SelectionSide,
  TableNode,
  SttmBuilderContextValue as ContextValue,
} from "@/features/sttm/types/sttm.types";
import type { SemanticLevel } from "@/types/api-contract";

const SttmBuilderContext = createContext<ContextValue | null>(null);
// v5 uses project+sttm scoped storage keys.
// v4 used a single localStorage key for all sessions.
const STTM_BUILDER_SESSION_BASE_KEY = "sttm-builder-session-v5";

/**
 * Build a storage key scoped by project and STTM IDs.
 * Format: sttm-builder-session-v5::{projectId}::{sttmId}
 * Falls back to base key for truly new sessions with no IDs yet.
 */
function getScopedStorageKey(projectId: string | null, sttmId: string | null): string {
  if (projectId && sttmId) {
    return `${STTM_BUILDER_SESSION_BASE_KEY}::${projectId}::${sttmId}`;
  }
  // Fallback for new sessions that haven't been saved yet
  return `${STTM_BUILDER_SESSION_BASE_KEY}::new`;
}

// Debounce times for different state categories
const CRITICAL_STATE_DEBOUNCE_MS = 250;    // mappings, relationships, sources/targets
const NON_CRITICAL_STATE_DEBOUNCE_MS = 5000; // chat, semantic context

export function SttmBuilderProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const dispatch = useAppDispatch();
  const state = useAppSelector((s) => s.sttmBuilder);
  const lastAssistantSignalSignature = useRef<string | null>(null);
  const signalEvaluationTimerRef = useRef<number | null>(null);
  const signalEvaluationInFlightRef = useRef(false);
  const queuedAssistantSignalEvaluationRef = useRef<{
    signature: string;
    activityType: string;
  } | null>(null);
  const semanticRefreshInFlightSignatureRef = useRef<string | null>(null);
  const lastSemanticRefreshSignatureRef = useRef<string | null>(null);
  const [sessionHydrated, setSessionHydrated] = useState(false);
  // Prevent double initialization during hydration
  const sessionHydrationPromiseRef = useRef<Promise<void> | null>(null);
  // Track last persisted state signatures to avoid redundant writes
  const lastCriticalStateSignatureRef = useRef<string | null>(null);
  const lastNonCriticalStateSignatureRef = useRef<string | null>(null);
  const criticalPersistTimerRef = useRef<number | null>(null);
  const nonCriticalPersistTimerRef = useRef<number | null>(null);

  const currentAssistantPage = useMemo(() => {
    if (pathname.includes("/summary")) return "summary";
    if (pathname.includes("/mapping")) return "mapping";
    return "builder";
  }, [pathname]);

  const currentAssistantSurface = currentAssistantPage === "mapping" ? "MAPPING" : "SOURCE_SELECTION";

  // Check if this is a "new" session (clear localStorage when navigating to /new)
  const isNewSession = pathname === "/sttm/builder/new";

  // Parallel hydration: read localStorage and prepare API calls simultaneously
  // NOTE: For existing STTMs, openSttmFromBackend loads state from backend, not localStorage.
  // localStorage is only used as a draft backup for NEW mappings that haven't been saved yet.
  useEffect(() => {
    // Prevent double initialization
    if (sessionHydrationPromiseRef.current) {
      return;
    }

    const hydrateSession = async () => {
      let parsedSession: PersistedSttmBuilderSession | null = null;

      // If this is a new session page, clear the "new" session storage to start fresh
      if (isNewSession) {
        try {
          // Clear the "new" session storage key
          const newSessionKey = getScopedStorageKey(null, null);
          window.localStorage.removeItem(newSessionKey);
          // Also clear old v4 key for migration
          window.localStorage.removeItem("sttm-builder-session-v4");
        } catch {
          // Ignore cleanup failures
        }
        // Don't hydrate - start fresh
        setSessionHydrated(true);
        return;
      }

      // Step 1: Read localStorage
      // For non-new sessions (returning to builder, page refresh), try to restore draft state
      // Priority: scoped key (if IDs exist in session) > "new" key > legacy v4 key
      const newSessionKey = getScopedStorageKey(null, null);
      const legacyKey = "sttm-builder-session-v4";

      try {
        // First try the "new" session key (most common for work-in-progress)
        let rawSession = window.localStorage.getItem(newSessionKey);

        // If no "new" session, check for legacy v4 key and migrate
        if (!rawSession) {
          rawSession = window.localStorage.getItem(legacyKey);
          if (rawSession) {
            // Migrate: remove old key after reading
            window.localStorage.removeItem(legacyKey);
          }
        }

        if (rawSession) {
          parsedSession = JSON.parse(rawSession) as PersistedSttmBuilderSession;

          // If session has project/sttm IDs, check for a scoped key and prefer it
          if (parsedSession.activeProjectId && parsedSession.activeSttmId) {
            const scopedKey = getScopedStorageKey(
              parsedSession.activeProjectId,
              parsedSession.activeSttmId
            );
            const scopedSession = window.localStorage.getItem(scopedKey);
            if (scopedSession) {
              try {
                const scopedParsed = JSON.parse(scopedSession) as PersistedSttmBuilderSession;
                // Use scoped session if it's newer
                if (scopedParsed.sessionSavedAt && parsedSession.sessionSavedAt) {
                  if (new Date(scopedParsed.sessionSavedAt) > new Date(parsedSession.sessionSavedAt)) {
                    parsedSession = scopedParsed;
                  }
                }
              } catch {
                // Ignore parsing errors for scoped key
              }
            }
          }
        }
      } catch (error) {
        console.warn("Unable to restore STTM builder draft session.", error);
        parsedSession = null;
      }

      // Step 2: Dispatch hydration if we have a session (non-blocking)
      if (parsedSession) {
        dispatch(hydrateBuilderSession(parsedSession));
      }

      // Hydration complete - API calls will happen in a separate effect
      setSessionHydrated(true);
    };

    sessionHydrationPromiseRef.current = hydrateSession();
  }, [dispatch, isNewSession]);

  // Load databases only when the user is inside the STTM builder.
  // The provider is mounted globally (for ChatWidget), so we guard here
  // to avoid hitting Snowflake on every page load (Projects, Dashboard, etc.).
  const isInSttmBuilder = pathname.startsWith("/sttm");

  // Parallel data fetching - dispatch both thunks simultaneously
  // The thunks themselves check cache freshness and skip if data is < 5 minutes old
  useEffect(() => {
    if (!sessionHydrated || !isInSttmBuilder) {
      return;
    }
    // Dispatch both in parallel - thunks will self-skip if cache is fresh
    void Promise.all([
      dispatch(fetchDatabases()),
      dispatch(fetchDerivedSources()),
    ]);
  }, [dispatch, sessionHydrated, isInSttmBuilder]);

  const persistedBuilderSession = useMemo<PersistedSttmBuilderSession>(() => ({
    sourceDatabases: state.sourceDatabases,
    targetDatabases: state.targetDatabases,
    cacheMetadata: state.cacheMetadata,
    sources: state.sources,
    targets: state.targets,
    sourceInfo: state.sourceInfo,
    targetInfo: state.targetInfo,
    sourceAttributeGroups: state.sourceAttributeGroups,
    targetAttributeGroup: state.targetAttributeGroup,
    mappingSuggestions: state.mappingSuggestions,
    chatMessages: state.chatMessages,
    assistantSignals: state.assistantSignals,
    assistantInferences: state.assistantInferences,
    assistantUnreadCount: state.assistantUnreadCount,
    firRecommendations: state.firRecommendations,
    firPrimaryQuestion: state.firPrimaryQuestion,
    firRecommendationLoading: state.firRecommendationLoading,
    firRecommendationCheckpoint: state.firRecommendationCheckpoint,
    firRecommendationContextKey: state.firRecommendationContextKey,
    mappingIntent: state.mappingIntent,
    agentThreadId: state.agentThreadId,
    agentParentMessageId: state.agentParentMessageId,
    semanticBundleId: state.semanticBundleId,
    semanticBundleLabel: state.semanticBundleLabel,
    semanticLevel: state.semanticLevel,
    semanticStatus: state.semanticStatus,
    semanticViewName: state.semanticViewName,
    semanticContextSummary: state.semanticContextSummary,
    semanticContextItems: state.semanticContextItems,
    semanticLineage: state.semanticLineage,
    semanticDatahubContext: state.semanticDatahubContext,
    datahubStatus: state.datahubStatus,
    pendingDerivedSourceDraft: state.pendingDerivedSourceDraft,
    derivedSourceDraftRequested: state.derivedSourceDraftRequested,
    drivingTableId: state.drivingTableId,
    relationships: state.relationships,
    derivedSources: state.derivedSources,
    sourceFilterSql: state.sourceFilterSql,
    sourceFilterGroups: state.sourceFilterGroups,
    sourceQuerySql: state.sourceQuerySql,
    sourceGroupBySql: state.sourceGroupBySql,
    sourceOrderBySql: state.sourceOrderBySql,
    mappings: state.mappings,
    selectedMappingIds: state.selectedMappingIds,
    mappingSql: state.mappingSql,
    mappingPreviewSql: state.mappingPreviewSql,
    mappingSqlVariant: state.mappingSqlVariant,
    isPreProcessModalOpen: state.isPreProcessModalOpen,
    activeMappingId: state.activeMappingId,
    pendingAiMappingReviews: state.pendingAiMappingReviews,
    activeSttmId: state.activeSttmId,
    activeProjectId: state.activeProjectId,
    activeSttmName: state.activeSttmName,
    activeProjectName: state.activeProjectName,
    sessionSavedAt: new Date().toISOString(),
  }), [state]);

  // Compute signatures for critical and non-critical state to detect changes
  const criticalStateSignature = useMemo(() => {
    return JSON.stringify({
      sourceDatabases: state.sourceDatabases,
      targetDatabases: state.targetDatabases,
      sources: state.sources,
      targets: state.targets,
      sourceInfo: state.sourceInfo,
      targetInfo: state.targetInfo,
      sourceAttributeGroups: state.sourceAttributeGroups,
      targetAttributeGroup: state.targetAttributeGroup,
      mappings: state.mappings,
      mappingSuggestions: state.mappingSuggestions,
      drivingTableId: state.drivingTableId,
      relationships: state.relationships,
      derivedSources: state.derivedSources,
      selectedMappingIds: state.selectedMappingIds,
      sourceFilterSql: state.sourceFilterSql,
      sourceFilterGroups: state.sourceFilterGroups,
      sourceQuerySql: state.sourceQuerySql,
      sourceGroupBySql: state.sourceGroupBySql,
      sourceOrderBySql: state.sourceOrderBySql,
      cacheMetadata: state.cacheMetadata,
    });
  }, [
    state.sourceDatabases,
    state.targetDatabases,
    state.sources,
    state.targets,
    state.sourceInfo,
    state.targetInfo,
    state.sourceAttributeGroups,
    state.targetAttributeGroup,
    state.mappings,
    state.mappingSuggestions,
    state.drivingTableId,
    state.relationships,
    state.derivedSources,
    state.selectedMappingIds,
    state.sourceFilterSql,
    state.sourceFilterGroups,
    state.sourceQuerySql,
    state.sourceGroupBySql,
    state.sourceOrderBySql,
    state.cacheMetadata,
  ]);

  const nonCriticalStateSignature = useMemo(() => {
    return JSON.stringify({
      chatMessages: state.chatMessages,
      assistantSignals: state.assistantSignals,
      assistantInferences: state.assistantInferences,
      assistantUnreadCount: state.assistantUnreadCount,
      firRecommendations: state.firRecommendations,
      firPrimaryQuestion: state.firPrimaryQuestion,
      semanticBundleId: state.semanticBundleId,
      semanticBundleLabel: state.semanticBundleLabel,
      semanticLevel: state.semanticLevel,
      semanticStatus: state.semanticStatus,
      semanticViewName: state.semanticViewName,
      semanticContextSummary: state.semanticContextSummary,
      semanticContextItems: state.semanticContextItems,
      semanticLineage: state.semanticLineage,
      semanticDatahubContext: state.semanticDatahubContext,
      datahubStatus: state.datahubStatus,
    });
  }, [
    state.chatMessages,
    state.assistantSignals,
    state.assistantInferences,
    state.assistantUnreadCount,
    state.firRecommendations,
    state.firPrimaryQuestion,
    state.semanticBundleId,
    state.semanticBundleLabel,
    state.semanticLevel,
    state.semanticStatus,
    state.semanticViewName,
    state.semanticContextSummary,
    state.semanticContextItems,
    state.semanticLineage,
    state.semanticDatahubContext,
    state.datahubStatus,
  ]);

  // Persist full state to localStorage with scoped key
  const persistState = useCallback(() => {
    try {
      const storageKey = getScopedStorageKey(state.activeProjectId, state.activeSttmId);
      window.localStorage.setItem(
        storageKey,
        JSON.stringify(persistedBuilderSession),
      );
    } catch (error) {
      console.warn("Unable to persist STTM builder draft session.", error);
    }
  }, [persistedBuilderSession, state.activeProjectId, state.activeSttmId]);

  // Critical state persistence (250ms debounce)
  useEffect(() => {
    if (!sessionHydrated) {
      return;
    }
    // Skip if signature hasn't changed
    if (criticalStateSignature === lastCriticalStateSignatureRef.current) {
      return;
    }
    lastCriticalStateSignatureRef.current = criticalStateSignature;

    if (criticalPersistTimerRef.current !== null) {
      window.clearTimeout(criticalPersistTimerRef.current);
    }
    criticalPersistTimerRef.current = window.setTimeout(() => {
      persistState();
      criticalPersistTimerRef.current = null;
    }, CRITICAL_STATE_DEBOUNCE_MS);

    return () => {
      if (criticalPersistTimerRef.current !== null) {
        window.clearTimeout(criticalPersistTimerRef.current);
        criticalPersistTimerRef.current = null;
      }
    };
  }, [criticalStateSignature, sessionHydrated, persistState]);

  // Non-critical state persistence (5s debounce)
  useEffect(() => {
    if (!sessionHydrated) {
      return;
    }
    // Skip if signature hasn't changed
    if (nonCriticalStateSignature === lastNonCriticalStateSignatureRef.current) {
      return;
    }
    lastNonCriticalStateSignatureRef.current = nonCriticalStateSignature;

    if (nonCriticalPersistTimerRef.current !== null) {
      window.clearTimeout(nonCriticalPersistTimerRef.current);
    }
    nonCriticalPersistTimerRef.current = window.setTimeout(() => {
      persistState();
      nonCriticalPersistTimerRef.current = null;
    }, NON_CRITICAL_STATE_DEBOUNCE_MS);

    return () => {
      if (nonCriticalPersistTimerRef.current !== null) {
        window.clearTimeout(nonCriticalPersistTimerRef.current);
        nonCriticalPersistTimerRef.current = null;
      }
    };
  }, [nonCriticalStateSignature, sessionHydrated, persistState]);

  const assistantSignalSignature = useMemo(() => {
    const selectedSources = state.sources
      .filter((table) => table.isSelected)
      .map((table) => table.qualifiedName)
      .sort();
    const selectedDerived = state.derivedSources
      .filter((source) => source.isSelected)
      .map((source) => source.id)
      .sort();
    const selectedTarget = state.targets.find((table) => table.isSelected)?.qualifiedName ?? null;
    const relationshipSignature = state.relationships
      .map((join) =>
        [
          join.leftTableId ?? "",
          join.rightTableId ?? "",
          join.joinType ?? "INNER",
          (join.conditions ?? [])
            .map((condition) => `${condition.leftColumn ?? ""}${condition.operator ?? "="}${condition.rightColumn ?? ""}`)
            .join("&"),
        ].join("|"),
      )
      .sort();

    return JSON.stringify({
      page: currentAssistantPage,
      surface: currentAssistantSurface,
      selectedSources,
      selectedDerived,
      selectedTarget,
      drivingTableId: state.drivingTableId,
      relationshipSignature,
      selectedMappingCount: state.selectedMappingIds.length,
    });
  }, [
    state.sources,
    state.derivedSources,
    state.targets,
    state.drivingTableId,
    state.relationships,
    state.selectedMappingIds,
    currentAssistantPage,
    currentAssistantSurface,
  ]);

  const buildAssistantActivityType = (previousSignature: string | null) => {
    type SignalSnapshot = {
      selectedSources?: string[];
      selectedDerived?: string[];
      selectedTarget?: string | null;
      relationshipSignature?: string[];
      selectedMappingCount?: number;
    };
    const parseSnapshot = (signature: string | null): SignalSnapshot | null => {
      if (!signature) return null;
      try {
        return JSON.parse(signature) as SignalSnapshot;
      } catch {
        return null;
      }
    };
    const current = parseSnapshot(assistantSignalSignature);
    const previous = parseSnapshot(previousSignature);
    const changed = (left: unknown, right: unknown) => JSON.stringify(left ?? null) !== JSON.stringify(right ?? null);

    // Relationships can be inferred automatically as tables are selected. Classify
    // the user action that actually changed instead of treating any existing join
    // as a new join checkpoint forever.
    if (current && previous) {
      if (changed(current.selectedSources, previous.selectedSources)) {
        return (current.selectedSources?.length ?? 0) > 1 ? "source_set_completed" : "selection_changed";
      }
      if (current.selectedTarget !== previous.selectedTarget) {
        return current.selectedTarget ? "target_selected" : "selection_changed";
      }
      if (changed(current.selectedDerived, previous.selectedDerived)) {
        return (current.selectedDerived?.length ?? 0) > 0 ? "derived_source_selected" : "selection_changed";
      }
      if (changed(current.relationshipSignature, previous.relationshipSignature)) {
        return "join_completed";
      }
      if (current.selectedMappingCount !== previous.selectedMappingCount) {
        return "mapping_context_changed";
      }
    }

    if ((current?.selectedSources?.length ?? 0) > 1) return "source_set_completed";
    if (current?.selectedTarget) return "target_selected";
    if ((current?.selectedDerived?.length ?? 0) > 0) return "derived_source_selected";
    if ((current?.relationshipSignature?.length ?? 0) > 0) return "join_completed";
    return currentAssistantPage === "mapping" ? "mapping_context_changed" : "selection_changed";
  };

  const runAssistantSignalEvaluation = (signature: string, activityType: string) => {
    signalEvaluationInFlightRef.current = true;
    dispatch(clearAssistantSignalsForContext());
    void dispatch(
      evaluateFirRecommendations({
        checkpoint: activityType,
        page: currentAssistantPage,
        surface: currentAssistantSurface,
        scopeType:
          activityType === "target_selected"
            ? "target"
            : activityType.includes("derived_source")
              ? "derived_source"
              : currentAssistantPage === "mapping"
                ? "mapping"
                : "table_set",
        candidateAction: activityType,
      }),
    ).finally(() => {
      signalEvaluationInFlightRef.current = false;
      const queuedEvaluation = queuedAssistantSignalEvaluationRef.current;
      if (!queuedEvaluation || queuedEvaluation.signature === signature) {
        queuedAssistantSignalEvaluationRef.current = null;
        return;
      }
      queuedAssistantSignalEvaluationRef.current = null;
      lastAssistantSignalSignature.current = queuedEvaluation.signature;
      runAssistantSignalEvaluation(queuedEvaluation.signature, queuedEvaluation.activityType);
    });
  };

  useEffect(() => {
    if (!state.loadState.initial || state.loadState.initial === "loading") {
      return;
    }
    // Source selection starts relationship discovery asynchronously. Evaluate
    // after it settles so one user action produces one complete checkpoint.
    if (state.loadState.relationships === "loading") {
      return;
    }
    if (!state.assistantPreferences.feedback_enabled && !state.assistantPreferences.recommendations_enabled) {
      return;
    }
    const hasSignalContext =
      state.sources.some((table) => table.isSelected) ||
      state.derivedSources.some((source) => source.isSelected) ||
      state.relationships.length > 0 ||
      !!state.targets.find((table) => table.isSelected) ||
      !!state.targetAttributeGroup ||
      state.selectedMappingIds.length > 0 ||
      state.mappings.length > 0;
    if (!hasSignalContext) {
      if (signalEvaluationTimerRef.current !== null) {
        window.clearTimeout(signalEvaluationTimerRef.current);
        signalEvaluationTimerRef.current = null;
      }
      queuedAssistantSignalEvaluationRef.current = null;
      abortPendingEvaluateSignals();
      lastAssistantSignalSignature.current = assistantSignalSignature;
      dispatch(clearAssistantSignalsForContext());
      return;
    }
    const previousSignature = lastAssistantSignalSignature.current;
    if (assistantSignalSignature === previousSignature) {
      return;
    }
    const activityType = buildAssistantActivityType(previousSignature);
    lastAssistantSignalSignature.current = assistantSignalSignature;
    if (signalEvaluationTimerRef.current !== null) {
      window.clearTimeout(signalEvaluationTimerRef.current);
    }
    signalEvaluationTimerRef.current = window.setTimeout(() => {
      if (signalEvaluationInFlightRef.current) {
        abortPendingEvaluateSignals();
        dispatch(clearAssistantSignalsForContext());
        queuedAssistantSignalEvaluationRef.current = {
          signature: assistantSignalSignature,
          activityType,
        };
        signalEvaluationTimerRef.current = null;
        return;
      }
      runAssistantSignalEvaluation(assistantSignalSignature, activityType);
      signalEvaluationTimerRef.current = null;
    }, 900);
    return () => {
      if (signalEvaluationTimerRef.current !== null) {
        window.clearTimeout(signalEvaluationTimerRef.current);
        signalEvaluationTimerRef.current = null;
      }
    };
  }, [
    assistantSignalSignature,
    dispatch,
    state.assistantPreferences.feedback_enabled,
    state.assistantPreferences.recommendations_enabled,
    state.loadState.initial,
    state.loadState.relationships,
    currentAssistantPage,
  ]);

  const value = useMemo<ContextValue>(() => {
    // Compose fullData from the two branches in Redux
    const fullData =
      state.sourceDatabases.length || state.targetDatabases.length
        ? { sources: state.sourceDatabases, targets: state.targetDatabases }
        : null;

    return {
      // Tree data
      fullData,

      // Flat lists
      sources: state.sources,
      targets: state.targets,
      sourceInfo: state.sourceInfo,
      targetInfo: state.targetInfo,

      // Attributes
      sourceAttributeGroups: state.sourceAttributeGroups,
      targetAttributeGroup: state.targetAttributeGroup,

      // Mapping
      mappingSuggestions: state.mappingSuggestions,
      mappingLoading: state.mappingLoading,
      autoMapStatusMessage: state.autoMapStatusMessage,
      autoMapProcessingIds: state.autoMapProcessingIds,

      // Chat
      chatMessages: state.chatMessages,
      chatLoading: state.chatLoading,
      assistantSignals: state.assistantSignals,
      assistantInferences: state.assistantInferences,
      assistantPreferences: state.assistantPreferences,
      assistantUnreadCount: state.assistantUnreadCount,
      firRecommendations: state.firRecommendations,
      firPrimaryQuestion: state.firPrimaryQuestion,
      firRecommendationLoading: state.firRecommendationLoading,
      firRecommendationCheckpoint: state.firRecommendationCheckpoint,
      firRecommendationContextKey: state.firRecommendationContextKey,
      mappingIntent: state.mappingIntent,
      semanticBundleId: state.semanticBundleId,
      semanticBundleLabel: state.semanticBundleLabel,
      semanticLevel: state.semanticLevel,
      semanticStatus: state.semanticStatus,
      semanticViewName: state.semanticViewName,
      semanticContextSummary: state.semanticContextSummary,
      semanticContextItems: state.semanticContextItems,
      semanticLineage: state.semanticLineage,
      semanticDatahubContext: state.semanticDatahubContext,
      datahubStatus: state.datahubStatus,
      pendingDerivedSourceDraft: state.pendingDerivedSourceDraft,
      derivedSourceDraftRequested: state.derivedSourceDraftRequested,

      // Session
      session: state.session,

      // Project/Mapping identity
      activeProjectId: state.activeProjectId,
      activeSttmId: state.activeSttmId,
      activeProjectName: state.activeProjectName,
      activeSttmName: state.activeSttmName,

      // Loading / error
      loadState: state.loadState,
      errorState: state.errorState,

      // Actions — data loading
      reloadInitialData: () => {
        dispatch(fetchDatabases());
        dispatch(fetchDerivedSources());
      },

      loadSchemas: (type: SelectionSide, dbId: string) => {
        dispatch(fetchSchemas({ type, dbId }));
      },

      selectSchema: (type: SelectionSide, dbId: string, schemaId: string) => {
        void dispatch(fetchTables({ type, dbId, schemaId })).then((action) => {
          const [database, schema] = schemaId.split(":", 2);
          const branch = type === "source" ? state.sourceDatabases : state.targetDatabases;
          const currentSchema = branch
            .find((item) => item.dbId === dbId)
            ?.schemas.find((item) => item.schemaId === schemaId);
          const payload = action.payload as { tables?: TableNode[] | null } | undefined;
          const tables = payload?.tables ?? currentSchema?.tables ?? [];
          void dispatch(
            evaluateFirRecommendations({
              checkpoint: "schema_browsed",
              page: "builder",
              surface: "SOURCE_SELECTION",
              scopeType: "schema",
              candidateAction:
                type === "source" ? "select_source_table" : "select_target_table",
              browsingContext: {
                side: type,
                database,
                schema,
                visible_candidate_tables: tables.map((table) => table.qualifiedName),
              },
            }),
          );
        });
      },

      // Actions — selection
      toggleSource: (tableId: string) => {
        const nextSelectedNames: string[] = [];
        for (const db of state.sourceDatabases) {
          for (const schema of db.schemas) {
            for (const table of schema.tables) {
              const isSelected =
                table.tableId === tableId ? !table.isSelected : table.isSelected;
              if (isSelected) {
                nextSelectedNames.push(table.qualifiedName);
              }
            }
          }
        }

        dispatch(toggleSourceAction({ tableId }));

        if (nextSelectedNames.length) {
          dispatch(fetchAttributes({ qualifiedNames: nextSelectedNames, side: "source" }));
        }
        dispatch(fetchRelationships());
      },

      selectTarget: (tableId: string) => {
        dispatch(selectTargetAction({ tableId }));
        // After selecting, refresh target attributes
        const target = state.targets.find((t) => t.tableId === tableId);
        if (target) {
          dispatch(
            fetchAttributes({ qualifiedNames: [target.qualifiedName], side: "target" })
          );
        }
      },

      selectAllSources: () => dispatch(selectAllSourcesAction()),
      clearSources: () => dispatch(clearSourcesAction()),
      clearTargets: () => dispatch(clearTargetsAction()),

      // Actions — AI
      runAutoMap: () => {
        void dispatch(
          evaluateFirRecommendations({
            checkpoint: "before_auto_map",
            page: "mapping",
            surface: "MAPPING",
            scopeType: "mapping",
            candidateAction: "run_auto_map",
          }),
        );
        void dispatch(runAutoMapThunk()).finally(() => {
          void dispatch(
            evaluateFirRecommendations({
              checkpoint: "on_auto_map_review",
              page: "mapping",
              surface: "MAPPING",
              scopeType: "mapping",
              candidateAction: "review_auto_map",
            }),
          );
        });
      },
      sendChatMessage: (message: string) => {
        dispatch(sendChatMessageThunk(message));
      },
      resetChatSession: () => {
        dispatch(resetChatSessionAction());
      },
      restoreChatSession: ({ messages }) => {
        dispatch(restoreChatSessionAction({ messages }));
      },
      submitChatFeedback: ({ messageId, rating, comment }) => {
        const targetMessage = state.chatMessages.find((item) => item.id === messageId);
        dispatch(
          submitChatFeedbackThunk({
            messageId,
            rating,
            comment: comment ?? null,
            requestId: targetMessage?.requestId ?? null,
            conversationId: targetMessage?.conversationId ?? state.agentThreadId,
          }),
        );
      },
      refreshAssistantSignals: (activityType?: string) => {
        const checkpoint =
          activityType ?? buildAssistantActivityType(lastAssistantSignalSignature.current);
        void dispatch(
          evaluateFirRecommendations({
            checkpoint,
            page: currentAssistantPage,
            surface: currentAssistantSurface,
            scopeType:
              checkpoint.includes("derived_source")
                ? "derived_source"
                : currentAssistantPage === "mapping"
                  ? "mapping"
                  : "table_set",
            candidateAction: checkpoint,
          }),
        );
      },
      requestSemanticRefresh: async () => {
        if (currentAssistantPage === "mapping") {
          return;
        }
        const selectedSourceTables = state.sources
          .filter((table) => table.isSelected)
          .map((table) => ({ database: table.qualifiedName.split(".", 3)[0], schema: table.qualifiedName.split(".", 3)[1], table: table.qualifiedName.split(".", 3)[2] }));
        const selectedDerivedSourceIds = state.derivedSources
          .filter((source) => source.isSelected)
          .map((source) => source.id);
        if (!selectedSourceTables.length && !selectedDerivedSourceIds.length) {
          return;
        }
        const selectedTargetTable = state.targets.find((table) => table.isSelected);
        const payload = {
          selected_source_tables: selectedSourceTables,
          selected_derived_sources: selectedDerivedSourceIds,
          target_table: selectedTargetTable
            ? { database: selectedTargetTable.qualifiedName.split(".", 3)[0], schema: selectedTargetTable.qualifiedName.split(".", 3)[1], table: selectedTargetTable.qualifiedName.split(".", 3)[2] }
            : null,
          relationships: state.relationships
            .filter((join) => join.leftTableId && join.rightTableId && join.conditions?.length)
            .map((join) => ({
              left_table: { database: (join.leftTableId as string).split(".", 3)[0], schema: (join.leftTableId as string).split(".", 3)[1], table: (join.leftTableId as string).split(".", 3)[2] },
              right_table: { database: (join.rightTableId as string).split(".", 3)[0], schema: (join.rightTableId as string).split(".", 3)[1], table: (join.rightTableId as string).split(".", 3)[2] },
              constraint_name: join.constraintName ?? null,
              join_type: join.joinType ?? "INNER",
              source: join.source ?? "USER_DEFINED",
              locked: join.locked ?? false,
              conditions: (join.conditions ?? []).map((condition) => ({
                left_column: condition.leftColumn,
                right_column: condition.rightColumn,
                operator: condition.operator ?? "=",
              })),
          })),
          requested_level: (selectedTargetTable ? "L3_MAPPING_ENRICHED" : "L2_ANALYST_READY") as SemanticLevel,
          force: false,
        };
        const signature = JSON.stringify(payload);
        if (
          semanticRefreshInFlightSignatureRef.current === signature ||
          lastSemanticRefreshSignatureRef.current === signature
        ) {
          return;
        }
        semanticRefreshInFlightSignatureRef.current = signature;
        try {
          const refresh = await dbService.refreshSemanticContext(payload);
          dispatch(applySemanticRefreshAction(refresh));
          lastSemanticRefreshSignatureRef.current = signature;
        } catch (error) {
          console.warn("Semantic refresh request did not complete in the background.", error);
        } finally {
          if (semanticRefreshInFlightSignatureRef.current === signature) {
            semanticRefreshInFlightSignatureRef.current = null;
          }
        }
      },
      respondToAssistantSignal: ({ signalId, status, optionSelected, rating, comment }) => {
        dispatch(
          respondToAssistantSignalThunk({
            signalId,
            status,
            optionSelected: optionSelected ?? null,
            rating: rating ?? null,
            comment: comment ?? null,
          }),
        );
      },
      updateAssistantPreferences: (settings) => {
        dispatch(updateAssistantPreferencesThunk(settings));
      },
      openPendingDerivedSourceDraft: () => {
        dispatch(openPendingDerivedSourceDraftAction());
      },
      acknowledgePendingDerivedSourceDraft: () => {
        dispatch(acknowledgePendingDerivedSourceDraftAction());
      },
      dismissPendingDerivedSourceDraft: () => {
        dispatch(dismissPendingDerivedSourceDraftAction());
      },
      applyPendingAiMappingReview: () => {
        dispatch(applyPendingAiMappingReviewAction());
      },
      skipPendingAiMappingReview: () => {
        dispatch(skipPendingAiMappingReviewAction());
      },

      // Computed - use tree-based count if available, fall back to flat sources
      selectedSourceCount:
        getSelectedSourceTables(state.sourceDatabases).length ||
        state.sources.filter((t) => t.isSelected).length,
      mappingCount: state.mappingSuggestions.filter(
        (item) => item.sourceAttributes.length > 0
      ).length,

      // Derived source features
      drivingTableId: state.drivingTableId,
      setDrivingTable: (tableId: string | null) =>
        dispatch(setDrivingTableAction({ tableId })),
      relationships: state.relationships,
      setRelationships: (joins) => dispatch(setRelationshipsAction({ joins })),
      derivedSources: state.derivedSources,
      addDerivedSource: (source: DerivedSource) =>
        dispatch(addDerivedSourceAction(source)),
      updateDerivedSource: (source: DerivedSource) =>
        dispatch(updateDerivedSourceAction(source)),
      removeDerivedSource: (id: string) =>
        dispatch(removeDerivedSourceAction({ id })),
      toggleDerivedSource: (id: string) =>
        dispatch(toggleDerivedSourceAction({ id })),

      sourceFilterSql: state.sourceFilterSql,
      sourceFilterGroups: state.sourceFilterGroups,
      sourceQuerySql: state.sourceQuerySql,
      sourceGroupBySql: state.sourceGroupBySql,
      sourceOrderBySql: state.sourceOrderBySql,
      setSourceFilterConditions: (payload: {
        sql: string;
        groups: RuleGroup[];
        baseSql?: string;
        groupBySql?: string;
        orderBySql?: string;
      }) =>
        dispatch(setSourceFilterConditionsAction(payload)),

      // UI Mapping state
      mappings: state.mappings,
      selectedMappingIds: state.selectedMappingIds,
      mappingSql: state.mappingSql,
      mappingPreviewSql: state.mappingPreviewSql,
      mappingSqlVariant: state.mappingSqlVariant,
      isPreProcessModalOpen: state.isPreProcessModalOpen,
      activeMappingId: state.activeMappingId,
      pendingAiMappingReviews: state.pendingAiMappingReviews,
      
      // UI Mapping actions
      applySemanticRefresh: (payload) => dispatch(applySemanticRefreshAction(payload)),
      initializeMappings: (mappings) => dispatch(initializeMappingsAction(mappings)),
      updateMapping: (id, updates) => dispatch(updateMappingAction({ id, updates })),
      toggleMappingSelection: (id) => dispatch(toggleMappingSelectionAction({ id })),
      selectAllMappings: (ids, select) => dispatch(selectAllMappingsAction({ ids, select })),
      bulkMarkMapped: (ids) => dispatch(bulkMarkMappedAction({ ids })),
      bulkSetDirect: (ids) => dispatch(bulkSetDirectAction({ ids })),
      setPreProcessModalOpen: (open, mappingId) => dispatch(setPreProcessModalOpenAction({ open, mappingId })),
      setMappingSql: (sql) => dispatch(setMappingSqlAction({ sql })),
      setMappingPreviewSql: (sql) => dispatch(setMappingPreviewSqlAction({ sql })),
      setMappingSqlVariant: (variant) => dispatch(setMappingSqlVariantAction({ variant })),
    };
  }, [state, dispatch, currentAssistantPage, currentAssistantSurface]);

  return (
    <SttmBuilderContext.Provider value={value}>
      {children}
    </SttmBuilderContext.Provider>
  );
}

export const useSttmBuilderContext = () => {
  const context = useContext(SttmBuilderContext);

  if (!context) {
    throw new Error(
      "useSttmBuilderContext must be used within SttmBuilderProvider"
    );
  }

  return context;
};
