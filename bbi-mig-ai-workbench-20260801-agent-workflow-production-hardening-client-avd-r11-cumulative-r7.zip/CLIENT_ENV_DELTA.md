# R11 environment and Snowflake delta

The backend defaults to `TBL_PROJECT_ATTRIBUTES`; this override remains
optional:

```dotenv
SNOWFLAKE_PROJECT_ATTRIBUTES_TABLE=TBL_PROJECT_ATTRIBUTES
```

No new mandatory environment variables are required. Keep the existing Cortex
model and agent object settings from the cumulative R9/R10 deployment.

If the application runtime role differs from the bootstrap/service-owner role,
run these grants with the client workbench database and schema:

```sql
GRANT SELECT, INSERT, UPDATE, DELETE
ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_PROJECT_ATTRIBUTES
TO ROLE <APP_RUNTIME_ROLE>;

GRANT SELECT, INSERT, UPDATE
ON TABLE <WORKBENCH_DB>.<WORKBENCH_SCHEMA>.TBL_AGENT_ARTIFACT_JOBS
TO ROLE <APP_RUNTIME_ROLE>;
```

The migration is additive and idempotent. It does not replace existing
projects, mappings, semantic bundles, FIR evidence, streams, tasks, or learning
status.
