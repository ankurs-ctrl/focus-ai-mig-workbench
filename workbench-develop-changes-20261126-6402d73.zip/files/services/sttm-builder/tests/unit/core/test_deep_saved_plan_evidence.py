from threading import RLock
from types import SimpleNamespace
from unittest.mock import Mock

from app.agent_runs.models import AgentActor
from app.agent_runs.repository import SnowflakeAgentRunRepository
from app.agent_tools.workbench import WorkbenchWorkflowHandlers


def test_saved_plan_lookup_is_exact_and_caller_scoped():
    session = Mock()
    session.sql.return_value.collect.return_value = [{
        "RUN_ID": "past-run", "STATUS": "AWAITING_CONFIRMATION", "PROJECT_ID": "past-project",
        "PLAN_ID": "past-plan", "REVISION": 2,
        "SOURCE_PREPARATION": '{"driving_source":"APP.SOURCES.ACCOUNTS"}',
    }]
    repository = SnowflakeAgentRunRepository(session, database="APP", schema="METADATA")
    actor = AgentActor(app_user_id="owner", tenant_id="tenant-a", effective_role="ROLE_A")
    results = repository.find_related_plan_artifacts(
        actor, 'APP."Mixed Case".ACCOUNT', run_id="active-run", project_id="active-project",
    )
    query, args = session.sql.call_args.args
    assert args == ["owner", "tenant-a", "ROLE_A", "active-run",
                    'APP."Mixed Case".ACCOUNT', '"APP"."Mixed Case"."ACCOUNT"', "active-project"]
    assert "r.ACTOR_USER_ID = ? AND r.TENANT_ID = ?" in query
    assert "r.RUN_PAYLOAD:actor:effective_role::STRING = ?" in query
    assert "m.VALUE:target_table::STRING IN (?, ?)" in query
    assert "plan:mapping_specs" in query
    assert "plan:plan_hash::STRING IS NOT NULL" in query
    assert "LIMIT 3" in query
    assert results[0]["source_preparation"] == {"driving_source": "APP.SOURCES.ACCOUNTS"}


def test_evidence_contains_only_scoped_design_leads_and_reads_history_once():
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = RLock()
    handler._budget = None
    handler._settings = SimpleNamespace(snowflake_sttm_table="APP.METADATA.TBL_STTM")
    source = 'APP.SOURCES."Accounts"'
    supporting_source = "APP.SOURCES.ADDRESSES"
    target = "APP.DEST.ACCOUNT"
    handler._plan_history_repository = Mock()
    handler._plan_history_repository.find_related_plan_artifacts.return_value = [
        {
            "run_id": "past-run", "status": "COMPLETED", "plan_id": "past-plan", "revision": 1,
            "source_preparation": {
                "driving_source": source,
                "supporting_sources": [supporting_source],
                "relationships": [{
                    "left_table": source, "right_table": supporting_source, "join_type": "LEFT",
                    "conditions": [{"left_column": '"AccountId"', "right_column": "ACCOUNT_ID", "operator": "="}],
                }],
                "derived_sources": [{"name": "CURRENT_ADDRESS", "sql": "private SQL"}],
                "value_bindings": [{"value": "private business value"}],
            },
        },
        {"run_id": "out-of-scope", "source_preparation": {"driving_source": "OTHER.SOURCES.ACCOUNTS"}},
        {"run_id": "target-as-source", "source_preparation": {"driving_source": target}},
        {"run_id": "metadata-source", "source_preparation": {"driving_source": "APP.METADATA.TBL_STTM"}},
    ]
    state = {"run_id": "active", "app_user_id": "owner", "effective_role": "ROLE_A",
             "authorized_schemas": ["APP.SOURCES", "APP.DEST", "APP.METADATA"]}
    leads = handler._related_saved_plans(state, target)
    assert [lead["run_id"] for lead in leads] == ["past-run"]
    assert leads[0]["driving_source"] == source
    assert leads[0]["join_candidates"][0]["conditions"][0]["left_column"] == '"AccountId"'
    assert leads[0]["cte_names"] == ["CURRENT_ADDRESS"]
    assert "private" not in repr(leads)
    assert handler._related_saved_plans({**state, "authorized_schemas": ["APP.DEST"]}, target) == []
    assert handler._plan_history_repository.find_related_plan_artifacts.call_count == 1
