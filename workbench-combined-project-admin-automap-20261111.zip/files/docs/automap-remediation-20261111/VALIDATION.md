# Validation record — November 11, 2026

## Verified locally

- Broad backend core run: 3,907 passed, 31 skipped, three failures. Two failures were assertions running against files edited during that long run; the remaining failure exposed a nullable source-binding bug. The bug was fixed and the exact failing test passed in isolation. This is not represented as a clean full-suite run.
- Subsequent source/FIR/payload/transformation selection: 181 passed.
- Latest dedicated remediation suite: 31 passed, including optional semantic/FIR outages, exact SQL preview keys, actual Contacts importer/compiler/publication replay, dependency provenance, bounded transformation splitting, candidate-only transformation generation, historical reprojection, and cross-project firm-literal isolation.
- Final combined remediation, admission, FIR-v3 and publication regression: 135 passed with the locked Snowpark runtime. Publication conflict test passed with HTTP 409 semantics.
- Frontend candidate suite: 79 passed. Mapping/status/navigation suite: 43 passed. SQL-upload workflow assertions passed.
- Frontend TypeScript check passed. Agent-spec checksum verification and Git whitespace check passed.
- Contacts replay checks 49 authored outputs and four CTEs through the real parser, frontend importer, compiler and publication validator, for qualified and unqualified physical names. Its Snowflake EXPLAIN transport is stubbed; this does not prove the actual client SQL executes in the test account.

## Native Snowflake

Authentication and test-account identity were verified. An initial attempt was blocked by CREDIT_LIMIT. After the user increased credits, the 33-column source inventory loaded. That run stopped at snapshot archival because the host had Snowpark 1.18 rather than the application's locked 1.49 API; zero model POSTs occurred and all scratch objects were cleaned up. The bounded locked-runtime retry PASSED: two of two targets valid, one actual model POST, zero retries/quote-review calls, maximum message 58,828 characters, no occupied execution slots afterward, and scratch schema cleaned up. See LIVE-RESULT.json. This fixture exercises real native source mapping and semantics; it intentionally has no FIR history and does not publish.

No existing client service, mapping, environment file, account configuration, warehouse/resource monitor, or original published version was changed. No FIR backfill was executed on client data. SPCS/browser acceptance, full FIR publish-to-reuse acceptance, and the exact screenshot's server exception remain unverified. The user accepted local-only testing for this source overlay; this package is not a claim of production acceptance or failure-free provider availability.

The full locked-runtime native retry also PASSED: all 33 requested identity targets received correct, valid source mappings across nine batches, no failed batches, and scratch cleanup completed. See LIVE-FULL-RESULT.json. This remains a source/semantic/runtime acceptance, not a live FIR or publication acceptance.

The frontend production build completed successfully; the final source also passed TypeScript.

## Remaining review considerations

Historical CTE/join proposals display recorded SQL and evidence for manual review/addition. They do not prefill/apply a new graph automatically. If an exact historical dependency body is missing, it remains missing. A single target that cannot fit exact evidence inside the existing allowance remains deferred. Live model output quality should be checked on client-specific business expectations after deployment. Existing draft preservation and explicit SQL validation gates remain in effect.
