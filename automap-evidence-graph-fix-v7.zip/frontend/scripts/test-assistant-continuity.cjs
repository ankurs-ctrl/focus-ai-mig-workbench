const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
function compile(filename, source, dependencies = {}) {
  const loaded = new Module(filename, module);
  loaded.require = name => dependencies[name] ?? (name.startsWith('@/')
    ? load(path.resolve(__dirname, `../src/${name.slice(2)}.ts`))
    : name.startsWith('.') ? load(path.resolve(path.dirname(filename), `${name}.ts`)) : require(name));
  loaded._compile(ts.transpileModule(source, {compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020,
  }}).outputText, filename);
  return loaded.exports;
}
function load(filename) { return compile(filename, fs.readFileSync(filename, 'utf8')); }
const slicePath = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
const source = fs.readFileSync(slicePath, 'utf8');
const ast = ts.createSourceFile(slicePath, source, ts.ScriptTarget.Latest, true);
const functions = [];
const reducers = {};
function visit(node) {
  if (ts.isFunctionDeclaration(node) && ['stablePreparedContextValue','compactPreparedContextHash','preparedWorkspaceSnapshot','autoMapSourceInputs'].includes(node.name?.text)) functions.push(node.getText(ast));
  if (ts.isPropertyAssignment(node) && ['setDrivingTable','setRelationships','resetChatSession','applyPreparedWorkspaceContext'].includes(node.name.getText(ast))) reducers[node.name.getText(ast)] = node.initializer.getText(ast);
  ts.forEachChild(node, visit);
}
visit(ast);
const {preparedWorkspaceSnapshot} = compile(slicePath, functions.join('\n'));
const {buildWorkbenchContextSnapshot} = load(path.resolve(__dirname, '../src/features/sttm/context/workbench-context.ts'));
const outcome = {job_id:'job-1', mappings:Object.fromEntries(Array.from({length:37}, (_,index)=>[`T${index}`,{unmatched_reason:'Missing source',confidence_score:0}]))};
const workspace = buildWorkbenchContextSnapshot({action:'assistant.requested', page:'builder',surface:'SOURCE_SELECTION',
  sourceTables:[], mappings:[], drivingTableId:'cte:one', autoMapOutcome:outcome,
  conversationHistory:[{role:'user',content:'Keep this decision'},{role:'assistant',content:'failed',status:'failed'}]});
assert.deepEqual(workspace.auto_map_outcome,outcome);
assert.equal(workspace.conversation_history.length,1);
const prepared=preparedWorkspaceSnapshot(workspace);
assert.deepEqual(prepared.workspace.conversation_history,[]);
assert.equal(prepared.workspace.auto_map_outcome,null);
assert.equal(preparedWorkspaceSnapshot({...workspace,page:'mapping',checked_mapping_row_ids:['row2'],conversation_history:[]}).dependencyHash,prepared.dependencyHash);
assert.notEqual(preparedWorkspaceSnapshot({...workspace,driving_relation_id:'cte:two'}).dependencyHash,prepared.dependencyHash);
assert.notEqual(preparedWorkspaceSnapshot({...workspace,filters:{query_modifiers:{qualify:'ROW_NUMBER() OVER (ORDER BY ID) = 1'}}}).dependencyHash,prepared.dependencyHash);
for (const [name,payload] of [['setDrivingTable',{tableId:'cte:two'}],['setRelationships',{joins:[]}]]) {
  const reducer = compile(slicePath,`module.exports = (${reducers[name]});`);
  const state={agentLogicalConversationId:'logical-1',agentThreadId:'physical-1'};
  reducer(state,{payload});
  assert.equal(state.agentLogicalConversationId,'logical-1');
  assert.equal(state.agentThreadId,null);
}
const apply = compile(slicePath,`module.exports = (snapshotFromState,preparedWorkspaceSnapshot,autoMapSourceInputs) => (${reducers.applyPreparedWorkspaceContext});`)(()=>workspace,preparedWorkspaceSnapshot,()=>"source-fingerprint");
const state={workspaceContextPendingSnapshotHash:prepared.dependencyHash,workspaceContextId:'old'};
apply(state,{payload:{snapshotHash:'stale',context:{workspace_context_id:'stale'}}});
assert.equal(state.workspaceContextId,'old');
apply(state,{payload:{snapshotHash:prepared.dependencyHash,context:{workspace_context_id:'new',status:'ready'}}});
assert.equal(state.workspaceContextId,'new');
const reset=compile(slicePath,`module.exports = (currentAssistantWelcome) => (${reducers.resetChatSession});`)(()=>({role:'assistant',content:''}));
reset(state); assert.equal(state.agentLogicalConversationId,null);
assert.match(source,/selected_mapping: \{/);
assert.match(source,/operation: shouldUseStructuredTransformationIntent\s*\? "sttm.transform"/);
assert.doesNotMatch(source,/isDerivedSourcePrompt\s*\? "sttm\.derived_sql\.generate"/);
assert.doesNotMatch(source.slice(source.indexOf('const transformationProjectAttributes'),source.indexOf('const stream = useDirectWorkbenchStream')),/\.catch/);
console.log('Assistant outcome, prepared identity, stale response, logical memory and transformation contract regressions passed.');
const provider=fs.readFileSync(path.resolve(__dirname,'../src/features/sttm/context/sttm-builder-context.tsx'),'utf8');
const baseline=provider.slice(provider.indexOf('// One baseline per open request'),provider.indexOf('const nonCriticalStateSignature'));
assert.match(baseline,/backendBaselineIdentityRef.current = null/);
assert.match(baseline,/`\$\{state.activeProjectId\}:\$\{state.activeSttmId\}`/);
assert.doesNotMatch(baseline,/\? `[^`]*activeSnapshotId/);
assert.match(source,/getSttm\(sttmId, \{ forceRefresh: true \}\)/);
const projectService=fs.readFileSync(path.resolve(__dirname,'../src/services/projectService.ts'),'utf8');
assert.match(projectService,/force_refresh=true/);
assert.doesNotMatch(source,/await queueRenderDelta/);
const schedulerSource=source.slice(source.indexOf('let answerRenderBuffer ='),source.indexOf('    try {',source.indexOf('let answerRenderBuffer =')));
const scheduler=compile(slicePath,`module.exports=(dispatch,window,streamBatchingEnabled)=>{const messageId='test';const assistantStreamDelta=value=>({...value,kind:'answer'}),assistantStreamSqlDelta=value=>({...value,kind:'sql'});${schedulerSource};return {queueRenderDelta,flushRenderBuffers};};`);
for(const batching of [true,false]) {
  const timers=new Map(); let nextTimer=0; const actions=[];
  const scheduled=scheduler(action=>actions.push(action),{
    setTimeout:callback=>{timers.set(++nextTimer,callback);return nextTimer;},
    clearTimeout:id=>timers.delete(id),
  },batching);
  for(let index=0;index<1000;index++) assert.equal(scheduled.queueRenderDelta('answer','x'),undefined);
  scheduled.queueRenderDelta('sql','SELECT 1');
  assert.equal(timers.size,1); assert.equal(actions.length,0);
  // Simulate a terminal event while all browser timers are throttled.
  scheduled.flushRenderBuffers();
  assert.equal(timers.size,0);
  assert.equal(actions[0].text,'x'.repeat(1000));
  assert.equal(actions[1].text,'SELECT 1');
  scheduled.flushRenderBuffers(); assert.equal(actions.length,2);
  scheduled.queueRenderDelta('answer','next');
  const callback=[...timers.values()][0];callback();
  assert.equal(actions[2].text,'next'); assert.equal(timers.size,0);
}
console.log('Stream ingestion never waits for render timers; terminal flush is exact even when timers are throttled.');