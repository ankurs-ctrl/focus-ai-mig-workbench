"use client";

import { useEffect } from "react";

export const CHUNK_RELOAD_KEY = "app-chunk-reload-attempt";
export const CHUNK_RELOAD_MAX_ATTEMPTS = 2;

export function isChunkLoadFailure(message: string) {
  return (
    message.includes("ChunkLoadError")
    || message.includes("Loading chunk")
    || message.includes("Failed to fetch dynamically imported module")
    || message.includes("error loading dynamically imported module")
  );
}

/**
 * Client-side recovery after React mounts. Pair with the inline layout script so
 * failures that happen before Providers load still trigger a reload.
 */
export function ChunkErrorRecovery() {
  useEffect(() => {
    // Clear the attempt counter only after the app has stayed healthy briefly.
    const clearTimer = window.setTimeout(() => {
      try {
        sessionStorage.removeItem(CHUNK_RELOAD_KEY);
      } catch {
        // Ignore storage failures.
      }
    }, 8_000);

    const attemptReload = (message: string) => {
      if (!isChunkLoadFailure(message)) {
        return;
      }

      try {
        const attempts = Number(sessionStorage.getItem(CHUNK_RELOAD_KEY) || "0");
        if (attempts >= CHUNK_RELOAD_MAX_ATTEMPTS) {
          return;
        }
        sessionStorage.setItem(CHUNK_RELOAD_KEY, String(attempts + 1));
      } catch {
        // Fall through and still try a single reload.
      }

      window.location.reload();
    };

    const onError = (event: ErrorEvent) => {
      attemptReload(event.message || String(event.error ?? ""));
    };

    const onUnhandledRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      const message =
        reason instanceof Error
          ? reason.message
          : typeof reason === "string"
            ? reason
            : "";
      attemptReload(message);
    };

    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);

    return () => {
      window.clearTimeout(clearTimer);
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
    };
  }, []);

  return null;
}
