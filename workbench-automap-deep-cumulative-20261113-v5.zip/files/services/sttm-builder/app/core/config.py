from functools import lru_cache
import re
from typing import Literal
from urllib.parse import urlparse
from uuid import UUID

from pydantic import BaseModel, Field, SecretStr, computed_field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Snowflake Cortex LLMs available for agent orchestration.
SNOWFLAKE_SUPPORTED_MODELS: list[str] = [
    "claude-sonnet-4-6",
    "claude-sonnet-4-5",
    "claude-sonnet-4",
    "claude-haiku-4-5",
    "claude-3-5-sonnet",
    "claude-3-haiku",
    "llama3.3-70b",
    "llama3.1-405b",
    "llama3.1-70b",
    "mistral-large2",
    "snowflake-arctic",
    "reka-flash",
    "jamba-1.5-large",
    "jamba-1.5-mini",
]

LEGACY_METADATA_DATABASE = "FFP_HDP_CRM_MIG_DB_DEV"
LEGACY_METADATA_SCHEMA = "SCH_STTM_METADATA"


class AgentConfig(BaseModel):
    """Internal agent definition — snowflake_name is infra detail, not exposed to callers."""

    id: str
    display_name: str
    description: str
    snowflake_name: str
    default_model: str


def _split_qualified_name(value: str) -> tuple[str, str, str] | None:
    parts = [part.strip() for part in value.split(".")]
    if len(parts) != 3 or not all(parts):
        return None
    return parts[0], parts[1], parts[2]


def _looks_like_placeholder(value: str) -> bool:
    normalized = value.strip().upper()
    if not normalized:
        return True
    return normalized.startswith(("DB.SCHEMA.", "YOUR_DB.YOUR_SCHEMA."))


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env.local",
        extra="ignore",
        case_sensitive=False,
        populate_by_name=True,
    )

    app_name: str = Field(default="BBI AI Migration Workbench API", alias="APP_NAME")
    app_env: str = Field(default="dev", alias="APP_ENV")
    app_version: str = Field(default="0.1.0", alias="APP_VERSION")
    port: int = Field(default=8000, alias="PORT")
    users_table: str = Field(default="TBL_USERS", alias="USERS_TABLE")
    app_role_admin: str = Field(default="WORKBENCH_ADMIN", alias="APP_ROLE_ADMIN")
    app_role_publisher: str = Field(
        default="WORKBENCH_PUBLISHER",
        alias="APP_ROLE_PUBLISHER",
    )
    app_role_viewer: str = Field(
        default="WORKBENCH_VIEWER",
        alias="APP_ROLE_VIEWER",
    )
    local_dev_auth_enabled: bool = Field(
        default=False,
        alias="LOCAL_DEV_AUTH_ENABLED",
    )
    local_dev_user_email: str = Field(
        default="",
        alias="LOCAL_DEV_USER_EMAIL",
    )
    local_dev_bypass_metadata: bool = Field(
        default=True,
        alias="LOCAL_DEV_BYPASS_METADATA",
    )
    auth_mode: str = Field(
        default="ingress_headers",
        alias="AUTH_MODE",
    )
    spcs_execute_as_caller_enabled: bool = Field(
        default=True,
        alias="SPCS_EXECUTE_AS_CALLER_ENABLED",
    )
    auth_session_cookie_name: str = Field(
        default="sttm_session",
        alias="AUTH_SESSION_COOKIE_NAME",
    )
    auth_state_cookie_name: str = Field(
        default="sttm_oauth_state",
        alias="AUTH_STATE_COOKIE_NAME",
    )
    auth_session_secret: str = Field(
        default="",
        alias="AUTH_SESSION_SECRET",
    )
    auth_session_encryption_key: str = Field(
        default="",
        alias="AUTH_SESSION_ENCRYPTION_KEY",
    )
    auth_session_cookie_domain: str = Field(
        default="",
        alias="AUTH_SESSION_COOKIE_DOMAIN",
    )
    auth_session_cookie_samesite: str = Field(
        default="lax",
        alias="AUTH_SESSION_COOKIE_SAMESITE",
    )
    auth_session_cookie_secure: bool = Field(
        default=True,
        alias="AUTH_SESSION_COOKIE_SECURE",
    )
    auth_session_cookie_max_age_seconds: int = Field(
        default=2592000,
        alias="AUTH_SESSION_COOKIE_MAX_AGE_SECONDS",
    )
    auth_oauth_state_ttl_seconds: int = Field(
        default=600,
        alias="AUTH_OAUTH_STATE_TTL_SECONDS",
    )
    auth_access_token_refresh_skew_seconds: int = Field(
        default=120,
        alias="AUTH_ACCESS_TOKEN_REFRESH_SKEW_SECONDS",
    )
    auth_principal_cache_ttl_seconds: int = Field(
        default=300,
        alias="AUTH_PRINCIPAL_CACHE_TTL_SECONDS",
    )
    auth_post_login_redirect_path: str = Field(
        default="/home",
        alias="AUTH_POST_LOGIN_REDIRECT_PATH",
    )
    auth_post_logout_redirect_path: str = Field(
        default="/home",
        alias="AUTH_POST_LOGOUT_REDIRECT_PATH",
    )
    snowflake_oauth_client_id: str = Field(
        default="",
        alias="SNOWFLAKE_OAUTH_CLIENT_ID",
    )
    snowflake_oauth_client_secret: str = Field(
        default="",
        alias="SNOWFLAKE_OAUTH_CLIENT_SECRET",
    )
    snowflake_oauth_authorize_url: str = Field(
        default="",
        alias="SNOWFLAKE_OAUTH_AUTHORIZE_URL",
    )
    snowflake_oauth_token_url: str = Field(
        default="",
        alias="SNOWFLAKE_OAUTH_TOKEN_URL",
    )
    snowflake_oauth_redirect_uri: str = Field(
        default="",
        alias="SNOWFLAKE_OAUTH_REDIRECT_URI",
    )
    snowflake_oauth_scope: str = Field(
        default="",
        alias="SNOWFLAKE_OAUTH_SCOPE",
    )
    snowflake_oauth_sessions_table: str = Field(
        default="TBL_WORKBENCH_OAUTH_SESSIONS",
        alias="SNOWFLAKE_OAUTH_SESSIONS_TABLE",
    )

    snowflake_account: str = Field(default="", alias="SNOWFLAKE_ACCOUNT")
    snowflake_host: str = Field(default="", alias="SNOWFLAKE_HOST")
    snowflake_rest_host: str = Field(default="", alias="SNOWFLAKE_REST_HOST")
    snowflake_authenticator: str = Field(default="", alias="SNOWFLAKE_AUTHENTICATOR")
    snowflake_private_key_path: str = Field(default="", alias="SNOWFLAKE_PRIVATE_KEY_PATH")
    snowflake_private_key_passphrase: SecretStr = Field(default=SecretStr(""), alias="SNOWFLAKE_PRIVATE_KEY_PASSPHRASE")
    snowflake_private_key_fingerprint: str = Field(default="", alias="SNOWFLAKE_PRIVATE_KEY_FINGERPRINT")
    snowflake_user: str = Field(default="", alias="SNOWFLAKE_USER")
    snowflake_password: str = Field(default="", alias="SNOWFLAKE_PASSWORD")
    snowflake_role: str = Field(default="", alias="SNOWFLAKE_ROLE")
    snowflake_warehouse: str = Field(default="", alias="SNOWFLAKE_WAREHOUSE")
    snowflake_control_warehouse: str = Field(
        default="",
        alias="SNOWFLAKE_CONTROL_WAREHOUSE",
    )
    snowflake_agent_warehouse: str = Field(
        default="",
        alias="SNOWFLAKE_AGENT_WAREHOUSE",
    )
    snowflake_execution_warehouse: str = Field(
        default="",
        alias="SNOWFLAKE_EXECUTION_WAREHOUSE",
    )
    snowflake_preparation_warehouse: str = Field(
        default="",
        alias="SNOWFLAKE_PREPARATION_WAREHOUSE",
    )
    auto_mapping_warehouse: str = Field(
        default="",
        alias="AUTO_MAPPING_WAREHOUSE",
    )
    snowflake_control_statement_timeout_seconds: int = Field(
        default=60,
        alias="SNOWFLAKE_CONTROL_STATEMENT_TIMEOUT_SECONDS",
    )
    snowflake_agent_statement_timeout_seconds: int = Field(
        default=300,
        alias="SNOWFLAKE_AGENT_STATEMENT_TIMEOUT_SECONDS",
    )
    snowflake_execution_statement_timeout_seconds: int = Field(
        default=900,
        alias="SNOWFLAKE_EXECUTION_STATEMENT_TIMEOUT_SECONDS",
    )
    snowflake_preparation_statement_timeout_seconds: int = Field(
        default=300,
        alias="SNOWFLAKE_PREPARATION_STATEMENT_TIMEOUT_SECONDS",
    )
    snowflake_automap_statement_timeout_seconds: int = Field(
        default=600,
        alias="SNOWFLAKE_AUTOMAP_STATEMENT_TIMEOUT_SECONDS",
    )
    snowflake_session_healthcheck_interval_seconds: int = Field(
        default=0,
        alias="SNOWFLAKE_SESSION_HEALTHCHECK_INTERVAL_SECONDS",
        description=(
            "Optional periodic pooled-session validation. Zero disables SELECT 1 "
            "health queries; failed real work reconnects the session instead."
        ),
    )
    snowflake_database: str = Field(default="", alias="SNOWFLAKE_DATABASE")
    snowflake_schema: str = Field(default="", alias="SNOWFLAKE_SCHEMA")
    crm_target_database: str = Field(default="", alias="CRM_TARGET_DATABASE")
    crm_target_schema: str = Field(default="", alias="CRM_TARGET_SCHEMA")
    crm_target_tables: str = Field(
        default="HOUSEHOLD,BUSINESS,ALERTS,CALLS",
        alias="CRM_TARGET_TABLES",
        description="Comma-separated allowlist of physical CRM target tables.",
    )
    crm_target_contract_json: str = Field(
        default="",
        alias="CRM_TARGET_CONTRACT_JSON",
        description=(
            "Optional versioned target contract JSON. Its tables mapping can "
            "restrict approved columns and attach stable semantic metadata."
        ),
    )
    crm_target_contract_version: str = Field(
        default="1.0",
        alias="CRM_TARGET_CONTRACT_VERSION",
    )

    snowflake_sttm_builder_agent: str = Field(
        default="",
        alias="SNOWFLAKE_STTM_BUILDER_AGENT",
    )
    snowflake_source_mapping_agent: str = Field(
        default="",
        alias="SNOWFLAKE_SOURCE_MAPPING_AGENT",
    )
    snowflake_transformation_rule_agent: str = Field(
        default="",
        alias="SNOWFLAKE_TRANSFORMATION_RULE_AGENT",
    )
    snowflake_semantic_model_agent: str = Field(
        default="",
        alias="SNOWFLAKE_SEMANTIC_MODEL_AGENT",
    )
    snowflake_workbench_conversation_agent: str = Field(
        default="",
        alias="SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT",
    )
    conversation_model_route_planning_enabled: bool = Field(
        default=False,
        alias="CONVERSATION_MODEL_ROUTE_PLANNING_ENABLED",
    )
    snowflake_dbt_conversion_agent: str = Field(
        default="",
        alias="SNOWFLAKE_DBT_CONVERSION_AGENT",
    )
    snowflake_test_case_generation_agent: str = Field(
        default="",
        alias="SNOWFLAKE_TEST_CASE_GENERATION_AGENT",
    )
    snowflake_relationships_procedure: str = Field(
        default="",
        alias="SNOWFLAKE_RELATIONSHIPS_PROCEDURE",
    )
    snowflake_semantic_model_table: str = Field(
        default="TBL_SEMANTIC_MODELS",
        alias="SNOWFLAKE_SEMANTIC_MODEL_TABLE",
    )
    snowflake_semantic_table_views_table: str = Field(
        default="SEM_TABLE_VIEWS",
        alias="SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE",
    )
    snowflake_semantic_views_database: str = Field(
        default="",
        alias="SNOWFLAKE_SEMANTIC_VIEWS_DATABASE",
        description="Database where SEM_TABLE_VIEWS lives (fallback for relationship extraction)",
    )
    snowflake_semantic_views_schema: str = Field(
        default="",
        alias="SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA",
        description="Schema where SEM_TABLE_VIEWS lives (fallback for relationship extraction)",
    )
    snowflake_semantic_column_views_table: str = Field(
        default="SEM_COLUMN_VIEWS",
        alias="SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE",
    )
    snowflake_semantic_native_views_table: str = Field(
        default="SEM_NATIVE_VIEWS",
        alias="SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE",
    )
    snowflake_semantic_projections_table: str = Field(
        default="TBL_SEMANTIC_PROJECTIONS",
        alias="SNOWFLAKE_SEMANTIC_PROJECTIONS_TABLE",
    )
    snowflake_semantic_bundles_table: str = Field(
        default="TBL_SEMANTIC_BUNDLES",
        alias="SNOWFLAKE_SEMANTIC_BUNDLES_TABLE",
    )
    snowflake_semantic_overrides_table: str = Field(
        default="TBL_SEMANTIC_OVERRIDES",
        alias="SNOWFLAKE_SEMANTIC_OVERRIDES_TABLE",
    )
    snowflake_derived_sources_table: str = Field(
        default="TBL_DERIVED_SOURCES",
        alias="SNOWFLAKE_DERIVED_SOURCES_TABLE",
    )
    snowflake_derived_view_prefix: str = Field(
        default="VW_DERIVED_SOURCE_",
        alias="SNOWFLAKE_DERIVED_VIEW_PREFIX",
    )
    snowflake_conversation_turns_table: str = Field(
        default="TBL_WORKBENCH_CONVERSATION_TURNS",
        alias="SNOWFLAKE_CONVERSATION_TURNS_TABLE",
    )
    snowflake_conversation_feedback_table: str = Field(
        default="TBL_WORKBENCH_FEEDBACK",
        alias="SNOWFLAKE_CONVERSATION_FEEDBACK_TABLE",
    )
    snowflake_conversation_recommendations_table: str = Field(
        default="TBL_WORKBENCH_RECOMMENDATIONS",
        alias="SNOWFLAKE_CONVERSATION_RECOMMENDATIONS_TABLE",
    )
    snowflake_assistant_inferences_table: str = Field(
        default="TBL_WORKBENCH_INFERENCES",
        alias="SNOWFLAKE_ASSISTANT_INFERENCES_TABLE",
    )
    snowflake_assistant_signals_table: str = Field(
        default="TBL_WORKBENCH_ASSISTANT_SIGNALS",
        alias="SNOWFLAKE_ASSISTANT_SIGNALS_TABLE",
    )
    snowflake_assistant_settings_table: str = Field(
        default="TBL_WORKBENCH_ASSISTANT_SETTINGS",
        alias="SNOWFLAKE_ASSISTANT_SETTINGS_TABLE",
    )
    snowflake_relationship_facts_table: str = Field(
        default="TBL_WORKBENCH_RELATIONSHIP_FACTS",
        alias="SNOWFLAKE_RELATIONSHIP_FACTS_TABLE",
    )
    snowflake_rag_documents_table: str = Field(
        default="TBL_WORKBENCH_RAG_DOCUMENTS",
        alias="SNOWFLAKE_RAG_DOCUMENTS_TABLE",
    )
    snowflake_client_notes_table: str = Field(
        default="TBL_WORKBENCH_CLIENT_NOTES",
        alias="SNOWFLAKE_CLIENT_NOTES_TABLE",
    )
    snowflake_client_sql_assets_table: str = Field(
        default="TBL_WORKBENCH_CLIENT_SQL_ASSETS",
        alias="SNOWFLAKE_CLIENT_SQL_ASSETS_TABLE",
    )
    snowflake_fir_events_table: str = Field(
        default="TBL_WORKBENCH_FIR_EVENTS",
        alias="SNOWFLAKE_FIR_EVENTS_TABLE",
    )
    snowflake_fir_feature_snapshots_table: str = Field(
        default="TBL_WORKBENCH_FIR_FEATURES",
        alias="SNOWFLAKE_FIR_FEATURES_TABLE",
    )
    snowflake_mapping_intents_table: str = Field(
        default="TBL_WORKBENCH_MAPPING_INTENTS",
        alias="SNOWFLAKE_MAPPING_INTENTS_TABLE",
    )
    snowflake_semantic_learnings_table: str = Field(
        default="TBL_WORKBENCH_SEMANTIC_LEARNINGS",
        alias="SNOWFLAKE_SEMANTIC_LEARNINGS_TABLE",
    )
    snowflake_fir_model_scores_table: str = Field(
        default="TBL_WORKBENCH_FIR_MODEL_SCORES",
        alias="SNOWFLAKE_FIR_MODEL_SCORES_TABLE",
    )
    snowflake_fir_templates_table: str = Field(
        default="TBL_WORKBENCH_FIR_TEMPLATES",
        alias="SNOWFLAKE_FIR_TEMPLATES_TABLE",
    )

    # FIR System Tables (AGT_FIR_SYSTEM batch processing)
    snowflake_fir_360_table: str = Field(
        default="TBL_AGENT_FIR_360",
        alias="SNOWFLAKE_FIR_360_TABLE",
        description="Core FIR lineage table linking feedback → inference → recommendation",
    )
    snowflake_semantic_versions_table: str = Field(
        default="TBL_SEMANTIC_VIEW_VERSIONS",
        alias="SNOWFLAKE_SEMANTIC_VERSIONS_TABLE",
        description="Versioned curated semantic views (RAW → CURATED_V1 → CURATED_V2)",
    )
    snowflake_fir_agent_recommendations_table: str = Field(
        default="TBL_FIR_AGENT_RECOMMENDATIONS",
        alias="SNOWFLAKE_FIR_AGENT_RECOMMENDATIONS_TABLE",
        description="Agent-specific recommendations with trigger conditions",
    )

    # FIR Feature Flags
    fir_streaming_enabled: bool = Field(
        default=False,
        alias="FIR_STREAMING_ENABLED",
        description="Enable streaming responses from agents (feature flag for phased rollout)",
    )
    fir_signal_bus_enabled: bool = Field(
        default=True,
        alias="FIR_SIGNAL_BUS_ENABLED",
        description="Enable real-time signal delivery via WebSocket",
    )
    fir_signal_max_per_window: int = Field(
        default=3,
        alias="FIR_SIGNAL_MAX_PER_WINDOW",
        description="Maximum signals to deliver per time window",
    )
    fir_signal_window_seconds: int = Field(
        default=30,
        alias="FIR_SIGNAL_WINDOW_SECONDS",
        description="Time window for signal batching in seconds",
    )
    fir_learning_context_enabled: bool = Field(
        default=True,
        alias="FIR_LEARNING_CONTEXT_ENABLED",
        description="Enable learning context injection into agent requests",
    )
    prepared_workspace_context_v2: bool = Field(
        default=True,
        alias="PREPARED_WORKSPACE_CONTEXT_V2",
    )
    perf_diagnostics_v1: bool = Field(
        default=True,
        alias="PERF_DIAGNOSTICS_V1",
    )
    prepared_context_cache_v2: bool = Field(
        default=True,
        alias="PREPARED_CONTEXT_CACHE_V2",
    )
    context_singleflight_v1: bool = Field(
        default=True,
        alias="CONTEXT_SINGLEFLIGHT_V1",
    )
    fir_query_pruning_v1: bool = Field(
        default=True,
        alias="FIR_QUERY_PRUNING_V1",
    )
    target_scoped_cache_invalidation_v1: bool = Field(
        default=True,
        alias="TARGET_SCOPED_CACHE_INVALIDATION_V1",
    )
    relationship_capability_cache_v1: bool = Field(
        default=True,
        alias="RELATIONSHIP_CAPABILITY_CACHE_V1",
    )
    relationship_proc_fast_guards_v1: bool = Field(
        default=True,
        alias="RELATIONSHIP_PROC_FAST_GUARDS_V1",
    )
    low_confidence_join_review_v1: bool = Field(
        default=True,
        alias="LOW_CONFIDENCE_JOIN_REVIEW_V1",
    )
    conversation_memory_v2: bool = Field(
        default=True,
        alias="CONVERSATION_MEMORY_V2",
    )
    snowflake_session_lease_pool_v1: bool = Field(
        default=False,
        alias="SNOWFLAKE_SESSION_LEASE_POOL_V1",
    )
    snowflake_write_lease_pool_v1: bool = Field(
        default=False,
        alias="SNOWFLAKE_WRITE_LEASE_POOL_V1",
    )
    learning_parallel_v1: bool = Field(
        default=False,
        alias="LEARNING_PARALLEL_V1",
    )
    prepare_parallel_v1: bool = Field(
        default=False,
        alias="PREPARE_PARALLEL_V1",
    )
    autosave_singleflight_v1: bool = Field(
        default=True,
        alias="AUTOSAVE_SINGLEFLIGHT_V1",
    )
    autosave_postsave_async_v1: bool = Field(
        default=False,
        alias="AUTOSAVE_POSTSAVE_ASYNC_V1",
    )
    preparation_warehouse_routing_v1: bool = Field(
        default=False,
        alias="PREPARATION_WAREHOUSE_ROUTING_V1",
    )
    durable_sttm_route_v1: bool = Field(
        default=True,
        alias="DURABLE_STTM_ROUTE_V1",
    )
    agent_request_scoped_analyst_v1: bool = Field(
        default=False, alias="AGENT_REQUEST_SCOPED_ANALYST_V1",
    )
    agent_bundle_view_schema: str = Field(
        default="", alias="AGENT_BUNDLE_VIEW_SCHEMA",
    )
    agent_stream_batching_v1: bool = Field(
        default=True,
        alias="AGENT_STREAM_BATCHING_V1",
    )
    agent_payload_budget_v1: bool = Field(
        default=True,
        alias="AGENT_PAYLOAD_BUDGET_V1",
    )
    auto_mapping_payload_budget_v1: bool = Field(
        default=True,
        alias="AUTO_MAPPING_PAYLOAD_BUDGET_V1",
    )
    agent_oversize_retry_v1: bool = Field(
        default=True,
        alias="AGENT_OVERSIZE_RETRY_V1",
    )
    backend_read_cache_v1: bool = Field(
        default=True,
        alias="BACKEND_READ_CACHE_V1",
    )
    dev_snapshot_cache_mode: str = Field(
        default="off",
        alias="DEV_SNAPSHOT_CACHE_MODE",
    )
    dev_snapshot_cache_dir: str = Field(
        default=".dev-cache/snowflake-api",
        alias="DEV_SNAPSHOT_CACHE_DIR",
    )
    dev_snapshot_cache_ttl_seconds: int = Field(
        default=1_209_600,
        alias="DEV_SNAPSHOT_CACHE_TTL_SECONDS",
    )
    sttm_source_bulk_write_v1: bool = Field(
        default=True,
        alias="STTM_SOURCE_BULK_WRITE_V1",
    )
    sttm_mapping_bulk_write_v1: bool = Field(
        default=True,
        alias="STTM_MAPPING_BULK_WRITE_V1",
    )
    assistant_streaming_v2: bool = Field(
        default=True,
        alias="ASSISTANT_STREAMING_V2",
    )
    chat_deferred_writes_v1: bool = Field(
        default=True,
        alias="CHAT_DEFERRED_WRITES_V1",
        description=(
            "Send response.completed before the artifact and conversation-turn writes; "
            "they still run on the same stream so the request session stays open"
        ),
    )
    fir_target_mapping_patterns_v2: bool = Field(
        default=True,
        alias="FIR_TARGET_MAPPING_PATTERNS_V2",
    )
    fir_recommendation_max_age_days: int = Field(
        default=30,
        ge=0,
        alias="FIR_RECOMMENDATION_MAX_AGE_DAYS",
        description=(
            "Hide unvalidated FIR recommendations older than this many days "
            "(0 disables the cutoff)"
        ),
    )
    fir_document_lineage_v3: bool = Field(
        default=True,
        alias="FIR_DOCUMENT_LINEAGE_V3",
        description="Enable SQL lineage V3 bundle curation and review workflows",
    )
    fir_durable_jobs_v2: bool = Field(
        default=True,
        alias="FIR_DURABLE_JOBS_V2",
    )
    prepared_context_l1_idle_seconds: int = Field(
        default=3600,
        alias="PREPARED_CONTEXT_L1_IDLE_SECONDS",
    )
    prepared_context_soft_revalidate_seconds: int = Field(
        default=86400,
        alias="PREPARED_CONTEXT_SOFT_REVALIDATE_SECONDS",
    )
    prepared_context_cleanup_days: int = Field(
        default=30,
        alias="PREPARED_CONTEXT_CLEANUP_DAYS",
    )
    prepared_context_debounce_ms: int = Field(
        default=750,
        alias="PREPARED_CONTEXT_DEBOUNCE_MS",
    )
    learning_parallel_workers: int = Field(
        default=4,
        alias="LEARNING_PARALLEL_WORKERS",
    )
    snowflake_session_lease_limit_per_instance: int = Field(
        default=12,
        alias="SNOWFLAKE_SESSION_LEASE_LIMIT_PER_INSTANCE",
    )
    relationship_capability_cache_seconds: int = Field(
        default=86400,
        alias="RELATIONSHIP_CAPABILITY_CACHE_SECONDS",
    )
    snowflake_prepared_workspace_contexts_table: str = Field(
        default="TBL_PREPARED_WORKSPACE_CONTEXTS",
        alias="SNOWFLAKE_PREPARED_WORKSPACE_CONTEXTS_TABLE",
    )
    snowflake_target_mapping_patterns_table: str = Field(
        default="TBL_FIR_TARGET_MAPPING_PATTERNS",
        alias="SNOWFLAKE_TARGET_MAPPING_PATTERNS_TABLE",
    )
    snowflake_fir_learning_jobs_table: str = Field(
        default="TBL_FIR_LEARNING_JOBS",
        alias="SNOWFLAKE_FIR_LEARNING_JOBS_TABLE",
    )
    snowflake_fir_learning_work_items_table: str = Field(
        default="TBL_FIR_LEARNING_WORK_ITEMS",
        alias="SNOWFLAKE_FIR_LEARNING_WORK_ITEMS_TABLE",
    )
    fir_pipeline_enabled: bool = Field(
        default=True,
        alias="FIR_PIPELINE_ENABLED",
    )
    fir_agent_processing_enabled: bool = Field(
        default=True,
        alias="FIR_AGENT_PROCESSING_ENABLED",
    )
    fir_catchup_schedule_cron: str = Field(
        default="USING CRON 0 2,14 * * * UTC",
        alias="FIR_CATCHUP_SCHEDULE_CRON",
    )
    fir_agent_request_timeout_seconds: int = Field(
        default=840,
        alias="FIR_AGENT_REQUEST_TIMEOUT_SECONDS",
    )
    fir_agent_max_assets_per_run: int = Field(
        default=1,
        alias="FIR_AGENT_MAX_ASSETS_PER_RUN",
    )
    fir_agent_max_patterns_per_batch: int = Field(
        default=10,
        alias="FIR_AGENT_MAX_PATTERNS_PER_BATCH",
    )
    fir_agent_max_concurrency: int = Field(
        default=2,
        alias="FIR_AGENT_MAX_CONCURRENCY",
    )
    fir_agent_retry_limit: int = Field(
        default=2,
        alias="FIR_AGENT_RETRY_LIMIT",
    )
    fir_process_uploads_immediately: bool = Field(
        default=True,
        alias="FIR_PROCESS_UPLOADS_IMMEDIATELY",
    )
    fir_upload_explanations_enabled: bool = Field(
        default=True,
        alias="FIR_UPLOAD_EXPLANATIONS_ENABLED",
    )
    fir_upload_explanation_model: str = Field(
        default="claude-haiku-4-5",
        alias="FIR_UPLOAD_EXPLANATION_MODEL",
    )
    fir_upload_explanation_timeout_seconds: int = Field(
        default=60, ge=5, le=90,
        alias="FIR_UPLOAD_EXPLANATION_TIMEOUT_SECONDS",
    )
    fir_agent_daily_request_limit: int = Field(
        default=50,
        alias="FIR_AGENT_DAILY_REQUEST_LIMIT",
    )
    fir_agent_daily_token_limit: int = Field(
        default=20_000_000,
        alias="FIR_AGENT_DAILY_TOKEN_LIMIT",
    )
    fir_job_max_runtime_seconds: int = Field(
        default=3600,
        alias="FIR_JOB_MAX_RUNTIME_SECONDS",
    )

    snowflake_workspace_snapshots_table: str = Field(
        default="TBL_WORKSPACE_SNAPSHOTS",
        alias="SNOWFLAKE_WORKSPACE_SNAPSHOTS_TABLE",
    )
    snowflake_agent_artifacts_table: str = Field(
        default="TBL_AGENT_ARTIFACTS",
        alias="SNOWFLAKE_AGENT_ARTIFACTS_TABLE",
    )
    snowflake_agent_artifact_stage: str = Field(
        default="AI_WORKBENCH_ARTIFACTS",
        alias="SNOWFLAKE_AGENT_ARTIFACT_STAGE",
    )
    agent_inline_artifact_limit_bytes: int = Field(
        default=32768,
        alias="AGENT_INLINE_ARTIFACT_LIMIT_BYTES",
    )
    agent_caller_inline_fallback_limit_bytes: int = Field(
        default=1048576,
        alias="AGENT_CALLER_INLINE_FALLBACK_LIMIT_BYTES",
    )
    agent_artifact_draft_retention_days: int = Field(
        default=90,
        alias="AGENT_ARTIFACT_DRAFT_RETENTION_DAYS",
    )
    agent_prompt_artifact_capture: bool = Field(
        default=False,
        alias="AGENT_PROMPT_ARTIFACT_CAPTURE",
        description="Opt-in owner-scoped prompt artifacts; may contain sensitive source context.",
    )
    snowflake_conversation_segments_table: str = Field(
        default="TBL_WORKBENCH_CONVERSATION_SEGMENTS",
        alias="SNOWFLAKE_CONVERSATION_SEGMENTS_TABLE",
    )
    agent_context_limit_tokens: int = Field(
        default=90000,
        alias="AGENT_CONTEXT_LIMIT_TOKENS",
    )
    agent_outbound_message_max_chars: int = Field(
        default=60000,
        alias="AGENT_OUTBOUND_MESSAGE_MAX_CHARS",
    )
    agent_outbound_message_max_bytes: int = Field(
        default=65536,
        alias="AGENT_OUTBOUND_MESSAGE_MAX_BYTES",
    )
    agent_payload_compact_encoding: bool = Field(
        default=False,
        alias="AGENT_PAYLOAD_COMPACT_ENCODING",
        description="Experimental packed prompt encoding; keep off until mapping accuracy is evaluated.",
    )
    automap_hybrid_context_v1: bool = Field(default=False, alias="AUTOMAP_HYBRID_CONTEXT_V1")
    automap_context_retrieval_v1: bool = Field(default=False, alias="AUTOMAP_CONTEXT_RETRIEVAL_V1")
    automap_fast_path_v1: bool = Field(default=False, alias="AUTOMAP_FAST_PATH_V1")
    automap_fast_project_ids: str = Field(
        default="", alias="AUTOMAP_FAST_PROJECT_IDS",
        description="Deprecated project rollout list, retained for configuration compatibility. Enabled Auto-map uses one engine for all projects.",
    )
    automap_fast_canary_revision: str = Field(
        default="", alias="AUTOMAP_FAST_CANARY_REVISION",
        description="Non-secret deployment label only; never enables or expands the canary.",
    )

    @field_validator("automap_fast_path_v1", mode="before")
    @classmethod
    def validate_fast_boolean(cls, value):
        if type(value) is bool:
            return value
        if isinstance(value, str) and value in {"true", "false"}:
            return value == "true"
        raise ValueError("AUTOMAP_FAST_PATH_V1 must be a boolean or canonical true/false")

    @field_validator("automap_fast_project_ids", mode="before")
    @classmethod
    def validate_fast_project_ids(cls, value):
        if not isinstance(value, str):
            raise ValueError("AUTOMAP_FAST_PROJECT_IDS must be a CSV string")
        if value in {"", "*"}:
            return value
        if len(value) > 1247 or not re.fullmatch(r"[1-9][0-9]{0,37}(?:,[1-9][0-9]{0,37}){0,31}", value):
            raise ValueError("AUTOMAP_FAST_PROJECT_IDS requires at most 32 canonical positive decimal IDs of at most 38 digits")
        projects = value.split(",")
        if len(projects) != len(set(projects)):
            raise ValueError("AUTOMAP_FAST_PROJECT_IDS must not contain duplicate IDs")
        return value

    @field_validator("automap_fast_canary_revision", mode="before")
    @classmethod
    def validate_fast_canary_revision(cls, value):
        if not isinstance(value, str) or (value and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", value)):
            raise ValueError("AUTOMAP_FAST_CANARY_REVISION must be an empty or bounded deployment label")
        return value

    automap_local_request_specs: bool = Field(default=False, alias="AUTOMAP_LOCAL_REQUEST_SPECS")
    automap_local_sso_enabled: bool = Field(default=False, alias="AUTOMAP_LOCAL_SSO_ENABLED")
    automap_fast_batch_targets: int = Field(default=8, ge=1, le=8, alias="AUTOMAP_FAST_BATCH_TARGETS")
    automap_fast_max_in_flight: int = Field(default=8, ge=1, le=32, alias="AUTOMAP_FAST_MAX_IN_FLIGHT")
    automap_fast_batch_seconds: int = Field(default=60, ge=10, le=600, alias="AUTOMAP_FAST_BATCH_SECONDS")
    automap_fast_job_seconds: int = Field(default=180, ge=60, le=600, alias="AUTOMAP_FAST_JOB_SECONDS")

    @model_validator(mode="after")
    def validate_local_automap(self):
        if self.automap_local_request_specs and not self.automap_local_sso_enabled:
            raise ValueError("Local request specs require explicit DEV-only local Auto-map authentication")
        if self.automap_local_sso_enabled:
            from app.core.automap_local_session import validate_local_settings
            validate_local_settings(self)
        return self

    automap_parallel_context_v1: bool = Field(default=False, alias="AUTOMAP_PARALLEL_CONTEXT_V1")
    automap_parallel_test_agent: str = Field(default="", alias="AUTOMAP_PARALLEL_TEST_AGENT")
    automap_parallel_permit_table_fqn: str = Field(default="", alias="AUTOMAP_PARALLEL_PERMIT_TABLE_FQN")
    automap_parallel_archive_table_fqn: str = Field(default="", alias="AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN")
    automap_parallel_account_namespace: str = Field(default="", alias="AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE")
    automap_parallel_pool_epoch: str = Field(default="", alias="AUTOMAP_PARALLEL_POOL_EPOCH")
    # Provisioned scan/reduce admission only, not an account-wide cap on all LLM calls.
    # Zero is the renderer's disabled sentinel; enabling requires capacity 1..32.
    automap_queue_seconds: int = Field(default=900, ge=30, le=3600, alias="AUTOMAP_QUEUE_SECONDS")
    automap_durable_runs_v2: bool = Field(default=False, alias="AUTOMAP_DURABLE_RUNS_V2")
    automap_recovery_capacity: int = Field(default=4, ge=1, le=16, alias="AUTOMAP_RECOVERY_CAPACITY")
    automap_run_seconds: int = Field(default=180, ge=10, le=600, alias="AUTOMAP_RUN_SECONDS")
    automap_recovery_poll_seconds: int = Field(default=5, ge=1, le=60, alias="AUTOMAP_RECOVERY_POLL_SECONDS")
    automap_run_retry_attempts: int = Field(default=2, ge=0, le=3, alias="AUTOMAP_RUN_RETRY_ATTEMPTS")
    automap_admission_session_capacity: int = Field(
        default=2, ge=1, le=8, alias="AUTOMAP_ADMISSION_SESSION_CAPACITY",
        description="Exclusive CONTROL sessions per matching caller/purpose/process; tune independently of model permits.",
    )
    automap_parallel_pool_capacity: int | None = Field(default=None, ge=0, le=32, alias="AUTOMAP_PARALLEL_POOL_CAPACITY")
    # Per-runtime scan workers; runtime clamps this to the provisioned capacity.
    automap_parallel_max_workers: int = Field(default=2, ge=1, le=32, alias="AUTOMAP_PARALLEL_MAX_WORKERS")
    automap_parallel_max_calls: int = Field(default=32, ge=1, le=64, alias="AUTOMAP_PARALLEL_MAX_CALLS")
    automap_parallel_max_reduction_rounds: int = Field(default=16, ge=0, le=32, alias="AUTOMAP_PARALLEL_MAX_REDUCTION_ROUNDS")

    @field_validator("automap_parallel_pool_capacity", "automap_parallel_max_workers",
                     "automap_parallel_max_calls", "automap_parallel_max_reduction_rounds", mode="before")
    @classmethod
    def validate_parallel_integer(cls, value):
        if isinstance(value, (bool, float)):
            raise ValueError("Parallel capacity and limits must be integers")
        return value

    @model_validator(mode="after")
    def validate_parallel_automap(self):
        if self.automap_durable_runs_v2:
            if not (self.automap_parallel_context_v1 and self.automap_fast_path_v1):
                raise ValueError('AUTOMAP_DURABLE_RUNS_V2 requires parallel admission and fast-path execution')
            if (self.automap_parallel_pool_capacity or 0)+self.automap_recovery_capacity>32:
                raise ValueError('Durable execution plus recovery capacity must not exceed 32')
        if self.automap_parallel_context_v1:
            if not self.automap_context_retrieval_v1:
                raise ValueError("AUTOMAP_PARALLEL_CONTEXT_V1 requires AUTOMAP_CONTEXT_RETRIEVAL_V1")
            for name in ("automap_parallel_test_agent", "automap_parallel_permit_table_fqn",
                         "automap_parallel_archive_table_fqn"):
                value = getattr(self, name)
                if (not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_$]*(?:\.[A-Za-z_][A-Za-z0-9_$]*){2}", value)
                        or _looks_like_placeholder(value)):
                    raise ValueError(f"{name.upper()} requires an explicit fully qualified name")
            if not re.fullmatch(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", self.automap_parallel_account_namespace):
                raise ValueError("AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE requires explicit canonical ORG.ACCOUNT")
            try:
                if str(UUID(self.automap_parallel_pool_epoch)) != self.automap_parallel_pool_epoch:
                    raise ValueError
            except ValueError:
                raise ValueError("AUTOMAP_PARALLEL_POOL_EPOCH requires an explicit canonical UUID") from None
            if self.automap_parallel_pool_capacity is None or self.automap_parallel_pool_capacity == 0:
                raise ValueError("AUTOMAP_PARALLEL_POOL_CAPACITY requires explicit provisioned capacity in [1, 32]")
        return self

    automap_context_batch_count: int = Field(default=4, ge=3, le=4, alias="AUTOMAP_CONTEXT_BATCH_COUNT")
    automap_context_max_rounds: int = Field(default=6, ge=1, le=12, alias="AUTOMAP_CONTEXT_MAX_ROUNDS")
    automap_context_max_operations: int = Field(default=256, ge=1, le=1024, alias="AUTOMAP_CONTEXT_MAX_OPERATIONS")
    automap_context_max_reads: int = Field(default=24, ge=1, le=64, alias="AUTOMAP_CONTEXT_MAX_READS")
    automap_context_target_seconds: int = Field(default=240, ge=30, le=600, alias="AUTOMAP_CONTEXT_TARGET_SECONDS")
    automap_learning_initial_limit: int = Field(default=4, ge=1, le=4, alias="AUTOMAP_LEARNING_INITIAL_LIMIT")
    automap_learning_active_limit: int = Field(default=4, ge=1, le=4, alias="AUTOMAP_LEARNING_ACTIVE_LIMIT")
    automap_search_more_rounds: int = Field(default=2, ge=0, le=2, alias="AUTOMAP_SEARCH_MORE_ROUNDS")
    automap_learning_max_chars: int = Field(default=12000, ge=1024, le=30000, alias="AUTOMAP_LEARNING_MAX_CHARS")
    fir_canonical_history_v1: bool = Field(default=False, alias="FIR_CANONICAL_HISTORY_V1")
    automap_recipe_search_service: str = Field(
        default="CSS_AUTOMAP_RECIPES_V1", alias="AUTOMAP_RECIPE_SEARCH_SERVICE",
    )
    automap_column_search_service: str = Field(default="", alias="AUTOMAP_COLUMN_SEARCH_SERVICE")
    agent_thread_context_max_chars: int = Field(
        default=80000,
        alias="AGENT_THREAD_CONTEXT_MAX_CHARS",
    )
    backend_project_summary_cache_seconds: int = Field(
        default=300,
        alias="BACKEND_PROJECT_SUMMARY_CACHE_SECONDS",
    )
    backend_recommendation_cache_seconds: int = Field(
        default=15,
        alias="BACKEND_RECOMMENDATION_CACHE_SECONDS",
    )
    table_selection_cache_seconds: int = Field(
        default=3600,
        alias="TABLE_SELECTION_CACHE_SECONDS",
        description=(
            "Per-authorized-user catalog cache lifetime. The cache is shared by UI and "
            "agent context services inside each SPCS backend instance."
        ),
    )
    table_selection_stale_if_error_seconds: int = Field(
        default=86400,
        alias="TABLE_SELECTION_STALE_IF_ERROR_SECONDS",
        description=(
            "Maximum age of a previously authorized catalog entry that may be served "
            "when Snowflake metadata refresh is temporarily unavailable."
        ),
    )
    agent_thread_rollover_ratio: float = Field(
        default=0.65,
        alias="AGENT_THREAD_ROLLOVER_RATIO",
    )
    agent_thread_hard_ratio: float = Field(
        default=0.80,
        alias="AGENT_THREAD_HARD_RATIO",
    )
    agent_recent_turns_to_keep: int = Field(
        default=8,
        alias="AGENT_RECENT_TURNS_TO_KEEP",
    )
    agent_max_turns_per_segment: int = Field(
        default=60,
        alias="AGENT_MAX_TURNS_PER_SEGMENT",
    )
    snowflake_projects_table: str = Field(
        default="TBL_PROJECTS",
        alias="SNOWFLAKE_PROJECTS_TABLE",
    )
    snowflake_project_attributes_table: str = Field(
        default="TBL_PROJECT_ATTRIBUTES",
        alias="SNOWFLAKE_PROJECT_ATTRIBUTES_TABLE",
    )
    snowflake_sttm_table: str = Field(
        default="TBL_STTM",
        alias="SNOWFLAKE_STTM_TABLE",
    )
    snowflake_sttm_versions_table: str = Field(
        default="TBL_STTM_VERSIONS",
        alias="SNOWFLAKE_STTM_VERSIONS_TABLE",
    )
    snowflake_sttm_sources_table: str = Field(
        default="TBL_STTM_SOURCES",
        alias="SNOWFLAKE_STTM_SOURCES_TABLE",
    )
    snowflake_sttm_attributes_table: str = Field(
        default="TBL_STTM_ATTRIBUTES",
        alias="SNOWFLAKE_STTM_ATTRIBUTES_TABLE",
    )
    # Deprecated compatibility alias. Current UI mapping-row state is stored in
    # TBL_STTM_ATTRIBUTES.CONDITION, so no separate mapping-row table is used.
    snowflake_sttm_mapping_rows_table: str = Field(
        default="TBL_STTM_ATTRIBUTES",
        alias="SNOWFLAKE_STTM_MAPPING_ROWS_TABLE",
    )
    snowflake_rag_search_service: str = Field(
        default="CSS_WORKBENCH_RAG",
        alias="SNOWFLAKE_RAG_SEARCH_SERVICE",
    )
    snowflake_agent_orchestration_model: str = Field(
        default="claude-sonnet-4",
        alias="SNOWFLAKE_AGENT_ORCHESTRATION_MODEL",
    )
    snowflake_session_retry_attempts: int = Field(
        default=2,
        alias="SNOWFLAKE_SESSION_RETRY_ATTEMPTS",
    )
    snowflake_session_retry_backoff_seconds: float = Field(
        default=1.0,
        alias="SNOWFLAKE_SESSION_RETRY_BACKOFF_SECONDS",
    )
    snowflake_user_session_cache_ttl_seconds: int = Field(
        default=1800,
        alias="SNOWFLAKE_USER_SESSION_CACHE_TTL_SECONDS",
    )
    snowflake_agent_retry_attempts: int = Field(
        default=3,
        alias="SNOWFLAKE_AGENT_RETRY_ATTEMPTS",
    )
    snowflake_agent_retry_backoff_seconds: float = Field(
        default=1.0,
        alias="SNOWFLAKE_AGENT_RETRY_BACKOFF_SECONDS",
    )
    auto_mapping_service_url: str = Field(
        default="",
        alias="AUTO_MAPPING_SERVICE_URL",
    )
    auto_mapping_service_timeout_seconds: float = Field(
        default=300.0,
        alias="AUTO_MAPPING_SERVICE_TIMEOUT_SECONDS",
    )
    auto_mapping_service_retry_attempts: int = Field(
        default=2,
        alias="AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS",
    )
    auto_mapping_worker_max_concurrency: int = Field(
        default=5,
        alias="AUTO_MAPPING_WORKER_MAX_CONCURRENCY",
    )
    auto_mapping_proxy_batch_size: int = Field(
        default=16,
        alias="AUTO_MAPPING_PROXY_BATCH_SIZE",
    )
    # Per-request worker-batch dispatch cap; retrieval also caps at its batch count.
    # This is not global admission for final mapping or other LLM calls.
    auto_mapping_proxy_max_in_flight: int = Field(
        default=5,
        alias="AUTO_MAPPING_PROXY_MAX_IN_FLIGHT",
    )
    auto_map_pipeline_v2: bool = Field(
        default=False,
        alias="AUTO_MAP_PIPELINE_V2",
    )
    agent_spec_source_mapping_sha256: str = Field(
        default="",
        alias="AGENT_SPEC_SOURCE_MAPPING_SHA256",
    )
    agent_spec_transformation_rule_sha256: str = Field(
        default="",
        alias="AGENT_SPEC_TRANSFORMATION_RULE_SHA256",
    )
    coco_enabled: bool = Field(default=False, alias="COCO_ENABLED")
    coco_service_url: str = Field(
        default="ws://127.0.0.1:8001/api/v1/coco/ws",
        alias="COCO_SERVICE_URL",
    )
    coco_knowledge_dir: str = Field(
        default="/app/knowledge",
        alias="COCO_KNOWLEDGE_DIR",
    )
    coco_workbench_api_url: str = Field(
        default="http://127.0.0.1:8000",
        alias="COCO_WORKBENCH_API_URL",
    )
    coco_snowflake_account: str = Field(default="", alias="COCO_SNOWFLAKE_ACCOUNT")
    coco_snowflake_warehouse: str = Field(default="", alias="COCO_SNOWFLAKE_WAREHOUSE")
    coco_snowflake_database: str = Field(default="", alias="COCO_SNOWFLAKE_DATABASE")
    coco_snowflake_schema: str = Field(default="", alias="COCO_SNOWFLAKE_SCHEMA")
    coco_permission_timeout_seconds: float = Field(
        default=300.0,
        alias="COCO_PERMISSION_TIMEOUT_SECONDS",
    )
    coco_cli_path: str = Field(
        default="/root/.local/bin/cortex",
        alias="CORTEX_CODE_CLI_PATH",
    )
    # Preserve existing DataHub integration settings alongside the Deep Agent.
    datahub_enabled: bool = Field(default=False, alias="DATAHUB_ENABLED")
    datahub_graphql_url: str = Field(default="", alias="DATAHUB_GRAPHQL_URL")
    datahub_ui_url: str = Field(default="", alias="DATAHUB_UI_URL")
    datahub_token: str = Field(default="", alias="DATAHUB_TOKEN")
    datahub_dataset_env: str = Field(default="PROD", alias="DATAHUB_DATASET_ENV")
    datahub_timeout_seconds: float = Field(default=10.0, alias="DATAHUB_TIMEOUT_SECONDS")
    migration_agent_source_mapping_agent: str = Field(default="", alias="MIGRATION_AGENT_SOURCE_MAPPING_AGENT")
    migration_agent_transformation_rule_agent: str = Field(default="", alias="MIGRATION_AGENT_TRANSFORMATION_RULE_AGENT")
    migration_agent_enabled: bool = Field(default=False, alias="MIGRATION_AGENT_ENABLED")
    assistant_unified_history_v1: bool = Field(default=False, alias="ASSISTANT_UNIFIED_HISTORY_V1")
    assistant_intent_routing_v1: bool = Field(default=False, alias="ASSISTANT_INTENT_ROUTING_V1")
    migration_agent_true_resume_v1: bool = Field(default=False, alias="MIGRATION_AGENT_TRUE_RESUME_V1")
    migration_agent_host_terminalization_v1: bool = Field(default=True, alias="MIGRATION_AGENT_HOST_TERMINALIZATION_V1")
    # Greetings and "what can you do" are answered locally in Deep mode instead
    # of starting a durable supervisor run.
    assistant_local_capability_answers: bool = Field(default=True, alias="ASSISTANT_LOCAL_CAPABILITY_ANSWERS")
    # Free-text turns the deterministic rules cannot place are classified by a
    # light model (structured output). Failures fall back to the rules.
    assistant_model_intent_routing: bool = Field(default=True, alias="ASSISTANT_MODEL_INTENT_ROUTING")
    assistant_intent_model: str = Field(default="", alias="ASSISTANT_INTENT_MODEL")  # empty: the light model
    assistant_intent_timeout_seconds: int = Field(default=5, ge=1, le=30, alias="ASSISTANT_INTENT_TIMEOUT_SECONDS")
    assistant_intent_min_confidence: float = Field(default=0.7, ge=0.0, le=1.0, alias="ASSISTANT_INTENT_MIN_CONFIDENCE")
    migration_agent_tool_governance_v1: bool = Field(default=False, alias="MIGRATION_AGENT_TOOL_GOVERNANCE_V1")
    migration_agent_effort_overrides: dict[str, dict[str, int | float | str]] = Field(
        default_factory=dict, alias="MIGRATION_AGENT_EFFORT_OVERRIDES"
    )
    @field_validator("migration_agent_effort_overrides", "migration_agent_capacity_scopes", "migration_agent_capacity_limits", mode="before")
    @classmethod
    def parse_deep_runtime_json(cls, value):
        # Environment sources decode JSON already; deployment dictionaries and
        # direct constructor callers can supply the equivalent serialized form.
        if isinstance(value, str):
            import json
            return json.loads(value)
        return value

    migration_agent_capacity_scopes: list[str] = Field(default_factory=list, alias="MIGRATION_AGENT_CAPACITY_SCOPES")
    migration_agent_capacity_limits: dict[str, int] = Field(default_factory=dict, alias="MIGRATION_AGENT_CAPACITY_LIMITS")
    migration_agent_capacity_procedure: str = Field(default="SP_ENSURE_AGENT_CAPACITY", alias="MIGRATION_AGENT_CAPACITY_PROCEDURE")
    migration_agent_capacity_table: str = Field(default="TBL_AGENT_CAPACITY_SLOTS", alias="MIGRATION_AGENT_CAPACITY_TABLE")
    migration_agent_capacity_wait_seconds: int = Field(default=30, ge=1, alias="MIGRATION_AGENT_CAPACITY_WAIT_SECONDS")
    migration_agent_worker_id: str = Field(default="agent-worker", alias="MIGRATION_AGENT_WORKER_ID")
    migration_agent_lease_seconds: int = Field(default=120, alias="MIGRATION_AGENT_LEASE_SECONDS")
    migration_agent_lock_timeout_seconds: int = Field(default=10, ge=1, le=60, alias="MIGRATION_AGENT_LOCK_TIMEOUT_SECONDS")
    migration_agent_heartbeat_seconds: int = Field(default=30, alias="MIGRATION_AGENT_HEARTBEAT_SECONDS")
    migration_agent_outbox_recovery_interval_seconds: int = Field(default=60, ge=5, le=3600, alias="MIGRATION_AGENT_OUTBOX_RECOVERY_INTERVAL_SECONDS")
    migration_agent_outbox_recovery_batch_size: int = Field(default=25, ge=1, le=1000, alias="MIGRATION_AGENT_OUTBOX_RECOVERY_BATCH_SIZE")
    migration_agent_max_concurrency: int = Field(default=2, alias="MIGRATION_AGENT_MAX_CONCURRENCY")
    # Loopback UDP base port; slot N listens on base+N. 0 disables the wake-up
    # signal and leaves pure lease polling (required when API and worker run
    # on different hosts).
    migration_agent_wake_port: int = Field(default=0, ge=0, le=65000, alias="MIGRATION_AGENT_WAKE_PORT")
    migration_agent_attachment_stage: str = Field(
        default="@WORKBENCH_AGENT_ATTACHMENTS",
        alias="MIGRATION_AGENT_ATTACHMENT_STAGE",
    )
    migration_agent_checkpoint_stage: str = Field(
        default="@WORKBENCH_AGENT_CHECKPOINTS",
        alias="MIGRATION_AGENT_CHECKPOINT_STAGE",
    )
    migration_agent_checkpoint_io_timeout_seconds: float = Field(
        default=30.0,
        gt=0,
        alias="MIGRATION_AGENT_CHECKPOINT_IO_TIMEOUT_SECONDS",
    )
    migration_agent_model_light: str = Field(default="", alias="MIGRATION_AGENT_MODEL_LIGHT")
    migration_agent_plan_offer_min_workstreams: int = Field(default=3, ge=2, le=6, alias="MIGRATION_AGENT_PLAN_OFFER_MIN_WORKSTREAMS")
    migration_agent_precedent_project_limit: int = Field(default=5, ge=1, le=30, alias="MIGRATION_AGENT_PRECEDENT_PROJECT_LIMIT")
    migration_agent_source_research_idle_boundaries: int = Field(default=4, ge=2, le=12, alias="MIGRATION_AGENT_SOURCE_RESEARCH_IDLE_BOUNDARIES")
    # Reading a precedent's whole source design (often 15-20 tables) is one legitimate batch.
    migration_agent_contract_batch_limit: int = Field(default=24, ge=2, le=48, alias="MIGRATION_AGENT_CONTRACT_BATCH_LIMIT")
    migration_agent_multi_target_limit: int = Field(default=10, ge=2, le=30, alias="MIGRATION_AGENT_MULTI_TARGET_LIMIT")
    # Multi-target runs: a target's join path that is neither data-verified nor
    # confirmed earlier leaves that source out of the target (its columns are
    # reported for review) instead of stopping every other target. "ask" keeps
    # the target in needs_research for the supervisor's single-target flow.
    migration_agent_multi_target_unjoined_policy: Literal["exclude", "ask"] = Field(
        default="exclude", alias="MIGRATION_AGENT_MULTI_TARGET_UNJOINED_POLICY")
    # When less than this share of a reused design's supporting tables joins
    # the driving source, the design fits another client's shape: a fresh
    # source proposal is prepared and kept if it joins more of its tables.
    migration_agent_multi_target_min_joined_fraction: float = Field(
        default=0.5, ge=0.0, le=1.0, alias="MIGRATION_AGENT_MULTI_TARGET_MIN_JOINED_FRACTION")
    # A target without any precedent gets its sources proposed by a model from
    # the requested source schema's metadata; the host validates every name
    # and verifies the joins against the data. Proposals below this confidence
    # are reported for review instead of being used.
    migration_agent_source_scout_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_SOURCE_SCOUT_ENABLED")
    migration_agent_source_scout_model: str = Field(default="", alias="MIGRATION_AGENT_SOURCE_SCOUT_MODEL")
    migration_agent_source_scout_min_confidence: float = Field(
        default=0.6, ge=0.0, le=1.0, alias="MIGRATION_AGENT_SOURCE_SCOUT_MIN_CONFIDENCE")
    migration_agent_source_scout_max_sources: int = Field(
        default=8, ge=1, le=24, alias="MIGRATION_AGENT_SOURCE_SCOUT_MAX_SOURCES")
    migration_agent_source_scout_max_tables: int = Field(
        default=200, ge=5, le=1000, alias="MIGRATION_AGENT_SOURCE_SCOUT_MAX_TABLES")
    migration_agent_source_scout_timeout_seconds: int = Field(
        default=60, ge=5, le=300, alias="MIGRATION_AGENT_SOURCE_SCOUT_TIMEOUT_SECONDS")
    # Verified contracts, catalog candidates and read-tool results are kept for
    # the whole conversation (or run) and revalidated on every claim, so a
    # resume or the next turn never re-reads unchanged Snowflake metadata.
    migration_agent_knowledge_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_KNOWLEDGE_ENABLED")
    migration_agent_knowledge_table: str = Field(default="TBL_AGENT_RUN_KNOWLEDGE", alias="MIGRATION_AGENT_KNOWLEDGE_TABLE")
    # Upper bound on reusing any stored item (contracts included) before it is
    # read again from Snowflake.
    migration_agent_knowledge_ttl_seconds: int = Field(default=21600, ge=60, le=604800, alias="MIGRATION_AGENT_KNOWLEDGE_TTL_SECONDS")
    # A stored contract confirmed against the catalog within this window is
    # reused by the next claim without another catalog query (resumes after a
    # question are typically minutes apart). Older ones get one batched
    # column-signature check before reuse. 0 checks on every claim.
    migration_agent_knowledge_recheck_seconds: int = Field(default=600, ge=0, le=86400, alias="MIGRATION_AGENT_KNOWLEDGE_RECHECK_SECONDS")
    # Relationship graph: join candidates are generated from current contracts
    # of the selected sources' schemas, verified against the data and scored.
    migration_agent_relationship_graph_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_RELATIONSHIP_GRAPH_ENABLED")
    migration_agent_relationship_universe_limit: int = Field(default=80, ge=2, le=500, alias="MIGRATION_AGENT_RELATIONSHIP_UNIVERSE_LIMIT")
    migration_agent_relationship_learning_limit: int = Field(default=200, ge=0, le=500, alias="MIGRATION_AGENT_RELATIONSHIP_LEARNING_LIMIT")
    migration_agent_auto_apply_verified_joins: bool = Field(default=True, alias="MIGRATION_AGENT_AUTO_APPLY_VERIFIED_JOINS")
    # Reuse a join a user confirmed earlier for the same (or an identically
    # shaped) table pair instead of asking the same question again.
    migration_agent_reuse_confirmed_joins: bool = Field(default=True, alias="MIGRATION_AGENT_REUSE_CONFIRMED_JOINS")
    # Extra EXPLAIN attempts allowed to find the column expressions that make
    # a generated mapping query fail, so the other columns still compile.
    migration_agent_sql_isolation_max_compiles: int = Field(
        default=16, ge=0, le=64, alias="MIGRATION_AGENT_SQL_ISOLATION_MAX_COMPILES"
    )
    # Join checks in source preparation. A join whose output has more rows
    # than the driving source by this ratio blocks the target unless the CTE
    # designer can express the lookup at one row per key; coverage below the
    # minimum is reported for review.
    migration_agent_join_max_fanout: float = Field(default=1.05, ge=1.0, le=10.0, alias="MIGRATION_AGENT_JOIN_MAX_FANOUT")
    migration_agent_join_min_coverage: float = Field(default=0.95, ge=0.0, le=1.0, alias="MIGRATION_AGENT_JOIN_MIN_COVERAGE")
    # Measure join cardinality and fan-out at every effort, not only when the
    # policy reconciles results (a fan-out otherwise surfaces as wrong rows).
    migration_agent_join_cardinality_check: bool = Field(default=True, alias="MIGRATION_AGENT_JOIN_CARDINALITY_CHECK")
    # Let the agent write CTEs when the data needs them: one row per key for a
    # lookup with duplicate keys, and an aggregate per driving key for a rule
    # that combines several child rows.
    migration_agent_cte_designer_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_CTE_DESIGNER_ENABLED")
    # Joins an aggregate CTE may contain between the driving source and the
    # rows it combines (a link table counts as one).
    migration_agent_cte_bridge_max_hops: int = Field(default=2, ge=1, le=4, alias="MIGRATION_AGENT_CTE_BRIDGE_MAX_HOPS")
    # A precedent CTE written for another schema is reused with its tables
    # re-pointed at the same-named current sources (validated like any CTE).
    migration_agent_precedent_cte_retarget_enabled: bool = Field(
        default=True, alias="MIGRATION_AGENT_PRECEDENT_CTE_RETARGET_ENABLED")
    # Firm values (project values): earlier mappings that bind a target column
    # to a firm value teach the agent to bind it the same way. A binding needs
    # this many earlier mappings; confidence is what a bound row carries; the
    # override flag lets precedent firm values replace a source guess.
    migration_agent_firm_values_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_FIRM_VALUES_ENABLED")
    migration_agent_firm_value_min_support: int = Field(default=1, ge=1, le=20, alias="MIGRATION_AGENT_FIRM_VALUE_MIN_SUPPORT")
    migration_agent_firm_value_confidence: float = Field(default=0.9, ge=0.0, le=1.0, alias="MIGRATION_AGENT_FIRM_VALUE_CONFIDENCE")
    migration_agent_firm_value_override_source: bool = Field(default=True, alias="MIGRATION_AGENT_FIRM_VALUE_OVERRIDE_SOURCE")
    migration_agent_firm_value_candidate_limit: int = Field(default=3, ge=1, le=10, alias="MIGRATION_AGENT_FIRM_VALUE_CANDIDATE_LIMIT")
    # The firm-value catalogue (app/agent_tools/firm_value_catalog.json when empty).
    migration_agent_firm_value_catalog_path: str = Field(default="", alias="MIGRATION_AGENT_FIRM_VALUE_CATALOG_PATH")
    # Filter a driving table's soft-deleted rows (DELETED, IS_DELETED, ...) unless the plan already does.
    migration_agent_soft_delete_filter_enabled: bool = Field(
        default=True, alias="MIGRATION_AGENT_SOFT_DELETE_FILTER_ENABLED")
    # Send the mapping specialists FIR's target-column recipes and stored recommendations (reads only).
    migration_agent_specialist_fir_context_enabled: bool = Field(
        default=True, alias="MIGRATION_AGENT_SPECIALIST_FIR_CONTEXT_ENABLED")
    # While the migration executor runs, the supervisor narrates its progress: at most one update per
    # min-gap, a heartbeat after the quiet interval, and no more than the narration limit per run.
    migration_agent_progress_updates_enabled: bool = Field(
        default=True, alias="MIGRATION_AGENT_PROGRESS_UPDATES_ENABLED")
    migration_agent_progress_heartbeat_seconds: int = Field(
        default=120, ge=15, le=1800, alias="MIGRATION_AGENT_PROGRESS_HEARTBEAT_SECONDS")
    migration_agent_progress_min_gap_seconds: int = Field(
        default=45, ge=5, le=900, alias="MIGRATION_AGENT_PROGRESS_MIN_GAP_SECONDS")
    migration_agent_progress_narration_limit: int = Field(
        default=40, ge=0, le=200, alias="MIGRATION_AGENT_PROGRESS_NARRATION_LIMIT")
    # Supervisor context window in tokens; 0 uses the model's Cortex window (200K for claude-sonnet-4-5,
    # 1M for claude-sonnet-4-6). Deep Agents summarizes older turns at 85% of it.
    migration_agent_max_completion_tokens: int = Field(
        default=16_384, ge=1024, le=65_536, alias="MIGRATION_AGENT_MAX_COMPLETION_TOKENS")
    migration_agent_context_window_tokens: int = Field(
        default=0, ge=0, le=1_000_000, alias="MIGRATION_AGENT_CONTEXT_WINDOW_TOKENS")
    # Cap on supervisor input+output tokens per run; 0 means no token cap.
    migration_agent_token_budget: int = Field(default=0, ge=0, alias="MIGRATION_AGENT_TOKEN_BUDGET")
    # Learning scope (app/core/learning_scope.py): the fixed target schema
    # learnings key on, older target names that are the same table, and the
    # table fingerprints that identify a source system when schema names don't.
    migration_canonical_target_schema: str = Field(
        default="", alias="MIGRATION_CANONICAL_TARGET_SCHEMA")
    migration_canonical_target_tables: str = Field(default="", alias="MIGRATION_CANONICAL_TARGET_TABLES")
    migration_target_aliases_json: str = Field(default="", alias="MIGRATION_TARGET_ALIASES_JSON")
    migration_source_system_fingerprints_json: str = Field(
        default="", alias="MIGRATION_SOURCE_SYSTEM_FINGERPRINTS_JSON")
    # Attachments are read once per run: role, the user's intended use, and
    # cited facts (each quote is checked against the file). SQL is read by the
    # parser; notes, transcripts, documents and spreadsheets by this model
    # (empty uses MIGRATION_AGENT_MODEL_MEDIUM).
    migration_agent_attachment_reading_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_ATTACHMENT_READING_ENABLED")
    migration_agent_attachment_model: str = Field(default="", alias="MIGRATION_AGENT_ATTACHMENT_MODEL")
    migration_agent_attachment_max_chars: int = Field(
        default=60_000, ge=2_000, le=400_000, alias="MIGRATION_AGENT_ATTACHMENT_MAX_CHARS")
    migration_agent_attachment_timeout_seconds: int = Field(
        default=120, ge=10, le=600, alias="MIGRATION_AGENT_ATTACHMENT_TIMEOUT_SECONDS")
    # The SQL debugger diagnoses a failing compile or preview, applies the
    # standard fix for the cause (or one model-proposed expression) and verifies
    # it before the column-isolation fallback holds anything back.
    migration_agent_sql_debug_enabled: bool = Field(default=True, alias="MIGRATION_AGENT_SQL_DEBUG_ENABLED")
    # Snowflake compiles/probes the debugger may spend per mapping.
    migration_agent_sql_debug_max_attempts: int = Field(
        default=12, ge=0, le=64, alias="MIGRATION_AGENT_SQL_DEBUG_MAX_ATTEMPTS")
    migration_agent_sql_debug_max_model_repairs_per_column: int = Field(
        default=1, ge=0, le=3, alias="MIGRATION_AGENT_SQL_DEBUG_MAX_MODEL_REPAIRS_PER_COLUMN")
    # Model for the one corrected expression when no standard fix applies;
    # empty uses MIGRATION_AGENT_MODEL_MEDIUM.
    migration_agent_sql_debug_model: str = Field(default="", alias="MIGRATION_AGENT_SQL_DEBUG_MODEL")
    migration_agent_sql_debug_timeout_seconds: int = Field(
        default=60, ge=5, le=300, alias="MIGRATION_AGENT_SQL_DEBUG_TIMEOUT_SECONDS")
    # Distinct source values shown to the repair model for a data error; 0 sends none.
    migration_agent_sql_debug_sample_values: int = Field(
        default=5, ge=0, le=20, alias="MIGRATION_AGENT_SQL_DEBUG_SAMPLE_VALUES")
    # Column mappings scored below this confidence get a (non-blocking) review item.
    migration_agent_column_review_confidence: float = Field(
        default=0.75, ge=0.0, le=1.0, alias="MIGRATION_AGENT_COLUMN_REVIEW_CONFIDENCE"
    )
    # Per-kind evidence weights for column confidence (see agent_tools/column_confidence.py).
    migration_agent_column_evidence_weights_json: str = Field(
        default="", alias="MIGRATION_AGENT_COLUMN_EVIDENCE_WEIGHTS_JSON"
    )
    # Distinct child key values sampled (ORDER BY HASH) per candidate.
    migration_agent_relationship_sample_values: int = Field(default=5000, ge=10, le=1_000_000, alias="MIGRATION_AGENT_RELATIONSHIP_SAMPLE_VALUES")
    migration_agent_relationship_min_child_values: int = Field(default=1, ge=1, le=10_000, alias="MIGRATION_AGENT_RELATIONSHIP_MIN_CHILD_VALUES")
    migration_agent_relationship_verify_batch: int = Field(default=25, ge=1, le=200, alias="MIGRATION_AGENT_RELATIONSHIP_VERIFY_BATCH")
    migration_agent_relationship_type_value_limit: int = Field(default=20, ge=1, le=500, alias="MIGRATION_AGENT_RELATIONSHIP_TYPE_VALUE_LIMIT")
    # How strongly missing parent keys count against a candidate (coverage ** n).
    migration_agent_relationship_orphan_sensitivity: float = Field(default=20.0, ge=1.0, le=200.0, alias="MIGRATION_AGENT_RELATIONSHIP_ORPHAN_SENSITIVITY")
    migration_agent_relationship_chance_floor: float = Field(default=0.05, ge=0.0001, le=1.0, alias="MIGRATION_AGENT_RELATIONSHIP_CHANCE_FLOOR")
    migration_agent_relationship_duplicate_parent_penalty: float = Field(default=0.5, ge=0.0, le=1.0, alias="MIGRATION_AGENT_RELATIONSHIP_DUPLICATE_PARENT_PENALTY")
    # A verified join is applied without a question only above this coverage.
    migration_agent_relationship_min_auto_coverage: float = Field(default=0.9, ge=0.0, le=1.0, alias="MIGRATION_AGENT_RELATIONSHIP_MIN_AUTO_COVERAGE")
    # JSON overrides of relationship_graph.DEFAULT_NAME_PRIORS / DEFAULT_EVIDENCE_WEIGHTS.
    migration_agent_relationship_name_priors_json: str = Field(default="", alias="MIGRATION_AGENT_RELATIONSHIP_NAME_PRIORS_JSON")
    migration_agent_relationship_evidence_weights_json: str = Field(default="", alias="MIGRATION_AGENT_RELATIONSHIP_EVIDENCE_WEIGHTS_JSON")
    # A plan decision at or above both values is applied without a question.
    migration_agent_auto_resolve_confidence: float = Field(default=0.75, ge=0.5, le=1.0, alias="MIGRATION_AGENT_AUTO_RESOLVE_CONFIDENCE")
    migration_agent_auto_resolve_margin: float = Field(default=0.15, ge=0.0, le=1.0, alias="MIGRATION_AGENT_AUTO_RESOLVE_MARGIN")
    migration_agent_model_medium: str = Field(default="", alias="MIGRATION_AGENT_MODEL_MEDIUM")
    migration_agent_model_high: str = Field(default="", alias="MIGRATION_AGENT_MODEL_HIGH")
    migration_agent_model_timeout_seconds: float = Field(
        default=90.0,
        gt=0,
        alias="MIGRATION_AGENT_MODEL_TIMEOUT_SECONDS",
    )
    migration_agent_extraction_chunk_chars: int = Field(default=24000, ge=1000, le=100000)
    migration_agent_extraction_note_limit: int = Field(default=20, ge=1, le=100)
    migration_agent_test_case_limit: int = Field(default=100, ge=1, le=1000, alias="MIGRATION_AGENT_TEST_CASE_LIMIT")
    migration_agent_learning_search_service: str = Field(default="", alias="MIGRATION_AGENT_LEARNING_SEARCH_SERVICE")
    migration_agent_sql_allowed_functions: list[str] = Field(default_factory=list)
    migration_agent_sql_preview_max_rows: int = Field(
        default=20, ge=1, le=1000, alias="MIGRATION_AGENT_SQL_PREVIEW_MAX_ROWS"
    )
    migration_agent_sql_timeout_seconds: int = Field(
        default=120, ge=5, le=1800, alias="MIGRATION_AGENT_SQL_TIMEOUT_SECONDS"
    )
    migration_agent_sql_result_max_bytes: int = Field(
        default=1_000_000, ge=10_000, le=10_000_000, alias="MIGRATION_AGENT_SQL_RESULT_MAX_BYTES"
    )
    cors_allowed_origins: str = Field(default="", alias="CORS_ALLOWED_ORIGINS")
    guardrails_enabled: bool = Field(default=True, alias="GUARDRAILS_ENABLED")
    guardrails_debug_routes_enabled: bool = Field(
        default=False,
        alias="GUARDRAILS_DEBUG_ROUTES_ENABLED",
    )
    guardrails_presidio_enabled: bool = Field(
        default=False,
        alias="GUARDRAILS_PRESIDIO_ENABLED",
    )
    guardrails_reject_raw_pii: bool = Field(
        default=False,
        alias="GUARDRAILS_REJECT_RAW_PII",
    )
    guardrails_redact_agent_requests: bool = Field(
        default=False,
        alias="GUARDRAILS_REDACT_AGENT_REQUESTS",
    )

    @computed_field
    @property
    def agents(self) -> list[AgentConfig]:
        return [
            AgentConfig(
                id="workbench_conversation",
                display_name="Workbench Conversation Agent",
                description=(
                    "Fast governed conversation agent for quick answers, recommendations, "
                    "feedback capture, and approved semantic-context RAG before any STTM handoff."
                ),
                snowflake_name=self.resolved_workbench_conversation_agent,
                default_model=self.snowflake_agent_orchestration_model,
            ),
            AgentConfig(
                id="sttm_builder",
                display_name="STTM Builder Agent",
                description=(
                    "Orchestration agent that routes requests to SOURCE_MAPPING_AGENT "
                    "or TRANSFORMATION_AGENT based on the interface (AUTO_MAP, CHAT, TRANSFORM). "
                    "Handles attribute mapping suggestions, refinements, and transformation rule generation."
                ),
                snowflake_name=self.resolved_sttm_builder_agent,
                default_model=self.snowflake_agent_orchestration_model,
            ),
            AgentConfig(
                id="dbt_conversion",
                display_name="DBT Conversion Agent",
                description=(
                    "Converts final STTM mapping SQL into dbt model files, source updates, "
                    "and schema YAML aligned to the client repository layout."
                ),
                snowflake_name=self.resolved_dbt_conversion_agent,
                default_model=self.snowflake_agent_orchestration_model,
            ),
            AgentConfig(
                id="test_case_generation",
                display_name="Test Case Generation Agent",
                description=(
                    "Generates QA seed data and detailed test-case documents from the final "
                    "validated STTM mapping."
                ),
                snowflake_name=self.resolved_test_case_generation_agent,
                default_model=self.snowflake_agent_orchestration_model,
            ),
        ]

    def qualify_table_name(self, table_name: str) -> str:
        return self.qualify_metadata_object_name(table_name)

    def qualify_metadata_object_name(self, object_name: str) -> str:
        candidate = object_name.strip()
        if not candidate:
            return candidate

        parts = _split_qualified_name(candidate)
        if parts:
            database, schema, resolved_object_name = parts
            # Deployment templates intentionally use DB.SCHEMA.<object> as a
            # portable placeholder.  Never send that literal namespace to
            # Snowflake; bind it to the configured metadata registry instead.
            if _looks_like_placeholder(candidate):
                resolved_database = self.resolved_metadata_database
                resolved_schema = self.resolved_metadata_schema
                if resolved_database and resolved_schema:
                    return (
                        f"{resolved_database}."
                        f"{resolved_schema}."
                        f"{resolved_object_name}"
                    )
            if self._should_rebase_legacy_metadata_namespace(database, schema):
                return (
                    f"{self.snowflake_database.strip()}."
                    f"{self.snowflake_schema.strip()}."
                    f"{resolved_object_name}"
                )
            return f"{database}.{schema}.{resolved_object_name}"

        if "." in candidate:
            return candidate

        database = self.resolved_metadata_database
        schema = self.resolved_metadata_schema
        if not database or not schema:
            return candidate
        return f"{database}.{schema}.{candidate}"

    @property
    def normalized_snowflake_authenticator(self) -> str:
        return (self.snowflake_authenticator or "").strip().lower()

    @property
    def local_dev_uses_externalbrowser(self) -> bool:
        return self.normalized_snowflake_authenticator == "externalbrowser"

    @property
    def resolved_metadata_database(self) -> str:
        if self.snowflake_database.strip():
            return self.snowflake_database.strip()
        for candidate in (
            self.snowflake_semantic_model_table,
            self.snowflake_semantic_bundles_table,
            self.snowflake_semantic_overrides_table,
            self.snowflake_derived_sources_table,
        ):
            parts = _split_qualified_name(candidate)
            if parts:
                return parts[0]
        return ""

    @property
    def resolved_metadata_schema(self) -> str:
        if self.snowflake_schema.strip():
            return self.snowflake_schema.strip()
        for candidate in (
            self.snowflake_semantic_model_table,
            self.snowflake_semantic_bundles_table,
            self.snowflake_semantic_overrides_table,
            self.snowflake_derived_sources_table,
        ):
            parts = _split_qualified_name(candidate)
            if parts:
                return parts[1]
        return ""

    @property
    def resolved_semantic_views_table(self) -> str:
        """Fully-qualified SEM_TABLE_VIEWS path.

        Priority: explicit SNOWFLAKE_SEMANTIC_VIEWS_DATABASE/SCHEMA env vars,
        then fallback to the main metadata namespace.
        """
        table_name = self.snowflake_semantic_table_views_table or "SEM_TABLE_VIEWS"
        parts = _split_qualified_name(table_name)
        if parts:
            return f"{parts[0]}.{parts[1]}.{parts[2]}"
        db = (self.snowflake_semantic_views_database or "").strip()
        schema = (self.snowflake_semantic_views_schema or "").strip()
        if db and schema:
            return f"{db}.{schema}.{table_name}"
        return self.qualify_table_name(table_name)

    @property
    def resolved_semantic_column_views_table(self) -> str:
        """Fully-qualified SEM_COLUMN_VIEWS path.

        Uses the same database/schema override as resolved_semantic_views_table
        so both tables resolve consistently when stored in a separate registry.
        """
        table_name = self.snowflake_semantic_column_views_table or "SEM_COLUMN_VIEWS"
        parts = _split_qualified_name(table_name)
        if parts:
            return f"{parts[0]}.{parts[1]}.{parts[2]}"
        db = (self.snowflake_semantic_views_database or "").strip()
        schema = (self.snowflake_semantic_views_schema or "").strip()
        if db and schema:
            return f"{db}.{schema}.{table_name}"
        return self.qualify_table_name(table_name)

    @property
    def resolved_semantic_native_views_table(self) -> str:
        """Fully-qualified SEM_NATIVE_VIEWS or LATEST_NATIVE_VIEWS path."""
        table_name = self.snowflake_semantic_native_views_table or "SEM_NATIVE_VIEWS"
        parts = _split_qualified_name(table_name)
        if parts:
            return f"{parts[0]}.{parts[1]}.{parts[2]}"
        db = (self.snowflake_semantic_views_database or "").strip()
        schema = (self.snowflake_semantic_views_schema or "").strip()
        if db and schema:
            return f"{db}.{schema}.{table_name}"
        return self.qualify_table_name(table_name)

    @property
    def resolved_sttm_builder_agent(self) -> str:
        return self._resolve_agent_name(
            self.snowflake_sttm_builder_agent,
            legacy_object_name="STTM_BUILDER_AGENT",
            default_object_name="AGT_STTM_BUILDER",
        )

    @property
    def resolved_semantic_model_agent(self) -> str:
        if not self.snowflake_semantic_model_agent.strip():
            database = (self.snowflake_semantic_views_database or "").strip()
            schema = (self.snowflake_semantic_views_schema or "").strip()
            if database and schema:
                return f"{database}.{schema}.AGT_SEMANTIC_MODEL_V2"
        return self._resolve_agent_name(
            self.snowflake_semantic_model_agent,
            legacy_object_name="SEMANTIC_MODEL_AGENT",
            default_object_name="AGT_SEMANTIC_MODEL_V2",
        )

    @property
    def resolved_source_mapping_agent(self) -> str:
        return self._resolve_agent_name(
            self.snowflake_source_mapping_agent,
            legacy_object_name="SOURCE_MAPPING_AGENT",
            default_object_name="AGT_SOURCE_MAPPING",
        )

    @property
    def resolved_transformation_rule_agent(self) -> str:
        return self._resolve_agent_name(
            self.snowflake_transformation_rule_agent,
            legacy_object_name="TRANSFORMATION_RULE_AGENT",
            default_object_name="AGT_TRANSFORMATION_RULE",
        )

    @property
    def resolved_workbench_conversation_agent(self) -> str:
        if not self.snowflake_workbench_conversation_agent:
            return self.resolved_sttm_builder_agent
        return self._resolve_agent_name(
            self.snowflake_workbench_conversation_agent,
            legacy_object_name="WORKBENCH_CONVERSATION_AGENT",
            default_object_name="AGT_STTM_BUILDER",
        )

    @property
    def resolved_dbt_conversion_agent(self) -> str:
        return self._resolve_agent_name(
            self.snowflake_dbt_conversion_agent,
            legacy_object_name="DBT_CONVERSION_AGENT",
            default_object_name="AGT_DBT_CONVERSION",
        )

    @property
    def resolved_test_case_generation_agent(self) -> str:
        return self._resolve_agent_name(
            self.snowflake_test_case_generation_agent,
            legacy_object_name="TEST_CASE_GENERATION_AGENT",
            default_object_name="AGT_DBT_TEST_GENERATION",
        )

    @property
    def resolved_relationships_procedure(self) -> str:
        raw_value = self.snowflake_relationships_procedure.strip()
        if raw_value and not _looks_like_placeholder(raw_value):
            parts = _split_qualified_name(self.qualify_metadata_object_name(raw_value))
            if parts:
                if (
                    self.relationship_proc_fast_guards_v1
                    and parts[2].upper() == "SP_GET_TABLE_RELATIONSHIPS"
                ):
                    parts = (parts[0], parts[1], "SP_GET_TABLE_RELATIONSHIPS_V2")
                return f"{parts[0]}.{parts[1]}.{parts[2]}"

        database = self.resolved_metadata_database
        schema = self.resolved_metadata_schema
        if not database or not schema:
            return ""
        procedure = (
            "SP_GET_TABLE_RELATIONSHIPS_V2"
            if self.relationship_proc_fast_guards_v1
            else "SP_GET_TABLE_RELATIONSHIPS"
        )
        return f"{database}.{schema}.{procedure}"

    @property
    def qualified_users_table(self) -> str:
        return self.qualify_table_name(self.users_table)

    @property
    def qualified_oauth_sessions_table(self) -> str:
        return self.qualify_table_name(self.snowflake_oauth_sessions_table)

    @property
    def local_dev_effective_email(self) -> str:
        return self.local_dev_user_email or self.snowflake_user

    @property
    def resolved_snowflake_host(self) -> str:
        host = (self.snowflake_host or "").strip()
        if host == "your_org-your_account.snowflakecomputing.com":
            return ""
        return host

    @property
    def rest_snowflake_host(self) -> str:
        """Public Snowflake host for REST APIs authenticated with user OAuth tokens."""
        explicit_rest_host = (self.snowflake_rest_host or "").strip().replace("_", "-").lower()
        if explicit_rest_host:
            if explicit_rest_host.endswith(".snowflakecomputing.com"):
                return explicit_rest_host
            return f"{explicit_rest_host}.snowflakecomputing.com"
        account = (self.snowflake_account or "").strip().replace("_", "-").lower()
        if account:
            if account.endswith(".snowflakecomputing.com"):
                return account
            return f"{account}.snowflakecomputing.com"
        for raw_url in (self.snowflake_oauth_token_url, self.snowflake_oauth_authorize_url):
            host = (urlparse(raw_url.strip()).hostname or "").strip()
            if host:
                return host
        return self.resolved_snowflake_host

    @property
    def non_local_env(self) -> bool:
        return self.app_env.strip().lower() not in {"", "dev", "local", "test"}

    @property
    def debug_routes_enabled(self) -> bool:
        if self.guardrails_debug_routes_enabled:
            return True
        return not self.non_local_env

    @property
    def uses_custom_oauth(self) -> bool:
        return self.auth_mode.strip().lower() == "custom_oauth"

    @property
    def auto_mapping_service_enabled(self) -> bool:
        return bool(self.resolved_auto_mapping_service_url)

    @property
    def resolved_auto_mapping_service_url(self) -> str:
        explicit = self.auto_mapping_service_url.strip()
        if explicit:
            return explicit
        # Local V2 uses the private worker ASGI app in-process. Deployed SPCS
        # environments must still provide the explicit internal service URL.
        if not self.non_local_env and self.auto_map_pipeline_v2:
            return "inprocess"
        return ""

    def _resolve_agent_name(
        self,
        raw_value: str,
        *,
        legacy_object_name: str,
        default_object_name: str,
    ) -> str:
        candidate = raw_value.strip()
        if candidate and not _looks_like_placeholder(candidate):
            parts = _split_qualified_name(candidate)
            if parts:
                database, schema, object_name = parts
                if object_name.upper() == legacy_object_name:
                    object_name = default_object_name
                if self._should_rebase_legacy_metadata_namespace(database, schema):
                    database = self.snowflake_database.strip()
                    schema = self.snowflake_schema.strip()
                return f"{database}.{schema}.{object_name}"
            if "." not in candidate:
                database = self.resolved_metadata_database
                schema = self.resolved_metadata_schema
                if database and schema:
                    object_name = default_object_name if candidate.upper() == legacy_object_name else candidate
                    return f"{database}.{schema}.{object_name}"

        database = self.resolved_metadata_database
        schema = self.resolved_metadata_schema
        if not database or not schema:
            return ""
        return f"{database}.{schema}.{default_object_name}"

    def _should_rebase_legacy_metadata_namespace(self, database: str, schema: str) -> bool:
        current_database = self.snowflake_database.strip()
        current_schema = self.snowflake_schema.strip()
        if not current_database or not current_schema:
            return False
        return (
            database.strip().upper() == LEGACY_METADATA_DATABASE
            and schema.strip().upper() == LEGACY_METADATA_SCHEMA
            and (
                current_database.strip().upper() != LEGACY_METADATA_DATABASE
                or current_schema.strip().upper() != LEGACY_METADATA_SCHEMA
            )
        )


@lru_cache
def get_settings() -> Settings:
    return Settings()
