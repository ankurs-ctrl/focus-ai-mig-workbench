from types import SimpleNamespace
import pytest
from app.agent_runs.policy import resolve_policy, validate_worker_configuration
from app.agent_runs.models import EffortLevel
from app.core.migration_knowledge import EvidenceScope, learning_applicable, search_projection, transcript_chunks


def test_effort_overrides_are_validated_and_snapshot_is_independent():
    settings=SimpleNamespace(migration_agent_effort_overrides={'high':{'max_parallel_mappings':4,'model_call_budget':100}})
    policy=resolve_policy(EffortLevel.HIGH,settings)
    assert policy.max_parallel_mappings==4 and policy.working_model_call_budget==80
    assert resolve_policy(EffortLevel.HIGH).max_parallel_mappings==5
    settings.migration_agent_effort_overrides={'high':{'max_parallel_mappings':0}}
    with pytest.raises(ValueError):resolve_policy(EffortLevel.HIGH,settings)


def test_worker_refuses_unguarded_or_unconfigured_runtime():
    settings=SimpleNamespace(migration_agent_enabled=True)
    with pytest.raises(ValueError,match='MIGRATION_AGENT_TRUE_RESUME'):validate_worker_configuration(settings)


def test_learning_requires_approval_scope_and_current_versions():
    scope=EvidenceScope(tenant_id='tenant',account='account',authorization_fingerprint='role-a',project_id='project')
    record={'scope':scope.model_dump(),'approval_status':'EXTRACTED_NOTE_DRAFT','semantic_version':'s1','contract_version':'c1'}
    assert not learning_applicable(record,scope,semantic_version='s1',contract_version='c1')
    record['approval_status']='APPROVED_BUSINESS_RULE'
    assert learning_applicable(record,scope,semantic_version='s1',contract_version='c1')
    assert not learning_applicable(record,scope,semantic_version='s2',contract_version='c1')
    assert not learning_applicable(record,scope.model_copy(update={'authorization_fingerprint':'role-b'}),semantic_version='s1',contract_version='c1')
    record['superseded_by']='newer'
    assert not learning_applicable(record,scope,semantic_version='s1',contract_version='c1')


def test_search_projection_excludes_operational_payloads():
    projection=search_projection({'summary':'Approved key conversion','structured_rule':{'credentials':'do-not-index'},'original_text':'raw rows','approval_status':'BUSINESS_REVIEW'})
    assert not projection['authoritative']
    assert 'credentials' not in str(projection) and 'raw rows' not in str(projection)


def test_search_projection_excludes_credentials_even_from_summary():
    projection=search_projection({'summary':'password=example','approval_status':'APPROVED_BUSINESS_RULE'})
    assert projection['text'] == '' and projection['excluded_sensitive']


def test_source_design_reads_legacy_learning_table_without_updated_at():
    from app.core.learning_retrieval import LearningRetrievalService
    queries = []

    class Session:
        def sql(self, query, params):
            queries.append((query, params))
            return SimpleNamespace(collect=lambda: [])

    service = object.__new__(LearningRetrievalService)
    service._session = Session()
    service._settings = SimpleNamespace(qualify_table_name=lambda name: f'DB.META.{name}')
    result = service.get_source_design_evidence(target_table='DB.TGT.HOUSEHOLD',
                                                project_ids=['1401'], budget=10)

    assert result == {'cards': [], 'retrieved_learning_ids': []}
    assert 'ORDER BY LEARNING_TYPE, CREATED_AT DESC' in queries[0][0]
    assert 'UPDATED_AT' not in queries[0][0]


def test_search_rechecks_current_scope_approval_revision_and_supersession():
    import json
    from app.core.migration_knowledge import MigrationKnowledgeService
    scope=EvidenceScope(tenant_id='tenant',account='account',authorization_fingerprint='role',project_id='project')
    valid={'scope':scope.model_dump(),'approval_status':'APPROVED_BUSINESS_RULE','summary':'Accepted mapping',
           'semantic_version':'s1','contract_version':'c1','revision':2}
    records={'valid':valid,'stale':{**valid,'revision':3},'rejected':{**valid,'approval_status':'REJECTED_NOTE'},
             'superseded':{**valid,'superseded_by':'new'},'foreign':{**valid,'scope':{**scope.model_dump(),'tenant_id':'other'}}}
    class Session:
        def sql(self,query,params):
            if 'SEARCH_PREVIEW' in query:
                filters=json.loads(params[1])['filter']['@and']
                assert {'@eq':{'TENANT_ID':'tenant'}} in filters
                result=[{'RESULT':{'results':[{'LEARNING_ID':key,'REVISION':2} for key in records]}}]
            else:result=[{'ATTRIBUTES':records[params[1]]}]
            return SimpleNamespace(collect=lambda:result)
    service=MigrationKnowledgeService(Session(),SimpleNamespace(snowflake_database='DB',snowflake_schema='META',
        migration_agent_learning_search_service='SEARCH'),scope)
    assert [r['learning_id'] for r in service.search('mapping',semantic_version='s1',contract_version='c1')] == ['valid']


def test_transcript_chunks_preserve_attribution_without_inventing_missing_fields():
    chunks=transcript_chunks('[00:12] Analyst: Keep active records.\nUnattributed text',meeting_id='meeting',document_version='v1')
    assert chunks[0]['speaker']=='Analyst' and chunks[0]['timestamp']=='00:12'
    assert chunks[1]['speaker'] is None and chunks[1]['timestamp'] is None


def test_exact_contract_prefill_leaves_ambiguous_and_incompatible_fields_unresolved():
    from app.agent_tools.prefill import prefill_exact_contracts
    targets=[{'name':'ID','type':'NUMBER'},{'name':'LABEL','type':'TEXT'},{'name':'CODE','type':'NUMBER'}]
    sources={'DB.SRC.A':{'column_contracts':[{'name':'ID','type':'NUMBER'},{'name':'LABEL','type':'TEXT'},{'name':'CODE','type':'TEXT'}]},
             'DB.SRC.B':{'column_contracts':[{'name':'LABEL','type':'TEXT'}]}}
    result=prefill_exact_contracts(targets,sources,['ID','LABEL','CODE'])
    assert [d.target_column for d in result]==['ID']
    assert result[0].learning_ids_used==[]


def test_shared_budget_tracks_actual_query_boundary_and_reserves_finalization():
    from app.agent_runtime.execution import ExecutionBudget,BudgetedSession,BudgetExceededError
    class Session:
        def sql(self,*args,**kwargs):return 'query'
    budget=ExecutionBudget(model_limit=5,tool_limit=5,category_limits={'snowflake_queries':1})
    session=BudgetedSession(Session(),budget)
    assert session.sql('SELECT 1')=='query'
    with pytest.raises(BudgetExceededError):session.sql('SELECT 2')
    assert budget.structured_snapshot()['category_snowflake_queries']==1


def test_rollback_remains_available_after_query_budget_exhaustion():
    from app.agent_runtime.execution import ExecutionBudget,BudgetedSession,BudgetExceededError
    class Session:
        def sql(self,query):return query
    budget=ExecutionBudget(model_limit=5,tool_limit=5,category_limits={'snowflake_queries':1})
    session=BudgetedSession(Session(),budget)
    session.sql('BEGIN')
    with pytest.raises(BudgetExceededError):session.sql('SELECT 1')
    budget.set_cancellation_check(lambda:True)
    assert session.sql('ROLLBACK')=='ROLLBACK'
    assert budget.structured_snapshot()['category_persistence_cleanup_queries']==1
