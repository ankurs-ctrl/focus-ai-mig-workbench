from __future__ import annotations

from typing import Any


def _issue(
    category: str,
    summary: str,
    *,
    mapping_key: str | None = None,
    blocking: bool = True,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "category": category,
        "blocking": blocking,
        "safe_summary": summary,
        "subject_keys": [mapping_key] if mapping_key else [],
        "details": details or {},
    }


def validate_mapping_set(
    manifest: list[dict[str, Any]],
    mapping_results: list[dict[str, Any]],
    checks: list[str],
) -> dict[str, Any]:
    """Apply deterministic, auditable gates to the complete mapping set."""
    enabled = set(checks)
    by_key = {str(item.get("mapping_key")): item for item in mapping_results}
    issues: list[dict[str, Any]] = []
    gates: dict[str, dict[str, Any]] = {}

    if "contract" in enabled:
        before = len(issues)
        seen_targets: dict[str, str] = {}
        for item in manifest:
            key = str(item.get("mapping_key"))
            result = by_key.get(key, {})
            target = str(item.get("target_table") or "")
            target_columns = set(result.get("target_columns") or [])
            decided = set(result.get("mapped_target_columns") or []) | set(
                result.get("unresolved_target_columns") or []
            )
            unknown = sorted(decided - target_columns)
            missing = sorted(target_columns - decided)
            if target.count(".") != 2 or not target_columns:
                issues.append(_issue("target_contract", "Target contract is missing or unreadable.", mapping_key=key))
            if not result.get("target_contract_hash"):
                issues.append(_issue("target_contract", "The target contract does not have an immutable validation hash.", mapping_key=key))
            if not result.get("sql_validation", {}).get("compile_valid", False):
                issues.append(_issue("target_contract", "Generated mapping SQL did not pass the target-contract compiler gate.", mapping_key=key, details={"validation": result.get("sql_validation") or {}}))
            if unknown:
                issues.append(_issue("target_contract", "Draft contains columns outside the target contract.", mapping_key=key, details={"columns": unknown}))
            if missing:
                issues.append(_issue("target_contract", "Target columns are not accounted for by a mapped or unresolved decision.", mapping_key=key, details={"columns": missing}))
            required = {
                str(column.get("name"))
                for column in result.get("target_column_contracts") or []
                if not bool(column.get("nullable", True))
            }
            unresolved_required = sorted(required - set(result.get("mapped_target_columns") or []))
            if unresolved_required:
                issues.append(_issue("target_contract", "Required target columns are unresolved.", mapping_key=key, details={"columns": unresolved_required}))
            if target in seen_targets and target:
                issues.append(_issue("target_contract", "Multiple mappings write the same target table.", mapping_key=key, details={"other_mapping_key": seen_targets[target]}))
            seen_targets[target] = key
        gates["contract"] = {"passed": len(issues) == before, "issue_count": len(issues) - before}

    if "keys" in enabled:
        before = len(issues)
        for key, result in by_key.items():
            target_keys = set(result.get("target_key_columns") or [])
            mapped = set(result.get("mapped_target_columns") or [])
            if not target_keys:
                issues.append(_issue("key_validation", "No target key metadata was found; key reconciliation requires review.", mapping_key=key))
            elif missing_keys := sorted(target_keys - mapped):
                issues.append(_issue("key_validation", "One or more target key columns are unresolved.", mapping_key=key, details={"columns": missing_keys}))
            metrics = result.get("key_metrics") or {}
            if metrics:
                total = int(metrics.get("total_count") or 0)
                unique = int(metrics.get("unique_count") or 0)
                nulls = int(metrics.get("null_count") or 0)
                if nulls:
                    issues.append(_issue("key_validation", "The generated output contains null target keys.", mapping_key=key, details={"null_count": nulls}))
                if unique < total:
                    issues.append(_issue("key_validation", "The generated output contains duplicate target keys.", mapping_key=key, details={"total_count": total, "unique_count": unique}))
        gates["keys"] = {"passed": len(issues) == before, "issue_count": len(issues) - before}

    if "dependencies" in enabled:
        before = len(issues)
        for item in manifest:
            key = str(item.get("mapping_key"))
            failed = [
                dep for dep in item.get("dependencies") or []
                if by_key.get(str(dep), {}).get("status") not in {"READY_FOR_REVIEW", "NEEDS_REVIEW"}
            ]
            if failed:
                issues.append(_issue("dependency", "Upstream mapping contracts are incomplete.", mapping_key=key, details={"dependencies": failed}))
        gates["dependencies"] = {"passed": len(issues) == before, "issue_count": len(issues) - before}

    if "relationships" in enabled:
        before = len(issues)
        for key, result in by_key.items():
            if (int(result.get("source_table_count") or 0) > 1
                    and int(result.get("relationship_count") or 0) == 0
                    and not result.get("scoped_sql_lineage_verified")):
                issues.append(_issue("relationship", "Multiple source tables require an approved join definition before validation can pass.", mapping_key=key))
            relationship_metrics = result.get("relationship_metrics") or {}
            fanout = float(relationship_metrics.get("fanout_ratio") or 1.0)
            if fanout > 1.05:
                issues.append(_issue("relationship", "Join fan-out exceeds the configured tolerance.", mapping_key=key, details={"fanout_ratio": fanout}))
            orphan_rate = float(relationship_metrics.get("orphan_rate") or 0.0)
            if orphan_rate > 0.0:
                issues.append(_issue("relationship", "Join reconciliation found orphaned source rows.", mapping_key=key, details={"orphan_rate": orphan_rate}, blocking=False))
        gates["relationships"] = {"passed": len(issues) == before, "issue_count": len(issues) - before}

    if "reconciliation" in enabled:
        before = len(issues)
        for key, result in by_key.items():
            target_count = len(result.get("target_columns") or [])
            mapped_count = len(result.get("mapped_target_columns") or [])
            unresolved = list(result.get("unresolved_target_columns") or [])
            duplicate_targets = list(result.get("duplicate_target_columns") or [])
            if target_count == 0 or mapped_count + len(unresolved) != target_count:
                issues.append(_issue("reconciliation", "Mapping decisions do not reconcile to the complete target contract.", mapping_key=key))
            if unresolved:
                issues.append(_issue("reconciliation", "High-effort reconciliation found unresolved target columns.", mapping_key=key, details={"columns": unresolved}))
            if duplicate_targets:
                issues.append(_issue("reconciliation", "Multiple decisions assign the same target column.", mapping_key=key, details={"columns": duplicate_targets}))
            if not result.get("sql_validation", {}).get("preview_valid", False):
                issues.append(_issue("reconciliation", "The bounded mapping preview did not complete successfully.", mapping_key=key, details={"validation": result.get("sql_validation") or {}}))
            metrics = result.get("reconciliation_metrics") or {}
            if not metrics:
                issues.append(_issue("reconciliation", "Executable row reconciliation metrics are missing.", mapping_key=key))
            else:
                source_count = int(metrics.get("source_row_count") or 0)
                output_count = int(metrics.get("output_row_count") or 0)
                if output_count > source_count:
                    issues.append(_issue("reconciliation", "Generated output contains row amplification.", mapping_key=key, details={"source_row_count": source_count, "output_row_count": output_count}))
                elif output_count < source_count:
                    issues.append(_issue("reconciliation", "Generated output does not account for every driving source row.", mapping_key=key, details={"source_row_count": source_count, "output_row_count": output_count}, blocking=False))
        gates["reconciliation"] = {"passed": len(issues) == before, "issue_count": len(issues) - before}

    if "blast_radius" in enabled:
        before = len(issues)
        dependents: dict[str, list[str]] = {}
        for item in manifest:
            for dependency in item.get("dependencies") or []:
                dependents.setdefault(str(dependency), []).append(str(item.get("mapping_key")))
        for key, downstream in dependents.items():
            if by_key.get(key, {}).get("status") != "READY_FOR_REVIEW":
                issues.append(_issue("blast_radius", "An upstream mapping needing review can affect downstream drafts.", mapping_key=key, details={"impacted_mapping_keys": downstream}, blocking=False))
            if not by_key.get(key, {}).get("target_contract_hash"):
                issues.append(_issue("blast_radius", "Downstream impact cannot be pinned because the upstream target contract hash is missing.", mapping_key=key, details={"impacted_mapping_keys": downstream}))
        gates["blast_radius"] = {"passed": len(issues) == before, "issue_count": len(issues) - before}

    return {
        "contract_version": "1.0",
        "gates": gates,
        "issues": issues,
        "passed": not any(item.get("blocking", True) for item in issues),
    }
