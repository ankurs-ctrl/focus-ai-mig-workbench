#!/usr/bin/env python3
"""Give existing FIR target patterns a reuse key and honest support counts.

Before 2.9.6 every re-save of the same mapping raised SUPPORT_COUNT, and the
same learned mapping published from different mappings produced separate rows.
This one-time pass groups active patterns by reuse key, keeps the strongest row
per group, counts each mapping or uploaded asset once, and supersedes the rest.

Dry run by default; pass --apply to write.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = ROOT / "services" / "sttm-builder"
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.core.relationship_learning import RelationshipLearningService  # noqa: E402
from app.core.target_mapping_patterns import (  # noqa: E402
    _INDEPENDENT_SUPPORT_STEP,
    _REUSE_CONFIDENCE_CAP,
    reuse_key_for_payload,
)
from scripts.manage_client_fir_learning import DEFAULT_ENV, row_dict, settings_and_client  # noqa: E402

_EVIDENCE_RANK = {
    "explicit_user_correction": 1,
    "published_mapping": 2,
    "validated_mapping": 3,
    "validated_imported_sql": 3,
    "validated_imported_workbook": 3,
    "historical_import": 3,
    "accepted_mapping_row": 4,
}


def _payload(value: Any) -> dict[str, Any]:
    if isinstance(value, str):
        value = json.loads(value)
    return value if isinstance(value, dict) else {}


def _rank(row: dict[str, Any], payload: dict[str, Any]) -> tuple:
    evidence = str((payload.get("provenance") or {}).get("evidence_class") or "")
    rank = _EVIDENCE_RANK.get(evidence, 2 if row.get("VALIDATION_STATUS") == "published" else 9)
    return (rank, -float(row.get("CONFIDENCE") or 0.0), str(row.get("UPDATED_AT") or ""))


def _support_key(row: dict[str, Any], payload: dict[str, Any]) -> str:
    if row.get("STTM_ID"):
        return f"sttm:{row['STTM_ID']}"
    asset_id = str((payload.get("provenance") or {}).get("asset_id") or "").strip()
    return f"asset:{asset_id}" if asset_id else ""


def plan(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    groups: dict[str, list[tuple[dict[str, Any], dict[str, Any]]]] = {}
    for row in rows:
        payload = _payload(row.get("PATTERN_PAYLOAD"))
        if payload:
            groups.setdefault(reuse_key_for_payload(payload), []).append((row, payload))
    updates: list[dict[str, Any]] = []
    superseded = 0
    for reuse_key, members in groups.items():
        members.sort(key=lambda item: _rank(*item))
        winner, _ = members[0]
        support_keys = sorted({key for key in (_support_key(*item) for item in members) if key})
        confidence = max(float(item[0].get("CONFIDENCE") or 0.0) for item in members)
        if len(support_keys) > 1:
            confidence = min(
                _REUSE_CONFIDENCE_CAP,
                confidence + _INDEPENDENT_SUPPORT_STEP * (len(support_keys) - 1),
            )
        updates.append(
            {
                "pattern_id": winner["PATTERN_ID"],
                "reuse_key": reuse_key,
                "support_keys": support_keys,
                "support_count": max(1, len(support_keys)),
                "confidence": round(confidence, 4),
                "superseded_by": None,
            }
        )
        for row, _ in members[1:]:
            superseded += 1
            updates.append(
                {
                    "pattern_id": row["PATTERN_ID"],
                    "reuse_key": reuse_key,
                    "support_keys": [],
                    "support_count": int(row.get("SUPPORT_COUNT") or 1),
                    "confidence": float(row.get("CONFIDENCE") or 0.0),
                    "superseded_by": winner["PATTERN_ID"],
                }
            )
    return updates, superseded


def apply(session: Any, table: str, updates: list[dict[str, Any]]) -> None:
    for start in range(0, len(updates), 200):
        literal = json.dumps(updates[start : start + 200]).replace("\\", "\\\\").replace("'", "''")
        session.sql(
            f"""
            MERGE INTO {table} target
            USING (
                SELECT
                    f.value:pattern_id::STRING AS PATTERN_ID,
                    f.value:reuse_key::STRING AS REUSE_KEY,
                    f.value:support_keys::ARRAY AS SUPPORT_KEYS,
                    f.value:support_count::NUMBER AS SUPPORT_COUNT,
                    f.value:confidence::FLOAT AS CONFIDENCE,
                    f.value:superseded_by::STRING AS SUPERSEDED_BY
                FROM TABLE(FLATTEN(INPUT => PARSE_JSON('{literal}'))) f
            ) source
            ON target.PATTERN_ID = source.PATTERN_ID AND target.STATUS = 'active'
            WHEN MATCHED AND source.SUPERSEDED_BY IS NULL THEN UPDATE SET
                PATTERN_PAYLOAD = OBJECT_INSERT(
                    OBJECT_INSERT(target.PATTERN_PAYLOAD, 'reuse_key', source.REUSE_KEY, TRUE),
                    'support_keys', source.SUPPORT_KEYS, TRUE
                ),
                SUPPORT_COUNT = source.SUPPORT_COUNT,
                CONFIDENCE = source.CONFIDENCE,
                UPDATED_AT = CURRENT_TIMESTAMP()
            WHEN MATCHED THEN UPDATE SET
                PATTERN_PAYLOAD = OBJECT_INSERT(target.PATTERN_PAYLOAD, 'reuse_key', source.REUSE_KEY, TRUE),
                STATUS = 'inactive',
                SUPERSEDED_BY = source.SUPERSEDED_BY,
                UPDATED_AT = CURRENT_TIMESTAMP()
            """
        ).collect()


def backfill_published_joins(session: Any, settings: Any, *, apply_changes: bool) -> int:
    """Seed learned joins from the latest snapshot of each published mapping."""
    sttm = settings.qualify_metadata_object_name("TBL_STTM")
    snapshots = settings.qualify_metadata_object_name("TBL_WORKSPACE_SNAPSHOTS")
    rows = [
        row_dict(row)
        for row in session.sql(
            f"""
            SELECT TO_VARCHAR(s.STTM_ID) AS STTM_ID, w.SNAPSHOT_PAYLOAD:relationships AS RELATIONSHIPS
            FROM {sttm} s
            JOIN {snapshots} w ON TO_VARCHAR(w.STTM_ID) = TO_VARCHAR(s.STTM_ID)
            WHERE UPPER(s.STATUS) IN ('PUBLISHED', 'COMPLETE')
            QUALIFY ROW_NUMBER() OVER (PARTITION BY s.STTM_ID ORDER BY w.CREATED_AT DESC) = 1
            """
        ).collect()
    ]
    store = RelationshipLearningService(session, settings)
    recorded = 0
    for row in rows:
        relationships = _payload_list(row.get("RELATIONSHIPS"))
        if not relationships:
            continue
        if apply_changes:
            recorded += store.record(
                relationships,
                evidence_class="published_mapping",
                support_key=f"sttm:{row['STTM_ID']}",
            )
        else:
            recorded += len(relationships)
    return recorded


def _payload_list(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, str):
        value = json.loads(value)
    return [item for item in value or [] if isinstance(item, dict)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--env-file", default=str(DEFAULT_ENV))
    parser.add_argument("--apply", action="store_true", help="Write the changes (default: dry run).")
    parser.add_argument(
        "--include-joins",
        action="store_true",
        help="Also seed TBL_FIR_RELATIONSHIP_LEARNINGS from published mappings.",
    )
    args = parser.parse_args()

    settings, client = settings_and_client(args.env_file)
    table = settings.qualify_metadata_object_name("TBL_FIR_TARGET_MAPPING_PATTERNS")
    rows = [
        row_dict(row)
        for row in client.session.sql(
            f"""
            SELECT PATTERN_ID, STTM_ID, CONFIDENCE, SUPPORT_COUNT, VALIDATION_STATUS,
                   PATTERN_PAYLOAD, UPDATED_AT
            FROM {table}
            WHERE STATUS = 'active'
            """
        ).collect()
    ]
    updates, superseded = plan(rows)
    kept = len(updates) - superseded
    inflated = sum(
        1
        for row in rows
        for update in updates
        if update["pattern_id"] == row["PATTERN_ID"]
        and update["superseded_by"] is None
        and int(row.get("SUPPORT_COUNT") or 1) != update["support_count"]
    )
    print(f"Active patterns: {len(rows)}")
    print(f"Distinct reuse keys kept: {kept}")
    print(f"Duplicates to supersede: {superseded}")
    print(f"Support counts corrected: {inflated}")
    if args.include_joins:
        joins = backfill_published_joins(client.session, settings, apply_changes=args.apply)
        print(f"Published joins {'recorded' if args.apply else 'to record'}: {joins}")
    if not args.apply:
        print("Dry run only. Re-run with --apply to write.")
        return 0
    apply(client.session, table, updates)
    print("Applied.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
