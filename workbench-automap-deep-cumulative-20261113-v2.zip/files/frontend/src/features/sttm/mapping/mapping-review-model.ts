import { storedRuleExpression, hasMappingDefinition } from '../shared/row-validation-state';
import type { AutoMapCandidate, AutoMapSuggestion } from '@/types/api-contract';
import type { DerivedSource, MappingState, TableNode } from '../types/sttm.types';
import { relationAliasFor, formatDiagnosticDisplayText } from './relation-alias';
import { renderSqlIdentifier, sqlIdentifierParts } from '../shared/sql-identifiers';

type DisplayNode = { canvasId?: string; id: string; alias: string; name: string; qualified: string; label: string };
export type ReviewCatalog = ReturnType<typeof reviewCatalog>;
const key = (value: string) => {const parts=sqlIdentifierParts(value);return parts.length?JSON.stringify(parts):`raw:${value}`;};

/** Names come from real workspace identities, never from stripping a hash suffix. */
export function reviewCatalog(sources: TableNode[] = [], derived: DerivedSource[] = []) {
  const represented=new Set(sources.filter(source=>source.isSelected&&source.tableId.startsWith('sql-instance:')).map(source=>key(source.qualifiedName)));
  const nodes: DisplayNode[] = sources.filter(source => source.isSelected&&(source.tableId.startsWith('sql-instance:')||!represented.has(key(source.qualifiedName)))).map(source => ({
    canvasId: source.tableId,
    id: source.tableId.startsWith('sql-instance:') ? source.tableId : source.qualifiedName,
    alias: relationAliasFor(source.tableId.startsWith('sql-instance:') ? source.tableId : source.qualifiedName),
    name: renderSqlIdentifier(sqlIdentifierParts(source.qualifiedName).slice(-1)) || source.tableName,
    qualified: source.qualifiedName, label: '',
  }));
  nodes.push(...derived.filter(source => source.isSelected).map(source => ({id: source.id,
    alias: relationAliasFor(source.id, source.sourceName), name: String(source.queryScope?.name || source.sourceName), qualified: source.sourceName, label: ''})));
  for (const node of nodes) {
    const sameName = nodes.filter(other => other.name === node.name);
    const samePhysical = nodes.filter(other => key(other.qualified) === key(node.qualified));
    const suffix=renderSqlIdentifier(sqlIdentifierParts(node.qualified).slice(-2));
    const sameSuffix=sameName.filter(other=>renderSqlIdentifier(sqlIdentifierParts(other.qualified).slice(-2))===suffix);
    const generatedAlias = node.alias === relationAliasFor(node.qualified)
      || (!node.id.startsWith('sql-instance:') && node.alias === relationAliasFor(node.id, node.name));
    node.label = samePhysical.length > 1 ? `${node.name} (${generatedAlias ? samePhysical.indexOf(node) + 1 : node.alias})`
      : sameName.length > 1 ? sameSuffix.length>1?node.qualified:suffix : node.name;
  }
  const resolveOwner = (owner: string) => {
    const exact = nodes.filter(node => key(node.alias) === key(owner) || node.id === owner || node.canvasId === owner);
    if (exact.length === 1) return exact[0];
    const physical = nodes.filter(node => key(node.qualified) === key(owner));
    return physical.length === 1 ? physical[0] : undefined;
  };
  const reference = (value: string) => {
    const parts = sqlIdentifierParts(value);
    if (parts.length < 2) return null;
    const owner = resolveOwner(renderSqlIdentifier(parts.slice(0, -1)));
    return owner ? {identity: `${owner.id}:${JSON.stringify(parts.at(-1))}`, display: `${owner.label}.${renderSqlIdentifier(parts.slice(-1))}`,
      title: `${owner.qualified}.${renderSqlIdentifier(parts.slice(-1))}`} : null;
  };
  // Tokenize quoted identifiers as a unit; never touch SQL string literals/comments.
  const tokens = /'(?:''|[^'])*'|\$\$[\s\S]*?\$\$|--[^\r\n]*|\/\*[\s\S]*?\*\/|(?:"(?:""|[^"])+"|[A-Za-z_][A-Za-z0-9_$]*)(?:\s*\.\s*(?:"(?:""|[^"])+"|[A-Za-z_][A-Za-z0-9_$]*))*/g;
  const display = (text: string) => String(text ?? '').replace(tokens, token => {
    if (/^'|^\$\$|^--|^\/\*/.test(token)) return token;
    return reference(token)?.display ?? resolveOwner(token)?.label ?? token;
  });
  const identity = (text: string) => reference(text)?.identity ?? resolveOwner(text)?.id ?? key(text);
  const sql = (text: string) => {
    const matches = String(text).match(/'(?:''|[^'])*'|\$\$[\s\S]*?\$\$|--[^\r\n]*|\/\*[\s\S]*?\*\/|(?:"(?:""|[^"])+"|[A-Za-z_][A-Za-z0-9_$]*)(?:\s*\.\s*(?:"(?:""|[^"])+"|[A-Za-z_][A-Za-z0-9_$]*))*|\d+(?:\.\d+)?|[^\s]/g) ?? [];
    return matches.filter(token => !/^--|^\/\*/.test(token)).map(token => /^'|^\$\$/.test(token) ? token
      : reference(token)?.identity ?? (sqlIdentifierParts(token).length ? key(token) : token)).join('|');
  };
  const diagnosticAliases = new Map(nodes.map(node => [node.alias.toUpperCase(), node.label]));
  const diagnostic = (text: string) => formatDiagnosticDisplayText(String(text ?? ''), diagnosticAliases);
  return {nodes, reference, display, diagnostic, identity, sql};
}

const noCatalog = reviewCatalog();
export function definitionKey(option: AutoMapCandidate | MappingState, catalog: ReviewCatalog = noCatalog) {
  const candidate = 'source_attributes' in option;
  const mode = (candidate ? option.mapping_mode : option.mappingMode) || 'source';
  const sources = candidate ? option.source_attributes : option.sourceColumns ?? (option.sourceColumn ? [option.sourceColumn] : []);
  const rule = (candidate ? option.preprocessing_rule_type : option.rule) || 'Direct';
  let expression = (candidate ? option.preprocessing_rule : option.expression) || '';
  const dependencies = (candidate ? option.source_dependencies : option.sourceDependencies) ?? [];
  const valueIds = (candidate ? option.value_binding_ids : option.valueBindingIds) ?? [];
  const attribute = (candidate ? option.attribute_name : option.attributeName) || null;
  const constant = candidate ? option.constant_value : option.constantValue;
  if (mode === 'source' && (!expression || /^(DIRECT|IDENTITY)$/i.test(expression))) {
    expression = /^(UPPER|LOWER|TRIM)$/i.test(rule) && sources.length === 1 ? `${rule}(${sources[0]})`
      : /^(DIRECT|IDENTITY)$/i.test(rule) && sources.length === 1 ? sources[0] : rule;
  }
  const canonicalValue = (value: string) => value.startsWith('$') ? value.toUpperCase() : value;
  const placeholders=expression.replace(/'(?:''|[^'])*'|\$\$[\s\S]*?\$\$/g,'').match(/\$[A-Za-z_][\w$]*/g)??[];
  const values=mode==='attribute'&&attribute?[`$${attribute}`]:mode==='constant'?(String(constant??'').startsWith('$')?[String(constant)]:[]):placeholders.length?placeholders:valueIds;
  return JSON.stringify([mode, sources.map(catalog.identity).sort(), mode === 'source' ? catalog.sql(expression) : null,
    constant ?? null, attribute?.toUpperCase() ?? null,
    [...new Set([...sources, ...dependencies].map(catalog.identity))].sort(),
    [...new Set(values.map(canonicalValue))].sort()]);
}

export function concreteCandidate(option: AutoMapCandidate) {
  const expression = option.preprocessing_rule ?? '';
  return Boolean(option.source_attributes?.some(source => typeof source === 'string' && source.trim())
    || (option.mapping_mode === 'constant' && option.constant_value != null)
    || (option.mapping_mode === 'attribute' && option.attribute_name?.trim())
    || /^(?:NULL|TRUE|FALSE|CURRENT_DATE|CURRENT_TIMESTAMP)$/i.test(expression.trim())
    || (/^\s*(?:\$[A-Za-z_]|[('"0-9+-]|(?:CASE|SELECT|WITH)\b|(?:[A-Za-z_][\w$]*|"[^"]+")\s*[.(])/i.test(expression)));

}
export function alternativeCandidates(row: MappingState, catalog: ReviewCatalog = noCatalog) {
  const current = definitionKey(row, catalog);
  const seen = new Set<string>();
  return (row.aiCandidates ?? []).filter(option => {
    if (!concreteCandidate(option)) return false;
    const identity = definitionKey(option, catalog);
    if (identity === current || seen.has(identity)) return false;
    seen.add(identity);return true;
  }).slice(0, 3);
}
export function currentCandidate(row: MappingState, catalog: ReviewCatalog = noCatalog) {
  return row.aiCandidates?.find(option => concreteCandidate(option) && definitionKey(option, catalog) === definitionKey(row, catalog));
}
export function previousMappingCandidate(row: MappingState): AutoMapCandidate | null {
  const sources = row.sourceColumns ?? (row.sourceColumn ? [row.sourceColumn] : []);
  if (!sources.length && row.constantValue == null && !row.attributeName && !row.expression && !storedRuleExpression(row)) return null;
  return {...currentCandidate(row), candidate_id: `previous:${row.id}:${definitionKey(row)}`,
    source_attributes: [...sources], source_dependencies: [...(row.sourceDependencies ?? [])],
    mapping_mode: row.mappingMode ?? 'source', constant_value: row.constantValue ?? null, attribute_name: row.attributeName ?? null,
    preprocessing_rule: row.expression ?? storedRuleExpression(row), preprocessing_rule_type: row.rule, preprocessing_nl_rule: row.nlRule ?? null,
    value_binding_ids: [...(row.valueBindingIds ?? [])], confidence_score: row.confidenceScore ?? null,
    confidence_reason: row.confidenceReason ?? null, transformation_classification: row.transformationClassification as AutoMapCandidate['transformation_classification'],
    validation_status: 'unvalidated', validation_errors: [], warnings: [], previously_applied: true,
    origin: row.manuallySaved || row.manuallyEditedAfterAutoMap || row.aiReviewStatus === 'edited'
      || (!row.selectedAiCandidateId && !currentCandidate(row)) ? 'manual' : 'ai'};
}
export function currentValidationCandidate(row: MappingState): AutoMapCandidate | null {
  const previous = previousMappingCandidate(row);
  return previous?.origin === 'manual' ? previous : currentCandidate(row) ?? previous;
}

function rawGuidanceForRow(row: MappingState): AutoMapSuggestion[] {
  const provided = [...(row.aiSuggestions ?? [])];
  const current = (row.aiCandidates??[]).find(item=>item.candidate_id===row.selectedAiCandidateId);
  const messages = [...(row.draftIssues ?? []).map(issue => issue.message), ...(row.reconciliationWarnings ?? []),
    ...(current?.warnings ?? []), ...(current?.validation_errors ?? []), ...(current?.scoring_issues ?? []).map(issue => issue.message)];
  for (const [index,message] of messages.entries()) if(message.trim()) provided.push({suggestion_id:`warning:${row.id}:${index}`,kind:'evidence',message,source_references:[]});
  for (const option of row.aiCandidates ?? []) if (!concreteCandidate(option)) {
    const message = option.unmatched_reason || option.confidence_reason || option.validation_errors?.join(' ');
    if (message) provided.push({suggestion_id: `guidance:${option.candidate_id}`, kind: 'evidence', message, source_references: []});
  }
  if (!provided.length && row.status !== 'MAPPED' && row.unmatchedReason) provided.push({suggestion_id: `row:${row.id}`, kind: 'evidence', message: row.unmatchedReason, source_references: []});
  const seen = new Set<string>();
  return provided.filter(item => {const key = `${item.kind}:${item.message.trim()}`;if (seen.has(key)) return false;seen.add(key);return true;});
}
export function plainValidationMessage(message: string) {
  if (/value|placeholder/i.test(message)) return 'Requires Value: provide the approved project Value before using this option.';
  if (/join|connect|relationship|undefined relation|outside.*selection/i.test(message)) return 'Requires join or source selection: review the required tables and relationship.';
  if (/column|attribute|source/i.test(message)) return 'Requires source: verify that the referenced column is available in the selection.';
  return 'Needs rule validation: review the expression and its required inputs.';
}

export function relevantWarnings(row: MappingState, warnings: string[], targets: string[]) {
  const current=row.targetColumn.toUpperCase();
  const seen=new Set<string>();
  return warnings.filter(message=>{
    const upper=message.toUpperCase();
    if(targets.some(target=>target.toUpperCase()!==current&&new RegExp('(^|[^A-Z0-9_])'+target.toUpperCase().replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'([^A-Z0-9_]|$)').test(upper))&&!upper.includes(current))return false;
    const key=message.trim().replace(/\s+/g,' ').toLowerCase();if(seen.has(key))return false;seen.add(key);return true;
  });
}

export function technicalReviewMessage(message:string):boolean {
  return /precedents? were supplied without|precedent_decision|packet\s*receipts?|packet evidence|citation|linked precedent does not support|exact evidence was examined in blocks|\b(?:capture_\w+|AUTO_MAP\w*|unresolvedFirmValue|missing_project_value|source_binding_\w+|scoring_issues|validation_errors)\b|\b(?:SQL|EXPLAIN|traceback|exception|stack trace|SQLSTATE|tool|payload|malformed proposal field)\b|\b\w*(?:Error|Exception)\b|\b(?:SELECT|INSERT|UPDATE|DELETE)\b[\s\S]*\b(?:FROM|INTO|SET)\b|https?:\/\/|\b[A-Z]:\\/i.test(message);
}

/** Display-only: never rewrite stored model reasoning, scores or diagnostics. */
export function businessReviewText(message: string | null | undefined): string {
  let diagnosticTail = false;
  return (message ?? '').split(/\r?\n|(?<=[.!?])\s+(?=[A-Z])/).map(part => {
    if (diagnosticTail) return '';
    const text = part.trim();
    if (/^Required Firm Value is unresolved:/i.test(text)) {
      const values = text.match(/\$[A-Za-z_][\w$]*/g) ?? [];
      return values.length ? `The mapping depends on a project Value: ${values.join(', ')}.` : 'The mapping depends on a project Value.';
    }
    if (/^(?:Source requires review|Missing source|Missing column|Column unavailable)$/i.test(text)) return 'The proposed source may not be available in the selected data.';
    if (technicalReviewMessage(text)) { diagnosticTail = true; return ''; }
    if (/\b(?:unresolved|needs? (?:review|validation)|review (?:needed|required)|validation failed|requires? human review)\b/i.test(text)) return '';
    return text;
  }).filter(Boolean).join(' ');
}

export function mappingDisplayStatus(row: MappingState) {
  return hasMappingDefinition(row) ? 'MAPPED' : 'UNMAPPED';
}

export function guidanceForRow(row:MappingState):AutoMapSuggestion[] {
  return rawGuidanceForRow(row).map(item => ({...item, message: businessReviewText(item.message)})).filter(item => item.message);
}
export function technicalGuidanceForRow(row:MappingState):AutoMapSuggestion[] {
  const entries=rawGuidanceForRow(row).filter(item=>technicalReviewMessage(item.message));
  const messages=[row.unmatchedReason,row.validation?.error,...(row.aiCandidates??[]).flatMap(option=>[option.confidence_reason,...(option.validation_errors??[]),...(option.warnings??[])])];
  for(const message of messages)if(message&&technicalReviewMessage(message)&&!entries.some(item=>item.message===message))entries.push({suggestion_id:`technical:${entries.length}`,kind:'evidence',message,source_references:[]});
  return entries;
}
