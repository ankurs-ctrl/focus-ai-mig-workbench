# Contacts upload and publication corrections

Source baseline: `719fd41f28105289c97beec7c54f3dedcc0eac13`, branch `sync/uat-frontend-native-integration`.

## Application changes

- Reference replacement now acquires the current upload request row lock **inside the same transaction** as deletion/insertion. Request, caller, role, processing ID, worker generation, lease token and expiry must match. A takeover uses the same row lock. A stale attempt rolls back before replacing evidence. Short curation, learning-preparation, relationship and FIR-event publication operations use the same fence. Learning execution retains its existing independent work-item leases.
- Durable reference reads require their exact authorized upload request. Legacy reads use legacy reference rows only and refuse to guess when the caller has a durable upload. There is no cross-caller “newest processing snapshot” fallback.
- Parsed target aliases carry a separate SQL identifier spelling through frontend rows, snapshots, reopened workspaces and compiler requests. The compiler validates this spelling against the display identity and existing safe identifier grammar. Quoted spaces/dots remain single identifiers.
- Unqualified dependencies bind to uniquely visible CTE output contracts. Their expressions use the same binding. Multiple visible owners are rejected. Hidden parent columns are not promoted into CTE outputs.
- Physical selection, instance suppression and imported graph hydration use quote-aware keys. Table-reference conversion preserves quoted component case, dots and escaped quotes. Unquoted names use canonical Snowflake case, preventing alias drift across Apply and graph construction.
- Recovery keys include a non-secret server-derived account/user/role scope. Recovery waits for that identity. A 404 means not visible/unknown, not proof that another caller’s request never existed. Useful preview handles survive terminal processing until successful Apply or explicit discard.
- Reference observation has per-request timeouts and an overall 60-second deadline. Authentication failures are explicit; original results remain visible. Cleanup and request-identity changes cancel obsolete observations.

No frontend navigation, tours, authentication flow or team styling was replaced. The recovery identity endpoint is additive and uses the existing caller Snowflake session. No credentials are stored in browser recovery keys.

## Actual Contacts fixture

`services/sttm-builder/tests/fixtures/sql_upload/contacts_actual.sql` contains the actual query supplied in the review handoff. Its business predicates, including the `ccOther` lookup against `ADDRESS1_COUNTRY`, remain unchanged.

Offline tests add an explicit UAT database/schema parsing context; they do not change or execute client tables. A separate compilation test supplies only the five relevant `SET` declarations from `docs/01-EverNest-HHs-reference.sql`: `LegacyContactPrefix`, `LegacyHHcPrefix`, `BackupOwnerID`, `BizContactRecordType`, `IndvContactRecordType`. These are test inputs, not new production defaults.

The regressions verify 49 individual rows and the complete projection, seven outer LEFT joins, four retained CTE definitions, separate country/state lookup instances, quoted target aliases, `HEADOFHOUSEHOLD` binding, typed snapshot round trip, and explicit ambiguity rejection. With the supplied Household values, the offline compiler reports valid and ready with no unresolved placeholders.

## Verification limits and installation

Snowflake transport, takeover ordering and browser network/timers are simulated in the regression tests. This is not evidence that client physical tables exist, live Snowflake EXPLAIN succeeds, or the Contacts business rules are correct. No live Snowflake mutation or UAT deployment was performed for these corrections.

Deploy backend and frontend together over the stated integration baseline. The earlier `719fd41` upload recovery schema and setup remain prerequisites; this correction adds no further table schema migration. Preserve destination environment files. Do not use an older ZIP to overwrite the frontend team's merged baseline.

## Local verification results

- Full backend run: 4,146 passed, 31 skipped.
- Final affected Contacts/publication tests: 24 passed (overlapping coverage, not additive).
- Frontend: all 25 harnesses passed; TypeScript passed.
- Original Contacts query hash: `3a9760e824b55498d93c04041d0c3df6634fabf8b8aae6ad139ea04885ff67fc`.
- Test values are packaged separately in `contacts_household_test_values.sql`; production SQL was not edited.
- No live Snowflake acceptance, remote push, or deployment was performed.
