from __future__ import annotations

import json
import hashlib
import logging
import re
import threading
from datetime import datetime, timezone
from typing import Any
from types import SimpleNamespace
from uuid import uuid4
from sqlglot import exp, parse, parse_one

logger = logging.getLogger(__name__)


class DraftAutosaveReviewError(RuntimeError):
    """An autosave failed after useful mapping/review evidence was prepared."""

    def __init__(self, message: str, *, partial_result: dict[str, Any]) -> None:
        self.partial_result = partial_result
        super().__init__(message)

from app.agent_runs.models import EFFORT_POLICIES, AgentActor, AgentCommand, EffortLevel, ToolResult
from app.agent_runs.value_bindings import prompt_project_value, valid_typed_project_value
from app.agent_runs.attachment_retrieval import load_scoped_attachments, retrieve_attachment_evidence
from app.agent_runs.contracts import (
    EvidenceReference,
    FIRMappingRecipeV1,
    MappingContextPackageV1,
    MigrationPlanArtifactV1,
    WorkbenchAgentResultV1,
    WorkbenchMutationReceipt,
)
from app.agent_runtime.execution import BudgetExceededError, ExecutionBudget, TraceEmitter, null_trace
from app.agent_tools.column_confidence import candidate_confidence
from app.agent_tools.commands import AgentCommandExecutor
from app.agent_tools.sql_isolation import compile_error_summary, isolate as isolate_failing_columns
from app.agent_tools.sql_debugger import (
    DATA_ERRORS,
    MODEL_FIX_SCHEMA,
    DebugContext,
    Diagnosis,
    SqlDebugger,
    model_fix_prompt,
    placeholders_in,
)
from app.agent_tools.contract_reader import (
    TableContractUnavailable,
    catalog_signatures,
    normalize_fqn,
    read_contracts,
    same_named_signatures,
    split_fqn,
)
from app.agent_tools.structural_precedents import retarget_cte_sql, schema_counterparts
from app.migration_workflow.population_rules import precedent_population
from app.agent_tools.firm_values import (
    apply as apply_firm_value,
    binding as firm_value_binding,
    choose as choose_firm_values,
    hints as firm_value_hints,
    known_values as known_firm_values,
    names_in as firm_value_names_in,
    norm as firm_value_norm,
    usable_value as usable_firm_value,
    usages_from_rows as firm_value_usages_from_rows,
)
from app.agent_runs.attachment_facts import (
    conflicts as attachment_conflicts,
    facts_for_target,
    mapping_evidence as attachment_mapping_evidence,
    value_bindings as attachment_value_bindings,
)
from app.core.workspace_snapshot import (
    base_query_sql,
    canonical_derived_source,
    canonical_mapping_row,
    canonical_snapshot,
    compile_mapping_item,
    derived_reference_prefix,
    grid_value_bindings,
    lift_join_filters,
    merge_validation_history,
    relation_alias_for,
    relation_graph as snapshot_relation_graph,
    rewrite_qualifiers,
    table_fqn as snapshot_table_fqn,
    validation_receipt,
)
from app.agent_tools.specialists import (
    CortexSpecialistAdapter,
    LearningCard,
    SpecialistRequest,
    SpecialistResponse,
)
from app.core.learning_retrieval import LearningRetrievalService
from app.core.learning_subjects import target_column_subject
from app.core.derived_source import DerivedSourceService
from app.core.dbt_conversion import DbtConversionService
from app.core.exceptions import SemanticAssetNotFoundError
from app.core.mapping_sql import MappingSqlService
from app.core.lookup_sql import normalized_lookup_relation
from app.core.conversation import ConversationService
from app.core.semantic_context import SemanticContextService
from app.core.snowflake_analyst import SnowflakeAnalystClient
from app.core.test_case_generation import TestCaseGenerationService
from app.core.exceptions import SnowflakeQueryError
from app.core.sql_execution_guard import sql_hash, is_single_read_only_query
from app.core.project_service import ProjectService
from app.core.sql_parser import active_sql_lineage as _active_sql_lineage, parse_sql_document as _parse_sql_document
from app.migration_workflow.validation import validate_mapping_set
from app.schema.common import TableRef
from app.schema.contracts import ApiActor
from app.schema.conversation import ConversationSearchRequestData
from app.schema.dbt_conversion import DbtConversionRequest
from app.schema.mapping_sql import (
    MappingSqlCompileRequest,
    MappingSqlMappingItem,
    MappingSqlPreviewRequest,
    MappingSqlReviewRequest,
)
from app.schema.project import ProjectCreateRequest, STTMAutosaveRequest, STTMCreateRequest
from app.schema.semantic_context import (
    SemanticContextRefreshRequest,
    SemanticBundleStatus,
    SemanticProjectionProfile,
    SemanticProjectionRequest,
)
from app.schema.derived_source import DerivedSourceDefinition
from app.schema.test_case_generation import TestCaseGenerationRequest
from app.schema.sttm_builder import (
    RelationEdge,
    RelationGraphContext,
    RelationNode,
    RelationNodeKind,
    RelationshipContextItem,
    ValueBinding,
)
from app.schema.workspace_context import (
    WorkbenchContextSnapshotV1,
    WorkspaceDerivedSourceRef,
    WorkspaceFilterState,
)


_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
_AGGREGATE_CALL = re.compile(
    r"\b(LISTAGG|ARRAY_AGG|OBJECT_AGG|ARRAY_UNIQUE_AGG|SUM|COUNT|COUNT_IF|AVG|MIN|MAX|MEDIAN|MODE|ANY_VALUE|"
    r"STDDEV\w*|VARIANCE\w*|VAR_POP|VAR_SAMP|BOOLAND_AGG|BOOLOR_AGG|HLL|APPROX_COUNT_DISTINCT)\s*\(", re.I)
_WINDOW_CLAUSE = re.compile(r"\bOVER\s*\(", re.I)
# Words that describe any migration request and so cannot identify a project.
_GENERIC_REQUEST_WORDS = frozenset({
    "the", "and", "for", "from", "with", "use", "using", "like", "earlier", "previous", "prior", "old",
    "learnings", "learning", "mapping", "mappings", "migration", "migrations", "project", "projects",
    "source", "sources", "target", "targets", "table", "tables", "data", "new", "all", "same", "similar",
})


def _historical_sql_driving_source(sql: str, verified_sources: list[str]) -> str | None:
    """Trace the final query's FROM through CTEs to an unambiguous physical source."""
    try:
        statements = parse(sql, read="snowflake")
    except Exception:
        return None
    statement = next((item for item in reversed(statements) if isinstance(item, exp.Query)), None)
    if statement is None:
        return None
    ctes = {cte.alias_or_name.upper(): cte.this for cte in statement.find_all(exp.CTE)}

    def trace(query: exp.Expression, seen: frozenset[str]) -> str | None:
        select = query if isinstance(query, exp.Select) else query.find(exp.Select)
        from_clause = (select.args.get("from_") or select.args.get("from")) if select else None
        table = from_clause.this if from_clause else None
        if not isinstance(table, exp.Table):
            return None
        reference = ".".join(part for part in (table.catalog, table.db, table.name) if part).upper()
        matches = [source for source in verified_sources
                   if source.upper() == reference or source.upper().endswith(f".{reference}")]
        if len(matches) == 1:
            return matches[0]
        if table.name.upper() in ctes and table.name.upper() not in seen:
            return trace(ctes[table.name.upper()], seen | {table.name.upper()})
        return None

    return trace(statement, frozenset())


def _scoped_precedent_query(
    sql: str, *, allowed_sources: list[str], target_columns: list[str],
) -> dict[str, Any]:
    """Verify a completed precedent's CTE scopes without flattening its joins."""
    parsed = parse_sql_document(sql)
    statements = parse(sql, read="snowflake")
    query = next((item for item in reversed(statements) if isinstance(item, exp.Query)), None)
    if query is None:
        raise ValueError("The precedent has no final SELECT query")
    aliases = [str(item.target_alias or "").upper() for item in parsed.column_mappings]
    if len(aliases) != len(set(aliases)) or set(aliases) != {value.upper() for value in target_columns}:
        raise ValueError("The precedent projection does not match the current target contract")
    references, active_ctes = _active_sql_lineage(sql, parsed)
    from app.agent_tools.source_readiness import resolve_visible_references
    resolved, unresolved = resolve_visible_references(references, allowed_sources)
    if unresolved or len(resolved) != len(references):
        raise ValueError("The precedent references missing or ambiguous current sources")
    ctes = {item.alias_or_name.upper(): item for item in query.find_all(exp.CTE)}
    scopes = [query, *(ctes[name].this for name in sorted(active_ctes) if name in ctes)]
    if len(scopes) != len(active_ctes) + 1:
        raise ValueError("An active precedent CTE cannot be resolved")
    for scope in scopes:
        # A nested query belongs to its own CTE scope. Each non-cross join
        # must carry an explicit predicate; physical fanout is assessed on the
        # final projection, after historical QUALIFY/DISTINCT shaping.
        for join in scope.find_all(exp.Join):
            if str(join.args.get("kind") or "").upper() == "CROSS":
                continue
            if join.args.get("on") is None and not join.args.get("using"):
                raise ValueError("A precedent join has no scoped join condition")
    return {
        "physical_sources": resolved,
        "active_ctes": sorted(active_ctes),
        "projection_columns": aliases,
        "sql_sha256": hashlib.sha256(sql.strip().encode("utf-8")).hexdigest(),
    }



def parse_sql_document(sql: str):
    parsed = _parse_sql_document(sql)
    for mapping in parsed.column_mappings:
        if mapping.physical_source_columns or mapping.unresolved_references or mapping.transformation:
            continue
        outputs = [step for step in mapping.lineage_path if step.get("kind") == "cte_output"]
        if not outputs:
            continue
        try:
            literal = parse_one(str(outputs[-1].get("expression") or ""), read="snowflake")
        except Exception:
            continue
        if isinstance(literal, (exp.Literal, exp.Null, exp.Boolean)):
            mapping.mapping_mode = "constant"
            mapping.constant_value = literal.sql(dialect="snowflake")
    return parsed


class WorkbenchWorkflowHandlers:
    """Idempotent adapters from workflow nodes to existing Workbench domain services."""

    # Conversation knowledge store shared by every partition of a claim.
    _knowledge: Any = None
    _settings: Any = None

    def __init__(
        self,
        *,
        repository: Any,
        settings: Any = None,
        project_service: ProjectService,
        session: Any,
        specialists: CortexSpecialistAdapter | None = None,
        budget: ExecutionBudget | None = None,
        trace: TraceEmitter | None = None,
        learning_retrieval: LearningRetrievalService | None = None,
        mapping_sql: MappingSqlService | None = None,
        semantic_context: SemanticContextService | None = None,
        derived_sources: DerivedSourceService | None = None,
        dbt_conversion: DbtConversionService | None = None,
        test_generation: TestCaseGenerationService | None = None,
        rag_search: ConversationService | None = None,
        analyst: SnowflakeAnalystClient | None = None,
        sql_preview_max_rows: int = 20,
        sql_timeout_seconds: int = 120,
        sql_result_max_bytes: int = 1_000_000,
        knowledge: Any | None = None,
    ) -> None:
        self.partition_factory = None
        # Set by the runtime for the length of one run; posts chat milestones.
        self.progress = None
        self._progress_counts: dict[str, dict[str, tuple[int, int]]] = {}
        self._settings = settings
        self._knowledge = knowledge
        self._repository = repository
        self._commands = AgentCommandExecutor(repository)
        self._projects = project_service
        self._session = session
        self._specialists = specialists
        self._budget = budget
        self._trace = trace or null_trace
        self._learning = learning_retrieval
        self._mapping_sql = mapping_sql
        self._semantic_context = semantic_context
        self._derived_sources = derived_sources
        self._dbt_conversion = dbt_conversion
        self._test_generation = test_generation
        self._rag_search = rag_search
        self._analyst = analyst
        self._sql_preview_max_rows = max(1, min(int(sql_preview_max_rows), 1000))
        self._sql_timeout_seconds = max(5, min(int(sql_timeout_seconds), 1800))
        self._sql_result_max_bytes = max(10_000, min(int(sql_result_max_bytes), 10_000_000))
        # Snowpark sessions and domain services are not thread-safe. Metadata
        # reads and mutations are serialized while independent Cortex calls run
        # concurrently across ready DAG nodes.
        self._domain_lock = threading.RLock()
        self._contract_cache = {}
        self._learning_card_cache = {}

    def usage_snapshot(self) -> tuple[int, int]:
        return self._budget.snapshot() if self._budget else (0, 0)

    def _tool(self, operation: str) -> None:
        if self._budget:
            self._budget.consume_tool(operation)

    def _model(self, operation: str) -> None:
        if self._budget:
            if operation.endswith(".repair"):
                self._budget.consume_category("retries", operation)
            self._budget.consume_category("specialist_model_calls", operation)
            self._budget.record_specialist_call()

    def _emit(self, event_type: str, status: str, summary: str, **data: Any) -> None:
        self._trace(event_type, status, summary, data)

    @staticmethod
    def _actor(state: dict[str, Any]) -> AgentActor:
        return AgentActor(
            app_user_id=str(state.get("actor_user_id") or state.get("app_user_id") or ""),
            snowflake_username=str(state.get("snowflake_username") or "") or None,
            tenant_id=str(state.get("tenant_id") or "default"),
            effective_role=str(state.get("effective_role") or ""),
            actor_type="agent-worker",
        )

    @staticmethod
    def _table_ref(fqn: str | None) -> TableRef | None:
        parts = [part.strip('"') for part in str(fqn or "").split(".") if part]
        if len(parts) != 3 or not all(_IDENTIFIER.fullmatch(part) for part in parts):
            return None
        return TableRef(database=parts[0], schema=parts[1], table=parts[2])

    def decision_thresholds(self) -> tuple[float, float]:
        """Confidence and margin at or above which a plan decision needs no question."""
        return (
            float(getattr(self._settings, "migration_agent_auto_resolve_confidence", 0.75)),
            float(getattr(self._settings, "migration_agent_auto_resolve_margin", 0.15)),
        )

    def remembered_decisions(self, state: dict[str, Any], subject_keys: list[str]) -> dict[str, str]:
        """This user's latest answer for each decision fingerprint in earlier runs.

        Answers persist as review items; reusing them means the same question
        about the same target (or, for values, the same project) is not asked
        again. The caller still accepts a value only if it is a current option.
        """
        wanted = {str(value) for value in subject_keys if str(value).strip()}
        if not wanted or not hasattr(self._repository, "find_answered_decisions"):
            return {}
        actor = self._actor(state)
        try:
            with self._domain_lock:
                # This run's own answers must be excluded: the graph replays the
                # node on resume and matches interrupts by call order, so
                # silently re-applying one would shift every later answer.
                items = self._repository.find_answered_decisions(
                    actor.user_id, actor.tenant_id, sorted(wanted),
                    exclude_run_id=str(state.get("run_id") or "") or None,
                )
        except Exception:
            logger.warning("Earlier decision answers could not be read; asking again", exc_info=True)
            return {}
        remembered: dict[str, str] = {}
        for item in items:
            try:
                payload = json.loads(item.answer or "")
            except (TypeError, json.JSONDecodeError):
                payload = {"answer": item.answer}
            if not isinstance(payload, dict) or payload.get("batch_decision") == "review_each":
                continue
            batch_values = payload.get("values") if isinstance(payload.get("values"), dict) else None
            for key in item.subject_keys:
                if key not in wanted or key in remembered:
                    continue
                value = batch_values.get(key) if batch_values is not None else (
                    payload.get("selected_value") or payload.get("answer")
                )
                if value not in (None, "") and str(value) != "__provide_current__":
                    remembered[key] = str(value)
        return remembered

    def _command(self, state: dict[str, Any], operation: str, subject_key: str, payload: dict[str, Any], *, project_id: str | None = None, sttm_id: str | None = None, expected_revision: int | None = None) -> AgentCommand:
        return AgentCommand(
            command_id=f"{state['run_id']}:{operation}:{subject_key}",
            run_id=str(state["run_id"]),
            step_id=f"{operation}:{subject_key}",
            operation=operation,
            subject_key=subject_key,
            actor=self._actor(state),
            project_id=project_id,
            sttm_id=sttm_id,
            expected_revision=expected_revision,
            payload=payload,
        )

    def authorize_scope(self, state: dict[str, Any]) -> dict[str, Any]:
        actor = self._actor(state)
        if not actor.user_id or not actor.effective_role:
            raise PermissionError("A delegated user identity and effective role are required")
        requested_targets = set(state.get("authorized_target_scope") or [])
        for item in state.get("manifest") or []:
            target = item.get("target_table")
            if target and requested_targets and target not in requested_targets:
                raise PermissionError(f"Target {target} is outside the authorized run scope")
        return {}

    def ingest_attachments(self, state: dict[str, Any]) -> dict[str, Any]:
        attachment_ids = list(state.get("attachment_ids") or [])
        for attachment_id in attachment_ids:
            self._tool("attachments.verify")
            with self._domain_lock:
                rows = self._session.sql(
                    """SELECT OWNER_USER_ID, TENANT_ID, SCAN_STATUS, PARSER_STATUS
                    FROM TBL_AGENT_ATTACHMENTS WHERE ATTACHMENT_ID = ? LIMIT 1""",
                    [attachment_id],
                ).collect()
            if not rows:
                raise PermissionError("An attachment is missing or outside the durable evidence store")
            row = rows[0].as_dict() if hasattr(rows[0], "as_dict") else dict(rows[0])
            actor = self._actor(state)
            if str(row.get("OWNER_USER_ID")) != actor.user_id or str(row.get("TENANT_ID")) != actor.tenant_id:
                raise PermissionError("An attachment is outside the initiating user's scope")
            if row.get("SCAN_STATUS") != "clean" or row.get("PARSER_STATUS") != "parsed":
                raise ValueError("An attachment has not passed safe parsing")
        readings = list(state.get("attachment_readings") or [])
        if attachment_ids and not readings and self._setting("migration_agent_attachment_reading_enabled", True):
            readings = self._read_attachments(state, attachment_ids)
        return {"attachment_ids": attachment_ids, "attachment_readings": readings}

    def _read_attachments(self, state: dict[str, Any], attachment_ids: list[str]) -> list[dict[str, Any]]:
        """Role, intent and cited facts for each attachment, cached by content and request."""
        from app.agent_runs.attachment_facts import read_attachment
        from app.agent_runtime.run_knowledge import TOOL_RESULT

        actor = self._actor(state)
        with self._domain_lock:
            attachments = load_scoped_attachments(self._session, attachment_ids, actor.user_id, actor.tenant_id)
        prompt = str(state.get("prompt") or "")
        targets = [str(value) for value in state.get("authorized_target_scope") or []]
        intent = hashlib.sha256(json.dumps([prompt, sorted(targets)]).encode("utf-8")).hexdigest()[:16]
        model = str(self._setting("migration_agent_attachment_model", "")
                    or self._setting("migration_agent_model_medium", "")
                    or self._setting("migration_agent_model_light", "") or "")

        def complete(text: str, schema: dict[str, Any]) -> dict[str, Any]:
            self._model("specialist.attachment_reader")
            with self._domain_lock:
                rows = self._session.sql(
                    "SELECT AI_COMPLETE(model => ?, prompt => ?, response_format => PARSE_JSON(?)) AS RESPONSE",
                    params=[model, text, json.dumps(schema)],
                ).collect(statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": str(
                    int(self._setting("migration_agent_attachment_timeout_seconds", 120)))})
            raw = rows[0][0] if rows else None
            return json.loads(raw) if isinstance(raw, str) else dict(raw or {})

        readings: list[dict[str, Any]] = []
        for attachment in attachments:
            key = f"attachment_reading:v1:{attachment.get('content_hash')}:{intent}"
            cached = self._knowledge.get(TOOL_RESULT, key) if self._knowledge is not None else None
            if cached is not None:
                readings.append(dict(cached))
                continue
            self._tool("attachments.read")
            try:
                reading = read_attachment(
                    attachment, request_text=prompt, targets=targets, complete=complete if model else None,
                    max_chars=int(self._setting("migration_agent_attachment_max_chars", 60_000)),
                ).as_dict()
            except BudgetExceededError:
                raise
            except Exception as exc:  # noqa: BLE001 - an unreadable file is reported, the run continues
                logger.warning("Attachment %s could not be read: %s", attachment.get("attachment_id"), type(exc).__name__)
                reading = {"attachment_id": attachment.get("attachment_id"), "filename": attachment.get("filename"),
                           "role": "reference", "usage_intent": "", "related_targets": [], "facts": [],
                           "dropped_facts": 0, "method": f"failed:{type(exc).__name__}"}
            if self._knowledge is not None and not str(reading.get("method")).startswith("failed"):
                self._knowledge.put_many(TOOL_RESULT, [(key, reading, [])])
            readings.append(reading)
            self._emit(
                "trace.action.completed", "succeeded" if reading["facts"] else "needs_review",
                f"Read {reading['filename']} as {str(reading['role']).replace('_', ' ')}: {len(reading['facts'])} "
                f"fact(s)" + (f"; {reading['dropped_facts']} unquotable statement(s) dropped." if reading.get("dropped_facts") else "."),
                trace_id=f"attachment-read:{reading.get('attachment_id')}", parent_trace_id=None, kind="workflow",
                label="Read attachment",
                details={"role": reading["role"], "usage_intent": reading.get("usage_intent"),
                         "related_targets": reading.get("related_targets"), "fact_count": len(reading["facts"]),
                         "kinds": sorted({fact["kind"] for fact in reading["facts"]})},
            )
        return readings

    def search_run_attachments(self, context: dict[str, Any], query: str, *, limit: int = 8) -> list[dict[str, Any]]:
        """Retrieve only parsed evidence owned by the caller of this durable run."""
        with self._domain_lock:
            evidence = load_scoped_attachments(
                self._session, list(context.get("attachment_ids") or []),
                str(context.get("app_user_id") or ""), str(context.get("tenant_id") or "default"),
            )
        return retrieve_attachment_evidence(evidence, query, limit=limit)

    def _project_name(self, state: dict[str, Any], decision: dict[str, Any]) -> str:
        """The name the user asked for, else the supervisor's, else a draft label covering every target."""
        from app.assistant_intent_classifier import requested_project_name

        if self._session is not None:
            self._model("assistant.project_name")
            with self._domain_lock:
                requested = requested_project_name(self._session, self._settings, str(state.get("prompt") or ""))
            if requested:
                return requested
        chosen = str(decision.get("project_name") or "").strip()
        if chosen and decision.get("name_source") != "host_default":
            return chosen[:255]
        targets = [str(item.get("target_table") or "").split(".")[-1] for item in state.get("manifest") or []
                   if item.get("target_table")]
        if len(targets) > 1:
            # A default taken from the first target mislabels a multi-target project.
            return f"Deep Agent draft - {len(targets)} targets"
        return (chosen or f"Migration Agent {str(state['run_id'])[-8:]}")[:255]

    def create_project(self, state: dict[str, Any]) -> dict[str, Any]:
        plan = (
            MigrationPlanArtifactV1.model_validate(state["migration_plan"])
            if state.get("migration_plan") else None
        )
        project_decision = dict(plan.project_decision or {}) if plan else {}
        # "Create a new project" must never add drafts to whichever project
        # happened to be open in the browser.
        create_requested = bool(project_decision.get("force_new"))
        if state.get("project_id") and not create_requested:
            with self._domain_lock:
                project = self._projects.get_project(str(state["project_id"]))
            actor = self._actor(state)
            # Older Workbench projects store the authenticated Snowflake username,
            # while newer records store the stable application user id.
            owner = str(project.created_by or "").strip().casefold() if project else ""
            caller_ids = {actor.user_id.strip().casefold()}
            if actor.snowflake_username:
                caller_ids.add(actor.snowflake_username.strip().casefold())
            if not owner or owner not in caller_ids:
                raise PermissionError("Existing project is not owned by the delegated caller")
            name = getattr(project, "project_name", None)
            return {"project_id": state["project_id"], **({"project_name": name} if name else {})}
        payload = {
            "project_name": self._project_name(state, project_decision),
            "description": str(project_decision.get("description") or state.get("prompt") or "")[:2_000],
            "metadata": {"created_by_migration_run": state["run_id"], "draft_only": True},
        }
        template_id = project_decision.get("template_id")
        if template_id:
            from app.schema.project import ProjectCreateFromTemplateRequest
            template_request = ProjectCreateFromTemplateRequest(
                **payload, template_id=template_id,
                source_system_key=project_decision["source_system_key"],
                target_database=project_decision.get("target_database"),
                target_schema=project_decision.get("target_schema"),
                bootstrap_mode="EMPTY", idempotency_key=f"deep-project:{state['run_id']}")
            self._tool("project.create_from_template")
            with self._domain_lock:
                result = self._projects.create_project_from_template(
                    template_request,
                    user_id=self._actor(state).user_id,
                    display_name=self._actor(state).snowflake_username,
                )
            return {"project_id": result.project.project_id, "project_name": payload["project_name"]}
        self._tool("project.create_draft")
        self._projects.ensure_storage_exists()
        receipt = self._commands.execute(
            self._command(state, "project.create_draft", f"migration_run:{state['run_id']}", payload),
            lambda: self._projects.create_project(
                ProjectCreateRequest.model_validate(payload),
                user_id=self._actor(state).user_id,
                display_name=self._actor(state).snowflake_username,
            ),
        )
        return {"project_id": receipt.result["project_id"], "project_name": payload["project_name"]}

    def create_mappings(self, state: dict[str, Any]) -> dict[str, Any]:
        project_id = str(state.get("project_id") or "")
        manifest = [dict(item) for item in state.get("manifest") or []]
        context = MappingContextPackageV1.model_validate(state.get("mapping_context_package") or {})
        source_refs = [table.model_dump(mode="json") for table in context.workspace.source_tables]
        if not source_refs:
            source_refs = [ref.model_dump(mode="json") for value in state.get("authorized_source_scope") or [] if (ref := self._table_ref(value))]
        authorized_targets = set(state.get("authorized_target_scope") or [])
        self._projects.ensure_storage_exists()
        existing_sttms = self._projects.list_sttms(project_id) if project_id else []
        for item in manifest:
            if authorized_targets and item.get("target_table") not in authorized_targets:
                raise PermissionError(f"Target {item.get('target_table')} is outside the authorized run scope")
            target = self._table_ref(item.get("target_table"))
            if target is None:
                raise ValueError(f"Mapping {item.get('mapping_name')} has no valid schema-qualified target")
            snapshot = {
                "context_version": "2.0",
                "context_key": f"migration:{state['run_id']}:{item['mapping_key']}",
                "page": "builder",
                "surface": "SOURCE_SELECTION",
                "project_id": project_id,
                "source_tables": source_refs,
                "target_table": target.model_dump(mode="json"),
                "driving_table": (
                    context.workspace.driving_table.model_dump(mode="json")
                    if context.workspace.driving_table else None
                ),
                "selected_columns_by_table": context.workspace.selected_columns_by_table,
                "mapping_rows": [],
                "relationships": context.workspace.relationships,
                "relation_graph": context.workspace.relation_graph,
                "derived_sources": [item.model_dump(mode="json") for item in context.workspace.derived_sources],
                "filters": context.workspace.filters.model_dump(mode="json"),
                "semantic": context.workspace.semantic.model_dump(mode="json"),
                "semantic_bundle": (
                    context.workspace.semantic_bundle.model_dump(mode="json")
                    if context.workspace.semantic_bundle else None
                ),
                "validation_history": context.workspace.validation_history,
            }
            stable_key = "deep-draft:" + hashlib.sha256(
                f"{state['run_id']}:{project_id}:{item['mapping_key']}:{item['target_table']}".upper().encode("utf-8")
            ).hexdigest()[:32]
            reusable = next((
                record for record in existing_sttms
                if str(record.target_table or "").strip('"').upper() == str(item["target_table"]).strip('"').upper()
                and bool(record.metadata.get("draft_only"))
                and (
                    record.metadata.get("mapping_key") == item["mapping_key"]
                    if record.metadata.get("mapping_key") else record.sttm_name == item["mapping_name"]
                )
                and (
                    # A follow-up child run edits the draft its lineage created.
                    str(record.metadata.get("migration_run_id") or "")
                    in {str(state["run_id"]), *map(str, state.get("run_lineage") or [])}
                )
            ), None)
            if reusable is not None:
                item["sttm_id"] = reusable.sttm_id
                item["status"] = "PENDING"
                continue
            payload = {"sttm_name": item["mapping_name"], "target_table": target.model_dump(mode="json"), "workspace_snapshot": snapshot, "metadata": {"migration_run_id": state["run_id"], "mapping_key": item["mapping_key"], "agent_external_key": stable_key, "draft_only": True}}
            self._tool("sttm.create_draft")
            receipt = self._commands.execute(
                self._command(state, "sttm.create_draft", f"target_table:{item['target_table']}", payload, project_id=project_id),
                lambda payload=payload: self._projects.create_sttm(project_id, STTMCreateRequest.model_validate(payload), user_id=self._actor(state).user_id, session_id=str(state["run_id"]), thread_id=str(state["run_id"])),
            )
            item["sttm_id"] = receipt.result["sttm_id"]
            item["status"] = "PENDING"
        self._emit("trace.group.started", "running", f"Scheduling {len(manifest)} mapping DAG node(s).", trace_id="mapping-execution", parent_trace_id=None, kind="group", label="Build draft mappings", details={"mapping_count": len(manifest)})
        return {"manifest": manifest}

    @staticmethod
    def _normalized_relationship(value: dict[str, Any]) -> RelationshipContextItem:
        candidate = dict(value)
        candidate.setdefault(
            "left_table",
            candidate.get("source_table") or candidate.get("from_table"),
        )
        candidate.setdefault(
            "right_table",
            candidate.get("target_table")
            or candidate.get("referenced_table")
            or candidate.get("to_table"),
        )
        raw_conditions = candidate.get("conditions") or candidate.get("column_mappings") or []
        normalized_conditions: list[dict[str, Any]] = []
        for condition in raw_conditions:
            if not isinstance(condition, dict):
                continue
            normalized_conditions.append({
                "left_column": condition.get("left_column")
                or condition.get("source_column")
                or condition.get("fk_column"),
                "right_column": condition.get("right_column")
                or condition.get("target_column")
                or condition.get("pk_column"),
                "operator": condition.get("operator") or "=",
            })
        candidate["conditions"] = normalized_conditions
        return RelationshipContextItem.model_validate(candidate)

    @staticmethod
    def _type_family(value: str) -> str:
        normalized = str(value or "").upper()
        if any(token in normalized for token in ("NUMBER", "DECIMAL", "NUMERIC", "INT", "FLOAT", "DOUBLE", "REAL")):
            return "numeric"
        if any(token in normalized for token in ("CHAR", "TEXT", "STRING", "VARCHAR")):
            return "text"
        if "TIMESTAMP" in normalized or normalized == "DATE" or normalized.startswith("TIME"):
            return "temporal"
        if "BOOLEAN" in normalized:
            return "boolean"
        if any(token in normalized for token in ("OBJECT", "ARRAY", "VARIANT")):
            return "semi_structured"
        return normalized

    @staticmethod
    def _quoted_table(table: TableRef) -> str:
        return ".".join(f'"{value}"' for value in (table.database, table.schema, table.table))

    @staticmethod
    def _quoted_column(value: str) -> str:
        if not _IDENTIFIER.fullmatch(str(value or "")):
            raise ValueError(f"Unsafe column identifier: {value}")
        return f'"{value}"'

    def _validate_source_relationships(
        self,
        *,
        state: dict[str, Any],
        source_tables: list[TableRef],
        raw_relationships: list[dict[str, Any]],
        reconcile: bool,
    ) -> tuple[list[RelationshipContextItem], list[dict[str, Any]], dict[str, Any]]:
        relationships: list[RelationshipContextItem] = []
        findings: list[dict[str, Any]] = []
        metrics_by_edge: dict[str, Any] = {}
        selected = {table.qualified_name.upper(): table for table in source_tables}
        contracts: dict[str, dict[str, Any]] = {}
        adjacency: dict[str, set[str]] = {key: set() for key in selected}

        for index, raw in enumerate(raw_relationships):
            normalized_raw = dict(raw)
            for side in ("left_table", "right_table"):
                reference = normalized_raw.get(side)
                if isinstance(reference, str):
                    current_table = selected.get(reference.strip('"').upper())
                    if current_table is not None:
                        normalized_raw[side] = current_table.model_dump()
            try:
                relationship = self._normalized_relationship(normalized_raw)
            except Exception:
                findings.append({
                    "category": "relationship_contract",
                    "blocking": True,
                    "safe_summary": "A planned join does not match the Workbench relationship contract.",
                    "details": {"relationship_index": index},
                })
                continue
            left_key = relationship.left_table.qualified_name.upper()
            right_key = relationship.right_table.qualified_name.upper()
            edge_id = str(raw.get("relationship_id") or raw.get("id") or f"join_{index + 1}")
            if left_key not in selected or right_key not in selected:
                findings.append({
                    "category": "relationship_scope",
                    "blocking": True,
                    "safe_summary": "A planned join references a table outside the prepared source set.",
                    "details": {"edge_id": edge_id},
                })
                continue
            if not relationship.conditions:
                findings.append({
                    "category": "relationship_contract",
                    "blocking": True,
                    "safe_summary": "A planned join has no column conditions.",
                    "details": {"edge_id": edge_id},
                })
                continue

            for table in (relationship.left_table, relationship.right_table):
                key = table.qualified_name.upper()
                if key not in contracts:
                    contracts[key] = self._describe_table(table.qualified_name)
            left_contract = {
                str(column["name"]).upper(): column
                for column in contracts[left_key]["column_contracts"]
            }
            right_contract = {
                str(column["name"]).upper(): column
                for column in contracts[right_key]["column_contracts"]
            }
            edge_invalid = False
            for condition in relationship.conditions:
                left_column = left_contract.get(condition.left_column.upper())
                right_column = right_contract.get(condition.right_column.upper())
                if left_column is None or right_column is None:
                    edge_invalid = True
                    findings.append({
                        "category": "join_key_contract",
                        "blocking": True,
                        "safe_summary": "A planned join key is missing from its source contract.",
                        "details": {
                            "edge_id": edge_id,
                            "left_column": condition.left_column,
                            "right_column": condition.right_column,
                        },
                    })
                    continue
                left_family = self._type_family(str(left_column.get("type") or ""))
                right_family = self._type_family(str(right_column.get("type") or ""))
                if left_family != right_family:
                    edge_invalid = True
                    findings.append({
                        "category": "join_key_type",
                        "blocking": True,
                        "safe_summary": "A planned join key has incompatible data types.",
                        "details": {
                            "edge_id": edge_id,
                            "left_type": left_column.get("type"),
                            "right_type": right_column.get("type"),
                        },
                    })
            if edge_invalid:
                continue
            alternative = relationship.normalized_lookup_alternative
            if alternative:
                if (len(relationship.conditions) != 1 or
                    not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", alternative) or
                    alternative.upper() not in right_contract or
                    self._type_family(str(left_contract[relationship.conditions[0].left_column.upper()].get("type") or "")) != "text" or
                    self._type_family(str(right_contract[alternative.upper()].get("type") or "")) != "text"):
                    findings.append({"category": "join_key_contract", "blocking": True,
                        "safe_summary": "A normalized lookup requires current text columns for the value, code, and alias.",
                        "details": {"edge_id": edge_id}})
                    continue
            missing_filter_columns = [
                item.column for item in relationship.literal_filters
                if item.column.upper() not in (left_contract if item.side == "left" else right_contract)
            ]
            if missing_filter_columns:
                findings.append({"category": "join_key_contract", "blocking": True,
                    "safe_summary": "A planned join filter column is missing from its source contract.",
                    "details": {"edge_id": edge_id, "columns": missing_filter_columns}})
                continue
            # Contract matching is case-insensitive, but SQL quotes identifiers:
            # precedent SQL written as `c.family_id` must become "FAMILY_ID", or
            # the join check and the saved draft both fail to compile.
            relationship = relationship.model_copy(update={
                "conditions": [condition.model_copy(update={
                    "left_column": str(left_contract[condition.left_column.upper()]["name"]),
                    "right_column": str(right_contract[condition.right_column.upper()]["name"]),
                }) for condition in relationship.conditions],
                "literal_filters": [item.model_copy(update={"column": str(
                    (left_contract if item.side == "left" else right_contract)[item.column.upper()]["name"])})
                    for item in relationship.literal_filters],
                **({"normalized_lookup_alternative": str(right_contract[alternative.upper()]["name"])}
                   if alternative else {}),
            })
            alternative = relationship.normalized_lookup_alternative
            relationships.append(relationship)
            adjacency[left_key].add(right_key)
            adjacency[right_key].add(left_key)

            if not reconcile:
                continue
            left_columns = [self._quoted_column(item.left_column) for item in relationship.conditions]
            right_columns = [self._quoted_column(item.right_column) for item in relationship.conditions]
            left_hash = f"HASH({', '.join(left_columns)})"
            right_hash = f"HASH({', '.join(right_columns)})"
            left_join_hash = f"HASH({', '.join(f'L.{column}' for column in left_columns)})"
            left_null = " OR ".join(f"L.{column} IS NULL" for column in left_columns)
            right_null = " OR ".join(f"R.{column} IS NULL" for column in right_columns)
            predicates = " AND ".join(
                f"L.{self._quoted_column(item.left_column)} {item.operator} R.{self._quoted_column(item.right_column)}"
                for item in relationship.conditions
            )
            if alternative:
                condition = relationship.conditions[0]
                left_key = self._quoted_column(condition.left_column)
                right_code = self._quoted_column(condition.right_column)
                right_alias = self._quoted_column(alternative)
                keyed_right, match_key = normalized_lookup_relation(
                    self._quoted_table(relationship.right_table), right_code, right_alias
                )
                if match_key.upper() in right_contract:
                    raise ValueError("A generated lookup key conflicts with the current table contract")
                predicates = f"TRIM(UPPER(L.{left_key})) = R.{match_key}"
            left_table = self._quoted_table(relationship.left_table)
            right_table = keyed_right if alternative else self._quoted_table(relationship.right_table)
            # A left-side filter scopes which child rows take part in this join
            # (e.g. only NOTEABLE_TYPE = 'Crm::Contact' associations); a
            # right-side filter narrows the parent inside the ON clause.
            left_scope = " AND ".join(
                f"L.{self._quoted_column(item.column)} = {MappingSqlService._string_literal(item.value)}"
                for item in relationship.literal_filters if item.side == "left"
            )
            right_filters = [
                f"R.{self._quoted_column(item.column)} = {MappingSqlService._string_literal(item.value)}"
                for item in relationship.literal_filters if item.side == "right"
            ]
            if right_filters:
                predicates = " AND ".join([predicates, *right_filters])
            left_where = f"WHERE {left_scope}" if left_scope else ""
            query = f"""
                WITH L_STATS AS (
                    SELECT COUNT(*) AS ROW_COUNT,
                           COUNT(DISTINCT {left_hash}) AS UNIQUE_KEY_COUNT,
                           COUNT_IF({left_null}) AS NULL_KEY_COUNT
                    FROM {left_table} AS L
                    {left_where}
                ), R_STATS AS (
                    SELECT COUNT(*) AS ROW_COUNT,
                           COUNT(DISTINCT {right_hash}) AS UNIQUE_KEY_COUNT,
                           COUNT_IF({right_null}) AS NULL_KEY_COUNT
                    FROM {right_table} AS R
                ), J_STATS AS (
                    SELECT COUNT(*) AS JOINED_ROW_COUNT,
                           COUNT_IF(NOT ({right_null})) AS MATCHED_ROW_COUNT,
                           COUNT_IF({right_null}) AS ORPHAN_ROW_COUNT,
                           COUNT(DISTINCT IFF(NOT ({right_null}), {left_join_hash}, NULL)) AS MATCHED_LEFT_KEY_COUNT
                    FROM {left_table} AS L
                    LEFT JOIN {right_table} AS R ON {predicates}
                    {left_where}
                )
                SELECT L_STATS.ROW_COUNT AS LEFT_ROW_COUNT,
                       L_STATS.UNIQUE_KEY_COUNT AS LEFT_UNIQUE_KEY_COUNT,
                       L_STATS.NULL_KEY_COUNT AS LEFT_NULL_KEY_COUNT,
                       R_STATS.ROW_COUNT AS RIGHT_ROW_COUNT,
                       R_STATS.UNIQUE_KEY_COUNT AS RIGHT_UNIQUE_KEY_COUNT,
                       R_STATS.NULL_KEY_COUNT AS RIGHT_NULL_KEY_COUNT,
                       J_STATS.JOINED_ROW_COUNT,
                       J_STATS.MATCHED_ROW_COUNT,
                       J_STATS.ORPHAN_ROW_COUNT,
                       J_STATS.MATCHED_LEFT_KEY_COUNT
                FROM L_STATS, R_STATS, J_STATS
            """
            self._tool("source_preparation.reconcile_join")
            try:
                with self._domain_lock:
                    rows = self._session.sql(query).collect()
                row = rows[0].as_dict() if rows and hasattr(rows[0], "as_dict") else (dict(rows[0]) if rows else {})
                left_count = int(row.get("LEFT_ROW_COUNT") or 0)
                right_count = int(row.get("RIGHT_ROW_COUNT") or 0)
                joined_count = int(row.get("JOINED_ROW_COUNT") or 0)
                orphan_count = int(row.get("ORPHAN_ROW_COUNT") or 0)
                left_unique = int(row.get("LEFT_UNIQUE_KEY_COUNT") or 0)
                right_unique = int(row.get("RIGHT_UNIQUE_KEY_COUNT") or 0)
                matched_left = int(row.get("MATCHED_LEFT_KEY_COUNT") or 0)
                fanout_ratio = (joined_count / left_count) if left_count else 0.0
                orphan_rate = (orphan_count / joined_count) if joined_count else 0.0
                coverage = (matched_left / left_unique) if left_unique else 0.0
                cardinality = (
                    "one_to_one" if left_unique == left_count and right_unique == right_count
                    else "many_to_one" if right_unique == right_count
                    else "one_to_many" if left_unique == left_count
                    else "many_to_many"
                )
                metrics_by_edge[edge_id] = {
                    "relationship_index": len(relationships) - 1,
                    "left_row_count": left_count,
                    "right_row_count": right_count,
                    "right_unique_key_count": right_unique,
                    "fanout_ratio": fanout_ratio,
                    "orphan_rate": orphan_rate,
                    "coverage": coverage,
                    "cardinality": cardinality,
                    "left_null_key_count": int(row.get("LEFT_NULL_KEY_COUNT") or 0),
                    "right_null_key_count": int(row.get("RIGHT_NULL_KEY_COUNT") or 0),
                }
                if fanout_ratio > float(self._setting("migration_agent_join_max_fanout", 1.05)):
                    findings.append({
                        "category": "join_fanout",
                        "blocking": True,
                        "safe_summary": "A planned join amplifies the driving population beyond tolerance.",
                        "details": {"edge_id": edge_id, "fanout_ratio": fanout_ratio},
                    })
                if coverage < float(self._setting("migration_agent_join_min_coverage", 0.95)):
                    findings.append({
                        "category": "join_coverage",
                        "blocking": False,
                        "safe_summary": "A planned join does not cover the full left-side key population.",
                        "details": {"edge_id": edge_id, "coverage": coverage},
                    })
            except Exception as exc:
                findings.append({
                    "category": "relationship_reconciliation",
                    "blocking": True,
                    "safe_summary": "Join cardinality and coverage could not be verified.",
                    "details": {"edge_id": edge_id, "error_code": type(exc).__name__},
                })

        if selected:
            driving_key = next(iter(selected))
            visited: set[str] = set()
            pending = [driving_key]
            while pending:
                key = pending.pop()
                if key in visited:
                    continue
                visited.add(key)
                pending.extend(adjacency.get(key) or [])
            disconnected = sorted(set(selected) - visited)
            if disconnected:
                findings.append({
                    "category": "relationship_graph",
                    "blocking": True,
                    "safe_summary": "The prepared source graph contains tables disconnected from the driving source.",
                    "details": {"disconnected_tables": disconnected},
                })
        # A fan-out through a link table (ACTIVITIES -> ACTIVITIES_CONTACTS ->
        # CONTACTS) sets the output grain to one row per pair, which earlier
        # mappings of the same targets chose too. It is a grain decision for the
        # user, not a broken join; a duplicated lookup still blocks.
        if not self._setting("migration_agent_link_table_fanout_blocking", False):
            usage: dict[str, int] = {}
            for relationship in relationships:
                for table in (relationship.left_table, relationship.right_table):
                    usage[table.qualified_name.upper()] = usage.get(table.qualified_name.upper(), 0) + 1
            for finding in findings:
                if finding.get("category") != "join_fanout" or not finding.get("blocking"):
                    continue
                metric = metrics_by_edge.get(str((finding.get("details") or {}).get("edge_id") or "")) or {}
                index = metric.get("relationship_index")
                if index is None or index >= len(relationships) or metric.get("cardinality") != "one_to_many":
                    continue
                link = relationships[index].right_table
                if usage.get(link.qualified_name.upper(), 0) < 2:
                    continue
                finding.update({
                    "category": "join_grain", "blocking": False,
                    "safe_summary": (f"Joining through {link.table} gives one row per pair "
                                     f"({float(metric.get('fanout_ratio') or 0):.2f} rows per "
                                     f"{relationships[index].left_table.table} row). Keep that grain, or keep one row "
                                     f"per {relationships[index].left_table.table}?"),
                    "details": {**dict(finding.get("details") or {}), "link_table": link.qualified_name},
                })
        return relationships, findings, metrics_by_edge

    def _reduce_fanout_children(
        self,
        *,
        workspace: WorkbenchContextSnapshotV1,
        relationship_models: list[RelationshipContextItem],
        findings: list[dict[str, Any]],
    ) -> None:
        """Keep one child row per parent where a 1:N child would multiply the driving rows.

        Each join is measured from the side nearer the driving source. When the
        far side is a child with several rows per near-side key (addresses,
        e-mails, phones, link tables), it is joined through a one-row-per-key
        CTE so every driving row appears once. Rules that combine all child
        rows are rebuilt as aggregates over the full table (see
        ``_design_aggregate_cte``). A reduction is kept only when the join,
        measured again through the CTE, no longer fans out.
        """
        from app.agent_tools.cte_designer import dedup_order_columns, reduce_child

        if not workspace.driving_table:
            return
        max_fanout = float(self._setting("migration_agent_join_max_fanout", 1.05))
        driving = workspace.driving_table.qualified_name.upper()
        order: dict[str, int] = {driving: 0}
        frontier = [driving]
        while frontier:
            following = []
            for node in frontier:
                for relationship in relationship_models:
                    left, right = relationship.left_table.qualified_name.upper(), relationship.right_table.qualified_name.upper()
                    for here, there in ((left, right), (right, left)):
                        if here == node and there not in order:
                            order[there] = order[node] + 1
                            following.append(there)
            frontier = following
        reduced: dict[str, str] = {}
        for index, relationship in enumerate(relationship_models):
            child, parent = relationship.left_table, relationship.right_table
            child_key, parent_key = child.qualified_name.upper(), parent.qualified_name.upper()
            if (child_key == driving or child_key in reduced or child_key not in order or parent_key not in order
                    or order[child_key] <= order[parent_key] or relationship.normalized_lookup_alternative
                    or any(item.side != "left" for item in relationship.literal_filters)
                    or str(workspace.relationships[index].get("right_relation_override") or "")
                    or str(workspace.relationships[index].get("dedup_relation_id") or "")):
                continue
            filters = [{"column": item.column, "value": item.value} for item in relationship.literal_filters]
            parent_sql = self._quoted_table(parent)
            where = " AND ".join(f"C.{self._quoted_column(item['column'])} = {MappingSqlService._string_literal(item['value'])}"
                                 for item in filters)
            predicates = " AND ".join(
                f"C.{self._quoted_column(item.left_column)} = P.{self._quoted_column(item.right_column)}"
                for item in relationship.conditions
            )
            child_keys = [item.left_column for item in relationship.conditions]
            key_list = ", ".join(self._quoted_column(value) for value in child_keys)
            child_sql = (f"(SELECT C.* FROM {self._quoted_table(child)} AS C WHERE {where})"
                         if where else self._quoted_table(child))
            self._tool("source_preparation.reconcile_join")
            try:
                with self._domain_lock:
                    rows = self._session.sql(
                        f"SELECT (SELECT COUNT(*) FROM {parent_sql}) AS NEAR_ROWS, "
                        f"(SELECT COUNT(*) FROM {parent_sql} AS P LEFT JOIN {child_sql} AS C ON {predicates}) AS JOINED_ROWS, "
                        f"(SELECT COUNT(*) FROM {child_sql} AS C) AS CHILD_ROWS, "
                        f"(SELECT COUNT(DISTINCT HASH({key_list})) FROM {child_sql} AS C) AS CHILD_KEYS"
                    ).collect()
            except BudgetExceededError:
                raise
            except Exception:  # noqa: BLE001 - an unmeasured join is left as designed
                continue
            row = rows[0].as_dict() if rows and hasattr(rows[0], "as_dict") else (dict(rows[0]) if rows else {})
            near_rows = int(row.get("NEAR_ROWS") or 0)
            fanout = (int(row.get("JOINED_ROWS") or 0) / near_rows) if near_rows else 0.0
            if fanout <= max_fanout:
                continue
            contract = self._describe_table(child.qualified_name)
            try:
                derived = reduce_child(
                    table=child.model_dump(mode="json"), key_columns=child_keys,
                    order_columns=dedup_order_columns(contract, child_keys), filters=filters,
                    columns=[{"name": column.get("name"), "data_type": column.get("type")}
                             for column in contract.get("column_contracts") or []],
                    parent_name=parent.table, rows=int(row.get("CHILD_ROWS") or 0), keys=int(row.get("CHILD_KEYS") or 0),
                )
            except ValueError:
                continue
            self._tool("source_preparation.reconcile_join")
            try:
                with self._domain_lock:
                    after_rows = self._session.sql(
                        f"SELECT COUNT(*) AS JOINED_ROWS FROM {parent_sql} AS P LEFT JOIN (\n{derived['sql_text']}\n) AS C ON {predicates}"
                    ).collect()
            except BudgetExceededError:
                raise
            except Exception:  # noqa: BLE001 - keep the design unchanged when it cannot be re-measured
                continue
            after = after_rows[0].as_dict() if after_rows and hasattr(after_rows[0], "as_dict") else (dict(after_rows[0]) if after_rows else {})
            fanout_after = (int(after.get("JOINED_ROWS") or 0) / near_rows) if near_rows else 0.0
            if fanout_after > max_fanout:
                continue
            reduced[child_key] = derived["id"]
            workspace.derived_sources.append(WorkspaceDerivedSourceRef(
                id=derived["id"], name=derived["name"],
                sql_hash=hashlib.sha256(derived["sql_text"].encode("utf-8")).hexdigest(),
                lineage=[*derived["lineage"], {
                    "sql": derived["sql_text"], "source": "cte_designer", "origin": "agent",
                    "purpose": derived["purpose"], "grain": derived["grain"], "keys": derived["keys"],
                    "output_columns": derived["output_columns"], "base_source_tables": derived["base_source_tables"],
                }],
            ))
            findings.append({
                "category": "join_child_reduced",
                "blocking": False,
                "safe_summary": (
                    f"{child.table} has {int(row.get('CHILD_ROWS') or 0)} rows for "
                    f"{int(row.get('CHILD_KEYS') or 0)} {parent.table} keys and multiplied the rows {fanout:.2f}x. "
                    f"Each {parent.table} row now reads one {child.table} row through CTE {derived['name']} "
                    f"(fan-out {fanout_after:.2f}). Confirm which row should be kept, or map a combined value."
                ),
                "details": {"child_table": child.qualified_name, "parent_table": parent.qualified_name,
                            "derived_source_id": derived["id"], "fanout_before": fanout, "fanout_after": fanout_after},
            })
            self._emit(
                "trace.action.completed", "succeeded",
                f"Built CTE {derived['name']}: one {child.table} row per {parent.table} key; "
                f"fan-out {fanout:.2f} -> {fanout_after:.2f}.",
                trace_id=f"cte-child:{derived['id']}", parent_trace_id="source-preparation",
                kind="workflow", label="Design child CTE", details={"derived_source_id": derived["id"], "sql": derived["sql_text"]},
            )
        for index, relationship in enumerate(relationship_models):
            for side, table in (("left", relationship.left_table), ("right", relationship.right_table)):
                cte_id = reduced.get(table.qualified_name.upper())
                if cte_id:
                    workspace.relationships[index] = {**workspace.relationships[index], f"{side}_relation_override": cte_id}

    def _design_lookup_ctes(
        self,
        *,
        workspace: WorkbenchContextSnapshotV1,
        relationship_models: list[RelationshipContextItem],
        findings: list[dict[str, Any]],
        metrics: dict[str, Any],
    ) -> None:
        """Replace a lookup that multiplies the driving rows with a one-row-per-key CTE.

        Applies only when the fan-out comes from repeated keys on the lookup
        side, the lookup is used by that join alone and is not the driving
        table. The join is measured again through the CTE; the blocking
        finding is replaced by a review note only when the fan-out is gone.
        """
        from app.agent_tools.cte_designer import dedup_lookup, dedup_order_columns

        max_fanout = float(self._setting("migration_agent_join_max_fanout", 1.05))
        driving = workspace.driving_table.qualified_name.upper() if workspace.driving_table else ""
        usage: dict[str, int] = {}
        for relationship in relationship_models:
            for table in (relationship.left_table, relationship.right_table):
                usage[table.qualified_name.upper()] = usage.get(table.qualified_name.upper(), 0) + 1
        for finding in list(findings):
            if finding.get("category") != "join_fanout" or not finding.get("blocking"):
                continue
            edge_id = str((finding.get("details") or {}).get("edge_id") or "")
            metric = metrics.get(edge_id) or {}
            index = metric.get("relationship_index")
            if index is None or index >= len(relationship_models):
                continue
            relationship = relationship_models[index]
            lookup = relationship.right_table
            right_rows = int(metric.get("right_row_count") or 0)
            right_keys = int(metric.get("right_unique_key_count") or 0)
            non_null = right_rows - int(metric.get("right_null_key_count") or 0)
            if (right_keys >= non_null or relationship.normalized_lookup_alternative or relationship.literal_filters
                    or lookup.qualified_name.upper() == driving or usage.get(lookup.qualified_name.upper(), 0) != 1):
                continue
            contract = self._describe_table(lookup.qualified_name)
            keys = [condition.right_column for condition in relationship.conditions]
            try:
                derived = dedup_lookup(
                    table=lookup.model_dump(mode="json"),
                    key_columns=keys,
                    order_columns=dedup_order_columns(contract, keys),
                    columns=[{"name": column.get("name"), "data_type": column.get("type")}
                             for column in contract.get("column_contracts") or []],
                    duplicate_keys=max(0, non_null - right_keys),
                    total_rows=right_rows,
                )
            except ValueError:
                continue
            predicates = " AND ".join(
                f"L.{self._quoted_column(item.left_column)} {item.operator} R.{self._quoted_column(item.right_column)}"
                for item in relationship.conditions
            )
            left_table = self._quoted_table(relationship.left_table)
            self._tool("source_preparation.reconcile_join")
            try:
                with self._domain_lock:
                    rows = self._session.sql(
                        f"SELECT (SELECT COUNT(*) FROM {left_table}) AS LEFT_ROW_COUNT, "
                        f"(SELECT COUNT(*) FROM {left_table} AS L LEFT JOIN (\n{derived['sql_text']}\n) AS R "
                        f"ON {predicates}) AS JOINED_ROW_COUNT"
                    ).collect()
            except BudgetExceededError:
                raise
            except Exception:  # noqa: BLE001 - the original finding stands
                continue
            row = rows[0].as_dict() if rows and hasattr(rows[0], "as_dict") else (dict(rows[0]) if rows else {})
            left_count = int(row.get("LEFT_ROW_COUNT") or 0)
            fanout_after = (int(row.get("JOINED_ROW_COUNT") or 0) / left_count) if left_count else 0.0
            if fanout_after > max_fanout:
                continue
            workspace.derived_sources.append(WorkspaceDerivedSourceRef(
                id=derived["id"],
                name=derived["name"],
                sql_hash=hashlib.sha256(derived["sql_text"].encode("utf-8")).hexdigest(),
                lineage=[{
                    "sql": derived["sql_text"], "source": "cte_designer", "origin": "agent",
                    "purpose": derived["purpose"], "grain": derived["grain"], "keys": derived["keys"],
                    "output_columns": derived["output_columns"], "base_source_tables": derived["base_source_tables"],
                }],
            ))
            workspace.relationships[index] = {**workspace.relationships[index], "dedup_relation_id": derived["id"]}
            metric["fanout_ratio_after_dedup"] = fanout_after
            findings.remove(finding)
            findings.append({
                "category": "join_dedup_applied",
                "blocking": False,
                "safe_summary": (
                    f"{lookup.table} repeats {max(0, non_null - right_keys)} of its keys, which multiplied the "
                    f"driving rows {float(metric.get('fanout_ratio') or 0):.2f}x. The join now uses CTE "
                    f"{derived['name']} (one row per {', '.join(keys)}); the fan-out is {fanout_after:.2f}. "
                    "Confirm the kept row is the right one, or choose how duplicates should combine."
                ),
                "details": {"edge_id": edge_id, "derived_source_id": derived["id"], "lookup_table": lookup.qualified_name,
                            "fanout_before": metric.get("fanout_ratio"), "fanout_after": fanout_after,
                            "order_by": dedup_order_columns(contract, keys)},
            })
            self._emit(
                "trace.action.completed", "succeeded",
                f"Built CTE {derived['name']}: one {lookup.table} row per {', '.join(keys)}; "
                f"fan-out {float(metric.get('fanout_ratio') or 0):.2f} -> {fanout_after:.2f}.",
                trace_id=f"cte-dedup:{edge_id}:{derived['id']}", parent_trace_id="source-preparation",
                kind="workflow", label="Design lookup CTE",
                details={"derived_source_id": derived["id"], "sql": derived["sql_text"]},
            )

    def _save_planned_derived_source(self, definition: DerivedSourceDefinition):
        """Reuse an identical visible CTE without replacing its definition."""
        approved = {table.qualified_name.upper() for table in definition.source_tables}
        canonical_sql = parse_one(definition.sql_text, read="snowflake").sql(dialect="snowflake")
        for existing in self._derived_sources.list_sources(project_id=definition.project_id):
            if existing.derived_source_name.upper() != definition.derived_source_name.upper():
                continue
            if existing.project_id and str(existing.project_id) != str(definition.project_id):
                continue
            sources = {table.qualified_name.upper() for table in existing.source_tables}
            if not sources or not sources.issubset(approved):
                continue
            try:
                same_sql = parse_one(existing.sql_text, read="snowflake").sql(dialect="snowflake") == canonical_sql
            except Exception:
                same_sql = False
            if same_sql:
                return existing
        return self._derived_sources.save_source(definition, materialize=False)

    def prepare_sources(self, state: dict[str, Any]) -> dict[str, Any]:
        """Validate and persist each mapping's source design independently."""
        plan = MigrationPlanArtifactV1.model_validate(state.get("migration_plan") or {})
        if plan.plan_hash != state.get("approved_plan_hash"):
            raise PermissionError("The source-preparation plan is not approved")
        specs = {spec.mapping_key: spec for spec in plan.mapping_specs}
        packages, diagnostics, receipts = {}, {}, []
        progress = getattr(self, "progress", None)
        if progress is not None:
            progress.plan_targets([str(m["target_table"]) for m in state.get("manifest") or []])
        for mapping in state.get("manifest") or []:
            key = mapping["mapping_key"]
            spec = specs[key].source_preparation if key in specs else plan.source_preparation
            # Target identity comes from the approved manifest, never a preceding mapping.
            spec = spec.model_copy(update={"target_table": mapping["target_table"]})
            if progress is not None:
                progress.set_phase(str(mapping["target_table"]), "preparing")
            result = self._prepare_mapping_sources({**state, "manifest": [mapping]}, spec)
            packages[key] = result["mapping_context_package"]
            diagnostics[key] = result["source_preparation_result"]
            receipts.extend(diagnostics[key].get("receipts") or [])
            self._sources_milestone(mapping["target_table"], packages[key], diagnostics[key])
        unresolved = [f"{key}:{issue}" for key, value in diagnostics.items() for issue in value.get("unresolved", [])]
        blocked_keys = [key for key, value in diagnostics.items() if value.get("unresolved")]
        # One mapping's risky-join or data-quality finding must not stop a
        # sibling mapping's clean, independently-verified source design from
        # reaching Auto Map. Only when every mapping in the batch is blocked
        # does the whole run-owned draft need a revised plan.
        all_blocked = bool(blocked_keys) and len(blocked_keys) == len(diagnostics)
        return {
            "mapping_context_packages": packages,
            "source_preparation_result": {
                "status": "needs_input" if all_blocked else "succeeded",
                "unresolved": unresolved, "mappings": diagnostics, "receipts": receipts,
                "blocked_mapping_keys": [] if all_blocked else blocked_keys,
            },
        }

    def _prepare_mapping_sources(self, state: dict[str, Any], spec) -> dict[str, Any]:
        """Persist the approved source-preparation state before Auto Map.

        This deliberately consumes the same canonical Workbench snapshot used by
        the interactive builder. It does not invent joins or call semantic
        generation; incomplete multi-source joins remain a blocking ambiguity.
        """
        plan = MigrationPlanArtifactV1.model_validate(state.get("migration_plan") or {})
        if plan.plan_hash != state.get("approved_plan_hash"):
            raise PermissionError("The source-preparation plan is not approved")
        context = MappingContextPackageV1.model_validate(state.get("mapping_context_package") or {})
        workspace = context.workspace.model_copy(deep=True)
        planned_sources = [
            value
            for value in [spec.driving_source, *spec.supporting_sources]
            if value
        ]
        if planned_sources:
            planned_refs = [
                ref for value in planned_sources if (ref := self._table_ref(value)) is not None
            ]
            if len(planned_refs) != len(planned_sources):
                raise ValueError("The approved source-preparation plan contains an invalid table name")
            allowed_schemas = {str(value).strip('"').upper() for value in state.get("authorized_schemas") or []}
            allowed_tables = {
                str(value).strip('"').upper()
                for value in [
                    *(state.get("authorized_source_scope") or []),
                    *(state.get("discovered_catalog_tables") or []),
                ]
            }
            unauthorized = [
                ref.qualified_name
                for ref in planned_refs
                if ref.qualified_name.upper() not in allowed_tables
                and f"{ref.database}.{ref.schema}".upper() not in allowed_schemas
            ]
            if unauthorized:
                raise PermissionError(
                    "The approved plan references source tables outside the caller's authorized scope: "
                    + ", ".join(unauthorized)
                )
            workspace.source_tables = planned_refs
            workspace.driving_table = self._table_ref(spec.driving_source)
        source_tables = [table.qualified_name for table in workspace.source_tables]
        if not source_tables:
            source_tables = [str(value) for value in state.get("authorized_source_scope") or []]
            workspace.source_tables = [
                ref for value in source_tables if (ref := self._table_ref(value)) is not None
            ]
        if workspace.driving_table is None and len(workspace.source_tables) == 1:
            workspace.driving_table = workspace.source_tables[0]
        if spec.selected_columns_by_table:
            workspace.selected_columns_by_table = spec.selected_columns_by_table
        workspace.relationships = spec.relationships
        if spec.value_bindings:
            graph = dict(workspace.relation_graph or {})
            graph["value_bindings"] = [
                {
                    "binding_id": f"plan_value:{binding.name}",
                    "value": binding.placeholder,
                    "resolved_value": binding.resolved_value,
                    "data_type": binding.data_type,
                    "attribute_name": binding.name,
                    "is_placeholder": True,
                    "allow_project_specific_value": True,
                    "resolution_status": "resolved" if binding.resolution_status == "resolved" else "unresolved",
                    "provenance": binding.source,
                    "evidence_ids": binding.evidence_ids,
                }
                for binding in spec.value_bindings
            ]
            workspace.relation_graph = graph
        workspace.derived_sources = []
        if spec.derived_sources:
            normalized_derived: list[WorkspaceDerivedSourceRef] = []
            for index, value in enumerate(spec.derived_sources):
                candidate = dict(value)
                sql = str(candidate.get("sql") or candidate.get("sql_outline") or "").strip()
                candidate.setdefault(
                    "id",
                    "agent_cte_" + hashlib.sha256(
                        f"{plan.plan_hash}:{index}:{candidate.get('name') or sql}".encode("utf-8")
                    ).hexdigest()[:24],
                )
                candidate.setdefault("name", f"Agent CTE {index + 1}")
                if sql:
                    candidate.setdefault("sql_hash", hashlib.sha256(sql.encode("utf-8")).hexdigest())
                    candidate["lineage"] = [
                        *list(candidate.get("lineage") or []),
                        {"sql": sql, "source": "approved_plan", "plan_hash": plan.plan_hash},
                    ]
                # Older saved plans may carry a provider spelling of the flag.
                # Normalize on execution as well as new plan submission.
                if "is_driving_source" not in candidate:
                    for alias in ("is_driving", "used_as_driving_source", "use_as_driving_source"):
                        if alias in candidate:
                            candidate["is_driving_source"] = candidate[alias]
                            break
                normalized_derived.append(WorkspaceDerivedSourceRef.model_validate(candidate))
            workspace.derived_sources = normalized_derived
            requested_drivers = [item.id for item in normalized_derived if getattr(item, "is_driving_source", False) is True]
            if len(requested_drivers) > 1:
                raise ValueError("The plan names multiple driving CTEs")
            if requested_drivers:
                workspace.driving_relation_id = requested_drivers[0]
        filter_payload = dict(spec.filters)
        if spec.grouping and not filter_payload.get("group_by_sql"):
            filter_payload["group_by_sql"] = ", ".join(spec.grouping)
        if spec.sorting and not filter_payload.get("order_by_sql"):
            filter_payload["order_by_sql"] = ", ".join(spec.sorting)
        if spec.aggregation:
            filter_payload["groups"] = [
                *list(filter_payload.get("groups") or []),
                {"kind": "aggregation", "items": spec.aggregation},
            ]
        workspace.filters = WorkspaceFilterState.model_validate(filter_payload)
        if spec.target_table:
            target_ref = self._table_ref(spec.target_table)
            if target_ref is None:
                raise ValueError("The approved source-preparation plan contains an invalid target table")
            authorized_targets = {
                str(value).strip('"').upper()
                for value in state.get("authorized_target_scope") or []
            }
            if authorized_targets and target_ref.qualified_name.upper() not in authorized_targets:
                raise PermissionError("The approved target table is outside the run's authorized target scope")
            workspace.target_table = target_ref
        semantic_reference = context.stored_semantic_context
        if workspace.source_tables and workspace.target_table and self._semantic_context is not None:
            try:
                self._tool("semantic_context.prepare_mapping_projection")
                with self._domain_lock:
                    semantic_bundle, semantic_projection = self._resolve_semantic_bundle(
                        workspace=workspace
                    )
                semantic_reference = semantic_reference.model_copy(update={
                    "status": (
                        "partial"
                        if semantic_bundle.status in {
                            SemanticBundleStatus.PARTIAL,
                            SemanticBundleStatus.FAILED,
                        }
                        else "available"
                    ),
                    "bundle_id": semantic_bundle.bundle_id,
                    "bundle_hash": semantic_bundle.bundle_hash,
                    "semantic_view_name": semantic_bundle.semantic_view_name,
                    "composed_model_hash": semantic_bundle.summary.composed_model_hash,
                    "provenance": ["SemanticContextService:stored_registry"],
                    "covered_tables": list(semantic_bundle.summary.tables),
                    "projection_id": semantic_projection["projection_id"],
                    "projection_hash": semantic_projection["projection_hash"],
                    "mapping_projection": semantic_projection["payload"],
                    "reading_instructions": (
                        semantic_bundle.reading_instructions.model_dump(mode="json")
                        if semantic_bundle.reading_instructions else {}
                    ),
                })
            except Exception as exc:
                if isinstance(exc, SemanticAssetNotFoundError):
                    partial = self.read_stored_semantic_context(
                        state,
                        source_tables=[table.qualified_name for table in workspace.source_tables],
                        target_table=workspace.target_table.qualified_name,
                        relationships=list(workspace.relationships),
                    )
                    partial_tables = list(partial.data.get("covered_tables") or [])
                    if partial_tables:
                        semantic_reference = semantic_reference.model_copy(update={
                            "status": "partial",
                            "covered_tables": partial_tables,
                            "provenance": ["WorkbenchSemanticKnowledgeResolver:stored_registry"],
                            "mapping_projection": dict(partial.data.get("semantic_context") or {}),
                        })
                preparation_findings = [{
                    "category": "semantic_context",
                    "blocking": False,
                    "safe_summary": "Stored semantic context did not cover the complete prepared source graph.",
                    "details": {"error_code": type(exc).__name__},
                }]
            else:
                preparation_findings = []
        else:
            preparation_findings = []
        from app.agent_runs.policy import policy_from_state
        policy = policy_from_state(state)
        accepted_precedent: dict[str, Any] = {}
        reference = spec.precedent_reference
        if reference:
            self._tool("project.verify_completed_precedent")
            with self._domain_lock:
                detail = self._projects.get_sttm_detail(str(reference.get("sttm_id") or ""))
            precedent_sql = str(
                (detail.latest_snapshot or {}).get("mapping_sql")
                or (detail.latest_snapshot or {}).get("raw_mapping_sql")
                or ""
            ) if detail else ""
            try:
                if not detail or str(detail.sttm.status).upper() != reference.get("status"):
                    raise ValueError("The precedent status changed after planning")
                if str(detail.sttm.target_table or "").upper() != workspace.target_table.qualified_name.upper():
                    raise ValueError("The precedent target has changed")
                if hashlib.sha256(precedent_sql.strip().encode("utf-8")).hexdigest() != reference.get("sql_sha256"):
                    raise ValueError("The precedent SQL revision has changed")
                contract = self._describe_table(workspace.target_table.qualified_name)
                scoped = _scoped_precedent_query(
                    precedent_sql,
                    allowed_sources=[table.qualified_name for table in workspace.source_tables],
                    target_columns=list(contract["columns"]),
                )
                accepted_precedent = {
                    "sttm_id": str(detail.sttm.sttm_id),
                    "status": str(detail.sttm.status).upper(),
                    "sql_sha256": scoped["sql_sha256"],
                    "active_ctes": scoped["active_ctes"],
                    "physical_sources": scoped["physical_sources"],
                }
            except (ValueError, TypeError, KeyError) as exc:
                preparation_findings.append({
                    "category": "precedent_contract",
                    "blocking": True,
                    "safe_summary": "The historical mapping no longer matches the current authorized source and target contracts.",
                    "details": {"error_code": type(exc).__name__},
                })
        if accepted_precedent:
            # The accepted SQL is a scoped CTE query. The legacy snapshot's
            # physical relationships are evidence from inside those scopes,
            # not edges in the final query. Do not apply raw-table fanout or
            # connectivity checks to a different graph.
            relationship_models, relationship_findings, relationship_metrics = [], [], {}
            workspace.relationships = []
            workspace.derived_sources = []
        else:
            relationship_models, relationship_findings, relationship_metrics = (
                self._validate_source_relationships(
                    state=state,
                    source_tables=workspace.source_tables,
                    raw_relationships=list(workspace.relationships),
                    reconcile=(policy.validation_depth == "reconcile"
                               or bool(self._setting("migration_agent_join_cardinality_check", True))
                               or any(
                        str(item.get("trust_state") or "").endswith("_cardinality_pending")
                        for item in workspace.relationships
                    )),
                )
            )
        preparation_findings.extend(relationship_findings)
        workspace.relationships = [
            relationship.model_dump(mode="json") for relationship in relationship_models
        ]
        if not accepted_precedent and self._setting("migration_agent_cte_designer_enabled", True):
            self._design_lookup_ctes(
                workspace=workspace,
                relationship_models=relationship_models,
                findings=preparation_findings,
                metrics=relationship_metrics,
            )
            self._reduce_fanout_children(
                workspace=workspace,
                relationship_models=relationship_models,
                findings=preparation_findings,
            )
        preparation_receipts: list[dict[str, Any]] = []
        if workspace.derived_sources:
            if self._derived_sources is None:
                preparation_findings.append({
                    "category": "derived_source_validation",
                    "blocking": True,
                    "safe_summary": "Derived-source validation is unavailable in this worker.",
                    "details": {},
                })
            else:
                persisted_refs: list[WorkspaceDerivedSourceRef] = []
                for derived in workspace.derived_sources:
                    sql = str(
                        next(
                            (
                                item.get("sql")
                                for item in reversed(derived.lineage)
                                if isinstance(item, dict) and item.get("sql")
                            ),
                            "",
                        )
                    ).strip()
                    if not sql:
                        preparation_findings.append({
                            "category": "derived_source_contract",
                            "blocking": True,
                            "safe_summary": "A planned derived source has no executable SQL.",
                            "details": {"derived_source_id": derived.id},
                        })
                        persisted_refs.append(derived)
                        continue
                    definition = DerivedSourceDefinition(
                        derived_source_id=derived.id,
                        derived_source_name=derived.name or derived.id,
                        sql_text=sql,
                        source_tables=workspace.source_tables,
                        driving_table=workspace.driving_table,
                        relationships=relationship_models,
                        filters=[workspace.filters.model_dump(mode="json")],
                        selected_columns_by_table=(
                            derived.selected_columns_by_table
                            or workspace.selected_columns_by_table
                        ),
                        purpose="Approved Deep Agent source-preparation plan",
                        business_description=str(state.get("prompt") or "")[:2_000],
                        grain=spec.intended_grain,
                        generated_by_request_id=str(state.get("run_id") or ""),
                        project_id=str(state.get("project_id") or "") or None,
                        sttm_id=str(mapping_manifest[0].get("sttm_id") or "") if (mapping_manifest := state.get("manifest") or []) else None,
                    )
                    self._tool("derived_source.validate_and_save")
                    derived_phase = "validation"
                    try:
                        with self._domain_lock:
                            receipt = self._commands.execute(
                                self._command(
                                    state,
                                    "derived_source.save_draft",
                                    derived.id,
                                    definition.model_dump(mode="json"),
                                    project_id=str(state.get("project_id") or "") or None,
                                ),
                                lambda definition=definition: self._save_planned_derived_source(definition),
                            )
                        record = dict(receipt.result)
                        if workspace.driving_relation_id == derived.id:
                            workspace.driving_relation_id = str(record.get("derived_source_id") or derived.id)
                        preparation_receipts.append(receipt.model_dump(mode="json"))
                        derived_phase = "materialization"
                        # The secure-view procedure executes DDL in its own
                        # transaction scope. Run it only after the definition
                        # and command receipt commit, so a retry can recover
                        # from a failed materialization without duplicating
                        # the definition write.
                        materialization = self._derived_sources.materialize_source(
                            str(record.get("derived_source_id") or derived.id)
                        )
                        preview_columns = list(record.get("preview_columns") or [])
                        persisted_refs.append(WorkspaceDerivedSourceRef(
                            id=str(record.get("derived_source_id") or derived.id),
                            name=str(record.get("derived_source_name") or derived.name or derived.id),
                            sql_hash=hashlib.sha256(sql.encode("utf-8")).hexdigest(),
                            selected_columns_by_table=(
                                record.get("selected_columns_by_table")
                                or derived.selected_columns_by_table
                            ),
                            lineage=[
                                *derived.lineage,
                                {
                                    "source": "validated_derived_source",
                                    "plan_hash": plan.plan_hash,
                                    "physical_view_name": materialization.get("physical_view_name"),
                                    "output_columns": preview_columns,
                                    "base_source_tables": record.get("base_source_tables") or [],
                                },
                            ],
                        ))
                    except Exception as exc:
                        preparation_findings.append({
                            "category": f"derived_source_{derived_phase}",
                            "blocking": True,
                            "safe_summary": "A planned derived source could not be validated or materialized.",
                            "details": {
                                "derived_source_id": derived.id,
                                "error_code": type(exc).__name__,
                            },
                        })
                        persisted_refs.append(derived)
                workspace.derived_sources = persisted_refs
        unresolved: list[str] = list(spec.unresolved_items)
        if not workspace.driving_table:
            unresolved.append("driving_source")
        if len(workspace.source_tables) > 1 and not workspace.relationships and not accepted_precedent:
            unresolved.append("join_definitions")
        for derived in workspace.derived_sources:
            sql = str(
                next(
                    (
                        item.get("sql")
                        for item in derived.lineage
                        if isinstance(item, dict) and item.get("sql")
                    ),
                    "",
                )
            ).strip()
            if sql and not re.match(r"^(?:SELECT|WITH)\b", sql, flags=re.IGNORECASE):
                unresolved.append(f"derived_source:{derived.id}:invalid_sql")
        unresolved.extend(
            f"{finding.get('category')}:{index + 1}"
            for index, finding in enumerate(preparation_findings)
            if finding.get("blocking", True)
        )
        self._emit(
            "source_preparation.started",
            "running",
            "Applying the approved source-preparation plan to the run-owned draft.",
            trace_id="source-preparation",
            parent_trace_id=None,
            kind="workflow",
            label="Prepare sources",
            details={"plan_hash": plan.plan_hash, "source_count": len(source_tables)},
        )
        updated_context = MappingContextPackageV1.model_validate({
            **context.model_dump(mode="json", exclude={"context_hash"}),
            "workspace": workspace.model_dump(mode="json", exclude={"context_hash"}),
            "stored_semantic_context": semantic_reference.model_dump(mode="json"),
        })
        receipts: list[dict[str, Any]] = list(preparation_receipts)
        for mapping in state.get("manifest") or []:
            sttm_id = str(mapping.get("sttm_id") or "")
            if not sttm_id:
                continue
            target = self._table_ref(str(mapping.get("target_table") or ""))
            workspace_payload = workspace.model_dump(mode="json")
            prepared_tables = [table.qualified_name for table in workspace.source_tables]
            try:
                snapshot = self._draft_snapshot(
                    state=state,
                    mapping={**mapping, "sttm_id": sttm_id},
                    target_table=target.qualified_name if target else str(mapping.get("target_table") or ""),
                    source_tables=prepared_tables,
                    source_columns={table: list(self._contract_cache_columns(table)) for table in prepared_tables},
                    rows=[],
                    context_workspace=workspace_payload,
                    design=None,
                    sql_validation={},
                    receipt=None,
                    workspace=workspace,
                    page="builder",
                    surface="SOURCE_SELECTION",
                )
            except ValueError:
                # No driving relation yet: the design is blocked and reported
                # below; save what was prepared so the review can show it.
                snapshot = {**workspace_payload, "page": "builder", "surface": "SOURCE_SELECTION",
                            "source_design_hash": self._source_design_hash(workspace_payload, target)}
            snapshot.update({
                "project_id": str(state.get("project_id") or ""),
                "sttm_id": sttm_id,
                "target_table": target.model_dump(mode="json") if target else snapshot.get("target_table"),
            })
            # A replica may replay source preparation after a mapping write but
            # before the graph checkpoint commits. Never replace that run's
            # mapped rows with the earlier empty source snapshot when the
            # source design is identical. A changed design still invalidates
            # the old rows through the normal autosave path.
            with self._domain_lock:
                previous = self._projects.get_sttm_detail(sttm_id)
            previous_snapshot = dict(previous.latest_snapshot or {}) if previous else {}
            if (
                previous and str(previous.sttm.metadata.get("migration_run_id") or "")
                in {str(state["run_id"]), *map(str, state.get("run_lineage") or [])}
                and previous_snapshot.get("mapping_rows")
                and previous_snapshot.get("source_design_hash") == snapshot["source_design_hash"]
            ):
                self._emit(
                    "source_preparation.reused", "succeeded",
                    "The run-owned source design and saved mapping rows were preserved during replay.",
                    trace_id=f"source-preparation-reused:{sttm_id}", kind="workflow",
                    label="Reuse prepared sources",
                )
                continue
            payload = {
                "workspace_snapshot": snapshot,
                "action": "migration_agent.source_preparation_saved",
                "session_id": str(state["run_id"]),
                "thread_id": str(state["run_id"]),
                "agent_artifacts": [{
                    "type": "source_preparation",
                    "plan_hash": plan.plan_hash,
                    "context_hash": updated_context.context_hash,
                    "semantic_status": updated_context.stored_semantic_context.status,
                }],
            }
            self._tool("sttm.autosave_source_preparation")
            with self._domain_lock:
                record = self._projects.get_sttm_record(sttm_id)
                expected_revision = int(record.current_version or 0) if record else None
                receipt = self._commands.execute(
                    self._command(
                        state,
                        "sttm.autosave_source_preparation",
                        f"sttm:{sttm_id}",
                        payload,
                        project_id=str(state.get("project_id") or ""),
                        sttm_id=sttm_id,
                        expected_revision=expected_revision,
                    ),
                    lambda sttm_id=sttm_id, payload=payload: self._projects.autosave_sttm(
                        sttm_id,
                        STTMAutosaveRequest.model_validate(payload),
                        user_id=self._actor(state).user_id,
                    ),
                    current_revision=lambda sttm_id=sttm_id: (
                        int(current.current_version or 0)
                        if (current := self._projects.get_sttm_record(sttm_id)) else None
                    ),
                )
            receipts.append(receipt.model_dump(mode="json"))
        result_status = "needs_input" if unresolved else "succeeded"
        self._emit(
            "source_preparation.completed",
            "needs_review" if unresolved else "succeeded",
            (
                "Source preparation requires a researched clarification before Auto Map."
                if unresolved
                else "The approved source-preparation snapshot is ready for Auto Map."
            ),
            trace_id="source-preparation",
            parent_trace_id=None,
            kind="workflow",
            label="Prepare sources",
            details={
                "unresolved": unresolved,
                "validation_findings": preparation_findings,
                "relationship_metrics": relationship_metrics,
                "context_hash": updated_context.context_hash,
                "receipt_count": len(receipts),
            },
        )
        return {
            "mapping_context_package": updated_context.model_dump(mode="json"),
            "authorized_source_scope": source_tables,
            "source_preparation_result": {
                "status": result_status,
                "unresolved": unresolved,
                "source_tables": source_tables,
                "driving_source": workspace.driving_table.qualified_name if workspace.driving_table else None,
                "relationship_count": len(workspace.relationships),
                "derived_source_count": len(workspace.derived_sources),
                "validation_findings": preparation_findings,
                "relationship_metrics": relationship_metrics,
                "semantic_status": updated_context.stored_semantic_context.status,
                "context_hash": updated_context.context_hash,
                "receipts": receipts,
                "accepted_precedent": accepted_precedent,
            }
        }

    def _describe_table(self, fqn: str) -> dict[str, Any]:
        key = normalize_fqn(fqn)
        contract = self._describe_tables([fqn]).get(key)
        if contract is None:
            raise TableContractUnavailable(f"{fqn} does not exist or is not visible to the current role.")
        return contract

    def _describe_tables(self, fqns: list[str]) -> dict[str, dict[str, Any]]:
        """Return current contracts for ``fqns`` with the fewest catalog reads.

        With a knowledge store, contracts verified earlier in the conversation
        are confirmed by one batched signature check (or trusted within the
        recheck window) instead of being described again. Everything else is
        described once and recorded for the rest of the conversation.
        """
        requested = list(dict.fromkeys(normalize_fqn(value) for value in fqns if str(value or "").strip()))
        for value in requested:
            split_fqn(value)
        if self._knowledge is not None:
            self._knowledge.ensure_verified(requested, reader=self._catalog_signatures)
        found: dict[str, dict[str, Any]] = {}
        missing: list[str] = []
        with self._domain_lock:
            for key in requested:
                contract = (self._knowledge.contract(key) if self._knowledge is not None
                            else self._contract_cache.get(key))
                if contract is None:
                    missing.append(key)
                else:
                    found[key] = contract
        if not missing:
            return found
        read = self._read_contract_batch(missing)
        with self._domain_lock:
            if self._knowledge is not None:
                self._knowledge.record_contracts(read, source="desc_table")
            else:
                self._contract_cache.update(read)
        found.update(read)
        return found

    def _read_contract_batch(self, tables: list[str]) -> dict[str, dict[str, Any]]:
        """Describe ``tables`` under one trace span; invisible tables are absent."""
        self._tool("snowflake.describe_table")
        single = len(tables) == 1
        trace_id = f"describe:{tables[0]}" if single else f"describe-batch:{uuid4().hex}"
        label = "Read table contract" if single else "Read table contracts"
        details = {"tables": tables, "query": "DESC TABLE"}
        self._emit(
            "trace.action.started", "running",
            f"Reading the contract for {tables[0]}." if single else f"Reading the contracts for {len(tables)} tables.",
            trace_id=trace_id, parent_trace_id="mapping-execution", kind="query", label=label, details=details,
        )
        with self._domain_lock:
            read = read_contracts(self._session.sql, tables)
        column_count = sum(len(contract["columns"]) for contract in read.values())
        self._emit(
            "trace.action.completed", "succeeded" if read else "failed",
            f"Read {column_count} columns from {tables[0]}." if single
            else f"Read {column_count} columns from {len(read)} of {len(tables)} tables.",
            trace_id=trace_id, parent_trace_id="mapping-execution", kind="query", label=label,
            details={**details, "row_count": column_count, "unavailable": sorted(set(tables) - set(read))},
        )
        return read

    def _catalog_signatures(self, tables: list[str]) -> dict[str, str]:
        """Confirm stored contracts with one set-based query per database."""
        self._tool("snowflake.confirm_contracts")
        trace_id = f"confirm-contracts:{uuid4().hex}"
        label = "Confirm stored contracts"
        self._emit(
            "trace.action.started", "running",
            f"Confirming {len(tables)} table contracts verified earlier in this conversation.",
            trace_id=trace_id, parent_trace_id="mapping-execution", kind="query", label=label,
            details={"tables": tables, "query": "INFORMATION_SCHEMA.COLUMNS signature"},
        )
        with self._domain_lock:
            signatures = catalog_signatures(self._session.sql, tables)
        self._emit(
            "trace.action.completed", "succeeded",
            f"Confirmed the current catalog state of {len(tables)} stored table contracts.",
            trace_id=trace_id, parent_trace_id="mapping-execution", kind="query", label=label,
            details={"tables": tables, "visible": len(signatures)},
        )
        return signatures

    def attach_knowledge_reader(self) -> None:
        """Let registry-level reuse confirm stored contracts through this adapter.

        Only the run's primary adapter is attached; partition adapters confirm
        through their own leased sessions inside ``_describe_tables``.
        """
        if self._knowledge is not None:
            self._knowledge.set_signature_reader(self._catalog_signatures)

    def _setting(self, name: str, default: Any) -> Any:
        return getattr(self._settings, name, default) if self._settings is not None else default

    def discover_relationship_graph(
        self,
        source_tables: list[str],
        visible_tables: list[str],
        external: list[tuple[str, dict[str, Any]]],
    ) -> dict[str, Any] | None:
        """Generate, verify and score join candidates around the selected sources.

        The universe is every caller-visible table in the selected sources'
        schemas (bounded by configuration). Candidates come from current
        contracts (``<STEM>_ID`` rule, polymorphic ``<X>_ID``/``<X>_TYPE``) plus
        ``external`` evidence; each is verified against the data and given a
        confidence among the competing parents of the same column.
        """
        from app.agent_runtime.run_knowledge import RELATIONSHIP
        from app.agent_tools import relationship_graph as graph

        if not self._setting("migration_agent_relationship_graph_enabled", True) or not source_tables:
            return None
        selected = [normalize_fqn(value) for value in source_tables]
        schemas = {value.rsplit(".", 1)[0] for value in selected}
        limit = int(self._setting("migration_agent_relationship_universe_limit", 80))
        neighbours = sorted(value for value in {normalize_fqn(item) for item in visible_tables}
                            if value.rsplit(".", 1)[0] in schemas and value not in selected)
        # Inspect the requested graph first. If its current key evidence
        # already connects every selected source, unrelated schema neighbours
        # cannot be required to establish that requested join path.
        selected_contracts = self._describe_tables(selected)
        selected_edges = graph.fk_name_candidates(selected_contracts, self._type_family)
        graph.merge_external(selected_edges, external, selected_contracts)
        connected = {selected[0]} if selected else set()
        for _ in selected:
            for edge in selected_edges:
                if {edge.child_table, edge.parent_table} & connected:
                    connected.update((edge.child_table, edge.parent_table))
        if set(selected) <= connected:
            neighbours = []
        universe = [*selected, *neighbours][:max(limit, len(selected))]
        truncated = len(selected) + len(neighbours) > len(universe)
        contracts = selected_contracts if not neighbours else self._describe_tables(universe)
        edges = graph.fk_name_candidates(contracts, self._type_family)

        slots = graph.polymorphic_slots(contracts)
        type_values: dict[tuple[str, str], list[str]] = {}
        pending_slots = []
        for table, id_column, type_column in slots:
            cached = self._knowledge.get(RELATIONSHIP, f"types:{table}.{type_column}") if self._knowledge else None
            if cached is not None:
                type_values[(table, type_column)] = list(cached.get("values") or [])
            else:
                pending_slots.append((table, id_column, type_column))
        queries = 0
        if pending_slots:
            self._tool("snowflake.relationship_type_values")
            with self._domain_lock:
                fresh = graph.polymorphic_type_values(
                    self._session.sql, pending_slots,
                    limit=int(self._setting("migration_agent_relationship_type_value_limit", 20)))
            queries += len(pending_slots)
            type_values.update(fresh)
            if self._knowledge is not None:
                self._knowledge.put_many(RELATIONSHIP, [
                    (f"types:{table}.{column}", {"values": values}, [table]) for (table, column), values in fresh.items()
                ])
        edges += graph.polymorphic_candidates(slots, type_values, contracts)
        external = [*external, *self._relationship_learning_claims(contracts)]
        graph.merge_external(edges, external, contracts)

        # Versioned: the verification metrics define how confidence is computed.
        verify_key = "verify:v2:"
        pending = []
        for edge in edges:
            cached = self._knowledge.get(RELATIONSHIP, f"{verify_key}{edge.key}") if self._knowledge else None
            if cached is not None:
                edge.verification = dict(cached)
            else:
                pending.append(edge)
        if pending:
            trace_id = f"relationship-verify:{uuid4().hex}"
            self._emit("trace.action.started", "running",
                       f"Verifying {len(pending)} join candidate(s) against the current data.",
                       trace_id=trace_id, parent_trace_id="mapping-execution", kind="query",
                       label="Verify join candidates", details={"candidates": len(pending)})
            self._tool("snowflake.relationship_verify")
            with self._domain_lock:
                queries += graph.verify_edges(
                    self._session.sql, pending,
                    sample_limit=int(self._setting("migration_agent_relationship_sample_values", 5000)),
                    min_child_values=int(self._setting("migration_agent_relationship_min_child_values", 1)),
                    batch_size=int(self._setting("migration_agent_relationship_verify_batch", 25)),
                )
            self._emit("trace.action.completed", "succeeded",
                       f"Verified {len(pending)} join candidate(s) in {queries} query(ies).",
                       trace_id=trace_id, parent_trace_id="mapping-execution", kind="query",
                       label="Verify join candidates",
                       details={"candidates": len(pending), "verified": sum(edge.verified for edge in pending)})
            if self._knowledge is not None:
                self._knowledge.put_many(RELATIONSHIP, [
                    (f"{verify_key}{edge.key}", dict(edge.verification or {}), [edge.child_table, edge.parent_table])
                    for edge in pending if edge.verification is not None
                ])

        def overrides(name: str) -> dict[str, float]:
            raw = str(self._setting(name, "") or "").strip()
            return {str(key): float(value) for key, value in json.loads(raw).items()} if raw else {}

        graph.score_edges(
            edges,
            name_priors=overrides("migration_agent_relationship_name_priors_json"),
            evidence_weights=overrides("migration_agent_relationship_evidence_weights_json"),
            orphan_sensitivity=float(self._setting("migration_agent_relationship_orphan_sensitivity", 20.0)),
            duplicate_parent_penalty=float(self._setting("migration_agent_relationship_duplicate_parent_penalty", 0.5)),
            chance_floor=float(self._setting("migration_agent_relationship_chance_floor", 0.05)),
        )
        confidence, margin = self.decision_thresholds()
        min_coverage = float(self._setting("migration_agent_relationship_min_auto_coverage", 0.9))
        serialized = []
        for edge in sorted(graph.without_subsumed_unfiltered(edges),
                           key=lambda item: (item.child_table, item.child_column, -item.confidence)):
            if edge.verification is not None and not edge.verified:
                continue  # verified absence of any overlap is not a candidate
            relationship = edge.to_relationship()
            relationship["name_rule"] = edge.name_rule
            relationship["auto_resolvable"] = graph.auto_resolvable(
                edge, confidence=confidence, margin=margin, min_coverage=min_coverage)
            relationship["competing_parents"] = edge.competitors
            serialized.append(relationship)
        return {
            "edges": serialized,
            "tables": sorted(contracts),
            "junction_tables": graph.junction_tables(edges),
            "thresholds": {"confidence": confidence, "margin": margin, "min_coverage": min_coverage},
            "metrics": {"tables": len(contracts), "candidates": len(edges), "verified_now": len(pending),
                        "queries": queries, "universe_truncated": truncated},
        }

    def _relationship_learning_claims(self, contracts: dict[str, dict[str, Any]]) -> list[tuple[str, dict[str, Any]]]:
        """Earlier projects' joins, translated onto identically shaped current tables.

        Learnings are matched by table name, then by column-set fingerprint;
        the original tables are described only when the learning carries no
        fingerprint. Every claim is still verified against the data by the
        relationship graph, so a wrong historical join cannot be applied.
        """
        from app.agent_tools import structural_precedents as precedents

        reader = getattr(getattr(self, "_learning", None), "get_relationship_learnings", None)
        if not callable(reader) or not contracts:
            return []
        self._tool("fir.retrieve_relationship_learnings")
        try:
            with self._domain_lock:
                rows = reader(table_names=sorted({table.rsplit(".", 1)[-1] for table in contracts}),
                              budget=int(self._setting("migration_agent_relationship_learning_limit", 200)))
        except Exception:
            logger.warning("Relationship learnings could not be read; continuing without them", exc_info=True)
            return []
        learnings = [item for item in (precedents.parse_relationship_learning(row) for row in rows) if item]
        needed = [table for table in precedents.tables_needing_contracts(learnings)
                  if table not in contracts and all(_IDENTIFIER.fullmatch(part) for part in table.split("."))]
        originals = {table: contracts[table] for table in precedents.tables_needing_contracts(learnings)
                     if table in contracts}
        if needed:
            try:
                originals.update(self._describe_tables(needed))
            except Exception:
                logger.warning("Original tables of relationship learnings could not be described", exc_info=True)
        claims = precedents.translate_learnings(learnings, contracts, originals)
        self._emit("trace.action.completed", "succeeded",
                   f"Reused {len(claims)} join(s) from {len(learnings)} earlier relationship learning(s).",
                   trace_id=f"relationship-learnings:{uuid4().hex}", parent_trace_id="mapping-execution",
                   kind="retrieval", label="Relationship learnings",
                   details={"learnings": len(learnings), "claims": len(claims),
                            "structural_precedents": sum(kind == "structural_precedent" for kind, _ in claims)})
        return claims

    def remembered_join_paths(
        self, state: dict[str, Any], targets: list[str], plan_tables: list[str],
    ) -> dict[str, dict[str, Any]]:
        """Joins a user already confirmed for these tables, reused instead of asking again.

        A confirmed join is stored as a validated learning. It is reused for a
        pending question only when it was confirmed by a user, it translates
        onto the current tables (same name and column signature), it connects
        the question's table to a table already resolved in this plan, and it
        is the only such answer. Conflicting earlier answers are asked again.
        """
        from app.agent_tools import structural_precedents as precedents

        if not bool(self._setting("migration_agent_reuse_confirmed_joins", True)):
            return {}
        pending = {normalize_fqn(value) for value in targets if normalize_fqn(value).count(".") == 2}
        resolved = {normalize_fqn(value) for value in plan_tables if normalize_fqn(value).count(".") == 2} - pending
        reader = getattr(getattr(self, "_learning", None), "get_relationship_learnings", None)
        if not pending or not resolved or not callable(reader):
            return {}
        try:
            contracts = self._describe_tables(sorted(pending | resolved))
            self._tool("fir.retrieve_confirmed_joins")
            with self._domain_lock:
                rows = reader(table_names=sorted({table.rsplit(".", 1)[-1] for table in contracts}),
                              budget=int(self._setting("migration_agent_relationship_learning_limit", 200)))
        except Exception:  # noqa: BLE001 - the questions are simply asked
            logger.warning("Confirmed join answers could not be read; asking again", exc_info=True)
            return {}
        learnings = [item for item in (precedents.parse_relationship_learning(row) for row in rows)
                     if item and item.get("user_confirmed")]
        originals = {}
        needed = [table for table in precedents.tables_needing_contracts(learnings) if table not in contracts]
        if needed:
            try:
                originals.update(self._describe_tables(needed))
            except Exception:  # noqa: BLE001
                logger.warning("Original tables of confirmed joins could not be described", exc_info=True)
        originals.update({table: contracts[table] for table in precedents.tables_needing_contracts(learnings)
                          if table in contracts})
        options: dict[str, dict[str, dict[str, Any]]] = {}
        for _kind, relationship in precedents.translate_learnings(learnings, contracts, originals):
            left, right = relationship["left_table"], relationship["right_table"]
            for target, other in ((left, right), (right, left)):
                if target in pending and other in resolved:
                    identity = json.dumps([left, right, relationship["conditions"], relationship["literal_filters"],
                                           relationship.get("normalized_lookup_alternative")], sort_keys=True)
                    options.setdefault(target, {}).setdefault(identity, relationship)
        remembered: dict[str, dict[str, Any]] = {}
        for target, found in options.items():
            if len(found) != 1:
                continue  # different earlier answers: a person decides again
            relationship = next(iter(found.values()))
            join = {key: relationship[key] for key in ("left_table", "right_table", "conditions", "literal_filters")}
            if relationship.get("normalized_lookup_alternative"):
                join["normalized_lookup_alternative"] = relationship["normalized_lookup_alternative"]
            join.update({"join_type": "LEFT", "source": "REMEMBERED_USER_CONFIRMATION"})
            remembered[target] = {"joins": [join], "evidence_ids": list(relationship.get("evidence_ids") or []),
                                  "translated_from": list(relationship.get("translated_from") or [])}
        return remembered

    def record_remembered_join(self, state: dict[str, Any], target: str, path: dict[str, Any]) -> None:
        """Show a reused, previously confirmed join as a completed step."""
        join = path["joins"][0]
        condition = (join.get("conditions") or [{}])[0]
        where = "".join(f" where {item.get('column')} = '{item.get('value')}'" for item in join.get("literal_filters") or [])
        lookup = f" (or {join['normalized_lookup_alternative']})" if join.get("normalized_lookup_alternative") else ""
        text = (f"{join['left_table'].rsplit('.', 1)[-1]}.{condition.get('left_column')} = "
                f"{join['right_table'].rsplit('.', 1)[-1]}.{condition.get('right_column')}{lookup}{where}")
        origin = " on another client's identical tables" if path.get("translated_from") else ""
        self._emit("trace.action.completed", "succeeded",
                   f"Reused the join you confirmed earlier{origin} for {target.rsplit('.', 1)[-1]}: {text}.",
                   trace_id=f"remembered-join:{state.get('run_id')}:{target}", parent_trace_id=None, kind="decision",
                   label="Reused confirmed join",
                   details={"target": target, "path": text, "evidence": path.get("evidence_ids") or [],
                            "decision": "remembered_user_confirmation", "reversible": True})

    def auto_apply_verified_joins(self) -> bool:
        """Whether a data-verified join path above the decision thresholds is applied without asking."""
        return bool(getattr(getattr(self, "_settings", None), "migration_agent_auto_apply_verified_joins", True))

    def record_auto_resolved_join(self, state: dict[str, Any], question: dict[str, Any], option: dict[str, Any]) -> None:
        """Show an automatically applied join as a completed step with its confidence and evidence."""
        target = str(question.get("target") or "")
        joins = [join for join in option.get("joins") or [] if isinstance(join, dict)]

        def describe(join: dict[str, Any]) -> str:
            condition = (join.get("conditions") or [{}])[0]
            filters = "".join(f" where {item.get('column')} = '{item.get('value')}'"
                              for item in join.get("literal_filters") or [] if isinstance(item, dict))
            return (f"{str(join.get('left_table') or '').split('.')[-1]}.{condition.get('left_column')} = "
                    f"{str(join.get('right_table') or '').split('.')[-1]}.{condition.get('right_column')}{filters}")

        confidence = float(option.get("confidence") or 0.0)
        path = " → ".join(describe(join) for join in joins)
        self._emit(
            "trace.action.completed", "succeeded",
            f"Applied the verified join for {target.split('.')[-1]} ({round(confidence * 100)}% confidence): {path}.",
            # Stable id: the workflow node replays after later questions and
            # must not show the same decision twice.
            trace_id=f"auto-join:{state.get('run_id')}:{target}", parent_trace_id=None, kind="decision",
            label="Auto-applied join",
            details={"target": target, "driver": question.get("driver"), "confidence": round(confidence, 4),
                     "path": path, "evidence": list(option.get("evidence") or [])[:6],
                     "decision": "auto_resolved", "reversible": True},
        )

    def record_confirmed_relationships(self, state: dict[str, Any], joins: list[dict[str, Any]]) -> int:
        """Store joins a user confirmed as validated, fingerprinted relationship learnings.

        Later projects reuse them on identically shaped tables (after data
        verification). A failed write never blocks the migration.
        """
        from app.agent_tools import structural_precedents as precedents

        writer = getattr(getattr(self, "_learning", None), "record_relationship_learning", None)
        if not callable(writer) or not joins:
            return 0
        actor = self._actor(state)
        tables = sorted({precedents.relationship_table(join.get(side)) for join in joins
                         for side in ("left_table", "right_table")} - {""})
        try:
            contracts = self._describe_tables(tables)
        except Exception:
            logger.warning("Confirmed joins could not be fingerprinted; not recorded", exc_info=True)
            return 0
        recorded = 0
        for join in joins:
            attributes = precedents.learning_attributes(join, contracts)
            if not attributes["left_table"] or not attributes["right_table"] or not attributes["conditions"]:
                continue
            summary = (f"{attributes['left_table']} joins {attributes['right_table']} on "
                       + " AND ".join(f"{c['left_column']} = {c['right_column']}" for c in attributes["conditions"])
                       + "".join(f" where {f['column']} = '{f['value']}'" for f in attributes["literal_filters"])
                       + " (confirmed by a user).")
            try:
                with self._domain_lock:
                    writer(attributes={**attributes, "provenance": "user_confirmed_join",
                                       "source": str(join.get("source") or "")},
                           summary=summary, confidence=1.0, trust_stage="validated",
                           entity_ids={"run_id": str(state.get("run_id") or "")},
                           user_id=actor.app_user_id or None,
                           evidence_ids=[f"run:{state.get('run_id')}"])
                recorded += 1
            except Exception:
                logger.warning("A confirmed join could not be recorded as a learning", exc_info=True)
        if recorded:
            self._emit("trace.action.completed", "succeeded",
                       f"Saved {recorded} confirmed join(s) for reuse in later projects.",
                       trace_id=f"relationship-writeback:{uuid4().hex}", parent_trace_id=None,
                       kind="learning", label="Save confirmed joins", details={"recorded": recorded})
        return recorded

    def inspect_table_contract(self, table_fqn: str) -> ToolResult:
        contract = self._describe_table(table_fqn)
        return ToolResult(
            status="succeeded",
            summary=f"Read {len(contract['columns'])} columns from {table_fqn}.",
            data={"table": table_fqn, **contract},
            evidence_refs=[f"table_contract:{table_fqn.upper()}"],
            metrics={"column_count": len(contract["columns"])},
        )

    def _published_relationship_evidence(
        self, precedents: list[dict[str, Any]], selected_sources: list[str],
    ) -> list[dict[str, Any]]:
        """Reuse accepted joins only when both current endpoints and keys exist."""
        selected = {value.upper() for value in selected_sources}
        if len(selected) < 2:
            return []

        def fqn(value: Any) -> str:
            if isinstance(value, dict):
                value = value.get("qualified_name") or value.get("fqn") or ".".join(
                    str(value.get(key) or "") for key in ("database", "schema", "table")
                )
            return str(value or "").strip('"').upper()

        def match(reference: str) -> str | None:
            candidates = [value for value in selected if value == reference or value.endswith(f".{reference}")]
            return candidates[0] if len(candidates) == 1 else None

        accepted: list[dict[str, Any]] = []
        for precedent in precedents:
            if str(precedent.get("sttm_status") or "").upper() not in {"COMPLETE", "PUBLISHED"}:
                continue
            sttm_id = str(precedent.get("sttm_id") or "")
            raw_relationships = [item for item in precedent.get("relationships") or [] if isinstance(item, dict)]
            if (not raw_relationships and precedent.get("mapping_sql")
                    and is_single_read_only_query(str(precedent["mapping_sql"]))):
                sql = str(precedent["mapping_sql"])
                parsed = parse_sql_document(sql)
                active_references, _ = _active_sql_lineage(sql, parsed)
                active = {match(value.upper()) for value in active_references}
                for join in parsed.join_patterns:
                    left, right = match(join.left_table.upper()), match(join.right_table.upper())
                    if not left or not right or left not in active or right not in active or not join.column_pairs:
                        continue
                    try:
                        condition = parse(join.condition, read="snowflake")[0]
                    except Exception:
                        continue
                    pending = [condition]
                    predicates = []
                    while pending:
                        node = pending.pop()
                        if isinstance(node, exp.And):
                            pending.extend([node.this, node.expression])
                        else:
                            predicates.append(node)
                    if len(predicates) != len(join.column_pairs) or any(
                        not isinstance(node, exp.EQ)
                        or not isinstance(node.this, exp.Column)
                        or not isinstance(node.expression, exp.Column)
                        for node in predicates
                    ):
                        continue
                    raw_relationships.append({
                        "left_table": left, "right_table": right,
                        "join_type": join.join_type,
                        "conditions": [{**pair, "operator": "="} for pair in join.column_pairs],
                    })
            for relationship in raw_relationships:
                left, right = fqn(relationship.get("left_table")), fqn(relationship.get("right_table"))
                if left not in selected or right not in selected or left == right:
                    continue
                raw_conditions = relationship.get("conditions") or []
                conditions = [{
                    "left_column": str(item.get("left_column") or ""),
                    "right_column": str(item.get("right_column") or ""),
                    "operator": "=",
                } for item in raw_conditions if isinstance(item, dict)
                      and str(item.get("operator") or "=").upper() == "="
                      and item.get("left_column") and item.get("right_column")]
                if not conditions or len(conditions) != len(raw_conditions):
                    continue
                try:
                    left_columns = {value.upper() for value in self._describe_table(left)["columns"]}
                    right_columns = {value.upper() for value in self._describe_table(right)["columns"]}
                except Exception:
                    continue
                if any(item["left_column"].upper() not in left_columns
                       or item["right_column"].upper() not in right_columns for item in conditions):
                    continue
                left_ref, right_ref = self._table_ref(left), self._table_ref(right)
                if left_ref is None or right_ref is None:
                    continue
                accepted.append({
                    "left_table": left_ref.model_dump(mode="json"),
                    "right_table": right_ref.model_dump(mode="json"),
                    "join_type": str(relationship.get("join_type") or "INNER").upper().removesuffix(" JOIN"),
                    "conditions": conditions,
                    "source": "PUBLISHED_STTM",
                    "trust_state": "published_current_columns_verified_cardinality_pending",
                    "evidence_ref": f"sttm_precedent:{sttm_id}",
                })
        return accepted

    def discover_current_relationships(
        self, state: dict[str, Any], source_tables: list[str],
        visible_tables: list[str] | None = None,
    ) -> ToolResult:
        """Reuse the Workbench's active-join service for a current source set."""
        if len(source_tables) < 2 or getattr(self, "_settings", None) is None:
            return ToolResult(status="succeeded", summary="No multi-source relationship lookup needed.",
                              data={"active": [], "recommendations": []})
        from app.core.table_selection import TableSelectionService
        from app.agent_tools.source_readiness import disconnected_plan_sources
        refs = [self._table_ref(value) for value in source_tables]
        if any(ref is None for ref in refs):
            return ToolResult(status="failed", summary="Relationship lookup requires qualified current tables.",
                              error_code="invalid_source_selection")
        scope = hashlib.sha256(json.dumps({
            "tenant": state.get("tenant_id"), "user": state.get("app_user_id") or state.get("actor_user_id"),
            "role": state.get("effective_role"), "schemas": sorted(state.get("authorized_schemas") or []),
        }, sort_keys=True).encode()).hexdigest()
        service = TableSelectionService(
            SimpleNamespace(session=self._session), self._settings,
            access_scope=scope, allow_legacy_relationship_procedure=False,
        )
        self._tool("table_selection.discover_relationships")
        try:
            with self._domain_lock:
                active, recommendations = service.list_relationship_discovery_for_tables(refs)
        except Exception as exc:
            return ToolResult(status="failed", summary="Current relationship discovery is unavailable; source design needs review.",
                              error_code="relationship_discovery_unavailable",
                              data={"active": [], "recommendations": [], "error_type": type(exc).__name__})
        active_by_id = {item.id: item for item in active}
        # The Workbench semantic resolver fetches the whole selection in one
        # set-based query. Pairwise retries would repeat the same registry read
        # and, on legacy deployments, accidentally fan out procedure calls.
        recommendation_limit = int(getattr(self._settings, "migration_agent_contract_batch_limit", 8))
        selected = {value.upper() for value in source_tables}
        verified = []
        for item in active_by_id.values():
            left = item.left_table.qualified_name.upper()
            right = item.right_table.qualified_name.upper()
            if left not in selected or right not in selected or item.review_required:
                continue
            left_columns = {value.upper() for value in self._describe_table(left)["columns"]}
            right_columns = {value.upper() for value in self._describe_table(right)["columns"]}
            if not item.conditions or any(
                condition.left_column.upper() not in left_columns
                or condition.right_column.upper() not in right_columns
                for condition in item.conditions
            ):
                continue
            verified.append({**item.model_dump(mode="json"),
                             "trust_state": "current_columns_verified_cardinality_pending"})
        disconnected = disconnected_plan_sources(source_tables[0], source_tables[1:], verified)
        expansion_candidates: list[dict[str, Any]] = []
        if disconnected:
            from app.core.semantic_knowledge_resolver import SemanticKnowledgeResolver
            self._tool("semantic_context.discover_bridge_sources")
            resolver = SemanticKnowledgeResolver(self._settings)
            try:
                with self._domain_lock:
                    records = resolver.resolve(self._session, refs)
            except Exception:
                records = []
            visible = {value.upper() for value in visible_tables or []}
            authorized_schemas = {str(value).strip('"').upper() for value in state.get("authorized_schemas") or []}
            authorized_sources = {str(value).strip('"').upper() for value in state.get("authorized_source_scope") or []}
            for record in records:
                owner = self._table_ref(str(record.get("fqn") or ""))
                if owner is None:
                    continue
                curated = str((record.get("curated_version") or {}).get("validation_status") or "").upper() in {
                    "VALIDATED", "APPROVED", "ACTIVE", "CONFIRMED",
                }
                for relationship in record.get("relationships") or []:
                    if not isinstance(relationship, dict):
                        continue
                    normalized = resolver._normalize_relationship(owner, relationship)
                    if normalized is None:
                        continue
                    left, right, outgoing, _incoming = normalized
                    related = right if left == owner.qualified_name.upper() else left
                    if related in selected or (visible and related not in visible):
                        continue
                    if authorized_sources or authorized_schemas:
                        if related not in authorized_sources and ".".join(related.split(".")[:2]) not in authorized_schemas:
                            continue
                    mappings = outgoing.get("column_mappings") or []
                    expansion_candidates.append({
                        "from_table": owner.qualified_name,
                        "related_table": related,
                        "confidence": relationship.get("confidence") or relationship.get("confidence_score"),
                        "validation_status": relationship.get("validation_status"),
                        "active": SemanticKnowledgeResolver._relationship_is_confirmed(relationship, curated=curated),
                        "column_mappings": [{"fk_column": item.get("fk_column"), "pk_column": item.get("pk_column")}
                                            for item in mappings if isinstance(item, dict)][:4],
                        "evidence_source": "workbench_semantic_registry",
                    })
            expansion_candidates.sort(key=lambda item: (bool(item["active"]), str(item.get("confidence") or "")), reverse=True)
            expansion_candidates = list({
                (item["from_table"], item["related_table"],
                 json.dumps(item["column_mappings"], sort_keys=True)): item
                for item in expansion_candidates
            }.values())[:recommendation_limit]
            # Registry edge direction can be stale even when its referenced
            # tables still exist. Check both sides against current contracts;
            # a corrected direction is a research hint, never an active join.
            for candidate in expansion_candidates:
                try:
                    owner_columns = {value.upper() for value in self._describe_table(candidate["from_table"])["columns"]}
                    related_columns = {value.upper() for value in self._describe_table(candidate["related_table"])["columns"]}
                except Exception:
                    candidate["column_contract_status"] = "unavailable"
                    candidate["active"] = False
                    continue
                mappings = candidate["column_mappings"]
                forward = bool(mappings) and all(
                    str(item.get("fk_column") or "").upper() in owner_columns
                    and str(item.get("pk_column") or "").upper() in related_columns
                    for item in mappings
                )
                reverse = bool(mappings) and all(
                    str(item.get("pk_column") or "").upper() in owner_columns
                    and str(item.get("fk_column") or "").upper() in related_columns
                    for item in mappings
                )
                candidate["column_contract_status"] = (
                    "verified" if forward else "reversed_candidate" if reverse else "mismatch"
                )
                candidate["candidate_conditions"] = [
                    {"from_column": item["fk_column"], "related_column": item["pk_column"]}
                    for item in mappings
                ] if forward else [
                    {"from_column": item["pk_column"], "related_column": item["fk_column"]}
                    for item in mappings
                ] if reverse else []
                candidate["active"] = bool(candidate["active"] and forward)
        return ToolResult(status="succeeded",
            summary=f"Found {len(verified)} active joins with current column contracts.",
            data={
                "evidence_source": "workbench_semantic_knowledge_resolver",
                "legacy_relationship_procedure_used": False,
                "active": verified,
                "recommendations": [item.model_dump(mode="json") for item in recommendations
                                    if item.review_required][:recommendation_limit],
                "expansion_candidates": expansion_candidates,
                "still_disconnected": disconnected,
            },
            evidence_refs=[f"current_relationship:{item.get('id')}" for item in verified])

    def read_stored_semantic_context(
        self,
        state: dict[str, Any],
        source_tables: list[str] | None = None,
        target_table: str | None = None,
        relationships: list[dict[str, Any]] | None = None,
    ) -> ToolResult:
        """Resolve only already-stored semantic assets through the app service."""
        if self._semantic_context is None:
            return ToolResult(
                status="failed",
                summary="Stored semantic context is unavailable; no semantic generation was attempted.",
                warnings=["semantic_context_unavailable"],
                error_code="semantic_context_unavailable",
                data={"status": "unavailable", "generation_allowed": False},
            )
        package = MappingContextPackageV1.model_validate(
            state.get("mapping_context_package") or {
                "run_id": state.get("run_id"),
                "thread_id": state.get("run_id"),
                "app_user_id": state.get("app_user_id") or state.get("actor_user_id"),
                "tenant_id": state.get("tenant_id") or "default",
                "effective_role": state.get("effective_role") or "",
                "authorized_schemas": state.get("authorized_schemas") or [],
                "workspace": state.get("page_context") or {},
            }
        )
        workspace = package.workspace
        # An explicitly supplied empty selection is meaningful: research has
        # not established a current source. Do not fall back to a stale UI
        # workspace selection from a previous mapping.
        selected_sources = (
            [ref for value in source_tables if (ref := self._table_ref(value))]
            if source_tables is not None else workspace.source_tables
        )
        selected_target = self._table_ref(target_table) if target_table else workspace.target_table
        same_workspace_sources = (
            source_tables is None
            or {ref.qualified_name.upper() for ref in selected_sources}
            == {ref.qualified_name.upper() for ref in workspace.source_tables}
        )
        same_workspace_selection = (
            same_workspace_sources
            and (target_table is None or (
                workspace.target_table is not None
                and selected_target is not None
                and workspace.target_table.qualified_name.upper() == selected_target.qualified_name.upper()
            ))
        )
        self._tool("semantic_context.read_stored_registry")
        try:
            with self._domain_lock:
                bundle = self._semantic_context.refresh_bundle(
                    SemanticContextRefreshRequest(
                        selected_source_tables=selected_sources,
                        selected_derived_sources=(workspace.selected_derived_source_ids() if same_workspace_selection else []),
                        target_table=selected_target,
                        relationships=(relationships if relationships is not None else
                                       workspace.relationships if same_workspace_selection else []),
                        selected_columns_by_table=(workspace.selected_columns_by_table if same_workspace_selection else {}),
                        force=False,
                    ),
                    agent_client=None,
                    allow_agent_refresh=False,
                )
        except SemanticAssetNotFoundError as exc:
            missing_assets = [
                str(item.get("message") or "")
                for item in exc.details
                if item.get("field") == "semantic_asset" and item.get("message")
            ]
            # One absent native asset must not erase business semantics for
            # every other selected table. Read the existing Workbench registry
            # in one batch for research, while keeping Analyst unavailable.
            partial_tables: list[dict[str, Any]] = []
            if getattr(self, "_settings", None) is not None:
                try:
                    from app.core.semantic_knowledge_resolver import SemanticKnowledgeResolver
                    self._tool("semantic_context.read_partial_registry")
                    with self._domain_lock:
                        records = SemanticKnowledgeResolver(self._settings).resolve(
                            self._session, [*selected_sources, *([selected_target] if selected_target else [])]
                        )
                    for record in records:
                        model = dict(record.get("semantic_model") or {})
                        partial_tables.append({
                            "fqn": record.get("fqn"),
                            "description": str(model.get("description") or "")[:1000],
                            "domain_summary": str(model.get("domain_summary") or "")[:1000],
                            "grain": str(model.get("grain") or "")[:500],
                            "attributes": [{
                                "name": item.get("name"),
                                "business_meaning": str(item.get("business_meaning") or item.get("description") or "")[:400],
                                "semantic_role": item.get("semantic_role"),
                                "is_primary_key": item.get("is_primary_key"),
                                "is_foreign_key": item.get("is_foreign_key"),
                            } for item in model.get("attributes") or [] if isinstance(item, dict)][:64],
                            "curated_version": record.get("curated_version"),
                        })
                except Exception:
                    logger.warning("Partial Workbench semantic read failed for selected source graph", exc_info=True)
            return ToolResult(
                status="succeeded",
                summary="Stored semantic context is incomplete; available Workbench table semantics remain research evidence, but Analyst cannot use a partial bundle.",
                warnings=["semantic_context_incomplete"],
                data={
                    "status": "partial" if partial_tables else "unavailable",
                    "generation_allowed": False,
                    "source": "stored_registry",
                    "missing_semantic_assets": missing_assets,
                    "covered_tables": [str(item.get("fqn") or "") for item in partial_tables],
                    "semantic_context": {"tables": partial_tables, "relationships": []},
                    "analyst_ready": False,
                    "registry": next(
                        (
                            str(item.get("message"))
                            for item in exc.details
                            if item.get("field") == "semantic_native_registry"
                        ),
                        None,
                    ),
                },
                evidence_refs=[*[f"semantic_table:{item['fqn']}" for item in partial_tables if item.get("fqn")],
                               *[value for value in missing_assets if value]],
            )
        except Exception:
            return ToolResult(
                status="succeeded",
                summary="Stored semantic context could not cover this selection; no semantic generation was attempted.",
                warnings=["semantic_context_unavailable"],
                data={"status": "unavailable", "generation_allowed": False, "source": "stored_registry"},
            )
        has_table_context = bundle.summary.source_table_count > 0 or bool(selected_target)
        partial = (
            bundle.status in {SemanticBundleStatus.PARTIAL, SemanticBundleStatus.FAILED}
            or not selected_sources
            or not getattr(bundle, "analyst_ready", True)
        )
        status = "unavailable" if not has_table_context else "partial" if partial else "available"
        projection_payload: dict[str, Any] = {}
        projection_id: str | None = None
        projection_hash: str | None = None
        if has_table_context and hasattr(self._semantic_context, "get_projection"):
            # The supervisor consumes a bounded projection.  Full semantic DDL
            # and YAML remain in the registry and are passed directly to Cortex
            # Analyst by ask_sql_analyst; they must not be copied into model
            # context or durable tool-event previews.
            with self._domain_lock:
                projection = self._semantic_context.get_projection(
                    SemanticProjectionRequest(
                        bundle_id=bundle.bundle_id,
                        bundle_hash=bundle.bundle_hash,
                        profile=SemanticProjectionProfile.CHAT_SUMMARY,
                    )
                )
            projection_payload = projection.payload
            projection_id = projection.projection_id
            projection_hash = projection.projection_hash
        elif has_table_context:
            # Compatibility for test/fallback semantic adapters that predate
            # projections. Production SemanticContextService always supplies
            # get_projection; this path still avoids fabricating semantics.
            projection_payload = {
                "tables": list(bundle.semantic_context or [])[:25],
                "relationships": [],
            }
        # The chat projection includes registry join candidates, including
        # relationships the composer excluded for unproven uniqueness. Only
        # carry relationships that survived that check into a draft plan.
        def relationship_fqn(value: Any) -> str:
            if isinstance(value, dict):
                return ".".join(str(value.get(key) or "") for key in ("database", "schema", "table"))
            return str(value or "")

        excluded_pairs = set()
        for item in getattr(bundle, "excluded_relationships", []) or []:
            raw = item.get("relationship") or item if isinstance(item, dict) else {}
            if not isinstance(raw, dict):
                continue
            pair = frozenset((
                relationship_fqn(raw.get("left_table") or item.get("left_table")).upper(),
                relationship_fqn(raw.get("right_table") or item.get("right_table")).upper(),
            ))
            excluded_pairs.add(pair)
        verified_relationships = []
        selected_names = {ref.qualified_name.upper() for ref in selected_sources}
        for relationship in projection_payload.get("relationships") or []:
            if not isinstance(relationship, dict):
                continue
            left = self._table_ref(relationship_fqn(relationship.get("left_table")))
            right = self._table_ref(relationship_fqn(relationship.get("right_table")))
            if not left or not right or not {left.qualified_name.upper(), right.qualified_name.upper()} <= selected_names:
                continue
            if frozenset((left.qualified_name.upper(), right.qualified_name.upper())) in excluded_pairs:
                continue
            if str(relationship.get("source") or "").upper() != "SEMANTIC_REGISTRY":
                continue
            if not any(isinstance(condition, dict) and condition.get("left_column") and condition.get("right_column")
                       for condition in relationship.get("conditions") or []):
                continue
            verified_relationships.append(relationship)
        return ToolResult(
            status="succeeded",
            summary=f"Read {status} semantic context from the stored registry.",
            data={
                "status": status,
                "source": "stored_registry",
                "generation_allowed": False,
                "bundle_id": bundle.bundle_id,
                "bundle_hash": bundle.bundle_hash,
                "semantic_view_name": bundle.semantic_view_name,
                "composed_model_hash": bundle.summary.composed_model_hash,
                "projection_id": projection_id,
                "projection_hash": projection_hash,
                "coverage": {
                    "table_count": bundle.summary.source_table_count,
                    "relationship_count": bundle.summary.relationship_count,
                },
                "covered_tables": list(bundle.summary.tables),
                "semantic_context": projection_payload,
                "verified_relationships": verified_relationships,
                "excluded_relationship_count": len(excluded_pairs),
                "reading_instructions": (
                    bundle.reading_instructions.model_dump(mode="json")
                    if bundle.reading_instructions else None
                ),
                "warnings": bundle.warnings,
                "analyst_ready": bool(getattr(bundle, "analyst_ready", False)) and bool(selected_sources),
                "missing_relationships": list(getattr(bundle, "missing_relationships", []) or []),
            },
            warnings=(
                ["semantic_context_selection_empty"] if not has_table_context
                else ["semantic_context_source_selection_missing"] if not selected_sources
                else ["semantic_context_partial"] if partial else []
            ),
            evidence_refs=[
                value for value in [bundle.bundle_id, bundle.bundle_hash, bundle.semantic_view_name] if value
            ],
        )

    def prepare_migration_evidence(
        self,
        state: dict[str, Any],
        *,
        source_tables: list[str],
        target_table: str,
        precedent_project_ids: list[str] | None = None,
    ) -> ToolResult:
        """Build one compact, read-only evidence package after catalog discovery."""
        self._describe_tables([target_table, *source_tables])
        target_contract = self._describe_table(target_table)
        target_columns = list(target_contract["columns"])
        target_types = {
            str(item.get("name") or "").upper(): str(item.get("type") or "")
            for item in target_contract.get("column_contracts") or []
            if isinstance(item, dict)
        }
        precedents: list[dict[str, Any]] = []
        exact_precedents: list[dict[str, Any]] = []
        from app.agent_runs.policy import policy_from_state
        discovery_limit = policy_from_state(state).retrieval_card_limit
        precedent_limit = min(
            discovery_limit,
            int(getattr(getattr(self, "_settings", None), "migration_agent_precedent_project_limit", 5)),
        )
        self._tool("project.find_target_precedents")
        with self._domain_lock:
            discovered_projects = self._projects.find_target_precedent_projects(target_table, limit=precedent_limit)
        # Targets are a shared schema while each client's sources differ, so
        # earlier projects over the same kind of source system are precedents
        # even when they mapped different targets. This never depends on the
        # prompt naming them.
        structural_projects: list[dict[str, Any]] = []
        finder = getattr(self._projects, "find_precedent_projects", None)
        if callable(finder):
            self._tool("project.find_precedents")
            try:
                with self._domain_lock:
                    structural_projects = [
                        item for item in finder(target_tables=[target_table], source_tables=list(source_tables),
                                                terms=[], limit=precedent_limit)
                        if item.get("shared_source_tables") and item.get("mappings_with_sql")
                    ]
            except Exception:
                logger.warning("Structural precedent search failed; using exact-target precedents only", exc_info=True)
        candidate_projects = list(dict.fromkeys([*(precedent_project_ids or []), *discovered_projects]))
        for project_id in candidate_projects[:precedent_limit]:
            project = self._precedent_project_context(state, project_id)
            precedents.append({
                "project_id": project_id,
                "status": project.status,
                "summary": project.summary,
                "project": project.data.get("project"),
                "mappings": project.data.get("mappings") or [],
            })
            if project.status != "succeeded":
                continue
            for mapping in project.data.get("mappings") or []:
                if str(mapping.get("target_table") or "").strip().upper() != target_table.strip().upper():
                    continue
                exact_precedents.append({
                    "project_id": project_id,
                    "project": project.data.get("project") or {},
                    "mapping": mapping,
                })

        # Existing accepted/draft mappings are the strongest source-graph
        # evidence.  Read only the best exact target matches and carry their
        # compact workspace facts forward; do not send full version/artifact
        # histories back to the supervisor.
        exact_precedents.sort(
            key=lambda item: (
                int(str(item["mapping"].get("status") or "").upper() in {"COMPLETE", "PUBLISHED"}),
                float(item["mapping"].get("coverage_percent") or 0),
                int(item["mapping"].get("mapped_count") or 0),
                int(item["mapping"].get("mapping_count") or 0),
            ),
            reverse=True,
        )
        precedent_details: list[dict[str, Any]] = []
        for candidate in exact_precedents[:precedent_limit]:
            sttm_id = str(candidate["mapping"].get("sttm_id") or "")
            if not sttm_id:
                continue
            detail = self._precedent_detail(sttm_id)
            if detail is None:
                continue
            snapshot = dict(detail.latest_snapshot or {})
            precedent_details.append({
                "project_id": candidate["project_id"],
                "project_name": candidate["project"].get("project_name"),
                "sttm_id": sttm_id,
                "sttm_name": detail.sttm.sttm_name,
                "sttm_status": getattr(detail.sttm, "status", "DRAFT"),
                "target_table": detail.sttm.target_table,
                "coverage_percent": detail.sttm.coverage_percent,
                "source_tables": snapshot.get("source_tables") or detail.sources,
                "driving_table": snapshot.get("driving_table"),
                "relationships": snapshot.get("relationships") or [],
                "derived_sources": snapshot.get("derived_sources") or [],
                "filters": snapshot.get("filters") or {},
                "selected_columns_by_table": snapshot.get("selected_columns_by_table") or {},
                "mapping_sql": snapshot.get("mapping_sql") or snapshot.get("raw_mapping_sql"),
                "mapping_rows": [
                    {
                        key: row.get(key)
                        for key in (
                            "target_column", "source_columns", "mapping_mode", "constant_value",
                            "rule", "expression", "natural_language_rule", "status", "confidence",
                        )
                        if row.get(key) not in (None, "", [], {})
                    }
                    for row in (snapshot.get("mapping_rows") or detail.mapping_rows or [])
                    if isinstance(row, dict)
                ],
            })

        def table_fqn(value: Any) -> str:
            if isinstance(value, str):
                return value.strip()
            if not isinstance(value, dict):
                return ""
            explicit = value.get("qualified_name") or value.get("qualifiedName") or value.get("fqn")
            if explicit:
                return str(explicit).strip()
            parts = [value.get("database") or value.get("database_name"), value.get("schema") or value.get("schema_name"), value.get("table") or value.get("table_name") or value.get("name")]
            return ".".join(str(part).strip() for part in parts if part)

        authorized_schemas_for_rank = {
            str(value).strip('"').upper() for value in state.get("authorized_schemas") or []
        }
        explicit_sources_for_rank = {
            str(value).strip('"').upper() for value in state.get("authorized_source_scope") or []
        }

        target_set = {column.upper() for column in target_columns}

        def precedent_rank(value: dict[str, Any]) -> tuple[int, int, int, int, int, int]:
            sources = [table_fqn(item).strip('"').upper() for item in value.get("source_tables") or []]
            in_scope = sum(
                source in explicit_sources_for_rank
                or not authorized_schemas_for_rank
                or ".".join(source.split(".")[:2]) in authorized_schemas_for_rank
                for source in sources if source.count(".") == 2
            )
            # A 100%-covered draft with no SQL or joins is weaker source-design
            # evidence than an exact target precedent with executable SQL and
            # a relationship graph. Coverage alone selected a two-table mapper
            # over the complete historical Household design in DEV.
            parsed_sql = parse_sql_document(str(value.get("mapping_sql") or "")) if value.get("mapping_sql") else None
            sql_columns = {str(item.target_alias or "").upper() for item in parsed_sql.column_mappings} if parsed_sql else set()
            row_columns = {str(item.get("target_column") or "").upper() for item in value.get("mapping_rows") or []}
            return (
                int(bool(target_set) and sql_columns == target_set),
                int(bool(target_set) and row_columns == target_set),
                int(str(value.get("sttm_status") or "").upper() in {"COMPLETE", "PUBLISHED"}),
                int(bool(str(value.get("mapping_sql") or "").strip())),
                int(bool(value.get("relationships"))),
                in_scope,
            )

        precedent_details.sort(key=precedent_rank, reverse=True)

        # Older mappings often have no (or another) target table recorded. When
        # nothing matches the target exactly, mappings whose SQL outputs most of
        # this target's columns are the same design for another source system.
        # They are research evidence only: the supervisor reads them with
        # inspect_precedent_mapping and translates tables to current sources.
        output_equivalent_precedents: list[dict[str, Any]] = []
        equivalent_finder = getattr(self._projects, "find_output_equivalent_mappings", None)
        # An exact-target draft without executable SQL (an unfinished attempt)
        # carries no design; it must not hide SQL-backed equivalents.
        exact_with_sql = any(str(item.get("mapping_sql") or "").strip() for item in precedent_details)
        if not exact_with_sql and callable(equivalent_finder):
            self._tool("project.find_output_equivalent_mappings")
            try:
                with self._domain_lock:
                    output_equivalent_precedents = equivalent_finder(target_columns=target_columns, limit=precedent_limit)
            except Exception:
                logger.warning("Output-equivalent precedent search failed", exc_info=True)

        fir_state = {
            **state,
            "precedent_project_ids": list(dict.fromkeys([
                *(state.get("precedent_project_ids") or []),
                *(precedent_project_ids or []),
                *[str(item["project_id"]) for item in structural_projects],
                *[str(value.get("project_id") or "") for value in exact_precedents],
            ])),
        }
        fir = self.retrieve_fir_evidence(fir_state, target_table, target_columns)
        if self._learning is not None:
            self._tool("fir.retrieve_source_design")
            with self._domain_lock:
                graph_evidence = self._learning.get_source_design_evidence(target_table=target_table,
                    project_ids=fir_state["precedent_project_ids"], budget=discovery_limit)
            fir.data.setdefault("cards", []).extend(graph_evidence["cards"])
            fir.evidence_refs.extend(graph_evidence["retrieved_learning_ids"])

        best_precedent = precedent_details[0] if precedent_details else {}
        precedent_sources = [
            table_fqn(value) for value in best_precedent.get("source_tables") or []
        ]
        precedent_sql = str(best_precedent.get("mapping_sql") or "").strip()
        parsed_precedent = parse_sql_document(precedent_sql) if precedent_sql else None

        def source_matches(reference: str, candidate: str) -> bool:
            ref = reference.strip('"').upper()
            value = candidate.strip('"').upper()
            return value == ref or value.endswith(f".{ref}")

        active_sql_references, active_cte_names = (
            _active_sql_lineage(precedent_sql, parsed_precedent)
            if parsed_precedent else ([], set())
        )
        referenced_precedent_sources = [
            candidate
            for candidate in precedent_sources
            if active_sql_references and any(
                source_matches(reference, candidate)
                for reference in active_sql_references
            )
        ]
        # Old snapshots sometimes persisted every table visible in the source
        # picker. Prefer the tables actually referenced by the accepted SQL;
        # otherwise the Deep Agent builds oversized bundles and invents joins
        # for unused lookup tables.
        precedent_source_graph = referenced_precedent_sources or precedent_sources
        # A mapping may depend on sources absent from the snapshot picker or its
        # obsolete SQL. Preserve explicit row and FIR lineage as additional candidates.
        from app.agent_tools.source_readiness import assess_source_readiness
        precedent_gaps = set(assess_source_readiness(
            target_columns,
            precedent_source_graph,
            list(best_precedent.get("mapping_rows") or []),
            [],
        )["unresolved_columns"])
        lineage_sources = []
        column_cards = [
            card.get("structured_rule") or {}
            for card in fir.data.get("cards", [])
            if str(card.get("target_column") or (card.get("structured_rule") or {}).get("target_column") or "").upper()
            in ({column.upper() for column in precedent_gaps} if best_precedent else
                {column.upper() for column in target_columns})
        ]
        # Graph-level FIR patterns can describe alternative projects and
        # mapper tables. Keep them as evidence, but do not silently add every
        # mentioned table to the selected source graph. Column-scoped cards
        # may add a source needed for a specific target attribute.
        for evidence in [best_precedent, *column_cards]:
            lineage_sources.extend(table_fqn(value) for value in evidence.get("source_tables", []))
            for row in evidence.get("mapping_rows", []) + [evidence]:
                for column in row.get("source_columns", []) or []:
                    if isinstance(column,str) and len(column.split(".")) == 4:
                        lineage_sources.append(column.rsplit(".",1)[0])
        # Historical rows and SQL are research hints, not a current source
        # selection. Only sources explicitly chosen from this run's catalog
        # discovery may enter the executable plan.
        proposed_sources = list(dict.fromkeys(
            value for value in source_tables if self._table_ref(value)
        ))
        historical_source_candidates = list(dict.fromkeys([
            *precedent_source_graph,
            *lineage_sources,
        ]))
        # An exact, published precedent is a bounded source allowlist. Its
        # active SQL can legitimately depend on cross-schema mapper/reference
        # tables (for example MAPPER_* and SCH_OPS code dictionaries). Admit
        # only those named tables after caller-visibility and contract checks;
        # unrelated historical/FIR mentions remain research hints.
        precedent_source_allowlist: set[str] = set()
        if str(best_precedent.get("sttm_status") or "").upper() in {"COMPLETE", "PUBLISHED"}:
            precedent_source_allowlist.update(str(value).strip('"').upper() for value in precedent_source_graph)
            precedent_source_allowlist.update(
                str(value).strip('"').upper() for value in active_sql_references
                if str(value).strip('"').count(".") == 2
            )
        authorized_schemas = {
            str(value).strip('"').upper()
            for value in state.get("authorized_schemas") or []
        }
        explicitly_authorized = {
            str(value).strip('"').upper()
            for value in state.get("authorized_source_scope") or []
        }

        def within_run_scope(value: str) -> bool:
            normalized = value.strip('"').upper()
            # An empty schema list means the user has not narrowed discovery
            # in the UI. The delegated Snowflake session's visible catalog
            # remains authoritative; a selected target alone is not a source
            # schema restriction.
            if not authorized_schemas:
                return True
            if normalized in explicitly_authorized:
                return True
            if normalized in precedent_source_allowlist:
                return True
            parts = normalized.split(".")
            return len(parts) == 3 and ".".join(parts[:2]) in authorized_schemas

        out_of_scope_sources = [value for value in proposed_sources if not within_run_scope(value)]
        proposed_sources = [value for value in proposed_sources if within_run_scope(value)]
        # Validate recovered precedent tables against the authenticated caller's
        # current catalog.  A historical snapshot never grants authorization.
        self._tool("snowflake.verify_precedent_tables")
        with self._domain_lock:
            visible_rows = self._session.sql("SHOW TERSE TABLES IN ACCOUNT").collect()
        visible_tables = set()
        for raw in visible_rows:
            row = raw.as_dict() if hasattr(raw, "as_dict") else dict(raw)
            fqn = ".".join(str(row.get(key) or row.get(key.upper()) or "") for key in ("database_name", "schema_name", "name"))
            if fqn.count(".") == 2:
                visible_tables.add(fqn.upper())
        from app.agent_tools.source_readiness import resolve_visible_references
        sql_references = active_sql_references
        recovered, unresolved_references = resolve_visible_references(sql_references,
            [value for value in visible_tables if within_run_scope(value)], precedent_source_graph)
        verified_sources = [value for value in proposed_sources if value.upper() in visible_tables]
        # A named driving source defines the row grain; it is not a request to
        # discard the other tables used by an exact-target historical design.
        # Expand only when that design's active FROM agrees with the selected
        # driver, and only to tables visible in the caller's current scope.
        historical_driver = _historical_sql_driving_source(precedent_sql, recovered) if precedent_sql else None
        expanded_from_precedent: list[str] = []
        if (verified_sources and historical_driver
                and verified_sources[0].upper() == historical_driver.upper()
                and parsed_precedent
                and {str(item.target_alias or "").upper() for item in parsed_precedent.column_mappings} == target_set):
            for table in recovered[:discovery_limit]:
                if table.upper() in {item.upper() for item in verified_sources}:
                    continue
                try:
                    self._describe_table(table)
                except Exception:
                    continue
                verified_sources.append(table)
                expanded_from_precedent.append(table)
        historical_column_mismatches: list[str] = []
        if parsed_precedent:
            required_by_table: dict[str, set[str]] = {}
            for mapping in parsed_precedent.column_mappings:
                if str(mapping.target_alias or "").upper() not in target_set:
                    continue
                for column in mapping.physical_source_columns:
                    parts = str(column).strip('"').upper().split(".")
                    if len(parts) == 4:
                        required_by_table.setdefault(".".join(parts[:3]), set()).add(parts[3])
            for table in verified_sources:
                required = required_by_table.get(table.upper()) or set()
                if not required:
                    continue
                try:
                    actual = {str(value).upper() for value in self._describe_table(table)["columns"]}
                except Exception:
                    historical_column_mismatches.append(f"Current source contract could not be verified: {table}")
                    continue
                historical_column_mismatches.extend(
                    f"Historical source column is absent from current contract: {table}.{column}"
                    for column in sorted(required - actual)
                )
        omitted_sources = [
            *out_of_scope_sources,
            *[value for value in proposed_sources if value.upper() not in visible_tables],
        ]
        historical_visible_sources = [
            value for value in historical_source_candidates
            if value.upper() in visible_tables and within_run_scope(value)
        ]
        # Rank research leads by independent provenance and exact target-column
        # lineage. This ranking never selects or approves a current source.
        candidate_support: dict[str, dict[str, Any]] = {}

        def note_source(candidate: str, *, precedent_id: str = "", approved: bool = False,
                        target_column: str = "", learning_id: str = "", driving: bool = False) -> None:
            table = str(candidate).strip('"').upper()
            if table not in visible_tables or not within_run_scope(table):
                return
            entry = candidate_support.setdefault(table, {
                "table": table, "precedent_ids": set(), "approved_precedent_ids": set(),
                "target_columns": set(), "learning_ids": set(), "driving_precedent_ids": set(),
            })
            if precedent_id:
                entry["precedent_ids"].add(precedent_id)
                if approved:
                    entry["approved_precedent_ids"].add(precedent_id)
            if target_column:
                entry["target_columns"].add(target_column.upper())
            if learning_id:
                entry["learning_ids"].add(learning_id)
            if driving and precedent_id:
                entry["driving_precedent_ids"].add(precedent_id)

        for precedent in precedent_details:
            precedent_id = str(precedent.get("sttm_id") or "")
            approved = str(precedent.get("sttm_status") or "").upper() in {"COMPLETE", "PUBLISHED"}
            precedent_sources_for_rank = [table_fqn(source) for source in precedent.get("source_tables") or []]
            driving_candidate = _historical_sql_driving_source(
                str(precedent.get("mapping_sql") or ""), precedent_sources_for_rank,
            )
            if driving_candidate:
                note_source(driving_candidate, precedent_id=precedent_id,
                            approved=approved, driving=True)
            for source in precedent_sources_for_rank:
                note_source(table_fqn(source), precedent_id=precedent_id, approved=approved)
            for row in precedent.get("mapping_rows") or []:
                for column in row.get("source_columns") or []:
                    if isinstance(column, str) and len(column.split(".")) == 4:
                        note_source(column.rsplit(".", 1)[0], precedent_id=precedent_id,
                                    approved=approved, target_column=str(row.get("target_column") or ""))
            parsed_for_rank = parse_sql_document(str(precedent.get("mapping_sql") or "")) if precedent.get("mapping_sql") else None
            if parsed_for_rank:
                for mapping in parsed_for_rank.column_mappings:
                    target_name = str(mapping.target_alias or "")
                    if target_name.upper() not in target_set:
                        continue
                    for column in mapping.physical_source_columns:
                        if not isinstance(column, str) or "." not in column:
                            continue
                        reference = column.rsplit(".", 1)[0]
                        resolved, _ = resolve_visible_references(
                            [reference], [value for value in visible_tables if within_run_scope(value)],
                            precedent_sources_for_rank,
                        )
                        for source in resolved:
                            note_source(source, precedent_id=precedent_id,
                                        approved=approved, target_column=target_name)
        for card in fir.data.get("cards") or []:
            if not isinstance(card, dict):
                continue
            rule = dict(card.get("structured_rule") or {})
            learning_id = str(card.get("learning_id") or "")
            lineage = rule.get("source_columns") or card.get("source_columns") or []
            if isinstance(lineage, str):
                lineage = [lineage]
            exact_lineage = [column for column in lineage
                             if isinstance(column, str) and len(column.split(".")) == 4]
            for column in exact_lineage:
                if isinstance(column, str) and len(column.split(".")) == 4:
                    note_source(column.rsplit(".", 1)[0], learning_id=learning_id,
                                target_column=str(card.get("target_column") or rule.get("target_column") or ""))
            if not exact_lineage:
                # Graph-level cards often list every table in a historical
                # project. They do not support every table's source role.
                card_sources = [str(value) for value in rule.get("source_tables") or []]
                if len(card_sources) == 1 and (card.get("target_column") or rule.get("target_column")):
                    note_source(card_sources[0], learning_id=learning_id,
                                target_column=str(card.get("target_column") or rule.get("target_column")))
        for source in historical_visible_sources:
            note_source(source)
        ranked_source_candidates = sorted(candidate_support.values(), key=lambda entry: (
            len(entry["approved_precedent_ids"]), len(entry["driving_precedent_ids"]),
            len(entry["target_columns"]),
            len(entry["precedent_ids"]), len(entry["learning_ids"]), entry["table"],
        ), reverse=True)
        source_candidate_evidence = [{
            "table": entry["table"],
            "accepted_precedent_count": len(entry["approved_precedent_ids"]),
            "historical_driving_count": len(entry["driving_precedent_ids"]),
            "precedent_count": len(entry["precedent_ids"]),
            "target_column_lineage_count": len(entry["target_columns"]),
            "fir_learning_count": len(entry["learning_ids"]),
            "evidence_ids": [
                *[f"sttm_precedent:{value}" for value in sorted(entry["precedent_ids"])],
                *[f"fir_learning:{value}" for value in sorted(entry["learning_ids"])],
            ],
            "approval_state": "candidate",
        } for entry in ranked_source_candidates[:discovery_limit]]
        historical_visible_sources = [entry["table"] for entry in ranked_source_candidates[:discovery_limit]]

        # If no complete, same-grain SQL precedent supplied the supporting
        # graph, use accepted column-scoped FIR lineage to research one. A FIR
        # table enters the plan only with current columns and an active or
        # published current-column-verified join path to the requested driver.
        # Competing tables for the same target column stay as review evidence.
        expanded_from_fir: dict[str, dict[str, set[str]]] = {}
        if verified_sources and not expanded_from_precedent:
            fir_candidates: dict[str, dict[str, set[str]]] = {}
            column_sources: dict[str, set[str]] = {}
            for card in fir.data.get("cards") or []:
                if not isinstance(card, dict):
                    continue
                rule = dict(card.get("structured_rule") or {})
                trust = str(card.get("approval_state") or card.get("trust_stage") or card.get("validation_status") or "").lower()
                target_name = str(card.get("target_column") or rule.get("target_column") or "").upper()
                if trust not in {"approved", "accepted", "validated"} or target_name not in target_set:
                    continue
                lineage = rule.get("source_columns") or card.get("source_columns") or []
                if isinstance(lineage, str):
                    lineage = [lineage]
                for raw in lineage:
                    parts = str(raw).strip('"').upper().split(".")
                    if len(parts) != 4:
                        continue
                    table, column = ".".join(parts[:3]), parts[3]
                    if table not in visible_tables or not within_run_scope(table):
                        continue
                    column_sources.setdefault(target_name, set()).add(table)
                    if table in verified_sources:
                        continue
                    record = fir_candidates.setdefault(table, {"columns": set(), "targets": set(), "evidence_ids": set()})
                    record["columns"].add(column)
                    record["targets"].add(target_name)
                    if card.get("learning_id"):
                        record["evidence_ids"].add(f"fir_learning:{card['learning_id']}")
            eligible = []
            for table, record in fir_candidates.items():
                if any(len(column_sources[target_name]) > 1 for target_name in record["targets"]):
                    continue
                try:
                    actual = {str(value).upper() for value in self._describe_table(table)["columns"]}
                except Exception:
                    continue
                if record["columns"] <= actual:
                    eligible.append(table)
            eligible = eligible[:discovery_limit]
            if eligible:
                researched = [verified_sources[0], *eligible]
                joins = self.discover_current_relationships(
                    state, researched, visible_tables=sorted(visible_tables),
                )
                links = [
                    *list(joins.data.get("active") or []),
                    *self._published_relationship_evidence(precedent_details, researched),
                ]
                connected = {verified_sources[0].upper()}
                while True:
                    next_connected = set(connected)
                    for link in links:
                        left = table_fqn(link.get("left_table")).upper()
                        right = table_fqn(link.get("right_table")).upper()
                        if left in connected:
                            next_connected.add(right)
                        if right in connected:
                            next_connected.add(left)
                    if next_connected == connected:
                        break
                    connected = next_connected
                for table in eligible:
                    if table.upper() in connected:
                        verified_sources.append(table)
                        expanded_from_fir[table] = fir_candidates[table]

        current_relationships = self.discover_current_relationships(
            state, verified_sources, visible_tables=sorted(visible_tables),
        )
        active_relationships = list(current_relationships.data.get("active") or [])
        published_relationships = self._published_relationship_evidence(precedent_details, verified_sources)
        semantic = self.read_stored_semantic_context(
            state, source_tables=verified_sources, target_table=target_table,
            relationships=[*active_relationships, *published_relationships],
        )
        semantic_bundle_id = str(semantic.data.get("bundle_id") or "").strip() or None
        semantic_view_name = str(semantic.data.get("semantic_view_name") or "").strip() or None
        source_business_names = " ".join(
            value.split(".")[-1].replace("_", " ") for value in verified_sources
        )
        rag = self.search_workbench_rag(
            state,
            query=(
                f"{target_table.split('.')[-1].replace('_', ' ')} business context "
                f"mappings relationships joins derived sources transformations {source_business_names}"
            ),
            limit=5,
            folders=["semantic", "relationships", "mappings", "published", "derived_sources", "historical_sql", "knowledge_notes"],
            semantic_bundle_id=semantic_bundle_id,
            semantic_view_name=semantic_view_name,
        )

        # Historical rows and alternative FIR cards are research evidence, not
        # proof that this run's selected sources cover the target contract.
        # Specialist mapping can use every card; Analyst readiness only uses
        # explicitly accepted rules whose lineage fits current sources.
        selected_upper = {value.upper() for value in verified_sources}
        accepted_rules = []
        for card in fir.data.get("cards") or []:
            if not isinstance(card, dict):
                continue
            rule = dict(card.get("structured_rule") or {})
            trust = str(card.get("approval_state") or card.get("trust_stage") or card.get("validation_status") or "").lower()
            if trust not in {"approved", "accepted", "validated"}:
                continue
            lineage = rule.get("source_columns") or card.get("source_columns") or []
            sources = {str(value).upper() for value in rule.get("source_tables") or [] if isinstance(value, str)}
            sources.update(str(value).rsplit(".", 1)[0].upper() for value in lineage
                           if isinstance(value, str) and len(value.split(".")) == 4)
            if sources <= selected_upper:
                accepted_rules.append({
                    **card, **rule,
                    "source_columns": lineage,
                    "source_tables": list(sources),
                })
        source_readiness = assess_source_readiness(target_columns, verified_sources, [], accepted_rules)
        from app.agent_tools.source_readiness import disconnected_plan_sources
        semantic_relationships = list(semantic.data.get("verified_relationships") or [])
        current_plan_relationships: list[dict[str, Any]] = []
        relationship_by_pair: dict[frozenset[str], dict[str, Any]] = {}
        relationship_conflicts: list[str] = []
        relationship_choices: dict[frozenset[str], list[dict[str, Any]]] = {}

        def canonical_join_keys(item: dict[str, Any]) -> tuple[tuple[str, str], ...]:
            left = table_fqn(item.get("left_table")).upper()
            right = table_fqn(item.get("right_table")).upper()
            reverse = left > right
            return tuple(sorted((
                str((condition.get("right_column") if reverse else condition.get("left_column")) or "").upper(),
                str((condition.get("left_column") if reverse else condition.get("right_column")) or "").upper(),
            ) for condition in item.get("conditions") or [] if isinstance(condition, dict)))

        def join_signature(item: dict[str, Any]) -> tuple[Any, ...]:
            return (canonical_join_keys(item), str(item.get("join_type") or "INNER").upper().removesuffix(" JOIN"))

        # Which evidence tiers (stored semantics, active Workbench joins,
        # published precedents) support each distinct join per table pair.
        join_support: dict[frozenset[str], dict[tuple[Any, ...], set[str]]] = {}
        for tier, items in (("semantic", semantic_relationships), ("active", active_relationships),
                            ("published", published_relationships)):
            for item in items:
                pair = frozenset((table_fqn(item.get("left_table")).upper(),
                                  table_fqn(item.get("right_table")).upper()))
                join_support.setdefault(pair, {}).setdefault(join_signature(item), set()).add(tier)

        for item in [*semantic_relationships, *active_relationships, *published_relationships]:
            pair = frozenset((table_fqn(item.get("left_table")).upper(),
                              table_fqn(item.get("right_table")).upper()))
            previous = relationship_by_pair.get(pair)
            if previous is not None:
                if join_signature(previous) != join_signature(item):
                    relationship_conflicts.append(" / ".join(sorted(pair)))
                    choices = relationship_choices.setdefault(pair, [previous])
                    if item not in choices:
                        choices.append(item)
                continue
            relationship_by_pair[pair] = item
            current_plan_relationships.append(item)
        # Research before asking: when two evidence tiers agree on a join and
        # the third disagrees, the agreed join wins without a user question.
        # Only a genuine tie (for example semantic vs. published, one each)
        # remains a confidence-gated decision.
        resolved_join_conflicts: list[dict[str, Any]] = []
        for pair, choices in list(relationship_choices.items()):
            support = join_support.get(pair, {})
            ranked = sorted(choices, key=lambda value: len(support.get(join_signature(value), ())), reverse=True)
            best, runner_up = ranked[0], (ranked[1] if len(ranked) > 1 else None)
            best_count = len(support.get(join_signature(best), ()))
            runner_count = len(support.get(join_signature(runner_up), ())) if runner_up else 0
            if best_count >= 2 and best_count > runner_count:
                current = relationship_by_pair[pair]
                if current is not best:
                    current_plan_relationships[current_plan_relationships.index(current)] = best
                    relationship_by_pair[pair] = best
                del relationship_choices[pair]
                label = " / ".join(sorted(pair))
                relationship_conflicts = [value for value in relationship_conflicts if value != label]
                resolved_join_conflicts.append({
                    "pair": label, "supported_by": sorted(support.get(join_signature(best), ())),
                    "rejected_by": sorted(set().union(*(tiers for signature, tiers in support.items()
                                                        if signature != join_signature(best)))),
                })
        semantic_disconnected = disconnected_plan_sources(
            verified_sources[0] if verified_sources else None,
            verified_sources[1:], current_plan_relationships,
        ) if verified_sources else []
        # Analyst proposes draft expressions for unresolved target columns. It
        # does not approve business rules; requiring already-mapped columns
        # here made the tool impossible to use for its intended discovery role.
        analyst_eligible = bool(verified_sources) and not semantic_disconnected and bool(semantic.data.get("analyst_ready"))

        analyst = self.ask_sql_analyst(
            state,
            (
                f"Using only the supplied stored semantic bundle, propose a read-only Snowflake SELECT/CTE "
                f"that populates the {target_table} contract at its intended business grain. Use only these "
                f"verified sources: {', '.join(verified_sources)}. Reuse verified relationships and explain "
                "any unresolved mappings; do not invent columns or perform DDL/DML."
            ),
            source_tables=verified_sources,
            target_table=target_table,
            relationships=current_plan_relationships,
            prefer_stored_model=True,
        ) if analyst_eligible else ToolResult(
            status="failed",
            summary="Cortex Analyst requires complete semantic coverage and an evidence-backed source design.",
            error_code="semantic_context_unavailable",
        )

        def relationship_table(value: Any) -> str:
            return table_fqn(value).upper()

        relationships = [
            value for value in (best_precedent.get("relationships") or [])
            if isinstance(value, dict)
            and relationship_table(value.get("left_table")) in selected_upper
            and relationship_table(value.get("right_table")) in selected_upper
        ]

        def resolve_source(reference: str) -> str | None:
            return next(
                (candidate for candidate in verified_sources if source_matches(reference, candidate)),
                None,
            )

        # Trace a referenced CTE output through single-column lineage. A
        # filtered or deduplicated CTE remains a separate plan artifact; this
        # trace only proposes a physical join key for human review.
        ctes_by_name = {cte.name.upper(): cte for cte in parsed_precedent.ctes} if parsed_precedent else {}

        def resolve_join_key(reference: str, column: str, seen: frozenset[str] = frozenset()) -> tuple[str, str] | None:
            physical = resolve_source(reference)
            if physical:
                return physical, column
            cte = ctes_by_name.get(str(reference).upper())
            if not cte or cte.name.upper() in seen:
                return None
            output = next((item for item in cte.output_columns
                           if str(item.get("name") or "").upper() == str(column).upper()), None)
            if output:
                references = output.get("source_references") or []
                if len(references) == 1 and not output.get("unresolved_references"):
                    ref = references[0]
                    return resolve_join_key(str(ref.get("relation") or ""), str(ref.get("column") or ""),
                                            seen | {cte.name.upper()})
            star_only = cte.output_columns and all(
                str(item.get("name") or "") == "*" and str(item.get("expression") or "") == "*"
                for item in cte.output_columns
            )
            if len(cte.tables_referenced) == 1 and not cte.derived_source_reasons and (not cte.output_columns or star_only):
                return resolve_join_key(cte.tables_referenced[0], column, seen | {cte.name.upper()})
            return None

        # Snapshot relationships may cover only part of a precedent graph.
        # Extract the active SQL joins as separate review candidates even when
        # some snapshot joins already exist.
        if parsed_precedent:
            for join in parsed_precedent.join_patterns:
                # Recognize exactly two normalized equality terms joined by
                # OR. The shared operand is the value; the other two are
                # alternatives on one lookup relation. No raw SQL is copied.
                try:
                    expression = parse(join.condition, read="snowflake")[0]
                except Exception:
                    expression = None

                def normalized_ref(node: Any) -> tuple[str, str] | None:
                    if not isinstance(node, exp.Trim) or not isinstance(node.this, exp.Upper):
                        return None
                    value = node.this.this
                    if not isinstance(value, exp.Column) or not value.table:
                        return None
                    relation = join.scope_aliases.get(str(value.table).upper())
                    return (relation, value.name) if relation else None

                if isinstance(expression, exp.Or) and all(isinstance(term, exp.EQ) for term in
                                                             (expression.this, expression.expression)):
                    terms = [(normalized_ref(term.this), normalized_ref(term.expression))
                             for term in (expression.this, expression.expression)]
                    if all(left and right for left, right in terms):
                        shared = set(terms[0]) & set(terms[1])
                        if len(shared) == 1:
                            value_ref = next(iter(shared))
                            alternatives = [next(ref for ref in pair if ref != value_ref) for pair in terms]
                            if (alternatives[0][0] == alternatives[1][0] and
                                    alternatives[0][1].upper() != alternatives[1][1].upper()):
                                value_key = resolve_join_key(*value_ref)
                                first_key = resolve_join_key(*alternatives[0])
                                second_key = resolve_join_key(*alternatives[1])
                                if (value_key and first_key and second_key and
                                        first_key[0] == second_key[0] and value_key[0] != first_key[0]):
                                    relationships.append({
                                        "left_table": self._table_ref(value_key[0]).model_dump(mode="json"),
                                        "right_table": self._table_ref(first_key[0]).model_dump(mode="json"),
                                        "join_type": str(join.join_type or "LEFT").upper(),
                                        "conditions": [{"left_column": value_key[1], "right_column": first_key[1], "operator": "="}],
                                        "normalized_lookup_alternative": second_key[1],
                                        "source": "HISTORICAL_NORMALIZED_LOOKUP_CANDIDATE",
                                        "review_reason": "Prior SQL used two normalized lookup alternatives; verify current contracts, CTE grain and business meaning.",
                                        "condition_sql": join.condition,
                                    })
                resolved_pairs = [
                    (resolve_join_key(join.left_table, str(pair.get("left_column") or "")),
                     resolve_join_key(join.right_table, str(pair.get("right_column") or "")))
                    for pair in join.column_pairs
                ]
                if not resolved_pairs or any(not left or not right for left, right in resolved_pairs):
                    continue
                left, right = resolved_pairs[0][0][0], resolved_pairs[0][1][0]
                if any(pair[0][0] != left or pair[1][0] != right for pair in resolved_pairs):
                    continue
                left_ref = self._table_ref(left)
                right_ref = self._table_ref(right)
                if not left_ref or not right_ref or left == right:
                    continue
                conditions = [{"left_column": pair[0][1], "right_column": pair[1][1], "operator": "="}
                              for pair in resolved_pairs]
                relationships.append({
                    "left_table": left_ref.model_dump(mode="json"),
                    "right_table": right_ref.model_dump(mode="json"),
                    "join_type": str(join.join_type or "LEFT").upper(),
                    "conditions": conditions,
                    "source": ("HISTORICAL_CTE_KEY_CANDIDATE" if
                               join.left_table.upper() in ctes_by_name or join.right_table.upper() in ctes_by_name
                               else "HISTORICAL_PRECEDENT_CANDIDATE"),
                    "condition_sql": join.condition,
                })
        # Historical joins remain candidates. A current registry join can
        # enter the plan only after semantic composition kept it for Analyst.
        verified_plan_relationships = current_plan_relationships
        verified_disconnected = disconnected_plan_sources(
            verified_sources[0] if verified_sources else None,
            verified_sources[1:], verified_plan_relationships,
        ) if verified_sources else []
        derived_sources = []
        incomplete_derived_sources: list[str] = []
        precedent_ctes = {
            cte.name.upper(): cte
            for cte in parsed_precedent.ctes
            if cte.name and cte.sql_text
        } if parsed_precedent else {}
        for value in (best_precedent.get("derived_sources") or []) if verified_sources else []:
            if not isinstance(value, dict):
                continue
            normalized = dict(value)
            if not normalized.get("sql"):
                normalized["sql"] = normalized.get("sql_text") or normalized.get("query")
            if not normalized.get("sql"):
                cte = precedent_ctes.get(str(normalized.get("name") or "").upper())
                if cte:
                    normalized["sql"] = cte.sql_text
                    normalized["base_source_tables"] = [
                        source for source in verified_sources
                        if any(source_matches(reference, source) for reference in cte.tables_referenced)
                    ]
                    normalized["source"] = "HISTORICAL_PRECEDENT_CANDIDATE"
            if normalized.get("sql"):
                derived_sources.append(normalized)
            else:
                incomplete_derived_sources.append(
                    str(normalized.get("name") or normalized.get("id") or "historical derived source")
                )
        if not derived_sources and parsed_precedent and verified_sources:
            derived_sources = [
                {
                    "name": cte.name,
                    "purpose": cte.purpose,
                    "sql": cte.sql_text,
                    "base_source_tables": [
                        value for value in verified_sources
                        if any(source_matches(reference, value) for reference in cte.tables_referenced)
                    ],
                    "source": "HISTORICAL_PRECEDENT_CANDIDATE",
                }
                for cte in parsed_precedent.ctes
                if cte.sql_text and cte.name.upper() in active_cte_names
            ]
        safe_derived_sources = []
        selected_source_set = {value.upper() for value in verified_sources}
        for value in derived_sources:
            cte = precedent_ctes.get(str(value.get("name") or "").upper())
            if cte is None:
                if value.get("base_source_tables"):
                    safe_derived_sources.append(value)
                continue
            references_verified = all(
                reference.upper() in active_cte_names or any(
                    source_matches(reference, table) for table in selected_source_set
                )
                for reference in cte.tables_referenced
            )
            if not references_verified and self._setting("migration_agent_precedent_cte_retarget_enabled", True):
                # The same CTE logic over this client's copies of its tables:
                # reuse it with the table names changed, and say so for review.
                adapted = retarget_cte_sql(str(value.get("sql") or ""), verified_sources, cte_names=active_cte_names)
                if adapted and adapted[1]:
                    value = {
                        **value, "sql": adapted[0],
                        "base_source_tables": sorted(set(adapted[1].values())),
                        "adapted_from_precedent": adapted[1],
                        "review_reason": "Reused precedent CTE with its tables re-pointed at the current sources: "
                                         + ", ".join(f"{old} → {new}" for old, new in adapted[1].items()),
                    }
                    references_verified = True
            if references_verified and (value.get("base_source_tables") or cte.dependencies):
                safe_derived_sources.append(value)
        # The first caller-selected source is the requested row grain. A
        # precedent may explain its supporting graph, but cannot silently
        # replace that grain with the driver saved in a different project.
        driving_source = verified_sources[0] if verified_sources else None

        mapping_rows = list(best_precedent.get("mapping_rows") or [])

        def historical_constant_value(value: Any) -> Any:
            """Store SQL string literals as values, preserving their SQL evidence."""
            if not isinstance(value, str):
                return value
            try:
                expression = parse_one(value, read="snowflake")
            except Exception:
                return value
            if isinstance(expression, exp.Literal) and expression.is_string:
                return expression.this
            return value

        parsed_mappings = {
            str(item.target_alias or "").upper(): item
            for item in (parsed_precedent.column_mappings if parsed_precedent else [])
            if item.target_alias
        }
        classifications: dict[str, str] = {}
        for row in mapping_rows:
            target_column = str(row.get("target_column") or "").strip()
            if not target_column:
                continue
            parsed_mapping = parsed_mappings.get(target_column.upper())
            mode = str(row.get("mapping_mode") or "").lower()
            expression = str(row.get("expression") or row.get("rule") or "").strip()
            if expression.lower() in {"direct", "custom", "source"}:
                expression = ""
            source_count = len(row.get("source_columns") or (parsed_mapping.physical_source_columns if parsed_mapping else []) or [])
            classifications[target_column] = (
                "constant" if mode == "constant" or (parsed_mapping and parsed_mapping.mapping_mode == "constant")
                else "many_to_one" if source_count > 1
                else "derived" if expression or (parsed_mapping and parsed_mapping.transformation)
                else "direct" if source_count == 1
                else "unresolved"
            )
        proposed_sql = str(analyst.data.get("sql") or "").strip()
        # Historical mappings may be scripts containing SET/CREATE/INSERT. They
        # remain evidence, but the governed plan may offer only a single
        # read-only statement for execution; the compiler owns final SQL.
        planned_sql = proposed_sql if proposed_sql and is_single_read_only_query(proposed_sql) else None
        precedent_reference = {}
        if (
            parsed_precedent
            and str(best_precedent.get("sttm_status") or "").upper() in {"COMPLETE", "PUBLISHED"}
            and {column.upper() for column in target_columns}
            == {str(item.target_alias or "").upper() for item in parsed_precedent.column_mappings}
            and not unresolved_references
            and len(recovered) == len(active_sql_references)
            and {value.upper() for value in recovered} == {value.upper() for value in verified_sources}
            and best_precedent.get("sttm_id")
            and historical_driver == driving_source
            and is_single_read_only_query(precedent_sql)
            and not verified_disconnected
            and not relationship_conflicts
        ):
            precedent_reference = {
                "sttm_id": str(best_precedent["sttm_id"]),
                "sql_sha256": hashlib.sha256(precedent_sql.encode("utf-8")).hexdigest(),
                "status": str(best_precedent["sttm_status"]).upper(),
            }
        if not planned_sql and precedent_reference and is_single_read_only_query(precedent_sql):
            planned_sql = precedent_sql
        selected_plan_sources = verified_sources
        mapping_evidence: list[dict[str, Any]] = []
        target_column_names = {value.upper() for value in target_columns}
        for row in mapping_rows:
            target_column = str(row.get("target_column") or "").strip()
            if not target_column or target_column.upper() not in target_column_names:
                continue
            parsed_mapping = parsed_mappings.get(target_column.upper())
            lineage = (
                [] if parsed_mapping and parsed_mapping.mapping_mode == "constant"
                else (parsed_mapping.physical_source_columns if parsed_mapping else []) or row.get("source_columns") or []
            )
            if isinstance(lineage, str):
                lineage = [lineage]
            transformation = str(row.get("expression") or row.get("rule") or "").strip()
            if transformation.lower() in {"direct", "custom", "source"}:
                transformation = ""
            transformation = transformation or str(parsed_mapping.transformation or "" if parsed_mapping else "")
            mapping_evidence.append({
                "target_column": target_column,
                "source_columns": list(lineage),
                "transformation": transformation[:2000],
                "mapping_mode": classifications.get(target_column) or str(row.get("mapping_mode") or "historical"),
                "constant_value": (
                    row.get("constant_value")
                    if row.get("constant_value") is not None
                    else historical_constant_value(parsed_mapping.constant_value) if parsed_mapping else None
                ),
                "evidence_source": "historical_precedent",
                "evidence_id": f"sttm_precedent:{best_precedent.get('sttm_id')}",
                "approval_state": "candidate",
            })
        # The best precedent establishes a useful starting graph, but its rows
        # are not the whole evidence estate. Preserve alternative column-level
        # lineage and transformations from other exact-target mappings so the
        # mapping specialist can resolve conflicts against current contracts.
        existing_mapping_evidence = {
            (str(item.get("target_column") or "").upper(),
             tuple(str(value).upper() for value in item.get("source_columns") or []),
             str(item.get("transformation") or "").strip().upper())
            for item in mapping_evidence
        }
        per_column_precedents: dict[str, int] = {}
        for precedent in precedent_details[:precedent_limit]:
            parsed_other = parse_sql_document(str(precedent.get("mapping_sql") or "")) if precedent.get("mapping_sql") else None
            parsed_by_target = {
                str(item.target_alias or "").upper(): item
                for item in parsed_other.column_mappings
                if item.target_alias
            } if parsed_other else {}
            rows_by_target = {
                str(item.get("target_column") or "").upper(): item
                for item in precedent.get("mapping_rows") or []
                if item.get("target_column")
            }
            for column in target_columns:
                key = column.upper()
                row = rows_by_target.get(key) or {}
                parsed_mapping = parsed_by_target.get(key)
                if not row and parsed_mapping is None:
                    continue
                lineage = (
                    [] if parsed_mapping and parsed_mapping.mapping_mode == "constant"
                    else (parsed_mapping.physical_source_columns if parsed_mapping else []) or row.get("source_columns") or []
                )
                if isinstance(lineage, str):
                    lineage = [lineage]
                transformation = str(row.get("expression") or row.get("rule") or "").strip()
                if transformation.lower() in {"direct", "custom", "source"}:
                    transformation = ""
                transformation = transformation or str(parsed_mapping.transformation or "" if parsed_mapping else "")
                signature = (key, tuple(str(value).upper() for value in lineage), transformation.upper())
                if signature in existing_mapping_evidence or per_column_precedents.get(key, 0) >= 3:
                    continue
                mapping_evidence.append({
                    "target_column": column,
                    "source_columns": list(lineage),
                    "transformation": transformation[:2000],
                    "mapping_mode": str(row.get("mapping_mode") or (parsed_mapping.mapping_mode if parsed_mapping else "historical")),
                    "constant_value": row.get("constant_value") if row.get("constant_value") is not None else (
                        historical_constant_value(parsed_mapping.constant_value) if parsed_mapping else None
                    ),
                    "evidence_source": "historical_precedent",
                    "evidence_id": f"sttm_precedent:{precedent.get('sttm_id')}",
                    "approval_state": "candidate",
                    "applicability": "requires_current_source_and_business_review",
                })
                existing_mapping_evidence.add(signature)
                per_column_precedents[key] = per_column_precedents.get(key, 0) + 1
        # Output-equivalent precedents (older SQL producing this target's
        # columns, recorded under another or no target) are column evidence too.
        for item in self._output_equivalent_column_evidence(output_equivalent_precedents, target_columns):
            signature = (str(item["target_column"]).upper(), tuple(str(value).upper() for value in item["source_columns"]),
                         str(item["transformation"]).strip().upper())
            if signature in existing_mapping_evidence or per_column_precedents.get(signature[0], 0) >= 3:
                continue
            mapping_evidence.append(item)
            existing_mapping_evidence.add(signature)
            per_column_precedents[signature[0]] = per_column_precedents.get(signature[0], 0) + 1
        for card in fir.data.get("cards") or []:
            if not isinstance(card, dict):
                continue
            target_column = str(card.get("target_column") or "").strip()
            if not target_column or target_column.upper() not in target_column_names:
                continue
            rule = dict(card.get("structured_rule") or {})
            lineage = card.get("source_columns") or rule.get("source_columns") or []
            if isinstance(lineage, str):
                lineage = [lineage]
            mapping_evidence.append({
                "target_column": target_column,
                "source_columns": list(lineage),
                "transformation": str(card.get("transformation") or rule.get("transformation") or "")[:2000],
                "mapping_mode": str(rule.get("mapping_mode") or card.get("evidence_class") or "fir_candidate"),
                "evidence_source": "fir_learning",
                "evidence_id": str(card.get("learning_id") or ""),
                "approval_state": str(card.get("approval_state") or card.get("trust_stage") or "unverified"),
            })
        evidence_refs = list(dict.fromkeys([
            f"table_contract:{target_table.upper()}",
            *semantic.evidence_refs,
            *fir.evidence_refs,
            *rag.evidence_refs,
            *analyst.evidence_refs,
            *[f"sttm_precedent:{value['sttm_id']}" for value in precedent_details],
        ]))
        current_attributes = {}
        if state.get("project_id"):
            self._tool("project.read_value_bindings")
            with self._domain_lock:
                current_attributes = {
                    item.attribute_name.upper(): item
                    for item in self._projects.list_project_attributes(str(state["project_id"]))
                }
        value_bindings = []
        bound_targets: set[str] = set()
        if parsed_precedent:
            for variable in parsed_precedent.variable_bindings:
                if not variable.project_value_candidate:
                    continue
                placeholder = f"${variable.name}"
                targets = [
                    str(mapping.target_alias)
                    for mapping in parsed_precedent.column_mappings
                    if mapping.target_alias and placeholder.upper() in (
                        str(mapping.constant_value or "") + " " + str(mapping.transformation or "")
                    ).upper()
                ]
                if not targets:
                    continue
                bound_targets.update(column.upper() for column in targets)
                current = current_attributes.get(variable.name.upper())
                current_resolved = current is not None and current.attribute_value is not None
                candidate_value = variable.resolved_value
                data_type = current.attribute_type if current else variable.inferred_type
                prompt_value = prompt_project_value(str(state.get("prompt") or ""), variable.name, targets, data_type)
                current_value = prompt_value if prompt_value is not None else (current.attribute_value if current_resolved else None)
                value_bindings.append({
                    "name": variable.name,
                    "placeholder": placeholder,
                    "candidate_value": (candidate_value if candidate_value is not None
                                        and valid_typed_project_value(str(candidate_value), data_type) else None),
                    "resolved_value": current_value,
                    "data_type": data_type,
                    "target_columns": targets,
                    "source": "user_prompt" if prompt_value is not None else ("project_attribute" if current_resolved else "historical_sql"),
                    "evidence_ids": [f"sttm_precedent:{best_precedent.get('sttm_id')}"],
                    "applicability": "current_project" if current_value is not None else "historical_firm_unverified",
                    "approval_state": "approved" if current_value is not None else "candidate",
                    "resolution_status": "resolved" if current_value is not None else "unresolved",
                })
        # Historical literal mappings are candidates until their applicability
        # to this project is established by current attributes or a decision.
        literal_candidates = [
            (str(row.get("target_column") or "").upper(), row.get("constant_value"))
            for row in best_precedent.get("mapping_rows") or []
        ]
        literal_candidates.extend(
            (str(mapping.target_alias or "").upper(), historical_constant_value(mapping.constant_value))
            for mapping in (parsed_precedent.column_mappings if parsed_precedent else [])
        )
        from app.agent_tools.firm_value_catalog import catalog_choices, load_catalog

        catalog_value_choices = catalog_choices(
            load_catalog(getattr(self, "_settings", None)),
            target_table,
            target_columns,
        )
        literal_targets: set[str] = set()
        for column, literal in literal_candidates:
            if not column or column not in target_set or column in bound_targets or literal is None:
                continue
            if column in literal_targets:
                continue
            literal_targets.add(column)
            catalog_choice = catalog_value_choices.get(column)
            name = catalog_choice.name if catalog_choice else f"constant_{column}"
            current = current_attributes.get(name.upper()) or current_attributes.get(column)
            current_resolved = current is not None and current.attribute_value is not None
            unresolved_placeholder = isinstance(literal, str) and literal.strip().startswith("$")
            data_type = current.attribute_type if current else (
                target_types.get(column) or type(literal).__name__.upper()
            )
            prompt_value = prompt_project_value(str(state.get("prompt") or ""), name, [column], data_type)
            current_value = prompt_value if prompt_value is not None else (current.attribute_value if current_resolved else None)
            # Ordinary SQL literals are column-mapping evidence, not project
            # configuration. Promote them to a value binding only when the
            # firm-value catalogue identifies the column, or this project/the
            # request explicitly owns a corresponding attribute.
            if catalog_choice is None and current_value is None:
                continue
            value_bindings.append({
                "name": name, "placeholder": f"${name}",
                "candidate_value": (str(literal) if not unresolved_placeholder
                                    and valid_typed_project_value(str(literal), data_type) else None),
                "resolved_value": current_value,
                "data_type": data_type,
                "target_columns": [column],
                "source": "user_prompt" if prompt_value is not None else ("project_attribute" if current_resolved else "historical_sql"),
                "evidence_ids": [f"sttm_precedent:{best_precedent.get('sttm_id')}"],
                "applicability": "current_project" if current_value is not None else "historical_firm_unverified",
                "approval_state": "approved" if current_value is not None else "candidate",
                "resolution_status": "resolved" if current_value is not None else "unresolved",
            })
        plan_candidate = {
            "normalized_intent": str(state.get("prompt") or f"Build a migration to {target_table}").strip(),
            "project_decision": {
                "operation": "create",
                "project_name": f"Deep Agent draft - {target_table.split('.')[-1]}",
                # Marks a placeholder: the project name the user asked for (or
                # the supervisor chose) replaces it when the project is created.
                "name_source": "host_default",
                "run_owned": True,
            },
            "source_preparation": {
                "driving_source": driving_source,
                "intended_grain": "Use the target semantic grain and verify it during join validation.",
                "supporting_sources": [value for value in selected_plan_sources if value != driving_source],
                "source_rationale": {
                    source: (
                        "Driving source selected for target row grain; compared with active SQL in "
                        f"exact-target precedent {best_precedent.get('sttm_id') or 'none'}."
                        if source == driving_source else
                        f"Accepted FIR lineage for {', '.join(sorted(expanded_from_fir[source]['targets']))}; "
                        f"current columns and Workbench relationship path verified. Evidence: "
                        f"{', '.join(sorted(expanded_from_fir[source]['evidence_ids']))}."
                        if source in expanded_from_fir else
                        f"Active SQL or target-column lineage in exact-target precedent "
                        f"{best_precedent.get('sttm_id') or 'none'}; current contract checked. "
                        f"Candidate target columns: {', '.join(sorted(candidate_support.get(source.upper(), {}).get('target_columns') or [])) or 'join/CTE support'}."
                    ) for source in selected_plan_sources
                },
                "selected_columns_by_table": (best_precedent.get("selected_columns_by_table") or {}) if precedent_reference else {},
                "relationships": relationships if precedent_reference else verified_plan_relationships,
                "derived_sources": safe_derived_sources,
                "value_bindings": value_bindings,
                "precedent_reference": precedent_reference,
                "filters": (best_precedent.get("filters") or {}) if precedent_reference else {},
                "target_table": target_table,
                "unresolved_items": ([] if precedent_reference else [
                    *(["A current driving source must be selected from the authenticated catalog."] if not verified_sources else []),
                    *[f"Referenced source requires discovery/authorization: {value}"
                      for value in source_readiness["missing_source_tables"]],
                    *([f"Current relationship evidence has no join path to {verified_sources[0]}: {value}"
                       for value in verified_disconnected] if len(verified_sources) > 1 else []),
                    *historical_column_mismatches,
                ]),
            },
            "auto_map": {
                "target_columns": target_columns,
                "evidence_gaps": source_readiness["unresolved_columns"],
                "mapping_evidence": mapping_evidence,
                "requested_mappings": list(state.get("requested_mappings") or []),
                "mapping_classifications": classifications if precedent_reference else {
                    column: "unresolved" for column in target_columns
                },
                "required_specialists": ["AGT_SOURCE_MAPPING", *(["AGT_TRANSFORMATION_RULE"] if any(value in {"derived", "many_to_one"} for value in classifications.values()) else [])],
                "validation_gates": ["target_contract", "join_cardinality", "sql_compile", "explain", "bounded_preview"],
            },
            "decisions": [{
                "subject": "target",
                "selected_value": target_table,
                "confidence": 1.0,
                "score_margin": 1.0,
                "rationale": "Selected from the caller-visible target contract used for this evidence package.",
                "evidence_ids": [f"table_contract:{target_table.upper()}"],
            }, *[
                {
                    "subject": "value_binding",
                    "decision_key": binding["name"],
                    "selected_value": str(binding["candidate_value"] or "__provide_current__"),
                    "confidence": 0.3,
                    "score_margin": 0.0,
                    "rationale": (
                        f"{binding['name']} appears in historical SQL for "
                        f"{', '.join(binding['target_columns'])}; its value is not verified for the current project."
                    ),
                    "question": (
                        f"Which value should {binding['name']} use for "
                        f"{', '.join(binding['target_columns'])} in this project?"
                    ),
                    "allow_free_text": True,
                    "evidence_ids": binding["evidence_ids"],
                    "alternatives": [
                        {"value": "__provide_current__", "label": "Enter a current value",
                         "description": "Provide the value for this project; the historical value will not be copied.",
                         "impact": "Use the supplied value in this draft plan."},
                    ] if binding["candidate_value"] is not None else [],
                }
                for binding in value_bindings if binding["resolution_status"] != "resolved"
            ], *[
                {
                    "subject": "join",
                    "decision_key": " / ".join(sorted(pair)),
                    "selected_value": "join_0",
                    "selected_label": f"{choices[0].get('join_type') or 'JOIN'} on " + ", ".join(
                        f"{condition.get('left_column')} = {condition.get('right_column')}"
                        for condition in choices[0].get("conditions") or []
                    ),
                    "selected_description": str(choices[0].get("source") or "Current relationship evidence"),
                    "selected_impact": "Uses this join for source preparation and validation probes.",
                    "confidence": 0.5,
                    "score_margin": 0.0,
                    "recommended": True,
                    "rationale": "Current, caller-visible relationship evidence disagrees on join keys or join type.",
                    "question": f"Which join rule applies between {' and '.join(sorted(pair))}?",
                    "evidence_ids": [
                        str(value.get("evidence_ref") or value.get("source") or "verified_relationship")
                        for value in choices[:3]
                    ],
                    "alternatives": [
                        {
                            "value": f"join_{index}",
                            "label": f"{value.get('join_type') or 'JOIN'} on " + ", ".join(
                                f"{condition.get('left_column')} = {condition.get('right_column')}"
                                for condition in value.get("conditions") or []
                            ),
                            "description": str(value.get("source") or "Current relationship evidence"),
                            "impact": "Changes the join used for this source pair and its validation probes.",
                            "evidence_ids": [str(value.get("evidence_ref") or value.get("source") or "verified_relationship")],
                            "relationship": value,
                        }
                        for index, value in enumerate(choices[1:3], start=1)
                    ],
                }
                for pair, choices in relationship_choices.items()
            ]],
            "execution_steps": [
                {"sequence": 1, "title": "Review stored evidence and proposed SQL", "description": "Use stored semantics, FIR, RAG, and exact target precedents to freeze the draft plan.", "phase": "plan_analysis", "query_kind": "mapping", "sql": planned_sql, "dynamic_sql": not bool(planned_sql), "runs_before_approval": True, "runs_after_approval": False},
                {"sequence": 2, "title": "Create run-owned project and STTM draft", "description": "Persist only run-owned draft records for the approved target.", "phase": "draft_execution", "query_kind": "none", "runs_before_approval": False, "runs_after_approval": True, "draft_writes": ["project", "STTM draft"]},
                {"sequence": 3, "title": "Validate sources, joins, and derived sources", "description": "Profile join coverage, cardinality, orphan rate, fanout, and compile every derived SELECT/CTE.", "phase": "draft_execution", "query_kind": "join_check", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True, "draft_writes": ["source preparation"]},
                {"sequence": 4, "title": "Run Auto Map and transformation specialists", "description": "Map every target column using FIR and correction history; invoke transformation rules only for complex rows.", "phase": "draft_execution", "query_kind": "mapping", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True, "draft_writes": ["mapping rows"]},
                {"sequence": 5, "title": "Compile, explain, and optimize SQL", "description": "Compile the canonical mapping, run EXPLAIN, request Analyst repair or optimization when useful, and revalidate.", "phase": "validation", "query_kind": "explain", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True},
                {"sequence": 6, "title": "Run bounded preview and reconciliation", "description": "Execute only the validated SELECT/WITH with configured row, timeout, warehouse, and result-size limits.", "phase": "preview", "query_kind": "preview", "dynamic_sql": True, "runs_before_approval": False, "runs_after_approval": True},
                {"sequence": 7, "title": "Return unpublished draft results", "description": "Return rows, validation, lineage, evidence, receipts, and unresolved items without publishing.", "phase": "delivery", "query_kind": "none", "runs_before_approval": False, "runs_after_approval": True},
            ],
            "evidence_ids_used": evidence_refs,
        }
        semantic_summary = {
            key: semantic.data.get(key)
            for key in (
                "status", "source", "generation_allowed", "bundle_id", "bundle_hash",
                "semantic_view_name", "composed_model_hash", "projection_id", "projection_hash",
                "coverage", "covered_tables", "analyst_ready", "missing_relationships",
                "missing_semantic_assets", "verified_relationships",
                "excluded_relationship_count", "warnings",
            )
            if semantic.data.get(key) not in (None, "", [], {})
        }
        semantic_summary["table_business_context"] = [
            {
                "fqn": item.get("fqn"),
                "description": item.get("description"),
                "domain_summary": item.get("domain_summary"),
                "grain": item.get("grain"),
                "notable_attributes": list(item.get("attributes") or item.get("notable_columns") or [])[:12],
            }
            for item in dict(semantic.data.get("semantic_context") or {}).get("tables") or []
            if isinstance(item, dict)
        ][:discovery_limit]
        compact_fir = {
            "cards": [
                {
                    key: card.get(key)
                    for key in (
                        "learning_id", "target_column", "source_columns", "transformation",
                        "confidence", "evidence_class", "provenance", "subject_key", "summary",
                        "structured_rule", "evidence_ids", "validation_status", "applicability",
                    )
                    if card.get(key) not in (None, "", [], {})
                }
                for card in (fir.data.get("cards") or [])[:50]
                if isinstance(card, dict)
            ],
            "retrieval": fir.data.get("retrieval") or {},
        }
        compact_rag = {
            "hits": [
                {
                    key: hit.get(key)
                    for key in ("doc_id", "title", "doc_folder", "text", "score", "source_type")
                    if hit.get(key) not in (None, "", [], {})
                }
                for hit in (rag.data.get("hits") or [])[:5]
                if isinstance(hit, dict)
            ]
        }
        compact_precedents = [
            {
                "project_id": value.get("project_id"),
                "project_name": value.get("project_name"),
                "sttm_id": value.get("sttm_id"),
                "sttm_name": value.get("sttm_name"),
                "target_table": value.get("target_table"),
                "coverage_percent": value.get("coverage_percent"),
                "source_tables": [table_fqn(item) for item in value.get("source_tables") or []],
                "relationship_count": len(value.get("relationships") or []),
                "derived_source_count": len(value.get("derived_sources") or []),
                "mapping_row_count": len(value.get("mapping_rows") or []),
                "has_mapping_sql": bool(value.get("mapping_sql")),
                "sttm_status": str(value.get("sttm_status") or ""),
                # Bounded per-column source lineage. Cross-target dependency
                # inference compares which source keys old mappings used for
                # each target column; it never needs rules or SQL text.
                "column_lineage": {
                    str(row.get("target_column") or "").upper(): [
                        str(column).upper() for column in (row.get("source_columns") or [])[:6]
                    ]
                    for row in (value.get("mapping_rows") or [])[:300]
                    if row.get("target_column") and row.get("source_columns")
                },
            }
            for value in precedent_details
        ]
        def registry_kind(item: dict[str, Any]) -> str:
            source_name = str(item.get("source") or "").upper()
            return "declared_fk" if source_name in {"FOREIGN_KEY", "DDL", "DECLARED_CONSTRAINT"} else "registry_inferred"

        relationship_graph = self.discover_relationship_graph(
            verified_sources,
            sorted(value for value in visible_tables if within_run_scope(value)),
            [
                *((registry_kind(item), item) for item in active_relationships if isinstance(item, dict)),
                *(("registry_inferred", item) for item in current_relationships.data.get("recommendations") or []
                  if isinstance(item, dict)),
                *(("registry_inferred", item) for item in semantic_relationships if isinstance(item, dict)),
                *(("published_precedent", item) for item in published_relationships if isinstance(item, dict)),
                *(("sql_parsed", item) for item in relationships if isinstance(item, dict)),
            ],
        )
        return ToolResult(
            status="succeeded",
            summary=(
                f"Prepared migration evidence for {target_table} with "
                f"{len(verified_sources)} verified source table(s), {len(target_contract['columns'])} "
                f"target column(s), and {len(fir.data.get('cards') or [])} FIR card(s)."
            ),
            data={
                # Put the compact research decision before the full candidate
                # plan. Large tool responses may be spooled to scratch; the
                # supervisor must see current-source leads without first
                # reading an oversized historical mapping payload.
                "research_summary": {
                    "target_table": target_table,
                    "target_column_count": len(target_columns),
                    "current_source_count": len(verified_sources),
                    "historical_candidates_are_unapproved": True,
                    "semantic_bridge_candidates": list(current_relationships.data.get("expansion_candidates") or []),
                    "published_join_count": len(published_relationships),
                    "structural_precedent_projects": [
                        {key: item.get(key) for key in ("project_id", "project_name", "reasons")}
                        for item in structural_projects
                    ],
                    "output_equivalent_precedents": output_equivalent_precedents,
                    "strongest_precedent_graph": {
                        "sttm_id": best_precedent.get("sttm_id"),
                        "project_id": best_precedent.get("project_id"),
                        "status": best_precedent.get("sttm_status"),
                        "sql_driving_source_candidate": _historical_sql_driving_source(precedent_sql, recovered) if precedent_sql else None,
                        # Which rows the precedent loads (status x type segmentation,
                        # soft deletes, date cut-offs): the default population.
                        "population_rules": precedent_population(precedent_sql)[:8] if precedent_sql else [],
                        "snapshot_driving_source": best_precedent.get("driving_table"),
                        "active_sql_source_count": len(active_sql_references),
                        "current_visible_sql_sources": recovered[:discovery_limit],
                        "expanded_supporting_sources": expanded_from_precedent,
                        "sql_sources_not_in_current_selection": [
                            value for value in recovered
                            if value.upper() not in {source.upper() for source in verified_sources}
                        ][:discovery_limit],
                        "unresolved_sql_references": unresolved_references[:discovery_limit],
                        "active_cte_count": len(active_cte_names),
                        "active_ctes": sorted(active_cte_names)[:discovery_limit],
                        "target_columns_in_sql": len({str(item.target_alias or "").upper()
                                                      for item in parsed_precedent.column_mappings}
                                                     & target_set) if parsed_precedent else 0,
                    },
                    "next_action": (
                        "Inspect and compare current-catalog source contracts, then prepare evidence again "
                        "with a source graph that explains every target attribute. Inspect the strongest "
                        "precedent's active SQL lineage and CTE dependencies; a mapper identifier table "
                        "alone does not establish full target-column coverage."
                        if not verified_sources else
                        "Resolve every selected source through current active joins or a reviewable join decision; "
                        "then validate the per-column lineage and delegate Auto Map."
                    ),
                },
                "source_tables": verified_sources,
                "historical_source_candidates": historical_visible_sources,
                "source_candidate_evidence": source_candidate_evidence,
                "stored_semantic_context": semantic_summary,
                "current_relationships": current_relationships.data,
                "relationship_graph": relationship_graph,
                "published_relationships": published_relationships,
                "relationship_conflicts": sorted(set(relationship_conflicts)),
                "resolved_relationship_conflicts": resolved_join_conflicts,
                "target_contract": {"table": target_table, **target_contract},
                "plan_candidate": plan_candidate,
                "historical_relationship_candidates": relationships,
                "historical_derived_candidates": [
                    {"name": item.get("name"), "purpose": item.get("purpose"), "source": item.get("source")}
                    for item in derived_sources
                ],
                "source_readiness": source_readiness,
                "analyst_eligibility": {
                    "eligible": analyst_eligible,
                    "source_graph_gaps": semantic_disconnected,
                    "unresolved_target_columns_for_mapping_specialists": source_readiness["unresolved_columns"],
                },
                "omitted_source_tables": omitted_sources,
                "fir": compact_fir,
                "precedent_projects": [
                    {
                        "project_id": value.get("project_id"),
                        "status": value.get("status"),
                        "summary": value.get("summary"),
                        "project": value.get("project"),
                        "mapping_count": len(value.get("mappings") or []),
                    }
                    for value in precedents
                ],
                "exact_target_precedents": compact_precedents,
                "workbench_rag": compact_rag,
                "cortex_analyst": {
                    key: analyst.data.get(key)
                    for key in (
                        "text", "sql", "suggestions", "warnings", "verified_query_used",
                        "semantic_view_name", "semantic_bundle_id", "semantic_bundle_hash",
                    )
                    if analyst.data.get(key) not in (None, "", [], {})
                },
            },
            evidence_refs=evidence_refs,
            warnings=[*semantic.warnings, *fir.warnings, *rag.warnings, *analyst.warnings, *(["precedent_sources_not_visible"] if omitted_sources else [])],
            metrics={
                "source_table_count": len(verified_sources),
                "target_column_count": len(target_contract["columns"]),
                "fir_card_count": len(fir.data.get("cards") or []),
                "precedent_project_count": len(precedents),
                "exact_precedent_count": len(precedent_details),
                "rag_hit_count": len(rag.data.get("hits") or []),
                "analyst_used": analyst.status == "succeeded",
            },
        )

    def _resolve_semantic_bundle(
        self,
        *,
        workspace: WorkbenchContextSnapshotV1,
        target_columns: list[str] | None = None,
        source_columns_by_table: dict[str, list[str]] | None = None,
    ) -> tuple[Any, dict[str, Any]]:
        if self._semantic_context is None:
            raise ValueError("semantic_context_unavailable")
        bundle = self._semantic_context.refresh_bundle(
            SemanticContextRefreshRequest(
                selected_source_tables=workspace.source_tables,
                selected_derived_sources=workspace.selected_derived_source_ids(),
                target_table=workspace.target_table,
                relationships=workspace.relationships,
                selected_columns_by_table=workspace.selected_columns_by_table,
                force=False,
            ),
            agent_client=None,
            allow_agent_refresh=False,
        )
        projection = self._semantic_context.get_projection(
            SemanticProjectionRequest(
                bundle_id=bundle.bundle_id,
                bundle_hash=bundle.bundle_hash,
                profile=SemanticProjectionProfile.MAPPING_BATCH,
                target_columns=target_columns or [],
                source_columns_by_table=source_columns_by_table or {},
            )
        )
        return bundle, {
            "projection_id": projection.projection_id,
            "projection_hash": projection.projection_hash,
            "payload": projection.payload,
        }

    @staticmethod
    def _catalog_matches(search_term: str, table_fqn: str) -> bool:
        """Match natural-language search terms against identifier-delimited FQNs."""
        query_tokens = re.findall(r"[a-z0-9]+", search_term.casefold())
        if not query_tokens:
            return True
        identifier_tokens = set(re.findall(r"[a-z0-9]+", table_fqn.casefold()))
        # Models naturally search for "loan income amount calculation" while
        # Snowflake identifiers use underscores. Requiring every term keeps the
        # lookup precise without requiring the model to guess identifier syntax.
        return all(token in identifier_tokens for token in query_tokens)

    def search_catalog(self, search_term: str, limit: int = 10) -> ToolResult:
        self._tool("snowflake.search_catalog")
        with self._domain_lock:
            rows = self._session.sql("SHOW TERSE TABLES IN ACCOUNT").collect()
        candidates: list[dict[str, str]] = []
        for raw in rows:
            row = raw.as_dict() if hasattr(raw, "as_dict") else dict(raw)
            database = str(row.get("database_name") or row.get("DATABASE_NAME") or "")
            schema = str(row.get("schema_name") or row.get("SCHEMA_NAME") or "")
            name = str(row.get("name") or row.get("NAME") or "")
            fqn = ".".join(value for value in (database, schema, name) if value)
            if len(fqn.split(".")) != 3 or not self._catalog_matches(search_term, fqn):
                continue
            candidates.append({"table": fqn, "database": database, "schema": schema, "name": name})
            if len(candidates) >= limit:
                break
        return ToolResult(
            status="succeeded",
            summary=f"Found {len(candidates)} caller-visible table candidate(s).",
            data={"query": search_term, "candidates": candidates},
            evidence_refs=[f"catalog_search:{search_term}"],
            metrics={"candidate_count": len(candidates)},
        )

    def search_catalog_batch(self, search_terms: list[str], limit_per_term: int = 8) -> ToolResult:
        """Resolve several naming variants with one caller-scoped metadata scan."""
        terms = list(dict.fromkeys(
            " ".join(str(term).strip().split())
            for term in search_terms
            if str(term).strip()
        ))[:8]
        if not terms:
            return ToolResult(status="failed", summary="At least one catalog search term is required.", error_code="validation_error")
        bounded_limit = max(1, min(int(limit_per_term), 15))
        self._tool("snowflake.search_catalog_batch")
        with self._domain_lock:
            rows = self._session.sql("SHOW TERSE TABLES IN ACCOUNT").collect()
        matches: dict[str, list[dict[str, str]]] = {term: [] for term in terms}
        for raw in rows:
            row = raw.as_dict() if hasattr(raw, "as_dict") else dict(raw)
            database = str(row.get("database_name") or row.get("DATABASE_NAME") or "")
            schema = str(row.get("schema_name") or row.get("SCHEMA_NAME") or "")
            name = str(row.get("name") or row.get("NAME") or "")
            fqn = ".".join(value for value in (database, schema, name) if value)
            if len(fqn.split(".")) != 3:
                continue
            candidate = {"table": fqn, "database": database, "schema": schema, "name": name}
            for term in terms:
                if len(matches[term]) < bounded_limit and self._catalog_matches(term, fqn):
                    matches[term].append(candidate)
        unique_tables = {
            candidate["table"]
            for values in matches.values()
            for candidate in values
        }
        return ToolResult(
            status="succeeded",
            summary=f"Resolved {len(terms)} naming variant(s) to {len(unique_tables)} caller-visible table candidate(s) in one catalog scan.",
            data={"terms": terms, "matches": matches, "candidates": sorted(unique_tables)},
            evidence_refs=[f"catalog_search:{term}" for term in terms],
            metrics={"term_count": len(terms), "candidate_count": len(unique_tables), "metadata_scans": 1},
        )

    def profile_table(self, state: dict[str, Any], table_fqn: str) -> ToolResult:
        ref = self._table_ref(table_fqn)
        if ref is None:
            raise ValueError("Profiling requires a schema-qualified table name")
        approved = {str(value).upper() for value in state.get("authorized_schemas") or []}
        approved.update(
            ".".join(str(value).strip('"').upper() for value in str(table).split(".")[:2])
            for table in state.get("authorized_source_scope") or []
            if len(str(table).split(".")) == 3
        )
        schema_key = f"{ref.database}.{ref.schema}".upper()
        if schema_key not in approved:
            raise PermissionError(f"Row profiling for {schema_key} requires explicit schema authorization")
        quoted = ".".join(f'"{value}"' for value in (ref.database, ref.schema, ref.table))
        self._tool("snowflake.profile_table")
        with self._domain_lock:
            rows = self._session.sql(f"SELECT COUNT(*) AS ROW_COUNT FROM {quoted}").collect()
        row = rows[0].as_dict() if rows and hasattr(rows[0], "as_dict") else (dict(rows[0]) if rows else {})
        count = int(row.get("ROW_COUNT") or row.get("row_count") or 0)
        return ToolResult(
            status="succeeded",
            summary=f"Profiled {table_fqn} without returning row values.",
            data={"table": table_fqn, "row_count": count},
            evidence_refs=[f"profile:{table_fqn.upper()}"],
            metrics={"row_count": count},
        )

    def execute_read_only_sql(
        self,
        state: dict[str, Any],
        sql: str,
        *,
        max_rows: int = 20,
        allowed_tables: set[str] | None = None,
    ) -> ToolResult:
        """Execute one bounded query through the caller's Snowflake session.

        This is intentionally narrower than a generic SQL tool: only SELECT or
        WITH queries are accepted, physical tables must already be in the run's
        authorized/discovered set, and returned rows are capped at twenty.
        """
        del state
        normalized = str(sql or "").strip().rstrip(";").strip()
        if not normalized:
            raise ValueError("SQL is empty")
        # Generated diagnostics commonly begin with a human-readable SQL
        # comment. Ignore leading comments for statement classification while
        # preserving the single-statement and read-only checks on executable
        # SQL. Previously a safe `-- Diagnostic\nSELECT ...` was denied because
        # the first token was a comment rather than SELECT.
        executable_sql = re.sub(
            r"\A(?:(?:\s*--[^\n]*(?:\n|$))|(?:\s*/\*.*?\*/))*\s*",
            "",
            normalized,
            flags=re.DOTALL,
        ).strip()
        if not executable_sql:
            raise ValueError("SQL contains comments but no executable statement")
        normalized = executable_sql
        if ";" in normalized:
            raise PermissionError("Only one read-only SQL statement may be executed")
        without_literals = re.sub(r"'(?:''|[^'])*'", "''", normalized)
        if not re.match(r"^(?:SELECT|WITH)\b", without_literals, flags=re.IGNORECASE):
            raise PermissionError("Only SELECT or WITH queries may be executed")
        prohibited = re.compile(
            r"\b(?:INSERT|UPDATE|DELETE|MERGE|COPY|CALL|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|PUT|GET|REMOVE|EXECUTE)\b",
            flags=re.IGNORECASE,
        )
        if prohibited.search(without_literals):
            raise PermissionError("The query contains an operation that is not read-only")

        table_matches = re.findall(
                r"\b(?:FROM|JOIN)\s+(?:ONLY\s+)?(?:\"([^\"]+)\"|([A-Za-z_][\w$]*))\."
                r"(?:\"([^\"]+)\"|([A-Za-z_][\w$]*))\."
                r"(?:\"([^\"]+)\"|([A-Za-z_][\w$]*))",
                without_literals,
                flags=re.IGNORECASE,
            )
        from app.core.sql_execution_guard import validate_relations
        physical_refs = validate_relations(normalized, set(allowed_tables or []), allowed_functions=set(getattr(self._settings, "migration_agent_sql_allowed_functions", []) or []))
        if not physical_refs:
            raise PermissionError("The query must reference an authorized physical relation")
        bounded_rows = max(1, min(int(max_rows), self._sql_preview_max_rows))
        preview_query = f"SELECT * FROM (\n{normalized}\n) AS AGENT_READ_ONLY_PREVIEW LIMIT {bounded_rows}"
        self._tool("snowflake.execute_read_only_sql")
        with self._domain_lock:
            dataframe = self._session.sql(preview_query)
            try:
                rows = dataframe.collect(statement_params={
                    "STATEMENT_TIMEOUT_IN_SECONDS": str(self._sql_timeout_seconds),
                    "QUERY_TAG": "deep_migration_agent_read_only_preview",
                })
            except TypeError:
                # Test doubles and older Snowpark clients may not expose
                # statement_params; authorization and row bounds still apply.
                rows = dataframe.collect()
            schema = getattr(dataframe, "schema", None)
        values = [
            json.loads(json.dumps(row.as_dict(recursive=True), default=str))
            if hasattr(row, "as_dict")
            else json.loads(json.dumps(dict(row), default=str))
            for row in rows
        ]
        result_truncated_by_size = False
        while values and len(json.dumps(values, default=str).encode("utf-8")) > self._sql_result_max_bytes:
            values.pop()
            result_truncated_by_size = True
        columns = [
            {"name": field.name, "data_type": str(field.datatype)}
            for field in (getattr(schema, "fields", None) or [])
        ]
        return ToolResult(
            status="succeeded",
            summary=f"Executed the read-only query and returned {len(values)} row(s).",
            data={
                "columns": columns,
                "rows": values,
                "row_count": len(values),
                "max_rows": bounded_rows,
                "truncated": len(rows) >= bounded_rows or result_truncated_by_size,
                "statement_timeout_seconds": self._sql_timeout_seconds,
                "result_max_bytes": self._sql_result_max_bytes,
            },
            evidence_refs=[f"query_preview:{hashlib.sha256(normalized.encode('utf-8')).hexdigest()}"],
            metrics={"row_count": len(values), "max_rows": bounded_rows},
        )

    def retrieve_fir_evidence(
        self,
        state: dict[str, Any],
        target_table: str,
        target_columns: list[str],
    ) -> ToolResult:
        from app.agent_runs.policy import policy_from_state
        policy = policy_from_state(state)
        cards, retrieved = self._learning_cards(
            state=state,
            target_table=target_table,
            target_columns=target_columns,
            budget=policy.retrieval_card_limit,
        )
        return ToolResult(
            status="succeeded",
            summary=f"Retrieved {len(cards)} exact FIR evidence card(s).",
            data={"cards": [card.model_dump(mode="json") for card in cards]},
            evidence_refs=retrieved,
            metrics={"card_count": len(cards)},
        )

    def list_project_templates(self, target_database=None, target_schema=None) -> ToolResult:
        self._tool("project.templates")
        with self._domain_lock:
            templates = self._projects.get_project_templates(target_database=target_database,target_schema=target_schema)
        return ToolResult(status="succeeded",summary="Available configured project templates.",
                          data={"templates":[item.model_dump(mode="json") for item in templates]})

    def search_precedents(self, *, query: str = "", source_tables: list[str] | None = None,
                          target_tables: list[str] | None = None, limit: int = 10) -> ToolResult:
        """Rank earlier projects by exact target, same-named sources and project text."""
        finder = getattr(self._projects, "find_precedent_projects", None)
        if not callable(finder):
            return ToolResult(status="failed", summary="Precedent search is unavailable.", error_code="capability_unavailable")
        terms = list(dict.fromkeys(word for word in re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}", query or "")
                                   if word.lower() not in _GENERIC_REQUEST_WORDS))[:24]
        self._tool("project.find_precedents")
        with self._domain_lock:
            ranked = finder(target_tables=list(target_tables or []), source_tables=list(source_tables or []),
                            terms=terms, limit=limit)
        return ToolResult(
            status="succeeded",
            summary=(f"Found {len(ranked)} precedent project(s)"
                     + (f"; best: {ranked[0]['project_name']} ({'; '.join(ranked[0]['reasons'])})." if ranked else ".")),
            data={"projects": ranked},
            evidence_refs=[f"project:{item['project_id']}" for item in ranked],
            metrics={"project_count": len(ranked)},
        )

    def list_projects(self) -> ToolResult:
        self._tool("project.list")
        with self._domain_lock:
            projects = self._projects.list_projects()
        values = [project.model_dump(mode="json") for project in projects]
        return ToolResult(
            status="succeeded",
            summary=f"Found {len(values)} caller-visible migration project(s).",
            data={"projects": values},
            metrics={"project_count": len(values)},
        )

    def _precedent_detail(self, sttm_id: str, operation: str = "project.get_sttm_detail") -> Any:
        """A precedent STTM's detail, read once per run.

        Research reads the same few precedent mappings for every target and at
        several steps; each read is about six Snowflake queries. Precedents do
        not change during a run, so the first read is reused. Agent drafts are
        never memoized: they are this run's (or its lineage's) working copy.
        """
        key = str(sttm_id or "")
        if not key:
            return None
        cache = self.__dict__.setdefault("_precedent_details", {})
        with self._domain_lock:
            if key in cache:
                return cache[key]
        self._tool(operation)
        with self._domain_lock:
            detail = self._projects.get_sttm_detail(key)
            metadata = dict(getattr(getattr(detail, "sttm", None), "metadata", None) or {})
            if detail is not None and not (metadata.get("draft_only") and metadata.get("migration_run_id")):
                cache[key] = detail
        return detail

    def user_preferences(self, state: dict[str, Any]) -> list[dict[str, Any]]:
        """The user's and the project's saved preferences, for the supervisor's context."""
        if self._learning is None or not hasattr(self._learning, "list_user_preferences"):
            return []
        self._tool("learning.list_preferences")
        with self._domain_lock:
            return self._learning.list_user_preferences(
                user_id=self._actor(state).user_id, project_id=str(state.get("project_id") or "") or None)

    def remember_user_preference(self, state: dict[str, Any], statement: str, scope: str,
                                 subject: str | None = None) -> ToolResult:
        """Save a durable preference the user stated, for this user or everyone in the project."""
        statement = str(statement or "").strip()
        if scope not in {"user", "project"} or not statement:
            return ToolResult(status="failed", summary="A preference needs a statement and a user or project scope.",
                              error_code="invalid_preference")
        project_id = str(state.get("project_id") or "") or None
        if scope == "project" and not project_id:
            return ToolResult(status="failed", summary="There is no project to save a project preference to.",
                              error_code="project_not_found")
        if self._learning is None:
            return ToolResult(status="failed", summary="Learning storage is unavailable.",
                              error_code="capability_unavailable")
        self._tool("learning.record_preference")
        actor = self._actor(state)
        with self._domain_lock:
            learning_id = self._learning.record_user_preference(
                statement, scope=scope, user_id=actor.user_id, project_id=project_id, subject=subject,
                conversation_id=str(state.get("conversation_id") or "") or None, run_id=str(state.get("run_id") or ""))
        self._emit("learning.recorded", "succeeded", f"Saved a {scope} preference: {statement[:160]}",
                   trace_id=f"learning:preference:{learning_id}", kind="learning", label="Saved preference",
                   details={"kind": "user_preference", "learning_id": learning_id, "scope": scope,
                            "statement": statement[:1000], "subject": subject})
        return ToolResult(status="succeeded", summary=f"Saved the {scope} preference.",
                          data={"learning_id": learning_id, "scope": scope})

    def firm_values_inventory(self, state: dict[str, Any], target_tables: list[str]) -> ToolResult:
        """Firm values the planned targets use: which this project holds, which are missing, who holds them."""
        from app.agent_tools.firm_value_catalog import inventory, load_catalog, required_values
        project_id = str(state.get("project_id") or "")
        catalog = load_catalog(getattr(self, "_settings", None))
        required = required_values(catalog, target_tables)
        # Force-new runs plan before the governed workflow creates their
        # destination project. They hold no values yet, but still need one
        # reviewed import decision before mapping begins.
        held = self._firm_values(state, refresh=True) if project_id else {}
        missing = [item["name"] for key, item in required.items() if key not in held]
        holders: list[dict[str, Any]] = []
        if missing and hasattr(self._projects, "firm_value_holders"):
            self._tool("project.firm_value_holders")
            with self._domain_lock:
                holders = self._projects.firm_value_holders(missing)
        result = inventory(catalog, target_tables, held, holders, project_id=project_id)
        return ToolResult(status="succeeded", summary=result["summary"], data=result,
                          metrics={"required": len(result["required"]), "missing": len(result["missing"])})

    def import_firm_values(self, state: dict[str, Any], source_project_id: str, names: list[str] | None = None,
                           *, overwrite: bool = False) -> ToolResult:
        """Copy firm values from another project into this one (all, or the named ones)."""
        from app.schema.project import ProjectAttributeImportRequest
        project_id = str(state.get("project_id") or "")
        if not project_id or not source_project_id:
            return ToolResult(status="failed", summary="Both projects are required.", error_code="project_not_found")
        self._tool("project.list_firm_values")
        with self._domain_lock:
            source = self._projects.list_project_attributes(str(source_project_id))
            before = {item.attribute_name.upper(): item.attribute_value for item in self._projects.list_project_attributes(project_id)}
        wanted = {firm_value_norm(name) for name in names or []}
        chosen = [item for item in source if not wanted or firm_value_norm(item.attribute_name) in wanted]
        if not chosen:
            return ToolResult(status="failed", summary=f"Project {source_project_id} holds none of those firm values.",
                              error_code="firm_values_not_found")
        self._tool("project.import_firm_values")
        with self._domain_lock:
            self._projects.import_project_attributes(
                project_id,
                ProjectAttributeImportRequest(source_project_id=str(source_project_id),
                                              attribute_ids=[item.attribute_id for item in chosen],
                                              overwrite_existing=overwrite),
                user_id=self._actor(state).user_id,
            )
        self.__dict__.setdefault("_firm_value_cache", {}).pop(project_id, None)
        created = [item.attribute_name for item in chosen if item.attribute_name.upper() not in before]
        changed = [item.attribute_name for item in chosen if item.attribute_name.upper() in before
                   and before[item.attribute_name.upper()] != item.attribute_value]
        kept = [item.attribute_name for item in chosen if item.attribute_name.upper() in before
                and before[item.attribute_name.upper()] == item.attribute_value]
        overwritten = changed if overwrite else []
        not_overwritten = [] if overwrite else changed
        return ToolResult(
            status="succeeded",
            summary=(f"Imported {len(created)} firm value(s) from project {source_project_id}"
                     + (f"; overwrote {len(overwritten)}" if overwritten else "")
                     + (f"; kept this project's {len(not_overwritten)} differing value(s)" if not_overwritten else "")
                     + "."),
            data={"created": created, "overwritten": overwritten, "kept_existing": not_overwritten, "unchanged": kept},
            metrics={"created": len(created)},
        )

    def _precedent_project_context(self, state: dict[str, Any], project_id: str) -> ToolResult:
        """A precedent project's context, read once per run.

        Evidence preparation reads the same candidate projects for every target;
        each read lists every STTM with its mapping counts (about six queries).
        The run's own project is always read fresh.
        """
        if str(project_id) == str(state.get("project_id") or ""):
            return self.get_project_context(project_id)
        cache = self.__dict__.setdefault("_precedent_projects", {})
        with self._domain_lock:
            cached = cache.get(str(project_id))
        if cached is not None:
            return cached
        result = self.get_project_context(project_id)
        if result.status == "succeeded":
            with self._domain_lock:
                cache[str(project_id)] = result
        return result

    def get_project_context(self, project_id: str) -> ToolResult:
        self._tool("project.get_context")
        with self._domain_lock:
            project = self._projects.get_project(project_id)
            if project is None:
                return ToolResult(status="failed", summary="The requested project was not found.", error_code="project_not_found")
            mappings = self._projects.list_sttms(project_id)
            precedents = self._projects.list_project_links(project_id)
        return ToolResult(
            status="succeeded",
            summary=f"Read project context with {len(mappings)} mapping(s) and {len(precedents)} precedent link(s).",
            data={
                "project": project.model_dump(mode="json"),
                "mappings": [value.model_dump(mode="json") for value in mappings],
                "precedents": [value.model_dump(mode="json") for value in precedents],
            },
            metrics={"mapping_count": len(mappings), "precedent_count": len(precedents)},
        )

    def _output_equivalent_column_evidence(
        self, equivalents: list[dict[str, Any]], target_columns: list[str], *, limit: int = 2,
    ) -> list[dict[str, Any]]:
        """Column lineage from the SQL of the strongest output-equivalent precedents.

        Lineage stays in the precedent's own schema; consumers compare it by
        table and column name, so another client's copy still corroborates.
        """
        wanted = {str(column).upper(): str(column) for column in target_columns}
        evidence: list[dict[str, Any]] = []

        def literal(value: Any) -> Any:
            """A SQL string literal as its value; anything else as written."""
            if not isinstance(value, str):
                return value
            try:
                parsed_value = parse_one(value, read="snowflake")
            except Exception:  # noqa: BLE001 - keep the SQL text as evidence
                return value
            return parsed_value.this if isinstance(parsed_value, exp.Literal) and parsed_value.is_string else value

        for precedent in list(equivalents or [])[:limit]:
            sttm_id = str(precedent.get("sttm_id") or "")
            if not sttm_id:
                continue
            try:
                detail = self._precedent_detail(sttm_id, "project.read_precedent_sql")
            except Exception:  # noqa: BLE001 - other evidence still applies
                logger.warning("Output-equivalent precedent %s could not be read", sttm_id, exc_info=True)
                continue
            snapshot = dict(getattr(detail, "latest_snapshot", None) or {}) if detail else {}
            sql = str(snapshot.get("mapping_sql") or snapshot.get("raw_mapping_sql") or "").strip()
            parsed = parse_sql_document(sql) if sql else None
            status = str(getattr(getattr(detail, "sttm", None), "status", "") or precedent.get("status") or "").upper()
            for mapping in (parsed.column_mappings if parsed else []):
                target = wanted.get(str(mapping.target_alias or "").upper())
                if not target:
                    continue
                constant = mapping.mapping_mode == "constant"
                evidence.append({
                    "target_column": target,
                    "source_columns": [] if constant else [str(value) for value in mapping.physical_source_columns or []],
                    "transformation": str(mapping.transformation or "")[:2000],
                    "mapping_mode": str(mapping.mapping_mode or "historical"),
                    "constant_value": literal(mapping.constant_value) if constant else None,
                    "evidence_source": "historical_precedent",
                    "evidence_id": f"sttm_precedent:{sttm_id}",
                    "approval_state": "approved" if status in {"COMPLETE", "PUBLISHED"} else "candidate",
                    "applicability": "output_equivalent_requires_current_source_translation",
                })
        return evidence

    def scout_target_sources(self, target_table: str, target_contract: dict[str, Any], *, schemas: list[str],
                             requested_text: str = "", known_designs: list[dict[str, Any]] | None = None,
                             ) -> dict[str, Any]:
        """Model-proposed sources for a target with no precedent, restricted to real tables of ``schemas``.

        ``schemas`` are the schemas the request named or other targets of the
        run already use. Schemas named in the request text are added. One
        metadata query per database builds the inventory (cached per run);
        the proposal is traced with its confidence and any rejected names.
        """
        from app.agent_tools import source_scout

        if not bool(self._setting("migration_agent_source_scout_enabled", True)):
            return {"reason": "disabled", "sources": []}
        wanted = {normalize_fqn(value) for value in schemas if normalize_fqn(value).count(".") == 1}
        target_schema = normalize_fqn(target_table).rsplit(".", 1)[0]
        try:
            databases = {part for part in (source_scout.database_of(value) for value in [target_table, *wanted]) if part}
            with self._domain_lock:
                wanted.update(source_scout.schemas_named_in_text(self._session.sql, databases, requested_text))
            wanted.discard(target_schema)
            if not wanted:
                return {"reason": "no_source_schema", "sources": []}
            key = tuple(sorted(wanted))
            cache = self.__dict__.setdefault("_scout_inventory", {})
            if key not in cache:
                self._tool("snowflake.scan_source_schema")
                with self._domain_lock:
                    cache[key] = source_scout.schema_inventory(
                        self._session.sql, sorted(wanted),
                        max_tables=int(self._setting("migration_agent_source_scout_max_tables", 200)))
            self._tool("cortex.source_scout")
            result = source_scout.scout_sources(
                self._session, self._settings, target=target_table,
                target_columns=source_scout.target_columns_of(target_contract), inventory=cache[key],
                request_text=requested_text, known_designs=known_designs)
        except Exception as exc:  # noqa: BLE001 - the target is reported for review
            logger.warning("Source scouting failed for %s: %s", target_table, type(exc).__name__, exc_info=True)
            return {"reason": f"scout_failed:{type(exc).__name__}", "sources": []}
        payload = {**result.as_dict(), "schemas": sorted(wanted), "inventory_tables": len(cache[key])}
        leaf = target_table.rsplit(".", 1)[-1]
        if result.usable:
            summary = (f"Proposed {len(result.sources)} source(s) for {leaf} from {', '.join(sorted(wanted))} "
                       f"({round(result.confidence * 100)}% confidence), driving source "
                       f"{result.driving_source.rsplit('.', 1)[-1]}; joins are verified next.")
        else:
            summary = f"No confident source proposal for {leaf} ({result.reason})."
        self._emit("trace.action.completed", "succeeded" if result.usable else "needs_review", summary,
                   trace_id=f"source-scout:{target_table}", parent_trace_id=None, kind="decision",
                   label="Propose sources without a precedent", details=payload)
        return payload

    def _precedent_schema_counterparts(self, historical_tables: list[str], target_table: str, *,
                                       requested_text: str = "", selected_scope: list[str] | None = None,
                                       ) -> list[dict[str, Any]]:
        """Schemas that hold a same-named, identically shaped copy of a precedent's sources.

        One metadata query per database, under the caller's role. A failure is
        reported as an empty result in the trace, never as evidence.
        """
        tables = sorted({normalize_fqn(value) for value in historical_tables if normalize_fqn(value).count(".") == 2})
        if not tables:
            return []
        self._tool("snowflake.find_schema_counterparts")
        try:
            with self._domain_lock:
                same_named = same_named_signatures(self._session.sql, tables)
        except Exception as exc:  # noqa: BLE001 - reported, the inspection itself still succeeds
            logger.warning("Schema counterpart lookup failed: %s", type(exc).__name__)
            self._emit("tool.warning", "needs_review", "Could not look for current copies of the precedent's source tables.",
                       trace_id=f"counterparts:{uuid4().hex}", kind="query", label="Find current source copies",
                       details={"error": type(exc).__name__})
            return []
        target_schema = normalize_fqn(target_table).rsplit(".", 1)[0] if normalize_fqn(target_table).count(".") == 2 else ""
        return schema_counterparts(tables, same_named, exclude_schemas=[target_schema] if target_schema else [],
                                   requested_text=requested_text, selected_scope=list(selected_scope or []))

    def inspect_precedent_mapping(self, sttm_id: str, expected_target: str, *, output_equivalent: bool = False,
                                  requested_text: str = "", selected_scope: list[str] | None = None) -> ToolResult:
        """Expose a bounded, read-only source/CTE design for a precedent of ``expected_target``.

        ``output_equivalent`` precedents were matched by the target columns
        their SQL produces; their recorded target may be empty or different.
        """
        detail = self._precedent_detail(sttm_id, "project.inspect_precedent_mapping")
        if detail is None or (not output_equivalent
                              and str(detail.sttm.target_table or "").upper() != expected_target.upper()):
            return ToolResult(status="failed", summary="The precedent does not match the verified target.",
                              error_code="precedent_target_mismatch")
        snapshot = dict(detail.latest_snapshot or {})
        sql = str(snapshot.get("mapping_sql") or snapshot.get("raw_mapping_sql") or "").strip()

        def fqn(value: Any) -> str:
            if isinstance(value, dict):
                value = ".".join(str(value.get(key) or "") for key in ("database", "schema", "table"))
            return str(value or "").strip('"').upper()

        saved_sources = [fqn(value) for value in snapshot.get("source_tables") or detail.sources]
        saved_sources = [value for value in saved_sources if value.count(".") == 2]
        parsed = parse_sql_document(sql) if sql else None
        active_references, active_ctes = _active_sql_lineage(sql, parsed) if parsed else ([], set())
        sql_driver = _historical_sql_driving_source(sql, saved_sources) if sql else None
        saved_driver = fqn(snapshot.get("driving_table")) or None
        ctes = [
            {
                "name": cte.name,
                "tables_referenced": list(cte.tables_referenced),
                "dependencies": list(cte.dependencies),
                "output_columns": [str(item.get("name") or item.get("alias") or "")
                                   for item in cte.output_columns[:20] if isinstance(item, dict)],
            }
            for cte in (parsed.ctes if parsed else [])
            if cte.name.upper() in active_ctes
        ][:24]
        joins = [
            {
                "left_table": item.left_table, "right_table": item.right_table,
                "join_type": item.join_type, "column_pairs": list(item.column_pairs),
                "condition_sql": item.condition[:240],
            }
            for item in (parsed.join_patterns if parsed else [])
            if item.left_table and item.right_table
        ][:32]
        mapping_rows = [
            {
                "target_column": item.get("target_column"),
                "source_columns": list(item.get("source_columns") or [])[:8],
                "mapping_mode": item.get("mapping_mode"),
                "transformation": str(item.get("expression") or item.get("rule") or "")[:240],
            }
            for item in (snapshot.get("mapping_rows") or detail.mapping_rows or [])
            if isinstance(item, dict) and item.get("target_column")
        ][:64]
        value_bindings = [
            {
                "name": item.name,
                "placeholder": f"${item.name}",
                "candidate_value": item.resolved_value,
                "inferred_type": item.inferred_type,
                "approval_state": "candidate",
                "applicability": "historical_firm_unverified",
            }
            for item in (parsed.variable_bindings if parsed else [])
            if item.project_value_candidate
        ][:32]
        counterparts = self._precedent_schema_counterparts(
            [*saved_sources, *[value for value in active_references if str(value).count(".") == 2]],
            expected_target, requested_text=requested_text, selected_scope=selected_scope,
        )
        best_copy = counterparts[0] if counterparts else None
        return ToolResult(
            status="succeeded",
            summary=f"Inspected precedent STTM {sttm_id}: {len(active_references)} active source references and {len(ctes)} active CTEs."
                    + (f" {'Requested source schema' if best_copy['named_in_request'] else 'Best current copy of its sources'}: "
                       f"{best_copy['schema']} ({best_copy['identical_count']} of {best_copy['historical_table_count']} tables identical)."
                       if best_copy else ""),
            data={
                "sttm_id": sttm_id,
                "project_id": detail.sttm.project_id,
                "status": detail.sttm.status,
                "target_table": detail.sttm.target_table,
                "saved_source_tables": saved_sources,
                "saved_driving_source": saved_driver,
                "sql_driving_source_candidate": sql_driver,
                "driving_source_conflict": bool(saved_driver and sql_driver and saved_driver != sql_driver),
                "active_sql_source_references": active_references[:32],
                "active_ctes": ctes,
                "historical_join_candidates": joins,
                "target_column_evidence": mapping_rows,
                "historical_value_bindings": value_bindings,
                # Other schemas with same-named, identically shaped tables: the
                # current client's copy of the same source system.
                "current_schema_counterparts": counterparts,
                "mapping_sql_sha256": hashlib.sha256(sql.encode()).hexdigest() if sql else None,
                "historical_sql_is_single_read_only": is_single_read_only_query(sql) if sql else False,
                "authoritative_for_reuse": str(detail.sttm.status or "").upper() in {"COMPLETE", "PUBLISHED"},
            },
            evidence_refs=[f"sttm_precedent:{sttm_id}"],
            metrics={"active_source_count": len(active_references), "active_cte_count": len(ctes)},
        )

    def coordinate_plan(self, state: dict[str, Any]) -> dict[str, Any]:
        """Accept only the plan authored and host-validated by the Deep supervisor."""
        supplied = dict(state.get("supervisor_plan") or {})
        if supplied.get("_deep_supervisor_validated") is True:
            return {"supervisor_plan": supplied}
        raise RuntimeError("deep_supervisor_plan_required")

    def revise_plan(self, state: dict[str, Any], feedback: str) -> dict[str, Any]:
        """Return revision feedback to the Deep supervisor without invoking Quick Agent."""
        current = dict(state.get("migration_plan") or {})
        self._emit(
            "plan.superseded",
            "needs_review",
            "The approved plan was superseded and returned to the Deep supervisor for revision.",
            trace_id=f"plan-revision:{state.get('run_id')}:{state.get('plan_revision') or 1}",
            parent_trace_id="plan-research",
            kind="plan",
            label="Plan revised",
            details={"superseded_plan_hash": current.get("plan_hash")},
        )
        return {
            "supervisor_plan": {},
            "plan_revision_request": feedback,
            "status": "AWAITING_INPUT",
        }

    @staticmethod
    def _completed_mapping_state(
        state: dict[str, Any], mapping_key: str | None = None
    ) -> tuple[dict[str, Any], dict[str, Any], MappingContextPackageV1]:
        workflow = dict(state.get("workflow_result") or {})
        mappings = list(workflow.get("mapping_results") or [])
        if not mapping_key and len(mappings) > 1:
            raise ValueError("mapping_key_required_for_multiple_mappings")
        selected = next(
            (
                item
                for item in mappings
                if not mapping_key or str(item.get("mapping_key")) == mapping_key
            ),
            None,
        )
        if selected is None:
            raise ValueError("completed_mapping_required")
        validation = dict(selected.get("sql_validation") or {})
        if not validation.get("compile_valid") or not validation.get("compiled_mapping_sql"):
            raise ValueError("validated_mapping_sql_required")
        context = MappingContextPackageV1.model_validate(
            (workflow.get("mapping_context_packages") or {}).get(str(selected.get("mapping_key")))
            or workflow.get("mapping_context_package") or {}
        )
        return workflow, dict(selected), context

    @staticmethod
    def _artifact_mapping_items(mapping: dict[str, Any]) -> list[MappingSqlMappingItem]:
        return [
            MappingSqlMappingItem(
                target_column=str(row.get("target_column") or ""),
                source_columns=[str(value) for value in row.get("source_columns") or []],
                source_dependencies=[str(value) for value in row.get("source_columns") or []],
                expression=str(row.get("expression") or "") or None,
                status="MAPPED" if row.get("status") == "draft" else "UNRESOLVED",
            )
            for row in mapping.get("mapping_rows") or []
            if row.get("target_column")
        ]

    def convert_mapping_to_dbt(
        self, state: dict[str, Any], mapping_key: str | None = None
    ) -> ToolResult:
        if self._dbt_conversion is None:
            return ToolResult(status="failed", summary="dbt conversion is unavailable.", error_code="capability_unavailable")
        workflow, mapping, context = self._completed_mapping_state(state, mapping_key)
        workspace = context.workspace
        target = self._table_ref(str(mapping.get("target_table") or ""))
        if target is None:
            raise ValueError("target_contract_required")
        request = DbtConversionRequest(
            project_id=str(workflow.get("project_id") or "") or None,
            sttm_id=str(mapping.get("sttm_id") or "") or None,
            project_name=workspace.project_name,
            domain_name=workspace.project_domain,
            source_tables=workspace.source_tables,
            target_table=target,
            driving_table=workspace.driving_table,
            selected_derived_sources=workspace.selected_derived_source_ids(),
            relationships=[self._normalized_relationship(value) for value in workspace.relationships],
            selected_columns_by_table=workspace.selected_columns_by_table,
            semantic_bundle_id=(workspace.semantic_bundle.bundle_id if workspace.semantic_bundle else workspace.semantic.bundle_id),
            semantic_bundle_label=(workspace.semantic_bundle.bundle_label if workspace.semantic_bundle else workspace.semantic.bundle_label),
            semantic_view_name=(workspace.semantic_bundle.semantic_view_name if workspace.semantic_bundle else workspace.semantic.view_name),
            source_query_sql=workspace.filters.base_query_sql,
            validated_sql=str(mapping["sql_validation"]["compiled_mapping_sql"]),
            generated_sql=str(mapping["sql_validation"]["compiled_mapping_sql"]),
            mappings=self._artifact_mapping_items(mapping),
            derived_source_lineage=[item.model_dump(mode="json") for item in workspace.derived_sources],
        )
        self._model("specialist.dbt_conversion")
        self._tool("cortex_agent.dbt_conversion")
        self._emit("agent.delegated", "running", "The existing dbt conversion agent is processing the validated mapping artifact.", trace_id=f"dbt:{state.get('run_id')}:{mapping.get('mapping_key')}", parent_trace_id="delivery", kind="delegation", label="AGT_DBT_CONVERSION")
        outcome = self._dbt_conversion.generate(
            request,
            request_id=str(state.get("run_id") or ""),
            actor=ApiActor(user_id=self._actor(state).user_id, role=self._actor(state).effective_role),
            context={"thread_id": state.get("thread_id") or state.get("run_id"), "context_hash": context.context_hash},
            warnings=[],
            meta={"mapping_key": mapping.get("mapping_key")},
        )
        data = outcome.data.model_dump(mode="json")
        if outcome.error is not None:
            return ToolResult(status="failed", summary=outcome.error.detail or outcome.error.title, data=data, error_code=outcome.error.code or "dbt_conversion_failed")
        artifact_refs = [str(item.get("file_path")) for item in data.get("generated_files") or [] if item.get("file_path")]
        self._emit("agent.completed", "succeeded", "The existing dbt conversion agent returned canonical artifacts.", trace_id=f"dbt:{state.get('run_id')}:{mapping.get('mapping_key')}", parent_trace_id="delivery", kind="delegation", label="AGT_DBT_CONVERSION", details={"artifact_refs": artifact_refs})
        self._emit("artifact.created", "succeeded", "Created run-owned dbt artifacts from validated mapping SQL.", trace_id=f"dbt-artifact:{state.get('run_id')}:{mapping.get('mapping_key')}", parent_trace_id="delivery", kind="artifact", label="dbt artifacts", details={"artifact_refs": artifact_refs})
        return ToolResult(status="succeeded", summary=outcome.data.message or "dbt artifacts generated.", data=data, artifact_refs=artifact_refs)

    def generate_mapping_tests(
        self, state: dict[str, Any], mapping_key: str | None = None
    ) -> ToolResult:
        if self._test_generation is None:
            return ToolResult(status="failed", summary="Test generation is unavailable.", error_code="capability_unavailable")
        workflow, mapping, context = self._completed_mapping_state(state, mapping_key)
        workspace = context.workspace
        target = self._table_ref(str(mapping.get("target_table") or ""))
        if target is None:
            raise ValueError("target_contract_required")
        request = TestCaseGenerationRequest(
            project_id=str(workflow.get("project_id") or "") or None,
            sttm_id=str(mapping.get("sttm_id") or "") or None,
            project_name=workspace.project_name,
            domain_name=workspace.project_domain,
            source_tables=workspace.source_tables,
            target_table=target,
            relationships=[self._normalized_relationship(value) for value in workspace.relationships],
            validated_sql=str(mapping["sql_validation"]["compiled_mapping_sql"]),
            mappings=self._artifact_mapping_items(mapping),
        )
        self._model("specialist.test_generation")
        self._tool("cortex_agent.test_generation")
        self._emit("agent.delegated", "running", "The existing test-generation agent is deriving tests from the validated mapping artifact.", trace_id=f"tests:{state.get('run_id')}:{mapping.get('mapping_key')}", parent_trace_id="delivery", kind="delegation", label="AGT_DBT_TEST_GENERATION")
        outcome = self._test_generation.generate(
            request,
            request_id=str(state.get("run_id") or ""),
            actor=ApiActor(user_id=self._actor(state).user_id, role=self._actor(state).effective_role),
            context={"thread_id": state.get("thread_id") or state.get("run_id"), "context_hash": context.context_hash},
            warnings=[],
            meta={"mapping_key": mapping.get("mapping_key")},
        )
        data = outcome.data.model_dump(mode="json")
        if outcome.error is not None:
            return ToolResult(status="failed", summary=outcome.error.detail or outcome.error.title, data=data, error_code=outcome.error.code or "test_generation_failed")
        artifact_refs = [str(item.get("file_path")) for item in data.get("seed_files") or [] if item.get("file_path")]
        from app.migration_workflow.testing import audit_test_artifacts
        data["host_audit"] = audit_test_artifacts(data, list(mapping.get("target_columns") or []))
        if not data["host_audit"]["passed"]:
            return ToolResult(status="needs_input", summary="Generated test candidates require review; tests have not run.",
                data=data, error_code="test_artifact_review_required")
        self._emit("agent.completed", "succeeded", "The existing test-generation agent returned canonical test artifacts.", trace_id=f"tests:{state.get('run_id')}:{mapping.get('mapping_key')}", parent_trace_id="delivery", kind="delegation", label="AGT_DBT_TEST_GENERATION", details={"test_count": len(data.get("test_case_document") or [])})
        self._emit("artifact.created", "succeeded", "Created run-owned mapping test artifacts.", trace_id=f"test-artifact:{state.get('run_id')}:{mapping.get('mapping_key')}", parent_trace_id="delivery", kind="artifact", label="Mapping tests", details={"artifact_refs": artifact_refs, "test_count": len(data.get("test_case_document") or [])})
        return ToolResult(status="succeeded", summary="Mapping test artifacts generated.", data=data, artifact_refs=artifact_refs)

    def run_mapping_contract_tests(self, state: dict[str, Any], mapping_key: str | None = None) -> ToolResult:
        """Execute host-generated contract assertions, never arbitrary specialist scripts."""
        from app.core.sql_execution_guard import sql_hash
        from app.migration_workflow.testing import contract_test_queries, evaluate_test_rows
        workflow, mapping, context = self._completed_mapping_state(state, mapping_key)
        validation = mapping["sql_validation"]
        sql = str(validation.get("compiled_mapping_preview_sql") or "")
        if (not validation.get("preview_valid") or not sql
                or validation.get("validated_preview_sql_hash") != sql_hash(sql)):
            return ToolResult(status="conflict", summary="Validate the current mapping SQL before executing tests.",
                error_code="current_sql_validation_required")
        receipt = mapping.get("mutation_receipt") or {}
        expected_revision = receipt.get("new_revision")
        self._tool("sttm.read_test_revision")
        with self._domain_lock:
            record = self._projects.get_sttm_record(str(mapping.get("sttm_id") or ""))
        if (expected_revision is None or record is None or record.current_version != expected_revision
                or not self._owns_draft(state, record)):
            return ToolResult(status="conflict", summary="The saved mapping revision changed; revalidate before testing.",
                error_code="stale_test_snapshot")
        tests = contract_test_queries(sql, mapping.get("target_column_contracts") or [],
                                     mapping.get("target_key_columns") or [])
        limit = getattr(self._settings, "migration_agent_test_case_limit", 100)
        if len(tests) > limit:
            return ToolResult(status="needs_input", summary="Required contract tests exceed the configured test allowance.",
                data={"required_tests": len(tests), "test_limit": limit}, error_code="test_allowance_exceeded")
        allowed = {table.qualified_name for table in context.workspace.source_tables}
        receipts = []
        for test in tests:
            outcome = self.execute_read_only_sql(state, test["sql"], max_rows=1, allowed_tables=allowed)
            if outcome.status != "succeeded":
                return outcome
            result = {**{k:v for k,v in test.items() if k != "sql"},
                **evaluate_test_rows(outcome.data.get("rows") or []), "artifact_revision": expected_revision,
                "context_hash": context.context_hash}
            receipts.append(result)
            self._emit("mapping.test.executed", result["status"], "Executed a read-only mapping contract assertion.",
                trace_id=f"test:{state['run_id']}:{mapping['mapping_key']}:{test['test_id']}",
                parent_trace_id="validation", kind="validation", label="Mapping contract test", details=result)
        passed = bool(receipts) and all(item["status"] == "passed" for item in receipts)
        return ToolResult(status="succeeded" if passed else "needs_input",
            summary="Mapping contract assertions passed." if passed else "Contract assertions need review or more test coverage.",
            data={"test_receipts": receipts, "all_passed": passed, "scope": "target_nullability_and_keys",
                  "business_correctness_verified": False, "generated_seed_scripts_executed": False})

    def search_workbench_rag(
        self,
        state: dict[str, Any],
        query: str,
        limit: int = 5,
        *,
        folders: list[str] | None = None,
        semantic_bundle_id: str | None = None,
        semantic_view_name: str | None = None,
    ) -> ToolResult:
        if self._rag_search is None:
            return ToolResult(status="failed", summary="Workbench RAG search is unavailable.", error_code="capability_unavailable")
        page = WorkbenchContextSnapshotV1.model_validate(state.get("page_context") or {})
        semantic = page.semantic_bundle or page.semantic
        self._tool("cortex_search.workbench_rag")
        try:
            result = self._rag_search.search(ConversationSearchRequestData(
                query=query,
                folders=folders or [],
                limit=max(1, min(limit, 10)),
                semantic_bundle_id=semantic_bundle_id or getattr(semantic, "bundle_id", None),
                semantic_view_name=(
                    semantic_view_name
                    or getattr(semantic, "semantic_view_name", None)
                    or getattr(semantic, "view_name", None)
                ),
            ))
        except SnowflakeQueryError:
            # Search is supporting evidence, not the source/target validity
            # boundary. Keep the failure explicit and preserve verified contracts.
            return ToolResult(status="failed", summary="Stored knowledge search is unavailable; no search evidence was added.",
                              error_code="knowledge_search_unavailable", warnings=["knowledge_search_unavailable"],
                              data={"hits": []})
        data = result.model_dump(mode="json")
        return ToolResult(
            status="succeeded",
            summary=f"Found {len(result.hits)} governed Workbench knowledge result(s).",
            data=data,
            evidence_refs=[hit.doc_id for hit in result.hits],
        )

    def ask_sql_analyst(
        self,
        state: dict[str, Any],
        question: str,
        *,
        source_tables: list[str] | None = None,
        target_table: str | None = None,
        relationships: list[dict[str, Any]] | None = None,
        prefer_stored_model: bool = False,
    ) -> ToolResult:
        if self._analyst is None:
            return ToolResult(status="failed", summary="Cortex Analyst is unavailable.", error_code="capability_unavailable")
        page = WorkbenchContextSnapshotV1.model_validate(state.get("page_context") or {})
        selected_sources = [
            ref for value in (source_tables or []) if (ref := self._table_ref(value)) is not None
        ] or page.source_tables
        selected_target = self._table_ref(target_table) if target_table else page.target_table
        view_name: str | None = None
        semantic_model_yaml: str | None = None
        bundle_id: str | None = None
        bundle_hash: str | None = None
        if selected_sources or selected_target:
            if self._semantic_context is None:
                return ToolResult(status="failed", summary="Stored semantic context is unavailable.", error_code="semantic_context_unavailable", warnings=["semantic_context_unavailable"])
            try:
                with self._domain_lock:
                    bundle = self._semantic_context.refresh_bundle(
                        SemanticContextRefreshRequest(
                            selected_source_tables=selected_sources,
                            target_table=selected_target,
                            relationships=relationships if relationships is not None else page.relationships,
                            selected_columns_by_table=page.selected_columns_by_table,
                            force=False,
                        ),
                        agent_client=None,
                        allow_agent_refresh=False,
                    )
                view_name = bundle.semantic_view_name
                semantic_model_yaml = bundle.semantic_model_yaml
                if prefer_stored_model:
                    view_name = None
                bundle_id = bundle.bundle_id
                bundle_hash = bundle.bundle_hash
            except Exception:
                return ToolResult(status="failed", summary="The selected tables do not have a complete stored semantic bundle for Cortex Analyst.", error_code="semantic_context_unavailable", warnings=["semantic_context_unavailable"])
        else:
            semantic = page.semantic_bundle or page.semantic
            view_name = getattr(semantic, "semantic_view_name", None) or getattr(semantic, "view_name", None)
            bundle_id = getattr(semantic, "bundle_id", None)
            bundle_hash = getattr(semantic, "bundle_hash", None)
            if self._semantic_context is not None and (bundle_id or bundle_hash):
                with self._domain_lock:
                    stored_bundle = self._semantic_context.get_bundle(
                        bundle_id=bundle_id, bundle_hash=bundle_hash
                    )
                if stored_bundle:
                    view_name = view_name or stored_bundle.get("semantic_view_name")
                    semantic_model_yaml = stored_bundle.get("semantic_model_yaml")
        if prefer_stored_model:
            view_name = None
        if not view_name and not semantic_model_yaml:
            return ToolResult(
                status="failed",
                summary="A stored semantic view or composed stored semantic bundle is required for Cortex Analyst; no semantic generation was attempted.",
                error_code="semantic_context_unavailable",
                warnings=["semantic_context_unavailable"],
            )
        self._model("specialist.sql_analyst")
        self._tool("cortex_analyst.ask")
        response = self._analyst.ask(
            question=question,
            semantic_view=view_name,
            semantic_model_yaml=semantic_model_yaml,
        )
        return ToolResult(
            status="succeeded",
            summary=response.text or "Cortex Analyst returned a governed answer.",
            data={
                "text": response.text,
                "sql": response.sql,
                "suggestions": response.suggestions,
                "warnings": response.warnings,
                "verified_query_used": response.verified_query_used,
                "semantic_view_name": view_name,
                "semantic_bundle_id": bundle_id,
                "semantic_bundle_hash": bundle_hash,
            },
            evidence_refs=[
                value for value in (view_name, bundle_id, bundle_hash) if value
            ],
        )

    def _specialist_learning(self, state: dict[str, Any], target_table: str, target_columns: list[str],
                             source_tables: list[str], source_contracts: dict[str, Any]) -> dict[str, Any]:
        """Recipes and stored FIR recommendations for the specialists; reads only, no model call."""
        if not getattr(self._settings, "migration_agent_specialist_fir_context_enabled", True):
            return {}
        grain = (state.get("migration_plan") or {}).get("source_preparation", {}).get("intended_grain")
        # Types and grain let a recipe learned elsewhere be checked against these sources.
        profiles = [{"physical_name": str(item.get("name") or ""), "type": item.get("type"), "grain": grain}
                    for contract in (source_contracts or {}).values()
                    for item in contract.get("column_contracts") or [] if isinstance(item, dict) and item.get("name")]
        self._tool("fir.retrieve_target_patterns")
        try:
            with self._domain_lock:
                result = self._learning.get_specialist_learning(
                    project_id=str(state.get("project_id") or ""), target_table=target_table,
                    target_columns=target_columns, source_tables=source_tables,
                    source_columns=[item["physical_name"] for item in profiles],
                    source_column_profiles=profiles,
                    linked_project_ids=list(state.get("precedent_project_ids") or []),
                )
        except Exception:
            logger.warning("Specialist FIR context is unavailable; mapping continues without it", exc_info=True)
            return {}
        self._emit("automap.fir_context", "succeeded",
                   f"{len(result['target_mapping_patterns'])} learned recipe(s) and "
                   f"{len(result['fir_recommendations'])} FIR recommendation(s) for {target_table.rsplit('.', 1)[-1]}.",
                   parent_trace_id="mapping-execution", kind="learning", label="FIR recipes",
                   pattern_ids=result["retrieved_pattern_ids"][:40],
                   recommendation_ids=result["retrieved_recommendation_ids"])
        return result

    def _learning_cards(
        self,
        *,
        state: dict[str, Any],
        target_table: str,
        target_columns: list[str],
        budget: int,
    ) -> tuple[list[LearningCard], list[str]]:
        if self._learning is None or not target_columns:
            return [], []
        cache_key = (str(state.get("project_id")),target_table,tuple(target_columns),budget,
                     str((state.get("mapping_context_package") or {}).get("context_hash")))
        with self._domain_lock:
            if cache_key in self._learning_card_cache:
                return self._learning_card_cache[cache_key]
            self._tool("fir.retrieve_exact")
            subject_keys = [target_column_subject(target_table, column) for column in target_columns]
            context = self._learning.get_learning_context(
                task="migration_mapping",subject_keys=subject_keys,project_id=str(state.get("project_id") or ""),
                linked_project_ids=list(state.get("precedent_project_ids") or []),budget=budget)
        cards = [
            LearningCard(
                learning_id=str(card["learning_id"]),
                subject_type=str(card.get("subject_type") or "target_column"),
                subject_key=str(card.get("subject_key") or ""),
                claim_key=str(card.get("claim_key") or ""),
                summary=str(card.get("summary") or ""),
                confidence=float(card.get("confidence") or 0),
                validation_status=str(card.get("trust_stage") or "evidence"),
                structured_rule=dict(card.get("structured_rule") or {}),
                evidence_ids=list(card.get("evidence_ids") or []),
            )
            for card in context.get("cards") or []
        ]
        result = cards, list(context.get("retrieved_learning_ids") or [])
        with self._domain_lock:
            self._learning_card_cache[cache_key] = result
        return result

    def _record_decision(
        self,
        *,
        state: dict[str, Any],
        mapping: dict[str, Any],
        retrieved: list[str],
        used: list[str],
        evidence: list[str],
        rows: list[dict[str, Any]],
    ) -> None:
        self._tool("fir.record_decision")
        context = MappingContextPackageV1.model_validate(state.get("mapping_context_package") or {})
        workspace = context.workspace
        relationship_dependencies = [
            str(value.get("relationship_id") or value.get("id") or value.get("name") or "")
            or hashlib.sha256(
                json.dumps(value, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()
            for value in workspace.relationships
        ]
        recipes = [
            FIRMappingRecipeV1(
                recipe_id=(
                    "fir_recipe_"
                    + hashlib.sha256(
                        f"{state['run_id']}:{mapping['mapping_key']}:{row['target_column']}".encode("utf-8")
                    ).hexdigest()[:40]
                ),
                target_fqn=str(mapping["target_table"]),
                target_column=str(row["target_column"]),
                source_tables=[table.qualified_name for table in workspace.source_tables],
                source_columns=[str(value) for value in row.get("source_columns") or []],
                driving_source=(
                    workspace.driving_table.qualified_name if workspace.driving_table else None
                ),
                row_grain=(state.get("migration_plan") or {}).get("source_preparation", {}).get("intended_grain"),
                relationship_dependencies=relationship_dependencies,
                derived_source_dependencies=[value.id for value in workspace.derived_sources],
                transformation_expression=str(row.get("expression") or "") or None,
                conditions=[
                    value
                    for value in [
                        workspace.filters.filter_sql,
                        workspace.filters.group_by_sql,
                        workspace.filters.order_by_sql,
                    ]
                    if value
                ],
                retrieved_evidence_ids=list(retrieved),
                used_evidence_ids=sorted({
                    *[str(value) for value in row.get("used_learning_ids") or []],
                    *[str(value) for value in row.get("evidence_ids") or []],
                }),
                confidence=float(row.get("confidence") or 0),
                validation_outcome="pending",
                artifact_version=str(state.get("manifest_version") or ""),
                quarantined=True,
            ).model_dump(mode="json")
            for row in rows
        ]
        sql = """INSERT INTO TBL_AGENT_DECISIONS
            (DECISION_ID, RUN_ID, STEP_ID, SUBJECT_TYPE, SUBJECT_KEY, CLAIM_KEY,
             RETRIEVED_LEARNING_IDS, USED_LEARNING_IDS, EVIDENCE_IDS, DECISION_PAYLOAD)
            SELECT ?, ?, ?, ?, ?, ?, PARSE_JSON(?), PARSE_JSON(?), PARSE_JSON(?), PARSE_JSON(?)"""
        params = [
            f"decision_{uuid4().hex}", str(state["run_id"]), f"map:{mapping['mapping_key']}",
            "target_table", str(mapping["target_table"]), "column_mapping_recipes",
            json.dumps(retrieved), json.dumps(used), json.dumps(evidence),
            json.dumps({"rows": rows, "recipes": recipes, "trust_stage": "candidate"}),
        ]
        with self._domain_lock:
            self._session.sql(sql, params).collect()

    def _record_follow_up_corrections(self, state: dict[str, Any], mapping: dict[str, Any],
                                      previous_rows: list[dict[str, Any]], rows: list[dict[str, Any]]) -> None:
        """A validated follow-up change to a column becomes a mapping correction.

        This is the same learning the mapping page records when a user edits a
        row, so later Auto Map and Deep Agent runs retrieve it through the
        correction history. Only columns the follow-up re-mapped are compared.
        """
        if self._learning is None:
            return
        def recipe(row: dict[str, Any]) -> list[str]:
            # Grid rows (the parent draft) and agent rows spell the same choice
            # differently; compare bare column names and whitespace-free SQL.
            expression = str(row.get("expression") or "").strip()
            if row.get("mapping_mode") == "attribute" and row.get("attribute_name"):
                return [f"${str(row['attribute_name']).upper()}"]
            if row.get("mapping_mode") == "constant":
                return [repr(row.get("constant_value"))]
            if expression.startswith("$") and re.fullmatch(r"\$\w+", expression):
                return [expression.upper()]
            if expression and not re.fullmatch(r'[\w."]+', expression):
                return [re.sub(r"\s+", "", expression).upper()]
            return sorted(str(value).rsplit(".", 1)[-1].strip('"').upper()
                          for value in row.get("source_columns") or [expression] if value)
        before = {str(row.get("target_column") or "").upper(): row for row in previous_rows}
        prompt = str(state.get("prompt") or "")[:200]
        recorded = []
        for row in rows:
            column = str(row.get("target_column") or "")
            if row.get("status") != "draft" or row.get("carried_from_run_id"):
                continue
            old = before.get(column.upper())
            if old is None or not recipe(old) or recipe(old) == recipe(row):
                continue
            try:
                learning_id = self._learning.record_mapping_correction(
                    target_column=column, incorrect_source=recipe(old), correct_source=recipe(row),
                    error_category="follow_up_change", prevention_hint=f"Changed in a follow-up request: {prompt}",
                    project_id=str(state.get("project_id") or ""), sttm_id=str(mapping.get("sttm_id") or ""),
                    user_id=self._actor(state).user_id, target_table=str(mapping.get("target_table") or ""),
                )
                recorded.append({"learning_id": learning_id, "column": column,
                                 "before": recipe(old), "after": recipe(row)})
            except Exception:
                logger.debug("Follow-up correction was not recorded", exc_info=True)
        if recorded:
            self._emit(
                "learning.recorded", "succeeded",
                f"Learned {len(recorded)} correction(s) for {self._short_name(mapping.get('target_table'))}.",
                trace_id=f"learning:corrections:{mapping.get('mapping_key')}", kind="learning",
                label="Learned from this change",
                details={"kind": "mapping_correction", "target_table": mapping.get("target_table"),
                         "corrections": recorded},
            )

    @staticmethod
    def _owns_draft(state: dict[str, Any], record: Any) -> bool:
        """The draft was created by this run or, for a follow-up, by its owned lineage."""
        owner = str((getattr(record, "metadata", None) or {}).get("migration_run_id") or "")
        return bool(owner) and owner in {str(state.get("run_id") or ""), *map(str, state.get("run_lineage") or [])}

    def _record_learning_outcomes(self, state: dict[str, Any], mapping: dict[str, Any],
                                  rows: list[dict[str, Any]], *, validated: bool) -> None:
        """Credit the learnings, FIR recommendations and patterns a compiled mapping actually cited.

        Outcomes are recorded once the SQL has compiled and previewed (or failed
        to), not when the specialist cites them. A mapped row that compiled and
        previewed counts as a success for everything it cited; an unresolved row
        or a failed compile counts as a use without success.
        """
        # The three id spaces are disjoint: learnings are lrn_*, FIR target
        # patterns tmp_*, FIR recommendations UUIDs.
        uuid_like = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)
        learning_outcomes: dict[str, bool] = {}
        recommendation_outcomes: dict[str, bool] = {}
        pattern_outcomes: dict[str, bool] = {}
        for row in rows:
            success = validated and row.get("status") == "draft"
            cited = {str(value) for value in [*(row.get("used_learning_ids") or []), *(row.get("evidence_ids") or []),
                                              *(row.get("used_recommendation_ids") or [])] if value}
            for value in cited:
                target = (recommendation_outcomes if uuid_like.match(value)
                          else pattern_outcomes if value.startswith("tmp_")
                          else learning_outcomes if value.startswith("lrn_") else None)
                if target is not None:
                    target[value] = target.get(value, False) or success
        if self._learning is not None:
            for learning_id, success in learning_outcomes.items():
                try:
                    self._learning.track_learning_usage(learning_id, was_successful=success)
                except Exception:
                    logger.debug("Learning usage was not recorded", exc_info=True)
        if not recommendation_outcomes and not pattern_outcomes:
            return
        from app.core.conversation_memory import ConversationMemoryService
        memory = ConversationMemoryService(self._session, self._settings)
        context_key = f"migration:{state.get('run_id')}:{mapping.get('mapping_key')}"
        for recommendation_id, success in recommendation_outcomes.items():
            try:
                memory.record_fir_recommendation_outcome(
                    recommendation_id=recommendation_id, outcome_type="validated" if success else "used",
                    context_key=context_key, request_id=f"{state.get('run_id')}:{mapping.get('mapping_key')}",
                    user_id=self._actor(state).user_id,
                    payload={"agent_name": "deep_agent", "sttm_id": mapping.get("sttm_id"),
                             "target_table": mapping.get("target_table")},
                )
            except Exception:
                logger.debug("FIR recommendation outcome was not recorded", exc_info=True)
        if pattern_outcomes:
            # A validated use supports the pattern; nothing is contradicted by a
            # failed compile alone, because the failure may lie elsewhere.
            supported = sorted(pattern_id for pattern_id, success in pattern_outcomes.items() if success)
            if supported:
                table = self._settings.qualify_metadata_object_name("TBL_FIR_TARGET_MAPPING_PATTERNS")
                placeholders = ", ".join("?" for _ in supported)
                try:
                    with self._domain_lock:
                        self._session.sql(
                            f"UPDATE {table} SET SUPPORT_COUNT = COALESCE(SUPPORT_COUNT, 0) + 1, "
                            f"UPDATED_AT = CURRENT_TIMESTAMP() WHERE PATTERN_ID IN ({placeholders})",
                            supported,
                        ).collect()
                except Exception:
                    logger.debug("Pattern support was not recorded", exc_info=True)

    def _record_validation_report(self, state: dict[str, Any], report: dict[str, Any]) -> None:
        self._tool("validation.record_artifact")
        sql = """INSERT INTO TBL_AGENT_DECISIONS
            (DECISION_ID, RUN_ID, STEP_ID, SUBJECT_TYPE, SUBJECT_KEY, CLAIM_KEY,
             RETRIEVED_LEARNING_IDS, USED_LEARNING_IDS, EVIDENCE_IDS, DECISION_PAYLOAD)
            SELECT ?, ?, ?, ?, ?, ?, PARSE_JSON('[]'), PARSE_JSON('[]'), PARSE_JSON('[]'), PARSE_JSON(?)"""
        with self._domain_lock:
            self._session.sql(sql, [
                f"decision_{uuid4().hex}", str(state["run_id"]), "cross_mapping_validation",
                "validation_artifact", f"validation:{state['run_id']}", "cross_mapping_gates",
                json.dumps(report),
            ]).collect()

    @staticmethod
    def _redact_sql_literals(sql: str) -> str:
        redacted = re.sub(r"'(?:''|[^'])*'", "'<redacted>'", sql)
        return re.sub(r"\b\d+(?:\.\d+)?\b", "?", redacted)

    def _canonical_design(
        self,
        *,
        state: dict[str, Any],
        source_tables: list[str],
        source_columns: dict[str, list[str]],
        workspace: WorkbenchContextSnapshotV1 | None = None,
    ) -> dict[str, Any]:
        """The prepared source design in the shape the mapping page compiles.

        Relation ids, aliases, derived-source nodes and join edges are built
        exactly as ``buildCompilerRelationGraph`` builds them, so a user who
        opens the draft recompiles the same SELECT the agent validated.
        """
        if workspace is None:
            workspace = MappingContextPackageV1.model_validate(
                state.get("mapping_context_package") or {}
            ).workspace
        try:
            stored_graph = dict(workspace.relation_graph or {})
            stored = RelationGraphContext.model_validate(stored_graph) if stored_graph else RelationGraphContext()
        except Exception:
            stored = RelationGraphContext()
        tables = [ref for table in source_tables if (ref := self._table_ref(table)) is not None]
        columns_by_table = {}
        for table in tables:
            contract = self._contract_cache_columns(table.qualified_name)
            names = source_columns.get(table.qualified_name) or source_columns.get(table.qualified_name.upper()) or []
            columns_by_table[table.qualified_name] = [
                {"name": name, "data_type": contract.get(str(name).upper())} for name in names
            ]
        driving_fqn = (
            workspace.driving_table.qualified_name if workspace.driving_table
            else (tables[0].qualified_name if tables else "")
        )
        derived = [canonical_derived_source(item) for item in workspace.derived_sources]
        derived_keys = {
            key.upper(): item["id"]
            for item in derived
            for key in (item["id"], item["name"], item["alias"], derived_reference_prefix(item["name"]))
            if key
        }
        physical_relationships: list[dict[str, Any]] = []
        derived_edges: list[dict[str, Any]] = []
        lookup_rewrites: dict[str, str] = {}
        derived_ids_known = {item["id"] for item in derived}
        selected_derived_driver = workspace.driving_relation_id if workspace.driving_relation_id in derived_ids_known else None
        for raw in workspace.relationships:
            # A side may be replaced by a one-row-per-key CTE (a lookup that
            # repeats its keys, or a child reduced to one row per parent).
            overrides = {
                "left": str(raw.get("left_relation_override") or ""),
                "right": str(raw.get("right_relation_override") or raw.get("dedup_relation_id") or ""),
            }
            if selected_derived_driver:
                for side in ("left", "right"):
                    if snapshot_table_fqn(raw.get(f"{side}_table")).upper() == driving_fqn.upper():
                        overrides[side] = selected_derived_driver
            if any(value in derived_ids_known for value in overrides.values()):
                relationship = self._normalized_relationship(raw)
                ends = {"left": relationship.left_table, "right": relationship.right_table}
                edge = {**relationship.model_dump(mode="json"), "literal_filters": []}
                for side, table in ends.items():
                    replacement = overrides[side] if overrides[side] in derived_ids_known else ""
                    edge[f"{side}_relation_id"] = replacement or table.qualified_name
                    if replacement:
                        prefix = derived_reference_prefix(next(item["name"] for item in derived if item["id"] == replacement))
                        for key in (table.qualified_name, f"{table.schema}.{table.table}", table.table,
                                    relation_alias_for(table.qualified_name)):
                            lookup_rewrites[key.upper()] = prefix
                derived_edges.append(edge)
                continue
            left_key = str(raw.get("left_relation_id") or snapshot_table_fqn(raw.get("left_table"))).upper()
            right_key = str(raw.get("right_relation_id") or snapshot_table_fqn(raw.get("right_table"))).upper()
            if left_key in derived_keys or right_key in derived_keys:
                derived_edges.append({
                    **raw,
                    "left_relation_id": derived_keys.get(left_key, snapshot_table_fqn(raw.get("left_table")) or left_key),
                    "right_relation_id": derived_keys.get(right_key, snapshot_table_fqn(raw.get("right_table")) or right_key),
                })
                continue
            physical_relationships.append(self._normalized_relationship(raw).model_dump(mode="json"))
        derived_ids = {item["id"] for item in derived}
        for edge in stored.edges:
            if (edge.left_relation_id in derived_ids or edge.right_relation_id in derived_ids) and not any(
                {item["left_relation_id"], item["right_relation_id"]} == {edge.left_relation_id, edge.right_relation_id}
                for item in derived_edges
            ):
                derived_edges.append(edge.model_dump(mode="json"))
        lifted = lift_join_filters(
            physical_relationships, source_columns_by_table=columns_by_table, driving_fqn=driving_fqn,
        )
        graph_payload = snapshot_relation_graph(
            source_tables=tables,
            source_columns_by_table=columns_by_table,
            derived_sources=[*derived, *lifted["derived_sources"]],
            relationships=lifted["relationships"],
            derived_edges=[*derived_edges, *lifted["derived_edges"]],
            value_bindings=stored.value_bindings,
        )
        graph = RelationGraphContext.model_validate(graph_payload)
        node_ids = {node.relation_id.upper(): node.relation_id for node in graph.nodes}
        driving_id = node_ids.get(str(selected_derived_driver or driving_fqn).upper())
        if selected_derived_driver:
            driver = next(item for item in derived if item["id"] == selected_derived_driver)
            prefix = derived_reference_prefix(driver["name"])
            for key in (driving_fqn, relation_alias_for(driving_fqn), driving_fqn.rsplit(".", 1)[-1]):
                lookup_rewrites[key.upper()] = prefix
        if not driving_id:
            raise ValueError("The prepared source graph has no valid driving relation")
        graph = graph.model_copy(update={"edges": self._edges_oriented_from(driving_id, list(graph.edges))})
        return {
            "graph": graph,
            "driving_id": driving_id,
            "driving_table": driving_fqn,
            "derived_sources": [*derived, *lifted["derived_sources"]],
            "relationships": lifted["relationships"],
            "rewrites": {**lifted["rewrites"], **lookup_rewrites, **{
                key: derived_reference_prefix(item["name"])
                for item in derived
                for key in (item["id"].upper(), str(item["name"]).upper(), item["alias"].upper())
            }},
            "parity_warnings": lifted["warnings"],
        }

    def _contract_cache_columns(self, table: str) -> dict[str, str]:
        """Column types from contracts already read in this run; never a new query."""
        key = normalize_fqn(table)
        with self._domain_lock:
            cached = self._knowledge.contract(key) if self._knowledge is not None else self._contract_cache.get(key)
        if not isinstance(cached, dict):
            return {}
        return {
            str(item.get("name") or "").upper(): str(item.get("type") or "")
            for item in cached.get("column_contracts") or []
            if isinstance(item, dict) and item.get("name")
        }

    def _compiler_graph(
        self,
        *,
        state: dict[str, Any],
        source_tables: list[str],
        source_columns: dict[str, list[str]],
    ) -> tuple[RelationGraphContext, dict[str, str], str, dict[str, list[str]]]:
        design = self._canonical_design(state=state, source_tables=source_tables, source_columns=source_columns)
        graph = design["graph"]
        aliases: dict[str, str] = {}
        derived_columns: dict[str, list[str]] = {}
        for node in graph.nodes:
            if node.table is not None:
                aliases[node.table.qualified_name.upper()] = node.alias
                aliases[node.table.table.upper()] = node.alias
            else:
                aliases[node.relation_id.upper()] = node.alias
                derived_columns[node.relation_id] = [
                    str(item.get("name") or "") for item in node.output_columns if isinstance(item, dict)
                ]
        graph = graph.model_copy(update={"value_bindings": self._precedent_value_bindings(state, list(graph.value_bindings))})
        return graph, aliases, design["driving_id"], derived_columns

    def _precedent_value_bindings(self, state: dict[str, Any], bindings: list[ValueBinding]) -> list[ValueBinding]:
        """Add the project's firm values and the accepted precedent's values to the graph's value bindings."""
        existing = {item.value.upper() for item in bindings}
        for firm_value in self._firm_values(state).values():
            item = firm_value_binding(firm_value)
            if item["value"].upper() not in existing:
                bindings.append(ValueBinding.model_validate(item))
                existing.add(item["value"].upper())
        accepted = dict(state.get("accepted_precedent") or {})
        if not accepted:
            return bindings
        detail = self._precedent_detail(str(accepted.get("sttm_id") or ""), "project.read_precedent_value_bindings")
        with self._domain_lock:
            current_attributes = self._projects.list_project_attributes(str(state.get("project_id") or ""))
        sql = str((detail.latest_snapshot or {}).get("mapping_sql") or (detail.latest_snapshot or {}).get("raw_mapping_sql") or "") if detail else ""
        if not detail or hashlib.sha256(sql.strip().encode("utf-8")).hexdigest() != accepted.get("sql_sha256"):
            raise ValueError("Accepted precedent changed before value binding")
        attributes = {item.attribute_name.upper(): item for item in current_attributes}
        for variable in parse_sql_document(sql).variable_bindings:
            if not variable.project_value_candidate or not variable.resolved_value:
                continue
            placeholder = f"${variable.name}"
            if placeholder.upper() in existing:
                continue
            current = attributes.get(variable.name.upper())
            bindings.append(ValueBinding(
                binding_id=f"precedent_value:{accepted['sttm_id']}:{variable.name}",
                value=placeholder,
                resolved_value=(current.attribute_value if current else variable.resolved_value),
                data_type=(current.attribute_type if current else variable.inferred_type),
                attribute_name=variable.name,
                is_placeholder=True,
                allow_project_specific_value=True,
                resolution_status="project_attribute" if current else "resolved",
                provenance=(
                    "current_project_attribute" if current else
                    "historical_draft_set_value" if accepted.get("status") == "IN_PROGRESS"
                    else "completed_precedent_set_value"
                ),
                evidence_ids=[f"sttm_precedent:{accepted['sttm_id']}"] if not current else [],
            ))
        return bindings

    def _firm_values(self, state: dict[str, Any], *, refresh: bool = False) -> dict[str, dict[str, Any]]:
        """The run project's active firm values that can be compiled, by normalized name."""
        project_id = str(state.get("project_id") or "")
        projects = getattr(self, "_projects", None)
        if (not project_id or projects is None or not hasattr(projects, "list_project_attributes")
                or getattr(self, "_settings", None) is not None
                and not self._setting("migration_agent_firm_values_enabled", True)):
            return {}
        cache = self.__dict__.setdefault("_firm_value_cache", {})
        if refresh or project_id not in cache:
            self._tool("project.list_firm_values")
            with self._domain_lock:
                records = self._projects.list_project_attributes(project_id)
            cache[project_id] = {
                firm_value_norm(item.attribute_name): {
                    "name": item.attribute_name, "type": item.attribute_type, "value": item.attribute_value,
                    "attribute_id": item.attribute_id,
                }
                for item in records if usable_firm_value(item.attribute_value, item.attribute_type)
            }
        return cache[project_id]

    def _firm_value_context(self, state: dict[str, Any], target_columns: list[str],
                            target_table: str | None = None) -> dict[str, Any]:
        """Which target columns earlier mappings bind to a firm value, and the values known for them.

        Earlier mappings decide first; the firm-value catalogue covers the
        columns none of them bind (a target no earlier project mapped yet).
        """
        if (not self._setting("migration_agent_firm_values_enabled", True) or self._projects is None
                or not hasattr(self._projects, "firm_value_usages")):
            return {"held": {}, "choices": {}, "values": []}
        held = self._firm_values(state)
        self._tool("project.firm_value_usages")
        with self._domain_lock:
            found = self._projects.firm_value_usages(list(target_columns))
        choices = choose_firm_values(
            target_columns, firm_value_usages_from_rows(found.get("usages") or []),
            [item["name"] for item in held.values()],
            min_support=int(self._setting("migration_agent_firm_value_min_support", 1)),
        )
        if target_table:
            from app.agent_tools.firm_value_catalog import catalog_choices, load_catalog
            for column, choice in catalog_choices(
                load_catalog(getattr(self, "_settings", None)), target_table,
                [column for column in target_columns if column not in choices],
            ).items():
                choices[column] = choice
        return {"held": held, "choices": choices, "values": list(found.get("values") or [])}

    def _stated_firm_value(self, state: dict[str, Any], name: str, column: str, data_type: str | None,
                           target_table: str) -> str | None:
        """A value for ``name`` the user stated in the request or an attachment."""
        stated = prompt_project_value(str(state.get("prompt") or ""), name, [column], data_type)
        if stated:
            return stated
        for item in attachment_value_bindings(facts_for_target(state.get("attachment_readings") or [], target_table)):
            if firm_value_norm(item.get("name")) == firm_value_norm(name) and usable_firm_value(item.get("value"), data_type):
                return str(item["value"]).strip()
        return None

    def _apply_firm_values(
        self, state: dict[str, Any], rows: list[dict[str, Any]], context: dict[str, Any], *,
        target_table: str, target_column_contracts: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Bind rows to firm values as earlier mappings do; review items for the ones that need a value.

        A firm value the project holds is used as it is; one the user stated is
        created in the project first. When the project has none, the column is
        left as it is and the reviewer picks a value other projects hold or
        types their own (the value is created in the project when applied).
        """
        choices: dict[str, Any] = context.get("choices") or {}
        # Shared with the caller, so values created here count as held later.
        held: dict[str, dict[str, Any]] = context.get("held")
        if held is None:
            held = context["held"] = {}
        target_types = {str(item.get("name") or "").upper(): str(item.get("type") or item.get("data_type") or "")
                        for item in target_column_contracts}
        confidence = float(self._setting("migration_agent_firm_value_confidence", 0.9))
        override = bool(self._setting("migration_agent_firm_value_override_source", True))
        limit = int(self._setting("migration_agent_firm_value_candidate_limit", 3))
        by_target = {str(row["target_column"]).upper(): row for row in rows}
        # A specialist that wrote a whole column as $Name made it a firm-value row.
        for row in rows:
            name = (re.fullmatch(r"\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*", str(row.get("expression") or "")) or [None, None])[1]
            if name and not row.get("source_columns") and firm_value_norm(name) in held:
                firm_value = held[firm_value_norm(name)]
                row.update({"mapping_mode": "attribute", "attribute_name": firm_value["name"],
                            "constant_value": firm_value["value"], "expression": None, "status": "draft",
                            "mapping_classification": "constant", "firm_values": [firm_value["name"]],
                            "missing_dependencies": []})
        reviews: list[dict[str, Any]] = []
        bound, created, needed = [], [], []
        for column, choice in choices.items():
            row = by_target.get(str(column).upper())
            if row is None or row.get("mapping_mode") == "attribute":
                continue
            data_type = target_types.get(str(column).upper()) or None
            firm_value = held.get(firm_value_norm(choice.name))
            if firm_value is None and (stated := self._stated_firm_value(state, choice.name, column, data_type, target_table)):
                firm_value = self._create_firm_value(state, choice.name, data_type, stated)
                if firm_value is not None:
                    held[firm_value_norm(choice.name)] = firm_value
                    created.append(choice.name)
            if firm_value is None:
                if choice.shape != "value":
                    continue
                known = known_firm_values(context.get("values") or [], choice.name,
                                          exclude_project=str(state.get("project_id") or ""), limit=limit)
                candidates = [{
                    "firm_value": item, "attribute_name": item["name"], "constant_value": item["value"],
                    "confidence": confidence * 0.5,
                    "reason": (f"{', '.join(item['projects'][:2])} use{'s' if len(item['projects']) == 1 else ''} "
                               f"{item['name']} = {item['value']}. {choice.reason} Values differ per firm: confirm "
                               "this one applies, or enter this firm's value."),
                    "evidence_ids": choice.evidence_ids, "origin": "firm_value",
                } for item in known]
                if row.get("status") == "draft" and row.get("source_columns"):
                    candidates.append({"source_columns": list(row.get("source_columns") or []),
                                       "transformation": row.get("expression"),
                                       "confidence": float(row.get("confidence") or 0),
                                       "reason": f"Current source mapping. {row.get('confidence_reason') or ''}".strip(),
                                       "evidence_ids": list(row.get("evidence_ids") or []), "origin": "current_row"})
                needed.append(choice.name)
                reviews.append({
                    "category": "mapping_candidate_review",
                    "blocking": row.get("status") != "draft",
                    "safe_summary": (f"{column}: needs firm value {choice.name}, which this project does not have yet. "
                                     f"{choice.reason}"),
                    "details": {"target_column": column, "candidates": candidates, "firm_value_name": choice.name,
                                "firm_value_type": data_type or (known[0]["type"] if known else "VARCHAR"),
                                "kind": "firm_value"},
                })
                continue
            replaced = apply_firm_value(row, choice, firm_value, confidence=confidence, override_source=override)
            if row.get("firm_values"):
                bound.append(f"{column} = {firm_value['name']}")
            if replaced and replaced.get("source_columns") and choice.shape == "value":
                reviews.append({
                    "category": "mapping_candidate_review", "blocking": False,
                    "safe_summary": (f"{column}: uses firm value {firm_value['name']} as earlier mappings do; "
                                     f"the source guess {', '.join(replaced['source_columns'])} was set aside."),
                    "details": {"target_column": column, "kind": "firm_value", "candidates": [
                        {"attribute_name": firm_value["name"], "constant_value": firm_value["value"],
                         "confidence": confidence, "reason": choice.reason, "evidence_ids": choice.evidence_ids,
                         "origin": "firm_value"},
                        {"source_columns": list(replaced["source_columns"]), "transformation": replaced.get("expression"),
                         "confidence": float(replaced.get("confidence") or 0),
                         "reason": str(replaced.get("confidence_reason") or "Source mapping candidate"),
                         "origin": "source_mapping_agent"},
                    ]},
                })
        needed.extend(self._hold_back_unheld_firm_values(state, rows, held, context.get("values") or [], reviews))
        if bound or created or needed:
            self._emit(
                "firm_values.applied", "succeeded",
                "; ".join(part for part in (
                    f"Bound {len(bound)} column(s) to firm values ({', '.join(bound[:6])})" if bound else "",
                    f"created firm value(s) {', '.join(sorted(set(created)))} from values you gave" if created else "",
                    f"{len(needed)} column(s) need a firm value this project does not have "
                    f"({', '.join(sorted(set(needed)))})" if needed else "",
                ) if part) + ".",
                trace_id=f"firm-values:{target_table}", parent_trace_id="mapping-execution", kind="decision",
                label="Firm values", details={"bound": bound, "created": sorted(set(created)), "needed": sorted(set(needed))},
            )
        return reviews

    def _hold_back_unheld_firm_values(self, state: dict[str, Any], rows: list[dict[str, Any]],
                                      held: dict[str, dict[str, Any]], values: list[dict[str, Any]],
                                      reviews: list[dict[str, Any]]) -> list[str]:
        """Hold back rows that use a firm value the project does not hold; one question per name.

        A rule copied from a precedent may use a firm value inside a larger
        expression ($LegacyHHcPrefix || 'HH_' || id). Unheld, Snowflake reads it
        as a missing session variable and the whole SELECT fails, and the draft
        save rejects an attribute row naming an unknown value even when it is
        unresolved. Returns the names that were asked for.
        """
        confidence = float(self._setting("migration_agent_firm_value_confidence", 0.9))
        limit = int(self._setting("migration_agent_firm_value_candidate_limit", 3))
        asked = {str(dict(item.get("details") or {}).get("firm_value_name") or "").upper() for item in reviews}
        needed: list[str] = []
        for row in rows:
            if row.get("mapping_mode") == "attribute":
                # A whole-column firm value (a precedent row or a promoted value binding).
                missing = [str(row["attribute_name"])] if row.get("attribute_name") and \
                    firm_value_norm(row["attribute_name"]) not in held else []
            else:
                missing = [name for name in firm_value_names_in(row.get("expression"))
                           if firm_value_norm(name) not in held]
            if not missing:
                continue
            expression = row.get("expression") or (f"${missing[0]}" if row.get("mapping_mode") == "attribute" else None)
            row.update({"status": "unresolved", "held_back_expression": expression,
                        "missing_dependencies": list(dict.fromkeys([
                            *(row.get("missing_dependencies") or []), *[f"firm_value:{name}" for name in missing]]))})
            # The canonical workspace converter infers a value binding from any
            # bare ``$Name`` expression. Clear executable binding state for all
            # held-back rows, including source-mode rows, so unresolved review
            # metadata cannot be promoted back into an active project value.
            row.update({"mapping_mode": "source", "attribute_name": None, "constant_value": None,
                        "expression": None, "firm_values": []})
            for name in missing:
                needed.append(name)
                if name.upper() in asked:
                    continue
                asked.add(name.upper())
                known = known_firm_values(values, name, exclude_project=str(state.get("project_id") or ""), limit=limit)
                reviews.append({
                    "category": "mapping_candidate_review", "blocking": False,
                    "safe_summary": (f"{row['target_column']}: the precedent rule uses firm value {name}, which this "
                                     f"project does not have yet: {str(expression)[:160]}"),
                    "details": {"target_column": row["target_column"], "firm_value_name": name, "kind": "firm_value",
                                "firm_value_type": "VARCHAR", "held_back_expression": expression,
                                "candidates": [{
                                    "firm_value": item, "attribute_name": item["name"], "constant_value": item["value"],
                                    "confidence": confidence * 0.5, "origin": "firm_value",
                                    "reason": f"{', '.join(item['projects'][:2])} use {item['name']} = {item['value']}.",
                                } for item in known]},
                })
        return needed

    def _create_firm_value(self, state: dict[str, Any], name: str, data_type: str | None, value: str) -> dict[str, Any] | None:
        """Create a firm value the user stated in the run's project."""
        from app.schema.project import ProjectAttributeCreateRequest
        kind = str(data_type or "VARCHAR").upper()
        kind = "VARCHAR" if kind in {"TEXT", "STRING"} or kind.startswith(("VARCHAR", "CHAR")) else kind.split("(")[0]
        self._tool("project.create_firm_value")
        try:
            with self._domain_lock:
                record = self._projects.create_project_attribute(
                    str(state["project_id"]),
                    ProjectAttributeCreateRequest(attribute_name=name, attribute_type=kind, attribute_value=value),
                    user_id=self._actor(state).user_id,
                )
        except Exception:  # noqa: BLE001 - a duplicate or invalid value leaves the column for review
            return self._firm_values(state, refresh=True).get(firm_value_norm(name))
        self.__dict__.setdefault("_firm_value_cache", {}).pop(str(state["project_id"]), None)
        return {"name": record.attribute_name, "type": record.attribute_type, "value": record.attribute_value,
                "attribute_id": record.attribute_id}

    @staticmethod
    def _edges_oriented_from(driving_id: str, edges: list[RelationEdge]) -> list[RelationEdge]:
        """Point every optional (LEFT) join away from the driving relation.

        Relationship evidence is stored child -> parent. When the driver is the
        parent (CONTACTS for its members, addresses, UDFs), compiling that edge
        as written becomes a RIGHT JOIN and the result takes the child's grain.
        An optional join always preserves the side nearer the driver.
        """
        distance = {driving_id: 0}
        frontier = [driving_id]
        while frontier:
            following = []
            for node in frontier:
                for edge in edges:
                    for here, there in ((edge.left_relation_id, edge.right_relation_id),
                                        (edge.right_relation_id, edge.left_relation_id)):
                        if here == node and there not in distance:
                            distance[there] = distance[node] + 1
                            following.append(there)
            frontier = following
        mirrored_operator = {"<": ">", ">": "<", "<=": ">=", ">=": "<="}
        oriented = []
        for edge in edges:
            join_type = str(edge.join_type or "LEFT").strip().upper()
            left_depth = distance.get(edge.left_relation_id)
            right_depth = distance.get(edge.right_relation_id)
            if (join_type not in {"LEFT", "LEFT OUTER"} or left_depth is None or right_depth is None
                    or left_depth <= right_depth or edge.normalized_lookup_alternative):
                oriented.append(edge)
                continue
            oriented.append(edge.model_copy(update={
                "left_relation_id": edge.right_relation_id,
                "right_relation_id": edge.left_relation_id,
                "conditions": [condition.model_copy(update={
                    "left_column": condition.right_column, "right_column": condition.left_column,
                    "operator": mirrored_operator.get(condition.operator.strip(), condition.operator),
                }) for condition in edge.conditions],
                "literal_filters": [item.model_copy(update={"side": "right" if item.side == "left" else "left"})
                                    for item in edge.literal_filters or []],
            }))
        return oriented

    def _population_filter(self, graph: Any, driving_relation_id: str | None,
                           filter_sql: str | None) -> tuple[str | None, list[dict[str, Any]]]:
        """The mapping's WHERE with the population rules the design implies (soft deletes)."""
        from app.migration_workflow.population_rules import (
            SOFT_DELETE_COLUMNS, mentions_column, merge_predicates, soft_delete_predicate,
        )
        rules: list[dict[str, Any]] = []
        if not self._setting("migration_agent_soft_delete_filter_enabled", True):
            return filter_sql, rules
        node = next((item for item in graph.nodes if item.relation_id == driving_relation_id), None)
        table = node.table.qualified_name if node is not None and getattr(node, "table", None) else None
        if not table or any(mentions_column(filter_sql, column) for column in SOFT_DELETE_COLUMNS):
            return filter_sql, rules
        try:
            contract = self._describe_table(table)
        except Exception:  # noqa: BLE001 - an undescribable driver keeps its current filter
            return filter_sql, rules
        predicate = soft_delete_predicate(node.alias, contract)
        if predicate:
            rules.append({"rule": "soft_delete", "predicate": predicate, "table": table,
                          "reason": f"{table} flags deleted records; only live ones are loaded."})
            filter_sql = merge_predicates(filter_sql, [predicate])
        return filter_sql, rules

    def _validate_generated_sql(
        self,
        *,
        state: dict[str, Any],
        target_table: str,
        source_tables: list[str],
        source_columns: dict[str, list[str]],
        rows: list[dict[str, Any]],
        policy: Any,
        target_key_columns: list[str] | None = None,
    ) -> dict[str, Any]:
        if self._mapping_sql is None:
            return {"compile_valid": False, "preview_valid": False, "safe_error": "Mapping SQL validation service is unavailable."}
        design = self._canonical_design(
            state=state,
            source_tables=source_tables,
            source_columns=source_columns,
        )
        stored_graph = design["graph"].model_copy(update={
            "value_bindings": self._precedent_value_bindings(state, list(design["graph"].value_bindings)),
        })
        driving_relation_id = design["driving_id"]
        workspace = MappingContextPackageV1.model_validate(
            state.get("mapping_context_package") or {}
        ).workspace
        effective_filter, population_rules = self._population_filter(
            stored_graph, driving_relation_id, workspace.filters.filter_sql)
        from app.core.mapping_sql import MappingSqlService
        # Resolved project values are written into the rows, as the grid holds
        # them; the compiler then sees the same graph a user's recompile sends.
        design["resolved_placeholders"] = MappingSqlService._resolved_placeholder_sql(stored_graph)
        design["target_types"] = self._contract_cache_columns(target_table)
        design["source_columns"] = source_columns

        # Agent expressions can retain aliases from historical SQL that are
        # absent from the approved current relation graph. Validate each one
        # before compiling the batch so one stale expression does not prevent
        # every valid target from producing SQL and preview rows.
        graph_nodes = {node.relation_id: node for node in stored_graph.nodes}
        graph_aliases = {node.relation_id: node.alias for node in stored_graph.nodes}
        alias_to_id = {node.alias.upper(): node.relation_id for node in stored_graph.nodes}
        precheck_held: list[dict[str, Any]] = []
        for row in rows:
            expression = str(row.get("expression") or "").strip()
            if row.get("status") != "draft" or not expression:
                continue
            try:
                normalized = MappingSqlService._normalize_expression_namespace(
                    expression, graph_nodes, graph_aliases
                )
                normalized = MappingSqlService._normalize_legacy_expression_aliases(
                    normalized, graph_nodes, alias_to_id, graph_aliases
                )
                MappingSqlService._validate_expression_aliases(normalized, alias_to_id, graph_nodes)
            except ValueError as exc:
                # Do not replace a failed transformation with a direct source.
                # The canonical compiler and bounded debugger may repair it;
                # otherwise isolation retains it as unresolved evidence.
                row["expression_precheck"] = str(exc)
                if "Ambiguous column in mapping expression" not in str(exc):
                    precheck_held.append(self._hold_back_row(row, str(exc)))

        mappings = []
        rows_by_target = {str(row["target_column"]): row for row in rows}
        # A row-level mapping cannot aggregate: without GROUP BY (or a derived
        # source at the aggregated grain) one such column fails the whole SQL.
        # It is reported for review instead of blocking the other columns.
        has_grouping = bool(workspace.filters.group_by_sql)
        aggregated_columns: list[str] = []
        held_back: list[dict[str, Any]] = list(precheck_held)
        for row in rows:
            if row["status"] != "draft":
                continue
            expression = str(row.get("expression") or "")
            if not has_grouping and _AGGREGATE_CALL.search(expression) and not _WINDOW_CLAUSE.search(expression):
                planned = self._design_aggregate_cte(row, design, stored_graph)
                if planned is not None:
                    stored_graph = planned
                else:
                    aggregated_columns.append(str(row["target_column"]))
                    held_back.append(self._hold_back_row(
                        row, "The expression aggregates rows, but the mapping has no GROUP BY or derived "
                             "source at the aggregated grain."))
                    continue
            canonical = self._canonical_row(row, design)
            if canonical["status"] != "MAPPED":
                continue
            if canonical["mapping_mode"] == "attribute" and str(canonical.get("constant_value") or "").startswith("$"):
                held_back.append(self._hold_back_row(
                    row, f"{canonical['constant_value']} needs a project value before this column can be loaded."))
                continue
            mappings.append(MappingSqlMappingItem.model_validate(compile_mapping_item(canonical)))
        # The graph the mapping page compiles: value bindings come from the
        # grid's Value rows, never from agent-only state.
        graph = stored_graph.model_copy(update={"value_bindings": [
            ValueBinding.model_validate(item)
            for item in grid_value_bindings([self._canonical_row(row, design) for row in rows])
        ]})
        if not mappings or not graph.nodes:
            return {"compile_valid": False, "preview_valid": False, "safe_error": "Mapped rows and a source relation are required for SQL validation.",
                    "workspace_design": design}
        result: dict[str, Any] = {"compile_valid": False, "preview_valid": False, "workspace_design": design,
                                  "effective_filter_sql": effective_filter, "population_rules": population_rules}
        design["compile_graph"] = graph
        phase = "compile"

        def compile_subset(subset: list[MappingSqlMappingItem]) -> tuple[Any, BaseException | None]:
            try:
                self._tool("mapping_sql.compile")
                with self._domain_lock:
                    return self._mapping_sql.compile(MappingSqlCompileRequest(
                        relation_graph=graph,
                        mappings=subset,
                        target_table=self._table_ref(target_table),
                        driving_relation_id=driving_relation_id,
                        where_predicates=[effective_filter] if effective_filter else [],
                        group_by_expressions=(
                            [value.strip() for value in workspace.filters.group_by_sql.split(",") if value.strip()]
                            if workspace.filters.group_by_sql else []
                        ),
                        order_by_expressions=(
                            [value.strip() for value in workspace.filters.order_by_sql.split(",") if value.strip()]
                            if workspace.filters.order_by_sql else []
                        ),
                        validate_with_explain=True,
                        accepted_precedent_sttm_id=(
                            str((state.get("accepted_precedent") or {}).get("sttm_id") or "") or None
                        ),
                        accepted_precedent_sql_hash=(
                            str((state.get("accepted_precedent") or {}).get("sql_sha256") or "") or None
                        ),
                    )), None
            except BudgetExceededError:
                raise
            except Exception as exc:  # noqa: BLE001 - attributed below, never swallowed
                return None, exc

        preview_limit = min(policy.preview_row_limit, 20)
        debugger = self._sql_debugger(
            state=state, target_table=target_table, graph=graph, stored_graph=stored_graph, design=design,
            compile_subset=compile_subset, preview_limit=preview_limit,
        )
        sql_repairs: list[dict[str, Any]] = [
            repair for row in rows for repair in row.get("repairs") or [] if repair.get("root_cause") == "aggregate_grain"
        ]
        result["sql_repairs"] = sql_repairs

        def hold_back(target: str, reason: str) -> None:
            row = rows_by_target.get(target)
            if row is not None and row.get("status") == "draft":
                held_back.append(self._hold_back_row(row, reason))

        def apply_repairs(outcome: Any) -> None:
            for repair in outcome.repairs:
                row = rows_by_target.get(repair.target_column)
                if row is not None:
                    row["expression"] = repair.after
                    row["repairs"] = [*list(row.get("repairs") or []), repair.as_dict()]
                sql_repairs.append(repair.as_dict())

        def record_compiled(compiled: Any) -> None:
            result.update({
                "compile_valid": bool(compiled.valid and compiled.ready),
                "preview_valid": False,
                "preview_row_count": 0,
                "warnings": [*compiled.warnings, *[
                    f"{item['target_column']} was left for review: {item['reason']}" for item in held_back]],
                "aggregated_columns_for_review": aggregated_columns,
                "columns_held_for_review": held_back,
                "compiled_mapping_sql": compiled.generated_sql,
                "compiled_mapping_preview_sql": compiled.preview_sql,
                "compiled_mapping_script": getattr(compiled, "script_sql", None),
                "compiled_mapping_sql_hash": hashlib.sha256(compiled.generated_sql.encode("utf-8")).hexdigest(),
            })

        try:
            if debugger is not None:
                linted = debugger.lint(mappings)
                apply_repairs(linted)
                for target, reason in linted.held.items():
                    hold_back(target, reason)
                mappings = [item for item in linted.items if item.target_column not in linted.held]
                if not mappings:
                    result["safe_error"] = "Every mapped column needs a project value or a corrected rule before SQL can compile."
                    return result
            compiled, compile_error = compile_subset(mappings)
            if compile_error is not None and debugger is not None:
                repaired = debugger.repair_compile(mappings, compile_error)
                apply_repairs(repaired)
                mappings = repaired.items
                compiled, compile_error = (repaired.compiled, repaired.error) if repaired.error is None else (None, repaired.error)
                result["sql_diagnoses"] = [
                    {"category": item.category, "targets": item.targets, "root_cause": item.root_cause}
                    for item in repaired.diagnoses
                ]
            if compile_error is not None:
                compiled, mappings = self._compile_without_failing_columns(
                    state=state,
                    target_table=target_table,
                    mappings=mappings,
                    rows_by_target=rows_by_target,
                    held_back=held_back,
                    compile_subset=compile_subset,
                    first_error=compile_error,
                    result=result,
                )
            record_compiled(compiled)
            self._emit("trace.action.completed", "succeeded" if result["compile_valid"] else "needs_review", "Generated mapping SQL passed compiler checks." if result["compile_valid"] else "Generated mapping SQL requires contract review.", trace_id=f"sql:{state['run_id']}:{target_table}", parent_trace_id="validation", kind="query", label="Compile mapping SQL", details={"query": self._redact_sql_literals(compiled.preview_sql), "valid": result["compile_valid"]})
            selected_preview_sql = compiled.preview_sql
            selected_generated_sql = compiled.generated_sql
            selected_variant = "original"
            if policy.validation_depth != "compile" and result["compile_valid"]:
                phase = "review"
                semantic_ref = MappingContextPackageV1.model_validate(
                    state.get("mapping_context_package") or {}
                ).stored_semantic_context
                semantic_model_yaml = None
                if self._semantic_context is not None and (
                    semantic_ref.bundle_id or semantic_ref.bundle_hash
                ):
                    with self._domain_lock:
                        stored_bundle = self._semantic_context.get_bundle(
                            bundle_id=semantic_ref.bundle_id,
                            bundle_hash=semantic_ref.bundle_hash,
                        )
                    if stored_bundle:
                        semantic_model_yaml = stored_bundle.get("semantic_model_yaml")
                self._tool("mapping_sql.review")
                source_query_sql = base_query_sql(graph.model_dump(mode="json"), driving_relation_id) or compiled.preview_sql
                design_relationships = [self._normalized_relationship(value) for value in design["relationships"]]
                design_derived_ids = [item["id"] for item in design["derived_sources"]]

                def review_request(current: Any, subset: list[MappingSqlMappingItem]) -> MappingSqlReviewRequest:
                    return MappingSqlReviewRequest(
                        source_tables=[ref for table in source_tables if (ref := self._table_ref(table))],
                        target_table=self._table_ref(target_table),
                        driving_table=workspace.driving_table or self._table_ref(source_tables[0]),
                        relationships=design_relationships,
                        selected_derived_sources=design_derived_ids,
                        selected_columns_by_table=workspace.selected_columns_by_table,
                        semantic_bundle_id=semantic_ref.bundle_id,
                        semantic_view_name=semantic_ref.semantic_view_name,
                        semantic_model_yaml=semantic_model_yaml,
                        relation_graph=graph,
                        source_query_sql=source_query_sql,
                        preview_sql=current.preview_sql,
                        generated_sql=current.generated_sql,
                        mappings=subset,
                        preview_limit=preview_limit,
                        attempt_ai_repair=True,
                    )

                with self._domain_lock:
                    review = self._mapping_sql.review(review_request(compiled, mappings))
                # The draft keeps the compiler's SELECT: it is what the mapping
                # page regenerates from these rows. An Analyst optimization is
                # offered for approval there, exactly as for a manual build.
                result.update({
                    "sql_review": review.model_dump(mode="json"),
                    "optimization_applied": False,
                    "optimization_available": bool(review.optimized_preview_sql),
                    "optimization_requires_approval": False,
                })
                self._emit(
                    "trace.action.completed",
                    "succeeded" if review.execution_ready else "needs_review",
                    (
                        "Snowflake validated the mapping SQL. Cortex Analyst also proposed an optimization, "
                        "kept as a suggestion for review in the mapping page."
                        if review.optimized_preview_sql else
                        "Snowflake validated the mapping SQL."
                    ),
                    trace_id=f"review:{state['run_id']}:{target_table}",
                    parent_trace_id="validation",
                    kind="validation",
                    label="Review mapping SQL",
                    details={
                        "review_agent": review.review_agent,
                        "review_kind": review.review_kind,
                        "optimized": review.optimized,
                        "execution_ready": review.execution_ready,
                    },
                )
            if policy.validation_depth != "compile" and result["compile_valid"]:
                phase = "preview"
                self._tool("mapping_sql.preview")

                def preview_request(preview_sql: str, generated_sql: str,
                                    subset: list[MappingSqlMappingItem]) -> MappingSqlPreviewRequest:
                    return MappingSqlPreviewRequest(
                        source_tables=[ref for table in source_tables if (ref := self._table_ref(table))],
                        target_table=self._table_ref(target_table),
                        driving_table=workspace.driving_table or self._table_ref(source_tables[0]),
                        relationships=design_relationships,
                        selected_derived_sources=design_derived_ids,
                        selected_columns_by_table=workspace.selected_columns_by_table,
                        relation_graph=graph,
                        semantic_bundle_id=semantic_ref.bundle_id,
                        semantic_view_name=semantic_ref.semantic_view_name,
                        semantic_model_yaml=semantic_model_yaml,
                        source_query_sql=source_query_sql,
                        preview_sql=preview_sql,
                        generated_sql=generated_sql,
                        mappings=subset,
                        preview_limit=preview_limit,
                        chosen_variant=selected_variant,
                        approved_preview_sql=preview_sql,
                        approved_generated_sql=generated_sql,
                    )

                try:
                    with self._domain_lock:
                        preview = self._mapping_sql.preview(
                            preview_request(selected_preview_sql, selected_generated_sql, mappings))
                except BudgetExceededError:
                    raise
                except Exception as preview_error:  # noqa: BLE001 - diagnosed, repaired or re-raised
                    if debugger is None:
                        raise
                    # A value in the data breaks a column rule. Find and fix
                    # that rule; a column that stays broken goes to review so
                    # the rest of the mapping still previews.
                    repaired = debugger.repair_preview(mappings, preview_error)
                    apply_repairs(repaired)
                    failing = list(repaired.diagnoses[-1].targets) if repaired.error is not None and repaired.diagnoses else []
                    if repaired.error is not None and not failing:
                        raise preview_error
                    for target in failing:
                        hold_back(target, f"Snowflake could not load its sample values ({repaired.diagnoses[-1].root_cause}).")
                    mappings = [item for item in repaired.items if item.target_column not in failing]
                    if not mappings:
                        raise preview_error
                    phase = "compile"
                    compiled, recompile_error = compile_subset(mappings)
                    if recompile_error is not None:
                        raise recompile_error
                    record_compiled(compiled)
                    selected_preview_sql, selected_generated_sql = compiled.preview_sql, compiled.generated_sql
                    phase = "review"
                    with self._domain_lock:
                        review = self._mapping_sql.review(review_request(compiled, mappings))
                    result.update({"sql_review": review.model_dump(mode="json"),
                                   "optimization_available": bool(review.optimized_preview_sql)})
                    phase = "preview"
                    with self._domain_lock:
                        preview = self._mapping_sql.preview(
                            preview_request(selected_preview_sql, selected_generated_sql, mappings))
                result.update({
                    "preview_valid": preview.valid,
                    "validated_preview_sql_hash": sql_hash(selected_preview_sql) if preview.valid else None,
                    "preview_row_count": len(preview.preview_rows),
                    "preview_columns": [column.name for column in preview.preview_columns],
                    "preview_rows": [row.model_dump(mode="json") for row in preview.preview_rows[:20]],
                    "executed_preview_sql": self._redact_sql_literals(preview.executed_preview_sql),
                    "validation_receipt": validation_receipt(
                        preview_sql=selected_preview_sql,
                        compile_valid=True,
                        review=result.get("sql_review"),
                        preview=preview.model_dump(mode="json"),
                        validated_by="deep_agent",
                        validated_at=datetime.now(timezone.utc).isoformat(),
                    ),
                })
                self._emit("trace.action.completed", "succeeded", "Executed a bounded mapping preview.", trace_id=f"preview:{state['run_id']}:{target_table}", parent_trace_id="validation", kind="query", label="Preview mapping SQL", details={"query": self._redact_sql_literals(preview.executed_preview_sql), "row_count": len(preview.preview_rows), "column_count": len(preview.preview_columns)})
            if policy.validation_depth == "reconcile" and result["compile_valid"]:
                phase = "reconcile"
                source_ref = self._table_ref(source_tables[0])
                if source_ref is not None:
                    source_fqn = ".".join(f'"{value}"' for value in (source_ref.database, source_ref.schema, source_ref.table))
                    safe_query = selected_preview_sql.strip().rstrip(";")
                    self._tool("mapping_sql.reconcile")
                    with self._domain_lock:
                        source_rows = self._session.sql(f"SELECT COUNT(*) AS ROW_COUNT FROM {source_fqn}").collect()
                        output_rows = self._session.sql(f"SELECT COUNT(*) AS ROW_COUNT FROM (\n{safe_query}\n) AS MIGRATION_OUTPUT").collect()
                    source_data = source_rows[0].as_dict() if source_rows and hasattr(source_rows[0], "as_dict") else (dict(source_rows[0]) if source_rows else {})
                    output_data = output_rows[0].as_dict() if output_rows and hasattr(output_rows[0], "as_dict") else (dict(output_rows[0]) if output_rows else {})
                    reconciliation = {
                        "source_row_count": int(source_data.get("ROW_COUNT") or source_data.get("row_count") or 0),
                        "output_row_count": int(output_data.get("ROW_COUNT") or output_data.get("row_count") or 0),
                    }
                    result["reconciliation_metrics"] = reconciliation
                    valid_keys = [value for value in target_key_columns or [] if _IDENTIFIER.fullmatch(value)]
                    if valid_keys:
                        key_expr = ", ".join(f'"{value}"' for value in valid_keys)
                        distinct_expr = f"HASH({key_expr})" if len(valid_keys) > 1 else key_expr
                        null_expr = " OR ".join(f'"{value}" IS NULL' for value in valid_keys)
                        with self._domain_lock:
                            key_rows = self._session.sql(
                                f"SELECT COUNT(*) AS TOTAL_COUNT, COUNT(DISTINCT {distinct_expr}) AS UNIQUE_COUNT, COUNT_IF({null_expr}) AS NULL_COUNT FROM (\n{safe_query}\n) AS MIGRATION_OUTPUT"
                            ).collect()
                        key_data = key_rows[0].as_dict() if key_rows and hasattr(key_rows[0], "as_dict") else (dict(key_rows[0]) if key_rows else {})
                        result["key_metrics"] = {
                            "total_count": int(key_data.get("TOTAL_COUNT") or 0),
                            "unique_count": int(key_data.get("UNIQUE_COUNT") or 0),
                            "null_count": int(key_data.get("NULL_COUNT") or 0),
                        }
                    self._emit("trace.action.completed", "succeeded", "Executed row and key reconciliation queries.", trace_id=f"reconcile:{state['run_id']}:{target_table}", parent_trace_id="validation", kind="validation", label="Reconcile mapping output", details={"source_row_count": reconciliation["source_row_count"], "output_row_count": reconciliation["output_row_count"]})
            return result
        except Exception as exc:
            logger.exception("Mapping SQL %s failed for run %s", phase, state.get("run_id"))
            result["safe_error"] = f"{type(exc).__name__}: mapping SQL {phase} failed."
            result["error_summary"] = compile_error_summary(exc)
            result["failed_phase"] = phase
            result["validation_complete"] = False
            result.setdefault("columns_held_for_review", held_back)
            if result.get("compiled_mapping_preview_sql"):
                result["validation_receipt"] = validation_receipt(
                    preview_sql=result["compiled_mapping_preview_sql"],
                    compile_valid=bool(result.get("compile_valid")),
                    review=result.get("sql_review"),
                    preview=None,
                    validated_by="deep_agent",
                    validated_at=datetime.now(timezone.utc).isoformat(),
                    error=result["error_summary"],
                    failed_phase=phase,
                )
            return result

    @staticmethod
    def _source_design_hash(workspace: dict[str, Any], target_table: Any) -> str:
        """Identity of an approved source design, independent of how a snapshot renders it."""
        filters = dict(workspace.get("filters") or {})
        design = {
            "source_tables": sorted(snapshot_table_fqn(item).upper() for item in workspace.get("source_tables") or []),
            "target_table": snapshot_table_fqn(target_table).upper(),
            "driving_table": snapshot_table_fqn(workspace.get("driving_table")).upper(),
            "relationships": workspace.get("relationships") or [],
            "derived_sources": sorted(
                (str(item.get("id") or ""), str(item.get("sql_hash") or ""))
                for item in workspace.get("derived_sources") or [] if isinstance(item, dict)
            ),
            "filters": {key: filters.get(key) for key in ("filter_sql", "group_by_sql", "order_by_sql")},
        }
        return hashlib.sha256(json.dumps(design, sort_keys=True, default=str).encode("utf-8")).hexdigest()

    def _draft_snapshot(
        self,
        *,
        state: dict[str, Any],
        mapping: dict[str, Any],
        target_table: str,
        source_tables: list[str],
        source_columns: dict[str, list[str]],
        rows: list[dict[str, Any]],
        context_workspace: dict[str, Any],
        design: dict[str, Any] | None,
        sql_validation: dict[str, Any],
        receipt: dict[str, Any] | None,
        workspace: WorkbenchContextSnapshotV1 | None = None,
        page: str = "mapping",
        surface: str = "MAPPING",
    ) -> dict[str, Any]:
        """The run-owned draft in exactly the shape the STTM builder saves."""
        if design is None:
            design = self._canonical_design(
                state=state, source_tables=source_tables, source_columns=source_columns, workspace=workspace,
            )
            design.update({
                "resolved_placeholders": {},
                "target_types": self._contract_cache_columns(target_table),
                "source_columns": source_columns,
            })
        canonical_rows = [self._canonical_row(row, design) for row in rows]
        graph = design.get("compile_graph") or design["graph"].model_copy(update={"value_bindings": [
            ValueBinding.model_validate(item) for item in grid_value_bindings(canonical_rows)
        ]})
        artifacts = [
            item for item in context_workspace.get("mapping_artifacts") or []
            if isinstance(item, dict) and item.get("type") != "compiled_mapping_sql"
        ]
        if sql_validation.get("compiled_mapping_preview_sql") or design.get("parity_warnings"):
            artifacts.append({
                "type": "extraction_sql",
                "artifact_hash": hashlib.sha256(
                    str(sql_validation.get("compiled_mapping_preview_sql") or "").encode("utf-8")
                ).hexdigest(),
                "label": "Salesforce extraction SQL",
                "read_only": True,
                "compile_valid": bool(sql_validation.get("compile_valid")),
                "preview_valid": bool(sql_validation.get("preview_valid")),
                "ui_parity_warnings": list(design.get("parity_warnings") or []),
            })
        excluded = {
            "mapping_rows", "relationships", "relation_graph", "derived_sources", "filters", "context_hash",
            "compiled_mapping_sql", "compiled_mapping_preview_sql", "compiled_mapping_context_hash",
            "mapping_artifacts", "validation_history", "mapping_sql", "raw_mapping_sql", "mapping_preview_sql",
        }
        base = {key: value for key, value in context_workspace.items() if key not in excluded}
        base.update({
            "context_key": f"migration:{state['run_id']}:{mapping['mapping_key']}",
            "project_id": state["project_id"],
            "sttm_id": mapping["sttm_id"],
            "source_design_hash": self._source_design_hash(context_workspace, target_table),
        })
        return canonical_snapshot(
            base,
            page=page,
            surface=surface,
            source_tables=[table for table in source_tables if self._table_ref(table) is not None],
            target_table=target_table,
            driving_table=design["driving_table"],
            graph=graph.model_dump(mode="json"),
            derived_sources=design["derived_sources"],
            relationships=design["relationships"],
            mapping_rows=canonical_rows,
            filters={
                **dict(context_workspace.get("filters") or {}),
                # Population rules the design added (soft deletes) are saved as the mapping's filter.
                **({"filter_sql": sql_validation["effective_filter_sql"]}
                   if sql_validation.get("effective_filter_sql") else {}),
            },
            compiled_mapping_sql=sql_validation.get("compiled_mapping_sql"),
            compiled_mapping_preview_sql=sql_validation.get("compiled_mapping_preview_sql"),
            compiled_mapping_script=sql_validation.get("compiled_mapping_script"),
            validation_history=merge_validation_history(context_workspace.get("validation_history") or [], receipt),
            mapping_artifacts=artifacts,
        )

    def _resolve_target_dependencies(
        self, state: dict[str, Any], mapping: dict[str, Any], rows: list[dict[str, Any]], source_tables: list[str],
    ) -> list[dict[str, Any]]:
        """Build columns that reference another target from that target's own key rule."""
        from app.migration_workflow.dependency_resolution import ForeignKey, resolve

        plan = state.get("migration_plan") or {}
        edges = [
            edge for edge in [*plan.get("dependencies", []),
                              *[d for spec in plan.get("mapping_specs", []) for d in spec.get("dependencies", [])]]
            if isinstance(edge, dict) and edge.get("consumer_mapping") == mapping.get("mapping_key")
        ]
        if not edges:
            return []
        consumer_tables = {normalize_fqn(value) for value in source_tables}
        schemas = {value.rsplit(".", 1)[0] for value in consumer_tables}
        cache: dict[str, list[ForeignKey]] = {}

        def foreign_keys(parent_table: str, parent_column: str) -> list[ForeignKey]:
            parent = normalize_fqn(parent_table)
            # Only a producer source in the consumer's own schemas is joined;
            # the relationship graph verifies the join against the data.
            if parent.rsplit(".", 1)[0] not in schemas:
                return []
            if parent not in cache:
                graph = self.discover_relationship_graph(sorted({*consumer_tables, parent}), [], []) or {}
                cache[parent] = [
                    ForeignKey(
                        child_table=normalize_fqn(str(edge["left_table"])),
                        child_column=str(edge["conditions"][0]["left_column"]),
                        parent_table=normalize_fqn(str(edge["right_table"])),
                        parent_column=str(edge["conditions"][0]["right_column"]),
                        confidence=float(edge.get("confidence") or 0.0),
                        evidence_id=f"relationship_graph:{normalize_fqn(str(edge['left_table']))}."
                                    f"{edge['conditions'][0]['left_column']}",
                    )
                    for edge in graph.get("edges") or []
                    if len(edge.get("conditions") or []) == 1 and not edge.get("literal_filters")
                    and (edge.get("verification") or {}).get("status") == "verified"
                ]
            return [key for key in cache[parent]
                    if key.parent_table == parent and key.parent_column.upper() == parent_column.upper()]

        confidence, _margin = self.decision_thresholds()
        resolutions = resolve(
            consumer_key=str(mapping.get("mapping_key") or ""), rows=rows, edges=edges,
            contracts=list(state.get("dependency_contracts") or []), consumer_tables=consumer_tables,
            foreign_keys=foreign_keys, min_confidence=confidence,
        )
        for item in resolutions:
            self._emit(
                "trace.action.completed",
                "succeeded" if item.status == "resolved" else "needs_review",
                f"{item.target_column} depends on {item.producer_mapping}.{item.producer_column}: {item.reason}",
                trace_id=f"dependency:{state.get('run_id')}:{mapping.get('mapping_key')}:{item.target_column}",
                parent_trace_id="mapping-execution", kind="validation", label="Resolve cross-target dependency",
                details=item.as_dict(),
            )
        return [item.as_dict() for item in resolutions]

    def _design_aggregate_cte(
        self, row: dict[str, Any], design: dict[str, Any], graph: RelationGraphContext,
    ) -> RelationGraphContext | None:
        """Give a row-combining rule its own per-driving-key CTE; the graph with it, or None."""
        from app.agent_tools.cte_designer import aggregate_per_key

        if not self._setting("migration_agent_cte_designer_enabled", True):
            return None
        canonical = self._canonical_row(row, design)
        expression = str(canonical.get("expression") or "")
        plan = aggregate_per_key(
            target_column=str(row["target_column"]),
            target_type=canonical.get("target_type"),
            expression=expression,
            graph=graph.model_dump(mode="json"),
            driving_id=design["driving_id"],
            derived_names={item["id"]: item["name"] for item in design.get("derived_sources") or []},
            max_hops=int(self._setting("migration_agent_cte_bridge_max_hops", 2)),
            reductions={
                item["id"]: entry["reduced_from"]
                for item in design.get("derived_sources") or []
                for entry in item.get("lineage") or [] if isinstance(entry, dict) and entry.get("reduced_from")
            },
        )
        if plan is None:
            return None
        derived = plan.derived_source
        if any(item["id"] == derived["id"] for item in design["derived_sources"]):
            nodes = list(graph.nodes)
        else:
            design["derived_sources"].append(derived)
            nodes = [*graph.nodes, RelationNode(
                relation_id=derived["id"], kind=RelationNodeKind.DERIVED_SOURCE,
                alias=relation_alias_for(derived["id"], derived["name"]), derived_source_id=derived["id"],
                sql_text=derived["sql_text"], output_columns=derived["output_columns"], grain=derived["grain"],
                keys=derived["keys"], base_relation_ids=[snapshot_table_fqn(ref) for ref in derived["base_source_tables"]],
            )]
        edges = [edge for edge in graph.edges if edge.edge_id != plan.edge["edge_id"]]
        edges.append(RelationEdge.model_validate(plan.edge))
        repair = {
            "target_column": row["target_column"], "root_cause": "aggregate_grain", "before": expression,
            "after": plan.expression, "method": "standard", "explanation": plan.explanation,
            "evidence": {"derived_source_id": derived["id"]},
        }
        row.update({
            "expression": plan.expression,
            "source_columns": [plan.source_column],
            "repairs": [*list(row.get("repairs") or []), repair],
        })
        self._emit(
            "trace.action.completed", "succeeded",
            f"Built CTE {derived['name']} for {row['target_column']}: {plan.explanation}",
            trace_id=f"cte-aggregate:{derived['id']}:{row['target_column']}", parent_trace_id="validation",
            kind="validation", label="Design aggregate CTE",
            details={"derived_source_id": derived["id"], "sql": derived["sql_text"]},
        )
        return graph.model_copy(update={"nodes": nodes, "edges": edges})

    def _sql_debugger(
        self,
        *,
        state: dict[str, Any],
        target_table: str,
        graph: RelationGraphContext,
        stored_graph: RelationGraphContext,
        design: dict[str, Any],
        compile_subset: Any,
        preview_limit: int,
    ) -> SqlDebugger | None:
        """A debugger over this mapping's canonical graph, or None when disabled."""
        if not bool(self._setting("migration_agent_sql_debug_enabled", True)):
            return None
        relation_columns: dict[str, set[str]] = {}
        derived_names = {item["id"]: item["name"] for item in design.get("derived_sources") or []}
        for node in graph.nodes:
            qualifier = (node.table.qualified_name if node.table is not None
                         else derived_reference_prefix(derived_names.get(node.relation_id, node.relation_id)))
            relation_columns[qualifier] = {
                str(item.get("name") or "") for item in node.output_columns
                if isinstance(item, dict) and item.get("name")
            }
        from app.core.mapping_sql import MappingSqlService
        placeholder_values: dict[str, tuple[str, str] | None] = {}
        for binding in stored_graph.value_bindings:
            names = {binding.attribute_name or "", str(binding.value or "").lstrip("$")}
            resolved = (
                str(binding.resolution_status or "").lower() in {"resolved", "project_attribute"}
                and binding.resolved_value is not None
            )
            value = ((MappingSqlService._compile_constant(binding.resolved_value, binding.data_type),
                      str(binding.resolved_value)) if resolved else None)
            for name in filter(None, names):
                placeholder_values[re.sub(r"[^A-Z0-9]", "", name.upper())] = value
        # A value stated in the user's notes or spec fills a placeholder the
        # project has not set; a value the project already holds wins.
        for binding in attachment_value_bindings(facts_for_target(state.get("attachment_readings") or [], target_table)):
            key = re.sub(r"[^A-Z0-9]", "", binding["name"].upper())
            if placeholder_values.get(key) is None:
                placeholder_values[key] = (MappingSqlService._compile_constant(binding["value"], None), binding["value"])
        context = DebugContext(
            relation_columns=relation_columns,
            placeholder_values=placeholder_values,
            target_types={key.upper(): value for key, value in (design.get("target_types") or {}).items()},
        )

        def probe(subset: list[MappingSqlMappingItem]) -> BaseException | None:
            compiled, error = compile_subset(subset)
            if error is not None:
                return error
            try:
                self._tool("mapping_sql.probe")
                with self._domain_lock:
                    self._mapping_sql.probe_preview(compiled.preview_sql, limit=preview_limit)
            except BudgetExceededError:
                raise
            except Exception as exc:  # noqa: BLE001 - the probe reports Snowflake's error
                return exc
            return None

        def render(subset: list[MappingSqlMappingItem]) -> str:
            request = MappingSqlCompileRequest(
                relation_graph=graph, mappings=subset, target_table=self._table_ref(target_table),
                driving_relation_id=design["driving_id"], validate_with_explain=False,
                allow_unresolved_placeholders=True,
            )
            with self._domain_lock:
                return self._mapping_sql.compile(request).preview_sql

        def on_event(kind: str, details: dict[str, Any]) -> None:
            target = details.get("target_column")
            if kind == "diagnosed":
                summary = f"Diagnosed {target}: {details.get('root_cause')}."
                status, label = "running", "Diagnose SQL error"
            elif kind == "repaired":
                summary = f"Fixed {target}: {details.get('explanation') or details.get('root_cause')}"
                status, label = "succeeded", "Repair column rule"
            else:
                summary = f"A proposed fix for {target} did not verify: {details.get('reason')}"
                status, label = "needs_review", "Repair column rule"
            self._emit(
                "trace.action.completed", status, summary,
                trace_id=f"sql-debug:{state['run_id']}:{target_table}:{target}:{kind}:{uuid4().hex[:8]}",
                parent_trace_id="validation", kind="validation", label=label,
                details={key: value for key, value in details.items() if key != "evidence"},
            )

        return SqlDebugger(
            context=context,
            compile_subset=compile_subset,
            render_subset=render,
            probe_subset=probe,
            model_fix=lambda item, diagnosis: self._sql_model_fix(state, item, diagnosis, context),
            max_attempts=int(self._setting("migration_agent_sql_debug_max_attempts", 12)),
            max_model_repairs_per_column=int(self._setting("migration_agent_sql_debug_max_model_repairs_per_column", 1)),
            on_event=on_event,
        )

    def _sql_model_fix(
        self, state: dict[str, Any], item: MappingSqlMappingItem, diagnosis: Diagnosis, context: DebugContext,
    ) -> tuple[str | None, str]:
        """One corrected expression from a structured completion; the debugger verifies it."""
        model = str(self._setting("migration_agent_sql_debug_model", "")
                    or self._setting("migration_agent_model_medium", "")
                    or self._setting("migration_agent_model_light", "") or "")
        if not model or self._session is None:
            return None, ""
        samples = self._debug_samples(item, diagnosis) if diagnosis.category in DATA_ERRORS else {}
        prompt = model_fix_prompt(
            item, diagnosis, target_type=context.target_types.get(item.target_column.upper()),
            relation_columns=context.relation_columns, samples=samples,
        )
        self._model("specialist.sql_debugger")
        with self._domain_lock:
            rows = self._session.sql(
                "SELECT AI_COMPLETE(model => ?, prompt => ?, response_format => PARSE_JSON(?)) AS RESPONSE",
                params=[model, prompt, json.dumps(MODEL_FIX_SCHEMA)],
            ).collect(statement_params={
                "STATEMENT_TIMEOUT_IN_SECONDS": str(int(self._setting("migration_agent_sql_debug_timeout_seconds", 60)))})
        raw = rows[0][0] if rows else None
        value = json.loads(raw) if isinstance(raw, str) else dict(raw or {})
        expression = str(value.get("expression") or "").strip()
        if not expression or placeholders_in(expression):
            return None, ""
        explanation = str(value.get("fix_explanation") or value.get("root_cause") or "Corrected by the SQL debugger.")
        return expression, explanation[:400]

    def _debug_samples(self, item: MappingSqlMappingItem, diagnosis: Diagnosis) -> dict[str, list[str]]:
        """A few distinct source values for the columns a failing rule reads."""
        limit = int(self._setting("migration_agent_sql_debug_sample_values", 5))
        samples: dict[str, list[str]] = {}
        if limit <= 0:
            return samples
        for dependency in item.source_dependencies[:3]:
            table, _, column = str(dependency).rpartition(".")
            ref = self._table_ref(table)
            column = column.strip('"')
            if ref is None or not _IDENTIFIER.fullmatch(column):
                continue
            quoted = ".".join(f'"{part}"' for part in (ref.database, ref.schema, ref.table))
            try:
                self._tool("snowflake.sample_values")
                with self._domain_lock:
                    rows = self._session.sql(
                        f'SELECT DISTINCT TO_VARCHAR("{column}") AS V FROM {quoted} WHERE "{column}" IS NOT NULL LIMIT {limit}'
                    ).collect()
            except BudgetExceededError:
                raise
            except Exception:  # noqa: BLE001 - samples are optional context
                continue
            samples[f"{ref.table}.{column}"] = [str(row[0])[:60] for row in rows]
        return samples

    @staticmethod
    def _canonical_row(row: dict[str, Any], design: dict[str, Any]) -> dict[str, Any]:
        """``row`` as the mapping grid saves it, qualified against the canonical design.

        A bare column name is qualified when exactly one selected relation
        produces it, as the grid's source-column picker would have chosen.
        """
        source_columns = design.get("source_columns") or {}
        derived = design.get("derived_sources") or []

        def qualify(value: Any) -> str:
            text = str(value or "").strip()
            name = text.strip('"')
            if not name or "." in name:
                return text
            owners = [
                table for table, columns in source_columns.items()
                if name.upper() in {str(column).upper() for column in columns}
            ]
            if len(owners) == 1:
                return f"{owners[0]}.{name}"
            derived_owners = [
                item for item in derived
                if name.upper() in {str(column.get("name") or "").upper() for column in item.get("output_columns") or []}
            ]
            if len(derived_owners) == 1:
                return f"{derived_reference_prefix(derived_owners[0]['name'])}.{name}"
            return text

        prepared = {**row, "source_columns": [qualify(value) for value in row.get("source_columns") or []]}
        # Specialists cite FIR recommendations (UUIDs) among evidence ids; the
        # grid field is what publishing credits back to the recommendation.
        cited = [str(value) for value in row.get("evidence_ids") or []
                 if re.fullmatch(r"[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", str(value))]
        if cited:
            prepared["used_recommendation_ids"] = list(dict.fromkeys([*(row.get("used_recommendation_ids") or []), *cited]))
        if row.get("source_dependencies"):
            prepared["source_dependencies"] = [qualify(value) for value in row["source_dependencies"]]
        # The grid holds resolved values; the firm values a rule used are kept by name.
        resolved = design.get("resolved_placeholders") or {}
        used = [name for name in firm_value_names_in(row.get("expression")) if f"${name}" in resolved]
        if row.get("mapping_mode") == "attribute" and row.get("attribute_name"):
            used.insert(0, str(row["attribute_name"]))
        if used:
            prepared["firm_values"] = list(dict.fromkeys([*used, *(row.get("firm_values") or [])]))
        target_type = (design.get("target_types") or {}).get(str(row.get("target_column") or "").upper())
        return canonical_mapping_row(
            prepared,
            target_type=target_type or row.get("target_type"),
            resolved_placeholders=design.get("resolved_placeholders"),
            qualifier_rewrites=design.get("rewrites"),
        )

    @staticmethod
    def _hold_back_row(row: dict[str, Any], reason: str) -> dict[str, Any]:
        """Move a draft row to review because its expression cannot be compiled.

        The rejected expression is kept on the row so the reviewer sees what
        was proposed and why Snowflake refused it.
        """
        expression = row.get("expression")
        row.update({
            "status": "unresolved",
            "rejected_expression": expression,
            "expression": None,
            # The match itself stays scored; only the rule failed. Reviewers
            # see both instead of an exact match shown at 0%.
            "candidate_confidence": row.get("candidate_confidence", row.get("confidence")),
            "rule_status": "sql_rejected",
            "confidence": 0.0,
            "sql_rejection": reason,
            "confidence_reason": f"{row.get('confidence_reason') or 'Candidate transformation'} Rejected: {reason}",
            "missing_dependencies": [*list(row.get("missing_dependencies") or []), "valid_snowflake_expression"],
        })
        return {"target_column": str(row["target_column"]), "expression": expression, "reason": reason}

    def _compile_without_failing_columns(
        self,
        *,
        state: dict[str, Any],
        target_table: str,
        mappings: list[MappingSqlMappingItem],
        rows_by_target: dict[str, dict[str, Any]],
        held_back: list[dict[str, Any]],
        compile_subset: Any,
        first_error: BaseException,
        result: dict[str, Any],
    ) -> tuple[Any, list[MappingSqlMappingItem]]:
        """Find the column expressions Snowflake rejects and compile the rest.

        Raises the compile error when the failure is in the join plan itself
        or cannot be attributed within the attempt budget.
        """
        budget = int(self._setting("migration_agent_sql_isolation_max_compiles", 16))
        isolation = isolate_failing_columns(
            mappings,
            compile_subset,
            key=lambda item: item.target_column,
            expression=lambda item: item.expression or "",
            max_attempts=budget,
            first_error=first_error,
        )
        result["isolation"] = {
            "attempts": isolation.attempts,
            "structural": isolation.structural,
            "exhausted": isolation.exhausted,
            "first_error": compile_error_summary(first_error),
        }
        if isolation.structural or isolation.compiled is None:
            raise isolation.error or first_error
        for target, reason in isolation.failing.items():
            row = rows_by_target.get(target)
            if row is None:
                continue
            item = self._hold_back_row(row, f"Snowflake rejected the expression ({reason}).")
            held_back.append(item)
            self._emit(
                "trace.action.completed",
                "needs_review",
                f"Held {target} back for review: Snowflake rejected its expression. The other columns still compile.",
                trace_id=f"sql-isolate:{state['run_id']}:{target_table}:{target}",
                parent_trace_id="validation",
                kind="validation",
                label="Isolate failing column",
                details={"target_column": target, "expression": item["expression"], "reason": reason},
            )
        return isolation.compiled, isolation.passing

    @staticmethod
    def _merge_specialist_decisions(
        source_response: SpecialistResponse,
        transform_response: SpecialistResponse,
    ) -> list[dict[str, Any]]:
        """Merge transformation advice without discarding source-selection evidence."""
        transformations = {
            decision.target_column: decision for decision in transform_response.decisions
        }
        rows: list[dict[str, Any]] = []
        for decision in source_response.decisions:
            transformed = transformations.get(decision.target_column)
            merged_source_columns = list(dict.fromkeys([
                *decision.source_columns,
                *(transformed.source_columns if transformed else []),
            ]))
            rows.append({
                "target_column": decision.target_column,
                "source_columns": merged_source_columns,
                "expression": (
                    transformed.expression
                    if transformed and transformed.expression
                    else decision.expression
                ),
                "mapping_classification": (
                    transformed.mapping_classification
                    if transformed and transformed.mapping_classification != "unresolved"
                    else decision.mapping_classification
                ),
                "confidence": min(
                    decision.confidence,
                    transformed.confidence if transformed else decision.confidence,
                ),
                "confidence_reason": (
                    f"{decision.decision_reason} {transformed.decision_reason}".strip()
                    if transformed else decision.decision_reason
                ),
                "used_learning_ids": sorted({
                    *decision.learning_ids_used,
                    *(transformed.learning_ids_used if transformed else []),
                }),
                "evidence_ids": sorted({
                    *decision.evidence_ids_used,
                    *(transformed.evidence_ids_used if transformed else []),
                }),
                "assumptions": list(dict.fromkeys([
                    *decision.assumptions,
                    *(transformed.assumptions if transformed else []),
                ])),
                "missing_dependencies": list(dict.fromkeys([
                    *decision.missing_dependencies,
                    *(transformed.missing_dependencies if transformed else []),
                ])),
                "status": (
                    "draft"
                    if decision.decision == "mapped"
                    and not (transformed and transformed.decision == "unresolved")
                    and not decision.missing_dependencies
                    and not (transformed.missing_dependencies if transformed else [])
                    else "unresolved"
                ),
            })
        return rows

    @staticmethod
    def _batch_uncorroborated_reviews(
        reviews: list[dict[str, Any]], rows: list[dict[str, Any]], target_table: str,
    ) -> list[dict[str, Any]]:
        """One review item for drafted columns that only lack corroboration.

        A mapped column below the confidence threshold with no disagreeing
        evidence needs a confirmation, not an investigation. Those are listed
        together, lowest confidence first. Columns where earlier evidence
        disagrees, and unresolved or held-back columns, keep their own items.
        """
        by_target = {str(row["target_column"]): row for row in rows}
        batched, kept = [], []
        for review in reviews:
            row = by_target.get(str(dict(review.get("details") or {}).get("target_column") or ""))
            evidence = dict((row or {}).get("confidence_evidence") or {})
            if (row is not None and row.get("status") == "draft" and not review.get("blocking")
                    and not evidence.get("conflicting_evidence_ids") and not row.get("sql_rejection")):
                batched.append((row, review))
            else:
                kept.append(review)
        if len(batched) < 2:
            return reviews
        batched.sort(key=lambda pair: float(pair[0].get("confidence") or 0))
        lines = [f"{row['target_column']} <- {', '.join(value.rsplit('.', 2)[-2] + '.' + value.rsplit('.', 1)[-1] for value in row.get('source_columns') or []) or row.get('expression') or 'constant'}"
                 f" ({float(row.get('confidence') or 0):.0%})" for row, _ in batched]
        kept.append({
            "category": "mapping_candidate_review",
            "blocking": False,
            "safe_summary": (f"{len(batched)} {target_table.rsplit('.', 1)[-1]} columns were mapped by the mapping agent "
                             "without independent corroboration. Confirm them together: " + "; ".join(lines)),
            "details": {"target_columns": [row["target_column"] for row, _ in batched],
                        "columns": [{"target_column": row["target_column"], "confidence": row.get("confidence"),
                                     "source_columns": row.get("source_columns") or [], "expression": row.get("expression"),
                                     "reasons": dict(row.get("confidence_evidence") or {}).get("reasons") or []}
                                    for row, _ in batched]},
        })
        return kept

    def _score_column_confidence(
        self,
        rows: list[dict[str, Any]],
        mapping_evidence: list[dict[str, Any]],
        source_contracts: dict[str, dict[str, Any]],
        target_column_contracts: list[dict[str, Any]],
    ) -> dict[str, list[str]]:
        """Replace self-reported confidence with evidence-based confidence on draft rows.

        Returns the target columns below the review threshold with the reasons.
        """
        from app.agent_tools.column_confidence import score_column, weights_from_settings

        weights = weights_from_settings(self._settings)
        threshold = float(self._setting("migration_agent_column_review_confidence", 0.75))
        target_types = {str(item.get("name") or "").upper(): str(item.get("type") or item.get("data_type") or "")
                        for item in target_column_contracts}
        source_types = {
            f"{normalize_fqn(table)}.{str(item.get('name') or '').upper()}": str(item.get("type") or "")
            for table, contract in source_contracts.items()
            for item in contract.get("column_contracts") or [] if isinstance(item, dict)
        }
        low: dict[str, list[str]] = {}
        for row in rows:
            if row.get("status") != "draft":
                continue
            scored = score_column(row, mapping_evidence, target_type=target_types.get(str(row["target_column"]).upper(), ""),
                                  source_types=source_types, weights=weights)
            row["specialist_confidence"] = row.get("confidence")
            row["confidence"] = scored["confidence"]
            row["confidence_evidence"] = {key: scored[key] for key in ("reasons", "agreeing_evidence_ids", "conflicting_evidence_ids")}
            row["evidence_ids"] = sorted({*list(row.get("evidence_ids") or []), *scored["agreeing_evidence_ids"]})
            if scored["confidence"] < threshold:
                low[str(row["target_column"])] = scored["reasons"]
        return low

    @staticmethod
    def _mapping_review_candidates(
        target_column: str,
        row: dict[str, Any],
        mapping_evidence: list[dict[str, Any]],
        source_contracts: dict[str, dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Keep only current, in-scope evidence as reviewable alternatives."""
        candidates: list[dict[str, Any]] = []
        if row.get("source_columns") or row.get("expression"):
            candidates.append({
                "source_columns": list(row.get("source_columns") or []),
                "transformation": row.get("expression"),
                "confidence": float(row.get("confidence") or 0),
                "reason": str(row.get("confidence_reason") or "Specialist proposal requires review."),
                "evidence_ids": list(row.get("evidence_ids") or []),
                "origin": "specialist",
            })
        contracts = {table.upper(): {str(col).upper() for col in contract.get("columns") or []}
                     for table, contract in source_contracts.items()}
        for item in mapping_evidence:
            if str(item.get("target_column") or "").upper() != target_column.upper():
                continue
            columns = [str(value) for value in item.get("source_columns") or []]
            if not columns and item.get("constant_value") is None:
                continue
            resolved_columns = []
            for value in columns:
                if "." not in value:
                    break
                table_name, column_name = value.rsplit(".", 1)
                matching_tables = [table for table, names in contracts.items()
                                   if (table == table_name.upper() or table.endswith("." + table_name.upper()))
                                   and column_name.upper() in names]
                if len(matching_tables) != 1:
                    break
                resolved_columns.append(f"{matching_tables[0]}.{column_name.upper()}")
            if len(resolved_columns) != len(columns):
                continue
            constant = item.get("constant_value")
            transformation = str(item.get("transformation") or "").strip()
            if not resolved_columns and (
                constant is None or str(constant).startswith("$")
            ):
                # A historical placeholder describes required business input,
                # not an executable current mapping candidate.
                continue
            origin = str(item.get("evidence_source") or "prior evidence")
            confidence = candidate_confidence(target_column, resolved_columns, item, mapping_evidence)
            candidates.append({
                "source_columns": resolved_columns,
                "transformation": transformation or None,
                "constant_value": constant,
                "confidence": round(confidence, 4),
                "reason": f"{origin.replace('_', ' ').capitalize()} candidate; current source columns exist, business applicability requires approval.",
                "evidence_ids": [str(item.get("evidence_id"))] if item.get("evidence_id") else [],
                "origin": origin,
            })
        unique: dict[tuple[Any, ...], dict[str, Any]] = {}
        for item in sorted(candidates, key=lambda value: value["confidence"], reverse=True):
            key = (tuple(item["source_columns"]), item.get("transformation"), item.get("constant_value"))
            unique.setdefault(key, item)
        return list(unique.values())[:3]

    @staticmethod
    def _promote_verified_plan_candidates(
        rows: list[dict[str, Any]],
        mapping_evidence: list[dict[str, Any]],
        source_contracts: dict[str, dict[str, Any]],
        target_column_contracts: list[dict[str, Any]],
    ) -> None:
        """Keep a current, executable best candidate as a reviewable draft.

        A specialist may omit a column or return only alternatives. A verified
        physical column or literal value can still be compiled and previewed;
        business acceptance remains explicit in the resulting review item.
        """
        target_types = {
            str(item.get("name") or "").upper(): str(item.get("type") or item.get("data_type") or "").upper()
            for item in target_column_contracts
        }
        for row in rows:
            if row.get("status") != "unresolved":
                continue
            candidates = WorkbenchWorkflowHandlers._mapping_review_candidates(
                str(row["target_column"]), row, mapping_evidence, source_contracts
            )
            best = candidates[0] if candidates else None
            if not best:
                continue
            sources = list(best.get("source_columns") or [])
            rule = str(best.get("transformation") or "").strip()
            expression = None
            classification = "direct"
            if len(sources) == 1 and rule.lower() in {"", "direct", "source", "none"}:
                pass
            elif not sources and best.get("constant_value") is not None and rule.lower() in {"", "value"}:
                value = str(best["constant_value"])
                if value.startswith("$") or any(char in value for char in "();\n\r"):
                    continue
                target_type = target_types.get(str(row["target_column"]).upper(), "")
                if value.upper() == "NULL":
                    expression = "NULL"
                elif re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value) and any(
                    token in target_type for token in ("NUMBER", "INT", "DECIMAL", "FLOAT")
                ):
                    expression = value
                else:
                    quoted = "'" + value.replace("'", "''") + "'"
                    expression = f"TO_DATE({quoted})" if target_type == "DATE" else quoted
                classification = "constant"
            else:
                continue
            row.update({
                "source_columns": sources,
                "expression": expression,
                "mapping_classification": classification,
                "confidence": float(best["confidence"]),
                "confidence_reason": str(best.get("reason") or "Verified current candidate; business review pending."),
                "evidence_ids": list(best.get("evidence_ids") or []),
                "missing_dependencies": [],
                "assumptions": [*list(row.get("assumptions") or []), "Provisional best candidate; business approval pending."],
                "status": "draft",
            })

    @staticmethod
    def _promote_approved_value_bindings(
        rows: list[dict[str, Any]], bindings: list[dict[str, Any]],
        target_column_contracts: list[dict[str, Any]],
    ) -> None:
        """Compile explicit current-project values for their approved targets."""
        target_types = {
            str(item.get("name") or "").upper(): str(item.get("type") or item.get("data_type") or "").upper()
            for item in target_column_contracts
        }
        by_target: dict[str, list[dict[str, Any]]] = {}
        for binding in bindings:
            if binding.get("resolution_status") != "resolved" or binding.get("approval_state") != "approved":
                continue
            value = binding.get("resolved_value")
            if value is None:
                continue
            for target in binding.get("target_columns") or []:
                by_target.setdefault(str(target).upper(), []).append(binding)
        for row in rows:
            # A project value may be only one ingredient in a derived rule
            # (for example, a prefix joined to a source identifier). Never
            # replace such a source-dependent rule with the bare value.
            if row.get("status") != "unresolved" or row.get("source_columns"):
                continue
            matches = by_target.get(str(row.get("target_column") or "").upper(), [])
            if len(matches) != 1:
                continue
            binding = matches[0]
            value = str(binding["resolved_value"]).strip()
            target_type = target_types.get(str(row["target_column"]).upper(), "")
            if not valid_typed_project_value(value, binding.get("data_type") or target_type) and value.upper() != "NULL":
                continue
            if value.upper() == "NULL":
                expression = "NULL"
            elif any(token in target_type for token in ("NUMBER", "INT", "DECIMAL", "FLOAT")) and re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value):
                expression = value
            elif target_type.startswith("BOOLEAN") and value.upper() in {"TRUE", "FALSE"}:
                expression = value.upper()
            else:
                quoted = "'" + value.replace("'", "''") + "'"
                expression = f"TO_DATE({quoted})" if target_type == "DATE" else quoted
            row.update({
                "source_columns": [], "expression": expression,
                "mapping_classification": "constant", "status": "draft",
                "confidence": max(float(row.get("confidence") or 0), 0.9),
                "confidence_reason": "Approved current-project value binding.",
                "evidence_ids": list(binding.get("evidence_ids") or []),
                "missing_dependencies": [],
                "assumptions": [*list(row.get("assumptions") or []), "Bound to approved current-project value."],
            })

    def check_active(self) -> None:
        if self._budget:
            self._budget.ensure_active("partition scheduling")

    def save_partition(self, state, partition) -> None:
        from app.agent_runs.models import MappingDagNode, StepStatus
        status = {"COMPLETED": StepStatus.SUCCEEDED, "RUNNING": StepStatus.RUNNING,
                  "WAITING_FOR_DEPENDENCY": StepStatus.BLOCKED}.get(partition.state.value, StepStatus.NEEDS_REVIEW)
        self.check_active()
        with self._domain_lock:
            self._repository.save_dag_node(MappingDagNode(
                run_id=state["run_id"], mapping_key="partition:" + partition.partition_id,
                mapping_name=partition.mapping_key, status=status,
                partition_payload=partition.model_dump(mode="json"),
                plan_hash=state.get("approved_plan_hash"),
            ))
        self._partition_milestone(state, partition)

    @staticmethod
    def _short_name(table: Any) -> str:
        return str(table or "").rsplit(".", 1)[-1].strip('"')

    def _milestone(self, target: str, phase: str, **facts: Any) -> None:
        """Record a structured fact for the supervisor to narrate; never chat text."""
        progress = getattr(self, "progress", None)
        if progress is None:
            return
        try:
            progress.milestone(str(target), phase, **facts)
        except Exception:
            logger.debug("Progress fact was not recorded", exc_info=True)

    def _sources_milestone(self, target: str, package: dict[str, Any], diagnostics: dict[str, Any]) -> None:
        unresolved = list(diagnostics.get("unresolved") or [])
        if unresolved:
            self._milestone(target, "needs_review", stage="source_preparation",
                            findings=[str(item)[:160] for item in unresolved[:4]], finding_count=len(unresolved))
            return
        workspace = dict((package or {}).get("workspace") or {})
        driving = workspace.get("driving_table")
        self._milestone(
            target, "mapping", stage="sources_ready",
            source_tables=[self._short_name(item.get("table") if isinstance(item, dict) else item)
                           for item in workspace.get("source_tables") or []][:8],
            driving_table=self._short_name(driving.get("table") if isinstance(driving, dict) else driving) or None,
            join_count=len(workspace.get("relationships") or []),
            population_filter=(str(dict(workspace.get("filters") or {}).get("filter_sql") or "")[:200] or None),
        )

    def _partition_milestone(self, state: dict[str, Any], partition: Any) -> None:
        """Per-target facts from partition state changes, for the supervisor to narrate."""
        if getattr(self, "progress", None) is None:
            return
        mapping = next((item for item in state.get("manifest") or []
                        if item.get("mapping_key") == partition.mapping_key), {})
        target = str(mapping.get("target_table") or partition.mapping_key)
        value = partition.state.value
        result = dict(partition.result or {})
        counts = self.__dict__.setdefault("_progress_counts", {}).setdefault(
            f"{state.get('run_id')}:{partition.mapping_key}", {})
        if partition.stage == "map":
            if value in {"COMPLETED", "NEEDS_REVIEW"}:
                total = len(result.get("target_columns") or partition.columns or [])
                counts[partition.partition_id] = (len(result.get("mapped_target_columns") or []), total)
            elif value == "RUNNING":
                progress = getattr(self, "progress", None)
                if progress is not None:
                    progress.set_phase(target, "mapping")
            return
        mapped = sum(item[0] for item in counts.values())
        total = sum(item[1] for item in counts.values())
        if value == "RUNNING":
            self._milestone(target, "compiling", mapped_columns=mapped, target_columns=total)
            return
        validation = dict(result.get("sql_validation") or {})
        facts = {
            "mapped_columns": len(result.get("mapped_target_columns") or []) or mapped,
            "target_columns": len(result.get("target_columns") or []) or total,
            "compile_valid": validation.get("compile_valid"),
            "preview_valid": validation.get("preview_valid"),
            "preview_rows": validation.get("preview_row_count"),
            "population_rules": [item.get("predicate") for item in validation.get("population_rules") or []
                                 if isinstance(item, dict)][:3],
        }
        if value == "COMPLETED":
            self._milestone(target, "done", **facts)
        elif value not in {"READY", "WAITING_FOR_DEPENDENCY"}:
            self._milestone(target, "needs_review", **facts,
                            unresolved_columns=list(result.get("unresolved_target_columns") or [])[:8],
                            reason=str(result.get("safe_summary") or "")[:200] or None)

    def _follow_up_carried_rows(self, state: dict[str, Any], mapping: dict[str, Any],
                                columns: list[str]) -> list[dict[str, Any]]:
        """Parent-draft rows a scoped follow-up keeps unchanged.

        Only a child run reusing its lineage's draft qualifies, and only when the
        approved plan names a strict subset of the target's columns. Any column
        the parent draft lacks is re-mapped, so the compile stage always sees
        every target column exactly once.
        """
        if not state.get("parent_run_id") or not mapping.get("sttm_id"):
            return []
        plan = state.get("migration_plan") or {}
        spec = next((item for item in plan.get("mapping_specs") or []
                     if item.get("mapping_key") == mapping.get("mapping_key")), None)
        auto_map = dict((spec or {}).get("auto_map") or plan.get("auto_map") or {})
        requested = {str(column).upper() for column in auto_map.get("target_columns") or []}
        contract = {column.upper() for column in columns}
        if not requested or not requested < contract:
            return []
        with self._domain_lock:
            detail = self._projects.get_sttm_detail(str(mapping["sttm_id"]))
        if detail is None or str(detail.sttm.metadata.get("migration_run_id") or "") not in set(
                state.get("run_lineage") or []):
            return []
        carried: dict[str, dict[str, Any]] = {}
        for row in (detail.latest_snapshot or {}).get("mapping_rows") or []:
            column = str(row.get("target_column") or "").upper()
            if column in contract and column not in requested and column not in carried:
                # The draft holds grid rows (MAPPED/UNMAPPED); the agent's own
                # draft/unresolved state is kept in review_status.
                durable = dict(row)
                review = str(durable.pop("review_status", "") or "").lower()
                durable["status"] = review if review in {"draft", "unresolved"} else (
                    "draft" if str(row.get("status") or "").upper() == "MAPPED" else "unresolved")
                durable.setdefault("mapping_classification", row.get("transformation_classification") or "direct")
                durable["carried_from_run_id"] = str(state.get("parent_run_id") or "")
                carried[column] = durable
        return [carried[column] for column in sorted(carried)]

    def build_partitions(self, state):
        from app.migration_workflow.scheduler import Dependency, Partition, PartitionState
        plan = state.get("migration_plan") or {}
        dependencies = [Dependency.model_validate(d) for d in [
            *plan.get("dependencies", []),
            *[d for spec in plan.get("mapping_specs", []) for d in spec.get("dependencies", [])],
        ]]
        dependencies = list({d.model_dump_json():d for d in dependencies}.values())
        partitions = []
        for mapping in state.get("manifest") or []:
            key = mapping["mapping_key"]
            columns = self._describe_table(mapping["target_table"])["columns"]
            carried = self._follow_up_carried_rows(state, mapping, columns)
            if carried:
                # A follow-up re-maps only the columns it names; every other
                # column keeps the parent draft's row.
                partitions.append(Partition(
                    partition_id=f"{key}:map:carried", mapping_key=key,
                    project_id=str(state.get("project_id") or ""),
                    columns=[str(row["target_column"]) for row in carried], state=PartitionState.COMPLETED,
                    result={"mapping_rows": carried, "target_columns": [row["target_column"] for row in carried],
                            "mapped_target_columns": [row["target_column"] for row in carried
                                                      if row.get("status") == "draft"],
                            "carried_from_run_id": state.get("parent_run_id")},
                ))
                kept = {str(row["target_column"]).upper() for row in carried}
                columns = [column for column in columns if column.upper() not in kept]
            relevant = [d for d in dependencies if d.consumer_mapping == key]
            unknown = {c for d in relevant for c in d.consumer_columns} - set(columns)
            if unknown:
                raise ValueError(f"Dependency references unknown columns: {sorted(unknown)}")
            groups = {}
            for column in columns:
                edges = tuple(i for i,d in enumerate(relevant) if d.blocking_scope in {"column", "mapping"} and (not d.consumer_columns or column in d.consumer_columns))
                groups.setdefault(edges, []).append(column)
            own = [f"{key}:map:carried"] if carried else []
            for i,(indices, targets) in enumerate(groups.items()):
                partition_id = f"{key}:map:{i}"
                own.append(partition_id)
                partitions.append(Partition(partition_id=partition_id, mapping_key=key,
                    project_id=str(state.get("project_id") or ""), columns=targets,
                    dependencies=[relevant[j] for j in indices]))
            partitions.append(Partition(partition_id=f"{key}:compile", mapping_key=key,
                project_id=str(state.get("project_id") or ""), stage="compile", waits_for=own,
                dependencies=[d for d in relevant if d.blocking_scope not in {"column", "mapping"}]))
        with self._domain_lock:
            saved = {node.mapping_key.removeprefix("partition:"): node for node in self._repository.list_dag_nodes(state["run_id"])
                     if node.partition_payload and node.plan_hash == state.get("approved_plan_hash")}
        # A completed partition may contain conservative unresolved rows from
        # a malformed specialist response. Rerun that partition on explicit
        # recovery while keeping partitions with valid decisions intact.
        retry_technical_mapping = {
            key for key, node in saved.items()
            if key.endswith(":compile") and
            str(node.status.value) == "NEEDS_REVIEW" and (
                not (node.partition_payload or {}).get("result", {}).get("sql_validation", {}).get("compile_valid", False)
                or any(
                    set(row.get("missing_dependencies") or []).intersection({
                        "valid_specialist_decision", "specialist_decision", "value_or_attribute_binding"
                    })
                    for row in (node.partition_payload or {}).get("result", {}).get("mapping_rows") or []
                )
            )
        }
        for index,p in enumerate(partitions):
            if p.partition_id in saved:
                previous = Partition.model_validate(saved[p.partition_id].partition_payload)
                if (previous.revision == p.revision and previous.columns == p.columns
                        and previous.dependencies == p.dependencies and previous.project_id in {"", p.project_id}):
                    previous.project_id = p.project_id
                    malformed_rows = (
                        previous.stage == "map" and
                        f"{previous.mapping_key}:compile" in retry_technical_mapping and
                        any({"valid_specialist_decision", "specialist_decision", "value_or_attribute_binding"}.intersection(
                                row.get("missing_dependencies") or [])
                            for row in (previous.result or {}).get("mapping_rows") or [])
                    )
                    if previous.state.value == "NEEDS_REVIEW" or malformed_rows:
                        prior = dict(previous.result or {})
                        reusable_rows = [dict(row) for row in prior.get("mapping_rows") or []
                                         if row.get("status") == "draft" and not row.get("missing_dependencies")
                                         and not row.get("sql_rejection")]
                        previous.state = PartitionState.READY
                        previous.result = ({"retry_mapping_rows": reusable_rows}
                                           if previous.stage == "compile" and prior.get("sql_validation", {}).get("compile_valid") else {})
                    partitions[index] = previous
        return partitions

    def execute_partition(self, state, mapping, partition, partitions):
        if self.partition_factory is not None:
            with self.partition_factory() as isolated:
                return isolated.execute_partition(state, mapping, partition, partitions)
        from copy import deepcopy
        from app.migration_workflow.scheduler import merge_column_partitions
        local = deepcopy(state)
        prepared = (state.get("mapping_context_packages") or {}).get(mapping["mapping_key"])
        if not prepared:
            raise ValueError("Mapping has no validated source-preparation context")
        context = MappingContextPackageV1.model_validate(prepared)
        workspace = context.workspace.model_copy(update={"sttm_id": mapping["sttm_id"]})
        context_values = context.model_dump(mode="json", exclude={"context_hash"})
        context_values["workspace"] = workspace.model_dump(mode="json")
        local["mapping_context_package"] = MappingContextPackageV1.model_validate(context_values).model_dump(mode="json")
        local["authorized_source_scope"] = [table.qualified_name for table in workspace.source_tables]
        local["accepted_precedent"] = dict(
            ((state.get("source_preparation_result") or {}).get("mappings") or {})
            .get(mapping["mapping_key"], {}).get("accepted_precedent") or {}
        )
        local["dependency_contracts"] = [c.model_dump(mode="json") for c in partition.dependency_contracts]
        dependencies = [*(state.get("migration_plan") or {}).get("dependencies", []),
            *[d for spec in (state.get("migration_plan") or {}).get("mapping_specs", []) for d in spec.get("dependencies", [])]]
        from app.migration_workflow.artifacts import emit_artifact_contracts
        def with_contracts(result, stages):
            output=[]
            for stage in stages:
                output.extend(emit_artifact_contracts(mapping_key=mapping["mapping_key"],
                    project_id=str(state.get("project_id") or ""),revision=partition.revision,
                    stage=stage,result=result,dependencies=dependencies))
            return {**result,"artifact_contracts":output}
        if partition.stage == "map":
            result = self.execute_mapping(local, {**mapping, "partition_columns": partition.columns, "defer_compile": True})
            return with_contracts(result, ["mapped"])
        rows = merge_column_partitions([p for p in partitions if p.mapping_key == mapping["mapping_key"]])
        reusable = {str(row["target_column"]): row
                    for row in (partition.result or {}).get("retry_mapping_rows") or []}
        # Retry unfinished decisions while preserving completed expressions.
        # The full compiler/preview still runs against current contracts.
        rows = [dict(reusable.get(str(row["target_column"]), row)) for row in rows]
        result = self.execute_mapping(local, {**mapping, "finalize_rows": rows})
        return with_contracts({**result, "partition_state": "COMPLETED" if result.get("status") == "READY_FOR_REVIEW" else "NEEDS_REVIEW"}, ["compiled", "validated"])

    def _accepted_precedent_rows(
        self, *, state: dict[str, Any], target_table: str, target_columns: list[str],
    ) -> list[dict[str, Any]]:
        accepted = dict(state.get("accepted_precedent") or {})
        sttm_id = str(accepted.get("sttm_id") or "")
        if not sttm_id:
            raise ValueError("No completed precedent was verified for this mapping")
        self._tool("project.read_completed_precedent")
        with self._domain_lock:
            detail = self._projects.get_sttm_detail(sttm_id)
        if not detail or str(detail.sttm.status).upper() != accepted.get("status"):
            raise ValueError("The historical mapping status changed after source preparation")
        if str(detail.sttm.target_table or "").upper() != target_table.upper():
            raise ValueError("The completed precedent target has changed")
        snapshot = dict(detail.latest_snapshot or {})
        sql = str(snapshot.get("mapping_sql") or snapshot.get("raw_mapping_sql") or "")
        if hashlib.sha256(sql.strip().encode("utf-8")).hexdigest() != accepted.get("sql_sha256"):
            raise ValueError("The completed precedent SQL revision has changed")
        _scoped_precedent_query(
            sql, allowed_sources=list(state.get("authorized_source_scope") or []),
            target_columns=self._describe_table(target_table)["columns"],
        )
        parsed = parse_sql_document(sql)
        by_target = {
            str(row.get("target_column") or "").upper(): row
            for row in (snapshot.get("mapping_rows") or detail.mapping_rows or [])
            if isinstance(row, dict) and row.get("target_column")
        }
        parsed_targets = {
            str(item.target_alias or "").upper(): item
            for item in parsed.column_mappings
        }
        rows = []
        for column in target_columns:
            original = by_target.get(column.upper(), {})
            parsed_row = parsed_targets[column.upper()]
            columns = list(original.get("source_columns") or parsed_row.physical_source_columns or [])
            expression = str(original.get("expression") or original.get("rule") or "").strip()
            if expression.lower() in {"direct", "custom", "source"}:
                expression = ""
            expression = expression or str(parsed_row.transformation or "").strip()
            rows.append({
                "target_column": column,
                "source_columns": columns,
                "expression": expression or None,
                "mapping_classification": (
                    "constant" if parsed_row.mapping_mode == "constant" else
                    "many_to_one" if len(columns) > 1 else
                    "derived" if expression else "direct"
                ),
                "confidence": 1.0 if accepted.get("status") in {"COMPLETE", "PUBLISHED"} else 0.7,
                "confidence_reason": "Exact historical SQL reused with current target and source contracts; draft business rules require review." if accepted.get("status") == "IN_PROGRESS" else "Exact completed precedent reused with current target and source contracts; business applicability remains reviewable.",
                "used_learning_ids": [],
                "evidence_ids": [f"sttm_precedent:{sttm_id}"],
                "assumptions": [],
                "missing_dependencies": [],
                "precedent_decision": (
                    "reuse_precedent_candidate" if accepted.get("status") == "IN_PROGRESS"
                    else "accept_precedent"
                ),
                "precedent_mapping_id": sttm_id,
                "status": "draft",
            })
        return rows

    def execute_mapping(self, state: dict[str, Any], mapping: dict[str, Any]) -> dict[str, Any]:
        if self._specialists is None and not state.get("accepted_precedent"):
            return {"mapping_key": mapping["mapping_key"], "mapping_name": mapping["mapping_name"], "sttm_id": mapping.get("sttm_id"), "status": "NEEDS_REVIEW", "partition_state": "NEEDS_REVIEW", "safe_summary": "Specialist agents are not configured; mapping could not execute."}
        mapping_key = str(mapping["mapping_key"])
        trace_id = f"mapping:{mapping_key}"
        self._emit(
            "automap.started",
            "running",
            f"Auto Map started for {mapping['mapping_name']} using the prepared workspace snapshot.",
            trace_id=trace_id,
            parent_trace_id="mapping-execution",
            kind="workflow",
            label="Auto Map",
            details={
                "mapping_key": mapping_key,
                "context_hash": str((state.get("mapping_context_package") or {}).get("context_hash") or ""),
            },
        )
        self._emit("trace.group.started", "running", f"Building {mapping['mapping_name']}.", trace_id=trace_id, parent_trace_id="mapping-execution", kind="mapping", label=mapping["mapping_name"])
        target_table = str(mapping["target_table"])
        source_tables = list(state.get("authorized_source_scope") or [])
        self._describe_tables([target_table, *source_tables])
        target_contract = self._describe_table(target_table)
        target_columns = mapping.get("partition_columns", target_contract["columns"])
        source_contracts = {table: self._describe_table(table) for table in source_tables}
        source_columns = {table: contract["columns"] for table, contract in source_contracts.items()}
        compiler_graph, _, _, _ = self._compiler_graph(
            state=state, source_tables=source_tables, source_columns=source_columns,
        )
        compiler_graph_payload = {
            "nodes": [node.model_dump(mode="json", include={
                "relation_id", "kind", "alias", "table", "derived_source_id",
                "output_columns", "grain", "keys", "base_relation_ids",
            }, exclude_none=True) for node in compiler_graph.nodes],
            "edges": [edge.model_dump(mode="json", exclude_none=True)
                      for edge in compiler_graph.edges],
            "value_bindings": [binding.model_dump(mode="json", exclude_none=True)
                               for binding in compiler_graph.value_bindings],
        }
        accepted = dict(state.get("accepted_precedent") or {})
        semantic_context = dict(
            (state.get("mapping_context_package") or {}).get("stored_semantic_context") or {}
        )
        if self._semantic_context is not None and not accepted:
            try:
                workspace_for_projection = MappingContextPackageV1.model_validate(
                    state.get("mapping_context_package") or {}
                ).workspace
                self._tool("semantic_context.project_mapping_batch")
                with self._domain_lock:
                    semantic_bundle, semantic_projection = self._resolve_semantic_bundle(
                        workspace=workspace_for_projection,
                        target_columns=target_columns,
                        source_columns_by_table=source_columns,
                    )
                semantic_context.update({
                    "status": "available",
                    "bundle_id": semantic_bundle.bundle_id,
                    "bundle_hash": semantic_bundle.bundle_hash,
                    "semantic_view_name": semantic_bundle.semantic_view_name,
                    "composed_model_hash": semantic_bundle.summary.composed_model_hash,
                    "covered_tables": list(semantic_bundle.summary.tables),
                    "projection_id": semantic_projection["projection_id"],
                    "projection_hash": semantic_projection["projection_hash"],
                    "mapping_projection": semantic_projection["payload"],
                    "reading_instructions": (
                        semantic_bundle.reading_instructions.model_dump(mode="json")
                        if semantic_bundle.reading_instructions else {}
                    ),
                })
            except Exception:
                # Physical contracts and FIR remain valid fallbacks. The
                # specialist sees the explicit unavailable/partial reference.
                semantic_context.setdefault("status", "unavailable")
        from app.agent_runs.policy import policy_from_state
        policy = policy_from_state(state)
        # An exact, hash-bound precedent already carries the evidence used to
        # select every column. Repeating open-ended retrieval here adds latency
        # and can turn an unavailable optional search service into a mapping
        # failure. The stored SQL and current contracts are rechecked below.
        learning_cards, retrieved_learning_ids = ([], []) if accepted else self._learning_cards(
            state=state, target_table=target_table, target_columns=target_columns,
            budget=policy.retrieval_card_limit,
        )
        if self._settings is not None and not accepted:
            from app.core.migration_knowledge import EvidenceScope, MigrationKnowledgeService, digest
            actor = self._actor(state)
            project_id = str(state.get("project_id") or "")
            scope = EvidenceScope(account=self._settings.snowflake_account, tenant_id=actor.tenant_id,
                project_id=project_id, authorization_fingerprint=digest({"account":self._settings.snowflake_account,
                    "role":actor.effective_role,"project":project_id}))
            semantic_version = str(semantic_context.get("bundle_hash") or "unavailable")
            contract_version = digest({"target":target_contract,"sources":source_contracts})
            with self._domain_lock:
                knowledge = MigrationKnowledgeService(self._session,self._settings,scope)
                records = knowledge.retrieve(
                    [target_column_subject(target_table,column) for column in target_columns],
                    semantic_version=semantic_version,contract_version=contract_version,limit=policy.retrieval_card_limit)
                if len(records) < policy.retrieval_card_limit:
                    discovered = knowledge.search(str(state.get('prompt') or target_table),
                        semantic_version=semantic_version,contract_version=contract_version,
                        limit=policy.retrieval_card_limit-len(records))
                    known = {record['learning_id'] for record in records}
                    records.extend(record for record in discovered if record['learning_id'] not in known)
            for record in records:
                learning_cards.append(LearningCard(learning_id=record["learning_id"],subject_type=record["kind"],
                    subject_key=record["subject_key"],claim_key=digest(record["structured_rule"]),summary=record["summary"],
                    confidence=record["confidence"],validation_status="APPROVED_BUSINESS_RULE",
                    structured_rule=record["structured_rule"],evidence_ids=record["evidence_ids"],
                    applicability={"semantic_version":semantic_version,"contract_version":contract_version}))
                retrieved_learning_ids.append(record["learning_id"])
        # Earlier mappings that bind these columns to firm values, and the
        # project's own firm values: the specialists see both.
        firm_context = ({"held": {}, "choices": {}, "values": []} if accepted
                        else self._firm_value_context(state, list(target_columns), target_table))
        specialist_learning = ({} if accepted or self._learning is None
                               else self._specialist_learning(state, target_table, list(target_columns),
                                                              list(source_tables), source_contracts))
        request = SpecialistRequest(
            run_id=str(state["run_id"]), step_id=f"map:{mapping['mapping_key']}", project_id=str(state["project_id"]), sttm_id=str(mapping["sttm_id"]), snapshot_id=f"draft:{mapping['sttm_id']}",
            target_contract={"target_table": target_table, "columns": target_contract["column_contracts"]}, target_columns=target_columns,
            allowed_source_tables=source_tables, allowed_source_columns=source_columns,
            compiler_relation_graph=compiler_graph_payload,
            relationship_graph=list(
                (state.get("mapping_context_package") or {}).get("workspace", {}).get("relationships") or []
            ),
            derived_outputs=list(
                (state.get("mapping_context_package") or {}).get("workspace", {}).get("derived_sources") or []
            ),
            stored_semantic_context=semantic_context,
            dependency_contracts=list(state.get("dependency_contracts") or []),
            attachment_facts=facts_for_target(state.get("attachment_readings") or [], target_table)[:80],
            workspace_context={
                "project_id": (state.get("mapping_context_package") or {}).get("workspace", {}).get("project_id"),
                "project_name": (state.get("mapping_context_package") or {}).get("workspace", {}).get("project_name"),
                "business_goal": (state.get("mapping_context_package") or {}).get("workspace", {}).get("business_goal"),
                "mapping_intent": (state.get("mapping_context_package") or {}).get("workspace", {}).get("mapping_intent"),
                "semantic_bundle": (state.get("mapping_context_package") or {}).get("workspace", {}).get("semantic_bundle"),
            },
            workspace_snapshot=dict((state.get("mapping_context_package") or {}).get("workspace") or {}),
            query_rules=dict(
                (state.get("mapping_context_package") or {}).get("workspace", {}).get("filters") or {}
            ),
            intended_grain=(state.get("migration_plan") or {}).get("source_preparation", {}).get("intended_grain"),
            original_request=str(state.get("prompt") or ""),
            current_mapping_rows=list(
                (state.get("mapping_context_package") or {}).get("workspace", {}).get("mapping_rows") or []
            ),
            learning_cards=learning_cards,
            target_mapping_patterns=list(specialist_learning.get("target_mapping_patterns") or []),
            fir_recommendations=list(specialist_learning.get("fir_recommendations") or []),
            project_value_placeholders=firm_value_hints(firm_context["choices"], firm_context["held"]),
            token_budget=policy.retrieval_token_budget, tool_budget=min(policy.tool_call_budget, 100),
            actor_user_id=self._actor(state).user_id, effective_role=str(self._actor(state).effective_role), tenant_id=self._actor(state).tenant_id,
        )
        prefilled = []
        source_agent_decisions = []
        if "finalize_rows" in mapping:
            rows = mapping["finalize_rows"]
            source_response = SpecialistResponse(safe_summary="Reused durable column partition decisions.")
            transform_response = SpecialistResponse()
            complex_targets = [row["target_column"] for row in rows
                               if row.get("mapping_classification") in {"derived", "many_to_one"}
                               and not row.get("expression") and not accepted]
            if complex_targets:
                from app.agent_tools.specialists import (
                    MalformedAgentResultError, SpecialistDecision,
                    decision_from_durable_row, complete_transformation_response,
                )
                try:
                    self._model("cortex_agent.transformation_rule")
                    self._tool("cortex_agent.transformation_rule")
                    transform_response = self._specialists.transformation_rule(request.model_copy(update={
                        "target_columns": complex_targets, "current_mapping_rows": rows}))
                    transform_response = complete_transformation_response(transform_response, complex_targets)
                except MalformedAgentResultError:
                    transform_response = SpecialistResponse(decisions=[SpecialistDecision(
                        target_column=column, decision="unresolved", confidence=0,
                        decision_reason="The transformation specialist did not return a valid structured rule.",
                        missing_dependencies=["valid_transformation_decision"],
                    ) for column in complex_targets], review_items=[{
                        "category": "transformation_specialist_unresolved", "blocking": True,
                        "safe_summary": "Transformation rules need review; valid source mappings were retained.",
                    }])
                source_response = SpecialistResponse(decisions=[decision_from_durable_row(row) for row in rows])
                rows = self._merge_specialist_decisions(source_response, transform_response)
            from collections import Counter
            from app.agent_tools.specialists import MalformedAgentResultError
            counts = Counter(row["target_column"] for row in rows)
            if set(counts) != set(target_columns) or any(count != 1 for count in counts.values()):
                raise MalformedAgentResultError("Durable mapping rows must cover each assigned target exactly once")
            duplicate_targets = []
        elif accepted:
            rows = self._accepted_precedent_rows(
                state=state, target_table=target_table, target_columns=target_columns,
            )
            source_response = SpecialistResponse(
                safe_summary="Reused an exact completed precedent after current contract and scope verification."
            )
            transform_response = SpecialistResponse()
            complex_targets = []
            duplicate_targets = []
        else:
            from app.agent_tools.prefill import prefill_exact_contracts
            prefilled = prefill_exact_contracts(target_contract["column_contracts"], source_contracts, target_columns)
            unresolved_targets = [c for c in target_columns if c not in {d.target_column for d in prefilled}]
            source_response, transform_response = self._specialists.map_targets(
                request.model_copy(update={"target_columns": unresolved_targets}), max_workers=policy.max_parallel_mappings,
                before_call=lambda operation: (self._model(operation), self._tool(operation)),
                transform=not mapping.get("defer_compile", False),
            )
            source_agent_decisions = list(source_response.decisions)
            source_response.decisions = prefilled + source_response.decisions
            complex_targets = [d.target_column for d in source_response.decisions if d.requires_transformation or d.mapping_classification in {"derived", "many_to_one"}]

            source_targets = [decision.target_column for decision in source_response.decisions]
            duplicate_targets = sorted({value for value in source_targets if source_targets.count(value) > 1})
            rows = self._merge_specialist_decisions(source_response, transform_response)
            decided_targets = {str(row["target_column"]) for row in rows}
            for column in target_columns:
                if column not in decided_targets:
                    rows.append({"target_column": column, "source_columns": [], "expression": None, "mapping_classification": "unresolved", "confidence": 0.0, "confidence_reason": "No specialist decision was returned.", "used_learning_ids": [], "evidence_ids": [], "assumptions": [], "missing_dependencies": ["specialist_decision"], "status": "unresolved"})
            self._emit(
                "automap.batch_completed",
                "succeeded",
                f"Auto Map classified all {len(target_columns)} target columns.",
                trace_id=f"{trace_id}:batch:1",
                parent_trace_id=trace_id,
                kind="workflow",
                label="Auto Map target-column batch",
                details={
                    "target_column_count": len(target_columns),
                    "mapped_count": sum(1 for row in rows if row["status"] == "draft"),
                    "unresolved_count": sum(1 for row in rows if row["status"] == "unresolved"),
                },
            )
        if accepted.get("status") == "IN_PROGRESS":
            source_response.review_items.append({
                "category": "historical_business_review",
                "blocking": True,
                "safe_summary": "The source SQL came from an in-progress historical mapping. Its business rules need approval before completion.",
                "details": {"precedent_sttm_id": accepted.get("sttm_id")},
            })
        specialist_outputs = {
            "source_trace_ids": list(dict.fromkeys(value for value in [source_response.raw_trace_id, *source_response.raw_trace_ids] if value)),
            "transformation_trace_ids": list(dict.fromkeys(value for value in [transform_response.raw_trace_id, *transform_response.raw_trace_ids] if value)),
            "source_decisions": [decision.model_dump(mode="json") for decision in source_agent_decisions],
            "transformation_decisions": [decision.model_dump(mode="json") for decision in transform_response.decisions],
            "prefilled_decisions": [decision.model_dump(mode="json") for decision in prefilled],
            "target_table": target_table,
        }
        called_specialist = bool(source_agent_decisions or transform_response.decisions)
        self._emit("agent.completed" if called_specialist else "automap.prefill_completed", "succeeded",
                   "Generated specialist mapping options are available." if called_specialist else "Reused verified column decisions without another source-mapping call.",
                   trace_id=f"{trace_id}:specialists:{'finalize' if 'finalize_rows' in mapping else 'source'}", parent_trace_id=trace_id, kind="delegation",
                   label="Generated mappings", details=specialist_outputs)
        # The canonical workspace contract requires a stable row identity.
        # Specialist decisions are column keyed, so assign a deterministic
        # draft ID before persisting or handing rows to a later partition.
        rows = [
            {**row, "id": str(row.get("id") or f"migration:{mapping['sttm_id']}:{row['target_column']}")}
            for row in rows
        ]
        plan_payload = state.get("migration_plan") or {}
        # A multi-target plan carries evidence per mapping; applying the
        # top-level (first target's) evidence to every mapping would promote
        # another target's candidates for identically named columns.
        mapping_spec = next((
            spec for spec in plan_payload.get("mapping_specs") or []
            if isinstance(spec, dict) and spec.get("mapping_key") == mapping.get("mapping_key")
        ), None) or {}
        plan_mapping_evidence = list(
            (mapping_spec.get("auto_map") or plan_payload.get("auto_map") or {}).get("mapping_evidence") or []
        )
        attachment_facts = facts_for_target(state.get("attachment_readings") or [], target_table)
        # The user's own specs and notes count as evidence for each column,
        # next to precedents and learnings (see column_confidence).
        plan_mapping_evidence.extend(attachment_mapping_evidence(attachment_facts))
        firm_value_reviews = self._apply_firm_values(
            state, rows, firm_context, target_table=target_table,
            target_column_contracts=target_contract["column_contracts"],
        )
        self._promote_approved_value_bindings(
            rows,
            list(
                (mapping_spec.get("source_preparation") or plan_payload.get("source_preparation") or {})
                .get("value_bindings") or []
            ),
            target_contract["column_contracts"],
        )
        self._promote_verified_plan_candidates(
            rows, plan_mapping_evidence, source_contracts, target_contract["column_contracts"]
        )
        dependency_resolutions = self._resolve_target_dependencies(state, mapping, rows, source_tables)
        # Promotions and cross-target dependency resolution can both create or
        # rewrite value-bearing expressions. Sanitize only after both so no
        # later pre-save step can reintroduce an unheld project value.
        self._hold_back_unheld_firm_values(state, rows, firm_context.get("held") or {},
                                           firm_context.get("values") or [], firm_value_reviews)
        if mapping.get("defer_compile"):
            return {"mapping_rows": rows, "target_columns": target_columns, "partition_state": "COMPLETED",
                    "dependency_resolutions": dependency_resolutions,
                    "review_items": source_response.review_items + transform_response.review_items}
        sql_validation = self._validate_generated_sql(
            state=state,
            target_table=target_table,
            source_tables=source_tables,
            source_columns=source_columns,
            rows=rows,
            policy=policy,
            target_key_columns=target_contract["key_columns"],
        )
        workspace_design = sql_validation.pop("workspace_design", None)
        receipt = sql_validation.pop("validation_receipt", None)
        low_confidence = self._score_column_confidence(
            rows, plan_mapping_evidence, source_contracts, target_contract["column_contracts"])
        facts_by_evidence = {fact["evidence_id"]: fact for fact in attachment_facts}
        for row in rows:
            cited = [facts_by_evidence[value] for value in row.get("evidence_ids") or [] if value in facts_by_evidence]
            if cited:
                row["attachment_evidence"] = [
                    {"filename": fact["filename"], "section": fact["section"], "quote": str(fact.get("quote") or "")[:300],
                     "evidence_id": fact["evidence_id"]}
                    for fact in cited[:3]
                ]
        candidate_reviews = []
        for row in rows:
            provisional = "Provisional best candidate; business approval pending." in (row.get("assumptions") or [])
            if row.get("status") != "unresolved" and not provisional and row["target_column"] not in low_confidence:
                continue
            candidates = self._mapping_review_candidates(
                str(row["target_column"]), row, plan_mapping_evidence, source_contracts
            )
            best = candidates[0] if candidates else None
            best_label = (
                ", ".join(best.get("source_columns") or [])
                or str(best.get("transformation") or best.get("constant_value") or "")
            ) if best else ""
            summary = (
                f"{row['target_column']}: best candidate {best_label} "
                f"({float(best['confidence']):.0%} confidence). {best['reason']}"
                if best else f"{row['target_column']}: no verified candidate; supply a current source or transformation rule."
            )
            if row.get("status") == "draft" and row["target_column"] in low_confidence:
                mapped_from = ", ".join(row.get("source_columns") or []) or str(row.get("expression") or "a constant")
                summary = (f"{row['target_column']}: mapped from {mapped_from} at {float(row['confidence']):.0%} "
                           f"confidence ({'; '.join(low_confidence[row['target_column']])}). Confirm or choose another source.")
            if row.get("sql_rejection"):
                summary += f" Proposed expression `{row.get('rejected_expression')}` was held back: {row['sql_rejection']}"
            candidate_reviews.append({
                "category": "mapping_candidate_review",
                "blocking": row.get("status") == "unresolved",
                "safe_summary": summary,
                "details": {"target_column": row["target_column"], "candidates": candidates,
                            "confidence": row.get("confidence"),
                            "current_choice": (
                                str(row.get("expression") or "").strip()
                                or (f"${row['attribute_name']}" if row.get("attribute_name") else "")
                                or ", ".join(str(value) for value in row.get("source_columns") or [])
                                or None
                            ),
                            **({"rejected_expression": row.get("rejected_expression"),
                                "rejection_reason": row["sql_rejection"]} if row.get("sql_rejection") else {})},
            })
        candidate_reviews = self._batch_uncorroborated_reviews(candidate_reviews, rows, target_table)
        # A firm-value decision replaces the generic candidate question for its column.
        firm_targets = {str(item["details"]["target_column"]).upper() for item in firm_value_reviews}
        candidate_reviews = [
            item for item in candidate_reviews
            if str((item.get("details") or {}).get("target_column") or "").upper() not in firm_targets
        ] + firm_value_reviews
        # One decision per column where an attachment says something else.
        for conflict in attachment_conflicts(rows, attachment_facts):
            fact = conflict["fact"]
            candidate_reviews.append({
                "category": "attachment_conflict",
                "blocking": False,
                "safe_summary": (
                    f"{conflict['target_column']} ({target_table}): {fact['filename']} says it comes from "
                    f"{', '.join(conflict['stated'])} (\"{str(fact.get('quote') or '')[:160]}\"), but the mapping "
                    f"uses {', '.join(conflict['mapped'])}. Choose one."
                ),
                "details": {"target_table": target_table, "target_column": conflict["target_column"],
                            "mapped": conflict["mapped"], "stated": conflict["stated"],
                            "evidence_id": fact["evidence_id"], "quote": fact.get("quote")},
            })
        for resolution in dependency_resolutions:
            if resolution["status"] == "resolved":
                continue
            candidate_reviews.append({
                "category": "cross_target_dependency",
                "blocking": resolution["status"] != "load_time",
                "safe_summary": f"{resolution['target_column']} ({target_table}): {resolution['reason']}",
                "details": {**resolution, "target_table": target_table},
            })
        # A repair that changes what a column loads (unconvertible values to
        # NULL, truncation, a model-written rule) is kept but confirmed.
        for repair in sql_validation.get("sql_repairs") or []:
            if repair.get("method") != "model" and repair.get("root_cause") not in DATA_ERRORS:
                continue
            candidate_reviews.append({
                "category": "sql_repair_review",
                "blocking": False,
                "safe_summary": (
                    f"{repair['target_column']}: the SQL debugger changed the rule so it loads. "
                    f"{repair.get('explanation') or ''} Confirm `{repair.get('after')}`."
                ).strip(),
                "details": {**repair, "target_table": target_table},
            })
        for rule in sql_validation.get("population_rules") or []:
            candidate_reviews.append({
                "category": "population_rule_review",
                "blocking": False,
                "safe_summary": f"{target_table.split('.')[-1]}: {rule['reason']} Filter `{rule['predicate']}`.",
                "details": {**rule, "target_table": target_table, "kind": "population_rule"},
            })
        context_workspace = dict((state.get("mapping_context_package") or {}).get("workspace") or {})
        snapshot = self._draft_snapshot(
            state=state,
            mapping=mapping,
            target_table=target_table,
            source_tables=source_tables,
            source_columns=source_columns,
            rows=rows,
            context_workspace=context_workspace,
            design=workspace_design,
            sql_validation=sql_validation,
            receipt=receipt,
        )
        payload = {"workspace_snapshot": snapshot, "action": "migration_agent.draft_saved", "session_id": state["run_id"], "thread_id": state["run_id"], "agent_artifacts": [{"type": "specialist_decision", "source_summary": source_response.safe_summary, "transformation_summary": transform_response.safe_summary, **specialist_outputs}]}
        self._tool("sttm.autosave_draft")
        self._projects.ensure_storage_exists()
        # A follow-up that re-maps a column changes the parent's choice; keep
        # the parent rows to learn from the change once it validates.
        previous_rows: list[dict[str, Any]] = []
        if state.get("parent_run_id"):
            with self._domain_lock:
                previous = self._projects.get_sttm_detail(str(mapping["sttm_id"]))
            previous_rows = list((previous.latest_snapshot or {}).get("mapping_rows") or []) if previous else []
        try:
            with self._domain_lock:
                def current_revision() -> int | None:
                    record = self._projects.get_sttm_record(str(mapping["sttm_id"]))
                    return int(record.current_version or 0) if record else None

                record = self._projects.get_sttm_record(str(mapping["sttm_id"]))
                if record is None or not self._owns_draft(state, record):
                    raise PermissionError("Draft overwrite requires ownership by this run")
                expected_revision = current_revision()
                autosave_receipt = self._commands.execute(
                    self._command(state, "sttm.autosave_draft", f"target_table:{target_table}", payload, project_id=str(state["project_id"]), sttm_id=str(mapping["sttm_id"]), expected_revision=expected_revision),
                    lambda: self._projects.autosave_sttm(str(mapping["sttm_id"]), STTMAutosaveRequest.model_validate(payload), user_id=self._actor(state).user_id),
                    current_revision=current_revision,
                )
        except PermissionError:
            raise
        except Exception as exc:
            save_review = {
                "category": "draft_save_failed",
                "blocking": True,
                "safe_summary": f"{target_table.rsplit('.', 1)[-1]} draft could not be saved: {exc}",
                "details": {"target_table": target_table, "sttm_id": str(mapping["sttm_id"]),
                            "error_type": type(exc).__name__},
            }
            raise DraftAutosaveReviewError(
                str(exc),
                partial_result={
                    "mapping_key": mapping["mapping_key"], "mapping_name": mapping["mapping_name"],
                    "target_table": target_table, "sttm_id": mapping["sttm_id"], "status": "NEEDS_REVIEW",
                    "target_columns": target_columns, "mapping_rows": rows,
                    "mapped_target_columns": [row["target_column"] for row in rows if row["status"] == "draft"],
                    "unresolved_target_columns": [row["target_column"] for row in rows if row["status"] == "unresolved"],
                    "review_items": source_response.review_items + transform_response.review_items
                                    + candidate_reviews + [save_review],
                    "sql_validation": sql_validation, "save_failed": True,
                    "safe_summary": save_review["safe_summary"],
                },
            ) from exc
        unresolved = [row["target_column"] for row in rows if row["status"] == "unresolved"]
        mapped = [row["target_column"] for row in rows if row["status"] == "draft"]
        used_learning_ids = sorted({value for row in rows for value in row.get("used_learning_ids") or []})
        evidence_ids = sorted({value for row in rows for value in row.get("evidence_ids") or []})
        self._record_decision(state=state, mapping=mapping, retrieved=retrieved_learning_ids, used=used_learning_ids, evidence=evidence_ids, rows=rows)
        validation_failed = any(item.get("blocking", False) for item in source_response.review_items) or not sql_validation.get("compile_valid", False) or (
            policy.validation_depth != "compile" and not sql_validation.get("preview_valid", False)
        ) or bool(sql_validation.get("optimization_requires_approval"))
        self._record_learning_outcomes(state, mapping, rows, validated=not validation_failed)
        if previous_rows and not validation_failed:
            self._record_follow_up_corrections(state, mapping, previous_rows, rows)
        status = "NEEDS_REVIEW" if unresolved or validation_failed else "READY_FOR_REVIEW"
        self._emit(
            "automap.completed",
            "needs_review" if status == "NEEDS_REVIEW" else "succeeded",
            f"Auto Map saved {len(rows)} target-column decisions to the run-owned draft.",
            trace_id=trace_id,
            parent_trace_id="mapping-execution",
            kind="workflow",
            label="Auto Map",
            details={
                "mapped_count": len(mapped),
                "unresolved_count": len(unresolved),
                "compile_valid": bool(sql_validation.get("compile_valid")),
                "preview_valid": bool(sql_validation.get("preview_valid")),
            },
        )
        self._emit("trace.group.completed", "succeeded", f"Saved {len(rows)} draft rows; {len(unresolved)} need review.", trace_id=trace_id, parent_trace_id="mapping-execution", kind="mapping", label=mapping["mapping_name"], details={"mapped_count": len(mapped), "unresolved_count": len(unresolved), "sttm_id": mapping["sttm_id"]})
        contract_hash = hashlib.sha256(json.dumps(target_contract["column_contracts"], sort_keys=True).encode("utf-8")).hexdigest()
        relationship_metrics_by_edge = dict(
            (state.get("source_preparation_result") or {}).get("relationship_metrics") or {}
        )
        aggregate_relationship_metrics = {
            "fanout_ratio": max(
                [float(value.get("fanout_ratio") or 1.0) for value in relationship_metrics_by_edge.values()]
                or [1.0]
            ),
            "orphan_rate": max(
                [float(value.get("orphan_rate") or 0.0) for value in relationship_metrics_by_edge.values()]
                or [0.0]
            ),
            "coverage": min(
                [float(value.get("coverage") or 0.0) for value in relationship_metrics_by_edge.values()]
                or [1.0]
            ),
            "edges": relationship_metrics_by_edge,
        }
        mapping_review_items = [
            {
                **item,
                "mapping_key": mapping["mapping_key"],
                "mapping_name": mapping["mapping_name"],
                "target_table": target_table,
                "sttm_id": mapping["sttm_id"],
                "details": {
                    **dict(item.get("details") or {}),
                    "mapping_key": mapping["mapping_key"],
                    "target_table": target_table,
                    "sttm_id": mapping["sttm_id"],
                },
            }
            for item in source_response.review_items + transform_response.review_items + candidate_reviews
        ]
        return {"mapping_key": mapping["mapping_key"], "mapping_name": mapping["mapping_name"], "target_table": target_table, "dependency_resolutions": dependency_resolutions, "sttm_id": mapping["sttm_id"], "status": status, "safe_summary": f"Saved {len(rows)} draft mapping rows; {len(unresolved)} require review.", "review_items": mapping_review_items, "target_columns": target_columns, "target_column_contracts": target_contract["column_contracts"], "target_contract_hash": contract_hash, "target_key_columns": target_contract["key_columns"], "mapped_target_columns": mapped, "unresolved_target_columns": unresolved, "duplicate_target_columns": duplicate_targets, "mapping_rows": rows, "relationship_count": len((snapshot.get("relation_graph") or {}).get("edges") or snapshot["relationships"]), "scoped_sql_lineage_verified": bool(accepted and sql_validation.get("compile_valid") and sql_validation.get("preview_valid")), "relationship_metrics": aggregate_relationship_metrics, "source_table_count": len(source_tables), "retrieved_learning_ids": retrieved_learning_ids, "used_learning_ids": used_learning_ids, "evidence_ids": evidence_ids, "sql_validation": sql_validation, "reconciliation_metrics": sql_validation.get("reconciliation_metrics") or {}, "key_metrics": sql_validation.get("key_metrics") or {}, "contributing_agents": ["verified_historical_precedent"] if accepted else ["AGT_SOURCE_MAPPING", *(["AGT_TRANSFORMATION_RULE"] if complex_targets else [])], "context_hash": str((state.get("mapping_context_package") or {}).get("context_hash") or ""), "mutation_receipt": autosave_receipt.model_dump(mode="json")}

    def cross_validate(self, state: dict[str, Any]) -> dict[str, Any]:
        progress = getattr(self, "progress", None)
        if progress is not None:
            results = list(state.get("mapping_results") or [])
            ready = sum(1 for item in results if item.get("status") == "READY_FOR_REVIEW")
            try:
                progress.announce("cross_validation", ready_targets=ready, targets=len(results))
            except Exception:
                logger.debug("Progress fact was not recorded", exc_info=True)
        review_items = []
        for result in state.get("mapping_results") or []:
            review_items.extend(
                {
                    **item,
                    "mapping_key": item.get("mapping_key") or result.get("mapping_key"),
                    "mapping_name": item.get("mapping_name") or result.get("mapping_name"),
                    "target_table": item.get("target_table") or result.get("target_table"),
                    "sttm_id": item.get("sttm_id") or result.get("sttm_id"),
                }
                for item in result.get("review_items") or []
            )
        from app.agent_runs.policy import policy_from_state
        policy = policy_from_state(state)
        report = validate_mapping_set(
            list(state.get("manifest") or []),
            list(state.get("mapping_results") or []),
            policy.cross_mapping_checks,
        )
        if policy.validation_depth == "reconcile":
            test_results = []
            for mapping in state.get("mapping_results") or []:
                if not dict(mapping.get("sql_validation") or {}).get("preview_valid"):
                    continue
                key = str(mapping.get("mapping_key") or "")
                try:
                    outcome = self.run_mapping_contract_tests(
                        {**state, "workflow_result": state}, key,
                    )
                    test_results.append({
                        "mapping_key": key, "status": outcome.status,
                        "summary": outcome.summary, **dict(outcome.data or {}),
                    })
                    if outcome.status != "succeeded":
                        report["issues"].append({
                            "category": "mapping_tests", "blocking": True,
                            "safe_summary": outcome.summary,
                            "subject_keys": [key],
                            "details": {"test_receipts": list((outcome.data or {}).get("test_receipts") or [])},
                        })
                except Exception as exc:
                    logger.exception("Mapping contract tests failed for run %s", state.get("run_id"))
                    test_results.append({"mapping_key": key, "status": "failed", "error_type": type(exc).__name__})
                    report["issues"].append({
                        "category": "mapping_tests", "blocking": True,
                        "safe_summary": "Read-only mapping contract tests did not complete.",
                        "subject_keys": [key], "details": {"error_type": type(exc).__name__},
                    })
            report["mapping_tests"] = test_results
            report["gates"]["mapping_tests"] = {
                "passed": bool(test_results) and all(item["status"] == "succeeded" for item in test_results),
                "result_count": len(test_results),
            }
            report["passed"] = not any(item.get("blocking", True) for item in report["issues"])
        mapping_results_by_key = {
            str(result.get("mapping_key") or ""): result
            for result in state.get("mapping_results") or []
        }
        scoped_issues = []
        for item in report["issues"]:
            mapping_key = str(item.get("mapping_key") or next(
                iter(item.get("subject_keys") or []),
                "",
            ))
            result = mapping_results_by_key.get(mapping_key, {})
            scoped_issues.append({
                **item,
                "mapping_key": mapping_key or None,
                "mapping_name": result.get("mapping_name"),
                "target_table": result.get("target_table"),
                "sttm_id": result.get("sttm_id"),
            })
        report["issues"] = scoped_issues
        artifact_payload = {
            "run_id": state["run_id"],
            "manifest_version": int(state.get("manifest_version") or 0),
            "manifest": state.get("manifest") or [],
            "mapping_results": state.get("mapping_results") or [],
            "validation": report,
        }
        report["artifact_digest"] = hashlib.sha256(
            json.dumps(artifact_payload, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        report["artifact_revision"] = str(state.get("manifest_version") or 0)
        self._emit(
            "artifact.created",
            "succeeded" if report["passed"] else "needs_review",
            "Created an immutable validation artifact for the run-owned Workbench draft.",
            trace_id=f"artifact:{report['artifact_digest']}",
            parent_trace_id="validation",
            kind="artifact",
            label="Validation artifact",
            details={
                "artifact_hash": report["artifact_digest"],
                "artifact_revision": report["artifact_revision"],
            },
        )
        for index, finding in enumerate(report.get("issues") or []):
            self._emit(
                "validation.finding",
                "needs_review" if finding.get("blocking", True) else "succeeded",
                str(finding.get("safe_summary") or "Validation finding recorded."),
                trace_id=f"validation:finding:{index + 1}",
                parent_trace_id="validation",
                kind="validation",
                label=str(finding.get("category") or "Validation finding"),
                details=dict(finding.get("details") or {}),
            )
        self._record_validation_report(state, report)
        if self._learning is not None:
            used_ids = sorted({
                str(value)
                for result in state.get("mapping_results") or []
                for value in result.get("used_learning_ids") or []
            })
            self._learning.record_validation_outcome(
                used_ids,
                passed=bool(report["passed"]),
                evidence_id=f"validation:{state['run_id']}",
            )
        review_items.extend(scoped_issues)
        self._emit("trace.group.completed", "succeeded", "All ready mapping DAG nodes finished.", trace_id="mapping-execution", parent_trace_id=None, kind="group", label="Build draft mappings", details={"mapping_count": len(state.get("mapping_results") or [])})
        self._emit("trace.group.completed", "succeeded" if report["passed"] else "needs_review", "Validation produced deterministic gate results.", trace_id="validation", parent_trace_id=None, kind="group", label="Validate migration", details={"passed": report["passed"]})
        self._emit("trace.action.completed", "succeeded" if report["passed"] else "needs_review", "Cross-mapping validation gates completed.", trace_id="cross-validation", parent_trace_id="validation", kind="validation", label="Run validation gates", details={"gates": report["gates"], "passed": report["passed"]})
        model_used, tool_used = self.usage_snapshot()
        context_hash = str((state.get("mapping_context_package") or {}).get("context_hash") or "")
        receipts = [
            WorkbenchMutationReceipt(
                operation="automap.save_draft",
                project_id=str(state.get("project_id") or "") or None,
                sttm_id=str(result.get("sttm_id") or "") or None,
                snapshot_id=(f"draft:{result.get('sttm_id')}" if result.get("sttm_id") else None),
                prior_revision=(result.get("mutation_receipt") or {}).get("prior_revision"),
                new_revision=(result.get("mutation_receipt") or {}).get("new_revision"),
                context_hash=context_hash,
                artifact_hash=report["artifact_digest"],
                changed_entity_types=[
                    "source_preparation",
                    "mapping_rows",
                    "mapping_sql",
                    "validation",
                ],
                route=(f"/sttm/builder/{result.get('sttm_id')}" if result.get("sttm_id") else None),
            )
            for result in state.get("mapping_results") or []
        ]
        canonical_result = WorkbenchAgentResultV1(
            operation="source_preparation_and_automap",
            route=receipts[0].route if receipts else None,
            contributing_agents=sorted({
                agent
                for result in state.get("mapping_results") or []
                for agent in result.get("contributing_agents") or []
            }),
            domain_result={
                "mapping_results": state.get("mapping_results") or [],
                "source_preparation": state.get("source_preparation_result") or {},
                "validation": report,
            },
            artifacts=[{
                "artifact_type": "validation_report",
                "artifact_hash": report["artifact_digest"],
                "artifact_revision": report["artifact_revision"],
                "status": "validated" if report["passed"] else "needs_review",
            }],
            semantic_evidence=(
                [EvidenceReference(
                    evidence_id=str(
                        (state.get("mapping_context_package") or {})
                        .get("stored_semantic_context", {})
                        .get("bundle_hash")
                        or (state.get("mapping_context_package") or {})
                        .get("stored_semantic_context", {})
                        .get("bundle_id")
                    ),
                    kind="stored_semantic_context",
                    provenance="SemanticContextService:stored_registry",
                    validated=True,
                    used=True,
                )]
                if (
                    (state.get("mapping_context_package") or {})
                    .get("stored_semantic_context", {})
                    .get("status") in {"available", "partial"}
                    and (
                        (state.get("mapping_context_package") or {})
                        .get("stored_semantic_context", {})
                        .get("bundle_hash")
                        or (state.get("mapping_context_package") or {})
                        .get("stored_semantic_context", {})
                        .get("bundle_id")
                    )
                )
                else []
            ),
            fir_evidence=[
                EvidenceReference(
                    evidence_id=learning_id,
                    kind="fir_learning",
                    provenance="AGT_FIR_SYSTEM",
                    validated=True,
                    used=True,
                )
                for learning_id in sorted({
                    str(value)
                    for result in state.get("mapping_results") or []
                    for value in result.get("used_learning_ids") or []
                })
            ],
            validation_findings=[
                value if isinstance(value, dict) else {"message": str(value)}
                for value in report.get("issues") or []
            ],
            mutation_receipts=receipts,
            user_summary=(
                "The approved run-owned draft passed the configured validation gates."
                if report["passed"]
                else "The run-owned draft was saved with validation findings that require review."
            ),
            recommended_next_actions=(
                ["Open the generated mapping in the existing Workbench UI."]
                if report["passed"]
                else ["Review unresolved target columns and validation findings before approval."]
            ),
            metrics={
                "mapping_count": len(state.get("mapping_results") or []),
                "model_calls_used": model_used,
                "tool_calls_used": tool_used,
            },
        )
        return {
            "validation_artifact_refs": [f"validation:{state['run_id']}", *[f"sttm:{item.get('sttm_id')}" for item in state.get("manifest") or [] if item.get("sttm_id")]],
            "review_items": review_items,
            "validation_report": report,
            "workbench_result": canonical_result.model_dump(mode="json"),
            "model_calls_used": model_used,
            "tool_calls_used": tool_used,
        }
