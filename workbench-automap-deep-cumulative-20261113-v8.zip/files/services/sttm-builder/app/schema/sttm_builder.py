from copy import deepcopy
from enum import Enum
import math
from typing import Any, Literal

from pydantic import BaseModel, Field, PrivateAttr, field_validator, model_serializer, model_validator

from app.schema.common import AttributeRef, TableRef
from app.schema.contracts import CONTRACT_VERSION, ApiActor, ApiError, ApiWarning, OperationContext
from app.schema.semantic_context import SemanticLevel, SemanticRefreshStatus, SemanticSurface
from app.schema.workspace_context import WorkbenchContextSnapshotV1


class AutoMapContextBudget(BaseModel):
    policy_version: str = "final-message-v1"
    exhaustive: bool = False
    final_chars: int = Field(default=0, ge=0)
    final_bytes: int = Field(default=0, ge=0)
    max_chars: int = Field(gt=0)
    max_bytes: int = Field(gt=0)
    included_evidence_ids: list[str] = Field(default_factory=list)
    deferred_group_ids: list[str] = Field(default_factory=list)
    budget_deferred_targets: list[str] = Field(default_factory=list)


class Interface(str, Enum):
    AUTO_MAP = "AUTO_MAP"
    CHAT = "CHAT"
    TRANSFORM = "TRANSFORM"


class SubAgent(str, Enum):
    SOURCE_MAPPING_AGENT = "SOURCE_MAPPING_AGENT"
    TRANSFORMATION_AGENT = "TRANSFORMATION_AGENT"


class STTMOperation(str, Enum):
    AUTO_MAP = "sttm.auto_map"
    CHAT = "sttm.chat"
    TRANSFORM = "sttm.transform"
    DERIVED_SQL_GENERATE = "sttm.derived_sql.generate"


class STTMStatus(str, Enum):
    COMPLETED = "completed"
    NEEDS_INPUT = "needs_input"
    FAILED = "failed"


_INTERFACE_TO_OPERATION = {
    Interface.AUTO_MAP: STTMOperation.AUTO_MAP,
    Interface.CHAT: STTMOperation.CHAT,
    Interface.TRANSFORM: STTMOperation.TRANSFORM,
}


_PRECEDENT_DECISIONS = {"followed", "adapted", "rejected", "accept_precedent", "override_precedent", "unresolved"}
_PATTERN_DECISIONS = {"accept_exact_precedent", "adapt_pattern", "override_pattern", "unresolved"}


def normalize_precedent_decision(value: Any) -> Any:
    """Map agent synonyms onto the precedent contract instead of failing the batch.

    Agents sometimes put pattern vocabulary (adapt_pattern) or "no_precedent" into
    precedent_decision. Adapting is not accepting a linked precedent, so anything
    outside the contract becomes "unresolved"; the precedent validator then keeps
    the inferred mapping for review.
    """
    if value is None:
        return None
    token = str(value).strip().lower()
    if token in _PRECEDENT_DECISIONS:
        return token
    return {
        "accept_exact_precedent": "accept_precedent",
        "accepted_precedent": "accept_precedent",
        "override_pattern": "override_precedent",
        "overridden_precedent": "override_precedent",
    }.get(token, "unresolved")


def normalize_pattern_decision(value: Any) -> Any:
    if value is None:
        return None
    token = str(value).strip().lower()
    if token in _PATTERN_DECISIONS:
        return token
    return {
        "accept_precedent": "accept_exact_precedent",
        "accept_pattern": "accept_exact_precedent",
        "adapt_precedent": "adapt_pattern",
        "override_precedent": "override_pattern",
    }.get(token, "unresolved")


class TargetAttributeItem(BaseModel):
    """One target attribute with its optional current source mapping."""

    selected_mapping: dict[str, Any] | None = None

    target_table: TableRef = Field(description="Target table this attribute belongs to.")
    target_attribute: str = Field(description="Target column name.")
    target_data_type: str | None = Field(
        default=None,
        description="Target column data type when the UI already knows it.",
    )
    target_description: str | None = Field(
        default=None,
        description=(
            "Optional business description or user-edited mapping guidance for the target "
            "attribute. Use this as additional context before probing metadata tools."
        ),
    )
    source_mappings: list[AttributeRef] | None = Field(
        default=None,
        description=(
            "Source attributes already mapped to this target attribute. "
            "Omit or set to null if not yet mapped."
        ),
    )


class RelationshipConditionItem(BaseModel):
    left_column: str = Field(description="Column from the left/source table.")
    right_column: str = Field(description="Column from the right/referenced table.")
    operator: str = Field(default="=", description="Join operator.")
    connector: Literal["AND", "OR"] | None = Field(
        default=None,
        description="How this condition attaches to the previous one. Ignored on the first condition.",
    )

    @model_serializer(mode="wrap")
    def _omit_empty_connector(self, serializer, _info):
        payload = serializer(self)
        if isinstance(payload, dict) and payload.get("connector") is None:
            payload.pop("connector", None)
        return payload


class RelationshipLiteralFilter(BaseModel):
    """A constant predicate applied inside a join, e.g. a polymorphic type discriminator."""

    side: Literal["left", "right"] = Field(description="Which relationship table the column belongs to.")
    column: str = Field(pattern=r"^[A-Za-z_][A-Za-z0-9_$]*$", description="Column compared to the literal.")
    operator: Literal["="] = "="
    value: str = Field(max_length=512, description="Literal value; always rendered as a quoted SQL string.")


class RelationshipContextItem(BaseModel):
    sql_predicate: str | None = None
    left_table: TableRef = Field(description="Source/left side table in the relationship.")
    right_table: TableRef = Field(description="Referenced/right side table in the relationship.")
    constraint_name: str | None = Field(
        default=None,
        description="Optional Snowflake foreign-key constraint name.",
    )
    join_type: str = Field(default="INNER", description="Join type currently applied in the UI.")
    conditions: list[RelationshipConditionItem] = Field(
        default_factory=list,
        description="Join conditions between the two tables.",
    )
    normalized_lookup_alternative: str | None = Field(
        default=None, description="Optional right-side code alias matched after trim/uppercase normalization.",
    )
    literal_filters: list[RelationshipLiteralFilter] = Field(
        default_factory=list, description="Constant predicates applied inside the join (for example NOTEABLE_TYPE = 'Crm::Contact').",
    )
    source: str | None = Field(
        default=None,
        description="Origin of the relationship, e.g. FOREIGN_KEY or USER_DEFINED.",
    )
    locked: bool = Field(
        default=False,
        description="Whether the relationship is currently locked/autogenerated in the UI.",
    )


class RelationNodeKind(str, Enum):
    PHYSICAL_TABLE = "PHYSICAL_TABLE"
    DERIVED_SOURCE = "DERIVED_SOURCE"
    CTE = "CTE"


class RelationNode(BaseModel):
    """One joinable relation in the source-query graph."""

    relation_id: str
    kind: RelationNodeKind
    alias: str
    table: TableRef | None = None
    derived_source_id: str | None = None
    physical_view_name: str | None = None
    sql_text: str | None = None
    original_cte_name: str | None = None
    definition_sql: str | None = None
    query_scope: dict[str, Any] | None = None
    output_columns: list[dict[str, Any]] = Field(default_factory=list)
    column_semantics: list[dict[str, Any]] = Field(default_factory=list)
    grain: str | None = None
    keys: list[str] = Field(default_factory=list)
    dependency_hash: str | None = None
    parent_relation_ids: list[str] = Field(default_factory=list)
    base_relation_ids: list[str] = Field(default_factory=list)


class RelationEdge(BaseModel):
    """A compiler-owned join between two relation nodes."""

    edge_id: str
    left_relation_id: str
    right_relation_id: str
    join_type: str = "INNER"
    conditions: list[RelationshipConditionItem] = Field(default_factory=list)
    additional_predicate: str | None = None
    normalized_lookup_alternative: str | None = None
    literal_filters: list[RelationshipLiteralFilter] = Field(default_factory=list)
    provenance: str | None = None
    validation_status: str | None = None


class ValueBinding(BaseModel):
    binding_id: str
    value: str
    resolved_value: str | None = None
    data_type: str | None = None
    attribute_name: str | None = None
    is_placeholder: bool = False
    allow_project_specific_value: bool = False
    resolution_status: str = "resolved"
    provenance: str | None = None
    evidence_ids: list[str] = Field(default_factory=list)


class RelationGraphContext(BaseModel):
    query_modifiers: dict[str, str] = Field(default_factory=dict)
    nodes: list[RelationNode] = Field(default_factory=list)
    edges: list[RelationEdge] = Field(default_factory=list)
    value_bindings: list[ValueBinding] = Field(default_factory=list)


class SemanticContextItem(BaseModel):
    table: TableRef = Field(description="Table the semantic model belongs to.")
    semantic_model: dict | list | str = Field(
        description="Stored semantic model payload returned from Snowflake."
    )
    scope: str = Field(default="TABLE", description="Scope of the semantic model payload.")


class STTMArtifactType(str, Enum):
    NONE = "none"
    SEMANTIC_CONTEXT = "semantic_context"
    ANALYST_ANSWER = "analyst_answer"
    DERIVED_SOURCE_DRAFT = "derived_source_draft"
    SOURCE_MAPPING = "source_mapping"
    TRANSFORMATION_RULES = "transformation_rules"


class STTMBuilderRequest(BaseModel):
    interface: Interface = Field(
        description=(
            "AUTO_MAP — button-triggered mapping request. "
            "CHAT — free-text message; orchestration agent decides which sub-agent to call. "
            "TRANSFORM — transformation rule generation."
        )
    )
    thread_id: str | None = Field(
        default=None,
        description="Cortex Agent thread ID. Omit to start a new session; supply to continue one.",
    )
    parent_message_id: int | None = Field(
        default=None,
        description="Assistant message ID to continue within an existing Cortex Agent thread.",
    )

    # Structured input — required for AUTO_MAP and TRANSFORM
    attributes: list[TargetAttributeItem] | None = Field(
        default=None,
        min_length=1,
        description=(
            "Target attributes to map or transform. Each item specifies the target table, "
            "target attribute, and optionally its current source mapping. "
            "Required for AUTO_MAP and TRANSFORM."
        ),
    )
    source_tables: list[TableRef] | None = Field(
        default=None,
        min_length=1,
        description=(
            "Pool of source tables available for mapping. "
            "Pass even when source mappings are already set. "
            "Required for AUTO_MAP and TRANSFORM."
        ),
    )

    # User message — required for CHAT, optional refinement context for AUTO_MAP / TRANSFORM
    message: str | None = Field(
        default=None,
        description=(
            "User's message or refinement feedback. "
            "Required for CHAT. "
            "Optional for AUTO_MAP / TRANSFORM to add context to the mapping request."
        ),
    )
    driving_table: TableRef | None = Field(
        default=None,
        description="Driving/source table currently emphasized in the STTM builder canvas.",
    )
    relationships: list[RelationshipContextItem] | None = Field(
        default=None,
        description="Current relationship graph between the selected source tables.",
    )
    semantic_context: list[SemanticContextItem] | None = Field(
        default=None,
        description="Semantic-model context already available for the selected tables.",
    )
    selected_columns_by_table: dict[str, list[str]] | None = Field(
        default=None,
        description="Optional selected column names grouped by fully-qualified table name.",
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_empty_context_lists(cls, data: Any) -> Any:
        if isinstance(data, dict) and data.get("source_tables") == []:
            return {**data, "source_tables": None}
        return data

    @model_validator(mode="after")
    def _validate_by_interface(self) -> "STTMBuilderRequest":
        if self.interface in (Interface.AUTO_MAP, Interface.TRANSFORM):
            missing = [
                name
                for name, val in [("attributes", self.attributes), ("source_tables", self.source_tables)]
                if not val
            ]
            if missing:
                raise ValueError(f"{self.interface} requires: {', '.join(missing)}")
        elif self.interface == Interface.CHAT:
            if not self.message:
                raise ValueError("CHAT interface requires a non-empty `message`")
        return self


class FIRLearningItem(BaseModel):
    """A learned pattern from FIR system."""
    learning_id: str = Field(description="Unique identifier for traceability")
    learning_type: str = Field(
        description="Source of learning: mapping_acceptance, mapping_edit, published_sttm, historical_sql"
    )
    pattern_key: str = Field(description="Hash of source+target pattern for matching")
    summary: str = Field(description="Human-readable description of the learning")
    confidence: float = Field(description="How reliable this learning is (0.0-1.0)")
    source: str = Field(description="Origin: feedback, published_sttm, historical_import, correction")
    business_rationale: str | None = Field(default=None, description="Why this mapping makes business sense")
    domain_pattern: str | None = Field(default=None, description="Reusable pattern name")
    reusability: str | None = Field(
        default=None,
        description="highly_reusable, table_specific, or column_specific"
    )
    created_at: str | None = Field(default=None, description="When this learning was created")


class SimilarMappingItem(BaseModel):
    """A similar mapping from this or other projects."""
    mapping_id: str
    project_id: str
    project_name: str
    sttm_id: str
    sttm_name: str
    target_column: str
    source_columns: list[str]
    mapping_mode: Literal["source", "constant", "attribute"] = "source"
    constant_value: str | None = None
    attribute_name: str | None = None
    preprocessing_rule: str | None = None
    preprocessing_rule_type: str | None = None
    confidence_score: float
    was_published: bool = False
    similarity_score: float = Field(description="How similar to current context")


class MappingPrecedentContext(BaseModel):
    """Complete, attributable precedent supplied to mapping agents."""

    precedent_sttm_id: str
    precedent_project_id: str | None = None
    compatibility: str | None = None
    confidence: float = 1.0
    priority: int = 0
    knowledge_categories: list[str] = Field(default_factory=list)
    allow_project_specific_values: bool = False
    mappings: list[dict[str, Any]] = Field(default_factory=list)
    relationships: list[dict[str, Any]] = Field(default_factory=list)
    filters: list[dict[str, Any]] = Field(default_factory=list)
    ctes: list[dict[str, Any]] = Field(default_factory=list)
    derived_sources: list[dict[str, Any]] = Field(default_factory=list)
    business_rules: list[dict[str, Any]] = Field(default_factory=list)
    alias_contract: dict[str, str] = Field(default_factory=dict)
    raw_sql_hash: str | None = None
    snapshot_id: str | None = None


class SemanticLearningItem(BaseModel):
    """Curated knowledge about column meanings and disambiguations."""
    learning_id: str
    learning_type: str = Field(description="column_disambiguation, transformation_pattern, domain_vocabulary")
    summary: str
    confidence: float
    applies_to: list[str] = Field(description="Column names this applies to")
    correct_interpretation: str | None = None
    incorrect_interpretation: str | None = None


class MappingIntentItem(BaseModel):
    """Business goal for this mapping session."""
    intent_id: str
    business_goal: str
    target_outcome: str
    lifecycle: str = Field(description="initial, migration, consolidation, enhancement")
    domain_hints: list[str] = Field(default_factory=list)
    captured_from: str = Field(description="user_response, inferred, previous_sttm")
    confidence: float


class ProjectContextItem(BaseModel):
    """Information about the current project and mapping."""
    project_id: str
    project_name: str
    project_description: str | None = None
    sttm_id: str | None = None
    sttm_name: str | None = None
    sttm_description: str | None = None
    sttm_status: str | None = None
    domain: str | None = None
    # Captured on New Project; tells the agents what the migration is for.
    intended_outcome: str | None = None
    business_process: str | None = None
    source_system_key: str | None = None
    sttm_count: int = 0
    published_count: int = 0
    common_patterns: list[dict[str, Any]] = Field(default_factory=list)
    common_source_tables: list[str] = Field(default_factory=list)
    related_sttms: list[dict[str, Any]] = Field(default_factory=list)


class CrossProjectPatternItem(BaseModel):
    """Reusable patterns from other projects."""
    pattern_id: str
    pattern_type: str = Field(description="mapping_pattern or transformation_pattern")
    description: str
    example_mapping: dict[str, Any] = Field(default_factory=dict)
    source_projects: list[str] = Field(default_factory=list)
    usage_count: int = 0
    avg_confidence: float = 0.0
    is_recommended: bool = False


class CorrectionHistoryItem(BaseModel):
    """History of corrections to avoid repeating mistakes."""
    correction_id: str
    target_column: str
    incorrect_source: list[str] = Field(description="What the AI originally suggested (WRONG)")
    correct_source: list[str] = Field(description="What the user changed it to (CORRECT)")
    error_category: str = Field(
        description="naming_confusion, semantic_mismatch, data_type_issue, etc."
    )
    prevention_hint: str = Field(description="How to avoid this mistake")
    correction_count: int = Field(description="How many times this correction was made")
    incorrect_decision: dict[str, Any] | None = None
    correct_decision: dict[str, Any] | None = None
    scope_hash: str | None = None


class LearningContext(BaseModel):
    """Comprehensive learning context passed to agents."""
    automap_policy_version: str | None = None
    mandatory_negative_evidence: list[dict[str, Any]] = Field(default_factory=list)
    search_evidence: list[dict[str, Any]] = Field(default_factory=list)
    source_candidates: dict[str, list[str]] = Field(default_factory=dict)
    search_diagnostics: dict[str, Any] = Field(default_factory=dict)
    fir_learnings: list[FIRLearningItem] = Field(default_factory=list)
    source_agent_learnings: list[dict[str, Any]] = Field(default_factory=list)
    transformation_patterns: list[dict[str, Any]] = Field(default_factory=list)
    similar_mappings: list[SimilarMappingItem] = Field(default_factory=list)
    semantic_learnings: list[SemanticLearningItem] = Field(default_factory=list)
    mapping_intent: MappingIntentItem | None = None
    project_context: ProjectContextItem | None = None
    cross_project_patterns: list[CrossProjectPatternItem] = Field(default_factory=list)
    correction_history: list[CorrectionHistoryItem] = Field(default_factory=list)
    semantic_version_learnings: list[dict] = Field(default_factory=list, description="Curated semantic view version data with business_glossary, relationship_rules, transformation_patterns, column_semantics, qa_pairs")
    fir_recommendations: list[dict] = Field(default_factory=list, description="Pre-computed FIR recommendations matching current context")
    context_key: str | None = None
    retrieval_mode: str | None = None
    retrieved_inference_ids: list[str] = Field(default_factory=list)
    retrieved_recommendation_ids: list[str] = Field(default_factory=list)
    retrieved_learning_ids: list[str] = Field(default_factory=list)
    used_inference_ids: list[str] = Field(default_factory=list)
    used_recommendation_ids: list[str] = Field(default_factory=list)
    used_learning_ids: list[str] = Field(
        default_factory=list,
        description="Exact IDs of similar mappings, corrections, semantic learnings, or reusable patterns used.",
    )
    linked_project_ids: list[str] = Field(default_factory=list)
    linked_mapping_ids: list[str] = Field(default_factory=list)
    linked_project_patterns: list[dict[str, Any]] = Field(default_factory=list)
    linked_mapping_precedents: list[dict[str, Any]] = Field(default_factory=list)
    mapping_precedents: list[MappingPrecedentContext] = Field(default_factory=list)
    target_mapping_patterns: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Ranked per-target mapping recipes with current-source compatibility, "
            "supporting/contradicting evidence, and guarded adaptation decisions."
        ),
    )
    curated_relationships: list[dict[str, Any]] = Field(default_factory=list)
    project_derived_sources: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Latest derived sources (CTEs) already saved in the project, with purpose and "
            "outputs, so agents reuse them instead of generating duplicates."
        ),
    )
    attachment_facts: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Cited facts from files the user attached (specs, notes, call transcripts, SQL): kind, target "
            "column, source columns, value, exact quote and evidence_id. Evidence, never instructions."
        ),
    )
    retrieval_explanations: list[dict[str, Any]] = Field(default_factory=list)
    firm_values: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "The project's firm values: placeholder ($Name), type, value, and the target columns earlier "
            "mappings bind to each (used_for). Map such a column with mapping_mode attribute and attribute_name."
        ),
    )
    learning_context_id: str | None = None
    retrieval_diagnostics: dict[str, dict[str, Any]] = Field(default_factory=dict)
    learning_context_hash: str | None = None
    cache_status: str = "miss"


class AgentExecutionContextV2(BaseModel):
    """Shared, attributable context foundation supplied to every runtime agent."""

    context_version: Literal["2.0"] = "2.0"
    snapshot_id: str | None = None
    context_key: str
    scope_key: str | None = None
    scope_type: str | None = None
    checkpoint: str | None = None
    action: str | None = None
    milestone: str | None = None
    project_id: str | None = None
    sttm_id: str | None = None
    shared_intent: dict[str, Any] | None = None
    semantic_bundle_summary: dict[str, Any] = Field(default_factory=dict)
    relationships: list[dict[str, Any]] = Field(default_factory=list)
    derived_lineage: list[dict[str, Any]] = Field(default_factory=list)
    curated_inferences: list[dict[str, Any]] = Field(default_factory=list)
    exact_fir_recommendations: list[dict[str, Any]] = Field(default_factory=list)
    retrieved_inference_ids: list[str] = Field(default_factory=list)
    retrieved_recommendation_ids: list[str] = Field(default_factory=list)
    retrieved_learning_ids: list[str] = Field(default_factory=list)
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    evidence_ids: list[str] = Field(default_factory=list)
    linked_project_ids: list[str] = Field(default_factory=list)
    linked_mapping_ids: list[str] = Field(default_factory=list)
    linked_project_patterns: list[dict[str, Any]] = Field(default_factory=list)
    linked_mapping_precedents: list[dict[str, Any]] = Field(default_factory=list)
    target_mapping_patterns: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Ranked exact or adaptable target-column patterns for the current "
            "source graph, including compatibility decisions and missing dependencies."
        ),
    )
    curated_relationships: list[dict[str, Any]] = Field(default_factory=list)
    retrieval_explanations: list[dict[str, Any]] = Field(default_factory=list)
    used_inference_ids: list[str] = Field(default_factory=list)
    used_recommendation_ids: list[str] = Field(default_factory=list)


class TransformationPatternItem(BaseModel):
    """Learned transformation pattern from past rule generations."""
    learning_id: str
    learning_type: str = Field(description="rule_acceptance, rule_edit, published_sttm")
    rule_type: str = Field(description="CAST, COALESCE, Custom, etc.")
    rule_expression: str
    sql_template: str | None = None
    description: str
    source_columns: list[str] = Field(default_factory=list)
    target_column: str
    confidence: float
    usage_count: int = 0
    success_rate: float | None = None


class SimilarTransformationItem(BaseModel):
    """Similar transformation from this or other projects."""
    transformation_id: str
    project_name: str
    sttm_name: str
    target_column: str
    rule_type: str
    rule_expression: str
    was_published: bool = False
    similarity_score: float


class TransformationCorrectionItem(BaseModel):
    """Past transformation corrections to avoid."""
    correction_id: str
    target_column: str
    incorrect_rule: str
    correct_rule: str
    error_category: str
    prevention_hint: str


class DomainVocabularyItem(BaseModel):
    """Domain-specific term definitions."""
    term: str
    definition: str
    sql_equivalent: str | None = None
    applies_to: list[str] = Field(default_factory=list)


class TransformationLearningContext(BaseModel):
    """Learning context for AGT_TRANSFORMATION_RULE."""
    transformation_patterns: list[TransformationPatternItem] = Field(default_factory=list)
    similar_transformations: list[SimilarTransformationItem] = Field(default_factory=list)
    correction_history: list[TransformationCorrectionItem] = Field(default_factory=list)
    domain_vocabulary: list[DomainVocabularyItem] = Field(default_factory=list)


class DBTPatternItem(BaseModel):
    """Learned dbt model pattern."""
    learning_id: str
    pattern_type: str = Field(description="materialization, cte_structure, layer_organization")
    source_type: str | None = None
    domain: str | None = None
    transformation_complexity: str | None = None
    model_template: str | None = None
    confidence: float
    usage_count: int = 0


class MacroUsagePatternItem(BaseModel):
    """Common macro combinations."""
    macro_name: str
    usage_context: str
    success_rate: float
    common_combinations: list[str] = Field(default_factory=list)


class MaterializationPatternItem(BaseModel):
    """Learned materialization choices."""
    materialization: str
    conditions: list[str] = Field(default_factory=list)
    refresh_frequency: str | None = None
    confidence: float


class LayerPatternItem(BaseModel):
    """Layer organization patterns."""
    layer: str = Field(description="staging, intermediate, marts")
    directory_structure: str
    naming_convention: str
    documentation_pattern: str | None = None


class DBTLearningContext(BaseModel):
    """Learning context for AGT_DBT_CONVERSION."""
    dbt_patterns: list[DBTPatternItem] = Field(default_factory=list)
    macro_usage_patterns: list[MacroUsagePatternItem] = Field(default_factory=list)
    materialization_patterns: list[MaterializationPatternItem] = Field(default_factory=list)
    layer_patterns: list[LayerPatternItem] = Field(default_factory=list)


class TestPatternItem(BaseModel):
    """Learned test case pattern."""
    learning_id: str
    rule_type: str
    target_column_pattern: str | None = None
    test_structure: str
    common_assertions: list[str] = Field(default_factory=list)
    success_rate: float


class EdgeCasePatternItem(BaseModel):
    """Domain-specific edge cases."""
    domain_name: str | None = None
    column_type: str | None = None
    edge_cases: list[str] = Field(default_factory=list)
    frequency_weight: float = 1.0


class ReconciliationPatternItem(BaseModel):
    """Reconciliation query patterns."""
    materialization: str | None = None
    reconciliation_type: str = Field(description="row_count, aggregate, key_based, value_by_value")
    query_template: str | None = None
    tolerance_thresholds: dict[str, float] = Field(default_factory=dict)


class TestLearningContext(BaseModel):
    """Learning context for AGT_TEST_CASE_GENERATION."""
    test_patterns: list[TestPatternItem] = Field(default_factory=list)
    edge_case_patterns: list[EdgeCasePatternItem] = Field(default_factory=list)
    reconciliation_patterns: list[ReconciliationPatternItem] = Field(default_factory=list)


class STTMBuilderContext(OperationContext):
    _prepared_automap: Any = PrivateAttr(default=None)
    _automap_finalization: str | None = PrivateAttr(default=None)
    source_tables: list[TableRef] | None = Field(default=None, min_length=1)
    driving_table: TableRef | None = None
    relationships: list[RelationshipContextItem] | None = None
    semantic_context: list[SemanticContextItem] | None = None
    selected_columns_by_table: dict[str, list[str]] | None = None
    surface: SemanticSurface = SemanticSurface.SOURCE_SELECTION
    semantic_level_requested: SemanticLevel = SemanticLevel.FULL_REGISTRY
    target_table: TableRef | None = None
    selected_derived_sources: list[str] | None = None
    semantic_bundle_id: str | None = None
    semantic_bundle_label: str | None = None
    semantic_view_name: str | None = None
    derived_source_lineage: list[dict[str, Any]] | None = None
    datahub_context: dict[str, Any] | None = None
    mapping_intent: dict[str, Any] | None = None
    workspace_context: WorkbenchContextSnapshotV1 | None = None
    execution_context: AgentExecutionContextV2 | None = None
    routing_hint: str | None = None
    project_id: str | None = Field(
        default=None,
        description="Project ID for FIR learning context retrieval."
    )
    sttm_id: str | None = Field(
        default=None,
        description="Current STTM ID for context retrieval."
    )
    learning_context: LearningContext | None = Field(
        default=None,
        description="Comprehensive learning context including FIR learnings, similar mappings, and correction history."
    )
    relation_graph: RelationGraphContext | None = None
    workspace_context_id: str | None = None
    workspace_context_hash: str | None = None
    semantic_bundle_hash: str | None = None
    learning_context_id: str | None = None
    learning_context_hash: str | None = None
    artifact_refs: list[dict[str, Any]] = Field(default_factory=list)
    prepared_context_hash: str | None = None
    omit_linked_precedent: bool = Field(
        default=False,
        description=(
            "Run a non-publishing shadow inference without linked mapping precedent. "
            "Semantic and FIR context remain available for controlled comparison."
        ),
    )
    replay_exact_precedent: bool = Field(
        default=False,
        description=(
            "Diagnostic-only deterministic replay of a fully compatible completed "
            "mapping. Normal Auto-map requests leave this false so AGT_SOURCE_MAPPING "
            "receives precedent as evidence and evaluates it against the current graph."
        ),
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_empty_source_tables(cls, data: Any) -> Any:
        if isinstance(data, dict):
            normalized = dict(data)
            normalized["semantic_level_requested"] = SemanticLevel.FULL_REGISTRY
            workspace = normalized.get("workspace_context")
            if isinstance(workspace, dict):
                normalized.setdefault("source_tables", workspace.get("source_tables") or None)
                normalized.setdefault("driving_table", workspace.get("driving_table"))
                normalized.setdefault("target_table", workspace.get("target_table"))
                normalized.setdefault("relationships", workspace.get("relationships") or None)
                normalized.setdefault("relation_graph", workspace.get("relation_graph"))
                normalized.setdefault("selected_columns_by_table", workspace.get("selected_columns_by_table") or None)
                # Clients send an explicit null when they have no intent;
                # setdefault would keep it and lose the workspace intent.
                if not normalized.get("mapping_intent"):
                    normalized["mapping_intent"] = workspace.get("mapping_intent")
                semantic = workspace.get("semantic")
                if isinstance(semantic, dict):
                    normalized.setdefault("semantic_bundle_id", semantic.get("bundle_id"))
                    normalized.setdefault("semantic_bundle_label", semantic.get("bundle_label"))
                    normalized.setdefault("semantic_view_name", semantic.get("view_name"))
                derived = workspace.get("derived_sources")
                if isinstance(derived, list):
                    normalized.setdefault("selected_derived_sources", [item.get("id") for item in derived if isinstance(item, dict) and item.get("id")] or None)
            if normalized.get("source_tables") == []:
                normalized["source_tables"] = None
            graph = normalized.get("relation_graph")
            relationships = normalized.get("relationships")
            graph_edges = graph.get("edges") if isinstance(graph, dict) else None
            if isinstance(relationships, list) and isinstance(graph_edges, list) and graph_edges:
                # Older UI builds copied derived-source graph edges into the
                # physical TableRef compatibility field, yielding payloads such
                # as {"database": "derived_..."} without schema/table. The
                # complete edge is already retained in relation_graph.
                def complete_table_ref(value: Any) -> bool:
                    return isinstance(value, dict) and all(
                        isinstance(value.get(part), str) and value.get(part)
                        for part in ("database", "schema", "table")
                    )

                normalized["relationships"] = [
                    relationship
                    for relationship in relationships
                    if isinstance(relationship, dict)
                    and complete_table_ref(relationship.get("left_table"))
                    and complete_table_ref(relationship.get("right_table"))
                ] or None
            return normalized
        return data


class STTMBuilderRequestData(BaseModel):
    intent: Interface
    intent_route: str | None = None
    attributes: list[TargetAttributeItem] | None = Field(default=None, min_length=1)
    message: str | None = None


class STTMAgentContext(BaseModel):
    source_tables: list[TableRef] | None = Field(default=None, min_length=1)
    driving_table: TableRef | None = None
    relationships: list[RelationshipContextItem] | None = None
    semantic_context: list[SemanticContextItem] | None = None
    selected_columns_by_table: dict[str, list[str]] | None = None
    surface: SemanticSurface = SemanticSurface.SOURCE_SELECTION
    semantic_level_requested: SemanticLevel = SemanticLevel.FULL_REGISTRY
    target_table: TableRef | None = None
    selected_derived_sources: list[str] | None = None
    semantic_bundle_id: str | None = None
    semantic_bundle_label: str | None = None
    semantic_view_name: str | None = None
    derived_source_lineage: list[dict[str, Any]] | None = None
    datahub_context: dict[str, Any] | None = None
    mapping_intent: dict[str, Any] | None = None
    workspace_context: WorkbenchContextSnapshotV1 | None = None
    execution_context: AgentExecutionContextV2 | None = None
    routing_hint: str | None = None
    project_id: str | None = None
    sttm_id: str | None = None
    learning_context: LearningContext | None = Field(
        default=None,
        description="Comprehensive learning context including FIR learnings, similar mappings, and correction history."
    )
    relation_graph: RelationGraphContext | None = None
    prepared_context_hash: str | None = None
    omit_linked_precedent: bool = False
    replay_exact_precedent: bool = False

    @model_validator(mode="before")
    @classmethod
    def _normalize_empty_source_tables(cls, data: Any) -> Any:
        if isinstance(data, dict) and data.get("source_tables") == []:
            return {**data, "source_tables": None}
        return data


class STTMAgentRequestEnvelope(BaseModel):
    contract_version: Literal["1.0"] = CONTRACT_VERSION
    request_id: str | None = None
    operation: STTMOperation
    context: STTMAgentContext = Field(default_factory=STTMAgentContext)
    data: STTMBuilderRequestData

    @classmethod
    def from_builder_request(
        cls,
        req: "STTMBuilderEnvelopeRequest",
    ) -> "STTMAgentRequestEnvelope":
        return cls(
            request_id=req.request_id,
            operation=req.operation,
            context=STTMAgentContext(
                source_tables=req.context.source_tables,
                driving_table=req.context.driving_table,
                relationships=req.context.relationships,
                semantic_context=req.context.semantic_context,
                selected_columns_by_table=req.context.selected_columns_by_table,
                surface=req.context.surface,
                semantic_level_requested=req.context.semantic_level_requested,
                target_table=req.context.target_table,
                selected_derived_sources=req.context.selected_derived_sources,
                semantic_bundle_id=req.context.semantic_bundle_id,
                semantic_bundle_label=req.context.semantic_bundle_label,
                semantic_view_name=req.context.semantic_view_name,
                derived_source_lineage=req.context.derived_source_lineage,
                datahub_context=req.context.datahub_context,
                mapping_intent=req.context.mapping_intent,
                workspace_context=req.context.workspace_context,
                execution_context=req.context.execution_context,
                routing_hint=req.context.routing_hint,
                project_id=req.context.project_id,
                sttm_id=req.context.sttm_id,
                learning_context=req.context.learning_context,
                relation_graph=req.context.relation_graph,
                prepared_context_hash=req.context.prepared_context_hash,
                omit_linked_precedent=req.context.omit_linked_precedent,
                replay_exact_precedent=req.context.replay_exact_precedent,
            ),
            data=req.data,
        )


class STTMBuilderEnvelopeRequest(BaseModel):
    contract_version: Literal["1.0"] = CONTRACT_VERSION
    request_id: str | None = None
    operation: STTMOperation
    actor: ApiActor | None = None
    context: STTMBuilderContext = Field(default_factory=STTMBuilderContext)
    data: STTMBuilderRequestData
    warnings: list[ApiWarning] = Field(default_factory=list)
    error: ApiError | None = None
    meta: dict[str, Any] = Field(default_factory=dict)

    def to_worker_payload(self) -> dict[str, Any]:
        """Send exact mirrored recipes once, without changing the prepared context."""
        payload = self.model_dump(mode="json", exclude_none=True)
        context = payload["context"]
        learning = context.get("learning_context") or {}
        execution = context.get("execution_context") or {}
        patterns = learning.get("target_mapping_patterns")
        if patterns and execution.get("target_mapping_patterns") == patterns:
            execution.pop("target_mapping_patterns")
            payload["meta"]["execution_patterns_from_learning_v1"] = True
        return payload

    @model_validator(mode="before")
    @classmethod
    def _restore_worker_patterns(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        meta = data.get("meta")
        if not isinstance(meta, dict) or "execution_patterns_from_learning_v1" not in meta:
            return data
        context = data.get("context") or {}
        if not isinstance(context, dict):
            raise ValueError("Invalid worker execution-pattern reference")
        learning = context.get("learning_context") or {}
        execution = context.get("execution_context")
        patterns = learning.get("target_mapping_patterns") if isinstance(learning, dict) else None
        if (
            meta["execution_patterns_from_learning_v1"] is not True
            or not isinstance(execution, dict)
            or "target_mapping_patterns" in execution
            or not isinstance(patterns, list)
            or not patterns
        ):
            raise ValueError("Invalid worker execution-pattern reference")
        restored_meta = dict(meta)
        restored_meta.pop("execution_patterns_from_learning_v1")
        return {
            **data,
            "meta": restored_meta,
            "context": {
                **context,
                "execution_context": {
                    **execution,
                    "target_mapping_patterns": deepcopy(patterns),
                },
            },
        }

    @model_validator(mode="after")
    def _validate_operation_matches_intent(self) -> "STTMBuilderEnvelopeRequest":
        expected = _INTERFACE_TO_OPERATION[self.data.intent]
        valid_operations = {expected}
        if self.data.intent == Interface.CHAT:
            valid_operations.add(STTMOperation.DERIVED_SQL_GENERATE)
        if self.operation not in valid_operations:
            raise ValueError(
                f"operation must be {expected.value!r} when data.intent is {self.data.intent.value!r}"
            )
        return self

    def to_flat_request(self) -> STTMBuilderRequest:
        return STTMBuilderRequest(
            interface=self.data.intent,
            thread_id=self.context.thread_id,
            parent_message_id=self.context.parent_message_id,
            attributes=self.data.attributes,
            source_tables=self.context.source_tables,
            message=self.data.message,
            driving_table=self.context.driving_table,
            relationships=self.context.relationships,
            semantic_context=self.context.semantic_context,
            selected_columns_by_table=self.context.selected_columns_by_table,
        )

    @classmethod
    def from_flat_request(
        cls,
        req: STTMBuilderRequest,
        *,
        request_id: str | None = None,
        warnings: list[ApiWarning] | None = None,
    ) -> "STTMBuilderEnvelopeRequest":
        return cls(
            request_id=request_id,
            operation=_INTERFACE_TO_OPERATION[req.interface],
            context=STTMBuilderContext(
                thread_id=req.thread_id,
                parent_message_id=req.parent_message_id,
                source_tables=req.source_tables,
                driving_table=req.driving_table,
                relationships=req.relationships,
                semantic_context=req.semantic_context,
                selected_columns_by_table=req.selected_columns_by_table,
            ),
            data=STTMBuilderRequestData(
                intent=req.interface,
                attributes=req.attributes,
                message=req.message,
            ),
            warnings=warnings or [],
        )


# ---------------------------------------------------------------------------
# Sub-agent result schemas
# ---------------------------------------------------------------------------


class MappingOption(BaseModel):
    # Keep provenance on the primary as well as alternatives across normalization.
    original_confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    transformation_confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    confidence_policy_version: str | None = None
    confidence_provenance: dict[str, Any] = Field(default_factory=dict)
    rule_candidate_id: str | None = None
    rule_stage: str | None = None
    rule_stage_reason: str | None = None
    rule_definition_hash: str | None = None
    source_attributes: list[str] = Field(
        description="Source attributes that map to this target attribute."
    )
    confidence_score: float = Field(
        ge=0.0,
        le=1.0,
        description="Mapping confidence (0 = no match, 1 = exact).",
    )
    confidence_reason: str | None = Field(
        default=None,
        description="Why the selected source attributes were chosen.",
    )
    candidate_source_attributes: list[str] = Field(
        default_factory=list,
        description="Best fallback source attributes when confidence is low or ambiguous.",
    )
    unmatched_reason: str | None = Field(
        default=None,
        description="Why no confident source mapping could be identified.",
    )
    preprocessing_rule: str | None = Field(
        default=None,
        description="Suggested preprocessing expression or built-in rule name.",
    )
    preprocessing_rule_type: str | None = Field(
        default=None,
        description="Suggested preprocessing rule type, for example Direct or Custom.",
    )
    preprocessing_nl_rule: str | None = Field(
        default=None,
        description="Natural-language description of the preprocessing rule.",
    )
    processing_order: int | None = Field(
        default=None,
        description="Suggested processing order for this mapping.",
    )
    description: str | None = Field(
        default=None,
        description="Suggested human-readable description for the mapping.",
    )
    used_inference_ids: list[str] = Field(default_factory=list)
    used_recommendation_ids: list[str] = Field(default_factory=list)
    used_learning_ids: list[str] = Field(default_factory=list)
    mapping_mode: Literal["source", "constant", "attribute"] = "source"
    constant_value: str | None = None
    attribute_name: str | None = None
    source_dependencies: list[str] = Field(default_factory=list)
    value_binding_ids: list[str] = Field(default_factory=list)
    transformation_classification: Literal[
        "value", "direct", "reused", "simple_multi_source", "complex", "unresolved"
    ] | None = None
    decision_basis: dict[str, Any] = Field(default_factory=dict)
    rule_intent: dict[str, Any] | None = None
    admitted_source_attributes: list[str] = Field(default_factory=list)
    precedent_reason: str | None = None
    precedent_decision: Literal[
        "followed", "adapted", "rejected", "accept_precedent", "override_precedent", "unresolved"
    ] | None = None
    pattern_decision: Literal[
        "accept_exact_precedent", "adapt_pattern", "override_pattern", "unresolved"
    ] | None = None
    precedent_mapping_id: str | None = Field(
        default=None,
        description=(
            "Parent linked STTM ID from mapping_precedents[*].precedent_sttm_id. "
            "Historical row mapping_id values belong in used_learning_ids instead."
        ),
    )
    override_evidence: list[str] = Field(default_factory=list)

    @field_validator("constant_value", mode="before")
    @classmethod
    def _normalize_agent_constant(cls, value: Any) -> Any:
        # The persisted/UI contract is textual; preserve JSON false and zero
        # without silently stringifying objects or accepting nonfinite numbers.
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("constant_value must be a finite JSON scalar")
            return str(value)
        return value

    @field_validator("precedent_decision", mode="before")
    @classmethod
    def _normalize_agent_precedent_decision(cls, value: Any) -> Any:
        return normalize_precedent_decision(value)

    @field_validator("pattern_decision", mode="before")
    @classmethod
    def _normalize_agent_pattern_decision(cls, value: Any) -> Any:
        return normalize_pattern_decision(value)

    @field_validator("mapping_mode", mode="before")
    @classmethod
    def _normalize_agent_mapping_mode(cls, value: Any) -> str:
        token = str(value or "source").strip().lower()
        if token in {"attribute", "project_attribute", "project_value"}:
            return "attribute"
        return "constant" if token in {"value", "constant", "literal", "placeholder"} else "source"

    @field_validator("transformation_classification", mode="before")
    @classmethod
    def _normalize_agent_transformation_classification(cls, value: Any) -> Any:
        if value is None:
            return None
        token = str(value).strip().lower()
        return {
            "multi_source": "simple_multi_source",
            "simple_multi_source": "simple_multi_source",
            "value": "value",
            "direct": "direct",
            "reused": "reused",
            "complex": "complex",
            "unresolved": "unresolved",
        }.get(token, token)


class JoinRecommendation(BaseModel):
    left_relation_id: str | None = None
    right_relation_id: str | None = None
    join_type: Literal["INNER", "LEFT", "RIGHT", "FULL"] | None = None
    conditions: list[dict[str, str]] = Field(default_factory=list)


class MappingDependencyProposal(BaseModel):
    target_columns: list[str] = Field(default_factory=list)
    evidence_ids: list[str] = Field(default_factory=list)
    publication_version_id: str | None = None
    ctes: list[dict[str, Any]] = Field(default_factory=list)
    joins: list[dict[str, Any]] = Field(default_factory=list)
    transformation: str | None = None
    population: Any = None


class MappingSuggestion(BaseModel):
    origin: Literal["model", "validation", "history"] | None = None
    suggestion_id: str = ""
    kind: Literal["relationship", "value", "business_rule", "source_data", "outside_selection", "evidence", "cte", "transformation"] = "evidence"
    message: str
    source_references: list[str] = Field(default_factory=list)
    join_recommendation: JoinRecommendation | None = None
    dependency_proposal: MappingDependencyProposal | None = None


class CandidateScoringIssue(BaseModel):
    code: str
    message: str
    category: Literal["source", "sql", "value", "validation", "evidence"]
    severity: Literal["error", "warning"]


class MappingCandidate(MappingOption):
    adjusted_confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    scoring_issues: list[CandidateScoringIssue] = Field(default_factory=list)
    scoring_policy_version: str | None = None
    candidate_id: str = ""
    validation_status: Literal["unvalidated", "valid", "invalid"] = "unvalidated"
    validation_errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class AttributeMapping(MappingOption):
    candidates: list[MappingCandidate] = Field(default_factory=list, max_length=4)
    selected_candidate_id: str | None = None
    # Preferred concrete draft, not a claim of successful validation.
    draft_candidate_id: str | None = None
    suggestions: list[MappingSuggestion] = Field(default_factory=list)


class SourceMappingResult(BaseModel):
    """Validated result from SOURCE_MAPPING_AGENT."""

    mappings: dict[str, AttributeMapping] = Field(
        description="Keyed by target attribute name."
    )


class TransformationRule(BaseModel):
    confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    confidence_reason: str | None = None
    rule_candidate_id: str | None = None
    target_attribute: str = Field(description="Target column this rule applies to.")
    rule: str = Field(description="Transformation expression or SQL fragment.")
    description: str | None = Field(
        default=None, description="Human-readable explanation of the rule."
    )
    used_inference_ids: list[str] = Field(default_factory=list)
    used_recommendation_ids: list[str] = Field(default_factory=list)
    learning_evidence: list[str] = Field(default_factory=list)
    pattern_decision: Literal[
        "accept_exact_precedent", "adapt_pattern", "override_pattern", "unresolved"
    ] | None = None
    decision_basis: dict[str, Any] = Field(default_factory=dict)
    rule_intent: dict[str, Any] | None = None
    admitted_source_attributes: list[str] = Field(default_factory=list)
    precedent_reason: str | None = None
    precedent_decision: Literal[
        "followed", "adapted", "rejected", "accept_precedent", "override_precedent", "unresolved"
    ] | None = None
    source_dependencies: list[str] = Field(default_factory=list)
    value_binding_ids: list[str] = Field(default_factory=list)
    override_evidence: list[str] = Field(default_factory=list)

    @field_validator("precedent_decision", mode="before")
    @classmethod
    def _normalize_precedent_decision(cls, value: Any) -> Any:
        return normalize_precedent_decision(value)

    @field_validator("pattern_decision", mode="before")
    @classmethod
    def _normalize_pattern_decision(cls, value: Any) -> Any:
        return normalize_pattern_decision(value)


class TransformationResult(BaseModel):
    """Validated result from TRANSFORMATION_AGENT."""

    rules: list[TransformationRule] = Field(
        description="One rule per target attribute."
    )


class STTMBuilderResponseData(BaseModel):
    intent: Interface
    status: STTMStatus
    agent: SubAgent | None = None
    result: SourceMappingResult | TransformationResult | None = None
    message: str | None = None
    artifact_type: STTMArtifactType = STTMArtifactType.NONE
    artifact: dict[str, Any] | None = None
    semantic_level_achieved: SemanticLevel | None = None
    semantic_refresh_status: SemanticRefreshStatus | None = None


class STTMAgentResponseEnvelope(BaseModel):
    contract_version: Literal["1.0"] = CONTRACT_VERSION
    request_id: str | None = None
    operation: STTMOperation
    context: STTMAgentContext = Field(default_factory=STTMAgentContext)
    data: STTMBuilderResponseData
    warnings: list[ApiWarning] = Field(default_factory=list)
    error: ApiError | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Unified response
# ---------------------------------------------------------------------------


class STTMBuilderResponse(BaseModel):
    _auto_map_admitted_evidence: dict[str, Any] = PrivateAttr(default_factory=dict)
    _auto_map_execution: Any = PrivateAttr(default=None)
    contract_version: Literal["1.0"] = CONTRACT_VERSION
    request_id: str | None = None
    operation: STTMOperation | None = Field(
        default=None,
        description="Canonical operation name for the standardized payload envelope.",
    )
    actor: ApiActor | None = None
    context: STTMBuilderContext = Field(default_factory=STTMBuilderContext)
    data: STTMBuilderResponseData | None = Field(
        default=None,
        description="Canonical response data for standardized clients.",
    )
    warnings: list[ApiWarning] = Field(default_factory=list)
    error: ApiError | None = None
    meta: dict[str, Any] = Field(default_factory=dict)

    # Legacy fields kept for existing frontend callers during the migration.
    thread_id: str | None = Field(
        default=None,
        description="Cortex Agent thread ID when an agent call completed."
    )
    parent_message_id: int | None = Field(
        default=None,
        description="Assistant message ID to use as the next parent when continuing the thread.",
    )
    agent: SubAgent | None = Field(
        default=None,
        description="Which sub-agent handled the request. Null when no sub-agent was called.",
    )
    result: SourceMappingResult | TransformationResult | None = Field(
        default=None,
        description="Typed result from the sub-agent. Null when agent is null.",
    )
    message: str | None = Field(
        default=None,
        description="Agent summary or clarifying question. Always present for CHAT interface.",
    )

    @classmethod
    def from_invocation(
        cls,
        request: STTMBuilderEnvelopeRequest,
        *,
        thread_id: str | None,
        parent_message_id: int | None,
        agent: SubAgent | None,
        result: SourceMappingResult | TransformationResult | None,
        message: str | None,
        status: STTMStatus,
        artifact_type: STTMArtifactType = STTMArtifactType.NONE,
        artifact: dict[str, Any] | None = None,
        semantic_level_achieved: SemanticLevel | None = None,
        semantic_refresh_status: SemanticRefreshStatus | None = None,
        warnings: list[ApiWarning] | None = None,
        error: ApiError | dict[str, Any] | None = None,
        meta: dict[str, Any] | None = None,
    ) -> "STTMBuilderResponse":
        context = request.context.model_copy(
            update={
                "thread_id": thread_id,
                "parent_message_id": parent_message_id,
            }
        )
        response_warnings = [*request.warnings, *(warnings or [])]
        normalized_error = _coerce_api_error(error)
        data = STTMBuilderResponseData(
            intent=request.data.intent,
            status=status,
            agent=agent,
            result=result,
            message=message,
            artifact_type=artifact_type,
            artifact=artifact,
            semantic_level_achieved=semantic_level_achieved,
            semantic_refresh_status=semantic_refresh_status,
        )
        return cls(
            request_id=request.request_id,
            operation=request.operation,
            actor=request.actor,
            context=context,
            data=data,
            warnings=response_warnings,
            error=normalized_error,
            meta={**request.meta, **(meta or {})},
            thread_id=thread_id,
            parent_message_id=parent_message_id,
            agent=agent,
            result=result,
            message=message,
        )


def _coerce_api_error(error: ApiError | dict[str, Any] | None) -> ApiError | None:
    if error is None or isinstance(error, ApiError):
        return error
    if not isinstance(error, dict):
        text = str(error).strip()
        if not text:
            return None
        return ApiError(title=text, detail=text)

    title = (
        str(error.get("title") or "").strip()
        or str(error.get("message") or "").strip()
        or str(error.get("detail") or "").strip()
        or str(error.get("code") or "").strip()
        or "Request failed"
    )
    detail = str(error.get("detail") or error.get("message") or title).strip() or title
    status_value = error.get("status")
    try:
        status = int(status_value) if status_value is not None else None
    except (TypeError, ValueError):
        status = None
    code_value = error.get("code")
    field_value = error.get("field")
    type_value = error.get("type")
    return ApiError(
        type=str(type_value).strip() if type_value else "about:blank",
        title=title,
        status=status,
        detail=detail,
        code=str(code_value).strip() if code_value else None,
        field=str(field_value).strip() if field_value else None,
    )


def normalize_sttm_builder_invoke_body(
    body: dict[str, Any] | STTMBuilderEnvelopeRequest | STTMBuilderRequest,
) -> STTMBuilderEnvelopeRequest:
    if isinstance(body, STTMBuilderEnvelopeRequest):
        return body

    if isinstance(body, STTMBuilderRequest):
        return STTMBuilderEnvelopeRequest.from_flat_request(
            body,
            warnings=[
                ApiWarning(
                    code="LEGACY_PAYLOAD",
                    message=(
                        "Accepted legacy flat STTM payload; send the standardized "
                        "contract_version/operation/context/data envelope for new integrations."
                    ),
                )
            ],
        )

    if "contract_version" in body or "schema_version" in body or "operation" in body or "data" in body:
        if "schema_version" in body and "contract_version" not in body:
            body = {**body, "contract_version": body["schema_version"]}
        return STTMBuilderEnvelopeRequest.model_validate(body)

    legacy = STTMBuilderRequest.model_validate(body)
    return STTMBuilderEnvelopeRequest.from_flat_request(
        legacy,
        warnings=[
            ApiWarning(
                code="LEGACY_PAYLOAD",
                message=(
                    "Accepted legacy flat STTM payload; send the standardized "
                    "contract_version/operation/context/data envelope for new integrations."
                ),
            )
        ],
    )
