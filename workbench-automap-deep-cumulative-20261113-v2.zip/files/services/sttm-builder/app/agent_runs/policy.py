"""Validated deployment policy. Each run stores an immutable resolved snapshot."""
from __future__ import annotations
from datetime import UTC, datetime
from typing import Any
from app.agent_runs.models import AgentRun, EFFORT_POLICIES, EffortLevel, EffortPolicy, RunStatus


def recovered_elapsed_seconds(run: AgentRun, *, now: datetime | None = None) -> float:
    """Keep an abandoned active run within its original response deadline.

    Queued resumes use persisted active time so a human approval wait does not
    consume the budget. An EXECUTING run with an expired lease has no reliable
    in-memory counter, so its original start time is the conservative bound.
    """
    elapsed = run.elapsed_seconds_used
    if run.status is RunStatus.EXECUTING:
        phase_start = run.phase_started_at or run.started_at
        if phase_start is not None:
            elapsed = max(elapsed, run.phase_elapsed_start + max(0.0, ((now or datetime.now(UTC)) - phase_start).total_seconds()))
    return elapsed


def resolve_policy(effort: EffortLevel, settings: Any = None) -> EffortPolicy:
    overrides = getattr(settings, 'migration_agent_effort_overrides', {}) or {}
    unknown = set(overrides) - {'light', 'medium', 'high'}
    if unknown:
        raise ValueError(f'Unknown effort policies: {sorted(unknown)}')
    base = EFFORT_POLICIES[effort].model_dump()
    changes = overrides.get(effort.value, {})
    allowed = set(EffortPolicy.model_fields) - {'effort'}
    if set(changes) - allowed:
        raise ValueError(f'Unknown effort settings: {sorted(set(changes) - allowed)}')
    base.update(changes)
    # Explicit working partitions are derived from the effective totals.
    base['working_model_call_budget'] = base['model_call_budget'] - base['finalization_model_call_budget']
    base['working_tool_call_budget'] = base['tool_call_budget'] - base['finalization_tool_call_budget']
    return EffortPolicy.model_validate(base)


def policy_from_state(state: dict[str, Any]) -> EffortPolicy:
    snapshot = state.get('effort_policy')
    return EffortPolicy.model_validate(snapshot) if snapshot else resolve_policy(EffortLevel(state.get('effort') or 'medium'))


def validate_worker_configuration(settings: Any) -> None:
    if not settings.migration_agent_enabled:
        raise ValueError('MIGRATION_AGENT_ENABLED must be enabled to start the worker')
    required = ['migration_agent_true_resume_v1', 'migration_agent_host_terminalization_v1', 'migration_agent_tool_governance_v1']
    missing = [name.upper() for name in required if not getattr(settings, name, False)]
    missing += [f'MIGRATION_AGENT_MODEL_{level.upper()}' for level in ('light','medium','high') if not getattr(settings, f'migration_agent_model_{level}', '').strip()]
    if missing:
        raise ValueError('Deep Agent configuration is incomplete: ' + ', '.join(missing))
    if getattr(settings, "non_local_env", False) and not settings.migration_agent_capacity_scopes:
        raise ValueError("MIGRATION_AGENT_CAPACITY_SCOPES must configure shared capacity in SPCS")
    from string import Formatter
    scopes = getattr(settings, 'migration_agent_capacity_scopes', [])
    limits = getattr(settings, 'migration_agent_capacity_limits', {})
    fields = set()
    scope_dimensions = set()
    for template in scopes:
        dimensions = set()
        for _, field, spec, conversion in Formatter().parse(template):
            if field is not None:
                if field not in {'account','tenant','role','project'} or spec or conversion:
                    raise ValueError('Capacity templates allow only account, tenant, role and project fields')
                fields.add(field)
                dimensions.add(field)
        scope_dimensions.add(frozenset(dimensions))
        if type(limits.get(template)) is not int or not 1 <= limits[template] <= 1000:
            raise ValueError('Each configured capacity scope requires an explicit limit between 1 and 1000')
    if getattr(settings, 'non_local_env', False) and fields != {'account','tenant','role','project'}:
        raise ValueError('SPCS capacity configuration must cover account, tenant, role and project')
    required_dimensions = [ {'account'}, {'account','tenant'}, {'account','role'}, {'account','tenant','project'} ]
    if getattr(settings, 'non_local_env', False) and any(frozenset(d) not in scope_dimensions for d in required_dimensions):
        raise ValueError('SPCS requires independent account, tenant, role and project capacity ceilings')
    if settings.migration_agent_heartbeat_seconds * 2 >= settings.migration_agent_lease_seconds:
        raise ValueError('Worker lease must exceed two heartbeat intervals')
    if settings.migration_agent_max_concurrency < 1:
        raise ValueError('Worker concurrency must be positive')
    for effort in (EffortLevel.LIGHT, EffortLevel.MEDIUM, EffortLevel.HIGH):
        resolve_policy(effort, settings)
