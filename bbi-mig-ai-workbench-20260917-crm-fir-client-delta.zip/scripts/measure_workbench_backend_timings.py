#!/usr/bin/env python3
"""Measure cold and warm Workbench API paths without browser automation.

Database/schema selection is discovered from the authenticated catalog unless
explicit values are supplied. The runner is read-only and contains no client
object, project, mapping, or STTM identifiers.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any, Callable


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "scripts"))

import run_evernest_v2_acceptance as acceptance  # noqa: E402


def _envelope(operation: str, data: dict[str, Any]) -> dict[str, Any]:
    return {
        "contract_version": "1.0",
        "operation": operation,
        "context": {},
        "data": data,
    }


def _items(response: Any) -> list[dict[str, Any]]:
    data = acceptance._response_data(response)
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return []


def _name(item: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = item.get(key)
        if value:
            return str(value)
    return ""


def _measure(label: str, call: Callable[[], Any], repeats: int) -> tuple[Any, list[dict[str, Any]]]:
    response = None
    timings: list[dict[str, Any]] = []
    for run in range(max(1, repeats)):
        started = time.perf_counter()
        response = call()
        elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
        timings.append(
            {
                "path": label,
                "run": run + 1,
                "temperature": "cold_process" if run == 0 else "warm_process",
                "status": response.status_code,
                "elapsed_ms": elapsed_ms,
                "server_total_ms": response.headers.get("x-workbench-timing-total-ms"),
                "server_auth_ms": response.headers.get("x-workbench-timing-auth-ms"),
                "server_session_ms": response.headers.get("x-workbench-timing-session-ms"),
                "server_snowflake_ms": response.headers.get("x-workbench-timing-snowflake-ms"),
                "cache_hit": response.headers.get("x-workbench-cache-hit"),
            }
        )
        if not response.is_success:
            break
    return response, timings


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database")
    parser.add_argument("--schema")
    parser.add_argument("--sttm-id", help="Optional saved mapping to measure.")
    parser.add_argument("--user", required=True, help="Provisioned Snowflake user.")
    parser.add_argument("--email", default="performance-test@example.com")
    parser.add_argument("--runs", type=int, default=2)
    args = parser.parse_args()

    acceptance._configure_environment()
    from fastapi.testclient import TestClient
    from app.core.config import get_settings
    from app.main import app

    get_settings.cache_clear()
    headers = {
        "Sf-Context-Current-User": args.user,
        "Sf-Context-Current-User-Email": args.email,
    }
    results: list[dict[str, Any]] = []
    with TestClient(app) as client:
        database_response, measured = _measure(
            "databases",
            lambda: client.post(
                "/api/v1/table-selection/databases",
                headers=headers,
                json=_envelope("table_selection.list_databases", {}),
            ),
            args.runs,
        )
        results.extend(measured)
        databases = _items(database_response)
        database = args.database or (_name(databases[0], "name", "database", "database_name") if databases else "")

        schema = args.schema or ""
        if database:
            schema_response, measured = _measure(
                "schemas",
                lambda: client.post(
                    "/api/v1/table-selection/schemas",
                    headers=headers,
                    json=_envelope("table_selection.list_schemas", {"database": database}),
                ),
                args.runs,
            )
            results.extend(measured)
            schemas = _items(schema_response)
            schema = schema or (_name(schemas[0], "name", "schema", "schema_name") if schemas else "")

        if database and schema:
            _, measured = _measure(
                "tables",
                lambda: client.post(
                    "/api/v1/table-selection/tables",
                    headers=headers,
                    json=_envelope(
                        "table_selection.list_tables",
                        {"database": database, "schema": schema},
                    ),
                ),
                args.runs,
            )
            results.extend(measured)

        _, measured = _measure(
            "projects_summary",
            lambda: client.get("/api/v1/projects/summary", headers=headers),
            args.runs,
        )
        results.extend(measured)

        if args.sttm_id:
            _, measured = _measure(
                "mapping_detail",
                lambda: client.get(f"/api/v1/sttms/{args.sttm_id}", headers=headers),
                args.runs,
            )
            results.extend(measured)

    print(
        json.dumps(
            {
                "selection": {"database": database or None, "schema": schema or None},
                "timings": results,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
