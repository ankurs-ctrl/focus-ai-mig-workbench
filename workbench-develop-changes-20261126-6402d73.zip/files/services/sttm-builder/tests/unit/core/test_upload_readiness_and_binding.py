"""Offline upload dependency checks and scope-aware lineage regressions."""
from pathlib import Path
from types import SimpleNamespace
import pytest
from app.core.sql_upload_jobs import verify_upload_schema, UploadConfigurationError, is_upload_configuration_error
from app.core.sql_parser import parse_sql_document
from app.core.target_mapping_patterns import TargetMappingPatternService
from app.core.config import Settings

COLUMNS = 'REQUEST_ID PROJECT_ID REQUESTED_BY REQUESTED_ROLE CONTENT_IDENTITY PROCESSOR_VERSION PROCESSING_ID REQUEST_PAYLOAD RESULT_PAYLOAD STATUS STAGE ERROR_CODE GENERATION LEASE_TOKEN LEASE_EXPIRES_AT CREATED_AT UPDATED_AT'.split()

def descriptor(name):
    return {'name':name,'type':'VARIANT' if name in {'REQUEST_PAYLOAD','RESULT_PAYLOAD'} else 'NUMBER(38,0)' if name=='GENERATION' else 'TIMESTAMP_LTZ(9)' if name in {'LEASE_EXPIRES_AT','CREATED_AT','UPDATED_AT'} else 'VARCHAR(16777216)'}


@pytest.mark.parametrize('missing,locks',[('PROCESSING_ID',1),(None,0),(None,2)],ids=['missing-processing-id','no-lock','duplicate-lock'])
def test_dependency_readiness_fails_closed_without_writes(missing,locks):
    statements=[]
    def sql(query):
        statements.append(query)
        return SimpleNamespace(collect=lambda:[descriptor(name)for name in COLUMNS if name!=missing] if query.startswith('DESCRIBE') else [{'N':locks}])
    with pytest.raises(UploadConfigurationError):verify_upload_schema(SimpleNamespace(sql=sql),'D.S.REQUESTS')
    assert all(query.startswith(('DESCRIBE','SELECT'))for query in statements)


def test_dependency_readiness_is_read_only_and_repeatable():
    statements=[]
    def sql(query):
        statements.append(query)
        return SimpleNamespace(collect=lambda:[descriptor(name)for name in COLUMNS] if query.startswith('DESCRIBE')else[{'N':1}])
    for _ in range(2): verify_upload_schema(SimpleNamespace(sql=sql),'D.S.REQUESTS')
    assert len(statements)==4


def test_configuration_errors_are_not_transport_uncertainty():
    assert is_upload_configuration_error(SimpleNamespace(errno=2003))
    assert is_upload_configuration_error(SimpleNamespace(sqlstate='42501'))
    assert not is_upload_configuration_error(TimeoutError())


def test_exact_contacts_backend_lineage_and_fir_agree_on_49_outputs():
    sql=(Path(__file__).resolve().parents[2]/'fixtures/sql_upload/contacts_actual.sql').read_text()
    parsed=parse_sql_document('USE DATABASE D;USE SCHEMA S;'+sql).to_dict()
    assert len(parsed['column_mappings'])==49
    assert not any(row['unresolved_references']for row in parsed['column_mappings'])
    patterns=TargetMappingPatternService(None,Settings()).extract_document_patterns(asset_id='contacts',project_id='501',parsed_document=parsed,evidence_class='unvalidated_authored_sql',base_confidence=.72)
    assert len(patterns)==49


@pytest.mark.parametrize('select',['LENGTH AS A, LENGTH(NAME) AS B','LENGTH(NAME) AS B, LENGTH AS A'],ids=['column-first','function-first'])
def test_function_identifier_is_not_a_bound_column(select):
    parsed=parse_sql_document(f'WITH c AS (SELECT ID AS LENGTH, NAME FROM D.S.T) SELECT {select} FROM c').to_dict()
    from sqlglot import parse_one,exp
    function=next(row for row in parsed['column_mappings']if row['target_alias']=='B')
    expression=parse_one(function['bound_expression'],read='snowflake')
    assert isinstance(expression,exp.Length)
    assert expression.this.table.upper()=='C'
    assert not any(row['unresolved_references']for row in parsed['column_mappings'])


def test_multiple_cte_owners_remain_unresolved():
    parsed=parse_sql_document('WITH a AS (SELECT ID FROM D.S.A), b AS (SELECT ID FROM D.S.B) SELECT ID FROM a JOIN b ON a.ID=b.ID').to_dict()
    assert parsed['column_mappings'][0]['unresolved_references']


def test_nested_cte_shadowing_uses_reachable_scope():
    parsed=parse_sql_document('WITH c AS (SELECT ID FROM D.S.A), n AS (WITH c AS (SELECT OTHER AS ID FROM D.S.B) SELECT ID FROM c) SELECT ID FROM n').to_dict()
    # This is a supported nested lexical binding; never promote a physically unrelated row.
    assert parsed['column_mappings'][0]['physical_source_columns']==['D.S.B.OTHER']


def test_clear_session_expires_host_and_configured_domain_cookies():
    from app.auth.router import clear_rejected_session
    response=clear_rejected_session(SimpleNamespace(auth_session_cookie_name='sttm_session',auth_state_cookie_name='sttm_state',auth_session_cookie_domain='.example.test'))
    cookies=response.headers.getlist('set-cookie')
    assert len(cookies)==4 and all('Max-Age=0' in cookie for cookie in cookies)
    assert sum('Domain=.example.test' in cookie for cookie in cookies)==2
    assert response.headers['cache-control']=='no-store'


@pytest.mark.parametrize('column',['REQUEST_PAYLOAD','GENERATION','LEASE_EXPIRES_AT'],ids=['payload-type','generation-type','lease-type'])
def test_readiness_rejects_incompatible_column_types(column):
    def sql(query):
        rows=[{**descriptor(name),'type':'VARCHAR(100)' if name==column else descriptor(name)['type']}for name in COLUMNS]
        return SimpleNamespace(collect=lambda:rows)
    with pytest.raises(UploadConfigurationError):verify_upload_schema(SimpleNamespace(sql=sql),'D.S.REQUESTS')


@pytest.mark.parametrize('alias,reference',[('c','C'),('C','c')],ids=['upper-reference','lower-reference'])
def test_unquoted_relation_alias_case_is_not_a_lineage_gap(alias,reference):
    parsed=parse_sql_document(f'WITH parent AS (SELECT ID FROM D.S.T) SELECT {reference}.ID FROM parent {alias}').to_dict()
    assert parsed['column_mappings'][0]['physical_source_columns']==['D.S.T.ID']
    assert not parsed['column_mappings'][0]['unresolved_references']


def test_quoted_case_relation_aliases_remain_distinct():
    parsed=parse_sql_document('WITH a AS (SELECT ID FROM D.S.A), b AS (SELECT ID FROM D.S.B) SELECT "x".ID AS LO, "X".ID AS HI FROM a "x" JOIN b "X" ON "x".ID="X".ID').to_dict()
    assert [row['physical_source_columns']for row in parsed['column_mappings']]==[['D.S.A.ID'],['D.S.B.ID']]


def test_simple_cte_star_traces_the_outer_column_and_leaves_ambiguous_stars_unresolved():
    simple = parse_sql_document(
        'WITH a AS (SELECT t.* FROM D.S.T t), b AS (SELECT * FROM a) SELECT b."CustomerId" FROM b'
    ).column_mappings[0]
    assert simple.physical_source_columns == ['D.S.T."CustomerId"']
    assert not simple.unresolved_references

    ambiguous = parse_sql_document(
        'WITH a AS (SELECT * FROM D.S.A a JOIN D.S.B b ON a.ID = b.ID) SELECT a.ID FROM a'
    ).column_mappings[0]
    assert not ambiguous.physical_source_columns
    assert ambiguous.unresolved_references == ["unresolved_cte_output:a.ID"]


def test_unused_static_values_can_be_selected_but_object_identifiers_cannot():
    bindings = parse_sql_document(
        "SET UnusedPrefix = 'ABC_'; SET TableFqn = 'D.S.T'; SELECT ID FROM IDENTIFIER($TableFqn);"
    ).variable_bindings
    assert bindings[0].reference_count == 0
    assert bindings[0].classification == "declared_unused"
    assert bindings[0].project_value_candidate
    assert not bindings[1].project_value_candidate
