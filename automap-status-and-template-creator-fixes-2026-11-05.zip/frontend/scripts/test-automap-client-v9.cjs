// Production reducers + installed SHA, using complete client-shaped resolution metadata.
const assert=require('node:assert/strict');
const test=require('node:test').test;
const ts=require('typescript');
const fs=require('node:fs');
const path=require('node:path');
const h=require('./test-automap-preservation.cjs');
const {helpers,reducer,stateFor,blank,imported,response,direct}=h;
const values=[{name:'FirmID',value:'current'}];
const begin=(state,checked=[],options)=>{
  state.selectedMappingIds=checked;
  reducer(h.pendingReducer)(state,{meta:{requestId:'run-one',arg:options}});
  state.autoMapRun.valuesRevision=helpers.autoMapRevisionHash(helpers.autoMapValuesSignature(values));
};
const finish=state=>reducer(h.fulfilledReducer)(state,{meta:{requestId:'run-one'},payload:{
  failedTargets:[],autoMapOutcome:null,autoMappingReview:null,reviewSummary:null}});
function reevaluation(proposal,{marked=true}={}){
  return response(proposal,{meta:{
    automap_preserved_targets:[],
    automap_baseline_preservation:{instruction:'preserve_frontend_rows',apply_preserved_mappings:false},
    automap_resolution:{mode:'reeval_selected',targets:[{target_attribute:'NAME',status:'pending',
      ...(marked?{reevaluate:true,had_baseline:true}:{}),execution_status:'not_validated',unresolved_values:[]}]},
    auto_mapping_review:{headline:'One replacement',recommendations:[],mapped_count:0,newly_mapped_count:0,
      proposed_count:1,preserved_count:0,total_count:1,unresolved_count:0,action_required_count:0},
  }});
}
const originals={source:()=>imported(),emptyConstant:()=>({...blank(),status:'MAPPED',mappingMode:'constant',constantValue:'',rule:'Value'}),
  attribute:()=>({...blank(),status:'MAPPED',mappingMode:'attribute',attributeName:'FirmID',constantValue:'$FirmID',rule:'Value'}),
  unpublished:()=>({...imported(),validation:null,status:'NEEDS_VALIDATION'})};
for(const [kind,make] of Object.entries(originals)){originals[kind]=()=>{const value=make();if(value.status==='MAPPED')value.validation=helpers.validatedRow(value,helpers.selectionValidationSignature({activeProjectId:'project'}));return value;};}
for(const[kind,make]of Object.entries(originals))for(const marked of[true,false])test(`pending reevaluation preserves original ${kind} definition/status (backend marker=${marked})`,()=>{
  const original=make();const state=stateFor(structuredClone(original));begin(state,['NAME']);
  helpers.applyAutoMapResponseToState(state,reevaluation(direct,{marked}));
  helpers.applyAutoMapResponseToState(state,reevaluation(direct,{marked})); // progress then terminal
  assert.deepEqual(state.mappings[0],original);
  assert.equal(state.pendingAiMappingReviews.length,1);
  const completion=helpers.autoMapCompletionCounts(state,['NAME'],'run-one',0);
  assert.deepEqual(completion,{newMappings:0,newProposals:0,replacementProposals:1,preservedDefinitions:1,unresolved:0});
  assert.match(helpers.autoMapCompletionMessage(1,completion),/1 replacement proposals awaiting review, 1 existing definitions retained, 0 unresolved/);
  finish(state);assert.deepEqual(state.mappings[0],original);
});
for(const kind of['source','emptyConstant','attribute'])test(`failed/unresolved reevaluation keeps mapped ${kind} and alternatives`,()=>{
  const original=originals[kind]();const state=stateFor(structuredClone(original));begin(state,['NAME']);
  const outcome=reevaluation({source_attributes:[],confidence_score:0,transformation_classification:'unresolved',
    candidate_source_attributes:['src.Alternative'],confidence_reason:'Check the business meaning.',unmatched_reason:'Need a business decision'});
  helpers.applyAutoMapResponseToState(state,outcome);finish(state);
  assert.deepEqual(state.mappings[0],original);assert.equal(state.pendingAiMappingReviews.length,0);
  assert.deepEqual(state.mappingSuggestions[0].candidateSourceAttributes,['src.Alternative']);
});
test('an invalid non-reevaluated baseline is still not certified by preservation',()=>{
  const state=stateFor({...imported(),validation:null});begin(state,[],{action:'complete'});
  // Explicit preserve-only compatibility operation, not the visible default action.
  const bad=reevaluation(direct);bad.meta.automap_resolution.mode='preserve_and_complete';
  bad.meta.automap_resolution.targets[0].reevaluate=false;
  bad.meta.automap_preserved_targets=['NAME'];
  helpers.applyAutoMapResponseToState(state,bad);
  assert.equal(state.mappings[0].status,'NEEDS_VALIDATION');
});
test('completion counts distinguish newly applied mappings from unaccepted evidence-review proposals',()=>{
  const state=stateFor(imported(),blank('NEW'),blank('REVIEW'),blank('UNKNOWN'));begin(state,['NAME','NEW','REVIEW','UNKNOWN']);
  const result=reevaluation(direct);result.result.mappings={NAME:direct,NEW:direct,REVIEW:direct,UNKNOWN:{
    source_attributes:[],transformation_classification:'unresolved',unmatched_reason:'Missing rule'}};
  result.meta.automap_evidence_review_only_targets=['REVIEW'];
  helpers.applyAutoMapResponseToState(state,result);
  const counts=helpers.autoMapCompletionCounts(state,['NAME','NEW','REVIEW','UNKNOWN'],'run-one',1);
  assert.deepEqual(counts,{newMappings:1,newProposals:1,replacementProposals:1,preservedDefinitions:1,unresolved:2});
  assert.match(helpers.autoMapCompletionMessage(4,counts),/1 new draft mappings applied, 1 new proposals, 1 replacement proposals/);
});
test('completion counts exclude old proposals from a different run or unchecked targets',()=>{
  const state=stateFor(imported(),blank('NEW'));begin(state,['NAME']);
  helpers.applyAutoMapResponseToState(state,reevaluation(direct));
  state.pendingAiMappingReviews.push({...state.pendingAiMappingReviews[0],mappingId:'NEW',targetColumn:'NEW',autoMapRunId:'older'});
  assert.equal(helpers.autoMapCompletionCounts(state,['NAME'],'run-one',0).replacementProposals,1);
  assert.equal(helpers.autoMapCompletionCounts(state,['NAME'],'run-one',0).newProposals,0);
});
for(const file of['auto-map-completion-toast.tsx','source-target-attribute-mapping.tsx'])test(`completion review action opens chat from ${file}`,()=>{
  const source=fs.readFileSync(path.join(__dirname,'../src/features/sttm/mapping',file),'utf8');
  const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);let handler;
  function visit(node){
    if(ts.isJsxAttribute(node)&&node.name.text==='onClick'&&node.initializer&&source.slice(node.pos,node.end).includes("setPanelView('chat'); openChat();"))handler=node.initializer.expression;
    ts.forEachChild(node,visit);
  }visit(ast);assert.ok(handler,'Review button must have an executable chat-opening handler');
  let view='history',open=false;
  h.compile(`return (${handler.getText(ast)});`,{setPanelView:v=>view=v,openChat:()=>open=true})();
  assert.equal(view,'chat');assert.equal(open,true);
});
test('selection sidebar exposes a single Auto-map action with the checked/all scope explanation',()=>{
  const source=fs.readFileSync(path.join(__dirname,'../src/features/sttm/mapping/source-target-attribute-list.tsx'),'utf8');
  assert.match(source,/const autoLabel = "Auto-map"/);
  assert.doesNotMatch(source,/>Retry unresolved<|>Reevaluate all</);
  assert.match(source,/Only \$\{checkedRows.length\} checked targets/);
  assert.match(source,/All targets reevaluated. Existing definitions stay/);
  const state=stateFor(imported(),blank('NEW'));assert.deepEqual(helpers.autoMapScope(state).names,['NAME','NEW']);
  state.selectedMappingIds=['NAME'];const scope=helpers.autoMapScope(state);
  assert.deepEqual(scope.names,['NAME']);assert.deepEqual(scope.existing,['NAME']);assert.equal(scope.mode,'reeval_selected');
});

test('run-start reevaluation authority preserves mapped status even when older response diagnostics are absent',()=>{
  const original=imported();const state=stateFor(structuredClone(original));begin(state,['NAME']);
  const result=reevaluation(direct);result.meta.automap_resolution.targets=[];
  result.meta.automap_preserved_targets=['NAME'];
  result.meta.auto_mapping_review.recommendations=[{category:'baseline_proposal',target_attribute:'NAME',severity:'action_required'}];
  helpers.applyAutoMapResponseToState(state,result);finish(state);
  assert.deepEqual(state.mappings[0],original);assert.equal(state.pendingAiMappingReviews.length,1);
});
