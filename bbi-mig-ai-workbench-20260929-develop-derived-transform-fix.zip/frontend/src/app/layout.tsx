import type { Metadata } from "next";
import "./globals.css";
import '@/theme/theme.css';
import Providers from "./Providers";
import { CLIENT_CONFIG as config } from '@/config/client.config';

export const metadata: Metadata = {
  title: config.app.title,
  description: config.app.description,
  icons: {
    icon: config.branding.logo.favicon,
  },
};

/**
 * Runs before React hydrates so a timed-out `app/layout` chunk can still recover.
 * Keep this in sync with CHUNK_RELOAD_* in chunk-error-recovery.tsx.
 */
const CHUNK_RECOVERY_SCRIPT = `
(function () {
  try {
    var key = "app-chunk-reload-attempt";
    var maxAttempts = 2;
    function isChunkFailure(message) {
      if (!message) return false;
      return (
        message.indexOf("ChunkLoadError") !== -1
        || message.indexOf("Loading chunk") !== -1
        || message.indexOf("Failed to fetch dynamically imported module") !== -1
        || message.indexOf("error loading dynamically imported module") !== -1
      );
    }
    function attemptReload(message) {
      if (!isChunkFailure(String(message || ""))) return;
      var attempts = Number(sessionStorage.getItem(key) || "0");
      if (attempts >= maxAttempts) return;
      sessionStorage.setItem(key, String(attempts + 1));
      window.location.reload();
    }
    window.addEventListener("error", function (event) {
      attemptReload((event && event.message) || (event && event.error && event.error.message) || "");
    });
    window.addEventListener("unhandledrejection", function (event) {
      var reason = event && event.reason;
      var message = reason && reason.message ? reason.message : String(reason || "");
      attemptReload(message);
    });
  } catch (e) {}
})();
`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="emotion-insertion-point" content="" />
        <script dangerouslySetInnerHTML={{ __html: CHUNK_RECOVERY_SCRIPT }} />
      </head>
      <body suppressHydrationWarning>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
