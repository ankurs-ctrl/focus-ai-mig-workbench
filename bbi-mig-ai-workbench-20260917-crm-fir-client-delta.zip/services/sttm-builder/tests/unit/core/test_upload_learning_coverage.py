from types import SimpleNamespace

from app.routers.upload import (
    _learning_coverage,
    _resolve_existing_mapping_context,
    _target_names_match,
)


def test_learning_coverage_does_not_claim_unresolved_rows() -> None:
    coverage = _learning_coverage(
        {
            "column_mappings": [
                {"target_column": "ID", "source_columns": ["SRC.ID"]},
                {"target_column": "NAME", "source_columns": [], "unresolved_references": ["SRC.NAME"]},
            ],
            "parse_warnings": ["row 3 was skipped"],
        },
        deterministic_saved=1,
        learning_job_id="job-1",
    )

    assert coverage["parsed_mapping_rows"] == 2
    assert coverage["resolved_mapping_rows"] == 1
    assert coverage["deterministic_learnings_saved"] == 1
    assert coverage["complete"] is False
    assert len(coverage["unresolved_rows"]) == 1
    assert len(coverage["skipped_rows"]) == 1


def test_locked_target_comparison_supports_excel_leaf_names() -> None:
    assert _target_names_match("CLIENT_DB.SALESFORCE.HOUSEHOLD", "HOUSEHOLD")
    assert _target_names_match("CLIENT_DB.SALESFORCE.HOUSEHOLD", "client_db.salesforce.household")
    assert not _target_names_match("CLIENT_DB.SALESFORCE.HOUSEHOLD", "CALLS")


def test_existing_mapping_context_uses_persisted_contract_metadata() -> None:
    project_service = SimpleNamespace(
        get_sttm_record=lambda _sttm_id: SimpleNamespace(
            project_id="project-1",
            target_table="CLIENT_DB.SALESFORCE.HOUSEHOLD",
            metadata={
                "physical_target_fqn": "CLIENT_DB.SALESFORCE.HOUSEHOLD",
                "logical_target_table_key": "CRM.HOUSEHOLD",
                "source_system_key": "REDTAIL",
            },
        )
    )

    assert _resolve_existing_mapping_context(
        project_service,
        sttm_id="sttm-1",
        project_id="project-1",
        expected_target_table="HOUSEHOLD",
        logical_target_key="UNTRUSTED.TARGET",
        source_system_key="UNTRUSTED_CRM",
    ) == (
        "CLIENT_DB.SALESFORCE.HOUSEHOLD",
        "CRM.HOUSEHOLD",
        "REDTAIL",
    )
