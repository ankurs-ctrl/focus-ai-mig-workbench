"""Read complete live agent specs through Agent Studio; never save or publish agents."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import subprocess

import yaml


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", default="")
    parser.add_argument("--snapshot-dir", type=Path, help="Compare existing private snapshots without connecting")
    parser.add_argument("--snow-cli", action="store_true", help="Use Snow CLI DESCRIBE instead of Agent Studio")
    parser.add_argument("--output-dir", type=Path, help="New private directory for complete before-spec snapshots")
    parser.add_argument("--connection", required=True)
    parser.add_argument("--agents", nargs="+", choices=["AGT_SOURCE_MAPPING", "AGT_STTM_BUILDER", "AGT_TRANSFORMATION_RULE", "AGT_FIR_SYSTEM"])
    parser.add_argument("--namespace", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if args.output_dir:
        if not args.output_dir.is_absolute() or args.output_dir.exists():
            parser.error("--output-dir must be a new absolute path")
        args.output_dir.mkdir(parents=True)
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_$]*\.[A-Za-z_][A-Za-z0-9_$]*', args.namespace):
        parser.error("--namespace must be DATABASE.SCHEMA")
    for name, template in (
        ("AGT_SOURCE_MAPPING", "source_mapping"), ("AGT_STTM_BUILDER", "sttm_builder"),
        ("AGT_TRANSFORMATION_RULE", "transformation_rule"), ("AGT_FIR_SYSTEM", "fir_system"),
    ):
        if args.agents and name not in args.agents:
            continue
        command = ([args.cli, "sql", "-c", args.connection, "--format", "JSON", "-q",
                    f"DESCRIBE AGENT {args.namespace}.{name}"] if args.snow_cli else
                   [args.cli, "agent-studio", "agent-read", "--fqn", f"{args.namespace}.{name}",
                    "--connection", args.connection])
        if args.snapshot_dir:
            live = json.loads((args.snapshot_dir / f"{name}.before.json").read_text(encoding="utf-8"))
        else:
            if not args.cli:
                parser.error("--cli is required without --snapshot-dir")
            process = subprocess.run(command, cwd=root, capture_output=True,
                                     text=True, encoding="utf-8", timeout=180, check=False)
            if process.returncode:
                raise RuntimeError(process.stderr or process.stdout)
            if args.snow_cli:
                result = json.loads(process.stdout)
                live = json.loads(result[0]["agent_spec"])
            else:
                result = json.loads(process.stdout[process.stdout.index("{"):])
                if not result.get("success"):
                    raise RuntimeError(json.dumps(result))
                live = yaml.safe_load(result.get("yaml_content") or "{}")
        if args.output_dir:
            (args.output_dir / f"{name}.before.json").write_text(json.dumps(live, indent=2), encoding="utf-8")
        local = yaml.safe_load((root / "infra/snowflake/agents" / f"agent_spec_{template}.yaml").read_text(encoding="utf-8"))
        rendered_local = yaml.safe_load(yaml.safe_dump(local).replace("__STTM_METADATA_NAMESPACE__", args.namespace))
        differing_fields = [key for key in ("models", "orchestration", "tools", "tool_resources")
                            if rendered_local.get(key) != live.get(key)]
        print(json.dumps({"agent": name, "non_instruction_differences": differing_fields}), flush=True)
        live_instructions, local_instructions = live.get("instructions") or {}, local.get("instructions") or {}
        if args.output_dir:
            import difflib
            for field in ("orchestration", "response"):
                delta = difflib.unified_diff(
                    str(live_instructions.get(field, "")).splitlines(),
                    str(local_instructions.get(field, "")).splitlines(),
                    fromfile="live", tofile="canonical", lineterm="",
                )
                (args.output_dir / f"{name}.{field}.diff").write_text("\n".join(delta), encoding="utf-8")
        print(json.dumps({"agent": name, "live_spec_sha256": hashlib.sha256(
            json.dumps(live, sort_keys=True).encode("utf-8")).hexdigest(),
            "models": live.get("models"), "orchestration": live.get("orchestration"),
            "tools": [item.get("tool_spec", {}).get("name") for item in live.get("tools") or []],
            "instruction_matches": {key: live_instructions.get(key) == value for key, value in local_instructions.items()},
            "live_instruction_chars": {key: len(value) for key, value in live_instructions.items() if isinstance(value, str)},
        }), flush=True)


if __name__ == "__main__":
    main()