from __future__ import annotations

import json
import re
from typing import Any

import httpx
from langchain_core.language_models import LanguageModelInput
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_openai import ChatOpenAI


def _tool_result_text(message: ToolMessage, tool_names: dict[str, str]) -> str:
    """Render an executed tool result as factual provider-safe context."""
    tool_name = message.name or tool_names.get(message.tool_call_id) or "workbench_tool"
    content = message.content
    if not isinstance(content, str):
        try:
            content = json.dumps(content, default=str, separators=(",", ":"))
        except (TypeError, ValueError):
            content = str(content)
    successful = getattr(message, 'status', None) != 'error'
    try:
        body = json.loads(content)
        if isinstance(body, dict) and body.get('status') in {'failed', 'denied', 'needs_input', 'cancelled'}:
            successful = False
    except (ValueError, TypeError):
        pass
    incomplete = content.endswith('formatting tools to split long lines.]')
    label = 'Incomplete tool page; retrieve complete evidence before relying on omitted fields' if incomplete else ('Verified result' if successful else 'Unsuccessful tool result')
    return f"[{label} from {tool_name}]\n{content}"


def normalize_cortex_tool_history(messages: list[BaseMessage]) -> list[BaseMessage]:
    """Make completed tool exchanges safe for Snowflake Cortex replay.

    Cortex currently rejects some otherwise valid OpenAI-compatible requests
    containing completed historical tool-call blocks. Durable graph state is
    left untouched. Only the provider request is normalized, retaining every
    actual tool result as labelled factual context for the supervisor.
    """
    tool_names: dict[str, str] = {}
    for message in messages:
        if isinstance(message, AIMessage):
            for call in message.tool_calls:
                call_id = call.get("id")
                name = call.get("name")
                if call_id and name:
                    tool_names[str(call_id)] = str(name)

    normalized: list[BaseMessage] = []
    supplied_records: set[str] = set()
    supplied_pages: set[tuple[str, str]] = set()
    for message in messages:
        if isinstance(message, ToolMessage):
            content = message.content
            tool_name = message.name or tool_names.get(message.tool_call_id) or 'workbench_tool'
            if isinstance(content, str) and len(content) > 16000:
                page_key = (tool_name, content)
                if page_key in supplied_pages:
                    normalized.append(HumanMessage(content='[Repeated tool page; use its earlier content and coverage limitations.]', name='workbench_tool_result'))
                    continue
                supplied_pages.add(page_key)
            record = None
            if isinstance(content, str):
                # The virtual filesystem may return the same complete JSON
                # record with a line-number prefix after tool-result offload.
                candidate = re.sub(r'^\s*1\s+(?=[{\[])', '', content)
                try:
                    record = json.dumps(json.loads(candidate), sort_keys=True, separators=(',', ':'))
                except (ValueError, TypeError):
                    pass
            if record is not None and record in supplied_records:
                normalized.append(HumanMessage(content='[Repeated complete tool record; use its earlier supplied body and citations.]', name='workbench_tool_result'))
                continue
            if record is not None:
                supplied_records.add(record)
            normalized.append(
                HumanMessage(
                    content=_tool_result_text(message, tool_names),
                    name="workbench_tool_result",
                )
            )
            continue
        if isinstance(message, AIMessage) and (
            message.tool_calls
            or message.invalid_tool_calls
            or "tool_calls" in message.additional_kwargs
        ):
            # Keep a real assistant preamble, but do not replay its historical
            # provider tool block. New tool calls remain available on this turn.
            if message.text.strip():
                normalized.append(AIMessage(content=message.text))
            continue
        normalized.append(message)
    return normalized


class SnowflakeCortexChatOpenAI(ChatOpenAI):
    """ChatOpenAI adapter with Cortex-compatible historical tool messages."""

    def _stream(self, messages, stop=None, run_manager=None, **kwargs):
        metrics={'text_characters':0,'argument_characters':0,'tool_chunks':0}
        try:
            for chunk in super()._stream(messages,stop=stop,run_manager=run_manager,**kwargs):
                message=chunk.message
                metrics['text_characters']+=len(message.text)
                for call in getattr(message,'tool_call_chunks',[]) or []:
                    metrics['tool_chunks']+=1
                    metrics['argument_characters']+=len(call.get('args') or '')
                yield chunk
        except Exception as exc:
            exc.model_stream_metrics=dict(metrics)
            raise

    def _get_request_payload(
        self,
        input_: LanguageModelInput,
        *,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        messages = self._convert_input(input_).to_messages()
        return super()._get_request_payload(
            normalize_cortex_tool_history(messages),
            stop=stop,
            **kwargs,
        )


# Input context windows of Cortex REST models (Snowflake "Model restrictions" table).
# Deep Agents' built-in compaction triggers at 85% of the model profile's
# max_input_tokens; without a profile it falls back to a fixed 170K tokens.
CORTEX_CONTEXT_WINDOWS = {
    "claude-haiku-4-5": 200_000,
    "claude-sonnet-4-5": 200_000,
    "claude-opus-4-5": 200_000,
    "claude-4-sonnet": 200_000,
    "claude-sonnet-4-6": 1_000_000,
    "claude-sonnet-5": 1_000_000,
    "claude-opus-4-6": 1_000_000,
    "claude-opus-4-7": 1_000_000,
    "claude-opus-4-8": 1_000_000,
    "claude-opus-5": 1_000_000,
    "openai-gpt-5": 272_000,
    "openai-gpt-5-mini": 272_000,
    "openai-gpt-5.1": 272_000,
    "openai-gpt-4.1": 128_000,
}
DEFAULT_CONTEXT_WINDOW = 200_000


def context_window_for(model: str, override: int | None = None) -> int:
    """The input window used for compaction and the context meter."""
    if override:
        return int(override)
    return CORTEX_CONTEXT_WINDOWS.get(str(model or "").strip().lower(), DEFAULT_CONTEXT_WINDOW)


def build_snowflake_cortex_model(
    *,
    host: str,
    oauth_token: str,
    model: str,
    role: str | None = None,
    warehouse: str | None = None,
    reasoning_effort: str | None = None,
    timeout_seconds: float = 240.0,
    max_retries: int = 2,
    auth_mode: str = "oauth_bearer",
    context_window_tokens: int | None = None,
    max_completion_tokens: int = 16_384,
) -> ChatOpenAI:
    """Build the OpenAI-compatible Snowflake Cortex chat adapter.

    The token and effective role are kept in the HTTP client configuration and
    are never put into prompts, graph state, checkpoints, or streamed events.
    """
    normalized_host = host.strip().rstrip("/")
    if not normalized_host:
        raise ValueError("Snowflake host is required")
    if not normalized_host.startswith(("http://", "https://")):
        normalized_host = f"https://{normalized_host}"
    if not oauth_token:
        raise ValueError("A delegated Snowflake OAuth token is required")
    headers: dict[str, str] = {}
    if auth_mode == "snowflake_token":
        # Local password/key-pair Snowpark sessions expose a Snowflake session
        # token, not an OAuth token. Match the auth form used by the existing
        # Cortex Agent and Analyst clients for that session type.
        headers["Authorization"] = f'Snowflake Token="{oauth_token}"'
    elif auth_mode == "oauth_bearer":
        headers["X-Snowflake-Authorization-Token-Type"] = "OAUTH"
    else:
        raise ValueError(f"Unsupported Snowflake Cortex auth mode: {auth_mode}")
    if role:
        headers["X-Snowflake-Role"] = role
    if warehouse:
        headers["X-Snowflake-Warehouse"] = warehouse
    model_options: dict[str, Any] = {}
    if reasoning_effort and model.startswith("openai-"):
        # Snowflake documents reasoning_effort for OpenAI reasoning models.
        # Anthropic models reject or ignore this provider-specific field.
        model_options["reasoning_effort"] = reasoning_effort
    return SnowflakeCortexChatOpenAI(
        model=model,
        api_key=oauth_token,
        base_url=f"{normalized_host}/api/v2/cortex/v1",
        default_headers=headers,
        timeout=timeout_seconds,
        max_retries=max_retries,
        stream_usage=True,
        max_completion_tokens=max_completion_tokens,
        http_client=httpx.Client(trust_env=False),
        http_async_client=httpx.AsyncClient(trust_env=False),
        profile={"max_input_tokens": context_window_for(model, context_window_tokens)},
        **model_options,
    )
