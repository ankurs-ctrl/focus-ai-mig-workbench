"""Version-two inventory: execution reservations plus bounded recovery exposure.

Provision all rows under a quiesced exclusive deployment gate. Legacy uncertain
operations are copied to the recovery portion, never discarded. Every uncertain
remote call consumes ONE row in this same inventory, including during handoff.
"""
from dataclasses import asdict
import json
import hashlib
import re
from uuid import uuid4

from app.core.automap_admission import (
    AdmissionInvariantError, AdmissionUnavailable, AdmissionContended, Permit, CallIdentity, StalePermit,
    _affected, _row,
)
from app.core.automap_runtime import RuntimeCallAdmission


class DurableRunAdmission(RuntimeCallAdmission):
    separate_wait_budget = True
    control_stripes = 64
    def __init__(self, *, recovery_capacity=4, **kwargs):
        super().__init__(**kwargs)
        if type(recovery_capacity) is not int or not 1 <= recovery_capacity <= 16:
            raise ValueError('Recovery capacity must be in [1,16]')
        if self.capacity + recovery_capacity > 32:
            raise ValueError('Total outstanding-call ceiling exceeds 32')
        self.recovery_capacity = recovery_capacity
        self.inventory_capacity = self.capacity + recovery_capacity
        self._claim_extra = (", DISPATCH_PROTOCOL = 'background_v2', MODEL_RUN_ID = NULL, REQUEST_ARCHIVE_REF = NULL, "
            "RUN_DEADLINE = NULL, NEXT_RECOVERY_AT = NULL, RECOVERY_ATTEMPTS = 0, "
            "RECOVERY_OWNER = NULL, RECOVERY_LEASE_AT = NULL, LAST_RECOVERY_REASON = NULL")

    def _health_details(self,summary,items):
        summary.update(capacity=self.inventory_capacity,execution_capacity=self.capacity,
            recovery_capacity=self.recovery_capacity,outstanding_ceiling=self.inventory_capacity,
            execution_free=sum(v['STATE']=='FREE' and v['SLOT_ID']<=self.capacity for v in items),
            recovery_occupied=sum(v['STATE']!='FREE' and v['SLOT_ID']>self.capacity for v in items))
        return summary

    def _claimable_slot(self, slot_id):
        return slot_id <= self.capacity

    def try_claim(self, identity):
        if type(identity) is not CallIdentity:
            raise TypeError('Trusted call identity required')
        with self._transaction() as session:
            # Serialize duplicate identities on one of 64 short claim stripes, never
            # globally serialize unrelated jobs or hold a lock during model execution.
            # Unlike informational standard-table PKs this row UPDATE actually
            # serializes duplicate operation claims across independent replicas.
            stripe=int.from_bytes(hashlib.sha256(json.dumps(asdict(identity),sort_keys=True).encode()).digest(),'big') % self.control_stripes
            n = _affected(self._sql(session, f"UPDATE {self._table}_CONTROL SET FENCE=FENCE+1 "
                "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND STRIPE_ID=?", [self.account_namespace,self.pool_epoch,stripe]))
            if n != 1:
                raise AdmissionInvariantError('Exactly one admission control row required')
            items = [_row(v) for v in self._sql(session,
                f"SELECT SLOT_ID, POOL_EPOCH, STATE, OWNER_TOKEN, FENCE, JOB_ID, CALLER_ID, GENERATION, SHARD_ID "
                f"FROM {self._table} WHERE ACCOUNT_NAMESPACE=? ORDER BY SLOT_ID LIMIT {self.inventory_capacity+1}",
                [self.account_namespace])]
            if (len(items)!=self.inventory_capacity or [v.get('SLOT_ID') for v in items]!=list(range(1,self.inventory_capacity+1))
                or any(v.get('POOL_EPOCH')!=self.pool_epoch or v.get('STATE') not in {'FREE','HELD','QUARANTINED'}
                       or type(v.get('FENCE')) is not int or v['FENCE']<0
                       or (v['STATE']=='FREE')!=(v.get('OWNER_TOKEN') is None) for v in items)):
                raise AdmissionInvariantError('Invalid execution/recovery inventory')
            if any(v['STATE']!='FREE' and all(v.get(k)==getattr(identity,a) for k,a in
                   [('JOB_ID','job_id'),('CALLER_ID','caller_id'),('GENERATION','generation'),('SHARD_ID','shard_id')]) for v in items):
                return None  # original attempt still outstanding; never resubmit
            available=[v for v in items if v['STATE']=='FREE' and v['SLOT_ID']<=self.capacity]
            free=available[stripe % len(available)] if available else None
            if free is None:
                return None
            owner=uuid4().hex
            n=_affected(self._sql(session,f"UPDATE {self._table} SET STATE='HELD', OWNER_TOKEN=?, FENCE=FENCE+1, "
                "JOB_ID=?, CALLER_ID=?, GENERATION=?, SHARD_ID=?, "
                "LEASE_EXPIRES_AT=DATEADD('second',?,CURRENT_TIMESTAMP()), UPDATED_AT=CURRENT_TIMESTAMP(), "
                f"COMPLETION=NULL, RECONCILIATION_REF=NULL {self._claim_extra} "
                "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND SLOT_ID=? AND FENCE=? AND STATE='FREE' AND OWNER_TOKEN IS NULL",
                [owner,identity.job_id,identity.caller_id,identity.generation,identity.shard_id,self.lease_seconds,
                 self.account_namespace,self.pool_epoch,free['SLOT_ID'],free['FENCE']]))
            if n==0: raise AdmissionContended('Execution reservation contended')
            if n!=1: raise AdmissionInvariantError('Execution claim updated multiple rows')
            return Permit(self.account_namespace,self.pool_epoch,free['SLOT_ID'],owner,free['FENCE']+1,identity)

    def recover_not_dispatched(self,permit):
        params=self._permit_params(permit)
        with self._transaction() as session:
            n=_affected(self._sql(session,f"UPDATE {self._table} SET STATE='FREE', OWNER_TOKEN=NULL, "
                "FENCE=FENCE+1, COMPLETION='NOT_DISPATCHED', LEASE_EXPIRES_AT=NULL, UPDATED_AT=CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND SLOT_ID=? AND OWNER_TOKEN=? AND FENCE=? "
                "AND JOB_ID=? AND CALLER_ID=? AND GENERATION=? AND SHARD_ID=? "
                "AND DISPATCH_PROTOCOL='background_v2' AND RECONCILIATION_REF IS NULL AND MODEL_RUN_ID IS NULL "
                "AND (STATE='QUARANTINED' OR (STATE='HELD' AND LEASE_EXPIRES_AT<=CURRENT_TIMESTAMP()))",params))
            if n!=1:raise StalePermit('No-dispatch proof changed')
            self._event(session,permit,'NOT_DISPATCHED_RELEASE',{'proof':'new_protocol_without_committed_thread'})

    def record_preparation(self, permit, reference, archive_ref, seconds):
        from app.core.automap_admission import ThreadReference
        if type(reference) is not ThreadReference or not re.fullmatch('[0-9a-f]{64}', archive_ref or ''):
            raise ValueError('Exact thread and archived request required')
        if type(seconds) is not int or not 10 <= seconds <= 600:
            raise ValueError('Bounded execution deadline required')
        self._change(permit, "RECONCILIATION_REF = ?, REQUEST_ARCHIVE_REF = ?, RUN_DEADLINE = DATEADD('second', ?, CURRENT_TIMESTAMP()), LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP())",
            [reference.serialize(), archive_ref, seconds, self.lease_seconds],
            "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP() AND RECONCILIATION_REF IS NULL AND REQUEST_ARCHIVE_REF IS NULL AND MODEL_RUN_ID IS NULL")

    def record_request(self, permit, archive_ref, seconds):
        if not re.fullmatch('[0-9a-f]{64}', archive_ref or ''):
            raise ValueError('Exact content-addressed request required')
        if type(seconds) is not int or not 10 <= seconds <= 600:
            raise ValueError('Bounded execution deadline required')
        self._change(permit, "REQUEST_ARCHIVE_REF = ?, RUN_DEADLINE = DATEADD('second', ?, CURRENT_TIMESTAMP())",
            [archive_ref, seconds], "STATE = 'HELD' AND REQUEST_ARCHIVE_REF IS NULL")

    def record_run(self, permit, run_id):
        if type(run_id) is not str or not re.fullmatch('[1-9][0-9]{0,18}-[1-9][0-9]{0,18}', run_id):
            raise ValueError('Provider-issued run identity required')
        self._change(permit, 'MODEL_RUN_ID = ?', [run_id], "STATE IN ('HELD','QUARANTINED') AND MODEL_RUN_ID IS NULL")

    def quarantine(self, permit):
        """Atomically transfer uncertain exposure; never increase outstanding calls.

        If the bounded recovery allowance is full, retain the original occupied
        row. Provider unavailability must not permit unbounded detached calls.
        """
        params = self._permit_params(permit)
        with self._transaction() as session:
            rows = self._sql(session, f"SELECT SLOT_ID, FENCE FROM {self._table} "
                "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID > ? "
                "AND STATE = 'FREE' AND OWNER_TOKEN IS NULL ORDER BY SLOT_ID LIMIT 1",
                [self.account_namespace, self.pool_epoch, self.capacity])
            if permit.slot_id > self.capacity or not rows:
                n = _affected(self._sql(session, f"UPDATE {self._table} SET STATE='QUARANTINED', "
                    "NEXT_RECOVERY_AT=CURRENT_TIMESTAMP(), UPDATED_AT=CURRENT_TIMESTAMP() "
                    "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND SLOT_ID=? AND OWNER_TOKEN=? "
                    "AND FENCE=? AND JOB_ID=? AND CALLER_ID=? AND GENERATION=? AND SHARD_ID=? "
                    "AND STATE IN ('HELD','QUARANTINED')", params))
                if n != 1:
                    raise StalePermit('Quarantine ownership changed')
                return
            target = _row(rows[0])
            # Copy before clearing. Conditional target fence AND source identity
            # prevent concurrent handoffs; rollback covers both UPDATEs.
            n = _affected(self._sql(session, f"UPDATE {self._table} t SET "
                "STATE='QUARANTINED', OWNER_TOKEN=s.OWNER_TOKEN, FENCE=t.FENCE+1, JOB_ID=s.JOB_ID, "
                "CALLER_ID=s.CALLER_ID, GENERATION=s.GENERATION, SHARD_ID=s.SHARD_ID, "
                "LEASE_EXPIRES_AT=NULL, RECONCILIATION_REF=s.RECONCILIATION_REF, "
                "DISPATCH_PROTOCOL=s.DISPATCH_PROTOCOL, MODEL_RUN_ID=s.MODEL_RUN_ID, REQUEST_ARCHIVE_REF=s.REQUEST_ARCHIVE_REF, "
                "RUN_DEADLINE=s.RUN_DEADLINE, RECOVERY_ATTEMPTS=0, NEXT_RECOVERY_AT=CURRENT_TIMESTAMP(), "
                "UPDATED_AT=CURRENT_TIMESTAMP(), COMPLETION=s.COMPLETION "
                f"FROM {self._table} s WHERE s.ACCOUNT_NAMESPACE=? AND s.POOL_EPOCH=? AND s.SLOT_ID=? "
                "AND s.OWNER_TOKEN=? AND s.FENCE=? AND s.JOB_ID=? AND s.CALLER_ID=? "
                "AND s.GENERATION=? AND s.SHARD_ID=? AND s.STATE IN ('HELD','QUARANTINED') "
                "AND t.ACCOUNT_NAMESPACE=s.ACCOUNT_NAMESPACE AND t.POOL_EPOCH=s.POOL_EPOCH "
                "AND t.SLOT_ID=? AND t.FENCE=? AND t.STATE='FREE' AND t.OWNER_TOKEN IS NULL",
                params + [target['SLOT_ID'], target['FENCE']]))
            if n != 1:
                raise StalePermit('Recovery handoff contended')
            self._event(session, permit, 'RECOVERY_HANDOFF', {'destination_slot':target['SLOT_ID']})
            n = _affected(self._sql(session, f"UPDATE {self._table} SET STATE='FREE', OWNER_TOKEN=NULL, "
                "FENCE=FENCE+1, LEASE_EXPIRES_AT=NULL, UPDATED_AT=CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND SLOT_ID=? AND OWNER_TOKEN=? "
                "AND FENCE=? AND JOB_ID=? AND CALLER_ID=? AND GENERATION=? AND SHARD_ID=? "
                "AND STATE IN ('HELD','QUARANTINED')", params))
            if n != 1:
                raise StalePermit('Original dispatcher reservation changed')

    def complete(self, permit, completion, *, reconciliation_ref=None):
        from app.core.automap_admission import Completion, _identity
        if type(completion) is not Completion:
            raise ValueError('Explicit terminal evidence required')
        if reconciliation_ref is not None: _identity(reconciliation_ref,'reconciliation_ref')
        params=self._permit_params(permit)
        with self._transaction() as session:
            self._event(session,permit,'TERMINAL_RELEASE',{'completion':completion.value,'evidence_ref':reconciliation_ref})
            n=_affected(self._sql(session,f"UPDATE {self._table} SET STATE='FREE', OWNER_TOKEN=NULL, "
                "FENCE=FENCE+1, LEASE_EXPIRES_AT=NULL, COMPLETION=?, RECONCILIATION_REF=?, UPDATED_AT=CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND SLOT_ID=? AND OWNER_TOKEN=? AND FENCE=? "
                "AND JOB_ID=? AND CALLER_ID=? AND GENERATION=? AND SHARD_ID=? AND STATE IN ('HELD','QUARANTINED')",
                [completion.value,reconciliation_ref]+params))
            if n!=1:raise StalePermit('Terminal release ownership changed')

    def operation(self, slot, fence, identity):
        with self._transaction() as session:
            rows=self._sql(session,f"SELECT * FROM {self._table} WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? "
                "AND SLOT_ID=? AND FENCE=? AND JOB_ID=? AND CALLER_ID=? AND GENERATION=? AND SHARD_ID=? "
                "AND STATE IN ('HELD','QUARANTINED') LIMIT 2",
                [self.account_namespace,self.pool_epoch,slot,fence,identity.job_id,identity.caller_id,identity.generation,identity.shard_id])
            if len(rows)!=1:raise StalePermit('Exact occupied operation not found')
            return self.permit_for(_row(rows[0]))

    def operator_abandon(self, permit, *, actor, reason, retirement_evidence, acknowledge_unknown):
        from app.core.automap_admission import _identity
        if acknowledge_unknown is not True:raise ValueError('Unknown remote outcome acknowledgement required')
        for name,value in [('actor',actor),('reason',reason),('retirement_evidence',retirement_evidence)]:_identity(value,name)
        params=self._permit_params(permit)
        with self._transaction() as session:
            self._event(session,permit,'OPERATOR_ABANDONED',{'actor':actor,'reason':reason,
                'retirement_evidence':retirement_evidence,'remote_outcome':'unknown','still_counted':True})
            n=_affected(self._sql(session,f"UPDATE {self._table} SET STATE='QUARANTINED', "
                "COMPLETION='OPERATOR_ABANDONED', NEXT_RECOVERY_AT=CURRENT_TIMESTAMP(), UPDATED_AT=CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? AND SLOT_ID=? AND OWNER_TOKEN=? AND FENCE=? "
                "AND JOB_ID=? AND CALLER_ID=? AND GENERATION=? AND SHARD_ID=? AND STATE IN ('HELD','QUARANTINED')",params))
            if n!=1:raise StalePermit('Abandonment operation changed')
        # Detach only within the configured uncertainty allowance. No claim of
        # remote completion; never remove unknown calls from the hard ceiling.
        self.quarantine(permit)

    def _event(self, session, permit, action, detail):
        # Audit INSERT shares the exact permit transition transaction. No tokens,
        # model prompts or customer SQL enter the event body.
        body = json.dumps({'slot_id':permit.slot_id,'fence':permit.fence,
            'identity':asdict(permit.identity),'owner_token_digest':hashlib.sha256(permit.owner.encode()).hexdigest(),'action':action,'detail':detail}, separators=(',',':'))
        rows = self._sql(session, f"INSERT INTO {self._table}_EVENTS "
            "(EVENT_ID, ACCOUNT_NAMESPACE, POOL_EPOCH, BODY, CREATED_AT) "
            "SELECT ?, ?, ?, PARSE_JSON(?), CURRENT_TIMESTAMP()",
            [uuid4().hex, self.account_namespace, self.pool_epoch, body])
        receipt={str(k).lower():v for k,v in _row(rows[0]).items()} if len(rows)==1 else {}
        if type(receipt.get('number of rows inserted')) is not int or receipt['number of rows inserted']!=1:
            raise AdmissionInvariantError('Audit append was not acknowledged')

    def recovery_candidates(self, caller_id, limit=4):
        """Internal same-caller lookup; owner capabilities never go to a public API."""
        if not 1 <= limit <= 16:
            raise ValueError('Bounded recovery scan required')
        with self._transaction() as session:
            rows = self._sql(session, f"SELECT * FROM {self._table} WHERE ACCOUNT_NAMESPACE=? "
                "AND POOL_EPOCH=? AND CALLER_ID=? AND STATE IN ('HELD','QUARANTINED') "
                "AND (STATE='QUARANTINED' OR LEASE_EXPIRES_AT<=CURRENT_TIMESTAMP()) "
                "AND (NEXT_RECOVERY_AT IS NULL OR NEXT_RECOVERY_AT<=CURRENT_TIMESTAMP()) "
                "AND (RECOVERY_OWNER IS NULL OR RECOVERY_LEASE_AT<=CURRENT_TIMESTAMP()) "
                f"ORDER BY UPDATED_AT, SLOT_ID LIMIT {limit}",
                [self.account_namespace,self.pool_epoch,caller_id])
            return [_row(row) for row in rows]

    def claim_recovery(self, permit):
        token = uuid4().hex
        try:
            self._change(permit,
                "RECOVERY_OWNER=?, RECOVERY_LEASE_AT=DATEADD('second',180,CURRENT_TIMESTAMP()), "
                "RECOVERY_ATTEMPTS=COALESCE(RECOVERY_ATTEMPTS,0)+1",
                [token], "STATE IN ('HELD','QUARANTINED') AND (STATE='QUARANTINED' OR "
                "LEASE_EXPIRES_AT<=CURRENT_TIMESTAMP()) AND (RECOVERY_OWNER IS NULL OR "
                "RECOVERY_LEASE_AT<=CURRENT_TIMESTAMP())")
        except StalePermit:
            return None
        return token

    def defer_recovery(self, permit, token, reason):
        if type(token) is not str or not re.fullmatch('[0-9a-f]{32}',token):
            raise ValueError('Invalid recovery lease')
        if reason not in {'unknown_outcome','auth_unavailable','missing_archive','active_dispatcher','release_uncertain'}:
            raise ValueError('Invalid safe recovery reason')
        self._change(permit,
            "RECOVERY_OWNER=NULL, RECOVERY_LEASE_AT=NULL, LAST_RECOVERY_REASON=?, "
            "NEXT_RECOVERY_AT=DATEADD('second', LEAST(300,15*POWER(2,LEAST(RECOVERY_ATTEMPTS,5))+UNIFORM(0,5,RANDOM())),CURRENT_TIMESTAMP())",
            [reason], "STATE IN ('HELD','QUARANTINED') AND RECOVERY_OWNER='" + token + "'")

    @staticmethod
    def permit_for(row):
        return Permit(row['ACCOUNT_NAMESPACE'], row['POOL_EPOCH'], row['SLOT_ID'], row['OWNER_TOKEN'], row['FENCE'],
            CallIdentity(row['JOB_ID'],row['CALLER_ID'],row['GENERATION'],row['SHARD_ID']))
