#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="${ENV_FILE:-${ROOT_DIR}/infra/snowflake/env/client.env}"
TOOLS_VENV="${ROOT_DIR}/.client-tools-venv"
SNOW_BIN="${TOOLS_VENV}/bin/snow"
RENDER_SCRIPT="${ROOT_DIR}/scripts/render_spcs_spec.py"
SPEC_TEMPLATE="${ROOT_DIR}/infra/snowflake/service-specs/webapp.yaml.tmpl"
AUTOMAP_SPEC_TEMPLATE="${ROOT_DIR}/infra/snowflake/service-specs/automap-worker.yaml.tmpl"
ARTIFACTS_DIR="${ROOT_DIR}/artifacts/client-spcs"
SKIP_BUILD="false"
SKIP_LOGIN="false"

if git -C "${ROOT_DIR}" rev-parse --short HEAD >/dev/null 2>&1; then
  DEFAULT_IMAGE_TAG="$(git -C "${ROOT_DIR}" rev-parse --short HEAD)"
else
  DEFAULT_IMAGE_TAG="$(date +%Y%m%d%H%M%S)"
fi

IMAGE_TAG="${IMAGE_TAG:-${DEFAULT_IMAGE_TAG}}"

usage() {
  cat <<EOF
Usage: $0 [--env-file path] [--image-tag tag] [--skip-build] [--skip-login]

Deploys the integrated SPCS workbench using Snow CLI with an already configured
Snowflake connection.

This script:
  1. tests the Snow CLI connection
  2. logs Docker into the Snowflake image registry
  3. builds and pushes sttm-builder, frontend, and nginx images
  4. renders the single-service SPCS spec
  5. creates or upgrades the webapp service
  6. lists the public endpoints

Examples:
  $0
  $0 --env-file infra/snowflake/env/client.env --image-tag client-001
  $0 --skip-build
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env-file)
      ENV_FILE="$2"
      shift 2
      ;;
    --image-tag)
      IMAGE_TAG="$2"
      shift 2
      ;;
    --skip-build)
      SKIP_BUILD="true"
      shift
      ;;
    --skip-login)
      SKIP_LOGIN="true"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "ERROR: env file not found: ${ENV_FILE}" >&2
  echo "Copy infra/snowflake/env/client.env.example to client.env and fill it first." >&2
  exit 1
fi

if [[ ! -x "${SNOW_BIN}" ]]; then
  echo "Snow CLI tools are not bootstrapped yet. Running bootstrap script first."
  "${ROOT_DIR}/scripts/bootstrap_client_spcs_tools.sh"
fi

set -a
source "${ENV_FILE}"
set +a

SNOWFLAKE_AUTHENTICATOR="${SNOWFLAKE_AUTHENTICATOR:-}"
SNOWFLAKE_PASSWORD="${SNOWFLAKE_PASSWORD:-}"

if [[ -n "${SNOWFLAKE_PASSWORD}" || "${SNOWFLAKE_AUTHENTICATOR}" == "snowflake" ]]; then
  echo "Refreshing Snow CLI connection '${SNOWFLAKE_CONNECTION:-}' from ${ENV_FILE} for password-based auth"
  "${ROOT_DIR}/scripts/configure_client_snow_connection.sh" --env-file "${ENV_FILE}" --force-recreate
fi

dns_label() {
  printf "%s" "${1:-}" | tr '[:upper:]' '[:lower:]' | tr '_' '-'
}

is_placeholder_name() {
  local value="${1:-}"
  [[ -z "${value}" ]] && return 0
  [[ "${value}" == DB.SCHEMA.* ]] && return 0
  [[ "${value}" == YOUR_DB.YOUR_SCHEMA.* ]] && return 0
  return 1
}

normalize_qualified_name_var() {
  local var_name="$1"
  local current_value="${!var_name:-}"
  if is_placeholder_name "${current_value}"; then
    export "${var_name}="
  fi
}

normalize_auto_mapping_url() {
  local current_value="${AUTO_MAPPING_SERVICE_URL:-}"
  local short_http="http://${AUTO_MAPPING_SERVICE_NAME}:8000"
  local short_https="https://${AUTO_MAPPING_SERVICE_NAME}:8000"
  if [[ -z "${current_value}" || "${current_value}" == "${short_http}" || "${current_value}" == "${short_https}" ]]; then
    export AUTO_MAPPING_SERVICE_URL="http://${AUTO_MAPPING_INTERNAL_HOST}:8000"
  fi
}

grant_role_if_set() {
  local sql_template="$1"
  shift
  local role=""
  local seen="|"
  for role in "$@"; do
    role="${role:-}"
    [[ -z "${role}" ]] && continue
    if [[ "${seen}" == *"|${role}|"* ]]; then
      continue
    fi
    seen="${seen}${role}|"
    "${SNOW_BIN}" sql -c "${SNOWFLAKE_CONNECTION}" -q "${sql_template//__ROLE__/${role}}"
  done
}

grant_caller_dml_if_table_set() {
  local table_name="${1:-}"
  local role_name="${2:-}"
  [[ -z "${table_name}" || -z "${role_name}" ]] && return 0
  if ! "${SNOW_BIN}" sql -c "${SNOWFLAKE_CONNECTION}" -q \
    "GRANT CALLER SELECT ON TABLE ${table_name} TO ROLE ${role_name};"; then
    echo "WARNING: Could not grant caller SELECT on ${table_name} to ${role_name}; continuing." >&2
  fi
  if ! "${SNOW_BIN}" sql -c "${SNOWFLAKE_CONNECTION}" -q \
    "GRANT CALLER INSERT, UPDATE, DELETE, TRUNCATE ON TABLE ${table_name} TO ROLE ${role_name};"; then
    echo "WARNING: Could not grant caller DML on ${table_name} to ${role_name}; continuing." >&2
  fi
}

required_vars=(
  SNOWFLAKE_CONNECTION
  SNOWFLAKE_ACCOUNT
  SNOWFLAKE_USER
  SNOWFLAKE_ROLE
  SNOWFLAKE_WAREHOUSE
  SNOWFLAKE_DATABASE
  SNOWFLAKE_SCHEMA
  SNOWFLAKE_REGISTRY_HOST
  SNOWFLAKE_IMAGE_REPOSITORY
  SNOWFLAKE_COMPUTE_POOL
  WEBAPP_SERVICE_NAME
  AUTO_MAPPING_COMPUTE_POOL
  AUTO_MAPPING_SERVICE_NAME
  SNOWFLAKE_EGRESS_INTEGRATION
  USERS_TABLE
  APP_ROLE_ADMIN
  APP_ROLE_PUBLISHER
  APP_ROLE_VIEWER
  SNOWFLAKE_STTM_BUILDER_AGENT
  SNOWFLAKE_SOURCE_MAPPING_AGENT
)

for var_name in "${required_vars[@]}"; do
  if [[ -z "${!var_name:-}" ]]; then
    echo "ERROR: ${var_name} must be set in ${ENV_FILE}" >&2
    exit 1
  fi
done

APP_NAME="${APP_NAME:-BBI AI Migration Workbench API}"
APP_ENV="${APP_ENV:-client}"
AUTH_MODE="${AUTH_MODE:-custom_oauth}"
SPCS_EXECUTE_AS_CALLER_ENABLED="${SPCS_EXECUTE_AS_CALLER_ENABLED:-true}"
SNOWFLAKE_AGENT_ORCHESTRATION_MODEL="${SNOWFLAKE_AGENT_ORCHESTRATION_MODEL:-claude-sonnet-4}"
SNOWFLAKE_HOST="${SNOWFLAKE_HOST:-}"
SNOWFLAKE_REST_HOST="${SNOWFLAKE_REST_HOST:-$(dns_label "${SNOWFLAKE_ACCOUNT}").snowflakecomputing.com}"
SNOWFLAKE_DATABASE_LOWER="$(printf "%s" "${SNOWFLAKE_DATABASE}" | tr '[:upper:]' '[:lower:]')"
SNOWFLAKE_SCHEMA_LOWER="$(printf "%s" "${SNOWFLAKE_SCHEMA}" | tr '[:upper:]' '[:lower:]')"
AUTO_MAPPING_SERVICE_NAME_LOWER="$(dns_label "${AUTO_MAPPING_SERVICE_NAME}")"
AUTO_MAPPING_SCHEMA_DNS="$(dns_label "${SNOWFLAKE_SCHEMA}")"
AUTO_MAPPING_DATABASE_DNS="$(dns_label "${SNOWFLAKE_DATABASE}")"
AUTO_MAPPING_INTERNAL_HOST="${AUTO_MAPPING_SERVICE_NAME_LOWER}.${AUTO_MAPPING_SCHEMA_DNS}.${AUTO_MAPPING_DATABASE_DNS}.snowflakecomputing.internal"

normalize_qualified_name_var SNOWFLAKE_STTM_BUILDER_AGENT
normalize_qualified_name_var SNOWFLAKE_SOURCE_MAPPING_AGENT
normalize_qualified_name_var SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT
normalize_qualified_name_var SNOWFLAKE_SEMANTIC_MODEL_AGENT
normalize_qualified_name_var SNOWFLAKE_DBT_CONVERSION_AGENT
normalize_qualified_name_var SNOWFLAKE_TEST_CASE_GENERATION_AGENT
normalize_qualified_name_var SNOWFLAKE_RELATIONSHIPS_PROCEDURE
normalize_auto_mapping_url

SNOWFLAKE_SOURCE_MAPPING_AGENT="${SNOWFLAKE_SOURCE_MAPPING_AGENT:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.AGT_SOURCE_MAPPING}"
SNOWFLAKE_SEMANTIC_MODEL_AGENT="${SNOWFLAKE_SEMANTIC_MODEL_AGENT:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.AGT_SEMANTIC_MODEL}"
SNOWFLAKE_DBT_CONVERSION_AGENT="${SNOWFLAKE_DBT_CONVERSION_AGENT:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.AGT_DBT_CONVERSION}"
SNOWFLAKE_TEST_CASE_GENERATION_AGENT="${SNOWFLAKE_TEST_CASE_GENERATION_AGENT:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.AGT_DBT_TEST_GENERATION}"
SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT="${SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT:-${SNOWFLAKE_STTM_BUILDER_AGENT}}"
SNOWFLAKE_RELATIONSHIPS_PROCEDURE="${SNOWFLAKE_RELATIONSHIPS_PROCEDURE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.SP_GET_TABLE_RELATIONSHIPS}"
SNOWFLAKE_SEMANTIC_MODEL_TABLE="${SNOWFLAKE_SEMANTIC_MODEL_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_SEMANTIC_MODELS}"
SNOWFLAKE_SEMANTIC_BUNDLES_TABLE="${SNOWFLAKE_SEMANTIC_BUNDLES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_SEMANTIC_BUNDLES}"
SNOWFLAKE_SEMANTIC_OVERRIDES_TABLE="${SNOWFLAKE_SEMANTIC_OVERRIDES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_SEMANTIC_OVERRIDES}"
SNOWFLAKE_DERIVED_SOURCES_TABLE="${SNOWFLAKE_DERIVED_SOURCES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_DERIVED_SOURCES}"
SNOWFLAKE_OAUTH_SESSIONS_TABLE="${SNOWFLAKE_OAUTH_SESSIONS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_OAUTH_SESSIONS}"
SNOWFLAKE_CONVERSATION_TURNS_TABLE="${SNOWFLAKE_CONVERSATION_TURNS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_CONVERSATION_TURNS}"
SNOWFLAKE_CONVERSATION_FEEDBACK_TABLE="${SNOWFLAKE_CONVERSATION_FEEDBACK_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_FEEDBACK}"
SNOWFLAKE_CONVERSATION_RECOMMENDATIONS_TABLE="${SNOWFLAKE_CONVERSATION_RECOMMENDATIONS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_RECOMMENDATIONS}"
SNOWFLAKE_ASSISTANT_INFERENCES_TABLE="${SNOWFLAKE_ASSISTANT_INFERENCES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_INFERENCES}"
SNOWFLAKE_ASSISTANT_SIGNALS_TABLE="${SNOWFLAKE_ASSISTANT_SIGNALS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_ASSISTANT_SIGNALS}"
SNOWFLAKE_ASSISTANT_SETTINGS_TABLE="${SNOWFLAKE_ASSISTANT_SETTINGS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_ASSISTANT_SETTINGS}"
SNOWFLAKE_RELATIONSHIP_FACTS_TABLE="${SNOWFLAKE_RELATIONSHIP_FACTS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_RELATIONSHIP_FACTS}"
SNOWFLAKE_RAG_DOCUMENTS_TABLE="${SNOWFLAKE_RAG_DOCUMENTS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_RAG_DOCUMENTS}"
SNOWFLAKE_CLIENT_NOTES_TABLE="${SNOWFLAKE_CLIENT_NOTES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_CLIENT_NOTES}"
SNOWFLAKE_CLIENT_SQL_ASSETS_TABLE="${SNOWFLAKE_CLIENT_SQL_ASSETS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_CLIENT_SQL_ASSETS}"
SNOWFLAKE_FIR_EVENTS_TABLE="${SNOWFLAKE_FIR_EVENTS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_FIR_EVENTS}"
SNOWFLAKE_FIR_FEATURES_TABLE="${SNOWFLAKE_FIR_FEATURES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_FIR_FEATURES}"
SNOWFLAKE_MAPPING_INTENTS_TABLE="${SNOWFLAKE_MAPPING_INTENTS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_MAPPING_INTENTS}"
SNOWFLAKE_SEMANTIC_LEARNINGS_TABLE="${SNOWFLAKE_SEMANTIC_LEARNINGS_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_SEMANTIC_LEARNINGS}"
SNOWFLAKE_FIR_MODEL_SCORES_TABLE="${SNOWFLAKE_FIR_MODEL_SCORES_TABLE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.TBL_WORKBENCH_FIR_MODEL_SCORES}"
SNOWFLAKE_RAG_SEARCH_SERVICE="${SNOWFLAKE_RAG_SEARCH_SERVICE:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.CSS_WORKBENCH_RAG}"
CORS_ALLOWED_ORIGINS="${CORS_ALLOWED_ORIGINS:-}"
AUTO_MAPPING_SERVICE_URL="${AUTO_MAPPING_SERVICE_URL:-http://${AUTO_MAPPING_INTERNAL_HOST}:8000}"
AUTO_MAPPING_SERVICE_TIMEOUT_SECONDS="${AUTO_MAPPING_SERVICE_TIMEOUT_SECONDS:-300}"
AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS="${AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS:-2}"
AUTO_MAPPING_WORKER_MAX_CONCURRENCY="${AUTO_MAPPING_WORKER_MAX_CONCURRENCY:-5}"
AUTO_MAPPING_PROXY_BATCH_SIZE="${AUTO_MAPPING_PROXY_BATCH_SIZE:-17}"
AUTO_MAPPING_PROXY_MAX_IN_FLIGHT="${AUTO_MAPPING_PROXY_MAX_IN_FLIGHT:-2}"
SNOWFLAKE_SESSION_RETRY_ATTEMPTS="${SNOWFLAKE_SESSION_RETRY_ATTEMPTS:-2}"
SNOWFLAKE_SESSION_RETRY_BACKOFF_SECONDS="${SNOWFLAKE_SESSION_RETRY_BACKOFF_SECONDS:-1.0}"
SNOWFLAKE_USER_SESSION_CACHE_TTL_SECONDS="${SNOWFLAKE_USER_SESSION_CACHE_TTL_SECONDS:-1800}"
SNOWFLAKE_AGENT_RETRY_ATTEMPTS="${SNOWFLAKE_AGENT_RETRY_ATTEMPTS:-3}"
SNOWFLAKE_AGENT_RETRY_BACKOFF_SECONDS="${SNOWFLAKE_AGENT_RETRY_BACKOFF_SECONDS:-1.0}"
SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT="${SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.STTM_BUILDER_OAUTH_CLIENT_CREDENTIALS}"
SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT="${SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT:-${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.STTM_BUILDER_OAUTH_SESSION_KEYS}"
SNOWFLAKE_OAUTH_AUTHORIZE_URL="${SNOWFLAKE_OAUTH_AUTHORIZE_URL:-}"
SNOWFLAKE_OAUTH_TOKEN_URL="${SNOWFLAKE_OAUTH_TOKEN_URL:-}"
SNOWFLAKE_OAUTH_REDIRECT_URI="${SNOWFLAKE_OAUTH_REDIRECT_URI:-}"
SNOWFLAKE_OAUTH_SCOPE="${SNOWFLAKE_OAUTH_SCOPE:-session:role-any}"
AUTH_SESSION_SECRET="${AUTH_SESSION_SECRET:-}"
AUTH_SESSION_ENCRYPTION_KEY="${AUTH_SESSION_ENCRYPTION_KEY:-}"
AUTH_SESSION_COOKIE_NAME="${AUTH_SESSION_COOKIE_NAME:-sttm_session}"
AUTH_STATE_COOKIE_NAME="${AUTH_STATE_COOKIE_NAME:-sttm_oauth_state}"
AUTH_SESSION_COOKIE_SECURE="${AUTH_SESSION_COOKIE_SECURE:-true}"
AUTH_SESSION_COOKIE_SAMESITE="${AUTH_SESSION_COOKIE_SAMESITE:-lax}"
AUTH_POST_LOGIN_REDIRECT_PATH="${AUTH_POST_LOGIN_REDIRECT_PATH:-/dashboard}"
AUTH_POST_LOGOUT_REDIRECT_PATH="${AUTH_POST_LOGOUT_REDIRECT_PATH:-/home}"
SPCS_ENABLE_CUSTOM_CREDENTIALS="false"
SNOWFLAKE_OAUTH_SECRET_MAPPINGS=""

if [[ "${AUTH_MODE}" == "custom_oauth" ]]; then
  SPCS_ENABLE_CUSTOM_CREDENTIALS="true"
  AUTH_SESSION_COOKIE_SECURE="true"
  oauth_required_vars=(
    SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT
    SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT
    SNOWFLAKE_OAUTH_AUTHORIZE_URL
    SNOWFLAKE_OAUTH_TOKEN_URL
    SNOWFLAKE_OAUTH_REDIRECT_URI
  )
  for var_name in "${oauth_required_vars[@]}"; do
    if [[ -z "${!var_name:-}" ]]; then
      echo "ERROR: ${var_name} must be set in ${ENV_FILE} when AUTH_MODE=custom_oauth" >&2
      exit 1
    fi
  done
  SNOWFLAKE_OAUTH_SECRET_MAPPINGS="$(printf '%s\n' \
    '      secrets:' \
    "        - snowflakeSecret: ${SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT}" \
    '          secretKeyRef: username' \
    '          envVarName: SNOWFLAKE_OAUTH_CLIENT_ID' \
    "        - snowflakeSecret: ${SNOWFLAKE_OAUTH_CLIENT_SECRET_OBJECT}" \
    '          secretKeyRef: password' \
    '          envVarName: SNOWFLAKE_OAUTH_CLIENT_SECRET' \
    "        - snowflakeSecret: ${SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT}" \
    '          secretKeyRef: username' \
    '          envVarName: AUTH_SESSION_SECRET' \
    "        - snowflakeSecret: ${SNOWFLAKE_OAUTH_SESSION_SECRET_OBJECT}" \
    '          secretKeyRef: password' \
    '          envVarName: AUTH_SESSION_ENCRYPTION_KEY')"
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: docker is required but was not found in PATH." >&2
  exit 1
fi

echo "Testing Snow CLI connection '${SNOWFLAKE_CONNECTION}'"
"${SNOW_BIN}" connection test -c "${SNOWFLAKE_CONNECTION}"

echo
echo "Ensuring compute pool '${SNOWFLAKE_COMPUTE_POOL}' exists"
"${SNOW_BIN}" sql -c "${SNOWFLAKE_CONNECTION}" -q \
  "CREATE COMPUTE POOL IF NOT EXISTS ${SNOWFLAKE_COMPUTE_POOL} MIN_NODES = 1 MAX_NODES = 1 INSTANCE_FAMILY = CPU_X64_S AUTO_RESUME = TRUE AUTO_SUSPEND_SECS = 3600;"

echo
echo "Ensuring compute pool '${AUTO_MAPPING_COMPUTE_POOL}' exists"
"${SNOW_BIN}" sql -c "${SNOWFLAKE_CONNECTION}" -q \
  "CREATE COMPUTE POOL IF NOT EXISTS ${AUTO_MAPPING_COMPUTE_POOL} MIN_NODES = 2 MAX_NODES = 2 INSTANCE_FAMILY = CPU_X64_S AUTO_RESUME = TRUE AUTO_SUSPEND_SECS = 3600;"

if [[ "${SKIP_LOGIN}" != "true" ]]; then
  echo "Logging Docker into Snowflake image registry via Snow CLI"
  "${SNOW_BIN}" spcs image-registry login -c "${SNOWFLAKE_CONNECTION}"
else
  echo "Skipping image-registry login"
fi

export SNOWFLAKE_DATABASE_LOWER="$(printf "%s" "${SNOWFLAKE_DATABASE}" | tr '[:upper:]' '[:lower:]')"
export SNOWFLAKE_SCHEMA_LOWER="$(printf "%s" "${SNOWFLAKE_SCHEMA}" | tr '[:upper:]' '[:lower:]')"
export SNOWFLAKE_IMAGE_REPOSITORY_LOWER="$(printf "%s" "${SNOWFLAKE_IMAGE_REPOSITORY}" | tr '[:upper:]' '[:lower:]')"
export AUTO_MAPPING_SERVICE_NAME_LOWER
export IMAGE_TAG
export APP_NAME
export APP_ENV
export AUTH_MODE
export SPCS_EXECUTE_AS_CALLER_ENABLED
export SNOWFLAKE_REST_HOST
export USERS_TABLE
export SNOWFLAKE_OAUTH_SESSIONS_TABLE
export APP_ROLE_ADMIN
export APP_ROLE_PUBLISHER
export APP_ROLE_VIEWER
export SNOWFLAKE_OAUTH_AUTHORIZE_URL
export SNOWFLAKE_OAUTH_TOKEN_URL
export SNOWFLAKE_OAUTH_REDIRECT_URI
export SNOWFLAKE_OAUTH_SCOPE
export AUTH_SESSION_COOKIE_NAME
export AUTH_STATE_COOKIE_NAME
export AUTH_SESSION_COOKIE_SECURE
export AUTH_SESSION_COOKIE_SAMESITE
export AUTH_POST_LOGIN_REDIRECT_PATH
export AUTH_POST_LOGOUT_REDIRECT_PATH
export SPCS_ENABLE_CUSTOM_CREDENTIALS
export SNOWFLAKE_OAUTH_SECRET_MAPPINGS
export SNOWFLAKE_WAREHOUSE
export SNOWFLAKE_DATABASE
export SNOWFLAKE_SCHEMA
export SNOWFLAKE_STTM_BUILDER_AGENT
export SNOWFLAKE_SOURCE_MAPPING_AGENT
export SNOWFLAKE_WORKBENCH_CONVERSATION_AGENT
export SNOWFLAKE_SEMANTIC_MODEL_AGENT
export SNOWFLAKE_DBT_CONVERSION_AGENT
export SNOWFLAKE_TEST_CASE_GENERATION_AGENT
export SNOWFLAKE_RELATIONSHIPS_PROCEDURE
export SNOWFLAKE_SEMANTIC_MODEL_TABLE
export SNOWFLAKE_DERIVED_SOURCES_TABLE
export SNOWFLAKE_CONVERSATION_TURNS_TABLE
export SNOWFLAKE_CONVERSATION_FEEDBACK_TABLE
export SNOWFLAKE_CONVERSATION_RECOMMENDATIONS_TABLE
export SNOWFLAKE_RELATIONSHIP_FACTS_TABLE
export SNOWFLAKE_RAG_DOCUMENTS_TABLE
export SNOWFLAKE_RAG_SEARCH_SERVICE
export SNOWFLAKE_AGENT_ORCHESTRATION_MODEL
export CORS_ALLOWED_ORIGINS
export AUTO_MAPPING_SERVICE_URL
export AUTO_MAPPING_SERVICE_TIMEOUT_SECONDS
export AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS
export AUTO_MAPPING_WORKER_MAX_CONCURRENCY
export AUTO_MAPPING_PROXY_BATCH_SIZE
export AUTO_MAPPING_PROXY_MAX_IN_FLIGHT
export SNOWFLAKE_SESSION_RETRY_ATTEMPTS
export SNOWFLAKE_SESSION_RETRY_BACKOFF_SECONDS
export SNOWFLAKE_USER_SESSION_CACHE_TTL_SECONDS
export SNOWFLAKE_AGENT_RETRY_ATTEMPTS
export SNOWFLAKE_AGENT_RETRY_BACKOFF_SECONDS

REGISTRY_BASE="${SNOWFLAKE_REGISTRY_HOST}/${SNOWFLAKE_DATABASE_LOWER}/${SNOWFLAKE_SCHEMA_LOWER}/${SNOWFLAKE_IMAGE_REPOSITORY_LOWER}"

build_and_push() {
  local name="$1"
  local context_dir="$2"
  local remote_image="${REGISTRY_BASE}/${name}:${IMAGE_TAG}"

  echo
  echo "Building ${name} -> ${remote_image}"
  docker build --platform linux/amd64 -t "${remote_image}" "${context_dir}"
  echo "Pushing ${remote_image}"
  docker push "${remote_image}"
}

if [[ "${SKIP_BUILD}" != "true" ]]; then
  build_and_push "sttm-builder" "${ROOT_DIR}/services/sttm-builder"
  build_and_push "sttm-automap-worker" "${ROOT_DIR}/services/sttm-builder"
  build_and_push "frontend" "${ROOT_DIR}/frontend"
  build_and_push "nginx" "${ROOT_DIR}/nginx"
else
  echo "Skipping Docker build/push"
fi

mkdir -p "${ARTIFACTS_DIR}"
RENDERED_SPEC="${ARTIFACTS_DIR}/webapp.${IMAGE_TAG}.yaml"
AUTOMAP_RENDERED_SPEC="${ARTIFACTS_DIR}/automap-worker.${IMAGE_TAG}.yaml"

echo
echo "Rendering service spec to ${RENDERED_SPEC}"
python3 "${RENDER_SCRIPT}" --template "${SPEC_TEMPLATE}" --output "${RENDERED_SPEC}"

echo
echo "Rendering auto-mapping worker spec to ${AUTOMAP_RENDERED_SPEC}"
python3 "${RENDER_SCRIPT}" --template "${AUTOMAP_SPEC_TEMPLATE}" --output "${AUTOMAP_RENDERED_SPEC}"

echo
echo "Creating service '${WEBAPP_SERVICE_NAME}' if needed"
"${SNOW_BIN}" spcs service create "${WEBAPP_SERVICE_NAME}" \
  --connection "${SNOWFLAKE_CONNECTION}" \
  --database "${SNOWFLAKE_DATABASE}" \
  --schema "${SNOWFLAKE_SCHEMA}" \
  --role "${SNOWFLAKE_ROLE}" \
  --warehouse "${SNOWFLAKE_WAREHOUSE}" \
  --compute-pool "${SNOWFLAKE_COMPUTE_POOL}" \
  --spec-path "${RENDERED_SPEC}" \
  --eai-name "${SNOWFLAKE_EGRESS_INTEGRATION}" \
  --if-not-exists \
  --format TABLE

echo
echo "Upgrading service '${WEBAPP_SERVICE_NAME}' to the latest spec"
"${SNOW_BIN}" spcs service upgrade "${WEBAPP_SERVICE_NAME}" \
  --connection "${SNOWFLAKE_CONNECTION}" \
  --database "${SNOWFLAKE_DATABASE}" \
  --schema "${SNOWFLAKE_SCHEMA}" \
  --role "${SNOWFLAKE_ROLE}" \
  --warehouse "${SNOWFLAKE_WAREHOUSE}" \
  --spec-path "${RENDERED_SPEC}" \
  --format TABLE

echo
echo "Listing service endpoints"
"${SNOW_BIN}" spcs service list-endpoints "${WEBAPP_SERVICE_NAME}" \
  --connection "${SNOWFLAKE_CONNECTION}" \
  --database "${SNOWFLAKE_DATABASE}" \
  --schema "${SNOWFLAKE_SCHEMA}" \
  --role "${SNOWFLAKE_ROLE}" \
  --warehouse "${SNOWFLAKE_WAREHOUSE}" \
  --format TABLE

echo
echo "Creating auto-mapping worker service '${AUTO_MAPPING_SERVICE_NAME}' if needed"
"${SNOW_BIN}" spcs service create "${AUTO_MAPPING_SERVICE_NAME}" \
  --connection "${SNOWFLAKE_CONNECTION}" \
  --database "${SNOWFLAKE_DATABASE}" \
  --schema "${SNOWFLAKE_SCHEMA}" \
  --role "${SNOWFLAKE_ROLE}" \
  --warehouse "${SNOWFLAKE_WAREHOUSE}" \
  --compute-pool "${AUTO_MAPPING_COMPUTE_POOL}" \
  --spec-path "${AUTOMAP_RENDERED_SPEC}" \
  --eai-name "${SNOWFLAKE_EGRESS_INTEGRATION}" \
  --if-not-exists \
  --format TABLE

echo
echo "Upgrading auto-mapping worker service '${AUTO_MAPPING_SERVICE_NAME}' to the latest spec"
"${SNOW_BIN}" spcs service upgrade "${AUTO_MAPPING_SERVICE_NAME}" \
  --connection "${SNOWFLAKE_CONNECTION}" \
  --database "${SNOWFLAKE_DATABASE}" \
  --schema "${SNOWFLAKE_SCHEMA}" \
  --role "${SNOWFLAKE_ROLE}" \
  --warehouse "${SNOWFLAKE_WAREHOUSE}" \
  --spec-path "${AUTOMAP_RENDERED_SPEC}" \
  --format TABLE

echo
echo "Pinning auto-mapping worker scale to min=2 max=2"
"${SNOW_BIN}" sql -c "${SNOWFLAKE_CONNECTION}" -q \
  "ALTER SERVICE IF EXISTS ${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.${AUTO_MAPPING_SERVICE_NAME} SET MIN_INSTANCES=2, MAX_INSTANCES=2;"

echo
echo "Applying caller-role grants"
grant_role_if_set \
  "GRANT SERVICE ROLE ${AUTO_MAPPING_SERVICE_NAME}!backend_access TO ROLE __ROLE__;" \
  "${SNOWFLAKE_ROLE}" \
  "${APP_ROLE_ADMIN}" \
  "${APP_ROLE_PUBLISHER}" \
  "${APP_ROLE_VIEWER}"
grant_role_if_set \
  "GRANT USAGE ON PROCEDURE ${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.SP_GET_TABLE_RELATIONSHIPS(VARCHAR, VARCHAR, VARCHAR) TO ROLE __ROLE__;" \
  "${SNOWFLAKE_ROLE}" \
  "${APP_ROLE_ADMIN}" \
  "${APP_ROLE_PUBLISHER}" \
  "${APP_ROLE_VIEWER}"
grant_role_if_set \
  "GRANT CALLER USAGE ON PROCEDURE ${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}.SP_GET_TABLE_RELATIONSHIPS(VARCHAR, VARCHAR, VARCHAR) TO ROLE __ROLE__;" \
  "${SNOWFLAKE_ROLE}"
for table_name in \
  "${SNOWFLAKE_SEMANTIC_BUNDLES_TABLE}" \
  "${SNOWFLAKE_SEMANTIC_OVERRIDES_TABLE}" \
  "${SNOWFLAKE_DERIVED_SOURCES_TABLE}" \
  "${SNOWFLAKE_CONVERSATION_TURNS_TABLE}" \
  "${SNOWFLAKE_CONVERSATION_FEEDBACK_TABLE}" \
  "${SNOWFLAKE_CONVERSATION_RECOMMENDATIONS_TABLE}" \
  "${SNOWFLAKE_ASSISTANT_INFERENCES_TABLE}" \
  "${SNOWFLAKE_ASSISTANT_SIGNALS_TABLE}" \
  "${SNOWFLAKE_ASSISTANT_SETTINGS_TABLE}" \
  "${SNOWFLAKE_RELATIONSHIP_FACTS_TABLE}" \
  "${SNOWFLAKE_RAG_DOCUMENTS_TABLE}" \
  "${SNOWFLAKE_CLIENT_NOTES_TABLE}" \
  "${SNOWFLAKE_CLIENT_SQL_ASSETS_TABLE}" \
  "${SNOWFLAKE_FIR_EVENTS_TABLE}" \
  "${SNOWFLAKE_FIR_FEATURES_TABLE}" \
  "${SNOWFLAKE_MAPPING_INTENTS_TABLE}" \
  "${SNOWFLAKE_SEMANTIC_LEARNINGS_TABLE}" \
  "${SNOWFLAKE_FIR_MODEL_SCORES_TABLE}"; do
  grant_caller_dml_if_table_set "${table_name}" "${SNOWFLAKE_ROLE}"
done

echo
echo "Listing auto-mapping worker endpoints"
"${SNOW_BIN}" spcs service list-endpoints "${AUTO_MAPPING_SERVICE_NAME}" \
  --connection "${SNOWFLAKE_CONNECTION}" \
  --database "${SNOWFLAKE_DATABASE}" \
  --schema "${SNOWFLAKE_SCHEMA}" \
  --role "${SNOWFLAKE_ROLE}" \
  --warehouse "${SNOWFLAKE_WAREHOUSE}" \
  --format TABLE

echo
echo "Deployment complete."
echo "Rendered spec: ${RENDERED_SPEC}"
echo "Auto-mapping worker spec: ${AUTOMAP_RENDERED_SPEC}"
echo "Next checks:"
echo "  1. snow spcs service status ${WEBAPP_SERVICE_NAME} -c ${SNOWFLAKE_CONNECTION} --database ${SNOWFLAKE_DATABASE} --schema ${SNOWFLAKE_SCHEMA}"
echo "  2. snow spcs service list-containers ${WEBAPP_SERVICE_NAME} -c ${SNOWFLAKE_CONNECTION} --database ${SNOWFLAKE_DATABASE} --schema ${SNOWFLAKE_SCHEMA}"
echo "  3. snow spcs service status ${AUTO_MAPPING_SERVICE_NAME} -c ${SNOWFLAKE_CONNECTION} --database ${SNOWFLAKE_DATABASE} --schema ${SNOWFLAKE_SCHEMA}"
echo "  4. Open the public endpoint from the command output and verify Snowflake sign-in"
