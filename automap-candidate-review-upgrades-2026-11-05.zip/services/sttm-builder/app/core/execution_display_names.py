"""Display metadata is distinct from the source references accepted by execution."""
from collections import Counter


def execution_display_names(context):
    nodes = (context.get('relation_graph') or {}).get('nodes') or []
    authored = {str(item.get('id')): item.get('name') for item in
                (context.get('workspace_context') or {}).get('derived_sources') or []}
    counts = Counter((node.get('table') or {}).get('table') for node in nodes if node.get('table'))
    records = []
    for node in nodes:
        table = node.get('table') or {}
        name = table.get('table') or node.get('original_cte_name') or authored.get(str(node.get('relation_id'))) or node.get('alias')
        if table and counts[table.get('table')] > 1:
            name = f"{name} ({node.get('alias')})"
        records.append({'relation_id': node.get('relation_id'), 'execution_alias': node.get('alias'),
                        'display_name': name, 'qualified_table': '.'.join(str(table.get(key) or '') for key in ('database','schema','table')) if table else None})
    return {'instruction': 'Use display_name in explanations. Structured source references, dependencies, citations and SQL must keep exact execution_alias/relation_id bindings. Never substitute a display name into executable SQL.',
            'relations': records}
