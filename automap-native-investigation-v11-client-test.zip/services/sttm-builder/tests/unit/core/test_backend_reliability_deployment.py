import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest
import yaml


ROOT = Path(__file__).resolve().parents[5]


@pytest.mark.skipif(not (ROOT/'infra/snowflake/env/client.env').is_file(), reason='Authoritative client.env is external; validate this deployment gate on the client AVD.')
def test_uat_pins_durable_pipeline_and_canonical_registry():
    from dotenv import dotenv_values
    from scripts.render_spcs_spec import PARALLEL_DEFAULTS, _OPTIONAL_TEMPLATE_DEFAULTS, render_template
    environment = dict(dotenv_values(ROOT / 'infra/snowflake/env/client.env', interpolate=False))
    assert environment['SNOWFLAKE_DATABASE'] == 'FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT'
    assert environment['AUTO_MAP_PIPELINE_V2'] == 'true'
    assert environment['SNOWFLAKE_SCHEMA'] == 'SCH_STTM_METADATA'
    assert environment['SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA'] == 'SCH_STTM_MCP'
    for name in ('webapp.yaml.tmpl', 'automap-worker.yaml.tmpl'):
        raw = (ROOT / 'infra/snowflake/service-specs' / name).read_text()
        values = {key: 'test-value' for key in re.findall(r'\$\{([A-Z][A-Z0-9_]*)\}', raw)}
        values.update(_OPTIONAL_TEMPLATE_DEFAULTS)  # Use valid defaults for settings absent from UAT.
        values.update(environment)
        values.update(PARALLEL_DEFAULTS)  # New rollout settings must stay valid and off.
        values['IMAGE_TAG'] = 'test-release'
        values['SNOWFLAKE_OAUTH_SECRET_MAPPINGS'] = ''
        values['COCO_SIDECAR_ENABLED'] = 'false'
        spec = yaml.safe_load(render_template(raw, values))
        runtime = spec['spec']['containers'][0]['env']
        assert runtime['SNOWFLAKE_DATABASE'] == 'FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT'
        assert runtime['SNOWFLAKE_SCHEMA'] == 'SCH_STTM_METADATA'
        assert runtime['SNOWFLAKE_SEMANTIC_VIEWS_SCHEMA'] == 'SCH_STTM_MCP'
        assert runtime['SNOWFLAKE_SEMANTIC_TABLE_VIEWS_TABLE'] == 'SEM_TABLE_REGISTRY'
        assert runtime['SNOWFLAKE_SEMANTIC_COLUMN_VIEWS_TABLE'] == 'SEM_COLUMN_REGISTRY'
        assert runtime['SNOWFLAKE_SEMANTIC_NATIVE_VIEWS_TABLE'] == 'SEM_NATIVE_VIEWS'
        assert runtime['AGENT_OUTBOUND_MESSAGE_MAX_CHARS'] == environment['AGENT_OUTBOUND_MESSAGE_MAX_CHARS']
        assert 2048 <= int(runtime['AGENT_OUTBOUND_MESSAGE_MAX_CHARS']) <= 180000
        if name == 'webapp.yaml.tmpl':
            assert runtime['AGENT_REQUEST_SCOPED_ANALYST_V1'] == 'false'
            assert runtime['AUTO_MAP_PIPELINE_V2'] == 'true'



def _uat_workflow():
    # BaseLoader preserves GitHub's `on` key instead of treating it as YAML 1.1 True.
    return yaml.load(
        (ROOT / '.github/workflows/pipeline-ai-migration-uat.yml').read_text(encoding='utf-8'),
        Loader=yaml.BaseLoader,
    )


def test_uat_workflow_guards_dispatch_and_push_at_job_level():
    workflow = _uat_workflow()
    assert workflow['on']['push']['branches'] == ['UAT']
    assert 'workflow_dispatch' in workflow['on']
    assert workflow['jobs']['deploy-workbench']['if'] == "github.ref == 'refs/heads/UAT'"


def test_uat_destination_guard_precedes_credentials_bootstrap_and_deploy():
    steps = _uat_workflow()['jobs']['deploy-workbench']['steps']
    names = [step['name'] for step in steps]
    guard_index = names.index('Guardrail: Require UAT deployment destinations')
    guard = steps[guard_index]
    assert guard['shell'] == 'pwsh'
    assert 'if' not in guard
    assert guard.get('continue-on-error', 'false') == 'false'
    for name in (
        'Guardrail: Confirm required secrets are present',
        'Configure Snow CLI Connection',
        'Validate parallel UAT profile and render before provisioning',
        'Provision and validate parallel UAT infrastructure in order',
        'Deploy Single-Service SPCS Webapp',
    ):
        assert guard_index < names.index(name)


@pytest.mark.parametrize('changed_key,replacement', [
    (None, None),
    ('SNOWFLAKE_DATABASE', 'FFP_HDP_DLAB_DB_DEV'),
    ('SNOWFLAKE_ROLE', 'FFP_HDP_DLAB_MIG_WORKBENCH_DB_DEPLOY_ROLE_DEV'),
    ('SNOWFLAKE_SCHEMA', 'UNAPPROVED_SCHEMA'),
    ('SNOWFLAKE_ACCOUNT', 'MHSUEJT-GD01711'),
    ('SNOWFLAKE_ACCOUNT', 'mhsuejt-ffp_hdp_snow_account_prod'),
    *[(key, value) for key in ('SNOWFLAKE_DATABASE', 'SNOWFLAKE_SCHEMA', 'SNOWFLAKE_ROLE', 'SNOWFLAKE_ACCOUNT')
      for value in (None, '')],
], ids=['approved-uat', 'reject-dev-database', 'reject-dev-role', 'reject-other-schema',
        'reject-dev-account', 'reject-nonexact-account',
        'missing-database', 'blank-database', 'missing-schema', 'blank-schema',
        'missing-role', 'blank-role', 'missing-account', 'blank-account'])
def test_uat_destination_guard_accepts_only_allowlisted_settings(tmp_path, changed_key, replacement):
    settings = {
        'SNOWFLAKE_ACCOUNT': 'MHSUEJT-FFP_HDP_SNOW_ACCOUNT_PROD',
        'SNOWFLAKE_DATABASE': 'FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT',
        'SNOWFLAKE_SCHEMA': 'SCH_STTM_METADATA',
        'SNOWFLAKE_ROLE': 'FFP_HDP_DLAB_MIG_WORKBENCH_DB_DEPLOY_ROLE_UAT',
    }
    if changed_key is not None:
        if replacement is None:
            del settings[changed_key]
        else:
            settings[changed_key] = replacement
    # Only synthetic, non-secret destinations; never read a local client profile.
    env_file = tmp_path / 'synthetic-destinations.env'
    env_file.write_text(
        '# Synthetic guard input\n' + ''.join(f'  {key} = "{value}"  \n' for key, value in settings.items()),
        encoding='utf-8',
    )
    steps = _uat_workflow()['jobs']['deploy-workbench']['steps']
    guard = next(step for step in steps if step['name'] == 'Guardrail: Require UAT deployment destinations')
    powershell = shutil.which('pwsh') or shutil.which('powershell')
    assert powershell is not None, 'PowerShell is required to exercise the actual workflow guard'
    # Execute only the checked-in guard, not any setup, credential, or deployment step.
    command = 'try {\n' + guard['run'] + '\n} catch {\n[Console]::Error.WriteLine($_.Exception.Message)\nexit 1\n}\nexit 0'
    environment = {key: value for key, value in os.environ.items()
                   if key.upper() in {'SYSTEMROOT', 'WINDIR', 'PATH', 'TEMP', 'TMP'}}
    environment['ENV_FILE'] = str(env_file)
    result = subprocess.run(
        [powershell, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', command],
        cwd=ROOT, env=environment, capture_output=True, text=True, timeout=30,
    )
    if changed_key is None:
        assert result.returncode == 0, result.stdout + result.stderr
        assert 'UAT deployment refused' not in result.stdout + result.stderr
    else:
        assert result.returncode != 0, result.stdout + result.stderr
        assert f'UAT deployment refused: {changed_key} is not the approved UAT destination.' in result.stderr


def test_semantic_version_uses_insert_select_for_json_binds() -> None:
    sql = (
        ROOT
        / "infra/snowflake/fir_system/procedures/sp-fir-create-semantic-version.sql"
    ).read_text()
    insert = sql[sql.index("INSERT INTO __STTM_METADATA_NAMESPACE__.TBL_SEMANTIC_VIEW_VERSIONS") :]
    assert ") SELECT" in insert
    assert ") VALUES" not in insert
    assert "PARSE_JSON(?)" in insert


def test_uat_powershell_renderer_exports_every_service_placeholder() -> None:
    # UAT uses the preserved single-service deployer, not DEV's safe variant.
    steps = _uat_workflow()['jobs']['deploy-workbench']['steps']
    deploy = next(step for step in steps if step['name'] == 'Deploy Single-Service SPCS Webapp')
    assert './scripts/deploy_spcs_client_snow_single_service.ps1' in deploy['run']
    script = (ROOT / "scripts/deploy_spcs_client_snow_single_service.ps1").read_text()
    exported = set(re.findall(r"\$env:([A-Z][A-Z0-9_]*)\s*=", script))
    from scripts.render_spcs_spec import _OPTIONAL_TEMPLATE_DEFAULTS
    exported.update(_OPTIONAL_TEMPLATE_DEFAULTS)
    for relative in (
        "infra/snowflake/service-specs/webapp.yaml.tmpl",
        "infra/snowflake/service-specs/automap-worker.yaml.tmpl",
    ):
        template = (ROOT / relative).read_text()
        placeholders = set(re.findall(r"\$\{([A-Z][A-Z0-9_]*)\}", template))
        assert placeholders <= exported, sorted(placeholders - exported)


def test_uat_supported_spcs_renderers_supply_catalog_cache_configuration() -> None:
    # The inactive protected safe deployer predates these cache exports in UAT.
    # Do not replace it with DEV's version merely to satisfy this contract.
    required = {
        "TABLE_SELECTION_CACHE_SECONDS",
        "TABLE_SELECTION_STALE_IF_ERROR_SECONDS",
    }
    for relative in (
        "scripts/deploy_spcs_client_snow.sh",
        "scripts/deploy_spcs_client_direct.sh",
        "scripts/deploy_spcs_client_snow.ps1",
        "scripts/deploy_spcs_client_snow_single_service.ps1",
        "deploy_bbi_workbench_v2.sh",
    ):
        script = (ROOT / relative).read_text()
        assert required <= set(re.findall(r"TABLE_SELECTION_[A-Z_]+", script)), relative


def test_spcs_proxy_buffers_json_but_not_agent_streams() -> None:
    config = (ROOT / "nginx/conf.d/default.conf").read_text()
    stream_location = config[
        config.index("location ~ ^/api/v1/") : config.index("location /api/")
    ]
    json_location = config[
        config.index("location /api/") : config.index("location /_next/static/")
    ]
    assert "proxy_buffering off;" in stream_location
    assert "gzip off;" in stream_location
    assert "proxy_buffering on;" in json_location
    assert "proxy_set_header Connection \"\";" in json_location


def test_uat_supported_deploy_defaults_use_adaptive_sixteen_target_batches() -> None:
    # UAT's inactive protected safe deployer retains its legacy batch default.
    files = (
        "infra/snowflake/env/client.env.example",
        "scripts/deploy_spcs_client_snow.sh",
        "scripts/deploy_spcs_client_snow.ps1",
        "scripts/deploy_spcs_client_snow_single_service.ps1",
        "deploy_bbi_workbench_v2.sh",
    )
    for relative in files:
        content = (ROOT / relative).read_text()
        defaults = [
            line
            for line in content.splitlines()
            if "AUTO_MAPPING_PROXY_BATCH_SIZE" in line and "=" in line
        ]
        assert any(re.search(r"(?<!\d)16(?!\d)", line) for line in defaults), relative


def test_spcs_entrypoints_enable_warm_parallel_runtime_defaults() -> None:
    scripts = (
        "scripts/deploy_spcs_client_snow.sh",
        "scripts/deploy_spcs_client_snow.ps1",
        "scripts/deploy_spcs_client_snow_safe.ps1",
        "scripts/deploy_spcs_client_snow_single_service.ps1",
        "deploy_bbi_workbench_v2.sh",
    )
    required = (
        "SNOWFLAKE_SESSION_LEASE_POOL_V1",
        "LEARNING_PARALLEL_V1",
        "PREPARE_PARALLEL_V1",
        "AUTOSAVE_POSTSAVE_ASYNC_V1",
        "PREPARATION_WAREHOUSE_ROUTING_V1",
        "SNOWFLAKE_PREPARATION_WAREHOUSE",
    )
    for relative in scripts:
        content = (ROOT / relative).read_text()
        for setting in required:
            assert setting in content, f"{relative}: missing {setting}"
        assert "3600" in content, f"{relative}: warm-pool default missing"


def test_low_confidence_review_is_enabled_in_backend_defaults() -> None:
    config = (ROOT / "services/sttm-builder/app/core/config.py").read_text()
    match = re.search(
        r"low_confidence_join_review_v1: bool = Field\(\s*default=(True|False)",
        config,
    )
    assert match and match.group(1) == "True"


def test_interactive_sttm_load_defers_and_does_not_cache_heavy_history() -> None:
    service = (ROOT / "services/sttm-builder/app/core/project_service.py").read_text()
    router = (ROOT / "services/sttm-builder/app/routers/projects.py").read_text()

    assert "versions=self._list_versions(sttm_id) if include_history else []" in service
    assert "agent_artifacts=self._list_artifacts(sttm_id) if include_history else []" in service
    assert "settings.backend_read_cache_v1 and not include_history" in router
    assert "projects:sttm-detail:" in router
