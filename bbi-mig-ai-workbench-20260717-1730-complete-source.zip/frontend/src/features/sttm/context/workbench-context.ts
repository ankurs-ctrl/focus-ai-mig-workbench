import type {
  MappingIntent,
  RelationshipContextItem,
  TableRef,
  WorkbenchContextSnapshotV2,
} from "@/types/api-contract";
import type {
  ColumnGroup,
  DerivedSource,
  JoinConfig,
  MappingState,
  RuleGroup,
  TableNode,
} from "@/features/sttm/types/sttm.types";

export type WorkbenchCheckpoint =
  | "project.created"
  | "mapping.created"
  | "target.selected"
  | "source_set.completed"
  | "join.completed"
  | "derived_source.saved"
  | "auto_map.requested"
  | "transformation.requested"
  | "assistant.requested"
  | "validation.completed"
  | "sttm.published"
  | string;

export type WorkbenchSnapshotInput = {
  action: WorkbenchCheckpoint;
  milestone?: string | null;
  page: string;
  surface: string;
  sessionId?: string | null;
  threadId?: string | null;
  projectId?: string | null;
  projectName?: string | null;
  projectDescription?: string | null;
  projectDomain?: string | null;
  projectOutcome?: string | null;
  sttmId?: string | null;
  sttmName?: string | null;
  sttmDescription?: string | null;
  mappingLifecycle?: string | null;
  businessGoal?: string | null;
  sourceTables: TableNode[];
  targetTable?: TableNode | null;
  drivingTableId?: string | null;
  sourceAttributeGroups?: ColumnGroup[];
  derivedSources?: DerivedSource[];
  relationships?: JoinConfig[];
  sourceFilterSql?: string;
  sourceQuerySql?: string;
  sourceGroupBySql?: string;
  sourceOrderBySql?: string;
  sourceFilterGroups?: RuleGroup[];
  mappings?: MappingState[];
  selectedMappingIds?: string[];
  activeMappingId?: string | null;
  mappingSql?: string | null;
  mappingPreviewSql?: string | null;
  mappingIntent?: MappingIntent | null;
  semanticBundleId?: string | null;
  semanticBundleHash?: string | null;
  semanticBundleLabel?: string | null;
  semanticLevel?: string | null;
  semanticStatus?: string | null;
  semanticViewName?: string | null;
  semanticLineage?: Array<Record<string, unknown>>;
  mappingArtifacts?: Array<Record<string, unknown>>;
  validationHistory?: Array<Record<string, unknown>>;
  scopeType?: WorkbenchContextSnapshotV2["scope_type"];
  candidateAction?: string | null;
  browsingContext?: WorkbenchContextSnapshotV2["browsing_context"];
};

export function tableRefFromQualifiedName(qualifiedName?: string | null): TableRef | null {
  if (!qualifiedName) return null;
  const parts = qualifiedName
    .split(".")
    .map((part) => part.replace(/^"|"$/g, "").trim())
    .filter(Boolean);
  if (parts.length < 3) return null;
  return { database: parts[0], schema: parts[1], table: parts.slice(2).join(".") };
}

function candidateTableFqn(value: unknown): string | null {
  if (typeof value === "string") {
    const normalized = value.trim();
    return normalized || null;
  }
  if (!value || typeof value !== "object") return null;

  const record = value as Record<string, unknown>;
  const qualifiedName = record.qualifiedName ?? record.qualified_name ?? record.fqn;
  if (typeof qualifiedName === "string" && qualifiedName.trim()) {
    return qualifiedName.trim();
  }

  const database = record.database ?? record.database_name;
  const schema = record.schema ?? record.schema_name;
  const table = record.table ?? record.table_name ?? record.name;
  if (
    typeof database === "string"
    && typeof schema === "string"
    && typeof table === "string"
  ) {
    return `${database}.${schema}.${table}`;
  }
  return null;
}

function normalizeBrowsingContext(
  browsingContext: WorkbenchContextSnapshotV2["browsing_context"],
): WorkbenchContextSnapshotV2["browsing_context"] {
  if (!browsingContext) return null;
  const candidates = (
    browsingContext.visible_candidate_tables ?? []
  ) as unknown[];
  return {
    ...browsingContext,
    visible_candidate_tables: Array.from(
      new Set(candidates.map(candidateTableFqn).filter((value): value is string => Boolean(value))),
    ).sort(),
  };
}

function selectedColumns(groups: ColumnGroup[] = []): Record<string, string[]> {
  return Object.fromEntries(
    groups
      .map((group) => [
        group.qualifiedName,
        group.columns
          .filter((column) => column.selected)
          .map((column) => String(column.name || ""))
          .filter(Boolean)
          .sort(),
      ] as const)
      .filter(([, columns]) => columns.length > 0)
      .sort(([left], [right]) => left.localeCompare(right)),
  );
}

function relationshipItems(relationships: JoinConfig[] = []): RelationshipContextItem[] {
  return relationships
    .filter((relationship) => relationship.leftTableId && relationship.rightTableId)
    .map((relationship) => ({
      left_table: tableRefFromQualifiedName(relationship.leftTableId)!,
      right_table: tableRefFromQualifiedName(relationship.rightTableId)!,
      join_type: relationship.joinType,
      constraint_name: relationship.constraintName,
      source: relationship.source,
      locked: relationship.locked,
      conditions: (relationship.conditions ?? []).map((condition) => ({
        left_column: condition.leftColumn ?? "",
        operator: condition.operator,
        right_column: condition.rightColumn ?? "",
      })),
    }));
}

export function buildWorkbenchContextSnapshot(
  input: WorkbenchSnapshotInput,
): WorkbenchContextSnapshotV2 {
  const sourceTables = input.sourceTables
    .map((table) => tableRefFromQualifiedName(table.qualifiedName))
    .filter((table): table is TableRef => Boolean(table))
    .sort((left, right) =>
      `${left.database}.${left.schema}.${left.table}`.localeCompare(
        `${right.database}.${right.schema}.${right.table}`,
      ),
    );
  const selectedDerived = (input.derivedSources ?? []).filter((source) => source.isSelected);
  const relationships = relationshipItems(input.relationships);

  return {
    context_version: "2.0",
    context_hash: "",
    context_key: "",
    captured_at: new Date().toISOString(),
    page: input.page,
    surface: input.surface,
    action: input.action,
    milestone: input.milestone ?? input.action,
    checkpoint: input.milestone ?? input.action,
    scope_type: input.scopeType ?? (input.browsingContext ? "schema" : "table_set"),
    scope_key: "",
    candidate_action: input.candidateAction ?? null,
    browsing_context: normalizeBrowsingContext(input.browsingContext),
    session_id: input.sessionId ?? null,
    thread_id: input.threadId ?? null,
    project_id: input.projectId ?? null,
    project_name: input.projectName ?? null,
    project_description: input.projectDescription ?? null,
    project_domain: input.projectDomain ?? null,
    project_outcome: input.projectOutcome ?? null,
    sttm_id: input.sttmId ?? null,
    sttm_name: input.sttmName ?? null,
    sttm_description: input.sttmDescription ?? null,
    mapping_lifecycle: input.mappingLifecycle ?? null,
    business_goal: input.businessGoal ?? null,
    source_tables: sourceTables,
    target_table: input.targetTable
      ? tableRefFromQualifiedName(input.targetTable.qualifiedName)
      : null,
    driving_table: tableRefFromQualifiedName(input.drivingTableId),
    selected_columns_by_table: selectedColumns(input.sourceAttributeGroups),
    derived_sources: selectedDerived.map((source) => ({
      id: source.id,
      name: source.sourceName,
      selected_columns_by_table: source.selectedColumnsByTable ?? {},
      lineage: (input.semanticLineage ?? []).filter(
        (item) => item.derived_source_id === source.id || item.id === source.id,
      ),
    })),
    relationships,
    filters: {
      filter_sql: input.sourceFilterSql ?? null,
      base_query_sql: input.sourceQuerySql ?? null,
      group_by_sql: input.sourceGroupBySql ?? null,
      order_by_sql: input.sourceOrderBySql ?? null,
      groups: (input.sourceFilterGroups ?? []) as unknown as Array<Record<string, unknown>>,
    },
    mapping_intent: input.mappingIntent ?? null,
    mapping_rows: (input.mappings ?? []).map((mapping) => ({
      id: mapping.id,
      target_column: mapping.targetColumn,
      target_type: mapping.targetType,
      source_columns: mapping.sourceColumns ?? (mapping.sourceColumn ? [mapping.sourceColumn] : []),
      source_type: mapping.sourceType,
      mapping_mode: mapping.mappingMode ?? "source",
      constant_value: mapping.constantValue ?? null,
      rule: mapping.rule,
      expression: mapping.expression,
      natural_language_rule: mapping.nlRule,
      description: mapping.description,
      load_order: mapping.loadOrder,
      confidence: mapping.confidenceScore,
      confidence_reason: mapping.confidenceReason,
      used_inference_ids: mapping.usedInferenceIds ?? [],
      used_recommendation_ids: mapping.usedRecommendationIds ?? [],
      used_learning_ids: mapping.usedLearningIds ?? [],
      status: mapping.status,
    })),
    checked_mapping_row_ids: input.selectedMappingIds ?? [],
    active_mapping_row_id: input.activeMappingId ?? null,
    mapping_sql: input.mappingSql ?? null,
    mapping_preview_sql: input.mappingPreviewSql ?? null,
    semantic: {
      bundle_id: input.semanticBundleId ?? null,
      bundle_hash: input.semanticBundleHash ?? null,
      bundle_label: input.semanticBundleLabel ?? null,
      level: input.semanticLevel ?? null,
      status: input.semanticStatus ?? null,
      view_name: input.semanticViewName ?? null,
    },
    semantic_bundle: {
      bundle_id: input.semanticBundleId ?? null,
      bundle_hash: input.semanticBundleHash ?? null,
      bundle_label: input.semanticBundleLabel ?? null,
      level: input.semanticLevel ?? null,
      status: input.semanticStatus ?? null,
      semantic_view_name: input.semanticViewName ?? null,
      source_tables: sourceTables,
      target_table: input.targetTable
        ? tableRefFromQualifiedName(input.targetTable.qualifiedName)
        : null,
      driving_table: tableRefFromQualifiedName(input.drivingTableId),
      derived_source_ids: selectedDerived.map((source) => source.id).sort(),
    },
    mapping_artifacts: input.mappingArtifacts ?? [],
    validation_history: input.validationHistory ?? [],
  };
}
