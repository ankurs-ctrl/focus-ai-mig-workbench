'use client';

import SourceTargetItem from './source-target-item';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { useMemo } from 'react';
import { WorkspaceEmptyMessage } from './workspace-empty-message';

type SourceTargetListProps = {
  type: 'source' | 'target';
  searchTerm?: string;
  /** Highlight state for the card, separate from whether the table is in the workspace. */
  isSelected?: (id: string) => boolean;
  onSelect?: (id: string, event: React.MouseEvent, orderedIds: string[]) => void;
};

export default function SourceTargetList({
  type,
  searchTerm = '',
  isSelected,
  onSelect,
}: SourceTargetListProps) {
  const { sources, targets } = useSttmBuilderContext();
  const items = type === 'source' ? sources : targets;

  const filteredItems = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    const workspaceItems = items.filter((item) => item.isSelected);
    const baseItems = !query
      ? workspaceItems
      : workspaceItems.filter((item) => {
          const haystack = [item.tableName, item.qualifiedName, item.tag]
            .filter(Boolean)
            .join(' ')
            .toLowerCase();

          return haystack.includes(query);
        });

    if (type === 'target') {
      return baseItems;
    }

    return [...baseItems].sort((left, right) => {
      if (left.isSelected === right.isSelected) {
        return 0;
      }
      return left.isSelected ? -1 : 1;
    });
  }, [items, searchTerm, type]);

  const orderedIds = useMemo(
    () => filteredItems.map((item) => item.tableId),
    [filteredItems],
  );

  // Clicking a card highlights it in place. Removing a table from the workspace
  // is done from the selection tree or Clear All, so a stray click cannot drop it.
  const selectHandler = (id: string, event: React.MouseEvent) => {
    onSelect?.(id, event, orderedIds);
  };

  if (filteredItems.length === 0) {
    return (
      <WorkspaceEmptyMessage>
        {type === "source"
          ? "Drag tables, schemas, or databases from Source Selection into this area."
          : "Drag one table from Target Selection into this area."}
      </WorkspaceEmptyMessage>
    );
  }

  return (
    <div>
      {filteredItems.map((item) => (
        <SourceTargetItem
          type={type}
          key={item.tableId}
          item={item}
          isSelected={isSelected?.(item.tableId) ?? false}
          selectHandler={selectHandler}
        />
      ))}
    </div>
  );
}
