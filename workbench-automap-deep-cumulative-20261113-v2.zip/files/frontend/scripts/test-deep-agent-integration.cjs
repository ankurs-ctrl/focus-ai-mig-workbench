const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const vm = require('node:vm');
const ts = require('typescript');
const root = path.resolve(__dirname, '../src/features/ai-agent');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const transpile = source => ts.transpileModule(source, { compilerOptions: {
  module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX,
}}).outputText;
const tree = (name) => ts.createSourceFile(name, read(name), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
function find(ast, predicate) {
  let match;
  function visit(node) { if (predicate(node)) match = node; ts.forEachChild(node, visit); }
  visit(ast); assert.ok(match); return match;
}
function evaluate(source, context) { return vm.runInNewContext(transpile(`(${source})`), context); }
const jsx = (type, props, key) => ({ type, props, key });
const components = new Proxy({}, { get: (_, key) => key });
let api = { deepAvailable: true, modelOptions: ['account-configured-model'] };
const m = new Module(path.join(root, 'ai-agent-page-composer.tsx'), module);
m.require = name => {
  if (name === 'react') return { useState: initial => [initial, () => {}], useRef: initial => ({ current: initial }) };
  if (name === 'react/jsx-runtime') return { jsx, jsxs: jsx };
  if (name === './use-ai-agent-send') return { useAiAgentSendApi: () => api };
  if (name === './context-meter') return { ContextMeter: 'ContextMeter' };
  if (name.includes('typography-tokens')) return { textStyleCssVars: () => ({}) };
  if (name.includes('layout-constants')) return { AI_AGENT_PAGE_CONTENT_MAX_WIDTH: 960 };
  return components;
};
m._compile(transpile(read('ai-agent-page-composer.tsx')), path.join(root, 'ai-agent-page-composer.tsx'));
const render = m.exports.AiAgentPageComposer;
function nodes(value) {
  if (Array.isArray(value)) return value.flatMap(nodes);
  if (!value || typeof value !== 'object') return [];
  return [value, ...nodes(value.props?.children)];
}
function text(value) {
  if (Array.isArray(value)) return value.map(text).join(' ');
  if (value && typeof value === 'object') return [text(value.props?.children), text(value.props?.primary)].filter(Boolean).join(" ");
  return typeof value === 'string' ? value : '';
}
(async () => {
  let options = { runMode: 'auto', effort: 'auto', modelName: null }, submitted;
  const props = () => ({ value: 'Create the full mapping', onChange() {}, options,
    onOptionsChange: value => { options = value; }, onSend: value => { submitted = value; } });
  let rendered = render(props());
  const plan = nodes(rendered).find(node => node.type === 'AiaMenuItem' && /Plan/.test(text(node)));
  assert.ok(plan); plan.props.onClick();
  assert.equal(options.runMode, 'plan');
  nodes(render(props())).find(node => node.key === 'low').props.onClick();
  assert.equal(options.effort, 'light', 'the UI Low effort selection is the backend light enum');
  nodes(render(props())).find(node => node.key === 'account-configured-model').props.onClick();
  assert.equal(options.modelName, 'account-configured-model');
  nodes(render(props())).find(node => node.props?.['aria-label'] === 'Send message').props.onClick();
  assert.deepEqual(submitted, options);
  // A new centered/docked composer instance keeps the page-owned selections.
  assert.ok(nodes(render(props())).some(node => text(node) === 'account-configured-model'));
  assert.ok(!nodes(render(props())).some(node => node.key === 'cortex'));
  let uploaded = [];
  api = { ...api, attachFile: async file => uploaded.push(file.name) };
  await nodes(render(props())).find(node => node.type === 'input').props.onChange({ target: { files: [{ name: 'rules.sql' }] } });
  assert.deepEqual(uploaded, ['rules.sql']);
  let stopped = 0;
  api = { ...api, isRunning: true, cancel: () => { stopped++; } };
  const stop = nodes(render({ ...props(), loading: true })).find(node => node.props?.['aria-label'] === 'Stop agent');
  assert.equal(stop.props.disabled, false); stop.props.onClick(); assert.equal(stopped, 1);

  const page = tree('AiAgentPage.tsx');
  const pendingEffect = find(page, node => ts.isCallExpression(node) && node.expression.getText(page) === 'useEffect'
    && node.arguments[0]?.getText(page).includes('const pending = pendingSendRef.current'));
  let sent = [], cleared = 0;
  const pendingSendRef = { current: { message: 'map all columns', projectId: 'project-b', options } };
  const sendApi = { deepAvailable: true, isLoading: false, scopeProjectId: 'project-a',
    send: (message, settings) => { sent.push([message, settings]); return true; } };
  const context = { pendingSendRef, sendApi, activeProjectId: 'project-b', GENERAL_PROJECT_VALUE: '', setDraft: () => { cleared++; } };
  const effect = () => evaluate(pendingEffect.arguments[0].getText(page), context)();
  effect(); assert.equal(sent.length, 0, 'browse submission cannot use the old project sender');
  sendApi.scopeProjectId = 'project-b'; context.activeProjectId = 'project-a'; effect(); assert.equal(sent.length, 0);
  context.activeProjectId = 'project-b'; effect(); effect();
  assert.equal(sent.length, 1); assert.equal(cleared, 1); assert.equal(sent[0][1], options);

  const panel = tree('deep-agent-panel.tsx');
  const connect = find(panel, node => ts.isVariableDeclaration(node) && node.name.getText(panel) === 'connectAndSendMigrationAgentMessage');
  let backendOptions, backendMessage;
  const client = { setOptions: value => { backendOptions = value; }, sendMessage: message => { backendMessage = message; } };
  const send = evaluate(connect.initializer.arguments[0].getText(panel), {
    migrationAgentClientRef: { current: client }, buildWorkspaceSnapshot: () => ({}), migrationAttachments: [],
    migrationAgentMessages: [], shouldAutoScrollRef: {}, animateMigrationAgentMessagesRef: {},
    setMigrationAgentMessages() {}, setMigrationAgentState() {}, migrationAgentState: { isConnected: true },
    migrationEffort: 'medium', migrationModelName: null, migrationRunMode: 'auto',
  });
  await send('Map every target', options);
  assert.equal(backendMessage, 'Map every target');
  assert.equal(backendOptions.effort, 'light'); assert.equal(backendOptions.runMode, 'plan');
  assert.equal(backendOptions.modelName, 'account-configured-model');
  console.log('Deep Agent controls, mode/model payloads, attachments, cancellation and project-scope handoff passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
