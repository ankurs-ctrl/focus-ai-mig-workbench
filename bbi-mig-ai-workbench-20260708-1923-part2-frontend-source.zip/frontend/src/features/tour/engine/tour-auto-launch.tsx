"use client";

import { useEffect, useRef } from "react";

import type { TourId } from "../types/tour.types";
import { hasSeenTour } from "./tour-persistence";
import {
  resolveContextualTourIdForPath,
  resolvePrimaryTourIdForPath,
} from "./tour-resolve";

type StartTourOptions = {
  autoLaunch?: boolean;
};

const NAV_AUTO_START_DELAY_MS = 600;
const CONTEXT_AUTO_START_DELAY_MS = 400;
const AUTO_START_RETRY_MS = 300;
const AUTO_START_MAX_ATTEMPTS = 30;

type TourAutoLaunchProps = {
  pathname: string;
  modalTourId: TourId | null;
  isOpen: boolean;
  startTour: (tourId: TourId, options?: StartTourOptions) => void;
  /** Bumps on route change or modal open. */
  navigationLaunchKey?: string | number;
  /** Bumps on row selection, automap, tab change, etc. */
  contextLaunchKey?: string | number;
};

export function TourAutoLaunch({
  pathname,
  modalTourId,
  isOpen,
  startTour,
  navigationLaunchKey = 0,
  contextLaunchKey = 0,
}: TourAutoLaunchProps) {
  const isOpenRef = useRef(isOpen);
  isOpenRef.current = isOpen;

  const startTourRef = useRef(startTour);
  startTourRef.current = startTour;

  /** Primary page tour — first visit per session when navigating to a route. */
  useEffect(() => {
    let cancelled = false;
    let attempts = 0;
    let retryTimer: number | undefined;

    const attempt = () => {
      if (cancelled || isOpenRef.current) return;

      const tourId = modalTourId ?? resolvePrimaryTourIdForPath(pathname);
      if (!tourId) {
        attempts += 1;
        if (attempts < AUTO_START_MAX_ATTEMPTS) {
          retryTimer = window.setTimeout(attempt, AUTO_START_RETRY_MS);
        }
        return;
      }

      if (hasSeenTour(tourId)) return;

      startTourRef.current(tourId, { autoLaunch: true });
    };

    const startTimer = window.setTimeout(attempt, NAV_AUTO_START_DELAY_MS);

    return () => {
      cancelled = true;
      window.clearTimeout(startTimer);
      if (retryTimer) window.clearTimeout(retryTimer);
    };
  }, [modalTourId, pathname, navigationLaunchKey]);

  /** Contextual tour — row selection, automap, tabs (first time per session only). */
  useEffect(() => {
    if (modalTourId) return;

    let cancelled = false;
    let attempts = 0;
    let retryTimer: number | undefined;

    const attempt = () => {
      if (cancelled || isOpenRef.current) return;

      const tourId = resolveContextualTourIdForPath(pathname);
      if (!tourId) {
        attempts += 1;
        if (attempts < AUTO_START_MAX_ATTEMPTS) {
          retryTimer = window.setTimeout(attempt, AUTO_START_RETRY_MS);
        }
        return;
      }

      if (hasSeenTour(tourId)) return;

      startTourRef.current(tourId, { autoLaunch: true });
    };

    const startTimer = window.setTimeout(attempt, CONTEXT_AUTO_START_DELAY_MS);

    return () => {
      cancelled = true;
      window.clearTimeout(startTimer);
      if (retryTimer) window.clearTimeout(retryTimer);
    };
  }, [contextLaunchKey, isOpen, modalTourId, pathname]);

  return null;
}
